"""Knowledge sync manager for offline agent synchronization.

Enables agents to catch up on missed knowledge when rejoining the mesh.
"""

import json
import struct
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Callable, List
from collections import deque

from mesh.learning.broadcast import KnowledgePacket, KnowledgeType


@dataclass
class SyncRequest:
    """Request for missed knowledge."""
    requester_id: bytes  # 8 bytes
    last_version: int    # Last version we have
    agent_types: list[str] = field(default_factory=list)  # Filter by agent type

    def to_bytes(self) -> bytes:
        agent_types_json = json.dumps(self.agent_types).encode('utf-8')
        return (
            self.requester_id.ljust(8, b'\x00')[:8] +
            self.last_version.to_bytes(8, 'big') +
            len(agent_types_json).to_bytes(4, 'big') +
            agent_types_json
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "SyncRequest":
        requester_id = data[:8]
        last_version = int.from_bytes(data[8:16], 'big')
        agent_types_len = int.from_bytes(data[16:20], 'big')
        agent_types = json.loads(data[20:20 + agent_types_len].decode('utf-8'))
        return cls(
            requester_id=requester_id,
            last_version=last_version,
            agent_types=agent_types,
        )


@dataclass
class SyncResponse:
    """Response with missed knowledge."""
    responder_id: bytes  # 8 bytes
    packets: list[KnowledgePacket] = field(default_factory=list)
    has_more: bool = False  # More packets available

    def to_bytes(self) -> bytes:
        packets_data = b''.join(
            len(p.to_bytes()).to_bytes(4, 'big') + p.to_bytes()
            for p in self.packets
        )
        return (
            self.responder_id.ljust(8, b'\x00')[:8] +
            len(self.packets).to_bytes(4, 'big') +
            (1 if self.has_more else 0).to_bytes(1, 'big') +
            packets_data
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "SyncResponse":
        responder_id = data[:8]
        packet_count = int.from_bytes(data[8:12], 'big')
        has_more = bool(data[12])

        packets = []
        offset = 13
        for _ in range(packet_count):
            pkt_len = int.from_bytes(data[offset:offset + 4], 'big')
            pkt_data = data[offset + 4:offset + 4 + pkt_len]
            packets.append(KnowledgePacket.from_bytes(pkt_data))
            offset += 4 + pkt_len

        return cls(
            responder_id=responder_id,
            packets=packets,
            has_more=has_more,
        )


class KnowledgeSyncManager:
    """Manages knowledge synchronization for offline agents.

    When an agent rejoins the mesh:
    1. Sends SyncRequest with last_version
    2. Peers respond with missed knowledge (SyncResponse)
    3. Agent applies deltas in version order

    Also maintains a history buffer for responding to sync requests.
    """

    # Maximum packets to keep in history
    MAX_HISTORY_SIZE = 1000

    # Maximum packets per sync response
    MAX_PACKETS_PER_RESPONSE = 50

    def __init__(
        self,
        model_id: bytes,
        send_sync_request: Optional[Callable[[bytes], None]] = None,
        send_sync_response: Optional[Callable[[bytes, bytes], None]] = None,
    ):
        """Initialize the sync manager.

        Args:
            model_id: This agent's 8-byte model identifier
            send_sync_request: Function to broadcast sync request
            send_sync_response: Function to send response to requester
        """
        self.model_id = model_id.ljust(8, b'\x00')[:8]
        self._send_request = send_sync_request
        self._send_response = send_sync_response

        # History buffer (ordered by version)
        self._history: deque[KnowledgePacket] = deque(maxlen=self.MAX_HISTORY_SIZE)

        # Track our current version
        self._current_version = 0

        # Pending sync state
        self._syncing = False
        self._sync_responses_received = 0
        self._expected_responses = 0

        # Callbacks
        self._on_sync_complete: Optional[Callable[[list[KnowledgePacket]], None]] = None

    def add_to_history(self, packet: KnowledgePacket) -> None:
        """Add a packet to the history buffer.

        Called when broadcasting or receiving knowledge.
        """
        self._history.append(packet)

        # Update version tracking
        if packet.version > self._current_version:
            self._current_version = packet.version

    def request_sync(
        self,
        last_version: int = 0,
        agent_types: Optional[list[str]] = None,
    ) -> None:
        """Request sync from peers.

        Args:
            last_version: Last version we have (0 for full sync)
            agent_types: Optional filter by agent type
        """
        if self._syncing:
            return  # Already syncing

        request = SyncRequest(
            requester_id=self.model_id,
            last_version=last_version,
            agent_types=agent_types or [],
        )

        if self._send_request:
            self._syncing = True
            self._sync_responses_received = 0
            self._send_request(request.to_bytes())

    def handle_sync_request(self, data: bytes) -> Optional[bytes]:
        """Handle an incoming sync request.

        Args:
            data: Raw SyncRequest bytes

        Returns:
            SyncResponse bytes to send back
        """
        try:
            request = SyncRequest.from_bytes(data)
        except Exception:
            return None

        # Don't respond to our own requests
        if request.requester_id == self.model_id:
            return None

        # Find packets newer than last_version
        packets_to_send = []
        for packet in self._history:
            if packet.version > request.last_version:
                # Filter by agent type if requested
                if request.agent_types:
                    try:
                        payload = json.loads(packet.payload.decode('utf-8'))
                        if payload.get("agent_type") not in request.agent_types:
                            continue
                    except Exception:
                        pass

                packets_to_send.append(packet)

                if len(packets_to_send) >= self.MAX_PACKETS_PER_RESPONSE:
                    break

        has_more = len([
            p for p in self._history
            if p.version > request.last_version
        ]) > len(packets_to_send)

        response = SyncResponse(
            responder_id=self.model_id,
            packets=packets_to_send,
            has_more=has_more,
        )

        return response.to_bytes()

    def handle_sync_response(self, data: bytes) -> list[KnowledgePacket]:
        """Handle an incoming sync response.

        Args:
            data: Raw SyncResponse bytes

        Returns:
            List of packets to process
        """
        try:
            response = SyncResponse.from_bytes(data)
        except Exception:
            return []

        self._sync_responses_received += 1

        # Sort packets by version
        packets = sorted(response.packets, key=lambda p: p.version)

        # Update our version tracking
        if packets:
            max_version = max(p.version for p in packets)
            if max_version > self._current_version:
                self._current_version = max_version

        # Check if sync is complete
        # (Simple heuristic: no more packets)
        if not response.has_more:
            self._syncing = False
            if self._on_sync_complete:
                self._on_sync_complete(packets)

        return packets

    def is_syncing(self) -> bool:
        """Check if we're currently syncing."""
        return self._syncing

    def get_current_version(self) -> int:
        """Get the current knowledge version."""
        return self._current_version

    def on_sync_complete(self, callback: Callable[[list[KnowledgePacket]], None]) -> None:
        """Set callback for when sync completes."""
        self._on_sync_complete = callback

    def get_history_size(self) -> int:
        """Get the number of packets in history."""
        return len(self._history)

    def get_stats(self) -> dict:
        """Get sync manager statistics."""
        return {
            "model_id": self.model_id.hex(),
            "current_version": self._current_version,
            "history_size": len(self._history),
            "is_syncing": self._syncing,
            "sync_responses_received": self._sync_responses_received,
        }
