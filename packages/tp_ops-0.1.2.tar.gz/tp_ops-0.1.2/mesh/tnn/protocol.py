"""TNN Mesh Protocol - Zero-config discovery and security.

Implements the TNN-based mesh nervous system:
- TNN probes for zero-config discovery
- TNN signatures on all mesh messages
- Challenge-response handshakes
- Adaptive routing weights

TRADE SECRET - TERNARYPHYSICS, INC.
"""

import os
import time
import struct
import secrets
import logging
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Tuple, Callable
from datetime import datetime, timedelta

from mesh.tnn.bindings import TNN, TNNSignature

logger = logging.getLogger(__name__)

# Protocol constants
TNN_PROBE_MAGIC = b"TNN1"
TNN_PROTOCOL_VERSION = 1
HANDSHAKE_TIMEOUT_MS = 5000
PROBE_INTERVAL_MS = 1000
MAX_PEER_SILENCE_MS = 30000

# Message types
TNN_MSG_TYPE_PROBE = 0       # Discovery probe
TNN_MSG_TYPE_RESPONSE = 1    # Probe response
TNN_MSG_TYPE_QUERY = 2       # Agent query
TNN_MSG_TYPE_ACK = 3         # Acknowledgment
TNN_MSG_TYPE_KNOWLEDGE = 4   # Broadcast learned pattern
TNN_MSG_TYPE_SYNC_REQ = 5    # Request missed knowledge
TNN_MSG_TYPE_SYNC_RESP = 6   # Send missed knowledge


@dataclass
class TNNPeer:
    """A discovered mesh peer with TNN identity."""
    model_id: int
    host: str
    port: int
    agent_name: str
    agent_type: str
    capabilities: List[str] = field(default_factory=list)
    last_seen: datetime = field(default_factory=datetime.utcnow)
    rtt_ms: float = 0.0
    handshake_complete: bool = False
    routing_weight: float = 1.0  # TNN-learned routing preference

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"

    def is_alive(self) -> bool:
        """Check if peer is still responding."""
        silence = (datetime.utcnow() - self.last_seen).total_seconds() * 1000
        return silence < MAX_PEER_SILENCE_MS


@dataclass
class TNNProbe:
    """TNN discovery probe packet.

    Format (48 bytes):
        magic:      4 bytes  "TNN1"
        version:    1 byte
        msg_type:   1 byte   (0=probe, 1=response, 2=query, 3=ack)
        flags:      2 bytes
        model_id:   8 bytes
        nonce:      8 bytes
        timestamp:  8 bytes
        signature:  16 bytes (first 16 bytes of TNN signature)
    """
    magic: bytes = TNN_PROBE_MAGIC
    version: int = TNN_PROTOCOL_VERSION
    msg_type: int = 0  # 0=probe, 1=response
    flags: int = 0
    model_id: int = 0
    nonce: int = 0
    timestamp: int = 0
    signature: bytes = b"\x00" * 16

    def pack(self) -> bytes:
        """Pack probe to bytes."""
        return struct.pack(
            "<4sBBHQQQ16s",
            self.magic,
            self.version,
            self.msg_type,
            self.flags,
            self.model_id,
            self.nonce,
            self.timestamp,
            self.signature[:16]
        )

    @classmethod
    def unpack(cls, data: bytes) -> "TNNProbe":
        """Unpack probe from bytes."""
        if len(data) < 48:
            raise ValueError("Probe too short")

        magic, version, msg_type, flags, model_id, nonce, timestamp, sig = \
            struct.unpack("<4sBBHQQQ16s", data[:48])

        return cls(
            magic=magic,
            version=version,
            msg_type=msg_type,
            flags=flags,
            model_id=model_id,
            nonce=nonce,
            timestamp=timestamp,
            signature=sig
        )


@dataclass
class TNNMessage:
    """TNN-signed mesh message.

    Format:
        header (16 bytes):
            magic:      4 bytes  "TNN1"
            version:    1 byte
            msg_type:   1 byte
            flags:      2 bytes
            length:     4 bytes  (payload length)
            reserved:   4 bytes
        signature:  32 bytes  (full TNN signature)
        payload:    variable
    """
    msg_type: int
    payload: bytes
    signature: TNNSignature = None
    flags: int = 0

    def pack(self, tnn: TNN) -> bytes:
        """Pack and sign message."""
        # Sign the payload
        self.signature = tnn.sign(self.payload)

        header = struct.pack(
            "<4sBBHII",
            TNN_PROBE_MAGIC,
            TNN_PROTOCOL_VERSION,
            self.msg_type,
            self.flags,
            len(self.payload),
            0  # reserved
        )

        return header + self.signature.bytes + self.payload

    @classmethod
    def unpack(cls, data: bytes) -> Tuple["TNNMessage", bytes]:
        """Unpack message (does not verify signature)."""
        if len(data) < 48:  # 16 header + 32 signature
            raise ValueError("Message too short")

        magic, version, msg_type, flags, length, _ = \
            struct.unpack("<4sBBHII", data[:16])

        if magic != TNN_PROBE_MAGIC:
            raise ValueError(f"Invalid magic: {magic}")

        sig = TNNSignature(data[16:48])
        payload = data[48:48 + length]

        return cls(
            msg_type=msg_type,
            payload=payload,
            signature=sig,
            flags=flags
        ), data[48 + length:]

    def verify(self, tnn: TNN) -> bool:
        """Verify message signature."""
        if self.signature is None:
            return False
        return tnn.verify(self.payload, self.signature)


class TNNHandshake:
    """TNN challenge-response handshake.

    Protocol:
    1. Initiator sends challenge (random nonce + model_id)
    2. Responder computes response = TNN_forward(challenge || initiator_id || nonce)
    3. Initiator verifies response using responder's TNN weights
    4. If valid, connection is authenticated

    The handshake proves both parties have compatible TNN models
    (either identical weights, or weights that produce similar outputs).
    """

    def __init__(self, local_tnn: TNN):
        self.tnn = local_tnn
        self._pending: Dict[int, Tuple[bytes, int, float]] = {}  # nonce → (challenge, peer_id, timestamp)

    def create_challenge(self) -> Tuple[bytes, int]:
        """Create a challenge for a peer.

        Returns:
            (challenge_bytes, nonce)
        """
        nonce = secrets.randbits(64)
        challenge = secrets.token_bytes(32)

        # Store for later verification
        self._pending[nonce] = (challenge, 0, time.time())

        return challenge, nonce

    def respond_to_challenge(self, challenge: bytes, peer_id: int, nonce: int) -> bytes:
        """Respond to a challenge from a peer.

        Args:
            challenge: Challenge bytes
            peer_id: Peer's model ID
            nonce: Challenge nonce

        Returns:
            Response bytes (32 bytes)
        """
        response = self.tnn.challenge_response(challenge, peer_id, nonce)
        # Pack response as bytes
        return struct.pack("<16h", *response)

    def verify_response(self, response: bytes, nonce: int, peer_tnn: TNN) -> bool:
        """Verify a challenge response.

        Args:
            response: Response bytes from peer
            nonce: Original challenge nonce
            peer_tnn: Peer's TNN (or our TNN for self-verification)

        Returns:
            True if response is valid
        """
        if nonce not in self._pending:
            logger.warning(f"Unknown nonce: {nonce}")
            return False

        challenge, peer_id, timestamp = self._pending.pop(nonce)

        # Check timeout
        if (time.time() - timestamp) * 1000 > HANDSHAKE_TIMEOUT_MS:
            logger.warning("Handshake timed out")
            return False

        # Compute expected response
        expected = peer_tnn.challenge_response(
            challenge, self.tnn.model_id, nonce
        )
        expected_bytes = struct.pack("<16h", *expected)

        # Constant-time comparison
        result = 0
        for a, b in zip(response, expected_bytes):
            result |= a ^ b

        return result == 0

    def cleanup_expired(self) -> None:
        """Remove expired pending challenges."""
        now = time.time()
        expired = [
            nonce for nonce, (_, _, ts) in self._pending.items()
            if (now - ts) * 1000 > HANDSHAKE_TIMEOUT_MS
        ]
        for nonce in expired:
            del self._pending[nonce]


class TNNProtocol:
    """TNN mesh protocol handler.

    Manages:
    - Discovery via TNN probes
    - Message signing/verification
    - Peer authentication
    - Routing weight adaptation
    """

    def __init__(self, local_tnn: TNN, agent_name: str, agent_type: str,
                 capabilities: List[str] = None):
        self.tnn = local_tnn
        self.agent_name = agent_name
        self.agent_type = agent_type
        self.capabilities = capabilities or []
        self.handshake = TNNHandshake(local_tnn)

        self._peers: Dict[int, TNNPeer] = {}  # model_id → peer
        self._on_peer_discovered: Optional[Callable[[TNNPeer], None]] = None
        self._on_peer_lost: Optional[Callable[[TNNPeer], None]] = None

    @property
    def model_id(self) -> int:
        return self.tnn.model_id

    @property
    def peers(self) -> List[TNNPeer]:
        return list(self._peers.values())

    def on_peer_discovered(self, callback: Callable[[TNNPeer], None]) -> None:
        """Set callback for peer discovery."""
        self._on_peer_discovered = callback

    def on_peer_lost(self, callback: Callable[[TNNPeer], None]) -> None:
        """Set callback for peer loss."""
        self._on_peer_lost = callback

    def create_probe(self) -> bytes:
        """Create a discovery probe packet."""
        nonce = secrets.randbits(64)
        timestamp = int(time.time() * 1000)

        # Sign probe data
        probe_data = struct.pack("<QQ", nonce, timestamp)
        sig = self.tnn.sign(probe_data)

        probe = TNNProbe(
            model_id=self.tnn.model_id,
            nonce=nonce,
            timestamp=timestamp,
            signature=sig.bytes[:16]
        )

        return probe.pack()

    def create_probe_response(self, request_nonce: int) -> bytes:
        """Create a response to a discovery probe."""
        timestamp = int(time.time() * 1000)

        # Sign response
        response_data = struct.pack("<QQ", request_nonce, timestamp)
        sig = self.tnn.sign(response_data)

        probe = TNNProbe(
            msg_type=1,  # response
            model_id=self.tnn.model_id,
            nonce=request_nonce,
            timestamp=timestamp,
            signature=sig.bytes[:16]
        )

        return probe.pack()

    def handle_probe(self, data: bytes, sender_host: str, sender_port: int) -> Optional[bytes]:
        """Handle incoming probe packet.

        Args:
            data: Raw probe bytes
            sender_host: Sender's IP
            sender_port: Sender's port

        Returns:
            Response packet if this is a probe request, None otherwise
        """
        try:
            probe = TNNProbe.unpack(data)
        except Exception as e:
            logger.warning(f"Invalid probe: {e}")
            return None

        if probe.magic != TNN_PROBE_MAGIC:
            return None

        if probe.model_id == self.tnn.model_id:
            # Ignore our own probes
            return None

        # Update or create peer
        peer = self._peers.get(probe.model_id)
        is_new = peer is None

        if is_new:
            peer = TNNPeer(
                model_id=probe.model_id,
                host=sender_host,
                port=sender_port,
                agent_name="",  # Will be filled in by mesh layer
                agent_type="",
            )
            self._peers[probe.model_id] = peer

            if self._on_peer_discovered:
                self._on_peer_discovered(peer)

        peer.last_seen = datetime.utcnow()
        peer.host = sender_host
        peer.port = sender_port

        # Calculate RTT from timestamp
        now_ms = int(time.time() * 1000)
        peer.rtt_ms = now_ms - probe.timestamp

        if probe.msg_type == 0:  # Probe request
            return self.create_probe_response(probe.nonce)

        return None

    def sign_message(self, payload: bytes, msg_type: int = 2) -> bytes:
        """Sign and pack a mesh message."""
        msg = TNNMessage(msg_type=msg_type, payload=payload)
        return msg.pack(self.tnn)

    def verify_message(self, data: bytes) -> Tuple[bool, Optional[bytes]]:
        """Verify and unpack a mesh message.

        Returns:
            (is_valid, payload or None)
        """
        try:
            msg, _ = TNNMessage.unpack(data)
        except Exception as e:
            logger.warning(f"Invalid message: {e}")
            return False, None

        if msg.verify(self.tnn):
            return True, msg.payload

        return False, None

    def check_peer_health(self) -> None:
        """Check for lost peers."""
        lost = [
            peer for peer in self._peers.values()
            if not peer.is_alive()
        ]

        for peer in lost:
            del self._peers[peer.model_id]
            if self._on_peer_lost:
                self._on_peer_lost(peer)

    def update_routing_weight(self, peer_id: int, success: bool, latency_ms: float) -> None:
        """Update TNN-learned routing weight for a peer.

        Uses a simple exponential moving average with
        success/failure feedback. In production, this would
        feed into TNN online learning.
        """
        peer = self._peers.get(peer_id)
        if not peer:
            return

        # Exponential moving average
        alpha = 0.1
        reward = 1.0 if success else 0.0

        # Incorporate latency (lower is better)
        latency_factor = 1.0 / (1.0 + latency_ms / 100.0)
        reward *= latency_factor

        peer.routing_weight = (1 - alpha) * peer.routing_weight + alpha * reward

    def get_best_peer(self, capabilities: List[str] = None) -> Optional[TNNPeer]:
        """Get best peer for routing based on TNN weights.

        Args:
            capabilities: Required capabilities (optional filter)

        Returns:
            Best peer or None
        """
        candidates = [p for p in self._peers.values() if p.is_alive()]

        if capabilities:
            candidates = [
                p for p in candidates
                if any(c in p.capabilities for c in capabilities)
            ]

        if not candidates:
            return None

        # Sort by routing weight (higher is better)
        return max(candidates, key=lambda p: p.routing_weight)

    def save_state(self, path: str) -> None:
        """Save TNN and routing state."""
        self.tnn.save(path)
        # Could also save peer routing weights here

    def load_state(self, path: str) -> None:
        """Load TNN and routing state."""
        self.tnn.load(path)
