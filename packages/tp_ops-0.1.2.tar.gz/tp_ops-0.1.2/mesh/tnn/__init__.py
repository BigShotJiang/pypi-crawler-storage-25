"""TNN: Ternary Neural Network - The Mesh Nervous System.

Python bindings for the C TNN library, used for:
- Zero-config discovery via TNN probes
- Message signing and verification
- Challenge-response handshakes
- Anomaly detection

TRADE SECRET - TERNARYPHYSICS, INC.
"""

from mesh.tnn.bindings import TNN, TNNSignature
from mesh.tnn.protocol import TNNProtocol, TNNHandshake

__all__ = ["TNN", "TNNSignature", "TNNProtocol", "TNNHandshake"]
