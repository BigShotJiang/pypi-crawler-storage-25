"""Network requirements check for mesh connectivity.

Probes network to detect what's blocked and reports clearly
to the customer so they can make informed decisions.

We provide information. They make decisions. We never modify their network.
"""

import socket
import subprocess
import ipaddress
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# Mesh ports
MESH_DISCOVERY_PORT = 9701  # UDP
MESH_MESSAGING_PORT = 9702  # TCP

# Resource-specific ports
RESOURCE_PORTS = {
    "k8s-agent": [
        ("K8s API", 6443, "tcp"),
    ],
    "postgres-agent": [
        ("PostgreSQL", 5432, "tcp"),
    ],
    "redis-agent": [
        ("Redis", 6379, "tcp"),
    ],
    "vm-agent": [
        ("SSH", 22, "tcp"),
    ],
    "apigw-agent": [
        ("HTTPS", 443, "tcp"),
    ],
    "azure-agent": [
        ("Azure HTTPS", 443, "tcp"),
    ],
    "security-agent": [],
}


class ConnectivityStatus(Enum):
    """Network connectivity status."""
    OPEN = "open"
    BLOCKED = "blocked"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"


@dataclass
class PortCheck:
    """Result of a port connectivity check."""
    description: str
    port: int
    protocol: str  # "tcp" or "udp"
    target: str    # IP or subnet
    status: ConnectivityStatus = ConnectivityStatus.UNKNOWN
    error: Optional[str] = None


@dataclass
class NetworkRequirements:
    """Network requirements for an agent."""
    agent_type: str
    agent_name: str
    required_ports: List[PortCheck] = field(default_factory=list)
    blocked_ports: List[PortCheck] = field(default_factory=list)
    mesh_reachable: bool = True
    known_agent_subnets: List[str] = field(default_factory=list)


def get_local_subnets() -> List[str]:
    """Get local network subnets for probe targets."""
    subnets = []
    try:
        # Get local IPs and derive /24 subnets
        result = subprocess.run(
            ["hostname", "-I"] if subprocess.os.name != "nt" else ["hostname"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            for ip in result.stdout.strip().split():
                try:
                    addr = ipaddress.ip_address(ip)
                    if isinstance(addr, ipaddress.IPv4Address):
                        # Get /24 subnet
                        network = ipaddress.ip_network(f"{ip}/24", strict=False)
                        subnets.append(str(network))
                except ValueError:
                    continue
    except Exception as e:
        logger.debug(f"Could not get local subnets: {e}")

    # Fallback common private subnets
    if not subnets:
        subnets = ["10.0.0.0/24", "192.168.1.0/24", "172.16.0.0/24"]

    return subnets


def get_known_agent_addresses() -> List[Tuple[str, int]]:
    """Get addresses of known agents from local config."""
    from cli.auth.credentials import load_agents

    addresses = []
    try:
        agents = load_agents()
        for name, agent in agents.items():
            config = agent.get("config", {})
            # Extract host from various agent configs
            host = config.get("host")
            if host:
                # Parse host:port format
                if ":" in host:
                    h, p = host.rsplit(":", 1)
                    addresses.append((h, int(p)))
                else:
                    addresses.append((host, MESH_MESSAGING_PORT))
    except Exception as e:
        logger.debug(f"Could not load agent addresses: {e}")

    return addresses


def check_tcp_port(host: str, port: int, timeout: float = 3.0) -> ConnectivityStatus:
    """Check if TCP port is reachable."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()

        if result == 0:
            return ConnectivityStatus.OPEN
        elif result in (111, 10061):  # Connection refused
            return ConnectivityStatus.OPEN  # Port reachable, just no service
        else:
            return ConnectivityStatus.BLOCKED
    except socket.timeout:
        return ConnectivityStatus.TIMEOUT
    except socket.gaierror:
        return ConnectivityStatus.UNKNOWN
    except Exception:
        return ConnectivityStatus.BLOCKED


def check_udp_port(host: str, port: int, timeout: float = 3.0) -> ConnectivityStatus:
    """Check if UDP port is reachable (best effort - UDP is connectionless)."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)

        # Send a TNN probe packet
        probe = b"TNN1\x01\x00\x00\x00" + b"\x00" * 40  # 48 byte probe
        sock.sendto(probe, (host, port))

        # Try to receive response (may timeout if no agent listening)
        try:
            data, addr = sock.recvfrom(1024)
            sock.close()
            return ConnectivityStatus.OPEN
        except socket.timeout:
            sock.close()
            # Timeout doesn't mean blocked for UDP - could just be no listener
            # We'll mark it as open unless we get ICMP unreachable
            return ConnectivityStatus.OPEN

    except socket.gaierror:
        return ConnectivityStatus.UNKNOWN
    except OSError as e:
        # ICMP port unreachable or network unreachable
        if e.errno in (101, 113, 10051, 10065):
            return ConnectivityStatus.BLOCKED
        return ConnectivityStatus.UNKNOWN
    except Exception:
        return ConnectivityStatus.UNKNOWN


def probe_subnet_for_agents(subnet: str, port: int = MESH_DISCOVERY_PORT,
                            sample_size: int = 5) -> List[Tuple[str, ConnectivityStatus]]:
    """Probe a subnet for mesh agents (samples a few IPs)."""
    results = []
    try:
        network = ipaddress.ip_network(subnet, strict=False)
        hosts = list(network.hosts())

        # Sample first, middle, and last IPs
        if len(hosts) >= sample_size:
            indices = [0, len(hosts)//4, len(hosts)//2, 3*len(hosts)//4, -1]
            sample_hosts = [hosts[i] for i in indices]
        else:
            sample_hosts = hosts[:sample_size]

        for host in sample_hosts:
            status = check_udp_port(str(host), port, timeout=1.0)
            results.append((str(host), status))

    except Exception as e:
        logger.debug(f"Error probing subnet {subnet}: {e}")

    return results


def check_network_requirements(agent_type: str, agent_name: str,
                               resource_host: Optional[str] = None) -> NetworkRequirements:
    """Check all network requirements for an agent.

    Args:
        agent_type: Type of agent (k8s-agent, postgres-agent, etc.)
        agent_name: Name being assigned to the agent
        resource_host: Host for resource-specific checks (if applicable)

    Returns:
        NetworkRequirements with all checks performed
    """
    reqs = NetworkRequirements(
        agent_type=agent_type,
        agent_name=agent_name,
    )

    # 1. Check mesh ports
    # Get known agent addresses
    known_agents = get_known_agent_addresses()
    subnets = get_local_subnets()
    reqs.known_agent_subnets = subnets

    # Check UDP discovery port to known agents
    for host, _ in known_agents:
        check = PortCheck(
            description="Mesh Discovery",
            port=MESH_DISCOVERY_PORT,
            protocol="udp",
            target=host,
        )
        check.status = check_udp_port(host, MESH_DISCOVERY_PORT)
        reqs.required_ports.append(check)
        if check.status == ConnectivityStatus.BLOCKED:
            reqs.blocked_ports.append(check)
            reqs.mesh_reachable = False

    # Check TCP messaging port to known agents
    for host, _ in known_agents:
        check = PortCheck(
            description="Mesh Messaging",
            port=MESH_MESSAGING_PORT,
            protocol="tcp",
            target=host,
        )
        check.status = check_tcp_port(host, MESH_MESSAGING_PORT)
        reqs.required_ports.append(check)
        if check.status == ConnectivityStatus.BLOCKED:
            reqs.blocked_ports.append(check)
            reqs.mesh_reachable = False

    # 2. Probe subnets for potential agents
    for subnet in subnets:
        results = probe_subnet_for_agents(subnet, sample_size=3)
        blocked_count = sum(1 for _, s in results if s == ConnectivityStatus.BLOCKED)
        if blocked_count > len(results) // 2:
            # More than half blocked = likely firewall rule
            check = PortCheck(
                description="Mesh Discovery",
                port=MESH_DISCOVERY_PORT,
                protocol="udp",
                target=subnet,
                status=ConnectivityStatus.BLOCKED,
            )
            reqs.blocked_ports.append(check)
            reqs.mesh_reachable = False

    # 3. Check resource-specific ports
    resource_ports = RESOURCE_PORTS.get(agent_type, [])
    if resource_host:
        for desc, port, proto in resource_ports:
            check = PortCheck(
                description=desc,
                port=port,
                protocol=proto,
                target=resource_host,
            )
            if proto == "tcp":
                check.status = check_tcp_port(resource_host, port)
            else:
                check.status = check_udp_port(resource_host, port)

            reqs.required_ports.append(check)
            if check.status == ConnectivityStatus.BLOCKED:
                reqs.blocked_ports.append(check)

    return reqs


def format_port_requirement(port: int, protocol: str, description: str) -> str:
    """Format a port requirement for display."""
    proto = protocol.upper()
    return f"Outbound {proto} {port} ({description})"


def format_blocked_port(check: PortCheck) -> str:
    """Format a blocked port for display."""
    proto = check.protocol.upper()
    return f"{proto} {check.port} is blocked to {check.target}"


class NetworkCheckResult(Enum):
    """Result of network check interaction."""
    PROCEED_FULL_MESH = 1       # All ports open, proceed normally
    OPEN_PORTS = 2              # Customer will open ports
    DROP_RELAY = 3              # Customer will drop relay
    CONTINUE_STANDALONE = 4     # Continue without mesh


def display_network_check(reqs: NetworkRequirements, terminal) -> NetworkCheckResult:
    """Display network check results and get customer decision.

    Args:
        reqs: Network requirements check results
        terminal: Terminal for output

    Returns:
        NetworkCheckResult indicating customer's choice
    """
    terminal.print()
    terminal.info("Checking network requirements...")
    terminal.print()

    # Show what the agent needs
    terminal.print("  This agent needs:")

    # Always show mesh ports
    terminal.print(f"  {terminal.BULLET} Outbound UDP {MESH_DISCOVERY_PORT} (mesh discovery)")
    terminal.print(f"  {terminal.BULLET} Outbound TCP {MESH_MESSAGING_PORT} (mesh messaging)")

    # Show resource-specific ports
    resource_ports = RESOURCE_PORTS.get(reqs.agent_type, [])
    for desc, port, proto in resource_ports:
        terminal.print(f"  {terminal.BULLET} Access to {desc} (port {port})")

    terminal.print()

    # If nothing blocked, proceed
    if not reqs.blocked_ports:
        terminal.success("All network paths are open")
        return NetworkCheckResult.PROCEED_FULL_MESH

    # Show what's blocked
    terminal.warning("Detected blocked paths:")
    terminal.print()

    shown_targets = set()
    for check in reqs.blocked_ports:
        if check.target not in shown_targets:
            terminal.print(f"  {terminal.BULLET} {format_blocked_port(check)}")
            shown_targets.add(check.target)

    terminal.print()
    terminal.print("  Your options:")
    terminal.print()

    # Build options based on what's blocked
    options = []

    # Option 1: Open ports
    unique_targets = list(shown_targets)
    if len(unique_targets) == 1:
        target = unique_targets[0]
        terminal.print(f"  1. Open mesh ports to {target} (enables mesh)")
    else:
        terminal.print(f"  1. Open mesh ports (enables mesh)")
    options.append(NetworkCheckResult.OPEN_PORTS)

    # Option 2: Drop relay
    terminal.print(f"  2. Drop a relay agent on a shared host")
    options.append(NetworkCheckResult.DROP_RELAY)

    # Option 3: Continue standalone
    terminal.print(f"  3. Continue without mesh (agent works independently)")
    options.append(NetworkCheckResult.CONTINUE_STANDALONE)

    terminal.print()

    # Get choice
    while True:
        try:
            choice = terminal.prompt("  Proceed? [1/2/3]")
            choice = choice.strip()
            if choice in ("1", "2", "3"):
                return options[int(choice) - 1]
            terminal.print("  Please enter 1, 2, or 3")
        except KeyboardInterrupt:
            terminal.print()
            return NetworkCheckResult.CONTINUE_STANDALONE
        except Exception:
            terminal.print("  Please enter 1, 2, or 3")


def show_relay_instructions(terminal) -> None:
    """Show instructions for dropping a relay agent."""
    terminal.print()
    terminal.info("To add a relay agent:")
    terminal.print()
    terminal.print("  1. Find a host that can reach both networks")
    terminal.print("  2. Run: tp-ops drop --type relay-agent --name relay-01")
    terminal.print("  3. The relay will be auto-discovered by other agents")
    terminal.print()
    terminal.info("Once the relay is dropped, blocked paths will automatically")
    terminal.info("route through it. No config changes needed on other agents.")
    terminal.print()


def show_port_opening_instructions(reqs: NetworkRequirements, terminal) -> None:
    """Show instructions for opening ports."""
    terminal.print()
    terminal.info("To enable mesh connectivity, open these ports:")
    terminal.print()

    shown = set()
    for check in reqs.blocked_ports:
        key = (check.port, check.protocol, check.target)
        if key not in shown:
            proto = check.protocol.upper()
            terminal.print(f"  {terminal.BULLET} {proto} {check.port} to {check.target}")
            shown.add(key)

    terminal.print()
    terminal.info("After opening ports, agents will auto-discover on next probe cycle.")
    terminal.print()
