"""Python bindings for the C TNN library using ctypes.

This module provides a pure-Python fallback implementation when
the C library is not available, ensuring the mesh always works.

TRADE SECRET - TERNARYPHYSICS, INC.
"""

import os
import struct
import hashlib
import secrets
from ctypes import (
    CDLL, Structure, c_uint64, c_uint32, c_int16, c_int, c_size_t,
    c_uint8, c_char_p, POINTER, byref, create_string_buffer, sizeof
)
from pathlib import Path
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# TNN constants (must match tnn.h)
TNN_INPUT_DIM = 64
TNN_HIDDEN_DIM = 32
TNN_OUTPUT_DIM = 16
TNN_L1_WEIGHTS = 64
TNN_L2_WEIGHTS = 16
TNN_SIG_SIZE = 32
TNN_MAGIC = 0x544E4E31  # "TNN1"
TNN_VERSION = 1


class TNNSignature:
    """TNN signature (32 bytes)."""

    def __init__(self, data: bytes = None):
        if data is None:
            self.bytes = bytes(TNN_SIG_SIZE)
        elif len(data) != TNN_SIG_SIZE:
            raise ValueError(f"Signature must be {TNN_SIG_SIZE} bytes")
        else:
            self.bytes = bytes(data)

    def __eq__(self, other) -> bool:
        if isinstance(other, TNNSignature):
            return self.bytes == other.bytes
        return False

    def __bytes__(self) -> bytes:
        return self.bytes

    def hex(self) -> str:
        return self.bytes.hex()

    @classmethod
    def from_hex(cls, hex_str: str) -> "TNNSignature":
        return cls(bytes.fromhex(hex_str))


class TNN:
    """Ternary Neural Network - the mesh nervous system.

    A tiny (2,888 parameter, <1KB) neural network used for:
    - Zero-config mesh discovery
    - Message signing/verification
    - Challenge-response handshakes
    - Anomaly detection

    Uses the C library when available, falls back to pure Python.
    """

    def __init__(self, seed: int = None, model_path: str = None):
        """Initialize TNN with random weights or load from file.

        Args:
            seed: Random seed for weight initialization
            model_path: Path to load saved model (overrides seed)
        """
        self._lib = self._load_library()
        self._use_c = self._lib is not None

        # Model data
        self._w1 = [0] * TNN_L1_WEIGHTS  # Layer 1 weights (packed ternary)
        self._b1 = [0] * TNN_HIDDEN_DIM  # Layer 1 biases (Q8.8)
        self._w2 = [0] * TNN_L2_WEIGHTS  # Layer 2 weights
        self._b2 = [0] * TNN_OUTPUT_DIM  # Layer 2 biases
        self._model_id = 0
        self._flags = 0

        if model_path and os.path.exists(model_path):
            self.load(model_path)
        else:
            if seed is None:
                seed = secrets.randbits(64)
            self._init_random(seed)

    def _load_library(self) -> Optional[CDLL]:
        """Try to load the C TNN library."""
        # Look for the library in common locations
        search_paths = [
            Path(__file__).parent.parent.parent / "build" / "libternary.a",
            Path(__file__).parent.parent.parent / "build" / "libternary.so",
            Path(__file__).parent.parent.parent / "build" / "libternary.dylib",
            Path("/usr/local/lib/libternary.so"),
            Path("/usr/local/lib/libternary.dylib"),
        ]

        # For now, use pure Python fallback
        # C library integration would require building a shared library
        # with exported TNN symbols
        return None

    def _init_random(self, seed: int) -> None:
        """Initialize with random ternary weights."""
        rng = seed

        def xorshift64(state: int) -> Tuple[int, int]:
            x = state & 0xFFFFFFFFFFFFFFFF
            x ^= (x >> 12) & 0xFFFFFFFFFFFFFFFF
            x ^= (x << 25) & 0xFFFFFFFFFFFFFFFF
            x ^= (x >> 27) & 0xFFFFFFFFFFFFFFFF
            return (x * 0x2545F4914F6CDD1D) & 0xFFFFFFFFFFFFFFFF, x

        # Initialize Layer 1 weights
        for i in range(TNN_L1_WEIGHTS):
            packed = 0
            for j in range(32):
                r, rng = xorshift64(rng)
                if (r & 0x3) == 0:
                    ternary = 0x0  # zero
                elif r & 0x1:
                    ternary = 0x1  # +1
                else:
                    ternary = 0x3  # -1
                packed |= ternary << (j * 2)
            self._w1[i] = packed

        # Initialize Layer 1 biases
        for i in range(TNN_HIDDEN_DIM):
            r, rng = xorshift64(rng)
            self._b1[i] = ((r & 0x1F) - 16) & 0xFFFF

        # Initialize Layer 2 weights
        for i in range(TNN_L2_WEIGHTS):
            packed = 0
            for j in range(32):
                r, rng = xorshift64(rng)
                if (r & 0x3) == 0:
                    ternary = 0x0
                elif r & 0x1:
                    ternary = 0x1
                else:
                    ternary = 0x3
                packed |= ternary << (j * 2)
            self._w2[i] = packed

        # Initialize Layer 2 biases
        for i in range(TNN_OUTPUT_DIM):
            r, rng = xorshift64(rng)
            self._b2[i] = ((r & 0x1F) - 16) & 0xFFFF

        # Generate model ID
        r, rng = xorshift64(rng)
        self._model_id = r

    def forward(self, input_vec: list) -> list:
        """Run forward pass: input[64] → output[16].

        Args:
            input_vec: List of 64 Q8.8 fixed-point values

        Returns:
            List of 16 Q8.8 output values
        """
        if len(input_vec) != TNN_INPUT_DIM:
            raise ValueError(f"Input must have {TNN_INPUT_DIM} elements")

        # Layer 1: 64 → 32 (ternary GEMV + bias + ReLU)
        hidden = []
        for i in range(TNN_HIDDEN_DIM):
            acc = 0
            # 64 inputs, 2 uint64 per row (32 weights each)
            for p in range(2):
                packed = self._w1[i * 2 + p]
                for k in range(32):
                    j = p * 32 + k
                    if j >= TNN_INPUT_DIM:
                        break
                    w = (packed >> (k * 2)) & 0x3
                    if w == 0x1:  # +1
                        acc += input_vec[j]
                    elif w == 0x3:  # -1
                        acc -= input_vec[j]
                    # 0x0 = skip

            # Add bias and ReLU
            acc += self._to_signed16(self._b1[i])
            acc = self._saturate(acc)
            hidden.append(max(0, acc))  # ReLU

        # Layer 2: 32 → 16 (ternary GEMV + bias)
        output = []
        for i in range(TNN_OUTPUT_DIM):
            acc = 0
            packed = self._w2[i]  # 1 uint64 per row (32 weights)
            for k in range(TNN_HIDDEN_DIM):
                w = (packed >> (k * 2)) & 0x3
                if w == 0x1:
                    acc += hidden[k]
                elif w == 0x3:
                    acc -= hidden[k]

            # Add bias (no activation)
            acc += self._to_signed16(self._b2[i])
            output.append(self._saturate(acc))

        return output

    def _to_signed16(self, val: int) -> int:
        """Convert unsigned 16-bit to signed."""
        if val >= 0x8000:
            return val - 0x10000
        return val

    def _saturate(self, val: int) -> int:
        """Saturate to Q8.8 range (-32768 to 32767)."""
        if val > 32767:
            return 32767
        if val < -32768:
            return -32768
        return val

    def sign(self, data: bytes) -> TNNSignature:
        """Generate TNN signature for data.

        Signature = TNN_forward(hash(data) || model_id)

        Args:
            data: Data to sign

        Returns:
            32-byte TNN signature
        """
        input_vec = self._build_input(data)
        output = self.forward(input_vec)

        # Pack output (16 × int16 = 32 bytes)
        sig_bytes = struct.pack("<16h", *output)
        return TNNSignature(sig_bytes)

    def verify(self, data: bytes, signature: TNNSignature) -> bool:
        """Verify TNN signature.

        Args:
            data: Original data
            signature: Signature to verify

        Returns:
            True if signature is valid
        """
        expected = self.sign(data)
        # Constant-time comparison
        result = 0
        for a, b in zip(signature.bytes, expected.bytes):
            result |= a ^ b
        return result == 0

    def challenge_response(self, challenge: bytes, peer_id: int, nonce: int) -> list:
        """Generate challenge-response for handshake.

        response = TNN_forward(challenge || peer_id || nonce || model_id)

        Args:
            challenge: Challenge bytes from peer
            peer_id: Peer's model ID
            nonce: Random nonce for replay protection

        Returns:
            16-element Q8.8 response vector
        """
        # Build input from challenge, peer_id, nonce
        h = self._fnv1a(challenge)
        h = self._hash_mix(h, peer_id)
        h = self._hash_mix(h, nonce)
        h = self._hash_mix(h, self._model_id)

        input_vec = []
        state = h
        for i in range(TNN_INPUT_DIM):
            state = self._hash_mix(state, i)
            val = (state & 0xFFFF)
            # Convert to signed and scale
            if val >= 0x8000:
                val = val - 0x10000
            input_vec.append(val >> 1)

        return self.forward(input_vec)

    def _build_input(self, data: bytes) -> list:
        """Build 64-element input vector from data hash."""
        h = self._fnv1a(data)
        h = self._hash_mix(h, self._model_id)

        input_vec = []
        state = h
        for i in range(TNN_INPUT_DIM):
            state = self._hash_mix(state, i)
            val = (state & 0xFFFF)
            if val >= 0x8000:
                val = val - 0x10000
            input_vec.append(val >> 1)

        return input_vec

    def _fnv1a(self, data: bytes) -> int:
        """FNV-1a hash."""
        h = 0xcbf29ce484222325
        for b in data:
            h ^= b
            h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
        return h

    def _hash_mix(self, h: int, value: int) -> int:
        """Mix additional value into hash."""
        h ^= value & 0xFFFFFFFFFFFFFFFF
        h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF
        h ^= (h >> 33)
        h = (h * 0xff51afd7ed558ccd) & 0xFFFFFFFFFFFFFFFF
        h ^= (h >> 33)
        return h

    @property
    def model_id(self) -> int:
        """Get unique model ID."""
        return self._model_id

    def save(self, path: str) -> None:
        """Save model to binary file."""
        data = self._serialize()
        with open(path, "wb") as f:
            f.write(data)

    def load(self, path: str) -> None:
        """Load model from binary file."""
        with open(path, "rb") as f:
            data = f.read()
        self._deserialize(data)

    def _serialize(self) -> bytes:
        """Serialize model to bytes."""
        parts = []

        # Layer 1 weights (64 × uint64)
        for w in self._w1:
            parts.append(struct.pack("<Q", w))

        # Layer 1 biases (32 × int16)
        for b in self._b1:
            parts.append(struct.pack("<h", self._to_signed16(b)))

        # Layer 2 weights (16 × uint64)
        for w in self._w2:
            parts.append(struct.pack("<Q", w))

        # Layer 2 biases (16 × int16)
        for b in self._b2:
            parts.append(struct.pack("<h", self._to_signed16(b)))

        # Metadata
        parts.append(struct.pack("<I", TNN_MAGIC))
        parts.append(struct.pack("<I", TNN_VERSION))
        parts.append(struct.pack("<Q", self._model_id))
        parts.append(struct.pack("<I", self._flags))
        parts.append(struct.pack("<I", 0))  # reserved

        return b"".join(parts)

    def _deserialize(self, data: bytes) -> None:
        """Deserialize model from bytes."""
        if len(data) < 760:  # Minimum model size
            raise ValueError("Data too small for TNN model")

        offset = 0

        # Layer 1 weights
        for i in range(TNN_L1_WEIGHTS):
            self._w1[i] = struct.unpack_from("<Q", data, offset)[0]
            offset += 8

        # Layer 1 biases
        for i in range(TNN_HIDDEN_DIM):
            self._b1[i] = struct.unpack_from("<h", data, offset)[0]
            offset += 2

        # Layer 2 weights
        for i in range(TNN_L2_WEIGHTS):
            self._w2[i] = struct.unpack_from("<Q", data, offset)[0]
            offset += 8

        # Layer 2 biases
        for i in range(TNN_OUTPUT_DIM):
            self._b2[i] = struct.unpack_from("<h", data, offset)[0]
            offset += 2

        # Metadata
        magic = struct.unpack_from("<I", data, offset)[0]
        offset += 4
        version = struct.unpack_from("<I", data, offset)[0]
        offset += 4

        if magic != TNN_MAGIC:
            raise ValueError(f"Invalid TNN magic: {magic:#x}")
        if version != TNN_VERSION:
            raise ValueError(f"Unsupported TNN version: {version}")

        self._model_id = struct.unpack_from("<Q", data, offset)[0]
        offset += 8
        self._flags = struct.unpack_from("<I", data, offset)[0]
