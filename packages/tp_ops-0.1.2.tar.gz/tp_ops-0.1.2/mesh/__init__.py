"""TernaryPhysics Agent Mesh - Cross-agent communication layer.

The mesh enables agents to discover each other and communicate
for cross-resource investigations.

Usage:
    from mesh import MeshNode, AgentInfo

    # Create local agent info
    agent = AgentInfo(
        id="k8s-prod-01",
        name="prod-cluster",
        agent_type="k8s-agent",
        host="localhost",
        port=7100,
        capabilities=["pods", "deployments", "logs"],
    )

    # Create mesh node (client + server)
    mesh = MeshNode(agent, port=7100)

    # Register query handler
    mesh.on_query(lambda req: handle_query(req))

    # Start mesh
    mesh.start()

    # Query other agents
    response = mesh.query("payments-db", "what's the connection pool status?")
"""

from mesh.client import MeshClient
from mesh.server import MeshServer, MeshNode
from mesh.discovery import Discovery
from mesh.integration import MeshAgentWrapper, MeshEnabledAgent
from mesh.types import (
    QueryRequest, QueryResponse, QueryType,
    AgentInfo, AgentStatus, MeshMessage,
)
from mesh.tnn import TNN, TNNSignature, TNNProtocol, TNNHandshake

__all__ = [
    "MeshClient",
    "MeshServer",
    "MeshNode",
    "MeshAgentWrapper",
    "MeshEnabledAgent",
    "Discovery",
    "QueryRequest",
    "QueryResponse",
    "QueryType",
    "AgentInfo",
    "AgentStatus",
    "MeshMessage",
    # TNN - mesh nervous system
    "TNN",
    "TNNSignature",
    "TNNProtocol",
    "TNNHandshake",
]
