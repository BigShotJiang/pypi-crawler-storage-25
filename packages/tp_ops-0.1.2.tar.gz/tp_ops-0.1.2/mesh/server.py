"""Mesh server - handle incoming queries from other agents."""

import logging
from typing import Callable, Optional, List, Dict, Any

from mesh.types import (
    AgentInfo, QueryRequest, QueryResponse, QueryType, MeshMessage
)
from mesh.transport.server import TransportServer

logger = logging.getLogger(__name__)


class MeshServer:
    """Server for handling incoming mesh queries.

    Receives queries from other agents and routes them to
    the appropriate handler (usually the LLM-powered agent).
    """

    def __init__(self, local_agent: AgentInfo, port: int = 7100):
        """Initialize mesh server.

        Args:
            local_agent: Info about the local agent
            port: Port to listen on
        """
        self.local_agent = local_agent
        self.port = port

        self._server = TransportServer(local_agent, port)
        self._query_handler: Optional[Callable[[QueryRequest], QueryResponse]] = None
        self._running = False

        # Wire up server handlers
        self._server.on_query(self._handle_query)

    def on_query(self, handler: Callable[[QueryRequest], QueryResponse]) -> None:
        """Register handler for incoming queries.

        The handler receives a QueryRequest and should return a QueryResponse.
        This is typically wired to the agent's LLM to answer the question.

        Example:
            def handle_query(request: QueryRequest) -> QueryResponse:
                answer = my_llm.answer(request.question, request.context)
                return QueryResponse(
                    source_agent=my_agent.name,
                    success=True,
                    answer=answer,
                )

            server.on_query(handle_query)
        """
        self._query_handler = handler

    def start(self) -> None:
        """Start the mesh server."""
        if self._running:
            return

        self._running = True
        self._server.start()
        logger.info(f"Mesh server listening on port {self.port}")

    def stop(self) -> None:
        """Stop the mesh server."""
        self._running = False
        self._server.stop()
        logger.info("Mesh server stopped")

    def _handle_query(self, request: QueryRequest) -> QueryResponse:
        """Handle an incoming query."""
        logger.info(f"Received query from {request.source_agent}: {request.question[:50]}...")

        if not self._query_handler:
            return QueryResponse(
                source_agent=self.local_agent.name,
                success=False,
                answer="",
                error="No query handler registered",
            )

        try:
            response = self._query_handler(request)
            response.source_agent = self.local_agent.name
            return response

        except Exception as e:
            logger.error(f"Query handler error: {e}")
            return QueryResponse(
                source_agent=self.local_agent.name,
                success=False,
                answer="",
                error=str(e),
            )


class MeshNode:
    """Combined mesh client and server for a single agent.

    Convenience class that wraps both MeshClient and MeshServer
    for agents that need to both query and respond.
    """

    def __init__(self, local_agent: AgentInfo, port: int = 7100):
        """Initialize mesh node.

        Args:
            local_agent: Info about the local agent
            port: Port for mesh communication
        """
        from mesh.client import MeshClient

        self.local_agent = local_agent
        self.port = port

        self.client = MeshClient(local_agent, port)
        self.server = MeshServer(local_agent, port)

        self._running = False

    def on_query(self, handler: Callable[[QueryRequest], QueryResponse]) -> None:
        """Register handler for incoming queries."""
        self.server.on_query(handler)

    def start(self) -> None:
        """Start both client and server."""
        if self._running:
            return

        self._running = True
        self.server.start()
        self.client.start()
        logger.info(f"Mesh node started: {self.local_agent.name}")

    def stop(self) -> None:
        """Stop both client and server."""
        self._running = False
        self.client.stop()
        self.server.stop()
        logger.info("Mesh node stopped")

    # Delegate common operations to client
    def query(self, target: str, question: str, **kwargs) -> Optional[QueryResponse]:
        """Query another agent."""
        return self.client.query(target, question, **kwargs)

    def get_peers(self) -> List[AgentInfo]:
        """Get all known peers."""
        return self.client.get_peers()

    def get_healthy_peers(self) -> List[AgentInfo]:
        """Get all healthy peers."""
        return self.client.get_healthy_peers()

    def add_static_peer(self, name: str, agent_type: str, host: str, port: int = 7100) -> None:
        """Add a static peer."""
        self.client.add_static_peer(name, agent_type, host, port)
