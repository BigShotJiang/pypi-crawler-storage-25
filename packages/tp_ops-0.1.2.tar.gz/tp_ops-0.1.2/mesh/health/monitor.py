"""Health monitor - tracks peer health via periodic pings.

Based on patterns from swarm/pkg/discovery/monitoring.go
"""

import threading
import logging
import time
from typing import Dict, List, Callable, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass

from mesh.types import AgentInfo, AgentStatus
from mesh.transport.client import TransportClient

logger = logging.getLogger(__name__)


@dataclass
class PeerHealth:
    """Health tracking for a single peer."""
    agent: AgentInfo
    last_check: Optional[datetime] = None
    last_success: Optional[datetime] = None
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    avg_rtt_ms: float = 0.0
    _rtt_samples: List[float] = None

    def __post_init__(self):
        if self._rtt_samples is None:
            self._rtt_samples = []

    def record_success(self, rtt_ms: float) -> None:
        """Record a successful health check."""
        self.last_check = datetime.utcnow()
        self.last_success = datetime.utcnow()
        self.consecutive_successes += 1
        self.consecutive_failures = 0

        # Update RTT average (keep last 10 samples)
        self._rtt_samples.append(rtt_ms)
        if len(self._rtt_samples) > 10:
            self._rtt_samples.pop(0)
        self.avg_rtt_ms = sum(self._rtt_samples) / len(self._rtt_samples)

        # Update agent status
        if self.consecutive_successes >= 2:
            self.agent.status = AgentStatus.ACTIVE
        self.agent.rtt_ms = self.avg_rtt_ms
        self.agent.last_seen = self.last_success
        self.agent.failure_count = 0

    def record_failure(self) -> None:
        """Record a failed health check."""
        self.last_check = datetime.utcnow()
        self.consecutive_failures += 1
        self.consecutive_successes = 0
        self.agent.failure_count = self.consecutive_failures

        # Update agent status based on failure count
        if self.consecutive_failures >= 3:
            self.agent.status = AgentStatus.UNHEALTHY
        elif self.consecutive_failures >= 1:
            self.agent.status = AgentStatus.DEGRADED


class HealthMonitor:
    """Monitor health of mesh peers via periodic pings.

    Features:
    - Periodic health checks (configurable interval)
    - Automatic status transitions (active → degraded → unhealthy)
    - Recovery detection (unhealthy → active after consecutive successes)
    - RTT tracking for latency monitoring
    - Callbacks for status changes
    """

    def __init__(
        self,
        local_agent_id: str,
        check_interval_sec: float = 30.0,
        unhealthy_threshold: int = 3,
        recovery_threshold: int = 2,
    ):
        """Initialize health monitor.

        Args:
            local_agent_id: ID of the local agent (for ping identification)
            check_interval_sec: Seconds between health checks
            unhealthy_threshold: Consecutive failures before marking unhealthy
            recovery_threshold: Consecutive successes before marking active
        """
        self.local_agent_id = local_agent_id
        self.check_interval = check_interval_sec
        self.unhealthy_threshold = unhealthy_threshold
        self.recovery_threshold = recovery_threshold

        self._client = TransportClient(timeout_sec=5.0)
        self._peers: Dict[str, PeerHealth] = {}
        self._lock = threading.RLock()

        self._on_status_change: List[Callable[[AgentInfo, AgentStatus, AgentStatus], None]] = []

        self._running = False
        self._thread: Optional[threading.Thread] = None

    def add_peer(self, agent: AgentInfo) -> None:
        """Add a peer to monitor."""
        with self._lock:
            if agent.id not in self._peers:
                self._peers[agent.id] = PeerHealth(agent=agent)
                logger.debug(f"Health monitor tracking: {agent.name}")

    def remove_peer(self, agent_id: str) -> None:
        """Remove a peer from monitoring."""
        with self._lock:
            self._peers.pop(agent_id, None)

    def on_status_change(
        self,
        callback: Callable[[AgentInfo, AgentStatus, AgentStatus], None]
    ) -> None:
        """Register callback for peer status changes.

        Callback receives (agent, old_status, new_status)
        """
        self._on_status_change.append(callback)

    def get_health(self, agent_id: str) -> Optional[PeerHealth]:
        """Get health info for a peer."""
        with self._lock:
            return self._peers.get(agent_id)

    def get_healthy_peers(self) -> List[AgentInfo]:
        """Get all healthy peers."""
        with self._lock:
            return [
                ph.agent for ph in self._peers.values()
                if ph.agent.is_healthy()
            ]

    def start(self) -> None:
        """Start the health monitor."""
        if self._running:
            return

        self._running = True
        self._thread = threading.Thread(
            target=self._monitor_loop,
            daemon=True,
            name="health-monitor"
        )
        self._thread.start()
        logger.info("Health monitor started")

    def stop(self) -> None:
        """Stop the health monitor."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Health monitor stopped")

    def check_now(self, agent_id: str) -> bool:
        """Immediately check health of a specific peer.

        Returns:
            True if healthy, False otherwise
        """
        with self._lock:
            peer_health = self._peers.get(agent_id)
            if not peer_health:
                return False

        return self._check_peer(peer_health)

    def _monitor_loop(self) -> None:
        """Background monitoring loop."""
        while self._running:
            try:
                self._check_all_peers()
            except Exception as e:
                logger.error(f"Health monitor error: {e}")

            # Sleep in increments for responsive shutdown
            sleep_until = time.time() + self.check_interval
            while time.time() < sleep_until and self._running:
                time.sleep(0.5)

    def _check_all_peers(self) -> None:
        """Check health of all peers."""
        with self._lock:
            peers = list(self._peers.values())

        for peer_health in peers:
            if not self._running:
                break
            self._check_peer(peer_health)

    def _check_peer(self, peer_health: PeerHealth) -> bool:
        """Check health of a single peer.

        Returns:
            True if healthy, False otherwise
        """
        agent = peer_health.agent
        old_status = agent.status

        start_time = time.time()

        try:
            result = self._client.health_check(
                agent.address,
                self.local_agent_id
            )

            if result:
                rtt_ms = (time.time() - start_time) * 1000
                peer_health.record_success(rtt_ms)
                logger.debug(f"Health check OK: {agent.name} ({rtt_ms:.1f}ms)")
            else:
                peer_health.record_failure()
                logger.debug(f"Health check failed: {agent.name} (no response)")

        except Exception as e:
            peer_health.record_failure()
            logger.debug(f"Health check error: {agent.name} - {e}")

        # Notify if status changed
        new_status = agent.status
        if old_status != new_status:
            self._notify_status_change(agent, old_status, new_status)

        return agent.is_healthy()

    def _notify_status_change(
        self,
        agent: AgentInfo,
        old_status: AgentStatus,
        new_status: AgentStatus
    ) -> None:
        """Notify callbacks of status change."""
        logger.info(f"Peer status change: {agent.name} {old_status.value} → {new_status.value}")

        for callback in self._on_status_change:
            try:
                callback(agent, old_status, new_status)
            except Exception as e:
                logger.error(f"Status change callback error: {e}")
