"""Message queue with reliable delivery and retry logic.

Based on patterns from swarm/pkg/discovery/queue.go
"""

import queue
import threading
import logging
import time
import uuid
from typing import Callable, Optional, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from mesh.types import MeshMessage, QueryRequest, QueryResponse

logger = logging.getLogger(__name__)


class DeliveryStatus(Enum):
    """Message delivery status."""
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    RETRYING = "retrying"


@dataclass
class QueuedMessage:
    """A message in the delivery queue."""
    msg_id: str
    target: str  # Target agent address (host:port)
    message: MeshMessage
    status: DeliveryStatus = DeliveryStatus.PENDING
    retries: int = 0
    max_retries: int = 3
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_attempt: Optional[datetime] = None
    error: Optional[str] = None
    callback: Optional[Callable[[bool, Optional[str]], None]] = None


@dataclass
class QueueStats:
    """Statistics for the message queue."""
    total_sent: int = 0
    total_delivered: int = 0
    total_failed: int = 0
    total_retries: int = 0
    avg_latency_ms: float = 0.0
    _latency_sum: float = 0.0
    _latency_count: int = 0

    def record_delivery(self, latency_ms: float) -> None:
        """Record a successful delivery."""
        self.total_delivered += 1
        self._latency_sum += latency_ms
        self._latency_count += 1
        self.avg_latency_ms = self._latency_sum / self._latency_count

    def record_failure(self) -> None:
        """Record a failed delivery."""
        self.total_failed += 1

    def record_retry(self) -> None:
        """Record a retry attempt."""
        self.total_retries += 1


class MessageQueue:
    """Reliable message delivery queue with exponential backoff.

    Features:
    - Async message queueing
    - Configurable retry with exponential backoff
    - Per-message callbacks for delivery confirmation
    - Statistics tracking
    - Worker pool for parallel delivery
    """

    def __init__(
        self,
        send_fn: Callable[[str, MeshMessage], bool],
        num_workers: int = 3,
        max_retries: int = 3,
        base_retry_interval_sec: float = 2.0,
        max_retry_interval_sec: float = 30.0,
        queue_size: int = 1000,
    ):
        """Initialize message queue.

        Args:
            send_fn: Function to actually send a message. Takes (address, message)
                     and returns True if delivered, False otherwise.
            num_workers: Number of worker threads for parallel delivery.
            max_retries: Maximum retry attempts per message.
            base_retry_interval_sec: Initial retry delay.
            max_retry_interval_sec: Maximum retry delay (cap for exponential backoff).
            queue_size: Maximum queue size.
        """
        self._send_fn = send_fn
        self._queue: queue.Queue[QueuedMessage] = queue.Queue(maxsize=queue_size)
        self._retry_queue: queue.Queue[QueuedMessage] = queue.Queue()
        self._pending: Dict[str, QueuedMessage] = {}
        self._lock = threading.Lock()

        self.num_workers = num_workers
        self.max_retries = max_retries
        self.base_retry_interval = base_retry_interval_sec
        self.max_retry_interval = max_retry_interval_sec

        self.stats = QueueStats()
        self._running = False
        self._workers: list[threading.Thread] = []
        self._retry_thread: Optional[threading.Thread] = None

    def start(self) -> None:
        """Start the queue workers."""
        if self._running:
            return

        self._running = True

        # Start worker threads
        for i in range(self.num_workers):
            t = threading.Thread(
                target=self._worker,
                args=(i,),
                daemon=True,
                name=f"msg-queue-worker-{i}"
            )
            t.start()
            self._workers.append(t)

        # Start retry thread
        self._retry_thread = threading.Thread(
            target=self._retry_worker,
            daemon=True,
            name="msg-queue-retry"
        )
        self._retry_thread.start()

        logger.info(f"Message queue started with {self.num_workers} workers")

    def stop(self) -> None:
        """Stop the queue workers."""
        self._running = False

        # Add poison pills to wake up workers
        for _ in range(self.num_workers):
            try:
                self._queue.put_nowait(None)
            except queue.Full:
                pass

        # Wait for workers
        for t in self._workers:
            t.join(timeout=2)

        if self._retry_thread:
            self._retry_thread.join(timeout=2)

        logger.info("Message queue stopped")

    def enqueue(
        self,
        target: str,
        message: MeshMessage,
        callback: Optional[Callable[[bool, Optional[str]], None]] = None,
    ) -> str:
        """Add a message to the delivery queue.

        Args:
            target: Target address (host:port)
            message: Message to send
            callback: Optional callback(success, error) when delivery completes

        Returns:
            Message ID for tracking
        """
        msg_id = message.msg_id or str(uuid.uuid4())[:8]
        message.msg_id = msg_id

        queued = QueuedMessage(
            msg_id=msg_id,
            target=target,
            message=message,
            max_retries=self.max_retries,
            callback=callback,
        )

        with self._lock:
            self._pending[msg_id] = queued

        self._queue.put(queued)
        self.stats.total_sent += 1

        logger.debug(f"Enqueued message {msg_id} to {target}")
        return msg_id

    def get_pending_count(self) -> int:
        """Get number of pending messages."""
        with self._lock:
            return len(self._pending)

    def _worker(self, worker_id: int) -> None:
        """Worker thread that processes messages."""
        while self._running:
            try:
                msg = self._queue.get(timeout=1.0)

                if msg is None:  # Poison pill
                    break

                self._deliver(msg)

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")

    def _deliver(self, msg: QueuedMessage) -> None:
        """Attempt to deliver a message."""
        msg.last_attempt = datetime.utcnow()
        start_time = time.time()

        try:
            success = self._send_fn(msg.target, msg.message)
            latency_ms = (time.time() - start_time) * 1000

            if success:
                msg.status = DeliveryStatus.DELIVERED
                self.stats.record_delivery(latency_ms)
                logger.debug(f"Delivered {msg.msg_id} to {msg.target} ({latency_ms:.1f}ms)")

                # Invoke callback
                if msg.callback:
                    try:
                        msg.callback(True, None)
                    except Exception as e:
                        logger.warning(f"Callback error for {msg.msg_id}: {e}")

                # Remove from pending
                with self._lock:
                    self._pending.pop(msg.msg_id, None)

            else:
                self._handle_failure(msg, "Send returned False")

        except Exception as e:
            self._handle_failure(msg, str(e))

    def _handle_failure(self, msg: QueuedMessage, error: str) -> None:
        """Handle a delivery failure."""
        msg.error = error
        msg.retries += 1

        if msg.retries <= msg.max_retries:
            msg.status = DeliveryStatus.RETRYING
            self.stats.record_retry()
            self._retry_queue.put(msg)
            logger.warning(f"Message {msg.msg_id} failed, will retry ({msg.retries}/{msg.max_retries}): {error}")
        else:
            msg.status = DeliveryStatus.FAILED
            self.stats.record_failure()
            logger.error(f"Message {msg.msg_id} permanently failed after {msg.retries} retries: {error}")

            # Invoke callback with failure
            if msg.callback:
                try:
                    msg.callback(False, error)
                except Exception as e:
                    logger.warning(f"Callback error for {msg.msg_id}: {e}")

            # Remove from pending
            with self._lock:
                self._pending.pop(msg.msg_id, None)

    def _retry_worker(self) -> None:
        """Worker thread that handles retries with backoff."""
        while self._running:
            try:
                msg = self._retry_queue.get(timeout=1.0)

                # Calculate backoff delay: base * 2^(retries-1), capped
                delay = min(
                    self.base_retry_interval * (2 ** (msg.retries - 1)),
                    self.max_retry_interval
                )

                logger.debug(f"Retry {msg.msg_id} in {delay:.1f}s")

                # Sleep in small increments to allow shutdown
                sleep_until = time.time() + delay
                while time.time() < sleep_until and self._running:
                    time.sleep(0.5)

                if self._running:
                    # Re-queue for delivery
                    self._queue.put(msg)

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Retry worker error: {e}")
