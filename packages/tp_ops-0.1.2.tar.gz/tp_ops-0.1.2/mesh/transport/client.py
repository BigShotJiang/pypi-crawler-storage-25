"""Transport client for sending messages to other agents."""

import json
import logging
import time
import urllib.request
import urllib.error
from typing import Optional, Dict, Any
from datetime import datetime

from mesh.types import (
    MeshMessage, QueryRequest, QueryResponse,
    AgentInfo, AgentStatus, HealthCheck
)

logger = logging.getLogger(__name__)

# Endpoints
QUERY_ENDPOINT = "/mesh/query"
HEALTH_ENDPOINT = "/mesh/health"
CAPABILITIES_ENDPOINT = "/mesh/capabilities"


class TransportClient:
    """HTTP/JSON client for mesh communication.

    Simple request/response over HTTP. Can be swapped for gRPC later.
    """

    def __init__(self, timeout_sec: float = 5.0):
        self.timeout = timeout_sec

    def send_message(self, address: str, message: MeshMessage) -> bool:
        """Send a generic mesh message.

        Args:
            address: Target address (host:port)
            message: Message to send

        Returns:
            True if delivered successfully
        """
        url = f"http://{address}/mesh/message"

        payload = {
            "msg_type": message.msg_type,
            "sender": message.sender,
            "payload": message.payload,
            "timestamp": message.timestamp.isoformat(),
            "msg_id": message.msg_id,
            "reply_to": message.reply_to,
        }

        return self._post(url, payload) is not None

    def query(self, address: str, request: QueryRequest) -> Optional[QueryResponse]:
        """Send a query to another agent.

        Args:
            address: Target address (host:port)
            request: Query request

        Returns:
            QueryResponse if successful, None if failed
        """
        url = f"http://{address}{QUERY_ENDPOINT}"

        payload = {
            "source_agent": request.source_agent,
            "target_agent": request.target_agent,
            "query_type": request.query_type.value,
            "question": request.question,
            "context": request.context,
            "trace_id": request.trace_id,
        }

        start_time = time.time()
        timeout = request.timeout_ms / 1000.0

        result = self._post(url, payload, timeout=timeout)

        if result is None:
            return None

        latency_ms = (time.time() - start_time) * 1000

        return QueryResponse(
            source_agent=result.get("source_agent", ""),
            success=result.get("success", False),
            answer=result.get("answer", ""),
            data=result.get("data", {}),
            error=result.get("error"),
            latency_ms=latency_ms,
            trace_id=result.get("trace_id"),
        )

    def health_check(self, address: str, local_agent_id: str) -> Optional[HealthCheck]:
        """Ping another agent for health status.

        Args:
            address: Target address (host:port)
            local_agent_id: Our agent ID (for the ping)

        Returns:
            HealthCheck if successful, None if failed
        """
        url = f"http://{address}{HEALTH_ENDPOINT}"

        payload = {
            "agent_id": local_agent_id,
            "timestamp": datetime.utcnow().isoformat(),
        }

        start_time = time.time()
        result = self._post(url, payload, timeout=2.0)

        if result is None:
            return None

        return HealthCheck(
            agent_id=result.get("agent_id", ""),
            timestamp=datetime.utcnow(),
            status=AgentStatus(result.get("status", "unknown")),
            load=result.get("load", 0.0),
            version=result.get("version", "unknown"),
        )

    def get_capabilities(self, address: str) -> Optional[Dict[str, Any]]:
        """Get capabilities of another agent.

        Args:
            address: Target address (host:port)

        Returns:
            Capabilities dict if successful, None if failed
        """
        url = f"http://{address}{CAPABILITIES_ENDPOINT}"

        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("Content-Type", "application/json")

            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode())

        except Exception as e:
            logger.debug(f"Failed to get capabilities from {address}: {e}")
            return None

    def _post(self, url: str, payload: Dict[str, Any],
              timeout: Optional[float] = None) -> Optional[Dict[str, Any]]:
        """POST JSON to a URL.

        Args:
            url: Full URL
            payload: JSON payload
            timeout: Request timeout

        Returns:
            Response JSON if successful, None if failed
        """
        timeout = timeout or self.timeout

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(url, data=data, method="POST")
            req.add_header("Content-Type", "application/json")

            with urllib.request.urlopen(req, timeout=timeout) as response:
                return json.loads(response.read().decode())

        except urllib.error.URLError as e:
            logger.debug(f"Connection failed to {url}: {e}")
            return None
        except urllib.error.HTTPError as e:
            logger.debug(f"HTTP error from {url}: {e.code}")
            return None
        except Exception as e:
            logger.debug(f"Request failed to {url}: {e}")
            return None
