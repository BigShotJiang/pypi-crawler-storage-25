"""Transport server for receiving mesh messages."""

import json
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Callable, Optional, Dict, Any, List
from datetime import datetime
import psutil

from mesh.types import (
    MeshMessage, QueryRequest, QueryResponse, QueryType,
    AgentInfo, AgentStatus, HealthCheck
)

logger = logging.getLogger(__name__)


class MeshRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for mesh endpoints."""

    def log_message(self, format, *args):
        """Suppress default logging."""
        pass

    def do_GET(self):
        """Handle GET requests."""
        if self.path == "/mesh/capabilities":
            self._handle_capabilities()
        elif self.path == "/mesh/status":
            self._handle_status()
        else:
            self.send_error(404)

    def do_POST(self):
        """Handle POST requests."""
        if self.path == "/mesh/query":
            self._handle_query()
        elif self.path == "/mesh/health":
            self._handle_health()
        elif self.path == "/mesh/message":
            self._handle_message()
        else:
            self.send_error(404)

    def _read_json(self) -> Optional[Dict[str, Any]]:
        """Read JSON body from request."""
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length)
            return json.loads(body.decode("utf-8"))
        except Exception as e:
            logger.warning(f"Failed to read JSON body: {e}")
            return None

    def _send_json(self, data: Dict[str, Any], status: int = 200):
        """Send JSON response."""
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)

    def _handle_query(self):
        """Handle query requests from other agents."""
        data = self._read_json()
        if not data:
            self.send_error(400, "Invalid JSON")
            return

        # Parse request
        try:
            request = QueryRequest(
                source_agent=data.get("source_agent", ""),
                target_agent=data.get("target_agent", ""),
                query_type=QueryType(data.get("query_type", "investigate")),
                question=data.get("question", ""),
                context=data.get("context", {}),
                trace_id=data.get("trace_id"),
            )
        except Exception as e:
            self.send_error(400, f"Invalid request: {e}")
            return

        # Invoke handler
        handler = self.server.mesh_server.query_handler
        if handler:
            try:
                response = handler(request)
                self._send_json({
                    "source_agent": response.source_agent,
                    "success": response.success,
                    "answer": response.answer,
                    "data": response.data,
                    "error": response.error,
                    "trace_id": response.trace_id,
                })
            except Exception as e:
                logger.error(f"Query handler error: {e}")
                self._send_json({
                    "success": False,
                    "error": str(e),
                }, status=500)
        else:
            self._send_json({
                "success": False,
                "error": "No query handler registered",
            }, status=501)

    def _handle_health(self):
        """Handle health check pings."""
        data = self._read_json()

        server = self.server.mesh_server

        # Calculate load
        try:
            load = psutil.cpu_percent() / 100.0
        except Exception:
            load = 0.0

        self._send_json({
            "agent_id": server.local_agent.id,
            "status": server.local_agent.status.value,
            "load": load,
            "version": "1.0.0",
            "timestamp": datetime.utcnow().isoformat(),
        })

    def _handle_capabilities(self):
        """Return agent capabilities."""
        server = self.server.mesh_server
        self._send_json({
            "agent_id": server.local_agent.id,
            "name": server.local_agent.name,
            "type": server.local_agent.agent_type,
            "capabilities": server.local_agent.capabilities,
            "version": "1.0.0",
        })

    def _handle_status(self):
        """Return agent status."""
        server = self.server.mesh_server
        self._send_json({
            "agent_id": server.local_agent.id,
            "status": server.local_agent.status.value,
            "uptime_sec": (datetime.utcnow() - server.start_time).total_seconds(),
        })

    def _handle_message(self):
        """Handle generic mesh messages."""
        data = self._read_json()
        if not data:
            self.send_error(400, "Invalid JSON")
            return

        message = MeshMessage(
            msg_type=data.get("msg_type", ""),
            sender=data.get("sender", ""),
            payload=data.get("payload", {}),
            msg_id=data.get("msg_id"),
            reply_to=data.get("reply_to"),
        )

        handler = self.server.mesh_server.message_handler
        if handler:
            try:
                handler(message)
                self._send_json({"received": True})
            except Exception as e:
                logger.error(f"Message handler error: {e}")
                self._send_json({"received": False, "error": str(e)}, status=500)
        else:
            self._send_json({"received": True})


class TransportServer:
    """HTTP server for receiving mesh communication."""

    def __init__(self, local_agent: AgentInfo, port: int = 7100):
        self.local_agent = local_agent
        self.port = port
        self.start_time = datetime.utcnow()

        self.query_handler: Optional[Callable[[QueryRequest], QueryResponse]] = None
        self.message_handler: Optional[Callable[[MeshMessage], None]] = None

        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def on_query(self, handler: Callable[[QueryRequest], QueryResponse]) -> None:
        """Register handler for incoming queries."""
        self.query_handler = handler

    def on_message(self, handler: Callable[[MeshMessage], None]) -> None:
        """Register handler for incoming messages."""
        self.message_handler = handler

    def start(self) -> None:
        """Start the server."""
        if self._running:
            return

        self._server = HTTPServer(("0.0.0.0", self.port), MeshRequestHandler)
        self._server.mesh_server = self  # Attach reference for handlers
        self._server.timeout = 1.0  # Allow periodic checking of _running flag

        self._running = True
        self._thread = threading.Thread(
            target=self._serve,
            daemon=True,
            name="mesh-server"
        )
        self._thread.start()

        logger.info(f"Mesh server started on port {self.port}")

    def stop(self) -> None:
        """Stop the server."""
        self._running = False
        if self._server:
            # shutdown() must be called from a different thread than serve_forever()
            self._server.shutdown()
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("Mesh server stopped")

    def _serve(self) -> None:
        """Server loop using serve_forever for clean shutdown."""
        self._server.serve_forever()
