"""Core types for mesh communication."""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime
from enum import Enum


class AgentStatus(Enum):
    """Agent health status."""
    ACTIVE = "active"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class QueryType(Enum):
    """Types of queries agents can handle."""
    STATUS = "status"           # Basic health check
    METRICS = "metrics"         # Resource metrics
    INVESTIGATE = "investigate" # Root cause investigation
    CAPABILITIES = "capabilities"  # What can this agent do?


@dataclass
class AgentInfo:
    """Information about an agent in the mesh."""
    id: str                          # Unique agent ID
    name: str                        # Human-readable name (e.g., "prod-cluster")
    agent_type: str                  # k8s-agent, postgres-agent, etc.
    host: str                        # Hostname or IP
    port: int                        # gRPC port
    capabilities: List[str] = field(default_factory=list)  # What it can answer
    status: AgentStatus = AgentStatus.UNKNOWN
    last_seen: Optional[datetime] = None
    rtt_ms: float = 0.0              # Round-trip time in ms
    failure_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def address(self) -> str:
        """Return host:port address."""
        return f"{self.host}:{self.port}"

    def is_healthy(self) -> bool:
        """Check if agent is healthy enough to query."""
        return self.status in (AgentStatus.ACTIVE, AgentStatus.DEGRADED)


@dataclass
class QueryRequest:
    """Request to query another agent."""
    source_agent: str          # Who's asking
    target_agent: str          # Who to ask (agent name or ID)
    query_type: QueryType      # Type of query
    question: str              # The actual question
    context: Dict[str, Any] = field(default_factory=dict)  # Additional context
    timeout_ms: int = 5000     # Timeout in milliseconds
    trace_id: Optional[str] = None  # For distributed tracing


@dataclass
class QueryResponse:
    """Response from a queried agent."""
    source_agent: str          # Who answered
    success: bool              # Did the query succeed?
    answer: str                # The response content
    data: Dict[str, Any] = field(default_factory=dict)  # Structured data
    error: Optional[str] = None  # Error message if failed
    latency_ms: float = 0.0    # How long it took
    trace_id: Optional[str] = None


@dataclass
class HealthCheck:
    """Health check ping/pong."""
    agent_id: str
    timestamp: datetime
    status: AgentStatus
    load: float = 0.0          # Current load 0-1
    version: str = "1.0.0"


@dataclass
class MeshMessage:
    """Generic mesh message wrapper."""
    msg_type: str              # query, response, health, broadcast
    sender: str                # Sender agent ID
    payload: Dict[str, Any]    # Message content
    timestamp: datetime = field(default_factory=datetime.utcnow)
    msg_id: Optional[str] = None
    reply_to: Optional[str] = None  # For request/response correlation
