"""Integration with TernaryPhysics conversational agents.

This module adds mesh capabilities to any ConversationalAgent,
allowing it to query other agents in the mesh and share knowledge.
"""

import logging
import uuid
from typing import TYPE_CHECKING, Optional, List, Dict, Any

from mesh.server import MeshNode
from mesh.types import AgentInfo, AgentStatus, QueryRequest, QueryResponse, QueryType
from mesh.learning import (
    OutcomeTracker,
    LearningFeedback,
    KnowledgeBroadcaster,
    KnowledgeAbsorber,
    KnowledgeSyncManager,
)
from mesh.tnn.protocol import (
    TNN_MSG_TYPE_KNOWLEDGE,
    TNN_MSG_TYPE_SYNC_REQ,
    TNN_MSG_TYPE_SYNC_RESP,
)

if TYPE_CHECKING:
    from agents.base.conversational import ConversationalAgent

logger = logging.getLogger(__name__)


class MeshEnabledAgent:
    """Mixin that adds mesh capabilities to a ConversationalAgent.

    Usage:
        class MyAgent(ConversationalAgent, MeshEnabledAgent):
            def __init__(self, ...):
                ConversationalAgent.__init__(self, ...)
                MeshEnabledAgent.__init__(self, ...)

    Or wrap an existing agent:
        agent = KubernetesChatAgent(...)
        mesh_agent = MeshAgentWrapper(agent, port=7100)
    """

    def init_mesh(
        self,
        agent_type: str,
        port: int = 7100,
        capabilities: Optional[List[str]] = None,
    ) -> None:
        """Initialize mesh capabilities.

        Args:
            agent_type: Type of this agent (k8s-agent, postgres-agent, etc.)
            port: Port for mesh communication
            capabilities: List of capabilities this agent offers
        """
        # Create agent info
        self._mesh_info = AgentInfo(
            id=f"{self.name}-{uuid.uuid4().hex[:8]}",
            name=self.name,
            agent_type=agent_type,
            host="0.0.0.0",
            port=port,
            capabilities=capabilities or [],
            status=AgentStatus.ACTIVE,
        )

        # Create mesh node
        self._mesh = MeshNode(self._mesh_info, port)

        # Register query handler
        self._mesh.on_query(self._handle_mesh_query)

        # Register the query_agent tool
        self._register_mesh_tool()

    def start_mesh(self) -> None:
        """Start mesh communication."""
        if hasattr(self, '_mesh'):
            self._mesh.start()
            logger.info(f"Mesh started for {self.name}")

    def stop_mesh(self) -> None:
        """Stop mesh communication."""
        if hasattr(self, '_mesh'):
            self._mesh.stop()

    def add_mesh_peer(self, name: str, agent_type: str, host: str, port: int = 7100) -> None:
        """Add a static peer to the mesh."""
        if hasattr(self, '_mesh'):
            self._mesh.add_static_peer(name, agent_type, host, port)

    def get_mesh_peers(self) -> List[AgentInfo]:
        """Get all peers in the mesh."""
        if hasattr(self, '_mesh'):
            return self._mesh.get_peers()
        return []

    def _register_mesh_tool(self) -> None:
        """Register the query_agent tool."""
        if hasattr(self, 'register_tool'):
            self.register_tool(
                name="query_agent",
                description=(
                    "Query another agent in the mesh. "
                    "Args: <agent_name> <question>. "
                    "Example: query_agent payments-db what is the connection pool status?"
                ),
                execute=self._execute_query_agent,
            )

    def _execute_query_agent(self, args: str) -> str:
        """Execute a query to another agent.

        Args format: <agent_name> <question>
        """
        if not hasattr(self, '_mesh'):
            return "Error: Mesh not initialized"

        # Parse args
        parts = args.strip().split(maxsplit=1)
        if len(parts) < 2:
            return "Error: Usage: query_agent <agent_name> <question>"

        target_name = parts[0]
        question = parts[1]

        # Query the target agent
        logger.info(f"Querying mesh peer: {target_name}")
        response = self._mesh.query(target_name, question)

        if response is None:
            return f"Error: Could not reach agent '{target_name}'"

        if not response.success:
            return f"Error from {target_name}: {response.error}"

        # Include metadata
        result = f"Response from {response.source_agent} ({response.latency_ms:.0f}ms):\n{response.answer}"

        # Track bytes processed
        if hasattr(self, 'bytes_processed'):
            self.bytes_processed += len(response.answer.encode('utf-8'))

        return result

    def _handle_mesh_query(self, request: QueryRequest) -> QueryResponse:
        """Handle an incoming query from another agent.

        This uses the same chat() method as user queries,
        so the LLM answers as if a human asked.
        """
        logger.info(f"Mesh query from {request.source_agent}: {request.question}")

        try:
            # Use the agent's chat method to answer
            if hasattr(self, 'chat'):
                answer = self.chat(request.question)
            else:
                answer = "This agent doesn't support chat queries"

            return QueryResponse(
                source_agent=self.name if hasattr(self, 'name') else "unknown",
                success=True,
                answer=answer,
                data={"context": request.context},
                trace_id=request.trace_id,
            )

        except Exception as e:
            logger.error(f"Error handling mesh query: {e}")
            return QueryResponse(
                source_agent=self.name if hasattr(self, 'name') else "unknown",
                success=False,
                answer="",
                error=str(e),
                trace_id=request.trace_id,
            )


class MeshAgentWrapper:
    """Wrapper that adds mesh capabilities to any existing agent.

    Usage:
        agent = KubernetesChatAgent(name="prod-cluster", ...)
        mesh_agent = MeshAgentWrapper(agent, agent_type="k8s-agent")
        mesh_agent.start()

        # Use as normal
        response = mesh_agent.chat("why are pods crashing?")

        # Agent can now query other agents via mesh
        # LLM will use: TOOL: query_agent payments-db connection pool status?
    """

    def __init__(
        self,
        agent: "ConversationalAgent",
        agent_type: str,
        port: int = 7100,
        capabilities: Optional[List[str]] = None,
    ):
        self._agent = agent
        self._agent_type = agent_type
        self._port = port
        self._capabilities = capabilities or []

        # Create agent info
        self._mesh_info = AgentInfo(
            id=f"{agent.name}-{uuid.uuid4().hex[:8]}",
            name=agent.name,
            agent_type=agent_type,
            host="0.0.0.0",
            port=port,
            capabilities=self._capabilities,
            status=AgentStatus.ACTIVE,
        )

        # Create mesh node
        self._mesh = MeshNode(self._mesh_info, port)
        self._mesh.on_query(self._handle_query)

        # Initialize learning components
        model_id = self._mesh_info.id.encode('utf-8')[:8].ljust(8, b'\x00')
        self._outcome_tracker = OutcomeTracker()
        self._learning_feedback = LearningFeedback()
        self._broadcaster = KnowledgeBroadcaster(model_id)
        self._absorber = KnowledgeAbsorber(
            model_id,
            learning_feedback=self._learning_feedback,
        )
        self._sync_manager = KnowledgeSyncManager(model_id)

        # Register query_agent tool on the wrapped agent
        agent.register_tool(
            name="query_agent",
            description=(
                "Query another agent in the mesh for cross-resource investigation. "
                "Args: <agent_name> <question>. "
                "Example: query_agent payments-db what is the connection pool status? "
                "Available agents can be listed with: TOOL: list_agents"
            ),
            execute=self._execute_query_agent,
        )

        agent.register_tool(
            name="list_agents",
            description="List all agents in the mesh",
            execute=self._execute_list_agents,
        )

    @property
    def name(self) -> str:
        return self._agent.name

    def start(self) -> None:
        """Start mesh communication."""
        self._mesh.start()

        # Wire up learning callbacks to mesh
        self._broadcaster.set_send_callback(self._broadcast_knowledge)
        self._absorber.set_forward_callback(self._broadcast_knowledge)

        # Request sync on startup
        self._sync_manager.request_sync()

        logger.info(f"Mesh-enabled agent started: {self.name}")

    def _broadcast_knowledge(self, data: bytes) -> None:
        """Broadcast knowledge packet to all peers."""
        # Use mesh to broadcast to all peers
        for peer in self._mesh.get_peers():
            try:
                self._mesh.send_raw(peer.id, data)
            except Exception as e:
                logger.debug(f"Failed to broadcast to {peer.name}: {e}")

    def stop(self) -> None:
        """Stop mesh communication."""
        self._mesh.stop()

    def add_peer(self, name: str, agent_type: str, host: str, port: int = 7100) -> None:
        """Add a static peer."""
        self._mesh.add_static_peer(name, agent_type, host, port)

    def get_peers(self) -> List[AgentInfo]:
        """Get all peers."""
        return self._mesh.get_peers()

    def chat(self, user_message: str) -> str:
        """Chat with the wrapped agent."""
        return self._agent.chat(user_message)

    def _execute_query_agent(self, args: str) -> str:
        """Query another agent."""
        parts = args.strip().split(maxsplit=1)
        if len(parts) < 2:
            return "Error: Usage: query_agent <agent_name> <question>"

        target = parts[0]
        question = parts[1]

        response = self._mesh.query(target, question)

        if response is None:
            return f"Error: Could not reach agent '{target}'"

        if not response.success:
            return f"Error from {target}: {response.error}"

        # Track bytes
        self._agent.bytes_processed += len(response.answer.encode('utf-8'))

        return f"[{response.source_agent}] {response.answer}"

    def _execute_list_agents(self, args: str) -> str:
        """List all agents in the mesh."""
        peers = self._mesh.get_peers()

        if not peers:
            return "No other agents found in mesh"

        lines = ["Agents in mesh:"]
        for peer in peers:
            status = "healthy" if peer.is_healthy() else peer.status.value
            lines.append(f"  - {peer.name} ({peer.agent_type}) [{status}]")

        return "\n".join(lines)

    def _handle_query(self, request: QueryRequest) -> QueryResponse:
        """Handle incoming query from another agent."""
        logger.info(f"Query from {request.source_agent}: {request.question}")

        try:
            answer = self._agent.chat(request.question)
            return QueryResponse(
                source_agent=self.name,
                success=True,
                answer=answer,
                trace_id=request.trace_id,
            )
        except Exception as e:
            return QueryResponse(
                source_agent=self.name,
                success=False,
                answer="",
                error=str(e),
                trace_id=request.trace_id,
            )

    # Learning system accessors
    @property
    def outcome_tracker(self) -> OutcomeTracker:
        """Get the outcome tracker for this agent."""
        return self._outcome_tracker

    @property
    def learning_feedback(self) -> LearningFeedback:
        """Get the learning feedback system."""
        return self._learning_feedback

    @property
    def broadcaster(self) -> KnowledgeBroadcaster:
        """Get the knowledge broadcaster."""
        return self._broadcaster

    @property
    def absorber(self) -> KnowledgeAbsorber:
        """Get the knowledge absorber."""
        return self._absorber

    def get_learning_stats(self) -> Dict[str, Any]:
        """Get statistics about learning system."""
        return {
            "pending_outcomes": len(self._outcome_tracker.get_pending_outcomes()),
            "applied_deltas": len(self._learning_feedback.get_applied_deltas()),
            "absorbed_patterns": len(self._absorber.get_absorbed_patterns()),
            "broadcaster": self._broadcaster.get_stats(),
            "sync": self._sync_manager.get_stats(),
        }

    # Delegate other attributes to wrapped agent
    def __getattr__(self, name: str) -> Any:
        return getattr(self._agent, name)
