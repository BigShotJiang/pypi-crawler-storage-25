"""mDNS-based discovery for local network agents."""

import socket
import threading
import logging
import json
from typing import Dict, List, Optional, Callable
from datetime import datetime

from mesh.types import AgentInfo, AgentStatus

logger = logging.getLogger(__name__)

# Service type for TernaryPhysics agents
SERVICE_TYPE = "_tp-ops-agent._tcp.local."


class MDNSDiscovery:
    """Discover agents on local network via mDNS/Bonjour.

    Uses zeroconf library for cross-platform mDNS.
    Falls back to manual broadcast if zeroconf unavailable.
    """

    def __init__(self, local_agent: AgentInfo):
        self.local_agent = local_agent
        self._zeroconf = None
        self._browser = None
        self._service_info = None
        self._discovered: Dict[str, AgentInfo] = {}
        self._lock = threading.Lock()
        self._running = False

    def start(self) -> None:
        """Start mDNS discovery and registration."""
        try:
            from zeroconf import Zeroconf, ServiceBrowser, ServiceInfo
            self._start_zeroconf()
        except ImportError:
            logger.warning("zeroconf not installed, mDNS discovery disabled")
            logger.info("Install with: pip install zeroconf")

    def stop(self) -> None:
        """Stop mDNS discovery."""
        self._running = False
        if self._zeroconf:
            try:
                if self._service_info:
                    self._zeroconf.unregister_service(self._service_info)
                self._zeroconf.close()
            except Exception as e:
                logger.warning(f"Error stopping mDNS: {e}")

    def discover(self) -> List[AgentInfo]:
        """Return currently discovered agents."""
        with self._lock:
            return list(self._discovered.values())

    def _start_zeroconf(self) -> None:
        """Initialize zeroconf for mDNS."""
        from zeroconf import Zeroconf, ServiceBrowser, ServiceInfo, ServiceListener

        self._zeroconf = Zeroconf()
        self._running = True

        # Register our service
        self._register_service()

        # Browse for other agents
        class AgentListener(ServiceListener):
            def __init__(self, mdns_discovery):
                self.mdns = mdns_discovery

            def add_service(self, zc, type_, name):
                self.mdns._on_service_found(zc, type_, name)

            def remove_service(self, zc, type_, name):
                self.mdns._on_service_removed(name)

            def update_service(self, zc, type_, name):
                self.mdns._on_service_found(zc, type_, name)

        self._browser = ServiceBrowser(
            self._zeroconf,
            SERVICE_TYPE,
            AgentListener(self)
        )
        logger.info(f"mDNS discovery started, browsing for {SERVICE_TYPE}")

    def _register_service(self) -> None:
        """Register this agent as an mDNS service."""
        from zeroconf import ServiceInfo

        # Build service properties
        properties = {
            b"id": self.local_agent.id.encode(),
            b"type": self.local_agent.agent_type.encode(),
            b"caps": ",".join(self.local_agent.capabilities).encode(),
            b"version": b"1.0.0",
        }

        hostname = socket.gethostname()
        service_name = f"{self.local_agent.name}.{SERVICE_TYPE}"

        self._service_info = ServiceInfo(
            SERVICE_TYPE,
            service_name,
            addresses=[socket.inet_aton(self._get_local_ip())],
            port=self.local_agent.port,
            properties=properties,
            server=f"{hostname}.local.",
        )

        self._zeroconf.register_service(self._service_info)
        logger.info(f"Registered mDNS service: {service_name}")

    def _on_service_found(self, zc, type_: str, name: str) -> None:
        """Handle discovered service."""
        from zeroconf import ServiceInfo

        info = zc.get_service_info(type_, name)
        if not info:
            return

        # Parse service info
        try:
            agent_id = info.properties.get(b"id", b"").decode()
            agent_type = info.properties.get(b"type", b"").decode()
            caps_str = info.properties.get(b"caps", b"").decode()
            capabilities = caps_str.split(",") if caps_str else []

            # Skip self
            if agent_id == self.local_agent.id:
                return

            # Get address
            addresses = info.parsed_addresses()
            if not addresses:
                return

            host = addresses[0]
            port = info.port

            # Extract name from service name
            agent_name = name.replace(f".{SERVICE_TYPE}", "")

            agent = AgentInfo(
                id=agent_id,
                name=agent_name,
                agent_type=agent_type,
                host=host,
                port=port,
                capabilities=capabilities,
                status=AgentStatus.UNKNOWN,
                last_seen=datetime.utcnow(),
            )

            with self._lock:
                self._discovered[agent_id] = agent

            logger.info(f"mDNS: discovered {agent_name} at {host}:{port}")

        except Exception as e:
            logger.warning(f"Error parsing mDNS service: {e}")

    def _on_service_removed(self, name: str) -> None:
        """Handle removed service."""
        agent_name = name.replace(f".{SERVICE_TYPE}", "")
        with self._lock:
            # Find and remove by name
            to_remove = None
            for agent_id, agent in self._discovered.items():
                if agent.name == agent_name:
                    to_remove = agent_id
                    break
            if to_remove:
                del self._discovered[to_remove]
                logger.info(f"mDNS: agent removed {agent_name}")

    def _get_local_ip(self) -> str:
        """Get local IP address."""
        try:
            # Connect to external address to determine local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"
