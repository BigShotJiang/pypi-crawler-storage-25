"""Static discovery - manually configured peers."""

import os
import json
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

from mesh.types import AgentInfo, AgentStatus

logger = logging.getLogger(__name__)

# Default config locations
CONFIG_PATHS = [
    Path.home() / ".config" / "tp-ops" / "mesh-peers.json",
    Path("/etc/tp-ops/mesh-peers.json"),
]


class StaticDiscovery:
    """Discover agents from static configuration.

    Reads peer configuration from:
    1. ~/.config/tp-ops/mesh-peers.json
    2. /etc/tp-ops/mesh-peers.json
    3. TPHY_MESH_PEERS environment variable (JSON)
    4. Programmatically added peers
    """

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path
        self._manual_peers: List[AgentInfo] = []

    def add_peer(self, agent: AgentInfo) -> None:
        """Manually add a peer."""
        self._manual_peers.append(agent)

    def add_peer_address(self, name: str, agent_type: str,
                         host: str, port: int = 7100) -> None:
        """Add a peer by address.

        New peers are assumed ACTIVE (trust then verify).
        The health monitor will demote them if unreachable.
        """
        agent = AgentInfo(
            id=f"{name}-{host}:{port}",
            name=name,
            agent_type=agent_type,
            host=host,
            port=port,
            status=AgentStatus.ACTIVE,  # Trust, then verify
        )
        self._manual_peers.append(agent)

    def discover(self) -> List[AgentInfo]:
        """Return all statically configured peers."""
        agents: List[AgentInfo] = []

        # Load from config file
        agents.extend(self._load_from_file())

        # Load from environment
        agents.extend(self._load_from_env())

        # Add manual peers
        agents.extend(self._manual_peers)

        return agents

    def _load_from_file(self) -> List[AgentInfo]:
        """Load peers from config file."""
        config_path = self.config_path

        if not config_path:
            # Try default paths
            for path in CONFIG_PATHS:
                if path.exists():
                    config_path = path
                    break

        if not config_path or not config_path.exists():
            return []

        try:
            with open(config_path) as f:
                data = json.load(f)
            return self._parse_peers(data.get("peers", []))
        except Exception as e:
            logger.warning(f"Error loading mesh config from {config_path}: {e}")
            return []

    def _load_from_env(self) -> List[AgentInfo]:
        """Load peers from environment variable."""
        env_value = os.environ.get("TPHY_MESH_PEERS")
        if not env_value:
            return []

        try:
            data = json.loads(env_value)
            if isinstance(data, list):
                return self._parse_peers(data)
            elif isinstance(data, dict):
                return self._parse_peers(data.get("peers", []))
        except Exception as e:
            logger.warning(f"Error parsing TPHY_MESH_PEERS: {e}")

        return []

    def _parse_peers(self, peers_data: List[Dict[str, Any]]) -> List[AgentInfo]:
        """Parse peer configuration into AgentInfo objects."""
        agents = []

        for peer in peers_data:
            try:
                # Support shorthand format: "name:host:port:type"
                if isinstance(peer, str):
                    peer = self._parse_shorthand(peer)

                agent = AgentInfo(
                    id=peer.get("id", f"{peer['name']}-{peer['host']}:{peer.get('port', 7100)}"),
                    name=peer["name"],
                    agent_type=peer["type"],
                    host=peer["host"],
                    port=peer.get("port", 7100),
                    capabilities=peer.get("capabilities", []),
                    status=AgentStatus.UNKNOWN,
                    metadata=peer.get("metadata", {}),
                )
                agents.append(agent)
            except KeyError as e:
                logger.warning(f"Invalid peer config, missing {e}: {peer}")
            except Exception as e:
                logger.warning(f"Error parsing peer config: {e}")

        return agents

    def _parse_shorthand(self, shorthand: str) -> Dict[str, Any]:
        """Parse shorthand peer format: name:host:port:type"""
        parts = shorthand.split(":")
        if len(parts) < 3:
            raise ValueError(f"Invalid shorthand format: {shorthand}")

        result = {
            "name": parts[0],
            "host": parts[1],
            "port": int(parts[2]) if len(parts) > 2 else 7100,
            "type": parts[3] if len(parts) > 3 else "unknown",
        }
        return result


def save_peers_config(peers: List[AgentInfo], path: Optional[Path] = None) -> None:
    """Save peers to config file."""
    if path is None:
        path = CONFIG_PATHS[0]

    path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "peers": [
            {
                "id": p.id,
                "name": p.name,
                "type": p.agent_type,
                "host": p.host,
                "port": p.port,
                "capabilities": p.capabilities,
            }
            for p in peers
        ]
    }

    with open(path, "w") as f:
        json.dump(data, f, indent=2)

    logger.info(f"Saved {len(peers)} peers to {path}")
