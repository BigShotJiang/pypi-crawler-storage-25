"""Main discovery coordinator - combines multiple discovery methods."""

import threading
import logging
from typing import Dict, List, Optional, Callable
from datetime import datetime, timedelta

from mesh.types import AgentInfo, AgentStatus

logger = logging.getLogger(__name__)


class Discovery:
    """Coordinates agent discovery from multiple sources.

    Combines mDNS (local network), static config, and Kubernetes DNS
    to find all agents in the mesh.
    """

    def __init__(self, local_agent: AgentInfo):
        self.local_agent = local_agent
        self.peers: Dict[str, AgentInfo] = {}
        self._lock = threading.RLock()
        self._discovery_sources: List[Callable[[], List[AgentInfo]]] = []
        self._on_peer_discovered: List[Callable[[AgentInfo], None]] = []
        self._on_peer_lost: List[Callable[[AgentInfo], None]] = []
        self._running = False
        self._refresh_thread: Optional[threading.Thread] = None

        # Config
        self.refresh_interval_sec = 30
        self.peer_timeout_sec = 90  # Mark peer unhealthy after this

    def add_discovery_source(self, source: Callable[[], List[AgentInfo]]) -> None:
        """Add a discovery source (mDNS, static, k8s DNS, etc.)."""
        self._discovery_sources.append(source)

    def on_peer_discovered(self, callback: Callable[[AgentInfo], None]) -> None:
        """Register callback for when a new peer is discovered."""
        self._on_peer_discovered.append(callback)

    def on_peer_lost(self, callback: Callable[[AgentInfo], None]) -> None:
        """Register callback for when a peer is lost."""
        self._on_peer_lost.append(callback)

    def start(self) -> None:
        """Start discovery background refresh."""
        if self._running:
            return

        self._running = True
        self._refresh_thread = threading.Thread(
            target=self._refresh_loop,
            daemon=True,
            name="discovery-refresh"
        )
        self._refresh_thread.start()
        logger.info(f"Discovery started for {self.local_agent.name}")

    def stop(self) -> None:
        """Stop discovery."""
        self._running = False
        if self._refresh_thread:
            self._refresh_thread.join(timeout=5)
        logger.info("Discovery stopped")

    def refresh(self) -> None:
        """Manually trigger discovery refresh."""
        discovered: Dict[str, AgentInfo] = {}

        for source in self._discovery_sources:
            try:
                agents = source()
                for agent in agents:
                    # Skip self
                    if agent.id == self.local_agent.id:
                        continue
                    # Merge - prefer newer info
                    if agent.id not in discovered:
                        discovered[agent.id] = agent
            except Exception as e:
                logger.warning(f"Discovery source failed: {e}")

        self._update_peers(discovered)

    def get_peers(self) -> List[AgentInfo]:
        """Get all known peers."""
        with self._lock:
            return list(self.peers.values())

    def get_peer(self, agent_id: str) -> Optional[AgentInfo]:
        """Get a specific peer by ID."""
        with self._lock:
            return self.peers.get(agent_id)

    def get_peer_by_name(self, name: str) -> Optional[AgentInfo]:
        """Get a peer by name."""
        with self._lock:
            for peer in self.peers.values():
                if peer.name == name:
                    return peer
        return None

    def get_peers_by_type(self, agent_type: str) -> List[AgentInfo]:
        """Get all peers of a specific type."""
        with self._lock:
            return [p for p in self.peers.values() if p.agent_type == agent_type]

    def get_healthy_peers(self) -> List[AgentInfo]:
        """Get all healthy peers."""
        with self._lock:
            return [p for p in self.peers.values() if p.is_healthy()]

    def update_peer_status(self, agent_id: str, status: AgentStatus,
                           rtt_ms: float = 0.0) -> None:
        """Update a peer's health status."""
        with self._lock:
            if agent_id in self.peers:
                self.peers[agent_id].status = status
                self.peers[agent_id].last_seen = datetime.utcnow()
                self.peers[agent_id].rtt_ms = rtt_ms
                if status == AgentStatus.ACTIVE:
                    self.peers[agent_id].failure_count = 0

    def record_failure(self, agent_id: str) -> None:
        """Record a communication failure with a peer."""
        with self._lock:
            if agent_id in self.peers:
                self.peers[agent_id].failure_count += 1
                if self.peers[agent_id].failure_count >= 3:
                    self.peers[agent_id].status = AgentStatus.UNHEALTHY

    def _refresh_loop(self) -> None:
        """Background refresh loop."""
        while self._running:
            try:
                self.refresh()
                self._check_stale_peers()
            except Exception as e:
                logger.error(f"Discovery refresh error: {e}")

            # Sleep in small increments to allow quick shutdown
            for _ in range(self.refresh_interval_sec * 2):
                if not self._running:
                    break
                threading.Event().wait(0.5)

    def _update_peers(self, discovered: Dict[str, AgentInfo]) -> None:
        """Update peer list with newly discovered agents."""
        with self._lock:
            # Check for new peers
            for agent_id, agent in discovered.items():
                if agent_id not in self.peers:
                    agent.last_seen = datetime.utcnow()
                    self.peers[agent_id] = agent
                    logger.info(f"Discovered new peer: {agent.name} ({agent.agent_type})")
                    for callback in self._on_peer_discovered:
                        try:
                            callback(agent)
                        except Exception as e:
                            logger.error(f"Peer discovered callback error: {e}")
                else:
                    # Update existing peer info
                    self.peers[agent_id].host = agent.host
                    self.peers[agent_id].port = agent.port
                    self.peers[agent_id].capabilities = agent.capabilities
                    self.peers[agent_id].last_seen = datetime.utcnow()

    def _check_stale_peers(self) -> None:
        """Check for peers that haven't been seen recently."""
        threshold = datetime.utcnow() - timedelta(seconds=self.peer_timeout_sec)

        with self._lock:
            stale = []
            for agent_id, agent in self.peers.items():
                if agent.last_seen and agent.last_seen < threshold:
                    if agent.status != AgentStatus.UNHEALTHY:
                        agent.status = AgentStatus.UNHEALTHY
                        stale.append(agent)

            for agent in stale:
                logger.warning(f"Peer went stale: {agent.name}")
                for callback in self._on_peer_lost:
                    try:
                        callback(agent)
                    except Exception as e:
                        logger.error(f"Peer lost callback error: {e}")
