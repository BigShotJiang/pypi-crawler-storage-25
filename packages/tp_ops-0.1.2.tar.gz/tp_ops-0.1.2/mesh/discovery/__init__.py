"""Agent discovery - find other agents in the mesh."""

from mesh.discovery.discovery import Discovery
from mesh.discovery.mdns import MDNSDiscovery
from mesh.discovery.static import StaticDiscovery

__all__ = ["Discovery", "MDNSDiscovery", "StaticDiscovery"]
