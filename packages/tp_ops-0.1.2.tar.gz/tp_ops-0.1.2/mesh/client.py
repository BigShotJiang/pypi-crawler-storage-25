"""Mesh client - query other agents in the mesh."""

import logging
import uuid
from typing import List, Optional, Dict, Any, Callable
from datetime import datetime

from mesh.types import (
    AgentInfo, AgentStatus, QueryRequest, QueryResponse, QueryType, MeshMessage
)
from mesh.discovery import Discovery, MDNSDiscovery, StaticDiscovery
from mesh.transport.client import TransportClient
from mesh.transport.queue import MessageQueue
from mesh.health import HealthMonitor

logger = logging.getLogger(__name__)


class MeshClient:
    """Client for querying other agents in the mesh.

    Provides:
    - Discovery of other agents (mDNS + static config)
    - Health monitoring of peers
    - Reliable message delivery with retries
    - Query routing to appropriate agents
    """

    def __init__(self, local_agent: AgentInfo, port: int = 7100):
        """Initialize mesh client.

        Args:
            local_agent: Info about the local agent
            port: Port for mesh communication
        """
        self.local_agent = local_agent
        self.port = port

        # Transport
        self._transport = TransportClient()

        # Discovery
        self._discovery = Discovery(local_agent)
        self._mdns = MDNSDiscovery(local_agent)
        self._static = StaticDiscovery()

        # Wire up discovery sources
        self._discovery.add_discovery_source(self._mdns.discover)
        self._discovery.add_discovery_source(self._static.discover)

        # Health monitoring
        self._health = HealthMonitor(local_agent.id)

        # Message queue
        self._queue = MessageQueue(
            send_fn=self._send_message,
            num_workers=2,
        )

        # Wire up discovery → health monitor
        self._discovery.on_peer_discovered(self._on_peer_discovered)
        self._discovery.on_peer_lost(self._on_peer_lost)

        self._running = False

    def start(self) -> None:
        """Start the mesh client."""
        if self._running:
            return

        self._running = True

        # Start components
        self._mdns.start()
        self._discovery.start()
        self._health.start()
        self._queue.start()

        logger.info(f"Mesh client started: {self.local_agent.name}")

    def stop(self) -> None:
        """Stop the mesh client."""
        self._running = False

        self._queue.stop()
        self._health.stop()
        self._discovery.stop()
        self._mdns.stop()

        logger.info("Mesh client stopped")

    def add_static_peer(self, name: str, agent_type: str, host: str, port: int = 7100) -> None:
        """Add a static peer configuration."""
        self._static.add_peer_address(name, agent_type, host, port)
        # Trigger discovery refresh
        self._discovery.refresh()

    def get_peers(self) -> List[AgentInfo]:
        """Get all known peers."""
        return self._discovery.get_peers()

    def get_healthy_peers(self) -> List[AgentInfo]:
        """Get all healthy peers."""
        return self._discovery.get_healthy_peers()

    def get_peer(self, name: str) -> Optional[AgentInfo]:
        """Get a peer by name."""
        return self._discovery.get_peer_by_name(name)

    def get_peers_by_type(self, agent_type: str) -> List[AgentInfo]:
        """Get all peers of a specific type."""
        return self._discovery.get_peers_by_type(agent_type)

    def query(
        self,
        target: str,
        question: str,
        query_type: QueryType = QueryType.INVESTIGATE,
        context: Optional[Dict[str, Any]] = None,
        timeout_ms: int = 10000,
    ) -> Optional[QueryResponse]:
        """Query another agent.

        Args:
            target: Target agent name
            question: The question to ask
            query_type: Type of query
            context: Additional context
            timeout_ms: Query timeout

        Returns:
            QueryResponse if successful, None if failed
        """
        # Find the target
        peer = self._discovery.get_peer_by_name(target)
        if not peer:
            logger.warning(f"Unknown target agent: {target}")
            return QueryResponse(
                source_agent=target,
                success=False,
                answer="",
                error=f"Agent '{target}' not found in mesh",
            )

        if not peer.is_healthy():
            logger.warning(f"Target agent unhealthy: {target}")
            return QueryResponse(
                source_agent=target,
                success=False,
                answer="",
                error=f"Agent '{target}' is unhealthy",
            )

        # Build request
        request = QueryRequest(
            source_agent=self.local_agent.name,
            target_agent=target,
            query_type=query_type,
            question=question,
            context=context or {},
            timeout_ms=timeout_ms,
            trace_id=str(uuid.uuid4())[:8],
        )

        # Send query
        logger.info(f"Querying {target}: {question[:50]}...")
        response = self._transport.query(peer.address, request)

        if response:
            logger.info(f"Got response from {target} ({response.latency_ms:.1f}ms)")
        else:
            logger.warning(f"No response from {target}")
            self._discovery.record_failure(peer.id)

        return response

    def query_by_type(
        self,
        agent_type: str,
        question: str,
        query_type: QueryType = QueryType.INVESTIGATE,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[QueryResponse]:
        """Query all agents of a specific type.

        Args:
            agent_type: Type of agents to query (e.g., "postgres-agent")
            question: The question to ask
            query_type: Type of query
            context: Additional context

        Returns:
            List of responses from all matching agents
        """
        peers = self.get_peers_by_type(agent_type)
        healthy = [p for p in peers if p.is_healthy()]

        if not healthy:
            logger.warning(f"No healthy {agent_type} agents found")
            return []

        responses = []
        for peer in healthy:
            response = self.query(
                peer.name,
                question,
                query_type,
                context,
            )
            if response:
                responses.append(response)

        return responses

    def broadcast(
        self,
        question: str,
        query_type: QueryType = QueryType.INVESTIGATE,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[QueryResponse]:
        """Query all healthy agents in the mesh.

        Args:
            question: The question to ask
            query_type: Type of query
            context: Additional context

        Returns:
            List of responses from all agents
        """
        healthy = self.get_healthy_peers()

        if not healthy:
            logger.warning("No healthy peers in mesh")
            return []

        responses = []
        for peer in healthy:
            response = self.query(
                peer.name,
                question,
                query_type,
                context,
            )
            if response:
                responses.append(response)

        return responses

    def _send_message(self, address: str, message: MeshMessage) -> bool:
        """Send function for message queue."""
        return self._transport.send_message(address, message)

    def _on_peer_discovered(self, agent: AgentInfo) -> None:
        """Handle new peer discovery."""
        self._health.add_peer(agent)
        logger.info(f"Mesh: discovered {agent.name} ({agent.agent_type}) at {agent.address}")

    def _on_peer_lost(self, agent: AgentInfo) -> None:
        """Handle lost peer."""
        self._health.remove_peer(agent.id)
        logger.info(f"Mesh: lost peer {agent.name}")
