"""Streaming TTS session for text-in/audio-out streaming."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator, Callable, Dict, List, Optional, Set, Union

from kugelaudio.exceptions import (
    AuthenticationError,
    InsufficientCreditsError,
    KugelAudioError,
)
from kugelaudio.models import AudioChunk, StreamConfig, WordTimestamp

logger = logging.getLogger(__name__)

# Default timeout for waiting on audio generation responses
_DEFAULT_RECV_TIMEOUT_S = 30.0
# Short poll interval for checking if more messages are available
_POLL_TIMEOUT_S = 0.05


def _raise_for_error(data: Dict[str, Any]) -> None:
    """Raise a specific exception based on the error message or error_code."""
    error_code = data.get("error_code", "")
    error_msg = data.get("error", "Unknown error")
    lower = f"{error_code} {error_msg}".lower()

    if "insufficient_credits" in lower or "no credits" in lower:
        raise InsufficientCreditsError(error_msg)
    if error_code == "UNAUTHORIZED" or "auth" in lower:
        raise AuthenticationError(error_msg)
    raise KugelAudioError(error_msg)


class StreamingSession:
    """WebSocket session for streaming text input and audio output.

    This allows streaming text (e.g., from an LLM) and receiving audio
    as it's generated. Text is buffered and processed when sentence
    boundaries are detected or when explicitly flushed.

    Example:
        async with client.tts.streaming_session(voice_id=123) as session:
            async for token in llm_stream:
                async for chunk in session.send(token):
                    play_audio(chunk)

            # Flush remaining text
            async for chunk in session.flush():
                play_audio(chunk)
    """

    def __init__(
        self,
        api_key: str,
        tts_url: str,
        config: Optional[StreamConfig] = None,
        on_word_timestamps: Optional[Callable[[List[WordTimestamp]], None]] = None,
    ):
        self._api_key = api_key
        self._tts_url = tts_url
        self._config = config or StreamConfig()
        self._ws: Optional[Any] = None
        self._session_id: Optional[str] = None
        self._is_started = False
        self._config_sent = False
        self._pending_messages: List[Dict[str, Any]] = []
        self._on_word_timestamps = on_word_timestamps
        self._last_word_timestamps: List[WordTimestamp] = []

    @property
    def last_word_timestamps(self) -> List[WordTimestamp]:
        """Return the most recently received word timestamps.

        Updated each time the server sends a ``word_timestamps`` message.
        """
        return self._last_word_timestamps

    async def __aenter__(self) -> StreamingSession:
        await self.connect()
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    async def connect(self) -> None:
        """Connect to the streaming WebSocket endpoint."""
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "websockets required. Install with: pip install websockets"
            )

        ws_url = self._tts_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{ws_url}/ws/tts/stream?api_key={self._api_key}"

        try:
            self._ws = await websockets.connect(ws_url, compression=None)
            self._is_started = True
            logger.debug("Streaming session connected")
        except websockets.exceptions.InvalidStatusCode as e:
            if e.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif e.status_code == 403:
                raise InsufficientCreditsError("Insufficient credits")
            raise KugelAudioError(f"Connection failed: {e}")

    async def _ensure_config_sent(self) -> None:
        """Send session config on first text message.

        The server's /ws/tts/stream endpoint does NOT send a session_started
        response. Instead, it reads config from the first messages in the
        main loop. We send config fields alongside the first text message.
        """
        if self._config_sent:
            return
        self._config_sent = True

    async def send(
        self,
        text: str,
        flush: bool = False,
    ) -> AsyncIterator[AudioChunk]:
        """Send text and yield any generated audio chunks.

        Args:
            text: Text to add to buffer
            flush: Force flush the buffer

        Yields:
            AudioChunk as audio is generated
        """
        if not self._is_started:
            await self.connect()

        # Build message
        msg: Dict[str, Any] = {"text": text, "flush": flush}

        if not self._config_sent:
            from kugelaudio.client import _warn_if_no_language

            _warn_if_no_language(self._config.language, self._config.normalize)
            config = self._config.to_dict()
            msg.update(config)
            self._config_sent = True

        await self._ws.send(json.dumps(msg))

        # Collect any generated audio
        async for chunk in self._receive_until_idle():
            yield chunk

    async def flush(self) -> AsyncIterator[AudioChunk]:
        """Flush the text buffer and yield remaining audio.

        Yields:
            AudioChunk as remaining audio is generated
        """
        if not self._is_started or not self._ws:
            return

        await self._ws.send(json.dumps({"flush": True}))

        async for chunk in self._receive_until_idle():
            yield chunk

    async def _receive_until_idle(self) -> AsyncIterator[AudioChunk]:
        """Receive messages until we get a chunk_complete or session_closed.

        The server sends:
          - {"generation_started": true, ...} when synthesis begins
          - {"audio": "<base64>", ...}       for each audio chunk
          - {"word_timestamps": [...], ...}  per-chunk word timestamps
          - {"chunk_complete": true, ...}    when a text chunk is done
          - {"session_closed": true, ...}    on session end
          - {"error": "..."}                 on error

        Timeout strategy:
          - _DEFAULT_RECV_TIMEOUT_S (30s) while waiting for the first
            message or for the next message once generation has started.
          - _POLL_TIMEOUT_S (50ms) only when no generation_started has
            been received yet AND no audio has arrived — i.e. the text
            we sent did not trigger synthesis (e.g. partial word with no
            sentence boundary).

        Once generation_started or audio is received, we always wait for
        the authoritative chunk_complete / session_closed signal from the
        server.  This prevents truncated audio when inter-frame latency
        exceeds the short poll timeout.
        """
        generation_active = False

        while True:
            if generation_active:
                timeout = _DEFAULT_RECV_TIMEOUT_S
            else:
                timeout = _POLL_TIMEOUT_S

            try:
                msg = await asyncio.wait_for(self._ws.recv(), timeout=timeout)
                data = json.loads(msg)

                if data.get("error"):
                    _raise_for_error(data)

                if data.get("generation_started"):
                    generation_active = True
                    continue

                if data.get("audio"):
                    generation_active = True
                    yield AudioChunk.from_dict(data)

                if "word_timestamps" in data:
                    stamps = [
                        WordTimestamp.from_dict(w) for w in data["word_timestamps"]
                    ]
                    self._last_word_timestamps = stamps
                    if self._on_word_timestamps:
                        self._on_word_timestamps(stamps)
                    continue

                if data.get("chunk_complete") or data.get("session_closed"):
                    break

            except asyncio.TimeoutError:
                if generation_active:
                    logger.warning(
                        "Timed out waiting for chunk_complete after %.0fs "
                        "(generation was active — possible server issue)",
                        _DEFAULT_RECV_TIMEOUT_S,
                    )
                break
            except Exception as e:
                if "ConnectionClosed" in str(type(e)):
                    close_code = getattr(e, "code", None)
                    if close_code == 4003:
                        raise InsufficientCreditsError("Insufficient credits") from e
                    if close_code == 4001:
                        raise AuthenticationError("WebSocket authentication failed") from e
                    break
                raise

    async def end_session(self) -> Dict[str, Any]:
        """End the current session but keep the WebSocket connection open.

        This allows starting a new session on the same connection, avoiding
        the overhead of a new WebSocket handshake (~200-300ms).

        After calling this, use :meth:`update_config` to change voice/model
        settings, then call :meth:`send` to start the next session.

        Returns:
            Session statistics from the ended session
        """
        stats: Dict[str, Any] = {}
        if not self._ws:
            return stats

        try:
            await self._ws.send(json.dumps({"close": True}))

            while True:
                msg = await asyncio.wait_for(
                    self._ws.recv(), timeout=_DEFAULT_RECV_TIMEOUT_S
                )
                data = json.loads(msg)
                if data.get("error"):
                    _raise_for_error(data)
                if data.get("session_closed"):
                    stats = data
                    break
        except Exception as e:
            # If the underlying websocket died (proxy/LB/server restart),
            # tear down state so the next send() reconnects cleanly rather
            # than calling .send() on a dead socket.
            if "ConnectionClosed" in str(type(e)) or isinstance(e, (OSError, asyncio.TimeoutError)):
                self._ws = None
                self._is_started = False

        # Reset session state so next send() starts a fresh session
        self._config_sent = False
        self._last_word_timestamps = []
        return stats

    def update_config(self, config: Optional[StreamConfig] = None, **kwargs) -> None:
        """Update session configuration for the next session.

        Call this after :meth:`end_session` and before the next :meth:`send`
        to change voice, model, language, or other settings.

        Args:
            config: Full replacement config. If None, update individual fields.
            **kwargs: Individual fields to update (voice_id, model_id, language, etc.)
        """
        if config is not None:
            self._config = config
        else:
            for key, value in kwargs.items():
                if hasattr(self._config, key):
                    setattr(self._config, key, value)
        self._config_sent = False

    async def close(self) -> Dict[str, Any]:
        """Close the session and the WebSocket connection.

        Sends a close command, drains messages until the server responds
        with ``session_closed``, then closes the WebSocket.

        For session reuse without closing the connection, use
        :meth:`end_session` instead.

        Returns:
            Session statistics
        """
        stats = await self.end_session()

        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None
            self._is_started = False

        return stats


class StreamingSessionSync:
    """Synchronous wrapper for StreamingSession."""

    def __init__(self, session: StreamingSession):
        self._session = session
        self._loop = asyncio.new_event_loop()

    def __enter__(self) -> StreamingSessionSync:
        self._loop.run_until_complete(self._session.connect())
        return self

    def __exit__(self, *args) -> None:
        self._loop.run_until_complete(self._session.close())
        self._loop.close()

    def send(self, text: str, flush: bool = False) -> List[AudioChunk]:
        """Send text and return generated audio chunks."""

        async def collect() -> List[AudioChunk]:
            chunks: List[AudioChunk] = []
            async for chunk in self._session.send(text, flush=flush):
                chunks.append(chunk)
            return chunks

        return self._loop.run_until_complete(collect())

    def flush(self) -> List[AudioChunk]:
        """Flush buffer and return remaining audio chunks."""

        async def collect() -> List[AudioChunk]:
            chunks: List[AudioChunk] = []
            async for chunk in self._session.flush():
                chunks.append(chunk)
            return chunks

        return self._loop.run_until_complete(collect())

    @property
    def last_word_timestamps(self) -> List[WordTimestamp]:
        """Return the most recently received word timestamps."""
        return self._session.last_word_timestamps

    def close(self) -> Dict[str, Any]:
        """Close the session."""
        return self._loop.run_until_complete(self._session.close())


class MultiContextSession:
    """WebSocket session for multi-context TTS streaming.

    Allows managing up to 5 independent audio generation contexts over
    a single WebSocket connection. Each context has its own text buffer,
    voice settings, and generation queue.

    Use cases:
    - Multi-speaker conversations with different voices
    - Pre-buffering audio while another stream plays
    - Interleaved audio generation for dynamic conversations

    Example:
        async with client.tts.multi_context_session() as session:
            # Create contexts with different voices
            await session.create_context("narrator", voice_id=123)
            await session.create_context("character", voice_id=456)

            # Send text to different speakers
            async for chunk in session.send("narrator", "The story begins."):
                play_audio("narrator", chunk)

            async for chunk in session.send("character", "Hello!"):
                play_audio("character", chunk)

            # Close specific context
            await session.close_context("narrator")
    """

    def __init__(
        self,
        api_key: str,
        tts_url: str,
        default_voice_id: Optional[int] = None,
        sample_rate: int = 24000,
        cfg_scale: float = 2.0,
        temperature: Optional[float] = None,
        max_new_tokens: int = 2048,
        normalize: bool = True,
        language: Optional[str] = None,
        inactivity_timeout: float = 20.0,
        word_timestamps: bool = False,
        on_word_timestamps: Optional[Callable[[str, List[WordTimestamp]], None]] = None,
    ):
        self._api_key = api_key
        self._tts_url = tts_url
        self._default_voice_id = default_voice_id
        self._sample_rate = sample_rate
        self._cfg_scale = cfg_scale
        self._temperature = temperature
        self._max_new_tokens = max_new_tokens
        self._normalize = normalize
        self._language = language
        self._inactivity_timeout = inactivity_timeout
        self._word_timestamps = word_timestamps
        self._ws: Optional[Any] = None
        self._session_id: Optional[str] = None
        self._is_started = False
        self._contexts: Set[str] = set()
        self._pending_messages: List[Dict[str, Any]] = []
        self._on_word_timestamps = on_word_timestamps
        self._last_word_timestamps: Dict[str, List[WordTimestamp]] = {}

    def get_word_timestamps(self, context_id: str) -> List[WordTimestamp]:
        """Return the most recently received word timestamps for *context_id*."""
        return self._last_word_timestamps.get(context_id, [])

    async def __aenter__(self) -> "MultiContextSession":
        await self.connect()
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    async def connect(self) -> None:
        """Connect to the multi-context WebSocket endpoint."""
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "websockets required. Install with: pip install websockets"
            )

        ws_url = self._tts_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_url = f"{ws_url}/ws/tts/multi?api_key={self._api_key}"

        try:
            self._ws = await websockets.connect(ws_url)
        except websockets.exceptions.InvalidStatusCode as e:
            if e.status_code == 401:
                raise AuthenticationError("Invalid API key")
            elif e.status_code == 403:
                raise InsufficientCreditsError("Insufficient credits")
            raise KugelAudioError(f"Connection failed: {e}")

    async def _start_session(
        self, context_id: str, voice_id: Optional[int] = None
    ) -> None:
        """Start the session with first context creation.

        The server's /ws/tts/multi endpoint does NOT send a ``session_started``
        message.  Instead, the first message that references a ``context_id``
        triggers an implicit ``create_context`` on the server side, which
        responds with ``{"context_created": true, "context_id": "..."}``.

        Per-context voice / generation settings must be nested inside a
        ``voice_settings`` dict (see ``create_context`` helper in the server).
        """
        if self._is_started:
            return

        if not self._ws:
            await self.connect()

        from kugelaudio.client import _warn_if_no_language

        _warn_if_no_language(self._language, self._normalize)

        effective_voice_id = voice_id or self._default_voice_id
        init_msg: Dict[str, Any] = {
            "text": " ",
            "context_id": context_id,
            "sample_rate": self._sample_rate,
            "normalize": self._normalize,
            "word_timestamps": self._word_timestamps,
        }
        if self._language is not None:
            init_msg["language"] = self._language
        if self._temperature is not None:
            init_msg["temperature"] = self._temperature
        if effective_voice_id is not None:
            init_msg["voice_settings"] = {
                "voice_id": effective_voice_id,
                "cfg_scale": self._cfg_scale,
                "max_new_tokens": self._max_new_tokens,
            }

        await self._ws.send(json.dumps(init_msg))

        # Wait for context_created confirmation (no session_started event)
        while True:
            msg = await asyncio.wait_for(
                self._ws.recv(), timeout=_DEFAULT_RECV_TIMEOUT_S
            )
            data = json.loads(msg)

            if data.get("error"):
                _raise_for_error(data)

            if data.get("context_created"):
                self._contexts.add(data["context_id"])
                self._is_started = True
                logger.debug(
                    "Multi-context session started, first context: %s",
                    data["context_id"],
                )
                break

    async def create_context(
        self,
        context_id: str,
        voice_id: Optional[int] = None,
    ) -> None:
        """Create a new context with optional voice override.

        Args:
            context_id: Unique identifier for this context
            voice_id: Optional voice ID (uses default if not specified)
        """
        if not self._is_started:
            await self._start_session(context_id, voice_id)
            return

        if context_id in self._contexts:
            return  # Already exists

        # Send context initialization — voice_id must be in voice_settings
        effective_voice_id = voice_id or self._default_voice_id
        msg: Dict[str, Any] = {"text": " ", "context_id": context_id}
        if effective_voice_id is not None:
            msg["voice_settings"] = {
                "voice_id": effective_voice_id,
                "cfg_scale": self._cfg_scale,
                "max_new_tokens": self._max_new_tokens,
            }

        await self._ws.send(json.dumps(msg))

        # Wait for confirmation
        while True:
            response = await self._ws.recv()
            data = json.loads(response)

            if data.get("error"):
                _raise_for_error(data)

            if data.get("context_created") and data.get("context_id") == context_id:
                self._contexts.add(context_id)
                break

    async def send(
        self,
        context_id: str,
        text: str,
        flush: bool = False,
    ) -> AsyncIterator[AudioChunk]:
        """Send text to a specific context and yield audio chunks.

        Args:
            context_id: Context to send text to
            text: Text to synthesize
            flush: Force flush the buffer

        Yields:
            AudioChunk as audio is generated
        """
        if not self._is_started:
            await self._start_session(context_id)

        if context_id not in self._contexts:
            await self.create_context(context_id)

        await self._ws.send(
            json.dumps(
                {
                    "text": text,
                    "context_id": context_id,
                    "flush": flush,
                }
            )
        )

        # Collect audio for this context. The server marks each text chunk's
        # audio delivery with `chunk_complete`; the sole terminal signal is
        # `context_closed`, which only arrives once `close_context` is called.
        async for chunk in self._receive_audio(context_id):
            yield chunk

    async def flush(self, context_id: str) -> AsyncIterator[AudioChunk]:
        """Flush a specific context's buffer.

        Args:
            context_id: Context to flush

        Yields:
            AudioChunk as remaining audio is generated
        """
        if not self._is_started or context_id not in self._contexts:
            return

        await self._ws.send(
            json.dumps(
                {
                    "flush": True,
                    "context_id": context_id,
                }
            )
        )

        # flush yields every audio chunk produced by the buffer drain, ending
        # once chunk_complete arrives (or we idle out). Use close_context for
        # terminal drains.
        async for chunk in self._receive_audio(context_id):
            yield chunk

    async def close_context(self, context_id: str) -> AsyncIterator[AudioChunk]:
        """Close a specific context and get remaining audio.

        Args:
            context_id: Context to close

        Yields:
            AudioChunk for any remaining buffered text
        """
        if not self._is_started or context_id not in self._contexts:
            return

        await self._ws.send(
            json.dumps(
                {
                    "close_context": True,
                    "context_id": context_id,
                }
            )
        )

        async for chunk in self._receive_audio(context_id, wait_for_close=True):
            yield chunk

        self._contexts.discard(context_id)

    async def keep_alive(self, context_id: str) -> None:
        """Reset inactivity timeout for a context.

        Args:
            context_id: Context to keep alive
        """
        if self._is_started and context_id in self._contexts:
            await self._ws.send(
                json.dumps(
                    {
                        "text": "",
                        "context_id": context_id,
                    }
                )
            )

    async def _receive_audio(
        self,
        context_id: str,
        wait_for_close: bool = False,
    ) -> AsyncIterator[AudioChunk]:
        """Receive audio messages for a specific context.

        The server sends (per context):
          - {"generation_started": true, "context_id": "...", ...}
          - {"audio": "<b64>", "context_id": "...", ...}
          - {"word_timestamps": [...], "context_id": "...", ...}
          - {"chunk_complete": true, "context_id": "...", ...}
          - {"context_closed": true, "context_id": "..."}
        """
        received_any_audio = False

        while True:
            # Use longer timeout when waiting for a definitive server signal
            if wait_for_close:
                timeout = _DEFAULT_RECV_TIMEOUT_S
            else:
                timeout = (
                    _POLL_TIMEOUT_S if received_any_audio else _DEFAULT_RECV_TIMEOUT_S
                )

            try:
                msg = await asyncio.wait_for(self._ws.recv(), timeout=timeout)
                data = json.loads(msg)

                if data.get("error"):
                    _raise_for_error(data)

                msg_ctx = data.get("context_id")

                # Skip messages for other contexts — stash if needed later
                if msg_ctx != context_id:
                    self._pending_messages.append(data)
                    continue

                if data.get("generation_started"):
                    received_any_audio = False
                    continue

                # Only yield audio for matching context
                if data.get("audio"):
                    received_any_audio = True
                    yield AudioChunk.from_dict(data)

                if "word_timestamps" in data:
                    stamps = [
                        WordTimestamp.from_dict(w) for w in data["word_timestamps"]
                    ]
                    self._last_word_timestamps[context_id] = stamps
                    if self._on_word_timestamps:
                        self._on_word_timestamps(context_id, stamps)
                    continue

                # chunk_complete = one text-chunk done
                if data.get("chunk_complete"):
                    if not wait_for_close:
                        break
                    continue

                # context_closed = context removed (terminal)
                if data.get("context_closed"):
                    if wait_for_close:
                        break

            except asyncio.TimeoutError:
                # Short poll timed out — nothing more right now
                break
            except Exception as e:
                if "ConnectionClosed" in str(type(e)):
                    close_code = getattr(e, "code", None)
                    if close_code == 4003:
                        raise InsufficientCreditsError("Insufficient credits") from e
                    if close_code == 4001:
                        raise AuthenticationError("WebSocket authentication failed") from e
                    break
                raise

    async def close(self) -> Dict[str, Any]:
        """Close the session and return stats.

        Sends a close command and drains messages until the server responds
        with ``session_closed``.  Intermediate messages (context_closed,
        audio, chunk_complete) are silently consumed.

        Returns:
            Session statistics including total audio generated
        """
        stats: Dict[str, Any] = {}

        if self._ws:
            try:
                await self._ws.send(json.dumps({"close_socket": True}))

                # Drain messages until session_closed or timeout
                while True:
                    msg = await asyncio.wait_for(
                        self._ws.recv(), timeout=_DEFAULT_RECV_TIMEOUT_S
                    )
                    data = json.loads(msg)

                    if data.get("session_closed"):
                        stats = data
                        break

            except Exception:
                pass
            finally:
                await self._ws.close()
                self._ws = None
                self._is_started = False
                self._contexts.clear()

        return stats

    @property
    def active_contexts(self) -> Set[str]:
        """Get the set of active context IDs."""
        return self._contexts.copy()

    @property
    def session_id(self) -> Optional[str]:
        """Get the session ID."""
        return self._session_id
