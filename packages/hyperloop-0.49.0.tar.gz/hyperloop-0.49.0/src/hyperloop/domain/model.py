"""Domain model — value objects, entities, and pipeline primitives.

All types are pure data with no I/O dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import NewType

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class TaskStatus(StrEnum):
    """Lifecycle status of a task."""

    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class Verdict(StrEnum):
    """Outcome reported by a worker."""

    PASS = "pass"
    FAIL = "fail"


class WorkerPollStatus(StrEnum):
    """Status returned when polling a worker."""

    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


class DriftType(StrEnum):
    """Type of drift detected between spec and reality."""

    COVERAGE = "coverage"
    FRESHNESS = "freshness"
    ALIGNMENT = "alignment"


class PromptSource(StrEnum):
    """Source layer of a composed prompt section."""

    BASE = "base"
    PROJECT_OVERLAY = "project-overlay"
    PROCESS_OVERLAY = "process-overlay"
    SPEC = "spec"
    FINDINGS = "findings"
    RUNTIME = "runtime"
    PR = "pr"


class PromptLabel(StrEnum):
    """Label identifying the kind of a composed prompt section."""

    PROMPT = "prompt"
    GUIDELINES = "guidelines"
    SPEC = "spec"
    FINDINGS = "findings"
    EPILOGUE = "epilogue"
    PR_FEEDBACK = "pr-feedback"


class SpecChangeType(StrEnum):
    """Type of change detected for a spec file."""

    ADDED = "added"
    MODIFIED = "modified"
    DELETED = "deleted"
    NEW = "new"


class PMFailureResponse(StrEnum):
    """Response to PM consecutive failures."""

    BACKOFF = "backoff"
    HALT = "halt"


class AuditResult(StrEnum):
    """Result of an alignment audit."""

    ALIGNED = "aligned"
    MISALIGNED = "misaligned"


class StepType(StrEnum):
    """Type of a pipeline step, parsed from PhaseStep.run."""

    AGENT = "agent"
    ACTION = "action"
    SIGNAL = "signal"
    CHECK = "check"


# ---------------------------------------------------------------------------
# Simple types
# ---------------------------------------------------------------------------

Phase = NewType("Phase", str)
"""Current pipeline step name — a branded string for type safety."""

# ---------------------------------------------------------------------------
# Core entities / value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Task:
    """A unit of work tracked by the orchestrator."""

    id: str
    title: str
    spec_ref: str
    status: TaskStatus
    phase: Phase | None
    deps: tuple[str, ...]
    round: int
    branch: str | None
    pr: str | None
    pr_title: str | None = None
    pr_description: str | None = None


@dataclass(frozen=True)
class WorkerResult:
    """Verdict reported by a finished worker."""

    verdict: Verdict
    detail: str


@dataclass(frozen=True)
class WorkerHandle:
    """Opaque handle to a running worker session."""

    task_id: str
    role: str
    agent_id: str
    session_id: str | None


@dataclass(frozen=True)
class PRComment:
    """A comment on a pull request, used for feedback tracking."""

    id: str
    author: str
    body: str
    url: str


@dataclass(frozen=True)
class TaskProposal:
    """Value object produced by the PM agent during intake."""

    title: str
    spec_ref: str  # "specs/widget.md@abc123"
    deps: tuple[str, ...]
    pr_title: str | None = None
    pr_description: str | None = None


# ---------------------------------------------------------------------------
# Reconciler types — flat phase map replacing nested pipelines
# ---------------------------------------------------------------------------


class StepOutcome(StrEnum):
    """Result category from executing a phase step."""

    ADVANCE = "advance"
    RETRY = "retry"
    WAIT = "wait"


@dataclass(frozen=True)
class StepResult:
    """Value object returned by step execution."""

    outcome: StepOutcome
    detail: str
    pr_url: str | None = None


class SignalStatus(StrEnum):
    """Status of an external signal (gate replacement)."""

    APPROVED = "approved"
    REJECTED = "rejected"
    PENDING = "pending"


@dataclass(frozen=True)
class Signal:
    """Value object returned by signal checks."""

    status: SignalStatus
    message: str


@dataclass(frozen=True)
class PhaseStep:
    """A single step in a flat phase map.

    The ``run`` field must be ``'<type> <target>'`` where type is a valid
    ``StepType`` member.  Validation happens eagerly at construction time
    so malformed values surface immediately rather than deep in the task
    processor.
    """

    run: str
    on_pass: str
    on_fail: str
    on_wait: str | None = None
    args: dict[str, object] = field(default_factory=lambda: dict[str, object]())

    def __post_init__(self) -> None:
        parts = self.run.split(maxsplit=1)
        if len(parts) != 2:
            msg = f"PhaseStep.run must be '<type> <target>', got '{self.run}'"
            raise ValueError(msg)
        try:
            step_type = StepType(parts[0])
        except ValueError:
            msg = f"Unknown step type '{parts[0]}' in '{self.run}'"
            raise ValueError(msg) from None
        object.__setattr__(self, "_cached_step_type", step_type)
        object.__setattr__(self, "_cached_target", parts[1])

    @property
    def step_type(self) -> StepType:
        """Return the parsed step type (cached)."""
        return self._cached_step_type  # type: ignore[attr-defined]

    @property
    def target(self) -> str:
        """Return the target name (cached)."""
        return self._cached_target  # type: ignore[attr-defined]


PhaseMap = dict[str, PhaseStep]
"""Flat mapping of phase name to step definition."""


@dataclass(frozen=True)
class Process:
    """A named process with a flat phase map."""

    name: str
    phases: PhaseMap = field(default_factory=lambda: PhaseMap())


# ---------------------------------------------------------------------------
# World snapshot (input to the decide function)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WorkerState:
    """Snapshot of a worker's current status."""

    task_id: str
    role: str
    status: WorkerPollStatus


@dataclass(frozen=True)
class World:
    """Complete snapshot of orchestrator state for decision-making.

    Note: ``workers`` is always empty when returned by ``StateStore.get_world()``
    because worker liveness is runtime state, not persisted state. Use
    ``build_world()`` from ``cycle.helpers`` to get a World with populated
    workers by merging state store data with runtime poll results.
    """

    tasks: dict[str, Task]
    workers: dict[str, WorkerState]
    epoch: str


# ---------------------------------------------------------------------------
# Actions (output of the decide function)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SpawnWorker:
    """Spawn a new worker for a task with a given role."""

    task_id: str
    role: str


@dataclass(frozen=True)
class ReapWorker:
    """Collect results from a finished worker."""

    task_id: str


@dataclass(frozen=True)
class AdvanceTask:
    """Transition a task to a new status and/or phase."""

    task_id: str
    to_status: TaskStatus
    to_phase: Phase | None


@dataclass(frozen=True)
class Halt:
    """Stop the orchestrator loop."""

    reason: str


Action = SpawnWorker | ReapWorker | AdvanceTask | Halt
"""Union of all action types emitted by the decide function."""


# ---------------------------------------------------------------------------
# Prompt composition context types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TaskContext:
    """Context for per-task workers (implementer, verifier, rebase-resolver)."""

    task_id: str
    spec_ref: str
    findings: str
    round: int
    pr_feedback: str = ""


@dataclass(frozen=True)
class SpecIntakeEntry:
    """A spec that needs PM attention, with optional change context."""

    path: str
    change_type: SpecChangeType
    diff: str = ""


@dataclass(frozen=True)
class IntakeContext:
    """Context for PM intake."""

    unprocessed_specs: tuple[str, ...]
    spec_entries: tuple[SpecIntakeEntry, ...] = ()
    failed_tasks: tuple[str, ...] = ()
    failure_details: tuple[str, ...] = ()


@dataclass(frozen=True)
class ImprovementContext:
    """Context for process-improver."""

    findings: str


AgentContext = TaskContext | IntakeContext | ImprovementContext
"""Union of all context types for prompt composition."""


# ---------------------------------------------------------------------------
# Composed prompt with provenance
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PromptSection:
    """A section of a composed prompt with its source layer."""

    source: PromptSource
    label: PromptLabel
    content: str


@dataclass(frozen=True)
class ComposedPrompt:
    """A fully composed prompt with provenance for each section."""

    sections: tuple[PromptSection, ...]
    text: str  # the flattened string passed to the runtime
