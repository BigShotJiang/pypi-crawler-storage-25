"""Abstract base class for LLM providers."""

from abc import ABC, abstractmethod
from typing import Optional


class AIProvider(ABC):
    """Abstract provider for LLM-based test generation."""

    def __init__(self, api_key: str, model: str = "", api_base: Optional[str] = None):
        self.api_key = api_key
        self.model = model
        self.api_base = api_base

    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str, temperature: float = 0.1) -> str:
        """Send a prompt to the LLM and return the response text."""
        ...


def resolve_provider(config: dict) -> AIProvider:
    """Factory: build a provider from config dict.

    Config shape (from config.yaml or defaults):
        provider: claude | openai
        model: str
        api_key: str | $ENV_VAR
        api_base: str (optional)
    """
    provider_name = config.get("provider", "claude").lower()
    model = config.get("model", "")
    api_key = config.get("api_key", "")
    api_base = config.get("api_base")

    # Resolve $ENV_VAR references
    if api_key.startswith("${") and api_key.endswith("}"):
        env_var = api_key[2:-1]
        api_key = __import__("os").environ.get(env_var, "")
    elif not api_key:
        # Fallback: try conventional env vars
        import os
        api_key = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY") or ""

    if provider_name == "openai":
        from lounger.ai.providers.openai import OpenAIProvider
        if not model:
            model = "gpt-4o"
        return OpenAIProvider(api_key=api_key, model=model, api_base=api_base)
    else:
        from lounger.ai.providers.claude import ClaudeProvider
        if not model:
            model = "claude-sonnet-4-20250514"
        return ClaudeProvider(api_key=api_key, model=model, api_base=api_base)
