"""Anthropic Claude API provider."""

from typing import Optional
import requests

from lounger.ai.providers.base import AIProvider
from lounger.log import log


DEFAULT_API_BASE = "https://api.anthropic.com/v1"


class ClaudeProvider(AIProvider):
    """Provider for Anthropic Claude models."""

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-20250514",
                 api_base: Optional[str] = None):
        super().__init__(api_key, model, api_base or DEFAULT_API_BASE)
        self._api_base = (api_base or DEFAULT_API_BASE).rstrip("/")

    def generate(self, system_prompt: str, user_prompt: str,
                 temperature: float = 0.1) -> str:
        url = f"{self._api_base}/messages"

        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }

        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "temperature": temperature,
            "system": system_prompt,
            "messages": [{"role": "user", "content": user_prompt}],
        }

        log.info(f"🤖 Calling Claude ({self.model})…")
        resp = requests.post(url, headers=headers, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()

        content_blocks = data.get("content", [])
        text = "".join(block.get("text", "") for block in content_blocks if block.get("type") == "text")
        return text.strip()
