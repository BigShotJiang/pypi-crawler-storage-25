"""OpenAI-compatible API provider."""

from typing import Optional
import requests

from lounger.ai.providers.base import AIProvider
from lounger.log import log


DEFAULT_API_BASE = "https://api.openai.com/v1"


class OpenAIProvider(AIProvider):
    """Provider for OpenAI or compatible APIs."""

    def __init__(self, api_key: str, model: str = "gpt-4o",
                 api_base: Optional[str] = None):
        super().__init__(api_key, model, api_base or DEFAULT_API_BASE)
        self._api_base = (api_base or DEFAULT_API_BASE).rstrip("/")

    def generate(self, system_prompt: str, user_prompt: str,
                 temperature: float = 0.1) -> str:
        url = f"{self._api_base}/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "content-type": "application/json",
        }

        payload = {
            "model": self.model,
            "max_tokens": 4096,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }

        log.info(f"🤖 Calling OpenAI ({self.model})…")
        resp = requests.post(url, headers=headers, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()

        choice = data.get("choices", [{}])[0]
        return choice.get("message", {}).get("content", "").strip()
