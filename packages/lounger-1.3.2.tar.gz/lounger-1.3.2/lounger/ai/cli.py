"""CLI command for `lounger ai`."""

import os
from pathlib import Path

import click

from lounger.ai.engine import AIEngine


@click.command("ai")
@click.argument("description", required=False, default="")
@click.option("-p", "--project", default=".", help="Project root directory (default: .)")
@click.option("--type", "output_type", default="yaml", type=click.Choice(["yaml"]),
              help="Output format (default: yaml)")
@click.option("--target", help="Target datas/ subdirectory (e.g. sample, custom)")
@click.option("--dry-run", is_flag=True, help="Preview without writing files")
@click.option("--interactive", "-i", is_flag=True, help="Interactive mode")
@click.option("--provider", help="LLM provider (claude, openai). Overrides config.")
@click.option("--model", help="Model name. Overrides config.")
@click.option("--curl", "curl_cmd", help="Curl command as precise API definition input")
def ai_command(description, project, output_type, target, dry_run, interactive, provider, model, curl_cmd):
    """Generate test cases from natural language using AI.

    Examples:

        lounger ai "Get all posts and verify status code is 200"

        lounger ai --curl 'curl -X POST https://api.example.com/users -H "Content-Type: application/json" -d \'{"name":"John"}\''

        lounger ai -i  (interactive mode)

        lounger ai "Test login flow with valid credentials" --dry-run
    """
    # Resolve project root
    project_root = Path(project).resolve()
    if not (project_root / "config" / "config.yaml").exists():
        click.echo(f"❌ Not a lounger project: {project_root} (config/config.yaml not found)")
        raise click.Abort()

    # Build engine
    engine = AIEngine(project_dir=str(project_root))

    # Override provider if specified
    if provider or model:
        config_path = project_root / "config" / "config.yaml"
        ai_cfg = {"provider": provider or "claude", "model": model or ""}
        if config_path.exists():
            import yaml
            with open(config_path) as f:
                cfg = yaml.safe_load(f) or {}
            existing_ai = cfg.get("ai", {})
            ai_cfg.setdefault("api_key", existing_ai.get("api_key", ""))
            ai_cfg.setdefault("api_base", existing_ai.get("api_base"))
        engine._resolve_provider_from_config(ai_cfg)

    if interactive:
        engine.generate_interactive(project=target)
        return

    if not description and not curl_cmd:
        click.echo("Usage: lounger ai <description>")
        click.echo("   or: lounger ai --curl 'curl ...'")
        click.echo("   or: lounger ai --interactive")
        raise click.Abort()

    # Parse curl if provided (even just the curl, description is optional)
    parsed_curl = None
    if curl_cmd:
        from lounger.ai.curl_parser import parse_curl, curl_to_text
        try:
            parsed_curl = parse_curl(curl_cmd)
            click.echo("🔧 Parsed curl command:")
            click.echo(curl_to_text(parsed_curl))
        except Exception as e:
            click.echo(f"❌ Failed to parse curl: {e}", err=True)
            raise click.Abort()

    result = engine.generate(
        description=description or "",
        output_type=output_type,
        project=target,
        dry_run=dry_run,
        curl_data=parsed_curl,
    )

    if result["success"]:
        if result.get("filepath"):
            click.echo(f"\n📄 Test case saved: {result['filepath']}")
        if result.get("warnings"):
            for w in result["warnings"]:
                click.echo(f"  ⚠️  {w}")
    else:
        click.echo(f"\n❌ {result.get('error')}", err=True)
        if result.get("raw_output"):
            click.echo("\n── Raw LLM output ──")
            click.echo(result["raw_output"])
        raise click.Abort()
