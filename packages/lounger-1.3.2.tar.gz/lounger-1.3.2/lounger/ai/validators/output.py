"""Validate generated YAML test cases against Lounger schema."""

from typing import Optional

from lounger.log import log


def validate_yaml_case(data: list) -> list[str]:
    """Validate a parsed YAML test case list.

    Returns a list of warning/error messages (empty = valid).
    """
    errors: list[str] = []

    if not isinstance(data, list):
        return ["Top-level structure must be a list"]

    for i, item in enumerate(data):
        if not isinstance(item, dict):
            errors.append(f"Item #{i} is not a dict")
            continue

        teststeps = item.get("teststeps")
        if teststeps is None:
            errors.append(f"Item #{i}: missing 'teststeps' key")
            continue

        if not isinstance(teststeps, list):
            errors.append(f"Item #{i}: 'teststeps' must be a list")
            continue

        for j, step in enumerate(teststeps):
            step_errors = _validate_step(step, i, j)
            errors.extend(step_errors)

    if errors:
        for err in errors:
            log.warning(f"⚠️  Validation: {err}")
    else:
        log.info("✅ Validation passed")

    return errors


def _validate_step(step: dict, item_idx: int, step_idx: int) -> list[str]:
    """Validate a single test step."""
    errors: list[str] = []

    if not isinstance(step, dict):
        return [f"Item #{item_idx}, step #{step_idx}: expected dict, got {type(step).__name__}"]

    if "step" not in step:
        errors.append(f"Item #{item_idx}, step #{step_idx}: missing 'step' field")

    has_request = "request" in step
    has_centrifuge = "centrifuge" in step

    if not has_request and not has_centrifuge:
        errors.append(f"Item #{item_idx}, step #{step_idx}: must contain 'request' or 'centrifuge'")

    if has_request:
        req = step["request"]
        if isinstance(req, dict):
            if "method" not in req:
                errors.append(f"Item #{item_idx}, step #{step_idx}: request missing 'method'")
            if "url" not in req:
                errors.append(f"Item #{item_idx}, step #{step_idx}: request missing 'url'")

            # Validate assertions if present
            validate = req.get("validate") or step.get("validate")
            if validate is not None:
                validate_errors = _validate_assertions(validate, item_idx, step_idx)
                errors.extend(validate_errors)

    return errors


# ── helpers ──

VALID_ASSERT_TYPES = {
    "equal", "not_equal", "contains", "not_contains",
    "type", "length", "greater", "greater_equal",
    "less", "less_equal", "is_null", "is_not_null",
}


def _validate_assertions(validate: dict, item_idx: int, step_idx: int) -> list[str]:
    errors: list[str] = []
    for assert_type, assertions in validate.items():
        if assert_type not in VALID_ASSERT_TYPES:
            errors.append(
                f"Item #{item_idx}, step #{step_idx}: unknown assert type '{assert_type}'"
            )
        if not isinstance(assertions, list):
            errors.append(
                f"Item #{item_idx}, step #{step_idx}: '{assert_type}' must be a list"
            )
            continue
        for pair in assertions:
            if not isinstance(pair, list) or len(pair) != 2:
                errors.append(
                    f"Item #{item_idx}, step #{step_idx}: each assertion must be [expression, expected]"
                )
    return errors
