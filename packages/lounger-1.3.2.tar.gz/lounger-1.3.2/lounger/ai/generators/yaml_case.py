"""Parse LLM output and write Lounger YAML test case files."""

import os
import re
from pathlib import Path
from typing import Optional

import yaml

from lounger.log import log


def parse_llm_response(text: str) -> Optional[list]:
    """Extract YAML list from LLM output.

    Handles:
    - ```yaml ... ``` code blocks
    - ``` ... ``` generic blocks
    - raw YAML starting with ``` - teststeps:
    """
    # Try yaml code block first
    block_match = re.search(
        r"```(?:yaml|yml)\s*\n(.*?)```",
        text,
        re.DOTALL,
    )
    if block_match:
        raw = block_match.group(1).strip()
    else:
        # Try generic code block
        block_match = re.search(r"```\s*\n(.*?)```", text, re.DOTALL)
        if block_match:
            raw = block_match.group(1).strip()
        else:
            raw = text.strip()

    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        log.error(f"YAML parse error: {e}")
        return None

    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    return None


def generate_filename(description: str, project: str = "custom") -> str:
    """Derive a YAML filename from the description."""
    # Take first ~40 chars, lowercase, replace spaces with underscores
    words = description.lower().split()
    # Remove common filler words
    clean = [w for w in words if w not in ("a", "an", "the", "for", "and", "to", "of", "is")]
    stem = "_".join(clean[:6]) if clean else "ai_generated"
    # Limit length
    stem = stem[:60].rstrip("_")
    project_dir = project.replace("/", os.sep)
    return f"datas/{project_dir}/test_{stem}.yaml"


def write_yaml_case(data: list, filepath: str, project_root: str, dry_run: bool = False) -> str:
    """Write parsed YAML test case to disk.

    Returns the absolute path written (or would-be-written).
    """
    full_path = Path(project_root) / filepath

    if dry_run:
        log.info(f"[dry-run] Would write: {full_path}")
        return str(full_path)

    full_path.parent.mkdir(parents=True, exist_ok=True)

    with open(full_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, allow_unicode=True, indent=2, sort_keys=False)

    log.info(f"✅ Written: {full_path}")
    return str(full_path)


def display_case(data: list) -> None:
    """Print generated YAML to console."""
    print(yaml.dump(data, allow_unicode=True, indent=2, sort_keys=False))
