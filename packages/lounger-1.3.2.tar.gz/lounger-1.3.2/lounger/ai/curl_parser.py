"""Parse curl command strings into structured API request data."""

import shlex
from typing import Optional


def parse_curl(curl_cmd: str) -> dict:
    """Parse a curl command and return structured request info.

    Returns:
        method: str (default "GET")
        url: str
        headers: dict[str, str]
        body: str | None
        auth: str | None (username:password)
        is_form: bool
    """
    result = {
        "method": "GET",
        "url": "",
        "headers": {},
        "body": None,
        "auth": None,
        "is_form": False,
    }

    # Normalize: collapse multi-line (backslash-newline) into spaces
    normalized = _collapse_lines(curl_cmd)

    # Remove leading "curl " if present
    normalized = normalized.strip()
    if normalized.startswith("curl "):
        normalized = normalized[5:].strip()

    try:
        tokens = shlex.split(normalized)
    except ValueError as e:
        raise ValueError(f"Failed to parse curl command: {e}")

    # Collect URLs from positional args (everything that's not a flag)
    urls = []

    i = 0
    while i < len(tokens):
        token = tokens[i]

        # ── long flags ──
        if token in ("--request", "--method"):
            i += 1
            if i < len(tokens):
                result["method"] = tokens[i].upper()
        elif token == "--header":
            i += 1
            if i < len(tokens):
                key, value = _parse_header(tokens[i])
                result["headers"][key] = value
        elif token in ("--data", "--data-raw", "--data-binary"):
            i += 1
            if i < len(tokens):
                result["body"] = tokens[i]
                if result["method"] == "GET":
                    result["method"] = "POST"
        elif token == "--user":
            i += 1
            if i < len(tokens):
                result["auth"] = tokens[i]
        elif token == "--form":
            result["is_form"] = True
            # skip next token (form data)
            i += 1
        elif token == "--get":
            result["method"] = "GET"
        elif token == "--head":
            result["method"] = "HEAD"

        # ── short flags ──
        elif token.startswith("-X"):
            val = token[2:]
            if val:
                result["method"] = val.upper()
            else:
                i += 1
                if i < len(tokens):
                    result["method"] = tokens[i].upper()
        elif token == "-H":
            i += 1
            if i < len(tokens):
                key, value = _parse_header(tokens[i])
                result["headers"][key] = value
        elif token in ("-d", "--data"):
            i += 1
            if i < len(tokens):
                result["body"] = tokens[i]
                if result["method"] == "GET":
                    result["method"] = "POST"
        elif token == "-u":
            i += 1
            if i < len(tokens):
                result["auth"] = tokens[i]
        elif token == "-F":
            result["is_form"] = True
            i += 1  # skip form value
        elif token == "-I" or token == "--head":
            result["method"] = "HEAD"

        # ── possibly a URL (not starting with -) ──
        elif not token.startswith("-"):
            urls.append(token)

        i += 1

    # Take the last URL (curl convention)
    if urls:
        result["url"] = urls[-1]

    return result


def _collapse_lines(cmd: str) -> str:
    """Join backslash-continued lines."""
    lines = cmd.split("\n")
    collapsed = []
    for line in lines:
        if line.rstrip().endswith("\\"):
            collapsed.append(line.rstrip()[:-1])
        else:
            collapsed.append(line)
    return " ".join(collapsed)


def _parse_header(header_str: str) -> tuple[str, str]:
    """Parse a header string like 'Content-Type: application/json'."""
    if ":" in header_str:
        key, _, value = header_str.partition(":")
        return key.strip(), value.strip()
    return header_str.strip(), ""


def curl_to_text(curl_data: dict) -> str:
    """Format parsed curl data as human-readable text for LLM prompts."""
    parts = [f"- **Method**: {curl_data['method']}"]
    parts.append(f"- **URL**: {curl_data['url']}")

    if curl_data["headers"]:
        h = "\n".join(f"  `{k}: {v}`" for k, v in curl_data["headers"].items())
        parts.append(f"- **Headers**:\n{h}")

    if curl_data["body"]:
        parts.append(f"- **Body**:\n```\n{curl_data['body']}\n```")

    if curl_data["auth"]:
        parts.append(f"- **Auth**: Basic (user present)")

    if curl_data["is_form"]:
        parts.append("- **Form data**: Yes")

    return "\n".join(parts)
