"""Core AI engine — orchestrates context, prompt, LLM, and output."""

import json
import os
from pathlib import Path
from typing import Optional

from lounger.ai.context import collect_context
from lounger.ai.generators.yaml_case import (
    display_case,
    generate_filename,
    parse_llm_response,
    write_yaml_case,
)
from lounger.ai.prompts import SYSTEM_PROMPT
from lounger.ai.providers.base import AIProvider, resolve_provider
from lounger.ai.validators.output import validate_yaml_case
from lounger.log import log


class AIEngine:
    """Main orchestrator for AI test generation."""

    def __init__(self, project_dir: str = ".", provider: Optional[AIProvider] = None):
        self.project_dir = Path(project_dir).resolve()
        self.provider = provider

    def _resolve_provider_from_config(self, ai_cfg: dict) -> None:
        """Set provider from a config dict (used by CLI overrides)."""
        self.provider = resolve_provider(ai_cfg)

    # ── public API ──

    def generate(self, description: str = "", output_type: str = "yaml",
                 project: Optional[str] = None, dry_run: bool = False,
                 curl_data: Optional[dict] = None) -> dict:
        """Generate a test case from natural language description and/or curl.

        Args:
            description: Natural language test description (optional if curl provided).
            output_type: "yaml" (default) or "python".
            project: Target datas/ subdirectory (e.g. "sample", "custom").
            dry_run: If True, print output without writing files.
            curl_data: Parsed curl command data from curl_parser.

        Returns:
            dict with keys: success, filepath (if written), text, warnings
        """
        # 1. Collect project context
        context = collect_context(str(self.project_dir))

        # 2. Ensure provider is configured
        if self.provider is None:
            ai_cfg = context.get("ai_config", {})
            if not ai_cfg.get("api_key"):
                ai_cfg["api_key"] = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY", "")
            if not ai_cfg.get("api_key"):
                return {
                    "success": False,
                    "error": "No API key found. Set ANTHROPIC_API_KEY/OPENAI_API_KEY env var "
                             "or configure ai.api_key in config/config.yaml",
                }
            self.provider = resolve_provider(ai_cfg)

        # 3. Build user prompt with context + curl data
        user_prompt = self._build_user_prompt(description, context, project, curl_data)

        # 4. Call LLM
        try:
            raw_output = self.provider.generate(
                system_prompt=SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
        except Exception as e:
            log.error(f"LLM call failed: {e}")
            return {"success": False, "error": str(e)}

        # 5. Parse response
        parsed = parse_llm_response(raw_output)
        if parsed is None:
            return {
                "success": False,
                "error": "Could not parse YAML from LLM response",
                "raw_output": raw_output,
            }

        # 6. Validate
        warnings = validate_yaml_case(parsed)

        # 7. Display / write
        log.info("── Generated Test Case ──")
        display_case(parsed)

        # 8. Write if not dry-run
        filepath = None
        label = description or (curl_data.get("method", "") + " " + curl_data.get("url", "")) if curl_data else "ai_generated"
        if not dry_run:
            proj = project or (context["test_projects"][0] if context["test_projects"] else "custom")
            rel_path = generate_filename(label, project=proj)
            filepath = write_yaml_case(parsed, rel_path, str(self.project_dir), dry_run=False)

        result = {
            "success": True,
            "warnings": warnings,
            "filepath": filepath,
            "data": parsed,
        }
        return result

    def generate_interactive(self, project: Optional[str] = None) -> None:
        """Interactive mode: loop prompt→generate cycle."""
        log.info("🤖 Lounger AI interactive mode. Type 'exit' to quit.\n")

        # Collect context once
        context = collect_context(str(self.project_dir))
        if self.provider is None:
            ai_cfg = context.get("ai_config", {})
            self.provider = resolve_provider(ai_cfg)

        while True:
            try:
                desc = input("🎯 Describe the test (or 'exit'): ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break

            if not desc:
                continue
            if desc.lower() in ("exit", "quit", "q"):
                break

            result = self.generate(desc, project=project, dry_run=True)

            if not result["success"]:
                log.error(f"Failed: {result.get('error')}")
                continue

            # Ask for confirmation
            try:
                confirm = input("\n💾 Write to file? (y/n): ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                break

            if confirm in ("y", "yes"):
                proj = project or (context["test_projects"][0] if context["test_projects"] else "custom")
                rel_path = generate_filename(desc, project=proj)
                filepath = write_yaml_case(result["data"], rel_path, str(self.project_dir))
                log.info(f"📄 Saved: {filepath}")

    # ── internal ──

    def _build_user_prompt(self, description: str, context: dict,
                           project: Optional[str] = None,
                           curl_data: Optional[dict] = None) -> str:
        sections = []

        # Project context
        sections.append("## Project Context")
        if context.get("base_url"):
            sections.append(f"- base_url: {context['base_url']}")
        if context.get("test_projects"):
            sections.append(f"- enabled test projects: {', '.join(context['test_projects'])}")
        if context.get("api_clients"):
            sections.append(f"- API clients available: {', '.join(context['api_clients'])}")
        if context.get("has_openapi"):
            sections.append("- OpenAPI spec detected (use it to inform endpoint paths and schemas)")

        # ── Curl input (precise API definition) ──
        if curl_data:
            from lounger.ai.curl_parser import curl_to_text
            sections.append("\n## Exact API Definition (from curl command)")
            sections.append("Use THIS as the authoritative API specification. "
                            "Generate the test case based on these exact details.")
            sections.append(curl_to_text(curl_data))

        # Existing examples (few-shot)
        if context.get("existing_examples"):
            sections.append("\n## Existing Test Examples (follow this style)")
            for ex in context["existing_examples"]:
                import yaml
                sections.append(f"### File: {ex['file']}")
                sections.append("```yaml")
                sections.append(yaml.dump([{"teststeps": ex["teststeps"]}],
                                          allow_unicode=True, indent=2, sort_keys=False))
                sections.append("```")

        # Target project
        target = project or (context["test_projects"][0] if context["test_projects"] else "custom")
        sections.append(f"\n## Task\nGenerate a YAML test case file for project `{target}`.")

        # User description (optional, supplement)
        if description:
            sections.append(f"\n### Additional notes:\n{description}")
        elif not curl_data:
            sections.append(f"\n### Test description:\n{description}")

        return "\n".join(sections)
