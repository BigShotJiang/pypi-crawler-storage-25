"""Collect project context for AI prompt enrichment."""

import os
from pathlib import Path
from typing import Any


def collect_context(project_dir: str) -> dict:
    """Scan a lounger project and return a context dict.

    Returns:
        base_url: str | None
        test_projects: list[str]  — enabled datas/ subdirs
        existing_examples: list[dict] — sampled YAML cases (up to 3)
        api_clients: list[dict] — discovered client methods
        has_openapi: bool
    """
    root = Path(project_dir).resolve()
    context: dict[str, Any] = {
        "base_url": None,
        "test_projects": [],
        "existing_examples": [],
        "api_clients": [],
        "has_openapi": False,
        "project_type": "api",  # default
    }

    # 1. Read config.yaml
    config_path = root / "config" / "config.yaml"
    if config_path.exists():
        try:
            import yaml
            with open(config_path, encoding="utf-8") as f:
                cfg = yaml.safe_load(f) or {}

            context["base_url"] = cfg.get("base_url")
            test_project = cfg.get("test_project", {})
            context["test_projects"] = [k for k, v in test_project.items() if v]

            # AI config
            context["ai_config"] = cfg.get("ai", {})
        except Exception:
            pass

    # 2. Sample existing YAML test cases (up to 3 files, first teststeps only)
    datas_dir = root / "datas"
    if datas_dir.exists():
        yaml_files = sorted(datas_dir.rglob("*.yaml")) + sorted(datas_dir.rglob("*.yml"))
        for yf in yaml_files[:3]:
            try:
                import yaml
                with open(yf, encoding="utf-8") as f:
                    data = yaml.safe_load(f)
                if isinstance(data, list) and len(data) > 0:
                    # Only keep first entry to limit context size
                    entry = data[0]
                    if isinstance(entry, dict) and "teststeps" in entry:
                        context["existing_examples"].append({
                            "file": str(yf.relative_to(root)),
                            "teststeps": entry["teststeps"][:3],  # first 3 steps
                        })
            except Exception:
                pass

    # 3. Scan api/clients/ for client classes (only file names)
    clients_dir = root / "api" / "clients"
    if clients_dir.exists():
        for py_file in sorted(clients_dir.glob("*.py")):
            if py_file.name == "__init__.py":
                continue
            context["api_clients"].append(py_file.stem)

    # 4. Check for OpenAPI spec
    for candidate in ("openapi.json", "openapi.yaml", "swagger.json", "swagger.yaml"):
        if (root / candidate).exists():
            context["has_openapi"] = True
            break
    for candidate in ("openapi.json", "openapi.yaml", "swagger.json", "swagger.yaml"):
        if (root / "config" / candidate).exists():
            context["has_openapi"] = True
            break

    # 5. Determine project type (web if playwright detected)
    pytest_ini = root / "pytest.ini"
    if pytest_ini.exists():
        try:
            content = pytest_ini.read_text(encoding="utf-8")
            if "playwright" in content.lower():
                context["project_type"] = "web"
        except Exception:
            pass

    return context
