"""Package data for vided."""
