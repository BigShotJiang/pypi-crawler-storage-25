"""TopicWorker — maintains state.current_topic from rolling self-buffer speech.

Listens on self_buffer for new finalized sentences. On each one, schedules a
debounced topic extraction job (max 1/5s, skipped if the rolling text hasn't
changed). Uses the user's configured AI provider (via _call_ai_for_tasks) so
cost/latency follows their existing settings.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import threading
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig
    from meeting_helper.buffer import SentenceBuffer

logger = logging.getLogger(__name__)


_EMPTY_TOPIC = {
    "topic": "",
    "ticket_ids": [],
    "search_query": "",
    "last_user_statement": "",
}

# Whisper hallucinates dots/short words on silence — e.g. "....." or "Okay."
# while the mic is muted. Require at least this many alphabetic-containing
# words before treating a sentence as real engagement.
MIN_ENGAGEMENT_WORDS = 5
_WORD_RE = re.compile(r"[A-Za-z]")


def _real_word_count(text: str) -> int:
    return sum(1 for tok in text.split() if _WORD_RE.search(tok))


class TopicWorker:
    """Background topic tracker bound to a self_buffer.

    Lifecycle: instantiate, call start(), then stop() on session end.
    """

    DEBOUNCE_SECS = 5.0
    WINDOW_SENTENCES = 25  # how many recent self-sentences to consider

    def __init__(self, config: "AppConfig", self_buffer: "SentenceBuffer") -> None:
        self._config = config
        self._buffer = self_buffer
        self._stop_event = threading.Event()
        self._last_run_at: float = 0.0
        self._last_hash: str = ""
        self._timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._enabled: bool = True
        # Cache the bound listener so add/remove see the SAME object identity
        # (bound methods are re-created on each attribute access).
        self._listener = self._on_sentence
        self._other_listener = self._on_other_sentence

    # ---- Lifecycle ----

    def start(self) -> None:
        from meeting_helper.state import state
        self._buffer.add_sentence_listener(self._listener)
        if state.other_buffer is not None:
            state.other_buffer.add_sentence_listener(self._other_listener)
        logger.info("TopicWorker started")

    def stop(self) -> None:
        from meeting_helper.state import state
        self._enabled = False
        self._stop_event.set()
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        try:
            self._buffer.remove_sentence_listener(self._listener)
        except Exception:
            pass
        if state.other_buffer is not None:
            try:
                state.other_buffer.remove_sentence_listener(self._other_listener)
            except Exception:
                pass
        logger.info("TopicWorker stopped")

    # ---- Trigger ----

    def _on_sentence(self, _sentence: str) -> None:
        """Called from the transcriber thread on every new finalized sentence."""
        if not self._enabled:
            return
        # Drop silence-driven hallucinations ("....." or single fillers) so a
        # muted user doesn't keep flipping engagement from Idle to Active.
        if _real_word_count(_sentence) < MIN_ENGAGEMENT_WORDS:
            return
        # Self-speech is the canonical engagement signal — re-arm Hot Moment.
        # Re-read config from the global singleton each time so live updates
        # via POST /config take effect on the next sentence (the worker holds
        # a reference to the same Config instance, but read-via-property is
        # the safe pattern in case the instance ever gets swapped).
        from meeting_helper.state import state
        from meeting_helper.config import get_config
        window_min = get_config().hot_moment_window_minutes
        state.arm_hot_moment(window_sec=window_min * 60.0)
        logger.debug("Hot Moment armed for %.1f min (= %.0f s)", window_min, window_min * 60.0)
        now = time.monotonic()
        elapsed = now - self._last_run_at
        if elapsed >= self.DEBOUNCE_SECS:
            # Run immediately
            self._schedule_run(0.0)
        else:
            # Debounce: schedule for the remaining window if not already pending
            with self._lock:
                if self._timer is None:
                    delay = self.DEBOUNCE_SECS - elapsed
                    t = threading.Timer(delay, self._fire_via_loop)
                    t.daemon = True
                    self._timer = t
                    t.start()

    def _on_other_sentence(self, _sentence: str) -> None:
        """Other-buffer sentence — only fires the worker if Hot Moment is active."""
        if not self._enabled:
            return
        from meeting_helper.state import state
        if not state.is_hot_moment():
            return
        # Hot Moment is on — treat exactly like a self-sentence trigger:
        # debounce, run, etc.
        self._on_sentence(_sentence)

    def _schedule_run(self, delay: float) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
        if delay <= 0:
            self._fire_via_loop()
        else:
            t = threading.Timer(delay, self._fire_via_loop)
            t.daemon = True
            with self._lock:
                self._timer = t
            t.start()

    def _fire_via_loop(self) -> None:
        """Hand off to the asyncio loop where _run() can do async work."""
        with self._lock:
            self._timer = None
        if not self._enabled:
            return
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is None:
            return
        asyncio.run_coroutine_threadsafe(self._run(), loop)

    # ---- Buffer merge ----

    def collect_window(
        self,
        other_buffer: "SentenceBuffer | None",
        n: int,
    ) -> list[tuple[str, str]]:
        """Build the chronological, role-labeled sentence list fed to the LLM.

        When Hot Moment is OFF (or ``other_buffer`` is None), returns the last
        ``n`` self-sentences as ``("self", text)`` tuples — identical to the
        pre-Hot-Moment behavior.

        When Hot Moment is ON, merges entries from both buffers by their
        per-entry ``timestamp`` and returns the last ``n`` entries of the
        merged stream. Each entry is ``("self"|"other", text)``.
        """
        from meeting_helper.state import state

        with self._buffer._lock:
            self_entries = [(e.timestamp, "self", e.text) for e in self._buffer._sentences]

        if other_buffer is None or not state.is_hot_moment():
            return [(role, text) for _ts, role, text in self_entries[-n:]]

        with other_buffer._lock:
            other_entries = [(e.timestamp, "other", e.text) for e in other_buffer._sentences]

        merged = sorted(self_entries + other_entries, key=lambda t: t[0])
        return [(role, text) for _ts, role, text in merged[-n:]]

    # ---- Async work ----

    async def _run(self) -> None:
        if not self._enabled:
            return

        from meeting_helper.state import state as _state
        labeled = self.collect_window(_state.other_buffer, n=self.WINDOW_SENTENCES)
        if not labeled:
            return

        # Hash-skip: if labeled text hasn't changed since last run, do nothing.
        text = "\n".join(f"{role}:{txt}" for role, txt in labeled)
        h = hashlib.sha1(text.encode("utf-8")).hexdigest()
        if h == self._last_hash:
            return
        self._last_hash = h
        self._last_run_at = time.monotonic()

        # Constrained pick: use the cached sprint tickets as the LLM's
        # candidate list. Avoids free-form drift and survives transcription
        # noise (the LLM understands "tribute remapper" = "the remapper").
        from meeting_helper.ai.client import (
            pick_topic_ticket,
            refresh_sprint_tickets,
        )
        from meeting_helper.state import state

        await refresh_sprint_tickets(state)
        picked = await pick_topic_ticket(state, self._config, question="")
        if picked is None:
            # Nothing in the sprint cache matched the conversation. Leave
            # state.current_topic alone so we don't blank the banner on a
            # transient mismatch.
            logger.debug("TopicWorker: no sprint match for current discussion")
            return

        topic_str = picked.get("title") or picked.get("_llm_topic") or ""
        ticket_ids = [picked.get("id")] if picked.get("id") else []
        cards = [picked]

        prev = state.current_topic or {}
        state.current_topic = {
            "topic": topic_str,
            "ticket_ids": ticket_ids,
            "search_query": picked.get("_llm_topic") or topic_str,
            "last_user_statement": prev.get("last_user_statement", ""),
        }
        state.current_topic_cards = cards

        # Broadcast so UIs can show what the agent thinks
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "topic",
                "topic": topic_str,
                "ticket_ids": ticket_ids,
                "last_user_statement": prev.get("last_user_statement", ""),
                "cards": cards,
                "hot_moment": {
                    "active": state.is_hot_moment(),
                    "until_wallclock": state.hot_moment_until_wallclock(),
                },
            })
        except Exception as exc:
            logger.warning("topic broadcast failed: %s", exc)

        logger.info(
            "TopicWorker picked: topic=%r ticket_id=%s",
            topic_str,
            ticket_ids[0] if ticket_ids else None,
        )

    async def _extract_topic(self, labeled: list[tuple[str, str]]) -> dict:
        """Call the user's configured AI provider to extract topic info."""
        from meeting_helper.ai.client import _call_ai_for_tasks
        from meeting_helper.ai.prompts import (
            TOPIC_EXTRACTION_SYSTEM_PROMPT,
            build_topic_extraction_user_message,
        )

        from meeting_helper.state import state
        prev_topic = (state.current_topic or {}).get("topic", "")
        user_msg = build_topic_extraction_user_message(
            labeled_sentences=labeled,
            previous_topic=prev_topic,
        )
        try:
            raw = await _call_ai_for_tasks(
                self._config, TOPIC_EXTRACTION_SYSTEM_PROMPT, user_msg
            )
        except Exception as exc:
            logger.warning("topic extraction AI call failed: %s", exc)
            return dict(_EMPTY_TOPIC)

        if not raw or not raw.strip():
            return dict(_EMPTY_TOPIC)

        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            return dict(_EMPTY_TOPIC)
        try:
            parsed = json.loads(match.group())
        except json.JSONDecodeError:
            return dict(_EMPTY_TOPIC)

        return {
            "topic": str(parsed.get("topic", "")).strip(),
            "ticket_ids": [str(t).strip() for t in (parsed.get("ticket_ids") or []) if str(t).strip()],
            "search_query": str(parsed.get("search_query", "")).strip(),
            "last_user_statement": str(parsed.get("last_user_statement", "")).strip(),
        }
