"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "2.5.6"
