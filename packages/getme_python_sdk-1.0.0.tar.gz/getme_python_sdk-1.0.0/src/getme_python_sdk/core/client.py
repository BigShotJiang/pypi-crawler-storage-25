import os

import requests_unixsocket
from dotenv import load_dotenv
import json
from urllib.parse import quote_plus

from .constants import Constants


class GetMeClient:
    """
    A client for interacting with the getMe daemon over a Unix Domain Socket.
    """

    def __init__(self):
        load_dotenv()
        self.unix_session = requests_unixsocket.Session()
        self.sock_path = quote_plus(
            os.getenv("GETME_SOCK_PATH", "/tmp/getMeStore/sockDir/getMe.sock")
        )

    def put(self, key, value):
        """
        Puts a key-value pair into the store. The value is sent in the request body.

        :param key: The key for the entry.
        :param value: The value to store.
        :raises Exception: If the server returns a non-200 status code.
        """

        url = f"{Constants.BaseUrl}{self.sock_path}/put"

        payload = {"key": key, "value": value}
        headers = {"Content-Type": "application/json"}

        response = self.unix_session.post(
            url, data=json.dumps(payload), headers=headers
        )
        if response.status_code != 200:
            raise Exception(f"Failed to put key-value pair: {response.text}")

        return response.json()

    def put_json(self, key, value):
        """Serializes value as JSON and stores it under the given key."""

        json_string = json.dumps(value, separators=(",", ":"))
        return self.put(key, json_string)

    def get(self, key) -> str:
        """
        Gets a value for a given key from the store.

        :param key: The key to retrieve.
        :return: The value associated with the key as a string.
        :raises Exception: If the server returns a non-200 status code.
        """
        resp = self.unix_session.get(
            f"{Constants.BaseUrl}{self.sock_path}/get", params={"key": key}
        )

        if resp.status_code != 200:
            raise Exception(f"Failed to get value for key '{key}': {resp.text}")

        print(resp.content.decode("utf-8"))
        return resp.content.decode("utf-8")

    def get_json(self, key):
        """Gets the value for key and parses it as JSON."""

        raw = self.get(key)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise Exception(f"value for key '{key}' is not valid JSON: {exc}") from exc

    def delete(self, key):
        """
        Deletes a key from the store.

        :param key: The key to delete.
        :raises Exception: If the server returns a non-200 status code.
        """
        url = f"{Constants.BaseUrl}{self.sock_path}/delete"
        response = self.unix_session.delete(url, params={"key": key})
        if response.status_code != 200:
            raise Exception(f"Failed to delete key-value pair: {response.text}")

    def clearStore(self):
        """
        Clears the entire store.

        :raises Exception: If the server returns a non-200 status code.
        """
        url = f"{Constants.BaseUrl}{self.sock_path}/clearStore"
        response = self.unix_session.delete(url)
        if response.status_code != 200:
            raise Exception(f"Failed to clear store: {response.text}")

    def batch_put(self, batch: dict):
        """
        Puts multiple key-value pairs into the store.

        :param batch: A dict of key-value pairs to store.
        :raises Exception: If the server returns a non-200 status code.
        """
        url = f"{Constants.BaseUrl}{self.sock_path}/batchPut"
        headers = {"Content-Type": "application/json"}

        response = self.unix_session.post(url, data=json.dumps(batch), headers=headers)
        if response.status_code != 200:
            raise Exception(f"Failed to batch put key-value pairs: {response.text}")

        return response.json()

    def batch_get(self, keys: list):
        """
        Gets multiple values for given keys from the store.

        :param keys: A list of keys to retrieve.
        :return: A dictionary mapping the requested keys to their retrieved values.
        :raises Exception: If the server returns a non-200 status code.
        """
        url = f"{Constants.BaseUrl}{self.sock_path}/batchGet"
        payload = {"keys": keys}
        headers = {"Content-Type": "application/json"}

        response = self.unix_session.post(
            url, data=json.dumps(payload), headers=headers
        )
        if response.status_code != 200:
            raise Exception(f"Failed to batch get keys: {response.text}")

        return response.json()

    def batch_delete(self, keys: list):
        """
        Deletes multiple keys from the store.

        :param keys: A list of keys to delete.
        :raises Exception: If the server returns a non-200 status code.
        """
        url = f"{Constants.BaseUrl}{self.sock_path}/batchDelete"
        payload = {"keys": keys}
        headers = {"Content-Type": "application/json"}

        response = self.unix_session.delete(
            url, data=json.dumps(payload), headers=headers
        )
        if response.status_code != 200:
            raise Exception(f"Failed to batch delete keys: {response.text}")

        return response.json()
