"""Tests for sca/extract.py -- wrapper-repo detection + repair."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from sca import extract


def test_no_wrappers_in_clean_repo(fake_repo: Path) -> None:
    findings = extract.detect(fake_repo.parent)
    parents = [f.parent_repo for f in findings]
    assert str(fake_repo) not in parents


def test_wrapper_pattern_is_detected(wrapper_repo: Path) -> None:
    findings = extract.detect(wrapper_repo.parent)
    assert len(findings) == 1
    f = findings[0]
    assert Path(f.parent_repo) == wrapper_repo
    assert len(f.nested_repos) == 1
    assert "inner" in f.nested_repos[0]


def test_wrapper_suggested_action_includes_keyword(wrapper_repo: Path) -> None:
    findings = extract.detect(wrapper_repo.parent)
    assert findings
    f = findings[0]
    # parent has no remote and a single tracked file -> archive-and-delete OR subtree-split
    assert any(kw in f.suggested_action.lower()
               for kw in ("archive", "subtree", "investigate"))


# ---------- repair: archive_and_delete ----------

def test_archive_and_delete_renames_dot_git(wrapper_repo: Path) -> None:
    result = extract.archive_and_delete(wrapper_repo)
    assert result["ok"] is True
    # original .git is gone
    assert not (wrapper_repo / ".git").exists()
    # but an archive directory exists
    archive = Path(result["archive_path"])
    assert archive.exists()
    assert archive.name.startswith(".git.archive-")
    # nested child repo is untouched
    assert (wrapper_repo / "inner" / ".git").exists()


def test_archive_and_delete_refuses_when_no_dot_git(tmp_path: Path) -> None:
    no_git = tmp_path / "not-a-repo"
    no_git.mkdir()
    result = extract.archive_and_delete(no_git)
    assert result["ok"] is False
    assert "no .git" in result["reason"].lower()


# ---------- repair: subtree_split ----------

def _commit_subdir(repo: Path, subdir: str, filename: str, body: str) -> None:
    """Helper: create a file inside a subdir of a repo and commit it."""
    sub = repo / subdir
    sub.mkdir(parents=True, exist_ok=True)
    (sub / filename).write_text(body, encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", f"add {subdir}/{filename}"],
                   cwd=repo, check=True, capture_output=True)


@pytest.fixture
def repo_with_subtree(tmp_path: Path) -> Path:
    """A repo whose history contains commits inside a `data/` subdir,
    suitable for `git subtree split --prefix=data`."""
    repo = tmp_path / "host"
    repo.mkdir()
    subprocess.run(["git", "init", "-b", "main"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@example.com"], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=repo, check=True, capture_output=True)
    (repo / "host-readme.md").write_text("host\n", encoding="utf-8")
    subprocess.run(["git", "add", "."], cwd=repo, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "host init"], cwd=repo, check=True, capture_output=True)
    _commit_subdir(repo, "data", "first.txt", "1\n")
    _commit_subdir(repo, "data", "second.txt", "2\n")
    return repo


def test_subtree_split_extracts_history(repo_with_subtree: Path, tmp_path: Path) -> None:
    target = tmp_path / "extracted"
    result = extract.subtree_split(repo_with_subtree, "data", target)
    assert result["ok"] is True, f"got {result}"
    assert (target / ".git").exists()
    assert (target / "first.txt").exists()
    assert (target / "second.txt").exists()
    # the extracted repo should NOT have host-only files at its root
    assert not (target / "host-readme.md").exists()
    # the extracted repo should have a `main` branch
    rc = subprocess.run(["git", "-C", str(target), "rev-parse", "main"],
                        capture_output=True, text=True)
    assert rc.returncode == 0


def test_subtree_split_refuses_into_nonempty_dir(repo_with_subtree: Path, tmp_path: Path) -> None:
    target = tmp_path / "occupied"
    target.mkdir()
    (target / "existing.txt").write_text("existing\n", encoding="utf-8")
    result = extract.subtree_split(repo_with_subtree, "data", target)
    assert result["ok"] is False
    assert "exist" in result["reason"].lower()
