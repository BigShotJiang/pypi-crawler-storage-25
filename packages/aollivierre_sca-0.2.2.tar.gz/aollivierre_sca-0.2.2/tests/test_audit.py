"""Tests for sca/audit.py -- repo discovery + classification of dirs/files."""
from __future__ import annotations

import io
import json
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from sca import audit


def _run_audit(root: Path) -> list[dict]:
    """Run audit.main() with audit.ROOT pointed at `root`; capture JSON output."""
    audit.ROOT = root.resolve()
    buf_out, buf_err = io.StringIO(), io.StringIO()
    with redirect_stdout(buf_out), redirect_stderr(buf_err):
        audit.main()
    return json.loads(buf_out.getvalue())


def test_audit_finds_a_clean_repo(fake_repo: Path) -> None:
    data = _run_audit(fake_repo.parent)
    repos = [x for x in data if x.get("type") == "repo"]
    names = [r["name"] for r in repos]
    assert fake_repo.name in names


def test_audit_classifies_empty_dir_as_non_repo(tmp_path: Path) -> None:
    (tmp_path / "empty-dir").mkdir()
    data = _run_audit(tmp_path)
    non_repos = [x for x in data if x.get("type") == "non_repo"]
    assert any(x["name"] == "empty-dir" for x in non_repos)


def test_audit_detects_loose_files_at_root(tmp_path: Path) -> None:
    (tmp_path / "stray.md").write_text("# loose\n", encoding="utf-8")
    data = _run_audit(tmp_path)
    loose = [x for x in data if x.get("type") == "loose_file"]
    assert any(x["name"] == "stray.md" for x in loose)


def test_audit_marks_clean_repo_as_ok(fake_repo: Path) -> None:
    data = _run_audit(fake_repo.parent)
    repo_entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert repo_entry["dirty"] is False
    assert repo_entry["has_remote"] is False
    # no remote -> critical NO_REMOTE gap; not OK
    assert "NO_REMOTE" in repo_entry["gaps"]


def test_audit_includes_branch_and_commit_count(fake_repo: Path) -> None:
    data = _run_audit(fake_repo.parent)
    repo_entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert repo_entry["branch"] == "main"
    assert repo_entry["commits"] == 1


def test_audit_handles_dirty_working_tree(fake_repo: Path) -> None:
    """Add an untracked file so the repo is dirty, then verify it's flagged."""
    (fake_repo / "untracked.txt").write_text("u\n", encoding="utf-8")
    data = _run_audit(fake_repo.parent)
    repo_entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert repo_entry["dirty"] is True
    assert repo_entry["untracked_files"] >= 1
    assert any(g.startswith("DIRTY_") for g in repo_entry["gaps"])


def test_audit_classifies_non_repo_parent_of_repo_as_container(
    fake_repo: Path, tmp_path: Path
) -> None:
    """A non-repo dir that holds a repo -> type=container (different from
    the wrapper-repo case where the parent itself has .git)."""
    # nest the existing fake_repo under a non-repo dir
    container_dir = tmp_path / "non_repo_holder"
    container_dir.mkdir()
    new_repo_loc = container_dir / fake_repo.name
    fake_repo.rename(new_repo_loc)

    data = _run_audit(tmp_path)
    container = next((x for x in data if x.get("name") == container_dir.name), None)
    assert container is not None
    assert container["type"] == "container"


def test_audit_classifies_outer_wrapper_as_repo(wrapper_repo: Path) -> None:
    """In contrast: when the parent has its OWN .git (wrapping nested repos),
    audit classifies it as a regular repo. The wrapper-repo *antipattern* is
    detected by sca/extract.py, not surfaced by audit."""
    data = _run_audit(wrapper_repo.parent)
    outer = next((x for x in data if x.get("name") == wrapper_repo.name), None)
    assert outer is not None
    assert outer["type"] == "repo"
