"""Tests for the archived-path severity downgrade in xor_obfuscation."""
from __future__ import annotations

from pathlib import Path

from sca.secrets import _is_archived_path, scan_repo


def test_active_path_not_archived():
    assert not _is_archived_path("src/main.py")
    assert not _is_archived_path("scripts/Install.ps1")


def test_dot_archive_top_level():
    assert _is_archived_path(".archive/old.ps1")
    assert _is_archived_path(r".archive\old.ps1")  # backslash form


def test_dot_archive_nested():
    assert _is_archived_path("src/.archive/old.py")


def test_archived_prefix():
    assert _is_archived_path("archived-test-scripts/foo.ps1")
    assert _is_archived_path("archived-2024/legacy.py")


def test_legacy_dir():
    assert _is_archived_path("legacy/old.py")
    assert _is_archived_path("deprecated/foo.ps1")


def test_legacy_prefix():
    assert _is_archived_path("legacy-2023/script.ps1")


def test_case_insensitive():
    assert _is_archived_path(".Archive/foo.ps1")
    assert _is_archived_path("ARCHIVED-old/x.py")


def _make_xor_repo(root: Path, scripts_in: dict[str, str]):
    """Build a fake repo with given path -> body, plus a decoder file."""
    import subprocess
    root.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init", "-q"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.email", "t@t.t"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=root, check=True)
    for rel, body in scripts_in.items():
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(body, encoding="utf-8")
    subprocess.run(["git", "add", "-A"], cwd=root, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=root, check=True)


_OBFUSCATED_SCRIPT = (
    '$config = @{\n'
    '    ObfuscatedTenantId = "abc123def456ghi789jkl012mno345"\n'
    '    ObfuscatedClientId = "xyz789uvw456rst123pqr890mno567"\n'
    '}\n'
)
_DECODER_SCRIPT = (
    "function ConvertTo-DecodedString { "
    "param([string]$Input) "
    "$bytes = [System.Convert]::FromBase64String($Input) "
    "for ($i=0; $i -lt $bytes.Length; $i++) { $bytes[$i] = $bytes[$i] -bxor 42 } "
    "return [System.Text.Encoding]::UTF8.GetString($bytes) }"
)


def test_xor_in_active_path_is_critical(tmp_path):
    repo = tmp_path / "active"
    _make_xor_repo(repo, {
        "src/Settings.ps1": _OBFUSCATED_SCRIPT,
        "src/Decoder.ps1": _DECODER_SCRIPT,
    })
    findings = scan_repo(repo)
    xor = [f for f in findings if f.category == "xor_obfuscation"]
    assert xor, "expected xor_obfuscation findings in active path"
    assert all(f.severity == "critical" for f in xor)


def test_xor_in_archived_path_downgrades_to_high(tmp_path):
    repo = tmp_path / "archived"
    _make_xor_repo(repo, {
        ".archive/Settings.ps1": _OBFUSCATED_SCRIPT,
        ".archive/Decoder.ps1": _DECODER_SCRIPT,
    })
    findings = scan_repo(repo)
    xor = [f for f in findings if f.category == "xor_obfuscation"]
    assert xor, "finding should still be reported, just at lower severity"
    assert all(f.severity == "high" for f in xor)
    assert all("archived/legacy path" in f.note for f in xor)


def test_xor_in_archived_test_scripts_downgrades(tmp_path):
    repo = tmp_path / "archived-tests"
    _make_xor_repo(repo, {
        "archived-test-scripts/Old.ps1": _OBFUSCATED_SCRIPT,
        "src/Decoder.ps1": _DECODER_SCRIPT,
    })
    findings = scan_repo(repo)
    xor = [f for f in findings if f.category == "xor_obfuscation"]
    # decoder is in src/, not archived; but the obfuscated finding's
    # severity is set from ITS path, not the decoder's.
    archived_findings = [f for f in xor if ".archive" in f.path or "archived-" in f.path]
    assert archived_findings
    assert all(f.severity == "high" for f in archived_findings)
