"""Render contract tests.

The renderer is data-driven: instead of pre-baking every section into the
HTML, we embed the structured data in <script type="application/json">
blocks and have client-side JS render filtering / grouping / sorting /
pagination. These tests check the *contract* of that data layer plus
the static parts of the page (tabs, top cards, banners, tables that don't
need interactivity).
"""
from __future__ import annotations

import json
import re

from sca import render


def _repo(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 10, "size_mb": 1.0, "commits": 5,
        "branch": "main", "remotes": {}, "remote_protocols": {},
        "uses_ssh": False, "status": "info", "gaps": [], "last_commit": "",
        "has_readme": True,
    }
    base.update(overrides)
    return base


def _embedded_repos(page: str) -> list[dict]:
    """Pull the repos-data JSON out of the rendered page."""
    m = re.search(
        r'<script id="repos-data" type="application/json">([^<]*)</script>',
        page, re.DOTALL)
    assert m, "repos-data script tag missing from rendered page"
    return json.loads(m.group(1))


def _embedded_plan(page: str) -> list[dict]:
    m = re.search(
        r'<script id="plan-data"\s+type="application/json">([^<]*)</script>',
        page, re.DOTALL)
    assert m, "plan-data script tag missing from rendered page"
    return json.loads(m.group(1))


# ---------- skeleton ----------

def test_render_includes_all_six_tabs() -> None:
    page = render.render([_repo()])
    for tab in ("overview", "repos", "findings", "branches", "plan", "toolchain"):
        assert f'data-tab="{tab}"' in page


def test_render_runs_without_optional_arguments() -> None:
    page = render.render([_repo()])
    assert "<html>" in page
    assert "<!DOCTYPE html>" in page


# ---------- repos data layer ----------

def test_render_embeds_protocol_for_https_remote() -> None:
    page = render.render([_repo(
        remotes={"origin": "https://github.com/o/r.git"},
        remote_protocols={"origin": "https"},
    )])
    [embed] = _embedded_repos(page)
    assert embed["remote_protocols"]["origin"] == "https"
    assert embed["uses_ssh"] is False


def test_render_embeds_protocol_for_ssh_remote() -> None:
    page = render.render([_repo(
        remotes={"origin": "git@github.com:o/r.git"},
        remote_protocols={"origin": "ssh"},
        uses_ssh=True,
        gaps=["REMOTE_USES_SSH"],
        status="warning",
    )])
    [embed] = _embedded_repos(page)
    assert embed["uses_ssh"] is True
    assert embed["remote_protocols"]["origin"] == "ssh"


def test_render_embeds_gh_match_for_no_remote_repo() -> None:
    page = render.render([_repo(
        type="repo", has_remote=False, status="critical",
        gaps=["NO_REMOTE"], remotes={}, remote_protocols={},
        gh_match={
            "name": "x", "nameWithOwner": "alice/x",
            "url": "https://github.com/alice/x",
            "visibility": "PRIVATE", "isArchived": False, "isFork": False,
        },
    )])
    [embed] = _embedded_repos(page)
    assert embed["gh_match_owner"] == "alice/x"
    assert embed["gh_match_url"] == "https://github.com/alice/x"


def test_render_embeds_branch_count_and_unpushed() -> None:
    repo = _repo(name="repo-a", ahead=2, gaps=["AHEAD_2"])
    branches_per_repo = {
        "repo-a": {
            "name": "repo-a",
            "branches": [
                {"name": "main", "on_remote": True,
                 "ahead_of_origin": 2, "behind_origin": 0, "last_commit": "abc"},
                {"name": "feature/x", "on_remote": False,
                 "last_commit": "def"},
            ],
        },
    }
    page = render.render([repo], branches_per_repo=branches_per_repo)
    [embed] = _embedded_repos(page)
    assert embed["n_branches"] == 2
    assert embed["unpushed_branches"] == 1


# ---------- risk tier classification ----------

def test_risk_tier_critical_for_leaked_secret() -> None:
    page = render.render([_repo(critical_secret_count=3)])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "critical"


def test_risk_tier_critical_for_no_remote_with_content() -> None:
    page = render.render([_repo(
        has_remote=False, gaps=["NO_REMOTE"], file_count=5, status="critical",
    )])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "critical"


def test_risk_tier_hygiene_for_missing_readme() -> None:
    page = render.render([_repo(has_readme=False)])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "hygiene"


def test_risk_tier_hygiene_for_unicode_chars() -> None:
    page = render.render([_repo(unicode_chars=42, unicode_files=3)])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "hygiene"


def test_risk_tier_cosmetic_for_ssh_only() -> None:
    page = render.render([_repo(
        uses_ssh=True,
        remotes={"origin": "git@github.com:o/r.git"},
        remote_protocols={"origin": "ssh"},
    )])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "cosmetic"


def test_risk_tier_clean_when_nothing_is_wrong() -> None:
    page = render.render([_repo(has_readme=True)])
    [embed] = _embedded_repos(page)
    assert embed["tier"] == "clean"


# ---------- overview tier cards ----------

def test_overview_renders_all_four_tier_cards() -> None:
    page = render.render([_repo()])
    for label in ("Critical", "Hygiene", "Cosmetic", "Git-clean"):
        assert f'>{label}<' in page


# ---------- branches tab ----------

def test_branches_tab_shows_drift_when_present() -> None:
    repo = _repo(name="repo-a", ahead=2, gaps=["AHEAD_2"])
    branches_per_repo = {
        "repo-a": {
            "name": "repo-a",
            "branches": [
                {"name": "main", "on_remote": True,
                 "ahead_of_origin": 2, "behind_origin": 0, "last_commit": "abc"},
                {"name": "feature/x", "on_remote": False,
                 "last_commit": "def"},
            ],
        },
    }
    page = render.render([repo], branches_per_repo=branches_per_repo)
    assert "feature/x" in page
    assert "unpushed" in page


def test_branches_tab_shows_clean_banner_when_no_drift() -> None:
    repo = _repo(name="clean", has_readme=True)
    branches_per_repo = {
        "clean": {
            "name": "clean",
            "branches": [
                {"name": "main", "on_remote": True,
                 "ahead_of_origin": 0, "behind_origin": 0, "last_commit": "x"},
            ],
        },
    }
    page = render.render([repo], branches_per_repo=branches_per_repo)
    assert "All branches in sync" in page


# ---------- toolchain section ----------

def test_toolchain_section_omitted_when_no_data() -> None:
    page = render.render([_repo()])
    assert "Toolchain looks healthy" not in page
    assert "Issues found" not in page


def test_toolchain_section_shows_health_when_no_issues() -> None:
    tc = {"git": {"installed": True, "version": "2.42.0"},
          "gh":  {"installed": True, "version": "2.40", "authenticated": True,
                  "user": "alice"},
          "credentials": {"helpers": ["manager"], "uses_os_keychain": True,
                          "uses_plaintext_store": False, "uses_manager": True},
          "issues": []}
    page = render.render([_repo()], toolchain=tc)
    assert "Toolchain looks healthy" in page


def test_toolchain_section_shows_issues_when_present() -> None:
    tc = {"git": {"installed": True, "version": "2.42.0"},
          "gh":  {"installed": True, "version": "2.40", "authenticated": False},
          "credentials": {"helpers": [], "uses_os_keychain": False,
                          "uses_plaintext_store": False, "uses_manager": False},
          "issues": ["no git credential helper configured"]}
    page = render.render([_repo()], toolchain=tc)
    assert "Issues found" in page
    assert "no git credential helper configured" in page


# ---------- plan tab ----------

def test_plan_tab_embeds_plan_data() -> None:
    plan = [{
        "name": "x", "state": "FullyCompliant", "actions": [
            {"kind": "set_remote_url", "description": "ssh -> https",
             "destructive": True, "params": {}},
            {"kind": "create_readme", "description": "stub README",
             "destructive": True, "params": {}},
        ],
    }]
    page = render.render([_repo()], plan=plan)
    embed = _embedded_plan(page)
    kinds = [p["kind"] for p in embed]
    assert "set_remote_url" in kinds
    assert "create_readme" in kinds
    assert all(p["repo"] == "x" for p in embed)


def test_plan_tab_handles_missing_plan() -> None:
    page = render.render([_repo()])
    embed = _embedded_plan(page)
    assert embed == []


# ---------- findings tab ----------

def test_findings_tab_clean_banner_when_no_findings() -> None:
    page = render.render([_repo()], secrets_per_repo={"x": []})
    assert "No findings" in page


def test_findings_tab_shows_per_repo_accordion() -> None:
    findings = {
        "leaky": [
            {"severity": "critical", "category": "github_pat",
             "path": "src/x.ps1", "line": 17,
             "excerpt": "Token = '<REDACTED>'", "note": "rotate"},
        ],
    }
    page = render.render([_repo(name="leaky")], secrets_per_repo=findings)
    # accordion present
    assert "<details" in page
    assert "<summary>" in page
    assert "github_pat" in page
    assert "src/x.ps1" in page
