"""Phase 5: Gitea match + mirror remediation."""
from __future__ import annotations

from sca import gitea, remediate
from sca.remediate import ActionKind

# ---------- pure helpers ----------

def _gitea(name: str, **kw) -> dict:
    base = {
        "name": name, "full_name": f"alice/{name}",
        "url": f"https://git.example.com/alice/{name}",
        "clone_url": f"https://git.example.com/alice/{name}.git",
        "ssh_url": f"git@git.example.com:alice/{name}.git",
        "private": True, "archived": False, "fork": False,
    }
    base.update(kw)
    return base


def test_find_match_case_insensitive() -> None:
    assert gitea.find_match("My-Repo", [_gitea("my-repo")])["name"] == "my-repo"


def test_find_match_underscore_to_hyphen() -> None:
    assert gitea.find_match("my_repo", [_gitea("my-repo")])["name"] == "my-repo"


def test_find_match_returns_none_when_empty() -> None:
    assert gitea.find_match("", [_gitea("x")]) is None
    assert gitea.find_match("x", []) is None


def test_find_match_no_match_returns_none() -> None:
    assert gitea.find_match("x", [_gitea("y")]) is None


# ---------- annotate ----------

def test_annotate_attaches_match_and_mirror_flag() -> None:
    entries = [
        {"type": "repo", "name": "my-repo", "path": "/tmp/my-repo",
         "remotes": {}},
    ]
    gitea.annotate(entries, [_gitea("my-repo")])
    assert entries[0]["gitea_match"]["name"] == "my-repo"
    # No `gitea` remote configured -> not mirrored yet
    assert entries[0]["gitea_mirrored"] is False


def test_annotate_marks_already_mirrored_by_remote_name() -> None:
    entries = [
        {"type": "repo", "name": "my-repo", "path": "/tmp/my-repo",
         "remotes": {"gitea": "https://git.example.com/alice/my-repo.git"}},
    ]
    gitea.annotate(entries, [_gitea("my-repo")])
    assert entries[0]["gitea_mirrored"] is True


def test_annotate_marks_already_mirrored_by_url_match() -> None:
    entries = [
        {"type": "repo", "name": "my-repo", "path": "/tmp/my-repo",
         "remotes": {"backup": "https://git.example.com/alice/my-repo.git"}},
    ]
    gitea.annotate(entries, [_gitea("my-repo")])
    assert entries[0]["gitea_mirrored"] is True


def test_annotate_no_op_without_gitea_repos() -> None:
    entries = [{"type": "repo", "name": "x"}]
    gitea.annotate(entries, None)
    assert "gitea_match" not in entries[0]


# ---------- planner: ENSURE_GITEA_REMOTE + MIRROR_PUSH ----------

def _entry(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "has_readme": True,
    }
    base.update(overrides)
    return base


def test_planner_schedules_gitea_remote_and_mirror_when_match_present() -> None:
    plan = remediate.plan_for_entry(_entry(gitea_match=_gitea("x")))
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.ENSURE_GITEA_REMOTE in kinds
    assert ActionKind.MIRROR_PUSH in kinds
    # Mirror push must come AFTER the remote is added
    assert kinds.index(ActionKind.ENSURE_GITEA_REMOTE) < kinds.index(ActionKind.MIRROR_PUSH)


def test_planner_no_gitea_actions_without_match() -> None:
    plan = remediate.plan_for_entry(_entry())
    assert plan is None
