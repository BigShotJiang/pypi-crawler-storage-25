"""Phase 3: toolchain audit (git/gh/credentials)."""
from __future__ import annotations

from sca import toolchain


def test_audit_returns_canonical_shape() -> None:
    data = toolchain.audit()
    assert "git" in data
    assert "gh" in data
    assert "credentials" in data
    assert "issues" in data
    assert isinstance(data["issues"], list)


def test_audit_flags_when_credential_helper_missing(monkeypatch) -> None:
    """Force the credential-helper helper to return no helpers and verify
    the issue is surfaced. Uses monkeypatching of the private helper to
    avoid relying on the real machine state."""
    monkeypatch.setattr(toolchain, "_credential_helper",
                        lambda: {"helpers": [], "uses_os_keychain": False,
                                 "uses_plaintext_store": False,
                                 "uses_manager": False})
    data = toolchain.audit()
    assert any("credential helper" in i for i in data["issues"])


def test_audit_flags_plaintext_store_helper(monkeypatch) -> None:
    monkeypatch.setattr(toolchain, "_credential_helper",
                        lambda: {"helpers": ["store"], "uses_os_keychain": False,
                                 "uses_plaintext_store": True,
                                 "uses_manager": False})
    data = toolchain.audit()
    assert any("plaintext" in i.lower() for i in data["issues"])


def test_audit_does_not_flag_when_os_keychain_in_use(monkeypatch) -> None:
    monkeypatch.setattr(toolchain, "_credential_helper",
                        lambda: {"helpers": ["manager"], "uses_os_keychain": True,
                                 "uses_plaintext_store": False,
                                 "uses_manager": True})
    data = toolchain.audit()
    # The two specific helper-related issues should be absent
    assert not any("no git credential helper" in i for i in data["issues"])
    assert not any("plaintext" in i.lower() for i in data["issues"])


def test_audit_flags_pat_in_env(monkeypatch) -> None:
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_abcdef0123456789abcdef0123456789abcd")
    data = toolchain.audit()
    assert any("GITHUB_TOKEN" in i for i in data["issues"])
