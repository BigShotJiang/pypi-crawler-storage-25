"""Tests for sca/init_workspace.py -- the end-to-end pipeline orchestrator."""
from __future__ import annotations

import json
from pathlib import Path

from sca import init_workspace


def test_pipeline_runs_against_clean_repo(fake_repo: Path, tmp_path: Path) -> None:
    """Run the full pipeline against a one-repo workspace; verify all
    expected artifacts land in the output directory."""
    out_dir = tmp_path / "run"
    init_workspace.run_pipeline(fake_repo.parent, out_dir)

    # all expected files exist
    for name in ("audit.json", "classified.json", "branches.json",
                 "remediation-plan.json", "report.html",
                 "summary.txt", "summary.json"):
        assert (out_dir / name).exists(), f"missing {name}"
    assert (out_dir / "secrets").is_dir()

    # audit found at least one repo
    audit = json.loads((out_dir / "audit.json").read_text(encoding="utf-8"))
    assert any(e.get("name") == fake_repo.name for e in audit)

    # secrets dir has a per-repo file for our fake_repo
    secrets_files = list((out_dir / "secrets").glob("*.json"))
    assert len(secrets_files) >= 1


def test_pipeline_summary_reflects_per_state_counts(
    fake_repo: Path, tmp_path: Path
) -> None:
    out_dir = tmp_path / "run"
    summary, _plans = init_workspace.run_pipeline(fake_repo.parent, out_dir)
    classify_breakdown = summary["stages"]["classify"]
    # the fake_repo has no remote -> LocalGitOnly
    assert classify_breakdown.get("LocalGitOnly", 0) >= 1


def test_pipeline_secret_scan_flags_pat_in_repo(
    repo_with_pat: Path, tmp_path: Path
) -> None:
    """A repo that contains a synthetic PAT should be reported as critical
    in the secret-scan summary."""
    out_dir = tmp_path / "run"
    summary, _plans = init_workspace.run_pipeline(repo_with_pat.parent, out_dir)
    secrets_summary = summary["stages"]["secrets"]
    assert secrets_summary["critical"] >= 1
    by_repo = secrets_summary["by_repo"]
    assert repo_with_pat.name in by_repo
    assert by_repo[repo_with_pat.name].get("critical", 0) >= 1
