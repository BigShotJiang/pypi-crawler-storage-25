"""Tests for sca/classify.py -- pure functions on audit-entry dicts."""
from __future__ import annotations

from pathlib import Path

from sca import classify
from sca.classify import RepoState, RepoStrategy


def _entry(**overrides):
    base = {
        "type": "repo",
        "name": "x",
        "path": "/tmp/x",
        "has_remote": True,
        "dirty": False,
        "ahead": 0,
        "behind": 0,
        "file_count": 10,
    }
    base.update(overrides)
    return base


def test_fully_compliant() -> None:
    assert classify.classify_state(_entry()) == RepoState.FULLY_COMPLIANT


def test_local_git_only() -> None:
    assert classify.classify_state(_entry(has_remote=False)) == RepoState.LOCAL_GIT_ONLY


def test_incomplete_takes_priority_over_partially_synced() -> None:
    assert classify.classify_state(_entry(dirty=True, ahead=3)) == RepoState.INCOMPLETE


def test_partially_synced() -> None:
    assert classify.classify_state(_entry(ahead=3)) == RepoState.PARTIALLY_SYNCED


def test_non_repo_dir_with_content() -> None:
    e = _entry(type="non_repo", file_count=5)
    assert classify.classify_state(e) == RepoState.NO_SOURCE_CONTROL


def test_non_repo_dir_empty() -> None:
    e = _entry(type="non_repo", file_count=0)
    assert classify.classify_state(e) == RepoState.EMPTY


def test_loose_file() -> None:
    e = _entry(type="loose_file", file_count=1)
    assert classify.classify_state(e) == RepoState.LOOSE_FILE


def test_container_classifies_as_container_not_wrapper() -> None:
    """A `container` entry from audit.py is a benign organisational
    directory (parent of nested repos with no outer .git). The genuine
    wrapper-repo antipattern has an outer .git too and is detected
    separately by sca/extract.py -- containers must NOT be flagged as
    WrapperRepo."""
    e = _entry(type="container")
    assert classify.classify_state(e) == RepoState.CONTAINER
    cls = classify.classify_strategy(e)
    assert cls.strategy == RepoStrategy.SKIP


def test_strategy_dedicated_for_existing_repo() -> None:
    cls = classify.classify_strategy(_entry(type="repo"))
    assert cls.strategy == RepoStrategy.DEDICATED


def test_strategy_dedicated_for_python_project(python_project: Path) -> None:
    e = _entry(type="non_repo", file_count=2,
               path=str(python_project))
    cls = classify.classify_strategy(e, python_project)
    assert cls.strategy == RepoStrategy.DEDICATED
    assert "pyproject.toml" in cls.reason


def test_strategy_consolidated_for_tiny_dir(tmp_path: Path) -> None:
    p = tmp_path / "tiny"
    p.mkdir()
    (p / "note.txt").write_text("a", encoding="utf-8")
    e = _entry(type="non_repo", file_count=1, path=str(p))
    cls = classify.classify_strategy(e, p)
    assert cls.strategy == RepoStrategy.CONSOLIDATED


def test_strategy_skip_for_empty_dir(empty_dir: Path) -> None:
    e = _entry(type="non_repo", file_count=0, path=str(empty_dir))
    cls = classify.classify_strategy(e, empty_dir)
    assert cls.strategy == RepoStrategy.SKIP


def test_classify_all_does_not_mutate_input() -> None:
    inputs = [_entry()]
    out = classify.classify_all(inputs)
    assert "classification" not in inputs[0]
    assert "classification" in out[0]
