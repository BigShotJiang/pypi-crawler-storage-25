"""Tests for sca/secrets.py -- the pattern-based committed-secret scanner."""
from __future__ import annotations

from pathlib import Path

from sca import secrets


def test_clean_repo_yields_no_findings(fake_repo: Path) -> None:
    findings = secrets.scan_repo(fake_repo)
    assert findings == []


def test_pat_in_committed_file_is_critical(repo_with_pat: Path) -> None:
    findings = secrets.scan_repo(repo_with_pat)
    crit = [f for f in findings if f.severity == "critical"]
    assert any(f.category == "github_pat" for f in crit), \
        f"expected a github_pat finding, got {[f.category for f in findings]}"
    pat_finding = next(f for f in crit if f.category == "github_pat")
    assert pat_finding.path == "leaky.ps1"
    assert "<REDACTED>" in pat_finding.excerpt
    # the live token text itself MUST NOT leak into the excerpt
    assert "github_pat_11ABCDE" not in pat_finding.excerpt


def test_xor_obfuscation_pair_is_critical(repo_with_xor_obfuscation: Path) -> None:
    findings = secrets.scan_repo(repo_with_xor_obfuscation)
    obfuscation = [f for f in findings if f.category == "xor_obfuscation"]
    assert obfuscation, \
        f"expected xor_obfuscation finding, got {[f.category for f in findings]}"
    assert all(f.severity == "critical" for f in obfuscation)
    assert any("config.psd1" in f.path for f in obfuscation)


def test_obfuscated_field_alone_is_not_flagged(fake_repo: Path) -> None:
    """If there's an Obfuscated* field but NO decoder in the repo, don't flag.
    (Could be cosmetic naming; not necessarily an XOR scheme.)"""
    cfg = fake_repo / "config.psd1"
    cfg.write_text(
        "@{ ObfuscatedTenantId = 'aGVsbG93b3JsZGZha2V0ZW5hbnRpZA==' }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(["git", "add", ".", "&&", "git", "commit", "-m", "x"],
                   cwd=fake_repo, shell=True, capture_output=True)
    # NB: pair-detection requires BOTH halves; missing decoder => no critical
    findings = secrets.scan_repo(fake_repo)
    assert all(f.category != "xor_obfuscation" for f in findings)


def test_function_call_rhs_is_not_flagged(fake_repo: Path) -> None:
    """ObfuscatedX = ConvertTo-ObfuscatedString -InputString $TenantId
    is a function call -- the value isn't IN the line. Don't flag."""
    cfg = fake_repo / "code.ps1"
    cfg.write_text(
        "$config = @{\n"
        "  ObfuscatedTenantId = ConvertTo-ObfuscatedString -InputString $TenantId\n"
        "  ObfuscatedClientId = $env:CLIENT_ID\n"
        "}\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "code"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    assert all(f.category != "xor_obfuscation" for f in findings), \
        f"function-call RHS should not be flagged: {[(f.path, f.line) for f in findings]}"


def test_markdown_obfuscated_examples_are_not_flagged(fake_repo: Path) -> None:
    """Documentation files with Obfuscated* field NAMES as examples shouldn't
    flag -- they're not recoverable secrets, just illustrative text."""
    doc = fake_repo / "docs" / "extraction-plan.md"
    doc.parent.mkdir()
    doc.write_text(
        "## Example obfuscated config\n\n"
        "```\n"
        "ObfuscatedTenantId = 'aGVsbG93b3JsZGZha2V0ZW5hbnRpZA=='\n"
        "```\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "docs"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    assert all(f.category != "xor_obfuscation" for f in findings), \
        f".md files should not flag xor obfuscation: " \
        f"{[(f.path, f.line) for f in findings]}"


def test_powershell_interpolation_value_is_not_flagged(fake_repo: Path) -> None:
    """ObfuscatedX = '$($config.X)' is a PowerShell expandable string -- the
    quotes are around a variable interpolation, not a literal value."""
    cfg = fake_repo / "code.ps1"
    cfg.write_text(
        "$opObfuscatedConfig = @{ ObfuscatedTenantId = 'abcd...real' }\n"
        "$exportConfig = @{\n"
        "    ObfuscatedTenantId = '$($opObfuscatedConfig.ObfuscatedTenantId)'\n"
        "    ObfuscatedClientId = '$($opObfuscatedConfig.ObfuscatedClientId)'\n"
        "}\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "code"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    obfuscated = [f for f in findings if f.category == "xor_obfuscation"]
    # The interpolation lines should be skipped; only the real top-line value
    # 'abcd...real' would flag, but 'abcd...real' contains '...' which the
    # harvest filters... but here we go via scan_repo so there's no harvest
    # filter. Use line numbers: lines 3 and 4 in our fixture are the
    # interpolation ones, so neither should appear in the obfuscated set.
    assert not any(f.line in (3, 4) for f in obfuscated), \
        f"interpolation lines should not flag: {[(f.line, f.excerpt) for f in obfuscated]}"


def test_commented_out_line_is_not_flagged(fake_repo: Path) -> None:
    """Lines starting with `#` are PowerShell / Python comments; their
    Obfuscated* references aren't real assignments."""
    cfg = fake_repo / "code.ps1"
    cfg.write_text(
        "$config = @{\n"
        "    ObfuscatedTenantId = 'aGVsbG93b3JsZGZha2V0ZW5hbnRpZA=='\n"
        "}\n"
        "# Example layout below:\n"
        "#     ObfuscatedTenantId = 'paste_encrypted_value_here'\n"
        "#     ObfuscatedClientId = 'paste_encrypted_value_here'\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "code"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    obfuscated = [f for f in findings if f.category == "xor_obfuscation"]
    # Line 2 is the real value; line 5 and 6 are commented placeholders.
    assert any(f.line == 2 for f in obfuscated), \
        "real value on line 2 should still flag"
    assert not any(f.line in (5, 6) for f in obfuscated), \
        f"commented lines should not flag: {[(f.line, f.excerpt) for f in obfuscated]}"


def test_regex_replace_lines_are_not_flagged(fake_repo: Path) -> None:
    """A PowerShell -replace pattern that happens to contain `Obfuscated*`
    text is a regex search pattern, not an assignment. Don't flag."""
    cfg = fake_repo / "fix-config.ps1"
    cfg.write_text(
        # PowerShell -replace pattern (search-and-replace operator)
        '$content = $content -replace "ObfuscatedDriveId = ' + chr(39)
        + "[^" + chr(39) + "]*" + chr(39) + '", "ObfuscatedDriveId = '
        + chr(39) + "$obfuscatedDriveId" + chr(39) + '"\n'
        # [Regex]::Replace static call
        '$content = [Regex]::Replace($content,'
        ' \'ObfuscatedListId = "[^"]+"\', "ObfuscatedListId = \\"$x\\"")\n'
        # PowerShell -match operator (used for detection)
        "if ($line -match 'ObfuscatedTenantId = ''aWlsPjg') {\n"
        "    Write-Output 'found'\n"
        "}\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "regex"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    assert all(f.category != "xor_obfuscation" for f in findings), \
        f"regex/replace lines should not flag: " \
        f"{[(f.path, f.line, f.excerpt) for f in findings]}"


def test_redacted_placeholder_is_not_flagged(fake_repo: Path) -> None:
    """Regression: after `sca redact --apply`, the working tree contains
    `Obfuscated* = '<REDACTED>'`. The xor scanner must recognise this as a
    placeholder and NOT flag it -- otherwise the audit double-counts every
    redaction we just did."""
    cfg = fake_repo / "config.psd1"
    cfg.write_text(
        "@{\n"
        "  ObfuscatedTenantId = '<REDACTED>'\n"
        "  ObfuscatedClientId = '<REDACTED>'\n"
        "}\n",
        encoding="utf-8",
    )
    decoder = fake_repo / "Get-DecryptedValue.ps1"
    decoder.write_text(
        "function Get-DecryptedValue { param($v) ($v -bxor 0x5A) }\n",
        encoding="utf-8",
    )
    import subprocess
    subprocess.run(("git", "add", "."), cwd=fake_repo, check=True,
                   capture_output=True)
    subprocess.run(("git", "commit", "-m", "redacted"), cwd=fake_repo,
                   check=True, capture_output=True)
    findings = secrets.scan_repo(fake_repo)
    assert all(f.category != "xor_obfuscation" for f in findings), \
        f"<REDACTED> values should not be flagged: {[(f.path, f.line, f.category) for f in findings]}"


def test_severity_exit_codes() -> None:
    """Critical findings exit 2; high findings exit 1; clean exits 0."""
    # exercised by integration tests against fixtures, but verify the contract
    # at least exists in the module
    assert hasattr(secrets, "main")


# ---------- new patterns: JWT, OAuth refresh, prefix-tolerant secret keys ----------

def _commit_file(repo: Path, name: str, body: str) -> None:
    """Helper: write a file and commit it to the fake_repo."""
    import subprocess
    (repo / name).write_text(body, encoding="utf-8")
    subprocess.run(("git", "add", name), cwd=repo, check=True, capture_output=True)
    subprocess.run(("git", "commit", "-m", "x"), cwd=repo, check=True, capture_output=True)


def test_jwt_access_token_is_critical(fake_repo: Path) -> None:
    """Three-segment base64url JWTs (header.payload.sig, both header and
    payload start with `eyJ`) should be flagged as live tokens."""
    # Synthetic JWT - shape only, no real claims
    jwt = (
        "eyJ" + "A" * 30 + "."
        + "eyJ" + "B" * 30 + "."
        + "C" * 30
    )
    _commit_file(fake_repo, "leaky.ps1", f'$AccessToken = "{jwt}"\n')
    findings = secrets.scan_repo(fake_repo)
    crit = [f for f in findings if f.category == "jwt_access_token"]
    assert crit, f"expected jwt_access_token finding, got {[f.category for f in findings]}"
    assert all(f.severity == "critical" for f in crit)
    # the live token text itself MUST NOT leak into the excerpt
    assert jwt not in crit[0].excerpt


def test_oauth_refresh_token_is_critical(fake_repo: Path) -> None:
    """Microsoft Identity refresh tokens (`0.<base64>.A<long base64>`) flag as live."""
    rt = "0." + "A" * 30 + ".A" + "B" * 220
    _commit_file(fake_repo, "leaky.ps1", f'$refreshToken = "{rt}"\n')
    findings = secrets.scan_repo(fake_repo)
    crit = [f for f in findings if f.category == "oauth_refresh_token"]
    assert crit, f"expected oauth_refresh_token, got {[f.category for f in findings]}"
    assert all(f.severity == "critical" for f in crit)
    assert rt not in crit[0].excerpt


def test_clientsecret_assignment_is_flagged(fake_repo: Path) -> None:
    """`'ClientSecret' = '...'` should match password_assignment despite the
    `Client` prefix that broke the old `\\b(secret|...)` rule."""
    body = (
        "@{\n"
        "  'ClientSecret' = 'aBcDeFgHiJkLmNoP_realsecret'\n"
        "  'TenantId'     = '00000000-0000-0000-0000-000000000001'\n"
        "}\n"
    )
    _commit_file(fake_repo, "config.psd1", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert pwd, f"expected password_assignment finding for ClientSecret, got {[f.category for f in findings]}"


def test_refreshtoken_and_accesstoken_assignment_are_flagged(fake_repo: Path) -> None:
    """Same prefix-tolerance: $RefreshToken = '...' and $AccessToken = '...'
    should match without requiring the prior `\\b` boundary."""
    body = (
        "$RefreshToken = 'someRealRefreshTokenValue123'\n"
        "$AccessToken  = 'someRealAccessTokenValue456'\n"
    )
    _commit_file(fake_repo, "auth.ps1", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    # We expect 2 hits (one per variable assignment).
    assert len(pwd) >= 2, \
        f"expected at least 2 password_assignment findings, got {len(pwd)}: {pwd}"


def test_secret_parameter_form_is_flagged(fake_repo: Path) -> None:
    """PowerShell parameter form: `-Secret 'value'` / `-ClientSecret '...'`
    has no `=` between key and value; should still be detected via
    SECRET_PARAMETER_PATTERN."""
    body = (
        "Connect-Service -ClientID 'app1' -Secret 'realSecretValue123' -TenantId 'tenant1'\n"
        "Invoke-Auth -ClientSecret 'anotherRealSecretValue456'\n"
    )
    _commit_file(fake_repo, "auth.ps1", body)
    findings = secrets.scan_repo(fake_repo)
    params = [f for f in findings if f.category == "secret_parameter"]
    assert len(params) >= 2, \
        f"expected at least 2 secret_parameter findings, got {len(params)}: " \
        f"{[(f.path, f.line, f.category) for f in findings]}"


def test_redacted_marker_is_skipped(fake_repo: Path) -> None:
    """After a redact pass, lines like `$Token = "<REDACTED>"` should NOT
    be re-flagged as secret findings -- they're audit noise."""
    body = (
        '$Token = "<REDACTED>"\n'
        '$Secret = "<REDACTED-JWT>"\n'
        '$RefreshToken = "<REDACTED-REFRESH-TOKEN>"\n'
        # Real secret on this line should still flag (sanity check)
        '$ClientSecret = "actuallyARealSecretValue123"\n'
    )
    _commit_file(fake_repo, "auth.ps1", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    # Only the line-4 real secret should flag; the 3 <REDACTED> lines should not.
    assert len(pwd) == 1, \
        f"expected exactly 1 password_assignment finding (the real one), got {len(pwd)}: " \
        f"{[(f.line, f.excerpt) for f in pwd]}"
    assert pwd[0].line == 4


def test_secret_substring_does_not_overmatch(fake_repo: Path) -> None:
    """`secretSize`, `tokenizer`, `passwordless` etc. should NOT be flagged
    because of the negative lookahead on identifier chars."""
    body = (
        "$secretSize = 32\n"             # not a secret value
        "$tokenizer = New-Tokenizer\n"  # not a secret
        '$passwordless_login = "true"\n'  # not a secret
    )
    _commit_file(fake_repo, "code.ps1", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    # The `=` in `secretSize = 32` does NOT have a quoted value - safe by
    # the regex tail. But verify no false positive on the words themselves.
    assert all("secretSize" not in f.excerpt for f in pwd), \
        f"secretSize should not match: {[(f.line, f.excerpt) for f in pwd]}"


# ---------- UPPER_SNAKE prefix support ----------
#
# Real-world finding from a workspace audit: Python config files commonly
# use AZURE_CLIENT_SECRET / JWT_SECRET / DB_PASSWORD / GITHUB_TOKEN /
# OPENAI_API_KEY etc. The earlier `(?<![A-Za-z0-9_])` boundary treated
# the underscore between AZURE and CLIENT as part of one big identifier,
# so the secret keyword inside silently never matched. GitHub's own
# secret scanner caught what we missed at push time.

def test_upper_snake_prefix_with_secret(fake_repo: Path) -> None:
    """AZURE_CLIENT_SECRET / JWT_SECRET / SECRET_KEY all flag."""
    body = "\n".join([
        'AZURE_CLIENT_SECRET = "realsecretvalueAAA"',
        'JWT_SECRET          = "realsecretvalueBBB"',
        'SECRET_KEY          = "realsecretvalueCCC"',
    ]) + "\n"
    _commit_file(fake_repo, "config.py", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert len(pwd) >= 3, \
        f"expected at least 3 findings, got {len(pwd)}: " \
        f"{[(f.line, f.excerpt) for f in pwd]}"


def test_upper_snake_prefix_with_token(fake_repo: Path) -> None:
    """OAUTH_TOKEN / BEARER_TOKEN / GITHUB_TOKEN / AUTH_TOKEN all flag."""
    body = "\n".join([
        'OAUTH_TOKEN  = "realtokenvalueAAA"',
        'BEARER_TOKEN = "realtokenvalueBBB"',
        'GITHUB_TOKEN = "realtokenvalueCCC"',
        'AUTH_TOKEN   = "realtokenvalueDDD"',
    ]) + "\n"
    _commit_file(fake_repo, "config.py", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert len(pwd) >= 4


def test_upper_snake_prefix_with_password(fake_repo: Path) -> None:
    """DB_PASSWORD / ADMIN_PASSWORD / EMAIL_PASSWORD all flag."""
    body = "\n".join([
        'DB_PASSWORD    = "realpasswordvalueAAA"',
        'ADMIN_PASSWORD = "realpasswordvalueBBB"',
        'EMAIL_PASSWORD = "realpasswordvalueCCC"',
    ]) + "\n"
    _commit_file(fake_repo, "config.py", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert len(pwd) >= 3


def test_upper_snake_prefix_with_api_key(fake_repo: Path) -> None:
    """OPENAI_API_KEY / SLACK_API_KEY / GITHUB_API_KEY all flag."""
    body = "\n".join([
        'OPENAI_API_KEY = "sk-realapikeyvalueAAA"',
        'SLACK_API_KEY  = "xoxb-realapikeyvalueBBB"',
        'GITHUB_API_KEY = "realapikeyvalueCCC"',
    ]) + "\n"
    _commit_file(fake_repo, "config.py", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert len(pwd) >= 3


def test_upper_snake_does_not_overmatch(fake_repo: Path) -> None:
    """Names like SECRET_BUFFER_SIZE (assigned to int), SECRET_PATH /
    PUBLIC_KEY_FILE (assigned to filenames), TOKEN_TYPE = "Bearer", etc.
    should NOT trip the password-assignment finder."""
    body = "\n".join([
        'SECRET_BUFFER_SIZE = 32',
        'SECRET_PATH        = "/etc/secrets/x"',
        'PUBLIC_KEY_FILE    = "a.pem"',
        'TOKEN_TYPE         = "Bearer"',
        'PASSWORD_FIELD     = "name"',
    ]) + "\n"
    _commit_file(fake_repo, "config.py", body)
    findings = secrets.scan_repo(fake_repo)
    pwd = [f for f in findings if f.category == "password_assignment"]
    assert len(pwd) == 0, \
        f"unexpected matches: {[(f.line, f.excerpt) for f in pwd]}"


def test_powershell_param_with_upper_snake_prefix(fake_repo: Path) -> None:
    """PowerShell parameter form with snake-case prefix: -AZURE_CLIENT_SECRET
    'value' / -OPENAI_API_KEY 'value'."""
    body = (
        "Connect-Service -CLIENT_ID 'app1' "
        "-AZURE_CLIENT_SECRET 'realsecretvalueAAA' "
        "-TENANT_ID 'tenant1'\n"
        "Invoke-OpenAI -OPENAI_API_KEY 'sk-realapikeyvalueBBB'\n"
    )
    _commit_file(fake_repo, "auth.ps1", body)
    findings = secrets.scan_repo(fake_repo)
    params = [f for f in findings if f.category == "secret_parameter"]
    assert len(params) >= 2, \
        f"expected at least 2 secret_parameter findings, got {len(params)}: " \
        f"{[(f.line, f.excerpt) for f in params]}"
