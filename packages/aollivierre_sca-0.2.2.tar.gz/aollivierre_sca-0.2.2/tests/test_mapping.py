"""Tests for sca/mapping.py -- match local folders to existing GitHub repos."""
from __future__ import annotations

from sca import mapping, remediate
from sca.remediate import ActionKind

# ---------- pure helpers ----------

def test_normalize_name_lowercases_and_collapses_separators() -> None:
    assert mapping.normalize_name("My_Repo") == "my-repo"
    assert mapping.normalize_name("MY-REPO") == "my-repo"
    assert mapping.normalize_name("my repo") == "my-repo"
    assert mapping.normalize_name("") == ""


def _gh(name: str, **kw) -> dict:
    base = {
        "name": name,
        "nameWithOwner": f"alice/{name}",
        "url": f"https://github.com/alice/{name}",
        "sshUrl": f"git@github.com:alice/{name}.git",
        "visibility": "PRIVATE",
        "isArchived": False,
        "isFork": False,
    }
    base.update(kw)
    return base


def test_find_matches_exact_first() -> None:
    repos = [_gh("Other"), _gh("my-repo"), _gh("my-repo-old")]
    out = mapping.find_matches("my-repo", repos)
    assert out and out[0]["name"] == "my-repo"


def test_find_matches_case_insensitive() -> None:
    repos = [_gh("MY-REPO")]
    out = mapping.find_matches("my-repo", repos)
    assert out and out[0]["name"] == "MY-REPO"


def test_find_matches_underscore_to_hyphen() -> None:
    repos = [_gh("my-repo")]
    out = mapping.find_matches("my_repo", repos)
    assert out and out[0]["name"] == "my-repo"


def test_find_matches_prefers_non_archived() -> None:
    archived = _gh("my-repo", isArchived=True)
    active = _gh("my-repo", nameWithOwner="alice/my-repo")
    out = mapping.find_matches("my-repo", [archived, active])
    # Archived is penalised, so the active one should rank first
    assert out[0]["isArchived"] is False
    assert out[1]["isArchived"] is True


def test_find_matches_returns_empty_when_no_match() -> None:
    repos = [_gh("alpha"), _gh("beta")]
    assert mapping.find_matches("gamma", repos) == []


def test_find_matches_handles_empty_inputs() -> None:
    assert mapping.find_matches("", []) == []
    assert mapping.find_matches("name", []) == []
    assert mapping.find_matches("", [_gh("name")]) == []


# ---------- annotate ----------

def test_annotate_skips_entries_with_remote() -> None:
    entries = [
        {"type": "repo", "name": "with-remote", "has_remote": True},
    ]
    mapping.annotate(entries, [_gh("with-remote")])
    assert "gh_match" not in entries[0]


def test_annotate_skips_empty_non_repos() -> None:
    entries = [
        {"type": "non_repo", "name": "empty-dir", "file_count": 0},
    ]
    mapping.annotate(entries, [_gh("empty-dir")])
    assert "gh_match" not in entries[0]


def test_annotate_attaches_match_for_no_remote_repo() -> None:
    entries = [
        {"type": "repo", "name": "my-repo", "has_remote": False, "path": "/c/code/my-repo"},
    ]
    mapping.annotate(entries, [_gh("my-repo")])
    assert entries[0]["gh_match"]["nameWithOwner"] == "alice/my-repo"


def test_annotate_uses_leaf_when_name_is_relative_path() -> None:
    entries = [
        {"type": "non_repo", "name": "subdir/my-repo", "file_count": 5,
         "has_remote": False, "path": "/c/code/subdir/my-repo"},
    ]
    mapping.annotate(entries, [_gh("my-repo")])
    assert entries[0]["gh_match"]["name"] == "my-repo"


def test_annotate_no_op_when_remote_repos_is_none() -> None:
    entries = [{"type": "repo", "name": "x", "has_remote": False}]
    mapping.annotate(entries, None)
    assert "gh_match" not in entries[0]


# ---------- planner uses gh_match instead of CREATE ----------

def _entry_no_remote_with_files(**overrides) -> dict:
    base = {
        "type": "non_repo", "name": "my-repo", "path": "/tmp/my-repo",
        "has_remote": False, "file_count": 5, "dirty": False,
        "ahead": 0, "behind": 0,
    }
    base.update(overrides)
    return base


def test_planner_maps_to_existing_repo_when_match_present() -> None:
    entry = _entry_no_remote_with_files(gh_match=_gh("my-repo"))
    plan = remediate.plan_for_entry(entry)
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.MAP_TO_REMOTE in kinds
    assert ActionKind.CREATE_GH_REPO not in kinds
    map_action = next(a for a in plan.actions if a.kind == ActionKind.MAP_TO_REMOTE)
    assert map_action.params["url"] == "https://github.com/alice/my-repo.git"


def test_planner_creates_new_repo_when_no_match() -> None:
    entry = _entry_no_remote_with_files()
    plan = remediate.plan_for_entry(entry)
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.CREATE_GH_REPO in kinds
    assert ActionKind.MAP_TO_REMOTE not in kinds


def test_planner_local_git_only_uses_map_when_match_present() -> None:
    entry = {
        "type": "repo", "name": "my-repo", "path": "/tmp/my-repo",
        "has_remote": False, "file_count": 5, "dirty": False,
        "ahead": 0, "behind": 0,
        "gh_match": _gh("my-repo"),
    }
    plan = remediate.plan_for_entry(entry)
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.MAP_TO_REMOTE in kinds
    assert ActionKind.CREATE_GH_REPO not in kinds
    # Pre-publish secret scan still runs
    assert ActionKind.SCAN_SECRETS in kinds
    assert kinds.index(ActionKind.SCAN_SECRETS) < kinds.index(ActionKind.MAP_TO_REMOTE)
