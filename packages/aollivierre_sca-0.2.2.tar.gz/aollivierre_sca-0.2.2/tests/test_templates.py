"""Tests for sca/templates.py -- stack detection and gitignore rendering."""
from __future__ import annotations

from pathlib import Path

from sca import templates


def test_python_project_detection(python_project: Path) -> None:
    stacks = templates.detect(python_project)
    assert "python" in stacks


def test_empty_dir_detects_nothing(empty_dir: Path) -> None:
    empty_dir.mkdir()
    assert templates.detect(empty_dir) == []


def test_render_includes_common_section() -> None:
    out = templates.render([])
    assert "# OS" in out
    assert ".env" in out


def test_render_includes_named_stack() -> None:
    out = templates.render(["python"])
    assert "__pycache__" in out
    assert ".venv" in out


def test_write_creates_gitignore(python_project: Path) -> None:
    target = templates.write(python_project)
    assert target == python_project / ".gitignore"
    assert target.exists()
    body = target.read_text(encoding="utf-8")
    assert "__pycache__" in body  # python section


def test_write_refuses_existing_without_overwrite(python_project: Path) -> None:
    (python_project / ".gitignore").write_text("# existing\n", encoding="utf-8")
    import pytest
    with pytest.raises(FileExistsError):
        templates.write(python_project)


def test_write_with_overwrite(python_project: Path) -> None:
    (python_project / ".gitignore").write_text("# existing\n", encoding="utf-8")
    target = templates.write(python_project, overwrite=True)
    assert "__pycache__" in target.read_text(encoding="utf-8")
