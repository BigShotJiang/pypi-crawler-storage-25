"""Tests for sca/push_branches.py -- batch branch pusher.

Push operations are exercised in dry-run mode against fixture repos so
nothing real gets pushed. The actual `git push` path is covered by the
visibility-gate tests.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from sca import push_branches


def _git(*cmd: str, cwd: Path) -> None:
    subprocess.run(("git",) + cmd, cwd=cwd, check=True, capture_output=True, text=True)


@pytest.fixture
def repo_with_unpushed_branch(fake_repo: Path) -> Path:
    """A repo with `main` + a `feature/x` branch that's local-only."""
    _git("checkout", "-b", "feature/x", cwd=fake_repo)
    (fake_repo / "f.txt").write_text("f\n", encoding="utf-8")
    _git("add", "f.txt", cwd=fake_repo)
    _git("commit", "-m", "feat", cwd=fake_repo)
    _git("checkout", "main", cwd=fake_repo)
    return fake_repo


def test_dry_run_finds_branches_needing_push(
    repo_with_unpushed_branch: Path,
) -> None:
    """Dry-run should report `would-push` for branches without a remote."""
    results = push_branches.push_branches_in_repo(
        repo_with_unpushed_branch, apply=False
    )
    actions = [r.action for r in results]
    branches_seen = [r.branch for r in results]
    # No remote -> both branches would push
    assert "would-push" in actions
    assert "main" in branches_seen
    assert "feature/x" in branches_seen


def test_clean_repo_yields_no_actions(fake_repo: Path) -> None:
    """A repo with no remote and no extra branches -> only main needs push.
    But if we filter for branches actually needing action, fake_repo with
    just `main` (no remote) reports `main: not on remote / would-push`."""
    results = push_branches.push_branches_in_repo(fake_repo, apply=False)
    # fake_repo has main + no remote -> main wants pushing
    assert any(r.branch == "main" and r.action == "would-push" for r in results)


def test_push_blocked_by_visibility_gate(
    repo_with_pat: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the visibility gate refuses (e.g. critical secret in a public
    repo), every branch is reported `blocked` instead of `would-push`."""
    # Add a fake origin pointing at a github URL the gate will treat as public.
    _git("remote", "add", "origin", "git@github.com:owner/repo.git", cwd=repo_with_pat)

    # Mock the gate to refuse (simulating "public + critical secrets").
    monkeypatch.setattr(
        push_branches._remediate, "_visibility_gate",
        lambda repo_path, *, offline=False: (False, "REFUSED: test"),
    )
    results = push_branches.push_branches_in_repo(repo_with_pat, apply=False)
    assert results, "expected at least one result"
    assert all(r.action == "blocked" for r in results)
    assert all("REFUSED" in r.reason for r in results)


def test_walk_finds_repos_under_root(
    repo_with_unpushed_branch: Path, tmp_path: Path,
) -> None:
    """push_branches_in_root walks the tree and finds all repos."""
    # `repo_with_unpushed_branch` is at <tmp>/repo
    # Create a sibling that's not a repo
    (tmp_path / "not_a_repo").mkdir()

    results = push_branches.push_branches_in_root(tmp_path, apply=False)
    # all results should come from `repo` (the only git dir)
    assert results
    assert all(r.repo == repo_with_unpushed_branch.name for r in results)


def test_diverged_branch_is_skipped(repo_with_unpushed_branch: Path) -> None:
    """If a branch is both ahead and behind origin, it shouldn't be pushed --
    that needs human merge/rebase. Dry-run shouldn't report it."""
    # Set up a fake remote (use the working tree itself as the remote)
    bare = repo_with_unpushed_branch.parent / "bare-mirror.git"
    subprocess.run(["git", "init", "--bare", str(bare)], check=True, capture_output=True)
    _git("remote", "add", "origin", str(bare), cwd=repo_with_unpushed_branch)
    _git("push", "-u", "origin", "main", cwd=repo_with_unpushed_branch)
    _git("push", "-u", "origin", "feature/x", cwd=repo_with_unpushed_branch)

    # Now diverge feature/x: a new local commit + a new remote commit
    _git("checkout", "feature/x", cwd=repo_with_unpushed_branch)
    (repo_with_unpushed_branch / "local.txt").write_text("L", encoding="utf-8")
    _git("add", "local.txt", cwd=repo_with_unpushed_branch)
    _git("commit", "-m", "local", cwd=repo_with_unpushed_branch)
    # Pretend remote got a different commit by pushing a new commit from a
    # different branch onto remote/feature/x. We'll simulate with a force.
    # Easiest: clone bare, commit + push, leave local diverged.
    work = repo_with_unpushed_branch.parent / "remote-side"
    subprocess.run(["git", "clone", str(bare), str(work)], check=True, capture_output=True)
    _git("checkout", "feature/x", cwd=work)
    (work / "remote-only.txt").write_text("R", encoding="utf-8")
    _git("add", "remote-only.txt", cwd=work)
    _git("commit", "-m", "remote", cwd=work)
    _git("push", "origin", "feature/x", cwd=work)

    # Refresh remote tracking ref in our test repo
    _git("fetch", "origin", cwd=repo_with_unpushed_branch)

    results = push_branches.push_branches_in_repo(
        repo_with_unpushed_branch, apply=False,
    )
    feature_results = [r for r in results if r.branch == "feature/x"]
    # diverged -> SKIPPED entirely (not in candidates list)
    assert feature_results == [], \
        f"diverged branch should not appear; got {feature_results}"
