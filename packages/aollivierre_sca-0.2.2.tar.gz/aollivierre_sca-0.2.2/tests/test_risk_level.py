"""Tests for the risk_level field on remediation actions."""
from __future__ import annotations

import json
import re

from sca import remediate, render
from sca.remediate import Action, ActionKind, RiskLevel

# ---------- Action: risk_level is auto-derived from kind ----------

def test_action_risk_level_auto_set_for_create_readme() -> None:
    a = Action(ActionKind.CREATE_README, "stub", destructive=True,
               params={"repo": "/x", "name": "x"})
    assert a.risk_level == RiskLevel.WRITES_FILE


def test_action_risk_level_auto_set_for_push() -> None:
    a = Action(ActionKind.PUSH, "push", destructive=True,
               params={"repo": "/x"})
    assert a.risk_level == RiskLevel.PUBLISH


def test_action_risk_level_auto_set_for_create_github_repo() -> None:
    a = Action(ActionKind.CREATE_GH_REPO, "create", destructive=True,
               params={"repo": "/x", "name": "x", "visibility": "private"})
    assert a.risk_level == RiskLevel.PUBLISH


def test_action_risk_level_auto_set_for_redact_secrets() -> None:
    a = Action(ActionKind.REDACT_SECRETS, "redact", destructive=True,
               params={"repo": "/x"})
    assert a.risk_level == RiskLevel.REWRITES_FILES


def test_action_risk_level_auto_set_for_init_repo() -> None:
    a = Action(ActionKind.INIT_REPO, "init", destructive=True,
               params={"repo": "/x"})
    assert a.risk_level == RiskLevel.GIT_STATE


def test_action_risk_level_auto_set_for_note() -> None:
    a = Action(ActionKind.NOTE, "just a note")
    assert a.risk_level == RiskLevel.NONE


def test_action_risk_level_explicit_override() -> None:
    a = Action(ActionKind.PUSH, "push", destructive=True,
               params={"repo": "/x"}, risk_level=RiskLevel.NONE)
    assert a.risk_level == RiskLevel.NONE


# ---------- asdict serialises risk_level as a string ----------

def test_action_asdict_serialises_risk_level() -> None:
    a = Action(ActionKind.PUSH, "push", destructive=True,
               params={"repo": "/x"})
    d = a.asdict()
    assert d["risk_level"] == "publish"
    assert d["kind"] == "push"


# ---------- Plan tab embed surfaces risk_level ----------

def _embed_plan(page: str) -> list[dict]:
    m = re.search(
        r'<script id="plan-data"\s+type="application/json">([^<]*)</script>',
        page, re.DOTALL)
    assert m, "plan-data script tag missing"
    return json.loads(m.group(1))


def _repo(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "size_mb": 1.0, "commits": 1,
        "branch": "main", "remotes": {}, "remote_protocols": {},
        "uses_ssh": False, "status": "info", "gaps": [], "last_commit": "",
        "has_readme": True,
    }
    base.update(overrides)
    return base


def test_render_plan_embeds_risk_level_for_each_action() -> None:
    plan = [{
        "name": "x", "state": "FullyCompliant", "actions": [
            Action(ActionKind.CREATE_README, "stub",
                   destructive=True, params={}).asdict(),
            Action(ActionKind.PUSH, "push",
                   destructive=True, params={}).asdict(),
            Action(ActionKind.SCAN_SECRETS, "scan",
                   destructive=False, params={}).asdict(),
        ],
    }]
    page = render.render([_repo()], plan=plan)
    embed = _embed_plan(page)
    by_kind = {p["kind"]: p for p in embed}
    assert by_kind["create_readme"]["risk_level"] == "writes_file"
    assert by_kind["push"]["risk_level"] == "publish"
    assert by_kind["scan_secrets"]["risk_level"] == "none"


def test_render_plan_includes_risk_filter_chips() -> None:
    page = render.render([_repo()])
    for risk in ("none", "writes_file", "rewrites_files", "git_state", "publish"):
        assert f'data-pfilter="risk:{risk}"' in page


# ---------- planner emits the right risk levels end-to-end ----------

def test_planner_emits_publish_for_no_remote_with_content() -> None:
    """A NoSourceControl-with-content repo should produce a plan that
    eventually pushes; the push action must be tagged 'publish'."""
    entry = {
        "type": "non_repo", "name": "new-thing", "path": "/tmp/new",
        "has_remote": False, "file_count": 5,
    }
    plan = remediate.plan_for_entry(entry)
    assert plan is not None
    push_actions = [a for a in plan.actions if a.kind == ActionKind.PUSH]
    assert push_actions
    assert all(a.risk_level == RiskLevel.PUBLISH for a in push_actions)


def test_planner_emits_writes_file_for_create_readme() -> None:
    """Compliant repo with no README should plan a CREATE_README at writes_file."""
    entry = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "has_readme": False,
    }
    plan = remediate.plan_for_entry(entry)
    assert plan is not None
    readme_actions = [a for a in plan.actions if a.kind == ActionKind.CREATE_README]
    assert readme_actions
    assert all(a.risk_level == RiskLevel.WRITES_FILE for a in readme_actions)
