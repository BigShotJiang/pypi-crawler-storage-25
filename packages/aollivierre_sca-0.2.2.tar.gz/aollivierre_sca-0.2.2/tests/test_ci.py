"""Tests for sca/ci.py -- baseline workflow audit + template content.

These tests pin the shape of the two baseline workflow templates so a
regression to the previous-broken state (cross-repo checkout + scanner
self-scan) is caught at PR time. The actual YAML files written into
consumer repos are generated from the strings tested here.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from sca import ci

# ---------- audit_repo (existing surface) ----------

def test_audit_no_workflows_dir(tmp_path: Path) -> None:
    """A repo with no .github/workflows/ should miss every baseline."""
    result = ci.audit_repo(tmp_path)
    assert set(result.missing_workflows) == set(ci.BASELINE_WORKFLOWS.keys())
    assert result.present_workflows == []


def test_audit_detects_unicode_check_by_keyword(tmp_path: Path) -> None:
    """Detection is content-aware: any of the unicode-check keywords counts."""
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "any-name.yml").write_text("name: ascii-check\n", encoding="utf-8")
    result = ci.audit_repo(tmp_path)
    assert "unicode-check" in result.present_workflows
    assert "secret-scan" in result.missing_workflows


def test_audit_detects_secret_scan_via_sca(tmp_path: Path) -> None:
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "scan.yml").write_text("run: sca scan .\n", encoding="utf-8")
    result = ci.audit_repo(tmp_path)
    assert "secret-scan" in result.present_workflows


def test_audit_detects_secret_scan_via_gitleaks(tmp_path: Path) -> None:
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "scan.yml").write_text("uses: gitleaks/gitleaks-action\n", encoding="utf-8")
    result = ci.audit_repo(tmp_path)
    assert "secret-scan" in result.present_workflows


# ---------- write_baseline_workflow ----------

def test_write_unicode_check_creates_file(tmp_path: Path) -> None:
    target = ci.write_baseline_workflow(tmp_path, "unicode-check")
    assert target == tmp_path / ".github" / "workflows" / "unicode-check.yml"
    assert target.exists()
    assert "name: unicode-check" in target.read_text(encoding="utf-8")


def test_write_secret_scan_creates_file(tmp_path: Path) -> None:
    target = ci.write_baseline_workflow(tmp_path, "secret-scan")
    assert target.exists()
    assert "name: secret-scan" in target.read_text(encoding="utf-8")


def test_write_idempotent_skips_existing(tmp_path: Path) -> None:
    target = ci.write_baseline_workflow(tmp_path, "unicode-check")
    sentinel = "# user-customized\n"
    target.write_text(sentinel, encoding="utf-8")
    again = ci.write_baseline_workflow(tmp_path, "unicode-check")
    assert again == target
    assert target.read_text(encoding="utf-8") == sentinel


def test_write_unknown_baseline_raises(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        ci.write_baseline_workflow(tmp_path, "no-such-baseline")


# ---------- template content (regression pins for Bug 1 and Bug 2 fixes) ----------

class TestUnicodeCheckTemplate:
    """The unicode-check template clones URT outside the workspace so the
    scan path `.` doesn't include URT's own test fixtures (which
    intentionally contain unicode for self-testing). See Bug 1."""

    template = ci._UNICODE_CHECK_YAML

    def test_clones_urt_to_tmp_outside_workspace(self) -> None:
        assert "/tmp/_urt" in self.template, (
            "URT must be cloned outside the workspace to avoid scanning the scanner."
        )

    def test_does_not_use_actions_checkout_for_urt(self) -> None:
        # The previous broken version did: actions/checkout@v5 with: repository:
        # aollivierre/UnicodeReplacementTool. That landed URT inside the workspace.
        for line in self.template.splitlines():
            if "actions/checkout" in line:
                continue  # only the consumer repo's own checkout is allowed
        assert "repository: aollivierre/UnicodeReplacementTool" not in self.template, (
            "Bug 1 regression: URT must be cloned via plain `git clone` to /tmp, "
            "not via actions/checkout (which restricts paths to the workspace)."
        )

    def test_runs_urt_from_tmp_path(self) -> None:
        assert "python /tmp/_urt/unicode_replacer.py" in self.template

    def test_does_not_invoke_urt_from_workspace_path(self) -> None:
        # `python _urt/unicode_replacer.py` would be the broken pattern.
        for line in self.template.splitlines():
            if line.lstrip().startswith("python _urt/"):
                pytest.fail(f"Bug 1 regression: invokes URT from workspace path: {line!r}")


class TestSecretScanTemplate:
    """The secret-scan template installs `aollivierre-sca` from PyPI rather
    than checking out source-control-automation cross-repo. See Bug 2:
    cross-repo checkout fails when source-control-automation is private
    (default GITHUB_TOKEN can't read other repos)."""

    template = ci._SECRET_SCAN_YAML

    def test_installs_sca_from_pypi(self) -> None:
        assert "pip install aollivierre-sca" in self.template

    def test_pins_sca_version(self) -> None:
        # Version pinning protects consumers from a surprise regression in
        # the canonical scanner.
        assert "aollivierre-sca==" in self.template, (
            "PyPI install must pin a version; bumping is a deliberate act."
        )

    def test_does_not_checkout_sca_cross_repo(self) -> None:
        assert "repository: aollivierre/source-control-automation" not in self.template, (
            "Bug 2 regression: cross-repo checkout fails for private repos. "
            "Install from PyPI instead."
        )

    def test_does_not_pip_install_editable_from_source(self) -> None:
        # `pip install -e .` was the previous source-install pattern that
        # required the cross-repo checkout to succeed.
        assert "pip install -e ." not in self.template

    def test_keeps_gitleaks_backstop(self) -> None:
        # Defense-in-depth: gitleaks remains as the independent second opinion.
        assert "gitleaks" in self.template

    def test_runs_sca_scan_with_test_excludes(self) -> None:
        assert "sca scan" in self.template
        assert "--exclude tests" in self.template
