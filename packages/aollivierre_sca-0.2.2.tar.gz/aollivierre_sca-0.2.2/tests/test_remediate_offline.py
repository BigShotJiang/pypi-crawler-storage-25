"""Tests for the --offline mode of the visibility gate.

Offline mode shouldn't call `gh api`; it should treat origin as public
and run the secret scanner. If the scanner is clean, allow the push;
if not, refuse.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from sca import remediate


def _add_origin(repo: Path, url: str) -> None:
    subprocess.run(["git", "-C", str(repo), "remote", "add", "origin", url],
                   check=True, capture_output=True)


def test_no_remote_passes_gate(fake_repo: Path) -> None:
    allowed, reason = remediate._visibility_gate(fake_repo, offline=True)
    assert allowed is True
    assert "no remote" in reason.lower()


def test_offline_clean_repo_passes_gate(fake_repo: Path) -> None:
    _add_origin(fake_repo, "git@github.com:owner/repo.git")
    allowed, reason = remediate._visibility_gate(fake_repo, offline=True)
    assert allowed is True
    assert "offline" in reason.lower()


def test_offline_with_pat_in_repo_blocks_gate(repo_with_pat: Path) -> None:
    _add_origin(repo_with_pat, "git@github.com:owner/repo.git")
    allowed, reason = remediate._visibility_gate(repo_with_pat, offline=True)
    assert allowed is False
    assert "REFUSED" in reason
    assert "github_pat" in reason  # category from the scan


def test_offline_with_xor_obfuscation_blocks_gate(repo_with_xor_obfuscation: Path) -> None:
    _add_origin(repo_with_xor_obfuscation, "git@github.com:owner/repo.git")
    allowed, reason = remediate._visibility_gate(repo_with_xor_obfuscation, offline=True)
    assert allowed is False
    assert "REFUSED" in reason


# ---------- gh-api fallback tests ----------

def test_visibility_fallback_returns_public_for_known_public(monkeypatch: pytest.MonkeyPatch) -> None:
    """If the `gh` CLI returns nothing, fall back to api.github.com.
    Mock both layers so the test doesn't actually hit the network."""
    monkeypatch.setattr(remediate, "_gh_visibility_via_cli",
                        lambda owner, repo: None)
    monkeypatch.setattr(remediate, "_gh_visibility_via_api",
                        lambda owner, repo: "public")
    assert remediate._gh_visibility("git@github.com:foo/bar.git") == "public"


def test_visibility_prefers_cli_when_available(monkeypatch: pytest.MonkeyPatch) -> None:
    cli_calls = []
    api_calls = []
    monkeypatch.setattr(remediate, "_gh_visibility_via_cli",
                        lambda o, r: cli_calls.append((o, r)) or "private")
    monkeypatch.setattr(remediate, "_gh_visibility_via_api",
                        lambda o, r: api_calls.append((o, r)) or "public")
    result = remediate._gh_visibility("https://github.com/foo/bar.git")
    assert result == "private"
    assert cli_calls == [("foo", "bar")]
    assert api_calls == []  # api fallback should NOT be called when CLI succeeds


def test_visibility_returns_none_for_non_github_url() -> None:
    assert remediate._gh_visibility("git@gitlab.com:foo/bar.git") is None
    assert remediate._gh_visibility("not-a-url") is None
