"""Tests for sca/branches.py -- per-repo branch inventory."""
from __future__ import annotations

import io
import json
import subprocess
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import pytest

from sca import branches


def _run_branches(root: Path) -> list[dict]:
    branches.ROOT = root.resolve()
    buf_out, buf_err = io.StringIO(), io.StringIO()
    with redirect_stdout(buf_out), redirect_stderr(buf_err):
        branches.main()
    return json.loads(buf_out.getvalue())


def _git(*cmd: str, cwd: Path) -> None:
    subprocess.run(("git",) + cmd, cwd=cwd, check=True, capture_output=True, text=True)


@pytest.fixture
def repo_with_extra_branch(fake_repo: Path) -> tuple[Path, str]:
    """A repo with `main` + a `feature/x` branch carrying one extra commit."""
    _git("checkout", "-b", "feature/x", cwd=fake_repo)
    (fake_repo / "feature.txt").write_text("hi\n", encoding="utf-8")
    _git("add", "feature.txt", cwd=fake_repo)
    _git("commit", "-m", "feature commit", cwd=fake_repo)
    _git("checkout", "main", cwd=fake_repo)
    return fake_repo, "feature/x"


def test_branches_reports_one_repo(fake_repo: Path) -> None:
    data = _run_branches(fake_repo.parent)
    assert len(data) == 1
    assert data[0]["name"] == fake_repo.name


def test_branches_lists_main_and_feature(repo_with_extra_branch: tuple[Path, str]) -> None:
    repo, feature_name = repo_with_extra_branch
    data = _run_branches(repo.parent)
    assert len(data) == 1
    branch_names = [b["name"] for b in data[0]["branches"]]
    assert "main" in branch_names
    assert feature_name in branch_names


def test_branches_main_behind_feature(repo_with_extra_branch: tuple[Path, str]) -> None:
    """main is missing 1 commit that feature/x has -- should show up in
    `main_behind_by` for the feature branch."""
    repo, feature_name = repo_with_extra_branch
    data = _run_branches(repo.parent)
    feature_entry = next(b for b in data[0]["branches"] if b["name"] == feature_name)
    assert feature_entry["main_behind_by"] == 1
    assert feature_entry["merged_into_main"] is False


def test_branches_no_remote_means_no_remote_state(fake_repo: Path) -> None:
    data = _run_branches(fake_repo.parent)
    branch = data[0]["branches"][0]
    # no remote -> no `on_remote` true entries
    assert branch["on_remote"] is False
