"""Tests for sca/remediate.py -- plan generation (execution is integration-level
and not exercised here)."""
from __future__ import annotations

from sca import remediate
from sca.remediate import ActionKind


def _audit_entry(**overrides):
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 10,
    }
    base.update(overrides)
    return base


def test_compliant_repo_yields_no_plan() -> None:
    plan = remediate.plan_for_entry(_audit_entry())
    assert plan is None


def test_local_git_only_plan_includes_secret_scan_before_create() -> None:
    plan = remediate.plan_for_entry(_audit_entry(has_remote=False))
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.SCAN_SECRETS in kinds
    # scan must come before create_github_repo so we never create-then-leak
    assert kinds.index(ActionKind.SCAN_SECRETS) < kinds.index(ActionKind.CREATE_GH_REPO)


def test_no_source_control_plan_includes_init_and_first_push() -> None:
    plan = remediate.plan_for_entry(
        _audit_entry(type="non_repo", file_count=5, has_remote=False)
    )
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.INIT_REPO in kinds
    assert ActionKind.PUSH in kinds
    # backup must come before init (defense-in-depth)
    assert kinds.index(ActionKind.BACKUP) < kinds.index(ActionKind.INIT_REPO)


def test_incomplete_plan_commits_and_pushes_only_if_remote() -> None:
    with_remote = remediate.plan_for_entry(_audit_entry(dirty=True))
    no_remote   = remediate.plan_for_entry(_audit_entry(dirty=True, has_remote=False))
    assert with_remote is not None and no_remote is not None
    assert ActionKind.PUSH in [a.kind for a in with_remote.actions]
    # local-git-only plan path takes precedence when has_remote=False
    # (no commit then push expected without remote)


def test_partially_synced_only_pushes_when_strictly_ahead() -> None:
    plan_ahead   = remediate.plan_for_entry(_audit_entry(ahead=3))
    plan_diverged = remediate.plan_for_entry(_audit_entry(ahead=3, behind=2))
    assert plan_ahead is not None and plan_diverged is not None
    assert ActionKind.PUSH in [a.kind for a in plan_ahead.actions]
    # diverged -> only a NOTE, no auto-push
    kinds = [a.kind for a in plan_diverged.actions]
    assert ActionKind.PUSH not in kinds
    assert ActionKind.NOTE in kinds


def test_container_plan_is_none() -> None:
    """Containers (organisational dirs holding child repos but no outer
    .git) need no remediation -- the planner should return None."""
    plan = remediate.plan_for_entry(_audit_entry(type="container"))
    assert plan is None


def test_destructive_actions_are_marked() -> None:
    """Every Action.destructive flag should match a sane intuition: backup is
    safe, init/commit/create-repo/push are destructive."""
    plan = remediate.plan_for_entry(
        _audit_entry(type="non_repo", file_count=5, has_remote=False)
    )
    assert plan is not None
    by_kind = {a.kind: a for a in plan.actions}
    assert by_kind[ActionKind.BACKUP].destructive is False
    assert by_kind[ActionKind.SCAN_SECRETS].destructive is False
    assert by_kind[ActionKind.APPLY_GITIGNORE].destructive is False
    assert by_kind[ActionKind.INIT_REPO].destructive is True
    assert by_kind[ActionKind.COMMIT_DIRTY].destructive is True
    assert by_kind[ActionKind.CREATE_GH_REPO].destructive is True
    assert by_kind[ActionKind.PUSH].destructive is True
