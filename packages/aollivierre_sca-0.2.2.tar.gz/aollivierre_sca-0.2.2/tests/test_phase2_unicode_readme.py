"""Phase 2: Unicode audit + README presence + remediation hooks."""
from __future__ import annotations

import io
import json
import subprocess
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import pytest

from sca import audit, remediate, unicode_audit
from sca import ci as _ci
from sca.remediate import ActionKind


def _git(*cmd: str, cwd: Path) -> None:
    subprocess.run(("git",) + cmd, cwd=cwd, check=True,
                   capture_output=True, text=True)


def _run_audit(root: Path) -> list[dict]:
    audit.ROOT = root.resolve()
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(io.StringIO()):
        audit.main()
    return json.loads(buf.getvalue())


# ---------- README detection ----------

def test_audit_marks_repo_with_readme(fake_repo: Path) -> None:
    data = _run_audit(fake_repo.parent)
    entry = next(x for x in data if x.get("name") == fake_repo.name)
    # fake_repo fixture writes a README.md
    assert entry["has_readme"] is True
    assert "MISSING_README" not in entry["gaps"]


def test_audit_flags_missing_readme(fake_repo: Path) -> None:
    (fake_repo / "README.md").unlink()
    _git("add", "-A", cwd=fake_repo)
    _git("commit", "-m", "remove readme", cwd=fake_repo)
    data = _run_audit(fake_repo.parent)
    entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert entry["has_readme"] is False
    assert "MISSING_README" in entry["gaps"]


# ---------- Unicode audit ----------

def test_unicode_audit_skips_pure_ascii(tmp_path: Path) -> None:
    (tmp_path / "x.ps1").write_text("Write-Host 'hello'\n", encoding="utf-8")
    rf = unicode_audit.scan_repo(tmp_path)
    assert rf.total_chars == 0
    assert rf.files == []


# Right single quotation mark (U+2019) is the classic non-ASCII offender
# we use as a fixture. Building it from its escape keeps THIS source file
# pure ASCII (so the URT CI check on v3/ stays green) while still
# producing the real character at runtime for the assertions below.
_SMART_QUOTE = "\u2019"


def test_unicode_audit_detects_non_ascii_in_ps1(tmp_path: Path) -> None:
    (tmp_path / "x.ps1").write_text(
        f"Write-Host 'hello{_SMART_QUOTE}world'\n", encoding="utf-8")
    rf = unicode_audit.scan_repo(tmp_path)
    assert rf.total_chars == 1
    assert rf.total_files == 1
    assert _SMART_QUOTE in rf.files[0].unique_chars


def test_unicode_audit_skips_markdown(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text(
        f"# hello{_SMART_QUOTE}world\n", encoding="utf-8")
    rf = unicode_audit.scan_repo(tmp_path)
    assert rf.total_chars == 0


def test_unicode_audit_skips_self_directory(tmp_path: Path) -> None:
    inner = tmp_path / "UnicodeReplacementTool"
    inner.mkdir()
    (inner / "x.ps1").write_text(
        f"Write-Host 'hello{_SMART_QUOTE}world'\n", encoding="utf-8")
    rf = unicode_audit.scan_repo(tmp_path)
    # The whole UnicodeReplacementTool dir is excluded.
    assert rf.total_chars == 0


def test_unicode_audit_records_line_numbers(tmp_path: Path) -> None:
    text = f"line one\nline{_SMART_QUOTE}two\nline three\n"
    (tmp_path / "x.ps1").write_text(text, encoding="utf-8")
    rf = unicode_audit.scan_repo(tmp_path)
    assert 2 in rf.files[0].line_numbers


# ---------- planner: README + Unicode actions ----------

def _entry(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5,
    }
    base.update(overrides)
    return base


def test_compliant_repo_with_missing_readme_yields_create_readme() -> None:
    plan = remediate.plan_for_entry(_entry(has_readme=False))
    assert plan is not None
    assert ActionKind.CREATE_README in [a.kind for a in plan.actions]


def test_compliant_repo_with_unicode_yields_replacement_action() -> None:
    plan = remediate.plan_for_entry(_entry(unicode_chars=42, unicode_files=3))
    assert plan is not None
    assert ActionKind.RUN_UNICODE_REPLACEMENT in [a.kind for a in plan.actions]


def test_compliant_repo_with_no_hygiene_issues_yields_none() -> None:
    plan = remediate.plan_for_entry(_entry(has_readme=True, unicode_chars=0))
    assert plan is None


# ---------- CI workflow audit + installer ----------

def test_ci_audit_detects_baseline_when_keyword_present(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    (repo / ".github" / "workflows").mkdir(parents=True)
    (repo / ".github" / "workflows" / "anything.yml").write_text(
        "name: ascii-only check\njobs: {}\n", encoding="utf-8")
    wf = _ci.audit_repo(repo)
    assert "unicode-check" in wf.present_workflows
    assert "unicode-check" not in wf.missing_workflows


def test_ci_audit_flags_missing_baseline(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    wf = _ci.audit_repo(repo)
    assert "unicode-check" in wf.missing_workflows


def test_ci_install_writes_workflow_and_is_idempotent(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    target = _ci.write_baseline_workflow(repo, "unicode-check")
    assert target.exists()
    body = target.read_text(encoding="utf-8")
    # Second call shouldn't change anything (idempotent)
    target2 = _ci.write_baseline_workflow(repo, "unicode-check")
    assert target2.read_text(encoding="utf-8") == body


def test_ci_install_rejects_unknown_baseline(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    with pytest.raises(ValueError):
        _ci.write_baseline_workflow(repo, "totally-fictional-baseline")


# ---------- secret-scan baseline ----------

def test_secret_scan_baseline_detected_via_gitleaks_keyword(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    (repo / ".github" / "workflows").mkdir(parents=True)
    (repo / ".github" / "workflows" / "any-name.yml").write_text(
        "name: foo\njobs:\n  s:\n    steps:\n      - run: gitleaks detect\n",
        encoding="utf-8")
    wf = _ci.audit_repo(repo)
    assert "secret-scan" in wf.present_workflows
    assert "secret-scan" not in wf.missing_workflows


def test_secret_scan_baseline_detected_via_sca_scan_keyword(tmp_path: Path) -> None:
    """A workflow that runs `sca scan` already does what this baseline asks."""
    repo = tmp_path / "r"
    (repo / ".github" / "workflows").mkdir(parents=True)
    (repo / ".github" / "workflows" / "test.yml").write_text(
        "name: tests\njobs:\n  scan:\n    steps:\n      - run: sca scan .\n",
        encoding="utf-8")
    wf = _ci.audit_repo(repo)
    assert "secret-scan" in wf.present_workflows


def test_secret_scan_baseline_detected_via_selfscan_keyword(tmp_path: Path) -> None:
    """source-control-automation's own v3-tests.yml uses a `selfscan` job
    name -- it must be detected as already-present so the baseline isn't
    duplicated."""
    repo = tmp_path / "r"
    (repo / ".github" / "workflows").mkdir(parents=True)
    (repo / ".github" / "workflows" / "v3-tests.yml").write_text(
        "name: v3 tests\njobs:\n  selfscan:\n    name: secrets self-scan\n"
        "    steps: []\n",
        encoding="utf-8")
    wf = _ci.audit_repo(repo)
    assert "secret-scan" in wf.present_workflows


def test_secret_scan_baseline_flagged_when_missing(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    wf = _ci.audit_repo(repo)
    assert "secret-scan" in wf.missing_workflows


def test_secret_scan_install_writes_yaml_and_is_idempotent(tmp_path: Path) -> None:
    repo = tmp_path / "r"
    repo.mkdir()
    target = _ci.write_baseline_workflow(repo, "secret-scan")
    assert target.exists()
    assert target.name == "secret-scan.yml"
    body = target.read_text(encoding="utf-8")
    # The two complementary jobs are present
    assert "sca-scan:" in body
    assert "gitleaks:" in body
    # Idempotent
    target2 = _ci.write_baseline_workflow(repo, "secret-scan")
    assert target2.read_text(encoding="utf-8") == body


def test_secret_scan_yaml_uses_canonical_sca_distribution(tmp_path: Path) -> None:
    """The SSOT job must install the canonical sca scanner (now via PyPI),
    not embed pattern logic inline. PyPI replaces the earlier cross-repo
    checkout pattern, which broke when source-control-automation was
    private (default GITHUB_TOKEN can't read other repos)."""
    repo = tmp_path / "r"
    repo.mkdir()
    body = _ci.write_baseline_workflow(repo, "secret-scan").read_text(encoding="utf-8")
    # New SSOT path: pip install from PyPI with a pinned version.
    assert "pip install aollivierre-sca==" in body
    # Must NOT regress to cross-repo checkout (Bug 2).
    assert "repository: aollivierre/source-control-automation" not in body
    # Must NOT inline a regex set.
    assert "github_pat_" not in body
    assert "ghp_" not in body


def test_planner_queues_secret_scan_install_when_missing() -> None:
    """The planner should queue an INSTALL_CI_WORKFLOW for every missing
    baseline, not just unicode-check."""
    plan = remediate.plan_for_entry(_entry(
        missing_workflows=["unicode-check", "secret-scan"],
    ))
    assert plan is not None
    install_actions = [a for a in plan.actions
                       if a.kind == ActionKind.INSTALL_CI_WORKFLOW]
    workflows = sorted(a.params.get("workflow") for a in install_actions)
    assert workflows == ["secret-scan", "unicode-check"]


def test_planner_skips_baselines_for_urt_repo() -> None:
    """URT is fully exempt from CI baseline installs."""
    plan = remediate.plan_for_entry(_entry(
        name="UnicodeReplacementTool",
        missing_workflows=["unicode-check", "secret-scan"],
    ))
    # URT exemption returns no actions at all from _hygiene_actions.
    if plan is not None:
        kinds = [a.kind for a in plan.actions]
        assert ActionKind.INSTALL_CI_WORKFLOW not in kinds
