"""Phase 4: secret redaction (force-rewrite working tree)."""
from __future__ import annotations

import subprocess
from pathlib import Path

from sca import redact, remediate
from sca.remediate import ActionKind


def _git(*cmd: str, cwd: Path) -> None:
    subprocess.run(("git",) + cmd, cwd=cwd, check=True,
                   capture_output=True, text=True)


# ---------- redact_text ----------

def test_redact_text_replaces_github_pat() -> None:
    text = ("$Token = 'github_pat_"
            "11ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_FAKE'")
    new, n = redact.redact_text(text)
    assert n == 1
    assert "github_pat_" not in new
    assert "<REDACTED>" in new


def test_redact_text_replaces_aws_access_key() -> None:
    text = "AKIAABCDEFGHIJKLMNOP\n"
    new, n = redact.redact_text(text)
    assert n == 1
    assert "AKIA" not in new


def test_redact_text_only_redacts_guid_when_only_config() -> None:
    text = "id = 11111111-2222-3333-4444-555555555555\n"
    new_default, n_default = redact.redact_text(text)
    assert n_default == 0
    assert "11111111" in new_default
    new_cfg, n_cfg = redact.redact_text(text, only_config=True)
    assert n_cfg == 1
    assert "11111111" not in new_cfg


def test_redact_text_keeps_password_key_strips_value() -> None:
    text = 'password = "hunter2hunter2"\n'
    new, n = redact.redact_text(text)
    assert n == 1
    assert "password" in new
    assert "hunter2" not in new
    assert "<REDACTED>" in new


def test_redact_text_no_change_for_clean_input() -> None:
    text = "print('hello world')\n"
    new, n = redact.redact_text(text)
    assert n == 0
    assert new == text


# ---------- redact_file ----------

def test_redact_file_writes_back(tmp_path: Path) -> None:
    p = tmp_path / "x.ps1"
    p.write_text("$Token = 'ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA'\n",
                 encoding="utf-8")
    n = redact.redact_file(p)
    assert n == 1
    assert "ghp_" not in p.read_text(encoding="utf-8")


# ---------- redact_repo on a real fake_repo ----------

def test_redact_repo_replaces_committed_pat(repo_with_pat: Path) -> None:
    n = redact.redact_repo(repo_with_pat)
    assert n >= 1
    body = (repo_with_pat / "leaky.ps1").read_text(encoding="utf-8")
    assert "github_pat_" not in body
    assert "<REDACTED>" in body


# ---------- planner: REDACT_SECRETS scheduled when annotated ----------

def _entry(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "has_readme": True,
    }
    base.update(overrides)
    return base


def test_planner_schedules_redact_when_critical_count_set() -> None:
    plan = remediate.plan_for_entry(_entry(critical_secret_count=3))
    assert plan is not None
    assert ActionKind.REDACT_SECRETS in [a.kind for a in plan.actions]


def test_planner_does_not_schedule_redact_when_zero() -> None:
    plan = remediate.plan_for_entry(_entry(critical_secret_count=0))
    assert plan is None
