"""Test for _restore_upstream_tracking() in sca.remediate.

Regression test for HANDOFF.md item #3: after a force-push of all refs
(filter-repo cleanup, mirror push, etc.) local branches lose their
upstream tracking config. This test exercises the post-step that
restores it.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from sca.remediate import _restore_upstream_tracking


def _git(*cmd: str, cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        ("git", "-C", str(cwd)) + cmd,
        capture_output=True, text=True, check=False,
    )


def _git_check(*cmd: str, cwd: Path) -> None:
    r = _git(*cmd, cwd=cwd)
    assert r.returncode == 0, f"git {' '.join(cmd)} failed: {r.stderr}"


@pytest.fixture
def repo_with_remote(tmp_path: Path) -> tuple[Path, Path]:
    """A local repo + a sibling bare repo that acts as `origin`. Several
    branches exist on both sides at the same SHA, but the local repo has
    NO upstream tracking config (mirroring the post-filter-repo state)."""
    bare = tmp_path / "origin.git"
    local = tmp_path / "work"
    local.mkdir()

    # Bare remote
    _git_check("init", "--bare", "-b", "main", str(bare), cwd=tmp_path)

    # Working repo
    _git_check("init", "-b", "main", str(local), cwd=tmp_path)
    _git_check("config", "user.email", "t@example.com", cwd=local)
    _git_check("config", "user.name", "Test", cwd=local)
    (local / "README.md").write_text("hello\n", encoding="utf-8")
    _git_check("add", "README.md", cwd=local)
    _git_check("commit", "-m", "initial", cwd=local)

    # Two more branches off main
    _git_check("checkout", "-b", "feature/a", cwd=local)
    (local / "a.txt").write_text("a\n", encoding="utf-8")
    _git_check("add", "a.txt", cwd=local)
    _git_check("commit", "-m", "a", cwd=local)

    _git_check("checkout", "main", cwd=local)
    _git_check("checkout", "-b", "feature/b", cwd=local)
    (local / "b.txt").write_text("b\n", encoding="utf-8")
    _git_check("add", "b.txt", cwd=local)
    _git_check("commit", "-m", "b", cwd=local)

    # A local-only branch that should NOT be retargeted (legitimate WIP)
    _git_check("checkout", "main", cwd=local)
    _git_check("checkout", "-b", "wip/local-only", cwd=local)
    (local / "wip.txt").write_text("wip\n", encoding="utf-8")
    _git_check("add", "wip.txt", cwd=local)
    _git_check("commit", "-m", "wip", cwd=local)

    # Wire origin and push three refs (NOT wip/local-only). Then strip
    # tracking config to mirror the post-filter-repo / post-mirror-push
    # state where every branch.<name>.remote / .merge entry is gone.
    _git_check("checkout", "main", cwd=local)
    _git_check("remote", "add", "origin", str(bare), cwd=local)
    _git_check("push", "origin", "main", cwd=local)
    _git_check("push", "origin", "feature/a", cwd=local)
    _git_check("push", "origin", "feature/b", cwd=local)
    # Strip tracking config -- this is what filter-repo + push --force --all
    # leaves behind.
    for branch in ("main", "feature/a", "feature/b"):
        _git("branch", "--unset-upstream", branch, cwd=local)

    return local, bare


def test_restore_upstream_tracking_sets_tracking_for_branches_on_remote(
    repo_with_remote: tuple[Path, Path],
) -> None:
    local, _bare = repo_with_remote

    # Pre-condition: no branch has an upstream
    for branch in ("main", "feature/a", "feature/b", "wip/local-only"):
        r = _git("rev-parse", "--abbrev-ref", f"{branch}@{{u}}", cwd=local)
        assert r.returncode != 0, \
            f"branch {branch} unexpectedly has upstream: {r.stdout}"

    n = _restore_upstream_tracking(local, "origin")

    # Three branches on origin -> three restored
    assert n == 3, f"expected 3 branches restored, got {n}"

    # Each remote-mirrored branch now has upstream
    for branch in ("main", "feature/a", "feature/b"):
        r = _git("rev-parse", "--abbrev-ref", f"{branch}@{{u}}", cwd=local)
        assert r.returncode == 0, \
            f"branch {branch} should have upstream, got: {r.stderr}"
        assert r.stdout.strip() == f"origin/{branch}"

    # The local-only WIP branch must remain unattached -- legitimate
    # local-only work shouldn't get fake tracking assigned.
    r = _git("rev-parse", "--abbrev-ref", "wip/local-only@{u}", cwd=local)
    assert r.returncode != 0, \
        "local-only branch should not have been retargeted to a remote"


def test_restore_upstream_tracking_idempotent(
    repo_with_remote: tuple[Path, Path],
) -> None:
    """Calling twice in a row should be a no-op on the second pass
    (counts the same branches; doesn't error)."""
    local, _bare = repo_with_remote

    n1 = _restore_upstream_tracking(local, "origin")
    n2 = _restore_upstream_tracking(local, "origin")
    assert n1 == n2 == 3


def test_restore_upstream_tracking_handles_missing_remote(
    tmp_path: Path,
) -> None:
    """If the named remote doesn't exist, the function should return 0
    cleanly rather than raising."""
    local = tmp_path / "no-remote"
    local.mkdir()
    _git_check("init", "-b", "main", str(local), cwd=tmp_path)
    _git_check("config", "user.email", "t@example.com", cwd=local)
    _git_check("config", "user.name", "Test", cwd=local)
    (local / "x").write_text("x\n", encoding="utf-8")
    _git_check("add", "x", cwd=local)
    _git_check("commit", "-m", "x", cwd=local)

    n = _restore_upstream_tracking(local, "origin")
    assert n == 0
