"""HTTPS/SSH protocol audit + SSH-to-HTTPS conversion tests."""
from __future__ import annotations

import io
import json
import subprocess
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from sca import audit, remediate
from sca.remediate import ActionKind


def _run_audit(root: Path) -> list[dict]:
    audit.ROOT = root.resolve()
    buf_out, buf_err = io.StringIO(), io.StringIO()
    with redirect_stdout(buf_out), redirect_stderr(buf_err):
        audit.main()
    return json.loads(buf_out.getvalue())


def _git(*cmd: str, cwd: Path) -> None:
    subprocess.run(("git",) + cmd, cwd=cwd, check=True,
                   capture_output=True, text=True)


# ---------- audit-side: classify_remote_protocol ----------

def test_classify_remote_protocol_https() -> None:
    assert audit.classify_remote_protocol("https://github.com/o/r.git") == "https"
    assert audit.classify_remote_protocol("http://gitea.example.com/o/r") == "https"


def test_classify_remote_protocol_ssh_shorthand() -> None:
    assert audit.classify_remote_protocol("git@github.com:o/r.git") == "ssh"


def test_classify_remote_protocol_ssh_url() -> None:
    assert audit.classify_remote_protocol("ssh://git@github.com/o/r.git") == "ssh"


def test_classify_remote_protocol_git_anon() -> None:
    assert audit.classify_remote_protocol("git://github.com/o/r.git") == "git"


def test_classify_remote_protocol_other() -> None:
    assert audit.classify_remote_protocol("") == "other"
    assert audit.classify_remote_protocol("file:///srv/git/r") == "other"


# ---------- audit-side: end-to-end flag on a real repo ----------

def test_audit_flags_ssh_remote(fake_repo: Path) -> None:
    _git("remote", "add", "origin", "git@github.com:owner/repo.git", cwd=fake_repo)
    data = _run_audit(fake_repo.parent)
    entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert entry["uses_ssh"] is True
    assert entry["remote_protocols"]["origin"] == "ssh"
    assert "REMOTE_USES_SSH" in entry["gaps"]


def test_audit_does_not_flag_https_remote(fake_repo: Path) -> None:
    _git("remote", "add", "origin",
         "https://github.com/owner/repo.git", cwd=fake_repo)
    data = _run_audit(fake_repo.parent)
    entry = next(x for x in data if x.get("name") == fake_repo.name)
    assert entry["uses_ssh"] is False
    assert "REMOTE_USES_SSH" not in entry["gaps"]


# ---------- remediate-side: ssh_to_https_url ----------

def test_ssh_to_https_url_shorthand() -> None:
    assert (remediate.ssh_to_https_url("git@github.com:owner/repo.git")
            == "https://github.com/owner/repo.git")


def test_ssh_to_https_url_no_dotgit_suffix() -> None:
    # Should add .git for consistency
    assert (remediate.ssh_to_https_url("git@github.com:owner/repo")
            == "https://github.com/owner/repo.git")


def test_ssh_to_https_url_proto_form() -> None:
    assert (remediate.ssh_to_https_url("ssh://git@github.com/owner/repo.git")
            == "https://github.com/owner/repo.git")


def test_ssh_to_https_url_rejects_https() -> None:
    assert remediate.ssh_to_https_url("https://github.com/owner/repo.git") is None


def test_ssh_to_https_url_rejects_other_hosts() -> None:
    assert remediate.ssh_to_https_url("git@gitlab.com:o/r.git") is None


# ---------- planner: SSH conversion is added even for FullyCompliant ----------

def _audit_entry(**overrides):
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 10,
    }
    base.update(overrides)
    return base


def test_compliant_repo_with_ssh_remote_yields_conversion_plan() -> None:
    plan = remediate.plan_for_entry(_audit_entry(
        uses_ssh=True,
        remotes={"origin": "git@github.com:o/r.git"},
        remote_protocols={"origin": "ssh"},
    ))
    assert plan is not None, "an SSH-only-issue should still produce a plan"
    kinds = [a.kind for a in plan.actions]
    assert ActionKind.SET_REMOTE_URL in kinds
    set_url = next(a for a in plan.actions if a.kind == ActionKind.SET_REMOTE_URL)
    assert set_url.params["url"] == "https://github.com/o/r.git"
    assert set_url.params["remote"] == "origin"
    assert set_url.destructive is True


def test_partially_synced_repo_converts_ssh_before_pushing() -> None:
    plan = remediate.plan_for_entry(_audit_entry(
        ahead=2,
        uses_ssh=True,
        remotes={"origin": "git@github.com:o/r.git"},
        remote_protocols={"origin": "ssh"},
    ))
    assert plan is not None
    kinds = [a.kind for a in plan.actions]
    assert kinds.index(ActionKind.SET_REMOTE_URL) < kinds.index(ActionKind.PUSH)


def test_https_only_repo_yields_no_conversion() -> None:
    plan = remediate.plan_for_entry(_audit_entry(
        uses_ssh=False,
        remotes={"origin": "https://github.com/o/r.git"},
        remote_protocols={"origin": "https"},
    ))
    assert plan is None
