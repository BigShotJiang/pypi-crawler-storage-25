"""Tests for the per-repo exemption rules shared between the planner
and the renderer's tier classifier."""
from __future__ import annotations

from sca import exemptions

# ---------- helpers ----------

def test_urt_repo_is_recognised() -> None:
    assert exemptions.is_urt_repo("UnicodeReplacementTool") is True
    assert exemptions.is_urt_repo("UnicodeReplacementTool/inner") is True
    assert exemptions.is_urt_repo("UnicodeReplacementTool\\inner") is True
    assert exemptions.is_urt_repo("UnicodeReplacementTool/vscode.ext") is True


def test_self_exempt_recognised() -> None:
    assert exemptions.is_self_exempt("source-control-automation") is True
    assert exemptions.is_self_exempt("source-control-automation/v3") is True


def test_unicode_exempt_covers_both_classes() -> None:
    assert exemptions.is_unicode_exempt("UnicodeReplacementTool") is True
    assert exemptions.is_unicode_exempt("source-control-automation") is True


def test_normal_repo_is_not_exempt() -> None:
    for n in ("ai-guides", "BitLocker", "Claude", "PSADTv4", "Terminal"):
        assert exemptions.is_unicode_exempt(n) is False
        assert exemptions.is_readme_exempt(n) is False
        assert exemptions.is_ci_baseline_exempt(n) is False


def test_empty_or_none_name_does_not_match() -> None:
    for n in (None, "", "   "):
        assert exemptions.is_urt_repo(n) is False
        assert exemptions.is_self_exempt(n) is False


# ---------- end-to-end via _risk_tier ----------

def _repo(**overrides) -> dict:
    base = {
        "type": "repo", "name": "ai-guides", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "size_mb": 1.0, "commits": 1,
        "branch": "main", "remotes": {"origin": "https://x"},
        "remote_protocols": {"origin": "https"},
        "uses_ssh": False, "status": "info", "gaps": [], "last_commit": "",
        "has_readme": True,
    }
    base.update(overrides)
    return base


def test_tier_clean_for_urt_with_unicode_and_no_readme() -> None:
    """A URT repo with non-ASCII source AND no README AND no CI should
    NOT be tiered as hygiene -- those are intentional design choices."""
    from sca.render import _risk_tier
    entry = _repo(
        name="UnicodeReplacementTool",
        unicode_chars=814, has_readme=False,
        missing_workflows=["unicode-check"],
    )
    assert _risk_tier(entry) == "clean"


def test_tier_clean_for_urt_nested_clone() -> None:
    from sca.render import _risk_tier
    entry = _repo(
        name="UnicodeReplacementTool/UnicodeReplacementTool",
        unicode_chars=814, has_readme=False,
        missing_workflows=["unicode-check"],
    )
    assert _risk_tier(entry) == "clean"


def test_tier_clean_for_self_with_unicode_in_test_fixtures() -> None:
    """source-control-automation can have non-ASCII in v3/tests/ (verified
    intentionally). The unicode signal alone should not tier it hygiene."""
    from sca.render import _risk_tier
    entry = _repo(name="source-control-automation", unicode_chars=5)
    assert _risk_tier(entry) == "clean"


def test_tier_hygiene_for_normal_repo_with_unicode() -> None:
    """Other repos with non-ASCII source still tier hygiene."""
    from sca.render import _risk_tier
    entry = _repo(name="Win11UpgradeScheduler", unicode_chars=10)
    assert _risk_tier(entry) == "hygiene"


def test_tier_hygiene_for_self_with_no_readme() -> None:
    """The self-exemption is unicode-only -- a missing README would
    still tier as hygiene."""
    from sca.render import _risk_tier
    entry = _repo(name="source-control-automation", has_readme=False)
    assert _risk_tier(entry) == "hygiene"
