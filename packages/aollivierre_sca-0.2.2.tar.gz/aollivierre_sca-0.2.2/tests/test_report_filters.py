"""Filter-logic tests for the Repos tab.

The actual filter runs in browser JS, but the predicates are simple boolean
expressions over the embedded data fields. This test re-implements the
predicates in Python and exercises them against realistic repo data,
guarding against regressions like 'has:secrets' silently never matching
because the source field is wrong.
"""
from __future__ import annotations

import json
import re

from sca import render

# ---------- predicates (mirror the JS in render.py:_JS) ----------

def _matches(repo: dict, filters: set[str]) -> bool:
    if not filters:
        return True
    tier_filters = [f.split(":", 1)[1] for f in filters if f.startswith("tier:")]
    if tier_filters and repo["tier"] not in tier_filters:
        return False
    if "has:secrets" in filters and not (repo.get("total_findings", 0) > 0):
        return False
    if "has:critical-secrets" in filters and not (repo.get("critical_secret_count", 0) > 0):
        return False
    if "has:unicode" in filters and not (repo.get("unicode_chars", 0) > 0):
        return False
    if "missing:readme" in filters and repo.get("has_readme") is not False:
        return False
    if "proto:ssh" in filters and not repo.get("uses_ssh"):
        return False
    if "dirty" in filters and not repo.get("dirty"):
        return False
    if "missing:remote" in filters and len(repo.get("remotes") or {}) > 0:
        return False
    return True


def _embed(page: str) -> list[dict]:
    m = re.search(
        r'<script id="repos-data" type="application/json">([^<]*)</script>',
        page, re.DOTALL)
    return json.loads(m.group(1))


def _r(**overrides) -> dict:
    base = {
        "type": "repo", "name": "x", "path": "/tmp/x",
        "has_remote": True, "dirty": False, "ahead": 0, "behind": 0,
        "file_count": 5, "size_mb": 1.0, "commits": 1,
        "branch": "main", "remotes": {"origin": "https://x"},
        "remote_protocols": {"origin": "https"},
        "uses_ssh": False, "status": "info", "gaps": [], "last_commit": "",
        "has_readme": True,
    }
    base.update(overrides)
    return base


# ---------- has:secrets vs has:critical-secrets ----------

def test_has_secrets_filter_matches_xor_only_repos() -> None:
    """A repo with xor_obfuscation findings has critical_secret_count=0 but
    total_findings>0 -- the 'has:secrets' filter should still find it."""
    repo = _r(name="xor-only", critical_secret_count=0, total_findings=34)
    page = render.render([repo])
    [embed] = _embed(page)
    assert _matches(embed, {"has:secrets"}) is True
    assert _matches(embed, {"has:critical-secrets"}) is False


def test_has_critical_secrets_filter_excludes_xor_only_repos() -> None:
    repo = _r(name="xor-only", critical_secret_count=0, total_findings=34)
    [embed] = _embed(render.render([repo]))
    assert _matches(embed, {"has:critical-secrets"}) is False


def test_has_secrets_filter_skips_clean_repos() -> None:
    repo = _r(critical_secret_count=0, total_findings=0)
    [embed] = _embed(render.render([repo]))
    assert _matches(embed, {"has:secrets"}) is False


# ---------- tier filters ----------

def test_tier_filter_critical_only_matches_critical() -> None:
    crit = _r(name="crit", critical_secret_count=3)
    hyg  = _r(name="hyg",  has_readme=False)
    page = render.render([crit, hyg])
    embeds = _embed(page)
    by_name = {r["name"]: r for r in embeds}
    assert _matches(by_name["crit"], {"tier:critical"}) is True
    assert _matches(by_name["hyg"],  {"tier:critical"}) is False


# ---------- combined filters (the bug class the user reported) ----------

def test_no_filters_matches_everything() -> None:
    repos = [_r(name=f"r{i}") for i in range(5)]
    embeds = _embed(render.render(repos))
    for r in embeds:
        assert _matches(r, set()) is True


def test_dirty_filter_matches_only_dirty_repo() -> None:
    a = _r(name="a", dirty=True, dirty_files=3)
    b = _r(name="b", dirty=False)
    embeds = {r["name"]: r for r in _embed(render.render([a, b]))}
    assert _matches(embeds["a"], {"dirty"}) is True
    assert _matches(embeds["b"], {"dirty"}) is False


def test_unicode_filter_matches_repos_with_non_ascii() -> None:
    a = _r(name="a", unicode_chars=42)
    b = _r(name="b", unicode_chars=0)
    embeds = {r["name"]: r for r in _embed(render.render([a, b]))}
    assert _matches(embeds["a"], {"has:unicode"}) is True
    assert _matches(embeds["b"], {"has:unicode"}) is False


# ---------- tier rule changes ----------

def test_missing_ci_baseline_alone_is_cosmetic_not_hygiene() -> None:
    """Regression: previously every repo got tier=hygiene because of
    missing-unicode-check. Demoted to cosmetic so the tier signal isn't
    dominated by a brand-new baseline nobody has yet."""
    [embed] = _embed(render.render([_r(missing_workflows=["unicode-check"])]))
    assert embed["tier"] == "cosmetic"


def test_unicode_chars_still_hygiene() -> None:
    [embed] = _embed(render.render([_r(unicode_chars=10)]))
    assert embed["tier"] == "hygiene"


def test_critical_secret_count_overrides_other_signals() -> None:
    [embed] = _embed(render.render([_r(
        critical_secret_count=5, has_readme=False, unicode_chars=10,
    )]))
    assert embed["tier"] == "critical"


# ---------- state field ----------

def test_classification_passes_through_to_embed() -> None:
    repo = _r()
    repo["classification"] = {
        "state": "FullyCompliant", "strategy": "Dedicated", "reason": "..."
    }
    [embed] = _embed(render.render([repo]))
    assert embed["state"] == "FullyCompliant"
    assert embed["state_label"] == "Git-clean"


def test_classification_missing_falls_back_to_question_mark_label() -> None:
    [embed] = _embed(render.render([_r()]))
    assert embed["state"] == ""
    assert embed["state_label"] == "?"
