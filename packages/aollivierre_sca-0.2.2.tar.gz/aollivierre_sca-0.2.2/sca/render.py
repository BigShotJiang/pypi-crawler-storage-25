#!/usr/bin/env python3
"""Render audit JSON to a single-file interactive HTML report.

The report is one self-contained HTML file: CSS and JavaScript are
embedded; no external resources, no build step, opens offline.

Layout:
    Top tab bar:    Overview | Repos | Findings | Branches | Plan | Toolchain
    Left sidebar:   per-tab anchor links to in-tab sections
    Main pane:      the active tab's content

Interactivity (vanilla JS):
    Repos tab     filter chips, group-by, sortable columns, search, pagination
    Findings tab  per-repo accordion with severity-grouped finding list
    Plan tab      flat sortable list of every remediation action

Public API:
    render(audit_data, *, title, secrets_per_repo,
           branches_per_repo, toolchain) -> str
"""
from __future__ import annotations

import argparse
import datetime
import html
import json
import sys
from pathlib import Path

# ---------- CSS ----------

_CSS = """
* { box-sizing: border-box; }
body { font-family: -apple-system, 'Segoe UI', system-ui, sans-serif;
       margin: 0; padding: 0; background: #0d1117; color: #e6edf3;
       line-height: 1.5; }

header { padding: 18px 24px 0; }
h1 { margin: 0 0 4px; font-size: 22px; }
h2 { margin: 24px 0 12px; font-size: 17px; padding-bottom: 6px;
     border-bottom: 1px solid #30363d; }
h3 { margin: 16px 0 8px; font-size: 14px; color: #c9d1d9; }
.sub { color: #8b949e; font-size: 12px; margin-bottom: 12px; }
.brand { color: #f85149; }

/* Tabs */
nav.tabs { display: flex; gap: 2px; border-bottom: 1px solid #30363d;
           margin-top: 14px; flex-wrap: wrap; }
nav.tabs button { background: transparent; color: #8b949e; border: 0;
                  border-bottom: 2px solid transparent; padding: 10px 16px;
                  cursor: pointer; font-size: 13px; font-family: inherit;
                  font-weight: 500; }
nav.tabs button:hover { color: #c9d1d9; }
nav.tabs button.active { color: #e6edf3; border-bottom-color: #f85149; }
nav.tabs .pill { display: inline-block; margin-left: 6px; padding: 1px 7px;
                  border-radius: 10px; font-size: 11px; background: #21262d;
                  color: #8b949e; }
nav.tabs button.active .pill { background: #490202; color: #ffa198; }

/* Layout */
.layout { display: grid; grid-template-columns: 220px 1fr; gap: 24px;
          padding: 18px 24px 32px; max-width: 1600px; }
aside.sidebar { position: sticky; top: 18px; align-self: start; }
aside .group { margin-bottom: 18px; }
aside .group-title { font-size: 11px; color: #6e7681; text-transform: uppercase;
                     letter-spacing: 0.6px; margin: 0 0 6px; padding-left: 10px; }
aside ul { list-style: none; margin: 0; padding: 0; }
aside li a { display: block; color: #8b949e; text-decoration: none; padding: 4px 10px;
             border-radius: 4px; font-size: 12px; }
aside li a:hover { background: #161b22; color: #c9d1d9; }
aside li a.active { background: #1f2a3a; color: #79c0ff; }

main.tabbed { min-width: 0; }
section.tab-content { display: none; }
section.tab-content.active { display: block; }

/* Cards */
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 12px; margin: 12px 0 8px; }
.card { background: #161b22; border: 1px solid #30363d; border-radius: 6px;
        padding: 12px; }
.card .label { font-size: 10px; color: #8b949e; text-transform: uppercase;
               letter-spacing: 0.5px; }
.card .value { font-size: 26px; font-weight: 600; margin-top: 4px; }
.card .footnote { color: #8b949e; font-size: 11px; margin-top: 6px; }
.card.crit { border-color: #6e0a0a; }
.card.crit .value { color: #f85149; }
.card.warn { border-color: #6e5500; }
.card.warn .value { color: #d29922; }
.card.ok { border-color: #1c5530; }
.card.ok .value { color: #3fb950; }
.card.info .value { color: #79c0ff; }

/* Tables */
table { width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 13px; }
th { text-align: left; padding: 8px 10px; background: #161b22; color: #8b949e;
     font-weight: 500; font-size: 11px; text-transform: uppercase;
     letter-spacing: 0.5px; border-bottom: 1px solid #30363d;
     position: sticky; top: 0; }
th.sortable { cursor: pointer; user-select: none; }
th.sortable:hover { color: #c9d1d9; }
th.sort-asc::after  { content: " \\25B2"; color: #79c0ff; }
th.sort-desc::after { content: " \\25BC"; color: #79c0ff; }
td { padding: 8px 10px; border-bottom: 1px solid #21262d; vertical-align: top; }
tr:hover td { background: #161b22; }
tr.row-crit td { background: #1f0808; }
tr.row-crit:hover td { background: #2c0e0e; }
tr.row-warn td { background: #1f1808; }
tr.row-warn:hover td { background: #2c2410; }
.group-row td { background: #1c2937 !important; font-weight: 500;
                color: #79c0ff; padding: 6px 10px; font-size: 11px;
                text-transform: uppercase; letter-spacing: 0.5px; }
.empty-row td { padding: 18px; color: #8b949e; text-align: center; font-style: italic; }

/* Tags */
.tag { display: inline-block; padding: 2px 7px; border-radius: 10px; font-size: 11px;
       font-weight: 500; margin-right: 4px; margin-bottom: 2px; }
.tag.crit { background: #490202; color: #ffa198; border: 1px solid #6e0a0a; }
.tag.warn { background: #4a3700; color: #e3b341; border: 1px solid #6e5500; }
.tag.info { background: #1c2937; color: #79c0ff; border: 1px solid #2a4a6e; }
.tag.ok   { background: #0a3a18; color: #56d364; border: 1px solid #1c5530; }
.tag.muted { background: #21262d; color: #8b949e; border: 1px solid #30363d; }

/* Path / commit */
.path { font-family: 'Cascadia Code', Consolas, monospace; font-size: 12px;
        color: #d2a8ff; }
.muted { color: #8b949e; }
.commit { color: #8b949e; font-size: 11px; }

/* Banner */
.banner { background: #1c2937; border: 1px solid #2a4a6e; padding: 12px 14px;
          border-radius: 6px; margin: 12px 0; }
.banner.crit { background: #490202; border-color: #6e0a0a; }
.banner.warn { background: #4a3700; border-color: #6e5500; }
.banner.ok   { background: #0a3a18; border-color: #1c5530; }
.banner h3 { margin: 0 0 6px; color: #79c0ff; font-size: 13px;
             text-transform: none; letter-spacing: 0; }
.banner.crit h3 { color: #ffa198; }
.banner.warn h3 { color: #e3b341; }
.banner.ok h3   { color: #56d364; }
.banner code { background: #0d1117; padding: 1px 6px; border-radius: 3px;
               color: #79c0ff; font-size: 12px; }
.banner ul { margin: 4px 0 0; padding-left: 20px; }
.banner li { font-size: 12px; line-height: 1.6; }

/* Filter bar (Repos tab) */
.toolbar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center;
           margin: 12px 0; }
.toolbar .chip { background: #21262d; color: #c9d1d9; border: 1px solid #30363d;
                 border-radius: 16px; padding: 4px 12px; font-size: 12px;
                 cursor: pointer; user-select: none; }
.toolbar .chip:hover { border-color: #58a6ff; }
.toolbar .chip.active { background: #1f2a3a; color: #79c0ff; border-color: #58a6ff; }
.toolbar input[type="text"], .toolbar select {
    background: #0d1117; border: 1px solid #30363d; color: #e6edf3;
    padding: 5px 10px; border-radius: 4px; font-size: 12px; font-family: inherit; }
.toolbar input[type="text"]:focus, .toolbar select:focus {
    outline: none; border-color: #58a6ff; }
.toolbar label { font-size: 11px; color: #8b949e; text-transform: uppercase;
                 letter-spacing: 0.5px; margin-right: 4px; }
.toolbar .spacer { flex: 1; }
.pagination { display: flex; gap: 6px; align-items: center; justify-content: center;
              margin: 12px 0; font-size: 12px; color: #8b949e; }
.pagination button { background: #21262d; color: #c9d1d9; border: 1px solid #30363d;
                     padding: 4px 10px; border-radius: 4px; cursor: pointer;
                     font-family: inherit; font-size: 12px; }
.pagination button:hover:not(:disabled) { border-color: #58a6ff; color: #79c0ff; }
.pagination button:disabled { opacity: 0.5; cursor: not-allowed; }

/* Accordion (Findings tab) */
details { background: #161b22; border: 1px solid #30363d; border-radius: 6px;
          margin: 6px 0; padding: 0; }
details > summary { cursor: pointer; padding: 10px 12px; font-size: 13px;
                    font-weight: 500; user-select: none; list-style: none; }
details > summary::-webkit-details-marker { display: none; }
details > summary::before { content: "\\25B6"; display: inline-block; margin-right: 8px;
                             color: #8b949e; transition: transform 0.15s; }
details[open] > summary::before { transform: rotate(90deg); }
details > .body { padding: 0 12px 12px; }
details > .body table { font-size: 12px; }
details > .body code { background: #0d1117; padding: 1px 6px; border-radius: 3px;
                       color: #ffa198; font-family: 'Cascadia Code', Consolas, monospace;
                       font-size: 11px; word-break: break-all; }
"""


# ---------- helpers ----------

# State -> human display label. Keep enum values unchanged (they're stable
# in the JSON output) but render them with clearer wording.
STATE_LABEL: dict[str, str] = {
    "FullyCompliant":          "Git-clean",
    "LocalGitOnly":            "Local-only repo",
    "NoSourceControl":         "No source control",
    "IncompleteSourceControl": "Uncommitted work",
    "PartiallySynced":         "Out of sync",
    "Empty":                   "Empty",
    "LooseFile":               "Loose file",
    "WrapperRepo":             "Wrapper repo",
    "Container":               "Container",
}

GAP_TAGS: dict[str, tuple[str, str]] = {
    "NO_REMOTE":              ("crit", "no remote"),
    "REMOTE_UNREACHABLE":     ("crit", "remote unreachable"),
    "REMOTE_NOT_GITHUB":      ("warn", "not on GitHub"),
    "REMOTE_USES_SSH":        ("warn", "SSH remote"),
    "MISSING_README":         ("warn", "no README"),
    "NOT_A_REPO":             ("warn", "not a git repo"),
    "LOOSE_FILE_NOT_IN_REPO": ("warn", "loose file"),
}


def _gap_label(g: str) -> tuple[str, str]:
    if g in GAP_TAGS:
        return GAP_TAGS[g]
    if g.startswith("DIRTY_"):
        return ("warn", f"dirty ({g.split('_')[1]})")
    if g.startswith("AHEAD_"):
        return ("warn", f"ahead {g.split('_')[1]}")
    if g.startswith("BEHIND_"):
        return ("warn", f"behind {g.split('_')[1]}")
    return ("info", g)


def _risk_tier(repo: dict) -> str:
    """Classify a repo into one of: critical / hygiene / cosmetic / clean.

    Rules (highest tier wins):
        critical : redactable critical secrets, no remote (with content),
                   unreachable remote
        hygiene  : missing README, non-ASCII source, uncommitted work,
                   behind remote
        cosmetic : SSH-only, missing CI baseline (every repo lacks the
                   brand-new unicode-check workflow on day one --
                   demoting this so it doesn't dominate the tier signal),
                   gitea match-but-not-mirrored, repo-mapping suggestion
        clean    : nothing of the above

    Notes:
      - xor_obfuscation findings are NOT critical here (per spec, low-risk;
        critical_secret_count already excludes them).
      - URT-related repos are exempt from the unicode/README/CI signals
        because they own those concerns by design (the mapping table
        itself contains every Unicode character it replaces).
      - source-control-automation is exempt from the unicode signal
        only -- its v3/tests/ directory uses Unicode in fixtures.
    """
    from sca import exemptions as _ex
    name = repo.get("name") or ""

    if int(repo.get("critical_secret_count", 0) or 0) > 0:
        return "critical"
    gaps = repo.get("gaps") or []
    if "NO_REMOTE" in gaps and repo.get("file_count", 0) > 0:
        return "critical"
    if "REMOTE_UNREACHABLE" in gaps:
        return "critical"

    has_unicode = int(repo.get("unicode_chars", 0) or 0) > 0
    if _ex.is_unicode_exempt(name):
        has_unicode = False
    no_readme = repo.get("has_readme") is False
    if _ex.is_readme_exempt(name):
        no_readme = False
    missing_ci = bool(repo.get("missing_workflows"))
    if _ex.is_ci_baseline_exempt(name):
        missing_ci = False

    if (no_readme
            or has_unicode
            or repo.get("dirty")
            or int(repo.get("behind", 0) or 0) > 0):
        return "hygiene"
    if (repo.get("uses_ssh")
            or missing_ci
            or (repo.get("gh_match") and not repo.get("has_remote"))
            or (repo.get("gitea_match") and not repo.get("gitea_mirrored"))):
        return "cosmetic"
    return "clean"


def _tag_status(entry: dict) -> None:
    if entry.get("status"):
        return
    t = entry.get("type")
    if t == "non_repo":
        entry["status"] = "warning" if entry.get("file_count", 0) > 0 else "info"
    elif t == "container":
        entry["status"] = "info"
    elif t == "loose_file":
        entry["status"] = "warning"
    else:
        entry["status"] = "info"


def _proto_tag(proto: str) -> str:
    cls = {"https": "ok", "ssh": "warn", "git": "warn"}.get(proto, "info")
    return f'<span class="tag {cls}">{html.escape(proto.upper())}</span>'


def _gap_tags_html(gaps: list[str]) -> str:
    if not gaps:
        return '<span class="tag ok">ok</span>'
    return "".join(
        f'<span class="tag {_gap_label(g)[0]}">{html.escape(_gap_label(g)[1])}</span>'
        for g in gaps
    )


def _summarise_branches_inline(b: dict | None) -> str:
    if not b or not b.get("branches"):
        return '<span class="muted">--</span>'
    branches = b["branches"]
    n = len(branches)
    unpushed = sum(1 for x in branches if not x.get("on_remote"))
    ahead = sum(int(x.get("ahead_of_origin", 0) or 0) for x in branches)
    behind = sum(int(x.get("behind_origin", 0) or 0) for x in branches)
    parts = [f"{n} branch{'es' if n != 1 else ''}"]
    if unpushed:
        parts.append(f'<span class="tag warn">{unpushed} unpushed</span>')
    if ahead:
        parts.append(f'<span class="tag warn">+{ahead}</span>')
    if behind:
        parts.append(f'<span class="tag warn">-{behind}</span>')
    return " ".join(parts)


# ---------- Overview tab ----------

def _render_overview(repos: list[dict],
                     non_repos: list[dict],
                     loose: list[dict],
                     toolchain: dict | None,
                     secrets_summary: dict) -> str:
    n_repos = len(repos)
    by_tier: dict[str, list[dict]] = {"critical": [], "hygiene": [],
                                       "cosmetic": [], "clean": []}
    for r in repos:
        by_tier[r["_risk_tier"]].append(r)

    total_crit_findings = secrets_summary.get("total_critical", 0)

    def _top_n(rows: list[dict], n: int = 5) -> str:
        if not rows:
            return '<p class="muted" style="margin:6px 0">(none)</p>'
        items = []
        for r in rows[:n]:
            extra = []
            if r.get("critical_secret_count"):
                extra.append(f'{r["critical_secret_count"]} secret(s)')
            if r.get("unicode_chars"):
                extra.append(f'{r["unicode_chars"]} non-ASCII')
            if r.get("dirty"):
                extra.append(f'{r.get("dirty_files", 0)} dirty')
            if "NO_REMOTE" in (r.get("gaps") or []):
                extra.append("no remote")
            tail = (' <span class="muted">-- ' + ", ".join(extra) + "</span>") if extra else ""
            items.append(f'<li><span class="path">{html.escape(r["name"])}</span>{tail}</li>')
        more = ""
        if len(rows) > n:
            more = f'<li class="muted">+ {len(rows) - n} more</li>'
        return "<ul>" + "".join(items) + more + "</ul>"

    cards = f"""
    <div class="grid">
      <div class="card crit">
        <div class="label">Critical</div>
        <div class="value">{len(by_tier['critical'])}</div>
        <div class="footnote">leaked secrets, no remote, unreachable</div>
      </div>
      <div class="card warn">
        <div class="label">Hygiene</div>
        <div class="value">{len(by_tier['hygiene'])}</div>
        <div class="footnote">README, unicode, CI, dirty, behind</div>
      </div>
      <div class="card info">
        <div class="label">Cosmetic</div>
        <div class="value">{len(by_tier['cosmetic'])}</div>
        <div class="footnote">SSH-only, mapping, mirror suggestions</div>
      </div>
      <div class="card ok">
        <div class="label">Git-clean</div>
        <div class="value">{len(by_tier['clean'])}</div>
        <div class="footnote">git state clean AND no other gaps</div>
      </div>
      <div class="card crit">
        <div class="label">Critical secret findings</div>
        <div class="value">{total_crit_findings}</div>
        <div class="footnote">across all repos</div>
      </div>
      <div class="card warn">
        <div class="label">Non-repo / loose</div>
        <div class="value">{len(non_repos) + len(loose)}</div>
        <div class="footnote">workspace items needing a decision</div>
      </div>
    </div>
    """

    tc_block = _render_toolchain_block(toolchain)

    return f"""
    <h2 id="overview-summary">Workspace summary</h2>
    <p class="sub">{n_repos} repo(s) audited. Repos can fall into multiple tiers; each repo is
    assigned its highest-severity tier.</p>
    {cards}

    {tc_block}

    <h2 id="overview-critical">Top: Critical ({len(by_tier['critical'])})</h2>
    <p class="sub">Stop and fix before the next push. Anything here means a leaked secret or a remote you can't reach.</p>
    {_top_n(by_tier['critical'])}

    <h2 id="overview-hygiene">Top: Hygiene ({len(by_tier['hygiene'])})</h2>
    <p class="sub">Should fix; not push-blocking. Missing README, non-ASCII source, dirty trees, missing CI baseline.</p>
    {_top_n(by_tier['hygiene'])}

    <h2 id="overview-cosmetic">Top: Cosmetic ({len(by_tier['cosmetic'])})</h2>
    <p class="sub">Standardise when convenient. SSH-only auth, unmapped GitHub repos, unmirrored Gitea repos.</p>
    {_top_n(by_tier['cosmetic'])}
    """


def _render_toolchain_block(tc: dict | None) -> str:
    if not tc:
        return ""
    git = tc.get("git") or {}
    gh = tc.get("gh") or {}
    creds = tc.get("credentials") or {}
    issues = tc.get("issues") or []
    auth_str = ("authed as " + (gh.get("user") or "?")) if gh.get("authenticated") \
        else "not authenticated"
    helpers = creds.get("helpers") or []
    helper_str = ", ".join(helpers) if helpers else "(none configured)"
    cred_tag_cls = ("ok" if creds.get("uses_os_keychain")
                    else "crit" if creds.get("uses_plaintext_store")
                    else "warn")
    cred_tag_text = ("OS keychain" if creds.get("uses_os_keychain")
                     else "PLAINTEXT" if creds.get("uses_plaintext_store")
                     else "other")
    issues_html = ""
    if issues:
        issues_html = ('<ul>' +
                       "".join(f'<li>{html.escape(i)}</li>' for i in issues) +
                       '</ul>')
    severity = "warn" if issues else "ok"
    head = "Issues found" if issues else "Toolchain looks healthy"
    return f"""
    <h2 id="overview-toolchain">Toolchain</h2>
    <div class="banner {severity}">
      <h3>{head}</h3>
      <p>
        <span class="tag {'ok' if git.get('installed') else 'crit'}">git</span>
        <span class="muted">{html.escape(str(git.get('version') or '?'))}</span>
        &nbsp;
        <span class="tag {'ok' if gh.get('installed') else 'crit'}">gh</span>
        <span class="muted">{html.escape(str(gh.get('version') or '?'))} -- {html.escape(auth_str)}</span>
        &nbsp;
        <span class="tag {cred_tag_cls}">credentials: {cred_tag_text}</span>
        <span class="muted">{html.escape(helper_str)}</span>
      </p>
      {issues_html}
    </div>
    """


# ---------- Repos tab (data injected as JSON, rendered client-side) ----------

def _repos_data_json(repos: list[dict],
                     branches_per_repo: dict) -> list[dict]:
    """Project audit entries into a compact, JSON-safe shape for the JS table."""
    out = []
    for r in repos:
        b = branches_per_repo.get(r.get("name", "")) or {}
        n_branches = len(b.get("branches") or [])
        unpushed = sum(1 for x in (b.get("branches") or []) if not x.get("on_remote"))
        proto_set = sorted(set((r.get("remote_protocols") or {}).values()))
        proto_str = ",".join(proto_set) or "(none)"
        gh_match = r.get("gh_match") or {}
        gitea_match = r.get("gitea_match") or {}
        out.append({
            "name": r.get("name", ""),
            "path": r.get("path", ""),
            "state": r.get("classification", {}).get("state") or "",
            "state_label": STATE_LABEL.get(
                r.get("classification", {}).get("state") or "", "?"),
            "strategy": r.get("classification", {}).get("strategy") or "",
            "tier": r["_risk_tier"],
            "branch": r.get("branch") or "?",
            "remotes": r.get("remotes") or {},
            "remote_protocols": r.get("remote_protocols") or {},
            "uses_ssh": bool(r.get("uses_ssh")),
            "has_readme": r.get("has_readme") if r.get("has_readme") is not None else True,
            "dirty": bool(r.get("dirty")),
            "dirty_files": int(r.get("dirty_files", 0) or 0),
            "ahead": int(r.get("ahead", 0) or 0),
            "behind": int(r.get("behind", 0) or 0),
            "commits": int(r.get("commits", 0) or 0),
            "size_mb": float(r.get("size_mb", 0) or 0),
            "file_count": int(r.get("file_count", 0) or 0),
            "n_branches": n_branches,
            "unpushed_branches": unpushed,
            "unicode_chars": int(r.get("unicode_chars", 0) or 0),
            "unicode_files": int(r.get("unicode_files", 0) or 0),
            "missing_workflows": list(r.get("missing_workflows") or []),
            "critical_secret_count": int(r.get("critical_secret_count", 0) or 0),
            "total_findings": int(r.get("total_findings", 0) or 0),
            "high_findings": int(r.get("high_findings", 0) or 0),
            "gh_match_owner": gh_match.get("nameWithOwner") or "",
            "gh_match_url": gh_match.get("url") or "",
            "gitea_match_full": gitea_match.get("full_name") or "",
            "gitea_mirrored": bool(r.get("gitea_mirrored")),
            "proto_str": proto_str,
            "last_commit": r.get("last_commit", "") or "",
            "gaps": list(r.get("gaps") or []),
        })
    return out


# ---------- Findings tab ----------

def _render_findings(secrets_per_repo: dict | None) -> str:
    if not secrets_per_repo:
        return '<p class="muted">No secret-scan data attached to this report.</p>'
    sev_rank = {"critical": 0, "high": 1, "info": 2}

    items_with_findings: list[tuple[str, list[dict]]] = []
    for repo, findings in secrets_per_repo.items():
        if not findings:
            continue
        items_with_findings.append((repo, findings))

    if not items_with_findings:
        return ('<div class="banner ok"><h3>No findings</h3>'
                '<p>The secret scanner found nothing across any audited repo.</p></div>')

    items_with_findings.sort(
        key=lambda kv: (
            -sum(1 for f in kv[1] if f.get("severity") == "critical"),
            -sum(1 for f in kv[1] if f.get("severity") == "high"),
            kv[0],
        ),
    )

    rendered = []
    for repo, findings in items_with_findings:
        crit = sum(1 for f in findings if f.get("severity") == "critical")
        high = sum(1 for f in findings if f.get("severity") == "high")
        info_n = sum(1 for f in findings if f.get("severity") == "info")
        # Group findings by category
        by_cat: dict[str, list[dict]] = {}
        for f in findings:
            by_cat.setdefault(f.get("category", "?"), []).append(f)

        cat_blocks = []
        for cat, group in sorted(by_cat.items(),
                                  key=lambda kv: (sev_rank.get(
                                      kv[1][0].get("severity") or "info", 99),
                                      kv[0])):
            sev = group[0].get("severity", "info")
            sev_cls = {"critical": "crit", "high": "warn",
                        "info": "info"}.get(sev, "info")
            rows = []
            for f in sorted(group, key=lambda x: (x.get("path", ""),
                                                    x.get("line", 0)))[:200]:
                rows.append(
                    f'<tr>'
                    f'<td><span class="path">{html.escape(f.get("path", ""))}'
                    f':{f.get("line", "")}</span></td>'
                    f'<td><code>{html.escape(f.get("excerpt", ""))}</code></td>'
                    f'<td><span class="muted">{html.escape(f.get("note", ""))}</span></td>'
                    f'</tr>')
            if len(group) > 200:
                rows.append(
                    f'<tr><td colspan="3" class="muted">'
                    f'(+ {len(group) - 200} more not shown; see secrets/{html.escape(repo)}.json)</td></tr>')
            cat_blocks.append(f"""
            <h3><span class="tag {sev_cls}">{html.escape(sev)}</span>
                {html.escape(cat)} ({len(group)})</h3>
            <table>
              <thead><tr><th>Location</th><th>Excerpt (masked)</th><th>Note</th></tr></thead>
              <tbody>{''.join(rows)}</tbody>
            </table>
            """)

        sev_summary = []
        if crit:
            sev_summary.append(f'<span class="tag crit">{crit} critical</span>')
        if high:
            sev_summary.append(f'<span class="tag warn">{high} high</span>')
        if info_n:
            sev_summary.append(f'<span class="tag info">{info_n} info</span>')

        rendered.append(f"""
        <details{' open' if crit else ''}>
          <summary>
            <strong>{html.escape(repo)}</strong>
            {' '.join(sev_summary)}
          </summary>
          <div class="body">{''.join(cat_blocks)}</div>
        </details>
        """)

    return ("<p class=\"sub\">All excerpts have the actual secret value replaced with "
            "<code>&lt;REDACTED&gt;</code> at scan time. This page is metadata-only.</p>"
            + "".join(rendered))


# ---------- Branches tab ----------

def _render_branches(repos: list[dict], branches_per_repo: dict) -> str:
    rows = []
    n_with_drift = 0
    for r in sorted(repos, key=lambda x: x.get("name", "")):
        name = r.get("name", "")
        b = branches_per_repo.get(name)
        if not b or not b.get("branches"):
            continue
        any_unpushed = any(not br.get("on_remote") for br in b["branches"])
        any_lag = any(int(br.get("ahead_of_origin", 0) or 0)
                      + int(br.get("behind_origin", 0) or 0) > 0
                      for br in b["branches"])
        any_dirty = bool(r.get("dirty"))
        if not (any_unpushed or any_lag or any_dirty):
            continue
        n_with_drift += 1
        n_branches = len(b["branches"])
        dirty_files = r.get("dirty_files", 0) if any_dirty else 0
        rows.append(
            f'<tr class="group-row"><td colspan="4">{html.escape(name)}'
            f' &mdash; {n_branches} branch{"es" if n_branches != 1 else ""}'
            + (f", {dirty_files} uncommitted file(s)" if dirty_files else "")
            + '</td></tr>')
        for br in sorted(b["branches"], key=lambda x: (
                not x.get("on_remote"),
                -int(x.get("ahead_of_origin", 0) or 0),
                x.get("name", ""))):
            ahead = int(br.get("ahead_of_origin", 0) or 0)
            behind = int(br.get("behind_origin", 0) or 0)
            tags = []
            if not br.get("on_remote"):
                tags.append('<span class="tag warn">unpushed</span>')
            if ahead:
                tags.append(f'<span class="tag warn">+{ahead}</span>')
            if behind:
                tags.append(f'<span class="tag warn">-{behind}</span>')
            if not tags:
                tags.append('<span class="tag ok">in sync</span>')
            rows.append(
                f'<tr><td><span class="path">{html.escape(br.get("name", ""))}</span></td>'
                f'<td>{"".join(tags)}</td>'
                f'<td><span class="commit">{html.escape(br.get("last_commit", ""))}</span></td>'
                f'<td></td></tr>')
    if not rows:
        return ('<div class="banner ok"><h3>All branches in sync</h3>'
                '<p>Every audited repo has a clean working tree, no unpushed branches, '
                'and no main-vs-feature drift.</p></div>')
    return f"""
    <p class="sub">{n_with_drift} repo{'s' if n_with_drift != 1 else ''} with branch drift.</p>
    <table>
      <thead><tr><th>Branch</th><th>Sync</th><th>Last commit</th><th></th></tr></thead>
      <tbody>{''.join(rows)}</tbody>
    </table>"""


# ---------- Plan tab ----------

def _flatten_plan_data(plan_entries: list[dict] | None) -> list[dict]:
    if not plan_entries:
        return []
    flat: list[dict] = []
    for p in plan_entries:
        for a in p.get("actions") or []:
            flat.append({
                "repo": p.get("name", ""),
                "state": p.get("state", ""),
                "kind": a.get("kind", ""),
                "description": a.get("description", ""),
                "destructive": bool(a.get("destructive")),
                "risk_level": a.get("risk_level") or "none",
            })
    return flat


# Display labels for risk_level (kept short for tag pills).
_RISK_LABEL: dict[str, tuple[str, str]] = {
    # value -> (css_class, label)
    "none":            ("ok",   "read-only"),
    "writes_file":     ("info", "writes file"),
    "rewrites_files":  ("warn", "rewrites files"),
    "git_state":       ("warn", "git state"),
    "publish":         ("crit", "publishes"),
}


# ---------- main render ----------

def render(data: list[dict], *, title: str = "Code audit",
           secrets_per_repo: dict | None = None,
           branches_per_repo: dict | None = None,
           toolchain: dict | None = None,
           plan: list[dict] | None = None) -> str:
    """Render an audit JSON list into a single self-contained HTML string."""
    branches_per_repo = branches_per_repo or {}
    secrets_per_repo = secrets_per_repo or {}

    for x in data:
        _tag_status(x)

    repos     = [x for x in data if x.get("type") == "repo"]
    non_repos = [x for x in data if x.get("type") == "non_repo"]
    loose     = [x for x in data if x.get("type") == "loose_file"]

    # Compute risk tier per repo (used by overview + repos tab)
    for r in repos:
        r["_risk_tier"] = _risk_tier(r)

    # Secrets summary for overview
    total_crit = sum(sum(1 for f in v if f.get("severity") == "critical")
                     for v in secrets_per_repo.values())
    total_high = sum(sum(1 for f in v if f.get("severity") == "high")
                     for v in secrets_per_repo.values())
    secrets_summary = {"total_critical": total_crit, "total_high": total_high}

    # ---- per-tab content ----
    overview_html = _render_overview(repos, non_repos, loose, toolchain, secrets_summary)
    findings_html = _render_findings(secrets_per_repo)
    branches_html = _render_branches(repos, branches_per_repo)
    repos_data_json = json.dumps(_repos_data_json(repos, branches_per_repo),
                                 default=str)
    plan_data_json  = json.dumps(_flatten_plan_data(plan), default=str)

    # Non-repo / loose section is inside the Repos tab as a secondary table
    nonrepo_rows = "".join(
        f'<tr><td><span class="path">{html.escape(r.get("name", ""))}</span></td>'
        f'<td>{r.get("file_count", 0)} files</td>'
        f'<td>{r.get("size_mb", 0)} MB</td>'
        f'<td>{_gap_tags_html(r.get("gaps", []))}</td></tr>'
        for r in sorted(non_repos,
                        key=lambda x: (-x.get("file_count", 0), x.get("name", ""))))
    loose_rows = "".join(
        f'<tr><td><span class="path">{html.escape(r.get("name", ""))}</span></td>'
        f'<td>{r.get("size_mb", 0)} MB</td>'
        f'<td>{_gap_tags_html(r.get("gaps", []))}</td></tr>'
        for r in sorted(loose, key=lambda x: x.get("name", "")))

    # ---- toolchain tab body (separate from overview's compact block) ----
    tc_tab = _render_toolchain_block(toolchain) if toolchain else \
        '<p class="muted">No toolchain data attached to this report.</p>'

    # ---- frame: tabs + sidebar + main pane ----
    n_repos = len(repos)
    n_nonrepo = len(non_repos)
    n_loose = len(loose)
    n_findings_repos = sum(1 for v in secrets_per_repo.values() if v)
    n_plan_actions = len(_flatten_plan_data(plan))

    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    sidebars = {
        "overview": [
            ("overview-summary",   "Summary"),
            ("overview-toolchain", "Toolchain"),
            ("overview-critical",  "Top: Critical"),
            ("overview-hygiene",   "Top: Hygiene"),
            ("overview-cosmetic",  "Top: Cosmetic"),
        ],
        "repos": [
            ("repos-table",   "Repos"),
            ("repos-nonrepo", "Non-repo dirs"),
            ("repos-loose",   "Loose files"),
        ],
        "findings": [
            ("findings-list", "Per-repo findings"),
        ],
        "branches": [
            ("branches-table", "Drift table"),
        ],
        "plan": [
            ("plan-table", "Action list"),
        ],
        "toolchain": [
            ("toolchain-detail", "Detail"),
        ],
    }

    def _sidebar_for(tab: str) -> str:
        items = sidebars.get(tab, [])
        if not items:
            return ""
        lis = "".join(f'<li><a href="#{i}">{html.escape(label)}</a></li>'
                      for i, label in items)
        return (f'<div class="group" data-side="{tab}">'
                f'<p class="group-title">{tab}</p><ul>{lis}</ul></div>')

    sidebar_html = "".join(_sidebar_for(k) for k in sidebars)

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{html.escape(title)} -- {html.escape(now)}</title>
<style>{_CSS}</style>
</head>
<body>
<header>
  <h1>{html.escape(title)}</h1>
  <div class="sub">Generated {html.escape(now)}</div>
  <nav class="tabs" id="tabs">
    <button data-tab="overview"  class="active">Overview</button>
    <button data-tab="repos">Repos <span class="pill">{n_repos}</span></button>
    <button data-tab="findings">Findings <span class="pill">{n_findings_repos}</span></button>
    <button data-tab="branches">Branches</button>
    <button data-tab="plan">Plan <span class="pill">{n_plan_actions}</span></button>
    <button data-tab="toolchain">Toolchain</button>
  </nav>
</header>

<div class="layout">
  <aside class="sidebar" id="sidebar">{sidebar_html}</aside>
  <main class="tabbed">

    <section class="tab-content active" data-tab="overview">
      {overview_html}
    </section>

    <section class="tab-content" data-tab="repos">
      <h2 id="repos-table">Repos ({n_repos})</h2>
      <div class="toolbar" id="repos-toolbar">
        <label>Filter:</label>
        <span class="chip" data-filter="tier:critical">Critical</span>
        <span class="chip" data-filter="tier:hygiene">Hygiene</span>
        <span class="chip" data-filter="tier:cosmetic">Cosmetic</span>
        <span class="chip" data-filter="tier:clean">Git-clean</span>
        <span class="chip" data-filter="has:secrets" title="any severity, any category">Has any findings</span>
        <span class="chip" data-filter="has:critical-secrets" title="redactable critical findings only (excludes xor_obfuscation)">Has critical secrets</span>
        <span class="chip" data-filter="has:unicode">Has unicode</span>
        <span class="chip" data-filter="missing:readme">No README</span>
        <span class="chip" data-filter="proto:ssh">SSH-only</span>
        <span class="chip" data-filter="dirty">Dirty</span>
        <span class="chip" data-filter="missing:remote">No remote</span>
        <button id="repos-reset" style="background:#21262d; color:#e3b341; border:1px solid #6e5500; border-radius:16px; padding:4px 12px; font-size:12px; cursor:pointer">Reset filters</button>
        <span class="spacer"></span>
        <label for="repos-group">Group by:</label>
        <select id="repos-group">
          <option value="">(none)</option>
          <option value="tier" selected>risk tier</option>
          <option value="state_label">git state</option>
          <option value="strategy">strategy</option>
          <option value="proto_str">protocol</option>
        </select>
        <input type="text" id="repos-search" placeholder="search by name..."
               style="width: 180px"/>
      </div>
      <table id="repos-table-el">
        <thead>
          <tr>
            <th class="sortable" data-sort="name">Repo</th>
            <th class="sortable" data-sort="state_label">State</th>
            <th class="sortable" data-sort="tier">Tier</th>
            <th>Remote</th>
            <th class="sortable" data-sort="n_branches">Branches</th>
            <th class="sortable" data-sort="critical_secret_count">Secrets</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody id="repos-tbody"></tbody>
      </table>
      <div class="pagination" id="repos-pagination"></div>

      <h2 id="repos-nonrepo">Non-repo directories ({n_nonrepo})</h2>
      <table>
        <thead><tr><th>Path</th><th>Files</th><th>Size</th><th>Status</th></tr></thead>
        <tbody>{nonrepo_rows or '<tr class="empty-row"><td colspan="4">none</td></tr>'}</tbody>
      </table>

      <h2 id="repos-loose">Loose files at root ({n_loose})</h2>
      <table>
        <thead><tr><th>File</th><th>Size</th><th>Status</th></tr></thead>
        <tbody>{loose_rows or '<tr class="empty-row"><td colspan="3">none</td></tr>'}</tbody>
      </table>
    </section>

    <section class="tab-content" data-tab="findings">
      <h2 id="findings-list">Per-repo secret findings</h2>
      <div class="toolbar">
        <button id="findings-expand"   style="background:#21262d; color:#79c0ff; border:1px solid #2a4a6e; border-radius:16px; padding:4px 12px; font-size:12px; cursor:pointer">Expand all</button>
        <button id="findings-collapse" style="background:#21262d; color:#8b949e; border:1px solid #30363d; border-radius:16px; padding:4px 12px; font-size:12px; cursor:pointer">Collapse all</button>
      </div>
      {findings_html}
    </section>

    <section class="tab-content" data-tab="branches">
      <h2 id="branches-table">Branch sync depth</h2>
      {branches_html}
    </section>

    <section class="tab-content" data-tab="plan">
      <h2 id="plan-table">Remediation actions</h2>
      <p class="sub">'Risk level' answers: what kind of side effect does this action have? Read-only is safest; "publishes" is the only level that makes data visible to others.</p>
      <div class="toolbar" id="plan-toolbar">
        <label>Risk:</label>
        <span class="chip" data-pfilter="risk:none"             title="read-only or writes outside the repo">Read-only</span>
        <span class="chip" data-pfilter="risk:writes_file"      title="adds a new working-tree file (trivially reversible)">Writes file</span>
        <span class="chip" data-pfilter="risk:rewrites_files"   title="modifies existing files in place; reversible via git history">Rewrites files</span>
        <span class="chip" data-pfilter="risk:git_state"        title="local git state change (init, commit, remote add); local-only, all undoable">Git state</span>
        <span class="chip" data-pfilter="risk:publish"          title="visible to others; hard to fully recall">Publishes</span>
        <span class="spacer"></span>
        <label for="plan-group">Group by:</label>
        <select id="plan-group">
          <option value="">(none)</option>
          <option value="risk_level" selected>risk level</option>
          <option value="kind">action kind</option>
          <option value="repo">repo</option>
          <option value="state">git state</option>
        </select>
        <input type="text" id="plan-search" placeholder="search..."
               style="width: 180px"/>
      </div>
      <table id="plan-table-el">
        <thead>
          <tr>
            <th class="sortable" data-sort="repo">Repo</th>
            <th class="sortable" data-sort="kind">Action</th>
            <th>Description</th>
            <th class="sortable" data-sort="risk_level">Risk level</th>
          </tr>
        </thead>
        <tbody id="plan-tbody"></tbody>
      </table>
    </section>

    <section class="tab-content" data-tab="toolchain">
      <div id="toolchain-detail">{tc_tab}</div>
    </section>

  </main>
</div>

<script id="repos-data" type="application/json">{repos_data_json}</script>
<script id="plan-data"  type="application/json">{plan_data_json}</script>

<script>
{_JS}
</script>
</body>
</html>
"""


# ---------- embedded JS ----------

_JS = r"""
(function () {
  'use strict';

  // ---------- tab switching ----------
  const tabs = document.querySelectorAll('#tabs button');
  const sections = document.querySelectorAll('main.tabbed > section.tab-content');
  const sideGroups = document.querySelectorAll('aside .group');

  function selectTab(name) {
    tabs.forEach(b => b.classList.toggle('active', b.dataset.tab === name));
    sections.forEach(s => s.classList.toggle('active', s.dataset.tab === name));
    sideGroups.forEach(g => g.style.display = (g.dataset.side === name ? '' : 'none'));
    history.replaceState(null, '', '#tab=' + name);
  }
  tabs.forEach(b => b.addEventListener('click', () => selectTab(b.dataset.tab)));
  // honour ?#tab=foo on load
  const m = (location.hash || '').match(/tab=(\w+)/);
  selectTab(m ? m[1] : 'overview');

  // ---------- helpers ----------
  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  // ---------- Repos tab interactivity ----------
  const reposData = JSON.parse(document.getElementById('repos-data').textContent || '[]');
  const reposState = {
    filters: new Set(['tier:critical', 'tier:hygiene', 'tier:cosmetic', 'tier:clean']),
    search: '',
    group: 'tier',
    sortKey: 'tier',
    sortAsc: true,
    page: 1,
    pageSize: 50,
  };
  // Filter chips reflect what's ACTIVE; on first paint all tier chips are
  // visually inactive (so user sees the full list) but the underlying set
  // includes everything. To make the UI honest, treat empty filter set or
  // full filter set as "show all", and any other subset as "active filter".
  function startActiveChips() {
    document.querySelectorAll('#repos-toolbar .chip').forEach(ch => {
      ch.addEventListener('click', () => {
        const f = ch.dataset.filter;
        if (reposState.filters.has(f)) reposState.filters.delete(f);
        else                            reposState.filters.add(f);
        ch.classList.toggle('active');
        reposState.page = 1;
        renderRepos();
      });
    });
    // start with no chips selected -> show all
    reposState.filters = new Set();
  }

  function repoMatchesFilters(r) {
    const fs = reposState.filters;
    if (fs.size === 0) return true;
    let tierFilters = [];
    let positive = true;
    for (const f of fs) {
      if (f.startsWith('tier:')) tierFilters.push(f.slice(5));
    }
    if (tierFilters.length && !tierFilters.includes(r.tier)) return false;
    if (fs.has('has:secrets') && !(r.total_findings > 0)) return false;
    if (fs.has('has:critical-secrets') && !(r.critical_secret_count > 0)) return false;
    if (fs.has('has:unicode') && !(r.unicode_chars > 0)) return false;
    if (fs.has('missing:readme') && r.has_readme !== false) return false;
    if (fs.has('proto:ssh') && !r.uses_ssh) return false;
    if (fs.has('dirty') && !r.dirty) return false;
    if (fs.has('missing:remote') && Object.keys(r.remotes || {}).length > 0) return false;
    return true;
  }

  function repoMatchesSearch(r) {
    if (!reposState.search) return true;
    const q = reposState.search.toLowerCase();
    return (r.name || '').toLowerCase().includes(q)
        || (r.path || '').toLowerCase().includes(q);
  }

  function rowClassForRepo(r) {
    if (r.tier === 'critical') return 'row-crit';
    if (r.tier === 'hygiene')  return 'row-warn';
    return '';
  }

  function tierTag(t) {
    const cls = {critical: 'crit', hygiene: 'warn', cosmetic: 'info', clean: 'ok'}[t] || 'muted';
    return `<span class="tag ${cls}">${escapeHtml(t)}</span>`;
  }

  function remoteCell(r) {
    const remotes = r.remotes || {};
    const protocols = r.remote_protocols || {};
    if (Object.keys(remotes).length === 0) {
      if (r.gh_match_owner) {
        return `<span class="muted">no remote --</span> <span class="tag info">would map -&gt; <a href="${escapeHtml(r.gh_match_url)}" style="color:#79c0ff">${escapeHtml(r.gh_match_owner)}</a></span>`;
      }
      return '<span class="muted">--</span>';
    }
    const lines = [];
    for (const [name, url] of Object.entries(remotes)) {
      const proto = protocols[name] || 'other';
      const protoCls = proto === 'https' ? 'ok' : (proto === 'ssh' ? 'warn' : 'info');
      const safeUrl = url.startsWith('http') ? escapeHtml(url) : '#';
      lines.push(`<span class="path">${escapeHtml(name)}: <a href="${safeUrl}" style="color:#79c0ff">${escapeHtml(url)}</a></span> <span class="tag ${protoCls}">${escapeHtml(proto.toUpperCase())}</span>`);
    }
    return lines.join('<br>');
  }

  function branchesCell(r) {
    if (!r.n_branches) return '<span class="muted">--</span>';
    const parts = [`${r.n_branches} branch${r.n_branches !== 1 ? 'es' : ''}`];
    if (r.unpushed_branches > 0) parts.push(`<span class="tag warn">${r.unpushed_branches} unpushed</span>`);
    return parts.join(' ');
  }

  function statusCell(r) {
    const tags = [];
    if (r.dirty)       tags.push(`<span class="tag warn">dirty (${r.dirty_files})</span>`);
    if (r.ahead)       tags.push(`<span class="tag warn">+${r.ahead}</span>`);
    if (r.behind)      tags.push(`<span class="tag warn">-${r.behind}</span>`);
    if (r.uses_ssh)    tags.push('<span class="tag warn">SSH</span>');
    if (r.has_readme === false) tags.push('<span class="tag warn">no README</span>');
    if (r.unicode_chars) tags.push(`<span class="tag warn">${r.unicode_chars} non-ASCII</span>`);
    if (r.critical_secret_count) tags.push(`<span class="tag crit">${r.critical_secret_count} secret(s)</span>`);
    if ((r.missing_workflows || []).length) tags.push(`<span class="tag warn">no CI: ${(r.missing_workflows || []).join(', ')}</span>`);
    if (!tags.length) tags.push('<span class="tag ok">ok</span>');
    return tags.join(' ');
  }

  function repoRow(r) {
    return `<tr class="${rowClassForRepo(r)}">
      <td><strong>${escapeHtml(r.name)}</strong><br>
          <span class="muted">${r.commits} commits * ${r.size_mb} MB * ${r.file_count} files</span></td>
      <td>${escapeHtml(r.state_label)}</td>
      <td>${tierTag(r.tier)}</td>
      <td>${remoteCell(r)}</td>
      <td>${branchesCell(r)}</td>
      <td>${r.critical_secret_count > 0
            ? `<span class="tag crit">${r.critical_secret_count} crit</span>`
            : (r.total_findings > 0
                ? `<span class="tag warn">${r.total_findings} total</span>`
                : '<span class="muted">0</span>')}</td>
      <td>${statusCell(r)}</td>
    </tr>`;
  }

  function tierOrder(t) {
    return ({critical: 0, hygiene: 1, cosmetic: 2, clean: 3})[t] ?? 9;
  }

  function compareRepos(a, b) {
    const k = reposState.sortKey;
    let av = a[k], bv = b[k];
    if (k === 'tier') { av = tierOrder(av); bv = tierOrder(bv); }
    if (typeof av === 'string') av = av.toLowerCase();
    if (typeof bv === 'string') bv = bv.toLowerCase();
    if (av === bv) return 0;
    return ((av < bv ? -1 : 1)) * (reposState.sortAsc ? 1 : -1);
  }

  function renderRepos() {
    const filtered = reposData.filter(r => repoMatchesFilters(r) && repoMatchesSearch(r));
    filtered.sort(compareRepos);

    // Group + paginate
    const tbody = document.getElementById('repos-tbody');
    if (filtered.length === 0) {
      tbody.innerHTML = '<tr class="empty-row"><td colspan="7">No repos match the current filters.</td></tr>';
      document.getElementById('repos-pagination').innerHTML = '';
      return;
    }

    const totalPages = Math.max(1, Math.ceil(filtered.length / reposState.pageSize));
    if (reposState.page > totalPages) reposState.page = totalPages;
    const start = (reposState.page - 1) * reposState.pageSize;
    const pageRows = filtered.slice(start, start + reposState.pageSize);

    let html = '';
    if (reposState.group) {
      const buckets = new Map();
      for (const r of pageRows) {
        const key = (reposState.group === 'tier')
          ? r.tier
          : (r[reposState.group] || '(none)');
        if (!buckets.has(key)) buckets.set(key, []);
        buckets.get(key).push(r);
      }
      const keys = [...buckets.keys()];
      if (reposState.group === 'tier') {
        keys.sort((a, b) => tierOrder(a) - tierOrder(b));
      } else {
        keys.sort();
      }
      for (const k of keys) {
        html += `<tr class="group-row"><td colspan="7">${escapeHtml(reposState.group)}: ${escapeHtml(k)} (${buckets.get(k).length})</td></tr>`;
        for (const r of buckets.get(k)) html += repoRow(r);
      }
    } else {
      for (const r of pageRows) html += repoRow(r);
    }
    tbody.innerHTML = html;

    // Pagination
    const pag = document.getElementById('repos-pagination');
    pag.innerHTML = `
      <button id="repos-prev"${reposState.page <= 1 ? ' disabled' : ''}>&laquo; prev</button>
      <span>Page ${reposState.page} of ${totalPages} -- ${filtered.length} repo(s)</span>
      <button id="repos-next"${reposState.page >= totalPages ? ' disabled' : ''}>next &raquo;</button>
    `;
    document.getElementById('repos-prev').onclick = () => { reposState.page--; renderRepos(); };
    document.getElementById('repos-next').onclick = () => { reposState.page++; renderRepos(); };

    // Sort indicators
    document.querySelectorAll('#repos-table-el th.sortable').forEach(th => {
      th.classList.remove('sort-asc', 'sort-desc');
      if (th.dataset.sort === reposState.sortKey) {
        th.classList.add(reposState.sortAsc ? 'sort-asc' : 'sort-desc');
      }
    });
  }

  startActiveChips();
  document.getElementById('repos-reset').addEventListener('click', () => {
    reposState.filters = new Set();
    reposState.search = '';
    reposState.page = 1;
    document.querySelectorAll('#repos-toolbar .chip').forEach(c => c.classList.remove('active'));
    document.getElementById('repos-search').value = '';
    renderRepos();
  });
  document.getElementById('repos-search').addEventListener('input', e => {
    reposState.search = e.target.value;
    reposState.page = 1;
    renderRepos();
  });
  document.getElementById('repos-group').addEventListener('change', e => {
    reposState.group = e.target.value;
    renderRepos();
  });
  document.querySelectorAll('#repos-table-el th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const k = th.dataset.sort;
      if (reposState.sortKey === k) reposState.sortAsc = !reposState.sortAsc;
      else { reposState.sortKey = k; reposState.sortAsc = true; }
      renderRepos();
    });
  });
  renderRepos();

  // ---------- Findings tab: expand-all / collapse-all ----------
  const expandBtn = document.getElementById('findings-expand');
  const collapseBtn = document.getElementById('findings-collapse');
  if (expandBtn) {
    expandBtn.addEventListener('click', () => {
      document.querySelectorAll('section[data-tab="findings"] details')
        .forEach(d => d.open = true);
    });
  }
  if (collapseBtn) {
    collapseBtn.addEventListener('click', () => {
      document.querySelectorAll('section[data-tab="findings"] details')
        .forEach(d => d.open = false);
    });
  }

  // ---------- Plan tab interactivity ----------
  const planData = JSON.parse(document.getElementById('plan-data').textContent || '[]');
  const RISK_LABEL = {
    none:            ['ok',   'read-only'],
    writes_file:     ['info', 'writes file'],
    rewrites_files:  ['warn', 'rewrites files'],
    git_state:       ['warn', 'git state'],
    publish:         ['crit', 'publishes'],
  };
  const RISK_ORDER = {none: 0, writes_file: 1, rewrites_files: 2, git_state: 3, publish: 4};
  const planState = {
    riskFilters: new Set(),  // set of risk_level values; empty = show all
    search: '',
    group: 'risk_level',
    sortKey: 'risk_level',
    sortAsc: true,
  };

  function planMatches(p) {
    if (planState.riskFilters.size > 0 && !planState.riskFilters.has(p.risk_level)) return false;
    if (planState.search) {
      const q = planState.search.toLowerCase();
      if (!(p.repo + ' ' + p.kind + ' ' + p.description).toLowerCase().includes(q)) return false;
    }
    return true;
  }

  function comparePlan(a, b) {
    const k = planState.sortKey;
    let av = a[k], bv = b[k];
    if (k === 'risk_level') { av = RISK_ORDER[av] ?? 9; bv = RISK_ORDER[bv] ?? 9; }
    if (typeof av === 'string') av = av.toLowerCase();
    if (typeof bv === 'string') bv = bv.toLowerCase();
    if (av === bv) return 0;
    return ((av < bv ? -1 : 1)) * (planState.sortAsc ? 1 : -1);
  }

  function planRow(p) {
    const [cls, label] = RISK_LABEL[p.risk_level] || ['muted', p.risk_level || '?'];
    const rowCls = (p.risk_level === 'publish') ? 'row-crit'
                 : (p.risk_level === 'rewrites_files' || p.risk_level === 'git_state') ? 'row-warn'
                 : '';
    return `<tr class="${rowCls}">
      <td><strong>${escapeHtml(p.repo)}</strong> <span class="muted">${escapeHtml(p.state)}</span></td>
      <td><span class="tag info">${escapeHtml(p.kind)}</span></td>
      <td>${escapeHtml(p.description)}</td>
      <td><span class="tag ${cls}">${escapeHtml(label)}</span></td>
    </tr>`;
  }

  function renderPlan() {
    const filtered = planData.filter(planMatches);
    filtered.sort(comparePlan);
    const tbody = document.getElementById('plan-tbody');
    if (filtered.length === 0) {
      tbody.innerHTML = '<tr class="empty-row"><td colspan="4">No actions match.</td></tr>';
      return;
    }
    let html = '';
    if (planState.group) {
      const buckets = new Map();
      for (const p of filtered) {
        const k = p[planState.group] || '(none)';
        if (!buckets.has(k)) buckets.set(k, []);
        buckets.get(k).push(p);
      }
      let keys = [...buckets.keys()];
      if (planState.group === 'risk_level') {
        keys.sort((a, b) => (RISK_ORDER[a] ?? 9) - (RISK_ORDER[b] ?? 9));
      } else {
        keys.sort();
      }
      for (const k of keys) {
        const labelTxt = (planState.group === 'risk_level' && RISK_LABEL[k])
          ? RISK_LABEL[k][1] : k;
        html += `<tr class="group-row"><td colspan="4">${escapeHtml(planState.group)}: ${escapeHtml(labelTxt)} (${buckets.get(k).length})</td></tr>`;
        for (const p of buckets.get(k)) html += planRow(p);
      }
    } else {
      for (const p of filtered) html += planRow(p);
    }
    tbody.innerHTML = html;
    document.querySelectorAll('#plan-table-el th.sortable').forEach(th => {
      th.classList.remove('sort-asc', 'sort-desc');
      if (th.dataset.sort === planState.sortKey) {
        th.classList.add(planState.sortAsc ? 'sort-asc' : 'sort-desc');
      }
    });
  }

  document.querySelectorAll('#plan-toolbar .chip').forEach(ch => {
    ch.addEventListener('click', () => {
      const f = ch.dataset.pfilter;
      if (!f || !f.startsWith('risk:')) return;
      const value = f.slice(5);
      if (planState.riskFilters.has(value)) planState.riskFilters.delete(value);
      else                                  planState.riskFilters.add(value);
      ch.classList.toggle('active');
      renderPlan();
    });
  });
  document.getElementById('plan-search').addEventListener('input', e => {
    planState.search = e.target.value;
    renderPlan();
  });
  document.getElementById('plan-group').addEventListener('change', e => {
    planState.group = e.target.value;
    renderPlan();
  });
  document.querySelectorAll('#plan-table-el th.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const k = th.dataset.sort;
      if (planState.sortKey === k) planState.sortAsc = !planState.sortAsc;
      else { planState.sortKey = k; planState.sortAsc = true; }
      renderPlan();
    });
  });
  renderPlan();
})();
"""


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Render audit JSON to HTML.")
    ap.add_argument("--audit", default="-",
                    help="Audit JSON path (default: stdin)")
    ap.add_argument("--out", default="-",
                    help="HTML output path (default: stdout)")
    ap.add_argument("--title", default="Code audit",
                    help="Title shown in the HTML page")
    args = ap.parse_args(argv)

    if args.audit == "-":
        data = json.load(sys.stdin)
    else:
        with open(args.audit, encoding="utf-8") as f:
            data = json.load(f)

    page = render(data, title=args.title)

    if args.out == "-":
        sys.stdout.write(page)
    else:
        out_path = Path(args.out)
        out_path.write_text(page, encoding="utf-8")
        print(f"wrote {out_path} ({len(page)} bytes)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
