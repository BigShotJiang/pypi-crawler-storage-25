#!/usr/bin/env python3
"""Build a `replace.txt` for `git filter-repo --replace-text` from a harvest
directory + a repo name.

Output format (literal substitution per line, no regex):
    <SECRET_VALUE>==><REDACTED>

This is a small helper so the history-rewrite step uses exactly the same
selection logic as the working-tree redaction (`sca redact --from-harvest`):
HARVEST_ALWAYS_REDACT plus real_looking_guid entries whose context shows
they are CLIENT-ish (AppId / clientId / cert / thumbprint / secret).

Usage:
    python -m sca.build_filter_repo_replacements <harvest-dir> <repo-name> [--out <file>]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from sca.redact import PLACEHOLDER, _harvest_values_for_repo


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("harvest", help="Path to harvest output directory")
    ap.add_argument("repo_name",
                    help="Leaf name of the repo (matches harvest occurrences[].repo)")
    ap.add_argument("--out", default=None,
                    help="Output file (default: <harvest>/<repo>-replace.txt)")
    args = ap.parse_args(argv)

    harvest = Path(args.harvest).resolve()
    pairs = _harvest_values_for_repo(harvest, args.repo_name)
    if not pairs:
        print(f"[build] no values to replace for {args.repo_name}", file=sys.stderr)
        return 1

    out_path = Path(args.out) if args.out else (harvest / f"{args.repo_name}-replace.txt")
    # Use literal substitution (filter-repo default). The placeholder is
    # `<REDACTED>` -- a string that will not collide with any real secret.
    lines = []
    for category, value in pairs:
        # filter-repo forbids `==>` inside the literal but our values won't
        # contain that token. Just be defensive: skip any value that does.
        if "==>" in value:
            print(f"[build] skipping value containing '==>' "
                  f"(category={category})", file=sys.stderr)
            continue
        # Literal mode is the default when there is no `regex:` / `glob:`
        # prefix. We add an explicit `literal:` prefix so the file is
        # unambiguous and so values starting with whitespace work.
        lines.append(f"literal:{value}==>{PLACEHOLDER}")

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[build] wrote {len(lines)} replacement(s) to {out_path}",
          file=sys.stderr)
    print(str(out_path))  # stdout: just the path
    return 0


if __name__ == "__main__":
    sys.exit(main())
