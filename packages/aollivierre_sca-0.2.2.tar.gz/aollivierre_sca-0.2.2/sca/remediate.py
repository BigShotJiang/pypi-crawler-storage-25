#!/usr/bin/env python3
"""Per-state remediation: turn audit findings into concrete git/gh operations.

Two-phase design:
    plan_remediation(audit_entries) -> list[RepoPlan]   (READ-ONLY)
    execute_plan(plan, apply=False) -> ExecutionResult  (defaults to dry-run)

Safety rails baked in:
    - Dry-run by default. `apply=False` prints what would happen and stops.
    - Backup-before-modify. Any destructive op zips the working tree to
      `<repo>/../<name>.backup-<date>.zip` first.
    - Visibility-before-push gate. Before pushing to a public GitHub repo,
      run sca/secrets.scan_repo. If any critical findings, refuse the push
      and tell the user to flip the repo private (or fix the leak) first.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import zipfile
from dataclasses import asdict, dataclass, field
from datetime import date
from enum import Enum
from pathlib import Path

from sca import classify as _classify
from sca import secrets as _secrets
from sca import templates as _templates

# ---------- types ----------

class ActionKind(str, Enum):
    BACKUP            = "backup"
    APPLY_GITIGNORE   = "apply_gitignore"
    INIT_REPO         = "init_repo"
    SCAN_SECRETS      = "scan_secrets"
    COMMIT_DIRTY      = "commit_dirty"
    CREATE_GH_REPO    = "create_github_repo"
    ADD_REMOTE        = "add_remote"
    SET_REMOTE_URL    = "set_remote_url"
    MAP_TO_REMOTE     = "map_to_existing_remote"
    PUSH              = "push"
    NOTE              = "note"
    RUN_UNICODE_REPLACEMENT = "run_unicode_replacement"
    CREATE_README     = "create_readme"
    INSTALL_CI_WORKFLOW = "install_ci_workflow"
    REDACT_SECRETS    = "redact_secrets"
    ENSURE_GITEA_REMOTE = "ensure_gitea_remote"
    MIRROR_PUSH       = "mirror_push"


class RiskLevel(str, Enum):
    """How impactful is an action? Used for UI grouping and filtering.

    Stable values that downstream tools (the React app, etc.) can switch on.
    The ordering reflects severity: anything that PUBLISHes externally is
    the most consequential, anything READ-only is the least.
    """
    NONE            = "none"            # read-only, or writes outside the repo
    WRITES_FILE     = "writes_file"     # adds a new working-tree file
    REWRITES_FILES  = "rewrites_files"  # modifies existing files in place
    GIT_STATE       = "git_state"       # local git state (init / commit / remote)
    PUBLISH         = "publish"         # visible to others; hard to fully recall


# Per-kind default risk level. Used by Action(...) to set risk_level when the
# caller doesn't pass one explicitly.
RISK_LEVEL_BY_KIND: dict[ActionKind, RiskLevel] = {
    ActionKind.NOTE:                RiskLevel.NONE,
    ActionKind.SCAN_SECRETS:        RiskLevel.NONE,
    ActionKind.BACKUP:              RiskLevel.WRITES_FILE,  # writes outside repo
    ActionKind.APPLY_GITIGNORE:     RiskLevel.WRITES_FILE,
    ActionKind.CREATE_README:       RiskLevel.WRITES_FILE,
    ActionKind.INSTALL_CI_WORKFLOW: RiskLevel.WRITES_FILE,
    ActionKind.RUN_UNICODE_REPLACEMENT: RiskLevel.REWRITES_FILES,
    ActionKind.REDACT_SECRETS:      RiskLevel.REWRITES_FILES,
    ActionKind.INIT_REPO:           RiskLevel.GIT_STATE,
    ActionKind.ADD_REMOTE:          RiskLevel.GIT_STATE,
    ActionKind.SET_REMOTE_URL:      RiskLevel.GIT_STATE,
    ActionKind.MAP_TO_REMOTE:       RiskLevel.GIT_STATE,
    ActionKind.ENSURE_GITEA_REMOTE: RiskLevel.GIT_STATE,
    ActionKind.COMMIT_DIRTY:        RiskLevel.GIT_STATE,
    ActionKind.CREATE_GH_REPO:      RiskLevel.PUBLISH,
    ActionKind.PUSH:                RiskLevel.PUBLISH,
    ActionKind.MIRROR_PUSH:         RiskLevel.PUBLISH,
}


@dataclass
class Action:
    kind: ActionKind
    description: str
    # `destructive` is the dry-run gate: True means "skip unless --apply".
    # It is NOT a claim that the action causes data loss. The honest
    # impact-tier is `risk_level` below; "destructive" is kept only because
    # downstream code (and tests) use it to gate execution.
    destructive: bool = False
    # free-form parameters interpreted by the executor
    params: dict = field(default_factory=dict)
    # Impact tier. Computed from `kind` if not passed.
    risk_level: RiskLevel | None = None

    def __post_init__(self) -> None:
        if self.risk_level is None:
            self.risk_level = RISK_LEVEL_BY_KIND.get(self.kind, RiskLevel.NONE)

    def asdict(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value
        d["risk_level"] = (self.risk_level or RiskLevel.NONE).value
        return d


@dataclass
class RepoPlan:
    path: str
    name: str
    state: str
    strategy: str
    reason: str
    actions: list[Action] = field(default_factory=list)

    def asdict(self) -> dict:
        return {
            "path": self.path, "name": self.name,
            "state": self.state, "strategy": self.strategy,
            "reason": self.reason,
            "actions": [a.asdict() for a in self.actions],
        }


@dataclass
class ActionResult:
    action: Action
    ok: bool
    message: str = ""
    skipped: bool = False


# ---------- helpers ----------

def _run(cmd: list[str], cwd: Path | None = None,
         timeout: int = 60) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True,
                           text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (subprocess.TimeoutExpired, OSError) as e:
        return -1, "", str(e)


def _restore_upstream_tracking(repo: Path, remote: str = "origin") -> int:
    """After a force-push of all refs (e.g. post `git filter-repo` or a
    `--mirror` push), set local-to-remote tracking on every local branch
    whose name exists on the remote. Returns the number of branches whose
    tracking was set.

    Why this exists: `git filter-repo --replace-text` strips the origin
    remote ("Why is my origin removed?" in its docs). Re-adding the
    remote and force-pushing every ref restores the data, but the
    local-to-remote tracking config (`branch.<name>.remote` +
    `branch.<name>.merge`) is never recreated by `push --force --all`.
    GitHub Desktop reads those keys directly, so missing config makes
    every branch read as "this branch has not been published yet" and
    the UI prompts the user to publish.

    Branches that aren't on the remote are left untouched (legitimate
    local-only WIP / abandoned spike).
    """
    rc, out, _ = _run([
        "git", "-C", str(repo), "for-each-ref",
        "--format=%(refname:short)", "refs/heads/",
    ])
    if rc != 0:
        return 0
    n = 0
    for branch in out.splitlines():
        branch = branch.strip()
        if not branch:
            continue
        # Does the remote also have this branch?
        rc, _, _ = _run([
            "git", "-C", str(repo), "ls-remote",
            "--exit-code", "--heads", remote, branch,
        ])
        if rc != 0:
            continue
        rc, _, _ = _run([
            "git", "-C", str(repo), "branch",
            "--set-upstream-to", f"{remote}/{branch}", branch,
        ])
        if rc == 0:
            n += 1
    return n


_GH_URL_RE = re.compile(
    r"(?:git@github\.com:|https://github\.com/)([^/]+)/([^/.]+)(?:\.git)?$"
)

_SSH_GH_RE = re.compile(
    r"^git@github\.com:(?P<owner>[^/]+)/(?P<repo>.+?)(?:\.git)?/?$"
)
_SSH_PROTO_RE = re.compile(
    r"^ssh://(?:git@)?github\.com[:/](?P<owner>[^/]+)/(?P<repo>.+?)(?:\.git)?/?$"
)


def _parse_gh_url(url: str) -> tuple[str, str] | None:
    m = _GH_URL_RE.search(url.strip())
    if not m:
        return None
    return m.group(1), m.group(2)


def ssh_to_https_url(url: str) -> str | None:
    """Convert a GitHub SSH remote URL to its HTTPS equivalent.

    Accepts both shorthand ('git@github.com:owner/repo[.git]') and
    URL form ('ssh://git@github.com/owner/repo[.git]'). Returns None
    if the URL is not a recognised GitHub SSH form."""
    u = (url or "").strip()
    m = _SSH_GH_RE.match(u) or _SSH_PROTO_RE.match(u)
    if not m:
        return None
    owner = m.group("owner")
    repo = m.group("repo")
    if not repo.endswith(".git"):
        repo = repo + ".git"
    return f"https://github.com/{owner}/{repo}"


def _gh_visibility_via_cli(owner: str, repo: str) -> str | None:
    """Try the `gh` CLI first -- fast, uses the local auth token."""
    rc, out, _ = _run(["gh", "api", f"repos/{owner}/{repo}",
                       "--jq", ".visibility"])
    if rc != 0 or not out:
        return None
    return out.lower()


def _gh_visibility_via_api(owner: str, repo: str) -> str | None:
    """Fallback: unauthenticated GET on api.github.com.

    Public repos: 200 OK, response includes `private: false`.
    Private repos (and non-existent ones): 404 -- indistinguishable to an
    anonymous client. Treat 404 as private (defensive -- pushing without
    knowing visibility is the dangerous case)."""
    import json
    import urllib.error
    import urllib.request

    url = f"https://api.github.com/repos/{owner}/{repo}"
    req = urllib.request.Request(url, headers={
        "User-Agent": "sca-secret-scanner",
        "Accept": "application/vnd.github+json",
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:  # noqa: S310 (https URL is safe)
            body = json.loads(resp.read().decode("utf-8"))
        return "private" if body.get("private") else "public"
    except urllib.error.HTTPError as e:
        if e.code == 404:
            # Anonymous can't see private repos. Treat as private (so the
            # gate runs the secret scan rather than waving the push through).
            return "private"
        return None
    except (urllib.error.URLError, OSError):
        return None


def _gh_visibility(remote_url: str) -> str | None:
    """Return 'public', 'private', or None (unknown / non-GitHub).

    Tries `gh` CLI first; if that fails (not installed, not authed, etc.)
    falls back to a direct unauthenticated api.github.com query."""
    parsed = _parse_gh_url(remote_url)
    if not parsed:
        return None
    owner, repo = parsed

    via_cli = _gh_visibility_via_cli(owner, repo)
    if via_cli is not None:
        return via_cli
    return _gh_visibility_via_api(owner, repo)


# ---------- plan ----------

def _suggest_repo_name(repo_path: Path) -> str:
    return repo_path.name


def _hygiene_actions(entry: dict) -> list[Action]:
    """Cheap, repo-scoped hygiene actions that apply regardless of state.

    Currently:
        - CREATE_README        when audit reports has_readme=False
        - RUN_UNICODE_REPLACEMENT when audit annotated unicode_chars > 0
        - INSTALL_CI_WORKFLOW  when audit annotated missing_workflows
        - ENSURE_GITEA_REMOTE  when mapping annotated gitea_match

    The UnicodeReplacementTool repository (and any clones of it) is
    exempt: the tool deliberately contains the Unicode characters it
    replaces, so running its own CI baseline against itself would
    always flag every mapping as a violation. Per the spec, URT must
    not target itself.
    """
    from sca import exemptions as _ex
    actions: list[Action] = []
    repo_path = entry.get("path", "")
    if entry.get("type") != "repo" or not repo_path:
        return actions
    name = entry.get("name") or ""
    # URT (and any nested clones) are fully exempt -- they own the
    # mapping table and shouldn't be self-targeting.
    if _ex.is_urt_repo(name):
        return actions
    # source-control-automation: skip URT only; README/CI still apply.
    skip_urt = _ex.is_unicode_exempt(name)

    # README: only if the repo has commits (skip empty repos)
    if entry.get("has_readme") is False:
        actions.append(Action(
            ActionKind.CREATE_README,
            "Create a stub README.md at repo root",
            destructive=True,
            params={"repo": repo_path, "name": entry.get("name", "")},
        ))

    # Unicode replacement: only if init_workspace populated `unicode_chars`
    if int(entry.get("unicode_chars", 0) or 0) > 0 and not skip_urt:
        actions.append(Action(
            ActionKind.RUN_UNICODE_REPLACEMENT,
            f"Run UnicodeReplacementTool ({entry['unicode_chars']} non-ASCII chars in "
            f"{entry.get('unicode_files', 0)} file(s))",
            destructive=True,
            params={"repo": repo_path},
        ))

    # CI: install every missing baseline workflow.
    # `missing_workflows` is populated by `sca/ci.py:audit_repo`; the set of
    # baselines it tracks lives in `sca/ci.py:BASELINE_WORKFLOWS`.
    for baseline in (entry.get("missing_workflows") or []):
        actions.append(Action(
            ActionKind.INSTALL_CI_WORKFLOW,
            f"Install baseline GitHub Actions workflow: {baseline}",
            destructive=True,
            params={"repo": repo_path, "workflow": baseline},
        ))

    # Gitea mirror: add remote if mapping found a match and remote is missing
    gitea = entry.get("gitea_match")
    if isinstance(gitea, dict) and gitea.get("clone_url"):
        actions.append(Action(
            ActionKind.ENSURE_GITEA_REMOTE,
            f"Ensure 'gitea' remote points at {gitea.get('full_name') or gitea.get('clone_url')}",
            destructive=True,
            params={"repo": repo_path, "url": gitea["clone_url"], "remote": "gitea"},
        ))
        # Mirror push only when both remotes are present (origin + gitea).
        actions.append(Action(
            ActionKind.MIRROR_PUSH,
            "Mirror-push all refs to Gitea",
            destructive=True,
            params={"repo": repo_path, "remote": "gitea"},
        ))

    # Secret redaction: if the audit annotated this entry with critical
    # findings (xor_obfuscation excluded), schedule a redaction pass.
    if int(entry.get("critical_secret_count", 0) or 0) > 0:
        actions.append(Action(
            ActionKind.REDACT_SECRETS,
            f"Redact {entry['critical_secret_count']} critical secret occurrence(s)",
            destructive=True,
            params={"repo": repo_path},
        ))

    return actions


def _protocol_conversion_actions(entry: dict) -> list[Action]:
    """Return CONVERT actions for any SSH remote on a GitHub repo.

    These run against any state -- a FullyCompliant repo whose only
    'gap' is `git@github.com:` still produces a plan."""
    actions: list[Action] = []
    if not entry.get("uses_ssh"):
        return actions
    repo_path = entry.get("path", "")
    remotes = entry.get("remotes") or {}
    protocols = entry.get("remote_protocols") or {}
    for remote_name, url in remotes.items():
        if protocols.get(remote_name) != "ssh":
            continue
        https = ssh_to_https_url(url)
        if not https:
            continue
        actions.append(Action(
            ActionKind.SET_REMOTE_URL,
            f"Rewrite remote '{remote_name}' from SSH to HTTPS ({url} -> {https})",
            destructive=True,
            params={"repo": repo_path, "remote": remote_name, "url": https},
        ))
    return actions


def plan_for_entry(entry: dict) -> RepoPlan | None:
    """Produce a RepoPlan for one audit entry, or None if no work needed."""
    cls = _classify.classify_strategy(entry)
    state = cls.state.value
    strategy = cls.strategy.value

    plan = RepoPlan(
        path=entry.get("path", ""),
        name=entry.get("name", ""),
        state=state,
        strategy=strategy,
        reason=cls.reason,
    )

    # Protocol conversion + hygiene can fire for ANY state, including FullyCompliant.
    proto_actions = _protocol_conversion_actions(entry)
    hygiene_actions = _hygiene_actions(entry)

    # No-ops (these don't need a path) -- but if there's any conversion or
    # hygiene work, fall through with a plan that only does that.
    if state in ("FullyCompliant", "Empty", "LooseFile", "Container"):
        if proto_actions or hygiene_actions:
            plan.actions += proto_actions + hygiene_actions
            return plan
        return None
    if state == "WrapperRepo":
        plan.actions.append(Action(
            ActionKind.NOTE, destructive=False,
            description="Wrapper repo detected. Run `sca extract` to detect/repair "
                        "instead of remediating in place.",
        ))
        return plan

    # Past this point we need a real path. If the audit entry didn't carry
    # one (shouldn't happen for a real repo entry), bail with a NOTE.
    if not plan.path:
        plan.actions.append(Action(
            ActionKind.NOTE, destructive=False,
            description="Audit entry has no path; cannot remediate.",
        ))
        return plan
    repo_path: Path = Path(plan.path)

    # If the audit annotated this entry with an existing-GitHub-repo match,
    # prefer mapping to that remote over creating a new one.
    gh_match = entry.get("gh_match") or None
    match_https_url: str | None = None
    match_name_with_owner: str = ""
    if isinstance(gh_match, dict):
        url_field = gh_match.get("url") or gh_match.get("html_url") or ""
        if url_field:
            match_https_url = url_field if url_field.endswith(".git") else url_field + ".git"
        match_name_with_owner = gh_match.get("nameWithOwner") or ""

    # NoSourceControl with content -> init + first push
    if state == "NoSourceControl" and entry.get("file_count", 0) > 0:
        plan.actions += [
            Action(ActionKind.BACKUP, "Backup directory before initialising git",
                   destructive=False, params={"repo": str(repo_path)}),
            Action(ActionKind.APPLY_GITIGNORE,
                   "Detect stack and write .gitignore",
                   destructive=False, params={"repo": str(repo_path)}),
            Action(ActionKind.INIT_REPO, "git init -b main",
                   destructive=True, params={"repo": str(repo_path)}),
        ]
        # Hygiene runs BEFORE the initial commit so it's part of history.
        plan.actions += hygiene_actions
        plan.actions += [
            Action(ActionKind.SCAN_SECRETS,
                   "Scan tree for committed-secret patterns",
                   destructive=False, params={"repo": str(repo_path)}),
            Action(ActionKind.COMMIT_DIRTY, "Initial commit",
                   destructive=True,
                   params={"repo": str(repo_path), "message": "Initial commit"}),
        ]
        if match_https_url:
            plan.actions.append(Action(
                ActionKind.MAP_TO_REMOTE,
                f"Map to existing GitHub repo {match_name_with_owner or match_https_url}",
                destructive=True,
                params={"repo": str(repo_path), "url": match_https_url},
            ))
        else:
            plan.actions.append(Action(
                ActionKind.CREATE_GH_REPO,
                "Create matching private repo on GitHub",
                destructive=True,
                params={"repo": str(repo_path),
                        "name": _suggest_repo_name(repo_path),
                        "visibility": "private"},
            ))
        plan.actions.append(Action(
            ActionKind.PUSH, "Push initial commit to origin",
            destructive=True,
            params={"repo": str(repo_path), "branch": "main"},
        ))
        return plan

    # LocalGitOnly -> visibility check + create remote + push
    if state == "LocalGitOnly":
        # Hygiene first so the publish includes README + ASCII-clean source.
        plan.actions += hygiene_actions
        plan.actions.append(Action(
            ActionKind.SCAN_SECRETS,
            "Pre-push secret scan (we're about to publish this)",
            destructive=False, params={"repo": str(repo_path)},
        ))
        if match_https_url:
            plan.actions.append(Action(
                ActionKind.MAP_TO_REMOTE,
                f"Map to existing GitHub repo {match_name_with_owner or match_https_url}",
                destructive=True,
                params={"repo": str(repo_path), "url": match_https_url},
            ))
        else:
            plan.actions.append(Action(
                ActionKind.CREATE_GH_REPO,
                "Create matching private repo on GitHub",
                destructive=True,
                params={"repo": str(repo_path),
                        "name": _suggest_repo_name(repo_path),
                        "visibility": "private"},
            ))
        plan.actions.append(Action(
            ActionKind.PUSH, "Push current branch to origin",
            destructive=True,
            params={"repo": str(repo_path), "branch": None},
        ))
        # Protocol conversion is a no-op here -- there's no remote yet --
        # so nothing more to add.
        return plan

    # Incomplete -> commit + (maybe) push
    if state == "IncompleteSourceControl":
        # Convert protocol BEFORE pushing, so the push uses HTTPS.
        plan.actions += proto_actions
        # Hygiene (README/unicode/CI) BEFORE the WIP commit so it's captured.
        plan.actions += hygiene_actions
        plan.actions += [
            Action(ActionKind.BACKUP, "Backup before staging dirty work",
                   destructive=False, params={"repo": str(repo_path)}),
            Action(ActionKind.SCAN_SECRETS,
                   "Scan dirty tree for secrets before committing",
                   destructive=False, params={"repo": str(repo_path)}),
            Action(ActionKind.COMMIT_DIRTY,
                   "Stage + commit uncommitted work as one WIP commit",
                   destructive=True,
                   params={"repo": str(repo_path),
                           "message": "WIP: snapshot via sca remediate"}),
        ]
        if entry.get("has_remote"):
            plan.actions.append(Action(
                ActionKind.PUSH, "Push if a remote exists", destructive=True,
                params={"repo": str(repo_path), "branch": None}))
        return plan

    # PartiallySynced -> push (skip if behind -- that's a merge decision)
    if state == "PartiallySynced":
        plan.actions += proto_actions
        plan.actions += hygiene_actions
        if entry.get("ahead", 0) > 0 and entry.get("behind", 0) == 0:
            plan.actions += [
                Action(ActionKind.SCAN_SECRETS,
                       "Pre-push secret scan",
                       destructive=False, params={"repo": str(repo_path)}),
                Action(ActionKind.PUSH, "Fast-forward push of unpushed commits",
                       destructive=True,
                       params={"repo": str(repo_path), "branch": None}),
            ]
        else:
            plan.actions.append(Action(
                ActionKind.NOTE, destructive=False,
                description=f"behind={entry.get('behind',0)} ahead={entry.get('ahead',0)} -- "
                            f"diverged or behind. Manual merge/rebase needed.",
            ))
        return plan

    return None


def plan_remediation(audit_entries: list[dict]) -> list[RepoPlan]:
    plans: list[RepoPlan] = []
    for entry in audit_entries:
        p = plan_for_entry(entry)
        if p is not None:
            plans.append(p)
    return plans


# ---------- execute ----------

def _backup_repo(repo_path: Path) -> Path:
    repo_path = repo_path.resolve()
    parent = repo_path.parent
    name = f"{repo_path.name}.backup-{date.today().isoformat()}.zip"
    target = parent / name
    if target.exists():
        return target  # idempotent
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in repo_path.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(repo_path)
            # skip noise
            if any(part in (".git", "node_modules", "__pycache__",
                            ".venv", "venv", "dist", "build", "Logs")
                   for part in rel.parts):
                continue
            try:
                zf.write(p, rel)
            except OSError:
                pass
    return target


def _visibility_gate(repo_path: Path, *, offline: bool = False) -> tuple[bool, str]:
    """If origin is a public GitHub repo and the scanner finds critical hits,
    block the push. Returns (allowed, reason).

    offline=True: don't call `gh api`. Treat unknown visibility as 'public'
    (defensive default for CI environments without gh auth)."""
    rc, out, _ = _run(["git", "-C", str(repo_path), "remote", "get-url", "origin"])
    if rc != 0:
        return True, "no remote -- nothing to gate"

    visibility: str | None
    if offline:
        visibility = "public"  # safest assumption when we can't check
        gate_note = "offline mode: assuming public"
    else:
        visibility = _gh_visibility(out)
        gate_note = f"visibility={visibility}"

    if visibility != "public":
        return True, f"{gate_note} -- gate not required"

    findings = _secrets.scan_repo(repo_path)
    crit = [f for f in findings if f.severity == "critical"]
    if crit:
        details = "; ".join(f"{f.path}:{f.line} ({f.category})" for f in crit[:3])
        return False, (
            f"REFUSED ({gate_note}): {len(crit)} critical secret finding(s). "
            f"First: {details}. Flip the repo private OR redact the secrets first."
        )
    return True, f"{gate_note}, scan clean ({len(findings)} non-critical findings)"


def execute_action(action: Action, apply: bool = False, *,
                   offline: bool = False) -> ActionResult:
    """Execute a single action. apply=False means describe only.
    offline=True passes through to the visibility gate on PUSH."""
    p = action.params
    if not apply and action.destructive:
        return ActionResult(action, ok=True, skipped=True,
                            message="(dry-run; destructive action skipped)")

    # NOTE is the only action that doesn't operate on a repo. Handle it
    # first so every branch below can treat `repo` as a non-optional Path.
    if action.kind == ActionKind.NOTE:
        return ActionResult(action, ok=True, message="(note)")
    if "repo" not in p:
        return ActionResult(action, ok=False,
                            message=f"action {action.kind} missing 'repo' param")
    repo = Path(p["repo"]).resolve()

    try:

        if action.kind == ActionKind.BACKUP:
            zip_path = _backup_repo(repo)
            return ActionResult(action, ok=True, message=f"backup -> {zip_path}")

        if action.kind == ActionKind.APPLY_GITIGNORE:
            target = _templates.write(repo, overwrite=False)
            return ActionResult(action, ok=True, message=f"wrote {target}")

        if action.kind == ActionKind.INIT_REPO:
            rc, _, err = _run(["git", "init", "-b", "main", str(repo)])
            return ActionResult(action, ok=(rc == 0), message=err or "ok")

        if action.kind == ActionKind.SCAN_SECRETS:
            findings = _secrets.scan_repo(repo)
            crit = sum(1 for f in findings if f.severity == "critical")
            high = sum(1 for f in findings if f.severity == "high")
            ok = crit == 0
            return ActionResult(action, ok=ok,
                                message=f"crit={crit} high={high} total={len(findings)}")

        if action.kind == ActionKind.COMMIT_DIRTY:
            rc1, _, _ = _run(["git", "-C", str(repo), "add", "-A"])
            rc2, out, err = _run([
                "git", "-C", str(repo), "commit", "-m", p.get("message", "WIP")
            ])
            return ActionResult(action, ok=(rc1 == 0 and rc2 == 0), message=err or out)

        if action.kind == ActionKind.CREATE_GH_REPO:
            name = p["name"]
            vis = p.get("visibility", "private")
            rc, out, err = _run([
                "gh", "repo", "create", name,
                f"--{vis}", "--source", str(repo), "--push",
            ])
            return ActionResult(action, ok=(rc == 0), message=(err or out))

        if action.kind == ActionKind.ADD_REMOTE:
            rc, out, err = _run([
                "git", "-C", str(repo), "remote", "add", "origin", p["url"]
            ])
            return ActionResult(action, ok=(rc == 0), message=err or out)

        if action.kind == ActionKind.SET_REMOTE_URL:
            remote_name = p.get("remote", "origin")
            rc, out, err = _run([
                "git", "-C", str(repo), "remote", "set-url", remote_name, p["url"]
            ])
            return ActionResult(action, ok=(rc == 0),
                                message=(err or out) or f"set {remote_name} -> {p['url']}")

        if action.kind == ActionKind.CREATE_README:
            target = repo / "README.md"
            if target.exists():
                return ActionResult(action, ok=True,
                                    message=f"{target} already exists -- skipped")
            name = p.get("name") or repo.name
            target.write_text(f"# {name}\n", encoding="utf-8")
            return ActionResult(action, ok=True, message=f"wrote {target}")

        if action.kind == ActionKind.RUN_UNICODE_REPLACEMENT:
            tool = os.environ.get("UNICODE_REPLACEMENT_TOOL", "")
            if not tool:
                return ActionResult(
                    action, ok=True, skipped=True,
                    message="UNICODE_REPLACEMENT_TOOL env var not set; "
                            "install UnicodeReplacementTool and re-run.",
                )
            # Resolve `tool` to a path to unicode_replacer.py. The env var
            # may point at the URT repo root, the script directly, or a
            # directory containing it under nested 'UnicodeReplacementTool'.
            tool_path = Path(tool)
            candidates = [
                tool_path,
                tool_path / "unicode_replacer.py",
                tool_path / "UnicodeReplacementTool" / "unicode_replacer.py",
            ]
            script = next((c for c in candidates
                            if c.is_file() and c.suffix == ".py"), None)
            if script is None:
                return ActionResult(
                    action, ok=False,
                    message=f"unicode_replacer.py not found via "
                            f"UNICODE_REPLACEMENT_TOOL={tool}",
                )
            # URT's CLI: positional <path>, plus flags. The `--pattern`
            # flag uses nargs='+' which would swallow a trailing path,
            # so the path MUST come before --pattern. Pattern set matches
            # the CI baseline so local + CI never diverge.
            cmd = ["python", str(script),
                   str(repo),
                   "--yes", "--no-backup", "--recursive",
                   "--pattern", "*.py", "*.ps1", "*.psm1", "*.psd1",
                   "*.toml", "*.yml", "*.yaml", "*.sh", "*.bat", "*.cmd"]
            rc, out, err = _run(cmd, timeout=600)
            return ActionResult(action, ok=(rc == 0),
                                message=(err or out)[:400])

        if action.kind == ActionKind.INSTALL_CI_WORKFLOW:
            from sca import ci as _ci
            workflow = p.get("workflow", "unicode-check")
            written = _ci.write_baseline_workflow(repo, workflow)
            return ActionResult(action, ok=True, message=f"wrote {written}")

        if action.kind == ActionKind.REDACT_SECRETS:
            from sca import redact as _redact
            n = _redact.redact_repo(repo)
            return ActionResult(action, ok=True,
                                message=f"redacted {n} occurrence(s)")

        if action.kind == ActionKind.ENSURE_GITEA_REMOTE:
            remote = p.get("remote", "gitea")
            rc, _, _ = _run(["git", "-C", str(repo), "remote", "get-url", remote])
            if rc == 0:
                rc2, out, err = _run([
                    "git", "-C", str(repo), "remote", "set-url", remote, p["url"],
                ])
            else:
                rc2, out, err = _run([
                    "git", "-C", str(repo), "remote", "add", remote, p["url"],
                ])
            return ActionResult(action, ok=(rc2 == 0),
                                message=(err or out) or f"{remote} -> {p['url']}")

        if action.kind == ActionKind.MIRROR_PUSH:
            remote = p.get("remote", "gitea")
            rc, out, err = _run([
                "git", "-C", str(repo), "push", remote, "--mirror",
            ], timeout=300)
            msg = err or out
            if rc == 0:
                # Force-push of all refs leaves local branches without
                # upstream config. Restore it so subsequent `git status` /
                # GUI clients (GitHub Desktop) see the branches as
                # published. See _restore_upstream_tracking() docstring.
                n = _restore_upstream_tracking(repo, remote)
                if n > 0:
                    suffix = f"; restored upstream tracking on {n} branch(es)"
                    msg = (msg + suffix).lstrip()
            return ActionResult(action, ok=(rc == 0), message=msg)

        if action.kind == ActionKind.MAP_TO_REMOTE:
            # Add origin if missing; otherwise update its URL to the matched repo.
            rc, _, _ = _run(["git", "-C", str(repo), "remote", "get-url", "origin"])
            if rc == 0:
                rc2, out, err = _run([
                    "git", "-C", str(repo), "remote", "set-url", "origin", p["url"],
                ])
            else:
                rc2, out, err = _run([
                    "git", "-C", str(repo), "remote", "add", "origin", p["url"],
                ])
            return ActionResult(action, ok=(rc2 == 0),
                                message=(err or out) or f"origin -> {p['url']}")

        if action.kind == ActionKind.PUSH:
            allowed, reason = _visibility_gate(repo, offline=offline)
            if not allowed:
                return ActionResult(action, ok=False, message=reason)
            branch = p.get("branch")
            cmd = ["git", "-C", str(repo), "push"]
            if branch:
                cmd += ["origin", branch]
            else:
                cmd += ["-u", "origin", "HEAD"]
            rc, out, err = _run(cmd)
            return ActionResult(action, ok=(rc == 0),
                                message=(err or out) + f" [gate: {reason}]")

        return ActionResult(action, ok=False, message=f"unknown action: {action.kind}")
    except Exception as e:
        return ActionResult(action, ok=False, message=f"exception: {e}")


def execute_plan(plans: list[RepoPlan], apply: bool = False, *,
                 offline: bool = False) -> list[dict]:
    """Run every action in every plan; abort a plan on first failure."""
    out = []
    for plan in plans:
        plan_results = []
        for action in plan.actions:
            result = execute_action(action, apply=apply, offline=offline)
            plan_results.append({
                "action": action.kind.value,
                "ok": result.ok,
                "skipped": result.skipped,
                "message": result.message,
            })
            if not result.ok and not result.skipped:
                plan_results.append({"action": "ABORT",
                                     "ok": False,
                                     "message": "abort plan after failure"})
                break
        out.append({
            "name": plan.name, "state": plan.state, "strategy": plan.strategy,
            "results": plan_results,
        })
    return out


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Plan and (optionally) execute remediations.")
    ap.add_argument("--audit", default="-",
                    help="Path to audit JSON (default: stdin)")
    ap.add_argument("--plan", action="store_true",
                    help="Print the plan as JSON and exit")
    ap.add_argument("--apply", action="store_true",
                    help="Actually run destructive actions (default: dry-run)")
    ap.add_argument("--offline", action="store_true",
                    help="Don't call gh api for visibility checks; treat unknown as public")
    args = ap.parse_args(argv)

    if args.audit == "-":
        data = json.load(sys.stdin)
    else:
        with open(args.audit, encoding="utf-8") as f:
            data = json.load(f)

    plans = plan_remediation(data)

    if args.plan:
        print(json.dumps([p.asdict() for p in plans], indent=2))
        return 0

    results = execute_plan(plans, apply=args.apply, offline=args.offline)
    print(json.dumps(results, indent=2, default=str))

    failures = sum(
        1 for r in results
        for ar in r["results"]
        if not ar["ok"] and not ar.get("skipped")
    )
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
