#!/usr/bin/env python3
"""Audit a repo's GitHub Actions workflows; install missing baseline ones.

Baseline (every repo should have at least these):
    unicode-check  -- runs UnicodeReplacementTool / ASCII-only check on push/PR

Detection is content-aware: a workflow file counts as the baseline
'unicode-check' if its YAML mentions either the tool name or the
keywords `ascii` / `unicode` in a job. We don't require a specific
filename so existing repos that already have an equivalent workflow
under a different name aren't double-installed.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

# Map: baseline-name -> (filename suggestion, content-detection keywords)
BASELINE_WORKFLOWS: dict[str, tuple[str, tuple[str, ...]]] = {
    "unicode-check": (
        "unicode-check.yml",
        ("unicodereplacementtool", "ascii-check", "ascii_check",
         "unicode-check", "ascii-only"),
    ),
    "secret-scan": (
        "secret-scan.yml",
        # The "self-scan" / "selfscan" terms catch source-control-automation's
        # own existing v3-tests.yml::selfscan job, which already does what
        # this baseline asks for. Content-aware detection means a repo with
        # any of these markers won't have a duplicate workflow installed.
        ("gitleaks", "sca scan", "redact-secrets",
         "secret-scan", "secret_scan", "secretscan",
         "self-scan", "selfscan"),
    ),
}


# Baseline workflow: this is the SAME flow used by source-control-automation's
# own CI (see .github/workflows/v3-tests.yml -> ascii-check job). The
# UnicodeReplacementTool is the single source of truth for the mapping
# table; this workflow clones URT fresh into /tmp on every run and invokes
# its `unicode_replacer.py --preview` against the repo. URT is cloned
# OUTSIDE the workspace so the scan path `.` doesn't pick up URT's own
# test fixtures (which intentionally contain unicode for self-testing).
# URT exits 0 in both clean and dirty cases, so we parse its summary line
# to fail the job on any non-zero count.
_UNICODE_CHECK_YAML = """\
name: unicode-check

on:
  push:
    branches: [ main, master ]
  pull_request:
  workflow_dispatch:

jobs:
  ascii-check:
    name: ascii-only via URT (single source of truth)
    runs-on: ubuntu-latest
    steps:
      - name: Checkout this repo
        uses: actions/checkout@v5

      - uses: actions/setup-python@v6
        with:
          python-version: "3.12"

      - name: Clone URT outside workspace (avoids scanning the scanner)
        shell: bash
        run: git clone --depth 1 https://github.com/aollivierre/UnicodeReplacementTool /tmp/_urt

      - name: Run URT in --preview mode
        shell: bash
        run: |
          set -o pipefail
          python /tmp/_urt/unicode_replacer.py \\
                 --preview \\
                 . \\
                 --recursive \\
                 --pattern '*.py' '*.ps1' '*.psm1' '*.psd1' '*.toml' \\
                           '*.yml' '*.yaml' '*.sh' '*.bat' '*.cmd' \\
                 | tee urt-preview.txt

          # URT prints "Files with Unicode: <n>" in its summary.
          # Markdown is exempt; we don't include *.md in --pattern.
          if grep -E "Files with Unicode: [1-9]" urt-preview.txt > /dev/null; then
            echo ""
            echo "URT found Unicode in tracked scripts/config."
            echo "Fix locally with the same command (without --preview):"
            echo ""
            echo "  git clone https://github.com/aollivierre/UnicodeReplacementTool /tmp/_urt"
            echo "  python /tmp/_urt/unicode_replacer.py --yes --no-backup --recursive \\\\"
            echo "         --pattern '*.py' '*.ps1' '*.psm1' '*.psd1' '*.toml' \\\\"
            echo "                   '*.yml' '*.yaml' '*.sh' '*.bat' '*.cmd' \\\\"
            echo "         ."
            exit 1
          fi
          echo ""
          echo "ascii-check: URT preview shows zero replacements needed."
"""


# Baseline workflow: defense-in-depth secret scanning. Two complementary
# jobs, modelled on `Claude/.github/workflows/secret-scan.yml`:
#
#   1. sca-scan   - canonical SSOT. Installs `aollivierre-sca` from PyPI
#                   and runs `sca scan` against the repo. Pattern
#                   changes happen in source-control-automation; cutting
#                   a release publishes a new wheel; consumers pick up
#                   the new patterns on the next workflow run.
#                   Critical findings fail the job; high-severity (e.g.
#                   real-looking GUIDs that may be public tenant IDs) is
#                   non-blocking per the workspace threat model.
#   2. gitleaks   - independent second opinion. Different pattern
#                   library, different maintainers, much wider coverage
#                   of token shapes (Slack, JWT, AWS rotation keys,
#                   etc.). If the canonical regresses, gitleaks catches
#                   it; if gitleaks is noisy on this repo's idioms,
#                   the canonical job still passes.
#
# The PyPI distribution channel replaces the earlier cross-repo checkout
# pattern, which was blocked when source-control-automation was private:
# the default GITHUB_TOKEN cannot read other repos. PyPI is public-by-
# design, removes the auth dependency, and adds version pinning.
_SECRET_SCAN_YAML = """\
name: secret-scan

# Defense-in-depth secret scanning. SSOT (sca, distributed via PyPI) +
# independent backstop (gitleaks). Pattern changes happen in
# source-control-automation; cutting a release on tag push publishes a
# new wheel; consumers pin a version and bump deliberately.

on:
  push:
    branches: [ main, master ]
  pull_request:
  workflow_dispatch:

jobs:
  sca-scan:
    name: sca scan (single source of truth)
    runs-on: ubuntu-latest
    steps:
      - name: Checkout this repo
        uses: actions/checkout@v5

      - uses: actions/setup-python@v6
        with:
          python-version: "3.12"

      - name: Install sca from PyPI
        shell: bash
        run: |
          python -m pip install --upgrade pip
          pip install aollivierre-sca==0.2.2

      - name: Run sca scan against this repo
        shell: bash
        run: |
          # exit codes:
          #   0 = clean
          #   1 = high-severity findings only (non-blocking; see threat model)
          #   2 = critical findings -> fail the job
          set +e
          sca scan . --exclude tests --exclude __tests__ --exclude fixtures \\
                     --exclude spec --exclude test_data --exclude test-data
          rc=$?
          if [ $rc -ge 2 ]; then
            echo "::error::sca found critical secret findings"
            exit 1
          fi
          echo "::notice::sca scan ok (exit=$rc; high-only is non-blocking)"
          exit 0

  gitleaks:
    name: gitleaks (independent second opinion)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v5

      - name: Install gitleaks
        shell: bash
        run: |
          set -euo pipefail
          VERSION=8.21.2
          curl -fsSL "https://github.com/gitleaks/gitleaks/releases/download/v${VERSION}/gitleaks_${VERSION}_linux_x64.tar.gz" \\
              -o gitleaks.tar.gz
          tar -xzf gitleaks.tar.gz gitleaks
          sudo mv gitleaks /usr/local/bin/gitleaks
          gitleaks version

      - name: Scan working tree
        shell: bash
        run: |
          # --no-git: scan working tree only (sca scan above covered the
          #          committed state).
          # --redact: never echo a secret value into CI logs.
          # --verbose: show finding lines so triage is fast.
          # --exit-code 1: any finding fails the job.
          gitleaks detect \\
            --source . \\
            --no-banner \\
            --no-git \\
            --redact \\
            --verbose \\
            --exit-code 1
"""


@dataclass
class WorkflowAudit:
    name: str            # repo-relative name
    path: str            # absolute path
    present_workflows: list[str] = field(default_factory=list)
    missing_workflows: list[str] = field(default_factory=list)

    def asdict(self) -> dict:
        return asdict(self)


# ---------- audit ----------

def _list_workflow_files(repo_root: Path) -> list[Path]:
    wf_dir = repo_root / ".github" / "workflows"
    if not wf_dir.is_dir():
        return []
    return sorted(p for p in wf_dir.iterdir()
                  if p.is_file() and p.suffix.lower() in (".yml", ".yaml"))


def _content_matches(text: str, keywords: tuple[str, ...]) -> bool:
    low = text.lower()
    return any(kw in low for kw in keywords)


def audit_repo(repo_root: Path) -> WorkflowAudit:
    repo_root = repo_root.resolve()
    files = _list_workflow_files(repo_root)
    contents: dict[Path, str] = {}
    for f in files:
        try:
            contents[f] = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            contents[f] = ""

    present: list[str] = []
    missing: list[str] = []
    for baseline, (_filename, keywords) in BASELINE_WORKFLOWS.items():
        hit = any(_content_matches(text, keywords) for text in contents.values())
        if hit:
            present.append(baseline)
        else:
            missing.append(baseline)

    return WorkflowAudit(
        name=repo_root.name,
        path=str(repo_root),
        present_workflows=present,
        missing_workflows=missing,
    )


# ---------- remediation ----------

def write_baseline_workflow(repo_root: Path, baseline: str) -> Path:
    """Write `<repo>/.github/workflows/<filename>` for the named baseline.

    Idempotent: if the target file already exists, leave it alone."""
    if baseline not in BASELINE_WORKFLOWS:
        raise ValueError(f"unknown baseline workflow: {baseline}")
    filename, _kw = BASELINE_WORKFLOWS[baseline]
    wf_dir = repo_root / ".github" / "workflows"
    wf_dir.mkdir(parents=True, exist_ok=True)
    target = wf_dir / filename
    if target.exists():
        return target
    if baseline == "unicode-check":
        target.write_text(_UNICODE_CHECK_YAML, encoding="utf-8")
    elif baseline == "secret-scan":
        target.write_text(_SECRET_SCAN_YAML, encoding="utf-8")
    else:
        target.write_text(f"# {baseline} placeholder\n", encoding="utf-8")
    return target


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit GitHub Actions workflows.")
    ap.add_argument("--root",
                    default=os.environ.get("CODE_ROOT", os.getcwd()),
                    help="Code root containing repos (default: $CODE_ROOT or cwd)")
    ap.add_argument("--summary", action="store_true",
                    help="Print a per-repo summary instead of full JSON")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    repos: list[Path] = []
    if (root / ".git").is_dir():
        repos = [root]
    else:
        for entry in sorted(root.iterdir()):
            if entry.is_dir() and (entry / ".git").is_dir():
                repos.append(entry)

    out = [audit_repo(r).asdict() for r in repos]
    if args.summary:
        for r in out:
            print(f"  {r['name']:40s} present={r['present_workflows']} "
                  f"missing={r['missing_workflows']}", file=sys.stderr)
        return 0
    print(json.dumps(out, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
