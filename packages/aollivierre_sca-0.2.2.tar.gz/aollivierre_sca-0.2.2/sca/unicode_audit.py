#!/usr/bin/env python3
"""Audit committed source files for non-ASCII characters.

Scope is intentionally narrow: only files whose extension implies "ASCII
only is expected" (PowerShell, Python, shell, batch). `.md` is excluded
because Markdown is legitimately Unicode-rich, and we never scan our own
copy of the UnicodeReplacementTool (it deliberately contains the
characters it replaces, so flagging it is a false positive).

The audit is read-only and reports per file:
    counts         : total non-ASCII characters in the file
    unique_chars   : sorted list of distinct non-ASCII codepoints
    line_numbers   : line numbers where non-ASCII characters appear

The actual replacement is delegated to the external
UnicodeReplacementTool; this module only surfaces what would be replaced.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path

# File extensions where we expect ASCII-only source. Curated, not exhaustive.
DEFAULT_TARGET_EXTENSIONS: tuple[str, ...] = (
    ".ps1", ".psm1", ".psd1", ".ps1xml",
    ".py",
    ".sh", ".bash", ".zsh",
    ".cmd", ".bat",
    ".bicep",
)

# Directory names we never recurse into.
SKIP_DIRS: frozenset[str] = frozenset({
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env",
    "dist", "build", "Logs", "logs", "ignored-bad-zips",
    # The UnicodeReplacementTool intentionally contains the characters it
    # replaces; scanning its own source would be a feedback loop.
    "UnicodeReplacementTool",
    # Test-fixture dirs: a project is allowed to commit non-ASCII bytes
    # in fixtures (e.g. test_phase2_unicode_readme.py here uses U+2019 to
    # verify detection). These match the same paths the secrets-scan and
    # harvest excludes use, so the three audit passes agree.
    "tests", "__tests__", "spec", "test_data", "test-data", "fixtures",
    # Archived / backup content: aligns with harvest.DEFAULT_EXCLUDES and
    # init_workspace.default_excludes. Repos like Claude use `backups/`
    # for session-transcript content owned by their canonical scanner.
    # See v3/HANDOFF.md item #1 for the larger SSOT fix.
    ".archive", "backups",
})


@dataclass
class FileFinding:
    path: str            # repo-relative
    count: int           # total non-ASCII chars in the file
    unique_chars: list[str]
    line_numbers: list[int]

    def asdict(self) -> dict:
        return asdict(self)


@dataclass
class RepoFinding:
    name: str
    path: str
    files: list[FileFinding] = field(default_factory=list)

    @property
    def total_chars(self) -> int:
        return sum(f.count for f in self.files)

    @property
    def total_files(self) -> int:
        return len(self.files)

    def asdict(self) -> dict:
        return {
            "name": self.name,
            "path": self.path,
            "total_chars": self.total_chars,
            "total_files": self.total_files,
            "files": [f.asdict() for f in self.files],
        }


# ---------- helpers ----------

def _run(cmd: list[str], cwd: Path | None = None,
         timeout: int = 30) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True,
                           text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (subprocess.TimeoutExpired, OSError) as e:
        return -1, "", str(e)


def _iter_target_files(repo_root: Path,
                       extensions: tuple[str, ...]) -> list[Path]:
    """Yield tracked files (or all files, if not a git repo) whose extension
    is in `extensions` and which are not under a SKIP_DIRS path."""
    repo_root = repo_root.resolve()
    rc, out, _ = _run(["git", "-C", str(repo_root), "ls-files"])
    if rc == 0:
        candidates = [repo_root / line for line in out.splitlines()]
    else:
        candidates = list(repo_root.rglob("*"))
    out_files: list[Path] = []
    for p in candidates:
        if not p.is_file():
            continue
        try:
            rel = p.relative_to(repo_root)
        except ValueError:
            continue
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        if p.suffix.lower() not in extensions:
            continue
        out_files.append(p)
    return out_files


def scan_file(path: Path) -> FileFinding | None:
    """Return a FileFinding if `path` contains any non-ASCII bytes; None otherwise."""
    try:
        data = path.read_bytes()
    except OSError:
        return None
    # Fast path: pure ASCII
    try:
        data.decode("ascii")
        return None
    except UnicodeDecodeError:
        pass
    # Fall back to a UTF-8 decode; ignore any decode errors to be robust.
    text = data.decode("utf-8", errors="replace")
    count = 0
    chars: set[str] = set()
    line_numbers: list[int] = []
    line = 1
    in_line = False
    for ch in text:
        if ch == "\n":
            line += 1
            continue
        cp = ord(ch)
        if cp > 0x7F:
            count += 1
            chars.add(ch)
            if not in_line or (line_numbers and line_numbers[-1] != line):
                line_numbers.append(line)
            in_line = True
        else:
            in_line = False
    return FileFinding(
        path=str(path),
        count=count,
        unique_chars=sorted(chars),
        line_numbers=sorted(set(line_numbers)),
    )


def scan_repo(repo_root: Path,
              extensions: tuple[str, ...] = DEFAULT_TARGET_EXTENSIONS,
              ) -> RepoFinding:
    """Audit one repo; return a RepoFinding (possibly with empty files list)."""
    repo_root = repo_root.resolve()
    finding = RepoFinding(name=repo_root.name, path=str(repo_root))
    for f in _iter_target_files(repo_root, extensions):
        ff = scan_file(f)
        if ff is None:
            continue
        # Re-write absolute path to repo-relative for cleaner reporting
        try:
            ff.path = str(f.relative_to(repo_root))
        except ValueError:
            pass
        finding.files.append(ff)
    finding.files.sort(key=lambda f: (-f.count, f.path))
    return finding


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit one or more repos for non-ASCII source.")
    ap.add_argument("--root",
                    default=os.environ.get("CODE_ROOT", os.getcwd()),
                    help="Code root (default: $CODE_ROOT or cwd). "
                         "If --root is itself a git repo, only that repo is scanned.")
    ap.add_argument("--ext", action="append", default=None,
                    help="Limit to a specific extension (repeatable). "
                         "Default: " + " ".join(DEFAULT_TARGET_EXTENSIONS))
    ap.add_argument("--summary", action="store_true",
                    help="Print a per-repo summary to stderr instead of full JSON")
    args = ap.parse_args(argv)

    extensions = tuple(args.ext) if args.ext else DEFAULT_TARGET_EXTENSIONS
    root = Path(args.root).resolve()
    if not root.is_dir():
        print(f"error: --root {root} is not a directory", file=sys.stderr)
        return 2

    # Collect repos under root (depth 3 cap, matching audit.py)
    repos: list[Path] = []
    if (root / ".git").is_dir():
        repos = [root]
    else:
        for dirpath, dirnames, _ in os.walk(root):
            rel = Path(dirpath).relative_to(root)
            if len(rel.parts) > 3:
                dirnames[:] = []
                continue
            if any(part in SKIP_DIRS for part in rel.parts):
                dirnames[:] = []
                continue
            if ".git" in dirnames:
                repos.append(Path(dirpath))
                dirnames.remove(".git")

    out: list[dict] = []
    for repo_path in sorted(set(repos)):
        rf = scan_repo(repo_path, extensions=extensions)
        out.append(rf.asdict())

    if args.summary:
        for entry in out:
            if entry["total_chars"] == 0:
                continue
            print(f"  {entry['name']:40s} {entry['total_chars']:6d} non-ASCII "
                  f"chars in {entry['total_files']} file(s)", file=sys.stderr)
        return 0

    print(json.dumps(out, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
