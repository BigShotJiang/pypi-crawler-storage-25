#!/usr/bin/env python3
"""Walk every repo under a code root; for each branch, check:
  - is it on remote?
  - does main/master have its commits (i.e., is main behind)?

Usage:
    python branch-audit.py [--root <path>] > branches.json
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

_parser = argparse.ArgumentParser()
_parser.add_argument("--root", default=os.environ.get("CODE_ROOT", os.getcwd()))
_args, _ = _parser.parse_known_args()
ROOT = Path(_args.root).resolve()
SKIP = {".archive", ".claude", "temp", "secrets"}

def run(cmd, cwd=None, timeout=15):
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception as e:
        return -1, "", str(e)

def find_repos(root):
    for dirpath, dirnames, _ in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        depth = len(rel.parts)
        if depth > 3:
            dirnames[:] = []
            continue
        if any(part in SKIP or part.startswith("sca-run-") or part == "sca-final-report"
               for part in rel.parts):
            dirnames[:] = []
            continue
        if any(part.endswith(".pre-clone-backup") for part in rel.parts):
            dirnames[:] = []
            continue
        if ".git" in dirnames:
            yield Path(dirpath)
            dirnames.remove(".git")
        for noisy in ("node_modules", "__pycache__", ".venv", "venv",
                      "ignored-bad-zips", "recorder-dom-capture", "Logs"):
            if noisy in dirnames:
                dirnames.remove(noisy)

def audit_repo(path):
    info = {"path": str(path), "name": str(path.relative_to(ROOT)), "branches": []}

    rc, default, _ = run(["git", "-C", str(path), "symbolic-ref",
                          "--short", "refs/remotes/origin/HEAD"])
    info["default_branch"] = default.replace("origin/", "") if rc == 0 else None

    rc, out, _ = run(["git", "-C", str(path), "for-each-ref",
                      "--format=%(refname:short)", "refs/heads/"])
    local_branches = out.splitlines() if rc == 0 else []

    # fetch first so remote-tracking refs are current (lightweight)
    run(["git", "-C", str(path), "fetch", "--quiet", "--all"], timeout=30)

    rc, out, _ = run(["git", "-C", str(path), "for-each-ref",
                      "--format=%(refname:short)", "refs/remotes/origin/"])
    remote_branches = set()
    if rc == 0:
        for line in out.splitlines():
            if line.startswith("origin/") and "HEAD" not in line:
                remote_branches.add(line[len("origin/"):])

    main_candidates = ["main", "master"]
    main_branch = next((b for b in main_candidates if b in local_branches), None)
    info["main_branch"] = main_branch

    for b in local_branches:
        bi = {"name": b, "on_remote": b in remote_branches}

        # ahead/behind vs origin/<b>
        if b in remote_branches:
            rc, out, _ = run(["git", "-C", str(path), "rev-list",
                              "--left-right", "--count",
                              f"{b}...origin/{b}"])
            if rc == 0 and out:
                a, beh = out.split()
                bi["ahead_of_origin"] = int(a)
                bi["behind_origin"] = int(beh)

        # if not the main, see if main contains this branch's tip
        if main_branch and b != main_branch:
            rc, out, _ = run(["git", "-C", str(path), "rev-list",
                              "--left-right", "--count",
                              f"{main_branch}...{b}"])
            if rc == 0 and out:
                # main is behind by `behind`, branch is ahead by `ahead`
                a, beh = out.split()
                bi["main_behind_by"] = int(beh)
                bi["main_ahead_by"] = int(a)
                # check if the branch tip is reachable from main
                rc2, out2, _ = run(["git", "-C", str(path), "merge-base",
                                    "--is-ancestor", b, main_branch])
                bi["merged_into_main"] = (rc2 == 0)

        # last commit
        rc, out, _ = run(["git", "-C", str(path), "log", "-1",
                          "--format=%h %ar  %s", b])
        bi["last_commit"] = out if rc == 0 else ""

        info["branches"].append(bi)

    return info

def main():
    repos = sorted(find_repos(ROOT))
    print(f"# Branch audit of {len(repos)} repos under {ROOT}", file=sys.stderr)
    out = []
    for r in repos:
        print(f"  scanning {r.relative_to(ROOT)}", file=sys.stderr)
        out.append(audit_repo(r))
    print(json.dumps(out, indent=2, default=str))

if __name__ == "__main__":
    main()
