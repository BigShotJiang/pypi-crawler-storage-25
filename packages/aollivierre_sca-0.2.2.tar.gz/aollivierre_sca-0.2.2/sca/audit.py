#!/usr/bin/env python3
"""Audit a code root: classify every folder, find gaps (no remote, dirty, etc.)

Usage:
    python audit-code.py [--root <path>] > audit.json
    python audit-code.py --root /home/me/code > audit.json   # Linux
    python audit-code.py --root C:/code > audit.json         # Windows

Defaults to env var CODE_ROOT or the current working directory.
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

_parser = argparse.ArgumentParser()
_parser.add_argument("--root", default=os.environ.get("CODE_ROOT", os.getcwd()))
_args, _ = _parser.parse_known_args()
ROOT = Path(_args.root).resolve()
SKIP = {".archive", ".claude", "temp", "secrets"}

def classify_remote_protocol(url: str) -> str:
    """Return 'https', 'ssh', 'git', or 'other' for a remote URL."""
    u = (url or "").strip()
    if not u:
        return "other"
    if u.startswith(("https://", "http://")):
        return "https"
    if u.startswith("ssh://") or u.startswith("git@"):
        return "ssh"
    if u.startswith("git://"):
        return "git"
    return "other"


def run(cmd, cwd=None, timeout=20):
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                           timeout=timeout, shell=False)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except Exception as e:
        return -1, "", str(e)

def find_repos(root: Path, max_depth=3):
    """Yield every directory containing a .git directory, up to max_depth."""
    for dirpath, dirnames, _ in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        depth = len(rel.parts)
        if depth > max_depth:
            dirnames[:] = []
            continue
        # skip noise (and our own run-output dirs / secret backup dirs)
        if any(part in SKIP or part.startswith("sca-run-") or part == "sca-final-report"
               for part in rel.parts):
            dirnames[:] = []
            continue
        if ".git" in dirnames:
            yield Path(dirpath)
            dirnames.remove(".git")  # don't descend into .git
        # don't descend into common heavy dirs
        for noisy in ("node_modules", "__pycache__", ".venv", "venv", "env",
                      "ignored-bad-zips", "recorder-dom-capture", "dist", "build"):
            if noisy in dirnames:
                dirnames.remove(noisy)

def list_top_level(root: Path):
    """Top-level directories that are NOT git repos and NOT skipped."""
    for entry in sorted(root.iterdir()):
        if not entry.is_dir():
            continue
        if (entry.name in SKIP
                or entry.name.startswith("sca-run-")
                or entry.name == "sca-final-report"):
            continue
        if (entry / ".git").exists():
            continue
        yield entry

def classify_repo(path: Path) -> dict:
    info: dict = {
        "path": str(path),
        "name": str(path.relative_to(ROOT)),
        "type": "repo",
    }
    rc, out, _ = run(["git", "-C", str(path), "branch", "--show-current"])
    info["branch"] = out if rc == 0 else None

    rc, out, _ = run(["git", "-C", str(path), "remote", "-v"])
    remotes = {}
    if rc == 0 and out:
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                remotes[parts[0]] = parts[1]
    info["remotes"] = remotes
    info["has_remote"] = bool(remotes)
    info["remote_protocols"] = {n: classify_remote_protocol(u) for n, u in remotes.items()}
    info["uses_ssh"] = any(p == "ssh" for p in info["remote_protocols"].values())

    rc, out, _ = run(["git", "-C", str(path), "status", "-s"])
    info["dirty_files"] = len(out.splitlines()) if out else 0
    info["dirty"] = info["dirty_files"] > 0

    # untracked count
    rc, out, _ = run(["git", "-C", str(path), "ls-files", "--others",
                      "--exclude-standard"])
    info["untracked_files"] = len(out.splitlines()) if out else 0

    # ahead/behind
    info["ahead"] = 0
    info["behind"] = 0
    rc, out, _ = run(["git", "-C", str(path), "rev-list", "--left-right",
                      "--count", "HEAD...@{u}"])
    if rc == 0 and out:
        try:
            a, b = out.split()
            info["ahead"] = int(a)
            info["behind"] = int(b)
        except Exception:
            pass

    # commit count (depth)
    rc, out, _ = run(["git", "-C", str(path), "rev-list", "--count", "HEAD"])
    info["commits"] = int(out) if rc == 0 and out else 0

    # last commit
    rc, out, _ = run(["git", "-C", str(path), "log", "-1",
                      "--format=%h %ar  %s"])
    info["last_commit"] = out if rc == 0 else ""

    # remote reachability (only origin, fast)
    info["remote_reachable"] = None
    info["remote_check_error"] = None
    if "origin" in remotes:
        rc, _, err = run(["git", "-C", str(path), "ls-remote",
                          "--exit-code", "--heads", "origin"], timeout=15)
        info["remote_reachable"] = (rc == 0)
        if rc != 0:
            info["remote_check_error"] = err.splitlines()[0] if err else f"rc={rc}"

    # is it on github.com?
    info["on_github"] = any("github.com" in url for url in remotes.values())

    # README presence (any case-insensitive README.* at the repo root)
    has_readme = False
    try:
        for child in path.iterdir():
            if child.is_file() and child.name.lower().startswith("readme"):
                has_readme = True
                break
    except OSError:
        pass
    info["has_readme"] = has_readme

    # file count + size (rough)
    total = 0
    count = 0
    for dirpath, dirnames, filenames in os.walk(path):
        if ".git" in dirnames:
            dirnames.remove(".git")
        for n in ("node_modules", "__pycache__", ".venv", "venv", "env",
                  "ignored-bad-zips", "recorder-dom-capture"):
            if n in dirnames:
                dirnames.remove(n)
        for f in filenames:
            try:
                total += (Path(dirpath) / f).stat().st_size
                count += 1
            except OSError:
                pass
        if count > 5000:
            break
    info["file_count"] = count
    info["size_mb"] = round(total / (1024*1024), 1)

    # gap classification
    gaps = []
    if not info["has_remote"]:
        gaps.append("NO_REMOTE")
    elif info["remote_reachable"] is False:
        gaps.append("REMOTE_UNREACHABLE")
    if not info["on_github"] and info["has_remote"]:
        gaps.append("REMOTE_NOT_GITHUB")
    if info["uses_ssh"]:
        gaps.append("REMOTE_USES_SSH")
    if not info["has_readme"]:
        gaps.append("MISSING_README")
    if info["ahead"] > 0:
        gaps.append(f"AHEAD_{info['ahead']}")
    if info["behind"] > 0:
        gaps.append(f"BEHIND_{info['behind']}")
    if info["dirty"]:
        gaps.append(f"DIRTY_{info['dirty_files']}")
    info["gaps"] = gaps
    info["status"] = "ok" if not gaps else ("critical" if "NO_REMOTE" in gaps or "REMOTE_UNREACHABLE" in gaps else "warning")
    return info

def classify_nonrepo(path: Path) -> dict:
    total = 0
    count = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for n in ("node_modules", "__pycache__", ".venv", "venv", "env"):
            if n in dirnames:
                dirnames.remove(n)
        for f in filenames:
            try:
                total += (Path(dirpath) / f).stat().st_size
                count += 1
            except OSError:
                pass
        if count > 5000:
            break
    return {
        "path": str(path),
        "name": str(path.relative_to(ROOT)),
        "type": "non_repo",
        "file_count": count,
        "size_mb": round(total / (1024*1024), 1),
        "gaps": ["NOT_A_REPO"],
        "status": "critical",
    }

def loose_files(root: Path):
    """Loose files at the root level (not in any repo)."""
    out = []
    for entry in sorted(root.iterdir()):
        if entry.is_file():
            try:
                out.append({
                    "path": str(entry),
                    "name": entry.name,
                    "type": "loose_file",
                    "size_mb": round(entry.stat().st_size / (1024*1024), 3),
                    "gaps": ["LOOSE_FILE_NOT_IN_REPO"],
                    "status": "warning",
                })
            except OSError:
                pass
    return out

def main():
    repos = sorted(set(find_repos(ROOT)))
    repo_paths = {str(p) for p in repos}

    results = []
    print(f"[*] found {len(repos)} repos", file=sys.stderr)
    for r in repos:
        print(f"[*] classifying {r.relative_to(ROOT)}...", file=sys.stderr)
        results.append(classify_repo(r))

    # non-repo top-level dirs
    for d in list_top_level(ROOT):
        if str(d) in repo_paths:
            continue
        # skip if it CONTAINS repos (parent of nested repos)
        contains_repo = any(str(d) == str(p.parent) or
                            str(p).startswith(str(d) + os.sep)
                            for p in repos)
        if contains_repo:
            results.append({
                "path": str(d),
                "name": str(d.relative_to(ROOT)),
                "type": "container",
                "gaps": [],
                "status": "info",
            })
        else:
            print(f"[*] non-repo dir {d.relative_to(ROOT)}...", file=sys.stderr)
            results.append(classify_nonrepo(d))

    # loose files at root
    results.extend(loose_files(ROOT))

    print(json.dumps(results, indent=2, default=str))

if __name__ == "__main__":
    main()
