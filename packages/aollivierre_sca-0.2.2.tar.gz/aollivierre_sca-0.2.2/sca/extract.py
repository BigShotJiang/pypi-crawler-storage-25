#!/usr/bin/env python3
"""Detect and (optionally) repair the "wrapper repo" antipattern.

Pattern: a parent directory has its own `.git`, and one or more child
directories also have their own `.git`. Symptoms:
  - Parent's `git status` lists nested repos as untracked or as gitlinks.
  - One `git add .` in the parent can accidentally embed children as
    submodule-shaped pointers.
  - History is split: parent commits a path, child has its own log
    for that path.

Detection (the easy half):
  Walk a code root. Any `.git` directory whose parent is itself inside
  another `.git`'s working tree is a child of a wrapper.

Repair (the harder half):
  Two clean options:
    A. Extract the parent's history of one specific subtree into a new
       repo (`git subtree split`), kill the parent .git. Useful when the
       parent's "useful work" lives entirely in one subdir.
    B. Archive the parent .git as a bare mirror, then delete it. The
       child repos remain untouched. Use when the parent was just a
       loose scratchpad with no real organising principle.

We default to detect-only. Repair operations are gated by an explicit
flag because they're destructive (subtree split + parent .git removal).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class WrapperFinding:
    parent_repo: str          # path of the wrapping repo
    nested_repos: list[str]   # paths of child repos contained inside
    parent_remote: str | None # parent's origin URL, if any
    parent_branch: str | None
    parent_tracked_files: int
    suggested_action: str

    def asdict(self) -> dict:
        return asdict(self)


def _run(cmd: list[str], cwd: Path | None = None) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=20)
        return r.returncode, r.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        return -1, ""


def _find_all_repos(root: Path, max_depth: int = 4) -> list[Path]:
    """Yield every directory containing a .git/, up to max_depth."""
    repos: list[Path] = []
    for dirpath, dirnames, _ in os.walk(root):
        rel_depth = len(Path(dirpath).relative_to(root).parts)
        if rel_depth > max_depth:
            dirnames[:] = []
            continue
        if ".git" in dirnames:
            repos.append(Path(dirpath))
            dirnames.remove(".git")
        for noisy in ("node_modules", "__pycache__", ".venv", "venv",
                      "dist", "build"):
            if noisy in dirnames:
                dirnames.remove(noisy)
    return repos


def detect(root: Path) -> list[WrapperFinding]:
    """Scan a code root for wrapper-repo situations."""
    repos = sorted(_find_all_repos(root.resolve()), key=lambda p: len(p.parts))
    findings: list[WrapperFinding] = []

    for parent in repos:
        # nested = repos whose path is strictly under `parent`
        nested = [
            r for r in repos
            if r != parent and parent.resolve() in r.resolve().parents
        ]
        if not nested:
            continue

        rc, remote_out = _run(["git", "-C", str(parent), "remote", "get-url", "origin"])
        remote: str | None = remote_out if rc == 0 else None
        rc, branch_out = _run(["git", "-C", str(parent), "branch", "--show-current"])
        branch: str | None = branch_out if rc == 0 else None
        rc, files_out = _run(["git", "-C", str(parent), "ls-files"])
        tracked = len(files_out.splitlines()) if rc == 0 else 0

        if not remote and tracked < 5:
            suggested = "archive-and-delete: parent has no remote and barely any tracked content"
        elif not remote:
            suggested = "subtree-split: parent has no remote but tracks meaningful content; extract into its own repo and kill the parent .git"
        else:
            suggested = "investigate: parent has its own remote -- probably intentional submodule-style layout, but verify"

        findings.append(WrapperFinding(
            parent_repo=str(parent),
            nested_repos=[str(r) for r in nested],
            parent_remote=remote,
            parent_branch=branch,
            parent_tracked_files=tracked,
            suggested_action=suggested,
        ))

    return findings


def archive_and_delete(parent_repo: Path, archive_remote: str | None = None) -> dict:
    """Repair option B: rename the parent .git to .git.archive-<date> and
    optionally push it as a bare mirror to a new GitHub repo first.
    Does NOT touch the child repos."""
    parent_repo = parent_repo.resolve()
    git_dir = parent_repo / ".git"
    if not git_dir.is_dir():
        return {"ok": False, "reason": f"no .git at {parent_repo}"}

    from datetime import date
    archive_path = parent_repo / f".git.archive-{date.today().isoformat()}"
    if archive_path.exists():
        return {"ok": False, "reason": f"archive path already exists: {archive_path}"}

    pushed = None
    if archive_remote:
        rc, out = _run(["git", "--git-dir", str(git_dir), "push", "--mirror", archive_remote])
        pushed = (rc == 0)
        if not pushed:
            return {"ok": False, "reason": f"mirror push failed: {out}"}

    git_dir.rename(archive_path)
    return {
        "ok": True,
        "parent_repo": str(parent_repo),
        "archive_path": str(archive_path),
        "pushed_to_remote": pushed,
    }


def subtree_split(parent_repo: Path, prefix: str, new_repo_dir: Path) -> dict:
    """Repair option A: extract a subtree's history from the parent into a
    new repo at `new_repo_dir`. Caller is responsible for archiving/deleting
    the parent .git afterward."""
    parent_repo = parent_repo.resolve()
    new_repo_dir = new_repo_dir.resolve()

    # 1. subtree split into a temp branch on the parent
    branch_name = f"sca-extract/{prefix.strip('/')}"
    rc, _ = _run(
        ["git", "-C", str(parent_repo), "subtree", "split",
         f"--prefix={prefix}", "-b", branch_name]
    )
    if rc != 0:
        return {"ok": False, "reason": f"git subtree split failed for prefix {prefix}"}

    # 2. clone that branch into the target dir
    if new_repo_dir.exists() and any(new_repo_dir.iterdir()):
        return {"ok": False,
                "reason": f"target {new_repo_dir} exists and isn't empty"}
    new_repo_dir.mkdir(parents=True, exist_ok=True)
    rc, out = _run([
        "git", "-c", "core.autocrlf=false", "clone",
        "-b", branch_name, "--single-branch",
        f"file://{parent_repo}", str(new_repo_dir),
    ])
    if rc != 0:
        return {"ok": False, "reason": f"clone of split branch failed: {out}"}

    # 3. set HEAD branch to main and drop the temp upstream
    _run(["git", "-C", str(new_repo_dir), "branch", "-m", branch_name, "main"])
    _run(["git", "-C", str(new_repo_dir), "remote", "remove", "origin"])
    _run(["git", "-C", str(new_repo_dir), "branch", "--unset-upstream", "main"])

    return {
        "ok": True,
        "parent_repo": str(parent_repo),
        "prefix": prefix,
        "new_repo_dir": str(new_repo_dir),
        "split_branch": branch_name,
    }


# ---------- CLI ----------

def _format_findings(findings: list[WrapperFinding], root: Path) -> str:
    if not findings:
        return "no wrapper-repo situations found\n"
    lines = []
    for f in findings:
        lines.append(f"\nWRAPPER: {Path(f.parent_repo).relative_to(root)}")
        lines.append(f"  remote:  {f.parent_remote or '<none>'}")
        lines.append(f"  branch:  {f.parent_branch or '<none>'}")
        lines.append(f"  tracked: {f.parent_tracked_files} files")
        lines.append(f"  nested ({len(f.nested_repos)}):")
        for n in f.nested_repos:
            lines.append(f"    - {Path(n).relative_to(root)}")
        lines.append(f"  suggested: {f.suggested_action}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Detect (and optionally repair) wrapper-repo situations."
    )
    ap.add_argument("--root",
                    default=os.environ.get("CODE_ROOT", os.getcwd()),
                    help="Code root to scan")
    ap.add_argument("--json", action="store_true",
                    help="Emit JSON instead of text")
    ap.add_argument("--archive-and-delete",
                    metavar="PARENT_REPO",
                    help="Repair: rename parent .git to .git.archive-<date>")
    ap.add_argument("--mirror-to",
                    metavar="GIT_URL",
                    help="With --archive-and-delete: also push the .git as a bare mirror to this URL first")
    args = ap.parse_args(argv)

    if args.archive_and_delete:
        result = archive_and_delete(Path(args.archive_and_delete), args.mirror_to)
        print(json.dumps(result, indent=2))
        return 0 if result.get("ok") else 2

    root = Path(args.root).resolve()
    findings = detect(root)

    if args.json:
        print(json.dumps([f.asdict() for f in findings], indent=2))
    else:
        print(_format_findings(findings, root), end="")

    return 0 if not findings else 1


if __name__ == "__main__":
    sys.exit(main())
