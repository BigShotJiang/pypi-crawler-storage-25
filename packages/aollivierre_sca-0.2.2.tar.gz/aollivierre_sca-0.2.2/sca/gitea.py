#!/usr/bin/env python3
"""Gitea mirror support.

Discovery: query Gitea's REST API for the authenticated user's repos and
pair them up with local code folders the same way `sca/mapping.py` does
for GitHub. Annotation lives on the audit entry as `gitea_match`.

Configuration: read from environment.
    GITEA_HOST   -- e.g. 'https://git.example.com' (required)
    GITEA_TOKEN  -- personal access token (required for private repos)
    GITEA_USER   -- optional; defaults to the token's owning user

When neither var is set, the module is a no-op and the rest of the
pipeline runs unchanged. This makes Gitea support strictly opt-in.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

DEFAULT_PER_PAGE = 50


def _env_config() -> tuple[str | None, str | None, str | None]:
    host = os.environ.get("GITEA_HOST", "").strip().rstrip("/") or None
    token = os.environ.get("GITEA_TOKEN", "").strip() or None
    user = os.environ.get("GITEA_USER", "").strip() or None
    return host, token, user


def _api_get(host: str, path: str, token: str | None,
             timeout: int = 15) -> tuple[int, list | dict | None]:
    url = f"{host.rstrip('/')}/api/v1/{path.lstrip('/')}"
    req = urllib.request.Request(url)
    req.add_header("Accept", "application/json")
    req.add_header("User-Agent", "sca-gitea-client")
    if token:
        req.add_header("Authorization", f"token {token}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            body = resp.read().decode("utf-8")
            return resp.status, json.loads(body) if body else None
    except urllib.error.HTTPError as e:
        return e.code, None
    except (urllib.error.URLError, OSError):
        return -1, None


def list_user_repos(host: str | None = None,
                    token: str | None = None,
                    user: str | None = None) -> list[dict] | None:
    """List the configured user's Gitea repos. Returns None if Gitea
    isn't configured (env vars missing) or the request fails."""
    if host is None or token is None:
        host_env, token_env, user_env = _env_config()
        host = host or host_env
        token = token or token_env
        user = user or user_env
    if not host or not token:
        return None

    repos: list[dict] = []
    page = 1
    while True:
        path = f"repos/search?limit={DEFAULT_PER_PAGE}&page={page}"
        if user:
            path += f"&owner={urllib.parse.quote(user)}"
        else:
            # /user/repos returns the authenticated user's repos
            path = f"user/repos?limit={DEFAULT_PER_PAGE}&page={page}"
        status, data = _api_get(host, path, token)
        if status != 200 or not data:
            break
        chunk = data.get("data") if isinstance(data, dict) else data
        if not chunk:
            break
        repos.extend(chunk)
        if len(chunk) < DEFAULT_PER_PAGE:
            break
        page += 1
        if page > 100:  # hard stop, never spin
            break
    # Normalise: surface name + clone_url + html_url + visibility
    out: list[dict] = []
    for r in repos:
        if not isinstance(r, dict):
            continue
        out.append({
            "name": r.get("name") or "",
            "full_name": r.get("full_name") or "",
            "url": r.get("html_url") or "",
            "clone_url": r.get("clone_url") or "",
            "ssh_url": r.get("ssh_url") or "",
            "private": bool(r.get("private")),
            "archived": bool(r.get("archived")),
            "fork": bool(r.get("fork")),
        })
    return out


def find_match(local_name: str, gitea_repos: list[dict]) -> dict | None:
    """Pure-name match (case-insensitive, separator-collapsed). Returns
    the first match or None."""
    if not local_name or not gitea_repos:
        return None
    target = local_name.lower().replace("_", "-").replace(" ", "-")
    for r in gitea_repos:
        name = (r.get("name") or "").lower().replace("_", "-").replace(" ", "-")
        if name == target:
            return r
    return None


def annotate(audit_entries: list[dict],
             gitea_repos: list[dict] | None) -> list[dict]:
    """Augment entries with `gitea_match` (and `gitea_mirrored` flag).

    The flag is True when the audit already shows a `gitea` remote on
    the local repo and a matching repo exists upstream."""
    if not gitea_repos:
        return audit_entries
    for entry in audit_entries:
        leaf = Path(entry.get("name") or "").name
        match = find_match(leaf, gitea_repos)
        if not match:
            continue
        entry["gitea_match"] = match
        # `gitea` already configured as a remote? Check by name OR by URL.
        remotes = entry.get("remotes") or {}
        clone_lc = (match.get("clone_url") or "").lower()
        html_lc = (match.get("html_url") or "").lower()
        already = False
        for rname, rurl in remotes.items():
            if "gitea" in (rname or "").lower():
                already = True
                break
            url_lc = (rurl or "").lower()
            if url_lc and (clone_lc == url_lc or (html_lc and html_lc in url_lc)):
                already = True
                break
        entry["gitea_mirrored"] = already
    return audit_entries


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Annotate audit JSON with Gitea matches.")
    ap.add_argument("--audit", default="-",
                    help="Path to audit JSON (default: stdin)")
    ap.add_argument("--out", default="-",
                    help="Output path (default: stdout)")
    ap.add_argument("--host", default=None)
    ap.add_argument("--token", default=None)
    ap.add_argument("--user", default=None)
    args = ap.parse_args(argv)

    if args.audit == "-":
        data = json.load(sys.stdin)
    else:
        with open(args.audit, encoding="utf-8") as f:
            data = json.load(f)

    repos = list_user_repos(host=args.host, token=args.token, user=args.user)
    if repos is None:
        print("[gitea] not configured (set GITEA_HOST + GITEA_TOKEN); "
              "passing audit through unchanged", file=sys.stderr)
    else:
        annotate(data, repos)
        matched = sum(1 for e in data if e.get("gitea_match"))
        print(f"[gitea] queried {len(repos)} repo(s); matched {matched} local entry(ies)",
              file=sys.stderr)

    payload = json.dumps(data, indent=2, default=str)
    if args.out == "-":
        sys.stdout.write(payload)
    else:
        Path(args.out).write_text(payload, encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
