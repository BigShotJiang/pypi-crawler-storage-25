#!/usr/bin/env python3
"""Batch-push every unpushed branch across one or more repos.

Closes the gap from the manual cleanup workflow: walk repos under a code
root, find local branches that aren't on the remote (or are strictly ahead
of it), run the secret scanner, and push each one.

Diverged branches (both local and remote have unique commits) are skipped
-- they require human judgement (merge, rebase, force-push).

Each push goes through `remediate._visibility_gate()` so a public repo
with critical secret findings can never leak via this command.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

from sca import branches as _branches
from sca import remediate as _remediate


@dataclass
class BranchPushResult:
    repo: str
    branch: str
    action: str          # "would-push" / "pushed" / "skipped" / "blocked" / "failed"
    reason: str = ""

    def asdict(self) -> dict:
        return asdict(self)


def _run(cmd: list[str], cwd: Path | None = None,
         timeout: int = 60) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True,
                           text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (subprocess.TimeoutExpired, OSError) as e:
        return -1, "", str(e)


def _branches_needing_push(repo_path: Path) -> list[dict]:
    """Use branches.audit_repo to identify branches to push.

    Returns dicts with at least: name, on_remote, ahead_of_origin, behind_origin."""
    # branches.audit_repo uses ROOT for a `name` rel-path; point it at the
    # repo's parent so relative_to never raises on isolated test repos.
    _branches.ROOT = repo_path.parent.resolve()
    info = _branches.audit_repo(repo_path)
    out: list[dict] = []
    for b in info.get("branches", []):
        if not b.get("on_remote"):
            out.append({**b, "_reason": "not on remote"})
            continue
        ahead = b.get("ahead_of_origin", 0)
        behind = b.get("behind_origin", 0)
        if ahead > 0 and behind == 0:
            out.append({**b, "_reason": f"ahead by {ahead}"})
        elif ahead > 0 and behind > 0:
            # diverged -- skip
            continue
    return out


def push_branches_in_repo(repo_path: Path, *,
                          apply: bool = False,
                          offline: bool = False) -> list[BranchPushResult]:
    """Push every local branch in `repo_path` that's missing or ahead on
    origin. Honors apply (default dry-run) and offline (visibility-gate
    fallback)."""
    repo_path = repo_path.resolve()
    repo_name = repo_path.name
    results: list[BranchPushResult] = []

    # Visibility gate runs ONCE per repo (the gate is a property of origin
    # + the secret scan of the working tree, not per branch).
    allowed, gate_reason = _remediate._visibility_gate(repo_path, offline=offline)

    candidates = _branches_needing_push(repo_path)
    if not candidates:
        return results

    if not allowed:
        for b in candidates:
            results.append(BranchPushResult(
                repo=repo_name, branch=b["name"],
                action="blocked",
                reason=f"visibility gate blocked the push: {gate_reason}",
            ))
        return results

    for b in candidates:
        bname = b["name"]
        if not apply:
            results.append(BranchPushResult(
                repo=repo_name, branch=bname, action="would-push",
                reason=f"{b['_reason']}; gate: {gate_reason}",
            ))
            continue

        # Push. If branch is not on remote, set upstream; if it is and we're
        # ahead, plain push.
        if not b.get("on_remote"):
            cmd = ["git", "-C", str(repo_path), "push", "-u", "origin", bname]
        else:
            cmd = ["git", "-C", str(repo_path), "push", "origin", bname]
        rc, _stdout, stderr = _run(cmd)
        if rc == 0:
            results.append(BranchPushResult(
                repo=repo_name, branch=bname, action="pushed",
                reason=b["_reason"],
            ))
        else:
            results.append(BranchPushResult(
                repo=repo_name, branch=bname, action="failed",
                reason=stderr.splitlines()[0] if stderr else f"rc={rc}",
            ))
    return results


def _walk_repos(root: Path) -> list[Path]:
    """Find every git repo under `root` (depth-limited to match audit.py)."""
    repos: list[Path] = []
    for dirpath, dirnames, _ in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        if any(p in {".archive", ".claude", "temp"} for p in rel.parts):
            dirnames[:] = []
            continue
        if len(rel.parts) > 3:
            dirnames[:] = []
            continue
        if ".git" in dirnames:
            repos.append(Path(dirpath))
            dirnames.remove(".git")
        for noisy in ("node_modules", "__pycache__", ".venv", "venv",
                      "dist", "build"):
            if noisy in dirnames:
                dirnames.remove(noisy)
    return repos


def push_branches_in_root(root: Path, *,
                          apply: bool = False,
                          offline: bool = False) -> list[BranchPushResult]:
    """Walk every repo under `root` and run push_branches_in_repo on each."""
    out: list[BranchPushResult] = []
    for repo in _walk_repos(root.resolve()):
        out.extend(push_branches_in_repo(repo, apply=apply, offline=offline))
    return out


def _format_text(results: list[BranchPushResult]) -> str:
    if not results:
        return "no branches needed pushing\n"
    lines = []
    by_repo: dict[str, list[BranchPushResult]] = {}
    for r in results:
        by_repo.setdefault(r.repo, []).append(r)
    for repo, items in by_repo.items():
        lines.append(f"\n{repo}:")
        for r in items:
            marker = {
                "would-push": "*",
                "pushed":     "[OK]",
                "skipped":    "-",
                "blocked":    "[WARNING]",
                "failed":     "[FAIL]",
            }.get(r.action, " ")
            lines.append(f"  {marker} {r.branch:40s} {r.action:12s}  {r.reason}")
    counts: dict[str, int] = {}
    for r in results:
        counts[r.action] = counts.get(r.action, 0) + 1
    lines.append("")
    lines.append(f"summary: {dict(counts)}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Batch-push unpushed/ahead branches across one or more repos."
    )
    ap.add_argument("--root",
                    default=os.environ.get("CODE_ROOT", os.getcwd()),
                    help="Code root to walk (default: $CODE_ROOT or cwd)")
    ap.add_argument("--apply", action="store_true",
                    help="Actually push (default: dry-run)")
    ap.add_argument("--offline", action="store_true",
                    help="Use offline visibility gate (treats unknown as public)")
    ap.add_argument("--json", action="store_true",
                    help="Emit JSON instead of formatted text")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    results = push_branches_in_root(root, apply=args.apply, offline=args.offline)

    if args.json:
        print(json.dumps([r.asdict() for r in results], indent=2))
    else:
        print(_format_text(results), end="")

    failures = sum(1 for r in results if r.action == "failed")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
