#!/usr/bin/env python3
"""Repo state and strategy classification.

Ports v1's 5-state model and repo-strategy decision into a stateless
function library that operates on audit entries (the dicts emitted by
`sca/audit.py`).

State (a measurable git fact):
    NoSourceControl       -- directory without .git
    LocalGitOnly          -- repo with no remote
    IncompleteSourceControl -- repo with uncommitted/unstaged work
    PartiallySynced       -- repo with unpushed (or unfetched) commits
    FullyCompliant        -- repo, has remote, clean tree, in sync

Strategy (a recommendation, not a fact):
    Dedicated             -- give this its own GitHub repo
    Consolidated          -- fold into an umbrella "misc" repo
    Skip                  -- too small / empty / junk to bother

Both are pure functions of audit fields (+ optional filesystem peek for
strategy) -- no side effects, no git calls. That keeps them trivial to
unit-test.
"""
from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class RepoState(str, Enum):
    NO_SOURCE_CONTROL = "NoSourceControl"
    LOCAL_GIT_ONLY = "LocalGitOnly"
    INCOMPLETE = "IncompleteSourceControl"
    PARTIALLY_SYNCED = "PartiallySynced"
    FULLY_COMPLIANT = "FullyCompliant"
    EMPTY = "Empty"  # not in v1 -- empty dirs don't deserve a repo
    LOOSE_FILE = "LooseFile"
    WRAPPER_REPO = "WrapperRepo"  # not in v1 -- parent of nested repos
    CONTAINER = "Container"        # benign organisational dir holding child repos


class RepoStrategy(str, Enum):
    DEDICATED = "Dedicated"
    CONSOLIDATED = "Consolidated"
    SKIP = "Skip"


@dataclass
class Classification:
    state: RepoState
    strategy: RepoStrategy
    reason: str

    def asdict(self) -> dict:
        return {
            "state": self.state.value,
            "strategy": self.strategy.value,
            "reason": self.reason,
        }


# ---------- state ----------

def classify_state(entry: dict) -> RepoState:
    """Derive a RepoState from one audit entry dict."""
    t = entry.get("type")

    if t == "loose_file":
        return RepoState.LOOSE_FILE
    if t == "container":
        # An organisational directory (e.g. C:/code/Windows/) that holds
        # child git repos but is NOT itself a repo -- nothing to fix,
        # just inventory. The genuine wrapper-repo antipattern (an outer
        # `.git` wrapping nested `.git` directories) is detected by
        # sca/extract.py and surfaces as type=repo with extras, not as
        # type=container.
        return RepoState.CONTAINER
    if t == "non_repo":
        if entry.get("file_count", 0) == 0:
            return RepoState.EMPTY
        return RepoState.NO_SOURCE_CONTROL

    if t != "repo":
        return RepoState.NO_SOURCE_CONTROL

    if not entry.get("has_remote"):
        return RepoState.LOCAL_GIT_ONLY
    if entry.get("dirty"):
        return RepoState.INCOMPLETE
    if entry.get("ahead", 0) > 0 or entry.get("behind", 0) > 0:
        return RepoState.PARTIALLY_SYNCED

    return RepoState.FULLY_COMPLIANT


# ---------- strategy ----------

# File markers that strongly signal "this is a real project, not a junk drawer"
DEDICATED_FILE_MARKERS = (
    ".sln", ".csproj", ".vbproj", ".fsproj",      # .NET
    "pyproject.toml", "setup.py", "setup.cfg",    # Python
    "package.json", "tsconfig.json",              # Node / TS
    "Cargo.toml", "go.mod",                       # Rust / Go
    "Gemfile", "composer.json",                    # Ruby / PHP
    "CMakeLists.txt", "Makefile",                  # C/C++
    "pom.xml", "build.gradle", "build.gradle.kts", # Java
    "Dockerfile", "docker-compose.yml",           # containerized
    ".github/workflows",                          # has CI
    "README.md",                                  # has its own readme (weak signal)
)

# Threshold above which a directory is large enough to deserve its own repo
DEDICATED_FILE_COUNT_THRESHOLD = 50


def _has_dedicated_marker(path: Path) -> str | None:
    """Return the first DEDICATED_FILE_MARKERS hit (or None)."""
    if not path.exists():
        return None
    for marker in DEDICATED_FILE_MARKERS:
        if (path / marker).exists():
            return marker
        # globs not supported in this simple scan; .csproj etc. need a glob
        if marker.startswith("."):
            try:
                for child in path.iterdir():
                    if child.suffix == marker:
                        return child.name
            except OSError:
                pass
    return None


def classify_strategy(entry: dict, path: Path | None = None) -> Classification:
    """Decide whether a directory deserves a dedicated repo, should be
    consolidated, or skipped entirely.

    Inputs come from the audit entry; `path` is optional and used to peek
    for project-marker files (.sln, pyproject.toml, etc.).
    """
    state = classify_state(entry)

    # Trivial cases first
    if state == RepoState.EMPTY:
        return Classification(state, RepoStrategy.SKIP,
                              "Empty directory -- nothing to back up")
    if state == RepoState.LOOSE_FILE:
        return Classification(state, RepoStrategy.CONSOLIDATED,
                              "Loose file at root -- fold into a workspace umbrella repo")
    if state == RepoState.CONTAINER:
        return Classification(state, RepoStrategy.SKIP,
                              "Organisational directory holding child repos -- no action needed")
    if state == RepoState.WRAPPER_REPO:
        return Classification(state, RepoStrategy.DEDICATED,
                              "Wrapper repo around nested children -- extract via sca extract")

    # Existing git repos always stay dedicated
    if entry.get("type") == "repo":
        return Classification(state, RepoStrategy.DEDICATED,
                              "Already a git repo -- preserve dedicated history")

    # For non-repo directories with content, consult markers + size
    if path is None:
        path_str = entry.get("path")
        if path_str:
            path = Path(path_str)

    file_count = entry.get("file_count", 0)

    if file_count > DEDICATED_FILE_COUNT_THRESHOLD:
        return Classification(state, RepoStrategy.DEDICATED,
                              f"Large project ({file_count} files > {DEDICATED_FILE_COUNT_THRESHOLD})")

    if path is not None:
        marker = _has_dedicated_marker(path)
        if marker:
            return Classification(state, RepoStrategy.DEDICATED,
                                  f"Project marker present: {marker}")

    if file_count <= 3:
        return Classification(state, RepoStrategy.CONSOLIDATED,
                              f"Tiny ({file_count} files) -- fold into umbrella repo")

    return Classification(state, RepoStrategy.CONSOLIDATED,
                          f"Small ({file_count} files), no project markers -- consolidate")


# ---------- batch ----------

def classify_all(audit_data: list[dict]) -> list[dict]:
    """Augment each audit entry with a `classification` field. Returns a new
    list; doesn't mutate inputs."""
    out: list[dict] = []
    for entry in audit_data:
        copy = dict(entry)
        path_str = entry.get("path")
        path = Path(path_str) if path_str else None
        copy["classification"] = classify_strategy(entry, path).asdict()
        out.append(copy)
    return out


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Classify audit entries.")
    ap.add_argument("--audit", default="-",
                    help="Path to audit JSON (default: stdin)")
    ap.add_argument("--summary", action="store_true",
                    help="Print a per-state count to stderr instead of full JSON")
    args = ap.parse_args(argv)

    if args.audit == "-":
        data = json.load(sys.stdin)
    else:
        with open(args.audit, encoding="utf-8") as f:
            data = json.load(f)

    classified = classify_all(data)

    if args.summary:
        from collections import Counter
        states = Counter(c["classification"]["state"] for c in classified)
        strategies = Counter(c["classification"]["strategy"] for c in classified)
        print("=== state counts ===", file=sys.stderr)
        for k, v in sorted(states.items(), key=lambda kv: -kv[1]):
            print(f"  {k:30s} {v}", file=sys.stderr)
        print("\n=== strategy counts ===", file=sys.stderr)
        for k, v in sorted(strategies.items(), key=lambda kv: -kv[1]):
            print(f"  {k:30s} {v}", file=sys.stderr)
        return 0

    print(json.dumps(classified, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
