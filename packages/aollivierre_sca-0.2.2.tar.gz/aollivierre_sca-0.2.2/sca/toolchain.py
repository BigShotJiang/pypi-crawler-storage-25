#!/usr/bin/env python3
"""Audit the local toolchain + GitHub auth posture.

What we want to know on any machine running `sca`:
    - is git installed? what version?
    - is gh installed? what version? is it authenticated?
    - what credential helper is configured? (we want a real OS keychain --
      not 'store' which writes plaintext to disk, not '' which means
      every push prompts for a password)
    - are there any known-bad signals (PAT in env, SSH keys not in agent)?

Strictly read-only. Returns a single dict; nothing about it touches the
filesystem outside reading config.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys


def _run(cmd: list[str], timeout: int = 15) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (subprocess.TimeoutExpired, OSError, FileNotFoundError) as e:
        return -1, "", str(e)


def _git_version() -> str | None:
    rc, out, _ = _run(["git", "--version"])
    if rc != 0:
        return None
    # "git version 2.42.0" -> "2.42.0"
    m = re.search(r"\bversion\s+([0-9.]+)", out)
    return m.group(1) if m else out


def _gh_version() -> str | None:
    rc, out, _ = _run(["gh", "--version"])
    if rc != 0:
        return None
    # "gh version 2.40.1 (...)"
    m = re.search(r"\bversion\s+([0-9.]+)", out)
    return m.group(1) if m else out.split("\n")[0]


def _gh_auth_status() -> dict:
    """Return {'authenticated': bool, 'host': ..., 'protocol': ..., 'user': ...}.

    Uses `gh auth status --hostname github.com --json`."""
    info: dict = {"authenticated": False, "host": None, "user": None,
                  "protocol": None, "raw": None}
    rc, out, _ = _run(["gh", "auth", "token"])
    if rc == 0 and out:
        info["authenticated"] = True
    rc2, out2, err2 = _run(["gh", "auth", "status"])
    info["raw"] = out2 or err2
    # Best-effort parse of the human output (gh auth status doesn't have --json)
    if rc2 == 0:
        info["authenticated"] = True
        m_user = re.search(r"Logged in to (\S+) account (\S+)", out2 + err2)
        if m_user:
            info["host"] = m_user.group(1)
            info["user"] = m_user.group(2)
        m_proto = re.search(r"Git operations protocol:\s*(\S+)", out2 + err2)
        if m_proto:
            info["protocol"] = m_proto.group(1).lower()
    return info


def _credential_helper() -> dict:
    """Inspect git's configured credential helper(s)."""
    rc, out, _ = _run(["git", "config", "--get-all", "credential.helper"])
    helpers = [h.strip() for h in out.splitlines() if h.strip()] if rc == 0 else []
    info: dict = {
        "helpers": helpers,
        "uses_os_keychain": False,
        "uses_plaintext_store": False,
        "uses_manager": False,
    }
    for h in helpers:
        low = h.lower()
        if "manager" in low or "wincred" in low:  # GCM / wincred
            info["uses_manager"] = True
            info["uses_os_keychain"] = True
        if "osxkeychain" in low or "libsecret" in low:
            info["uses_os_keychain"] = True
        if low == "store" or low.endswith(" store"):
            info["uses_plaintext_store"] = True
    return info


def _env_pat_signals() -> list[str]:
    """Names of env vars that look like raw GitHub PATs."""
    bad: list[str] = []
    for name, val in os.environ.items():
        if not val:
            continue
        u = name.upper()
        if not any(s in u for s in ("GITHUB", "GH_", "TOKEN", "PAT")):
            continue
        if val.startswith(("ghp_", "github_pat_")):
            bad.append(name)
    return bad


def audit() -> dict:
    """Return a single dict snapshot of the local toolchain state."""
    git_ver = _git_version()
    gh_ver = _gh_version()
    gh_auth = _gh_auth_status() if gh_ver else {"authenticated": False}
    creds = _credential_helper() if git_ver else {"helpers": []}
    env_pats = _env_pat_signals()

    issues: list[str] = []
    if not git_ver:
        issues.append("git is not on PATH")
    if not gh_ver:
        issues.append("gh CLI is not on PATH (install for OAuth + repo mapping)")
    if gh_ver and not gh_auth.get("authenticated"):
        issues.append("gh is installed but not authenticated -- run `gh auth login`")
    if creds.get("helpers") == []:
        issues.append("no git credential helper configured -- pushes will prompt or fail")
    if creds.get("uses_plaintext_store"):
        issues.append("git credential helper is `store` (plaintext on disk) -- "
                      "switch to OS keychain / GCM")
    for name in env_pats:
        issues.append(f"env var {name} contains a raw PAT-shaped value -- "
                      "prefer OS keychain over env vars")
    if gh_auth.get("protocol") == "ssh":
        issues.append("gh is configured to use SSH for git operations -- "
                      "prefer HTTPS so pushes flow through the credential helper")

    return {
        "git": {"installed": git_ver is not None, "version": git_ver,
                "path": shutil.which("git")},
        "gh":  {"installed": gh_ver is not None, "version": gh_ver,
                "path": shutil.which("gh"), **gh_auth},
        "credentials": creds,
        "env_pat_signals": env_pats,
        "issues": issues,
    }


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Audit local toolchain + GitHub auth.")
    ap.add_argument("--summary", action="store_true",
                    help="Print human summary instead of JSON")
    args = ap.parse_args(argv)
    data = audit()
    if args.summary:
        print(f"  git: {'OK' if data['git']['installed'] else 'MISSING'} "
              f"(version {data['git']['version']})", file=sys.stderr)
        print(f"  gh:  {'OK' if data['gh']['installed'] else 'MISSING'} "
              f"(version {data['gh']['version']}, "
              f"auth={'yes' if data['gh'].get('authenticated') else 'no'})",
              file=sys.stderr)
        print(f"  credential helpers: {data['credentials']['helpers'] or '(none)'}",
              file=sys.stderr)
        if data["issues"]:
            print("  issues:", file=sys.stderr)
            for i in data["issues"]:
                print(f"    - {i}", file=sys.stderr)
        return 0
    print(json.dumps(data, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
