#!/usr/bin/env python3
"""Match local code folders to existing GitHub repositories.

Before suggesting `gh repo create`, we should ask: does the user already
own a GitHub repo whose name lines up with this local folder? If yes,
the right move is to add it as `origin` and push -- not to create a
brand-new (and forever empty) duplicate repo.

This module is intentionally thin:

    list_user_repos()       calls `gh repo list` once and returns the
                            user's repos (as a list of dicts).
    find_matches()          pure function: given a local name and a list
                            of remote repos, return matches by name (after
                            a lightweight normalisation).
    annotate()              augment audit entries in place with `gh_match`
                            (and `gh_match_candidates` when ambiguous).

CLI:
    sca audit | sca map [--owner USER]                 -> annotated audit JSON
    sca map --audit audit.json [--owner USER] --out a2.json

Network-only step. If `gh` is missing or not authed, annotate() is a
no-op; the rest of the pipeline still works.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def _run(cmd: list[str], timeout: int = 60) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (subprocess.TimeoutExpired, OSError) as e:
        return -1, "", str(e)


_GH_FIELDS = "name,nameWithOwner,url,sshUrl,visibility,isArchived,isFork"


def list_user_repos(owner: str | None = None,
                    limit: int = 1000) -> list[dict] | None:
    """Return the authenticated user's GitHub repos via `gh`.

    Returns None if `gh` is unavailable / not authenticated. An empty
    list means the call succeeded but the account owns no repos."""
    cmd = ["gh", "repo", "list"]
    if owner:
        cmd.append(owner)
    cmd += ["--limit", str(limit), "--json", _GH_FIELDS]
    rc, out, _err = _run(cmd)
    if rc != 0:
        return None
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, list) else None


def normalize_name(s: str) -> str:
    """Lower-case, collapse separators -- so 'My_Repo' matches 'my-repo'."""
    return (s or "").strip().lower().replace("_", "-").replace(" ", "-")


def find_matches(local_name: str, remote_repos: list[dict]) -> list[dict]:
    """Return remote repos whose normalised name equals the local name.

    Ordering: exact-name matches first (case-sensitive), then
    case-insensitive equality, then normalised equality. Within each
    group, non-archived/non-fork beats archived/fork."""
    if not local_name or not remote_repos:
        return []
    target_norm = normalize_name(local_name)

    def _rank(r: dict) -> tuple[int, int]:
        name = r.get("name") or ""
        if name == local_name:
            tier = 0
        elif name.lower() == local_name.lower():
            tier = 1
        elif normalize_name(name) == target_norm:
            tier = 2
        else:
            tier = 99
        # second axis: penalise archived / fork
        penalty = (1 if r.get("isArchived") else 0) + (1 if r.get("isFork") else 0)
        return (tier, penalty)

    candidates = [r for r in remote_repos if _rank(r)[0] < 99]
    return sorted(candidates, key=_rank)


def annotate(audit_entries: list[dict],
             remote_repos: list[dict] | None) -> list[dict]:
    """Mutate-in-place: attach `gh_match` to entries that look mappable.

    Only annotates entries that don't already have a remote -- those are
    the ones the remediation planner would otherwise feed into
    `gh repo create`."""
    if not remote_repos:
        return audit_entries
    for entry in audit_entries:
        if entry.get("has_remote"):
            continue
        # Skip non-content entries
        if entry.get("type") not in ("repo", "non_repo"):
            continue
        if entry.get("type") == "non_repo" and entry.get("file_count", 0) == 0:
            continue
        name = entry.get("name") or ""
        # `name` can be a relative path; only match on the leaf
        leaf = Path(name).name
        matches = find_matches(leaf, remote_repos)
        if matches:
            entry["gh_match"] = matches[0]
            if len(matches) > 1:
                entry["gh_match_candidates"] = matches
    return audit_entries


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Annotate audit JSON with GitHub repo matches.")
    ap.add_argument("--audit", default="-",
                    help="Path to audit JSON (default: stdin)")
    ap.add_argument("--out", default="-",
                    help="Output path (default: stdout)")
    ap.add_argument("--owner", default=None,
                    help="GitHub user/org to query (default: authenticated user)")
    ap.add_argument("--limit", type=int, default=1000,
                    help="Max repos to fetch (default: 1000)")
    args = ap.parse_args(argv)

    if args.audit == "-":
        data = json.load(sys.stdin)
    else:
        with open(args.audit, encoding="utf-8") as f:
            data = json.load(f)

    repos = list_user_repos(owner=args.owner, limit=args.limit)
    if repos is None:
        print("[map] gh CLI unavailable or not authenticated; passing audit through unchanged",
              file=sys.stderr)
    else:
        annotate(data, repos)
        matched = sum(1 for e in data if e.get("gh_match"))
        print(f"[map] queried {len(repos)} GitHub repo(s); matched {matched} local entry(ies)",
              file=sys.stderr)

    payload = json.dumps(data, indent=2, default=str)
    if args.out == "-":
        sys.stdout.write(payload)
    else:
        Path(args.out).write_text(payload, encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
