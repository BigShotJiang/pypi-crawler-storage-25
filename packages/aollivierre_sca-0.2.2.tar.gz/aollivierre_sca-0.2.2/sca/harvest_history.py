#!/usr/bin/env python3
"""Harvest secret values from a repo's FULL git history (not just the
working tree). Required for thorough history rewrites: a value that
existed in an old commit but has been edited away in HEAD won't appear
in `sca harvest` (which scans the working tree).

Strategy: stream the union of all blobs (every commit, every branch)
through the same regex set as `sca/secrets.py`. Dedupe by value.

Output is a list of unique values to add to a filter-repo replace.txt;
they're also written to `<harvest>/by-category-history/...` for backup.

Usage:
    python -m sca.harvest_history <repo-path> <harvest-out-dir>
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from sca import harvest as _harvest
from sca import secrets as _secrets


def _enumerate_blobs(repo_root: Path) -> set[str]:
    """Return every blob SHA reachable from any ref in the repo."""
    rc = subprocess.run(
        ["git", "-C", str(repo_root), "rev-list", "--objects", "--all"],
        capture_output=True, text=True,
    )
    if rc.returncode != 0:
        return set()
    blobs: set[str] = set()
    # Every line is "<sha> [path]" -- we only want the SHA. cat-file --batch-check
    # to filter to blob type.
    sha_lines = [ln.split()[0] for ln in rc.stdout.splitlines() if ln.strip()]
    if not sha_lines:
        return set()
    chk = subprocess.run(
        ["git", "-C", str(repo_root), "cat-file", "--batch-check"],
        input="\n".join(sha_lines), capture_output=True, text=True,
    )
    for line in chk.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "blob":
            blobs.add(parts[0])
    return blobs


def _read_blob(repo_root: Path, sha: str, max_bytes: int = 2 * 1024 * 1024
               ) -> bytes | None:
    rc = subprocess.run(
        ["git", "-C", str(repo_root), "cat-file", "blob", sha],
        capture_output=True,
    )
    if rc.returncode != 0:
        return None
    if len(rc.stdout) > max_bytes:
        return None
    return rc.stdout


def harvest_history(repo_root: Path,
                    categories: tuple[str, ...] = _harvest.HIGH_CONFIDENCE
                                                     + _harvest.MEDIUM_CONFIDENCE
                    ) -> list[dict]:
    """Walk every blob in the repo's history; return raw findings using
    the same `sca.harvest.harvest_text` rules. Path is the blob SHA;
    line is offset within the blob."""
    repo_root = repo_root.resolve()
    out: list[dict] = []
    blobs = _enumerate_blobs(repo_root)
    print(f"[history] {len(blobs)} blob(s) in repo history",
          file=sys.stderr)
    seen_values: set[str] = set()
    for sha in sorted(blobs):
        data = _read_blob(repo_root, sha)
        if data is None:
            continue
        try:
            text = data.decode("utf-8", errors="ignore")
        except (UnicodeDecodeError, ValueError):
            continue
        # Path is unknown for orphan blobs -- pass blob sha as a fake path.
        # harvest_text requires a path string for some category gates
        # (real_looking_guid uses the suffix). For history scan we use
        # a sentinel; this means GUID category wouldn't fire. That's OK:
        # the values we MISS in working-tree harvest are usually `Obfuscated*`
        # or live tokens, both of which don't depend on path suffix.
        for f in _harvest.harvest_text(text, "<history-blob>", categories):
            v = f["value"]
            if v in seen_values:
                continue
            seen_values.add(v)
            f["repo"] = repo_root.name
            f["path"] = sha
            f["line"] = 0
            out.append(f)
        # XOR obfuscation discovery: same pattern as harvest.harvest_repo
        # but per-blob and assuming a decoder exists somewhere in history.
        if "xor_obfuscation" in categories:
            for m in _secrets.OBFUSCATED_FIELD_PATTERN.finditer(text):
                line_text = _harvest._line_at(text, m.start())
                value = _harvest._extract_xor_value(line_text)
                if not value:
                    continue
                if _harvest._is_template_xor_value(value):
                    continue
                if value in seen_values:
                    continue
                seen_values.add(value)
                out.append({
                    "category": "xor_obfuscation",
                    "severity": "critical",
                    "value": value,
                    "field_name": line_text.strip()[:120],
                    "line": 0,
                    "context": line_text[:200],
                    "repo": repo_root.name,
                    "path": sha,
                })
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("repo", help="Path to git repo")
    ap.add_argument("harvest", help="Existing harvest output dir to extend")
    args = ap.parse_args(argv)

    repo = Path(args.repo).resolve()
    harvest_root = Path(args.harvest).resolve()

    findings = harvest_history(repo)
    print(f"[history] found {len(findings)} extra unique values "
          f"({sum(1 for f in findings if f['category'] == 'xor_obfuscation')} xor)",
          file=sys.stderr)

    # Append to the existing on-disk inventory by writing per-id files.
    if findings:
        cat_dir = harvest_root / "by-category"
        cat_dir.mkdir(parents=True, exist_ok=True)
        import hashlib
        import json as _json
        for f in findings:
            cat_path = cat_dir / f["category"]
            cat_path.mkdir(exist_ok=True)
            fid = hashlib.sha256(f["value"].encode("utf-8")).hexdigest()[:16]
            entry = {
                "id": fid, "category": f["category"], "severity": f["severity"],
                "value": f["value"], "context": f.get("context", ""),
                "occurrences": [{"repo": f["repo"], "path": f["path"],
                                  "line": f["line"]}],
            }
            if "field_name" in f:
                entry["field_name"] = f["field_name"]
            (cat_path / f"{fid}.json").write_text(
                _json.dumps(entry, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
    return 0


if __name__ == "__main__":
    sys.exit(main())
