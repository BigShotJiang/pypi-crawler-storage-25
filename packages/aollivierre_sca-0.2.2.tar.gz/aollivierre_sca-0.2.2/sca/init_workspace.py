#!/usr/bin/env python3
"""End-to-end workspace audit pipeline.

READ-ONLY by default. The pipeline only WRITES to its own output
directory and OPENS the HTML report -- it never touches your repos.
After the report opens, if stdin is interactive, you'll get a y/N
prompt to apply the remediation plan. Type 'n' / Enter to skip.

Stages (all read-only):
    <out>/audit.json              full repo + non-repo classification
    <out>/classified.json         audit + state/strategy fields
    <out>/branches.json           per-repo branch state
    <out>/secrets/<repo>.json     per-repo secret-scan results (excerpts MASKED)
    <out>/remediation-plan.json   what would-need-fixing per repo
    <out>/report.html             single-file HTML report (opens automatically)
    <out>/summary.txt             human-readable one-pager

Usage:
    sca init-workspace --root ~/code --out ~/audit-runs/2026-05-01
    sca init-workspace --root ~/code           # defaults to ./sca-run-<timestamp>
    sca init-workspace --no-open               # skip auto-open of HTML
    sca init-workspace --no-prompt             # skip the y/N remediate prompt
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import platform
import subprocess
import sys
from collections import Counter
from pathlib import Path

from sca import audit as _audit
from sca import branches as _branches
from sca import ci as _ci
from sca import classify as _classify
from sca import gitea as _gitea
from sca import mapping as _mapping
from sca import remediate as _remediate
from sca import render as _render
from sca import secrets as _secrets
from sca import toolchain as _toolchain
from sca import unicode_audit as _unicode_audit


def _looks_like_code_root(root: Path) -> tuple[bool, str]:
    """Heuristic check: does `root` look like a directory full of repos?

    Returns (is_likely, reason). Used to warn before audit runs on a
    plainly-wrong directory like ~/Documents."""
    if not root.is_dir():
        return False, f"{root} is not a directory"
    try:
        entries = list(root.iterdir())
    except OSError as e:
        return False, f"cannot read {root}: {e}"
    git_dirs = sum(1 for e in entries if e.is_dir() and (e / ".git").is_dir())
    if git_dirs >= 1:
        return True, f"found {git_dirs} git repo(s) at depth 1"
    # Maybe the directory itself is a single repo
    if (root / ".git").is_dir():
        return True, "directory itself is a git repo"
    return False, "no .git directories found at depth 1"


def _open_in_browser(html_path: Path) -> bool:
    """Open `html_path` in the default browser. Returns True if launched.

    On Windows, uses `explorer.exe <path>`. explorer.exe always runs in the
    interactive user's session -- so even when sca is launched from an
    elevated PowerShell, the browser opens in the regular user context with
    its profile, extensions, etc. (rather than under SYSTEM/admin).

    On macOS uses `open`; on Linux uses `xdg-open`."""
    p = str(html_path)
    try:
        system = platform.system()
        if system == "Windows":
            # Don't use webbrowser.open / cmd start -- those inherit the
            # current process's elevation. explorer.exe is always user-session.
            subprocess.Popen(["explorer.exe", p],
                             creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
        elif system == "Darwin":
            subprocess.Popen(["open", p])
        else:  # Linux + others
            subprocess.Popen(["xdg-open", p],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        return True
    except (OSError, FileNotFoundError):
        return False


def _safe_filename(s: str) -> str:
    """Make a string safe to use as a filename."""
    return s.replace("/", "__").replace("\\", "__").replace(":", "_")


def run_pipeline(root: Path, out_dir: Path) -> tuple[dict, list]:
    """Execute the full pipeline. Returns (summary, plans) where plans
    is the list of RepoPlan objects so callers can optionally execute them."""
    out_dir.mkdir(parents=True, exist_ok=True)
    secrets_dir = out_dir / "secrets"
    secrets_dir.mkdir(exist_ok=True)

    summary: dict = {
        "root": str(root),
        "out_dir": str(out_dir),
        "started_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "stages": {},
    }

    # ---- 1. audit ----
    print(f"[1/6] auditing {root} ...", file=sys.stderr)
    _audit.ROOT = root.resolve()
    # _audit.main() prints to stdout -- capture it.
    import io
    from contextlib import redirect_stderr, redirect_stdout
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(io.StringIO()):
        _audit.main()
    audit_data = json.loads(buf.getvalue())

    # ---- 1b. GitHub repo mapping (best-effort; no-op if gh unavailable) ----
    try:
        gh_repos = _mapping.list_user_repos()
    except Exception as exc:
        gh_repos = None
        print(f"  (mapping skipped: {exc})", file=sys.stderr)
    if gh_repos is not None:
        _mapping.annotate(audit_data, gh_repos)
        n_mapped = sum(1 for e in audit_data if e.get("gh_match"))
        summary["stages"]["mapping"] = {
            "gh_repos_seen": len(gh_repos),
            "local_matches": n_mapped,
        }
        print(f"      mapped {n_mapped} local entry(ies) to existing GitHub repos",
              file=sys.stderr)
    else:
        summary["stages"]["mapping"] = {"skipped": "gh CLI unavailable or not authenticated"}

    # ---- 1c. Gitea mapping (opt-in; no-op unless GITEA_HOST + GITEA_TOKEN set) ----
    try:
        gitea_repos = _gitea.list_user_repos()
    except Exception as exc:
        gitea_repos = None
        print(f"  (gitea skipped: {exc})", file=sys.stderr)
    if gitea_repos is not None:
        _gitea.annotate(audit_data, gitea_repos)
        n_g = sum(1 for e in audit_data if e.get("gitea_match"))
        n_mirrored = sum(1 for e in audit_data if e.get("gitea_mirrored"))
        summary["stages"]["gitea"] = {
            "repos_seen": len(gitea_repos),
            "matches": n_g,
            "already_mirrored": n_mirrored,
        }
        print(f"      Gitea: {n_g} match(es), {n_mirrored} already mirrored",
              file=sys.stderr)
    else:
        summary["stages"]["gitea"] = {"skipped": "GITEA_HOST/GITEA_TOKEN not set"}

    # ---- 1d. CI workflow audit (per-repo) ----
    print("[1d] auditing CI workflows ...", file=sys.stderr)
    ci_data: list[dict] = []
    for entry in audit_data:
        if entry.get("type") != "repo":
            continue
        wf = _ci.audit_repo(Path(entry["path"]))
        ci_data.append(wf.asdict())
        entry["present_workflows"] = wf.present_workflows
        entry["missing_workflows"] = wf.missing_workflows
    (out_dir / "ci.json").write_text(json.dumps(ci_data, indent=2),
                                     encoding="utf-8")
    summary["stages"]["ci"] = {
        "repos_audited": len(ci_data),
        "missing_unicode_check": sum(
            1 for r in ci_data if "unicode-check" in r["missing_workflows"]
        ),
    }

    # ---- 1e. Unicode audit (per-repo) ----
    print("[1e] auditing non-ASCII source ...", file=sys.stderr)
    unicode_data: list[dict] = []
    for entry in audit_data:
        if entry.get("type") != "repo":
            continue
        rf = _unicode_audit.scan_repo(Path(entry["path"]))
        unicode_data.append(rf.asdict())
        entry["unicode_chars"] = rf.total_chars
        entry["unicode_files"] = rf.total_files
    (out_dir / "unicode.json").write_text(json.dumps(unicode_data, indent=2),
                                          encoding="utf-8")
    summary["stages"]["unicode"] = {
        "repos_with_non_ascii": sum(1 for r in unicode_data if r["total_chars"] > 0),
        "total_chars": sum(r["total_chars"] for r in unicode_data),
    }

    # ---- 1f. Toolchain audit (single shot, host-level not per-repo) ----
    print("[1f] auditing toolchain ...", file=sys.stderr)
    tc = _toolchain.audit()
    (out_dir / "toolchain.json").write_text(json.dumps(tc, indent=2),
                                            encoding="utf-8")
    summary["stages"]["toolchain"] = {
        "git": tc["git"]["version"],
        "gh":  tc["gh"]["version"],
        "gh_authenticated": bool(tc["gh"].get("authenticated")),
        "issues": tc["issues"],
    }

    (out_dir / "audit.json").write_text(json.dumps(audit_data, indent=2),
                                        encoding="utf-8")
    summary["stages"]["audit"] = {"entries": len(audit_data)}

    # ---- 2. classify ----
    print(f"[2/6] classifying {len(audit_data)} entries ...", file=sys.stderr)
    classified = _classify.classify_all(audit_data)
    (out_dir / "classified.json").write_text(json.dumps(classified, indent=2),
                                             encoding="utf-8")
    # Fold classification back into audit_data so render() can show the state.
    # `classify_all` returns a NEW list; here we copy the classification field
    # onto the original entries, indexed by path (audit_data and classified
    # are produced from the same input, in the same order, but paths are the
    # safer key).
    by_path = {c.get("path"): c.get("classification") for c in classified}
    for entry in audit_data:
        cls = by_path.get(entry.get("path"))
        if cls is not None:
            entry["classification"] = cls
    states = Counter(c["classification"]["state"] for c in classified)
    summary["stages"]["classify"] = dict(states)

    # ---- 3. branches ----
    print("[3/6] auditing branches ...", file=sys.stderr)
    _branches.ROOT = root.resolve()
    buf = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(io.StringIO()):
        _branches.main()
    branch_data = json.loads(buf.getvalue())
    (out_dir / "branches.json").write_text(json.dumps(branch_data, indent=2),
                                           encoding="utf-8")
    summary["stages"]["branches"] = {"repos": len(branch_data)}

    # ---- 4. per-repo secret scan ----
    repos = [e for e in audit_data if e.get("type") == "repo"]
    print(f"[4/6] secret-scanning {len(repos)} repo(s) ...", file=sys.stderr)
    # By default skip directories where intentionally PAT-shaped strings
    # show up as test fixtures (this scanner's own tests, for instance).
    # Users can rerun a single repo with `sca scan <repo>` (no excludes)
    # if they want the full picture.
    # Aligned with sca/harvest.py:DEFAULT_EXCLUDES so the audit pass
    # matches the harvest pass. Without `.archive` and `backups`, audits
    # of repos that quarantine old config under those paths trip on
    # archived/transcripted secret-shaped strings (e.g. Claude's session
    # transcripts under `backups/` would each register as critical).
    # See v3/HANDOFF.md item #1 (skip-rules SSOT) for the larger fix.
    default_excludes = ["tests", "__tests__", "spec", "test_data",
                        "test-data", "fixtures", ".archive", "backups"]
    secret_summary: dict = {
        "clean": 0, "high_only": 0, "critical": 0,
        "by_repo": {},
    }
    findings_per_repo: dict[str, list[dict]] = {}
    for entry in repos:
        repo_path = Path(entry["path"])
        try:
            findings = _secrets.scan_repo(repo_path, exclude=default_excludes)
        except Exception as exc:
            findings = []
            secret_summary["by_repo"][entry["name"]] = {"error": str(exc)}
            continue
        crit = sum(1 for f in findings if f.severity == "critical")
        high = sum(1 for f in findings if f.severity == "high")
        per_repo = {
            "critical": crit, "high": high, "total": len(findings),
            "findings": [f.asdict() for f in findings],
        }
        fname = _safe_filename(entry["name"]) + ".json"
        (secrets_dir / fname).write_text(json.dumps(per_repo, indent=2),
                                         encoding="utf-8")
        secret_summary["by_repo"][entry["name"]] = {
            "critical": crit, "high": high, "total": len(findings),
        }
        # Annotate the audit entry so the planner + UI can use these:
        #   critical_secret_count: drives REDACT_SECRETS action and the
        #     critical risk tier. Excludes xor_obfuscation per spec (low-risk).
        #   total_findings: ALL findings of any severity. Drives the
        #     "has secrets" filter in the report.
        crit_redactable = sum(1 for f in findings
                              if f.severity == "critical"
                              and f.category != "xor_obfuscation")
        entry["critical_secret_count"] = crit_redactable
        entry["total_findings"] = len(findings)
        entry["high_findings"] = high
        # Collect findings (already-masked) for the HTML report
        findings_per_repo[entry["name"]] = [f.asdict() for f in findings]
        if crit:
            secret_summary["critical"] += 1
        elif high:
            secret_summary["high_only"] += 1
        else:
            secret_summary["clean"] += 1
    summary["stages"]["secrets"] = secret_summary
    summary["_findings_per_repo"] = findings_per_repo  # consumed by render below

    # ---- 5. remediation plan ----
    print("[5/6] generating remediation plan ...", file=sys.stderr)
    plans = _remediate.plan_remediation(audit_data)
    (out_dir / "remediation-plan.json").write_text(
        json.dumps([p.asdict() for p in plans], indent=2),
        encoding="utf-8",
    )
    summary["stages"]["remediation"] = {
        "repos_needing_action": len(plans),
        "by_state": dict(Counter(p.state for p in plans)),
    }

    # ---- 6. render HTML ----
    print("[6/6] rendering HTML report ...", file=sys.stderr)
    title = f"Workspace audit -- {root.name} -- {summary['started_at'][:10]}"
    branches_per_repo = {b.get("name"): b for b in branch_data if b.get("name")}
    html_body = _render.render(audit_data, title=title,
                               secrets_per_repo=findings_per_repo,
                               branches_per_repo=branches_per_repo,
                               toolchain=tc,
                               plan=[p.asdict() for p in plans])
    (out_dir / "report.html").write_text(html_body, encoding="utf-8")
    summary["stages"]["render"] = {"html_bytes": len(html_body)}
    # strip the bulky finding lists from the summary that's written to disk
    summary.pop("_findings_per_repo", None)

    # ---- summary.txt ----
    summary["finished_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    (out_dir / "summary.txt").write_text(_format_summary(summary),
                                         encoding="utf-8")
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2),
                                          encoding="utf-8")
    # ---- manifest.json (data-layer index for downstream tools) ----
    manifest = {
        "schema_version": 1,
        "generator": "sca init-workspace",
        "started_at": summary["started_at"],
        "finished_at": summary["finished_at"],
        "files": {
            "audit":          "audit.json",
            "classified":     "classified.json",
            "branches":       "branches.json",
            "ci":             "ci.json",
            "unicode":        "unicode.json",
            "toolchain":      "toolchain.json",
            "secrets_dir":    "secrets/",
            "remediation":    "remediation-plan.json",
            "report_html":    "report.html",
            "summary_json":   "summary.json",
            "summary_txt":    "summary.txt",
        },
        "schema_doc": "../DATA_LAYER.md",
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2),
                                           encoding="utf-8")
    return summary, plans


def _format_summary(summary: dict) -> str:
    lines = [
        f"sca init-workspace -- {summary['started_at']}",
        f"  root:    {summary['root']}",
        f"  out:     {summary['out_dir']}",
        "",
        f"  audit:   {summary['stages']['audit']['entries']} entries",
    ]
    lines.append("  state breakdown:")
    for state, n in sorted(summary["stages"]["classify"].items(),
                           key=lambda kv: -kv[1]):
        lines.append(f"    {state:30s} {n}")
    sec = summary["stages"]["secrets"]
    lines.append("")
    lines.append(f"  secrets: {sec['critical']} repo(s) critical, "
                 f"{sec['high_only']} high-only, {sec['clean']} clean")
    if sec["critical"]:
        lines.append("    repos with CRITICAL findings:")
        for name, r in sec["by_repo"].items():
            if isinstance(r, dict) and r.get("critical", 0) > 0:
                lines.append(f"      {name:40s} crit={r['critical']} high={r['high']}")
    rem = summary["stages"]["remediation"]
    lines.append("")
    lines.append(f"  remediation: {rem['repos_needing_action']} repos need action")
    for state, n in rem["by_state"].items():
        lines.append(f"    {state:30s} {n}")
    lines.append("")
    lines.append(f"  artifacts: {summary['out_dir']}/")
    lines.append("    audit.json classified.json branches.json")
    lines.append("    secrets/<repo>.json")
    lines.append("    remediation-plan.json report.html summary.json")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Run the full sca pipeline.")
    ap.add_argument("--root",
                    default=os.environ.get("CODE_ROOT", os.getcwd()),
                    help="Code root to audit (default: $CODE_ROOT or cwd)")
    ap.add_argument("--out", default=None,
                    help="Output directory (default: ./sca-run-<timestamp>)")
    ap.add_argument("--no-open", action="store_true",
                    help="Don't auto-open report.html in a browser")
    ap.add_argument("--no-warn", action="store_true",
                    help="Skip the 'does this look like a code root?' check")
    ap.add_argument("--no-prompt", action="store_true",
                    help="Don't prompt y/N for remediation after the report opens")
    ap.add_argument("--offline", action="store_true",
                    help="If you confirm the remediation prompt, run with the offline visibility gate")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    if not root.is_dir():
        print(f"error: --root {root} is not a directory", file=sys.stderr)
        return 2

    # Heuristic: warn (but don't block) if cwd doesn't look like a code root.
    if not args.no_warn:
        ok, reason = _looks_like_code_root(root)
        if not ok:
            print(f"\n[WARN] {root}", file=sys.stderr)
            print(f"       doesn't look like a code root ({reason}).", file=sys.stderr)
            print( "       Did you mean to cd to your code dir first, "
                   "or pass --root <path>?", file=sys.stderr)
            print( "       Pass --no-warn to skip this check.\n", file=sys.stderr)
            # still proceed -- produces a 0-repo report rather than failing

    if args.out:
        out_dir = Path(args.out).resolve()
    else:
        ts = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
        out_dir = Path.cwd() / f"sca-run-{ts}"

    summary, plans = run_pipeline(root, out_dir)
    print(_format_summary(summary), file=sys.stderr)

    report = out_dir / "report.html"
    # Always print the path prominently so it's findable when running
    # from an elevated shell (auto-open might bounce to a different
    # session and you wouldn't see the window).
    print("\n" + "=" * 70, file=sys.stderr)
    print(f"  HTML report:  {report}", file=sys.stderr)
    print("=" * 70, file=sys.stderr)

    if not args.no_open:
        if _open_in_browser(report):
            print("  (opened in browser)", file=sys.stderr)
        else:
            print("  (auto-open failed; open the path above manually)",
                  file=sys.stderr)

    print(str(report))  # stdout: just the report path (machine-readable)

    # ---- y/N remediation prompt (interactive sessions only) ----
    plan_path = out_dir / "remediation-plan.json"
    plan_data = json.loads(plan_path.read_text(encoding="utf-8")) if plan_path.exists() else []
    n_actionable = sum(1 for p in plan_data
                       if any(a.get("destructive") for a in p.get("actions", [])))

    if (not args.no_prompt and n_actionable > 0
            and sys.stdin is not None and sys.stdin.isatty()):
        print("", file=sys.stderr)
        print(f"  Remediation plan has {n_actionable} repo(s) with destructive "
              f"actions queued.", file=sys.stderr)
        print( "  Review the report + remediation-plan.json before proceeding.",
              file=sys.stderr)
        try:
            answer = input("  Run remediation now? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = ""
        if answer in ("y", "yes"):
            print("\n  applying remediation plan ...", file=sys.stderr)
            results = _remediate.execute_plan(plans, apply=True,
                                              offline=args.offline)
            (out_dir / "remediation-results.json").write_text(
                json.dumps(results, indent=2, default=str),
                encoding="utf-8",
            )
            failures = sum(
                1 for r in results
                for ar in r["results"]
                if not ar["ok"] and not ar.get("skipped")
            )
            print(f"  remediation complete; {failures} action(s) failed; "
                  f"see {out_dir}/remediation-results.json", file=sys.stderr)
            return 0 if failures == 0 else 1
        else:
            print("  skipped. To run later: "
                  "sca audit | sca remediate --apply",
                  file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
