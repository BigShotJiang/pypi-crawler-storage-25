#!/usr/bin/env python3
"""Pick a `.gitignore` template based on what's in a directory.

The template files live alongside this module at `sca/templates/gitignore/`.
Each is a partial gitignore for one stack (python, node, dotnet, powershell).
`common.gitignore` holds OS / editor / secrets-hygiene patterns that everyone
wants. Storing them inside the package lets `pip install` ship them too.

Public surface:
    detect(path) -> list[str]                 stack names ordered by signal strength
    render(stacks, include_common=True) -> str a combined gitignore body
    write(path, *, overwrite=False) -> Path    write/merge into <path>/.gitignore
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

_THIS = Path(__file__).resolve()
_TEMPLATES_DIR = _THIS.parent / "templates" / "gitignore"


# Markers to identify a stack. The first match wins for ordering, but multiple
# stacks can apply (e.g. a Python project with a bundled npm front-end).
STACK_MARKERS: dict[str, tuple[str, ...]] = {
    "python":     ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", "Pipfile"),
    "node":       ("package.json", "yarn.lock", "pnpm-lock.yaml"),
    "dotnet":     (".sln", ".csproj", ".fsproj", ".vbproj"),
    "powershell": (".psd1", ".psm1", ".ps1"),
}


def detect(path: Path) -> list[str]:
    """Return stack names with marker hits, ordered by hit count desc."""
    if not path.exists() or not path.is_dir():
        return []

    counts: dict[str, int] = {}
    # walk only the top-level + one level deep to keep this cheap
    for stack, markers in STACK_MARKERS.items():
        n = 0
        for child in path.rglob("*"):
            if not child.is_file():
                continue
            try:
                rel = child.relative_to(path)
            except ValueError:
                continue
            if len(rel.parts) > 3:
                continue  # don't dive too deep
            name = child.name
            ext = child.suffix
            for m in markers:
                if m.startswith("."):
                    if ext == m:
                        n += 1
                        break
                elif name == m:
                    n += 1
                    break
        if n:
            counts[stack] = n

    return [k for k, _ in sorted(counts.items(), key=lambda kv: -kv[1])]


def _read_template(name: str) -> str:
    p = _TEMPLATES_DIR / f"{name}.gitignore"
    if not p.exists():
        raise FileNotFoundError(f"no such template: {name} (looked at {p})")
    return p.read_text(encoding="utf-8")


def render(stacks: list[str], include_common: bool = True) -> str:
    """Combine template bodies into a single gitignore string."""
    parts: list[str] = []
    if include_common:
        parts.append("# --- common (OS / editor / secrets) ---")
        parts.append(_read_template("common").strip())
    for stack in stacks:
        parts.append(f"\n# --- {stack} ---")
        parts.append(_read_template(stack).strip())
    return "\n".join(parts) + "\n"


def write(path: Path, *, overwrite: bool = False) -> Path:
    """Auto-detect stacks for `path` and write `path/.gitignore`. If a
    .gitignore already exists, refuse unless overwrite=True."""
    target = path / ".gitignore"
    if target.exists() and not overwrite:
        raise FileExistsError(f"{target} already exists (pass overwrite=True)")
    stacks = detect(path)
    body = render(stacks, include_common=True)
    target.write_text(body, encoding="utf-8")
    return target


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Detect a directory's stack and emit/write a gitignore."
    )
    ap.add_argument("path", nargs="?", default=".",
                    help="Directory to inspect (default: cwd)")
    ap.add_argument("--write", action="store_true",
                    help="Write the result to <path>/.gitignore")
    ap.add_argument("--overwrite", action="store_true",
                    help="With --write: overwrite an existing .gitignore")
    ap.add_argument("--no-common", action="store_true",
                    help="Skip the common (OS/editor/secrets) section")
    args = ap.parse_args(argv)

    path = Path(args.path).resolve()
    stacks = detect(path)
    if not stacks:
        print(f"# no stack markers detected under {path}", file=sys.stderr)

    if args.write:
        try:
            target = write(path, overwrite=args.overwrite)
            print(f"wrote {target}", file=sys.stderr)
            print(f"detected stacks: {', '.join(stacks) or '(none)'}", file=sys.stderr)
            return 0
        except FileExistsError as e:
            print(f"refused: {e}", file=sys.stderr)
            return 2
    else:
        body = render(stacks, include_common=not args.no_common)
        sys.stdout.write(body)
        return 0


if __name__ == "__main__":
    sys.exit(main())
