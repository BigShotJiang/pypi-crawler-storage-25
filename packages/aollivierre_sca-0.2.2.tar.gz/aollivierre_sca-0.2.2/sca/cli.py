#!/usr/bin/env python3
"""sca -- source-control-automation v3 CLI.

[LOCKED] SAFE TO RUN -- read-only by default.
   None of these subcommands modify your repos unless you explicitly
   pass --apply (or one of the gated repair flags). Bare `sca` runs
   the audit pipeline + opens an HTML report + asks you y/N before
   doing anything destructive.

  sca                                         No subcommand: runs init-workspace
                                              in the current directory.

Subcommands:
  sca audit      [--root PATH]                Walk a code root, classify every dir, emit JSON.
  sca branches   [--root PATH]                Per-repo branch state (unpushed, main-behind, diverged).
  sca scan       [REPO]                       Pattern-scan a single repo for committed secrets.
  sca classify   [--audit JSON] [--summary]   Add state + strategy classifications to audit JSON.
  sca extract    [--root PATH] [--json]       Detect wrapper-repo (parent .git wraps nested .git) cases.
  sca gitignore  [PATH] [--write]             Detect stack(s) and emit/write a .gitignore.
  sca remediate  [--audit JSON] [--plan|--apply]  Plan or execute per-state remediations.
  sca render     [--audit JSON] [--out F]     Render an audit JSON to single-file HTML.
  sca init-workspace [--root PATH] [--out D]  Run the full pipeline; one output dir + auto-open HTML.
  sca push-branches  [--root PATH] [--apply]  Push every unpushed/ahead branch across all repos.

Pipelines:
  sca audit | sca classify --summary           # quick state breakdown
  sca audit > a.json && sca classify --audit a.json | sca render --audit -

All --root args respect the CODE_ROOT env var as default.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


def _add_root(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--root",
        default=os.environ.get("CODE_ROOT", os.getcwd()),
        help="Code root to walk (default: $CODE_ROOT or cwd)",
    )


def _cmd_audit(args: argparse.Namespace) -> int:
    from sca import audit
    audit.ROOT = Path(args.root).resolve()
    audit.main()
    return 0


def _cmd_branches(args: argparse.Namespace) -> int:
    from sca import branches
    branches.ROOT = Path(args.root).resolve()
    branches.main()
    return 0


def _cmd_scan(args: argparse.Namespace) -> int:
    from sca import secrets
    argv = [args.repo]
    if args.json:
        argv.append("--json")
    for ex in args.exclude or []:
        argv += ["--exclude", ex]
    return secrets.main(argv)


def _cmd_classify(args: argparse.Namespace) -> int:
    from sca import classify
    argv = []
    if args.audit:
        argv += ["--audit", args.audit]
    if args.summary:
        argv += ["--summary"]
    return classify.main(argv)


def _cmd_map(args: argparse.Namespace) -> int:
    from sca import mapping
    argv = ["--audit", args.audit, "--out", args.out, "--limit", str(args.limit)]
    if args.owner:
        argv += ["--owner", args.owner]
    return mapping.main(argv)


def _cmd_unicode(args: argparse.Namespace) -> int:
    from sca import unicode_audit
    argv = ["--root", args.root]
    if args.summary:
        argv.append("--summary")
    return unicode_audit.main(argv)


def _cmd_ci(args: argparse.Namespace) -> int:
    from sca import ci as _ci
    argv = ["--root", args.root]
    if args.summary:
        argv.append("--summary")
    return _ci.main(argv)


def _cmd_toolchain(args: argparse.Namespace) -> int:
    from sca import toolchain
    return toolchain.main(["--summary"] if args.summary else [])


def _cmd_redact(args: argparse.Namespace) -> int:
    from sca import redact
    argv = [args.repo]
    if args.apply:
        argv.append("--apply")
    for ex in args.exclude or []:
        argv += ["--exclude", ex]
    if args.from_harvest:
        argv += ["--from-harvest", args.from_harvest]
    return redact.main(argv)


def _cmd_harvest(args: argparse.Namespace) -> int:
    from sca import harvest
    argv = ["--root", args.root, "--out", args.out, "--categories", args.categories]
    if args.include_tests:
        argv.append("--include-tests")
    for ex in args.exclude or []:
        argv += ["--exclude", ex]
    return harvest.main(argv)


def _cmd_gitea(args: argparse.Namespace) -> int:
    from sca import gitea
    argv = ["--audit", args.audit, "--out", args.out]
    if args.host:
        argv += ["--host", args.host]
    if args.token:
        argv += ["--token", args.token]
    if args.user:
        argv += ["--user", args.user]
    return gitea.main(argv)


def _cmd_extract(args: argparse.Namespace) -> int:
    from sca import extract
    argv = ["--root", args.root]
    if args.json:
        argv += ["--json"]
    if args.archive_and_delete:
        argv += ["--archive-and-delete", args.archive_and_delete]
    if args.mirror_to:
        argv += ["--mirror-to", args.mirror_to]
    return extract.main(argv)


def _cmd_gitignore(args: argparse.Namespace) -> int:
    from sca import templates
    argv = [args.path]
    if args.write:
        argv.append("--write")
    if args.overwrite:
        argv.append("--overwrite")
    if args.no_common:
        argv.append("--no-common")
    return templates.main(argv)


def _cmd_remediate(args: argparse.Namespace) -> int:
    from sca import remediate
    argv = ["--audit", args.audit]
    if args.plan:
        argv.append("--plan")
    if args.apply:
        argv.append("--apply")
    if args.offline:
        argv.append("--offline")
    return remediate.main(argv)


def _cmd_render(args: argparse.Namespace) -> int:
    from sca import render
    argv = ["--audit", args.audit, "--out", args.out]
    if args.title:
        argv += ["--title", args.title]
    return render.main(argv)


def _cmd_init_workspace(args: argparse.Namespace) -> int:
    from sca import init_workspace
    argv = ["--root", args.root]
    if args.out:
        argv += ["--out", args.out]
    if args.no_open:
        argv.append("--no-open")
    if args.no_warn:
        argv.append("--no-warn")
    if args.no_prompt:
        argv.append("--no-prompt")
    if args.offline:
        argv.append("--offline")
    return init_workspace.main(argv)


def _cmd_push_branches(args: argparse.Namespace) -> int:
    from sca import push_branches
    argv = ["--root", args.root]
    if args.apply:
        argv.append("--apply")
    if args.offline:
        argv.append("--offline")
    if args.json:
        argv.append("--json")
    return push_branches.main(argv)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sca", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=False)

    p_audit = sub.add_parser("audit", help="Walk a code root, classify dirs, emit JSON")
    _add_root(p_audit)
    p_audit.set_defaults(fn=_cmd_audit)

    p_branches = sub.add_parser("branches", help="Per-repo branch state report")
    _add_root(p_branches)
    p_branches.set_defaults(fn=_cmd_branches)

    p_scan = sub.add_parser("scan", help="Scan one repo for committed secrets")
    p_scan.add_argument("repo", nargs="?", default=os.getcwd(),
                        help="Path to git repo (default: cwd)")
    p_scan.add_argument("--json", action="store_true")
    p_scan.add_argument("--exclude", action="append", default=[], metavar="PATTERN",
                        help="Skip paths matching PATTERN (repeatable)")
    p_scan.set_defaults(fn=_cmd_scan)

    p_classify = sub.add_parser("classify", help="Classify audit entries by state + strategy")
    p_classify.add_argument("--audit", default="-",
                            help="Path to audit JSON (default: stdin)")
    p_classify.add_argument("--summary", action="store_true",
                            help="Print per-state counts to stderr instead of full JSON")
    p_classify.set_defaults(fn=_cmd_classify)

    p_map = sub.add_parser("map",
                           help="Annotate audit JSON with matching GitHub repos (gh CLI)")
    p_map.add_argument("--audit", default="-",
                       help="Path to audit JSON (default: stdin)")
    p_map.add_argument("--out", default="-",
                      help="Output path (default: stdout)")
    p_map.add_argument("--owner", default=None,
                       help="GitHub user/org (default: authenticated user)")
    p_map.add_argument("--limit", type=int, default=1000,
                       help="Max repos to fetch (default: 1000)")
    p_map.set_defaults(fn=_cmd_map)

    p_uni = sub.add_parser("unicode",
                           help="Audit non-ASCII characters in source files")
    _add_root(p_uni)
    p_uni.add_argument("--summary", action="store_true")
    p_uni.set_defaults(fn=_cmd_unicode)

    p_ci = sub.add_parser("ci",
                          help="Audit GitHub Actions workflow presence per repo")
    _add_root(p_ci)
    p_ci.add_argument("--summary", action="store_true")
    p_ci.set_defaults(fn=_cmd_ci)

    p_tc = sub.add_parser("toolchain",
                          help="Audit local git/gh versions + auth + credential helper")
    p_tc.add_argument("--summary", action="store_true")
    p_tc.set_defaults(fn=_cmd_toolchain)

    p_redact = sub.add_parser("redact",
                              help="Force-redact committed secrets in working tree")
    p_redact.add_argument("repo", nargs="?", default=os.getcwd())
    p_redact.add_argument("--apply", action="store_true",
                          help="Actually rewrite files (default: dry-run)")
    p_redact.add_argument("--exclude", action="append", default=[], metavar="PATTERN")
    p_redact.add_argument("--from-harvest", default=None, metavar="DIR",
                          help="Use harvest output (sca harvest output dir) as "
                               "precise redaction list -- no regex FPs")
    p_redact.set_defaults(fn=_cmd_redact)

    p_harvest = sub.add_parser("harvest",
                               help="Extract unique secret values to a backup directory "
                                    "(read-only; intended to run BEFORE redaction)")
    _add_root(p_harvest)
    p_harvest.add_argument("--out", default=str(
        (Path(os.environ.get("CODE_ROOT", "C:/code")) / "secrets").as_posix()),
        help="Backup directory (default: $CODE_ROOT/secrets)")
    p_harvest.add_argument("--categories", default="high+medium",
                           choices=("high", "high+medium", "all"),
                           help="Confidence tiers to harvest")
    p_harvest.add_argument("--exclude", action="append", default=None, metavar="PATTERN",
                           help="Path pattern to skip (repeatable)")
    p_harvest.add_argument("--include-tests", action="store_true",
                           help="Don't skip test/fixtures dirs (surfaces synthetic PATs)")
    p_harvest.set_defaults(fn=_cmd_harvest)

    p_gitea = sub.add_parser("gitea",
                             help="Annotate audit JSON with Gitea matches "
                                  "(needs GITEA_HOST + GITEA_TOKEN)")
    p_gitea.add_argument("--audit", default="-")
    p_gitea.add_argument("--out", default="-")
    p_gitea.add_argument("--host", default=None)
    p_gitea.add_argument("--token", default=None)
    p_gitea.add_argument("--user", default=None)
    p_gitea.set_defaults(fn=_cmd_gitea)

    p_extract = sub.add_parser("extract",
                               help="Detect (or repair) wrapper-repo antipattern")
    _add_root(p_extract)
    p_extract.add_argument("--json", action="store_true")
    p_extract.add_argument("--archive-and-delete", metavar="PARENT_REPO",
                           help="Repair: archive parent .git as .git.archive-<date>")
    p_extract.add_argument("--mirror-to", metavar="GIT_URL",
                           help="With --archive-and-delete: push as bare mirror first")
    p_extract.set_defaults(fn=_cmd_extract)

    p_gitignore = sub.add_parser("gitignore",
                                 help="Detect stack(s) and emit/write a .gitignore")
    p_gitignore.add_argument("path", nargs="?", default=".",
                             help="Directory to inspect (default: cwd)")
    p_gitignore.add_argument("--write", action="store_true",
                             help="Write the result to <path>/.gitignore")
    p_gitignore.add_argument("--overwrite", action="store_true",
                             help="With --write: overwrite an existing .gitignore")
    p_gitignore.add_argument("--no-common", action="store_true",
                             help="Skip the common (OS/editor/secrets) section")
    p_gitignore.set_defaults(fn=_cmd_gitignore)

    p_remediate = sub.add_parser("remediate",
                                 help="Plan/execute per-state remediations")
    p_remediate.add_argument("--audit", default="-",
                             help="Path to audit JSON (default: stdin)")
    p_remediate.add_argument("--plan", action="store_true",
                             help="Print the plan as JSON and exit")
    p_remediate.add_argument("--apply", action="store_true",
                             help="Actually run destructive actions (default: dry-run)")
    p_remediate.add_argument("--offline", action="store_true",
                             help="Skip the gh-api visibility check; treat unknown as public (safer for CI)")
    p_remediate.set_defaults(fn=_cmd_remediate)

    p_render = sub.add_parser("render", help="Render audit JSON to HTML")
    p_render.add_argument("--audit", default="-", help="Audit JSON path (default: stdin)")
    p_render.add_argument("--out", default="-", help="Output HTML path (default: stdout)")
    p_render.add_argument("--title", default="Code audit", help="Title shown in the HTML page")
    p_render.set_defaults(fn=_cmd_render)

    p_iw = sub.add_parser("init-workspace",
                          help="Run the full audit pipeline -> one output directory")
    _add_root(p_iw)
    p_iw.add_argument("--out", default=None,
                      help="Output directory (default: ./sca-run-<timestamp>)")
    p_iw.add_argument("--no-open", action="store_true",
                      help="Don't auto-open report.html in a browser")
    p_iw.add_argument("--no-warn", action="store_true",
                      help="Skip the 'does this look like a code root?' check")
    p_iw.add_argument("--no-prompt", action="store_true",
                      help="Don't prompt y/N for remediation after the report opens")
    p_iw.add_argument("--offline", action="store_true",
                      help="If you confirm the prompt, use the offline visibility gate")
    p_iw.set_defaults(fn=_cmd_init_workspace)

    p_pb = sub.add_parser("push-branches",
                          help="Push every unpushed/ahead branch across all repos")
    _add_root(p_pb)
    p_pb.add_argument("--apply", action="store_true",
                      help="Actually push (default: dry-run)")
    p_pb.add_argument("--offline", action="store_true",
                      help="Use offline visibility gate (treats unknown as public)")
    p_pb.add_argument("--json", action="store_true")
    p_pb.set_defaults(fn=_cmd_push_branches)

    args = parser.parse_args(argv)

    if args.cmd is None:
        # No subcommand -> default to `init-workspace` in cwd.
        # Construct args namespace as if init-workspace was called bare.
        from sca import init_workspace
        return init_workspace.main([])

    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
