#!/usr/bin/env python3
"""Per-repo exemption rules shared between the planner and the renderer.

Two repos in this workspace must NOT be remediated automatically because
they contain intentional Unicode / structural choices:

  * UnicodeReplacementTool (and any nested clones) -- by design contains
    every Unicode character it knows how to replace; running its own CI
    baseline against itself would always fail. Fully exempt from
    hygiene actions AND from the hygiene tier signals.

  * source-control-automation -- this very project. v3/tests/ contains
    test fixtures that intentionally use Unicode (e.g. U+2019) to verify
    the audit/redaction logic; URT must not rewrite them. Exempt from
    the unicode signal only.
"""
from __future__ import annotations


def _norm(name: str | None) -> str:
    return (name or "").replace("\\", "/")


def is_urt_repo(name: str | None) -> bool:
    """The UnicodeReplacementTool repo or any nested clone of it."""
    n = _norm(name)
    return n == "UnicodeReplacementTool" or n.startswith("UnicodeReplacementTool/")


def is_self_exempt(name: str | None) -> bool:
    """source-control-automation itself."""
    n = _norm(name)
    return n == "source-control-automation" or n.startswith("source-control-automation/")


def is_unicode_exempt(name: str | None) -> bool:
    """True if the repo should NOT be flagged for non-ASCII source.

    Either a URT repo (mapping table by design) or this project itself
    (test fixtures by design)."""
    return is_urt_repo(name) or is_self_exempt(name)


def is_readme_exempt(name: str | None) -> bool:
    """True if 'no README' shouldn't tier this repo as hygiene."""
    return is_urt_repo(name)


def is_ci_baseline_exempt(name: str | None) -> bool:
    """True if 'missing unicode-check workflow' shouldn't tier this repo."""
    return is_urt_repo(name)
