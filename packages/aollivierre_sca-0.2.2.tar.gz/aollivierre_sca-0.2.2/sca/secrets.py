#!/usr/bin/env python3
"""Secret scanner for committed files.

Detects patterns that should never be in a tracked file:
  - Live PATs / API keys (github_pat_, ghp_, sk-, AKIA...)
  - "Obfuscated*" config fields paired with a decode function in same repo
    (the XOR + base64 antipattern that masquerades as encryption)
  - Embedded PFX / private key blobs
  - SharePoint tenant URLs and obvious tenant/client/list UUIDs in config files
  - `password = "..."` shaped lines in config / source

Output: a list of finding dicts, JSON-serializable. Same shape returned whether
called as a CLI (`python -m sca.secrets <repo>`) or imported.

Severity convention:
  - critical: the secret value is recoverable from the repo as-is
              (live token, XOR-obfuscation+decoder, embedded pfx)
  - high:     identifying values that aid an attacker (tenant/client GUIDs in config)
  - info:     stylistic concerns (password=... patterns; needs human eyes)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from pathlib import Path

# ---------- patterns ----------

LIVE_TOKEN_PATTERNS: list[tuple[str, str]] = [
    ("github_pat",      r"github_pat_[A-Za-z0-9_]{50,}"),
    ("ghp",             r"ghp_[A-Za-z0-9]{30,}"),
    ("openai_sk",       r"sk-[A-Za-z0-9]{30,}"),
    ("aws_access_key",  r"AKIA[0-9A-Z]{16}"),
    ("slack_token",     r"xox[baprs]-[A-Za-z0-9-]{20,}"),
    ("google_api_key",  r"AIza[0-9A-Za-z\-_]{35}"),
    ("private_key_pem", r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----"),
    # JWT: header.payload.signature, all base64url. The header always starts
    # with `eyJ` (base64 of `{"`) and the payload is also a JSON object.
    ("jwt_access_token",
     r"eyJ[A-Za-z0-9_\-]{20,}\.eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}"),
    # Microsoft Identity Platform / MSAL refresh tokens: `0.<base64url>.A<long base64url>`.
    # The leading "0." version prefix and the "A"-prefixed second segment of
    # ~256+ chars are the discriminating signal.
    ("oauth_refresh_token",
     r"0\.[A-Za-z0-9_\-]{20,}\.A[A-Za-z0-9_\-]{200,}"),
]

# Hand-rolled obfuscation: an "Obfuscated*" field in a data file paired with a
# decode function in the same repo. This is the antipattern we caught in
# ResetIntuneEnrollment / bitlocker / etc.
OBFUSCATED_FIELD_PATTERN = re.compile(
    # `Obfuscated` + an uppercase letter (e.g. T in TenantId) + any
    # alphanumeric tail. The original pattern was [A-Za-z]* which missed
    # `ObfuscatedBase64` (the digit broke the match) -- a real config
    # field that we now correctly catch.
    r"\bObfuscated[A-Z][A-Za-z0-9]*\s*=",
    re.IGNORECASE,
)
DECODE_FUNCTION_HINTS = [
    re.compile(r"function\s+Get-DecryptedValue", re.IGNORECASE),
    re.compile(r"-bxor\s+(?:0x[0-9a-f]{1,2}|\d{1,3})", re.IGNORECASE),
    re.compile(r"\[Convert\]::FromBase64String.*-bxor", re.IGNORECASE | re.DOTALL),
]

# UUIDs that look like Azure / SharePoint identifiers, in config-shaped files
GUID_PATTERN = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
    re.IGNORECASE,
)
PLACEHOLDER_GUIDS = {
    "00000000-0000-0000-0000-000000000000",
}

SHAREPOINT_URL_PATTERN = re.compile(
    r"\b[a-z0-9-]+\.sharepoint\.com\b", re.IGNORECASE
)

PASSWORD_ASSIGNMENT_PATTERN = re.compile(
    r"""(?ix)
    # Boundaries: only LETTERS count as part of an identifier for the
    # purposes of this match. Underscores and digits are treated as
    # separators -- this is what makes UPPER_SNAKE prefixes like
    # AZURE_CLIENT_SECRET, JWT_SECRET, DB_PASSWORD, GITHUB_TOKEN,
    # OPENAI_API_KEY all match without enumerating each prefix.
    # The strict `\b` won't work (the underscore between AZURE and
    # CLIENT is a word char so there's no boundary there), and using
    # `(?<![A-Za-z0-9_])` on either side blocks every UPPER_SNAKE prefix.
    (?<![A-Za-z])
    (?:
        password | passwd | pwd
      | (?: client_? | refresh_? | access_? | api_? )? secret (?: _? (?: key | token ) )?
      | (?: refresh_? | access_? ) token | token
      | api[_-]? key
    )
    (?![A-Za-z])                            # not followed by more identifier letters
    ['"]?                                   # optional closing quote on the key
                                            # (PowerShell `'ClientSecret' = ...`)
    \s* [:=] \s*
    ['"][^'"\s]{8,}['"]
    """
)

# PowerShell parameter form: -Secret 'value', -ClientSecret "...", -Token '...'.
# The current PASSWORD_ASSIGNMENT_PATTERN requires `[:=]` between the key and
# the value; PowerShell parameters use whitespace instead. Match those too.
# Also accept an optional UPPER_SNAKE prefix (-AZURE_CLIENT_SECRET, etc.).
SECRET_PARAMETER_PATTERN = re.compile(
    r"""(?ix)
    -                                       # PowerShell parameter prefix
    (?: [A-Za-z][A-Za-z0-9]*_ )*            # optional snake-case prefixes
                                            # (AZURE_, OPENAI_, GITHUB_, ...)
    (?:
        (?: client_? | refresh_? | access_? | api_? )? secret (?: _? (?: key | token ) )?
      | (?: refresh_? | access_? ) token | token
      | api[_-]? key
      | password
    )
    (?![A-Za-z])                            # parameter name ends here
    \s+
    ['"][^'"\s]{8,}['"]
    """
)

# files we should never bother scanning
SKIP_FILE_GLOBS = {".git", "node_modules", "__pycache__", ".venv", "venv",
                   "dist", "build", "Logs", "logs", "ignored-bad-zips"}
# binary-likely extensions -- skip
BINARY_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip", ".gz", ".tar",
               ".7z", ".exe", ".dll", ".so", ".dylib", ".bin", ".class",
               ".pyc", ".o", ".a", ".lib", ".woff", ".woff2", ".ttf", ".otf",
               ".ico", ".jar", ".war", ".db", ".sqlite", ".pfx", ".p12"}
# size cap for any single file we'll read
MAX_FILE_BYTES = 2 * 1024 * 1024  # 2 MB


@dataclass
class Finding:
    severity: str       # "critical" | "high" | "info"
    category: str       # short tag, e.g. "github_pat"
    path: str           # repo-relative
    line: int
    excerpt: str        # ~80-char context window, secret value MASKED
    note: str = ""

    def asdict(self) -> dict:
        return asdict(self)


# ---------- helpers ----------

def _is_skipped_path(path: Path, repo_root: Path) -> bool:
    rel = path.relative_to(repo_root)
    return any(part in SKIP_FILE_GLOBS for part in rel.parts)


def _is_binary(path: Path) -> bool:
    if path.suffix.lower() in BINARY_EXTS:
        return True
    try:
        with path.open("rb") as f:
            chunk = f.read(2048)
        return b"\x00" in chunk
    except OSError:
        return True


def _mask(s: str, secret_start: int, secret_end: int) -> str:
    """Mask the actual secret bytes; keep ~10 chars of context around it."""
    pre = s[max(0, secret_start - 30):secret_start]
    post = s[secret_end:secret_end + 30]
    masked = "<REDACTED>"
    excerpt = (pre + masked + post).replace("\n", " ").strip()
    return excerpt[:120]


def _path_matches_any(rel_path: Path, patterns: list[str]) -> bool:
    """True if `rel_path` matches any of the glob-ish patterns. Patterns are
    matched against both the full relative path and any individual path part."""
    if not patterns:
        return False
    s = str(rel_path).replace("\\", "/")
    for pat in patterns:
        norm = pat.replace("\\", "/").strip("/")
        if not norm:
            continue
        # 1) substring match against the full relative path
        if norm in s:
            return True
        # 2) exact match against any single path part (e.g. "tests")
        if norm in rel_path.parts:
            return True
    return False


def _iter_repo_files(repo_root: Path,
                     extra_excludes: list[str] | None = None) -> Iterable[Path]:
    """Yield tracked files under the repo (uses `git ls-files`)."""
    extra_excludes = extra_excludes or []
    rc, out = _run(["git", "-C", str(repo_root), "ls-files"])
    if rc != 0:
        # not a git repo or git missing -- fall back to walking the tree
        for p in repo_root.rglob("*"):
            if not p.is_file():
                continue
            if _is_skipped_path(p, repo_root):
                continue
            if _path_matches_any(p.relative_to(repo_root), extra_excludes):
                continue
            yield p
        return
    for rel in out.splitlines():
        p = repo_root / rel
        if not p.is_file():
            continue
        if _is_skipped_path(p, repo_root):
            continue
        if _path_matches_any(p.relative_to(repo_root), extra_excludes):
            continue
        yield p


def _run(cmd: list[str], timeout: int = 30) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        return -1, ""


# ---------- scanners ----------

_BASE64_RUN_RE = re.compile(r"[A-Za-z0-9+/=_-]{200,}")
_OBFUSCATION_HINT_RE = re.compile(
    r"obfuscat|base64|encoded|encrypted", re.IGNORECASE
)


def _line_is_obfuscated_blob(text: str, offset: int) -> bool:
    """True if `offset` falls inside a line that looks like an obfuscated /
    base64-encoded blob. Live-token regexes (github_pat_, AIza..., etc.) can
    match coincidentally inside long base64 strings; we don't want to flag
    those.

    Two signals (either is enough):
      a) The line contains an Obfuscated* assignment.
      b) The line contains the word `obfuscat`/`base64`/`encoded`/`encrypted`
         AND has a contiguous run of base64-ish chars >= 200 long (so it's
         clearly a blob, not just a prose mention).
    """
    line_start = text.rfind("\n", 0, offset) + 1
    line_end = text.find("\n", offset)
    if line_end == -1:
        line_end = len(text)
    line = text[line_start:line_end]
    if OBFUSCATED_FIELD_PATTERN.search(line):
        return True
    if _OBFUSCATION_HINT_RE.search(line) and _BASE64_RUN_RE.search(line):
        return True
    return False


def _is_archived_path(rel: str) -> bool:
    """True if a relative path looks like archived/legacy code.

    The user's workspace convention puts deprecated scripts under names
    like `.archive/`, `archived-test-scripts/`, or `legacy/`. Live-token
    findings (real PATs, etc.) stay critical regardless -- treat them
    as burned anywhere -- but `xor_obfuscation` (a pattern, not a value)
    drops from critical to high in these paths, so dead-code structural
    leaks don't block CI on repos that are otherwise clean.
    """
    from pathlib import PurePosixPath
    parts = PurePosixPath(rel.replace("\\", "/")).parts
    for part in parts:
        p = part.lower()
        if p in (".archive", "legacy", "deprecated"):
            return True
        if p.startswith("archived-") or p.startswith(".archive-") \
                or p.startswith("legacy-"):
            return True
    return False


def scan_live_tokens(text: str, path_str: str) -> list[Finding]:
    out: list[Finding] = []
    for category, regex in LIVE_TOKEN_PATTERNS:
        for m in re.finditer(regex, text):
            # Skip matches that fall inside an obvious XOR-obfuscation blob:
            # the "google_api_key" / "github_pat" regexes can match coincidentally
            # inside a multi-KB base64 string by sheer luck.
            if _line_is_obfuscated_blob(text, m.start()):
                continue
            line = text.count("\n", 0, m.start()) + 1
            out.append(Finding(
                severity="critical",
                category=category,
                path=path_str,
                line=line,
                excerpt=_mask(text, m.start(), m.end()),
                note="Live secret pattern. Treat the credential as burned; rotate immediately.",
            ))
    return out


# Already-redacted markers we should skip in scanner output. Reduces audit
# noise after a redact pass: `$Token = "<REDACTED>"` should not be re-flagged.
_REDACTED_VALUE_RE = re.compile(
    r"""['"]\s*<REDACTED(?:-[A-Z\-]+)?>\s*['"]""", re.IGNORECASE
)


def _match_value_is_redacted_marker(match_text: str) -> bool:
    return bool(_REDACTED_VALUE_RE.search(match_text))


def scan_password_assignments(text: str, path_str: str) -> list[Finding]:
    out: list[Finding] = []
    for m in re.finditer(PASSWORD_ASSIGNMENT_PATTERN, text):
        if _match_value_is_redacted_marker(m.group(0)):
            continue
        line = text.count("\n", 0, m.start()) + 1
        out.append(Finding(
            severity="info",
            category="password_assignment",
            path=path_str,
            line=line,
            excerpt=_mask(text, m.start(), m.end()),
            note="password/secret/api_key assignment to a literal -- verify it's not a real secret.",
        ))
    return out


def scan_secret_parameters(text: str, path_str: str) -> list[Finding]:
    """PowerShell parameter form: `-Secret 'value'` / `-ClientSecret "..."`.
    Distinct from `password_assignment` because there's no `=`/`:` between
    the key and the value -- the key is a parameter name passed by the
    caller. Same severity as password_assignment (info: needs human eyes).
    """
    out: list[Finding] = []
    for m in re.finditer(SECRET_PARAMETER_PATTERN, text):
        if _match_value_is_redacted_marker(m.group(0)):
            continue
        line = text.count("\n", 0, m.start()) + 1
        out.append(Finding(
            severity="info",
            category="secret_parameter",
            path=path_str,
            line=line,
            excerpt=_mask(text, m.start(), m.end()),
            note="Secret-like value passed as a PowerShell parameter -- verify it's not a real secret.",
        ))
    return out


# Files we expect to contain placeholder versions of obfuscated fields
# (template / example / sample naming conventions).
TEMPLATE_NAME_HINTS = (".template.", ".example.", ".sample.", "-template.",
                        "-example.", "-sample.")

# A line/value is a "placeholder" if it looks like a documentation
# example rather than a real obfuscated blob: short, contains angle
# brackets, contains 'TODO/FIXME/PLACEHOLDER', or is bracketed punctuation
PLACEHOLDER_VALUE_RE = re.compile(
    r"""
    \s*                                 # whitespace after the `=` match
    ['"]?                               # optional quote
    (?:                                 # one of:
        <[^>]*>                         #   <REDACTED>, <bracketed-token>
        | \$\([^)]*\)                   #   $(powershell.expr) interpolation
        | \{\{[^}]*\}\}                 #   {{ jinja }}
        | \$\{[^}]*\}                   #   ${shell}
        | \{[^}]*\}                     #   {python.fmt}
        | (?:TODO|FIXME|PLACEHOLDER|EXAMPLE|REPLACE_ME|YOUR_[A-Z_]+|REDACTED)
        | [\w_-]*(?:paste|placeholder|example|replace|sample)[\w_-]*
                                        #   paste_encrypted_value_here etc.
        | [a-zA-Z]{0,8}                 #   very short tokens like "AAAA", "x"
    )
    ['"]?\s*(?:[#}].*)?$                # end-of-line, optional comment / closing brace
    """,
    re.VERBOSE | re.IGNORECASE,
)
# NOTE: the leading `=\s*` was removed because `_line_value_is_placeholder`
# already consumes up to the `=` (the OBFUSCATED_FIELD_PATTERN ends with `=`,
# so its match_end is past the equals). The regex therefore receives the
# value side of the assignment, with leading whitespace.


def _is_template_filename(p: Path) -> bool:
    name = p.name.lower()
    return any(hint in name for hint in TEMPLATE_NAME_HINTS)


def _is_documentation_path(rel_path: str) -> bool:
    """Markdown / RST / docs/* files often contain Obfuscated* field
    NAMES as illustrative examples ('here's how a leaked config looks')
    without any real secret value next to them. They're noisy in audits
    and harvest already skips them; do the same here so the two passes
    agree on what is a real finding."""
    p = rel_path.lower().replace("\\", "/")
    if p.endswith((".md", ".rst", ".adoc", ".txt")):
        return True
    if "/docs/" in p or p.startswith("docs/"):
        return True
    return False


_RHS_QUOTED_STRING_RE = re.compile(r"=\s*['\"][^'\"\n]*['\"]")


def _line_has_string_literal_rhs(text: str, match_start: int) -> bool:
    """True if the line containing match_start has a quoted-string value
    after its first `=`. Used to distinguish:
        ObfuscatedTenantId = 'aBcDeF...'                  (quoted: real value)
        ObfuscatedTenantId = ConvertTo-ObfuscatedString $x (no quote: code)
        ObfuscatedTenantId = $config.ObfuscatedTenantId    (no quote: variable)
    """
    line_start = text.rfind("\n", 0, match_start) + 1
    line_end = text.find("\n", match_start)
    if line_end == -1:
        line_end = len(text)
    line = text[line_start:line_end]
    return bool(_RHS_QUOTED_STRING_RE.search(line))


# A line is a regex/replace operation if it uses one of these keywords.
# The `Obfuscated*` token inside such a line is part of the regex pattern,
# not a real assignment.
_REGEX_OPERATION_RE = re.compile(
    # PowerShell `-replace` / `-match` start with a non-word char so a
    # leading `\b` won't match. Anchor on whitespace-or-start instead.
    r"(?:^|\s)-(?:replace|match)\b"
    r"|\bre\.(?:sub|match|search|finditer|findall)\b"
    r"|\bregex\.\w+"
    r"|\.replace\s*\("
    r"|\bString\.Replace\b"
    r"|\[Regex\]::(?:Replace|Match|IsMatch)"
    r"|\bsed\s+s/",
    re.IGNORECASE,
)
# Or the value side itself contains regex metacharacters that wouldn't
# show up in a real obfuscated value (which is base64-shaped).
_REGEX_METACHAR_RE = re.compile(
    r"\[\^[^\]]+\]|\(\?:[^)]+\)|\\[bdsw]|\.\*\?|\.\+\?",
)


def _line_is_regex_operation(text: str, match_start: int) -> bool:
    """True if the line containing match_start is a regex/replace
    operation (the Obfuscated* text is a search pattern, not a value)."""
    line_start = text.rfind("\n", 0, match_start) + 1
    line_end = text.find("\n", match_start)
    if line_end == -1:
        line_end = len(text)
    line = text[line_start:line_end]
    if _REGEX_OPERATION_RE.search(line):
        return True
    if _REGEX_METACHAR_RE.search(line):
        return True
    return False


def _line_is_comment(text: str, match_start: int) -> bool:
    """True if the line containing `match_start` is a comment.

    Recognises the common single-line forms across the languages we
    actually scan:
        # ...    PowerShell, Python, shell, YAML, INI
        // ...   C / C#, JS / TS, Rust, Go, Java
        ; ...    INI, assembly
        -- ...   SQL, Lua, Haskell, Ada
    Lines may have leading whitespace before the comment marker.
    """
    line_start = text.rfind("\n", 0, match_start) + 1
    # Walk to first non-whitespace char on the line
    i = line_start
    while i < len(text) and text[i] in " \t":
        i += 1
    if i >= len(text):
        return False
    rest = text[i:i + 2]
    if rest.startswith("#") or rest.startswith(";"):
        return True
    if rest in ("//", "--"):
        return True
    return False


def _line_value_is_placeholder(text: str, match_end: int) -> bool:
    """Look at the rest of the line after an Obfuscated* match; return True
    if the value looks like a documentation placeholder."""
    line_end = text.find("\n", match_end)
    if line_end == -1:
        line_end = len(text)
    rest = text[match_end:line_end]
    return bool(PLACEHOLDER_VALUE_RE.match(rest))


def scan_obfuscated_fields(repo_root: Path, file_paths: list[Path]) -> list[Finding]:
    """Pair files containing `Obfuscated*` fields with files containing decoder hints
    in the SAME repo. If both exist, the obfuscated values are recoverable.

    Skips findings if the file is a template/example file OR the value is
    obviously a placeholder."""
    obfuscated_files: list[tuple[Path, list[tuple[int, str]]]] = []
    decoder_files: list[Path] = []

    for p in file_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if _is_template_filename(p):
            # Templates may legitimately contain Obfuscated* field names
            # (with placeholder values) for documentation purposes.
            continue
        try:
            rel = str(p.relative_to(repo_root))
        except ValueError:
            rel = p.name
        if _is_documentation_path(rel):
            # .md / .rst / docs/ files: skip. Examples of leaked configs
            # in documentation are not real, recoverable secrets.
            continue
        hits: list[tuple[int, str]] = []
        for m in OBFUSCATED_FIELD_PATTERN.finditer(text):
            # Skip commented-out lines (PowerShell `#`, Python `#`, etc.)
            if _line_is_comment(text, m.start()):
                continue
            # Skip lines that are regex/replace operations -- the
            # `Obfuscated*` text is a search pattern, not an assignment.
            if _line_is_regex_operation(text, m.start()):
                continue
            if _line_value_is_placeholder(text, m.end()):
                continue
            # Real-value detection: only flag if the RHS is a quoted
            # string literal. Variable references and function calls
            # (`ObfuscatedTenantId = ConvertTo-ObfuscatedString $x`)
            # are not themselves the secret -- the real value lives
            # wherever $x came from, which the scanner can't follow.
            if not _line_has_string_literal_rhs(text, m.start()):
                continue
            line = text.count("\n", 0, m.start()) + 1
            hits.append((line, m.group(0)))
        if hits:
            obfuscated_files.append((p, hits))
        if any(rx.search(text) for rx in DECODE_FUNCTION_HINTS):
            decoder_files.append(p)

    if not (obfuscated_files and decoder_files):
        return []

    out: list[Finding] = []
    decoder_names = ", ".join(str(d.relative_to(repo_root)) for d in decoder_files[:3])
    for p, hits in obfuscated_files:
        rel = str(p.relative_to(repo_root))
        archived = _is_archived_path(rel)
        # Archived/legacy paths still get the finding surfaced (high
        # severity, audit-visible) but don't fail CI (which only blocks
        # on critical). The pattern still represents leaked structure
        # worth eventual cleanup; it's just not a live-incident-level
        # risk in dead code paths whose secrets are presumed rotated.
        severity = "high" if archived else "critical"
        suffix = ""
        if archived:
            suffix = (" Note: file is in an archived/legacy path; severity "
                      "downgraded from critical to high. Redact or remove "
                      "to clear.")
        for line, frag in hits:
            out.append(Finding(
                severity=severity,
                category="xor_obfuscation",
                path=rel,
                line=line,
                excerpt=frag,
                note=f"`Obfuscated*` field in same repo as a decode function ({decoder_names}). "
                     f"Treat as plaintext leak; XOR+base64 != encryption.{suffix}",
            ))
    return out


def scan_real_looking_guids(text: str, path_str: str) -> list[Finding]:
    """Flag UUIDs in config-shaped files that aren't placeholder zeros."""
    if not (path_str.endswith((".psd1", ".json", ".yaml", ".yml", ".env",
                               ".config", ".ini", ".toml"))):
        return []
    out: list[Finding] = []
    for m in GUID_PATTERN.finditer(text):
        if m.group(0).lower() in PLACEHOLDER_GUIDS:
            continue
        line = text.count("\n", 0, m.start()) + 1
        out.append(Finding(
            severity="high",
            category="real_looking_guid",
            path=path_str,
            line=line,
            excerpt=_mask(text, m.start(), m.end()),
            note="UUID in config file. May be a tenant/client/list ID -- verify before publishing.",
        ))
    return out


def scan_sharepoint_urls(text: str, path_str: str) -> list[Finding]:
    out: list[Finding] = []
    for m in SHAREPOINT_URL_PATTERN.finditer(text):
        url = m.group(0).lower()
        if url in {"test.sharepoint.com", "example.sharepoint.com",
                   "contoso.sharepoint.com"}:
            continue
        line = text.count("\n", 0, m.start()) + 1
        out.append(Finding(
            severity="high",
            category="sharepoint_url",
            path=path_str,
            line=line,
            excerpt=_mask(text, m.start(), m.end()),
            note="Real-looking SharePoint tenant URL.",
        ))
    return out


# ---------- top-level scan ----------

def scan_repo(repo_root: Path,
              exclude: list[str] | None = None) -> list[Finding]:
    """Scan a git repo for committed secrets.

    exclude: list of path-pattern strings (substring or path-part match).
             Pass e.g. ["tests"] to skip test fixtures that contain
             intentionally PAT-shaped strings."""
    repo_root = repo_root.resolve()
    findings: list[Finding] = []
    file_paths: list[Path] = []

    for p in _iter_repo_files(repo_root, extra_excludes=exclude or []):
        if _is_binary(p):
            continue
        try:
            if p.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        file_paths.append(p)

    # First pass: per-file pattern scanners
    for p in file_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = str(p.relative_to(repo_root))
        findings.extend(scan_live_tokens(text, rel))
        findings.extend(scan_password_assignments(text, rel))
        findings.extend(scan_secret_parameters(text, rel))
        findings.extend(scan_real_looking_guids(text, rel))
        findings.extend(scan_sharepoint_urls(text, rel))

    # Cross-file: obfuscated-field-with-decoder-in-same-repo
    findings.extend(scan_obfuscated_fields(repo_root, file_paths))

    # Sort: critical first, then by path/line
    sev_rank = {"critical": 0, "high": 1, "info": 2}
    findings.sort(key=lambda f: (sev_rank.get(f.severity, 99), f.path, f.line))
    return findings


# ---------- CLI ----------

def _format_text(findings: list[Finding]) -> str:
    if not findings:
        return "no findings\n"
    lines = []
    by_sev: dict[str, list[Finding]] = {}
    for f in findings:
        by_sev.setdefault(f.severity, []).append(f)
    for sev in ("critical", "high", "info"):
        bucket = by_sev.get(sev, [])
        if not bucket:
            continue
        lines.append(f"\n=== {sev.upper()} ({len(bucket)}) ===")
        for f in bucket:
            lines.append(f"  [{f.category}] {f.path}:{f.line}")
            lines.append(f"    {f.excerpt}")
            if f.note:
                lines.append(f"    note: {f.note}")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Scan a repo for committed secrets.")
    ap.add_argument("repo", nargs="?", default=os.getcwd(),
                    help="Path to git repo (default: cwd)")
    ap.add_argument("--json", action="store_true",
                    help="Emit JSON instead of formatted text")
    ap.add_argument("--exclude", action="append", default=[],
                    metavar="PATTERN",
                    help="Skip paths matching PATTERN (repeatable). "
                         "Matches as substring of relative path OR exact path-part.")
    args = ap.parse_args(argv)

    repo = Path(args.repo).resolve()
    if not repo.exists():
        print(f"error: {repo} does not exist", file=sys.stderr)
        return 2

    findings = scan_repo(repo, exclude=args.exclude)

    if args.json:
        print(json.dumps([f.asdict() for f in findings], indent=2))
    else:
        print(_format_text(findings), end="")

    # exit code communicates severity for CI
    if any(f.severity == "critical" for f in findings):
        return 2
    if any(f.severity == "high" for f in findings):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
