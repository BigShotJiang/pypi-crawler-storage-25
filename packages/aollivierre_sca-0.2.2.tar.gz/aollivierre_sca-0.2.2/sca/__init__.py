"""source-control-automation v3 -- Python rewrite."""

__version__ = "0.1.0-dev"
