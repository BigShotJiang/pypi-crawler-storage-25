#!/usr/bin/env python3
"""Force-redact committed secrets in working-tree files.

Reads the same patterns as `sca.secrets`; rewrites every match (except
the XOR-obfuscation antipattern) to `<REDACTED>` in place. The repo's
git history is unchanged -- this is a working-tree fix only. After
running, the user should commit the redaction and rotate the leaked
secret. (History rewriting is out of scope: it requires force-pushes
and breaks every clone.)

Categories that ARE redacted:
    github_pat, ghp, openai_sk, aws_access_key, slack_token,
    google_api_key, private_key_pem,
    jwt_access_token, oauth_refresh_token,
    real_looking_guid (config files only),
    sharepoint_url,
    password_assignment, secret_parameter.

Categories NOT redacted (out of scope per the task spec):
    xor_obfuscation -- the field name is innocuous; redacting it would
                       break decoders without removing the secret. The
                       audit still flags these for human attention.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

from sca import secrets as _secrets

# Categories we will rewrite. Keep in sync with secrets.py.
REDACTABLE_CATEGORIES: frozenset[str] = frozenset({
    "github_pat", "ghp", "openai_sk", "aws_access_key", "slack_token",
    "google_api_key", "private_key_pem",
    "jwt_access_token", "oauth_refresh_token",
    "real_looking_guid", "sharepoint_url",
    "password_assignment", "secret_parameter",
})

PLACEHOLDER = "<REDACTED>"


def _patterns_for_redaction() -> list[tuple[str, re.Pattern]]:
    """Compile redaction-eligible patterns from sca.secrets."""
    out: list[tuple[str, re.Pattern]] = []
    for category, regex in _secrets.LIVE_TOKEN_PATTERNS:
        if category in REDACTABLE_CATEGORIES:
            out.append((category, re.compile(regex)))
    out.append(("password_assignment", _secrets.PASSWORD_ASSIGNMENT_PATTERN))
    out.append(("secret_parameter", _secrets.SECRET_PARAMETER_PATTERN))
    out.append(("real_looking_guid", _secrets.GUID_PATTERN))
    out.append(("sharepoint_url", _secrets.SHAREPOINT_URL_PATTERN))
    return out


def redact_text(text: str, *, only_config: bool = False) -> tuple[str, int]:
    """Return (redacted_text, num_replacements). If only_config is True,
    GUID redaction is skipped (callers gate that on file extension)."""
    n = 0
    new = text
    for category, regex in _patterns_for_redaction():
        if category == "real_looking_guid" and not only_config:
            continue
        if category in ("password_assignment", "secret_parameter"):
            # Replace just the literal value, keep the key + separator (`=`,
            # `:`, or whitespace for the parameter form).
            # Skip if the value is already the placeholder (avoids double-counting
            # when a more specific token regex already redacted this line).
            def _sub(m: re.Match) -> str:
                nonlocal n
                if PLACEHOLDER in m.group(0):
                    return m.group(0)
                n += 1
                key_part = re.split(r"['\"]", m.group(0), maxsplit=1)[0]
                return f"{key_part}\"{PLACEHOLDER}\""
            new = regex.sub(_sub, new)
            continue
        if category == "real_looking_guid":
            # Skip placeholder zeros.
            def _sub_guid(m: re.Match) -> str:
                nonlocal n
                if m.group(0).lower() in _secrets.PLACEHOLDER_GUIDS:
                    return m.group(0)
                n += 1
                return PLACEHOLDER
            new = regex.sub(_sub_guid, new)
            continue
        # Default: replace the whole match with the placeholder.
        def _generic_sub(m: re.Match) -> str:
            nonlocal n
            n += 1
            return PLACEHOLDER
        new = regex.sub(_generic_sub, new)
    return new, n


def redact_file(path: Path) -> int:
    """Redact a single file in place. Returns the number of replacements."""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return 0
    only_config = path.suffix.lower() in (".psd1", ".json", ".yaml", ".yml",
                                          ".env", ".config", ".ini", ".toml")
    new, n = redact_text(text, only_config=only_config)
    if n > 0 and new != text:
        try:
            path.write_text(new, encoding="utf-8")
        except OSError:
            return 0
    return n


def redact_repo(repo_root: Path,
                exclude: list[str] | None = None) -> int:
    """Redact every redactable secret in the repo's tracked files."""
    repo_root = repo_root.resolve()
    total = 0
    for p in _secrets._iter_repo_files(repo_root, extra_excludes=exclude or []):
        if _secrets._is_binary(p):
            continue
        try:
            if p.stat().st_size > _secrets.MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        total += redact_file(p)
    return total


# ---------- harvest-driven redaction (precise; no regex FPs) ----------

# Categories from harvest that we always redact (high confidence).
HARVEST_ALWAYS_REDACT: frozenset[str] = frozenset({
    "github_pat", "ghp", "openai_sk", "aws_access_key", "slack_token",
    "google_api_key", "private_key_pem",
    "xor_obfuscation",
    "sharepoint_url",
})

# Context keywords that mark a real_looking_guid as a CLIENT-ish value
# (an AppId / clientId / cert ref). Tenant IDs are public per the user's
# threat model and remain unredacted; everything else (task IDs, profile
# GUIDs, enrollment IDs, module GUIDs) also stays.
_GUID_CLIENT_CONTEXT_RE = __import__("re").compile(
    r"\b(AppId|clientId|client_id|client-id|application_id|applicationId|"
    r"cert(ificate)?|thumbprint|fingerprint|secret)\b",
    __import__("re").IGNORECASE,
)


def _harvest_values_for_repo(harvest_root: Path, repo_name: str
                              ) -> list[tuple[str, str]]:
    """Return [(category, value)] of secrets to redact in this repo.

    Reads the harvest output, deduplicates by value, and applies the
    'GUID needs CLIENT context' rule for real_looking_guid."""
    cat_dir = harvest_root / "by-category"
    if not cat_dir.is_dir():
        return []
    out: list[tuple[str, str]] = []
    seen: set[str] = set()
    for sub in sorted(cat_dir.iterdir()):
        if not sub.is_dir():
            continue
        category = sub.name
        for entry_file in sorted(sub.glob("*.json")):
            try:
                d = json.loads(entry_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            value = d.get("value", "")
            if not value or value in seen:
                continue
            occurrences = [o for o in d.get("occurrences", [])
                            if o.get("repo") == repo_name]
            if not occurrences:
                continue
            keep = False
            if category in HARVEST_ALWAYS_REDACT:
                keep = True
            elif category == "real_looking_guid":
                ctx = d.get("context") or ""
                if _GUID_CLIENT_CONTEXT_RE.search(ctx):
                    keep = True
            if keep:
                out.append((category, value))
                seen.add(value)
    return out


def redact_repo_from_harvest(repo_root: Path, harvest_root: Path,
                              dry_run: bool = False) -> dict:
    """Apply literal-string redactions from a harvest dir.

    Returns a summary dict {'replacements': int, 'files_changed': int,
    'values_redacted': int, 'by_category': dict}."""
    repo_root = repo_root.resolve()
    harvest_root = harvest_root.resolve()
    pairs = _harvest_values_for_repo(harvest_root, repo_root.name)
    by_cat: dict[str, int] = {}
    files_changed: set[str] = set()
    total_replacements = 0
    if not pairs:
        return {"replacements": 0, "files_changed": 0,
                "values_redacted": 0, "by_category": {}}

    # Walk every text file in the repo (using git ls-files) and apply
    # literal substitutions. We don't bound to harvest's listed paths
    # because the same value may have leaked into other tracked files.
    #
    # IMPORTANT: read/write in BINARY mode so we don't perturb line
    # endings (CRLF/LF). Text-mode IO on Windows would round-trip every
    # line and produce a useless mega-diff for a tiny logical change.
    placeholder_bytes = PLACEHOLDER.encode("utf-8")
    pairs_bytes = [(cat, val.encode("utf-8")) for cat, val in pairs]
    for p in _secrets._iter_repo_files(repo_root):
        if _secrets._is_binary(p):
            continue
        try:
            if p.stat().st_size > _secrets.MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        try:
            data = p.read_bytes()
        except OSError:
            continue
        new_data = data
        local_count = 0
        for category, value_b in pairs_bytes:
            if value_b not in new_data:
                continue
            n = new_data.count(value_b)
            new_data = new_data.replace(value_b, placeholder_bytes)
            local_count += n
            by_cat[category] = by_cat.get(category, 0) + n
        if local_count > 0:
            total_replacements += local_count
            files_changed.add(str(p))
            if not dry_run:
                try:
                    p.write_bytes(new_data)
                except OSError:
                    pass
    return {
        "replacements":     total_replacements,
        "files_changed":    len(files_changed),
        "values_redacted":  len({v for _, v in pairs
                                  if total_replacements > 0}),
        "by_category":      by_cat,
        "files":            sorted(files_changed),
    }


# ---------- CLI ----------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Force-redact committed secrets in place.")
    ap.add_argument("repo", nargs="?", default=os.getcwd(),
                    help="Path to git repo (default: cwd)")
    ap.add_argument("--apply", action="store_true",
                    help="Actually rewrite files. Without this flag, dry-run.")
    ap.add_argument("--exclude", action="append", default=[], metavar="PATTERN")
    ap.add_argument("--from-harvest", default=None, metavar="DIR",
                    help="Use the harvest output at DIR as the precise list "
                         "of values to redact (no regex FPs). Honors the "
                         "GUID-needs-CLIENT-context rule.")
    args = ap.parse_args(argv)

    repo = Path(args.repo).resolve()

    if args.from_harvest:
        result = redact_repo_from_harvest(
            repo, Path(args.from_harvest), dry_run=not args.apply,
        )
        print(json.dumps(result, indent=2))
        return 0

    if not args.apply:
        # Dry-run: scan + report what would be redacted, but don't write.
        findings = _secrets.scan_repo(repo, exclude=args.exclude or None)
        eligible = [f for f in findings if f.category in REDACTABLE_CATEGORIES]
        print(json.dumps(
            {"would_redact": len(eligible),
             "by_category": {c: sum(1 for f in eligible if f.category == c)
                             for c in REDACTABLE_CATEGORIES},
             "skipped_xor_obfuscation": sum(1 for f in findings
                                            if f.category == "xor_obfuscation")},
            indent=2,
        ))
        return 0
    n = redact_repo(repo, exclude=args.exclude)
    print(json.dumps({"redacted": n}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
