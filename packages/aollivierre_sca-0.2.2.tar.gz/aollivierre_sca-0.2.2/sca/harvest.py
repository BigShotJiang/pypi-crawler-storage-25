#!/usr/bin/env python3
"""Harvest unique secret values from contaminated repos.

Read-only. Walks the same patterns sca.secrets uses, but instead of
masking the matched bytes, captures the real value into a deduplicated
on-disk inventory. The output is intended as a backup BEFORE any
redaction or history rewrite -- so the user can rotate the credential
on the issuing service.

Output layout (default --out is C:/code/secrets):

    secrets/
    +-- README.md                     (warning + usage notes)
    +-- .gitignore                    (ignores everything inside)
    +-- manifest.json                 (index of every harvested value)
    +-- by-category/
    |   +-- github_pat/
    |   |   +-- <hash>.json           (one file per unique value)
    |   +-- xor_obfuscation/
    |   +-- ...
    +-- by-repo/
        +-- <repo-name>.json          (all findings for one repo)

Each <hash>.json:
    {
      "id":          <16-char sha256 prefix of the value>,
      "category":    "github_pat" | "xor_obfuscation" | ...,
      "severity":    "critical" | "high" | "info",
      "value":       <raw secret bytes>,                # the actual secret
      "context":     <120-char window around the match>,
      "occurrences": [
        {"repo": "...", "path": "...", "line": ...},
        ...
      ]
    }

CLI:
    sca harvest --root C:/code [--out C:/code/secrets]
    sca harvest --root C:/code/some-repo            # single repo

Categories that ARE harvested:
    github_pat, ghp, openai_sk, aws_access_key, slack_token,
    google_api_key, private_key_pem,
    xor_obfuscation,                # captures the right-hand value too
    real_looking_guid,
    sharepoint_url,
    password_assignment.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

from sca import secrets as _secrets

# Paste the categories ordered by precision (highest first). The CLI
# accepts --categories to limit the harvest.
HIGH_CONFIDENCE: tuple[str, ...] = (
    "github_pat", "ghp", "openai_sk", "aws_access_key",
    "slack_token", "google_api_key", "private_key_pem",
    "jwt_access_token", "oauth_refresh_token",
    "xor_obfuscation",
)
MEDIUM_CONFIDENCE: tuple[str, ...] = (
    "real_looking_guid", "sharepoint_url",
)
LOW_CONFIDENCE: tuple[str, ...] = (
    "password_assignment", "secret_parameter",
)


def _hash_id(value: str, length: int = 16) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="replace")).hexdigest()[:length]


def _safe_filename(s: str) -> str:
    return s.replace("/", "__").replace("\\", "__").replace(":", "_")


# ---------- raw extraction (parallel to sca.secrets.scan_repo) ----------

def _line_at(text: str, offset: int) -> str:
    line_start = text.rfind("\n", 0, offset) + 1
    line_end = text.find("\n", offset)
    if line_end == -1:
        line_end = len(text)
    return text[line_start:line_end]


def _context_window(text: str, start: int, end: int, width: int = 60) -> str:
    pre = text[max(0, start - width):start]
    post = text[end:end + width]
    ctx = (pre + "<<<HIT>>>" + post).replace("\n", " ")
    return ctx[: 2 * width + 16]


def _extract_xor_value(line: str) -> str | None:
    """Pull the right-hand value of an `Obfuscated* = "..."` line."""
    m = re.search(r"=\s*[\"']([^\"']+)[\"']", line)
    if m:
        return m.group(1)
    m = re.search(r"=\s*([^\s]+)", line)
    return m.group(1) if m else None


# A "value" that's actually a code/template reference, not a real obfuscated
# string. Drop these to avoid false positives like:
#     ObfuscatedTenantId = '$($opObfuscatedConfig.ObfuscatedTenantId)'
#     ObfuscatedClientId = '{self.obfuscate_string(self.client_id)}'
_TEMPLATE_VALUE_RE = re.compile(
    r"""
    ^[\s'"]*       # optional surrounding quotes
    (?:
        \$\(.*\)   # PowerShell $(...)
        | \$\{.*\} # Bash / template ${...}
        | \{.*\}   # Python f-string / Jinja {...}
        | <[^>]+>  # <bracketed-token>
    )
    [\s'"]*$
    """,
    re.VERBOSE,
)


def _is_template_xor_value(value: str) -> bool:
    s = value.strip().strip("'\"")
    if not s:
        return True
    if _TEMPLATE_VALUE_RE.match(value.strip()):
        return True
    # Heuristic: anything starting with $ or { is code/template, not a real
    # base64-ish blob.
    if s.startswith(("$", "{")):
        return True
    # Function-call shaped values: starts with a verb-noun PowerShell pattern,
    # or contains a hyphen + uppercase letter (cmdlet style).
    if re.match(r"^[A-Z][a-zA-Z]+-[A-Z]", s):
        return True
    # Documentation-truncation markers: e.g. 'aWlsPjg/...' is a truncated
    # example in a .md file, not a real value.
    if "..." in s:
        return True
    # Placeholder phrases.
    placeholder_words = ("paste", "encrypted", "encoded",
                         "your_", "your-", "example", "placeholder",
                         "sample", "TODO", "FIXME")
    low = s.lower()
    if any(w.lower() in low for w in placeholder_words):
        # only treat as placeholder if it's MOSTLY english-looking. Real
        # base64 might coincidentally contain 'your' substring. Require
        # at least 3 non-base64 characters (letters with no digits in vicinity)
        # OR an underscore (real base64 doesn't use _).
        if "_" in s or "-" in s or " " in s:
            return True
    # Real obfuscated blobs are >= 16 chars; anything shorter looks like
    # a placeholder ('AAAA' etc.).
    if len(s) < 16:
        return True
    return False


def _xor_path_likely_documentation(path: str) -> bool:
    """A .md or readme file shouldn't contain a real obfuscated secret --
    if it does, the user should flag manually. Default: skip."""
    p = path.lower().replace("\\", "/")
    if p.endswith(".md") or p.endswith(".rst"):
        return True
    if "/docs/" in p or p.startswith("docs/"):
        return True
    return False


# SharePoint placeholder hostnames -- these are clearly examples in docs/
# config templates, not real tenant URLs.
_SHAREPOINT_PLACEHOLDERS = {
    "test.sharepoint.com", "example.sharepoint.com", "contoso.sharepoint.com",
    "tenant.sharepoint.com", "yoursite.sharepoint.com",
    "yourcompany.sharepoint.com", "yourtenant.sharepoint.com",
    "company.sharepoint.com", "mycompany.sharepoint.com",
    "testcompany.sharepoint.com", "demo.sharepoint.com",
}


def _is_placeholder_sharepoint(url: str) -> bool:
    low = url.strip().lower()
    for prefix in ("https://", "http://"):
        if low.startswith(prefix):
            low = low[len(prefix):]
    low = low.rstrip("/")
    if low in _SHAREPOINT_PLACEHOLDERS:
        return True
    # any hostname starting with "your" is a placeholder by convention
    host = low.split("/")[0]
    if host.startswith("your") and host.endswith(".sharepoint.com"):
        return True
    return False


def harvest_text(text: str, path_str: str,
                 categories: tuple[str, ...]) -> list[dict]:
    """Return a list of raw findings for one file. Each finding has:
        {category, severity, value, line, context}
    """
    out: list[dict] = []

    # Live tokens
    for category, regex in _secrets.LIVE_TOKEN_PATTERNS:
        if category not in categories:
            continue
        for m in re.finditer(regex, text):
            if _secrets._line_is_obfuscated_blob(text, m.start()):
                continue
            line = text.count("\n", 0, m.start()) + 1
            out.append({
                "category": category,
                "severity": "critical",
                "value": text[m.start():m.end()],
                "line": line,
                "context": _context_window(text, m.start(), m.end()),
            })

    if "password_assignment" in categories:
        for m in re.finditer(_secrets.PASSWORD_ASSIGNMENT_PATTERN, text):
            # Already-redacted lines are audit noise, not findings.
            if _secrets._match_value_is_redacted_marker(m.group(0)):
                continue
            line = text.count("\n", 0, m.start()) + 1
            out.append({
                "category": "password_assignment",
                "severity": "info",
                "value": text[m.start():m.end()],
                "line": line,
                "context": _context_window(text, m.start(), m.end()),
            })

    if "secret_parameter" in categories:
        for m in re.finditer(_secrets.SECRET_PARAMETER_PATTERN, text):
            if _secrets._match_value_is_redacted_marker(m.group(0)):
                continue
            line = text.count("\n", 0, m.start()) + 1
            out.append({
                "category": "secret_parameter",
                "severity": "info",
                "value": text[m.start():m.end()],
                "line": line,
                "context": _context_window(text, m.start(), m.end()),
            })

    if "real_looking_guid" in categories:
        # Only treat as a finding in config-shaped files (matches sca.secrets)
        if path_str.endswith((".psd1", ".json", ".yaml", ".yml", ".env",
                               ".config", ".ini", ".toml")):
            for m in re.finditer(_secrets.GUID_PATTERN, text):
                if m.group(0).lower() in _secrets.PLACEHOLDER_GUIDS:
                    continue
                line = text.count("\n", 0, m.start()) + 1
                out.append({
                    "category": "real_looking_guid",
                    "severity": "high",
                    "value": m.group(0),
                    "line": line,
                    "context": _context_window(text, m.start(), m.end()),
                })

    if "sharepoint_url" in categories:
        for m in re.finditer(_secrets.SHAREPOINT_URL_PATTERN, text):
            if _is_placeholder_sharepoint(m.group(0)):
                continue
            line = text.count("\n", 0, m.start()) + 1
            out.append({
                "category": "sharepoint_url",
                "severity": "high",
                "value": m.group(0),
                "line": line,
                "context": _context_window(text, m.start(), m.end()),
            })
    return out


# Match the path-substring exclude list init_workspace uses for the
# audit secret scan, so harvest doesn't trip on a project's own test
# fixtures (synthetic PATs etc.) or archived/backup-of-archive content.
DEFAULT_EXCLUDES: list[str] = [
    "tests", "__tests__", "spec", "test_data", "test-data", "fixtures",
    ".archive", "backups",
]


def harvest_repo(repo_root: Path,
                 categories: tuple[str, ...] = HIGH_CONFIDENCE + MEDIUM_CONFIDENCE,
                 excludes: list[str] | None = None,
                 ) -> list[dict]:
    """Walk a repo and return raw findings (with real values) for the
    requested categories.

    `excludes`: list of path-pattern strings (substring or path-part match).
    Defaults to DEFAULT_EXCLUDES; pass [] to scan everything (including
    test fixtures, which on this project would surface synthetic PATs)."""
    repo_root = repo_root.resolve()
    if excludes is None:
        excludes = list(DEFAULT_EXCLUDES)
    findings: list[dict] = []
    file_paths: list[Path] = []
    for p in _secrets._iter_repo_files(repo_root, extra_excludes=excludes):
        if _secrets._is_binary(p):
            continue
        try:
            if p.stat().st_size > _secrets.MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        file_paths.append(p)

    for p in file_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        rel = str(p.relative_to(repo_root))
        for f in harvest_text(text, rel, categories):
            f["repo"] = repo_root.name
            f["path"] = rel
            findings.append(f)

    # XOR obfuscation: when scan_obfuscated_fields would flag the file,
    # capture the right-hand value of each `Obfuscated*` assignment.
    if "xor_obfuscation" in categories:
        # Re-use sca.secrets to know whether decoders exist in this repo.
        decoder_present = False
        for p in file_paths:
            try:
                text = p.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if any(rx.search(text) for rx in _secrets.DECODE_FUNCTION_HINTS):
                decoder_present = True
                break
        if decoder_present:
            for p in file_paths:
                if _secrets._is_template_filename(p):
                    continue
                try:
                    text = p.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                rel = str(p.relative_to(repo_root))
                rel = str(p.relative_to(repo_root))
                if _xor_path_likely_documentation(rel):
                    continue
                for m in _secrets.OBFUSCATED_FIELD_PATTERN.finditer(text):
                    if _secrets._line_value_is_placeholder(text, m.end()):
                        continue
                    line_no = text.count("\n", 0, m.start()) + 1
                    line_text = _line_at(text, m.start())
                    value = _extract_xor_value(line_text)
                    if not value:
                        continue
                    # Drop code/template references that aren't actual values.
                    if _is_template_xor_value(value):
                        continue
                    findings.append({
                        "category": "xor_obfuscation",
                        "severity": "critical",
                        "value": value,
                        "field_name": line_text.strip()[:120],
                        "line": line_no,
                        "context": line_text[:200],
                        "repo": repo_root.name,
                        "path": rel,
                    })

    return findings


# ---------- on-disk inventory ----------

@dataclass
class HarvestEntry:
    id: str
    category: str
    severity: str
    value: str
    context: str = ""
    occurrences: list[dict] = field(default_factory=list)
    field_name: str | None = None

    def asdict(self) -> dict:
        d = {"id": self.id, "category": self.category, "severity": self.severity,
             "value": self.value, "context": self.context,
             "occurrences": self.occurrences}
        if self.field_name:
            d["field_name"] = self.field_name
        return d


def _ensure_out_dir(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    (out / "by-category").mkdir(exist_ok=True)
    (out / "by-repo").mkdir(exist_ok=True)
    # Always (re-)write README + .gitignore so the directory is self-explanatory
    (out / ".gitignore").write_text("*\n!.gitignore\n!README.md\n",
                                    encoding="utf-8")
    (out / "README.md").write_text(
        "# Secret backup -- DO NOT COMMIT\n\n"
        "This directory contains real secret values harvested from the local\n"
        "code workspace. It exists so you have a record of what to rotate\n"
        "after a redaction / history-rewrite pass.\n\n"
        "**Treat this directory like the inside of a vault.**\n\n"
        "* `manifest.json`          index of every unique value\n"
        "* `by-category/<cat>/`     one file per unique value, grouped by category\n"
        "* `by-repo/<name>.json`    all findings for one repo\n\n"
        "After rotation, **delete this directory**.\n",
        encoding="utf-8",
    )


def write_inventory(findings: list[dict], out: Path) -> dict:
    """Deduplicate by value, write per-category and per-repo files,
    return a manifest dict suitable for JSON serialisation."""
    _ensure_out_dir(out)
    by_id: dict[str, HarvestEntry] = {}
    for f in findings:
        value = f["value"]
        fid = _hash_id(value)
        entry = by_id.get(fid)
        if entry is None:
            entry = HarvestEntry(
                id=fid,
                category=f["category"],
                severity=f["severity"],
                value=value,
                context=f.get("context", ""),
                field_name=f.get("field_name"),
            )
            by_id[fid] = entry
        occ = {"repo": f["repo"], "path": f["path"], "line": f["line"]}
        if occ not in entry.occurrences:
            entry.occurrences.append(occ)

    # Write per-id files
    for entry in by_id.values():
        cat_dir = out / "by-category" / entry.category
        cat_dir.mkdir(parents=True, exist_ok=True)
        (cat_dir / f"{entry.id}.json").write_text(
            json.dumps(entry.asdict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    # Per-repo aggregate
    by_repo_map: dict[str, list[dict]] = {}
    for entry in by_id.values():
        for occ in entry.occurrences:
            by_repo_map.setdefault(occ["repo"], []).append({
                "id":       entry.id,
                "category": entry.category,
                "severity": entry.severity,
                "path":     occ["path"],
                "line":     occ["line"],
                "preview":  entry.value[:24] + ("..." if len(entry.value) > 24 else ""),
            })
    for repo, rows in by_repo_map.items():
        rows.sort(key=lambda r: (r["category"], r["path"], r["line"]))
        (out / "by-repo" / f"{_safe_filename(repo)}.json").write_text(
            json.dumps({"repo": repo, "count": len(rows), "findings": rows},
                       indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    # Top-level manifest
    from collections import Counter
    cat_counts = Counter(e.category for e in by_id.values())
    repo_counts = Counter(o["repo"] for e in by_id.values() for o in e.occurrences)
    manifest = {
        "schema_version": 1,
        "generator":      "sca harvest",
        "generated_at":   __import__("datetime").datetime.now()
                          .isoformat(timespec="seconds"),
        "unique_values":  len(by_id),
        "total_findings": sum(len(e.occurrences) for e in by_id.values()),
        "by_category":    dict(cat_counts),
        "by_repo":        dict(repo_counts),
    }
    (out / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return manifest


# ---------- CLI ----------

def _find_repos(root: Path) -> list[Path]:
    if (root / ".git").is_dir():
        return [root]
    out: list[Path] = []
    for dirpath, dirnames, _ in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        if len(rel.parts) > 3:
            dirnames[:] = []
            continue
        if any(part in {".git", ".archive", ".claude", "temp",
                          "secrets", "sca-final-report"}
               or part.startswith("sca-run-")
               for part in rel.parts):
            dirnames[:] = []
            continue
        if ".git" in dirnames:
            out.append(Path(dirpath))
            dirnames.remove(".git")
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Harvest unique secret values to disk.")
    ap.add_argument("--root", default=os.environ.get("CODE_ROOT", os.getcwd()))
    ap.add_argument("--out", default=str(Path(os.environ.get("CODE_ROOT", "C:/code")) / "secrets"))
    ap.add_argument("--categories", default="high+medium",
                    choices=("high", "high+medium", "all"),
                    help="Confidence tiers to harvest. high = live tokens "
                         "+ xor; medium also adds GUIDs and SharePoint URLs; "
                         "all also adds password_assignment (lots of FPs).")
    ap.add_argument("--exclude", action="append", default=None, metavar="PATTERN",
                    help="Path pattern to skip (repeatable). Default exclude list: "
                         + ", ".join(DEFAULT_EXCLUDES) +
                         ". Pass --exclude '' once to clear the defaults.")
    ap.add_argument("--include-tests", action="store_true",
                    help="Don't skip 'tests' / 'fixtures' / etc. -- harvest EVERYTHING. "
                         "Will surface synthetic test PATs as findings.")
    args = ap.parse_args(argv)

    if args.categories == "high":
        cats = HIGH_CONFIDENCE
    elif args.categories == "all":
        cats = HIGH_CONFIDENCE + MEDIUM_CONFIDENCE + LOW_CONFIDENCE
    else:
        cats = HIGH_CONFIDENCE + MEDIUM_CONFIDENCE

    if args.include_tests:
        excludes: list[str] = []
    elif args.exclude is not None:
        # User passed at least one --exclude. Treat their list as authoritative
        # (allows them to clear the defaults via `--exclude ''`).
        excludes = [e for e in args.exclude if e]
    else:
        excludes = list(DEFAULT_EXCLUDES)

    root = Path(args.root).resolve()
    out  = Path(args.out).resolve()
    repos = _find_repos(root)
    print(f"[harvest] {len(repos)} repo(s) under {root}", file=sys.stderr)
    print(f"[harvest] categories: {', '.join(cats)}", file=sys.stderr)
    print(f"[harvest] excludes:   {excludes or '(none)'}", file=sys.stderr)

    all_findings: list[dict] = []
    for r in repos:
        findings = harvest_repo(r, categories=cats, excludes=excludes)
        if findings:
            print(f"  {r.name:40s} {len(findings)} finding(s)", file=sys.stderr)
        all_findings.extend(findings)

    if not all_findings:
        print("[harvest] no findings to write.", file=sys.stderr)
        return 0

    manifest = write_inventory(all_findings, out)
    print("", file=sys.stderr)
    print(f"[harvest] wrote {manifest['unique_values']} unique value(s) "
          f"({manifest['total_findings']} total occurrences)", file=sys.stderr)
    print(f"[harvest] backup at: {out}", file=sys.stderr)
    print("", file=sys.stderr)
    print("By category:", file=sys.stderr)
    for cat, n in sorted(manifest["by_category"].items(), key=lambda kv: -kv[1]):
        print(f"  {cat:30s} {n}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
