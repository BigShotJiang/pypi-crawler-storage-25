"""
Built-in inference metrics available via --metric on the inference command.
"""

from collections.abc import Callable, Iterable
from enum import Enum
from typing import Any

import numpy as np

from ai_parade._toolkit.data.output import ModelOutput

MetricFn = Callable[[Iterable[ModelOutput], Iterable[ModelOutput]], Any]


class Metric(str, Enum):
	top1 = "top1"
	top5 = "top5"


def _imagenet_top_k(k: int) -> MetricFn:
	def metric(
		predictions: Iterable[ModelOutput], references: Iterable[ModelOutput]
	) -> float:
		from sklearn.metrics import top_k_accuracy_score
		preds = list(predictions)
		refs = list(references)
		return top_k_accuracy_score(
			np.array([x["class_ImageNet1k"] for x in refs]),
			np.array([x["class_ImageNet1k_logit"] for x in preds]),
			k=k,
			labels=range(1000),
		)

	return metric


def _resolve(metric: Metric) -> MetricFn:
	match metric:
		case Metric.top1:
			return _imagenet_top_k(1)
		case Metric.top5:
			return _imagenet_top_k(5)


def build_metrics(metrics: list[Metric]) -> dict[str, MetricFn]:
	"""Resolve selected Metric enum values to a metrics dict for the inference() function."""
	return {m.value: _resolve(m) for m in metrics}
