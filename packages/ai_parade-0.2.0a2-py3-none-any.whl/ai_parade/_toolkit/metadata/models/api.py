from pathlib import Path
from typing import TYPE_CHECKING, Callable

from ai_parade._toolkit.enums.formats import ExactModelFormat
from ai_parade._toolkit.run.ModelRunner import ModelRunner

from .pyproject import ModelMetadataPyproject, PyTorchOptionsPyproject

if TYPE_CHECKING:
	# its circular import, but we need it only for types and we could split the models
	from .final import ModelMetadata

RunnerGetter = Callable[["ModelMetadata", Path], ModelRunner]


class ModelMetadataApi(ModelMetadataPyproject):
	"""
	Api definition of model metadata (registration).
	"""

	get_custom_runner: RunnerGetter | None = None
	"""
	Uninitialized type of the runner

	The getter function which returns ModelRunner instance from ModelMetadata and weights path.

	None (default) will use default runner for given format
	"""

	position_in_family: float  # type: ignore redefinition with un-optional type

	format: ExactModelFormat  # type: ignore redefinition with exact format


PyTorchOptionsApi = PyTorchOptionsPyproject
"""
Api definition of pytorch options 
"""
