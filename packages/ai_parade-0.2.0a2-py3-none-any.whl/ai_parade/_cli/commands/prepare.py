import asyncio
import logging
import re
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import tomllib
import typer

from ai_parade._toolkit.constants import get_lock_path
from ai_parade._toolkit.downloader import download
from ai_parade.toolkit import get_local_metadata

from .._shared import FEATURE_SETS, ExitCode
from ._common import (
	ModelNameType,
	RepositoryPathType,
	VerboseType,
	WeightsPathType,
	app,
)

logger = logging.getLogger(__name__)

prepare_app = typer.Typer()
app.add_typer(prepare_app, name="prepare", help="Prepare a model.")


def _python_from_lock(lock_path: Path) -> str:
	with open(lock_path, "rb") as f:
		req = tomllib.load(f).get("requires-python", "")
	m = re.search(r"(\d+\.\d+)", req)
	if not m:
		raise ValueError(
			f"Lock file {lock_path} has no parseable requires-python field."
		)
	return m.group(1)


def _venv_python_matches(venv_path: Path, expected: str) -> bool:
	cfg = venv_path / "pyvenv.cfg"
	if not cfg.exists():
		return False
	for line in cfg.read_text().splitlines():
		if line.startswith("version = ") or line.startswith("version_info = "):
			return line.split(" = ", 1)[1].strip().startswith(expected)
	return False


@prepare_app.command("weights")
def prepare_weights(
	model_name: ModelNameType,
	weights_path: WeightsPathType = Path("build"),
	repository_path: RepositoryPathType = Path("."),
	token_path: Path = Path(".ai_parade/gdrive_credentials.json"),
	train_dataset: str | None = None,
	verbose: VerboseType = [],
):
	"""
	Download model weights.
	"""
	metadata_list = asyncio.run(get_local_metadata(repository_path))
	metadata = next(x for x in metadata_list if x.name == model_name)
	assert metadata.download_link is not None
	if isinstance(metadata.download_link, str):
		if train_dataset is not None:
			logger.warning(
				f"Model has only one download link without specified dataset name, using it. Dataset: {train_dataset}"
			)
		link = metadata.download_link
	else:
		if train_dataset is not None:
			link = metadata.download_link[train_dataset]
		else:
			link = next(iter(metadata.download_link.values()))
	logger.info(f"Downloading model from {link}")
	asyncio.run(download(link, weights_path, token_path))
	logger.info(f"Model downloaded to {weights_path}")


@prepare_app.command("venv")
def prepare_venv(
	feature_set: Annotated[
		str | None,
		typer.Argument(
			help=f"Feature set to install. One of: {', '.join(FEATURE_SETS)}. Required unless --lockfile is given."
		),
	] = None,
	venv_path: Annotated[
		Path,
		typer.Option("--venv", help="Path to the virtual environment."),
	] = Path(".ai-parade-venv"),
	lockfile: Annotated[
		Path | None,
		typer.Option(
			"--lockfile",
			help="Override the lock file. Defaults to the repository lock for the given feature set.",
			exists=True,
			resolve_path=True,
		),
	] = None,
	resolution: Annotated[
		str | None,
		typer.Option(
			"--resolution",
			help="Dependency resolution variant (e.g. highest, lowest-direct). Ignored when --lockfile is given.",
		),
	] = None,
	repository_path: RepositoryPathType = Path("."),
	verbose: VerboseType = [],
):
	"""
	Create or sync a virtual environment from a lock file.
	"""
	if lockfile is not None:
		lock_path = lockfile
	elif feature_set is not None:
		local_lock = get_lock_path(
			repository_path, feature_set, resolution, local_platform=True
		)
		if local_lock.exists():
			logger.debug(f"Using current-platform lock: {local_lock}")
			lock_path = local_lock
		else:
			if sys.platform != "linux":
				logger.warning(
					f"No lock for the current platform ({sys.platform}); "
					"falling back to Linux lock which may be incompatible."
				)
			lock_path = get_lock_path(repository_path, feature_set, resolution)
	else:
		raise typer.BadParameter("Provide either FEATURE_SET or --lockfile.")

	if not lock_path.exists():
		logger.error(f"Lock file not found: {lock_path}")
		raise typer.Exit(code=ExitCode.NO_LOCK)

	python_version = _python_from_lock(lock_path)
	logger.debug(f"Lock requires Python {python_version}")

	if not _venv_python_matches(venv_path, python_version):
		logger.info(f"Creating venv at {venv_path} with Python {python_version}")
		subprocess.run(
			[
				"uv",
				"venv",
				"--relocatable",
				"--python",
				python_version,
				str(venv_path),
				"--clear",
			],
			check=True,
		)

	logger.info(f"Syncing {lock_path} into {venv_path}")
	subprocess.run(
		["uv", "pip", "sync", str(lock_path), "--python", str(venv_path)],
		check=True,
	)


@prepare_app.command("all")
def prepare_all(
	model_name: ModelNameType,
	feature_set: Annotated[
		str,
		typer.Argument(
			help=f"Feature set to install. One of: {', '.join(FEATURE_SETS)}."
		),
	],
	repository_path: RepositoryPathType = Path("."),
	verbose: VerboseType = [],
):
	"""
	[Unstable]
	Download model weights and prepare the virtual environment.
	"""
	prepare_weights(
		model_name=model_name,
		repository_path=repository_path,
		verbose=verbose,
	)
	prepare_venv(
		feature_set=feature_set,
		repository_path=repository_path,
		verbose=verbose,
	)
