import asyncio
import json
from pathlib import Path
from typing import Annotated

import typer

from ai_parade._toolkit.constants import get_metadata_cache
from ai_parade._toolkit.metadata.models.final import ModelMetadata
from ai_parade._toolkit.metadata.parsing import get_local_metadata
from ai_parade._toolkit.run.runner_selector import get_runner

from ._common import RepositoryPathType, VerboseType, app


def _serialize_metadata(metadata: ModelMetadata) -> dict:
	return metadata.model_dump(mode="json", exclude_none=True, exclude={"repository_path"})


def _write_metadata(path: Path, metadata_list: list[ModelMetadata]) -> None:
	with open(path, "w") as f:
		json.dump([_serialize_metadata(m) for m in metadata_list], f, indent=4)


@app.command()
def ls(
	repository: RepositoryPathType = Path("."),
	print_metadata: Annotated[
		bool,
		typer.Option(
			"--print",
			help="If set to True, print full metadata for each model. "
			"Otherwise, only model names will be printed. "
		),
	] = False,
	skip_cache: Annotated[
		bool,
		typer.Option(
			help="If set to True, all models will be reloaded and size will be recalculated (if required)."
		),
	] = False,
	include_size: Annotated[
		bool,
		typer.Option(
			help="If set to True, size of each model will be included in the metadata."
		),
	] = False,
	output_file: Annotated[
		Path | None,
		typer.Option(
			"--output", "-o",
			help="Path to the output file where the list of models will be saved."
		),
	] = None,
	verbose: VerboseType = [],
):
	"""
	List all available models in the repository.
	"""
	cache_file = get_metadata_cache(repository)
	if skip_cache or not cache_file.exists():
		metadata_list = asyncio.run(get_local_metadata(repository))
		cache_file.parent.mkdir(parents=True, exist_ok=True)
		_write_metadata(cache_file, metadata_list)
	else:
		with open(cache_file, "r") as f:
			metadata_list = [ModelMetadata(**d) for d in json.load(f)]

	# compute sizes if needed, and update cache
	assert len(metadata_list) > 0
	if include_size and metadata_list[0].real_size is None:
		for model in metadata_list:
			model.real_size = asyncio.run(get_runner(model, Path()).get_model_size())
		_write_metadata(cache_file, metadata_list)

	if output_file:
		_write_metadata(output_file, metadata_list)

	if print_metadata:
		print(json.dumps([_serialize_metadata(m) for m in metadata_list], indent=4))
	else:
		print(
			"Models metadata parsed:\n\t" + "\n\t".join(m.name for m in metadata_list),
			flush=True,
		)
