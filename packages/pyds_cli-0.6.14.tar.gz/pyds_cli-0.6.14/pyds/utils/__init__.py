"""Utility functions for pyds."""

import os
import subprocess
from pathlib import Path
from typing import Dict, Optional, Tuple

import ruamel.yaml
from pyprojroot import here
from rich.console import Console
from sh import which

console = Console()
ANACONDA = os.getenv("anaconda", os.getenv("CONDA_PREFIX"))


def read_config():
    """Read PyDS configuration file.

    The PyDS configuration file is always located in the home directory
    and has the name `.pyds.yaml`.

    :returns: A dictionary of PyDS configurations.
    :raises FileNotFoundError: when the pyds config file cannot be found.
    """
    try:
        config_path = Path.home() / ".pyds.yaml"
        yaml = ruamel.yaml.YAML()  # defaults to round-trip

        with config_path.open("r+") as f:
            return yaml.load(f.read())
    except FileNotFoundError:
        raise FileNotFoundError("❗️Please run `pyds configure` to configure pyds!")


# def run(
#     cmd: str,
#     cwd=Path("."),
#     shell: bool = True,
#     capture_output: bool = True,
#     log: bool = True,
#     show_out: bool = False,
#     activate_env=False,
# ):
#     """Convenience function to run a shell command while also logging the command.

#     :param cmd: The command to run.
#     :param cwd: The working directory in which to run the code.
#     :param shell: Passed to `subprocess.run`'s `shell` argument.
#     :param capture_output: Passed to `subprocess.run`'s `capture_output` argument.
#     :param log: Whether or not to log the command to screen.
#     :param show_out: Whether or not to show the output of `cmd` to the terminal.
#     :param activate_env: Whether or not to activate
#         the project's conda environment or not before running the command.
#         Defaults to False.
#     :returns: The result of `subprocess.run`.
#     """
#     if activate_env:
#         env = get_conda_env_name()
#         cmd = f"bash -c 'source activate {env} && {cmd}'"
#     else:
#         cmd = f"bash -c 'source activate base && {cmd}'"
#     if log:
#         logger.info(f"+ {cmd}")

#     run_kwargs = {
#         "cwd": cwd,
#         "shell": shell,
#     }

#     if show_out:
#         run_kwargs["stdout"] = subprocess.PIPE
#     else:
#         run_kwargs["capture_output"] = capture_output
#     out = subprocess.run(
#         cmd,
#         **run_kwargs,
#     )
#     return out


def read_conda_env(env_file="environment.yml", cwd: Path = Path(".")) -> Dict:
    """Load `environment.yml` as a dictionary.

    We try loading from the specified working directory first.
    Otherwise, we use pyprojroot to find the `environment.yml` file.
    If both fail, we raise a loud error.

    :param env_file: The name of the environment file to use.
    :param cwd: The directory in which to look for the environment file.
    :raises NameError: If we are unable to find the environment.yml file.
    :returns: Dictionary containing the conda configuration.
    """
    yaml = ruamel.yaml.YAML()  # defaults to round-trip

    try:
        with open(cwd / env_file, "r+") as f:
            return yaml.load(f.read())
    except FileNotFoundError:
        pass

    try:
        with open(here() / env_file, "r+") as f:
            return yaml.load(f.read())
    except RecursionError:
        pass

    raise NameError(
        "❗️Unable to find environment.yml. Are you inside a project directory?"
    )


def get_conda_env_name(env_file="environment.yml", cwd: Path = Path(".")):
    """Get conda environment name from the environment specification file.

    This function can be executed from anywhere _within_ a project directory.

    We search for `environment.yml` by default.

    :param env_file: Name of the environment file.
    :param cwd: Where to begin recursive search of the project root directory.
    :returns: The environment name.
    """
    env = read_conda_env(env_file=env_file, cwd=cwd)
    return env["name"]


def get_env_bin_dir(env_file="environment.yml", cwd: Path = Path(".")):
    """Get the environment bin directory.

    Used to identify the absolute path to an environment's executables.

    :param env_file: Name of the environment file
        from which we look for the environment name.
    :param cwd: Where to begin recursive search of the project root directory.
    :returns: Path to the conda environment's `bin` directory.
    """
    env_name = get_conda_env_name(env_file=env_file, cwd=cwd)
    ENV_BIN_DIR = f"{ANACONDA}/envs/{env_name}/bin"
    return ENV_BIN_DIR


def discover_conda_executable() -> Path:
    """Discover the conda executable.

    I intend to expand this function
    with other ways of getting the `conda_exe` programmatically.

    :raises Exception: If we cannot find a path to a conda executable.
    :returns: Path to the conda or mamba executable.
    """
    # First, try mamba
    try:
        return Path(str(which("mamba")).strip())
    except Exception:
        pass

    try:
        return Path(str(which("micromamba")).strip())
    except Exception:
        pass

    try:
        return Path(str(which("conda")).strip())
    except Exception:
        pass

    # If which fails, try using environment variables.
    conda_exe = os.getenv("CONDA_EXE")
    if conda_exe is not None:
        return Path(conda_exe)

    raise Exception("Could not find conda executable! Do you have `conda` installed?")


PIXI_EXE = str(which("pixi")).strip()


def is_gh_installed() -> bool:
    """Check if the gh CLI is installed."""
    try:
        result = subprocess.run(
            ["gh", "--version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def is_gh_authenticated() -> bool:
    """Check if the gh CLI is authenticated."""
    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def create_github_repo(
    repo_name: str, description: str, private: bool = False
) -> Tuple[bool, Optional[str]]:
    """Create a GitHub repository using the gh CLI.

    :param repo_name: Name of the repository to create.
    :param description: Description for the repository.
    :param private: Whether to create a private repository.
    :returns: Tuple of (success, message).
    """
    try:
        visibility = "--private" if private else "--public"
        result = subprocess.run(
            [
                "gh",
                "repo",
                "create",
                repo_name,
                "--description",
                description,
                visibility,
                "--source",
                ".",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return True, None
        else:
            return False, result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        return False, str(e)
