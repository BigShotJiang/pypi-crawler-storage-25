"""
Spotify API wrapper: search, playlist operations, batching.
Author: David
Date: 2026-03-22
Version: 0.1.0
"""

from __future__ import annotations

import logging
import math
import time

import spotipy
from tqdm import tqdm
from spotipy.oauth2 import SpotifyOAuth

from playlist_sync.config import (
    SEARCH_DELAY_SEC,
    SPOTIFY_PLAYLIST_BATCH,
    SPOTIFY_SEARCH_LIMIT,
)

logger = logging.getLogger("playlist_sync")


def get_spotify_client(config: dict[str, str]) -> spotipy.Spotify:
    """Create an authenticated Spotify client."""
    scope = "playlist-modify-public playlist-modify-private playlist-read-private"
    auth_manager = SpotifyOAuth(
        client_id=config["SPOTIPY_CLIENT_ID"],
        client_secret=config["SPOTIPY_CLIENT_SECRET"],
        redirect_uri=config["SPOTIPY_REDIRECT_URI"],
        scope=scope,
    )
    sp = spotipy.Spotify(auth_manager=auth_manager, requests_timeout=30, retries=3)

    user = sp.current_user()
    logger.info("Authenticated as Spotify user: %s", user.get("display_name", user["id"]))
    return sp


class RateLimitError(Exception):
    """Raised when Spotify rate limit is hit and retry wait is too long."""
    def __init__(self, retry_after: int):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after}s")


def _handle_rate_limit(e: spotipy.SpotifyException) -> None:
    """Handle 429 rate limit errors with short backoff or raise if too long."""
    retry_after = int(e.headers.get("Retry-After", 60)) if e.headers else 60

    if retry_after <= 120:
        # Manageable wait — just pause and retry
        logger.warning("Rate limited, waiting %ds...", retry_after)
        time.sleep(retry_after + 1)
    else:
        # Multi-hour wait — save progress and stop
        raise RateLimitError(retry_after)


def search_track(
    sp: spotipy.Spotify,
    query: str,
    limit: int = SPOTIFY_SEARCH_LIMIT,
) -> list[dict]:
    """Search Spotify for tracks. Returns list of track dicts."""
    if not query.strip():
        return []

    time.sleep(SEARCH_DELAY_SEC)

    for attempt in range(3):
        try:
            results = sp.search(q=query, type="track", limit=limit)
            items = results.get("tracks", {}).get("items", [])
            logger.debug("Search '%s' -> %d results", query[:60], len(items))
            return items
        except spotipy.SpotifyException as e:
            if e.http_status == 429:
                _handle_rate_limit(e)
                continue
            logger.warning("Spotify search failed for '%s': %s", query[:60], e)
            return []

    return []


def search_by_isrc(sp: spotipy.Spotify, isrc: str) -> list[dict]:
    """Search Spotify by ISRC code."""
    return search_track(sp, f"isrc:{isrc}", limit=1)


def get_track_details(sp: spotipy.Spotify, track_id: str) -> dict | None:
    """Get full track details including external_ids (ISRC)."""
    try:
        return sp.track(track_id)
    except spotipy.SpotifyException as e:
        logger.warning("Failed to get track details for %s: %s", track_id, e)
        return None


def get_playlist_tracks(sp: spotipy.Spotify, playlist_id: str) -> list[dict]:
    """Fetch all tracks from a Spotify playlist (handles pagination)."""
    tracks: list[dict] = []
    results = sp.playlist_tracks(playlist_id)

    while results:
        for item in results.get("items", []):
            track = item.get("track")
            if track:
                tracks.append(track)

        if results.get("next"):
            results = sp.next(results)
        else:
            break

    logger.info("Fetched %d tracks from Spotify playlist %s", len(tracks), playlist_id)
    return tracks


def get_tracks_batch(
    sp: spotipy.Spotify,
    track_ids: list[str],
) -> dict[str, dict]:
    """Fetch full track objects for multiple tracks in batches of 50.

    Returns {track_id: track_dict} for successfully fetched tracks.
    Uses the /tracks endpoint which supports up to 50 IDs per call.
    Stops early if the endpoint returns 403 (restricted in Dev Mode).
    """
    results: dict[str, dict] = {}
    total_batches = math.ceil(len(track_ids) / 50)
    consecutive_403s = 0

    for i in tqdm(range(0, len(track_ids), 50), desc="Metadata", unit="batch", total=total_batches):
        batch = track_ids[i:i + 50]
        time.sleep(SEARCH_DELAY_SEC)
        try:
            response = sp.tracks(batch)
            for track in response.get("tracks", []):
                if track:
                    results[track["id"]] = track
            consecutive_403s = 0
        except spotipy.SpotifyException as e:
            if e.http_status == 403:
                consecutive_403s += 1
                if consecutive_403s >= 3:
                    logger.warning(
                        "/tracks endpoint returned 403 three times in a row. "
                        "Spotify has restricted this endpoint for your app type. Skipping."
                    )
                    break
            elif e.http_status == 429:
                consecutive_403s = 0
                _handle_rate_limit(e)
                try:
                    response = sp.tracks(batch)
                    for track in response.get("tracks", []):
                        if track:
                            results[track["id"]] = track
                except spotipy.SpotifyException:
                    logger.warning("Failed to fetch tracks batch at offset %d after retry", i)
            else:
                consecutive_403s = 0
                logger.warning("Failed to fetch tracks batch at offset %d: %s", i, e)

    logger.info("Fetched metadata for %d/%d tracks", len(results), len(track_ids))
    return results


def get_artists_batch(
    sp: spotipy.Spotify,
    artist_ids: list[str],
) -> dict[str, dict]:
    """Fetch artist objects in batches of 50. Returns {artist_id: artist_dict}.

    Each artist dict includes 'genres' (list of strings) and other metadata.
    """
    results: dict[str, dict] = {}
    total_batches = math.ceil(len(artist_ids) / 50)
    consecutive_403s = 0

    for i in tqdm(range(0, len(artist_ids), 50), desc="Artists", unit="batch", total=total_batches):
        batch = artist_ids[i:i + 50]
        time.sleep(SEARCH_DELAY_SEC)
        try:
            response = sp.artists(batch)
            for artist in response.get("artists", []):
                if artist:
                    results[artist["id"]] = artist
            consecutive_403s = 0
        except spotipy.SpotifyException as e:
            if e.http_status == 403:
                consecutive_403s += 1
                if consecutive_403s >= 3:
                    logger.warning(
                        "/artists endpoint returned 403 three times in a row. "
                        "Spotify has restricted this endpoint for your app type. Skipping."
                    )
                    break
            elif e.http_status == 429:
                consecutive_403s = 0
                _handle_rate_limit(e)
                try:
                    response = sp.artists(batch)
                    for artist in response.get("artists", []):
                        if artist:
                            results[artist["id"]] = artist
                except spotipy.SpotifyException:
                    logger.warning("Failed to fetch artists batch at offset %d after retry", i)
            else:
                consecutive_403s = 0
                logger.warning("Failed to fetch artists batch at offset %d: %s", i, e)

    logger.info("Fetched genre data for %d/%d artists", len(results), len(artist_ids))
    return results


def get_audio_features_batch(
    sp: spotipy.Spotify,
    track_ids: list[str],
) -> dict[str, dict]:
    """Fetch audio features for multiple tracks. Returns {track_id: features}.

    Uses the single-track endpoint since GET /audio-features (batch) was
    removed in Feb 2026. Rate-limited to avoid 429s.

    If the endpoint returns 403 (access removed for this app type), logs a
    warning and returns an empty dict immediately rather than retrying for
    every track.
    """
    features: dict[str, dict] = {}
    consecutive_403s = 0

    for track_id in tqdm(track_ids, desc="Audio features", unit="track"):
        time.sleep(SEARCH_DELAY_SEC)
        try:
            result = sp.audio_features([track_id])
            if result and result[0]:
                features[track_id] = result[0]
                logger.debug("Audio features for %s: tempo=%.1f, energy=%.2f",
                             track_id, result[0].get("tempo", 0), result[0].get("energy", 0))
            consecutive_403s = 0
        except spotipy.SpotifyException as e:
            if e.http_status == 403:
                consecutive_403s += 1
                if consecutive_403s >= 3:
                    logger.warning(
                        "Audio features endpoint returned 403 three times in a row. "
                        "Spotify has restricted this endpoint for your app type. Skipping."
                    )
                    break
            else:
                consecutive_403s = 0
            logger.warning("Failed to get audio features for %s: %s", track_id, e)

    logger.info("Fetched audio features for %d/%d tracks", len(features), len(track_ids))
    return features


def add_tracks_to_playlist(
    sp: spotipy.Spotify,
    playlist_id: str,
    uris: list[str],
    dry_run: bool = False,
) -> int:
    """Add tracks to Spotify playlist in batches of 100."""
    if not uris:
        return 0

    if dry_run:
        logger.info("[DRY RUN] Would add %d tracks to playlist", len(uris))
        return len(uris)

    added = 0
    for i in range(0, len(uris), SPOTIFY_PLAYLIST_BATCH):
        batch = uris[i:i + SPOTIFY_PLAYLIST_BATCH]
        try:
            sp.playlist_add_items(playlist_id, batch)
            added += len(batch)
            logger.debug("Added batch of %d tracks (%d/%d)", len(batch), added, len(uris))
        except spotipy.SpotifyException as e:
            logger.error("Failed to add batch at offset %d: %s", i, e)

    logger.info("Added %d/%d tracks to Spotify playlist", added, len(uris))
    return added


def remove_tracks_from_playlist(
    sp: spotipy.Spotify,
    playlist_id: str,
    uris: list[str],
    dry_run: bool = False,
) -> int:
    """Remove tracks from Spotify playlist in batches of 100."""
    if not uris:
        return 0

    if dry_run:
        logger.info("[DRY RUN] Would remove %d tracks from playlist", len(uris))
        return len(uris)

    removed = 0
    for i in range(0, len(uris), SPOTIFY_PLAYLIST_BATCH):
        batch = uris[i:i + SPOTIFY_PLAYLIST_BATCH]
        try:
            sp.playlist_remove_all_occurrences_of_items(playlist_id, batch)
            removed += len(batch)
            logger.debug("Removed batch of %d tracks (%d/%d)", len(batch), removed, len(uris))
        except spotipy.SpotifyException as e:
            logger.error("Failed to remove batch at offset %d: %s", i, e)

    logger.info("Removed %d/%d tracks from Spotify playlist", removed, len(uris))
    return removed
