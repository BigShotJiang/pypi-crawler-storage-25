"""Configuration module"""
