"""Authentication module for TzamunCode"""
