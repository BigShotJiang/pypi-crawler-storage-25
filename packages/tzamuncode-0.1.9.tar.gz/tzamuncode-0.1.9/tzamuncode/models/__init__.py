"""Models module for AI backends"""
