"""MCP client for connecting to MCP servers and executing tools."""

import json
import subprocess
from typing import Dict, List, Any, Optional


class MCPClient:
    """Client for interacting with MCP servers."""
    
    def __init__(self, server_command: str):
        """
        Initialize MCP client.
        
        Args:
            server_command: Command to start the MCP server (e.g., 'paperclip-mcp-server')
        """
        self.server_command = server_command
        self.tools: List[Dict[str, Any]] = []
        self.process: Optional[subprocess.Popen] = None
        
    def connect(self) -> bool:
        """
        Connect to the MCP server and discover available tools.
        
        Returns:
            True if connection successful, False otherwise
        """
        try:
            # Start the MCP server process
            self.process = subprocess.Popen(
                [self.server_command],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            # Send initialize request
            init_request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {},
                    "clientInfo": {
                        "name": "tzamuncode",
                        "version": "0.1.5"
                    }
                }
            }
            
            self._send_request(init_request)
            init_response = self._read_response()
            
            if not init_response or "error" in init_response:
                return False
            
            # Send initialized notification
            initialized_notification = {
                "jsonrpc": "2.0",
                "method": "notifications/initialized"
            }
            self._send_request(initialized_notification)
            
            # List available tools
            tools_request = {
                "jsonrpc": "2.0",
                "id": 2,
                "method": "tools/list"
            }
            
            self._send_request(tools_request)
            tools_response = self._read_response()
            
            if tools_response and "result" in tools_response:
                self.tools = tools_response["result"].get("tools", [])
                return True
            
            return False
            
        except Exception as e:
            print(f"Error connecting to MCP server: {e}")
            return False
    
    def get_tools(self) -> List[Dict[str, Any]]:
        """
        Get list of available tools.
        
        Returns:
            List of tool definitions
        """
        return self.tools
    
    def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Call a tool on the MCP server.
        
        Args:
            tool_name: Name of the tool to call
            arguments: Tool arguments
            
        Returns:
            Tool execution result
        """
        try:
            request = {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                }
            }
            
            self._send_request(request)
            response = self._read_response()
            
            if response and "result" in response:
                return response["result"]
            elif response and "error" in response:
                return {"error": response["error"]}
            else:
                return {"error": "No response from server"}
                
        except Exception as e:
            return {"error": str(e)}
    
    def disconnect(self):
        """Disconnect from the MCP server."""
        if self.process:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except:
                self.process.kill()
            self.process = None
    
    def _send_request(self, request: Dict[str, Any]):
        """Send a JSON-RPC request to the server."""
        if self.process and self.process.stdin:
            request_str = json.dumps(request) + "\n"
            self.process.stdin.write(request_str)
            self.process.stdin.flush()
    
    def _read_response(self) -> Optional[Dict[str, Any]]:
        """Read a JSON-RPC response from the server."""
        if self.process and self.process.stdout:
            try:
                line = self.process.stdout.readline()
                if line:
                    return json.loads(line)
            except json.JSONDecodeError:
                pass
        return None
    
    def format_tools_for_prompt(self) -> str:
        """
        Format tools as a string for inclusion in AI prompt.
        
        Returns:
            Formatted tools description
        """
        if not self.tools:
            return ""
        
        tools_text = "\n\nYou have access to the following tools:\n\n"
        
        for tool in self.tools:
            name = tool.get("name", "unknown")
            description = tool.get("description", "")
            input_schema = tool.get("inputSchema", {})
            properties = input_schema.get("properties", {})
            required = input_schema.get("required", [])
            
            tools_text += f"**{name}**\n"
            tools_text += f"Description: {description}\n"
            
            if properties:
                tools_text += "Parameters:\n"
                for param_name, param_info in properties.items():
                    param_type = param_info.get("type", "string")
                    param_desc = param_info.get("description", "")
                    is_required = " (required)" if param_name in required else " (optional)"
                    tools_text += f"  - {param_name} ({param_type}){is_required}: {param_desc}\n"
            
            tools_text += "\n"
        
        tools_text += """
To use a tool, respond with a JSON object in this format:
{
  "tool": "tool_name",
  "arguments": {
    "param1": "value1",
    "param2": "value2"
  }
}

After I execute the tool, I will provide you with the result, and you can continue your response.
"""
        
        return tools_text
    
    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()
