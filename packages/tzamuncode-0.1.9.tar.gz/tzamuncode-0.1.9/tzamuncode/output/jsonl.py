"""JSONL output formatter for Paperclip integration."""

import json
import sys
import uuid


class JSONLOutput:
    """Outputs events in JSONL format for Paperclip to parse."""
    
    def __init__(self):
        self.session_id = str(uuid.uuid4())
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.messages = []
    
    def emit(self, event: dict):
        """Emit a JSONL event to stdout."""
        print(json.dumps(event), flush=True)
    
    def session_started(self, model: str, backend: str):
        """Emit session started event."""
        self.emit({
            "type": "session.started",
            "session_id": self.session_id,
            "model": model,
            "backend": backend
        })
    
    def message(self, content: str):
        """Emit a message event."""
        self.messages.append(content)
        self.emit({
            "type": "message",
            "role": "assistant",
            "content": content
        })
    
    def tool_call(self, tool: str, arguments: dict):
        """Emit a tool call event."""
        self.emit({
            "type": "tool.call",
            "tool": tool,
            "arguments": arguments
        })
    
    def tool_result(self, tool: str, result: dict):
        """Emit a tool result event."""
        self.emit({
            "type": "tool.result",
            "tool": tool,
            "result": result
        })
    
    def usage(self, input_tokens: int, output_tokens: int):
        """Emit a usage event."""
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.emit({
            "type": "usage",
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cached_input_tokens": 0
        })
    
    def error(self, message: str, code: str = "unknown"):
        """Emit an error event."""
        self.emit({
            "type": "error",
            "message": message,
            "code": code
        })
    
    def result(self, summary: str = None):
        """Emit final result event."""
        self.emit({
            "type": "result",
            "session_id": self.session_id,
            "summary": summary or "\n\n".join(self.messages),
            "total_cost_usd": 0.0,
            "usage": {
                "input_tokens": self.total_input_tokens,
                "output_tokens": self.total_output_tokens,
                "cached_input_tokens": 0
            }
        })
