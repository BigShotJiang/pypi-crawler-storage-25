"""Output formatters for TzamunCode CLI."""
