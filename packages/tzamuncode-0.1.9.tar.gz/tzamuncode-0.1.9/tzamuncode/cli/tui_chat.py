"""
TUI Chat Interface for TzamunCode
Built with Textual for a Claude Code-like experience
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Header, Footer, Static, Input, RichLog
from textual.binding import Binding
from textual import events
from rich.text import Text
from rich.panel import Panel
from rich.table import Table
from typing import Optional

from ..models.ollama import OllamaClient


class CommandMenu(Static):
    """Popup menu for slash commands"""
    
    COMMANDS = {
        '/help': 'Show available commands',
        '/models': 'List and switch models',
        '/settings': 'Show settings',
        '/clear': 'Clear conversation history',
        '/exit': 'Exit chat',
    }
    
    def compose(self) -> ComposeResult:
        table = Table(title="Available Commands", border_style="cyan")
        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Description", style="white")
        
        for cmd, desc in self.COMMANDS.items():
            table.add_row(cmd, desc)
        
        yield Static(table)


class ShortcutsMenu(Static):
    """Popup menu for keyboard shortcuts"""
    
    def compose(self) -> ComposeResult:
        table = Table(title="Keyboard Shortcuts", border_style="blue")
        table.add_column("Key", style="cyan", no_wrap=True)
        table.add_column("Action", style="white")
        
        table.add_row("Ctrl+C", "Exit chat")
        table.add_row("Ctrl+L", "Clear screen")
        table.add_row("/", "Show commands")
        table.add_row("?", "Show this help")
        
        yield Static(table)


class ChatMessage(Static):
    """A single chat message"""
    
    def __init__(self, role: str, content: str, **kwargs):
        super().__init__(**kwargs)
        self.role = role
        self.content = content
    
    def render(self) -> Text:
        if self.role == "user":
            return Text(f"You › {self.content}", style="bold green")
        else:
            return Text(f"TzamunCode › {self.content}", style="bold blue")


class TUIChat(App):
    """TUI Chat Application"""
    
    CSS = """
    Screen {
        background: $surface;
    }
    
    #header {
        dock: top;
        height: 5;
        background: $primary;
        color: $text;
        content-align: center middle;
    }
    
    #messages {
        height: 1fr;
        border: solid $primary;
        background: $surface;
        overflow-y: scroll;
    }
    
    #input-container {
        dock: bottom;
        height: 3;
        background: $panel;
    }
    
    #input {
        width: 100%;
    }
    
    .command-menu {
        layer: overlay;
        offset: 0 -10;
        width: 60;
        height: auto;
        background: $panel;
        border: solid $primary;
    }
    
    .shortcuts-menu {
        layer: overlay;
        offset: 0 -10;
        width: 40;
        height: auto;
        background: $panel;
        border: solid $primary;
    }
    """
    
    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit"),
        Binding("ctrl+l", "clear", "Clear"),
    ]
    
    def __init__(self, model: str = "qwen2.5:32b", **kwargs):
        super().__init__(**kwargs)
        self.model = model
        self.client = OllamaClient(model=model)
        self.conversation_history = []
        self.command_menu_visible = False
        self.shortcuts_menu_visible = False
    
    def compose(self) -> ComposeResult:
        """Create child widgets"""
        # Header with ASCII logo
        header_text = """╔╦╗╔═╗╔═╗╔╦╗╦ ╦╔╗╔╔═╗╔═╗╔╦╗╔═╗
 ║ ╔═╝╠═╣║║║║ ║║║║║  ║ ║ ║║╣ 
 ╩ ╚═╝╩ ╩╩ ╩╚═╝╝╚╝╚═╝╚═╝═╩╝╚═╝
AI Coding Assistant • Model: """ + self.model
        
        yield Static(header_text, id="header")
        
        # Message history
        yield RichLog(id="messages", highlight=True, markup=True)
        
        # Input container
        with Container(id="input-container"):
            yield Input(placeholder="Type your message... (/ for commands, ? for shortcuts)", id="input")
    
    def on_mount(self) -> None:
        """Called when app starts"""
        messages = self.query_one("#messages", RichLog)
        messages.write("[bold green]Welcome to TzamunCode![/bold green]")
        messages.write("[dim]Type '/' for commands or '?' for shortcuts[/dim]")
        messages.write("")
        
        # Focus input
        self.query_one("#input", Input).focus()
    
    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input changes in real-time"""
        current_value = event.value
        
        # Show command menu when user types '/'
        if current_value.endswith('/') and len(current_value) == 1:
            self.show_command_menu()
            # Clear the '/' from input
            event.input.value = ""
            return
        
        # Show shortcuts menu when user types '?'
        if current_value.endswith('?') and len(current_value) == 1:
            self.show_shortcuts_menu()
            # Clear the '?' from input
            event.input.value = ""
            return
    
    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission"""
        user_input = event.value.strip()
        
        if not user_input:
            return
        
        # Clear input
        event.input.value = ""
        
        if user_input.lower() in ['exit', 'quit', '/exit']:
            self.exit()
            return
        
        if user_input == '/clear':
            self.action_clear()
            return
        
        if user_input.startswith('/'):
            self.handle_slash_command(user_input)
            return
        
        # Regular message - send to AI
        self.send_message(user_input)
    
    def send_message(self, message: str) -> None:
        """Send message to AI and display response"""
        messages = self.query_one("#messages", RichLog)
        
        # Show user message
        messages.write(f"[bold green]You[/bold green] › {message}")
        
        # Add to conversation history
        self.conversation_history.append({"role": "user", "content": message})
        
        # Show thinking indicator
        messages.write("[dim]TzamunCode is thinking...[/dim]")
        
        try:
            # Get AI response (streaming)
            response = ""
            for chunk in self.client.chat_stream(self.conversation_history):
                response += chunk
            
            # Remove thinking indicator and show response
            messages.clear()
            
            # Re-show conversation
            for msg in self.conversation_history:
                if msg["role"] == "user":
                    messages.write(f"[bold green]You[/bold green] › {msg['content']}")
                elif msg["role"] == "assistant":
                    messages.write(f"[bold blue]TzamunCode[/bold blue] › {msg['content']}")
            
            # Show new response
            messages.write(f"[bold blue]TzamunCode[/bold blue] › {response}")
            messages.write("")
            
            # Add to history
            self.conversation_history.append({"role": "assistant", "content": response})
            
        except Exception as e:
            messages.write(f"[bold red]Error:[/bold red] {e}")
    
    def show_command_menu(self) -> None:
        """Show command menu"""
        messages = self.query_one("#messages", RichLog)
        
        table = Table(title="Available Commands", border_style="cyan")
        table.add_column("Command", style="cyan", no_wrap=True)
        table.add_column("Description", style="white")
        
        table.add_row("/help", "Show available commands")
        table.add_row("/models", "List and switch models")
        table.add_row("/settings", "Show settings")
        table.add_row("/clear", "Clear conversation history")
        table.add_row("/exit", "Exit chat")
        
        messages.write(table)
        messages.write("")
    
    def show_shortcuts_menu(self) -> None:
        """Show shortcuts menu"""
        messages = self.query_one("#messages", RichLog)
        
        table = Table(title="Keyboard Shortcuts", border_style="blue")
        table.add_column("Key", style="cyan", no_wrap=True)
        table.add_column("Action", style="white")
        
        table.add_row("Ctrl+C", "Exit chat")
        table.add_row("Ctrl+L", "Clear screen")
        table.add_row("/", "Show commands")
        table.add_row("?", "Show this help")
        
        messages.write(table)
        messages.write("")
    
    def handle_slash_command(self, command: str) -> None:
        """Handle slash commands"""
        messages = self.query_one("#messages", RichLog)
        
        if command == "/help":
            self.show_command_menu()
        elif command == "/models":
            messages.write("[bold blue]Available Models:[/bold blue]")
            try:
                models = self.client.list_models()
                for idx, model in enumerate(models, 1):
                    status = "✓ Active" if model == self.model else ""
                    messages.write(f"  {idx}. {model} {status}")
            except Exception as e:
                messages.write(f"[bold red]Error:[/bold red] {e}")
            messages.write("")
        elif command == "/settings":
            messages.write(f"[bold blue]Current Settings:[/bold blue]")
            messages.write(f"  Model: {self.model}")
            messages.write(f"  Streaming: Enabled")
            messages.write("")
        elif command == "/clear":
            self.action_clear()
        else:
            messages.write(f"[bold red]Unknown command:[/bold red] {command}")
            messages.write("[dim]Type '/' to see available commands[/dim]")
            messages.write("")
    
    def action_clear(self) -> None:
        """Clear conversation history"""
        self.conversation_history = []
        messages = self.query_one("#messages", RichLog)
        messages.clear()
        messages.write("[bold green]Conversation cleared[/bold green]")
        messages.write("")
    
    def action_quit(self) -> None:
        """Quit the app"""
        self.exit()


def run_tui_chat(model: str = "qwen2.5:32b", system: Optional[str] = None):
    """Run the TUI chat interface"""
    app = TUIChat(model=model)
    app.run()
