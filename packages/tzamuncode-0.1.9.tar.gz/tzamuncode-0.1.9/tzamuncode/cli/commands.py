"""
Command implementations for TzamunCode CLI
"""

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.live import Live
from rich.spinner import Spinner
from typing import Optional
import sys

from ..models.ollama import OllamaClient
from ..utils.file_ops import FileManager

console = Console()

def chat_command(model: str, system: Optional[str] = None):
    """Interactive chat with AI"""
    client = OllamaClient(model=model)
    
    console.print(Panel.fit(
        f"[bold blue]TzamunCode Chat[/bold blue]\n\n"
        f"Model: [cyan]{model}[/cyan]\n"
        f"Type [bold]'exit'[/bold] or [bold]'quit'[/bold] to end the session",
        border_style="blue"
    ))
    
    conversation_history = []
    
    if system:
        conversation_history.append({"role": "system", "content": system})
    
    while True:
        try:
            user_input = Prompt.ask("\n[bold green]You[/bold green]")
            
            if user_input.lower() in ['exit', 'quit', 'q']:
                console.print("[dim]Goodbye! 👋[/dim]")
                break
            
            conversation_history.append({"role": "user", "content": user_input})
            
            console.print("\n[bold blue]TzamunCode[/bold blue]:", end=" ")
            
            # Stream response
            response = ""
            for chunk in client.chat_stream(conversation_history):
                response += chunk
                console.print(chunk, end="")
            
            console.print()  # New line after response
            
            conversation_history.append({"role": "assistant", "content": response})
            
        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted. Goodbye! 👋[/dim]")
            break
        except Exception as e:
            console.print(f"\n[bold red]Error:[/bold red] {e}")

def generate_command(prompt: str, model: str, output: Optional[str] = None):
    """Generate code based on prompt"""
    client = OllamaClient(model=model)
    file_manager = FileManager()
    
    console.print(f"\n[bold blue]Generating:[/bold blue] {prompt}")
    console.print(f"[dim]Model: {model}[/dim]\n")
    
    # Create generation prompt
    full_prompt = f"""Generate code for: {prompt}

Requirements:
- Write clean, well-documented code
- Include error handling
- Follow best practices
- Add comments explaining complex logic

Generate the complete, working code:"""
    
    with console.status("[bold blue]Generating code...", spinner="dots"):
        response = client.generate(full_prompt)
    
    # Extract code from response
    code = response.strip()
    
    # Display generated code
    console.print("\n[bold green]Generated Code:[/bold green]\n")
    
    # Try to detect language for syntax highlighting
    language = "python"  # Default
    if output:
        if output.endswith('.js'):
            language = "javascript"
        elif output.endswith('.go'):
            language = "go"
        elif output.endswith('.rs'):
            language = "rust"
    
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    console.print(syntax)
    
    # Save to file if output specified
    if output:
        if Confirm.ask(f"\n[bold]Save to {output}?[/bold]"):
            file_manager.write_file(output, code)
            console.print(f"[bold green]✓[/bold green] Saved to {output}")
    else:
        if Confirm.ask("\n[bold]Save to file?[/bold]"):
            filename = Prompt.ask("Filename")
            file_manager.write_file(filename, code)
            console.print(f"[bold green]✓[/bold green] Saved to {filename}")

def edit_command(file_path: str, instruction: str, model: str, apply: bool = False):
    """Edit a file using AI"""
    client = OllamaClient(model=model)
    file_manager = FileManager()
    
    # Read current file
    try:
        current_content = file_manager.read_file(file_path)
    except FileNotFoundError:
        console.print(f"[bold red]Error:[/bold red] File not found: {file_path}")
        return
    
    console.print(f"\n[bold blue]Editing:[/bold blue] {file_path}")
    console.print(f"[bold blue]Instruction:[/bold blue] {instruction}")
    console.print(f"[dim]Model: {model}[/dim]\n")
    
    # Create edit prompt
    edit_prompt = f"""You are editing the file: {file_path}

Current content:
```
{current_content}
```

Instruction: {instruction}

Provide the complete modified file content. Only output the code, no explanations:"""
    
    with console.status("[bold blue]Generating changes...", spinner="dots"):
        new_content = client.generate(edit_prompt)
    
    # Show diff
    diff = file_manager.show_diff(file_path, new_content)
    
    if diff:
        console.print("\n[bold yellow]Changes:[/bold yellow]\n")
        console.print(diff)
        
        # Apply changes
        if apply or Confirm.ask("\n[bold]Apply these changes?[/bold]"):
            file_manager.write_file(file_path, new_content)
            console.print(f"[bold green]✓[/bold green] Changes applied to {file_path}")
        else:
            console.print("[dim]Changes not applied[/dim]")
    else:
        console.print("[dim]No changes needed[/dim]")

def explain_command(file_path: str, model: str, detailed: bool = False):
    """Explain code in a file"""
    client = OllamaClient(model=model)
    file_manager = FileManager()
    
    # Read file
    try:
        content = file_manager.read_file(file_path)
    except FileNotFoundError:
        console.print(f"[bold red]Error:[/bold red] File not found: {file_path}")
        return
    
    console.print(f"\n[bold blue]Explaining:[/bold blue] {file_path}")
    console.print(f"[dim]Model: {model}[/dim]\n")
    
    # Create explanation prompt
    detail_level = "detailed" if detailed else "concise"
    explain_prompt = f"""Explain this code in a {detail_level} way:

File: {file_path}
```
{content}
```

Provide a clear explanation covering:
- What the code does
- Key functions/classes
- Important logic
- Potential improvements (if detailed)

Explanation:"""
    
    with console.status("[bold blue]Analyzing code...", spinner="dots"):
        explanation = client.generate(explain_prompt)
    
    # Display explanation
    console.print(Panel(
        Markdown(explanation),
        title=f"[bold blue]Explanation: {file_path}[/bold blue]",
        border_style="blue"
    ))
