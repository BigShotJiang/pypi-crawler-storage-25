"""
Additional methods for RealtimeChat class
These will be added to realtime_chat.py
"""

import json
from pathlib import Path
from rich.syntax import Syntax
from rich.prompt import Prompt, Confirm


def read_file(self, file_path: str):
    """Read and display a file with syntax highlighting"""
    try:
        full_path = self.workspace / file_path
        
        if not full_path.exists():
            console.print(f"\n[bold red]✗[/bold red] File not found: {file_path}\n")
            return
        
        if full_path.is_dir():
            console.print(f"\n[bold red]✗[/bold red] {file_path} is a directory, not a file\n")
            return
        
        # Read file content
        content = full_path.read_text()
        
        # Detect language for syntax highlighting
        suffix = full_path.suffix.lstrip('.')
        lang_map = {
            'py': 'python', 'js': 'javascript', 'ts': 'typescript',
            'jsx': 'jsx', 'tsx': 'tsx', 'java': 'java', 'cpp': 'cpp',
            'c': 'c', 'go': 'go', 'rs': 'rust', 'rb': 'ruby',
            'php': 'php', 'html': 'html', 'css': 'css', 'json': 'json',
            'yaml': 'yaml', 'yml': 'yaml', 'xml': 'xml', 'md': 'markdown',
            'sh': 'bash', 'bash': 'bash', 'sql': 'sql'
        }
        language = lang_map.get(suffix, 'text')
        
        console.print()
        console.print(f"[bold cyan]📄 {file_path}[/bold cyan] ({len(content)} chars, {len(content.splitlines())} lines)\n")
        
        # Syntax highlighted display
        syntax = Syntax(content, language, theme="monokai", line_numbers=True)
        console.print(syntax)
        console.print()
        
        # Add to conversation context
        self.conversation_history.append({
            "role": "user",
            "content": f"I read the file {file_path}:\n```{language}\n{content}\n```"
        })
        
    except Exception as e:
        console.print(f"\n[bold red]✗ Error reading file:[/bold red] {e}\n")


def write_file(self, file_path: str):
    """Write content to a file interactively"""
    try:
        console.print()
        console.print(f"[bold cyan]Writing to:[/bold cyan] {file_path}")
        console.print("[dim]Enter content (type 'EOF' on a new line to finish):[/dim]\n")
        
        lines = []
        while True:
            line = input()
            if line == 'EOF':
                break
            lines.append(line)
        
        content = '\n'.join(lines)
        
        full_path = self.workspace / file_path
        
        # Confirm if file exists
        if full_path.exists():
            if not Confirm.ask(f"\n[bold yellow]⚠[/bold yellow] File exists. Overwrite?"):
                console.print("[dim]Write cancelled[/dim]\n")
                return
        
        # Create parent directories if needed
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write file
        full_path.write_text(content)
        
        console.print(f"\n[bold green]✓[/bold green] Written {len(content)} chars to {file_path}\n")
        
        # Add to conversation context
        self.conversation_history.append({
            "role": "user",
            "content": f"I wrote to file {file_path}:\n```\n{content}\n```"
        })
        
    except KeyboardInterrupt:
        console.print("\n[dim]Write cancelled[/dim]\n")
    except Exception as e:
        console.print(f"\n[bold red]✗ Error writing file:[/bold red] {e}\n")


def switch_backend(self):
    """Switch between vLLM and Ollama backends"""
    console.print()
    console.print("[bold cyan]Switch AI Backend[/bold cyan]\n")
    console.print(f"Current: [bold]{'vLLM' if self.use_vllm else 'Ollama'}[/bold]\n")
    console.print("  [bold]1[/bold]. ⚡ [cyan]vLLM[/cyan] - Fast inference (Qwen 2.5 7B)")
    console.print("  [bold]2[/bold]. 🦙 [green]Ollama[/green] - Powerful models (Qwen 2.5 32B)")
    
    choice = Prompt.ask("\nSwitch to", choices=["1", "2"], default="2" if self.use_vllm else "1")
    
    new_use_vllm = (choice == "1")
    
    if new_use_vllm == self.use_vllm:
        console.print("\n[dim]Already using this backend[/dim]\n")
        return
    
    # Switch backend
    self.use_vllm = new_use_vllm
    
    if self.use_vllm:
        from ..models.vllm_client import VLLMClient
        self.model = "qwen2.5-7b-instruct"
        self.client = VLLMClient(model=self.model)
        self.backend = "vLLM"
        console.print("\n[bold green]✓[/bold green] Switched to [cyan]vLLM[/cyan] backend\n")
    else:
        from ..models.ollama import OllamaClient
        self.model = "qwen2.5:32b"
        self.client = OllamaClient(model=self.model)
        self.backend = "Ollama"
        console.print("\n[bold green]✓[/bold green] Switched to [green]Ollama[/green] backend\n")


def show_conversation_history(self):
    """Show conversation history"""
    console.print()
    
    if len(self.conversation_history) <= 1:  # Only system prompt
        console.print("[dim]No conversation history yet[/dim]\n")
        return
    
    console.print(f"[bold cyan]Conversation History[/bold cyan] ({len(self.conversation_history) - 1} messages)\n")
    
    for idx, msg in enumerate(self.conversation_history[1:], 1):  # Skip system prompt
        role = msg['role']
        content = msg['content']
        
        if role == 'user':
            console.print(f"[bold green]{idx}. You[/bold green] › {content[:100]}{'...' if len(content) > 100 else ''}")
        else:
            console.print(f"[bold blue]{idx}. AI[/bold blue] › {content[:100]}{'...' if len(content) > 100 else ''}")
    
    console.print()


def save_conversation(self, filename: str):
    """Save conversation to JSON file"""
    try:
        save_path = self.workspace / filename
        
        # Prepare data
        data = {
            'model': self.model,
            'backend': self.backend,
            'workspace': str(self.workspace),
            'conversation': self.conversation_history
        }
        
        # Save to file
        with open(save_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        console.print(f"\n[bold green]✓[/bold green] Conversation saved to {filename}\n")
        
    except Exception as e:
        console.print(f"\n[bold red]✗ Error saving:[/bold red] {e}\n")


def load_conversation(self, filename: str):
    """Load conversation from JSON file"""
    try:
        load_path = self.workspace / filename
        
        if not load_path.exists():
            console.print(f"\n[bold red]✗[/bold red] File not found: {filename}\n")
            return
        
        # Load data
        with open(load_path, 'r') as f:
            data = json.load(f)
        
        # Restore conversation
        self.conversation_history = data['conversation']
        
        console.print(f"\n[bold green]✓[/bold green] Loaded conversation from {filename}")
        console.print(f"[dim]Model: {data.get('model', 'unknown')} | Messages: {len(self.conversation_history)}[/dim]\n")
        
    except Exception as e:
        console.print(f"\n[bold red]✗ Error loading:[/bold red] {e}\n")
