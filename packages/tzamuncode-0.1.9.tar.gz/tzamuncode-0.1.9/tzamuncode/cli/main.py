"""
TzamunCode CLI - Main Entry Point
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Confirm
from rich.table import Table
from typing import Optional
import sys

from ..models.ollama import OllamaClient
from ..utils.file_ops import FileManager
from .commands import chat_command, generate_command, edit_command, explain_command
from .agentic_commands import agentic_command, project_command

app = typer.Typer(
    name="tzamuncode",
    help="TzamunCode - AI Coding Assistant powered by local models 🚀",
    add_completion=False,
)

console = Console()

def version_callback(value: bool):
    if value:
        from .. import __version__
        console.print(f"[bold blue]TzamunCode[/bold blue] version {__version__}")
        console.print("Built with ❤️ in Saudi Arabia 🇸🇦")
        raise typer.Exit()

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit"
    )
):
    """
    TzamunCode - AI Coding Assistant
    
    Privacy-first AI coding assistant powered by local models.
    """
    # If no subcommand provided, show interactive backend selection
    if ctx.invoked_subcommand is None:
        from rich.prompt import Prompt
        from .realtime_chat import RealtimeChat
        from ..auth.auth_manager import AuthManager
        
        # Check authentication
        auth = AuthManager()
        if not auth.is_authenticated():
            console.print("\n[bold yellow]🔐 Authentication Required[/bold yellow]\n")
            console.print("[dim]Please login to use TzamunCode[/dim]\n")
            console.print("Run: [cyan]tzamuncode login[/cyan]\n")
            return
        
        console.print("\n[bold cyan]🚀 TzamunCode AI Assistant[/bold cyan]\n")
        console.print("Select AI Backend:\n")
        console.print("  [bold]1[/bold]. ⚡ [cyan]vLLM[/cyan] - Fast inference (Qwen 2.5 7B)")
        console.print("  [bold]2[/bold]. 🦙 [green]Ollama[/green] - Powerful models (Qwen 2.5 32B)")
        
        choice = Prompt.ask("\nChoose backend", choices=["1", "2"], default="2")
        
        if choice == "1":
            console.print("\n✅ Starting with [cyan]vLLM[/cyan] backend...\n")
            chat = RealtimeChat(model="qwen2.5-7b-instruct", use_vllm=True)
        else:
            console.print("\n✅ Starting with [green]Ollama[/green] backend...\n")
            chat = RealtimeChat(model="qwen2.5:32b", use_vllm=False)
        
        chat.run()

@app.command()
def agent(
    backend: str = typer.Option(
        "vllm",
        "--backend",
        "-b",
        help="AI backend to use (vllm or ollama)"
    ),
    model: str = typer.Option(
        "qwen2.5-7b-instruct",
        "--model",
        "-m",
        help="Model name to use"
    ),
    apply: bool = typer.Option(
        False,
        "--apply",
        help="Auto-apply changes without confirmation"
    ),
    mcp_server: Optional[str] = typer.Option(
        None,
        "--mcp-server",
        help="MCP server command (e.g., 'paperclip-mcp-server')"
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output JSONL format for Paperclip"
    ),
    max_tokens: int = typer.Option(
        4096,
        "--max-tokens",
        help="Maximum tokens to generate (default: 4096)"
    ),
    max_tool_result_chars: int = typer.Option(
        8000,
        "--max-tool-result-chars",
        help="Maximum characters for tool results to prevent context overflow (default: 8000)"
    )
):
    """
    Agentic execution mode for Paperclip integration.
    
    Reads prompt from stdin, calls AI backend, outputs response to stdout.
    Supports MCP tool calling and JSONL output format.
    
    Examples:
        echo "Write a Python function" | tzamuncode agent --backend vllm --model qwen2.5-7b-instruct
        echo "Fix the bug" | tzamuncode agent --apply --backend ollama --model qwen2.5:32b
        echo "Create an issue" | tzamuncode agent --backend vllm --mcp-server paperclip-mcp-server --json
    """
    import requests
    import os
    import json as json_lib
    import re
    from typing import Optional
    
    from ..output.jsonl import JSONLOutput
    
    # Initialize output handler
    output = JSONLOutput() if json_output else None
    
    # Read prompt from stdin
    prompt = sys.stdin.read().strip()
    
    if not prompt:
        if output:
            output.error("No prompt provided via stdin", "invalid_input")
        sys.stderr.write("Error: No prompt provided via stdin\n")
        raise typer.Exit(code=1)
    
    # Emit session started
    if output:
        output.session_started(model, backend)
    
    # Initialize MCP client if server specified
    mcp_client = None
    tools_description = ""
    
    if mcp_server:
        try:
            from ..mcp.client import MCPClient
            mcp_client = MCPClient(mcp_server)
            if mcp_client.connect():
                tools_description = mcp_client.format_tools_for_prompt()
                sys.stderr.write(f"Connected to MCP server with {len(mcp_client.get_tools())} tools\n")
            else:
                sys.stderr.write("Warning: Failed to connect to MCP server, continuing without tools\n")
                mcp_client = None
        except Exception as e:
            sys.stderr.write(f"Warning: MCP initialization failed: {e}\n")
            mcp_client = None
    
    # Enhance prompt with tools if available
    enhanced_prompt = prompt
    if tools_description:
        enhanced_prompt = f"{prompt}\n{tools_description}"
    
    # Multi-turn conversation for tool calling
    max_turns = 5
    conversation_history = [{"role": "user", "content": enhanced_prompt}]
    final_response = ""
    
    for turn in range(max_turns):
        # Get backend URL from environment or use defaults
        if backend == "vllm":
            base_url = os.getenv('VLLM_BASE_URL', 'http://localhost:8000')
            # Call vLLM (OpenAI-compatible API)
            try:
                response = requests.post(
                    f"{base_url}/v1/chat/completions",
                    json={
                        "model": model,
                        "messages": conversation_history,
                        "temperature": 0.7,
                        "max_tokens": max_tokens,
                        "stream": False
                    },
                    timeout=300
                )
                response.raise_for_status()
                result = response.json()
                ai_response = result["choices"][0]["message"]["content"]
                
                # Track usage
                if output and "usage" in result:
                    output.usage(
                        result["usage"].get("prompt_tokens", 0),
                        result["usage"].get("completion_tokens", 0)
                    )
            except Exception as e:
                if output:
                    output.error(str(e), "vllm_error")
                sys.stderr.write(f"Error calling vLLM: {e}\n")
                if mcp_client:
                    mcp_client.disconnect()
                raise typer.Exit(code=1)
    
        elif backend == "ollama":
            base_url = os.getenv('OLLAMA_BASE_URL', 'http://localhost:11434')
            # Call Ollama API (convert conversation to single prompt)
            full_prompt = "\n".join([f"{msg['role']}: {msg['content']}" for msg in conversation_history])
            try:
                response = requests.post(
                    f"{base_url}/api/generate",
                    json={
                        "model": model,
                        "prompt": full_prompt,
                        "stream": False,
                        "options": {
                            "temperature": 0.7,
                            "num_predict": max_tokens
                        }
                    },
                    timeout=300
                )
                response.raise_for_status()
                result = response.json()
                ai_response = result["response"]
                
                # Track usage
                if output:
                    output.usage(
                        result.get("prompt_eval_count", 0),
                        result.get("eval_count", 0)
                    )
            except Exception as e:
                if output:
                    output.error(str(e), "ollama_error")
                sys.stderr.write(f"Error calling Ollama: {e}\n")
                if mcp_client:
                    mcp_client.disconnect()
                raise typer.Exit(code=1)
        
        else:
            if output:
                output.error(f"Unknown backend '{backend}'. Use 'vllm' or 'ollama'", "invalid_backend")
            sys.stderr.write(f"Error: Unknown backend '{backend}'. Use 'vllm' or 'ollama'\n")
            if mcp_client:
                mcp_client.disconnect()
            raise typer.Exit(code=1)
        
        # Check if response contains a tool call
        tool_call_match = None
        if mcp_client:
            # Look for JSON tool call in response
            json_pattern = r'\{\s*"tool"\s*:\s*"([^"]+)"\s*,\s*"arguments"\s*:\s*\{[^}]*\}\s*\}'
            tool_call_match = re.search(json_pattern, ai_response, re.DOTALL)
        
        if tool_call_match and mcp_client:
            # Extract and execute tool call
            try:
                tool_call_json = tool_call_match.group(0)
                tool_call = json_lib.loads(tool_call_json)
                tool_name = tool_call["tool"]
                tool_args = tool_call["arguments"]
                
                if output:
                    output.tool_call(tool_name, tool_args)
                
                sys.stderr.write(f"Executing tool: {tool_name}\n")
                
                # Execute the tool
                tool_result = mcp_client.call_tool(tool_name, tool_args)
                
                if output:
                    output.tool_result(tool_name, tool_result)
                
                # Format and truncate tool result to prevent context overflow
                tool_result_str = json_lib.dumps(tool_result, indent=2)
                
                # Truncate if too large
                if len(tool_result_str) > max_tool_result_chars:
                    truncated_result = tool_result_str[:max_tool_result_chars]
                    truncation_msg = f"\n\n[... Result truncated. Showing first {max_tool_result_chars} characters of {len(tool_result_str)} total characters ...]"
                    tool_result_str = truncated_result + truncation_msg
                    sys.stderr.write(f"Warning: Tool result truncated from {len(json_lib.dumps(tool_result, indent=2))} to {max_tool_result_chars} chars\n")
                
                # Add assistant response and tool result to conversation
                conversation_history.append({"role": "assistant", "content": ai_response})
                conversation_history.append({
                    "role": "user",
                    "content": f"Tool execution result:\n{tool_result_str}"
                })
                
                # Continue to next turn
                continue
                
            except Exception as e:
                sys.stderr.write(f"Error executing tool: {e}\n")
                # Continue with the response as-is
                final_response = ai_response
                break
        else:
            # No tool call, this is the final response
            final_response = ai_response
            break
    
    # Disconnect MCP client
    if mcp_client:
        mcp_client.disconnect()
    
    # Output final response
    if output:
        output.message(final_response)
        output.result(final_response)
    else:
        print(final_response, flush=True)
    
    # Exit successfully
    raise typer.Exit(code=0)

@app.command()
def chat(
    model: str = typer.Option(
        "qwen2.5:32b",
        "--model",
        "-m",
        help="Model to use for chat"
    ),
    system: Optional[str] = typer.Option(
        None,
        "--system",
        "-s",
        help="System prompt"
    ),
    vllm: bool = typer.Option(
        False,
        "--vllm",
        help="Use vLLM backend (faster)"
    )
):
    """
    Start an interactive chat session with TzamunCode AI.
    
    Features:
    - Beautiful UI with welcome screen
    - Type '/' to see all commands
    - '/models' to switch models
    - '/settings' to view settings
    - '/help' for help
    
    Examples:
        tzamuncode chat
        tzamuncode chat --model deepseek-coder-v2
        tzc chat -m qwen2.5:32b
    """
    from .realtime_chat import run_realtime_chat
    from ..auth.auth_manager import AuthManager
    
    # Check authentication
    auth = AuthManager()
    if not auth.is_authenticated():
        console.print("\n[bold yellow]🔐 Authentication Required[/bold yellow]\n")
        console.print("[dim]Please login to use TzamunCode[/dim]\n")
        console.print("Run: [cyan]tzamuncode login[/cyan]\n")
        return
    
    if vllm and model == 'qwen2.5:32b':
        model = 'qwen2.5-7b-instruct'
    run_realtime_chat(model=model, system=system, use_vllm=vllm)

@app.command()
def generate(
    prompt: str = typer.Argument(..., help="What to generate"),
    model: str = typer.Option(
        "qwen2.5:32b",
        "--model",
        "-m",
        help="Model to use"
    ),
    output: Optional[str] = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file or directory"
    )
):
    """
    Generate code based on a prompt.
    
    Examples:
        tzamuncode generate "Create a Flask REST API"
        tzamuncode generate "Add unit tests" --output tests/
        tzc generate "Python web scraper" -o scraper.py
    """
    generate_command(prompt=prompt, model=model, output=output)

@app.command()
def edit(
    file_path: str = typer.Argument(..., help="File to edit"),
    instruction: str = typer.Argument(..., help="What to change"),
    model: str = typer.Option(
        "qwen2.5:32b",
        "--model",
        "-m",
        help="Model to use"
    ),
    apply: bool = typer.Option(
        False,
        "--apply",
        "-a",
        help="Apply changes without confirmation"
    )
):
    """
    Edit a file using AI.
    
    Examples:
        tzamuncode edit app.py "Add error handling"
        tzamuncode edit . "Add type hints to all functions"
        tzc edit main.py "Refactor to use async" --apply
    """
    edit_command(file_path=file_path, instruction=instruction, model=model, apply=apply)

@app.command()
def explain(
    file_path: str = typer.Argument(..., help="File to explain"),
    model: str = typer.Option(
        "qwen2.5:32b",
        "--model",
        "-m",
        help="Model to use"
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        "-d",
        help="Provide detailed explanation"
    )
):
    """
    Explain code in a file.
    
    Examples:
        tzamuncode explain complex_function.py
        tzamuncode explain auth.py --detailed
        tzc explain main.py -d
    """
    explain_command(file_path=file_path, model=model, detailed=detailed)

@app.command()
def code(
    instruction: str = typer.Argument(..., help="What to do"),
    model: str = typer.Option(
        "qwen2.5:32b",
        "--model",
        "-m",
        help="Model to use"
    ),
    workspace: Optional[str] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Project directory (default: current)"
    ),
    apply: bool = typer.Option(
        False,
        "--apply",
        "-a",
        help="Auto-apply changes without confirmation"
    )
):
    """
    Agentic AI mode - AI autonomously accesses files and writes code.
    
    Similar to Claude Code, the AI will:
    - Scan your project structure
    - Read files autonomously
    - Edit multiple files
    - Execute git operations
    - Plan and execute multi-step tasks
    
    Examples:
        tzamuncode code "Add authentication to this Flask app"
        tzamuncode code "Refactor all Python files to use async/await"
        tzc code "Add unit tests for all functions" --apply
    """
    agentic_command(
        instruction=instruction,
        model=model,
        workspace=workspace,
        auto_apply=apply
    )

@app.command()
def project(
    workspace: Optional[str] = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Project directory (default: current)"
    )
):
    """
    Analyze and understand project structure.
    
    Examples:
        tzamuncode project
        tzamuncode project --workspace /path/to/project
        tzc project
    """
    project_command(workspace=workspace)

@app.command()
def login(
    username: Optional[str] = typer.Option(
        None,
        "--username",
        "-u",
        help="TzamunAI username"
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="TzamunAI API key (alternative to username/password)"
    )
):
    """
    Login to TzamunAI (app.tzamun.ai)
    
    Examples:
        tzamuncode login
        tzamuncode login --username myuser
        tzamuncode login --api-key YOUR_API_KEY
    """
    from ..auth.auth_manager import AuthManager
    from rich.prompt import Prompt
    import getpass
    
    auth = AuthManager()
    
    # Check if already logged in
    if auth.is_authenticated():
        user_info = auth.get_user_info()
        console.print(f"\n[bold yellow]⚠[/bold yellow] Already logged in as [cyan]{user_info.get('username')}[/cyan]")
        if not Confirm.ask("Logout and login again?"):
            return
        auth.logout()
    
    console.print("\n[bold cyan]🔐 Login to TzamunAI[/bold cyan]\n")
    
    # API Key login
    if api_key:
        console.print("[dim]Validating API key...[/dim]")
        if auth.login_with_api_key(api_key):
            console.print("\n[bold green]✓[/bold green] Successfully logged in with API key!\n")
        else:
            console.print("\n[bold red]✗[/bold red] Invalid API key\n")
        return
    
    # Username/Password login
    if not username:
        username = Prompt.ask("[cyan]Username[/cyan]")
    
    password = getpass.getpass("Password: ")
    
    console.print("\n[dim]Authenticating...[/dim]")
    
    if auth.login_with_credentials(username, password):
        console.print(f"\n[bold green]✓[/bold green] Successfully logged in as [cyan]{username}[/cyan]!\n")
        console.print("[dim]Your session will expire in 30 days[/dim]\n")
    else:
        console.print("\n[bold red]✗[/bold red] Login failed. Check your credentials.\n")

@app.command()
def logout():
    """
    Logout from TzamunAI
    
    Examples:
        tzamuncode logout
    """
    from ..auth.auth_manager import AuthManager
    
    auth = AuthManager()
    
    if not auth.is_authenticated():
        console.print("\n[dim]Not logged in[/dim]\n")
        return
    
    user_info = auth.get_user_info()
    auth.logout()
    
    console.print(f"\n[bold green]✓[/bold green] Logged out [cyan]{user_info.get('username')}[/cyan]\n")

@app.command()
def whoami():
    """
    Show current authentication status
    
    Examples:
        tzamuncode whoami
    """
    from ..auth.auth_manager import AuthManager
    
    auth = AuthManager()
    
    console.print()
    
    if not auth.is_authenticated():
        console.print("[bold yellow]Not authenticated[/bold yellow]")
        console.print("\n[dim]Login with:[/dim] [cyan]tzamuncode login[/cyan]\n")
        return
    
    user_info = auth.get_user_info()
    
    table = Table(
        title="[bold cyan]Authentication Status[/bold cyan]",
        border_style="blue",
        show_header=True,
        header_style="bold white on blue"
    )
    table.add_column("Property", style="bold cyan", width=20)
    table.add_column("Value", style="yellow")
    
    table.add_row("Status", "✓ Authenticated")
    table.add_row("Username", user_info.get('username', 'N/A'))
    table.add_row("Auth Type", user_info.get('type', 'N/A').replace('_', ' ').title())
    
    console.print(table)
    console.print()

@app.command()
def info():
    """
    Show information about TzamunCode and available models.
    """
    from .. import __version__
    from ..auth.auth_manager import AuthManager
    
    auth = AuthManager()
    
    console.print(Panel.fit(
        f"""[bold blue]TzamunCode CLI[/bold blue] v{__version__}
        
[bold]AI Coding Assistant powered by local models[/bold]

Built by [bold cyan]Tzamun Arabia IT Co.[/bold cyan] 🇸🇦

[dim]Privacy-first • No cloud dependencies • Complete control[/dim]
""",
        border_style="blue"
    ))
    
    # Show auth status
    if auth.is_authenticated():
        user_info = auth.get_user_info()
        console.print(f"\n[bold green]✓[/bold green] Logged in as [cyan]{user_info.get('username')}[/cyan]")
    else:
        console.print("\n[dim]Not logged in • Use[/dim] [cyan]tzamuncode login[/cyan]")
    
    # Check Ollama connection
    try:
        client = OllamaClient()
        models = client.list_models()
        
        console.print("\n[bold green]✓[/bold green] Connected to Ollama")
        console.print(f"[bold]Available models:[/bold] {len(models)}")
        
        for model in models[:5]:  # Show first 5
            console.print(f"  • {model}")
        
        if len(models) > 5:
            console.print(f"  ... and {len(models) - 5} more")
            
    except Exception as e:
        console.print(f"\n[bold red]✗[/bold red] Could not connect to Ollama: {e}")
        console.print("[dim]Make sure Ollama is running: ollama serve[/dim]")

def run():
    """Entry point for the CLI"""
    app()

if __name__ == "__main__":
    run()
