"""
Authentication commands for TzamunCode CLI
"""

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.table import Table
import getpass

from ..auth.auth_manager import AuthManager

console = Console()


def login_command():
    """Interactive login command"""
    auth = AuthManager()
    
    # Check if already logged in
    if auth.is_authenticated():
        user_info = auth.get_user_info()
        console.print(f"\n[yellow]Already logged in as:[/yellow] [cyan]{user_info['username']}[/cyan]")
        
        if not Confirm.ask("\n[bold]Logout and login again?[/bold]"):
            return
        
        auth.logout()
        console.print("[dim]Logged out[/dim]\n")
    
    # Show login options
    console.print(Panel.fit(
        """[bold cyan]TzamunCode Authentication[/bold cyan]

Choose login method:
[bold]1.[/bold] Username & Password (TzamunAI account)
[bold]2.[/bold] API Key (from TzamunAI TCHub)
""",
        border_style="blue",
        title="[bold blue]Login[/bold blue]"
    ))
    
    choice = Prompt.ask("\n[bold]Select option[/bold]", choices=["1", "2"], default="2")
    
    if choice == "1":
        # Username/Password login
        console.print("\n[bold blue]Login with TzamunAI Account[/bold blue]\n")
        
        username = Prompt.ask("[bold]Username[/bold]")
        password = getpass.getpass("Password: ")
        
        console.print("\n[dim]Authenticating...[/dim]")
        
        if auth.login_with_credentials(username, password):
            console.print(f"\n[bold green]✓ Successfully logged in as {username}![/bold green]\n")
        else:
            console.print("\n[bold red]✗ Login failed. Please check your credentials.[/bold red]\n")
    
    else:
        # API Key login
        console.print("\n[bold blue]Login with API Key[/bold blue]\n")
        console.print("[dim]Get your API key from: https://app.tzamun.ai/admin (API Config tab)[/dim]\n")
        
        api_key = Prompt.ask("[bold]API Key[/bold]", password=True)
        
        console.print("\n[dim]Validating API key...[/dim]")
        
        if auth.login_with_api_key(api_key):
            console.print("\n[bold green]✓ Successfully authenticated with API key![/bold green]\n")
        else:
            console.print("\n[bold red]✗ Invalid API key. Please check and try again.[/bold red]\n")


def logout_command():
    """Logout command"""
    auth = AuthManager()
    
    if not auth.is_authenticated():
        console.print("\n[yellow]Not logged in[/yellow]\n")
        return
    
    user_info = auth.get_user_info()
    
    if Confirm.ask(f"\n[bold]Logout from {user_info['username']}?[/bold]"):
        auth.logout()
        console.print("\n[bold green]✓ Logged out successfully[/bold green]\n")


def whoami_command():
    """Show current user info"""
    auth = AuthManager()
    
    if not auth.is_authenticated():
        console.print("\n[yellow]Not logged in[/yellow]")
        console.print("[dim]Run 'tzamuncode login' to authenticate[/dim]\n")
        return
    
    user_info = auth.get_user_info()
    
    table = Table(title="Current User", border_style="blue")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="yellow")
    
    table.add_row("Status", "✓ Authenticated")
    table.add_row("Type", user_info['type'].replace('_', ' ').title())
    table.add_row("User", user_info['username'])
    
    console.print()
    console.print(table)
    console.print()


def require_auth(func):
    """Decorator to require authentication before running a command"""
    def wrapper(*args, **kwargs):
        auth = AuthManager()
        
        if not auth.is_authenticated():
            console.print("\n[bold red]✗ Authentication required[/bold red]")
            console.print("[dim]Run 'tzamuncode login' to authenticate[/dim]\n")
            return
        
        return func(*args, **kwargs)
    
    return wrapper
