"""CLI module for TzamunCode"""
