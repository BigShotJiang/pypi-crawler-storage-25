"""
Agentic commands - Advanced AI operations with autonomous file access
"""

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Confirm
from rich.live import Live
from rich.status import Status
from typing import Optional
import sys

from ..agents.coder import AgenticCoder

console = Console()


def agentic_command(
    instruction: str,
    model: str = "qwen2.5:32b",
    workspace: Optional[str] = None,
    auto_apply: bool = False
):
    """
    Execute an instruction using agentic AI with autonomous file access.
    
    This is similar to Claude Code - the AI can:
    - Scan your project
    - Read files autonomously
    - Write/edit multiple files
    - Execute git operations
    - Plan multi-step tasks
    
    Args:
        instruction: What to do (e.g., "Add authentication to this Flask app")
        model: Model to use
        workspace: Project directory (default: current directory)
        auto_apply: Apply changes without confirmation
    """
    console.print(f"\n[bold blue]TzamunCode Agentic Mode[/bold blue]")
    console.print(f"[dim]Model: {model}[/dim]")
    console.print(f"[dim]Workspace: {workspace or 'current directory'}[/dim]\n")
    
    console.print(Panel(
        f"[bold]Instruction:[/bold]\n{instruction}\n\n"
        "[dim]The AI will autonomously:\n"
        "• Scan project structure\n"
        "• Read relevant files\n"
        "• Plan changes\n"
        "• Edit multiple files\n"
        "• Provide summary[/dim]",
        border_style="blue"
    ))
    
    if not auto_apply:
        if not Confirm.ask("\n[bold]Allow AI to access and modify files?[/bold]"):
            console.print("[dim]Cancelled[/dim]")
            return
    
    # Initialize agentic coder
    with console.status("[bold blue]Initializing AI agent...", spinner="dots"):
        try:
            agent = AgenticCoder(
                model=model,
                workspace=workspace
            )
        except Exception as e:
            console.print(f"[bold red]Error:[/bold red] Failed to initialize agent: {e}")
            return
    
    console.print("[bold green]✓[/bold green] Agent initialized\n")
    
    # Execute instruction
    console.print("[bold blue]AI is working...[/bold blue]\n")
    
    try:
        with Live(console=console, refresh_per_second=4) as live:
            result = agent.execute(instruction)
        
        if result['success']:
            console.print("\n[bold green]✓ Task completed![/bold green]\n")
            console.print(Panel(
                Markdown(result['result']),
                title="[bold blue]Summary[/bold blue]",
                border_style="green"
            ))
        else:
            console.print(f"\n[bold red]✗ Error:[/bold red] {result.get('error', 'Unknown error')}")
            
    except KeyboardInterrupt:
        console.print("\n[dim]Interrupted by user[/dim]")
    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")


def project_command(workspace: Optional[str] = None):
    """
    Analyze and understand the project structure.
    
    Args:
        workspace: Project directory (default: current directory)
    """
    from ..utils.project_scanner import ProjectScanner
    from pathlib import Path
    
    workspace_path = Path(workspace) if workspace else Path.cwd()
    
    console.print(f"\n[bold blue]Scanning Project:[/bold blue] {workspace_path}\n")
    
    with console.status("[bold blue]Analyzing project...", spinner="dots"):
        scanner = ProjectScanner(workspace_path)
        structure = scanner.scan()
        project_type = scanner.get_project_type()
    
    # Display results
    console.print(Panel.fit(
        f"""[bold]Project Analysis[/bold]

[bold cyan]Type:[/bold cyan] {project_type}
[bold cyan]Total Files:[/bold cyan] {structure['total_files']}
[bold cyan]Total Directories:[/bold cyan] {structure['total_dirs']}
[bold cyan]Languages:[/bold cyan] {', '.join(structure['languages']) if structure['languages'] else 'None detected'}

[bold]Key Files:[/bold]
{chr(10).join('  • ' + f for f in structure['key_files'][:15])}
{f"  ... and {len(structure['key_files']) - 15} more" if len(structure['key_files']) > 15 else ""}
""",
        border_style="blue",
        title="[bold blue]Project Structure[/bold blue]"
    ))
