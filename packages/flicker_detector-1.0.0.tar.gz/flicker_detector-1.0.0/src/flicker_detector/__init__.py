"""Umbrella distribution for flicker-detector[cpu] / flicker-detector[gpu]."""

from __future__ import annotations

__all__ = ["package_version"]


def package_version() -> str:
    try:
        from importlib.metadata import version

        return version("flicker-detector")
    except Exception:  # pragma: no cover
        return "0.0.0"
