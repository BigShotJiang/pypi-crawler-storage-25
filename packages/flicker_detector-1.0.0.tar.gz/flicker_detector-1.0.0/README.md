# flicker-detector

Umbrella package on PyPI. Install the **CPU** backend with `[cpu]` (same command names as the future GPU wheel).

## Install (Windows x64)

```powershell
py -m pip install "flicker-detector[cpu]"
```

After install, use:

- `flicker-detector` — local detection CLI  
- `flicker-detector-server` — web UI + HTTP API  
- `flicker-detector-client` — submit jobs to a running server  

### GPU backend (planned)

When **`flicker-detector-gpu`** is published, this package will gain a **`[gpu]`** extra (same three commands, different binaries). Until then, only `[cpu]` is available. Use **either** CPU or GPU extra, never both — script names overlap.

### Direct backend only

```powershell
py -m pip install flicker-detector-cpu
```

Same commands as with `[cpu]`; skips this umbrella package.
