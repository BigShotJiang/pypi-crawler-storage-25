# Authors

## Lead Author & Maintainer

**Bulent Soykan**
- **Role**: Principal Investigator, Lead Developer
- **Email**: soykanb@gmail.com
- **Website**: https://www.bulentsoykan.com/
- **Blog**: https://bulentsoykan.github.io/
- **LinkedIn**: https://www.linkedin.com/in/bulent-soykan/
- **GitHub**: https://github.com/bulentsoykan

### Contributions
- Conceptualization and design of CognitiveTwin framework
- Implementation of multi-modal fusion architecture
- Development of temporal dynamics modeling approach
- Experimental design and validation
- Comprehensive evaluation including fairness and robustness testing
- Documentation and publication-ready repository organization
- Achievement of state-of-the-art results (MAE: 1.619, R²: 0.682, AUROC: 0.912)

## Acknowledgments

This work builds upon research from the TADPOLE Challenge and ADNI consortium. Special thanks to the open-source community for providing foundational tools and libraries that made this research possible.

## Citation

If you use CognitiveTwin in your research, please cite:

```bibtex
@article{cognitivetwin2025,
  title={CognitiveTwin: AI-Driven Digital Twins for Personalized Cognitive Decline Prediction},
  author={Soykan, Bulent},
  journal={Nature Machine Intelligence},
  year={2025},
  url={https://github.com/bulentsoykan/cognitivedt}
}
```

## Contact

For research collaboration, technical questions, or clinical applications, please contact Bulent Soykan at soykanb@gmail.com or visit https://www.bulentsoykan.com/.