#!/usr/bin/env python3
"""
PyPI Publication Script for CognitiveTwin

This script automates the process of building and publishing the CognitiveTwin package to PyPI.

Author: Bulent Soykan (soykanb@gmail.com)
Repository: https://github.com/bulentsoykan/cognitivedt
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(cmd, check=True, capture_output=False):
    """Run a command and handle errors."""
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, check=check, capture_output=capture_output, text=True)
    if capture_output and result.stdout:
        print(result.stdout)
    return result

def check_prerequisites():
    """Check if all required tools are installed."""
    print("🔍 Checking prerequisites...")
    
    # Check if build and twine are installed
    try:
        import build
        print("✅ build package is available")
    except ImportError:
        print("❌ build package not found. Install with: pip install build")
        return False
    
    try:
        result = run_command(["twine", "--version"], capture_output=True)
        print("✅ twine is available")
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("❌ twine not found. Install with: pip install twine")
        return False
    
    return True

def clean_build_artifacts():
    """Clean previous build artifacts."""
    print("🧹 Cleaning build artifacts...")
    
    artifacts = ["dist", "build", "*.egg-info"]
    for artifact in artifacts:
        if artifact.startswith("*"):
            # Handle glob patterns
            import glob
            for path in glob.glob(artifact):
                if os.path.isdir(path):
                    import shutil
                    shutil.rmtree(path)
                    print(f"   Removed directory: {path}")
                else:
                    os.remove(path)
                    print(f"   Removed file: {path}")
        else:
            if os.path.exists(artifact):
                if os.path.isdir(artifact):
                    import shutil
                    shutil.rmtree(artifact)
                    print(f"   Removed directory: {artifact}")
                else:
                    os.remove(artifact)
                    print(f"   Removed file: {artifact}")

def run_tests():
    """Run tests before publishing."""
    print("🧪 Running tests...")
    try:
        run_command(["python", "-m", "pytest", "tests/", "-v"])
        print("✅ All tests passed")
        return True
    except subprocess.CalledProcessError:
        print("❌ Tests failed. Fix issues before publishing.")
        return False
    except FileNotFoundError:
        print("⚠️  Tests directory not found, skipping tests")
        return True

def build_package():
    """Build the package."""
    print("🔨 Building package...")
    try:
        run_command(["python", "-m", "build"])
        print("✅ Package built successfully")
        return True
    except subprocess.CalledProcessError:
        print("❌ Package build failed")
        return False

def check_package():
    """Check the built package."""
    print("🔍 Checking package...")
    try:
        run_command(["twine", "check", "dist/*"])
        print("✅ Package check passed")
        return True
    except subprocess.CalledProcessError:
        print("❌ Package check failed")
        return False

def upload_to_testpypi():
    """Upload to Test PyPI first."""
    print("📤 Uploading to Test PyPI...")
    try:
        run_command([
            "twine", "upload", 
            "--repository", "testpypi",
            "dist/*"
        ])
        print("✅ Uploaded to Test PyPI successfully")
        print("🔗 Check at: https://test.pypi.org/project/cognitivedt/")
        return True
    except subprocess.CalledProcessError:
        print("❌ Upload to Test PyPI failed")
        return False

def upload_to_pypi():
    """Upload to PyPI."""
    print("📤 Uploading to PyPI...")
    
    # Ask for confirmation
    response = input("Are you sure you want to upload to PyPI? This cannot be undone. (yes/no): ")
    if response.lower() != "yes":
        print("❌ Upload cancelled")
        return False
    
    try:
        run_command([
            "twine", "upload", 
            "dist/*"
        ])
        print("✅ Uploaded to PyPI successfully!")
        print("🔗 Check at: https://pypi.org/project/cognitivedt/")
        return True
    except subprocess.CalledProcessError:
        print("❌ Upload to PyPI failed")
        return False

def main():
    """Main publication workflow."""
    print("🚀 CognitiveTwin PyPI Publication Script")
    print("=" * 50)
    
    # Change to package directory
    script_dir = Path(__file__).parent
    package_dir = script_dir.parent
    os.chdir(package_dir)
    print(f"📁 Working directory: {package_dir}")
    
    # Run the publication workflow
    steps = [
        ("Checking prerequisites", check_prerequisites),
        ("Cleaning build artifacts", clean_build_artifacts),
        ("Running tests", run_tests),
        ("Building package", build_package),
        ("Checking package", check_package),
    ]
    
    for step_name, step_func in steps:
        print(f"\n{step_name}...")
        if not step_func():
            print(f"❌ {step_name} failed. Stopping.")
            sys.exit(1)
    
    print("\n🎉 Package is ready for publication!")
    print("\nChoose publication target:")
    print("1. Test PyPI (recommended first)")
    print("2. PyPI (production)")
    print("3. Both (Test PyPI first, then PyPI)")
    
    choice = input("Enter choice (1/2/3): ").strip()
    
    if choice == "1":
        upload_to_testpypi()
    elif choice == "2":
        upload_to_pypi()
    elif choice == "3":
        if upload_to_testpypi():
            print("\n" + "="*50)
            input("Press Enter after testing the Test PyPI package to continue to PyPI...")
            upload_to_pypi()
    else:
        print("❌ Invalid choice")
        sys.exit(1)
    
    print("\n🎉 Publication process completed!")
    print("\nNext steps:")
    print("1. Test the installation: pip install cognitivedt")
    print("2. Verify the package works: python -c 'import cognitivedt; print(cognitivedt.__version__)'")
    print("3. Check the PyPI page for correct metadata display")

if __name__ == "__main__":
    main()