#!/bin/bash

# PyPI Setup Script for CognitiveTwin
# Author: Bulent Soykan (soykanb@gmail.com)
# Repository: https://github.com/bulentsoykan/cognitivedt

echo "🚀 Setting up PyPI publication environment for CognitiveTwin"
echo "============================================================"

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ]; then
    echo "❌ Error: pyproject.toml not found. Please run this script from the project root."
    exit 1
fi

echo "📁 Current directory: $(pwd)"

# Install required packages
echo "📦 Installing publication dependencies..."

# Check if virtual environment is active
if [ -z "$VIRTUAL_ENV" ]; then
    echo "⚠️  No virtual environment detected. It's recommended to use one."
    echo "   Run: python -m venv venv && source venv/bin/activate"
    read -p "Continue anyway? (y/N): " continue_choice
    if [ "$continue_choice" != "y" ] && [ "$continue_choice" != "Y" ]; then
        echo "❌ Exiting. Please activate a virtual environment first."
        exit 1
    fi
fi

# Install build tools
python -m pip install --upgrade pip
python -m pip install --upgrade build twine

echo "✅ Build tools installed successfully"

# Verify tools
echo "🔍 Verifying installation..."
python -m build --version
twine --version

echo "✅ All tools verified"

# Setup PyPI configuration
echo ""
echo "🔐 PyPI Configuration"
echo "===================="
echo "You'll need to configure your PyPI credentials. Choose one option:"
echo ""
echo "Option 1: API Tokens (Recommended)"
echo "  1. Go to https://pypi.org/manage/account/token/"
echo "  2. Create a new API token"
echo "  3. Run: twine configure"
echo "  4. Username: __token__"
echo "  5. Password: <your-api-token>"
echo ""
echo "Option 2: Username/Password"
echo "  1. Run: twine configure"
echo "  2. Enter your PyPI username and password"
echo ""
echo "Option 3: Environment Variables"
echo "  export TWINE_USERNAME=__token__"
echo "  export TWINE_PASSWORD=<your-api-token>"
echo ""

read -p "Configure PyPI credentials now? (y/N): " config_choice
if [ "$config_choice" = "y" ] || [ "$config_choice" = "Y" ]; then
    echo "Running twine configure..."
    twine configure
    echo "✅ PyPI credentials configured"
fi

# Test PyPI setup (optional)
echo ""
echo "🧪 Test PyPI Setup"
echo "=================="
echo "For testing, you can also configure Test PyPI:"
echo "1. Go to https://test.pypi.org/manage/account/token/"
echo "2. Create a new API token"
echo "3. Add to ~/.pypirc:"
echo ""
cat << 'EOF'
[testpypi]
  username = __token__
  password = <your-test-pypi-token>
EOF
echo ""

# Create .pypirc template if it doesn't exist
if [ ! -f ~/.pypirc ]; then
    echo "📝 Creating .pypirc template..."
    cat > ~/.pypirc << 'EOF'
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = <your-pypi-token>

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = <your-test-pypi-token>
EOF
    echo "✅ Created ~/.pypirc template. Please edit it with your tokens."
else
    echo "ℹ️  ~/.pypirc already exists"
fi

echo ""
echo "🎉 Setup completed!"
echo ""
echo "Next steps:"
echo "1. Edit ~/.pypirc with your actual API tokens"
echo "2. Run the publication script: python scripts/publish_pypi.py"
echo "3. Or use manual commands (see PYPI_COMMANDS.md)"
echo ""
echo "📚 Documentation:"
echo "   - PyPI Guide: https://packaging.python.org/en/latest/tutorials/packaging-projects/"
echo "   - Twine: https://twine.readthedocs.io/"
echo ""