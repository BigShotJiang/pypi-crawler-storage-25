#!/usr/bin/env python3
"""
Package Check Script for CognitiveTwin

This script verifies that the package is ready for PyPI publication
by checking metadata, imports, and basic functionality.

Author: Bulent Soykan (soykanb@gmail.com)
Repository: https://github.com/bulentsoykan/cognitivedt
"""

import sys
import importlib.util
from pathlib import Path
import subprocess
import json

def check_pyproject_toml():
    """Check pyproject.toml for required fields."""
    print("🔍 Checking pyproject.toml...")
    
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        print("❌ pyproject.toml not found")
        return False
    
    import tomllib
    try:
        with open(pyproject_path, "rb") as f:
            config = tomllib.load(f)
    except Exception as e:
        print(f"❌ Error reading pyproject.toml: {e}")
        return False
    
    # Check required fields
    project = config.get("project", {})
    required_fields = ["name", "version", "description", "authors"]
    missing_fields = []
    
    for field in required_fields:
        if field not in project:
            missing_fields.append(field)
        else:
            print(f"   ✅ {field}: {project[field]}")
    
    if missing_fields:
        print(f"❌ Missing required fields: {missing_fields}")
        return False
    
    # Check URLs
    urls = config.get("project", {}).get("urls", {})
    if urls:
        print("   URLs:")
        for name, url in urls.items():
            print(f"      {name}: {url}")
    
    return True

def check_package_structure():
    """Check package directory structure."""
    print("\n🔍 Checking package structure...")
    
    package_dir = Path("cognitivedt")
    if not package_dir.exists():
        print("❌ Package directory 'cognitivedt' not found")
        return False
    
    init_file = package_dir / "__init__.py"
    if not init_file.exists():
        print("❌ __init__.py not found in package directory")
        return False
    
    print("   ✅ Package directory exists")
    print("   ✅ __init__.py found")
    
    # Check key modules
    key_modules = ["data", "io", "representation", "dynamics", "evaluation"]
    for module in key_modules:
        module_path = package_dir / module
        if module_path.exists():
            print(f"   ✅ {module}/ directory found")
        else:
            print(f"   ⚠️  {module}/ directory not found")
    
    return True

def check_imports():
    """Check that the package can be imported."""
    print("\n🔍 Checking package imports...")
    
    try:
        import cognitivedt
        print("   ✅ cognitivedt imports successfully")
        
        # Check version
        version = getattr(cognitivedt, '__version__', None)
        if version:
            print(f"   ✅ Version: {version}")
        else:
            print("   ⚠️  No __version__ attribute found")
        
        # Check author
        author = getattr(cognitivedt, '__author__', None)
        if author:
            print(f"   ✅ Author: {author}")
        else:
            print("   ⚠️  No __author__ attribute found")
        
        # Try importing key classes
        from cognitivedt import PatientData, VisitData, TADPOLELoader
        print("   ✅ Key classes import successfully")
        
        return True
        
    except ImportError as e:
        print(f"   ❌ Import failed: {e}")
        return False
    except Exception as e:
        print(f"   ❌ Unexpected error: {e}")
        return False

def check_dependencies():
    """Check if all dependencies are available."""
    print("\n🔍 Checking dependencies...")
    
    # Read dependencies from pyproject.toml
    try:
        import tomllib
        with open("pyproject.toml", "rb") as f:
            config = tomllib.load(f)
        
        deps = config.get("project", {}).get("dependencies", [])
        if not deps:
            print("   ⚠️  No dependencies listed in pyproject.toml")
            return True
        
        print(f"   Found {len(deps)} dependencies")
        
        # Check each dependency
        missing_deps = []
        for dep in deps:
            # Extract package name (before any version specifiers)
            pkg_name = dep.split(">=")[0].split("==")[0].split("~=")[0].strip()
            
            try:
                __import__(pkg_name)
                print(f"   ✅ {pkg_name}")
            except ImportError:
                missing_deps.append(pkg_name)
                print(f"   ❌ {pkg_name} (not installed)")
        
        if missing_deps:
            print(f"\n   ⚠️  Missing dependencies: {missing_deps}")
            print("   Install with: pip install -e .")
            return False
        
        return True
        
    except Exception as e:
        print(f"   ❌ Error checking dependencies: {e}")
        return False

def check_readme():
    """Check README file."""
    print("\n🔍 Checking README...")
    
    readme_files = ["README.md", "README.rst", "README.txt"]
    for readme in readme_files:
        if Path(readme).exists():
            print(f"   ✅ {readme} found")
            
            # Check file size
            size = Path(readme).stat().st_size
            if size < 100:
                print(f"   ⚠️  {readme} is very short ({size} bytes)")
            else:
                print(f"   ✅ {readme} has good length ({size} bytes)")
            
            return True
    
    print("   ❌ No README file found")
    return False

def check_license():
    """Check LICENSE file."""
    print("\n🔍 Checking LICENSE...")
    
    license_files = ["LICENSE", "LICENSE.txt", "LICENSE.md"]
    for license_file in license_files:
        if Path(license_file).exists():
            print(f"   ✅ {license_file} found")
            return True
    
    print("   ❌ No LICENSE file found")
    return False

def run_build_test():
    """Test building the package."""
    print("\n🔍 Testing package build...")
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "build", "--outdir", "dist_test"],
            capture_output=True,
            text=True,
            check=True
        )
        print("   ✅ Package builds successfully")
        
        # Check outputs
        dist_test = Path("dist_test")
        if dist_test.exists():
            files = list(dist_test.glob("*"))
            print(f"   ✅ Created {len(files)} distribution files:")
            for file in files:
                print(f"      - {file.name}")
            
            # Clean up test build
            import shutil
            shutil.rmtree(dist_test)
            
        return True
        
    except subprocess.CalledProcessError as e:
        print("   ❌ Package build failed")
        print(f"   Error: {e.stderr}")
        return False
    except FileNotFoundError:
        print("   ❌ 'build' module not found. Install with: pip install build")
        return False

def main():
    """Run all package checks."""
    print("🔍 CognitiveTwin Package Verification")
    print("=" * 40)
    
    checks = [
        ("pyproject.toml configuration", check_pyproject_toml),
        ("Package structure", check_package_structure),
        ("Package imports", check_imports),
        ("Dependencies", check_dependencies),
        ("README file", check_readme),
        ("LICENSE file", check_license),
        ("Build test", run_build_test),
    ]
    
    passed = 0
    total = len(checks)
    
    for check_name, check_func in checks:
        if check_func():
            passed += 1
        else:
            print()  # Add spacing after failed checks
    
    print("\n" + "=" * 40)
    print(f"📊 Results: {passed}/{total} checks passed")
    
    if passed == total:
        print("🎉 Package is ready for PyPI publication!")
        print("\nNext steps:")
        print("1. Run: python scripts/publish_pypi.py")
        print("2. Or follow manual steps in PYPI_COMMANDS.md")
        return 0
    else:
        print("❌ Some checks failed. Please fix the issues above.")
        print("\nCommon fixes:")
        print("- Install dependencies: pip install -e '.[all]'")
        print("- Install build tools: pip install build twine")
        print("- Check pyproject.toml syntax")
        return 1

if __name__ == "__main__":
    sys.exit(main())