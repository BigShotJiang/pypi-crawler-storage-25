# CognitiveTwin: Data Sources Guide

## Primary Dataset: TADPOLE Challenge (Recommended Starting Point)

### TADPOLE (The Alzheimer's Disease Prediction Of Longitudinal Evolution)
- **URL:** https://tadpole.grand-challenge.org/
- **Source:** Derived from ADNI (Alzheimer's Disease Neuroimaging Initiative)
- **Access:** Free after registration at https://adni.loni.usc.edu/
- **Format:** CSV files
- **Size:** ~1,737 subjects, ~12,741 visits
- **Contents:**
  - **Cognitive scores:** MMSE, ADAS-Cog (ADAS11, ADAS13), CDR-SB, RAVLT, FAQ
  - **MRI volumetrics:** Hippocampal volume, ventricular volume, entorhinal cortex,
    whole brain volume, fusiform gyrus, mid-temporal cortex (FreeSurfer-derived)
  - **PET biomarkers:** FDG-PET, AV45 (amyloid PET) SUVRs
  - **CSF biomarkers:** Abeta42, total Tau, phospho-Tau (pTau)
  - **Genetics:** APOE genotype (ε2/ε3/ε4 alleles)
  - **Demographics:** Age, sex, education, ethnicity, marital status
  - **Diagnosis:** CN (Cognitively Normal), MCI, Dementia at each visit
- **Key Files:**
  - `TADPOLE_D1_D2.csv` — Main longitudinal dataset (training)
  - `TADPOLE_D3.csv` — Prospective test set
  - `TADPOLE_D4_corr.csv` — Cross-sectional test set
- **License:** ADNI Data Use Agreement (academic research)
- **Columns of Interest (exact TADPOLE column names):**
  ```
  RID              — Patient ID (integer)
  VISCODE          — Visit code (bl, m06, m12, m18, m24, ...)
  EXAMDATE         — Examination date
  DX               — Diagnosis (CN, MCI, Dementia)
  DX_bl            — Baseline diagnosis
  AGE              — Age at visit
  PTGENDER         — Sex (Male/Female)
  PTEDUCAT         — Years of education
  PTETHCAT         — Ethnicity
  PTRACCAT         — Race
  PTMARRY          — Marital status
  APOE4            — Number of APOE-ε4 alleles (0, 1, 2)
  MMSE             — Mini-Mental State Examination
  ADAS11           — ADAS-Cog 11 items
  ADAS13           — ADAS-Cog 13 items
  CDRSB            — Clinical Dementia Rating Sum of Boxes
  RAVLT_immediate  — Rey Auditory Verbal Learning Test (immediate)
  RAVLT_learning   — RAVLT learning score
  RAVLT_forgetting — RAVLT forgetting score
  RAVLT_perc_forgetting — RAVLT percent forgetting
  FAQ              — Functional Activities Questionnaire
  Ventricles       — Ventricular volume (mm³)
  Hippocampus      — Hippocampal volume (mm³)
  WholeBrain       — Whole brain volume (mm³)
  Entorhinal       — Entorhinal cortex thickness (mm)
  Fusiform         — Fusiform gyrus volume (mm³)
  MidTemp          — Middle temporal gyrus volume (mm³)
  ICV              — Intracranial volume (mm³)
  FDG              — FDG-PET SUVR
  AV45             — Amyloid PET SUVR (florbetapir)
  ABETA            — CSF Amyloid-beta 42 (pg/mL)
  TAU              — CSF Total Tau (pg/mL)
  PTAU             — CSF Phospho-Tau (pg/mL)
  ```

## Secondary / Supplementary Datasets

### 1. ADNI (Full Dataset)
- **URL:** https://adni.loni.usc.edu/
- **Phases:** ADNI-1, ADNI-GO, ADNI-2, ADNI-3, ADNI-4
- **Superset of TADPOLE** — includes additional imaging, genetics (GWAS),
  plasma biomarkers, digital biomarkers
- **Use for:** Extended validation, additional modalities beyond TADPOLE

### 2. OASIS (Open Access Series of Imaging Studies)
- **URL:** https://www.oasis-brains.org/
- **OASIS-3:** 1,098 subjects, 2,168 MRI sessions over 30 years
- **Contents:** MRI, PET (amyloid, tau), clinical assessments, CDR
- **Access:** Free after registration
- **Use for:** External validation cohort

### 3. NACC (National Alzheimer's Coordinating Center)
- **URL:** https://naccdata.org/
- **Size:** >45,000 subjects from 39 Alzheimer's Disease Research Centers
- **Contents:** Uniform Data Set (UDS) — demographics, cognitive tests,
  clinical diagnosis, neuropathology
- **Access:** Free for researchers after application
- **Use for:** Large-scale external validation, fairness analysis

### 4. AIBL (Australian Imaging, Biomarker & Lifestyle)
- **URL:** https://aibl.csiro.au/
- **Size:** 1,100+ subjects, 5+ years follow-up
- **Contents:** Cognitive tests, MRI, PET (amyloid), blood biomarkers, genetics
- **Access:** Data sharing agreement required
- **Use for:** Cross-cohort generalization (non-US population)

### 5. UK Biobank
- **URL:** https://www.ukbiobank.ac.uk/
- **Size:** 500,000 participants (subset with brain imaging ~50,000)
- **Contents:** Cognitive tests, MRI, genetics, blood, lifestyle
- **Access:** Application-based
- **Use for:** Population-level validation, genetic analyses

### 6. HCP (Human Connectome Project — Aging)
- **URL:** https://www.humanconnectome.org/study/hcp-aging
- **Size:** 1,200+ subjects aged 36-100
- **Contents:** High-resolution MRI, cognitive assessments
- **Use for:** Healthy aging reference trajectories

## Recommended Data Strategy

### Phase 1 — Development (Use TADPOLE)
1. Download `TADPOLE_D1_D2.csv` from the TADPOLE challenge
2. Use 70/15/15 train/val/test split stratified by baseline DX and APOE4
3. All schemas in `cognitivedt/data/schemas.py` map directly to TADPOLE columns

### Phase 2 — Internal Validation
1. Use `TADPOLE_D3.csv` (prospective) as temporal validation set
2. Test robustness to missing data patterns in real TADPOLE data

### Phase 3 — External Validation
1. Map OASIS-3 and NACC variables to CognitiveTwin schemas
2. Evaluate cross-cohort generalization without retraining
3. Fine-tune with small samples (transfer learning)

### Phase 4 — Scale & Generalize
1. UK Biobank for population-level validation
2. AIBL for non-US cohort validation
3. Federated learning across multiple sites

## Quick Start: Getting TADPOLE Data

```bash
# 1. Register at https://adni.loni.usc.edu/ (takes 1-3 days for approval)
# 2. Navigate to: Study Data → Test Data → TADPOLE Challenge Data
# 3. Download TADPOLE_D1_D2.csv
# 4. Place in your data directory:

mkdir -p data/raw
mv ~/Downloads/TADPOLE_D1_D2.csv data/raw/

# 5. Use the CognitiveTwin loader:
python -c "
from cognitivedt.io.loader import TADPOLELoader
loader = TADPOLELoader(data_dir='data/raw')
patients = loader.load_dataset('TADPOLE_D1_D2.csv')
print(f'Loaded {len(patients)} patients')
"
```
