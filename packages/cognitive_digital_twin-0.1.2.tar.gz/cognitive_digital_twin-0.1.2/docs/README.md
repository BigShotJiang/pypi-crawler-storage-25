# CognitiveTwin Documentation

Welcome to the CognitiveTwin documentation! This directory contains comprehensive documentation for the AI-driven digital twins framework for cognitive decline prediction.

## 📚 Documentation Structure

### 📄 Research Paper
- **[Manuscript](paper/manuscript.md)**: Complete research paper with methodology, results, and discussion
- **[Supplementary Materials](paper/)**: Additional figures, tables, and detailed analyses

### 🔬 Experimental Documentation  
- **[Experimental Results](experiments/results.md)**: Detailed quantitative results and performance metrics
- **[Generated Figures](experiments/figures/)**: Publication-ready figures and visualizations
- **[LaTeX Tables](experiments/tables/)**: Formatted tables for research publication
- **[Raw Results](experiments/)**: Complete experimental outputs and data files

### 🛠️ Technical Guides
- **[Technical Implementation Guide](technical_guide.md)**: Architecture details and implementation notes
- **[Data Acquisition Guide](data_guide.md)**: Instructions for obtaining and setting up TADPOLE data
- **[API Reference](api/)**: Detailed API documentation (generated from docstrings)

### 🎯 Key Results Summary

Our corrected experimental results demonstrate state-of-the-art performance:

| Metric | CognitiveTwin | Previous SOTA | Improvement |
|--------|---------------|---------------|-------------|
| MAE (MMSE points) | **1.619** | 3.080 | **47.5%** |
| R² | **0.682** | 0.280 | **143.6%** |
| AUROC | **0.912** | 0.810 | **12.6%** |
| ECE | **0.054** | 0.089 | **39.3%** |

### 🔍 Navigation Guide

#### For Researchers
1. Start with the [Research Paper](paper/manuscript.md) for complete methodology
2. Review [Experimental Results](experiments/results.md) for detailed quantitative analysis
3. Examine [Generated Figures](experiments/figures/) for publication-quality visualizations

#### For Developers  
1. Read the [Technical Implementation Guide](technical_guide.md) for architecture details
2. Follow the [Data Acquisition Guide](data_guide.md) to set up datasets
3. Use the [API Reference](api/) for detailed function documentation

#### For Reproducibility
1. Follow installation instructions in the main [README](../README.md)
2. Use scripts in [experiments/scripts/](../experiments/scripts/) to reproduce results
3. Refer to [experimental results](experiments/results.md) for expected outputs

## 🔗 Quick Links

### External Resources
- [TADPOLE Challenge](https://tadpole.grand-challenge.org/) - Dataset source
- [ADNI Database](http://adni.loni.usc.edu/) - Original data collection
- [GitHub Repository](https://github.com/bulentsoykan/cognitivedt) - Source code

### Internal Documentation
- [Main README](../README.md) - Project overview and quick start
- [Contributing Guidelines](../CONTRIBUTING.md) - How to contribute to the project
- [Changelog](../CHANGELOG.md) - Project version history
- [License](../LICENSE) - MIT license details

## 📊 Figure Gallery

### Model Performance
![Model Performance Summary](experiments/figures/model_performance_summary.png)

*Comprehensive performance comparison showing CognitiveTwin's superior accuracy across all metrics*

### Temporal Dynamics
![Trajectory Example](experiments/figures/trajectory_uq_example.png)

*Example patient trajectory showing the model's ability to capture cognitive decline patterns with uncertainty quantification*

### Prediction Quality
![Prediction Scatter](experiments/figures/prediction_scatter.png)

*Scatter plot demonstrating strong correlation (R² = 0.682) between predicted and actual MMSE scores*

## 🏆 Key Achievements

### Technical Innovations
- **Multi-Modal Fusion**: Transformer-based cross-modal attention mechanism
- **Temporal Dynamics**: GRU-based modeling of disease progression patterns  
- **Uncertainty Quantification**: Calibrated prediction intervals for clinical decision support
- **Robustness**: Maintained performance under missing data and distribution shift

### Clinical Impact
- **Personalized Predictions**: Individual cognitive trajectories with confidence intervals
- **Fair Performance**: Balanced accuracy across demographic groups
- **Clinical Utility**: 46% reduction in number needed to screen
- **Real-World Robustness**: Minimal degradation with realistic data quality issues

### Methodological Contributions
- **Comprehensive Evaluation**: Fairness, robustness, and calibration assessment
- **Publication Standards**: Reproducible experiments with detailed documentation
- **Open Science**: Complete code and documentation for community use

## 🤝 Community

### Get Involved
- **Issues**: Report bugs or request features on [GitHub Issues](https://github.com/bulentsoykan/cognitivedt/issues)
- **Discussions**: Join conversations on [GitHub Discussions](https://github.com/bulentsoykan/cognitivedt/discussions)  
- **Contributing**: Follow our [Contributing Guidelines](../CONTRIBUTING.md)

### Citation
If you use CognitiveTwin in your research, please cite our work:

```bibtex
@article{cognitivetwin2025,
  title={CognitiveTwin: AI-Driven Digital Twins for Personalized Cognitive Decline Prediction},
  author={Soykan, Bulent},
  journal={Nature Machine Intelligence},
  year={2025},
  url={https://github.com/bulentsoykan/cognitivedt}
}
```

---

**📧 Contact**: For questions about documentation or research, please open an issue or contact the maintainers directly.