"""Data loading module for the CognitiveTwin framework.

This module provides :class:`TADPOLELoader`, the primary entry-point for
reading raw TADPOLE CSV files and converting them into a list of validated
:class:`~cognitivedt.data.base.PatientData` objects.

Workflow
--------
1. Read the CSV with ``pandas``.
2. Per-row cleaning (strip whitespace, parse dates, coerce numerics).
3. Group rows by patient (``RID``).
4. For each patient, build :class:`VisitData` per visit and wrap them in a
   :class:`PatientData`.
5. Return a list of ``PatientData`` ready for downstream consumption.

Usage
-----
>>> from cognitivedt.io.loader import TADPOLELoader
>>> loader = TADPOLELoader(data_dir="data/raw")
>>> patients = loader.load_dataset("TADPOLE_D1_D2.csv")
>>> print(f"Loaded {len(patients)} patients with "
...       f"{sum(p.n_visits for p in patients)} total visits.")
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd

from cognitivedt.data.base import PatientData, VisitData
from cognitivedt.data.schemas import (
    CognitiveScores,
    CSFBiomarkers,
    Demographics,
    Diagnosis,
    GeneticProfile,
    MRIVolumetrics,
    PETBiomarkers,
    Sex,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# TADPOLE column -> schema field mapping
# ---------------------------------------------------------------------------

# Maps TADPOLE CSV column names to the corresponding Pydantic field names.
# The loader uses these maps to extract the right columns during parsing.

_DEMOGRAPHIC_MAP: Dict[str, str] = {
    "AGE": "age",
    "PTGENDER": "sex",
    "PTEDUCAT": "education_years",
    "PTETHCAT": "ethnicity",
    "PTRACCAT": "race",
    "PTMARRY": "marital_status",
}

_COGNITIVE_MAP: Dict[str, str] = {
    "MMSE": "mmse",
    "ADAS11": "adas11",
    "ADAS13": "adas13",
    "CDRSB": "cdrsb",
    "RAVLT_immediate": "ravlt_immediate",
    "RAVLT_learning": "ravlt_learning",
    "RAVLT_forgetting": "ravlt_forgetting",
    "RAVLT_perc_forgetting": "ravlt_perc_forgetting",
    "FAQ": "faq",
}

_MRI_MAP: Dict[str, str] = {
    "Ventricles": "ventricles",
    "Hippocampus": "hippocampus",
    "WholeBrain": "whole_brain",
    "Entorhinal": "entorhinal",
    "Fusiform": "fusiform",
    "MidTemp": "mid_temp",
    "ICV": "icv",
}

_PET_MAP: Dict[str, str] = {
    "FDG": "fdg",
    "AV45": "av45",
}

_CSF_MAP: Dict[str, str] = {
    "ABETA": "abeta",
    "TAU": "tau",
    "PTAU": "ptau",
}


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _safe_float(value: object) -> Optional[float]:
    """Coerce *value* to ``float`` or return ``None`` on failure."""
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    try:
        result = float(value)  # type: ignore[arg-type]
        if np.isnan(result):
            return None
        return result
    except (ValueError, TypeError):
        return None


def _safe_int(value: object) -> Optional[int]:
    """Coerce *value* to ``int`` or return ``None`` on failure."""
    f = _safe_float(value)
    if f is None:
        return None
    return int(round(f))


def _parse_sex(raw: object) -> Sex:
    """Map TADPOLE gender strings to :class:`Sex` enum."""
    s = str(raw).strip().lower()
    if s in ("male", "m", "1"):
        return Sex.MALE
    if s in ("female", "f", "2"):
        return Sex.FEMALE
    # Default  TADPOLE should only contain Male/Female
    logger.warning("Unrecognised sex value '%s'; defaulting to Male.", raw)
    return Sex.MALE


def _parse_diagnosis(raw: object) -> Optional[Diagnosis]:
    """Map TADPOLE diagnosis strings to :class:`Diagnosis` enum."""
    if raw is None or (isinstance(raw, float) and np.isnan(raw)):
        return None
    s = str(raw).strip()
    mapping = {
        "CN": Diagnosis.CN,
        "NL": Diagnosis.CN,
        "NL to MCI": Diagnosis.MCI,
        "SMC": Diagnosis.CN,
        "EMCI": Diagnosis.MCI,
        "LMCI": Diagnosis.MCI,
        "MCI": Diagnosis.MCI,
        "MCI to Dementia": Diagnosis.DEMENTIA,
        "Dementia": Diagnosis.DEMENTIA,
        "AD": Diagnosis.DEMENTIA,
    }
    dx = mapping.get(s)
    if dx is None:
        logger.debug("Unknown diagnosis string '%s'; returning None.", s)
    return dx


def _visit_code_to_months(viscode: str) -> float:
    """Convert a TADPOLE visit code to months from baseline.

    Examples: ``"bl"`` -> 0.0, ``"m06"`` -> 6.0, ``"m24"`` -> 24.0.
    """
    v = str(viscode).strip().lower()
    if v in ("bl", "sc", "scmri"):
        return 0.0
    if v.startswith("m"):
        try:
            return float(v[1:])
        except ValueError:
            pass
    # Fallback: try to parse as a plain number
    try:
        return float(v)
    except ValueError:
        logger.warning("Cannot parse visit code '%s'; treating as 0.", viscode)
        return 0.0


def _extract_submodel(
    row: pd.Series,
    col_map: Dict[str, str],
    *,
    as_float: bool = True,
) -> Dict[str, object]:
    """Extract fields from a DataFrame row using a column-mapping dict.

    Parameters
    ----------
    row : pd.Series
        A single row from the TADPOLE DataFrame.
    col_map : dict
        Mapping of ``{TADPOLE_column: schema_field_name}``.
    as_float : bool
        If ``True``, coerce every extracted value through :func:`_safe_float`.

    Returns
    -------
    dict
        ``{schema_field_name: value}`` ready for Pydantic model construction.
    """
    out: Dict[str, object] = {}
    for csv_col, field_name in col_map.items():
        raw = row.get(csv_col)
        if as_float:
            out[field_name] = _safe_float(raw)
        else:
            out[field_name] = raw if not (isinstance(raw, float) and np.isnan(raw)) else None
    return out


# ---------------------------------------------------------------------------
# Row -> VisitData builder
# ---------------------------------------------------------------------------

def _row_to_visit(row: pd.Series) -> VisitData:
    """Convert a single TADPOLE DataFrame row into a :class:`VisitData`.

    Parameters
    ----------
    row : pd.Series
        One row of the TADPOLE CSV, as read by ``pandas``.

    Returns
    -------
    VisitData
        Validated visit record.
    """
    viscode = str(row.get("VISCODE", "bl"))
    months = _visit_code_to_months(viscode)

    # -- Demographics -------------------------------------------------------
    age_val = _safe_float(row.get("AGE"))
    edu_val = _safe_float(row.get("PTEDUCAT"))
    demographics = Demographics(
        age=age_val if age_val is not None else 0.0,
        sex=_parse_sex(row.get("PTGENDER")),
        education_years=edu_val if edu_val is not None else 0.0,
        ethnicity=row.get("PTETHCAT") if not (
            isinstance(row.get("PTETHCAT"), float) and np.isnan(row.get("PTETHCAT"))
        ) else None,
        race=row.get("PTRACCAT") if not (
            isinstance(row.get("PTRACCAT"), float) and np.isnan(row.get("PTRACCAT"))
        ) else None,
        marital_status=row.get("PTMARRY") if not (
            isinstance(row.get("PTMARRY"), float) and np.isnan(row.get("PTMARRY"))
        ) else None,
    )

    # -- Cognitive scores ---------------------------------------------------
    cog_fields = _extract_submodel(row, _COGNITIVE_MAP)
    cognitive = CognitiveScores(**cog_fields)  # type: ignore[arg-type]

    # -- MRI ----------------------------------------------------------------
    mri_fields = _extract_submodel(row, _MRI_MAP)
    has_mri = any(v is not None for v in mri_fields.values())
    mri = MRIVolumetrics(**mri_fields) if has_mri else None  # type: ignore[arg-type]

    # -- PET ----------------------------------------------------------------
    pet_fields = _extract_submodel(row, _PET_MAP)
    has_pet = any(v is not None for v in pet_fields.values())
    pet = PETBiomarkers(**pet_fields) if has_pet else None  # type: ignore[arg-type]

    # -- CSF ----------------------------------------------------------------
    csf_fields = _extract_submodel(row, _CSF_MAP)
    has_csf = any(v is not None for v in csf_fields.values())
    csf = CSFBiomarkers(**csf_fields) if has_csf else None  # type: ignore[arg-type]

    # -- Exam date ----------------------------------------------------------
    exam_date = None
    raw_date = row.get("EXAMDATE")
    if raw_date is not None and not (isinstance(raw_date, float) and np.isnan(raw_date)):
        try:
            exam_date = pd.Timestamp(raw_date).date()
        except (ValueError, TypeError):
            pass

    return VisitData(
        visit_code=viscode,
        exam_date=exam_date,
        months_from_baseline=months,
        diagnosis=_parse_diagnosis(row.get("DX")),
        demographics=demographics,
        cognitive=cognitive,
        mri=mri,
        pet=pet,
        csf=csf,
    )


# ---------------------------------------------------------------------------
# Main loader class
# ---------------------------------------------------------------------------

class TADPOLELoader:
    """Loader for TADPOLE-format CSV files.

    Parameters
    ----------
    data_dir : str or Path
        Root directory containing raw CSV files.
    min_visits : int
        Minimum number of visits a patient must have to be included
        (default 2  need at least one follow-up for longitudinal modelling).
    """

    def __init__(self, data_dir: Union[str, Path], min_visits: int = 2) -> None:
        self.data_dir = Path(data_dir)
        self.min_visits = min_visits

        if not self.data_dir.exists():
            raise FileNotFoundError(
                f"Data directory does not exist: {self.data_dir}"
            )

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    def load_dataset(
        self,
        filename: str = "TADPOLE_D1_D2.csv",
        *,
        patient_ids: Optional[Sequence[str]] = None,
    ) -> List[PatientData]:
        """Load and parse a TADPOLE CSV into validated :class:`PatientData`.

        Parameters
        ----------
        filename : str
            Name of the CSV file within :attr:`data_dir`.
        patient_ids : sequence of str, optional
            If provided, only load these patient IDs (RID values).
            Useful for debugging or loading a specific subset.

        Returns
        -------
        list[PatientData]
            One entry per patient, sorted by patient ID.

        Raises
        ------
        FileNotFoundError
            If the CSV file does not exist.
        """
        filepath = self.data_dir / filename
        if not filepath.exists():
            raise FileNotFoundError(f"CSV file not found: {filepath}")

        logger.info("Reading %s &", filepath)
        df = pd.read_csv(filepath, low_memory=False)
        logger.info("Loaded DataFrame with %d rows, %d columns.", *df.shape)

        # Ensure RID is a string for consistent keying
        df["RID"] = df["RID"].astype(str)

        if patient_ids is not None:
            id_set = set(str(pid) for pid in patient_ids)
            df = df[df["RID"].isin(id_set)]
            logger.info("Filtered to %d rows for %d requested patients.",
                        len(df), len(id_set))

        patients = self._build_patients(df)
        logger.info(
            "Built %d patients (min_visits=%d). Total visits: %d.",
            len(patients),
            self.min_visits,
            sum(p.n_visits for p in patients),
        )
        return patients

    def load_and_split(
        self,
        filename: str = "TADPOLE_D1_D2.csv",
        train_ratio: float = 0.70,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
        random_state: int = 42,
    ) -> Tuple[List[PatientData], List[PatientData], List[PatientData]]:
        """Load data and split patients into train / val / test sets.

        The split is **patient-level** (no data leakage) and stratified by
        baseline diagnosis.

        Parameters
        ----------
        filename : str
            CSV filename inside :attr:`data_dir`.
        train_ratio, val_ratio, test_ratio : float
            Proportions for each split.  Must sum to 1.0.
        random_state : int
            Random seed for reproducibility.

        Returns
        -------
        tuple[list[PatientData], list[PatientData], list[PatientData]]
            ``(train, val, test)`` patient lists.
        """
        if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-6:
            raise ValueError("Split ratios must sum to 1.0")

        patients = self.load_dataset(filename)
        rng = np.random.RandomState(random_state)

        # Stratify by baseline diagnosis
        strata: Dict[str, List[PatientData]] = {}
        for p in patients:
            key = p.baseline_diagnosis.value if p.baseline_diagnosis else "Unknown"
            strata.setdefault(key, []).append(p)

        train: List[PatientData] = []
        val: List[PatientData] = []
        test: List[PatientData] = []

        for _key, group in sorted(strata.items()):
            rng.shuffle(group)  # type: ignore[arg-type]
            n = len(group)
            n_train = int(n * train_ratio)
            n_val = int(n * val_ratio)
            train.extend(group[:n_train])
            val.extend(group[n_train : n_train + n_val])
            test.extend(group[n_train + n_val :])

        logger.info(
            "Split: train=%d, val=%d, test=%d (total=%d).",
            len(train), len(val), len(test), len(patients),
        )
        return train, val, test

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _build_patients(self, df: pd.DataFrame) -> List[PatientData]:
        """Group rows by RID and construct :class:`PatientData` objects."""
        patients: List[PatientData] = []

        for rid, group_df in df.groupby("RID"):
            visits: List[VisitData] = []
            for _, row in group_df.iterrows():
                try:
                    visit = _row_to_visit(row)
                    visits.append(visit)
                except Exception:
                    logger.debug(
                        "Skipping row for RID=%s, VISCODE=%s due to parsing error.",
                        rid,
                        row.get("VISCODE"),
                        exc_info=True,
                    )

            if len(visits) < self.min_visits:
                continue

            # Genetics (time-invariant  take from first non-null row)
            apoe_raw = _safe_int(group_df["APOE4"].dropna().iloc[0]) if "APOE4" in group_df.columns and not group_df["APOE4"].dropna().empty else None
            genetics = GeneticProfile(apoe4_count=apoe_raw) if apoe_raw is not None else None

            # Baseline diagnosis
            bl_dx = None
            if "DX_bl" in group_df.columns:
                bl_dx = _parse_diagnosis(group_df["DX_bl"].iloc[0])

            patient = PatientData(
                patient_id=str(rid),
                genetics=genetics,
                baseline_diagnosis=bl_dx,
                visits=visits,
            )
            patients.append(patient)

        # Sort by patient ID for deterministic ordering
        patients.sort(key=lambda p: p.patient_id)
        return patients

    # -----------------------------------------------------------------------
    # Utility methods
    # -----------------------------------------------------------------------

    def describe(self, patients: List[PatientData]) -> Dict[str, object]:
        """Return a summary dictionary describing a patient list.

        Useful for quick quality checks after loading.
        """
        n_patients = len(patients)
        n_visits = sum(p.n_visits for p in patients)
        follow_ups = [p.follow_up_months for p in patients]
        dx_counts: Dict[str, int] = {}
        for p in patients:
            key = p.baseline_diagnosis.value if p.baseline_diagnosis else "Unknown"
            dx_counts[key] = dx_counts.get(key, 0) + 1

        return {
            "n_patients": n_patients,
            "n_visits": n_visits,
            "mean_visits_per_patient": n_visits / max(n_patients, 1),
            "mean_follow_up_months": float(np.mean(follow_ups)) if follow_ups else 0.0,
            "median_follow_up_months": float(np.median(follow_ups)) if follow_ups else 0.0,
            "baseline_diagnosis_counts": dx_counts,
        }
