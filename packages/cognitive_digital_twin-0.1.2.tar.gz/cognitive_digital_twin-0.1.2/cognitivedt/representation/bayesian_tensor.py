"""Bayesian Tensor Decomposition fusion model.

Treats multi-modal longitudinal data as a 3-D tensor
(Patient -> Time -> Feature) and performs probabilistic low-rank
decomposition to obtain a compact patient representation.

Advantages over point-estimate tensor methods:
* Naturally handles missing entries (marginalise over unknowns).
* Provides per-element uncertainty estimates.
* Prior distributions regularise the decomposition, avoiding overfitting
  on sparse clinical data.

The current implementation uses a variational inference approach with
diagonal Gaussian approximate posteriors over the factor matrices.

Requires the optional ``pyro-ppl`` dependency for full Bayesian inference::

    pip install cognitivedt[bayesian]
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn

from cognitivedt.representation.base import BaseFusionModel


class BayesianTensorFusionModel(BaseFusionModel):
    """Bayesian Tensor Decomposition for multi-modal fusion.

    Parameters
    ----------
    modality_dims : dict[str, int]
        ``{modality_name: raw_feature_dim}``.
    rank : int
        Rank of the tensor decomposition (controls capacity vs. parsimony).
    output_dim_size : int
        Dimensionality of the final fused representation.
    n_time_steps : int
        Maximum number of longitudinal time-steps to support.
    prior_std : float
        Standard deviation of the Gaussian prior on factor matrices.
    dropout : float
        Dropout rate applied after the fusion layer.
    """

    def __init__(
        self,
        modality_dims: Dict[str, int],
        rank: int = 32,
        output_dim_size: int = 256,
        n_time_steps: int = 20,
        prior_std: float = 1.0,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self._output_dim = output_dim_size
        self.rank = rank
        self.prior_std = prior_std
        self.modality_names = sorted(modality_dims.keys())

        total_feature_dim = sum(modality_dims.values())

        # --- Variational parameters for factor matrices --------------------
        # Factor U (patient/batch dimension)  learned per-forward-pass
        # Factor V (time dimension)
        self.time_factor_mean = nn.Parameter(torch.randn(n_time_steps, rank) * 0.01)
        self.time_factor_log_var = nn.Parameter(torch.full((n_time_steps, rank), -3.0))

        # Factor W (feature dimension)
        self.feature_factor_mean = nn.Parameter(torch.randn(total_feature_dim, rank) * 0.01)
        self.feature_factor_log_var = nn.Parameter(torch.full((total_feature_dim, rank), -3.0))

        # --- Per-modality input projection to common space -----------------
        self.modality_projections = nn.ModuleDict(
            {
                name: nn.Linear(dim, dim)  # identity-ish but learnable
                for name, dim in modality_dims.items()
            }
        )

        # --- Output MLP from rank-dimensional summary to output_dim --------
        self.output_mlp = nn.Sequential(
            nn.Linear(rank, output_dim_size),
            nn.LayerNorm(output_dim_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(output_dim_size, output_dim_size),
            nn.LayerNorm(output_dim_size),
        )

    # ------------------------------------------------------------------
    # BaseFusionModel interface
    # ------------------------------------------------------------------

    @property
    def output_dim(self) -> int:  # noqa: D102
        return self._output_dim

    def encode(
        self,
        modality_tensors: Dict[str, torch.Tensor],
        mask: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """Fuse multi-modal features via Bayesian tensor decomposition.

        Parameters
        ----------
        modality_tensors : dict[str, Tensor]
            ``{modality_name: (batch, features)}``.
        mask : dict[str, Tensor] | None
            Optional boolean masks.

        Returns
        -------
        Tensor
            Fused representation, ``(batch, output_dim)``.
        """
        # Concatenate all modality features into a single vector
        parts: list[torch.Tensor] = []
        for name in self.modality_names:
            if name in modality_tensors:
                parts.append(self.modality_projections[name](modality_tensors[name]))
        if not parts:
            batch_size = next(iter(modality_tensors.values())).shape[0]
            device = next(iter(modality_tensors.values())).device
            return torch.zeros(batch_size, self._output_dim, device=device)

        x = torch.cat(parts, dim=-1)  # (batch, total_feature_dim)

        # TODO: Implement full variational tensor decomposition with Pyro.
        #       For now, approximate via: patient_factor = x @ W_mean
        #       which gives a rank-dimensional summary.
        # Sample feature factor from variational posterior (reparameterised)
        if self.training:
            std = torch.exp(0.5 * self.feature_factor_log_var)
            eps = torch.randn_like(std)
            w_sample = self.feature_factor_mean + eps * std
        else:
            w_sample = self.feature_factor_mean

        # Project: (batch, total_feat) @ (total_feat, rank) -> (batch, rank)
        patient_factor = x @ w_sample

        return self.output_mlp(patient_factor)  # (batch, output_dim)

    def kl_loss(self) -> torch.Tensor:
        """Compute KL divergence between variational posteriors and priors.

        Returns
        -------
        Tensor
            Scalar KL divergence to be added to the training loss.
        """
        kl = torch.tensor(0.0, device=self.feature_factor_mean.device)
        for mean, log_var in [
            (self.feature_factor_mean, self.feature_factor_log_var),
            (self.time_factor_mean, self.time_factor_log_var),
        ]:
            prior_var = self.prior_std**2
            kl_elem = -0.5 * (
                1
                + log_var
                - math.log(prior_var)
                - (mean.pow(2) + log_var.exp()) / prior_var
            )
            kl = kl + kl_elem.sum()
        return kl


# Needed for kl_loss math.log
import math  # noqa: E402
