"""Abstract base class for multi-modal representation / fusion models.

Every fusion model in CognitiveTwin must subclass
:class:`BaseFusionModel` and implement its abstract interface.
This guarantees that the rest of the pipeline (dynamics, evaluation, etc.)
can consume **any** fusion implementation without modification.

Design rationale
----------------
* Fusion models receive per-visit, per-modality tensors and produce a
  single fused representation tensor that captures cross-modal interactions.
* The ``encode`` method handles a **single** time-step; batched /
  sequential encoding is the caller's responsibility (or can be delegated
  to :meth:`encode_sequence`).
* ``output_dim`` exposes the dimensionality of the fused representation so
  that downstream modules can auto-configure.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Optional

import torch
import torch.nn as nn


class BaseFusionModel(ABC, nn.Module):
    """Abstract base class for multi-modal fusion models.

    Subclasses must implement :meth:`encode` and :meth:`output_dim`.

    A fusion model ingests a dictionary of per-modality tensors
    (e.g. ``{"cognitive": ..., "mri": ..., "csf": ...}``) and produces
    a single fused representation tensor.
    """

    @abstractmethod
    def encode(
        self,
        modality_tensors: Dict[str, torch.Tensor],
        mask: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """Fuse multi-modal inputs into a single representation.

        Parameters
        ----------
        modality_tensors : dict[str, Tensor]
            Mapping from modality name to a tensor of shape
            ``(batch, features)`` (single time-step) or
            ``(batch, time, features)`` (sequence).
        mask : dict[str, Tensor] | None
            Optional boolean masks indicating which features are
            observed (``True``) vs. missing (``False``) for each modality.
            Shape mirrors ``modality_tensors``.

        Returns
        -------
        Tensor
            Fused representation of shape ``(batch, output_dim)`` or
            ``(batch, time, output_dim)``.
        """
        ...

    @property
    @abstractmethod
    def output_dim(self) -> int:
        """Dimensionality of the fused representation vector."""
        ...

    # ------------------------------------------------------------------
    # Convenience (non-abstract) methods
    # ------------------------------------------------------------------

    def encode_sequence(
        self,
        modality_sequences: Dict[str, torch.Tensor],
        mask: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """Encode a full temporal sequence of multi-modal data.

        Default implementation loops over the time dimension and calls
        :meth:`encode` per step.  Subclasses may override for a more
        efficient batched implementation.

        Parameters
        ----------
        modality_sequences : dict[str, Tensor]
            Per-modality tensors of shape ``(batch, time, features)``.
        mask : dict[str, Tensor] | None
            Optional masks of matching shape.

        Returns
        -------
        Tensor
            Shape ``(batch, time, output_dim)``.
        """
        # Infer time dimension from the first modality tensor
        first_tensor = next(iter(modality_sequences.values()))
        batch_size, time_steps, _ = first_tensor.shape

        outputs = []
        for t in range(time_steps):
            step_tensors = {
                name: tensor[:, t, :] for name, tensor in modality_sequences.items()
            }
            step_mask = (
                {name: m[:, t, :] for name, m in mask.items()} if mask else None
            )
            outputs.append(self.encode(step_tensors, step_mask))

        return torch.stack(outputs, dim=1)  # (batch, time, output_dim)
