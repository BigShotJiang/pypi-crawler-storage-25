"""Transformer-based multi-modal fusion model.

Implements cross-modal attention to learn interactions between cognitive
scores, biomarkers, imaging features, and genetics.  The architecture
follows the design described in the CognitiveTwin research paper:

1. Per-modality linear projection to a common ``d_model`` space.
2. Learnable modality-type embeddings added to distinguish sources.
3. Sinusoidal positional encoding for temporal ordering.
4. Stacked Transformer encoder layers with multi-head self-attention
   operating over the **concatenated** set of modality tokens.
5. A pooling head that aggregates tokens into a single fused vector.
"""

from __future__ import annotations

import math
from typing import Dict, Optional

import torch
import torch.nn as nn

from cognitivedt.representation.base import BaseFusionModel


class PositionalEncoding(nn.Module):
    """Sinusoidal positional encoding (Vaswani et al., 2017)."""

    def __init__(self, d_model: int, max_len: int = 512, dropout: float = 0.1) -> None:
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float) * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # (1, max_len, d_model)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Add positional encoding.  *x* has shape ``(batch, seq_len, d_model)``."""
        x = x + self.pe[:, : x.size(1), :]
        return self.dropout(x)


class TransformerFusionModel(BaseFusionModel):
    """Transformer-based multi-modal fusion.

    Parameters
    ----------
    modality_dims : dict[str, int]
        Mapping from modality name to its raw feature dimensionality.
        Example: ``{"cognitive": 9, "mri": 7, "pet": 2, "csf": 3}``.
    d_model : int
        Common embedding dimensionality for all modalities.
    n_heads : int
        Number of attention heads in each Transformer layer.
    n_layers : int
        Number of stacked Transformer encoder layers.
    d_ff : int
        Dimensionality of the feed-forward sub-layer.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        modality_dims: Dict[str, int],
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 4,
        d_ff: int = 512,
        dropout: float = 0.15,
    ) -> None:
        super().__init__()
        self._d_model = d_model
        self.modality_names = sorted(modality_dims.keys())

        # --- Per-modality projection layers --------------------------------
        self.modality_projections = nn.ModuleDict(
            {
                name: nn.Sequential(
                    nn.Linear(dim, d_model),
                    nn.LayerNorm(d_model),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                )
                for name, dim in modality_dims.items()
            }
        )

        # --- Learnable modality-type embeddings ----------------------------
        self.modality_embeddings = nn.Embedding(len(modality_dims), d_model)

        # --- Positional encoding -------------------------------------------
        self.pos_encoder = PositionalEncoding(d_model, dropout=dropout)

        # --- Transformer encoder stack -------------------------------------
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=n_heads,
            dim_feedforward=d_ff,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer, num_layers=n_layers
        )

        # --- Pooling & output projection -----------------------------------
        self.output_projection = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.LayerNorm(d_model),
        )

    # ------------------------------------------------------------------
    # BaseFusionModel interface
    # ------------------------------------------------------------------

    @property
    def output_dim(self) -> int:  # noqa: D102
        return self._d_model

    def encode(
        self,
        modality_tensors: Dict[str, torch.Tensor],
        mask: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """Fuse per-modality features via cross-modal Transformer attention.

        Parameters
        ----------
        modality_tensors : dict[str, Tensor]
            ``{modality_name: (batch, features)}``.
        mask : dict[str, Tensor] | None
            ``{modality_name: (batch, features)}`` boolean masks.

        Returns
        -------
        Tensor
            Fused representation, ``(batch, d_model)``.
        """
        tokens: list[torch.Tensor] = []

        for idx, name in enumerate(self.modality_names):
            if name not in modality_tensors:
                continue
            x_m = modality_tensors[name]  # (batch, feat_dim)
            proj = self.modality_projections[name](x_m)  # (batch, d_model)

            # Add modality-type embedding
            mod_idx = torch.tensor(idx, device=proj.device)
            proj = proj + self.modality_embeddings(mod_idx)

            tokens.append(proj.unsqueeze(1))  # (batch, 1, d_model)

        if not tokens:
            # Fallback: return zeros if no modalities present
            batch_size = next(iter(modality_tensors.values())).shape[0]
            device = next(iter(modality_tensors.values())).device
            return torch.zeros(batch_size, self._d_model, device=device)

        # Concatenate modality tokens -> (batch, n_modalities, d_model)
        token_seq = torch.cat(tokens, dim=1)
        token_seq = self.pos_encoder(token_seq)

        # Transformer encoder
        encoded = self.transformer_encoder(token_seq)  # (batch, n_mod, d_model)

        # Mean pooling across modality tokens
        fused = encoded.mean(dim=1)  # (batch, d_model)
        fused = self.output_projection(fused)

        return fused
