"""Graph Neural Network fusion model.

Models multi-modal patient data as a heterogeneous graph where:
* **Nodes** represent individual modality feature vectors at each time-step.
* **Edges** encode relationships:
  - Within-modality temporal edges (connecting the same modality across time).
  - Cross-modal edges (connecting different modalities at the same visit).
* Message passing aggregates neighbourhood information to produce a
  patient-level fused representation.

This module requires the optional ``torch-geometric`` dependency::

    pip install cognitivedt[gnn]
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn

from cognitivedt.representation.base import BaseFusionModel


class GNNFusionModel(BaseFusionModel):
    """Graph Neural Network multi-modal fusion.

    Parameters
    ----------
    modality_dims : dict[str, int]
        ``{modality_name: raw_feature_dim}``.
    hidden_dim : int
        Hidden dimensionality of GNN layers.
    output_dim_size : int
        Dimensionality of the final fused representation.
    n_gnn_layers : int
        Number of message-passing layers.
    dropout : float
        Dropout probability.
    conv_type : str
        Type of graph convolution (``"GCN"`` or ``"GAT"``).
    """

    def __init__(
        self,
        modality_dims: Dict[str, int],
        hidden_dim: int = 128,
        output_dim_size: int = 256,
        n_gnn_layers: int = 3,
        dropout: float = 0.15,
        conv_type: str = "GAT",
    ) -> None:
        super().__init__()
        self._output_dim = output_dim_size
        self.modality_names = sorted(modality_dims.keys())
        self.hidden_dim = hidden_dim
        self.n_gnn_layers = n_gnn_layers
        self.conv_type = conv_type

        # --- Per-modality input projection ---------------------------------
        self.modality_projections = nn.ModuleDict(
            {
                name: nn.Sequential(
                    nn.Linear(dim, hidden_dim),
                    nn.LayerNorm(hidden_dim),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                )
                for name, dim in modality_dims.items()
            }
        )

        # --- GNN layers (placeholders  require torch_geometric) -----------
        # TODO: Replace with actual torch_geometric layers when dependency
        #       is available. For now we use simple linear message-passing
        #       approximation layers.
        self.gnn_layers = nn.ModuleList()
        for _ in range(n_gnn_layers):
            self.gnn_layers.append(
                nn.Sequential(
                    nn.Linear(hidden_dim, hidden_dim),
                    nn.LayerNorm(hidden_dim),
                    nn.ReLU(),
                    nn.Dropout(dropout),
                )
            )

        # --- Readout -------------------------------------------------------
        self.readout = nn.Sequential(
            nn.Linear(hidden_dim, output_dim_size),
            nn.LayerNorm(output_dim_size),
        )

    # ------------------------------------------------------------------
    # BaseFusionModel interface
    # ------------------------------------------------------------------

    @property
    def output_dim(self) -> int:  # noqa: D102
        return self._output_dim

    def encode(
        self,
        modality_tensors: Dict[str, torch.Tensor],
        mask: Optional[Dict[str, torch.Tensor]] = None,
    ) -> torch.Tensor:
        """Encode multi-modal features via graph message passing.

        Parameters
        ----------
        modality_tensors : dict[str, Tensor]
            ``{modality_name: (batch, features)}``.
        mask : dict[str, Tensor] | None
            Optional boolean masks.

        Returns
        -------
        Tensor
            Fused representation, ``(batch, output_dim)``.
        """
        # Project each modality to hidden_dim
        node_features: list[torch.Tensor] = []
        for name in self.modality_names:
            if name not in modality_tensors:
                continue
            proj = self.modality_projections[name](modality_tensors[name])
            node_features.append(proj)  # (batch, hidden_dim)

        if not node_features:
            batch_size = next(iter(modality_tensors.values())).shape[0]
            device = next(iter(modality_tensors.values())).device
            return torch.zeros(batch_size, self._output_dim, device=device)

        # Stack nodes: (batch, n_modalities, hidden_dim)
        nodes = torch.stack(node_features, dim=1)

        # TODO: Build proper edge_index for cross-modal + temporal edges
        #       and use torch_geometric conv layers.
        # Placeholder: approximate message passing with mean-aggregation
        # + residual MLP layers.
        h = nodes.mean(dim=1)  # (batch, hidden_dim)  global aggregation

        for layer in self.gnn_layers:
            h = h + layer(h)  # residual connection

        return self.readout(h)  # (batch, output_dim)
