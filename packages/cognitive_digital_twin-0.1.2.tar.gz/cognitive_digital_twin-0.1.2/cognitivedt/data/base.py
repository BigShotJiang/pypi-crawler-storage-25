"""Composite data models that aggregate modality-level schemas.

This module defines two central objects:

* :class:`VisitData`  all information collected at a **single** clinical visit.
* :class:`PatientData`  the complete longitudinal record for **one** patient,
  composed of an ordered sequence of :class:`VisitData` plus time-invariant
  fields (genetics, baseline demographics).

Together they form the canonical data representation consumed by every
downstream component in CognitiveTwin (fusion, dynamics, generative, evaluation).
"""

from __future__ import annotations

from datetime import date
from typing import List, Optional, Sequence

import numpy as np
from pydantic import BaseModel, Field, model_validator

from cognitivedt.data.schemas import (
    CognitiveScores,
    CSFBiomarkers,
    Demographics,
    Diagnosis,
    GeneticProfile,
    MRIVolumetrics,
    PETBiomarkers,
)


# ---------------------------------------------------------------------------
# Visit-level record
# ---------------------------------------------------------------------------

class VisitData(BaseModel):
    """All data collected at a single longitudinal visit.

    Parameters
    ----------
    visit_code : str
        TADPOLE visit code (e.g. ``"bl"``, ``"m06"``, ``"m12"``).
    exam_date : date | None
        Date the examination took place (TADPOLE: ``EXAMDATE``).
    months_from_baseline : float
        Time in months since the patient's baseline visit.  Derived from
        ``visit_code`` or computed from ``exam_date``.
    diagnosis : Diagnosis | None
        Clinical diagnosis at this visit (CN / MCI / Dementia).
    demographics : Demographics
        Age, sex, education, etc. (age is visit-specific).
    cognitive : CognitiveScores
        Cognitive test results at this visit.
    mri : MRIVolumetrics | None
        Structural MRI measures (may be missing at some visits).
    pet : PETBiomarkers | None
        PET imaging summaries (may be missing at some visits).
    csf : CSFBiomarkers | None
        CSF biomarker concentrations (may be missing at some visits).
    """

    visit_code: str = Field(
        ...,
        description="TADPOLE visit code, e.g. 'bl', 'm06', 'm12', 'm24'.",
    )
    exam_date: Optional[date] = Field(
        default=None,
        description="Date of the clinical visit.",
    )
    months_from_baseline: float = Field(
        ...,
        ge=0.0,
        description="Months elapsed since the patient's baseline visit.",
    )
    diagnosis: Optional[Diagnosis] = Field(
        default=None,
        description="Clinical diagnosis at this visit.",
    )
    demographics: Demographics
    cognitive: CognitiveScores = Field(default_factory=CognitiveScores)
    mri: Optional[MRIVolumetrics] = None
    pet: Optional[PETBiomarkers] = None
    csf: Optional[CSFBiomarkers] = None

    model_config = {"frozen": True}

    # ---- helpers -----------------------------------------------------------

    def available_modalities(self) -> list[str]:
        """Return a list of modality names that have at least one non-null value."""
        present: list[str] = []
        if self.cognitive and any(
            v is not None for v in self.cognitive.model_dump().values()
        ):
            present.append("cognitive")
        if self.mri and any(v is not None for v in self.mri.model_dump().values()):
            present.append("mri")
        if self.pet and any(v is not None for v in self.pet.model_dump().values()):
            present.append("pet")
        if self.csf and any(v is not None for v in self.csf.model_dump().values()):
            present.append("csf")
        return present

    def to_flat_dict(self) -> dict[str, object]:
        """Flatten all modality fields into a single ``{name: value}`` dict.

        Useful for quick conversion to a pandas DataFrame row.
        """
        flat: dict[str, object] = {
            "visit_code": self.visit_code,
            "months_from_baseline": self.months_from_baseline,
            "diagnosis": self.diagnosis.value if self.diagnosis else None,
        }
        flat.update(
            {f"demo_{k}": v for k, v in self.demographics.model_dump().items()}
        )
        flat.update(
            {f"cog_{k}": v for k, v in self.cognitive.model_dump().items()}
        )
        if self.mri:
            flat.update({f"mri_{k}": v for k, v in self.mri.model_dump().items()})
        if self.pet:
            flat.update({f"pet_{k}": v for k, v in self.pet.model_dump().items()})
        if self.csf:
            flat.update({f"csf_{k}": v for k, v in self.csf.model_dump().items()})
        return flat


# ---------------------------------------------------------------------------
# Patient-level longitudinal record
# ---------------------------------------------------------------------------

class PatientData(BaseModel):
    """Complete longitudinal record for a single patient.

    Composes an ordered sequence of :class:`VisitData` with time-invariant
    fields (patient ID, genetics, baseline diagnosis).

    Parameters
    ----------
    patient_id : str
        Unique patient identifier (TADPOLE: ``RID``).
    genetics : GeneticProfile | None
        Genetic risk factors (constant across visits).
    baseline_diagnosis : Diagnosis | None
        Diagnosis at the baseline visit (TADPOLE: ``DX_bl``).
    visits : list[VisitData]
        Temporally ordered list of clinical visits.  Must contain at least
        one visit (the baseline).
    """

    patient_id: str = Field(
        ...,
        description="Unique patient identifier (TADPOLE: RID).",
    )
    genetics: Optional[GeneticProfile] = None
    baseline_diagnosis: Optional[Diagnosis] = Field(
        default=None,
        description="Diagnosis at the baseline visit.",
    )
    visits: List[VisitData] = Field(
        ...,
        min_length=1,
        description="Temporally ordered list of clinical visits.",
    )

    model_config = {"frozen": False}  # mutable so we can append visits

    # ---- validators --------------------------------------------------------

    @model_validator(mode="after")
    def _visits_sorted_by_time(self) -> "PatientData":
        """Ensure visits are sorted by ``months_from_baseline``."""
        times = [v.months_from_baseline for v in self.visits]
        if times != sorted(times):
            # Auto-sort rather than reject  TADPOLE rows are not always ordered.
            self.visits = sorted(
                self.visits, key=lambda v: v.months_from_baseline
            )
        return self

    # ---- convenience properties --------------------------------------------

    @property
    def n_visits(self) -> int:
        """Number of longitudinal visits."""
        return len(self.visits)

    @property
    def follow_up_months(self) -> float:
        """Total follow-up duration in months."""
        if self.n_visits < 2:
            return 0.0
        return self.visits[-1].months_from_baseline - self.visits[0].months_from_baseline

    @property
    def baseline_visit(self) -> VisitData:
        """Return the first (baseline) visit."""
        return self.visits[0]

    @property
    def last_visit(self) -> VisitData:
        """Return the most recent visit."""
        return self.visits[-1]

    @property
    def diagnosis_trajectory(self) -> list[Optional[Diagnosis]]:
        """Return the sequence of diagnoses across visits."""
        return [v.diagnosis for v in self.visits]

    @property
    def time_points(self) -> list[float]:
        """Return list of months-from-baseline for each visit."""
        return [v.months_from_baseline for v in self.visits]

    def has_progression(self) -> bool:
        """Return ``True`` if the patient ever progressed to a worse diagnosis.

        Ordering: CN < MCI < Dementia.
        """
        order = {Diagnosis.CN: 0, Diagnosis.MCI: 1, Diagnosis.DEMENTIA: 2}
        diagnoses = [
            order[d] for d in self.diagnosis_trajectory if d is not None
        ]
        if len(diagnoses) < 2:
            return False
        return max(diagnoses) > diagnoses[0]

    def get_mmse_trajectory(self) -> tuple[list[float], list[float]]:
        """Return ``(times, scores)`` for visits where MMSE is available."""
        times: list[float] = []
        scores: list[float] = []
        for v in self.visits:
            if v.cognitive.mmse is not None:
                times.append(v.months_from_baseline)
                scores.append(v.cognitive.mmse)
        return times, scores

    def to_feature_matrix(
        self,
        feature_names: Optional[Sequence[str]] = None,
    ) -> np.ndarray:
        """Convert the visit sequence into a 2-D numpy array.

        Parameters
        ----------
        feature_names : sequence of str, optional
            Flat feature keys to include (as produced by
            :meth:`VisitData.to_flat_dict`).  If ``None``, all numeric columns
            from the first visit are used.

        Returns
        -------
        np.ndarray
            Array of shape ``(n_visits, n_features)``.  Missing values are
            encoded as ``np.nan``.
        """
        rows = [v.to_flat_dict() for v in self.visits]
        if feature_names is None:
            # Discover numeric keys from the first row
            feature_names = [
                k for k, v in rows[0].items() if isinstance(v, (int, float))
            ]
        matrix = np.full((len(rows), len(feature_names)), np.nan)
        for i, row in enumerate(rows):
            for j, feat in enumerate(feature_names):
                val = row.get(feat)
                if isinstance(val, (int, float)):
                    matrix[i, j] = float(val)
        return matrix
