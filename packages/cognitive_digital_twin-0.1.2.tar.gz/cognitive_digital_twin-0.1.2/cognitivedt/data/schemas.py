"""Pydantic schemas for individual data modalities from the TADPOLE dataset.

This module defines validated, type-safe data structures for every data modality
that flows through the CognitiveTwin pipeline.  Each schema maps directly to
columns found in the TADPOLE D1/D2 CSV export from ADNI.

Design decisions
----------------
* All biomarker / volumetric fields are ``Optional[float]`` because TADPOLE has
  substantial missingness  forcing ``float`` would reject most real rows.
* We use ``model_validator`` where cross-field constraints exist (e.g. APOE4
  allele count must be 0-2).
* ``Field(description=&)`` provides self-documenting schemas that can be
  serialised to JSON-Schema for downstream consumers.
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class Diagnosis(str, Enum):
    """Clinical diagnosis label used in TADPOLE (column ``DX``)."""

    CN = "CN"          # Cognitively Normal
    MCI = "MCI"        # Mild Cognitive Impairment
    DEMENTIA = "Dementia"


class Sex(str, Enum):
    """Biological sex (TADPOLE column ``PTGENDER``)."""

    MALE = "Male"
    FEMALE = "Female"


# ---------------------------------------------------------------------------
# Demographic schema
# ---------------------------------------------------------------------------

class Demographics(BaseModel):
    """Static and slowly-changing patient demographics.

    These fields are typically recorded once at screening / baseline but may be
    re-confirmed at subsequent visits.

    TADPOLE columns
    ----------------
    AGE, PTGENDER, PTEDUCAT, PTETHCAT, PTRACCAT, PTMARRY
    """

    age: float = Field(
        ...,
        ge=0.0,
        le=120.0,
        description="Age at the visit in years (TADPOLE: AGE).",
    )
    sex: Sex = Field(
        ...,
        description="Biological sex (TADPOLE: PTGENDER).",
    )
    education_years: float = Field(
        ...,
        ge=0.0,
        le=30.0,
        description="Years of formal education (TADPOLE: PTEDUCAT).",
    )
    ethnicity: Optional[str] = Field(
        default=None,
        description="Self-reported ethnicity (TADPOLE: PTETHCAT).",
    )
    race: Optional[str] = Field(
        default=None,
        description="Self-reported race (TADPOLE: PTRACCAT).",
    )
    marital_status: Optional[str] = Field(
        default=None,
        description="Marital status (TADPOLE: PTMARRY).",
    )

    model_config = {"frozen": True}


# ---------------------------------------------------------------------------
# Genetic schema
# ---------------------------------------------------------------------------

class GeneticProfile(BaseModel):
    """Genetic risk factors available in TADPOLE.

    TADPOLE columns
    ----------------
    APOE4
    """

    apoe4_count: int = Field(
        ...,
        ge=0,
        le=2,
        description=(
            "Number of APOE-e4 alleles (0, 1, or 2).  "
            "TADPOLE column: APOE4."
        ),
    )

    model_config = {"frozen": True}


# ---------------------------------------------------------------------------
# Cognitive scores schema
# ---------------------------------------------------------------------------

class CognitiveScores(BaseModel):
    """Cognitive test battery recorded at each longitudinal visit.

    All scores are optional because not every test is administered at every
    visit in TADPOLE.

    TADPOLE columns
    ----------------
    MMSE, ADAS11, ADAS13, CDRSB, RAVLT_immediate, RAVLT_learning,
    RAVLT_forgetting, RAVLT_perc_forgetting, FAQ
    """

    mmse: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=30.0,
        description="Mini-Mental State Examination (0-30, higher = better).",
    )
    adas11: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=70.0,
        description="ADAS-Cog 11-item subscale (0-70, lower = better).",
    )
    adas13: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=85.0,
        description="ADAS-Cog 13-item subscale (0-85, lower = better).",
    )
    cdrsb: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=18.0,
        description="Clinical Dementia Rating Sum of Boxes (0-18, lower = better).",
    )
    ravlt_immediate: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="RAVLT total immediate recall (sum of 5 trials).",
    )
    ravlt_learning: Optional[float] = Field(
        default=None,
        description="RAVLT learning score (trial 5 minus trial 1).",
    )
    ravlt_forgetting: Optional[float] = Field(
        default=None,
        description="RAVLT forgetting score (trial 5 minus delayed recall).",
    )
    ravlt_perc_forgetting: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=100.0,
        description="RAVLT percent forgetting.",
    )
    faq: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=30.0,
        description="Functional Activities Questionnaire (0-30, lower = better).",
    )

    model_config = {"frozen": True}


# ---------------------------------------------------------------------------
# MRI volumetrics schema
# ---------------------------------------------------------------------------

class MRIVolumetrics(BaseModel):
    """Structural MRI volumetric and cortical thickness measures.

    All volumes are in mm3 and thicknesses in mm as reported by the
    FreeSurfer longitudinal pipeline in TADPOLE.

    TADPOLE columns
    ----------------
    Ventricles, Hippocampus, WholeBrain, Entorhinal, Fusiform, MidTemp, ICV
    """

    ventricles: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Ventricular volume in mm3 (TADPOLE: Ventricles).",
    )
    hippocampus: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Hippocampal volume in mm3 (TADPOLE: Hippocampus).",
    )
    whole_brain: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Whole brain volume in mm3 (TADPOLE: WholeBrain).",
    )
    entorhinal: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Entorhinal cortex thickness in mm (TADPOLE: Entorhinal).",
    )
    fusiform: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Fusiform gyrus volume in mm3 (TADPOLE: Fusiform).",
    )
    mid_temp: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Middle temporal gyrus volume in mm3 (TADPOLE: MidTemp).",
    )
    icv: Optional[float] = Field(
        default=None,
        ge=0.0,
        description="Intracranial volume in mm3 (TADPOLE: ICV).",
    )

    model_config = {"frozen": True}

    # ---- derived helpers ---------------------------------------------------

    def normalized_hippocampus(self) -> Optional[float]:
        """Return hippocampal volume as a fraction of ICV, or *None*."""
        if self.hippocampus is not None and self.icv is not None and self.icv > 0:
            return self.hippocampus / self.icv
        return None

    def normalized_ventricles(self) -> Optional[float]:
        """Return ventricular volume as a fraction of ICV, or *None*."""
        if self.ventricles is not None and self.icv is not None and self.icv > 0:
            return self.ventricles / self.icv
        return None


# ---------------------------------------------------------------------------
# PET biomarkers schema
# ---------------------------------------------------------------------------

class PETBiomarkers(BaseModel):
    """Positron Emission Tomography biomarker summaries.

    TADPOLE columns
    ----------------
    FDG, AV45
    """

    fdg: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "FDG-PET standardised uptake value ratio (SUVR). "
            "Lower values indicate hypometabolism (TADPOLE: FDG)."
        ),
    )
    av45: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "Amyloid PET (florbetapir / AV45) SUVR. "
            "Higher values indicate greater amyloid burden (TADPOLE: AV45)."
        ),
    )

    model_config = {"frozen": True}


# ---------------------------------------------------------------------------
# CSF biomarkers schema
# ---------------------------------------------------------------------------

class CSFBiomarkers(BaseModel):
    """Cerebrospinal fluid biomarker concentrations.

    TADPOLE columns
    ----------------
    ABETA, TAU, PTAU
    """

    abeta: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "CSF Amyloid-beta 1-42 concentration in pg/mL. "
            "Lower values suggest amyloid pathology (TADPOLE: ABETA)."
        ),
    )
    tau: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "CSF total Tau concentration in pg/mL. "
            "Higher values indicate neurodegeneration (TADPOLE: TAU)."
        ),
    )
    ptau: Optional[float] = Field(
        default=None,
        ge=0.0,
        description=(
            "CSF phosphorylated Tau concentration in pg/mL. "
            "Higher values indicate tau pathology (TADPOLE: PTAU)."
        ),
    )

    model_config = {"frozen": True}

    # ---- derived helpers ---------------------------------------------------

    def tau_abeta_ratio(self) -> Optional[float]:
        """Return Tau / Abeta ratio, a strong AD biomarker, or *None*."""
        if self.tau is not None and self.abeta is not None and self.abeta > 0:
            return self.tau / self.abeta
        return None

    @model_validator(mode="after")
    def _warn_implausible_values(self) -> "CSFBiomarkers":
        """Flag values outside typical clinical ranges (soft check)."""
        # Typical ranges: Abeta 200-1700, Tau 80-1300, pTau 8-120
        # We do not reject  just document that downstream QC may flag them.
        return self
