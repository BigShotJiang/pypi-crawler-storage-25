"""Anomaly detection for patient trajectories.

Identifies patients whose cognitive trajectories deviate significantly
from model expectations.  Clinically, anomalous trajectories may indicate:
* Rapid progression (alert for intensified monitoring).
* Misdiagnosis (trajectory inconsistent with label).
* Data quality issues (recording errors, protocol deviations).
* Comorbidities (non-AD causes of cognitive change).

Methods
-------
* **Reconstruction-based:** flag patients with high reconstruction error
  from the dynamics model (DMM / KVAE).
* **Isolation Forest:** fit an unsupervised detector on the latent
  representations.
* **Statistical process control:** z-score each trajectory against
  population-level norms.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from numpy.typing import NDArray


def reconstruction_anomaly_scores(
    x_true: NDArray[np.floating],
    x_recon: NDArray[np.floating],
    reduction: str = "mean",
) -> NDArray[np.floating]:
    """Compute per-patient anomaly scores from reconstruction error.

    Parameters
    ----------
    x_true : ndarray
        Ground-truth trajectories, ``(n_patients, n_visits, n_features)``.
    x_recon : ndarray
        Reconstructed trajectories (same shape).
    reduction : str
        How to reduce across visits and features:
        ``"mean"`` (default) or ``"max"``.

    Returns
    -------
    ndarray
        Anomaly scores, ``(n_patients,)``.  Higher = more anomalous.
    """
    errors = (x_true - x_recon) ** 2  # (patients, visits, features)

    if reduction == "max":
        return np.max(errors.reshape(errors.shape[0], -1), axis=1)
    # Default: mean
    return np.mean(errors.reshape(errors.shape[0], -1), axis=1)


def isolation_forest_anomaly(
    latent_representations: NDArray[np.floating],
    contamination: float = 0.05,
    random_state: int = 42,
) -> Tuple[NDArray[np.integer], NDArray[np.floating]]:
    """Detect anomalies using Isolation Forest on latent representations.

    Parameters
    ----------
    latent_representations : ndarray
        ``(n_patients, latent_dim)``  latent states from a dynamics model
        (e.g. last-step posterior mean).
    contamination : float
        Expected proportion of anomalies.
    random_state : int
        Random seed.

    Returns
    -------
    tuple[ndarray, ndarray]
        ``(labels, scores)``  labels are 1 (normal) or -1 (anomaly);
        scores are continuous anomaly scores (more negative = more anomalous).
    """
    from sklearn.ensemble import IsolationForest

    clf = IsolationForest(
        contamination=contamination,
        random_state=random_state,
        n_estimators=200,
    )
    labels = clf.fit_predict(latent_representations)
    scores = clf.decision_function(latent_representations)

    return labels, scores


def statistical_process_control(
    trajectories: NDArray[np.floating],
    population_mean: Optional[NDArray[np.floating]] = None,
    population_std: Optional[NDArray[np.floating]] = None,
    z_threshold: float = 2.0,
) -> Tuple[NDArray[np.bool_], NDArray[np.floating]]:
    """Flag anomalous trajectories using z-score thresholding.

    Parameters
    ----------
    trajectories : ndarray
        ``(n_patients, n_visits)``  single-feature trajectory (e.g. MMSE).
    population_mean : ndarray | None
        Expected mean trajectory, ``(n_visits,)``.
        If ``None``, estimated from *trajectories*.
    population_std : ndarray | None
        Expected std trajectory.
        If ``None``, estimated from *trajectories*.
    z_threshold : float
        Z-score threshold for flagging.

    Returns
    -------
    tuple[ndarray, ndarray]
        ``(is_anomalous, max_z_scores)``  boolean flags per patient and
        the maximum absolute z-score observed in their trajectory.
    """
    if population_mean is None:
        population_mean = np.nanmean(trajectories, axis=0)
    if population_std is None:
        population_std = np.nanstd(trajectories, axis=0)
        population_std = np.where(population_std < 1e-8, 1.0, population_std)

    z_scores = np.abs((trajectories - population_mean) / population_std)
    max_z = np.nanmax(z_scores, axis=1)
    is_anomalous = max_z > z_threshold

    return is_anomalous, max_z


def trajectory_change_point_detection(
    trajectory: NDArray[np.floating],
    window_size: int = 3,
    threshold_factor: float = 2.0,
) -> List[int]:
    """Detect change points in a single patient's trajectory.

    Uses a simple sliding-window approach: compute the mean absolute
    change within windows and flag time-points where the local change
    exceeds ``threshold_factor -> global_mean_change``.

    Parameters
    ----------
    trajectory : ndarray
        ``(n_visits,)``  single-feature values over time.
    window_size : int
        Number of visits in the sliding window.
    threshold_factor : float
        Multiplier for the global mean change.

    Returns
    -------
    list[int]
        Indices of detected change points.
    """
    if len(trajectory) < window_size + 1:
        return []

    diffs = np.abs(np.diff(trajectory))
    global_mean = float(np.mean(diffs))

    change_points: list[int] = []
    for i in range(len(diffs) - window_size + 1):
        window_mean = float(np.mean(diffs[i : i + window_size]))
        if window_mean > threshold_factor * global_mean and global_mean > 0:
            change_points.append(i + window_size)

    return change_points
