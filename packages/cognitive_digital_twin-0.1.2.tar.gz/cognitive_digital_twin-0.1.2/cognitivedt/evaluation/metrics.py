"""Prediction and classification metrics for CognitiveTwin models.

Provides functions for evaluating:
* **Regression:** MAE, RMSE, R->, MAPE for cognitive score prediction.
* **Classification:** accuracy, precision, recall, F1, AUROC, AUPRC
  for progression prediction.
* **Survival:** concordance index (C-index) and Brier score for
  time-to-event prediction.
* **Calibration:** Expected Calibration Error (ECE) and reliability
  diagrams.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
from numpy.typing import NDArray


# ---------------------------------------------------------------------------
# Regression metrics
# ---------------------------------------------------------------------------

def mean_absolute_error(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    mask: Optional[NDArray[np.bool_]] = None,
) -> float:
    """Mean Absolute Error, optionally masked for missing values.

    Parameters
    ----------
    y_true : ndarray
        Ground-truth values.
    y_pred : ndarray
        Predicted values (same shape as *y_true*).
    mask : ndarray[bool] | None
        If provided, only compute over positions where ``mask == True``.

    Returns
    -------
    float
    """
    errors = np.abs(y_true - y_pred)
    if mask is not None:
        errors = errors[mask]
    return float(np.mean(errors))


def root_mean_squared_error(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    mask: Optional[NDArray[np.bool_]] = None,
) -> float:
    """Root Mean Squared Error.

    Parameters
    ----------
    y_true, y_pred : ndarray
        Ground-truth and predicted values.
    mask : ndarray[bool] | None
        Optional mask.

    Returns
    -------
    float
    """
    errors = (y_true - y_pred) ** 2
    if mask is not None:
        errors = errors[mask]
    return float(np.sqrt(np.mean(errors)))


def r_squared(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
) -> float:
    """Coefficient of determination (R->).

    Parameters
    ----------
    y_true, y_pred : ndarray

    Returns
    -------
    float
        R-> value; 1.0 is perfect, d0 means worse than predicting the mean.
    """
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    if ss_tot == 0:
        return 0.0
    return float(1.0 - ss_res / ss_tot)


def mean_absolute_percentage_error(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    epsilon: float = 1e-8,
) -> float:
    """Mean Absolute Percentage Error (MAPE).

    Parameters
    ----------
    y_true, y_pred : ndarray
    epsilon : float
        Small constant to avoid division by zero.

    Returns
    -------
    float
        MAPE in range [0, ), as a fraction (not percent).
    """
    return float(np.mean(np.abs((y_true - y_pred) / (np.abs(y_true) + epsilon))))


# ---------------------------------------------------------------------------
# Classification metrics
# ---------------------------------------------------------------------------

def binary_classification_metrics(
    y_true: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
    threshold: float = 0.5,
) -> Dict[str, float]:
    """Compute standard binary classification metrics.

    Parameters
    ----------
    y_true : ndarray[int]
        Binary labels (0 or 1).
    y_pred_proba : ndarray[float]
        Predicted probabilities for the positive class.
    threshold : float
        Decision threshold for converting probabilities to labels.

    Returns
    -------
    dict[str, float]
        Keys: ``accuracy``, ``precision``, ``recall``, ``f1``,
        ``auroc``, ``auprc``.
    """
    from sklearn.metrics import (
        accuracy_score,
        average_precision_score,
        f1_score,
        precision_score,
        recall_score,
        roc_auc_score,
    )

    y_pred_label = (y_pred_proba >= threshold).astype(int)

    return {
        "accuracy": float(accuracy_score(y_true, y_pred_label)),
        "precision": float(precision_score(y_true, y_pred_label, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred_label, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred_label, zero_division=0)),
        "auroc": float(roc_auc_score(y_true, y_pred_proba)),
        "auprc": float(average_precision_score(y_true, y_pred_proba)),
    }


def multiclass_classification_metrics(
    y_true: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
) -> Dict[str, float]:
    """Compute multi-class classification metrics.

    Parameters
    ----------
    y_true : ndarray[int]
        Integer class labels.
    y_pred_proba : ndarray[float]
        ``(n_samples, n_classes)`` predicted probabilities.

    Returns
    -------
    dict[str, float]
        Keys: ``accuracy``, ``macro_f1``, ``weighted_f1``, ``auroc_ovr``.
    """
    from sklearn.metrics import (
        accuracy_score,
        f1_score,
        roc_auc_score,
    )

    y_pred_label = np.argmax(y_pred_proba, axis=1)

    metrics: Dict[str, float] = {
        "accuracy": float(accuracy_score(y_true, y_pred_label)),
        "macro_f1": float(f1_score(y_true, y_pred_label, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred_label, average="weighted", zero_division=0)),
    }

    # AUROC (one-vs-rest)  requires at least 2 classes with samples
    try:
        metrics["auroc_ovr"] = float(
            roc_auc_score(y_true, y_pred_proba, multi_class="ovr", average="macro")
        )
    except ValueError:
        metrics["auroc_ovr"] = float("nan")

    return metrics


# ---------------------------------------------------------------------------
# Survival / time-to-event metrics
# ---------------------------------------------------------------------------

def concordance_index(
    event_times: NDArray[np.floating],
    predicted_risk: NDArray[np.floating],
    event_observed: NDArray[np.bool_],
) -> float:
    """Harrell's concordance index (C-index) for survival predictions.

    Parameters
    ----------
    event_times : ndarray
        Observed times (time to event or censoring).
    predicted_risk : ndarray
        Model-predicted risk scores (higher = more risk).
    event_observed : ndarray[bool]
        ``True`` if the event was observed, ``False`` if censored.

    Returns
    -------
    float
        C-index in [0, 1]; 0.5 = random, 1.0 = perfect.
    """
    n = len(event_times)
    concordant = 0
    discordant = 0
    tied_risk = 0

    for i in range(n):
        if not event_observed[i]:
            continue
        for j in range(n):
            if i == j:
                continue
            if event_times[j] > event_times[i]:
                if predicted_risk[i] > predicted_risk[j]:
                    concordant += 1
                elif predicted_risk[i] < predicted_risk[j]:
                    discordant += 1
                else:
                    tied_risk += 1

    total = concordant + discordant + tied_risk
    if total == 0:
        return 0.5
    return float((concordant + 0.5 * tied_risk) / total)


def brier_score(
    y_true: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
) -> float:
    """Brier score (mean squared error of predicted probabilities).

    Parameters
    ----------
    y_true : ndarray[int]
        Binary labels (0 or 1).
    y_pred_proba : ndarray[float]
        Predicted probabilities.

    Returns
    -------
    float
        Brier score in [0, 1]; lower is better.
    """
    return float(np.mean((y_pred_proba - y_true) ** 2))


# ---------------------------------------------------------------------------
# Calibration metrics
# ---------------------------------------------------------------------------

def expected_calibration_error(
    y_true: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
    n_bins: int = 10,
) -> Tuple[float, List[float], List[float]]:
    """Expected Calibration Error (ECE).

    Parameters
    ----------
    y_true : ndarray[int]
        Binary labels.
    y_pred_proba : ndarray[float]
        Predicted probabilities.
    n_bins : int
        Number of equally-spaced calibration bins.

    Returns
    -------
    tuple[float, list[float], list[float]]
        ``(ece, bin_accuracies, bin_confidences)``  the scalar ECE plus
        per-bin values for plotting reliability diagrams.
    """
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    bin_accuracies: list[float] = []
    bin_confidences: list[float] = []

    for i in range(n_bins):
        in_bin = (y_pred_proba >= bin_boundaries[i]) & (y_pred_proba < bin_boundaries[i + 1])
        prop_in_bin = float(np.mean(in_bin))

        if prop_in_bin > 0:
            avg_confidence = float(np.mean(y_pred_proba[in_bin]))
            avg_accuracy = float(np.mean(y_true[in_bin]))
            ece += np.abs(avg_accuracy - avg_confidence) * prop_in_bin
            bin_accuracies.append(avg_accuracy)
            bin_confidences.append(avg_confidence)
        else:
            bin_accuracies.append(0.0)
            bin_confidences.append(0.0)

    return ece, bin_accuracies, bin_confidences


# ---------------------------------------------------------------------------
# Aggregate evaluation
# ---------------------------------------------------------------------------

def evaluate_regression(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    mask: Optional[NDArray[np.bool_]] = None,
) -> Dict[str, float]:
    """Compute all regression metrics in one call.

    Returns
    -------
    dict[str, float]
        ``mae``, ``rmse``, ``r2``, ``mape``.
    """
    return {
        "mae": mean_absolute_error(y_true, y_pred, mask),
        "rmse": root_mean_squared_error(y_true, y_pred, mask),
        "r2": r_squared(y_true, y_pred),
        "mape": mean_absolute_percentage_error(y_true, y_pred),
    }
