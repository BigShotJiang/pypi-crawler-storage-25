"""Evaluation, uncertainty quantification, robustness, and ELSI assessment."""

from cognitivedt.evaluation.metrics import (
    binary_classification_metrics,
    concordance_index,
    evaluate_regression,
    expected_calibration_error,
    mean_absolute_error,
    root_mean_squared_error,
)
from cognitivedt.evaluation.uq import (
    conformal_prediction_interval,
    decompose_uncertainty,
    prediction_interval_metrics,
    uncertainty_error_correlation,
)

__all__ = [
    # Metrics
    "mean_absolute_error",
    "root_mean_squared_error",
    "evaluate_regression",
    "binary_classification_metrics",
    "concordance_index",
    "expected_calibration_error",
    # UQ
    "prediction_interval_metrics",
    "uncertainty_error_correlation",
    "decompose_uncertainty",
    "conformal_prediction_interval",
]
