"""Robustness testing utilities.

Assess model reliability under realistic perturbations:
* **Missing data:** simulate increasing missingness (MCAR, MAR, MNAR).
* **Noise injection:** add Gaussian noise to features.
* **Distribution shift:** evaluate on data from different time periods
  or external cohorts.
* **Adversarial perturbations:** FGSM-based input attacks.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
from numpy.typing import NDArray

import torch
import torch.nn as nn


# ---------------------------------------------------------------------------
# Missing data robustness
# ---------------------------------------------------------------------------

def simulate_missing_data(
    X: NDArray[np.floating],
    missing_rate: float,
    mechanism: str = "MCAR",
    random_state: int = 42,
) -> NDArray[np.floating]:
    """Simulate missing data by replacing entries with NaN.

    Parameters
    ----------
    X : ndarray
        Complete feature matrix, ``(n_samples, n_features)``.
    missing_rate : float
        Fraction of entries to set missing, in [0, 1).
    mechanism : str
        ``"MCAR"`` (completely at random), ``"MAR"`` (at random 
        missingness depends on observed values), or ``"MNAR"``
        (not at random  missingness depends on the value itself).
    random_state : int
        Random seed.

    Returns
    -------
    ndarray
        Copy of *X* with ``np.nan`` injected.
    """
    rng = np.random.RandomState(random_state)
    X_out = X.copy().astype(float)
    n_samples, n_features = X_out.shape

    if mechanism == "MCAR":
        mask = rng.random((n_samples, n_features)) < missing_rate
        X_out[mask] = np.nan

    elif mechanism == "MAR":
        # Missingness of feature j depends on feature (j-1)
        for j in range(1, n_features):
            col = X_out[:, j - 1]
            threshold = np.nanpercentile(col, 100 * (1 - missing_rate))
            missing_mask = col > threshold
            subset = rng.choice(np.where(missing_mask)[0],
                                size=int(missing_rate * n_samples),
                                replace=False) if np.sum(missing_mask) > 0 else np.array([], dtype=int)
            X_out[subset, j] = np.nan

    elif mechanism == "MNAR":
        # Features with extreme values are more likely to be missing
        for j in range(n_features):
            col = X_out[:, j]
            probs = np.abs(col - np.nanmean(col)) / (np.nanstd(col) + 1e-8)
            probs = probs / probs.sum() * missing_rate * n_samples
            probs = np.clip(probs, 0, 1)
            mask = rng.random(n_samples) < probs
            X_out[mask, j] = np.nan

    return X_out


def evaluate_missing_robustness(
    eval_fn: Callable[[NDArray[np.floating]], Dict[str, float]],
    X: NDArray[np.floating],
    missing_rates: Sequence[float] = (0.0, 0.05, 0.10, 0.15, 0.20, 0.25),
    mechanism: str = "MCAR",
    n_repeats: int = 5,
) -> Dict[float, Dict[str, float]]:
    """Evaluate model at increasing levels of missing data.

    Parameters
    ----------
    eval_fn : callable
        Function that takes a (possibly NaN-containing) feature matrix and
        returns a dict of metric name -> value.
    X : ndarray
        Complete feature matrix.
    missing_rates : sequence of float
        Missingness fractions to test.
    mechanism : str
        Missing data mechanism.
    n_repeats : int
        Number of random repeats per rate (results are averaged).

    Returns
    -------
    dict[float, dict[str, float]]
        ``{missing_rate: {metric_name: mean_value}}``.
    """
    results: Dict[float, Dict[str, float]] = {}

    for rate in missing_rates:
        repeat_results: List[Dict[str, float]] = []
        for rep in range(n_repeats):
            X_missing = simulate_missing_data(X, rate, mechanism, random_state=42 + rep)
            metrics = eval_fn(X_missing)
            repeat_results.append(metrics)

        # Average across repeats
        avg: Dict[str, float] = {}
        for key in repeat_results[0]:
            avg[key] = float(np.mean([r[key] for r in repeat_results]))
        results[rate] = avg

    return results


# ---------------------------------------------------------------------------
# Noise sensitivity
# ---------------------------------------------------------------------------

def evaluate_noise_robustness(
    eval_fn: Callable[[NDArray[np.floating]], Dict[str, float]],
    X: NDArray[np.floating],
    noise_levels: Sequence[float] = (0.0, 0.05, 0.10, 0.15, 0.20),
    n_repeats: int = 5,
) -> Dict[float, Dict[str, float]]:
    """Evaluate model under Gaussian noise injection.

    Parameters
    ----------
    eval_fn : callable
        Evaluation function.
    X : ndarray
        Clean feature matrix.
    noise_levels : sequence of float
        Noise standard deviations as fraction of per-feature std.
    n_repeats : int
        Random repeats per level.

    Returns
    -------
    dict[float, dict[str, float]]
    """
    feature_stds = np.nanstd(X, axis=0)
    results: Dict[float, Dict[str, float]] = {}

    for sigma_frac in noise_levels:
        repeat_results: List[Dict[str, float]] = []
        for rep in range(n_repeats):
            rng = np.random.RandomState(42 + rep)
            noise = rng.randn(*X.shape) * feature_stds * sigma_frac
            X_noisy = X + noise
            metrics = eval_fn(X_noisy)
            repeat_results.append(metrics)

        avg: Dict[str, float] = {}
        for key in repeat_results[0]:
            avg[key] = float(np.mean([r[key] for r in repeat_results]))
        results[sigma_frac] = avg

    return results


# ---------------------------------------------------------------------------
# Adversarial robustness (FGSM)
# ---------------------------------------------------------------------------

def fgsm_attack(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    loss_fn: Callable[..., torch.Tensor],
    epsilon: float = 0.01,
) -> torch.Tensor:
    """Generate adversarial examples using Fast Gradient Sign Method.

    Parameters
    ----------
    model : nn.Module
        The target model.
    x : Tensor
        Input tensor (requires_grad will be set).
    y : Tensor
        Ground-truth labels / targets.
    loss_fn : callable
        Loss function ``loss_fn(output, y) -> scalar Tensor``.
    epsilon : float
        Perturbation budget.

    Returns
    -------
    Tensor
        Adversarial inputs ``x_adv``.
    """
    x_adv = x.clone().detach().requires_grad_(True)
    output = model(x_adv)
    if hasattr(output, "loss"):
        loss = output.loss
    else:
        loss = loss_fn(output, y)
    loss.backward()

    perturbation = epsilon * x_adv.grad.sign()
    x_adv = x_adv + perturbation
    return x_adv.detach()


def evaluate_adversarial_robustness(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    loss_fn: Callable[..., torch.Tensor],
    eval_fn: Callable[[torch.Tensor, torch.Tensor], Dict[str, float]],
    epsilons: Sequence[float] = (0.0, 0.01, 0.05, 0.10),
) -> Dict[float, Dict[str, float]]:
    """Evaluate model under FGSM adversarial attacks.

    Parameters
    ----------
    model : nn.Module
        Target model.
    x, y : Tensor
        Test inputs and targets.
    loss_fn : callable
        Loss function for computing gradients.
    eval_fn : callable
        ``eval_fn(x, y) -> dict`` evaluation function.
    epsilons : sequence of float
        Perturbation budgets to test.

    Returns
    -------
    dict[float, dict[str, float]]
        ``{epsilon: metrics_dict}``.
    """
    results: Dict[float, Dict[str, float]] = {}
    model.eval()

    for eps in epsilons:
        if eps == 0.0:
            x_test = x
        else:
            x_test = fgsm_attack(model, x, y, loss_fn, epsilon=eps)
        metrics = eval_fn(x_test, y)
        results[eps] = metrics

    return results
