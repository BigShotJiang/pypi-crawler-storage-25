"""Ethical, Legal, and Social Implications (ELSI) assessment module.

Provides tools for evaluating the fairness, privacy, and
interpretability of CognitiveTwin models, aligning with Objective 4
(VVUQ & ELSI) of the research proposal.

Key assessments:
* **Fairness:** demographic parity, equalised odds, calibration by group.
* **Privacy:** membership inference attack simulation.
* **Interpretability:** feature importance and attention analysis.
* **Reporting:** generate structured fairness audit reports.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from numpy.typing import NDArray


# ---------------------------------------------------------------------------
# Fairness metrics
# ---------------------------------------------------------------------------

def demographic_parity(
    y_pred: NDArray[np.integer],
    sensitive_attribute: NDArray[np.integer],
) -> Dict[str, float]:
    """Compute demographic parity across groups.

    Demographic parity requires that the positive prediction rate is
    equal across groups defined by the sensitive attribute.

    Parameters
    ----------
    y_pred : ndarray[int]
        Predicted binary labels (0 or 1).
    sensitive_attribute : ndarray[int]
        Group membership for each sample.

    Returns
    -------
    dict[str, float]
        ``group_rates``  positive prediction rate per group.
        ``max_difference``  largest pairwise difference in rates.
        ``passes``  whether max_difference < 0.05.
    """
    groups = np.unique(sensitive_attribute)
    rates: Dict[str, float] = {}

    for g in groups:
        mask = sensitive_attribute == g
        rates[str(g)] = float(np.mean(y_pred[mask]))

    rate_values = list(rates.values())
    max_diff = max(rate_values) - min(rate_values) if rate_values else 0.0

    return {
        "group_rates": rates,  # type: ignore[dict-item]
        "max_difference": max_diff,
        "passes": max_diff < 0.05,
    }


def equalized_odds(
    y_true: NDArray[np.integer],
    y_pred: NDArray[np.integer],
    sensitive_attribute: NDArray[np.integer],
) -> Dict[str, Any]:
    """Compute equalised odds across groups.

    Equalised odds requires equal TPR and FPR across groups.

    Parameters
    ----------
    y_true : ndarray[int]
        True binary labels.
    y_pred : ndarray[int]
        Predicted binary labels.
    sensitive_attribute : ndarray[int]
        Group membership.

    Returns
    -------
    dict
        Per-group TPR, FPR, and max differences.
    """
    groups = np.unique(sensitive_attribute)
    tpr_by_group: Dict[str, float] = {}
    fpr_by_group: Dict[str, float] = {}

    for g in groups:
        mask = sensitive_attribute == g
        positives = y_true[mask] == 1
        negatives = y_true[mask] == 0

        if np.sum(positives) > 0:
            tpr_by_group[str(g)] = float(np.mean(y_pred[mask][positives] == 1))
        else:
            tpr_by_group[str(g)] = 0.0

        if np.sum(negatives) > 0:
            fpr_by_group[str(g)] = float(np.mean(y_pred[mask][negatives] == 1))
        else:
            fpr_by_group[str(g)] = 0.0

    tpr_vals = list(tpr_by_group.values())
    fpr_vals = list(fpr_by_group.values())
    tpr_diff = max(tpr_vals) - min(tpr_vals) if tpr_vals else 0.0
    fpr_diff = max(fpr_vals) - min(fpr_vals) if fpr_vals else 0.0
    eo_diff = max(tpr_diff, fpr_diff)

    return {
        "tpr_by_group": tpr_by_group,
        "fpr_by_group": fpr_by_group,
        "tpr_max_difference": tpr_diff,
        "fpr_max_difference": fpr_diff,
        "equalized_odds_difference": eo_diff,
        "passes": eo_diff < 0.05,
    }


def calibration_by_group(
    y_true: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
    sensitive_attribute: NDArray[np.integer],
    n_bins: int = 10,
) -> Dict[str, float]:
    """Compute Expected Calibration Error (ECE) per demographic group.

    Parameters
    ----------
    y_true : ndarray[int]
        Binary labels.
    y_pred_proba : ndarray[float]
        Predicted probabilities.
    sensitive_attribute : ndarray[int]
        Group membership.
    n_bins : int
        Number of calibration bins.

    Returns
    -------
    dict[str, float]
        ``{group_label: ece_value}``.
    """
    from cognitivedt.evaluation.metrics import expected_calibration_error

    groups = np.unique(sensitive_attribute)
    ece_by_group: Dict[str, float] = {}

    for g in groups:
        mask = sensitive_attribute == g
        if np.sum(mask) < n_bins:
            ece_by_group[str(g)] = float("nan")
            continue
        ece, _, _ = expected_calibration_error(
            y_true[mask], y_pred_proba[mask], n_bins=n_bins
        )
        ece_by_group[str(g)] = ece

    return ece_by_group


def performance_by_group(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    sensitive_attribute: NDArray[np.integer],
) -> Dict[str, Dict[str, float]]:
    """Compute regression metrics per demographic group.

    Parameters
    ----------
    y_true, y_pred : ndarray
        Ground-truth and predicted values.
    sensitive_attribute : ndarray
        Group membership.

    Returns
    -------
    dict[str, dict[str, float]]
        ``{group_label: {"mae": ..., "rmse": ..., ...}}``.
    """
    from cognitivedt.evaluation.metrics import evaluate_regression

    groups = np.unique(sensitive_attribute)
    results: Dict[str, Dict[str, float]] = {}

    for g in groups:
        mask = sensitive_attribute == g
        results[str(g)] = evaluate_regression(y_true[mask], y_pred[mask])

    return results


def disparate_impact_ratio(
    y_pred: NDArray[np.integer],
    sensitive_attribute: NDArray[np.integer],
    privileged_group: int = 0,
    unprivileged_group: int = 1,
) -> float:
    """Compute disparate impact ratio.

    Parameters
    ----------
    y_pred : ndarray
        Binary predictions.
    sensitive_attribute : ndarray
        Group labels.
    privileged_group, unprivileged_group : int
        Group identifiers.

    Returns
    -------
    float
        Ratio of positive prediction rates.  Values in [0.8, 1.2] are
        generally considered acceptable (80% rule).
    """
    priv_mask = sensitive_attribute == privileged_group
    unpriv_mask = sensitive_attribute == unprivileged_group

    rate_priv = float(np.mean(y_pred[priv_mask])) if np.sum(priv_mask) > 0 else 0.0
    rate_unpriv = float(np.mean(y_pred[unpriv_mask])) if np.sum(unpriv_mask) > 0 else 0.0

    if rate_priv == 0:
        return 0.0
    return rate_unpriv / rate_priv


# ---------------------------------------------------------------------------
# Privacy assessment
# ---------------------------------------------------------------------------

def membership_inference_attack(
    train_losses: NDArray[np.floating],
    test_losses: NDArray[np.floating],
    threshold_percentile: float = 50.0,
) -> Dict[str, float]:
    """Simulate a basic membership inference attack.

    A membership inference attack tries to determine whether a sample
    was in the training set.  If the model over-fits, training losses
    will be systematically lower than test losses.

    Parameters
    ----------
    train_losses : ndarray
        Per-sample loss on training data.
    test_losses : ndarray
        Per-sample loss on non-training data.
    threshold_percentile : float
        Percentile of combined losses to use as threshold.

    Returns
    -------
    dict[str, float]
        ``attack_accuracy``  how well the attack discriminates members.
        ``advantage``  accuracy - 0.5 (0 = no advantage, 0.5 = perfect).
        ``vulnerable``  whether advantage > 0.1.
    """
    all_losses = np.concatenate([train_losses, test_losses])
    threshold = float(np.percentile(all_losses, threshold_percentile))

    # Predict "member" if loss < threshold
    train_pred_member = np.sum(train_losses < threshold)
    test_pred_nonmember = np.sum(test_losses >= threshold)

    accuracy = (train_pred_member + test_pred_nonmember) / len(all_losses)
    advantage = accuracy - 0.5

    return {
        "attack_accuracy": float(accuracy),
        "advantage": float(advantage),
        "vulnerable": advantage > 0.1,
    }


# ---------------------------------------------------------------------------
# Fairness audit report
# ---------------------------------------------------------------------------

def generate_fairness_report(
    y_true: NDArray[np.integer],
    y_pred: NDArray[np.integer],
    y_pred_proba: NDArray[np.floating],
    sensitive_attributes: Dict[str, NDArray[np.integer]],
) -> Dict[str, Any]:
    """Generate a comprehensive fairness audit report.

    Parameters
    ----------
    y_true : ndarray
        True binary labels.
    y_pred : ndarray
        Predicted binary labels.
    y_pred_proba : ndarray
        Predicted probabilities.
    sensitive_attributes : dict[str, ndarray]
        ``{attribute_name: group_labels}``  e.g.
        ``{"sex": ..., "age_group": ..., "ethnicity": ...}``.

    Returns
    -------
    dict[str, Any]
        Structured report with per-attribute fairness metrics.
    """
    report: Dict[str, Any] = {"overall_positive_rate": float(np.mean(y_pred))}

    for attr_name, groups in sensitive_attributes.items():
        attr_report: Dict[str, Any] = {}
        attr_report["demographic_parity"] = demographic_parity(y_pred, groups)
        attr_report["equalized_odds"] = equalized_odds(y_true, y_pred, groups)
        attr_report["calibration_by_group"] = calibration_by_group(
            y_true, y_pred_proba, groups
        )
        report[attr_name] = attr_report

    # Overall assessment
    all_pass = all(
        report[attr]["demographic_parity"]["passes"]
        and report[attr]["equalized_odds"]["passes"]
        for attr in sensitive_attributes
    )
    report["all_criteria_passed"] = all_pass

    return report
