"""Uncertainty Quantification (UQ) utilities.

Provides tools for assessing and decomposing predictive uncertainty:
* Prediction interval coverage and width.
* Epistemic vs. aleatoric uncertainty decomposition.
* Calibration of uncertainty estimates.
* Conformal prediction intervals.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import numpy as np
from numpy.typing import NDArray


def prediction_interval_metrics(
    y_true: NDArray[np.floating],
    lower: NDArray[np.floating],
    upper: NDArray[np.floating],
) -> Dict[str, float]:
    """Evaluate quality of prediction intervals.

    Parameters
    ----------
    y_true : ndarray
        Ground-truth values.
    lower : ndarray
        Lower bound of the prediction interval.
    upper : ndarray
        Upper bound of the prediction interval.

    Returns
    -------
    dict[str, float]
        ``picp``  Prediction Interval Coverage Probability (fraction of
        true values inside the interval).
        ``mpiw``  Mean Prediction Interval Width.
        ``nmpiw``  Normalised MPIW (divided by range of y_true).
    """
    in_interval = (y_true >= lower) & (y_true <= upper)
    picp = float(np.mean(in_interval))
    widths = upper - lower
    mpiw = float(np.mean(widths))

    y_range = float(np.ptp(y_true)) if np.ptp(y_true) > 0 else 1.0
    nmpiw = mpiw / y_range

    return {"picp": picp, "mpiw": mpiw, "nmpiw": nmpiw}


def uncertainty_error_correlation(
    absolute_errors: NDArray[np.floating],
    uncertainties: NDArray[np.floating],
) -> Dict[str, float]:
    """Measure how well uncertainty tracks prediction error.

    A good uncertainty estimate should correlate with actual errors:
    higher uncertainty -> larger errors.

    Parameters
    ----------
    absolute_errors : ndarray
        ``|y_true - y_pred|``.
    uncertainties : ndarray
        Model-reported uncertainty (e.g. std or variance).

    Returns
    -------
    dict[str, float]
        ``spearman_rho``  Spearman rank correlation.
        ``pearson_r``  Pearson linear correlation.
    """
    from scipy.stats import pearsonr, spearmanr

    rho, _ = spearmanr(absolute_errors, uncertainties)
    r, _ = pearsonr(absolute_errors, uncertainties)

    return {
        "spearman_rho": float(rho),
        "pearson_r": float(r),
    }


def decompose_uncertainty(
    ensemble_predictions: NDArray[np.floating],
    ensemble_variances: Optional[NDArray[np.floating]] = None,
) -> Dict[str, float]:
    """Decompose total predictive uncertainty into epistemic and aleatoric.

    Parameters
    ----------
    ensemble_predictions : ndarray
        Predictions from an ensemble, shape ``(n_models, n_samples, ...)``.
    ensemble_variances : ndarray | None
        Per-model predicted variances (aleatoric), same shape.
        If ``None``, aleatoric is assumed zero.

    Returns
    -------
    dict[str, float]
        ``epistemic``  mean epistemic uncertainty (variance of means).
        ``aleatoric``  mean aleatoric uncertainty (mean of variances).
        ``total``  sum of epistemic and aleatoric.
    """
    # Epistemic: variance of the means across ensemble members
    epistemic = float(np.mean(np.var(ensemble_predictions, axis=0)))

    # Aleatoric: mean of the predicted variances
    if ensemble_variances is not None:
        aleatoric = float(np.mean(np.mean(ensemble_variances, axis=0)))
    else:
        aleatoric = 0.0

    return {
        "epistemic": epistemic,
        "aleatoric": aleatoric,
        "total": epistemic + aleatoric,
    }


def conformal_prediction_interval(
    y_cal: NDArray[np.floating],
    y_cal_pred: NDArray[np.floating],
    y_test_pred: NDArray[np.floating],
    alpha: float = 0.05,
) -> Tuple[NDArray[np.floating], NDArray[np.floating]]:
    """Construct distribution-free conformal prediction intervals.

    Uses the split-conformal method: compute non-conformity scores on a
    calibration set, then use the (1 - ->)-quantile to form intervals on
    the test set.

    Parameters
    ----------
    y_cal : ndarray
        True values on the calibration set.
    y_cal_pred : ndarray
        Predicted values on the calibration set.
    y_test_pred : ndarray
        Predicted values on the test set.
    alpha : float
        Desired miscoverage rate (e.g. 0.05 for 95% intervals).

    Returns
    -------
    tuple[ndarray, ndarray]
        ``(lower, upper)`` prediction interval bounds for the test set.
    """
    # Non-conformity scores
    scores = np.abs(y_cal - y_cal_pred)

    # Quantile with finite-sample correction
    n = len(scores)
    q_level = np.ceil((1 - alpha) * (n + 1)) / n
    q_level = min(q_level, 1.0)
    q_hat = float(np.quantile(scores, q_level))

    lower = y_test_pred - q_hat
    upper = y_test_pred + q_hat

    return lower, upper


def uncertainty_calibration_error(
    y_true: NDArray[np.floating],
    y_pred: NDArray[np.floating],
    y_std: NDArray[np.floating],
    n_bins: int = 10,
) -> float:
    """Calibration error for regression uncertainty.

    Checks whether the fraction of observations within k-sigma intervals
    matches the expected coverage from a Gaussian.

    Parameters
    ----------
    y_true : ndarray
        True values.
    y_pred : ndarray
        Predicted means.
    y_std : ndarray
        Predicted standard deviations.
    n_bins : int
        Number of confidence levels to check.

    Returns
    -------
    float
        Mean absolute calibration error across confidence levels.
    """
    from scipy.stats import norm

    expected_coverages = np.linspace(0.1, 0.9, n_bins)
    errors = []

    for p in expected_coverages:
        z = norm.ppf((1 + p) / 2)
        lower = y_pred - z * y_std
        upper = y_pred + z * y_std
        observed_coverage = float(np.mean((y_true >= lower) & (y_true <= upper)))
        errors.append(abs(observed_coverage - p))

    return float(np.mean(errors))
