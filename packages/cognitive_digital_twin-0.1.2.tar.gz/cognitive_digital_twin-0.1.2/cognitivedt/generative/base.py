"""Abstract base class for generative models (synthetic data generation).

Generative models in CognitiveTwin produce **synthetic patient data** for:

* Data augmentation (especially for under-represented sub-groups).
* Privacy-preserving cohort generation.
* Counter-factual trajectory exploration ("what if APOE-->4 = 0?").

All generative models subclass :class:`BaseGenerativeModel` and implement
``generate``, ``forward`` (training), and ``compute_loss``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional

import torch
import torch.nn as nn


@dataclass
class GenerativeOutput:
    """Standard return container for generative model forward passes.

    Attributes
    ----------
    x_generated : Tensor
        Generated (reconstructed) observations, ``(batch, time, obs_dim)``
        or ``(batch, obs_dim)``.
    loss : Tensor
        Total scalar training loss.
    reconstruction_loss : Tensor | None
        Reconstruction component of the loss.
    kl_divergence : Tensor | None
        KL divergence (for VAE-family models).
    discriminator_loss : Tensor | None
        Discriminator loss (for GAN-family models).
    generator_loss : Tensor | None
        Generator loss (for GAN-family models).
    extras : dict
        Model-specific auxiliary outputs.
    """

    x_generated: torch.Tensor
    loss: torch.Tensor
    reconstruction_loss: Optional[torch.Tensor] = None
    kl_divergence: Optional[torch.Tensor] = None
    discriminator_loss: Optional[torch.Tensor] = None
    generator_loss: Optional[torch.Tensor] = None
    extras: Dict[str, torch.Tensor] = field(default_factory=dict)


class BaseGenerativeModel(ABC, nn.Module):
    """Abstract base for conditional generative models.

    Subclasses must implement:
    * :meth:`forward`  training pass (reconstruction / adversarial).
    * :meth:`generate`  sample new synthetic observations.
    * :meth:`compute_loss`  return the training objective.
    """

    @abstractmethod
    def forward(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> GenerativeOutput:
        """Training forward pass.

        Parameters
        ----------
        x : Tensor
            Real observations, ``(batch, obs_dim)`` or
            ``(batch, time, obs_dim)``.
        conditions : Tensor | None
            Conditioning variables (demographics, genetics, etc.),
            shape ``(batch, cond_dim)``.

        Returns
        -------
        GenerativeOutput
        """
        ...

    @abstractmethod
    def generate(
        self,
        n_samples: int,
        conditions: Optional[torch.Tensor] = None,
        *,
        temperature: float = 1.0,
    ) -> torch.Tensor:
        """Generate synthetic observations.

        Parameters
        ----------
        n_samples : int
            Number of samples to generate.
        conditions : Tensor | None
            Conditioning variables, ``(n_samples, cond_dim)``.
        temperature : float
            Sampling temperature  higher = more diverse.

        Returns
        -------
        Tensor
            Synthetic observations, ``(n_samples, obs_dim)`` or
            ``(n_samples, time, obs_dim)``.
        """
        ...

    @abstractmethod
    def compute_loss(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute the scalar training loss.

        Parameters
        ----------
        x : Tensor
            Real observations.
        conditions : Tensor | None
            Conditioning variables.

        Returns
        -------
        Tensor
            Scalar loss to be minimised.
        """
        ...
