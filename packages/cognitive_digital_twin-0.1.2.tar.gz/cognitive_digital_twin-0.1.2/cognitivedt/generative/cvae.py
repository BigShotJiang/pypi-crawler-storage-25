"""Conditional Variational Auto-Encoder (CVAE) for synthetic patient generation.

Generates synthetic patient visit data **conditioned** on patient-level
attributes (e.g. age, sex, APOE genotype, baseline diagnosis).

Architecture
------------
    Encoder:  [x, c] -> [->_z, logvar_z]      (recognition model)
    Latent:   z ~ N(->_z, diag(exp(logvar_z)))
    Decoder:  [z, c] -> x_reconstructed        (generative model)

where *c* is the conditioning vector and *x* is the patient feature vector.

Training objective: ELBO = E[log p(x | z, c)] - KL[q(z | x, c) || p(z | c)]
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from cognitivedt.generative.base import BaseGenerativeModel, GenerativeOutput


class ConditionalVAE(BaseGenerativeModel):
    """Conditional VAE for synthetic patient data generation.

    Parameters
    ----------
    obs_dim : int
        Dimensionality of the observation / feature vector.
    cond_dim : int
        Dimensionality of the conditioning vector.
    latent_dim : int
        Dimensionality of the VAE latent space.
    hidden_dim : int
        Width of encoder and decoder hidden layers.
    n_hidden_layers : int
        Number of hidden layers in encoder/decoder.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        obs_dim: int = 256,
        cond_dim: int = 16,
        latent_dim: int = 32,
        hidden_dim: int = 256,
        n_hidden_layers: int = 2,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.obs_dim = obs_dim
        self.cond_dim = cond_dim
        self.latent_dim = latent_dim

        # ---- Encoder: [x, c] -> ->, logvar ---------------------------------
        encoder_layers: list[nn.Module] = [
            nn.Linear(obs_dim + cond_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        ]
        for _ in range(n_hidden_layers - 1):
            encoder_layers.extend([
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
        self.encoder = nn.Sequential(*encoder_layers)
        self.enc_mean = nn.Linear(hidden_dim, latent_dim)
        self.enc_log_var = nn.Linear(hidden_dim, latent_dim)

        # ---- Decoder: [z, c] -> x_recon -----------------------------------
        decoder_layers: list[nn.Module] = [
            nn.Linear(latent_dim + cond_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        ]
        for _ in range(n_hidden_layers - 1):
            decoder_layers.extend([
                nn.Linear(hidden_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(dropout),
            ])
        decoder_layers.append(nn.Linear(hidden_dim, obs_dim))
        self.decoder = nn.Sequential(*decoder_layers)

    # ------------------------------------------------------------------
    # BaseGenerativeModel interface
    # ------------------------------------------------------------------

    def forward(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> GenerativeOutput:
        """Training forward pass.

        Parameters
        ----------
        x : Tensor
            ``(batch, obs_dim)`` real observations.
        conditions : Tensor | None
            ``(batch, cond_dim)`` conditioning variables.

        Returns
        -------
        GenerativeOutput
        """
        cond = self._ensure_conditions(x, conditions)
        enc_input = torch.cat([x, cond], dim=-1)

        h = self.encoder(enc_input)
        mu = self.enc_mean(h)
        log_var = self.enc_log_var(h)

        # Reparameterised sampling
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        z = mu + eps * std

        dec_input = torch.cat([z, cond], dim=-1)
        x_recon = self.decoder(dec_input)

        # Losses
        recon_loss = F.mse_loss(x_recon, x, reduction="mean")
        kl_loss = -0.5 * torch.sum(1 + log_var - mu.pow(2) - log_var.exp(), dim=-1).mean()
        total_loss = recon_loss + kl_loss

        return GenerativeOutput(
            x_generated=x_recon,
            loss=total_loss,
            reconstruction_loss=recon_loss,
            kl_divergence=kl_loss,
        )

    def generate(
        self,
        n_samples: int,
        conditions: Optional[torch.Tensor] = None,
        *,
        temperature: float = 1.0,
    ) -> torch.Tensor:
        """Generate synthetic observations.

        Parameters
        ----------
        n_samples : int
            Number of samples.
        conditions : Tensor | None
            ``(n_samples, cond_dim)``.
        temperature : float
            Scales the sampling noise (higher = more diverse).

        Returns
        -------
        Tensor
            ``(n_samples, obs_dim)`` synthetic observations.
        """
        device = next(self.parameters()).device
        z = torch.randn(n_samples, self.latent_dim, device=device) * temperature

        if conditions is None:
            conditions = torch.zeros(n_samples, self.cond_dim, device=device)

        dec_input = torch.cat([z, conditions], dim=-1)
        return self.decoder(dec_input)

    def compute_loss(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute ELBO loss."""
        return self.forward(x, conditions).loss

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _ensure_conditions(
        self, x: torch.Tensor, conditions: Optional[torch.Tensor]
    ) -> torch.Tensor:
        """Return conditions tensor; create zeros if None."""
        if conditions is not None:
            return conditions
        return torch.zeros(x.shape[0], self.cond_dim, device=x.device)
