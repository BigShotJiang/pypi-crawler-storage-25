"""Conditional Generative Adversarial Network (CGAN) for synthetic data.

Generates realistic synthetic patient data through adversarial training:
* **Generator (G):**  noise + conditions -> synthetic patient features.
* **Discriminator (D):**  features + conditions -> real/fake probability.

Conditioning variables include demographics, genetics, and baseline
diagnosis, allowing targeted generation of specific patient sub-groups.

Training follows the standard minimax game with label smoothing and
spectral normalisation for stability.
"""

from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from cognitivedt.generative.base import BaseGenerativeModel, GenerativeOutput


class Generator(nn.Module):
    """CGAN generator network: [noise, conditions] -> synthetic features."""

    def __init__(
        self,
        noise_dim: int,
        cond_dim: int,
        obs_dim: int,
        hidden_dim: int,
        n_layers: int,
        dropout: float,
    ) -> None:
        super().__init__()
        layers: list[nn.Module] = [
            nn.Linear(noise_dim + cond_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Dropout(dropout),
        ]
        for _ in range(n_layers - 1):
            layers.extend([
                nn.Linear(hidden_dim, hidden_dim),
                nn.BatchNorm1d(hidden_dim),
                nn.LeakyReLU(0.2),
                nn.Dropout(dropout),
            ])
        layers.append(nn.Linear(hidden_dim, obs_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, noise: torch.Tensor, conditions: torch.Tensor) -> torch.Tensor:
        """Generate synthetic features from noise and conditions."""
        return self.net(torch.cat([noise, conditions], dim=-1))


class Discriminator(nn.Module):
    """CGAN discriminator network: [features, conditions] -> real probability."""

    def __init__(
        self,
        obs_dim: int,
        cond_dim: int,
        hidden_dim: int,
        n_layers: int,
        dropout: float,
    ) -> None:
        super().__init__()
        layers: list[nn.Module] = [
            nn.Linear(obs_dim + cond_dim, hidden_dim),
            nn.LeakyReLU(0.2),
            nn.Dropout(dropout),
        ]
        for _ in range(n_layers - 1):
            layers.extend([
                nn.Linear(hidden_dim, hidden_dim),
                nn.LeakyReLU(0.2),
                nn.Dropout(dropout),
            ])
        layers.append(nn.Linear(hidden_dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor, conditions: torch.Tensor) -> torch.Tensor:
        """Return logit for real vs. fake classification."""
        return self.net(torch.cat([x, conditions], dim=-1))


class ConditionalGAN(BaseGenerativeModel):
    """Conditional GAN for synthetic patient data.

    Parameters
    ----------
    obs_dim : int
        Feature vector dimensionality.
    cond_dim : int
        Conditioning vector dimensionality.
    noise_dim : int
        Dimensionality of the input noise vector.
    hidden_dim : int
        Width of hidden layers in G and D.
    n_layers : int
        Number of hidden layers.
    dropout : float
        Dropout probability.
    label_smoothing : float
        One-sided label smoothing for the discriminator (real labels
        are set to ``1.0 - label_smoothing``).
    """

    def __init__(
        self,
        obs_dim: int = 256,
        cond_dim: int = 16,
        noise_dim: int = 64,
        hidden_dim: int = 256,
        n_layers: int = 3,
        dropout: float = 0.1,
        label_smoothing: float = 0.1,
    ) -> None:
        super().__init__()
        self.obs_dim = obs_dim
        self.cond_dim = cond_dim
        self.noise_dim = noise_dim
        self.label_smoothing = label_smoothing

        self.generator = Generator(
            noise_dim=noise_dim,
            cond_dim=cond_dim,
            obs_dim=obs_dim,
            hidden_dim=hidden_dim,
            n_layers=n_layers,
            dropout=dropout,
        )
        self.discriminator = Discriminator(
            obs_dim=obs_dim,
            cond_dim=cond_dim,
            hidden_dim=hidden_dim,
            n_layers=n_layers,
            dropout=dropout,
        )

    # ------------------------------------------------------------------
    # BaseGenerativeModel interface
    # ------------------------------------------------------------------

    def forward(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> GenerativeOutput:
        """Full training forward pass (both G and D losses).

        Parameters
        ----------
        x : Tensor
            ``(batch, obs_dim)`` real observations.
        conditions : Tensor | None
            ``(batch, cond_dim)`` conditioning variables.

        Returns
        -------
        GenerativeOutput
        """
        cond = self._ensure_conditions(x, conditions)
        batch = x.shape[0]
        device = x.device

        # --- Generate fake data -------------------------------------------
        noise = torch.randn(batch, self.noise_dim, device=device)
        x_fake = self.generator(noise, cond)

        # --- Discriminator ------------------------------------------------
        d_real = self.discriminator(x, cond)
        d_fake = self.discriminator(x_fake.detach(), cond)

        real_label = torch.full((batch, 1), 1.0 - self.label_smoothing, device=device)
        fake_label = torch.zeros(batch, 1, device=device)

        d_loss_real = F.binary_cross_entropy_with_logits(d_real, real_label)
        d_loss_fake = F.binary_cross_entropy_with_logits(d_fake, fake_label)
        d_loss = (d_loss_real + d_loss_fake) / 2

        # --- Generator ----------------------------------------------------
        d_fake_for_g = self.discriminator(x_fake, cond)
        g_loss = F.binary_cross_entropy_with_logits(
            d_fake_for_g, torch.ones(batch, 1, device=device)
        )

        total_loss = d_loss + g_loss

        return GenerativeOutput(
            x_generated=x_fake,
            loss=total_loss,
            discriminator_loss=d_loss,
            generator_loss=g_loss,
        )

    def generate(
        self,
        n_samples: int,
        conditions: Optional[torch.Tensor] = None,
        *,
        temperature: float = 1.0,
    ) -> torch.Tensor:
        """Generate synthetic patient features.

        Parameters
        ----------
        n_samples : int
            Number of synthetic samples.
        conditions : Tensor | None
            ``(n_samples, cond_dim)``.
        temperature : float
            Scales the input noise.

        Returns
        -------
        Tensor
            ``(n_samples, obs_dim)`` synthetic features.
        """
        device = next(self.parameters()).device
        noise = torch.randn(n_samples, self.noise_dim, device=device) * temperature

        if conditions is None:
            conditions = torch.zeros(n_samples, self.cond_dim, device=device)

        self.generator.eval()
        with torch.no_grad():
            result = self.generator(noise, conditions)
        self.generator.train()
        return result

    def compute_loss(
        self,
        x: torch.Tensor,
        conditions: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Compute combined generator + discriminator loss."""
        return self.forward(x, conditions).loss

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _ensure_conditions(
        self, x: torch.Tensor, conditions: Optional[torch.Tensor]
    ) -> torch.Tensor:
        if conditions is not None:
            return conditions
        return torch.zeros(x.shape[0], self.cond_dim, device=x.device)
