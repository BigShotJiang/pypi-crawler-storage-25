"""CognitiveTwin (cognitivedt)  AI-driven digital twins for cognitive decline.

Top-level package.  Import the most commonly used classes here for
convenience::

    from cognitivedt import PatientData, VisitData, TADPOLELoader
"""

__version__ = "0.1.0"
__author__ = "Bulent Soykan"
__email__ = "soykanb@gmail.com"
__url__ = "https://github.com/bulentsoykan/cognitivedt"

from cognitivedt.data.base import PatientData, VisitData
from cognitivedt.data.schemas import (
    CognitiveScores,
    CSFBiomarkers,
    Demographics,
    Diagnosis,
    GeneticProfile,
    MRIVolumetrics,
    PETBiomarkers,
    Sex,
)
from cognitivedt.io.loader import TADPOLELoader

__all__ = [
    # Version
    "__version__",
    # Data models
    "PatientData",
    "VisitData",
    "CognitiveScores",
    "CSFBiomarkers",
    "Demographics",
    "Diagnosis",
    "GeneticProfile",
    "MRIVolumetrics",
    "PETBiomarkers",
    "Sex",
    # I/O
    "TADPOLELoader",
]
