"""Plotting and visualisation utilities for CognitiveTwin.

Provides publication-quality figures for:
* Patient trajectory plots (observed + predicted with uncertainty).
* Calibration / reliability diagrams.
* Fairness comparison bar charts.
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
from numpy.typing import NDArray


def plot_trajectory(
    times: NDArray[np.floating],
    observed: NDArray[np.floating],
    predicted: Optional[NDArray[np.floating]] = None,
    lower: Optional[NDArray[np.floating]] = None,
    upper: Optional[NDArray[np.floating]] = None,
    title: str = "Cognitive Trajectory",
    ylabel: str = "MMSE Score",
    save_path: Optional[str] = None,
) -> None:
    """Plot observed vs. predicted trajectory with uncertainty band.

    Parameters
    ----------
    times : ndarray
        Time points (months from baseline).
    observed : ndarray
        Observed values.
    predicted : ndarray | None
        Predicted values.
    lower, upper : ndarray | None
        95% prediction interval bounds.
    title, ylabel : str
        Plot labels.
    save_path : str | None
        File path to save the figure.
    """
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(times[: len(observed)], observed, "ko-", label="Observed", markersize=5)

    if predicted is not None:
        pred_times = times[: len(predicted)]
        ax.plot(pred_times, predicted, "b--", label="Predicted", linewidth=2)
        if lower is not None and upper is not None:
            ax.fill_between(pred_times, lower, upper, alpha=0.2, color="blue", label="95% CI")

    ax.set_xlabel("Months from baseline")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    ax.grid(True, alpha=0.3)

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_calibration_diagram(
    bin_confidences: Sequence[float],
    bin_accuracies: Sequence[float],
    ece: float,
    title: str = "Reliability Diagram",
    save_path: Optional[str] = None,
) -> None:
    """Plot a calibration / reliability diagram.

    Parameters
    ----------
    bin_confidences, bin_accuracies : sequence of float
        Per-bin mean confidence and observed accuracy.
    ece : float
        Expected Calibration Error.
    title : str
        Plot title.
    save_path : str | None
        File path to save.
    """
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.bar(bin_confidences, bin_accuracies, width=0.08, alpha=0.7,
           color="steelblue", edgecolor="black", label=f"Model (ECE={ece:.3f})")
    ax.plot([0, 1], [0, 1], "r--", label="Perfect calibration")
    ax.set_xlabel("Mean predicted probability")
    ax.set_ylabel("Observed frequency")
    ax.set_title(title)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.legend()
    ax.set_aspect("equal")

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_fairness_comparison(
    group_metrics: Dict[str, Dict[str, float]],
    metric_name: str = "mae",
    title: str = "Performance by Demographic Group",
    save_path: Optional[str] = None,
) -> None:
    """Bar chart comparing a metric across demographic groups.

    Parameters
    ----------
    group_metrics : dict[str, dict[str, float]]
        ``{group_name: {metric_name: value}}``.
    metric_name : str
        Which metric to plot.
    title : str
        Plot title.
    save_path : str | None
        File path to save.
    """
    import matplotlib.pyplot as plt

    groups = list(group_metrics.keys())
    values = [group_metrics[g][metric_name] for g in groups]

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(groups, values, color="steelblue", edgecolor="black", alpha=0.8)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                f"{val:.3f}", ha="center", va="bottom", fontsize=10)
    ax.set_ylabel(metric_name.upper())
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.3)

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
