"""Utility functions (plotting, logging, etc.)."""
