"""Abstract base class for temporal dynamics / state-space models.

Every dynamics model in CognitiveTwin (DMM, KVAE, etc.) must subclass
:class:`BaseDynamicsModel` and implement its abstract interface.

The dynamics layer sits *between* the fusion/representation layer and the
predictive output layer.  It receives a sequence of fused representations
``z_{1:T}`` and models how the latent patient state evolves over time.

Key responsibilities
--------------------
* **Filtering:** estimate the current latent state given observations up to
  now -> ``p(z_t | x_{1:t})``.
* **Prediction (forecasting):** sample future latent states ->
  ``p(z_{t+h} | x_{1:t})``.
* **Smoothing (optional):** estimate past states using all observations ->
  ``p(z_t | x_{1:T})``.
* **ELBO / loss computation:** return the training objective (reconstruction
  + KL terms for variational models).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn


@dataclass
class DynamicsOutput:
    """Standard output container for dynamics models.

    Attributes
    ----------
    z_mean : Tensor
        Posterior (or filtered) mean of latent states, ``(batch, time, latent_dim)``.
    z_log_var : Tensor
        Log-variance of latent states, ``(batch, time, latent_dim)``.
    x_recon : Tensor
        Reconstructed observations, ``(batch, time, obs_dim)``.
    loss : Tensor
        Scalar training loss (negative ELBO or similar).
    kl_divergence : Tensor | None
        KL divergence term if applicable.
    reconstruction_loss : Tensor | None
        Reconstruction loss term.
    extras : dict
        Any model-specific auxiliary outputs (attention weights, etc.).
    """

    z_mean: torch.Tensor
    z_log_var: torch.Tensor
    x_recon: torch.Tensor
    loss: torch.Tensor
    kl_divergence: Optional[torch.Tensor] = None
    reconstruction_loss: Optional[torch.Tensor] = None
    extras: Dict[str, torch.Tensor] = field(default_factory=dict)


class BaseDynamicsModel(ABC, nn.Module):
    """Abstract base class for temporal dynamics models.

    Subclasses must implement:
    * :meth:`forward`  full pass returning :class:`DynamicsOutput`.
    * :meth:`predict`  forecast future latent states given history.
    * :attr:`latent_dim`  dimensionality of the latent space.
    """

    @abstractmethod
    def forward(
        self,
        x: torch.Tensor,
        time_points: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
    ) -> DynamicsOutput:
        """Full forward pass for training (filtering + reconstruction).

        Parameters
        ----------
        x : Tensor
            Observation sequence, shape ``(batch, time, obs_dim)``.
            Typically the output of a fusion model.
        time_points : Tensor | None
            Absolute or relative time stamps, shape ``(batch, time)``.
            Used by models that handle irregular time intervals.
        mask : Tensor | None
            Boolean mask, shape ``(batch, time)`` or ``(batch, time, obs_dim)``.
            ``True`` for observed, ``False`` for missing.

        Returns
        -------
        DynamicsOutput
        """
        ...

    @abstractmethod
    def predict(
        self,
        x_history: torch.Tensor,
        horizon: int,
        time_history: Optional[torch.Tensor] = None,
        time_future: Optional[torch.Tensor] = None,
        n_samples: int = 1,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forecast future latent states (and optionally observations).

        Parameters
        ----------
        x_history : Tensor
            Observed sequence, ``(batch, T_hist, obs_dim)``.
        horizon : int
            Number of future time-steps to predict.
        time_history : Tensor | None
            Time stamps for the observed sequence.
        time_future : Tensor | None
            Time stamps for the future steps.
        n_samples : int
            Number of Monte-Carlo forecast samples (for uncertainty).

        Returns
        -------
        tuple[Tensor, Tensor]
            ``(mean_prediction, std_prediction)`` each of shape
            ``(batch, horizon, obs_dim)``.  If ``n_samples > 1``, the mean
            and std are computed across the sample dimension.
        """
        ...

    @property
    @abstractmethod
    def latent_dim(self) -> int:
        """Dimensionality of the latent state ``z_t``."""
        ...

    # ------------------------------------------------------------------
    # Convenience (non-abstract) methods
    # ------------------------------------------------------------------

    def sample_latent(
        self,
        mean: torch.Tensor,
        log_var: torch.Tensor,
    ) -> torch.Tensor:
        """Reparameterised sampling from a diagonal Gaussian.

        Parameters
        ----------
        mean : Tensor
            Gaussian mean, any shape.
        log_var : Tensor
            Log-variance, same shape as *mean*.

        Returns
        -------
        Tensor
            A sample of the same shape.
        """
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mean + eps * std

    def kl_divergence_standard_normal(
        self,
        mean: torch.Tensor,
        log_var: torch.Tensor,
    ) -> torch.Tensor:
        """Analytic KL divergence ``KL[q(z) || N(0, I)]``.

        Parameters
        ----------
        mean, log_var : Tensor
            Parameters of the approximate posterior ``q(z) = N(mean, exp(log_var))``.

        Returns
        -------
        Tensor
            Scalar KL divergence (summed over latent dims, averaged over batch).
        """
        kl = -0.5 * torch.sum(1 + log_var - mean.pow(2) - log_var.exp(), dim=-1)
        return kl.mean()
