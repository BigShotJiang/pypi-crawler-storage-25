"""Deep Markov Model (DMM) for temporal cognitive dynamics.

Implements the generative model described by Krishnan et al. (2017)
adapted for clinical longitudinal data:

    Generative model:
        z_1 ~ N(->_0, ò_0)                          (initial state)
        z_t | z_{t-1} ~ N(->_trans(z_{t-1}), ò_trans(z_{t-1}))  (transition)
        x_t | z_t     ~ N(->_emit(z_t),  ò_emit(z_t))           (emission)

    Inference model:
        q(z_{1:T} | x_{1:T}) = _t  q(z_t | z_{t-1}, x_{1:T})
        parameterised by a bidirectional RNN (the "combiner").

Training objective: maximise the Evidence Lower Bound (ELBO).
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from cognitivedt.dynamics.base import BaseDynamicsModel, DynamicsOutput


class GatedTransition(nn.Module):
    """Neural network parameterising the Markov transition ``p(z_t | z_{t-1})``."""

    def __init__(self, z_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.lin_gate = nn.Linear(z_dim, z_dim)
        self.lin_proposed_mean = nn.Linear(z_dim, z_dim)
        self.lin_z_to_hidden = nn.Linear(z_dim, hidden_dim)
        self.lin_hidden_to_mean = nn.Linear(hidden_dim, z_dim)
        self.lin_z_to_log_var = nn.Linear(z_dim, z_dim)

        # Softplus for positive std
        self.softplus = nn.Softplus()

    def forward(self, z_prev: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute prior mean and log-var for z_t given z_{t-1}."""
        gate = torch.sigmoid(self.lin_gate(z_prev))
        proposed_mean = self.lin_proposed_mean(z_prev)
        hidden = F.relu(self.lin_z_to_hidden(z_prev))
        mean = gate * proposed_mean + (1 - gate) * self.lin_hidden_to_mean(hidden)
        log_var = self.lin_z_to_log_var(F.relu(proposed_mean))
        return mean, log_var


class Emitter(nn.Module):
    """Neural network parameterising the emission ``p(x_t | z_t)``."""

    def __init__(self, z_dim: int, obs_dim: int, hidden_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(z_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, obs_dim),
        )

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        """Map latent state to observation space."""
        return self.net(z)


class Combiner(nn.Module):
    """Combine RNN hidden state with prior to form the approximate posterior.

    q(z_t | z_{t-1}, x_{1:T}) is parameterised by combining the transition
    prior with information from a bidirectional RNN running over observations.
    """

    def __init__(self, z_dim: int, rnn_dim: int) -> None:
        super().__init__()
        self.lin_z = nn.Linear(z_dim, z_dim)
        self.lin_rnn = nn.Linear(rnn_dim, z_dim)
        self.lin_mean = nn.Linear(z_dim, z_dim)
        self.lin_log_var = nn.Linear(z_dim, z_dim)
        self.tanh = nn.Tanh()

    def forward(
        self, z_prev: torch.Tensor, rnn_hidden: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute posterior mean and log-var for z_t."""
        combined = self.tanh(self.lin_z(z_prev) + self.lin_rnn(rnn_hidden))
        mean = self.lin_mean(combined)
        log_var = self.lin_log_var(combined)
        return mean, log_var


class DeepMarkovModel(BaseDynamicsModel):
    """Deep Markov Model for cognitive decline dynamics.

    Parameters
    ----------
    obs_dim : int
        Observation dimensionality (output of the fusion model).
    z_dim : int
        Latent state dimensionality.
    hidden_dim : int
        Hidden layer width for transition / emission networks.
    rnn_dim : int
        Hidden size of the inference (bidirectional GRU) network.
    n_rnn_layers : int
        Number of recurrent layers in the inference network.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        obs_dim: int = 256,
        z_dim: int = 64,
        hidden_dim: int = 128,
        rnn_dim: int = 128,
        n_rnn_layers: int = 1,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self._z_dim = z_dim
        self.obs_dim = obs_dim
        self.rnn_dim = rnn_dim

        # Generative model components
        self.transition = GatedTransition(z_dim, hidden_dim)
        self.emitter = Emitter(z_dim, obs_dim, hidden_dim)

        # Initial state prior parameters
        self.z0_mean = nn.Parameter(torch.zeros(z_dim))
        self.z0_log_var = nn.Parameter(torch.zeros(z_dim))

        # Inference network: bidirectional GRU over observations
        self.rnn = nn.GRU(
            input_size=obs_dim,
            hidden_size=rnn_dim,
            num_layers=n_rnn_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if n_rnn_layers > 1 else 0.0,
        )

        # Combiner merges RNN output with transition prior
        self.combiner = Combiner(z_dim, rnn_dim * 2)  # *2 for bidirectional

    # ------------------------------------------------------------------
    # BaseDynamicsModel interface
    # ------------------------------------------------------------------

    @property
    def latent_dim(self) -> int:  # noqa: D102
        return self._z_dim

    def forward(
        self,
        x: torch.Tensor,
        time_points: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
    ) -> DynamicsOutput:
        """Training forward pass: encode observations, compute ELBO.

        Parameters
        ----------
        x : Tensor
            ``(batch, T, obs_dim)``  observation sequence.
        time_points : Tensor | None
            ``(batch, T)``  timestamps (unused in basic DMM).
        mask : Tensor | None
            ``(batch, T)``  boolean mask for observed time-steps.

        Returns
        -------
        DynamicsOutput
        """
        batch, T, _ = x.shape

        # --- Inference network (run RNN over observations) -----------------
        rnn_out, _ = self.rnn(x)  # (batch, T, rnn_dim*2)

        # --- Sequential latent sampling ------------------------------------
        z_means = []
        z_log_vars = []
        z_samples = []
        x_recons = []
        kl_total = torch.tensor(0.0, device=x.device)

        z_prev = self.z0_mean.expand(batch, -1)
        for t in range(T):
            # Prior from transition
            prior_mean, prior_log_var = self.transition(z_prev)

            # Posterior from combiner
            post_mean, post_log_var = self.combiner(z_prev, rnn_out[:, t, :])

            # Sample z_t (reparameterised)
            z_t = self.sample_latent(post_mean, post_log_var)

            # Emit observation
            x_recon_t = self.emitter(z_t)

            # KL divergence: q(z_t | ...) || p(z_t | z_{t-1})
            kl_t = self._kl_gaussian(
                post_mean, post_log_var, prior_mean, prior_log_var
            )
            kl_total = kl_total + kl_t

            z_means.append(post_mean)
            z_log_vars.append(post_log_var)
            z_samples.append(z_t)
            x_recons.append(x_recon_t)
            z_prev = z_t

        z_mean = torch.stack(z_means, dim=1)       # (batch, T, z_dim)
        z_log_var = torch.stack(z_log_vars, dim=1)  # (batch, T, z_dim)
        x_recon = torch.stack(x_recons, dim=1)      # (batch, T, obs_dim)

        # --- Losses --------------------------------------------------------
        recon_loss = F.mse_loss(x_recon, x, reduction="mean")
        loss = recon_loss + kl_total

        return DynamicsOutput(
            z_mean=z_mean,
            z_log_var=z_log_var,
            x_recon=x_recon,
            loss=loss,
            kl_divergence=kl_total,
            reconstruction_loss=recon_loss,
        )

    def predict(
        self,
        x_history: torch.Tensor,
        horizon: int,
        time_history: Optional[torch.Tensor] = None,
        time_future: Optional[torch.Tensor] = None,
        n_samples: int = 1,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forecast future observations.

        Parameters
        ----------
        x_history : Tensor
            ``(batch, T_hist, obs_dim)``.
        horizon : int
            Steps to forecast.
        n_samples : int
            Monte-Carlo samples for uncertainty estimation.

        Returns
        -------
        tuple[Tensor, Tensor]
            ``(mean, std)`` each ``(batch, horizon, obs_dim)``.
        """
        batch = x_history.shape[0]

        all_preds = []
        for _ in range(n_samples):
            # Encode history to get final latent state
            out = self.forward(x_history)
            z_t = self.sample_latent(
                out.z_mean[:, -1, :], out.z_log_var[:, -1, :]
            )

            preds = []
            for _ in range(horizon):
                z_mean, z_log_var = self.transition(z_t)
                z_t = self.sample_latent(z_mean, z_log_var)
                x_pred = self.emitter(z_t)
                preds.append(x_pred)

            all_preds.append(torch.stack(preds, dim=1))  # (batch, horizon, obs_dim)

        samples = torch.stack(all_preds, dim=0)  # (n_samples, batch, horizon, obs_dim)
        mean = samples.mean(dim=0)
        std = samples.std(dim=0) if n_samples > 1 else torch.zeros_like(mean)
        return mean, std

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _kl_gaussian(
        mu_q: torch.Tensor,
        logvar_q: torch.Tensor,
        mu_p: torch.Tensor,
        logvar_p: torch.Tensor,
    ) -> torch.Tensor:
        """KL divergence between two diagonal Gaussians, averaged over batch."""
        var_q = logvar_q.exp()
        var_p = logvar_p.exp()
        kl = 0.5 * (
            logvar_p - logvar_q + (var_q + (mu_q - mu_p).pow(2)) / var_p - 1
        )
        return kl.sum(dim=-1).mean()
