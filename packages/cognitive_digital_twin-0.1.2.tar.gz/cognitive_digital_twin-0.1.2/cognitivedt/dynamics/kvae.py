"""Kalman Variational Auto-Encoder (KVAE) for temporal dynamics.

Combines a deep encoder/decoder (VAE) with a linear-Gaussian
state-space model (Kalman filter).  The VAE maps high-dimensional
observations to a low-dimensional latent code, while the Kalman filter
models smooth linear dynamics in that code space.

Architecture
------------
    Encoder:  x_t  ->  a_t  (VAE bottleneck code)
    Kalman:   a_t  ->  z_t  (linear state-space dynamics)
    Decoder:  a_t  ->  x_t (reconstruction)

Advantages over the DMM:
* Closed-form Kalman updates give efficient exact inference in the
  linear-Gaussian sub-model.
* Disentangles observation non-linearity (VAE) from dynamics (Kalman),
  improving interpretability.

Reference: Fraccaro et al., "A Disentangled Recognition and Nonlinear
Dynamics Model for Unsupervised Learning", NeurIPS 2017.
"""

from __future__ import annotations

from typing import Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from cognitivedt.dynamics.base import BaseDynamicsModel, DynamicsOutput


class KalmanVAE(BaseDynamicsModel):
    """Kalman Variational Auto-Encoder.

    Parameters
    ----------
    obs_dim : int
        Observation dimensionality (from fusion layer).
    a_dim : int
        VAE bottleneck dimensionality.
    z_dim : int
        Kalman filter state dimensionality.
    encoder_hidden : int
        Hidden units in the VAE encoder.
    decoder_hidden : int
        Hidden units in the VAE decoder.
    dropout : float
        Dropout probability.
    """

    def __init__(
        self,
        obs_dim: int = 256,
        a_dim: int = 32,
        z_dim: int = 64,
        encoder_hidden: int = 128,
        decoder_hidden: int = 128,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self._z_dim = z_dim
        self.obs_dim = obs_dim
        self.a_dim = a_dim

        # ---- VAE Encoder: x_t -> (->_a, logvar_a) -------------------------
        self.encoder = nn.Sequential(
            nn.Linear(obs_dim, encoder_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(encoder_hidden, encoder_hidden),
            nn.ReLU(),
        )
        self.enc_mean = nn.Linear(encoder_hidden, a_dim)
        self.enc_log_var = nn.Linear(encoder_hidden, a_dim)

        # ---- VAE Decoder: a_t -> x_t  ------------------------------------
        self.decoder = nn.Sequential(
            nn.Linear(a_dim, decoder_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(decoder_hidden, decoder_hidden),
            nn.ReLU(),
            nn.Linear(decoder_hidden, obs_dim),
        )

        # ---- Kalman parameters (learnable) --------------------------------
        # Transition matrix A: z_t = A z_{t-1} + process noise
        self.A = nn.Parameter(torch.eye(z_dim) * 0.99)
        # Emission matrix C: a_t = C z_t + observation noise
        self.C = nn.Parameter(torch.randn(a_dim, z_dim) * 0.1)
        # Log-diagonal of process and observation noise covariances
        self.log_Q = nn.Parameter(torch.zeros(z_dim))  # process noise
        self.log_R = nn.Parameter(torch.zeros(a_dim))  # observation noise

        # Initial state
        self.z0_mean = nn.Parameter(torch.zeros(z_dim))
        self.z0_log_var = nn.Parameter(torch.zeros(z_dim))

    # ------------------------------------------------------------------
    # BaseDynamicsModel interface
    # ------------------------------------------------------------------

    @property
    def latent_dim(self) -> int:  # noqa: D102
        return self._z_dim

    def forward(
        self,
        x: torch.Tensor,
        time_points: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
    ) -> DynamicsOutput:
        """Training forward pass.

        Parameters
        ----------
        x : Tensor
            ``(batch, T, obs_dim)``  observation sequence.
        time_points, mask : optional
            Currently unused placeholders.

        Returns
        -------
        DynamicsOutput
        """
        batch, T, _ = x.shape

        # --- Step 1: VAE encoding ------------------------------------------
        a_means = []
        a_log_vars = []
        a_samples = []
        x_recons = []
        vae_kl = torch.tensor(0.0, device=x.device)

        for t in range(T):
            h = self.encoder(x[:, t, :])
            a_mean = self.enc_mean(h)
            a_log_var = self.enc_log_var(h)
            a_t = self.sample_latent(a_mean, a_log_var)

            x_recon = self.decoder(a_t)

            # KL for VAE bottleneck
            vae_kl = vae_kl + self.kl_divergence_standard_normal(a_mean, a_log_var)

            a_means.append(a_mean)
            a_log_vars.append(a_log_var)
            a_samples.append(a_t)
            x_recons.append(x_recon)

        x_recon_all = torch.stack(x_recons, dim=1)  # (batch, T, obs_dim)

        # --- Step 2: Kalman filtering over a_{1:T} -------------------------
        # TODO: Implement full Kalman filter forward pass with learned
        #       A, C, Q, R matrices.  For now, compute a simplified
        #       dynamics loss based on transition consistency.
        a_seq = torch.stack(a_samples, dim=1)  # (batch, T, a_dim)

        # Dynamics consistency loss: ||a_t - C @ A @ C^+ @ a_{t-1}||->
        # Simplified: penalise deviation from linear dynamics in a-space
        dynamics_loss = torch.tensor(0.0, device=x.device)
        if T > 1:
            # Project a -> z (pseudo-inverse of C) -> propagate -> project back
            C_pinv = torch.linalg.pinv(self.C)  # (z_dim, a_dim)
            for t in range(1, T):
                z_prev = a_seq[:, t - 1, :] @ C_pinv.T  # (batch, z_dim)
                z_pred = z_prev @ self.A.T               # (batch, z_dim)
                a_pred = z_pred @ self.C.T                # (batch, a_dim)
                dynamics_loss = dynamics_loss + F.mse_loss(a_seq[:, t, :], a_pred)
            dynamics_loss = dynamics_loss / (T - 1)

        # --- Aggregate losses ----------------------------------------------
        recon_loss = F.mse_loss(x_recon_all, x, reduction="mean")
        total_loss = recon_loss + vae_kl + dynamics_loss

        # Construct z_mean / z_log_var from the a-space (project to z-space)
        # This is an approximation; full Kalman smoothing would be more precise.
        z_mean = a_seq  # Placeholder: use a-space as the "latent" summary
        z_log_var = torch.stack(a_log_vars, dim=1)

        return DynamicsOutput(
            z_mean=z_mean,
            z_log_var=z_log_var,
            x_recon=x_recon_all,
            loss=total_loss,
            kl_divergence=vae_kl,
            reconstruction_loss=recon_loss,
            extras={"dynamics_loss": dynamics_loss},
        )

    def predict(
        self,
        x_history: torch.Tensor,
        horizon: int,
        time_history: Optional[torch.Tensor] = None,
        time_future: Optional[torch.Tensor] = None,
        n_samples: int = 1,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Forecast future observations using Kalman prediction.

        Parameters
        ----------
        x_history : Tensor
            ``(batch, T_hist, obs_dim)``.
        horizon : int
            Steps to forecast.
        n_samples : int
            Monte-Carlo samples.

        Returns
        -------
        tuple[Tensor, Tensor]
            ``(mean, std)`` each ``(batch, horizon, obs_dim)``.
        """
        # Encode last observation to get a_T
        h = self.encoder(x_history[:, -1, :])
        a_mean = self.enc_mean(h)

        # Project to z-space
        C_pinv = torch.linalg.pinv(self.C)
        z_t = a_mean @ C_pinv.T  # (batch, z_dim)

        all_preds = []
        for _ in range(n_samples):
            preds = []
            z = z_t
            for _ in range(horizon):
                # Kalman prediction: z_{t+1} = A z_t + noise
                z = z @ self.A.T
                Q = torch.exp(self.log_Q)
                if n_samples > 1:
                    z = z + torch.randn_like(z) * Q.sqrt()

                # Map to a-space then decode
                a = z @ self.C.T
                x_pred = self.decoder(a)
                preds.append(x_pred)

            all_preds.append(torch.stack(preds, dim=1))

        samples = torch.stack(all_preds, dim=0)
        mean = samples.mean(dim=0)
        std = samples.std(dim=0) if n_samples > 1 else torch.zeros_like(mean)
        return mean, std
