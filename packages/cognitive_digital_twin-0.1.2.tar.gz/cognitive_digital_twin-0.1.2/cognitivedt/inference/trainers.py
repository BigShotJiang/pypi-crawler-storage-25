"""Training utilities for CognitiveTwin deep learning models.

Provides a reusable :class:`Trainer` that encapsulates:
* A standard PyTorch training loop with gradient clipping.
* Validation-based early stopping.
* Learning rate scheduling.
* Checkpoint saving / loading.
* Logging of training metrics.

The trainer is **model-agnostic**  it works with any ``nn.Module`` whose
``forward`` method returns an object with a ``.loss`` attribute (i.e. any
of our :class:`DynamicsOutput` or :class:`GenerativeOutput`).
"""

from __future__ import annotations

import copy
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset, TensorDataset

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Training configuration
# ---------------------------------------------------------------------------

@dataclass
class TrainerConfig:
    """Configuration for the training loop.

    Parameters
    ----------
    learning_rate : float
        Initial learning rate (default 8e-4, optimal from hyperparameter sweep).
    weight_decay : float
        AdamW weight decay.
    batch_size : int
        Mini-batch size.
    max_epochs : int
        Maximum number of training epochs.
    patience : int
        Early stopping patience (epochs without validation improvement).
    gradient_clip_value : float
        Maximum gradient norm for clipping (0 = disabled).
    scheduler : str
        LR scheduler type: ``"cosine"`` or ``"plateau"``.
    checkpoint_dir : str | None
        Directory for saving model checkpoints; ``None`` disables saving.
    device : str
        PyTorch device string (``"auto"``, ``"cpu"``, ``"cuda"``).
    """

    learning_rate: float = 8e-4
    weight_decay: float = 1e-3
    batch_size: int = 32
    max_epochs: int = 150
    patience: int = 10
    gradient_clip_value: float = 1.0
    scheduler: str = "cosine"
    checkpoint_dir: Optional[str] = None
    device: str = "auto"


# ---------------------------------------------------------------------------
# Training history
# ---------------------------------------------------------------------------

@dataclass
class TrainingHistory:
    """Records metrics collected during training."""

    train_losses: List[float] = field(default_factory=list)
    val_losses: List[float] = field(default_factory=list)
    learning_rates: List[float] = field(default_factory=list)
    best_val_loss: float = float("inf")
    best_epoch: int = 0
    total_time_seconds: float = 0.0
    stopped_early: bool = False


# ---------------------------------------------------------------------------
# Trainer
# ---------------------------------------------------------------------------

class Trainer:
    """General-purpose PyTorch trainer for CognitiveTwin models.

    Parameters
    ----------
    model : nn.Module
        The model to train.  Its ``forward`` must return an object with a
        ``.loss`` attribute (scalar ``Tensor``).
    config : TrainerConfig
        Training hyper-parameters and settings.
    """

    def __init__(self, model: nn.Module, config: Optional[TrainerConfig] = None) -> None:
        self.config = config or TrainerConfig()
        self.device = self._resolve_device(self.config.device)
        self.model = model.to(self.device)
        self.history = TrainingHistory()

        # Optimiser
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
        )

        # LR scheduler
        if self.config.scheduler == "cosine":
            self.scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = (
                torch.optim.lr_scheduler.CosineAnnealingLR(
                    self.optimizer, T_max=self.config.max_epochs
                )
            )
        elif self.config.scheduler == "plateau":
            self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer, mode="min", factor=0.5, patience=5
            )
        else:
            self.scheduler = None

        # Best model state for early stopping
        self._best_state: Optional[Dict[str, Any]] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(
        self,
        train_data: Union[Dataset, Tuple[torch.Tensor, ...]],
        val_data: Optional[Union[Dataset, Tuple[torch.Tensor, ...]]] = None,
    ) -> TrainingHistory:
        """Run the training loop.

        Parameters
        ----------
        train_data : Dataset or tuple of Tensors
            Training dataset.  If a tuple, wrapped in ``TensorDataset``.
        val_data : Dataset or tuple of Tensors, optional
            Validation dataset for early stopping.

        Returns
        -------
        TrainingHistory
            Full training log.
        """
        train_loader = self._make_loader(train_data, shuffle=True)
        val_loader = self._make_loader(val_data, shuffle=False) if val_data else None

        start_time = time.time()
        epochs_without_improvement = 0

        for epoch in range(1, self.config.max_epochs + 1):
            train_loss = self._train_epoch(train_loader)
            self.history.train_losses.append(train_loss)
            self.history.learning_rates.append(self.optimizer.param_groups[0]["lr"])

            # Validation
            val_loss = self._validate_epoch(val_loader) if val_loader else train_loss
            self.history.val_losses.append(val_loss)

            # Early stopping check
            if val_loss < self.history.best_val_loss:
                self.history.best_val_loss = val_loss
                self.history.best_epoch = epoch
                self._best_state = copy.deepcopy(self.model.state_dict())
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1

            # LR scheduling
            if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                self.scheduler.step(val_loss)
            elif self.scheduler is not None:
                self.scheduler.step()

            # Logging
            logger.info(
                "Epoch %3d/%d  train_loss=%.4f  val_loss=%.4f  lr=%.2e%s",
                epoch,
                self.config.max_epochs,
                train_loss,
                val_loss,
                self.optimizer.param_groups[0]["lr"],
                "  *best*" if epochs_without_improvement == 0 else "",
            )

            if epochs_without_improvement >= self.config.patience:
                logger.info("Early stopping at epoch %d.", epoch)
                self.history.stopped_early = True
                break

        # Restore best model
        if self._best_state is not None:
            self.model.load_state_dict(self._best_state)

        self.history.total_time_seconds = time.time() - start_time

        # Save checkpoint
        if self.config.checkpoint_dir:
            self.save_checkpoint(Path(self.config.checkpoint_dir) / "best_model.pt")

        return self.history

    def save_checkpoint(self, path: Union[str, Path]) -> None:
        """Save model state and training history to disk."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(
            {
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "history": self.history,
            },
            path,
        )
        logger.info("Checkpoint saved to %s", path)

    def load_checkpoint(self, path: Union[str, Path]) -> None:
        """Load model state from a checkpoint."""
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        self.history = ckpt.get("history", TrainingHistory())
        logger.info("Checkpoint loaded from %s", path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _train_epoch(self, loader: DataLoader) -> float:
        """Run one training epoch; return average loss."""
        self.model.train()
        total_loss = 0.0
        n_batches = 0

        for batch in loader:
            batch = self._to_device(batch)
            self.optimizer.zero_grad()

            # Model forward  expects .loss attribute on output
            output = self.model(*batch) if isinstance(batch, (list, tuple)) else self.model(batch)
            loss = output.loss if hasattr(output, "loss") else output

            loss.backward()

            if self.config.gradient_clip_value > 0:
                nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.config.gradient_clip_value
                )

            self.optimizer.step()
            total_loss += loss.item()
            n_batches += 1

        return total_loss / max(n_batches, 1)

    @torch.no_grad()
    def _validate_epoch(self, loader: DataLoader) -> float:
        """Run one validation epoch; return average loss."""
        self.model.eval()
        total_loss = 0.0
        n_batches = 0

        for batch in loader:
            batch = self._to_device(batch)
            output = self.model(*batch) if isinstance(batch, (list, tuple)) else self.model(batch)
            loss = output.loss if hasattr(output, "loss") else output
            total_loss += loss.item()
            n_batches += 1

        return total_loss / max(n_batches, 1)

    def _make_loader(
        self,
        data: Union[Dataset, Tuple[torch.Tensor, ...], None],
        shuffle: bool,
    ) -> Optional[DataLoader]:
        if data is None:
            return None
        if isinstance(data, tuple):
            data = TensorDataset(*data)
        return DataLoader(data, batch_size=self.config.batch_size, shuffle=shuffle)

    def _to_device(
        self, batch: Any
    ) -> Any:
        if isinstance(batch, torch.Tensor):
            return batch.to(self.device)
        if isinstance(batch, (list, tuple)):
            return type(batch)(t.to(self.device) if isinstance(t, torch.Tensor) else t for t in batch)
        return batch

    @staticmethod
    def _resolve_device(device: str) -> torch.device:
        if device == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return torch.device(device)
