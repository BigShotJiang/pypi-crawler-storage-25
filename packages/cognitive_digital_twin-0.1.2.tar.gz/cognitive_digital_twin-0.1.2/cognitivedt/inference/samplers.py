"""Sampling and probabilistic inference utilities.

Provides functions for:
* **Monte-Carlo prediction:** draw multiple trajectory samples from a
  dynamics model and aggregate statistics.
* **Variational Inference (VI):** wrappers around Pyro / NumPyro for
  approximate Bayesian inference over model parameters.
* **MCMC:** Hamiltonian Monte Carlo / NUTS sampling for exact (in the
  limit) posterior inference.

These routines are used both during training (for Bayesian models) and
at test time (for uncertainty quantification).

.. note::
   The Pyro-based functions (``run_variational_inference``,
   ``run_mcmc_sampling``) require the optional ``pyro-ppl`` dependency::

       pip install cognitivedt[bayesian]
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Monte-Carlo prediction sampling
# ---------------------------------------------------------------------------

@torch.no_grad()
def monte_carlo_predict(
    model: nn.Module,
    x_history: torch.Tensor,
    horizon: int,
    n_samples: int = 50,
    time_history: Optional[torch.Tensor] = None,
    time_future: Optional[torch.Tensor] = None,
) -> Dict[str, torch.Tensor]:
    """Draw multiple forecast samples from a dynamics model.

    This is the primary method for obtaining predictive uncertainty
    estimates at test time.  The model's ``predict`` method is called
    ``n_samples`` times; results are aggregated into summary statistics.

    Parameters
    ----------
    model : nn.Module
        A trained dynamics model with a ``predict`` method.
    x_history : Tensor
        Observed input sequence, ``(batch, T_hist, obs_dim)``.
    horizon : int
        Number of future time-steps to forecast.
    n_samples : int
        Number of Monte-Carlo trajectory samples.
    time_history, time_future : Tensor | None
        Optional time-stamp tensors.

    Returns
    -------
    dict[str, Tensor]
        ``"mean"``  point prediction (batch, horizon, obs_dim).
        ``"std"``  standard deviation (batch, horizon, obs_dim).
        ``"samples"``  raw samples (n_samples, batch, horizon, obs_dim).
        ``"lower_95"``  2.5th percentile (batch, horizon, obs_dim).
        ``"upper_95"``  97.5th percentile (batch, horizon, obs_dim).
    """
    model.eval()
    all_samples: list[torch.Tensor] = []

    for _ in range(n_samples):
        mean, _ = model.predict(
            x_history,
            horizon=horizon,
            time_history=time_history,
            time_future=time_future,
            n_samples=1,
        )
        all_samples.append(mean)

    samples = torch.stack(all_samples, dim=0)  # (n_samples, batch, horizon, obs)

    return {
        "mean": samples.mean(dim=0),
        "std": samples.std(dim=0),
        "samples": samples,
        "lower_95": torch.quantile(samples, 0.025, dim=0),
        "upper_95": torch.quantile(samples, 0.975, dim=0),
    }


# ---------------------------------------------------------------------------
# MC Dropout prediction
# ---------------------------------------------------------------------------

def mc_dropout_predict(
    model: nn.Module,
    x_history: torch.Tensor,
    horizon: int,
    n_samples: int = 50,
    time_history: Optional[torch.Tensor] = None,
    time_future: Optional[torch.Tensor] = None,
) -> Dict[str, torch.Tensor]:
    """Estimate uncertainty via Monte-Carlo Dropout.

    Enables dropout at test time and draws ``n_samples`` stochastic forward
    passes.  The variance across passes approximates epistemic (model)
    uncertainty.

    Parameters
    ----------
    model : nn.Module
        A model containing ``nn.Dropout`` layers.
    x_history : Tensor
        ``(batch, T_hist, obs_dim)``.
    horizon : int
        Prediction horizon.
    n_samples : int
        Number of stochastic passes.
    time_history, time_future : Tensor | None
        Optional time-stamp tensors.

    Returns
    -------
    dict[str, Tensor]
        Same structure as :func:`monte_carlo_predict`.
    """
    # Enable dropout during inference
    _set_dropout_training(model, training=True)

    results = monte_carlo_predict(
        model, x_history, horizon, n_samples, time_history, time_future
    )

    # Restore normal eval mode
    _set_dropout_training(model, training=False)
    model.eval()

    return results


def _set_dropout_training(model: nn.Module, training: bool) -> None:
    """Toggle training mode on Dropout layers only."""
    for m in model.modules():
        if isinstance(m, (nn.Dropout, nn.Dropout2d, nn.Dropout3d)):
            m.training = training


# ---------------------------------------------------------------------------
# Deep Ensemble prediction
# ---------------------------------------------------------------------------

@torch.no_grad()
def ensemble_predict(
    models: List[nn.Module],
    x_history: torch.Tensor,
    horizon: int,
    time_history: Optional[torch.Tensor] = None,
    time_future: Optional[torch.Tensor] = None,
) -> Dict[str, torch.Tensor]:
    """Estimate uncertainty from a deep ensemble.

    Each ensemble member provides an independent prediction.  The
    disagreement (variance) across members captures epistemic uncertainty.

    Parameters
    ----------
    models : list[nn.Module]
        Ensemble of independently trained models.
    x_history : Tensor
        ``(batch, T_hist, obs_dim)``.
    horizon : int
        Prediction horizon.
    time_history, time_future : Tensor | None
        Optional time-stamp tensors.

    Returns
    -------
    dict[str, Tensor]
        ``"mean"``, ``"std"``, ``"samples"``  same structure as
        :func:`monte_carlo_predict`.
    """
    preds: list[torch.Tensor] = []

    for model in models:
        model.eval()
        mean, _ = model.predict(
            x_history,
            horizon=horizon,
            time_history=time_history,
            time_future=time_future,
            n_samples=1,
        )
        preds.append(mean)

    samples = torch.stack(preds, dim=0)

    return {
        "mean": samples.mean(dim=0),
        "std": samples.std(dim=0),
        "samples": samples,
        "lower_95": torch.quantile(samples, 0.025, dim=0),
        "upper_95": torch.quantile(samples, 0.975, dim=0),
    }


# ---------------------------------------------------------------------------
# Variational Inference (Pyro)
# ---------------------------------------------------------------------------

def run_variational_inference(
    pyro_model: Callable[..., Any],
    pyro_guide: Callable[..., Any],
    data: Dict[str, torch.Tensor],
    *,
    n_steps: int = 5000,
    learning_rate: float = 1e-3,
    num_particles: int = 4,
) -> Dict[str, Any]:
    """Run stochastic variational inference using Pyro.

    Parameters
    ----------
    pyro_model : callable
        A Pyro model function defining the generative model with
        ``pyro.sample`` statements.
    pyro_guide : callable
        A Pyro guide function defining the variational family.
    data : dict[str, Tensor]
        Observed data to condition on.
    n_steps : int
        Number of SVI optimisation steps.
    learning_rate : float
        Adam learning rate for the ELBO optimiser.
    num_particles : int
        Number of particles for the ELBO estimator.

    Returns
    -------
    dict[str, Any]
        ``"losses"``  list of ELBO losses per step.
        ``"guide"``  the trained guide.
        ``"params"``  Pyro parameter store snapshot.

    Raises
    ------
    ImportError
        If ``pyro-ppl`` is not installed.
    """
    try:
        import pyro
        from pyro.infer import SVI, Trace_ELBO
        from pyro.optim import Adam as PyroAdam
    except ImportError as exc:
        raise ImportError(
            "Pyro-PPL is required for variational inference. "
            "Install it with: pip install cognitivedt[bayesian]"
        ) from exc

    pyro.clear_param_store()

    optimizer = PyroAdam({"lr": learning_rate})
    svi = SVI(pyro_model, pyro_guide, optimizer, loss=Trace_ELBO(num_particles=num_particles))

    losses: list[float] = []
    for step in range(n_steps):
        loss = svi.step(**data)
        losses.append(loss)
        if step % 500 == 0:
            logger.info("SVI step %d/%d  ELBO loss=%.4f", step, n_steps, loss)

    return {
        "losses": losses,
        "guide": pyro_guide,
        "params": dict(pyro.get_param_store()),
    }


# ---------------------------------------------------------------------------
# MCMC Sampling (Pyro / NUTS)
# ---------------------------------------------------------------------------

def run_mcmc_sampling(
    pyro_model: Callable[..., Any],
    data: Dict[str, torch.Tensor],
    *,
    num_samples: int = 1000,
    warmup_steps: int = 200,
    num_chains: int = 1,
) -> Dict[str, Any]:
    """Run MCMC sampling (NUTS) using Pyro.

    Parameters
    ----------
    pyro_model : callable
        A Pyro model function.
    data : dict[str, Tensor]
        Observed data to condition on.
    num_samples : int
        Number of posterior samples to draw (per chain).
    warmup_steps : int
        Number of burn-in / warm-up steps.
    num_chains : int
        Number of independent chains.

    Returns
    -------
    dict[str, Any]
        ``"samples"``  dict mapping parameter names to posterior sample
        tensors of shape ``(num_samples,) + param_shape``.
        ``"diagnostics"``  dict with R-hat and effective sample size.

    Raises
    ------
    ImportError
        If ``pyro-ppl`` is not installed.
    """
    try:
        import pyro
        from pyro.infer import MCMC, NUTS
    except ImportError as exc:
        raise ImportError(
            "Pyro-PPL is required for MCMC sampling. "
            "Install it with: pip install cognitivedt[bayesian]"
        ) from exc

    kernel = NUTS(pyro_model)
    mcmc = MCMC(
        kernel,
        num_samples=num_samples,
        warmup_steps=warmup_steps,
        num_chains=num_chains,
    )
    mcmc.run(**data)

    samples = mcmc.get_samples()
    diagnostics = mcmc.diagnostics()

    logger.info(
        "MCMC complete: %d samples -> %d chains.  Parameters: %s",
        num_samples,
        num_chains,
        list(samples.keys()),
    )

    return {
        "samples": samples,
        "diagnostics": diagnostics,
    }
