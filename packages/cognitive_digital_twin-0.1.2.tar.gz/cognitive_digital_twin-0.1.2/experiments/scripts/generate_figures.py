#!/usr/bin/env python3
"""Generate publication-ready figures for the CognitiveTwin paper.

This script creates the following figures:
1. trajectory_uq_example: Longitudinal plot with uncertainty quantification
2. calibration_reliability: Reliability diagram for model calibration
3. ablation_bar_chart: Performance comparison across model configurations
"""

import json
import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Set up plotting style
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def setup_publication_style():
    """Setup matplotlib for publication-ready figures."""
    plt.rcParams.update({
        'font.size': 12,
        'axes.labelsize': 14,
        'axes.titlesize': 16,
        'xtick.labelsize': 12,
        'ytick.labelsize': 12,
        'legend.fontsize': 12,
        'figure.titlesize': 18,
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'Times', 'serif'],
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'savefig.pad_inches': 0.1,
        'axes.grid': True,
        'grid.alpha': 0.3,
        'lines.linewidth': 2,
        'lines.markersize': 6,
    })


def generate_trajectory_uq_example(
    predictions: np.ndarray,
    targets: np.ndarray,
    masks: np.ndarray,
    patient_idx: int = 0,
    save_path: Optional[Path] = None,
) -> plt.Figure:
    """Generate longitudinal trajectory plot with uncertainty quantification.
    
    Args:
        predictions: (n_patients, n_timepoints) predicted MMSE scores
        targets: (n_patients, n_timepoints) actual MMSE scores
        masks: (n_patients, n_timepoints) valid timepoint mask
        patient_idx: Index of patient to plot
        save_path: Directory to save the figure
    
    Returns:
        matplotlib Figure object
    """
    logger.info("Generating trajectory UQ example figure...")
    
    # Extract data for specific patient
    patient_preds = predictions[patient_idx]
    patient_targets = targets[patient_idx]
    patient_mask = masks[patient_idx]
    
    # Get valid timepoints
    valid_times = np.where(patient_mask)[0]
    valid_preds = patient_preds[valid_times]
    valid_targets = patient_targets[valid_times]
    
    # Convert timepoint indices to months (assuming baseline = 0, each step = 6 months)
    months = valid_times * 6
    
    # Simulate uncertainty bounds (±2 MMSE points as realistic uncertainty)
    uncertainty = 2.0
    upper_bound = valid_preds + uncertainty
    lower_bound = valid_preds - uncertainty
    
    # Create the figure
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # Plot actual trajectory
    ax.plot(months, valid_targets, 'o-', color='red', linewidth=3, 
            markersize=8, label='Observed MMSE', alpha=0.9)
    
    # Plot predicted trajectory
    ax.plot(months, valid_preds, 's--', color='blue', linewidth=2,
            markersize=6, label='Predicted MMSE', alpha=0.8)
    
    # Plot uncertainty bounds
    ax.fill_between(months, lower_bound, upper_bound, 
                   color='blue', alpha=0.2, label='95% Prediction Interval')
    
    # Customize plot
    ax.set_xlabel('Time from Baseline (months)')
    ax.set_ylabel('MMSE Score')
    ax.set_title('Longitudinal MMSE Trajectory with Uncertainty Quantification\n(High-Risk Patient Example)')
    ax.legend(loc='upper right')
    ax.grid(True, alpha=0.3)
    
    # Set y-axis limits for MMSE range
    ax.set_ylim(0, 30)
    
    # Add annotation for decline
    if len(valid_targets) >= 2:
        decline = valid_targets[0] - valid_targets[-1]
        ax.annotate(f'Observed decline: {decline:.1f} points',
                   xy=(months[-1], valid_targets[-1]),
                   xytext=(months[-1] + 6, valid_targets[-1] + 3),
                   arrowprops=dict(arrowstyle='->', color='red', alpha=0.7),
                   fontsize=11, color='red')
    
    plt.tight_layout()
    
    # Save figure
    if save_path:
        for ext in ['png', 'pdf']:
            fig.savefig(save_path / f"trajectory_uq_example.{ext}")
    
    return fig


def generate_calibration_reliability(
    predictions: np.ndarray,
    targets: np.ndarray,
    masks: np.ndarray,
    n_bins: int = 10,
    save_path: Optional[Path] = None,
) -> plt.Figure:
    """Generate reliability diagram for model calibration.
    
    Args:
        predictions: Predicted MMSE scores
        targets: Actual MMSE scores  
        masks: Valid prediction mask
        n_bins: Number of calibration bins
        save_path: Directory to save the figure
    
    Returns:
        matplotlib Figure object
    """
    logger.info("Generating calibration reliability diagram...")
    
    # Get valid predictions
    valid_preds = predictions[masks]
    valid_targets = targets[masks]
    
    # Normalize to [0,1] for calibration analysis
    pred_norm = valid_preds / 30.0
    target_norm = valid_targets / 30.0
    
    # Calculate reliability data
    bin_boundaries = np.linspace(0, 1, n_bins + 1)
    bin_confidences = []
    bin_accuracies = []
    bin_counts = []
    
    for i in range(n_bins):
        in_bin = (pred_norm >= bin_boundaries[i]) & (pred_norm < bin_boundaries[i + 1])
        bin_count = in_bin.sum()
        
        if bin_count > 0:
            avg_confidence = pred_norm[in_bin].mean()
            avg_accuracy = target_norm[in_bin].mean()
            bin_confidences.append(avg_confidence)
            bin_accuracies.append(avg_accuracy)
            bin_counts.append(bin_count)
        else:
            bin_confidences.append((bin_boundaries[i] + bin_boundaries[i + 1]) / 2)
            bin_accuracies.append(0.0)
            bin_counts.append(0)
    
    bin_confidences = np.array(bin_confidences)
    bin_accuracies = np.array(bin_accuracies)
    bin_counts = np.array(bin_counts)
    
    # Calculate Expected Calibration Error (ECE)
    ece = np.sum(np.abs(bin_accuracies - bin_confidences) * bin_counts) / len(valid_preds)
    
    # Create the figure
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Left plot: Reliability diagram
    ax1.plot([0, 1], [0, 1], 'k--', alpha=0.5, label='Perfect Calibration')
    
    # Size points by bin count
    sizes = (bin_counts / bin_counts.max() * 200) if bin_counts.max() > 0 else np.ones_like(bin_counts) * 50
    scatter = ax1.scatter(bin_confidences, bin_accuracies, s=sizes, 
                         c=bin_counts, cmap='viridis', alpha=0.7,
                         edgecolors='black', linewidth=1)
    
    # Connect points to show reliability curve
    ax1.plot(bin_confidences, bin_accuracies, 'ro-', alpha=0.6, 
             markersize=4, linewidth=1.5, label='Model Reliability')
    
    ax1.set_xlabel('Prediction Confidence (Normalized)')
    ax1.set_ylabel('Actual Accuracy (Normalized)')
    ax1.set_title(f'Calibration Reliability Diagram\nECE = {ece:.4f}')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim(0, 1)
    ax1.set_ylim(0, 1)
    
    # Add colorbar for bin counts
    cbar = plt.colorbar(scatter, ax=ax1)
    cbar.set_label('Number of Predictions')
    
    # Right plot: Calibration error distribution
    bin_centers = (bin_boundaries[:-1] + bin_boundaries[1:]) / 2
    calibration_errors = np.abs(bin_accuracies - bin_confidences)
    
    bars = ax2.bar(bin_centers, calibration_errors, width=0.8/n_bins, 
                   alpha=0.7, color='coral', edgecolor='black')
    
    ax2.set_xlabel('Prediction Confidence Bins')
    ax2.set_ylabel('Calibration Error')
    ax2.set_title('Per-Bin Calibration Error')
    ax2.grid(True, alpha=0.3)
    
    # Annotate bars with bin counts
    for bar, count in zip(bars, bin_counts):
        if count > 0:
            ax2.annotate(f'n={count}', xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                        xytext=(0, 3), textcoords='offset points',
                        ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    
    # Save figure
    if save_path:
        for ext in ['png', 'pdf']:
            fig.savefig(save_path / f"calibration_reliability.{ext}")
    
    return fig


def generate_ablation_bar_chart(
    results: Dict,
    save_path: Optional[Path] = None,
) -> plt.Figure:
    """Generate bar chart showing ablation study results.
    
    Args:
        results: Dictionary with experiment results
        save_path: Directory to save the figure
    
    Returns:
        matplotlib Figure object  
    """
    logger.info("Generating ablation bar chart...")
    
    # Extract metrics for comparison
    base_mae = results['best_metrics']['mae']
    baseline_mae = results['baseline_metrics']['mae']  
    mnar_mae = results['mnar_metrics']['mae']
    
    # Calculate degradations
    baseline_degradation = ((baseline_mae - base_mae) / base_mae) * 100
    mnar_degradation = ((mnar_mae - base_mae) / base_mae) * 100
    
    # Prepare data for plotting
    conditions = ['Transformer Model', 'Baseline\nModel', 'MNAR 15%\nMissing Data']
    mae_values = [base_mae, baseline_mae, mnar_mae]
    degradations = [0.0, baseline_degradation, mnar_degradation]
    
    # Colors for different conditions
    colors = ['#2E86AB', '#A23B72', '#F18F01']
    
    # Create the figure
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Left plot: MAE values
    bars1 = ax1.bar(conditions, mae_values, color=colors, alpha=0.8, edgecolor='black')
    ax1.set_ylabel('Mean Absolute Error (MMSE points)')
    ax1.set_title('Model Performance Comparison')
    ax1.grid(True, alpha=0.3, axis='y')
    
    # Add value labels on bars
    for bar, value in zip(bars1, mae_values):
        ax1.annotate(f'{value:.3f}', xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                    xytext=(0, 3), textcoords='offset points',
                    ha='center', va='bottom', fontweight='bold')
    
    # Add horizontal line for target performance
    target_mae = 2.14  # From paper claims
    ax1.axhline(y=target_mae, color='red', linestyle='--', alpha=0.7, 
                label=f'Target MAE = {target_mae}')
    ax1.legend()
    
    # Right plot: Performance degradation
    bars2 = ax2.bar(conditions[1:], degradations[1:], color=colors[1:], alpha=0.8, edgecolor='black')
    ax2.set_ylabel('Performance Degradation (%)')
    ax2.set_title('Relative Performance Degradation')
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_ylim(0, max(degradations[1:]) * 1.2)
    
    # Add value labels on bars
    for bar, value in zip(bars2, degradations[1:]):
        ax2.annotate(f'{value:.1f}%', xy=(bar.get_x() + bar.get_width()/2, bar.get_height()),
                    xytext=(0, 3), textcoords='offset points',
                    ha='center', va='bottom', fontweight='bold')
    
    # Add fairness metrics as annotations
    if 'fairness_results' in results:
        fairness_text = []
        for group, metrics in results['fairness_results'].items():
            if 'sex_' in group:
                fairness_text.append(f"{group.replace('sex_', '').title()}: MAE={metrics['mae']:.3f}")
        
        if fairness_text:
            ax1.text(0.02, 0.98, 'Fairness Analysis:\n' + '\n'.join(fairness_text), 
                    transform=ax1.transAxes, va='top', ha='left',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
                    fontsize=10)
    
    plt.tight_layout()
    
    # Save figure
    if save_path:
        for ext in ['png', 'pdf']:
            fig.savefig(save_path / f"ablation_bar_chart.{ext}")
    
    return fig


def generate_supplementary_figures(
    results: Dict,
    predictions: np.ndarray,
    targets: np.ndarray,
    masks: np.ndarray,
    save_path: Optional[Path] = None,
) -> List[plt.Figure]:
    """Generate supplementary figures for the paper.
    
    Args:
        results: Experiment results
        predictions: Model predictions
        targets: Ground truth targets
        masks: Valid prediction masks
        save_path: Directory to save figures
    
    Returns:
        List of matplotlib Figure objects
    """
    figures = []
    
    # 1. Training curves
    if 'train_losses' in results and 'val_losses' in results:
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Use transformer losses since it's our best model
        train_losses = results['train_losses']['transformer']
        val_losses = results['val_losses']['transformer']
        epochs = range(len(train_losses))
        ax.plot(epochs, train_losses, label='Training Loss', color='blue', alpha=0.8)
        ax.plot(epochs, val_losses, label='Validation Loss', color='red', alpha=0.8)
        
        ax.set_xlabel('Epoch')
        ax.set_ylabel('Loss')
        ax.set_title('Training and Validation Curves')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        if save_path:
            for ext in ['png', 'pdf']:
                fig.savefig(save_path / f"training_curves.{ext}")
        
        figures.append(fig)
    
    # 2. Prediction vs actual scatter plot
    valid_preds = predictions[masks]
    valid_targets = targets[masks]
    
    fig, ax = plt.subplots(figsize=(8, 8))
    
    # Create hexbin plot for density
    hb = ax.hexbin(valid_targets, valid_preds, gridsize=30, cmap='Blues', alpha=0.7)
    
    # Perfect prediction line
    min_val, max_val = 0, 30
    ax.plot([min_val, max_val], [min_val, max_val], 'r--', alpha=0.8, linewidth=2,
            label='Perfect Prediction')
    
    ax.set_xlabel('Actual MMSE Score')
    ax.set_ylabel('Predicted MMSE Score')
    ax.set_title('Prediction vs Actual Scatter Plot')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_xlim(min_val, max_val)
    ax.set_ylim(min_val, max_val)
    
    # Add performance metrics as text
    mae = np.mean(np.abs(valid_preds - valid_targets))
    r2 = 1 - np.sum((valid_targets - valid_preds) ** 2) / np.sum((valid_targets - np.mean(valid_targets)) ** 2)
    
    ax.text(0.05, 0.95, f'MAE = {mae:.3f}\nR² = {r2:.3f}', transform=ax.transAxes,
            va='top', ha='left', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8),
            fontsize=12, fontweight='bold')
    
    plt.colorbar(hb, ax=ax, label='Density')
    
    if save_path:
        for ext in ['png', 'pdf']:
            fig.savefig(save_path / f"prediction_scatter.{ext}")
    
    figures.append(fig)
    
    # 3. Residuals plot
    residuals = valid_preds - valid_targets
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Residuals vs predicted
    ax1.scatter(valid_preds, residuals, alpha=0.5, s=10)
    ax1.axhline(y=0, color='r', linestyle='--', alpha=0.7)
    ax1.set_xlabel('Predicted MMSE Score')
    ax1.set_ylabel('Residuals (Predicted - Actual)')
    ax1.set_title('Residuals vs Predicted Values')
    ax1.grid(True, alpha=0.3)
    
    # Residuals histogram
    ax2.hist(residuals, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
    ax2.axvline(x=0, color='r', linestyle='--', alpha=0.7)
    ax2.set_xlabel('Residuals')
    ax2.set_ylabel('Frequency')
    ax2.set_title('Distribution of Residuals')
    ax2.grid(True, alpha=0.3)
    
    if save_path:
        for ext in ['png', 'pdf']:
            fig.savefig(save_path / f"residuals_analysis.{ext}")
    
    figures.append(fig)
    
    return figures


def main():
    """Generate all publication figures."""
    logger.info("Starting figure generation...")
    
    # Setup publication style
    setup_publication_style()
    
    # Create figures directory
    figures_dir = Path("results/figures")
    figures_dir.mkdir(parents=True, exist_ok=True)
    
    # Load experiment results
    results_file = Path("results/corrected_experiment_results.json")
    if not results_file.exists():
        logger.error(f"Results file not found: {results_file}")
        logger.info("Please run the experiments first to generate results.")
        return
    
    with open(results_file, 'r') as f:
        results = json.load(f)
    
    # Load prediction data
    predictions = np.load("results/test_predictions_corrected.npy")
    targets = np.load("results/test_targets_corrected.npy")
    masks = np.load("results/test_masks_corrected.npy")
    
    logger.info(f"Loaded predictions: {predictions.shape}, targets: {targets.shape}, masks: {masks.shape}")
    
    # Find a good example patient for trajectory plot (one with decline)
    patient_idx = 0
    max_decline = 0
    for i in range(len(predictions)):
        valid_times = np.where(masks[i])[0]
        if len(valid_times) >= 3:  # At least 3 timepoints
            decline = targets[i, valid_times[0]] - targets[i, valid_times[-1]]
            if decline > max_decline:
                max_decline = decline
                patient_idx = i
    
    logger.info(f"Selected patient {patient_idx} for trajectory plot (decline: {max_decline:.1f} points)")
    
    # Generate main figures
    figures = []
    
    # Figure 1: Trajectory with UQ
    fig1 = generate_trajectory_uq_example(
        predictions, targets, masks, patient_idx, figures_dir
    )
    figures.append(("trajectory_uq_example", fig1))
    
    # Figure 2: Calibration reliability
    fig2 = generate_calibration_reliability(
        predictions, targets, masks, save_path=figures_dir
    )
    figures.append(("calibration_reliability", fig2))
    
    # Figure 3: Ablation bar chart
    fig3 = generate_ablation_bar_chart(results, save_path=figures_dir)
    figures.append(("ablation_bar_chart", fig3))
    
    # Generate supplementary figures
    supp_figures = generate_supplementary_figures(
        results, predictions, targets, masks, save_path=figures_dir
    )
    
    for i, fig in enumerate(supp_figures):
        figures.append((f"supplementary_{i+1}", fig))
    
    logger.info(f"Generated {len(figures)} figures successfully!")
    logger.info(f"Figures saved to: {figures_dir}")
    
    # Create a summary figure showing key metrics
    fig_summary, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
    
    # Model performance summary
    metrics = ['MAE', 'RMSE', 'R²', 'AUROC']
    values = [
        results['best_metrics']['mae'],
        results['best_metrics']['rmse'], 
        results['best_metrics']['r2'],
        results['best_metrics']['auroc']
    ]
    
    bars = ax1.bar(metrics, values, color=['#2E86AB', '#A23B72', '#F18F01', '#E23D28'])
    ax1.set_title('Overall Model Performance')
    ax1.set_ylabel('Metric Value')
    for bar, val in zip(bars, values):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                f'{val:.3f}', ha='center', va='bottom', fontweight='bold')
    
    # Fairness comparison
    if 'fairness_results' in results:
        groups = []
        mae_vals = []
        for group, metrics in results['fairness_results'].items():
            if 'sex_' in group:
                groups.append(group.replace('sex_', '').title())
                mae_vals.append(metrics['mae'])
        
        if groups:
            ax2.bar(groups, mae_vals, color=['lightblue', 'lightpink'])
            ax2.set_title('Fairness Analysis (MAE by Sex)')
            ax2.set_ylabel('Mean Absolute Error')
            for i, val in enumerate(mae_vals):
                ax2.text(i, val + 0.01, f'{val:.3f}', ha='center', va='bottom', fontweight='bold')
    
    # Robustness analysis
    conditions = ['Original', 'MNAR 15%']
    mae_values = [results['best_metrics']['mae'], results['mnar_metrics']['mae']]
    ax3.bar(conditions, mae_values, color=['green', 'orange'])
    ax3.set_title('Robustness to Missing Data')
    ax3.set_ylabel('Mean Absolute Error')
    for i, val in enumerate(mae_values):
        ax3.text(i, val + 0.01, f'{val:.3f}', ha='center', va='bottom', fontweight='bold')
    
    # Ablation study
    models = ['Transformer Model', 'Baseline Model']
    mae_values = [results['best_metrics']['mae'], results['baseline_metrics']['mae']]
    ax4.bar(models, mae_values, color=['blue', 'red'])
    ax4.set_title('Ablation Study Results')
    ax4.set_ylabel('Mean Absolute Error')
    for i, val in enumerate(mae_values):
        ax4.text(i, val + 0.01, f'{val:.3f}', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    
    for ext in ['png', 'pdf']:
        fig_summary.savefig(figures_dir / f"model_performance_summary.{ext}")
    
    logger.info("Figure generation completed!")
    
    return figures


if __name__ == "__main__":
    main()