#!/usr/bin/env python3
"""Run comprehensive experiments for the CognitiveTwin paper.

This script executes the full experimental pipeline:
1. Initialize TransformerFusion and DeepMarkovModel components
2. Train the model on TADPOLE training split (150 epochs)
3. Evaluate on test split for predictive metrics (MAE, AUROC)
4. Calculate fairness metrics (Calibration by Sex/Age)
5. Simulate 15% MNAR scenario
6. Run ablation test removing Cross-Modal Attention
"""

import json
import logging
import os
import pickle
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import mean_absolute_error, roc_auc_score
from sklearn.model_selection import train_test_split

# Add package to path
from cognitivedt.data.base import PatientData, VisitData
from cognitivedt.dynamics.dmm import DeepMarkovModel
from cognitivedt.evaluation.metrics import (
    expected_calibration_error,
    mean_absolute_error as mae_metric,
    r_squared,
    root_mean_squared_error,
)
from cognitivedt.inference.trainers import Trainer, TrainerConfig
from cognitivedt.io.loader import TADPOLELoader
from cognitivedt.representation.transformer import TransformerFusionModel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Set device
device = torch.device("cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu")
logger.info(f"Using device: {device}")

# Configuration - FULL TRAINING
EPOCHS = 150  # Full training as per paper
BATCH_SIZE = 32
LEARNING_RATE = 8e-4
HIDDEN_DIM = 256
LATENT_DIM = 64
N_HEADS = 8
N_LAYERS = 4
DROPOUT = 0.15
PATIENCE = 10


def prepare_multimodal_data(patients: List[PatientData]) -> Tuple[Dict[str, torch.Tensor], torch.Tensor, torch.Tensor]:
    """Convert patient data to multimodal tensors for the proper model architecture.
    
    Returns:
        modality_features: Dict with separate tensors for each modality
        targets: (n_patients, n_timepoints) - MMSE scores  
        masks: (n_patients, n_timepoints) - valid timepoint mask
    """
    max_timepoints = max(p.n_visits for p in patients)
    n_patients = len(patients)
    
    # Initialize separate tensors for each modality
    cognitive_tensor = torch.zeros(n_patients, max_timepoints, 9)
    biomarker_tensor = torch.zeros(n_patients, max_timepoints, 15)  # CSF + blood markers
    imaging_tensor = torch.zeros(n_patients, max_timepoints, 7)  # MRI volumes
    genetic_tensor = torch.zeros(n_patients, 1)  # APOE4 (time-invariant)
    
    targets = torch.zeros(n_patients, max_timepoints)
    masks = torch.zeros(n_patients, max_timepoints, dtype=torch.bool)
    
    for i, patient in enumerate(patients):
        # Genetic features (time-invariant)
        if patient.genetics:
            genetic_tensor[i, 0] = patient.genetics.apoe4_count / 2.0  # Normalize to [0,1]
        
        for j, visit in enumerate(patient.visits[:max_timepoints]):
            # Cognitive features
            if visit.cognitive:
                cognitive_vals = torch.tensor([
                    visit.cognitive.mmse or 0.0,
                    visit.cognitive.adas11 or 0.0,
                    visit.cognitive.adas13 or 0.0,
                    visit.cognitive.cdrsb or 0.0,
                    visit.cognitive.ravlt_immediate or 0.0,
                    visit.cognitive.ravlt_learning or 0.0,
                    visit.cognitive.ravlt_forgetting or 0.0,
                    visit.cognitive.ravlt_perc_forgetting or 0.0,
                    visit.cognitive.faq or 0.0,
                ])
                cognitive_tensor[i, j] = cognitive_vals
                
                # Set target (MMSE)
                if visit.cognitive.mmse is not None:
                    targets[i, j] = visit.cognitive.mmse
                    masks[i, j] = True
            
            # Biomarker features (CSF + blood)
            biomarker_vals = torch.zeros(15)
            if visit.csf:
                biomarker_vals[0] = visit.csf.abeta or 0.0
                biomarker_vals[1] = visit.csf.tau or 0.0
                biomarker_vals[2] = visit.csf.ptau or 0.0
            if visit.pet:
                biomarker_vals[3] = visit.pet.fdg or 0.0
                biomarker_vals[4] = visit.pet.av45 or 0.0
            # Add demographic features as biomarkers
            biomarker_vals[5] = visit.demographics.age
            biomarker_vals[6] = 1.0 if visit.demographics.sex.value == "Male" else 0.0
            biomarker_vals[7] = visit.demographics.education_years
            biomarker_tensor[i, j] = biomarker_vals
            
            # Imaging features (MRI)
            if visit.mri:
                imaging_vals = torch.tensor([
                    visit.mri.ventricles or 0.0,
                    visit.mri.hippocampus or 0.0,
                    visit.mri.whole_brain or 0.0,
                    visit.mri.entorhinal or 0.0,
                    visit.mri.fusiform or 0.0,
                    visit.mri.mid_temp or 0.0,
                    visit.mri.icv or 0.0,
                ])
                # Normalize by ICV if available
                if visit.mri.icv and visit.mri.icv > 0:
                    imaging_vals[:6] = imaging_vals[:6] / visit.mri.icv * 1000
                imaging_tensor[i, j] = imaging_vals
    
    # Normalize each modality separately (z-score normalization)
    for tensor in [cognitive_tensor, biomarker_tensor, imaging_tensor]:
        valid_data = tensor[masks.unsqueeze(-1).expand_as(tensor)].reshape(-1, tensor.shape[-1])
        if valid_data.numel() > 0:
            mean = valid_data.mean(dim=0)
            std = valid_data.std(dim=0) + 1e-6
            tensor[:] = (tensor - mean) / std
    
    # Normalize genetic features
    genetic_mean = genetic_tensor.mean()
    genetic_std = genetic_tensor.std() + 1e-6
    genetic_tensor = (genetic_tensor - genetic_mean) / genetic_std
    
    modality_features = {
        "cognitive": cognitive_tensor.to(device),
        "biomarkers": biomarker_tensor.to(device),
        "imaging": imaging_tensor.to(device),
        "genetics": genetic_tensor.to(device),
    }
    
    return modality_features, targets.to(device), masks.to(device)


class FullCognitiveTwinModel(nn.Module):
    """Full CognitiveTwin model with proper TransformerFusion + DMM architecture."""
    
    def __init__(self):
        super().__init__()
        
        # Modality-specific dimensions
        self.modality_dims = {
            "cognitive": 9,
            "biomarkers": 15,
            "imaging": 7,
            "genetics": 1,
        }
        
        # TransformerFusion for multi-modal integration
        self.fusion_model = TransformerFusionModel(
            modality_dims=self.modality_dims,
            d_model=HIDDEN_DIM,
            n_heads=N_HEADS,
            n_layers=N_LAYERS,
            d_ff=HIDDEN_DIM * 2,
            dropout=DROPOUT,
        )
        
        # DMM for temporal dynamics
        self.dmm = DeepMarkovModel(
            obs_dim=HIDDEN_DIM,
            z_dim=LATENT_DIM,
            hidden_dim=HIDDEN_DIM // 2,
            rnn_dim=HIDDEN_DIM // 2,
            n_rnn_layers=3,
            dropout=DROPOUT,
        )
        
        # Output projection to MMSE score
        self.output_projection = nn.Sequential(
            nn.Linear(HIDDEN_DIM, HIDDEN_DIM // 2),
            nn.ReLU(),
            nn.Dropout(DROPOUT),
            nn.Linear(HIDDEN_DIM // 2, 1),
        )
        
        # Learning rate warmup steps
        self.warmup_steps = 1000
        self.current_step = 0
    
    def forward(self, modality_features, masks):
        """Forward pass with proper multi-modal fusion.
        
        Args:
            modality_features: Dict of modality tensors
            masks: (batch, time) boolean mask
        
        Returns:
            predictions: (batch, time, 1) 
            loss: scalar combining DMM loss and prediction loss
        """
        batch_size = masks.shape[0]
        max_time = masks.shape[1]
        
        # Process each timepoint through fusion model
        fused_sequence = []
        for t in range(max_time):
            # Extract features at timepoint t for each modality
            timepoint_features = {}
            for name, tensor in modality_features.items():
                if name == "genetics":
                    # Genetics is time-invariant
                    timepoint_features[name] = tensor
                else:
                    timepoint_features[name] = tensor[:, t, :]
            
            # Apply transformer fusion
            fused_t = self.fusion_model.encode(timepoint_features)
            fused_sequence.append(fused_t)
        
        # Stack to create temporal sequence
        fused_sequence = torch.stack(fused_sequence, dim=1)  # (batch, time, hidden_dim)
        
        # Apply DMM for temporal modeling
        dmm_output = self.dmm(fused_sequence, mask=masks)
        
        # Project to MMSE predictions
        predictions = self.output_projection(dmm_output.x_recon)  # (batch, time, 1)
        
        # Combined loss
        total_loss = dmm_output.loss
        
        return predictions, total_loss


def train_full_model(
    model: nn.Module,
    train_data: Tuple,
    val_data: Tuple,
    epochs: int = EPOCHS,
) -> Tuple[List[float], List[float]]:
    """Train the full model with proper optimization."""
    
    train_features, train_targets, train_masks = train_data
    val_features, val_targets, val_masks = val_data
    
    # Optimizer with weight decay
    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-3)
    
    # Learning rate scheduler (cosine annealing)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    
    train_losses = []
    val_losses = []
    best_val_loss = float("inf")
    patience_counter = 0
    best_model_state = None
    
    for epoch in range(epochs):
        # Training
        model.train()
        epoch_loss = 0.0
        n_batches = 0
        
        # Create batches
        indices = torch.randperm(len(train_masks))
        
        for i in range(0, len(indices), BATCH_SIZE):
            batch_idx = indices[i : i + BATCH_SIZE]
            
            # Get batch data
            batch_features = {
                name: tensor[batch_idx] for name, tensor in train_features.items()
            }
            batch_targets = train_targets[batch_idx]
            batch_masks = train_masks[batch_idx]
            
            optimizer.zero_grad()
            
            # Forward pass
            predictions, dmm_loss = model(batch_features, batch_masks)
            predictions = predictions.squeeze(-1)
            
            # MSE loss for MMSE prediction
            valid_preds = predictions[batch_masks]
            valid_targets = batch_targets[batch_masks]
            mse_loss = nn.functional.mse_loss(valid_preds, valid_targets)
            
            # Combined loss with weighting
            total_loss = dmm_loss * 0.1 + mse_loss  # Weight DMM loss less
            
            total_loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            
            optimizer.step()
            
            epoch_loss += total_loss.item()
            n_batches += 1
        
        avg_train_loss = epoch_loss / max(n_batches, 1)
        train_losses.append(avg_train_loss)
        
        # Validation
        model.eval()
        with torch.no_grad():
            val_predictions, val_dmm_loss = model(val_features, val_masks)
            val_predictions = val_predictions.squeeze(-1)
            
            valid_val_preds = val_predictions[val_masks]
            valid_val_targets = val_targets[val_masks]
            val_mse = nn.functional.mse_loss(valid_val_preds, valid_val_targets)
            
            total_val_loss = (val_dmm_loss * 0.1 + val_mse).item()
        
        val_losses.append(total_val_loss)
        
        # Learning rate scheduling
        scheduler.step()
        
        # Early stopping
        if total_val_loss < best_val_loss:
            best_val_loss = total_val_loss
            patience_counter = 0
            best_model_state = model.state_dict()
        else:
            patience_counter += 1
        
        # Logging
        if epoch % 10 == 0 or epoch == epochs - 1:
            logger.info(
                f"Epoch {epoch}/{epochs} - Train Loss: {avg_train_loss:.4f}, "
                f"Val Loss: {total_val_loss:.4f}, LR: {scheduler.get_last_lr()[0]:.6f}"
            )
        
        if patience_counter >= PATIENCE:
            logger.info(f"Early stopping at epoch {epoch}")
            break
    
    # Restore best model
    if best_model_state is not None:
        model.load_state_dict(best_model_state)
    
    return train_losses, val_losses


def evaluate_full_model(
    model: nn.Module,
    test_data: Tuple,
    test_patients: List[PatientData],
) -> Dict[str, float]:
    """Evaluate the full model and calculate all metrics."""
    
    test_features, test_targets, test_masks = test_data
    
    model.eval()
    with torch.no_grad():
        predictions, _ = model(test_features, test_masks)
        predictions = predictions.squeeze(-1)
    
    # Convert to numpy
    preds_np = predictions.cpu().numpy()
    targets_np = test_targets.cpu().numpy()
    masks_np = test_masks.cpu().numpy()
    
    # Get valid predictions
    valid_preds = preds_np[masks_np]
    valid_targets = targets_np[masks_np]
    
    # Clip predictions to valid MMSE range
    valid_preds = np.clip(valid_preds, 0, 30)
    
    # Calculate regression metrics
    mae = mean_absolute_error(valid_targets, valid_preds)
    rmse = np.sqrt(np.mean((valid_targets - valid_preds) ** 2))
    r2 = r_squared(valid_targets, valid_preds)
    
    # Calculate progression (binary: decline > 3 points)
    progression_true = []
    progression_scores = []
    
    for i in range(len(test_masks)):
        valid_idx = np.where(masks_np[i])[0]
        if len(valid_idx) >= 2:
            # Check actual decline
            actual_decline = targets_np[i, valid_idx[0]] - targets_np[i, valid_idx[-1]]
            pred_decline = preds_np[i, valid_idx[0]] - preds_np[i, valid_idx[-1]]
            
            progression_true.append(1 if actual_decline > 3 else 0)
            # Use predicted decline as a continuous score
            progression_scores.append(pred_decline / 30.0 + 0.5)  # Normalize to [0,1]
    
    if len(progression_true) > 1:
        try:
            auroc = roc_auc_score(progression_true, progression_scores)
        except:
            auroc = 0.5
    else:
        auroc = 0.5
    
    # Calculate calibration error
    ece = calculate_calibration_error(valid_targets, valid_preds)
    
    return {
        "mae": mae,
        "rmse": rmse, 
        "r2": r2,
        "auroc": auroc,
        "ece": ece,
    }


def calculate_calibration_error(y_true, y_pred, n_bins=10):
    """Calculate Expected Calibration Error for regression."""
    # Normalize to [0,1] for calibration
    y_true_norm = y_true / 30.0
    y_pred_norm = y_pred / 30.0
    
    ece = 0.0
    for i in range(n_bins):
        bin_min = i / n_bins
        bin_max = (i + 1) / n_bins
        
        in_bin = (y_pred_norm >= bin_min) & (y_pred_norm < bin_max)
        if in_bin.sum() > 0:
            bin_accuracy = y_true_norm[in_bin].mean()
            bin_confidence = y_pred_norm[in_bin].mean()
            bin_weight = in_bin.sum() / len(y_pred_norm)
            ece += np.abs(bin_accuracy - bin_confidence) * bin_weight
    
    return ece


def main():
    """Run full experimental pipeline with proper model."""
    logger.info("Starting CognitiveTwin experiments with FULL MODEL (150 epochs)...")
    
    # Create results directory
    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)
    
    # Step 1: Load data
    logger.info("Loading TADPOLE dataset...")
    loader = TADPOLELoader(data_dir=".", min_visits=2)
    train_patients, val_patients, test_patients = loader.load_and_split("TADPOLE_D1_D2.csv")
    
    logger.info(f"Data split: Train={len(train_patients)}, Val={len(val_patients)}, Test={len(test_patients)}")
    
    # Step 2: Prepare multi-modal data
    logger.info("Preparing multi-modal data tensors...")
    train_data = prepare_multimodal_data(train_patients)
    val_data = prepare_multimodal_data(val_patients)
    test_data = prepare_multimodal_data(test_patients)
    
    # Step 3: Initialize full model
    logger.info("Initializing FULL CognitiveTwin model...")
    model = FullCognitiveTwinModel()
    model = model.to(device)
    
    total_params = sum(p.numel() for p in model.parameters())
    logger.info(f"Model parameters: {total_params:,}")
    
    # Step 4: Train model for full 150 epochs
    logger.info(f"Training model for {EPOCHS} epochs...")
    train_losses, val_losses = train_full_model(model, train_data, val_data, epochs=EPOCHS)
    
    # Save model
    torch.save(model.state_dict(), results_dir / "full_model_150epochs.pt")
    
    # Step 5: Evaluate on test set
    logger.info("Evaluating on test set...")
    test_metrics = evaluate_full_model(model, test_data, test_patients)
    
    logger.info("Test Set Performance:")
    logger.info(f"  MAE: {test_metrics['mae']:.4f}")
    logger.info(f"  RMSE: {test_metrics['rmse']:.4f}")
    logger.info(f"  R²: {test_metrics['r2']:.4f}")
    logger.info(f"  AUROC: {test_metrics['auroc']:.4f}")
    logger.info(f"  ECE: {test_metrics['ece']:.4f}")
    
    # Step 6: Fairness analysis
    logger.info("Calculating fairness metrics...")
    fairness_results = {}
    
    # Group by sex
    male_idx = [i for i, p in enumerate(test_patients) 
                if p.visits[0].demographics.sex.value == "Male"]
    female_idx = [i for i, p in enumerate(test_patients)
                  if p.visits[0].demographics.sex.value == "Female"]
    
    for group_name, indices in [("male", male_idx), ("female", female_idx)]:
        if indices:
            group_features = {
                name: tensor[indices] for name, tensor in test_data[0].items()
            }
            group_data = (group_features, test_data[1][indices], test_data[2][indices])
            group_patients = [test_patients[i] for i in indices]
            
            group_metrics = evaluate_full_model(model, group_data, group_patients)
            fairness_results[f"sex_{group_name}"] = group_metrics
            logger.info(f"  Sex={group_name}: MAE={group_metrics['mae']:.4f}, AUROC={group_metrics['auroc']:.4f}")
    
    # Group by age
    age_groups = {"<65": [], "65-75": [], ">75": []}
    for i, p in enumerate(test_patients):
        age = p.visits[0].demographics.age
        if age < 65:
            age_groups["<65"].append(i)
        elif age <= 75:
            age_groups["65-75"].append(i)
        else:
            age_groups[">75"].append(i)
    
    for group_name, indices in age_groups.items():
        if indices:
            group_features = {
                name: tensor[indices] for name, tensor in test_data[0].items()
            }
            group_data = (group_features, test_data[1][indices], test_data[2][indices])
            group_patients = [test_patients[i] for i in indices]
            
            group_metrics = evaluate_full_model(model, group_data, group_patients)
            fairness_results[f"age_{group_name}"] = group_metrics
            logger.info(f"  Age={group_name}: MAE={group_metrics['mae']:.4f}, ECE={group_metrics['ece']:.4f}")
    
    # Step 7: MNAR simulation (15% missing MRI for low MMSE)
    logger.info("Simulating 15% MNAR scenario...")
    mnar_features = {name: tensor.clone() for name, tensor in test_data[0].items()}
    
    # Drop imaging features for patients with low MMSE
    low_mmse_mask = test_data[1] < 24
    for i in range(len(test_data[2])):
        for t in range(test_data[2].shape[1]):
            if test_data[2][i, t] and low_mmse_mask[i, t]:
                if torch.rand(1).item() < 0.15:
                    mnar_features["imaging"][i, t, :] = 0
    
    mnar_data = (mnar_features, test_data[1], test_data[2])
    mnar_metrics = evaluate_full_model(model, mnar_data, test_patients)
    
    logger.info(f"  MNAR MAE: {mnar_metrics['mae']:.4f} (degradation: {(mnar_metrics['mae'] - test_metrics['mae']) / test_metrics['mae'] * 100:.1f}%)")
    
    # Step 8: Ablation - remove attention mechanism
    logger.info("Running ablation study (no cross-modal attention)...")
    
    # Create ablated model (simple concatenation instead of attention)
    class AblatedModel(nn.Module):
        def __init__(self):
            super().__init__()
            total_dim = sum([9, 15, 7, 1])  # All modality dimensions
            self.projection = nn.Sequential(
                nn.Linear(total_dim, HIDDEN_DIM),
                nn.ReLU(),
                nn.Dropout(DROPOUT),
            )
            self.dmm = DeepMarkovModel(
                obs_dim=HIDDEN_DIM,
                z_dim=LATENT_DIM,
                hidden_dim=HIDDEN_DIM // 2,
                rnn_dim=HIDDEN_DIM // 2,
                n_rnn_layers=3,
                dropout=DROPOUT,
            )
            self.output_projection = nn.Sequential(
                nn.Linear(HIDDEN_DIM, HIDDEN_DIM // 2),
                nn.ReLU(),
                nn.Dropout(DROPOUT),
                nn.Linear(HIDDEN_DIM // 2, 1),
            )
        
        def forward(self, modality_features, masks):
            batch_size = masks.shape[0]
            max_time = masks.shape[1]
            
            # Simple concatenation of all modalities
            concat_sequence = []
            for t in range(max_time):
                features_t = []
                features_t.append(modality_features["cognitive"][:, t, :])
                features_t.append(modality_features["biomarkers"][:, t, :])
                features_t.append(modality_features["imaging"][:, t, :])
                features_t.append(modality_features["genetics"])
                
                concat_t = torch.cat(features_t, dim=-1)
                projected_t = self.projection(concat_t)
                concat_sequence.append(projected_t)
            
            concat_sequence = torch.stack(concat_sequence, dim=1)
            dmm_output = self.dmm(concat_sequence, mask=masks)
            predictions = self.output_projection(dmm_output.x_recon)
            
            return predictions, dmm_output.loss
    
    ablated_model = AblatedModel().to(device)
    logger.info("Training ablated model (quick 20 epochs)...")
    ablated_losses, _ = train_full_model(ablated_model, train_data, val_data, epochs=20)
    ablated_metrics = evaluate_full_model(ablated_model, test_data, test_patients)
    
    logger.info(f"  Ablated MAE: {ablated_metrics['mae']:.4f} (degradation: {(ablated_metrics['mae'] - test_metrics['mae']) / test_metrics['mae'] * 100:.1f}%)")
    
    # Save all results
    results = {
        "test_metrics": test_metrics,
        "fairness_results": fairness_results,
        "mnar_metrics": mnar_metrics,
        "ablated_metrics": ablated_metrics,
        "train_losses": train_losses[-50:],  # Last 50 epochs
        "val_losses": val_losses[-50:],
    }
    
    with open(results_dir / "full_experiment_results.json", "w") as f:
        json.dump(results, f, indent=2, default=float)
    
    # Save predictions for plotting
    model.eval()
    with torch.no_grad():
        test_predictions, _ = model(test_data[0], test_data[2])
        test_predictions = test_predictions.squeeze(-1).cpu().numpy()
    
    np.save(results_dir / "test_predictions_full.npy", test_predictions)
    np.save(results_dir / "test_targets_full.npy", test_data[1].cpu().numpy())
    np.save(results_dir / "test_masks_full.npy", test_data[2].cpu().numpy())
    
    logger.info("Full experiments completed successfully!")
    logger.info(f"Final Test MAE: {test_metrics['mae']:.4f} (Target: 2.14)")
    
    return results


if __name__ == "__main__":
    results = main()