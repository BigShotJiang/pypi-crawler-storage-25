"""Tests for replay-from-log: cache-match, miss policy, content sensitivity."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import pytest

from gyre import (
    CallRecord,
    Memory,
    ReplayCacheMissError,
    Tool,
    agent_context,
    load_log,
)
from gyre.session import _call_key, _ReplayCache, hash_memory_content
from gyre.subprocess import CLIResponse


def _ok_response(
    cost: float = 0.05,
    result: str = "ok",
    structured_output: dict[str, Any] | None = None,
) -> CLIResponse:
    if structured_output is None:
        structured_output = {"answer": True, "value": 42, "items": ["a", "b"]}
    return CLIResponse(
        success=True,
        result=result,
        structured_output=structured_output,
        session_id="sess-orig",
        duration_ms=12,
        cost_usd=cost,
        raw={"subtype": "success"},
    )


@pytest.fixture
def stub(monkeypatch: pytest.MonkeyPatch) -> list[dict[str, Any]]:
    """Stub the live subprocess. Captured calls are appended to the list."""
    captured: list[dict[str, Any]] = []

    async def stub_impl(prompt: str, **kwargs: Any) -> CLIResponse:
        captured.append({"prompt": prompt, **kwargs})
        return _ok_response()

    monkeypatch.setattr("gyre.subprocess._run_claude_impl", stub_impl)
    return captured


@pytest.fixture
def panic_stub(monkeypatch: pytest.MonkeyPatch) -> None:
    """Make any live subprocess call fail loudly. Replay must avoid it."""

    async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
        raise AssertionError("Live subprocess invoked during replay")

    monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)


class TestCallKey:
    """Direct tests of the cache key formula."""

    def _base(self, **overrides: Any) -> dict[str, Any]:
        defaults: dict[str, Any] = {
            "kind": "check",
            "prompt": "ok?",
            "schema": None,
            "tool_names": None,
            "memory_labels": (),
            "memory_hashes": (),
            "system_prompt": None,
            "append_prompt": None,
            "model": None,
            "permission_mode": "default",
            "working_dir": None,
        }
        defaults.update(overrides)
        return defaults

    def test_identical_inputs_collide(self) -> None:
        a = _call_key(**self._base())
        b = _call_key(**self._base())
        assert a == b

    def test_prompt_change_diverges(self) -> None:
        a = _call_key(**self._base(prompt="ok?"))
        b = _call_key(**self._base(prompt="ok??"))
        assert a != b

    def test_tool_order_normalized(self) -> None:
        a = _call_key(**self._base(tool_names=("Read", "Edit")))
        b = _call_key(**self._base(tool_names=("Edit", "Read")))
        assert a == b

    def test_memory_order_preserved(self) -> None:
        """Memory order matters because it determines prompt-append order."""
        a = _call_key(
            **self._base(
                memory_labels=("voice", "style"),
                memory_hashes=("h1", "h2"),
            )
        )
        b = _call_key(
            **self._base(
                memory_labels=("style", "voice"),
                memory_hashes=("h2", "h1"),
            )
        )
        assert a != b

    def test_memory_hash_change_diverges(self) -> None:
        a = _call_key(**self._base(memory_labels=("v",), memory_hashes=("h1",)))
        b = _call_key(**self._base(memory_labels=("v",), memory_hashes=("h2",)))
        assert a != b

    def test_model_change_diverges(self) -> None:
        a = _call_key(**self._base(model="sonnet"))
        b = _call_key(**self._base(model="opus"))
        assert a != b

    def test_system_prompt_change_diverges(self) -> None:
        a = _call_key(**self._base(system_prompt="A"))
        b = _call_key(**self._base(system_prompt="B"))
        assert a != b

    def test_permission_mode_change_diverges(self) -> None:
        a = _call_key(**self._base(permission_mode="default"))
        b = _call_key(**self._base(permission_mode="plan"))
        assert a != b


class TestReplayCache:
    """Direct tests of _ReplayCache lookup behavior."""

    def _rec(self, prompt: str = "p", model: str | None = None) -> CallRecord:
        return CallRecord.make(
            kind="check",
            prompt=prompt,
            type_name="bool",
            schema=None,
            tool_names=None,
            memory_labels=(),
            session_id="t",
            cost_usd=0.0,
            duration_ms=1,
            result="ok",
            model=model,
        )

    def test_match_returns_record(self) -> None:
        rec = self._rec()
        cache = _ReplayCache([rec])
        assert cache.try_match(rec.replay_key()) is rec

    def test_miss_returns_none(self) -> None:
        cache = _ReplayCache([self._rec(prompt="a")])
        miss = self._rec(prompt="b")
        assert cache.try_match(miss.replay_key()) is None

    def test_fifo_on_duplicate_keys(self) -> None:
        """Two records with identical inputs pop in insertion order."""
        r1 = self._rec(prompt="same")
        r2 = self._rec(prompt="same")
        cache = _ReplayCache([r1, r2])
        first = cache.try_match(r1.replay_key())
        second = cache.try_match(r2.replay_key())
        third = cache.try_match(r1.replay_key())
        assert first is r1
        assert second is r2
        assert third is None

    def test_total_loaded_unchanged_after_pops(self) -> None:
        cache = _ReplayCache([self._rec(), self._rec()])
        cache.try_match(self._rec().replay_key())
        assert cache.total_loaded == 2
        assert len(cache) == 1


class TestRoundTrip:
    """End-to-end: live run → dump → load → replay → match."""

    @pytest.mark.asyncio
    async def test_replay_returns_cached_value_without_subprocess(
        self,
        stub: list[Any],
        panic_stub: None,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        # Live phase: capture a log.
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            assert await agent.check("ok?") is True
            agent.dump_log(log_path)

        # Replay phase: panic_stub fixture makes the live impl raise if hit.
        async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
            raise AssertionError("Live subprocess invoked during replay")

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)

        async with agent_context(replay_from=log_path) as replay_agent:
            answer = await replay_agent.check("ok?")
            assert answer is True

    @pytest.mark.asyncio
    async def test_load_log_round_trips(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context(model="sonnet") as agent:
            await agent.check("ok?")
            agent.dump_log(log_path)

        records = load_log(log_path)
        assert len(records) == 1
        rec = records[0]
        assert rec.kind == "check"
        assert "ok?" in rec.prompt  # `check` augments with a JSON hint
        assert rec.model == "sonnet"
        assert rec.structured_output == {"answer": True}

    @pytest.mark.asyncio
    async def test_replay_preserves_cost_so_budget_tracks(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(cost=0.30, structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            await agent.check("ok?")
            await agent.check("ok?")
            agent.dump_log(log_path)

        async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
            raise AssertionError("live call during replay")

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)

        async with agent_context(replay_from=log_path) as replay_agent:
            await replay_agent.check("ok?")
            await replay_agent.check("ok?")
            assert replay_agent.cost_usd == pytest.approx(0.60)

    @pytest.mark.asyncio
    async def test_replay_get_returns_same_value(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"value": 7})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            assert await agent.get(int, "how many?") == 7
            agent.dump_log(log_path)

        async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
            raise AssertionError("live call during replay")

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)

        async with agent_context(replay_from=log_path) as replay_agent:
            assert await replay_agent.get(int, "how many?") == 7


class TestMissPolicy:
    """Cache-miss behavior: raise vs passthrough."""

    @pytest.mark.asyncio
    async def test_miss_raises_by_default(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            await agent.check("seen?")
            agent.dump_log(log_path)

        async with agent_context(replay_from=log_path) as replay_agent:
            with pytest.raises(ReplayCacheMissError) as exc:
                await replay_agent.check("unseen?")
            assert exc.value.kind == "check"
            assert "unseen?" in exc.value.prompt

    @pytest.mark.asyncio
    async def test_miss_passthrough_falls_through(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        live_calls: list[str] = []

        async def live_stub(prompt: str, **_kwargs: Any) -> CLIResponse:
            live_calls.append(prompt)
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            await agent.check("seen?")
            agent.dump_log(log_path)

        live_calls.clear()
        async with agent_context(
            replay_from=log_path, replay_on_miss="passthrough"
        ) as replay_agent:
            # First call hits cache (no live call expected).
            await replay_agent.check("seen?")
            # Second call misses → live call.
            await replay_agent.check("brand new?")
        # The "brand new?" prompt is in the live-call list; "seen?" is not.
        assert any("brand new?" in p for p in live_calls)
        assert not any("seen?" in p for p in live_calls)


class TestContentSensitivity:
    """Replay must distinguish calls by full input signature."""

    @pytest.mark.asyncio
    async def test_memory_content_change_causes_miss(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        memory_path = tmp_path / "voice.md"
        memory_path.write_text("voice v1", encoding="utf-8")
        voice = Memory(label="voice", path=memory_path)

        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context(memories=[voice]) as agent:
            await agent.check("on brand?")
            agent.dump_log(log_path)

        # Same prompt, but the memory file changed — this is a different call.
        memory_path.write_text("voice v2", encoding="utf-8")

        async with agent_context(
            memories=[voice], replay_from=log_path
        ) as replay_agent:
            with pytest.raises(ReplayCacheMissError):
                await replay_agent.check("on brand?")

    @pytest.mark.asyncio
    async def test_model_change_causes_miss(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context(model="sonnet") as agent:
            await agent.check("ok?")
            agent.dump_log(log_path)

        async with agent_context(
            model="opus", replay_from=log_path
        ) as replay_agent:
            with pytest.raises(ReplayCacheMissError):
                await replay_agent.check("ok?")

    @pytest.mark.asyncio
    async def test_tool_order_doesnt_matter(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Tools sorted in the cache key — order is not part of the signature."""

        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context(tools=[Tool.Read, Tool.Edit]) as agent:
            await agent.check("ok?")
            agent.dump_log(log_path)

        async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
            raise AssertionError("live call during replay")

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)

        async with agent_context(
            tools=[Tool.Edit, Tool.Read], replay_from=log_path
        ) as replay_agent:
            await replay_agent.check("ok?")  # must hit cache despite reorder


class TestParallelDuplicates:
    """Replay handles `gather()` of identical-input calls correctly."""

    @pytest.mark.asyncio
    async def test_parallel_duplicates_all_replay(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        # Live phase: 4 identical calls.
        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            await asyncio.gather(*(agent.check("same?") for _ in range(4)))
            agent.dump_log(log_path)

        async def boom(_prompt: str, **_kwargs: Any) -> CLIResponse:
            raise AssertionError("live call during replay")

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", boom)

        async with agent_context(replay_from=log_path) as replay_agent:
            results = await asyncio.gather(
                *(replay_agent.check("same?") for _ in range(4))
            )
            assert all(r is True for r in results)
            assert replay_agent.iterations == 4

    @pytest.mark.asyncio
    async def test_one_extra_duplicate_misses(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """N+1 identical calls against a log of N: the last one misses."""

        async def live_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(structured_output={"answer": True})

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", live_stub)

        log_path = tmp_path / "run.json"
        async with agent_context() as agent:
            await agent.check("same?")
            await agent.check("same?")
            agent.dump_log(log_path)

        async with agent_context(replay_from=log_path) as replay_agent:
            await replay_agent.check("same?")  # match #1
            await replay_agent.check("same?")  # match #2
            with pytest.raises(ReplayCacheMissError):
                await replay_agent.check("same?")  # bucket exhausted


class TestLoadLog:
    """Direct tests of load_log and CallRecord.from_dict."""

    def test_load_log_handles_missing_optional_fields(
        self, tmp_path: Path
    ) -> None:
        """A pre-replay log (no memory_hashes / model / etc.) loads with defaults."""
        old_format = [
            {
                "kind": "check",
                "prompt": "ok?",
                "type_name": "bool",
                "schema": None,
                "tools": None,
                "memory_labels": [],
                "session_id": "old",
                "cost_usd": 0.05,
                "duration_ms": 10,
                "timestamp": "2026-01-01T00:00:00+00:00",
                "result_summary": "yes",
            }
        ]
        log_path = tmp_path / "old.json"
        log_path.write_text(json.dumps(old_format), encoding="utf-8")

        records = load_log(log_path)
        assert len(records) == 1
        r = records[0]
        assert r.model is None
        assert r.permission_mode == "default"
        assert r.memory_hashes == ()
        assert r.structured_output is None
        assert r.result == "yes"  # falls back to result_summary

    def test_replay_key_stable_across_dump_load(self, tmp_path: Path) -> None:
        """A record's replay_key survives a dump→load round trip."""
        rec = CallRecord.make(
            kind="check",
            prompt="ok?",
            type_name="bool",
            schema=None,
            tool_names=("Edit", "Read"),
            memory_labels=("voice",),
            session_id="t",
            cost_usd=0.0,
            duration_ms=1,
            result="ok",
            model="sonnet",
            memory_hashes=(hash_memory_content("voice content"),),
        )
        log_path = tmp_path / "log.json"
        log_path.write_text(
            json.dumps([rec.to_jsonable()], indent=2), encoding="utf-8"
        )
        loaded = load_log(log_path)[0]
        assert loaded.replay_key() == rec.replay_key()
