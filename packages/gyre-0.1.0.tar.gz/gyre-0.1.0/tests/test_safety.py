"""Tests for Phase 3 safety: do() tool-scope enforcement and dry_run."""

from __future__ import annotations

from typing import Any

import pytest

from gyre import (
    Agent,
    AgentConfig,
    MissingToolScopeError,
    PermissionMode,
    Tool,
    agent_context,
    do,
)
from gyre.subprocess import CLIResponse


def _ok_response() -> CLIResponse:
    # `answer: True` lets `check()` parse cleanly; other commands ignore it.
    return CLIResponse(
        success=True,
        result="ok",
        structured_output={"answer": True, "value": "ok", "items": []},
        session_id="t",
        duration_ms=1,
        cost_usd=0.0,
        raw={"subtype": "success"},
    )


@pytest.fixture
def stub_run(monkeypatch: pytest.MonkeyPatch) -> list[dict[str, Any]]:
    """Replace `_run_claude_impl` and capture each call's kwargs."""
    captured: list[dict[str, Any]] = []

    async def stub(prompt: str, **kwargs: Any) -> CLIResponse:
        captured.append({"prompt": prompt, **kwargs})
        return _ok_response()

    monkeypatch.setattr("gyre.subprocess._run_claude_impl", stub)
    return captured


class TestDoToolScope:
    """Top-level and Agent.do() must have a visible tool list."""

    @pytest.mark.asyncio
    async def test_bare_do_raises(self) -> None:
        with pytest.raises(MissingToolScopeError):
            await do("delete everything")

    @pytest.mark.asyncio
    async def test_do_with_tools_kwarg_passes(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        await do("edit X", tools=[Tool.Read, Tool.Edit])
        assert stub_run[-1]["tools"] == (Tool.Read, Tool.Edit)

    @pytest.mark.asyncio
    async def test_do_with_config_tools_passes(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        cfg = AgentConfig(tools=(Tool.Read,))
        await do("inspect X", config=cfg)
        assert stub_run[-1]["tools"] == (Tool.Read,)

    @pytest.mark.asyncio
    async def test_tools_kwarg_overrides_config(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        cfg = AgentConfig(tools=(Tool.Read,))
        await do("write X", tools=[Tool.Write], config=cfg)
        assert stub_run[-1]["tools"] == (Tool.Write,)

    @pytest.mark.asyncio
    async def test_agent_do_outside_scope_raises(self) -> None:
        agent = Agent()  # no tools configured
        with pytest.raises(MissingToolScopeError):
            await agent.do("touch X")

    @pytest.mark.asyncio
    async def test_agent_do_inside_scope_passes(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        async with agent_context(tools=[Tool.Read, Tool.Edit]) as agent:
            await agent.do("edit X")
        assert stub_run[-1]["tools"] == (Tool.Read, Tool.Edit)

    @pytest.mark.asyncio
    async def test_agent_do_after_with_tools_passes(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        agent = Agent().with_tools(Tool.Bash)
        await agent.do("ls")
        assert stub_run[-1]["tools"] == (Tool.Bash,)


class TestDryRun:
    """agent_context(dry_run=True) forces PLAN and rejects mutating tools."""

    @pytest.mark.asyncio
    async def test_dry_run_forces_plan_mode(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        async with agent_context(
            tools=[Tool.Read],
            permission_mode=PermissionMode.BYPASS,
            dry_run=True,
        ) as agent:
            await agent.check("ok?")
        assert stub_run[-1]["permission_mode"] == PermissionMode.PLAN.value

    @pytest.mark.asyncio
    async def test_dry_run_rejects_mutating_tools(self) -> None:
        with pytest.raises(ValueError, match="mutating tools"):
            async with agent_context(
                tools=[Tool.Read, Tool.Edit],
                dry_run=True,
            ) as _:
                pass

    @pytest.mark.asyncio
    async def test_dry_run_lists_all_offending_tools(self) -> None:
        with pytest.raises(ValueError) as exc:
            async with agent_context(
                tools=[Tool.Edit, Tool.Bash, Tool.Read],
                dry_run=True,
            ) as _:
                pass
        msg = str(exc.value)
        assert "Edit" in msg
        assert "Bash" in msg
        assert "Read" not in msg  # read-only tool stays allowed

    @pytest.mark.asyncio
    async def test_dry_run_passes_through_string_tools(
        self, stub_run: list[dict[str, Any]]
    ) -> None:
        # Custom/MCP tools are unclassifiable; they pass through.
        async with agent_context(
            tools=[Tool.Read, "mcp__custom__shellish"],
            dry_run=True,
        ) as agent:
            await agent.check("ok?")
        assert stub_run[-1]["tools"] == (Tool.Read, "mcp__custom__shellish")
