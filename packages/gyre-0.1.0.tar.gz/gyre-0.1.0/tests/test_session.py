"""Tests for session controls (budget, iteration limit, parallelism)."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from gyre import (
    BudgetExceededError,
    IterationLimitError,
    agent_context,
)
from gyre.session import CallRecord, _active_session, _Session
from gyre.subprocess import CLIResponse


def _rec(cost: float = 0.0) -> CallRecord:
    """Build a synthetic CallRecord for direct _Session tests."""
    return CallRecord.make(
        kind="check",
        prompt="q",
        type_name="bool",
        schema=None,
        tool_names=None,
        memory_labels=(),
        session_id="t",
        cost_usd=cost,
        duration_ms=1,
        result="ok",
    )


def _make_response(cost_usd: float = 0.10) -> CLIResponse:
    """Build a synthetic CLI response for tests that bypass the subprocess."""
    return CLIResponse(
        success=True,
        result="ok",
        structured_output={"answer": True},
        session_id="test",
        duration_ms=10,
        cost_usd=cost_usd,
        raw={"total_cost_usd": cost_usd, "subtype": "success"},
    )


@pytest.fixture
def fake_run(monkeypatch: pytest.MonkeyPatch) -> list[float]:
    """Replace `_run_claude_impl` with a stub that returns canned costs.

    The fixture returns a mutable list the test can append per-call costs
    to (popped FIFO); if the list is empty the stub falls back to $0.10.
    """
    costs: list[float] = []

    async def stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
        cost = costs.pop(0) if costs else 0.10
        return _make_response(cost_usd=cost)

    monkeypatch.setattr("gyre.subprocess._run_claude_impl", stub)
    return costs


class TestSessionUnit:
    """Direct tests of the _Session bookkeeping logic."""

    def test_record_increments_counters(self) -> None:
        s = _Session()
        s.record(_rec(0.10))
        s.record(_rec(0.05))
        assert s.iterations == 2
        assert s.cost_usd == pytest.approx(0.15)

    def test_iteration_limit_raises_after_max(self) -> None:
        s = _Session(max_iterations=2)
        s.record(_rec())
        s.record(_rec())
        with pytest.raises(IterationLimitError) as exc:
            s.record(_rec())
        assert exc.value.iterations == 3
        assert exc.value.max_iterations == 2

    def test_budget_raises_when_exceeded(self) -> None:
        s = _Session(budget_usd=1.0)
        s.record(_rec(0.6))
        s.record(_rec(0.3))  # total 0.9, still under
        with pytest.raises(BudgetExceededError) as exc:
            s.record(_rec(0.2))  # crosses to 1.1
        assert exc.value.cost_usd == pytest.approx(1.1)
        assert exc.value.budget_usd == 1.0

    def test_budget_exact_match_does_not_raise(self) -> None:
        s = _Session(budget_usd=1.0)
        s.record(_rec(1.0))
        assert s.cost_usd == pytest.approx(1.0)

    def test_budget_remaining(self) -> None:
        s = _Session(budget_usd=2.0)
        assert s.budget_remaining == pytest.approx(2.0)
        s.record(_rec(0.5))
        assert s.budget_remaining == pytest.approx(1.5)

    def test_budget_remaining_unbounded(self) -> None:
        assert _Session().budget_remaining is None

    def test_rejects_non_positive_limits(self) -> None:
        with pytest.raises(ValueError):
            _Session(max_iterations=0)
        with pytest.raises(ValueError):
            _Session(budget_usd=0)
        with pytest.raises(ValueError):
            _Session(max_parallel=0)


class TestSessionIntegration:
    """Tests that drive run_claude through agent_context with a fake CLI."""

    @pytest.mark.asyncio
    async def test_no_session_means_unbounded(self, fake_run: list[float]) -> None:
        """Outside an agent_context, calls do not touch any session."""
        from gyre.subprocess import run_claude

        for _ in range(5):
            await run_claude("ping")
        assert _active_session.get() is None

    @pytest.mark.asyncio
    async def test_iteration_limit_enforced(self, fake_run: list[float]) -> None:
        """The (max_iterations + 1)th call raises IterationLimitError."""
        async with agent_context(max_iterations=3) as agent:
            await agent.check("q")
            await agent.check("q")
            await agent.check("q")
            with pytest.raises(IterationLimitError):
                await agent.check("q")
            assert agent.iterations == 4  # the failing call is recorded

    @pytest.mark.asyncio
    async def test_budget_enforced(self, fake_run: list[float]) -> None:
        """Cumulative cost crossing budget_usd raises BudgetExceededError."""
        fake_run.extend([0.40, 0.40, 0.40])
        async with agent_context(budget_usd=1.0) as agent:
            await agent.check("q")  # 0.40
            await agent.check("q")  # 0.80
            with pytest.raises(BudgetExceededError):
                await agent.check("q")  # 1.20 — over
            assert agent.cost_usd == pytest.approx(1.20)
            assert agent.budget_remaining == pytest.approx(0.0)

    @pytest.mark.asyncio
    async def test_max_parallel_serializes_calls(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """max_parallel=N caps in-flight calls via the session semaphore."""
        in_flight = 0
        peak = 0
        gate = asyncio.Event()

        async def slow_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            nonlocal in_flight, peak
            in_flight += 1
            peak = max(peak, in_flight)
            await gate.wait()
            in_flight -= 1
            return _make_response(cost_usd=0.0)

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", slow_stub)

        async with agent_context(max_parallel=2) as agent:
            tasks = [asyncio.create_task(agent.check("q")) for _ in range(5)]
            # Let the loop schedule everything; only 2 should be in-flight.
            await asyncio.sleep(0)
            await asyncio.sleep(0)
            assert peak <= 2
            gate.set()
            await asyncio.gather(*tasks)
            assert agent.iterations == 5

    @pytest.mark.asyncio
    async def test_top_level_check_picks_up_session(
        self, fake_run: list[float]
    ) -> None:
        """A top-level `check()` call inside a context is also budgeted."""
        from gyre import check as top_level_check

        async with agent_context(max_iterations=1) as agent:
            await top_level_check("q")
            with pytest.raises(IterationLimitError):
                await top_level_check("q")
            assert agent.iterations == 2

    @pytest.mark.asyncio
    async def test_session_isolation_between_contexts(
        self, fake_run: list[float]
    ) -> None:
        """Counters reset between independent agent_context invocations."""
        async with agent_context() as agent1:
            await agent1.check("q")
            assert agent1.iterations == 1

        async with agent_context() as agent2:
            assert agent2.iterations == 0
            await agent2.check("q")
            assert agent2.iterations == 1
