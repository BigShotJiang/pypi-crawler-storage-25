"""Tests for Phase 4: session log capture and dump_log."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from gyre import (
    Agent,
    BudgetExceededError,
    CallRecord,
    Tool,
    agent_context,
    memorize,
)
from gyre.subprocess import CLIResponse


def _ok_response(cost: float = 0.05, result: str = "ok") -> CLIResponse:
    return CLIResponse(
        success=True,
        result=result,
        structured_output={"answer": True, "value": 42, "items": ["a", "b"]},
        session_id="sess-1",
        duration_ms=12,
        cost_usd=cost,
        raw={"subtype": "success"},
    )


@pytest.fixture
def stub(monkeypatch: pytest.MonkeyPatch) -> list[dict[str, Any]]:
    captured: list[dict[str, Any]] = []

    async def stub_impl(prompt: str, **kwargs: Any) -> CLIResponse:
        captured.append({"prompt": prompt, **kwargs})
        return _ok_response()

    monkeypatch.setattr("gyre.subprocess._run_claude_impl", stub_impl)
    return captured


class TestLogCapture:
    @pytest.mark.asyncio
    async def test_check_recorded_with_kind_and_type(self, stub: list[Any]) -> None:
        async with agent_context() as agent:
            await agent.check("ok?")
        log = agent.log()
        assert len(log) == 1
        rec = log[0]
        assert rec.kind == "check"
        assert rec.type_name == "bool"
        assert rec.session_id == "sess-1"
        assert rec.cost_usd == pytest.approx(0.05)
        assert rec.duration_ms == 12

    @pytest.mark.asyncio
    async def test_get_records_target_type_name(self, stub: list[Any]) -> None:
        async with agent_context() as agent:
            await agent.get(int, "how many?")
        rec = agent.log()[0]
        assert rec.kind == "get"
        assert rec.type_name == "int"

    @pytest.mark.asyncio
    async def test_get_list_records_item_type_name(self, stub: list[Any]) -> None:
        async with agent_context() as agent:
            await agent.get_list(str, "list them")
        rec = agent.log()[0]
        assert rec.kind == "get_list"
        assert rec.type_name == "str"

    @pytest.mark.asyncio
    async def test_do_records_kind_with_no_type_name(self, stub: list[Any]) -> None:
        async with agent_context(tools=[Tool.Read]) as agent:
            await agent.do("inspect X")
        rec = agent.log()[0]
        assert rec.kind == "do"
        assert rec.type_name is None
        assert rec.tools == ("Read",)

    @pytest.mark.asyncio
    async def test_memory_labels_captured(
        self, stub: list[Any], tmp_path: Path
    ) -> None:
        m = memorize("brand voice notes", label="voice", directory=tmp_path)
        async with agent_context(memories=[m]) as agent:
            await agent.check("on brand?")
        rec = agent.log()[0]
        assert rec.memory_labels == ("voice",)

    @pytest.mark.asyncio
    async def test_result_summary_truncated(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        async def long_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(result="x" * 5000)

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", long_stub)

        async with agent_context(tools=[Tool.Read]) as agent:
            await agent.do("noop")
        rec = agent.log()[0]
        assert len(rec.result_summary) <= 500
        assert rec.result_summary.endswith("…")

    @pytest.mark.asyncio
    async def test_full_result_preserved(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The full untruncated result is available on `result`."""
        full = "x" * 5000

        async def long_stub(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(result=full)

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", long_stub)

        async with agent_context(tools=[Tool.Read]) as agent:
            await agent.do("noop")
        rec = agent.log()[0]
        assert rec.result == full
        assert len(rec.result) == 5000

    @pytest.mark.asyncio
    async def test_log_includes_call_that_breached_budget(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        async def stub_impl(_prompt: str, **_kwargs: Any) -> CLIResponse:
            return _ok_response(cost=0.6)

        monkeypatch.setattr("gyre.subprocess._run_claude_impl", stub_impl)

        async with agent_context(budget_usd=1.0) as agent:
            await agent.check("q")  # 0.6
            with pytest.raises(BudgetExceededError):
                await agent.check("q")  # 1.2 — over
            assert len(agent.log()) == 2  # the offending call IS recorded


class TestDumpLog:
    @pytest.mark.asyncio
    async def test_dump_log_round_trips(
        self, stub: list[Any], tmp_path: Path
    ) -> None:
        out = tmp_path / "log.json"
        async with agent_context() as agent:
            await agent.check("ok?")
            await agent.get(int, "n?")
            agent.dump_log(out)

        data = json.loads(out.read_text())
        assert isinstance(data, list)
        assert len(data) == 2
        assert data[0]["kind"] == "check"
        assert data[1]["kind"] == "get"
        # timestamps are ISO strings
        assert "T" in data[0]["timestamp"]

    @pytest.mark.asyncio
    async def test_dump_log_outside_session_writes_empty(
        self, tmp_path: Path
    ) -> None:
        out = tmp_path / "empty.json"
        Agent().dump_log(out)
        assert json.loads(out.read_text()) == []

    @pytest.mark.asyncio
    async def test_log_summary_mentions_call_count(self, stub: list[Any]) -> None:
        async with agent_context() as agent:
            await agent.check("ok?")
            await agent.check("ok?")
            summary = agent.log_summary()
        assert "2 calls" in summary
        assert "check" in summary

    @pytest.mark.asyncio
    async def test_call_record_to_jsonable_serializable(
        self, stub: list[Any]
    ) -> None:
        async with agent_context() as agent:
            await agent.check("ok?")
        rec: CallRecord = agent.log()[0]
        # Must round-trip through json.dumps without a custom encoder.
        json.dumps(rec.to_jsonable())
