"""Tests for Gyre commands."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import BaseModel

from gyre.commands import _build_list_schema, _TypedGetList, memorize
from gyre.schemas import type_to_json_schema, wrap_for_extraction
from gyre.types import (
    MUTATING_TOOLS,
    AgentConfig,
    AgentResult,
    Memory,
    PermissionMode,
    Tool,
)


class TestTypes:
    """Test type definitions."""

    def test_agent_config_defaults(self) -> None:
        """AgentConfig has sensible defaults."""
        config = AgentConfig()
        assert config.system_prompt is None
        assert config.tools is None
        assert config.permission_mode == PermissionMode.DEFAULT
        assert config.timeout is None  # Uses model-based defaults

    def test_agent_config_immutable(self) -> None:
        """AgentConfig is immutable."""
        config = AgentConfig()
        with pytest.raises(AttributeError):
            config.timeout = 100.0  # type: ignore[misc]

    def test_agent_result_generic(self) -> None:
        """AgentResult works with generic types."""
        result: AgentResult[int] = AgentResult(
            value=42,
            session_id="test-session",
            duration_ms=100,
            cost_usd=0.01,
            raw_response={},
        )
        assert result.value == 42


class TestSchemas:
    """Test JSON schema generation."""

    def test_primitive_types(self) -> None:
        """Primitive types generate correct schemas."""
        assert type_to_json_schema(str) == {"type": "string"}
        assert type_to_json_schema(int) == {"type": "integer"}
        assert type_to_json_schema(float) == {"type": "number"}
        assert type_to_json_schema(bool) == {"type": "boolean"}

    def test_list_type(self) -> None:
        """list[T] generates correct schema."""
        schema = type_to_json_schema(list[str])
        assert schema == {"type": "array", "items": {"type": "string"}}

    def test_nested_list(self) -> None:
        """Nested list types work."""
        schema = type_to_json_schema(list[list[int]])
        assert schema == {
            "type": "array",
            "items": {"type": "array", "items": {"type": "integer"}},
        }

    def test_dict_type(self) -> None:
        """dict[str, T] generates correct schema."""
        schema = type_to_json_schema(dict[str, int])
        assert schema == {
            "type": "object",
            "additionalProperties": {"type": "integer"},
        }

    def test_pydantic_model(self) -> None:
        """Pydantic models generate correct schema."""

        class Task(BaseModel):
            title: str
            done: bool

        schema = type_to_json_schema(Task)
        assert schema["type"] == "object"
        assert "title" in schema["properties"]
        assert "done" in schema["properties"]

    def test_wrap_for_extraction(self) -> None:
        """wrap_for_extraction creates wrapper object."""
        inner = {"type": "string"}
        wrapped = wrap_for_extraction(inner, key="value")
        assert wrapped == {
            "type": "object",
            "properties": {"value": {"type": "string"}},
            "required": ["value"],
        }

    def test_unsupported_type_raises(self) -> None:
        """Unsupported types raise TypeError."""
        with pytest.raises(TypeError, match="Unsupported type"):
            type_to_json_schema(set)  # type: ignore[arg-type]


class TestAgent:
    """Test Agent fluent builder."""

    def test_agent_chaining(self) -> None:
        """Agent methods chain correctly."""
        from gyre import Agent, PermissionMode, Tool

        agent = (
            Agent()
            .with_prompt("test prompt")
            .with_tools(Tool.Read, Tool.Grep)
            .with_permission_mode(PermissionMode.PLAN)
            .with_timeout(60.0)
            .in_directory("/tmp")
        )

        assert agent._config.system_prompt == "test prompt"
        assert agent._config.tools == (Tool.Read, Tool.Grep)
        assert agent._config.permission_mode == PermissionMode.PLAN
        assert agent._config.timeout == 60.0
        assert agent._config.working_dir == "/tmp"

    def test_with_tools_accepts_strings(self) -> None:
        """with_tools accepts raw strings for MCP/custom tools."""
        from gyre import Agent, Tool

        agent = Agent().with_tools(Tool.Read, "mcp__custom__foo")
        assert agent._config.tools == (Tool.Read, "mcp__custom__foo")

    def test_agent_immutability(self) -> None:
        """Agent methods return new instances."""
        from gyre import Agent

        agent1 = Agent()
        agent2 = agent1.with_prompt("test")

        assert agent1 is not agent2
        assert agent1._config.system_prompt is None
        assert agent2._config.system_prompt == "test"


class TestTool:
    """Test Tool enum and MUTATING_TOOLS."""

    def test_tool_serializes_to_string(self) -> None:
        """Tool members serialize cleanly as their CLI name."""
        assert Tool.Read.value == "Read"
        assert Tool.Edit.value == "Edit"

    def test_mutating_tools_set(self) -> None:
        """MUTATING_TOOLS contains the side-effecting built-ins."""
        assert Tool.Bash in MUTATING_TOOLS
        assert Tool.Edit in MUTATING_TOOLS
        assert Tool.Write in MUTATING_TOOLS
        assert Tool.MultiEdit in MUTATING_TOOLS
        assert Tool.NotebookEdit in MUTATING_TOOLS

    def test_read_only_tools_not_mutating(self) -> None:
        """Read-only tools are absent from MUTATING_TOOLS."""
        assert Tool.Read not in MUTATING_TOOLS
        assert Tool.Grep not in MUTATING_TOOLS
        assert Tool.Glob not in MUTATING_TOOLS


class TestMemory:
    """Test the Memory handle and memorize()."""

    def test_memorize_returns_memory_handle(self, tmp_path: Path) -> None:
        """memorize() writes the file and returns a Memory."""
        m = memorize("hello world", label="greeting", directory=tmp_path)
        assert isinstance(m, Memory)
        assert m.label == "greeting"
        assert m.path.exists()
        assert m.read() == "hello world"

    def test_memorize_default_label(self) -> None:
        """memorize() generates a label when none is given."""
        m = memorize("content")
        assert m.label.startswith("memory_")
        assert m.path.exists()

    def test_memory_rejects_missing_path(self, tmp_path: Path) -> None:
        """Memory raises FileNotFoundError for a non-existent path."""
        missing = tmp_path / "nope.txt"
        with pytest.raises(FileNotFoundError):
            Memory(label="x", path=missing)

    def test_memory_re_reads_on_each_read(self, tmp_path: Path) -> None:
        """Memory.read() reflects subsequent edits to the file."""
        m = memorize("v1", directory=tmp_path)
        m.path.write_text("v2", encoding="utf-8")
        assert m.read() == "v2"

    def test_memorize_path_writes_to_exact_path(self, tmp_path: Path) -> None:
        """`path=` writes content to exactly that path."""
        target = tmp_path / "voice.md"
        m = memorize("brand voice", label="voice", path=target)
        assert m.path == target
        assert target.read_text() == "brand voice"

    def test_memorize_path_creates_parent_dirs(self, tmp_path: Path) -> None:
        """`path=` creates missing parent directories."""
        target = tmp_path / "deeply" / "nested" / "voice.md"
        m = memorize("x", path=target)
        assert m.path == target
        assert target.exists()

    def test_memorize_path_and_directory_mutually_exclusive(
        self, tmp_path: Path
    ) -> None:
        """Passing both `path` and `directory` is a ValueError."""
        with pytest.raises(ValueError, match="not both"):
            memorize("x", path=tmp_path / "f.md", directory=tmp_path)


class TestGetListN:
    """Test the n= argument on get_list."""

    def test_n_injects_min_max_items(self) -> None:
        """When n is set, the built schema constrains items to exactly n."""
        schema = _build_list_schema(int, n=8)
        items = schema["properties"]["items"]
        assert items["type"] == "array"
        assert items["items"] == {"type": "integer"}
        assert items["minItems"] == 8
        assert items["maxItems"] == 8

    def test_n_unset_omits_min_max(self) -> None:
        """Without n, the schema places no count constraint."""
        schema = _build_list_schema(str, n=None)
        items = schema["properties"]["items"]
        assert "minItems" not in items
        assert "maxItems" not in items

    def test_n_negative_rejected(self) -> None:
        """Negative n raises ValueError before any CLI call."""
        import asyncio

        async def call() -> None:
            await _TypedGetList(int)("how many?", n=-1)

        with pytest.raises(ValueError, match="non-negative"):
            asyncio.run(call())
