"""Type definitions for Gyre."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class PermissionMode(Enum):
    """Permission modes for Claude CLI operations."""

    DEFAULT = "default"
    ACCEPT_EDITS = "acceptEdits"
    BYPASS = "bypassPermissions"
    PLAN = "plan"


class Tool(str, Enum):
    """Built-in Claude Code tools.

    Inherits from str so values serialize cleanly to the CLI. Custom or
    MCP tools can be passed as plain strings alongside Tool members
    wherever a tool list is accepted.

    Mutating tools (those that can modify the filesystem or shell state)
    are listed in `MUTATING_TOOLS`. Operations that should not perform
    side effects (e.g. dry-run mode) reject these.
    """

    Bash = "Bash"
    Edit = "Edit"
    Glob = "Glob"
    Grep = "Grep"
    MultiEdit = "MultiEdit"
    NotebookEdit = "NotebookEdit"
    NotebookRead = "NotebookRead"
    Read = "Read"
    Task = "Task"
    TodoWrite = "TodoWrite"
    WebFetch = "WebFetch"
    WebSearch = "WebSearch"
    Write = "Write"


MUTATING_TOOLS: frozenset[Tool] = frozenset(
    {Tool.Bash, Tool.Edit, Tool.MultiEdit, Tool.NotebookEdit, Tool.Write}
)


ToolSpec = Tool | str
"""A tool reference: either a Tool enum member or a raw string for
custom/MCP tools. Strings are passed through to the CLI unchanged."""


@dataclass(frozen=True, slots=True)
class Memory:
    """A handle to a piece of context stored on disk.

    Returned by `gyre.memorize()`. Pass via `memories=[...]` to any
    operation to inject the file's content into the prompt, wrapped in
    a `<context label="...">` tag.

    Memory files must exist when the handle is constructed; missing
    files raise `FileNotFoundError`. The file is re-read on every call
    that uses the memory, so live edits are picked up.
    """

    label: str
    path: Path
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        if not self.path.exists():
            raise FileNotFoundError(f"Memory file not found: {self.path}")

    def read(self) -> str:
        """Read the memory's content from disk."""
        return self.path.read_text(encoding="utf-8")


@dataclass(frozen=True, slots=True)
class AgentConfig:
    """Immutable configuration for agent operations."""

    system_prompt: str | None = None
    append_prompt: str | None = None
    tools: tuple[ToolSpec, ...] | None = None
    permission_mode: PermissionMode = PermissionMode.DEFAULT
    model: str | None = None
    timeout: float | None = None  # None = use model-based default
    working_dir: str | None = None
    memories: tuple[Memory, ...] | None = None


@dataclass(frozen=True, slots=True)
class AgentResult(Generic[T]):
    """Result from an agent operation."""

    value: T
    session_id: str
    duration_ms: int
    cost_usd: float
    raw_response: dict[str, Any]

    @property
    def duration_formatted(self) -> str:
        """Return duration as human-readable string (e.g., '1m 30s')."""
        total_seconds = self.duration_ms // 1000
        minutes, seconds = divmod(total_seconds, 60)
        if minutes > 0:
            return f"{minutes}m {seconds}s"
        return f"{seconds}s"
