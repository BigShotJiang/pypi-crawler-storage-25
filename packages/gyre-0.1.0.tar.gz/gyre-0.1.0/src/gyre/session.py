"""Per-context session state: budget, iteration limit, parallelism, log, replay.

A `_Session` is installed by `agent_context` via the `_active_session`
contextvar. Every `run_claude` call within the context picks it up
automatically: the call passes through the session's semaphore for
`max_parallel`, and on success the session records a `CallRecord` and
bumps the iteration counter, raising `BudgetExceededError` or
`IterationLimitError` on the call that crosses the configured limit.

The log is the second wedge: every call is captured with its kind,
prompt, schema, tools, memory labels and content hashes, model, system
prompt, permission mode, working dir, cost, duration, full result, and
structured output. `Agent.dump_log(path)` writes JSON for offline
inspection, eval, or replay.

When `agent_context(replay_from=path)` is active, calls are matched
against records loaded from `path`. Hash-keyed FIFO buckets handle
duplicate-input calls (e.g. parallel scoring of identical drafts)
correctly. A miss raises `ReplayCacheMissError` by default; pass
`replay_on_miss="passthrough"` to fall through to a live call.

Outside a context, no session is active and calls run unbounded.
"""

from __future__ import annotations

import asyncio
import contextvars
import hashlib
import json
from collections import deque
from collections.abc import Iterable
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from gyre.errors import BudgetExceededError, IterationLimitError

_RESULT_SUMMARY_MAX_CHARS = 500


def _truncate(text: str, limit: int = _RESULT_SUMMARY_MAX_CHARS) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1] + "…"


def hash_memory_content(content: str) -> str:
    """Stable sha256 hex digest of a memory's content. Used for cache keys."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _call_key(
    *,
    kind: str,
    prompt: str,
    schema: dict[str, Any] | None,
    tool_names: tuple[str, ...] | None,
    memory_labels: tuple[str, ...],
    memory_hashes: tuple[str, ...],
    system_prompt: str | None,
    append_prompt: str | None,
    model: str | None,
    permission_mode: str,
    working_dir: str | None,
) -> str:
    """Compute the canonical replay cache key for a call.

    Hashes everything that can affect the call's output. Tool order is
    normalized (sorted) since it doesn't affect output. Memory order is
    preserved since it determines the order memories are appended to
    the prompt.
    """
    payload = {
        "kind": kind,
        "prompt": prompt,
        "schema": schema,
        "tools": sorted(tool_names) if tool_names else None,
        "memories": list(zip(memory_labels, memory_hashes, strict=True)),
        "system_prompt": system_prompt,
        "append_prompt": append_prompt,
        "model": model,
        "permission_mode": permission_mode,
        "working_dir": working_dir,
    }
    blob = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class CallRecord:
    """One row in the session log: a single call to the Claude CLI.

    Captures the full call signature (prompt, schema, tools, model,
    system prompt, permission mode, working dir, memory labels and
    content hashes) and the response (cost, duration, full result,
    structured output). The combination is enough to replay the call
    deterministically from the log.

    Memory contents themselves are not stored — only labels and content
    hashes — so logs stay tractable even with large memory files.
    """

    kind: str
    """One of "check", "do", "get", "get_list", or "raw"."""

    prompt: str
    """The user-level prompt, before memory injection."""

    type_name: str | None
    """For typed extraction: the target type's __name__. None for `do`."""

    schema: dict[str, Any] | None
    """JSON schema sent to the CLI, if any."""

    tools: tuple[str, ...] | None
    """Tool names allowed for this call (already serialized to strings)."""

    memory_labels: tuple[str, ...]
    """Labels of memories attached to this call (contents not inlined)."""

    session_id: str
    """The CLI session id from the response."""

    cost_usd: float
    duration_ms: int
    timestamp: datetime
    """UTC timestamp recorded after the call returned."""

    result: str
    """The full CLI `result` field, untruncated. Suitable for replay
    or eval. Use `result_summary` for display."""

    result_summary: str
    """The CLI's `result` field, truncated to ~500 chars for display
    in `log_summary()`. The full result is in `result`."""

    # Fields below have defaults so existing test sites that build
    # synthetic CallRecords via `make()` keep working without churn.

    system_prompt: str | None = None
    """System prompt sent to the CLI, if any. Part of the replay key."""

    append_prompt: str | None = None
    """Append-system-prompt sent to the CLI, if any. Part of the replay key."""

    model: str | None = None
    """Model identifier passed to the CLI. Part of the replay key."""

    permission_mode: str = "default"
    """Permission mode in effect for this call. Part of the replay key."""

    working_dir: str | None = None
    """Working directory for the call. Part of the replay key."""

    memory_hashes: tuple[str, ...] = ()
    """sha256 of each memory's content at call time, in order. Lets
    replay distinguish two records with the same memory labels but
    different content."""

    structured_output: dict[str, Any] | None = None
    """The CLI's `structured_output` field, preserved verbatim. Required
    for replaying typed extractions, which read this dict to construct
    the returned value."""

    @classmethod
    def make(
        cls,
        *,
        kind: str,
        prompt: str,
        type_name: str | None,
        schema: dict[str, Any] | None,
        tool_names: tuple[str, ...] | None,
        memory_labels: tuple[str, ...],
        session_id: str,
        cost_usd: float,
        duration_ms: int,
        result: str,
        system_prompt: str | None = None,
        append_prompt: str | None = None,
        model: str | None = None,
        permission_mode: str = "default",
        working_dir: str | None = None,
        memory_hashes: tuple[str, ...] = (),
        structured_output: dict[str, Any] | None = None,
    ) -> CallRecord:
        return cls(
            kind=kind,
            prompt=prompt,
            type_name=type_name,
            schema=schema,
            tools=tool_names,
            memory_labels=memory_labels,
            session_id=session_id,
            cost_usd=cost_usd,
            duration_ms=duration_ms,
            timestamp=datetime.now(UTC),
            result=result,
            result_summary=_truncate(result),
            system_prompt=system_prompt,
            append_prompt=append_prompt,
            model=model,
            permission_mode=permission_mode,
            working_dir=working_dir,
            memory_hashes=memory_hashes,
            structured_output=structured_output,
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CallRecord:
        """Construct a CallRecord from a JSON-loaded dict.

        Handles old log files (pre-replay-feature) gracefully: missing
        fields default to None / () / "default", which means a record
        with no captured `system_prompt` will only match a live call
        that also has no `system_prompt`.
        """
        timestamp = data.get("timestamp")
        if isinstance(timestamp, str):
            ts = datetime.fromisoformat(timestamp)
        elif isinstance(timestamp, datetime):
            ts = timestamp
        else:
            ts = datetime.now(UTC)

        result = data.get("result")
        if result is None:
            result = data.get("result_summary", "")
        result_summary = data.get("result_summary", _truncate(result))

        return cls(
            kind=data["kind"],
            prompt=data["prompt"],
            type_name=data.get("type_name"),
            schema=data.get("schema"),
            tools=tuple(data["tools"]) if data.get("tools") else None,
            memory_labels=tuple(data.get("memory_labels") or ()),
            session_id=data.get("session_id", ""),
            cost_usd=float(data.get("cost_usd", 0.0)),
            duration_ms=int(data.get("duration_ms", 0)),
            timestamp=ts,
            result=result,
            result_summary=result_summary,
            system_prompt=data.get("system_prompt"),
            append_prompt=data.get("append_prompt"),
            model=data.get("model"),
            permission_mode=data.get("permission_mode", "default"),
            working_dir=data.get("working_dir"),
            memory_hashes=tuple(data.get("memory_hashes") or ()),
            structured_output=data.get("structured_output"),
        )

    def to_jsonable(self) -> dict[str, Any]:
        """Return a dict that `json.dumps` can serialize directly."""
        data = asdict(self)
        data["timestamp"] = self.timestamp.isoformat()
        return data

    def replay_key(self) -> str:
        """Compute this record's replay cache key from its stored fields."""
        return _call_key(
            kind=self.kind,
            prompt=self.prompt,
            schema=self.schema,
            tool_names=self.tools,
            memory_labels=self.memory_labels,
            memory_hashes=self.memory_hashes,
            system_prompt=self.system_prompt,
            append_prompt=self.append_prompt,
            model=self.model,
            permission_mode=self.permission_mode,
            working_dir=self.working_dir,
        )


def load_log(path: str | Path) -> tuple[CallRecord, ...]:
    """Load a dumped session log into a tuple of `CallRecord`.

    Reads the JSON array written by `Agent.dump_log` and reconstructs
    each row. Pre-replay-feature logs (without `memory_hashes`,
    `system_prompt`, etc.) load with default values for the missing
    fields; they will only match live calls that also have those
    defaults.

    Args:
        path: Filesystem path to a JSON file produced by `dump_log`.

    Returns:
        Records in original log order.
    """
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return tuple(CallRecord.from_dict(d) for d in raw)


class _ReplayCache:
    """Hash-keyed FIFO buckets of CallRecords for replay matching.

    Identical-input calls (same key) bucket into a deque and pop FIFO
    on match — this preserves the order of duplicates within an
    `asyncio.gather(...)` fanout of identical-prompt calls (e.g.
    scoring N copies of a draft).
    """

    __slots__ = ("_buckets", "_total")

    def __init__(self, records: Iterable[CallRecord]) -> None:
        self._buckets: dict[str, deque[CallRecord]] = {}
        self._total = 0
        for r in records:
            self._buckets.setdefault(r.replay_key(), deque()).append(r)
            self._total += 1

    def __len__(self) -> int:
        return sum(len(b) for b in self._buckets.values())

    @property
    def total_loaded(self) -> int:
        """Records originally loaded, even after some have been consumed."""
        return self._total

    def try_match(self, key: str) -> CallRecord | None:
        bucket = self._buckets.get(key)
        if not bucket:
            return None
        return bucket.popleft()


class _Session:
    __slots__ = (
        "_budget_usd",
        "_cost_usd",
        "_iterations",
        "_log",
        "_max_iterations",
        "_replay_cache",
        "_replay_on_miss",
        "_semaphore",
    )

    def __init__(
        self,
        *,
        max_iterations: int | None = None,
        budget_usd: float | None = None,
        max_parallel: int | None = None,
        replay_cache: _ReplayCache | None = None,
        replay_on_miss: Literal["raise", "passthrough"] = "raise",
    ) -> None:
        if max_iterations is not None and max_iterations <= 0:
            raise ValueError(f"max_iterations must be positive, got {max_iterations}")
        if budget_usd is not None and budget_usd <= 0:
            raise ValueError(f"budget_usd must be positive, got {budget_usd}")
        if max_parallel is not None and max_parallel <= 0:
            raise ValueError(f"max_parallel must be positive, got {max_parallel}")
        if replay_on_miss not in ("raise", "passthrough"):
            raise ValueError(
                f"replay_on_miss must be 'raise' or 'passthrough', got {replay_on_miss!r}"
            )

        self._max_iterations = max_iterations
        self._budget_usd = budget_usd
        self._semaphore: asyncio.Semaphore | None = (
            asyncio.Semaphore(max_parallel) if max_parallel is not None else None
        )
        self._iterations = 0
        self._cost_usd = 0.0
        self._log: list[CallRecord] = []
        self._replay_cache = replay_cache
        self._replay_on_miss: Literal["raise", "passthrough"] = replay_on_miss

    @property
    def iterations(self) -> int:
        return self._iterations

    @property
    def cost_usd(self) -> float:
        return self._cost_usd

    @property
    def budget_remaining(self) -> float | None:
        if self._budget_usd is None:
            return None
        return max(0.0, self._budget_usd - self._cost_usd)

    def log(self) -> tuple[CallRecord, ...]:
        """Return all recorded calls in order, including the one that
        raised on a limit (if any)."""
        return tuple(self._log)

    def has_replay(self) -> bool:
        return self._replay_cache is not None

    @property
    def replay_on_miss(self) -> Literal["raise", "passthrough"]:
        return self._replay_on_miss

    def try_replay_match(self, key: str) -> CallRecord | None:
        """Return a cached CallRecord matching `key`, popping it FIFO.

        Returns None if replay is not configured or no record matches.
        """
        if self._replay_cache is None:
            return None
        return self._replay_cache.try_match(key)

    async def acquire(self) -> None:
        if self._semaphore is not None:
            await self._semaphore.acquire()

    def release(self) -> None:
        if self._semaphore is not None:
            self._semaphore.release()

    def record(self, record: CallRecord) -> None:
        """Append a record, bump counters, and check limits.

        Raises `IterationLimitError` or `BudgetExceededError` if this
        call pushed the session past a configured limit. The record is
        appended *before* the limit check, so the log includes the
        offending call (matching `cost_usd` and `iterations`).
        """
        self._log.append(record)
        self._iterations += 1
        self._cost_usd += record.cost_usd
        if (
            self._max_iterations is not None
            and self._iterations > self._max_iterations
        ):
            raise IterationLimitError(self._iterations, self._max_iterations)
        if self._budget_usd is not None and self._cost_usd > self._budget_usd:
            raise BudgetExceededError(self._cost_usd, self._budget_usd)

    def log_summary(self) -> str:
        """Multi-line text summary suitable for printing."""
        if not self._log:
            return "No calls recorded."
        lines = [
            f"{len(self._log)} calls, ${self._cost_usd:.4f} total"
            + (
                f" / ${self._budget_usd:.4f} budget"
                if self._budget_usd is not None
                else ""
            )
        ]
        for i, r in enumerate(self._log, start=1):
            type_part = f"<{r.type_name}>" if r.type_name else ""
            lines.append(
                f"  {i:>3}. {r.kind}{type_part} ${r.cost_usd:.4f} "
                f"{r.duration_ms}ms — {_truncate(r.prompt, 80)}"
            )
        return "\n".join(lines)

    def dump_log(self, path: str | Path) -> None:
        """Write the log to `path` as a JSON array."""
        out = [r.to_jsonable() for r in self._log]
        Path(path).write_text(json.dumps(out, indent=2), encoding="utf-8")


_active_session: contextvars.ContextVar[_Session | None] = contextvars.ContextVar(
    "gyre_active_session", default=None
)
