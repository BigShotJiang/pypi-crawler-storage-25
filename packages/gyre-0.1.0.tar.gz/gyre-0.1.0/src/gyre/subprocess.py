"""Claude CLI subprocess management."""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Any

from gyre.errors import AgentExecutionError, AgentTimeoutError, ReplayCacheMissError
from gyre.session import (
    CallRecord,
    _active_session,
    _call_key,
    hash_memory_content,
)
from gyre.types import Memory, Tool, ToolSpec

# Default timeouts by model (in seconds)
MODEL_TIMEOUTS: dict[str, float] = {
    "opus": 1800.0,      # 30 minutes
    "sonnet": 1200.0,    # 20 minutes
    "haiku": 600.0,      # 10 minutes
}
DEFAULT_TIMEOUT = 1200.0  # 20 minutes fallback


def _get_timeout_for_model(model: str | None, explicit_timeout: float | None) -> float:
    """Get the appropriate timeout for a model.

    Args:
        model: Model name or alias (e.g., "opus", "sonnet", "haiku").
        explicit_timeout: Explicitly provided timeout, if any.

    Returns:
        Timeout in seconds.
    """
    if explicit_timeout is not None:
        return explicit_timeout

    if model:
        # Check for exact match or if model contains the alias
        model_lower = model.lower()
        for alias, timeout in MODEL_TIMEOUTS.items():
            if alias in model_lower:
                return timeout

    return DEFAULT_TIMEOUT


@dataclass(frozen=True, slots=True)
class CLIResponse:
    """Parsed response from Claude CLI."""

    success: bool
    result: str
    structured_output: dict[str, Any] | None
    session_id: str
    duration_ms: int
    cost_usd: float
    raw: dict[str, Any]


def _tool_name(t: ToolSpec) -> str:
    """Serialize a Tool enum member or raw string to its CLI name."""
    return t.value if isinstance(t, Tool) else t


async def run_claude(
    prompt: str,
    *,
    system_prompt: str | None = None,
    append_prompt: str | None = None,
    tools: tuple[ToolSpec, ...] | None = None,
    permission_mode: str = "default",
    json_schema: dict[str, Any] | None = None,
    model: str | None = None,
    working_dir: str | None = None,
    timeout: float | None = None,
    memories: tuple[Memory, ...] | None = None,
    kind: str = "raw",
    type_name: str | None = None,
) -> CLIResponse:
    """Execute Claude CLI and return parsed response.

    If an `agent_context` session is active, this call passes through
    the session's parallelism gate (`max_parallel`), is recorded in the
    session log as a `CallRecord`, and reports its cost on success —
    which may raise `BudgetExceededError` or `IterationLimitError` if
    the call crosses the configured limit.

    Args:
        prompt: The prompt to send to Claude.
        system_prompt: Override the system prompt.
        append_prompt: Append to the system prompt.
        tools: Limit available tools.
        permission_mode: Permission mode for the operation.
        json_schema: JSON schema for structured output.
        model: Model to use (e.g., "claude-sonnet-4-20250514").
        working_dir: Working directory for the operation.
        timeout: Timeout in seconds. If None, uses model-based defaults
            (30min for Opus, 20min for Sonnet, 10min for Haiku).
        memories: Memory handles to include as context.
        kind: Tag stored in the session log ("check", "do", "get",
            "get_list", or "raw"). Set by the public command functions.
        type_name: For typed extractions, the target type's __name__,
            stored in the log.

    Returns:
        CLIResponse with parsed output.

    Raises:
        AgentTimeoutError: If the operation times out.
        AgentExecutionError: If Claude CLI fails.
        BudgetExceededError: If a session is active and this call's
            cost pushed the cumulative total past the budget.
        IterationLimitError: If a session is active and this call
            pushed the iteration count past the limit.
    """
    session = _active_session.get()
    if session is None:
        return await _run_claude_impl(
            prompt,
            system_prompt=system_prompt,
            append_prompt=append_prompt,
            tools=tools,
            permission_mode=permission_mode,
            json_schema=json_schema,
            model=model,
            working_dir=working_dir,
            timeout=timeout,
            memories=memories,
        )

    tool_names: tuple[str, ...] | None = (
        tuple(_tool_name(t) for t in tools) if tools else None
    )
    memory_labels: tuple[str, ...] = (
        tuple(m.label for m in memories) if memories else ()
    )
    memory_hashes: tuple[str, ...] = (
        tuple(hash_memory_content(m.read()) for m in memories) if memories else ()
    )

    if session.has_replay():
        key = _call_key(
            kind=kind,
            prompt=prompt,
            schema=json_schema,
            tool_names=tool_names,
            memory_labels=memory_labels,
            memory_hashes=memory_hashes,
            system_prompt=system_prompt,
            append_prompt=append_prompt,
            model=model,
            permission_mode=permission_mode,
            working_dir=working_dir,
        )
        cached = session.try_replay_match(key)
        if cached is not None:
            response = CLIResponse(
                success=True,
                result=cached.result,
                structured_output=cached.structured_output,
                session_id=cached.session_id,
                duration_ms=cached.duration_ms,
                cost_usd=cached.cost_usd,
                raw={"subtype": "success", "replayed": True},
            )
            record = CallRecord.make(
                kind=kind,
                prompt=prompt,
                type_name=type_name,
                schema=json_schema,
                tool_names=tool_names,
                memory_labels=memory_labels,
                session_id=cached.session_id,
                cost_usd=cached.cost_usd,
                duration_ms=cached.duration_ms,
                result=cached.result,
                system_prompt=system_prompt,
                append_prompt=append_prompt,
                model=model,
                permission_mode=permission_mode,
                working_dir=working_dir,
                memory_hashes=memory_hashes,
                structured_output=cached.structured_output,
            )
            session.record(record)
            return response
        if session.replay_on_miss == "raise":
            raise ReplayCacheMissError(kind=kind, prompt=prompt, key=key)
        # passthrough — fall through to a live call

    await session.acquire()
    try:
        response = await _run_claude_impl(
            prompt,
            system_prompt=system_prompt,
            append_prompt=append_prompt,
            tools=tools,
            permission_mode=permission_mode,
            json_schema=json_schema,
            model=model,
            working_dir=working_dir,
            timeout=timeout,
            memories=memories,
        )
    finally:
        session.release()

    record = CallRecord.make(
        kind=kind,
        prompt=prompt,
        type_name=type_name,
        schema=json_schema,
        tool_names=tool_names,
        memory_labels=memory_labels,
        session_id=response.session_id,
        cost_usd=response.cost_usd,
        duration_ms=response.duration_ms,
        result=response.result,
        system_prompt=system_prompt,
        append_prompt=append_prompt,
        model=model,
        permission_mode=permission_mode,
        working_dir=working_dir,
        memory_hashes=memory_hashes,
        structured_output=response.structured_output,
    )
    session.record(record)
    return response


async def _run_claude_impl(
    prompt: str,
    *,
    system_prompt: str | None = None,
    append_prompt: str | None = None,
    tools: tuple[ToolSpec, ...] | None = None,
    permission_mode: str = "default",
    json_schema: dict[str, Any] | None = None,
    model: str | None = None,
    working_dir: str | None = None,
    timeout: float | None = None,
    memories: tuple[Memory, ...] | None = None,
) -> CLIResponse:
    """Spawn the Claude CLI subprocess and parse its response.

    The session-aware wrapper lives in `run_claude`; this helper is the
    raw subprocess interaction without budget/iteration accounting.
    """
    cmd = ["claude", "-p", "--output-format", "json"]

    if system_prompt:
        cmd.extend(["--system-prompt", system_prompt])
    if append_prompt:
        cmd.extend(["--append-system-prompt", append_prompt])
    if tools:
        cmd.extend(["--allowedTools", ",".join(_tool_name(t) for t in tools)])
    if permission_mode != "default":
        cmd.extend(["--permission-mode", permission_mode])
    if json_schema:
        cmd.extend(["--output-format", "json", "--json-schema", json.dumps(json_schema)])
    if model:
        cmd.extend(["--model", model])
    if memories:
        # Read each memory at call time and append wrapped in a <context>
        # tag carrying its label. Errors propagate — Memory construction
        # already validated existence; failures here mean the file was
        # removed or made unreadable since then, and the caller should
        # see that.
        memory_contents = [
            f'<context label="{m.label}">\n{m.read()}\n</context>' for m in memories
        ]
        prompt = prompt + "\n\n" + "\n".join(memory_contents)

    cmd.append(prompt)

    # Determine timeout based on model if not explicitly set
    effective_timeout = _get_timeout_for_model(model, timeout)

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=working_dir,
    )

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(), timeout=effective_timeout
        )
    except TimeoutError as err:
        proc.kill()
        await proc.wait()
        raise AgentTimeoutError(effective_timeout, "Claude CLI execution") from err

    try:
        data = json.loads(stdout.decode()) if stdout else {}
    except json.JSONDecodeError:
        data = {}

    if proc.returncode != 0 or data.get("is_error"):
        error_msg = data.get("result", "") if data else ""
        error_output = stderr.decode() if stderr else ""
        if error_msg:
            error_output = f"{error_msg}\n{error_output}".strip()
        raise AgentExecutionError(
            f"Claude CLI failed with exit code {proc.returncode}",
            stderr=error_output if error_output else None,
        )

    if not data:
        raise AgentExecutionError("Failed to parse Claude CLI output")

    return CLIResponse(
        success=data.get("subtype") == "success",
        result=data.get("result", ""),
        structured_output=data.get("structured_output"),
        session_id=data.get("session_id", ""),
        duration_ms=data.get("duration_ms", 0),
        cost_usd=data.get("total_cost_usd", 0.0),
        raw=data,
    )
