"""Fluent builder API and context manager for Gyre."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import replace
from pathlib import Path
from typing import Literal, TypeVar

from gyre.commands import _TypedGet, _TypedGetList
from gyre.commands import check as _check
from gyre.commands import do as _do
from gyre.commands import get_int as _get_int
from gyre.session import (
    CallRecord,
    _active_session,
    _ReplayCache,
    _Session,
    load_log,
)
from gyre.types import (
    MUTATING_TOOLS,
    AgentConfig,
    AgentResult,
    Memory,
    PermissionMode,
    Tool,
    ToolSpec,
)

T = TypeVar("T")


class Agent:
    """Fluent builder for agent operations.

    Provides a chainable API for configuring and executing agent operations.

    Example:
        >>> agent = Agent()
        >>> agent = agent.with_prompt("You are a code reviewer")
        >>> agent = agent.with_tools("Read", "Grep")
        >>> result = await agent.check("Does this follow PEP 8?")

        # Or chained:
        >>> result = await (Agent()
        ...     .with_prompt("You are a code reviewer")
        ...     .with_tools("Read", "Grep")
        ...     .check("Does this follow PEP 8?"))
    """

    __slots__ = ("_config", "_session")

    def __init__(
        self,
        config: AgentConfig | None = None,
        *,
        _session: _Session | None = None,
    ) -> None:
        """Initialize agent with optional configuration.

        Args:
            config: Initial configuration. Defaults to AgentConfig().
            _session: Internal — the session this Agent reports calls
                to. Set by `agent_context`; bare `Agent()` instances
                outside a context have no session and run unbounded.
        """
        self._config = config or AgentConfig()
        self._session = _session

    # Read-only session introspection

    @property
    def iterations(self) -> int:
        """Successful calls recorded against the active session, or 0."""
        return self._session.iterations if self._session is not None else 0

    @property
    def cost_usd(self) -> float:
        """Cumulative USD cost of recorded calls, or 0.0 outside a session."""
        return self._session.cost_usd if self._session is not None else 0.0

    @property
    def budget_remaining(self) -> float | None:
        """USD remaining before `BudgetExceededError`, or None if unbounded."""
        return self._session.budget_remaining if self._session is not None else None

    def log(self) -> tuple[CallRecord, ...]:
        """Return the session's CallRecord log in order, or () outside a session."""
        return self._session.log() if self._session is not None else ()

    def log_summary(self) -> str:
        """Return a multi-line text summary of the session log."""
        return (
            self._session.log_summary()
            if self._session is not None
            else "No active session."
        )

    def dump_log(self, path: str | Path) -> None:
        """Write the session log to `path` as a JSON array.

        Outside a session this writes an empty array, so calling code
        doesn't need to branch on session presence.
        """
        if self._session is not None:
            self._session.dump_log(path)
        else:
            Path(path).write_text("[]\n", encoding="utf-8")

    # Fluent configuration methods (return new instance for immutability)

    def with_prompt(self, prompt: str) -> Agent:
        """Set the system prompt.

        Args:
            prompt: The system prompt to use.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, system_prompt=prompt), _session=self._session)

    def with_append_prompt(self, prompt: str) -> Agent:
        """Append to the system prompt.

        Args:
            prompt: Text to append to the system prompt.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, append_prompt=prompt), _session=self._session)

    def with_tools(self, *tools: ToolSpec) -> Agent:
        """Limit available tools.

        Args:
            *tools: Tools to allow. Pass `Tool` enum members
                (e.g. `Tool.Read`, `Tool.Grep`); raw strings are
                accepted for custom or MCP tools.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, tools=tools), _session=self._session)

    def with_permission_mode(self, mode: PermissionMode) -> Agent:
        """Set permission mode.

        Args:
            mode: The permission mode to use.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, permission_mode=mode), _session=self._session)

    def with_model(self, model: str) -> Agent:
        """Set the model to use.

        Args:
            model: Model identifier (e.g., "claude-sonnet-4-20250514").

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, model=model), _session=self._session)

    def with_timeout(self, seconds: float) -> Agent:
        """Set operation timeout.

        Args:
            seconds: Timeout in seconds.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, timeout=seconds), _session=self._session)

    def in_directory(self, path: str) -> Agent:
        """Set working directory.

        Args:
            path: Path to the working directory.

        Returns:
            New Agent instance with updated config.
        """
        return Agent(replace(self._config, working_dir=path), _session=self._session)

    def with_memories(self, *memories: Memory) -> Agent:
        """Attach memory handles as context.

        Args:
            *memories: `Memory` handles returned by `memorize()`.

        Returns:
            New Agent instance with updated config.
        """
        existing = self._config.memories or ()
        return Agent(replace(self._config, memories=existing + memories), _session=self._session)

    # Operation methods

    async def check(self, question: str) -> bool:
        """Ask a yes/no question.

        Args:
            question: The yes/no question to ask.

        Returns:
            True or False based on the agent's response.
        """
        return await _check(question, config=self._config)

    async def do(self, instruction: str) -> AgentResult[str]:
        """Execute an action.

        Args:
            instruction: The instruction for the agent to execute.

        Returns:
            AgentResult containing the result and metadata.
        """
        return await _do(instruction, config=self._config)

    async def get(self, return_type: type[T], prompt: str) -> T:
        """Extract a typed value.

        Args:
            return_type: The expected return type.
            prompt: The question/prompt for extraction.

        Returns:
            Extracted value of type `return_type`.

        Example:
            >>> count = await agent.get(int, "How many functions?")
        """
        return await _TypedGet(return_type)(prompt, config=self._config)

    async def get_list(
        self,
        item_type: type[T],
        prompt: str,
        *,
        n: int | None = None,
    ) -> list[T]:
        """Extract a typed list.

        Args:
            item_type: The type of items in the list.
            prompt: The question/prompt for extraction.
            n: If set, require exactly `n` items.

        Returns:
            List of extracted values.

        Example:
            >>> items = await agent.get_list(str, "List all TODOs")
            >>> drafts = await agent.get_list(Draft, "Generate intros", n=8)
        """
        return await _TypedGetList(item_type)(prompt, n=n, config=self._config)

    async def get_int(self, question: str) -> int:
        """Get an integer.

        Args:
            question: The question to ask.

        Returns:
            Integer value.
        """
        return await _get_int(question, config=self._config)


@asynccontextmanager
async def agent_context(
    system_prompt: str | None = None,
    tools: list[ToolSpec] | None = None,
    permission_mode: PermissionMode = PermissionMode.DEFAULT,
    model: str | None = None,
    timeout: float = 300.0,
    working_dir: str | None = None,
    memories: list[Memory] | None = None,
    *,
    max_iterations: int | None = None,
    budget_usd: float | None = None,
    max_parallel: int | None = None,
    dry_run: bool = False,
    replay_from: str | Path | None = None,
    replay_on_miss: Literal["raise", "passthrough"] = "raise",
) -> AsyncIterator[Agent]:
    """Scoped agent session with optional budget, parallelism, and replay.

    Every `run_claude` call within this context (whether via the yielded
    `Agent` or via top-level `check`/`do`/`get` helpers) is reported to
    the session. The session enforces, after each successful call:

    - `max_iterations`: maximum number of successful calls before
      `IterationLimitError` is raised.
    - `budget_usd`: maximum cumulative cost in USD before
      `BudgetExceededError` is raised. The call that crosses the line
      still incurs its cost; that cost is reflected on the error.
    - `max_parallel`: caps concurrent in-flight calls via an
      `asyncio.Semaphore` (useful when fanning out with `asyncio.gather`).

    With `replay_from=<dump_log path>`, calls are matched against the
    loaded log by hash of their inputs (prompt, schema, tools, model,
    system prompt, permission mode, working dir, memory content
    hashes). On a hit, the cached result is returned without invoking
    the CLI but the session log still records the call (with the
    original cost), so budgets and iteration counts behave as they did
    in the original run. On a miss, `replay_on_miss="raise"` (default)
    raises `ReplayCacheMissError`; `"passthrough"` falls through to a
    live call.

    Args:
        system_prompt: System prompt for all operations.
        tools: Allowed tools for all operations.
        permission_mode: Permission mode for all operations.
        model: Model to use.
        timeout: Timeout for operations.
        working_dir: Working directory for operations.
        memories: Memory handles to include as context for every call.
        max_iterations: Cap on successful calls in this session.
        budget_usd: Cap on cumulative USD cost in this session.
        max_parallel: Cap on concurrent in-flight calls.
        dry_run: When True, force `PermissionMode.PLAN` (overriding
            `permission_mode`) and reject any tool from `MUTATING_TOOLS`
            in `tools`. Raw-string tool names pass through — gyre can't
            classify custom/MCP tools, so the caller is responsible for
            those.
        replay_from: Path to a JSON log produced by `dump_log`. When
            given, calls match against the log by content hash and
            return cached results without invoking the CLI.
        replay_on_miss: "raise" (default) raises `ReplayCacheMissError`
            on an unmatched call; "passthrough" falls through to a live
            call. Only consulted when `replay_from` is set.

    Yields:
        An `Agent` whose `iterations`, `cost_usd`, and `budget_remaining`
        properties reflect the current session state.

    Example:
        >>> async with agent_context(
        ...     tools=[Tool.Read, Tool.Grep],
        ...     max_iterations=20,
        ...     budget_usd=2.00,
        ...     max_parallel=4,
        ... ) as agent:
        ...     issues = await agent.get_list(str, "Find security issues")
        ...     print(f"used ${agent.cost_usd:.4f}")

        >>> # Pin a known-good run, iterate locally:
        >>> async with agent_context(replay_from="run.json") as agent:
        ...     ...  # all calls served from the log
    """
    if dry_run and tools:
        forbidden = [t for t in tools if isinstance(t, Tool) and t in MUTATING_TOOLS]
        if forbidden:
            names = ", ".join(t.value for t in forbidden)
            raise ValueError(
                f"dry_run=True forbids mutating tools: {names}. "
                f"Remove them or drop dry_run."
            )
    effective_permission_mode = PermissionMode.PLAN if dry_run else permission_mode
    config = AgentConfig(
        system_prompt=system_prompt,
        tools=tuple(tools) if tools else None,
        permission_mode=effective_permission_mode,
        model=model,
        timeout=timeout,
        working_dir=working_dir,
        memories=tuple(memories) if memories else None,
    )
    replay_cache = (
        _ReplayCache(load_log(replay_from)) if replay_from is not None else None
    )
    session = _Session(
        max_iterations=max_iterations,
        budget_usd=budget_usd,
        max_parallel=max_parallel,
        replay_cache=replay_cache,
        replay_on_miss=replay_on_miss,
    )
    token = _active_session.set(session)
    try:
        yield Agent(config, _session=session)
    finally:
        _active_session.reset(token)
