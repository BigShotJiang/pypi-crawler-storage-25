"""JSON schema generation from Python types."""

from __future__ import annotations

from typing import Any, get_args, get_origin

from pydantic import BaseModel


def type_to_json_schema(typ: type) -> dict[str, Any]:
    """Convert Python type to JSON Schema for Claude CLI.

    Supports:
    - Primitive types: str, int, float, bool
    - list[T] for any supported T
    - dict[str, T] for any supported T
    - Pydantic BaseModel subclasses

    Args:
        typ: The Python type to convert.

    Returns:
        JSON Schema dictionary.

    Raises:
        TypeError: If the type is not supported.
    """
    # Handle Pydantic models
    if isinstance(typ, type) and issubclass(typ, BaseModel):
        return typ.model_json_schema()

    # Handle primitive types
    type_map: dict[type, dict[str, Any]] = {
        str: {"type": "string"},
        int: {"type": "integer"},
        float: {"type": "number"},
        bool: {"type": "boolean"},
    }

    if typ in type_map:
        return type_map[typ]

    # Handle generic types (list[T], dict[str, T])
    origin = get_origin(typ)
    args = get_args(typ)

    # Handle list[T]
    if origin is list:
        if not args:
            return {"type": "array"}
        inner_type = args[0]
        return {"type": "array", "items": type_to_json_schema(inner_type)}

    # Handle dict[str, T]
    if origin is dict:
        if len(args) >= 2:
            value_type = args[1]
            return {
                "type": "object",
                "additionalProperties": type_to_json_schema(value_type),
            }
        return {"type": "object"}

    raise TypeError(f"Unsupported type for JSON schema: {typ}")


def wrap_for_extraction(schema: dict[str, Any], key: str = "value") -> dict[str, Any]:
    """Wrap schema in object for reliable extraction.

    Claude's structured output works best when wrapped in an object
    with a named key.

    Args:
        schema: The JSON schema to wrap.
        key: The key name to use (default: "value").

    Returns:
        Wrapped JSON schema.
    """
    return {
        "type": "object",
        "properties": {key: schema},
        "required": [key],
    }
