"""CLI for managing Gyre projects and scripts."""

from __future__ import annotations

import argparse
import asyncio
import importlib.util
import sys
from pathlib import Path

from gyre.types import Memory

PROJECTS_DIR = Path.home() / ".config" / "gyre" / "projects"

# Context files to auto-load from cwd
CONTEXT_FILES = ("CLAUDE.md", "AGENTS.md", "README.md")


def gather_context(directory: Path) -> list[Memory]:
    """Gather context from standard files in the directory.

    Returns:
        List of `Memory` handles, one per discovered context file.
    """
    from gyre.commands import memorize

    memories: list[Memory] = []
    for filename in CONTEXT_FILES:
        filepath = directory / filename
        if filepath.exists():
            content = filepath.read_text(encoding="utf-8")
            wrapped = f"# {filename}\n\n{content}"
            memories.append(memorize(wrapped, label=filename))
    return memories


def get_or_create_project(working_dir: Path) -> str:
    """Find existing project for working_dir or create one.

    Returns the project name.
    """
    import json

    # Search existing projects for matching working_dir
    if PROJECTS_DIR.exists():
        for project_dir in PROJECTS_DIR.iterdir():
            config_file = project_dir / "config.json"
            if config_file.exists():
                try:
                    config = json.loads(config_file.read_text())
                    if config.get("working_dir") == str(working_dir):
                        return project_dir.name
                except (json.JSONDecodeError, OSError):
                    continue

    # No existing project found - create one
    project_name = working_dir.name
    # Handle name conflicts by appending a number
    base_name = project_name
    counter = 1
    while (PROJECTS_DIR / project_name).exists():
        project_name = f"{base_name}-{counter}"
        counter += 1

    # Create project structure
    project_dir = PROJECTS_DIR / project_name
    project_dir.mkdir(parents=True)
    (project_dir / "scripts").mkdir()

    config = {"name": project_name, "working_dir": str(working_dir)}
    (project_dir / "config.json").write_text(json.dumps(config, indent=2) + "\n")

    return project_name


def run_prompt_sync(
    prompt: str,
    *,
    model: str | None = None,
    bypass: bool = False,
    background: bool = False,
) -> None:
    """Run a prompt with auto-gathered context from cwd."""
    import json
    import subprocess
    import tempfile

    cwd = Path.cwd()

    # Auto-create project for this working directory
    project_name = get_or_create_project(cwd)

    # Gather context files
    context_files = []
    for filename in CONTEXT_FILES:
        filepath = cwd / filename
        if filepath.exists():
            context_files.append(filename)

    # Build the prompt with context
    full_prompt = prompt
    if context_files:
        context_parts = []
        for filename in context_files:
            filepath = cwd / filename
            content = filepath.read_text(encoding="utf-8")
            context_parts.append(f"<context name=\"{filename}\">\n{content}\n</context>")
        full_prompt = "\n\n".join(context_parts) + "\n\n" + prompt

    # Build command - use streaming output format for interactive mode
    if background:
        cmd = ["claude", "-p", "--output-format", "json"]
    else:
        cmd = ["claude", "-p", "--verbose", "--output-format", "stream-json"]
    if model:
        cmd.extend(["--model", model])
    if bypass:
        cmd.extend(["--permission-mode", "bypassPermissions"])
    cmd.append(full_prompt)

    # Show startup feedback
    model_name = model or "sonnet"
    context_info = f" with {', '.join(context_files)}" if context_files else ""

    if background:
        # Background mode: spawn detached process with output to file
        output_dir = Path(tempfile.gettempdir()) / "gyre"
        output_dir.mkdir(exist_ok=True)

        # Generate unique output file
        import time
        timestamp = int(time.time())
        output_file = output_dir / f"task_{timestamp}.json"

        sys.stderr.write(f"⚡ [{project_name}] background task ({model_name}){context_info}\n")
        sys.stderr.write(f"   {cwd}\n")
        sys.stderr.write(f"   Output: {output_file}\n")
        sys.stderr.write(f"   Prompt: {prompt[:60]}{'...' if len(prompt) > 60 else ''}\n\n")
        sys.stderr.flush()

        # Spawn detached process
        with open(output_file, "w") as outf:
            subprocess.Popen(
                cmd,
                cwd=cwd,
                stdout=outf,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )

        sys.stderr.write(f"✓ Task started in background. Check {output_file} for results.\n")
        sys.stderr.flush()
        return

    # Interactive streaming mode
    sys.stderr.write(f"⚡ [{project_name}] ({model_name}){context_info}\n")
    sys.stderr.write(f"   {cwd}\n")
    sys.stderr.write("─" * 60 + "\n")
    sys.stderr.flush()

    # Run Claude process with streaming output
    try:
        process = subprocess.Popen(
            cmd,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        final_result = None
        total_cost = 0.0
        duration_ms = 0

        # Stream output in real-time
        streamed_content = False
        if process.stdout:
            for line in process.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    msg_type = data.get("type", "")

                    if msg_type == "assistant":
                        # Assistant message with content blocks
                        content_blocks = data.get("message", {}).get("content", [])
                        for block in content_blocks:
                            if block.get("type") == "text":
                                text = block.get("text", "")
                                if text:
                                    sys.stdout.write(text)
                                    sys.stdout.flush()
                                    streamed_content = True
                    elif msg_type == "result":
                        # Final result with metadata
                        final_result = data.get("result", "")
                        total_cost = data.get("total_cost_usd", 0.0)
                        duration_ms = data.get("duration_ms", 0)
                        # Print final result only if we haven't streamed anything
                        if final_result and not streamed_content:
                            print(final_result)
                except json.JSONDecodeError:
                    # Not JSON, print as-is
                    print(line)

        process.wait()

        if process.returncode != 0:
            stderr_output = process.stderr.read() if process.stderr else ""
            sys.stderr.write(f"\nError: {stderr_output}\n")
            sys.exit(1)

        # Show summary
        sys.stderr.write("\n" + "─" * 60 + "\n")
        total_seconds = duration_ms // 1000
        minutes, seconds = divmod(total_seconds, 60)
        duration_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"
        sys.stderr.write(f"✓ Done [{duration_str} | ${total_cost:.4f}]\n")
        sys.stderr.flush()

    except KeyboardInterrupt:
        sys.stderr.write("\n\n⚠ Interrupted.\n")
        sys.exit(1)
    except FileNotFoundError:
        sys.stderr.write("Error: 'claude' CLI not found. Install it first.\n")
        sys.exit(1)


def get_projects() -> list[str]:
    """Return list of available project names."""
    if not PROJECTS_DIR.exists():
        return []
    return [p.name for p in PROJECTS_DIR.iterdir() if p.is_dir() and (p / "config.json").exists()]


def get_scripts(project: str) -> list[str]:
    """Return list of script names for a project."""
    scripts_dir = PROJECTS_DIR / project / "scripts"
    if not scripts_dir.exists():
        return []
    return [s.stem for s in scripts_dir.glob("*.py")]


def list_projects() -> None:
    """List all available projects."""
    projects = get_projects()
    if not projects:
        print("No projects found.")
        return
    print("Available projects:")
    for p in sorted(projects):
        scripts = get_scripts(p)
        print(f"  {p} ({len(scripts)} scripts)")


def list_scripts(project: str) -> None:
    """List all scripts for a project."""
    scripts = get_scripts(project)
    if not scripts:
        print(f"No scripts found for project '{project}'.")
        return
    print(f"Scripts for '{project}':")
    for s in sorted(scripts):
        print(f"  {s}")


def run_script(project: str, script: str) -> None:
    """Run a script from a project."""
    script_path = PROJECTS_DIR / project / "scripts" / f"{script}.py"
    if not script_path.exists():
        print(f"Script not found: {script_path}")
        sys.exit(1)

    spec = importlib.util.spec_from_file_location(script, script_path)
    if spec is None or spec.loader is None:
        print(f"Failed to load script: {script_path}")
        sys.exit(1)

    module = importlib.util.module_from_spec(spec)
    sys.modules[script] = module
    spec.loader.exec_module(module)

    if hasattr(module, "main"):
        result = module.main()
        if asyncio.iscoroutine(result):
            asyncio.run(result)
    else:
        print(f"Script '{script}' has no main() function.")
        sys.exit(1)


def create_project(name: str, working_dir: Path | None = None) -> None:
    """Create a new gyre project."""
    import json

    project_dir = PROJECTS_DIR / name
    if project_dir.exists():
        print(f"Project '{name}' already exists.")
        sys.exit(1)

    # Create project structure
    project_dir.mkdir(parents=True)
    scripts_dir = project_dir / "scripts"
    scripts_dir.mkdir()

    # Create config.json
    config = {
        "name": name,
        "working_dir": str(working_dir or Path.cwd()),
    }
    config_path = project_dir / "config.json"
    config_path.write_text(json.dumps(config, indent=2) + "\n")

    print(f"✓ Created project '{name}' at {project_dir}")
    print(f"  Working directory: {config['working_dir']}")
    print(f"  Add scripts to: {scripts_dir}/")


def create_script(project: str, script_name: str, description: str = "") -> None:
    """Create a new script in a project."""
    project_dir = PROJECTS_DIR / project
    if not project_dir.exists():
        print(f"Project '{project}' does not exist. Create it first with: gyre create {project}")
        sys.exit(1)

    scripts_dir = project_dir / "scripts"
    script_path = scripts_dir / f"{script_name}.py"

    if script_path.exists():
        print(f"Script '{script_name}' already exists in project '{project}'.")
        sys.exit(1)

    # Create a template script
    template = f'''"""{description or f"Script: {script_name}"}"""

import asyncio

from gyre import Tool, do


async def main() -> None:
    result = await do(
        "Your prompt here",
        tools=[Tool.Read, Tool.Edit],
    )

    print(result)


if __name__ == "__main__":
    asyncio.run(main())
'''
    script_path.write_text(template)

    print(f"✓ Created script '{script_name}' in project '{project}'")
    print(f"  Path: {script_path}")
    print(f"  Run with: gyre run {project} {script_name}")


def main() -> None:
    """Main CLI entry point."""
    # Check if first arg is a subcommand
    subcommands = {"list", "run", "create", "new"}
    if len(sys.argv) > 1 and sys.argv[1] in subcommands:
        _run_subcommand()
    else:
        _run_prompt_mode()


def _run_prompt_mode() -> None:
    """Handle direct prompt execution."""
    parser = argparse.ArgumentParser(
        prog="gyre",
        description="Run Claude agents with automatic context from CLAUDE.md, AGENTS.md, README.md",
        epilog="Subcommands: gyre list [project], gyre run <project> <script>",
    )
    parser.add_argument(
        "prompt",
        nargs="?",
        help="Prompt to execute (auto-loads context from cwd)",
    )
    parser.add_argument(
        "-m", "--model",
        choices=["opus", "sonnet", "haiku"],
        help="Model to use (default: sonnet)",
    )
    parser.add_argument(
        "-y", "--yes",
        action="store_true",
        help="Bypass permission prompts (auto-accept all)",
    )
    parser.add_argument(
        "-b", "--background",
        action="store_true",
        help="Run in background (output saved to file)",
    )

    args = parser.parse_args()

    if args.prompt:
        run_prompt_sync(args.prompt, model=args.model, bypass=args.yes, background=args.background)
    else:
        parser.print_help()


def _run_subcommand() -> None:
    """Handle subcommands (list, run, create)."""
    parser = argparse.ArgumentParser(prog="gyre")
    subparsers = parser.add_subparsers(dest="command")

    # list command
    list_parser = subparsers.add_parser("list", help="List projects or scripts")
    list_parser.add_argument("project", nargs="?", help="Project name (omit to list all projects)")

    # run command
    run_parser = subparsers.add_parser("run", help="Run a project script")
    run_parser.add_argument("project", help="Project name")
    run_parser.add_argument("script", help="Script name")

    # create/new command (aliases)
    for cmd in ("create", "new"):
        create_parser = subparsers.add_parser(cmd, help="Create a project or script")
        create_parser.add_argument("project", help="Project name")
        create_parser.add_argument(
            "script", nargs="?", help="Script name (creates script in project)"
        )
        create_parser.add_argument(
            "-d", "--description", default="", help="Script description"
        )
        create_parser.add_argument(
            "-w", "--working-dir", type=Path, help="Project working directory"
        )

    args = parser.parse_args()

    if args.command == "list":
        if args.project:
            list_scripts(args.project)
        else:
            list_projects()
    elif args.command == "run":
        run_script(args.project, args.script)
    elif args.command in ("create", "new"):
        if args.script:
            # Create a script in an existing project
            create_script(args.project, args.script, args.description)
        else:
            # Create a new project
            create_project(args.project, args.working_dir)


if __name__ == "__main__":
    main()
