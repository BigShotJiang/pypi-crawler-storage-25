"""Custom exceptions for Gyre."""

from __future__ import annotations

from typing import Any


class GyreError(Exception):
    """Base exception for Gyre."""

    pass


class AgentTimeoutError(GyreError):
    """Agent operation timed out."""

    def __init__(self, timeout: float, operation: str) -> None:
        self.timeout = timeout
        self.operation = operation
        super().__init__(f"{operation} timed out after {timeout}s")


class AgentExecutionError(GyreError):
    """Agent failed to execute operation."""

    def __init__(self, message: str, stderr: str | None = None) -> None:
        self.stderr = stderr
        full_message = message
        if stderr:
            full_message = f"{message}\nstderr: {stderr}"
        super().__init__(full_message)


class TypeExtractionError(GyreError):
    """Failed to extract typed value from response."""

    def __init__(self, expected_type: type, raw_response: dict[str, Any]) -> None:
        self.expected_type = expected_type
        self.raw_response = raw_response
        super().__init__(f"Failed to extract {expected_type.__name__} from response")


class SchemaValidationError(GyreError):
    """Response did not match expected JSON schema."""

    def __init__(self, message: str, schema: dict[str, Any] | None = None) -> None:
        self.schema = schema
        super().__init__(message)


class BudgetExceededError(GyreError):
    """Session cumulative cost exceeded the configured budget.

    Raised after the call that pushed the running total over the limit.
    The cost-incurring call still completed; its cost is included in
    `cost_usd`. The result of that call is not returned to the caller —
    use the session log (Phase 4) to recover it if needed.
    """

    def __init__(self, cost_usd: float, budget_usd: float) -> None:
        self.cost_usd = cost_usd
        self.budget_usd = budget_usd
        super().__init__(
            f"Session cost ${cost_usd:.4f} exceeded budget ${budget_usd:.4f}"
        )


class IterationLimitError(GyreError):
    """Session call count exceeded the configured iteration limit.

    Raised after the call that pushed the count past the limit.
    """

    def __init__(self, iterations: int, max_iterations: int) -> None:
        self.iterations = iterations
        self.max_iterations = max_iterations
        super().__init__(
            f"Session reached iteration limit: "
            f"{iterations} > max_iterations={max_iterations}"
        )


class MissingToolScopeError(GyreError):
    """`do()` was called without an explicit tool scope.

    `do()` can mutate the filesystem or shell state, so gyre refuses to
    run it unless the caller has visibly committed to a tool list —
    either via the `tools=` kwarg or by being inside an `agent_context`
    / `Agent` configured with tools. This makes side-effect potential
    locally readable at the call site.
    """

    def __init__(self) -> None:
        super().__init__(
            "do() requires an explicit tool scope. Pass tools=[...] at "
            "the call site, or call it inside an agent_context / on an "
            "Agent configured with .with_tools(...)."
        )


class ReplayCacheMissError(GyreError):
    """During replay, a live call did not match any logged record.

    Raised when `agent_context(replay_from=...)` is active and the
    current call's inputs (prompt, schema, tools, model, system prompt,
    permission mode, working dir, and memory content hashes) do not
    correspond to any record in the loaded log. Pass
    `replay_on_miss="passthrough"` to fall through to a live call
    instead.
    """

    def __init__(self, *, kind: str, prompt: str, key: str) -> None:
        self.kind = kind
        self.prompt = prompt
        self.key = key
        prompt_short = prompt if len(prompt) <= 80 else prompt[:79] + "…"
        super().__init__(
            f"Replay cache miss: kind={kind!r} prompt={prompt_short!r} "
            f"(key={key[:12]}…). Pass replay_on_miss='passthrough' to fall "
            f"through to a live call."
        )
