"""Gyre - Elegant Python API for Claude CLI agents.

Simple usage:
    >>> from gyre import check, do, get, get_list, get_int
    >>>
    >>> # Yes/no question
    >>> if await check("Is this Python file valid?"):
    ...     await do("Format the file using black")
    >>>
    >>> # Typed extraction
    >>> count = await get[int]("How many functions?")
    >>> items = await get_list[str]("List all to-do comments")

Fluent builder:
    >>> from gyre import Agent
    >>>
    >>> agent = (Agent()
    ...     .with_prompt("You are a code reviewer")
    ...     .with_tools("Read", "Grep"))
    >>> result = await agent.check("Does this follow PEP 8?")

Context manager:
    >>> from gyre import agent_context
    >>>
    >>> async with agent_context(system_prompt="Security auditor") as agent:
    ...     issues = await agent.get_list(str, "Find vulnerabilities")
"""

from gyre.agent import Agent, agent_context
from gyre.commands import check, do, get, get_int, get_list, memorize
from gyre.errors import (
    AgentExecutionError,
    AgentTimeoutError,
    BudgetExceededError,
    GyreError,
    IterationLimitError,
    MissingToolScopeError,
    ReplayCacheMissError,
    SchemaValidationError,
    TypeExtractionError,
)
from gyre.session import CallRecord, load_log
from gyre.types import (
    MUTATING_TOOLS,
    AgentConfig,
    AgentResult,
    Memory,
    PermissionMode,
    Tool,
    ToolSpec,
)

__all__ = [
    # Core classes
    "Agent",
    "AgentConfig",
    "AgentResult",
    "CallRecord",
    "Memory",
    "PermissionMode",
    "Tool",
    "ToolSpec",
    "MUTATING_TOOLS",
    # Context manager
    "agent_context",
    # Direct functions
    "check",
    "do",
    "get",
    "get_list",
    "get_int",
    "memorize",
    "load_log",
    # Errors
    "GyreError",
    "AgentTimeoutError",
    "AgentExecutionError",
    "TypeExtractionError",
    "SchemaValidationError",
    "BudgetExceededError",
    "IterationLimitError",
    "MissingToolScopeError",
    "ReplayCacheMissError",
]

__version__ = "0.1.0"
