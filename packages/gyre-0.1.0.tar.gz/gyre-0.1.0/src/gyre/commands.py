"""Core commands for Gyre: check, do, get, get_int, get_list, memorize."""

from __future__ import annotations

import os
import tempfile
import uuid
from pathlib import Path
from typing import Any, Generic, TypeVar, cast

from gyre.errors import MissingToolScopeError, TypeExtractionError
from gyre.schemas import type_to_json_schema, wrap_for_extraction
from gyre.subprocess import run_claude
from gyre.types import AgentConfig, AgentResult, Memory, ToolSpec

T = TypeVar("T")


def _merge_memories(
    config_memories: tuple[Memory, ...] | None,
    arg_memories: tuple[Memory, ...] | list[Memory] | None,
) -> tuple[Memory, ...] | None:
    """Merge memories from config and argument into a single tuple."""
    if config_memories is None and arg_memories is None:
        return None
    result: list[Memory] = []
    if config_memories:
        result.extend(config_memories)
    if arg_memories:
        result.extend(arg_memories)
    return tuple(result) if result else None


def memorize(
    content: str,
    *,
    label: str | None = None,
    path: str | Path | None = None,
    directory: str | Path | None = None,
) -> Memory:
    """Store information in a local file and return a `Memory` handle.

    The returned handle can be passed to any operation via the
    `memories=[...]` parameter. The file's content is re-read on every
    call that uses the memory, wrapped in a `<context label="...">` tag,
    and appended to the prompt.

    Args:
        content: The information to remember.
        label: Human-readable label used in the `<context label="...">`
            tag. Defaults to a generated `"memory_<hex>"` identifier.
        path: Exact filesystem path to write to. Use this for memories
            you want under version control. Parent directories are
            created if missing. Mutually exclusive with `directory`.
        directory: Directory to store a gyre-named memory file in.
            Mutually exclusive with `path`. If neither `path` nor
            `directory` is given, writes to the system temp directory.

    Returns:
        A `Memory` handle.

    Example:
        >>> voice = memorize("Brand voice: terse, no fluff", label="voice")
        >>> await do("Draft an intro", memories=[voice], tools=[...])

        >>> # Under version control:
        >>> voice = memorize(
        ...     "Brand voice: terse",
        ...     label="voice",
        ...     path="memories/voice.md",
        ... )
    """
    if path is not None and directory is not None:
        raise ValueError("Pass either `path` or `directory`, not both.")

    suffix_hex = uuid.uuid4().hex[:8]
    resolved_label = label if label is not None else f"memory_{suffix_hex}"

    resolved_path: Path
    if path is not None:
        resolved_path = Path(path)
        resolved_path.parent.mkdir(parents=True, exist_ok=True)
        resolved_path.write_text(content, encoding="utf-8")
    elif directory is not None:
        dir_path = Path(directory)
        dir_path.mkdir(parents=True, exist_ok=True)
        resolved_path = dir_path / f"memory_{suffix_hex}.txt"
        resolved_path.write_text(content, encoding="utf-8")
    else:
        fd, temp_path = tempfile.mkstemp(suffix=".txt", prefix="gyre_memory_")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        resolved_path = Path(temp_path)

    return Memory(label=resolved_label, path=resolved_path)


async def check(
    question: str,
    *,
    config: AgentConfig | None = None,
    memories: tuple[Memory, ...] | list[Memory] | None = None,
) -> bool:
    """Ask agent a yes/no question.

    Args:
        question: The yes/no question to ask.
        config: Optional agent configuration.
        memories: Memory handles to include as context.

    Returns:
        True or False based on the agent's response.

    Example:
        >>> if await check("Is this Python file syntactically valid?"):
        ...     print("Valid!")
    """
    config = config or AgentConfig()
    all_memories = _merge_memories(config.memories, memories)

    schema = {
        "type": "object",
        "properties": {"answer": {"type": "boolean"}},
        "required": ["answer"],
    }

    json_hint = 'Respond with JSON: {"answer": true} or {"answer": false}'
    enhanced_prompt = f"{question}\n\n{json_hint}"

    response = await run_claude(
        enhanced_prompt,
        system_prompt=config.system_prompt,
        append_prompt=config.append_prompt,
        tools=config.tools,
        permission_mode=config.permission_mode.value,
        json_schema=schema,
        model=config.model,
        working_dir=config.working_dir,
        timeout=config.timeout,
        memories=all_memories,
        kind="check",
        type_name="bool",
    )

    if response.structured_output and "answer" in response.structured_output:
        return bool(response.structured_output["answer"])

    raise TypeExtractionError(bool, response.raw)


async def do(
    instruction: str,
    *,
    tools: tuple[ToolSpec, ...] | list[ToolSpec] | None = None,
    config: AgentConfig | None = None,
    memories: tuple[Memory, ...] | list[Memory] | None = None,
) -> AgentResult[str]:
    """Execute an action and wait for completion.

    `do()` can mutate the filesystem or shell state, so it requires an
    explicit tool scope: pass `tools=[...]` here, or call it inside an
    `agent_context` / on an `Agent` configured with `.with_tools(...)`.
    Without a visible tool list, `MissingToolScopeError` is raised
    before any subprocess call. See `MissingToolScopeError` for the
    rationale.

    Args:
        instruction: The instruction for the agent to execute.
        tools: Tools allowed for this call. Overrides `config.tools` if
            both are given. Required if neither is set.
        config: Optional agent configuration.
        memories: Memory handles to include as context.

    Returns:
        AgentResult containing the result and metadata.

    Raises:
        MissingToolScopeError: If no tool list is in scope.

    Example:
        >>> result = await do(
        ...     "Refactor the calculate function",
        ...     tools=[Tool.Read, Tool.Edit],
        ... )
        >>> print(f"Done in {result.duration_formatted}")
    """
    config = config or AgentConfig()
    effective_tools: tuple[ToolSpec, ...] | None = (
        tuple(tools) if tools is not None else config.tools
    )
    if effective_tools is None:
        raise MissingToolScopeError()

    all_memories = _merge_memories(config.memories, memories)

    response = await run_claude(
        instruction,
        system_prompt=config.system_prompt,
        append_prompt=config.append_prompt,
        tools=effective_tools,
        permission_mode=config.permission_mode.value,
        model=config.model,
        working_dir=config.working_dir,
        timeout=config.timeout,
        memories=all_memories,
        kind="do",
    )

    return AgentResult(
        value=response.result,
        session_id=response.session_id,
        duration_ms=response.duration_ms,
        cost_usd=response.cost_usd,
        raw_response=response.raw,
    )


class _TypedGet(Generic[T]):
    """Bound typed getter for a specific type."""

    __slots__ = ("_value_type",)

    def __init__(self, value_type: type[T]) -> None:
        self._value_type = value_type

    async def __call__(
        self,
        prompt: str,
        *,
        config: AgentConfig | None = None,
        memories: tuple[Memory, ...] | list[Memory] | None = None,
    ) -> T:
        """Execute the typed extraction.

        Args:
            prompt: The question/prompt for extraction.
            config: Optional agent configuration.
            memories: Memory handles to include as context.

        Returns:
            Extracted value of type T.
        """
        config = config or AgentConfig()
        all_memories = _merge_memories(config.memories, memories)

        schema = wrap_for_extraction(type_to_json_schema(self._value_type))

        enhanced_prompt = f"{prompt}\n\nRespond with a JSON object containing a 'value' field."

        response = await run_claude(
            enhanced_prompt,
            system_prompt=config.system_prompt,
            append_prompt=config.append_prompt,
            tools=config.tools,
            permission_mode=config.permission_mode.value,
            json_schema=schema,
            model=config.model,
            working_dir=config.working_dir,
            timeout=config.timeout,
            memories=all_memories,
            kind="get",
            type_name=self._value_type.__name__,
        )

        if response.structured_output and "value" in response.structured_output:
            return self._parse_value(response.structured_output["value"])

        raise TypeExtractionError(self._value_type, response.raw)

    def _parse_value(self, value: Any) -> T:
        """Parse and validate the extracted value."""
        from pydantic import BaseModel

        # If it's a Pydantic model, construct it
        if isinstance(self._value_type, type) and issubclass(self._value_type, BaseModel):
            return cast(T, self._value_type.model_validate(value))  # type: ignore[redundant-cast]

        # For primitives, return as-is (already validated by JSON schema)
        return cast(T, value)


class _Get:
    """Generic typed value extraction.

    Enables subscript syntax: get[int]("question")
    """

    def __class_getitem__(cls, item: type[T]) -> _TypedGet[T]:
        """Enable get[Type] syntax."""
        return _TypedGet(item)


# Export for subscript syntax: get[int]("question")
get = _Get


def _build_list_schema(item_type: type, n: int | None) -> dict[str, Any]:
    """Build the JSON schema for a `get_list` extraction.

    Wraps `type_to_json_schema(item_type)` in an `items` array. When `n`
    is given, constrains the array to exactly `n` elements via
    `minItems`/`maxItems`.
    """
    items_schema: dict[str, Any] = {
        "type": "array",
        "items": type_to_json_schema(item_type),
    }
    if n is not None:
        items_schema["minItems"] = n
        items_schema["maxItems"] = n
    return {
        "type": "object",
        "properties": {"items": items_schema},
        "required": ["items"],
    }


class _TypedGetList(Generic[T]):
    """Bound typed list getter for a specific item type."""

    __slots__ = ("_item_type",)

    def __init__(self, item_type: type[T]) -> None:
        self._item_type = item_type

    async def __call__(
        self,
        prompt: str,
        *,
        n: int | None = None,
        config: AgentConfig | None = None,
        memories: tuple[Memory, ...] | list[Memory] | None = None,
    ) -> list[T]:
        """Execute the typed list extraction.

        Args:
            prompt: The question/prompt for extraction.
            n: If set, require exactly `n` items. Enforced via the JSON
                schema (`minItems` and `maxItems`) and surfaced in the
                prompt so the model knows the target count.
            config: Optional agent configuration.
            memories: Memory handles to include as context.

        Returns:
            List of extracted values.
        """
        if n is not None and n < 0:
            raise ValueError(f"n must be non-negative, got {n}")

        config = config or AgentConfig()
        all_memories = _merge_memories(config.memories, memories)

        schema = _build_list_schema(self._item_type, n)

        count_hint = f" of exactly {n} items" if n is not None else ""
        enhanced_prompt = (
            f"{prompt}\n\n"
            f"Respond with a JSON object containing an 'items' array{count_hint}."
        )

        response = await run_claude(
            enhanced_prompt,
            system_prompt=config.system_prompt,
            append_prompt=config.append_prompt,
            tools=config.tools,
            permission_mode=config.permission_mode.value,
            json_schema=schema,
            model=config.model,
            working_dir=config.working_dir,
            timeout=config.timeout,
            memories=all_memories,
            kind="get_list",
            type_name=self._item_type.__name__,
        )

        if response.structured_output and "items" in response.structured_output:
            return self._parse_items(response.structured_output["items"])

        raise TypeExtractionError(list, response.raw)

    def _parse_items(self, items: list[Any]) -> list[T]:
        """Parse and validate the extracted items."""
        from pydantic import BaseModel

        # If it's a Pydantic model, construct each item
        if isinstance(self._item_type, type) and issubclass(self._item_type, BaseModel):
            return [cast(T, self._item_type.model_validate(item)) for item in items]  # type: ignore[redundant-cast]

        # For primitives, return as-is
        return cast(list[T], items)


class _GetList:
    """Generic typed list extraction.

    Enables subscript syntax: get_list[str]("question")
    """

    def __class_getitem__(cls, item: type[T]) -> _TypedGetList[T]:
        """Enable get_list[Type] syntax."""
        return _TypedGetList(item)


# Export for subscript syntax: get_list[str]("question")
get_list = _GetList


async def get_int(
    question: str,
    *,
    config: AgentConfig | None = None,
    memories: tuple[Memory, ...] | list[Memory] | None = None,
) -> int:
    """Get an integer from the agent.

    Shorthand for get[int](question).

    Args:
        question: The question to ask.
        config: Optional agent configuration.
        memories: Memory handles to include as context.

    Returns:
        Integer value.

    Example:
        >>> count = await get_int("How many functions are in main.py?")
    """
    return await _TypedGet(int)(question, config=config, memories=memories)
