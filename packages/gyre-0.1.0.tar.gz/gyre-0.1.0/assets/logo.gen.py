#!/usr/bin/env python3
"""Procedural baseline for the gyre monogram logo.

Emits to stdout the procedural starting point of the logo: a capital G
whose inner crossbar is a logarithmic spiral. The shipped `logo.svg`
sits one Inkscape pass on top of this baseline (a small affine tweak
to the spiral and accent dot); rerun this script if you want to start
from the math again.

Usage:
    python3 assets/logo.gen.py > /tmp/baseline.svg
"""
from __future__ import annotations

import math
import sys

SLATE = "#1f2937"
ACCENT = "#ef6c4a"


def log_spiral_points(
    cx: float, cy: float, a: float, b: float,
    theta_start: float, theta_end: float,
    steps: int = 380, direction: int = -1,
) -> list[tuple[float, float]]:
    """Logarithmic spiral r = a * exp(b*theta). direction=+1 ccw, -1 cw."""
    pts: list[tuple[float, float]] = []
    for i in range(steps + 1):
        t = theta_start + (theta_end - theta_start) * (i / steps)
        r = a * math.exp(b * t)
        x = cx + r * math.cos(direction * t)
        y = cy + r * math.sin(direction * t)
        pts.append((x, y))
    return pts


def main() -> None:
    vb = 200
    cx = cy = vb / 2
    cap = 130       # cap height
    stem = 12       # ~9% of cap, medium-bold weight
    r_outer = cap / 2

    # G outer arc with a notch on the right (opening between -25° and +25°).
    top_open = math.radians(-25)
    bot_open = math.radians(25)
    p_top = (cx + r_outer * math.cos(top_open), cy + r_outer * math.sin(top_open))
    p_bot = (cx + r_outer * math.cos(bot_open), cy + r_outer * math.sin(bot_open))
    g_outer = (
        f'<path d="M {p_top[0]:.2f} {p_top[1]:.2f} '
        f'A {r_outer:.2f} {r_outer:.2f} 0 1 0 {p_bot[0]:.2f} {p_bot[1]:.2f}" '
        f'fill="none" stroke="{SLATE}" stroke-width="{stem}" stroke-linecap="round"/>'
    )

    # Right shelf — short vertical from the bottom of the opening to mid-line.
    shelf_top = (p_bot[0], cy + 2)
    shelf = (
        f'<line x1="{p_bot[0]:.2f}" y1="{p_bot[1]:.2f}" '
        f'x2="{shelf_top[0]:.2f}" y2="{shelf_top[1]:.2f}" '
        f'stroke="{SLATE}" stroke-width="{stem}" stroke-linecap="round"/>'
    )

    # Spiral. For r = a·exp(b·θ) with direction=-1, the tangent is
    # horizontal-left at θ = atan(-1/b); b=-0.30 keeps the spiral inside the
    # G interior after that rotation.
    a, b = 32.0, -0.30
    theta_start = math.atan(-1.0 / b)
    spiral_pts = log_spiral_points(
        cx, cy, a, b,
        theta_start=theta_start,
        theta_end=theta_start + 5.0 * math.pi,
    )
    anchor = (shelf_top[0] - stem / 2 - 1, shelf_top[1])
    dx = anchor[0] - spiral_pts[0][0]
    dy = anchor[1] - spiral_pts[0][1]
    spiral_pts = [(x + dx, y + dy) for x, y in spiral_pts]
    points = " ".join(f"{x:.2f},{y:.2f}" for x, y in spiral_pts)
    spiral = (
        f'<polyline points="{points}" fill="none" stroke="{SLATE}" '
        f'stroke-width="{stem * 0.55}" stroke-linecap="round" stroke-linejoin="round"/>'
    )

    end_x, end_y = spiral_pts[-1]
    accent = f'<circle cx="{end_x:.2f}" cy="{end_y:.2f}" r="4.5" fill="{ACCENT}"/>'

    sys.stdout.write(
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vb} {vb}" '
        f'width="{vb}" height="{vb}">\n'
        f'  {g_outer}\n  {shelf}\n  {spiral}\n  {accent}\n'
        f'</svg>\n'
    )


if __name__ == "__main__":
    main()
