# Changelog

All notable changes to this project are documented here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and
the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-05-02

Initial public release.

### Added

- Core primitives: `check`, `do`, `get[T]`, `get_list[T]`, `get_int`.
- `agent_context` with `budget_usd`, `max_iterations`, `max_parallel`,
  and `dry_run`. Limits are checked after each call; the call that
  crosses still records its cost.
- `Memory` handles via `memorize()`. `path=` for versioned memories
  under your repo, `directory=` for gyre-named files in a chosen dir,
  default temp file otherwise. Re-read on every call.
- `Tool` enum, `MUTATING_TOOLS`, and `MissingToolScopeError` —
  `do()` refuses to run without an explicit tool scope.
- Session log: every call records a `CallRecord`. `Agent.dump_log`,
  `Agent.log()`, `Agent.log_summary()`.
- Hash-cache replay: `agent_context(replay_from=path)` matches calls
  by sha256 of the full call signature (prompt, schema, tools, model,
  system prompt, permission mode, working dir, memory content
  hashes). FIFO duplicate bucketing for parallel fanouts. Default
  miss policy raises `ReplayCacheMissError`; pass
  `replay_on_miss="passthrough"` to fall through to a live call.
- `load_log(path) -> tuple[CallRecord, ...]` lower-level primitive.
- CLI: `gyre "<prompt>"` (direct execution with auto-loaded
  `CLAUDE.md` / `AGENTS.md` / `README.md` context, `--model`, `-y`,
  `-b`), `gyre list [project]`, `gyre run <project> <script>`,
  `gyre create|new <project> [<script>]`.
