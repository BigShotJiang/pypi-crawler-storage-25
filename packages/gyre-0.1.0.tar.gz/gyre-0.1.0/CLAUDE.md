# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Test Commands

```bash
uv sync --all-extras      # Install dependencies
uv run pytest -v          # Run all tests
uv run pytest tests/test_commands.py::TestSchemas::test_primitive_types  # Run single test
uv run mypy src/gyre --strict   # Type check
uv run ruff check src/gyre      # Lint
uv run ruff check src/gyre --fix  # Auto-fix lint issues
```

## Architecture

Gyre is a Python library for orchestrating Claude CLI agents with strong typing and asyncio support.

**Core execution flow:**
1. User calls a command (`check`, `do`, `get[T]`, `get_list[T]`)
2. `commands.py` builds a JSON schema from the Python type via `schemas.py`
3. `subprocess.py` spawns `claude -p --output-format json --json-schema <schema>` and parses the response
4. Structured output is extracted and converted back to the requested Python type

**Key modules:**
- `subprocess.py` - Claude CLI process management with model-based timeouts (Opus: 30min, Sonnet: 20min, Haiku: 10min)
- `schemas.py` - Converts Python types (primitives, `list[T]`, `dict[str, T]`, Pydantic models) to JSON Schema
- `commands.py` - User-facing commands: `check`, `do`, `get[T]`, `get_list[T]`, `get_int`, `memorize`
- `agent.py` - Fluent builder (`Agent().with_prompt().with_tools()`) and `agent_context()` context manager
- `types.py` - `AgentConfig` (immutable, frozen dataclass), `AgentResult[T]`, `PermissionMode` enum
- `errors.py` - Exception hierarchy: `GyreError` base, plus `AgentTimeoutError`, `AgentExecutionError`, `TypeExtractionError`, `SchemaValidationError`
- `cli.py` - CLI entry point. `gyre "<prompt>"` runs a one-shot prompt with auto-loaded context from `CLAUDE.md` / `AGENTS.md` / `README.md` in the cwd (flags: `-m {opus,sonnet,haiku}`, `-y` to bypass permissions, `-b` for background mode writing JSON to `$TMPDIR/gyre/`). Subcommands: `gyre list [project]`, `gyre run <project> <script>`, `gyre create|new <project> [<script>]`. Projects live in `~/.config/gyre/projects/`.

**Generic type pattern:**
The `get[T]` and `get_list[T]` subscript syntax uses `__class_getitem__` to return typed callable instances (`_TypedGet[T]`, `_TypedGetList[T]`).

**Immutability:**
`AgentConfig` and `Agent` use immutable patterns - fluent methods return new instances via `dataclasses.replace()`.

**Memory system:**
The `memorize()` function stores context in temp files that can be passed to commands via the `memories` parameter. Memory content is wrapped in `<context>` tags and appended to prompts in `subprocess.py`.
