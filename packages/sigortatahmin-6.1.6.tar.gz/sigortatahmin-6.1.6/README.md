# 🛡️ SigortaTahmin - Aktüeryal Hesaplama Motoru v0.6.2

Otomobiller için teknik trafik sigortası prim hesaplaması yapan profesyonel bir kütüphanedir.

## 🎯 Amacı Nedir?

Bu kütüphane; karmaşık sigorta verilerini, araç segmentlerini ve risk faktörlerini kullanarak bir otomobilin sahip olması gereken **teknik karşılığı (primi)** hesaplamayı amaçlar. Sadece bir hesap makinesi değil, aktüeryal bir karar destek mekanizmasıdır.

## 🚀 Öne Çıkan Özellikler

* **Katmanlı Prim Analizi:** Saf primden brüt prime giden şeffaf hesaplama süreci.
* **Dinamik Risk Katsayıları:** Araç segmenti (A, B, C, D, E ) ve model yılına göre ağırlıklandırılmış çarpanlar.
* **Hasar Denetimi:** Hasarsızlık indirimi (No-Claim Discount) ve ek risk (Malus) sürprim kontrolleri.
* **Veri Güvenliği:** Mantıksal hata kontrolleri ve üretim yılı kısıtlamaları.

## 📦 Kurulum

Kütüphaneyi terminal üzerinden saniyeler içinde kurabilirsin:

```bash
pip install SigortaTahmin

