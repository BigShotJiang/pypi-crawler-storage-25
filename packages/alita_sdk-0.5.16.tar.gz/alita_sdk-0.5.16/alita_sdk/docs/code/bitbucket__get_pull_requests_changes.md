# bitbucket - get_pull_requests_changes

**Toolkit**: `bitbucket`
**Method**: `get_pull_requests_changes`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def get_pull_requests_changes(self, pr_id: str) -> Dict[str, Any]:
        """
        Get changes of a pull request
        Parameters:
            pr_id(str): the pull request ID
        Returns:
            dict: Changes of the pull request as a dictionary
        """
        try:
            return self._bitbucket.get_pull_requests_changes(pr_id=pr_id)
        except Exception as e:
            return ToolException(f"Can't get changes from pull request `{pr_id}` due to error:\n{str(e)}")
```
