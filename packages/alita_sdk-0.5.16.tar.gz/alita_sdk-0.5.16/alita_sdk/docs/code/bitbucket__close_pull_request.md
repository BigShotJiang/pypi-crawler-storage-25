# bitbucket - close_pull_request

**Toolkit**: `bitbucket`
**Method**: `close_pull_request`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def close_pull_request(self, pr_id: str, message: str = None) -> str:
        """
        Close (decline) a pull request without merging it.
        Parameters:
            pr_id (str): the pull request ID
            message (str, optional): Optional message explaining why the pull request is being closed
        Returns:
            str: A success or failure message
        """
        try:
            result = self._bitbucket.close_pull_request(pr_id=pr_id, message=message)
            return f"Successfully closed pull request {pr_id}\n{str(result)}"
        except Exception as e:
            return ToolException(f"Can't close pull request `{pr_id}` due to error:\n{str(e)}")
```
