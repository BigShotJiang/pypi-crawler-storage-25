# bitbucket - create_file

**Toolkit**: `bitbucket`
**Method**: `create_file`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def create_file(self, file_path: str, file_contents: str, branch: str) -> str:
        """
        Creates a new file on the bitbucket repo
        Parameters:
            file_path(str): a string which contains the file path (example: "hello_world.md").
            file_contents(str): a string which the file contents (example: "# Hello World!").
            branch(str): branch name (by default: active_branch)
        Returns:
            str: A success or failure message
        """
        # Check if file already exists to prevent silent overwrites
        try:
            self._read_file(file_path, branch)
            # If read succeeds, file exists - raise error
            raise ToolException(
                f"File already exists: {file_path}. Use update_file() to modify existing files."
            )
        except ToolException as e:
            # If the error is about file not found, proceed with creation
            # Otherwise, re-raise (it could be our "already exists" error or another issue)
            error_msg = str(e).lower()
            if "already exists" in error_msg:
                raise
            # File doesn't exist (404 or similar) - proceed with creation
            pass
        except Exception:
            # File doesn't exist or other read error - proceed with creation attempt
            pass
        
        try:
            self._bitbucket.create_file(file_path=file_path, file_contents=file_contents, branch=branch)
            return f"File has been created: {file_path}."
        except Exception as e:
            raise ToolException(f"File was not created due to error: {str(e)}")
```
