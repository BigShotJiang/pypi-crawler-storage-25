# aws - get_available_tools

**Toolkit**: `aws`
**Method**: `get_available_tools`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def get_available_tools(self) -> List[dict]:
        return [
            {
                "name": "query_table",
                "description": self.query_table.__doc__,
                "args_schema": ArgsSchema.QueryTableArgs.value,
                "ref": self.query_table,
            },
            {
                "name": "vector_search",
                "description": self.vector_search.__doc__,
                "args_schema": ArgsSchema.VectorSearchArgs.value,
                "ref": self.vector_search,
            },
            {
                "name": "get_table_schema",
                "description": self.get_table_schema.__doc__,
                "args_schema": ArgsSchema.NoInput.value,
                "ref": self.get_table_schema,
            },
        ]
```
