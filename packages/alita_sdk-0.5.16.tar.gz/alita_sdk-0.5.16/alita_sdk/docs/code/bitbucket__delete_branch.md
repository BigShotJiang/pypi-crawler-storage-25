# bitbucket - delete_branch

**Toolkit**: `bitbucket`
**Method**: `delete_branch`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def delete_branch(self, branch_name: str) -> str:
        """
        Delete a branch from the repository.
        
        Parameters:
            branch_name (str): The name of the branch to delete
            
        Returns:
            str: Success message if branch is deleted, or ToolException if branch cannot be deleted
            
        Raises:
            ToolException: If attempting to delete main/master branch or if deletion fails
        """
        # Prevent deletion of protected branches
        if branch_name.lower() in ['main', 'master']:
            raise ToolException(
                f"Cannot delete branch '{branch_name}'. "
                "Deletion of main or master branches is forbidden for safety reasons."
            )
        
        try:
            # Fetch all branches to verify the branch exists
            branches = self._bitbucket.list_branches()
            
            if branch_name not in branches:
                raise ToolException(
                    f"Branch '{branch_name}' does not exist in the repository. "
                    f"Available branches: {', '.join(branches[:20])}"
                )
            
            # If the deleted branch was the active branch, switch to main
            if self._active_branch == branch_name:
                raise ToolException(
                    f"Branch '{branch_name}' cannot be deleted because it is currently the active branch. "
                    "Please switch to a different branch before deleting."
                )
            
            # Delete the branch
            self._bitbucket.delete_branch(branch_name)

            return f"Branch '{branch_name}' has been deleted successfully."
            
            # Return success message
            return f"Branch '{branch_name}' deleted successfully"
            
        except ToolException:
            raise
        except Exception as e:
            raise ToolException(f"Failed to delete branch '{branch_name}': {str(e)}")
```
