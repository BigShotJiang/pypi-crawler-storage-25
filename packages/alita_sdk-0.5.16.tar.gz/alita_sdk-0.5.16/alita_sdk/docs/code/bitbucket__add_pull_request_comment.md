# bitbucket - add_pull_request_comment

**Toolkit**: `bitbucket`
**Method**: `add_pull_request_comment`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def add_pull_request_comment(self, pr_id: str, content, inline=None) -> str:
        """
        Add a comment to a pull request. Supports multiple content types and inline comments.
        Parameters:
            pr_id (str): the pull request ID
            content (str or dict): The comment content. Can be a string (raw text) or a dict with keys 'raw', 'markup', 'html'.
            inline (dict, optional): Inline comment details. Example: {"from": 57, "to": 122, "path": "<string>"}
        Returns:
            str: A success or failure message
        """
        try:
            return self._bitbucket.add_pull_request_comment(pr_id=pr_id, content=content, inline=inline)
        except Exception as e:
            return ToolException(f"Can't add comment to pull request `{pr_id}` due to error:\n{str(e)}")
```
