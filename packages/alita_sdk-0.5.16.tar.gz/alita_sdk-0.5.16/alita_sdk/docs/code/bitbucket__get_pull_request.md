# bitbucket - get_pull_request

**Toolkit**: `bitbucket`
**Method**: `get_pull_request`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def get_pull_request(self, pr_id: str) -> Dict[str, Any]:
        """
        Get details of a pull request
        Parameters:
            pr_id(str): the pull request ID
        Returns:
            dict: Details of the pull request as a dictionary
        """
        try:
            return self._bitbucket.get_pull_request(pr_id=pr_id)
        except Exception as e:
            return ToolException(f"Can't get pull request `{pr_id}` due to error:\n{str(e)}")
```
