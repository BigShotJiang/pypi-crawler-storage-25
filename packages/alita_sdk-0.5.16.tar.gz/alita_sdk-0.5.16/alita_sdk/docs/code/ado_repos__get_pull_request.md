# ado_repos - get_pull_request

**Toolkit**: `ado_repos`
**Method**: `get_pull_request`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def get_pull_request(self, pull_request_id: str) -> str:
        """
        Fetches particular pull request from the Azure DevOps repository.

        Returns:
            str: A plaintext report containing PR by ID.
        """
        try:
            pull_request = self._client.get_pull_request_by_id(
                project=self.project, pull_request_id=pull_request_id
            )
        except Exception as e:
            msg = f"Failed to find pull request with '{pull_request_id}' ID. Error: {e}"
            logger.error(msg)
            return ToolException(msg)

        if pull_request:
            parsed_pr = self.parse_pull_requests(pull_request)
            return parsed_pr
        else:
            return f"Pull request with '{pull_request_id}' ID is not found"
```

## Helper Methods

```python
Helper: parse_pull_requests
    def parse_pull_requests(
            self, pull_requests: Union[GitPullRequest, List[GitPullRequest]]
    ) -> List[dict]:
        """
        Extracts title and number from each Pull Request and puts them in a dictionary
        Parameters:
            issues(List[GitPullRequest]): A list of ADO Repos  GitPullRequest objects
        Returns:
            List[dict]: A dictionary of Pull Request titles and numbers
        """
        if not isinstance(pull_requests, list):
            pull_requests = [pull_requests]

        parsed = []
        try:
            for pull_request in pull_requests:
                comment_threads: List[GitPullRequestCommentThread] = (
                    self._client.get_threads(
                        repository_id=self.repository_id,
                        pull_request_id=pull_request.pull_request_id,
                        project=self.project,
                    )
                )

                commits: List[GitCommitRef] = self._client.get_pull_request_commits(
                    repository_id=self.repository_id,
                    project=self.project,
                    pull_request_id=pull_request.pull_request_id,
                )

                commit_details = [
                    {"commit_id": commit.commit_id, "comment": commit.comment}
                    for commit in commits
                ]

                parsed.append(
                    {
                        "title": pull_request.title,
                        "pull_request_id": pull_request.pull_request_id,
                        "commits": commit_details,
                        "comments": self.parse_pull_request_comments(comment_threads),
                        "source_branch": pull_request.source_ref_name,
                        "target_branch": pull_request.target_ref_name,
                    }
                )
        except Exception as e:
            msg = f"Failed to parse pull requests. Error: {str(e)}"
            logger.error(msg)
            return ToolException(msg)

        return parsed
```
