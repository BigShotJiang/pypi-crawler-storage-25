"""Synchronous ZapApi client."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ZapApiError,
)
from .resources.account import Account
from .resources.contacts import Contacts
from .resources.groups import Groups
from .resources.messages import Messages
from .resources.sessions import Sessions
from .resources.webhooks import Webhooks

__all__ = ["ZapApi"]


class ZapApi:
    """Synchronous client for the ZapApi REST API.

    Example::

        from zapapi import ZapApi

        client = ZapApi(api_key="zap_live_...")
        sessions = client.sessions.list()
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.zapapi.net",
        timeout: int = 30,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "zapapi-python/1.0.0",
            },
            timeout=timeout,
        )

        # Lazy-initialized resource instances
        self._sessions: Optional[Sessions] = None
        self._messages: Optional[Messages] = None
        self._groups: Optional[Groups] = None
        self._contacts: Optional[Contacts] = None
        self._webhooks: Optional[Webhooks] = None
        self._account: Optional[Account] = None

    # -- resource properties -----------------------------------------------

    @property
    def sessions(self) -> Sessions:
        if self._sessions is None:
            self._sessions = Sessions(self._request)
        return self._sessions

    @property
    def messages(self) -> Messages:
        if self._messages is None:
            self._messages = Messages(self._request)
        return self._messages

    @property
    def groups(self) -> Groups:
        if self._groups is None:
            self._groups = Groups(self._request)
        return self._groups

    @property
    def contacts(self) -> Contacts:
        if self._contacts is None:
            self._contacts = Contacts(self._request)
        return self._contacts

    @property
    def webhooks(self) -> Webhooks:
        if self._webhooks is None:
            self._webhooks = Webhooks(self._request)
        return self._webhooks

    @property
    def account(self) -> Account:
        if self._account is None:
            self._account = Account(self._request)
        return self._account

    # -- HTTP layer --------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Execute an HTTP request and return the parsed JSON response."""
        kwargs: Dict[str, Any] = {}
        if data is not None:
            kwargs["json"] = data

        response = self._http.request(method, path, **kwargs)
        return self._handle_response(response)

    @staticmethod
    def _handle_response(response: httpx.Response) -> Any:
        """Parse the response, raising typed exceptions on error."""
        if response.is_success:
            if response.status_code == 204:
                return None
            return response.json()

        # Attempt to extract an error body
        try:
            body = response.json()
        except Exception:
            body = {}

        message = body.get("message", response.text)
        status = response.status_code

        if status == 401:
            raise AuthenticationError(message)
        if status == 404:
            raise NotFoundError(message)
        if status == 422:
            raise ValidationError(errors=body.get("errors"), message=message)
        if status == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                retry_after=int(retry_after) if retry_after else None
            )
        raise ZapApiError(message=message, status_code=status)

    # -- lifecycle ---------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "ZapApi":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
