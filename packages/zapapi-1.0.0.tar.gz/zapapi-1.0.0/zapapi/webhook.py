"""Webhook signature verification helper."""

from __future__ import annotations

import hashlib
import hmac


def verify_signature(body: bytes, signature: str, secret: str) -> bool:
    """Verify an incoming webhook signature.

    ZapApi signs every webhook delivery with an HMAC-SHA256 digest using
    the webhook secret you configured.  Pass the raw request body, the
    value of the ``X-ZapApi-Signature`` header, and your secret to this
    function.

    Args:
        body: The raw request body as bytes.
        signature: The signature string from the ``X-ZapApi-Signature`` header.
        secret: The webhook secret configured in your ZapApi dashboard.

    Returns:
        ``True`` if the signature is valid, ``False`` otherwise.
    """
    expected = hmac.new(
        key=secret.encode("utf-8"),
        msg=body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature)
