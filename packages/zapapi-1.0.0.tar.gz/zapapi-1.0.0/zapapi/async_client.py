"""Asynchronous ZapApi client."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from .exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ZapApiError,
)
from .resources.account import AsyncAccount
from .resources.contacts import AsyncContacts
from .resources.groups import AsyncGroups
from .resources.messages import AsyncMessages
from .resources.sessions import AsyncSessions
from .resources.webhooks import AsyncWebhooks

__all__ = ["AsyncZapApi"]


class AsyncZapApi:
    """Asynchronous client for the ZapApi REST API.

    Example::

        import asyncio
        from zapapi import AsyncZapApi

        async def main():
            async with AsyncZapApi(api_key="zap_live_...") as client:
                sessions = await client.sessions.list()
                print(sessions)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.zapapi.net",
        timeout: int = 30,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.AsyncClient(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "zapapi-python/1.0.0",
            },
            timeout=timeout,
        )

        self._sessions: Optional[AsyncSessions] = None
        self._messages: Optional[AsyncMessages] = None
        self._groups: Optional[AsyncGroups] = None
        self._contacts: Optional[AsyncContacts] = None
        self._webhooks: Optional[AsyncWebhooks] = None
        self._account: Optional[AsyncAccount] = None

    # -- resource properties -----------------------------------------------

    @property
    def sessions(self) -> AsyncSessions:
        if self._sessions is None:
            self._sessions = AsyncSessions(self._request)
        return self._sessions

    @property
    def messages(self) -> AsyncMessages:
        if self._messages is None:
            self._messages = AsyncMessages(self._request)
        return self._messages

    @property
    def groups(self) -> AsyncGroups:
        if self._groups is None:
            self._groups = AsyncGroups(self._request)
        return self._groups

    @property
    def contacts(self) -> AsyncContacts:
        if self._contacts is None:
            self._contacts = AsyncContacts(self._request)
        return self._contacts

    @property
    def webhooks(self) -> AsyncWebhooks:
        if self._webhooks is None:
            self._webhooks = AsyncWebhooks(self._request)
        return self._webhooks

    @property
    def account(self) -> AsyncAccount:
        if self._account is None:
            self._account = AsyncAccount(self._request)
        return self._account

    # -- HTTP layer --------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Execute an async HTTP request and return the parsed JSON response."""
        kwargs: Dict[str, Any] = {}
        if data is not None:
            kwargs["json"] = data

        response = await self._http.request(method, path, **kwargs)
        return self._handle_response(response)

    @staticmethod
    def _handle_response(response: httpx.Response) -> Any:
        """Parse the response, raising typed exceptions on error."""
        if response.is_success:
            if response.status_code == 204:
                return None
            return response.json()

        try:
            body = response.json()
        except Exception:
            body = {}

        message = body.get("message", response.text)
        status = response.status_code

        if status == 401:
            raise AuthenticationError(message)
        if status == 404:
            raise NotFoundError(message)
        if status == 422:
            raise ValidationError(errors=body.get("errors"), message=message)
        if status == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                retry_after=int(retry_after) if retry_after else None
            )
        raise ZapApiError(message=message, status_code=status)

    # -- lifecycle ---------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncZapApi":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
