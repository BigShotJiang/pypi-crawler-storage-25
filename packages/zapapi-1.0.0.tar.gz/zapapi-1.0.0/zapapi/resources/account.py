"""Account resource — manage your ZapApi account and API keys."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Account:
    """Synchronous account resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    def get(self) -> Dict[str, Any]:
        """Get current account details."""
        return self._request("GET", "/account")

    def update(self, **kwargs: Any) -> Dict[str, Any]:
        """Update account settings."""
        return self._request("PUT", "/account", data=kwargs)

    def usage(self) -> Dict[str, Any]:
        """Get current billing period usage."""
        return self._request("GET", "/account/usage")

    def api_keys(self) -> List[Dict[str, Any]]:
        """List all API keys."""
        return self._request("GET", "/account/api-keys")

    def create_api_key(
        self,
        name: str,
        *,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a new API key."""
        data: Dict[str, Any] = {"name": name}
        if scopes is not None:
            data["scopes"] = scopes
        return self._request("POST", "/account/api-keys", data=data)

    def revoke_api_key(self, key_id: str) -> Dict[str, Any]:
        """Revoke an API key."""
        return self._request("DELETE", f"/account/api-keys/{key_id}")


class AsyncAccount:
    """Asynchronous account resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def get(self) -> Dict[str, Any]:
        return await self._request("GET", "/account")

    async def update(self, **kwargs: Any) -> Dict[str, Any]:
        return await self._request("PUT", "/account", data=kwargs)

    async def usage(self) -> Dict[str, Any]:
        return await self._request("GET", "/account/usage")

    async def api_keys(self) -> List[Dict[str, Any]]:
        return await self._request("GET", "/account/api-keys")

    async def create_api_key(
        self,
        name: str,
        *,
        scopes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"name": name}
        if scopes is not None:
            data["scopes"] = scopes
        return await self._request("POST", "/account/api-keys", data=data)

    async def revoke_api_key(self, key_id: str) -> Dict[str, Any]:
        return await self._request("DELETE", f"/account/api-keys/{key_id}")
