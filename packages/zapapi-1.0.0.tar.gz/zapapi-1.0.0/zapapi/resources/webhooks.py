"""Webhooks resource — manage webhook endpoints."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Webhooks:
    """Synchronous webhooks resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    def create(
        self,
        url: str,
        events: List[str],
        *,
        secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Register a new webhook endpoint."""
        data: Dict[str, Any] = {"url": url, "events": events}
        if secret is not None:
            data["secret"] = secret
        return self._request("POST", "/webhooks", data=data)

    def list(self) -> List[Dict[str, Any]]:
        """List all registered webhooks."""
        return self._request("GET", "/webhooks")

    def get(self, webhook_id: str) -> Dict[str, Any]:
        """Get a webhook by ID."""
        return self._request("GET", f"/webhooks/{webhook_id}")

    def update(
        self,
        webhook_id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        secret: Optional[str] = None,
        active: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Update an existing webhook."""
        data: Dict[str, Any] = {}
        if url is not None:
            data["url"] = url
        if events is not None:
            data["events"] = events
        if secret is not None:
            data["secret"] = secret
        if active is not None:
            data["active"] = active
        return self._request("PUT", f"/webhooks/{webhook_id}", data=data)

    def delete(self, webhook_id: str) -> Dict[str, Any]:
        """Delete a webhook."""
        return self._request("DELETE", f"/webhooks/{webhook_id}")

    def deliveries(self, webhook_id: str) -> List[Dict[str, Any]]:
        """List recent delivery attempts for a webhook."""
        return self._request("GET", f"/webhooks/{webhook_id}/deliveries")

    def test(self, webhook_id: str) -> Dict[str, Any]:
        """Send a test event to a webhook."""
        return self._request("POST", f"/webhooks/{webhook_id}/test")


class AsyncWebhooks:
    """Asynchronous webhooks resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def create(
        self,
        url: str,
        events: List[str],
        *,
        secret: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"url": url, "events": events}
        if secret is not None:
            data["secret"] = secret
        return await self._request("POST", "/webhooks", data=data)

    async def list(self) -> List[Dict[str, Any]]:
        return await self._request("GET", "/webhooks")

    async def get(self, webhook_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/webhooks/{webhook_id}")

    async def update(
        self,
        webhook_id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        secret: Optional[str] = None,
        active: Optional[bool] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if url is not None:
            data["url"] = url
        if events is not None:
            data["events"] = events
        if secret is not None:
            data["secret"] = secret
        if active is not None:
            data["active"] = active
        return await self._request("PUT", f"/webhooks/{webhook_id}", data=data)

    async def delete(self, webhook_id: str) -> Dict[str, Any]:
        return await self._request("DELETE", f"/webhooks/{webhook_id}")

    async def deliveries(self, webhook_id: str) -> List[Dict[str, Any]]:
        return await self._request("GET", f"/webhooks/{webhook_id}/deliveries")

    async def test(self, webhook_id: str) -> Dict[str, Any]:
        return await self._request("POST", f"/webhooks/{webhook_id}/test")
