"""Groups resource — manage WhatsApp groups."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Groups:
    """Synchronous groups resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    def create(
        self,
        session_id: str,
        name: str,
        participants: List[str],
    ) -> Dict[str, Any]:
        """Create a new group."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/groups",
            data={"name": name, "participants": participants},
        )

    def list(self, session_id: str) -> List[Dict[str, Any]]:
        """List all groups for a session."""
        return self._request("GET", f"/sessions/{session_id}/groups")

    def get(self, session_id: str, group_id: str) -> Dict[str, Any]:
        """Get a group by ID."""
        return self._request("GET", f"/sessions/{session_id}/groups/{group_id}")

    def update(
        self,
        session_id: str,
        group_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update group name or description."""
        data: Dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        return self._request("PUT", f"/sessions/{session_id}/groups/{group_id}", data=data)

    def leave(self, session_id: str, group_id: str) -> Dict[str, Any]:
        """Leave a group."""
        return self._request("POST", f"/sessions/{session_id}/groups/{group_id}/leave")

    def add_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        """Add participants to a group."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/add",
            data={"participants": participants},
        )

    def remove_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        """Remove participants from a group."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/remove",
            data={"participants": participants},
        )

    def promote_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        """Promote participants to admin."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/promote",
            data={"participants": participants},
        )

    def demote_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        """Demote admins to regular participants."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/demote",
            data={"participants": participants},
        )

    def invite_link(self, session_id: str, group_id: str) -> Dict[str, Any]:
        """Get the invite link for a group."""
        return self._request("GET", f"/sessions/{session_id}/groups/{group_id}/invite")


class AsyncGroups:
    """Asynchronous groups resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def create(
        self, session_id: str, name: str, participants: List[str]
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/groups",
            data={"name": name, "participants": participants},
        )

    async def list(self, session_id: str) -> List[Dict[str, Any]]:
        return await self._request("GET", f"/sessions/{session_id}/groups")

    async def get(self, session_id: str, group_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/sessions/{session_id}/groups/{group_id}")

    async def update(
        self,
        session_id: str,
        group_id: str,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {}
        if name is not None:
            data["name"] = name
        if description is not None:
            data["description"] = description
        return await self._request("PUT", f"/sessions/{session_id}/groups/{group_id}", data=data)

    async def leave(self, session_id: str, group_id: str) -> Dict[str, Any]:
        return await self._request("POST", f"/sessions/{session_id}/groups/{group_id}/leave")

    async def add_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/add",
            data={"participants": participants},
        )

    async def remove_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/remove",
            data={"participants": participants},
        )

    async def promote_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/promote",
            data={"participants": participants},
        )

    async def demote_participants(
        self, session_id: str, group_id: str, participants: List[str]
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/groups/{group_id}/participants/demote",
            data={"participants": participants},
        )

    async def invite_link(self, session_id: str, group_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/sessions/{session_id}/groups/{group_id}/invite")
