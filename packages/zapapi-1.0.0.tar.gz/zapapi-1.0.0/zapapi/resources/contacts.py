"""Contacts resource — check numbers and fetch profile pictures."""

from __future__ import annotations

from typing import Any, Callable, Dict, List


class Contacts:
    """Synchronous contacts resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    def check(self, session_id: str, phone: str) -> Dict[str, Any]:
        """Check if a phone number is registered on WhatsApp."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/contacts/check",
            data={"phone": phone},
        )

    def check_batch(self, session_id: str, phones: List[str]) -> Dict[str, Any]:
        """Check multiple phone numbers at once."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/contacts/check-batch",
            data={"phones": phones},
        )

    def profile_picture(self, session_id: str, phone: str) -> Dict[str, Any]:
        """Get the profile picture URL for a contact."""
        return self._request(
            "GET",
            f"/sessions/{session_id}/contacts/{phone}/profile-picture",
        )


class AsyncContacts:
    """Asynchronous contacts resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def check(self, session_id: str, phone: str) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/contacts/check",
            data={"phone": phone},
        )

    async def check_batch(self, session_id: str, phones: List[str]) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/contacts/check-batch",
            data={"phones": phones},
        )

    async def profile_picture(self, session_id: str, phone: str) -> Dict[str, Any]:
        return await self._request(
            "GET",
            f"/sessions/{session_id}/contacts/{phone}/profile-picture",
        )
