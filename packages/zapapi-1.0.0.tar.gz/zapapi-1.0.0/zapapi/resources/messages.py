"""Messages resource — send and manage WhatsApp messages."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Messages:
    """Synchronous messages resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    # --- sending ----------------------------------------------------------

    def send_text(
        self,
        session_id: str,
        to: str,
        text: str,
        *,
        quote_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a text message."""
        data: Dict[str, Any] = {"to": to, "text": text}
        if quote_id is not None:
            data["quote_id"] = quote_id
        return self._request("POST", f"/sessions/{session_id}/messages/text", data=data)

    def send_media(
        self,
        session_id: str,
        to: str,
        media_url: str,
        *,
        type: str = "image",
        caption: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a media message (image, video, audio, document)."""
        data: Dict[str, Any] = {"to": to, "media_url": media_url, "type": type}
        if caption is not None:
            data["caption"] = caption
        if filename is not None:
            data["filename"] = filename
        return self._request("POST", f"/sessions/{session_id}/messages/media", data=data)

    def send_buttons(
        self,
        session_id: str,
        to: str,
        text: str,
        buttons: List[Dict[str, str]],
        *,
        footer: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a message with interactive buttons."""
        data: Dict[str, Any] = {"to": to, "text": text, "buttons": buttons}
        if footer is not None:
            data["footer"] = footer
        return self._request("POST", f"/sessions/{session_id}/messages/buttons", data=data)

    def send_list(
        self,
        session_id: str,
        to: str,
        text: str,
        button_text: str,
        sections: List[Dict[str, Any]],
        *,
        title: Optional[str] = None,
        footer: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a list message."""
        data: Dict[str, Any] = {
            "to": to,
            "text": text,
            "button_text": button_text,
            "sections": sections,
        }
        if title is not None:
            data["title"] = title
        if footer is not None:
            data["footer"] = footer
        return self._request("POST", f"/sessions/{session_id}/messages/list", data=data)

    def send_location(
        self,
        session_id: str,
        to: str,
        latitude: float,
        longitude: float,
        *,
        name: Optional[str] = None,
        address: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Send a location pin."""
        data: Dict[str, Any] = {"to": to, "latitude": latitude, "longitude": longitude}
        if name is not None:
            data["name"] = name
        if address is not None:
            data["address"] = address
        return self._request("POST", f"/sessions/{session_id}/messages/location", data=data)

    def send_contact(
        self,
        session_id: str,
        to: str,
        contacts: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Send one or more contact cards."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/contact",
            data={"to": to, "contacts": contacts},
        )

    def send_poll(
        self,
        session_id: str,
        to: str,
        question: str,
        options: List[str],
        *,
        max_selections: int = 1,
    ) -> Dict[str, Any]:
        """Send a poll."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/poll",
            data={
                "to": to,
                "question": question,
                "options": options,
                "max_selections": max_selections,
            },
        )

    def send_reaction(
        self,
        session_id: str,
        to: str,
        message_id: str,
        emoji: str,
    ) -> Dict[str, Any]:
        """React to a message with an emoji."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/reaction",
            data={"to": to, "message_id": message_id, "emoji": emoji},
        )

    def send_sticker(
        self,
        session_id: str,
        to: str,
        sticker_url: str,
    ) -> Dict[str, Any]:
        """Send a sticker from a URL."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/sticker",
            data={"to": to, "sticker_url": sticker_url},
        )

    # --- actions ----------------------------------------------------------

    def delete(self, session_id: str, message_id: str, to: str) -> Dict[str, Any]:
        """Delete (revoke) a message."""
        return self._request(
            "DELETE",
            f"/sessions/{session_id}/messages/{message_id}",
            data={"to": to},
        )

    def mark_as_read(self, session_id: str, message_id: str, to: str) -> Dict[str, Any]:
        """Mark a message as read."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/{message_id}/read",
            data={"to": to},
        )

    def send_typing(
        self,
        session_id: str,
        to: str,
        *,
        duration: int = 3000,
    ) -> Dict[str, Any]:
        """Send a typing indicator."""
        return self._request(
            "POST",
            f"/sessions/{session_id}/messages/typing",
            data={"to": to, "duration": duration},
        )


class AsyncMessages:
    """Asynchronous messages resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def send_text(
        self,
        session_id: str,
        to: str,
        text: str,
        *,
        quote_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"to": to, "text": text}
        if quote_id is not None:
            data["quote_id"] = quote_id
        return await self._request("POST", f"/sessions/{session_id}/messages/text", data=data)

    async def send_media(
        self,
        session_id: str,
        to: str,
        media_url: str,
        *,
        type: str = "image",
        caption: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"to": to, "media_url": media_url, "type": type}
        if caption is not None:
            data["caption"] = caption
        if filename is not None:
            data["filename"] = filename
        return await self._request("POST", f"/sessions/{session_id}/messages/media", data=data)

    async def send_buttons(
        self,
        session_id: str,
        to: str,
        text: str,
        buttons: List[Dict[str, str]],
        *,
        footer: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"to": to, "text": text, "buttons": buttons}
        if footer is not None:
            data["footer"] = footer
        return await self._request("POST", f"/sessions/{session_id}/messages/buttons", data=data)

    async def send_list(
        self,
        session_id: str,
        to: str,
        text: str,
        button_text: str,
        sections: List[Dict[str, Any]],
        *,
        title: Optional[str] = None,
        footer: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "to": to,
            "text": text,
            "button_text": button_text,
            "sections": sections,
        }
        if title is not None:
            data["title"] = title
        if footer is not None:
            data["footer"] = footer
        return await self._request("POST", f"/sessions/{session_id}/messages/list", data=data)

    async def send_location(
        self,
        session_id: str,
        to: str,
        latitude: float,
        longitude: float,
        *,
        name: Optional[str] = None,
        address: Optional[str] = None,
    ) -> Dict[str, Any]:
        data: Dict[str, Any] = {"to": to, "latitude": latitude, "longitude": longitude}
        if name is not None:
            data["name"] = name
        if address is not None:
            data["address"] = address
        return await self._request("POST", f"/sessions/{session_id}/messages/location", data=data)

    async def send_contact(
        self,
        session_id: str,
        to: str,
        contacts: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/contact",
            data={"to": to, "contacts": contacts},
        )

    async def send_poll(
        self,
        session_id: str,
        to: str,
        question: str,
        options: List[str],
        *,
        max_selections: int = 1,
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/poll",
            data={
                "to": to,
                "question": question,
                "options": options,
                "max_selections": max_selections,
            },
        )

    async def send_reaction(
        self,
        session_id: str,
        to: str,
        message_id: str,
        emoji: str,
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/reaction",
            data={"to": to, "message_id": message_id, "emoji": emoji},
        )

    async def send_sticker(
        self,
        session_id: str,
        to: str,
        sticker_url: str,
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/sticker",
            data={"to": to, "sticker_url": sticker_url},
        )

    async def delete(self, session_id: str, message_id: str, to: str) -> Dict[str, Any]:
        return await self._request(
            "DELETE",
            f"/sessions/{session_id}/messages/{message_id}",
            data={"to": to},
        )

    async def mark_as_read(self, session_id: str, message_id: str, to: str) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/{message_id}/read",
            data={"to": to},
        )

    async def send_typing(
        self,
        session_id: str,
        to: str,
        *,
        duration: int = 3000,
    ) -> Dict[str, Any]:
        return await self._request(
            "POST",
            f"/sessions/{session_id}/messages/typing",
            data={"to": to, "duration": duration},
        )
