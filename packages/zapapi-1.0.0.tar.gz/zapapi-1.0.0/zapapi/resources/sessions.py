"""Sessions resource — manage WhatsApp sessions."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional


class Sessions:
    """Synchronous sessions resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    def create(self, name: str) -> Dict[str, Any]:
        """Create a new WhatsApp session."""
        return self._request("POST", "/sessions", data={"name": name})

    def list(self) -> List[Dict[str, Any]]:
        """List all sessions."""
        return self._request("GET", "/sessions")

    def get(self, session_id: str) -> Dict[str, Any]:
        """Get a session by ID."""
        return self._request("GET", f"/sessions/{session_id}")

    def get_qr_code(self, session_id: str) -> Dict[str, Any]:
        """Get the QR code for session pairing."""
        return self._request("GET", f"/sessions/{session_id}/qr")

    def connect(self, session_id: str) -> Dict[str, Any]:
        """Connect (start) a session."""
        return self._request("POST", f"/sessions/{session_id}/connect")

    def disconnect(self, session_id: str) -> Dict[str, Any]:
        """Disconnect (stop) a session."""
        return self._request("POST", f"/sessions/{session_id}/disconnect")

    def delete(self, session_id: str) -> Dict[str, Any]:
        """Delete a session permanently."""
        return self._request("DELETE", f"/sessions/{session_id}")

    def get_profile(self, session_id: str) -> Dict[str, Any]:
        """Get the WhatsApp profile for a session."""
        return self._request("GET", f"/sessions/{session_id}/profile")

    def update_profile(self, session_id: str, **kwargs: Any) -> Dict[str, Any]:
        """Update the WhatsApp profile for a session.

        Keyword arguments may include ``name``, ``status``, and ``picture``.
        """
        return self._request("PUT", f"/sessions/{session_id}/profile", data=kwargs)


class AsyncSessions:
    """Asynchronous sessions resource."""

    def __init__(self, request: Callable[..., Any]) -> None:
        self._request = request

    async def create(self, name: str) -> Dict[str, Any]:
        return await self._request("POST", "/sessions", data={"name": name})

    async def list(self) -> List[Dict[str, Any]]:
        return await self._request("GET", "/sessions")

    async def get(self, session_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/sessions/{session_id}")

    async def get_qr_code(self, session_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/sessions/{session_id}/qr")

    async def connect(self, session_id: str) -> Dict[str, Any]:
        return await self._request("POST", f"/sessions/{session_id}/connect")

    async def disconnect(self, session_id: str) -> Dict[str, Any]:
        return await self._request("POST", f"/sessions/{session_id}/disconnect")

    async def delete(self, session_id: str) -> Dict[str, Any]:
        return await self._request("DELETE", f"/sessions/{session_id}")

    async def get_profile(self, session_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/sessions/{session_id}/profile")

    async def update_profile(self, session_id: str, **kwargs: Any) -> Dict[str, Any]:
        return await self._request("PUT", f"/sessions/{session_id}/profile", data=kwargs)
