"""ZapApi — Official Python SDK for the ZapApi WhatsApp API.

Quick start::

    from zapapi import ZapApi

    client = ZapApi(api_key="zap_live_...")
    client.messages.send_text("sess_abc", "5511999999999@s.whatsapp.net", "Hello!")
"""

from .async_client import AsyncZapApi
from .client import ZapApi
from .exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ZapApiError,
)
from .webhook import verify_signature

__all__ = [
    "ZapApi",
    "AsyncZapApi",
    "ZapApiError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "NotFoundError",
    "verify_signature",
]

__version__ = "1.0.0"
