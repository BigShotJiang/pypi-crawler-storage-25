"""Typed exceptions for the ZapApi SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class ZapApiError(Exception):
    """Base exception for all ZapApi API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None) -> None:
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)

    def __repr__(self) -> str:
        return f"ZapApiError(message={self.message!r}, status_code={self.status_code!r})"


class AuthenticationError(ZapApiError):
    """Raised when the API key is invalid or missing."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message=message, status_code=401)


class ValidationError(ZapApiError):
    """Raised when the request payload fails server-side validation."""

    def __init__(
        self,
        errors: Optional[List[Dict[str, Any]]] = None,
        message: str = "Validation failed",
    ) -> None:
        self.errors = errors or []
        super().__init__(message=message, status_code=422)

    def __repr__(self) -> str:
        return f"ValidationError(errors={self.errors!r})"


class RateLimitError(ZapApiError):
    """Raised when the API rate limit is exceeded."""

    def __init__(self, retry_after: Optional[int] = None) -> None:
        self.retry_after = retry_after
        message = "Rate limit exceeded"
        if retry_after is not None:
            message += f" — retry after {retry_after}s"
        super().__init__(message=message, status_code=429)

    def __repr__(self) -> str:
        return f"RateLimitError(retry_after={self.retry_after!r})"


class NotFoundError(ZapApiError):
    """Raised when the requested resource does not exist."""

    def __init__(self, message: str = "Resource not found") -> None:
        super().__init__(message=message, status_code=404)
