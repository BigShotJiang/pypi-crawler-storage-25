# ZapApi Python SDK

[![PyPI version](https://img.shields.io/pypi/v/zapapi.svg)](https://pypi.org/project/zapapi/)
[![Python versions](https://img.shields.io/pypi/pyversions/zapapi.svg)](https://pypi.org/project/zapapi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

SDK oficial Python para a [ZapApi](https://zapapi.net) — WhatsApp API para desenvolvedores.

## Instalacao

```bash
pip install zapapi
```

## Quick Start

```python
from zapapi import ZapApi

client = ZapApi(api_key="zap_live_sua_chave_aqui")

# Criar uma sessao
session = client.sessions.create(name="Meu Bot")

# Enviar mensagem de texto
client.messages.send_text(
    session_id=session["id"],
    to="5511999999999@s.whatsapp.net",
    text="Ola pelo ZapApi!",
)

# Listar sessoes
for s in client.sessions.list():
    print(s["name"], s["status"])
```

## Async

```python
import asyncio
from zapapi import AsyncZapApi

async def main():
    async with AsyncZapApi(api_key="zap_live_sua_chave_aqui") as client:
        sessions = await client.sessions.list()

        await client.messages.send_text(
            session_id=sessions[0]["id"],
            to="5511999999999@s.whatsapp.net",
            text="Mensagem async!",
        )

asyncio.run(main())
```

## Recursos Disponiveis

| Recurso | Descricao |
|---------|-----------|
| `client.sessions` | Criar, conectar, desconectar e gerenciar sessoes WhatsApp |
| `client.messages` | Enviar texto, midia, botoes, listas, localizacao, contato, enquete, reacao, sticker |
| `client.groups` | Criar e gerenciar grupos, participantes, links de convite |
| `client.contacts` | Verificar numeros, foto de perfil |
| `client.webhooks` | Registrar, atualizar, testar e gerenciar webhooks |
| `client.account` | Dados da conta, uso, chaves de API |

## Enviar Diferentes Tipos de Mensagem

```python
# Midia (imagem, video, audio, documento)
client.messages.send_media(
    session_id="sess_abc",
    to="5511999999999@s.whatsapp.net",
    media_url="https://example.com/foto.jpg",
    type="image",
    caption="Veja esta foto!",
)

# Localizacao
client.messages.send_location(
    session_id="sess_abc",
    to="5511999999999@s.whatsapp.net",
    latitude=-23.5505,
    longitude=-46.6333,
    name="Sao Paulo",
)

# Enquete
client.messages.send_poll(
    session_id="sess_abc",
    to="5511999999999@s.whatsapp.net",
    question="Qual sua linguagem favorita?",
    options=["Python", "TypeScript", "Go"],
)

# Reacao
client.messages.send_reaction(
    session_id="sess_abc",
    to="5511999999999@s.whatsapp.net",
    message_id="msg_xyz",
    emoji="👍",
)
```

## Gerenciar Grupos

```python
# Criar grupo
group = client.groups.create(
    session_id="sess_abc",
    name="Equipe Vendas",
    participants=["5511999999999@s.whatsapp.net"],
)

# Adicionar participantes
client.groups.add_participants(
    session_id="sess_abc",
    group_id=group["id"],
    participants=["5511888888888@s.whatsapp.net"],
)

# Link de convite
link = client.groups.invite_link(session_id="sess_abc", group_id=group["id"])
```

## Webhooks

```python
# Registrar webhook
client.webhooks.create(
    url="https://meuapp.com/webhook",
    events=["message.received", "session.status"],
    secret="meu_segredo",
)

# Verificar assinatura no seu servidor
from zapapi import verify_signature

is_valid = verify_signature(
    body=request.body,          # bytes do body
    signature=request.headers["X-ZapApi-Signature"],
    secret="meu_segredo",
)
```

## Tratamento de Erros

```python
from zapapi import ZapApi, ZapApiError, RateLimitError, AuthenticationError

client = ZapApi(api_key="zap_live_...")

try:
    client.sessions.get("sess_inexistente")
except AuthenticationError:
    print("Chave de API invalida")
except RateLimitError as e:
    print(f"Rate limit — tente novamente em {e.retry_after}s")
except ZapApiError as e:
    print(f"Erro {e.status_code}: {e.message}")
```

## Context Manager

```python
# Sync
with ZapApi(api_key="zap_live_...") as client:
    client.sessions.list()

# Async
async with AsyncZapApi(api_key="zap_live_...") as client:
    await client.sessions.list()
```

## Links

- [Documentacao](https://docs.zapapi.net/sdks/python)
- [API Reference](https://docs.zapapi.net/api)
- [Dashboard](https://app.zapapi.net)
- [GitHub](https://github.com/willenrocha/zapapi-python)

## Licenca

MIT - [INOVIX](https://zapapi.net)
