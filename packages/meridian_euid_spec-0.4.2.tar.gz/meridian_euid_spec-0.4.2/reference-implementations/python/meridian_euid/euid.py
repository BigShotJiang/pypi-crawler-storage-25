from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Final

from .exceptions import EUIDChecksumError, EUIDDomainCodeError, EUIDFormatError
from .mod32 import ALPHABET_32, VALUE_32, mod32_check_character

BIGINT_MIN: Final[int] = 1
BIGINT_MAX: Final[int] = 9223372036854775807
TOKEN_MIN_LENGTH: Final[int] = 1
TOKEN_MAX_LENGTH: Final[int] = 4

# Crockford Base32 alphabet — 32 chars, excludes I/L/O/U everywhere.
_ALNUM32_RE = re.compile(r"^[0-9A-HJ-KMNP-TV-Z]+$")
_LOWERCASE_RE = re.compile(r"[a-z]")


@dataclass(frozen=True, slots=True)
class _ParsedEuid:
    domain_code: str
    prefix: str
    body: str
    checksum: str


def _validate_token(token: str, *, label: str, error_cls: type[EUIDFormatError]) -> str:
    if not isinstance(token, str):
        raise error_cls(f"{label} must be a string")
    if not (TOKEN_MIN_LENGTH <= len(token) <= TOKEN_MAX_LENGTH):
        raise error_cls(f"{label} must be 1-4 characters")
    if not _ALNUM32_RE.fullmatch(token):
        raise error_cls(
            f"{label} must use uppercase Crockford Base32 characters (no I/L/O/U)"
        )
    return token


def validate_domain_code(code: str) -> str:
    """Validate a Meridian domain code without normalizing it."""
    return _validate_token(code, label="domain code", error_cls=EUIDDomainCodeError)


def validate_prefix(prefix: str) -> str:
    """Validate a Meridian prefix token without normalizing it."""
    return _validate_token(prefix, label="prefix", error_cls=EUIDFormatError)


def _reject_input(euid: str) -> str:
    """Reject non-ASCII, whitespace, or lowercase characters."""
    if not euid.isascii():
        raise EUIDFormatError("EUID must be ASCII")
    if any(ch.isspace() for ch in euid):
        raise EUIDFormatError("whitespace is not permitted in EUID")
    if _LOWERCASE_RE.search(euid):
        raise EUIDFormatError("lowercase letters are not permitted in EUID")
    return euid


def _parse_canonical(euid: str) -> _ParsedEuid:
    if ":" in euid:
        raise EUIDFormatError("invalid EUID syntax")
    if euid.count("-") != 2:
        raise EUIDFormatError("invalid EUID syntax")

    domain_code, prefix, tail = euid.split("-", 2)
    validate_domain_code(domain_code)
    validate_prefix(prefix)

    if len(tail) < 2:
        raise EUIDFormatError("invalid EUID syntax")
    body, checksum = tail[:-1], tail[-1]

    if not body or body[0] == "0":
        raise EUIDFormatError("invalid EUID syntax")
    if not _ALNUM32_RE.fullmatch(body):
        raise EUIDFormatError("invalid EUID syntax")
    if checksum not in ALPHABET_32:
        raise EUIDFormatError("invalid EUID syntax")

    return _ParsedEuid(
        domain_code=domain_code,
        prefix=prefix,
        body=body,
        checksum=checksum,
    )


def compute_check_character(payload: str) -> str:
    """Compute the Meridian v0.4.0 check character for `payload`."""
    return mod32_check_character(payload)


def _int_to_base32(integer: int) -> str:
    if integer < BIGINT_MIN or integer > BIGINT_MAX:
        raise EUIDFormatError(f"integer must be between {BIGINT_MIN} and {BIGINT_MAX}")

    result: list[str] = []
    while integer > 0:
        result.append(ALPHABET_32[integer % 32])
        integer //= 32
    return "".join(reversed(result))


def _base32_to_int(body: str) -> int:
    integer = 0
    for ch in body:
        value = VALUE_32.get(ch)
        if value is None:
            raise EUIDFormatError(f"invalid Base32 character: {ch!r}")
        integer = integer * 32 + value
        if integer > BIGINT_MAX:
            raise EUIDFormatError(
                f"integer must be between {BIGINT_MIN} and {BIGINT_MAX}"
            )
    return integer


def validate(euid: str) -> str:
    """Validate a Meridian EUID and return its canonical string."""
    if not isinstance(euid, str):
        raise EUIDFormatError("EUID must be a string")

    candidate = _reject_input(euid)
    parsed = _parse_canonical(candidate)
    _base32_to_int(parsed.body)

    payload = f"{parsed.domain_code}{parsed.prefix}{parsed.body}"
    expected = mod32_check_character(payload)
    if parsed.checksum != expected:
        raise EUIDChecksumError("checksum mismatch")

    return f"{parsed.domain_code}-{parsed.prefix}-{parsed.body}{parsed.checksum}"


def is_valid(euid: str) -> bool:
    """Return True if `euid` is a valid canonical Meridian EUID."""
    try:
        validate(euid)
        return True
    except Exception:
        return False


def encode(integer: int, prefix: str, *, domain_code: str) -> str:
    """Encode an integer as a canonical Meridian EUID."""
    if not isinstance(integer, int) or isinstance(integer, bool):
        raise EUIDFormatError("integer must be an int")

    validated_domain = validate_domain_code(domain_code)
    validated_prefix = validate_prefix(prefix)
    body = _int_to_base32(integer)
    payload = f"{validated_domain}{validated_prefix}{body}"
    checksum = mod32_check_character(payload)
    return f"{validated_domain}-{validated_prefix}-{body}{checksum}"


def parse(euid: str) -> dict[str, object]:
    """Parse a canonical Meridian EUID into its structural components."""
    canonical = validate(euid)
    parsed = _parse_canonical(canonical)
    return {
        "domain_code": parsed.domain_code,
        "prefix": parsed.prefix,
        "body": parsed.body,
        "checksum": parsed.checksum,
        "integer": _base32_to_int(parsed.body),
    }
