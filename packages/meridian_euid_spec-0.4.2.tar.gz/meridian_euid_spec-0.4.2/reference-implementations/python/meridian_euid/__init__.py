"""Meridian EUID Python reference implementation."""

from .euid import (
    BIGINT_MAX,
    BIGINT_MIN,
    compute_check_character,
    encode,
    is_valid,
    parse,
    validate,
    validate_domain_code,
    validate_prefix,
)
from .exceptions import (
    EUIDChecksumError,
    EUIDDomainCodeError,
    EUIDError,
    EUIDFormatError,
    EUIDGovernanceError,
    EUIDIssuerAppCodeError,
    EUIDPrefixOwnershipError,
)
from .governance import (
    assert_prefix_issuer_app_code,
    assert_registered_domain,
    load_domain_registry,
    load_prefix_ownership_registry,
    resolve_prefix_issuer_app_code,
    validate_issuer_app_code,
    validate_registries_consistent,
)

from importlib.metadata import PackageNotFoundError, version as _get_version

try:
    __version__ = _get_version("meridian-euid")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"

__all__ = [
    "__version__",
    "BIGINT_MIN",
    "BIGINT_MAX",
    "compute_check_character",
    "encode",
    "is_valid",
    "parse",
    "validate",
    "validate_domain_code",
    "validate_prefix",
    "load_domain_registry",
    "load_prefix_ownership_registry",
    "assert_registered_domain",
    "validate_issuer_app_code",
    "resolve_prefix_issuer_app_code",
    "assert_prefix_issuer_app_code",
    "validate_registries_consistent",
    "EUIDError",
    "EUIDFormatError",
    "EUIDChecksumError",
    "EUIDDomainCodeError",
    "EUIDGovernanceError",
    "EUIDIssuerAppCodeError",
    "EUIDPrefixOwnershipError",
]
