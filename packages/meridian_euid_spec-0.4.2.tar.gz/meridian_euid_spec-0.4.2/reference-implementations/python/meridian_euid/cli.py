"""Meridian EUID command-line interface."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional, Sequence

from . import __version__
from .euid import compute_check_character, encode, parse, validate
from .exceptions import EUIDError


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Main CLI entry point. Returns exit code."""
    parser = argparse.ArgumentParser(
        prog="meridian-euid",
        description="Meridian EUID validator, encoder, and parser.",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate a canonical Meridian EUID",
    )
    validate_parser.add_argument("euid", help="The EUID to validate")

    check_parser = subparsers.add_parser(
        "compute-check",
        help="Compute check character for a checksum payload",
    )
    check_parser.add_argument(
        "payload",
        help="Checksum payload with no hyphens: DOMAIN+PREFIX+BODY",
    )

    encode_parser = subparsers.add_parser(
        "encode",
        help="Encode an integer as a Meridian EUID",
    )
    encode_parser.add_argument("integer", type=int, help="Integer to encode")
    encode_parser.add_argument(
        "prefix", help="Prefix token (1-4 uppercase Crockford Base32 characters)"
    )
    encode_parser.add_argument(
        "--domain-code",
        required=True,
        dest="domain_code",
        help="Domain token (1-4 uppercase Crockford Base32 characters)",
    )

    parse_parser = subparsers.add_parser(
        "parse",
        help="Parse an EUID into its components",
    )
    parse_parser.add_argument("euid", help="The EUID to parse")

    args = parser.parse_args(argv)

    commands = {
        "validate": cmd_validate,
        "compute-check": cmd_compute_check,
        "encode": cmd_encode,
        "parse": cmd_parse,
    }
    return commands[args.command](args)


def cmd_validate(args: argparse.Namespace) -> int:
    try:
        canonical = validate(args.euid)
        print(f"VALID: {canonical}")
        return 0
    except EUIDError as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        return 1


def cmd_compute_check(args: argparse.Namespace) -> int:
    try:
        check_char = compute_check_character(args.payload)
        print(check_char)
        return 0
    except (EUIDError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def cmd_encode(args: argparse.Namespace) -> int:
    try:
        euid = encode(args.integer, args.prefix, domain_code=args.domain_code)
        print(euid)
        return 0
    except (EUIDError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


def cmd_parse(args: argparse.Namespace) -> int:
    try:
        result = parse(args.euid)
        print(json.dumps(result, indent=2))
        return 0
    except (EUIDError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
