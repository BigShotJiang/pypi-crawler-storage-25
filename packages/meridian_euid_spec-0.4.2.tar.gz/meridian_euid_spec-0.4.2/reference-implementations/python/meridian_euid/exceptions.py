from __future__ import annotations


class EUIDError(ValueError):
    """Base error for Meridian EUID failures."""


class EUIDFormatError(EUIDError):
    """Raised when an EUID fails canonical syntax or token validation."""


class EUIDChecksumError(EUIDError):
    """Raised when an EUID fails checksum computation or verification."""


class EUIDDomainCodeError(EUIDFormatError):
    """Raised when a domain code is syntactically invalid."""


class EUIDGovernanceError(EUIDError):
    """Raised when registry-backed governance checks fail."""


class EUIDIssuerAppCodeError(EUIDGovernanceError):
    """Raised when an issuer_app_code is syntactically invalid."""


class EUIDPrefixOwnershipError(EUIDGovernanceError):
    """Raised when a prefix is unclaimed or claimed by a different issuer_app_code."""
