from __future__ import annotations

from importlib import resources
import json
from pathlib import Path
import re
from typing import Mapping

from .euid import validate_domain_code, validate_prefix
from .exceptions import (
    EUIDDomainCodeError,
    EUIDFormatError,
    EUIDGovernanceError,
    EUIDIssuerAppCodeError,
    EUIDPrefixOwnershipError,
)

_ISSUER_APP_CODE_RE = re.compile(r"^[a-z0-9]+(?:[._-][a-z0-9]+)*$")


def _read_registry_text(path: str | Path | None, filename: str) -> str:
    if path is not None:
        return Path(path).read_text(encoding="utf-8")
    return (
        resources.files("meridian_euid").joinpath(filename).read_text(encoding="utf-8")
    )


def validate_issuer_app_code(issuer_app_code: str) -> str:
    """Validate a lowercase ASCII issuer_app_code token."""
    if not isinstance(issuer_app_code, str):
        raise EUIDIssuerAppCodeError("issuer_app_code must be a string")
    if not _ISSUER_APP_CODE_RE.fullmatch(issuer_app_code):
        raise EUIDIssuerAppCodeError(
            "issuer_app_code must match ^[a-z0-9]+(?:[._-][a-z0-9]+)*$"
        )
    return issuer_app_code


def load_domain_registry(path: str | Path | None = None) -> frozenset[str]:
    """Load the checked-in domain registry and return registered domain codes."""
    data = json.loads(_read_registry_text(path, "domain_code_registry.json"))
    domains = data.get("domains")
    if not isinstance(domains, dict):
        raise EUIDGovernanceError("domain registry must contain an object at 'domains'")

    registered: set[str] = set()
    for domain_code in domains:
        try:
            validate_domain_code(domain_code)
        except EUIDDomainCodeError as exc:
            raise EUIDGovernanceError(
                f"domain registry contains invalid domain code {domain_code!r}: {exc}"
            ) from exc
        registered.add(domain_code)

    return frozenset(registered)


def load_prefix_ownership_registry(
    path: str | Path | None = None,
) -> dict[tuple[str, str], str]:
    """Load the checked-in prefix ownership registry as a flattened mapping."""
    data = json.loads(_read_registry_text(path, "prefix_ownership_registry.json"))
    ownership = data.get("ownership")
    if not isinstance(ownership, dict):
        raise EUIDGovernanceError(
            "prefix ownership registry must contain an object at 'ownership'"
        )

    loaded: dict[tuple[str, str], str] = {}
    for domain_code, claims in ownership.items():
        try:
            validate_domain_code(domain_code)
        except EUIDDomainCodeError as exc:
            raise EUIDGovernanceError(
                f"prefix ownership registry contains invalid domain code "
                f"{domain_code!r}: {exc}"
            ) from exc
        if not isinstance(claims, dict):
            raise EUIDGovernanceError(
                f"ownership entries for domain {domain_code!r} must be objects"
            )
        for prefix, claim in claims.items():
            try:
                validate_prefix(prefix)
            except EUIDFormatError as exc:
                raise EUIDGovernanceError(
                    f"prefix ownership registry contains invalid prefix {prefix!r} "
                    f"for domain {domain_code!r}: {exc}"
                ) from exc
            if not isinstance(claim, dict):
                raise EUIDGovernanceError(
                    f"claim for {(domain_code, prefix)!r} must be an object "
                    "containing 'issuer_app_code'"
                )
            issuer_app_code = claim.get("issuer_app_code")
            if issuer_app_code is None:
                raise EUIDGovernanceError(
                    f"claim for {(domain_code, prefix)!r} must contain "
                    "'issuer_app_code'"
                )
            loaded[(domain_code, prefix)] = validate_issuer_app_code(issuer_app_code)

    return loaded


def assert_registered_domain(
    domain_code: str,
    *,
    registry: frozenset[str] | None = None,
    path: str | Path | None = None,
) -> str:
    """Assert that a domain code exists in the checked-in registry."""
    validated = validate_domain_code(domain_code)
    registered = registry or load_domain_registry(path)
    if validated not in registered:
        raise EUIDGovernanceError(f"domain code {validated!r} is not registered")
    return validated


def resolve_prefix_issuer_app_code(
    domain_code: str,
    prefix: str,
    *,
    registry: Mapping[tuple[str, str], str] | None = None,
    path: str | Path | None = None,
) -> str:
    """Return the issuer_app_code for a claimed `(domain_code, prefix)` pair."""
    validated_domain = validate_domain_code(domain_code)
    validated_prefix = validate_prefix(prefix)
    ownership = registry or load_prefix_ownership_registry(path)
    try:
        return ownership[(validated_domain, validated_prefix)]
    except KeyError as exc:
        raise EUIDPrefixOwnershipError(
            f"prefix {validated_prefix!r} is not claimed in domain {validated_domain!r}"
        ) from exc


def assert_prefix_issuer_app_code(
    domain_code: str,
    prefix: str,
    issuer_app_code: str,
    *,
    registry: Mapping[tuple[str, str], str] | None = None,
    path: str | Path | None = None,
) -> str:
    """Assert that `issuer_app_code` is the registered claimant for a prefix."""
    validated_issuer_app_code = validate_issuer_app_code(issuer_app_code)

    actual_issuer_app_code = resolve_prefix_issuer_app_code(
        domain_code,
        prefix,
        registry=registry,
        path=path,
    )
    if actual_issuer_app_code != validated_issuer_app_code:
        raise EUIDPrefixOwnershipError(
            f"prefix {prefix!r} in domain {domain_code!r} is claimed by "
            f"{actual_issuer_app_code!r}, not {validated_issuer_app_code!r}"
        )
    return actual_issuer_app_code


def validate_registries_consistent(
    *,
    domain_registry_path: str | Path | None = None,
    prefix_ownership_registry_path: str | Path | None = None,
) -> None:
    """Validate that the checked-in governance registries agree with each other."""
    registered_domains = load_domain_registry(domain_registry_path)
    ownership = load_prefix_ownership_registry(prefix_ownership_registry_path)

    for domain_code, _prefix in ownership:
        if domain_code not in registered_domains:
            raise EUIDGovernanceError(
                f"domain code {domain_code!r} appears in prefix ownership registry "
                "but is not registered"
            )
