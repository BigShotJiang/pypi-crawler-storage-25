"""Tests for issuer_app_code and registry governance helpers."""

from __future__ import annotations

from importlib import resources
import json
from pathlib import Path
import subprocess
import sys

import pytest

from meridian_euid import (
    assert_prefix_issuer_app_code,
    assert_registered_domain,
    load_domain_registry,
    load_prefix_ownership_registry,
    resolve_prefix_issuer_app_code,
    validate_issuer_app_code,
    validate_registries_consistent,
    EUIDGovernanceError,
    EUIDIssuerAppCodeError,
    EUIDPrefixOwnershipError,
)


def _write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


class TestIssuerAppCodeValidation:
    def test_valid_issuer_app_code(self) -> None:
        assert validate_issuer_app_code("meridian.lims") == "meridian.lims"
        assert validate_issuer_app_code("ops_intake") == "ops_intake"
        assert validate_issuer_app_code("stress-suite") == "stress-suite"

    def test_invalid_issuer_app_code(self) -> None:
        with pytest.raises(EUIDIssuerAppCodeError, match="must match"):
            validate_issuer_app_code("Meridian.Lims")

        with pytest.raises(EUIDIssuerAppCodeError, match="must match"):
            validate_issuer_app_code("meridian..lims")


class TestRegistryHelpers:
    def test_load_domain_registry(self) -> None:
        registry = load_domain_registry()
        assert "A1" in registry
        assert "MAX" in registry

    def test_load_prefix_ownership_registry(self) -> None:
        registry = load_prefix_ownership_registry()
        assert registry[("A1", "Z9")] == "meridian.lims"

    def test_assert_registered_domain(self) -> None:
        assert assert_registered_domain("A1") == "A1"

    def test_assert_registered_domain_unknown(self) -> None:
        with pytest.raises(EUIDGovernanceError, match="not registered"):
            assert_registered_domain("Q2")

    def test_resolve_prefix_issuer_app_code(self) -> None:
        assert resolve_prefix_issuer_app_code("A1", "Z9") == "meridian.lims"

    def test_resolve_prefix_issuer_app_code_unknown(self) -> None:
        with pytest.raises(EUIDPrefixOwnershipError, match="not claimed"):
            resolve_prefix_issuer_app_code("A1", "N9")

    def test_assert_prefix_issuer_app_code(self) -> None:
        assert (
            assert_prefix_issuer_app_code("A1", "Z9", "meridian.lims")
            == "meridian.lims"
        )

    def test_assert_prefix_issuer_app_code_wrong_claimant(self) -> None:
        with pytest.raises(EUIDPrefixOwnershipError, match="claimed by"):
            assert_prefix_issuer_app_code("A1", "Z9", "other.owner")

    def test_packaged_registries_match_repo_root(self) -> None:
        repo_root = _repo_root()

        for filename in ("domain_code_registry.json", "prefix_ownership_registry.json"):
            packaged = json.loads(
                resources.files("meridian_euid")
                .joinpath(filename)
                .read_text(encoding="utf-8")
            )
            root_copy = json.loads((repo_root / filename).read_text(encoding="utf-8"))
            assert packaged == root_copy


class TestRegistryConsistency:
    def test_validate_registries_consistent(self) -> None:
        validate_registries_consistent()

    def test_unknown_domain_in_prefix_registry(self, tmp_path: Path) -> None:
        domain_registry_path = tmp_path / "domain_code_registry.json"
        prefix_registry_path = tmp_path / "prefix_ownership_registry.json"

        _write_json(
            domain_registry_path,
            {"version": "0.4.0", "domains": {"A1": {"description": "Example"}}},
        )
        _write_json(
            prefix_registry_path,
            {
                "version": "0.4.0",
                "ownership": {
                    "ZZ": {
                        "Z9": {"issuer_app_code": "meridian.lims"},
                    }
                },
            },
        )

        with pytest.raises(EUIDGovernanceError, match="appears in prefix ownership"):
            validate_registries_consistent(
                domain_registry_path=domain_registry_path,
                prefix_ownership_registry_path=prefix_registry_path,
            )

    def test_invalid_prefix_in_registry(self, tmp_path: Path) -> None:
        prefix_registry_path = tmp_path / "prefix_ownership_registry.json"

        _write_json(
            prefix_registry_path,
            {
                "version": "0.4.0",
                "ownership": {
                    "A1": {
                        "OU": {"issuer_app_code": "meridian.lims"},
                    }
                },
            },
        )

        with pytest.raises(EUIDGovernanceError, match="uppercase Crockford"):
            load_prefix_ownership_registry(prefix_registry_path)

    def test_invalid_issuer_app_code_in_registry(self, tmp_path: Path) -> None:
        prefix_registry_path = tmp_path / "prefix_ownership_registry.json"

        _write_json(
            prefix_registry_path,
            {
                "version": "0.4.0",
                "ownership": {
                    "A1": {
                        "Z9": {"issuer_app_code": "Meridian.Lims"},
                    }
                },
            },
        )

        with pytest.raises(EUIDIssuerAppCodeError, match="must match"):
            load_prefix_ownership_registry(prefix_registry_path)

    def test_missing_issuer_app_code_field(self, tmp_path: Path) -> None:
        prefix_registry_path = tmp_path / "prefix_ownership_registry.json"

        _write_json(
            prefix_registry_path,
            {
                "version": "0.4.0",
                "ownership": {
                    "A1": {
                        "Z9": {"owner": "meridian.lims"},
                    }
                },
            },
        )

        with pytest.raises(EUIDGovernanceError, match="must contain 'issuer_app_code'"):
            load_prefix_ownership_registry(prefix_registry_path)

    def test_wrong_claim_shape(self, tmp_path: Path) -> None:
        prefix_registry_path = tmp_path / "prefix_ownership_registry.json"

        _write_json(
            prefix_registry_path,
            {
                "version": "0.4.0",
                "ownership": {
                    "A1": {
                        "Z9": "meridian.lims",
                    }
                },
            },
        )

        with pytest.raises(EUIDGovernanceError, match="must be an object"):
            load_prefix_ownership_registry(prefix_registry_path)


class TestInstalledWheelGovernanceHelpers:
    def test_governance_helpers_work_from_installed_wheel(self, tmp_path: Path) -> None:
        package_root = Path(__file__).resolve().parents[1]
        wheel_dir = tmp_path / "wheelhouse"
        venv_dir = tmp_path / "venv"
        script_path = tmp_path / "check_governance.py"
        scripts_dir = "Scripts" if sys.platform == "win32" else "bin"

        subprocess.run(
            [
                sys.executable,
                "-m",
                "build",
                "--wheel",
                "--no-isolation",
                "--outdir",
                str(wheel_dir),
            ],
            cwd=package_root,
            check=True,
        )

        wheel_path = next(wheel_dir.glob("meridian_euid-*.whl"))

        subprocess.run(
            [sys.executable, "-m", "venv", str(venv_dir)],
            check=True,
        )

        venv_python = venv_dir / scripts_dir / "python"

        subprocess.run(
            [str(venv_python), "-m", "pip", "install", str(wheel_path)],
            check=True,
        )

        script_path.write_text(
            "\n".join(
                [
                    "import json",
                    "from meridian_euid import (",
                    "    load_domain_registry,",
                    "    load_prefix_ownership_registry,",
                    "    resolve_prefix_issuer_app_code,",
                    "    validate_registries_consistent,",
                    ")",
                    "",
                    "domains = load_domain_registry()",
                    "ownership = load_prefix_ownership_registry()",
                    "validate_registries_consistent()",
                    "print(json.dumps({",
                    '    "has_A1": "A1" in domains,',
                    '    "loaded_issuer": ownership[("A1", "Z9")],',
                    '    "resolved_issuer": resolve_prefix_issuer_app_code("A1", "Z9"),',
                    "}))",
                ]
            )
            + "\n",
            encoding="utf-8",
        )

        result = subprocess.run(
            [str(venv_python), str(script_path)],
            cwd=tmp_path,
            check=True,
            capture_output=True,
            text=True,
        )

        assert json.loads(result.stdout) == {
            "has_A1": True,
            "loaded_issuer": "meridian.lims",
            "resolved_issuer": "meridian.lims",
        }
