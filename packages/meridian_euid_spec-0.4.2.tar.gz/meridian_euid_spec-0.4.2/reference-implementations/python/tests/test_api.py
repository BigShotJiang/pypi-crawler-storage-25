"""Unit tests for canonical EUID API methods."""

from __future__ import annotations

import pytest

from meridian_euid import (
    BIGINT_MAX,
    compute_check_character,
    encode,
    is_valid,
    parse,
    validate,
    validate_domain_code,
    validate_prefix,
    EUIDChecksumError,
    EUIDDomainCodeError,
    EUIDFormatError,
)


class TestComputeCheckCharacter:
    def test_valid_payload(self) -> None:
        assert compute_check_character("001") == "Y"

    def test_empty_payload_raises(self) -> None:
        with pytest.raises(ValueError, match="non-empty"):
            compute_check_character("")

    def test_invalid_payload_char_raises(self) -> None:
        with pytest.raises(ValueError, match="invalid character"):
            compute_check_character("A1-Z9-1")

    def test_known_adjacent_transposition_blind_spot_inside_payload(self) -> None:
        assert validate("A1-Z9-10Z2") == "A1-Z9-10Z2"
        assert validate("A1-Z9-1Z02") == "A1-Z9-1Z02"

    def test_known_adjacent_transposition_blind_spot_at_checksum_boundary(self) -> None:
        assert validate("A1-Z9-40Z") == "A1-Z9-40Z"
        assert validate("A1-Z9-4Z0") == "A1-Z9-4Z0"


class TestValidate:
    def test_returns_canonical_string(self) -> None:
        assert validate("A1-Z9-3V9") == "A1-Z9-3V9"

    def test_lowercase_raises_format_error(self) -> None:
        with pytest.raises(EUIDFormatError, match="lowercase"):
            validate("a1-z9-1y")

    def test_non_string_raises_format_error(self) -> None:
        with pytest.raises(EUIDFormatError, match="must be a string"):
            validate(123)  # type: ignore[arg-type]

    def test_colon_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="syntax"):
            validate("A1:Z9-1Y")

    def test_missing_domain_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="domain code"):
            validate("-Z9-3V9")

    def test_missing_prefix_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="prefix"):
            validate("A1--3V9")

    def test_extra_hyphen_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="syntax"):
            validate("A1-Z9-3-V9")

    def test_checksum_mismatch_raises(self) -> None:
        with pytest.raises(EUIDChecksumError, match="checksum mismatch"):
            validate("A1-Z9-3VZ")

    def test_body_leading_zero_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="syntax"):
            validate("A1-Z9-01Y")

    def test_overflow_body_is_rejected(self) -> None:
        with pytest.raises(EUIDFormatError, match="between 1 and"):
            validate("A1-Z9-80000000000000Z")


class TestIsValid:
    def test_valid_returns_true(self) -> None:
        assert is_valid("A1-Z9-3V9") is True

    def test_invalid_returns_false(self) -> None:
        assert is_valid("A1-Z9-3VZ") is False

    def test_legacy_shape_returns_false(self) -> None:
        assert is_valid("DEV:DNA-ME9") is False
        assert is_valid("TX-1C") is False


class TestEncode:
    def test_basic_encode(self) -> None:
        assert encode(1, "Z9", domain_code="A1") == "A1-Z9-11"

    def test_encode_requires_domain(self) -> None:
        with pytest.raises(TypeError):
            encode(1, "Z9")  # type: ignore[call-arg]

    def test_zero_integer_raises(self) -> None:
        with pytest.raises(EUIDFormatError, match="between 1 and"):
            encode(0, "Z9", domain_code="A1")

    def test_overflow_integer_raises(self) -> None:
        with pytest.raises(EUIDFormatError, match="between 1 and"):
            encode(BIGINT_MAX + 1, "Z9", domain_code="A1")

    def test_lowercase_domain_raises(self) -> None:
        with pytest.raises(EUIDDomainCodeError, match="uppercase Crockford"):
            encode(1, "Z9", domain_code="a1")

    def test_lowercase_prefix_raises(self) -> None:
        with pytest.raises(EUIDFormatError, match="uppercase Crockford"):
            encode(1, "z9", domain_code="A1")

    def test_bool_integer_raises(self) -> None:
        with pytest.raises(EUIDFormatError, match="must be an int"):
            encode(True, "Z9", domain_code="A1")  # type: ignore[arg-type]


class TestParse:
    def test_parse_returns_prefix(self) -> None:
        result = parse("A1-Z9-3V9")
        assert result == {
            "domain_code": "A1",
            "prefix": "Z9",
            "body": "3V",
            "checksum": "9",
            "integer": 123,
        }

    def test_parse_bigint_max(self) -> None:
        result = parse("MAX-MAX-7ZZZZZZZZZZZZB")
        assert result["integer"] == BIGINT_MAX

    def test_parse_invalid_checksum_raises(self) -> None:
        with pytest.raises(EUIDChecksumError):
            parse("A1-Z9-3VZ")


class TestTokenValidation:
    def test_validate_domain_code_accepts_digits(self) -> None:
        assert validate_domain_code("0A") == "0A"

    def test_validate_domain_code_rejects_too_long(self) -> None:
        with pytest.raises(EUIDDomainCodeError, match="1-4"):
            validate_domain_code("ABCDE")

    def test_validate_prefix_accepts_single_char(self) -> None:
        assert validate_prefix("7") == "7"

    def test_validate_prefix_rejects_invalid_char(self) -> None:
        with pytest.raises(EUIDFormatError, match="uppercase Crockford"):
            validate_prefix("OU")
