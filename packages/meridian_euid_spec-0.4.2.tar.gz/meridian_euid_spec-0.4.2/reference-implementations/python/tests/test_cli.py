"""Tests for CLI commands."""

from __future__ import annotations

import json

import pytest

from meridian_euid.cli import main


class TestValidateCommand:
    def test_valid_euid(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["validate", "A1-Z9-3V9"])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert "VALID: A1-Z9-3V9" in captured.out

    def test_invalid_euid(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["validate", "A1-Z9-3VZ"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "INVALID" in captured.err

    def test_legacy_shape_rejected(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["validate", "DEV:DNA-ME9"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "INVALID" in captured.err


class TestComputeCheckCommand:
    def test_valid_payload(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["compute-check", "001"])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert captured.out.strip() == "Y"

    def test_invalid_payload(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["compute-check", "A1-Z9-1"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "ERROR" in captured.err


class TestEncodeCommand:
    def test_encode(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["encode", "1", "Z9", "--domain-code", "A1"])
        assert exit_code == 0
        captured = capsys.readouterr()
        assert captured.out.strip() == "A1-Z9-11"

    def test_missing_domain_code_argument(self) -> None:
        with pytest.raises(SystemExit):
            main(["encode", "1", "Z9"])

    def test_invalid_prefix_returns_error(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        exit_code = main(["encode", "1", "ou", "--domain-code", "A1"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "ERROR" in captured.err


class TestParseCommand:
    def test_parse(self, capsys: pytest.CaptureFixture[str]) -> None:
        exit_code = main(["parse", "A1-Z9-3V9"])
        assert exit_code == 0
        captured = capsys.readouterr()
        result = json.loads(captured.out)
        assert result["domain_code"] == "A1"
        assert result["prefix"] == "Z9"
        assert result["integer"] == 123

    def test_invalid_parse_returns_error(
        self, capsys: pytest.CaptureFixture[str]
    ) -> None:
        exit_code = main(["parse", "A1-Z9-3VZ"])
        assert exit_code == 1
        captured = capsys.readouterr()
        assert "ERROR" in captured.err
