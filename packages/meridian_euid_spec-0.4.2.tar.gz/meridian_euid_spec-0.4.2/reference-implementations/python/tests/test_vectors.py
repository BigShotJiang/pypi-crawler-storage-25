from __future__ import annotations

import json
import pathlib
import unittest

from meridian_euid import (
    assert_prefix_issuer_app_code,
    assert_registered_domain,
    is_valid,
    validate,
)


def _repo_root() -> pathlib.Path:
    here = pathlib.Path(__file__).resolve()
    return here.parents[3]


class TestVectorsV3(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        vectors_path = _repo_root() / "test-vectors" / "v3.json"
        cls.vectors = json.loads(vectors_path.read_text(encoding="utf-8"))

    def test_valid(self) -> None:
        for item in self.vectors["valid"]:
            euid = item["euid"]
            self.assertEqual(validate(euid), euid)
            self.assertTrue(is_valid(euid))

    def test_invalid(self) -> None:
        for item in self.vectors["invalid"]:
            euid = item["euid"]
            with self.assertRaises(Exception, msg=f"expected invalid: {item}"):
                validate(euid)

    def test_governance(self) -> None:
        for item in self.vectors["governance"]["registered_domains"]:
            self.assertEqual(
                assert_registered_domain(item["domain_code"]), item["domain_code"]
            )

        for item in self.vectors["governance"]["prefix_claims"]:
            self.assertEqual(
                assert_prefix_issuer_app_code(
                    item["domain_code"],
                    item["prefix"],
                    item["issuer_app_code"],
                ),
                item["issuer_app_code"],
            )


if __name__ == "__main__":
    unittest.main()
