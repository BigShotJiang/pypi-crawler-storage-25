# Test Vectors

Machine-readable test cases for validating Meridian EUID implementations.

## Purpose

The vectors define the shared contract for v0.4.0 canonical validation and basic governance examples. The Python reference implementation uses them in its test suite.

## File Format

### v3.json (current)

```json
{
  "meta": {
    "id": "meridian-euid-test-vectors-v3",
    "generated_on": "2026-04-15",
    "spec_version": "0.4.0",
    "checksum_system": "Luhn-style MOD 32 (Crockford Base32), payload = DOMAIN + PREFIX + BODY"
  },
  "valid": [...],
  "invalid": [...],
  "governance": {
    "registered_domains": [...],
    "prefix_claims": [...]
  }
}
```

### Sections

| Section | Description |
|---------|-------------|
| `meta` | Version and generation metadata |
| `valid` | Canonical EUIDs that MUST validate |
| `invalid` | Inputs that MUST be rejected |
| `governance.registered_domains` | Domain codes expected to exist in the checked-in registry |
| `governance.prefix_claims` | `(domain, prefix, issuer_app_code)` examples expected to resolve |

## Constraints (0.4.0)

- Canonical shape: `DOMAIN-PREFIX-BODYCHECKSUM`
- `DOMAIN`: 1-4 uppercase Crockford Base32 characters
- `PREFIX`: 1-4 uppercase Crockford Base32 characters
- `BODY/CHECKSUM` inventory: `0123456789ABCDEFGHJKMNPQRSTVWXYZ`
- Forbidden everywhere: `I`, `L`, `O`, `U`
- BODY integer range: `1..9223372036854775807`
- Lowercase input MUST be rejected
- Hyphens are validated structurally and are excluded from checksum computation
- `issuer_app_code` matches `^[a-z0-9]+(?:[._-][a-z0-9]+)*$`

## Example Entries

### Valid

```json
{
  "euid": "A1-Z9-3V9",
  "domain_code": "A1",
  "prefix": "Z9",
  "integer": 123
}
```

### Invalid

```json
{
  "euid": "A1:Z9-3V9",
  "reason": "':' separator is not allowed"
}
```

### Governance

```json
{
  "domain_code": "A1",
  "prefix": "Z9",
  "issuer_app_code": "meridian.lims"
}
```

## Usage in Tests

```python
import json
from pathlib import Path

from meridian_euid import assert_prefix_issuer_app_code, validate

vectors = json.loads(Path("test-vectors/v3.json").read_text())

for case in vectors["valid"]:
    assert validate(case["euid"]) == case["euid"]

for case in vectors["governance"]["prefix_claims"]:
    assert (
        assert_prefix_issuer_app_code(
            case["domain_code"],
            case["prefix"],
            case["issuer_app_code"],
        )
        == case["issuer_app_code"]
    )
```

## Related Documentation

- [SPEC.md](../SPEC.md) — Normative specification
- [Python README](../reference-implementations/python/README.md)
