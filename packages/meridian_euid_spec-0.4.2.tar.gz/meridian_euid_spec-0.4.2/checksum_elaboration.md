# Checksum Elaboration

Meridian keeps the checksum inside the same safe Crockford/Base32 alphabet used by the rest of the identifier:

`0123456789ABCDEFGHJKMNPQRSTVWXYZ`

## Why Meridian Does This

Using one alphabet keeps the operational model simple:

- printers and label templates only need one symbol set
- regexes and validators only need one token alphabet
- scanners and operator workflows do not have to special-case checksum-only symbols
- support documentation can describe one safe character inventory instead of a main alphabet plus an exception set

This matters more in practice than squeezing extra theoretical value out of a broader checksum symbol extension.

## Trade-Off

Meridian is choosing operational simplicity over adopting a checksum scheme that introduces extra checksum-only symbols.

That trade-off means:

- the checksum integrates cleanly into the printable string
- the canonical grammar stays small and easy to audit
- implementers do not need custom handling for extra checksum characters

Meridian still keeps delimiter mistakes visible because hyphens are validated structurally before checksum verification.

## Limitations

This checksum is a compact typo screen, not a strong integrity mechanism.

It catches many common input mistakes, but not all of them. Some adjacent transpositions remain valid under the MOD 32 check. For example, both `A1-Z9-10Z2` and `A1-Z9-1Z02` validate even though `0Z` has been transposed inside the payload.
