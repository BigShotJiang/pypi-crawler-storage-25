# Meridian: Enterprise Unique Identifier (EUID) Specification

[![Version](https://img.shields.io/badge/version-0.4.0-blue?style=flat-square)](https://github.com/lsmc-bio/meridian-euid/tags)

## Status of This Document

This document defines the Meridian Enterprise Unique Identifier (EUID) format, canonical representation, and validation rules.

This is a draft public standard. Implementations MAY adopt it, but implementers should expect clarifications and editorial corrections in future revisions.

The normative requirements of this specification use the terms **MUST**, **MUST NOT**, **SHOULD**, **SHOULD NOT**, and **MAY** as described in RFC 2119.

## 1. Scope

An EUID is a compact, scan-reliable identifier intended to label and reference physical and logical entities across an enterprise, including use in printed labels and barcodes.

This specification defines:

- The canonical `DOMAIN-PREFIX-BODYCHECKSUM` syntax.
- The canonical Crockford Base32 alphabet and character rules.
- Canonicalization and validation rules.
- A single-character MOD 32 checksum and its computation.
- The normative BODY integer range: `1..9223372036854775807`.
- Lightweight governance expectations for checked-in domain and prefix ownership registries.

This specification does not define:

- A database schema or storage engine.
- Business semantics encoded in the identifier string.
- A network governance service or dynamic registry protocol.
- GS1 syntax, GS1 application identifiers, or GS1 barcode profiles.

## 2. Problem Statement

Enterprise systems need identifiers that are short enough for labels, readable and transcribable by humans, safe to move through common operational tools, and robust against transcription and scanning errors.

Meridian addresses these constraints by combining:

- A fixed printable syntax.
- Strict canonical validation.
- A trailing checksum.
- A lookup-first design: the string is an identifier, not a source of business truth.

## 3. Design Goals and Non-Goals

### 3.1 Goals

A conforming Meridian EUID system:

- MUST support printing and scanning on typical laboratory and industrial label sizes.
- MUST be representable as plain ASCII without whitespace.
- MUST provide strong syntactic separation between `DOMAIN`, `PREFIX`, and `BODYCHECKSUM`.
- MUST include a checksum character that detects common input errors.
- MUST remain practical for sequence-backed issuance in PostgreSQL-backed systems.

### 3.2 Non-Goals

- Meridian EUIDs do not embed patient identity, workflow state, routing truth, or object metadata.
- Meridian EUIDs do not replace external partner or regulatory identifiers when those are separately required.
- Meridian EUIDs do not partially imitate GS1.

## 4. Terminology

- **Canonical form**: The exact rendered string defined by this document.
- **Domain code**: A 1-4 character token from the canonical alphabet. It is mandatory in every EUID.
- **Prefix**: A 1-4 character token from the canonical alphabet. It is mandatory in every EUID.
- **Body**: The Crockford Base32 encoding of a sequence-allocated integer in the range `1..9223372036854775807`.
- **Checksum**: The trailing single-character MOD 32 check symbol.
- **Issuer app code**: Lowercase ASCII governance token naming the issuing application or service. It is not part of the canonical EUID string and MUST match `^[a-z0-9]+(?:[._-][a-z0-9]+)*$`.
- **Resolver**: A system that uses `(DOMAIN, PREFIX)` registry information to route a lookup request.
- **Relying system**: Any system that accepts, stores, displays, transmits, or scans an EUID.

Historical note: the pre-0.4.0 specification used the term `CATEGORY`. This document replaces that term with `PREFIX` and treats it as an owned namespace token rather than as an authoritative classification.

Required identity statement (normative text for repo-wide reuse):

> Meridian does not use UUIDs. Internal identity is sequence-based. External identity is EUID-based.

## 5. Canonical Syntax

### 5.1 Grammar (authoritative)

An EUID has the form:

`DOMAIN-PREFIX-BODYCHECKSUM`

Where:

- `DOMAIN` is mandatory.
- `PREFIX` is mandatory.
- `BODYCHECKSUM` is mandatory.

Delimiter rules:

- `-` is the only legal separator.
- `-` MUST appear exactly twice.
- `:` MUST NOT appear.

### 5.2 Character inventory

Meridian uses the Crockford Base32 safe alphabet:

`0123456789ABCDEFGHJKMNPQRSTVWXYZ`

Forbidden everywhere:

`I`, `L`, `O`, `U`

### 5.3 Component constraints

Domain code constraints:

- `DOMAIN` MUST be 1-4 characters from the canonical alphabet.
- `DOMAIN` MAY include digits, including leading digits.

Prefix constraints:

- `PREFIX` MUST be 1-4 characters from the canonical alphabet.
- `PREFIX` MAY include digits, including leading digits.

Body constraints:

- `BODY` MUST be the Crockford Base32 encoding of an integer in the inclusive range `1..9223372036854775807`.
- `BODY` MUST be unpadded.
- `BODY` MUST NOT begin with `0`.

Checksum constraints:

- `CHECKSUM` MUST be exactly 1 character from the canonical alphabet.

### 5.4 Canonical regex

The following regex describes the canonical string form:

`^(?:[0-9A-HJ-KMNP-TV-Z]{1,4})-(?:[0-9A-HJ-KMNP-TV-Z]{1,4})-(?:[1-9A-HJ-KMNP-TV-Z][0-9A-HJ-KMNP-TV-Z]*)[0-9A-HJ-KMNP-TV-Z]$`

This regex checks canonical structure and token alphabets. Implementations MUST additionally enforce the BODY integer upper bound defined in Section 5.3.

## 6. Checksum

### 6.1 Purpose

The checksum is intended to detect common errors in manual transcription, copy/paste, OCR, and barcode scanning.

It is a compact accidental-typo screen, not a cryptographic integrity mechanism, authenticity signal, or tamper-proofing measure.

Like other single-character Luhn-style checks, it does not detect every possible input error. In particular, some adjacent transpositions remain undetected.

### 6.2 Character-to-value mapping

Each checksum character maps to its index in the canonical alphabet:

`0123456789ABCDEFGHJKMNPQRSTVWXYZ`

So `0 -> 0`, `1 -> 1`, ..., `9 -> 9`, `A -> 10`, ..., `Z -> 31` (skipping forbidden letters).

Implementations MUST reject any character outside the canonical alphabet.

### 6.3 Checksum payload

Checksum payload is:

`DOMAIN + PREFIX + BODY`

The rendered hyphens are excluded from checksum computation. Hyphen count and placement are validated structurally by syntax rules in Section 5.

### 6.4 Checksum type

Meridian uses a single-character Luhn-style MOD 32 checksum aligned to the canonical alphabet.

### 6.5 Luhn-style MOD 32 algorithm (normative)

Given a non-empty checksum payload string `payload` consisting only of characters in the canonical alphabet:

1. Initialize `sum = 0`.
2. Process `payload` from right to left.
3. For the rightmost character of `payload`, use factor `2`, then alternate factors `1, 2, 1, 2, ...` moving left.
4. For each character:
   - Map the character to value `v` in the range `0..31`.
   - Compute `p = v * factor`.
   - Add the base-32 digit-sum of `p` to `sum`:
     - `sum += floor(p / 32) + (p mod 32)`
     - Because `factor` is 1 or 2, this is equivalent to `sum += p` when `p < 32`, else `sum += p - 31`.
5. Compute `check_value = (32 - (sum mod 32)) mod 32`.
6. Map `check_value` back to a character using the canonical alphabet. This is `CHECKSUM`.

Verification:

- An EUID is checksum-valid if the computed checksum equals the presented checksum.

## 7. Canonicalization and Validation

### 7.1 Canonicalization

Issuers MUST output canonical uppercase form.

Validators MUST reject:

- Lowercase ASCII letters.
- Whitespace, whether leading, trailing, or internal.
- Non-ASCII input.
- Any attempt at tolerant decoding, trimming, character substitution, or omitted components.

Validators MUST NOT:

- Auto-uppercase input.
- Trim input.
- Rewrite visually similar characters.
- Accept partial EUIDs.

### 7.2 Validation order

A relying system that accepts EUID input MUST validate in the following order:

1. **Input rejection**: reject non-ASCII, whitespace, and lowercase characters.
2. **Syntax validation**: confirm exact canonical structure, delimiter placement, token alphabets, and token length constraints.
3. **BODY range validation**: confirm that BODY decodes to an integer in `1..9223372036854775807`.
4. **Checksum verification**: compute the check character per Section 6 and compare it to the presented checksum.
5. **Optional governance and lookup checks**: perform registry checks, ownership checks, and backing-system lookup if required by the calling system.

Failure at any step MUST result in immediate rejection.

## 8. Issuance Model

Meridian does not use UUIDs. Internal identity is sequence-based. External identity is EUID-based.

Issuing systems SHOULD treat BODY as an opaque, monotonically increasing value allocated by a PostgreSQL `BIGINT` sequence or equivalent signed 64-bit identity allocator.

Meridian does not impose a hard allocator scope. The monotone allocator MAY be global, per-domain, per-prefix, or shared across any chosen set of prefixes or apps, at the issuing domain's discretion.

A common expected operating pattern is per app or per app-managed prefix set, but that is not normative.

Relative ordering guarantees apply only within identifiers issued by the same allocator scope.

Issuers MUST NOT:

- Encode arbitrary-precision integers beyond the signed PostgreSQL `BIGINT` maximum.
- Derive BODY from patient identifiers, accessions, vendor identifiers, or other external identifiers.
- Embed workflow meaning or authoritative business meaning into the EUID string.

## 9. Prefix Ownership and Resolver Routing

`PREFIX` is a domain-unique ownership token.

The prefix governance model is:

- Each `(DOMAIN, PREFIX)` pair MUST be owned by exactly one issuer app code.
- Prefixes are allocated, not inherited.
- Apps MAY own multiple prefixes.
- Multiple apps in the same domain MUST NOT share a generic common prefix for issuance.

Resolvers MAY route on `(DOMAIN, PREFIX)` if a registry is configured to support that behavior.

Resolver routing is governance behavior, not business truth:

- `(DOMAIN, PREFIX)` MAY select a likely owner or resolver path.
- `(DOMAIN, PREFIX)` MUST NOT be treated as authoritative proof of object type, assay, workflow state, or business semantics.
- All authoritative meaning MUST be obtained by lookup in the backing system.

Humans MAY form passive expectations based on familiar prefixes. Software MUST NOT treat those expectations as authoritative truth.

## 10. Governance Registries

This specification defines a deliberately lightweight governance mechanism based on checked-in JSON files:

- [domain_code_registry.json](domain_code_registry.json)
- [prefix_ownership_registry.json](prefix_ownership_registry.json)

The current governance posture is:

- Domain code governance is the checked-in domain registry JSON.
- Prefix ownership governance is the checked-in prefix ownership JSON.
- `issuer_app_code` values in the ownership registry MUST match `^[a-z0-9]+(?:[._-][a-z0-9]+)*$`.
- Ownership registry leaf entries use explicit objects, for example: `"Z9": { "issuer_app_code": "meridian.lims" }`.
- Registry updates MAY remain manual.

Issuing or claiming behavior SHOULD fail if:

- `DOMAIN` is not present in the domain registry.
- `(DOMAIN, PREFIX)` is not present in the ownership registry.
- The attempting issuer app code does not match the registered `issuer_app_code` for `(DOMAIN, PREFIX)`.

Implementations SHOULD also validate registry consistency, including that every domain referenced by the ownership registry exists in the domain registry.

These registry checks are optional with respect to canonical string validity, but they are the expected governance path for real issuance and routing.

## 11. Leakage Policy

Seeing a Meridian EUID intentionally reveals only limited structural information:

Allowed visible leakage:

- Domain code.
- Prefix token.
- Relative monotone ordering for identifiers that share the same allocator scope.

Not encoded as authoritative meaning:

- Patient identity.
- Workflow state.
- Specimen status.
- Assay meaning as authoritative truth.
- External accession identifiers.
- Vendor identifiers.
- Internal object metadata beyond what the system separately exposes.

No authoritative business logic may be derived from the string alone.

Software MUST NOT infer cross-domain or cross-prefix ordering unless the compared identifiers are known to come from the same allocator scope.

If a future external-facing deployment needs lower leakage, that need MUST be addressed with a separate external alias or profile, not by overloading the canonical Meridian syntax.

## 12. Relationship to GS1

Meridian is an internal enterprise identifier scheme.

Meridian is **not** a GS1 identification key.

A barcode carrying a Meridian string is **not** a GS1 barcode unless a future Meridian profile explicitly adopts GS1 syntax and GS1 application identifier rules.

GS1 identifiers, when relevant, SHOULD be treated as external identifiers associated with Meridian-managed objects.

Meridian MUST NOT partially imitate GS1. Meridian and GS1 MAY coexist on the same labeled object, but they remain distinct identifier systems with distinct governance and syntax rules.

Future GS1 interoperability, if needed, MUST be addressed by a separate profile rather than by changing the canonical Meridian syntax defined in this document.

## 13. Labels and Barcodes

If an EUID is encoded in a barcode, the encoded data MUST include the full canonical string, including the checksum character.

Barcode symbology choice is outside the normative scope of this specification. See [meridian_clinical_lab_profile.md](meridian_clinical_lab_profile.md) for minimal operational guidance.

## 14. Prohibited Practices

Relying systems and issuers MUST NOT:

- Accept lowercase input.
- Accept `:` as a valid separator.
- Accept EUIDs missing DOMAIN or PREFIX.
- Auto-correct malformed identifiers.
- Reuse or reassign EUIDs.
- Strip or rewrite DOMAIN or PREFIX tokens.
- Treat PREFIX as authoritative business semantics.
- Treat registry routing as a substitute for backing-system lookup.
- Extend BODY beyond the signed PostgreSQL `BIGINT` range.

## 15. Change Control

Any change to any of the following MUST be treated as a breaking change and requires a new major version:

- Canonical syntax or delimiter rules.
- DOMAIN, PREFIX, BODY, or CHECKSUM token constraints.
- Checksum algorithm or checksum payload scope.
- Canonical alphabet or forbidden-character rules.
- BODY integer range.

## Appendix A. Examples (Non-Normative)

See [test-vectors/v3.json](test-vectors/v3.json) for machine-verified examples used by the Python reference implementation.
