# Changelog

All notable changes to this project are documented in this file.

This project follows [Semantic Versioning](https://semver.org/) for the specification and reference implementations.

## [Unreleased]

_No unreleased changes._

## [0.4.1] - 2026-04-15

### Fixed
- Bundled the governance registries inside the Python wheel so `load_domain_registry()` and `load_prefix_ownership_registry()` work without explicit paths after installation.
- Added an install-from-wheel test that exercises the no-argument governance helper flow outside the source tree.

### Changed
- Clarified that BODY monotonicity is allocator-scope dependent and chosen at domain discretion rather than fixed globally, per-domain, or per-prefix.
- Tightened the checksum and leakage text to state that the single-character MOD 32 checksum is a compact typo screen only and does not detect every adjacent transposition.

## [0.4.0] - 2026-04-15

### Changed
- Replaced the old mixed-shape model with one canonical EUID syntax: `DOMAIN-PREFIX-BODYCHECKSUM`.
- Made `DOMAIN` and `PREFIX` mandatory 1-4 character Crockford/Base32 tokens drawn from `0123456789ABCDEFGHJKMNPQRSTVWXYZ`.
- Made the BODY integer range normative and limited it to signed PostgreSQL `BIGINT`: `1..9223372036854775807`.
- Kept the Luhn-style MOD 32 checksum, but fixed the payload to `DOMAIN + PREFIX + BODY` with hyphens excluded.
- Reframed `CATEGORY` as `PREFIX` and documented prefix ownership as a domain-unique governance model.
- Added lightweight checked-in governance registries:
  - `domain_code_registry.json`
  - `prefix_ownership_registry.json`
- Added supporting docs:
  - `meridian_clinical_lab_profile.md`
  - `checksum_elaboration.md`
- Rebuilt the Python reference implementation around a single-format API with separate governance helpers.
- Replaced `test-vectors/v2.json` with `test-vectors/v3.json`.

### Removed
- Absent-domain EUIDs.
- `:` as a legal separator.
- Production/domain environment switching in the Python API and CLI.
- Sandbox terminology, aliases, and other compatibility surfaces.
- The supported TypeScript reference implementation and its CI workflow.

## [0.3.2] - 2026-04-05

### Changed
- Made `domain` / `domain_code` the primary public terminology across the spec, shared vectors, and repository docs.
- Aligned the repository on the strict 0.3.2 alphabet policy:
  - letters-only code alphabet: `ABCDEFGHJKMNPQRSTVWXYZ`
  - full 32-symbol inventory: `0123456789ABCDEFGHJKMNPQRSTVWXYZ`
- Removed `PROD` from claimed-code examples and registry text because `O` is forbidden and therefore invalid.
- Migrated the TypeScript reference implementation from sandbox-first terminology and single-letter sandbox rules to the 0.3 domain-code model.
- Updated the shared vector contract to use `valid_domain` and `allowed_domain_codes`, including multi-character domain-code cases.
- Added TypeScript CI so shared-vector and implementation drift is caught alongside Python CI.
- Expanded ignore rules for macOS/Windows filesystem junk that should never affect release artifacts.

### Fixed
- Removed the unused Python backward-compatibility import that caused `ruff check` to fail.
- Corrected stale 0.1/0.2 version references in docs, vectors, and TypeScript package metadata.

## [0.1.0pre] - 2026-02-08

### Added
- `encode()` function: integer + category + sandbox? -> EUID (Python, TypeScript)
- `parse()` function: EUID -> components + decoded integer (Python, TypeScript)
- Python CLI `encode` and `parse` subcommands
- §12 Operational Role of Structural Components (SPEC.md)
- §16 Checksum Error Detection Properties (SPEC.md)
- GitHub Actions CI workflow for Python implementation
- `ruff` formatting and `mypy` type checking

### Changed
- SPEC.md rewritten (new grammar: `[SANDBOX ":"] CATEGORY "-" BODY CHECKSUM`)
- CATEGORY minimum length: 1 -> 2 characters (now 2-3)
- Reserved sandbox prefixes expanded: A only -> A-G inclusive (7 reserved, 15 available)
- Uppercase-only enforcement: lowercase input MUST be rejected (no normalization)
- Checksum system changed to Luhn-style MOD 32 over Crockford Base32 (SPEC.md §7.5)
- V2_SPEC.md renamed to SPEC.md (all cross-references resolved)
- Test vectors regenerated with 2-char+ categories, expanded coverage (30 cases)
- Validation order clarified: input rejection -> syntax -> checksum -> authorization
- Coverage threshold lowered from 100% to 75% (88% achieved)

### Removed
- Legacy v1 test vectors file (`test-vectors/v1.json`)
- Lowercase normalization (replaced with strict rejection)

## [1.0.0-draft] - 2026-02-04

### Added
- Initial public draft of the Meridian EUID specification ([SPEC.md](SPEC.md))
- Machine-readable test vectors v1 (deprecated; removed in 0.1.0pre — see git history)
- Non-normative Python reference implementation
- Non-normative TypeScript reference implementation
- CC BY 4.0 license for specification content

### Specification Highlights
- Production and sandbox EUID syntax with strict environment segregation
- ISO/IEC 7064 MOD 37-2 checksum with supplementary character `*` forbidden
- Canonical form enforcement (uppercase only, no normalization)
