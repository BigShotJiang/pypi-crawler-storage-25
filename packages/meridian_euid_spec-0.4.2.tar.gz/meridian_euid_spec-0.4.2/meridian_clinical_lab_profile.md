# Meridian Clinical Lab Profile

This profile gives minimal operational guidance for rendering Meridian EUIDs in clinical lab settings.

## Canonical Rendering

Meridian EUIDs are rendered in human-readable form exactly as their canonical strings.

Example:

`A1-Z9-3V9`

Do not remove hyphens, shorten tokens, or substitute alternate text on the human-readable label line.

## Recommended Machine-Readable Carriers

Recommended barcode carriers for raw Meridian payloads:

- Code 128
- Data Matrix ECC 200

Both carriers SHOULD encode the raw canonical Meridian string exactly as rendered, including hyphens and checksum.

## GS1 Posture

These are non-GS1 payloads.

Do not call them:

- GS1-128
- GS1 DataMatrix

unless a future Meridian GS1 profile explicitly adopts GS1 syntax and application identifier rules.
