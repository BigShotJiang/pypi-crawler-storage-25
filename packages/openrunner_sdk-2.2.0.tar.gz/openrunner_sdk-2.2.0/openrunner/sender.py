"""Background sender thread for flushing metrics and sending heartbeats.

The sender runs as a daemon thread that:
- Flushes the write buffer when size >= threshold or interval elapsed
- Sends heartbeat signals at a configured interval
- Drains remaining buffer on stop()

All operations are defensive -- exceptions are logged as warnings
and never crash the sender thread or caller.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from openrunner.api_client import APIClient
    from openrunner.buffer import WriteBuffer
    from openrunner.offline import OfflineStorage
    from openrunner.wal import WriteAheadLog

logger = logging.getLogger("openrunner")


class Sender:
    """Background thread that flushes the write buffer to the server."""

    def __init__(
        self,
        buffer: WriteBuffer,
        client: APIClient,
        run_id: str,
        flush_interval: float = 5.0,
        flush_threshold: int = 100,
        heartbeat_interval: float = 30.0,
        system_metrics_interval: float = 15.0,
        system_metrics_enabled: bool = True,
        offline_storage: OfflineStorage | None = None,
        wal: WriteAheadLog | None = None,
    ) -> None:
        self._buffer = buffer
        self._client = client
        self._run_id = run_id
        self._offline_storage = offline_storage
        self._wal = wal
        self._consecutive_failures = 0
        self._flush_interval = flush_interval
        self._flush_threshold = flush_threshold
        self._heartbeat_interval = heartbeat_interval
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run, daemon=True, name="openrunner-sender"
        )
        self._last_flush_time = time.monotonic()
        self._last_heartbeat = 0.0

        # Console log buffer (Feature 1: log capture)
        self._console_buffer: list[dict] = []
        self._console_lock = threading.Lock()

        # Stop signal from server (Feature 2: stop/abort)
        self._stop_requested = False

        # System metrics
        self._system_metrics_enabled = system_metrics_enabled
        self._system_metrics = None
        self._system_metrics_interval = system_metrics_interval
        self._last_system_sample = 0.0
        self._system_step = 0
        if self._system_metrics_enabled:
            try:
                from openrunner.system_metrics import SystemMetrics
                self._system_metrics = SystemMetrics()
            except Exception:
                logger.debug("System metrics init failed, disabling")
                self._system_metrics_enabled = False

    def start(self) -> None:
        """Start the background sender thread.

        If a WAL is configured, replays any un-acked entries from a
        previous crash before starting the normal flush loop.
        """
        self._last_flush_time = time.monotonic()
        self._last_heartbeat = time.monotonic()
        # Replay WAL entries from a previous crash
        if self._wal is not None:
            self._replay_wal()
        self._thread.start()

    def _replay_wal(self) -> None:
        """Replay un-acked WAL entries from a previous session."""
        try:
            entries = self._wal.replay()
            if not entries:
                return
            logger.info("Replaying %d WAL entries for run %s", len(entries), self._run_id)
            for entry in entries:
                entry_type = entry.get("type")
                data = entry.get("data")
                seq = entry.get("seq")
                try:
                    if entry_type == "metrics" and data:
                        self._client.post_metrics(self._run_id, data)
                    self._wal.ack(seq)
                except Exception as e:
                    logger.warning("WAL replay failed for seq %s: %s", seq, e)
        except Exception as e:
            logger.warning("WAL replay error: %s", e)

    def stop(self, timeout: float = 30.0) -> None:
        """Signal stop, join thread, and drain remaining buffer."""
        self._stop_event.set()
        self._thread.join(timeout=timeout)
        # Final drain after thread exits
        self._flush()
        self._flush_console_logs()
        # Close offline storage if present
        if self._offline_storage is not None:
            self._offline_storage.close()
        # Clean up system metrics (NVML shutdown)
        if self._system_metrics is not None:
            self._system_metrics.shutdown()

    def _run(self) -> None:
        """Main sender loop -- runs in a background thread."""
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=1.0)

            # Check flush conditions
            if self._should_flush():
                self._flush()
                self._flush_console_logs()

            # Check heartbeat
            if self._should_heartbeat():
                self._send_heartbeat()

            # Check system metrics
            if self._should_sample_system():
                self._sample_system_metrics()

        # Final drain on shutdown (thread-side)
        self._flush()
        self._flush_console_logs()

    def _flush(self) -> None:
        """Drain the buffer and send metrics and media to the server.

        Partitions the batch into regular metrics and media items.
        Metrics are sent via post_metrics as before. Media items
        (Image, Table) are uploaded individually via create_media_file.

        When offline_storage is set, writes metrics to disk instead of HTTP.
        Media items are skipped in offline mode (logged as warning).
        """
        batch = self._buffer.drain()
        if not batch:
            return

        # Partition into metrics and media
        metrics = []
        media_items = []
        for item in batch:
            if item.get("_media"):
                media_items.append(item)
            else:
                metrics.append(item)

        # Offline branch: write to disk
        if self._offline_storage is not None:
            if metrics:
                try:
                    self._offline_storage.append_metrics(metrics)
                except Exception as e:
                    logger.warning("Failed to write offline metrics: %s", e)
            if media_items:
                logger.warning(
                    "Skipping %d media items in offline mode", len(media_items)
                )
            self._last_flush_time = time.monotonic()
            return

        # Online branch: send via HTTP
        if metrics:
            # Write to WAL before sending (crash recovery)
            wal_seq = None
            if self._wal is not None:
                try:
                    wal_seq = self._wal.write("metrics", metrics)
                except Exception as e:
                    logger.warning("WAL write failed: %s", e)

            try:
                self._client.post_metrics(self._run_id, metrics)
                self._consecutive_failures = 0
                # Ack WAL entry on success
                if wal_seq is not None and self._wal is not None:
                    self._wal.ack(wal_seq)
            except Exception as e:
                self._consecutive_failures += 1
                logger.warning(
                    "Failed to flush metrics (%d consecutive): %s",
                    self._consecutive_failures,
                    e,
                )

                if self._consecutive_failures >= 3:
                    # Auto-fallback to offline mode
                    if self._offline_storage is None:
                        logger.warning(
                            "Switching to offline mode after %d failures",
                            self._consecutive_failures,
                        )
                        from openrunner.offline import OfflineStorage
                        self._offline_storage = OfflineStorage.for_run(self._run_id)

                # Write to offline storage if available, otherwise re-queue
                if self._offline_storage is not None:
                    try:
                        self._offline_storage.append_metrics(metrics)
                    except Exception as oe:
                        logger.warning("Offline write also failed: %s", oe)
                else:
                    for m in metrics:
                        self._buffer.put(m)

        # Process media items
        for item in media_items:
            try:
                self._process_media_item(item)
            except Exception as e:
                logger.warning("Failed to process media item: %s", e)

        self._last_flush_time = time.monotonic()

    def _process_media_item(self, item: dict) -> None:
        """Handle a single media item (image, table, audio, video, etc.)."""
        media_type = item.get("_media_type")

        if media_type == "image":
            # Serialize the Image object (lazy -- happens here in sender thread)
            image_obj = item["_image_obj"]
            img_bytes, content_type = image_obj._serialize()

            # Collect overlay metadata (masks, boxes) if present
            overlay_data = None
            if hasattr(image_obj, "_get_overlay_data"):
                overlay_data = image_obj._get_overlay_data()

            # Create media file record on server
            result = self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="image",
                step=item.get("step"),
                caption=item.get("caption"),
                content_type=content_type,
                data=overlay_data,
            )
            if result and result.get("presigned_url"):
                # Upload the bytes to the presigned URL
                self._client.upload_media_bytes(
                    result["presigned_url"], img_bytes, content_type
                )

        elif media_type == "table":
            # Table data is already serialized -- send inline
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="table",
                step=item.get("step"),
                data=item.get("_table_data"),
            )

        elif media_type == "audio":
            # Serialize Audio object to WAV bytes
            audio_obj = item["_audio_obj"]
            audio_bytes, content_type = audio_obj._serialize()

            result = self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="audio",
                step=item.get("step"),
                caption=item.get("caption"),
                content_type=content_type,
            )
            if result and result.get("presigned_url"):
                self._client.upload_media_bytes(
                    result["presigned_url"], audio_bytes, content_type
                )

        elif media_type == "video":
            # Serialize Video object to MP4/WebM bytes
            video_obj = item["_video_obj"]
            video_bytes, content_type = video_obj._serialize()

            result = self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="video",
                step=item.get("step"),
                caption=item.get("caption"),
                content_type=content_type,
            )
            if result and result.get("presigned_url"):
                self._client.upload_media_bytes(
                    result["presigned_url"], video_bytes, content_type
                )

        elif media_type == "histogram":
            # Histogram data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="histogram",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_histogram_data"),
            )

        elif media_type == "plotly":
            # Plotly data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="plotly",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_plotly_data"),
            )

        elif media_type == "point_cloud_3d":
            # Point cloud data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="point_cloud_3d",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_point_cloud_data"),
            )

        elif media_type == "html":
            # HTML data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="html",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_html_data"),
            )

        elif media_type == "embedding":
            # Embedding data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="embedding",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_embedding_data"),
            )

        elif media_type == "transcript":
            # Transcript data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="transcript",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_transcript_data"),
            )

        elif media_type == "audio_comparison":
            # Audio comparison metadata -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="audio_comparison",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_comparison_data"),
            )

        elif media_type == "bounding_boxes_2d":
            # BBox: upload the image first, then store box data as JSONB
            bbox_obj = item["_bbox_obj"]
            img_bytes, content_type = bbox_obj._serialize_image()

            # Create media file for the image + bbox overlay
            result = self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="bounding_boxes_2d",
                step=item.get("step"),
                caption=item.get("caption"),
                content_type=content_type,
                data=bbox_obj._serialize_boxes(),
            )
            if result and result.get("presigned_url"):
                self._client.upload_media_bytes(
                    result["presigned_url"], img_bytes, content_type
                )

        elif media_type == "molecule":
            # Molecule data is already serialized -- send inline as JSONB
            self._client.create_media_file(
                run_id=self._run_id,
                key=item["key"],
                media_type="molecule",
                step=item.get("step"),
                caption=item.get("caption"),
                data=item.get("_molecule_data"),
            )

    def _should_flush(self) -> bool:
        """Return True if flush conditions are met."""
        if self._buffer.size >= self._flush_threshold:
            return True
        elapsed = time.monotonic() - self._last_flush_time
        return elapsed >= self._flush_interval

    def _should_heartbeat(self) -> bool:
        """Return True if heartbeat interval has elapsed."""
        return (time.monotonic() - self._last_heartbeat) >= self._heartbeat_interval

    def add_console_line(self, timestamp: str, stream: str, text: str) -> None:
        """Add a console log line to the buffer (thread-safe)."""
        with self._console_lock:
            self._console_buffer.append({
                "timestamp": timestamp,
                "stream": stream,
                "line": text,
            })

    def _flush_console_logs(self) -> None:
        """Send buffered console log lines to the server."""
        with self._console_lock:
            if not self._console_buffer:
                return
            batch = list(self._console_buffer)
            self._console_buffer.clear()

        if self._offline_storage is not None:
            # TODO: offline console log storage
            return

        try:
            self._client.post_logs(self._run_id, batch)
        except Exception as e:
            logger.warning("Failed to flush console logs: %s", e)

    def _send_heartbeat(self) -> None:
        """Send heartbeat to the server and check for stop signal."""
        try:
            result = self._client.post_heartbeat(self._run_id)
            self._last_heartbeat = time.monotonic()
            if result and result.get("stop_requested"):
                self._stop_requested = True
                logger.info("Stop requested by server for run %s", self._run_id)
        except Exception as e:
            logger.warning("Heartbeat failed: %s", e)

    def _should_sample_system(self) -> bool:
        """Return True if system metrics should be sampled."""
        if not self._system_metrics_enabled or self._system_metrics is None:
            return False
        return (time.monotonic() - self._last_system_sample) >= self._system_metrics_interval

    def _sample_system_metrics(self) -> None:
        """Collect system metrics and queue them in the buffer."""
        assert self._system_metrics is not None
        try:
            metrics = self._system_metrics.sample()
            if metrics:
                timestamp = datetime.now(timezone.utc).isoformat()
                for key, value in metrics.items():
                    self._buffer.put({
                        "key": key,
                        "value": value,
                        "step": self._system_step,
                        "timestamp": timestamp,
                    })
                self._system_step += 1
            self._last_system_sample = time.monotonic()
        except Exception as e:
            logger.warning("System metrics sample failed: %s", e)
