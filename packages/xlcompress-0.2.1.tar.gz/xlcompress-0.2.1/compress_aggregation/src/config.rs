use std::collections::HashMap;
use once_cell::sync::Lazy;

/// NFS (Number Format String) dictionary mapping Excel format strings to type codes.
///
/// Type codes:
///   1 = Integer
///   2 = Float
///   3 = Percentage
///   4 = Scientific
///   5 = Date
///   6 = Time
pub static NFS_DIC: Lazy<HashMap<&'static str, i32>> = Lazy::new(|| {
    let mut m = HashMap::new();
    m.insert("0", 1);
    m.insert("0.00", 2);
    m.insert("#,##0", 1);
    m.insert("#,##0.00", 2);
    m.insert("0%", 3);
    m.insert("0.00%", 3);
    m.insert("0.00E+00", 4);
    m.insert("#,##0;(#,##0)", 1);
    m.insert("#,##0;[Red](#,##0)", 1);
    m.insert("#,##0.00;(#,##0.00)", 2);
    m.insert("#,##0.00;[Red](#,##0.00)", 2);
    m.insert("##0.0E+0", 4);
    m.insert("d/m/yyyy", 5);
    m.insert("d-mm-yy", 5);
    m.insert("d-mmm", 5);
    m.insert("mmm-yy", 5);
    m.insert("h:mm tt", 6);
    m.insert("h:mm:ss tt", 6);
    m.insert("H:mm", 6);
    m.insert("H:mm:ss", 6);
    m.insert("m/d/yyyy H:mm", 6);
    m.insert("mm:ss", 6);
    m.insert("[h]:mm:ss", 6);
    m.insert("mmss.0", 6);
    m
});

/// When true, use the NFS cell value directly as the type (bypassing DIC lookup).
/// Mirrors Python config.NFS_TAG = True.
pub const NFS_TAG: bool = true;

/// When true, include FMT1 format dict in prompts.
pub const FMT1_TAG: bool = false;

/// When true, include FMT3 format dict in prompts.
pub const FMT3_TAG: bool = false;
