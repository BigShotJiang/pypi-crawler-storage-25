use once_cell::sync::Lazy;
use regex::Regex;

use crate::case_judge;
use crate::config::{NFS_DIC, NFS_TAG};

static RE_YEAR: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^19\d{2}$|^20\d{2}$").unwrap()
});

static RE_INT: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^-?\d+$").unwrap()
});

static RE_FLOAT: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^-?\d+\.\d+$").unwrap()
});

/// A detected cell type.
///
/// `Numeric(i32)` covers the integer type codes 0-8 from the Python:
///   0 = Year, 1 = Int, 2 = Float, 3 = Percentage, 4 = Scientific,
///   5 = Date,  6 = Time, 7 = Currency, 8 = Email
///
/// `Text(String)` covers everything else (type code 9 in Python becomes the
/// raw cell text so downstream code can group identical strings together).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum CellType {
    Numeric(i32),
    Text(String),
}

/// Strip thousands-separator commas from a value that is otherwise all digits/signs/dots.
///
/// Mirrors Python `TableDataAggregation.check_and_process_string`.
///
/// Input:  s &str
/// Output: String — cleaned value (may equal the input)
pub fn check_and_process_string(s: &str) -> String {
    let all_numeric = s.chars().enumerate().all(|(i, c)| {
        c.is_ascii_digit() || c == ',' || c == '.'
            || ((c == '+' || c == '-') && i == 0)
    });
    if all_numeric {
        s.replace(',', "")
    } else {
        s.to_string()
    }
}

/// Identify the numeric type code of a cell value string.
///
/// Returns codes 1–9 matching the Python `identify_number` method.
/// Code 9 means "not a recognised number" (will be treated as raw text).
///
/// Input:  s &str — cell value (already cleaned of thousands-separators)
/// Output: i32
fn identify_number(s: &str) -> i32 {
    if RE_INT.is_match(s) {
        1
    } else if RE_FLOAT.is_match(s) {
        2
    } else if case_judge::is_percentage(s) {
        3
    } else if case_judge::is_scientific_notation(s) {
        4
    } else if case_judge::is_date(s) {
        5
    } else if case_judge::is_time(s) {
        6
    } else if case_judge::is_currency(s) {
        7
    } else if case_judge::is_email(s) {
        8
    } else {
        9
    }
}

/// Determine the `CellType` for a cell given its NFS format string and raw value.
///
/// Logic mirrors Python `TableDataAggregation.get_type`:
///  - Empty cell → returns `None`.
///  - NFS_TAG mode: if nfs_cell == "None", classify by value heuristics;
///    otherwise use nfs_cell string directly as type key.
///  - Non-NFS_TAG mode: look up nfs_cell in DIC; fall back to value heuristics.
///
/// Input:  nfs_cell &str — NFS format string for the cell (may be "None")
///         cell &str     — cell display value
/// Output: Option<CellType> — None means empty cell; Some(t) is the type
pub fn get_type(nfs_cell: &str, cell: &str) -> Option<CellType> {
    if cell.is_empty() {
        return None;
    }

    if NFS_TAG {
        if nfs_cell == "None" {
            if RE_YEAR.is_match(cell) {
                Some(CellType::Numeric(0))
            } else {
                let cleaned = check_and_process_string(cell);
                let code = identify_number(&cleaned);
                if code == 9 {
                    Some(CellType::Text(cell.to_string()))
                } else {
                    Some(CellType::Numeric(code))
                }
            }
        } else {
            // Use the NFS string itself as a text-typed key so identical format
            // strings aggregate together, matching the Python behaviour.
            Some(CellType::Text(nfs_cell.to_string()))
        }
    } else {
        // Non-NFS mode: DIC lookup first.
        if let Some(&code) = NFS_DIC.get(nfs_cell) {
            return Some(CellType::Numeric(code));
        }
        if RE_YEAR.is_match(cell) {
            Some(CellType::Numeric(0))
        } else {
            let cleaned = check_and_process_string(cell);
            let code = identify_number(&cleaned);
            if code == 9 {
                Some(CellType::Text(cell.to_string()))
            } else {
                Some(CellType::Numeric(code))
            }
        }
    }
}

/// One detected homogeneous region in the spreadsheet grid.
///
/// `top_left` and `bottom_right` are 0-based (row, col) indices within the
/// sub-table grid passed to `aggregate_similar_areas`.
#[derive(Debug, Clone)]
pub struct Area {
    pub top_left: (usize, usize),
    pub bottom_right: (usize, usize),
    pub cell_type: CellType,
}

/// Flood-fill a 2-D grid of cell values + NFS strings, grouping adjacent cells
/// of the same type into rectangular bounding boxes.
///
/// Mirrors Python `TableDataAggregation.aggregate_similar_areas` (iterative BFS
/// instead of recursive DFS to avoid stack overflow on large sheets).
///
/// Input:
///   input     — 2-D grid of cell values, row-major; `input[r][c]` is the display value
///   nfs_input — 2-D grid of NFS format strings, same dimensions
///
/// Output: Vec<Area> — one entry per connected region (excluding empty cells)
pub fn aggregate_similar_areas(
    input: &[Vec<String>],
    nfs_input: &[Vec<String>],
) -> Vec<Area> {
    let rows = input.len();
    let cols = if rows == 0 { 0 } else { input[0].len() };
    let mut visited = vec![vec![false; cols]; rows];
    let mut areas = Vec::new();

    for r in 0..rows {
        for c in 0..cols {
            if visited[r][c] || input[r][c].is_empty() {
                continue;
            }

            let empty = String::new();
            let nfs_val = nfs_input.get(r).and_then(|row| row.get(c)).unwrap_or(&empty);
            let val_type = match get_type(nfs_val, &input[r][c]) {
                Some(t) => t,
                None => continue,
            };

            // BFS to find the connected region.
            let mut queue = std::collections::VecDeque::new();
            queue.push_back((r, c));
            visited[r][c] = true;

            let mut min_r = r;
            let mut min_c = c;
            let mut max_r = r;
            let mut max_c = c;

            while let Some((cr, cc)) = queue.pop_front() {
                min_r = min_r.min(cr);
                min_c = min_c.min(cc);
                max_r = max_r.max(cr);
                max_c = max_c.max(cc);

                for (dr, dc) in [(-1i32, 0i32), (1, 0), (0, -1), (0, 1)] {
                    let nr = cr as i32 + dr;
                    let nc = cc as i32 + dc;
                    if nr < 0 || nc < 0 {
                        continue;
                    }
                    let (nr, nc) = (nr as usize, nc as usize);
                    if nr >= rows || nc >= cols || visited[nr][nc] {
                        continue;
                    }
                    let nfs_nb = nfs_input.get(nr).and_then(|row| row.get(nc)).unwrap_or(&empty);
                    let neighbor_type = get_type(nfs_nb, &input[nr][nc]);
                    if neighbor_type.as_ref() == Some(&val_type) {
                        visited[nr][nc] = true;
                        queue.push_back((nr, nc));
                    }
                }
            }

            areas.push(Area {
                top_left: (min_r, min_c),
                bottom_right: (max_r, max_c),
                cell_type: val_type,
            });
        }
    }

    areas
}

/// Map a `CellType` to the human-readable label used in the output JSON.
///
/// Numeric codes follow the Python `change_data` / `ValueAddress.process` mapping.
/// Text types pass through the raw string (NFS key or original cell value).
///
/// Input:  cell_type &CellType
/// Output: String — label such as "IntNum", "DateData", or raw text
pub fn type_label(cell_type: &CellType) -> String {
    match cell_type {
        CellType::Numeric(0) => "YearData".to_string(),
        CellType::Numeric(1) => "IntNum".to_string(),
        CellType::Numeric(2) => "FloatNum".to_string(),
        CellType::Numeric(3) => "PercentageNum".to_string(),
        CellType::Numeric(4) => "SentificNum".to_string(),
        CellType::Numeric(5) => "DateData".to_string(),
        CellType::Numeric(6) => "TimeData".to_string(),
        CellType::Numeric(7) => "CurrencyData".to_string(),
        CellType::Numeric(8) => "EmailData".to_string(),
        CellType::Numeric(_) => "Unknown".to_string(),
        CellType::Text(s) => s.clone(),
    }
}
