use once_cell::sync::Lazy;
use regex::Regex;

#[cfg(feature = "tokenize")]
use tiktoken_rs::{cl100k_base, CoreBPE};

#[cfg(feature = "tokenize")]
pub(crate) static BPE: Lazy<CoreBPE> = Lazy::new(|| cl100k_base().expect("cl100k_base BPE must load"));

static RE_CELL_START: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"\|[A-Z]+\d+,").unwrap()
});

static RE_FIRST_ADDR: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"([A-Z]+)(\d+)").unwrap()
});

/// Parse a pipe-delimited spreadsheet row string into individual cell tokens.
///
/// Each cell token has the form `COL_ADDR,value` (e.g. `A1,Hello`).
/// Mirrors Python `parse_excel_row`.
///
/// Input:  row &str  — one row from the encoded spreadsheet text
/// Output: Vec<String> — one entry per cell, each `"ADDR,value"`
pub fn parse_excel_row(row: &str) -> Vec<String> {
    let starts: Vec<usize> = RE_CELL_START
        .find_iter(row)
        .map(|m| m.start())
        .collect();
    let mut cells = Vec::with_capacity(starts.len());
    for i in 0..starts.len() {
        let start = starts[i] + 1; // skip the leading '|'
        let end = if i + 1 < starts.len() { starts[i + 1] } else { row.len() };
        cells.push(row[start..end].to_string());
    }
    cells
}

/// Parse a row and return only the cell *values* (everything after the first comma).
///
/// Numeric-looking values that contain commas (thousands separators) have those
/// commas stripped, matching the Python `parse_excel_row_value` behaviour.
///
/// Input:  row &str
/// Output: Vec<String>
pub fn parse_excel_row_value(row: &str) -> Vec<String> {
    let cells = parse_excel_row(row);
    cells
        .into_iter()
        .map(|cell| {
            let value = match cell.splitn(2, ',').nth(1) {
                Some(v) => v.trim().to_string(),
                None => String::new(),
            };
            // Strip thousands-separator commas from purely numeric strings.
            if value.chars().all(|c| c.isdigit() || c == ',') {
                value.replace(',', "")
            } else {
                value
            }
        })
        .collect()
}

/// Convert a spreadsheet column letter string (e.g. "A", "AB") to a 1-based column number.
///
/// Input:  col_str &str — uppercase column letters
/// Output: u32 — 1-based column index
pub fn col_letter_to_num(col_str: &str) -> u32 {
    col_str
        .chars()
        .fold(0u32, |acc, c| acc * 26 + (c as u32 - 'A' as u32 + 1))
}

/// Convert a 1-based column number to a column letter string (e.g. 1 → "A", 28 → "AB").
///
/// Input:  col_num u32 — 1-based column number (must be ≥ 1)
/// Output: String — uppercase column letters
pub fn col_num_to_letter(mut col_num: u32) -> String {
    let mut letter = String::new();
    while col_num > 0 {
        let remainder = (col_num - 1) % 26;
        letter.insert(0, (b'A' + remainder as u8) as char);
        col_num = (col_num - 1) / 26;
    }
    letter
}

/// Convert a spreadsheet address string (e.g. "B3") to a 0-based (row, col) tuple.
///
/// Input:  address &str — e.g. "AB12"
/// Output: (usize, usize) — (row_index, col_index), both 0-based
pub fn excel_address_to_coords(address: &str) -> (usize, usize) {
    let mut col_letters = String::new();
    let mut row_digits = String::new();
    for ch in address.chars() {
        if ch.is_ascii_alphabetic() {
            col_letters.push(ch);
        } else {
            row_digits.push(ch);
        }
    }
    let row_index = row_digits.parse::<usize>().unwrap_or(1) - 1;
    let col_index = col_letter_to_num(&col_letters) as usize - 1;
    (row_index, col_index)
}

/// Convert a 0-based (row, col) coordinate pair to an Excel address string (e.g. "B3").
///
/// Input:  coord (usize, usize) — (row_index, col_index), both 0-based
/// Output: String — e.g. "AB12"
pub fn tuple_to_excel_cell(coord: (usize, usize)) -> String {
    let (row, mut col) = coord;
    let mut excel_col = String::new();
    loop {
        excel_col.insert(0, (b'A' + (col % 26) as u8) as char);
        if col < 26 {
            break;
        }
        col = col / 26 - 1;
    }
    format!("{}{}", excel_col, row + 1)
}

/// Count tiktoken cl100k_base tokens across an array of text strings.
///
/// Input:  texts &[&str] — text segments to encode and count
/// Output: usize — total token count
#[cfg(feature = "tokenize")]
pub fn count_tokens(texts: &[&str]) -> usize {
    texts
        .iter()
        .map(|t| BPE.encode_with_special_tokens(t).len())
        .sum()
}

/// Extract the first spreadsheet address found in a cell row to determine the
/// top-left offset (row_l, col_l) of the sub-table within the full sheet.
///
/// Input:  first_cell &str — first token from parse_excel_row, e.g. "B3,value"
/// Output: (usize, usize) — (row_offset, col_offset), both 0-based
pub fn parse_first_cell_offset(first_cell: &str) -> (usize, usize) {
    let address = first_cell.splitn(2, ',').next().unwrap_or("");
    if let Some(caps) = RE_FIRST_ADDR.captures(address) {
        let col_l = col_letter_to_num(&caps[1]) as usize - 1;
        let row_l = caps[2].parse::<usize>().unwrap_or(1) - 1;
        (row_l, col_l)
    } else {
        (0, 0)
    }
}

/// Extension trait so u32::isdigit works inline (convenience alias for is_ascii_digit).
trait CharExt {
    fn isdigit(self) -> bool;
}
impl CharExt for char {
    fn isdigit(self) -> bool {
        self.is_ascii_digit()
    }
}
