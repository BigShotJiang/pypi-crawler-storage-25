use crate::aggregation::{type_label, Area};
use crate::utils::{col_num_to_letter, tuple_to_excel_cell};
#[cfg(feature = "tokenize")]
use crate::utils::BPE;

/// Convert a list of `Area` structs (with grid-relative 0-based indices) into
/// `(label, address_range)` string pairs, adjusting coordinates by the sheet
/// top-left offset `(row_l, col_l)`.
///
/// When begin == end address the pair uses a single cell address; otherwise
/// `"BEGIN:END"` range notation is used.  This mirrors Python `ValueAddress.process`.
///
/// Input:
///   areas       — slice of `Area` values from `aggregate_similar_areas`
///   row_l       — 0-based row offset of the sub-table within the full sheet
///   col_l       — 0-based col offset of the sub-table within the full sheet
///
/// Output: Vec<(String, String)> — (type_label, address_or_range)
pub fn areas_to_tuples(
    areas: &[Area],
    row_l: usize,
    col_l: usize,
) -> Vec<(String, String)> {
    areas
        .iter()
        .map(|area| {
            let begin = tuple_to_excel_cell((
                area.top_left.0 + row_l,
                area.top_left.1 + col_l,
            ));
            let end = tuple_to_excel_cell((
                area.bottom_right.0 + row_l,
                area.bottom_right.1 + col_l,
            ));
            let address = if begin == end {
                begin
            } else {
                format!("{}:{}", begin, end)
            };
            (type_label(&area.cell_type), address)
        })
        .collect()
}

/// Render a list of `(label, address)` tuples into the compact input string used
/// by the LLM prompt, e.g. `(IntNum|A1:B3),(DateData|C1)`.
///
/// Input:  tuples &[(String, String)] — from `areas_to_tuples`
/// Output: String
pub fn tuples_to_input_string(tuples: &[(String, String)]) -> String {
    let parts: Vec<String> = tuples
        .iter()
        .map(|(label, addr)| format!("({}|{})", label, addr))
        .collect();
    parts.join(",")
}

/// Build the spreadsheet description line used in the LLM prompt.
///
/// Format: `"The spreadsheet has {rows} rows and {cols} columns. Column names:[A,B,...]; Row numbers:[1,2,...]"`
///
/// Input:
///   row_num — number of rows in the sub-table
///   col_num — number of columns
///   row_l   — 0-based row offset (first row label = row_l + 1)
///   col_l   — 0-based col offset (first col label = col_num_to_letter(col_l + 1))
///
/// Output: String
pub fn build_description(row_num: usize, col_num: usize, row_l: usize, col_l: usize) -> String {
    let col_names: Vec<String> = (0..col_num)
        .map(|i| col_num_to_letter((i + col_l + 1) as u32))
        .collect();
    let col_part = format!("[{}]", col_names.join(","));

    let row_names: Vec<String> = (0..row_num)
        .map(|i| (i + row_l + 1).to_string())
        .collect();
    let row_part = format!("[{}]", row_names.join(","));

    format!(
        "The spreadsheet has {} rows and {} columns. Column names:{}; Row numbers:{}",
        row_num, col_num, col_part, row_part
    )
}

/// Format detected areas as LLM-friendly tuple strings.
///
/// Input:  areas &[(type_label, address_range)]
/// Output: space-separated string like "(IntNum|A1:C5) (DateData|B2)"
pub fn format_areas_as_tuples(areas: &[(String, String)]) -> String {
    areas
        .iter()
        .map(|(label, addr)| format!("({}|{})", label, addr))
        .collect::<Vec<_>>()
        .join(" ")
}

/// Count cl100k_base tokens in text.
///
/// Input:  text &str
/// Output: usize — token count
#[cfg(feature = "tokenize")]
pub fn count_tokens(text: &str) -> usize {
    BPE.encode_with_special_tokens(text).len()
}

/// Classify token count into LLM context bucket.
///
/// Input:  token_count usize
/// Output: "<4k", "4-32k", or ">32k"
pub fn bucket_length(token_count: usize) -> &'static str {
    if token_count < 4096 {
        "<4k"
    } else if token_count < 32768 {
        "4-32k"
    } else {
        ">32k"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bucket_length() {
        assert_eq!(bucket_length(4095), "<4k");
        assert_eq!(bucket_length(4096), "4-32k");
        assert_eq!(bucket_length(32768), ">32k");
    }

    #[test]
    fn test_format_areas_as_tuples() {
        let areas = vec![
            ("IntNum".to_string(), "A1".to_string()),
            ("DateData".to_string(), "B2:C5".to_string()),
        ];
        let result = format_areas_as_tuples(&areas);
        assert_eq!(result, "(IntNum|A1) (DateData|B2:C5)");
    }

    #[test]
    fn test_build_description_content() {
        let desc = build_description(3, 3, 0, 0);
        assert!(desc.contains("A,B,C"), "missing col names: {}", desc);
        assert!(desc.contains("1,2,3"), "missing row numbers: {}", desc);
    }
}
