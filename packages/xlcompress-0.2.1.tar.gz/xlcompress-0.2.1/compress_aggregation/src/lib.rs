//! # compress_aggregation
//!
//! Port of the Python `compress_aggregation` module from SpreadsheetLLM.
//!
//! Takes a spreadsheet encoded as a 2-D grid of (value, NFS-format) pairs and
//! identifies contiguous regions of the same data type, producing compact
//! `(TypeLabel|AddressRange)` tuples suitable for LLM prompts.
//!
//! ## Public API entry points
//!
//! - [`process_sheet`] — high-level: grid → tuple string + description
//! - [`aggregate_similar_areas`] — mid-level: grid → `Vec<Area>`
//! - [`areas_to_tuples`] — convert `Area` list to `(label, address)` pairs
//! - [`tuples_to_input_string`] — render tuples to prompt string
//! - [`build_description`] — build the spreadsheet description sentence
//! - [`parse_excel_row`] / [`parse_excel_row_value`] — row parsing helpers
//! - [`excel_address_to_coords`] / [`tuple_to_excel_cell`] — coordinate helpers
//! - [`count_tokens`] — tiktoken cl100k_base token counter

pub mod aggregation;
pub mod case_judge;
pub mod config;
pub mod utils;
pub mod value_address;

// Flatten the most-used symbols into the crate root for convenience.
pub use aggregation::{aggregate_similar_areas, get_type, type_label, Area, CellType};
pub use utils::{
    col_letter_to_num, col_num_to_letter, excel_address_to_coords,
    parse_excel_row, parse_excel_row_value, parse_first_cell_offset, tuple_to_excel_cell,
};
#[cfg(feature = "tokenize")]
pub use utils::count_tokens;
pub use value_address::{
    areas_to_tuples, build_description, bucket_length,
    format_areas_as_tuples, tuples_to_input_string,
};
#[cfg(feature = "tokenize")]
pub use value_address::count_tokens as count_tokens_single;

/// Process a complete spreadsheet sub-table into the compact prompt representation.
///
/// This is the primary entry point for the `compress_excel` CLI crate.
///
/// Input:
///   `cell_grid`  — 2-D grid of cell display values, row-major (`cell_grid[row][col]`)
///   `nfs_grid`   — 2-D grid of NFS format strings, same dimensions.
///                  Use `"None"` for cells with no number format.
///   `row_l`      — 0-based row index of the top-left cell in the full sheet
///   `col_l`      — 0-based col index of the top-left cell in the full sheet
///
/// Output: `(input_string, description_string)` where
///   - `input_string`      is e.g. `"(IntNum|A1:A10),(DateData|C1:C5),..."`
///   - `description_string` is the "The spreadsheet has N rows …" sentence
pub fn process_sheet(
    cell_grid: &[Vec<String>],
    nfs_grid: &[Vec<String>],
    row_l: usize,
    col_l: usize,
) -> (String, String) {
    let areas = aggregate_similar_areas(cell_grid, nfs_grid);
    let tuples = areas_to_tuples(&areas, row_l, col_l);
    let input_str = tuples_to_input_string(&tuples);
    let row_num = cell_grid.len();
    let col_num = if row_num == 0 { 0 } else { cell_grid[0].len() };
    let desc = build_description(row_num, col_num, row_l, col_l);
    (input_str, desc)
}
