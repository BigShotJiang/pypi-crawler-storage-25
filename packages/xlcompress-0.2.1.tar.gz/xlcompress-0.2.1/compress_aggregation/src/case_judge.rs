use once_cell::sync::Lazy;
use regex::Regex;

// All regexes compiled once at startup.

static RE_SCIENTIFIC: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$").unwrap()
});

static RE_PERCENTAGE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^[+-]?(\d+(\.\d*)?|\.\d+)%$").unwrap()
});

static RE_CURRENCY: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"^[$€£¥]\d+(\.\d{1,2})?$").unwrap()
});

static RE_DATE: Lazy<Regex> = Lazy::new(|| {
    Regex::new(
        r"(?-u)^(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{4}|\d{1,2}[-/]\d{1,2}|\d{4}[-/]\d{1,2})"
    ).unwrap()
});

static RE_TIME: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^(2[0-3]|[01]?\d):([0-5]?\d)(\s?(AM|PM|am|pm))?$").unwrap()
});

static RE_IPV4: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$").unwrap()
});

static RE_IPV6: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^([0-9a-fA-F]{1,4}:){7}([0-9a-fA-F]{1,4})$").unwrap()
});

static RE_EMAIL: Lazy<Regex> = Lazy::new(|| {
    Regex::new(r"(?-u)^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9_.+-]+\.[a-zA-Z]{2,}$").unwrap()
});

/// Returns true if `s` looks like a number in scientific (or plain numeric) notation.
/// Matches integers, decimals, and exponent forms like 1.5e-3.
///
/// Input:  &str
/// Output: bool
pub fn is_scientific_notation(s: &str) -> bool {
    RE_SCIENTIFIC.is_match(s)
}

/// Returns true if `s` is a percentage literal such as "12.5%" or "-3%".
///
/// Input:  &str
/// Output: bool
pub fn is_percentage(s: &str) -> bool {
    RE_PERCENTAGE.is_match(s)
}

/// Returns true if `s` starts with a currency symbol ($, €, £, ¥) followed by digits
/// and an optional two-decimal fraction.
///
/// Input:  &str
/// Output: bool
pub fn is_currency(s: &str) -> bool {
    RE_CURRENCY.is_match(s)
}

/// Returns true if `s` begins with a recognisable date pattern (anchored at start,
/// not necessarily the full string — mirrors Python re.match behaviour).
///
/// Recognised forms: YYYY-MM-DD, DD/MM/YYYY, DD-MM, YYYY-MM (with - or / separators).
///
/// Input:  &str
/// Output: bool
pub fn is_date(s: &str) -> bool {
    RE_DATE.is_match(s)
}

/// Returns true if `s` is a time string like "14:30", "9:05 AM", "23:59".
///
/// Input:  &str
/// Output: bool
pub fn is_time(s: &str) -> bool {
    RE_TIME.is_match(s)
}

/// Returns true if `s` is a valid fraction with non-zero denominator (e.g. "3/4").
///
/// Input:  &str
/// Output: bool
pub fn is_fraction(s: &str) -> bool {
    let parts: Vec<&str> = s.splitn(2, '/').collect();
    if parts.len() != 2 {
        return false;
    }
    match (parts[0].trim().parse::<i64>(), parts[1].trim().parse::<i64>()) {
        (Ok(_), Ok(d)) => d != 0,
        _ => false,
    }
}

/// Returns true if `ip` is a valid IPv4 or IPv6 address.
///
/// Input:  &str
/// Output: bool
pub fn check_ip(ip: &str) -> bool {
    RE_IPV4.is_match(ip) || RE_IPV6.is_match(ip)
}

/// Returns true if `email` matches a basic email pattern.
///
/// Input:  &str
/// Output: bool
pub fn is_email(email: &str) -> bool {
    RE_EMAIL.is_match(email)
}
