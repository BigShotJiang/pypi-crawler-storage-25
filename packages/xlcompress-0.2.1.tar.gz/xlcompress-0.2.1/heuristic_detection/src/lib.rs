pub mod boundary;
pub mod cell_features;
pub mod core_sheet;
pub mod sheet_map;
pub mod region_growth;
pub mod header_reco;
pub mod detector;

pub use boundary::Boundary;

/// Input data for one worksheet.
///
/// All coordinate fields use 1-indexed, inclusive ranges.
pub struct SheetData {
    pub rows: usize,
    pub cols: usize,
    /// Cell string values, shape rows×cols (empty string = blank cell).
    pub values: Vec<Vec<String>>,
    /// Number-format codes, shape rows×cols.
    pub nfs: Vec<Vec<String>>,
    pub has_color: Vec<Vec<bool>>,
    pub has_formula: Vec<Vec<bool>>,
    /// Per-cell border flags [top, bottom, left, right], shape rows×cols.
    pub borders: Vec<Vec<[bool; 4]>>,
    /// Merged-cell regions as (top, bottom, left, right) tuples, 1-indexed inclusive.
    pub merged: Vec<(usize, usize, usize, usize)>,
}

/// Detect table boundaries in a worksheet.
///
/// Returns `Boundary` values in the **original** 1-indexed coordinate space.
/// For large sheets (rows > 1000 or rows × cols > 30 000) the fast
/// region-growth path is used; otherwise the full TableSense pipeline runs.
pub fn detect_boundaries(sheet: &SheetData) -> Vec<Boundary> {
    use core_sheet::CoreSheet;
    use sheet_map::SheetMap;
    use detector::TableDetectionHybrid;

    let core = CoreSheet::new(sheet);
    let map = SheetMap::from_core(&core);
    let mut det = TableDetectionHybrid::new_for_sheet(map);
    det.detect(true)
}
