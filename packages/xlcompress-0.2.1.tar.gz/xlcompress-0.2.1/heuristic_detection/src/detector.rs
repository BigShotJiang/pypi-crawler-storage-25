//! Orchestration of the heuristic table detection pipeline.
//!
//! Combines all filter, trimmer, and header-recognition logic into
//! `TableDetectionHybrid`, mirroring the C# partial class of the same name.

use std::collections::HashMap;
use std::collections::HashSet;

use crate::boundary::{
    Boundary, area_size, height, width, submatrix_sum, contains_box, contains_box_list,
    is_overlap, is_overlap_list, is_suppression_box, is_overlap_or_neighbor,
    overlap_box, unify_box, distinct_boxes, remove_these_candidates,
    remove_and_append_candidates, append_these_candidates,
    rank_boxes_by_location, rank_boxes_by_size,
    left_col, right_col, up_row, down_row, distinct_strs,
};
use crate::region_growth::find_connected_ranges;
use crate::sheet_map::SheetMap;

/// Main detector struct.  Holds the sheet reference, candidate box list,
/// and caches for header queries.
pub struct TableDetectionHybrid {
    pub sheet: SheetMap,
    boxes: Vec<Boundary>,
    region_growth_boxes: Vec<Boundary>,
    header_up_map: HashMap<Boundary, bool>,
    header_left_map: HashMap<Boundary, bool>,
}

impl TableDetectionHybrid {
    /// Create detector bound to an already-constructed `SheetMap`.
    pub fn new_for_sheet(sheet: SheetMap) -> Self {
        Self {
            sheet,
            boxes: Vec::new(),
            region_growth_boxes: Vec::new(),
            header_up_map: HashMap::new(),
            header_left_map: HashMap::new(),
        }
    }

    /// Run detection and return all detected `Boundary` values.
    ///
    /// If the sheet is large (rows > 1000 or rows*cols > 30000) the faster
    /// `RegionGrowthDetect` path is used.  Otherwise the full `TableSenseDetect`
    /// pipeline runs.
    pub fn detect(&mut self, eliminate_overlaps: bool) -> Vec<Boundary> {
        let h = self.sheet.height;
        let w = self.sheet.width;

        if h > 1000 || h * w > 30000 {
            self.region_growth_detect(1, 1);
        } else {
            self.table_sense_detect();
        }

        if eliminate_overlaps {
            rank_boxes_by_size(&mut self.boxes);
            self.eliminate_overlaps();
        }

        rank_boxes_by_location(&mut self.boxes);
        self.boxes.clone()
    }

    // ── Header recognition ────────────────────────────────────────────────────

    /// True when `header` represents a valid top-header row (with caching).
    pub fn is_header_up(&mut self, header: Boundary) -> bool {
        if let Some(&v) = self.header_up_map.get(&header) { return v; }
        let result = self.compute_is_header_up(header);
        self.header_up_map.insert(header, result);
        result
    }

    /// True when `header` represents a valid left-header column (with caching).
    pub fn is_header_left(&mut self, header: Boundary) -> bool {
        if let Some(&v) = self.header_left_map.get(&header) { return v; }
        let result = self.compute_is_header_left(header);
        self.header_left_map.insert(header, result);
        result
    }

    fn compute_is_header_up(&mut self, header: Boundary) -> bool {
        if !self.is_header_up_simple(header) { return false; }
        let header_down_side = down_row(header, -1, 1);
        let sim = self.sheet.compute_similar_row(header, header_down_side);
        if sim < 0.15 && self.is_header_up_simple(header_down_side) { return false; }
        let ce1 = submatrix_sum(&self.sheet.sum_content_exist, header);
        let ce2 = submatrix_sum(&self.sheet.sum_content_exist, header_down_side);
        if ce1 == 2 && ce2 == 2 && self.header_rate(header, 0) == self.header_rate(header_down_side, 0) {
            return false;
        }
        true
    }

    fn compute_is_header_left(&mut self, header: Boundary) -> bool {
        if self.is_header_left_simple(header) { return true; }
        let header_right = right_col(header, -1, 1);
        let d_right = self.sheet.content_exist_value_density(header_right);
        let d_self  = self.sheet.content_exist_value_density(header);
        if d_right >= 1.5 * d_self && d_right > 2.0 * 0.6 && self.is_header_left_simple(header_right) {
            return true;
        }
        false
    }

    fn is_header_up_simple(&mut self, header: Boundary) -> bool {
        if header.right == header.left { return false; }
        let ce = submatrix_sum(&self.sheet.sum_content_exist, header);
        if ce <= 4 && self.header_rate(header, 0) <= 0.5 { return false; }
        let area = area_size(header);
        let distinct = self.sheet.text_distinct_count(header);
        if (area > 4.0 && distinct <= 2) || (area > 3.0 && distinct < 2) { return false; }
        let right_region = Boundary::new(
            header.top, header.bottom,
            (header.left).min(header.right - 5) + 3, header.right,
        );
        if self.sheet.content_exist_value_density(header) > 2.0 * 0.3
            && self.header_rate(header, 6) > 0.4
            && self.header_rate(right_region, 6) > 0.3
        {
            return true;
        }
        false
    }

    fn is_header_left_simple(&mut self, header: Boundary) -> bool {
        if header.bottom - header.top == 0 { return false; }
        if header.bottom - header.top == 1 && self.header_rate(header, 6) >= 0.5 { return true; }
        let area = area_size(header);
        let distinct = self.sheet.text_distinct_count(header);
        if (area > 4.0 && distinct <= 2) || (area > 3.0 && distinct < 2) { return false; }
        let ce = submatrix_sum(&self.sheet.sum_content_exist, header);
        if ce <= 4 && self.header_rate(header, 6) <= 0.5 { return false; }
        let up_region = Boundary::new(
            (header.top).min(header.bottom - 5) + 3, header.bottom,
            header.left, header.right,
        );
        if self.sheet.content_exist_value_density(header) > 2.0 * 0.3
            && self.header_rate(header, 6) > 0.4
            && self.header_rate(up_region, 6) > 0.3
        {
            return true;
        }
        false
    }

    fn is_header_up_with_data_area(&mut self, upper_row: Boundary, box_: Boundary) -> bool {
        let up = upper_row.top;
        if !self.is_header_up(upper_row) { return false; }
        let mut r = upper_row;
        while self.is_header_up_simple(r) && r.top <= up + 2 && r.top < box_.bottom {
            r = Boundary::new(r.top + 1, r.top + 1, r.left, r.right);
        }
        for k in 1..=3 {
            let next = Boundary::new(r.top + k, r.top + k, r.left, r.right);
            if next.top <= box_.bottom && self.is_header_up(next) { return false; }
        }
        true
    }

    /// Compute the header-like-cell rate for `box`.
    ///
    /// `step` controls how far down to look for content existence when the box
    /// is a single row (default 6 matching C# default parameter).
    ///
    /// Returns fraction of non-empty cells whose content looks like a header label.
    pub fn header_rate(&self, box_: Boundary, step: i32) -> f64 {
        let mut cnt_exist = 0i32;
        let mut cnt_all   = 0i32;
        let mut cnt_hdr   = 0i32;

        for i in box_.top..=box_.bottom {
            for j in box_.left..=box_.right {
                cnt_all += 1;
                let surrounding = if box_.top == box_.bottom {
                    Boundary::new(i, i + step, j, j)
                } else {
                    Boundary::new(i, i, j, j)
                };
                if submatrix_sum(&self.sheet.sum_content_exist, surrounding) != 0 {
                    cnt_exist += 1;
                    let fi = &self.sheet.feature_map.get((i - 1) as usize)
                        .and_then(|r| r.get((j - 1) as usize));
                    if let Some(f) = fi {
                        if f.mark_text() {
                            let is_hdr = (f.alphabet_ratio >= f.number_ratio && f.alphabet_ratio != 0.0)
                                || f.alphabet_ratio * f.text_length as f64 > 2.5
                                || f.sp_char_ratio > 0.0;
                            if is_hdr { cnt_hdr += 1; }
                        }
                    }
                }
            }
        }
        if cnt_all == 0 { return 0.0; }
        cnt_hdr as f64 / (cnt_exist.max((cnt_all as f64 / 3.0) as i32)) as f64
    }

    /// For each box in `boxes`, return a single-row `Boundary` at the top if it
    /// qualifies as an up-header.
    pub fn findout_upheaders(&mut self, boxes: &[Boundary]) -> Vec<Boundary> {
        boxes.iter().filter_map(|&b| {
            let header = Boundary::new(b.top, b.top, b.left, b.right);
            if self.is_header_up(header) { Some(header) } else { None }
        }).collect()
    }

    /// For each box in `boxes`, return a single-column `Boundary` at the left if
    /// it qualifies as a left-header.
    pub fn findout_leftheaders(&mut self, boxes: &[Boundary]) -> Vec<Boundary> {
        boxes.iter().filter_map(|&b| {
            let header = Boundary::new(b.top, b.bottom, b.left, b.left);
            if self.is_header_left(header) { Some(header) } else { None }
        }).collect()
    }

    // ── Main detect paths ─────────────────────────────────────────────────────

    fn region_growth_detect(&mut self, thresh_hor: i32, thresh_ver: i32) {
        self.boxes = find_connected_ranges(
            &self.sheet.content_strs, Some(&self.sheet.value_map_border),
            thresh_hor, thresh_ver, 1,
        );
        self.little_boxes_filter();
        self.up_header_trim();
        self.surrounding_boundaries_trim();
        self.retrieve_up_header(1);
        self.retrieve_up_header(2);
        self.retrieve_left_header();
        self.retrieve_left(1);
        self.retrieve_left(2);
    }

    fn table_sense_detect(&mut self) {
        self.sheet.propose_boundary_lines();
        self.sheet.cohension_detection();
        let block_regions = self.sheet.generate_block_regions();

        let large = self.sheet.height * self.sheet.width > 10000;

        // Collect region-growth candidates
        let mut rg_boxes: Vec<Boundary> = Vec::new();
        let thresh_hor_limit = 7;
        for thresh_hor in 1..thresh_hor_limit {
            let thresh_ver_limit = if thresh_hor < 3 { 3 } else { 2 };
            for thresh_ver in 1..thresh_ver_limit {
                let boxes = find_connected_ranges(
                    &self.sheet.content_strs, Some(&self.sheet.value_map_border),
                    thresh_hor, thresh_ver, 0,
                );
                for b in boxes { if self.general_filter(b) { rg_boxes.push(b); } }
                if !large {
                    let boxes2 = find_connected_ranges(
                        &self.sheet.content_strs, None,
                        thresh_hor, thresh_ver, 0,
                    );
                    for b in boxes2 { if self.general_filter(b) { rg_boxes.push(b); } }
                }
            }
        }

        let mut sheet_boxes: Vec<Boundary> = Vec::new();

        if !large {
            for block in &block_regions {
                self.boxes = self.generate_raw_candidate_boxes(*block);
                for &b in &rg_boxes {
                    if is_overlap(*block, b) { self.boxes.push(b); }
                }
                self.boxes = distinct_boxes(self.boxes.clone());
                self.block_candidates_refine_and_filter();
                sheet_boxes.extend_from_slice(&self.boxes);
            }
        }

        self.boxes = distinct_boxes(sheet_boxes);
        rank_boxes_by_location(&mut self.boxes);
        self.candidates_refine_and_filter();
    }

    // ── Raw candidate generation ──────────────────────────────────────────────

    fn generate_raw_candidate_boxes(&mut self, block: Boundary) -> Vec<Boundary> {
        let mut row_lines: Vec<i32> = self.sheet.row_boundary_lines.iter()
            .copied()
            .filter(|&r| r >= block.top - 2 && r <= block.bottom - 1)
            .collect();
        let mut col_lines: Vec<i32> = self.sheet.col_boundary_lines.iter()
            .copied()
            .filter(|&c| c >= block.left - 2 && c <= block.right - 1)
            .collect();

        // Filter row lines that have actual content inhomogeneity
        row_lines = row_lines.into_iter().filter(|&row| {
            for index in (block.left - 3)..block.right {
                let box_up   = Boundary::new(row + 1, row + 1, index, index + 3);
                let box_down = Boundary::new(row + 2, row + 2, index, index + 3);
                let s_up   = submatrix_sum(&self.sheet.sum_content_exist, box_up);
                let s_down = submatrix_sum(&self.sheet.sum_content_exist, box_down);
                if (s_up > 0 && s_down == 0) || (s_down > 0 && s_up == 0) { return true; }
            }
            false
        }).collect::<std::collections::HashSet<_>>().into_iter().collect();

        col_lines = col_lines.into_iter().filter(|&col| {
            for index in (block.top - 3)..block.bottom {
                let box_left  = Boundary::new(index, index + 3, col + 1, col + 1);
                let box_right = Boundary::new(index, index + 3, col + 2, col + 2);
                let s_left  = submatrix_sum(&self.sheet.sum_content_exist, box_left);
                let s_right = submatrix_sum(&self.sheet.sum_content_exist, box_right);
                if (s_left > 0 && s_right == 0) || (s_right > 0 && s_left == 0) { return true; }
            }
            false
        }).collect::<std::collections::HashSet<_>>().into_iter().collect();

        let mark_complex = row_lines.len() > 300 || col_lines.len() > 150;
        row_lines.truncate(300);
        col_lines.truncate(150);

        let mut result = Vec::new();
        for &left in &col_lines {
            if left < block.left - 2 { continue; }
            for &right in &col_lines {
                if left >= right || right > block.right - 1 { continue; }
                let mut not_valid_down: HashSet<i32> = HashSet::new();
                for &up in &row_lines {
                    if up < block.top - 2 { continue; }
                    let box_up_out   = Boundary::new(up + 1, up + 1, left + 2, right + 1);
                    let box_left_out = Boundary::new(up + 2, up + 4, left + 1, left + 1);
                    let box_right_out= Boundary::new(up + 2, up + 4, right + 2, right + 2);
                    let box_up_in    = Boundary::new(up + 2, up + 2, left + 2, right + 1);
                    if submatrix_sum(&self.sheet.sum_content_exist, box_up_out) >= 6 { continue; }
                    if submatrix_sum(&self.sheet.sum_content_exist, box_left_out) >= 6 { continue; }
                    if submatrix_sum(&self.sheet.sum_content_exist, box_right_out) >= 6 { continue; }
                    if submatrix_sum(&self.sheet.sum_content_exist, box_up_in) == 0 { continue; }
                    for &down in &row_lines {
                        if up >= down || down > block.bottom - 1 { continue; }
                        if not_valid_down.contains(&down) { continue; }
                        let box_down_out = Boundary::new(down + 2, down + 2, left + 2, right + 1);
                        let box_down_in  = Boundary::new(down + 1, down + 1, left + 2, right + 1);
                        if submatrix_sum(&self.sheet.sum_content_exist, box_down_out) >= 6 {
                            not_valid_down.insert(down); continue;
                        }
                        if submatrix_sum(&self.sheet.sum_content_exist, box_down_in) == 0 {
                            not_valid_down.insert(down); continue;
                        }
                        let b = Boundary::new(up + 2, down + 1, left + 2, right + 1);
                        if mark_complex {
                            let a = area_size(b);
                            if a > 0.0 && submatrix_sum(&self.sheet.sum_all, b) as f64 / a < 2.0 * 0.3 { continue; }
                        }
                        if self.general_filter(b) { result.push(b); }
                    }
                }
            }
        }
        result
    }

    // ── Filter/refine pipelines ───────────────────────────────────────────────

    fn block_candidates_refine_and_filter(&mut self) {
        self.up_header_trim();
        self.overlap_cohension_filter();
        self.overlap_border_cohension_filter();
        self.little_boxes_filter();
        self.overlap_up_header_filter();
        self.surrounding_boundaries_trim();
        self.overlap_up_header_filter();
        self.splitted_empty_lines_filter();
    }

    fn candidates_refine_and_filter(&mut self) {
        self.border_cohensions_addition();
        self.little_boxes_filter();
        self.retrieve_distant_up_header();
        self.vertical_relational_merge();
        self.suppression_soft_filter();
        self.header_priority_filter();
        self.pair_alike_contains_filter();
        self.pair_contains_filter();
        self.combine_contains_fill_area_filter_soft();
        self.combine_contains_fill_line_filter_soft();
        self.contains_little_filter();
        self.pair_alike_contains_filter();
        self.pair_contains_filter();
        self.nesting_combination_filter();
        self.overlap_header_filter();
        self.boxes = distinct_boxes(self.boxes.clone());
        self.forced_border_filter();
        self.adjoin_header_filter();
        self.little_boxes_filter();
        self.pair_contains_filter_hard();
        self.combine_contains_filter_hard();
        self.add_region_growth(1, 1);
        self.add_compact_region_growth();
        self.merge_filter();
        self.retrieve_left_header();
        self.left_header_trim();
        self.bottom_trim();
        self.retrieve_up_header(1);
        self.retrieve_up_header(2);
        self.up_trim_simple();
        self.little_boxes_filter();
    }

    // ── Filters ───────────────────────────────────────────────────────────────

    fn general_filter(&mut self, b: Boundary) -> bool {
        if b.bottom - b.top < 1 || b.right - b.left < 1 { return false; }
        if !self.verify_box_border_value_in_out_simple(b) { return false; }
        if !self.verify_box_border_value_out_sparse(b) { return false; }
        if !self.verify_box_border_value_not_null(b) { return false; }
        if !self.verify_box_split(b) { return false; }
        true
    }

    fn verify_box_border_value_not_null(&self, b: Boundary) -> bool {
        let edges = [
            Boundary::new(b.top, b.top, b.left, b.right),
            Boundary::new(b.bottom, b.bottom, b.left, b.right),
            Boundary::new(b.top, b.bottom, b.left, b.left),
            Boundary::new(b.top, b.bottom, b.right, b.right),
        ];
        for e in &edges {
            if submatrix_sum(&self.sheet.sum_content, *e) + submatrix_sum(&self.sheet.sum_color, *e) == 0 {
                return false;
            }
        }
        true
    }

    fn verify_box_border_value_in_out_simple(&self, b: Boundary) -> bool {
        let checks = [
            Boundary::new(b.top - 1, b.top - 1, b.left, b.right),
            Boundary::new(b.bottom + 1, b.bottom + 1, b.left, b.right),
            Boundary::new(b.top, b.bottom, b.left - 1, b.left - 1),
            Boundary::new(b.top, b.bottom, b.right + 1, b.right + 1),
        ];
        for e in &checks {
            if submatrix_sum(&self.sheet.sum_content_exist, *e) >= 6 { return false; }
        }
        true
    }

    fn verify_box_border_value_out_sparse(&self, b: Boundary) -> bool {
        let box_up    = Boundary::new(b.top - 1, b.top - 1, b.left, b.right);
        let box_down  = Boundary::new(b.bottom + 1, b.bottom + 1, b.left, b.right);
        let box_left  = Boundary::new(b.top, b.bottom, b.left - 1, b.left - 1);
        let box_right = Boundary::new(b.top, b.bottom, b.right + 1, b.right + 1);
        let su = submatrix_sum(&self.sheet.sum_content_exist, box_up);
        let sd = submatrix_sum(&self.sheet.sum_content_exist, box_down);
        let sl = submatrix_sum(&self.sheet.sum_content_exist, box_left);
        let sr = submatrix_sum(&self.sheet.sum_content_exist, box_right);
        if su >= 6 || sd >= 6 || sl >= 6 || sr >= 6 { return false; }
        if b.bottom - b.top <= 2 && (sl >= 2 || sr >= 2) { return false; }
        if b.right - b.left <= 1 && (su >= 2 || sd >= 2) { return false; }
        if b.bottom - b.top <= 4 && (sl >= 4 || sr >= 4) { return false; }
        if b.right - b.left <= 4 && (su >= 4 || sd >= 4) { return false; }
        true
    }

    fn verify_box_split(&self, b: Boundary) -> bool {
        let (up, down, left, right) = (b.top, b.bottom, b.left, b.right);
        let up_offset  = if b.bottom - b.top > 12 { 2 } else { 0 };
        let left_offset= if b.right - b.left > 12 { 2 } else { 0 };

        for i in (up + 3 + up_offset)..(down - 4) {
            let e3 = Boundary::new(i, i + 2, left, right);
            let e1 = Boundary::new(i + 1, i + 1, left, right);
            if submatrix_sum(&self.sheet.sum_content, e1) < 3 {
                if submatrix_sum(&self.sheet.sum_content, e1)
                    + submatrix_sum(&self.sheet.sum_color, e1) == 0
                    && submatrix_sum(&self.sheet.sum_content_exist, e3) == 0
                {
                    let mut k = i + 3;
                    let mut e_down = Boundary::new(k, k, left, right);
                    while k < down {
                        e_down = Boundary::new(k, k, left, right);
                        if submatrix_sum(&self.sheet.sum_content, e_down) > 5 { break; }
                        k += 1;
                    }
                    k = i - 1;
                    let mut e_up = Boundary::new(k, k, left, right);
                    while k > up {
                        e_up = Boundary::new(k, k, left, right);
                        if submatrix_sum(&self.sheet.sum_content, e_up) > 5 { break; }
                        k -= 1;
                    }
                    if submatrix_sum(&self.sheet.sum_content_exist, e_up) > 5
                        && submatrix_sum(&self.sheet.sum_content_exist, e_down) > 5
                    { return false; }
                } else {
                    let sc = submatrix_sum(&self.sheet.sum_color, e1);
                    let sb = submatrix_sum(&self.sheet.sum_border_col, e1);
                    if sc + sb < 5 && !is_overlap_list(e1, &self.sheet.cohension_regions, true, false, false) {
                        let bul = Boundary::new(up, i + 1, left, left + 2);
                        let bur = Boundary::new(up, i + 1, right - 2, right);
                        let bdl = Boundary::new(i + 1, down, left, left + 2);
                        let bdr = Boundary::new(i + 1, down, right - 2, right);
                        let dul = self.corner_density(bul, true, false);
                        let dur = self.corner_density(bur, true, false);
                        let ddl = self.corner_density(bdl, true, false);
                        let ddr = self.corner_density(bdr, true, false);
                        if dul == 0.0 && ddl > 2.0 * 0.2 { return false; }
                        if dur == 0.0 && ddr > 2.0 * 0.2 { return false; }
                        if ddl == 0.0 && dul > 2.0 * 0.2 { return false; }
                        if ddr == 0.0 && dur > 2.0 * 0.2 { return false; }
                    }
                }
            }
        }

        for i in (left + 3 + left_offset)..(right - 4) {
            let e3 = Boundary::new(up, down, i, i + 2);
            let e1 = Boundary::new(up, down, i + 1, i + 1);
            if submatrix_sum(&self.sheet.sum_content, e1) < 3 {
                if submatrix_sum(&self.sheet.sum_content, e1)
                    + submatrix_sum(&self.sheet.sum_color, e1) == 0
                    && submatrix_sum(&self.sheet.sum_content_exist, e3) == 0
                {
                    let mut k = i + 3;
                    let mut e_right = Boundary::new(up, down, k, k);
                    while k < down {
                        e_right = Boundary::new(up, down, k, k);
                        if submatrix_sum(&self.sheet.sum_content, e_right) > 5 { break; }
                        k += 1;
                    }
                    k = i - 1;
                    let mut e_left = Boundary::new(up, down, k, k);
                    while k > up {
                        e_left = Boundary::new(up, down, k, k);
                        if submatrix_sum(&self.sheet.sum_content, e_left) > 5 { break; }
                        k -= 1;
                    }
                    if e_right.right - e_left.right >= 3 { return false; }
                } else {
                    let sc = submatrix_sum(&self.sheet.sum_color, e1);
                    let sb = submatrix_sum(&self.sheet.sum_border_row, e1);
                    if sc + sb < 5 && !is_overlap_list(e1, &self.sheet.cohension_regions, true, false, false) {
                        let bul = Boundary::new(up, up + 2, left, i + 1);
                        let bur = Boundary::new(up, up + 2, i + 1, right);
                        let bdl = Boundary::new(down - 2, down, left, i + 1);
                        let bdr = Boundary::new(down - 2, down, i + 1, right);
                        let dul = self.corner_density(bul, false, true);
                        let dur = self.corner_density(bur, false, true);
                        let ddl = self.corner_density(bdl, false, true);
                        let ddr = self.corner_density(bdr, false, true);
                        let a_ul = area_size(bul);
                        let a_ur = area_size(bur);
                        let a_dl = area_size(bdl);
                        let a_dr = area_size(bdr);
                        if dul == 0.0 && a_ur > 0.0 && dur / a_ur > 2.0 * 0.2 { return false; }
                        if dur == 0.0 && a_ul > 0.0 && dul / a_ul > 2.0 * 0.2 { return false; }
                        if ddl == 0.0 && a_dr > 0.0 && ddr / a_dr > 2.0 * 0.2 { return false; }
                        if ddr == 0.0 && a_dl > 0.0 && ddl / a_dl > 2.0 * 0.2 { return false; }
                    }
                }
            }
        }
        true
    }

    /// Density helper for corner boxes in `verify_box_split`.
    fn corner_density(&self, b: Boundary, use_col_border: bool, use_row_border: bool) -> f64 {
        let sc = submatrix_sum(&self.sheet.sum_content, b);
        let scol= submatrix_sum(&self.sheet.sum_color, b);
        let sb  = if use_col_border {
            submatrix_sum(&self.sheet.sum_border_col, b)
        } else if use_row_border {
            submatrix_sum(&self.sheet.sum_border_row, b)
        } else { 0 };
        (sc + scol + sb) as f64
    }

    fn little_boxes_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            let rows = b.bottom - b.top;
            let cols = b.right - b.left;
            // Thin boxes
            if rows < 1 || cols < 1 { removed.insert(b); continue; }
            if (rows < 2 || cols < 2) && area_size(b) < 8.0 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.7 { removed.insert(b); continue; }
            } else if (rows < 2 || cols < 2) && area_size(b) < 24.0 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.6 { removed.insert(b); continue; }
            } else if rows < 2 || cols < 2 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.55 { removed.insert(b); continue; }
            } else if rows < 3 || cols < 3 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.35 { removed.insert(b); continue; }
            }
            // Small boxes
            if area_size(b) < 7.0 { removed.insert(b); continue; }
            if (rows < 5 && cols < 3) || (rows < 3 && cols < 5) {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.55 { removed.insert(b); continue; }
            } else if rows < 5 && cols < 5 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.4 { removed.insert(b); continue; }
            } else if rows < 8 && cols < 8 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.35 { removed.insert(b); continue; }
            } else if rows < 14 && cols < 14 {
                if self.sheet.content_exist_value_density(b) < 2.0 * 0.25 { removed.insert(b); continue; }
            }
            // Thin with empty internal rows/cols
            if rows == 2 {
                let win = Boundary::new(b.top + 1, b.bottom - 1, b.left, b.right);
                if submatrix_sum(&self.sheet.sum_content_exist, win) <= 5
                    && self.sheet.content_exist_value_density(b) < 2.0 * 0.45
                { removed.insert(b); continue; }
            }
            if cols == 2 {
                let win = Boundary::new(b.top, b.bottom, b.left + 1, b.right - 1);
                if submatrix_sum(&self.sheet.sum_content_exist, win) <= 5
                    && self.sheet.content_exist_value_density(b) < 2.0 * 0.45
                { removed.insert(b); continue; }
            }
            // Check internal empty windows
            if rows > 3 && rows < 4 {
                let mut rm = false;
                for idx in (b.top + 1)..b.bottom {
                    let win = Boundary::new(idx, idx + 1, b.left, b.right);
                    if submatrix_sum(&self.sheet.sum_content_exist, win) <= 3
                        && self.sheet.content_exist_value_density(b) < 2.0 * 0.4
                    { rm = true; break; }
                }
                if rm { removed.insert(b); continue; }
            }
            if cols > 2 && cols <= 4 {
                let mut rm = false;
                for idx in (b.left + 2)..b.right {
                    let win = Boundary::new(b.top, b.bottom, idx, idx + 1);
                    if submatrix_sum(&self.sheet.sum_content_exist, win) <= 3
                        && self.sheet.content_exist_value_density(b) < 2.0 * 0.4
                    { rm = true; break; }
                }
                if rm { removed.insert(b); continue; }
            }
            if cols > 4 && cols <= 7 {
                let mut rm = false;
                for idx in (b.left + 2)..(b.right - 1) {
                    let win = Boundary::new(b.top, b.bottom, idx, idx + 1);
                    if submatrix_sum(&self.sheet.sum_content_exist, win) <= 3
                        && self.sheet.content_exist_value_density(b) < 2.0 * 0.5
                    { rm = true; break; }
                }
                if rm { removed.insert(b); continue; }
            }
            if rows > 4 && rows <= 7 {
                let mut rm = false;
                for idx in (b.top + 1)..(b.bottom - 1) {
                    let win = Boundary::new(idx, idx + 1, b.left, b.right);
                    if submatrix_sum(&self.sheet.sum_content_exist, win) <= 3
                        && self.sheet.content_exist_value_density(b) < 2.0 * 0.5
                    { rm = true; break; }
                }
                if rm { removed.insert(b); continue; }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn none_border_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            let bu = Boundary::new(b.top, b.top, b.left, b.right);
            let bd = Boundary::new(b.bottom, b.bottom, b.left, b.right);
            let bl = Boundary::new(b.top, b.bottom, b.left, b.left);
            let br = Boundary::new(b.top, b.bottom, b.right, b.right);
            for e in &[bu, bd, bl, br] {
                if submatrix_sum(&self.sheet.sum_content, *e) + submatrix_sum(&self.sheet.sum_color, *e) == 0 {
                    removed.insert(b); break;
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn overlap_pivot_filter(&mut self) {
        let pv = self.sheet.pivot_boxes.clone();
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if is_overlap_list(b, &pv, false, false, false) { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
        for pb in pv { self.boxes.push(pb); }
    }

    fn merge_filter(&mut self) {
        let mb = self.sheet.merge_boxes.clone();
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if (contains_box(b, Boundary::new(0,0,0,0), 2) && contains_box_list(&mb, b, 2))
                || mb.contains(&b)
            { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn overlap_border_cohension_filter(&mut self) {
        let small = self.sheet.small_cohension_border_regions.clone();
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if is_overlap_list(b, &small, true, true, true) { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn overlap_cohension_filter(&mut self) {
        let coh = self.sheet.cohension_regions.clone();
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if removed.contains(&b) { continue; }
            if is_overlap_list(b, &coh, true, true, false) { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn eliminate_overlaps(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        for i in 0..self.boxes.len().saturating_sub(1) {
            let b1 = self.boxes[i];
            if removed.contains(&b1) { continue; }
            let mut removed1: HashSet<Boundary> = HashSet::new();
            let mut mark_removal = false;
            for j in (i + 1)..self.boxes.len() {
                let b2 = self.boxes[j];
                if removed.contains(&b2) { continue; }
                if is_overlap(b1, b2) {
                    if area_size(b1) >= area_size(b2) { removed1.insert(b2); }
                    else { mark_removal = true; break; }
                }
            }
            if mark_removal { removed.insert(b1); }
            else { removed.extend(removed1); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn forced_border_filter(&mut self) {
        let small = self.sheet.small_cohension_border_regions.clone();
        let border_regions: Vec<Boundary> = small.iter().filter(|b| self.boxes.contains(b)).copied().collect();
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if is_overlap_list(b, &border_regions, true, false, false) { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn splitted_empty_lines_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            if removed.contains(&b) { continue; }
            if !self.verify_box_split(b) { removed.insert(b); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    // ── Suppression filters ───────────────────────────────────────────────────

    fn compare_suppression_boxes_header(&mut self, b1: Boundary, b2: Boundary) -> i32 {
        if b1.top != b2.top {
            let h1 = self.is_header_up(up_row(b1, 0, 1));
            let h2_1 = self.is_header_up(up_row(b2, 0, 1));
            let h2_2 = self.is_header_up(up_row(b2, 1, 1));
            if h1 && !h2_1 { return 1; }
            if !h1 && (h2_1 || h2_2) { return 2; }
        }
        if b1.left != b2.left {
            let h1 = self.is_header_left(left_col(b1, 0, 1));
            let h2 = self.is_header_left(left_col(b2, 0, 1));
            if h1 && !h2 { return 1; }
            if !h1 && h2 { return 2; }
        }
        if b1.bottom != b2.bottom {
            let d1 = self.is_header_up(down_row(b1, 0, 1));
            let d2 = self.is_header_up(down_row(b2, 0, 1));
            if d1 && !d2 && self.sheet.content_exist_value_density(down_row(b2, -1, 1)) < 0.2 * 2.0 {
                return 2;
            }
        }
        if b1.right != b2.right {
            let r1 = self.is_header_left(right_col(b1, 0, 1));
            let r2 = self.is_header_left(right_col(b2, 0, 1));
            if r1 && !r2 && self.sheet.content_exist_value_density(right_col(b2, -1, 1)) < 0.2 * 2.0 {
                return 2;
            }
        }
        0
    }

    fn check_sparsity_up_row(&mut self, b: Boundary, depth: i32) -> i32 {
        let area = area_size(b);
        if self.is_header_up(b) { return 1; }
        let distinct = self.sheet.text_distinct_count(b) as f64;
        if self.sheet.content_exist_value_density(b) >= 2.0 * 0.3 && distinct >= (0.2 * area).max(3.0) {
            return 1;
        }
        let ce = submatrix_sum(&self.sheet.sum_content_exist, b);
        if depth == 1 && ce <= 4 && area >= 6.0 { return 2; }
        if depth == 1 && ce <= 6 && area >= 10.0 { return 2; }
        0
    }

    fn check_sparsity_down_row(&mut self, b: Boundary, depth: i32) -> i32 {
        let area = area_size(b);
        let distinct = self.sheet.text_distinct_count(b) as f64;
        if self.sheet.content_exist_value_density(b) >= 2.0 * 0.3 && distinct >= (area * 0.2).max(3.0) {
            return 1;
        }
        let ce = submatrix_sum(&self.sheet.sum_content_exist, b);
        if depth == 1 && (ce <= 4 || self.sheet.text_distinct_count(b) < 2) && area >= 6.0 { return 2; }
        if depth == 1 && (ce <= 6 || (self.sheet.content_exist_value_density(b) <= 0.3 * 2.0 && self.sheet.text_distinct_count(b) < 3)) && area >= 10.0 { return 2; }
        0
    }

    fn check_sparsity_col(&mut self, b: Boundary, depth: i32) -> i32 {
        let area = area_size(b);
        let distinct = self.sheet.text_distinct_count(b) as f64;
        if self.sheet.content_exist_value_density(b) >= 2.0 * 0.3 && distinct >= (area * 0.2).max(3.0) {
            return 1;
        }
        let ce = submatrix_sum(&self.sheet.sum_content_exist, b);
        if depth == 1 && ce <= 4 && area >= 5.0 { return 2; }
        0
    }

    fn compare_suppression_boxes_sparsity(&mut self, b1: Boundary, b2: Boundary) -> i32 {
        if b1.top != b2.top {
            if self.check_sparsity_up_row(up_row(b1, 0, 1), 1) == 2 { return 2; }
        }
        if b1.bottom != b2.bottom {
            if self.check_sparsity_down_row(down_row(b1, 0, 1), 1) == 2 { return 2; }
        }
        if b1.left != b2.left {
            if self.check_sparsity_col(left_col(b1, 0, 1), 1) == 2 { return 2; }
        }
        if b1.right != b2.right {
            if self.check_sparsity_col(right_col(b1, 0, 1), 1) == 2 { return 2; }
        }
        for i in 0..(b2.top - b1.top) {
            let v = self.check_sparsity_up_row(up_row(b1, i, 1), i - b1.top + 1);
            if v != 0 { return v; }
        }
        for i in (b2.bottom - b1.bottom..0).rev() {
            let v = self.check_sparsity_down_row(down_row(b1, i, 1), -i + 1);
            if v != 0 { return v; }
        }
        0
    }

    fn compare_suppression_boxes_merge(&self, b1: Boundary, b2: Boundary) -> i32 {
        let mb = &self.sheet.merge_boxes;
        if is_overlap_list(right_col(b1, 0, 2), mb, false, false, false)
            && !is_overlap_list(right_col(b2, 0, 2), mb, false, false, false)
        { return 2; }
        if is_overlap_list(down_row(b1, 0, 2), mb, false, false, false)
            && !is_overlap_list(down_row(b2, 0, 2), mb, false, false, false)
        { return 2; }
        0
    }

    fn compare_suppression_boxes(&mut self, b1: Boundary, b2: Boundary) -> i32 {
        if b1 == b2 { return 0; }
        let h = self.compare_suppression_boxes_header(b1, b2);
        if h != 0 { return h; }
        let s = self.compare_suppression_boxes_sparsity(b1, b2);
        if s != 0 { return s; }
        self.compare_suppression_boxes_merge(b1, b2)
    }

    fn suppression_soft_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let boxes_snap = self.boxes.clone();
        for i in 0..boxes_snap.len() {
            let b1 = boxes_snap[i];
            if removed.contains(&b1) { continue; }
            for j in (i + 1)..boxes_snap.len() {
                let b2 = boxes_snap[j];
                if removed.contains(&b2) { continue; }
                if !is_suppression_box(b1, b2, 2, 4) || !is_overlap(b1, b2) { continue; }
                if height(b2) < 0.6 * height(b1) || height(b1) < 0.6 * height(b2)
                    || width(b2) < 0.6 * width(b1) || width(b1) < 0.6 * width(b2) { continue; }
                let ov = overlap_box(b1, b2);
                let r1 = self.compare_suppression_boxes(b1, ov);
                let r2 = if r1 == 0 { self.compare_suppression_boxes(b2, ov) } else { 0 };
                if r1 == 1 || r2 == 2 { removed.insert(b2); }
                else if r1 == 2 || r2 == 1 { removed.insert(b1); break; }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    // ── Contains-based filters ────────────────────────────────────────────────

    fn pair_contains_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for i in 0..snap.len() {
            let b1 = snap[i];
            // Skip if it has non-containment overlaps
            let cnt_ov = snap.iter().filter(|&&b2| {
                is_overlap(b1, b2) && !contains_box(b1, b2, 0) && !contains_box(b2, b1, 0)
            }).count();
            if cnt_ov != 0 { continue; }
            for j in 0..snap.len() {
                let b2 = snap[j];
                if !contains_box(b1, b2, 0) || b1 == b2 { continue; }
                // b1 contains b2: prefer the smaller one
                let remain = Boundary::new(b2.bottom + 1, b1.bottom, b1.left, b1.right);
                let density_b2 = self.sheet.content_exist_value_density(b2);
                let density_remain = self.sheet.content_exist_value_density(remain);
                if density_b2 > 2.0 * density_remain { removed.insert(b1); break; }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn pair_contains_filter_hard(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for i in 0..snap.len() {
            let b1 = snap[i];
            for j in 0..snap.len() {
                let b2 = snap[j];
                if b1 == b2 { continue; }
                if contains_box(b1, b2, 0) && !contains_box(b2, b1, 0) {
                    if area_size(b1) > 4.0 * area_size(b2) {
                        removed.insert(b1);
                        break;
                    }
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn combine_contains_filter_hard(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for i in 0..snap.len() {
            let b1 = snap[i];
            let inner: Vec<Boundary> = snap.iter().copied()
                .filter(|&b2| b2 != b1 && contains_box(b1, b2, 1) && !is_suppression_box(b1, b2, 2, -1))
                .collect();
            if inner.is_empty() { continue; }
            let inner_area: f64 = inner.iter().map(|&b| area_size(b)).sum();
            if inner_area > 0.7 * area_size(b1) { removed.insert(b1); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn combine_contains_fill_area_filter_soft(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for &b1 in &snap {
            let inner: Vec<Boundary> = snap.iter().copied()
                .filter(|&b2| b2 != b1 && contains_box(b1, b2, 1))
                .collect();
            if inner.is_empty() { continue; }
            let inner_area: f64 = inner.iter().map(|&b| area_size(b)).sum();
            if inner_area > 0.6 * area_size(b1) {
                // Check if inner boxes fill the row/col lines
                let row_lines: Vec<i32> = inner.iter().flat_map(|b| (b.top..=b.bottom).collect::<Vec<_>>()).collect();
                let col_lines: Vec<i32> = inner.iter().flat_map(|b| (b.left..=b.right).collect::<Vec<_>>()).collect();
                if crate::boundary::is_fill_box_row_col_lines(b1, &row_lines, &col_lines) {
                    removed.insert(b1);
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn combine_contains_fill_line_filter_soft(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for &b1 in &snap {
            let inner: Vec<Boundary> = snap.iter().copied()
                .filter(|&b2| b2 != b1 && contains_box(b1, b2, 2))
                .collect();
            if inner.len() < 2 { continue; }
            let row_lines: Vec<i32> = inner.iter().flat_map(|b| (b.top..=b.bottom).collect::<Vec<_>>()).collect();
            let col_lines: Vec<i32> = inner.iter().flat_map(|b| (b.left..=b.right).collect::<Vec<_>>()).collect();
            if crate::boundary::is_fill_lines(b1.top, b1.bottom, &row_lines)
                && crate::boundary::is_fill_lines(b1.left, b1.right, &col_lines)
            {
                removed.insert(b1);
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn contains_little_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for &b1 in &snap {
            let inner: Vec<Boundary> = snap.iter().copied()
                .filter(|&b2| b2 != b1 && contains_box(b1, b2, 0) && area_size(b2) < 0.1 * area_size(b1))
                .collect();
            if inner.len() > 3 { removed.insert(b1); }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn pair_alike_contains_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        // Vertical direction
        for i in 0..snap.len() {
            let b1 = snap[i];
            for j in 0..snap.len() {
                let b2 = snap[j];
                if !contains_box(b1, b2, 1) || b1.bottom <= b2.bottom { continue; }
                if (b1.left - b2.left).abs() > 2 || (b1.right - b2.right).abs() > 2 { continue; }
                if (b1.top - b2.top).abs() > 2 { continue; }
                let remain = Boundary::new(b2.bottom + 1, b1.bottom, b1.left, b1.right);
                let b2_bot = Boundary::new(b2.top.max(b2.bottom - 12), b2.bottom, b2.left, b2.right);
                let d_rem  = self.sheet.content_exist_value_density(remain);
                let d_b2   = self.sheet.content_exist_value_density(b2_bot);
                if d_b2 > 2.0 * d_rem && (d_rem > 2.0 * 0.25 || d_b2 > 2.0 * 0.5) {
                    removed.insert(b1);
                } else {
                    removed.insert(b2);
                }
            }
        }
        // Horizontal direction
        for i in 0..snap.len() {
            let b1 = snap[i];
            for j in 0..snap.len() {
                let b2 = snap[j];
                if !contains_box(b1, b2, 1) { continue; }
                if (b1.top - b2.top).abs() > 2 || (b1.bottom - b2.bottom).abs() > 2 { continue; }
                if (b1.left - b2.left).abs() > 2 || b1.right <= b2.right { continue; }
                let remain = Boundary::new(b1.top, b1.bottom, b2.right + 1, b1.right);
                let b2_right = Boundary::new(b2.top, b2.bottom, b2.left.max(b2.right - 12), b2.right);
                let d_rem  = self.sheet.content_exist_value_density(remain);
                let d_b2   = self.sheet.content_exist_value_density(b2_right);
                if d_b2 > 2.0 * d_rem && (d_b2 > 0.5 || d_rem > 0.25) {
                    removed.insert(b1);
                } else {
                    removed.insert(b2);
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn nesting_combination_filter(&mut self) {
        let col_lines = self.sheet.col_boundary_lines.clone();
        let row_lines = self.sheet.row_boundary_lines.clone();
        let mut removed: Vec<Boundary> = Vec::new();
        for &left in &col_lines {
            for &right in &col_lines {
                if left >= right { continue; }
                let group: Vec<Boundary> = self.boxes.iter().copied()
                    .filter(|b| b.left >= left - 1 && b.left <= left + 3 && b.right >= right - 1 && b.right <= right + 3)
                    .collect();
                removed.extend(find_inter_candidates(&group));
            }
        }
        for &up in &row_lines {
            for &down in &row_lines {
                if up >= down { continue; }
                let group: Vec<Boundary> = self.boxes.iter().copied()
                    .filter(|b| b.top >= up - 1 && b.bottom >= down - 1 && b.top <= up + 3 && b.bottom <= down + 3)
                    .collect();
                removed.extend(find_inter_candidates(&group));
            }
        }
        let rm_set: HashSet<Boundary> = removed.into_iter().collect();
        remove_these_candidates(&rm_set, &mut self.boxes);
    }

    fn header_priority_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        // Left/right dimension
        for i in 0..snap.len() {
            let b1 = snap[i];
            for j in 0..snap.len() {
                let b2 = snap[j];
                if b1 == b2 || !is_overlap(b1, b2) || contains_box(b2, b1, 2) { continue; }
                if (b1.top - b2.top).abs() > 2 || (b1.bottom - b2.bottom).abs() > 2 { continue; }
                if (b1.left - b2.left).abs() <= 1 { continue; }
                let b1l = left_col(b1, 0, 1);
                let b2l = left_col(b2, 0, 1);
                if contains_box(b1, b2, 0) && self.is_header_up(b2) && !self.is_header_up(Boundary::new(b1.top, b1.top, b2.left, b2.right)) {
                    removed.insert(b1);
                } else if self.is_header_left(b1l) && !self.is_header_left(b2l) {
                    removed.insert(b2);
                } else if self.is_header_left(b2l) && !self.is_header_left(b1l) {
                    removed.insert(b1); break;
                }
            }
        }
        // Up/down dimension
        let snap2 = self.boxes.clone();
        for i in 0..snap2.len() {
            let b1 = snap2[i];
            for j in 0..snap2.len() {
                let b2 = snap2[j];
                if b2 == b1 || !is_overlap(b1, b2) { continue; }
                if (b1.left - b2.left).abs() > 2 || (b1.right - b2.right).abs() > 2 { continue; }
                if (b1.top - b2.top).abs() <= 1 { continue; }
                let h1 = self.is_header_up(up_row(b1, 0, 1));
                let h2 = self.is_header_up(up_row(b2, 0, 1));
                if h1 && !h2 { removed.insert(b2); }
                else if h2 && !h1 { removed.insert(b1); break; }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn overlap_up_header_filter(&mut self) {
        let up_headers: Vec<Boundary> = {
            let snap = self.boxes.clone();
            snap.iter().filter_map(|&b| {
                let h = Boundary::new(b.top, b.top, b.left, b.right);
                if self.is_header_up(h) { Some(h) } else { None }
            }).collect()
        };
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes {
            for &hdr in &up_headers {
                let up_of_hdr = Boundary::new(hdr.top - 1, hdr.bottom - 1, hdr.left, hdr.right);
                let same_boundary = (up_of_hdr.left == b.left && up_of_hdr.right == b.right)
                    || ((up_of_hdr.left - b.left).abs() <= 1 && (up_of_hdr.right - b.right).abs() <= 1 && b.right - b.left > 5)
                    || ((up_of_hdr.left - b.left).abs() <= 2 && (up_of_hdr.right - b.right).abs() <= 2 && b.right - b.left > 10)
                    || ((b.bottom - up_of_hdr.top - 1).abs() < 2 && up_of_hdr.right - up_of_hdr.left > 3);
                if same_boundary && is_overlap(b, up_of_hdr) && (up_of_hdr.top - b.top).abs() > 1 {
                    removed.insert(b); break;
                }
                if (up_of_hdr.top + 1 - b.top).abs() <= 1 && is_overlap(b, hdr)
                    && b.left >= up_of_hdr.left + 1 && b.left <= up_of_hdr.right - 1
                {
                    let dev = Boundary::new(hdr.top, hdr.bottom, b.left - 2, b.left);
                    if submatrix_sum(&self.sheet.sum_content_exist, dev) >= 6 && self.header_rate(dev, 0) == 1.0 {
                        removed.insert(b);
                    }
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn overlap_header_filter(&mut self) {
        let up_headers: Vec<Boundary> = {
            let s = self.boxes.clone();
            s.iter().filter_map(|&b| {
                let h = Boundary::new(b.top, b.top, b.left, b.right);
                if self.is_header_up(h) { Some(h) } else { None }
            }).collect()
        };
        let left_headers: Vec<Boundary> = {
            let s = self.boxes.clone();
            s.iter().filter_map(|&b| {
                let h = Boundary::new(b.top, b.bottom, b.left, b.left);
                if self.is_header_left(h) { Some(h) } else { None }
            }).collect()
        };
        let mut removed: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for &b in &snap {
            'outer_up: for &uh in &up_headers {
                let region = Boundary::new(b.bottom.max(b.bottom - 4).max(b.top), b.bottom, b.left - 1, b.right - 1);
                if !contains_box(b, uh, 0) && is_overlap(region, uh) {
                    let has_alt = snap.iter().any(|&b2| {
                        is_overlap(b, b2) && !is_overlap(b2, uh)
                            && (b.right - b2.right).abs() < 2 && (b.left - b2.left).abs() < 2
                    });
                    if has_alt { removed.insert(b); break 'outer_up; }
                }
            }
            'outer_left: for &lh in &left_headers {
                let region = Boundary::new(b.top - 1, b.bottom - 1, b.right.max(b.right - 5).max(b.left), b.right);
                if !contains_box(b, lh, 0) && is_overlap(region, lh) {
                    let has_alt = snap.iter().any(|&b2| is_overlap(b, b2) && !is_overlap(b2, lh));
                    if has_alt { removed.insert(b); break 'outer_left; }
                }
            }
        }
        remove_these_candidates(&removed, &mut self.boxes);
    }

    fn adjoin_header_filter(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for i in 0..snap.len() {
            let b1 = snap[i];
            for j in (i + 1)..snap.len() {
                let b2 = snap[j];
                if b1 == b2 || !is_overlap(b1, b2) { continue; }
                let merged_left  = b1.left.min(b2.left);
                let merged_right = b1.right.max(b2.right);
                let check_up  = b1.top == b2.top && b2.bottom - b2.top > 4 && b1.bottom - b1.top > 4
                    && self.is_header_up(Boundary::new(b1.top, b1.top, merged_left, merged_right));
                let check_left= b1.left == b2.left && b2.right - b2.left > 4 && b1.right - b1.left > 4
                    && self.is_header_left(Boundary::new(b1.top.min(b2.top), b1.bottom.max(b2.bottom), b1.left, b1.left));
                if !(check_up || check_left) { continue; }
                let merged = unify_box(b1, b2);
                let no_other_overlap = snap.iter().all(|&b3| b3 == b1 || b3 == b2 || !is_overlap(merged, b3));
                if no_other_overlap {
                    if b1 != merged { removed.insert(b1); }
                    if b2 != merged { removed.insert(b2); }
                    appended.insert(merged);
                }
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
    }

    // ── Region-growth add-back ────────────────────────────────────────────────

    fn add_region_growth(&mut self, thresh_hor: i32, thresh_ver: i32) {
        self.region_growth_boxes = find_connected_ranges(
            &self.sheet.content_strs, None, thresh_hor, thresh_ver, 1,
        );
        let mut appended: HashSet<Boundary> = HashSet::new();
        let mut removed: HashSet<Boundary> = HashSet::new();
        let rg = self.region_growth_boxes.clone();
        for &b in &rg {
            if submatrix_sum(&self.sheet.sum_content_exist, b) < 24 { continue; }
            let overlapping: Vec<Boundary> = self.boxes.iter().copied().filter(|&b2| is_overlap(b2, b)).collect();
            let inner: Vec<Boundary> = self.boxes.iter().copied()
                .filter(|&b2| contains_box(b, b2, 1) && !is_suppression_box(b, b2, 2, -1))
                .collect();
            if overlapping.is_empty() {
                appended.insert(b);
            } else if overlapping.len() == 1 && inner.len() == 1 {
                let diff_area = area_size(b) - area_size(inner[0]);
                let diff_ce = submatrix_sum(&self.sheet.sum_content_exist, b)
                    - submatrix_sum(&self.sheet.sum_content_exist, inner[0]);
                if diff_area > 20.0 && diff_area > 0.0 && (diff_ce as f64 / diff_area) > 0.5 * 2.0 {
                    appended.insert(b);
                    removed.insert(b); // mirroring C# bug: it adds b to both
                }
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn add_compact_region_growth(&mut self) {
        let rg = self.region_growth_boxes.clone();
        let mut compact = self.pro_process_reduce_to_compact(rg);
        compact = self.pro_process_reduce_to_compact(compact);
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &compact {
            if submatrix_sum(&self.sheet.sum_content_exist, b) < 7 { continue; }
            let expanded = Boundary::new(b.top - 1, b.bottom + 1, b.left - 1, b.right + 1);
            let diff = submatrix_sum(&self.sheet.sum_content_exist, expanded)
                - submatrix_sum(&self.sheet.sum_content_exist, b);
            if diff > 10 { continue; }
            if !is_overlap_list(b, &self.boxes, false, false, false) {
                appended.insert(b);
            }
        }
        append_these_candidates(appended, &mut self.boxes);
    }

    fn pro_process_reduce_to_compact(&mut self, ranges: Vec<Boundary>) -> Vec<Boundary> {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for b in &ranges {
            let mut nb = *b;
            let mut changed = true;
            while changed && nb.left <= nb.right && nb.top <= nb.bottom {
                changed = false;
                while nb.top < nb.bottom && self.sheet.content_exist_value_density(up_row(nb, nb.top - nb.top, 1)) < 0.8 {
                    nb.top += 1; changed = true;
                }
                while nb.bottom > nb.top && self.sheet.content_exist_value_density(down_row(nb, nb.bottom - nb.bottom, 1)) < 0.8 {
                    nb.bottom -= 1; changed = true;
                }
                while nb.left < nb.right && self.sheet.content_exist_value_density(left_col(nb, nb.left - nb.left, 1)) < 0.8 {
                    nb.left += 1; changed = true;
                }
                while nb.right > nb.left && self.sheet.content_exist_value_density(right_col(nb, nb.right - nb.right, 1)) < 0.8 {
                    nb.right -= 1; changed = true;
                }
            }
            if nb != *b {
                removed.insert(*b);
                if nb.left < nb.right && nb.top < nb.bottom { appended.insert(nb); }
            }
        }
        let mut result = ranges;
        remove_and_append_candidates(&removed, appended, &mut result);
        result
    }

    // ── Border cohesion addition ──────────────────────────────────────────────

    fn border_cohensions_addition(&mut self) {
        let mut border_regions: Vec<Boundary> = Vec::new();
        border_regions.extend(self.sheet.cohension_border_regions.clone());
        for &b in &self.sheet.small_cohension_border_regions.clone() {
            if b.bottom - b.top > 1 && b.right - b.left > 1 { border_regions.push(b); }
        }
        // Filter out border regions that have dense content adjacent
        let clear: Vec<Boundary> = border_regions.into_iter().filter(|&b| {
            let bu = up_row(b, -1, 1);
            let bd = down_row(b, -1, 1);
            let bl = left_col(b, -1, 1);
            let br = right_col(b, -1, 1);
            if b.right - b.left > 3 && self.sheet.content_exist_value_density(bu) >= 2.0 * 0.5 { return false; }
            if b.right - b.left > 3 && self.sheet.content_exist_value_density(bd) >= 2.0 * 0.5 { return false; }
            if b.bottom - b.top > 3 && self.sheet.content_exist_value_density(bl) >= 2.0 * 0.5 { return false; }
            if b.bottom - b.top > 3 && self.sheet.content_exist_value_density(br) >= 2.0 * 0.5 { return false; }
            true
        }).collect();
        // Suppression filter
        let filtered = self.border_cohension_filter_suppression(clear);
        self.boxes.extend(filtered);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn border_cohension_filter_suppression(&self, mut cohensions: Vec<Boundary>) -> Vec<Boundary> {
        let mut removed: HashSet<Boundary> = HashSet::new();
        for &b1 in &self.boxes {
            for &bc in &cohensions {
                if is_suppression_box(b1, bc, 2, -1) && b1 != bc { removed.insert(bc); }
            }
        }
        cohensions.retain(|b| !removed.contains(b));
        cohensions
    }

    // ── Vertical relational merge ─────────────────────────────────────────────

    fn vertical_relational_merge(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut forced: Vec<Boundary> = Vec::new();
        let snap = self.boxes.clone();

        for &b in &snap {
            let dr  = down_row(b, 0, 1);
            let mut dr2 = down_row(dr, -1, 1);
            for k in 1..6 {
                dr2 = down_row(dr, -k, 1);
                let left_sum = submatrix_sum(&self.sheet.sum_content_exist, left_col(dr2, 0, 1));
                if (left_sum != 0 && k > 1) || submatrix_sum(&self.sheet.sum_content_exist, dr2) >= 4 { break; }
            }
            if self.sheet.content_exist_value_density(dr2) >= 2.0 * 0.2
                && submatrix_sum(&self.sheet.sum_content_exist, dr2) >= 4
                && self.sheet.compute_similar_row(dr, dr2) < 0.1
                && !self.is_header_up(dr2)
                && !self.sheet.exists_merged(dr2)
            {
                forced.push(Boundary::new(dr.top, dr2.top, b.left, b.right));
            }

            let ur  = up_row(b, 0, 1);
            let mut ur2 = up_row(ur, -1, 1);
            for k in 1..6 {
                ur2 = up_row(ur, -k, 1);
                let left_sum = submatrix_sum(&self.sheet.sum_content_exist, left_col(ur2, 0, 1));
                if (left_sum != 0 && k > 1) || submatrix_sum(&self.sheet.sum_content_exist, ur2) >= 4 { break; }
            }
            if self.sheet.content_exist_value_density(ur2) >= 2.0 * 0.2
                && submatrix_sum(&self.sheet.sum_content_exist, ur2) >= 4
                && self.sheet.compute_similar_row(ur, ur2) < 0.1
                && !self.is_header_up(ur)
                && !self.sheet.exists_merged(ur)
            {
                forced.push(Boundary::new(ur2.top, ur.top, b.left, b.right));
            }
        }
        forced = distinct_boxes(forced);

        for &f in &forced {
            for &b in &snap {
                if f.left == b.left && f.right == b.right && is_overlap(b, f) && !contains_box(b, f, 0) {
                    removed.insert(b);
                }
            }
        }
        remove_and_append_candidates(&removed, std::iter::empty(), &mut self.boxes);
    }

    // ── Trimmers ─────────────────────────────────────────────────────────────

    fn surrounding_boundaries_trim(&mut self) {
        let mut cnt_boxes = -1i32;
        while self.boxes.len() as i32 != cnt_boxes {
            self.boxes = distinct_boxes(self.boxes.clone());
            cnt_boxes = self.boxes.len() as i32;
            self.find_left_boundary_not_sparse();
            self.find_up_boundary_not_sparse();
            self.sparse_boundaries_trim();
            self.bottom_boundary_trim();
            self.up_boundary_compact_trim();
            self.none_border_filter();
        }
    }

    fn up_header_trim(&mut self) {
        self.find_up_boundary_not_sparse();
        self.find_up_boundary_is_header();
        self.find_up_boundary_is_clear_header();
        self.find_up_boundary_is_compact_header(0.6, 0.8);
        self.find_up_boundary_is_compact_header(0.4, 0.7);
        self.find_up_boundary_is_compact_header(0.2, 0.5);
    }

    fn find_up_boundary_not_sparse(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut ub1 = Boundary::new(b.top, b.top, b.left, b.right);
            let ub2 = Boundary::new(b.top + 1, b.top + 1, b.left, b.right);
            while ub1.top < nb.bottom {
                let d = self.sheet.content_exist_value_density(ub1);
                let distinct = self.sheet.text_distinct_count(ub1);
                if d < 2.0 * 0.2 || (b.right - b.left + 1 >= 5 && distinct <= 1) {
                    ub1 = Boundary::new(ub1.top + 1, ub1.top + 1, nb.left, nb.right);
                } else if !self.is_header_up(ub1) && b.right - b.left > 7
                    && 2 * submatrix_sum(&self.sheet.sum_content_exist, ub1)
                        <= submatrix_sum(&self.sheet.sum_content_exist, ub2)
                    && (submatrix_sum(&self.sheet.sum_content_exist, ub1) < 7
                        || d < 0.3 * 2.0)
                {
                    ub1 = Boundary::new(ub1.top + 1, ub1.top + 1, nb.left, nb.right);
                } else { break; }
            }
            nb.top = ub1.top;
            if b != nb && nb.top < nb.bottom { removed.insert(b); appended.insert(nb); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn find_up_boundary_is_header(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut ubr = Boundary::new(b.top, b.top, b.left, b.right);
            while !self.is_header_up(ubr) && ubr.top <= b.top + 3 && ubr.top < b.bottom {
                ubr = Boundary::new(ubr.top + 1, ubr.top + 1, nb.left, nb.right);
            }
            nb.top = ubr.top;
            if b == nb { continue; }
            if self.is_header_up_with_data_area(ubr, b) && nb.top < nb.bottom {
                removed.insert(b); appended.insert(nb);
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn find_up_boundary_is_clear_header(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut ubr = Boundary::new(b.top, b.top, b.left, b.right);
            while submatrix_sum(&self.sheet.sum_content_exist, ubr) > 3 && ubr.top < b.top + 6 && ubr.top < b.bottom {
                ubr = Boundary::new(ubr.top + 1, ubr.top + 1, nb.left, nb.right);
            }
            if submatrix_sum(&self.sheet.sum_content_exist, ubr) > 3 { continue; }
            while submatrix_sum(&self.sheet.sum_content_exist, ubr) < 3 && ubr.top < b.top + 2 && ubr.top < b.bottom {
                ubr = Boundary::new(ubr.top + 1, ubr.top + 1, nb.left, nb.right);
            }
            nb.top = ubr.top;
            if b == nb || submatrix_sum(&self.sheet.sum_content_exist, ubr) < 3 { continue; }
            if self.is_header_up_with_data_area(ubr, b) && nb.top < nb.bottom {
                removed.insert(b); appended.insert(nb);
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn find_up_boundary_is_compact_header(&mut self, thresh_low: f64, _thresh_high: f64) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            if b.right - b.left + 1 <= 4 { continue; }
            let mut nb = b;
            let mut ubr = Boundary::new(b.top, b.top, b.left, b.right);
            while self.sheet.content_exist_value_density(ubr) < 2.0 * thresh_low
                && ubr.top < b.top + 6 && ubr.top < b.bottom
            {
                ubr = Boundary::new(ubr.top + 1, ubr.top + 1, nb.left, nb.right);
            }
            nb.top = ubr.top;
            if b == nb || self.sheet.content_exist_value_density(ubr) < 2.0 * thresh_low { continue; }
            if self.is_header_up_with_data_area(ubr, b) && nb.top < nb.bottom {
                removed.insert(b); appended.insert(nb);
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn up_boundary_compact_trim(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut r1 = Boundary::new(b.top, b.top, b.left, b.right);
            let mut r2 = Boundary::new(b.top + 1, b.top + 1, b.left, b.right);
            while !(self.is_header_up(r1) && !self.is_header_up(r2))
                && 2.0 * self.sheet.content_exist_value_density(r1) <= self.sheet.content_exist_value_density(r2)
                && r1.top < b.top + 6 && r2.top < b.bottom
            {
                r1 = Boundary::new(r1.top + 1, r1.top + 1, nb.left, nb.right);
                r2 = Boundary::new(r2.top + 1, r2.top + 1, nb.left, nb.right);
            }
            nb.top = r1.top;
            if b == nb || self.sheet.content_exist_value_density(r1) <= 0.6 * self.sheet.content_exist_value_density(r2) {
                continue;
            }
            if nb.top < nb.bottom { removed.insert(b); appended.insert(nb); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn sparse_boundaries_trim(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut changed = true;
            while changed && nb.left < nb.right && nb.top < nb.bottom {
                changed = false;
                // left
                if nb.left > 0 {
                    let mut lb = Boundary::new(nb.top, nb.bottom, nb.left, nb.left);
                    while submatrix_sum(&self.sheet.sum_content_exist, lb) < 3 {
                        lb = Boundary::new(lb.top, lb.bottom, lb.left + 1, lb.left + 1);
                        if submatrix_sum(&self.sheet.sum_content_exist, lb) == 0 { break; }
                    }
                    while lb.left < nb.right && submatrix_sum(&self.sheet.sum_content_exist, lb) == 0 {
                        lb = Boundary::new(lb.top, lb.bottom, lb.left + 1, lb.left + 1);
                        changed = true; nb.left = lb.left;
                    }
                }
                // right
                if nb.right <= self.sheet.width {
                    let mut rb = Boundary::new(nb.top, nb.bottom, nb.right, nb.right);
                    while submatrix_sum(&self.sheet.sum_content_exist, rb) < 3 {
                        rb = Boundary::new(rb.top, rb.bottom, rb.left - 1, rb.right - 1);
                        if submatrix_sum(&self.sheet.sum_content_exist, rb) == 0 { break; }
                    }
                    while rb.right > nb.left && submatrix_sum(&self.sheet.sum_content_exist, rb) == 0 {
                        rb = Boundary::new(rb.top, rb.bottom, rb.left - 1, rb.right - 1);
                        changed = true; nb.right = rb.right;
                    }
                }
                // up
                if nb.top > 0 {
                    let mut ub = Boundary::new(nb.top, nb.top, nb.left, nb.right);
                    while !self.is_header_up(ub) && (submatrix_sum(&self.sheet.sum_content_exist, ub) < 3
                        || self.sheet.content_exist_value_density(ub) < 2.0 * 0.1
                        || (submatrix_sum(&self.sheet.sum_content_exist, ub) < 5 && nb.right - nb.left + 1 > 7))
                    {
                        ub = Boundary::new(ub.top + 1, ub.bottom + 1, ub.left, ub.right);
                        if submatrix_sum(&self.sheet.sum_content_exist, ub) == 0 { break; }
                    }
                    while ub.top < nb.bottom && submatrix_sum(&self.sheet.sum_content_exist, ub) == 0 {
                        ub = Boundary::new(ub.top + 1, ub.bottom + 1, ub.left, ub.right);
                        changed = true; nb.top = ub.top;
                    }
                }
                // down
                if nb.bottom <= self.sheet.height {
                    let mut db = Boundary::new(nb.bottom, nb.bottom, nb.left, nb.right);
                    while submatrix_sum(&self.sheet.sum_content_exist, db) < 3 {
                        db = Boundary::new(db.top - 1, db.top - 1, nb.left, nb.right);
                        if submatrix_sum(&self.sheet.sum_content_exist, db) == 0 { break; }
                    }
                    while db.bottom > nb.top && submatrix_sum(&self.sheet.sum_content_exist, db) == 0 {
                        db = Boundary::new(db.top - 1, db.top - 1, nb.left, nb.right);
                        changed = true; nb.bottom = db.bottom;
                    }
                }
            }
            if b != nb { removed.insert(b); if nb.left < nb.right && nb.top < nb.bottom { appended.insert(nb); } }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn bottom_boundary_trim(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut bl = b.bottom;
            while bl > b.top {
                let row = Boundary::new(bl, bl, b.left, b.right);
                let wide = b.right - b.left + 1 > 6;
                let lpart = Boundary::new(bl, bl, (b.left + 5).min(b.right - 1), b.right);
                let prev4 = Boundary::new(bl.max(b.top).max(bl - 4), bl.max(bl - 2).saturating_sub(1), b.left, b.right);
                let left3 = Boundary::new(bl, bl, b.left, b.left + 2);
                if wide && (self.sheet.exists_merged(lpart)
                    || (self.sheet.exists_merged(row) && !self.sheet.exists_merged(prev4))
                    || (submatrix_sum(&self.sheet.sum_content_exist, Boundary::new(bl, bl, b.left, b.left)) == 0
                        && self.sheet.content_exist_value_density(row) < 0.15 * 2.0)
                    || (submatrix_sum(&self.sheet.sum_content_exist, left3) == 0
                        && self.sheet.content_exist_value_density(row) < 0.3 * 2.0))
                {
                    bl -= 1; continue;
                }
                if b.right - b.left + 1 >= 2 && submatrix_sum(&self.sheet.sum_content_exist, row) < 3 {
                    bl -= 1; continue;
                }
                break;
            }
            nb.bottom = bl;
            // Skip header at bottom
            let mut bl_skip = bl;
            let mut cnt = 0;
            while cnt < 5 && bl > b.top
                && submatrix_sum(&self.sheet.sum_content_exist, Boundary::new(bl_skip, bl_skip, b.left, b.right)) >= 2
                && self.header_rate(Boundary::new(bl_skip, bl_skip, b.left, b.right), 0) > 0.6
            {
                cnt += 1; bl_skip -= 1;
            }
            if cnt < 3 && submatrix_sum(&self.sheet.sum_content_exist, Boundary::new(bl_skip, bl_skip, b.left, b.right)) == 0 {
                while bl_skip > b.top && submatrix_sum(&self.sheet.sum_content_exist, Boundary::new(bl_skip, bl_skip, b.left, b.right)) == 0 {
                    bl_skip -= 1;
                }
                nb.bottom = bl_skip;
            }
            if b == nb { continue; }
            removed.insert(b);
            if nb.top < nb.bottom { appended.insert(nb); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn find_left_boundary_not_sparse(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            let mut mark = true;
            while mark && nb.left < nb.right {
                mark = false;
                let ll = Boundary::new(nb.top, nb.bottom, nb.left, nb.left);
                if (b.bottom - b.top + 1) >= 5
                    && self.sheet.content_exist_value_density(ll) < 0.7
                    && self.sheet.text_distinct_count(ll) <= 1
                {
                    mark = true; nb.left += 1;
                } else if ((b.bottom - b.top) > 3 && submatrix_sum(&self.sheet.sum_content_exist, ll) < 5)
                    || ((b.bottom - b.top + 1) > 10
                        && (submatrix_sum(&self.sheet.sum_content_exist, ll) < 7
                            || self.sheet.content_exist_value_density(ll) < 2.0 * 0.15))
                {
                    mark = true; nb.left += 1;
                }
            }
            if b != nb { removed.insert(b); if nb.left < nb.right && nb.top < nb.bottom { appended.insert(nb); } }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn retrieve_distant_up_header(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let already = self.is_header_up_with_data_area(up_row(b, 0, 1), b);
            if already { continue; }
            let mut compact_row = up_row(b, -1, 1);
            for hsp in 1..5i32 {
                compact_row = up_row(b, -hsp, 1);
                if submatrix_sum(&self.sheet.sum_content_exist, compact_row) >= 6
                    && self.sheet.text_distinct_count(compact_row) > 1
                    && self.sheet.content_exist_value_density(compact_row) >= 2.0 * 0.5
                { break; }
            }
            let mut mark_header = self.is_header_up(compact_row) && self.header_rate(compact_row, 6) > 0.8;
            let mut cnt = 0;
            while cnt < 3 && mark_header && self.is_header_up_simple(up_row(compact_row, -1, 1)) {
                cnt += 1; compact_row = up_row(compact_row, -1, 1);
            }
            if mark_header {
                let above_sparse = submatrix_sum(&self.sheet.sum_content_exist, up_row(compact_row, -1, 1)) < 3
                    || submatrix_sum(&self.sheet.sum_content_exist, up_row(compact_row, -2, 1)) < 3
                    || submatrix_sum(&self.sheet.sum_content_exist, up_row(compact_row, -3, 1)) < 3;
                if above_sparse {
                    removed.insert(b);
                    appended.insert(Boundary::new(compact_row.top, b.bottom, b.left, b.right));
                }
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
    }

    fn retrieve_up_header(&mut self, step: i32) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut mark_hdr = self.is_header_up(Boundary::new(b.top, b.top, b.left, b.right));
            let mut up = b.top - step;
            while up > 0 {
                let bup = Boundary::new(up, up, b.left, b.right);
                if mark_hdr && !self.is_header_up(bup) && !self.sheet.exists_merged(bup) { break; }
                if distinct_strs(&self.sheet.content_strs, up, up, b.left, b.right) >= 2 { up -= 1; continue; }
                if self.sheet.exists_merged(bup) && distinct_strs(&self.sheet.content_strs, up, up, b.left, b.right) >= 2 { up -= 1; continue; }
                if self.sheet.content_exist_value_density(bup) >= 2.0 * 0.4
                    && submatrix_sum(&self.sheet.sum_content_exist, bup) >= 4
                    && distinct_strs(&self.sheet.content_strs, up, up, b.left, b.right) >= 2
                { up -= 1; continue; }
                if b.right - b.left >= 8
                    && (self.sheet.row_content_exist_value_density_split(bup, 4) >= 0.7
                        || self.sheet.row_content_exist_value_density_split(bup, 8) >= 0.7)
                    && !(self.sheet.content_exist_value_density(bup) >= 2.0 * 0.4 && !self.is_header_up(bup))
                { up -= 1; continue; }
                break;
            }
            if up < b.top - step && up >= b.top - 6 {
                removed.insert(b);
                appended.insert(Boundary::new(up + 1, b.bottom, b.left, b.right));
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn retrieve_left(&mut self, step: i32) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        let snap = self.boxes.clone();
        for &b in &snap {
            let mut left = b.left - step;
            while left > 0 {
                let bl = Boundary::new(b.top, b.bottom, left, left);
                if self.sheet.exists_merged(bl) { left -= 1; continue; }
                if self.sheet.content_exist_value_density(bl) >= 2.0 * 0.4
                    && submatrix_sum(&self.sheet.sum_content_exist, bl) >= 4
                { left -= 1; continue; }
                if b.bottom - b.top >= 8
                    && (self.sheet.col_content_exist_value_density_split(bl, 4) == 1.0
                        || self.sheet.col_content_exist_value_density_split(bl, 8) >= 0.8)
                    && !(self.sheet.content_exist_value_density(bl) >= 2.0 * 0.4 && !self.is_header_left(bl))
                { left -= 1; continue; }
                break;
            }
            if left < b.left - step && left >= b.left - 5 {
                let gap = Boundary::new(b.top, b.bottom, left + 1, b.left - 1);
                if !is_overlap_list(gap, &snap, false, false, false) {
                    removed.insert(b);
                    appended.insert(Boundary::new(b.top, b.bottom, left + 1, b.right));
                }
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn retrieve_left_header(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut nb = b;
            loop {
                if nb.left <= 1 { break; }
                let bl1 = left_col(nb, 0, 1);
                let bl_m1 = left_col(nb, -1, 1);
                let bl_m2 = left_col(nb, -2, 1);
                let bl_m3 = left_col(nb, -3, 1);
                if is_overlap_list(bl_m2, &self.boxes, false, false, false) { break; }
                let tmp;
                if !self.is_header_left(bl1)
                    && submatrix_sum(&self.sheet.sum_content, bl_m1) > 3
                    && submatrix_sum(&self.sheet.sum_content, bl_m2) == 0
                {
                    tmp = Boundary::new(nb.top, nb.bottom, nb.left - 1, nb.right);
                } else if !self.is_header_left(bl1)
                    && submatrix_sum(&self.sheet.sum_content, bl_m1) + submatrix_sum(&self.sheet.sum_content, bl_m2) > 3
                    && submatrix_sum(&self.sheet.sum_content, bl_m3) == 0
                {
                    tmp = Boundary::new(nb.top, nb.bottom, nb.left - 2, nb.right);
                } else if submatrix_sum(&self.sheet.sum_content, bl_m1) > 5
                    && self.sheet.col_content_exist_value_density_split(bl_m1, 5) > 0.2
                    && submatrix_sum(&self.sheet.sum_border_row, bl_m2) == 0
                {
                    tmp = Boundary::new(nb.top, nb.bottom, nb.left - 1, nb.right);
                } else if submatrix_sum(&self.sheet.sum_border_row, bl_m1) > 0 {
                    tmp = Boundary::new(nb.top, nb.bottom, nb.left - 1, nb.right);
                } else { break; }
                if tmp == nb { break; }
                nb = tmp;
            }
            if nb != b { removed.insert(b); appended.insert(nb); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn left_header_trim(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            if distinct_strs(&self.sheet.content_strs, b.top, b.bottom, b.left, b.left) <= 1 {
                removed.insert(b);
                appended.insert(Boundary::new(b.top, b.bottom, b.left + 1, b.right));
            }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn bottom_trim(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut k = 0;
            while k < b.bottom - b.top {
                let row = Boundary::new(b.bottom - k, b.bottom - k, b.left, b.right);
                if self.sheet.content_exist_value_density(row) < 0.3 * 2.0
                    || (b.right - b.left + 1 > 3
                        && distinct_strs(&self.sheet.content_strs, b.bottom - k, b.bottom - k, b.left, b.right) <= 1)
                { k += 1; } else { break; }
            }
            if k > 0 { removed.insert(b); appended.insert(Boundary::new(b.top, b.bottom - k, b.left, b.right)); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }

    fn up_trim_simple(&mut self) {
        let mut removed: HashSet<Boundary> = HashSet::new();
        let mut appended: HashSet<Boundary> = HashSet::new();
        for &b in &self.boxes.clone() {
            let mut k = 0;
            while k < b.bottom - b.top {
                if distinct_strs(&self.sheet.content_strs, b.top + k, b.top + k, b.left, b.right) <= 1 {
                    k += 1;
                } else { break; }
            }
            if k > 0 { removed.insert(b); appended.insert(Boundary::new(b.top + k, b.bottom, b.left, b.right)); }
        }
        remove_and_append_candidates(&removed, appended, &mut self.boxes);
        self.boxes = distinct_boxes(self.boxes.clone());
    }
}

fn find_inter_candidates(ranges: &[Boundary]) -> Vec<Boundary> {
    let mut inter = Vec::new();
    for &b in ranges {
        let mark_in  = ranges.iter().any(|&b2| b2 != b && contains_box(b2, b, 2));
        let mark_out = ranges.iter().any(|&b2| b2 != b && contains_box(b, b2, 2));
        if mark_in && mark_out { inter.push(b); }
    }
    inter
}
