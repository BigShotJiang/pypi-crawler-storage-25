// Header recognition logic lives on TableDetectionHybrid (see detector.rs).
// This module re-exports the relevant public entry points for clarity and
// hosts the unit tests for header scoring.

/// Header-scoring unit tests.
#[cfg(test)]
mod tests {
    use crate::boundary::Boundary;
    use crate::cell_features::CellFeatures;
    use crate::sheet_map::SheetMap;
    use crate::detector::TableDetectionHybrid;

    fn make_sheet_with_row(texts: &[&str]) -> SheetMap {
        let rows = 3usize;
        let cols = texts.len();
        let features: Vec<Vec<CellFeatures>> = (0..rows).map(|_i| {
            texts.iter().map(|&t| {
                let tlen = t.len();
                CellFeatures {
                    text_length: tlen,
                    alphabet_ratio: if tlen > 0 {
                        t.chars().filter(|c| c.is_alphabetic()).count() as f64 / tlen as f64
                    } else { 0.0 },
                    number_ratio: if tlen > 0 {
                        t.chars().filter(|c| c.is_ascii_digit()).count() as f64 / tlen as f64
                    } else { 0.0 },
                    sp_char_ratio: 0.0,
                    ..Default::default()
                }
            }).collect()
        }).collect();

        let cells: Vec<Vec<String>> = (0..rows).map(|_| {
            texts.iter().map(|&s| s.to_string()).collect()
        }).collect();

        SheetMap::new(7, 7, features, cells, vec![], vec![])
    }

    /// A row of all-text cells (column headers) should score as a header.
    #[test]
    fn all_text_row_is_header() {
        let texts: Vec<&str> = vec!["Name", "Address", "City", "State", "Country"];
        let sheet = make_sheet_with_row(&texts);
        let det = TableDetectionHybrid::new_for_sheet(sheet);

        // Row 1 in 1-indexed within the padded sheet is row 1+ROW_OFFSET
        let header = Boundary::new(8, 8, 8, 8 + texts.len() as i32 - 1);
        let rate = det.header_rate(header, 6);
        assert!(rate > 0.4, "All-text row should score high header rate, got {}", rate);
    }

    /// A row of all-numeric cells should not score as a header.
    #[test]
    fn all_number_row_is_not_header() {
        let texts: Vec<&str> = vec!["123", "456", "789", "012", "345"];
        let sheet = make_sheet_with_row(&texts);
        let det = TableDetectionHybrid::new_for_sheet(sheet);

        let header = Boundary::new(8, 8, 8, 8 + texts.len() as i32 - 1);
        let rate = det.header_rate(header, 6);
        assert!(rate <= 0.3, "All-number row should score low header rate, got {}", rate);
    }
}
