use std::collections::VecDeque;
use crate::boundary::Boundary;

// Neighbour offsets: up, down, right, left (4 cardinal directions, matching C# step=4)
static DX: [i32; 4] = [1, -1, 0, 0];
static DY: [i32; 4] = [0, 0, 1, -1];

const ST_ROW: i32 = 1;
const ST_COL: i32 = 1;

/// BFS flood-fill table detector.
///
/// Finds connected regions of non-empty cells, tolerating gaps up to
/// `threshold_hor` columns and `threshold_ver` rows.
///
/// `content` is a 0-indexed row-major matrix of cell strings (empty = blank).
/// `value_map_border` is optional; non-zero values reset the gap counter.
/// `direct=1` scans bottom-to-top (default), `direct=0` top-to-bottom.
///
/// Returns 1-indexed inclusive `Boundary` values, one per detected table region.
pub fn find_connected_ranges(
    content: &[Vec<String>],
    value_map_border: Option<&[Vec<i32>]>,
    threshold_hor: i32,
    threshold_ver: i32,
    direct: i32,
) -> Vec<Boundary> {
    let row_num = content.len() as i32;
    let col_num = if row_num > 0 { content[0].len() as i32 } else { return vec![] };

    let range_up_row    = ST_ROW - 1;
    let range_left_col  = ST_COL - 1;
    let range_down_row  = ST_ROW + row_num - 2;
    let range_right_col = ST_COL + col_num - 2;

    let vis_h = row_num as usize;
    let vis_w = col_num as usize;
    let mut vis:         Vec<Vec<bool>> = vec![vec![false; vis_w]; vis_h];
    let mut counter_hor: Vec<Vec<i32>>  = vec![vec![threshold_hor; vis_w]; vis_h];
    let mut counter_ver: Vec<Vec<i32>>  = vec![vec![threshold_ver; vis_w]; vis_h];

    // Build scan order
    let row_range: Vec<i32> = if direct == 0 {
        (range_up_row..=range_down_row).collect()
    } else {
        (range_up_row..=range_down_row).rev().collect()
    };
    let col_range: Vec<i32> = (range_left_col..=range_right_col).collect();

    let mut ret: Vec<(i32, i32, i32, i32)> = Vec::new();

    for &row_idx in &row_range {
        for &col_idx in &col_range {
            let vi = (row_idx - ST_ROW + 1) as usize;
            let vj = (col_idx - ST_COL + 1) as usize;
            if vis[vi][vj] { continue; }
            if content[row_idx as usize][col_idx as usize].is_empty() { continue; }

            // BFS
            let mut queue: VecDeque<(i32, i32)> = VecDeque::new();
            queue.push_back((row_idx, col_idx));
            vis[vi][vj] = true;

            let mut min_row = i32::MAX;
            let mut min_col = i32::MAX;
            let mut max_row = i32::MIN;
            let mut max_col = i32::MIN;

            while let Some((row, col)) = queue.pop_front() {
                let ci = (row - ST_ROW + 1) as usize;
                let cj = (col - ST_COL + 1) as usize;

                if counter_hor[ci][cj] == 0 || counter_ver[ci][cj] == 0 { continue; }

                min_row = min_row.min(row);
                min_col = min_col.min(col);
                max_row = max_row.max(row);
                max_col = max_col.max(col);

                for i in 0..4usize {
                    let next_row = row + DX[i];
                    let next_col = col + DY[i];

                    if next_row < range_up_row || next_row > range_down_row
                        || next_col < range_left_col || next_col > range_right_col
                    { continue; }

                    let ni = (next_row - ST_ROW + 1) as usize;
                    let nj = (next_col - ST_COL + 1) as usize;
                    if vis[ni][nj] { continue; }
                    vis[ni][nj] = true;

                    let border_val = value_map_border
                        .and_then(|m| m.get(next_row as usize))
                        .and_then(|r| r.get(next_col as usize))
                        .copied()
                        .unwrap_or(0);

                    if content[next_row as usize][next_col as usize].is_empty() {
                        if DY[i] != 0 {
                            counter_hor[ni][nj] = counter_hor[ci][cj] - 1;
                        }
                        if DX[i] != 0 {
                            counter_ver[ni][nj] = counter_ver[ci][cj] - 1;
                        }
                    }
                    if border_val != 0 {
                        if DY[i] != 0 { counter_hor[ni][nj] = threshold_hor; }
                        if DX[i] != 0 { counter_ver[ni][nj] = threshold_ver; }
                    }

                    queue.push_back((next_row, next_col));
                }
            }

            if min_row == i32::MAX || max_row - min_row < 1 { continue; }
            ret.push((min_row, min_col, max_row, max_col));
            for ri in min_row..=max_row {
                for rj in min_col..=max_col {
                    vis[(ri - ST_ROW + 1) as usize][(rj - ST_COL + 1) as usize] = true;
                }
            }
        }
    }

    // Trim empty edges 3 times
    for _ in 0..3 {
        ret = trim(content, ret);
    }

    ret.into_iter()
        .filter(|&(r1, c1, r2, c2)| r1 < r2 && c1 < c2)
        .map(|(r1, c1, r2, c2)| Boundary::new(r1 + 1, r2 + 1, c1 + 1, c2 + 1))
        .collect()
}

/// Remove empty leading/trailing rows and columns from each detected range.
fn trim(content: &[Vec<String>], list: Vec<(i32, i32, i32, i32)>) -> Vec<(i32, i32, i32, i32)> {
    list.into_iter().map(|(mut up, mut left, mut down, mut right)| {
        // Remove leading empty rows
        let mut i = up;
        while i <= down {
            if is_row_empty(content, left, right, i) { up += 1; i += 1; } else { break; }
        }
        // Remove trailing empty rows
        let mut i = down;
        while i >= up {
            if is_row_empty(content, left, right, i) { down -= 1; i -= 1; } else { break; }
        }
        // Remove leading empty cols
        let mut j = left;
        while j <= right {
            if is_col_empty(content, up, down, j) { left += 1; j += 1; } else { break; }
        }
        // Remove trailing empty cols
        let mut j = right;
        while j >= left {
            if is_col_empty(content, up, down, j) { right -= 1; j -= 1; } else { break; }
        }
        (up, left, down, right)
    }).collect()
}

fn is_row_empty(content: &[Vec<String>], left: i32, right: i32, row: i32) -> bool {
    let r = row as usize;
    for c in left as usize..=right as usize {
        if content.get(r).and_then(|row| row.get(c)).map(|s| !s.is_empty()).unwrap_or(false) {
            return false;
        }
    }
    true
}

fn is_col_empty(content: &[Vec<String>], up: i32, down: i32, col: i32) -> bool {
    let c = col as usize;
    for r in up as usize..=down as usize {
        if content.get(r).and_then(|row| row.get(c)).map(|s| !s.is_empty()).unwrap_or(false) {
            return false;
        }
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 5×5 grid with two isolated 2×2 clusters; should detect 2 regions.
    #[test]
    fn two_isolated_clusters() {
        let mut grid: Vec<Vec<String>> = vec![vec![String::new(); 5]; 5];
        // Cluster 1: rows 0-1, cols 0-1
        grid[0][0] = "A".into(); grid[0][1] = "B".into();
        grid[1][0] = "C".into(); grid[1][1] = "D".into();
        // Cluster 2: rows 3-4, cols 3-4
        grid[3][3] = "X".into(); grid[3][4] = "Y".into();
        grid[4][3] = "Z".into(); grid[4][4] = "W".into();

        let result = find_connected_ranges(&grid, None, 1, 1, 1);
        assert_eq!(result.len(), 2, "Expected 2 clusters, got {}", result.len());
    }
}
