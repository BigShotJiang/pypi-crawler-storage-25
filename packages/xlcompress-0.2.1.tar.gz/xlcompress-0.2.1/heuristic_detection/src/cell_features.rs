/// Per-cell formatting and content features extracted from a sheet.
///
/// Mirrors C# `CellFeatures`. All fields are computed during `SheetMap` construction
/// from the caller-provided `SheetData`.
#[derive(Debug, Clone, Default)]
pub struct CellFeatures {
    pub has_bottom_border: bool,
    pub has_top_border: bool,
    pub has_left_border: bool,
    pub has_right_border: bool,
    pub has_fill_color: bool,
    pub has_formula: bool,
    /// Length in characters of the effective cell text.
    pub text_length: usize,
    /// Fraction of characters that are alphabetic.
    pub alphabet_ratio: f64,
    /// Fraction of characters that are numeric digits.
    pub number_ratio: f64,
    /// Fraction of special characters (* / ： \ - + ().
    pub sp_char_ratio: f64,
}

impl CellFeatures {
    /// The placeholder text inserted for formula cells that produce an empty display value.
    pub const DEFAULT_FORMULA_CONTENT: &'static str = "0.00";

    /// True when the cell has non-empty text.
    pub fn mark_text(&self) -> bool {
        self.text_length > 0
    }
}

/// Extract cell features and effective string values from caller-supplied data.
///
/// `values` is the raw cell text (rows × cols, 0-indexed).
/// `has_formula`, `has_color`, `borders` are matching shape boolean arrays.
/// `merged` is a list of (top, bottom, left, right) 1-indexed inclusive regions.
///
/// Returns `(features, cells)` both row-major with shape (rows × cols).
pub fn extract_features(
    rows: usize,
    cols: usize,
    values: &[Vec<String>],
    has_formula: &[Vec<bool>],
    has_color: &[Vec<bool>],
    borders: &[Vec<[bool; 4]>],  // [top, bottom, left, right]
    merged: &[(usize, usize, usize, usize)], // 1-indexed inclusive
) -> (Vec<Vec<CellFeatures>>, Vec<Vec<String>>) {
    let mut cells: Vec<Vec<String>> = (0..rows)
        .map(|i| (0..cols).map(|j| {
            let raw = &values[i][j];
            if raw.is_empty() && has_formula[i][j] {
                CellFeatures::DEFAULT_FORMULA_CONTENT.to_string()
            } else {
                raw.trim().to_string()
            }
        }).collect())
        .collect();

    // Propagate merged cell values: fill all cells in a merged region with
    // the value from the top-left cell of that region (0-indexed access).
    for &(top, bottom, left, right) in merged {
        // Convert from 1-indexed to 0-indexed
        let r0 = top.saturating_sub(1);
        let c0 = left.saturating_sub(1);
        let anchor_val = if r0 < rows && c0 < cols { cells[r0][c0].clone() } else { String::new() };
        for r in r0..=bottom.saturating_sub(1) {
            for c in c0..=right.saturating_sub(1) {
                if r < rows && c < cols {
                    cells[r][c] = anchor_val.clone();
                }
            }
        }
    }

    let mut features: Vec<Vec<CellFeatures>> = vec![
        vec![CellFeatures::default(); cols]; rows
    ];

    for i in 0..rows {
        for j in 0..cols {
            let b = &borders[i][j];
            let text = &cells[i][j];
            let tlen = text.len();
            let (alpha, num, sp) = if tlen > 0 {
                let alpha = text.chars().filter(|c| c.is_alphabetic()).count() as f64 / tlen as f64;
                let num   = text.chars().filter(|c| c.is_ascii_digit()).count() as f64 / tlen as f64;
                // Special chars: * / ：  \ at any position; - + ( skipping first char
                let sp_count = text.chars().filter(|&c| matches!(c, '*' | '/' | '：' | '\\')).count()
                    + text.chars().skip(1).filter(|&c| matches!(c, '-' | '+' | '(')).count();
                let sp = sp_count as f64 / tlen as f64;
                (alpha, num, sp)
            } else {
                (0.0, 0.0, 0.0)
            };

            features[i][j] = CellFeatures {
                has_top_border: b[0],
                has_bottom_border: b[1],
                has_left_border: b[2],
                has_right_border: b[3],
                has_fill_color: has_color[i][j],
                has_formula: has_formula[i][j],
                text_length: tlen,
                alphabet_ratio: alpha,
                number_ratio: num,
                sp_char_ratio: sp,
            };
        }
    }

    (features, cells)
}
