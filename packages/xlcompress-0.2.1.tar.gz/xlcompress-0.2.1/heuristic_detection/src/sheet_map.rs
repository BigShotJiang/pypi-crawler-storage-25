use std::collections::HashSet;

use crate::boundary::{
    Boundary, area_size, calc_sum_matrix, submatrix_sum,
    down_row, up_row, left_col, right_col, is_overlap, is_overlap_or_neighbor,
    unify_box, distinct_boxes, distinct_strs, get_unified_ranges,
};
use crate::cell_features::CellFeatures;

// ── Window (offset padding) constants matching C# HeuristicTableDetector ──────
const ROW_OFFSET: i32 = 7; // WindowHeight + 2
const COL_OFFSET: i32 = 7; // WindowWidth + 2

/// All sheet-level data needed by the detector.
///
/// Mirrors C# `SheetMap`. Prefix-sum arrays (`sum_*`) use 1-indexed coordinates
/// via `submatrix_sum`. The content/feature matrices are extended by `ROW_OFFSET`
/// empty rows/cols on each side.
pub struct SheetMap {
    pub height: i32,
    pub width: i32,

    pub pivot_boxes: Vec<Boundary>,
    pub merge_boxes: Vec<Boundary>,

    /// Effective cell strings, padded, 0-indexed internally.
    pub content_strs: Vec<Vec<String>>,

    /// Cell features, padded, 0-indexed internally.
    pub feature_map: Vec<Vec<CellFeatures>>,

    // Raw value maps (padded, same indexing as feature_map)
    pub value_map_content: Vec<Vec<i32>>,
    pub value_map_border: Vec<Vec<i32>>,
    pub value_map_color: Vec<Vec<i32>>,
    pub value_map_all: Vec<Vec<i32>>,

    // Prefix-sum matrices (1-indexed via submatrix_sum)
    pub sum_content: Vec<Vec<i32>>,
    pub sum_content_exist: Vec<Vec<i32>>,
    pub sum_border: Vec<Vec<i32>>,
    pub sum_border_col: Vec<Vec<i32>>,
    pub sum_border_row: Vec<Vec<i32>>,
    pub sum_color: Vec<Vec<i32>>,
    pub sum_all: Vec<Vec<i32>>,

    pub row_boundary_lines: Vec<i32>,
    pub col_boundary_lines: Vec<i32>,

    row_diffs_bool: Vec<Vec<bool>>,
    col_diffs_bool: Vec<Vec<bool>>,
    row_diffs: Vec<Vec<f64>>,
    col_diffs: Vec<Vec<f64>>,

    pub cohension_regions: Vec<Boundary>,
    pub merge_forced_cohension_regions: Vec<Boundary>,
    pub col_forced_cohension_regions: Vec<Boundary>,
    pub row_forced_cohension_regions: Vec<Boundary>,
    pub color_forced_cohension_regions: Vec<Boundary>,
    pub edge_forced_cohension_regions: Vec<Boundary>,
    pub cohension_border_regions: Vec<Boundary>,
    pub small_cohension_border_regions: Vec<Boundary>,
}

impl SheetMap {
    /// Construct a `SheetMap` from already-extracted features and cell strings.
    ///
    /// `row_offset` and `col_offset` are the padding widths on each side (typically
    /// `WindowHeight + 2 = 7` matching C# `HeuristicTableDetector`).
    pub fn new(
        row_offset: usize,
        col_offset: usize,
        features: Vec<Vec<CellFeatures>>,
        contents: Vec<Vec<String>>,
        merged_ranges: Vec<Boundary>,
        pivot_tables: Vec<Boundary>,
    ) -> Self {
        let ro = row_offset as i32;
        let co = col_offset as i32;

        let src_h = features.len();
        let src_w = if src_h > 0 { features[0].len() } else { 0 };
        let height = (src_h as i32) + 2 * ro;
        let width  = (src_w as i32) + 2 * co;

        // Extend feature map with empty padding
        let empty_feat = CellFeatures::default();
        let mut feature_map = vec![vec![CellFeatures::default(); width as usize]; height as usize];
        for i in 0..height as usize {
            for j in 0..width as usize {
                let ri = i as i32 - ro;
                let cj = j as i32 - co;
                if ri >= 0 && ri < src_h as i32 && cj >= 0 && cj < src_w as i32 {
                    feature_map[i][j] = features[ri as usize][cj as usize].clone();
                } else {
                    feature_map[i][j] = empty_feat.clone();
                }
            }
        }

        // Extend content strings
        let mut content_strs = vec![vec![String::new(); width as usize]; height as usize];
        for i in 0..height as usize {
            for j in 0..width as usize {
                let ri = i as i32 - ro;
                let cj = j as i32 - co;
                if ri >= 0 && ri < src_h as i32 && cj >= 0 && cj < src_w as i32 {
                    content_strs[i][j] = contents[ri as usize][cj as usize].clone();
                }
            }
        }

        // Shift merge boxes by offset
        let merge_boxes: Vec<Boundary> = merged_ranges.iter().map(|b| {
            Boundary::new(b.top + ro, b.bottom + ro, b.left + co, b.right + co)
        }).collect();

        // Shift pivot boxes by offset
        let pivot_boxes: Vec<Boundary> = pivot_tables.iter().map(|b| {
            Boundary::new(b.top + ro, b.bottom + ro, b.left + co, b.right + co)
        }).collect();

        // Build value maps
        let value_map_content = Self::compute_value_map_feat(height as usize, width as usize, &feature_map,
            |f| (if f.has_formula { 2 } else { 0 }) + (if f.mark_text() { 2 } else { 0 }));
        let value_map_content_exist = Self::compute_value_map_feat(height as usize, width as usize, &feature_map,
            |f| if f.has_formula || f.mark_text() { 2 } else { 0 });
        let value_map_border = Self::compute_value_map_feat(height as usize, width as usize, &feature_map, |f| {
            let cnt = f.has_bottom_border as i32 + f.has_top_border as i32
                    + f.has_left_border as i32 + f.has_right_border as i32;
            (if cnt >= 3 { cnt - 1 } else { cnt }) * 2
        });
        let value_map_border_col = Self::compute_value_map_feat(height as usize, width as usize, &feature_map,
            |f| if f.has_left_border || f.has_right_border { 2 } else { 0 });
        let value_map_border_row = Self::compute_value_map_feat(height as usize, width as usize, &feature_map,
            |f| if f.has_bottom_border || f.has_top_border { 2 } else { 0 });
        let value_map_color = Self::compute_value_map_feat(height as usize, width as usize, &feature_map,
            |f| if f.has_fill_color { 2 } else { 0 });
        let value_map_all = Self::compute_value_map_all(height as usize, width as usize,
            &value_map_content, &value_map_border, &value_map_color);

        // Build prefix sums
        let sum_content = calc_sum_matrix(&value_map_content);
        let sum_content_exist = calc_sum_matrix(&value_map_content_exist);
        let sum_border = calc_sum_matrix(&value_map_border);
        let sum_border_col = calc_sum_matrix(&value_map_border_col);
        let sum_border_row = calc_sum_matrix(&value_map_border_row);
        let sum_color = calc_sum_matrix(&value_map_color);
        let sum_all = calc_sum_matrix(&value_map_all);

        SheetMap {
            height,
            width,
            pivot_boxes,
            merge_boxes,
            content_strs,
            feature_map,
            value_map_content,
            value_map_border,
            value_map_color,
            value_map_all,
            sum_content,
            sum_content_exist,
            sum_border,
            sum_border_col,
            sum_border_row,
            sum_color,
            sum_all,
            row_boundary_lines: Vec::new(),
            col_boundary_lines: Vec::new(),
            row_diffs_bool: Vec::new(),
            col_diffs_bool: Vec::new(),
            row_diffs: Vec::new(),
            col_diffs: Vec::new(),
            cohension_regions: Vec::new(),
            merge_forced_cohension_regions: Vec::new(),
            col_forced_cohension_regions: Vec::new(),
            row_forced_cohension_regions: Vec::new(),
            color_forced_cohension_regions: Vec::new(),
            edge_forced_cohension_regions: Vec::new(),
            cohension_border_regions: Vec::new(),
            small_cohension_border_regions: Vec::new(),
        }
    }

    fn compute_value_map_feat(h: usize, w: usize, fm: &[Vec<CellFeatures>], f: impl Fn(&CellFeatures) -> i32) -> Vec<Vec<i32>> {
        let mut m = vec![vec![0i32; w]; h];
        for i in 0..h { for j in 0..w { m[i][j] = f(&fm[i][j]); } }
        m
    }

    fn compute_value_map_all(h: usize, w: usize, c: &[Vec<i32>], b: &[Vec<i32>], col: &[Vec<i32>]) -> Vec<Vec<i32>> {
        let mut m = vec![vec![0i32; w]; h];
        for i in 0..h { for j in 0..w { m[i][j] = (c[i][j] + b[i][j] + col[i][j]).min(16); } }
        m
    }

    // ── Query helpers ──────────────────────────────────────────────────────────

    /// Content-existence density: `sum_content_exist(box) / (2 * area(box))`.
    pub fn content_exist_value_density(&self, b: Boundary) -> f64 {
        let a = area_size(b);
        if a <= 0.0 { return 0.0; }
        submatrix_sum(&self.sum_content_exist, b) as f64 / (2.0 * a)
    }

    /// Convenience constructor from a `CoreSheet`.
    pub fn from_core(core: &crate::core_sheet::CoreSheet) -> Self {
        Self::new(
            ROW_OFFSET as usize,
            COL_OFFSET as usize,
            core.features.clone(),
            core.cells.clone(),
            core.merged_areas.clone(),
            vec![],
        )
    }

    /// Number of distinct non-empty text strings in `box`.
    pub fn text_distinct_count(&self, b: Boundary) -> usize {
        let mut set = HashSet::new();
        for i in (b.top - 1) as usize..=(b.bottom - 1) as usize {
            for j in (b.left - 1) as usize..=(b.right - 1) as usize {
                if i < self.feature_map.len() && j < self.feature_map[0].len() {
                    let fi = &self.feature_map[i][j];
                    if fi.mark_text() {
                        // Use the content string as key
                        if i < self.content_strs.len() && j < self.content_strs[i].len() {
                            set.insert(self.content_strs[i][j].clone());
                        }
                    }
                }
            }
        }
        set.len()
    }

    /// True if any merged region overlaps `box`.
    pub fn exists_merged(&self, b: Boundary) -> bool {
        self.merge_boxes.iter().any(|&m| is_overlap(m, b))
    }

    /// Content-existence density for the left or right `frac`-column split of `box`.
    pub fn row_content_exist_value_density_split(&self, b: Boundary, frac: i32) -> f64 {
        if b.right - b.left + 1 <= 0 { return 0.0; }
        let mid = b.left + (b.right - b.left + 1) / frac;
        let left_box  = Boundary::new(b.top, b.bottom, b.left, mid);
        let right_box = Boundary::new(b.top, b.bottom, mid + 1, b.right);
        self.content_exist_value_density(left_box).max(self.content_exist_value_density(right_box))
    }

    /// Content-existence density for the top or bottom `frac`-row split of `box`.
    pub fn col_content_exist_value_density_split(&self, b: Boundary, frac: i32) -> f64 {
        if b.bottom - b.top + 1 <= 0 { return 0.0; }
        let mid = b.top + (b.bottom - b.top + 1) / frac;
        let top_box    = Boundary::new(b.top, mid, b.left, b.right);
        let bottom_box = Boundary::new(mid + 1, b.bottom, b.left, b.right);
        self.content_exist_value_density(top_box).max(self.content_exist_value_density(bottom_box))
    }

    /// Proportion of differing cells between two single-row (or single-col) boxes.
    /// Used to decide whether consecutive rows are "similar" (low value = similar).
    pub fn compute_similar_row(&self, b1: Boundary, b2: Boundary) -> f64 {
        let w = (b1.right - b1.left + 1) as usize;
        if w == 0 { return 0.0; }
        let mut diff = 0usize;
        for j in 0..w {
            let c1 = b1.left as usize + j - 1;
            let c2 = b2.left as usize + j - 1;
            let r1 = (b1.top - 1) as usize;
            let r2 = (b2.top - 1) as usize;
            let v1 = self.content_strs.get(r1).and_then(|row| row.get(c1)).map(|s| s.as_str()).unwrap_or("");
            let v2 = self.content_strs.get(r2).and_then(|row| row.get(c2)).map(|s| s.as_str()).unwrap_or("");
            if v1 != v2 { diff += 1; }
        }
        diff as f64 / w as f64
    }

    /// Compute border-diff score in the row direction for a box boundary.
    pub fn compute_border_diffs_row(&self, b: Boundary) -> f64 {
        let up    = (b.top - 2) as usize;
        let down  = (b.bottom - 1) as usize;
        let left  = (b.left - 2) as usize;
        let right = (b.right - 1) as usize;

        let mut cnt1 = 0.0f64;
        if up < self.row_diffs_bool.len() {
            for j in left..=right {
                if j < self.row_diffs_bool[up].len()
                    && self.row_diffs_bool[up][j]
                    && self.row_diffs[up].get(j).copied().unwrap_or(0.0) > 0.0
                {
                    cnt1 += self.row_diffs[up][j].abs();
                }
            }
        }
        let mut cnt2 = 0.0f64;
        if down < self.row_diffs_bool.len() {
            for j in left..=right {
                if j < self.row_diffs_bool[down].len()
                    && self.row_diffs_bool[down][j]
                    && self.row_diffs[down].get(j).copied().unwrap_or(0.0) < 0.0
                {
                    cnt2 += self.row_diffs[down][j].abs();
                }
            }
        }
        let w = crate::boundary::width(b);
        if w <= 0.0 { 0.0 } else { (cnt1 + cnt2) / w }
    }

    /// Compute border-diff score in the column direction for a box boundary.
    pub fn compute_border_diffs_col(&self, b: Boundary) -> f64 {
        let up    = (b.top - 2) as usize;
        let down  = (b.bottom - 1) as usize;
        let left  = (b.left - 2) as usize;
        let right = (b.right - 1) as usize;

        let mut cnt3 = 0.0f64;
        if left < self.col_diffs_bool.len() {
            for i in up..=down {
                if i < self.col_diffs_bool[left].len()
                    && self.col_diffs_bool[left][i]
                    && self.col_diffs[left].get(i).copied().unwrap_or(0.0) > 0.0
                {
                    cnt3 += self.col_diffs[left][i].abs();
                }
            }
        }
        let mut cnt4 = 0.0f64;
        if right < self.col_diffs_bool.len() {
            for i in up..=down {
                if i < self.col_diffs_bool[right].len()
                    && self.col_diffs_bool[right][i]
                    && self.col_diffs[right].get(i).copied().unwrap_or(0.0) < 0.0
                {
                    cnt4 += self.col_diffs[right][i].abs();
                }
            }
        }
        let h = crate::boundary::height(b);
        if h <= 0.0 { 0.0 } else { (cnt3 + cnt4) / h }
    }

    // ── Boundary line proposal ─────────────────────────────────────────────────

    /// Compute row/col difference maps and propose candidate boundary lines.
    /// Populates `self.row_boundary_lines`, `self.col_boundary_lines`.
    pub fn propose_boundary_lines(&mut self) {
        self.compute_value_diff();
        self.row_boundary_lines = Self::propose_lines_by_diff(&self.row_diffs_bool, 1.0);
        self.col_boundary_lines = Self::propose_lines_by_diff(&self.col_diffs_bool, 1.0);
        self.row_boundary_lines.dedup();
        self.col_boundary_lines.dedup();

        // Sort by decreasing number of diff=true cells (most discriminating first)
        let rdiff = self.row_diffs_bool.clone();
        self.row_boundary_lines.sort_by(|&x, &y| {
            let cx = rdiff.get(x as usize).map(|v| v.iter().filter(|&&b| b).count()).unwrap_or(0);
            let cy = rdiff.get(y as usize).map(|v| v.iter().filter(|&&b| b).count()).unwrap_or(0);
            cy.cmp(&cx)
        });
        let cdiff = self.col_diffs_bool.clone();
        self.col_boundary_lines.sort_by(|&x, &y| {
            let cx = cdiff.get(x as usize).map(|v| v.iter().filter(|&&b| b).count()).unwrap_or(0);
            let cy = cdiff.get(y as usize).map(|v| v.iter().filter(|&&b| b).count()).unwrap_or(0);
            cy.cmp(&cx)
        });
    }

    fn propose_lines_by_diff(diffs: &[Vec<bool>], thresh: f64) -> Vec<i32> {
        diffs.iter().enumerate()
            .filter(|(_, d)| d.iter().filter(|&&v| v).count() as f64 >= thresh)
            .map(|(i, _)| i as i32)
            .collect()
    }

    /// Compute per-row and per-column value differences.
    fn compute_value_diff(&mut self) {
        let h = self.height as usize;
        let w = self.width as usize;

        // row diffs: for each boundary row index r in [0..h-1], compare row r vs r+1
        self.row_diffs_bool = vec![vec![false; w]; h];
        self.row_diffs      = vec![vec![0.0; w]; h];
        for r in 0..h.saturating_sub(1) {
            for c in 0..w {
                let v_top = self.value_map_all[r][c] as f64;
                let v_bot = self.value_map_all[r + 1][c] as f64;
                let diff  = v_top - v_bot;
                self.row_diffs[r][c] = diff;
                self.row_diffs_bool[r][c] = diff.abs() > 0.0;
            }
        }

        // col diffs: for each boundary col index c in [0..w-1], compare col c vs c+1
        self.col_diffs_bool = vec![vec![false; h]; w];
        self.col_diffs      = vec![vec![0.0; h]; w];
        for c in 0..w.saturating_sub(1) {
            for r in 0..h {
                let v_left  = self.value_map_all[r][c] as f64;
                let v_right = self.value_map_all[r][c + 1] as f64;
                let diff    = v_left - v_right;
                self.col_diffs[c][r] = diff;
                self.col_diffs_bool[c][r] = diff.abs() > 0.0;
            }
        }
    }

    // ── Cohesion detection ─────────────────────────────────────────────────────

    /// Detect cohesion regions (merged, color, border).
    /// Populates all `*_cohension_*` fields.
    pub fn cohension_detection(&mut self) {
        self.col_forced_cohension_regions   = Vec::new();
        self.row_forced_cohension_regions   = Vec::new();
        self.color_forced_cohension_regions = Vec::new();
        self.merge_forced_cohension_regions = Vec::new();
        self.edge_forced_cohension_regions  = Vec::new();
        self.cohension_regions              = Vec::new();
        self.cohension_border_regions       = Vec::new();
        self.small_cohension_border_regions = Vec::new();

        // Merge cohesion: unified ranges of merged areas
        let merged_unified = get_unified_ranges(self.merge_boxes.clone());
        self.merge_forced_cohension_regions = merged_unified;

        // Color cohesion: unified ranges of color-filled cells
        self.color_forced_cohension_regions = self.generate_color_cohensions();

        // Border cohesion regions
        self.deal_with_border_cohension_regions();

        self.cohension_regions.extend(self.col_forced_cohension_regions.clone());
        self.cohension_regions.extend(self.row_forced_cohension_regions.clone());
        self.cohension_regions.extend(self.merge_forced_cohension_regions.clone());
    }

    /// Build color-cohesion regions: connected groups of colored cells.
    fn generate_color_cohensions(&self) -> Vec<Boundary> {
        // Collect all colored cells as single-cell boundaries and unify
        let colored: Vec<Boundary> = (0..self.height as usize)
            .flat_map(|i| (0..self.width as usize).filter_map(move |j| {
                if self.feature_map[i][j].has_fill_color {
                    Some(Boundary::new((i + 1) as i32, (i + 1) as i32, (j + 1) as i32, (j + 1) as i32))
                } else {
                    None
                }
            }))
            .collect();
        get_unified_ranges(colored)
    }

    /// Detect border-based cohesion regions via greedy rectangle search.
    fn deal_with_border_cohension_regions(&mut self) {
        let h = self.height as usize;
        let w = self.width as usize;
        // Build a bool map: cell has all four borders
        let border_map: Vec<Vec<bool>> = (0..h).map(|i| {
            (0..w).map(|j| {
                let f = &self.feature_map[i][j];
                f.has_top_border && f.has_bottom_border && f.has_left_border && f.has_right_border
            }).collect()
        }).collect();

        let mut regions: Vec<Boundary> = Vec::new();
        let mut small_regions: Vec<Boundary> = Vec::new();
        let mut mark = vec![vec![false; w]; h];

        for i in 0..h {
            for j in 0..w {
                if mark[i][j] || !border_map[i][j] { continue; }
                // Greedy expand rectangle
                let mut step_row = 0usize;
                let mut step_col = 0usize;

                // Expand diagonally first
                while i + step_row < h && j + step_col < w && border_map[i + step_row][j + step_col] {
                    step_row += 1;
                    step_col += 1;
                }
                if step_row > 0 { step_row -= 1; }
                if step_col > 0 { step_col -= 1; }
                // Expand row
                while i + step_row < h && border_map[i + step_row][j + step_col] { step_row += 1; }
                if step_row > 0 { step_row -= 1; }
                // Expand col
                while j + step_col < w && border_map[i + step_row][j + step_col] { step_col += 1; }
                if step_col > 0 { step_col -= 1; }

                if step_row > 0 || step_col > 0 {
                    let b = Boundary::new(
                        (i + 1) as i32, (i + 1 + step_row) as i32,
                        (j + 1) as i32, (j + 1 + step_col) as i32,
                    );
                    for ri in i..=(i + step_row) { for ci in j..=(j + step_col) { mark[ri][ci] = true; } }
                    if step_row >= 2 || step_col >= 2 {
                        regions.push(b);
                    } else {
                        small_regions.push(b);
                    }
                }
            }
        }
        self.cohension_border_regions = regions;
        self.small_cohension_border_regions = small_regions;
    }

    // ── Block region generation ────────────────────────────────────────────────

    /// Split the sheet into disconnected block regions.
    ///
    /// Returns a list of `Boundary` values (1-indexed) representing the non-empty
    /// top-level regions of the sheet.
    pub fn generate_block_regions(&self) -> Vec<Boundary> {
        let initial = Boundary::new(1, self.height, 1, self.width);
        let mut prev = vec![initial];
        loop {
            let mut next = Vec::new();
            let mut cnt_split = 0;
            for &region in &prev {
                if region.bottom - region.top <= 0 || region.right - region.left <= 0 { continue; }
                let trimmed = self.trim_empty_edges(region);
                if trimmed != region {
                    next.push(trimmed);
                    cnt_split += 1;
                    continue;
                }
                let split = self.split_block_region(region);
                if split.len() == 2 {
                    next.push(split[0]);
                    next.push(split[1]);
                    cnt_split += 1;
                } else {
                    next.push(region);
                }
            }
            if cnt_split == 0 { return next; }
            prev = next;
        }
    }

    fn trim_empty_edges(&self, b: Boundary) -> Boundary {
        let mut up    = b.top;
        let mut down  = b.bottom;
        let mut left  = b.left;
        let mut right = b.right;

        while up < down {
            let e = Boundary::new(up, up, left, right);
            if submatrix_sum(&self.sum_content, e) + submatrix_sum(&self.sum_color, e) + submatrix_sum(&self.sum_border, e) != 0 { break; }
            up += 1;
        }
        while down >= up {
            let e = Boundary::new(down, down, left, right);
            if submatrix_sum(&self.sum_content, e) + submatrix_sum(&self.sum_color, e) + submatrix_sum(&self.sum_border, e) != 0 { break; }
            down -= 1;
        }
        while left < right {
            let e = Boundary::new(up, down, left, left);
            if submatrix_sum(&self.sum_content, e) + submatrix_sum(&self.sum_color, e) + submatrix_sum(&self.sum_border, e) != 0 { break; }
            left += 1;
        }
        while right >= left {
            let e = Boundary::new(up, down, right, right);
            if submatrix_sum(&self.sum_content, e) + submatrix_sum(&self.sum_color, e) + submatrix_sum(&self.sum_border, e) != 0 { break; }
            right -= 1;
        }
        Boundary::new(up, down, left, right)
    }

    fn split_block_region(&self, b: Boundary) -> Vec<Boundary> {
        let (up, down, left, right) = (b.top, b.bottom, b.left, b.right);

        // Horizontal split
        let mut i = up + 4;
        while i <= down - 4 {
            let e5 = Boundary::new(i - 2, i + 2, left, right);
            let e3 = Boundary::new(i - 1, i + 1, left, right);
            let e1 = Boundary::new(i, i, left, right);

            let cond = (submatrix_sum(&self.sum_content, e1) + submatrix_sum(&self.sum_color, e1) == 0
                && (submatrix_sum(&self.sum_content_exist, e3) == 0
                    || (submatrix_sum(&self.sum_content_exist, e3) < 6 && submatrix_sum(&self.sum_content_exist, e5) < 10)))
                || (self.content_exist_value_density(e5) < 0.1 && submatrix_sum(&self.sum_content_exist, e5) < 10);

            if cond {
                let mut k = i + 2;
                let mut e_down = Boundary::new(k, k, left, right);
                while k < down {
                    e_down = Boundary::new(k, k, left, right);
                    if submatrix_sum(&self.sum_content_exist, e_down) > 2 { break; }
                    k += 1;
                }
                let mut k = i - 2;
                let mut e_up = Boundary::new(k, k, left, right);
                while k > up {
                    e_up = Boundary::new(k, k, left, right);
                    if submatrix_sum(&self.sum_content_exist, e_up) > 2 { break; }
                    k -= 1;
                }
                if down - e_down.top > 1 && e_up.top - up > 1 {
                    return vec![Boundary::new(up, i - 1, left, right), Boundary::new(i + 1, down, left, right)];
                }
            }
            i += 1;
        }

        // Vertical split
        let mut i = left + 4;
        while i <= right - 4 {
            let e1  = Boundary::new(up, down, i, i);
            let e3  = Boundary::new(up, down, i - 1, i + 1);
            let e5  = Boundary::new(up, down, i - 2, i + 2);

            let cond = (submatrix_sum(&self.sum_content, e1) + submatrix_sum(&self.sum_color, e1) == 0
                && (submatrix_sum(&self.sum_content_exist, e3) == 0
                    || (submatrix_sum(&self.sum_content_exist, e3) < 6 && submatrix_sum(&self.sum_content_exist, e5) < 10)))
                || (self.content_exist_value_density(e5) < 0.1 && submatrix_sum(&self.sum_content_exist, e5) < 10);

            if cond {
                let mut k = i + 2;
                let mut e_right = Boundary::new(up, down, k, k);
                while k <= right {
                    e_right = Boundary::new(up, down, k, k);
                    if submatrix_sum(&self.sum_content_exist, e_right) > 2 { break; }
                    k += 1;
                }
                let mut k = i - 2;
                let mut e_left = Boundary::new(up, down, k, k);
                while k >= left {
                    e_left = Boundary::new(up, down, k, k);
                    if submatrix_sum(&self.sum_content_exist, e_left) > 2 { break; }
                    k -= 1;
                }
                // Check mutual match (simplified — omit verifyMutualMatchCol for now)
                if right - e_right.left > 1 && e_left.left - left > 1 {
                    return vec![Boundary::new(up, down, left, i - 1), Boundary::new(up, down, i + 1, right)];
                }
            }
            i += 1;
        }
        vec![]
    }
}
