/// Axis-aligned rectangular region in a spreadsheet.
///
/// All coordinates are 1-indexed and inclusive.
/// `top <= bottom`, `left <= right` for a valid, non-empty boundary.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Boundary {
    pub top: i32,
    pub bottom: i32,
    pub left: i32,
    pub right: i32,
}

impl Boundary {
    /// Construct a new boundary with the given (1-indexed, inclusive) coordinates.
    pub fn new(top: i32, bottom: i32, left: i32, right: i32) -> Self {
        Self { top, bottom, left, right }
    }

    /// Index-access matching C# `this[int index]`: 0=top,1=bottom,2=left,3=right.
    pub fn get(&self, index: usize) -> i32 {
        match index {
            0 => self.top,
            1 => self.bottom,
            2 => self.left,
            3 => self.right,
            _ => panic!("Boundary index out of range: {}", index),
        }
    }

    /// Mutable index-access matching C# `this[int index]`.
    pub fn set(&mut self, index: usize, value: i32) {
        match index {
            0 => self.top = value,
            1 => self.bottom = value,
            2 => self.left = value,
            3 => self.right = value,
            _ => panic!("Boundary index out of range: {}", index),
        }
    }
}

impl PartialOrd for Boundary {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Boundary {
    /// Lexicographic order: top, bottom, left, right — matching C# `CompareTo`.
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.top.cmp(&other.top)
            .then(self.bottom.cmp(&other.bottom))
            .then(self.left.cmp(&other.left))
            .then(self.right.cmp(&other.right))
    }
}

// ── Geometry helpers (ported from Utils.cs) ──────────────────────────────────

/// Area (number of cells) of a single boundary. Returns 0 for invalid boxes.
pub fn area_size(b: Boundary) -> f64 {
    if b.bottom < b.top || b.right < b.left { return 0.0; }
    ((b.bottom - b.top + 1) * (b.right - b.left + 1)) as f64
}

/// Height of a boundary in rows. Returns 0 for invalid boxes.
pub fn height(b: Boundary) -> f64 {
    if b.bottom < b.top { return 0.0; }
    (b.bottom - b.top + 1) as f64
}

/// Width of a boundary in columns. Returns 0 for invalid boxes.
pub fn width(b: Boundary) -> f64 {
    if b.right < b.left { return 0.0; }
    (b.right - b.left + 1) as f64
}

/// Returns the leftmost `step` columns of `box`, starting at offset `start` from the left edge.
pub fn left_col(b: Boundary, start: i32, step: i32) -> Boundary {
    Boundary::new(b.top, b.bottom, b.left + start, b.left + start + step - 1)
}

/// Returns the topmost `step` rows of `box`, starting at offset `start` from the top edge.
pub fn up_row(b: Boundary, start: i32, step: i32) -> Boundary {
    Boundary::new(b.top + start, b.top + start + step - 1, b.left, b.right)
}

/// Returns the rightmost `step` columns of `box`, offset `start` inward from the right edge.
pub fn right_col(b: Boundary, start: i32, step: i32) -> Boundary {
    Boundary::new(b.top, b.bottom, b.right - start - step + 1, b.right - start)
}

/// Returns the bottommost `step` rows of `box`, offset `start` inward from the bottom edge.
pub fn down_row(b: Boundary, start: i32, step: i32) -> Boundary {
    Boundary::new(b.bottom - start - step + 1, b.bottom - start, b.left, b.right)
}

/// True when `box1` contains `box2` (with optional tolerance `step` on each side).
pub fn contains_box(box1: Boundary, box2: Boundary, step: i32) -> bool {
    box1.top <= box2.top + step
        && box1.bottom >= box2.bottom - step
        && box1.left <= box2.left + step
        && box1.right >= box2.right - step
}

/// True when any box in `boxes1` contains `box2` (excluding identity).
pub fn contains_box_list(boxes1: &[Boundary], box2: Boundary, step: i32) -> bool {
    boxes1.iter().any(|&b1| contains_box(b1, box2, step) && b1 != box2)
}

/// True when `box1` overlaps or is adjacent (≤1 cell gap) to `box2`.
pub fn is_overlap_or_neighbor(box1: Boundary, box2: Boundary) -> bool {
    !((box1.top > box2.bottom + 1)
        || (box1.bottom + 1 < box2.top)
        || (box1.left > box2.right + 1)
        || (box1.right + 1 < box2.left))
}

/// True when `box1` and `box2` strictly overlap.
pub fn is_overlap(box1: Boundary, box2: Boundary) -> bool {
    !((box1.top > box2.bottom)
        || (box1.bottom < box2.top)
        || (box1.left > box2.right)
        || (box1.right < box2.left))
}

/// True when `box1` overlaps any box in `boxes2` (excluding identity).
/// `except_forward` skips pairs where box1 contains the other.
/// `except_backward` skips pairs where the other contains box1.
/// `except_suppression` skips pairs where boxes are suppression-equivalent.
pub fn is_overlap_list(
    box1: Boundary,
    boxes2: &[Boundary],
    except_forward: bool,
    except_backward: bool,
    except_suppression: bool,
) -> bool {
    boxes2.iter().any(|&box2| {
        box2 != box1
            && is_overlap(box1, box2)
            && !(except_forward && contains_box(box1, box2, 0))
            && !(except_backward && contains_box(box2, box1, 0))
            && !(except_suppression && is_suppression_box(box1, box2, 2, -1))
    })
}

/// True when both boxes are within `step` cells of each other on all sides.
/// `direction_num` restricts to one axis; -1 means all four sides.
pub fn is_suppression_box(box1: Boundary, box2: Boundary, step: i32, direction_num: i32) -> bool {
    for i in 0..4usize {
        let diff = (box1.get(i) - box2.get(i)).abs();
        if direction_num >= 0 && i as i32 != direction_num && direction_num != 4 {
            if diff > 0 { return false; }
        } else if diff > step {
            return false;
        }
    }
    true
}

/// Intersection (overlap) of two boundaries. May be invalid if they don't overlap.
pub fn overlap_box(box1: Boundary, box2: Boundary) -> Boundary {
    Boundary::new(
        box1.top.max(box2.top),
        box1.bottom.min(box2.bottom),
        box1.left.max(box2.left),
        box1.right.min(box2.right),
    )
}

/// Intersection of three boundaries.
pub fn overlap_box3(box1: Boundary, box2: Boundary, box3: Boundary) -> Boundary {
    overlap_box(box1, overlap_box(box2, box3))
}

/// Bounding box (union) of two boundaries.
pub fn unify_box(box1: Boundary, box2: Boundary) -> Boundary {
    Boundary::new(
        box1.top.min(box2.top),
        box1.bottom.max(box2.bottom),
        box1.left.min(box2.left),
        box1.right.max(box2.right),
    )
}

/// Remove duplicate boundaries from a list.
pub fn distinct_boxes(boxes: Vec<Boundary>) -> Vec<Boundary> {
    let mut seen = std::collections::HashSet::new();
    boxes.into_iter().filter(|b| seen.insert(*b)).collect()
}

/// Remove all occurrences of `to_remove` from `boxes`.
pub fn remove_these_candidates(to_remove: &std::collections::HashSet<Boundary>, boxes: &mut Vec<Boundary>) {
    if !to_remove.is_empty() {
        boxes.retain(|b| !to_remove.contains(b));
    }
}

/// Append elements of `to_append` that are not already in `boxes`.
pub fn append_these_candidates(to_append: impl IntoIterator<Item = Boundary>, boxes: &mut Vec<Boundary>) {
    let existing: std::collections::HashSet<Boundary> = boxes.iter().copied().collect();
    for b in to_append {
        if !existing.contains(&b) {
            boxes.push(b);
        }
    }
}

/// Remove `to_remove` from and append `to_append` to `boxes`.
pub fn remove_and_append_candidates(
    to_remove: &std::collections::HashSet<Boundary>,
    to_append: impl IntoIterator<Item = Boundary>,
    boxes: &mut Vec<Boundary>,
) {
    remove_these_candidates(to_remove, boxes);
    // Rebuild set after removal for correct dedup
    let existing: std::collections::HashSet<Boundary> = boxes.iter().copied().collect();
    for b in to_append {
        if !existing.contains(&b) {
            boxes.push(b);
        }
    }
}

/// Sort boxes by location: left + 0.00001*top (matching C# `ComputeBoxByLocation`).
pub fn rank_boxes_by_location(boxes: &mut Vec<Boundary>) {
    boxes.sort_by(|a, b| {
        let va = a.left as f64 + 0.00001 * a.top as f64;
        let vb = b.left as f64 + 0.00001 * b.top as f64;
        va.partial_cmp(&vb).unwrap()
    });
}

/// Sort boxes by area descending (largest first).
pub fn rank_boxes_by_size(boxes: &mut Vec<Boundary>) {
    boxes.sort_by(|a, b| area_size(*b).partial_cmp(&area_size(*a)).unwrap());
}

/// Merge overlapping or neighboring boxes into minimal covering boxes.
/// Iterates until no further merges occur (matching C# `GetUnifiedRanges`).
pub fn get_unified_ranges(merge_boxes: Vec<Boundary>) -> Vec<Boundary> {
    let mut new_boxes = merge_boxes;
    loop {
        let prev = new_boxes.clone();
        let mut result = Vec::new();
        let mut used = vec![false; prev.len()];
        let mut cnt_unify = 0;
        for i in 0..prev.len() {
            if used[i] { continue; }
            let mut merged = false;
            for j in (i + 1)..prev.len() {
                if used[j] { continue; }
                if is_overlap_or_neighbor(prev[i], prev[j]) {
                    result.push(unify_box(prev[i], prev[j]));
                    used[j] = true;
                    merged = true;
                    cnt_unify += 1;
                    break;
                }
            }
            if !merged {
                result.push(prev[i]);
            }
        }
        new_boxes = result;
        if cnt_unify == 0 { break; }
    }
    new_boxes
}

/// Count distinct non-empty strings in the submatrix [up-1..down-1, left-1..right-1]
/// of `contents` (1-indexed, inclusive coordinates).
pub fn distinct_strs(contents: &[Vec<String>], up: i32, down: i32, left: i32, right: i32) -> usize {
    let mut set = std::collections::HashSet::new();
    for i in (up - 1) as usize..=(down - 1) as usize {
        for j in (left - 1) as usize..=(right - 1) as usize {
            if i < contents.len() && j < contents[i].len() && !contents[i][j].is_empty() {
                set.insert(contents[i][j].clone());
            }
        }
    }
    set.len()
}

/// Check that `x` and `y` have opposite zero/nonzero status.
pub fn verify_values_opposite(x: i32, y: i32) -> bool {
    (x == 0) != (y == 0)
}

/// Check that |x - y| > threshold.
pub fn verify_values_diff(x: i32, y: i32, thresh: i32) -> bool {
    (x - y).abs() > thresh
}

/// True when `lines` covers `[start, end]` densely enough
/// (matching C# `IsFillLines`).
pub fn is_fill_lines(start: i32, end: i32, lines: &[i32]) -> bool {
    if lines.is_empty() { return false; }
    let inside: Vec<i32> = lines.iter().copied().filter(|&l| l >= start && l <= end).collect();
    if inside.is_empty() { return false; }
    let min_l = *inside.iter().min().unwrap();
    let max_l = *inside.iter().max().unwrap();
    if min_l <= start && max_l >= end {
        let distinct_count = inside.iter().collect::<std::collections::HashSet<_>>().len();
        if distinct_count as f64 > (end - start + 1) as f64 * 0.8 {
            return true;
        }
        if end - start > 5 {
            let mut sorted = inside.clone();
            sorted.sort();
            let mut max_gap = 0i32;
            let mut prev = sorted[0];
            for &v in &sorted[1..] {
                max_gap = max_gap.max(v - prev);
                prev = v;
            }
            max_gap = max_gap.max(end - prev);
            if max_gap <= 5i32.max(((end - start) as f64 * 0.2) as i32) {
                return true;
            }
        }
    }
    false
}

/// True when the row or column lines cover `box1` (matching C# `IsFillBoxRowColLines`).
pub fn is_fill_box_row_col_lines(box1: Boundary, row_lines: &[i32], col_lines: &[i32]) -> bool {
    is_fill_lines(box1.top, box1.bottom, row_lines) || is_fill_lines(box1.left, box1.right, col_lines)
}

/// Map a number format string to a category code (matching C# `GetNumberFormatCode`).
/// 0 = general/none, 1 = numeric, 2 = text/@, 3 = date/time.
pub fn get_number_format_code(format: &str) -> i32 {
    match format {
        "" | "General" => 0,
        "0" | "0.00" | "#,##0" | "#,##0.00" | "0%" | "0.00%" | "0.00E+00"
        | "#,##0 ;(#,##0)" | "#,##0 ;[Red](#,##0)" | "#,##0.00;(#,##0.00)"
        | "#,##0.00;[Red](#,##0.00)" | "##0.0E+0" => 1,
        "# ?/?" | "# ??/??" | "@" => 2,
        "d/m/yyyy" | "d-mmm-yy" | "d-mmm" | "mmm-yy" | "h:mm tt" | "h:mm:ss tt"
        | "H:mm" | "H:mm:ss" | "m/d/yyyy H:mm" | "mm:ss" | "[h]:mm:ss" | "mmss.0" => 3,
        _ => 0,
    }
}

// ── Prefix-sum helpers (ported from Utils.cs extension methods) ───────────────

/// Build a 2-D prefix-sum matrix from a raw value matrix.
///
/// Input and output are row-major `Vec<Vec<i32>>` with the same dimensions.
/// The result satisfies `result[i][j] = sum of values[0..=i][0..=j]`.
pub fn calc_sum_matrix(value_map: &[Vec<i32>]) -> Vec<Vec<i32>> {
    let h = value_map.len();
    if h == 0 { return vec![]; }
    let w = value_map[0].len();
    if w == 0 { return vec![vec![]; h]; }

    let mut result = vec![vec![0i32; w]; h];
    result[0][0] = value_map[0][0];
    for i in 1..h { result[i][0] = result[i - 1][0] + value_map[i][0]; }
    for j in 1..w { result[0][j] = result[0][j - 1] + value_map[0][j]; }
    for i in 1..h {
        for j in 1..w {
            result[i][j] = result[i - 1][j] + result[i][j - 1] - result[i - 1][j - 1] + value_map[i][j];
        }
    }
    result
}

/// Query the sum of a submatrix from a prefix-sum matrix.
///
/// `box` uses 1-indexed, inclusive coordinates matching the C# `SubmatrixSum`.
/// Coordinates are clamped to valid range automatically.
pub fn submatrix_sum(sum_map: &[Vec<i32>], b: Boundary) -> i32 {
    let h = sum_map.len() as i32;
    if h == 0 { return 0; }
    let w = sum_map[0].len() as i32;
    if w == 0 { return 0; }

    let top    = b.top.max(1).min(h) as usize;
    let bottom = b.bottom.max(1).min(h) as usize;
    let left   = b.left.max(1).min(w) as usize;
    let right  = b.right.max(1).min(w) as usize;
    if top > bottom || left > right { return 0; }

    let mut result = sum_map[bottom - 1][right - 1];
    if left > 1    { result -= sum_map[bottom - 1][left - 2]; }
    if top  > 1    { result -= sum_map[top - 2][right - 1]; }
    if left > 1 && top > 1 { result += sum_map[top - 2][left - 2]; }
    result
}

// ── Statistics helpers (ported from Utils.cs) ─────────────────────────────────

/// Mean of a slice.
pub fn average(vals: &[f64]) -> f64 {
    if vals.is_empty() { return 0.0; }
    let s: f64 = vals.iter().sum();
    (s / vals.len() as f64 * 1000.0).round() / 1000.0
}

/// Population standard deviation.
pub fn stdev(vals: &[f64]) -> f64 {
    let avg = average(vals);
    let var: f64 = vals.iter().map(|v| (v - avg) * (v - avg)).sum::<f64>() / vals.len() as f64;
    (var.sqrt() * 1000.0).round() / 1000.0
}

/// L1 distance (mean absolute difference) between two equal-length slices.
pub fn r1(v1: &[f64], v2: &[f64]) -> f64 {
    let s: f64 = v1.iter().zip(v2).map(|(a, b)| (a - b).abs()).sum();
    s / v1.len() as f64
}

/// Pearson correlation coefficient.
pub fn correl(a1: &[f64], a2: &[f64]) -> f64 {
    let avg1 = average(a1);
    let sd1  = stdev(a1);
    let avg2 = average(a2);
    let sd2  = stdev(a2);
    let n = a1.len().min(a2.len()) as f64;
    let s: f64 = a1.iter().zip(a2).map(|(x, y)| (x - avg1) / sd1 * ((y - avg2) / sd2)).sum();
    (s / n * 1000.0).round() / 1000.0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn boundary_overlap() {
        let a = Boundary::new(1, 3, 1, 3);
        let b = Boundary::new(2, 4, 2, 4);
        assert!(is_overlap(a, b));
        let c = Boundary::new(5, 6, 5, 6);
        assert!(!is_overlap(a, c));
    }

    #[test]
    fn boundary_containment() {
        let outer = Boundary::new(1, 10, 1, 10);
        let inner = Boundary::new(3, 7, 3, 7);
        assert!(contains_box(outer, inner, 0));
        assert!(!contains_box(inner, outer, 0));
    }

    #[test]
    fn boundary_unify() {
        let a = Boundary::new(1, 3, 1, 3);
        let b = Boundary::new(2, 5, 2, 6);
        let u = unify_box(a, b);
        assert_eq!(u, Boundary::new(1, 5, 1, 6));
    }

    #[test]
    fn prefix_sum_3x3() {
        let map: Vec<Vec<i32>> = vec![
            vec![1, 2, 3],
            vec![4, 5, 6],
            vec![7, 8, 9],
        ];
        let sum = calc_sum_matrix(&map);
        // Total sum of 1..=9 = 45
        let total = submatrix_sum(&sum, Boundary::new(1, 3, 1, 3));
        assert_eq!(total, 45);
        // Single cell
        assert_eq!(submatrix_sum(&sum, Boundary::new(2, 2, 2, 2)), 5);
        // Top-left 2x2: 1+2+4+5 = 12
        assert_eq!(submatrix_sum(&sum, Boundary::new(1, 2, 1, 2)), 12);
    }
}
