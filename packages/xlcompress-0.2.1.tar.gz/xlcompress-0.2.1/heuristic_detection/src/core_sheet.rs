use crate::boundary::Boundary;
use crate::cell_features::{CellFeatures, extract_features};
use crate::SheetData;

/// Wrapper around `SheetData` that holds extracted cell features and normalised
/// merged-region coordinates — analogous to C# `CoreSheet`.
///
/// Coordinates stored here are **0-indexed** (row 0 = first data row).
pub struct CoreSheet {
    pub height: usize,
    pub width: usize,
    /// 0-indexed cell features, shape (height × width).
    pub features: Vec<Vec<CellFeatures>>,
    /// Effective cell string values after merged-cell propagation, 0-indexed.
    pub cells: Vec<Vec<String>>,
    /// Merged areas in **0-indexed** coordinates (top, bottom, left, right).
    pub merged_areas: Vec<Boundary>,
}

impl CoreSheet {
    /// Build a `CoreSheet` from the public `SheetData` struct.
    ///
    /// `merged` entries in `SheetData` are 1-indexed; they are converted to
    /// 0-indexed `Boundary` values here, matching the C# constructor.
    pub fn new(data: &SheetData) -> Self {
        let (features, cells) = extract_features(
            data.rows,
            data.cols,
            &data.values,
            &data.has_formula,
            &data.has_color,
            &data.borders,
            &data.merged,
        );

        // C# converts 1-indexed firstRow/firstColumn-relative merged regions to 0-indexed.
        // Our SheetData already uses 1-indexed inclusive, so subtract 1.
        let merged_areas = data.merged.iter().map(|&(top, bottom, left, right)| {
            Boundary::new(
                (top as i32) - 1,
                (bottom as i32) - 1,
                (left as i32) - 1,
                (right as i32) - 1,
            )
        }).collect();

        Self { height: data.rows, width: data.cols, features, cells, merged_areas }
    }
}
