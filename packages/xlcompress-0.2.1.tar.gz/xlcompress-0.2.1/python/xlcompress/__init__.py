from xlcompress._native import compress, list_sheets, SheetResult

def compress_to_string(source, **kwargs):
    """Compress and return all sheets as a single string for LLM prompts."""
    results = compress(source, **kwargs)
    parts = []
    for r in results:
        parts.append(f"--- Sheet: {r.name} ---\n\n{r.compressed}")
    return "\n\n".join(parts)

__all__ = ["compress", "compress_to_string", "list_sheets", "SheetResult"]
