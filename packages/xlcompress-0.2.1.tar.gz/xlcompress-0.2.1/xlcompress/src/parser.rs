use calamine::{Data, Reader, open_workbook_auto};
use std::io::Cursor;

pub struct ParsedSheet {
    pub name: String,
    pub values: Vec<Vec<String>>,
    pub nfs: Vec<Vec<String>>,
    pub rows: usize,
    pub cols: usize,
}

fn float_to_string(f: f64) -> String {
    if f == f.trunc() && f.abs() < 1e15 {
        format!("{}", f as i64)
    } else {
        f.to_string()
    }
}

fn data_to_string(d: &Data) -> String {
    match d {
        Data::Float(f) => float_to_string(*f),
        Data::DateTime(dt) => float_to_string(dt.as_f64()),
        Data::Int(i) => i.to_string(),
        Data::String(s) => s.clone(),
        Data::Bool(b) => b.to_string(),
        Data::DateTimeIso(s) | Data::DurationIso(s) => s.clone(),
        Data::Empty | Data::Error(_) => String::new(),
    }
}

fn extract_sheets<RS: std::io::Read + std::io::Seek, R: Reader<RS>>(
    wb: &mut R,
) -> Result<Vec<ParsedSheet>, String>
where
    R::Error: std::fmt::Display,
{
    let names: Vec<String> = wb.sheet_names().to_vec();
    let mut sheets = Vec::new();
    for name in &names {
        let range = wb
            .worksheet_range(name)
            .map_err(|e| format!("Failed to read sheet '{}': {}", name, e))?;
        let (rows, cols) = range.get_size();
        let mut values = vec![vec![String::new(); cols]; rows];
        let nfs = vec![vec!["None".to_string(); cols]; rows];
        for (r, row) in range.rows().enumerate() {
            for (c, cell) in row.iter().enumerate() {
                values[r][c] = data_to_string(cell);
            }
        }
        sheets.push(ParsedSheet { name: name.clone(), values, nfs, rows, cols });
    }
    Ok(sheets)
}

fn get_names<RS: std::io::Read + std::io::Seek>(
    wb: &mut impl Reader<RS>,
) -> Vec<String> {
    wb.sheet_names().to_vec()
}

pub fn open_from_path(path: &str) -> Result<Vec<ParsedSheet>, String> {
    let mut wb = open_workbook_auto(path).map_err(|e| format!("Cannot open '{}': {}", path, e))?;
    extract_sheets(&mut wb)
}

pub fn open_from_bytes(bytes: &[u8], fmt: &str) -> Result<Vec<ParsedSheet>, String> {
    let cursor = Cursor::new(bytes);
    match fmt {
        "xlsx" => {
            let mut wb: calamine::Xlsx<_> =
                Reader::new(cursor).map_err(|e| format!("xlsx parse error: {}", e))?;
            extract_sheets(&mut wb)
        }
        "xlsb" => {
            let mut wb: calamine::Xlsb<_> =
                Reader::new(cursor).map_err(|e| format!("xlsb parse error: {}", e))?;
            extract_sheets(&mut wb)
        }
        _ => Err(format!("Unsupported format '{}', use 'xlsx' or 'xlsb'", fmt)),
    }
}

pub fn sheet_names_from_path(path: &str) -> Result<Vec<String>, String> {
    let mut wb = open_workbook_auto(path).map_err(|e| format!("Cannot open '{}': {}", path, e))?;
    Ok(get_names(&mut wb))
}

pub fn sheet_names_from_bytes(bytes: &[u8], fmt: &str) -> Result<Vec<String>, String> {
    let cursor = Cursor::new(bytes);
    match fmt {
        "xlsx" => {
            let mut wb: calamine::Xlsx<_> =
                Reader::new(cursor).map_err(|e| format!("xlsx parse error: {}", e))?;
            Ok(get_names(&mut wb))
        }
        "xlsb" => {
            let mut wb: calamine::Xlsb<_> =
                Reader::new(cursor).map_err(|e| format!("xlsb parse error: {}", e))?;
            Ok(get_names(&mut wb))
        }
        _ => Err(format!("Unsupported format '{}', use 'xlsx' or 'xlsb'", fmt)),
    }
}
