mod parser;
mod pipeline;

use pyo3::prelude::*;
use pyo3::types::PyBytes;
use std::path::Path;

use pipeline::{CompressOptions, compress_sheet};

#[pyclass]
#[derive(Clone)]
struct SheetResult {
    #[pyo3(get)]
    name: String,
    #[pyo3(get)]
    original: String,
    #[pyo3(get)]
    compressed: String,
    #[pyo3(get)]
    original_tokens: usize,
    #[pyo3(get)]
    compressed_tokens: usize,
}

enum Source {
    Path(String),
    Bytes(Vec<u8>, String), // (bytes, format)
}

fn resolve_source(source: &Bound<'_, PyAny>, format: Option<&str>) -> PyResult<Source> {
    // Try bytes first
    if let Ok(py_bytes) = source.downcast::<PyBytes>() {
        let fmt = format
            .ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "format is required when source is bytes",
            ))?;
        return Ok(Source::Bytes(py_bytes.as_bytes().to_vec(), fmt.to_string()));
    }

    // Try string path
    let path = if let Ok(s) = source.extract::<String>() {
        s
    } else if let Ok(fspath) = source.call_method0("__fspath__") {
        fspath.extract::<String>()?
    } else {
        return Err(PyErr::new::<pyo3::exceptions::PyTypeError, _>(
            "source must be a file path (str/PathLike) or bytes",
        ));
    };

    if !Path::new(&path).exists() {
        return Err(PyErr::new::<pyo3::exceptions::PyFileNotFoundError, _>(
            format!("File not found: {}", path),
        ));
    }
    Ok(Source::Path(path))
}

#[pyfunction]
#[pyo3(signature = (source, *, format=None, sheets=None, mode="aggregated", structural=true, structural_k=4))]
fn compress(
    source: &Bound<'_, PyAny>,
    format: Option<&str>,
    sheets: Option<Vec<String>>,
    mode: &str,
    structural: bool,
    structural_k: usize,
) -> PyResult<Vec<SheetResult>> {
    let src = resolve_source(source, format)?;

    let parsed = match &src {
        Source::Path(p) => parser::open_from_path(p),
        Source::Bytes(b, f) => parser::open_from_bytes(b, f),
    }
    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;

    // Validate requested sheet names
    if let Some(ref requested) = sheets {
        let available: Vec<&str> = parsed.iter().map(|s| s.name.as_str()).collect();
        for name in requested {
            if !available.contains(&name.as_str()) {
                return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                    format!("Sheet '{}' not found. Available: {:?}", name, available),
                ));
            }
        }
    }

    let opts = CompressOptions {
        mode: mode.to_string(),
        structural,
        structural_k,
    };

    let mut results = Vec::new();
    for sheet in &parsed {
        if let Some(ref requested) = sheets {
            if !requested.contains(&sheet.name) {
                continue;
            }
        }
        if let Some(cs) = compress_sheet(sheet, &opts) {
            results.push(SheetResult {
                name: cs.name,
                original: cs.original,
                compressed: cs.compressed,
                original_tokens: cs.original_tokens,
                compressed_tokens: cs.compressed_tokens,
            });
        }
    }
    Ok(results)
}

#[pyfunction]
#[pyo3(signature = (source, *, format=None))]
fn list_sheets(
    source: &Bound<'_, PyAny>,
    format: Option<&str>,
) -> PyResult<Vec<String>> {
    let src = resolve_source(source, format)?;
    let names = match &src {
        Source::Path(p) => parser::sheet_names_from_path(p),
        Source::Bytes(b, f) => parser::sheet_names_from_bytes(b, f),
    }
    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;
    Ok(names)
}

#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<SheetResult>()?;
    m.add_function(wrap_pyfunction!(compress, m)?)?;
    m.add_function(wrap_pyfunction!(list_sheets, m)?)?;
    Ok(())
}
