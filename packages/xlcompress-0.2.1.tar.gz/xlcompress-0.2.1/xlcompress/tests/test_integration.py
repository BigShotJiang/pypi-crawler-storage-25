import xlcompress
import os
import pytest

FIXTURE_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "tests", "fixtures")
XLSB_FILE = os.path.join(FIXTURE_DIR, "A.CRE-All-in-One-Model-v0.895-owen3f.xlsb")


def test_list_sheets():
    names = xlcompress.list_sheets(XLSB_FILE)
    assert isinstance(names, list)
    assert len(names) > 0
    assert all(isinstance(n, str) for n in names)


def test_compress_all_sheets():
    results = xlcompress.compress(XLSB_FILE)
    assert isinstance(results, list)
    assert len(results) > 0
    for r in results:
        assert hasattr(r, "name")
        assert hasattr(r, "original")
        assert hasattr(r, "compressed")
        assert hasattr(r, "original_tokens")
        assert hasattr(r, "compressed_tokens")
        assert isinstance(r.name, str)


def test_compress_single_sheet():
    names = xlcompress.list_sheets(XLSB_FILE)
    first = names[0]
    results = xlcompress.compress(XLSB_FILE, sheets=[first])
    assert len(results) == 1
    assert results[0].name == first


def test_compress_invalid_sheet():
    with pytest.raises(ValueError):
        xlcompress.compress(XLSB_FILE, sheets=["NONEXISTENT_SHEET_999"])


def test_compress_modes():
    names = xlcompress.list_sheets(XLSB_FILE)
    first = names[0]
    for mode in ["aggregated", "vanilla", "inverted"]:
        results = xlcompress.compress(XLSB_FILE, sheets=[first], mode=mode)
        assert len(results) == 1
        assert len(results[0].compressed) > 0


def test_compress_to_string():
    names = xlcompress.list_sheets(XLSB_FILE)
    first = names[0]
    result = xlcompress.compress_to_string(XLSB_FILE, sheets=[first])
    assert isinstance(result, str)
    assert "--- Sheet:" in result


def test_compress_from_bytes():
    with open(XLSB_FILE, "rb") as f:
        data = f.read()
    results = xlcompress.compress(data, format="xlsb")
    assert len(results) > 0


def test_compress_bytes_no_format():
    with open(XLSB_FILE, "rb") as f:
        data = f.read()
    with pytest.raises((ValueError, TypeError)):
        xlcompress.compress(data)


def test_file_not_found():
    with pytest.raises(FileNotFoundError):
        xlcompress.compress("/nonexistent/path.xlsx")


def test_no_structural():
    names = xlcompress.list_sheets(XLSB_FILE)
    first = names[0]
    results = xlcompress.compress(XLSB_FILE, sheets=[first], structural=False)
    assert len(results) == 1
