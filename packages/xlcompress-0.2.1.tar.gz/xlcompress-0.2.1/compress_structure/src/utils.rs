use once_cell::sync::Lazy;
use regex::Regex;

static CELL_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"\|([A-Z]+)(\d+),([^|]*)").unwrap());

static ADDR_RE: Lazy<Regex> =
    Lazy::new(|| Regex::new(r"^([A-Z]+)(\d+)$").unwrap());

/// Parse one encoded row string into a Vec of (col_1indexed, row_1indexed, value) tuples.
///
/// Input: a row string of the form `|A1,val1|B1,val2|...`
/// Output: Vec<(col: usize, row: usize, value: String)> where col and row are 1-indexed.
pub fn parse_row(row: &str) -> Vec<(usize, usize, String)> {
    CELL_RE
        .captures_iter(row)
        .map(|cap| {
            let col_str = &cap[1];
            let row_num: usize = cap[2].parse().unwrap_or(1);
            let value = cap[3].to_string();
            let col_num = col_letter_to_num(col_str);
            (col_num, row_num, value)
        })
        .collect()
}

/// Convert a column letter string (e.g. "A", "AA") to a 1-based column number.
///
/// Input: column letter string (all uppercase, non-empty)
/// Output: 1-based column index (usize)
pub fn col_letter_to_num(col: &str) -> usize {
    col.bytes().fold(0usize, |acc, b| {
        acc * 26 + (b - b'A' + 1) as usize
    })
}

/// Convert a 1-based column number to a column letter string (e.g. 1 -> "A", 27 -> "AA").
///
/// Input: 1-based column number (usize, must be >= 1)
/// Output: uppercase column letter string
pub fn col_num_to_letter(mut n: usize) -> String {
    let mut result = Vec::new();
    while n > 0 {
        n -= 1;
        result.push((b'A' + (n % 26) as u8) as char);
        n /= 26;
    }
    result.into_iter().rev().collect()
}

/// Parse an Excel address string like "B3" into (col_1indexed, row_1indexed).
///
/// Input: address string e.g. "AB12"
/// Output: Option<(col: usize, row: usize)> both 1-indexed, or None if unparseable
pub fn parse_address(addr: &str) -> Option<(usize, usize)> {
    let caps = ADDR_RE.captures(addr)?;
    let col = col_letter_to_num(&caps[1]);
    let row: usize = caps[2].parse().ok()?;
    Some((col, row))
}

/// Format a (col_1indexed, row_1indexed) pair into an Excel address string like "B3".
///
/// Input: (col: usize, row: usize) both 1-indexed
/// Output: Excel address string
pub fn format_address(col: usize, row: usize) -> String {
    format!("{}{}", col_num_to_letter(col), row)
}

/// Encode a list of (col, row, value) cells as a row string `|A1,val|B1,val|...`.
///
/// Input: slice of (col_1indexed, row_1indexed, value) tuples
/// Output: encoded row string
pub fn encode_row(cells: &[(usize, usize, String)]) -> String {
    let mut s = String::new();
    for (col, row, val) in cells {
        s.push('|');
        s.push_str(&format_address(*col, *row));
        s.push(',');
        s.push_str(val);
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_col_roundtrip() {
        for n in 1..=702usize {
            assert_eq!(col_letter_to_num(&col_num_to_letter(n)), n);
        }
    }

    #[test]
    fn test_parse_row() {
        let row = "|A1,hello|B1,world";
        let cells = parse_row(row);
        assert_eq!(cells.len(), 2);
        assert_eq!(cells[0], (1, 1, "hello".into()));
        assert_eq!(cells[1], (2, 1, "world".into()));
    }
}
