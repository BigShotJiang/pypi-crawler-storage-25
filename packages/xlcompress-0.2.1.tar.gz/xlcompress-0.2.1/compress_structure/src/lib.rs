pub mod config;
pub mod utils;
pub mod compress_structure;

use std::collections::HashMap;
use serde::{Deserialize, Serialize};
use serde_json::Value;

pub use compress_structure::{
    row_delete,
    col_delete,
    delete_space,
    coordinate_rearrangement,
    groundtruth_coordinate_rearrangement,
    extract_boundaries_from_labels,
    extract_cell_rows,
    extract_nfs_rows,
    rows_to_new_input,
};
pub use utils::{col_letter_to_num, col_num_to_letter, parse_address, format_address, parse_row, encode_row};
pub use config::DELTA;

/// A single record from the input JSONL file.
///
/// The layout matches the Python data["messages"] structure:
/// messages[0] = system, messages[1] = user (contains the prompt with Cell_Input / NFS_Input),
/// messages[2] = assistant (contains the labels as a Vec<Vec<String>>).
#[derive(Debug, Serialize, Deserialize)]
pub struct InputRecord {
    pub file_name: String,
    pub messages: Vec<Value>,
    #[serde(flatten)]
    pub extra: HashMap<String, Value>,
}

/// Output of the coordinate mapping, written per-record to the mapping JSONL file.
#[derive(Debug, Serialize, Deserialize)]
pub struct MappingRecord {
    pub file_name: String,
    /// Maps compact address -> original address (forward map, "reflection" in Python).
    pub reflection: HashMap<String, String>,
    /// Maps original address -> compact address (reverse map, "reflection_r" in Python).
    pub reflection_r: HashMap<String, String>,
}

/// Compress one InputRecord in place.
///
/// Applies boundary-based structural compression:
/// 1. Extract row and column boundary indices from the label ranges.
/// 2. Merge with any externally-supplied extra boundaries.
/// 3. Filter rows and columns to within DELTA of each boundary.
/// 4. Delete interior whitespace rows.
/// 5. Remap coordinates to a compact 1-indexed grid.
/// 6. Update the record's prompt and labels in place.
///
/// Input:
///   - `record`: mutable reference to an InputRecord
///   - `extra_row_boundaries`: additional absolute 1-based row boundary indices
///   - `extra_col_boundaries`: additional absolute 1-based column boundary indices
///
/// Output: Ok(MappingRecord) on success, Err(String) describing the failure.
pub fn compress_record(
    record: &mut InputRecord,
    extra_row_boundaries: &[usize],
    extra_col_boundaries: &[usize],
) -> Result<MappingRecord, String> {
    let prompt = record
        .messages
        .get(1)
        .and_then(|m| m["content"].as_str())
        .ok_or("messages[1].content missing or not a string")?
        .to_string();

    let labels_value = record
        .messages
        .get(2)
        .and_then(|m| m["content"].as_array())
        .ok_or("messages[2].content missing or not an array")?
        .clone();

    let mut labels: Vec<Vec<String>> = labels_value
        .iter()
        .map(|group| {
            group
                .as_array()
                .unwrap_or(&vec![])
                .iter()
                .filter_map(|v| v.as_str().map(|s| s.to_string()))
                .collect()
        })
        .collect();

    // Gather boundaries from labels + any externally supplied boundaries.
    let (mut row_bounds, mut col_bounds) = extract_boundaries_from_labels(&labels);
    row_bounds.extend_from_slice(extra_row_boundaries);
    col_bounds.extend_from_slice(extra_col_boundaries);
    row_bounds.sort_unstable();
    row_bounds.dedup();
    col_bounds.sort_unstable();
    col_bounds.dedup();

    // Extract rows.
    let txt_rows = extract_cell_rows(&prompt);
    let nfs_rows = extract_nfs_rows(&prompt);

    if txt_rows.is_empty() {
        return Err("No Cell_Input rows found in prompt".into());
    }

    // Row/col deletion.
    let txt_rows = row_delete(&txt_rows, &row_bounds);
    let txt_rows = col_delete(&txt_rows, &col_bounds);
    let nfs_rows = row_delete(&nfs_rows, &row_bounds);
    let nfs_rows = col_delete(&nfs_rows, &col_bounds);

    // Interior whitespace deletion.
    let (txt_rows, nfs_rows) = delete_space(txt_rows, nfs_rows);

    if txt_rows.len() != nfs_rows.len() {
        return Err(format!(
            "txt_rows ({}) and nfs_rows ({}) length mismatch after delete_space",
            txt_rows.len(),
            nfs_rows.len()
        ));
    }

    // Coordinate remapping.
    let (new_txt_rows, forward, reverse) = coordinate_rearrangement(&txt_rows);
    let (new_nfs_rows, _, _) = coordinate_rearrangement(&nfs_rows);

    if new_txt_rows.len() != new_nfs_rows.len() {
        return Err("length mismatch after coordinate_rearrangement".into());
    }

    // Remap labels.
    groundtruth_coordinate_rearrangement(&reverse, &mut labels);

    // Build new prompt.
    let new_prompt = rows_to_new_input(&new_txt_rows, &new_nfs_rows);

    // Write back.
    if let Some(msg) = record.messages.get_mut(1) {
        msg["content"] = Value::String(new_prompt);
    }
    if let Some(msg) = record.messages.get_mut(2) {
        let new_labels_value: Value = serde_json::to_value(&labels).unwrap();
        msg["content"] = new_labels_value;
    }

    Ok(MappingRecord {
        file_name: record.file_name.clone(),
        reflection: forward,
        reflection_r: reverse,
    })
}

/// Process a complete input JSONL string and return (output JSONL, mapping JSONL).
///
/// Each line of `input_jsonl` is a JSON-encoded InputRecord. Records that fail to
/// parse or compress are skipped (matching Python's try/except continue behaviour).
/// Records with empty label ranges and no external boundaries are passed through
/// unmodified, matching the Python `len(boundary_list) == 0` branch.
///
/// Input:
///   - `input_jsonl`: full contents of the input JSONL file as a string
///
/// Output: (output_jsonl_string, mapping_jsonl_string)
pub fn compress_jsonl(input_jsonl: &str) -> (String, String) {
    let mut output_lines: Vec<String> = Vec::new();
    let mut mapping_lines: Vec<String> = Vec::new();

    for line in input_jsonl.lines() {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let mut record: InputRecord = match serde_json::from_str(line) {
            Ok(r) => r,
            Err(e) => {
                eprintln!("JSON parse error: {}", e);
                continue;
            }
        };

        match compress_record(&mut record, &[], &[]) {
            Ok(mapping) => {
                output_lines.push(serde_json::to_string(&record).unwrap());
                mapping_lines.push(serde_json::to_string(&mapping).unwrap());
            }
            Err(e) => {
                eprintln!("Compression error for {}: {}", record.file_name, e);
                // Pass through unmodified (matches Python fallback for empty boundary_list).
                output_lines.push(serde_json::to_string(&record).unwrap());
            }
        }
    }

    (output_lines.join("\n"), mapping_lines.join("\n"))
}
