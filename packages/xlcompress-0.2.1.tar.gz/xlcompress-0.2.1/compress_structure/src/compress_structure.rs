use std::collections::{BTreeSet, HashMap};

use crate::config::DELTA;
use crate::utils::{encode_row, format_address, parse_row};

/// Build a keep-tag array for rows or columns given a set of boundary indices.
///
/// Mirrors Python's row_delete / col_delete tag-building logic.
/// All indices are 1-based.
///
/// Input:
///   - `boundaries`: sorted 1-based boundary indices (absolute, already offset-adjusted)
///   - `offset`: the 1-based index of the first row/col present in the data
///     (so that absolute boundary indices are converted to local 1-based positions)
///   - `count`: total number of rows/cols in the data
///
/// Output: Vec<bool> of length `count`, where `true` means the row/col should be kept.
fn build_keep_tag(boundaries: &[usize], offset: usize, count: usize) -> Vec<bool> {
    // tag is 1-indexed internally: tag[1..=count]
    // We use a 0-indexed vec of length count+1 and ignore index 0.
    let mut tag = vec![false; count + 1];

    for &b in boundaries {
        // Convert absolute boundary to local 1-based index.
        let rb = if b < offset {
            // boundary is before the data window — clamp to 1
            1usize
        } else {
            let local = b - offset + 1;
            if local > count { count } else { local }
        };
        tag[rb] = true;

        let lo = if rb > DELTA { rb - DELTA } else { 1 };
        let hi = if rb + DELTA <= count { rb + DELTA } else { count };
        for i in lo..=hi {
            tag[i] = true;
        }
    }

    // Return as 0-indexed Vec<bool> aligned with data rows/cols (index 0 = first row/col).
    tag[1..=count].to_vec()
}

/// Find runs of consecutive `true` values in a bool slice and return their (start, end) inclusive
/// 0-based indices. Only runs of length >= 2 are returned (matching Python logic).
///
/// Input: slice of bool
/// Output: Vec of (start_inclusive, end_inclusive) 0-based index pairs
fn find_consecutive_true_intervals(tag: &[bool]) -> Vec<(usize, usize)> {
    let mut intervals = Vec::new();
    let mut start: Option<usize> = None;
    let mut count = 0usize;

    for (i, &v) in tag.iter().enumerate() {
        if v {
            if start.is_none() {
                start = Some(i);
            }
            count += 1;
        }

        if !v || i == tag.len() - 1 {
            if count >= 2 {
                let end = if !v { i - 1 } else { i };
                intervals.push((start.unwrap(), end));
            }
            start = None;
            count = 0;
        }
    }
    intervals
}

/// Check whether all cells in a parsed row have empty values.
///
/// Input: slice of (col, row, value) tuples representing one row's cells
/// Output: true if every cell's value is the empty string
fn row_is_blank(cells: &[(usize, usize, String)]) -> bool {
    cells.iter().all(|(_, _, v)| v.is_empty())
}

/// Check which column positions (0-indexed into the cell list) are blank across all rows.
///
/// Input: 2-D slice — outer is rows, inner is cells as (col, row, value)
/// Output: Vec<bool> of length = number of columns; true means the column is entirely blank
fn col_blank_tags(grid: &[Vec<(usize, usize, String)>]) -> Vec<bool> {
    if grid.is_empty() {
        return vec![];
    }
    let ncols = grid[0].len();
    let mut blank = vec![true; ncols];
    for row_cells in grid {
        for (j, (_, _, v)) in row_cells.iter().enumerate() {
            if j < ncols && v != " " && !v.is_empty() {
                blank[j] = false;
            }
        }
    }
    blank
}

/// Delete rows outside the DELTA neighbourhood of any boundary row.
///
/// Input:
///   - `rows`: encoded row strings in the form `|A1,val|B1,val|...`
///   - `row_boundaries`: sorted 1-based absolute row indices that are boundaries
///
/// Output: filtered Vec of encoded row strings (same format)
pub fn row_delete(rows: &[String], row_boundaries: &[usize]) -> Vec<String> {
    if rows.is_empty() || row_boundaries.is_empty() {
        return rows.to_vec();
    }

    // Determine the 1-based row index of the first row in `rows`.
    let first_cells = parse_row(&rows[0]);
    let offset = first_cells.first().map(|(_, r, _)| *r).unwrap_or(1);

    let keep = build_keep_tag(row_boundaries, offset, rows.len());

    rows.iter()
        .zip(keep.iter())
        .filter_map(|(row, &k)| if k { Some(row.clone()) } else { None })
        .collect()
}

/// Delete columns outside the DELTA neighbourhood of any boundary column.
///
/// Input:
///   - `rows`: encoded row strings in the form `|A1,val|B1,val|...`
///   - `col_boundaries`: sorted 1-based absolute column indices that are boundaries
///
/// Output: filtered Vec of encoded row strings with non-kept columns removed
pub fn col_delete(rows: &[String], col_boundaries: &[usize]) -> Vec<String> {
    if rows.is_empty() || col_boundaries.is_empty() {
        return rows.to_vec();
    }

    // Determine the 1-based col index of the first column in `rows`.
    let first_cells = parse_row(&rows[0]);
    let offset = first_cells.first().map(|(c, _, _)| *c).unwrap_or(1);
    let width = first_cells.len();

    let keep = build_keep_tag(col_boundaries, offset, width);

    rows.iter()
        .map(|row| {
            let cells = parse_row(row);
            let kept: Vec<(usize, usize, String)> = cells
                .into_iter()
                .zip(keep.iter())
                .filter_map(|(cell, &k)| if k { Some(cell) } else { None })
                .collect();
            encode_row(&kept)
        })
        .collect()
}

/// Remove interior blank rows and interior blank columns from two parallel row lists.
///
/// "Interior" means not at index 0 or at the last index. Blank runs of length >= 2
/// are deleted (the boundary rows of the run at indices 0 and len-1 are kept to
/// preserve edge rows). Single blank rows are also deleted unless at the edges.
///
/// This mirrors Python's delete_space function. The two lists (txt and nfs) are
/// filtered in lockstep using the row tags derived from `txt_rows`.
///
/// Input:
///   - `txt_rows`: cell-value encoded row strings
///   - `nfs_rows`: number-format encoded row strings (parallel to txt_rows)
///
/// Output: (new_txt_rows, new_nfs_rows) with interior blanks removed
pub fn delete_space(
    txt_rows: Vec<String>,
    nfs_rows: Vec<String>,
) -> (Vec<String>, Vec<String>) {
    // --- row blanks ---
    let parsed_grid: Vec<Vec<(usize, usize, String)>> =
        txt_rows.iter().map(|r| parse_row(r)).collect();

    let mut row_tag: Vec<u8> = parsed_grid
        .iter()
        .map(|cells| if row_is_blank(cells) { 1 } else { 0 })
        .collect();

    // Mark interior consecutive blank runs: boundary indices of the run get tag=2
    // (kept), interior remain 1 (deleted). Single blanks in the interior also get
    // deleted (tag stays 1).
    // Python uses find_consecutive_ones_intervals which only returns runs of >=2.
    let row_intervals = find_consecutive_true_intervals(
        &row_tag.iter().map(|&t| t == 1).collect::<Vec<_>>(),
    );
    for (start, end) in &row_intervals {
        if *start == 0 || *end == row_tag.len() - 1 {
            continue;
        }
        row_tag[*start] = 2;
        row_tag[*end] = 2;
    }

    // --- col blanks ---
    let col_blank = col_blank_tags(&parsed_grid);
    let mut col_tag: Vec<u8> = col_blank.iter().map(|&b| if b { 1 } else { 0 }).collect();

    let col_intervals = find_consecutive_true_intervals(
        &col_tag.iter().map(|&t| t == 1).collect::<Vec<_>>(),
    );
    for (start, end) in &col_intervals {
        if *start == 0 || *end == col_tag.len() - 1 {
            continue;
        }
        col_tag[*start] = 2;
        col_tag[*end] = 2;
    }

    // Filter rows: keep rows where row_tag != 1
    let new_txt_rows: Vec<String> = txt_rows
        .iter()
        .zip(row_tag.iter())
        .filter_map(|(r, &t)| if t != 1 { Some(r.clone()) } else { None })
        .collect();
    let new_nfs_rows: Vec<String> = nfs_rows
        .iter()
        .zip(row_tag.iter())
        .filter_map(|(r, &t)| if t != 1 { Some(r.clone()) } else { None })
        .collect();

    // Note: col filtering is NOT applied to the row strings here — Python's delete_space
    // also only filters rows, not columns (col_tag is computed but the col deletion
    // pass already happened upstream in compress_layout via col_delete).
    // The col_tag computation in Python appears unused in delete_space itself as well.
    let _ = col_tag; // suppress unused warning, matches Python behaviour

    (new_txt_rows, new_nfs_rows)
}

/// Remap coordinates to a compact 1-indexed grid.
///
/// Each cell's address is replaced by its 1-based position in the surviving grid:
/// row position = which surviving row it is (1-based), col position = which column
/// within that row (1-based). The original addresses are recorded in two maps.
///
/// Input: encoded row strings (any grid, after deletion passes)
///
/// Output:
///   - `new_rows`: re-addressed encoded row strings
///   - `forward`: map from new compact address (e.g. "A1") to original address (e.g. "C5")
///   - `reverse`: map from original address to new compact address
pub fn coordinate_rearrangement(
    rows: &[String],
) -> (Vec<String>, HashMap<String, String>, HashMap<String, String>) {
    let mut new_rows = Vec::with_capacity(rows.len());
    let mut forward: HashMap<String, String> = HashMap::new();
    let mut reverse: HashMap<String, String> = HashMap::new();

    for (i, row) in rows.iter().enumerate() {
        let cells = parse_row(row);
        let new_row_num = i + 1;
        let mut new_cells: Vec<(usize, usize, String)> = Vec::with_capacity(cells.len());

        for (j, (orig_col, orig_row, value)) in cells.into_iter().enumerate() {
            let new_col = j + 1;
            let after_addr = format_address(new_col, new_row_num);
            let before_addr = format_address(orig_col, orig_row);
            forward.insert(after_addr.clone(), before_addr.clone());
            reverse.insert(before_addr, after_addr.clone());
            new_cells.push((new_col, new_row_num, value));
        }

        new_rows.push(encode_row(&new_cells));
    }

    (new_rows, forward, reverse)
}

/// Remap range labels (e.g. "B2:C5") through the reverse coordinate map.
///
/// Input:
///   - `reverse`: map from original address to compact address (from coordinate_rearrangement)
///   - `labels`: mutable reference to a Vec of Vec<String> where each inner string is
///     a range "ADDR:ADDR"; both addresses are remapped in place
///
/// Output: the labels Vec is mutated in place and also returned
pub fn groundtruth_coordinate_rearrangement(
    reverse: &HashMap<String, String>,
    labels: &mut Vec<Vec<String>>,
) {
    for label_group in labels.iter_mut() {
        for label in label_group.iter_mut() {
            let parts: Vec<&str> = label.splitn(2, ':').collect();
            if parts.len() == 2 {
                let new_start = reverse.get(parts[0]).cloned().unwrap_or_else(|| parts[0].to_string());
                let new_end = reverse.get(parts[1]).cloned().unwrap_or_else(|| parts[1].to_string());
                *label = format!("{}:{}", new_start, new_end);
            }
        }
    }
}

/// Extract boundary rows and columns from a set of range labels.
///
/// Each label is of the form "ADDR:ADDR". Both endpoints contribute their row and column
/// to the respective boundary sets.
///
/// Input: reference to Vec<Vec<String>> labels
/// Output: (row_boundaries, col_boundaries) as sorted Vec<usize>, 1-based
pub fn extract_boundaries_from_labels(
    labels: &[Vec<String>],
) -> (Vec<usize>, Vec<usize>) {
    let mut rows: BTreeSet<usize> = BTreeSet::new();
    let mut cols: BTreeSet<usize> = BTreeSet::new();

    for group in labels {
        for label in group {
            let parts: Vec<&str> = label.splitn(2, ':').collect();
            for part in parts {
                if let Some((col, row)) = crate::utils::parse_address(part) {
                    rows.insert(row);
                    cols.insert(col);
                }
            }
        }
    }

    (rows.into_iter().collect(), cols.into_iter().collect())
}

/// Parse an encoded spreadsheet table from a prompt string.
///
/// The prompt is expected to contain a section delimited by `Cell_Input: ` and ending
/// before `\n\nNFS_Input:`. Rows within the section are split on `\n|<first_col_letter>`.
///
/// Input: prompt string
/// Output: Vec of row strings, or empty Vec if the section is not found
pub fn extract_cell_rows(prompt: &str) -> Vec<String> {
    extract_section(prompt, "Cell_Input: ", "\nNFS_Input:")
}

/// Parse an encoded NFS (number format string) table from a prompt string.
///
/// Mirrors get_table_nfs_input from Python utils.
///
/// Input: prompt string
/// Output: Vec of row strings, or empty Vec if the section is not found
pub fn extract_nfs_rows(prompt: &str) -> Vec<String> {
    // Try both delimiters the Python code handles.
    let section = extract_section(prompt, "\nNFS_Input: ", "\n\n###\n\n");
    if !section.is_empty() {
        return section;
    }
    extract_section(prompt, "NFS_Input: ", "\n\n###\n\n")
}

/// Internal helper: extract a table section from `prompt` between `start_marker` and
/// `end_marker`, then split it into row strings.
///
/// Input: prompt str, start_marker str, end_marker str
/// Output: Vec<String> of row strings
fn extract_section(prompt: &str, start_marker: &str, end_marker: &str) -> Vec<String> {
    let start = match prompt.find(start_marker) {
        Some(i) => i + start_marker.len(),
        None => return vec![],
    };
    let end = prompt[start..].find(end_marker).map(|i| start + i).unwrap_or(prompt.len());
    let section = prompt[start..end].trim();
    if section.is_empty() {
        return vec![];
    }

    // Split on row boundaries: `\n|<first column letter>`
    // The first cell's column letter starts the second character of the first row.
    let first_col_letter = section.chars().nth(1).unwrap_or('A');
    let delimiter = format!("\n|{}", first_col_letter);
    let parts: Vec<&str> = section.split(&delimiter).collect();

    let mut rows = vec![parts[0].to_string()];
    for part in &parts[1..] {
        rows.push(format!("|{}{}", first_col_letter, part));
    }
    rows
}

/// Build a prompt section string from compressed cell and NFS rows.
///
/// Mirrors Python's rows_to_new_input.
///
/// Input: txt_rows and nfs_rows as slices of encoded row strings
/// Output: formatted prompt section string
pub fn rows_to_new_input(txt_rows: &[String], nfs_rows: &[String]) -> String {
    format!(
        "\nCell_Input: {}\n\nNFS_Input: {}\n\n###\n\n",
        txt_rows.join("\n"),
        nfs_rows.join("\n")
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_build_keep_tag_basic() {
        // 10 rows, boundary at row 3, delta=4 => keep rows 1..=7 (local 1-based)
        let tag = build_keep_tag(&[3], 1, 10);
        // index 0 = row 1, index 6 = row 7
        for i in 0..7 {
            assert!(tag[i], "row {} should be kept", i + 1);
        }
        for i in 7..10 {
            assert!(!tag[i], "row {} should not be kept", i + 1);
        }
    }

    #[test]
    fn test_find_consecutive_true_intervals() {
        let tag = vec![false, true, true, true, false, false];
        let intervals = find_consecutive_true_intervals(&tag);
        assert_eq!(intervals, vec![(1, 3)]);
    }

    #[test]
    fn test_coordinate_rearrangement() {
        let rows = vec!["|C3,hello|D3,world".to_string()];
        let (new_rows, fwd, rev) = coordinate_rearrangement(&rows);
        assert_eq!(new_rows[0], "|A1,hello|B1,world");
        assert_eq!(fwd["A1"], "C3");
        assert_eq!(rev["C3"], "A1");
    }
}
