/// Number of rows/columns on each side of a boundary row/col to retain.
/// Matches Python config.DELTA = 4.
pub const DELTA: usize = 4;
