# XGuard Agent Safety MCP

A ModelScope/XGuard-powered MCP server for agent safety.

## Tools
- inspect_prompt
- inspect_response
- inspect_conversation
- inspect_tool_call

## Features
- Prompt safety inspection
- Response safety inspection
- Conversation safety inspection
- Tool-call safety gate for agents

## Notes
- Default model is controlled by env var `XGUARD_MODEL_ID`
- Explanation length is controlled by env var `XGUARD_EXPLAIN_TOKENS`
