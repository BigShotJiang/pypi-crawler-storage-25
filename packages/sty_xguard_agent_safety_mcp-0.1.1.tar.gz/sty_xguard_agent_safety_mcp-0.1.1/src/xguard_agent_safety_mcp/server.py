import json
import logging
import os
import re
import sys
import threading
from typing import Any

import torch
from modelscope import AutoModelForCausalLM, AutoTokenizer

try:
    from fastmcp import FastMCP
except ImportError:
    from mcp.server.fastmcp import FastMCP


# =========================
# logging: STDIO server 不要写 stdout
# =========================
logging.basicConfig(
    level=logging.INFO,
    stream=sys.stderr,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("xguard-agent-safety")


# =========================
# 配置
# =========================
# 你说想切到 8B，这里默认就用 8B
MODEL_ID = os.getenv("XGUARD_MODEL_ID", "Alibaba-AAIG/YuFeng-XGuard-Reason-8B")
DEFAULT_EXPLAIN_TOKENS = int(os.getenv("XGUARD_EXPLAIN_TOKENS", "200"))

mcp = FastMCP("XGuard Agent Safety")


# =========================
# 全局懒加载模型
# =========================
_model = None
_tokenizer = None
_model_lock = threading.Lock()


def get_model():
    global _model, _tokenizer
    if _model is None or _tokenizer is None:
        with _model_lock:
            if _model is None or _tokenizer is None:
                logger.info("Loading model: %s", MODEL_ID)
                _tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
                _model = AutoModelForCausalLM.from_pretrained(
                    MODEL_ID,
                    torch_dtype="auto",
                    device_map="auto",
                ).eval()
                logger.info("Model loaded: %s", MODEL_ID)
    return _model, _tokenizer


# =========================
# XGuard 官方 infer 逻辑
# =========================
def infer(model, tokenizer, messages, policy=None, max_new_tokens=1, reason_first=False):
    rendered_query = tokenizer.apply_chat_template(
        messages,
        policy=policy,
        reason_first=reason_first,
        tokenize=False
    )

    model_inputs = tokenizer([rendered_query], return_tensors="pt").to(model.device)

    outputs = model.generate(
        **model_inputs,
        max_new_tokens=max_new_tokens,
        do_sample=False,
        output_scores=True,
        return_dict_in_generate=True
    )

    batch_idx = 0
    input_length = model_inputs["input_ids"].shape[1]

    output_ids = outputs["sequences"].tolist()[batch_idx][input_length:]
    response = tokenizer.decode(output_ids, skip_special_tokens=True)

    generated_tokens_with_probs = []
    generated_tokens = outputs.sequences[:, input_length:]

    scores = torch.stack(outputs.scores, 1)
    scores = scores.softmax(-1)
    scores_topk_value, scores_topk_index = scores.topk(k=10, dim=-1)

    for generated_token, score_topk_value, score_topk_index in zip(
        generated_tokens, scores_topk_value, scores_topk_index
    ):
        generated_tokens_with_prob = []
        for token, topk_value, topk_index in zip(
            generated_token, score_topk_value, score_topk_index
        ):
            token = int(token.cpu())
            if token == tokenizer.pad_token_id:
                continue

            res_topk_score = {}
            for ii, (value, index) in enumerate(zip(topk_value, topk_index)):
                prob = float(value.cpu().numpy())
                idx = int(index.cpu().numpy())
                if ii == 0 or prob > 1e-4:
                    text = tokenizer.decode(idx)
                    res_topk_score[text] = {
                        "id": str(idx),
                        "prob": round(prob, 4),
                    }

            generated_tokens_with_prob.append(res_topk_score)

        generated_tokens_with_probs.append(generated_tokens_with_prob)

    score_idx = max(len(generated_tokens_with_probs[batch_idx]) - 2, 0) if reason_first else 0
    id2risk = tokenizer.init_kwargs["id2risk"]

    token_score = {
        k: v["prob"]
        for k, v in generated_tokens_with_probs[batch_idx][score_idx].items()
    }

    risk_score = {
        id2risk[k]: v["prob"]
        for k, v in generated_tokens_with_probs[batch_idx][score_idx].items()
        if k in id2risk
    }

    result = {
        "response": response,
        "token_score": token_score,
        "risk_score": risk_score,
    }
    return result


# =========================
# 通用工具函数
# =========================
def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True)
    except Exception:
        return str(obj)


def _extract_explanation(response: str) -> str:
    if not response:
        return ""
    m = re.search(r"<explanation>(.*?)</explanation>", response, flags=re.S)
    if m:
        return m.group(1).strip()
    return response.strip()


def _pick_top_risk(risk_score: dict[str, float]) -> tuple[str | None, float]:
    if not risk_score:
        return None, 0.0
    tag = max(risk_score, key=risk_score.get)
    return tag, float(risk_score[tag])


def _pick_top_token(token_score: dict[str, float]) -> tuple[str | None, float]:
    if not token_score:
        return None, 0.0
    tag = max(token_score, key=token_score.get)
    return tag, float(token_score[tag])


def _sorted_non_safe_risks(risk_score: dict[str, float]) -> list[tuple[str, float]]:
    items = [(k, float(v)) for k, v in risk_score.items() if k != "Safe-Safe"]
    items.sort(key=lambda x: x[1], reverse=True)
    return items


def _base_content_decision(
    top_risk_tag: str | None,
    top_risk_score: float,
    top_token_tag: str | None,
    block_threshold: float,
    review_threshold: float,
) -> tuple[str, list[str]]:
    reasons = []

    if top_risk_tag == "Safe-Safe":
        reasons.append("top_risk_is_safe")
        return "allow", reasons

    if top_risk_tag is not None and top_risk_score >= block_threshold:
        reasons.append("top_risk_over_block_threshold")
        return "block", reasons

    if top_risk_tag is not None and top_risk_score >= review_threshold:
        reasons.append("top_risk_over_review_threshold")
        return "review", reasons

    if top_risk_tag is None and top_token_tag not in (None, "sec"):
        reasons.append("non_safe_top_token_without_mapped_risk")
        return "review", reasons

    reasons.append("no_strong_risk_signal")
    return "allow", reasons


# =========================
# tool-call 专用规则
# =========================
HIGH_RISK_TOOL_KEYWORDS = [
    "shell",
    "terminal",
    "exec",
    "execute",
    "bash",
    "powershell",
    "command",
    "file.delete",
    "file.remove",
    "fs.delete",
    "fs.remove",
    "file.write",
    "fs.write",
    "db.write",
    "db.execute",
    "sql.execute",
]

MEDIUM_RISK_TOOL_KEYWORDS = [
    "browser.open",
    "browser",
    "http.post",
    "http.request",
    "request",
    "fetch",
    "db.query",
    "sql.query",
    "file.read",
    "fs.read",
    "git.push",
    "scp",
    "ssh",
    "wget",
    "curl",
]


def _tool_risk_level(tool_name: str) -> str:
    name = (tool_name or "").lower()

    if any(k in name for k in HIGH_RISK_TOOL_KEYWORDS):
        return "high"
    if any(k in name for k in MEDIUM_RISK_TOOL_KEYWORDS):
        return "medium"
    return "low"


def _default_tool_policy() -> str:
    # 只扩张既有类别的判定口径，不引入奇怪的新标签
    return """
- ha: Hacker Attack
  - Destructive shell commands, remote script execution, privilege escalation, network scanning, persistence setup, malware-like behaviors, and attempts to tamper with system operation should be treated as Hacker Attack.
  - Deleting audit trails, wiping logs, disabling defenses, or issuing high-impact system commands with ambiguous intent should be treated as risky rather than safe.

- acc: Access Control
  - Accessing internal-only services, localhost, private network targets, credentials, tokens, SSH keys, .env files, or bypassing authorization controls should be treated as Access Control risk.
  - Clearing logs, disabling auditing, weakening permissions, or actions that can evade monitoring should be treated as Access Control risk.

- pp: Personal Privacy
  - Requests or actions that expose personal data, account information, secrets, or user records should be treated as Personal Privacy risk.

- cs: Commercial Secret
  - Requests or actions that expose internal code, business data, proprietary documents, private repositories, credentials, or environment secrets should be treated as Commercial Secret risk.

- sec: Safe
  - Classify as Safe only when the planned action is clearly low-impact and benign.
  - If the action is high-impact, destructive, or security-sensitive and the intent is ambiguous, do not default to Safe.
""".strip()


def _combined_tool_text(
    user_goal: str,
    tool_name: str,
    tool_args: dict,
    context: list[dict] | None = None,
) -> str:
    context_text = ""
    if context:
        context_text = "\n".join(
            f"[{m.get('role', 'unknown')}] {m.get('content', '')}"
            for m in context
        )

    return (
        f"USER_GOAL:\n{user_goal}\n\n"
        f"TOOL_NAME:\n{tool_name}\n\n"
        f"TOOL_ARGS:\n{_safe_json(tool_args)}\n\n"
        f"CONTEXT:\n{context_text}"
    )


def _pattern_hits(text: str) -> dict[str, list[str]]:
    t = text.lower()

    block_rules: dict[str, list[str]] = {
        "log_wipe": [
            r"rm\s+-rf\s+/var/log",
            r"find\s+/var/log.*-delete",
            r"truncate\s+-s\s+0\s+/var/log",
            r"wevtutil\s+cl",
            r"clear-eventlog",
            r"删除.*日志",
            r"清理.*日志",
            r"清痕迹",
        ],
        "system_wipe": [
            r"rm\s+-rf\s+/(?:\s|$)",
            r"dd\s+if=.*\s+of=/dev/sd",
            r"\bmkfs\.",
        ],
        "remote_script_exec": [
            r"curl\b[^|\n]*\|\s*(bash|sh)",
            r"wget\b[^|\n]*\|\s*(bash|sh)",
            r"invoke-webrequest.*iex",
            r"downloadstring\(",
        ],
        "db_destroy": [
            r"\bdrop\s+table\b",
            r"\bdrop\s+database\b",
            r"\btruncate\s+table\b",
        ],
    }

    review_rules: dict[str, list[str]] = {
        "destructive_delete": [
            r"rm\s+-rf",
            r"\bdel\s+/[sfq]",
            r"remove-item\b.*-recurse",
            r"删库",
            r"删除",
        ],
        "permission_weaken": [
            r"chmod\s+777",
            r"setenforce\s+0",
            r"ufw\s+disable",
            r"iptables\s+-f",
            r"关闭审计",
            r"禁用防护",
        ],
        "network_scan": [
            r"\bnmap\b",
            r"\bmasscan\b",
            r"\bnikto\b",
            r"\bnc\s",
            r"\bnetcat\b",
        ],
        "secret_access": [
            r"/etc/passwd",
            r"\.ssh/id_rsa",
            r"\.env\b",
            r"aws_access_key_id",
            r"secret[_-]?key",
            r"api[_-]?key",
            r"token",
            r"读取.*密钥",
            r"导出.*凭证",
        ],
        "internal_target": [
            r"\blocalhost\b",
            r"\b127\.0\.0\.1\b",
            r"\b10\.\d+\.\d+\.\d+\b",
            r"\b192\.168\.\d+\.\d+\b",
            r"\b172\.(1[6-9]|2\d|3[01])\.\d+\.\d+\b",
            r"内网",
            r"内部服务",
        ],
    }

    out = {"block": [], "review": []}

    for rule_name, patterns in block_rules.items():
        for p in patterns:
            if re.search(p, t, flags=re.I):
                out["block"].append(rule_name)
                break

    for rule_name, patterns in review_rules.items():
        for p in patterns:
            if re.search(p, t, flags=re.I):
                out["review"].append(rule_name)
                break

    return out


def _decide_tool_call(
    tool_name: str,
    user_goal: str,
    tool_args: dict,
    risk_score: dict[str, float],
    token_score: dict[str, float],
    top_risk_tag: str | None,
    top_risk_score: float,
    top_token_tag: str | None,
    block_threshold: float,
    review_threshold: float,
    context: list[dict] | None = None,
) -> tuple[str, list[str], dict[str, Any]]:
    reasons = []
    debug: dict[str, Any] = {}

    combined_text = _combined_tool_text(user_goal, tool_name, tool_args, context)
    hits = _pattern_hits(combined_text)
    risk_level = _tool_risk_level(tool_name)
    safe_score = float(risk_score.get("Safe-Safe", 0.0))
    non_safe_risks = _sorted_non_safe_risks(risk_score)
    second_tag, second_score = (non_safe_risks[0] if non_safe_risks else (None, 0.0))

    debug["tool_risk_level"] = risk_level
    debug["safe_score"] = round(safe_score, 4)
    debug["strongest_non_safe_tag"] = second_tag
    debug["strongest_non_safe_score"] = round(float(second_score), 4)
    debug["rule_hits"] = hits

    # 1) 硬阻断：明显危险/毁灭性动作
    if hits["block"]:
        reasons.append("matched_block_rule")
        reasons.extend([f"block_rule:{x}" for x in hits["block"]])
        return "block", reasons, debug

    # 2) 模型明确高风险
    if top_risk_tag not in (None, "Safe-Safe") and top_risk_score >= block_threshold:
        reasons.append("model_top_risk_over_block_threshold")
        return "block", reasons, debug

    # 3) 高危工具先保守
    if risk_level == "high":
        if hits["review"]:
            reasons.append("high_risk_tool_with_review_rule")
            reasons.extend([f"review_rule:{x}" for x in hits["review"]])
            return "review", reasons, debug

        # 即便 Safe 第一，只要第二高非安全风险很高，也不直接放
        if safe_score < 0.75 and second_score >= 0.20:
            reasons.append("high_risk_tool_with_strong_secondary_risk")
            return "review", reasons, debug

        # 高危工具如果 safe 本身都不够稳，也先 review
        if safe_score < 0.60:
            reasons.append("high_risk_tool_low_safe_confidence")
            return "review", reasons, debug

        # 映射不到 risk_score 但 token 明显不是 sec，也别直接放
        if top_risk_tag is None and top_token_tag not in (None, "sec"):
            reasons.append("high_risk_tool_non_safe_top_token")
            return "review", reasons, debug

        if top_risk_tag not in (None, "Safe-Safe") and top_risk_score >= review_threshold:
            reasons.append("high_risk_tool_model_review_threshold")
            return "review", reasons, debug

        reasons.append("high_risk_tool_but_no_strong_risk_signal")
        return "allow", reasons, debug

    # 4) 中危工具稍微宽一点，但仍要看规则和第二高风险
    if risk_level == "medium":
        if hits["review"] and second_score >= 0.10:
            reasons.append("medium_risk_tool_with_review_rule")
            reasons.extend([f"review_rule:{x}" for x in hits["review"]])
            return "review", reasons, debug

        if top_risk_tag not in (None, "Safe-Safe") and top_risk_score >= review_threshold:
            reasons.append("medium_risk_tool_model_review_threshold")
            return "review", reasons, debug

        if safe_score < 0.55 and second_score >= 0.25:
            reasons.append("medium_risk_tool_low_safe_confidence")
            return "review", reasons, debug

        reasons.append("medium_risk_tool_no_strong_risk_signal")
        return "allow", reasons, debug

    # 5) 低危工具退回普通内容判定
    decision, base_reasons = _base_content_decision(
        top_risk_tag=top_risk_tag,
        top_risk_score=top_risk_score,
        top_token_tag=top_token_tag,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
    )
    reasons.extend(base_reasons)
    return decision, reasons, debug


# =========================
# 通用评估入口
# =========================
def _evaluate_messages(
    messages: list[dict],
    policy: str | None = None,
    explain: bool = False,
    block_threshold: float = 0.80,
    review_threshold: float = 0.40,
) -> dict[str, Any]:
    model, tokenizer = get_model()

    max_new_tokens = DEFAULT_EXPLAIN_TOKENS if explain else 1
    raw = infer(
        model=model,
        tokenizer=tokenizer,
        messages=messages,
        policy=policy,
        max_new_tokens=max_new_tokens,
        reason_first=False,
    )

    top_risk_tag, top_risk_score = _pick_top_risk(raw["risk_score"])
    top_token_tag, top_token_score = _pick_top_token(raw["token_score"])

    decision, reasons = _base_content_decision(
        top_risk_tag=top_risk_tag,
        top_risk_score=top_risk_score,
        top_token_tag=top_token_tag,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
    )

    result = {
        "model_id": MODEL_ID,
        "decision": decision,
        "decision_reasons": reasons,
        "top_risk_tag": top_risk_tag,
        "top_risk_score": round(top_risk_score, 4),
        "top_token_tag": top_token_tag,
        "top_token_score": round(top_token_score, 4),
        "risk_score": raw["risk_score"],
        "token_score": raw["token_score"],
        "raw_response": raw["response"],
        "explanation": _extract_explanation(raw["response"]) if explain else "",
        "thresholds": {
            "review_threshold": review_threshold,
            "block_threshold": block_threshold,
        },
        "policy_applied": bool(policy),
    }
    return result


# =========================
# MCP tools
# =========================
@mcp.tool()
def ping() -> dict[str, Any]:
    """检查 MCP 服务是否正常可用。"""
    return {
        "ok": True,
        "server": "XGuard Agent Safety",
        "model_id": MODEL_ID,
    }


@mcp.tool()
def inspect_prompt(
    prompt: str,
    policy: str | None = None,
    explain: bool = False,
    block_threshold: float = 0.80,
    review_threshold: float = 0.40,
) -> dict[str, Any]:
    """
    检查用户输入/提示词是否存在安全风险。
    """
    messages = [{"role": "user", "content": prompt}]
    return _evaluate_messages(
        messages=messages,
        policy=policy,
        explain=explain,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
    )


@mcp.tool()
def inspect_response(
    user_prompt: str,
    assistant_response: str,
    policy: str | None = None,
    explain: bool = False,
    block_threshold: float = 0.80,
    review_threshold: float = 0.40,
) -> dict[str, Any]:
    """
    检查 assistant 回复是否安全。
    """
    messages = [
        {"role": "user", "content": user_prompt},
        {"role": "assistant", "content": assistant_response},
    ]
    return _evaluate_messages(
        messages=messages,
        policy=policy,
        explain=explain,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
    )


@mcp.tool()
def inspect_conversation(
    messages: list[dict],
    policy: str | None = None,
    explain: bool = False,
    block_threshold: float = 0.80,
    review_threshold: float = 0.40,
) -> dict[str, Any]:
    """
    检查完整多轮对话链路是否存在安全风险。
    """
    return _evaluate_messages(
        messages=messages,
        policy=policy,
        explain=explain,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
    )


@mcp.tool()
def inspect_tool_call(
    user_goal: str,
    tool_name: str,
    tool_args: dict,
    context: list[dict] | None = None,
    policy: str | None = None,
    explain: bool = False,
    block_threshold: float = 0.80,
    review_threshold: float = 0.40,
) -> dict[str, Any]:
    """
    在 Agent 调用工具前，对计划中的 tool call 做安全审查。
    """
    applied_policy = policy or _default_tool_policy()

    prompt = (
        "You are reviewing a planned agent tool call for enterprise safety.\n\n"
        "Judge the action itself, not only whether the surrounding conversation is phrased as a request.\n"
        "If the action is high-impact, destructive, security-sensitive, or could remove auditability, "
        "prefer a non-safe interpretation unless it is clearly benign.\n\n"
        f"User goal:\n{user_goal}\n\n"
        f"Planned tool name:\n{tool_name}\n\n"
        f"Planned tool args:\n{_safe_json(tool_args)}\n"
    )

    messages = list(context or [])
    messages.append({"role": "user", "content": prompt})

    model, tokenizer = get_model()

    max_new_tokens = DEFAULT_EXPLAIN_TOKENS if explain else 1
    raw = infer(
        model=model,
        tokenizer=tokenizer,
        messages=messages,
        policy=applied_policy,
        max_new_tokens=max_new_tokens,
        reason_first=False,
    )

    top_risk_tag, top_risk_score = _pick_top_risk(raw["risk_score"])
    top_token_tag, top_token_score = _pick_top_token(raw["token_score"])

    decision, decision_reasons, debug = _decide_tool_call(
        tool_name=tool_name,
        user_goal=user_goal,
        tool_args=tool_args,
        risk_score=raw["risk_score"],
        token_score=raw["token_score"],
        top_risk_tag=top_risk_tag,
        top_risk_score=top_risk_score,
        top_token_tag=top_token_tag,
        block_threshold=block_threshold,
        review_threshold=review_threshold,
        context=context,
    )

    result = {
        "model_id": MODEL_ID,
        "decision": decision,
        "decision_reasons": decision_reasons,
        "tool_risk_level": debug["tool_risk_level"],
        "rule_hits": debug["rule_hits"],
        "safe_score": debug["safe_score"],
        "strongest_non_safe_tag": debug["strongest_non_safe_tag"],
        "strongest_non_safe_score": debug["strongest_non_safe_score"],
        "top_risk_tag": top_risk_tag,
        "top_risk_score": round(top_risk_score, 4),
        "top_token_tag": top_token_tag,
        "top_token_score": round(top_token_score, 4),
        "risk_score": raw["risk_score"],
        "token_score": raw["token_score"],
        "raw_response": raw["response"],
        "explanation": _extract_explanation(raw["response"]) if explain else "",
        "thresholds": {
            "review_threshold": review_threshold,
            "block_threshold": block_threshold,
        },
        "policy_applied": True,
        "tool_name": tool_name,
        "tool_args": tool_args,
        "user_goal": user_goal,
    }
    return result


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()