"""Xiniu CLI package."""
