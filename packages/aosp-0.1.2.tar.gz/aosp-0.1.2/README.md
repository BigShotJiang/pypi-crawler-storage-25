# aosp

Python wrapper around an AOSP (Android Open Source Project) source tree. Sources `build/envsetup.sh`, runs `lunch`, exposes the resulting build environment as a Python object, and provides convenience accessors for the product-out tree.

Requires `sh` and [`yautil`](../yautil) (uses `docker_sh` for sandboxed builds).

## Install

```bash
pip install -e .
```

Python ≥ 3.9.

## API

```python
from aosp import Aosp, load_aosp, get_env
```

### `Aosp`

Main object representing one AOSP checkout + build target.

```python
aosp = Aosp(path="/path/to/aosp", build_target="aosp_arm64-eng")
# or
aosp = Aosp.from_path("/path/to/aosp", build_target="aosp_arm64-eng")
```

Notable properties:

| Member          | Description                                                                 |
| --------------- | --------------------------------------------------------------------------- |
| `path`          | Absolute path to the AOSP root.                                             |
| `build_target`  | The `lunch` target.                                                         |
| `env`           | `dict` of env vars exported by `envsetup.sh` + `lunch`.                     |
| `build_var`     | `dict` of build variables from `get_build_var`.                             |
| `out`           | `AospProductOut` — wrapper around `$ANDROID_PRODUCT_OUT`.                   |
| `external_paths`| Extra `PATH` entries injected when running commands inside the tree.        |

### `AospProductOut`

Returned by `Aosp.out`. Helpers for locating files under `$ANDROID_PRODUCT_OUT`:

| Member                       | Returns                                                       |
| ---------------------------- | ------------------------------------------------------------- |
| `dir`                        | Absolute path of the product-out directory.                   |
| `system_dir`                 | `system/` partition root.                                     |
| `system_lib_dirs`            | All directories on the target's `LD_LIBRARY_PATH`.            |
| `system_bin_dirs`            | All directories on the target's `PATH`.                       |
| `rc_path`                    | Path to the target's init `*.rc`.                             |
| `find_system_lib(basename)`  | List of matching library files across `system_lib_dirs`.      |
| `find_system_bin(basename)`  | List of matching binaries across `system_bin_dirs`.           |

### `load_aosp(...)`

Module-level factory (see `aosp.aosp.load_aosp`) that constructs an `Aosp` from a config profile.

### `get_env(path, target=None) -> dict`

Lower-level helper: sources `build/envsetup.sh` in `path` (and optionally runs `lunch <target>`), then returns the resulting environment as a `dict`.

```python
env = get_env("/path/to/aosp", "aosp_arm64-eng")
print(env["ANDROID_PRODUCT_OUT"])
```
