import argparse
import sys
from unittest import TestCase

from aosp import Aosp


class TestAosp(TestCase):
    pass
