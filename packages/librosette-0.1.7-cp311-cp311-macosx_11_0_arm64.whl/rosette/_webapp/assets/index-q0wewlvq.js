const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-C2Rw4G7o.js","assets/core-DxBnVPgq.js","assets/event-BC8TvpKC.js","assets/index-DWHWQ1OU.js","assets/index-BQlnJ-sT.js","assets/webviewWindow-DoRoZnHQ.js"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
(async () => {
  function Jw(l, n) {
    for (var r = 0; r < n.length; r++) {
      const o = n[r];
      if (typeof o != "string" && !Array.isArray(o)) {
        for (const i in o) if (i !== "default" && !(i in l)) {
          const c = Object.getOwnPropertyDescriptor(o, i);
          c && Object.defineProperty(l, i, c.get ? c : {
            enumerable: true,
            get: () => o[i]
          });
        }
      }
    }
    return Object.freeze(Object.defineProperty(l, Symbol.toStringTag, {
      value: "Module"
    }));
  }
  (function() {
    const n = document.createElement("link").relList;
    if (n && n.supports && n.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) o(i);
    new MutationObserver((i) => {
      for (const c of i) if (c.type === "childList") for (const d of c.addedNodes) d.tagName === "LINK" && d.rel === "modulepreload" && o(d);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function r(i) {
      const c = {};
      return i.integrity && (c.integrity = i.integrity), i.referrerPolicy && (c.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? c.credentials = "include" : i.crossOrigin === "anonymous" ? c.credentials = "omit" : c.credentials = "same-origin", c;
    }
    function o(i) {
      if (i.ep) return;
      i.ep = true;
      const c = r(i);
      fetch(i.href, c);
    }
  })();
  function Fv(l) {
    return l && l.__esModule && Object.prototype.hasOwnProperty.call(l, "default") ? l.default : l;
  }
  var Md = {
    exports: {}
  }, Ho = {};
  var sy;
  function eS() {
    if (sy) return Ho;
    sy = 1;
    var l = Symbol.for("react.transitional.element"), n = Symbol.for("react.fragment");
    function r(o, i, c) {
      var d = null;
      if (c !== void 0 && (d = "" + c), i.key !== void 0 && (d = "" + i.key), "key" in i) {
        c = {};
        for (var f in i) f !== "key" && (c[f] = i[f]);
      } else c = i;
      return i = c.ref, {
        $$typeof: l,
        type: o,
        key: d,
        ref: i !== void 0 ? i : null,
        props: c
      };
    }
    return Ho.Fragment = n, Ho.jsx = r, Ho.jsxs = r, Ho;
  }
  var iy;
  function tS() {
    return iy || (iy = 1, Md.exports = eS()), Md.exports;
  }
  var y = tS(), jd = {
    exports: {}
  }, ze = {};
  var cy;
  function nS() {
    if (cy) return ze;
    cy = 1;
    var l = Symbol.for("react.transitional.element"), n = Symbol.for("react.portal"), r = Symbol.for("react.fragment"), o = Symbol.for("react.strict_mode"), i = Symbol.for("react.profiler"), c = Symbol.for("react.consumer"), d = Symbol.for("react.context"), f = Symbol.for("react.forward_ref"), g = Symbol.for("react.suspense"), p = Symbol.for("react.memo"), v = Symbol.for("react.lazy"), b = Symbol.for("react.activity"), S = Symbol.iterator;
    function C(j) {
      return j === null || typeof j != "object" ? null : (j = S && j[S] || j["@@iterator"], typeof j == "function" ? j : null);
    }
    var k = {
      isMounted: function() {
        return false;
      },
      enqueueForceUpdate: function() {
      },
      enqueueReplaceState: function() {
      },
      enqueueSetState: function() {
      }
    }, x = Object.assign, E = {};
    function _(j, O, K) {
      this.props = j, this.context = O, this.refs = E, this.updater = K || k;
    }
    _.prototype.isReactComponent = {}, _.prototype.setState = function(j, O) {
      if (typeof j != "object" && typeof j != "function" && j != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, j, O, "setState");
    }, _.prototype.forceUpdate = function(j) {
      this.updater.enqueueForceUpdate(this, j, "forceUpdate");
    };
    function N() {
    }
    N.prototype = _.prototype;
    function A(j, O, K) {
      this.props = j, this.context = O, this.refs = E, this.updater = K || k;
    }
    var R = A.prototype = new N();
    R.constructor = A, x(R, _.prototype), R.isPureReactComponent = true;
    var I = Array.isArray;
    function T() {
    }
    var L = {
      H: null,
      A: null,
      T: null,
      S: null
    }, D = Object.prototype.hasOwnProperty;
    function H(j, O, K) {
      var W = K.ref;
      return {
        $$typeof: l,
        type: j,
        key: O,
        ref: W !== void 0 ? W : null,
        props: K
      };
    }
    function q(j, O) {
      return H(j.type, O, j.props);
    }
    function re(j) {
      return typeof j == "object" && j !== null && j.$$typeof === l;
    }
    function ee(j) {
      var O = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + j.replace(/[=:]/g, function(K) {
        return O[K];
      });
    }
    var de = /\/+/g;
    function ge(j, O) {
      return typeof j == "object" && j !== null && j.key != null ? ee("" + j.key) : O.toString(36);
    }
    function Ee(j) {
      switch (j.status) {
        case "fulfilled":
          return j.value;
        case "rejected":
          throw j.reason;
        default:
          switch (typeof j.status == "string" ? j.then(T, T) : (j.status = "pending", j.then(function(O) {
            j.status === "pending" && (j.status = "fulfilled", j.value = O);
          }, function(O) {
            j.status === "pending" && (j.status = "rejected", j.reason = O);
          })), j.status) {
            case "fulfilled":
              return j.value;
            case "rejected":
              throw j.reason;
          }
      }
      throw j;
    }
    function $(j, O, K, W, J) {
      var ie = typeof j;
      (ie === "undefined" || ie === "boolean") && (j = null);
      var pe = false;
      if (j === null) pe = true;
      else switch (ie) {
        case "bigint":
        case "string":
        case "number":
          pe = true;
          break;
        case "object":
          switch (j.$$typeof) {
            case l:
            case n:
              pe = true;
              break;
            case v:
              return pe = j._init, $(pe(j._payload), O, K, W, J);
          }
      }
      if (pe) return J = J(j), pe = W === "" ? "." + ge(j, 0) : W, I(J) ? (K = "", pe != null && (K = pe.replace(de, "$&/") + "/"), $(J, O, K, "", function(U) {
        return U;
      })) : J != null && (re(J) && (J = q(J, K + (J.key == null || j && j.key === J.key ? "" : ("" + J.key).replace(de, "$&/") + "/") + pe)), O.push(J)), 1;
      pe = 0;
      var Re = W === "" ? "." : W + ":";
      if (I(j)) for (var X = 0; X < j.length; X++) W = j[X], ie = Re + ge(W, X), pe += $(W, O, K, ie, J);
      else if (X = C(j), typeof X == "function") for (j = X.call(j), X = 0; !(W = j.next()).done; ) W = W.value, ie = Re + ge(W, X++), pe += $(W, O, K, ie, J);
      else if (ie === "object") {
        if (typeof j.then == "function") return $(Ee(j), O, K, W, J);
        throw O = String(j), Error("Objects are not valid as a React child (found: " + (O === "[object Object]" ? "object with keys {" + Object.keys(j).join(", ") + "}" : O) + "). If you meant to render a collection of children, use an array instead.");
      }
      return pe;
    }
    function F(j, O, K) {
      if (j == null) return j;
      var W = [], J = 0;
      return $(j, W, "", "", function(ie) {
        return O.call(K, ie, J++);
      }), W;
    }
    function fe(j) {
      if (j._status === -1) {
        var O = j._result;
        O = O(), O.then(function(K) {
          (j._status === 0 || j._status === -1) && (j._status = 1, j._result = K);
        }, function(K) {
          (j._status === 0 || j._status === -1) && (j._status = 2, j._result = K);
        }), j._status === -1 && (j._status = 0, j._result = O);
      }
      if (j._status === 1) return j._result.default;
      throw j._result;
    }
    var ye = typeof reportError == "function" ? reportError : function(j) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var O = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof j == "object" && j !== null && typeof j.message == "string" ? String(j.message) : String(j),
          error: j
        });
        if (!window.dispatchEvent(O)) return;
      } else if (typeof process == "object" && typeof process.emit == "function") {
        process.emit("uncaughtException", j);
        return;
      }
      console.error(j);
    }, ke = {
      map: F,
      forEach: function(j, O, K) {
        F(j, function() {
          O.apply(this, arguments);
        }, K);
      },
      count: function(j) {
        var O = 0;
        return F(j, function() {
          O++;
        }), O;
      },
      toArray: function(j) {
        return F(j, function(O) {
          return O;
        }) || [];
      },
      only: function(j) {
        if (!re(j)) throw Error("React.Children.only expected to receive a single React element child.");
        return j;
      }
    };
    return ze.Activity = b, ze.Children = ke, ze.Component = _, ze.Fragment = r, ze.Profiler = i, ze.PureComponent = A, ze.StrictMode = o, ze.Suspense = g, ze.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = L, ze.__COMPILER_RUNTIME = {
      __proto__: null,
      c: function(j) {
        return L.H.useMemoCache(j);
      }
    }, ze.cache = function(j) {
      return function() {
        return j.apply(null, arguments);
      };
    }, ze.cacheSignal = function() {
      return null;
    }, ze.cloneElement = function(j, O, K) {
      if (j == null) throw Error("The argument must be a React element, but you passed " + j + ".");
      var W = x({}, j.props), J = j.key;
      if (O != null) for (ie in O.key !== void 0 && (J = "" + O.key), O) !D.call(O, ie) || ie === "key" || ie === "__self" || ie === "__source" || ie === "ref" && O.ref === void 0 || (W[ie] = O[ie]);
      var ie = arguments.length - 2;
      if (ie === 1) W.children = K;
      else if (1 < ie) {
        for (var pe = Array(ie), Re = 0; Re < ie; Re++) pe[Re] = arguments[Re + 2];
        W.children = pe;
      }
      return H(j.type, J, W);
    }, ze.createContext = function(j) {
      return j = {
        $$typeof: d,
        _currentValue: j,
        _currentValue2: j,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      }, j.Provider = j, j.Consumer = {
        $$typeof: c,
        _context: j
      }, j;
    }, ze.createElement = function(j, O, K) {
      var W, J = {}, ie = null;
      if (O != null) for (W in O.key !== void 0 && (ie = "" + O.key), O) D.call(O, W) && W !== "key" && W !== "__self" && W !== "__source" && (J[W] = O[W]);
      var pe = arguments.length - 2;
      if (pe === 1) J.children = K;
      else if (1 < pe) {
        for (var Re = Array(pe), X = 0; X < pe; X++) Re[X] = arguments[X + 2];
        J.children = Re;
      }
      if (j && j.defaultProps) for (W in pe = j.defaultProps, pe) J[W] === void 0 && (J[W] = pe[W]);
      return H(j, ie, J);
    }, ze.createRef = function() {
      return {
        current: null
      };
    }, ze.forwardRef = function(j) {
      return {
        $$typeof: f,
        render: j
      };
    }, ze.isValidElement = re, ze.lazy = function(j) {
      return {
        $$typeof: v,
        _payload: {
          _status: -1,
          _result: j
        },
        _init: fe
      };
    }, ze.memo = function(j, O) {
      return {
        $$typeof: p,
        type: j,
        compare: O === void 0 ? null : O
      };
    }, ze.startTransition = function(j) {
      var O = L.T, K = {};
      L.T = K;
      try {
        var W = j(), J = L.S;
        J !== null && J(K, W), typeof W == "object" && W !== null && typeof W.then == "function" && W.then(T, ye);
      } catch (ie) {
        ye(ie);
      } finally {
        O !== null && K.types !== null && (O.types = K.types), L.T = O;
      }
    }, ze.unstable_useCacheRefresh = function() {
      return L.H.useCacheRefresh();
    }, ze.use = function(j) {
      return L.H.use(j);
    }, ze.useActionState = function(j, O, K) {
      return L.H.useActionState(j, O, K);
    }, ze.useCallback = function(j, O) {
      return L.H.useCallback(j, O);
    }, ze.useContext = function(j) {
      return L.H.useContext(j);
    }, ze.useDebugValue = function() {
    }, ze.useDeferredValue = function(j, O) {
      return L.H.useDeferredValue(j, O);
    }, ze.useEffect = function(j, O) {
      return L.H.useEffect(j, O);
    }, ze.useEffectEvent = function(j) {
      return L.H.useEffectEvent(j);
    }, ze.useId = function() {
      return L.H.useId();
    }, ze.useImperativeHandle = function(j, O, K) {
      return L.H.useImperativeHandle(j, O, K);
    }, ze.useInsertionEffect = function(j, O) {
      return L.H.useInsertionEffect(j, O);
    }, ze.useLayoutEffect = function(j, O) {
      return L.H.useLayoutEffect(j, O);
    }, ze.useMemo = function(j, O) {
      return L.H.useMemo(j, O);
    }, ze.useOptimistic = function(j, O) {
      return L.H.useOptimistic(j, O);
    }, ze.useReducer = function(j, O, K) {
      return L.H.useReducer(j, O, K);
    }, ze.useRef = function(j) {
      return L.H.useRef(j);
    }, ze.useState = function(j) {
      return L.H.useState(j);
    }, ze.useSyncExternalStore = function(j, O, K) {
      return L.H.useSyncExternalStore(j, O, K);
    }, ze.useTransition = function() {
      return L.H.useTransition();
    }, ze.version = "19.2.4", ze;
  }
  var uy;
  function th() {
    return uy || (uy = 1, jd.exports = nS()), jd.exports;
  }
  var m = th();
  const Xa = Fv(m), nh = Jw({
    __proto__: null,
    default: Xa
  }, [
    m
  ]);
  var Ld = {
    exports: {}
  }, Uo = {}, Rd = {
    exports: {}
  }, Ad = {};
  var dy;
  function lS() {
    return dy || (dy = 1, (function(l) {
      function n($, F) {
        var fe = $.length;
        $.push(F);
        e: for (; 0 < fe; ) {
          var ye = fe - 1 >>> 1, ke = $[ye];
          if (0 < i(ke, F)) $[ye] = F, $[fe] = ke, fe = ye;
          else break e;
        }
      }
      function r($) {
        return $.length === 0 ? null : $[0];
      }
      function o($) {
        if ($.length === 0) return null;
        var F = $[0], fe = $.pop();
        if (fe !== F) {
          $[0] = fe;
          e: for (var ye = 0, ke = $.length, j = ke >>> 1; ye < j; ) {
            var O = 2 * (ye + 1) - 1, K = $[O], W = O + 1, J = $[W];
            if (0 > i(K, fe)) W < ke && 0 > i(J, K) ? ($[ye] = J, $[W] = fe, ye = W) : ($[ye] = K, $[O] = fe, ye = O);
            else if (W < ke && 0 > i(J, fe)) $[ye] = J, $[W] = fe, ye = W;
            else break e;
          }
        }
        return F;
      }
      function i($, F) {
        var fe = $.sortIndex - F.sortIndex;
        return fe !== 0 ? fe : $.id - F.id;
      }
      if (l.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
        var c = performance;
        l.unstable_now = function() {
          return c.now();
        };
      } else {
        var d = Date, f = d.now();
        l.unstable_now = function() {
          return d.now() - f;
        };
      }
      var g = [], p = [], v = 1, b = null, S = 3, C = false, k = false, x = false, E = false, _ = typeof setTimeout == "function" ? setTimeout : null, N = typeof clearTimeout == "function" ? clearTimeout : null, A = typeof setImmediate < "u" ? setImmediate : null;
      function R($) {
        for (var F = r(p); F !== null; ) {
          if (F.callback === null) o(p);
          else if (F.startTime <= $) o(p), F.sortIndex = F.expirationTime, n(g, F);
          else break;
          F = r(p);
        }
      }
      function I($) {
        if (x = false, R($), !k) if (r(g) !== null) k = true, T || (T = true, ee());
        else {
          var F = r(p);
          F !== null && Ee(I, F.startTime - $);
        }
      }
      var T = false, L = -1, D = 5, H = -1;
      function q() {
        return E ? true : !(l.unstable_now() - H < D);
      }
      function re() {
        if (E = false, T) {
          var $ = l.unstable_now();
          H = $;
          var F = true;
          try {
            e: {
              k = false, x && (x = false, N(L), L = -1), C = true;
              var fe = S;
              try {
                t: {
                  for (R($), b = r(g); b !== null && !(b.expirationTime > $ && q()); ) {
                    var ye = b.callback;
                    if (typeof ye == "function") {
                      b.callback = null, S = b.priorityLevel;
                      var ke = ye(b.expirationTime <= $);
                      if ($ = l.unstable_now(), typeof ke == "function") {
                        b.callback = ke, R($), F = true;
                        break t;
                      }
                      b === r(g) && o(g), R($);
                    } else o(g);
                    b = r(g);
                  }
                  if (b !== null) F = true;
                  else {
                    var j = r(p);
                    j !== null && Ee(I, j.startTime - $), F = false;
                  }
                }
                break e;
              } finally {
                b = null, S = fe, C = false;
              }
              F = void 0;
            }
          } finally {
            F ? ee() : T = false;
          }
        }
      }
      var ee;
      if (typeof A == "function") ee = function() {
        A(re);
      };
      else if (typeof MessageChannel < "u") {
        var de = new MessageChannel(), ge = de.port2;
        de.port1.onmessage = re, ee = function() {
          ge.postMessage(null);
        };
      } else ee = function() {
        _(re, 0);
      };
      function Ee($, F) {
        L = _(function() {
          $(l.unstable_now());
        }, F);
      }
      l.unstable_IdlePriority = 5, l.unstable_ImmediatePriority = 1, l.unstable_LowPriority = 4, l.unstable_NormalPriority = 3, l.unstable_Profiling = null, l.unstable_UserBlockingPriority = 2, l.unstable_cancelCallback = function($) {
        $.callback = null;
      }, l.unstable_forceFrameRate = function($) {
        0 > $ || 125 < $ ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : D = 0 < $ ? Math.floor(1e3 / $) : 5;
      }, l.unstable_getCurrentPriorityLevel = function() {
        return S;
      }, l.unstable_next = function($) {
        switch (S) {
          case 1:
          case 2:
          case 3:
            var F = 3;
            break;
          default:
            F = S;
        }
        var fe = S;
        S = F;
        try {
          return $();
        } finally {
          S = fe;
        }
      }, l.unstable_requestPaint = function() {
        E = true;
      }, l.unstable_runWithPriority = function($, F) {
        switch ($) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            $ = 3;
        }
        var fe = S;
        S = $;
        try {
          return F();
        } finally {
          S = fe;
        }
      }, l.unstable_scheduleCallback = function($, F, fe) {
        var ye = l.unstable_now();
        switch (typeof fe == "object" && fe !== null ? (fe = fe.delay, fe = typeof fe == "number" && 0 < fe ? ye + fe : ye) : fe = ye, $) {
          case 1:
            var ke = -1;
            break;
          case 2:
            ke = 250;
            break;
          case 5:
            ke = 1073741823;
            break;
          case 4:
            ke = 1e4;
            break;
          default:
            ke = 5e3;
        }
        return ke = fe + ke, $ = {
          id: v++,
          callback: F,
          priorityLevel: $,
          startTime: fe,
          expirationTime: ke,
          sortIndex: -1
        }, fe > ye ? ($.sortIndex = fe, n(p, $), r(g) === null && $ === r(p) && (x ? (N(L), L = -1) : x = true, Ee(I, fe - ye))) : ($.sortIndex = ke, n(g, $), k || C || (k = true, T || (T = true, ee()))), $;
      }, l.unstable_shouldYield = q, l.unstable_wrapCallback = function($) {
        var F = S;
        return function() {
          var fe = S;
          S = F;
          try {
            return $.apply(this, arguments);
          } finally {
            S = fe;
          }
        };
      };
    })(Ad)), Ad;
  }
  var fy;
  function rS() {
    return fy || (fy = 1, Rd.exports = lS()), Rd.exports;
  }
  var Td = {
    exports: {}
  }, tn = {};
  var hy;
  function aS() {
    if (hy) return tn;
    hy = 1;
    var l = th();
    function n(g) {
      var p = "https://react.dev/errors/" + g;
      if (1 < arguments.length) {
        p += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var v = 2; v < arguments.length; v++) p += "&args[]=" + encodeURIComponent(arguments[v]);
      }
      return "Minified React error #" + g + "; visit " + p + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function r() {
    }
    var o = {
      d: {
        f: r,
        r: function() {
          throw Error(n(522));
        },
        D: r,
        C: r,
        L: r,
        m: r,
        X: r,
        S: r,
        M: r
      },
      p: 0,
      findDOMNode: null
    }, i = Symbol.for("react.portal");
    function c(g, p, v) {
      var b = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return {
        $$typeof: i,
        key: b == null ? null : "" + b,
        children: g,
        containerInfo: p,
        implementation: v
      };
    }
    var d = l.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function f(g, p) {
      if (g === "font") return "";
      if (typeof p == "string") return p === "use-credentials" ? p : "";
    }
    return tn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = o, tn.createPortal = function(g, p) {
      var v = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!p || p.nodeType !== 1 && p.nodeType !== 9 && p.nodeType !== 11) throw Error(n(299));
      return c(g, p, null, v);
    }, tn.flushSync = function(g) {
      var p = d.T, v = o.p;
      try {
        if (d.T = null, o.p = 2, g) return g();
      } finally {
        d.T = p, o.p = v, o.d.f();
      }
    }, tn.preconnect = function(g, p) {
      typeof g == "string" && (p ? (p = p.crossOrigin, p = typeof p == "string" ? p === "use-credentials" ? p : "" : void 0) : p = null, o.d.C(g, p));
    }, tn.prefetchDNS = function(g) {
      typeof g == "string" && o.d.D(g);
    }, tn.preinit = function(g, p) {
      if (typeof g == "string" && p && typeof p.as == "string") {
        var v = p.as, b = f(v, p.crossOrigin), S = typeof p.integrity == "string" ? p.integrity : void 0, C = typeof p.fetchPriority == "string" ? p.fetchPriority : void 0;
        v === "style" ? o.d.S(g, typeof p.precedence == "string" ? p.precedence : void 0, {
          crossOrigin: b,
          integrity: S,
          fetchPriority: C
        }) : v === "script" && o.d.X(g, {
          crossOrigin: b,
          integrity: S,
          fetchPriority: C,
          nonce: typeof p.nonce == "string" ? p.nonce : void 0
        });
      }
    }, tn.preinitModule = function(g, p) {
      if (typeof g == "string") if (typeof p == "object" && p !== null) {
        if (p.as == null || p.as === "script") {
          var v = f(p.as, p.crossOrigin);
          o.d.M(g, {
            crossOrigin: v,
            integrity: typeof p.integrity == "string" ? p.integrity : void 0,
            nonce: typeof p.nonce == "string" ? p.nonce : void 0
          });
        }
      } else p == null && o.d.M(g);
    }, tn.preload = function(g, p) {
      if (typeof g == "string" && typeof p == "object" && p !== null && typeof p.as == "string") {
        var v = p.as, b = f(v, p.crossOrigin);
        o.d.L(g, v, {
          crossOrigin: b,
          integrity: typeof p.integrity == "string" ? p.integrity : void 0,
          nonce: typeof p.nonce == "string" ? p.nonce : void 0,
          type: typeof p.type == "string" ? p.type : void 0,
          fetchPriority: typeof p.fetchPriority == "string" ? p.fetchPriority : void 0,
          referrerPolicy: typeof p.referrerPolicy == "string" ? p.referrerPolicy : void 0,
          imageSrcSet: typeof p.imageSrcSet == "string" ? p.imageSrcSet : void 0,
          imageSizes: typeof p.imageSizes == "string" ? p.imageSizes : void 0,
          media: typeof p.media == "string" ? p.media : void 0
        });
      }
    }, tn.preloadModule = function(g, p) {
      if (typeof g == "string") if (p) {
        var v = f(p.as, p.crossOrigin);
        o.d.m(g, {
          as: typeof p.as == "string" && p.as !== "script" ? p.as : void 0,
          crossOrigin: v,
          integrity: typeof p.integrity == "string" ? p.integrity : void 0
        });
      } else o.d.m(g);
    }, tn.requestFormReset = function(g) {
      o.d.r(g);
    }, tn.unstable_batchedUpdates = function(g, p) {
      return g(p);
    }, tn.useFormState = function(g, p, v) {
      return d.H.useFormState(g, p, v);
    }, tn.useFormStatus = function() {
      return d.H.useHostTransitionStatus();
    }, tn.version = "19.2.4", tn;
  }
  var my;
  function Qv() {
    if (my) return Td.exports;
    my = 1;
    function l() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(l);
      } catch (n) {
        console.error(n);
      }
    }
    return l(), Td.exports = aS(), Td.exports;
  }
  var gy;
  function oS() {
    if (gy) return Uo;
    gy = 1;
    var l = rS(), n = th(), r = Qv();
    function o(e) {
      var t = "https://react.dev/errors/" + e;
      if (1 < arguments.length) {
        t += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var a = 2; a < arguments.length; a++) t += "&args[]=" + encodeURIComponent(arguments[a]);
      }
      return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function i(e) {
      return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
    }
    function c(e) {
      var t = e, a = e;
      if (e.alternate) for (; t.return; ) t = t.return;
      else {
        e = t;
        do
          t = e, (t.flags & 4098) !== 0 && (a = t.return), e = t.return;
        while (e);
      }
      return t.tag === 3 ? a : null;
    }
    function d(e) {
      if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
      }
      return null;
    }
    function f(e) {
      if (e.tag === 31) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
      }
      return null;
    }
    function g(e) {
      if (c(e) !== e) throw Error(o(188));
    }
    function p(e) {
      var t = e.alternate;
      if (!t) {
        if (t = c(e), t === null) throw Error(o(188));
        return t !== e ? null : e;
      }
      for (var a = e, s = t; ; ) {
        var u = a.return;
        if (u === null) break;
        var h = u.alternate;
        if (h === null) {
          if (s = u.return, s !== null) {
            a = s;
            continue;
          }
          break;
        }
        if (u.child === h.child) {
          for (h = u.child; h; ) {
            if (h === a) return g(u), e;
            if (h === s) return g(u), t;
            h = h.sibling;
          }
          throw Error(o(188));
        }
        if (a.return !== s.return) a = u, s = h;
        else {
          for (var w = false, M = u.child; M; ) {
            if (M === a) {
              w = true, a = u, s = h;
              break;
            }
            if (M === s) {
              w = true, s = u, a = h;
              break;
            }
            M = M.sibling;
          }
          if (!w) {
            for (M = h.child; M; ) {
              if (M === a) {
                w = true, a = h, s = u;
                break;
              }
              if (M === s) {
                w = true, s = h, a = u;
                break;
              }
              M = M.sibling;
            }
            if (!w) throw Error(o(189));
          }
        }
        if (a.alternate !== s) throw Error(o(190));
      }
      if (a.tag !== 3) throw Error(o(188));
      return a.stateNode.current === a ? e : t;
    }
    function v(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e;
      for (e = e.child; e !== null; ) {
        if (t = v(e), t !== null) return t;
        e = e.sibling;
      }
      return null;
    }
    var b = Object.assign, S = Symbol.for("react.element"), C = Symbol.for("react.transitional.element"), k = Symbol.for("react.portal"), x = Symbol.for("react.fragment"), E = Symbol.for("react.strict_mode"), _ = Symbol.for("react.profiler"), N = Symbol.for("react.consumer"), A = Symbol.for("react.context"), R = Symbol.for("react.forward_ref"), I = Symbol.for("react.suspense"), T = Symbol.for("react.suspense_list"), L = Symbol.for("react.memo"), D = Symbol.for("react.lazy"), H = Symbol.for("react.activity"), q = Symbol.for("react.memo_cache_sentinel"), re = Symbol.iterator;
    function ee(e) {
      return e === null || typeof e != "object" ? null : (e = re && e[re] || e["@@iterator"], typeof e == "function" ? e : null);
    }
    var de = Symbol.for("react.client.reference");
    function ge(e) {
      if (e == null) return null;
      if (typeof e == "function") return e.$$typeof === de ? null : e.displayName || e.name || null;
      if (typeof e == "string") return e;
      switch (e) {
        case x:
          return "Fragment";
        case _:
          return "Profiler";
        case E:
          return "StrictMode";
        case I:
          return "Suspense";
        case T:
          return "SuspenseList";
        case H:
          return "Activity";
      }
      if (typeof e == "object") switch (e.$$typeof) {
        case k:
          return "Portal";
        case A:
          return e.displayName || "Context";
        case N:
          return (e._context.displayName || "Context") + ".Consumer";
        case R:
          var t = e.render;
          return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case L:
          return t = e.displayName || null, t !== null ? t : ge(e.type) || "Memo";
        case D:
          t = e._payload, e = e._init;
          try {
            return ge(e(t));
          } catch {
          }
      }
      return null;
    }
    var Ee = Array.isArray, $ = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, F = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, fe = {
      pending: false,
      data: null,
      method: null,
      action: null
    }, ye = [], ke = -1;
    function j(e) {
      return {
        current: e
      };
    }
    function O(e) {
      0 > ke || (e.current = ye[ke], ye[ke] = null, ke--);
    }
    function K(e, t) {
      ke++, ye[ke] = e.current, e.current = t;
    }
    var W = j(null), J = j(null), ie = j(null), pe = j(null);
    function Re(e, t) {
      switch (K(ie, t), K(J, e), K(W, null), t.nodeType) {
        case 9:
        case 11:
          e = (e = t.documentElement) && (e = e.namespaceURI) ? Rp(e) : 0;
          break;
        default:
          if (e = t.tagName, t = t.namespaceURI) t = Rp(t), e = Ap(t, e);
          else switch (e) {
            case "svg":
              e = 1;
              break;
            case "math":
              e = 2;
              break;
            default:
              e = 0;
          }
      }
      O(W), K(W, e);
    }
    function X() {
      O(W), O(J), O(ie);
    }
    function U(e) {
      e.memoizedState !== null && K(pe, e);
      var t = W.current, a = Ap(t, e.type);
      t !== a && (K(J, e), K(W, a));
    }
    function te(e) {
      J.current === e && (O(W), O(J)), pe.current === e && (O(pe), Oo._currentValue = fe);
    }
    var he, be;
    function we(e) {
      if (he === void 0) try {
        throw Error();
      } catch (a) {
        var t = a.stack.trim().match(/\n( *(at )?)/);
        he = t && t[1] || "", be = -1 < a.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < a.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
      return `
` + he + e + be;
    }
    var je = false;
    function Xe(e, t) {
      if (!e || je) return "";
      je = true;
      var a = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var s = {
          DetermineComponentFrameRoot: function() {
            try {
              if (t) {
                var oe = function() {
                  throw Error();
                };
                if (Object.defineProperty(oe.prototype, "props", {
                  set: function() {
                    throw Error();
                  }
                }), typeof Reflect == "object" && Reflect.construct) {
                  try {
                    Reflect.construct(oe, []);
                  } catch (Q) {
                    var Z = Q;
                  }
                  Reflect.construct(e, [], oe);
                } else {
                  try {
                    oe.call();
                  } catch (Q) {
                    Z = Q;
                  }
                  e.call(oe.prototype);
                }
              } else {
                try {
                  throw Error();
                } catch (Q) {
                  Z = Q;
                }
                (oe = e()) && typeof oe.catch == "function" && oe.catch(function() {
                });
              }
            } catch (Q) {
              if (Q && Z && typeof Q.stack == "string") return [
                Q.stack,
                Z.stack
              ];
            }
            return [
              null,
              null
            ];
          }
        };
        s.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
        var u = Object.getOwnPropertyDescriptor(s.DetermineComponentFrameRoot, "name");
        u && u.configurable && Object.defineProperty(s.DetermineComponentFrameRoot, "name", {
          value: "DetermineComponentFrameRoot"
        });
        var h = s.DetermineComponentFrameRoot(), w = h[0], M = h[1];
        if (w && M) {
          var z = w.split(`
`), P = M.split(`
`);
          for (u = s = 0; s < z.length && !z[s].includes("DetermineComponentFrameRoot"); ) s++;
          for (; u < P.length && !P[u].includes("DetermineComponentFrameRoot"); ) u++;
          if (s === z.length || u === P.length) for (s = z.length - 1, u = P.length - 1; 1 <= s && 0 <= u && z[s] !== P[u]; ) u--;
          for (; 1 <= s && 0 <= u; s--, u--) if (z[s] !== P[u]) {
            if (s !== 1 || u !== 1) do
              if (s--, u--, 0 > u || z[s] !== P[u]) {
                var ne = `
` + z[s].replace(" at new ", " at ");
                return e.displayName && ne.includes("<anonymous>") && (ne = ne.replace("<anonymous>", e.displayName)), ne;
              }
            while (1 <= s && 0 <= u);
            break;
          }
        }
      } finally {
        je = false, Error.prepareStackTrace = a;
      }
      return (a = e ? e.displayName || e.name : "") ? we(a) : "";
    }
    function We(e, t) {
      switch (e.tag) {
        case 26:
        case 27:
        case 5:
          return we(e.type);
        case 16:
          return we("Lazy");
        case 13:
          return e.child !== t && t !== null ? we("Suspense Fallback") : we("Suspense");
        case 19:
          return we("SuspenseList");
        case 0:
        case 15:
          return Xe(e.type, false);
        case 11:
          return Xe(e.type.render, false);
        case 1:
          return Xe(e.type, true);
        case 31:
          return we("Activity");
        default:
          return "";
      }
    }
    function Ce(e) {
      try {
        var t = "", a = null;
        do
          t += We(e, a), a = e, e = e.return;
        while (e);
        return t;
      } catch (s) {
        return `
Error generating stack: ` + s.message + `
` + s.stack;
      }
    }
    var Ne = Object.prototype.hasOwnProperty, Ae = l.unstable_scheduleCallback, Ie = l.unstable_cancelCallback, $e = l.unstable_shouldYield, vt = l.unstable_requestPaint, Ke = l.unstable_now, an = l.unstable_getCurrentPriorityLevel, un = l.unstable_ImmediatePriority, Wn = l.unstable_UserBlockingPriority, Dl = l.unstable_NormalPriority, zl = l.unstable_LowPriority, lt = l.unstable_IdlePriority, Mt = l.log, on = l.unstable_setDisableYieldValue, en = null, xt = null;
    function Vt(e) {
      if (typeof Mt == "function" && on(e), xt && typeof xt.setStrictMode == "function") try {
        xt.setStrictMode(en, e);
      } catch {
      }
    }
    var jt = Math.clz32 ? Math.clz32 : Qr, Sr = Math.log, Hl = Math.LN2;
    function Qr(e) {
      return e >>>= 0, e === 0 ? 32 : 31 - (Sr(e) / Hl | 0) | 0;
    }
    var fl = 256, Wr = 262144, Jr = 4194304;
    function Ln(e) {
      var t = e & 42;
      if (t !== 0) return t;
      switch (e & -e) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return e & 261888;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return e & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return e;
      }
    }
    function Ul(e, t, a) {
      var s = e.pendingLanes;
      if (s === 0) return 0;
      var u = 0, h = e.suspendedLanes, w = e.pingedLanes;
      e = e.warmLanes;
      var M = s & 134217727;
      return M !== 0 ? (s = M & ~h, s !== 0 ? u = Ln(s) : (w &= M, w !== 0 ? u = Ln(w) : a || (a = M & ~e, a !== 0 && (u = Ln(a))))) : (M = s & ~h, M !== 0 ? u = Ln(M) : w !== 0 ? u = Ln(w) : a || (a = s & ~e, a !== 0 && (u = Ln(a)))), u === 0 ? 0 : t !== 0 && t !== u && (t & h) === 0 && (h = u & -u, a = t & -t, h >= a || h === 32 && (a & 4194048) !== 0) ? t : u;
    }
    function hl(e, t) {
      return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
    }
    function ps(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return t + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function ea() {
      var e = Jr;
      return Jr <<= 1, (Jr & 62914560) === 0 && (Jr = 4194304), e;
    }
    function Cr(e) {
      for (var t = [], a = 0; 31 > a; a++) t.push(e);
      return t;
    }
    function Er(e, t) {
      e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
    }
    function Jn(e, t, a, s, u, h) {
      var w = e.pendingLanes;
      e.pendingLanes = a, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= a, e.entangledLanes &= a, e.errorRecoveryDisabledLanes &= a, e.shellSuspendCounter = 0;
      var M = e.entanglements, z = e.expirationTimes, P = e.hiddenUpdates;
      for (a = w & ~a; 0 < a; ) {
        var ne = 31 - jt(a), oe = 1 << ne;
        M[ne] = 0, z[ne] = -1;
        var Z = P[ne];
        if (Z !== null) for (P[ne] = null, ne = 0; ne < Z.length; ne++) {
          var Q = Z[ne];
          Q !== null && (Q.lane &= -536870913);
        }
        a &= ~oe;
      }
      s !== 0 && ys(e, s, 0), h !== 0 && u === 0 && e.tag !== 0 && (e.suspendedLanes |= h & ~(w & ~t));
    }
    function ys(e, t, a) {
      e.pendingLanes |= t, e.suspendedLanes &= ~t;
      var s = 31 - jt(t);
      e.entangledLanes |= t, e.entanglements[s] = e.entanglements[s] | 1073741824 | a & 261930;
    }
    function bs(e, t) {
      var a = e.entangledLanes |= t;
      for (e = e.entanglements; a; ) {
        var s = 31 - jt(a), u = 1 << s;
        u & t | e[s] & t && (e[s] |= t), a &= ~u;
      }
    }
    function vs(e, t) {
      var a = t & -t;
      return a = (a & 42) !== 0 ? 1 : el(a), (a & (e.suspendedLanes | t)) !== 0 ? 0 : a;
    }
    function el(e) {
      switch (e) {
        case 2:
          e = 1;
          break;
        case 8:
          e = 4;
          break;
        case 32:
          e = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          e = 128;
          break;
        case 268435456:
          e = 134217728;
          break;
        default:
          e = 0;
      }
      return e;
    }
    function Ka(e) {
      return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
    }
    function tl() {
      var e = F.p;
      return e !== 0 ? e : (e = window.event, e === void 0 ? 32 : ey(e.type));
    }
    function _r(e, t) {
      var a = F.p;
      try {
        return F.p = e, t();
      } finally {
        F.p = a;
      }
    }
    var ml = Math.random().toString(36).slice(2), $t = "__reactFiber$" + ml, le = "__reactProps$" + ml, De = "__reactContainer$" + ml, Lt = "__reactEvents$" + ml, at = "__reactListeners$" + ml, kt = "__reactHandles$" + ml, bt = "__reactResources$" + ml, ot = "__reactMarker$" + ml;
    function gt(e) {
      delete e[$t], delete e[le], delete e[Lt], delete e[at], delete e[kt];
    }
    function Tt(e) {
      var t = e[$t];
      if (t) return t;
      for (var a = e.parentNode; a; ) {
        if (t = a[De] || a[$t]) {
          if (a = t.alternate, t.child !== null || a !== null && a.child !== null) for (e = Hp(e); e !== null; ) {
            if (a = e[$t]) return a;
            e = Hp(e);
          }
          return t;
        }
        e = a, a = e.parentNode;
      }
      return null;
    }
    function Je(e) {
      if (e = e[$t] || e[De]) {
        var t = e.tag;
        if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e;
      }
      return null;
    }
    function Pt(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
      throw Error(o(33));
    }
    function Dt(e) {
      var t = e[bt];
      return t || (t = e[bt] = {
        hoistableStyles: /* @__PURE__ */ new Map(),
        hoistableScripts: /* @__PURE__ */ new Map()
      }), t;
    }
    function it(e) {
      e[ot] = true;
    }
    var nl = /* @__PURE__ */ new Set(), ll = {};
    function vn(e, t) {
      $n(e, t), $n(e + "Capture", t);
    }
    function $n(e, t) {
      for (ll[e] = t, e = 0; e < t.length; e++) nl.add(t[e]);
    }
    var ta = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), Yl = {}, kr = {};
    function Bl(e) {
      return Ne.call(kr, e) ? true : Ne.call(Yl, e) ? false : ta.test(e) ? kr[e] = true : (Yl[e] = true, false);
    }
    function rl(e, t, a) {
      if (Bl(t)) if (a === null) e.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
            e.removeAttribute(t);
            return;
          case "boolean":
            var s = t.toLowerCase().slice(0, 5);
            if (s !== "data-" && s !== "aria-") {
              e.removeAttribute(t);
              return;
            }
        }
        e.setAttribute(t, "" + a);
      }
    }
    function Xl(e, t, a) {
      if (a === null) e.removeAttribute(t);
      else {
        switch (typeof a) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            e.removeAttribute(t);
            return;
        }
        e.setAttribute(t, "" + a);
      }
    }
    function dn(e, t, a, s) {
      if (s === null) e.removeAttribute(a);
      else {
        switch (typeof s) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            e.removeAttribute(a);
            return;
        }
        e.setAttributeNS(t, a, "" + s);
      }
    }
    function Zt(e) {
      switch (typeof e) {
        case "bigint":
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return e;
        case "object":
          return e;
        default:
          return "";
      }
    }
    function xs(e) {
      var t = e.type;
      return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
    }
    function xc(e, t, a) {
      var s = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
      if (!e.hasOwnProperty(t) && typeof s < "u" && typeof s.get == "function" && typeof s.set == "function") {
        var u = s.get, h = s.set;
        return Object.defineProperty(e, t, {
          configurable: true,
          get: function() {
            return u.call(this);
          },
          set: function(w) {
            a = "" + w, h.call(this, w);
          }
        }), Object.defineProperty(e, t, {
          enumerable: s.enumerable
        }), {
          getValue: function() {
            return a;
          },
          setValue: function(w) {
            a = "" + w;
          },
          stopTracking: function() {
            e._valueTracker = null, delete e[t];
          }
        };
      }
    }
    function na(e) {
      if (!e._valueTracker) {
        var t = xs(e) ? "checked" : "value";
        e._valueTracker = xc(e, t, "" + e[t]);
      }
    }
    function Za(e) {
      if (!e) return false;
      var t = e._valueTracker;
      if (!t) return true;
      var a = t.getValue(), s = "";
      return e && (s = xs(e) ? e.checked ? "true" : "false" : e.value), e = s, e !== a ? (t.setValue(e), true) : false;
    }
    function ws(e) {
      if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
      try {
        return e.activeElement || e.body;
      } catch {
        return e.body;
      }
    }
    var P1 = /[\n"\\]/g;
    function Rn(e) {
      return e.replace(P1, function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      });
    }
    function wc(e, t, a, s, u, h, w, M) {
      e.name = "", w != null && typeof w != "function" && typeof w != "symbol" && typeof w != "boolean" ? e.type = w : e.removeAttribute("type"), t != null ? w === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + Zt(t)) : e.value !== "" + Zt(t) && (e.value = "" + Zt(t)) : w !== "submit" && w !== "reset" || e.removeAttribute("value"), t != null ? Sc(e, w, Zt(t)) : a != null ? Sc(e, w, Zt(a)) : s != null && e.removeAttribute("value"), u == null && h != null && (e.defaultChecked = !!h), u != null && (e.checked = u && typeof u != "function" && typeof u != "symbol"), M != null && typeof M != "function" && typeof M != "symbol" && typeof M != "boolean" ? e.name = "" + Zt(M) : e.removeAttribute("name");
    }
    function Eh(e, t, a, s, u, h, w, M) {
      if (h != null && typeof h != "function" && typeof h != "symbol" && typeof h != "boolean" && (e.type = h), t != null || a != null) {
        if (!(h !== "submit" && h !== "reset" || t != null)) {
          na(e);
          return;
        }
        a = a != null ? "" + Zt(a) : "", t = t != null ? "" + Zt(t) : a, M || t === e.value || (e.value = t), e.defaultValue = t;
      }
      s = s ?? u, s = typeof s != "function" && typeof s != "symbol" && !!s, e.checked = M ? e.checked : !!s, e.defaultChecked = !!s, w != null && typeof w != "function" && typeof w != "symbol" && typeof w != "boolean" && (e.name = w), na(e);
    }
    function Sc(e, t, a) {
      t === "number" && ws(e.ownerDocument) === e || e.defaultValue === "" + a || (e.defaultValue = "" + a);
    }
    function la(e, t, a, s) {
      if (e = e.options, t) {
        t = {};
        for (var u = 0; u < a.length; u++) t["$" + a[u]] = true;
        for (a = 0; a < e.length; a++) u = t.hasOwnProperty("$" + e[a].value), e[a].selected !== u && (e[a].selected = u), u && s && (e[a].defaultSelected = true);
      } else {
        for (a = "" + Zt(a), t = null, u = 0; u < e.length; u++) {
          if (e[u].value === a) {
            e[u].selected = true, s && (e[u].defaultSelected = true);
            return;
          }
          t !== null || e[u].disabled || (t = e[u]);
        }
        t !== null && (t.selected = true);
      }
    }
    function _h(e, t, a) {
      if (t != null && (t = "" + Zt(t), t !== e.value && (e.value = t), a == null)) {
        e.defaultValue !== t && (e.defaultValue = t);
        return;
      }
      e.defaultValue = a != null ? "" + Zt(a) : "";
    }
    function kh(e, t, a, s) {
      if (t == null) {
        if (s != null) {
          if (a != null) throw Error(o(92));
          if (Ee(s)) {
            if (1 < s.length) throw Error(o(93));
            s = s[0];
          }
          a = s;
        }
        a == null && (a = ""), t = a;
      }
      a = Zt(t), e.defaultValue = a, s = e.textContent, s === a && s !== "" && s !== null && (e.value = s), na(e);
    }
    function ra(e, t) {
      if (t) {
        var a = e.firstChild;
        if (a && a === e.lastChild && a.nodeType === 3) {
          a.nodeValue = t;
          return;
        }
      }
      e.textContent = t;
    }
    var K1 = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
    function Mh(e, t, a) {
      var s = t.indexOf("--") === 0;
      a == null || typeof a == "boolean" || a === "" ? s ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : s ? e.setProperty(t, a) : typeof a != "number" || a === 0 || K1.has(t) ? t === "float" ? e.cssFloat = a : e[t] = ("" + a).trim() : e[t] = a + "px";
    }
    function jh(e, t, a) {
      if (t != null && typeof t != "object") throw Error(o(62));
      if (e = e.style, a != null) {
        for (var s in a) !a.hasOwnProperty(s) || t != null && t.hasOwnProperty(s) || (s.indexOf("--") === 0 ? e.setProperty(s, "") : s === "float" ? e.cssFloat = "" : e[s] = "");
        for (var u in t) s = t[u], t.hasOwnProperty(u) && a[u] !== s && Mh(e, u, s);
      } else for (var h in t) t.hasOwnProperty(h) && Mh(e, h, t[h]);
    }
    function Cc(e) {
      if (e.indexOf("-") === -1) return false;
      switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var Z1 = /* @__PURE__ */ new Map([
      [
        "acceptCharset",
        "accept-charset"
      ],
      [
        "htmlFor",
        "for"
      ],
      [
        "httpEquiv",
        "http-equiv"
      ],
      [
        "crossOrigin",
        "crossorigin"
      ],
      [
        "accentHeight",
        "accent-height"
      ],
      [
        "alignmentBaseline",
        "alignment-baseline"
      ],
      [
        "arabicForm",
        "arabic-form"
      ],
      [
        "baselineShift",
        "baseline-shift"
      ],
      [
        "capHeight",
        "cap-height"
      ],
      [
        "clipPath",
        "clip-path"
      ],
      [
        "clipRule",
        "clip-rule"
      ],
      [
        "colorInterpolation",
        "color-interpolation"
      ],
      [
        "colorInterpolationFilters",
        "color-interpolation-filters"
      ],
      [
        "colorProfile",
        "color-profile"
      ],
      [
        "colorRendering",
        "color-rendering"
      ],
      [
        "dominantBaseline",
        "dominant-baseline"
      ],
      [
        "enableBackground",
        "enable-background"
      ],
      [
        "fillOpacity",
        "fill-opacity"
      ],
      [
        "fillRule",
        "fill-rule"
      ],
      [
        "floodColor",
        "flood-color"
      ],
      [
        "floodOpacity",
        "flood-opacity"
      ],
      [
        "fontFamily",
        "font-family"
      ],
      [
        "fontSize",
        "font-size"
      ],
      [
        "fontSizeAdjust",
        "font-size-adjust"
      ],
      [
        "fontStretch",
        "font-stretch"
      ],
      [
        "fontStyle",
        "font-style"
      ],
      [
        "fontVariant",
        "font-variant"
      ],
      [
        "fontWeight",
        "font-weight"
      ],
      [
        "glyphName",
        "glyph-name"
      ],
      [
        "glyphOrientationHorizontal",
        "glyph-orientation-horizontal"
      ],
      [
        "glyphOrientationVertical",
        "glyph-orientation-vertical"
      ],
      [
        "horizAdvX",
        "horiz-adv-x"
      ],
      [
        "horizOriginX",
        "horiz-origin-x"
      ],
      [
        "imageRendering",
        "image-rendering"
      ],
      [
        "letterSpacing",
        "letter-spacing"
      ],
      [
        "lightingColor",
        "lighting-color"
      ],
      [
        "markerEnd",
        "marker-end"
      ],
      [
        "markerMid",
        "marker-mid"
      ],
      [
        "markerStart",
        "marker-start"
      ],
      [
        "overlinePosition",
        "overline-position"
      ],
      [
        "overlineThickness",
        "overline-thickness"
      ],
      [
        "paintOrder",
        "paint-order"
      ],
      [
        "panose-1",
        "panose-1"
      ],
      [
        "pointerEvents",
        "pointer-events"
      ],
      [
        "renderingIntent",
        "rendering-intent"
      ],
      [
        "shapeRendering",
        "shape-rendering"
      ],
      [
        "stopColor",
        "stop-color"
      ],
      [
        "stopOpacity",
        "stop-opacity"
      ],
      [
        "strikethroughPosition",
        "strikethrough-position"
      ],
      [
        "strikethroughThickness",
        "strikethrough-thickness"
      ],
      [
        "strokeDasharray",
        "stroke-dasharray"
      ],
      [
        "strokeDashoffset",
        "stroke-dashoffset"
      ],
      [
        "strokeLinecap",
        "stroke-linecap"
      ],
      [
        "strokeLinejoin",
        "stroke-linejoin"
      ],
      [
        "strokeMiterlimit",
        "stroke-miterlimit"
      ],
      [
        "strokeOpacity",
        "stroke-opacity"
      ],
      [
        "strokeWidth",
        "stroke-width"
      ],
      [
        "textAnchor",
        "text-anchor"
      ],
      [
        "textDecoration",
        "text-decoration"
      ],
      [
        "textRendering",
        "text-rendering"
      ],
      [
        "transformOrigin",
        "transform-origin"
      ],
      [
        "underlinePosition",
        "underline-position"
      ],
      [
        "underlineThickness",
        "underline-thickness"
      ],
      [
        "unicodeBidi",
        "unicode-bidi"
      ],
      [
        "unicodeRange",
        "unicode-range"
      ],
      [
        "unitsPerEm",
        "units-per-em"
      ],
      [
        "vAlphabetic",
        "v-alphabetic"
      ],
      [
        "vHanging",
        "v-hanging"
      ],
      [
        "vIdeographic",
        "v-ideographic"
      ],
      [
        "vMathematical",
        "v-mathematical"
      ],
      [
        "vectorEffect",
        "vector-effect"
      ],
      [
        "vertAdvY",
        "vert-adv-y"
      ],
      [
        "vertOriginX",
        "vert-origin-x"
      ],
      [
        "vertOriginY",
        "vert-origin-y"
      ],
      [
        "wordSpacing",
        "word-spacing"
      ],
      [
        "writingMode",
        "writing-mode"
      ],
      [
        "xmlnsXlink",
        "xmlns:xlink"
      ],
      [
        "xHeight",
        "x-height"
      ]
    ]), F1 = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function Ss(e) {
      return F1.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
    }
    function gl() {
    }
    var Ec = null;
    function _c(e) {
      return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
    }
    var aa = null, oa = null;
    function Lh(e) {
      var t = Je(e);
      if (t && (e = t.stateNode)) {
        var a = e[le] || null;
        e: switch (e = t.stateNode, t.type) {
          case "input":
            if (wc(e, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name), t = a.name, a.type === "radio" && t != null) {
              for (a = e; a.parentNode; ) a = a.parentNode;
              for (a = a.querySelectorAll('input[name="' + Rn("" + t) + '"][type="radio"]'), t = 0; t < a.length; t++) {
                var s = a[t];
                if (s !== e && s.form === e.form) {
                  var u = s[le] || null;
                  if (!u) throw Error(o(90));
                  wc(s, u.value, u.defaultValue, u.defaultValue, u.checked, u.defaultChecked, u.type, u.name);
                }
              }
              for (t = 0; t < a.length; t++) s = a[t], s.form === e.form && Za(s);
            }
            break e;
          case "textarea":
            _h(e, a.value, a.defaultValue);
            break e;
          case "select":
            t = a.value, t != null && la(e, !!a.multiple, t, false);
        }
      }
    }
    var kc = false;
    function Rh(e, t, a) {
      if (kc) return e(t, a);
      kc = true;
      try {
        var s = e(t);
        return s;
      } finally {
        if (kc = false, (aa !== null || oa !== null) && (ci(), aa && (t = aa, e = oa, oa = aa = null, Lh(t), e))) for (t = 0; t < e.length; t++) Lh(e[t]);
      }
    }
    function Fa(e, t) {
      var a = e.stateNode;
      if (a === null) return null;
      var s = a[le] || null;
      if (s === null) return null;
      a = s[t];
      e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (s = !s.disabled) || (e = e.type, s = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !s;
          break e;
        default:
          e = false;
      }
      if (e) return null;
      if (a && typeof a != "function") throw Error(o(231, t, typeof a));
      return a;
    }
    var pl = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Mc = false;
    if (pl) try {
      var Qa = {};
      Object.defineProperty(Qa, "passive", {
        get: function() {
          Mc = true;
        }
      }), window.addEventListener("test", Qa, Qa), window.removeEventListener("test", Qa, Qa);
    } catch {
      Mc = false;
    }
    var Vl = null, jc = null, Cs = null;
    function Ah() {
      if (Cs) return Cs;
      var e, t = jc, a = t.length, s, u = "value" in Vl ? Vl.value : Vl.textContent, h = u.length;
      for (e = 0; e < a && t[e] === u[e]; e++) ;
      var w = a - e;
      for (s = 1; s <= w && t[a - s] === u[h - s]; s++) ;
      return Cs = u.slice(e, 1 < s ? 1 - s : void 0);
    }
    function Es(e) {
      var t = e.keyCode;
      return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
    }
    function _s() {
      return true;
    }
    function Th() {
      return false;
    }
    function fn(e) {
      function t(a, s, u, h, w) {
        this._reactName = a, this._targetInst = u, this.type = s, this.nativeEvent = h, this.target = w, this.currentTarget = null;
        for (var M in e) e.hasOwnProperty(M) && (a = e[M], this[M] = a ? a(h) : h[M]);
        return this.isDefaultPrevented = (h.defaultPrevented != null ? h.defaultPrevented : h.returnValue === false) ? _s : Th, this.isPropagationStopped = Th, this;
      }
      return b(t.prototype, {
        preventDefault: function() {
          this.defaultPrevented = true;
          var a = this.nativeEvent;
          a && (a.preventDefault ? a.preventDefault() : typeof a.returnValue != "unknown" && (a.returnValue = false), this.isDefaultPrevented = _s);
        },
        stopPropagation: function() {
          var a = this.nativeEvent;
          a && (a.stopPropagation ? a.stopPropagation() : typeof a.cancelBubble != "unknown" && (a.cancelBubble = true), this.isPropagationStopped = _s);
        },
        persist: function() {
        },
        isPersistent: _s
      }), t;
    }
    var Mr = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function(e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0
    }, ks = fn(Mr), Wa = b({}, Mr, {
      view: 0,
      detail: 0
    }), Q1 = fn(Wa), Lc, Rc, Ja, Ms = b({}, Wa, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: Tc,
      button: 0,
      buttons: 0,
      relatedTarget: function(e) {
        return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
      },
      movementX: function(e) {
        return "movementX" in e ? e.movementX : (e !== Ja && (Ja && e.type === "mousemove" ? (Lc = e.screenX - Ja.screenX, Rc = e.screenY - Ja.screenY) : Rc = Lc = 0, Ja = e), Lc);
      },
      movementY: function(e) {
        return "movementY" in e ? e.movementY : Rc;
      }
    }), Nh = fn(Ms), W1 = b({}, Ms, {
      dataTransfer: 0
    }), J1 = fn(W1), ex = b({}, Wa, {
      relatedTarget: 0
    }), Ac = fn(ex), tx = b({}, Mr, {
      animationName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), nx = fn(tx), lx = b({}, Mr, {
      clipboardData: function(e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      }
    }), rx = fn(lx), ax = b({}, Mr, {
      data: 0
    }), Oh = fn(ax), ox = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    }, sx = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    }, ix = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey"
    };
    function cx(e) {
      var t = this.nativeEvent;
      return t.getModifierState ? t.getModifierState(e) : (e = ix[e]) ? !!t[e] : false;
    }
    function Tc() {
      return cx;
    }
    var ux = b({}, Wa, {
      key: function(e) {
        if (e.key) {
          var t = ox[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress" ? (e = Es(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? sx[e.keyCode] || "Unidentified" : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: Tc,
      charCode: function(e) {
        return e.type === "keypress" ? Es(e) : 0;
      },
      keyCode: function(e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function(e) {
        return e.type === "keypress" ? Es(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      }
    }), dx = fn(ux), fx = b({}, Ms, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0
    }), Ih = fn(fx), hx = b({}, Wa, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: Tc
    }), mx = fn(hx), gx = b({}, Mr, {
      propertyName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), px = fn(gx), yx = b({}, Ms, {
      deltaX: function(e) {
        return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
      },
      deltaY: function(e) {
        return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
      },
      deltaZ: 0,
      deltaMode: 0
    }), bx = fn(yx), vx = b({}, Mr, {
      newState: 0,
      oldState: 0
    }), xx = fn(vx), wx = [
      9,
      13,
      27,
      32
    ], Nc = pl && "CompositionEvent" in window, eo = null;
    pl && "documentMode" in document && (eo = document.documentMode);
    var Sx = pl && "TextEvent" in window && !eo, Dh = pl && (!Nc || eo && 8 < eo && 11 >= eo), zh = " ", Hh = false;
    function Uh(e, t) {
      switch (e) {
        case "keyup":
          return wx.indexOf(t.keyCode) !== -1;
        case "keydown":
          return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function Yh(e) {
      return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
    }
    var sa = false;
    function Cx(e, t) {
      switch (e) {
        case "compositionend":
          return Yh(t);
        case "keypress":
          return t.which !== 32 ? null : (Hh = true, zh);
        case "textInput":
          return e = t.data, e === zh && Hh ? null : e;
        default:
          return null;
      }
    }
    function Ex(e, t) {
      if (sa) return e === "compositionend" || !Nc && Uh(e, t) ? (e = Ah(), Cs = jc = Vl = null, sa = false, e) : null;
      switch (e) {
        case "paste":
          return null;
        case "keypress":
          if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
            if (t.char && 1 < t.char.length) return t.char;
            if (t.which) return String.fromCharCode(t.which);
          }
          return null;
        case "compositionend":
          return Dh && t.locale !== "ko" ? null : t.data;
        default:
          return null;
      }
    }
    var _x = {
      color: true,
      date: true,
      datetime: true,
      "datetime-local": true,
      email: true,
      month: true,
      number: true,
      password: true,
      range: true,
      search: true,
      tel: true,
      text: true,
      time: true,
      url: true,
      week: true
    };
    function Bh(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === "input" ? !!_x[e.type] : t === "textarea";
    }
    function Xh(e, t, a, s) {
      aa ? oa ? oa.push(s) : oa = [
        s
      ] : aa = s, t = pi(t, "onChange"), 0 < t.length && (a = new ks("onChange", "change", null, a, s), e.push({
        event: a,
        listeners: t
      }));
    }
    var to = null, no = null;
    function kx(e) {
      Ep(e, 0);
    }
    function js(e) {
      var t = Pt(e);
      if (Za(t)) return e;
    }
    function Vh(e, t) {
      if (e === "change") return t;
    }
    var $h = false;
    if (pl) {
      var Oc;
      if (pl) {
        var Ic = "oninput" in document;
        if (!Ic) {
          var qh = document.createElement("div");
          qh.setAttribute("oninput", "return;"), Ic = typeof qh.oninput == "function";
        }
        Oc = Ic;
      } else Oc = false;
      $h = Oc && (!document.documentMode || 9 < document.documentMode);
    }
    function Gh() {
      to && (to.detachEvent("onpropertychange", Ph), no = to = null);
    }
    function Ph(e) {
      if (e.propertyName === "value" && js(no)) {
        var t = [];
        Xh(t, no, e, _c(e)), Rh(kx, t);
      }
    }
    function Mx(e, t, a) {
      e === "focusin" ? (Gh(), to = t, no = a, to.attachEvent("onpropertychange", Ph)) : e === "focusout" && Gh();
    }
    function jx(e) {
      if (e === "selectionchange" || e === "keyup" || e === "keydown") return js(no);
    }
    function Lx(e, t) {
      if (e === "click") return js(t);
    }
    function Rx(e, t) {
      if (e === "input" || e === "change") return js(t);
    }
    function Ax(e, t) {
      return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
    }
    var xn = typeof Object.is == "function" ? Object.is : Ax;
    function lo(e, t) {
      if (xn(e, t)) return true;
      if (typeof e != "object" || e === null || typeof t != "object" || t === null) return false;
      var a = Object.keys(e), s = Object.keys(t);
      if (a.length !== s.length) return false;
      for (s = 0; s < a.length; s++) {
        var u = a[s];
        if (!Ne.call(t, u) || !xn(e[u], t[u])) return false;
      }
      return true;
    }
    function Kh(e) {
      for (; e && e.firstChild; ) e = e.firstChild;
      return e;
    }
    function Zh(e, t) {
      var a = Kh(e);
      e = 0;
      for (var s; a; ) {
        if (a.nodeType === 3) {
          if (s = e + a.textContent.length, e <= t && s >= t) return {
            node: a,
            offset: t - e
          };
          e = s;
        }
        e: {
          for (; a; ) {
            if (a.nextSibling) {
              a = a.nextSibling;
              break e;
            }
            a = a.parentNode;
          }
          a = void 0;
        }
        a = Kh(a);
      }
    }
    function Fh(e, t) {
      return e && t ? e === t ? true : e && e.nodeType === 3 ? false : t && t.nodeType === 3 ? Fh(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : false : false;
    }
    function Qh(e) {
      e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
      for (var t = ws(e.document); t instanceof e.HTMLIFrameElement; ) {
        try {
          var a = typeof t.contentWindow.location.href == "string";
        } catch {
          a = false;
        }
        if (a) e = t.contentWindow;
        else break;
        t = ws(e.document);
      }
      return t;
    }
    function Dc(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
    }
    var Tx = pl && "documentMode" in document && 11 >= document.documentMode, ia = null, zc = null, ro = null, Hc = false;
    function Wh(e, t, a) {
      var s = a.window === a ? a.document : a.nodeType === 9 ? a : a.ownerDocument;
      Hc || ia == null || ia !== ws(s) || (s = ia, "selectionStart" in s && Dc(s) ? s = {
        start: s.selectionStart,
        end: s.selectionEnd
      } : (s = (s.ownerDocument && s.ownerDocument.defaultView || window).getSelection(), s = {
        anchorNode: s.anchorNode,
        anchorOffset: s.anchorOffset,
        focusNode: s.focusNode,
        focusOffset: s.focusOffset
      }), ro && lo(ro, s) || (ro = s, s = pi(zc, "onSelect"), 0 < s.length && (t = new ks("onSelect", "select", null, t, a), e.push({
        event: t,
        listeners: s
      }), t.target = ia)));
    }
    function jr(e, t) {
      var a = {};
      return a[e.toLowerCase()] = t.toLowerCase(), a["Webkit" + e] = "webkit" + t, a["Moz" + e] = "moz" + t, a;
    }
    var ca = {
      animationend: jr("Animation", "AnimationEnd"),
      animationiteration: jr("Animation", "AnimationIteration"),
      animationstart: jr("Animation", "AnimationStart"),
      transitionrun: jr("Transition", "TransitionRun"),
      transitionstart: jr("Transition", "TransitionStart"),
      transitioncancel: jr("Transition", "TransitionCancel"),
      transitionend: jr("Transition", "TransitionEnd")
    }, Uc = {}, Jh = {};
    pl && (Jh = document.createElement("div").style, "AnimationEvent" in window || (delete ca.animationend.animation, delete ca.animationiteration.animation, delete ca.animationstart.animation), "TransitionEvent" in window || delete ca.transitionend.transition);
    function Lr(e) {
      if (Uc[e]) return Uc[e];
      if (!ca[e]) return e;
      var t = ca[e], a;
      for (a in t) if (t.hasOwnProperty(a) && a in Jh) return Uc[e] = t[a];
      return e;
    }
    var em = Lr("animationend"), tm = Lr("animationiteration"), nm = Lr("animationstart"), Nx = Lr("transitionrun"), Ox = Lr("transitionstart"), Ix = Lr("transitioncancel"), lm = Lr("transitionend"), rm = /* @__PURE__ */ new Map(), Yc = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    Yc.push("scrollEnd");
    function qn(e, t) {
      rm.set(e, t), vn(t, [
        e
      ]);
    }
    var Ls = typeof reportError == "function" ? reportError : function(e) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var t = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
          error: e
        });
        if (!window.dispatchEvent(t)) return;
      } else if (typeof process == "object" && typeof process.emit == "function") {
        process.emit("uncaughtException", e);
        return;
      }
      console.error(e);
    }, An = [], ua = 0, Bc = 0;
    function Rs() {
      for (var e = ua, t = Bc = ua = 0; t < e; ) {
        var a = An[t];
        An[t++] = null;
        var s = An[t];
        An[t++] = null;
        var u = An[t];
        An[t++] = null;
        var h = An[t];
        if (An[t++] = null, s !== null && u !== null) {
          var w = s.pending;
          w === null ? u.next = u : (u.next = w.next, w.next = u), s.pending = u;
        }
        h !== 0 && am(a, u, h);
      }
    }
    function As(e, t, a, s) {
      An[ua++] = e, An[ua++] = t, An[ua++] = a, An[ua++] = s, Bc |= s, e.lanes |= s, e = e.alternate, e !== null && (e.lanes |= s);
    }
    function Xc(e, t, a, s) {
      return As(e, t, a, s), Ts(e);
    }
    function Rr(e, t) {
      return As(e, null, null, t), Ts(e);
    }
    function am(e, t, a) {
      e.lanes |= a;
      var s = e.alternate;
      s !== null && (s.lanes |= a);
      for (var u = false, h = e.return; h !== null; ) h.childLanes |= a, s = h.alternate, s !== null && (s.childLanes |= a), h.tag === 22 && (e = h.stateNode, e === null || e._visibility & 1 || (u = true)), e = h, h = h.return;
      return e.tag === 3 ? (h = e.stateNode, u && t !== null && (u = 31 - jt(a), e = h.hiddenUpdates, s = e[u], s === null ? e[u] = [
        t
      ] : s.push(t), t.lane = a | 536870912), h) : null;
    }
    function Ts(e) {
      if (50 < Mo) throw Mo = 0, Qu = null, Error(o(185));
      for (var t = e.return; t !== null; ) e = t, t = e.return;
      return e.tag === 3 ? e.stateNode : null;
    }
    var da = {};
    function Dx(e, t, a, s) {
      this.tag = e, this.key = a, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = s, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
    }
    function wn(e, t, a, s) {
      return new Dx(e, t, a, s);
    }
    function Vc(e) {
      return e = e.prototype, !(!e || !e.isReactComponent);
    }
    function yl(e, t) {
      var a = e.alternate;
      return a === null ? (a = wn(e.tag, t, e.key, e.mode), a.elementType = e.elementType, a.type = e.type, a.stateNode = e.stateNode, a.alternate = e, e.alternate = a) : (a.pendingProps = t, a.type = e.type, a.flags = 0, a.subtreeFlags = 0, a.deletions = null), a.flags = e.flags & 65011712, a.childLanes = e.childLanes, a.lanes = e.lanes, a.child = e.child, a.memoizedProps = e.memoizedProps, a.memoizedState = e.memoizedState, a.updateQueue = e.updateQueue, t = e.dependencies, a.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }, a.sibling = e.sibling, a.index = e.index, a.ref = e.ref, a.refCleanup = e.refCleanup, a;
    }
    function om(e, t) {
      e.flags &= 65011714;
      var a = e.alternate;
      return a === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = a.childLanes, e.lanes = a.lanes, e.child = a.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = a.memoizedProps, e.memoizedState = a.memoizedState, e.updateQueue = a.updateQueue, e.type = a.type, t = a.dependencies, e.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }), e;
    }
    function Ns(e, t, a, s, u, h) {
      var w = 0;
      if (s = e, typeof e == "function") Vc(e) && (w = 1);
      else if (typeof e == "string") w = Bw(e, a, W.current) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
      else e: switch (e) {
        case H:
          return e = wn(31, a, t, u), e.elementType = H, e.lanes = h, e;
        case x:
          return Ar(a.children, u, h, t);
        case E:
          w = 8, u |= 24;
          break;
        case _:
          return e = wn(12, a, t, u | 2), e.elementType = _, e.lanes = h, e;
        case I:
          return e = wn(13, a, t, u), e.elementType = I, e.lanes = h, e;
        case T:
          return e = wn(19, a, t, u), e.elementType = T, e.lanes = h, e;
        default:
          if (typeof e == "object" && e !== null) switch (e.$$typeof) {
            case A:
              w = 10;
              break e;
            case N:
              w = 9;
              break e;
            case R:
              w = 11;
              break e;
            case L:
              w = 14;
              break e;
            case D:
              w = 16, s = null;
              break e;
          }
          w = 29, a = Error(o(130, e === null ? "null" : typeof e, "")), s = null;
      }
      return t = wn(w, a, t, u), t.elementType = e, t.type = s, t.lanes = h, t;
    }
    function Ar(e, t, a, s) {
      return e = wn(7, e, s, t), e.lanes = a, e;
    }
    function $c(e, t, a) {
      return e = wn(6, e, null, t), e.lanes = a, e;
    }
    function sm(e) {
      var t = wn(18, null, null, 0);
      return t.stateNode = e, t;
    }
    function qc(e, t, a) {
      return t = wn(4, e.children !== null ? e.children : [], e.key, t), t.lanes = a, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
      }, t;
    }
    var im = /* @__PURE__ */ new WeakMap();
    function Tn(e, t) {
      if (typeof e == "object" && e !== null) {
        var a = im.get(e);
        return a !== void 0 ? a : (t = {
          value: e,
          source: t,
          stack: Ce(t)
        }, im.set(e, t), t);
      }
      return {
        value: e,
        source: t,
        stack: Ce(t)
      };
    }
    var fa = [], ha = 0, Os = null, ao = 0, Nn = [], On = 0, $l = null, al = 1, ol = "";
    function bl(e, t) {
      fa[ha++] = ao, fa[ha++] = Os, Os = e, ao = t;
    }
    function cm(e, t, a) {
      Nn[On++] = al, Nn[On++] = ol, Nn[On++] = $l, $l = e;
      var s = al;
      e = ol;
      var u = 32 - jt(s) - 1;
      s &= ~(1 << u), a += 1;
      var h = 32 - jt(t) + u;
      if (30 < h) {
        var w = u - u % 5;
        h = (s & (1 << w) - 1).toString(32), s >>= w, u -= w, al = 1 << 32 - jt(t) + u | a << u | s, ol = h + e;
      } else al = 1 << h | a << u | s, ol = e;
    }
    function Gc(e) {
      e.return !== null && (bl(e, 1), cm(e, 1, 0));
    }
    function Pc(e) {
      for (; e === Os; ) Os = fa[--ha], fa[ha] = null, ao = fa[--ha], fa[ha] = null;
      for (; e === $l; ) $l = Nn[--On], Nn[On] = null, ol = Nn[--On], Nn[On] = null, al = Nn[--On], Nn[On] = null;
    }
    function um(e, t) {
      Nn[On++] = al, Nn[On++] = ol, Nn[On++] = $l, al = t.id, ol = t.overflow, $l = e;
    }
    var Ft = null, wt = null, Qe = false, ql = null, In = false, Kc = Error(o(519));
    function Gl(e) {
      var t = Error(o(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? "text" : "HTML", ""));
      throw oo(Tn(t, e)), Kc;
    }
    function dm(e) {
      var t = e.stateNode, a = e.type, s = e.memoizedProps;
      switch (t[$t] = e, t[le] = s, a) {
        case "dialog":
          Ge("cancel", t), Ge("close", t);
          break;
        case "iframe":
        case "object":
        case "embed":
          Ge("load", t);
          break;
        case "video":
        case "audio":
          for (a = 0; a < Lo.length; a++) Ge(Lo[a], t);
          break;
        case "source":
          Ge("error", t);
          break;
        case "img":
        case "image":
        case "link":
          Ge("error", t), Ge("load", t);
          break;
        case "details":
          Ge("toggle", t);
          break;
        case "input":
          Ge("invalid", t), Eh(t, s.value, s.defaultValue, s.checked, s.defaultChecked, s.type, s.name, true);
          break;
        case "select":
          Ge("invalid", t);
          break;
        case "textarea":
          Ge("invalid", t), kh(t, s.value, s.defaultValue, s.children);
      }
      a = s.children, typeof a != "string" && typeof a != "number" && typeof a != "bigint" || t.textContent === "" + a || s.suppressHydrationWarning === true || jp(t.textContent, a) ? (s.popover != null && (Ge("beforetoggle", t), Ge("toggle", t)), s.onScroll != null && Ge("scroll", t), s.onScrollEnd != null && Ge("scrollend", t), s.onClick != null && (t.onclick = gl), t = true) : t = false, t || Gl(e, true);
    }
    function fm(e) {
      for (Ft = e.return; Ft; ) switch (Ft.tag) {
        case 5:
        case 31:
        case 13:
          In = false;
          return;
        case 27:
        case 3:
          In = true;
          return;
        default:
          Ft = Ft.return;
      }
    }
    function ma(e) {
      if (e !== Ft) return false;
      if (!Qe) return fm(e), Qe = true, false;
      var t = e.tag, a;
      if ((a = t !== 3 && t !== 27) && ((a = t === 5) && (a = e.type, a = !(a !== "form" && a !== "button") || fd(e.type, e.memoizedProps)), a = !a), a && wt && Gl(e), fm(e), t === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(o(317));
        wt = zp(e);
      } else if (t === 31) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(o(317));
        wt = zp(e);
      } else t === 27 ? (t = wt, or(e.type) ? (e = yd, yd = null, wt = e) : wt = t) : wt = Ft ? zn(e.stateNode.nextSibling) : null;
      return true;
    }
    function Tr() {
      wt = Ft = null, Qe = false;
    }
    function Zc() {
      var e = ql;
      return e !== null && (pn === null ? pn = e : pn.push.apply(pn, e), ql = null), e;
    }
    function oo(e) {
      ql === null ? ql = [
        e
      ] : ql.push(e);
    }
    var Fc = j(null), Nr = null, vl = null;
    function Pl(e, t, a) {
      K(Fc, t._currentValue), t._currentValue = a;
    }
    function xl(e) {
      e._currentValue = Fc.current, O(Fc);
    }
    function Qc(e, t, a) {
      for (; e !== null; ) {
        var s = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, s !== null && (s.childLanes |= t)) : s !== null && (s.childLanes & t) !== t && (s.childLanes |= t), e === a) break;
        e = e.return;
      }
    }
    function Wc(e, t, a, s) {
      var u = e.child;
      for (u !== null && (u.return = e); u !== null; ) {
        var h = u.dependencies;
        if (h !== null) {
          var w = u.child;
          h = h.firstContext;
          e: for (; h !== null; ) {
            var M = h;
            h = u;
            for (var z = 0; z < t.length; z++) if (M.context === t[z]) {
              h.lanes |= a, M = h.alternate, M !== null && (M.lanes |= a), Qc(h.return, a, e), s || (w = null);
              break e;
            }
            h = M.next;
          }
        } else if (u.tag === 18) {
          if (w = u.return, w === null) throw Error(o(341));
          w.lanes |= a, h = w.alternate, h !== null && (h.lanes |= a), Qc(w, a, e), w = null;
        } else w = u.child;
        if (w !== null) w.return = u;
        else for (w = u; w !== null; ) {
          if (w === e) {
            w = null;
            break;
          }
          if (u = w.sibling, u !== null) {
            u.return = w.return, w = u;
            break;
          }
          w = w.return;
        }
        u = w;
      }
    }
    function ga(e, t, a, s) {
      e = null;
      for (var u = t, h = false; u !== null; ) {
        if (!h) {
          if ((u.flags & 524288) !== 0) h = true;
          else if ((u.flags & 262144) !== 0) break;
        }
        if (u.tag === 10) {
          var w = u.alternate;
          if (w === null) throw Error(o(387));
          if (w = w.memoizedProps, w !== null) {
            var M = u.type;
            xn(u.pendingProps.value, w.value) || (e !== null ? e.push(M) : e = [
              M
            ]);
          }
        } else if (u === pe.current) {
          if (w = u.alternate, w === null) throw Error(o(387));
          w.memoizedState.memoizedState !== u.memoizedState.memoizedState && (e !== null ? e.push(Oo) : e = [
            Oo
          ]);
        }
        u = u.return;
      }
      e !== null && Wc(t, e, a, s), t.flags |= 262144;
    }
    function Is(e) {
      for (e = e.firstContext; e !== null; ) {
        if (!xn(e.context._currentValue, e.memoizedValue)) return true;
        e = e.next;
      }
      return false;
    }
    function Or(e) {
      Nr = e, vl = null, e = e.dependencies, e !== null && (e.firstContext = null);
    }
    function Qt(e) {
      return hm(Nr, e);
    }
    function Ds(e, t) {
      return Nr === null && Or(e), hm(e, t);
    }
    function hm(e, t) {
      var a = t._currentValue;
      if (t = {
        context: t,
        memoizedValue: a,
        next: null
      }, vl === null) {
        if (e === null) throw Error(o(308));
        vl = t, e.dependencies = {
          lanes: 0,
          firstContext: t
        }, e.flags |= 524288;
      } else vl = vl.next = t;
      return a;
    }
    var zx = typeof AbortController < "u" ? AbortController : function() {
      var e = [], t = this.signal = {
        aborted: false,
        addEventListener: function(a, s) {
          e.push(s);
        }
      };
      this.abort = function() {
        t.aborted = true, e.forEach(function(a) {
          return a();
        });
      };
    }, Hx = l.unstable_scheduleCallback, Ux = l.unstable_NormalPriority, zt = {
      $$typeof: A,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0
    };
    function Jc() {
      return {
        controller: new zx(),
        data: /* @__PURE__ */ new Map(),
        refCount: 0
      };
    }
    function so(e) {
      e.refCount--, e.refCount === 0 && Hx(Ux, function() {
        e.controller.abort();
      });
    }
    var io = null, eu = 0, pa = 0, ya = null;
    function Yx(e, t) {
      if (io === null) {
        var a = io = [];
        eu = 0, pa = ld(), ya = {
          status: "pending",
          value: void 0,
          then: function(s) {
            a.push(s);
          }
        };
      }
      return eu++, t.then(mm, mm), t;
    }
    function mm() {
      if (--eu === 0 && io !== null) {
        ya !== null && (ya.status = "fulfilled");
        var e = io;
        io = null, pa = 0, ya = null;
        for (var t = 0; t < e.length; t++) (0, e[t])();
      }
    }
    function Bx(e, t) {
      var a = [], s = {
        status: "pending",
        value: null,
        reason: null,
        then: function(u) {
          a.push(u);
        }
      };
      return e.then(function() {
        s.status = "fulfilled", s.value = t;
        for (var u = 0; u < a.length; u++) (0, a[u])(t);
      }, function(u) {
        for (s.status = "rejected", s.reason = u, u = 0; u < a.length; u++) (0, a[u])(void 0);
      }), s;
    }
    var gm = $.S;
    $.S = function(e, t) {
      Wg = Ke(), typeof t == "object" && t !== null && typeof t.then == "function" && Yx(e, t), gm !== null && gm(e, t);
    };
    var Ir = j(null);
    function tu() {
      var e = Ir.current;
      return e !== null ? e : pt.pooledCache;
    }
    function zs(e, t) {
      t === null ? K(Ir, Ir.current) : K(Ir, t.pool);
    }
    function pm() {
      var e = tu();
      return e === null ? null : {
        parent: zt._currentValue,
        pool: e
      };
    }
    var ba = Error(o(460)), nu = Error(o(474)), Hs = Error(o(542)), Us = {
      then: function() {
      }
    };
    function ym(e) {
      return e = e.status, e === "fulfilled" || e === "rejected";
    }
    function bm(e, t, a) {
      switch (a = e[a], a === void 0 ? e.push(t) : a !== t && (t.then(gl, gl), t = a), t.status) {
        case "fulfilled":
          return t.value;
        case "rejected":
          throw e = t.reason, xm(e), e;
        default:
          if (typeof t.status == "string") t.then(gl, gl);
          else {
            if (e = pt, e !== null && 100 < e.shellSuspendCounter) throw Error(o(482));
            e = t, e.status = "pending", e.then(function(s) {
              if (t.status === "pending") {
                var u = t;
                u.status = "fulfilled", u.value = s;
              }
            }, function(s) {
              if (t.status === "pending") {
                var u = t;
                u.status = "rejected", u.reason = s;
              }
            });
          }
          switch (t.status) {
            case "fulfilled":
              return t.value;
            case "rejected":
              throw e = t.reason, xm(e), e;
          }
          throw zr = t, ba;
      }
    }
    function Dr(e) {
      try {
        var t = e._init;
        return t(e._payload);
      } catch (a) {
        throw a !== null && typeof a == "object" && typeof a.then == "function" ? (zr = a, ba) : a;
      }
    }
    var zr = null;
    function vm() {
      if (zr === null) throw Error(o(459));
      var e = zr;
      return zr = null, e;
    }
    function xm(e) {
      if (e === ba || e === Hs) throw Error(o(483));
    }
    var va = null, co = 0;
    function Ys(e) {
      var t = co;
      return co += 1, va === null && (va = []), bm(va, e, t);
    }
    function uo(e, t) {
      t = t.props.ref, e.ref = t !== void 0 ? t : null;
    }
    function Bs(e, t) {
      throw t.$$typeof === S ? Error(o(525)) : (e = Object.prototype.toString.call(t), Error(o(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)));
    }
    function wm(e) {
      function t(V, B) {
        if (e) {
          var G = V.deletions;
          G === null ? (V.deletions = [
            B
          ], V.flags |= 16) : G.push(B);
        }
      }
      function a(V, B) {
        if (!e) return null;
        for (; B !== null; ) t(V, B), B = B.sibling;
        return null;
      }
      function s(V) {
        for (var B = /* @__PURE__ */ new Map(); V !== null; ) V.key !== null ? B.set(V.key, V) : B.set(V.index, V), V = V.sibling;
        return B;
      }
      function u(V, B) {
        return V = yl(V, B), V.index = 0, V.sibling = null, V;
      }
      function h(V, B, G) {
        return V.index = G, e ? (G = V.alternate, G !== null ? (G = G.index, G < B ? (V.flags |= 67108866, B) : G) : (V.flags |= 67108866, B)) : (V.flags |= 1048576, B);
      }
      function w(V) {
        return e && V.alternate === null && (V.flags |= 67108866), V;
      }
      function M(V, B, G, ae) {
        return B === null || B.tag !== 6 ? (B = $c(G, V.mode, ae), B.return = V, B) : (B = u(B, G), B.return = V, B);
      }
      function z(V, B, G, ae) {
        var Le = G.type;
        return Le === x ? ne(V, B, G.props.children, ae, G.key) : B !== null && (B.elementType === Le || typeof Le == "object" && Le !== null && Le.$$typeof === D && Dr(Le) === B.type) ? (B = u(B, G.props), uo(B, G), B.return = V, B) : (B = Ns(G.type, G.key, G.props, null, V.mode, ae), uo(B, G), B.return = V, B);
      }
      function P(V, B, G, ae) {
        return B === null || B.tag !== 4 || B.stateNode.containerInfo !== G.containerInfo || B.stateNode.implementation !== G.implementation ? (B = qc(G, V.mode, ae), B.return = V, B) : (B = u(B, G.children || []), B.return = V, B);
      }
      function ne(V, B, G, ae, Le) {
        return B === null || B.tag !== 7 ? (B = Ar(G, V.mode, ae, Le), B.return = V, B) : (B = u(B, G), B.return = V, B);
      }
      function oe(V, B, G) {
        if (typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint") return B = $c("" + B, V.mode, G), B.return = V, B;
        if (typeof B == "object" && B !== null) {
          switch (B.$$typeof) {
            case C:
              return G = Ns(B.type, B.key, B.props, null, V.mode, G), uo(G, B), G.return = V, G;
            case k:
              return B = qc(B, V.mode, G), B.return = V, B;
            case D:
              return B = Dr(B), oe(V, B, G);
          }
          if (Ee(B) || ee(B)) return B = Ar(B, V.mode, G, null), B.return = V, B;
          if (typeof B.then == "function") return oe(V, Ys(B), G);
          if (B.$$typeof === A) return oe(V, Ds(V, B), G);
          Bs(V, B);
        }
        return null;
      }
      function Z(V, B, G, ae) {
        var Le = B !== null ? B.key : null;
        if (typeof G == "string" && G !== "" || typeof G == "number" || typeof G == "bigint") return Le !== null ? null : M(V, B, "" + G, ae);
        if (typeof G == "object" && G !== null) {
          switch (G.$$typeof) {
            case C:
              return G.key === Le ? z(V, B, G, ae) : null;
            case k:
              return G.key === Le ? P(V, B, G, ae) : null;
            case D:
              return G = Dr(G), Z(V, B, G, ae);
          }
          if (Ee(G) || ee(G)) return Le !== null ? null : ne(V, B, G, ae, null);
          if (typeof G.then == "function") return Z(V, B, Ys(G), ae);
          if (G.$$typeof === A) return Z(V, B, Ds(V, G), ae);
          Bs(V, G);
        }
        return null;
      }
      function Q(V, B, G, ae, Le) {
        if (typeof ae == "string" && ae !== "" || typeof ae == "number" || typeof ae == "bigint") return V = V.get(G) || null, M(B, V, "" + ae, Le);
        if (typeof ae == "object" && ae !== null) {
          switch (ae.$$typeof) {
            case C:
              return V = V.get(ae.key === null ? G : ae.key) || null, z(B, V, ae, Le);
            case k:
              return V = V.get(ae.key === null ? G : ae.key) || null, P(B, V, ae, Le);
            case D:
              return ae = Dr(ae), Q(V, B, G, ae, Le);
          }
          if (Ee(ae) || ee(ae)) return V = V.get(G) || null, ne(B, V, ae, Le, null);
          if (typeof ae.then == "function") return Q(V, B, G, Ys(ae), Le);
          if (ae.$$typeof === A) return Q(V, B, G, Ds(B, ae), Le);
          Bs(B, ae);
        }
        return null;
      }
      function _e(V, B, G, ae) {
        for (var Le = null, et = null, Me = B, Ye = B = 0, Fe = null; Me !== null && Ye < G.length; Ye++) {
          Me.index > Ye ? (Fe = Me, Me = null) : Fe = Me.sibling;
          var tt = Z(V, Me, G[Ye], ae);
          if (tt === null) {
            Me === null && (Me = Fe);
            break;
          }
          e && Me && tt.alternate === null && t(V, Me), B = h(tt, B, Ye), et === null ? Le = tt : et.sibling = tt, et = tt, Me = Fe;
        }
        if (Ye === G.length) return a(V, Me), Qe && bl(V, Ye), Le;
        if (Me === null) {
          for (; Ye < G.length; Ye++) Me = oe(V, G[Ye], ae), Me !== null && (B = h(Me, B, Ye), et === null ? Le = Me : et.sibling = Me, et = Me);
          return Qe && bl(V, Ye), Le;
        }
        for (Me = s(Me); Ye < G.length; Ye++) Fe = Q(Me, V, Ye, G[Ye], ae), Fe !== null && (e && Fe.alternate !== null && Me.delete(Fe.key === null ? Ye : Fe.key), B = h(Fe, B, Ye), et === null ? Le = Fe : et.sibling = Fe, et = Fe);
        return e && Me.forEach(function(dr) {
          return t(V, dr);
        }), Qe && bl(V, Ye), Le;
      }
      function Te(V, B, G, ae) {
        if (G == null) throw Error(o(151));
        for (var Le = null, et = null, Me = B, Ye = B = 0, Fe = null, tt = G.next(); Me !== null && !tt.done; Ye++, tt = G.next()) {
          Me.index > Ye ? (Fe = Me, Me = null) : Fe = Me.sibling;
          var dr = Z(V, Me, tt.value, ae);
          if (dr === null) {
            Me === null && (Me = Fe);
            break;
          }
          e && Me && dr.alternate === null && t(V, Me), B = h(dr, B, Ye), et === null ? Le = dr : et.sibling = dr, et = dr, Me = Fe;
        }
        if (tt.done) return a(V, Me), Qe && bl(V, Ye), Le;
        if (Me === null) {
          for (; !tt.done; Ye++, tt = G.next()) tt = oe(V, tt.value, ae), tt !== null && (B = h(tt, B, Ye), et === null ? Le = tt : et.sibling = tt, et = tt);
          return Qe && bl(V, Ye), Le;
        }
        for (Me = s(Me); !tt.done; Ye++, tt = G.next()) tt = Q(Me, V, Ye, tt.value, ae), tt !== null && (e && tt.alternate !== null && Me.delete(tt.key === null ? Ye : tt.key), B = h(tt, B, Ye), et === null ? Le = tt : et.sibling = tt, et = tt);
        return e && Me.forEach(function(Ww) {
          return t(V, Ww);
        }), Qe && bl(V, Ye), Le;
      }
      function mt(V, B, G, ae) {
        if (typeof G == "object" && G !== null && G.type === x && G.key === null && (G = G.props.children), typeof G == "object" && G !== null) {
          switch (G.$$typeof) {
            case C:
              e: {
                for (var Le = G.key; B !== null; ) {
                  if (B.key === Le) {
                    if (Le = G.type, Le === x) {
                      if (B.tag === 7) {
                        a(V, B.sibling), ae = u(B, G.props.children), ae.return = V, V = ae;
                        break e;
                      }
                    } else if (B.elementType === Le || typeof Le == "object" && Le !== null && Le.$$typeof === D && Dr(Le) === B.type) {
                      a(V, B.sibling), ae = u(B, G.props), uo(ae, G), ae.return = V, V = ae;
                      break e;
                    }
                    a(V, B);
                    break;
                  } else t(V, B);
                  B = B.sibling;
                }
                G.type === x ? (ae = Ar(G.props.children, V.mode, ae, G.key), ae.return = V, V = ae) : (ae = Ns(G.type, G.key, G.props, null, V.mode, ae), uo(ae, G), ae.return = V, V = ae);
              }
              return w(V);
            case k:
              e: {
                for (Le = G.key; B !== null; ) {
                  if (B.key === Le) if (B.tag === 4 && B.stateNode.containerInfo === G.containerInfo && B.stateNode.implementation === G.implementation) {
                    a(V, B.sibling), ae = u(B, G.children || []), ae.return = V, V = ae;
                    break e;
                  } else {
                    a(V, B);
                    break;
                  }
                  else t(V, B);
                  B = B.sibling;
                }
                ae = qc(G, V.mode, ae), ae.return = V, V = ae;
              }
              return w(V);
            case D:
              return G = Dr(G), mt(V, B, G, ae);
          }
          if (Ee(G)) return _e(V, B, G, ae);
          if (ee(G)) {
            if (Le = ee(G), typeof Le != "function") throw Error(o(150));
            return G = Le.call(G), Te(V, B, G, ae);
          }
          if (typeof G.then == "function") return mt(V, B, Ys(G), ae);
          if (G.$$typeof === A) return mt(V, B, Ds(V, G), ae);
          Bs(V, G);
        }
        return typeof G == "string" && G !== "" || typeof G == "number" || typeof G == "bigint" ? (G = "" + G, B !== null && B.tag === 6 ? (a(V, B.sibling), ae = u(B, G), ae.return = V, V = ae) : (a(V, B), ae = $c(G, V.mode, ae), ae.return = V, V = ae), w(V)) : a(V, B);
      }
      return function(V, B, G, ae) {
        try {
          co = 0;
          var Le = mt(V, B, G, ae);
          return va = null, Le;
        } catch (Me) {
          if (Me === ba || Me === Hs) throw Me;
          var et = wn(29, Me, null, V.mode);
          return et.lanes = ae, et.return = V, et;
        } finally {
        }
      };
    }
    var Hr = wm(true), Sm = wm(false), Kl = false;
    function lu(e) {
      e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          lanes: 0,
          hiddenCallbacks: null
        },
        callbacks: null
      };
    }
    function ru(e, t) {
      e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        callbacks: null
      });
    }
    function Zl(e) {
      return {
        lane: e,
        tag: 0,
        payload: null,
        callback: null,
        next: null
      };
    }
    function Fl(e, t, a) {
      var s = e.updateQueue;
      if (s === null) return null;
      if (s = s.shared, (rt & 2) !== 0) {
        var u = s.pending;
        return u === null ? t.next = t : (t.next = u.next, u.next = t), s.pending = t, t = Ts(e), am(e, null, a), t;
      }
      return As(e, s, t, a), Ts(e);
    }
    function fo(e, t, a) {
      if (t = t.updateQueue, t !== null && (t = t.shared, (a & 4194048) !== 0)) {
        var s = t.lanes;
        s &= e.pendingLanes, a |= s, t.lanes = a, bs(e, a);
      }
    }
    function au(e, t) {
      var a = e.updateQueue, s = e.alternate;
      if (s !== null && (s = s.updateQueue, a === s)) {
        var u = null, h = null;
        if (a = a.firstBaseUpdate, a !== null) {
          do {
            var w = {
              lane: a.lane,
              tag: a.tag,
              payload: a.payload,
              callback: null,
              next: null
            };
            h === null ? u = h = w : h = h.next = w, a = a.next;
          } while (a !== null);
          h === null ? u = h = t : h = h.next = t;
        } else u = h = t;
        a = {
          baseState: s.baseState,
          firstBaseUpdate: u,
          lastBaseUpdate: h,
          shared: s.shared,
          callbacks: s.callbacks
        }, e.updateQueue = a;
        return;
      }
      e = a.lastBaseUpdate, e === null ? a.firstBaseUpdate = t : e.next = t, a.lastBaseUpdate = t;
    }
    var ou = false;
    function ho() {
      if (ou) {
        var e = ya;
        if (e !== null) throw e;
      }
    }
    function mo(e, t, a, s) {
      ou = false;
      var u = e.updateQueue;
      Kl = false;
      var h = u.firstBaseUpdate, w = u.lastBaseUpdate, M = u.shared.pending;
      if (M !== null) {
        u.shared.pending = null;
        var z = M, P = z.next;
        z.next = null, w === null ? h = P : w.next = P, w = z;
        var ne = e.alternate;
        ne !== null && (ne = ne.updateQueue, M = ne.lastBaseUpdate, M !== w && (M === null ? ne.firstBaseUpdate = P : M.next = P, ne.lastBaseUpdate = z));
      }
      if (h !== null) {
        var oe = u.baseState;
        w = 0, ne = P = z = null, M = h;
        do {
          var Z = M.lane & -536870913, Q = Z !== M.lane;
          if (Q ? (Ze & Z) === Z : (s & Z) === Z) {
            Z !== 0 && Z === pa && (ou = true), ne !== null && (ne = ne.next = {
              lane: 0,
              tag: M.tag,
              payload: M.payload,
              callback: null,
              next: null
            });
            e: {
              var _e = e, Te = M;
              Z = t;
              var mt = a;
              switch (Te.tag) {
                case 1:
                  if (_e = Te.payload, typeof _e == "function") {
                    oe = _e.call(mt, oe, Z);
                    break e;
                  }
                  oe = _e;
                  break e;
                case 3:
                  _e.flags = _e.flags & -65537 | 128;
                case 0:
                  if (_e = Te.payload, Z = typeof _e == "function" ? _e.call(mt, oe, Z) : _e, Z == null) break e;
                  oe = b({}, oe, Z);
                  break e;
                case 2:
                  Kl = true;
              }
            }
            Z = M.callback, Z !== null && (e.flags |= 64, Q && (e.flags |= 8192), Q = u.callbacks, Q === null ? u.callbacks = [
              Z
            ] : Q.push(Z));
          } else Q = {
            lane: Z,
            tag: M.tag,
            payload: M.payload,
            callback: M.callback,
            next: null
          }, ne === null ? (P = ne = Q, z = oe) : ne = ne.next = Q, w |= Z;
          if (M = M.next, M === null) {
            if (M = u.shared.pending, M === null) break;
            Q = M, M = Q.next, Q.next = null, u.lastBaseUpdate = Q, u.shared.pending = null;
          }
        } while (true);
        ne === null && (z = oe), u.baseState = z, u.firstBaseUpdate = P, u.lastBaseUpdate = ne, h === null && (u.shared.lanes = 0), tr |= w, e.lanes = w, e.memoizedState = oe;
      }
    }
    function Cm(e, t) {
      if (typeof e != "function") throw Error(o(191, e));
      e.call(t);
    }
    function Em(e, t) {
      var a = e.callbacks;
      if (a !== null) for (e.callbacks = null, e = 0; e < a.length; e++) Cm(a[e], t);
    }
    var xa = j(null), Xs = j(0);
    function _m(e, t) {
      e = Ll, K(Xs, e), K(xa, t), Ll = e | t.baseLanes;
    }
    function su() {
      K(Xs, Ll), K(xa, xa.current);
    }
    function iu() {
      Ll = Xs.current, O(xa), O(Xs);
    }
    var Sn = j(null), Dn = null;
    function Ql(e) {
      var t = e.alternate;
      K(Nt, Nt.current & 1), K(Sn, e), Dn === null && (t === null || xa.current !== null || t.memoizedState !== null) && (Dn = e);
    }
    function cu(e) {
      K(Nt, Nt.current), K(Sn, e), Dn === null && (Dn = e);
    }
    function km(e) {
      e.tag === 22 ? (K(Nt, Nt.current), K(Sn, e), Dn === null && (Dn = e)) : Wl();
    }
    function Wl() {
      K(Nt, Nt.current), K(Sn, Sn.current);
    }
    function Cn(e) {
      O(Sn), Dn === e && (Dn = null), O(Nt);
    }
    var Nt = j(0);
    function Vs(e) {
      for (var t = e; t !== null; ) {
        if (t.tag === 13) {
          var a = t.memoizedState;
          if (a !== null && (a = a.dehydrated, a === null || gd(a) || pd(a))) return t;
        } else if (t.tag === 19 && (t.memoizedProps.revealOrder === "forwards" || t.memoizedProps.revealOrder === "backwards" || t.memoizedProps.revealOrder === "unstable_legacy-backwards" || t.memoizedProps.revealOrder === "together")) {
          if ((t.flags & 128) !== 0) return t;
        } else if (t.child !== null) {
          t.child.return = t, t = t.child;
          continue;
        }
        if (t === e) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) return null;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
      return null;
    }
    var wl = 0, Ue = null, ft = null, Ht = null, $s = false, wa = false, Ur = false, qs = 0, go = 0, Sa = null, Xx = 0;
    function Rt() {
      throw Error(o(321));
    }
    function uu(e, t) {
      if (t === null) return false;
      for (var a = 0; a < t.length && a < e.length; a++) if (!xn(e[a], t[a])) return false;
      return true;
    }
    function du(e, t, a, s, u, h) {
      return wl = h, Ue = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, $.H = e === null || e.memoizedState === null ? cg : ku, Ur = false, h = a(s, u), Ur = false, wa && (h = jm(t, a, s, u)), Mm(e), h;
    }
    function Mm(e) {
      $.H = bo;
      var t = ft !== null && ft.next !== null;
      if (wl = 0, Ht = ft = Ue = null, $s = false, go = 0, Sa = null, t) throw Error(o(300));
      e === null || Ut || (e = e.dependencies, e !== null && Is(e) && (Ut = true));
    }
    function jm(e, t, a, s) {
      Ue = e;
      var u = 0;
      do {
        if (wa && (Sa = null), go = 0, wa = false, 25 <= u) throw Error(o(301));
        if (u += 1, Ht = ft = null, e.updateQueue != null) {
          var h = e.updateQueue;
          h.lastEffect = null, h.events = null, h.stores = null, h.memoCache != null && (h.memoCache.index = 0);
        }
        $.H = ug, h = t(a, s);
      } while (wa);
      return h;
    }
    function Vx() {
      var e = $.H, t = e.useState()[0];
      return t = typeof t.then == "function" ? po(t) : t, e = e.useState()[0], (ft !== null ? ft.memoizedState : null) !== e && (Ue.flags |= 1024), t;
    }
    function fu() {
      var e = qs !== 0;
      return qs = 0, e;
    }
    function hu(e, t, a) {
      t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~a;
    }
    function mu(e) {
      if ($s) {
        for (e = e.memoizedState; e !== null; ) {
          var t = e.queue;
          t !== null && (t.pending = null), e = e.next;
        }
        $s = false;
      }
      wl = 0, Ht = ft = Ue = null, wa = false, go = qs = 0, Sa = null;
    }
    function sn() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      return Ht === null ? Ue.memoizedState = Ht = e : Ht = Ht.next = e, Ht;
    }
    function Ot() {
      if (ft === null) {
        var e = Ue.alternate;
        e = e !== null ? e.memoizedState : null;
      } else e = ft.next;
      var t = Ht === null ? Ue.memoizedState : Ht.next;
      if (t !== null) Ht = t, ft = e;
      else {
        if (e === null) throw Ue.alternate === null ? Error(o(467)) : Error(o(310));
        ft = e, e = {
          memoizedState: ft.memoizedState,
          baseState: ft.baseState,
          baseQueue: ft.baseQueue,
          queue: ft.queue,
          next: null
        }, Ht === null ? Ue.memoizedState = Ht = e : Ht = Ht.next = e;
      }
      return Ht;
    }
    function Gs() {
      return {
        lastEffect: null,
        events: null,
        stores: null,
        memoCache: null
      };
    }
    function po(e) {
      var t = go;
      return go += 1, Sa === null && (Sa = []), e = bm(Sa, e, t), t = Ue, (Ht === null ? t.memoizedState : Ht.next) === null && (t = t.alternate, $.H = t === null || t.memoizedState === null ? cg : ku), e;
    }
    function Ps(e) {
      if (e !== null && typeof e == "object") {
        if (typeof e.then == "function") return po(e);
        if (e.$$typeof === A) return Qt(e);
      }
      throw Error(o(438, String(e)));
    }
    function gu(e) {
      var t = null, a = Ue.updateQueue;
      if (a !== null && (t = a.memoCache), t == null) {
        var s = Ue.alternate;
        s !== null && (s = s.updateQueue, s !== null && (s = s.memoCache, s != null && (t = {
          data: s.data.map(function(u) {
            return u.slice();
          }),
          index: 0
        })));
      }
      if (t == null && (t = {
        data: [],
        index: 0
      }), a === null && (a = Gs(), Ue.updateQueue = a), a.memoCache = t, a = t.data[t.index], a === void 0) for (a = t.data[t.index] = Array(e), s = 0; s < e; s++) a[s] = q;
      return t.index++, a;
    }
    function Sl(e, t) {
      return typeof t == "function" ? t(e) : t;
    }
    function Ks(e) {
      var t = Ot();
      return pu(t, ft, e);
    }
    function pu(e, t, a) {
      var s = e.queue;
      if (s === null) throw Error(o(311));
      s.lastRenderedReducer = a;
      var u = e.baseQueue, h = s.pending;
      if (h !== null) {
        if (u !== null) {
          var w = u.next;
          u.next = h.next, h.next = w;
        }
        t.baseQueue = u = h, s.pending = null;
      }
      if (h = e.baseState, u === null) e.memoizedState = h;
      else {
        t = u.next;
        var M = w = null, z = null, P = t, ne = false;
        do {
          var oe = P.lane & -536870913;
          if (oe !== P.lane ? (Ze & oe) === oe : (wl & oe) === oe) {
            var Z = P.revertLane;
            if (Z === 0) z !== null && (z = z.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: P.action,
              hasEagerState: P.hasEagerState,
              eagerState: P.eagerState,
              next: null
            }), oe === pa && (ne = true);
            else if ((wl & Z) === Z) {
              P = P.next, Z === pa && (ne = true);
              continue;
            } else oe = {
              lane: 0,
              revertLane: P.revertLane,
              gesture: null,
              action: P.action,
              hasEagerState: P.hasEagerState,
              eagerState: P.eagerState,
              next: null
            }, z === null ? (M = z = oe, w = h) : z = z.next = oe, Ue.lanes |= Z, tr |= Z;
            oe = P.action, Ur && a(h, oe), h = P.hasEagerState ? P.eagerState : a(h, oe);
          } else Z = {
            lane: oe,
            revertLane: P.revertLane,
            gesture: P.gesture,
            action: P.action,
            hasEagerState: P.hasEagerState,
            eagerState: P.eagerState,
            next: null
          }, z === null ? (M = z = Z, w = h) : z = z.next = Z, Ue.lanes |= oe, tr |= oe;
          P = P.next;
        } while (P !== null && P !== t);
        if (z === null ? w = h : z.next = M, !xn(h, e.memoizedState) && (Ut = true, ne && (a = ya, a !== null))) throw a;
        e.memoizedState = h, e.baseState = w, e.baseQueue = z, s.lastRenderedState = h;
      }
      return u === null && (s.lanes = 0), [
        e.memoizedState,
        s.dispatch
      ];
    }
    function yu(e) {
      var t = Ot(), a = t.queue;
      if (a === null) throw Error(o(311));
      a.lastRenderedReducer = e;
      var s = a.dispatch, u = a.pending, h = t.memoizedState;
      if (u !== null) {
        a.pending = null;
        var w = u = u.next;
        do
          h = e(h, w.action), w = w.next;
        while (w !== u);
        xn(h, t.memoizedState) || (Ut = true), t.memoizedState = h, t.baseQueue === null && (t.baseState = h), a.lastRenderedState = h;
      }
      return [
        h,
        s
      ];
    }
    function Lm(e, t, a) {
      var s = Ue, u = Ot(), h = Qe;
      if (h) {
        if (a === void 0) throw Error(o(407));
        a = a();
      } else a = t();
      var w = !xn((ft || u).memoizedState, a);
      if (w && (u.memoizedState = a, Ut = true), u = u.queue, xu(Tm.bind(null, s, u, e), [
        e
      ]), u.getSnapshot !== t || w || Ht !== null && Ht.memoizedState.tag & 1) {
        if (s.flags |= 2048, Ca(9, {
          destroy: void 0
        }, Am.bind(null, s, u, a, t), null), pt === null) throw Error(o(349));
        h || (wl & 127) !== 0 || Rm(s, t, a);
      }
      return a;
    }
    function Rm(e, t, a) {
      e.flags |= 16384, e = {
        getSnapshot: t,
        value: a
      }, t = Ue.updateQueue, t === null ? (t = Gs(), Ue.updateQueue = t, t.stores = [
        e
      ]) : (a = t.stores, a === null ? t.stores = [
        e
      ] : a.push(e));
    }
    function Am(e, t, a, s) {
      t.value = a, t.getSnapshot = s, Nm(t) && Om(e);
    }
    function Tm(e, t, a) {
      return a(function() {
        Nm(t) && Om(e);
      });
    }
    function Nm(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var a = t();
        return !xn(e, a);
      } catch {
        return true;
      }
    }
    function Om(e) {
      var t = Rr(e, 2);
      t !== null && yn(t, e, 2);
    }
    function bu(e) {
      var t = sn();
      if (typeof e == "function") {
        var a = e;
        if (e = a(), Ur) {
          Vt(true);
          try {
            a();
          } finally {
            Vt(false);
          }
        }
      }
      return t.memoizedState = t.baseState = e, t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Sl,
        lastRenderedState: e
      }, t;
    }
    function Im(e, t, a, s) {
      return e.baseState = a, pu(e, ft, typeof s == "function" ? s : Sl);
    }
    function $x(e, t, a, s, u) {
      if (Qs(e)) throw Error(o(485));
      if (e = t.action, e !== null) {
        var h = {
          payload: u,
          action: e,
          next: null,
          isTransition: true,
          status: "pending",
          value: null,
          reason: null,
          listeners: [],
          then: function(w) {
            h.listeners.push(w);
          }
        };
        $.T !== null ? a(true) : h.isTransition = false, s(h), a = t.pending, a === null ? (h.next = t.pending = h, Dm(t, h)) : (h.next = a.next, t.pending = a.next = h);
      }
    }
    function Dm(e, t) {
      var a = t.action, s = t.payload, u = e.state;
      if (t.isTransition) {
        var h = $.T, w = {};
        $.T = w;
        try {
          var M = a(u, s), z = $.S;
          z !== null && z(w, M), zm(e, t, M);
        } catch (P) {
          vu(e, t, P);
        } finally {
          h !== null && w.types !== null && (h.types = w.types), $.T = h;
        }
      } else try {
        h = a(u, s), zm(e, t, h);
      } catch (P) {
        vu(e, t, P);
      }
    }
    function zm(e, t, a) {
      a !== null && typeof a == "object" && typeof a.then == "function" ? a.then(function(s) {
        Hm(e, t, s);
      }, function(s) {
        return vu(e, t, s);
      }) : Hm(e, t, a);
    }
    function Hm(e, t, a) {
      t.status = "fulfilled", t.value = a, Um(t), e.state = a, t = e.pending, t !== null && (a = t.next, a === t ? e.pending = null : (a = a.next, t.next = a, Dm(e, a)));
    }
    function vu(e, t, a) {
      var s = e.pending;
      if (e.pending = null, s !== null) {
        s = s.next;
        do
          t.status = "rejected", t.reason = a, Um(t), t = t.next;
        while (t !== s);
      }
      e.action = null;
    }
    function Um(e) {
      e = e.listeners;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
    function Ym(e, t) {
      return t;
    }
    function Bm(e, t) {
      if (Qe) {
        var a = pt.formState;
        if (a !== null) {
          e: {
            var s = Ue;
            if (Qe) {
              if (wt) {
                t: {
                  for (var u = wt, h = In; u.nodeType !== 8; ) {
                    if (!h) {
                      u = null;
                      break t;
                    }
                    if (u = zn(u.nextSibling), u === null) {
                      u = null;
                      break t;
                    }
                  }
                  h = u.data, u = h === "F!" || h === "F" ? u : null;
                }
                if (u) {
                  wt = zn(u.nextSibling), s = u.data === "F!";
                  break e;
                }
              }
              Gl(s);
            }
            s = false;
          }
          s && (t = a[0]);
        }
      }
      return a = sn(), a.memoizedState = a.baseState = t, s = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Ym,
        lastRenderedState: t
      }, a.queue = s, a = og.bind(null, Ue, s), s.dispatch = a, s = bu(false), h = _u.bind(null, Ue, false, s.queue), s = sn(), u = {
        state: t,
        dispatch: null,
        action: e,
        pending: null
      }, s.queue = u, a = $x.bind(null, Ue, u, h, a), u.dispatch = a, s.memoizedState = e, [
        t,
        a,
        false
      ];
    }
    function Xm(e) {
      var t = Ot();
      return Vm(t, ft, e);
    }
    function Vm(e, t, a) {
      if (t = pu(e, t, Ym)[0], e = Ks(Sl)[0], typeof t == "object" && t !== null && typeof t.then == "function") try {
        var s = po(t);
      } catch (w) {
        throw w === ba ? Hs : w;
      }
      else s = t;
      t = Ot();
      var u = t.queue, h = u.dispatch;
      return a !== t.memoizedState && (Ue.flags |= 2048, Ca(9, {
        destroy: void 0
      }, qx.bind(null, u, a), null)), [
        s,
        h,
        e
      ];
    }
    function qx(e, t) {
      e.action = t;
    }
    function $m(e) {
      var t = Ot(), a = ft;
      if (a !== null) return Vm(t, a, e);
      Ot(), t = t.memoizedState, a = Ot();
      var s = a.queue.dispatch;
      return a.memoizedState = e, [
        t,
        s,
        false
      ];
    }
    function Ca(e, t, a, s) {
      return e = {
        tag: e,
        create: a,
        deps: s,
        inst: t,
        next: null
      }, t = Ue.updateQueue, t === null && (t = Gs(), Ue.updateQueue = t), a = t.lastEffect, a === null ? t.lastEffect = e.next = e : (s = a.next, a.next = e, e.next = s, t.lastEffect = e), e;
    }
    function qm() {
      return Ot().memoizedState;
    }
    function Zs(e, t, a, s) {
      var u = sn();
      Ue.flags |= e, u.memoizedState = Ca(1 | t, {
        destroy: void 0
      }, a, s === void 0 ? null : s);
    }
    function Fs(e, t, a, s) {
      var u = Ot();
      s = s === void 0 ? null : s;
      var h = u.memoizedState.inst;
      ft !== null && s !== null && uu(s, ft.memoizedState.deps) ? u.memoizedState = Ca(t, h, a, s) : (Ue.flags |= e, u.memoizedState = Ca(1 | t, h, a, s));
    }
    function Gm(e, t) {
      Zs(8390656, 8, e, t);
    }
    function xu(e, t) {
      Fs(2048, 8, e, t);
    }
    function Gx(e) {
      Ue.flags |= 4;
      var t = Ue.updateQueue;
      if (t === null) t = Gs(), Ue.updateQueue = t, t.events = [
        e
      ];
      else {
        var a = t.events;
        a === null ? t.events = [
          e
        ] : a.push(e);
      }
    }
    function Pm(e) {
      var t = Ot().memoizedState;
      return Gx({
        ref: t,
        nextImpl: e
      }), function() {
        if ((rt & 2) !== 0) throw Error(o(440));
        return t.impl.apply(void 0, arguments);
      };
    }
    function Km(e, t) {
      return Fs(4, 2, e, t);
    }
    function Zm(e, t) {
      return Fs(4, 4, e, t);
    }
    function Fm(e, t) {
      if (typeof t == "function") {
        e = e();
        var a = t(e);
        return function() {
          typeof a == "function" ? a() : t(null);
        };
      }
      if (t != null) return e = e(), t.current = e, function() {
        t.current = null;
      };
    }
    function Qm(e, t, a) {
      a = a != null ? a.concat([
        e
      ]) : null, Fs(4, 4, Fm.bind(null, t, e), a);
    }
    function wu() {
    }
    function Wm(e, t) {
      var a = Ot();
      t = t === void 0 ? null : t;
      var s = a.memoizedState;
      return t !== null && uu(t, s[1]) ? s[0] : (a.memoizedState = [
        e,
        t
      ], e);
    }
    function Jm(e, t) {
      var a = Ot();
      t = t === void 0 ? null : t;
      var s = a.memoizedState;
      if (t !== null && uu(t, s[1])) return s[0];
      if (s = e(), Ur) {
        Vt(true);
        try {
          e();
        } finally {
          Vt(false);
        }
      }
      return a.memoizedState = [
        s,
        t
      ], s;
    }
    function Su(e, t, a) {
      return a === void 0 || (wl & 1073741824) !== 0 && (Ze & 261930) === 0 ? e.memoizedState = t : (e.memoizedState = a, e = ep(), Ue.lanes |= e, tr |= e, a);
    }
    function eg(e, t, a, s) {
      return xn(a, t) ? a : xa.current !== null ? (e = Su(e, a, s), xn(e, t) || (Ut = true), e) : (wl & 42) === 0 || (wl & 1073741824) !== 0 && (Ze & 261930) === 0 ? (Ut = true, e.memoizedState = a) : (e = ep(), Ue.lanes |= e, tr |= e, t);
    }
    function tg(e, t, a, s, u) {
      var h = F.p;
      F.p = h !== 0 && 8 > h ? h : 8;
      var w = $.T, M = {};
      $.T = M, _u(e, false, t, a);
      try {
        var z = u(), P = $.S;
        if (P !== null && P(M, z), z !== null && typeof z == "object" && typeof z.then == "function") {
          var ne = Bx(z, s);
          yo(e, t, ne, kn(e));
        } else yo(e, t, s, kn(e));
      } catch (oe) {
        yo(e, t, {
          then: function() {
          },
          status: "rejected",
          reason: oe
        }, kn());
      } finally {
        F.p = h, w !== null && M.types !== null && (w.types = M.types), $.T = w;
      }
    }
    function Px() {
    }
    function Cu(e, t, a, s) {
      if (e.tag !== 5) throw Error(o(476));
      var u = ng(e).queue;
      tg(e, u, t, fe, a === null ? Px : function() {
        return lg(e), a(s);
      });
    }
    function ng(e) {
      var t = e.memoizedState;
      if (t !== null) return t;
      t = {
        memoizedState: fe,
        baseState: fe,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Sl,
          lastRenderedState: fe
        },
        next: null
      };
      var a = {};
      return t.next = {
        memoizedState: a,
        baseState: a,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Sl,
          lastRenderedState: a
        },
        next: null
      }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
    }
    function lg(e) {
      var t = ng(e);
      t.next === null && (t = e.alternate.memoizedState), yo(e, t.next.queue, {}, kn());
    }
    function Eu() {
      return Qt(Oo);
    }
    function rg() {
      return Ot().memoizedState;
    }
    function ag() {
      return Ot().memoizedState;
    }
    function Kx(e) {
      for (var t = e.return; t !== null; ) {
        switch (t.tag) {
          case 24:
          case 3:
            var a = kn();
            e = Zl(a);
            var s = Fl(t, e, a);
            s !== null && (yn(s, t, a), fo(s, t, a)), t = {
              cache: Jc()
            }, e.payload = t;
            return;
        }
        t = t.return;
      }
    }
    function Zx(e, t, a) {
      var s = kn();
      a = {
        lane: s,
        revertLane: 0,
        gesture: null,
        action: a,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, Qs(e) ? sg(t, a) : (a = Xc(e, t, a, s), a !== null && (yn(a, e, s), ig(a, t, s)));
    }
    function og(e, t, a) {
      var s = kn();
      yo(e, t, a, s);
    }
    function yo(e, t, a, s) {
      var u = {
        lane: s,
        revertLane: 0,
        gesture: null,
        action: a,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      if (Qs(e)) sg(t, u);
      else {
        var h = e.alternate;
        if (e.lanes === 0 && (h === null || h.lanes === 0) && (h = t.lastRenderedReducer, h !== null)) try {
          var w = t.lastRenderedState, M = h(w, a);
          if (u.hasEagerState = true, u.eagerState = M, xn(M, w)) return As(e, t, u, 0), pt === null && Rs(), false;
        } catch {
        } finally {
        }
        if (a = Xc(e, t, u, s), a !== null) return yn(a, e, s), ig(a, t, s), true;
      }
      return false;
    }
    function _u(e, t, a, s) {
      if (s = {
        lane: 2,
        revertLane: ld(),
        gesture: null,
        action: s,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, Qs(e)) {
        if (t) throw Error(o(479));
      } else t = Xc(e, a, s, 2), t !== null && yn(t, e, 2);
    }
    function Qs(e) {
      var t = e.alternate;
      return e === Ue || t !== null && t === Ue;
    }
    function sg(e, t) {
      wa = $s = true;
      var a = e.pending;
      a === null ? t.next = t : (t.next = a.next, a.next = t), e.pending = t;
    }
    function ig(e, t, a) {
      if ((a & 4194048) !== 0) {
        var s = t.lanes;
        s &= e.pendingLanes, a |= s, t.lanes = a, bs(e, a);
      }
    }
    var bo = {
      readContext: Qt,
      use: Ps,
      useCallback: Rt,
      useContext: Rt,
      useEffect: Rt,
      useImperativeHandle: Rt,
      useLayoutEffect: Rt,
      useInsertionEffect: Rt,
      useMemo: Rt,
      useReducer: Rt,
      useRef: Rt,
      useState: Rt,
      useDebugValue: Rt,
      useDeferredValue: Rt,
      useTransition: Rt,
      useSyncExternalStore: Rt,
      useId: Rt,
      useHostTransitionStatus: Rt,
      useFormState: Rt,
      useActionState: Rt,
      useOptimistic: Rt,
      useMemoCache: Rt,
      useCacheRefresh: Rt
    };
    bo.useEffectEvent = Rt;
    var cg = {
      readContext: Qt,
      use: Ps,
      useCallback: function(e, t) {
        return sn().memoizedState = [
          e,
          t === void 0 ? null : t
        ], e;
      },
      useContext: Qt,
      useEffect: Gm,
      useImperativeHandle: function(e, t, a) {
        a = a != null ? a.concat([
          e
        ]) : null, Zs(4194308, 4, Fm.bind(null, t, e), a);
      },
      useLayoutEffect: function(e, t) {
        return Zs(4194308, 4, e, t);
      },
      useInsertionEffect: function(e, t) {
        Zs(4, 2, e, t);
      },
      useMemo: function(e, t) {
        var a = sn();
        t = t === void 0 ? null : t;
        var s = e();
        if (Ur) {
          Vt(true);
          try {
            e();
          } finally {
            Vt(false);
          }
        }
        return a.memoizedState = [
          s,
          t
        ], s;
      },
      useReducer: function(e, t, a) {
        var s = sn();
        if (a !== void 0) {
          var u = a(t);
          if (Ur) {
            Vt(true);
            try {
              a(t);
            } finally {
              Vt(false);
            }
          }
        } else u = t;
        return s.memoizedState = s.baseState = u, e = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: e,
          lastRenderedState: u
        }, s.queue = e, e = e.dispatch = Zx.bind(null, Ue, e), [
          s.memoizedState,
          e
        ];
      },
      useRef: function(e) {
        var t = sn();
        return e = {
          current: e
        }, t.memoizedState = e;
      },
      useState: function(e) {
        e = bu(e);
        var t = e.queue, a = og.bind(null, Ue, t);
        return t.dispatch = a, [
          e.memoizedState,
          a
        ];
      },
      useDebugValue: wu,
      useDeferredValue: function(e, t) {
        var a = sn();
        return Su(a, e, t);
      },
      useTransition: function() {
        var e = bu(false);
        return e = tg.bind(null, Ue, e.queue, true, false), sn().memoizedState = e, [
          false,
          e
        ];
      },
      useSyncExternalStore: function(e, t, a) {
        var s = Ue, u = sn();
        if (Qe) {
          if (a === void 0) throw Error(o(407));
          a = a();
        } else {
          if (a = t(), pt === null) throw Error(o(349));
          (Ze & 127) !== 0 || Rm(s, t, a);
        }
        u.memoizedState = a;
        var h = {
          value: a,
          getSnapshot: t
        };
        return u.queue = h, Gm(Tm.bind(null, s, h, e), [
          e
        ]), s.flags |= 2048, Ca(9, {
          destroy: void 0
        }, Am.bind(null, s, h, a, t), null), a;
      },
      useId: function() {
        var e = sn(), t = pt.identifierPrefix;
        if (Qe) {
          var a = ol, s = al;
          a = (s & ~(1 << 32 - jt(s) - 1)).toString(32) + a, t = "_" + t + "R_" + a, a = qs++, 0 < a && (t += "H" + a.toString(32)), t += "_";
        } else a = Xx++, t = "_" + t + "r_" + a.toString(32) + "_";
        return e.memoizedState = t;
      },
      useHostTransitionStatus: Eu,
      useFormState: Bm,
      useActionState: Bm,
      useOptimistic: function(e) {
        var t = sn();
        t.memoizedState = t.baseState = e;
        var a = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: null,
          lastRenderedState: null
        };
        return t.queue = a, t = _u.bind(null, Ue, true, a), a.dispatch = t, [
          e,
          t
        ];
      },
      useMemoCache: gu,
      useCacheRefresh: function() {
        return sn().memoizedState = Kx.bind(null, Ue);
      },
      useEffectEvent: function(e) {
        var t = sn(), a = {
          impl: e
        };
        return t.memoizedState = a, function() {
          if ((rt & 2) !== 0) throw Error(o(440));
          return a.impl.apply(void 0, arguments);
        };
      }
    }, ku = {
      readContext: Qt,
      use: Ps,
      useCallback: Wm,
      useContext: Qt,
      useEffect: xu,
      useImperativeHandle: Qm,
      useInsertionEffect: Km,
      useLayoutEffect: Zm,
      useMemo: Jm,
      useReducer: Ks,
      useRef: qm,
      useState: function() {
        return Ks(Sl);
      },
      useDebugValue: wu,
      useDeferredValue: function(e, t) {
        var a = Ot();
        return eg(a, ft.memoizedState, e, t);
      },
      useTransition: function() {
        var e = Ks(Sl)[0], t = Ot().memoizedState;
        return [
          typeof e == "boolean" ? e : po(e),
          t
        ];
      },
      useSyncExternalStore: Lm,
      useId: rg,
      useHostTransitionStatus: Eu,
      useFormState: Xm,
      useActionState: Xm,
      useOptimistic: function(e, t) {
        var a = Ot();
        return Im(a, ft, e, t);
      },
      useMemoCache: gu,
      useCacheRefresh: ag
    };
    ku.useEffectEvent = Pm;
    var ug = {
      readContext: Qt,
      use: Ps,
      useCallback: Wm,
      useContext: Qt,
      useEffect: xu,
      useImperativeHandle: Qm,
      useInsertionEffect: Km,
      useLayoutEffect: Zm,
      useMemo: Jm,
      useReducer: yu,
      useRef: qm,
      useState: function() {
        return yu(Sl);
      },
      useDebugValue: wu,
      useDeferredValue: function(e, t) {
        var a = Ot();
        return ft === null ? Su(a, e, t) : eg(a, ft.memoizedState, e, t);
      },
      useTransition: function() {
        var e = yu(Sl)[0], t = Ot().memoizedState;
        return [
          typeof e == "boolean" ? e : po(e),
          t
        ];
      },
      useSyncExternalStore: Lm,
      useId: rg,
      useHostTransitionStatus: Eu,
      useFormState: $m,
      useActionState: $m,
      useOptimistic: function(e, t) {
        var a = Ot();
        return ft !== null ? Im(a, ft, e, t) : (a.baseState = e, [
          e,
          a.queue.dispatch
        ]);
      },
      useMemoCache: gu,
      useCacheRefresh: ag
    };
    ug.useEffectEvent = Pm;
    function Mu(e, t, a, s) {
      t = e.memoizedState, a = a(s, t), a = a == null ? t : b({}, t, a), e.memoizedState = a, e.lanes === 0 && (e.updateQueue.baseState = a);
    }
    var ju = {
      enqueueSetState: function(e, t, a) {
        e = e._reactInternals;
        var s = kn(), u = Zl(s);
        u.payload = t, a != null && (u.callback = a), t = Fl(e, u, s), t !== null && (yn(t, e, s), fo(t, e, s));
      },
      enqueueReplaceState: function(e, t, a) {
        e = e._reactInternals;
        var s = kn(), u = Zl(s);
        u.tag = 1, u.payload = t, a != null && (u.callback = a), t = Fl(e, u, s), t !== null && (yn(t, e, s), fo(t, e, s));
      },
      enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var a = kn(), s = Zl(a);
        s.tag = 2, t != null && (s.callback = t), t = Fl(e, s, a), t !== null && (yn(t, e, a), fo(t, e, a));
      }
    };
    function dg(e, t, a, s, u, h, w) {
      return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(s, h, w) : t.prototype && t.prototype.isPureReactComponent ? !lo(a, s) || !lo(u, h) : true;
    }
    function fg(e, t, a, s) {
      e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(a, s), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(a, s), t.state !== e && ju.enqueueReplaceState(t, t.state, null);
    }
    function Yr(e, t) {
      var a = t;
      if ("ref" in t) {
        a = {};
        for (var s in t) s !== "ref" && (a[s] = t[s]);
      }
      if (e = e.defaultProps) {
        a === t && (a = b({}, a));
        for (var u in e) a[u] === void 0 && (a[u] = e[u]);
      }
      return a;
    }
    function hg(e) {
      Ls(e);
    }
    function mg(e) {
      console.error(e);
    }
    function gg(e) {
      Ls(e);
    }
    function Ws(e, t) {
      try {
        var a = e.onUncaughtError;
        a(t.value, {
          componentStack: t.stack
        });
      } catch (s) {
        setTimeout(function() {
          throw s;
        });
      }
    }
    function pg(e, t, a) {
      try {
        var s = e.onCaughtError;
        s(a.value, {
          componentStack: a.stack,
          errorBoundary: t.tag === 1 ? t.stateNode : null
        });
      } catch (u) {
        setTimeout(function() {
          throw u;
        });
      }
    }
    function Lu(e, t, a) {
      return a = Zl(a), a.tag = 3, a.payload = {
        element: null
      }, a.callback = function() {
        Ws(e, t);
      }, a;
    }
    function yg(e) {
      return e = Zl(e), e.tag = 3, e;
    }
    function bg(e, t, a, s) {
      var u = a.type.getDerivedStateFromError;
      if (typeof u == "function") {
        var h = s.value;
        e.payload = function() {
          return u(h);
        }, e.callback = function() {
          pg(t, a, s);
        };
      }
      var w = a.stateNode;
      w !== null && typeof w.componentDidCatch == "function" && (e.callback = function() {
        pg(t, a, s), typeof u != "function" && (nr === null ? nr = /* @__PURE__ */ new Set([
          this
        ]) : nr.add(this));
        var M = s.stack;
        this.componentDidCatch(s.value, {
          componentStack: M !== null ? M : ""
        });
      });
    }
    function Fx(e, t, a, s, u) {
      if (a.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
        if (t = a.alternate, t !== null && ga(t, a, u, true), a = Sn.current, a !== null) {
          switch (a.tag) {
            case 31:
            case 13:
              return Dn === null ? ui() : a.alternate === null && At === 0 && (At = 3), a.flags &= -257, a.flags |= 65536, a.lanes = u, s === Us ? a.flags |= 16384 : (t = a.updateQueue, t === null ? a.updateQueue = /* @__PURE__ */ new Set([
                s
              ]) : t.add(s), ed(e, s, u)), false;
            case 22:
              return a.flags |= 65536, s === Us ? a.flags |= 16384 : (t = a.updateQueue, t === null ? (t = {
                transitions: null,
                markerInstances: null,
                retryQueue: /* @__PURE__ */ new Set([
                  s
                ])
              }, a.updateQueue = t) : (a = t.retryQueue, a === null ? t.retryQueue = /* @__PURE__ */ new Set([
                s
              ]) : a.add(s)), ed(e, s, u)), false;
          }
          throw Error(o(435, a.tag));
        }
        return ed(e, s, u), ui(), false;
      }
      if (Qe) return t = Sn.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = u, s !== Kc && (e = Error(o(422), {
        cause: s
      }), oo(Tn(e, a)))) : (s !== Kc && (t = Error(o(423), {
        cause: s
      }), oo(Tn(t, a))), e = e.current.alternate, e.flags |= 65536, u &= -u, e.lanes |= u, s = Tn(s, a), u = Lu(e.stateNode, s, u), au(e, u), At !== 4 && (At = 2)), false;
      var h = Error(o(520), {
        cause: s
      });
      if (h = Tn(h, a), ko === null ? ko = [
        h
      ] : ko.push(h), At !== 4 && (At = 2), t === null) return true;
      s = Tn(s, a), a = t;
      do {
        switch (a.tag) {
          case 3:
            return a.flags |= 65536, e = u & -u, a.lanes |= e, e = Lu(a.stateNode, s, e), au(a, e), false;
          case 1:
            if (t = a.type, h = a.stateNode, (a.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || h !== null && typeof h.componentDidCatch == "function" && (nr === null || !nr.has(h)))) return a.flags |= 65536, u &= -u, a.lanes |= u, u = yg(u), bg(u, e, a, s), au(a, u), false;
        }
        a = a.return;
      } while (a !== null);
      return false;
    }
    var Ru = Error(o(461)), Ut = false;
    function Wt(e, t, a, s) {
      t.child = e === null ? Sm(t, null, a, s) : Hr(t, e.child, a, s);
    }
    function vg(e, t, a, s, u) {
      a = a.render;
      var h = t.ref;
      if ("ref" in s) {
        var w = {};
        for (var M in s) M !== "ref" && (w[M] = s[M]);
      } else w = s;
      return Or(t), s = du(e, t, a, w, h, u), M = fu(), e !== null && !Ut ? (hu(e, t, u), Cl(e, t, u)) : (Qe && M && Gc(t), t.flags |= 1, Wt(e, t, s, u), t.child);
    }
    function xg(e, t, a, s, u) {
      if (e === null) {
        var h = a.type;
        return typeof h == "function" && !Vc(h) && h.defaultProps === void 0 && a.compare === null ? (t.tag = 15, t.type = h, wg(e, t, h, s, u)) : (e = Ns(a.type, null, s, t, t.mode, u), e.ref = t.ref, e.return = t, t.child = e);
      }
      if (h = e.child, !Hu(e, u)) {
        var w = h.memoizedProps;
        if (a = a.compare, a = a !== null ? a : lo, a(w, s) && e.ref === t.ref) return Cl(e, t, u);
      }
      return t.flags |= 1, e = yl(h, s), e.ref = t.ref, e.return = t, t.child = e;
    }
    function wg(e, t, a, s, u) {
      if (e !== null) {
        var h = e.memoizedProps;
        if (lo(h, s) && e.ref === t.ref) if (Ut = false, t.pendingProps = s = h, Hu(e, u)) (e.flags & 131072) !== 0 && (Ut = true);
        else return t.lanes = e.lanes, Cl(e, t, u);
      }
      return Au(e, t, a, s, u);
    }
    function Sg(e, t, a, s) {
      var u = s.children, h = e !== null ? e.memoizedState : null;
      if (e === null && t.stateNode === null && (t.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      }), s.mode === "hidden") {
        if ((t.flags & 128) !== 0) {
          if (h = h !== null ? h.baseLanes | a : a, e !== null) {
            for (s = t.child = e.child, u = 0; s !== null; ) u = u | s.lanes | s.childLanes, s = s.sibling;
            s = u & ~h;
          } else s = 0, t.child = null;
          return Cg(e, t, h, a, s);
        }
        if ((a & 536870912) !== 0) t.memoizedState = {
          baseLanes: 0,
          cachePool: null
        }, e !== null && zs(t, h !== null ? h.cachePool : null), h !== null ? _m(t, h) : su(), km(t);
        else return s = t.lanes = 536870912, Cg(e, t, h !== null ? h.baseLanes | a : a, a, s);
      } else h !== null ? (zs(t, h.cachePool), _m(t, h), Wl(), t.memoizedState = null) : (e !== null && zs(t, null), su(), Wl());
      return Wt(e, t, u, a), t.child;
    }
    function vo(e, t) {
      return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      }), t.sibling;
    }
    function Cg(e, t, a, s, u) {
      var h = tu();
      return h = h === null ? null : {
        parent: zt._currentValue,
        pool: h
      }, t.memoizedState = {
        baseLanes: a,
        cachePool: h
      }, e !== null && zs(t, null), su(), km(t), e !== null && ga(e, t, s, true), t.childLanes = u, null;
    }
    function Js(e, t) {
      return t = ti({
        mode: t.mode,
        children: t.children
      }, e.mode), t.ref = e.ref, e.child = t, t.return = e, t;
    }
    function Eg(e, t, a) {
      return Hr(t, e.child, null, a), e = Js(t, t.pendingProps), e.flags |= 2, Cn(t), t.memoizedState = null, e;
    }
    function Qx(e, t, a) {
      var s = t.pendingProps, u = (t.flags & 128) !== 0;
      if (t.flags &= -129, e === null) {
        if (Qe) {
          if (s.mode === "hidden") return e = Js(t, s), t.lanes = 536870912, vo(null, e);
          if (cu(t), (e = wt) ? (e = Dp(e, In), e = e !== null && e.data === "&" ? e : null, e !== null && (t.memoizedState = {
            dehydrated: e,
            treeContext: $l !== null ? {
              id: al,
              overflow: ol
            } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, a = sm(e), a.return = t, t.child = a, Ft = t, wt = null)) : e = null, e === null) throw Gl(t);
          return t.lanes = 536870912, null;
        }
        return Js(t, s);
      }
      var h = e.memoizedState;
      if (h !== null) {
        var w = h.dehydrated;
        if (cu(t), u) if (t.flags & 256) t.flags &= -257, t = Eg(e, t, a);
        else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
        else throw Error(o(558));
        else if (Ut || ga(e, t, a, false), u = (a & e.childLanes) !== 0, Ut || u) {
          if (s = pt, s !== null && (w = vs(s, a), w !== 0 && w !== h.retryLane)) throw h.retryLane = w, Rr(e, w), yn(s, e, w), Ru;
          ui(), t = Eg(e, t, a);
        } else e = h.treeContext, wt = zn(w.nextSibling), Ft = t, Qe = true, ql = null, In = false, e !== null && um(t, e), t = Js(t, s), t.flags |= 4096;
        return t;
      }
      return e = yl(e.child, {
        mode: s.mode,
        children: s.children
      }), e.ref = t.ref, t.child = e, e.return = t, e;
    }
    function ei(e, t) {
      var a = t.ref;
      if (a === null) e !== null && e.ref !== null && (t.flags |= 4194816);
      else {
        if (typeof a != "function" && typeof a != "object") throw Error(o(284));
        (e === null || e.ref !== a) && (t.flags |= 4194816);
      }
    }
    function Au(e, t, a, s, u) {
      return Or(t), a = du(e, t, a, s, void 0, u), s = fu(), e !== null && !Ut ? (hu(e, t, u), Cl(e, t, u)) : (Qe && s && Gc(t), t.flags |= 1, Wt(e, t, a, u), t.child);
    }
    function _g(e, t, a, s, u, h) {
      return Or(t), t.updateQueue = null, a = jm(t, s, a, u), Mm(e), s = fu(), e !== null && !Ut ? (hu(e, t, h), Cl(e, t, h)) : (Qe && s && Gc(t), t.flags |= 1, Wt(e, t, a, h), t.child);
    }
    function kg(e, t, a, s, u) {
      if (Or(t), t.stateNode === null) {
        var h = da, w = a.contextType;
        typeof w == "object" && w !== null && (h = Qt(w)), h = new a(s, h), t.memoizedState = h.state !== null && h.state !== void 0 ? h.state : null, h.updater = ju, t.stateNode = h, h._reactInternals = t, h = t.stateNode, h.props = s, h.state = t.memoizedState, h.refs = {}, lu(t), w = a.contextType, h.context = typeof w == "object" && w !== null ? Qt(w) : da, h.state = t.memoizedState, w = a.getDerivedStateFromProps, typeof w == "function" && (Mu(t, a, w, s), h.state = t.memoizedState), typeof a.getDerivedStateFromProps == "function" || typeof h.getSnapshotBeforeUpdate == "function" || typeof h.UNSAFE_componentWillMount != "function" && typeof h.componentWillMount != "function" || (w = h.state, typeof h.componentWillMount == "function" && h.componentWillMount(), typeof h.UNSAFE_componentWillMount == "function" && h.UNSAFE_componentWillMount(), w !== h.state && ju.enqueueReplaceState(h, h.state, null), mo(t, s, h, u), ho(), h.state = t.memoizedState), typeof h.componentDidMount == "function" && (t.flags |= 4194308), s = true;
      } else if (e === null) {
        h = t.stateNode;
        var M = t.memoizedProps, z = Yr(a, M);
        h.props = z;
        var P = h.context, ne = a.contextType;
        w = da, typeof ne == "object" && ne !== null && (w = Qt(ne));
        var oe = a.getDerivedStateFromProps;
        ne = typeof oe == "function" || typeof h.getSnapshotBeforeUpdate == "function", M = t.pendingProps !== M, ne || typeof h.UNSAFE_componentWillReceiveProps != "function" && typeof h.componentWillReceiveProps != "function" || (M || P !== w) && fg(t, h, s, w), Kl = false;
        var Z = t.memoizedState;
        h.state = Z, mo(t, s, h, u), ho(), P = t.memoizedState, M || Z !== P || Kl ? (typeof oe == "function" && (Mu(t, a, oe, s), P = t.memoizedState), (z = Kl || dg(t, a, z, s, Z, P, w)) ? (ne || typeof h.UNSAFE_componentWillMount != "function" && typeof h.componentWillMount != "function" || (typeof h.componentWillMount == "function" && h.componentWillMount(), typeof h.UNSAFE_componentWillMount == "function" && h.UNSAFE_componentWillMount()), typeof h.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof h.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = s, t.memoizedState = P), h.props = s, h.state = P, h.context = w, s = z) : (typeof h.componentDidMount == "function" && (t.flags |= 4194308), s = false);
      } else {
        h = t.stateNode, ru(e, t), w = t.memoizedProps, ne = Yr(a, w), h.props = ne, oe = t.pendingProps, Z = h.context, P = a.contextType, z = da, typeof P == "object" && P !== null && (z = Qt(P)), M = a.getDerivedStateFromProps, (P = typeof M == "function" || typeof h.getSnapshotBeforeUpdate == "function") || typeof h.UNSAFE_componentWillReceiveProps != "function" && typeof h.componentWillReceiveProps != "function" || (w !== oe || Z !== z) && fg(t, h, s, z), Kl = false, Z = t.memoizedState, h.state = Z, mo(t, s, h, u), ho();
        var Q = t.memoizedState;
        w !== oe || Z !== Q || Kl || e !== null && e.dependencies !== null && Is(e.dependencies) ? (typeof M == "function" && (Mu(t, a, M, s), Q = t.memoizedState), (ne = Kl || dg(t, a, ne, s, Z, Q, z) || e !== null && e.dependencies !== null && Is(e.dependencies)) ? (P || typeof h.UNSAFE_componentWillUpdate != "function" && typeof h.componentWillUpdate != "function" || (typeof h.componentWillUpdate == "function" && h.componentWillUpdate(s, Q, z), typeof h.UNSAFE_componentWillUpdate == "function" && h.UNSAFE_componentWillUpdate(s, Q, z)), typeof h.componentDidUpdate == "function" && (t.flags |= 4), typeof h.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof h.componentDidUpdate != "function" || w === e.memoizedProps && Z === e.memoizedState || (t.flags |= 4), typeof h.getSnapshotBeforeUpdate != "function" || w === e.memoizedProps && Z === e.memoizedState || (t.flags |= 1024), t.memoizedProps = s, t.memoizedState = Q), h.props = s, h.state = Q, h.context = z, s = ne) : (typeof h.componentDidUpdate != "function" || w === e.memoizedProps && Z === e.memoizedState || (t.flags |= 4), typeof h.getSnapshotBeforeUpdate != "function" || w === e.memoizedProps && Z === e.memoizedState || (t.flags |= 1024), s = false);
      }
      return h = s, ei(e, t), s = (t.flags & 128) !== 0, h || s ? (h = t.stateNode, a = s && typeof a.getDerivedStateFromError != "function" ? null : h.render(), t.flags |= 1, e !== null && s ? (t.child = Hr(t, e.child, null, u), t.child = Hr(t, null, a, u)) : Wt(e, t, a, u), t.memoizedState = h.state, e = t.child) : e = Cl(e, t, u), e;
    }
    function Mg(e, t, a, s) {
      return Tr(), t.flags |= 256, Wt(e, t, a, s), t.child;
    }
    var Tu = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null
    };
    function Nu(e) {
      return {
        baseLanes: e,
        cachePool: pm()
      };
    }
    function Ou(e, t, a) {
      return e = e !== null ? e.childLanes & ~a : 0, t && (e |= _n), e;
    }
    function jg(e, t, a) {
      var s = t.pendingProps, u = false, h = (t.flags & 128) !== 0, w;
      if ((w = h) || (w = e !== null && e.memoizedState === null ? false : (Nt.current & 2) !== 0), w && (u = true, t.flags &= -129), w = (t.flags & 32) !== 0, t.flags &= -33, e === null) {
        if (Qe) {
          if (u ? Ql(t) : Wl(), (e = wt) ? (e = Dp(e, In), e = e !== null && e.data !== "&" ? e : null, e !== null && (t.memoizedState = {
            dehydrated: e,
            treeContext: $l !== null ? {
              id: al,
              overflow: ol
            } : null,
            retryLane: 536870912,
            hydrationErrors: null
          }, a = sm(e), a.return = t, t.child = a, Ft = t, wt = null)) : e = null, e === null) throw Gl(t);
          return pd(e) ? t.lanes = 32 : t.lanes = 536870912, null;
        }
        var M = s.children;
        return s = s.fallback, u ? (Wl(), u = t.mode, M = ti({
          mode: "hidden",
          children: M
        }, u), s = Ar(s, u, a, null), M.return = t, s.return = t, M.sibling = s, t.child = M, s = t.child, s.memoizedState = Nu(a), s.childLanes = Ou(e, w, a), t.memoizedState = Tu, vo(null, s)) : (Ql(t), Iu(t, M));
      }
      var z = e.memoizedState;
      if (z !== null && (M = z.dehydrated, M !== null)) {
        if (h) t.flags & 256 ? (Ql(t), t.flags &= -257, t = Du(e, t, a)) : t.memoizedState !== null ? (Wl(), t.child = e.child, t.flags |= 128, t = null) : (Wl(), M = s.fallback, u = t.mode, s = ti({
          mode: "visible",
          children: s.children
        }, u), M = Ar(M, u, a, null), M.flags |= 2, s.return = t, M.return = t, s.sibling = M, t.child = s, Hr(t, e.child, null, a), s = t.child, s.memoizedState = Nu(a), s.childLanes = Ou(e, w, a), t.memoizedState = Tu, t = vo(null, s));
        else if (Ql(t), pd(M)) {
          if (w = M.nextSibling && M.nextSibling.dataset, w) var P = w.dgst;
          w = P, s = Error(o(419)), s.stack = "", s.digest = w, oo({
            value: s,
            source: null,
            stack: null
          }), t = Du(e, t, a);
        } else if (Ut || ga(e, t, a, false), w = (a & e.childLanes) !== 0, Ut || w) {
          if (w = pt, w !== null && (s = vs(w, a), s !== 0 && s !== z.retryLane)) throw z.retryLane = s, Rr(e, s), yn(w, e, s), Ru;
          gd(M) || ui(), t = Du(e, t, a);
        } else gd(M) ? (t.flags |= 192, t.child = e.child, t = null) : (e = z.treeContext, wt = zn(M.nextSibling), Ft = t, Qe = true, ql = null, In = false, e !== null && um(t, e), t = Iu(t, s.children), t.flags |= 4096);
        return t;
      }
      return u ? (Wl(), M = s.fallback, u = t.mode, z = e.child, P = z.sibling, s = yl(z, {
        mode: "hidden",
        children: s.children
      }), s.subtreeFlags = z.subtreeFlags & 65011712, P !== null ? M = yl(P, M) : (M = Ar(M, u, a, null), M.flags |= 2), M.return = t, s.return = t, s.sibling = M, t.child = s, vo(null, s), s = t.child, M = e.child.memoizedState, M === null ? M = Nu(a) : (u = M.cachePool, u !== null ? (z = zt._currentValue, u = u.parent !== z ? {
        parent: z,
        pool: z
      } : u) : u = pm(), M = {
        baseLanes: M.baseLanes | a,
        cachePool: u
      }), s.memoizedState = M, s.childLanes = Ou(e, w, a), t.memoizedState = Tu, vo(e.child, s)) : (Ql(t), a = e.child, e = a.sibling, a = yl(a, {
        mode: "visible",
        children: s.children
      }), a.return = t, a.sibling = null, e !== null && (w = t.deletions, w === null ? (t.deletions = [
        e
      ], t.flags |= 16) : w.push(e)), t.child = a, t.memoizedState = null, a);
    }
    function Iu(e, t) {
      return t = ti({
        mode: "visible",
        children: t
      }, e.mode), t.return = e, e.child = t;
    }
    function ti(e, t) {
      return e = wn(22, e, null, t), e.lanes = 0, e;
    }
    function Du(e, t, a) {
      return Hr(t, e.child, null, a), e = Iu(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
    }
    function Lg(e, t, a) {
      e.lanes |= t;
      var s = e.alternate;
      s !== null && (s.lanes |= t), Qc(e.return, t, a);
    }
    function zu(e, t, a, s, u, h) {
      var w = e.memoizedState;
      w === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: s,
        tail: a,
        tailMode: u,
        treeForkCount: h
      } : (w.isBackwards = t, w.rendering = null, w.renderingStartTime = 0, w.last = s, w.tail = a, w.tailMode = u, w.treeForkCount = h);
    }
    function Rg(e, t, a) {
      var s = t.pendingProps, u = s.revealOrder, h = s.tail;
      s = s.children;
      var w = Nt.current, M = (w & 2) !== 0;
      if (M ? (w = w & 1 | 2, t.flags |= 128) : w &= 1, K(Nt, w), Wt(e, t, s, a), s = Qe ? ao : 0, !M && e !== null && (e.flags & 128) !== 0) e: for (e = t.child; e !== null; ) {
        if (e.tag === 13) e.memoizedState !== null && Lg(e, a, t);
        else if (e.tag === 19) Lg(e, a, t);
        else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue;
        }
        if (e === t) break e;
        for (; e.sibling === null; ) {
          if (e.return === null || e.return === t) break e;
          e = e.return;
        }
        e.sibling.return = e.return, e = e.sibling;
      }
      switch (u) {
        case "forwards":
          for (a = t.child, u = null; a !== null; ) e = a.alternate, e !== null && Vs(e) === null && (u = a), a = a.sibling;
          a = u, a === null ? (u = t.child, t.child = null) : (u = a.sibling, a.sibling = null), zu(t, false, u, a, h, s);
          break;
        case "backwards":
        case "unstable_legacy-backwards":
          for (a = null, u = t.child, t.child = null; u !== null; ) {
            if (e = u.alternate, e !== null && Vs(e) === null) {
              t.child = u;
              break;
            }
            e = u.sibling, u.sibling = a, a = u, u = e;
          }
          zu(t, true, a, null, h, s);
          break;
        case "together":
          zu(t, false, null, null, void 0, s);
          break;
        default:
          t.memoizedState = null;
      }
      return t.child;
    }
    function Cl(e, t, a) {
      if (e !== null && (t.dependencies = e.dependencies), tr |= t.lanes, (a & t.childLanes) === 0) if (e !== null) {
        if (ga(e, t, a, false), (a & t.childLanes) === 0) return null;
      } else return null;
      if (e !== null && t.child !== e.child) throw Error(o(153));
      if (t.child !== null) {
        for (e = t.child, a = yl(e, e.pendingProps), t.child = a, a.return = t; e.sibling !== null; ) e = e.sibling, a = a.sibling = yl(e, e.pendingProps), a.return = t;
        a.sibling = null;
      }
      return t.child;
    }
    function Hu(e, t) {
      return (e.lanes & t) !== 0 ? true : (e = e.dependencies, !!(e !== null && Is(e)));
    }
    function Wx(e, t, a) {
      switch (t.tag) {
        case 3:
          Re(t, t.stateNode.containerInfo), Pl(t, zt, e.memoizedState.cache), Tr();
          break;
        case 27:
        case 5:
          U(t);
          break;
        case 4:
          Re(t, t.stateNode.containerInfo);
          break;
        case 10:
          Pl(t, t.type, t.memoizedProps.value);
          break;
        case 31:
          if (t.memoizedState !== null) return t.flags |= 128, cu(t), null;
          break;
        case 13:
          var s = t.memoizedState;
          if (s !== null) return s.dehydrated !== null ? (Ql(t), t.flags |= 128, null) : (a & t.child.childLanes) !== 0 ? jg(e, t, a) : (Ql(t), e = Cl(e, t, a), e !== null ? e.sibling : null);
          Ql(t);
          break;
        case 19:
          var u = (e.flags & 128) !== 0;
          if (s = (a & t.childLanes) !== 0, s || (ga(e, t, a, false), s = (a & t.childLanes) !== 0), u) {
            if (s) return Rg(e, t, a);
            t.flags |= 128;
          }
          if (u = t.memoizedState, u !== null && (u.rendering = null, u.tail = null, u.lastEffect = null), K(Nt, Nt.current), s) break;
          return null;
        case 22:
          return t.lanes = 0, Sg(e, t, a, t.pendingProps);
        case 24:
          Pl(t, zt, e.memoizedState.cache);
      }
      return Cl(e, t, a);
    }
    function Ag(e, t, a) {
      if (e !== null) if (e.memoizedProps !== t.pendingProps) Ut = true;
      else {
        if (!Hu(e, a) && (t.flags & 128) === 0) return Ut = false, Wx(e, t, a);
        Ut = (e.flags & 131072) !== 0;
      }
      else Ut = false, Qe && (t.flags & 1048576) !== 0 && cm(t, ao, t.index);
      switch (t.lanes = 0, t.tag) {
        case 16:
          e: {
            var s = t.pendingProps;
            if (e = Dr(t.elementType), t.type = e, typeof e == "function") Vc(e) ? (s = Yr(e, s), t.tag = 1, t = kg(null, t, e, s, a)) : (t.tag = 0, t = Au(null, t, e, s, a));
            else {
              if (e != null) {
                var u = e.$$typeof;
                if (u === R) {
                  t.tag = 11, t = vg(null, t, e, s, a);
                  break e;
                } else if (u === L) {
                  t.tag = 14, t = xg(null, t, e, s, a);
                  break e;
                }
              }
              throw t = ge(e) || e, Error(o(306, t, ""));
            }
          }
          return t;
        case 0:
          return Au(e, t, t.type, t.pendingProps, a);
        case 1:
          return s = t.type, u = Yr(s, t.pendingProps), kg(e, t, s, u, a);
        case 3:
          e: {
            if (Re(t, t.stateNode.containerInfo), e === null) throw Error(o(387));
            s = t.pendingProps;
            var h = t.memoizedState;
            u = h.element, ru(e, t), mo(t, s, null, a);
            var w = t.memoizedState;
            if (s = w.cache, Pl(t, zt, s), s !== h.cache && Wc(t, [
              zt
            ], a, true), ho(), s = w.element, h.isDehydrated) if (h = {
              element: s,
              isDehydrated: false,
              cache: w.cache
            }, t.updateQueue.baseState = h, t.memoizedState = h, t.flags & 256) {
              t = Mg(e, t, s, a);
              break e;
            } else if (s !== u) {
              u = Tn(Error(o(424)), t), oo(u), t = Mg(e, t, s, a);
              break e;
            } else {
              switch (e = t.stateNode.containerInfo, e.nodeType) {
                case 9:
                  e = e.body;
                  break;
                default:
                  e = e.nodeName === "HTML" ? e.ownerDocument.body : e;
              }
              for (wt = zn(e.firstChild), Ft = t, Qe = true, ql = null, In = true, a = Sm(t, null, s, a), t.child = a; a; ) a.flags = a.flags & -3 | 4096, a = a.sibling;
            }
            else {
              if (Tr(), s === u) {
                t = Cl(e, t, a);
                break e;
              }
              Wt(e, t, s, a);
            }
            t = t.child;
          }
          return t;
        case 26:
          return ei(e, t), e === null ? (a = Xp(t.type, null, t.pendingProps, null)) ? t.memoizedState = a : Qe || (a = t.type, e = t.pendingProps, s = yi(ie.current).createElement(a), s[$t] = t, s[le] = e, Jt(s, a, e), it(s), t.stateNode = s) : t.memoizedState = Xp(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
        case 27:
          return U(t), e === null && Qe && (s = t.stateNode = Up(t.type, t.pendingProps, ie.current), Ft = t, In = true, u = wt, or(t.type) ? (yd = u, wt = zn(s.firstChild)) : wt = u), Wt(e, t, t.pendingProps.children, a), ei(e, t), e === null && (t.flags |= 4194304), t.child;
        case 5:
          return e === null && Qe && ((u = s = wt) && (s = jw(s, t.type, t.pendingProps, In), s !== null ? (t.stateNode = s, Ft = t, wt = zn(s.firstChild), In = false, u = true) : u = false), u || Gl(t)), U(t), u = t.type, h = t.pendingProps, w = e !== null ? e.memoizedProps : null, s = h.children, fd(u, h) ? s = null : w !== null && fd(u, w) && (t.flags |= 32), t.memoizedState !== null && (u = du(e, t, Vx, null, null, a), Oo._currentValue = u), ei(e, t), Wt(e, t, s, a), t.child;
        case 6:
          return e === null && Qe && ((e = a = wt) && (a = Lw(a, t.pendingProps, In), a !== null ? (t.stateNode = a, Ft = t, wt = null, e = true) : e = false), e || Gl(t)), null;
        case 13:
          return jg(e, t, a);
        case 4:
          return Re(t, t.stateNode.containerInfo), s = t.pendingProps, e === null ? t.child = Hr(t, null, s, a) : Wt(e, t, s, a), t.child;
        case 11:
          return vg(e, t, t.type, t.pendingProps, a);
        case 7:
          return Wt(e, t, t.pendingProps, a), t.child;
        case 8:
          return Wt(e, t, t.pendingProps.children, a), t.child;
        case 12:
          return Wt(e, t, t.pendingProps.children, a), t.child;
        case 10:
          return s = t.pendingProps, Pl(t, t.type, s.value), Wt(e, t, s.children, a), t.child;
        case 9:
          return u = t.type._context, s = t.pendingProps.children, Or(t), u = Qt(u), s = s(u), t.flags |= 1, Wt(e, t, s, a), t.child;
        case 14:
          return xg(e, t, t.type, t.pendingProps, a);
        case 15:
          return wg(e, t, t.type, t.pendingProps, a);
        case 19:
          return Rg(e, t, a);
        case 31:
          return Qx(e, t, a);
        case 22:
          return Sg(e, t, a, t.pendingProps);
        case 24:
          return Or(t), s = Qt(zt), e === null ? (u = tu(), u === null && (u = pt, h = Jc(), u.pooledCache = h, h.refCount++, h !== null && (u.pooledCacheLanes |= a), u = h), t.memoizedState = {
            parent: s,
            cache: u
          }, lu(t), Pl(t, zt, u)) : ((e.lanes & a) !== 0 && (ru(e, t), mo(t, null, null, a), ho()), u = e.memoizedState, h = t.memoizedState, u.parent !== s ? (u = {
            parent: s,
            cache: s
          }, t.memoizedState = u, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = u), Pl(t, zt, s)) : (s = h.cache, Pl(t, zt, s), s !== u.cache && Wc(t, [
            zt
          ], a, true))), Wt(e, t, t.pendingProps.children, a), t.child;
        case 29:
          throw t.pendingProps;
      }
      throw Error(o(156, t.tag));
    }
    function El(e) {
      e.flags |= 4;
    }
    function Uu(e, t, a, s, u) {
      if ((t = (e.mode & 32) !== 0) && (t = false), t) {
        if (e.flags |= 16777216, (u & 335544128) === u) if (e.stateNode.complete) e.flags |= 8192;
        else if (rp()) e.flags |= 8192;
        else throw zr = Us, nu;
      } else e.flags &= -16777217;
    }
    function Tg(e, t) {
      if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0) e.flags &= -16777217;
      else if (e.flags |= 16777216, !Pp(t)) if (rp()) e.flags |= 8192;
      else throw zr = Us, nu;
    }
    function ni(e, t) {
      t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag !== 22 ? ea() : 536870912, e.lanes |= t, Ma |= t);
    }
    function xo(e, t) {
      if (!Qe) switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var a = null; t !== null; ) t.alternate !== null && (a = t), t = t.sibling;
          a === null ? e.tail = null : a.sibling = null;
          break;
        case "collapsed":
          a = e.tail;
          for (var s = null; a !== null; ) a.alternate !== null && (s = a), a = a.sibling;
          s === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : s.sibling = null;
      }
    }
    function St(e) {
      var t = e.alternate !== null && e.alternate.child === e.child, a = 0, s = 0;
      if (t) for (var u = e.child; u !== null; ) a |= u.lanes | u.childLanes, s |= u.subtreeFlags & 65011712, s |= u.flags & 65011712, u.return = e, u = u.sibling;
      else for (u = e.child; u !== null; ) a |= u.lanes | u.childLanes, s |= u.subtreeFlags, s |= u.flags, u.return = e, u = u.sibling;
      return e.subtreeFlags |= s, e.childLanes = a, t;
    }
    function Jx(e, t, a) {
      var s = t.pendingProps;
      switch (Pc(t), t.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return St(t), null;
        case 1:
          return St(t), null;
        case 3:
          return a = t.stateNode, s = null, e !== null && (s = e.memoizedState.cache), t.memoizedState.cache !== s && (t.flags |= 2048), xl(zt), X(), a.pendingContext && (a.context = a.pendingContext, a.pendingContext = null), (e === null || e.child === null) && (ma(t) ? El(t) : e === null || e.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, Zc())), St(t), null;
        case 26:
          var u = t.type, h = t.memoizedState;
          return e === null ? (El(t), h !== null ? (St(t), Tg(t, h)) : (St(t), Uu(t, u, null, s, a))) : h ? h !== e.memoizedState ? (El(t), St(t), Tg(t, h)) : (St(t), t.flags &= -16777217) : (e = e.memoizedProps, e !== s && El(t), St(t), Uu(t, u, e, s, a)), null;
        case 27:
          if (te(t), a = ie.current, u = t.type, e !== null && t.stateNode != null) e.memoizedProps !== s && El(t);
          else {
            if (!s) {
              if (t.stateNode === null) throw Error(o(166));
              return St(t), null;
            }
            e = W.current, ma(t) ? dm(t) : (e = Up(u, s, a), t.stateNode = e, El(t));
          }
          return St(t), null;
        case 5:
          if (te(t), u = t.type, e !== null && t.stateNode != null) e.memoizedProps !== s && El(t);
          else {
            if (!s) {
              if (t.stateNode === null) throw Error(o(166));
              return St(t), null;
            }
            if (h = W.current, ma(t)) dm(t);
            else {
              var w = yi(ie.current);
              switch (h) {
                case 1:
                  h = w.createElementNS("http://www.w3.org/2000/svg", u);
                  break;
                case 2:
                  h = w.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                  break;
                default:
                  switch (u) {
                    case "svg":
                      h = w.createElementNS("http://www.w3.org/2000/svg", u);
                      break;
                    case "math":
                      h = w.createElementNS("http://www.w3.org/1998/Math/MathML", u);
                      break;
                    case "script":
                      h = w.createElement("div"), h.innerHTML = "<script><\/script>", h = h.removeChild(h.firstChild);
                      break;
                    case "select":
                      h = typeof s.is == "string" ? w.createElement("select", {
                        is: s.is
                      }) : w.createElement("select"), s.multiple ? h.multiple = true : s.size && (h.size = s.size);
                      break;
                    default:
                      h = typeof s.is == "string" ? w.createElement(u, {
                        is: s.is
                      }) : w.createElement(u);
                  }
              }
              h[$t] = t, h[le] = s;
              e: for (w = t.child; w !== null; ) {
                if (w.tag === 5 || w.tag === 6) h.appendChild(w.stateNode);
                else if (w.tag !== 4 && w.tag !== 27 && w.child !== null) {
                  w.child.return = w, w = w.child;
                  continue;
                }
                if (w === t) break e;
                for (; w.sibling === null; ) {
                  if (w.return === null || w.return === t) break e;
                  w = w.return;
                }
                w.sibling.return = w.return, w = w.sibling;
              }
              t.stateNode = h;
              e: switch (Jt(h, u, s), u) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  s = !!s.autoFocus;
                  break e;
                case "img":
                  s = true;
                  break e;
                default:
                  s = false;
              }
              s && El(t);
            }
          }
          return St(t), Uu(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, a), null;
        case 6:
          if (e && t.stateNode != null) e.memoizedProps !== s && El(t);
          else {
            if (typeof s != "string" && t.stateNode === null) throw Error(o(166));
            if (e = ie.current, ma(t)) {
              if (e = t.stateNode, a = t.memoizedProps, s = null, u = Ft, u !== null) switch (u.tag) {
                case 27:
                case 5:
                  s = u.memoizedProps;
              }
              e[$t] = t, e = !!(e.nodeValue === a || s !== null && s.suppressHydrationWarning === true || jp(e.nodeValue, a)), e || Gl(t, true);
            } else e = yi(e).createTextNode(s), e[$t] = t, t.stateNode = e;
          }
          return St(t), null;
        case 31:
          if (a = t.memoizedState, e === null || e.memoizedState !== null) {
            if (s = ma(t), a !== null) {
              if (e === null) {
                if (!s) throw Error(o(318));
                if (e = t.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(o(557));
                e[$t] = t;
              } else Tr(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
              St(t), e = false;
            } else a = Zc(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), e = true;
            if (!e) return t.flags & 256 ? (Cn(t), t) : (Cn(t), null);
            if ((t.flags & 128) !== 0) throw Error(o(558));
          }
          return St(t), null;
        case 13:
          if (s = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
            if (u = ma(t), s !== null && s.dehydrated !== null) {
              if (e === null) {
                if (!u) throw Error(o(318));
                if (u = t.memoizedState, u = u !== null ? u.dehydrated : null, !u) throw Error(o(317));
                u[$t] = t;
              } else Tr(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
              St(t), u = false;
            } else u = Zc(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = u), u = true;
            if (!u) return t.flags & 256 ? (Cn(t), t) : (Cn(t), null);
          }
          return Cn(t), (t.flags & 128) !== 0 ? (t.lanes = a, t) : (a = s !== null, e = e !== null && e.memoizedState !== null, a && (s = t.child, u = null, s.alternate !== null && s.alternate.memoizedState !== null && s.alternate.memoizedState.cachePool !== null && (u = s.alternate.memoizedState.cachePool.pool), h = null, s.memoizedState !== null && s.memoizedState.cachePool !== null && (h = s.memoizedState.cachePool.pool), h !== u && (s.flags |= 2048)), a !== e && a && (t.child.flags |= 8192), ni(t, t.updateQueue), St(t), null);
        case 4:
          return X(), e === null && sd(t.stateNode.containerInfo), St(t), null;
        case 10:
          return xl(t.type), St(t), null;
        case 19:
          if (O(Nt), s = t.memoizedState, s === null) return St(t), null;
          if (u = (t.flags & 128) !== 0, h = s.rendering, h === null) if (u) xo(s, false);
          else {
            if (At !== 0 || e !== null && (e.flags & 128) !== 0) for (e = t.child; e !== null; ) {
              if (h = Vs(e), h !== null) {
                for (t.flags |= 128, xo(s, false), e = h.updateQueue, t.updateQueue = e, ni(t, e), t.subtreeFlags = 0, e = a, a = t.child; a !== null; ) om(a, e), a = a.sibling;
                return K(Nt, Nt.current & 1 | 2), Qe && bl(t, s.treeForkCount), t.child;
              }
              e = e.sibling;
            }
            s.tail !== null && Ke() > si && (t.flags |= 128, u = true, xo(s, false), t.lanes = 4194304);
          }
          else {
            if (!u) if (e = Vs(h), e !== null) {
              if (t.flags |= 128, u = true, e = e.updateQueue, t.updateQueue = e, ni(t, e), xo(s, true), s.tail === null && s.tailMode === "hidden" && !h.alternate && !Qe) return St(t), null;
            } else 2 * Ke() - s.renderingStartTime > si && a !== 536870912 && (t.flags |= 128, u = true, xo(s, false), t.lanes = 4194304);
            s.isBackwards ? (h.sibling = t.child, t.child = h) : (e = s.last, e !== null ? e.sibling = h : t.child = h, s.last = h);
          }
          return s.tail !== null ? (e = s.tail, s.rendering = e, s.tail = e.sibling, s.renderingStartTime = Ke(), e.sibling = null, a = Nt.current, K(Nt, u ? a & 1 | 2 : a & 1), Qe && bl(t, s.treeForkCount), e) : (St(t), null);
        case 22:
        case 23:
          return Cn(t), iu(), s = t.memoizedState !== null, e !== null ? e.memoizedState !== null !== s && (t.flags |= 8192) : s && (t.flags |= 8192), s ? (a & 536870912) !== 0 && (t.flags & 128) === 0 && (St(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : St(t), a = t.updateQueue, a !== null && ni(t, a.retryQueue), a = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (a = e.memoizedState.cachePool.pool), s = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (s = t.memoizedState.cachePool.pool), s !== a && (t.flags |= 2048), e !== null && O(Ir), null;
        case 24:
          return a = null, e !== null && (a = e.memoizedState.cache), t.memoizedState.cache !== a && (t.flags |= 2048), xl(zt), St(t), null;
        case 25:
          return null;
        case 30:
          return null;
      }
      throw Error(o(156, t.tag));
    }
    function ew(e, t) {
      switch (Pc(t), t.tag) {
        case 1:
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
          return xl(zt), X(), e = t.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (t.flags = e & -65537 | 128, t) : null;
        case 26:
        case 27:
        case 5:
          return te(t), null;
        case 31:
          if (t.memoizedState !== null) {
            if (Cn(t), t.alternate === null) throw Error(o(340));
            Tr();
          }
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 13:
          if (Cn(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
            if (t.alternate === null) throw Error(o(340));
            Tr();
          }
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
          return O(Nt), null;
        case 4:
          return X(), null;
        case 10:
          return xl(t.type), null;
        case 22:
        case 23:
          return Cn(t), iu(), e !== null && O(Ir), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 24:
          return xl(zt), null;
        case 25:
          return null;
        default:
          return null;
      }
    }
    function Ng(e, t) {
      switch (Pc(t), t.tag) {
        case 3:
          xl(zt), X();
          break;
        case 26:
        case 27:
        case 5:
          te(t);
          break;
        case 4:
          X();
          break;
        case 31:
          t.memoizedState !== null && Cn(t);
          break;
        case 13:
          Cn(t);
          break;
        case 19:
          O(Nt);
          break;
        case 10:
          xl(t.type);
          break;
        case 22:
        case 23:
          Cn(t), iu(), e !== null && O(Ir);
          break;
        case 24:
          xl(zt);
      }
    }
    function wo(e, t) {
      try {
        var a = t.updateQueue, s = a !== null ? a.lastEffect : null;
        if (s !== null) {
          var u = s.next;
          a = u;
          do {
            if ((a.tag & e) === e) {
              s = void 0;
              var h = a.create, w = a.inst;
              s = h(), w.destroy = s;
            }
            a = a.next;
          } while (a !== u);
        }
      } catch (M) {
        ut(t, t.return, M);
      }
    }
    function Jl(e, t, a) {
      try {
        var s = t.updateQueue, u = s !== null ? s.lastEffect : null;
        if (u !== null) {
          var h = u.next;
          s = h;
          do {
            if ((s.tag & e) === e) {
              var w = s.inst, M = w.destroy;
              if (M !== void 0) {
                w.destroy = void 0, u = t;
                var z = a, P = M;
                try {
                  P();
                } catch (ne) {
                  ut(u, z, ne);
                }
              }
            }
            s = s.next;
          } while (s !== h);
        }
      } catch (ne) {
        ut(t, t.return, ne);
      }
    }
    function Og(e) {
      var t = e.updateQueue;
      if (t !== null) {
        var a = e.stateNode;
        try {
          Em(t, a);
        } catch (s) {
          ut(e, e.return, s);
        }
      }
    }
    function Ig(e, t, a) {
      a.props = Yr(e.type, e.memoizedProps), a.state = e.memoizedState;
      try {
        a.componentWillUnmount();
      } catch (s) {
        ut(e, t, s);
      }
    }
    function So(e, t) {
      try {
        var a = e.ref;
        if (a !== null) {
          switch (e.tag) {
            case 26:
            case 27:
            case 5:
              var s = e.stateNode;
              break;
            case 30:
              s = e.stateNode;
              break;
            default:
              s = e.stateNode;
          }
          typeof a == "function" ? e.refCleanup = a(s) : a.current = s;
        }
      } catch (u) {
        ut(e, t, u);
      }
    }
    function sl(e, t) {
      var a = e.ref, s = e.refCleanup;
      if (a !== null) if (typeof s == "function") try {
        s();
      } catch (u) {
        ut(e, t, u);
      } finally {
        e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
      }
      else if (typeof a == "function") try {
        a(null);
      } catch (u) {
        ut(e, t, u);
      }
      else a.current = null;
    }
    function Dg(e) {
      var t = e.type, a = e.memoizedProps, s = e.stateNode;
      try {
        e: switch (t) {
          case "button":
          case "input":
          case "select":
          case "textarea":
            a.autoFocus && s.focus();
            break e;
          case "img":
            a.src ? s.src = a.src : a.srcSet && (s.srcset = a.srcSet);
        }
      } catch (u) {
        ut(e, e.return, u);
      }
    }
    function Yu(e, t, a) {
      try {
        var s = e.stateNode;
        Sw(s, e.type, a, t), s[le] = t;
      } catch (u) {
        ut(e, e.return, u);
      }
    }
    function zg(e) {
      return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && or(e.type) || e.tag === 4;
    }
    function Bu(e) {
      e: for (; ; ) {
        for (; e.sibling === null; ) {
          if (e.return === null || zg(e.return)) return null;
          e = e.return;
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18; ) {
          if (e.tag === 27 && or(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue e;
          e.child.return = e, e = e.child;
        }
        if (!(e.flags & 2)) return e.stateNode;
      }
    }
    function Xu(e, t, a) {
      var s = e.tag;
      if (s === 5 || s === 6) e = e.stateNode, t ? (a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a).insertBefore(e, t) : (t = a.nodeType === 9 ? a.body : a.nodeName === "HTML" ? a.ownerDocument.body : a, t.appendChild(e), a = a._reactRootContainer, a != null || t.onclick !== null || (t.onclick = gl));
      else if (s !== 4 && (s === 27 && or(e.type) && (a = e.stateNode, t = null), e = e.child, e !== null)) for (Xu(e, t, a), e = e.sibling; e !== null; ) Xu(e, t, a), e = e.sibling;
    }
    function li(e, t, a) {
      var s = e.tag;
      if (s === 5 || s === 6) e = e.stateNode, t ? a.insertBefore(e, t) : a.appendChild(e);
      else if (s !== 4 && (s === 27 && or(e.type) && (a = e.stateNode), e = e.child, e !== null)) for (li(e, t, a), e = e.sibling; e !== null; ) li(e, t, a), e = e.sibling;
    }
    function Hg(e) {
      var t = e.stateNode, a = e.memoizedProps;
      try {
        for (var s = e.type, u = t.attributes; u.length; ) t.removeAttributeNode(u[0]);
        Jt(t, s, a), t[$t] = e, t[le] = a;
      } catch (h) {
        ut(e, e.return, h);
      }
    }
    var _l = false, Yt = false, Vu = false, Ug = typeof WeakSet == "function" ? WeakSet : Set, Kt = null;
    function tw(e, t) {
      if (e = e.containerInfo, ud = Ei, e = Qh(e), Dc(e)) {
        if ("selectionStart" in e) var a = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
        else e: {
          a = (a = e.ownerDocument) && a.defaultView || window;
          var s = a.getSelection && a.getSelection();
          if (s && s.rangeCount !== 0) {
            a = s.anchorNode;
            var u = s.anchorOffset, h = s.focusNode;
            s = s.focusOffset;
            try {
              a.nodeType, h.nodeType;
            } catch {
              a = null;
              break e;
            }
            var w = 0, M = -1, z = -1, P = 0, ne = 0, oe = e, Z = null;
            t: for (; ; ) {
              for (var Q; oe !== a || u !== 0 && oe.nodeType !== 3 || (M = w + u), oe !== h || s !== 0 && oe.nodeType !== 3 || (z = w + s), oe.nodeType === 3 && (w += oe.nodeValue.length), (Q = oe.firstChild) !== null; ) Z = oe, oe = Q;
              for (; ; ) {
                if (oe === e) break t;
                if (Z === a && ++P === u && (M = w), Z === h && ++ne === s && (z = w), (Q = oe.nextSibling) !== null) break;
                oe = Z, Z = oe.parentNode;
              }
              oe = Q;
            }
            a = M === -1 || z === -1 ? null : {
              start: M,
              end: z
            };
          } else a = null;
        }
        a = a || {
          start: 0,
          end: 0
        };
      } else a = null;
      for (dd = {
        focusedElem: e,
        selectionRange: a
      }, Ei = false, Kt = t; Kt !== null; ) if (t = Kt, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, Kt = e;
      else for (; Kt !== null; ) {
        switch (t = Kt, h = t.alternate, e = t.flags, t.tag) {
          case 0:
            if ((e & 4) !== 0 && (e = t.updateQueue, e = e !== null ? e.events : null, e !== null)) for (a = 0; a < e.length; a++) u = e[a], u.ref.impl = u.nextImpl;
            break;
          case 11:
          case 15:
            break;
          case 1:
            if ((e & 1024) !== 0 && h !== null) {
              e = void 0, a = t, u = h.memoizedProps, h = h.memoizedState, s = a.stateNode;
              try {
                var _e = Yr(a.type, u);
                e = s.getSnapshotBeforeUpdate(_e, h), s.__reactInternalSnapshotBeforeUpdate = e;
              } catch (Te) {
                ut(a, a.return, Te);
              }
            }
            break;
          case 3:
            if ((e & 1024) !== 0) {
              if (e = t.stateNode.containerInfo, a = e.nodeType, a === 9) md(e);
              else if (a === 1) switch (e.nodeName) {
                case "HEAD":
                case "HTML":
                case "BODY":
                  md(e);
                  break;
                default:
                  e.textContent = "";
              }
            }
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          default:
            if ((e & 1024) !== 0) throw Error(o(163));
        }
        if (e = t.sibling, e !== null) {
          e.return = t.return, Kt = e;
          break;
        }
        Kt = t.return;
      }
    }
    function Yg(e, t, a) {
      var s = a.flags;
      switch (a.tag) {
        case 0:
        case 11:
        case 15:
          Ml(e, a), s & 4 && wo(5, a);
          break;
        case 1:
          if (Ml(e, a), s & 4) if (e = a.stateNode, t === null) try {
            e.componentDidMount();
          } catch (w) {
            ut(a, a.return, w);
          }
          else {
            var u = Yr(a.type, t.memoizedProps);
            t = t.memoizedState;
            try {
              e.componentDidUpdate(u, t, e.__reactInternalSnapshotBeforeUpdate);
            } catch (w) {
              ut(a, a.return, w);
            }
          }
          s & 64 && Og(a), s & 512 && So(a, a.return);
          break;
        case 3:
          if (Ml(e, a), s & 64 && (e = a.updateQueue, e !== null)) {
            if (t = null, a.child !== null) switch (a.child.tag) {
              case 27:
              case 5:
                t = a.child.stateNode;
                break;
              case 1:
                t = a.child.stateNode;
            }
            try {
              Em(e, t);
            } catch (w) {
              ut(a, a.return, w);
            }
          }
          break;
        case 27:
          t === null && s & 4 && Hg(a);
        case 26:
        case 5:
          Ml(e, a), t === null && s & 4 && Dg(a), s & 512 && So(a, a.return);
          break;
        case 12:
          Ml(e, a);
          break;
        case 31:
          Ml(e, a), s & 4 && Vg(e, a);
          break;
        case 13:
          Ml(e, a), s & 4 && $g(e, a), s & 64 && (e = a.memoizedState, e !== null && (e = e.dehydrated, e !== null && (a = uw.bind(null, a), Rw(e, a))));
          break;
        case 22:
          if (s = a.memoizedState !== null || _l, !s) {
            t = t !== null && t.memoizedState !== null || Yt, u = _l;
            var h = Yt;
            _l = s, (Yt = t) && !h ? jl(e, a, (a.subtreeFlags & 8772) !== 0) : Ml(e, a), _l = u, Yt = h;
          }
          break;
        case 30:
          break;
        default:
          Ml(e, a);
      }
    }
    function Bg(e) {
      var t = e.alternate;
      t !== null && (e.alternate = null, Bg(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && gt(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
    }
    var Et = null, hn = false;
    function kl(e, t, a) {
      for (a = a.child; a !== null; ) Xg(e, t, a), a = a.sibling;
    }
    function Xg(e, t, a) {
      if (xt && typeof xt.onCommitFiberUnmount == "function") try {
        xt.onCommitFiberUnmount(en, a);
      } catch {
      }
      switch (a.tag) {
        case 26:
          Yt || sl(a, t), kl(e, t, a), a.memoizedState ? a.memoizedState.count-- : a.stateNode && (a = a.stateNode, a.parentNode.removeChild(a));
          break;
        case 27:
          Yt || sl(a, t);
          var s = Et, u = hn;
          or(a.type) && (Et = a.stateNode, hn = false), kl(e, t, a), Ao(a.stateNode), Et = s, hn = u;
          break;
        case 5:
          Yt || sl(a, t);
        case 6:
          if (s = Et, u = hn, Et = null, kl(e, t, a), Et = s, hn = u, Et !== null) if (hn) try {
            (Et.nodeType === 9 ? Et.body : Et.nodeName === "HTML" ? Et.ownerDocument.body : Et).removeChild(a.stateNode);
          } catch (h) {
            ut(a, t, h);
          }
          else try {
            Et.removeChild(a.stateNode);
          } catch (h) {
            ut(a, t, h);
          }
          break;
        case 18:
          Et !== null && (hn ? (e = Et, Op(e.nodeType === 9 ? e.body : e.nodeName === "HTML" ? e.ownerDocument.body : e, a.stateNode), Ia(e)) : Op(Et, a.stateNode));
          break;
        case 4:
          s = Et, u = hn, Et = a.stateNode.containerInfo, hn = true, kl(e, t, a), Et = s, hn = u;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          Jl(2, a, t), Yt || Jl(4, a, t), kl(e, t, a);
          break;
        case 1:
          Yt || (sl(a, t), s = a.stateNode, typeof s.componentWillUnmount == "function" && Ig(a, t, s)), kl(e, t, a);
          break;
        case 21:
          kl(e, t, a);
          break;
        case 22:
          Yt = (s = Yt) || a.memoizedState !== null, kl(e, t, a), Yt = s;
          break;
        default:
          kl(e, t, a);
      }
    }
    function Vg(e, t) {
      if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
        e = e.dehydrated;
        try {
          Ia(e);
        } catch (a) {
          ut(t, t.return, a);
        }
      }
    }
    function $g(e, t) {
      if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
        Ia(e);
      } catch (a) {
        ut(t, t.return, a);
      }
    }
    function nw(e) {
      switch (e.tag) {
        case 31:
        case 13:
        case 19:
          var t = e.stateNode;
          return t === null && (t = e.stateNode = new Ug()), t;
        case 22:
          return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new Ug()), t;
        default:
          throw Error(o(435, e.tag));
      }
    }
    function ri(e, t) {
      var a = nw(e);
      t.forEach(function(s) {
        if (!a.has(s)) {
          a.add(s);
          var u = dw.bind(null, e, s);
          s.then(u, u);
        }
      });
    }
    function mn(e, t) {
      var a = t.deletions;
      if (a !== null) for (var s = 0; s < a.length; s++) {
        var u = a[s], h = e, w = t, M = w;
        e: for (; M !== null; ) {
          switch (M.tag) {
            case 27:
              if (or(M.type)) {
                Et = M.stateNode, hn = false;
                break e;
              }
              break;
            case 5:
              Et = M.stateNode, hn = false;
              break e;
            case 3:
            case 4:
              Et = M.stateNode.containerInfo, hn = true;
              break e;
          }
          M = M.return;
        }
        if (Et === null) throw Error(o(160));
        Xg(h, w, u), Et = null, hn = false, h = u.alternate, h !== null && (h.return = null), u.return = null;
      }
      if (t.subtreeFlags & 13886) for (t = t.child; t !== null; ) qg(t, e), t = t.sibling;
    }
    var Gn = null;
    function qg(e, t) {
      var a = e.alternate, s = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          mn(t, e), gn(e), s & 4 && (Jl(3, e, e.return), wo(3, e), Jl(5, e, e.return));
          break;
        case 1:
          mn(t, e), gn(e), s & 512 && (Yt || a === null || sl(a, a.return)), s & 64 && _l && (e = e.updateQueue, e !== null && (s = e.callbacks, s !== null && (a = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = a === null ? s : a.concat(s))));
          break;
        case 26:
          var u = Gn;
          if (mn(t, e), gn(e), s & 512 && (Yt || a === null || sl(a, a.return)), s & 4) {
            var h = a !== null ? a.memoizedState : null;
            if (s = e.memoizedState, a === null) if (s === null) if (e.stateNode === null) {
              e: {
                s = e.type, a = e.memoizedProps, u = u.ownerDocument || u;
                t: switch (s) {
                  case "title":
                    h = u.getElementsByTagName("title")[0], (!h || h[ot] || h[$t] || h.namespaceURI === "http://www.w3.org/2000/svg" || h.hasAttribute("itemprop")) && (h = u.createElement(s), u.head.insertBefore(h, u.querySelector("head > title"))), Jt(h, s, a), h[$t] = e, it(h), s = h;
                    break e;
                  case "link":
                    var w = qp("link", "href", u).get(s + (a.href || ""));
                    if (w) {
                      for (var M = 0; M < w.length; M++) if (h = w[M], h.getAttribute("href") === (a.href == null || a.href === "" ? null : a.href) && h.getAttribute("rel") === (a.rel == null ? null : a.rel) && h.getAttribute("title") === (a.title == null ? null : a.title) && h.getAttribute("crossorigin") === (a.crossOrigin == null ? null : a.crossOrigin)) {
                        w.splice(M, 1);
                        break t;
                      }
                    }
                    h = u.createElement(s), Jt(h, s, a), u.head.appendChild(h);
                    break;
                  case "meta":
                    if (w = qp("meta", "content", u).get(s + (a.content || ""))) {
                      for (M = 0; M < w.length; M++) if (h = w[M], h.getAttribute("content") === (a.content == null ? null : "" + a.content) && h.getAttribute("name") === (a.name == null ? null : a.name) && h.getAttribute("property") === (a.property == null ? null : a.property) && h.getAttribute("http-equiv") === (a.httpEquiv == null ? null : a.httpEquiv) && h.getAttribute("charset") === (a.charSet == null ? null : a.charSet)) {
                        w.splice(M, 1);
                        break t;
                      }
                    }
                    h = u.createElement(s), Jt(h, s, a), u.head.appendChild(h);
                    break;
                  default:
                    throw Error(o(468, s));
                }
                h[$t] = e, it(h), s = h;
              }
              e.stateNode = s;
            } else Gp(u, e.type, e.stateNode);
            else e.stateNode = $p(u, s, e.memoizedProps);
            else h !== s ? (h === null ? a.stateNode !== null && (a = a.stateNode, a.parentNode.removeChild(a)) : h.count--, s === null ? Gp(u, e.type, e.stateNode) : $p(u, s, e.memoizedProps)) : s === null && e.stateNode !== null && Yu(e, e.memoizedProps, a.memoizedProps);
          }
          break;
        case 27:
          mn(t, e), gn(e), s & 512 && (Yt || a === null || sl(a, a.return)), a !== null && s & 4 && Yu(e, e.memoizedProps, a.memoizedProps);
          break;
        case 5:
          if (mn(t, e), gn(e), s & 512 && (Yt || a === null || sl(a, a.return)), e.flags & 32) {
            u = e.stateNode;
            try {
              ra(u, "");
            } catch (_e) {
              ut(e, e.return, _e);
            }
          }
          s & 4 && e.stateNode != null && (u = e.memoizedProps, Yu(e, u, a !== null ? a.memoizedProps : u)), s & 1024 && (Vu = true);
          break;
        case 6:
          if (mn(t, e), gn(e), s & 4) {
            if (e.stateNode === null) throw Error(o(162));
            s = e.memoizedProps, a = e.stateNode;
            try {
              a.nodeValue = s;
            } catch (_e) {
              ut(e, e.return, _e);
            }
          }
          break;
        case 3:
          if (xi = null, u = Gn, Gn = bi(t.containerInfo), mn(t, e), Gn = u, gn(e), s & 4 && a !== null && a.memoizedState.isDehydrated) try {
            Ia(t.containerInfo);
          } catch (_e) {
            ut(e, e.return, _e);
          }
          Vu && (Vu = false, Gg(e));
          break;
        case 4:
          s = Gn, Gn = bi(e.stateNode.containerInfo), mn(t, e), gn(e), Gn = s;
          break;
        case 12:
          mn(t, e), gn(e);
          break;
        case 31:
          mn(t, e), gn(e), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, ri(e, s)));
          break;
        case 13:
          mn(t, e), gn(e), e.child.flags & 8192 && e.memoizedState !== null != (a !== null && a.memoizedState !== null) && (oi = Ke()), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, ri(e, s)));
          break;
        case 22:
          u = e.memoizedState !== null;
          var z = a !== null && a.memoizedState !== null, P = _l, ne = Yt;
          if (_l = P || u, Yt = ne || z, mn(t, e), Yt = ne, _l = P, gn(e), s & 8192) e: for (t = e.stateNode, t._visibility = u ? t._visibility & -2 : t._visibility | 1, u && (a === null || z || _l || Yt || Br(e)), a = null, t = e; ; ) {
            if (t.tag === 5 || t.tag === 26) {
              if (a === null) {
                z = a = t;
                try {
                  if (h = z.stateNode, u) w = h.style, typeof w.setProperty == "function" ? w.setProperty("display", "none", "important") : w.display = "none";
                  else {
                    M = z.stateNode;
                    var oe = z.memoizedProps.style, Z = oe != null && oe.hasOwnProperty("display") ? oe.display : null;
                    M.style.display = Z == null || typeof Z == "boolean" ? "" : ("" + Z).trim();
                  }
                } catch (_e) {
                  ut(z, z.return, _e);
                }
              }
            } else if (t.tag === 6) {
              if (a === null) {
                z = t;
                try {
                  z.stateNode.nodeValue = u ? "" : z.memoizedProps;
                } catch (_e) {
                  ut(z, z.return, _e);
                }
              }
            } else if (t.tag === 18) {
              if (a === null) {
                z = t;
                try {
                  var Q = z.stateNode;
                  u ? Ip(Q, true) : Ip(z.stateNode, false);
                } catch (_e) {
                  ut(z, z.return, _e);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === e) break e;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === e) break e;
              a === t && (a = null), t = t.return;
            }
            a === t && (a = null), t.sibling.return = t.return, t = t.sibling;
          }
          s & 4 && (s = e.updateQueue, s !== null && (a = s.retryQueue, a !== null && (s.retryQueue = null, ri(e, a))));
          break;
        case 19:
          mn(t, e), gn(e), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, ri(e, s)));
          break;
        case 30:
          break;
        case 21:
          break;
        default:
          mn(t, e), gn(e);
      }
    }
    function gn(e) {
      var t = e.flags;
      if (t & 2) {
        try {
          for (var a, s = e.return; s !== null; ) {
            if (zg(s)) {
              a = s;
              break;
            }
            s = s.return;
          }
          if (a == null) throw Error(o(160));
          switch (a.tag) {
            case 27:
              var u = a.stateNode, h = Bu(e);
              li(e, h, u);
              break;
            case 5:
              var w = a.stateNode;
              a.flags & 32 && (ra(w, ""), a.flags &= -33);
              var M = Bu(e);
              li(e, M, w);
              break;
            case 3:
            case 4:
              var z = a.stateNode.containerInfo, P = Bu(e);
              Xu(e, P, z);
              break;
            default:
              throw Error(o(161));
          }
        } catch (ne) {
          ut(e, e.return, ne);
        }
        e.flags &= -3;
      }
      t & 4096 && (e.flags &= -4097);
    }
    function Gg(e) {
      if (e.subtreeFlags & 1024) for (e = e.child; e !== null; ) {
        var t = e;
        Gg(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling;
      }
    }
    function Ml(e, t) {
      if (t.subtreeFlags & 8772) for (t = t.child; t !== null; ) Yg(e, t.alternate, t), t = t.sibling;
    }
    function Br(e) {
      for (e = e.child; e !== null; ) {
        var t = e;
        switch (t.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            Jl(4, t, t.return), Br(t);
            break;
          case 1:
            sl(t, t.return);
            var a = t.stateNode;
            typeof a.componentWillUnmount == "function" && Ig(t, t.return, a), Br(t);
            break;
          case 27:
            Ao(t.stateNode);
          case 26:
          case 5:
            sl(t, t.return), Br(t);
            break;
          case 22:
            t.memoizedState === null && Br(t);
            break;
          case 30:
            Br(t);
            break;
          default:
            Br(t);
        }
        e = e.sibling;
      }
    }
    function jl(e, t, a) {
      for (a = a && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
        var s = t.alternate, u = e, h = t, w = h.flags;
        switch (h.tag) {
          case 0:
          case 11:
          case 15:
            jl(u, h, a), wo(4, h);
            break;
          case 1:
            if (jl(u, h, a), s = h, u = s.stateNode, typeof u.componentDidMount == "function") try {
              u.componentDidMount();
            } catch (P) {
              ut(s, s.return, P);
            }
            if (s = h, u = s.updateQueue, u !== null) {
              var M = s.stateNode;
              try {
                var z = u.shared.hiddenCallbacks;
                if (z !== null) for (u.shared.hiddenCallbacks = null, u = 0; u < z.length; u++) Cm(z[u], M);
              } catch (P) {
                ut(s, s.return, P);
              }
            }
            a && w & 64 && Og(h), So(h, h.return);
            break;
          case 27:
            Hg(h);
          case 26:
          case 5:
            jl(u, h, a), a && s === null && w & 4 && Dg(h), So(h, h.return);
            break;
          case 12:
            jl(u, h, a);
            break;
          case 31:
            jl(u, h, a), a && w & 4 && Vg(u, h);
            break;
          case 13:
            jl(u, h, a), a && w & 4 && $g(u, h);
            break;
          case 22:
            h.memoizedState === null && jl(u, h, a), So(h, h.return);
            break;
          case 30:
            break;
          default:
            jl(u, h, a);
        }
        t = t.sibling;
      }
    }
    function $u(e, t) {
      var a = null;
      e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (a = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== a && (e != null && e.refCount++, a != null && so(a));
    }
    function qu(e, t) {
      e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && so(e));
    }
    function Pn(e, t, a, s) {
      if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) Pg(e, t, a, s), t = t.sibling;
    }
    function Pg(e, t, a, s) {
      var u = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          Pn(e, t, a, s), u & 2048 && wo(9, t);
          break;
        case 1:
          Pn(e, t, a, s);
          break;
        case 3:
          Pn(e, t, a, s), u & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && so(e)));
          break;
        case 12:
          if (u & 2048) {
            Pn(e, t, a, s), e = t.stateNode;
            try {
              var h = t.memoizedProps, w = h.id, M = h.onPostCommit;
              typeof M == "function" && M(w, t.alternate === null ? "mount" : "update", e.passiveEffectDuration, -0);
            } catch (z) {
              ut(t, t.return, z);
            }
          } else Pn(e, t, a, s);
          break;
        case 31:
          Pn(e, t, a, s);
          break;
        case 13:
          Pn(e, t, a, s);
          break;
        case 23:
          break;
        case 22:
          h = t.stateNode, w = t.alternate, t.memoizedState !== null ? h._visibility & 2 ? Pn(e, t, a, s) : Co(e, t) : h._visibility & 2 ? Pn(e, t, a, s) : (h._visibility |= 2, Ea(e, t, a, s, (t.subtreeFlags & 10256) !== 0 || false)), u & 2048 && $u(w, t);
          break;
        case 24:
          Pn(e, t, a, s), u & 2048 && qu(t.alternate, t);
          break;
        default:
          Pn(e, t, a, s);
      }
    }
    function Ea(e, t, a, s, u) {
      for (u = u && ((t.subtreeFlags & 10256) !== 0 || false), t = t.child; t !== null; ) {
        var h = e, w = t, M = a, z = s, P = w.flags;
        switch (w.tag) {
          case 0:
          case 11:
          case 15:
            Ea(h, w, M, z, u), wo(8, w);
            break;
          case 23:
            break;
          case 22:
            var ne = w.stateNode;
            w.memoizedState !== null ? ne._visibility & 2 ? Ea(h, w, M, z, u) : Co(h, w) : (ne._visibility |= 2, Ea(h, w, M, z, u)), u && P & 2048 && $u(w.alternate, w);
            break;
          case 24:
            Ea(h, w, M, z, u), u && P & 2048 && qu(w.alternate, w);
            break;
          default:
            Ea(h, w, M, z, u);
        }
        t = t.sibling;
      }
    }
    function Co(e, t) {
      if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) {
        var a = e, s = t, u = s.flags;
        switch (s.tag) {
          case 22:
            Co(a, s), u & 2048 && $u(s.alternate, s);
            break;
          case 24:
            Co(a, s), u & 2048 && qu(s.alternate, s);
            break;
          default:
            Co(a, s);
        }
        t = t.sibling;
      }
    }
    var Eo = 8192;
    function _a(e, t, a) {
      if (e.subtreeFlags & Eo) for (e = e.child; e !== null; ) Kg(e, t, a), e = e.sibling;
    }
    function Kg(e, t, a) {
      switch (e.tag) {
        case 26:
          _a(e, t, a), e.flags & Eo && e.memoizedState !== null && Xw(a, Gn, e.memoizedState, e.memoizedProps);
          break;
        case 5:
          _a(e, t, a);
          break;
        case 3:
        case 4:
          var s = Gn;
          Gn = bi(e.stateNode.containerInfo), _a(e, t, a), Gn = s;
          break;
        case 22:
          e.memoizedState === null && (s = e.alternate, s !== null && s.memoizedState !== null ? (s = Eo, Eo = 16777216, _a(e, t, a), Eo = s) : _a(e, t, a));
          break;
        default:
          _a(e, t, a);
      }
    }
    function Zg(e) {
      var t = e.alternate;
      if (t !== null && (e = t.child, e !== null)) {
        t.child = null;
        do
          t = e.sibling, e.sibling = null, e = t;
        while (e !== null);
      }
    }
    function _o(e) {
      var t = e.deletions;
      if ((e.flags & 16) !== 0) {
        if (t !== null) for (var a = 0; a < t.length; a++) {
          var s = t[a];
          Kt = s, Qg(s, e);
        }
        Zg(e);
      }
      if (e.subtreeFlags & 10256) for (e = e.child; e !== null; ) Fg(e), e = e.sibling;
    }
    function Fg(e) {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          _o(e), e.flags & 2048 && Jl(9, e, e.return);
          break;
        case 3:
          _o(e);
          break;
        case 12:
          _o(e);
          break;
        case 22:
          var t = e.stateNode;
          e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, ai(e)) : _o(e);
          break;
        default:
          _o(e);
      }
    }
    function ai(e) {
      var t = e.deletions;
      if ((e.flags & 16) !== 0) {
        if (t !== null) for (var a = 0; a < t.length; a++) {
          var s = t[a];
          Kt = s, Qg(s, e);
        }
        Zg(e);
      }
      for (e = e.child; e !== null; ) {
        switch (t = e, t.tag) {
          case 0:
          case 11:
          case 15:
            Jl(8, t, t.return), ai(t);
            break;
          case 22:
            a = t.stateNode, a._visibility & 2 && (a._visibility &= -3, ai(t));
            break;
          default:
            ai(t);
        }
        e = e.sibling;
      }
    }
    function Qg(e, t) {
      for (; Kt !== null; ) {
        var a = Kt;
        switch (a.tag) {
          case 0:
          case 11:
          case 15:
            Jl(8, a, t);
            break;
          case 23:
          case 22:
            if (a.memoizedState !== null && a.memoizedState.cachePool !== null) {
              var s = a.memoizedState.cachePool.pool;
              s != null && s.refCount++;
            }
            break;
          case 24:
            so(a.memoizedState.cache);
        }
        if (s = a.child, s !== null) s.return = a, Kt = s;
        else e: for (a = e; Kt !== null; ) {
          s = Kt;
          var u = s.sibling, h = s.return;
          if (Bg(s), s === a) {
            Kt = null;
            break e;
          }
          if (u !== null) {
            u.return = h, Kt = u;
            break e;
          }
          Kt = h;
        }
      }
    }
    var lw = {
      getCacheForType: function(e) {
        var t = Qt(zt), a = t.data.get(e);
        return a === void 0 && (a = e(), t.data.set(e, a)), a;
      },
      cacheSignal: function() {
        return Qt(zt).controller.signal;
      }
    }, rw = typeof WeakMap == "function" ? WeakMap : Map, rt = 0, pt = null, qe = null, Ze = 0, ct = 0, En = null, er = false, ka = false, Gu = false, Ll = 0, At = 0, tr = 0, Xr = 0, Pu = 0, _n = 0, Ma = 0, ko = null, pn = null, Ku = false, oi = 0, Wg = 0, si = 1 / 0, ii = null, nr = null, qt = 0, lr = null, ja = null, Rl = 0, Zu = 0, Fu = null, Jg = null, Mo = 0, Qu = null;
    function kn() {
      return (rt & 2) !== 0 && Ze !== 0 ? Ze & -Ze : $.T !== null ? ld() : tl();
    }
    function ep() {
      if (_n === 0) if ((Ze & 536870912) === 0 || Qe) {
        var e = Wr;
        Wr <<= 1, (Wr & 3932160) === 0 && (Wr = 262144), _n = e;
      } else _n = 536870912;
      return e = Sn.current, e !== null && (e.flags |= 32), _n;
    }
    function yn(e, t, a) {
      (e === pt && (ct === 2 || ct === 9) || e.cancelPendingCommit !== null) && (La(e, 0), rr(e, Ze, _n, false)), Er(e, a), ((rt & 2) === 0 || e !== pt) && (e === pt && ((rt & 2) === 0 && (Xr |= a), At === 4 && rr(e, Ze, _n, false)), il(e));
    }
    function tp(e, t, a) {
      if ((rt & 6) !== 0) throw Error(o(327));
      var s = !a && (t & 127) === 0 && (t & e.expiredLanes) === 0 || hl(e, t), u = s ? sw(e, t) : Ju(e, t, true), h = s;
      do {
        if (u === 0) {
          ka && !s && rr(e, t, 0, false);
          break;
        } else {
          if (a = e.current.alternate, h && !aw(a)) {
            u = Ju(e, t, false), h = false;
            continue;
          }
          if (u === 2) {
            if (h = t, e.errorRecoveryDisabledLanes & h) var w = 0;
            else w = e.pendingLanes & -536870913, w = w !== 0 ? w : w & 536870912 ? 536870912 : 0;
            if (w !== 0) {
              t = w;
              e: {
                var M = e;
                u = ko;
                var z = M.current.memoizedState.isDehydrated;
                if (z && (La(M, w).flags |= 256), w = Ju(M, w, false), w !== 2) {
                  if (Gu && !z) {
                    M.errorRecoveryDisabledLanes |= h, Xr |= h, u = 4;
                    break e;
                  }
                  h = pn, pn = u, h !== null && (pn === null ? pn = h : pn.push.apply(pn, h));
                }
                u = w;
              }
              if (h = false, u !== 2) continue;
            }
          }
          if (u === 1) {
            La(e, 0), rr(e, t, 0, true);
            break;
          }
          e: {
            switch (s = e, h = u, h) {
              case 0:
              case 1:
                throw Error(o(345));
              case 4:
                if ((t & 4194048) !== t) break;
              case 6:
                rr(s, t, _n, !er);
                break e;
              case 2:
                pn = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(o(329));
            }
            if ((t & 62914560) === t && (u = oi + 300 - Ke(), 10 < u)) {
              if (rr(s, t, _n, !er), Ul(s, 0, true) !== 0) break e;
              Rl = t, s.timeoutHandle = Tp(np.bind(null, s, a, pn, ii, Ku, t, _n, Xr, Ma, er, h, "Throttled", -0, 0), u);
              break e;
            }
            np(s, a, pn, ii, Ku, t, _n, Xr, Ma, er, h, null, -0, 0);
          }
        }
        break;
      } while (true);
      il(e);
    }
    function np(e, t, a, s, u, h, w, M, z, P, ne, oe, Z, Q) {
      if (e.timeoutHandle = -1, oe = t.subtreeFlags, oe & 8192 || (oe & 16785408) === 16785408) {
        oe = {
          stylesheets: null,
          count: 0,
          imgCount: 0,
          imgBytes: 0,
          suspenseyImages: [],
          waitingForImages: true,
          waitingForViewTransition: false,
          unsuspend: gl
        }, Kg(t, h, oe);
        var _e = (h & 62914560) === h ? oi - Ke() : (h & 4194048) === h ? Wg - Ke() : 0;
        if (_e = Vw(oe, _e), _e !== null) {
          Rl = h, e.cancelPendingCommit = _e(up.bind(null, e, t, h, a, s, u, w, M, z, ne, oe, null, Z, Q)), rr(e, h, w, !P);
          return;
        }
      }
      up(e, t, h, a, s, u, w, M, z);
    }
    function aw(e) {
      for (var t = e; ; ) {
        var a = t.tag;
        if ((a === 0 || a === 11 || a === 15) && t.flags & 16384 && (a = t.updateQueue, a !== null && (a = a.stores, a !== null))) for (var s = 0; s < a.length; s++) {
          var u = a[s], h = u.getSnapshot;
          u = u.value;
          try {
            if (!xn(h(), u)) return false;
          } catch {
            return false;
          }
        }
        if (a = t.child, t.subtreeFlags & 16384 && a !== null) a.return = t, t = a;
        else {
          if (t === e) break;
          for (; t.sibling === null; ) {
            if (t.return === null || t.return === e) return true;
            t = t.return;
          }
          t.sibling.return = t.return, t = t.sibling;
        }
      }
      return true;
    }
    function rr(e, t, a, s) {
      t &= ~Pu, t &= ~Xr, e.suspendedLanes |= t, e.pingedLanes &= ~t, s && (e.warmLanes |= t), s = e.expirationTimes;
      for (var u = t; 0 < u; ) {
        var h = 31 - jt(u), w = 1 << h;
        s[h] = -1, u &= ~w;
      }
      a !== 0 && ys(e, a, t);
    }
    function ci() {
      return (rt & 6) === 0 ? (jo(0), false) : true;
    }
    function Wu() {
      if (qe !== null) {
        if (ct === 0) var e = qe.return;
        else e = qe, vl = Nr = null, mu(e), va = null, co = 0, e = qe;
        for (; e !== null; ) Ng(e.alternate, e), e = e.return;
        qe = null;
      }
    }
    function La(e, t) {
      var a = e.timeoutHandle;
      a !== -1 && (e.timeoutHandle = -1, _w(a)), a = e.cancelPendingCommit, a !== null && (e.cancelPendingCommit = null, a()), Rl = 0, Wu(), pt = e, qe = a = yl(e.current, null), Ze = t, ct = 0, En = null, er = false, ka = hl(e, t), Gu = false, Ma = _n = Pu = Xr = tr = At = 0, pn = ko = null, Ku = false, (t & 8) !== 0 && (t |= t & 32);
      var s = e.entangledLanes;
      if (s !== 0) for (e = e.entanglements, s &= t; 0 < s; ) {
        var u = 31 - jt(s), h = 1 << u;
        t |= e[u], s &= ~h;
      }
      return Ll = t, Rs(), a;
    }
    function lp(e, t) {
      Ue = null, $.H = bo, t === ba || t === Hs ? (t = vm(), ct = 3) : t === nu ? (t = vm(), ct = 4) : ct = t === Ru ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, En = t, qe === null && (At = 1, Ws(e, Tn(t, e.current)));
    }
    function rp() {
      var e = Sn.current;
      return e === null ? true : (Ze & 4194048) === Ze ? Dn === null : (Ze & 62914560) === Ze || (Ze & 536870912) !== 0 ? e === Dn : false;
    }
    function ap() {
      var e = $.H;
      return $.H = bo, e === null ? bo : e;
    }
    function op() {
      var e = $.A;
      return $.A = lw, e;
    }
    function ui() {
      At = 4, er || (Ze & 4194048) !== Ze && Sn.current !== null || (ka = true), (tr & 134217727) === 0 && (Xr & 134217727) === 0 || pt === null || rr(pt, Ze, _n, false);
    }
    function Ju(e, t, a) {
      var s = rt;
      rt |= 2;
      var u = ap(), h = op();
      (pt !== e || Ze !== t) && (ii = null, La(e, t)), t = false;
      var w = At;
      e: do
        try {
          if (ct !== 0 && qe !== null) {
            var M = qe, z = En;
            switch (ct) {
              case 8:
                Wu(), w = 6;
                break e;
              case 3:
              case 2:
              case 9:
              case 6:
                Sn.current === null && (t = true);
                var P = ct;
                if (ct = 0, En = null, Ra(e, M, z, P), a && ka) {
                  w = 0;
                  break e;
                }
                break;
              default:
                P = ct, ct = 0, En = null, Ra(e, M, z, P);
            }
          }
          ow(), w = At;
          break;
        } catch (ne) {
          lp(e, ne);
        }
      while (true);
      return t && e.shellSuspendCounter++, vl = Nr = null, rt = s, $.H = u, $.A = h, qe === null && (pt = null, Ze = 0, Rs()), w;
    }
    function ow() {
      for (; qe !== null; ) sp(qe);
    }
    function sw(e, t) {
      var a = rt;
      rt |= 2;
      var s = ap(), u = op();
      pt !== e || Ze !== t ? (ii = null, si = Ke() + 500, La(e, t)) : ka = hl(e, t);
      e: do
        try {
          if (ct !== 0 && qe !== null) {
            t = qe;
            var h = En;
            t: switch (ct) {
              case 1:
                ct = 0, En = null, Ra(e, t, h, 1);
                break;
              case 2:
              case 9:
                if (ym(h)) {
                  ct = 0, En = null, ip(t);
                  break;
                }
                t = function() {
                  ct !== 2 && ct !== 9 || pt !== e || (ct = 7), il(e);
                }, h.then(t, t);
                break e;
              case 3:
                ct = 7;
                break e;
              case 4:
                ct = 5;
                break e;
              case 7:
                ym(h) ? (ct = 0, En = null, ip(t)) : (ct = 0, En = null, Ra(e, t, h, 7));
                break;
              case 5:
                var w = null;
                switch (qe.tag) {
                  case 26:
                    w = qe.memoizedState;
                  case 5:
                  case 27:
                    var M = qe;
                    if (w ? Pp(w) : M.stateNode.complete) {
                      ct = 0, En = null;
                      var z = M.sibling;
                      if (z !== null) qe = z;
                      else {
                        var P = M.return;
                        P !== null ? (qe = P, di(P)) : qe = null;
                      }
                      break t;
                    }
                }
                ct = 0, En = null, Ra(e, t, h, 5);
                break;
              case 6:
                ct = 0, En = null, Ra(e, t, h, 6);
                break;
              case 8:
                Wu(), At = 6;
                break e;
              default:
                throw Error(o(462));
            }
          }
          iw();
          break;
        } catch (ne) {
          lp(e, ne);
        }
      while (true);
      return vl = Nr = null, $.H = s, $.A = u, rt = a, qe !== null ? 0 : (pt = null, Ze = 0, Rs(), At);
    }
    function iw() {
      for (; qe !== null && !$e(); ) sp(qe);
    }
    function sp(e) {
      var t = Ag(e.alternate, e, Ll);
      e.memoizedProps = e.pendingProps, t === null ? di(e) : qe = t;
    }
    function ip(e) {
      var t = e, a = t.alternate;
      switch (t.tag) {
        case 15:
        case 0:
          t = _g(a, t, t.pendingProps, t.type, void 0, Ze);
          break;
        case 11:
          t = _g(a, t, t.pendingProps, t.type.render, t.ref, Ze);
          break;
        case 5:
          mu(t);
        default:
          Ng(a, t), t = qe = om(t, Ll), t = Ag(a, t, Ll);
      }
      e.memoizedProps = e.pendingProps, t === null ? di(e) : qe = t;
    }
    function Ra(e, t, a, s) {
      vl = Nr = null, mu(t), va = null, co = 0;
      var u = t.return;
      try {
        if (Fx(e, u, t, a, Ze)) {
          At = 1, Ws(e, Tn(a, e.current)), qe = null;
          return;
        }
      } catch (h) {
        if (u !== null) throw qe = u, h;
        At = 1, Ws(e, Tn(a, e.current)), qe = null;
        return;
      }
      t.flags & 32768 ? (Qe || s === 1 ? e = true : ka || (Ze & 536870912) !== 0 ? e = false : (er = e = true, (s === 2 || s === 9 || s === 3 || s === 6) && (s = Sn.current, s !== null && s.tag === 13 && (s.flags |= 16384))), cp(t, e)) : di(t);
    }
    function di(e) {
      var t = e;
      do {
        if ((t.flags & 32768) !== 0) {
          cp(t, er);
          return;
        }
        e = t.return;
        var a = Jx(t.alternate, t, Ll);
        if (a !== null) {
          qe = a;
          return;
        }
        if (t = t.sibling, t !== null) {
          qe = t;
          return;
        }
        qe = t = e;
      } while (t !== null);
      At === 0 && (At = 5);
    }
    function cp(e, t) {
      do {
        var a = ew(e.alternate, e);
        if (a !== null) {
          a.flags &= 32767, qe = a;
          return;
        }
        if (a = e.return, a !== null && (a.flags |= 32768, a.subtreeFlags = 0, a.deletions = null), !t && (e = e.sibling, e !== null)) {
          qe = e;
          return;
        }
        qe = e = a;
      } while (e !== null);
      At = 6, qe = null;
    }
    function up(e, t, a, s, u, h, w, M, z) {
      e.cancelPendingCommit = null;
      do
        fi();
      while (qt !== 0);
      if ((rt & 6) !== 0) throw Error(o(327));
      if (t !== null) {
        if (t === e.current) throw Error(o(177));
        if (h = t.lanes | t.childLanes, h |= Bc, Jn(e, a, h, w, M, z), e === pt && (qe = pt = null, Ze = 0), ja = t, lr = e, Rl = a, Zu = h, Fu = u, Jg = s, (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? (e.callbackNode = null, e.callbackPriority = 0, fw(Dl, function() {
          return gp(), null;
        })) : (e.callbackNode = null, e.callbackPriority = 0), s = (t.flags & 13878) !== 0, (t.subtreeFlags & 13878) !== 0 || s) {
          s = $.T, $.T = null, u = F.p, F.p = 2, w = rt, rt |= 4;
          try {
            tw(e, t, a);
          } finally {
            rt = w, F.p = u, $.T = s;
          }
        }
        qt = 1, dp(), fp(), hp();
      }
    }
    function dp() {
      if (qt === 1) {
        qt = 0;
        var e = lr, t = ja, a = (t.flags & 13878) !== 0;
        if ((t.subtreeFlags & 13878) !== 0 || a) {
          a = $.T, $.T = null;
          var s = F.p;
          F.p = 2;
          var u = rt;
          rt |= 4;
          try {
            qg(t, e);
            var h = dd, w = Qh(e.containerInfo), M = h.focusedElem, z = h.selectionRange;
            if (w !== M && M && M.ownerDocument && Fh(M.ownerDocument.documentElement, M)) {
              if (z !== null && Dc(M)) {
                var P = z.start, ne = z.end;
                if (ne === void 0 && (ne = P), "selectionStart" in M) M.selectionStart = P, M.selectionEnd = Math.min(ne, M.value.length);
                else {
                  var oe = M.ownerDocument || document, Z = oe && oe.defaultView || window;
                  if (Z.getSelection) {
                    var Q = Z.getSelection(), _e = M.textContent.length, Te = Math.min(z.start, _e), mt = z.end === void 0 ? Te : Math.min(z.end, _e);
                    !Q.extend && Te > mt && (w = mt, mt = Te, Te = w);
                    var V = Zh(M, Te), B = Zh(M, mt);
                    if (V && B && (Q.rangeCount !== 1 || Q.anchorNode !== V.node || Q.anchorOffset !== V.offset || Q.focusNode !== B.node || Q.focusOffset !== B.offset)) {
                      var G = oe.createRange();
                      G.setStart(V.node, V.offset), Q.removeAllRanges(), Te > mt ? (Q.addRange(G), Q.extend(B.node, B.offset)) : (G.setEnd(B.node, B.offset), Q.addRange(G));
                    }
                  }
                }
              }
              for (oe = [], Q = M; Q = Q.parentNode; ) Q.nodeType === 1 && oe.push({
                element: Q,
                left: Q.scrollLeft,
                top: Q.scrollTop
              });
              for (typeof M.focus == "function" && M.focus(), M = 0; M < oe.length; M++) {
                var ae = oe[M];
                ae.element.scrollLeft = ae.left, ae.element.scrollTop = ae.top;
              }
            }
            Ei = !!ud, dd = ud = null;
          } finally {
            rt = u, F.p = s, $.T = a;
          }
        }
        e.current = t, qt = 2;
      }
    }
    function fp() {
      if (qt === 2) {
        qt = 0;
        var e = lr, t = ja, a = (t.flags & 8772) !== 0;
        if ((t.subtreeFlags & 8772) !== 0 || a) {
          a = $.T, $.T = null;
          var s = F.p;
          F.p = 2;
          var u = rt;
          rt |= 4;
          try {
            Yg(e, t.alternate, t);
          } finally {
            rt = u, F.p = s, $.T = a;
          }
        }
        qt = 3;
      }
    }
    function hp() {
      if (qt === 4 || qt === 3) {
        qt = 0, vt();
        var e = lr, t = ja, a = Rl, s = Jg;
        (t.subtreeFlags & 10256) !== 0 || (t.flags & 10256) !== 0 ? qt = 5 : (qt = 0, ja = lr = null, mp(e, e.pendingLanes));
        var u = e.pendingLanes;
        if (u === 0 && (nr = null), Ka(a), t = t.stateNode, xt && typeof xt.onCommitFiberRoot == "function") try {
          xt.onCommitFiberRoot(en, t, void 0, (t.current.flags & 128) === 128);
        } catch {
        }
        if (s !== null) {
          t = $.T, u = F.p, F.p = 2, $.T = null;
          try {
            for (var h = e.onRecoverableError, w = 0; w < s.length; w++) {
              var M = s[w];
              h(M.value, {
                componentStack: M.stack
              });
            }
          } finally {
            $.T = t, F.p = u;
          }
        }
        (Rl & 3) !== 0 && fi(), il(e), u = e.pendingLanes, (a & 261930) !== 0 && (u & 42) !== 0 ? e === Qu ? Mo++ : (Mo = 0, Qu = e) : Mo = 0, jo(0);
      }
    }
    function mp(e, t) {
      (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, so(t)));
    }
    function fi() {
      return dp(), fp(), hp(), gp();
    }
    function gp() {
      if (qt !== 5) return false;
      var e = lr, t = Zu;
      Zu = 0;
      var a = Ka(Rl), s = $.T, u = F.p;
      try {
        F.p = 32 > a ? 32 : a, $.T = null, a = Fu, Fu = null;
        var h = lr, w = Rl;
        if (qt = 0, ja = lr = null, Rl = 0, (rt & 6) !== 0) throw Error(o(331));
        var M = rt;
        if (rt |= 4, Fg(h.current), Pg(h, h.current, w, a), rt = M, jo(0, false), xt && typeof xt.onPostCommitFiberRoot == "function") try {
          xt.onPostCommitFiberRoot(en, h);
        } catch {
        }
        return true;
      } finally {
        F.p = u, $.T = s, mp(e, t);
      }
    }
    function pp(e, t, a) {
      t = Tn(a, t), t = Lu(e.stateNode, t, 2), e = Fl(e, t, 2), e !== null && (Er(e, 2), il(e));
    }
    function ut(e, t, a) {
      if (e.tag === 3) pp(e, e, a);
      else for (; t !== null; ) {
        if (t.tag === 3) {
          pp(t, e, a);
          break;
        } else if (t.tag === 1) {
          var s = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof s.componentDidCatch == "function" && (nr === null || !nr.has(s))) {
            e = Tn(a, e), a = yg(2), s = Fl(t, a, 2), s !== null && (bg(a, s, t, e), Er(s, 2), il(s));
            break;
          }
        }
        t = t.return;
      }
    }
    function ed(e, t, a) {
      var s = e.pingCache;
      if (s === null) {
        s = e.pingCache = new rw();
        var u = /* @__PURE__ */ new Set();
        s.set(t, u);
      } else u = s.get(t), u === void 0 && (u = /* @__PURE__ */ new Set(), s.set(t, u));
      u.has(a) || (Gu = true, u.add(a), e = cw.bind(null, e, t, a), t.then(e, e));
    }
    function cw(e, t, a) {
      var s = e.pingCache;
      s !== null && s.delete(t), e.pingedLanes |= e.suspendedLanes & a, e.warmLanes &= ~a, pt === e && (Ze & a) === a && (At === 4 || At === 3 && (Ze & 62914560) === Ze && 300 > Ke() - oi ? (rt & 2) === 0 && La(e, 0) : Pu |= a, Ma === Ze && (Ma = 0)), il(e);
    }
    function yp(e, t) {
      t === 0 && (t = ea()), e = Rr(e, t), e !== null && (Er(e, t), il(e));
    }
    function uw(e) {
      var t = e.memoizedState, a = 0;
      t !== null && (a = t.retryLane), yp(e, a);
    }
    function dw(e, t) {
      var a = 0;
      switch (e.tag) {
        case 31:
        case 13:
          var s = e.stateNode, u = e.memoizedState;
          u !== null && (a = u.retryLane);
          break;
        case 19:
          s = e.stateNode;
          break;
        case 22:
          s = e.stateNode._retryCache;
          break;
        default:
          throw Error(o(314));
      }
      s !== null && s.delete(t), yp(e, a);
    }
    function fw(e, t) {
      return Ae(e, t);
    }
    var hi = null, Aa = null, td = false, mi = false, nd = false, ar = 0;
    function il(e) {
      e !== Aa && e.next === null && (Aa === null ? hi = Aa = e : Aa = Aa.next = e), mi = true, td || (td = true, mw());
    }
    function jo(e, t) {
      if (!nd && mi) {
        nd = true;
        do
          for (var a = false, s = hi; s !== null; ) {
            if (e !== 0) {
              var u = s.pendingLanes;
              if (u === 0) var h = 0;
              else {
                var w = s.suspendedLanes, M = s.pingedLanes;
                h = (1 << 31 - jt(42 | e) + 1) - 1, h &= u & ~(w & ~M), h = h & 201326741 ? h & 201326741 | 1 : h ? h | 2 : 0;
              }
              h !== 0 && (a = true, wp(s, h));
            } else h = Ze, h = Ul(s, s === pt ? h : 0, s.cancelPendingCommit !== null || s.timeoutHandle !== -1), (h & 3) === 0 || hl(s, h) || (a = true, wp(s, h));
            s = s.next;
          }
        while (a);
        nd = false;
      }
    }
    function hw() {
      bp();
    }
    function bp() {
      mi = td = false;
      var e = 0;
      ar !== 0 && Ew() && (e = ar);
      for (var t = Ke(), a = null, s = hi; s !== null; ) {
        var u = s.next, h = vp(s, t);
        h === 0 ? (s.next = null, a === null ? hi = u : a.next = u, u === null && (Aa = a)) : (a = s, (e !== 0 || (h & 3) !== 0) && (mi = true)), s = u;
      }
      qt !== 0 && qt !== 5 || jo(e), ar !== 0 && (ar = 0);
    }
    function vp(e, t) {
      for (var a = e.suspendedLanes, s = e.pingedLanes, u = e.expirationTimes, h = e.pendingLanes & -62914561; 0 < h; ) {
        var w = 31 - jt(h), M = 1 << w, z = u[w];
        z === -1 ? ((M & a) === 0 || (M & s) !== 0) && (u[w] = ps(M, t)) : z <= t && (e.expiredLanes |= M), h &= ~M;
      }
      if (t = pt, a = Ze, a = Ul(e, e === t ? a : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), s = e.callbackNode, a === 0 || e === t && (ct === 2 || ct === 9) || e.cancelPendingCommit !== null) return s !== null && s !== null && Ie(s), e.callbackNode = null, e.callbackPriority = 0;
      if ((a & 3) === 0 || hl(e, a)) {
        if (t = a & -a, t === e.callbackPriority) return t;
        switch (s !== null && Ie(s), Ka(a)) {
          case 2:
          case 8:
            a = Wn;
            break;
          case 32:
            a = Dl;
            break;
          case 268435456:
            a = lt;
            break;
          default:
            a = Dl;
        }
        return s = xp.bind(null, e), a = Ae(a, s), e.callbackPriority = t, e.callbackNode = a, t;
      }
      return s !== null && s !== null && Ie(s), e.callbackPriority = 2, e.callbackNode = null, 2;
    }
    function xp(e, t) {
      if (qt !== 0 && qt !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
      var a = e.callbackNode;
      if (fi() && e.callbackNode !== a) return null;
      var s = Ze;
      return s = Ul(e, e === pt ? s : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), s === 0 ? null : (tp(e, s, t), vp(e, Ke()), e.callbackNode != null && e.callbackNode === a ? xp.bind(null, e) : null);
    }
    function wp(e, t) {
      if (fi()) return null;
      tp(e, t, true);
    }
    function mw() {
      kw(function() {
        (rt & 6) !== 0 ? Ae(un, hw) : bp();
      });
    }
    function ld() {
      if (ar === 0) {
        var e = pa;
        e === 0 && (e = fl, fl <<= 1, (fl & 261888) === 0 && (fl = 256)), ar = e;
      }
      return ar;
    }
    function Sp(e) {
      return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : Ss("" + e);
    }
    function Cp(e, t) {
      var a = t.ownerDocument.createElement("input");
      return a.name = t.name, a.value = t.value, e.id && a.setAttribute("form", e.id), t.parentNode.insertBefore(a, t), e = new FormData(e), a.parentNode.removeChild(a), e;
    }
    function gw(e, t, a, s, u) {
      if (t === "submit" && a && a.stateNode === u) {
        var h = Sp((u[le] || null).action), w = s.submitter;
        w && (t = (t = w[le] || null) ? Sp(t.formAction) : w.getAttribute("formAction"), t !== null && (h = t, w = null));
        var M = new ks("action", "action", null, s, u);
        e.push({
          event: M,
          listeners: [
            {
              instance: null,
              listener: function() {
                if (s.defaultPrevented) {
                  if (ar !== 0) {
                    var z = w ? Cp(u, w) : new FormData(u);
                    Cu(a, {
                      pending: true,
                      data: z,
                      method: u.method,
                      action: h
                    }, null, z);
                  }
                } else typeof h == "function" && (M.preventDefault(), z = w ? Cp(u, w) : new FormData(u), Cu(a, {
                  pending: true,
                  data: z,
                  method: u.method,
                  action: h
                }, h, z));
              },
              currentTarget: u
            }
          ]
        });
      }
    }
    for (var rd = 0; rd < Yc.length; rd++) {
      var ad = Yc[rd], pw = ad.toLowerCase(), yw = ad[0].toUpperCase() + ad.slice(1);
      qn(pw, "on" + yw);
    }
    qn(em, "onAnimationEnd"), qn(tm, "onAnimationIteration"), qn(nm, "onAnimationStart"), qn("dblclick", "onDoubleClick"), qn("focusin", "onFocus"), qn("focusout", "onBlur"), qn(Nx, "onTransitionRun"), qn(Ox, "onTransitionStart"), qn(Ix, "onTransitionCancel"), qn(lm, "onTransitionEnd"), $n("onMouseEnter", [
      "mouseout",
      "mouseover"
    ]), $n("onMouseLeave", [
      "mouseout",
      "mouseover"
    ]), $n("onPointerEnter", [
      "pointerout",
      "pointerover"
    ]), $n("onPointerLeave", [
      "pointerout",
      "pointerover"
    ]), vn("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), vn("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), vn("onBeforeInput", [
      "compositionend",
      "keypress",
      "textInput",
      "paste"
    ]), vn("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), vn("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), vn("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Lo = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), bw = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Lo));
    function Ep(e, t) {
      t = (t & 4) !== 0;
      for (var a = 0; a < e.length; a++) {
        var s = e[a], u = s.event;
        s = s.listeners;
        e: {
          var h = void 0;
          if (t) for (var w = s.length - 1; 0 <= w; w--) {
            var M = s[w], z = M.instance, P = M.currentTarget;
            if (M = M.listener, z !== h && u.isPropagationStopped()) break e;
            h = M, u.currentTarget = P;
            try {
              h(u);
            } catch (ne) {
              Ls(ne);
            }
            u.currentTarget = null, h = z;
          }
          else for (w = 0; w < s.length; w++) {
            if (M = s[w], z = M.instance, P = M.currentTarget, M = M.listener, z !== h && u.isPropagationStopped()) break e;
            h = M, u.currentTarget = P;
            try {
              h(u);
            } catch (ne) {
              Ls(ne);
            }
            u.currentTarget = null, h = z;
          }
        }
      }
    }
    function Ge(e, t) {
      var a = t[Lt];
      a === void 0 && (a = t[Lt] = /* @__PURE__ */ new Set());
      var s = e + "__bubble";
      a.has(s) || (_p(t, e, 2, false), a.add(s));
    }
    function od(e, t, a) {
      var s = 0;
      t && (s |= 4), _p(a, e, s, t);
    }
    var gi = "_reactListening" + Math.random().toString(36).slice(2);
    function sd(e) {
      if (!e[gi]) {
        e[gi] = true, nl.forEach(function(a) {
          a !== "selectionchange" && (bw.has(a) || od(a, false, e), od(a, true, e));
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[gi] || (t[gi] = true, od("selectionchange", false, t));
      }
    }
    function _p(e, t, a, s) {
      switch (ey(t)) {
        case 2:
          var u = Gw;
          break;
        case 8:
          u = Pw;
          break;
        default:
          u = Sd;
      }
      a = u.bind(null, t, a, e), u = void 0, !Mc || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (u = true), s ? u !== void 0 ? e.addEventListener(t, a, {
        capture: true,
        passive: u
      }) : e.addEventListener(t, a, true) : u !== void 0 ? e.addEventListener(t, a, {
        passive: u
      }) : e.addEventListener(t, a, false);
    }
    function id(e, t, a, s, u) {
      var h = s;
      if ((t & 1) === 0 && (t & 2) === 0 && s !== null) e: for (; ; ) {
        if (s === null) return;
        var w = s.tag;
        if (w === 3 || w === 4) {
          var M = s.stateNode.containerInfo;
          if (M === u) break;
          if (w === 4) for (w = s.return; w !== null; ) {
            var z = w.tag;
            if ((z === 3 || z === 4) && w.stateNode.containerInfo === u) return;
            w = w.return;
          }
          for (; M !== null; ) {
            if (w = Tt(M), w === null) return;
            if (z = w.tag, z === 5 || z === 6 || z === 26 || z === 27) {
              s = h = w;
              continue e;
            }
            M = M.parentNode;
          }
        }
        s = s.return;
      }
      Rh(function() {
        var P = h, ne = _c(a), oe = [];
        e: {
          var Z = rm.get(e);
          if (Z !== void 0) {
            var Q = ks, _e = e;
            switch (e) {
              case "keypress":
                if (Es(a) === 0) break e;
              case "keydown":
              case "keyup":
                Q = dx;
                break;
              case "focusin":
                _e = "focus", Q = Ac;
                break;
              case "focusout":
                _e = "blur", Q = Ac;
                break;
              case "beforeblur":
              case "afterblur":
                Q = Ac;
                break;
              case "click":
                if (a.button === 2) break e;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                Q = Nh;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                Q = J1;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                Q = mx;
                break;
              case em:
              case tm:
              case nm:
                Q = nx;
                break;
              case lm:
                Q = px;
                break;
              case "scroll":
              case "scrollend":
                Q = Q1;
                break;
              case "wheel":
                Q = bx;
                break;
              case "copy":
              case "cut":
              case "paste":
                Q = rx;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                Q = Ih;
                break;
              case "toggle":
              case "beforetoggle":
                Q = xx;
            }
            var Te = (t & 4) !== 0, mt = !Te && (e === "scroll" || e === "scrollend"), V = Te ? Z !== null ? Z + "Capture" : null : Z;
            Te = [];
            for (var B = P, G; B !== null; ) {
              var ae = B;
              if (G = ae.stateNode, ae = ae.tag, ae !== 5 && ae !== 26 && ae !== 27 || G === null || V === null || (ae = Fa(B, V), ae != null && Te.push(Ro(B, ae, G))), mt) break;
              B = B.return;
            }
            0 < Te.length && (Z = new Q(Z, _e, null, a, ne), oe.push({
              event: Z,
              listeners: Te
            }));
          }
        }
        if ((t & 7) === 0) {
          e: {
            if (Z = e === "mouseover" || e === "pointerover", Q = e === "mouseout" || e === "pointerout", Z && a !== Ec && (_e = a.relatedTarget || a.fromElement) && (Tt(_e) || _e[De])) break e;
            if ((Q || Z) && (Z = ne.window === ne ? ne : (Z = ne.ownerDocument) ? Z.defaultView || Z.parentWindow : window, Q ? (_e = a.relatedTarget || a.toElement, Q = P, _e = _e ? Tt(_e) : null, _e !== null && (mt = c(_e), Te = _e.tag, _e !== mt || Te !== 5 && Te !== 27 && Te !== 6) && (_e = null)) : (Q = null, _e = P), Q !== _e)) {
              if (Te = Nh, ae = "onMouseLeave", V = "onMouseEnter", B = "mouse", (e === "pointerout" || e === "pointerover") && (Te = Ih, ae = "onPointerLeave", V = "onPointerEnter", B = "pointer"), mt = Q == null ? Z : Pt(Q), G = _e == null ? Z : Pt(_e), Z = new Te(ae, B + "leave", Q, a, ne), Z.target = mt, Z.relatedTarget = G, ae = null, Tt(ne) === P && (Te = new Te(V, B + "enter", _e, a, ne), Te.target = G, Te.relatedTarget = mt, ae = Te), mt = ae, Q && _e) t: {
                for (Te = vw, V = Q, B = _e, G = 0, ae = V; ae; ae = Te(ae)) G++;
                ae = 0;
                for (var Le = B; Le; Le = Te(Le)) ae++;
                for (; 0 < G - ae; ) V = Te(V), G--;
                for (; 0 < ae - G; ) B = Te(B), ae--;
                for (; G--; ) {
                  if (V === B || B !== null && V === B.alternate) {
                    Te = V;
                    break t;
                  }
                  V = Te(V), B = Te(B);
                }
                Te = null;
              }
              else Te = null;
              Q !== null && kp(oe, Z, Q, Te, false), _e !== null && mt !== null && kp(oe, mt, _e, Te, true);
            }
          }
          e: {
            if (Z = P ? Pt(P) : window, Q = Z.nodeName && Z.nodeName.toLowerCase(), Q === "select" || Q === "input" && Z.type === "file") var et = Vh;
            else if (Bh(Z)) if ($h) et = Rx;
            else {
              et = jx;
              var Me = Mx;
            }
            else Q = Z.nodeName, !Q || Q.toLowerCase() !== "input" || Z.type !== "checkbox" && Z.type !== "radio" ? P && Cc(P.elementType) && (et = Vh) : et = Lx;
            if (et && (et = et(e, P))) {
              Xh(oe, et, a, ne);
              break e;
            }
            Me && Me(e, Z, P), e === "focusout" && P && Z.type === "number" && P.memoizedProps.value != null && Sc(Z, "number", Z.value);
          }
          switch (Me = P ? Pt(P) : window, e) {
            case "focusin":
              (Bh(Me) || Me.contentEditable === "true") && (ia = Me, zc = P, ro = null);
              break;
            case "focusout":
              ro = zc = ia = null;
              break;
            case "mousedown":
              Hc = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              Hc = false, Wh(oe, a, ne);
              break;
            case "selectionchange":
              if (Tx) break;
            case "keydown":
            case "keyup":
              Wh(oe, a, ne);
          }
          var Ye;
          if (Nc) e: {
            switch (e) {
              case "compositionstart":
                var Fe = "onCompositionStart";
                break e;
              case "compositionend":
                Fe = "onCompositionEnd";
                break e;
              case "compositionupdate":
                Fe = "onCompositionUpdate";
                break e;
            }
            Fe = void 0;
          }
          else sa ? Uh(e, a) && (Fe = "onCompositionEnd") : e === "keydown" && a.keyCode === 229 && (Fe = "onCompositionStart");
          Fe && (Dh && a.locale !== "ko" && (sa || Fe !== "onCompositionStart" ? Fe === "onCompositionEnd" && sa && (Ye = Ah()) : (Vl = ne, jc = "value" in Vl ? Vl.value : Vl.textContent, sa = true)), Me = pi(P, Fe), 0 < Me.length && (Fe = new Oh(Fe, e, null, a, ne), oe.push({
            event: Fe,
            listeners: Me
          }), Ye ? Fe.data = Ye : (Ye = Yh(a), Ye !== null && (Fe.data = Ye)))), (Ye = Sx ? Cx(e, a) : Ex(e, a)) && (Fe = pi(P, "onBeforeInput"), 0 < Fe.length && (Me = new Oh("onBeforeInput", "beforeinput", null, a, ne), oe.push({
            event: Me,
            listeners: Fe
          }), Me.data = Ye)), gw(oe, e, P, a, ne);
        }
        Ep(oe, t);
      });
    }
    function Ro(e, t, a) {
      return {
        instance: e,
        listener: t,
        currentTarget: a
      };
    }
    function pi(e, t) {
      for (var a = t + "Capture", s = []; e !== null; ) {
        var u = e, h = u.stateNode;
        if (u = u.tag, u !== 5 && u !== 26 && u !== 27 || h === null || (u = Fa(e, a), u != null && s.unshift(Ro(e, u, h)), u = Fa(e, t), u != null && s.push(Ro(e, u, h))), e.tag === 3) return s;
        e = e.return;
      }
      return [];
    }
    function vw(e) {
      if (e === null) return null;
      do
        e = e.return;
      while (e && e.tag !== 5 && e.tag !== 27);
      return e || null;
    }
    function kp(e, t, a, s, u) {
      for (var h = t._reactName, w = []; a !== null && a !== s; ) {
        var M = a, z = M.alternate, P = M.stateNode;
        if (M = M.tag, z !== null && z === s) break;
        M !== 5 && M !== 26 && M !== 27 || P === null || (z = P, u ? (P = Fa(a, h), P != null && w.unshift(Ro(a, P, z))) : u || (P = Fa(a, h), P != null && w.push(Ro(a, P, z)))), a = a.return;
      }
      w.length !== 0 && e.push({
        event: t,
        listeners: w
      });
    }
    var xw = /\r\n?/g, ww = /\u0000|\uFFFD/g;
    function Mp(e) {
      return (typeof e == "string" ? e : "" + e).replace(xw, `
`).replace(ww, "");
    }
    function jp(e, t) {
      return t = Mp(t), Mp(e) === t;
    }
    function ht(e, t, a, s, u, h) {
      switch (a) {
        case "children":
          typeof s == "string" ? t === "body" || t === "textarea" && s === "" || ra(e, s) : (typeof s == "number" || typeof s == "bigint") && t !== "body" && ra(e, "" + s);
          break;
        case "className":
          Xl(e, "class", s);
          break;
        case "tabIndex":
          Xl(e, "tabindex", s);
          break;
        case "dir":
        case "role":
        case "viewBox":
        case "width":
        case "height":
          Xl(e, a, s);
          break;
        case "style":
          jh(e, s, h);
          break;
        case "data":
          if (t !== "object") {
            Xl(e, "data", s);
            break;
          }
        case "src":
        case "href":
          if (s === "" && (t !== "a" || a !== "href")) {
            e.removeAttribute(a);
            break;
          }
          if (s == null || typeof s == "function" || typeof s == "symbol" || typeof s == "boolean") {
            e.removeAttribute(a);
            break;
          }
          s = Ss("" + s), e.setAttribute(a, s);
          break;
        case "action":
        case "formAction":
          if (typeof s == "function") {
            e.setAttribute(a, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
            break;
          } else typeof h == "function" && (a === "formAction" ? (t !== "input" && ht(e, t, "name", u.name, u, null), ht(e, t, "formEncType", u.formEncType, u, null), ht(e, t, "formMethod", u.formMethod, u, null), ht(e, t, "formTarget", u.formTarget, u, null)) : (ht(e, t, "encType", u.encType, u, null), ht(e, t, "method", u.method, u, null), ht(e, t, "target", u.target, u, null)));
          if (s == null || typeof s == "symbol" || typeof s == "boolean") {
            e.removeAttribute(a);
            break;
          }
          s = Ss("" + s), e.setAttribute(a, s);
          break;
        case "onClick":
          s != null && (e.onclick = gl);
          break;
        case "onScroll":
          s != null && Ge("scroll", e);
          break;
        case "onScrollEnd":
          s != null && Ge("scrollend", e);
          break;
        case "dangerouslySetInnerHTML":
          if (s != null) {
            if (typeof s != "object" || !("__html" in s)) throw Error(o(61));
            if (a = s.__html, a != null) {
              if (u.children != null) throw Error(o(60));
              e.innerHTML = a;
            }
          }
          break;
        case "multiple":
          e.multiple = s && typeof s != "function" && typeof s != "symbol";
          break;
        case "muted":
          e.muted = s && typeof s != "function" && typeof s != "symbol";
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "defaultValue":
        case "defaultChecked":
        case "innerHTML":
        case "ref":
          break;
        case "autoFocus":
          break;
        case "xlinkHref":
          if (s == null || typeof s == "function" || typeof s == "boolean" || typeof s == "symbol") {
            e.removeAttribute("xlink:href");
            break;
          }
          a = Ss("" + s), e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", a);
          break;
        case "contentEditable":
        case "spellCheck":
        case "draggable":
        case "value":
        case "autoReverse":
        case "externalResourcesRequired":
        case "focusable":
        case "preserveAlpha":
          s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(a, "" + s) : e.removeAttribute(a);
          break;
        case "inert":
        case "allowFullScreen":
        case "async":
        case "autoPlay":
        case "controls":
        case "default":
        case "defer":
        case "disabled":
        case "disablePictureInPicture":
        case "disableRemotePlayback":
        case "formNoValidate":
        case "hidden":
        case "loop":
        case "noModule":
        case "noValidate":
        case "open":
        case "playsInline":
        case "readOnly":
        case "required":
        case "reversed":
        case "scoped":
        case "seamless":
        case "itemScope":
          s && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(a, "") : e.removeAttribute(a);
          break;
        case "capture":
        case "download":
          s === true ? e.setAttribute(a, "") : s !== false && s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(a, s) : e.removeAttribute(a);
          break;
        case "cols":
        case "rows":
        case "size":
        case "span":
          s != null && typeof s != "function" && typeof s != "symbol" && !isNaN(s) && 1 <= s ? e.setAttribute(a, s) : e.removeAttribute(a);
          break;
        case "rowSpan":
        case "start":
          s == null || typeof s == "function" || typeof s == "symbol" || isNaN(s) ? e.removeAttribute(a) : e.setAttribute(a, s);
          break;
        case "popover":
          Ge("beforetoggle", e), Ge("toggle", e), rl(e, "popover", s);
          break;
        case "xlinkActuate":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:actuate", s);
          break;
        case "xlinkArcrole":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", s);
          break;
        case "xlinkRole":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:role", s);
          break;
        case "xlinkShow":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:show", s);
          break;
        case "xlinkTitle":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:title", s);
          break;
        case "xlinkType":
          dn(e, "http://www.w3.org/1999/xlink", "xlink:type", s);
          break;
        case "xmlBase":
          dn(e, "http://www.w3.org/XML/1998/namespace", "xml:base", s);
          break;
        case "xmlLang":
          dn(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", s);
          break;
        case "xmlSpace":
          dn(e, "http://www.w3.org/XML/1998/namespace", "xml:space", s);
          break;
        case "is":
          rl(e, "is", s);
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          (!(2 < a.length) || a[0] !== "o" && a[0] !== "O" || a[1] !== "n" && a[1] !== "N") && (a = Z1.get(a) || a, rl(e, a, s));
      }
    }
    function cd(e, t, a, s, u, h) {
      switch (a) {
        case "style":
          jh(e, s, h);
          break;
        case "dangerouslySetInnerHTML":
          if (s != null) {
            if (typeof s != "object" || !("__html" in s)) throw Error(o(61));
            if (a = s.__html, a != null) {
              if (u.children != null) throw Error(o(60));
              e.innerHTML = a;
            }
          }
          break;
        case "children":
          typeof s == "string" ? ra(e, s) : (typeof s == "number" || typeof s == "bigint") && ra(e, "" + s);
          break;
        case "onScroll":
          s != null && Ge("scroll", e);
          break;
        case "onScrollEnd":
          s != null && Ge("scrollend", e);
          break;
        case "onClick":
          s != null && (e.onclick = gl);
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "innerHTML":
        case "ref":
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          if (!ll.hasOwnProperty(a)) e: {
            if (a[0] === "o" && a[1] === "n" && (u = a.endsWith("Capture"), t = a.slice(2, u ? a.length - 7 : void 0), h = e[le] || null, h = h != null ? h[a] : null, typeof h == "function" && e.removeEventListener(t, h, u), typeof s == "function")) {
              typeof h != "function" && h !== null && (a in e ? e[a] = null : e.hasAttribute(a) && e.removeAttribute(a)), e.addEventListener(t, s, u);
              break e;
            }
            a in e ? e[a] = s : s === true ? e.setAttribute(a, "") : rl(e, a, s);
          }
      }
    }
    function Jt(e, t, a) {
      switch (t) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "img":
          Ge("error", e), Ge("load", e);
          var s = false, u = false, h;
          for (h in a) if (a.hasOwnProperty(h)) {
            var w = a[h];
            if (w != null) switch (h) {
              case "src":
                s = true;
                break;
              case "srcSet":
                u = true;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(o(137, t));
              default:
                ht(e, t, h, w, a, null);
            }
          }
          u && ht(e, t, "srcSet", a.srcSet, a, null), s && ht(e, t, "src", a.src, a, null);
          return;
        case "input":
          Ge("invalid", e);
          var M = h = w = u = null, z = null, P = null;
          for (s in a) if (a.hasOwnProperty(s)) {
            var ne = a[s];
            if (ne != null) switch (s) {
              case "name":
                u = ne;
                break;
              case "type":
                w = ne;
                break;
              case "checked":
                z = ne;
                break;
              case "defaultChecked":
                P = ne;
                break;
              case "value":
                h = ne;
                break;
              case "defaultValue":
                M = ne;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (ne != null) throw Error(o(137, t));
                break;
              default:
                ht(e, t, s, ne, a, null);
            }
          }
          Eh(e, h, M, z, P, w, u, false);
          return;
        case "select":
          Ge("invalid", e), s = w = h = null;
          for (u in a) if (a.hasOwnProperty(u) && (M = a[u], M != null)) switch (u) {
            case "value":
              h = M;
              break;
            case "defaultValue":
              w = M;
              break;
            case "multiple":
              s = M;
            default:
              ht(e, t, u, M, a, null);
          }
          t = h, a = w, e.multiple = !!s, t != null ? la(e, !!s, t, false) : a != null && la(e, !!s, a, true);
          return;
        case "textarea":
          Ge("invalid", e), h = u = s = null;
          for (w in a) if (a.hasOwnProperty(w) && (M = a[w], M != null)) switch (w) {
            case "value":
              s = M;
              break;
            case "defaultValue":
              u = M;
              break;
            case "children":
              h = M;
              break;
            case "dangerouslySetInnerHTML":
              if (M != null) throw Error(o(91));
              break;
            default:
              ht(e, t, w, M, a, null);
          }
          kh(e, s, u, h);
          return;
        case "option":
          for (z in a) if (a.hasOwnProperty(z) && (s = a[z], s != null)) switch (z) {
            case "selected":
              e.selected = s && typeof s != "function" && typeof s != "symbol";
              break;
            default:
              ht(e, t, z, s, a, null);
          }
          return;
        case "dialog":
          Ge("beforetoggle", e), Ge("toggle", e), Ge("cancel", e), Ge("close", e);
          break;
        case "iframe":
        case "object":
          Ge("load", e);
          break;
        case "video":
        case "audio":
          for (s = 0; s < Lo.length; s++) Ge(Lo[s], e);
          break;
        case "image":
          Ge("error", e), Ge("load", e);
          break;
        case "details":
          Ge("toggle", e);
          break;
        case "embed":
        case "source":
        case "link":
          Ge("error", e), Ge("load", e);
        case "area":
        case "base":
        case "br":
        case "col":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "track":
        case "wbr":
        case "menuitem":
          for (P in a) if (a.hasOwnProperty(P) && (s = a[P], s != null)) switch (P) {
            case "children":
            case "dangerouslySetInnerHTML":
              throw Error(o(137, t));
            default:
              ht(e, t, P, s, a, null);
          }
          return;
        default:
          if (Cc(t)) {
            for (ne in a) a.hasOwnProperty(ne) && (s = a[ne], s !== void 0 && cd(e, t, ne, s, a, void 0));
            return;
          }
      }
      for (M in a) a.hasOwnProperty(M) && (s = a[M], s != null && ht(e, t, M, s, a, null));
    }
    function Sw(e, t, a, s) {
      switch (t) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "input":
          var u = null, h = null, w = null, M = null, z = null, P = null, ne = null;
          for (Q in a) {
            var oe = a[Q];
            if (a.hasOwnProperty(Q) && oe != null) switch (Q) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                z = oe;
              default:
                s.hasOwnProperty(Q) || ht(e, t, Q, null, s, oe);
            }
          }
          for (var Z in s) {
            var Q = s[Z];
            if (oe = a[Z], s.hasOwnProperty(Z) && (Q != null || oe != null)) switch (Z) {
              case "type":
                h = Q;
                break;
              case "name":
                u = Q;
                break;
              case "checked":
                P = Q;
                break;
              case "defaultChecked":
                ne = Q;
                break;
              case "value":
                w = Q;
                break;
              case "defaultValue":
                M = Q;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (Q != null) throw Error(o(137, t));
                break;
              default:
                Q !== oe && ht(e, t, Z, Q, s, oe);
            }
          }
          wc(e, w, M, z, P, ne, h, u);
          return;
        case "select":
          Q = w = M = Z = null;
          for (h in a) if (z = a[h], a.hasOwnProperty(h) && z != null) switch (h) {
            case "value":
              break;
            case "multiple":
              Q = z;
            default:
              s.hasOwnProperty(h) || ht(e, t, h, null, s, z);
          }
          for (u in s) if (h = s[u], z = a[u], s.hasOwnProperty(u) && (h != null || z != null)) switch (u) {
            case "value":
              Z = h;
              break;
            case "defaultValue":
              M = h;
              break;
            case "multiple":
              w = h;
            default:
              h !== z && ht(e, t, u, h, s, z);
          }
          t = M, a = w, s = Q, Z != null ? la(e, !!a, Z, false) : !!s != !!a && (t != null ? la(e, !!a, t, true) : la(e, !!a, a ? [] : "", false));
          return;
        case "textarea":
          Q = Z = null;
          for (M in a) if (u = a[M], a.hasOwnProperty(M) && u != null && !s.hasOwnProperty(M)) switch (M) {
            case "value":
              break;
            case "children":
              break;
            default:
              ht(e, t, M, null, s, u);
          }
          for (w in s) if (u = s[w], h = a[w], s.hasOwnProperty(w) && (u != null || h != null)) switch (w) {
            case "value":
              Z = u;
              break;
            case "defaultValue":
              Q = u;
              break;
            case "children":
              break;
            case "dangerouslySetInnerHTML":
              if (u != null) throw Error(o(91));
              break;
            default:
              u !== h && ht(e, t, w, u, s, h);
          }
          _h(e, Z, Q);
          return;
        case "option":
          for (var _e in a) if (Z = a[_e], a.hasOwnProperty(_e) && Z != null && !s.hasOwnProperty(_e)) switch (_e) {
            case "selected":
              e.selected = false;
              break;
            default:
              ht(e, t, _e, null, s, Z);
          }
          for (z in s) if (Z = s[z], Q = a[z], s.hasOwnProperty(z) && Z !== Q && (Z != null || Q != null)) switch (z) {
            case "selected":
              e.selected = Z && typeof Z != "function" && typeof Z != "symbol";
              break;
            default:
              ht(e, t, z, Z, s, Q);
          }
          return;
        case "img":
        case "link":
        case "area":
        case "base":
        case "br":
        case "col":
        case "embed":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "source":
        case "track":
        case "wbr":
        case "menuitem":
          for (var Te in a) Z = a[Te], a.hasOwnProperty(Te) && Z != null && !s.hasOwnProperty(Te) && ht(e, t, Te, null, s, Z);
          for (P in s) if (Z = s[P], Q = a[P], s.hasOwnProperty(P) && Z !== Q && (Z != null || Q != null)) switch (P) {
            case "children":
            case "dangerouslySetInnerHTML":
              if (Z != null) throw Error(o(137, t));
              break;
            default:
              ht(e, t, P, Z, s, Q);
          }
          return;
        default:
          if (Cc(t)) {
            for (var mt in a) Z = a[mt], a.hasOwnProperty(mt) && Z !== void 0 && !s.hasOwnProperty(mt) && cd(e, t, mt, void 0, s, Z);
            for (ne in s) Z = s[ne], Q = a[ne], !s.hasOwnProperty(ne) || Z === Q || Z === void 0 && Q === void 0 || cd(e, t, ne, Z, s, Q);
            return;
          }
      }
      for (var V in a) Z = a[V], a.hasOwnProperty(V) && Z != null && !s.hasOwnProperty(V) && ht(e, t, V, null, s, Z);
      for (oe in s) Z = s[oe], Q = a[oe], !s.hasOwnProperty(oe) || Z === Q || Z == null && Q == null || ht(e, t, oe, Z, s, Q);
    }
    function Lp(e) {
      switch (e) {
        case "css":
        case "script":
        case "font":
        case "img":
        case "image":
        case "input":
        case "link":
          return true;
        default:
          return false;
      }
    }
    function Cw() {
      if (typeof performance.getEntriesByType == "function") {
        for (var e = 0, t = 0, a = performance.getEntriesByType("resource"), s = 0; s < a.length; s++) {
          var u = a[s], h = u.transferSize, w = u.initiatorType, M = u.duration;
          if (h && M && Lp(w)) {
            for (w = 0, M = u.responseEnd, s += 1; s < a.length; s++) {
              var z = a[s], P = z.startTime;
              if (P > M) break;
              var ne = z.transferSize, oe = z.initiatorType;
              ne && Lp(oe) && (z = z.responseEnd, w += ne * (z < M ? 1 : (M - P) / (z - P)));
            }
            if (--s, t += 8 * (h + w) / (u.duration / 1e3), e++, 10 < e) break;
          }
        }
        if (0 < e) return t / e / 1e6;
      }
      return navigator.connection && (e = navigator.connection.downlink, typeof e == "number") ? e : 5;
    }
    var ud = null, dd = null;
    function yi(e) {
      return e.nodeType === 9 ? e : e.ownerDocument;
    }
    function Rp(e) {
      switch (e) {
        case "http://www.w3.org/2000/svg":
          return 1;
        case "http://www.w3.org/1998/Math/MathML":
          return 2;
        default:
          return 0;
      }
    }
    function Ap(e, t) {
      if (e === 0) switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
      return e === 1 && t === "foreignObject" ? 0 : e;
    }
    function fd(e, t) {
      return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
    }
    var hd = null;
    function Ew() {
      var e = window.event;
      return e && e.type === "popstate" ? e === hd ? false : (hd = e, true) : (hd = null, false);
    }
    var Tp = typeof setTimeout == "function" ? setTimeout : void 0, _w = typeof clearTimeout == "function" ? clearTimeout : void 0, Np = typeof Promise == "function" ? Promise : void 0, kw = typeof queueMicrotask == "function" ? queueMicrotask : typeof Np < "u" ? function(e) {
      return Np.resolve(null).then(e).catch(Mw);
    } : Tp;
    function Mw(e) {
      setTimeout(function() {
        throw e;
      });
    }
    function or(e) {
      return e === "head";
    }
    function Op(e, t) {
      var a = t, s = 0;
      do {
        var u = a.nextSibling;
        if (e.removeChild(a), u && u.nodeType === 8) if (a = u.data, a === "/$" || a === "/&") {
          if (s === 0) {
            e.removeChild(u), Ia(t);
            return;
          }
          s--;
        } else if (a === "$" || a === "$?" || a === "$~" || a === "$!" || a === "&") s++;
        else if (a === "html") Ao(e.ownerDocument.documentElement);
        else if (a === "head") {
          a = e.ownerDocument.head, Ao(a);
          for (var h = a.firstChild; h; ) {
            var w = h.nextSibling, M = h.nodeName;
            h[ot] || M === "SCRIPT" || M === "STYLE" || M === "LINK" && h.rel.toLowerCase() === "stylesheet" || a.removeChild(h), h = w;
          }
        } else a === "body" && Ao(e.ownerDocument.body);
        a = u;
      } while (a);
      Ia(t);
    }
    function Ip(e, t) {
      var a = e;
      e = 0;
      do {
        var s = a.nextSibling;
        if (a.nodeType === 1 ? t ? (a._stashedDisplay = a.style.display, a.style.display = "none") : (a.style.display = a._stashedDisplay || "", a.getAttribute("style") === "" && a.removeAttribute("style")) : a.nodeType === 3 && (t ? (a._stashedText = a.nodeValue, a.nodeValue = "") : a.nodeValue = a._stashedText || ""), s && s.nodeType === 8) if (a = s.data, a === "/$") {
          if (e === 0) break;
          e--;
        } else a !== "$" && a !== "$?" && a !== "$~" && a !== "$!" || e++;
        a = s;
      } while (a);
    }
    function md(e) {
      var t = e.firstChild;
      for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
        var a = t;
        switch (t = t.nextSibling, a.nodeName) {
          case "HTML":
          case "HEAD":
          case "BODY":
            md(a), gt(a);
            continue;
          case "SCRIPT":
          case "STYLE":
            continue;
          case "LINK":
            if (a.rel.toLowerCase() === "stylesheet") continue;
        }
        e.removeChild(a);
      }
    }
    function jw(e, t, a, s) {
      for (; e.nodeType === 1; ) {
        var u = a;
        if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
          if (!s && (e.nodeName !== "INPUT" || e.type !== "hidden")) break;
        } else if (s) {
          if (!e[ot]) switch (t) {
            case "meta":
              if (!e.hasAttribute("itemprop")) break;
              return e;
            case "link":
              if (h = e.getAttribute("rel"), h === "stylesheet" && e.hasAttribute("data-precedence")) break;
              if (h !== u.rel || e.getAttribute("href") !== (u.href == null || u.href === "" ? null : u.href) || e.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin) || e.getAttribute("title") !== (u.title == null ? null : u.title)) break;
              return e;
            case "style":
              if (e.hasAttribute("data-precedence")) break;
              return e;
            case "script":
              if (h = e.getAttribute("src"), (h !== (u.src == null ? null : u.src) || e.getAttribute("type") !== (u.type == null ? null : u.type) || e.getAttribute("crossorigin") !== (u.crossOrigin == null ? null : u.crossOrigin)) && h && e.hasAttribute("async") && !e.hasAttribute("itemprop")) break;
              return e;
            default:
              return e;
          }
        } else if (t === "input" && e.type === "hidden") {
          var h = u.name == null ? null : "" + u.name;
          if (u.type === "hidden" && e.getAttribute("name") === h) return e;
        } else return e;
        if (e = zn(e.nextSibling), e === null) break;
      }
      return null;
    }
    function Lw(e, t, a) {
      if (t === "") return null;
      for (; e.nodeType !== 3; ) if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !a || (e = zn(e.nextSibling), e === null)) return null;
      return e;
    }
    function Dp(e, t) {
      for (; e.nodeType !== 8; ) if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !t || (e = zn(e.nextSibling), e === null)) return null;
      return e;
    }
    function gd(e) {
      return e.data === "$?" || e.data === "$~";
    }
    function pd(e) {
      return e.data === "$!" || e.data === "$?" && e.ownerDocument.readyState !== "loading";
    }
    function Rw(e, t) {
      var a = e.ownerDocument;
      if (e.data === "$~") e._reactRetry = t;
      else if (e.data !== "$?" || a.readyState !== "loading") t();
      else {
        var s = function() {
          t(), a.removeEventListener("DOMContentLoaded", s);
        };
        a.addEventListener("DOMContentLoaded", s), e._reactRetry = s;
      }
    }
    function zn(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
          if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "$~" || t === "&" || t === "F!" || t === "F") break;
          if (t === "/$" || t === "/&") return null;
        }
      }
      return e;
    }
    var yd = null;
    function zp(e) {
      e = e.nextSibling;
      for (var t = 0; e; ) {
        if (e.nodeType === 8) {
          var a = e.data;
          if (a === "/$" || a === "/&") {
            if (t === 0) return zn(e.nextSibling);
            t--;
          } else a !== "$" && a !== "$!" && a !== "$?" && a !== "$~" && a !== "&" || t++;
        }
        e = e.nextSibling;
      }
      return null;
    }
    function Hp(e) {
      e = e.previousSibling;
      for (var t = 0; e; ) {
        if (e.nodeType === 8) {
          var a = e.data;
          if (a === "$" || a === "$!" || a === "$?" || a === "$~" || a === "&") {
            if (t === 0) return e;
            t--;
          } else a !== "/$" && a !== "/&" || t++;
        }
        e = e.previousSibling;
      }
      return null;
    }
    function Up(e, t, a) {
      switch (t = yi(a), e) {
        case "html":
          if (e = t.documentElement, !e) throw Error(o(452));
          return e;
        case "head":
          if (e = t.head, !e) throw Error(o(453));
          return e;
        case "body":
          if (e = t.body, !e) throw Error(o(454));
          return e;
        default:
          throw Error(o(451));
      }
    }
    function Ao(e) {
      for (var t = e.attributes; t.length; ) e.removeAttributeNode(t[0]);
      gt(e);
    }
    var Hn = /* @__PURE__ */ new Map(), Yp = /* @__PURE__ */ new Set();
    function bi(e) {
      return typeof e.getRootNode == "function" ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument;
    }
    var Al = F.d;
    F.d = {
      f: Aw,
      r: Tw,
      D: Nw,
      C: Ow,
      L: Iw,
      m: Dw,
      X: Hw,
      S: zw,
      M: Uw
    };
    function Aw() {
      var e = Al.f(), t = ci();
      return e || t;
    }
    function Tw(e) {
      var t = Je(e);
      t !== null && t.tag === 5 && t.type === "form" ? lg(t) : Al.r(e);
    }
    var Ta = typeof document > "u" ? null : document;
    function Bp(e, t, a) {
      var s = Ta;
      if (s && typeof t == "string" && t) {
        var u = Rn(t);
        u = 'link[rel="' + e + '"][href="' + u + '"]', typeof a == "string" && (u += '[crossorigin="' + a + '"]'), Yp.has(u) || (Yp.add(u), e = {
          rel: e,
          crossOrigin: a,
          href: t
        }, s.querySelector(u) === null && (t = s.createElement("link"), Jt(t, "link", e), it(t), s.head.appendChild(t)));
      }
    }
    function Nw(e) {
      Al.D(e), Bp("dns-prefetch", e, null);
    }
    function Ow(e, t) {
      Al.C(e, t), Bp("preconnect", e, t);
    }
    function Iw(e, t, a) {
      Al.L(e, t, a);
      var s = Ta;
      if (s && e && t) {
        var u = 'link[rel="preload"][as="' + Rn(t) + '"]';
        t === "image" && a && a.imageSrcSet ? (u += '[imagesrcset="' + Rn(a.imageSrcSet) + '"]', typeof a.imageSizes == "string" && (u += '[imagesizes="' + Rn(a.imageSizes) + '"]')) : u += '[href="' + Rn(e) + '"]';
        var h = u;
        switch (t) {
          case "style":
            h = Na(e);
            break;
          case "script":
            h = Oa(e);
        }
        Hn.has(h) || (e = b({
          rel: "preload",
          href: t === "image" && a && a.imageSrcSet ? void 0 : e,
          as: t
        }, a), Hn.set(h, e), s.querySelector(u) !== null || t === "style" && s.querySelector(To(h)) || t === "script" && s.querySelector(No(h)) || (t = s.createElement("link"), Jt(t, "link", e), it(t), s.head.appendChild(t)));
      }
    }
    function Dw(e, t) {
      Al.m(e, t);
      var a = Ta;
      if (a && e) {
        var s = t && typeof t.as == "string" ? t.as : "script", u = 'link[rel="modulepreload"][as="' + Rn(s) + '"][href="' + Rn(e) + '"]', h = u;
        switch (s) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            h = Oa(e);
        }
        if (!Hn.has(h) && (e = b({
          rel: "modulepreload",
          href: e
        }, t), Hn.set(h, e), a.querySelector(u) === null)) {
          switch (s) {
            case "audioworklet":
            case "paintworklet":
            case "serviceworker":
            case "sharedworker":
            case "worker":
            case "script":
              if (a.querySelector(No(h))) return;
          }
          s = a.createElement("link"), Jt(s, "link", e), it(s), a.head.appendChild(s);
        }
      }
    }
    function zw(e, t, a) {
      Al.S(e, t, a);
      var s = Ta;
      if (s && e) {
        var u = Dt(s).hoistableStyles, h = Na(e);
        t = t || "default";
        var w = u.get(h);
        if (!w) {
          var M = {
            loading: 0,
            preload: null
          };
          if (w = s.querySelector(To(h))) M.loading = 5;
          else {
            e = b({
              rel: "stylesheet",
              href: e,
              "data-precedence": t
            }, a), (a = Hn.get(h)) && bd(e, a);
            var z = w = s.createElement("link");
            it(z), Jt(z, "link", e), z._p = new Promise(function(P, ne) {
              z.onload = P, z.onerror = ne;
            }), z.addEventListener("load", function() {
              M.loading |= 1;
            }), z.addEventListener("error", function() {
              M.loading |= 2;
            }), M.loading |= 4, vi(w, t, s);
          }
          w = {
            type: "stylesheet",
            instance: w,
            count: 1,
            state: M
          }, u.set(h, w);
        }
      }
    }
    function Hw(e, t) {
      Al.X(e, t);
      var a = Ta;
      if (a && e) {
        var s = Dt(a).hoistableScripts, u = Oa(e), h = s.get(u);
        h || (h = a.querySelector(No(u)), h || (e = b({
          src: e,
          async: true
        }, t), (t = Hn.get(u)) && vd(e, t), h = a.createElement("script"), it(h), Jt(h, "link", e), a.head.appendChild(h)), h = {
          type: "script",
          instance: h,
          count: 1,
          state: null
        }, s.set(u, h));
      }
    }
    function Uw(e, t) {
      Al.M(e, t);
      var a = Ta;
      if (a && e) {
        var s = Dt(a).hoistableScripts, u = Oa(e), h = s.get(u);
        h || (h = a.querySelector(No(u)), h || (e = b({
          src: e,
          async: true,
          type: "module"
        }, t), (t = Hn.get(u)) && vd(e, t), h = a.createElement("script"), it(h), Jt(h, "link", e), a.head.appendChild(h)), h = {
          type: "script",
          instance: h,
          count: 1,
          state: null
        }, s.set(u, h));
      }
    }
    function Xp(e, t, a, s) {
      var u = (u = ie.current) ? bi(u) : null;
      if (!u) throw Error(o(446));
      switch (e) {
        case "meta":
        case "title":
          return null;
        case "style":
          return typeof a.precedence == "string" && typeof a.href == "string" ? (t = Na(a.href), a = Dt(u).hoistableStyles, s = a.get(t), s || (s = {
            type: "style",
            instance: null,
            count: 0,
            state: null
          }, a.set(t, s)), s) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        case "link":
          if (a.rel === "stylesheet" && typeof a.href == "string" && typeof a.precedence == "string") {
            e = Na(a.href);
            var h = Dt(u).hoistableStyles, w = h.get(e);
            if (w || (u = u.ownerDocument || u, w = {
              type: "stylesheet",
              instance: null,
              count: 0,
              state: {
                loading: 0,
                preload: null
              }
            }, h.set(e, w), (h = u.querySelector(To(e))) && !h._p && (w.instance = h, w.state.loading = 5), Hn.has(e) || (a = {
              rel: "preload",
              as: "style",
              href: a.href,
              crossOrigin: a.crossOrigin,
              integrity: a.integrity,
              media: a.media,
              hrefLang: a.hrefLang,
              referrerPolicy: a.referrerPolicy
            }, Hn.set(e, a), h || Yw(u, e, a, w.state))), t && s === null) throw Error(o(528, ""));
            return w;
          }
          if (t && s !== null) throw Error(o(529, ""));
          return null;
        case "script":
          return t = a.async, a = a.src, typeof a == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = Oa(a), a = Dt(u).hoistableScripts, s = a.get(t), s || (s = {
            type: "script",
            instance: null,
            count: 0,
            state: null
          }, a.set(t, s)), s) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        default:
          throw Error(o(444, e));
      }
    }
    function Na(e) {
      return 'href="' + Rn(e) + '"';
    }
    function To(e) {
      return 'link[rel="stylesheet"][' + e + "]";
    }
    function Vp(e) {
      return b({}, e, {
        "data-precedence": e.precedence,
        precedence: null
      });
    }
    function Yw(e, t, a, s) {
      e.querySelector('link[rel="preload"][as="style"][' + t + "]") ? s.loading = 1 : (t = e.createElement("link"), s.preload = t, t.addEventListener("load", function() {
        return s.loading |= 1;
      }), t.addEventListener("error", function() {
        return s.loading |= 2;
      }), Jt(t, "link", a), it(t), e.head.appendChild(t));
    }
    function Oa(e) {
      return '[src="' + Rn(e) + '"]';
    }
    function No(e) {
      return "script[async]" + e;
    }
    function $p(e, t, a) {
      if (t.count++, t.instance === null) switch (t.type) {
        case "style":
          var s = e.querySelector('style[data-href~="' + Rn(a.href) + '"]');
          if (s) return t.instance = s, it(s), s;
          var u = b({}, a, {
            "data-href": a.href,
            "data-precedence": a.precedence,
            href: null,
            precedence: null
          });
          return s = (e.ownerDocument || e).createElement("style"), it(s), Jt(s, "style", u), vi(s, a.precedence, e), t.instance = s;
        case "stylesheet":
          u = Na(a.href);
          var h = e.querySelector(To(u));
          if (h) return t.state.loading |= 4, t.instance = h, it(h), h;
          s = Vp(a), (u = Hn.get(u)) && bd(s, u), h = (e.ownerDocument || e).createElement("link"), it(h);
          var w = h;
          return w._p = new Promise(function(M, z) {
            w.onload = M, w.onerror = z;
          }), Jt(h, "link", s), t.state.loading |= 4, vi(h, a.precedence, e), t.instance = h;
        case "script":
          return h = Oa(a.src), (u = e.querySelector(No(h))) ? (t.instance = u, it(u), u) : (s = a, (u = Hn.get(h)) && (s = b({}, a), vd(s, u)), e = e.ownerDocument || e, u = e.createElement("script"), it(u), Jt(u, "link", s), e.head.appendChild(u), t.instance = u);
        case "void":
          return null;
        default:
          throw Error(o(443, t.type));
      }
      else t.type === "stylesheet" && (t.state.loading & 4) === 0 && (s = t.instance, t.state.loading |= 4, vi(s, a.precedence, e));
      return t.instance;
    }
    function vi(e, t, a) {
      for (var s = a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), u = s.length ? s[s.length - 1] : null, h = u, w = 0; w < s.length; w++) {
        var M = s[w];
        if (M.dataset.precedence === t) h = M;
        else if (h !== u) break;
      }
      h ? h.parentNode.insertBefore(e, h.nextSibling) : (t = a.nodeType === 9 ? a.head : a, t.insertBefore(e, t.firstChild));
    }
    function bd(e, t) {
      e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.title == null && (e.title = t.title);
    }
    function vd(e, t) {
      e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.integrity == null && (e.integrity = t.integrity);
    }
    var xi = null;
    function qp(e, t, a) {
      if (xi === null) {
        var s = /* @__PURE__ */ new Map(), u = xi = /* @__PURE__ */ new Map();
        u.set(a, s);
      } else u = xi, s = u.get(a), s || (s = /* @__PURE__ */ new Map(), u.set(a, s));
      if (s.has(e)) return s;
      for (s.set(e, null), a = a.getElementsByTagName(e), u = 0; u < a.length; u++) {
        var h = a[u];
        if (!(h[ot] || h[$t] || e === "link" && h.getAttribute("rel") === "stylesheet") && h.namespaceURI !== "http://www.w3.org/2000/svg") {
          var w = h.getAttribute(t) || "";
          w = e + w;
          var M = s.get(w);
          M ? M.push(h) : s.set(w, [
            h
          ]);
        }
      }
      return s;
    }
    function Gp(e, t, a) {
      e = e.ownerDocument || e, e.head.insertBefore(a, t === "title" ? e.querySelector("head > title") : null);
    }
    function Bw(e, t, a) {
      if (a === 1 || t.itemProp != null) return false;
      switch (e) {
        case "meta":
        case "title":
          return true;
        case "style":
          if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "") break;
          return true;
        case "link":
          if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError) break;
          switch (t.rel) {
            case "stylesheet":
              return e = t.disabled, typeof t.precedence == "string" && e == null;
            default:
              return true;
          }
        case "script":
          if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string") return true;
      }
      return false;
    }
    function Pp(e) {
      return !(e.type === "stylesheet" && (e.state.loading & 3) === 0);
    }
    function Xw(e, t, a, s) {
      if (a.type === "stylesheet" && (typeof s.media != "string" || matchMedia(s.media).matches !== false) && (a.state.loading & 4) === 0) {
        if (a.instance === null) {
          var u = Na(s.href), h = t.querySelector(To(u));
          if (h) {
            t = h._p, t !== null && typeof t == "object" && typeof t.then == "function" && (e.count++, e = wi.bind(e), t.then(e, e)), a.state.loading |= 4, a.instance = h, it(h);
            return;
          }
          h = t.ownerDocument || t, s = Vp(s), (u = Hn.get(u)) && bd(s, u), h = h.createElement("link"), it(h);
          var w = h;
          w._p = new Promise(function(M, z) {
            w.onload = M, w.onerror = z;
          }), Jt(h, "link", s), a.instance = h;
        }
        e.stylesheets === null && (e.stylesheets = /* @__PURE__ */ new Map()), e.stylesheets.set(a, t), (t = a.state.preload) && (a.state.loading & 3) === 0 && (e.count++, a = wi.bind(e), t.addEventListener("load", a), t.addEventListener("error", a));
      }
    }
    var xd = 0;
    function Vw(e, t) {
      return e.stylesheets && e.count === 0 && Ci(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(a) {
        var s = setTimeout(function() {
          if (e.stylesheets && Ci(e, e.stylesheets), e.unsuspend) {
            var h = e.unsuspend;
            e.unsuspend = null, h();
          }
        }, 6e4 + t);
        0 < e.imgBytes && xd === 0 && (xd = 62500 * Cw());
        var u = setTimeout(function() {
          if (e.waitingForImages = false, e.count === 0 && (e.stylesheets && Ci(e, e.stylesheets), e.unsuspend)) {
            var h = e.unsuspend;
            e.unsuspend = null, h();
          }
        }, (e.imgBytes > xd ? 50 : 800) + t);
        return e.unsuspend = a, function() {
          e.unsuspend = null, clearTimeout(s), clearTimeout(u);
        };
      } : null;
    }
    function wi() {
      if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
        if (this.stylesheets) Ci(this, this.stylesheets);
        else if (this.unsuspend) {
          var e = this.unsuspend;
          this.unsuspend = null, e();
        }
      }
    }
    var Si = null;
    function Ci(e, t) {
      e.stylesheets = null, e.unsuspend !== null && (e.count++, Si = /* @__PURE__ */ new Map(), t.forEach($w, e), Si = null, wi.call(e));
    }
    function $w(e, t) {
      if (!(t.state.loading & 4)) {
        var a = Si.get(e);
        if (a) var s = a.get(null);
        else {
          a = /* @__PURE__ */ new Map(), Si.set(e, a);
          for (var u = e.querySelectorAll("link[data-precedence],style[data-precedence]"), h = 0; h < u.length; h++) {
            var w = u[h];
            (w.nodeName === "LINK" || w.getAttribute("media") !== "not all") && (a.set(w.dataset.precedence, w), s = w);
          }
          s && a.set(null, s);
        }
        u = t.instance, w = u.getAttribute("data-precedence"), h = a.get(w) || s, h === s && a.set(null, u), a.set(w, u), this.count++, s = wi.bind(this), u.addEventListener("load", s), u.addEventListener("error", s), h ? h.parentNode.insertBefore(u, h.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(u, e.firstChild)), t.state.loading |= 4;
      }
    }
    var Oo = {
      $$typeof: A,
      Provider: null,
      Consumer: null,
      _currentValue: fe,
      _currentValue2: fe,
      _threadCount: 0
    };
    function qw(e, t, a, s, u, h, w, M, z) {
      this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Cr(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Cr(0), this.hiddenUpdates = Cr(null), this.identifierPrefix = s, this.onUncaughtError = u, this.onCaughtError = h, this.onRecoverableError = w, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = z, this.incompleteTransitions = /* @__PURE__ */ new Map();
    }
    function Kp(e, t, a, s, u, h, w, M, z, P, ne, oe) {
      return e = new qw(e, t, a, w, z, P, ne, oe, M), t = 1, h === true && (t |= 24), h = wn(3, null, null, t), e.current = h, h.stateNode = e, t = Jc(), t.refCount++, e.pooledCache = t, t.refCount++, h.memoizedState = {
        element: s,
        isDehydrated: a,
        cache: t
      }, lu(h), e;
    }
    function Zp(e) {
      return e ? (e = da, e) : da;
    }
    function Fp(e, t, a, s, u, h) {
      u = Zp(u), s.context === null ? s.context = u : s.pendingContext = u, s = Zl(t), s.payload = {
        element: a
      }, h = h === void 0 ? null : h, h !== null && (s.callback = h), a = Fl(e, s, t), a !== null && (yn(a, e, t), fo(a, e, t));
    }
    function Qp(e, t) {
      if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var a = e.retryLane;
        e.retryLane = a !== 0 && a < t ? a : t;
      }
    }
    function wd(e, t) {
      Qp(e, t), (e = e.alternate) && Qp(e, t);
    }
    function Wp(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = Rr(e, 67108864);
        t !== null && yn(t, e, 67108864), wd(e, 67108864);
      }
    }
    function Jp(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = kn();
        t = el(t);
        var a = Rr(e, t);
        a !== null && yn(a, e, t), wd(e, t);
      }
    }
    var Ei = true;
    function Gw(e, t, a, s) {
      var u = $.T;
      $.T = null;
      var h = F.p;
      try {
        F.p = 2, Sd(e, t, a, s);
      } finally {
        F.p = h, $.T = u;
      }
    }
    function Pw(e, t, a, s) {
      var u = $.T;
      $.T = null;
      var h = F.p;
      try {
        F.p = 8, Sd(e, t, a, s);
      } finally {
        F.p = h, $.T = u;
      }
    }
    function Sd(e, t, a, s) {
      if (Ei) {
        var u = Cd(s);
        if (u === null) id(e, t, s, _i, a), ty(e, s);
        else if (Zw(u, e, t, a, s)) s.stopPropagation();
        else if (ty(e, s), t & 4 && -1 < Kw.indexOf(e)) {
          for (; u !== null; ) {
            var h = Je(u);
            if (h !== null) switch (h.tag) {
              case 3:
                if (h = h.stateNode, h.current.memoizedState.isDehydrated) {
                  var w = Ln(h.pendingLanes);
                  if (w !== 0) {
                    var M = h;
                    for (M.pendingLanes |= 2, M.entangledLanes |= 2; w; ) {
                      var z = 1 << 31 - jt(w);
                      M.entanglements[1] |= z, w &= ~z;
                    }
                    il(h), (rt & 6) === 0 && (si = Ke() + 500, jo(0));
                  }
                }
                break;
              case 31:
              case 13:
                M = Rr(h, 2), M !== null && yn(M, h, 2), ci(), wd(h, 2);
            }
            if (h = Cd(s), h === null && id(e, t, s, _i, a), h === u) break;
            u = h;
          }
          u !== null && s.stopPropagation();
        } else id(e, t, s, null, a);
      }
    }
    function Cd(e) {
      return e = _c(e), Ed(e);
    }
    var _i = null;
    function Ed(e) {
      if (_i = null, e = Tt(e), e !== null) {
        var t = c(e);
        if (t === null) e = null;
        else {
          var a = t.tag;
          if (a === 13) {
            if (e = d(t), e !== null) return e;
            e = null;
          } else if (a === 31) {
            if (e = f(t), e !== null) return e;
            e = null;
          } else if (a === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null;
          } else t !== e && (e = null);
        }
      }
      return _i = e, null;
    }
    function ey(e) {
      switch (e) {
        case "beforetoggle":
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "toggle":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 2;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 8;
        case "message":
          switch (an()) {
            case un:
              return 2;
            case Wn:
              return 8;
            case Dl:
            case zl:
              return 32;
            case lt:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var _d = false, sr = null, ir = null, cr = null, Io = /* @__PURE__ */ new Map(), Do = /* @__PURE__ */ new Map(), ur = [], Kw = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
    function ty(e, t) {
      switch (e) {
        case "focusin":
        case "focusout":
          sr = null;
          break;
        case "dragenter":
        case "dragleave":
          ir = null;
          break;
        case "mouseover":
        case "mouseout":
          cr = null;
          break;
        case "pointerover":
        case "pointerout":
          Io.delete(t.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          Do.delete(t.pointerId);
      }
    }
    function zo(e, t, a, s, u, h) {
      return e === null || e.nativeEvent !== h ? (e = {
        blockedOn: t,
        domEventName: a,
        eventSystemFlags: s,
        nativeEvent: h,
        targetContainers: [
          u
        ]
      }, t !== null && (t = Je(t), t !== null && Wp(t)), e) : (e.eventSystemFlags |= s, t = e.targetContainers, u !== null && t.indexOf(u) === -1 && t.push(u), e);
    }
    function Zw(e, t, a, s, u) {
      switch (t) {
        case "focusin":
          return sr = zo(sr, e, t, a, s, u), true;
        case "dragenter":
          return ir = zo(ir, e, t, a, s, u), true;
        case "mouseover":
          return cr = zo(cr, e, t, a, s, u), true;
        case "pointerover":
          var h = u.pointerId;
          return Io.set(h, zo(Io.get(h) || null, e, t, a, s, u)), true;
        case "gotpointercapture":
          return h = u.pointerId, Do.set(h, zo(Do.get(h) || null, e, t, a, s, u)), true;
      }
      return false;
    }
    function ny(e) {
      var t = Tt(e.target);
      if (t !== null) {
        var a = c(t);
        if (a !== null) {
          if (t = a.tag, t === 13) {
            if (t = d(a), t !== null) {
              e.blockedOn = t, _r(e.priority, function() {
                Jp(a);
              });
              return;
            }
          } else if (t === 31) {
            if (t = f(a), t !== null) {
              e.blockedOn = t, _r(e.priority, function() {
                Jp(a);
              });
              return;
            }
          } else if (t === 3 && a.stateNode.current.memoizedState.isDehydrated) {
            e.blockedOn = a.tag === 3 ? a.stateNode.containerInfo : null;
            return;
          }
        }
      }
      e.blockedOn = null;
    }
    function ki(e) {
      if (e.blockedOn !== null) return false;
      for (var t = e.targetContainers; 0 < t.length; ) {
        var a = Cd(e.nativeEvent);
        if (a === null) {
          a = e.nativeEvent;
          var s = new a.constructor(a.type, a);
          Ec = s, a.target.dispatchEvent(s), Ec = null;
        } else return t = Je(a), t !== null && Wp(t), e.blockedOn = a, false;
        t.shift();
      }
      return true;
    }
    function ly(e, t, a) {
      ki(e) && a.delete(t);
    }
    function Fw() {
      _d = false, sr !== null && ki(sr) && (sr = null), ir !== null && ki(ir) && (ir = null), cr !== null && ki(cr) && (cr = null), Io.forEach(ly), Do.forEach(ly);
    }
    function Mi(e, t) {
      e.blockedOn === t && (e.blockedOn = null, _d || (_d = true, l.unstable_scheduleCallback(l.unstable_NormalPriority, Fw)));
    }
    var ji = null;
    function ry(e) {
      ji !== e && (ji = e, l.unstable_scheduleCallback(l.unstable_NormalPriority, function() {
        ji === e && (ji = null);
        for (var t = 0; t < e.length; t += 3) {
          var a = e[t], s = e[t + 1], u = e[t + 2];
          if (typeof s != "function") {
            if (Ed(s || a) === null) continue;
            break;
          }
          var h = Je(a);
          h !== null && (e.splice(t, 3), t -= 3, Cu(h, {
            pending: true,
            data: u,
            method: a.method,
            action: s
          }, s, u));
        }
      }));
    }
    function Ia(e) {
      function t(z) {
        return Mi(z, e);
      }
      sr !== null && Mi(sr, e), ir !== null && Mi(ir, e), cr !== null && Mi(cr, e), Io.forEach(t), Do.forEach(t);
      for (var a = 0; a < ur.length; a++) {
        var s = ur[a];
        s.blockedOn === e && (s.blockedOn = null);
      }
      for (; 0 < ur.length && (a = ur[0], a.blockedOn === null); ) ny(a), a.blockedOn === null && ur.shift();
      if (a = (e.ownerDocument || e).$$reactFormReplay, a != null) for (s = 0; s < a.length; s += 3) {
        var u = a[s], h = a[s + 1], w = u[le] || null;
        if (typeof h == "function") w || ry(a);
        else if (w) {
          var M = null;
          if (h && h.hasAttribute("formAction")) {
            if (u = h, w = h[le] || null) M = w.formAction;
            else if (Ed(u) !== null) continue;
          } else M = w.action;
          typeof M == "function" ? a[s + 1] = M : (a.splice(s, 3), s -= 3), ry(a);
        }
      }
    }
    function ay() {
      function e(h) {
        h.canIntercept && h.info === "react-transition" && h.intercept({
          handler: function() {
            return new Promise(function(w) {
              return u = w;
            });
          },
          focusReset: "manual",
          scroll: "manual"
        });
      }
      function t() {
        u !== null && (u(), u = null), s || setTimeout(a, 20);
      }
      function a() {
        if (!s && !navigation.transition) {
          var h = navigation.currentEntry;
          h && h.url != null && navigation.navigate(h.url, {
            state: h.getState(),
            info: "react-transition",
            history: "replace"
          });
        }
      }
      if (typeof navigation == "object") {
        var s = false, u = null;
        return navigation.addEventListener("navigate", e), navigation.addEventListener("navigatesuccess", t), navigation.addEventListener("navigateerror", t), setTimeout(a, 100), function() {
          s = true, navigation.removeEventListener("navigate", e), navigation.removeEventListener("navigatesuccess", t), navigation.removeEventListener("navigateerror", t), u !== null && (u(), u = null);
        };
      }
    }
    function kd(e) {
      this._internalRoot = e;
    }
    Li.prototype.render = kd.prototype.render = function(e) {
      var t = this._internalRoot;
      if (t === null) throw Error(o(409));
      var a = t.current, s = kn();
      Fp(a, s, e, t, null, null);
    }, Li.prototype.unmount = kd.prototype.unmount = function() {
      var e = this._internalRoot;
      if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Fp(e.current, 2, null, e, null, null), ci(), t[De] = null;
      }
    };
    function Li(e) {
      this._internalRoot = e;
    }
    Li.prototype.unstable_scheduleHydration = function(e) {
      if (e) {
        var t = tl();
        e = {
          blockedOn: null,
          target: e,
          priority: t
        };
        for (var a = 0; a < ur.length && t !== 0 && t < ur[a].priority; a++) ;
        ur.splice(a, 0, e), a === 0 && ny(e);
      }
    };
    var oy = n.version;
    if (oy !== "19.2.4") throw Error(o(527, oy, "19.2.4"));
    F.findDOMNode = function(e) {
      var t = e._reactInternals;
      if (t === void 0) throw typeof e.render == "function" ? Error(o(188)) : (e = Object.keys(e).join(","), Error(o(268, e)));
      return e = p(t), e = e !== null ? v(e) : null, e = e === null ? null : e.stateNode, e;
    };
    var Qw = {
      bundleType: 0,
      version: "19.2.4",
      rendererPackageName: "react-dom",
      currentDispatcherRef: $,
      reconcilerVersion: "19.2.4"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
      var Ri = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!Ri.isDisabled && Ri.supportsFiber) try {
        en = Ri.inject(Qw), xt = Ri;
      } catch {
      }
    }
    return Uo.createRoot = function(e, t) {
      if (!i(e)) throw Error(o(299));
      var a = false, s = "", u = hg, h = mg, w = gg;
      return t != null && (t.unstable_strictMode === true && (a = true), t.identifierPrefix !== void 0 && (s = t.identifierPrefix), t.onUncaughtError !== void 0 && (u = t.onUncaughtError), t.onCaughtError !== void 0 && (h = t.onCaughtError), t.onRecoverableError !== void 0 && (w = t.onRecoverableError)), t = Kp(e, 1, false, null, null, a, s, null, u, h, w, ay), e[De] = t.current, sd(e), new kd(t);
    }, Uo.hydrateRoot = function(e, t, a) {
      if (!i(e)) throw Error(o(299));
      var s = false, u = "", h = hg, w = mg, M = gg, z = null;
      return a != null && (a.unstable_strictMode === true && (s = true), a.identifierPrefix !== void 0 && (u = a.identifierPrefix), a.onUncaughtError !== void 0 && (h = a.onUncaughtError), a.onCaughtError !== void 0 && (w = a.onCaughtError), a.onRecoverableError !== void 0 && (M = a.onRecoverableError), a.formState !== void 0 && (z = a.formState)), t = Kp(e, 1, true, t, a ?? null, s, u, z, h, w, M, ay), t.context = Zp(null), a = t.current, s = kn(), s = el(s), u = Zl(s), u.callback = null, Fl(a, u, s), a = s, t.current.lanes = a, Er(t, a), il(t), e[De] = t.current, sd(e), new Li(t);
    }, Uo.version = "19.2.4", Uo;
  }
  var py;
  function sS() {
    if (py) return Ld.exports;
    py = 1;
    function l() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(l);
      } catch (n) {
        console.error(n);
      }
    }
    return l(), Ld.exports = oS(), Ld.exports;
  }
  var iS = sS();
  const cS = "modulepreload", uS = function(l) {
    return "/" + l;
  }, yy = {}, yt = function(n, r, o) {
    let i = Promise.resolve();
    if (r && r.length > 0) {
      let d = function(p) {
        return Promise.all(p.map((v) => Promise.resolve(v).then((b) => ({
          status: "fulfilled",
          value: b
        }), (b) => ({
          status: "rejected",
          reason: b
        }))));
      };
      document.getElementsByTagName("link");
      const f = document.querySelector("meta[property=csp-nonce]"), g = (f == null ? void 0 : f.nonce) || (f == null ? void 0 : f.getAttribute("nonce"));
      i = d(r.map((p) => {
        if (p = uS(p), p in yy) return;
        yy[p] = true;
        const v = p.endsWith(".css"), b = v ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${p}"]${b}`)) return;
        const S = document.createElement("link");
        if (S.rel = v ? "stylesheet" : cS, v || (S.as = "script"), S.crossOrigin = "", S.href = p, g && S.setAttribute("nonce", g), document.head.appendChild(S), v) return new Promise((C, k) => {
          S.addEventListener("load", C), S.addEventListener("error", () => k(new Error(`Unable to preload CSS for ${p}`)));
        });
      }));
    }
    function c(d) {
      const f = new Event("vite:preloadError", {
        cancelable: true
      });
      if (f.payload = d, window.dispatchEvent(f), !f.defaultPrevented) throw d;
    }
    return i.then((d) => {
      for (const f of d || []) f.status === "rejected" && c(f.reason);
      return n().catch(c);
    });
  }, by = (l) => {
    let n;
    const r = /* @__PURE__ */ new Set(), o = (p, v) => {
      const b = typeof p == "function" ? p(n) : p;
      if (!Object.is(b, n)) {
        const S = n;
        n = v ?? (typeof b != "object" || b === null) ? b : Object.assign({}, n, b), r.forEach((C) => C(n, S));
      }
    }, i = () => n, f = {
      setState: o,
      getState: i,
      getInitialState: () => g,
      subscribe: (p) => (r.add(p), () => r.delete(p))
    }, g = n = l(o, i, f);
    return f;
  }, dS = ((l) => l ? by(l) : by), fS = (l) => l;
  function hS(l, n = fS) {
    const r = Xa.useSyncExternalStore(l.subscribe, Xa.useCallback(() => n(l.getState()), [
      l,
      n
    ]), Xa.useCallback(() => n(l.getInitialState()), [
      l,
      n
    ]));
    return Xa.useDebugValue(r), r;
  }
  const vy = (l) => {
    const n = dS(l), r = (o) => hS(n, o);
    return Object.assign(r, n), r;
  }, _t = ((l) => l ? vy(l) : vy);
  function mS(l, n) {
    let r;
    try {
      r = l();
    } catch {
      return;
    }
    return {
      getItem: (i) => {
        var c;
        const d = (g) => g === null ? null : JSON.parse(g, void 0), f = (c = r.getItem(i)) != null ? c : null;
        return f instanceof Promise ? f.then(d) : d(f);
      },
      setItem: (i, c) => r.setItem(i, JSON.stringify(c, void 0)),
      removeItem: (i) => r.removeItem(i)
    };
  }
  const Of = (l) => (n) => {
    try {
      const r = l(n);
      return r instanceof Promise ? r : {
        then(o) {
          return Of(o)(r);
        },
        catch(o) {
          return this;
        }
      };
    } catch (r) {
      return {
        then(o) {
          return this;
        },
        catch(o) {
          return Of(o)(r);
        }
      };
    }
  }, gS = (l, n) => (r, o, i) => {
    let c = {
      storage: mS(() => window.localStorage),
      partialize: (E) => E,
      version: 0,
      merge: (E, _) => ({
        ..._,
        ...E
      }),
      ...n
    }, d = false, f = 0;
    const g = /* @__PURE__ */ new Set(), p = /* @__PURE__ */ new Set();
    let v = c.storage;
    if (!v) return l((...E) => {
      console.warn(`[zustand persist middleware] Unable to update item '${c.name}', the given storage is currently unavailable.`), r(...E);
    }, o, i);
    const b = () => {
      const E = c.partialize({
        ...o()
      });
      return v.setItem(c.name, {
        state: E,
        version: c.version
      });
    }, S = i.setState;
    i.setState = (E, _) => (S(E, _), b());
    const C = l((...E) => (r(...E), b()), o, i);
    i.getInitialState = () => C;
    let k;
    const x = () => {
      var E, _;
      if (!v) return;
      const N = ++f;
      d = false, g.forEach((R) => {
        var I;
        return R((I = o()) != null ? I : C);
      });
      const A = ((_ = c.onRehydrateStorage) == null ? void 0 : _.call(c, (E = o()) != null ? E : C)) || void 0;
      return Of(v.getItem.bind(v))(c.name).then((R) => {
        if (R) if (typeof R.version == "number" && R.version !== c.version) {
          if (c.migrate) {
            const I = c.migrate(R.state, R.version);
            return I instanceof Promise ? I.then((T) => [
              true,
              T
            ]) : [
              true,
              I
            ];
          }
          console.error("State loaded from storage couldn't be migrated since no migrate function was provided");
        } else return [
          false,
          R.state
        ];
        return [
          false,
          void 0
        ];
      }).then((R) => {
        var I;
        if (N !== f) return;
        const [T, L] = R;
        if (k = c.merge(L, (I = o()) != null ? I : C), r(k, true), T) return b();
      }).then(() => {
        N === f && (A == null ? void 0 : A(o(), void 0), k = o(), d = true, p.forEach((R) => R(k)));
      }).catch((R) => {
        N === f && (A == null ? void 0 : A(void 0, R));
      });
    };
    return i.persist = {
      setOptions: (E) => {
        c = {
          ...c,
          ...E
        }, E.storage && (v = E.storage);
      },
      clearStorage: () => {
        v == null ? void 0 : v.removeItem(c.name);
      },
      getOptions: () => c,
      rehydrate: () => x(),
      hasHydrated: () => d,
      onHydrate: (E) => (g.add(E), () => {
        g.delete(E);
      }),
      onFinishHydration: (E) => (p.add(E), () => {
        p.delete(E);
      })
    }, c.skipHydration || x(), k || C;
  }, lh = gS, Bn = {
    dark: "#44ff44",
    light: "#44ff44"
  }, tc = {
    dark: "#ffffff",
    light: "#000000"
  };
  function If() {
    return typeof window > "u" || window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function xy(l) {
    return l === "system" ? If() : l;
  }
  const Zo = 288, qi = 200, Gi = 480, me = _t()(lh((l, n) => ({
    themeSetting: "system",
    theme: If(),
    wasmReady: false,
    cursorWorld: null,
    sidebarTab: "layers",
    inspectorFocusRequested: false,
    inspectorFocusField: null,
    showGrid: true,
    zenMode: false,
    explorerCollapsed: false,
    sidebarCollapsed: false,
    explorerWidth: Zo,
    sidebarWidth: Zo,
    setThemeSetting: (r) => l({
      themeSetting: r,
      theme: xy(r)
    }),
    toggleTheme: () => l((r) => {
      const o = r.theme === "dark" ? "light" : "dark";
      return {
        themeSetting: o,
        theme: o
      };
    }),
    syncSystemTheme: () => l((r) => r.themeSetting === "system" ? {
      theme: If()
    } : {}),
    setWasmReady: (r) => l({
      wasmReady: r
    }),
    setCursorWorld: (r) => l({
      cursorWorld: r
    }),
    getSelectionColor: () => Bn[n().theme],
    setSidebarTab: (r) => l({
      sidebarTab: r
    }),
    requestInspectorFocus: () => l({
      sidebarTab: "inspector",
      inspectorFocusRequested: true,
      inspectorFocusField: null
    }),
    requestInspectorFocusField: (r) => l({
      sidebarTab: "inspector",
      inspectorFocusRequested: true,
      inspectorFocusField: r
    }),
    clearInspectorFocus: () => l({
      inspectorFocusRequested: false,
      inspectorFocusField: null
    }),
    toggleGrid: () => l((r) => ({
      showGrid: !r.showGrid
    })),
    toggleZenMode: () => l((r) => ({
      zenMode: !r.zenMode
    })),
    toggleExplorerCollapsed: () => l((r) => ({
      explorerCollapsed: !r.explorerCollapsed
    })),
    toggleSidebarCollapsed: () => l((r) => ({
      sidebarCollapsed: !r.sidebarCollapsed
    })),
    setExplorerCollapsed: (r) => l({
      explorerCollapsed: r
    }),
    setSidebarCollapsed: (r) => l({
      sidebarCollapsed: r
    }),
    setExplorerWidth: (r) => l({
      explorerWidth: Math.round(Math.max(qi, Math.min(Gi, r)))
    }),
    setSidebarWidth: (r) => l({
      sidebarWidth: Math.round(Math.max(qi, Math.min(Gi, r)))
    })
  }), {
    name: "rosette-ui",
    partialize: (l) => ({
      themeSetting: l.themeSetting,
      showGrid: l.showGrid,
      zenMode: l.zenMode,
      explorerCollapsed: l.explorerCollapsed,
      sidebarCollapsed: l.sidebarCollapsed,
      explorerWidth: l.explorerWidth,
      sidebarWidth: l.sidebarWidth
    }),
    onRehydrateStorage: () => (l) => {
      if (l) {
        l.theme = xy(l.themeSetting);
        const n = (r) => Math.round(Math.max(qi, Math.min(Gi, r)));
        l.explorerWidth = n(l.explorerWidth), l.sidebarWidth = n(l.sidebarWidth);
      }
    }
  }));
  typeof window < "u" && window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
    me.getState().syncSystemTheme();
  });
  let Fo = null, Yo = null;
  async function pS() {
    if (Fo) return Fo;
    if (Yo) return Yo;
    Yo = (async () => {
      const l = await yt(() => import("./rosette_wasm-CeO5KTZx.js"), []);
      return await l.default(), Fo = l, l;
    })();
    try {
      return await Yo;
    } catch (l) {
      throw Yo = null, l;
    }
  }
  function Wv() {
    const [l, n] = m.useState(Fo), [r, o] = m.useState(!Fo), [i, c] = m.useState(null), d = me((f) => f.setWasmReady);
    return m.useEffect(() => {
      let f = true;
      return pS().then((g) => {
        f && (n(g), o(false), d(true));
      }).catch((g) => {
        console.error("Failed to load WASM module:", g), f && (c(g), o(false));
      }), () => {
        f = false;
      };
    }, [
      d
    ]), {
      wasm: l,
      isLoading: r,
      error: i,
      isReady: !!l && !r && !i
    };
  }
  const sc = 1.18, ic = 0.82, yS = 1.5, bS = 0.67, vS = 8, xS = 24, Jv = 100, wS = 200, wy = 1e6, Sy = 1e3, SS = [
    1,
    2,
    5,
    10,
    20,
    50,
    100,
    200,
    500,
    1e3
  ], Cy = 0.1, e0 = 100, t0 = "'Source Code Pro', monospace", CS = 530, rh = 0.72, xe = 50, Pi = Math.pow(2, -6), Nd = 1e-18, Od = 3, Ve = _t((l, n) => ({
    zoom: Pi,
    offset: {
      x: 0,
      y: 0
    },
    initialized: false,
    setZoom: (r) => l({
      zoom: Math.max(Nd, Math.min(Od, r))
    }),
    zoomAt: (r, o, i) => {
      const c = n(), d = Math.max(Nd, Math.min(Od, c.zoom * r)), f = (o - c.offset.x) / c.zoom, g = (i - c.offset.y) / c.zoom, p = o - f * d, v = i - g * d;
      l({
        zoom: d,
        offset: {
          x: p,
          y: v
        }
      });
    },
    pan: (r, o) => l((i) => ({
      offset: {
        x: i.offset.x + r,
        y: i.offset.y + o
      }
    })),
    setOffset: (r, o) => l({
      offset: {
        x: r,
        y: o
      }
    }),
    reset: (r, o) => l({
      zoom: Pi,
      offset: {
        x: r / 2,
        y: o / 2
      },
      initialized: true
    }),
    initOffset: (r, o) => {
      n().initialized || l({
        offset: {
          x: r / 2,
          y: o / 2
        },
        initialized: true
      });
    },
    zoomToBounds: (r, o, i, c) => {
      const d = Math.abs(r.maxX - r.minX), f = Math.abs(r.maxY - r.minY), g = 1e3, p = Math.max(d, g), v = Math.max(f, g), b = p * Cy, S = v * Cy, C = p + b * 2, k = v + S * 2, x = (r.minX + r.maxX) / 2, E = (r.minY + r.maxY) / 2, _ = o / C, N = i / k, A = Math.max(Nd, Math.min(_, N, Od)), R = c ? c.x : o / 2, I = c ? c.y : i / 2, T = {
        x: R - x * A,
        y: I - E * A
      };
      l({
        zoom: A,
        offset: T
      });
    },
    zoomToFit: (r, o, i, c) => {
      if (r) n().zoomToBounds(r, o, i, c);
      else {
        const d = c ? c.x : o / 2, f = c ? c.y : i / 2;
        l({
          zoom: Pi,
          offset: {
            x: d,
            y: f
          },
          initialized: true
        });
      }
    },
    zoomToSelected: (r, o, i, c) => {
      r && n().zoomToBounds(r, o, i, c);
    },
    centerOnBounds: (r, o, i, c) => {
      const d = n(), f = (r.minX + r.maxX) / 2, g = (r.minY + r.maxY) / 2, p = c ? c.x : o / 2, v = c ? c.y : i / 2, b = {
        x: p - f * d.zoom,
        y: v - g * d.zoom
      };
      l({
        offset: b
      });
    }
  }));
  if (typeof window < "u" && window.parent !== window) {
    const l = (n) => {
      window.parent.postMessage({
        type: "rosette-viewport",
        zoom: n.zoom,
        offsetX: n.offset.x,
        offsetY: n.offset.y
      }, "*");
    };
    Ve.subscribe(l), l(Ve.getState());
  }
  function Ai(l) {
    const n = l.replace("#", ""), r = Number.parseInt(n.slice(0, 2), 16) / 255, o = Number.parseInt(n.slice(2, 4), 16) / 255, i = Number.parseInt(n.slice(4, 6), 16) / 255;
    return [
      r,
      o,
      i,
      1
    ];
  }
  function ES(l) {
    const { wasm: n, isReady: r } = Wv(), [o, i] = m.useState(null), [c, d] = m.useState(false), [f, g] = m.useState(null), p = m.useRef(null), v = me((_) => _.theme), b = me((_) => _.showGrid), { zoom: S, offset: C } = Ve();
    m.useEffect(() => {
      if (!r || !n || !l) return;
      let _ = true;
      async function N() {
        try {
          const A = await n.WasmRenderer.create(l);
          if (!_) {
            A.destroy();
            return;
          }
          A.set_theme(v === "dark");
          const R = Bn[v], [I, T, L, D] = Ai(R);
          A.set_selection_color(I, T, L, D);
          const H = tc[v], [q, re, ee, de] = Ai(H);
          A.set_hover_color(q, re, ee, de), A.set_dpr(window.devicePixelRatio || 1), p.current = A, i(A), d(true);
        } catch (A) {
          console.error("Failed to create renderer:", A), _ && g(A);
        }
      }
      return N(), () => {
        _ = false, p.current && (p.current.destroy(), p.current = null);
      };
    }, [
      r,
      n,
      l
    ]), m.useEffect(() => {
      if (o && c) {
        o.set_theme(v === "dark");
        const _ = Bn[v], [N, A, R, I] = Ai(_);
        o.set_selection_color(N, A, R, I);
        const T = tc[v], [L, D, H, q] = Ai(T);
        o.set_hover_color(L, D, H, q);
      }
    }, [
      o,
      c,
      v
    ]), m.useEffect(() => {
      o && c && o.set_grid_visible(b);
    }, [
      o,
      c,
      b
    ]), m.useEffect(() => {
      if (o && c) {
        const _ = window.devicePixelRatio || 1;
        o.set_viewport(C.x * _, C.y * _, S * _);
      }
    }, [
      o,
      c,
      S,
      C.x,
      C.y
    ]);
    const k = m.useCallback(() => {
      o && c && o.render();
    }, [
      o,
      c
    ]), x = m.useCallback((_, N) => {
      o && c && (o.set_dpr(window.devicePixelRatio || 1), o.resize(_, N));
    }, [
      o,
      c
    ]), E = m.useCallback((_, N) => {
      if (o && c) {
        const A = window.devicePixelRatio || 1, R = o.screen_to_world(_ * A, N * A);
        return {
          x: R[0],
          y: R[1]
        };
      }
      return null;
    }, [
      o,
      c
    ]);
    return {
      renderer: o,
      isReady: c,
      error: f,
      render: k,
      resize: x,
      screenToWorld: E
    };
  }
  const Gt = _t((l) => ({
    activeTool: "select",
    toolSetAt: 0,
    setTool: (n) => l({
      activeTool: n,
      toolSetAt: Date.now()
    })
  })), se = _t((l) => ({
    selectedIds: /* @__PURE__ */ new Set(),
    hoveredId: null,
    lastSelectedId: null,
    select: (n) => l({
      selectedIds: /* @__PURE__ */ new Set([
        n
      ]),
      lastSelectedId: n
    }),
    addToSelection: (n) => l((r) => ({
      selectedIds: /* @__PURE__ */ new Set([
        ...r.selectedIds,
        n
      ]),
      lastSelectedId: n
    })),
    toggleSelection: (n) => l((r) => {
      const o = new Set(r.selectedIds);
      if (o.has(n)) {
        o.delete(n);
        const i = r.lastSelectedId === n ? o.size > 0 ? [
          ...o
        ][o.size - 1] : null : r.lastSelectedId;
        return {
          selectedIds: o,
          lastSelectedId: i
        };
      } else return o.add(n), {
        selectedIds: o,
        lastSelectedId: n
      };
    }),
    deselect: (n) => l((r) => {
      const o = new Set(r.selectedIds);
      o.delete(n);
      const i = r.lastSelectedId === n ? o.size > 0 ? [
        ...o
      ][o.size - 1] : null : r.lastSelectedId;
      return {
        selectedIds: o,
        lastSelectedId: i
      };
    }),
    removeFromSelection: (n) => se.getState().deselect(n),
    clearSelection: () => l({
      selectedIds: /* @__PURE__ */ new Set(),
      lastSelectedId: null
    }),
    selectAll: (n) => l({
      selectedIds: new Set(n),
      lastSelectedId: n.length > 0 ? n[n.length - 1] : null
    }),
    setSelection: (n) => l({
      selectedIds: n,
      lastSelectedId: n.size > 0 ? [
        ...n
      ][n.size - 1] : null
    }),
    setHover: (n) => l({
      hoveredId: n
    }),
    selectNext: (n) => l((r) => {
      if (n.length === 0) return r;
      if (r.selectedIds.size === 0) return {
        selectedIds: /* @__PURE__ */ new Set([
          n[0]
        ]),
        lastSelectedId: n[0]
      };
      const o = r.lastSelectedId ?? [
        ...r.selectedIds
      ][0], i = n.indexOf(o);
      if (i === -1) return {
        selectedIds: /* @__PURE__ */ new Set([
          n[0]
        ]),
        lastSelectedId: n[0]
      };
      const c = (i + 1) % n.length, d = n[c];
      return {
        selectedIds: /* @__PURE__ */ new Set([
          d
        ]),
        lastSelectedId: d
      };
    }),
    selectPrevious: (n) => l((r) => {
      if (n.length === 0) return r;
      if (r.selectedIds.size === 0) {
        const f = n[n.length - 1];
        return {
          selectedIds: /* @__PURE__ */ new Set([
            f
          ]),
          lastSelectedId: f
        };
      }
      const o = r.lastSelectedId ?? [
        ...r.selectedIds
      ][0], i = n.indexOf(o);
      if (i === -1) {
        const f = n[n.length - 1];
        return {
          selectedIds: /* @__PURE__ */ new Set([
            f
          ]),
          lastSelectedId: f
        };
      }
      const c = (i - 1 + n.length) % n.length, d = n[c];
      return {
        selectedIds: /* @__PURE__ */ new Set([
          d
        ]),
        lastSelectedId: d
      };
    })
  })), os = _t((l) => ({
    isOpen: false,
    position: {
      x: 0,
      y: 0
    },
    variant: "canvas",
    targetId: null,
    open: (n, r, o = null) => l({
      isOpen: true,
      position: r,
      variant: n,
      targetId: o
    }),
    close: () => l({
      isOpen: false
    })
  }));
  function Id() {
    return `ruler-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }
  const Oe = _t((l, n) => ({
    rulers: /* @__PURE__ */ new Map(),
    activeRulerId: null,
    previewEnd: null,
    selectedRulerIds: /* @__PURE__ */ new Set(),
    hoveredRulerId: null,
    marqueePreviewIds: /* @__PURE__ */ new Set(),
    hoveredEndpoint: null,
    draggingEndpoint: null,
    draggingEndpointOriginal: null,
    isMovingRuler: false,
    moveStartPoint: null,
    moveOriginalPoint: null,
    snapPoint: null,
    startRuler: (r) => {
      const o = Id(), i = {
        id: o,
        start: r,
        end: r
      };
      return l((c) => {
        const d = new Map(c.rulers);
        return d.set(o, i), {
          rulers: d,
          activeRulerId: o,
          previewEnd: r
        };
      }), o;
    },
    updatePreview: (r) => {
      const o = n();
      o.activeRulerId && l((i) => {
        const c = new Map(i.rulers), d = c.get(o.activeRulerId);
        return d && c.set(o.activeRulerId, {
          ...d,
          end: r
        }), {
          rulers: c,
          previewEnd: r
        };
      });
    },
    finalizeRuler: (r) => {
      const o = n();
      if (!o.activeRulerId) return null;
      const i = o.rulers.get(o.activeRulerId);
      if (!i) return null;
      const c = {
        ...i,
        end: r
      };
      return l((d) => {
        const f = new Map(d.rulers);
        return f.set(o.activeRulerId, c), {
          rulers: f,
          activeRulerId: null,
          previewEnd: null
        };
      }), c;
    },
    cancelCreation: () => {
      const r = n();
      r.activeRulerId && l((o) => {
        const i = new Map(o.rulers);
        return i.delete(r.activeRulerId), {
          rulers: i,
          activeRulerId: null,
          previewEnd: null
        };
      });
    },
    updateEndpoint: (r, o, i) => {
      l((c) => {
        const d = new Map(c.rulers), f = d.get(r);
        return f && d.set(r, {
          ...f,
          [o]: i
        }), {
          rulers: d
        };
      });
    },
    removeRuler: (r) => {
      l((o) => {
        var _a, _b2;
        const i = new Map(o.rulers);
        i.delete(r);
        const c = new Set(o.selectedRulerIds);
        return c.delete(r), {
          rulers: i,
          selectedRulerIds: c,
          hoveredRulerId: o.hoveredRulerId === r ? null : o.hoveredRulerId,
          hoveredEndpoint: ((_a = o.hoveredEndpoint) == null ? void 0 : _a.rulerId) === r ? null : o.hoveredEndpoint,
          draggingEndpoint: ((_b2 = o.draggingEndpoint) == null ? void 0 : _b2.rulerId) === r ? null : o.draggingEndpoint
        };
      });
    },
    removeRulers: (r) => {
      l((o) => {
        const i = new Map(o.rulers), c = new Set(o.selectedRulerIds);
        for (const d of r) i.delete(d), c.delete(d);
        return {
          rulers: i,
          selectedRulerIds: c,
          hoveredRulerId: r.includes(o.hoveredRulerId ?? "") ? null : o.hoveredRulerId,
          hoveredEndpoint: o.hoveredEndpoint && r.includes(o.hoveredEndpoint.rulerId) ? null : o.hoveredEndpoint,
          draggingEndpoint: o.draggingEndpoint && r.includes(o.draggingEndpoint.rulerId) ? null : o.draggingEndpoint
        };
      });
    },
    clearAllRulers: () => l({
      rulers: /* @__PURE__ */ new Map(),
      activeRulerId: null,
      previewEnd: null,
      selectedRulerIds: /* @__PURE__ */ new Set(),
      hoveredRulerId: null,
      marqueePreviewIds: /* @__PURE__ */ new Set(),
      hoveredEndpoint: null,
      draggingEndpoint: null,
      draggingEndpointOriginal: null,
      isMovingRuler: false,
      moveStartPoint: null,
      moveOriginalPoint: null,
      snapPoint: null
    }),
    setHoveredEndpoint: (r) => l({
      hoveredEndpoint: r
    }),
    setDraggingEndpoint: (r) => {
      if (r) {
        const o = n().rulers.get(r.rulerId), i = o ? {
          ...o[r.endpoint]
        } : null;
        l({
          draggingEndpoint: r,
          draggingEndpointOriginal: i
        });
      } else l({
        draggingEndpoint: null
      });
    },
    endDraggingEndpoint: () => {
      const r = n(), { draggingEndpoint: o, draggingEndpointOriginal: i, rulers: c } = r;
      if (!o || !i) return l({
        draggingEndpoint: null,
        draggingEndpointOriginal: null
      }), null;
      const d = c.get(o.rulerId);
      if (!d) return l({
        draggingEndpoint: null,
        draggingEndpointOriginal: null
      }), null;
      const f = d[o.endpoint], g = f.x !== i.x || f.y !== i.y;
      return l({
        draggingEndpoint: null,
        draggingEndpointOriginal: null
      }), g ? {
        rulerId: o.rulerId,
        endpoint: o.endpoint,
        oldPosition: i,
        newPosition: {
          ...f
        }
      } : null;
    },
    selectRuler: (r) => l({
      selectedRulerIds: r ? /* @__PURE__ */ new Set([
        r
      ]) : /* @__PURE__ */ new Set()
    }),
    toggleSelection: (r) => l((o) => {
      const i = new Set(o.selectedRulerIds);
      return i.has(r) ? i.delete(r) : i.add(r), {
        selectedRulerIds: i
      };
    }),
    addToSelection: (r) => {
      l((o) => {
        const i = new Set(o.selectedRulerIds);
        for (const c of r) i.add(c);
        return {
          selectedRulerIds: i
        };
      });
    },
    setSelection: (r) => l({
      selectedRulerIds: r
    }),
    clearSelection: () => l({
      selectedRulerIds: /* @__PURE__ */ new Set()
    }),
    setHoveredRuler: (r) => l({
      hoveredRulerId: r
    }),
    setMarqueePreviewIds: (r) => l({
      marqueePreviewIds: new Set(r)
    }),
    startMoveRuler: (r) => {
      n().selectedRulerIds.size !== 0 && l({
        isMovingRuler: true,
        moveStartPoint: r,
        moveOriginalPoint: r
      });
    },
    moveRuler: (r) => {
      const o = n();
      if (!o.isMovingRuler || o.selectedRulerIds.size === 0 || !o.moveStartPoint) return;
      const i = r.x - o.moveStartPoint.x, c = r.y - o.moveStartPoint.y;
      l((d) => {
        const f = new Map(d.rulers);
        for (const g of o.selectedRulerIds) {
          const p = f.get(g);
          p && f.set(g, {
            ...p,
            start: {
              x: p.start.x + i,
              y: p.start.y + c
            },
            end: {
              x: p.end.x + i,
              y: p.end.y + c
            }
          });
        }
        return {
          rulers: f,
          moveStartPoint: r
        };
      });
    },
    endMoveRuler: () => {
      const r = n(), { selectedRulerIds: o, moveStartPoint: i, moveOriginalPoint: c } = r;
      let d = null;
      if (i && c && o.size > 0) {
        const f = i.x - c.x, g = i.y - c.y;
        (f !== 0 || g !== 0) && (d = {
          rulerIds: [
            ...o
          ],
          deltaX: f,
          deltaY: g
        });
      }
      return l({
        isMovingRuler: false,
        moveStartPoint: null,
        moveOriginalPoint: null
      }), d;
    },
    deleteSelectedRulers: () => {
      const r = n();
      r.selectedRulerIds.size > 0 && n().removeRulers(Array.from(r.selectedRulerIds));
    },
    addRuler: (r, o) => {
      const i = Id(), c = {
        id: i,
        start: r,
        end: o
      };
      return l((d) => {
        const f = new Map(d.rulers);
        return f.set(i, c), {
          rulers: f
        };
      }), i;
    },
    restoreRulers: (r) => {
      const o = [];
      return l((i) => {
        const c = new Map(i.rulers);
        for (const d of r) {
          const f = Id();
          c.set(f, {
            ...d,
            id: f
          }), o.push(f);
        }
        return {
          rulers: c
        };
      }), o;
    },
    setSnapPoint: (r) => l({
      snapPoint: r
    })
  })), Se = _t((l) => ({
    library: null,
    renderer: null,
    syncGeneration: 0,
    setLibrary: (n) => l({
      library: n
    }),
    setRenderer: (n) => l({
      renderer: n
    }),
    bumpSyncGeneration: () => l((n) => ({
      syncGeneration: n.syncGeneration + 1
    }))
  }));
  function n0(l) {
    const n = [
      l.name
    ];
    for (const r of l.children) n.push(...n0(r));
    return n;
  }
  function _S(l) {
    const n = /* @__PURE__ */ new Set(), r = [];
    for (const o of l) for (const i of n0(o)) n.has(i) || (n.add(i), r.push(i));
    return r;
  }
  function l0(l) {
    const n = [];
    if (l.children.length > 0) {
      n.push(l.name);
      for (const r of l.children) n.push(...l0(r));
    }
    return n;
  }
  function r0(l) {
    return [
      ...l
    ].sort((n, r) => n.name.localeCompare(r.name)).map((n) => ({
      ...n,
      children: n.children.length > 0 ? r0(n.children) : n.children
    }));
  }
  function kS(l) {
    function n(o) {
      if (o.children.length === 0) return 1;
      let i = 0;
      for (const c of o.children) i = Math.max(i, n(c));
      return 1 + i;
    }
    let r = 0;
    for (const o of l) r = Math.max(r, n(o));
    return r;
  }
  const ue = _t()(lh((l) => ({
    projectName: "untitled-project",
    cells: [],
    cellTree: null,
    expandedCells: /* @__PURE__ */ new Set(),
    activeCell: null,
    editingCellName: null,
    cellsLoaded: false,
    hierarchyLevelLimit: 1 / 0,
    maxTreeDepth: 0,
    hiddenCells: /* @__PURE__ */ new Set(),
    cellListMode: "nested",
    isFocused: false,
    focusedItem: null,
    setProjectName: (n) => l({
      projectName: n
    }),
    setCells: (n) => l((r) => {
      const o = [
        ...n
      ].sort((c, d) => c.localeCompare(d)), i = r.activeCell && o.includes(r.activeCell) ? r.activeCell : o[0] ?? null;
      return {
        cells: o,
        activeCell: i,
        cellsLoaded: true
      };
    }),
    setCellTree: (n) => l((r) => {
      var _a;
      const o = r0(n), i = _S(o), c = kS(o), d = r.expandedCells.size === 0 ? new Set(o.flatMap(l0)) : r.expandedCells, f = r.activeCell && i.includes(r.activeCell) ? r.activeCell : i[0] ?? null, g = ((_a = r.focusedItem) == null ? void 0 : _a.type) === "cell" && !i.includes(r.focusedItem.name) ? null : r.focusedItem;
      return {
        cellTree: o,
        cells: i,
        expandedCells: d,
        activeCell: f,
        focusedItem: g,
        maxTreeDepth: c,
        cellsLoaded: true
      };
    }),
    toggleExpanded: (n) => l((r) => {
      const o = new Set(r.expandedCells);
      return o.has(n) ? o.delete(n) : o.add(n), {
        expandedCells: o
      };
    }),
    setHierarchyLevelLimit: (n) => l({
      hierarchyLevelLimit: n
    }),
    setActiveCell: (n) => l({
      activeCell: n
    }),
    setEditingCellName: (n) => l({
      editingCellName: n
    }),
    renameCell: (n, r) => l((o) => {
      var _a;
      const i = o.cells.map((g) => g === n ? r : g).sort((g, p) => g.localeCompare(p)), c = o.activeCell === n ? r : o.activeCell, d = ((_a = o.focusedItem) == null ? void 0 : _a.type) === "cell" && o.focusedItem.name === n ? {
        type: "cell",
        name: r
      } : o.focusedItem, f = new Set(o.hiddenCells);
      return f.has(n) && (f.delete(n), f.add(r)), {
        cells: i,
        activeCell: c,
        focusedItem: d,
        hiddenCells: f
      };
    }),
    removeCell: (n) => l((r) => {
      var _a;
      const o = r.cells.filter((f) => f !== n), i = r.activeCell === n ? o[0] ?? null : r.activeCell, c = ((_a = r.focusedItem) == null ? void 0 : _a.type) === "cell" && r.focusedItem.name === n ? null : r.focusedItem, d = new Set(r.hiddenCells);
      return d.delete(n), {
        cells: o,
        activeCell: i,
        focusedItem: c,
        hiddenCells: d
      };
    }),
    addCell: (n) => l((r) => r.cells.includes(n) ? r : {
      cells: [
        ...r.cells,
        n
      ].sort((i, c) => i.localeCompare(c))
    }),
    toggleCellVisibility: (n) => l((r) => {
      const o = new Set(r.hiddenCells);
      return o.has(n) ? o.delete(n) : o.add(n), {
        hiddenCells: o
      };
    }),
    showAllCells: () => l({
      hiddenCells: /* @__PURE__ */ new Set()
    }),
    hideAllCells: () => l((n) => ({
      hiddenCells: new Set(n.cells)
    })),
    setCellListMode: (n) => l({
      cellListMode: n
    }),
    setFocused: (n) => l((r) => {
      if (n) {
        const o = r.activeCell ?? r.cells[0] ?? null;
        return {
          isFocused: true,
          focusedItem: o ? {
            type: "cell",
            name: o
          } : null
        };
      }
      return {
        isFocused: false,
        focusedItem: null
      };
    }),
    setFocusedItem: (n) => l({
      focusedItem: n
    })
  }), {
    name: "rosette-explorer",
    partialize: (l) => ({
      projectName: l.projectName,
      cellListMode: l.cellListMode
    })
  }));
  function ah() {
    const l = ue.getState().cells;
    let n = 1, r = `cell${n}`;
    for (; l.includes(r); ) n++, r = `cell${n}`;
    return r;
  }
  ue.subscribe((l, n) => {
    l.projectName !== n.projectName && yt(async () => {
      const { useTabsStore: r } = await Promise.resolve().then(() => v0);
      return {
        useTabsStore: r
      };
    }, void 0).then(({ useTabsStore: r }) => {
      const { activeTabId: o, getActiveTab: i, updateTab: c } = r.getState();
      if (!o) return;
      const d = i();
      d && !d.filePath && c(o, {
        title: l.projectName
      });
    });
  });
  const Ki = _t((l) => ({
    cellName: null,
    bounds: null,
    origin: {
      x: 0,
      y: 0
    },
    startDrag: (n, r, o) => l({
      cellName: n,
      bounds: r,
      origin: o
    }),
    endDrag: () => l({
      cellName: null,
      bounds: null,
      origin: {
        x: 0,
        y: 0
      }
    })
  })), oh = "img:";
  function Mn(l) {
    return l.startsWith(oh);
  }
  function Gr(l) {
    return l.slice(oh.length);
  }
  function ss(l) {
    return oh + l;
  }
  function es(l, n) {
    const { images: r } = Bt.getState();
    let o = null, i = 1 / 0;
    for (const c of r.values()) if (l >= c.x && l <= c.x + c.width && n >= c.y && n <= c.y + c.height) {
      const d = c.width * c.height;
      d < i && (i = d, o = ss(c.id));
    }
    return o;
  }
  function Ey(l, n, r, o) {
    const { images: i } = Bt.getState(), c = [];
    for (const d of i.values()) {
      const f = d.x + d.width, g = d.y + d.height;
      d.x <= r && f >= l && d.y <= o && g >= n && c.push(ss(d.id));
    }
    return c;
  }
  const Bt = _t((l, n) => ({
    images: /* @__PURE__ */ new Map(),
    addImage: (r) => {
      const o = new Map(n().images);
      o.set(r.id, r), l({
        images: o
      });
    },
    removeImage: (r) => {
      const o = new Map(n().images);
      o.delete(r), l({
        images: o
      });
    },
    updateImage: (r, o) => {
      const i = new Map(n().images), c = i.get(r);
      c && (i.set(r, {
        ...c,
        ...o
      }), l({
        images: i
      }));
    },
    clearImages: () => {
      for (const r of n().images.values()) URL.revokeObjectURL(r.url);
      l({
        images: /* @__PURE__ */ new Map()
      });
    }
  }));
  let Vr = null;
  const Xt = _t((l) => ({
    message: null,
    level: "info",
    show: (n, r = "info", o = 3e3) => {
      Vr !== null && clearTimeout(Vr), l({
        message: n,
        level: r
      }), Vr = setTimeout(() => {
        l({
          message: null
        }), Vr = null;
      }, o);
    },
    clear: () => {
      Vr !== null && (clearTimeout(Vr), Vr = null), l({
        message: null
      });
    }
  })), Fn = _t((l) => ({
    isDirty: false,
    markDirty: () => l({
      isDirty: true
    }),
    markClean: () => l({
      isDirty: false
    })
  }));
  let Dd = null;
  function MS(l) {
    const n = (r) => {
      const o = r.useTabsStore.getState().activeTabId;
      o && r.useTabsStore.getState().updateTab(o, {
        isDirty: l
      });
    };
    Dd ? n(Dd) : yt(() => Promise.resolve().then(() => v0), void 0).then((r) => {
      Dd = r, n(r);
    });
  }
  Fn.subscribe((l, n) => {
    l.isDirty !== n.isDirty && MS(l.isDirty);
  });
  const _y = 100, ce = _t((l, n) => ({
    undoStack: [],
    redoStack: [],
    canUndo: false,
    canRedo: false,
    execute: (r, o) => {
      try {
        r.execute(o);
      } catch (i) {
        Xt.getState().show(String(i), "warn");
        return;
      }
      Se.getState().bumpSyncGeneration(), Fn.getState().markDirty(), l((i) => {
        const c = [
          ...i.undoStack,
          r
        ];
        return c.length > _y && c.shift(), {
          undoStack: c,
          redoStack: [],
          canUndo: true,
          canRedo: false
        };
      });
    },
    undo: (r) => {
      const { undoStack: o } = n();
      if (o.length === 0) return;
      const i = o[o.length - 1];
      try {
        i.undo(r);
      } catch (c) {
        Xt.getState().show(String(c), "warn");
        return;
      }
      Se.getState().bumpSyncGeneration(), Fn.getState().markDirty(), l((c) => {
        const d = c.undoStack.slice(0, -1), f = [
          ...c.redoStack,
          i
        ];
        return {
          undoStack: d,
          redoStack: f,
          canUndo: d.length > 0,
          canRedo: true
        };
      });
    },
    redo: (r) => {
      const { redoStack: o } = n();
      if (o.length === 0) return;
      const i = o[o.length - 1];
      try {
        i.execute(r);
      } catch (c) {
        Xt.getState().show(String(c), "warn");
        return;
      }
      Se.getState().bumpSyncGeneration(), Fn.getState().markDirty(), l((c) => {
        const d = c.redoStack.slice(0, -1);
        return {
          undoStack: [
            ...c.undoStack,
            i
          ],
          redoStack: d,
          canUndo: true,
          canRedo: d.length > 0
        };
      });
    },
    clear: () => {
      l({
        undoStack: [],
        redoStack: [],
        canUndo: false,
        canRedo: false
      });
    },
    pushCommand: (r) => {
      Fn.getState().markDirty(), l((o) => {
        const i = [
          ...o.undoStack,
          r
        ];
        return i.length > _y && i.shift(), {
          undoStack: i,
          redoStack: [],
          canUndo: true,
          canRedo: false
        };
      });
    }
  })), Xn = _t((l) => ({
    elements: [],
    hasContent: false,
    copy: (n) => l({
      elements: n,
      hasContent: n.length > 0
    }),
    clear: () => l({
      elements: [],
      hasContent: false
    })
  })), Df = {
    solid: 0,
    hatched: 1,
    crosshatched: 2,
    dotted: 3,
    horizontal: 4,
    vertical: 5,
    zigzag: 6,
    brick: 7
  }, Qo = [
    "#f44336",
    "#ff9800",
    "#ffeb3b",
    "#4caf50",
    "#00bcd4",
    "#2196f3",
    "#9c27b0",
    "#ff69b4",
    "#795548",
    "#607d8b",
    "#3f51b5",
    "#009688",
    "#e6e6e6",
    "#8d6e63",
    "#ff6f00",
    "#1a237e"
  ], zf = 999, nc = [
    {
      id: 1,
      layerNumber: 1,
      datatype: 0,
      name: "silicon",
      color: "#ff69b4",
      visible: true,
      fillPattern: "solid",
      opacity: 0.7
    },
    {
      id: 2,
      layerNumber: 10,
      datatype: 0,
      name: "metal",
      color: "#ffeb3b",
      visible: true,
      fillPattern: "solid",
      opacity: 0.7
    },
    {
      id: 3,
      layerNumber: 100,
      datatype: 0,
      name: "text",
      color: "#607d8b",
      visible: true,
      fillPattern: "dotted",
      opacity: 0.7
    }
  ], ve = _t((l, n) => ({
    layers: new Map(nc.map((r) => [
      r.id,
      r
    ])),
    activeLayerId: 1,
    editingLayerId: null,
    expandedLayerId: null,
    isFocused: false,
    focusedLayerId: null,
    getLayer: (r) => n().layers.get(r),
    getActiveLayer: () => {
      const r = n();
      return r.layers.get(r.activeLayerId);
    },
    setActiveLayer: (r) => l({
      activeLayerId: r
    }),
    setLayer: (r) => l((o) => {
      const i = new Map(o.layers);
      return i.set(r.id, r), {
        layers: i
      };
    }),
    addLayer: (r, o) => {
      const i = n(), c = Array.from(i.layers.values());
      let d = 1;
      const f = new Set(c.map((C) => C.layerNumber));
      for (; f.has(d) && d <= zf; ) d++;
      if (d > zf) return c[0];
      const p = Math.max(0, ...c.map((C) => C.id)) + 1, v = new Set(c.map((C) => C.color)), b = o ?? Qo.find((C) => !v.has(C)) ?? Qo[c.length % Qo.length], S = {
        id: p,
        layerNumber: d,
        datatype: 0,
        name: r ?? `layer${d}`,
        color: b,
        visible: true,
        fillPattern: "solid",
        opacity: 0.7
      };
      return l((C) => {
        const k = new Map(C.layers);
        return k.set(S.id, S), {
          layers: k,
          activeLayerId: S.id
        };
      }), S;
    },
    deleteLayer: (r) => l((o) => {
      if (o.layers.size <= 1) return o;
      const i = new Map(o.layers);
      i.delete(r);
      let c = o.activeLayerId;
      o.activeLayerId === r && (c = i.keys().next().value ?? 1);
      const d = o.focusedLayerId === r ? null : o.focusedLayerId;
      return {
        layers: i,
        activeLayerId: c,
        focusedLayerId: d
      };
    }),
    toggleVisibility: (r) => l((o) => {
      const i = o.layers.get(r);
      if (!i) return o;
      const c = new Map(o.layers);
      return c.set(r, {
        ...i,
        visible: !i.visible
      }), {
        layers: c
      };
    }),
    showAllLayers: () => l((r) => {
      const o = new Map(r.layers);
      for (const [i, c] of o) o.set(i, {
        ...c,
        visible: true
      });
      return {
        layers: o
      };
    }),
    hideAllLayers: () => l((r) => {
      const o = new Map(r.layers);
      for (const [i, c] of o) o.set(i, {
        ...c,
        visible: false
      });
      return {
        layers: o
      };
    }),
    getAllLayers: () => Array.from(n().layers.values()).sort((r, o) => r.layerNumber - o.layerNumber || r.datatype - o.datatype),
    layerExists: (r, o) => {
      const i = n().layers;
      for (const c of i.values()) if (c.layerNumber === r && c.datatype === o) return true;
      return false;
    },
    resetLayers: (r) => l(() => {
      var _a;
      const o = new Map(r.map((c) => [
        c.id,
        c
      ])), i = ((_a = r[0]) == null ? void 0 : _a.id) ?? 1;
      return {
        layers: o,
        activeLayerId: i,
        editingLayerId: null,
        expandedLayerId: null,
        isFocused: false,
        focusedLayerId: null
      };
    }),
    setEditingLayerId: (r) => l({
      editingLayerId: r
    }),
    setExpandedLayerId: (r) => l({
      expandedLayerId: r
    }),
    setFocused: (r) => {
      if (r) {
        const i = n().activeLayerId;
        l({
          isFocused: true,
          focusedLayerId: i
        });
      } else l({
        isFocused: false,
        focusedLayerId: null
      });
    },
    setFocusedLayerId: (r) => l({
      focusedLayerId: r
    })
  }));
  function cc(l, n = 0.7) {
    const r = l.replace("#", ""), o = Number.parseInt(r.slice(0, 2), 16) / 255, i = Number.parseInt(r.slice(2, 4), 16) / 255, c = Number.parseInt(r.slice(4, 6), 16) / 255;
    return [
      o,
      i,
      c,
      n
    ];
  }
  function Hf(l) {
    return {
      minX: l[0],
      minY: l[1],
      maxX: l[2],
      maxY: l[3]
    };
  }
  function Uf(l) {
    return {
      x: (l.minX + l.maxX) / 2,
      y: (l.minY + l.maxY) / 2
    };
  }
  function jS(l, n) {
    const r = /* @__PURE__ */ new Set(), o = [];
    for (const i of n) {
      if (r.has(i)) continue;
      const d = l.get_group_ids(i).filter((f) => n.has(f));
      for (const f of d) r.add(f);
      d.length > 0 && o.push(d);
    }
    return o;
  }
  function LS(l, n, r, o) {
    const i = jS(l, n);
    if (o === "origin-align") return RS(l, i);
    if (i.length < 2 || !r) return [];
    const c = i.findIndex((v) => v.includes(r));
    if (c === -1) return [];
    const d = l.get_bounds_for_ids(i[c]);
    if (!d) return [];
    const f = Hf(d), g = Uf(f), p = [];
    for (let v = 0; v < i.length; v++) {
      if (v === c) continue;
      const b = i[v], S = l.get_bounds_for_ids(b);
      if (!S) continue;
      const C = Hf(S), k = Uf(C);
      let x = 0, E = 0;
      switch (o) {
        case "align-left":
          x = f.minX - C.minX;
          break;
        case "align-center-h":
          x = g.x - k.x;
          break;
        case "align-right":
          x = f.maxX - C.maxX;
          break;
        case "align-top":
          E = f.minY - C.minY;
          break;
        case "align-center-v":
          E = g.y - k.y;
          break;
        case "align-bottom":
          E = f.maxY - C.maxY;
          break;
        case "center-align":
          x = g.x - k.x, E = g.y - k.y;
          break;
      }
      (x !== 0 || E !== 0) && p.push({
        ids: b,
        dx: x,
        dy: E
      });
    }
    return p;
  }
  function RS(l, n) {
    const r = [];
    for (const o of n) {
      const i = l.get_bounds_for_ids(o);
      if (!i) continue;
      const c = Uf(Hf(i)), d = -c.x, f = -c.y;
      (d !== 0 || f !== 0) && r.push({
        ids: o,
        dx: d,
        dy: f
      });
    }
    return r;
  }
  const Yn = "__TAURI__" in window;
  async function is(l, n) {
    const { invoke: r } = await yt(async () => {
      const { invoke: o } = await import("./core-DxBnVPgq.js");
      return {
        invoke: o
      };
    }, []);
    return r(l, n);
  }
  async function a0(l) {
    const n = await is("read_gds_bytes", {
      path: l
    });
    return new Uint8Array(n);
  }
  async function o0(l, n) {
    return is("save_gds", {
      path: l,
      bytes: Array.from(n)
    });
  }
  async function s0(l, n) {
    return is("save_bytes", {
      path: l,
      bytes: Array.from(n)
    });
  }
  async function i0() {
    return is("get_pending_file");
  }
  async function c0() {
    const { open: l } = await yt(async () => {
      const { open: r } = await import("./index-C2Rw4G7o.js");
      return {
        open: r
      };
    }, __vite__mapDeps([0,1])), n = await l({
      title: "Open GDS File",
      filters: [
        {
          name: "GDS Files",
          extensions: [
            "gds",
            "gds2",
            "gdsii"
          ]
        }
      ],
      multiple: false,
      directory: false
    });
    return n === null ? null : n;
  }
  async function u0(l) {
    const { save: n } = await yt(async () => {
      const { save: o } = await import("./index-C2Rw4G7o.js");
      return {
        save: o
      };
    }, __vite__mapDeps([0,1]));
    return await n({
      title: "Save GDS File",
      filters: [
        {
          name: "GDS Files",
          extensions: [
            "gds"
          ]
        }
      ],
      defaultPath: l
    });
  }
  async function d0(l) {
    const { save: n } = await yt(async () => {
      const { save: r } = await import("./index-C2Rw4G7o.js");
      return {
        save: r
      };
    }, __vite__mapDeps([0,1]));
    return n({
      title: "Export Screenshot",
      filters: [
        {
          name: "PNG Image",
          extensions: [
            "png"
          ]
        }
      ],
      defaultPath: l
    });
  }
  async function f0() {
    const { open: l } = await yt(async () => {
      const { open: r } = await import("./index-C2Rw4G7o.js");
      return {
        open: r
      };
    }, __vite__mapDeps([0,1])), n = await l({
      title: "Insert Image",
      filters: [
        {
          name: "Image Files",
          extensions: [
            "png",
            "jpg",
            "jpeg",
            "svg",
            "webp",
            "gif",
            "bmp"
          ]
        }
      ],
      multiple: false,
      directory: false
    });
    return n === null ? null : n;
  }
  async function h0(l) {
    const n = await is("read_gds_bytes", {
      path: l
    });
    return new Uint8Array(n);
  }
  async function m0(l, n) {
    const { listen: r } = await yt(async () => {
      const { listen: i } = await import("./event-BC8TvpKC.js");
      return {
        listen: i
      };
    }, __vite__mapDeps([2,1]));
    return await r(l, (i) => n(i.payload));
  }
  const g0 = Object.freeze(Object.defineProperty({
    __proto__: null,
    getPendingFile: i0,
    isTauri: Yn,
    listenTauri: m0,
    pickGdsFile: c0,
    pickImageFile: f0,
    pickSaveFile: u0,
    pickSaveImageFile: d0,
    readFileBytes: h0,
    readGdsBytes: a0,
    saveBytes: s0,
    saveGds: o0
  }, Symbol.toStringTag, {
    value: "Module"
  })), p0 = 100 * xe, uc = 64, rn = _t((l, n) => ({
    width: p0,
    cornerRadius: 0,
    numArcPoints: uc,
    setWidth: (r) => l({
      width: r
    }),
    setCornerRadius: (r) => l({
      cornerRadius: r
    }),
    setNumArcPoints: (r) => l({
      numArcPoints: r
    }),
    pathMetadata: /* @__PURE__ */ new Map(),
    setPathMetadata: (r, o) => {
      const i = new Map(n().pathMetadata);
      i.set(r, o), l({
        pathMetadata: i
      });
    },
    removePathMetadata: (r) => {
      const o = new Map(n().pathMetadata);
      o.delete(r), l({
        pathMetadata: o
      });
    }
  }));
  function AS() {
    return `tab-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  }
  const Pe = _t((l, n) => ({
    tabs: [],
    activeTabId: null,
    addTab: (r) => {
      const o = AS(), i = {
        id: o,
        title: (r == null ? void 0 : r.title) ?? "untitled",
        filePath: (r == null ? void 0 : r.filePath) ?? null,
        isDirty: false
      };
      return l((c) => ({
        tabs: [
          ...c.tabs,
          i
        ],
        activeTabId: o
      })), o;
    },
    closeTab: (r) => {
      const o = n(), i = o.tabs.findIndex((f) => f.id === r);
      if (i === -1) return false;
      const c = o.tabs.filter((f) => f.id !== r);
      let d = o.activeTabId;
      return o.activeTabId === r && (c.length === 0 ? d = null : i < c.length ? d = c[i].id : d = c[c.length - 1].id), l({
        tabs: c,
        activeTabId: d
      }), true;
    },
    setActiveTab: (r) => {
      n().tabs.some((i) => i.id === r) && l({
        activeTabId: r
      });
    },
    updateTab: (r, o) => {
      l((i) => ({
        tabs: i.tabs.map((c) => c.id === r ? {
          ...c,
          ...o
        } : c)
      }));
    },
    getActiveTab: () => {
      const r = n();
      return r.activeTabId ? r.tabs.find((o) => o.id === r.activeTabId) ?? null : null;
    },
    getTab: (r) => n().tabs.find((o) => o.id === r),
    findTabByPath: (r) => n().tabs.find((o) => o.filePath === r)
  })), cs = /* @__PURE__ */ new Map(), pr = /* @__PURE__ */ new Map();
  function ts(l) {
    const n = Ve.getState(), r = se.getState(), o = ce.getState(), i = ve.getState(), c = ue.getState(), d = Gt.getState(), f = rn.getState(), g = Oe.getState(), p = Xn.getState(), v = Fn.getState(), b = {
      viewport: {
        zoom: n.zoom,
        offset: {
          ...n.offset
        },
        initialized: n.initialized
      },
      selection: {
        selectedIds: new Set(r.selectedIds),
        hoveredId: r.hoveredId,
        lastSelectedId: r.lastSelectedId
      },
      history: {
        undoStack: [
          ...o.undoStack
        ],
        redoStack: [
          ...o.redoStack
        ]
      },
      layers: {
        layers: new Map(i.layers),
        activeLayerId: i.activeLayerId
      },
      explorer: {
        projectName: c.projectName,
        cells: [
          ...c.cells
        ],
        cellTree: c.cellTree,
        expandedCells: new Set(c.expandedCells),
        activeCell: c.activeCell,
        cellsLoaded: c.cellsLoaded,
        hierarchyLevelLimit: c.hierarchyLevelLimit,
        maxTreeDepth: c.maxTreeDepth,
        hiddenCells: new Set(c.hiddenCells)
      },
      tool: {
        activeTool: d.activeTool
      },
      path: {
        width: f.width,
        cornerRadius: f.cornerRadius,
        numArcPoints: f.numArcPoints,
        pathMetadata: new Map(f.pathMetadata)
      },
      rulers: {
        rulers: new Map(g.rulers),
        selectedRulerIds: new Set(g.selectedRulerIds)
      },
      clipboard: {
        elements: [
          ...p.elements
        ],
        hasContent: p.hasContent
      },
      document: {
        isDirty: v.isDirty
      }
    };
    cs.set(l, b), Pe.getState().updateTab(l, {
      isDirty: v.isDirty
    });
  }
  function y0(l) {
    const n = cs.get(l);
    if (!n) return;
    Ve.setState({
      zoom: n.viewport.zoom,
      offset: {
        ...n.viewport.offset
      },
      initialized: n.viewport.initialized
    }), se.setState({
      selectedIds: new Set(n.selection.selectedIds),
      hoveredId: n.selection.hoveredId,
      lastSelectedId: n.selection.lastSelectedId
    }), ce.setState({
      undoStack: [
        ...n.history.undoStack
      ],
      redoStack: [
        ...n.history.redoStack
      ],
      canUndo: n.history.undoStack.length > 0,
      canRedo: n.history.redoStack.length > 0
    }), ve.setState({
      layers: new Map(n.layers.layers),
      activeLayerId: n.layers.activeLayerId,
      editingLayerId: null,
      expandedLayerId: null,
      isFocused: false,
      focusedLayerId: null
    }), ue.setState({
      projectName: n.explorer.projectName,
      cells: [
        ...n.explorer.cells
      ],
      cellTree: n.explorer.cellTree,
      expandedCells: new Set(n.explorer.expandedCells),
      activeCell: n.explorer.activeCell,
      editingCellName: null,
      cellsLoaded: n.explorer.cellsLoaded,
      hierarchyLevelLimit: n.explorer.hierarchyLevelLimit,
      maxTreeDepth: n.explorer.maxTreeDepth,
      hiddenCells: new Set(n.explorer.hiddenCells),
      isFocused: false,
      focusedItem: null
    }), Gt.setState({
      activeTool: n.tool.activeTool,
      toolSetAt: Date.now()
    }), rn.setState({
      width: n.path.width,
      cornerRadius: n.path.cornerRadius,
      numArcPoints: n.path.numArcPoints,
      pathMetadata: new Map(n.path.pathMetadata)
    }), Oe.setState({
      rulers: new Map(n.rulers.rulers),
      activeRulerId: null,
      previewEnd: null,
      selectedRulerIds: new Set(n.rulers.selectedRulerIds),
      hoveredRulerId: null,
      marqueePreviewIds: /* @__PURE__ */ new Set(),
      hoveredEndpoint: null,
      draggingEndpoint: null,
      draggingEndpointOriginal: null,
      isMovingRuler: false,
      moveStartPoint: null,
      moveOriginalPoint: null,
      snapPoint: null
    }), Xn.setState({
      elements: [
        ...n.clipboard.elements
      ],
      hasContent: n.clipboard.hasContent
    }), Fn.setState({
      isDirty: n.document.isDirty
    });
    const r = pr.get(l) ?? null;
    Se.setState({
      library: r
    }), Se.getState().bumpSyncGeneration();
  }
  function Zi(l) {
    cs.delete(l);
    const n = pr.get(l);
    n && (n.free(), pr.delete(l));
  }
  function Wo(l, n) {
    pr.set(l, n);
  }
  function Fi(l) {
    return pr.get(l) ?? null;
  }
  function $r(l, n) {
    if (l && l !== n) {
      ts(l);
      const r = Se.getState().library;
      r && pr.set(l, r);
    }
    y0(n);
  }
  function b0() {
    return {
      viewport: {
        zoom: Pi,
        offset: {
          x: 0,
          y: 0
        },
        initialized: false
      },
      selection: {
        selectedIds: /* @__PURE__ */ new Set(),
        hoveredId: null,
        lastSelectedId: null
      },
      history: {
        undoStack: [],
        redoStack: []
      },
      layers: {
        layers: new Map(nc.map((l) => [
          l.id,
          l
        ])),
        activeLayerId: 1
      },
      explorer: {
        projectName: "untitled-project",
        cells: [
          "top"
        ],
        cellTree: null,
        expandedCells: /* @__PURE__ */ new Set(),
        activeCell: "top",
        cellsLoaded: true,
        hierarchyLevelLimit: 1 / 0,
        maxTreeDepth: 0,
        hiddenCells: /* @__PURE__ */ new Set()
      },
      tool: {
        activeTool: "select"
      },
      path: {
        width: p0,
        cornerRadius: 0,
        numArcPoints: uc,
        pathMetadata: /* @__PURE__ */ new Map()
      },
      rulers: {
        rulers: /* @__PURE__ */ new Map(),
        selectedRulerIds: /* @__PURE__ */ new Set()
      },
      clipboard: {
        elements: [],
        hasContent: false
      },
      document: {
        isDirty: false
      }
    };
  }
  function Qi(l, n) {
    const r = new n.WasmLibrary("rosette");
    try {
      r.add_cell("top");
    } catch {
    }
    r.set_active_cell("top"), pr.set(l, r);
    const o = b0();
    return cs.set(l, o), r;
  }
  function TS(l, n, r) {
    pr.set(l, n);
    const o = {
      ...b0(),
      ...r
    };
    cs.set(l, o);
  }
  const v0 = Object.freeze(Object.defineProperty({
    __proto__: null,
    deleteTabSnapshot: Zi,
    getTabLibrary: Fi,
    initNewTab: Qi,
    initTabWithLibrary: TS,
    restoreTabSnapshot: y0,
    saveTabSnapshot: ts,
    setTabLibrary: Wo,
    switchTab: $r,
    useTabsStore: Pe
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  let Va = null, ul = null, dl = null, Wi = null, jn = null;
  const Jo = /* @__PURE__ */ new Map();
  function yr(l) {
    const n = (ul == null ? void 0 : ul.get(l)) ?? null;
    if (n) return n;
    if (!l.startsWith("ref:") && Va) {
      const r = Va.active_cell_name();
      let o = Va.get_element_index(l);
      if (o < 0 && Jo.has(l) && (o = Jo.get(l)), o >= 0) {
        if (Jo.set(l, o), dl && r && dl[r]) {
          const i = dl[r];
          if (o < i.length && i[o]) return i[o];
        }
        if (Wi && o < Wi.length) {
          const i = Wi[o];
          if (i) return i;
        }
      }
    }
    return null;
  }
  async function NS(l) {
    try {
      return (await fetch("/api/design/edit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(l)
      })).ok;
    } catch {
      return false;
    }
  }
  async function Ol(l) {
    try {
      const n = await fetch("/api/design/edit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(l)
      }), r = await n.text();
      if (!n.ok) return Xt.getState().show(`Source edit failed (HTTP ${n.status}): ${l.op}`, "error", 5e3), false;
      try {
        const o = JSON.parse(r);
        if (!o.ok) return Xt.getState().show(`Source edit failed: ${o.error || l.op}`, "error", 5e3), false;
      } catch {
      }
      return true;
    } catch {
      return Xt.getState().show("Source edit failed: could not reach server", "error", 5e3), false;
    }
  }
  function Go(l, n) {
    const r = yr(l);
    r && (r.type !== "polygon" && r.type !== "path" || Ol({
      op: "modify_vertices",
      file: r.file,
      line: r.line,
      old_code: r.code,
      vertices: Array.from(n)
    }));
  }
  function OS(l, n, r) {
    const o = yr(l);
    o && o.type === "ref" && Ol({
      op: "move_ref",
      file: o.file,
      line: o.line,
      old_code: o.code,
      dx: n,
      dy: r
    });
  }
  function IS(l, n, r) {
    const o = yr(l);
    o && (o.type !== "polygon" && o.type !== "path" || Ol({
      op: "modify_layer",
      file: o.file,
      line: o.line,
      old_code: o.code,
      layer: n,
      datatype: r
    }));
  }
  function DS(l) {
    const n = yr(l);
    n && Ol({
      op: "delete_element",
      file: n.file,
      line: n.line,
      old_code: n.code
    });
  }
  function x0(l, n, r) {
    const o = Va == null ? void 0 : Va.active_cell_name(), i = ue.getState().cells[0] ?? null;
    if (o && i && o !== i) {
      if (dl && dl[o]) {
        const g = dl[o];
        let p = 0, v = "", b = o;
        for (const S of g) if (S && S.line > p) {
          p = S.line, v = S.file;
          const C = S.code.indexOf(".");
          C > 0 && (b = S.code.substring(0, C).trim());
        }
        if (v && p > 0) {
          Ol({
            op: "add_element",
            file: v,
            after_line: p,
            element_type: "polygon",
            vertices: Array.from(l),
            layer: n,
            datatype: r,
            cell_var: b
          });
          return;
        }
      }
      if (jn && jn[o]) {
        const g = jn[o];
        Ol({
          op: "add_element",
          file: g.file,
          after_line: g.line,
          element_type: "polygon",
          vertices: Array.from(l),
          layer: n,
          datatype: r,
          cell_var: g.var_name
        });
        return;
      }
    }
    if (!ul || ul.size === 0) return;
    let c = 0, d = "", f = "cell";
    for (const g of ul.values()) if (g.line > c) {
      c = g.line, d = g.file;
      const p = g.code.indexOf(".");
      p > 0 && (f = g.code.substring(0, p).trim());
    }
    !d || c === 0 || Ol({
      op: "add_element",
      file: d,
      after_line: c,
      element_type: "polygon",
      vertices: Array.from(l),
      layer: n,
      datatype: r,
      cell_var: f
    });
  }
  function w0(l, n, r) {
    const o = ue.getState().cells[0] ?? null;
    let i = "", c = "design", d = 0;
    if (n === o && ul) for (const g of ul.values()) {
      i || (i = g.file);
      const p = g.code.indexOf(".");
      p > 0 && (c = g.code.substring(0, p).trim()), g.type === "ref" && g.line > d && (d = g.line);
    }
    else if (dl && dl[n]) {
      for (const g of dl[n]) if (g && g.type === "ref" && g.line > d) {
        d = g.line, i || (i = g.file);
        const p = g.code.indexOf(".");
        p > 0 && (c = g.code.substring(0, p).trim());
      }
    }
    if (jn && jn[n]) {
      const g = jn[n];
      i || (i = g.file), d || (d = g.line, c = g.var_name);
    }
    if (!d && ul) for (const g of ul.values()) g.line > d && (d = g.line, i || (i = g.file));
    if (!i || !d) return;
    const f = jn && jn[l] ? jn[l].var_name : l;
    Ol({
      op: "add_ref",
      file: i,
      after_line: d,
      cell_name: f,
      parent_var: c,
      transform: r
    });
  }
  function zS(l) {
    if (!jn || !jn[l]) return;
    const n = jn[l];
    Ol({
      op: "delete_cell",
      file: n.file,
      cell_name: l,
      var_name: n.var_name
    });
  }
  function HS(l, n, r) {
    if (Wi = n, dl = r ?? null, !n || n.length === 0) {
      ul = null;
      return;
    }
    const o = /* @__PURE__ */ new Map();
    try {
      const i = l.get_render_polygons();
      for (const c of i) {
        const d = c[0];
        if (d) if (d.startsWith("ref:")) {
          const f = d.indexOf(":", 4), g = parseInt(d.substring(4, f > 0 ? f : void 0), 10);
          if (g >= 0 && g < n.length) {
            const p = n[g];
            p && o.set(d, p);
          }
        } else {
          const f = l.get_element_index(d);
          if (f >= 0 && f < n.length) {
            const g = n[f];
            g && o.set(d, g);
          }
        }
      }
    } catch {
    }
    ul = o.size > 0 ? o : null;
  }
  function Yf() {
    return new URLSearchParams(window.location.search).get("design") === "true";
  }
  function ns() {
    return new URLSearchParams(window.location.search).get("embed") === "true";
  }
  function US() {
    return new URLSearchParams(window.location.search).get("src");
  }
  function YS() {
    const n = new URLSearchParams(window.location.search).get("colors");
    return n ? n.split(",").map((r) => `#${r.trim()}`) : null;
  }
  function BS() {
    const n = new URLSearchParams(window.location.search).get("fills");
    return n ? n.split(",").map((r) => r.trim()) : null;
  }
  function XS() {
    return new URLSearchParams(window.location.search).get("name");
  }
  function VS() {
    const n = new URLSearchParams(window.location.search).get("panelWidth");
    if (!n) return null;
    const r = Number.parseInt(n, 10);
    return Number.isNaN(r) || r <= 0 ? null : r;
  }
  function $S() {
    const n = new URLSearchParams(window.location.search).get("zoom");
    if (!n) return null;
    const r = Number.parseFloat(n);
    return Number.isNaN(r) || r <= 0 ? null : r;
  }
  function qS() {
    return Yn && !Yf() && !ns();
  }
  function GS(l) {
    return l !== null && !Array.isArray(l) && "name" in l && "children" in l;
  }
  function zd(l, n) {
    for (const r of n.values()) {
      const o = r.visible ? r.opacity ?? 0.7 : 0, [i, c, d, f] = cc(r.color, o);
      l.set_layer_color(r.layerNumber, r.datatype, i, c, d, f);
    }
  }
  const lc = Qo;
  function PS(l, n) {
    if (n.length === 0) return false;
    const r = new Set(n.map((f) => `${f.layerNumber}/${f.datatype}`)), o = n.map((f) => ({
      id: f.id,
      layerNumber: f.layerNumber,
      datatype: f.datatype,
      name: f.name,
      color: f.color,
      visible: f.visible ?? true,
      fillPattern: f.fillPattern ?? "solid",
      opacity: f.opacity ?? 0.7
    })), i = l.get_used_layers();
    let c = Math.max(0, ...o.map((f) => f.id)) + 1, d = o.length;
    for (let f = 0; f < i.length; f += 2) {
      const g = i[f], p = i[f + 1], v = `${g}/${p}`;
      r.has(v) || (o.push({
        id: c++,
        layerNumber: g,
        datatype: p,
        name: p === 0 ? `layer${g}` : `layer${g}/${p}`,
        color: lc[d % lc.length],
        visible: true,
        fillPattern: "solid",
        opacity: 0.7
      }), d++);
    }
    return ve.getState().resetLayers(o), true;
  }
  function Hd(l) {
    const n = l.get_used_layers();
    if (n.length === 0) return;
    const r = [];
    for (let o = 0; o < n.length; o += 2) {
      const i = n[o], c = n[o + 1], d = o / 2 + 1, f = (d - 1) % lc.length, g = c === 0 ? `layer${i}` : `layer${i}/${c}`;
      r.push({
        id: d,
        layerNumber: i,
        datatype: c,
        name: g,
        color: lc[f],
        visible: true,
        fillPattern: "solid",
        opacity: 0.7
      });
    }
    ve.getState().resetLayers(r);
  }
  function Ud() {
    ce.getState().clear(), se.getState().clearSelection(), Oe.getState().clearAllRulers(), Xn.getState().clear(), Fn.getState().markClean();
  }
  function KS(l, n) {
    const r = l.get_cell_tree();
    if (r) {
      ue.getState().setCellTree(r);
      const o = l.active_cell_name();
      o && ue.getState().setActiveCell(o);
    } else ue.getState().setCells([
      "top"
    ]);
    n && ue.getState().setProjectName(n);
  }
  function ZS(l, n) {
    const [r, o] = m.useState(null), [i, c] = m.useState(false), d = ve((k) => k.layers), f = m.useRef(d), g = m.useRef(0), p = m.useCallback((k) => {
      Va = k, o(k);
    }, []), v = m.useRef(l);
    m.useEffect(() => {
      f.current = d;
    }, [
      d
    ]), m.useEffect(() => {
      v.current = l;
    }, [
      l
    ]), m.useEffect(() => Pe.subscribe((x, E) => {
      if (x.activeTabId && x.activeTabId !== E.activeTabId) {
        const _ = Fi(x.activeTabId);
        _ && (p(_), c(true));
      }
    }), [
      p
    ]), m.useEffect(() => {
      if (!l || !n || Yf() || ns()) return;
      const { tabs: k } = Pe.getState();
      if (k.length > 0) {
        const A = Pe.getState().activeTabId;
        if (A) {
          const R = Fi(A);
          if (R) {
            p(R), c(true);
            return;
          }
        }
      }
      const x = ue.getState().projectName, E = Pe.getState().addTab({
        title: x
      }), _ = Qi(E, l), N = _.get_cell_tree();
      N ? ue.getState().setCellTree(N) : ue.getState().setCells([
        "top"
      ]), p(_), c(true);
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (!l || !n) return;
      const k = () => {
        const x = Pe.getState().addTab({
          title: "untitled-project"
        }), E = Qi(x, l);
        Ud(), ve.getState().resetLayers(nc), ue.getState().setProjectName("untitled-project");
        const _ = E.get_cell_tree();
        _ ? ue.getState().setCellTree(_) : ue.getState().setCells([
          "top"
        ]), ue.getState().setActiveCell("top");
        const N = document.getElementById("rosette-canvas");
        if (N) {
          const A = N.getBoundingClientRect();
          Ve.getState().reset(A.width, A.height);
        }
        p(E), c(true), Se.getState().bumpSyncGeneration();
      };
      return window.addEventListener("rosette-new-tab", k), () => window.removeEventListener("rosette-new-tab", k);
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (!l || !n || !qS()) return;
      let k = false;
      const x = async (_) => {
        if (!k) try {
          const N = Pe.getState().findTabByPath(_);
          if (N) {
            const H = Pe.getState().activeTabId;
            if (H && H !== N.id) {
              $r(H, N.id), Pe.getState().setActiveTab(N.id);
              const q = Fi(N.id);
              q && (p(q), c(true));
            }
            return;
          }
          const A = await a0(_);
          if (k) return;
          const R = l.WasmLibrary.from_gds_bytes(A), I = Pe.getState().activeTabId;
          if (I) {
            ts(I);
            const H = Se.getState().library;
            H && Wo(I, H);
          }
          const T = _.split(/[/\\]/).pop() ?? "untitled", L = Pe.getState().addTab({
            title: T,
            filePath: _
          });
          Hd(R), zd(R, ve.getState().layers), Wo(L, R), Ud(), KS(R, T);
          const D = document.getElementById("rosette-canvas");
          if (D) {
            const H = D.getBoundingClientRect();
            Ve.getState().reset(H.width, H.height);
          }
          p(R), c(true), Se.getState().bumpSyncGeneration();
        } catch (N) {
          console.error("Failed to open GDS file:", N);
        }
      };
      i0().then((_) => {
        _ && !k && x(_);
      });
      let E = null;
      return m0("open-file", x).then((_) => {
        k ? _() : E = _;
      }), () => {
        k = true, E == null ? void 0 : E();
      };
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (!l || !n) return;
      const k = () => {
        const x = Pe.getState().activeTabId;
        if (x) {
          ts(x);
          const R = Se.getState().library;
          R && Wo(x, R);
        }
        const E = Pe.getState().addTab({
          title: "untitled-project"
        }), _ = Qi(E, l);
        Ud(), ve.getState().resetLayers(nc), ue.getState().setProjectName("untitled-project");
        const N = _.get_cell_tree();
        N ? ue.getState().setCellTree(N) : ue.getState().setCells([
          "top"
        ]), ue.getState().setActiveCell("top");
        const A = document.getElementById("rosette-canvas");
        if (A) {
          const R = A.getBoundingClientRect();
          Ve.getState().reset(R.width, R.height);
        }
        p(_), c(true), Se.getState().bumpSyncGeneration();
      };
      return window.addEventListener("rosette-new-file", k), () => window.removeEventListener("rosette-new-file", k);
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (!l || !n || !Yf()) return;
      const k = new EventSource("/api/design/events");
      return k.addEventListener("design", (x) => {
        try {
          const E = JSON.parse(x.data);
          if (E.version < g.current && (g.current = 0), E.version !== g.current && E.json) try {
            const _ = l.WasmLibrary.from_library_json(E.json);
            E.layers && E.layers.length > 0 ? PS(_, E.layers) : Hd(_), zd(_, ve.getState().layers);
            const N = Va;
            p(_), c(true), g.current = E.version, ce.getState().clear();
            const A = [
              ...se.getState().selectedIds
            ], R = [];
            for (const T of A) if (T.startsWith("ref:")) R.push({
              elemIdx: -1,
              refId: T
            });
            else if (N) {
              let L = N.get_element_index(T);
              L < 0 && (L = Jo.get(T) ?? -1), L >= 0 && Jo.set(T, L), R.push({
                elemIdx: L,
                refId: ""
              });
            }
            se.getState().clearSelection(), N && requestAnimationFrame(() => {
              try {
                N.free();
              } catch {
              }
            }), HS(_, E.source_map ?? null, E.child_source_maps ?? null), jn = E.cell_vars ?? null;
            const I = _.get_cell_tree();
            if (I) {
              const T = ue.getState().activeCell;
              ue.getState().setCellTree(I), T && ue.getState().cells.includes(T) && _.set_active_cell(T);
            } else E.cells && (GS(E.cells) ? ue.getState().setCellTree([
              E.cells
            ]) : ue.getState().setCells(E.cells));
            if (E.filename && ue.getState().setProjectName(E.filename), R.length > 0) {
              const T = /* @__PURE__ */ new Set(), L = _.get_all_ids(), D = /* @__PURE__ */ new Map();
              for (const H of L) if (!H.startsWith("ref:")) {
                const q = _.get_element_index(H);
                q >= 0 && D.set(q, H);
              }
              for (const H of R) if (H.refId) T.add(H.refId);
              else if (H.elemIdx >= 0) {
                const q = D.get(H.elemIdx);
                q && T.add(q);
              }
              T.size > 0 && se.getState().setSelection(T);
            }
          } catch (_) {
            console.error("Failed to parse design:", _);
          }
        } catch (E) {
          console.error("Failed to parse SSE event:", E);
        }
      }), k.onerror = () => {
        console.warn("SSE connection error, reconnecting...");
      }, () => {
        k.close();
      };
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (!l || !n || !ns()) return;
      const k = US();
      if (!k || k.startsWith("//") || /^https?:\/\//i.test(k)) {
        console.error("Embed mode requires a relative ?src= parameter pointing to a JSON file");
        return;
      }
      let x = false;
      return (async () => {
        try {
          const E = await fetch(k);
          if (!E.ok) throw new Error(`Failed to fetch ${k}: ${E.status}`);
          const _ = await E.text();
          if (x) return;
          const N = l.WasmLibrary.from_library_json(_);
          Hd(N);
          const A = YS(), R = BS();
          if (A || R) {
            const D = ve.getState().layers, q = Array.from(D.values()).map((re, ee) => {
              let de = re;
              return A && ee < A.length && (de = {
                ...de,
                color: A[ee]
              }), R && ee < R.length && R[ee] in Df && (de = {
                ...de,
                fillPattern: R[ee]
              }), de;
            });
            ve.getState().resetLayers(q);
          }
          zd(N, ve.getState().layers);
          const I = Se.getState().library;
          I && I.free(), p(N), c(true);
          const T = XS();
          T && ue.getState().setProjectName(T);
          const L = N.get_cell_tree();
          if (L) {
            ue.getState().setCellTree(L);
            const D = N.active_cell_name();
            D && ue.getState().setActiveCell(D);
          }
        } catch (E) {
          console.error("Failed to load embed design:", E);
        }
      })(), () => {
        x = true;
      };
    }, [
      l,
      n,
      p
    ]), m.useEffect(() => {
      if (r) for (const k of d.values()) {
        const x = k.visible ? k.opacity ?? 0.7 : 0, [E, _, N, A] = cc(k.color, x);
        r.set_layer_color(k.layerNumber, k.datatype, E, _, N, A), r.set_layer_fill_pattern(k.layerNumber, k.datatype, Df[k.fillPattern ?? "solid"] ?? 0);
      }
    }, [
      r,
      d
    ]);
    const b = m.useCallback((k, x, E, _, N) => r ? r.add_rectangle(k, x, E, _, N, 0) ?? null : null, [
      r
    ]), S = m.useCallback((k, x) => r ? r.add_polygon(new Float64Array(k), x, 0) ?? null : null, [
      r
    ]), C = m.useCallback(() => {
      r && r.clear_active_cell();
    }, [
      r
    ]);
    return {
      library: r,
      isReady: i,
      addRectangle: b,
      addPolygon: S,
      clearCell: C
    };
  }
  const ky = 8;
  function My(l, n) {
    const r = n.x - l.x, o = n.y - l.y;
    if (r === 0 && o === 0) return n;
    const i = Math.abs(Math.atan2(Math.abs(o), Math.abs(r)) * (180 / Math.PI));
    return i <= ky ? {
      x: n.x,
      y: l.y
    } : i >= 90 - ky ? {
      x: l.x,
      y: n.y
    } : n;
  }
  function FS(l, n, r = 64) {
    const o = l.length;
    if (o < 3 || n <= 0) return l;
    const i = [];
    for (let p = 0; p < o - 1; p++) {
      const v = l[p + 1].x - l[p].x, b = l[p + 1].y - l[p].y;
      i.push(Math.sqrt(v * v + b * b));
    }
    const c = o - 2, d = [];
    for (let p = 1; p < o - 1; p++) {
      const v = l[p - 1], b = l[p], S = l[p + 1], C = i[p - 1], k = i[p];
      if (C < 1e-10 || k < 1e-10) {
        d.push(null);
        continue;
      }
      const x = (b.x - v.x) / C, E = (b.y - v.y) / C, _ = (S.x - b.x) / k, N = (S.y - b.y) / k, A = x * N - E * _, R = x * _ + E * N, I = Math.atan2(A, R);
      Math.abs(I) < 1e-6 ? d.push(null) : d.push(I);
    }
    const f = d.map((p) => {
      if (p === null) return 0;
      const v = Math.abs(p) / 2;
      return n * Math.tan(v);
    });
    for (let p = 0; p < 3; p++) for (let v = 0; v < i.length; v++) {
      const b = i[v] * 0.95, S = v > 0 ? v - 1 : null, C = v < c ? v : null, k = S !== null ? f[S] : 0, x = C !== null ? f[C] : 0, E = k + x;
      if (E > b && E > 1e-10) {
        const _ = b / E;
        S !== null && (f[S] = Math.min(f[S], k * _)), C !== null && (f[C] = Math.min(f[C], x * _));
      }
    }
    const g = [
      l[0]
    ];
    for (let p = 0; p < c; p++) {
      const v = p + 1, b = l[v], S = d[p];
      if (S === null) {
        g.push(b);
        continue;
      }
      const C = f[p], k = Math.abs(S) / 2, x = Math.tan(k), E = Math.abs(x) > 1e-10 ? C / x : 0;
      if (E < 1e-6 || C < 1e-6) {
        g.push(b);
        continue;
      }
      const _ = l[v - 1], N = l[v + 1], A = i[v - 1], R = i[v], I = (b.x - _.x) / A, T = (b.y - _.y) / A, L = (N.x - b.x) / R, D = (N.y - b.y) / R, H = S > 0 ? 1 : -1, q = b.x + I * -C, re = b.y + T * -C, ee = b.x + L * C, de = b.y + D * C, ge = -T * H, Ee = I * H, $ = q + ge * E, F = re + Ee * E, fe = q - $, ye = re - F, ke = Math.min(Math.max(Math.ceil(Math.abs(S) * 180 / Math.PI * 2), 8), r);
      g.push({
        x: q,
        y: re
      });
      for (let j = 1; j < ke; j++) {
        const O = j / ke, K = S * O, W = Math.cos(K), J = Math.sin(K);
        g.push({
          x: $ + fe * W - ye * J,
          y: F + fe * J + ye * W
        });
      }
      g.push({
        x: ee,
        y: de
      });
    }
    return g.push(l[o - 1]), g;
  }
  function QS(l, n) {
    const r = l.length;
    if (r < 3 || n <= 0) return [];
    const o = [];
    for (let g = 0; g < r - 1; g++) {
      const p = l[g + 1].x - l[g].x, v = l[g + 1].y - l[g].y;
      o.push(Math.sqrt(p * p + v * v));
    }
    const i = r - 2, c = [];
    for (let g = 1; g < r - 1; g++) {
      const p = l[g - 1], v = l[g], b = l[g + 1], S = o[g - 1], C = o[g];
      if (S < 1e-10 || C < 1e-10) {
        c.push(null);
        continue;
      }
      const k = (v.x - p.x) / S, x = (v.y - p.y) / S, E = (b.x - v.x) / C, _ = (b.y - v.y) / C, N = k * _ - x * E, A = k * E + x * _, R = Math.atan2(N, A);
      c.push(Math.abs(R) < 1e-6 ? null : R);
    }
    const d = c.map((g) => g === null ? 0 : n * Math.tan(Math.abs(g) / 2));
    for (let g = 0; g < 3; g++) for (let p = 0; p < o.length; p++) {
      const v = o[p] * 0.95, b = p > 0 ? p - 1 : null, S = p < i ? p : null, C = b !== null ? d[b] : 0, k = S !== null ? d[S] : 0, x = C + k;
      if (x > v && x > 1e-10) {
        const E = v / x;
        b !== null && (d[b] = Math.min(d[b], C * E)), S !== null && (d[S] = Math.min(d[S], k * E));
      }
    }
    const f = [];
    for (let g = 0; g < i; g++) {
      const p = c[g];
      if (p === null) continue;
      const v = Math.abs(p) / 2, b = Math.tan(v);
      if (Math.abs(b) < 1e-10) continue;
      const S = d[g] / b;
      S < n - 1e-6 && f.push({
        cornerIndex: g + 1,
        requested: n,
        actual: S
      });
    }
    return f;
  }
  function WS(l, n, r = 0, o = 64) {
    const i = r > 0 ? FS(l, r, o) : l;
    if (i.length < 2) return [];
    const c = n / 2, d = i.length, f = [], g = [];
    for (let p = 0; p < d; p++) {
      const v = i[p];
      let b, S;
      if (p === 0) {
        const C = i[1], k = C.x - v.x, x = C.y - v.y, E = Math.sqrt(k * k + x * x);
        if (E < 1e-10) continue;
        b = -x / E * c, S = k / E * c;
      } else if (p === d - 1) {
        const C = i[d - 2], k = v.x - C.x, x = v.y - C.y, E = Math.sqrt(k * k + x * x);
        if (E < 1e-10) continue;
        b = -x / E * c, S = k / E * c;
      } else {
        const C = i[p - 1], k = i[p + 1], x = v.x - C.x, E = v.y - C.y, _ = Math.sqrt(x * x + E * E), N = k.x - v.x, A = k.y - v.y, R = Math.sqrt(N * N + A * A);
        if (_ < 1e-10 || R < 1e-10) continue;
        const I = -E / _, T = x / _, L = -A / R, D = N / R, H = I * L + T * D, q = Math.acos(Math.min(1, Math.max(-1, H))), re = Math.cos(q / 2), ee = re > 1e-6 ? 1 / re : 1, de = (I + L) / 2, ge = (T + D) / 2, Ee = Math.sqrt(de * de + ge * ge);
        Ee < 1e-10 ? (b = I * c, S = T * c) : (b = de / Ee * c * ee, S = ge / Ee * c * ee);
      }
      f.push({
        x: v.x + b,
        y: v.y + S
      }), g.push({
        x: v.x - b,
        y: v.y - S
      });
    }
    return g.reverse(), [
      ...f,
      ...g
    ];
  }
  class S0 {
    constructor(n, r, o, i, c, d = 0) {
      __publicField(this, "type", "create-rectangle");
      __publicField(this, "description");
      __publicField(this, "elementId", null);
      this.x = n, this.y = r, this.width = o, this.height = i, this.layer = c, this.datatype = d, this.description = `Create rectangle at (${n}, ${r})`;
    }
    execute(n) {
      const r = n.library.add_rectangle(this.x, this.y, this.width, this.height, this.layer, this.datatype);
      if (r) {
        this.elementId = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().select(r);
        const o = new Float64Array([
          this.x,
          this.y,
          this.x + this.width,
          this.y,
          this.x + this.width,
          this.y + this.height,
          this.x,
          this.y + this.height
        ]);
        x0(o, this.layer, this.datatype);
      }
    }
    undo(n) {
      if (this.elementId) {
        n.library.remove_element(this.elementId), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const { selectedIds: r, removeFromSelection: o } = se.getState();
        r.has(this.elementId) && o(this.elementId);
      }
    }
    getElementId() {
      return this.elementId;
    }
  }
  function xr(l, n) {
    const r = [], o = /* @__PURE__ */ new Set();
    for (const i of n) {
      if (i.startsWith("ref:")) {
        const g = i.split(":")[1];
        if (o.has(g)) continue;
        o.add(g);
        const p = l.get_cell_ref_info(i);
        p && (r.push({
          type: "cell-ref",
          cellName: p.cell_name,
          transform: new Float64Array(p.transform)
        }), p.free());
        continue;
      }
      const c = l.get_cell_ref_info(i);
      if (c) {
        r.push({
          type: "cell-ref",
          cellName: c.cell_name,
          transform: new Float64Array(c.transform)
        }), c.free();
        continue;
      }
      const d = l.get_text_element_info(i);
      if (d) {
        r.push({
          type: "text",
          text: d.text,
          x: d.x,
          y: d.y,
          height: d.height,
          layer: d.layer,
          datatype: d.datatype
        });
        continue;
      }
      const f = l.get_element_info(i);
      f && (r.push({
        type: "polygon",
        vertices: new Float64Array(f.vertices),
        layer: f.layer,
        datatype: f.datatype
      }), f.free());
    }
    return r;
  }
  function us(l, n) {
    const r = [];
    for (const o of n) if (o.type === "cell-ref") {
      const i = l.add_cell_ref_with_transform(o.cellName, o.transform);
      i && r.push(i);
    } else if (o.type === "text") {
      const i = l.add_text(o.text, o.x, o.y, o.height, o.layer, o.datatype);
      i && r.push(i);
    } else {
      const i = l.add_polygon(o.vertices, o.layer, o.datatype);
      i && r.push(i);
    }
    return r;
  }
  function C0(l, n) {
    if (new URLSearchParams(window.location.search).get("design") !== "true") return;
    const o = l.library.active_cell_name();
    if (o) for (const i of n) i.type === "cell-ref" && w0(i.cellName, o, Array.from(i.transform));
  }
  class dc {
    constructor(n) {
      __publicField(this, "type", "delete-elements");
      __publicField(this, "description");
      __publicField(this, "snapshots", []);
      __publicField(this, "restoredIds", []);
      this.elementIds = n;
      const r = n.length;
      this.description = r === 1 ? "Delete element" : `Delete ${r} elements`;
    }
    execute(n) {
      let r = this.restoredIds.length > 0 ? this.restoredIds : this.elementIds;
      const o = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Map();
      for (const p of r) {
        const v = n.library.get_cell_ref_info(p);
        if (v) {
          const b = v.cell_name, S = p.startsWith("ref:") ? p.split(":")[1] : p;
          v.free(), c.has(b) || c.set(b, /* @__PURE__ */ new Set()), c.get(b).add(S);
        }
      }
      for (const [p, v] of c) {
        const b = n.library.get_cell_ref_parents(p), S = Array.isArray(b) ? b.length : 0;
        if (S > 0 && v.size >= S) {
          o.add(p);
          for (const C of r) {
            const k = n.library.get_cell_ref_info(C);
            k && (k.cell_name === p && i.add(C), k.free());
          }
        }
      }
      if (i.size > 0) {
        r = r.filter((v) => !i.has(v));
        const p = [
          ...o
        ].map((v) => `"${v}"`).join(", ");
        if (Xt.getState().show(`Cannot delete last reference to ${p}. Delete the cell from the Explorer instead.`, "warn", 5e3), r.length === 0) return;
      }
      this.snapshots.length === 0 && (this.snapshots = xr(n.library, r));
      const d = new URLSearchParams(window.location.search).get("design") === "true", f = /* @__PURE__ */ new Map();
      let g = 0;
      for (const p of r) {
        const v = yr(p);
        if (v) {
          const b = `${v.file}:${v.line}`;
          f.has(b) || f.set(b, p);
        } else d && g++;
      }
      g > 0 && d && Xt.getState().show(`${g} element(s) deleted from viewer only \u2014 no source tracking available. Changes may revert on reload.`, "warn", 5e3), n.library.remove_elements(r), this.restoredIds = [], bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().clearSelection();
      for (const p of f.values()) DS(p);
    }
    undo(n) {
      this.restoredIds = us(n.library, this.snapshots), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), this.restoredIds.length > 0 && se.getState().setSelection(new Set(this.restoredIds));
    }
  }
  class fc {
    constructor() {
      __publicField(this, "type", "paste-elements");
      __publicField(this, "description");
      __publicField(this, "createdIds", []);
      __publicField(this, "snapshots");
      const { elements: n } = Xn.getState();
      this.snapshots = n.map((o) => o.type === "cell-ref" ? {
        type: "cell-ref",
        cellName: o.cellName,
        transform: new Float64Array(o.transform)
      } : o.type === "text" ? {
        ...o
      } : {
        type: "polygon",
        vertices: new Float64Array(o.vertices),
        layer: o.layer,
        datatype: o.datatype
      });
      const r = this.snapshots.length;
      this.description = r === 1 ? "Paste element" : `Paste ${r} elements`;
    }
    execute(n) {
      this.snapshots.length !== 0 && (this.createdIds = us(n.library, this.snapshots), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), this.createdIds.length > 0 && se.getState().setSelection(new Set(this.createdIds)), C0(n, this.snapshots));
    }
    undo(n) {
      n.library.remove_elements(this.createdIds), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().clearSelection();
    }
  }
  class hc {
    constructor(n) {
      __publicField(this, "type", "duplicate-elements");
      __publicField(this, "description");
      __publicField(this, "snapshots", []);
      __publicField(this, "createdIds", []);
      this.elementIds = n;
      const r = n.length;
      this.description = r === 1 ? "Duplicate element" : `Duplicate ${r} elements`;
    }
    execute(n) {
      this.snapshots.length === 0 && (this.snapshots = xr(n.library, this.elementIds)), this.createdIds = us(n.library, this.snapshots), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), this.createdIds.length > 0 && se.getState().setSelection(new Set(this.createdIds)), C0(n, this.snapshots);
    }
    undo(n) {
      n.library.remove_elements(this.createdIds), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), this.elementIds.length > 0 ? se.getState().setSelection(new Set(this.elementIds)) : se.getState().clearSelection();
    }
  }
  class E0 {
    constructor(n, r, o = 0) {
      __publicField(this, "type", "create-polygon");
      __publicField(this, "description");
      __publicField(this, "elementId", null);
      this.points = n, this.layer = r, this.datatype = o, this.description = `Create polygon with ${n.length / 2} vertices`;
    }
    execute(n) {
      const r = n.library.add_polygon(this.points, this.layer, this.datatype);
      r && (this.elementId = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().select(r), x0(this.points, this.layer, this.datatype));
    }
    undo(n) {
      if (this.elementId) {
        n.library.remove_element(this.elementId), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const { selectedIds: r, removeFromSelection: o } = se.getState();
        r.has(this.elementId) && o(this.elementId);
      }
    }
    getElementId() {
      return this.elementId;
    }
  }
  function jy(l) {
    const n = l / xe / 1e3;
    return n.toFixed(n >= 10 ? 1 : n >= 1 ? 2 : 3);
  }
  function _0(l, n) {
    if (n <= 0) return;
    const r = QS(l, n);
    if (r.length === 0) return;
    const o = jy(n), i = Math.min(...r.map((f) => f.actual)), c = jy(i), d = r.length === 1 ? `Bend radius reduced to ${c} \xB5m at corner ${r[0].cornerIndex} (requested ${o} \xB5m)` : `Bend radius reduced at ${r.length} corners (min ${c} \xB5m, requested ${o} \xB5m)`;
    Xt.getState().show(d, "warn");
  }
  class k0 {
    constructor(n, r, o, i = 0, c, d = 0, f = uc) {
      __publicField(this, "type", "create-path");
      __publicField(this, "description");
      __publicField(this, "elementId", null);
      __publicField(this, "metadata", null);
      this.points = n, this.width = r, this.layer = o, this.datatype = i, this.waypoints = c, this.cornerRadius = d, this.numArcPoints = f, this.description = `Create path with ${n.length / 2} waypoints`;
    }
    execute(n) {
      const r = n.library.create_path_rounded(this.points, this.width, this.cornerRadius, this.numArcPoints, this.layer, this.datatype);
      r && (this.elementId = r, this.metadata ? rn.getState().setPathMetadata(r, this.metadata) : this.waypoints && (this.metadata = {
        waypoints: this.waypoints,
        width: this.width,
        cornerRadius: this.cornerRadius,
        numArcPoints: this.numArcPoints,
        layer: this.layer,
        datatype: this.datatype
      }, rn.getState().setPathMetadata(r, this.metadata)), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().select(r), this.waypoints && _0(this.waypoints, this.cornerRadius));
    }
    undo(n) {
      if (this.elementId) {
        this.metadata || (this.metadata = rn.getState().pathMetadata.get(this.elementId) ?? null), rn.getState().removePathMetadata(this.elementId), n.library.remove_element(this.elementId), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const { selectedIds: r, removeFromSelection: o } = se.getState();
        r.has(this.elementId) && o(this.elementId);
      }
    }
    getElementId() {
      return this.elementId;
    }
  }
  class Bo {
    constructor(n, r, o, i) {
      __publicField(this, "type", "edit-path");
      __publicField(this, "description");
      __publicField(this, "currentId");
      __publicField(this, "oldMeta");
      __publicField(this, "newMeta");
      this.currentId = n, this.oldMeta = r, this.newMeta = o, this.description = i;
    }
    execute(n) {
      this.currentId = this.rebuildPath(n, this.currentId, this.newMeta);
    }
    undo(n) {
      this.currentId = this.rebuildPath(n, this.currentId, this.oldMeta);
    }
    rebuildPath(n, r, o) {
      const i = new Float64Array(o.waypoints.length * 2);
      for (let d = 0; d < o.waypoints.length; d++) i[d * 2] = o.waypoints[d].x, i[d * 2 + 1] = o.waypoints[d].y;
      n.library.remove_element(r);
      const c = n.library.create_path_rounded(i, o.width, o.cornerRadius, o.numArcPoints ?? uc, o.layer, o.datatype);
      return c ? (rn.getState().removePathMetadata(r), rn.getState().setPathMetadata(c, {
        ...o
      }), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().select(c), _0(o.waypoints, o.cornerRadius), c) : (n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), r);
    }
  }
  class JS {
    constructor(n, r, o) {
      __publicField(this, "type", "move-elements");
      __publicField(this, "description");
      this.elementIds = n, this.deltaX = r, this.deltaY = o;
      const i = n.length;
      this.description = i === 1 ? "Move element" : `Move ${i} elements`;
    }
    execute(n) {
      n.library.translate_elements(this.elementIds, this.deltaX, this.deltaY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.translate_elements(this.elementIds, -this.deltaX, -this.deltaY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class e2 {
    constructor(n, r) {
      __publicField(this, "type", "create-ruler");
      __publicField(this, "description", "Create ruler");
      __publicField(this, "ruler");
      __publicField(this, "alreadyCreated");
      "id" in n ? (this.ruler = n, this.alreadyCreated = true) : (this.ruler = {
        id: "",
        start: n,
        end: r
      }, this.alreadyCreated = false);
    }
    execute(n) {
      if (this.alreadyCreated) {
        const { rulers: r } = Oe.getState();
        r.has(this.ruler.id) || Oe.setState((o) => {
          const i = new Map(o.rulers);
          return i.set(this.ruler.id, this.ruler), {
            rulers: i
          };
        });
      } else {
        const r = Oe.getState().addRuler(this.ruler.start, this.ruler.end);
        this.ruler = {
          ...this.ruler,
          id: r
        };
      }
    }
    undo(n) {
      Oe.getState().removeRuler(this.ruler.id);
    }
    getRulerId() {
      return this.ruler.id;
    }
  }
  class sh {
    constructor(n) {
      __publicField(this, "type", "delete-rulers");
      __publicField(this, "description");
      __publicField(this, "snapshots", []);
      __publicField(this, "restoredIds", []);
      this.rulerIds = n;
      const r = n.length;
      this.description = r === 1 ? "Delete ruler" : `Delete ${r} rulers`;
    }
    execute(n) {
      const { rulers: r, removeRulers: o } = Oe.getState(), i = this.restoredIds.length > 0 ? this.restoredIds : this.rulerIds;
      if (this.snapshots.length === 0) for (const c of i) {
        const d = r.get(c);
        d && this.snapshots.push({
          ...d
        });
      }
      o(i), this.restoredIds = [];
    }
    undo(n) {
      const r = Oe.getState().restoreRulers(this.snapshots);
      this.restoredIds = r, r.length > 0 && Oe.getState().setSelection(new Set(r));
    }
  }
  class M0 {
    constructor(n, r, o) {
      __publicField(this, "type", "move-rulers");
      __publicField(this, "description");
      this.rulerIds = n, this.deltaX = r, this.deltaY = o;
      const i = n.length;
      this.description = i === 1 ? "Move ruler" : `Move ${i} rulers`;
    }
    execute(n) {
      this.applyDelta(this.deltaX, this.deltaY);
    }
    undo(n) {
      this.applyDelta(-this.deltaX, -this.deltaY);
    }
    applyDelta(n, r) {
      Oe.setState((o) => {
        const i = new Map(o.rulers);
        for (const c of this.rulerIds) {
          const d = i.get(c);
          d && i.set(c, {
            ...d,
            start: {
              x: d.start.x + n,
              y: d.start.y + r
            },
            end: {
              x: d.end.x + n,
              y: d.end.y + r
            }
          });
        }
        return {
          rulers: i
        };
      });
    }
  }
  class j0 {
    constructor(n, r, o, i) {
      __publicField(this, "type", "move-ruler-endpoint");
      __publicField(this, "description", "Move ruler endpoint");
      this.rulerId = n, this.endpoint = r, this.oldPosition = o, this.newPosition = i;
    }
    execute(n) {
      Oe.getState().updateEndpoint(this.rulerId, this.endpoint, this.newPosition);
    }
    undo(n) {
      Oe.getState().updateEndpoint(this.rulerId, this.endpoint, this.oldPosition);
    }
  }
  class L0 {
    constructor(n, r) {
      __publicField(this, "type", "add-layer");
      __publicField(this, "description", "Add layer");
      __publicField(this, "createdLayer", null);
      this.name = n, this.color = r;
    }
    execute(n) {
      this.createdLayer ? (ve.getState().setLayer(this.createdLayer), ve.getState().setActiveLayer(this.createdLayer.id)) : this.createdLayer = ve.getState().addLayer(this.name, this.color);
    }
    undo(n) {
      this.createdLayer && ve.getState().deleteLayer(this.createdLayer.id);
    }
  }
  class ih {
    constructor(n) {
      __publicField(this, "type", "delete-layer");
      __publicField(this, "description");
      __publicField(this, "snapshot", null);
      __publicField(this, "elementSnapshots", []);
      __publicField(this, "restoredElementIds", []);
      this.layerId = n, this.description = "Delete layer";
    }
    execute(n) {
      const r = ve.getState();
      if (this.snapshot = r.getLayer(this.layerId) ?? null, !this.snapshot) return;
      const o = this.restoredElementIds.length > 0 ? this.restoredElementIds : n.library.get_elements_on_layer(this.snapshot.layerNumber, this.snapshot.datatype);
      if (this.elementSnapshots.length === 0) for (const i of o) {
        const c = n.library.get_element_info(i);
        c && (this.elementSnapshots.push({
          vertices: new Float64Array(c.vertices),
          layer: c.layer,
          datatype: c.datatype
        }), c.free());
      }
      n.library.remove_elements(o), this.restoredElementIds = [], n.library.remove_layer_color(this.snapshot.layerNumber, this.snapshot.datatype), r.deleteLayer(this.layerId), se.getState().clearSelection(), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      if (!this.snapshot) return;
      ve.getState().setLayer(this.snapshot), ve.getState().setActiveLayer(this.snapshot.id), Bf(this.snapshot, n);
      const r = [];
      for (const o of this.elementSnapshots) {
        const i = n.library.add_polygon(o.vertices, o.layer, o.datatype);
        i && r.push(i);
      }
      this.restoredElementIds = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  function Bf(l, n) {
    const r = l.visible ? l.opacity : 0, [o, i, c, d] = cc(l.color, r);
    n.library.set_layer_color(l.layerNumber, l.datatype, o, i, c, d), n.library.set_layer_fill_pattern(l.layerNumber, l.datatype, Df[l.fillPattern ?? "solid"] ?? 0);
  }
  class R0 {
    constructor(n, r) {
      __publicField(this, "type", "edit-layer");
      __publicField(this, "description");
      this.oldLayer = n, this.newLayer = r, this.description = `Edit layer "${n.name}"`;
    }
    execute(n) {
      const r = ve.getState();
      (this.oldLayer.layerNumber !== this.newLayer.layerNumber || this.oldLayer.datatype !== this.newLayer.datatype) && n.library.remove_layer_color(this.oldLayer.layerNumber, this.oldLayer.datatype), r.setLayer(this.newLayer), Bf(this.newLayer, n), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      const r = ve.getState();
      (this.oldLayer.layerNumber !== this.newLayer.layerNumber || this.oldLayer.datatype !== this.newLayer.datatype) && n.library.remove_layer_color(this.newLayer.layerNumber, this.newLayer.datatype), r.setLayer(this.oldLayer), Bf(this.oldLayer, n), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class Ly {
    constructor(n, r, o) {
      __publicField(this, "type", "change-element-layer");
      __publicField(this, "description");
      __publicField(this, "originals", []);
      __publicField(this, "newIds", []);
      this.elementIds = n, this.newLayer = r, this.newDatatype = o;
      const i = n.length;
      this.description = i === 1 ? "Change element layer" : `Change layer of ${i} elements`;
    }
    execute(n) {
      if (this.originals.length === 0) for (const i of this.elementIds) {
        const c = n.library.get_text_element_info(i);
        if (c) {
          this.originals.push({
            id: i,
            snapshot: {
              type: "text",
              text: c.text,
              x: c.x,
              y: c.y,
              height: c.height,
              layer: c.layer,
              datatype: c.datatype
            }
          });
          continue;
        }
        const d = n.library.get_element_info(i);
        d && (this.originals.push({
          id: i,
          snapshot: {
            vertices: new Float64Array(d.vertices),
            layer: d.layer,
            datatype: d.datatype
          }
        }), d.free());
      }
      const r = this.newIds.length > 0 ? this.newIds : this.elementIds;
      n.library.remove_elements(r);
      const o = [];
      for (const { snapshot: i } of this.originals) {
        let c;
        "type" in i && i.type === "text" ? c = n.library.add_text(i.text, i.x, i.y, i.height, this.newLayer, this.newDatatype) : c = n.library.add_polygon(i.vertices, this.newLayer, this.newDatatype), c && o.push(c);
      }
      this.newIds = o, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), o.length > 0 && se.getState().setSelection(new Set(o));
    }
    undo(n) {
      n.library.remove_elements(this.newIds);
      const r = [];
      for (const { snapshot: o } of this.originals) {
        let i;
        "type" in o && o.type === "text" ? i = n.library.add_text(o.text, o.x, o.y, o.height, o.layer, o.datatype) : i = n.library.add_polygon(o.vertices, o.layer, o.datatype), i && r.push(i);
      }
      this.newIds = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), r.length > 0 && se.getState().setSelection(new Set(r));
    }
  }
  class t2 {
    constructor(n, r, o, i) {
      __publicField(this, "type", "resize-elements");
      __publicField(this, "description");
      __publicField(this, "originals", []);
      __publicField(this, "newIds", []);
      this.elementIds = n, this.oldBounds = r, this.newWidth = o, this.newHeight = i;
      const c = n.length;
      this.description = c === 1 ? "Resize element" : `Resize ${c} elements`;
    }
    execute(n) {
      if (this.originals.length === 0) for (const g of this.elementIds) {
        const p = n.library.get_element_info(g);
        p && (this.originals.push({
          id: g,
          snapshot: {
            vertices: new Float64Array(p.vertices),
            layer: p.layer,
            datatype: p.datatype
          }
        }), p.free());
      }
      const r = this.oldBounds.maxX - this.oldBounds.minX, o = this.oldBounds.maxY - this.oldBounds.minY, i = r !== 0 ? this.newWidth / r : 1, c = o !== 0 ? this.newHeight / o : 1, d = this.newIds.length > 0 ? this.newIds : this.elementIds;
      n.library.remove_elements(d);
      const f = [];
      for (const { snapshot: g } of this.originals) {
        const p = new Float64Array(g.vertices.length);
        for (let b = 0; b < g.vertices.length; b += 2) p[b] = this.oldBounds.minX + (g.vertices[b] - this.oldBounds.minX) * i, p[b + 1] = this.oldBounds.minY + (g.vertices[b + 1] - this.oldBounds.minY) * c;
        const v = n.library.add_polygon(p, g.layer, g.datatype);
        v && f.push(v);
      }
      this.newIds = f, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), f.length > 0 && se.getState().setSelection(new Set(f));
    }
    undo(n) {
      n.library.remove_elements(this.newIds);
      const r = [];
      for (const { snapshot: o } of this.originals) {
        const i = n.library.add_polygon(o.vertices, o.layer, o.datatype);
        i && r.push(i);
      }
      this.newIds = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), r.length > 0 && se.getState().setSelection(new Set(r));
    }
  }
  class Yd {
    constructor(n, r, o) {
      __publicField(this, "type", "edit-vertices");
      __publicField(this, "description");
      __publicField(this, "original", null);
      __publicField(this, "currentId");
      this.newVertices = r, this.currentId = n, this.description = o ?? "Edit vertices";
    }
    execute(n) {
      if (!this.original) {
        const o = n.library.get_element_info(this.currentId);
        if (!o) return;
        this.original = {
          vertices: new Float64Array(o.vertices),
          layer: o.layer,
          datatype: o.datatype
        }, o.free();
      }
      n.library.remove_element(this.currentId);
      const r = n.library.add_polygon(this.newVertices, this.original.layer, this.original.datatype);
      r && (this.currentId = r, se.getState().setSelection(/* @__PURE__ */ new Set([
        r
      ]))), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      if (!this.original) return;
      n.library.remove_element(this.currentId);
      const r = n.library.add_polygon(this.original.vertices, this.original.layer, this.original.datatype);
      r && (this.currentId = r, se.getState().setSelection(/* @__PURE__ */ new Set([
        r
      ]))), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class n2 {
    constructor(n, r, o, i, c) {
      __publicField(this, "type", "move-elements-to");
      __publicField(this, "description");
      __publicField(this, "deltaX");
      __publicField(this, "deltaY");
      __publicField(this, "currentIds");
      this.currentIds = [
        ...n
      ], this.deltaX = i - r, this.deltaY = c - o, this.description = n.length === 1 ? "Move element" : `Move ${n.length} elements`;
    }
    execute(n) {
      n.library.translate_elements(this.currentIds, this.deltaX, this.deltaY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.translate_elements(this.currentIds, -this.deltaX, -this.deltaY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class Bd {
    constructor(n, r, o, i) {
      __publicField(this, "type", "set-instance-transform");
      __publicField(this, "description");
      this.refId = n, this.oldTransform = r, this.newTransform = o, this.description = i ?? "Set instance transform";
    }
    execute(n) {
      n.library.set_cell_ref_transform(this.refId, this.newTransform), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.set_cell_ref_transform(this.refId, this.oldTransform), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class l2 {
    constructor(n, r, o) {
      __publicField(this, "type", "set-instance-array");
      __publicField(this, "description");
      this.refId = n, this.oldParams = r, this.newParams = o, this.description = "Set instance array";
    }
    execute(n) {
      this.applyParams(n, this.newParams);
    }
    undo(n) {
      this.applyParams(n, this.oldParams);
    }
    applyParams(n, r) {
      r && (r.columns > 1 || r.rows > 1) ? n.library.set_cell_ref_array(this.refId, r.columns, r.rows, r.colSpacing, r.rowSpacing) : n.library.set_cell_ref_array(this.refId, 1, 1, 0, 0), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  function bn(l) {
    const n = l.get_cell_tree();
    n && ue.getState().setCellTree(n);
  }
  class ch {
    constructor(n) {
      __publicField(this, "type", "add-cell");
      __publicField(this, "description");
      __publicField(this, "cellName");
      this.cellName = n, this.description = `Add cell "${n}"`;
    }
    execute(n) {
      n.library.add_cell(this.cellName), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.remove_cell(this.cellName), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class uh {
    constructor(n) {
      __publicField(this, "type", "delete-cell");
      __publicField(this, "description");
      __publicField(this, "cellName");
      __publicField(this, "elementSnapshots", []);
      __publicField(this, "cellOrigin", [
        0,
        0
      ]);
      __publicField(this, "parentRefs", []);
      this.cellName = n, this.description = `Delete cell "${n}"`;
    }
    execute(n) {
      if (this.elementSnapshots.length === 0 && this.parentRefs.length === 0) {
        const o = n.library.get_cell_origin_by_name(this.cellName);
        o && (this.cellOrigin = [
          o[0],
          o[1]
        ]);
        const i = n.library.get_cell_ref_parents(this.cellName);
        Array.isArray(i) && (this.parentRefs = i.map((f) => ({
          parent: f.parent,
          transform: new Float64Array(f.transform)
        })));
        const c = n.library.active_cell_name();
        n.library.set_active_cell(this.cellName);
        const d = n.library.get_all_ids();
        d.length > 0 && (this.elementSnapshots = xr(n.library, d)), c && n.library.set_active_cell(c);
      }
      n.library.remove_cell_cascade(this.cellName), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), new URLSearchParams(window.location.search).get("design") === "true" && zS(this.cellName);
    }
    undo(n) {
      n.library.add_cell(this.cellName);
      const r = n.library.active_cell_name();
      n.library.set_active_cell(this.cellName), n.library.set_cell_origin(this.cellOrigin[0], this.cellOrigin[1]), this.elementSnapshots.length > 0 && us(n.library, this.elementSnapshots), r && n.library.set_active_cell(r);
      for (const o of this.parentRefs) n.library.add_cell_ref_to_with_transform(o.parent, this.cellName, o.transform);
      bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class r2 {
    constructor(n, r, o, i) {
      __publicField(this, "type", "set-cell-origin");
      __publicField(this, "description", "Set cell origin");
      this.oldX = n, this.oldY = r, this.newX = o, this.newY = i;
    }
    execute(n) {
      n.library.set_cell_origin(this.newX, this.newY), n.renderer.set_crosshair_origin(this.newX, this.newY), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.set_cell_origin(this.oldX, this.oldY), n.renderer.set_crosshair_origin(this.oldX, this.oldY), n.renderer.mark_dirty();
    }
  }
  class A0 {
    constructor(n, r) {
      __publicField(this, "type", "rename-cell");
      __publicField(this, "description");
      this.oldName = n, this.newName = r, this.description = `Rename cell "${n}" to "${r}"`;
    }
    execute(n) {
      const r = ue.getState();
      r.activeCell === this.oldName && r.setActiveCell(this.newName), n.library.rename_cell(this.oldName, this.newName), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      const r = ue.getState();
      r.activeCell === this.newName && r.setActiveCell(this.oldName), n.library.rename_cell(this.newName, this.oldName), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class T0 {
    constructor(n, r, o) {
      __publicField(this, "type", "add-cell-ref");
      __publicField(this, "description");
      __publicField(this, "elementId", null);
      this.cellName = n, this.x = r, this.y = o, this.description = `Place instance of "${n}"`;
    }
    execute(n) {
      const r = n.library.add_cell_ref(this.cellName, this.x, this.y);
      if (r) {
        this.elementId = r, bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const o = n.library.get_element_index(r);
        if (o >= 0 && se.getState().select(`ref:${o}:0`), new URLSearchParams(window.location.search).get("design") === "true") {
          const c = n.library.active_cell_name();
          c && w0(this.cellName, c, [
            1,
            0,
            0,
            1,
            this.x,
            this.y
          ]);
        }
      }
    }
    undo(n) {
      if (this.elementId) {
        n.library.remove_element(this.elementId), bn(n.library), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const { selectedIds: r, removeFromSelection: o } = se.getState();
        r.has(this.elementId) && o(this.elementId);
      }
    }
  }
  function ln(l) {
    return Math.round(l / xe) * xe;
  }
  function mc() {
    const { activeLayerId: l, layers: n } = ve.getState(), r = n.get(l);
    return {
      layerNumber: (r == null ? void 0 : r.layerNumber) ?? 1,
      datatype: (r == null ? void 0 : r.datatype) ?? 0
    };
  }
  function gc(l) {
    const { zoom: n, offset: r } = Ve.getState(), o = l.getBoundingClientRect(), i = (o.width / 2 - r.x) / n, c = (o.height / 2 - r.y) / n, d = o.width / n, f = o.height / n, g = Math.max(ln(d * 0.1 / 2), xe), p = Math.max(ln(f * 0.1 / 2), xe);
    return {
      centerX: i,
      centerY: c,
      halfW: g,
      halfH: p
    };
  }
  function N0(l, n, r) {
    const { centerX: o, centerY: i, halfW: c, halfH: d } = gc(r), f = c * 2, g = d * 2, p = ln(o - c), v = ln(i - d), { layerNumber: b, datatype: S } = mc(), C = new S0(p, v, f, g, b, S);
    ce.getState().execute(C, {
      library: l,
      renderer: n
    });
  }
  function O0(l, n, r) {
    const { centerX: o, centerY: i, halfW: c, halfH: d } = gc(r), f = new Float64Array([
      ln(o - c),
      ln(i - d),
      ln(o + c),
      ln(i - d),
      ln(o),
      ln(i + d)
    ]), { layerNumber: g, datatype: p } = mc(), v = new E0(f, g, p);
    ce.getState().execute(v, {
      library: l,
      renderer: n
    });
  }
  function I0(l, n, r) {
    const { centerX: o, centerY: i, halfH: c } = gc(r), d = Math.max(ln(c), xe), { layerNumber: f, datatype: g } = mc(), p = new z0("Text", ln(o), ln(i), d, f, g);
    ce.getState().execute(p, {
      library: l,
      renderer: n
    }), Se.getState().bumpSyncGeneration();
  }
  function D0(l, n, r) {
    const { centerX: o, centerY: i, halfW: c } = gc(r), d = ln(o - c), f = ln(o + c), g = ln(i), p = new Float64Array([
      d,
      g,
      f,
      g
    ]), v = [
      {
        x: d,
        y: g
      },
      {
        x: f,
        y: g
      }
    ], { layerNumber: b, datatype: S } = mc(), { width: C, cornerRadius: k, numArcPoints: x } = rn.getState(), E = new k0(p, C, b, S, v, k, x);
    ce.getState().execute(E, {
      library: l,
      renderer: n
    });
  }
  class z0 {
    constructor(n, r, o, i, c, d = 0) {
      __publicField(this, "type", "create-text");
      __publicField(this, "description");
      __publicField(this, "elementId", null);
      this.text = n, this.x = r, this.y = o, this.height = i, this.layer = c, this.datatype = d, this.description = `Create text "${n.slice(0, 20)}" at (${r}, ${o})`;
    }
    execute(n) {
      const r = n.library.add_text(this.text, this.x, this.y, this.height, this.layer, this.datatype);
      r && (this.elementId = r, n.renderer.sync_from_library(n.library), n.renderer.mark_dirty(), se.getState().select(r));
    }
    undo(n) {
      if (this.elementId) {
        n.library.remove_element(this.elementId), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
        const { selectedIds: r, removeFromSelection: o } = se.getState();
        r.has(this.elementId) && o(this.elementId);
      }
    }
    getElementId() {
      return this.elementId;
    }
  }
  class a2 {
    constructor(n, r, o) {
      __publicField(this, "type", "update-text-content");
      __publicField(this, "description", "Update text content");
      this.elementId = n, this.oldText = r, this.newText = o;
    }
    execute(n) {
      n.library.update_text(this.elementId, this.newText), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.update_text(this.elementId, this.oldText), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class o2 {
    constructor(n, r, o, i, c) {
      __publicField(this, "type", "move-text");
      __publicField(this, "description", "Move text");
      this.elementId = n, this.oldX = r, this.oldY = o, this.newX = i, this.newY = c;
    }
    execute(n) {
      n.library.set_text_position(this.elementId, this.newX, this.newY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.set_text_position(this.elementId, this.oldX, this.oldY), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class s2 {
    constructor(n, r, o) {
      __publicField(this, "type", "set-text-height");
      __publicField(this, "description", "Set text height");
      this.elementId = n, this.oldHeight = r, this.newHeight = o;
    }
    execute(n) {
      n.library.set_text_height(this.elementId, this.newHeight), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      n.library.set_text_height(this.elementId, this.oldHeight), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class H0 {
    constructor(n) {
      __publicField(this, "type", "text-to-polygons");
      __publicField(this, "description");
      __publicField(this, "snapshots", []);
      __publicField(this, "resultIds", []);
      this.textElementIds = n, this.description = n.length === 1 ? "Convert text to polygons" : `Convert ${n.length} texts to polygons`;
    }
    execute(n) {
      if (this.snapshots.length === 0) for (const r of this.textElementIds) {
        const o = n.library.get_text_element_info(r);
        o && this.snapshots.push({
          snapshot: {
            type: "text",
            text: o.text,
            x: o.x,
            y: o.y,
            height: o.height,
            layer: o.layer,
            datatype: o.datatype
          },
          currentId: r
        });
      }
      this.resultIds = [];
      for (const r of this.snapshots) {
        const o = n.library.text_to_polygons(r.currentId);
        this.resultIds.push(...o);
      }
      this.resultIds.length > 0 ? se.getState().selectAll(this.resultIds) : se.getState().clearSelection(), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      this.resultIds.length > 0 && (n.library.remove_elements(this.resultIds), this.resultIds = []);
      const r = [];
      for (const o of this.snapshots) {
        const i = o.snapshot, c = n.library.add_text(i.text, i.x, i.y, i.height, i.layer, i.datatype);
        c && (o.currentId = c, r.push(c));
      }
      r.length > 0 && se.getState().selectAll(r), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class U0 {
    constructor(n, r, o) {
      __publicField(this, "type", "align-elements");
      __publicField(this, "description");
      __publicField(this, "deltas", []);
      this.selectedIds = n, this.referenceId = r, this.alignType = o, this.description = `Align elements (${o})`;
    }
    execute(n) {
      this.deltas.length === 0 && (this.deltas = LS(n.library, this.selectedIds, this.referenceId, this.alignType));
      for (const r of this.deltas) n.library.translate_elements(r.ids, r.dx, r.dy);
      n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      for (let r = this.deltas.length - 1; r >= 0; r--) {
        const o = this.deltas[r];
        n.library.translate_elements(o.ids, -o.dx, -o.dy);
      }
      n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class Y0 {
    constructor(n, r, o) {
      __publicField(this, "type", "boolean-operation");
      __publicField(this, "description");
      __publicField(this, "snapshots", []);
      __publicField(this, "currentIds");
      __publicField(this, "currentBaseId");
      __publicField(this, "resultIds", []);
      this.operation = r, this.description = `Boolean ${r}`, this.currentIds = [
        ...n
      ], this.currentBaseId = o;
    }
    execute(n) {
      this.snapshots.length === 0 && (this.snapshots = xr(n.library, this.currentIds)), this.resultIds = n.library.boolean_operation(this.currentIds, this.operation, this.currentBaseId), this.resultIds.length > 0 ? se.getState().selectAll(this.resultIds) : se.getState().clearSelection(), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
    undo(n) {
      this.resultIds.length > 0 && n.library.remove_elements(this.resultIds);
      const r = us(n.library, this.snapshots), o = this.currentIds.indexOf(this.currentBaseId);
      this.currentIds = r, o >= 0 && o < r.length && (this.currentBaseId = r[o]), this.resultIds = [], se.getState().selectAll(r), n.renderer.sync_from_library(n.library), n.renderer.mark_dirty();
    }
  }
  class i2 {
    constructor(n) {
      __publicField(this, "type", "add-image");
      __publicField(this, "description", "Insert image");
      this.entry = n;
    }
    execute(n) {
      Bt.getState().addImage(this.entry), se.getState().select(ss(this.entry.id));
    }
    undo(n) {
      Bt.getState().removeImage(this.entry.id), se.getState().clearSelection();
    }
  }
  class B0 {
    constructor(n) {
      __publicField(this, "type", "remove-image");
      __publicField(this, "description", "Remove image");
      __publicField(this, "snapshots", []);
      __publicField(this, "imageIds");
      this.imageIds = Array.isArray(n) ? n : [
        n
      ];
    }
    execute(n) {
      const r = Bt.getState();
      if (this.snapshots.length === 0) for (const o of this.imageIds) {
        const i = r.images.get(o);
        i && this.snapshots.push(i);
      }
      for (const o of this.imageIds) Bt.getState().removeImage(o);
      se.getState().clearSelection();
    }
    undo(n) {
      const r = [];
      for (const o of this.snapshots) Bt.getState().addImage(o), r.push(ss(o.id));
      r.length > 0 && se.getState().selectAll(r);
    }
  }
  class c2 {
    constructor(n, r, o, i, c) {
      __publicField(this, "type", "move-image");
      __publicField(this, "description", "Move image");
      this.imageId = n, this.oldX = r, this.oldY = o, this.newX = i, this.newY = c;
    }
    execute(n) {
      Bt.getState().updateImage(this.imageId, {
        x: this.newX,
        y: this.newY
      });
    }
    undo(n) {
      Bt.getState().updateImage(this.imageId, {
        x: this.oldX,
        y: this.oldY
      });
    }
  }
  class u2 {
    constructor(n, r, o) {
      __publicField(this, "type", "move-images");
      __publicField(this, "description", "Move images");
      this.imageIds = n, this.deltaX = r, this.deltaY = o;
    }
    execute(n) {
      const r = Bt.getState();
      for (const o of this.imageIds) {
        const i = Gr(o), c = r.images.get(i);
        c && r.updateImage(i, {
          x: c.x + this.deltaX,
          y: c.y + this.deltaY
        });
      }
    }
    undo(n) {
      const r = Bt.getState();
      for (const o of this.imageIds) {
        const i = Gr(o), c = r.images.get(i);
        c && r.updateImage(i, {
          x: c.x - this.deltaX,
          y: c.y - this.deltaY
        });
      }
    }
  }
  class d2 {
    constructor(n, r, o, i, c) {
      __publicField(this, "type", "resize-image");
      __publicField(this, "description", "Resize image");
      this.imageId = n, this.oldWidth = r, this.oldHeight = o, this.newWidth = i, this.newHeight = c;
    }
    execute(n) {
      Bt.getState().updateImage(this.imageId, {
        width: this.newWidth,
        height: this.newHeight
      });
    }
    undo(n) {
      Bt.getState().updateImage(this.imageId, {
        width: this.oldWidth,
        height: this.oldHeight
      });
    }
  }
  const cn = _t()((l) => ({
    isOpen: false,
    initialSearch: "",
    open: (n) => l({
      isOpen: true,
      initialSearch: n ?? ""
    }),
    close: () => l({
      isOpen: false,
      initialSearch: ""
    }),
    toggle: () => l((n) => ({
      isOpen: !n.isOpen,
      initialSearch: ""
    }))
  })), Xf = _t()((l, n) => ({
    stack: [],
    claim: (r) => l((o) => ({
      stack: o.stack.includes(r) ? o.stack : [
        ...o.stack,
        r
      ]
    })),
    release: (r) => l((o) => ({
      stack: o.stack.filter((i) => i !== r)
    })),
    isCanvasActive: () => n().stack.length === 0
  })), nn = _t((l) => ({
    activeText: null,
    showCursor: true,
    isEditingText: false,
    startEditing: (n, r) => l({
      activeText: {
        x: n,
        y: r,
        content: "",
        cursorPosition: {
          line: 0,
          column: 0
        }
      },
      showCursor: true,
      isEditingText: true
    }),
    setActiveText: (n) => l({
      activeText: n,
      showCursor: true
    }),
    stopEditing: () => l({
      activeText: null,
      showCursor: true,
      isEditingText: false
    }),
    toggleCursor: () => l((n) => ({
      showCursor: !n.showCursor
    })),
    resetCursor: () => l({
      showCursor: true
    })
  }));
  function X0(l) {
    var n, r, o = "";
    if (typeof l == "string" || typeof l == "number") o += l;
    else if (typeof l == "object") if (Array.isArray(l)) {
      var i = l.length;
      for (n = 0; n < i; n++) l[n] && (r = X0(l[n])) && (o && (o += " "), o += r);
    } else for (r in l) l[r] && (o && (o += " "), o += r);
    return o;
  }
  function f2() {
    for (var l, n, r = 0, o = "", i = arguments.length; r < i; r++) (l = arguments[r]) && (n = X0(l)) && (o && (o += " "), o += n);
    return o;
  }
  const dh = "-", h2 = (l) => {
    const n = g2(l), { conflictingClassGroups: r, conflictingClassGroupModifiers: o } = l;
    return {
      getClassGroupId: (d) => {
        const f = d.split(dh);
        return f[0] === "" && f.length !== 1 && f.shift(), V0(f, n) || m2(d);
      },
      getConflictingClassGroupIds: (d, f) => {
        const g = r[d] || [];
        return f && o[d] ? [
          ...g,
          ...o[d]
        ] : g;
      }
    };
  }, V0 = (l, n) => {
    var _a;
    if (l.length === 0) return n.classGroupId;
    const r = l[0], o = n.nextPart.get(r), i = o ? V0(l.slice(1), o) : void 0;
    if (i) return i;
    if (n.validators.length === 0) return;
    const c = l.join(dh);
    return (_a = n.validators.find(({ validator: d }) => d(c))) == null ? void 0 : _a.classGroupId;
  }, Ry = /^\[(.+)\]$/, m2 = (l) => {
    if (Ry.test(l)) {
      const n = Ry.exec(l)[1], r = n == null ? void 0 : n.substring(0, n.indexOf(":"));
      if (r) return "arbitrary.." + r;
    }
  }, g2 = (l) => {
    const { theme: n, prefix: r } = l, o = {
      nextPart: /* @__PURE__ */ new Map(),
      validators: []
    };
    return y2(Object.entries(l.classGroups), r).forEach(([c, d]) => {
      Vf(d, o, c, n);
    }), o;
  }, Vf = (l, n, r, o) => {
    l.forEach((i) => {
      if (typeof i == "string") {
        const c = i === "" ? n : Ay(n, i);
        c.classGroupId = r;
        return;
      }
      if (typeof i == "function") {
        if (p2(i)) {
          Vf(i(o), n, r, o);
          return;
        }
        n.validators.push({
          validator: i,
          classGroupId: r
        });
        return;
      }
      Object.entries(i).forEach(([c, d]) => {
        Vf(d, Ay(n, c), r, o);
      });
    });
  }, Ay = (l, n) => {
    let r = l;
    return n.split(dh).forEach((o) => {
      r.nextPart.has(o) || r.nextPart.set(o, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      }), r = r.nextPart.get(o);
    }), r;
  }, p2 = (l) => l.isThemeGetter, y2 = (l, n) => n ? l.map(([r, o]) => {
    const i = o.map((c) => typeof c == "string" ? n + c : typeof c == "object" ? Object.fromEntries(Object.entries(c).map(([d, f]) => [
      n + d,
      f
    ])) : c);
    return [
      r,
      i
    ];
  }) : l, b2 = (l) => {
    if (l < 1) return {
      get: () => {
      },
      set: () => {
      }
    };
    let n = 0, r = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map();
    const i = (c, d) => {
      r.set(c, d), n++, n > l && (n = 0, o = r, r = /* @__PURE__ */ new Map());
    };
    return {
      get(c) {
        let d = r.get(c);
        if (d !== void 0) return d;
        if ((d = o.get(c)) !== void 0) return i(c, d), d;
      },
      set(c, d) {
        r.has(c) ? r.set(c, d) : i(c, d);
      }
    };
  }, $0 = "!", v2 = (l) => {
    const { separator: n, experimentalParseClassName: r } = l, o = n.length === 1, i = n[0], c = n.length, d = (f) => {
      const g = [];
      let p = 0, v = 0, b;
      for (let E = 0; E < f.length; E++) {
        let _ = f[E];
        if (p === 0) {
          if (_ === i && (o || f.slice(E, E + c) === n)) {
            g.push(f.slice(v, E)), v = E + c;
            continue;
          }
          if (_ === "/") {
            b = E;
            continue;
          }
        }
        _ === "[" ? p++ : _ === "]" && p--;
      }
      const S = g.length === 0 ? f : f.substring(v), C = S.startsWith($0), k = C ? S.substring(1) : S, x = b && b > v ? b - v : void 0;
      return {
        modifiers: g,
        hasImportantModifier: C,
        baseClassName: k,
        maybePostfixModifierPosition: x
      };
    };
    return r ? (f) => r({
      className: f,
      parseClassName: d
    }) : d;
  }, x2 = (l) => {
    if (l.length <= 1) return l;
    const n = [];
    let r = [];
    return l.forEach((o) => {
      o[0] === "[" ? (n.push(...r.sort(), o), r = []) : r.push(o);
    }), n.push(...r.sort()), n;
  }, w2 = (l) => ({
    cache: b2(l.cacheSize),
    parseClassName: v2(l),
    ...h2(l)
  }), S2 = /\s+/, C2 = (l, n) => {
    const { parseClassName: r, getClassGroupId: o, getConflictingClassGroupIds: i } = n, c = [], d = l.trim().split(S2);
    let f = "";
    for (let g = d.length - 1; g >= 0; g -= 1) {
      const p = d[g], { modifiers: v, hasImportantModifier: b, baseClassName: S, maybePostfixModifierPosition: C } = r(p);
      let k = !!C, x = o(k ? S.substring(0, C) : S);
      if (!x) {
        if (!k) {
          f = p + (f.length > 0 ? " " + f : f);
          continue;
        }
        if (x = o(S), !x) {
          f = p + (f.length > 0 ? " " + f : f);
          continue;
        }
        k = false;
      }
      const E = x2(v).join(":"), _ = b ? E + $0 : E, N = _ + x;
      if (c.includes(N)) continue;
      c.push(N);
      const A = i(x, k);
      for (let R = 0; R < A.length; ++R) {
        const I = A[R];
        c.push(_ + I);
      }
      f = p + (f.length > 0 ? " " + f : f);
    }
    return f;
  };
  function E2() {
    let l = 0, n, r, o = "";
    for (; l < arguments.length; ) (n = arguments[l++]) && (r = q0(n)) && (o && (o += " "), o += r);
    return o;
  }
  const q0 = (l) => {
    if (typeof l == "string") return l;
    let n, r = "";
    for (let o = 0; o < l.length; o++) l[o] && (n = q0(l[o])) && (r && (r += " "), r += n);
    return r;
  };
  function _2(l, ...n) {
    let r, o, i, c = d;
    function d(g) {
      const p = n.reduce((v, b) => b(v), l());
      return r = w2(p), o = r.cache.get, i = r.cache.set, c = f, f(g);
    }
    function f(g) {
      const p = o(g);
      if (p) return p;
      const v = C2(g, r);
      return i(g, v), v;
    }
    return function() {
      return c(E2.apply(null, arguments));
    };
  }
  const Ct = (l) => {
    const n = (r) => r[l] || [];
    return n.isThemeGetter = true, n;
  }, G0 = /^\[(?:([a-z-]+):)?(.+)\]$/i, k2 = /^\d+\/\d+$/, M2 = /* @__PURE__ */ new Set([
    "px",
    "full",
    "screen"
  ]), j2 = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/, L2 = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/, R2 = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/, A2 = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/, T2 = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/, Tl = (l) => $a(l) || M2.has(l) || k2.test(l), fr = (l) => Ga(l, "length", Y2), $a = (l) => !!l && !Number.isNaN(Number(l)), Xd = (l) => Ga(l, "number", $a), Xo = (l) => !!l && Number.isInteger(Number(l)), N2 = (l) => l.endsWith("%") && $a(l.slice(0, -1)), Be = (l) => G0.test(l), hr = (l) => j2.test(l), O2 = /* @__PURE__ */ new Set([
    "length",
    "size",
    "percentage"
  ]), I2 = (l) => Ga(l, O2, P0), D2 = (l) => Ga(l, "position", P0), z2 = /* @__PURE__ */ new Set([
    "image",
    "url"
  ]), H2 = (l) => Ga(l, z2, X2), U2 = (l) => Ga(l, "", B2), Vo = () => true, Ga = (l, n, r) => {
    const o = G0.exec(l);
    return o ? o[1] ? typeof n == "string" ? o[1] === n : n.has(o[1]) : r(o[2]) : false;
  }, Y2 = (l) => L2.test(l) && !R2.test(l), P0 = () => false, B2 = (l) => A2.test(l), X2 = (l) => T2.test(l), V2 = () => {
    const l = Ct("colors"), n = Ct("spacing"), r = Ct("blur"), o = Ct("brightness"), i = Ct("borderColor"), c = Ct("borderRadius"), d = Ct("borderSpacing"), f = Ct("borderWidth"), g = Ct("contrast"), p = Ct("grayscale"), v = Ct("hueRotate"), b = Ct("invert"), S = Ct("gap"), C = Ct("gradientColorStops"), k = Ct("gradientColorStopPositions"), x = Ct("inset"), E = Ct("margin"), _ = Ct("opacity"), N = Ct("padding"), A = Ct("saturate"), R = Ct("scale"), I = Ct("sepia"), T = Ct("skew"), L = Ct("space"), D = Ct("translate"), H = () => [
      "auto",
      "contain",
      "none"
    ], q = () => [
      "auto",
      "hidden",
      "clip",
      "visible",
      "scroll"
    ], re = () => [
      "auto",
      Be,
      n
    ], ee = () => [
      Be,
      n
    ], de = () => [
      "",
      Tl,
      fr
    ], ge = () => [
      "auto",
      $a,
      Be
    ], Ee = () => [
      "bottom",
      "center",
      "left",
      "left-bottom",
      "left-top",
      "right",
      "right-bottom",
      "right-top",
      "top"
    ], $ = () => [
      "solid",
      "dashed",
      "dotted",
      "double",
      "none"
    ], F = () => [
      "normal",
      "multiply",
      "screen",
      "overlay",
      "darken",
      "lighten",
      "color-dodge",
      "color-burn",
      "hard-light",
      "soft-light",
      "difference",
      "exclusion",
      "hue",
      "saturation",
      "color",
      "luminosity"
    ], fe = () => [
      "start",
      "end",
      "center",
      "between",
      "around",
      "evenly",
      "stretch"
    ], ye = () => [
      "",
      "0",
      Be
    ], ke = () => [
      "auto",
      "avoid",
      "all",
      "avoid-page",
      "page",
      "left",
      "right",
      "column"
    ], j = () => [
      $a,
      Be
    ];
    return {
      cacheSize: 500,
      separator: ":",
      theme: {
        colors: [
          Vo
        ],
        spacing: [
          Tl,
          fr
        ],
        blur: [
          "none",
          "",
          hr,
          Be
        ],
        brightness: j(),
        borderColor: [
          l
        ],
        borderRadius: [
          "none",
          "",
          "full",
          hr,
          Be
        ],
        borderSpacing: ee(),
        borderWidth: de(),
        contrast: j(),
        grayscale: ye(),
        hueRotate: j(),
        invert: ye(),
        gap: ee(),
        gradientColorStops: [
          l
        ],
        gradientColorStopPositions: [
          N2,
          fr
        ],
        inset: re(),
        margin: re(),
        opacity: j(),
        padding: ee(),
        saturate: j(),
        scale: j(),
        sepia: ye(),
        skew: j(),
        space: ee(),
        translate: ee()
      },
      classGroups: {
        aspect: [
          {
            aspect: [
              "auto",
              "square",
              "video",
              Be
            ]
          }
        ],
        container: [
          "container"
        ],
        columns: [
          {
            columns: [
              hr
            ]
          }
        ],
        "break-after": [
          {
            "break-after": ke()
          }
        ],
        "break-before": [
          {
            "break-before": ke()
          }
        ],
        "break-inside": [
          {
            "break-inside": [
              "auto",
              "avoid",
              "avoid-page",
              "avoid-column"
            ]
          }
        ],
        "box-decoration": [
          {
            "box-decoration": [
              "slice",
              "clone"
            ]
          }
        ],
        box: [
          {
            box: [
              "border",
              "content"
            ]
          }
        ],
        display: [
          "block",
          "inline-block",
          "inline",
          "flex",
          "inline-flex",
          "table",
          "inline-table",
          "table-caption",
          "table-cell",
          "table-column",
          "table-column-group",
          "table-footer-group",
          "table-header-group",
          "table-row-group",
          "table-row",
          "flow-root",
          "grid",
          "inline-grid",
          "contents",
          "list-item",
          "hidden"
        ],
        float: [
          {
            float: [
              "right",
              "left",
              "none",
              "start",
              "end"
            ]
          }
        ],
        clear: [
          {
            clear: [
              "left",
              "right",
              "both",
              "none",
              "start",
              "end"
            ]
          }
        ],
        isolation: [
          "isolate",
          "isolation-auto"
        ],
        "object-fit": [
          {
            object: [
              "contain",
              "cover",
              "fill",
              "none",
              "scale-down"
            ]
          }
        ],
        "object-position": [
          {
            object: [
              ...Ee(),
              Be
            ]
          }
        ],
        overflow: [
          {
            overflow: q()
          }
        ],
        "overflow-x": [
          {
            "overflow-x": q()
          }
        ],
        "overflow-y": [
          {
            "overflow-y": q()
          }
        ],
        overscroll: [
          {
            overscroll: H()
          }
        ],
        "overscroll-x": [
          {
            "overscroll-x": H()
          }
        ],
        "overscroll-y": [
          {
            "overscroll-y": H()
          }
        ],
        position: [
          "static",
          "fixed",
          "absolute",
          "relative",
          "sticky"
        ],
        inset: [
          {
            inset: [
              x
            ]
          }
        ],
        "inset-x": [
          {
            "inset-x": [
              x
            ]
          }
        ],
        "inset-y": [
          {
            "inset-y": [
              x
            ]
          }
        ],
        start: [
          {
            start: [
              x
            ]
          }
        ],
        end: [
          {
            end: [
              x
            ]
          }
        ],
        top: [
          {
            top: [
              x
            ]
          }
        ],
        right: [
          {
            right: [
              x
            ]
          }
        ],
        bottom: [
          {
            bottom: [
              x
            ]
          }
        ],
        left: [
          {
            left: [
              x
            ]
          }
        ],
        visibility: [
          "visible",
          "invisible",
          "collapse"
        ],
        z: [
          {
            z: [
              "auto",
              Xo,
              Be
            ]
          }
        ],
        basis: [
          {
            basis: re()
          }
        ],
        "flex-direction": [
          {
            flex: [
              "row",
              "row-reverse",
              "col",
              "col-reverse"
            ]
          }
        ],
        "flex-wrap": [
          {
            flex: [
              "wrap",
              "wrap-reverse",
              "nowrap"
            ]
          }
        ],
        flex: [
          {
            flex: [
              "1",
              "auto",
              "initial",
              "none",
              Be
            ]
          }
        ],
        grow: [
          {
            grow: ye()
          }
        ],
        shrink: [
          {
            shrink: ye()
          }
        ],
        order: [
          {
            order: [
              "first",
              "last",
              "none",
              Xo,
              Be
            ]
          }
        ],
        "grid-cols": [
          {
            "grid-cols": [
              Vo
            ]
          }
        ],
        "col-start-end": [
          {
            col: [
              "auto",
              {
                span: [
                  "full",
                  Xo,
                  Be
                ]
              },
              Be
            ]
          }
        ],
        "col-start": [
          {
            "col-start": ge()
          }
        ],
        "col-end": [
          {
            "col-end": ge()
          }
        ],
        "grid-rows": [
          {
            "grid-rows": [
              Vo
            ]
          }
        ],
        "row-start-end": [
          {
            row: [
              "auto",
              {
                span: [
                  Xo,
                  Be
                ]
              },
              Be
            ]
          }
        ],
        "row-start": [
          {
            "row-start": ge()
          }
        ],
        "row-end": [
          {
            "row-end": ge()
          }
        ],
        "grid-flow": [
          {
            "grid-flow": [
              "row",
              "col",
              "dense",
              "row-dense",
              "col-dense"
            ]
          }
        ],
        "auto-cols": [
          {
            "auto-cols": [
              "auto",
              "min",
              "max",
              "fr",
              Be
            ]
          }
        ],
        "auto-rows": [
          {
            "auto-rows": [
              "auto",
              "min",
              "max",
              "fr",
              Be
            ]
          }
        ],
        gap: [
          {
            gap: [
              S
            ]
          }
        ],
        "gap-x": [
          {
            "gap-x": [
              S
            ]
          }
        ],
        "gap-y": [
          {
            "gap-y": [
              S
            ]
          }
        ],
        "justify-content": [
          {
            justify: [
              "normal",
              ...fe()
            ]
          }
        ],
        "justify-items": [
          {
            "justify-items": [
              "start",
              "end",
              "center",
              "stretch"
            ]
          }
        ],
        "justify-self": [
          {
            "justify-self": [
              "auto",
              "start",
              "end",
              "center",
              "stretch"
            ]
          }
        ],
        "align-content": [
          {
            content: [
              "normal",
              ...fe(),
              "baseline"
            ]
          }
        ],
        "align-items": [
          {
            items: [
              "start",
              "end",
              "center",
              "baseline",
              "stretch"
            ]
          }
        ],
        "align-self": [
          {
            self: [
              "auto",
              "start",
              "end",
              "center",
              "stretch",
              "baseline"
            ]
          }
        ],
        "place-content": [
          {
            "place-content": [
              ...fe(),
              "baseline"
            ]
          }
        ],
        "place-items": [
          {
            "place-items": [
              "start",
              "end",
              "center",
              "baseline",
              "stretch"
            ]
          }
        ],
        "place-self": [
          {
            "place-self": [
              "auto",
              "start",
              "end",
              "center",
              "stretch"
            ]
          }
        ],
        p: [
          {
            p: [
              N
            ]
          }
        ],
        px: [
          {
            px: [
              N
            ]
          }
        ],
        py: [
          {
            py: [
              N
            ]
          }
        ],
        ps: [
          {
            ps: [
              N
            ]
          }
        ],
        pe: [
          {
            pe: [
              N
            ]
          }
        ],
        pt: [
          {
            pt: [
              N
            ]
          }
        ],
        pr: [
          {
            pr: [
              N
            ]
          }
        ],
        pb: [
          {
            pb: [
              N
            ]
          }
        ],
        pl: [
          {
            pl: [
              N
            ]
          }
        ],
        m: [
          {
            m: [
              E
            ]
          }
        ],
        mx: [
          {
            mx: [
              E
            ]
          }
        ],
        my: [
          {
            my: [
              E
            ]
          }
        ],
        ms: [
          {
            ms: [
              E
            ]
          }
        ],
        me: [
          {
            me: [
              E
            ]
          }
        ],
        mt: [
          {
            mt: [
              E
            ]
          }
        ],
        mr: [
          {
            mr: [
              E
            ]
          }
        ],
        mb: [
          {
            mb: [
              E
            ]
          }
        ],
        ml: [
          {
            ml: [
              E
            ]
          }
        ],
        "space-x": [
          {
            "space-x": [
              L
            ]
          }
        ],
        "space-x-reverse": [
          "space-x-reverse"
        ],
        "space-y": [
          {
            "space-y": [
              L
            ]
          }
        ],
        "space-y-reverse": [
          "space-y-reverse"
        ],
        w: [
          {
            w: [
              "auto",
              "min",
              "max",
              "fit",
              "svw",
              "lvw",
              "dvw",
              Be,
              n
            ]
          }
        ],
        "min-w": [
          {
            "min-w": [
              Be,
              n,
              "min",
              "max",
              "fit"
            ]
          }
        ],
        "max-w": [
          {
            "max-w": [
              Be,
              n,
              "none",
              "full",
              "min",
              "max",
              "fit",
              "prose",
              {
                screen: [
                  hr
                ]
              },
              hr
            ]
          }
        ],
        h: [
          {
            h: [
              Be,
              n,
              "auto",
              "min",
              "max",
              "fit",
              "svh",
              "lvh",
              "dvh"
            ]
          }
        ],
        "min-h": [
          {
            "min-h": [
              Be,
              n,
              "min",
              "max",
              "fit",
              "svh",
              "lvh",
              "dvh"
            ]
          }
        ],
        "max-h": [
          {
            "max-h": [
              Be,
              n,
              "min",
              "max",
              "fit",
              "svh",
              "lvh",
              "dvh"
            ]
          }
        ],
        size: [
          {
            size: [
              Be,
              n,
              "auto",
              "min",
              "max",
              "fit"
            ]
          }
        ],
        "font-size": [
          {
            text: [
              "base",
              hr,
              fr
            ]
          }
        ],
        "font-smoothing": [
          "antialiased",
          "subpixel-antialiased"
        ],
        "font-style": [
          "italic",
          "not-italic"
        ],
        "font-weight": [
          {
            font: [
              "thin",
              "extralight",
              "light",
              "normal",
              "medium",
              "semibold",
              "bold",
              "extrabold",
              "black",
              Xd
            ]
          }
        ],
        "font-family": [
          {
            font: [
              Vo
            ]
          }
        ],
        "fvn-normal": [
          "normal-nums"
        ],
        "fvn-ordinal": [
          "ordinal"
        ],
        "fvn-slashed-zero": [
          "slashed-zero"
        ],
        "fvn-figure": [
          "lining-nums",
          "oldstyle-nums"
        ],
        "fvn-spacing": [
          "proportional-nums",
          "tabular-nums"
        ],
        "fvn-fraction": [
          "diagonal-fractions",
          "stacked-fractions"
        ],
        tracking: [
          {
            tracking: [
              "tighter",
              "tight",
              "normal",
              "wide",
              "wider",
              "widest",
              Be
            ]
          }
        ],
        "line-clamp": [
          {
            "line-clamp": [
              "none",
              $a,
              Xd
            ]
          }
        ],
        leading: [
          {
            leading: [
              "none",
              "tight",
              "snug",
              "normal",
              "relaxed",
              "loose",
              Tl,
              Be
            ]
          }
        ],
        "list-image": [
          {
            "list-image": [
              "none",
              Be
            ]
          }
        ],
        "list-style-type": [
          {
            list: [
              "none",
              "disc",
              "decimal",
              Be
            ]
          }
        ],
        "list-style-position": [
          {
            list: [
              "inside",
              "outside"
            ]
          }
        ],
        "placeholder-color": [
          {
            placeholder: [
              l
            ]
          }
        ],
        "placeholder-opacity": [
          {
            "placeholder-opacity": [
              _
            ]
          }
        ],
        "text-alignment": [
          {
            text: [
              "left",
              "center",
              "right",
              "justify",
              "start",
              "end"
            ]
          }
        ],
        "text-color": [
          {
            text: [
              l
            ]
          }
        ],
        "text-opacity": [
          {
            "text-opacity": [
              _
            ]
          }
        ],
        "text-decoration": [
          "underline",
          "overline",
          "line-through",
          "no-underline"
        ],
        "text-decoration-style": [
          {
            decoration: [
              ...$(),
              "wavy"
            ]
          }
        ],
        "text-decoration-thickness": [
          {
            decoration: [
              "auto",
              "from-font",
              Tl,
              fr
            ]
          }
        ],
        "underline-offset": [
          {
            "underline-offset": [
              "auto",
              Tl,
              Be
            ]
          }
        ],
        "text-decoration-color": [
          {
            decoration: [
              l
            ]
          }
        ],
        "text-transform": [
          "uppercase",
          "lowercase",
          "capitalize",
          "normal-case"
        ],
        "text-overflow": [
          "truncate",
          "text-ellipsis",
          "text-clip"
        ],
        "text-wrap": [
          {
            text: [
              "wrap",
              "nowrap",
              "balance",
              "pretty"
            ]
          }
        ],
        indent: [
          {
            indent: ee()
          }
        ],
        "vertical-align": [
          {
            align: [
              "baseline",
              "top",
              "middle",
              "bottom",
              "text-top",
              "text-bottom",
              "sub",
              "super",
              Be
            ]
          }
        ],
        whitespace: [
          {
            whitespace: [
              "normal",
              "nowrap",
              "pre",
              "pre-line",
              "pre-wrap",
              "break-spaces"
            ]
          }
        ],
        break: [
          {
            break: [
              "normal",
              "words",
              "all",
              "keep"
            ]
          }
        ],
        hyphens: [
          {
            hyphens: [
              "none",
              "manual",
              "auto"
            ]
          }
        ],
        content: [
          {
            content: [
              "none",
              Be
            ]
          }
        ],
        "bg-attachment": [
          {
            bg: [
              "fixed",
              "local",
              "scroll"
            ]
          }
        ],
        "bg-clip": [
          {
            "bg-clip": [
              "border",
              "padding",
              "content",
              "text"
            ]
          }
        ],
        "bg-opacity": [
          {
            "bg-opacity": [
              _
            ]
          }
        ],
        "bg-origin": [
          {
            "bg-origin": [
              "border",
              "padding",
              "content"
            ]
          }
        ],
        "bg-position": [
          {
            bg: [
              ...Ee(),
              D2
            ]
          }
        ],
        "bg-repeat": [
          {
            bg: [
              "no-repeat",
              {
                repeat: [
                  "",
                  "x",
                  "y",
                  "round",
                  "space"
                ]
              }
            ]
          }
        ],
        "bg-size": [
          {
            bg: [
              "auto",
              "cover",
              "contain",
              I2
            ]
          }
        ],
        "bg-image": [
          {
            bg: [
              "none",
              {
                "gradient-to": [
                  "t",
                  "tr",
                  "r",
                  "br",
                  "b",
                  "bl",
                  "l",
                  "tl"
                ]
              },
              H2
            ]
          }
        ],
        "bg-color": [
          {
            bg: [
              l
            ]
          }
        ],
        "gradient-from-pos": [
          {
            from: [
              k
            ]
          }
        ],
        "gradient-via-pos": [
          {
            via: [
              k
            ]
          }
        ],
        "gradient-to-pos": [
          {
            to: [
              k
            ]
          }
        ],
        "gradient-from": [
          {
            from: [
              C
            ]
          }
        ],
        "gradient-via": [
          {
            via: [
              C
            ]
          }
        ],
        "gradient-to": [
          {
            to: [
              C
            ]
          }
        ],
        rounded: [
          {
            rounded: [
              c
            ]
          }
        ],
        "rounded-s": [
          {
            "rounded-s": [
              c
            ]
          }
        ],
        "rounded-e": [
          {
            "rounded-e": [
              c
            ]
          }
        ],
        "rounded-t": [
          {
            "rounded-t": [
              c
            ]
          }
        ],
        "rounded-r": [
          {
            "rounded-r": [
              c
            ]
          }
        ],
        "rounded-b": [
          {
            "rounded-b": [
              c
            ]
          }
        ],
        "rounded-l": [
          {
            "rounded-l": [
              c
            ]
          }
        ],
        "rounded-ss": [
          {
            "rounded-ss": [
              c
            ]
          }
        ],
        "rounded-se": [
          {
            "rounded-se": [
              c
            ]
          }
        ],
        "rounded-ee": [
          {
            "rounded-ee": [
              c
            ]
          }
        ],
        "rounded-es": [
          {
            "rounded-es": [
              c
            ]
          }
        ],
        "rounded-tl": [
          {
            "rounded-tl": [
              c
            ]
          }
        ],
        "rounded-tr": [
          {
            "rounded-tr": [
              c
            ]
          }
        ],
        "rounded-br": [
          {
            "rounded-br": [
              c
            ]
          }
        ],
        "rounded-bl": [
          {
            "rounded-bl": [
              c
            ]
          }
        ],
        "border-w": [
          {
            border: [
              f
            ]
          }
        ],
        "border-w-x": [
          {
            "border-x": [
              f
            ]
          }
        ],
        "border-w-y": [
          {
            "border-y": [
              f
            ]
          }
        ],
        "border-w-s": [
          {
            "border-s": [
              f
            ]
          }
        ],
        "border-w-e": [
          {
            "border-e": [
              f
            ]
          }
        ],
        "border-w-t": [
          {
            "border-t": [
              f
            ]
          }
        ],
        "border-w-r": [
          {
            "border-r": [
              f
            ]
          }
        ],
        "border-w-b": [
          {
            "border-b": [
              f
            ]
          }
        ],
        "border-w-l": [
          {
            "border-l": [
              f
            ]
          }
        ],
        "border-opacity": [
          {
            "border-opacity": [
              _
            ]
          }
        ],
        "border-style": [
          {
            border: [
              ...$(),
              "hidden"
            ]
          }
        ],
        "divide-x": [
          {
            "divide-x": [
              f
            ]
          }
        ],
        "divide-x-reverse": [
          "divide-x-reverse"
        ],
        "divide-y": [
          {
            "divide-y": [
              f
            ]
          }
        ],
        "divide-y-reverse": [
          "divide-y-reverse"
        ],
        "divide-opacity": [
          {
            "divide-opacity": [
              _
            ]
          }
        ],
        "divide-style": [
          {
            divide: $()
          }
        ],
        "border-color": [
          {
            border: [
              i
            ]
          }
        ],
        "border-color-x": [
          {
            "border-x": [
              i
            ]
          }
        ],
        "border-color-y": [
          {
            "border-y": [
              i
            ]
          }
        ],
        "border-color-s": [
          {
            "border-s": [
              i
            ]
          }
        ],
        "border-color-e": [
          {
            "border-e": [
              i
            ]
          }
        ],
        "border-color-t": [
          {
            "border-t": [
              i
            ]
          }
        ],
        "border-color-r": [
          {
            "border-r": [
              i
            ]
          }
        ],
        "border-color-b": [
          {
            "border-b": [
              i
            ]
          }
        ],
        "border-color-l": [
          {
            "border-l": [
              i
            ]
          }
        ],
        "divide-color": [
          {
            divide: [
              i
            ]
          }
        ],
        "outline-style": [
          {
            outline: [
              "",
              ...$()
            ]
          }
        ],
        "outline-offset": [
          {
            "outline-offset": [
              Tl,
              Be
            ]
          }
        ],
        "outline-w": [
          {
            outline: [
              Tl,
              fr
            ]
          }
        ],
        "outline-color": [
          {
            outline: [
              l
            ]
          }
        ],
        "ring-w": [
          {
            ring: de()
          }
        ],
        "ring-w-inset": [
          "ring-inset"
        ],
        "ring-color": [
          {
            ring: [
              l
            ]
          }
        ],
        "ring-opacity": [
          {
            "ring-opacity": [
              _
            ]
          }
        ],
        "ring-offset-w": [
          {
            "ring-offset": [
              Tl,
              fr
            ]
          }
        ],
        "ring-offset-color": [
          {
            "ring-offset": [
              l
            ]
          }
        ],
        shadow: [
          {
            shadow: [
              "",
              "inner",
              "none",
              hr,
              U2
            ]
          }
        ],
        "shadow-color": [
          {
            shadow: [
              Vo
            ]
          }
        ],
        opacity: [
          {
            opacity: [
              _
            ]
          }
        ],
        "mix-blend": [
          {
            "mix-blend": [
              ...F(),
              "plus-lighter",
              "plus-darker"
            ]
          }
        ],
        "bg-blend": [
          {
            "bg-blend": F()
          }
        ],
        filter: [
          {
            filter: [
              "",
              "none"
            ]
          }
        ],
        blur: [
          {
            blur: [
              r
            ]
          }
        ],
        brightness: [
          {
            brightness: [
              o
            ]
          }
        ],
        contrast: [
          {
            contrast: [
              g
            ]
          }
        ],
        "drop-shadow": [
          {
            "drop-shadow": [
              "",
              "none",
              hr,
              Be
            ]
          }
        ],
        grayscale: [
          {
            grayscale: [
              p
            ]
          }
        ],
        "hue-rotate": [
          {
            "hue-rotate": [
              v
            ]
          }
        ],
        invert: [
          {
            invert: [
              b
            ]
          }
        ],
        saturate: [
          {
            saturate: [
              A
            ]
          }
        ],
        sepia: [
          {
            sepia: [
              I
            ]
          }
        ],
        "backdrop-filter": [
          {
            "backdrop-filter": [
              "",
              "none"
            ]
          }
        ],
        "backdrop-blur": [
          {
            "backdrop-blur": [
              r
            ]
          }
        ],
        "backdrop-brightness": [
          {
            "backdrop-brightness": [
              o
            ]
          }
        ],
        "backdrop-contrast": [
          {
            "backdrop-contrast": [
              g
            ]
          }
        ],
        "backdrop-grayscale": [
          {
            "backdrop-grayscale": [
              p
            ]
          }
        ],
        "backdrop-hue-rotate": [
          {
            "backdrop-hue-rotate": [
              v
            ]
          }
        ],
        "backdrop-invert": [
          {
            "backdrop-invert": [
              b
            ]
          }
        ],
        "backdrop-opacity": [
          {
            "backdrop-opacity": [
              _
            ]
          }
        ],
        "backdrop-saturate": [
          {
            "backdrop-saturate": [
              A
            ]
          }
        ],
        "backdrop-sepia": [
          {
            "backdrop-sepia": [
              I
            ]
          }
        ],
        "border-collapse": [
          {
            border: [
              "collapse",
              "separate"
            ]
          }
        ],
        "border-spacing": [
          {
            "border-spacing": [
              d
            ]
          }
        ],
        "border-spacing-x": [
          {
            "border-spacing-x": [
              d
            ]
          }
        ],
        "border-spacing-y": [
          {
            "border-spacing-y": [
              d
            ]
          }
        ],
        "table-layout": [
          {
            table: [
              "auto",
              "fixed"
            ]
          }
        ],
        caption: [
          {
            caption: [
              "top",
              "bottom"
            ]
          }
        ],
        transition: [
          {
            transition: [
              "none",
              "all",
              "",
              "colors",
              "opacity",
              "shadow",
              "transform",
              Be
            ]
          }
        ],
        duration: [
          {
            duration: j()
          }
        ],
        ease: [
          {
            ease: [
              "linear",
              "in",
              "out",
              "in-out",
              Be
            ]
          }
        ],
        delay: [
          {
            delay: j()
          }
        ],
        animate: [
          {
            animate: [
              "none",
              "spin",
              "ping",
              "pulse",
              "bounce",
              Be
            ]
          }
        ],
        transform: [
          {
            transform: [
              "",
              "gpu",
              "none"
            ]
          }
        ],
        scale: [
          {
            scale: [
              R
            ]
          }
        ],
        "scale-x": [
          {
            "scale-x": [
              R
            ]
          }
        ],
        "scale-y": [
          {
            "scale-y": [
              R
            ]
          }
        ],
        rotate: [
          {
            rotate: [
              Xo,
              Be
            ]
          }
        ],
        "translate-x": [
          {
            "translate-x": [
              D
            ]
          }
        ],
        "translate-y": [
          {
            "translate-y": [
              D
            ]
          }
        ],
        "skew-x": [
          {
            "skew-x": [
              T
            ]
          }
        ],
        "skew-y": [
          {
            "skew-y": [
              T
            ]
          }
        ],
        "transform-origin": [
          {
            origin: [
              "center",
              "top",
              "top-right",
              "right",
              "bottom-right",
              "bottom",
              "bottom-left",
              "left",
              "top-left",
              Be
            ]
          }
        ],
        accent: [
          {
            accent: [
              "auto",
              l
            ]
          }
        ],
        appearance: [
          {
            appearance: [
              "none",
              "auto"
            ]
          }
        ],
        cursor: [
          {
            cursor: [
              "auto",
              "default",
              "pointer",
              "wait",
              "text",
              "move",
              "help",
              "not-allowed",
              "none",
              "context-menu",
              "progress",
              "cell",
              "crosshair",
              "vertical-text",
              "alias",
              "copy",
              "no-drop",
              "grab",
              "grabbing",
              "all-scroll",
              "col-resize",
              "row-resize",
              "n-resize",
              "e-resize",
              "s-resize",
              "w-resize",
              "ne-resize",
              "nw-resize",
              "se-resize",
              "sw-resize",
              "ew-resize",
              "ns-resize",
              "nesw-resize",
              "nwse-resize",
              "zoom-in",
              "zoom-out",
              Be
            ]
          }
        ],
        "caret-color": [
          {
            caret: [
              l
            ]
          }
        ],
        "pointer-events": [
          {
            "pointer-events": [
              "none",
              "auto"
            ]
          }
        ],
        resize: [
          {
            resize: [
              "none",
              "y",
              "x",
              ""
            ]
          }
        ],
        "scroll-behavior": [
          {
            scroll: [
              "auto",
              "smooth"
            ]
          }
        ],
        "scroll-m": [
          {
            "scroll-m": ee()
          }
        ],
        "scroll-mx": [
          {
            "scroll-mx": ee()
          }
        ],
        "scroll-my": [
          {
            "scroll-my": ee()
          }
        ],
        "scroll-ms": [
          {
            "scroll-ms": ee()
          }
        ],
        "scroll-me": [
          {
            "scroll-me": ee()
          }
        ],
        "scroll-mt": [
          {
            "scroll-mt": ee()
          }
        ],
        "scroll-mr": [
          {
            "scroll-mr": ee()
          }
        ],
        "scroll-mb": [
          {
            "scroll-mb": ee()
          }
        ],
        "scroll-ml": [
          {
            "scroll-ml": ee()
          }
        ],
        "scroll-p": [
          {
            "scroll-p": ee()
          }
        ],
        "scroll-px": [
          {
            "scroll-px": ee()
          }
        ],
        "scroll-py": [
          {
            "scroll-py": ee()
          }
        ],
        "scroll-ps": [
          {
            "scroll-ps": ee()
          }
        ],
        "scroll-pe": [
          {
            "scroll-pe": ee()
          }
        ],
        "scroll-pt": [
          {
            "scroll-pt": ee()
          }
        ],
        "scroll-pr": [
          {
            "scroll-pr": ee()
          }
        ],
        "scroll-pb": [
          {
            "scroll-pb": ee()
          }
        ],
        "scroll-pl": [
          {
            "scroll-pl": ee()
          }
        ],
        "snap-align": [
          {
            snap: [
              "start",
              "end",
              "center",
              "align-none"
            ]
          }
        ],
        "snap-stop": [
          {
            snap: [
              "normal",
              "always"
            ]
          }
        ],
        "snap-type": [
          {
            snap: [
              "none",
              "x",
              "y",
              "both"
            ]
          }
        ],
        "snap-strictness": [
          {
            snap: [
              "mandatory",
              "proximity"
            ]
          }
        ],
        touch: [
          {
            touch: [
              "auto",
              "none",
              "manipulation"
            ]
          }
        ],
        "touch-x": [
          {
            "touch-pan": [
              "x",
              "left",
              "right"
            ]
          }
        ],
        "touch-y": [
          {
            "touch-pan": [
              "y",
              "up",
              "down"
            ]
          }
        ],
        "touch-pz": [
          "touch-pinch-zoom"
        ],
        select: [
          {
            select: [
              "none",
              "text",
              "all",
              "auto"
            ]
          }
        ],
        "will-change": [
          {
            "will-change": [
              "auto",
              "scroll",
              "contents",
              "transform",
              Be
            ]
          }
        ],
        fill: [
          {
            fill: [
              l,
              "none"
            ]
          }
        ],
        "stroke-w": [
          {
            stroke: [
              Tl,
              fr,
              Xd
            ]
          }
        ],
        stroke: [
          {
            stroke: [
              l,
              "none"
            ]
          }
        ],
        sr: [
          "sr-only",
          "not-sr-only"
        ],
        "forced-color-adjust": [
          {
            "forced-color-adjust": [
              "auto",
              "none"
            ]
          }
        ]
      },
      conflictingClassGroups: {
        overflow: [
          "overflow-x",
          "overflow-y"
        ],
        overscroll: [
          "overscroll-x",
          "overscroll-y"
        ],
        inset: [
          "inset-x",
          "inset-y",
          "start",
          "end",
          "top",
          "right",
          "bottom",
          "left"
        ],
        "inset-x": [
          "right",
          "left"
        ],
        "inset-y": [
          "top",
          "bottom"
        ],
        flex: [
          "basis",
          "grow",
          "shrink"
        ],
        gap: [
          "gap-x",
          "gap-y"
        ],
        p: [
          "px",
          "py",
          "ps",
          "pe",
          "pt",
          "pr",
          "pb",
          "pl"
        ],
        px: [
          "pr",
          "pl"
        ],
        py: [
          "pt",
          "pb"
        ],
        m: [
          "mx",
          "my",
          "ms",
          "me",
          "mt",
          "mr",
          "mb",
          "ml"
        ],
        mx: [
          "mr",
          "ml"
        ],
        my: [
          "mt",
          "mb"
        ],
        size: [
          "w",
          "h"
        ],
        "font-size": [
          "leading"
        ],
        "fvn-normal": [
          "fvn-ordinal",
          "fvn-slashed-zero",
          "fvn-figure",
          "fvn-spacing",
          "fvn-fraction"
        ],
        "fvn-ordinal": [
          "fvn-normal"
        ],
        "fvn-slashed-zero": [
          "fvn-normal"
        ],
        "fvn-figure": [
          "fvn-normal"
        ],
        "fvn-spacing": [
          "fvn-normal"
        ],
        "fvn-fraction": [
          "fvn-normal"
        ],
        "line-clamp": [
          "display",
          "overflow"
        ],
        rounded: [
          "rounded-s",
          "rounded-e",
          "rounded-t",
          "rounded-r",
          "rounded-b",
          "rounded-l",
          "rounded-ss",
          "rounded-se",
          "rounded-ee",
          "rounded-es",
          "rounded-tl",
          "rounded-tr",
          "rounded-br",
          "rounded-bl"
        ],
        "rounded-s": [
          "rounded-ss",
          "rounded-es"
        ],
        "rounded-e": [
          "rounded-se",
          "rounded-ee"
        ],
        "rounded-t": [
          "rounded-tl",
          "rounded-tr"
        ],
        "rounded-r": [
          "rounded-tr",
          "rounded-br"
        ],
        "rounded-b": [
          "rounded-br",
          "rounded-bl"
        ],
        "rounded-l": [
          "rounded-tl",
          "rounded-bl"
        ],
        "border-spacing": [
          "border-spacing-x",
          "border-spacing-y"
        ],
        "border-w": [
          "border-w-s",
          "border-w-e",
          "border-w-t",
          "border-w-r",
          "border-w-b",
          "border-w-l"
        ],
        "border-w-x": [
          "border-w-r",
          "border-w-l"
        ],
        "border-w-y": [
          "border-w-t",
          "border-w-b"
        ],
        "border-color": [
          "border-color-s",
          "border-color-e",
          "border-color-t",
          "border-color-r",
          "border-color-b",
          "border-color-l"
        ],
        "border-color-x": [
          "border-color-r",
          "border-color-l"
        ],
        "border-color-y": [
          "border-color-t",
          "border-color-b"
        ],
        "scroll-m": [
          "scroll-mx",
          "scroll-my",
          "scroll-ms",
          "scroll-me",
          "scroll-mt",
          "scroll-mr",
          "scroll-mb",
          "scroll-ml"
        ],
        "scroll-mx": [
          "scroll-mr",
          "scroll-ml"
        ],
        "scroll-my": [
          "scroll-mt",
          "scroll-mb"
        ],
        "scroll-p": [
          "scroll-px",
          "scroll-py",
          "scroll-ps",
          "scroll-pe",
          "scroll-pt",
          "scroll-pr",
          "scroll-pb",
          "scroll-pl"
        ],
        "scroll-px": [
          "scroll-pr",
          "scroll-pl"
        ],
        "scroll-py": [
          "scroll-pt",
          "scroll-pb"
        ],
        touch: [
          "touch-x",
          "touch-y",
          "touch-pz"
        ],
        "touch-x": [
          "touch"
        ],
        "touch-y": [
          "touch"
        ],
        "touch-pz": [
          "touch"
        ]
      },
      conflictingClassGroupModifiers: {
        "font-size": [
          "leading"
        ]
      }
    };
  }, $2 = _2(V2);
  function Y(...l) {
    return $2(f2(l));
  }
  const Ty = 38, Ti = 16;
  function Zr(l) {
    const n = l.getBoundingClientRect(), { zenMode: r, explorerCollapsed: o, sidebarCollapsed: i, explorerWidth: c, sidebarWidth: d } = me.getState();
    let f = 0, g = 0;
    r || (f = o ? Ty + Ti : c + Ti, g = i ? Ty + Ti : d + Ti);
    const p = Math.max(1, n.width - f - g), v = n.height;
    return {
      width: p,
      height: v,
      screenCenter: {
        x: f + p / 2,
        y: v / 2
      }
    };
  }
  const q2 = typeof navigator < "u" && /Mac|iPod|iPhone|iPad/.test(navigator.platform), He = {
    mod: q2 ? "\u2318" : "Ctrl",
    shift: "\u21E7",
    backspace: "\u232B"
  };
  function ds() {
    const l = document.getElementById("rosette-canvas"), { library: n } = Se.getState();
    if (!l || !n) return;
    const r = n.get_all_bounds(), o = r ? {
      minX: r[0],
      minY: r[1],
      maxX: r[2],
      maxY: r[3]
    } : null, i = Zr(l);
    i.width <= 0 || i.height <= 0 || Ve.getState().zoomToFit(o, i.width, i.height, i.screenCenter);
  }
  function qr(l, n) {
    const r = se.getState().selectedIds;
    if (r.size === 0) return;
    const o = l.get_bounds_for_ids([
      ...r
    ]);
    if (!o) return;
    const i = {
      minX: o[0],
      minY: o[1],
      maxX: o[2],
      maxY: o[3]
    }, c = Zr(n);
    Ve.getState().centerOnBounds(i, c.width, c.height, c.screenCenter);
  }
  const G2 = /* @__PURE__ */ new Set([
    "ArrowUp",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight"
  ]);
  function P2(l, n, r) {
    const o = Ve((v) => v.zoomAt), i = Ve((v) => v.pan), c = Ve((v) => v.zoomToSelected), d = Gt((v) => v.setTool), f = m.useRef(/* @__PURE__ */ new Set()), g = m.useRef(false), p = m.useRef(null);
    m.useEffect(() => {
      const v = () => {
        const x = f.current;
        if (x.size === 0) {
          p.current = null;
          return;
        }
        const E = g.current ? xS : vS;
        let _ = 0, N = 0;
        x.has("ArrowUp") && (N += E), x.has("ArrowDown") && (N -= E), x.has("ArrowLeft") && (_ += E), x.has("ArrowRight") && (_ -= E), (_ !== 0 || N !== 0) && i(_, N), p.current = requestAnimationFrame(v);
      }, b = () => {
        p.current === null && f.current.size > 0 && (p.current = requestAnimationFrame(v));
      }, S = (x) => {
        const E = l.current;
        if (!E) return;
        if (g.current = x.shiftKey, (x.metaKey || x.ctrlKey) && (x.key === "k" || x.key === "K")) {
          x.preventDefault(), cn.getState().toggle();
          return;
        }
        if (!Xf.getState().isCanvasActive() || x.target instanceof HTMLInputElement || x.target instanceof HTMLTextAreaElement || nn.getState().isEditingText) return;
        if (x.key === "/" && !x.metaKey && !x.ctrlKey && !x.altKey) {
          x.preventDefault(), cn.getState().open();
          return;
        }
        if (G2.has(x.key)) {
          x.preventDefault(), f.current.add(x.key), b();
          return;
        }
        const _ = E.getBoundingClientRect(), N = _.width / 2, A = _.height / 2, R = x.shiftKey ? yS : sc, I = x.shiftKey ? bS : ic;
        switch (x.key) {
          case "=":
          case "+":
            x.preventDefault(), o(R, N, A);
            break;
          case "-":
          case "_":
            x.preventDefault(), o(I, N, A);
            break;
        }
        if ((x.metaKey || x.ctrlKey) && (x.key === "a" || x.key === "A")) {
          if (x.preventDefault(), n) {
            const T = n.get_all_ids();
            se.getState().selectAll(T);
          }
          return;
        }
        if ((x.metaKey || x.ctrlKey) && (x.key === "c" || x.key === "C") && !x.shiftKey) {
          if (x.preventDefault(), n) {
            const { selectedIds: T } = se.getState();
            if (T.size > 0) {
              const L = xr(n, T);
              Xn.getState().copy(L);
            }
          }
          return;
        }
        if ((x.metaKey || x.ctrlKey) && (x.key === "v" || x.key === "V") && !x.shiftKey) {
          if (x.preventDefault(), n && r && E) {
            const { hasContent: T } = Xn.getState();
            if (T) {
              const L = new fc();
              ce.getState().execute(L, {
                library: n,
                renderer: r
              }), qr(n, E);
            }
          }
          return;
        }
        if ((x.metaKey || x.ctrlKey) && (x.key === "b" || x.key === "B") && !x.shiftKey) {
          if (x.preventDefault(), n && r && E) {
            const { selectedIds: T } = se.getState();
            if (T.size > 0) {
              const L = new hc([
                ...T
              ]);
              ce.getState().execute(L, {
                library: n,
                renderer: r
              }), qr(n, E);
            }
          }
          return;
        }
        if (x.key === "Delete" || x.key === "Backspace") {
          x.preventDefault();
          const { selectedRulerIds: T } = Oe.getState();
          if (T.size > 0 && n && r) {
            const L = new sh([
              ...T
            ]);
            ce.getState().execute(L, {
              library: n,
              renderer: r
            });
            return;
          }
          if (n && r) {
            const { selectedIds: L } = se.getState();
            if (L.size > 0) {
              const D = [], H = [];
              for (const q of L) Mn(q) ? D.push(q) : H.push(q);
              if (D.length > 0) {
                const q = new B0(D.map(Gr));
                ce.getState().execute(q, {
                  library: n,
                  renderer: r
                });
              }
              if (H.length > 0) {
                const q = new dc(H);
                ce.getState().execute(q, {
                  library: n,
                  renderer: r
                });
              }
            }
          }
          return;
        }
        if ((x.metaKey || x.ctrlKey) && x.key === "z" && !x.shiftKey) {
          if (x.preventDefault(), n && r) {
            const { canUndo: T, undo: L } = ce.getState();
            T && L({
              library: n,
              renderer: r
            });
          }
          return;
        }
        if ((x.metaKey || x.ctrlKey) && ((x.key === "z" || x.key === "Z") && x.shiftKey || x.key === "y" || x.key === "Y")) {
          if (x.preventDefault(), n && r) {
            const { canRedo: T, redo: L } = ce.getState();
            T && L({
              library: n,
              renderer: r
            });
          }
          return;
        }
        if (x.key === "Tab") {
          if (x.preventDefault(), n && E) {
            const T = n.get_group_representative_ids();
            if (T.length > 0) {
              x.shiftKey ? se.getState().selectPrevious(T) : se.getState().selectNext(T);
              const D = se.getState().lastSelectedId;
              if (D) {
                const H = n.get_group_ids(D);
                H.length > 1 && se.setState({
                  selectedIds: new Set(H),
                  lastSelectedId: D
                });
              }
              qr(n, E);
            }
          }
          return;
        }
        if (x.key === "Enter" && (Gt.getState().activeTool === "rectangle" || Gt.getState().activeTool === "polygon" || Gt.getState().activeTool === "path" || Gt.getState().activeTool === "text")) {
          if (Date.now() - Gt.getState().toolSetAt > 2e3) return;
          if (x.preventDefault(), n && r && E) {
            const L = Gt.getState().activeTool;
            L === "rectangle" ? N0(n, r, E) : L === "polygon" ? O0(n, r, E) : L === "path" ? D0(n, r, E) : I0(n, r, E);
          }
          return;
        }
        if (!(x.metaKey || x.ctrlKey)) switch (x.key) {
          case "Escape":
            x.preventDefault(), Oe.getState().activeRulerId ? Oe.getState().cancelCreation() : Oe.getState().selectedRulerIds.size > 0 ? Oe.getState().clearSelection() : se.getState().selectedIds.size > 0 ? se.getState().clearSelection() : d("select");
            break;
          case "v":
          case "V":
            x.preventDefault(), d("select");
            break;
          case "p":
          case "P":
            x.preventDefault(), d("pan");
            break;
          case "q":
          case "Q":
            x.preventDefault(), d("laser");
            break;
          case "z":
          case "Z":
            x.preventDefault(), d("zoom");
            break;
          case "r":
          case "R":
            x.preventDefault(), d("rectangle");
            break;
          case "m":
          case "M":
            x.preventDefault(), d("move");
            break;
          case "g":
          case "G":
            x.preventDefault(), d("polygon");
            break;
          case "h":
          case "H":
            x.preventDefault(), d("path");
            break;
          case "t":
            x.preventDefault(), d("text");
            break;
          case "u":
          case "U":
            x.preventDefault(), d("ruler");
            break;
          case "i":
            x.preventDefault(), cn.getState().open("add instance ");
            break;
          case "f":
            x.preventDefault(), ds();
            break;
          case "F":
            if (x.preventDefault(), n && E) {
              const T = se.getState().selectedIds;
              if (T.size > 0) {
                const L = n.get_bounds_for_ids([
                  ...T
                ]), D = L ? {
                  minX: L[0],
                  minY: L[1],
                  maxX: L[2],
                  maxY: L[3]
                } : null, H = Zr(E);
                c(D, H.width, H.height, H.screenCenter);
              }
            }
            break;
          case "E":
            if (x.shiftKey) {
              x.preventDefault(), me.getState().explorerCollapsed && me.getState().toggleExplorerCollapsed(), ue.getState().setFocused(true);
              break;
            }
            x.preventDefault(), se.getState().selectedIds.size > 0 && me.getState().requestInspectorFocus();
            break;
          case "e":
            x.preventDefault(), se.getState().selectedIds.size > 0 && me.getState().requestInspectorFocus();
            break;
          case "L":
            x.preventDefault(), me.getState().setSidebarTab("layers"), ve.getState().setFocused(true);
            break;
          case "I":
            x.preventDefault(), me.getState().setSidebarTab("inspector");
            break;
          case "c": {
            if (x.preventDefault(), !n || !r) break;
            const T = ah(), L = new ch(T);
            ce.getState().execute(L, {
              library: n,
              renderer: r
            }), me.getState().explorerCollapsed && me.getState().toggleExplorerCollapsed(), ue.getState().setActiveCell(T), ue.getState().setEditingCellName(T);
            break;
          }
        }
      }, C = (x) => {
        g.current = x.shiftKey, f.current.delete(x.key);
      }, k = () => {
        f.current.clear(), g.current = false;
      };
      return window.addEventListener("keydown", S), window.addEventListener("keyup", C), window.addEventListener("blur", k), () => {
        window.removeEventListener("keydown", S), window.removeEventListener("keyup", C), window.removeEventListener("blur", k), p.current !== null && cancelAnimationFrame(p.current);
      };
    }, [
      l,
      o,
      i,
      d,
      n,
      r,
      c
    ]);
  }
  const K2 = 500, Z2 = 3, F2 = _t((l, n) => ({
    points: [],
    opacity: 1,
    isDrawing: false,
    addPoint: (r) => {
      const { points: o, isDrawing: i } = n();
      if (!i) return;
      if (o.length > 0) {
        const d = o[o.length - 1], f = r.x - d.x, g = r.y - d.y;
        if (Math.sqrt(f * f + g * g) < Z2) return;
      }
      const c = [
        ...o,
        r
      ];
      c.length > K2 && c.shift(), l({
        points: c
      });
    },
    startDrawing: () => {
      l({
        isDrawing: true,
        points: [],
        opacity: 1
      });
    },
    stopDrawing: () => {
      l({
        isDrawing: false
      });
    },
    setOpacity: (r) => {
      l({
        opacity: Math.max(0, Math.min(1, r))
      });
    },
    reset: () => {
      l({
        points: [],
        opacity: 1,
        isDrawing: false
      });
    }
  })), Q2 = 300, Ny = 16, Oy = 2, Vd = 2.5;
  function W2(l, n, r, o) {
    const i = 1 - o;
    return {
      x: i * i * l.x + 2 * i * o * n.x + o * o * r.x,
      y: i * i * l.y + 2 * i * o * n.y + o * o * r.y
    };
  }
  function J2(l) {
    if (l.length <= 2) return l;
    const n = [
      l[0]
    ];
    for (let r = 1; r < l.length - 1; r++) {
      const o = Math.max(0, r - Oy), i = Math.min(l.length - 1, r + Oy);
      let c = 0, d = 0;
      const f = i - o + 1;
      for (let g = o; g <= i; g++) c += l[g].x, d += l[g].y;
      n.push({
        x: c / f,
        y: d / f
      });
    }
    return n.push(l[l.length - 1]), n;
  }
  function eC(l) {
    if (l.length < 3) return l;
    const n = [
      l[0]
    ];
    for (let r = 1; r < l.length - 1; r++) {
      const o = l[r - 1], i = l[r], c = l[r + 1], d = {
        x: (o.x + i.x) / 2,
        y: (o.y + i.y) / 2
      }, f = {
        x: (i.x + c.x) / 2,
        y: (i.y + c.y) / 2
      };
      r === 1 && n.push(d);
      for (let g = 1; g <= Ny; g++) {
        const p = g / Ny;
        n.push(W2(d, i, f, p));
      }
    }
    return n.push(l[l.length - 1]), n;
  }
  function tC(l) {
    if (l.length < 2) return l;
    const n = [
      l[0]
    ];
    let r = 0, o = l[0];
    for (let g = 1; g < l.length; g++) {
      const p = l[g], v = p.x - o.x, b = p.y - o.y, S = Math.sqrt(v * v + b * b);
      if (S < 1e-6) {
        o = p;
        continue;
      }
      const C = v / S, k = b / S;
      let x = Vd - r;
      for (; x <= S; ) n.push({
        x: o.x + C * x,
        y: o.y + k * x
      }), x += Vd;
      r = S - (x - Vd), o = p;
    }
    const i = l[l.length - 1], c = n[n.length - 1], d = i.x - c.x, f = i.y - c.y;
    return Math.sqrt(d * d + f * f) > 0.5 && n.push(i), n;
  }
  function nC(l, n) {
    const r = Gt((_) => _.activeTool), { points: o, opacity: i, isDrawing: c, addPoint: d, startDrawing: f, stopDrawing: g, setOpacity: p, reset: v } = F2(), b = m.useRef(null), S = m.useRef(null);
    m.useEffect(() => {
      if (!(!l || !n)) if (o.length === 0) l.clear_laser();
      else {
        const _ = J2(o), N = eC(_), A = tC(N), R = window.devicePixelRatio || 1, I = new Float64Array(A.length * 2);
        for (let T = 0; T < A.length; T++) I[T * 2] = A[T].x * R, I[T * 2 + 1] = A[T].y * R;
        l.set_laser_points(I);
      }
    }, [
      l,
      n,
      o
    ]), m.useEffect(() => {
      !l || !n || l.set_laser_opacity(i);
    }, [
      l,
      n,
      i
    ]);
    const C = m.useCallback(() => {
      S.current !== null && cancelAnimationFrame(S.current), b.current = performance.now();
      const _ = (N) => {
        if (b.current === null) return;
        const A = N - b.current, R = Math.min(A / Q2, 1);
        if (R >= 1) {
          b.current = null, S.current = null, v();
          return;
        }
        p(1 - R), S.current = requestAnimationFrame(_);
      };
      S.current = requestAnimationFrame(_);
    }, [
      v,
      p
    ]), k = m.useCallback((_) => {
      r !== "laser" || _.button !== 0 || (S.current !== null && (cancelAnimationFrame(S.current), S.current = null, b.current = null), f(), d({
        x: _.clientX,
        y: _.clientY
      }));
    }, [
      r,
      f,
      d
    ]), x = m.useCallback((_) => {
      r !== "laser" || !c || d({
        x: _.clientX,
        y: _.clientY
      });
    }, [
      r,
      c,
      d
    ]), E = m.useCallback(() => {
      r !== "laser" || !c || (g(), C());
    }, [
      r,
      c,
      g,
      C
    ]);
    return m.useEffect(() => () => {
      S.current !== null && cancelAnimationFrame(S.current);
    }, []), m.useEffect(() => {
      r !== "laser" && (S.current !== null && (cancelAnimationFrame(S.current), S.current = null, b.current = null), v());
    }, [
      r,
      v
    ]), {
      handleMouseDown: k,
      handleMouseMove: x,
      handleMouseUp: E,
      isLaserActive: r === "laser"
    };
  }
  const lC = _t((l, n) => ({
    box: null,
    isDrawing: false,
    startDrawing: (r, o) => l({
      box: {
        x: r,
        y: o,
        width: 0,
        height: 0
      },
      isDrawing: true
    }),
    updateBox: (r, o) => {
      const i = n();
      !i.box || !i.isDrawing || l({
        box: {
          ...i.box,
          width: r - i.box.x,
          height: o - i.box.y
        }
      });
    },
    stopDrawing: () => l({
      isDrawing: false
    }),
    reset: () => l({
      box: null,
      isDrawing: false
    })
  }));
  function rC(l) {
    const n = Gt((C) => C.activeTool), { box: r, isDrawing: o, startDrawing: i, updateBox: c, reset: d } = lC(), { zoom: f, offset: g, zoomToBounds: p } = Ve(), v = m.useCallback((C) => {
      if (n !== "zoom" || C.button !== 0) return;
      const k = l.current;
      if (!k) return;
      const x = k.getBoundingClientRect(), E = C.clientX - x.left, _ = C.clientY - x.top;
      i(E, _);
    }, [
      n,
      l,
      i
    ]), b = m.useCallback((C) => {
      if (n !== "zoom" || !o) return;
      const k = l.current;
      if (!k) return;
      const x = k.getBoundingClientRect(), E = C.clientX - x.left, _ = C.clientY - x.top;
      c(E, _);
    }, [
      n,
      o,
      l,
      c
    ]), S = m.useCallback(() => {
      if (n !== "zoom" || !o || !r) {
        d();
        return;
      }
      const C = l.current;
      if (Math.abs(r.width) > 5 && Math.abs(r.height) > 5 && C) {
        const k = Math.min(r.x, r.x + r.width), x = Math.max(r.x, r.x + r.width), E = Math.min(r.y, r.y + r.height), _ = Math.max(r.y, r.y + r.height), N = (k - g.x) / f, A = (x - g.x) / f, R = (E - g.y) / f, I = (_ - g.y) / f, T = {
          minX: N,
          maxX: A,
          minY: R,
          maxY: I
        }, L = Zr(C);
        L.width > 0 && L.height > 0 && p(T, L.width, L.height, L.screenCenter);
      }
      d();
    }, [
      n,
      o,
      r,
      f,
      g,
      p,
      d,
      l
    ]);
    return m.useEffect(() => {
      n !== "zoom" && d();
    }, [
      n,
      d
    ]), {
      handleMouseDown: v,
      handleMouseMove: b,
      handleMouseUp: S,
      box: r,
      isZoomActive: n === "zoom",
      isDrawingZoom: o
    };
  }
  function Da(l) {
    return Math.round(l / xe) * xe;
  }
  const Nl = new Float64Array(8), $o = new Float32Array(4);
  function aC(l, n, r) {
    const o = m.useRef(null), i = m.useRef(false), c = m.useRef([
      0.5,
      0.5,
      0.5,
      0.5
    ]), d = m.useCallback((v) => {
      if (v.button !== 0) return;
      const S = v.currentTarget.getBoundingClientRect(), C = v.clientX - S.left, k = v.clientY - S.top, x = l(C, k);
      if (!x) return;
      const E = Da(x.x), _ = Da(x.y);
      o.current = {
        x: E,
        y: _
      }, i.current = true;
      const N = ve.getState().activeLayerId, R = ve.getState().layers.get(N);
      if (R) {
        const [I, T, L] = cc(R.color, 0.5);
        c.current = [
          I,
          T,
          L,
          0.5
        ];
      } else c.current = [
        0.5,
        0.5,
        0.5,
        0.5
      ];
    }, [
      l
    ]), f = m.useCallback((v, b) => {
      const S = o.current;
      if (!i.current || !S || !r) return false;
      const C = l(v, b);
      if (!C) return false;
      const k = Da(C.x), x = Da(C.y), E = Math.min(S.x, k), _ = Math.min(S.y, x), N = Math.max(S.x, k), A = Math.max(S.y, x);
      Nl[0] = E, Nl[1] = _, Nl[2] = N, Nl[3] = _, Nl[4] = N, Nl[5] = A, Nl[6] = E, Nl[7] = A;
      const R = c.current;
      return $o[0] = R[0], $o[1] = R[1], $o[2] = R[2], $o[3] = R[3], r.set_preview_shape(Nl, $o), r.mark_dirty(), true;
    }, [
      l,
      r
    ]), g = m.useCallback((v, b) => {
      const S = o.current;
      if (!S || !n || !r) return;
      const C = Da(v), k = Da(b), x = Math.min(S.x, C), E = Math.min(S.y, k), _ = Math.abs(C - S.x), N = Math.abs(k - S.y);
      if (_ > 0 && N > 0) {
        const A = ve.getState().activeLayerId, I = ve.getState().layers.get(A), T = (I == null ? void 0 : I.layerNumber) ?? 1, L = (I == null ? void 0 : I.datatype) ?? 0, D = new S0(x, E, _, N, T, L);
        ce.getState().execute(D, {
          library: n,
          renderer: r
        });
      }
      r.clear_preview(), i.current = false, o.current = null;
    }, [
      n,
      r
    ]), p = m.useCallback(() => {
      i.current = false, o.current = null, r == null ? void 0 : r.clear_preview();
    }, [
      r
    ]);
    return {
      handleMouseDown: d,
      handleMouseMove: f,
      finalizeRectangle: g,
      cancelDrawing: p
    };
  }
  function Ni(l) {
    return Math.round(l / xe) * xe;
  }
  function Iy(l, n, r, o) {
    const i = (l.x - n.x) * r, c = (l.y - n.y) * r;
    return Math.sqrt(i * i + c * c) <= o;
  }
  const Dy = 10, zy = 8, oC = 6;
  function Hy(l, n, r) {
    const o = oC / r;
    let i = null, c = null, d = l.x, f = l.y;
    for (const g of n) if (i === null && Math.abs(l.x - g.x) <= o && (d = g.x, i = g), c === null && Math.abs(l.y - g.y) <= o && (f = g.y, c = g), i !== null && c !== null) break;
    return {
      point: {
        x: d,
        y: f
      },
      guides: {
        alignedVertexX: i,
        alignedVertexY: c
      }
    };
  }
  function Uy(l, n) {
    const r = n.x - l.x, o = n.y - l.y;
    if (r === 0 && o === 0) return n;
    const i = Math.abs(Math.atan2(Math.abs(o), Math.abs(r)) * (180 / Math.PI));
    return i <= zy ? {
      x: n.x,
      y: l.y
    } : i >= 90 - zy ? {
      x: l.x,
      y: n.y
    } : n;
  }
  function sC(l, n, r, o) {
    const [i, c] = m.useState([]), [d, f] = m.useState(false), [g, p] = m.useState(null), [v, b] = m.useState(false), [S, C] = m.useState(null), k = ve((I) => I.activeLayerId), x = ve((I) => I.layers), E = Gt((I) => I.activeTool);
    m.useEffect(() => {
      E !== "polygon" && (c([]), f(false), p(null), b(false), C(null));
    }, [
      E
    ]);
    const _ = m.useCallback((I) => {
      if (!n || !r || I.length < 3) return;
      const T = new Float64Array(I.length * 2);
      for (let re = 0; re < I.length; re++) T[re * 2] = I[re].x, T[re * 2 + 1] = I[re].y;
      const L = x.get(k), D = (L == null ? void 0 : L.layerNumber) ?? 1, H = (L == null ? void 0 : L.datatype) ?? 0, q = new E0(T, D, H);
      ce.getState().execute(q, {
        library: n,
        renderer: r
      }), c([]), f(false), p(null), b(false);
    }, [
      n,
      r,
      k,
      x
    ]), N = m.useCallback((I) => {
      if (I.button !== 0) return;
      const L = I.currentTarget.getBoundingClientRect(), D = I.clientX - L.left, H = I.clientY - L.top, q = l(D, H);
      if (!q) return;
      let re = {
        x: Ni(q.x),
        y: Ni(q.y)
      };
      if (i.length > 0 && !I.shiftKey && (re = Hy(re, i, o).point, re = Uy(i[i.length - 1], re)), i.length >= 3) {
        const ge = i[0];
        if (Iy(ge, re, o, Dy)) {
          _(i);
          return;
        }
      }
      const ee = i[i.length - 1];
      if (ee && re.x === ee.x && re.y === ee.y) return;
      const de = [
        ...i,
        re
      ];
      c(de), f(true);
    }, [
      l,
      i,
      o,
      _
    ]), A = m.useCallback((I) => {
      const L = I.currentTarget.getBoundingClientRect(), D = I.clientX - L.left, H = I.clientY - L.top, q = l(D, H);
      if (!q) return;
      let re = {
        x: Ni(q.x),
        y: Ni(q.y)
      }, ee = null;
      if (i.length > 0 && !I.shiftKey) {
        const ge = Hy(re, i, o);
        re = ge.point, ee = ge.guides, re = Uy(i[i.length - 1], re);
      }
      const de = i.length >= 3 && Iy(i[0], re, o, Dy);
      de && (re = {
        ...i[0]
      }, ee = null), b(de), p(re), C(ee);
    }, [
      l,
      i,
      o
    ]), R = m.useCallback(() => {
      c([]), f(false), p(null), b(false), C(null);
    }, []);
    return {
      handleMouseDown: N,
      handleMouseMove: A,
      cancelDrawing: R,
      isDrawing: d,
      points: i,
      cursorPoint: g,
      isNearStart: v,
      alignmentGuides: S
    };
  }
  function Oi(l) {
    return Math.round(l / xe) * xe;
  }
  const iC = 6;
  function Yy(l, n, r) {
    const o = iC / r;
    let i = null, c = null, d = l.x, f = l.y;
    for (const g of n) if (i === null && Math.abs(l.x - g.x) <= o && (d = g.x, i = g), c === null && Math.abs(l.y - g.y) <= o && (f = g.y, c = g), i !== null && c !== null) break;
    return {
      point: {
        x: d,
        y: f
      },
      guides: {
        alignedVertexX: i,
        alignedVertexY: c
      }
    };
  }
  function cC(l, n, r, o) {
    const [i, c] = m.useState([]), [d, f] = m.useState(false), [g, p] = m.useState(null), [v, b] = m.useState(null), S = ve((R) => R.activeLayerId), C = ve((R) => R.layers), k = Gt((R) => R.activeTool);
    m.useEffect(() => {
      k !== "path" && (c([]), f(false), p(null), b(null));
    }, [
      k
    ]);
    const x = m.useCallback((R) => {
      if (!n || !r || R.length < 2) return;
      const { width: I, cornerRadius: T, numArcPoints: L } = rn.getState(), D = new Float64Array(R.length * 2);
      for (let de = 0; de < R.length; de++) D[de * 2] = R[de].x, D[de * 2 + 1] = R[de].y;
      const H = C.get(S), q = (H == null ? void 0 : H.layerNumber) ?? 1, re = (H == null ? void 0 : H.datatype) ?? 0, ee = new k0(D, I, q, re, [
        ...R
      ], T, L);
      ce.getState().execute(ee, {
        library: n,
        renderer: r
      }), c([]), f(false), p(null), b(null);
    }, [
      n,
      r,
      S,
      C
    ]), E = m.useCallback((R) => {
      if (R.button !== 0) return;
      const T = R.currentTarget.getBoundingClientRect(), L = R.clientX - T.left, D = R.clientY - T.top, H = l(L, D);
      if (!H) return;
      let q = {
        x: Oi(H.x),
        y: Oi(H.y)
      };
      if (i.length > 0 && !R.shiftKey && (q = Yy(q, i, o).point, q = My(i[i.length - 1], q)), R.detail >= 2 && i.length >= 2) {
        x(i);
        return;
      }
      const re = i[i.length - 1];
      if (re && q.x === re.x && q.y === re.y) return;
      const ee = [
        ...i,
        q
      ];
      c(ee), f(true);
    }, [
      l,
      i,
      o,
      x
    ]), _ = m.useCallback((R) => {
      const T = R.currentTarget.getBoundingClientRect(), L = R.clientX - T.left, D = R.clientY - T.top, H = l(L, D);
      if (!H) return;
      let q = {
        x: Oi(H.x),
        y: Oi(H.y)
      }, re = null;
      if (i.length > 0 && !R.shiftKey) {
        const ee = Yy(q, i, o);
        q = ee.point, re = ee.guides, q = My(i[i.length - 1], q);
      }
      p(q), b(re);
    }, [
      l,
      i,
      o
    ]), N = m.useCallback((R) => {
      R.key === "Enter" && i.length >= 2 && (R.preventDefault(), x(i));
    }, [
      i,
      x
    ]);
    m.useEffect(() => {
      if (d) return window.addEventListener("keydown", N), () => window.removeEventListener("keydown", N);
    }, [
      d,
      N
    ]);
    const A = m.useCallback(() => {
      c([]), f(false), p(null), b(null);
    }, []);
    return {
      handleMouseDown: E,
      handleMouseMove: _,
      cancelDrawing: A,
      isDrawing: d,
      waypoints: i,
      cursorPoint: g,
      alignmentGuides: v
    };
  }
  const By = _t((l, n) => ({
    box: null,
    isDrawing: false,
    previewIds: /* @__PURE__ */ new Set(),
    startDrawing: (r, o) => l({
      box: {
        x: r,
        y: o,
        width: 0,
        height: 0
      },
      isDrawing: true,
      previewIds: /* @__PURE__ */ new Set()
    }),
    updateBox: (r, o) => {
      const i = n();
      !i.box || !i.isDrawing || l({
        box: {
          ...i.box,
          width: r - i.box.x,
          height: o - i.box.y
        }
      });
    },
    setPreviewIds: (r) => l({
      previewIds: new Set(r)
    }),
    reset: () => l({
      box: null,
      isDrawing: false,
      previewIds: /* @__PURE__ */ new Set()
    })
  })), Xy = 15;
  function $f(l) {
    if (!l) return null;
    try {
      const n = l.get_all_vertices();
      return n.length > 0 ? n : null;
    } catch {
      return null;
    }
  }
  function uC(l, n, r, o, i, c) {
    const d = i - r, f = c - o, g = d * d + f * f;
    if (g === 0) {
      const C = (l - r) * (l - r) + (n - o) * (n - o);
      return {
        point: {
          x: r,
          y: o
        },
        distSq: C
      };
    }
    const p = Math.max(0, Math.min(1, ((l - r) * d + (n - o) * f) / g)), v = r + p * d, b = o + p * f, S = (l - v) * (l - v) + (n - b) * (n - b);
    return {
      point: {
        x: v,
        y: b
      },
      distSq: S
    };
  }
  function dC(l, n, r, o, i) {
    let c = null, d = Xy * Xy;
    const f = (l - i.x) / o, g = (n - i.y) / o;
    for (const p of r) {
      const v = p.length / 2;
      if (!(v < 2)) for (let b = 0; b < v; b++) {
        const S = (b + 1) % v, C = p[b * 2], k = p[b * 2 + 1], x = p[S * 2], E = p[S * 2 + 1], { point: _, distSq: N } = uC(f, g, C, k, x, E), A = N * o * o;
        A < d && (d = A, c = _);
      }
    }
    return c;
  }
  function Vy(l) {
    return Math.round(l / xe) * xe;
  }
  function fC(l) {
    const n = [];
    let r = 0;
    for (; r < l.length; ) {
      const o = l[r];
      if (r++, o < 2 || r + o * 2 > l.length) break;
      const i = [];
      for (let c = 0; c < o; c++) i.push(l[r], l[r + 1]), r += 2;
      n.push(i);
    }
    return n;
  }
  function qf(l, n, r, o, i, c, d, f = false) {
    if (!f && i && i.length >= 5) {
      const g = fC(i);
      if (g.length > 0) {
        const p = dC(l, n, g, c, d);
        if (p) return {
          point: p,
          isGeometrySnap: true
        };
      }
    }
    return {
      point: {
        x: Vy(r),
        y: Vy(o)
      },
      isGeometrySnap: false
    };
  }
  const $y = 5;
  function qy(l, n) {
    return l.get_group_ids(n);
  }
  function Gy(l, n) {
    const r = /* @__PURE__ */ new Set(), o = [];
    for (const i of n) {
      const c = l.get_group_ids(i);
      for (const d of c) r.has(d) || (r.add(d), o.push(d));
    }
    return o;
  }
  const hC = 8, Ii = 12, Gf = 140, Pf = 56;
  function mC(l, n, r, o, i, c) {
    const d = l - r, f = n - o, g = i - r, p = c - o, v = d * g + f * p, b = g * g + p * p;
    if (b === 0) return Math.sqrt(d * d + f * f);
    const S = Math.max(0, Math.min(1, v / b)), C = r + S * g, k = o + S * p, x = l - C, E = n - k;
    return Math.sqrt(x * x + E * E);
  }
  function Py(l, n, r, o, i) {
    for (const c of r.values()) {
      const d = c.start.x * o + i.x, f = c.start.y * o + i.y, g = c.end.x * o + i.x, p = c.end.y * o + i.y, v = l - d, b = n - f;
      if (v * v + b * b <= Ii * Ii) return {
        rulerId: c.id,
        endpoint: "start"
      };
      const S = l - g, C = n - p;
      if (S * S + C * C <= Ii * Ii) return {
        rulerId: c.id,
        endpoint: "end"
      };
    }
    return null;
  }
  function Ky(l, n, r, o, i) {
    for (const c of r.values()) {
      const d = c.start.x * o + i.x, f = c.start.y * o + i.y, g = c.end.x * o + i.x, p = c.end.y * o + i.y, v = (d + g) / 2, b = (f + p) / 2, S = Gf / 2, C = Pf / 2;
      if (l >= v - S && l <= v + S && n >= b - C && n <= b + C || mC(l, n, d, f, g, p) <= hC) return c.id;
    }
    return null;
  }
  function gC(l, n, r, o, i, c, d, f) {
    if (l >= i && l <= d && n >= c && n <= f || r >= i && r <= d && o >= c && o <= f) return true;
    const g = [
      [
        i,
        c,
        d,
        c
      ],
      [
        d,
        c,
        d,
        f
      ],
      [
        i,
        f,
        d,
        f
      ],
      [
        i,
        c,
        i,
        f
      ]
    ];
    for (const [p, v, b, S] of g) if (pC(l, n, r, o, p, v, b, S)) return true;
    return false;
  }
  function pC(l, n, r, o, i, c, d, f) {
    const g = Di(i, c, d, f, l, n), p = Di(i, c, d, f, r, o), v = Di(l, n, r, o, i, c), b = Di(l, n, r, o, d, f);
    return !!((g > 0 && p < 0 || g < 0 && p > 0) && (v > 0 && b < 0 || v < 0 && b > 0) || g === 0 && zi(i, c, d, f, l, n) || p === 0 && zi(i, c, d, f, r, o) || v === 0 && zi(l, n, r, o, i, c) || b === 0 && zi(l, n, r, o, d, f));
  }
  function Di(l, n, r, o, i, c) {
    return (i - l) * (o - n) - (r - l) * (c - n);
  }
  function zi(l, n, r, o, i, c) {
    return Math.min(l, r) <= i && i <= Math.max(l, r) && Math.min(n, o) <= c && c <= Math.max(n, o);
  }
  function Zy(l, n, r, o, i, c, d) {
    const f = [];
    for (const g of i.values()) {
      const p = g.start.x * c + d.x, v = g.start.y * c + d.y, b = g.end.x * c + d.x, S = g.end.y * c + d.y;
      if (gC(p, v, b, S, l, n, r, o)) {
        f.push(g.id);
        continue;
      }
      const C = (p + b) / 2, k = (v + S) / 2, x = C - Gf / 2, E = C + Gf / 2, _ = k - Pf / 2, N = k + Pf / 2;
      x <= r && E >= l && _ <= o && N >= n && f.push(g.id);
    }
    return f;
  }
  function yC(l, n, r) {
    const { selectedIds: o, hoveredId: i, clearSelection: c, setHover: d } = se(), { box: f, isDrawing: g, previewIds: p, startDrawing: v, updateBox: b, setPreviewIds: S, reset: C } = By(), { zoom: k, offset: x } = Ve(), E = Oe((j) => j.rulers), _ = Oe((j) => j.selectedRulerIds), N = Oe((j) => j.selectRuler), A = Oe((j) => j.toggleSelection), R = Oe((j) => j.addToSelection), I = Oe((j) => j.clearSelection), T = Oe((j) => j.setHoveredRuler), L = Oe((j) => j.setHoveredEndpoint), D = Oe((j) => j.setDraggingEndpoint), H = Oe((j) => j.endDraggingEndpoint), q = Oe((j) => j.updateEndpoint), re = Oe((j) => j.hoveredRulerId), ee = Oe((j) => j.hoveredEndpoint), de = Oe((j) => j.draggingEndpoint), ge = Oe((j) => j.setMarqueePreviewIds), Ee = Oe((j) => j.setSnapPoint), $ = m.useRef("");
    m.useEffect(() => {
      if (!r) return;
      const j = Array.from(o).filter((O) => !Mn(O));
      r.set_selection(j);
    }, [
      r,
      o
    ]), m.useEffect(() => {
      if (r) if (g) {
        const j = Array.from(p).filter((O) => !Mn(O));
        r.set_hover_multiple(j);
      } else if (i && !Mn(i) && n) {
        const j = qy(n, i);
        r.set_hover_multiple(j);
      } else r.set_hover(void 0);
    }, [
      r,
      n,
      i,
      g,
      p
    ]);
    const F = m.useCallback((j) => {
      if (j.button !== 0) return;
      const K = j.currentTarget.getBoundingClientRect(), W = j.clientX - K.left, J = j.clientY - K.top, ie = Py(W, J, E, k, x);
      if (ie) {
        N(ie.rulerId), D(ie), c();
        return;
      }
      const pe = Ky(W, J, E, k, x);
      if (pe) {
        j.shiftKey ? R([
          pe
        ]) : j.metaKey || j.ctrlKey ? A(pe) : N(pe), c();
        return;
      }
      _.size > 0 && I();
      const Re = l(W, J);
      if (!Re || !n) return;
      let X = n.hit_test(Re.x, Re.y);
      if (X || (X = es(Re.x, Re.y) ?? void 0), X) {
        const U = Mn(X) ? [
          X
        ] : qy(n, X);
        if (j.shiftKey) {
          const te = se.getState().selectedIds, he = /* @__PURE__ */ new Set([
            ...te,
            ...U
          ]);
          se.setState({
            selectedIds: he,
            lastSelectedId: X
          });
        } else if (j.metaKey || j.ctrlKey) {
          const te = se.getState().selectedIds, he = U.every((we) => te.has(we)), be = new Set(te);
          if (he) for (const we of U) be.delete(we);
          else for (const we of U) be.add(we);
          se.setState({
            selectedIds: be,
            lastSelectedId: X
          });
        } else se.setState({
          selectedIds: new Set(U),
          lastSelectedId: X
        });
      } else v(W, J), !j.shiftKey && !j.metaKey && !j.ctrlKey && c();
    }, [
      l,
      n,
      E,
      k,
      x,
      _,
      c,
      N,
      A,
      R,
      I,
      D,
      v
    ]), fe = m.useCallback((j) => {
      const K = j.currentTarget.getBoundingClientRect(), W = j.clientX - K.left, J = j.clientY - K.top;
      if (de) {
        const X = l(W, J);
        if (X) {
          const U = $f(n), te = qf(W, J, X.x, X.y, U, k, x, j.shiftKey);
          q(de.rulerId, de.endpoint, te.point), Ee(te.isGeometrySnap ? te.point : null);
        }
        return;
      }
      if (g) {
        b(W, J);
        const X = By.getState().box;
        if (X) {
          const U = Math.min(X.x, X.x + X.width), te = Math.max(X.x, X.x + X.width), he = Math.min(X.y, X.y + X.height), be = Math.max(X.y, X.y + X.height), we = Zy(U, he, te, be, E, k, x);
          ge(we);
          {
            const je = (U - x.x) / k, Xe = (te - x.x) / k, We = (he - x.y) / k, Ce = (be - x.y) / k, Ne = Math.min(je, Xe), Ae = Math.max(je, Xe), Ie = Math.min(We, Ce), $e = Math.max(We, Ce), vt = n ? n.hit_test_rect(Ne, Ie, Ae, $e) : [], Ke = n ? Gy(n, vt) : vt, an = Ey(Ne, Ie, Ae, $e), un = [
              ...Ke,
              ...an
            ], Wn = un.sort().join(",");
            Wn !== $.current && ($.current = Wn, S(un));
          }
        }
        return;
      }
      const ie = Py(W, J, E, k, x);
      let pe = null;
      ie ? (((ee == null ? void 0 : ee.rulerId) !== ie.rulerId || (ee == null ? void 0 : ee.endpoint) !== ie.endpoint) && L(ie), re !== ie.rulerId && T(ie.rulerId), pe = ie.rulerId) : (ee && L(null), pe = Ky(W, J, E, k, x), pe !== re && T(pe));
      const Re = l(W, J);
      if (!Re || !n) {
        i !== null && d(null);
        return;
      }
      if (pe) i !== null && d(null);
      else {
        let X = n.hit_test(Re.x, Re.y);
        X || (X = es(Re.x, Re.y) ?? void 0), (X ?? null) !== i && d(X ?? null);
      }
    }, [
      l,
      n,
      E,
      i,
      re,
      ee,
      de,
      d,
      T,
      L,
      q,
      ge,
      g,
      b,
      k,
      x,
      S,
      Ee
    ]), ye = m.useCallback(() => {
      if (de) {
        const K = H();
        if (Ee(null), K && n && r) {
          const W = new j0(K.rulerId, K.endpoint, K.oldPosition, K.newPosition);
          ce.getState().pushCommand(W);
        }
        return;
      }
      if (!g || !f) {
        C(), ge([]);
        return;
      }
      const j = Math.abs(f.width), O = Math.abs(f.height);
      if (j > $y || O > $y) {
        const K = Math.min(f.x, f.x + f.width), W = Math.max(f.x, f.x + f.width), J = Math.min(f.y, f.y + f.height), ie = Math.max(f.y, f.y + f.height), pe = Zy(K, J, W, ie, E, k, x), Re = (K - x.x) / k, X = (W - x.x) / k, U = (J - x.y) / k, te = (ie - x.y) / k, he = Math.min(Re, X), be = Math.max(Re, X), we = Math.min(U, te), je = Math.max(U, te), Xe = n ? n.hit_test_rect(he, we, be, je) : [], We = n ? Gy(n, Xe) : Xe, Ce = Ey(he, we, be, je);
        pe.length > 0 && R(pe);
        const Ne = [
          ...We,
          ...Ce
        ];
        if (Ne.length > 0) {
          const Ae = se.getState().selectedIds, Ie = /* @__PURE__ */ new Set([
            ...Ae,
            ...Ne
          ]);
          se.getState().setSelection(Ie);
        }
      }
      C(), ge([]);
    }, [
      g,
      f,
      n,
      r,
      E,
      k,
      x,
      de,
      R,
      H,
      C,
      ge,
      Ee
    ]), ke = m.useCallback(() => {
      i !== null && d(null), re !== null && T(null), ee !== null && L(null), de !== null && D(null), C(), ge([]);
    }, [
      i,
      re,
      ee,
      de,
      d,
      T,
      L,
      D,
      C,
      ge
    ]);
    return {
      handleMouseDown: F,
      handleMouseMove: fe,
      handleMouseUp: ye,
      handleMouseLeave: ke,
      selectedIds: o,
      hoveredId: i,
      hoveredRulerId: re,
      hoveredEndpoint: ee,
      marqueeBox: f,
      isDrawingMarquee: g,
      previewIds: p
    };
  }
  const bC = 8, vC = 140, xC = 56;
  function wC(l, n, r, o, i, c) {
    const d = l - r, f = n - o, g = i - r, p = c - o, v = d * g + f * p, b = g * g + p * p;
    if (b === 0) return Math.sqrt(d * d + f * f);
    const S = Math.max(0, Math.min(1, v / b)), C = r + S * g, k = o + S * p, x = l - C, E = n - k;
    return Math.sqrt(x * x + E * E);
  }
  function Fy(l, n, r, o, i) {
    for (const c of r.values()) {
      const d = c.start.x * o + i.x, f = c.start.y * o + i.y, g = c.end.x * o + i.x, p = c.end.y * o + i.y, v = (d + g) / 2, b = (f + p) / 2, S = vC / 2, C = xC / 2;
      if (l >= v - S && l <= v + S && n >= b - C && n <= b + C || wC(l, n, d, f, g, p) <= bC) return c.id;
    }
    return null;
  }
  function SC(l, n, r) {
    const [o, i] = m.useState(false), [c, d] = m.useState(null), [f, g] = m.useState(null), { zoom: p, offset: v } = Ve(), b = Oe((A) => A.rulers), S = Oe((A) => A.selectRuler), C = m.useRef(null), k = m.useCallback((A) => {
      if (A.button !== 0) return;
      const I = A.currentTarget.getBoundingClientRect(), T = A.clientX - I.left, L = A.clientY - I.top, D = l(T, L);
      if (!D) return;
      const H = Fy(T, L, b, p, v);
      if (H) {
        S(H), se.getState().clearSelection(), C.current = {
          elementIds: [],
          rulerId: H,
          startWorld: D,
          currentDelta: {
            x: 0,
            y: 0
          }
        }, i(true);
        return;
      }
      let q;
      if (n && (q = n.hit_test(D.x, D.y) ?? void 0), q || (q = es(D.x, D.y) ?? void 0), !q) return;
      S(null);
      const { selectedIds: re } = se.getState();
      if (Mn(q)) {
        let ge;
        re.has(q) ? ge = [
          ...re
        ].filter((Ee) => Mn(Ee)) : (ge = [
          q
        ], se.getState().select(q)), C.current = {
          elementIds: ge,
          rulerId: null,
          startWorld: D,
          currentDelta: {
            x: 0,
            y: 0
          }
        }, i(true);
        return;
      }
      if (!n) return;
      const ee = n.get_group_ids(q);
      let de;
      re.has(q) ? de = [
        ...re
      ].filter((ge) => !Mn(ge)) : (de = ee, se.getState().setSelection(new Set(ee))), C.current = {
        elementIds: de,
        rulerId: null,
        startWorld: D,
        currentDelta: {
          x: 0,
          y: 0
        }
      }, i(true);
    }, [
      l,
      n,
      b,
      p,
      v,
      S
    ]), x = m.useCallback((A) => {
      const I = A.currentTarget.getBoundingClientRect(), T = A.clientX - I.left, L = A.clientY - I.top, D = l(T, L);
      if (!D) return;
      if (!o) {
        const ge = Fy(T, L, b, p, v);
        ge !== f && g(ge);
        {
          let Ee = null;
          n && (Ee = n.hit_test(D.x, D.y) ?? null), Ee || (Ee = es(D.x, D.y)), Ee !== c && d(Ee);
        }
        return;
      }
      const H = C.current;
      if (!H) return;
      const q = D.x - H.startWorld.x, re = D.y - H.startWorld.y, ee = q - H.currentDelta.x, de = re - H.currentDelta.y;
      if (ee !== 0 || de !== 0) {
        if (H.rulerId) {
          const ge = Oe.getState().rulers.get(H.rulerId);
          ge && (Oe.getState().updateEndpoint(H.rulerId, "start", {
            x: ge.start.x + ee,
            y: ge.start.y + de
          }), Oe.getState().updateEndpoint(H.rulerId, "end", {
            x: ge.end.x + ee,
            y: ge.end.y + de
          }));
        } else if (H.elementIds.length > 0 && Mn(H.elementIds[0])) {
          const ge = Bt.getState();
          for (const Ee of H.elementIds) {
            const $ = Gr(Ee), F = ge.images.get($);
            F && ge.updateImage($, {
              x: F.x + ee,
              y: F.y + de
            });
          }
        } else n && r && (n.translate_elements(H.elementIds, ee, de), r.sync_from_library(n), r.mark_dirty(), Se.getState().bumpSyncGeneration());
        H.currentDelta = {
          x: q,
          y: re
        };
      }
    }, [
      l,
      n,
      r,
      b,
      p,
      v,
      o,
      c,
      f
    ]), E = m.useCallback(() => {
      if (!o) {
        i(false), C.current = null;
        return;
      }
      const A = C.current;
      if (!A) {
        i(false);
        return;
      }
      const { elementIds: R, rulerId: I, currentDelta: T } = A;
      if (I && (T.x !== 0 || T.y !== 0)) {
        const L = new M0([
          I
        ], T.x, T.y);
        ce.getState().pushCommand(L), i(false), C.current = null;
        return;
      }
      if (R.length > 0 && Mn(R[0]) && (T.x !== 0 || T.y !== 0)) {
        const L = new u2(R, T.x, T.y);
        ce.getState().pushCommand(L);
      } else if (n && r && (T.x !== 0 || T.y !== 0)) {
        n.translate_elements(R, -T.x, -T.y), r.sync_from_library(n);
        const L = new JS(R, T.x, T.y);
        ce.getState().execute(L, {
          library: n,
          renderer: r
        });
        const D = /* @__PURE__ */ new Set();
        for (const H of R) {
          const q = yr(H);
          if (!q) {
            console.warn("[move] no source for", H.slice(0, 8), "\u2014 edit skipped");
            continue;
          }
          if (q.type === "ref") {
            const re = `${q.file}:${q.line}`;
            D.has(re) || (D.add(re), OS(H, T.x, T.y));
          } else {
            const re = n.get_element_info(H);
            re && (Go(H, new Float64Array(re.vertices)), re.free());
          }
        }
      }
      i(false), C.current = null;
    }, [
      o,
      n,
      r
    ]), _ = m.useCallback(() => {
      if (!o) {
        i(false), C.current = null;
        return;
      }
      const A = C.current;
      if (A && (A.currentDelta.x !== 0 || A.currentDelta.y !== 0)) if (A.rulerId) {
        const R = Oe.getState().rulers.get(A.rulerId);
        R && (Oe.getState().updateEndpoint(A.rulerId, "start", {
          x: R.start.x - A.currentDelta.x,
          y: R.start.y - A.currentDelta.y
        }), Oe.getState().updateEndpoint(A.rulerId, "end", {
          x: R.end.x - A.currentDelta.x,
          y: R.end.y - A.currentDelta.y
        }));
      } else if (A.elementIds.length > 0 && Mn(A.elementIds[0])) {
        const R = Bt.getState();
        for (const I of A.elementIds) {
          const T = Gr(I), L = R.images.get(T);
          L && R.updateImage(T, {
            x: L.x - A.currentDelta.x,
            y: L.y - A.currentDelta.y
          });
        }
      } else n && r && (n.translate_elements(A.elementIds, -A.currentDelta.x, -A.currentDelta.y), r.sync_from_library(n), r.mark_dirty());
      i(false), C.current = null;
    }, [
      o,
      n,
      r
    ]), N = m.useCallback(() => {
      o && _(), d(null), g(null);
    }, [
      o,
      _
    ]);
    return {
      handleMouseDown: k,
      handleMouseMove: x,
      handleMouseUp: E,
      handleMouseLeave: N,
      cancelMove: _,
      isMoving: o,
      hoveredId: c,
      hoveredRulerId: f
    };
  }
  function Qy(l, n) {
    return l.line < n.line ? true : l.line > n.line ? false : l.column < n.column;
  }
  function fh(l) {
    if (!l || !l.isActive || l.anchor.line === l.focus.line && l.anchor.column === l.focus.column) return null;
    const n = Qy(l.anchor, l.focus) ? l.anchor : l.focus, r = Qy(l.anchor, l.focus) ? l.focus : l.anchor;
    return {
      start: n,
      end: r
    };
  }
  function CC(l) {
    var _a;
    if (!((_a = l.selection) == null ? void 0 : _a.isActive)) return "";
    const n = fh(l.selection);
    if (!n) return "";
    const r = l.content.split(`
`);
    let o = "";
    for (let i = n.start.line; i <= n.end.line; i++) {
      const c = r[i], d = i === n.start.line ? n.start.column : 0, f = i === n.end.line ? n.end.column : c.length;
      o += c.substring(d, f), i < n.end.line && (o += `
`);
    }
    return o;
  }
  function EC(l) {
    var _a;
    if (!((_a = l.selection) == null ? void 0 : _a.isActive)) return l;
    const n = fh(l.selection);
    if (!n) return l;
    const o = [
      ...l.content.split(`
`)
    ];
    if (n.start.line === n.end.line) {
      const i = o[n.start.line];
      o[n.start.line] = i.substring(0, n.start.column) + i.substring(n.end.column);
    } else {
      const i = o[n.start.line], c = o[n.end.line];
      o[n.start.line] = i.substring(0, n.start.column) + c.substring(n.end.column), o.splice(n.start.line + 1, n.end.line - n.start.line);
    }
    return {
      ...l,
      content: o.join(`
`),
      cursorPosition: {
        line: n.start.line,
        column: n.start.column
      },
      selection: void 0
    };
  }
  function _C(l, n, r) {
    var _a;
    r == null ? void 0 : r.preventDefault(), r == null ? void 0 : r.stopPropagation();
    const o = l.content.split(`
`), { line: i, column: c } = l.cursorPosition, d = (r == null ? void 0 : r.shiftKey) || false;
    let f = i, g = c, p = l;
    switch (d && !((_a = l.selection) == null ? void 0 : _a.isActive) && (p = {
      ...l,
      selection: {
        anchor: {
          line: i,
          column: c
        },
        focus: {
          line: i,
          column: c
        },
        isActive: true
      }
    }), n) {
      case "ArrowLeft":
        c > 0 ? g = c - 1 : i > 0 && (f = i - 1, g = o[f].length);
        break;
      case "ArrowRight":
        c < o[i].length ? g = c + 1 : i < o.length - 1 && (f = i + 1, g = 0);
        break;
      case "ArrowUp":
        i > 0 && (f = i - 1, g = Math.min(c, o[f].length));
        break;
      case "ArrowDown":
        i < o.length - 1 && (f = i + 1, g = Math.min(c, o[f].length));
        break;
      case "Home":
        g = 0;
        break;
      case "End":
        g = o[i].length;
        break;
    }
    if (d) {
      const v = {
        line: f,
        column: g
      }, b = p.selection.anchor.line === v.line && p.selection.anchor.column === v.column;
      return {
        ...p,
        cursorPosition: v,
        selection: {
          ...p.selection,
          focus: v,
          isActive: !b
        }
      };
    }
    return {
      ...p,
      cursorPosition: {
        line: f,
        column: g
      },
      selection: void 0
    };
  }
  function kC(l, n) {
    if (n.key === "a" && (n.ctrlKey || n.metaKey)) {
      n.preventDefault(), n.stopPropagation();
      const r = l.content.split(`
`), o = r.length - 1, i = r[o].length;
      return {
        ...l,
        cursorPosition: {
          line: o,
          column: i
        },
        selection: {
          anchor: {
            line: 0,
            column: 0
          },
          focus: {
            line: o,
            column: i
          },
          isActive: true
        }
      };
    }
    return n.key === "c" && (n.ctrlKey || n.metaKey) ? (n.preventDefault(), n.stopPropagation(), l) : n.key === "v" && (n.ctrlKey || n.metaKey) ? l : null;
  }
  function Wy(l, n, r) {
    var _a;
    if (r && (r.ctrlKey || r.metaKey)) {
      const d = kC(l, r);
      if (d) return d;
    }
    let o = null;
    if (((_a = l.selection) == null ? void 0 : _a.isActive) && (n.length === 1 || n === "Backspace" || n === "Delete") && (l = EC(l), n === "Backspace" || n === "Delete")) return l;
    const i = l.content.split(`
`), c = i[l.cursorPosition.line];
    switch (n) {
      case "Enter": {
        if (r == null ? void 0 : r.preventDefault(), r == null ? void 0 : r.stopPropagation(), !(r == null ? void 0 : r.shiftKey)) return null;
        const d = c.slice(0, l.cursorPosition.column), f = c.slice(l.cursorPosition.column), g = [
          ...i
        ];
        g[l.cursorPosition.line] = d, g.splice(l.cursorPosition.line + 1, 0, f), o = {
          ...l,
          content: g.join(`
`),
          cursorPosition: {
            line: l.cursorPosition.line + 1,
            column: 0
          },
          selection: void 0
        };
        break;
      }
      case "Backspace": {
        if (r == null ? void 0 : r.preventDefault(), r == null ? void 0 : r.stopPropagation(), l.cursorPosition.column > 0) {
          const d = [
            ...i
          ];
          d[l.cursorPosition.line] = c.slice(0, l.cursorPosition.column - 1) + c.slice(l.cursorPosition.column), o = {
            ...l,
            content: d.join(`
`),
            cursorPosition: {
              ...l.cursorPosition,
              column: l.cursorPosition.column - 1
            },
            selection: void 0
          };
        } else if (l.cursorPosition.line > 0) {
          const d = i[l.cursorPosition.line - 1], f = [
            ...i
          ];
          f.splice(l.cursorPosition.line - 1, 2, d + c), o = {
            ...l,
            content: f.join(`
`),
            cursorPosition: {
              line: l.cursorPosition.line - 1,
              column: d.length
            },
            selection: void 0
          };
        }
        break;
      }
      case "Delete": {
        if (r == null ? void 0 : r.preventDefault(), r == null ? void 0 : r.stopPropagation(), l.cursorPosition.column < c.length) {
          const d = [
            ...i
          ];
          d[l.cursorPosition.line] = c.slice(0, l.cursorPosition.column) + c.slice(l.cursorPosition.column + 1), o = {
            ...l,
            content: d.join(`
`),
            cursorPosition: l.cursorPosition,
            selection: void 0
          };
        } else if (l.cursorPosition.line < i.length - 1) {
          const d = i[l.cursorPosition.line + 1], f = [
            ...i
          ];
          f.splice(l.cursorPosition.line, 2, c + d), o = {
            ...l,
            content: f.join(`
`),
            cursorPosition: l.cursorPosition,
            selection: void 0
          };
        }
        break;
      }
      case "ArrowLeft":
      case "ArrowRight":
      case "ArrowUp":
      case "ArrowDown":
      case "Home":
      case "End":
        o = _C(l, n, r);
        break;
      default:
        if (n.length === 1) {
          r == null ? void 0 : r.preventDefault(), r == null ? void 0 : r.stopPropagation();
          const d = [
            ...i
          ];
          d[l.cursorPosition.line] = c.slice(0, l.cursorPosition.column) + n + c.slice(l.cursorPosition.column), o = {
            ...l,
            content: d.join(`
`),
            cursorPosition: {
              ...l.cursorPosition,
              column: l.cursorPosition.column + 1
            },
            selection: void 0
          };
        }
        break;
    }
    return o || l;
  }
  function Jy(l) {
    return Math.round(l / xe) * xe;
  }
  function MC(l, n, r) {
    const o = nn((p) => p.isEditingText), i = m.useRef(null), c = m.useCallback(() => {
      const p = nn.getState().activeText;
      if (!p || !p.content.trim() || !n || !r) {
        nn.getState().stopEditing();
        return;
      }
      const v = ve.getState().layers.get(ve.getState().activeLayerId), b = (v == null ? void 0 : v.layerNumber) ?? 1, S = (v == null ? void 0 : v.datatype) ?? 0, C = new z0(p.content, p.x, p.y, e0 * xe, b, S);
      ce.getState().execute(C, {
        library: n,
        renderer: r
      }), Se.getState().bumpSyncGeneration(), nn.getState().stopEditing();
    }, [
      n,
      r
    ]), d = m.useCallback(() => {
      nn.getState().stopEditing();
    }, []), f = m.useCallback((p) => {
      if (p.button !== 0) return;
      const b = p.currentTarget.getBoundingClientRect(), S = p.clientX - b.left, C = p.clientY - b.top, k = l(S, C);
      if (!k) return;
      if (o) {
        c();
        return;
      }
      const x = Jy(k.x), E = Jy(k.y);
      nn.getState().startEditing(x, E);
    }, [
      l,
      o,
      c
    ]), g = m.useCallback((p) => {
    }, []);
    return m.useEffect(() => {
      if (!o) return;
      const p = (v) => {
        const b = nn.getState().activeText;
        if (!b) return;
        if (v.key === "Escape") {
          v.preventDefault(), v.stopPropagation(), d(), Gt.getState().setTool("select");
          return;
        }
        if (v.key === "c" && (v.ctrlKey || v.metaKey)) {
          const C = CC(b);
          C && (v.preventDefault(), navigator.clipboard.writeText(C));
          return;
        }
        if (v.key === "v" && (v.ctrlKey || v.metaKey)) {
          v.preventDefault(), v.stopPropagation(), navigator.clipboard.readText().then((C) => {
            if (!C) return;
            const k = nn.getState().activeText;
            if (!k) return;
            let x = k;
            for (const E of C) {
              const _ = Wy(x, E === `
` ? "Enter" : E, {
                shiftKey: E === `
`,
                ctrlKey: false,
                metaKey: false,
                preventDefault: () => {
                },
                stopPropagation: () => {
                },
                key: E === `
` ? "Enter" : E
              });
              _ && (x = _);
            }
            nn.getState().setActiveText(x);
          });
          return;
        }
        const S = Wy(b, v.key, v);
        if (S === null) {
          c();
          return;
        }
        S !== b && (nn.getState().setActiveText(S), nn.getState().resetCursor());
      };
      return window.addEventListener("keydown", p, true), () => window.removeEventListener("keydown", p, true);
    }, [
      o,
      c,
      d
    ]), m.useEffect(() => (o && (i.current = setInterval(() => {
      nn.getState().toggleCursor();
    }, CS)), () => {
      i.current && (clearInterval(i.current), i.current = null);
    }), [
      o
    ]), {
      handleMouseDown: f,
      handleMouseMove: g,
      commitText: c,
      cancelEditing: d,
      isEditing: o
    };
  }
  const eb = 12, jC = 8, LC = 140, RC = 56;
  function tb(l, n, r, o, i) {
    const c = n.x * r + o.x, d = n.y * r + o.y, f = l.x - c, g = l.y - d;
    return f * f + g * g <= i * i;
  }
  function AC(l, n, r, o, i, c) {
    const d = l - r, f = n - o, g = i - r, p = c - o, v = d * g + f * p, b = g * g + p * p;
    if (b === 0) return Math.sqrt(d * d + f * f);
    const S = Math.max(0, Math.min(1, v / b)), C = r + S * g, k = o + S * p, x = l - C, E = n - k;
    return Math.sqrt(x * x + E * E);
  }
  function TC(l, n, r, o, i, c) {
    const d = r.start.x * o + i.x, f = r.start.y * o + i.y, g = r.end.x * o + i.x, p = r.end.y * o + i.y;
    return AC(l, n, d, f, g, p) <= c;
  }
  function NC(l, n, r, o, i) {
    const c = r.start.x * o + i.x, d = r.start.y * o + i.y, f = r.end.x * o + i.x, g = r.end.y * o + i.y, p = (c + f) / 2, v = (d + g) / 2, b = LC / 2, S = RC / 2;
    return l >= p - b && l <= p + b && n >= v - S && n <= v + S;
  }
  function nb(l, n, r, o, i, c) {
    const d = {
      x: l,
      y: n
    };
    for (const f of r.values()) if (f.id !== c) {
      if (tb(d, f.start, o, i, eb)) return {
        rulerId: f.id,
        endpoint: "start"
      };
      if (tb(d, f.end, o, i, eb)) return {
        rulerId: f.id,
        endpoint: "end"
      };
    }
    return null;
  }
  function lb(l, n, r, o, i, c) {
    for (const d of r.values()) if (d.id !== c && (NC(l, n, d, o, i) || TC(l, n, d, o, i, jC))) return d.id;
    return null;
  }
  function OC(l, n, r, o, i) {
    const c = Gt((F) => F.activeTool), { rulers: d, activeRulerId: f, selectedRulerIds: g, hoveredRulerId: p, draggingEndpoint: v, isMovingRuler: b, startRuler: S, updatePreview: C, finalizeRuler: k, cancelCreation: x, updateEndpoint: E, setHoveredEndpoint: _, setDraggingEndpoint: N, endDraggingEndpoint: A, selectRuler: R, toggleSelection: I, addToSelection: T, clearSelection: L, setHoveredRuler: D, startMoveRuler: H, moveRuler: q, endMoveRuler: re, setSnapPoint: ee } = Oe();
    m.useEffect(() => {
      c !== "ruler" && (f && x(), _(null), D(null));
    }, [
      c,
      f,
      x,
      _,
      D
    ]);
    const de = m.useCallback((F) => {
      if (F.button !== 0) return;
      const ye = F.currentTarget.getBoundingClientRect(), ke = F.clientX - ye.left, j = F.clientY - ye.top, O = l(ke, j);
      if (!O) return;
      const K = $f(n), J = qf(ke, j, O.x, O.y, K, o, i, F.shiftKey).point, ie = nb(ke, j, d, o, i, f ?? void 0);
      if (ie) {
        F.shiftKey ? T([
          ie.rulerId
        ]) : F.metaKey || F.ctrlKey ? I(ie.rulerId) : R(ie.rulerId), N(ie);
        return;
      }
      const pe = lb(ke, j, d, o, i, f ?? void 0);
      if (pe) {
        F.shiftKey ? T([
          pe
        ]) : F.metaKey || F.ctrlKey ? I(pe) : g.has(pe) ? H(J) : R(pe);
        return;
      }
      if (f) {
        const Re = k(J);
        if (ee(null), Re && n && r) {
          const X = new e2(Re);
          ce.getState().pushCommand(X);
        }
      } else g.size > 0 && !F.shiftKey && !F.metaKey && !F.ctrlKey ? L() : g.size === 0 && S(J);
    }, [
      l,
      n,
      r,
      d,
      o,
      i,
      f,
      g,
      S,
      k,
      N,
      R,
      I,
      T,
      L,
      H,
      ee
    ]), ge = m.useCallback((F) => {
      const ye = F.currentTarget.getBoundingClientRect(), ke = F.clientX - ye.left, j = F.clientY - ye.top, O = l(ke, j);
      if (!O) return;
      const K = $f(n), W = qf(ke, j, O.x, O.y, K, o, i, F.shiftKey), J = W.point;
      if (b) {
        q(J), ee(W.isGeometrySnap ? J : null);
        return;
      }
      if (v) {
        E(v.rulerId, v.endpoint, J), ee(W.isGeometrySnap ? J : null);
        return;
      }
      if (f) {
        C(J), ee(W.isGeometrySnap ? J : null);
        return;
      }
      const ie = nb(ke, j, d, o, i);
      _(ie);
      const pe = ie ? ie.rulerId : lb(ke, j, d, o, i);
      D(pe), !ie && !pe && g.size === 0 ? ee(W.isGeometrySnap ? J : null) : ee(null);
    }, [
      l,
      n,
      d,
      o,
      i,
      f,
      v,
      b,
      g,
      C,
      E,
      q,
      _,
      D,
      ee
    ]), Ee = m.useCallback(() => {
      if (v) {
        const F = A();
        if (ee(null), F && n && r) {
          const fe = new j0(F.rulerId, F.endpoint, F.oldPosition, F.newPosition);
          ce.getState().pushCommand(fe);
        }
      }
      if (b) {
        const F = re();
        if (F && n && r) {
          const fe = new M0(F.rulerIds, F.deltaX, F.deltaY);
          ce.getState().pushCommand(fe);
        }
      }
    }, [
      v,
      b,
      A,
      re,
      n,
      r,
      ee
    ]), $ = m.useCallback(() => {
      x(), _(null), D(null), N(null), ee(null);
    }, [
      x,
      _,
      D,
      N,
      ee
    ]);
    return {
      handleMouseDown: de,
      handleMouseMove: ge,
      handleMouseUp: Ee,
      cancelDrawing: $,
      isCreating: f !== null,
      isDraggingEndpoint: v !== null,
      isMovingRuler: b,
      hoveredRulerId: p,
      selectedRulerIds: g
    };
  }
  const Hi = "#ff0000", $d = 4;
  function IC() {
    const [l, n] = m.useState({
      x: 0,
      y: 0
    });
    return m.useEffect(() => {
      const r = (o) => {
        n({
          x: o.clientX,
          y: o.clientY
        });
      };
      return window.addEventListener("mousemove", r), () => window.removeEventListener("mousemove", r);
    }, []), y.jsx("div", {
      className: "pointer-events-none fixed z-50",
      style: {
        width: "8px",
        height: "8px",
        borderRadius: "50%",
        backgroundColor: Hi,
        boxShadow: `
          0 0 ${$d}px ${Hi},
          0 0 ${$d * 2}px ${Hi},
          0 0 ${$d * 3}px ${Hi}`,
        opacity: 0.9,
        left: 0,
        top: 0,
        transform: `translate(${l.x - 4}px, ${l.y - 4}px)`,
        willChange: "transform"
      }
    });
  }
  const DC = "rgba(46, 229, 120, 0.1)", zC = "rgba(46, 229, 120, 0.6)";
  function HC({ box: l }) {
    const n = l.width >= 0 ? l.x : l.x + l.width, r = l.height >= 0 ? l.y : l.y + l.height, o = Math.abs(l.width), i = Math.abs(l.height);
    return o < 2 && i < 2 ? null : y.jsx("div", {
      className: "pointer-events-none absolute",
      style: {
        left: n,
        top: r,
        width: o,
        height: i,
        backgroundColor: DC,
        border: `1px solid ${zC}`
      }
    });
  }
  const UC = "rgba(59, 130, 246, 0.1)", YC = "rgba(59, 130, 246, 0.6)";
  function BC({ box: l }) {
    const n = l.width >= 0 ? l.x : l.x + l.width, r = l.height >= 0 ? l.y : l.y + l.height, o = Math.abs(l.width), i = Math.abs(l.height);
    return o < 2 && i < 2 ? null : y.jsx("div", {
      className: "pointer-events-none absolute",
      style: {
        left: n,
        top: r,
        width: o,
        height: i,
        backgroundColor: UC,
        border: `1px solid ${YC}`
      }
    });
  }
  function XC({ points: l, cursorPoint: n, isNearStart: r, alignmentGuides: o }) {
    var _a;
    const { zoom: i, offset: c } = Ve(), d = ve((A) => A.activeLayerId), p = ((_a = ve((A) => A.layers).get(d)) == null ? void 0 : _a.color) ?? "#888888", v = (A) => ({
      x: A.x * i + c.x,
      y: A.y * i + c.y
    });
    if (l.length === 0) return null;
    const S = (n ? [
      ...l,
      n
    ] : l).map(v), C = S.map((A, R) => `${R === 0 ? "M" : "L"} ${A.x} ${A.y}`).join(" "), k = l.length >= 3 && n ? `M ${S[S.length - 1].x} ${S[S.length - 1].y} L ${S[0].x} ${S[0].y}` : "", x = S[0], E = n ? v(n) : null, _ = (o == null ? void 0 : o.alignedVertexX) ? v(o.alignedVertexX) : null, N = (o == null ? void 0 : o.alignedVertexY) ? v(o.alignedVertexY) : null;
    return y.jsxs("svg", {
      className: "pointer-events-none absolute inset-0 h-full w-full overflow-visible",
      children: [
        E && _ && y.jsx("line", {
          x1: _.x,
          y1: _.y,
          x2: E.x,
          y2: E.y,
          stroke: Bn.dark,
          strokeWidth: 1,
          strokeDasharray: "3 3",
          opacity: 0.5
        }),
        E && N && y.jsx("line", {
          x1: N.x,
          y1: N.y,
          x2: E.x,
          y2: E.y,
          stroke: Bn.dark,
          strokeWidth: 1,
          strokeDasharray: "3 3",
          opacity: 0.5
        }),
        r && y.jsx("circle", {
          cx: x.x,
          cy: x.y,
          r: 9,
          fill: "none",
          stroke: p,
          strokeWidth: 1.5,
          opacity: 0.5,
          className: "animate-pulse"
        }),
        y.jsx("path", {
          d: C,
          fill: "none",
          stroke: p,
          strokeWidth: 1.5,
          strokeDasharray: "6 4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }),
        k && y.jsx("path", {
          d: k,
          fill: "none",
          stroke: p,
          strokeWidth: r ? 2 : 1,
          strokeDasharray: r ? "none" : "4 4",
          strokeLinecap: "round",
          opacity: r ? 0.8 : 0.5
        }),
        l.map((A, R) => {
          const I = S[R];
          return y.jsx("circle", {
            cx: I.x,
            cy: I.y,
            r: R === 0 ? 4 : 2.5,
            fill: R === 0 ? p : "white",
            stroke: p,
            strokeWidth: 1
          }, R);
        })
      ]
    });
  }
  function VC({ waypoints: l, cursorPoint: n, alignmentGuides: r }) {
    var _a;
    const { zoom: o, offset: i } = Ve(), c = ve((D) => D.activeLayerId), d = ve((D) => D.layers), f = rn((D) => D.width), g = rn((D) => D.cornerRadius), p = rn((D) => D.numArcPoints), b = ((_a = d.get(c)) == null ? void 0 : _a.color) ?? "#888888", S = (D) => ({
      x: D.x * o + i.x,
      y: D.y * o + i.y
    });
    if (l.length === 0) return null;
    const C = l[l.length - 1], k = n && C && Math.abs(n.x - C.x) < 1e-6 && Math.abs(n.y - C.y) < 1e-6, x = n && !k ? [
      ...l,
      n
    ] : l, E = x.map(S), _ = E.map((D, H) => `${H === 0 ? "M" : "L"} ${D.x} ${D.y}`).join(" "), A = WS(x, f, g, p).map(S), R = A.length > 0 ? A.map((D, H) => `${H === 0 ? "M" : "L"} ${D.x} ${D.y}`).join(" ") + " Z" : "", I = n ? S(n) : null, T = (r == null ? void 0 : r.alignedVertexX) ? S(r.alignedVertexX) : null, L = (r == null ? void 0 : r.alignedVertexY) ? S(r.alignedVertexY) : null;
    return y.jsxs("svg", {
      className: "pointer-events-none absolute inset-0 h-full w-full overflow-visible",
      children: [
        I && T && y.jsx("line", {
          x1: T.x,
          y1: T.y,
          x2: I.x,
          y2: I.y,
          stroke: Bn.dark,
          strokeWidth: 1,
          strokeDasharray: "3 3",
          opacity: 0.5
        }),
        I && L && y.jsx("line", {
          x1: L.x,
          y1: L.y,
          x2: I.x,
          y2: I.y,
          stroke: Bn.dark,
          strokeWidth: 1,
          strokeDasharray: "3 3",
          opacity: 0.5
        }),
        R && y.jsx("path", {
          d: R,
          fill: b,
          fillOpacity: 0.15,
          stroke: "none"
        }),
        R && y.jsx("path", {
          d: R,
          fill: "none",
          stroke: b,
          strokeWidth: 1,
          strokeOpacity: 0.4
        }),
        y.jsx("path", {
          d: _,
          fill: "none",
          stroke: b,
          strokeWidth: 1.5,
          strokeDasharray: "6 4",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }),
        l.map((D, H) => {
          const q = E[H];
          return y.jsx("circle", {
            cx: q.x,
            cy: q.y,
            r: H === 0 ? 4 : 2.5,
            fill: H === 0 ? b : "white",
            stroke: b,
            strokeWidth: 1
          }, H);
        })
      ]
    });
  }
  function hh(l) {
    const n = 1 / (l * xe), r = Jv * n;
    return r >= wy ? {
      unit: "mm",
      scale: wy
    } : r >= Sy ? {
      unit: "\xB5m",
      scale: Sy
    } : {
      unit: "nm",
      scale: 1
    };
  }
  function $C(l) {
    return Number.isFinite(l) ? l : 0;
  }
  function nt(l, n) {
    const r = $C(l) / n.scale;
    return Math.abs(r) >= 1e6 ? r.toExponential(3) : r.toFixed(3);
  }
  const qC = {
    dark: {
      line: "#8b959f",
      text: "#8b959f",
      background: "#1a1d21",
      border: "#8b959f",
      endpoint: "#8b959f",
      hover: "#ffffff"
    },
    light: {
      line: "#4b5563",
      text: "#4b5563",
      background: "rgba(255, 255, 255, 0.95)",
      border: "#4b5563",
      endpoint: "#4b5563",
      hover: "#000000"
    }
  }, rb = 3, ab = 5, GC = 6, PC = {
    dark: {
      fill: "rgba(68, 255, 68, 0.3)",
      stroke: Bn.dark
    },
    light: {
      fill: "rgba(68, 255, 68, 0.3)",
      stroke: Bn.light
    }
  };
  function KC(l, n) {
    const r = Math.abs(n.x - l.x) / xe, o = Math.abs(n.y - l.y) / xe, i = Math.sqrt(r * r + o * o);
    return {
      dx: r,
      dy: o,
      diagonal: i
    };
  }
  function ZC({ point: l, worldToScreen: n, theme: r }) {
    const o = PC[r], i = n(l), c = GC;
    return y.jsxs("g", {
      children: [
        y.jsx("circle", {
          cx: i.x,
          cy: i.y,
          r: c,
          fill: o.fill,
          stroke: o.stroke,
          strokeWidth: 2
        }),
        y.jsx("line", {
          x1: i.x - c - 2,
          y1: i.y,
          x2: i.x + c + 2,
          y2: i.y,
          stroke: o.stroke,
          strokeWidth: 1.5
        }),
        y.jsx("line", {
          x1: i.x,
          y1: i.y - c - 2,
          x2: i.x,
          y2: i.y + c + 2,
          stroke: o.stroke,
          strokeWidth: 1.5
        })
      ]
    });
  }
  function FC({ ruler: l, worldToScreen: n, hoveredEndpoint: r, isSelected: o, isHovered: i, isDragging: c, theme: d, zoom: f }) {
    const g = qC[d], p = Bn[d], v = n(l.start), b = n(l.end), S = o ? p : i ? g.hover : g.line, C = o ? p : i ? g.hover : g.border, k = o || i || c ? 2 : 1.5, x = {
      x: (v.x + b.x) / 2,
      y: (v.y + b.y) / 2
    }, { dx: E, dy: _, diagonal: N } = KC(l.start, l.end), A = hh(f), R = `${nt(E, A)} ${A.unit}`, I = `${nt(_, A)} ${A.unit}`, T = `${nt(N, A)} ${A.unit}`, L = 140, D = 56;
    return y.jsxs("g", {
      children: [
        y.jsx("line", {
          x1: v.x,
          y1: v.y,
          x2: b.x,
          y2: b.y,
          stroke: S,
          strokeWidth: k,
          strokeDasharray: "6 4",
          strokeLinecap: "round"
        }),
        y.jsx("foreignObject", {
          x: x.x - L / 2,
          y: x.y - D / 2,
          width: L,
          height: D,
          overflow: "visible",
          children: y.jsx("div", {
            style: {
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            },
            children: y.jsxs("div", {
              style: {
                backgroundColor: g.background,
                border: `1px solid ${C}`,
                borderRadius: "4px",
                padding: "4px 8px",
                fontFamily: "monospace",
                fontSize: "11px",
                color: g.text,
                lineHeight: "14px",
                whiteSpace: "nowrap"
              },
              children: [
                y.jsxs("div", {
                  children: [
                    y.jsx("span", {
                      style: {
                        opacity: 0.7
                      },
                      children: "\u0394x"
                    }),
                    " ",
                    R
                  ]
                }),
                y.jsxs("div", {
                  children: [
                    y.jsx("span", {
                      style: {
                        opacity: 0.7
                      },
                      children: "\u0394y"
                    }),
                    " ",
                    I
                  ]
                }),
                y.jsxs("div", {
                  children: [
                    y.jsx("span", {
                      style: {
                        opacity: 0.7
                      },
                      children: "\u0394d"
                    }),
                    " ",
                    T
                  ]
                })
              ]
            })
          })
        }),
        y.jsx("circle", {
          cx: v.x,
          cy: v.y,
          r: r === "start" ? ab : rb,
          fill: o ? p : r === "start" ? g.hover : g.endpoint,
          stroke: o ? p : r === "start" ? g.hover : "none",
          strokeWidth: r === "start" || o ? 2 : 0,
          style: {
            transition: "r 0.1s, fill 0.1s"
          }
        }),
        y.jsx("circle", {
          cx: b.x,
          cy: b.y,
          r: r === "end" ? ab : rb,
          fill: o ? p : r === "end" ? g.hover : g.endpoint,
          stroke: o ? p : r === "end" ? g.hover : "none",
          strokeWidth: r === "end" || o ? 2 : 0,
          style: {
            transition: "r 0.1s, fill 0.1s"
          }
        })
      ]
    });
  }
  function QC() {
    const { zoom: l, offset: n } = Ve(), r = me((S) => S.theme), { rulers: o, activeRulerId: i, selectedRulerIds: c, hoveredRulerId: d, marqueePreviewIds: f, hoveredEndpoint: g, draggingEndpoint: p, snapPoint: v } = Oe(), b = (S) => ({
      x: S.x * l + n.x,
      y: S.y * l + n.y
    });
    return o.size === 0 && !v ? null : y.jsxs("svg", {
      className: "pointer-events-none absolute inset-0 h-full w-full overflow-visible",
      children: [
        Array.from(o.values()).map((S) => {
          const C = S.id === i, k = c.has(S.id), x = S.id === d || f.has(S.id), E = (g == null ? void 0 : g.rulerId) === S.id, _ = (p == null ? void 0 : p.rulerId) === S.id;
          return y.jsx(FC, {
            ruler: S,
            worldToScreen: b,
            hoveredEndpoint: E ? g.endpoint : _ ? p.endpoint : null,
            isSelected: k,
            isHovered: x && !k,
            isDragging: _ || C,
            theme: r,
            zoom: l
          }, S.id);
        }),
        v && y.jsx(ZC, {
          point: v,
          worldToScreen: b,
          theme: r
        })
      ]
    });
  }
  const ob = "ref:";
  function K0(l) {
    if (!l.startsWith(ob)) return null;
    const n = l.slice(ob.length), r = n.indexOf(":");
    if (r === -1) return null;
    const o = Number.parseInt(n.slice(0, r), 10);
    return Number.isNaN(o) ? null : o;
  }
  function WC(l) {
    const n = /* @__PURE__ */ new Set();
    for (const r of l) {
      const o = K0(r);
      o !== null && n.add(o);
    }
    return n;
  }
  const Un = 9;
  function JC(l, n, r, o) {
    if (!l) return null;
    const i = `ref:${n}:0`, c = l.get_cell_ref_info(i);
    if (!c) return null;
    const [d, f, g, p, v, b] = c.transform, S = c.cell_name;
    c.free();
    const C = l.get_cell_origin_by_name(S), k = C ? C[0] : 0, x = C ? C[1] : 0, E = d * k + f * x + v, _ = g * k + p * x + b;
    return {
      x: E * r + o.x,
      y: _ * r + o.y
    };
  }
  function e5() {
    const { zoom: l, offset: n } = Ve(), r = Se((b) => b.library), i = me((b) => b.theme) === "dark";
    Se((b) => b.syncGeneration), ue((b) => b.activeCell);
    const c = se((b) => b.selectedIds), d = se((b) => b.hoveredId), f = WC(c);
    if (d) {
      const b = K0(d);
      b !== null && f.add(b);
    }
    if (f.size === 0) return null;
    let g = [];
    if (r) try {
      const b = r.get_instance_label_data();
      b && Array.isArray(b) && (g = b);
    } catch {
      return null;
    }
    const p = g.filter((b) => f.has(b.elementIndex));
    if (p.length === 0) return null;
    const v = i ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.5)";
    return y.jsx(y.Fragment, {
      children: p.map((b) => {
        const S = b.minX * l + n.x, C = b.minY * l + n.y, k = JC(r, b.elementIndex, l, n);
        return y.jsxs("div", {
          children: [
            y.jsx("div", {
              className: Y("pointer-events-none absolute text-[13px] leading-none font-mono select-none", i ? "text-white" : "text-black"),
              style: {
                left: `${S}px`,
                top: `${C}px`,
                transform: "translateY(-100%)",
                paddingBottom: "2px"
              },
              children: b.name
            }),
            k && y.jsxs("svg", {
              className: "pointer-events-none absolute top-0 left-0 select-none",
              style: {
                width: `${Un * 2 + 1}px`,
                height: `${Un * 2 + 1}px`,
                transform: `translate(${k.x - Un}px, ${k.y - Un}px)`
              },
              viewBox: `0 0 ${Un * 2 + 1} ${Un * 2 + 1}`,
              children: [
                y.jsx("line", {
                  x1: "0",
                  y1: Un,
                  x2: Un * 2,
                  y2: Un,
                  stroke: v,
                  strokeWidth: "1"
                }),
                y.jsx("line", {
                  x1: Un,
                  y1: "0",
                  x2: Un,
                  y2: Un * 2,
                  stroke: v,
                  strokeWidth: "1"
                })
              ]
            })
          ]
        }, `inst-${b.elementIndex}`);
      })
    });
  }
  function t5(l, n) {
    const r = n / rh, o = l.split(`
`), i = Math.max(1, ...o.map((f) => f.length)), c = r * 0.6 * i, d = r * 1.2 * o.length;
    return {
      width: c,
      totalHeight: d
    };
  }
  function n5({ label: l, zoom: n, offset: r, color: o, isSelected: i, isHovered: c }) {
    const d = l.height / rh * n;
    if (d < 1) return null;
    const { width: f, totalHeight: g } = t5(l.text, l.height), p = l.x * n + r.x, v = (l.y - g) * n + r.y, b = i || c;
    let S;
    if (b) {
      const C = f * n, k = g * n, x = i ? "rgba(68, 255, 68, 0.8)" : o;
      S = {
        position: "absolute",
        left: "-3px",
        top: "-3px",
        width: `${C + 6}px`,
        height: `${k + 6}px`,
        border: `1.5px solid ${x}`,
        borderRadius: "1px",
        pointerEvents: "none"
      };
    }
    return y.jsxs("div", {
      className: "pointer-events-none absolute top-0 left-0 select-none whitespace-pre",
      style: {
        transform: `translate(${p}px, ${v}px)`,
        fontSize: `${d}px`,
        lineHeight: 1.2,
        fontFamily: t0,
        color: i ? "rgb(68, 255, 68)" : o
      },
      children: [
        b && y.jsx("div", {
          style: S
        }),
        l.text
      ]
    });
  }
  function l5({ zoom: l, offset: n, color: r }) {
    const o = nn((_) => _.activeText), i = nn((_) => _.showCursor);
    if (!o) return null;
    const c = e0 * xe / rh * l;
    if (c < 1) return null;
    const d = c * 1.2, f = c * 0.6, g = o.content.split(`
`), p = d * Math.max(1, g.length), v = o.x * l + n.x, b = o.y * l + n.y - p, S = fh(o.selection), C = o.cursorPosition.line, x = o.cursorPosition.column * f, E = C * d;
    return y.jsxs("div", {
      className: "pointer-events-none absolute top-0 left-0 select-none",
      style: {
        transform: `translate(${v}px, ${b}px)`,
        fontSize: `${c}px`,
        lineHeight: `${d}px`,
        fontFamily: t0,
        color: r
      },
      children: [
        g.map((_, N) => {
          if (!(S && N >= S.start.line && N <= S.end.line)) return y.jsx("div", {
            style: {
              height: `${d}px`,
              whiteSpace: "pre"
            },
            children: _ || "\u200B"
          }, N);
          const R = N === S.start.line ? S.start.column : 0, I = N === S.end.line ? S.end.column : _.length, T = _.substring(0, R), L = _.substring(R, I), D = _.substring(I);
          return y.jsxs("div", {
            style: {
              height: `${d}px`,
              whiteSpace: "pre"
            },
            children: [
              T && y.jsx("span", {
                children: T
              }),
              L && y.jsx("span", {
                style: {
                  backgroundColor: "rgba(65, 105, 225, 0.7)",
                  color: "#ffffff"
                },
                children: L
              }),
              D && y.jsx("span", {
                children: D
              }),
              !_ && "\u200B"
            ]
          }, N);
        }),
        i && y.jsx("div", {
          className: "absolute",
          style: {
            left: `${x}px`,
            top: `${E}px`,
            width: "2px",
            height: `${d}px`,
            backgroundColor: r
          }
        })
      ]
    });
  }
  function r5() {
    var _a;
    const { zoom: l, offset: n } = Ve(), r = Se((_) => _.library), i = me((_) => _.theme) === "dark", c = nn((_) => _.isEditingText), d = Se((_) => _.syncGeneration), f = ue((_) => _.activeCell), g = se((_) => _.selectedIds), p = se((_) => _.hoveredId), v = ve((_) => _.layers), b = ve((_) => _.activeLayerId), S = m.useMemo(() => {
      if (!r) return [];
      try {
        const _ = r.get_text_labels();
        if (_ && Array.isArray(_)) return _;
      } catch {
      }
      return [];
    }, [
      r,
      d,
      f
    ]), k = ((_a = v.get(b)) == null ? void 0 : _a.color) ?? (i ? "#ffffff" : "#000000"), x = (_, N) => {
      for (const A of v.values()) if (A.layerNumber === _ && A.datatype === N) return A.color;
      return i ? "#ffffff" : "#000000";
    };
    return S.length > 0 || c ? y.jsxs("div", {
      className: Y("pointer-events-none absolute inset-0 overflow-hidden"),
      children: [
        S.map((_) => y.jsx(n5, {
          label: _,
          zoom: l,
          offset: n,
          color: x(_.layer, _.datatype),
          isSelected: g.has(_.id),
          isHovered: p === _.id
        }, _.id)),
        c && y.jsx(l5, {
          zoom: l,
          offset: n,
          color: k
        })
      ]
    }) : null;
  }
  function a5() {
    const { zoom: l, offset: n } = Ve(), r = se((S) => S.selectedIds), o = se((S) => S.hoveredId), i = rn((S) => S.pathMetadata), c = me((S) => S.theme), d = c === "dark" ? Bn.dark : Bn.light, f = c === "dark" ? tc.dark : tc.light, g = (S) => ({
      x: S.x * l + n.x,
      y: S.y * l + n.y
    }), p = [];
    for (const S of r) {
      const C = i.get(S);
      C && C.waypoints.length >= 2 && p.push({
        meta: C,
        color: d
      });
    }
    let v = null;
    if (o && !r.has(o)) {
      const S = i.get(o);
      S && S.waypoints.length >= 2 && (v = {
        meta: S,
        color: f
      });
    }
    const b = v ? [
      ...p,
      v
    ] : p;
    return b.length === 0 ? null : y.jsx("svg", {
      className: "pointer-events-none absolute inset-0 h-full w-full overflow-visible",
      children: b.map(({ meta: S, color: C }, k) => {
        const x = S.waypoints.map(g), E = x.map((_, N) => `${N === 0 ? "M" : "L"} ${_.x} ${_.y}`).join(" ");
        return y.jsxs("g", {
          children: [
            y.jsx("path", {
              d: E,
              fill: "none",
              stroke: C,
              strokeWidth: 1,
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeOpacity: 0.8
            }),
            x.map((_, N) => y.jsx("circle", {
              cx: _.x,
              cy: _.y,
              r: 3,
              fill: C,
              fillOpacity: 0.9
            }, N))
          ]
        }, k);
      })
    });
  }
  function o5({ entry: l, zoom: n, offset: r, isSelected: o, isHovered: i, isDark: c }) {
    const d = l.x * n + r.x, f = l.y * n + r.y, g = l.width * n, p = l.height * n;
    if (g < 1 && p < 1) return null;
    const v = o || i, b = o ? "rgba(68, 255, 68, 0.8)" : c ? "rgba(255, 255, 255, 0.8)" : "rgba(0, 0, 0, 0.8)";
    return y.jsxs("div", {
      className: "pointer-events-none absolute top-0 left-0",
      style: {
        transform: `translate(${d}px, ${f}px)`,
        width: `${g}px`,
        height: `${p}px`
      },
      children: [
        y.jsx("img", {
          src: l.url,
          alt: l.filename,
          className: "block h-full w-full",
          style: {
            objectFit: "fill"
          },
          draggable: false
        }),
        v && y.jsx("div", {
          className: "pointer-events-none absolute inset-0",
          style: {
            border: `1.5px solid ${b}`
          }
        })
      ]
    });
  }
  function s5() {
    const { zoom: l, offset: n } = Ve(), r = Bt((f) => f.images), o = se((f) => f.selectedIds), i = se((f) => f.hoveredId), d = me((f) => f.theme) === "dark";
    return r.size === 0 ? null : y.jsx("div", {
      className: Y("pointer-events-none absolute inset-0 overflow-hidden"),
      children: [
        ...r.values()
      ].map((f) => {
        const g = ss(f.id);
        return y.jsx(o5, {
          entry: f,
          zoom: l,
          offset: n,
          isSelected: o.has(g),
          isHovered: i === g,
          isDark: d
        }, f.id);
      })
    });
  }
  function Pa(l, n) {
    m.useEffect(() => {
      if (n) return Xf.getState().claim(l), () => {
        Xf.getState().release(l);
      };
    }, [
      l,
      n
    ]);
  }
  function i5(l) {
    return "separator" in l && l.separator;
  }
  function c5({ library: l, renderer: n, canvasRef: r }) {
    const o = m.useRef(null), { isOpen: i, position: c, variant: d, targetId: f, close: g } = os(), { selectedIds: p } = se(), { hasContent: v } = Xn(), S = me((A) => A.theme) === "dark";
    Pa("context-menu", i);
    const C = l ? l.get_all_ids().length > 0 : false, k = p.size > 0, E = m.useCallback(() => {
      const A = () => {
        if (!l) return;
        const D = xr(l, p);
        Xn.getState().copy(D), g();
      }, R = () => {
        if (!l || !n) return;
        const D = new fc();
        ce.getState().execute(D, {
          library: l,
          renderer: n
        });
        const H = r.current;
        H && qr(l, H), g();
      }, I = () => {
        if (!l || !n || p.size === 0) return;
        const D = new hc([
          ...p
        ]);
        ce.getState().execute(D, {
          library: l,
          renderer: n
        });
        const H = r.current;
        H && qr(l, H), g();
      }, T = () => {
        if (!l || !n || p.size === 0) return;
        const D = new dc([
          ...p
        ]);
        ce.getState().execute(D, {
          library: l,
          renderer: n
        }), g();
      }, L = () => {
        if (!l) return;
        const D = l.get_all_ids();
        se.getState().selectAll(D), g();
      };
      if (d === "element") return [
        {
          id: "edit",
          label: "Edit",
          shortcut: {
            key: "E"
          },
          action: () => {
            me.getState().requestInspectorFocus(), g();
          },
          disabled: !k
        },
        {
          id: "sep0",
          separator: true
        },
        {
          id: "copy",
          label: "Copy",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "C"
          },
          action: A,
          disabled: !k
        },
        {
          id: "paste",
          label: "Paste",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "V"
          },
          action: R,
          disabled: !v
        },
        {
          id: "duplicate",
          label: "Duplicate",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "B"
          },
          action: I,
          disabled: !k
        },
        {
          id: "sep1",
          separator: true
        },
        {
          id: "delete",
          label: "Delete",
          shortcut: {
            key: He.backspace
          },
          action: T,
          disabled: !k
        },
        {
          id: "sep2",
          separator: true
        },
        {
          id: "selectAll",
          label: "Select All",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "A"
          },
          action: L,
          disabled: !C
        }
      ];
      if (d === "ruler") {
        const D = () => {
          if (!l || !n) return;
          const { selectedRulerIds: H } = Oe.getState();
          if (H.size > 0) {
            const q = new sh([
              ...H
            ]);
            ce.getState().execute(q, {
              library: l,
              renderer: n
            });
          }
          g();
        };
        return [
          {
            id: "paste",
            label: "Paste",
            shortcut: {
              modifiers: [
                He.mod
              ],
              key: "V"
            },
            action: R,
            disabled: !v
          },
          {
            id: "sep1",
            separator: true
          },
          {
            id: "delete",
            label: "Delete",
            shortcut: {
              key: He.backspace
            },
            action: D,
            disabled: false
          },
          {
            id: "sep2",
            separator: true
          },
          {
            id: "selectAll",
            label: "Select All",
            shortcut: {
              modifiers: [
                He.mod
              ],
              key: "A"
            },
            action: L,
            disabled: true
          }
        ];
      }
      if (d === "image") {
        const D = () => {
          me.getState().requestInspectorFocus(), g();
        }, H = () => {
          if (!l || !n) return;
          const q = [
            ...p
          ].filter(Mn).map(Gr);
          if (q.length > 0) {
            const re = new B0(q);
            ce.getState().execute(re, {
              library: l,
              renderer: n
            });
          }
          g();
        };
        return [
          {
            id: "edit",
            label: "Edit",
            shortcut: {
              key: "E"
            },
            action: D,
            disabled: false
          },
          {
            id: "sep0",
            separator: true
          },
          {
            id: "delete",
            label: "Delete",
            shortcut: {
              key: He.backspace
            },
            action: H,
            disabled: false
          }
        ];
      }
      if (d === "layer") {
        const D = f ? Number(f) : null, H = ve.getState(), q = D !== null ? H.getLayer(D) : void 0, re = H.layers.size <= 1, ee = () => {
          if (!l || !n) return;
          const O = new L0();
          ce.getState().execute(O, {
            library: l,
            renderer: n
          }), g();
        }, de = () => {
          D !== null && ve.getState().setEditingLayerId(D), g();
        }, ge = () => {
          D !== null && ve.getState().toggleVisibility(D), g();
        }, Ee = () => {
          if (!l || !n || D === null) return;
          const O = new ih(D);
          ce.getState().execute(O, {
            library: l,
            renderer: n
          }), g();
        }, $ = Array.from(H.layers.values()), F = $.every((O) => O.visible), fe = $.every((O) => !O.visible), ye = () => {
          ve.getState().showAllLayers(), g();
        }, ke = () => {
          ve.getState().hideAllLayers(), g();
        };
        return [
          {
            id: "editLayer",
            label: "Edit Layer",
            action: () => {
              D !== null && (ve.getState().setExpandedLayerId(D), ve.getState().setActiveLayer(D), me.getState().setSidebarTab("layers")), g();
            },
            disabled: !q
          },
          {
            id: "addLayer",
            label: "Add Layer",
            action: ee,
            disabled: false
          },
          {
            id: "rename",
            label: "Rename Layer",
            action: de,
            disabled: !q
          },
          {
            id: "toggleVisibility",
            label: (q == null ? void 0 : q.visible) ? "Hide Layer" : "Show Layer",
            action: ge,
            disabled: !q
          },
          {
            id: "sep1",
            separator: true
          },
          {
            id: "showAll",
            label: "Show All Layers",
            action: ye,
            disabled: F
          },
          {
            id: "hideAll",
            label: "Hide All Layers",
            action: ke,
            disabled: fe
          },
          {
            id: "sep2",
            separator: true
          },
          {
            id: "delete",
            label: "Delete Layer",
            action: Ee,
            disabled: !q || re
          }
        ];
      }
      if (d === "cell") {
        const D = f, H = ue.getState(), q = H.cells.length <= 1, re = () => {
          if (!l || !n) return;
          const j = ah(), O = new ch(j);
          ce.getState().execute(O, {
            library: l,
            renderer: n
          }), me.getState().explorerCollapsed && me.getState().toggleExplorerCollapsed(), ue.getState().setActiveCell(j), ue.getState().setEditingCellName(j), g();
        }, ee = () => {
          D && ue.getState().setEditingCellName(D), g();
        }, de = () => {
          if (!l || !n || !D) return;
          const j = new uh(D);
          ce.getState().execute(j, {
            library: l,
            renderer: n
          }), g();
        }, ge = D ? H.hiddenCells.has(D) : false, Ee = () => {
          D && ue.getState().toggleCellVisibility(D), g();
        }, $ = H.cells, F = $.every((j) => !H.hiddenCells.has(j)), fe = $.every((j) => H.hiddenCells.has(j));
        return [
          {
            id: "addCell",
            label: "Add Cell",
            action: re,
            disabled: !D
          },
          {
            id: "rename",
            label: "Rename Cell",
            action: ee,
            disabled: !D
          },
          {
            id: "toggleVisibility",
            label: ge ? "Show Cell" : "Hide Cell",
            action: Ee,
            disabled: !D
          },
          {
            id: "sep1",
            separator: true
          },
          {
            id: "showAllCells",
            label: "Show All Cells",
            action: () => {
              ue.getState().showAllCells(), g();
            },
            disabled: F
          },
          {
            id: "hideAllCells",
            label: "Hide All Cells",
            action: () => {
              ue.getState().hideAllCells(), g();
            },
            disabled: fe
          },
          {
            id: "sep2",
            separator: true
          },
          {
            id: "viewFlat",
            label: `${H.cellListMode === "flat" ? "\u2713  " : "     "}Flat List`,
            action: () => {
              const { cellListMode: j, setCellListMode: O } = ue.getState();
              O(j === "flat" ? "nested" : "flat"), g();
            },
            disabled: false
          },
          {
            id: "sep3",
            separator: true
          },
          {
            id: "delete",
            label: "Delete Cell",
            action: de,
            disabled: !D || q
          }
        ];
      }
      return [
        {
          id: "paste",
          label: "Paste",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "V"
          },
          action: R,
          disabled: !v
        },
        {
          id: "sep1",
          separator: true
        },
        {
          id: "selectAll",
          label: "Select All",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "A"
          },
          action: L,
          disabled: !C
        }
      ];
    }, [
      d,
      l,
      n,
      p,
      k,
      v,
      C,
      g,
      r,
      f
    ])();
    m.useEffect(() => {
      if (!i) return;
      const A = (R) => {
        o.current && !o.current.contains(R.target) && g();
      };
      return document.addEventListener("mousedown", A), () => document.removeEventListener("mousedown", A);
    }, [
      i,
      g
    ]), m.useEffect(() => {
      if (!i) return;
      const A = (R) => {
        R.key === "Escape" && (R.preventDefault(), g());
      };
      return document.addEventListener("keydown", A), () => document.removeEventListener("keydown", A);
    }, [
      i,
      g
    ]);
    const [_, N] = m.useState(c);
    return m.useLayoutEffect(() => {
      if (!i || !o.current) {
        N(c);
        return;
      }
      const R = o.current.getBoundingClientRect(), I = 8;
      let { x: T, y: L } = c;
      T + R.width + I > window.innerWidth && (T = window.innerWidth - R.width - I), L + R.height + I > window.innerHeight && (L = window.innerHeight - R.height - I), T < I && (T = I), L < I && (L = I), N({
        x: T,
        y: L
      });
    }, [
      i,
      c
    ]), i ? y.jsx("div", {
      ref: o,
      className: Y("fixed z-50 min-w-[170px] rounded-xl border py-1", S ? "border-white/10 bg-[rgb(29,29,29)] text-white/90" : "border-black/10 bg-[rgb(241,241,241)] text-black/90"),
      style: {
        left: _.x,
        top: _.y
      },
      children: E.map((A) => {
        var _a;
        if (i5(A)) return y.jsx("div", {
          className: Y("my-1 h-px", S ? "bg-white/10" : "bg-black/10")
        }, A.id);
        const R = A;
        return y.jsxs("button", {
          className: Y("mx-1 flex w-[calc(100%-0.5rem)] cursor-pointer items-center justify-between gap-3 rounded-lg px-2 py-1.5 text-left text-xs", "transition-colors", R.disabled ? "opacity-40" : S ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
          onClick: () => {
            R.disabled || R.action();
          },
          disabled: R.disabled,
          children: [
            y.jsx("span", {
              children: R.label
            }),
            R.shortcut && y.jsxs("span", {
              className: "flex gap-0.5",
              children: [
                (_a = R.shortcut.modifiers) == null ? void 0 : _a.map((I) => y.jsx("kbd", {
                  className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[11px]", S ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10"),
                  children: I
                }, I)),
                y.jsx("kbd", {
                  className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[11px]", S ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10"),
                  children: R.shortcut.key
                })
              ]
            })
          ]
        }, R.id);
      })
    }) : null;
  }
  const sb = "rosette-canvas";
  function ib() {
    const l = m.useRef(null), n = m.useRef(null), r = m.useRef({
      x: 0,
      y: 0
    }), o = m.useRef(null), i = m.useRef(null), [c, d] = m.useState(false), [f, g] = m.useState(false), { wasm: p, isReady: v } = Wv(), { renderer: b, isReady: S, render: C, resize: k, screenToWorld: x, error: E } = ES(c ? sb : null), { library: _ } = ZS(p, v);
    m.useEffect(() => (Se.getState().setLibrary(_), () => Se.getState().setLibrary(null)), [
      _
    ]), m.useEffect(() => (Se.getState().setRenderer(b), () => Se.getState().setRenderer(null)), [
      b
    ]);
    const { zoomAt: N, pan: A, initOffset: R, zoom: I, offset: T } = Ve(), L = me((le) => le.setCursorWorld), D = me((le) => le.theme), H = Gt((le) => le.activeTool), { handleMouseDown: q, handleMouseMove: re, handleMouseUp: ee, isLaserActive: de } = nC(b, S), { handleMouseDown: ge, handleMouseMove: Ee, handleMouseUp: $, box: F, isZoomActive: fe, isDrawingZoom: ye } = rC(n), { handleMouseDown: ke, handleMouseMove: j, finalizeRectangle: O, cancelDrawing: K } = aC(x, _, b), { handleMouseDown: W, handleMouseMove: J, handleMouseUp: ie, handleMouseLeave: pe, hoveredId: Re, hoveredRulerId: X, marqueeBox: U, isDrawingMarquee: te } = yC(x, _, b), { handleMouseDown: he, handleMouseMove: be, handleMouseUp: we, handleMouseLeave: je, hoveredRulerId: Xe } = SC(x, _, b), { handleMouseDown: We, handleMouseMove: Ce, cancelDrawing: Ne, points: Ae, cursorPoint: Ie, isNearStart: $e, alignmentGuides: vt } = sC(x, _, b, I), { handleMouseDown: Ke, handleMouseMove: an, cancelDrawing: un, waypoints: Wn, cursorPoint: Dl, alignmentGuides: zl } = cC(x, _, b, I), { handleMouseDown: lt, handleMouseMove: Mt, handleMouseUp: on, cancelDrawing: en, isCreating: xt, isDraggingEndpoint: Vt, isMovingRuler: jt, hoveredRulerId: Sr } = OC(x, _, b, I, T), { handleMouseDown: Hl, handleMouseMove: Qr, cancelEditing: fl, isEditing: Wr } = MC(x, _, b);
    m.useEffect(() => {
      const le = l.current, De = n.current;
      if (!le || !De) return;
      const Lt = () => {
        const kt = le.getBoundingClientRect(), bt = Math.floor(kt.width), ot = Math.floor(kt.height);
        if (bt > 0 && ot > 0) {
          const gt = window.devicePixelRatio || 1;
          De.width = Math.floor(bt * gt), De.height = Math.floor(ot * gt), De.style.width = `${bt}px`, De.style.height = `${ot}px`, R(bt, ot), c || d(true), k(Math.floor(bt * gt), Math.floor(ot * gt)), C();
        }
      };
      Lt();
      const at = new ResizeObserver(Lt);
      return at.observe(le), () => at.disconnect();
    }, [
      k,
      C,
      c,
      R
    ]), m.useEffect(() => {
      if (!S) return;
      let le;
      const De = () => {
        C(), le = requestAnimationFrame(De);
      };
      return De(), () => cancelAnimationFrame(le);
    }, [
      S,
      C
    ]);
    const Jr = ve((le) => le.layers);
    m.useEffect(() => {
      !b || !_ || (b.sync_from_library(_), b.mark_dirty());
    }, [
      b,
      _,
      Jr
    ]);
    const Ln = ue((le) => le.activeCell);
    m.useEffect(() => {
      if (!_ || !b || !Ln) return;
      _.active_cell_name() !== Ln && (_.set_active_cell(Ln), b.sync_from_library(_), b.mark_dirty(), ds());
    }, [
      _,
      b,
      Ln
    ]);
    const Ul = ue((le) => le.hierarchyLevelLimit);
    m.useEffect(() => {
      if (!_ || !b) return;
      const le = Ul === 1 / 0 ? 0 : Ul;
      _.set_hierarchy_depth_limit(le), b.sync_from_library(_), b.mark_dirty();
    }, [
      _,
      b,
      Ul
    ]);
    const hl = ue((le) => le.hiddenCells);
    m.useEffect(() => {
      if (!_ || !b) return;
      const le = new Set(_.get_hidden_cells());
      for (const De of le) hl.has(De) || _.set_cell_visibility(De, true);
      for (const De of hl) le.has(De) || _.set_cell_visibility(De, false);
      b.sync_from_library(_), b.mark_dirty();
    }, [
      _,
      b,
      hl
    ]);
    const ps = m.useRef(false), ea = m.useRef(null);
    m.useEffect(() => {
      const le = n.current;
      if (!_ || !le) return;
      const De = _.get_all_bounds();
      if (!De) return;
      const Lt = {
        minX: De[0],
        minY: De[1],
        maxX: De[2],
        maxY: De[3]
      }, at = Zr(le);
      if (at.width <= 0 || at.height <= 0) return;
      const kt = ea.current !== null && ea.current !== _;
      if (!ps.current || kt) {
        Ve.getState().zoomToFit(Lt, at.width, at.height, at.screenCenter);
        const ot = ns() ? $S() : null;
        if (ot !== null) {
          const gt = at.screenCenter ?? {
            x: at.width / 2,
            y: at.height / 2
          };
          Ve.getState().zoomAt(ot, gt.x, gt.y);
        }
        ps.current = true;
      }
      ea.current = _;
    }, [
      _
    ]);
    const Cr = m.useCallback((le) => {
      le.preventDefault();
      const De = n.current;
      if (!De) return;
      const Lt = De.getBoundingClientRect(), at = le.clientX - Lt.left, kt = le.clientY - Lt.top, bt = le.ctrlKey || Math.abs(le.deltaY) < 50;
      let ot;
      bt ? ot = Math.pow(2, -le.deltaY * 0.01) : ot = le.deltaY > 0 ? ic : sc, N(ot, at, kt);
    }, [
      N
    ]), Er = m.useCallback((le) => {
      if (H === "laser" && le.button === 0) {
        q(le);
        return;
      }
      if (H === "zoom" && le.button === 0) {
        ge(le);
        return;
      }
      if (H === "rectangle" && le.button === 0) {
        ke(le);
        return;
      }
      if (H === "select" && le.button === 0) {
        W(le);
        return;
      }
      if (H === "move" && le.button === 0) {
        he(le);
        return;
      }
      if (H === "polygon" && le.button === 0) {
        We(le);
        return;
      }
      if (H === "path" && le.button === 0) {
        Ke(le);
        return;
      }
      if (H === "ruler" && le.button === 0) {
        lt(le);
        return;
      }
      if (H === "text" && le.button === 0) {
        Hl(le);
        return;
      }
      (le.button === 1 || le.button === 0 && H === "pan") && (g(true), r.current = {
        x: le.clientX,
        y: le.clientY
      });
    }, [
      H,
      q,
      ge,
      ke,
      W,
      he,
      We,
      Ke,
      lt,
      Hl
    ]), Jn = m.useRef(0);
    m.useEffect(() => () => {
      Jn.current && cancelAnimationFrame(Jn.current);
    }, []), m.useEffect(() => {
      const le = o.current;
      if (!le) return;
      const De = (le.x - T.x) / I, Lt = (le.y - T.y) / I, at = Math.trunc(De / xe), kt = Math.trunc(Lt / xe);
      L({
        x: at,
        y: -kt
      });
    }, [
      I,
      T,
      L
    ]);
    const ys = m.useCallback((le) => {
      const De = n.current;
      if (!De) return;
      const Lt = De.getBoundingClientRect(), at = le.clientX - Lt.left, kt = le.clientY - Lt.top;
      o.current = {
        x: at,
        y: kt
      };
      let bt = false;
      H === "laser" && re(le), H === "zoom" && Ee(le), H === "rectangle" && j(at, kt) && (bt = true), H === "select" && J(le), H === "move" && be(le), H === "polygon" && Ce(le), H === "path" && an(le), H === "ruler" && Mt(le), H === "text" && Qr(le);
      const ot = x(at, kt);
      if (i.current = ot, Jn.current === 0 && (Jn.current = requestAnimationFrame(() => {
        Jn.current = 0;
        const gt = i.current;
        if (gt) {
          const Tt = Math.trunc(gt.x / xe), Je = Math.trunc(gt.y / xe);
          L({
            x: Tt,
            y: -Je
          });
        } else L(null);
      })), f) {
        const gt = le.clientX - r.current.x, Tt = le.clientY - r.current.y;
        r.current = {
          x: le.clientX,
          y: le.clientY
        }, A(gt, Tt);
      }
      bt && C();
    }, [
      A,
      x,
      L,
      f,
      H,
      re,
      Ee,
      j,
      J,
      be,
      Ce,
      an,
      Mt,
      Qr,
      C
    ]), bs = m.useCallback(() => {
      H === "laser" && ee(), H === "zoom" && $(), H === "rectangle" && i.current && O(i.current.x, i.current.y), H === "select" && ie(), H === "move" && we(), H === "ruler" && on(), g(false);
    }, [
      H,
      ee,
      $,
      O,
      ie,
      we,
      on
    ]), vs = m.useCallback(() => {
      g(false), K(), Ne(), un(), en(), fl(), pe(), je(), Jn.current && (cancelAnimationFrame(Jn.current), Jn.current = 0), o.current = null, L(null);
    }, [
      L,
      K,
      Ne,
      un,
      en,
      fl,
      pe,
      je
    ]), el = os((le) => le.open), Ka = m.useCallback((le) => {
      le.preventDefault();
      const De = n.current;
      if (!De) return;
      const Lt = De.getBoundingClientRect(), at = le.clientX - Lt.left, kt = le.clientY - Lt.top, bt = x(at, kt);
      if (!bt) return;
      const { rulers: ot, selectRuler: gt } = Oe.getState();
      for (const Je of ot.values()) {
        const Pt = Je.start.x * I + T.x, Dt = Je.start.y * I + T.y, it = Je.end.x * I + T.x, nl = Je.end.y * I + T.y, ll = (Pt + it) / 2, vn = (Dt + nl) / 2, $n = 70, ta = 28;
        if (at >= ll - $n && at <= ll + $n && kt >= vn - ta && kt <= vn + ta) {
          gt(Je.id), el("ruler", {
            x: le.clientX,
            y: le.clientY
          }, Je.id);
          return;
        }
        const Yl = at - Pt, kr = kt - Dt, Bl = it - Pt, rl = nl - Dt, Xl = Yl * Bl + kr * rl, dn = Bl * Bl + rl * rl;
        if (dn > 0) {
          const Zt = Math.max(0, Math.min(1, Xl / dn)), xs = Pt + Zt * Bl, xc = Dt + Zt * rl, na = at - xs, Za = kt - xc;
          if (Math.sqrt(na * na + Za * Za) <= 8) {
            gt(Je.id), el("ruler", {
              x: le.clientX,
              y: le.clientY
            }, Je.id);
            return;
          }
        }
      }
      if (_) {
        const Je = _.hit_test(bt.x, bt.y);
        if (Je) {
          const Pt = _.get_group_ids(Je), { selectedIds: Dt, setSelection: it } = se.getState();
          Pt.every((ll) => Dt.has(ll)) || it(new Set(Pt)), el("element", {
            x: le.clientX,
            y: le.clientY
          }, Je);
          return;
        }
      }
      const Tt = es(bt.x, bt.y);
      if (Tt) {
        const { selectedIds: Je } = se.getState();
        Je.has(Tt) || se.getState().select(Tt), el("image", {
          x: le.clientX,
          y: le.clientY
        }, Tt);
        return;
      }
      el("canvas", {
        x: le.clientX,
        y: le.clientY
      });
    }, [
      _,
      x,
      el,
      I,
      T
    ]), tl = Ki((le) => le.cellName), _r = m.useRef(null);
    if (m.useEffect(() => {
      if (!tl) return;
      const le = n.current;
      if (!le || !b || !_) return;
      const { bounds: De, origin: Lt } = Ki.getState(), at = (bt) => {
        if (!De) return;
        const ot = le.getBoundingClientRect(), gt = bt.clientX - ot.left, Tt = bt.clientY - ot.top, Je = x(gt, Tt);
        if (!Je) return;
        const Pt = Je.x - Lt.x, Dt = Je.y - Lt.y, it = De[0] + Pt, nl = De[1] + Dt, ll = De[2] + Pt, vn = De[3] + Dt, $n = new Float64Array([
          it,
          nl,
          ll,
          nl,
          ll,
          vn,
          it,
          vn
        ]), ta = new Float32Array([
          0.5,
          0.5,
          0.5,
          0
        ]);
        b.set_preview_shape($n, ta);
        const { zoom: Yl, offset: kr } = Ve.getState(), Bl = 9 / Yl, Xl = me.getState().theme === "dark" ? new Float32Array([
          1,
          1,
          1,
          0.5
        ]) : new Float32Array([
          0,
          0,
          0,
          0.5
        ]);
        if (b.set_preview_origin(Je.x, Je.y, Bl, Xl), b.mark_dirty(), _r.current) {
          const dn = it * Yl + kr.x, Zt = nl * Yl + kr.y;
          _r.current.style.transform = `translate(${dn}px, ${Zt}px) translateY(-100%)`, _r.current.style.display = "block";
        }
      }, kt = (bt) => {
        const ot = le.getBoundingClientRect(), gt = bt.clientX - ot.left, Tt = bt.clientY - ot.top, Je = x(gt, Tt);
        b.clear_preview(), b.mark_dirty();
        const Pt = gt >= 0 && Tt >= 0 && gt <= ot.width && Tt <= ot.height;
        if (Je && Pt) {
          const Dt = _.active_cell_name();
          if (Dt && Dt !== tl && _.can_instance_cell(Dt, tl)) {
            const it = new T0(tl, Je.x, Je.y);
            ce.getState().execute(it, {
              library: _,
              renderer: b
            });
          }
        }
        Ki.getState().endDrag();
      };
      return document.addEventListener("mousemove", at), document.addEventListener("mouseup", kt), () => {
        document.removeEventListener("mousemove", at), document.removeEventListener("mouseup", kt), b.clear_preview(), b.mark_dirty();
      };
    }, [
      tl,
      _,
      b,
      x
    ]), m.useEffect(() => {
      const le = n.current;
      if (le) return le.addEventListener("wheel", Cr, {
        passive: false
      }), () => le.removeEventListener("wheel", Cr);
    }, [
      Cr
    ]), P2(n, _, b), E) return y.jsx("div", {
      className: "flex h-full w-full items-center justify-center bg-red-950 text-red-200",
      children: y.jsxs("div", {
        className: "text-center",
        children: [
          y.jsx("p", {
            className: "text-lg font-semibold",
            children: "Failed to initialize renderer"
          }),
          y.jsx("p", {
            className: "mt-2 text-sm opacity-75",
            children: E.message
          }),
          y.jsx("p", {
            className: "mt-4 text-xs opacity-50",
            children: "WebGPU may not be supported in your browser. Try Chrome 113+, Safari 17+, or Edge 113+."
          })
        ]
      })
    });
    const $t = (() => {
      if (f || jt) return "cursor-grabbing";
      if (H === "pan") return "cursor-grab";
      if (H === "move") return "cursor-move";
      if (de) return "cursor-none";
      if (fe || H === "rectangle" || H === "polygon" || H === "path") return "cursor-crosshair";
      if (H === "text") return Wr ? "cursor-text" : "cursor-crosshair";
      if (H === "ruler") return Vt ? "cursor-grabbing" : xt ? "cursor-crosshair" : Sr ? "cursor-pointer" : "cursor-crosshair";
      if (H === "select") {
        if (te) return "cursor-crosshair";
        if (X || Re) return "cursor-pointer";
      }
      return "cursor-default";
    })();
    return y.jsxs("div", {
      ref: l,
      className: "relative h-full w-full select-none overflow-hidden",
      children: [
        y.jsx("canvas", {
          ref: n,
          id: sb,
          className: $t,
          onMouseDown: Er,
          onMouseMove: ys,
          onMouseUp: bs,
          onMouseLeave: vs,
          onContextMenu: Ka
        }),
        de && !f && y.jsx(IC, {}),
        ye && F && y.jsx(HC, {
          box: F
        }),
        te && U && y.jsx(BC, {
          box: U
        }),
        H === "polygon" && Ae.length > 0 && y.jsx(XC, {
          points: Ae,
          cursorPoint: Ie,
          isNearStart: $e,
          alignmentGuides: vt
        }),
        H === "path" && Wn.length > 0 && y.jsx(VC, {
          waypoints: Wn,
          cursorPoint: Dl,
          alignmentGuides: zl
        }),
        tl && y.jsx("div", {
          ref: _r,
          className: `pointer-events-none absolute top-0 left-0 text-[13px] leading-none font-mono select-none ${D === "dark" ? "text-white" : "text-black"}`,
          style: {
            display: "none",
            paddingBottom: "2px"
          },
          children: tl
        }),
        y.jsx(s5, {}),
        y.jsx(a5, {}),
        y.jsx(e5, {}),
        y.jsx(r5, {}),
        y.jsx(QC, {}),
        y.jsx(c5, {
          library: _,
          renderer: b,
          canvasRef: n
        })
      ]
    });
  }
  var cb = 1, u5 = 0.9, d5 = 0.8, f5 = 0.17, qd = 0.1, Gd = 0.999, h5 = 0.9999, m5 = 0.99, g5 = /[\\\/_+.#"@\[\(\{&]/, p5 = /[\\\/_+.#"@\[\(\{&]/g, y5 = /[\s-]/, Z0 = /[\s-]/g;
  function Kf(l, n, r, o, i, c, d) {
    if (c === n.length) return i === l.length ? cb : m5;
    var f = `${i},${c}`;
    if (d[f] !== void 0) return d[f];
    for (var g = o.charAt(c), p = r.indexOf(g, i), v = 0, b, S, C, k; p >= 0; ) b = Kf(l, n, r, o, p + 1, c + 1, d), b > v && (p === i ? b *= cb : g5.test(l.charAt(p - 1)) ? (b *= d5, C = l.slice(i, p - 1).match(p5), C && i > 0 && (b *= Math.pow(Gd, C.length))) : y5.test(l.charAt(p - 1)) ? (b *= u5, k = l.slice(i, p - 1).match(Z0), k && i > 0 && (b *= Math.pow(Gd, k.length))) : (b *= f5, i > 0 && (b *= Math.pow(Gd, p - i))), l.charAt(p) !== n.charAt(c) && (b *= h5)), (b < qd && r.charAt(p - 1) === o.charAt(c + 1) || o.charAt(c + 1) === o.charAt(c) && r.charAt(p - 1) !== o.charAt(c)) && (S = Kf(l, n, r, o, p + 1, c + 2, d), S * qd > b && (b = S * qd)), b > v && (v = b), p = r.indexOf(g, p + 1);
    return d[f] = v, v;
  }
  function ub(l) {
    return l.toLowerCase().replace(Z0, " ");
  }
  function b5(l, n, r) {
    return l = r && r.length > 0 ? `${l + " " + r.join(" ")}` : l, Kf(l, n, ub(l), ub(n), 0, 0, {});
  }
  function gr(l, n, { checkForDefaultPrevented: r = true } = {}) {
    return function(i) {
      if (l == null ? void 0 : l(i), r === false || !i.defaultPrevented) return n == null ? void 0 : n(i);
    };
  }
  function db(l, n) {
    if (typeof l == "function") return l(n);
    l != null && (l.current = n);
  }
  function br(...l) {
    return (n) => {
      let r = false;
      const o = l.map((i) => {
        const c = db(i, n);
        return !r && typeof c == "function" && (r = true), c;
      });
      if (r) return () => {
        for (let i = 0; i < o.length; i++) {
          const c = o[i];
          typeof c == "function" ? c() : db(l[i], null);
        }
      };
    };
  }
  function Fr(...l) {
    return m.useCallback(br(...l), l);
  }
  function v5(l, n) {
    const r = m.createContext(n), o = (c) => {
      const { children: d, ...f } = c, g = m.useMemo(() => f, Object.values(f));
      return y.jsx(r.Provider, {
        value: g,
        children: d
      });
    };
    o.displayName = l + "Provider";
    function i(c) {
      const d = m.useContext(r);
      if (d) return d;
      if (n !== void 0) return n;
      throw new Error(`\`${c}\` must be used within \`${l}\``);
    }
    return [
      o,
      i
    ];
  }
  function x5(l, n = []) {
    let r = [];
    function o(c, d) {
      const f = m.createContext(d), g = r.length;
      r = [
        ...r,
        d
      ];
      const p = (b) => {
        var _a;
        const { scope: S, children: C, ...k } = b, x = ((_a = S == null ? void 0 : S[l]) == null ? void 0 : _a[g]) || f, E = m.useMemo(() => k, Object.values(k));
        return y.jsx(x.Provider, {
          value: E,
          children: C
        });
      };
      p.displayName = c + "Provider";
      function v(b, S) {
        var _a;
        const C = ((_a = S == null ? void 0 : S[l]) == null ? void 0 : _a[g]) || f, k = m.useContext(C);
        if (k) return k;
        if (d !== void 0) return d;
        throw new Error(`\`${b}\` must be used within \`${c}\``);
      }
      return [
        p,
        v
      ];
    }
    const i = () => {
      const c = r.map((d) => m.createContext(d));
      return function(f) {
        const g = (f == null ? void 0 : f[l]) || c;
        return m.useMemo(() => ({
          [`__scope${l}`]: {
            ...f,
            [l]: g
          }
        }), [
          f,
          g
        ]);
      };
    };
    return i.scopeName = l, [
      o,
      w5(i, ...n)
    ];
  }
  function w5(...l) {
    const n = l[0];
    if (l.length === 1) return n;
    const r = () => {
      const o = l.map((i) => ({
        useScope: i(),
        scopeName: i.scopeName
      }));
      return function(c) {
        const d = o.reduce((f, { useScope: g, scopeName: p }) => {
          const b = g(c)[`__scope${p}`];
          return {
            ...f,
            ...b
          };
        }, {});
        return m.useMemo(() => ({
          [`__scope${n.scopeName}`]: d
        }), [
          d
        ]);
      };
    };
    return r.scopeName = n.scopeName, r;
  }
  var ls = (globalThis == null ? void 0 : globalThis.document) ? m.useLayoutEffect : () => {
  }, S5 = nh[" useId ".trim().toString()] || (() => {
  }), C5 = 0;
  function Il(l) {
    const [n, r] = m.useState(S5());
    return ls(() => {
      r((o) => o ?? String(C5++));
    }, [
      l
    ]), n ? `radix-${n}` : "";
  }
  var E5 = nh[" useInsertionEffect ".trim().toString()] || ls;
  function _5({ prop: l, defaultProp: n, onChange: r = () => {
  }, caller: o }) {
    const [i, c, d] = k5({
      defaultProp: n,
      onChange: r
    }), f = l !== void 0, g = f ? l : i;
    {
      const v = m.useRef(l !== void 0);
      m.useEffect(() => {
        const b = v.current;
        b !== f && console.warn(`${o} is changing from ${b ? "controlled" : "uncontrolled"} to ${f ? "controlled" : "uncontrolled"}. Components should not switch from controlled to uncontrolled (or vice versa). Decide between using a controlled or uncontrolled value for the lifetime of the component.`), v.current = f;
      }, [
        f,
        o
      ]);
    }
    const p = m.useCallback((v) => {
      var _a;
      if (f) {
        const b = M5(v) ? v(l) : v;
        b !== l && ((_a = d.current) == null ? void 0 : _a.call(d, b));
      } else c(v);
    }, [
      f,
      l,
      c,
      d
    ]);
    return [
      g,
      p
    ];
  }
  function k5({ defaultProp: l, onChange: n }) {
    const [r, o] = m.useState(l), i = m.useRef(r), c = m.useRef(n);
    return E5(() => {
      c.current = n;
    }, [
      n
    ]), m.useEffect(() => {
      var _a;
      i.current !== r && ((_a = c.current) == null ? void 0 : _a.call(c, r), i.current = r);
    }, [
      r,
      i
    ]), [
      r,
      o,
      c
    ];
  }
  function M5(l) {
    return typeof l == "function";
  }
  var fs = Qv();
  const j5 = Fv(fs);
  function hs(l) {
    const n = L5(l), r = m.forwardRef((o, i) => {
      const { children: c, ...d } = o, f = m.Children.toArray(c), g = f.find(A5);
      if (g) {
        const p = g.props.children, v = f.map((b) => b === g ? m.Children.count(p) > 1 ? m.Children.only(null) : m.isValidElement(p) ? p.props.children : null : b);
        return y.jsx(n, {
          ...d,
          ref: i,
          children: m.isValidElement(p) ? m.cloneElement(p, void 0, v) : null
        });
      }
      return y.jsx(n, {
        ...d,
        ref: i,
        children: c
      });
    });
    return r.displayName = `${l}.Slot`, r;
  }
  function L5(l) {
    const n = m.forwardRef((r, o) => {
      const { children: i, ...c } = r;
      if (m.isValidElement(i)) {
        const d = N5(i), f = T5(c, i.props);
        return i.type !== m.Fragment && (f.ref = o ? br(o, d) : d), m.cloneElement(i, f);
      }
      return m.Children.count(i) > 1 ? m.Children.only(null) : null;
    });
    return n.displayName = `${l}.SlotClone`, n;
  }
  var R5 = Symbol("radix.slottable");
  function A5(l) {
    return m.isValidElement(l) && typeof l.type == "function" && "__radixId" in l.type && l.type.__radixId === R5;
  }
  function T5(l, n) {
    const r = {
      ...n
    };
    for (const o in n) {
      const i = l[o], c = n[o];
      /^on[A-Z]/.test(o) ? i && c ? r[o] = (...f) => {
        const g = c(...f);
        return i(...f), g;
      } : i && (r[o] = i) : o === "style" ? r[o] = {
        ...i,
        ...c
      } : o === "className" && (r[o] = [
        i,
        c
      ].filter(Boolean).join(" "));
    }
    return {
      ...l,
      ...r
    };
  }
  function N5(l) {
    var _a, _b2;
    let n = (_a = Object.getOwnPropertyDescriptor(l.props, "ref")) == null ? void 0 : _a.get, r = n && "isReactWarning" in n && n.isReactWarning;
    return r ? l.ref : (n = (_b2 = Object.getOwnPropertyDescriptor(l, "ref")) == null ? void 0 : _b2.get, r = n && "isReactWarning" in n && n.isReactWarning, r ? l.props.ref : l.props.ref || l.ref);
  }
  var O5 = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ], F0 = O5.reduce((l, n) => {
    const r = hs(`Primitive.${n}`), o = m.forwardRef((i, c) => {
      const { asChild: d, ...f } = i, g = d ? r : n;
      return typeof window < "u" && (window[Symbol.for("radix-ui")] = true), y.jsx(g, {
        ...f,
        ref: c
      });
    });
    return o.displayName = `Primitive.${n}`, {
      ...l,
      [n]: o
    };
  }, {});
  function I5(l, n) {
    l && fs.flushSync(() => l.dispatchEvent(n));
  }
  function rs(l) {
    const n = m.useRef(l);
    return m.useEffect(() => {
      n.current = l;
    }), m.useMemo(() => (...r) => {
      var _a;
      return (_a = n.current) == null ? void 0 : _a.call(n, ...r);
    }, []);
  }
  function D5(l, n = globalThis == null ? void 0 : globalThis.document) {
    const r = rs(l);
    m.useEffect(() => {
      const o = (i) => {
        i.key === "Escape" && r(i);
      };
      return n.addEventListener("keydown", o, {
        capture: true
      }), () => n.removeEventListener("keydown", o, {
        capture: true
      });
    }, [
      r,
      n
    ]);
  }
  var z5 = "DismissableLayer", Zf = "dismissableLayer.update", H5 = "dismissableLayer.pointerDownOutside", U5 = "dismissableLayer.focusOutside", fb, Q0 = m.createContext({
    layers: /* @__PURE__ */ new Set(),
    layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
    branches: /* @__PURE__ */ new Set()
  }), W0 = m.forwardRef((l, n) => {
    const { disableOutsidePointerEvents: r = false, onEscapeKeyDown: o, onPointerDownOutside: i, onFocusOutside: c, onInteractOutside: d, onDismiss: f, ...g } = l, p = m.useContext(Q0), [v, b] = m.useState(null), S = (v == null ? void 0 : v.ownerDocument) ?? (globalThis == null ? void 0 : globalThis.document), [, C] = m.useState({}), k = Fr(n, (L) => b(L)), x = Array.from(p.layers), [E] = [
      ...p.layersWithOutsidePointerEventsDisabled
    ].slice(-1), _ = x.indexOf(E), N = v ? x.indexOf(v) : -1, A = p.layersWithOutsidePointerEventsDisabled.size > 0, R = N >= _, I = X5((L) => {
      const D = L.target, H = [
        ...p.branches
      ].some((q) => q.contains(D));
      !R || H || (i == null ? void 0 : i(L), d == null ? void 0 : d(L), L.defaultPrevented || (f == null ? void 0 : f()));
    }, S), T = V5((L) => {
      const D = L.target;
      [
        ...p.branches
      ].some((q) => q.contains(D)) || (c == null ? void 0 : c(L), d == null ? void 0 : d(L), L.defaultPrevented || (f == null ? void 0 : f()));
    }, S);
    return D5((L) => {
      N === p.layers.size - 1 && (o == null ? void 0 : o(L), !L.defaultPrevented && f && (L.preventDefault(), f()));
    }, S), m.useEffect(() => {
      if (v) return r && (p.layersWithOutsidePointerEventsDisabled.size === 0 && (fb = S.body.style.pointerEvents, S.body.style.pointerEvents = "none"), p.layersWithOutsidePointerEventsDisabled.add(v)), p.layers.add(v), hb(), () => {
        r && p.layersWithOutsidePointerEventsDisabled.size === 1 && (S.body.style.pointerEvents = fb);
      };
    }, [
      v,
      S,
      r,
      p
    ]), m.useEffect(() => () => {
      v && (p.layers.delete(v), p.layersWithOutsidePointerEventsDisabled.delete(v), hb());
    }, [
      v,
      p
    ]), m.useEffect(() => {
      const L = () => C({});
      return document.addEventListener(Zf, L), () => document.removeEventListener(Zf, L);
    }, []), y.jsx(F0.div, {
      ...g,
      ref: k,
      style: {
        pointerEvents: A ? R ? "auto" : "none" : void 0,
        ...l.style
      },
      onFocusCapture: gr(l.onFocusCapture, T.onFocusCapture),
      onBlurCapture: gr(l.onBlurCapture, T.onBlurCapture),
      onPointerDownCapture: gr(l.onPointerDownCapture, I.onPointerDownCapture)
    });
  });
  W0.displayName = z5;
  var Y5 = "DismissableLayerBranch", B5 = m.forwardRef((l, n) => {
    const r = m.useContext(Q0), o = m.useRef(null), i = Fr(n, o);
    return m.useEffect(() => {
      const c = o.current;
      if (c) return r.branches.add(c), () => {
        r.branches.delete(c);
      };
    }, [
      r.branches
    ]), y.jsx(F0.div, {
      ...l,
      ref: i
    });
  });
  B5.displayName = Y5;
  function X5(l, n = globalThis == null ? void 0 : globalThis.document) {
    const r = rs(l), o = m.useRef(false), i = m.useRef(() => {
    });
    return m.useEffect(() => {
      const c = (f) => {
        if (f.target && !o.current) {
          let g = function() {
            J0(H5, r, p, {
              discrete: true
            });
          };
          const p = {
            originalEvent: f
          };
          f.pointerType === "touch" ? (n.removeEventListener("click", i.current), i.current = g, n.addEventListener("click", i.current, {
            once: true
          })) : g();
        } else n.removeEventListener("click", i.current);
        o.current = false;
      }, d = window.setTimeout(() => {
        n.addEventListener("pointerdown", c);
      }, 0);
      return () => {
        window.clearTimeout(d), n.removeEventListener("pointerdown", c), n.removeEventListener("click", i.current);
      };
    }, [
      n,
      r
    ]), {
      onPointerDownCapture: () => o.current = true
    };
  }
  function V5(l, n = globalThis == null ? void 0 : globalThis.document) {
    const r = rs(l), o = m.useRef(false);
    return m.useEffect(() => {
      const i = (c) => {
        c.target && !o.current && J0(U5, r, {
          originalEvent: c
        }, {
          discrete: false
        });
      };
      return n.addEventListener("focusin", i), () => n.removeEventListener("focusin", i);
    }, [
      n,
      r
    ]), {
      onFocusCapture: () => o.current = true,
      onBlurCapture: () => o.current = false
    };
  }
  function hb() {
    const l = new CustomEvent(Zf);
    document.dispatchEvent(l);
  }
  function J0(l, n, r, { discrete: o }) {
    const i = r.originalEvent.target, c = new CustomEvent(l, {
      bubbles: false,
      cancelable: true,
      detail: r
    });
    n && i.addEventListener(l, n, {
      once: true
    }), o ? I5(i, c) : i.dispatchEvent(c);
  }
  var $5 = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ], q5 = $5.reduce((l, n) => {
    const r = hs(`Primitive.${n}`), o = m.forwardRef((i, c) => {
      const { asChild: d, ...f } = i, g = d ? r : n;
      return typeof window < "u" && (window[Symbol.for("radix-ui")] = true), y.jsx(g, {
        ...f,
        ref: c
      });
    });
    return o.displayName = `Primitive.${n}`, {
      ...l,
      [n]: o
    };
  }, {}), Pd = "focusScope.autoFocusOnMount", Kd = "focusScope.autoFocusOnUnmount", mb = {
    bubbles: false,
    cancelable: true
  }, G5 = "FocusScope", e1 = m.forwardRef((l, n) => {
    const { loop: r = false, trapped: o = false, onMountAutoFocus: i, onUnmountAutoFocus: c, ...d } = l, [f, g] = m.useState(null), p = rs(i), v = rs(c), b = m.useRef(null), S = Fr(n, (x) => g(x)), C = m.useRef({
      paused: false,
      pause() {
        this.paused = true;
      },
      resume() {
        this.paused = false;
      }
    }).current;
    m.useEffect(() => {
      if (o) {
        let x = function(A) {
          if (C.paused || !f) return;
          const R = A.target;
          f.contains(R) ? b.current = R : mr(b.current, {
            select: true
          });
        }, E = function(A) {
          if (C.paused || !f) return;
          const R = A.relatedTarget;
          R !== null && (f.contains(R) || mr(b.current, {
            select: true
          }));
        }, _ = function(A) {
          if (document.activeElement === document.body) for (const I of A) I.removedNodes.length > 0 && mr(f);
        };
        document.addEventListener("focusin", x), document.addEventListener("focusout", E);
        const N = new MutationObserver(_);
        return f && N.observe(f, {
          childList: true,
          subtree: true
        }), () => {
          document.removeEventListener("focusin", x), document.removeEventListener("focusout", E), N.disconnect();
        };
      }
    }, [
      o,
      f,
      C.paused
    ]), m.useEffect(() => {
      if (f) {
        pb.add(C);
        const x = document.activeElement;
        if (!f.contains(x)) {
          const _ = new CustomEvent(Pd, mb);
          f.addEventListener(Pd, p), f.dispatchEvent(_), _.defaultPrevented || (P5(W5(t1(f)), {
            select: true
          }), document.activeElement === x && mr(f));
        }
        return () => {
          f.removeEventListener(Pd, p), setTimeout(() => {
            const _ = new CustomEvent(Kd, mb);
            f.addEventListener(Kd, v), f.dispatchEvent(_), _.defaultPrevented || mr(x ?? document.body, {
              select: true
            }), f.removeEventListener(Kd, v), pb.remove(C);
          }, 0);
        };
      }
    }, [
      f,
      p,
      v,
      C
    ]);
    const k = m.useCallback((x) => {
      if (!r && !o || C.paused) return;
      const E = x.key === "Tab" && !x.altKey && !x.ctrlKey && !x.metaKey, _ = document.activeElement;
      if (E && _) {
        const N = x.currentTarget, [A, R] = K5(N);
        A && R ? !x.shiftKey && _ === R ? (x.preventDefault(), r && mr(A, {
          select: true
        })) : x.shiftKey && _ === A && (x.preventDefault(), r && mr(R, {
          select: true
        })) : _ === N && x.preventDefault();
      }
    }, [
      r,
      o,
      C.paused
    ]);
    return y.jsx(q5.div, {
      tabIndex: -1,
      ...d,
      ref: S,
      onKeyDown: k
    });
  });
  e1.displayName = G5;
  function P5(l, { select: n = false } = {}) {
    const r = document.activeElement;
    for (const o of l) if (mr(o, {
      select: n
    }), document.activeElement !== r) return;
  }
  function K5(l) {
    const n = t1(l), r = gb(n, l), o = gb(n.reverse(), l);
    return [
      r,
      o
    ];
  }
  function t1(l) {
    const n = [], r = document.createTreeWalker(l, NodeFilter.SHOW_ELEMENT, {
      acceptNode: (o) => {
        const i = o.tagName === "INPUT" && o.type === "hidden";
        return o.disabled || o.hidden || i ? NodeFilter.FILTER_SKIP : o.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
      }
    });
    for (; r.nextNode(); ) n.push(r.currentNode);
    return n;
  }
  function gb(l, n) {
    for (const r of l) if (!Z5(r, {
      upTo: n
    })) return r;
  }
  function Z5(l, { upTo: n }) {
    if (getComputedStyle(l).visibility === "hidden") return true;
    for (; l; ) {
      if (n !== void 0 && l === n) return false;
      if (getComputedStyle(l).display === "none") return true;
      l = l.parentElement;
    }
    return false;
  }
  function F5(l) {
    return l instanceof HTMLInputElement && "select" in l;
  }
  function mr(l, { select: n = false } = {}) {
    if (l && l.focus) {
      const r = document.activeElement;
      l.focus({
        preventScroll: true
      }), l !== r && F5(l) && n && l.select();
    }
  }
  var pb = Q5();
  function Q5() {
    let l = [];
    return {
      add(n) {
        const r = l[0];
        n !== r && (r == null ? void 0 : r.pause()), l = yb(l, n), l.unshift(n);
      },
      remove(n) {
        var _a;
        l = yb(l, n), (_a = l[0]) == null ? void 0 : _a.resume();
      }
    };
  }
  function yb(l, n) {
    const r = [
      ...l
    ], o = r.indexOf(n);
    return o !== -1 && r.splice(o, 1), r;
  }
  function W5(l) {
    return l.filter((n) => n.tagName !== "A");
  }
  var J5 = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ], eE = J5.reduce((l, n) => {
    const r = hs(`Primitive.${n}`), o = m.forwardRef((i, c) => {
      const { asChild: d, ...f } = i, g = d ? r : n;
      return typeof window < "u" && (window[Symbol.for("radix-ui")] = true), y.jsx(g, {
        ...f,
        ref: c
      });
    });
    return o.displayName = `Primitive.${n}`, {
      ...l,
      [n]: o
    };
  }, {}), tE = "Portal", n1 = m.forwardRef((l, n) => {
    var _a;
    const { container: r, ...o } = l, [i, c] = m.useState(false);
    ls(() => c(true), []);
    const d = r || i && ((_a = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : _a.body);
    return d ? j5.createPortal(y.jsx(eE.div, {
      ...o,
      ref: n
    }), d) : null;
  });
  n1.displayName = tE;
  function nE(l, n) {
    return m.useReducer((r, o) => n[r][o] ?? r, l);
  }
  var pc = (l) => {
    const { present: n, children: r } = l, o = lE(n), i = typeof r == "function" ? r({
      present: o.isPresent
    }) : m.Children.only(r), c = Fr(o.ref, rE(i));
    return typeof r == "function" || o.isPresent ? m.cloneElement(i, {
      ref: c
    }) : null;
  };
  pc.displayName = "Presence";
  function lE(l) {
    const [n, r] = m.useState(), o = m.useRef(null), i = m.useRef(l), c = m.useRef("none"), d = l ? "mounted" : "unmounted", [f, g] = nE(d, {
      mounted: {
        UNMOUNT: "unmounted",
        ANIMATION_OUT: "unmountSuspended"
      },
      unmountSuspended: {
        MOUNT: "mounted",
        ANIMATION_END: "unmounted"
      },
      unmounted: {
        MOUNT: "mounted"
      }
    });
    return m.useEffect(() => {
      const p = Ui(o.current);
      c.current = f === "mounted" ? p : "none";
    }, [
      f
    ]), ls(() => {
      const p = o.current, v = i.current;
      if (v !== l) {
        const S = c.current, C = Ui(p);
        l ? g("MOUNT") : C === "none" || (p == null ? void 0 : p.display) === "none" ? g("UNMOUNT") : g(v && S !== C ? "ANIMATION_OUT" : "UNMOUNT"), i.current = l;
      }
    }, [
      l,
      g
    ]), ls(() => {
      if (n) {
        let p;
        const v = n.ownerDocument.defaultView ?? window, b = (C) => {
          const x = Ui(o.current).includes(CSS.escape(C.animationName));
          if (C.target === n && x && (g("ANIMATION_END"), !i.current)) {
            const E = n.style.animationFillMode;
            n.style.animationFillMode = "forwards", p = v.setTimeout(() => {
              n.style.animationFillMode === "forwards" && (n.style.animationFillMode = E);
            });
          }
        }, S = (C) => {
          C.target === n && (c.current = Ui(o.current));
        };
        return n.addEventListener("animationstart", S), n.addEventListener("animationcancel", b), n.addEventListener("animationend", b), () => {
          v.clearTimeout(p), n.removeEventListener("animationstart", S), n.removeEventListener("animationcancel", b), n.removeEventListener("animationend", b);
        };
      } else g("ANIMATION_END");
    }, [
      n,
      g
    ]), {
      isPresent: [
        "mounted",
        "unmountSuspended"
      ].includes(f),
      ref: m.useCallback((p) => {
        o.current = p ? getComputedStyle(p) : null, r(p);
      }, [])
    };
  }
  function Ui(l) {
    return (l == null ? void 0 : l.animationName) || "none";
  }
  function rE(l) {
    var _a, _b2;
    let n = (_a = Object.getOwnPropertyDescriptor(l.props, "ref")) == null ? void 0 : _a.get, r = n && "isReactWarning" in n && n.isReactWarning;
    return r ? l.ref : (n = (_b2 = Object.getOwnPropertyDescriptor(l, "ref")) == null ? void 0 : _b2.get, r = n && "isReactWarning" in n && n.isReactWarning, r ? l.props.ref : l.props.ref || l.ref);
  }
  var aE = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ], ms = aE.reduce((l, n) => {
    const r = hs(`Primitive.${n}`), o = m.forwardRef((i, c) => {
      const { asChild: d, ...f } = i, g = d ? r : n;
      return typeof window < "u" && (window[Symbol.for("radix-ui")] = true), y.jsx(g, {
        ...f,
        ref: c
      });
    });
    return o.displayName = `Primitive.${n}`, {
      ...l,
      [n]: o
    };
  }, {}), Zd = 0;
  function oE() {
    m.useEffect(() => {
      const l = document.querySelectorAll("[data-radix-focus-guard]");
      return document.body.insertAdjacentElement("afterbegin", l[0] ?? bb()), document.body.insertAdjacentElement("beforeend", l[1] ?? bb()), Zd++, () => {
        Zd === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((n) => n.remove()), Zd--;
      };
    }, []);
  }
  function bb() {
    const l = document.createElement("span");
    return l.setAttribute("data-radix-focus-guard", ""), l.tabIndex = 0, l.style.outline = "none", l.style.opacity = "0", l.style.position = "fixed", l.style.pointerEvents = "none", l;
  }
  var cl = function() {
    return cl = Object.assign || function(n) {
      for (var r, o = 1, i = arguments.length; o < i; o++) {
        r = arguments[o];
        for (var c in r) Object.prototype.hasOwnProperty.call(r, c) && (n[c] = r[c]);
      }
      return n;
    }, cl.apply(this, arguments);
  };
  function l1(l, n) {
    var r = {};
    for (var o in l) Object.prototype.hasOwnProperty.call(l, o) && n.indexOf(o) < 0 && (r[o] = l[o]);
    if (l != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, o = Object.getOwnPropertySymbols(l); i < o.length; i++) n.indexOf(o[i]) < 0 && Object.prototype.propertyIsEnumerable.call(l, o[i]) && (r[o[i]] = l[o[i]]);
    return r;
  }
  function sE(l, n, r) {
    if (r || arguments.length === 2) for (var o = 0, i = n.length, c; o < i; o++) (c || !(o in n)) && (c || (c = Array.prototype.slice.call(n, 0, o)), c[o] = n[o]);
    return l.concat(c || Array.prototype.slice.call(n));
  }
  var Ji = "right-scroll-bar-position", ec = "width-before-scroll-bar", iE = "with-scroll-bars-hidden", cE = "--removed-body-scroll-bar-size";
  function Fd(l, n) {
    return typeof l == "function" ? l(n) : l && (l.current = n), l;
  }
  function uE(l, n) {
    var r = m.useState(function() {
      return {
        value: l,
        callback: n,
        facade: {
          get current() {
            return r.value;
          },
          set current(o) {
            var i = r.value;
            i !== o && (r.value = o, r.callback(o, i));
          }
        }
      };
    })[0];
    return r.callback = n, r.facade;
  }
  var dE = typeof window < "u" ? m.useLayoutEffect : m.useEffect, vb = /* @__PURE__ */ new WeakMap();
  function fE(l, n) {
    var r = uE(null, function(o) {
      return l.forEach(function(i) {
        return Fd(i, o);
      });
    });
    return dE(function() {
      var o = vb.get(r);
      if (o) {
        var i = new Set(o), c = new Set(l), d = r.current;
        i.forEach(function(f) {
          c.has(f) || Fd(f, null);
        }), c.forEach(function(f) {
          i.has(f) || Fd(f, d);
        });
      }
      vb.set(r, l);
    }, [
      l
    ]), r;
  }
  function hE(l) {
    return l;
  }
  function mE(l, n) {
    n === void 0 && (n = hE);
    var r = [], o = false, i = {
      read: function() {
        if (o) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
        return r.length ? r[r.length - 1] : l;
      },
      useMedium: function(c) {
        var d = n(c, o);
        return r.push(d), function() {
          r = r.filter(function(f) {
            return f !== d;
          });
        };
      },
      assignSyncMedium: function(c) {
        for (o = true; r.length; ) {
          var d = r;
          r = [], d.forEach(c);
        }
        r = {
          push: function(f) {
            return c(f);
          },
          filter: function() {
            return r;
          }
        };
      },
      assignMedium: function(c) {
        o = true;
        var d = [];
        if (r.length) {
          var f = r;
          r = [], f.forEach(c), d = r;
        }
        var g = function() {
          var v = d;
          d = [], v.forEach(c);
        }, p = function() {
          return Promise.resolve().then(g);
        };
        p(), r = {
          push: function(v) {
            d.push(v), p();
          },
          filter: function(v) {
            return d = d.filter(v), r;
          }
        };
      }
    };
    return i;
  }
  function gE(l) {
    l === void 0 && (l = {});
    var n = mE(null);
    return n.options = cl({
      async: true,
      ssr: false
    }, l), n;
  }
  var r1 = function(l) {
    var n = l.sideCar, r = l1(l, [
      "sideCar"
    ]);
    if (!n) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
    var o = n.read();
    if (!o) throw new Error("Sidecar medium not found");
    return m.createElement(o, cl({}, r));
  };
  r1.isSideCarExport = true;
  function pE(l, n) {
    return l.useMedium(n), r1;
  }
  var a1 = gE(), Qd = function() {
  }, yc = m.forwardRef(function(l, n) {
    var r = m.useRef(null), o = m.useState({
      onScrollCapture: Qd,
      onWheelCapture: Qd,
      onTouchMoveCapture: Qd
    }), i = o[0], c = o[1], d = l.forwardProps, f = l.children, g = l.className, p = l.removeScrollBar, v = l.enabled, b = l.shards, S = l.sideCar, C = l.noRelative, k = l.noIsolation, x = l.inert, E = l.allowPinchZoom, _ = l.as, N = _ === void 0 ? "div" : _, A = l.gapMode, R = l1(l, [
      "forwardProps",
      "children",
      "className",
      "removeScrollBar",
      "enabled",
      "shards",
      "sideCar",
      "noRelative",
      "noIsolation",
      "inert",
      "allowPinchZoom",
      "as",
      "gapMode"
    ]), I = S, T = fE([
      r,
      n
    ]), L = cl(cl({}, R), i);
    return m.createElement(m.Fragment, null, v && m.createElement(I, {
      sideCar: a1,
      removeScrollBar: p,
      shards: b,
      noRelative: C,
      noIsolation: k,
      inert: x,
      setCallbacks: c,
      allowPinchZoom: !!E,
      lockRef: r,
      gapMode: A
    }), d ? m.cloneElement(m.Children.only(f), cl(cl({}, L), {
      ref: T
    })) : m.createElement(N, cl({}, L, {
      className: g,
      ref: T
    }), f));
  });
  yc.defaultProps = {
    enabled: true,
    removeScrollBar: true,
    inert: false
  };
  yc.classNames = {
    fullWidth: ec,
    zeroRight: Ji
  };
  var yE = function() {
    if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
  };
  function bE() {
    if (!document) return null;
    var l = document.createElement("style");
    l.type = "text/css";
    var n = yE();
    return n && l.setAttribute("nonce", n), l;
  }
  function vE(l, n) {
    l.styleSheet ? l.styleSheet.cssText = n : l.appendChild(document.createTextNode(n));
  }
  function xE(l) {
    var n = document.head || document.getElementsByTagName("head")[0];
    n.appendChild(l);
  }
  var wE = function() {
    var l = 0, n = null;
    return {
      add: function(r) {
        l == 0 && (n = bE()) && (vE(n, r), xE(n)), l++;
      },
      remove: function() {
        l--, !l && n && (n.parentNode && n.parentNode.removeChild(n), n = null);
      }
    };
  }, SE = function() {
    var l = wE();
    return function(n, r) {
      m.useEffect(function() {
        return l.add(n), function() {
          l.remove();
        };
      }, [
        n && r
      ]);
    };
  }, o1 = function() {
    var l = SE(), n = function(r) {
      var o = r.styles, i = r.dynamic;
      return l(o, i), null;
    };
    return n;
  }, CE = {
    left: 0,
    top: 0,
    right: 0,
    gap: 0
  }, Wd = function(l) {
    return parseInt(l || "", 10) || 0;
  }, EE = function(l) {
    var n = window.getComputedStyle(document.body), r = n[l === "padding" ? "paddingLeft" : "marginLeft"], o = n[l === "padding" ? "paddingTop" : "marginTop"], i = n[l === "padding" ? "paddingRight" : "marginRight"];
    return [
      Wd(r),
      Wd(o),
      Wd(i)
    ];
  }, _E = function(l) {
    if (l === void 0 && (l = "margin"), typeof window > "u") return CE;
    var n = EE(l), r = document.documentElement.clientWidth, o = window.innerWidth;
    return {
      left: n[0],
      top: n[1],
      right: n[2],
      gap: Math.max(0, o - r + n[2] - n[0])
    };
  }, kE = o1(), qa = "data-scroll-locked", ME = function(l, n, r, o) {
    var i = l.left, c = l.top, d = l.right, f = l.gap;
    return r === void 0 && (r = "margin"), `
  .`.concat(iE, ` {
   overflow: hidden `).concat(o, `;
   padding-right: `).concat(f, "px ").concat(o, `;
  }
  body[`).concat(qa, `] {
    overflow: hidden `).concat(o, `;
    overscroll-behavior: contain;
    `).concat([
      n && "position: relative ".concat(o, ";"),
      r === "margin" && `
    padding-left: `.concat(i, `px;
    padding-top: `).concat(c, `px;
    padding-right: `).concat(d, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(f, "px ").concat(o, `;
    `),
      r === "padding" && "padding-right: ".concat(f, "px ").concat(o, ";")
    ].filter(Boolean).join(""), `
  }
  
  .`).concat(Ji, ` {
    right: `).concat(f, "px ").concat(o, `;
  }
  
  .`).concat(ec, ` {
    margin-right: `).concat(f, "px ").concat(o, `;
  }
  
  .`).concat(Ji, " .").concat(Ji, ` {
    right: 0 `).concat(o, `;
  }
  
  .`).concat(ec, " .").concat(ec, ` {
    margin-right: 0 `).concat(o, `;
  }
  
  body[`).concat(qa, `] {
    `).concat(cE, ": ").concat(f, `px;
  }
`);
  }, xb = function() {
    var l = parseInt(document.body.getAttribute(qa) || "0", 10);
    return isFinite(l) ? l : 0;
  }, jE = function() {
    m.useEffect(function() {
      return document.body.setAttribute(qa, (xb() + 1).toString()), function() {
        var l = xb() - 1;
        l <= 0 ? document.body.removeAttribute(qa) : document.body.setAttribute(qa, l.toString());
      };
    }, []);
  }, LE = function(l) {
    var n = l.noRelative, r = l.noImportant, o = l.gapMode, i = o === void 0 ? "margin" : o;
    jE();
    var c = m.useMemo(function() {
      return _E(i);
    }, [
      i
    ]);
    return m.createElement(kE, {
      styles: ME(c, !n, i, r ? "" : "!important")
    });
  }, Ff = false;
  if (typeof window < "u") try {
    var Yi = Object.defineProperty({}, "passive", {
      get: function() {
        return Ff = true, true;
      }
    });
    window.addEventListener("test", Yi, Yi), window.removeEventListener("test", Yi, Yi);
  } catch {
    Ff = false;
  }
  var za = Ff ? {
    passive: false
  } : false, RE = function(l) {
    return l.tagName === "TEXTAREA";
  }, s1 = function(l, n) {
    if (!(l instanceof Element)) return false;
    var r = window.getComputedStyle(l);
    return r[n] !== "hidden" && !(r.overflowY === r.overflowX && !RE(l) && r[n] === "visible");
  }, AE = function(l) {
    return s1(l, "overflowY");
  }, TE = function(l) {
    return s1(l, "overflowX");
  }, wb = function(l, n) {
    var r = n.ownerDocument, o = n;
    do {
      typeof ShadowRoot < "u" && o instanceof ShadowRoot && (o = o.host);
      var i = i1(l, o);
      if (i) {
        var c = c1(l, o), d = c[1], f = c[2];
        if (d > f) return true;
      }
      o = o.parentNode;
    } while (o && o !== r.body);
    return false;
  }, NE = function(l) {
    var n = l.scrollTop, r = l.scrollHeight, o = l.clientHeight;
    return [
      n,
      r,
      o
    ];
  }, OE = function(l) {
    var n = l.scrollLeft, r = l.scrollWidth, o = l.clientWidth;
    return [
      n,
      r,
      o
    ];
  }, i1 = function(l, n) {
    return l === "v" ? AE(n) : TE(n);
  }, c1 = function(l, n) {
    return l === "v" ? NE(n) : OE(n);
  }, IE = function(l, n) {
    return l === "h" && n === "rtl" ? -1 : 1;
  }, DE = function(l, n, r, o, i) {
    var c = IE(l, window.getComputedStyle(n).direction), d = c * o, f = r.target, g = n.contains(f), p = false, v = d > 0, b = 0, S = 0;
    do {
      if (!f) break;
      var C = c1(l, f), k = C[0], x = C[1], E = C[2], _ = x - E - c * k;
      (k || _) && i1(l, f) && (b += _, S += k);
      var N = f.parentNode;
      f = N && N.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? N.host : N;
    } while (!g && f !== document.body || g && (n.contains(f) || n === f));
    return (v && Math.abs(b) < 1 || !v && Math.abs(S) < 1) && (p = true), p;
  }, Bi = function(l) {
    return "changedTouches" in l ? [
      l.changedTouches[0].clientX,
      l.changedTouches[0].clientY
    ] : [
      0,
      0
    ];
  }, Sb = function(l) {
    return [
      l.deltaX,
      l.deltaY
    ];
  }, Cb = function(l) {
    return l && "current" in l ? l.current : l;
  }, zE = function(l, n) {
    return l[0] === n[0] && l[1] === n[1];
  }, HE = function(l) {
    return `
  .block-interactivity-`.concat(l, ` {pointer-events: none;}
  .allow-interactivity-`).concat(l, ` {pointer-events: all;}
`);
  }, UE = 0, Ha = [];
  function YE(l) {
    var n = m.useRef([]), r = m.useRef([
      0,
      0
    ]), o = m.useRef(), i = m.useState(UE++)[0], c = m.useState(o1)[0], d = m.useRef(l);
    m.useEffect(function() {
      d.current = l;
    }, [
      l
    ]), m.useEffect(function() {
      if (l.inert) {
        document.body.classList.add("block-interactivity-".concat(i));
        var x = sE([
          l.lockRef.current
        ], (l.shards || []).map(Cb), true).filter(Boolean);
        return x.forEach(function(E) {
          return E.classList.add("allow-interactivity-".concat(i));
        }), function() {
          document.body.classList.remove("block-interactivity-".concat(i)), x.forEach(function(E) {
            return E.classList.remove("allow-interactivity-".concat(i));
          });
        };
      }
    }, [
      l.inert,
      l.lockRef.current,
      l.shards
    ]);
    var f = m.useCallback(function(x, E) {
      if ("touches" in x && x.touches.length === 2 || x.type === "wheel" && x.ctrlKey) return !d.current.allowPinchZoom;
      var _ = Bi(x), N = r.current, A = "deltaX" in x ? x.deltaX : N[0] - _[0], R = "deltaY" in x ? x.deltaY : N[1] - _[1], I, T = x.target, L = Math.abs(A) > Math.abs(R) ? "h" : "v";
      if ("touches" in x && L === "h" && T.type === "range") return false;
      var D = window.getSelection(), H = D && D.anchorNode, q = H ? H === T || H.contains(T) : false;
      if (q) return false;
      var re = wb(L, T);
      if (!re) return true;
      if (re ? I = L : (I = L === "v" ? "h" : "v", re = wb(L, T)), !re) return false;
      if (!o.current && "changedTouches" in x && (A || R) && (o.current = I), !I) return true;
      var ee = o.current || I;
      return DE(ee, E, x, ee === "h" ? A : R);
    }, []), g = m.useCallback(function(x) {
      var E = x;
      if (!(!Ha.length || Ha[Ha.length - 1] !== c)) {
        var _ = "deltaY" in E ? Sb(E) : Bi(E), N = n.current.filter(function(I) {
          return I.name === E.type && (I.target === E.target || E.target === I.shadowParent) && zE(I.delta, _);
        })[0];
        if (N && N.should) {
          E.cancelable && E.preventDefault();
          return;
        }
        if (!N) {
          var A = (d.current.shards || []).map(Cb).filter(Boolean).filter(function(I) {
            return I.contains(E.target);
          }), R = A.length > 0 ? f(E, A[0]) : !d.current.noIsolation;
          R && E.cancelable && E.preventDefault();
        }
      }
    }, []), p = m.useCallback(function(x, E, _, N) {
      var A = {
        name: x,
        delta: E,
        target: _,
        should: N,
        shadowParent: BE(_)
      };
      n.current.push(A), setTimeout(function() {
        n.current = n.current.filter(function(R) {
          return R !== A;
        });
      }, 1);
    }, []), v = m.useCallback(function(x) {
      r.current = Bi(x), o.current = void 0;
    }, []), b = m.useCallback(function(x) {
      p(x.type, Sb(x), x.target, f(x, l.lockRef.current));
    }, []), S = m.useCallback(function(x) {
      p(x.type, Bi(x), x.target, f(x, l.lockRef.current));
    }, []);
    m.useEffect(function() {
      return Ha.push(c), l.setCallbacks({
        onScrollCapture: b,
        onWheelCapture: b,
        onTouchMoveCapture: S
      }), document.addEventListener("wheel", g, za), document.addEventListener("touchmove", g, za), document.addEventListener("touchstart", v, za), function() {
        Ha = Ha.filter(function(x) {
          return x !== c;
        }), document.removeEventListener("wheel", g, za), document.removeEventListener("touchmove", g, za), document.removeEventListener("touchstart", v, za);
      };
    }, []);
    var C = l.removeScrollBar, k = l.inert;
    return m.createElement(m.Fragment, null, k ? m.createElement(c, {
      styles: HE(i)
    }) : null, C ? m.createElement(LE, {
      noRelative: l.noRelative,
      gapMode: l.gapMode
    }) : null);
  }
  function BE(l) {
    for (var n = null; l !== null; ) l instanceof ShadowRoot && (n = l.host, l = l.host), l = l.parentNode;
    return n;
  }
  const XE = pE(a1, YE);
  var u1 = m.forwardRef(function(l, n) {
    return m.createElement(yc, cl({}, l, {
      ref: n,
      sideCar: XE
    }));
  });
  u1.classNames = yc.classNames;
  var VE = function(l) {
    if (typeof document > "u") return null;
    var n = Array.isArray(l) ? l[0] : l;
    return n.ownerDocument.body;
  }, Ua = /* @__PURE__ */ new WeakMap(), Xi = /* @__PURE__ */ new WeakMap(), Vi = {}, Jd = 0, d1 = function(l) {
    return l && (l.host || d1(l.parentNode));
  }, $E = function(l, n) {
    return n.map(function(r) {
      if (l.contains(r)) return r;
      var o = d1(r);
      return o && l.contains(o) ? o : (console.error("aria-hidden", r, "in not contained inside", l, ". Doing nothing"), null);
    }).filter(function(r) {
      return !!r;
    });
  }, qE = function(l, n, r, o) {
    var i = $E(n, Array.isArray(l) ? l : [
      l
    ]);
    Vi[r] || (Vi[r] = /* @__PURE__ */ new WeakMap());
    var c = Vi[r], d = [], f = /* @__PURE__ */ new Set(), g = new Set(i), p = function(b) {
      !b || f.has(b) || (f.add(b), p(b.parentNode));
    };
    i.forEach(p);
    var v = function(b) {
      !b || g.has(b) || Array.prototype.forEach.call(b.children, function(S) {
        if (f.has(S)) v(S);
        else try {
          var C = S.getAttribute(o), k = C !== null && C !== "false", x = (Ua.get(S) || 0) + 1, E = (c.get(S) || 0) + 1;
          Ua.set(S, x), c.set(S, E), d.push(S), x === 1 && k && Xi.set(S, true), E === 1 && S.setAttribute(r, "true"), k || S.setAttribute(o, "true");
        } catch (_) {
          console.error("aria-hidden: cannot operate on ", S, _);
        }
      });
    };
    return v(n), f.clear(), Jd++, function() {
      d.forEach(function(b) {
        var S = Ua.get(b) - 1, C = c.get(b) - 1;
        Ua.set(b, S), c.set(b, C), S || (Xi.has(b) || b.removeAttribute(o), Xi.delete(b)), C || b.removeAttribute(r);
      }), Jd--, Jd || (Ua = /* @__PURE__ */ new WeakMap(), Ua = /* @__PURE__ */ new WeakMap(), Xi = /* @__PURE__ */ new WeakMap(), Vi = {});
    };
  }, GE = function(l, n, r) {
    r === void 0 && (r = "data-aria-hidden");
    var o = Array.from(Array.isArray(l) ? l : [
      l
    ]), i = VE(l);
    return i ? (o.push.apply(o, Array.from(i.querySelectorAll("[aria-live], script"))), qE(o, i, r, "aria-hidden")) : function() {
      return null;
    };
  }, bc = "Dialog", [f1] = x5(bc), [PE, Qn] = f1(bc), h1 = (l) => {
    const { __scopeDialog: n, children: r, open: o, defaultOpen: i, onOpenChange: c, modal: d = true } = l, f = m.useRef(null), g = m.useRef(null), [p, v] = _5({
      prop: o,
      defaultProp: i ?? false,
      onChange: c,
      caller: bc
    });
    return y.jsx(PE, {
      scope: n,
      triggerRef: f,
      contentRef: g,
      contentId: Il(),
      titleId: Il(),
      descriptionId: Il(),
      open: p,
      onOpenChange: v,
      onOpenToggle: m.useCallback(() => v((b) => !b), [
        v
      ]),
      modal: d,
      children: r
    });
  };
  h1.displayName = bc;
  var m1 = "DialogTrigger", KE = m.forwardRef((l, n) => {
    const { __scopeDialog: r, ...o } = l, i = Qn(m1, r), c = Fr(n, i.triggerRef);
    return y.jsx(ms.button, {
      type: "button",
      "aria-haspopup": "dialog",
      "aria-expanded": i.open,
      "aria-controls": i.contentId,
      "data-state": ph(i.open),
      ...o,
      ref: c,
      onClick: gr(l.onClick, i.onOpenToggle)
    });
  });
  KE.displayName = m1;
  var mh = "DialogPortal", [ZE, g1] = f1(mh, {
    forceMount: void 0
  }), p1 = (l) => {
    const { __scopeDialog: n, forceMount: r, children: o, container: i } = l, c = Qn(mh, n);
    return y.jsx(ZE, {
      scope: n,
      forceMount: r,
      children: m.Children.map(o, (d) => y.jsx(pc, {
        present: r || c.open,
        children: y.jsx(n1, {
          asChild: true,
          container: i,
          children: d
        })
      }))
    });
  };
  p1.displayName = mh;
  var rc = "DialogOverlay", y1 = m.forwardRef((l, n) => {
    const r = g1(rc, l.__scopeDialog), { forceMount: o = r.forceMount, ...i } = l, c = Qn(rc, l.__scopeDialog);
    return c.modal ? y.jsx(pc, {
      present: o || c.open,
      children: y.jsx(QE, {
        ...i,
        ref: n
      })
    }) : null;
  });
  y1.displayName = rc;
  var FE = hs("DialogOverlay.RemoveScroll"), QE = m.forwardRef((l, n) => {
    const { __scopeDialog: r, ...o } = l, i = Qn(rc, r);
    return y.jsx(u1, {
      as: FE,
      allowPinchZoom: true,
      shards: [
        i.contentRef
      ],
      children: y.jsx(ms.div, {
        "data-state": ph(i.open),
        ...o,
        ref: n,
        style: {
          pointerEvents: "auto",
          ...o.style
        }
      })
    });
  }), Pr = "DialogContent", b1 = m.forwardRef((l, n) => {
    const r = g1(Pr, l.__scopeDialog), { forceMount: o = r.forceMount, ...i } = l, c = Qn(Pr, l.__scopeDialog);
    return y.jsx(pc, {
      present: o || c.open,
      children: c.modal ? y.jsx(WE, {
        ...i,
        ref: n
      }) : y.jsx(JE, {
        ...i,
        ref: n
      })
    });
  });
  b1.displayName = Pr;
  var WE = m.forwardRef((l, n) => {
    const r = Qn(Pr, l.__scopeDialog), o = m.useRef(null), i = Fr(n, r.contentRef, o);
    return m.useEffect(() => {
      const c = o.current;
      if (c) return GE(c);
    }, []), y.jsx(v1, {
      ...l,
      ref: i,
      trapFocus: r.open,
      disableOutsidePointerEvents: true,
      onCloseAutoFocus: gr(l.onCloseAutoFocus, (c) => {
        var _a;
        c.preventDefault(), (_a = r.triggerRef.current) == null ? void 0 : _a.focus();
      }),
      onPointerDownOutside: gr(l.onPointerDownOutside, (c) => {
        const d = c.detail.originalEvent, f = d.button === 0 && d.ctrlKey === true;
        (d.button === 2 || f) && c.preventDefault();
      }),
      onFocusOutside: gr(l.onFocusOutside, (c) => c.preventDefault())
    });
  }), JE = m.forwardRef((l, n) => {
    const r = Qn(Pr, l.__scopeDialog), o = m.useRef(false), i = m.useRef(false);
    return y.jsx(v1, {
      ...l,
      ref: n,
      trapFocus: false,
      disableOutsidePointerEvents: false,
      onCloseAutoFocus: (c) => {
        var _a, _b2;
        (_a = l.onCloseAutoFocus) == null ? void 0 : _a.call(l, c), c.defaultPrevented || (o.current || ((_b2 = r.triggerRef.current) == null ? void 0 : _b2.focus()), c.preventDefault()), o.current = false, i.current = false;
      },
      onInteractOutside: (c) => {
        var _a, _b2;
        (_a = l.onInteractOutside) == null ? void 0 : _a.call(l, c), c.defaultPrevented || (o.current = true, c.detail.originalEvent.type === "pointerdown" && (i.current = true));
        const d = c.target;
        ((_b2 = r.triggerRef.current) == null ? void 0 : _b2.contains(d)) && c.preventDefault(), c.detail.originalEvent.type === "focusin" && i.current && c.preventDefault();
      }
    });
  }), v1 = m.forwardRef((l, n) => {
    const { __scopeDialog: r, trapFocus: o, onOpenAutoFocus: i, onCloseAutoFocus: c, ...d } = l, f = Qn(Pr, r), g = m.useRef(null), p = Fr(n, g);
    return oE(), y.jsxs(y.Fragment, {
      children: [
        y.jsx(e1, {
          asChild: true,
          loop: true,
          trapped: o,
          onMountAutoFocus: i,
          onUnmountAutoFocus: c,
          children: y.jsx(W0, {
            role: "dialog",
            id: f.contentId,
            "aria-describedby": f.descriptionId,
            "aria-labelledby": f.titleId,
            "data-state": ph(f.open),
            ...d,
            ref: p,
            onDismiss: () => f.onOpenChange(false)
          })
        }),
        y.jsxs(y.Fragment, {
          children: [
            y.jsx(l_, {
              titleId: f.titleId
            }),
            y.jsx(a_, {
              contentRef: g,
              descriptionId: f.descriptionId
            })
          ]
        })
      ]
    });
  }), gh = "DialogTitle", e_ = m.forwardRef((l, n) => {
    const { __scopeDialog: r, ...o } = l, i = Qn(gh, r);
    return y.jsx(ms.h2, {
      id: i.titleId,
      ...o,
      ref: n
    });
  });
  e_.displayName = gh;
  var x1 = "DialogDescription", t_ = m.forwardRef((l, n) => {
    const { __scopeDialog: r, ...o } = l, i = Qn(x1, r);
    return y.jsx(ms.p, {
      id: i.descriptionId,
      ...o,
      ref: n
    });
  });
  t_.displayName = x1;
  var w1 = "DialogClose", n_ = m.forwardRef((l, n) => {
    const { __scopeDialog: r, ...o } = l, i = Qn(w1, r);
    return y.jsx(ms.button, {
      type: "button",
      ...o,
      ref: n,
      onClick: gr(l.onClick, () => i.onOpenChange(false))
    });
  });
  n_.displayName = w1;
  function ph(l) {
    return l ? "open" : "closed";
  }
  var S1 = "DialogTitleWarning", [lj, C1] = v5(S1, {
    contentName: Pr,
    titleName: gh,
    docsSlug: "dialog"
  }), l_ = ({ titleId: l }) => {
    const n = C1(S1), r = `\`${n.contentName}\` requires a \`${n.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${n.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${n.docsSlug}`;
    return m.useEffect(() => {
      l && (document.getElementById(l) || console.error(r));
    }, [
      r,
      l
    ]), null;
  }, r_ = "DialogDescriptionWarning", a_ = ({ contentRef: l, descriptionId: n }) => {
    const o = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${C1(r_).contentName}}.`;
    return m.useEffect(() => {
      var _a;
      const i = (_a = l.current) == null ? void 0 : _a.getAttribute("aria-describedby");
      n && i && (document.getElementById(n) || console.warn(o));
    }, [
      o,
      l,
      n
    ]), null;
  }, o_ = h1, s_ = p1, i_ = y1, c_ = b1, u_ = Symbol.for("react.lazy"), ac = nh[" use ".trim().toString()];
  function d_(l) {
    return typeof l == "object" && l !== null && "then" in l;
  }
  function E1(l) {
    return l != null && typeof l == "object" && "$$typeof" in l && l.$$typeof === u_ && "_payload" in l && d_(l._payload);
  }
  function f_(l) {
    const n = h_(l), r = m.forwardRef((o, i) => {
      let { children: c, ...d } = o;
      E1(c) && typeof ac == "function" && (c = ac(c._payload));
      const f = m.Children.toArray(c), g = f.find(g_);
      if (g) {
        const p = g.props.children, v = f.map((b) => b === g ? m.Children.count(p) > 1 ? m.Children.only(null) : m.isValidElement(p) ? p.props.children : null : b);
        return y.jsx(n, {
          ...d,
          ref: i,
          children: m.isValidElement(p) ? m.cloneElement(p, void 0, v) : null
        });
      }
      return y.jsx(n, {
        ...d,
        ref: i,
        children: c
      });
    });
    return r.displayName = `${l}.Slot`, r;
  }
  function h_(l) {
    const n = m.forwardRef((r, o) => {
      let { children: i, ...c } = r;
      if (E1(i) && typeof ac == "function" && (i = ac(i._payload)), m.isValidElement(i)) {
        const d = y_(i), f = p_(c, i.props);
        return i.type !== m.Fragment && (f.ref = o ? br(o, d) : d), m.cloneElement(i, f);
      }
      return m.Children.count(i) > 1 ? m.Children.only(null) : null;
    });
    return n.displayName = `${l}.SlotClone`, n;
  }
  var m_ = Symbol("radix.slottable");
  function g_(l) {
    return m.isValidElement(l) && typeof l.type == "function" && "__radixId" in l.type && l.type.__radixId === m_;
  }
  function p_(l, n) {
    const r = {
      ...n
    };
    for (const o in n) {
      const i = l[o], c = n[o];
      /^on[A-Z]/.test(o) ? i && c ? r[o] = (...f) => {
        const g = c(...f);
        return i(...f), g;
      } : i && (r[o] = i) : o === "style" ? r[o] = {
        ...i,
        ...c
      } : o === "className" && (r[o] = [
        i,
        c
      ].filter(Boolean).join(" "));
    }
    return {
      ...l,
      ...r
    };
  }
  function y_(l) {
    var _a, _b2;
    let n = (_a = Object.getOwnPropertyDescriptor(l.props, "ref")) == null ? void 0 : _a.get, r = n && "isReactWarning" in n && n.isReactWarning;
    return r ? l.ref : (n = (_b2 = Object.getOwnPropertyDescriptor(l, "ref")) == null ? void 0 : _b2.get, r = n && "isReactWarning" in n && n.isReactWarning, r ? l.props.ref : l.props.ref || l.ref);
  }
  var b_ = [
    "a",
    "button",
    "div",
    "form",
    "h2",
    "h3",
    "img",
    "input",
    "label",
    "li",
    "nav",
    "ol",
    "p",
    "select",
    "span",
    "svg",
    "ul"
  ], wr = b_.reduce((l, n) => {
    const r = f_(`Primitive.${n}`), o = m.forwardRef((i, c) => {
      const { asChild: d, ...f } = i, g = d ? r : n;
      return typeof window < "u" && (window[Symbol.for("radix-ui")] = true), y.jsx(g, {
        ...f,
        ref: c
      });
    });
    return o.displayName = `Primitive.${n}`, {
      ...l,
      [n]: o
    };
  }, {}), qo = '[cmdk-group=""]', ef = '[cmdk-group-items=""]', v_ = '[cmdk-group-heading=""]', _1 = '[cmdk-item=""]', Eb = `${_1}:not([aria-disabled="true"])`, Qf = "cmdk-item-select", Ya = "data-value", x_ = (l, n, r) => b5(l, n, r), k1 = m.createContext(void 0), gs = () => m.useContext(k1), M1 = m.createContext(void 0), yh = () => m.useContext(M1), j1 = m.createContext(void 0), L1 = m.forwardRef((l, n) => {
    let r = Ba(() => {
      var O, K;
      return {
        search: "",
        value: (K = (O = l.value) != null ? O : l.defaultValue) != null ? K : "",
        selectedItemId: void 0,
        filtered: {
          count: 0,
          items: /* @__PURE__ */ new Map(),
          groups: /* @__PURE__ */ new Set()
        }
      };
    }), o = Ba(() => /* @__PURE__ */ new Set()), i = Ba(() => /* @__PURE__ */ new Map()), c = Ba(() => /* @__PURE__ */ new Map()), d = Ba(() => /* @__PURE__ */ new Set()), f = R1(l), { label: g, children: p, value: v, onValueChange: b, filter: S, shouldFilter: C, loop: k, disablePointerSelection: x = false, vimBindings: E = true, ..._ } = l, N = Il(), A = Il(), R = Il(), I = m.useRef(null), T = A_();
    Kr(() => {
      if (v !== void 0) {
        let O = v.trim();
        r.current.value = O, L.emit();
      }
    }, [
      v
    ]), Kr(() => {
      T(6, de);
    }, []);
    let L = m.useMemo(() => ({
      subscribe: (O) => (d.current.add(O), () => d.current.delete(O)),
      snapshot: () => r.current,
      setState: (O, K, W) => {
        var J, ie, pe, Re;
        if (!Object.is(r.current[O], K)) {
          if (r.current[O] = K, O === "search") ee(), q(), T(1, re);
          else if (O === "value") {
            if (document.activeElement.hasAttribute("cmdk-input") || document.activeElement.hasAttribute("cmdk-root")) {
              let X = document.getElementById(R);
              X ? X.focus() : (J = document.getElementById(N)) == null || J.focus();
            }
            if (T(7, () => {
              var X;
              r.current.selectedItemId = (X = ge()) == null ? void 0 : X.id, L.emit();
            }), W || T(5, de), ((ie = f.current) == null ? void 0 : ie.value) !== void 0) {
              let X = K ?? "";
              (Re = (pe = f.current).onValueChange) == null || Re.call(pe, X);
              return;
            }
          }
          L.emit();
        }
      },
      emit: () => {
        d.current.forEach((O) => O());
      }
    }), []), D = m.useMemo(() => ({
      value: (O, K, W) => {
        var J;
        K !== ((J = c.current.get(O)) == null ? void 0 : J.value) && (c.current.set(O, {
          value: K,
          keywords: W
        }), r.current.filtered.items.set(O, H(K, W)), T(2, () => {
          q(), L.emit();
        }));
      },
      item: (O, K) => (o.current.add(O), K && (i.current.has(K) ? i.current.get(K).add(O) : i.current.set(K, /* @__PURE__ */ new Set([
        O
      ]))), T(3, () => {
        ee(), q(), r.current.value || re(), L.emit();
      }), () => {
        c.current.delete(O), o.current.delete(O), r.current.filtered.items.delete(O);
        let W = ge();
        T(4, () => {
          ee(), (W == null ? void 0 : W.getAttribute("id")) === O && re(), L.emit();
        });
      }),
      group: (O) => (i.current.has(O) || i.current.set(O, /* @__PURE__ */ new Set()), () => {
        c.current.delete(O), i.current.delete(O);
      }),
      filter: () => f.current.shouldFilter,
      label: g || l["aria-label"],
      getDisablePointerSelection: () => f.current.disablePointerSelection,
      listId: N,
      inputId: R,
      labelId: A,
      listInnerRef: I
    }), []);
    function H(O, K) {
      var W, J;
      let ie = (J = (W = f.current) == null ? void 0 : W.filter) != null ? J : x_;
      return O ? ie(O, r.current.search, K) : 0;
    }
    function q() {
      if (!r.current.search || f.current.shouldFilter === false) return;
      let O = r.current.filtered.items, K = [];
      r.current.filtered.groups.forEach((J) => {
        let ie = i.current.get(J), pe = 0;
        ie.forEach((Re) => {
          let X = O.get(Re);
          pe = Math.max(X, pe);
        }), K.push([
          J,
          pe
        ]);
      });
      let W = I.current;
      Ee().sort((J, ie) => {
        var pe, Re;
        let X = J.getAttribute("id"), U = ie.getAttribute("id");
        return ((pe = O.get(U)) != null ? pe : 0) - ((Re = O.get(X)) != null ? Re : 0);
      }).forEach((J) => {
        let ie = J.closest(ef);
        ie ? ie.appendChild(J.parentElement === ie ? J : J.closest(`${ef} > *`)) : W.appendChild(J.parentElement === W ? J : J.closest(`${ef} > *`));
      }), K.sort((J, ie) => ie[1] - J[1]).forEach((J) => {
        var ie;
        let pe = (ie = I.current) == null ? void 0 : ie.querySelector(`${qo}[${Ya}="${encodeURIComponent(J[0])}"]`);
        pe == null ? void 0 : pe.parentElement.appendChild(pe);
      });
    }
    function re() {
      let O = Ee().find((W) => W.getAttribute("aria-disabled") !== "true"), K = O == null ? void 0 : O.getAttribute(Ya);
      L.setState("value", K || void 0);
    }
    function ee() {
      var O, K, W, J;
      if (!r.current.search || f.current.shouldFilter === false) {
        r.current.filtered.count = o.current.size;
        return;
      }
      r.current.filtered.groups = /* @__PURE__ */ new Set();
      let ie = 0;
      for (let pe of o.current) {
        let Re = (K = (O = c.current.get(pe)) == null ? void 0 : O.value) != null ? K : "", X = (J = (W = c.current.get(pe)) == null ? void 0 : W.keywords) != null ? J : [], U = H(Re, X);
        r.current.filtered.items.set(pe, U), U > 0 && ie++;
      }
      for (let [pe, Re] of i.current) for (let X of Re) if (r.current.filtered.items.get(X) > 0) {
        r.current.filtered.groups.add(pe);
        break;
      }
      r.current.filtered.count = ie;
    }
    function de() {
      var O, K, W;
      let J = ge();
      J && (((O = J.parentElement) == null ? void 0 : O.firstChild) === J && ((W = (K = J.closest(qo)) == null ? void 0 : K.querySelector(v_)) == null || W.scrollIntoView({
        block: "nearest"
      })), J.scrollIntoView({
        block: "nearest"
      }));
    }
    function ge() {
      var O;
      return (O = I.current) == null ? void 0 : O.querySelector(`${_1}[aria-selected="true"]`);
    }
    function Ee() {
      var O;
      return Array.from(((O = I.current) == null ? void 0 : O.querySelectorAll(Eb)) || []);
    }
    function $(O) {
      let K = Ee()[O];
      K && L.setState("value", K.getAttribute(Ya));
    }
    function F(O) {
      var K;
      let W = ge(), J = Ee(), ie = J.findIndex((Re) => Re === W), pe = J[ie + O];
      (K = f.current) != null && K.loop && (pe = ie + O < 0 ? J[J.length - 1] : ie + O === J.length ? J[0] : J[ie + O]), pe && L.setState("value", pe.getAttribute(Ya));
    }
    function fe(O) {
      let K = ge(), W = K == null ? void 0 : K.closest(qo), J;
      for (; W && !J; ) W = O > 0 ? L_(W, qo) : R_(W, qo), J = W == null ? void 0 : W.querySelector(Eb);
      J ? L.setState("value", J.getAttribute(Ya)) : F(O);
    }
    let ye = () => $(Ee().length - 1), ke = (O) => {
      O.preventDefault(), O.metaKey ? ye() : O.altKey ? fe(1) : F(1);
    }, j = (O) => {
      O.preventDefault(), O.metaKey ? $(0) : O.altKey ? fe(-1) : F(-1);
    };
    return m.createElement(wr.div, {
      ref: n,
      tabIndex: -1,
      ..._,
      "cmdk-root": "",
      onKeyDown: (O) => {
        var K;
        (K = _.onKeyDown) == null || K.call(_, O);
        let W = O.nativeEvent.isComposing || O.keyCode === 229;
        if (!(O.defaultPrevented || W)) switch (O.key) {
          case "n":
          case "j": {
            E && O.ctrlKey && ke(O);
            break;
          }
          case "ArrowDown": {
            ke(O);
            break;
          }
          case "p":
          case "k": {
            E && O.ctrlKey && j(O);
            break;
          }
          case "ArrowUp": {
            j(O);
            break;
          }
          case "Home": {
            O.preventDefault(), $(0);
            break;
          }
          case "End": {
            O.preventDefault(), ye();
            break;
          }
          case "Enter": {
            O.preventDefault();
            let J = ge();
            if (J) {
              let ie = new Event(Qf);
              J.dispatchEvent(ie);
            }
          }
        }
      }
    }, m.createElement("label", {
      "cmdk-label": "",
      htmlFor: D.inputId,
      id: D.labelId,
      style: N_
    }, g), vc(l, (O) => m.createElement(M1.Provider, {
      value: L
    }, m.createElement(k1.Provider, {
      value: D
    }, O))));
  }), w_ = m.forwardRef((l, n) => {
    var r, o;
    let i = Il(), c = m.useRef(null), d = m.useContext(j1), f = gs(), g = R1(l), p = (o = (r = g.current) == null ? void 0 : r.forceMount) != null ? o : d == null ? void 0 : d.forceMount;
    Kr(() => {
      if (!p) return f.item(i, d == null ? void 0 : d.id);
    }, [
      p
    ]);
    let v = A1(i, c, [
      l.value,
      l.children,
      c
    ], l.keywords), b = yh(), S = vr((T) => T.value && T.value === v.current), C = vr((T) => p || f.filter() === false ? true : T.search ? T.filtered.items.get(i) > 0 : true);
    m.useEffect(() => {
      let T = c.current;
      if (!(!T || l.disabled)) return T.addEventListener(Qf, k), () => T.removeEventListener(Qf, k);
    }, [
      C,
      l.onSelect,
      l.disabled
    ]);
    function k() {
      var T, L;
      x(), (L = (T = g.current).onSelect) == null || L.call(T, v.current);
    }
    function x() {
      b.setState("value", v.current, true);
    }
    if (!C) return null;
    let { disabled: E, value: _, onSelect: N, forceMount: A, keywords: R, ...I } = l;
    return m.createElement(wr.div, {
      ref: br(c, n),
      ...I,
      id: i,
      "cmdk-item": "",
      role: "option",
      "aria-disabled": !!E,
      "aria-selected": !!S,
      "data-disabled": !!E,
      "data-selected": !!S,
      onPointerMove: E || f.getDisablePointerSelection() ? void 0 : x,
      onClick: E ? void 0 : k
    }, l.children);
  }), S_ = m.forwardRef((l, n) => {
    let { heading: r, children: o, forceMount: i, ...c } = l, d = Il(), f = m.useRef(null), g = m.useRef(null), p = Il(), v = gs(), b = vr((C) => i || v.filter() === false ? true : C.search ? C.filtered.groups.has(d) : true);
    Kr(() => v.group(d), []), A1(d, f, [
      l.value,
      l.heading,
      g
    ]);
    let S = m.useMemo(() => ({
      id: d,
      forceMount: i
    }), [
      i
    ]);
    return m.createElement(wr.div, {
      ref: br(f, n),
      ...c,
      "cmdk-group": "",
      role: "presentation",
      hidden: b ? void 0 : true
    }, r && m.createElement("div", {
      ref: g,
      "cmdk-group-heading": "",
      "aria-hidden": true,
      id: p
    }, r), vc(l, (C) => m.createElement("div", {
      "cmdk-group-items": "",
      role: "group",
      "aria-labelledby": r ? p : void 0
    }, m.createElement(j1.Provider, {
      value: S
    }, C))));
  }), C_ = m.forwardRef((l, n) => {
    let { alwaysRender: r, ...o } = l, i = m.useRef(null), c = vr((d) => !d.search);
    return !r && !c ? null : m.createElement(wr.div, {
      ref: br(i, n),
      ...o,
      "cmdk-separator": "",
      role: "separator"
    });
  }), E_ = m.forwardRef((l, n) => {
    let { onValueChange: r, ...o } = l, i = l.value != null, c = yh(), d = vr((p) => p.search), f = vr((p) => p.selectedItemId), g = gs();
    return m.useEffect(() => {
      l.value != null && c.setState("search", l.value);
    }, [
      l.value
    ]), m.createElement(wr.input, {
      ref: n,
      ...o,
      "cmdk-input": "",
      autoComplete: "off",
      autoCorrect: "off",
      spellCheck: false,
      "aria-autocomplete": "list",
      role: "combobox",
      "aria-expanded": true,
      "aria-controls": g.listId,
      "aria-labelledby": g.labelId,
      "aria-activedescendant": f,
      id: g.inputId,
      type: "text",
      value: i ? l.value : d,
      onChange: (p) => {
        i || c.setState("search", p.target.value), r == null ? void 0 : r(p.target.value);
      }
    });
  }), __ = m.forwardRef((l, n) => {
    let { children: r, label: o = "Suggestions", ...i } = l, c = m.useRef(null), d = m.useRef(null), f = vr((p) => p.selectedItemId), g = gs();
    return m.useEffect(() => {
      if (d.current && c.current) {
        let p = d.current, v = c.current, b, S = new ResizeObserver(() => {
          b = requestAnimationFrame(() => {
            let C = p.offsetHeight;
            v.style.setProperty("--cmdk-list-height", C.toFixed(1) + "px");
          });
        });
        return S.observe(p), () => {
          cancelAnimationFrame(b), S.unobserve(p);
        };
      }
    }, []), m.createElement(wr.div, {
      ref: br(c, n),
      ...i,
      "cmdk-list": "",
      role: "listbox",
      tabIndex: -1,
      "aria-activedescendant": f,
      "aria-label": o,
      id: g.listId
    }, vc(l, (p) => m.createElement("div", {
      ref: br(d, g.listInnerRef),
      "cmdk-list-sizer": ""
    }, p)));
  }), k_ = m.forwardRef((l, n) => {
    let { open: r, onOpenChange: o, overlayClassName: i, contentClassName: c, container: d, ...f } = l;
    return m.createElement(o_, {
      open: r,
      onOpenChange: o
    }, m.createElement(s_, {
      container: d
    }, m.createElement(i_, {
      "cmdk-overlay": "",
      className: i
    }), m.createElement(c_, {
      "aria-label": l.label,
      "cmdk-dialog": "",
      className: c
    }, m.createElement(L1, {
      ref: n,
      ...f
    }))));
  }), M_ = m.forwardRef((l, n) => vr((r) => r.filtered.count === 0) ? m.createElement(wr.div, {
    ref: n,
    ...l,
    "cmdk-empty": "",
    role: "presentation"
  }) : null), j_ = m.forwardRef((l, n) => {
    let { progress: r, children: o, label: i = "Loading...", ...c } = l;
    return m.createElement(wr.div, {
      ref: n,
      ...c,
      "cmdk-loading": "",
      role: "progressbar",
      "aria-valuenow": r,
      "aria-valuemin": 0,
      "aria-valuemax": 100,
      "aria-label": i
    }, vc(l, (d) => m.createElement("div", {
      "aria-hidden": true
    }, d)));
  }), Po = Object.assign(L1, {
    List: __,
    Item: w_,
    Input: E_,
    Group: S_,
    Separator: C_,
    Dialog: k_,
    Empty: M_,
    Loading: j_
  });
  function L_(l, n) {
    let r = l.nextElementSibling;
    for (; r; ) {
      if (r.matches(n)) return r;
      r = r.nextElementSibling;
    }
  }
  function R_(l, n) {
    let r = l.previousElementSibling;
    for (; r; ) {
      if (r.matches(n)) return r;
      r = r.previousElementSibling;
    }
  }
  function R1(l) {
    let n = m.useRef(l);
    return Kr(() => {
      n.current = l;
    }), n;
  }
  var Kr = typeof window > "u" ? m.useEffect : m.useLayoutEffect;
  function Ba(l) {
    let n = m.useRef();
    return n.current === void 0 && (n.current = l()), n;
  }
  function vr(l) {
    let n = yh(), r = () => l(n.snapshot());
    return m.useSyncExternalStore(n.subscribe, r, r);
  }
  function A1(l, n, r, o = []) {
    let i = m.useRef(), c = gs();
    return Kr(() => {
      var d;
      let f = (() => {
        var p;
        for (let v of r) {
          if (typeof v == "string") return v.trim();
          if (typeof v == "object" && "current" in v) return v.current ? (p = v.current.textContent) == null ? void 0 : p.trim() : i.current;
        }
      })(), g = o.map((p) => p.trim());
      c.value(l, f, g), (d = n.current) == null || d.setAttribute(Ya, f), i.current = f;
    }), i;
  }
  var A_ = () => {
    let [l, n] = m.useState(), r = Ba(() => /* @__PURE__ */ new Map());
    return Kr(() => {
      r.current.forEach((o) => o()), r.current = /* @__PURE__ */ new Map();
    }, [
      l
    ]), (o, i) => {
      r.current.set(o, i), n({});
    };
  };
  function T_(l) {
    let n = l.type;
    return typeof n == "function" ? n(l.props) : "render" in n ? n.render(l.props) : l;
  }
  function vc({ asChild: l, children: n }, r) {
    return l && m.isValidElement(n) ? m.cloneElement(T_(n), {
      ref: n.ref
    }, r(n.props.children)) : r(n);
  }
  var N_ = {
    position: "absolute",
    width: "1px",
    height: "1px",
    padding: "0",
    margin: "-1px",
    overflow: "hidden",
    clip: "rect(0, 0, 0, 0)",
    whiteSpace: "nowrap",
    borderWidth: "0"
  };
  const as = _t()(lh((l) => ({
    isMinimized: true,
    toggle: () => l((n) => ({
      isMinimized: !n.isMinimized
    }))
  }), {
    name: "rosette-minimap",
    partialize: (l) => ({
      isMinimized: l.isMinimized
    })
  })), O_ = "image/png,image/jpeg,image/svg+xml,image/webp,image/gif,image/bmp";
  function I_(l) {
    var _a;
    const n = ((_a = l.split(".").pop()) == null ? void 0 : _a.toLowerCase()) ?? "";
    return {
      png: "image/png",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      svg: "image/svg+xml",
      webp: "image/webp",
      gif: "image/gif",
      bmp: "image/bmp"
    }[n] ?? "application/octet-stream";
  }
  function D_(l) {
    return l.replace(/\\/g, "/").split("/").pop() ?? l;
  }
  function T1(l) {
    return new Promise((n, r) => {
      const o = new Image();
      o.onload = () => n({
        naturalWidth: o.naturalWidth,
        naturalHeight: o.naturalHeight
      }), o.onerror = () => r(new Error("Failed to decode image")), o.src = l;
    });
  }
  function z_() {
    return new Promise((l) => {
      const n = document.createElement("input");
      n.type = "file", n.accept = O_, n.style.display = "none", n.addEventListener("change", async () => {
        var _a;
        const r = (_a = n.files) == null ? void 0 : _a[0];
        if (!r) {
          l(null);
          return;
        }
        const o = URL.createObjectURL(r);
        try {
          const { naturalWidth: i, naturalHeight: c } = await T1(o);
          l({
            url: o,
            filename: r.name,
            naturalWidth: i,
            naturalHeight: c
          });
        } catch {
          URL.revokeObjectURL(o), l(null);
        }
      }), n.addEventListener("cancel", () => l(null)), document.body.appendChild(n), n.click(), document.body.removeChild(n);
    });
  }
  async function H_() {
    const l = await f0();
    if (!l) return null;
    const n = D_(l), r = I_(n), o = await h0(l), i = new Blob([
      o.buffer
    ], {
      type: r
    }), c = URL.createObjectURL(i);
    try {
      const { naturalWidth: d, naturalHeight: f } = await T1(c);
      return {
        url: c,
        filename: n,
        naturalWidth: d,
        naturalHeight: f
      };
    } catch {
      return URL.revokeObjectURL(c), null;
    }
  }
  function U_(l) {
    const { zoom: n, offset: r } = Ve.getState(), o = document.getElementById("rosette-canvas");
    if (!o) return;
    const i = o.getBoundingClientRect(), c = (i.width / 2 - r.x) / n, d = (i.height / 2 - r.y) / n, g = i.width / n * 0.2, p = l.naturalHeight / l.naturalWidth, v = g * p, b = c - g / 2, S = d - v / 2, C = {
      id: crypto.randomUUID(),
      url: l.url,
      filename: l.filename,
      x: b,
      y: S,
      width: g,
      height: v,
      naturalWidth: l.naturalWidth,
      naturalHeight: l.naturalHeight,
      lockAspectRatio: true
    }, { library: k, renderer: x } = Se.getState();
    if (k && x) {
      const E = new i2(C);
      ce.getState().execute(E, {
        library: k,
        renderer: x
      });
    }
  }
  async function Y_() {
    const l = Yn ? await H_() : await z_();
    l && U_(l);
  }
  function B_() {
    const { setThemeSetting: l } = me.getState(), { close: n } = cn.getState(), { setTool: r } = Gt.getState();
    return [
      {
        id: "file-new",
        type: "command",
        name: "File: New",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "N"
        },
        action: async () => {
          n();
          const { handleNewFile: i } = await yt(async () => {
            const { handleNewFile: c } = await Promise.resolve().then(() => Zn);
            return {
              handleNewFile: c
            };
          }, void 0);
          await i();
        },
        searchableText: "File new create blank empty reset"
      },
      ..."__TAURI__" in window ? [
        {
          id: "file-open",
          type: "command",
          name: "File: Open GDS",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "O"
          },
          action: async () => {
            n();
            const { emitOpenFile: i } = await yt(async () => {
              const { emitOpenFile: f } = await Promise.resolve().then(() => Zn);
              return {
                emitOpenFile: f
              };
            }, void 0), { pickGdsFile: c } = await yt(async () => {
              const { pickGdsFile: f } = await Promise.resolve().then(() => g0);
              return {
                pickGdsFile: f
              };
            }, void 0), d = await c();
            d && await i(d);
          },
          searchableText: "File open gds load import"
        },
        {
          id: "file-save",
          type: "command",
          name: "File: Save",
          shortcut: {
            modifiers: [
              He.mod
            ],
            key: "S"
          },
          action: async () => {
            n();
            const { handleSave: i } = await yt(async () => {
              const { handleSave: c } = await Promise.resolve().then(() => Zn);
              return {
                handleSave: c
              };
            }, void 0);
            await i(false);
          },
          searchableText: "File save gds export write"
        },
        {
          id: "file-save-as",
          type: "command",
          name: "File: Save As",
          shortcut: {
            modifiers: [
              He.mod,
              "\u21E7"
            ],
            key: "S"
          },
          action: async () => {
            n();
            const { handleSave: i } = await yt(async () => {
              const { handleSave: c } = await Promise.resolve().then(() => Zn);
              return {
                handleSave: c
              };
            }, void 0);
            await i(true);
          },
          searchableText: "File save as gds export write new"
        }
      ] : [],
      {
        id: "file-screenshot",
        type: "command",
        name: "File: Export Screenshot",
        action: async () => {
          n();
          const { handleScreenshot: i } = await yt(async () => {
            const { handleScreenshot: c } = await Promise.resolve().then(() => Zn);
            return {
              handleScreenshot: c
            };
          }, void 0);
          await i();
        },
        searchableText: "File export screenshot image png capture canvas save picture"
      },
      {
        id: "file-screenshot-clipboard",
        type: "command",
        name: "File: Copy Screenshot to Clipboard",
        action: async () => {
          n();
          const { handleScreenshotToClipboard: i } = await yt(async () => {
            const { handleScreenshotToClipboard: c } = await Promise.resolve().then(() => Zn);
            return {
              handleScreenshotToClipboard: c
            };
          }, void 0);
          await i();
        },
        searchableText: "File copy screenshot clipboard image png capture"
      },
      {
        id: "theme-dark",
        type: "command",
        name: "Set Theme: Dark",
        action: () => {
          l("dark"), n();
        },
        searchableText: "Set theme dark mode"
      },
      {
        id: "theme-light",
        type: "command",
        name: "Set Theme: Light",
        action: () => {
          l("light"), n();
        },
        searchableText: "Set theme light mode"
      },
      {
        id: "theme-system",
        type: "command",
        name: "Set Theme: System",
        action: () => {
          l("system"), n();
        },
        searchableText: "Set theme system auto automatic"
      },
      {
        id: "view-toggle-minimap",
        type: "command",
        name: "View: Toggle Minimap",
        action: () => {
          as.getState().toggle(), n();
        },
        searchableText: "Toggle minimap show hide overview map"
      },
      {
        id: "view-toggle-grid",
        type: "command",
        name: "View: Toggle Grid",
        action: () => {
          me.getState().toggleGrid(), n();
        },
        searchableText: "Toggle grid show hide dots points"
      },
      {
        id: "view-toggle-zen-mode",
        type: "command",
        name: "View: Toggle Zen Mode",
        action: () => {
          me.getState().toggleZenMode(), n();
        },
        searchableText: "Toggle zen mode focus distraction free hide toolbar explorer sidebar panels"
      },
      {
        id: "view-show-layers",
        type: "command",
        name: "View: Show Layers Panel",
        action: () => {
          me.getState().setSidebarTab("layers"), n();
        },
        searchableText: "Show layers panel sidebar switch tab"
      },
      {
        id: "view-show-inspector",
        type: "command",
        name: "View: Show Inspector Panel",
        action: () => {
          me.getState().setSidebarTab("inspector"), n();
        },
        searchableText: "Show inspector panel sidebar switch tab properties"
      },
      {
        id: "view-focus-explorer",
        type: "command",
        name: "View: Focus Explorer",
        shortcut: {
          modifiers: [
            He.shift
          ],
          key: "E"
        },
        action: () => {
          me.getState().explorerCollapsed && me.getState().toggleExplorerCollapsed(), ue.getState().setFocused(true), n();
        },
        searchableText: "Focus explorer panel cells tree navigate keyboard"
      },
      {
        id: "view-focus-layers",
        type: "command",
        name: "View: Focus Layers",
        shortcut: {
          modifiers: [
            He.shift
          ],
          key: "L"
        },
        action: () => {
          me.getState().setSidebarTab("layers"), ve.getState().setFocused(true), n();
        },
        searchableText: "Focus layers panel navigate keyboard"
      },
      {
        id: "view-zoom-in",
        type: "command",
        name: "View: Zoom In",
        shortcut: {
          key: "+"
        },
        action: () => {
          const i = document.getElementById("rosette-canvas");
          if (i) {
            const c = i.getBoundingClientRect();
            Ve.getState().zoomAt(sc, c.width / 2, c.height / 2);
          }
          n();
        },
        searchableText: "Zoom in magnify enlarge"
      },
      {
        id: "view-zoom-out",
        type: "command",
        name: "View: Zoom Out",
        shortcut: {
          key: "-"
        },
        action: () => {
          const i = document.getElementById("rosette-canvas");
          if (i) {
            const c = i.getBoundingClientRect();
            Ve.getState().zoomAt(ic, c.width / 2, c.height / 2);
          }
          n();
        },
        searchableText: "Zoom out shrink reduce"
      },
      {
        id: "view-zoom-to-fit",
        type: "command",
        name: "View: Zoom to Fit",
        shortcut: {
          key: "F"
        },
        action: () => {
          ds(), n();
        },
        searchableText: "Zoom to fit all objects view"
      },
      {
        id: "view-zoom-to-selection",
        type: "command",
        name: "View: Zoom to Selection",
        shortcut: {
          modifiers: [
            He.shift
          ],
          key: "F"
        },
        action: () => {
          const i = document.getElementById("rosette-canvas"), { library: c } = Se.getState();
          if (i && c) {
            const d = se.getState().selectedIds;
            if (d.size > 0) {
              const f = c.get_bounds_for_ids([
                ...d
              ]), g = f ? {
                minX: f[0],
                minY: f[1],
                maxX: f[2],
                maxY: f[3]
              } : null, p = Zr(i);
              Ve.getState().zoomToSelected(g, p.width, p.height, p.screenCenter);
            }
          }
          n();
        },
        searchableText: "Zoom to fit selection selected elements"
      },
      {
        id: "tool-select",
        type: "tool",
        name: "Tool: Select",
        shortcut: {
          key: "V"
        },
        action: () => {
          r("select"), n();
        },
        searchableText: "Tool select cursor pointer"
      },
      {
        id: "tool-laser",
        type: "tool",
        name: "Tool: Laser Pointer",
        shortcut: {
          key: "Q"
        },
        action: () => {
          r("laser"), n();
        },
        searchableText: "Tool laser pointer"
      },
      {
        id: "tool-pan",
        type: "tool",
        name: "Tool: Pan",
        shortcut: {
          key: "P"
        },
        action: () => {
          r("pan"), n();
        },
        searchableText: "Tool pan hand grab"
      },
      {
        id: "tool-move",
        type: "tool",
        name: "Tool: Move",
        shortcut: {
          key: "M"
        },
        action: () => {
          r("move"), n();
        },
        searchableText: "Tool move drag"
      },
      {
        id: "tool-zoom",
        type: "tool",
        name: "Tool: Zoom",
        shortcut: {
          key: "Z"
        },
        action: () => {
          r("zoom"), n();
        },
        searchableText: "Tool zoom magnify"
      },
      {
        id: "tool-ruler",
        type: "tool",
        name: "Tool: Ruler",
        shortcut: {
          key: "U"
        },
        action: () => {
          r("ruler"), n();
        },
        searchableText: "Tool ruler measure distance"
      },
      {
        id: "tool-rectangle",
        type: "tool",
        name: "Tool: Rectangle",
        shortcut: {
          key: "R"
        },
        action: () => {
          r("rectangle"), n();
        },
        searchableText: "Tool rectangle shape draw box"
      },
      {
        id: "tool-polygon",
        type: "tool",
        name: "Tool: Polygon",
        shortcut: {
          key: "G"
        },
        action: () => {
          r("polygon"), n();
        },
        searchableText: "Tool polygon shape draw"
      },
      {
        id: "tool-path",
        type: "tool",
        name: "Tool: Path",
        shortcut: {
          key: "H"
        },
        action: () => {
          r("path"), n();
        },
        searchableText: "Tool path waveguide route draw"
      },
      {
        id: "tool-text",
        type: "tool",
        name: "Tool: Text",
        shortcut: {
          key: "T"
        },
        action: () => {
          r("text"), n();
        },
        searchableText: "Tool text label annotation"
      },
      {
        id: "add-rectangle",
        type: "command",
        name: "Add: Rectangle",
        shortcut: {
          key: "R",
          then: "\u21B5"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), d = document.getElementById("rosette-canvas");
          i && c && d && N0(i, c, d), n();
        },
        searchableText: "Add rectangle create shape box place"
      },
      {
        id: "add-polygon",
        type: "command",
        name: "Add: Polygon",
        shortcut: {
          key: "G",
          then: "\u21B5"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), d = document.getElementById("rosette-canvas");
          i && c && d && O0(i, c, d), n();
        },
        searchableText: "Add polygon create shape triangle place"
      },
      {
        id: "add-path",
        type: "command",
        name: "Add: Path",
        shortcut: {
          key: "H",
          then: "\u21B5"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), d = document.getElementById("rosette-canvas");
          i && c && d && D0(i, c, d), n();
        },
        searchableText: "Add path create waveguide route place"
      },
      {
        id: "add-text",
        type: "command",
        name: "Add: Text",
        shortcut: {
          key: "T",
          then: "\u21B5"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), d = document.getElementById("rosette-canvas");
          i && c && d && I0(i, c, d), n();
        },
        searchableText: "Add text create label annotation place"
      },
      {
        id: "insert-image",
        type: "command",
        name: "Insert: Image",
        action: () => {
          Y_(), n();
        },
        searchableText: "Insert image picture photo reference overlay annotation"
      },
      {
        id: "edit-undo",
        type: "command",
        name: "Edit: Undo",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "Z"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState();
          if (i && c) {
            const { canUndo: d, undo: f } = ce.getState();
            d && f({
              library: i,
              renderer: c
            });
          }
          n();
        },
        searchableText: "Undo revert back"
      },
      {
        id: "edit-redo",
        type: "command",
        name: "Edit: Redo",
        shortcut: {
          modifiers: [
            He.mod,
            He.shift
          ],
          key: "Z"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState();
          if (i && c) {
            const { canRedo: d, redo: f } = ce.getState();
            d && f({
              library: i,
              renderer: c
            });
          }
          n();
        },
        searchableText: "Redo repeat forward"
      },
      {
        id: "edit-copy",
        type: "command",
        name: "Edit: Copy Selection",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "C"
        },
        action: () => {
          const { library: i } = Se.getState(), { selectedIds: c } = se.getState();
          if (!i || c.size === 0) {
            n();
            return;
          }
          const d = xr(i, c);
          Xn.getState().copy(d), n();
        },
        searchableText: "Copy selection clipboard"
      },
      {
        id: "edit-paste",
        type: "command",
        name: "Edit: Paste",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "V"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState();
          if (!i || !c || !Xn.getState().hasContent) {
            n();
            return;
          }
          const d = new fc();
          ce.getState().execute(d, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Paste clipboard"
      },
      {
        id: "edit-duplicate",
        type: "command",
        name: "Edit: Duplicate Selection",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "B"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), { selectedIds: d } = se.getState();
          if (!i || !c || d.size === 0) {
            n();
            return;
          }
          const f = new hc([
            ...d
          ]);
          ce.getState().execute(f, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Duplicate selection clone"
      },
      {
        id: "edit-delete",
        type: "command",
        name: "Edit: Delete Selection",
        shortcut: {
          key: He.backspace
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState(), { selectedIds: d } = se.getState();
          if (!i || !c || d.size === 0) {
            n();
            return;
          }
          const f = new dc([
            ...d
          ]);
          ce.getState().execute(f, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Delete selection remove"
      },
      {
        id: "edit-edit-selection",
        type: "command",
        name: "Edit: Edit Selection in Inspector",
        shortcut: {
          key: "E"
        },
        action: () => {
          se.getState().selectedIds.size > 0 && me.getState().requestInspectorFocus(), n();
        },
        searchableText: "Edit selection inspector properties focus"
      },
      {
        id: "edit-select-all",
        type: "command",
        name: "Edit: Select All",
        shortcut: {
          modifiers: [
            He.mod
          ],
          key: "A"
        },
        action: () => {
          const { library: i } = Se.getState();
          if (!i) {
            n();
            return;
          }
          const c = i.get_all_ids();
          se.getState().selectAll(c), n();
        },
        searchableText: "Select all elements"
      },
      {
        id: "edit-text-to-polygons",
        type: "command",
        name: "Edit: Convert Text to Polygons",
        action: () => {
          const { selectedIds: i } = se.getState(), { library: c, renderer: d } = Se.getState();
          if (!c || !d || i.size === 0) {
            n();
            return;
          }
          const f = [
            ...i
          ].filter((p) => c.is_text_element(p));
          if (f.length === 0) {
            n();
            return;
          }
          const g = new H0(f);
          ce.getState().execute(g, {
            library: c,
            renderer: d
          }), n();
        },
        searchableText: "Convert text to polygons outline vectorize font"
      },
      {
        id: "layer-add",
        type: "layer",
        name: "Layer: Add",
        action: () => {
          const { library: i, renderer: c } = Se.getState();
          if (!i || !c) {
            n();
            return;
          }
          const d = new L0();
          ce.getState().execute(d, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Add new layer create"
      },
      {
        id: "layer-delete",
        type: "layer",
        name: "Layer: Delete Active",
        action: () => {
          const { library: i, renderer: c } = Se.getState(), { activeLayerId: d, layers: f } = ve.getState();
          if (!i || !c || f.size <= 1) {
            n();
            return;
          }
          const g = new ih(d);
          ce.getState().execute(g, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Delete active layer remove"
      },
      {
        id: "layer-edit",
        type: "layer",
        name: "Layer: Edit Active",
        action: () => {
          const { activeLayerId: i } = ve.getState();
          ve.getState().setExpandedLayerId(i), me.getState().setSidebarTab("layers"), n();
        },
        searchableText: "Edit active layer color fill pattern properties"
      },
      {
        id: "layer-rename",
        type: "layer",
        name: "Layer: Rename Active",
        action: () => {
          const { activeLayerId: i } = ve.getState();
          ve.getState().setEditingLayerId(i), n();
        },
        searchableText: "Rename active layer"
      },
      {
        id: "layer-toggle-visibility",
        type: "layer",
        name: "Layer: Toggle Active Visibility",
        action: () => {
          const { activeLayerId: i } = ve.getState();
          ve.getState().toggleVisibility(i), n();
        },
        searchableText: "Toggle active layer visibility show hide"
      },
      {
        id: "layer-show-all",
        type: "layer",
        name: "Layer: Show All",
        action: () => {
          ve.getState().showAllLayers(), n();
        },
        searchableText: "Show all layers visible"
      },
      {
        id: "layer-hide-all",
        type: "layer",
        name: "Layer: Hide All",
        action: () => {
          ve.getState().hideAllLayers(), n();
        },
        searchableText: "Hide all layers invisible"
      },
      ...ve.getState().getAllLayers().map((i) => ({
        id: `layer-activate-${i.id}`,
        type: "layer",
        name: `Layer: Set Active: ${i.name}`,
        color: i.color,
        action: () => {
          ve.getState().setActiveLayer(i.id), n();
        },
        searchableText: `Layer set active ${i.name} switch`
      })),
      {
        id: "cell-add",
        type: "cell",
        name: "Cell: Add",
        shortcut: {
          key: "C"
        },
        action: () => {
          const { library: i, renderer: c } = Se.getState();
          if (!i || !c) {
            n();
            return;
          }
          const d = ah(), f = new ch(d);
          ce.getState().execute(f, {
            library: i,
            renderer: c
          }), me.getState().explorerCollapsed && me.getState().toggleExplorerCollapsed(), ue.getState().setActiveCell(d), ue.getState().setEditingCellName(d), n();
        },
        searchableText: "Add new cell create"
      },
      {
        id: "cell-delete",
        type: "cell",
        name: "Cell: Delete Active",
        action: () => {
          const { library: i, renderer: c } = Se.getState(), { activeCell: d, cells: f } = ue.getState();
          if (!i || !c || !d || f.length <= 1) {
            n();
            return;
          }
          const g = new uh(d);
          ce.getState().execute(g, {
            library: i,
            renderer: c
          }), n();
        },
        searchableText: "Delete active cell remove"
      },
      {
        id: "cell-rename",
        type: "cell",
        name: "Cell: Rename Active",
        action: () => {
          const { activeCell: i } = ue.getState();
          i && ue.getState().setEditingCellName(i), n();
        },
        searchableText: "Rename active cell"
      },
      {
        id: "cell-change-origin",
        type: "cell",
        name: "Cell: Change Origin",
        action: () => {
          se.getState().clearSelection(), me.getState().requestInspectorFocusField("X"), n();
        },
        searchableText: "Cell change origin position offset set move"
      },
      {
        id: "cell-toggle-visibility",
        type: "cell",
        name: "Cell: Toggle Active Visibility",
        action: () => {
          const { activeCell: i } = ue.getState();
          i && ue.getState().toggleCellVisibility(i), n();
        },
        searchableText: "Toggle cell visibility hide show active"
      },
      {
        id: "cell-show-all",
        type: "cell",
        name: "Cell: Show All",
        action: () => {
          ue.getState().showAllCells(), n();
        },
        searchableText: "Show all cells visible unhide"
      },
      {
        id: "cell-hide-all",
        type: "cell",
        name: "Cell: Hide All",
        action: () => {
          ue.getState().hideAllCells(), n();
        },
        searchableText: "Hide all cells invisible"
      },
      {
        id: "cell-toggle-flat-list",
        type: "cell",
        name: "Cell: Toggle Flat List",
        action: () => {
          const { cellListMode: i, setCellListMode: c } = ue.getState();
          c(i === "flat" ? "nested" : "flat"), n();
        },
        searchableText: "Toggle flat list nested tree hierarchy cell explorer view"
      },
      ...ue.getState().cells.map((i) => ({
        id: `cell-activate-${i}`,
        type: "cell",
        name: `Cell: Set Active: ${i}`,
        action: () => {
          ue.getState().setActiveCell(i), n();
        },
        searchableText: `Cell set active ${i} switch`
      })),
      ...ue.getState().cells.filter((i) => i !== ue.getState().activeCell).map((i) => ({
        id: `cell-instance-${i}`,
        type: "cell",
        name: `Cell: Add Instance: ${i}`,
        action: () => {
          const { library: c, renderer: d } = Se.getState(), f = ue.getState().activeCell;
          if (!c || !d || !f) {
            n();
            return;
          }
          if (!c.can_instance_cell(f, i)) {
            n();
            return;
          }
          const { zoom: g, offset: p } = Ve.getState(), v = window.innerWidth / 2, b = window.innerHeight / 2, S = (v - p.x) / g, C = (b - p.y) / g, k = new T0(i, S, C);
          ce.getState().execute(k, {
            library: c,
            renderer: d
          }), n();
        },
        searchableText: `Cell add instance ${i} place ref reference`
      })),
      {
        id: "hierarchy-set-max-level",
        type: "command",
        name: "Hierarchy: Show All Levels",
        action: () => {
          const { setHierarchyLevelLimit: i } = ue.getState();
          i(1 / 0), n();
        },
        searchableText: "Hierarchy show all levels max depth expand full"
      },
      {
        id: "hierarchy-set-level",
        type: "command",
        name: "Hierarchy: Set Level",
        action: () => {
          n(), requestAnimationFrame(() => {
            const i = document.getElementById("hierarchy-level-input");
            i && (i.focus(), i.select());
          });
        },
        searchableText: "Hierarchy set level depth limit change"
      },
      ...$_(n),
      ...q_(n)
    ];
  }
  const X_ = [
    {
      id: "align-left",
      name: "Align Left",
      search: "Align left edges"
    },
    {
      id: "align-center-h",
      name: "Align Center Horizontally",
      search: "Align center horizontal middle"
    },
    {
      id: "align-right",
      name: "Align Right",
      search: "Align right edges"
    },
    {
      id: "align-top",
      name: "Align Top",
      search: "Align top edges"
    },
    {
      id: "align-center-v",
      name: "Align Center Vertically",
      search: "Align center vertical middle"
    },
    {
      id: "align-bottom",
      name: "Align Bottom",
      search: "Align bottom edges"
    },
    {
      id: "center-align",
      name: "Center Align",
      search: "Center align both axes"
    },
    {
      id: "origin-align",
      name: "Align to Origin",
      search: "Origin align center zero"
    }
  ], V_ = [
    {
      id: "union",
      name: "Union",
      search: "Boolean union merge combine"
    },
    {
      id: "subtract",
      name: "Subtract",
      search: "Boolean subtract difference cut"
    },
    {
      id: "intersect",
      name: "Intersect",
      search: "Boolean intersect overlap common"
    },
    {
      id: "xor",
      name: "Exclude (XOR)",
      search: "Boolean exclude xor symmetric difference"
    }
  ];
  function $_(l) {
    return V_.map((n) => ({
      id: `boolean-${n.id}`,
      type: "command",
      name: `Boolean: ${n.name}`,
      action: () => {
        const { library: r, renderer: o } = Se.getState();
        if (!r || !o) {
          l();
          return;
        }
        const { selectedIds: i, lastSelectedId: c } = se.getState();
        if (i.size < 2) {
          l();
          return;
        }
        const d = [
          ...i
        ], f = c ?? d[0], g = new Y0(d, n.id, f);
        ce.getState().execute(g, {
          library: r,
          renderer: o
        }), l();
      },
      searchableText: n.search
    }));
  }
  function q_(l) {
    return X_.map((n) => ({
      id: `align-${n.id}`,
      type: "command",
      name: `Align: ${n.name}`,
      action: () => {
        const { library: r, renderer: o } = Se.getState();
        if (!r || !o) {
          l();
          return;
        }
        const { selectedIds: i, lastSelectedId: c } = se.getState();
        if (i.size === 0) {
          l();
          return;
        }
        if (n.id !== "origin-align" && i.size < 2) {
          l();
          return;
        }
        const d = new U0(new Set(i), c, n.id);
        ce.getState().execute(d, {
          library: r,
          renderer: o
        }), l();
      },
      searchableText: n.search
    }));
  }
  function G_({ shortcut: l }) {
    var _a;
    const r = me((i) => i.theme) === "dark", o = Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[11px]", r ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10");
    return y.jsxs("span", {
      className: "flex items-center gap-0.5",
      children: [
        (_a = l.modifiers) == null ? void 0 : _a.map((i, c) => y.jsx("kbd", {
          className: o,
          children: i
        }, c)),
        y.jsx("kbd", {
          className: o,
          children: l.key
        }),
        l.then && y.jsxs(y.Fragment, {
          children: [
            y.jsx("span", {
              className: Y("px-1 text-[11px]", r ? "text-white/50" : "text-gray-500"),
              children: "then"
            }),
            y.jsx("kbd", {
              className: o,
              children: l.then
            })
          ]
        })
      ]
    });
  }
  function P_({ item: l }) {
    const r = me((o) => o.theme) === "dark";
    return y.jsxs(Po.Item, {
      value: l.searchableText,
      onSelect: l.action,
      className: Y("flex cursor-pointer items-center justify-between rounded-lg px-3 py-2", r ? "text-white/80 aria-selected:bg-[rgb(54,54,54)] aria-selected:text-white" : "text-gray-700 aria-selected:bg-[rgb(217,217,217)] aria-selected:text-gray-900"),
      children: [
        y.jsx("span", {
          className: "text-sm",
          children: l.name
        }),
        l.color && y.jsx("span", {
          className: Y("inline-block h-3.5 w-3.5 shrink-0 rounded border", r ? "border-white/15" : "border-black/15"),
          style: {
            backgroundColor: l.color
          }
        }),
        l.shortcut && y.jsx(G_, {
          shortcut: l.shortcut
        })
      ]
    });
  }
  function _b() {
    const n = me((b) => b.theme) === "dark", r = cn((b) => b.isOpen), o = cn((b) => b.close);
    Pa("command-palette", r);
    const [i, c] = m.useState(""), d = m.useRef(null), f = m.useMemo(() => B_(), [
      r
    ]), g = m.useMemo(() => {
      const b = i.toLowerCase();
      return f.filter((S) => S.searchableText.toLowerCase().includes(b));
    }, [
      f,
      i
    ]), p = m.useMemo(() => [
      ...g
    ].sort((b, S) => b.name.localeCompare(S.name)), [
      g
    ]), v = m.useCallback((b) => {
      const S = b.target;
      S instanceof Node && d.current && !d.current.contains(S) && o();
    }, [
      o
    ]);
    return m.useEffect(() => {
      if (!r) {
        c("");
        return;
      }
      return c(cn.getState().initialSearch), document.addEventListener("mousedown", v), () => {
        document.removeEventListener("mousedown", v);
      };
    }, [
      r,
      v
    ]), r ? y.jsx("div", {
      className: "fixed inset-0 z-[200]",
      children: y.jsx(Po, {
        className: "fixed inset-0 flex items-start justify-center px-4 pt-[min(15vh,120px)]",
        shouldFilter: false,
        loop: true,
        label: "Command Menu",
        onKeyDown: (b) => {
          b.key === "Escape" && (b.preventDefault(), o());
        },
        children: y.jsxs("div", {
          ref: d,
          className: Y("w-full max-w-[560px] overflow-hidden rounded-xl border shadow-md backdrop-blur-xl", n ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
          children: [
            y.jsx(Po.Input, {
              value: i,
              onValueChange: c,
              placeholder: "Type a command or search...",
              className: Y("w-full border-b bg-transparent px-4 py-3 text-sm outline-none", n ? "border-white/10 text-white/90 placeholder:text-white/50" : "border-black/10 text-gray-900 placeholder:text-gray-500"),
              autoFocus: true
            }),
            y.jsxs(Po.List, {
              className: "max-h-[320px] overflow-y-auto p-1",
              onWheel: (b) => b.stopPropagation(),
              children: [
                y.jsx(Po.Empty, {
                  className: Y("px-3 py-2 text-sm", n ? "text-white/50" : "text-gray-500"),
                  children: "No matching commands"
                }),
                p.map((b) => y.jsx(P_, {
                  item: b
                }, b.id))
              ]
            })
          ]
        })
      })
    }) : null;
  }
  const st = Xa.createContext({});
  var K_ = Object.defineProperty, kb = Object.getOwnPropertySymbols, Z_ = Object.prototype.hasOwnProperty, F_ = Object.prototype.propertyIsEnumerable, Mb = (l, n, r) => n in l ? K_(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, tf = (l, n) => {
    for (var r in n || (n = {})) Z_.call(n, r) && Mb(l, r, n[r]);
    if (kb) for (var r of kb(n)) F_.call(n, r) && Mb(l, r, n[r]);
    return l;
  };
  const Q_ = (l, n) => {
    const r = m.useContext(st), o = tf(tf({}, r), l);
    return m.createElement("svg", tf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M12 22L12 2",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19 16H5C3.89543 16 3 15.1046 3 14L3 10C3 8.89543 3.89543 8 5 8H19C20.1046 8 21 8.89543 21 10V14C21 15.1046 20.1046 16 19 16Z",
      stroke: "currentColor"
    }));
  }, W_ = m.forwardRef(Q_);
  var J_ = W_, e4 = Object.defineProperty, jb = Object.getOwnPropertySymbols, t4 = Object.prototype.hasOwnProperty, n4 = Object.prototype.propertyIsEnumerable, Lb = (l, n, r) => n in l ? e4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, nf = (l, n) => {
    for (var r in n || (n = {})) t4.call(n, r) && Lb(l, r, n[r]);
    if (jb) for (var r of jb(n)) n4.call(n, r) && Lb(l, r, n[r]);
    return l;
  };
  const l4 = (l, n) => {
    const r = m.useContext(st), o = nf(nf({}, r), l);
    return m.createElement("svg", nf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M22 12L2 12",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 19V5C8 3.89543 8.89543 3 10 3H14C15.1046 3 16 3.89543 16 5V19C16 20.1046 15.1046 21 14 21H10C8.89543 21 8 20.1046 8 19Z",
      stroke: "currentColor"
    }));
  }, r4 = m.forwardRef(l4);
  var a4 = r4, o4 = Object.defineProperty, Rb = Object.getOwnPropertySymbols, s4 = Object.prototype.hasOwnProperty, i4 = Object.prototype.propertyIsEnumerable, Ab = (l, n, r) => n in l ? o4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, lf = (l, n) => {
    for (var r in n || (n = {})) s4.call(n, r) && Ab(l, r, n[r]);
    if (Rb) for (var r of Rb(n)) i4.call(n, r) && Ab(l, r, n[r]);
    return l;
  };
  const c4 = (l, n) => {
    const r = m.useContext(st), o = lf(lf({}, r), l);
    return m.createElement("svg", lf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M3 21L3 3L9 3V15L21 15V21H3Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M13 19V21",
      stroke: "currentColor",
      strokeLinecap: "round"
    }), m.createElement("path", {
      d: "M9 19V21",
      stroke: "currentColor",
      strokeLinecap: "round"
    }), m.createElement("path", {
      d: "M3 7H5",
      stroke: "currentColor",
      strokeLinecap: "round"
    }), m.createElement("path", {
      d: "M3 11H5",
      stroke: "currentColor",
      strokeLinecap: "round"
    }), m.createElement("path", {
      d: "M3 15H5",
      stroke: "currentColor",
      strokeLinecap: "round"
    }), m.createElement("path", {
      d: "M17 19V21",
      stroke: "currentColor",
      strokeLinecap: "round"
    }));
  }, u4 = m.forwardRef(c4);
  var d4 = u4, f4 = Object.defineProperty, Tb = Object.getOwnPropertySymbols, h4 = Object.prototype.hasOwnProperty, m4 = Object.prototype.propertyIsEnumerable, Nb = (l, n, r) => n in l ? f4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, rf = (l, n) => {
    for (var r in n || (n = {})) h4.call(n, r) && Nb(l, r, n[r]);
    if (Tb) for (var r of Tb(n)) m4.call(n, r) && Nb(l, r, n[r]);
    return l;
  };
  const g4 = (l, n) => {
    const r = m.useContext(st), o = rf(rf({}, r), l);
    return m.createElement("svg", rf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M4 16.01L4.01 15.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 20.01L4.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 8.01L4.01 7.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 4.01L4.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 12.01L4.01 11.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 20.01L8.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 20.01L12.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16 20.01L16.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 20.01L20.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 16.01L20.01 15.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 12.01L20.01 11.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 8.01L20.01 7.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 4.01L20.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16 4.01L16.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 4.01L12.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 4.01L8.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 16V8H16V16H8Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, p4 = m.forwardRef(g4);
  var y4 = p4, b4 = Object.defineProperty, Ob = Object.getOwnPropertySymbols, v4 = Object.prototype.hasOwnProperty, x4 = Object.prototype.propertyIsEnumerable, Ib = (l, n, r) => n in l ? b4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, af = (l, n) => {
    for (var r in n || (n = {})) v4.call(n, r) && Ib(l, r, n[r]);
    if (Ob) for (var r of Ob(n)) x4.call(n, r) && Ib(l, r, n[r]);
    return l;
  };
  const w4 = (l, n) => {
    const r = m.useContext(st), o = af(af({}, r), l);
    return m.createElement("svg", af({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M22 21L2 21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 15V5C8 3.89543 8.89543 3 10 3H14C15.1046 3 16 3.89543 16 5V15C16 16.1046 15.1046 17 14 17H10C8.89543 17 8 16.1046 8 15Z",
      stroke: "currentColor"
    }));
  }, S4 = m.forwardRef(w4);
  var C4 = S4, E4 = Object.defineProperty, Db = Object.getOwnPropertySymbols, _4 = Object.prototype.hasOwnProperty, k4 = Object.prototype.propertyIsEnumerable, zb = (l, n, r) => n in l ? E4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, of = (l, n) => {
    for (var r in n || (n = {})) _4.call(n, r) && zb(l, r, n[r]);
    if (Db) for (var r of Db(n)) k4.call(n, r) && zb(l, r, n[r]);
    return l;
  };
  const M4 = (l, n) => {
    const r = m.useContext(st), o = of(of({}, r), l);
    return m.createElement("svg", of({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M3 22L3 2",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19 16H9C7.89543 16 7 15.1046 7 14V10C7 8.89543 7.89543 8 9 8H19C20.1046 8 21 8.89543 21 10V14C21 15.1046 20.1046 16 19 16Z",
      stroke: "currentColor"
    }));
  }, j4 = m.forwardRef(M4);
  var L4 = j4, R4 = Object.defineProperty, Hb = Object.getOwnPropertySymbols, A4 = Object.prototype.hasOwnProperty, T4 = Object.prototype.propertyIsEnumerable, Ub = (l, n, r) => n in l ? R4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, sf = (l, n) => {
    for (var r in n || (n = {})) A4.call(n, r) && Ub(l, r, n[r]);
    if (Hb) for (var r of Hb(n)) T4.call(n, r) && Ub(l, r, n[r]);
    return l;
  };
  const N4 = (l, n) => {
    const r = m.useContext(st), o = sf(sf({}, r), l);
    return m.createElement("svg", sf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M21 22V2",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M15 16H5C3.89543 16 3 15.1046 3 14L3 10C3 8.89543 3.89543 8 5 8H15C16.1046 8 17 8.89543 17 10V14C17 15.1046 16.1046 16 15 16Z",
      stroke: "currentColor"
    }));
  }, O4 = m.forwardRef(N4);
  var I4 = O4, D4 = Object.defineProperty, Yb = Object.getOwnPropertySymbols, z4 = Object.prototype.hasOwnProperty, H4 = Object.prototype.propertyIsEnumerable, Bb = (l, n, r) => n in l ? D4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, cf = (l, n) => {
    for (var r in n || (n = {})) z4.call(n, r) && Bb(l, r, n[r]);
    if (Yb) for (var r of Yb(n)) H4.call(n, r) && Bb(l, r, n[r]);
    return l;
  };
  const U4 = (l, n) => {
    const r = m.useContext(st), o = cf(cf({}, r), l);
    return m.createElement("svg", cf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M22 3L2 3",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 19V9C8 7.89543 8.89543 7 10 7H14C15.1046 7 16 7.89543 16 9V19C16 20.1046 15.1046 21 14 21H10C8.89543 21 8 20.1046 8 19Z",
      stroke: "currentColor"
    }));
  }, Y4 = m.forwardRef(U4);
  var B4 = Y4, X4 = Object.defineProperty, Xb = Object.getOwnPropertySymbols, V4 = Object.prototype.hasOwnProperty, $4 = Object.prototype.propertyIsEnumerable, Vb = (l, n, r) => n in l ? X4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, uf = (l, n) => {
    for (var r in n || (n = {})) V4.call(n, r) && Vb(l, r, n[r]);
    if (Xb) for (var r of Xb(n)) $4.call(n, r) && Vb(l, r, n[r]);
    return l;
  };
  const q4 = (l, n) => {
    const r = m.useContext(st), o = uf(uf({}, r), l);
    return m.createElement("svg", uf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M5.21173 15.1113L2.52473 12.4243C2.29041 12.1899 2.29041 11.8101 2.52473 11.5757L5.21173 8.88873C5.44605 8.65442 5.82595 8.65442 6.06026 8.88873L8.74727 11.5757C8.98158 11.8101 8.98158 12.1899 8.74727 12.4243L6.06026 15.1113C5.82595 15.3456 5.44605 15.3456 5.21173 15.1113Z",
      stroke: "currentColor"
    }), m.createElement("path", {
      d: "M11.5757 21.475L8.88874 18.788C8.65443 18.5537 8.65443 18.1738 8.88874 17.9395L11.5757 15.2525C11.8101 15.0182 12.19 15.0182 12.4243 15.2525L15.1113 17.9395C15.3456 18.1738 15.3456 18.5537 15.1113 18.788L12.4243 21.475C12.19 21.7094 11.8101 21.7094 11.5757 21.475Z",
      stroke: "currentColor"
    }), m.createElement("path", {
      d: "M11.5757 8.7475L8.88874 6.06049C8.65443 5.82618 8.65443 5.44628 8.88874 5.21197L11.5757 2.52496C11.8101 2.29065 12.19 2.29065 12.4243 2.52496L15.1113 5.21197C15.3456 5.44628 15.3456 5.82618 15.1113 6.06049L12.4243 8.7475C12.19 8.98181 11.8101 8.98181 11.5757 8.7475Z",
      stroke: "currentColor"
    }), m.createElement("path", {
      d: "M17.9396 15.1113L15.2526 12.4243C15.0183 12.1899 15.0183 11.8101 15.2526 11.5757L17.9396 8.88873C18.174 8.65442 18.5539 8.65442 18.7882 8.88873L21.4752 11.5757C21.7095 11.8101 21.7095 12.1899 21.4752 12.4243L18.7882 15.1113C18.5539 15.3456 18.174 15.3456 17.9396 15.1113Z",
      stroke: "currentColor"
    }));
  }, G4 = m.forwardRef(q4);
  var P4 = G4, K4 = Object.defineProperty, $b = Object.getOwnPropertySymbols, Z4 = Object.prototype.hasOwnProperty, F4 = Object.prototype.propertyIsEnumerable, qb = (l, n, r) => n in l ? K4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, df = (l, n) => {
    for (var r in n || (n = {})) Z4.call(n, r) && qb(l, r, n[r]);
    if ($b) for (var r of $b(n)) F4.call(n, r) && qb(l, r, n[r]);
    return l;
  };
  const Q4 = (l, n) => {
    const r = m.useContext(st), o = df(df({}, r), l);
    return m.createElement("svg", df({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M12 12L4 4M4 4V8M4 4H8",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 12L20 4M20 4V8M20 4H16",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 12L4 20M4 20V16M4 20H8",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 12L20 20M20 20V16M20 20H16",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, W4 = m.forwardRef(Q4);
  var bh = W4, J4 = Object.defineProperty, Gb = Object.getOwnPropertySymbols, ek = Object.prototype.hasOwnProperty, tk = Object.prototype.propertyIsEnumerable, Pb = (l, n, r) => n in l ? J4(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, ff = (l, n) => {
    for (var r in n || (n = {})) ek.call(n, r) && Pb(l, r, n[r]);
    if (Gb) for (var r of Gb(n)) tk.call(n, r) && Pb(l, r, n[r]);
    return l;
  };
  const nk = (l, n) => {
    const r = m.useContext(st), o = ff(ff({}, r), l);
    return m.createElement("svg", ff({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M3 20C11 20 21 4 21 4",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, lk = m.forwardRef(nk);
  var N1 = lk, rk = Object.defineProperty, Kb = Object.getOwnPropertySymbols, ak = Object.prototype.hasOwnProperty, ok = Object.prototype.propertyIsEnumerable, Zb = (l, n, r) => n in l ? rk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, hf = (l, n) => {
    for (var r in n || (n = {})) ak.call(n, r) && Zb(l, r, n[r]);
    if (Kb) for (var r of Kb(n)) ok.call(n, r) && Zb(l, r, n[r]);
    return l;
  };
  const sk = (l, n) => {
    const r = m.useContext(st), o = hf(hf({}, r), l);
    return m.createElement("svg", hf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M10.5 15H9.6C9.26863 15 9 15.2686 9 15.6V20.4C9 20.7314 9.26863 21 9.6 21H20.4C20.7314 21 21 20.7314 21 20.4V9.6C21 9.26863 20.7314 9 20.4 9H15.6C15.2686 9 15 9.26863 15 9.6V10.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M13.5 15H14.4C14.7314 15 15 14.7314 15 14.4V13.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M9 13.5V14.4C9 14.7314 8.73137 15 8.4 15H3.6C3.26863 15 3 14.7314 3 14.4V3.6C3 3.26863 3.26863 3 3.6 3H14.4C14.7314 3 15 3.26863 15 3.6V8.4C15 8.73137 14.7314 9 14.4 9H13.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M9 10.5V9.6C9 9.26863 9.26863 9 9.6 9H10.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, ik = m.forwardRef(sk);
  var ck = ik, uk = Object.defineProperty, Fb = Object.getOwnPropertySymbols, dk = Object.prototype.hasOwnProperty, fk = Object.prototype.propertyIsEnumerable, Qb = (l, n, r) => n in l ? uk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, mf = (l, n) => {
    for (var r in n || (n = {})) dk.call(n, r) && Qb(l, r, n[r]);
    if (Fb) for (var r of Fb(n)) fk.call(n, r) && Qb(l, r, n[r]);
    return l;
  };
  const hk = (l, n) => {
    const r = m.useContext(st), o = mf(mf({}, r), l);
    return m.createElement("svg", mf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M21 13.5V16.5M13.5 21H16.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16.5 9H9.6C9.26863 9 9 9.26863 9 9.6V16.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M10.5 21H9.6C9.26863 21 9 20.7314 9 20.4V19.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M21 19.5V20.4C21 20.7314 20.7314 21 20.4 21H19.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19.5 9H20.4C20.7314 9 21 9.26863 21 9.6V10.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M3 10.5V7.5M7.5 3H10.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M7.5 15H14.4C14.7314 15 15 14.7314 15 14.4V7.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4.5 15H3.6C3.26863 15 3 14.7314 3 14.4V13.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M3 4.5V3.6C3 3.26863 3.26863 3 3.6 3H4.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M13.5 3H14.4C14.7314 3 15 3.26863 15 3.6V4.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, mk = m.forwardRef(hk);
  var gk = mk, pk = Object.defineProperty, Wb = Object.getOwnPropertySymbols, yk = Object.prototype.hasOwnProperty, bk = Object.prototype.propertyIsEnumerable, Jb = (l, n, r) => n in l ? pk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, gf = (l, n) => {
    for (var r in n || (n = {})) yk.call(n, r) && Jb(l, r, n[r]);
    if (Wb) for (var r of Wb(n)) bk.call(n, r) && Jb(l, r, n[r]);
    return l;
  };
  const vk = (l, n) => {
    const r = m.useContext(st), o = gf(gf({}, r), l);
    return m.createElement("svg", gf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M3 5H21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M3 12H21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M3 19H21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, xk = m.forwardRef(vk);
  var wk = xk, Sk = Object.defineProperty, ev = Object.getOwnPropertySymbols, Ck = Object.prototype.hasOwnProperty, Ek = Object.prototype.propertyIsEnumerable, tv = (l, n, r) => n in l ? Sk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, pf = (l, n) => {
    for (var r in n || (n = {})) Ck.call(n, r) && tv(l, r, n[r]);
    if (ev) for (var r of ev(n)) Ek.call(n, r) && tv(l, r, n[r]);
    return l;
  };
  const _k = (l, n) => {
    const r = m.useContext(st), o = pf(pf({}, r), l);
    return m.createElement("svg", pf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M20 12.5C20.2761 12.5 20.5 12.2761 20.5 12C20.5 11.7239 20.2761 11.5 20 11.5C19.7239 11.5 19.5 11.7239 19.5 12C19.5 12.2761 19.7239 12.5 20 12.5Z",
      fill: "currentColor",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 12.5C12.2761 12.5 12.5 12.2761 12.5 12C12.5 11.7239 12.2761 11.5 12 11.5C11.7239 11.5 11.5 11.7239 11.5 12C11.5 12.2761 11.7239 12.5 12 12.5Z",
      fill: "currentColor",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 12.5C4.27614 12.5 4.5 12.2761 4.5 12C4.5 11.7239 4.27614 11.5 4 11.5C3.72386 11.5 3.5 11.7239 3.5 12C3.5 12.2761 3.72386 12.5 4 12.5Z",
      fill: "currentColor",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, kk = m.forwardRef(_k);
  var Mk = kk, jk = Object.defineProperty, nv = Object.getOwnPropertySymbols, Lk = Object.prototype.hasOwnProperty, Rk = Object.prototype.propertyIsEnumerable, lv = (l, n, r) => n in l ? jk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, yf = (l, n) => {
    for (var r in n || (n = {})) Lk.call(n, r) && lv(l, r, n[r]);
    if (nv) for (var r of nv(n)) Rk.call(n, r) && lv(l, r, n[r]);
    return l;
  };
  const Ak = (l, n) => {
    const r = m.useContext(st), o = yf(yf({}, r), l);
    return m.createElement("svg", yf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M15 6L9 12L15 18",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, Tk = m.forwardRef(Ak);
  var Nk = Tk, Ok = Object.defineProperty, rv = Object.getOwnPropertySymbols, Ik = Object.prototype.hasOwnProperty, Dk = Object.prototype.propertyIsEnumerable, av = (l, n, r) => n in l ? Ok(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, bf = (l, n) => {
    for (var r in n || (n = {})) Ik.call(n, r) && av(l, r, n[r]);
    if (rv) for (var r of rv(n)) Dk.call(n, r) && av(l, r, n[r]);
    return l;
  };
  const zk = (l, n) => {
    const r = m.useContext(st), o = bf(bf({}, r), l);
    return m.createElement("svg", bf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M9 6L15 12L9 18",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, Hk = m.forwardRef(zk);
  var O1 = Hk, Uk = Object.defineProperty, ov = Object.getOwnPropertySymbols, Yk = Object.prototype.hasOwnProperty, Bk = Object.prototype.propertyIsEnumerable, sv = (l, n, r) => n in l ? Uk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, vf = (l, n) => {
    for (var r in n || (n = {})) Yk.call(n, r) && sv(l, r, n[r]);
    if (ov) for (var r of ov(n)) Bk.call(n, r) && sv(l, r, n[r]);
    return l;
  };
  const Xk = (l, n) => {
    const r = m.useContext(st), o = vf(vf({}, r), l);
    return m.createElement("svg", vf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M18 16.5V3M18 3L21.5 6.5M18 3L14.5 6.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M18 16.5C18 18.433 16.433 20 14.5 20C12.567 20 11 18.433 11 16.5V7.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M11 7.5C11 5.567 9.433 4 7.5 4C5.567 4 4 5.567 4 7.5V19.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, Vk = m.forwardRef(Xk);
  var $k = Vk, qk = Object.defineProperty, iv = Object.getOwnPropertySymbols, Gk = Object.prototype.hasOwnProperty, Pk = Object.prototype.propertyIsEnumerable, cv = (l, n, r) => n in l ? qk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, xf = (l, n) => {
    for (var r in n || (n = {})) Gk.call(n, r) && cv(l, r, n[r]);
    if (iv) for (var r of iv(n)) Pk.call(n, r) && cv(l, r, n[r]);
    return l;
  };
  const Kk = (l, n) => {
    const r = m.useContext(st), o = xf(xf({}, r), l);
    return m.createElement("svg", xf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M11.6473 2.25623C11.8576 2.10344 12.1424 2.10344 12.3527 2.25623L22.1089 9.34458C22.3192 9.49737 22.4072 9.76819 22.3269 10.0154L18.6003 21.4846C18.52 21.7318 18.2896 21.8992 18.0297 21.8992H5.97029C5.71035 21.8992 5.47998 21.7318 5.39965 21.4846L1.67309 10.0154C1.59276 9.76819 1.68076 9.49737 1.89105 9.34458L11.6473 2.25623Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, Zk = m.forwardRef(Kk);
  var Fk = Zk, Qk = Object.defineProperty, uv = Object.getOwnPropertySymbols, Wk = Object.prototype.hasOwnProperty, Jk = Object.prototype.propertyIsEnumerable, dv = (l, n, r) => n in l ? Qk(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, wf = (l, n) => {
    for (var r in n || (n = {})) Wk.call(n, r) && dv(l, r, n[r]);
    if (uv) for (var r of uv(n)) Jk.call(n, r) && dv(l, r, n[r]);
    return l;
  };
  const eM = (l, n) => {
    const r = m.useContext(st), o = wf(wf({}, r), l);
    return m.createElement("svg", wf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M9 12H12M15 12H12M12 12V9M12 12V15",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M21 3.6V20.4C21 20.7314 20.7314 21 20.4 21H3.6C3.26863 21 3 20.7314 3 20.4V3.6C3 3.26863 3.26863 3 3.6 3H20.4C20.7314 3 21 3.26863 21 3.6Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, tM = m.forwardRef(eM);
  var I1 = tM, nM = Object.defineProperty, fv = Object.getOwnPropertySymbols, lM = Object.prototype.hasOwnProperty, rM = Object.prototype.propertyIsEnumerable, hv = (l, n, r) => n in l ? nM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Sf = (l, n) => {
    for (var r in n || (n = {})) lM.call(n, r) && hv(l, r, n[r]);
    if (fv) for (var r of fv(n)) rM.call(n, r) && hv(l, r, n[r]);
    return l;
  };
  const aM = (l, n) => {
    const r = m.useContext(st), o = Sf(Sf({}, r), l);
    return m.createElement("svg", Sf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M4 16.01L4.01 15.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 20.01L4.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 8.01L4.01 7.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 4.01L4.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4 12.01L4.01 11.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 12.01L12.01 11.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 20.01L8.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 20.01L12.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16 20.01L16.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 20.01L20.01 19.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 16.01L20.01 15.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 12.01L20.01 11.9989",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 8.01L20.01 7.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M20 4.01L20.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16 4.01L16.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 4.01L12.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M8 4.01L8.01 3.99889",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, oM = m.forwardRef(aM);
  var sM = oM, iM = Object.defineProperty, mv = Object.getOwnPropertySymbols, cM = Object.prototype.hasOwnProperty, uM = Object.prototype.propertyIsEnumerable, gv = (l, n, r) => n in l ? iM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Cf = (l, n) => {
    for (var r in n || (n = {})) cM.call(n, r) && gv(l, r, n[r]);
    if (mv) for (var r of mv(n)) uM.call(n, r) && gv(l, r, n[r]);
    return l;
  };
  const dM = (l, n) => {
    const r = m.useContext(st), o = Cf(Cf({}, r), l);
    return m.createElement("svg", Cf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M12 19C15.866 19 19 15.866 19 12C19 8.13401 15.866 5 12 5C8.13401 5 5 8.13401 5 12C5 15.866 8.13401 19 12 19Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 19V21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M5 12H3",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 5V3",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19 12H21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, fM = m.forwardRef(dM);
  var hM = fM, mM = Object.defineProperty, pv = Object.getOwnPropertySymbols, gM = Object.prototype.hasOwnProperty, pM = Object.prototype.propertyIsEnumerable, yv = (l, n, r) => n in l ? mM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Ef = (l, n) => {
    for (var r in n || (n = {})) gM.call(n, r) && yv(l, r, n[r]);
    if (pv) for (var r of pv(n)) pM.call(n, r) && yv(l, r, n[r]);
    return l;
  };
  const yM = (l, n) => {
    const r = m.useContext(st), o = Ef(Ef({}, r), l);
    return m.createElement("svg", Ef({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M16 7V2.6C16 2.26863 15.7314 2 15.4 2H8.6C8.26863 2 8 2.26863 8 2.6V21.4C8 21.7314 8.26863 22 8.6 22H15.4C15.7314 22 16 21.7314 16 21.4V17M16 7H13M16 7V12M16 12H13M16 12V17M16 17H13",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, bM = m.forwardRef(yM);
  var D1 = bM, vM = Object.defineProperty, bv = Object.getOwnPropertySymbols, xM = Object.prototype.hasOwnProperty, wM = Object.prototype.propertyIsEnumerable, vv = (l, n, r) => n in l ? vM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, _f = (l, n) => {
    for (var r in n || (n = {})) xM.call(n, r) && vv(l, r, n[r]);
    if (bv) for (var r of bv(n)) wM.call(n, r) && vv(l, r, n[r]);
    return l;
  };
  const SM = (l, n) => {
    const r = m.useContext(st), o = _f(_f({}, r), l);
    return m.createElement("svg", _f({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M21 3.6V20.4C21 20.7314 20.7314 21 20.4 21H3.6C3.26863 21 3 20.7314 3 20.4V3.6C3 3.26863 3.26863 3 3.6 3H20.4C20.7314 3 21 3.26863 21 3.6Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M10 16L14 8",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, CM = m.forwardRef(SM);
  var z1 = CM, EM = Object.defineProperty, xv = Object.getOwnPropertySymbols, _M = Object.prototype.hasOwnProperty, kM = Object.prototype.propertyIsEnumerable, wv = (l, n, r) => n in l ? EM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, kf = (l, n) => {
    for (var r in n || (n = {})) _M.call(n, r) && wv(l, r, n[r]);
    if (xv) for (var r of xv(n)) kM.call(n, r) && wv(l, r, n[r]);
    return l;
  };
  const MM = (l, n) => {
    const r = m.useContext(st), o = kf(kf({}, r), l);
    return m.createElement("svg", kf({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M3 20.4V3.6C3 3.26863 3.26863 3 3.6 3H20.4C20.7314 3 21 3.26863 21 3.6V20.4C21 20.7314 20.7314 21 20.4 21H3.6C3.26863 21 3 20.7314 3 20.4Z",
      stroke: "currentColor"
    }), m.createElement("path", {
      d: "M3 4C3.55228 4 4 3.55228 4 3C4 2.44772 3.55228 2 3 2C2.44772 2 2 2.44772 2 3C2 3.55228 2.44772 4 3 4Z",
      fill: "currentColor",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M21 22C21.5523 22 22 21.5523 22 21C22 20.4477 21.5523 20 21 20C20.4477 20 20 20.4477 20 21C20 21.5523 20.4477 22 21 22Z",
      fill: "currentColor",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, jM = m.forwardRef(MM);
  var LM = jM, RM = Object.defineProperty, Sv = Object.getOwnPropertySymbols, AM = Object.prototype.hasOwnProperty, TM = Object.prototype.propertyIsEnumerable, Cv = (l, n, r) => n in l ? RM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Mf = (l, n) => {
    for (var r in n || (n = {})) AM.call(n, r) && Cv(l, r, n[r]);
    if (Sv) for (var r of Sv(n)) TM.call(n, r) && Cv(l, r, n[r]);
    return l;
  };
  const NM = (l, n) => {
    const r = m.useContext(st), o = Mf(Mf({}, r), l);
    return m.createElement("svg", Mf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M15 3.6V14.4C15 14.7314 14.7314 15 14.4 15H3.6C3.26863 15 3 14.7314 3 14.4V3.6C3 3.26863 3.26863 3 3.6 3H14.4C14.7314 3 15 3.26863 15 3.6Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M13.5 21H16.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M21 13.5V16.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M21 19.5V20.4C21 20.7314 20.7314 21 20.4 21H19.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M10.5 21H9.6C9.26863 21 9 20.7314 9 20.4V19.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19.5 9H20.4C20.7314 9 21 9.26863 21 9.6V10.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16.5 9H9.6C9.26863 9 9 9.26863 9 9.6V16.5",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, OM = m.forwardRef(NM);
  var IM = OM, DM = Object.defineProperty, Ev = Object.getOwnPropertySymbols, zM = Object.prototype.hasOwnProperty, HM = Object.prototype.propertyIsEnumerable, _v = (l, n, r) => n in l ? DM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, jf = (l, n) => {
    for (var r in n || (n = {})) zM.call(n, r) && _v(l, r, n[r]);
    if (Ev) for (var r of Ev(n)) HM.call(n, r) && _v(l, r, n[r]);
    return l;
  };
  const UM = (l, n) => {
    const r = m.useContext(st), o = jf(jf({}, r), l);
    return m.createElement("svg", jf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M12 2V6",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 18V22",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M22 12H18",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M6 12H2",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M4.92896 4.92896L7.75738 7.75738",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M16.2427 16.2427L19.0711 19.0711",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M19.071 4.92896L16.2426 7.75738",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M7.75732 16.2427L4.9289 19.0711",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, YM = m.forwardRef(UM);
  var BM = YM, XM = Object.defineProperty, kv = Object.getOwnPropertySymbols, VM = Object.prototype.hasOwnProperty, $M = Object.prototype.propertyIsEnumerable, Mv = (l, n, r) => n in l ? XM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Lf = (l, n) => {
    for (var r in n || (n = {})) VM.call(n, r) && Mv(l, r, n[r]);
    if (kv) for (var r of kv(n)) $M.call(n, r) && Mv(l, r, n[r]);
    return l;
  };
  const qM = (l, n) => {
    const r = m.useContext(st), o = Lf(Lf({}, r), l);
    return m.createElement("svg", Lf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M19 7V5L5 5V7",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M12 5L12 19M12 19H10M12 19H14",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, GM = m.forwardRef(qM);
  var PM = GM, KM = Object.defineProperty, jv = Object.getOwnPropertySymbols, ZM = Object.prototype.hasOwnProperty, FM = Object.prototype.propertyIsEnumerable, Lv = (l, n, r) => n in l ? KM(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Rf = (l, n) => {
    for (var r in n || (n = {})) ZM.call(n, r) && Lv(l, r, n[r]);
    if (jv) for (var r of jv(n)) FM.call(n, r) && Lv(l, r, n[r]);
    return l;
  };
  const QM = (l, n) => {
    const r = m.useContext(st), o = Rf(Rf({}, r), l);
    return m.createElement("svg", Rf({
      width: "1.5em",
      height: "1.5em",
      strokeWidth: 1.5,
      viewBox: "0 0 24 24",
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M15 9H20.4C20.7314 9 21 9.26863 21 9.6V20.4C21 20.7314 20.7314 21 20.4 21H9.6C9.26863 21 9 20.7314 9 20.4V15",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M15 9V3.6C15 3.26863 14.7314 3 14.4 3H3.6C3.26863 3 3 3.26863 3 3.6V14.4C3 14.7314 3.26863 15 3.6 15H9",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, WM = m.forwardRef(QM);
  var JM = WM, e3 = Object.defineProperty, Rv = Object.getOwnPropertySymbols, t3 = Object.prototype.hasOwnProperty, n3 = Object.prototype.propertyIsEnumerable, Av = (l, n, r) => n in l ? e3(l, n, {
    enumerable: true,
    configurable: true,
    writable: true,
    value: r
  }) : l[n] = r, Af = (l, n) => {
    for (var r in n || (n = {})) t3.call(n, r) && Av(l, r, n[r]);
    if (Rv) for (var r of Rv(n)) n3.call(n, r) && Av(l, r, n[r]);
    return l;
  };
  const l3 = (l, n) => {
    const r = m.useContext(st), o = Af(Af({}, r), l);
    return m.createElement("svg", Af({
      width: "1.5em",
      height: "1.5em",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      fill: "none",
      xmlns: "http://www.w3.org/2000/svg",
      color: "currentColor",
      ref: n
    }, o), m.createElement("path", {
      d: "M8 11H11M14 11H11M11 11V8M11 11V14",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M17 17L21 21",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }), m.createElement("path", {
      d: "M3 11C3 15.4183 6.58172 19 11 19C13.213 19 15.2161 18.1015 16.6644 16.6493C18.1077 15.2022 19 13.2053 19 11C19 6.58172 15.4183 3 11 3C6.58172 3 3 6.58172 3 11Z",
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }));
  }, r3 = m.forwardRef(l3);
  var vh = r3;
  const $i = {
    md: 768,
    lg: 1120
  };
  function H1() {
    if (typeof window > "u") return {
      isLg: true,
      isMd: false,
      isSm: false
    };
    const l = window.innerWidth;
    return {
      isLg: l >= $i.lg,
      isMd: l >= $i.md && l < $i.lg,
      isSm: l < $i.md
    };
  }
  let Ko = H1();
  const Wf = /* @__PURE__ */ new Set();
  function a3(l) {
    return Wf.add(l), () => Wf.delete(l);
  }
  function o3() {
    return Ko;
  }
  if (typeof window < "u") {
    const l = () => {
      const n = H1();
      if (n.isLg !== Ko.isLg || n.isMd !== Ko.isMd || n.isSm !== Ko.isSm) {
        Ko = n;
        for (const r of Wf) r();
      }
    };
    window.addEventListener("resize", l);
  }
  function xh() {
    return m.useSyncExternalStore(a3, o3, () => ({
      isLg: true,
      isMd: false,
      isSm: false
    }));
  }
  const s3 = 8;
  function U1({ side: l, width: n, onResize: r }) {
    const [o, i] = m.useState(false), c = m.useRef(0), d = m.useRef(0), f = m.useCallback((v) => {
      const b = Math.max(qi, Math.min(Gi, v));
      return Math.abs(b - Zo) <= s3 ? Zo : Math.round(b);
    }, []), g = m.useCallback((v) => {
      if (v.button !== 0) return;
      v.preventDefault(), v.stopPropagation(), c.current = v.clientX, d.current = n, i(true), document.body.style.userSelect = "none", document.body.style.cursor = "col-resize";
      const b = (C) => {
        const k = C.clientX - c.current, x = l === "left" ? d.current + k : d.current - k;
        r(f(x));
      }, S = () => {
        document.removeEventListener("mousemove", b), document.removeEventListener("mouseup", S), document.body.style.userSelect = "", document.body.style.cursor = "", i(false);
      };
      document.addEventListener("mousemove", b), document.addEventListener("mouseup", S);
    }, [
      l,
      n,
      r,
      f
    ]), p = m.useCallback(() => {
      r(Zo);
    }, [
      r
    ]);
    return {
      handleProps: {
        onMouseDown: g,
        onDoubleClick: p,
        style: {
          position: "absolute",
          top: 0,
          bottom: 0,
          width: 6,
          cursor: "col-resize",
          zIndex: 50,
          ...l === "left" ? {
            right: -3
          } : {
            left: -3
          }
        }
      },
      isResizing: o
    };
  }
  async function Jf(l) {
    const { emit: n } = await yt(async () => {
      const { emit: r } = await import("./event-BC8TvpKC.js");
      return {
        emit: r
      };
    }, __vite__mapDeps([2,1]));
    await n("open-file", l);
  }
  async function eh(l) {
    var _a;
    const n = Se.getState().library;
    if (n) try {
      let r = null;
      if (l || (r = ((_a = Pe.getState().getActiveTab()) == null ? void 0 : _a.filePath) ?? null), r || (r = await u0()), !r) return;
      !r.endsWith(".gds") && !r.endsWith(".gds2") && !r.endsWith(".gdsii") && (r += ".gds");
      const o = n.to_gds();
      await o0(r, o), Fn.getState().markClean();
      const i = Pe.getState().activeTabId;
      if (i) {
        const c = r.split(/[/\\]/).pop() ?? "untitled";
        Pe.getState().updateTab(i, {
          filePath: r,
          title: c,
          isDirty: false
        });
      }
      Xt.getState().show(`Saved to ${r.split("/").pop()}`);
    } catch (r) {
      console.error("Failed to save GDS file:", r), Xt.getState().show(`Save failed: ${r}`, "error");
    }
  }
  async function Y1() {
    if (!Fn.getState().isDirty) return true;
    if (Yn) {
      const { ask: l } = await yt(async () => {
        const { ask: n } = await import("./index-C2Rw4G7o.js");
        return {
          ask: n
        };
      }, __vite__mapDeps([0,1]));
      return l("You have unsaved changes. Do you want to discard them?", {
        title: "Unsaved Changes",
        kind: "warning",
        okLabel: "Discard",
        cancelLabel: "Cancel"
      });
    }
    return window.confirm("You have unsaved changes. Do you want to discard them?");
  }
  async function wh() {
    window.dispatchEvent(new CustomEvent("rosette-new-file"));
  }
  async function B1() {
    const { renderer: l } = Se.getState();
    if (!l) throw new Error("Renderer not ready");
    const n = await l.capture_screenshot(), r = new DataView(n.buffer, n.byteOffset, n.byteLength), o = r.getUint32(0, true), i = r.getUint32(4, true), c = n.slice(8), d = document.createElement("canvas");
    d.width = o, d.height = i;
    const f = d.getContext("2d");
    if (!f) throw new Error("Failed to create 2D context");
    const g = new ImageData(new Uint8ClampedArray(c.buffer, c.byteOffset, c.byteLength), o, i);
    return f.putImageData(g, 0, 0), new Promise((p, v) => {
      d.toBlob((b) => b ? p(b) : v(new Error("PNG encoding failed")), "image/png");
    });
  }
  async function i3() {
    try {
      const l = await B1();
      if (Yn) {
        let n = await d0();
        if (!n) return;
        n.endsWith(".png") || (n += ".png");
        const r = new Uint8Array(await l.arrayBuffer());
        await s0(n, r), Xt.getState().show(`Screenshot saved to ${n.split("/").pop()}`);
      } else {
        const n = URL.createObjectURL(l), r = document.createElement("a");
        r.href = n, r.download = "screenshot.png", document.body.appendChild(r), r.click(), document.body.removeChild(r), URL.revokeObjectURL(n), Xt.getState().show("Screenshot downloaded");
      }
    } catch (l) {
      console.error("Screenshot failed:", l), Xt.getState().show(`Screenshot failed: ${l}`, "error");
    }
  }
  async function c3() {
    try {
      const l = await B1();
      await navigator.clipboard.write([
        new ClipboardItem({
          "image/png": l
        })
      ]), Xt.getState().show("Screenshot copied to clipboard");
    } catch (l) {
      console.error("Screenshot to clipboard failed:", l), Xt.getState().show(`Screenshot to clipboard failed: ${l}`, "error");
    }
  }
  const Zn = Object.freeze(Object.defineProperty({
    __proto__: null,
    confirmDiscardChanges: Y1,
    emitOpenFile: Jf,
    handleNewFile: wh,
    handleSave: eh,
    handleScreenshot: i3,
    handleScreenshotToClipboard: c3
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  function Vn({ label: l, shortcut: n, position: r = "bottom", align: o = "center", className: i, children: c }) {
    var _a;
    const d = me((v) => v.theme) === "dark", f = Y("inline-flex h-[18px] min-w-[18px] items-center justify-center rounded border px-1 text-[11px]", d ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10"), p = r === "left" || r === "right" ? Y("top-1/2 -translate-y-1/2", r === "left" ? "right-full mr-3" : "left-full ml-3") : Y(o === "end" ? "right-0" : "left-1/2 -translate-x-1/2", r === "bottom" ? "top-full mt-2" : "bottom-full mb-2");
    return y.jsxs("div", {
      className: Y("group relative", i),
      children: [
        c,
        y.jsxs("div", {
          className: Y("pointer-events-none select-none absolute z-50 flex items-center gap-1.5 rounded-lg border px-2 py-0.5 text-[11px] whitespace-nowrap opacity-0 transition-opacity group-hover:opacity-100", p, d ? "border-white/10 bg-[rgb(29,29,29)] text-white/90" : "border-black/10 bg-[rgb(241,241,241)] text-black/90"),
          children: [
            y.jsx("span", {
              children: l
            }),
            n && y.jsxs("span", {
              className: "flex gap-0.5",
              children: [
                (_a = n.modifiers) == null ? void 0 : _a.map((v) => y.jsx("kbd", {
                  className: f,
                  children: v
                }, v)),
                y.jsx("kbd", {
                  className: f,
                  children: n.key
                })
              ]
            })
          ]
        })
      ]
    });
  }
  function u3(l) {
    return "separator" in l && l.separator;
  }
  function d3(l, n, r, o = "nested") {
    if (o === "flat" || !l) return n;
    const i = [];
    function c(d) {
      for (const f of d) i.push(f.name), f.children.length > 0 && r.has(f.name) && c(f.children);
    }
    return c(l), i;
  }
  function f3(l, n) {
    if (!l) return null;
    function r(o, i) {
      for (const c of o) {
        if (c.name === n) return i;
        const d = r(c.children, c.name);
        if (d !== null) return d;
      }
      return null;
    }
    return r(l, null);
  }
  function Tv(l, n) {
    if (!l) return null;
    function r(o) {
      for (const i of o) {
        if (i.name === n) return i;
        const c = r(i.children);
        if (c) return c;
      }
      return null;
    }
    return r(l);
  }
  function Nv(l, n, r, o, i = "nested") {
    const c = [];
    if (l.length > 1) for (const f of l) c.push({
      type: "tab",
      id: f.id
    });
    const d = d3(n, r, o, i);
    for (const f of d) c.push({
      type: "cell",
      name: f
    });
    return c;
  }
  function X1(l, n) {
    return l === null || n === null ? l === n : l.type !== n.type ? false : l.type === "tab" && n.type === "tab" ? l.id === n.id : l.type === "cell" && n.type === "cell" ? l.name === n.name : false;
  }
  function h3(l, n) {
    return n ? l.findIndex((r) => X1(r, n)) : -1;
  }
  function m3({ expanded: l, isDark: n }) {
    return y.jsx("svg", {
      width: "16",
      height: "16",
      viewBox: "0 0 16 16",
      className: Y("flex-shrink-0 transition-transform duration-150", l ? "rotate-90" : "rotate-0", n ? "text-white/40" : "text-black/40"),
      children: y.jsx("path", {
        d: "M6 4l4 4-4 4",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "1.5"
      })
    });
  }
  function g3({ items: l, isDark: n, onAction: r }) {
    const o = m.useRef(null), [i, c] = m.useState(false);
    return m.useLayoutEffect(() => {
      o.current && o.current.getBoundingClientRect().right > window.innerWidth - 8 && c(true);
    }, []), y.jsx("div", {
      ref: o,
      className: Y("absolute -top-1 z-50 ml-1 min-w-[170px] rounded-xl border py-1", i ? "right-full mr-1" : "left-full", n ? "border-white/10 bg-[rgb(29,29,29)] text-white/90" : "border-black/10 bg-[rgb(241,241,241)] text-black/90"),
      children: l.map((d) => {
        var _a;
        return u3(d) ? y.jsx("div", {
          className: Y("my-1 h-px", n ? "bg-white/10" : "bg-black/10")
        }, d.id) : y.jsxs("button", {
          className: Y("mx-1 flex w-[calc(100%-0.5rem)] cursor-pointer items-center justify-between gap-3 rounded-lg px-2 py-1.5 text-left text-xs transition-colors", d.disabled ? "opacity-40" : n ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
          disabled: d.disabled,
          onClick: () => {
            d.disabled || (Promise.resolve(d.action()).catch((f) => console.error("Menu action failed:", f)), r());
          },
          children: [
            y.jsx("span", {
              children: d.label
            }),
            d.shortcut && y.jsxs("span", {
              className: "flex gap-0.5",
              children: [
                (_a = d.shortcut.modifiers) == null ? void 0 : _a.map((f) => y.jsx("kbd", {
                  className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[11px]", n ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10"),
                  children: f
                }, f)),
                y.jsx("kbd", {
                  className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[11px]", n ? "border-white/15 bg-white/10" : "border-black/15 bg-black/10"),
                  children: d.shortcut.key
                })
              ]
            })
          ]
        }, d.id);
      })
    });
  }
  function p3({ isDark: l }) {
    const [n, r] = m.useState(false), [o, i] = m.useState(null), c = m.useRef(null);
    Pa("explorer-menu", n);
    const d = m.useCallback(() => {
      r(false), i(null);
    }, []);
    m.useEffect(() => {
      if (!n) return;
      const g = (p) => {
        c.current && !c.current.contains(p.target) && d();
      };
      return document.addEventListener("mousedown", g), () => document.removeEventListener("mousedown", g);
    }, [
      n,
      d
    ]), m.useEffect(() => {
      if (!n) return;
      const g = (p) => {
        p.key === "Escape" && (p.preventDefault(), d());
      };
      return document.addEventListener("keydown", g), () => document.removeEventListener("keydown", g);
    }, [
      n,
      d
    ]);
    const f = [
      {
        id: "file",
        label: "File",
        buildItems: () => [
          {
            id: "file-new",
            label: "New",
            shortcut: {
              modifiers: [
                He.mod
              ],
              key: "N"
            },
            action: async () => {
              await wh();
            },
            disabled: false
          },
          {
            id: "file-open",
            label: "Open...",
            shortcut: {
              modifiers: [
                He.mod
              ],
              key: "O"
            },
            action: async () => {
              const { pickGdsFile: g } = await yt(async () => {
                const { pickGdsFile: b } = await Promise.resolve().then(() => g0);
                return {
                  pickGdsFile: b
                };
              }, void 0), { emitOpenFile: p } = await yt(async () => {
                const { emitOpenFile: b } = await Promise.resolve().then(() => Zn);
                return {
                  emitOpenFile: b
                };
              }, void 0), v = await g();
              v && await p(v);
            },
            disabled: !Yn
          },
          {
            id: "file-save",
            label: "Save",
            shortcut: {
              modifiers: [
                He.mod
              ],
              key: "S"
            },
            action: async () => {
              const { handleSave: g } = await yt(async () => {
                const { handleSave: p } = await Promise.resolve().then(() => Zn);
                return {
                  handleSave: p
                };
              }, void 0);
              await g(false);
            },
            disabled: !Yn
          },
          {
            id: "file-save-as",
            label: "Save As...",
            shortcut: {
              modifiers: [
                He.mod,
                He.shift
              ],
              key: "S"
            },
            action: async () => {
              const { handleSave: g } = await yt(async () => {
                const { handleSave: p } = await Promise.resolve().then(() => Zn);
                return {
                  handleSave: p
                };
              }, void 0);
              await g(true);
            },
            disabled: !Yn
          },
          {
            id: "sep-file-1",
            separator: true
          },
          {
            id: "file-screenshot",
            label: "Export Screenshot",
            action: async () => {
              const { handleScreenshot: g } = await yt(async () => {
                const { handleScreenshot: p } = await Promise.resolve().then(() => Zn);
                return {
                  handleScreenshot: p
                };
              }, void 0);
              await g();
            },
            disabled: false
          },
          {
            id: "file-screenshot-clipboard",
            label: "Copy Screenshot",
            action: async () => {
              const { handleScreenshotToClipboard: g } = await yt(async () => {
                const { handleScreenshotToClipboard: p } = await Promise.resolve().then(() => Zn);
                return {
                  handleScreenshotToClipboard: p
                };
              }, void 0);
              await g();
            },
            disabled: false
          }
        ]
      },
      {
        id: "edit",
        label: "Edit",
        buildItems: () => {
          const { library: g, renderer: p } = Se.getState(), { canUndo: v, canRedo: b } = ce.getState(), { selectedIds: S } = se.getState(), { hasContent: C } = Xn.getState(), { selectedRulerIds: k } = Oe.getState(), x = S.size > 0, E = k.size > 0, _ = g ? g.get_all_ids().length > 0 : false;
          return [
            {
              id: "undo",
              label: "Undo",
              shortcut: {
                modifiers: [
                  He.mod
                ],
                key: "Z"
              },
              action: () => {
                g && p && ce.getState().undo({
                  library: g,
                  renderer: p
                });
              },
              disabled: !v
            },
            {
              id: "redo",
              label: "Redo",
              shortcut: {
                modifiers: [
                  He.mod,
                  He.shift
                ],
                key: "Z"
              },
              action: () => {
                g && p && ce.getState().redo({
                  library: g,
                  renderer: p
                });
              },
              disabled: !b
            },
            {
              id: "sep-edit-1",
              separator: true
            },
            {
              id: "copy",
              label: "Copy",
              shortcut: {
                modifiers: [
                  He.mod
                ],
                key: "C"
              },
              action: () => {
                if (!g) return;
                const N = se.getState().selectedIds, A = xr(g, N);
                Xn.getState().copy(A);
              },
              disabled: !x
            },
            {
              id: "paste",
              label: "Paste",
              shortcut: {
                modifiers: [
                  He.mod
                ],
                key: "V"
              },
              action: () => {
                if (!g || !p) return;
                const N = new fc();
                ce.getState().execute(N, {
                  library: g,
                  renderer: p
                });
                const A = document.querySelector("canvas");
                A && qr(g, A);
              },
              disabled: !C
            },
            {
              id: "duplicate",
              label: "Duplicate",
              shortcut: {
                modifiers: [
                  He.mod
                ],
                key: "B"
              },
              action: () => {
                if (!g || !p) return;
                const N = se.getState().selectedIds;
                if (N.size === 0) return;
                const A = new hc([
                  ...N
                ]);
                ce.getState().execute(A, {
                  library: g,
                  renderer: p
                });
                const R = document.querySelector("canvas");
                R && qr(g, R);
              },
              disabled: !x
            },
            {
              id: "sep-edit-2",
              separator: true
            },
            {
              id: "delete",
              label: "Delete",
              shortcut: {
                key: He.backspace
              },
              action: () => {
                if (!g || !p) return;
                const N = Oe.getState().selectedRulerIds;
                if (N.size > 0) {
                  const I = new sh([
                    ...N
                  ]);
                  ce.getState().execute(I, {
                    library: g,
                    renderer: p
                  });
                  return;
                }
                const A = se.getState().selectedIds;
                if (A.size === 0) return;
                const R = new dc([
                  ...A
                ]);
                ce.getState().execute(R, {
                  library: g,
                  renderer: p
                });
              },
              disabled: !x && !E
            },
            {
              id: "sep-edit-3",
              separator: true
            },
            {
              id: "selectAll",
              label: "Select All",
              shortcut: {
                modifiers: [
                  He.mod
                ],
                key: "A"
              },
              action: () => {
                if (!g) return;
                const N = g.get_all_ids();
                se.getState().selectAll(N);
              },
              disabled: !_
            }
          ];
        }
      },
      {
        id: "view",
        label: "View",
        buildItems: () => {
          const { library: g } = Se.getState(), { selectedIds: p } = se.getState(), v = p.size > 0;
          return [
            {
              id: "zoomIn",
              label: "Zoom In",
              shortcut: {
                key: "+"
              },
              action: () => {
                const b = document.querySelector("canvas");
                if (!b) return;
                const S = b.getBoundingClientRect();
                Ve.getState().zoomAt(sc, S.width / 2, S.height / 2);
              },
              disabled: false
            },
            {
              id: "zoomOut",
              label: "Zoom Out",
              shortcut: {
                key: "-"
              },
              action: () => {
                const b = document.querySelector("canvas");
                if (!b) return;
                const S = b.getBoundingClientRect();
                Ve.getState().zoomAt(ic, S.width / 2, S.height / 2);
              },
              disabled: false
            },
            {
              id: "sep-view-1",
              separator: true
            },
            {
              id: "fitAll",
              label: "Fit All",
              shortcut: {
                key: "F"
              },
              action: () => {
                ds();
              },
              disabled: false
            },
            {
              id: "fitSelection",
              label: "Fit Selection",
              shortcut: {
                modifiers: [
                  He.shift
                ],
                key: "F"
              },
              action: () => {
                const b = document.querySelector("canvas");
                if (!b || !g) return;
                const S = se.getState().selectedIds;
                if (S.size === 0) return;
                const C = g.get_bounds_for_ids([
                  ...S
                ]), k = C ? {
                  minX: C[0],
                  minY: C[1],
                  maxX: C[2],
                  maxY: C[3]
                } : null, x = Zr(b);
                Ve.getState().zoomToSelected(k, x.width, x.height, x.screenCenter);
              },
              disabled: !v
            }
          ];
        }
      },
      {
        id: "preferences",
        label: "Preferences",
        buildItems: () => {
          const { themeSetting: g, showGrid: p } = me.getState();
          return [
            {
              id: "theme-light",
              label: `${g === "light" ? "\u2713  " : "     "}Light`,
              action: () => me.getState().setThemeSetting("light"),
              disabled: false
            },
            {
              id: "theme-dark",
              label: `${g === "dark" ? "\u2713  " : "     "}Dark`,
              action: () => me.getState().setThemeSetting("dark"),
              disabled: false
            },
            {
              id: "theme-system",
              label: `${g === "system" ? "\u2713  " : "     "}System`,
              action: () => me.getState().setThemeSetting("system"),
              disabled: false
            },
            {
              id: "sep-prefs-1",
              separator: true
            },
            {
              id: "show-grid",
              label: `${p ? "\u2713  " : "     "}Show Grid`,
              action: () => me.getState().toggleGrid(),
              disabled: false
            }
          ];
        }
      }
    ];
    return y.jsxs("div", {
      ref: c,
      className: "relative ml-auto flex-shrink-0",
      children: [
        y.jsx("button", {
          type: "button",
          onClick: () => {
            r((g) => !g), i(null);
          },
          className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", n && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
          children: y.jsx("div", {
            className: "flex h-4 w-4 items-center justify-center",
            children: y.jsx(wk, {
              className: Y("h-4 w-4", l ? "text-white/60" : "text-black/60")
            })
          })
        }),
        n && y.jsx("div", {
          className: Y("absolute top-full right-0 z-50 mt-1 min-w-[140px] rounded-xl border py-1", l ? "border-white/10 bg-[rgb(29,29,29)] text-white/90" : "border-black/10 bg-[rgb(241,241,241)] text-black/90"),
          children: f.map((g) => y.jsxs("div", {
            className: "relative",
            children: [
              y.jsxs("button", {
                type: "button",
                className: Y("mx-1 flex w-[calc(100%-0.5rem)] cursor-pointer items-center justify-between gap-3 rounded-lg px-2 py-1.5 text-left text-xs transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", o === g.id && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
                onMouseEnter: () => i(g.id),
                onClick: () => i(o === g.id ? null : g.id),
                children: [
                  y.jsx("span", {
                    children: g.label
                  }),
                  y.jsx("svg", {
                    width: "12",
                    height: "12",
                    viewBox: "0 0 16 16",
                    className: "flex-shrink-0",
                    children: y.jsx("path", {
                      d: "M6 4l4 4-4 4",
                      fill: "none",
                      stroke: "currentColor",
                      strokeWidth: "1.5"
                    })
                  })
                ]
              }),
              o === g.id && y.jsx(g3, {
                items: g.buildItems(),
                isDark: l,
                onAction: d
              })
            ]
          }, g.id))
        })
      ]
    });
  }
  function V1({ name: l, isActive: n, isFocused: r, isDark: o, depth: i, hasChildren: c, isExpanded: d, isHidden: f, onToggleExpand: g, onSelect: p, onRename: v, startEditing: b, canDrag: S }) {
    const [C, k] = m.useState(false), [x, E] = m.useState(l), _ = m.useRef(null), N = m.useRef(null);
    m.useEffect(() => {
      r && N.current && N.current.scrollIntoView({
        block: "nearest"
      });
    }, [
      r
    ]), m.useEffect(() => {
      b && (k(true), E(l), ue.getState().setEditingCellName(null));
    }, [
      b,
      l
    ]), m.useEffect(() => {
      C && _.current && (_.current.focus(), _.current.select());
    }, [
      C
    ]);
    const A = m.useCallback(() => {
      const D = x.trim();
      D && D !== l ? v(D) : E(l), k(false);
    }, [
      x,
      l,
      v
    ]), R = m.useCallback((D) => {
      D.key === "Enter" ? A() : D.key === "Escape" && (E(l), k(false));
    }, [
      A,
      l
    ]), I = m.useCallback((D) => {
      D.preventDefault(), D.stopPropagation(), os.getState().open("cell", {
        x: D.clientX,
        y: D.clientY
      }, l);
    }, [
      l
    ]), T = m.useCallback((D) => {
      D.stopPropagation(), g();
    }, [
      g
    ]), L = m.useCallback((D) => {
      if (D.button !== 0 || !S || C) {
        S || D.preventDefault();
        return;
      }
      const H = {
        x: D.clientX,
        y: D.clientY
      };
      let q = false;
      const re = (de) => {
        const ge = de.clientX - H.x, Ee = de.clientY - H.y;
        if (!(!q && ge * ge + Ee * Ee < 25) && !q) {
          q = true;
          const { library: $ } = Se.getState();
          if (!$) return;
          const F = $.get_cell_bounds(l) ?? null, fe = $.get_cell_origin_by_name(l), ye = {
            x: fe ? fe[0] : 0,
            y: fe ? fe[1] : 0
          };
          Ki.getState().startDrag(l, F, ye);
        }
      }, ee = () => {
        document.removeEventListener("mousemove", re), document.removeEventListener("mouseup", ee);
      };
      document.addEventListener("mousemove", re), document.addEventListener("mouseup", ee);
    }, [
      S,
      C,
      l
    ]);
    return y.jsxs("button", {
      ref: N,
      type: "button",
      className: Y("mx-1 flex w-[calc(100%-8px)] cursor-pointer items-center rounded-lg py-1.5 text-left transition-colors focus:outline-none", n ? o ? "bg-[rgb(54,54,54)] text-white/90" : "bg-[rgb(217,217,217)] text-black/90" : r ? o ? "bg-[rgb(44,44,44)] text-white/90" : "bg-[rgb(227,227,227)] text-black/90" : o ? "text-white/70 hover:bg-[rgb(54,54,54)] hover:text-white/90" : "text-black/70 hover:bg-[rgb(217,217,217)] hover:text-black/90", r && (o ? "ring-1 ring-white/25" : "ring-1 ring-black/20")),
      style: {
        paddingLeft: `${7 + i * 10}px`,
        paddingRight: "7px"
      },
      onClick: p,
      onContextMenu: I,
      onMouseDown: L,
      tabIndex: -1,
      children: [
        c ? y.jsx("button", {
          type: "button",
          className: "mr-0.5 flex h-4 w-4 flex-shrink-0 cursor-pointer items-center justify-center bg-transparent border-none p-0",
          onClick: T,
          children: y.jsx(m3, {
            expanded: d,
            isDark: o
          })
        }) : y.jsx("span", {
          className: "mr-0.5 h-4 w-4 flex-shrink-0"
        }),
        y.jsx("div", {
          className: "relative h-5 min-w-0 flex-1",
          children: C ? y.jsx("input", {
            ref: _,
            type: "text",
            value: x,
            onChange: (D) => E(D.target.value),
            onBlur: A,
            onKeyDown: R,
            onClick: (D) => D.stopPropagation(),
            className: Y("absolute inset-0 m-0 box-border w-full border-0 bg-transparent p-0 text-sm leading-5 outline-none focus:ring-0", o ? "text-white/90" : "text-black/90")
          }) : y.jsx("span", {
            className: Y("absolute inset-0 truncate text-sm leading-5 select-none", f && "opacity-40"),
            onDoubleClick: (D) => {
              D.stopPropagation(), k(true), E(l);
            },
            children: l
          })
        })
      ]
    });
  }
  function $1({ node: l, depth: n, isDark: r, activeCell: o, focusedCellName: i, editingCellName: c, expandedCells: d, hiddenCells: f, onSelect: g, onRename: p, onToggleExpand: v }) {
    const b = l.children.length > 0, S = d.has(l.name), C = l.name !== o;
    return y.jsxs(y.Fragment, {
      children: [
        y.jsx(V1, {
          name: l.name,
          isActive: l.name === o,
          isFocused: l.name === i,
          isDark: r,
          depth: n,
          hasChildren: b,
          isExpanded: S,
          isHidden: f.has(l.name),
          onToggleExpand: () => v(l.name),
          onSelect: () => g(l.name),
          onRename: (k) => p(l.name, k),
          startEditing: c === l.name,
          canDrag: C
        }),
        b && S && l.children.map((k) => y.jsx($1, {
          node: k,
          depth: n + 1,
          isDark: r,
          activeCell: o,
          focusedCellName: i,
          editingCellName: c,
          expandedCells: d,
          hiddenCells: f,
          onSelect: g,
          onRename: p,
          onToggleExpand: v
        }, `${l.name}/${k.name}`))
      ]
    });
  }
  function y3({ tab: l, isActive: n, isFocused: r, isDark: o, onSelect: i, onClose: c, onMiddleClick: d }) {
    const f = m.useRef(null);
    return m.useEffect(() => {
      r && f.current && f.current.scrollIntoView({
        block: "nearest"
      });
    }, [
      r
    ]), y.jsxs("div", {
      ref: f,
      role: "tab",
      tabIndex: 0,
      "aria-selected": n,
      className: Y("group mx-1 flex w-[calc(100%-8px)] cursor-pointer items-center gap-1.5 rounded-lg py-1.5 pr-1 pl-2 transition-colors", n ? o ? "bg-[rgb(54,54,54)] text-white/90" : "bg-[rgb(217,217,217)] text-black/90" : r ? o ? "bg-[rgb(44,44,44)] text-white/90" : "bg-[rgb(227,227,227)] text-black/90" : o ? "text-white/70 hover:bg-[rgb(54,54,54)] hover:text-white/90" : "text-black/70 hover:bg-[rgb(217,217,217)] hover:text-black/90", r && (o ? "ring-1 ring-white/25" : "ring-1 ring-black/20")),
      onClick: i,
      onKeyDown: (g) => {
        (g.key === "Enter" || g.key === " ") && (g.preventDefault(), i());
      },
      onMouseDown: d,
      children: [
        l.isDirty ? y.jsx("span", {
          className: Y("h-1.5 w-1.5 flex-shrink-0 rounded-full", o ? "bg-white/50" : "bg-black/50")
        }) : y.jsx("span", {
          className: "h-1.5 w-1.5 flex-shrink-0"
        }),
        y.jsx("span", {
          className: "min-w-0 flex-1 truncate text-sm select-none",
          children: l.title
        }),
        y.jsx("button", {
          type: "button",
          onClick: c,
          className: Y("flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-sm transition-opacity", "opacity-0 group-hover:opacity-100", o ? "hover:bg-white/15 text-white/50 hover:text-white/80" : "hover:bg-black/15 text-black/50 hover:text-black/80"),
          children: y.jsx("svg", {
            width: "8",
            height: "8",
            viewBox: "0 0 8 8",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            children: y.jsx("path", {
              d: "M1.5 1.5l5 5M6.5 1.5l-5 5"
            })
          })
        })
      ]
    });
  }
  function b3({ isDark: l, focusedItem: n }) {
    const r = Pe((f) => f.tabs), o = Pe((f) => f.activeTabId), i = m.useCallback((f) => {
      f !== o && ($r(o, f), Pe.getState().setActiveTab(f));
    }, [
      o
    ]), c = m.useCallback(async (f, g) => {
      f.stopPropagation(), window.dispatchEvent(new CustomEvent("rosette-close-tab", {
        detail: g
      }));
    }, []), d = m.useCallback((f, g) => {
      f.button === 1 && (f.preventDefault(), window.dispatchEvent(new CustomEvent("rosette-close-tab", {
        detail: g
      })));
    }, []);
    return r.length <= 1 ? null : y.jsxs(y.Fragment, {
      children: [
        y.jsx("div", {
          className: "flex flex-col gap-0.5 py-1",
          children: r.map((f) => y.jsx(y3, {
            tab: f,
            isActive: f.id === o,
            isFocused: (n == null ? void 0 : n.type) === "tab" && n.id === f.id,
            isDark: l,
            onSelect: () => i(f.id),
            onClose: (g) => c(g, f.id),
            onMiddleClick: (g) => d(g, f.id)
          }, f.id))
        }),
        y.jsx("div", {
          className: Y("h-px", l ? "bg-white/10" : "bg-black/10")
        })
      ]
    });
  }
  function v3({ isDark: l, onExpand: n }) {
    const r = Pe((o) => o.tabs.length);
    return y.jsxs("div", {
      className: Y("fixed top-4 left-4 z-40 flex w-[38px] flex-col items-center gap-1 rounded-xl border pt-[4.5px] pb-[5px]", l ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
      children: [
        y.jsxs("div", {
          className: "relative p-1",
          children: [
            y.jsx("img", {
              src: "/icon.svg",
              alt: "",
              draggable: false,
              className: Y("h-5 w-5 select-none pointer-events-none rounded border", l ? "border-white/40" : "border-black/40")
            }),
            r > 1 && y.jsx("span", {
              className: Y("absolute -top-1 -right-1 flex h-3.5 min-w-3.5 items-center justify-center rounded-full px-0.5 text-[9px] font-medium leading-none", l ? "bg-white/20 text-white/80" : "bg-black/20 text-black/80"),
              children: r
            })
          ]
        }),
        y.jsx("div", {
          className: Y("mx-1 h-px w-5", l ? "bg-white/10" : "bg-black/10")
        }),
        y.jsx("button", {
          type: "button",
          onClick: n,
          className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
          children: y.jsx(O1, {
            className: Y("h-4 w-4", l ? "text-white/60" : "text-black/60")
          })
        })
      ]
    });
  }
  function Ov() {
    const n = me((X) => X.theme) === "dark", r = me((X) => X.explorerCollapsed), o = me((X) => X.toggleExplorerCollapsed), i = me((X) => X.explorerWidth), c = me((X) => X.setExplorerWidth), { isSm: d } = xh(), { handleProps: f } = U1({
      side: "left",
      width: i,
      onResize: c
    }), g = ue((X) => X.projectName), p = ue((X) => X.setProjectName), v = ue((X) => X.cells), b = ue((X) => X.cellTree), S = ue((X) => X.activeCell), C = ue((X) => X.setActiveCell), k = ue((X) => X.editingCellName), x = ue((X) => X.expandedCells), E = ue((X) => X.toggleExpanded), _ = ue((X) => X.cellsLoaded), N = ue((X) => X.hierarchyLevelLimit), A = ue((X) => X.setHierarchyLevelLimit), R = ue((X) => X.maxTreeDepth), I = ue((X) => X.hiddenCells), T = ue((X) => X.cellListMode), L = ue((X) => X.isFocused), D = ue((X) => X.focusedItem), H = ue((X) => X.setFocused), q = ue((X) => X.setFocusedItem);
    Pa("explorer-panel", L);
    const [re, ee] = m.useState(false), de = m.useRef(null);
    m.useEffect(() => {
      if (!d || !re) return;
      const X = (U) => {
        de.current && !de.current.contains(U.target) && ee(false);
      };
      return document.addEventListener("mousedown", X), () => document.removeEventListener("mousedown", X);
    }, [
      d,
      re
    ]);
    const ge = (X, U) => X === 1 / 0 ? U > 0 ? U.toString() : "" : X.toString(), [Ee, $] = m.useState(ge(N, R));
    m.useEffect(() => {
      $(ge(N, R));
    }, [
      N,
      R
    ]);
    const [F, fe] = m.useState(false), [ye, ke] = m.useState(g), j = m.useRef(null);
    m.useEffect(() => {
      F && j.current && (j.current.focus(), j.current.select());
    }, [
      F
    ]);
    const O = m.useCallback(() => {
      const X = ye.trim();
      X && X !== g ? p(X) : ke(g), fe(false);
    }, [
      ye,
      g,
      p
    ]), K = m.useCallback((X) => {
      X.key === "Enter" ? O() : X.key === "Escape" && (ke(g), fe(false));
    }, [
      O,
      g
    ]), W = m.useCallback((X, U) => {
      const { library: te, renderer: he } = Se.getState();
      if (te && he) {
        const be = new A0(X, U);
        ce.getState().execute(be, {
          library: te,
          renderer: he
        });
      } else ue.getState().renameCell(X, U);
    }, []), J = m.useCallback((X) => {
      X === S && v.length <= 1 || C(X === S ? null : X);
    }, [
      S,
      v.length,
      C
    ]), ie = m.useCallback((X) => {
      X.target === X.currentTarget && (X.preventDefault(), os.getState().open("cell", {
        x: X.clientX,
        y: X.clientY
      }));
    }, []);
    m.useEffect(() => {
      if (!L) return;
      const X = (U) => {
        de.current && !de.current.contains(U.target) && H(false);
      };
      return document.addEventListener("mousedown", X), () => document.removeEventListener("mousedown", X);
    }, [
      L,
      H
    ]), m.useEffect(() => {
      if (!L) return;
      const X = (U) => {
        if (U.target instanceof HTMLInputElement || U.target instanceof HTMLTextAreaElement) return;
        const { focusedItem: te, cellTree: he, cells: be, expandedCells: we, activeCell: je, editingCellName: Xe, cellListMode: We } = ue.getState();
        if (Xe) return;
        const Ce = Pe.getState().tabs, Ne = Nv(Ce, he, be, we, We);
        if (Ne.length === 0) return;
        const Ae = h3(Ne, te);
        switch (U.key) {
          case "ArrowDown": {
            U.preventDefault();
            const Ie = Ae < Ne.length - 1 ? Ae + 1 : 0;
            q(Ne[Ie]);
            break;
          }
          case "ArrowUp": {
            U.preventDefault();
            const Ie = Ae > 0 ? Ae - 1 : Ne.length - 1;
            q(Ne[Ie]);
            break;
          }
          case "ArrowRight": {
            if (U.preventDefault(), (te == null ? void 0 : te.type) === "cell" && he && We === "nested") {
              const Ie = Tv(he, te.name);
              Ie && Ie.children.length > 0 && !we.has(te.name) ? E(te.name) : Ie && Ie.children.length > 0 && we.has(te.name) && q({
                type: "cell",
                name: Ie.children[0].name
              });
            }
            break;
          }
          case "ArrowLeft": {
            if (U.preventDefault(), (te == null ? void 0 : te.type) === "cell" && he && We === "nested") {
              const Ie = Tv(he, te.name);
              if (Ie && Ie.children.length > 0 && we.has(te.name)) E(te.name);
              else {
                const $e = f3(he, te.name);
                $e && q({
                  type: "cell",
                  name: $e
                });
              }
            }
            break;
          }
          case " ": {
            if (U.preventDefault(), !te) break;
            if (te.type === "tab") {
              const Ie = Pe.getState().activeTabId;
              te.id !== Ie && ($r(Ie, te.id), Pe.getState().setActiveTab(te.id));
            } else te.name === je ? be.length > 1 && C(null) : C(te.name);
            break;
          }
          case "Enter": {
            U.preventDefault(), (te == null ? void 0 : te.type) === "cell" && ue.getState().setEditingCellName(te.name);
            break;
          }
          case "Delete":
          case "Backspace": {
            if (U.preventDefault(), !te) break;
            if (te.type === "tab") {
              const Ie = Ae;
              window.dispatchEvent(new CustomEvent("rosette-close-tab", {
                detail: te.id
              })), setTimeout(() => {
                const $e = ue.getState(), vt = Pe.getState().tabs, Ke = Nv(vt, $e.cellTree, $e.cells, $e.expandedCells, $e.cellListMode);
                if (Ke.length === 0) q(null);
                else {
                  const an = Math.min(Ie, Ke.length - 1);
                  q(Ke[an]);
                }
              }, 0);
            } else if (be.length > 1) {
              const { library: Ie, renderer: $e } = Se.getState();
              if (Ie && $e) {
                const vt = Ae < Ne.length - 1 ? Ae + 1 : Ae - 1, Ke = vt >= 0 ? Ne[vt] : null, an = new uh(te.name);
                ce.getState().execute(an, {
                  library: Ie,
                  renderer: $e
                }), Ke && !X1(Ke, te) && q(Ke);
              }
            }
            break;
          }
          case "z":
          case "Z": {
            if (!(U.metaKey || U.ctrlKey)) return;
            U.preventDefault();
            const { library: $e, renderer: vt } = Se.getState();
            if (!$e || !vt) break;
            U.shiftKey ? ce.getState().redo({
              library: $e,
              renderer: vt
            }) : ce.getState().undo({
              library: $e,
              renderer: vt
            });
            break;
          }
          case "Escape": {
            U.preventDefault(), H(false);
            break;
          }
          default:
            return;
        }
      };
      return document.addEventListener("keydown", X), () => document.removeEventListener("keydown", X);
    }, [
      L,
      H,
      q,
      C,
      E
    ]);
    const pe = m.useCallback(() => {
      d ? ee(true) : o();
    }, [
      d,
      o
    ]);
    if (r && !(d && re)) return y.jsx(v3, {
      isDark: n,
      onExpand: pe
    });
    const Re = d && re;
    return y.jsxs(y.Fragment, {
      children: [
        Re && y.jsx("div", {
          className: "fixed inset-0 z-39"
        }),
        y.jsxs("div", {
          ref: de,
          className: Y("fixed top-4 left-4 z-40 rounded-xl border transition-opacity duration-200", _ ? "opacity-100" : "pointer-events-none opacity-0", n ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]", Re && "shadow-xl"),
          style: {
            width: i
          },
          children: [
            y.jsx("div", {
              ...f
            }),
            y.jsxs("div", {
              className: "flex items-center gap-1 px-1 pt-1 pb-[3px]",
              children: [
                y.jsx("div", {
                  className: "flex-shrink-0 p-1",
                  children: y.jsx("img", {
                    src: "/icon.svg",
                    alt: "",
                    draggable: false,
                    className: Y("h-5 w-5 select-none pointer-events-none rounded border", n ? "border-white/40" : "border-black/40")
                  })
                }),
                y.jsx("div", {
                  className: "relative h-5 min-w-0 flex-1",
                  children: F ? y.jsx("input", {
                    ref: j,
                    type: "text",
                    value: ye,
                    onChange: (X) => ke(X.target.value),
                    onBlur: O,
                    onKeyDown: K,
                    onClick: (X) => X.stopPropagation(),
                    className: Y("absolute inset-0 m-0 box-border w-full border-0 bg-transparent p-0 text-xs font-medium leading-5 outline-none focus:ring-0", n ? "text-white/90" : "text-black/90")
                  }) : y.jsx("button", {
                    type: "button",
                    className: Y("absolute inset-0 cursor-text truncate border-0 bg-transparent p-0 text-left text-xs font-medium leading-5 select-none focus:outline-none", n ? "text-white/60" : "text-black/60"),
                    onClick: () => {
                      ke(g), fe(true);
                    },
                    children: g
                  })
                }),
                !d && y.jsx("button", {
                  type: "button",
                  onClick: o,
                  className: Y("flex-shrink-0 cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", n ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
                  children: y.jsx(Nk, {
                    className: Y("h-4 w-4", n ? "text-white/60" : "text-black/60")
                  })
                }),
                y.jsx(p3, {
                  isDark: n
                })
              ]
            }),
            y.jsx("div", {
              className: Y("h-px", n ? "bg-white/10" : "bg-black/10")
            }),
            y.jsx(b3, {
              isDark: n,
              focusedItem: L ? D : null
            }),
            y.jsx("div", {
              className: "flex flex-col gap-0.5 overflow-y-auto py-1",
              style: {
                maxHeight: "calc(100vh - 176px)"
              },
              onWheel: (X) => X.stopPropagation(),
              onContextMenu: ie,
              children: b && T === "nested" ? b.map((X) => y.jsx($1, {
                node: X,
                depth: 0,
                isDark: n,
                activeCell: S,
                focusedCellName: L && (D == null ? void 0 : D.type) === "cell" ? D.name : null,
                editingCellName: k,
                expandedCells: x,
                hiddenCells: I,
                onSelect: J,
                onRename: W,
                onToggleExpand: E
              }, X.name)) : v.map((X) => y.jsx(V1, {
                name: X,
                isActive: X === S,
                isFocused: L && (D == null ? void 0 : D.type) === "cell" && D.name === X,
                isDark: n,
                depth: 0,
                hasChildren: false,
                isExpanded: false,
                isHidden: I.has(X),
                onToggleExpand: () => {
                },
                onSelect: () => J(X),
                onRename: (U) => W(X, U),
                startEditing: k === X,
                canDrag: X !== S
              }, X))
            }),
            y.jsx("div", {
              className: Y("h-px", n ? "bg-white/10" : "bg-black/10")
            }),
            y.jsxs("div", {
              className: "flex items-center justify-between pl-2 pr-[5.5px] py-1.5",
              children: [
                y.jsx("span", {
                  className: Y("text-xs select-none pointer-events-none", n ? "text-white/40" : "text-black/40"),
                  children: "Level"
                }),
                y.jsxs("div", {
                  className: "flex items-center gap-1",
                  children: [
                    y.jsx("input", {
                      id: "hierarchy-level-input",
                      type: "number",
                      min: "1",
                      max: R,
                      value: Ee,
                      onChange: (X) => {
                        const U = X.target.value;
                        $(U);
                        const te = parseInt(U, 10);
                        !isNaN(te) && te >= 1 && A(te);
                      },
                      onBlur: () => {
                        const X = parseInt(Ee, 10) || R, U = Math.max(1, Math.min(X, R));
                        A(U), $(U.toString());
                      },
                      onKeyDown: (X) => {
                        if (X.key === "Enter") {
                          const U = parseInt(Ee, 10) || R, te = Math.max(1, Math.min(U, R));
                          A(te), $(te.toString()), X.currentTarget.blur();
                        } else X.key === "Escape" && X.currentTarget.blur();
                      },
                      className: Y("h-6 w-12 rounded-lg border px-2 text-xs tabular-nums outline-none", n ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90")
                    }),
                    y.jsx(Vn, {
                      label: "All levels",
                      position: "bottom",
                      children: y.jsx("button", {
                        type: "button",
                        onClick: () => A(1 / 0),
                        className: Y("flex h-6 w-6 cursor-pointer items-center justify-center rounded-lg border transition-colors", n ? "border-white/10 bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/90" : "border-black/10 bg-black/5 text-black/40 hover:bg-black/10 hover:text-black/90"),
                        children: y.jsxs("svg", {
                          width: "14",
                          height: "14",
                          viewBox: "0 0 24 24",
                          fill: "none",
                          stroke: "currentColor",
                          strokeWidth: "2",
                          strokeLinecap: "round",
                          strokeLinejoin: "round",
                          children: [
                            y.jsx("polygon", {
                              points: "12 2 2 7 12 12 22 7 12 2"
                            }),
                            y.jsx("polyline", {
                              points: "2 17 12 22 22 17"
                            }),
                            y.jsx("polyline", {
                              points: "2 12 12 17 22 12"
                            })
                          ]
                        })
                      })
                    })
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }
  function x3(l, n) {
    if (l.length < 4) return null;
    let r = l[0], o = l[1], i = l[2], c = l[3];
    if (!Number.isFinite(r) || !Number.isFinite(o) || !Number.isFinite(i) || !Number.isFinite(c)) return null;
    const d = Math.max((i - r) * 0.05, (c - o) * 0.05, 1);
    r -= d, o -= d, i += d, c += d;
    const f = i - r, g = c - o, p = n / f, v = n / g, b = Math.min(p, v), S = f * b, C = g * b, k = (n - S) / 2, x = (n - C) / 2;
    return {
      minX: r,
      minY: o,
      maxX: i,
      maxY: c,
      width: f,
      height: g,
      scale: b,
      offsetX: k,
      offsetY: x
    };
  }
  function oc(l, n, r) {
    return {
      x: (l - r.minX) * r.scale + r.offsetX,
      y: (n - r.minY) * r.scale + r.offsetY
    };
  }
  function w3(l, n, r) {
    return {
      x: r.minX + (l - r.offsetX) / r.scale,
      y: r.minY + (n - r.offsetY) / r.scale
    };
  }
  function S3(l, n, r) {
    for (const [, o, i] of r) {
      if (o.length < 3) continue;
      const c = Math.round(i[0] * 255), d = Math.round(i[1] * 255), f = Math.round(i[2] * 255), g = i[3];
      l.fillStyle = `rgba(${c},${d},${f},${g})`, l.beginPath();
      const p = oc(o[0][0], o[0][1], n);
      l.moveTo(p.x, p.y);
      for (let v = 1; v < o.length; v++) {
        const b = oc(o[v][0], o[v][1], n);
        l.lineTo(b.x, b.y);
      }
      l.closePath(), l.fill();
    }
  }
  function C3(l, n, r, o, i, c, d) {
    const f = -r.x / o, g = -r.y / o, p = f + i / o, v = g + c / o, b = oc(f, g, n), S = oc(p, v, n), C = b.x, k = b.y, x = S.x - b.x, E = S.y - b.y;
    l.strokeStyle = d.viewportStroke, l.lineWidth = 1.5, l.setLineDash([
      3,
      3
    ]), l.strokeRect(C, k, x, E), l.fillStyle = d.viewportFill, l.fillRect(C, k, x, E), l.setLineDash([]);
  }
  function E3(l) {
    return {
      canvasBg: l ? "rgb(29,29,29)" : "rgb(241,241,241)",
      viewportStroke: l ? "rgba(255, 255, 255, 0.9)" : "rgba(0, 0, 0, 0.9)",
      viewportFill: l ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)"
    };
  }
  const Kn = 180;
  function Iv() {
    const l = m.useRef(null), n = m.useRef(null), r = m.useRef(null), o = m.useRef(null), [i, c] = m.useState(false), d = Ve((L) => L.zoom), f = Ve((L) => L.offset), g = me((L) => L.theme), p = Se((L) => L.library), v = ve((L) => L.layers), b = as((L) => L.isMinimized), S = ce((L) => L.undoStack.length), C = ce((L) => L.redoStack.length), k = g === "dark", x = m.useMemo(() => E3(k), [
      k
    ]);
    m.useEffect(() => {
      const L = l.current;
      if (!L) return;
      const D = (H) => {
        const q = document.getElementById("rosette-canvas");
        q && (H.preventDefault(), q.dispatchEvent(new WheelEvent("wheel", H)));
      };
      return L.addEventListener("wheel", D, {
        passive: false
      }), () => L.removeEventListener("wheel", D);
    }, []);
    const E = m.useCallback(() => {
      var _a;
      return ((_a = document.getElementById("rosette-canvas")) == null ? void 0 : _a.getBoundingClientRect()) ?? null;
    }, []), _ = m.useCallback((L) => {
      var _a;
      const D = o.current;
      if (!D) return;
      const H = (_a = n.current) == null ? void 0 : _a.getBoundingClientRect();
      if (!H) return;
      const q = L.clientX - H.left, re = L.clientY - H.top, ee = w3(q, re, D), de = E();
      if (!de) return;
      const ge = -(ee.x * d) + de.width / 2, Ee = -(ee.y * d) + de.height / 2;
      Ve.getState().setOffset(ge, Ee);
    }, [
      d,
      E
    ]), N = m.useCallback((L) => {
      L.stopPropagation(), c(true), _(L);
    }, [
      _
    ]), A = m.useCallback((L) => {
      i && _(L);
    }, [
      i,
      _
    ]), R = m.useCallback(() => {
      c(false);
    }, []), I = m.useCallback(() => {
      c(false);
    }, []);
    if (m.useEffect(() => {
      if (b || !p) return;
      const L = p.get_all_bounds();
      if (!L) {
        o.current = null, r.current = null;
        return;
      }
      const D = x3(L, Kn);
      if (!D) {
        o.current = null, r.current = null;
        return;
      }
      o.current = D;
      let H;
      try {
        H = p.get_render_polygons();
      } catch {
        r.current = null;
        return;
      }
      if (!H || H.length === 0) {
        r.current = null;
        return;
      }
      const q = /* @__PURE__ */ new Set();
      for (const [, ge] of v) ge.visible || q.add(`${ge.layerNumber}:${ge.datatype}`);
      let re = H;
      q.size > 0 && (re = H.filter(([ge]) => {
        const Ee = p.get_element_info(ge);
        if (!Ee) return true;
        const $ = `${Ee.layer}:${Ee.datatype}`, F = q.has($);
        return Ee.free(), !F;
      }));
      const ee = document.createElement("canvas");
      ee.width = Kn, ee.height = Kn;
      const de = ee.getContext("2d");
      de && (de.clearRect(0, 0, Kn, Kn), S3(de, D, re), r.current = ee);
    }, [
      p,
      v,
      b,
      S,
      C
    ]), m.useEffect(() => {
      if (b) return;
      const L = n.current;
      if (!L) return;
      const D = L.getContext("2d");
      if (!D) return;
      const H = o.current;
      if (D.clearRect(0, 0, Kn, Kn), D.fillStyle = x.canvasBg, D.fillRect(0, 0, Kn, Kn), r.current && D.drawImage(r.current, 0, 0), H) {
        const q = E();
        q && q.width > 0 && q.height > 0 && C3(D, H, f, d, q.width, q.height, x);
      }
    }, [
      d,
      f,
      b,
      x,
      E,
      S,
      C
    ]), b) return null;
    const T = `rounded-xl border p-1 ${k ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"}`;
    return y.jsx("div", {
      className: "pointer-events-none absolute bottom-4 right-4 select-none",
      children: y.jsx("div", {
        ref: l,
        className: `pointer-events-auto relative ${T}`,
        children: y.jsx("canvas", {
          ref: n,
          width: Kn,
          height: Kn,
          className: "pointer-events-auto cursor-move rounded-lg",
          onMouseDown: N,
          onMouseMove: A,
          onMouseUp: R,
          onMouseLeave: I
        })
      })
    });
  }
  const _3 = Qo, k3 = [
    {
      id: "solid",
      label: "Solid"
    },
    {
      id: "hatched",
      label: "Hatched"
    },
    {
      id: "crosshatched",
      label: "Cross"
    },
    {
      id: "dotted",
      label: "Dotted"
    },
    {
      id: "horizontal",
      label: "Horiz"
    },
    {
      id: "vertical",
      label: "Vert"
    },
    {
      id: "zigzag",
      label: "Zigzag"
    },
    {
      id: "brick",
      label: "Brick"
    }
  ];
  function M3({ pattern: l, className: n }) {
    return y.jsxs("svg", {
      width: 14,
      height: 14,
      viewBox: "0 0 14 14",
      className: n,
      children: [
        y.jsx("rect", {
          x: "0",
          y: "0",
          width: 14,
          height: 14,
          fill: "currentColor",
          opacity: "0.15",
          rx: "1"
        }),
        l === "solid" && y.jsx("rect", {
          x: "1",
          y: "1",
          width: 12,
          height: 12,
          fill: "currentColor",
          opacity: "0.5",
          rx: "0.5"
        }),
        l === "hatched" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          children: [
            y.jsx("line", {
              x1: "0",
              y1: "4",
              x2: "4",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "9",
              x2: "9",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "14",
              x2: "14",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "5",
              y1: "14",
              x2: "14",
              y2: "5"
            }),
            y.jsx("line", {
              x1: "10",
              y1: "14",
              x2: "14",
              y2: "10"
            })
          ]
        }),
        l === "crosshatched" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          children: [
            y.jsx("line", {
              x1: "0",
              y1: "4",
              x2: "4",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "9",
              x2: "9",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "14",
              x2: "14",
              y2: "0"
            }),
            y.jsx("line", {
              x1: "5",
              y1: "14",
              x2: "14",
              y2: "5"
            }),
            y.jsx("line", {
              x1: "10",
              y1: "14",
              x2: "14",
              y2: "10"
            }),
            y.jsx("line", {
              x1: "10",
              y1: "0",
              x2: "14",
              y2: "4"
            }),
            y.jsx("line", {
              x1: "5",
              y1: "0",
              x2: "14",
              y2: "9"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "0",
              x2: "14",
              y2: "14"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "5",
              x2: "9",
              y2: "14"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "10",
              x2: "4",
              y2: "14"
            })
          ]
        }),
        l === "dotted" && y.jsxs("g", {
          fill: "currentColor",
          opacity: "0.6",
          children: [
            y.jsx("circle", {
              cx: "3.5",
              cy: "3.5",
              r: "1"
            }),
            y.jsx("circle", {
              cx: "10.5",
              cy: "3.5",
              r: "1"
            }),
            y.jsx("circle", {
              cx: "3.5",
              cy: "10.5",
              r: "1"
            }),
            y.jsx("circle", {
              cx: "10.5",
              cy: "10.5",
              r: "1"
            }),
            y.jsx("circle", {
              cx: "7",
              cy: "7",
              r: "1"
            })
          ]
        }),
        l === "horizontal" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          children: [
            y.jsx("line", {
              x1: "0",
              y1: "3.5",
              x2: "14",
              y2: "3.5"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "7",
              x2: "14",
              y2: "7"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "10.5",
              x2: "14",
              y2: "10.5"
            })
          ]
        }),
        l === "vertical" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          children: [
            y.jsx("line", {
              x1: "3.5",
              y1: "0",
              x2: "3.5",
              y2: "14"
            }),
            y.jsx("line", {
              x1: "7",
              y1: "0",
              x2: "7",
              y2: "14"
            }),
            y.jsx("line", {
              x1: "10.5",
              y1: "0",
              x2: "10.5",
              y2: "14"
            })
          ]
        }),
        l === "zigzag" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          fill: "none",
          children: [
            y.jsx("polyline", {
              points: "0,5 3.5,2 7,5 10.5,2 14,5"
            }),
            y.jsx("polyline", {
              points: "0,10 3.5,7 7,10 10.5,7 14,10"
            })
          ]
        }),
        l === "brick" && y.jsxs("g", {
          stroke: "currentColor",
          strokeWidth: "1",
          opacity: "0.6",
          children: [
            y.jsx("line", {
              x1: "0",
              y1: "3.5",
              x2: "14",
              y2: "3.5"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "7",
              x2: "14",
              y2: "7"
            }),
            y.jsx("line", {
              x1: "0",
              y1: "10.5",
              x2: "14",
              y2: "10.5"
            }),
            y.jsx("line", {
              x1: "3.5",
              y1: "0",
              x2: "3.5",
              y2: "3.5"
            }),
            y.jsx("line", {
              x1: "10.5",
              y1: "0",
              x2: "10.5",
              y2: "3.5"
            }),
            y.jsx("line", {
              x1: "7",
              y1: "3.5",
              x2: "7",
              y2: "7"
            }),
            y.jsx("line", {
              x1: "3.5",
              y1: "7",
              x2: "3.5",
              y2: "10.5"
            }),
            y.jsx("line", {
              x1: "10.5",
              y1: "7",
              x2: "10.5",
              y2: "10.5"
            }),
            y.jsx("line", {
              x1: "7",
              y1: "10.5",
              x2: "7",
              y2: "14"
            })
          ]
        })
      ]
    });
  }
  function j3({ color: l, isDark: n, onChange: r, hexTabIdx: o }) {
    const [i, c] = m.useState(l), d = m.useRef(null);
    m.useEffect(() => {
      c(l);
    }, [
      l
    ]);
    const f = m.useCallback(() => {
      const p = i.trim().replace(/^#?/, "#");
      /^#[0-9a-fA-F]{6}$/.test(p) ? r(p.toLowerCase()) : c(l);
    }, [
      i,
      l,
      r
    ]), g = m.useCallback((p) => {
      var _a, _b2;
      p.key === "Enter" ? (p.preventDefault(), (_a = d.current) == null ? void 0 : _a.blur()) : p.key === "Escape" && (p.preventDefault(), p.stopPropagation(), c(l), (_b2 = d.current) == null ? void 0 : _b2.blur());
    }, [
      l
    ]);
    return y.jsxs("div", {
      className: "flex flex-col gap-1.5",
      children: [
        y.jsx("div", {
          className: "grid grid-cols-8 gap-1",
          children: _3.map((p) => y.jsx("button", {
            type: "button",
            onClick: (v) => {
              v.stopPropagation(), r(p);
            },
            className: Y("h-5 w-full rounded border outline-none transition-all", p === l ? "ring-1 ring-offset-1 " + (n ? "ring-white/60 ring-offset-[rgb(29,29,29)]" : "ring-black/60 ring-offset-[rgb(241,241,241)]") : n ? "border-white/10 hover:border-white/30" : "border-black/10 hover:border-black/30"),
            style: {
              backgroundColor: p
            },
            tabIndex: -1
          }, p))
        }),
        y.jsxs("div", {
          className: "flex items-center gap-1.5",
          children: [
            y.jsx("div", {
              className: Y("h-5 w-5 flex-shrink-0 rounded border", n ? "border-white/10" : "border-black/10"),
              style: {
                backgroundColor: l
              }
            }),
            y.jsx("input", {
              ref: d,
              type: "text",
              value: i,
              "data-tab-index": o,
              onChange: (p) => c(p.target.value),
              onBlur: f,
              onKeyDown: g,
              onClick: (p) => p.stopPropagation(),
              tabIndex: -1,
              className: Y("h-6 min-w-0 flex-1 rounded border px-1.5 font-mono text-xs outline-none", n ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90")
            })
          ]
        })
      ]
    });
  }
  function L3({ value: l, isDark: n, onChange: r, baseTabIdx: o }) {
    return y.jsx("div", {
      className: "grid grid-cols-4 gap-1",
      children: k3.map((i, c) => {
        const d = l === i.id;
        return y.jsx("button", {
          type: "button",
          "data-tab-index": o != null ? o + c : void 0,
          onClick: (f) => {
            f.stopPropagation(), r(i.id);
          },
          className: Y("flex flex-col items-center gap-0.5 rounded-lg border px-1 py-1 text-[10px] outline-none transition-colors", d ? n ? "border-white/20 bg-white/10 text-white/90" : "border-black/20 bg-black/10 text-black/90" : n ? "border-white/5 text-white/40 hover:border-white/15 hover:text-white/70 focus:border-white/15 focus:text-white/70" : "border-black/5 text-black/40 hover:border-black/15 hover:text-black/70 focus:border-black/15 focus:text-black/70"),
          tabIndex: -1,
          children: y.jsx(M3, {
            pattern: i.id
          })
        }, i.id);
      })
    });
  }
  function Dv({ label: l, value: n, isDark: r, onChange: o, tabIdx: i }) {
    const [c, d] = m.useState(String(n)), [f, g] = m.useState(false), p = m.useRef(null);
    m.useEffect(() => {
      f || d(String(n));
    }, [
      n,
      f
    ]);
    const v = m.useCallback(() => {
      const b = Number.parseInt(c, 10);
      !Number.isNaN(b) && b >= 0 && b <= zf && b !== n ? o(b) : d(String(n));
    }, [
      c,
      n,
      o
    ]);
    return y.jsxs("div", {
      className: "flex items-center justify-between",
      children: [
        y.jsx("span", {
          className: Y("text-xs select-none", r ? "text-white/50" : "text-black/50"),
          children: l
        }),
        y.jsx("input", {
          ref: p,
          type: "text",
          value: c,
          "data-tab-index": i,
          onChange: (b) => d(b.target.value),
          onFocus: (b) => {
            g(true), b.target.select();
          },
          onBlur: () => {
            g(false), v();
          },
          onKeyDown: (b) => {
            var _a, _b2;
            b.key === "Enter" ? (b.preventDefault(), (_a = p.current) == null ? void 0 : _a.blur()) : b.key === "Escape" && (b.preventDefault(), b.stopPropagation(), d(String(n)), (_b2 = p.current) == null ? void 0 : _b2.blur());
          },
          onClick: (b) => b.stopPropagation(),
          tabIndex: -1,
          className: Y("w-16 cursor-text rounded border px-1.5 py-0.5 text-right font-mono text-xs outline-none transition-colors", f ? r ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90" : r ? "border-transparent text-white/90 hover:bg-white/5" : "border-transparent text-black/90 hover:bg-black/5")
        })
      ]
    });
  }
  function R3({ label: l, value: n, isDark: r, onChange: o, tabIdx: i }) {
    const [c, d] = m.useState(n), [f, g] = m.useState(false), p = m.useRef(null);
    m.useEffect(() => {
      f || d(n);
    }, [
      n,
      f
    ]);
    const v = m.useCallback(() => {
      const b = c.trim();
      b && b !== n ? o(b) : d(n);
    }, [
      c,
      n,
      o
    ]);
    return y.jsxs("div", {
      className: "flex items-center justify-between",
      children: [
        y.jsx("span", {
          className: Y("text-xs select-none", r ? "text-white/50" : "text-black/50"),
          children: l
        }),
        y.jsx("input", {
          ref: p,
          type: "text",
          value: c,
          "data-tab-index": i,
          onChange: (b) => d(b.target.value),
          onFocus: (b) => {
            g(true), b.target.select();
          },
          onBlur: () => {
            g(false), v();
          },
          onKeyDown: (b) => {
            var _a, _b2;
            b.key === "Enter" ? (b.preventDefault(), (_a = p.current) == null ? void 0 : _a.blur()) : b.key === "Escape" && (b.preventDefault(), b.stopPropagation(), d(n), (_b2 = p.current) == null ? void 0 : _b2.blur());
          },
          onClick: (b) => b.stopPropagation(),
          tabIndex: -1,
          className: Y("w-28 cursor-text truncate rounded border px-1.5 py-0.5 text-right text-xs outline-none transition-colors", f ? r ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90" : r ? "border-transparent text-white/90 hover:bg-white/5" : "border-transparent text-black/90 hover:bg-black/5")
        })
      ]
    });
  }
  function Tf({ label: l, isDark: n }) {
    return y.jsx("span", {
      className: Y("text-[10px] font-semibold uppercase tracking-wider select-none", n ? "text-white/30" : "text-black/30"),
      children: l
    });
  }
  function A3({ layer: l, isDark: n }) {
    const r = Se((f) => f.library), o = Se((f) => f.renderer), i = m.useRef(null), c = m.useCallback((f) => {
      if (!r || !o) return;
      const g = {
        ...l,
        ...f
      };
      if (f.layerNumber !== void 0 || f.datatype !== void 0) {
        for (const v of ve.getState().layers.values()) if (v.id !== l.id && v.layerNumber === g.layerNumber && v.datatype === g.datatype) {
          Xt.getState().show(`Layer ${g.layerNumber}/${g.datatype} already exists`, "warn");
          return;
        }
      }
      const p = new R0(l, g);
      ce.getState().execute(p, {
        library: r,
        renderer: o
      });
    }, [
      l,
      r,
      o
    ]);
    m.useEffect(() => {
      const f = requestAnimationFrame(() => {
        var _a, _b2;
        (_b2 = (_a = i.current) == null ? void 0 : _a.querySelector("[data-tab-index='0']")) == null ? void 0 : _b2.focus();
      });
      return () => cancelAnimationFrame(f);
    }, []), m.useEffect(() => {
      const f = (g) => {
        var _a;
        if (g.key === "Escape") {
          const p = document.activeElement;
          if (p && ((_a = i.current) == null ? void 0 : _a.contains(p)) && p.tagName === "INPUT") return;
          g.preventDefault(), ve.getState().setExpandedLayerId(null);
        }
      };
      return document.addEventListener("keydown", f), () => document.removeEventListener("keydown", f);
    }, []), m.useEffect(() => {
      const f = (g) => {
        i.current && !i.current.contains(g.target) && ve.getState().setExpandedLayerId(null);
      };
      return document.addEventListener("mousedown", f), () => document.removeEventListener("mousedown", f);
    }, []);
    const d = m.useCallback((f) => {
      if (f.key === "Escape" || (f.stopPropagation(), f.key !== "Tab" || !i.current)) return;
      f.preventDefault();
      const g = Array.from(i.current.querySelectorAll("[data-tab-index]")).sort((S, C) => Number(S.dataset.tabIndex) - Number(C.dataset.tabIndex));
      if (g.length === 0) return;
      const p = g.findIndex((S) => S === document.activeElement), v = f.shiftKey ? -1 : 1, b = p === -1 ? 0 : (p + v + g.length) % g.length;
      g[b].focus();
    }, []);
    return y.jsxs("div", {
      ref: i,
      role: "group",
      className: "mx-1 flex w-[calc(100%-8px)] flex-col gap-2 px-2.5 py-2",
      onClick: (f) => f.stopPropagation(),
      onKeyDown: d,
      onMouseDown: (f) => f.stopPropagation(),
      children: [
        y.jsx(R3, {
          label: "Name",
          value: l.name,
          isDark: n,
          onChange: (f) => c({
            name: f
          }),
          tabIdx: 0
        }),
        y.jsx("div", {
          className: Y("h-px", n ? "bg-white/5" : "bg-black/5")
        }),
        y.jsxs("div", {
          className: "flex flex-col gap-1.5",
          children: [
            y.jsx(Tf, {
              label: "Color",
              isDark: n
            }),
            y.jsx(j3, {
              color: l.color,
              isDark: n,
              onChange: (f) => c({
                color: f
              }),
              hexTabIdx: 1
            })
          ]
        }),
        y.jsx("div", {
          className: Y("h-px", n ? "bg-white/5" : "bg-black/5")
        }),
        y.jsxs("div", {
          className: "flex flex-col gap-1",
          children: [
            y.jsx(Tf, {
              label: "GDS",
              isDark: n
            }),
            y.jsx(Dv, {
              label: "Layer",
              value: l.layerNumber,
              isDark: n,
              onChange: (f) => c({
                layerNumber: f
              }),
              tabIdx: 2
            }),
            y.jsx(Dv, {
              label: "Datatype",
              value: l.datatype,
              isDark: n,
              onChange: (f) => c({
                datatype: f
              }),
              tabIdx: 3
            })
          ]
        }),
        y.jsx("div", {
          className: Y("h-px", n ? "bg-white/5" : "bg-black/5")
        }),
        y.jsxs("div", {
          className: "flex flex-col gap-1.5",
          children: [
            y.jsx(Tf, {
              label: "Fill",
              isDark: n
            }),
            y.jsx(L3, {
              value: l.fillPattern,
              isDark: n,
              onChange: (f) => c({
                fillPattern: f
              }),
              baseTabIdx: 4
            })
          ]
        })
      ]
    });
  }
  function T3({ layer: l, isActive: n, isFocused: r, isExpanded: o, isDark: i, onSelect: c, onToggleExpand: d, startEditing: f }) {
    const [g, p] = m.useState(false), [v, b] = m.useState(l.name), S = m.useRef(null), C = m.useRef(null);
    m.useEffect(() => {
      r && C.current && C.current.scrollIntoView({
        block: "nearest"
      });
    }, [
      r
    ]), m.useEffect(() => {
      f && (p(true), b(l.name), ve.getState().setEditingLayerId(null));
    }, [
      f,
      l.name
    ]), m.useEffect(() => {
      g && S.current && (S.current.focus(), S.current.select());
    }, [
      g
    ]);
    const k = Se((I) => I.library), x = Se((I) => I.renderer), E = m.useCallback(() => {
      const I = v.trim();
      if (I && I !== l.name && k && x) {
        const T = new R0(l, {
          ...l,
          name: I
        });
        ce.getState().execute(T, {
          library: k,
          renderer: x
        });
      } else b(l.name);
      p(false);
    }, [
      v,
      l,
      k,
      x
    ]), _ = m.useCallback((I) => {
      I.key === "Enter" ? E() : I.key === "Escape" && (b(l.name), p(false));
    }, [
      E,
      l.name
    ]), N = m.useCallback((I) => {
      I.preventDefault(), I.stopPropagation(), os.getState().open("layer", {
        x: I.clientX,
        y: I.clientY
      }, String(l.id));
    }, [
      l.id
    ]), A = m.useCallback((I) => {
      I.stopPropagation(), c(), d();
    }, [
      c,
      d
    ]), R = m.useCallback((I) => {
      o && I.stopPropagation();
    }, [
      o
    ]);
    return y.jsxs("div", {
      className: "flex flex-col gap-0.5",
      children: [
        y.jsxs("button", {
          ref: C,
          type: "button",
          className: Y("group relative mx-1 flex w-[calc(100%-8px)] cursor-pointer items-center gap-2 rounded-lg px-[7px] py-1.5 text-left transition-colors", n ? i ? "bg-[rgb(54,54,54)] text-white/90" : "bg-[rgb(217,217,217)] text-black/90" : r ? i ? "bg-[rgb(44,44,44)] text-white/90" : "bg-[rgb(227,227,227)] text-black/90" : i ? "text-white/70 hover:bg-[rgb(54,54,54)] hover:text-white/90" : "text-black/70 hover:bg-[rgb(217,217,217)] hover:text-black/90", r && (i ? "ring-1 ring-white/25" : "ring-1 ring-black/20")),
          onClick: c,
          onContextMenu: N,
          onMouseDown: (I) => I.preventDefault(),
          tabIndex: -1,
          children: [
            y.jsx("span", {
              role: "img",
              className: Y("h-4.5 w-4.5 flex-shrink-0 cursor-pointer rounded border outline-none transition-shadow", i ? "border-white/10 hover:border-white/30" : "border-black/10 hover:border-black/30", !l.visible && "opacity-40"),
              style: {
                backgroundColor: l.color
              },
              onClick: A,
              onMouseDown: R,
              onKeyDown: () => {
              }
            }),
            y.jsx("div", {
              className: "relative h-5 min-w-0 flex-1",
              children: g ? y.jsx("input", {
                ref: S,
                type: "text",
                value: v,
                onChange: (I) => b(I.target.value),
                onBlur: E,
                onKeyDown: _,
                onClick: (I) => I.stopPropagation(),
                className: Y("absolute inset-0 m-0 box-border w-full border-0 bg-transparent p-0 text-sm leading-5 outline-none focus:ring-0", i ? "text-white/90" : "text-gray-900")
              }) : y.jsx("span", {
                className: Y("absolute inset-0 truncate text-sm leading-5 select-none", !l.visible && "opacity-40"),
                onDoubleClick: (I) => {
                  I.stopPropagation(), p(true);
                },
                children: l.name
              })
            }),
            y.jsxs("div", {
              className: Y("flex flex-shrink-0 items-center self-center font-mono text-xs", !l.visible && "opacity-40"),
              children: [
                y.jsx("span", {
                  className: "select-none",
                  children: l.layerNumber
                }),
                y.jsx("span", {
                  className: "px-0.5 opacity-50 select-none",
                  children: "/"
                }),
                y.jsx("span", {
                  className: "select-none",
                  children: l.datatype
                })
              ]
            })
          ]
        }),
        o && y.jsx(A3, {
          layer: l,
          isDark: i
        })
      ]
    });
  }
  function N3() {
    const n = me((x) => x.theme) === "dark", { getAllLayers: r, activeLayerId: o, setActiveLayer: i } = ve(), c = ve((x) => x.editingLayerId), d = ve((x) => x.expandedLayerId), f = ve((x) => x.setExpandedLayerId), g = ve((x) => x.isFocused), p = ve((x) => x.focusedLayerId), v = ve((x) => x.setFocused), b = ve((x) => x.setFocusedLayerId);
    Pa("layers-panel", g);
    const S = r(), C = m.useRef(null), k = m.useCallback((x) => {
      const E = ve.getState().expandedLayerId;
      f(E === x ? null : x);
    }, [
      f
    ]);
    return m.useEffect(() => {
      if (!g) return;
      const x = (E) => {
        C.current && !C.current.contains(E.target) && v(false);
      };
      return document.addEventListener("mousedown", x), () => document.removeEventListener("mousedown", x);
    }, [
      g,
      v
    ]), m.useEffect(() => {
      if (!g) return;
      const x = (E) => {
        if (E.target instanceof HTMLInputElement || E.target instanceof HTMLTextAreaElement) return;
        const { focusedLayerId: _, editingLayerId: N, expandedLayerId: A } = ve.getState();
        if (N || A) return;
        const R = ve.getState().getAllLayers();
        if (R.length === 0) return;
        const I = _ != null ? R.findIndex((T) => T.id === _) : -1;
        switch (E.key) {
          case "ArrowDown": {
            E.preventDefault();
            const T = I < R.length - 1 ? I + 1 : 0;
            b(R[T].id);
            break;
          }
          case "ArrowUp": {
            E.preventDefault();
            const T = I > 0 ? I - 1 : R.length - 1;
            b(R[T].id);
            break;
          }
          case " ": {
            E.preventDefault(), _ != null && i(_);
            break;
          }
          case "Enter": {
            if (E.preventDefault(), _ != null) {
              const T = ve.getState().expandedLayerId;
              f(T === _ ? null : _);
            }
            break;
          }
          case "Delete":
          case "Backspace": {
            if (E.preventDefault(), _ != null && R.length > 1) {
              const { library: T, renderer: L } = Se.getState();
              if (T && L) {
                const D = I < R.length - 1 ? I + 1 : I - 1, H = D >= 0 ? R[D].id : null, q = new ih(_);
                ce.getState().execute(q, {
                  library: T,
                  renderer: L
                }), H != null && H !== _ && b(H);
              }
            }
            break;
          }
          case "z":
          case "Z": {
            if (!(E.metaKey || E.ctrlKey)) return;
            E.preventDefault();
            const { library: L, renderer: D } = Se.getState();
            if (!L || !D) break;
            E.shiftKey ? ce.getState().redo({
              library: L,
              renderer: D
            }) : ce.getState().undo({
              library: L,
              renderer: D
            });
            break;
          }
          case "Escape": {
            E.preventDefault(), v(false);
            break;
          }
          default:
            return;
        }
      };
      return document.addEventListener("keydown", x), () => document.removeEventListener("keydown", x);
    }, [
      g,
      v,
      b,
      i,
      f
    ]), y.jsx("div", {
      className: "flex h-full flex-col",
      children: y.jsx("div", {
        ref: C,
        className: "flex flex-1 flex-col gap-0.5 overflow-y-auto py-1",
        onWheel: (x) => x.stopPropagation(),
        children: S.map((x) => y.jsx(T3, {
          layer: x,
          isActive: x.id === o,
          isFocused: g && x.id === p,
          isExpanded: d === x.id,
          isDark: n,
          onSelect: () => i(x.id),
          onToggleExpand: () => k(x.id),
          startEditing: c === x.id
        }, x.id))
      })
    });
  }
  function dt({ label: l, value: n, unit: r, isDark: o, onChange: i, readOnly: c }) {
    const [d, f] = m.useState(false), [g, p] = m.useState(n), v = m.useRef(null), b = m.useRef(false), S = m.useRef(true);
    m.useEffect(() => (S.current = true, () => {
      S.current = false;
    }), []), m.useEffect(() => {
      d || p(n);
    }, [
      n,
      d
    ]), m.useEffect(() => {
      d && v.current && (v.current.focus(), v.current.select());
    }, [
      d
    ]);
    const C = m.useCallback(() => {
      if (b.current) {
        b.current = false, f(false);
        return;
      }
      if (!S.current) return;
      const x = Number.parseFloat(g);
      !Number.isNaN(x) && i && i(x), f(false);
    }, [
      g,
      i
    ]), k = m.useCallback((x) => {
      var _a, _b2;
      x.key === "Enter" ? (x.preventDefault(), (_a = v.current) == null ? void 0 : _a.blur()) : x.key === "Escape" && (x.preventDefault(), x.stopPropagation(), b.current = true, p(n), (_b2 = v.current) == null ? void 0 : _b2.blur());
    }, [
      n
    ]);
    return y.jsxs("div", {
      className: "flex items-center justify-between gap-2 px-3 py-1",
      "data-field": l,
      children: [
        y.jsx("span", {
          className: Y("text-xs select-none", c ? o ? "text-white/30" : "text-black/30" : o ? "text-white/50" : "text-black/50"),
          children: l
        }),
        y.jsxs("div", {
          className: "flex items-center gap-1",
          children: [
            d && !c ? y.jsx("input", {
              ref: v,
              type: "text",
              value: g,
              onChange: (x) => p(x.target.value),
              onBlur: C,
              onKeyDown: k,
              onClick: (x) => x.stopPropagation(),
              className: Y("w-20 rounded border px-1.5 py-0.5 text-right font-mono text-xs outline-none", o ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90")
            }) : y.jsx("button", {
              type: "button",
              onClick: () => {
                !c && i && f(true);
              },
              onFocus: () => {
                !c && i && f(true);
              },
              className: Y("w-20 rounded border border-transparent px-1.5 py-0.5 text-right font-mono text-xs outline-none transition-colors", c ? o ? "text-white/30" : "text-black/30" : o ? "cursor-text text-white/90 hover:bg-white/5" : "cursor-text text-black/90 hover:bg-black/5"),
              tabIndex: c ? -1 : 0,
              children: n
            }),
            r && y.jsx("span", {
              className: Y("w-6 text-xs select-none", c ? o ? "text-white/20" : "text-black/20" : o ? "text-white/40" : "text-black/40"),
              children: r
            })
          ]
        })
      ]
    });
  }
  function O3({ label: l, value: n, isDark: r, onChange: o }) {
    const [i, c] = m.useState(false), [d, f] = m.useState(n), g = m.useRef(null), p = m.useRef(false), v = m.useRef(true);
    m.useEffect(() => (v.current = true, () => {
      v.current = false;
    }), []), m.useEffect(() => {
      i || f(n);
    }, [
      n,
      i
    ]), m.useEffect(() => {
      i && g.current && (g.current.focus(), g.current.select());
    }, [
      i
    ]);
    const b = m.useCallback(() => {
      if (p.current) {
        p.current = false, c(false);
        return;
      }
      if (!v.current) return;
      const C = d.trim();
      C && C !== n && o(C), c(false);
    }, [
      d,
      n,
      o
    ]), S = m.useCallback((C) => {
      var _a, _b2;
      C.key === "Enter" ? (C.preventDefault(), (_a = g.current) == null ? void 0 : _a.blur()) : C.key === "Escape" && (C.preventDefault(), C.stopPropagation(), p.current = true, f(n), (_b2 = g.current) == null ? void 0 : _b2.blur());
    }, [
      n
    ]);
    return y.jsxs("div", {
      className: "flex items-center justify-between gap-2 px-3 py-1",
      "data-field": l,
      children: [
        y.jsx("span", {
          className: Y("text-xs select-none", r ? "text-white/50" : "text-black/50"),
          children: l
        }),
        i ? y.jsx("input", {
          ref: g,
          type: "text",
          value: d,
          onChange: (C) => f(C.target.value),
          onBlur: b,
          onKeyDown: S,
          onClick: (C) => C.stopPropagation(),
          className: Y("w-32 rounded border px-1.5 py-0.5 text-right text-xs outline-none", r ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90")
        }) : y.jsx("button", {
          type: "button",
          onClick: () => c(true),
          onFocus: () => c(true),
          className: Y("w-32 truncate rounded border border-transparent px-1.5 py-0.5 text-right text-xs outline-none transition-colors", r ? "cursor-text text-white/90 hover:bg-white/5" : "cursor-text text-black/90 hover:bg-black/5"),
          tabIndex: 0,
          children: n
        })
      ]
    });
  }
  function I3({ label: l, value: n, isDark: r, onChange: o }) {
    const [i, c] = m.useState(false), [d, f] = m.useState(n), g = m.useRef(null), p = m.useRef(false), v = m.useRef(true);
    m.useEffect(() => (v.current = true, () => {
      v.current = false;
    }), []), m.useEffect(() => {
      i || f(n);
    }, [
      n,
      i
    ]), m.useEffect(() => {
      i && g.current && (g.current.focus(), g.current.select());
    }, [
      i
    ]);
    const b = m.useCallback(() => {
      if (p.current) {
        p.current = false, c(false);
        return;
      }
      if (!v.current) return;
      const x = d.trim();
      x && x !== n && o(x), c(false);
    }, [
      d,
      n,
      o
    ]), S = m.useCallback((x) => {
      var _a, _b2;
      x.key === "Enter" && !x.shiftKey ? (x.preventDefault(), (_a = g.current) == null ? void 0 : _a.blur()) : x.key === "Escape" && (x.preventDefault(), x.stopPropagation(), p.current = true, f(n), (_b2 = g.current) == null ? void 0 : _b2.blur());
    }, [
      n
    ]), C = n.split(`
`), k = C.length > 2 ? `${C.slice(0, 2).join(`
`)}...` : n;
    return y.jsxs("div", {
      className: "px-3 py-1",
      "data-field": l,
      children: [
        y.jsx("div", {
          className: "flex items-center justify-between gap-2 pb-1",
          children: y.jsx("span", {
            className: Y("text-xs select-none", r ? "text-white/50" : "text-black/50"),
            children: l
          })
        }),
        i ? y.jsx("textarea", {
          ref: g,
          value: d,
          onChange: (x) => f(x.target.value),
          onBlur: b,
          onKeyDown: S,
          onClick: (x) => x.stopPropagation(),
          rows: Math.min(6, Math.max(2, d.split(`
`).length)),
          className: Y("w-full resize-none rounded border px-1.5 py-1 font-mono text-xs leading-relaxed outline-none", r ? "border-white/10 bg-white/5 text-white/90" : "border-black/10 bg-black/5 text-black/90")
        }) : y.jsx("button", {
          type: "button",
          onClick: () => c(true),
          onFocus: () => c(true),
          className: Y("w-full whitespace-pre-wrap rounded border border-transparent px-1.5 py-1 text-left font-mono text-xs leading-relaxed outline-none transition-colors", r ? "cursor-text text-white/90 hover:bg-white/5" : "cursor-text text-black/90 hover:bg-black/5"),
          tabIndex: 0,
          children: k || y.jsx("span", {
            className: r ? "text-white/30" : "text-black/30",
            children: "Empty"
          })
        })
      ]
    });
  }
  function Nf({ currentLayer: l, currentDatatype: n, isDark: r, onChange: o }) {
    const i = ve((T) => T.getAllLayers)(), [c, d] = m.useState(`${l}:${n}`), [f, g] = m.useState(false), [p, v] = m.useState(-1);
    Pa("layer-selector", f);
    const b = m.useRef(null), S = m.useRef(null), C = `${l}:${n}`;
    m.useEffect(() => {
      d(C);
    }, [
      C
    ]);
    const k = i.find((T) => `${T.layerNumber}:${T.datatype}` === c), [x, E] = m.useState({
      top: 0,
      right: 0,
      width: 0
    }), _ = m.useCallback(() => {
      if (!b.current) return;
      const T = b.current.getBoundingClientRect();
      E({
        top: T.bottom + 4,
        right: window.innerWidth - T.right,
        width: Math.max(T.width, 160)
      });
      const L = i.findIndex((D) => `${D.layerNumber}:${D.datatype}` === c);
      v(L >= 0 ? L : 0), g(true);
    }, [
      i,
      c
    ]), N = m.useCallback(() => {
      var _a;
      g(false), (_a = b.current) == null ? void 0 : _a.focus();
    }, []), A = m.useCallback((T) => {
      d(`${T.layerNumber}:${T.datatype}`), o(T.layerNumber, T.datatype), N();
    }, [
      o,
      N
    ]);
    m.useEffect(() => {
      f && S.current && S.current.focus();
    }, [
      f
    ]), m.useEffect(() => {
      if (!f) return;
      const T = (L) => {
        var _a, _b2;
        ((_a = b.current) == null ? void 0 : _a.contains(L.target)) || ((_b2 = S.current) == null ? void 0 : _b2.contains(L.target)) || g(false);
      };
      return document.addEventListener("mousedown", T), () => document.removeEventListener("mousedown", T);
    }, [
      f
    ]);
    const R = m.useCallback((T) => {
      (T.key === "ArrowDown" || T.key === "ArrowUp" || T.key === "Enter" || T.key === " ") && (T.preventDefault(), _());
    }, [
      _
    ]), I = m.useCallback((T) => {
      switch (T.key) {
        case "ArrowDown":
          T.preventDefault(), T.stopPropagation(), v((L) => Math.min(L + 1, i.length - 1));
          break;
        case "ArrowUp":
          T.preventDefault(), T.stopPropagation(), v((L) => Math.max(L - 1, 0));
          break;
        case "Enter":
        case " ": {
          T.preventDefault(), T.stopPropagation();
          const L = i[p];
          L && A(L);
          break;
        }
        case "Escape":
        case "Tab":
          T.preventDefault(), T.stopPropagation(), N();
          break;
      }
    }, [
      i,
      p,
      A,
      N
    ]);
    return y.jsxs("div", {
      className: "flex items-center justify-between gap-2 px-3 py-1",
      children: [
        y.jsx("span", {
          className: Y("text-xs select-none", r ? "text-white/50" : "text-black/50"),
          children: "Layer"
        }),
        y.jsxs("button", {
          ref: b,
          type: "button",
          onClick: () => f ? N() : _(),
          onKeyDown: R,
          className: Y("flex max-w-36 items-center gap-1.5 rounded-lg border px-1.5 py-0.5 text-xs outline-none transition-colors", r ? "border-white/10 bg-white/5 text-white/90 hover:bg-white/10 focus-visible:border-white/40" : "border-black/10 bg-black/5 text-black/90 hover:bg-black/10 focus-visible:border-black/40"),
          children: [
            k && y.jsx("div", {
              className: Y("h-3 w-3 flex-shrink-0 rounded-sm border", r ? "border-white/10" : "border-black/10"),
              style: {
                backgroundColor: k.color
              }
            }),
            y.jsx("span", {
              className: "truncate",
              children: k ? k.name : `${l}/${n}`
            }),
            y.jsx("svg", {
              width: "12",
              height: "12",
              viewBox: "0 0 16 16",
              className: Y("flex-shrink-0 transition-transform", f && "rotate-180", r ? "text-white/40" : "text-black/40"),
              children: y.jsx("path", {
                d: "M4 6l4 4 4-4",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "1.5"
              })
            })
          ]
        }),
        f && fs.createPortal(y.jsx("div", {
          ref: S,
          role: "listbox",
          tabIndex: -1,
          onKeyDown: I,
          className: Y("fixed z-50 overflow-y-auto rounded-xl border py-1 shadow-lg outline-none", r ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
          style: {
            top: x.top,
            right: x.right,
            minWidth: x.width,
            maxHeight: 200
          },
          children: i.map((T, L) => {
            const H = `${T.layerNumber}:${T.datatype}` === c, q = L === p;
            return y.jsxs("div", {
              "data-layer-option": true,
              role: "option",
              "aria-selected": H,
              className: Y("mx-1 flex w-[calc(100%-8px)] cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors", q ? r ? "bg-[rgb(54,54,54)] text-white/90" : "bg-[rgb(217,217,217)] text-black/90" : r ? "text-white/70" : "text-black/70"),
              onMouseDown: (re) => {
                re.preventDefault(), A(T);
              },
              onMouseEnter: () => v(L),
              children: [
                y.jsx("div", {
                  className: Y("h-3.5 w-3.5 flex-shrink-0 rounded-sm border", r ? "border-white/10" : "border-black/10"),
                  style: {
                    backgroundColor: T.color
                  }
                }),
                y.jsx("span", {
                  className: "flex-1 truncate",
                  children: T.name
                }),
                y.jsxs("span", {
                  className: Y("flex-shrink-0 font-mono text-[11px]", r ? "text-white/40" : "text-black/40"),
                  children: [
                    T.layerNumber,
                    "/",
                    T.datatype
                  ]
                }),
                H && y.jsx("svg", {
                  width: "14",
                  height: "14",
                  viewBox: "0 0 16 16",
                  className: Y("flex-shrink-0", r ? "text-white/70" : "text-black/70"),
                  children: y.jsx("path", {
                    d: "M3.5 8.5l3 3 6-7",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                  })
                })
              ]
            }, T.id);
          })
        }), document.body)
      ]
    });
  }
  function zv({ sourceInfo: l, isDark: n }) {
    const [r, o] = m.useState(false), [i, c] = m.useState(l.code), d = m.useRef(null);
    m.useEffect(() => {
      c(l.code), o(false);
    }, [
      l.code,
      l.line
    ]);
    const f = m.useCallback(async () => {
      if (i.trim() === l.code.trim()) {
        o(false);
        return;
      }
      await NS({
        file: l.file,
        line: l.line,
        old_code: l.code,
        new_code: i
      }) && o(false);
    }, [
      i,
      l
    ]), g = l.file.split("/").pop() ?? l.file;
    return y.jsxs(y.Fragment, {
      children: [
        y.jsx("div", {
          className: Y("px-3 pt-2.5 pb-0.5 text-[10px] font-semibold uppercase tracking-wider select-none", n ? "text-white/30" : "text-black/30"),
          children: "Source"
        }),
        y.jsxs("div", {
          className: "flex items-center justify-between gap-2 px-3 py-0.5",
          children: [
            y.jsx("span", {
              className: Y("text-xs select-none", n ? "text-white/50" : "text-black/50"),
              children: "Location"
            }),
            y.jsxs("span", {
              className: Y("text-xs font-mono tabular-nums select-all", n ? "text-white/80" : "text-black/80"),
              title: `${l.file}:${l.line}`,
              children: [
                g,
                ":",
                l.line
              ]
            })
          ]
        }),
        l.fn && l.fn !== "<module>" && y.jsxs("div", {
          className: "flex items-center justify-between gap-2 px-3 py-0.5",
          children: [
            y.jsx("span", {
              className: Y("text-xs select-none", n ? "text-white/50" : "text-black/50"),
              children: "Function"
            }),
            y.jsxs("span", {
              className: Y("text-xs font-mono select-all", n ? "text-white/80" : "text-black/80"),
              children: [
                l.fn,
                "()"
              ]
            })
          ]
        }),
        y.jsx("div", {
          className: "px-3 py-1",
          children: r ? y.jsx("textarea", {
            ref: d,
            className: Y("w-full rounded px-1.5 py-1 text-[11px] font-mono leading-tight resize-none border", n ? "bg-white/5 text-white/90 border-white/10 focus:border-blue-400/50" : "bg-black/5 text-black/90 border-black/10 focus:border-blue-500/50"),
            value: i,
            rows: Math.min(i.split(`
`).length + 1, 5),
            onChange: (p) => c(p.target.value),
            onKeyDown: (p) => {
              p.key === "Enter" && (p.metaKey || p.ctrlKey) && (p.preventDefault(), f()), p.key === "Escape" && (c(l.code), o(false));
            },
            onBlur: f,
            autoFocus: true
          }) : y.jsx("button", {
            type: "button",
            className: Y("w-full rounded px-1.5 py-1 text-left text-[11px] font-mono leading-tight", "cursor-pointer transition-colors", n ? "bg-white/5 text-white/70 hover:bg-white/10" : "bg-black/5 text-black/70 hover:bg-black/10"),
            onClick: () => o(true),
            title: "Click to edit source (Cmd+Enter to save, Escape to cancel)",
            children: l.code
          })
        })
      ]
    });
  }
  function It({ label: l, isDark: n }) {
    return y.jsx("div", {
      className: Y("px-3 pt-2.5 pb-0.5 text-[10px] font-semibold uppercase tracking-wider select-none", n ? "text-white/30" : "text-black/30"),
      children: l
    });
  }
  function q1({ index: l, x: n, y: r, unit: o, isDark: i, canRemove: c, onChangeX: d, onChangeY: f, onRemove: g, readOnly: p }) {
    return y.jsxs("div", {
      "data-vertex-row": true,
      children: [
        y.jsxs("div", {
          className: "flex items-center justify-between px-3 pt-1.5 pb-0",
          children: [
            y.jsxs("span", {
              className: Y("text-[10px] font-mono select-none", i ? "text-white/30" : "text-black/30"),
              children: [
                "V",
                l
              ]
            }),
            !p && y.jsx("button", {
              type: "button",
              onClick: g,
              disabled: !c,
              className: Y("flex-shrink-0 rounded p-0.5 transition-colors", c ? i ? "text-white/40 hover:bg-white/10 hover:text-white/70" : "text-black/40 hover:bg-black/10 hover:text-black/70" : i ? "cursor-not-allowed text-white/10" : "cursor-not-allowed text-black/10"),
              tabIndex: c ? 0 : -1,
              children: y.jsx("svg", {
                width: "12",
                height: "12",
                viewBox: "0 0 16 16",
                fill: "none",
                stroke: "currentColor",
                children: y.jsx("path", {
                  d: "M4 8h8",
                  strokeWidth: "1.5",
                  strokeLinecap: "round"
                })
              })
            })
          ]
        }),
        y.jsx(dt, {
          label: "X",
          value: n,
          unit: o,
          isDark: i,
          onChange: d,
          readOnly: p
        }),
        y.jsx(dt, {
          label: "Y",
          value: r,
          unit: o,
          isDark: i,
          onChange: f,
          readOnly: p
        })
      ]
    });
  }
  function Hv({ vertices: l, unitInfo: n, isDark: r, onChangeVertex: o, onRemoveVertex: i, onAddVertex: c, readOnly: d, label: f }) {
    const g = l.length / 2, p = g > 3, v = m.useRef(null), [b, S] = m.useState(null);
    m.useEffect(() => {
      if (b === null) return;
      const x = b;
      let E, _ = 0;
      const N = 10, A = () => {
        const R = v.current;
        if (!R) {
          S(null);
          return;
        }
        const I = R.querySelectorAll("[data-vertex-row]");
        if (I.length <= x) {
          if (_++, _ >= N) {
            S(null);
            return;
          }
          E = requestAnimationFrame(A);
          return;
        }
        R.scrollTop = R.scrollHeight;
        const T = I[I.length - 1];
        if (T) {
          const L = T.querySelector("[data-field='X'] button");
          L && L.focus();
        }
        S(null);
      };
      return E = requestAnimationFrame(A), () => cancelAnimationFrame(E);
    }, [
      b
    ]);
    const C = m.useCallback(() => {
      c(), S(g);
    }, [
      c,
      g
    ]), k = [];
    for (let x = 0; x < g; x++) {
      const E = l[x * 2], _ = l[x * 2 + 1], N = nt(E / xe, n), A = nt(-_ / xe, n);
      k.push(y.jsx(q1, {
        index: x,
        x: N,
        y: A,
        unit: n.unit,
        isDark: r,
        canRemove: p,
        onChangeX: (R) => o(x, "x", R),
        onChangeY: (R) => o(x, "y", R),
        onRemove: () => i(x),
        readOnly: d
      }, x));
    }
    return y.jsxs(y.Fragment, {
      children: [
        y.jsx(It, {
          label: f ?? "Vertices",
          isDark: r
        }),
        y.jsx("div", {
          ref: v,
          className: "flex max-h-48 flex-col overflow-y-auto",
          children: k
        }),
        !d && y.jsx("div", {
          className: "px-3 pt-1",
          children: y.jsxs("button", {
            type: "button",
            onClick: C,
            className: Y("flex w-full items-center justify-center gap-1 rounded-lg border px-2 py-1 text-xs transition-colors", r ? "border-white/10 text-white/50 hover:bg-white/5 hover:text-white/70" : "border-black/10 text-black/50 hover:bg-black/5 hover:text-black/70"),
            children: [
              y.jsx("svg", {
                width: "12",
                height: "12",
                viewBox: "0 0 16 16",
                fill: "none",
                stroke: "currentColor",
                children: y.jsx("path", {
                  d: "M8 4v8M4 8h8",
                  strokeWidth: "1.5",
                  strokeLinecap: "round"
                })
              }),
              "Add vertex"
            ]
          })
        })
      ]
    });
  }
  function D3() {
    const l = se((i) => i.selectedIds), n = Se((i) => i.library), [r, o] = m.useState(0);
    return m.useEffect(() => {
      if (!n || l.size === 0) return;
      let i;
      const c = () => {
        n.is_dirty() && o((d) => d + 1), i = requestAnimationFrame(c);
      };
      return i = requestAnimationFrame(c), () => cancelAnimationFrame(i);
    }, [
      n,
      l
    ]), m.useMemo(() => {
      if (l.size === 0 || !n) return null;
      let i = null;
      const c = l.values().next().value;
      if (c.startsWith("ref:")) {
        const S = n.get_cell_ref_info(c);
        if (S) {
          const [C, k, x, E, _, N] = S.transform, A = n.get_cell_origin_by_name(S.cell_name), R = A ? A[0] : 0, I = A ? A[1] : 0, L = Math.atan2(x, C) * 180 / Math.PI, D = Math.sqrt(C * C + x * x), H = n.get_cell_ref_array(c);
          let q = null;
          H && H.length === 4 && (q = {
            columns: H[0],
            rows: H[1],
            colSpacing: H[2],
            rowSpacing: H[3]
          }), i = {
            cellName: S.cell_name,
            x: C * R + k * I + _,
            y: x * R + E * I + N,
            tx: _,
            ty: N,
            rotation: L,
            scale: D,
            transform: new Float64Array(S.transform),
            childOriginX: R,
            childOriginY: I,
            array: q,
            refId: c,
            ids: [
              ...l
            ]
          }, S.free();
        }
      }
      const d = [];
      for (const S of l) {
        const C = n.get_element_info(S);
        C && (d.push({
          id: S,
          layer: C.layer,
          datatype: C.datatype,
          vertexCount: C.vertices.length / 2,
          vertices: new Float64Array(C.vertices)
        }), C.free());
      }
      if (d.length === 0) return null;
      const f = n.get_bounds_for_ids([
        ...l
      ]), g = f ? {
        minX: f[0],
        minY: f[1],
        maxX: f[2],
        maxY: f[3]
      } : null, p = d[0].layer, v = d[0].datatype, b = d.some((S) => S.layer !== p || S.datatype !== v);
      return {
        elements: d,
        bounds: g,
        isMixed: b,
        instance: i
      };
    }, [
      l,
      n,
      r
    ]);
  }
  const z3 = {
    unit: "\xB5m",
    scale: 1e3
  };
  function H3() {
    var _a, _b2, _c, _d, _e;
    const n = me((U) => U.theme) === "dark", r = z3, o = D3(), i = Se((U) => U.library), c = Se((U) => U.renderer), d = ue((U) => U.activeCell);
    ce((U) => U.undoStack.length + U.redoStack.length);
    const f = rn((U) => U.pathMetadata), g = se((U) => U.selectedIds), p = Bt((U) => U.images), v = m.useMemo(() => {
      for (const U of g) if (Mn(U)) return Gr(U);
      return null;
    }, [
      g
    ]), b = v ? p.get(v) ?? null : null, S = i == null ? void 0 : i.get_cell_origin(), C = S ? {
      x: S[0],
      y: S[1]
    } : {
      x: 0,
      y: 0
    }, k = m.useRef(C);
    k.current = C;
    const x = m.useRef(void 0), E = m.useRef(void 0), _ = m.useCallback((U) => {
      if (!d || !i || !c || U === d) return;
      const te = new A0(d, U);
      ce.getState().execute(te, {
        library: i,
        renderer: c
      });
    }, [
      d,
      i,
      c
    ]), N = m.useCallback((U, te) => {
      if (!i || !c) return;
      const he = te * r.scale, be = U === "y" ? -he * xe : he * xe, we = k.current, je = new r2(we.x, we.y, U === "x" ? be : we.x, U === "y" ? be : we.y);
      ce.getState().execute(je, {
        library: i,
        renderer: c
      });
    }, [
      i,
      c,
      r
    ]), A = m.useCallback((U, te) => {
      if (!o || !i || !c) return;
      const he = o.elements.map((we) => we.id), be = new Ly(he, U, te);
      ce.getState().execute(be, {
        library: i,
        renderer: c
      }), o.elements.length === 1 && IS(o.elements[0].id, U, te);
    }, [
      o,
      i,
      c
    ]), R = m.useCallback((U) => {
      if (!i) return;
      let te = i.get_element_info(U);
      if (!te) {
        const he = se.getState().selectedIds;
        if (he.size === 1) {
          const be = he.values().next().value;
          be && (te = i.get_element_info(be));
        }
      }
      te && (Go(U, new Float64Array(te.vertices)), te.free());
    }, [
      i
    ]), I = m.useCallback((U, te) => {
      if (!(o == null ? void 0 : o.bounds) || !i || !c) return;
      const he = te * r.scale, be = U === "y" ? -he * xe : he * xe, we = o.elements.map((Xe) => Xe.id), je = new n2(we, o.bounds.minX, o.bounds.minY, U === "x" ? be : o.bounds.minX, U === "y" ? be - (o.bounds.maxY - o.bounds.minY) : o.bounds.minY);
      ce.getState().execute(je, {
        library: i,
        renderer: c
      }), o.elements.length === 1 && R(o.elements[0].id);
    }, [
      o,
      i,
      c,
      r,
      R
    ]), T = m.useCallback((U, te) => {
      if (!(o == null ? void 0 : o.bounds) || !i || !c) return;
      const be = te * r.scale * xe;
      if (be <= 0) return;
      const we = o.bounds.maxX - o.bounds.minX, je = o.bounds.maxY - o.bounds.minY, Xe = o.elements.map((Ce) => Ce.id), We = new t2(Xe, o.bounds, U === "width" ? be : we, U === "height" ? be : je);
      ce.getState().execute(We, {
        library: i,
        renderer: c
      }), o.elements.length === 1 && R(o.elements[0].id);
    }, [
      o,
      i,
      c,
      r,
      R
    ]), L = m.useCallback((U, te, he) => {
      if (!o || !i || !c) return;
      const be = o.elements[0];
      if (!be) return;
      const we = new Float64Array(be.vertices), je = he * r.scale, Xe = te === "y" ? -je * xe : je * xe;
      we[U * 2 + (te === "x" ? 0 : 1)] = Xe;
      const We = new Yd(be.id, we, "Edit vertex");
      ce.getState().execute(We, {
        library: i,
        renderer: c
      }), Go(be.id, we);
    }, [
      o,
      i,
      c,
      r
    ]), D = m.useCallback((U) => {
      if (!o || !i || !c) return;
      const te = o.elements[0];
      if (!te || te.vertexCount <= 3) return;
      const he = new Float64Array(te.vertices.length - 2);
      let be = 0;
      for (let je = 0; je < te.vertexCount; je++) je !== U && (he[be] = te.vertices[je * 2], he[be + 1] = te.vertices[je * 2 + 1], be += 2);
      const we = new Yd(te.id, he, "Remove vertex");
      ce.getState().execute(we, {
        library: i,
        renderer: c
      }), Go(te.id, he);
    }, [
      o,
      i,
      c
    ]), H = m.useCallback(() => {
      if (!o || !i || !c) return;
      const U = o.elements[0];
      if (!U) return;
      const te = U.vertexCount, he = U.vertices[(te - 1) * 2], be = U.vertices[(te - 1) * 2 + 1], we = U.vertices[0], je = U.vertices[1], Xe = (he + we) / 2, We = (be + je) / 2, Ce = new Float64Array(U.vertices.length + 2);
      Ce.set(U.vertices), Ce[U.vertices.length] = Xe, Ce[U.vertices.length + 1] = We;
      const Ne = new Yd(U.id, Ce, "Add vertex");
      ce.getState().execute(Ne, {
        library: i,
        renderer: c
      }), Go(U.id, Ce);
    }, [
      o,
      i,
      c
    ]), q = m.useRef(null);
    m.useEffect(() => {
      const U = q.current;
      if (!U) return;
      const te = (he) => {
        if (he.key !== "Escape" && he.key === "Tab") {
          he.stopPropagation(), he.preventDefault();
          const be = Array.from(U.querySelectorAll("input, textarea, button:not([tabindex='-1']):not([data-layer-option])"));
          if (be.length === 0) return;
          const we = be.indexOf(document.activeElement), je = he.shiftKey ? (we - 1 + be.length) % be.length : (we + 1) % be.length;
          be[je].focus();
        }
      };
      return U.addEventListener("keydown", te), () => U.removeEventListener("keydown", te);
    }, []);
    const re = me((U) => U.inspectorFocusRequested), ee = me((U) => U.inspectorFocusField);
    m.useEffect(() => {
      !re || !q.current || (me.getState().clearInspectorFocus(), requestAnimationFrame(() => {
        const U = q.current;
        if (!U) return;
        let te = null;
        if (ee) {
          const he = U.querySelector(`[data-field="${ee}"]`);
          he && (te = he.querySelector("button:not([tabindex='-1']), input, textarea"));
        }
        te || (te = U.querySelector("input, textarea, button:not([tabindex='-1']):not([data-layer-option])")), te && te.focus();
      }));
    }, [
      re,
      ee
    ]);
    const de = m.useMemo(() => !o || o.elements.length !== 1 ? null : yr(o.elements[0].id), [
      o
    ]), ge = m.useCallback((U) => {
      const te = x.current, he = E.current;
      if (!te || !he || !i || !c || !se.getState().selectedIds.has(he)) return;
      const be = U * r.scale * xe;
      if (be <= 0) return;
      const we = new Bo(he, te, {
        ...te,
        width: be
      }, "Change path width");
      ce.getState().execute(we, {
        library: i,
        renderer: c
      });
    }, [
      i,
      c,
      r
    ]), Ee = m.useCallback((U) => {
      const te = x.current, he = E.current;
      if (!te || !he || !i || !c || !se.getState().selectedIds.has(he)) return;
      const be = U * r.scale * xe;
      if (be < 0) return;
      const we = new Bo(he, te, {
        ...te,
        cornerRadius: be
      }, "Change path corner radius");
      ce.getState().execute(we, {
        library: i,
        renderer: c
      });
    }, [
      i,
      c,
      r
    ]), $ = m.useCallback((U, te, he) => {
      const be = x.current, we = E.current;
      if (!be || !we || !i || !c || !se.getState().selectedIds.has(we)) return;
      const je = he * r.scale, Xe = te === "y" ? -je * xe : je * xe, We = be.waypoints.map((Ne, Ae) => Ae !== U ? Ne : te === "x" ? {
        x: Xe,
        y: Ne.y
      } : {
        x: Ne.x,
        y: Xe
      }), Ce = new Bo(we, be, {
        ...be,
        waypoints: We
      }, "Edit path waypoint");
      ce.getState().execute(Ce, {
        library: i,
        renderer: c
      });
    }, [
      i,
      c,
      r
    ]), F = m.useCallback(() => {
      const U = x.current, te = E.current;
      if (!U || !te || !i || !c || !se.getState().selectedIds.has(te)) return;
      const he = U.waypoints, be = he[he.length - 1], we = he[he.length - 2];
      let je = be.x - we.x, Xe = be.y - we.y;
      je === 0 && Xe === 0 && (je = xe);
      const We = {
        x: be.x + je,
        y: be.y + Xe
      }, Ce = new Bo(te, U, {
        ...U,
        waypoints: [
          ...he,
          We
        ]
      }, "Add path waypoint");
      ce.getState().execute(Ce, {
        library: i,
        renderer: c
      });
    }, [
      i,
      c
    ]);
    if (!o && b) {
      const U = nt(b.x / xe, r), te = nt(-b.y / xe, r), he = nt(b.width / xe, r), be = nt(b.height / xe, r), we = b.lockAspectRatio, je = (Ce, Ne) => {
        if (!i || !c || !v) return;
        const Ae = Bt.getState().images.get(v);
        if (!Ae) return;
        const Ie = Ne * r.scale, $e = Ce === "y" ? -Ie * xe : Ie * xe, vt = new c2(v, Ae.x, Ae.y, Ce === "x" ? $e : Ae.x, Ce === "y" ? $e : Ae.y);
        ce.getState().execute(vt, {
          library: i,
          renderer: c
        });
      }, Xe = (Ce, Ne) => {
        if (!i || !c || !v) return;
        const Ae = Bt.getState().images.get(v);
        if (!Ae) return;
        const $e = Ne * r.scale * xe;
        if ($e <= 0) return;
        let vt, Ke;
        if (Ae.lockAspectRatio) {
          const un = Ae.naturalHeight / Ae.naturalWidth;
          Ce === "width" ? (vt = $e, Ke = $e * un) : (Ke = $e, vt = $e / un);
        } else vt = Ce === "width" ? $e : Ae.width, Ke = Ce === "height" ? $e : Ae.height;
        const an = new d2(v, Ae.width, Ae.height, vt, Ke);
        ce.getState().execute(an, {
          library: i,
          renderer: c
        });
      }, We = () => {
        v && Bt.getState().updateImage(v, {
          lockAspectRatio: !we
        });
      };
      return y.jsxs("div", {
        ref: q,
        className: "flex flex-col pb-2",
        onWheel: (Ce) => Ce.stopPropagation(),
        children: [
          y.jsx("div", {
            className: "px-3 pt-2 pb-1",
            children: y.jsx("span", {
              className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
              children: "Image"
            })
          }),
          y.jsx("div", {
            className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "File",
            isDark: n
          }),
          y.jsxs("div", {
            className: "flex items-center justify-between gap-2 px-3 py-1",
            children: [
              y.jsx("span", {
                className: Y("text-xs select-none", n ? "text-white/50" : "text-black/50"),
                children: "Name"
              }),
              y.jsx("span", {
                className: Y("max-w-32 truncate text-right text-xs", n ? "text-white/90" : "text-black/90"),
                title: b.filename,
                children: b.filename
              })
            ]
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Position",
            isDark: n
          }),
          y.jsx(dt, {
            label: "X",
            value: U,
            unit: r.unit,
            isDark: n,
            onChange: (Ce) => je("x", Ce)
          }),
          y.jsx(dt, {
            label: "Y",
            value: te,
            unit: r.unit,
            isDark: n,
            onChange: (Ce) => je("y", Ce)
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Size",
            isDark: n
          }),
          y.jsx(dt, {
            label: "W",
            value: he,
            unit: r.unit,
            isDark: n,
            onChange: (Ce) => Xe("width", Ce)
          }),
          y.jsx(dt, {
            label: "H",
            value: be,
            unit: r.unit,
            isDark: n,
            onChange: (Ce) => Xe("height", Ce)
          }),
          y.jsxs("div", {
            className: "flex items-center justify-between gap-2 px-3 py-1.5",
            children: [
              y.jsx("span", {
                className: Y("text-xs select-none", n ? "text-white/50" : "text-black/50"),
                children: "Lock ratio"
              }),
              y.jsxs("button", {
                type: "button",
                onClick: We,
                className: Y("flex items-center gap-1 rounded-lg border px-1.5 py-0.5 text-xs transition-colors", we ? n ? "border-white/20 bg-white/10 text-white/80" : "border-black/20 bg-black/10 text-black/80" : n ? "border-white/10 text-white/40 hover:text-white/60" : "border-black/10 text-black/40 hover:text-black/60"),
                children: [
                  y.jsx("svg", {
                    width: "12",
                    height: "12",
                    viewBox: "0 0 16 16",
                    fill: "none",
                    stroke: "currentColor",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    children: we ? y.jsxs(y.Fragment, {
                      children: [
                        y.jsx("rect", {
                          x: "3",
                          y: "7",
                          width: "10",
                          height: "7",
                          rx: "1"
                        }),
                        y.jsx("path", {
                          d: "M5 7V5a3 3 0 0 1 6 0v2"
                        })
                      ]
                    }) : y.jsxs(y.Fragment, {
                      children: [
                        y.jsx("rect", {
                          x: "3",
                          y: "7",
                          width: "10",
                          height: "7",
                          rx: "1"
                        }),
                        y.jsx("path", {
                          d: "M5 7V5a3 3 0 0 1 6 0"
                        })
                      ]
                    })
                  }),
                  we ? "On" : "Off"
                ]
              })
            ]
          })
        ]
      });
    }
    if (!o) {
      const U = nt(C.x / xe, r), te = nt(-C.y / xe, r);
      return y.jsxs("div", {
        ref: q,
        className: "flex flex-col pb-2",
        onWheel: (he) => he.stopPropagation(),
        children: [
          y.jsx("div", {
            className: "px-3 pt-2 pb-1",
            children: y.jsx("span", {
              className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
              children: "Cell"
            })
          }),
          y.jsx("div", {
            className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Name",
            isDark: n
          }),
          d ? y.jsx(O3, {
            label: "Name",
            value: d,
            isDark: n,
            onChange: _
          }) : y.jsx("div", {
            className: "px-3 py-1",
            children: y.jsx("span", {
              className: Y("text-xs italic select-none", n ? "text-white/40" : "text-black/40"),
              children: "No cell"
            })
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Origin",
            isDark: n
          }),
          y.jsx(dt, {
            label: "X",
            value: U,
            unit: r.unit,
            isDark: n,
            onChange: (he) => N("x", he)
          }),
          y.jsx(dt, {
            label: "Y",
            value: te,
            unit: r.unit,
            isDark: n,
            onChange: (he) => N("y", he)
          })
        ]
      });
    }
    const { elements: fe, bounds: ye, isMixed: ke } = o, j = fe.length === 1, O = fe[0], K = fe.every((U) => U.id.startsWith("ref:")) || i != null && i.get_group_ids(O.id).length > 1 || ((_a = yr(O.id)) == null ? void 0 : _a.type) === "ref";
    if (j && i && i.is_text_element(O.id)) {
      const U = i.get_text_element_info(O.id);
      if (U) {
        const te = nt(U.x / xe, r), he = nt(-U.y / xe, r), be = nt(U.height / xe, r), we = (Ce, Ne) => {
          if (!c) return;
          const Ae = Ne * r.scale, Ie = Ce === "y" ? -Ae * xe : Ae * xe, $e = new o2(O.id, U.x, U.y, Ce === "x" ? Ie : U.x, Ce === "y" ? Ie : U.y);
          ce.getState().execute($e, {
            library: i,
            renderer: c
          });
        }, je = (Ce) => {
          if (!c || Ce === U.text) return;
          const Ne = new a2(O.id, U.text, Ce);
          ce.getState().execute(Ne, {
            library: i,
            renderer: c
          }), Se.getState().bumpSyncGeneration();
        }, Xe = (Ce) => {
          if (!c) return;
          const Ae = Ce * r.scale * xe;
          if (Ae <= 0) return;
          const Ie = new s2(O.id, U.height, Ae);
          ce.getState().execute(Ie, {
            library: i,
            renderer: c
          }), Se.getState().bumpSyncGeneration();
        }, We = (Ce, Ne) => {
          if (!c) return;
          const Ae = new Ly([
            O.id
          ], Ce, Ne);
          ce.getState().execute(Ae, {
            library: i,
            renderer: c
          }), Se.getState().bumpSyncGeneration();
        };
        return y.jsxs("div", {
          ref: q,
          className: "flex flex-col pb-2",
          onWheel: (Ce) => Ce.stopPropagation(),
          children: [
            y.jsx("div", {
              className: "px-3 pt-2 pb-1",
              children: y.jsx("span", {
                className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
                children: "Text"
              })
            }),
            y.jsx("div", {
              className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx(It, {
              label: "Layer",
              isDark: n
            }),
            y.jsx(Nf, {
              currentLayer: U.layer,
              currentDatatype: U.datatype,
              isDark: n,
              onChange: We
            }),
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx(It, {
              label: "Content",
              isDark: n
            }),
            y.jsx(I3, {
              label: "Text",
              value: U.text,
              isDark: n,
              onChange: je
            }),
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx(It, {
              label: "Position",
              isDark: n
            }),
            y.jsx(dt, {
              label: "X",
              value: te,
              unit: r.unit,
              isDark: n,
              onChange: (Ce) => we("x", Ce)
            }),
            y.jsx(dt, {
              label: "Y",
              value: he,
              unit: r.unit,
              isDark: n,
              onChange: (Ce) => we("y", Ce)
            }),
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx(It, {
              label: "Size",
              isDark: n
            }),
            y.jsx(dt, {
              label: "Size",
              value: be,
              unit: r.unit,
              isDark: n,
              onChange: Xe
            }),
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx("div", {
              className: "px-3 pt-2",
              children: y.jsx("button", {
                type: "button",
                onClick: () => {
                  if (!c) return;
                  const Ce = new H0([
                    O.id
                  ]);
                  ce.getState().execute(Ce, {
                    library: i,
                    renderer: c
                  });
                },
                className: Y("flex w-full items-center justify-center gap-1.5 rounded-lg border px-2 py-1.5 text-xs transition-colors", n ? "border-white/10 text-white/60 hover:bg-white/5 hover:text-white/80" : "border-black/10 text-black/60 hover:bg-black/5 hover:text-black/80"),
                children: "Convert to Polygons"
              })
            })
          ]
        });
      }
    }
    const W = j && O ? f.get(O.id) : void 0;
    if (x.current = W, E.current = O == null ? void 0 : O.id, W && j) {
      const U = nt(W.width / xe, r), te = nt(W.cornerRadius / xe, r), he = ye ? nt(ye.minX / xe, r) : "\u2014", be = ye ? nt(-ye.maxY / xe, r) : "\u2014", we = W.waypoints.map((je, Xe) => {
        const We = nt(je.x / xe, r), Ce = nt(-je.y / xe, r);
        return y.jsx(q1, {
          index: Xe,
          x: We,
          y: Ce,
          unit: r.unit,
          isDark: n,
          canRemove: W.waypoints.length > 2,
          onChangeX: (Ne) => $(Xe, "x", Ne),
          onChangeY: (Ne) => $(Xe, "y", Ne),
          onRemove: () => {
            if (W.waypoints.length <= 2) return;
            const Ne = x.current, Ae = E.current;
            if (!Ne || !Ae || !i || !c) return;
            const Ie = Ne.waypoints.filter((vt, Ke) => Ke !== Xe), $e = new Bo(Ae, Ne, {
              ...Ne,
              waypoints: Ie
            }, "Remove path waypoint");
            ce.getState().execute($e, {
              library: i,
              renderer: c
            });
          }
        }, Xe);
      });
      return y.jsxs("div", {
        ref: q,
        className: "flex flex-col pb-2",
        onWheel: (je) => je.stopPropagation(),
        children: [
          y.jsx("div", {
            className: "px-3 pt-2 pb-1",
            children: y.jsxs("span", {
              className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
              children: [
                "Path \xB7 ",
                W.waypoints.length,
                " waypoints"
              ]
            })
          }),
          y.jsx("div", {
            className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Layer",
            isDark: n
          }),
          y.jsx(Nf, {
            currentLayer: O.layer,
            currentDatatype: O.datatype,
            isDark: n,
            onChange: A
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Path",
            isDark: n
          }),
          y.jsx(dt, {
            label: "Width",
            value: U,
            unit: r.unit,
            isDark: n,
            onChange: ge
          }),
          y.jsx(dt, {
            label: "Radius",
            value: te,
            unit: r.unit,
            isDark: n,
            onChange: Ee
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Position",
            isDark: n
          }),
          y.jsx(dt, {
            label: "X",
            value: he,
            unit: r.unit,
            isDark: n,
            onChange: (je) => I("x", je)
          }),
          y.jsx(dt, {
            label: "Y",
            value: be,
            unit: r.unit,
            isDark: n,
            onChange: (je) => I("y", je)
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Waypoints",
            isDark: n
          }),
          y.jsx("div", {
            className: "flex max-h-48 flex-col overflow-y-auto",
            children: we
          }),
          y.jsx("div", {
            className: "px-3 pt-1",
            children: y.jsxs("button", {
              type: "button",
              onClick: F,
              className: Y("flex w-full items-center justify-center gap-1 rounded-lg border px-2 py-1 text-xs transition-colors", n ? "border-white/10 text-white/50 hover:bg-white/5 hover:text-white/70" : "border-black/10 text-black/50 hover:bg-black/5 hover:text-black/70"),
              children: [
                y.jsx("svg", {
                  width: "12",
                  height: "12",
                  viewBox: "0 0 16 16",
                  fill: "none",
                  stroke: "currentColor",
                  children: y.jsx("path", {
                    d: "M8 4v8M4 8h8",
                    strokeWidth: "1.5",
                    strokeLinecap: "round"
                  })
                }),
                "Add waypoint"
              ]
            })
          })
        ]
      });
    }
    if (o.instance) {
      const U = o.instance, te = nt(U.tx / xe, r), he = nt(-U.ty / xe, r), be = ye ? nt((ye.maxX - ye.minX) / xe, r) : "\u2014", we = ye ? nt((ye.maxY - ye.minY) / xe, r) : "\u2014", je = Number.isFinite(U.rotation) ? U.rotation.toFixed(3) : "0.000", Xe = Number.isFinite(U.scale) ? U.scale.toFixed(3) : "1.000", We = ((_b2 = U.array) == null ? void 0 : _b2.columns) ?? 1, Ce = ((_c = U.array) == null ? void 0 : _c.rows) ?? 1, Ne = ((_d = U.array) == null ? void 0 : _d.colSpacing) ?? 0, Ae = ((_e = U.array) == null ? void 0 : _e.rowSpacing) ?? 0, Ie = We > 1 || Ce > 1, $e = nt(Ne / xe, r), vt = nt(Ae / xe, r), Ke = U.transform[0] * U.transform[3] - U.transform[1] * U.transform[2] < 0, an = (lt, Mt, on, en) => {
        const xt = lt * Math.PI / 180, Vt = Math.cos(xt), jt = Math.sin(xt), Sr = Mt * Vt, Hl = Ke ? Mt * jt : -Mt * jt, Qr = Mt * jt, fl = Ke ? -Mt * Vt : Mt * Vt;
        return new Float64Array([
          Sr,
          Hl,
          Qr,
          fl,
          on,
          en
        ]);
      }, un = (lt, Mt) => {
        if (!i || !c) return;
        const on = Mt * r.scale, en = lt === "y" ? -on * xe : on * xe, xt = new Float64Array(U.transform);
        lt === "x" ? xt[4] = en : xt[5] = en;
        const Vt = new Bd(U.refId, U.transform, xt, "Move instance");
        ce.getState().execute(Vt, {
          library: i,
          renderer: c
        });
      }, Wn = (lt) => {
        if (!i || !c) return;
        const Mt = an(lt, U.scale, U.tx, U.ty), on = new Bd(U.refId, U.transform, Mt, "Rotate instance");
        ce.getState().execute(on, {
          library: i,
          renderer: c
        });
      }, Dl = (lt) => {
        if (!i || !c || lt <= 0) return;
        const Mt = an(U.rotation, lt, U.tx, U.ty), on = new Bd(U.refId, U.transform, Mt, "Scale instance");
        ce.getState().execute(on, {
          library: i,
          renderer: c
        });
      }, zl = (lt, Mt) => {
        if (!i || !c) return;
        const on = U.array;
        let en = We, xt = Ce, Vt = Ne, jt = Ae;
        switch (lt) {
          case "columns":
            en = Math.max(1, Math.round(Mt));
            break;
          case "rows":
            xt = Math.max(1, Math.round(Mt));
            break;
          case "colSpacing":
            Vt = Mt * r.scale * xe;
            break;
          case "rowSpacing":
            jt = Mt * r.scale * xe;
            break;
        }
        const Sr = {
          columns: en,
          rows: xt,
          colSpacing: Vt,
          rowSpacing: jt
        }, Hl = new l2(U.refId, on, Sr);
        ce.getState().execute(Hl, {
          library: i,
          renderer: c
        });
      };
      return y.jsxs("div", {
        ref: q,
        className: "flex flex-col pb-2",
        onWheel: (lt) => lt.stopPropagation(),
        children: [
          y.jsx("div", {
            className: "px-3 pt-2 pb-1",
            children: y.jsxs("span", {
              className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
              children: [
                "Instance \xB7 ",
                U.cellName
              ]
            })
          }),
          y.jsx("div", {
            className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Position",
            isDark: n
          }),
          y.jsx(dt, {
            label: "X",
            value: te,
            unit: r.unit,
            isDark: n,
            onChange: (lt) => un("x", lt)
          }),
          y.jsx(dt, {
            label: "Y",
            value: he,
            unit: r.unit,
            isDark: n,
            onChange: (lt) => un("y", lt)
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Transform",
            isDark: n
          }),
          y.jsx(dt, {
            label: "Rotation",
            value: je,
            unit: "\xB0",
            isDark: n,
            onChange: Wn
          }),
          y.jsx(dt, {
            label: "Scale",
            value: Xe,
            isDark: n,
            onChange: Dl
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Array",
            isDark: n
          }),
          y.jsx(dt, {
            label: "Columns",
            value: String(We),
            isDark: n,
            onChange: (lt) => zl("columns", lt)
          }),
          y.jsx(dt, {
            label: "Rows",
            value: String(Ce),
            isDark: n,
            onChange: (lt) => zl("rows", lt)
          }),
          Ie && y.jsxs(y.Fragment, {
            children: [
              y.jsx(dt, {
                label: "Col gap",
                value: $e,
                unit: r.unit,
                isDark: n,
                onChange: (lt) => zl("colSpacing", lt)
              }),
              y.jsx(dt, {
                label: "Row gap",
                value: vt,
                unit: r.unit,
                isDark: n,
                onChange: (lt) => zl("rowSpacing", lt)
              })
            ]
          }),
          y.jsx("div", {
            className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
          }),
          y.jsx(It, {
            label: "Size",
            isDark: n
          }),
          y.jsx(dt, {
            label: "W",
            value: be,
            unit: r.unit,
            isDark: n,
            readOnly: true
          }),
          y.jsx(dt, {
            label: "H",
            value: we,
            unit: r.unit,
            isDark: n,
            readOnly: true
          }),
          de && y.jsxs(y.Fragment, {
            children: [
              y.jsx("div", {
                className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
              }),
              y.jsx(zv, {
                sourceInfo: de,
                isDark: n
              })
            ]
          })
        ]
      });
    }
    const J = ye ? nt(ye.minX / xe, r) : "\u2014", ie = ye ? nt(-ye.maxY / xe, r) : "\u2014", pe = ye ? nt((ye.maxX - ye.minX) / xe, r) : "\u2014", Re = ye ? nt((ye.maxY - ye.minY) / xe, r) : "\u2014", X = K || j;
    return y.jsxs("div", {
      ref: q,
      className: "flex flex-col pb-2",
      onWheel: (U) => U.stopPropagation(),
      children: [
        y.jsx("div", {
          className: "px-3 pt-2 pb-1",
          children: y.jsx("span", {
            className: Y("text-xs font-medium select-none", n ? "text-white/70" : "text-black/70"),
            children: j ? `Polygon \xB7 ${O.vertexCount} vertices` : `${fe.length} elements`
          })
        }),
        y.jsx("div", {
          className: Y("mx-3 h-px", n ? "bg-white/5" : "bg-black/5")
        }),
        !K && y.jsxs(y.Fragment, {
          children: [
            y.jsx(It, {
              label: "Layer",
              isDark: n
            }),
            ke ? y.jsxs("div", {
              className: "flex items-center justify-between gap-2 px-3 py-1",
              children: [
                y.jsx("span", {
                  className: Y("text-xs select-none", n ? "text-white/50" : "text-black/50"),
                  children: "Layer"
                }),
                y.jsx("span", {
                  className: Y("text-xs italic select-none", n ? "text-white/40" : "text-black/40"),
                  children: "Mixed"
                })
              ]
            }) : y.jsx(Nf, {
              currentLayer: O.layer,
              currentDatatype: O.datatype,
              isDark: n,
              onChange: A
            }),
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            })
          ]
        }),
        y.jsx(It, {
          label: "Position",
          isDark: n
        }),
        y.jsx(dt, {
          label: "X",
          value: J,
          unit: r.unit,
          isDark: n,
          onChange: X ? (U) => I("x", U) : void 0,
          readOnly: !X
        }),
        y.jsx(dt, {
          label: "Y",
          value: ie,
          unit: r.unit,
          isDark: n,
          onChange: X ? (U) => I("y", U) : void 0,
          readOnly: !X
        }),
        y.jsx("div", {
          className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
        }),
        y.jsx(It, {
          label: "Size",
          isDark: n
        }),
        y.jsx(dt, {
          label: "W",
          value: pe,
          unit: r.unit,
          isDark: n,
          onChange: j && !K ? (U) => T("width", U) : void 0,
          readOnly: !j || K
        }),
        y.jsx(dt, {
          label: "H",
          value: Re,
          unit: r.unit,
          isDark: n,
          onChange: j && !K ? (U) => T("height", U) : void 0,
          readOnly: !j || K
        }),
        (j || K) && y.jsxs(y.Fragment, {
          children: [
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            K && !j ? fe.map((U, te) => y.jsx(Hv, {
              vertices: U.vertices,
              unitInfo: r,
              isDark: n,
              onChangeVertex: L,
              onRemoveVertex: D,
              onAddVertex: H,
              readOnly: true,
              label: fe.length > 1 ? `Vertices (${te + 1}/${fe.length})` : void 0
            }, U.id)) : y.jsx(Hv, {
              vertices: O.vertices,
              unitInfo: r,
              isDark: n,
              onChangeVertex: L,
              onRemoveVertex: D,
              onAddVertex: H,
              readOnly: K
            })
          ]
        }),
        de && y.jsxs(y.Fragment, {
          children: [
            y.jsx("div", {
              className: Y("mx-3 mt-1 h-px", n ? "bg-white/5" : "bg-black/5")
            }),
            y.jsx(zv, {
              sourceInfo: de,
              isDark: n
            })
          ]
        })
      ]
    });
  }
  const G1 = [
    {
      id: "layers",
      icon: P4,
      label: "Layers",
      shortcut: "L"
    },
    {
      id: "inspector",
      icon: d4,
      label: "Inspector",
      shortcut: "I"
    }
  ];
  function U3({ isDark: l, onExpand: n }) {
    return y.jsx("div", {
      className: Y("fixed top-4 right-4 z-40 flex w-[38px] flex-col items-center gap-1 rounded-xl border py-1", l ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
      children: G1.map((r) => {
        const o = r.icon;
        return y.jsx(Vn, {
          label: r.label,
          shortcut: {
            modifiers: [
              He.shift
            ],
            key: r.shortcut
          },
          position: "left",
          children: y.jsx("button", {
            onClick: () => n(r.id),
            className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
            children: y.jsx("div", {
              className: "flex h-4 w-4 items-center justify-center",
              children: y.jsx(o, {
                className: Y("h-4 w-4", l ? "text-white/60" : "text-black/60")
              })
            })
          })
        }, r.id);
      })
    });
  }
  function Uv() {
    const n = me((N) => N.theme) === "dark", r = me((N) => N.sidebarCollapsed), o = me((N) => N.toggleSidebarCollapsed), i = me((N) => N.sidebarWidth), c = me((N) => N.setSidebarWidth), { isSm: d } = xh(), { handleProps: f } = U1({
      side: "right",
      width: i,
      onResize: c
    }), g = me((N) => N.sidebarTab), p = me((N) => N.setSidebarTab), v = as((N) => N.isMinimized), [b, S] = m.useState(false), C = m.useRef(null);
    m.useEffect(() => {
      if (!d || !b) return;
      const N = (A) => {
        C.current && !C.current.contains(A.target) && S(false);
      };
      return document.addEventListener("mousedown", N), () => document.removeEventListener("mousedown", N);
    }, [
      d,
      b
    ]);
    const k = m.useCallback((N) => {
      p(N), d ? S(true) : o();
    }, [
      d,
      o,
      p
    ]), E = (v ? 0 : 206) + 24;
    if (r && !(d && b)) return y.jsx(U3, {
      isDark: n,
      onExpand: k
    });
    const _ = d && b;
    return y.jsxs(y.Fragment, {
      children: [
        _ && y.jsx("div", {
          className: "fixed inset-0 z-39"
        }),
        y.jsxs("div", {
          ref: C,
          className: Y("fixed top-4 right-4 z-40 rounded-xl border", n ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]", _ && "shadow-xl"),
          style: {
            width: i
          },
          children: [
            y.jsx("div", {
              ...f
            }),
            y.jsxs("div", {
              className: "flex items-center gap-1 px-1 pt-1 pb-[3px]",
              children: [
                G1.map((N) => {
                  const A = N.icon, R = g === N.id;
                  return y.jsx(Vn, {
                    label: N.label,
                    shortcut: {
                      modifiers: [
                        He.shift
                      ],
                      key: N.shortcut
                    },
                    children: y.jsx("button", {
                      onClick: () => p(N.id),
                      className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", n ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", R && (n ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
                      children: y.jsx("div", {
                        className: "flex h-4 w-4 items-center justify-center",
                        children: y.jsx(A, {
                          className: Y("h-4 w-4", n ? "text-white/90" : "text-black/90")
                        })
                      })
                    })
                  }, N.id);
                }),
                !d && y.jsx("button", {
                  type: "button",
                  onClick: o,
                  className: Y("ml-auto cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", n ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
                  children: y.jsx(O1, {
                    className: Y("h-4 w-4", n ? "text-white/60" : "text-black/60")
                  })
                })
              ]
            }),
            y.jsx("div", {
              className: Y("h-px", n ? "bg-white/10" : "bg-black/10")
            }),
            y.jsxs("div", {
              className: "overflow-y-auto",
              style: {
                maxHeight: `calc(100vh - ${70 + E}px)`
              },
              onWheel: (N) => N.stopPropagation(),
              children: [
                g === "layers" && y.jsx(N3, {}),
                g === "inspector" && y.jsx(H3, {})
              ]
            })
          ]
        })
      ]
    });
  }
  const Y3 = (l) => {
    const n = 1 / (l * xe), r = Jv * n, o = hh(l), i = r / o.scale, c = SS.find((f) => f >= i) ?? i, d = o.unit === "mm" && c >= 1e3 ? c.toExponential(1) : c;
    return {
      length: c * o.scale,
      label: `${d} ${o.unit}`
    };
  }, Yv = "0.1.7";
  function B3({ isDark: l }) {
    return y.jsxs("div", {
      className: "group relative flex items-center gap-1.5",
      children: [
        y.jsx("div", {
          className: "h-1.5 w-1.5 flex-shrink-0 rounded-full bg-yellow-500"
        }),
        y.jsxs("span", {
          className: Y("text-[10px] select-none", l ? "text-white/40" : "text-black/40"),
          children: [
            "v",
            Yv
          ]
        }),
        y.jsxs("div", {
          className: Y("pointer-events-none absolute bottom-full left-0 z-50 mb-2 w-56 rounded-lg border p-2.5 text-[11px] leading-relaxed opacity-0 transition-opacity group-hover:opacity-100", l ? "border-white/10 bg-[rgb(29,29,29)] text-white/70" : "border-black/10 bg-[rgb(241,241,241)] text-black/70"),
          children: [
            y.jsxs("span", {
              className: Y("font-medium", l ? "text-white/90" : "text-black/90"),
              children: [
                "Rosette v",
                Yv,
                " Beta"
              ]
            }),
            y.jsx("p", {
              className: "mt-1.5",
              children: "Features may be unstable or incomplete. Not suitable for production use."
            })
          ]
        })
      ]
    });
  }
  function X3({ isDark: l }) {
    const n = Xt((o) => o.message), r = Xt((o) => o.level);
    return n ? y.jsx("div", {
      className: "flex min-w-0 flex-1 items-center justify-center",
      children: y.jsx("span", {
        className: Y("truncate text-[11px] select-none", r === "warn" && (l ? "text-yellow-400/80" : "text-yellow-600/80"), r === "error" && (l ? "text-red-400/80" : "text-red-600/80"), r === "info" && (l ? "text-white/50" : "text-black/50")),
        children: n
      })
    }) : y.jsx("div", {
      className: "flex-1"
    });
  }
  function V3({ isDark: l }) {
    const n = se((g) => g.selectedIds), r = Se((g) => g.library), o = ve((g) => g.layers), i = rn((g) => g.pathMetadata), c = m.useMemo(() => {
      const g = n.size;
      if (g === 0 || !r) return null;
      const p = n.values().next().value, v = p.startsWith("ref:");
      if (g === 1 && v) {
        const x = r.get_cell_ref_info(p);
        if (x) {
          const E = x.cell_name;
          return x.free(), {
            label: `Instance "${E}"`,
            layerNumber: null,
            datatype: null
          };
        }
      }
      if (g === 1 && r.is_text_element(p)) {
        const x = r.get_text_element_info(p);
        if (x) return {
          label: `Text "${x.text.length > 20 ? x.text.slice(0, 20) + "\u2026" : x.text}"`,
          layerNumber: x.layer,
          datatype: x.datatype
        };
      }
      if (g === 1) {
        const x = i.get(p);
        if (x) return {
          label: `Path \xB7 ${x.waypoints.length} waypoints`,
          layerNumber: x.layer,
          datatype: x.datatype
        };
      }
      let b = null, S = null, C = false, k = 0;
      for (const x of n) {
        const E = r.get_element_info(x);
        if (E && (b === null ? (b = E.layer, S = E.datatype) : (E.layer !== b || E.datatype !== S) && (C = true), g === 1 && (k = E.vertices.length / 2), E.free(), C && g > 1)) break;
      }
      return g === 1 ? {
        label: `Polygon \xB7 ${k} vertices`,
        layerNumber: b,
        datatype: S
      } : C ? {
        label: `${g} elements \xB7 Mixed layers`,
        layerNumber: null,
        datatype: null
      } : {
        label: `${g} elements`,
        layerNumber: b,
        datatype: S
      };
    }, [
      n,
      r,
      i
    ]);
    if (!c) return null;
    const d = m.useMemo(() => {
      if (c.layerNumber === null) return null;
      for (const g of o.values()) if (g.layerNumber === c.layerNumber && g.datatype === c.datatype) return {
        name: g.name,
        color: g.color
      };
      return null;
    }, [
      c,
      o
    ]), f = c.layerNumber !== null ? ` \xB7 ${(d == null ? void 0 : d.name) ? `${c.layerNumber}/${c.datatype} ${d.name}` : `${c.layerNumber}/${c.datatype}`}` : "";
    return y.jsxs("div", {
      className: "flex min-w-0 flex-1 items-center justify-center gap-1.5",
      children: [
        d && y.jsx("div", {
          className: "h-2 w-2 flex-shrink-0 rounded-full -translate-y-px",
          style: {
            backgroundColor: d.color
          }
        }),
        y.jsxs("span", {
          className: Y("truncate text-[11px] select-none", l ? "text-white/50" : "text-black/50"),
          children: [
            c.label,
            f
          ]
        })
      ]
    });
  }
  function $3({ isDark: l }) {
    const n = Xt((o) => o.message), r = se((o) => o.selectedIds.size > 0);
    return n ? y.jsx(X3, {
      isDark: l
    }) : r ? y.jsx(V3, {
      isDark: l
    }) : y.jsx("div", {
      className: "flex-1"
    });
  }
  function Bv({ isDark: l, widthInPixels: n, label: r }) {
    return y.jsxs("div", {
      className: "flex items-center gap-1.5",
      children: [
        y.jsx("div", {
          className: Y("h-px", l ? "bg-white/50" : "bg-black/50"),
          style: {
            width: `${Math.max(n, 20)}px`
          }
        }),
        y.jsx(Vn, {
          label: "Zoom to Fit",
          position: "top",
          children: y.jsx("button", {
            onClick: ds,
            className: Y("flex cursor-pointer items-center justify-center rounded p-0.5 text-[10px] select-none transition-colors focus:outline-none", l ? "text-white/40 hover:text-white/70" : "text-black/40 hover:text-black/70"),
            children: r
          })
        })
      ]
    });
  }
  function Xv({ compact: l = false, minimal: n = false }) {
    const r = me((N) => {
      var _a;
      return (_a = N.cursorWorld) == null ? void 0 : _a.x;
    }), o = me((N) => {
      var _a;
      return (_a = N.cursorWorld) == null ? void 0 : _a.y;
    }), i = me((N) => N.theme), c = Ve((N) => N.zoom), d = me((N) => N.zenMode), f = me((N) => N.toggleZenMode), g = as((N) => N.isMinimized), p = as((N) => N.toggle), v = i === "dark", b = m.useMemo(() => hh(c), [
      c
    ]), S = m.useMemo(() => r !== void 0 ? nt(r, b) : "\u2014", [
      r,
      b
    ]), C = m.useMemo(() => o !== void 0 ? nt(o, b) : "\u2014", [
      o,
      b
    ]), { length: k, label: x } = m.useMemo(() => Y3(c), [
      c
    ]), E = Math.min(k * c * xe, wS), _ = !l && !n;
    return y.jsxs("div", {
      className: "relative flex-shrink-0",
      children: [
        !_ && y.jsx("div", {
          className: "absolute bottom-full right-3 mb-2 font-mono text-[11px]",
          children: y.jsx(Bv, {
            isDark: v,
            widthInPixels: E,
            label: x
          })
        }),
        y.jsxs("div", {
          className: Y("flex h-6 items-center border-t px-3 font-mono text-[11px]", v ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
          children: [
            y.jsxs("div", {
              className: "flex min-w-0 flex-shrink-0 items-center gap-1.5",
              children: [
                !l && !n && y.jsxs(y.Fragment, {
                  children: [
                    y.jsx(B3, {
                      isDark: v
                    }),
                    y.jsx("span", {
                      className: Y("mx-1 select-none pointer-events-none", v ? "text-white/20" : "text-black/20"),
                      children: "\xB7"
                    })
                  ]
                }),
                n ? y.jsxs("span", {
                  className: Y("text-[10px] select-none pointer-events-none", v ? "text-white/70" : "text-black/70"),
                  children: [
                    S,
                    ", ",
                    C,
                    " ",
                    b.unit
                  ]
                }) : y.jsxs(y.Fragment, {
                  children: [
                    y.jsx("span", {
                      className: Y("leading-none select-none pointer-events-none", v ? "text-white/40" : "text-black/40"),
                      children: "x:"
                    }),
                    y.jsx("span", {
                      className: Y("w-18 text-right leading-none select-none pointer-events-none", v ? "text-white/70" : "text-black/70"),
                      children: S
                    }),
                    y.jsx("span", {
                      className: Y("text-[10px] leading-none select-none pointer-events-none", v ? "text-white/30" : "text-black/30"),
                      children: b.unit
                    }),
                    y.jsx("span", {
                      className: Y("mx-1 leading-none select-none pointer-events-none", v ? "text-white/20" : "text-black/20"),
                      children: "\xB7"
                    }),
                    y.jsx("span", {
                      className: Y("leading-none select-none pointer-events-none", v ? "text-white/40" : "text-black/40"),
                      children: "y:"
                    }),
                    y.jsx("span", {
                      className: Y("w-18 text-right leading-none select-none pointer-events-none", v ? "text-white/70" : "text-black/70"),
                      children: C
                    }),
                    y.jsx("span", {
                      className: Y("text-[10px] leading-none select-none pointer-events-none", v ? "text-white/30" : "text-black/30"),
                      children: b.unit
                    })
                  ]
                })
              ]
            }),
            !n && y.jsx($3, {
              isDark: v
            }),
            n && y.jsx("div", {
              className: "flex-1"
            }),
            y.jsxs("div", {
              className: "flex flex-shrink-0 items-center gap-2",
              children: [
                _ && y.jsx(Bv, {
                  isDark: v,
                  widthInPixels: E,
                  label: x
                }),
                y.jsx(Vn, {
                  label: "Zen Mode",
                  position: "top",
                  children: y.jsx("button", {
                    onClick: f,
                    className: Y("flex cursor-pointer items-center justify-center rounded p-0.5 transition-colors focus:outline-none", v ? "hover:bg-white/10" : "hover:bg-black/10", d && (v ? "bg-white/10" : "bg-black/10")),
                    children: y.jsx(BM, {
                      width: 14,
                      height: 14,
                      className: Y(v ? "text-white/50" : "text-black/50")
                    })
                  })
                }),
                y.jsx(Vn, {
                  label: "Minimap",
                  position: "top",
                  align: "end",
                  children: y.jsx("button", {
                    onClick: p,
                    className: Y("flex cursor-pointer items-center justify-center rounded p-0.5 transition-colors focus:outline-none", v ? "hover:bg-white/10" : "hover:bg-black/10", !g && (v ? "bg-white/10" : "bg-black/10")),
                    children: y.jsx(hM, {
                      width: 14,
                      height: 14,
                      className: Y(v ? "text-white/50" : "text-black/50")
                    })
                  })
                })
              ]
            })
          ]
        })
      ]
    });
  }
  function q3({ title: l, titleId: n, ...r }, o) {
    return m.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 20 20",
      fill: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": n
    }, r), l ? m.createElement("title", {
      id: n
    }, l) : null, m.createElement("path", {
      d: "M10 1a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 10 1ZM5.05 3.05a.75.75 0 0 1 1.06 0l1.062 1.06A.75.75 0 1 1 6.11 5.173L5.05 4.11a.75.75 0 0 1 0-1.06ZM14.95 3.05a.75.75 0 0 1 0 1.06l-1.06 1.062a.75.75 0 0 1-1.062-1.061l1.061-1.06a.75.75 0 0 1 1.06 0ZM3 8a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 0 1.5h-1.5A.75.75 0 0 1 3 8ZM14 8a.75.75 0 0 1 .75-.75h1.5a.75.75 0 0 1 0 1.5h-1.5A.75.75 0 0 1 14 8ZM7.172 10.828a.75.75 0 0 1 0 1.061L6.11 12.95a.75.75 0 0 1-1.06-1.06l1.06-1.06a.75.75 0 0 1 1.06 0ZM10.766 7.51a.75.75 0 0 0-1.37.365l-.492 6.861a.75.75 0 0 0 1.204.65l1.043-.799.985 3.678a.75.75 0 0 0 1.45-.388l-.978-3.646 1.292.204a.75.75 0 0 0 .74-1.16l-3.874-5.764Z"
    }));
  }
  const Sh = m.forwardRef(q3);
  function G3({ title: l, titleId: n, ...r }, o) {
    return m.createElement("svg", Object.assign({
      xmlns: "http://www.w3.org/2000/svg",
      fill: "none",
      viewBox: "0 0 24 24",
      strokeWidth: 1.5,
      stroke: "currentColor",
      "aria-hidden": "true",
      "data-slot": "icon",
      ref: o,
      "aria-labelledby": n
    }, r), l ? m.createElement("title", {
      id: n
    }, l) : null, m.createElement("path", {
      strokeLinecap: "round",
      strokeLinejoin: "round",
      d: "M10.05 4.575a1.575 1.575 0 1 0-3.15 0v3m3.15-3v-1.5a1.575 1.575 0 0 1 3.15 0v1.5m-3.15 0 .075 5.925m3.075.75V4.575m0 0a1.575 1.575 0 0 1 3.15 0V15M6.9 7.575a1.575 1.575 0 1 0-3.15 0v8.175a6.75 6.75 0 0 0 6.75 6.75h2.018a5.25 5.25 0 0 0 3.712-1.538l1.732-1.732a5.25 5.25 0 0 0 1.538-3.712l.003-2.024a.668.668 0 0 1 .198-.471 1.575 1.575 0 1 0-2.228-2.228 3.818 3.818 0 0 0-1.12 2.687M6.9 7.575V12m6.27 4.318A4.49 4.49 0 0 1 16.35 15m.002 0h-.002"
    }));
  }
  const Ch = m.forwardRef(G3), P3 = [
    {
      id: "select",
      icon: Sh,
      label: "Select",
      shortcut: "V"
    },
    {
      id: "laser",
      icon: N1,
      label: "Laser Pointer",
      shortcut: "Q"
    },
    {
      id: "pan",
      icon: Ch,
      label: "Pan",
      shortcut: "P"
    },
    {
      id: "move",
      icon: bh,
      label: "Move",
      shortcut: "M"
    },
    {
      id: "zoom",
      icon: vh,
      label: "Zoom",
      shortcut: "Z"
    },
    {
      id: "ruler",
      icon: D1,
      label: "Ruler",
      shortcut: "U"
    }
  ], Vv = [
    {
      id: "rectangle",
      icon: LM,
      label: "Rectangle",
      shortcut: "R"
    },
    {
      id: "polygon",
      icon: Fk,
      label: "Polygon",
      shortcut: "G"
    },
    {
      id: "path",
      icon: $k,
      label: "Path",
      shortcut: "H"
    },
    {
      id: "text",
      icon: PM,
      label: "Text",
      shortcut: "T"
    }
  ], K3 = [
    {
      id: "select",
      icon: Sh,
      label: "Select",
      shortcut: "V"
    },
    {
      id: "pan",
      icon: Ch,
      label: "Pan",
      shortcut: "P"
    },
    {
      id: "move",
      icon: bh,
      label: "Move",
      shortcut: "M"
    },
    {
      id: "zoom",
      icon: vh,
      label: "Zoom",
      shortcut: "Z"
    }
  ], $v = [
    {
      id: "laser",
      icon: N1,
      label: "Laser Pointer",
      shortcut: "Q"
    },
    {
      id: "ruler",
      icon: D1,
      label: "Ruler",
      shortcut: "U"
    }
  ], Z3 = [
    {
      id: "select",
      icon: Sh,
      label: "Select",
      shortcut: "V"
    },
    {
      id: "pan",
      icon: Ch,
      label: "Pan",
      shortcut: "P"
    }
  ];
  function qv({ tool: l, isActive: n, onClick: r, isDark: o }) {
    const i = l.icon;
    return y.jsx(Vn, {
      label: l.label,
      shortcut: {
        key: l.shortcut
      },
      children: y.jsx("button", {
        onClick: r,
        className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", o ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", n && (o ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
        children: y.jsx("div", {
          className: "flex h-5 w-5 items-center justify-center",
          children: y.jsx(i, {
            className: Y("h-5 w-5", o ? "text-white/90" : "text-black/90")
          })
        })
      })
    });
  }
  function Gv({ isDark: l }) {
    return y.jsx("div", {
      className: Y("mx-0 h-6 w-[1px]", l ? "bg-white/10" : "bg-black/10")
    });
  }
  function F3({ isDark: l, overflowBaseTools: n, overflowShapeTools: r, showInstance: o, showCommands: i }) {
    const [c, d] = m.useState(false), f = m.useRef(null), g = m.useRef(null), { activeTool: p, setTool: v } = Gt(), b = cn((x) => x.open), S = cn((x) => x.toggle), C = [
      ...n,
      ...r
    ].some((x) => x.id === p);
    m.useEffect(() => {
      if (!c) return;
      const x = (_) => {
        var _a, _b2;
        const N = _.target;
        !((_a = g.current) == null ? void 0 : _a.contains(N)) && !((_b2 = f.current) == null ? void 0 : _b2.contains(N)) && d(false);
      }, E = (_) => {
        _.key === "Escape" && d(false);
      };
      return document.addEventListener("mousedown", x, true), document.addEventListener("keydown", E), () => {
        document.removeEventListener("mousedown", x, true), document.removeEventListener("keydown", E);
      };
    }, [
      c
    ]);
    const k = m.useCallback(() => {
      if (!f.current) return {
        left: 0,
        top: 0
      };
      const x = f.current.getBoundingClientRect(), E = 200;
      let _ = x.left;
      return _ + E > window.innerWidth - 8 && (_ = window.innerWidth - E - 8), {
        left: _,
        top: x.bottom + 8
      };
    }, []);
    return y.jsxs(y.Fragment, {
      children: [
        y.jsx(Vn, {
          label: "More tools",
          className: c ? "[&>div:last-child]:hidden" : void 0,
          children: y.jsx("button", {
            ref: f,
            onClick: () => d(!c),
            className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", (C || c) && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
            children: y.jsx("div", {
              className: "flex h-5 w-5 items-center justify-center",
              children: y.jsx(Mk, {
                className: Y("h-5 w-5", l ? "text-white/90" : "text-black/90")
              })
            })
          })
        }),
        c && fs.createPortal(y.jsxs("div", {
          ref: g,
          className: Y("fixed z-[9999] min-w-[180px] rounded-xl border p-1 backdrop-blur-xl", l ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
          style: (() => {
            const x = k();
            return {
              left: `${x.left}px`,
              top: `${x.top}px`
            };
          })(),
          children: [
            n.length > 0 && y.jsx("div", {
              className: "flex flex-col",
              children: n.map((x) => {
                const E = x.icon, _ = p === x.id;
                return y.jsxs("button", {
                  onClick: () => {
                    v(x.id), d(false);
                  },
                  className: Y("flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", _ && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
                  children: [
                    y.jsx(E, {
                      className: Y("h-4 w-4", l ? "text-white/90" : "text-black/90")
                    }),
                    y.jsx("span", {
                      className: l ? "text-white/90" : "text-black/90",
                      children: x.label
                    }),
                    y.jsx("kbd", {
                      className: Y("ml-auto inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[10px]", l ? "border-white/15 bg-white/10 text-white/70" : "border-black/15 bg-black/10 text-black/70"),
                      children: x.shortcut
                    })
                  ]
                }, x.id);
              })
            }),
            r.length > 0 && y.jsxs(y.Fragment, {
              children: [
                y.jsx("div", {
                  className: Y("my-1 h-px", l ? "bg-white/10" : "bg-black/10")
                }),
                y.jsx("div", {
                  className: "flex flex-col",
                  children: r.map((x) => {
                    const E = x.icon, _ = p === x.id;
                    return y.jsxs("button", {
                      onClick: () => {
                        v(x.id), d(false);
                      },
                      className: Y("flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", _ && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
                      children: [
                        y.jsx(E, {
                          className: Y("h-4 w-4", l ? "text-white/90" : "text-black/90")
                        }),
                        y.jsx("span", {
                          className: l ? "text-white/90" : "text-black/90",
                          children: x.label
                        }),
                        y.jsx("kbd", {
                          className: Y("ml-auto inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[10px]", l ? "border-white/15 bg-white/10 text-white/70" : "border-black/15 bg-black/10 text-black/70"),
                          children: x.shortcut
                        })
                      ]
                    }, x.id);
                  })
                })
              ]
            }),
            (o || i) && y.jsxs(y.Fragment, {
              children: [
                y.jsx("div", {
                  className: Y("my-1 h-px", l ? "bg-white/10" : "bg-black/10")
                }),
                y.jsxs("div", {
                  className: "flex flex-col",
                  children: [
                    o && y.jsxs("button", {
                      onClick: () => {
                        b("add instance "), d(false);
                      },
                      className: Y("flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
                      children: [
                        y.jsx(I1, {
                          className: Y("h-4 w-4", l ? "text-white/90" : "text-black/90")
                        }),
                        y.jsx("span", {
                          className: l ? "text-white/90" : "text-black/90",
                          children: "Instance"
                        }),
                        y.jsx("kbd", {
                          className: Y("ml-auto inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[10px]", l ? "border-white/15 bg-white/10 text-white/70" : "border-black/15 bg-black/10 text-black/70"),
                          children: "I"
                        })
                      ]
                    }),
                    i && y.jsxs("button", {
                      onClick: () => {
                        S(), d(false);
                      },
                      className: Y("flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-xs transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
                      children: [
                        y.jsx(z1, {
                          className: Y("h-4 w-4", l ? "text-white/90" : "text-black/90")
                        }),
                        y.jsx("span", {
                          className: l ? "text-white/90" : "text-black/90",
                          children: "Commands"
                        }),
                        y.jsxs("span", {
                          className: "ml-auto flex gap-0.5",
                          children: [
                            y.jsx("kbd", {
                              className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[10px]", l ? "border-white/15 bg-white/10 text-white/70" : "border-black/15 bg-black/10 text-black/70"),
                              children: He.mod
                            }),
                            y.jsx("kbd", {
                              className: Y("inline-flex h-5 min-w-5 items-center justify-center rounded border px-1 text-[10px]", l ? "border-white/15 bg-white/10 text-white/70" : "border-black/15 bg-black/10 text-black/70"),
                              children: "K"
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              ]
            })
          ]
        }), document.body)
      ]
    });
  }
  function Pv({ compact: l = false, minimal: n = false }) {
    const { activeTool: r, setTool: o } = Gt(), c = me((k) => k.theme) === "dark", d = n ? Z3 : l ? K3 : P3, f = !l && !n, g = !l && !n, p = !l && !n, v = !l && !n, b = l || n, S = n ? [
      ...$v,
      {
        id: "move",
        icon: bh,
        label: "Move",
        shortcut: "M"
      },
      {
        id: "zoom",
        icon: vh,
        label: "Zoom",
        shortcut: "Z"
      }
    ] : l ? $v : [], C = l || n ? Vv : [];
    return y.jsxs("div", {
      className: Y("fixed top-4 z-50 mx-auto w-fit", l || n ? "left-14 right-14" : "left-0 right-0", "flex items-center gap-1 rounded-xl border px-1 pt-1 pb-[3px]", c ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
      children: [
        d.map((k) => y.jsx(qv, {
          tool: k,
          isActive: r === k.id,
          onClick: () => o(k.id),
          isDark: c
        }, k.id)),
        f && y.jsxs(y.Fragment, {
          children: [
            y.jsx(Gv, {
              isDark: c
            }),
            Vv.map((k) => y.jsx(qv, {
              tool: k,
              isActive: r === k.id,
              onClick: () => o(k.id),
              isDark: c
            }, k.id))
          ]
        }),
        g && y.jsx(Q3, {
          isDark: c
        }),
        p && y.jsx(W3, {
          isDark: c
        }),
        y.jsx(Gv, {
          isDark: c
        }),
        v && y.jsx(J3, {
          isDark: c
        }),
        b && y.jsx(F3, {
          isDark: c,
          overflowBaseTools: S,
          overflowShapeTools: C,
          showInstance: true,
          showCommands: true
        })
      ]
    });
  }
  const Kv = [
    {
      id: "union",
      icon: JM,
      label: "Union",
      kind: "boolean"
    },
    {
      id: "subtract",
      icon: IM,
      label: "Subtract",
      kind: "boolean"
    },
    {
      id: "intersect",
      icon: gk,
      label: "Intersect",
      kind: "boolean"
    },
    {
      id: "xor",
      icon: ck,
      label: "Exclude",
      kind: "boolean"
    },
    {
      id: "align-left",
      icon: L4,
      label: "Align Left",
      kind: "align"
    },
    {
      id: "align-center-h",
      icon: J_,
      label: "Align Center H",
      kind: "align"
    },
    {
      id: "align-right",
      icon: I4,
      label: "Align Right",
      kind: "align"
    },
    {
      id: "center-align",
      icon: y4,
      label: "Center Align",
      kind: "align"
    },
    {
      id: "align-top",
      icon: B4,
      label: "Align Top",
      kind: "align"
    },
    {
      id: "align-center-v",
      icon: a4,
      label: "Align Center V",
      kind: "align"
    },
    {
      id: "align-bottom",
      icon: C4,
      label: "Align Bottom",
      kind: "align"
    },
    {
      id: "origin-align",
      icon: sM,
      label: "Origin Align",
      kind: "align"
    }
  ];
  function Zv(l) {
    const { library: n, renderer: r } = Se.getState();
    if (!n || !r) return;
    const { selectedIds: o, lastSelectedId: i } = se.getState();
    if (o.size !== 0) if (l.kind === "boolean") {
      if (o.size < 2) return;
      const c = [
        ...o
      ], d = i ?? c[0], f = new Y0(c, l.id, d);
      ce.getState().execute(f, {
        library: n,
        renderer: r
      });
    } else {
      const c = l.id;
      if (c !== "origin-align" && o.size < 2) return;
      const d = new U0(new Set(o), i, c);
      ce.getState().execute(d, {
        library: n,
        renderer: r
      });
    }
  }
  function Q3({ isDark: l }) {
    const [n, r] = m.useState(Kv[0]), [o, i] = m.useState(false), c = m.useRef(null), d = m.useRef(null), f = m.useRef(null), g = n.icon;
    m.useEffect(() => {
      if (!o) return;
      const A = (R) => {
        R.key === "Escape" && i(false);
      };
      return document.addEventListener("keydown", A), () => {
        document.removeEventListener("keydown", A);
      };
    }, [
      o
    ]);
    const p = m.useCallback(() => {
      f.current = setTimeout(() => i(false), 150);
    }, []), v = m.useCallback(() => {
      f.current && (clearTimeout(f.current), f.current = null);
    }, []), b = m.useCallback(() => {
      v(), i(true);
    }, [
      v
    ]), S = m.useCallback(() => {
      p();
    }, [
      p
    ]), C = m.useCallback(() => {
      v();
    }, [
      v
    ]), k = m.useCallback(() => {
      p();
    }, [
      p
    ]), x = m.useCallback(() => {
      Zv(n);
    }, [
      n
    ]), E = m.useCallback((A) => {
      A.preventDefault(), i(true);
    }, []), _ = m.useCallback((A) => {
      r(A), i(false), setTimeout(() => Zv(A), 0);
    }, []), N = m.useCallback((A) => {
      if (d.current = A, !A || !c.current) return;
      const R = c.current.getBoundingClientRect(), I = A.getBoundingClientRect();
      let L = R.left + R.width / 2 - I.width / 2, D = R.bottom + 9;
      L + I.width > window.innerWidth - 8 && (L = window.innerWidth - I.width - 8), L < 8 && (L = 8), D + I.height > window.innerHeight - 8 && (D = R.top - I.height - 8), A.style.left = `${L}px`, A.style.top = `${D}px`, A.style.visibility = "visible";
    }, []);
    return y.jsxs(y.Fragment, {
      children: [
        y.jsx(Vn, {
          label: n.label,
          className: o ? "[&>div:last-child]:hidden" : void 0,
          children: y.jsx("button", {
            ref: c,
            onClick: x,
            onContextMenu: E,
            onMouseEnter: b,
            onMouseLeave: S,
            className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
            children: y.jsx("div", {
              className: "flex h-5 w-5 items-center justify-center",
              children: y.jsx(g, {
                className: Y("h-5 w-5", l ? "text-white/90" : "text-black/90")
              })
            })
          })
        }),
        o && fs.createPortal(y.jsx("div", {
          ref: N,
          onMouseEnter: C,
          onMouseLeave: k,
          className: Y("fixed z-[9999] rounded-xl border p-2 backdrop-blur-xl", l ? "border-white/10 bg-[rgb(29,29,29)]" : "border-black/10 bg-[rgb(241,241,241)]"),
          style: {
            visibility: "hidden"
          },
          children: y.jsx("div", {
            className: "grid grid-cols-4 gap-1",
            children: Kv.map((A) => y.jsx(Vn, {
              label: A.label,
              className: "[&>div:last-child]:mt-0.5",
              children: y.jsx("button", {
                onClick: () => _(A),
                className: Y("cursor-pointer rounded-lg p-1.5 transition-colors", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]"),
                children: y.jsx(A.icon, {
                  className: Y("h-5 w-5", l ? "text-white/90" : "text-black/90")
                })
              })
            }, A.id))
          })
        }), document.body)
      ]
    });
  }
  function W3({ isDark: l }) {
    const n = cn((c) => c.open), r = cn((c) => c.isOpen), o = cn((c) => c.initialSearch), i = r && !!o;
    return y.jsx(Vn, {
      label: "Instance",
      shortcut: {
        key: "I"
      },
      children: y.jsx("button", {
        onClick: () => n("add instance "),
        className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", i && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
        children: y.jsx("div", {
          className: "flex h-5 w-5 items-center justify-center",
          children: y.jsx(I1, {
            className: Y("h-5 w-5", l ? "text-white/90" : "text-black/90")
          })
        })
      })
    });
  }
  function J3({ isDark: l }) {
    const n = cn((c) => c.isOpen), r = cn((c) => c.initialSearch), o = cn((c) => c.toggle), i = n && !r;
    return y.jsx(Vn, {
      label: "Commands",
      shortcut: {
        modifiers: [
          He.mod
        ],
        key: "K"
      },
      children: y.jsx("button", {
        onClick: o,
        className: Y("cursor-pointer rounded-lg p-1.5 transition-colors focus:outline-none", l ? "hover:bg-[rgb(54,54,54)]" : "hover:bg-[rgb(217,217,217)]", i && (l ? "bg-[rgb(54,54,54)]" : "bg-[rgb(217,217,217)]")),
        children: y.jsx("div", {
          className: "flex h-5 w-5 items-center justify-center",
          children: y.jsx(z1, {
            className: Y("h-5 w-5", l ? "text-white/90" : "text-black/90")
          })
        })
      })
    });
  }
  const ej = 5e3;
  function tj() {
    const [l, n] = m.useState({
      status: "idle"
    }), [r, o] = m.useState(false), i = me((p) => p.theme) === "dark", c = m.useRef(null), d = m.useRef("");
    m.useEffect(() => {
      if (!Yn) return;
      const p = setTimeout(async () => {
        try {
          n({
            status: "checking"
          });
          const { check: v } = await yt(async () => {
            const { check: S } = await import("./index-DWHWQ1OU.js");
            return {
              check: S
            };
          }, __vite__mapDeps([3,1])), b = await v();
          b ? (c.current = b, d.current = b.version, n({
            status: "available",
            version: b.version,
            notes: b.body ?? null
          })) : n({
            status: "idle"
          });
        } catch (v) {
          console.warn("[updater] check failed:", v), n({
            status: "idle"
          });
        }
      }, ej);
      return () => clearTimeout(p);
    }, []);
    const f = m.useCallback(async () => {
      const p = c.current;
      if (p) try {
        const v = d.current;
        n({
          status: "downloading",
          version: v,
          progress: 0
        });
        let b = 0, S = 1;
        await p.downloadAndInstall((C) => {
          switch (C.event) {
            case "Started":
              S = C.data.contentLength ?? 1;
              break;
            case "Progress":
              b += C.data.chunkLength ?? 0, n({
                status: "downloading",
                version: v,
                progress: Math.min(b / S, 1)
              });
              break;
            case "Finished":
              break;
          }
        }), n({
          status: "ready",
          version: v
        });
      } catch (v) {
        console.error("[updater] download failed:", v), n({
          status: "error",
          message: v instanceof Error ? v.message : "Download failed"
        });
      }
    }, []), g = m.useCallback(async () => {
      try {
        const { relaunch: p } = await yt(async () => {
          const { relaunch: v } = await import("./index-BQlnJ-sT.js");
          return {
            relaunch: v
          };
        }, __vite__mapDeps([4,1]));
        await p();
      } catch (p) {
        console.error("[updater] relaunch failed:", p);
      }
    }, []);
    return !Yn || l.status === "idle" || l.status === "checking" || r ? null : y.jsxs("div", {
      className: Y("fixed bottom-10 right-4 z-[200] flex w-72 flex-col gap-2 rounded-xl border p-3 shadow-lg backdrop-blur-xl animate-[update-toast-in_0.3s_ease-out]", i ? "border-white/10 bg-[rgb(29,29,29)]/95 text-white/90" : "border-black/10 bg-[rgb(241,241,241)]/95 text-black/90"),
      children: [
        y.jsxs("div", {
          className: "flex items-center justify-between",
          children: [
            y.jsx("span", {
              className: "text-xs font-medium",
              children: l.status === "error" ? "Update failed" : "Update available"
            }),
            y.jsx("button", {
              type: "button",
              onClick: () => o(true),
              className: Y("flex h-5 w-5 items-center justify-center rounded transition-colors", i ? "hover:bg-white/10 text-white/40" : "hover:bg-black/10 text-black/40"),
              children: y.jsx("svg", {
                width: "10",
                height: "10",
                viewBox: "0 0 10 10",
                fill: "none",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                children: y.jsx("path", {
                  d: "M1 1l8 8M9 1l-8 8"
                })
              })
            })
          ]
        }),
        l.status !== "error" && y.jsxs("p", {
          className: Y("text-[11px]", i ? "text-white/50" : "text-black/50"),
          children: [
            "v",
            l.version,
            " is ready to install"
          ]
        }),
        l.status === "error" && y.jsx("p", {
          className: Y("text-[11px]", i ? "text-red-400/80" : "text-red-600/80"),
          children: l.message
        }),
        l.status === "downloading" && y.jsx("div", {
          className: Y("h-1 w-full overflow-hidden rounded-full", i ? "bg-white/10" : "bg-black/10"),
          children: y.jsx("div", {
            className: "h-full rounded-full bg-brand-purple transition-[width] duration-300 ease-out",
            style: {
              width: `${Math.round(l.progress * 100)}%`
            }
          })
        }),
        l.status === "available" && y.jsx("button", {
          type: "button",
          onClick: f,
          className: "mt-0.5 flex h-7 items-center justify-center rounded-lg border border-brand-purple-dark/50 bg-brand-purple px-3 text-xs font-medium text-white shadow-sm shadow-brand-purple-dark/30 ring-1 ring-inset ring-white/15 transition-colors hover:bg-brand-purple-light active:translate-y-px",
          children: "Download and install"
        }),
        l.status === "downloading" && y.jsxs("p", {
          className: Y("text-center text-[11px]", i ? "text-white/40" : "text-black/40"),
          children: [
            "Downloading... ",
            Math.round(l.progress * 100),
            "%"
          ]
        }),
        l.status === "ready" && y.jsx("button", {
          type: "button",
          onClick: g,
          className: "mt-0.5 flex h-7 items-center justify-center rounded-lg border border-brand-purple-dark/50 bg-brand-purple px-3 text-xs font-medium text-white shadow-sm shadow-brand-purple-dark/30 ring-1 ring-inset ring-white/15 transition-colors hover:bg-brand-purple-light active:translate-y-px",
          children: "Restart to update"
        }),
        l.status === "error" && y.jsx("button", {
          type: "button",
          onClick: () => o(true),
          className: Y("mt-0.5 flex h-7 items-center justify-center rounded-lg border px-3 text-xs font-medium transition-colors active:translate-y-px", i ? "border-white/10 text-white/70 hover:bg-white/5" : "border-black/10 text-black/70 hover:bg-black/5"),
          children: "Dismiss"
        })
      ]
    });
  }
  function nj() {
    const l = me((f) => f.theme), n = me((f) => f.zenMode), { isLg: r, isMd: o, isSm: i } = xh(), c = ns(), d = m.useRef(null);
    return m.useEffect(() => {
      d.current === null ? r ? (me.getState().setExplorerCollapsed(false), me.getState().setSidebarCollapsed(false)) : (me.getState().setExplorerCollapsed(true), me.getState().setSidebarCollapsed(true)) : d.current && !r ? (me.getState().setExplorerCollapsed(true), me.getState().setSidebarCollapsed(true)) : !d.current && r && (me.getState().setExplorerCollapsed(false), me.getState().setSidebarCollapsed(false)), d.current = r;
    }, [
      r
    ]), m.useEffect(() => {
      if (!c) return;
      const f = VS();
      f !== null && (me.getState().setExplorerWidth(f), me.getState().setSidebarWidth(f));
    }, [
      c
    ]), m.useEffect(() => {
      if (!Yn || c) return;
      const f = async (g) => {
        if (g.metaKey || g.ctrlKey) {
          if (g.key === "n") g.preventDefault(), await wh();
          else if (g.key === "o") {
            g.preventDefault();
            const v = await c0();
            v && await Jf(v);
          } else if (g.key === "s" && g.shiftKey) g.preventDefault(), await eh(true);
          else if (g.key === "s" && !g.shiftKey) g.preventDefault(), await eh(false);
          else if (g.key === "t") {
            g.preventDefault();
            const v = Pe.getState().activeTabId;
            if (v) {
              ts(v);
              const b = Se.getState().library;
              b && Wo(v, b);
            }
            window.dispatchEvent(new CustomEvent("rosette-new-tab"));
          } else if (g.key === "w") {
            g.preventDefault();
            const v = Pe.getState().activeTabId;
            v && window.dispatchEvent(new CustomEvent("rosette-close-tab", {
              detail: v
            }));
          } else if (g.key === "[" && g.shiftKey) {
            g.preventDefault();
            const { tabs: v, activeTabId: b } = Pe.getState();
            if (v.length > 1 && b) {
              const C = (v.findIndex((k) => k.id === b) - 1 + v.length) % v.length;
              $r(b, v[C].id), Pe.getState().setActiveTab(v[C].id);
            }
          } else if (g.key === "]" && g.shiftKey) {
            g.preventDefault();
            const { tabs: v, activeTabId: b } = Pe.getState();
            if (v.length > 1 && b) {
              const C = (v.findIndex((k) => k.id === b) + 1) % v.length;
              $r(b, v[C].id), Pe.getState().setActiveTab(v[C].id);
            }
          }
        }
      };
      return window.addEventListener("keydown", f), () => window.removeEventListener("keydown", f);
    }, [
      c
    ]), m.useEffect(() => {
      if (c) return;
      const f = async (g) => {
        const p = g.detail;
        if (!p) return;
        const v = Pe.getState().getTab(p);
        if (!v) return;
        const b = Pe.getState().activeTabId === p;
        if ((b ? v.isDirty || Fn.getState().isDirty : v.isDirty) && !await Y1()) return;
        const C = Pe.getState(), k = C.tabs.findIndex((x) => x.id === p);
        if (b && C.tabs.length > 1) {
          const x = C.tabs.filter((_) => _.id !== p), E = k < x.length ? x[k].id : x[x.length - 1].id;
          $r(p, E), Pe.getState().closeTab(p), Zi(p);
        } else b && C.tabs.length === 1 ? (Pe.getState().closeTab(p), window.dispatchEvent(new CustomEvent("rosette-new-tab")), Zi(p)) : (Pe.getState().closeTab(p), Zi(p));
      };
      return window.addEventListener("rosette-close-tab", f), () => window.removeEventListener("rosette-close-tab", f);
    }, [
      c
    ]), m.useEffect(() => {
      if (!Yn || c) return;
      let f = null, g = false;
      return (async () => {
        try {
          const { getCurrentWebviewWindow: p } = await yt(async () => {
            const { getCurrentWebviewWindow: S } = await import("./webviewWindow-DoRoZnHQ.js");
            return {
              getCurrentWebviewWindow: S
            };
          }, __vite__mapDeps([5,1,2])), b = await p().onDragDropEvent(async (S) => {
            if (S.payload.type === "drop") {
              const k = S.payload.paths.find((x) => x.endsWith(".gds") || x.endsWith(".gds2") || x.endsWith(".gdsii"));
              k && await Jf(k);
            }
          });
          g ? b() : f = b;
        } catch {
        }
      })(), () => {
        g = true, f == null ? void 0 : f();
      };
    }, [
      c
    ]), c ? y.jsxs("div", {
      className: `flex h-screen w-screen flex-col ${l === "dark" ? "bg-black" : "bg-white"}`,
      children: [
        y.jsxs("div", {
          className: "relative min-h-0 flex-1",
          children: [
            y.jsx(ib, {}),
            !n && y.jsx(Pv, {
              compact: !r,
              minimal: i
            }),
            !n && y.jsx(Ov, {}),
            !n && y.jsx(Uv, {}),
            !i && y.jsx(Iv, {}),
            y.jsx(_b, {})
          ]
        }),
        y.jsx(Xv, {
          compact: o || i,
          minimal: i
        })
      ]
    }) : y.jsxs("div", {
      className: `flex h-screen w-screen flex-col ${l === "dark" ? "bg-black" : "bg-white"}`,
      children: [
        y.jsxs("div", {
          className: "relative min-h-0 flex-1",
          children: [
            y.jsx(ib, {}),
            !n && y.jsx(Pv, {
              compact: !r,
              minimal: i
            }),
            !n && y.jsx(Ov, {}),
            !n && y.jsx(Uv, {}),
            !i && y.jsx(Iv, {}),
            y.jsx(_b, {})
          ]
        }),
        y.jsx(Xv, {
          compact: o || i,
          minimal: i
        }),
        y.jsx(tj, {})
      ]
    });
  }
  iS.createRoot(document.getElementById("root")).render(y.jsx(m.StrictMode, {
    children: y.jsx(nj, {})
  }));
})();
