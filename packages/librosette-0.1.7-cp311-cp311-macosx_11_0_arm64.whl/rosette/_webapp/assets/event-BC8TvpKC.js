import { invoke as a, transformCallback as c } from "./core-DxBnVPgq.js";
var i;
(function(e) {
  e.WINDOW_RESIZED = "tauri://resize", e.WINDOW_MOVED = "tauri://move", e.WINDOW_CLOSE_REQUESTED = "tauri://close-requested", e.WINDOW_DESTROYED = "tauri://destroyed", e.WINDOW_FOCUS = "tauri://focus", e.WINDOW_BLUR = "tauri://blur", e.WINDOW_SCALE_FACTOR_CHANGED = "tauri://scale-change", e.WINDOW_THEME_CHANGED = "tauri://theme-changed", e.WINDOW_CREATED = "tauri://window-created", e.WEBVIEW_CREATED = "tauri://webview-created", e.DRAG_ENTER = "tauri://drag-enter", e.DRAG_OVER = "tauri://drag-over", e.DRAG_DROP = "tauri://drag-drop", e.DRAG_LEAVE = "tauri://drag-leave";
})(i || (i = {}));
async function _(e, n) {
  window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(e, n), await a("plugin:event|unlisten", { event: e, eventId: n });
}
async function d(e, n, t) {
  var r;
  const l = typeof (t == null ? void 0 : t.target) == "string" ? { kind: "AnyLabel", label: t.target } : (r = t == null ? void 0 : t.target) !== null && r !== void 0 ? r : { kind: "Any" };
  return a("plugin:event|listen", { event: e, target: l, handler: c(n) }).then((u) => async () => _(e, u));
}
async function o(e, n, t) {
  return d(e, (r) => {
    _(e, r.id), n(r);
  }, t);
}
async function W(e, n) {
  await a("plugin:event|emit", { event: e, payload: n });
}
async function g(e, n, t) {
  await a("plugin:event|emit_to", { target: typeof e == "string" ? { kind: "AnyLabel", label: e } : e, event: n, payload: t });
}
export {
  i as TauriEvent,
  W as emit,
  g as emitTo,
  d as listen,
  o as once
};
