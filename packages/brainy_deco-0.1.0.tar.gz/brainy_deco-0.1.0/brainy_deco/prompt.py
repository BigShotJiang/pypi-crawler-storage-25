"""
Prompt builder: converts function signature + docstring into an LLM prompt.
"""

from __future__ import annotations

import inspect
import textwrap
from typing import Any, get_type_hints


# ── helpers ──────────────────────────────────────────────────────────────────

def _type_name(annotation) -> str:
    """Return a readable name for a type annotation."""
    if annotation is inspect.Parameter.empty:
        return "any"
    if hasattr(annotation, "__name__"):
        return annotation.__name__
    # e.g. list[int], dict[str, Any] …
    return str(annotation)


def _format_param(name: str, annotation, default) -> str:
    parts = [f"  - {name}"]
    if annotation is not inspect.Parameter.empty:
        parts.append(f" ({_type_name(annotation)})")
    if default is not inspect.Parameter.empty:
        parts.append(f" [default: {default!r}]")
    return "".join(parts)


# ── main builder ─────────────────────────────────────────────────────────────

def build_prompt(func, bound_args: dict[str, Any]) -> list[dict]:
    """
    Build the list of messages to send to the LLM.

    Returns a list of chat messages:
      [{"role": "system", ...}, {"role": "user", ...}]
    """
    sig = inspect.signature(func)
    doc = inspect.getdoc(func) or "(no description provided)"

    # ── system prompt ────────────────────────────────────────────────────────
    system_lines = [
        "You are a smart assistant that executes Python functions on behalf of the user.",
        "You will be given a function description, its parameters, and their actual values.",
        "Your job is to produce ONLY a Python assignment statement of the form:",
        "",
        "    _llm_return = <value>",
        "",
        "where <value> is the result of the function applied to the given inputs.",
        "Do NOT include any explanation, markdown fences, or extra text.",
        "The value must be a valid Python literal that can be evaluated with eval().",
    ]

    # Describe return type if annotated
    return_annotation = sig.return_annotation
    if return_annotation is not inspect.Parameter.empty:
        system_lines.append(
            f"The return type should be: {_type_name(return_annotation)}"
        )

    system_prompt = "\n".join(system_lines)

    # ── user prompt ──────────────────────────────────────────────────────────
    user_lines: list[str] = []

    # 1. Function description
    user_lines.append("## Function description")
    user_lines.append(doc)
    user_lines.append("")

    # 2. Parameter declarations
    user_lines.append("## Parameters")
    for param_name, param in sig.parameters.items():
        user_lines.append(
            _format_param(param_name, param.annotation, param.default)
        )
    user_lines.append("")

    # 3. Actual call values
    user_lines.append("## Call arguments")
    for name, value in bound_args.items():
        user_lines.append(f"  - {name} = {value!r}")
    user_lines.append("")

    # 4. Instruction
    user_lines.append(
        "Produce ONLY the assignment: _llm_return = <result>"
    )

    user_prompt = "\n".join(user_lines)

    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
