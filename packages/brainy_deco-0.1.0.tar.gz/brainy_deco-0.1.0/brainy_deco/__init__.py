"""
smart_function: A Python module that converts decorated functions into LLM calls.
"""

from .decorator import smart_func
from .backends import OllamaBackend, OpenAIBackend

__all__ = ["smart_func", "OllamaBackend", "OpenAIBackend"]
__version__ = "0.1.0"
