"""
LLM backends for smart_function.
Supports Ollama (default, local) and OpenAI-compatible APIs.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any


class LLMBackend(ABC):
    """Abstract base class for LLM backends."""

    @abstractmethod
    def chat(self, messages: list[dict], **kwargs) -> str:
        """Send messages and return the assistant's reply as a string."""
        ...


class OllamaBackend(LLMBackend):
    """
    Backend that talks to a local Ollama instance.
    Default base_url: http://localhost:11434
    """

    def __init__(
        self,
        model: str,
        base_url: str = "http://localhost:11434",
        timeout: int = 120,
        **options,
    ):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.options = options  # e.g. temperature, top_p …

    def chat(self, messages: list[dict], **kwargs) -> str:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx is required for OllamaBackend. Install it with: pip install httpx"
            ) from exc

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }
        if self.options:
            payload["options"] = self.options
        payload.update(kwargs)

        response = httpx.post(
            f"{self.base_url}/api/chat",
            json=payload,
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()
        return data["message"]["content"]


class OpenAIBackend(LLMBackend):
    """
    Backend compatible with OpenAI Chat Completions API
    (works with OpenAI, Azure OpenAI, local LM Studio, etc.).
    """

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str = "https://api.openai.com/v1",
        timeout: int = 120,
        **kwargs,
    ):
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.extra_kwargs = kwargs  # e.g. temperature, max_tokens …

    def chat(self, messages: list[dict], **kwargs) -> str:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx is required for OpenAIBackend. Install it with: pip install httpx"
            ) from exc

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
        }
        payload.update(self.extra_kwargs)
        payload.update(kwargs)

        response = httpx.post(
            f"{self.base_url}/chat/completions",
            headers=headers,
            json=payload,
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]
