"""
Response parser: extract the _llm_return value from the LLM reply.
"""

from __future__ import annotations

import ast
import re
from typing import Any


# Matches:  _llm_return = <value>
# The value may be wrapped in markdown fences, so we strip those first.
_ASSIGN_RE = re.compile(
    r"_llm_return\s*=\s*(.+)",
    re.DOTALL,
)


def _strip_fences(text: str) -> str:
    """Remove markdown code fences if present."""
    # ```python ... ``` or ``` ... ```
    fenced = re.sub(r"```(?:\w+)?\n?(.*?)```", r"\1", text, flags=re.DOTALL)
    return fenced.strip()


def parse_response(raw: str) -> Any:
    """
    Extract the value assigned to _llm_return from the LLM's reply.

    Raises ValueError if the assignment cannot be found or safely evaluated.
    """
    cleaned = _strip_fences(raw)

    m = _ASSIGN_RE.search(cleaned)
    if not m:
        raise ValueError(
            f"Could not find '_llm_return = ...' in LLM response.\n"
            f"Raw response:\n{raw}"
        )

    value_str = m.group(1).strip()

    try:
        # ast.literal_eval is safe – it only evaluates Python literals.
        return ast.literal_eval(value_str)
    except (ValueError, SyntaxError) as exc:
        raise ValueError(
            f"Could not evaluate '_llm_return' value: {value_str!r}\n"
            f"Error: {exc}"
        ) from exc
