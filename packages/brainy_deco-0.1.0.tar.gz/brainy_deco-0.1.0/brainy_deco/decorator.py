"""
Core decorator: @smart_func
"""

from __future__ import annotations

import functools
import inspect
import logging
from typing import Any, Callable

from .backends import LLMBackend, OllamaBackend
from .prompt import build_prompt
from .parser import parse_response

logger = logging.getLogger(__name__)


def smart_func(
    model: str = "gemma4",
    *,
    backend: LLMBackend | None = None,
    base_url: str = "http://localhost:11434",
    api_key: str | None = None,
    backend_type: str = "ollama",
    debug: bool = False,
    **backend_kwargs,
) -> Callable:
    """
    Decorator that replaces a function body with an LLM call.

    Parameters
    ----------
    model : str
        Name of the LLM model (e.g. "llama3", "gpt-4o", "qwen2.5").
    backend : LLMBackend, optional
        A pre-constructed backend instance. If given, all other connection
        parameters are ignored.
    base_url : str
        Base URL of the API endpoint.
        Ollama default : "http://localhost:11434"
        OpenAI default : "https://api.openai.com/v1"
    api_key : str, optional
        API key (not needed for Ollama).
    backend_type : str
        Which backend to auto-create when *backend* is not supplied.
        One of "ollama" (default) or "openai".
    debug : bool
        If True, log the assembled prompt and raw response.
    **backend_kwargs
        Extra keyword arguments forwarded to the backend constructor
        (e.g. temperature=0.2, timeout=60).

    Example
    -------
    ::

        from smart_function import smart_func

        @smart_func("qwen2.5")
        def translate(text: str, target_language: str) -> str:
            \"\"\"Translate the given text into the target language.\"\"\"

        result = translate("Hello, world!", "French")
        # → "Bonjour, le monde !"
    """

    def decorator(func: Callable) -> Callable:

        # Resolve backend once at decoration time for efficiency.
        resolved_backend: LLMBackend
        if backend is not None:
            resolved_backend = backend
        elif backend_type == "openai":
            from .backends import OpenAIBackend
            resolved_backend = OpenAIBackend(
                model=model,
                api_key=api_key,
                base_url=base_url,
                **backend_kwargs,
            )
        else:  # default: ollama
            resolved_backend = OllamaBackend(
                model=model,
                base_url=base_url,
                **backend_kwargs,
            )

        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            # Bind arguments to their parameter names using the real signature.
            sig = inspect.signature(func)
            try:
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
            except TypeError as exc:
                raise TypeError(
                    f"smart_func: argument binding failed for '{func.__name__}': {exc}"
                ) from exc

            bound_args: dict[str, Any] = dict(bound.arguments)

            # Build messages
            messages = build_prompt(func, bound_args)

            if debug:
                for m in messages:
                    logger.debug("[smart_func] %s:\n%s", m["role"].upper(), m["content"])

            # Call LLM
            raw_response = resolved_backend.chat(messages)

            if debug:
                logger.debug("[smart_func] RAW RESPONSE:\n%s", raw_response)

            # Parse and return
            return parse_response(raw_response)

        return wrapper

    return decorator
