"""
Unit tests for smart_function.
Run with:  uv run pytest tests/
"""

import pytest
from unittest.mock import MagicMock, patch

from smart_function import smart_func
from smart_function.prompt import build_prompt
from smart_function.parser import parse_response
from smart_function.backends import OllamaBackend, OpenAIBackend


# ─────────────────────────────────────────────────────────────────────────────
# Parser tests
# ─────────────────────────────────────────────────────────────────────────────

class TestParseResponse:
    def test_simple_string(self):
        assert parse_response('_llm_return = "hello"') == "hello"

    def test_integer(self):
        assert parse_response("_llm_return = 42") == 42

    def test_float(self):
        assert parse_response("_llm_return = 3.14") == pytest.approx(3.14)

    def test_list(self):
        assert parse_response("_llm_return = [1, 2, 3]") == [1, 2, 3]

    def test_dict(self):
        assert parse_response('_llm_return = {"a": 1}') == {"a": 1}

    def test_none(self):
        assert parse_response("_llm_return = None") is None

    def test_strips_markdown_fence(self):
        raw = "```python\n_llm_return = 99\n```"
        assert parse_response(raw) == 99

    def test_missing_assignment_raises(self):
        with pytest.raises(ValueError, match="_llm_return"):
            parse_response("The answer is 42")

    def test_invalid_literal_raises(self):
        with pytest.raises(ValueError):
            parse_response("_llm_return = open('/etc/passwd')")


# ─────────────────────────────────────────────────────────────────────────────
# Prompt builder tests
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildPrompt:
    def _dummy_func(self, text: str, n: int = 3) -> list:
        """Return the n most common words in text."""

    def test_returns_two_messages(self):
        msgs = build_prompt(self._dummy_func, {"text": "hello world", "n": 3})
        assert len(msgs) == 2
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"

    def test_docstring_in_user_prompt(self):
        msgs = build_prompt(self._dummy_func, {"text": "hello", "n": 1})
        assert "most common words" in msgs[1]["content"]

    def test_argument_values_in_user_prompt(self):
        msgs = build_prompt(self._dummy_func, {"text": "foo", "n": 5})
        assert "foo" in msgs[1]["content"]
        assert "5" in msgs[1]["content"]

    def test_return_type_in_system_prompt(self):
        msgs = build_prompt(self._dummy_func, {"text": "x", "n": 1})
        assert "list" in msgs[0]["content"]


# ─────────────────────────────────────────────────────────────────────────────
# Decorator integration tests (mocked backend)
# ─────────────────────────────────────────────────────────────────────────────

class TestSmartFunc:
    def _make_mock_backend(self, reply: str) -> MagicMock:
        backend = MagicMock()
        backend.chat.return_value = reply
        return backend

    def test_string_return(self):
        mock_backend = self._make_mock_backend('_llm_return = "Bonjour le monde"')

        @smart_func("dummy", backend=mock_backend)
        def translate(text: str, target_language: str) -> str:
            """Translate text into the target language."""

        result = translate("Hello world", "French")
        assert result == "Bonjour le monde"
        assert mock_backend.chat.called

    def test_float_return(self):
        mock_backend = self._make_mock_backend("_llm_return = 0.85")

        @smart_func("dummy", backend=mock_backend)
        def sentiment(text: str) -> float:
            """Return a sentiment score between -1 and 1."""

        result = sentiment("Great product!")
        assert result == pytest.approx(0.85)

    def test_dict_return(self):
        mock_backend = self._make_mock_backend(
            '_llm_return = {"name": "Alice", "age": 30}'
        )

        @smart_func("dummy", backend=mock_backend)
        def extract(bio: str) -> dict:
            """Extract name and age from a biography."""

        result = extract("Alice is 30 years old.")
        assert result == {"name": "Alice", "age": 30}

    def test_default_args_applied(self):
        """Default parameter values should appear in the prompt."""
        captured_messages = []

        def fake_chat(messages, **kw):
            captured_messages.extend(messages)
            return "_llm_return = []"

        backend = MagicMock()
        backend.chat.side_effect = fake_chat

        @smart_func("dummy", backend=backend)
        def top_words(text: str, n: int = 5) -> list:
            """Return the top n words."""

        top_words("hello world")  # n not provided → default 5
        user_content = captured_messages[1]["content"]
        assert "5" in user_content  # default should be reflected

    def test_bad_llm_response_raises(self):
        mock_backend = self._make_mock_backend("Sure, the answer is forty-two.")

        @smart_func("dummy", backend=mock_backend)
        def add(a: int, b: int) -> int:
            """Return a + b."""

        with pytest.raises(ValueError):
            add(1, 2)
