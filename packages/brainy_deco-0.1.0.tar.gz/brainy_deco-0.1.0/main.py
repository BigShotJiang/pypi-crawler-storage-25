import sys
import logging
from smart_function import smart_func
#logging.basicConfig(level=logging.DEBUG)

@smart_func(debug=True)
def add(a: int, b: int) -> int:
    """Multiply two integers."""


@smart_func(debug=True)
def guess_feeling(question: str) -> str:
    """
    Guess the feeling of questioner.
    Return only the feeling.
    Accepted feelings:
        - happy
        - sad
        - angry
        - surprised
        - neutral
    """


def main():
    print(f'Q: {sys.argv[1]}')
    print(f'Feeling: {guess_feeling(sys.argv[1])}')


if __name__ == "__main__":
    main()