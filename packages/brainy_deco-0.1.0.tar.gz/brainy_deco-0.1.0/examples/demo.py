"""
Examples demonstrating smart_function usage.

Run with:  uv run examples/demo.py
"""

import logging
from brainy_deco import smart_func

logging.basicConfig(level=logging.ERROR)

# ─────────────────────────────────────────────────────────────────────────────
# Example 1 – simple translation (Ollama, default)
# ─────────────────────────────────────────────────────────────────────────────

@smart_func("gemma4", debug=True)
def translate(text: str, target_language: str) -> str:
    """Translate the given text into the target language."""


# ─────────────────────────────────────────────────────────────────────────────
# Example 2 – sentiment analysis returning a float score
# ─────────────────────────────────────────────────────────────────────────────

@smart_func("gemma4")
def sentiment_score(text: str) -> float:
    """
    Analyse the sentiment of the text and return a score
    between -1.0 (very negative) and 1.0 (very positive).
    """


# ─────────────────────────────────────────────────────────────────────────────
# Example 3 – extract structured data as a dict
# ─────────────────────────────────────────────────────────────────────────────

@smart_func("gemma4")
def extract_person(bio: str) -> dict:
    """
    Extract personal information from a short biography.
    Return a dict with keys: name, age, occupation.
    If a field is unknown, use None.
    """


# ─────────────────────────────────────────────────────────────────────────────
# Example 4 – using an OpenAI-compatible endpoint
# ─────────────────────────────────────────────────────────────────────────────

# @smart_func(
#     "gpt-4o-mini",
#     backend_type="openai",
#     api_key="sk-...",
# )
# def summarize(article: str, max_words: int = 100) -> str:
#     """Summarize the article in at most max_words words."""


if __name__ == "__main__":
    # Example 1
    print("=== Translation ===")
    result = translate("Hello, world!", "French")
    print(f"Result: {result!r}")
    print()

    # Example 2
    print("=== Sentiment ===")
    score = sentiment_score("I absolutely love this product, it's amazing!")
    print(f"Score: {score}")
    print()

    # Example 3
    print("=== Entity extraction ===")
    person = extract_person(
        "Marie Curie was a 66-year-old physicist and chemist "
        "who pioneered research on radioactivity."
    )
    print(f"Person: {person}")
