from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path
from typing import Sequence

from dotenv import dotenv_values, set_key

from .workspace import bootstrap_workspace, resolve_workspace_root

SECRET_KEYS = {
    "NINETH_API_KEY",
    "METAAPI_TOKEN",
    "CAPITAL_API_KEY",
    "CAPITAL_PASSWORD",
}


def _read_env_file(env_path: Path) -> dict[str, str]:
    if not env_path.exists():
        return {}
    loaded = dotenv_values(env_path)
    return {key: value for key, value in loaded.items() if value is not None}


def _write_env_value(env_path: Path, key: str, value: str) -> None:
    env_path.parent.mkdir(parents=True, exist_ok=True)
    set_key(str(env_path), key, value)
    os.environ[key] = value


def _display_default(key: str, current: str | None, fallback: str = "") -> str:
    value = (current or fallback or "").strip()
    if not value:
        return "not set"
    if key in SECRET_KEYS:
        return "configured"
    return value


def _prompt_value(key: str, prompt: str, current: str | None = None, fallback: str = "") -> str:
    default_value = (current or fallback or "").strip()
    label = f"{prompt} [{_display_default(key, current, fallback)}]: "
    if key in SECRET_KEYS:
        answer = getpass.getpass(label)
    else:
        answer = input(label)
    answer = answer.strip()
    return answer or default_value


def _prompt_choice(prompt: str, options: list[tuple[str, str]], default: str) -> str:
    print(prompt)
    for index, (_, label) in enumerate(options, start=1):
        print(f"  {index}. {label}")
    default_index = next(
        (str(index) for index, (value, _) in enumerate(options, start=1) if value == default),
        "1",
    )
    answer = input(f"Select [{default_index}]: ").strip() or default_index
    if answer.isdigit():
        index = int(answer) - 1
        if 0 <= index < len(options):
            return options[index][0]
    for value, _ in options:
        if answer == value:
            return value
    return default


def _prompt_bool(prompt: str, current: str | None = None, fallback: str = "true") -> str:
    default_value = (current or fallback or "true").strip().lower()
    default_yes = default_value in {"1", "true", "yes", "y", "on"}
    answer = input(f"{prompt} [{'Y/n' if default_yes else 'y/N'}]: ").strip().lower()
    if not answer:
        return "true" if default_yes else "false"
    return "true" if answer in {"y", "yes", "true", "1", "on"} else "false"


def _capital_bridge_available() -> bool:
    try:
        __import__("nursery_capital_py")
    except ImportError:
        return False
    return True


def _run_setup_wizard(workspace_root: Path) -> None:
    env_path = workspace_root / ".env"
    current = _read_env_file(env_path)

    print(f"\nMinters setup\nWorkspace: {workspace_root}\n")
    print("Press Enter to keep the current value. Secret values are hidden.\n")

    api_key = _prompt_value("NINETH_API_KEY", "Nineth API key", current.get("NINETH_API_KEY"))
    if api_key:
        _write_env_value(env_path, "NINETH_API_KEY", api_key)

    broker_options = [
        ("default", "Use current or default broker flow"),
        ("farm", "Local Farm"),
        ("farm_ext", "MetaAPI / farm_ext"),
        ("capital", "Capital.com"),
        ("auto", "Auto-detect"),
    ]
    current_mode = current.get("BROKER_MODE", "farm") or "farm"
    broker_mode = _prompt_choice("Broker flow:", broker_options, default="default")
    effective_mode = current_mode if broker_mode == "default" else broker_mode

    if effective_mode:
        _write_env_value(env_path, "BROKER_MODE", effective_mode)
    if effective_mode == "farm_ext":
        _write_env_value(env_path, "FARM_EXT_ENABLED", "true")
    elif effective_mode == "farm":
        _write_env_value(env_path, "FARM_EXT_ENABLED", "false")
    elif effective_mode == "capital":
        _write_env_value(env_path, "CAPITAL_ENABLED", "true")

    if effective_mode == "farm":
        farm_host = _prompt_value("FARM_HOST", "Farm host", current.get("FARM_HOST"), "127.0.0.1")
        master_account = _prompt_value(
            "MASTER_ACCOUNT_ID",
            "Default master account id",
            current.get("MASTER_ACCOUNT_ID"),
            "sim",
        )
        if farm_host:
            _write_env_value(env_path, "FARM_HOST", farm_host)
        if master_account:
            _write_env_value(env_path, "MASTER_ACCOUNT_ID", master_account)
    elif effective_mode == "farm_ext":
        metaapi_token = _prompt_value("METAAPI_TOKEN", "MetaAPI token", current.get("METAAPI_TOKEN"))
        metaapi_account = _prompt_value(
            "METAAPI_ACCOUNT_ID",
            "MetaAPI account id",
            current.get("METAAPI_ACCOUNT_ID"),
        )
        if metaapi_token:
            _write_env_value(env_path, "METAAPI_TOKEN", metaapi_token)
        if metaapi_account:
            _write_env_value(env_path, "METAAPI_ACCOUNT_ID", metaapi_account)
    elif effective_mode == "capital":
        capital_api_key = _prompt_value("CAPITAL_API_KEY", "Capital API key", current.get("CAPITAL_API_KEY"))
        capital_identifier = _prompt_value(
            "CAPITAL_IDENTIFIER",
            "Capital identifier",
            current.get("CAPITAL_IDENTIFIER"),
        )
        capital_password = _prompt_value(
            "CAPITAL_PASSWORD",
            "Capital password",
            current.get("CAPITAL_PASSWORD"),
        )
        capital_demo = _prompt_bool(
            "Use Capital demo environment",
            current.get("CAPITAL_DEMO"),
            "true",
        )
        if capital_api_key:
            _write_env_value(env_path, "CAPITAL_API_KEY", capital_api_key)
        if capital_identifier:
            _write_env_value(env_path, "CAPITAL_IDENTIFIER", capital_identifier)
        if capital_password:
            _write_env_value(env_path, "CAPITAL_PASSWORD", capital_password)
        _write_env_value(env_path, "CAPITAL_DEMO", capital_demo)
        if not _capital_bridge_available():
            print(
                "[WARNING] Capital Rust bridge is not built in this Python environment. "
                "Run 'cd harness/capital && maturin develop' inside the workspace if you need Capital mode.\n"
            )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="minters", description="Run the Mint Seal application.")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Launch the Seal UI.")
    run_parser.add_argument("--workspace", type=Path, help="Path to the writable Mint workspace.")
    run_parser.add_argument("--model", help="Override REGULATOR_MODEL for this session.")
    run_parser.add_argument(
        "--default",
        action="store_true",
        help="Skip the interactive setup wizard and use the current workspace configuration.",
    )

    workspace_parser = subparsers.add_parser("workspace", help="Print the resolved workspace path.")
    workspace_parser.add_argument("--workspace", type=Path, help="Path to the writable Mint workspace.")

    return parser


def _prepare_workspace(explicit: Path | None = None) -> Path:
    workspace_root = resolve_workspace_root(explicit)
    os.environ["MINTERS_WORKSPACE"] = str(workspace_root)
    os.environ["MINT_WORKSPACE"] = str(workspace_root)
    return workspace_root


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    command = args.command or "run"

    if command == "workspace":
        workspace_root = _prepare_workspace(getattr(args, "workspace", None))
        print(workspace_root)
        return 0

    if command != "run":
        parser.error(f"Unknown command: {command}")

    workspace_root = _prepare_workspace(args.workspace)
    bootstrap_workspace(workspace_root)

    if sys.stdin.isatty() and not args.default:
        _run_setup_wizard(workspace_root)

    if args.model:
        os.environ["REGULATOR_MODEL"] = args.model

    from regulator.seal import SealApp

    SealApp(model_name=os.environ.get("REGULATOR_MODEL", args.model or "1984-m3-0421")).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
