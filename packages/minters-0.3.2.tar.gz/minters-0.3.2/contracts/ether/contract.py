import asyncio
from harness import capital, farm

class EtherContract:

    epic = "EthereumUSD"
    symbol = "ETHUSDm"
    lot_size = 0.1

    async def run(self):

        while True:
            # we just test the buy contract
            order = await capital.market_buy(self.epic, self.lot_size)
            print("Order response:", order)

            await asyncio.sleep(5)  # wait before placing the next order

            # do the same in the farm engine
            order = await farm.market_buy(self.symbol, size=self.lot_size)
            print("Farm Order response:", order)
            # end
            break



if __name__ == "__main__":
    contract = EtherContract()
    asyncio.run(contract.run())