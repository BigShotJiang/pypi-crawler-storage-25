"""
candy.banner — Bannière ASCII v19
"""

import sys

VERSION = "19.0.0"
BETA    = False
RELEASE = "31 mars 2026"

_BANNER = f"""
\033[95m   ██████╗ █████╗ ███╗   ██╗██████╗ ██╗   ██╗
\033[95m  ██╔════╝██╔══██╗████╗  ██║██╔══██╗╚██╗ ██╔╝
\033[96m  ██║     ███████║██╔██╗ ██║██║  ██║ ╚████╔╝
\033[96m  ██║     ██╔══██║██║╚██╗██║██║  ██║  ╚██╔╝
\033[94m  ╚██████╗██║  ██║██║ ╚████║██████╔╝   ██║
\033[94m   ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝    ╚═╝\033[0m
\033[90m  ──────────────────────────────────────────────
\033[97m  ⚡ Cedric7-Thinking Engine  \033[90m│\033[97m  v{VERSION}  \033[90m│\033[92m  ✅ Stable
\033[97m  🎨 ImageGen  \033[90m│\033[97m  120 personnalités  \033[90m│\033[97m  MIT
\033[90m  ──────────────────────────────────────────────\033[0m
"""

_shown = False

def show_banner():
    global _shown
    if _shown:
        return
    _shown = True
    if "CANDY_NO_BANNER" in __import__("os").environ:
        return
    try:
        sys.stdout.write(_BANNER)
        sys.stdout.flush()
    except Exception:
        pass
