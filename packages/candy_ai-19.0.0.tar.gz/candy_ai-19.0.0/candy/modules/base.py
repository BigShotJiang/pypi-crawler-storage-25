"""
candy.modules.base — Classe de base v5
"""

import sys
from typing import Optional, Generator
from ..client import _client
from ..config import get_profile, Profile


class BoundModule:
    """Module lié à un profil via .use('nom')."""

    def __init__(self, personality: str, profile: Profile):
        self._personality = personality
        self._profile = profile

    def ask(self, prompt: str, context: Optional[str] = None) -> str:
        result = _client.ask(self._personality, prompt, self._profile,
                             context=context, stream=False)
        return result.get("response", "")

    def stream(self, prompt: str, context: Optional[str] = None) -> Generator[str, None, None]:
        yield from _client.ask(self._personality, prompt, self._profile,
                                context=context, stream=True)

    def stream_print(self, prompt: str, context: Optional[str] = None, end: str = "\n") -> str:
        """Streame et affiche dans le terminal. Retourne la réponse complète."""
        full = []
        for token in self.stream(prompt, context=context):
            sys.stdout.write(token)
            sys.stdout.flush()
            full.append(token)
        sys.stdout.write(end)
        return "".join(full)

    def ask_with_meta(self, prompt: str, context: Optional[str] = None) -> dict:
        return _client.ask(self._personality, prompt, self._profile,
                           context=context, stream=False)

    def batch(self, prompts: list, context: Optional[str] = None) -> list:
        """Envoie plusieurs prompts, retourne une liste de réponses."""
        return _client.batch(self._personality, prompts, self._profile, context=context)

    def quota(self) -> dict:
        return _client.quota(self._profile)

    def ping(self) -> float:
        return _client.ping(self._profile)

    def is_online(self) -> bool:
        return _client.is_online(self._profile)

    def chat(self, max_history: int = 20):
        """Crée une session de conversation multi-tours avec ce profil."""
        from ..conversation import Conversation
        class _BoundConv(Conversation):
            pass
        name = object.__getattribute__(self._profile, "_name")

        class _FakeModule:
            _personality = self._personality
        return Conversation(_FakeModule, profile=name, max_history=max_history)

    def __repr__(self):
        name = object.__getattribute__(self._profile, "_name")
        return f"<candy.{self._personality} profile='{name}'>"


class BaseModule:
    """Classe de base pour toutes les personnalités candy."""

    _personality: str = "full"

    @classmethod
    def use(cls, profile_name: str) -> BoundModule:
        """
        Utilise un profil spécifique.

            cfg.A.lang  = "FR"
            Coding.use("A").ask("Explique les décorateurs")
        """
        return BoundModule(cls._personality, get_profile(profile_name))

    @classmethod
    def ask(cls, prompt: str, context: Optional[str] = None) -> str:
        """Appel simple avec le profil 'default'."""
        result = _client.ask(cls._personality, prompt, get_profile("default"),
                             context=context, stream=False)
        return result.get("response", "")

    @classmethod
    def stream(cls, prompt: str, context: Optional[str] = None) -> Generator[str, None, None]:
        """Streaming avec le profil 'default'."""
        yield from _client.ask(cls._personality, prompt, get_profile("default"),
                                context=context, stream=True)

    @classmethod
    def stream_print(cls, prompt: str, context: Optional[str] = None, end: str = "\n") -> str:
        """Streame et affiche. Retourne la réponse complète."""
        full = []
        for token in cls.stream(prompt, context=context):
            sys.stdout.write(token)
            sys.stdout.flush()
            full.append(token)
        sys.stdout.write(end)
        return "".join(full)

    @classmethod
    def ask_with_meta(cls, prompt: str, context: Optional[str] = None) -> dict:
        return _client.ask(cls._personality, prompt, get_profile("default"),
                           context=context, stream=False)

    @classmethod
    def batch(cls, prompts: list, context: Optional[str] = None) -> list:
        """Envoie plusieurs prompts d'un coup. Retourne une liste de réponses."""
        return _client.batch(cls._personality, prompts, get_profile("default"), context=context)

    @classmethod
    def chat(cls, profile: str = "default", max_history: int = 20):
        """
        Ouvre une session de conversation multi-tours.

            session = Coding.chat(profile="A")
            print(session.say("Explique les générateurs"))
            print(session.say("Donne un exemple"))
        """
        from ..conversation import Conversation
        return Conversation(cls, profile=profile, max_history=max_history)

    @classmethod
    def quota(cls) -> dict:
        return _client.quota(get_profile("default"))

    @classmethod
    def ping(cls) -> float:
        return _client.ping(get_profile("default"))

    @classmethod
    def is_online(cls) -> bool:
        return _client.is_online(get_profile("default"))

    @classmethod
    def personalities(cls) -> list:
        return _client.personalities(get_profile("default"))
