# 🍬 candy-ai v19

**Framework IA Python professionnel** — Cedric7-Thinking Engine

```bash
pip install candy-ai
```

---

## Quick Start

```python
from candy import Coding

response = Coding.ask("Write a binary search in Python")
print(response)
```

---

## Streaming

```python
from candy import Writing

for token in Writing.stream("Write a short story about a lighthouse keeper"):
    print(token, end="", flush=True)
```

---

## Conversations multi-tours

```python
from candy import Conversation, Coding, cfg

cfg.A.lang = "FR"

chat = Conversation(Coding, profile="A")
print(chat.say("Explique les décorateurs Python"))
print(chat.say("Donne-moi un exemple avec une classe"))

chat.show_history()
chat.save("chat.json")           # écrase
chat.save("chat.json", append=True)  # fusionne avec l'existant
chat.load("chat.json")
```

---

## 🆕 Nouveautés v19

- **`save(append=True)`** — fusionne l'historique sans écraser l'ancien
- Bannière stable (plus de mention BETA)
- Corrections mineures de stabilité

---

## ImageGen — Génération d'images

```python
from candy import ImageGen

ImageGen.create("un chat astronaute sur la lune", save="chat.png")
ImageGen.create(
    "portrait d'un robot steampunk",
    style="photorealistic",
    size="1024x1024",
    save="robot.png"
)
ImageGen.variation("original.png", strength=0.6, save="variation.png")
desc = ImageGen.describe("photo.jpg", lang="FR")
images = ImageGen.batch(["forêt", "ville", "portrait"], save_dir="./output/")
print(ImageGen.styles())
```

---

## Context support

```python
from candy import Analytic

data = """
Month,Revenue
Jan,12000
Feb,15400
"""

response = Analytic.ask("What trend do you see?", context=data)
print(response)
```

---

## Check your quota

```python
from candy import Math
print(Math.quota())
# {'ip': '...', 'quota_used_today': 12, 'quota_limit': 500, 'quota_remaining': 488}
```

---

## Available personalities (120)

| Import | Domain |
|--------|--------|
| `Math` | Mathematics |
| `Coding` | Software engineering |
| `Reflexion` | Deep thinking & philosophy |
| `Analytic` | Data analysis |
| `Full` | All domains combined |
| `Science` | Multi-disciplinary science |
| `Writing` | Creative & technical writing |
| `History` | World history |
| `Law` | Legal concepts |
| `Medicine` | Medical knowledge |
| `Finance` | Finance & investment |
| `Marketing` | Growth & marketing |
| `Security` | Cybersecurity |
| `Design` | UI/UX & graphic design |
| `Language` | Translation & linguistics |
| `Psychology` | Human behavior |
| `Education` | Pedagogy & teaching |
| `Research` | Academic research |
| `Business` | Strategy & consulting |
| `Productivity` | Efficiency & systems |
| `Cooking` | Recipes & nutrition |
| `Travel` | Trip planning |
| `Music` | Music theory & production |
| `Film` | Cinema & screenwriting |
| `Sports` | Sports analysis & coaching |
| `Philosophy` | Ethics & metaphysics |
| `Environment` | Ecology & sustainability |
| `Architecture` | Building & urban design |
| `Automotive` | Vehicles & mechanics |
| `Astronomy` | Astrophysics & space |
| `Biology` | Life sciences |
| `Chemistry` | Chemical science |
| `Physics` | Classical & quantum physics |
| `Engineering` | Multi-discipline engineering |
| `Entrepreneur` | Startups & ventures |
| `Ethics` | Applied moral philosophy |
| `Geopolitics` | International relations |
| `Crypto` | Blockchain & DeFi |
| `AI` | Machine learning & AI |
| `DevOps` | Cloud & infrastructure |
| `Database` | DB design & optimization |
| `GameDev` | Game development |
| `Comic` | Humor & comedy writing |
| `Storyteller` | Narrative & fiction |
| `Translator` | Professional translation |
| `Summarizer` | Content summarization |
| `Debugger` | Bug finding & fixing |
| `Reviewer` | Code & content review |
| `Planner` | Project planning |
| `Tutor` | Adaptive teaching |
| `Nutrition` | Nutrition & diet |
| `Yoga` | Yoga & wellness |
| `Mindfulness` | Mindfulness & meditation |
| `Parenting` | Parenting & family |
| `Relationship` | Relationships & communication |
| `Leadership` | Leadership & management |
| `Negotiation` | Negotiation & persuasion |
| `PublicSpeak` | Public speaking |
| `Branding` | Brand strategy |
| `UXResearch` | UX research |
| `DataVis` | Data visualization |
| `MLOps` | ML operations |
| `Prompt` | Prompt engineering |
| `Blockchain` | Blockchain & Web3 |
| `IoT` | Internet of Things |
| `ArVr` | AR/VR development |
| `Quantum` | Quantum computing |
| `Robotics` | Robotics & automation |
| `Bioinformatics` | Bioinformatics |
| `ClimateTech` | Climate technology |
| `Agri` | Agriculture & food |
| `Interior` | Interior design |
| `Fashion` | Fashion & style |
| `Photography` | Photography & editing |
| `Podcast` | Podcasting |
| `Youtube` | YouTube strategy |
| `SocialMedia` | Social media |
| `SEO` | Search engine optimization |
| `Copywriting` | Copywriting & ads |
| `TaxLaw` | Tax law |
| `RealEstate` | Real estate |
| `Insurance` | Insurance |
| `Logistics` | Logistics & supply chain |
| `HRM` | Human resources |
| `ProjectMgmt` | Project management |
| `Consulting` | Business consulting |
| `PublicPolicy` | Public policy |
| `Journalism` | Journalism & media |
| `SpeechWrite` | Speechwriting |
| `Mythology` | Mythology & folklore |
| `Screenwriting` | Screenwriting & scripts |
| `Comics` | Comics & graphic novels |
| `Animation` | Animation & motion |
| `GameDesign` | Game design |
| `VFX` | Visual effects |
| `Cybersecurity` | Cybersecurity |
| `CloudArch` | Cloud architecture |
| `DataScience` | Data science |
| `Neuroscience` | Neuroscience |
| `SpaceScience` | Space science |
| `Materials` | Materials science |
| `Oceanography` | Oceanography |
| `Venture` | Venture capital |
| `Trading` | Trading & markets |
| `Ecommerce` | E-commerce |
| `SupplyChain` | Supply chain |
| `Accounting` | Accounting & finance |
| `MentalHealth` | Mental health |
| `Fitness` | Fitness & training |
| `Sleep` | Sleep science |
| `Longevity` | Longevity & health |
| `Sociology` | Sociology |
| `Linguistics` | Linguistics |
| `Anthropology` | Anthropology |
| `Education2` | Advanced education |
| `Sports2` | Advanced sports |
| `Futurism` | Futurism & trends |
| `Sustainability` | Sustainability |
| `SmartCity` | Smart cities |
| `Web3` | Web3 & decentralization |
| `PromptEng2` | Advanced prompt engineering |

---

## Powered by Cedric7-Thinking

candy connects to the **Cedric7-Thinking** engine.  
Usage is subject to a daily quota (500 requests/day by default).

---

## License

MIT
