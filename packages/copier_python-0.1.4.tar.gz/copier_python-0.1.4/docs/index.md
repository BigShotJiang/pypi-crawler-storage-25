---
icon: lucide/book-open
---

--8<-- "README.md"
