import unittest

import bentu
import bentu_downloader


class ImportAliasTests(unittest.TestCase):
    def test_bentu_downloader_import_exports_public_api(self):
        self.assertEqual(bentu_downloader.__version__, bentu.__version__)
        self.assertIs(bentu_downloader.Downloader, bentu.Downloader)
        self.assertIs(bentu_downloader.download, bentu.download)


if __name__ == "__main__":
    unittest.main()
