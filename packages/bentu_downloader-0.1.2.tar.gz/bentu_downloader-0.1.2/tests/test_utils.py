import unittest

from bentu.utils import resolve_output_path, sanitize_filename


class UtilsTests(unittest.TestCase):
    def test_sanitize_filename_removes_bad_characters(self):
        self.assertEqual(sanitize_filename('bad:/name*"'), "bad__name__")

    def test_resolve_output_path_renders_template(self):
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as temp_dir:
            path = resolve_output_path("%(title)s.%(ext)s", "My Video", "mp4", temp_dir)
            self.assertEqual(path, Path(temp_dir) / "My Video.mp4")


if __name__ == "__main__":
    unittest.main()
