import unittest

from bentu.hls import HlsDownloader


class HlsTests(unittest.TestCase):
    def test_parse_segments_resolves_relative_urls(self):
        downloader = HlsDownloader(user_agent="test", timeout=1, chunk_size=4)
        playlist = """#EXTM3U
#EXTINF:1,
seg-1.ts
#EXTINF:1,
folder/seg-2.ts
"""

        segments = downloader._parse_segments("https://example.com/live/index.m3u8", playlist)

        self.assertEqual(
            [item.url for item in segments],
            [
                "https://example.com/live/seg-1.ts",
                "https://example.com/live/folder/seg-2.ts",
            ],
        )


if __name__ == "__main__":
    unittest.main()
