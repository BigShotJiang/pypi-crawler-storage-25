import unittest

from bentu.compat import BentuDL


class CompatTests(unittest.TestCase):
    def test_options_are_mapped_from_flexible_params(self):
        bdl = BentuDL(
            {
                "outtmpl": "downloads/%(title)s.%(ext)s",
                "format": "bestvideo",
                "paths": {"home": "media"},
                "quiet": True,
                "headers": {"Referer": "https://example.com/"},
            }
        )

        self.assertEqual(bdl.options.output, "downloads/%(title)s.%(ext)s")
        self.assertEqual(bdl.options.format, "bestvideo")
        self.assertEqual(bdl.options.directory, "media")
        self.assertTrue(bdl.options.quiet)
        self.assertEqual(bdl.options.headers["Referer"], "https://example.com/")


if __name__ == "__main__":
    unittest.main()
