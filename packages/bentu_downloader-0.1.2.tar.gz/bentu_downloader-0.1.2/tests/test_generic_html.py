import unittest

from bentu.providers.generic_html import GenericHtmlProvider


class GenericHtmlTests(unittest.TestCase):
    def test_extract_formats_finds_visible_script_media_urls(self):
        provider = GenericHtmlProvider()
        page = """
        <html>
          <head><title>Example</title></head>
          <body>
            <script>
              window.__DATA__ = {"playable_url":"https:\\/\\/cdn.example.com\\/video.mp4?token=abc"};
            </script>
          </body>
        </html>
        """

        formats = provider._extract_formats("https://example.com/watch", page, {"User-Agent": "test"})

        self.assertEqual(len(formats), 1)
        self.assertEqual(formats[0].url, "https://cdn.example.com/video.mp4?token=abc")
        self.assertEqual(formats[0].ext, "mp4")


if __name__ == "__main__":
    unittest.main()
