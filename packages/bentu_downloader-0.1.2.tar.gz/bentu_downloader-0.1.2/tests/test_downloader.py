import unittest

from bentu.downloader import Downloader
from bentu.models import DownloadOptions, MediaFormat, MediaInfo


class DownloaderTests(unittest.TestCase):
    def test_select_format_by_id(self):
        downloader = Downloader(providers=[])
        info = MediaInfo(
            webpage_url="https://example.com",
            title="Example",
            formats=[
                MediaFormat(format_id="low", url="https://example.com/low.mp4"),
                MediaFormat(format_id="high", url="https://example.com/high.mp4"),
            ],
        )

        selected = downloader._select_format(info, "high")

        self.assertEqual(selected.url, "https://example.com/high.mp4")

    def test_options_can_be_created_with_output_template(self):
        options = DownloadOptions(output="%(title)s.%(ext)s")
        self.assertEqual(options.output, "%(title)s.%(ext)s")


if __name__ == "__main__":
    unittest.main()
