"""Public import alias for the bentu-downloader package.

Install name:
    pip install bentu-downloader

Python import name:
    import bentu_downloader
"""

from bentu import (
    BentuDL,
    BentuError,
    DownloadError,
    DownloadOptions,
    DownloadResult,
    Downloader,
    ExtractError,
    MediaFormat,
    MediaInfo,
    UnsupportedURLError,
    __version__,
    download,
    extract_info,
)

__all__ = [
    "BentuDL",
    "BentuError",
    "DownloadError",
    "DownloadOptions",
    "DownloadResult",
    "Downloader",
    "ExtractError",
    "MediaFormat",
    "MediaInfo",
    "UnsupportedURLError",
    "__version__",
    "download",
    "extract_info",
]
