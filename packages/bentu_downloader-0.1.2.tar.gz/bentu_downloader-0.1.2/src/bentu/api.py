from __future__ import annotations

from .downloader import Downloader
from .models import DownloadOptions, DownloadResult, MediaInfo


def extract_info(url: str) -> MediaInfo:
    """Extract metadata and formats for a URL."""

    return Downloader().extract_info(url)


def download(url: str, output: str | None = None, **kwargs) -> DownloadResult:
    """Download a URL using Bentu's default downloader.

    Parameters mirror the CLI where practical. Unknown keyword arguments must
    be valid ``DownloadOptions`` fields.
    """

    options_data = dict(kwargs)
    if output is not None:
        options_data["output"] = output
    return Downloader().download(url, DownloadOptions(**options_data))
