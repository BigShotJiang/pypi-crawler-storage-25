from __future__ import annotations

import json
import sys
from importlib.metadata import PackageNotFoundError, version
from urllib.error import URLError
from urllib.request import Request, urlopen

from .exceptions import UpdateCheckError

PACKAGE_NAME = "bentu-downloader"
PYPI_URL = f"https://pypi.org/pypi/{PACKAGE_NAME}/json"


def current_version() -> str:
    try:
        return version(PACKAGE_NAME)
    except PackageNotFoundError:
        from . import __version__

        return __version__


def check_for_update(timeout: float = 2.0) -> tuple[str, str] | None:
    installed = current_version()
    request = Request(PYPI_URL, headers={"User-Agent": f"bentu/{installed}"})
    try:
        with urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except URLError as error:
        raise UpdateCheckError(str(error)) from error
    except Exception as error:
        raise UpdateCheckError(str(error)) from error

    latest = str(payload.get("info", {}).get("version") or "").strip()
    if latest and _version_tuple(latest) > _version_tuple(installed):
        return installed, latest
    return None


def print_update_notice(repeat: int = 3) -> None:
    try:
        update = check_for_update()
    except UpdateCheckError:
        return
    if update is None:
        return

    installed, latest = update
    message = (
        f"Neue Bentu-Version verfügbar: {installed} -> {latest}. "
        f"Aktualisieren mit: {sys.executable} -m pip install -U {PACKAGE_NAME}"
    )
    for _ in range(max(1, repeat)):
        print(message, file=sys.stderr)


def _version_tuple(value: str) -> tuple[int, ...]:
    parts: list[int] = []
    for chunk in value.replace("-", ".").split("."):
        digits = "".join(char for char in chunk if char.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)
