from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict

from . import __version__
from ._version import USER_AGENT
from .downloader import Downloader
from .exceptions import BentuError
from .models import DownloadOptions, MediaFormat, MediaInfo
from .version_check import print_update_notice


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bentu",
        description="Download public media URLs and simple HTML-exposed videos.",
    )
    parser.add_argument("url", nargs="?", help="URL to download")
    parser.add_argument("-o", "--output", default="%(title)s.%(ext)s", help="Output template")
    parser.add_argument("-f", "--format", default="best", help="Format id to download")
    parser.add_argument("-P", "--paths", dest="directory", help="Output directory")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing output file")
    parser.add_argument("--quiet", "-q", action="store_true", help="Reduce terminal output")
    parser.add_argument("--retries", type=int, default=2, help="Retry count after network failures")
    parser.add_argument("--chunk-size", type=int, default=1024 * 256, help="Download chunk size in bytes")
    parser.add_argument(
        "--add-header",
        action="append",
        default=[],
        metavar="KEY:VALUE",
        help="Add an HTTP header. Can be used more than once.",
    )
    parser.add_argument("--print-info", action="store_true", help="Print extracted metadata as JSON")
    parser.add_argument("--list-formats", action="store_true", help="List available formats")
    parser.add_argument("--no-update-check", action="store_true", help="Disable PyPI update check")
    parser.add_argument("--timeout", type=float, default=30.0, help="Network timeout in seconds")
    parser.add_argument("--user-agent", default=USER_AGENT, help="HTTP user agent")
    parser.add_argument("--version", action="version", version=f"bentu {__version__}")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.no_update_check and not args.quiet:
        print_update_notice()

    if not args.url:
        parser.print_help()
        return 2

    options = DownloadOptions(
        output=args.output,
        format=args.format,
        directory=args.directory,
        overwrite=args.overwrite,
        quiet=args.quiet,
        retries=args.retries,
        chunk_size=args.chunk_size,
        timeout=args.timeout,
        user_agent=args.user_agent,
        headers=_parse_headers(args.add_header),
        update_check=not args.no_update_check,
        progress_hook=None if args.quiet else _print_progress,
    )
    downloader = Downloader(options=options)

    try:
        if args.print_info:
            info = downloader.extract_info(args.url, options)
            print(json.dumps(_info_to_dict(info), indent=2, ensure_ascii=False))
            return 0

        if args.list_formats:
            info = downloader.extract_info(args.url, options)
            _print_formats(info)
            return 0

        result = downloader.download(args.url, options)
        if not args.quiet:
            print()
            print(f"Downloaded: {result.path} ({result.bytes_written} bytes)")
        return 0
    except BentuError as error:
        print(f"bentu: error: {error}", file=sys.stderr)
        return 1


def _info_to_dict(info: MediaInfo) -> dict:
    data = asdict(info)
    data["formats"] = [asdict(item) for item in info.formats]
    return data


def _print_formats(info: MediaInfo) -> None:
    print(f"Title: {info.title}")
    print("Formats:")
    for item in info.formats:
        print(_format_line(item))


def _format_line(item: MediaFormat) -> str:
    size = f"{item.filesize} bytes" if item.filesize is not None else "unknown size"
    quality = item.quality or item.media_type
    ext = item.ext or "unknown"
    return f"  {item.format_id:12} {ext:6} {quality:12} {size}  {item.url}"


def _parse_headers(values: list[str]) -> dict[str, str]:
    headers: dict[str, str] = {}
    for value in values:
        if ":" not in value:
            raise SystemExit(f"Invalid --add-header value: {value!r}. Expected KEY:VALUE.")
        key, header_value = value.split(":", 1)
        key = key.strip()
        if not key:
            raise SystemExit(f"Invalid --add-header value: {value!r}. Header name is empty.")
        headers[key] = header_value.strip()
    return headers


def _print_progress(downloaded: int, total: int | None) -> None:
    if total:
        percent = downloaded / total * 100
        message = f"\rDownloading: {downloaded}/{total} bytes ({percent:5.1f}%)"
    else:
        message = f"\rDownloading: {downloaded} bytes"
    print(message, end="", file=sys.stderr, flush=True)
