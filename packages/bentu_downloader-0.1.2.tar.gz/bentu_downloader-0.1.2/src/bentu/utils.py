from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import unquote, urlparse


MEDIA_EXTENSIONS = {
    ".3gp",
    ".aac",
    ".flac",
    ".m4a",
    ".m4v",
    ".mkv",
    ".mov",
    ".mp3",
    ".mp4",
    ".mpeg",
    ".mpg",
    ".ogg",
    ".opus",
    ".ts",
    ".wav",
    ".webm",
}


def guess_ext(url: str, content_type: str | None = None) -> str | None:
    path = unquote(urlparse(url).path)
    suffix = Path(path).suffix.lower().strip(".")
    if suffix:
        return "ts" if suffix == "m2ts" else suffix

    if not content_type:
        return None

    content_type = content_type.split(";")[0].strip().lower()
    mapping = {
        "application/vnd.apple.mpegurl": "m3u8",
        "application/x-mpegurl": "m3u8",
        "audio/aac": "aac",
        "audio/flac": "flac",
        "audio/mpeg": "mp3",
        "audio/mp4": "m4a",
        "audio/ogg": "ogg",
        "video/mp2t": "ts",
        "video/mp4": "mp4",
        "video/quicktime": "mov",
        "video/webm": "webm",
        "video/x-matroska": "mkv",
    }
    return mapping.get(content_type)


def is_probably_media_url(url: str) -> bool:
    suffix = Path(unquote(urlparse(url).path)).suffix.lower()
    return suffix in MEDIA_EXTENSIONS or suffix == ".m3u8"


def is_hls_url(url: str, content_type: str | None = None) -> bool:
    ext = guess_ext(url, content_type)
    return ext == "m3u8"


def sanitize_filename(value: str, replacement: str = "_") -> str:
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", replacement, value)
    value = re.sub(r"\s+", " ", value).strip()
    return value.strip(". ") or "video"


def title_from_url(url: str) -> str:
    parsed = urlparse(url)
    name = Path(unquote(parsed.path)).stem
    return sanitize_filename(name or parsed.netloc or "video")


def resolve_output_path(template: str, title: str, ext: str, directory: str | Path | None = None) -> Path:
    safe_title = sanitize_filename(title)
    safe_ext = sanitize_filename(ext).lower()
    rendered = template.replace("%(title)s", safe_title).replace("%(ext)s", safe_ext)
    path = Path(rendered)
    if directory is not None and not path.is_absolute():
        path = Path(directory) / path
    return path
