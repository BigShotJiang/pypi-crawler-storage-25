from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from .exceptions import DownloadError


@dataclass(slots=True)
class HlsSegment:
    url: str


class HlsDownloader:
    def __init__(
        self,
        user_agent: str,
        timeout: float,
        chunk_size: int,
        headers: dict[str, str] | None = None,
        progress_hook: Callable[[int, int | None], None] | None = None,
    ) -> None:
        self.user_agent = user_agent
        self.timeout = timeout
        self.chunk_size = chunk_size
        self.headers = headers or {}
        self.progress_hook = progress_hook

    def download(self, playlist_url: str, target: Path) -> int:
        playlist = self._fetch_text(playlist_url)
        if "#EXT-X-KEY" in playlist:
            raise DownloadError("Encrypted HLS playlists are not supported.")

        if "#EXT-X-STREAM-INF" in playlist:
            playlist_url = self._select_variant(playlist_url, playlist)
            playlist = self._fetch_text(playlist_url)

        segments = self._parse_segments(playlist_url, playlist)
        if not segments:
            raise DownloadError("HLS playlist did not contain media segments.")

        bytes_written = 0
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("wb") as output:
            for segment in segments:
                request = Request(segment.url, headers=self._headers())
                with urlopen(request, timeout=self.timeout) as response:
                    while True:
                        chunk = response.read(self.chunk_size)
                        if not chunk:
                            break
                        output.write(chunk)
                        bytes_written += len(chunk)
                        if self.progress_hook:
                            self.progress_hook(bytes_written, None)
        return bytes_written

    def _fetch_text(self, url: str) -> str:
        request = Request(url, headers=self._headers())
        with urlopen(request, timeout=self.timeout) as response:
            return response.read().decode("utf-8", errors="replace")

    def _headers(self) -> dict[str, str]:
        return {"User-Agent": self.user_agent, **self.headers}

    def _select_variant(self, playlist_url: str, playlist: str) -> str:
        best_bandwidth = -1
        best_url = None
        pending_bandwidth = 0

        for raw_line in playlist.splitlines():
            line = raw_line.strip()
            if line.startswith("#EXT-X-STREAM-INF"):
                pending_bandwidth = self._parse_bandwidth(line)
            elif line and not line.startswith("#"):
                absolute = urljoin(playlist_url, line)
                if pending_bandwidth >= best_bandwidth:
                    best_bandwidth = pending_bandwidth
                    best_url = absolute
                pending_bandwidth = 0

        if best_url is None:
            raise DownloadError("HLS master playlist did not contain variants.")
        return best_url

    def _parse_bandwidth(self, line: str) -> int:
        marker = "BANDWIDTH="
        if marker not in line:
            return 0
        value = line.split(marker, 1)[1].split(",", 1)[0]
        return int(value) if value.isdigit() else 0

    def _parse_segments(self, playlist_url: str, playlist: str) -> list[HlsSegment]:
        segments: list[HlsSegment] = []
        for raw_line in playlist.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            segments.append(HlsSegment(url=urljoin(playlist_url, line)))
        return segments
