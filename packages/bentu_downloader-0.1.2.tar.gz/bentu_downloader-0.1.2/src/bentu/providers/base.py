from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from bentu.models import DownloadOptions, MediaInfo


@dataclass(slots=True)
class ExtractionContext:
    options: DownloadOptions


class Provider(Protocol):
    name: str

    def supports(self, url: str) -> bool:
        """Return whether this provider should try to extract the URL."""

    def extract(self, url: str, context: ExtractionContext) -> MediaInfo:
        """Extract downloadable formats for the URL."""
