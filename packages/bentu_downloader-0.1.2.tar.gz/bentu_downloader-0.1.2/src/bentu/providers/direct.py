from __future__ import annotations

from urllib.parse import urlparse
from urllib.request import Request, urlopen

from bentu.exceptions import ExtractError
from bentu.models import MediaFormat, MediaInfo
from bentu.providers.base import ExtractionContext
from bentu.utils import guess_ext, is_probably_media_url, title_from_url


class DirectProvider:
    name = "direct"

    def supports(self, url: str) -> bool:
        parsed = urlparse(url)
        return parsed.scheme in {"http", "https"} and is_probably_media_url(url)

    def extract(self, url: str, context: ExtractionContext) -> MediaInfo:
        headers = {"User-Agent": context.options.user_agent, **context.options.headers}
        content_type = None
        filesize = None

        try:
            request = Request(url, method="HEAD", headers=headers)
            with urlopen(request, timeout=context.options.timeout) as response:
                content_type = response.headers.get("Content-Type")
                content_length = response.headers.get("Content-Length")
                filesize = int(content_length) if content_length and content_length.isdigit() else None
        except Exception:
            content_type = None

        ext = guess_ext(url, content_type)
        if not ext:
            raise ExtractError("Could not determine media type for direct URL.")

        media_type = "stream" if ext == "m3u8" else "video"
        return MediaInfo(
            webpage_url=url,
            title=title_from_url(url),
            extractor=self.name,
            formats=[
                MediaFormat(
                    format_id="best",
                    url=url,
                    ext=ext,
                    media_type=media_type,
                    filesize=filesize,
                    headers=headers,
                )
            ],
        )
