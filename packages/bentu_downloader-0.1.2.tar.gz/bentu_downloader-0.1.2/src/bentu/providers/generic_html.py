from __future__ import annotations

import html
import json
import re
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

from bentu.exceptions import ExtractError
from bentu.models import MediaFormat, MediaInfo
from bentu.providers.base import ExtractionContext
from bentu.utils import guess_ext, title_from_url


class GenericHtmlProvider:
    name = "generic-html"

    def supports(self, url: str) -> bool:
        return urlparse(url).scheme in {"http", "https"}

    def extract(self, url: str, context: ExtractionContext) -> MediaInfo:
        headers = {"User-Agent": context.options.user_agent, **context.options.headers}
        request = Request(url, headers=headers)
        with urlopen(request, timeout=context.options.timeout) as response:
            content_type = response.headers.get("Content-Type", "")
            if "text/html" not in content_type and "application/xhtml" not in content_type:
                raise ExtractError(f"URL is not an HTML page: {content_type or 'unknown content type'}")
            raw = response.read(2_000_000)

        page = raw.decode("utf-8", errors="replace")
        title = self._extract_title(page) or title_from_url(url)
        formats = self._extract_formats(url, page, headers)
        if not formats:
            raise ExtractError("No downloadable video URL was found in the HTML page.")

        return MediaInfo(webpage_url=url, title=title, extractor=self.name, formats=formats)

    def _extract_title(self, page: str) -> str | None:
        match = re.search(r"<title[^>]*>(.*?)</title>", page, flags=re.IGNORECASE | re.DOTALL)
        if match:
            return html.unescape(re.sub(r"\s+", " ", match.group(1))).strip()

        for attr in ("og:title", "twitter:title"):
            match = re.search(
                rf'<meta[^>]+(?:property|name)=["\']{re.escape(attr)}["\'][^>]+content=["\']([^"\']+)["\']',
                page,
                flags=re.IGNORECASE,
            )
            if match:
                return html.unescape(match.group(1)).strip()
        return None

    def _extract_formats(self, base_url: str, page: str, headers: dict[str, str]) -> list[MediaFormat]:
        urls: list[str] = []

        patterns = [
            r'<meta[^>]+property=["\']og:video(?::url)?["\'][^>]+content=["\']([^"\']+)["\']',
            r'<meta[^>]+property=["\']og:video:secure_url["\'][^>]+content=["\']([^"\']+)["\']',
            r'<meta[^>]+name=["\']twitter:player:stream["\'][^>]+content=["\']([^"\']+)["\']',
            r'<source[^>]+src=["\']([^"\']+)["\']',
            r'<video[^>]+src=["\']([^"\']+)["\']',
            r'["\'](?:contentUrl|embedUrl|playable_url|video_url|media_url|downloadUrl|download_url)["\']\s*:\s*["\']([^"\']+)["\']',
        ]
        for pattern in patterns:
            urls.extend(re.findall(pattern, page, flags=re.IGNORECASE))

        urls.extend(self._extract_json_ld_urls(page))
        urls.extend(self._extract_visible_media_urls(page))

        formats: list[MediaFormat] = []
        seen: set[str] = set()
        for index, media_url in enumerate(urls, start=1):
            media_url = html.unescape(media_url.strip())
            media_url = media_url.replace("\\/", "/")
            if not media_url:
                continue
            absolute = urljoin(base_url, media_url)
            if absolute in seen:
                continue
            seen.add(absolute)
            ext = guess_ext(absolute) or "mp4"
            formats.append(
                MediaFormat(
                    format_id=f"html-{index}",
                    url=absolute,
                    ext=ext,
                    media_type="stream" if ext == "m3u8" else "video",
                    headers=headers,
                )
            )

        return formats

    def _extract_visible_media_urls(self, page: str) -> list[str]:
        media_url_pattern = (
            r'https?:\\?/\\?/[^"\'<>\s]+?'
            r'(?:\.mp4|\.m4v|\.webm|\.mov|\.m3u8|\.mp3|\.m4a|\.aac|\.ogg)'
            r'(?:\?[^"\'<>\s]*)?'
        )
        return [item.replace("\\/", "/") for item in re.findall(media_url_pattern, page, flags=re.IGNORECASE)]

    def _extract_json_ld_urls(self, page: str) -> list[str]:
        urls: list[str] = []
        scripts = re.findall(
            r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
            page,
            flags=re.IGNORECASE | re.DOTALL,
        )
        for script in scripts:
            try:
                data = json.loads(html.unescape(script.strip()))
            except json.JSONDecodeError:
                continue
            self._walk_json_ld(data, urls)
        return urls

    def _walk_json_ld(self, value, urls: list[str]) -> None:
        if isinstance(value, dict):
            for key in ("contentUrl", "embedUrl"):
                item = value.get(key)
                if isinstance(item, str):
                    urls.append(item)
            for item in value.values():
                self._walk_json_ld(item, urls)
        elif isinstance(value, list):
            for item in value:
                self._walk_json_ld(item, urls)
