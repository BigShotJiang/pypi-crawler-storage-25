from __future__ import annotations

from urllib.parse import urlparse

from bentu.exceptions import ExtractError
from bentu.providers.base import ExtractionContext


class PlatformNoticeProvider:
    """Known-platform guardrail for sites that need platform-specific extractors."""

    name = "platform-notice"

    _known_hosts = {
        "facebook.com": "Facebook",
        "www.facebook.com": "Facebook",
        "fb.watch": "Facebook",
        "instagram.com": "Instagram",
        "www.instagram.com": "Instagram",
        "mobile.instagram.com": "Instagram",
        "youtube.com": "YouTube",
        "www.youtube.com": "YouTube",
        "youtu.be": "YouTube",
        "m.youtube.com": "YouTube",
        "tiktok.com": "TikTok",
        "www.tiktok.com": "TikTok",
        "vm.tiktok.com": "TikTok",
        "voe.sx": "VOE",
        "www.voe.sx": "VOE",
        "vimeo.com": "Vimeo",
        "www.vimeo.com": "Vimeo",
        "filmora.wondershare.com": "Filmora",
        "www.filmora.wondershare.com": "Filmora",
        "megakino.co": "movie-streaming site",
        "megakino.to": "movie-streaming site",
        "megakino.tv": "movie-streaming site",
        "x.com": "X",
        "www.x.com": "X",
        "twitter.com": "X",
        "www.twitter.com": "X",
    }

    def supports(self, url: str) -> bool:
        host = urlparse(url).netloc.lower()
        return any(host == known or host.endswith(f".{known}") for known in self._known_hosts)

    def extract(self, url: str, context: ExtractionContext):
        host = urlparse(url).netloc.lower()
        platform = next(
            (name for known, name in self._known_hosts.items() if host == known or host.endswith(f".{known}")),
            "this platform",
        )
        raise ExtractError(
            f"{platform} needs a dedicated extractor or does not expose a public downloadable media URL on this page. "
            "Bentu downloads direct public media and simple public streams, but does not bypass access controls."
        )
