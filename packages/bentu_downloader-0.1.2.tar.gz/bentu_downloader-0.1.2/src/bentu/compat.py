from __future__ import annotations

from dataclasses import asdict
from typing import Iterable

from ._version import USER_AGENT
from .downloader import Downloader
from .models import DownloadOptions, DownloadResult, MediaInfo


class BentuDL:
    """Small high-level option wrapper.

    It intentionally supports only the common options that map cleanly to
    Bentu's core API.
    """

    def __init__(self, params: dict | None = None) -> None:
        self.params = params or {}
        self.options = self._options_from_params(self.params)
        self.downloader = Downloader(options=self.options)

    def extract_info(self, url: str, download: bool = True) -> dict:
        if download:
            result = self.downloader.download(url, self.options)
            data = _result_to_dict(result)
            data["requested_downloads"] = [{"filepath": str(result.path)}]
            return data
        return _info_to_dict(self.downloader.extract_info(url, self.options))

    def download(self, urls: str | Iterable[str]) -> int:
        if isinstance(urls, str):
            urls = [urls]

        errors = 0
        for url in urls:
            try:
                self.downloader.download(url, self.options)
            except Exception:
                errors += 1
                if not self.params.get("ignoreerrors"):
                    raise
        return errors

    def __enter__(self) -> "BentuDL":
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False

    def _options_from_params(self, params: dict) -> DownloadOptions:
        paths = params.get("paths") or {}
        headers = dict(params.get("headers") or {})

        return DownloadOptions(
            output=params.get("outtmpl") or params.get("output") or "%(title)s.%(ext)s",
            format=params.get("format") or "best",
            directory=paths.get("home") if isinstance(paths, dict) else None,
            overwrite=bool(params.get("overwrites") or params.get("force_overwrites")),
            quiet=bool(params.get("quiet")),
            retries=int(params.get("retries", 2)),
            chunk_size=int(params.get("buffersize", 1024 * 256)),
            timeout=float(params.get("socket_timeout", 30.0)),
            user_agent=params.get("user_agent") or USER_AGENT,
            headers=headers,
        )


def _info_to_dict(info: MediaInfo) -> dict:
    return asdict(info)


def _result_to_dict(result: DownloadResult) -> dict:
    data = _info_to_dict(result.info)
    data["filepath"] = str(result.path)
    data["bytes_written"] = result.bytes_written
    data["format"] = asdict(result.format)
    return data
