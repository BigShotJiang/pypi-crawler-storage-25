from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from ._version import USER_AGENT


@dataclass(slots=True)
class MediaFormat:
    """A downloadable media representation."""

    format_id: str
    url: str
    ext: str | None = None
    quality: str | None = None
    media_type: str = "video"
    filesize: int | None = None
    headers: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class MediaInfo:
    """Extracted information for a URL."""

    webpage_url: str
    title: str
    formats: list[MediaFormat]
    id: str | None = None
    description: str | None = None
    thumbnail: str | None = None
    duration: float | None = None
    extractor: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class DownloadOptions:
    """Options accepted by the Python API and CLI."""

    output: str = "%(title)s.%(ext)s"
    format: str = "best"
    directory: str | Path | None = None
    overwrite: bool = False
    quiet: bool = False
    chunk_size: int = 1024 * 256
    timeout: float = 30.0
    retries: int = 2
    user_agent: str = USER_AGENT
    headers: dict[str, str] = field(default_factory=dict)
    update_check: bool = True
    progress_hook: Callable[[int, int | None], None] | None = field(default=None, repr=False)


@dataclass(slots=True)
class DownloadResult:
    """Result returned after a successful download."""

    path: Path
    info: MediaInfo
    format: MediaFormat
    bytes_written: int
