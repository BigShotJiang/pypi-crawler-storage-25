from __future__ import annotations

from pathlib import Path
from time import sleep
from urllib.request import Request, urlopen

from .exceptions import DownloadError, ExtractError, UnsupportedURLError
from .hls import HlsDownloader
from .models import DownloadOptions, DownloadResult, MediaFormat, MediaInfo
from .providers import DirectProvider, ExtractionContext, GenericHtmlProvider, PlatformNoticeProvider, Provider
from .utils import is_hls_url, resolve_output_path


class Downloader:
    """Main Bentu downloader."""

    def __init__(self, providers: list[Provider] | None = None, options: DownloadOptions | None = None) -> None:
        self.options = options or DownloadOptions()
        self.providers = providers or [
            DirectProvider(),
            GenericHtmlProvider(),
            PlatformNoticeProvider(),
        ]

    def extract_info(self, url: str, options: DownloadOptions | None = None) -> MediaInfo:
        options = options or self.options
        context = ExtractionContext(options=options)
        errors: list[str] = []

        for provider in self.providers:
            if not provider.supports(url):
                continue
            try:
                return provider.extract(url, context)
            except ExtractError as error:
                errors.append(f"{provider.name}: {error}")
                continue

        if errors:
            raise ExtractError("; ".join(errors))
        raise UnsupportedURLError(f"No provider supports this URL: {url}")

    def download(self, url: str, options: DownloadOptions | None = None) -> DownloadResult:
        options = options or self.options
        info = self.extract_info(url, options)
        selected = self._select_format(info, options.format)
        ext = selected.ext or "mp4"
        target = resolve_output_path(options.output, info.title, ext, options.directory)

        if target.exists() and not options.overwrite:
            raise DownloadError(f"Target file already exists: {target}")

        if is_hls_url(selected.url) or selected.media_type == "stream":
            bytes_written = HlsDownloader(
                user_agent=options.user_agent,
                timeout=options.timeout,
                chunk_size=options.chunk_size,
                headers=options.headers,
                progress_hook=None if options.quiet else options.progress_hook,
            ).download(selected.url, target)
        else:
            bytes_written = self._download_http(selected, target, options)

        return DownloadResult(path=target, info=info, format=selected, bytes_written=bytes_written)

    def _select_format(self, info: MediaInfo, format_selector: str) -> MediaFormat:
        if not info.formats:
            raise ExtractError("No formats were extracted.")

        if format_selector in {"best", ""}:
            return info.formats[0]

        for media_format in info.formats:
            if media_format.format_id == format_selector:
                return media_format

        available = ", ".join(item.format_id for item in info.formats)
        raise ExtractError(f"Format '{format_selector}' was not found. Available formats: {available}")

    def _download_http(self, media_format: MediaFormat, target: Path, options: DownloadOptions) -> int:
        headers = {"User-Agent": options.user_agent, **options.headers}
        headers.update(media_format.headers)

        last_error: Exception | None = None
        for attempt in range(max(1, options.retries + 1)):
            request = Request(media_format.url, headers=headers)
            bytes_written = 0
            target.parent.mkdir(parents=True, exist_ok=True)
            try:
                with urlopen(request, timeout=options.timeout) as response, target.open("wb") as output:
                    total = _content_length(response.headers.get("Content-Length"))
                    while True:
                        chunk = response.read(options.chunk_size)
                        if not chunk:
                            break
                        output.write(chunk)
                        bytes_written += len(chunk)
                        if options.progress_hook and not options.quiet:
                            options.progress_hook(bytes_written, total)
                return bytes_written
            except Exception as error:
                last_error = error
                if target.exists():
                    target.unlink(missing_ok=True)
                if attempt < options.retries:
                    sleep(min(2**attempt, 5))
                    continue
                break

        raise DownloadError(f"Download failed: {last_error}") from last_error


def _content_length(value: str | None) -> int | None:
    return int(value) if value and value.isdigit() else None
