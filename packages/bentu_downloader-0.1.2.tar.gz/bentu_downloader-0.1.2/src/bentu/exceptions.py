class BentuError(Exception):
    """Base error raised by Bentu."""


class UnsupportedURLError(BentuError):
    """Raised when no provider can handle a URL."""


class ExtractError(BentuError):
    """Raised when a provider cannot extract usable media."""


class DownloadError(BentuError):
    """Raised when a media download fails."""


class UpdateCheckError(BentuError):
    """Raised when the PyPI update check fails."""
