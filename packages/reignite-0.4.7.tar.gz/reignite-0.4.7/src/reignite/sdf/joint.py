### THIS FILE WAS AUTO-GENERATED ###
from __future__ import annotations

import typing
from xml.etree import ElementTree as ET

from typing import List

from ..utils.model import BaseModel
from ..utils.errors import SDFError
from ..utils.pose import Pose as _SDFPose
from ..utils.vector3 import Vector3 as _SDFVector3
from ..utils.version import cmp_version
from ..utils.migration import apply_migrations

if typing.TYPE_CHECKING:
    from ..elements.frame import Frame
    from ..elements.mimic import Mimic
    from ..elements.pose import Pose
    from ..elements.sensor import Sensor


import math

def _parse_int32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (-2147483648 <= v <= 2147483647):
            return SDFError(f"int32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid int32: {raw}")


def _parse_uint32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (0 <= v <= 4294967295):
            return SDFError(f"uint32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid uint32: {raw}")


def _parse_double(raw: str) -> float | SDFError:
    try:
        v = float(raw)
        if not math.isfinite(v) or abs(v) > math.inf:
            return SDFError(f"double out of range: {raw}")
        return v
    except ValueError:
        return SDFError(f"Invalid double: {raw}")



class Joint(BaseModel):
    class Axis(BaseModel):
        class Dynamics(BaseModel):
            def __init__(
                self,
                sdf_version: str | None = None,
                damping: float = 0,
                friction: float = 0,
                spring_reference: float = 0,
                spring_stiffness: float = 0
            ):
                super().__init__(sdf_version)
                self.damping = damping
                self.friction = friction
                self.spring_reference = spring_reference
                self.spring_stiffness = spring_stiffness

            def to_version(self, target_version: str) -> "Joint.Axis.Dynamics":
                if self.damping is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'damping' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.friction is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'friction' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.spring_reference is not None and cmp_version(target_version, "1.5") < 0:
                    raise ValueError(f"'spring_reference' is not supported in SDF version {target_version} (added in 1.5)")
                if self.spring_stiffness is not None and cmp_version(target_version, "1.5") < 0:
                    raise ValueError(f"'spring_stiffness' is not supported in SDF version {target_version} (added in 1.5)")
                kwargs = {"sdf_version": target_version}
                kwargs["damping"] = self.damping
                kwargs["friction"] = self.friction
                kwargs["spring_reference"] = self.spring_reference
                kwargs["spring_stiffness"] = self.spring_stiffness
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("dynamics")
                if self.damping is not None:
                    el.set("damping", str(self.damping))
                if self.friction is not None:
                    el.set("friction", str(self.friction))
                if self.spring_reference is not None:
                    _c_tmp = ET.Element("spring_reference")
                    _c_tmp.text = str(self.spring_reference)
                    el.append(_c_tmp)
                if self.spring_stiffness is not None:
                    _c_tmp = ET.Element("spring_stiffness")
                    _c_tmp.text = str(self.spring_stiffness)
                    el.append(_c_tmp)
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis.Dynamics | SDFError":
                _damping = _parse_double(el.get("damping", 0))
                if isinstance(_damping, SDFError):
                    return _damping.extend("@damping")
                _friction = _parse_double(el.get("friction", 0))
                if isinstance(_friction, SDFError):
                    return _friction.extend("@friction")
                _c_tmp = el.find("spring_reference")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("spring_reference")
                    _spring_reference = _val
                else:
                    _spring_reference = None
                if _spring_reference is not None and cmp_version(version, "1.5") < 0:
                    return SDFError(f"'spring_reference' is not supported in SDF version {version} (added in 1.5)")
                _c_tmp = el.find("spring_stiffness")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("spring_stiffness")
                    _spring_stiffness = _val
                else:
                    _spring_stiffness = None
                if _spring_stiffness is not None and cmp_version(version, "1.5") < 0:
                    return SDFError(f"'spring_stiffness' is not supported in SDF version {version} (added in 1.5)")
                return cls(sdf_version=version, damping=_damping, friction=_friction, spring_reference=_spring_reference, spring_stiffness=_spring_stiffness)

        class Limit(BaseModel):
            def __init__(
                self,
                sdf_version: str | None = None,
                dissipation: float = 1.0,
                effort: float = 0,
                lower: float = -1e16,
                stiffness: float = 1e8,
                upper: float = 1e16,
                velocity: float = 0
            ):
                super().__init__(sdf_version)
                self.dissipation = dissipation
                self.effort = effort
                self.lower = lower
                self.stiffness = stiffness
                self.upper = upper
                self.velocity = velocity

            def to_version(self, target_version: str) -> "Joint.Axis.Limit":
                if self.dissipation is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'dissipation' is not supported in SDF version {target_version} (added in 1.4)")
                if self.effort is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'effort' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.lower is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'lower' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.stiffness is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'stiffness' is not supported in SDF version {target_version} (added in 1.4)")
                if self.upper is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'upper' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.velocity is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'velocity' is not supported in SDF version {target_version} (removed in 1.2)")
                kwargs = {"sdf_version": target_version}
                kwargs["dissipation"] = self.dissipation
                kwargs["effort"] = self.effort
                kwargs["lower"] = self.lower
                kwargs["stiffness"] = self.stiffness
                kwargs["upper"] = self.upper
                kwargs["velocity"] = self.velocity
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("limit")
                if self.dissipation is not None:
                    _c_tmp = ET.Element("dissipation")
                    _c_tmp.text = str(self.dissipation)
                    el.append(_c_tmp)
                if self.effort is not None:
                    el.set("effort", str(self.effort))
                if self.lower is not None:
                    el.set("lower", str(self.lower))
                if self.stiffness is not None:
                    _c_tmp = ET.Element("stiffness")
                    _c_tmp.text = str(self.stiffness)
                    el.append(_c_tmp)
                if self.upper is not None:
                    el.set("upper", str(self.upper))
                if self.velocity is not None:
                    el.set("velocity", str(self.velocity))
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis.Limit | SDFError":
                _c_tmp = el.find("dissipation")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 1.0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("dissipation")
                    _dissipation = _val
                else:
                    _dissipation = None
                if _dissipation is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'dissipation' is not supported in SDF version {version} (added in 1.4)")
                _effort = _parse_double(el.get("effort", 0))
                if isinstance(_effort, SDFError):
                    return _effort.extend("@effort")
                _lower = _parse_double(el.get("lower", -1e16))
                if isinstance(_lower, SDFError):
                    return _lower.extend("@lower")
                _c_tmp = el.find("stiffness")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 1e8
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("stiffness")
                    _stiffness = _val
                else:
                    _stiffness = None
                if _stiffness is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'stiffness' is not supported in SDF version {version} (added in 1.4)")
                _upper = _parse_double(el.get("upper", 1e16))
                if isinstance(_upper, SDFError):
                    return _upper.extend("@upper")
                _velocity = _parse_double(el.get("velocity", 0))
                if isinstance(_velocity, SDFError):
                    return _velocity.extend("@velocity")
                return cls(sdf_version=version, dissipation=_dissipation, effort=_effort, lower=_lower, stiffness=_stiffness, upper=_upper, velocity=_velocity)

        class Xyz(BaseModel):
            def __init__(
                self,
                sdf_version: str | None = None,
                expressed_in: str = "",
                xyz: _SDFVector3 = None
            ):
                super().__init__(sdf_version)
                if xyz is None:
                    xyz = _SDFVector3.from_sdf("0 0 1", version=sdf_version)
                self.expressed_in = expressed_in
                self.xyz = xyz

            def to_version(self, target_version: str) -> "Joint.Axis.Xyz":
                if self.expressed_in is not None and cmp_version(target_version, "1.7") < 0:
                    raise ValueError(f"'expressed_in' is not supported in SDF version {target_version} (added in 1.7)")
                if self.xyz is not None and cmp_version(target_version, "1.2") < 0:
                    raise ValueError(f"'xyz' is not supported in SDF version {target_version} (added in 1.2)")
                kwargs = {"sdf_version": target_version}
                kwargs["expressed_in"] = self.expressed_in
                kwargs["xyz"] = self.xyz
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("xyz")
                if self.expressed_in is not None:
                    el.set("expressed_in", self.expressed_in)
                if self.xyz is not None:
                    el.text = self.xyz.to_sdf(version)
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis.Xyz | SDFError":
                _expressed_in = el.get("expressed_in", "")
                if isinstance(_expressed_in, SDFError):
                    return _expressed_in.extend("@expressed_in")
                if _expressed_in is not None and cmp_version(version, "1.7") < 0:
                    if _expressed_in != "":
                        return SDFError(f"'expressed_in' is not supported in SDF version {version} (added in 1.7)")
                _text = el.text or "0 0 1"
                _xyz = _SDFVector3._from_sdf(_text, version)
                if isinstance(_xyz, SDFError):
                    return _xyz
                if _xyz is not None and cmp_version(version, "1.2") < 0:
                    if _xyz != "0 0 1":
                        return SDFError(f"'xyz' is not supported in SDF version {version} (added in 1.2)")
                return cls(sdf_version=version, expressed_in=_expressed_in, xyz=_xyz)

        _MIGRATIONS = [{"version": "1.7", "ops": [{"type": "map", "from": "use_parent_model_frame", "to": "xyz::expressed_in", "from_values": ["true", "True", "TRUE", "1"], "to_value": "__model__"}]}]

        def __init__(
            self,
            sdf_version: str | None = None,
            dynamics: "Joint.Axis.Dynamics" = None,
            initial_position: float = 0,
            limit: "Joint.Axis.Limit" = None,
            mimic: "Mimic" = None,
            use_parent_model_frame: bool = False,
            xyz: _SDFVector3 = None
        ):
            super().__init__(sdf_version)
            if xyz is None:
                xyz = _SDFVector3.from_sdf("0 0 1", version=sdf_version)
            self.dynamics = dynamics
            self.initial_position = initial_position
            self.limit = limit
            self.mimic = mimic
            self.use_parent_model_frame = use_parent_model_frame
            self.xyz = xyz
            if self.dynamics is not None:
                if getattr(self.dynamics, '__version__', None) is None:
                    self.dynamics.__version__ = self.__version__
                elif getattr(self.dynamics, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.dynamics = self.dynamics.to_version(self.__version__)
            if self.limit is not None:
                if getattr(self.limit, '__version__', None) is None:
                    self.limit.__version__ = self.__version__
                elif getattr(self.limit, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.limit = self.limit.to_version(self.__version__)
            if self.mimic is not None:
                if getattr(self.mimic, '__version__', None) is None:
                    self.mimic.__version__ = self.__version__
                elif getattr(self.mimic, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.mimic = self.mimic.to_version(self.__version__)

        def to_version(self, target_version: str) -> "Joint.Axis":
            from ..elements.mimic import Mimic
            if self.initial_position is not None and cmp_version(target_version, "1.6") < 0:
                raise ValueError(f"'initial_position' is not supported in SDF version {target_version} (added in 1.6)")
            if self.initial_position is not None and cmp_version(target_version, "1.9") >= 0:
                raise ValueError(f"'initial_position' is not supported in SDF version {target_version} (removed in 1.9)")
            if self.mimic is not None and cmp_version(target_version, "1.11") < 0:
                raise ValueError(f"'mimic' is not supported in SDF version {target_version} (added in 1.11)")
            if self.use_parent_model_frame is not None and cmp_version(target_version, "1.5") < 0:
                raise ValueError(f"'use_parent_model_frame' is not supported in SDF version {target_version} (added in 1.5)")
            if self.use_parent_model_frame is not None and cmp_version(target_version, "1.7") >= 0:
                raise ValueError(f"'use_parent_model_frame' is not supported in SDF version {target_version} (removed in 1.7)")
            if self.xyz is not None and cmp_version(target_version, "1.2") >= 0:
                raise ValueError(f"'xyz' is not supported in SDF version {target_version} (removed in 1.2)")
            kwargs = {"sdf_version": target_version}
            kwargs["dynamics"] = self.dynamics.to_version(target_version) if self.dynamics is not None else None
            kwargs["initial_position"] = self.initial_position
            kwargs["limit"] = self.limit.to_version(target_version) if self.limit is not None else None
            kwargs["mimic"] = self.mimic.to_version(target_version) if self.mimic is not None else None
            kwargs["use_parent_model_frame"] = self.use_parent_model_frame
            kwargs["xyz"] = self.xyz
            new_obj = self.__class__(**kwargs)
            apply_migrations(new_obj, target_version)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            from ..elements.mimic import Mimic
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("axis")
            if self.dynamics is not None:
                el.append(self.dynamics.to_sdf(version))
            if self.initial_position is not None:
                _c_tmp = ET.Element("initial_position")
                _c_tmp.text = str(self.initial_position)
                el.append(_c_tmp)
            if self.limit is None:
                self.limit = self.__class__.Limit(sdf_version=version)
            if self.limit is not None:
                el.append(self.limit.to_sdf(version))
            if self.mimic is not None:
                el.append(self.mimic.to_sdf(version))
            if self.use_parent_model_frame is not None:
                _c_tmp = ET.Element("use_parent_model_frame")
                _c_tmp.text = str(self.use_parent_model_frame).lower()
                el.append(_c_tmp)
            if self.xyz is not None:
                el.set("xyz", self.xyz.to_sdf(version))
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis | SDFError":
            from ..elements.mimic import Mimic
            _c_dynamics = el.find("dynamics")
            if _c_dynamics is not None:
                _res = cls.Dynamics._from_sdf(_c_dynamics, version)
                if isinstance(_res, SDFError):
                    return _res.extend("dynamics")
                _dynamics = _res
            else:
                _dynamics = None
            _c_tmp = el.find("initial_position")
            if _c_tmp is not None:
                _text = _c_tmp.text if _c_tmp.text is not None else 0
                _val = _parse_double(_text)
                if isinstance(_val, SDFError):
                    return _val.extend("initial_position")
                _initial_position = _val
            else:
                _initial_position = None
            if _initial_position is not None and cmp_version(version, "1.6") < 0:
                return SDFError(f"'initial_position' is not supported in SDF version {version} (added in 1.6)")
            _c_limit = el.find("limit")
            if _c_limit is not None:
                _res = cls.Limit._from_sdf(_c_limit, version)
                if isinstance(_res, SDFError):
                    return _res.extend("limit")
                _limit = _res
            else:
                _res = cls.Limit._from_sdf(ET.Element("limit"), version)
                if isinstance(_res, SDFError):
                    return _res.extend("limit")
                _limit = _res
            _c_mimic = el.find("mimic")
            if _c_mimic is not None:
                _res = Mimic._from_sdf(_c_mimic, version)
                if isinstance(_res, SDFError):
                    return _res.extend("mimic")
                _mimic = _res
            else:
                _mimic = None
            if _mimic is not None and cmp_version(version, "1.11") < 0:
                return SDFError(f"'mimic' is not supported in SDF version {version} (added in 1.11)")
            _c_tmp = el.find("use_parent_model_frame")
            if _c_tmp is not None:
                _text = _c_tmp.text if _c_tmp.text is not None else False
                _val = str(_text).strip().lower() == 'true'
                if isinstance(_val, SDFError):
                    return _val.extend("use_parent_model_frame")
                _use_parent_model_frame = _val
            else:
                _use_parent_model_frame = None
            if _use_parent_model_frame is not None and cmp_version(version, "1.5") < 0:
                return SDFError(f"'use_parent_model_frame' is not supported in SDF version {version} (added in 1.5)")
            _xyz = _SDFVector3._from_sdf(el.get("xyz", "0 0 1"), version)
            if isinstance(_xyz, SDFError):
                return _xyz.extend("@xyz")
            return cls(sdf_version=version, dynamics=_dynamics, initial_position=_initial_position, limit=_limit, mimic=_mimic, use_parent_model_frame=_use_parent_model_frame, xyz=_xyz)

    class Axis2(BaseModel):
        class Axis2Limit(BaseModel):
            def __init__(
                self,
                sdf_version: str | None = None,
                dissipation: float = 1.0,
                effort: float = 0,
                lower: float = -1e16,
                stiffness: float = 1e8,
                upper: float = 1e16,
                velocity: float = 0
            ):
                super().__init__(sdf_version)
                self.dissipation = dissipation
                self.effort = effort
                self.lower = lower
                self.stiffness = stiffness
                self.upper = upper
                self.velocity = velocity

            def to_version(self, target_version: str) -> "Joint.Axis2.Axis2Limit":
                if self.dissipation is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'dissipation' is not supported in SDF version {target_version} (added in 1.4)")
                if self.effort is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'effort' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.lower is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'lower' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.stiffness is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'stiffness' is not supported in SDF version {target_version} (added in 1.4)")
                if self.upper is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'upper' is not supported in SDF version {target_version} (removed in 1.2)")
                if self.velocity is not None and cmp_version(target_version, "1.2") >= 0:
                    raise ValueError(f"'velocity' is not supported in SDF version {target_version} (removed in 1.2)")
                kwargs = {"sdf_version": target_version}
                kwargs["dissipation"] = self.dissipation
                kwargs["effort"] = self.effort
                kwargs["lower"] = self.lower
                kwargs["stiffness"] = self.stiffness
                kwargs["upper"] = self.upper
                kwargs["velocity"] = self.velocity
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("limit")
                if self.dissipation is not None:
                    _c_tmp = ET.Element("dissipation")
                    _c_tmp.text = str(self.dissipation)
                    el.append(_c_tmp)
                if self.effort is not None:
                    el.set("effort", str(self.effort))
                if self.lower is not None:
                    el.set("lower", str(self.lower))
                if self.stiffness is not None:
                    _c_tmp = ET.Element("stiffness")
                    _c_tmp.text = str(self.stiffness)
                    el.append(_c_tmp)
                if self.upper is not None:
                    el.set("upper", str(self.upper))
                if self.velocity is not None:
                    el.set("velocity", str(self.velocity))
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis2.Axis2Limit | SDFError":
                _c_tmp = el.find("dissipation")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 1.0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("dissipation")
                    _dissipation = _val
                else:
                    _dissipation = None
                if _dissipation is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'dissipation' is not supported in SDF version {version} (added in 1.4)")
                _effort = _parse_double(el.get("effort", 0))
                if isinstance(_effort, SDFError):
                    return _effort.extend("@effort")
                _lower = _parse_double(el.get("lower", -1e16))
                if isinstance(_lower, SDFError):
                    return _lower.extend("@lower")
                _c_tmp = el.find("stiffness")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 1e8
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("stiffness")
                    _stiffness = _val
                else:
                    _stiffness = None
                if _stiffness is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'stiffness' is not supported in SDF version {version} (added in 1.4)")
                _upper = _parse_double(el.get("upper", 1e16))
                if isinstance(_upper, SDFError):
                    return _upper.extend("@upper")
                _velocity = _parse_double(el.get("velocity", 0))
                if isinstance(_velocity, SDFError):
                    return _velocity.extend("@velocity")
                return cls(sdf_version=version, dissipation=_dissipation, effort=_effort, lower=_lower, stiffness=_stiffness, upper=_upper, velocity=_velocity)

        _MIGRATIONS = [{"version": "1.7", "ops": [{"type": "map", "from": "use_parent_model_frame", "to": "xyz::expressed_in", "from_values": ["true", "True", "TRUE", "1"], "to_value": "__model__"}]}]

        def __init__(
            self,
            sdf_version: str | None = None,
            dynamics: "Dynamics" = None,
            initial_position: float = 0,
            limit: "Joint.Axis2.Axis2Limit" = None,
            mimic: "Mimic" = None,
            use_parent_model_frame: bool = False,
            xyz: _SDFVector3 = None
        ):
            super().__init__(sdf_version)
            if xyz is None:
                xyz = _SDFVector3.from_sdf("0 0 1", version=sdf_version)
            self.dynamics = dynamics
            self.initial_position = initial_position
            self.limit = limit
            self.mimic = mimic
            self.use_parent_model_frame = use_parent_model_frame
            self.xyz = xyz
            if self.dynamics is not None:
                if getattr(self.dynamics, '__version__', None) is None:
                    self.dynamics.__version__ = self.__version__
                elif getattr(self.dynamics, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.dynamics = self.dynamics.to_version(self.__version__)
            if self.limit is not None:
                if getattr(self.limit, '__version__', None) is None:
                    self.limit.__version__ = self.__version__
                elif getattr(self.limit, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.limit = self.limit.to_version(self.__version__)
            if self.mimic is not None:
                if getattr(self.mimic, '__version__', None) is None:
                    self.mimic.__version__ = self.__version__
                elif getattr(self.mimic, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.mimic = self.mimic.to_version(self.__version__)

        def to_version(self, target_version: str) -> "Joint.Axis2":
            from ..elements.mimic import Mimic
            if self.initial_position is not None and cmp_version(target_version, "1.6") < 0:
                raise ValueError(f"'initial_position' is not supported in SDF version {target_version} (added in 1.6)")
            if self.initial_position is not None and cmp_version(target_version, "1.9") >= 0:
                raise ValueError(f"'initial_position' is not supported in SDF version {target_version} (removed in 1.9)")
            if self.mimic is not None and cmp_version(target_version, "1.11") < 0:
                raise ValueError(f"'mimic' is not supported in SDF version {target_version} (added in 1.11)")
            if self.use_parent_model_frame is not None and cmp_version(target_version, "1.5") < 0:
                raise ValueError(f"'use_parent_model_frame' is not supported in SDF version {target_version} (added in 1.5)")
            if self.use_parent_model_frame is not None and cmp_version(target_version, "1.7") >= 0:
                raise ValueError(f"'use_parent_model_frame' is not supported in SDF version {target_version} (removed in 1.7)")
            if self.xyz is not None and cmp_version(target_version, "1.2") >= 0:
                raise ValueError(f"'xyz' is not supported in SDF version {target_version} (removed in 1.2)")
            kwargs = {"sdf_version": target_version}
            kwargs["dynamics"] = self.dynamics.to_version(target_version) if self.dynamics is not None else None
            kwargs["initial_position"] = self.initial_position
            kwargs["limit"] = self.limit.to_version(target_version) if self.limit is not None else None
            kwargs["mimic"] = self.mimic.to_version(target_version) if self.mimic is not None else None
            kwargs["use_parent_model_frame"] = self.use_parent_model_frame
            kwargs["xyz"] = self.xyz
            new_obj = self.__class__(**kwargs)
            apply_migrations(new_obj, target_version)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            from ..elements.mimic import Mimic
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("axis2")
            if self.dynamics is not None:
                el.append(self.dynamics.to_sdf(version))
            if self.initial_position is not None:
                _c_tmp = ET.Element("initial_position")
                _c_tmp.text = str(self.initial_position)
                el.append(_c_tmp)
            if cmp_version(version, "1.6") >= 0:
                if self.limit is None:
                    self.limit = self.__class__.Axis2Limit(sdf_version=version)
            if self.limit is not None:
                el.append(self.limit.to_sdf(version))
            if self.mimic is not None:
                el.append(self.mimic.to_sdf(version))
            if self.use_parent_model_frame is not None:
                _c_tmp = ET.Element("use_parent_model_frame")
                _c_tmp.text = str(self.use_parent_model_frame).lower()
                el.append(_c_tmp)
            if self.xyz is not None:
                el.set("xyz", self.xyz.to_sdf(version))
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Axis2 | SDFError":
            from ..elements.mimic import Mimic
            _c_dynamics = el.find("dynamics")
            if _c_dynamics is not None:
                _res = Dynamics._from_sdf(_c_dynamics, version)
                if isinstance(_res, SDFError):
                    return _res.extend("dynamics")
                _dynamics = _res
            else:
                _dynamics = None
            _c_tmp = el.find("initial_position")
            if _c_tmp is not None:
                _text = _c_tmp.text if _c_tmp.text is not None else 0
                _val = _parse_double(_text)
                if isinstance(_val, SDFError):
                    return _val.extend("initial_position")
                _initial_position = _val
            else:
                _initial_position = None
            if _initial_position is not None and cmp_version(version, "1.6") < 0:
                return SDFError(f"'initial_position' is not supported in SDF version {version} (added in 1.6)")
            _c_limit = el.find("limit")
            if _c_limit is not None:
                _res = cls.Axis2Limit._from_sdf(_c_limit, version)
                if isinstance(_res, SDFError):
                    return _res.extend("limit")
                _limit = _res
            else:
                _res = cls.Axis2Limit._from_sdf(ET.Element("limit"), version)
                if isinstance(_res, SDFError):
                    return _res.extend("limit")
                _limit = _res
            _c_mimic = el.find("mimic")
            if _c_mimic is not None:
                _res = Mimic._from_sdf(_c_mimic, version)
                if isinstance(_res, SDFError):
                    return _res.extend("mimic")
                _mimic = _res
            else:
                _mimic = None
            if _mimic is not None and cmp_version(version, "1.11") < 0:
                return SDFError(f"'mimic' is not supported in SDF version {version} (added in 1.11)")
            _c_tmp = el.find("use_parent_model_frame")
            if _c_tmp is not None:
                _text = _c_tmp.text if _c_tmp.text is not None else False
                _val = str(_text).strip().lower() == 'true'
                if isinstance(_val, SDFError):
                    return _val.extend("use_parent_model_frame")
                _use_parent_model_frame = _val
            else:
                _use_parent_model_frame = None
            if _use_parent_model_frame is not None and cmp_version(version, "1.5") < 0:
                return SDFError(f"'use_parent_model_frame' is not supported in SDF version {version} (added in 1.5)")
            _xyz = _SDFVector3._from_sdf(el.get("xyz", "0 0 1"), version)
            if isinstance(_xyz, SDFError):
                return _xyz.extend("@xyz")
            return cls(sdf_version=version, dynamics=_dynamics, initial_position=_initial_position, limit=_limit, mimic=_mimic, use_parent_model_frame=_use_parent_model_frame, xyz=_xyz)

    class Child(BaseModel):
        def __init__(
            self,
            sdf_version: str | None = None,
            child: str = "__default__",
            link: str = "__default__"
        ):
            super().__init__(sdf_version)
            self.child = child
            self.link = link

        def to_version(self, target_version: str) -> "Joint.Child":
            if self.link is not None and cmp_version(target_version, "1.2") >= 0:
                raise ValueError(f"'link' is not supported in SDF version {target_version} (removed in 1.2)")
            kwargs = {"sdf_version": target_version}
            kwargs["child"] = self.child
            kwargs["link"] = self.link
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("child")
            if self.child is not None:
                el.text = self.child
            if self.link is not None:
                if cmp_version(version, "1.2") >= 0:
                    el.text = self.link
                else:
                    el.set("link", self.link)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Child | SDFError":
            _text = el.text or "__default__"
            _child = _text
            if isinstance(_child, SDFError):
                return _child
            _raw_link = None
            if cmp_version(version, "1.2") >= 0:
                _raw_link = el.text
            else:
                _raw_link = el.get("link")
            if _raw_link is None: _raw_link = "__default__"
            _link = _raw_link
            if isinstance(_link, SDFError):
                return _link.extend("@link")
            return cls(sdf_version=version, child=_child, link=_link)

    class Origin(BaseModel):
        def __init__(self, sdf_version: str | None = None, pose: _SDFPose = None):
            super().__init__(sdf_version)
            if pose is None:
                pose = _SDFPose.from_sdf("0 0 0 0 0 0", version=sdf_version)
            self.pose = pose

        def to_version(self, target_version: str) -> "Joint.Origin":
            kwargs = {"sdf_version": target_version}
            kwargs["pose"] = self.pose
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("origin")
            if self.pose is not None:
                if cmp_version(version, "1.2") >= 0:
                    _c_tmp = ET.Element("pose")
                    _c_tmp.text = self.pose.to_sdf(version)
                    el.append(_c_tmp)
                else:
                    el.set("pose", self.pose.to_sdf(version))
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Origin | SDFError":
            _raw_pose = None
            if cmp_version(version, "1.2") >= 0:
                _c_tmp = el.find("pose")
                if _c_tmp is not None: _raw_pose = _c_tmp.text
            else:
                _raw_pose = el.get("pose")
            if _raw_pose is None: _raw_pose = "0 0 0 0 0 0"
            _pose = _SDFPose._from_sdf(_raw_pose, version)
            if isinstance(_pose, SDFError):
                return _pose.extend("@pose")
            return cls(sdf_version=version, pose=_pose)

    class Parent(BaseModel):
        def __init__(
            self,
            sdf_version: str | None = None,
            link: str = "__default__",
            parent: str = "__default__"
        ):
            super().__init__(sdf_version)
            self.link = link
            self.parent = parent

        def to_version(self, target_version: str) -> "Joint.Parent":
            if self.link is not None and cmp_version(target_version, "1.2") >= 0:
                raise ValueError(f"'link' is not supported in SDF version {target_version} (removed in 1.2)")
            kwargs = {"sdf_version": target_version}
            kwargs["link"] = self.link
            kwargs["parent"] = self.parent
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("parent")
            if self.link is not None:
                if cmp_version(version, "1.2") >= 0:
                    el.text = self.link
                else:
                    el.set("link", self.link)
            if self.parent is not None:
                el.text = self.parent
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Parent | SDFError":
            _raw_link = None
            if cmp_version(version, "1.2") >= 0:
                _raw_link = el.text
            else:
                _raw_link = el.get("link")
            if _raw_link is None: _raw_link = "__default__"
            _link = _raw_link
            if isinstance(_link, SDFError):
                return _link.extend("@link")
            _text = el.text or "__default__"
            _parent = _text
            if isinstance(_parent, SDFError):
                return _parent
            return cls(sdf_version=version, link=_link, parent=_parent)

    class Physics(BaseModel):
        class Ode(BaseModel):
            class OdeLimit(BaseModel):
                def __init__(self, sdf_version: str | None = None, cfm: float = 0.0, erp: float = 0.2):
                    super().__init__(sdf_version)
                    self.cfm = cfm
                    self.erp = erp

                def to_version(self, target_version: str) -> "Joint.Physics.Ode.OdeLimit":
                    if self.cfm is not None and cmp_version(target_version, "1.2") >= 0:
                        raise ValueError(f"'cfm' is not supported in SDF version {target_version} (removed in 1.2)")
                    if self.erp is not None and cmp_version(target_version, "1.2") >= 0:
                        raise ValueError(f"'erp' is not supported in SDF version {target_version} (removed in 1.2)")
                    kwargs = {"sdf_version": target_version}
                    kwargs["cfm"] = self.cfm
                    kwargs["erp"] = self.erp
                    new_obj = self.__class__(**kwargs)
                    return new_obj

                def to_sdf(self, version: str | None = None) -> ET.Element:
                    if self.__version__ is None and version is not None:
                        self.__version__ = version
                    elif version is not None and version != self.__version__:
                        return self.to_version(version).to_sdf()
                    version = self.__version__ or version
                    el = ET.Element("limit")
                    if self.cfm is not None:
                        el.set("cfm", str(self.cfm))
                    if self.erp is not None:
                        el.set("erp", str(self.erp))
                    return el

                @classmethod
                def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Physics.Ode.OdeLimit | SDFError":
                    _cfm = _parse_double(el.get("cfm", 0.0))
                    if isinstance(_cfm, SDFError):
                        return _cfm.extend("@cfm")
                    _erp = _parse_double(el.get("erp", 0.2))
                    if isinstance(_erp, SDFError):
                        return _erp.extend("@erp")
                    return cls(sdf_version=version, cfm=_cfm, erp=_erp)

            class Suspension(BaseModel):
                def __init__(self, sdf_version: str | None = None, cfm: float = 0.0, erp: float = 0.2):
                    super().__init__(sdf_version)
                    self.cfm = cfm
                    self.erp = erp

                def to_version(self, target_version: str) -> "Joint.Physics.Ode.Suspension":
                    if self.cfm is not None and cmp_version(target_version, "1.2") >= 0:
                        raise ValueError(f"'cfm' is not supported in SDF version {target_version} (removed in 1.2)")
                    if self.erp is not None and cmp_version(target_version, "1.2") >= 0:
                        raise ValueError(f"'erp' is not supported in SDF version {target_version} (removed in 1.2)")
                    kwargs = {"sdf_version": target_version}
                    kwargs["cfm"] = self.cfm
                    kwargs["erp"] = self.erp
                    new_obj = self.__class__(**kwargs)
                    return new_obj

                def to_sdf(self, version: str | None = None) -> ET.Element:
                    if self.__version__ is None and version is not None:
                        self.__version__ = version
                    elif version is not None and version != self.__version__:
                        return self.to_version(version).to_sdf()
                    version = self.__version__ or version
                    el = ET.Element("suspension")
                    if self.cfm is not None:
                        el.set("cfm", str(self.cfm))
                    if self.erp is not None:
                        el.set("erp", str(self.erp))
                    return el

                @classmethod
                def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Physics.Ode.Suspension | SDFError":
                    _cfm = _parse_double(el.get("cfm", 0.0))
                    if isinstance(_cfm, SDFError):
                        return _cfm.extend("@cfm")
                    _erp = _parse_double(el.get("erp", 0.2))
                    if isinstance(_erp, SDFError):
                        return _erp.extend("@erp")
                    return cls(sdf_version=version, cfm=_cfm, erp=_erp)

            def __init__(
                self,
                sdf_version: str | None = None,
                bounce: float = 0,
                cfm: float = 0,
                cfm_damping: bool = False,
                erp: float = 0.2,
                fudge_factor: float = 0,
                implicit_spring_damper: bool = False,
                limit: "Joint.Physics.Ode.OdeLimit" = None,
                max_force: float = 0,
                provide_feedback: bool = False,
                suspension: "Joint.Physics.Ode.Suspension" = None,
                velocity: float = 0
            ):
                super().__init__(sdf_version)
                self.bounce = bounce
                self.cfm = cfm
                self.cfm_damping = cfm_damping
                self.erp = erp
                self.fudge_factor = fudge_factor
                self.implicit_spring_damper = implicit_spring_damper
                self.limit = limit
                self.max_force = max_force
                self.provide_feedback = provide_feedback
                self.suspension = suspension
                self.velocity = velocity
                if self.limit is not None:
                    if getattr(self.limit, '__version__', None) is None:
                        self.limit.__version__ = self.__version__
                    elif getattr(self.limit, '__version__', None) != self.__version__ and self.__version__ is not None:
                        self.limit = self.limit.to_version(self.__version__)
                if self.suspension is not None:
                    if getattr(self.suspension, '__version__', None) is None:
                        self.suspension.__version__ = self.__version__
                    elif getattr(self.suspension, '__version__', None) != self.__version__ and self.__version__ is not None:
                        self.suspension = self.suspension.to_version(self.__version__)

            def to_version(self, target_version: str) -> "Joint.Physics.Ode":
                if self.cfm_damping is not None and cmp_version(target_version, "1.3") < 0:
                    raise ValueError(f"'cfm_damping' is not supported in SDF version {target_version} (added in 1.3)")
                if self.erp is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'erp' is not supported in SDF version {target_version} (added in 1.4)")
                if self.implicit_spring_damper is not None and cmp_version(target_version, "1.4") < 0:
                    raise ValueError(f"'implicit_spring_damper' is not supported in SDF version {target_version} (added in 1.4)")
                if self.provide_feedback is not None and cmp_version(target_version, "1.3") < 0:
                    raise ValueError(f"'provide_feedback' is not supported in SDF version {target_version} (added in 1.3)")
                if self.provide_feedback is not None and cmp_version(target_version, "1.7") >= 0:
                    raise ValueError(f"'provide_feedback' is not supported in SDF version {target_version} (removed in 1.7)")
                kwargs = {"sdf_version": target_version}
                kwargs["bounce"] = self.bounce
                kwargs["cfm"] = self.cfm
                kwargs["cfm_damping"] = self.cfm_damping
                kwargs["erp"] = self.erp
                kwargs["fudge_factor"] = self.fudge_factor
                kwargs["implicit_spring_damper"] = self.implicit_spring_damper
                kwargs["limit"] = self.limit.to_version(target_version) if self.limit is not None else None
                kwargs["max_force"] = self.max_force
                kwargs["provide_feedback"] = self.provide_feedback
                kwargs["suspension"] = self.suspension.to_version(target_version) if self.suspension is not None else None
                kwargs["velocity"] = self.velocity
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("ode")
                if self.bounce is not None:
                    _c_tmp = ET.Element("bounce")
                    _c_tmp.text = str(self.bounce)
                    el.append(_c_tmp)
                if self.cfm is not None:
                    _c_tmp = ET.Element("cfm")
                    _c_tmp.text = str(self.cfm)
                    el.append(_c_tmp)
                if self.cfm_damping is not None:
                    _c_tmp = ET.Element("cfm_damping")
                    _c_tmp.text = str(self.cfm_damping).lower()
                    el.append(_c_tmp)
                if self.erp is not None:
                    _c_tmp = ET.Element("erp")
                    _c_tmp.text = str(self.erp)
                    el.append(_c_tmp)
                if self.fudge_factor is not None:
                    _c_tmp = ET.Element("fudge_factor")
                    _c_tmp.text = str(self.fudge_factor)
                    el.append(_c_tmp)
                if self.implicit_spring_damper is not None:
                    _c_tmp = ET.Element("implicit_spring_damper")
                    _c_tmp.text = str(self.implicit_spring_damper).lower()
                    el.append(_c_tmp)
                if self.limit is not None:
                    el.append(self.limit.to_sdf(version))
                if self.max_force is not None:
                    _c_tmp = ET.Element("max_force")
                    _c_tmp.text = str(self.max_force)
                    el.append(_c_tmp)
                if self.provide_feedback is not None:
                    _c_tmp = ET.Element("provide_feedback")
                    _c_tmp.text = str(self.provide_feedback).lower()
                    el.append(_c_tmp)
                if self.suspension is not None:
                    el.append(self.suspension.to_sdf(version))
                if self.velocity is not None:
                    _c_tmp = ET.Element("velocity")
                    _c_tmp.text = str(self.velocity)
                    el.append(_c_tmp)
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Physics.Ode | SDFError":
                _c_tmp = el.find("bounce")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("bounce")
                    _bounce = _val
                else:
                    _bounce = None
                _c_tmp = el.find("cfm")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("cfm")
                    _cfm = _val
                else:
                    _cfm = None
                _c_tmp = el.find("cfm_damping")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else False
                    _val = str(_text).strip().lower() == 'true'
                    if isinstance(_val, SDFError):
                        return _val.extend("cfm_damping")
                    _cfm_damping = _val
                else:
                    _cfm_damping = None
                if _cfm_damping is not None and cmp_version(version, "1.3") < 0:
                    return SDFError(f"'cfm_damping' is not supported in SDF version {version} (added in 1.3)")
                _c_tmp = el.find("erp")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0.2
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("erp")
                    _erp = _val
                else:
                    _erp = None
                if _erp is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'erp' is not supported in SDF version {version} (added in 1.4)")
                _c_tmp = el.find("fudge_factor")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("fudge_factor")
                    _fudge_factor = _val
                else:
                    _fudge_factor = None
                _c_tmp = el.find("implicit_spring_damper")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else False
                    _val = str(_text).strip().lower() == 'true'
                    if isinstance(_val, SDFError):
                        return _val.extend("implicit_spring_damper")
                    _implicit_spring_damper = _val
                else:
                    _implicit_spring_damper = None
                if _implicit_spring_damper is not None and cmp_version(version, "1.4") < 0:
                    return SDFError(f"'implicit_spring_damper' is not supported in SDF version {version} (added in 1.4)")
                _c_limit = el.find("limit")
                if _c_limit is not None:
                    _res = cls.OdeLimit._from_sdf(_c_limit, version)
                    if isinstance(_res, SDFError):
                        return _res.extend("limit")
                    _limit = _res
                else:
                    _limit = None
                _c_tmp = el.find("max_force")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("max_force")
                    _max_force = _val
                else:
                    _max_force = None
                _c_tmp = el.find("provide_feedback")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else False
                    _val = str(_text).strip().lower() == 'true'
                    if isinstance(_val, SDFError):
                        return _val.extend("provide_feedback")
                    _provide_feedback = _val
                else:
                    _provide_feedback = None
                if _provide_feedback is not None and cmp_version(version, "1.3") < 0:
                    return SDFError(f"'provide_feedback' is not supported in SDF version {version} (added in 1.3)")
                _c_suspension = el.find("suspension")
                if _c_suspension is not None:
                    _res = cls.Suspension._from_sdf(_c_suspension, version)
                    if isinstance(_res, SDFError):
                        return _res.extend("suspension")
                    _suspension = _res
                else:
                    _suspension = None
                _c_tmp = el.find("velocity")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else 0
                    _val = _parse_double(_text)
                    if isinstance(_val, SDFError):
                        return _val.extend("velocity")
                    _velocity = _val
                else:
                    _velocity = None
                return cls(sdf_version=version, bounce=_bounce, cfm=_cfm, cfm_damping=_cfm_damping, erp=_erp, fudge_factor=_fudge_factor, implicit_spring_damper=_implicit_spring_damper, limit=_limit, max_force=_max_force, provide_feedback=_provide_feedback, suspension=_suspension, velocity=_velocity)

        class Simbody(BaseModel):
            def __init__(self, sdf_version: str | None = None, must_be_loop_joint: bool = False):
                super().__init__(sdf_version)
                self.must_be_loop_joint = must_be_loop_joint

            def to_version(self, target_version: str) -> "Joint.Physics.Simbody":
                kwargs = {"sdf_version": target_version}
                kwargs["must_be_loop_joint"] = self.must_be_loop_joint
                new_obj = self.__class__(**kwargs)
                return new_obj

            def to_sdf(self, version: str | None = None) -> ET.Element:
                if self.__version__ is None and version is not None:
                    self.__version__ = version
                elif version is not None and version != self.__version__:
                    return self.to_version(version).to_sdf()
                version = self.__version__ or version
                el = ET.Element("simbody")
                if self.must_be_loop_joint is not None:
                    _c_tmp = ET.Element("must_be_loop_joint")
                    _c_tmp.text = str(self.must_be_loop_joint).lower()
                    el.append(_c_tmp)
                return el

            @classmethod
            def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Physics.Simbody | SDFError":
                _c_tmp = el.find("must_be_loop_joint")
                if _c_tmp is not None:
                    _text = _c_tmp.text if _c_tmp.text is not None else False
                    _val = str(_text).strip().lower() == 'true'
                    if isinstance(_val, SDFError):
                        return _val.extend("must_be_loop_joint")
                    _must_be_loop_joint = _val
                else:
                    _must_be_loop_joint = None
                return cls(sdf_version=version, must_be_loop_joint=_must_be_loop_joint)

        _MIGRATIONS = [{"version": "1.4", "ops": [{"type": "move", "from": "update_rate", "to": "real_time_update_rate"}, {"type": "move", "from": "ode::solver::dt", "to": "max_step_size"}, {"type": "move", "from": "bullet::dt", "to": "max_step_size"}]}]

        def __init__(
            self,
            sdf_version: str | None = None,
            ode: "Joint.Physics.Ode" = None,
            provide_feedback: bool = False,
            simbody: "Joint.Physics.Simbody" = None
        ):
            super().__init__(sdf_version)
            self.ode = ode
            self.provide_feedback = provide_feedback
            self.simbody = simbody
            if self.ode is not None:
                if getattr(self.ode, '__version__', None) is None:
                    self.ode.__version__ = self.__version__
                elif getattr(self.ode, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.ode = self.ode.to_version(self.__version__)
            if self.simbody is not None:
                if getattr(self.simbody, '__version__', None) is None:
                    self.simbody.__version__ = self.__version__
                elif getattr(self.simbody, '__version__', None) != self.__version__ and self.__version__ is not None:
                    self.simbody = self.simbody.to_version(self.__version__)

        def to_version(self, target_version: str) -> "Joint.Physics":
            if self.provide_feedback is not None and cmp_version(target_version, "1.4") < 0:
                raise ValueError(f"'provide_feedback' is not supported in SDF version {target_version} (added in 1.4)")
            if self.simbody is not None and cmp_version(target_version, "1.4") < 0:
                raise ValueError(f"'simbody' is not supported in SDF version {target_version} (added in 1.4)")
            kwargs = {"sdf_version": target_version}
            kwargs["ode"] = self.ode.to_version(target_version) if self.ode is not None else None
            kwargs["provide_feedback"] = self.provide_feedback
            kwargs["simbody"] = self.simbody.to_version(target_version) if self.simbody is not None else None
            new_obj = self.__class__(**kwargs)
            apply_migrations(new_obj, target_version)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("physics")
            if self.ode is not None:
                el.append(self.ode.to_sdf(version))
            if self.provide_feedback is not None:
                _c_tmp = ET.Element("provide_feedback")
                _c_tmp.text = str(self.provide_feedback).lower()
                el.append(_c_tmp)
            if self.simbody is not None:
                el.append(self.simbody.to_sdf(version))
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str) -> "Joint.Physics | SDFError":
            _c_ode = el.find("ode")
            if _c_ode is not None:
                _res = cls.Ode._from_sdf(_c_ode, version)
                if isinstance(_res, SDFError):
                    return _res.extend("ode")
                _ode = _res
            else:
                _ode = None
            _c_tmp = el.find("provide_feedback")
            if _c_tmp is not None:
                _text = _c_tmp.text if _c_tmp.text is not None else False
                _val = str(_text).strip().lower() == 'true'
                if isinstance(_val, SDFError):
                    return _val.extend("provide_feedback")
                _provide_feedback = _val
            else:
                _provide_feedback = None
            if _provide_feedback is not None and cmp_version(version, "1.4") < 0:
                return SDFError(f"'provide_feedback' is not supported in SDF version {version} (added in 1.4)")
            _c_simbody = el.find("simbody")
            if _c_simbody is not None:
                _res = cls.Simbody._from_sdf(_c_simbody, version)
                if isinstance(_res, SDFError):
                    return _res.extend("simbody")
                _simbody = _res
            else:
                _simbody = None
            if _simbody is not None and cmp_version(version, "1.4") < 0:
                return SDFError(f"'simbody' is not supported in SDF version {version} (added in 1.4)")
            return cls(sdf_version=version, ode=_ode, provide_feedback=_provide_feedback, simbody=_simbody)

    def __init__(
        self,
        sdf_version: str | None = None,
        axis: "Joint.Axis" = None,
        axis2: "Joint.Axis2" = None,
        child: "Joint.Child" = None,
        frames: List["Frame"] = None,
        gearbox_ratio: float = 1.0,
        gearbox_reference_body: str = "__default__",
        name: str = "__default__",
        origin: "Joint.Origin" = None,
        parent: "Joint.Parent" = None,
        physics: "Joint.Physics" = None,
        pose: "Pose" = None,
        screw_thread_pitch: float = 1.0,
        sensor: "Sensor" = None,
        thread_pitch: float = 1.0,
        type: str = "__default__"
    ):
        super().__init__(sdf_version)
        self.axis = axis
        self.axis2 = axis2
        self.child = child
        self.frames = frames or []
        self.gearbox_ratio = gearbox_ratio
        self.gearbox_reference_body = gearbox_reference_body
        self.name = name
        self.origin = origin
        self.parent = parent
        self.physics = physics
        self.pose = pose
        self.screw_thread_pitch = screw_thread_pitch
        self.sensor = sensor
        self.thread_pitch = thread_pitch
        self.type = type
        if self.axis is not None:
            if getattr(self.axis, '__version__', None) is None:
                self.axis.__version__ = self.__version__
            elif getattr(self.axis, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.axis = self.axis.to_version(self.__version__)
        if self.axis2 is not None:
            if getattr(self.axis2, '__version__', None) is None:
                self.axis2.__version__ = self.__version__
            elif getattr(self.axis2, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.axis2 = self.axis2.to_version(self.__version__)
        if self.child is not None:
            if getattr(self.child, '__version__', None) is None:
                self.child.__version__ = self.__version__
            elif getattr(self.child, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.child = self.child.to_version(self.__version__)
        for _i, _c in enumerate(self.frames):
            if getattr(_c, '__version__', None) is None:
                _c.__version__ = self.__version__
            elif getattr(_c, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.frames[_i] = _c.to_version(self.__version__)
        if self.origin is not None:
            if getattr(self.origin, '__version__', None) is None:
                self.origin.__version__ = self.__version__
            elif getattr(self.origin, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.origin = self.origin.to_version(self.__version__)
        if self.parent is not None:
            if getattr(self.parent, '__version__', None) is None:
                self.parent.__version__ = self.__version__
            elif getattr(self.parent, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.parent = self.parent.to_version(self.__version__)
        if self.physics is not None:
            if getattr(self.physics, '__version__', None) is None:
                self.physics.__version__ = self.__version__
            elif getattr(self.physics, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.physics = self.physics.to_version(self.__version__)
        if self.pose is not None:
            if getattr(self.pose, '__version__', None) is None:
                self.pose.__version__ = self.__version__
            elif getattr(self.pose, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.pose = self.pose.to_version(self.__version__)
        if self.sensor is not None:
            if getattr(self.sensor, '__version__', None) is None:
                self.sensor.__version__ = self.__version__
            elif getattr(self.sensor, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.sensor = self.sensor.to_version(self.__version__)

    def add_frame(self, *items: "Frame"):
        if self.frames is None:
            self.frames = []
        self.frames.extend(items)

    def to_version(self, target_version: str) -> "Joint":
        from ..elements.frame import Frame
        from ..elements.pose import Pose
        from ..elements.sensor import Sensor
        if self.frames is not None and cmp_version(target_version, "1.5") < 0:
            raise ValueError(f"'frames' is not supported in SDF version {target_version} (added in 1.5)")
        if self.frames is not None and cmp_version(target_version, "1.7") >= 0:
            raise ValueError(f"'frames' is not supported in SDF version {target_version} (removed in 1.7)")
        if self.gearbox_ratio is not None and cmp_version(target_version, "1.4") < 0:
            raise ValueError(f"'gearbox_ratio' is not supported in SDF version {target_version} (added in 1.4)")
        if self.gearbox_reference_body is not None and cmp_version(target_version, "1.4") < 0:
            raise ValueError(f"'gearbox_reference_body' is not supported in SDF version {target_version} (added in 1.4)")
        if self.origin is not None and cmp_version(target_version, "1.2") >= 0:
            raise ValueError(f"'origin' is not supported in SDF version {target_version} (removed in 1.2)")
        if self.pose is not None and cmp_version(target_version, "1.2") < 0:
            raise ValueError(f"'pose' is not supported in SDF version {target_version} (added in 1.2)")
        if self.screw_thread_pitch is not None and cmp_version(target_version, "1.10") < 0:
            raise ValueError(f"'screw_thread_pitch' is not supported in SDF version {target_version} (added in 1.10)")
        if self.sensor is not None and cmp_version(target_version, "1.4") < 0:
            raise ValueError(f"'sensor' is not supported in SDF version {target_version} (added in 1.4)")
        kwargs = {"sdf_version": target_version}
        kwargs["axis"] = self.axis.to_version(target_version) if self.axis is not None else None
        kwargs["axis2"] = self.axis2.to_version(target_version) if self.axis2 is not None else None
        kwargs["child"] = self.child.to_version(target_version) if self.child is not None else None
        kwargs["frames"] = [c.to_version(target_version) for c in (self.frames or [])]
        kwargs["gearbox_ratio"] = self.gearbox_ratio
        kwargs["gearbox_reference_body"] = self.gearbox_reference_body
        kwargs["name"] = self.name
        kwargs["origin"] = self.origin.to_version(target_version) if self.origin is not None else None
        kwargs["parent"] = self.parent.to_version(target_version) if self.parent is not None else None
        kwargs["physics"] = self.physics.to_version(target_version) if self.physics is not None else None
        kwargs["pose"] = self.pose.to_version(target_version) if self.pose is not None else None
        kwargs["screw_thread_pitch"] = self.screw_thread_pitch
        kwargs["sensor"] = self.sensor.to_version(target_version) if self.sensor is not None else None
        kwargs["thread_pitch"] = self.thread_pitch
        kwargs["type"] = self.type
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str | None = None) -> ET.Element:
        from ..elements.frame import Frame
        from ..elements.pose import Pose
        from ..elements.sensor import Sensor
        if self.__version__ is None and version is not None:
            self.__version__ = version
        elif version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = self.__version__ or version
        el = ET.Element("joint")
        if self.axis is not None:
            el.append(self.axis.to_sdf(version))
        if self.axis2 is not None:
            el.append(self.axis2.to_sdf(version))
        if self.child is not None:
            el.append(self.child.to_sdf(version))
        for item in (self.frames or []):
            el.append(item.to_sdf(version))
        if self.gearbox_ratio is not None:
            _c_tmp = ET.Element("gearbox_ratio")
            _c_tmp.text = str(self.gearbox_ratio)
            el.append(_c_tmp)
        if self.gearbox_reference_body is not None:
            _c_tmp = ET.Element("gearbox_reference_body")
            _c_tmp.text = self.gearbox_reference_body
            el.append(_c_tmp)
        if self.name is not None:
            el.set("name", self.name)
        if self.origin is not None:
            el.append(self.origin.to_sdf(version))
        if self.parent is not None:
            el.append(self.parent.to_sdf(version))
        if self.physics is not None:
            el.append(self.physics.to_sdf(version))
        if self.pose is not None:
            el.append(self.pose.to_sdf(version))
        if self.screw_thread_pitch is not None:
            _c_tmp = ET.Element("screw_thread_pitch")
            _c_tmp.text = str(self.screw_thread_pitch)
            el.append(_c_tmp)
        if self.sensor is not None:
            el.append(self.sensor.to_sdf(version))
        if self.thread_pitch is not None:
            _c_tmp = ET.Element("thread_pitch")
            _c_tmp.text = str(self.thread_pitch)
            el.append(_c_tmp)
        if self.type is not None:
            el.set("type", self.type)
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str) -> "Joint | SDFError":
        from ..elements.frame import Frame
        from ..elements.pose import Pose
        from ..elements.sensor import Sensor
        _c_axis = el.find("axis")
        if _c_axis is not None:
            _res = cls.Axis._from_sdf(_c_axis, version)
            if isinstance(_res, SDFError):
                return _res.extend("axis")
            _axis = _res
        else:
            _axis = None
        _c_axis2 = el.find("axis2")
        if _c_axis2 is not None:
            _res = cls.Axis2._from_sdf(_c_axis2, version)
            if isinstance(_res, SDFError):
                return _res.extend("axis2")
            _axis2 = _res
        else:
            _axis2 = None
        _c_child = el.find("child")
        if _c_child is not None:
            _res = cls.Child._from_sdf(_c_child, version)
            if isinstance(_res, SDFError):
                return _res.extend("child")
            _child = _res
        else:
            _child = None
        _frames = []
        for c in el.findall("frame"):
            _res = Frame._from_sdf(c, version)
            if isinstance(_res, SDFError):
                return _res.extend("frame")
            _frames.append(_res)
        if _frames and cmp_version(version, "1.5") < 0:
            return SDFError(f"'frames' is not supported in SDF version {version} (added in 1.5)")
        _c_tmp = el.find("gearbox_ratio")
        if _c_tmp is not None:
            _text = _c_tmp.text if _c_tmp.text is not None else 1.0
            _val = _parse_double(_text)
            if isinstance(_val, SDFError):
                return _val.extend("gearbox_ratio")
            _gearbox_ratio = _val
        else:
            _gearbox_ratio = None
        if _gearbox_ratio is not None and cmp_version(version, "1.4") < 0:
            return SDFError(f"'gearbox_ratio' is not supported in SDF version {version} (added in 1.4)")
        _c_tmp = el.find("gearbox_reference_body")
        if _c_tmp is not None:
            _text = _c_tmp.text if _c_tmp.text is not None else "__default__"
            _val = _text
            if isinstance(_val, SDFError):
                return _val.extend("gearbox_reference_body")
            _gearbox_reference_body = _val
        else:
            _gearbox_reference_body = None
        if _gearbox_reference_body is not None and cmp_version(version, "1.4") < 0:
            return SDFError(f"'gearbox_reference_body' is not supported in SDF version {version} (added in 1.4)")
        _name = el.get("name", "__default__")
        if isinstance(_name, SDFError):
            return _name.extend("@name")
        _c_origin = el.find("origin")
        if _c_origin is not None:
            _res = cls.Origin._from_sdf(_c_origin, version)
            if isinstance(_res, SDFError):
                return _res.extend("origin")
            _origin = _res
        else:
            _origin = None
        _c_parent = el.find("parent")
        if _c_parent is not None:
            _res = cls.Parent._from_sdf(_c_parent, version)
            if isinstance(_res, SDFError):
                return _res.extend("parent")
            _parent = _res
        else:
            _parent = None
        _c_physics = el.find("physics")
        if _c_physics is not None:
            _res = cls.Physics._from_sdf(_c_physics, version)
            if isinstance(_res, SDFError):
                return _res.extend("physics")
            _physics = _res
        else:
            _physics = None
        _c_pose = el.find("pose")
        if _c_pose is not None:
            _res = Pose._from_sdf(_c_pose, version)
            if isinstance(_res, SDFError):
                return _res.extend("pose")
            _pose = _res
        else:
            _pose = None
        if _pose is not None and cmp_version(version, "1.2") < 0:
            return SDFError(f"'pose' is not supported in SDF version {version} (added in 1.2)")
        _c_tmp = el.find("screw_thread_pitch")
        if _c_tmp is not None:
            _text = _c_tmp.text if _c_tmp.text is not None else 1.0
            _val = _parse_double(_text)
            if isinstance(_val, SDFError):
                return _val.extend("screw_thread_pitch")
            _screw_thread_pitch = _val
        else:
            _screw_thread_pitch = None
        if _screw_thread_pitch is not None and cmp_version(version, "1.10") < 0:
            return SDFError(f"'screw_thread_pitch' is not supported in SDF version {version} (added in 1.10)")
        _c_sensor = el.find("sensor")
        if _c_sensor is not None:
            _res = Sensor._from_sdf(_c_sensor, version)
            if isinstance(_res, SDFError):
                return _res.extend("sensor")
            _sensor = _res
        else:
            _sensor = None
        if _sensor is not None and cmp_version(version, "1.4") < 0:
            return SDFError(f"'sensor' is not supported in SDF version {version} (added in 1.4)")
        _c_tmp = el.find("thread_pitch")
        if _c_tmp is not None:
            _text = _c_tmp.text if _c_tmp.text is not None else 1.0
            _val = _parse_double(_text)
            if isinstance(_val, SDFError):
                return _val.extend("thread_pitch")
            _thread_pitch = _val
        else:
            _thread_pitch = None
        _type = el.get("type", "__default__")
        if isinstance(_type, SDFError):
            return _type.extend("@type")
        return cls(sdf_version=version, axis=_axis, axis2=_axis2, child=_child, frames=_frames, gearbox_ratio=_gearbox_ratio, gearbox_reference_body=_gearbox_reference_body, name=_name, origin=_origin, parent=_parent, physics=_physics, pose=_pose, screw_thread_pitch=_screw_thread_pitch, sensor=_sensor, thread_pitch=_thread_pitch, type=_type)
