"""Tests for Paygent metering engine — cost calculation + cache update."""

from __future__ import annotations

import pytest

from paygent.metering import (
    calculate_cost,
    create_usage_event,
    normalize_model_name,
    update_cache,
)
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    PlanConfig,
    UserSession,
)
from paygent.providers import TokenInfo


# ---------------------------------------------------------------------------
# Cost Calculation
# ---------------------------------------------------------------------------


class TestCalculateCost:
    def test_basic_token_cost(self, pro_plan_config: PlanConfig):
        """GPT-4o: 1000 input tokens + 200 output tokens."""
        info = TokenInfo(model="gpt-4o", input_tokens=1000, output_tokens=200, total_tokens=1200)
        cost_tokens, cost_tools, cost_total = calculate_cost(info, pro_plan_config)

        # input: (1000/1000) * 0.0025 = 0.0025
        # output: (200/1000) * 0.01 = 0.002
        expected_tokens = 0.0025 + 0.002
        assert cost_tokens == pytest.approx(expected_tokens)
        assert cost_tools == 0.0
        assert cost_total == pytest.approx(expected_tokens)

    def test_mini_model_cost(self, pro_plan_config: PlanConfig):
        """GPT-4o-mini is much cheaper."""
        info = TokenInfo(model="gpt-4o-mini", input_tokens=1000, output_tokens=1000, total_tokens=2000)
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)

        # input: (1000/1000) * 0.00015 = 0.00015
        # output: (1000/1000) * 0.0006 = 0.0006
        assert cost_tokens == pytest.approx(0.00075)

    def test_anthropic_model_cost(self, pro_plan_config: PlanConfig):
        """Claude Sonnet cost rates."""
        info = TokenInfo(
            model="claude-sonnet-4-20250514",
            input_tokens=2000,
            output_tokens=500,
            total_tokens=2500,
        )
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)

        # input: (2000/1000) * 0.003 = 0.006
        # output: (500/1000) * 0.015 = 0.0075
        assert cost_tokens == pytest.approx(0.0135)

    def test_tool_costs_known_tools(self, pro_plan_config: PlanConfig):
        """Known tools use their configured costs."""
        info = TokenInfo(model="gpt-4o", input_tokens=0, output_tokens=0, total_tokens=0)
        _, cost_tools, _ = calculate_cost(info, pro_plan_config, tool_calls=["web_search", "code_exec"])

        # web_search: 0.05, code_exec: 0.10
        assert cost_tools == pytest.approx(0.15)

    def test_tool_costs_unknown_tool_uses_default(self, pro_plan_config: PlanConfig):
        """Unknown tools fall back to default_tool_cost."""
        info = TokenInfo()
        _, cost_tools, _ = calculate_cost(info, pro_plan_config, tool_calls=["unknown_tool"])

        assert cost_tools == pytest.approx(0.02)  # default_tool_cost

    def test_combined_token_and_tool_cost(self, pro_plan_config: PlanConfig):
        """Total cost = token cost + tool cost."""
        info = TokenInfo(model="gpt-4o", input_tokens=1000, output_tokens=200, total_tokens=1200)
        cost_tokens, cost_tools, cost_total = calculate_cost(
            info, pro_plan_config, tool_calls=["web_search"]
        )

        assert cost_total == pytest.approx(cost_tokens + cost_tools)
        assert cost_tools == pytest.approx(0.05)

    def test_unknown_model_zero_token_cost(self, pro_plan_config: PlanConfig):
        """Model with no configured rate and no default — token cost is 0."""
        info = TokenInfo(model="llama-3-70b", input_tokens=5000, output_tokens=1000, total_tokens=6000)
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)
        assert cost_tokens == 0.0

    def test_unknown_model_uses_default_cost_rate(self):
        """Model with no configured rate falls back to default_cost_rate."""
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=1000, output_tokens=500, total_tokens=1500)
        cost_tokens, _, _ = calculate_cost(info, config)
        # input: (1000/1000) * 0.002 = 0.002
        # output: (500/1000) * 0.008 = 0.004
        assert cost_tokens == pytest.approx(0.006)

    def test_configured_model_ignores_default_cost_rate(self):
        """Configured model uses its specific rate, not default_cost_rate."""
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="gpt-4o", input_tokens=1000, output_tokens=200, total_tokens=1200)
        cost_tokens, _, _ = calculate_cost(info, config)
        # Should use gpt-4o rate, NOT default
        expected = (1000 / 1000.0) * 0.0025 + (200 / 1000.0) * 0.01
        assert cost_tokens == pytest.approx(expected)

    def test_default_cost_rate_none_no_cost(self):
        """When default_cost_rate is None, unknown models get $0 cost."""
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=None,
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=1000, output_tokens=500, total_tokens=1500)
        cost_tokens, _, _ = calculate_cost(info, config)
        assert cost_tokens == 0.0

    def test_default_cost_rate_warning_logged(self, caplog):
        """Warning should be logged when using default_cost_rate."""
        import logging
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=100, output_tokens=50, total_tokens=150)
        with caplog.at_level(logging.WARNING, logger="paygent"):
            calculate_cost(info, config)
        assert "llama-3-70b" in caplog.text
        assert "default_cost_rate" in caplog.text

    def test_no_default_no_rate_warning_logged(self, caplog):
        """Warning should be logged when model has no rate and no default."""
        import logging
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=100, output_tokens=50, total_tokens=150)
        with caplog.at_level(logging.WARNING, logger="paygent"):
            calculate_cost(info, config)
        assert "llama-3-70b" in caplog.text
        assert "no default_cost_rate" in caplog.text.lower() or "default_cost_rate" in caplog.text

    def test_no_model_zero_token_cost(self, pro_plan_config: PlanConfig):
        """No model name — token cost is 0."""
        info = TokenInfo(input_tokens=1000, output_tokens=200)
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)
        assert cost_tokens == 0.0

    def test_zero_tokens(self, pro_plan_config: PlanConfig):
        """Zero tokens — cost should be zero."""
        info = TokenInfo(model="gpt-4o", input_tokens=0, output_tokens=0, total_tokens=0)
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)
        assert cost_tokens == 0.0

    def test_empty_tool_calls(self, pro_plan_config: PlanConfig):
        """Empty tool calls list — tool cost is 0."""
        info = TokenInfo()
        _, cost_tools, _ = calculate_cost(info, pro_plan_config, tool_calls=[])
        assert cost_tools == 0.0

    def test_none_tool_calls(self, pro_plan_config: PlanConfig):
        """None tool calls — tool cost is 0."""
        info = TokenInfo()
        _, cost_tools, _ = calculate_cost(info, pro_plan_config, tool_calls=None)
        assert cost_tools == 0.0

    def test_empty_plan_config(self):
        """Plan with no cost rates — everything is 0."""
        info = TokenInfo(model="gpt-4o", input_tokens=1000, output_tokens=200, total_tokens=1200)
        config = PlanConfig()
        cost_tokens, cost_tools, cost_total = calculate_cost(info, config)
        assert cost_tokens == 0.0
        assert cost_tools == 0.0
        assert cost_total == 0.0

    def test_large_token_counts(self, pro_plan_config: PlanConfig):
        """Large token counts should calculate correctly."""
        info = TokenInfo(model="gpt-4o", input_tokens=100_000, output_tokens=50_000, total_tokens=150_000)
        cost_tokens, _, _ = calculate_cost(info, pro_plan_config)

        # input: (100000/1000) * 0.0025 = 0.25
        # output: (50000/1000) * 0.01 = 0.50
        assert cost_tokens == pytest.approx(0.75)


# ---------------------------------------------------------------------------
# Model Name Normalization
# ---------------------------------------------------------------------------


class TestNormalizeModelName:
    def test_exact_match(self, pro_plan_config: PlanConfig):
        """Exact match returns the model name as-is."""
        assert normalize_model_name("gpt-4o", pro_plan_config) == "gpt-4o"

    def test_versioned_model_normalized(self, pro_plan_config: PlanConfig):
        """Versioned model name maps to the configured short alias."""
        assert normalize_model_name("gpt-4o-mini-2024-07-18", pro_plan_config) == "gpt-4o-mini"

    def test_longest_prefix_wins(self, pro_plan_config: PlanConfig):
        """gpt-4o-mini-2024-07-18 matches gpt-4o-mini, not gpt-4o."""
        result = normalize_model_name("gpt-4o-mini-2024-07-18", pro_plan_config)
        assert result == "gpt-4o-mini"
        assert result != "gpt-4o"

    def test_versioned_gpt4o(self, pro_plan_config: PlanConfig):
        """gpt-4o-2024-11-20 maps to gpt-4o."""
        assert normalize_model_name("gpt-4o-2024-11-20", pro_plan_config) == "gpt-4o"

    def test_anthropic_versioned(self):
        """Anthropic versioned model maps to configured name."""
        config = PlanConfig(
            cost_rates={
                "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
            },
        )
        # If Anthropic ever adds a date suffix
        assert normalize_model_name("claude-sonnet-4-20250514", config) == "claude-sonnet-4-20250514"

    def test_no_match_returns_original(self, pro_plan_config: PlanConfig):
        """Unknown model name is returned unchanged."""
        assert normalize_model_name("llama-3-70b", pro_plan_config) == "llama-3-70b"

    def test_none_returns_none(self, pro_plan_config: PlanConfig):
        """None model stays None."""
        assert normalize_model_name(None, pro_plan_config) is None

    def test_empty_config(self):
        """No configured models — original name returned."""
        config = PlanConfig()
        assert normalize_model_name("gpt-4o-mini-2024-07-18", config) == "gpt-4o-mini-2024-07-18"

    def test_matches_model_limits_too(self):
        """Should match against model_limits even if no cost_rate for that model."""
        from paygent.models import ModelLimitConfig
        config = PlanConfig(
            model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50000)},
        )
        assert normalize_model_name("gpt-4o-2024-11-20", config) == "gpt-4o"


class TestDefaultCostRateInEvent:
    def test_unknown_model_event_uses_default_rate(self):
        """create_usage_event should use default_cost_rate for unknown models."""
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=1000, output_tokens=500, total_tokens=1500)
        event = create_usage_event("user_1", info, config)
        assert event.cost_tokens > 0
        assert event.cost_tokens == pytest.approx(0.006)
        assert event.model == "llama-3-70b"  # model name preserved

    def test_unknown_model_still_tracked_in_cache(self):
        """Unknown model with default rate should still be tracked in per-model cache."""
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=1000, output_tokens=500, total_tokens=1500)
        event = create_usage_event("user_1", info, config)
        session = UserSession(
            user_id="user_1",
            plan="pro",
            plan_config=config,
            current_usage=CurrentUsage(),
        )
        update_cache(session, event)
        assert "llama-3-70b" in session.current_usage.period_tokens_by_model
        assert session.current_usage.period_tokens_by_model["llama-3-70b"] == 1500
        assert session.current_usage.period_cost > 0

    def test_unknown_model_affects_spend_guardrails(self):
        """Cost from default_cost_rate should count toward spend limits."""
        config = PlanConfig(
            max_spend_per_period=0.005,
            hard_gate_at=1.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            default_cost_rate=ModelCostRate(input=0.002, output=0.008),
        )
        info = TokenInfo(model="llama-3-70b", input_tokens=1000, output_tokens=500, total_tokens=1500)
        event = create_usage_event("user_1", info, config)
        session = UserSession(
            user_id="user_1",
            plan="pro",
            plan_config=config,
            current_usage=CurrentUsage(),
        )
        update_cache(session, event)
        # Cost = 0.006 > limit 0.005 → should hit hard gate
        from paygent.guardrails import check_guard
        result = check_guard(session, model="llama-3-70b")
        assert result.status == "hard_gate"


class TestNormalizedCostCalculation:
    def test_versioned_model_gets_costed(self, pro_plan_config: PlanConfig):
        """create_usage_event normalizes the model so cost is non-zero."""
        info = TokenInfo(
            model="gpt-4o-mini-2024-07-18",
            input_tokens=1000,
            output_tokens=500,
            total_tokens=1500,
        )
        event = create_usage_event(
            user_id="user_1",
            token_info=info,
            plan_config=pro_plan_config,
        )
        assert event.model == "gpt-4o-mini"
        assert event.cost_tokens > 0
        # (1000/1000)*0.00015 + (500/1000)*0.0006 = 0.00015 + 0.0003 = 0.00045
        assert event.cost_tokens == pytest.approx(0.00045, abs=0.0001)

    def test_versioned_model_tracked_under_short_name(self, pro_plan_config: PlanConfig):
        """Cache update should use the normalized model name."""
        info = TokenInfo(
            model="gpt-4o-mini-2024-07-18",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
        )
        event = create_usage_event(
            user_id="user_1",
            token_info=info,
            plan_config=pro_plan_config,
        )
        session = UserSession(
            user_id="user_1",
            plan="pro",
            plan_config=pro_plan_config,
            current_usage=CurrentUsage(),
        )
        update_cache(session, event)

        assert "gpt-4o-mini" in session.current_usage.period_tokens_by_model
        assert "gpt-4o-mini-2024-07-18" not in session.current_usage.period_tokens_by_model
        assert session.current_usage.period_tokens_by_model["gpt-4o-mini"] == 150


# ---------------------------------------------------------------------------
# Create Usage Event
# ---------------------------------------------------------------------------


class TestCreateUsageEvent:
    def test_basic_event(self, pro_plan_config: PlanConfig):
        """Creates a fully-costed event."""
        info = TokenInfo(model="gpt-4o", input_tokens=1000, output_tokens=200, total_tokens=1200)
        event = create_usage_event(
            user_id="user_123",
            token_info=info,
            plan_config=pro_plan_config,
        )

        assert event.user_id == "user_123"
        assert event.model == "gpt-4o"
        assert event.input_tokens == 1000
        assert event.output_tokens == 200
        assert event.total_tokens == 1200
        assert event.cost_tokens > 0
        assert event.cost_total > 0
        assert event.synced is False
        assert event.id  # has a UUID

    def test_event_with_all_fields(self, pro_plan_config: PlanConfig):
        """Event with session, tools, and metadata."""
        info = TokenInfo(model="gpt-4o", input_tokens=500, output_tokens=100, total_tokens=600)
        event = create_usage_event(
            user_id="user_123",
            token_info=info,
            plan_config=pro_plan_config,
            session_id="sess_abc",
            tool_calls=["web_search"],
            metadata={"agent": "research"},
        )

        assert event.session_id == "sess_abc"
        assert event.tool_calls == ["web_search"]
        assert event.cost_tools == pytest.approx(0.05)
        assert event.metadata == {"agent": "research"}

    def test_event_calculates_total_tokens_if_missing(self, pro_plan_config: PlanConfig):
        """If total_tokens is 0, it should be calculated from input + output."""
        info = TokenInfo(model="gpt-4o", input_tokens=300, output_tokens=100, total_tokens=0)
        event = create_usage_event(
            user_id="user_1",
            token_info=info,
            plan_config=pro_plan_config,
        )
        assert event.total_tokens == 400

    def test_unique_event_ids(self, pro_plan_config: PlanConfig):
        """Each event gets a unique ID (idempotency key)."""
        info = TokenInfo(model="gpt-4o", input_tokens=100, output_tokens=50, total_tokens=150)
        e1 = create_usage_event("u1", info, pro_plan_config)
        e2 = create_usage_event("u1", info, pro_plan_config)
        assert e1.id != e2.id

    def test_fail_open_on_bad_input(self):
        """Even with a broken plan config, should return a zero-cost event."""
        info = TokenInfo(model="gpt-4o", input_tokens=100, output_tokens=50, total_tokens=150)
        # Pass None as plan_config to trigger exception
        event = create_usage_event("u1", info, plan_config=None)
        assert event.user_id == "u1"
        assert event.cost_total == 0.0


# ---------------------------------------------------------------------------
# Cache Update
# ---------------------------------------------------------------------------


class TestUpdateCache:
    def _make_event(self, model="gpt-4o", cost_total=0.10, cost_tokens=0.08,
                    total_tokens=500, tool_calls=None):
        from paygent.models import UsageEvent
        return UsageEvent(
            user_id="user_1",
            model=model,
            cost_tokens=cost_tokens,
            cost_tools=cost_total - cost_tokens,
            cost_total=cost_total,
            total_tokens=total_tokens,
            input_tokens=300,
            output_tokens=200,
            tool_calls=tool_calls or [],
        )

    def test_basic_cache_update(self, pro_session: UserSession):
        """Cache should reflect the event's cost and tokens."""
        event = self._make_event()
        update_cache(pro_session, event)

        usage = pro_session.current_usage
        assert usage.period_cost == pytest.approx(0.10)
        assert usage.session_cost == pytest.approx(0.10)
        assert usage.period_tokens_total == 500
        assert usage.period_tokens_by_model["gpt-4o"] == 500
        assert usage.period_cost_by_model["gpt-4o"] == pytest.approx(0.08)

    def test_multiple_events_accumulate(self, pro_session: UserSession):
        """Multiple events should accumulate in the cache."""
        e1 = self._make_event(model="gpt-4o", cost_total=0.10, cost_tokens=0.08, total_tokens=500)
        e2 = self._make_event(model="gpt-4o", cost_total=0.20, cost_tokens=0.18, total_tokens=1000)
        update_cache(pro_session, e1)
        update_cache(pro_session, e2)

        usage = pro_session.current_usage
        assert usage.period_cost == pytest.approx(0.30)
        assert usage.session_cost == pytest.approx(0.30)
        assert usage.period_tokens_total == 1500
        assert usage.period_tokens_by_model["gpt-4o"] == 1500
        assert usage.period_cost_by_model["gpt-4o"] == pytest.approx(0.26)

    def test_multi_model_tracking(self, pro_session: UserSession):
        """Different models should be tracked independently."""
        e1 = self._make_event(model="gpt-4o", cost_total=0.10, cost_tokens=0.08, total_tokens=500)
        e2 = self._make_event(model="claude-sonnet-4-20250514", cost_total=0.20, cost_tokens=0.18, total_tokens=800)
        update_cache(pro_session, e1)
        update_cache(pro_session, e2)

        usage = pro_session.current_usage
        assert usage.period_cost == pytest.approx(0.30)
        assert usage.period_tokens_total == 1300
        assert usage.period_tokens_by_model["gpt-4o"] == 500
        assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 800
        assert usage.period_cost_by_model["gpt-4o"] == pytest.approx(0.08)
        assert usage.period_cost_by_model["claude-sonnet-4-20250514"] == pytest.approx(0.18)

    def test_no_model_skips_per_model_tracking(self, pro_session: UserSession):
        """Event without a model name should update totals but not per-model dicts."""
        event = self._make_event(model=None, cost_total=0.05, cost_tokens=0.0, total_tokens=200)
        update_cache(pro_session, event)

        usage = pro_session.current_usage
        assert usage.period_cost == pytest.approx(0.05)
        assert usage.period_tokens_total == 200
        assert usage.period_tokens_by_model == {}
        assert usage.period_cost_by_model == {}

    def test_cache_update_with_existing_usage(self, pro_plan_config: PlanConfig):
        """Cache update on a session that already has usage from backend bootstrap."""
        existing_usage = CurrentUsage(
            period_cost=23.47,
            session_cost=1.20,
            period_tokens_total=51700,
            period_tokens_by_model={"gpt-4o": 31200, "claude-sonnet-4-20250514": 8400},
            period_cost_by_model={"gpt-4o": 15.60, "claude-sonnet-4-20250514": 5.04},
        )
        session = UserSession(
            user_id="user_123",
            plan="pro",
            plan_config=pro_plan_config,
            current_usage=existing_usage,
        )

        event = self._make_event(model="gpt-4o", cost_total=0.10, cost_tokens=0.08, total_tokens=500)
        update_cache(session, event)

        usage = session.current_usage
        assert usage.period_cost == pytest.approx(23.57)
        assert usage.session_cost == pytest.approx(1.30)
        assert usage.period_tokens_total == 52200
        assert usage.period_tokens_by_model["gpt-4o"] == 31700
        # Claude tokens unchanged
        assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 8400

    def test_fail_open_on_broken_session(self):
        """If session or usage is broken, update should not raise."""
        from paygent.models import UsageEvent
        event = UsageEvent(user_id="u1", cost_total=0.10, total_tokens=100)

        # Pass None as session — should not raise
        update_cache(None, event)  # type: ignore

    def test_zero_cost_event(self, pro_session: UserSession):
        """Zero-cost event should still update token counts."""
        event = self._make_event(model="gpt-4o", cost_total=0.0, cost_tokens=0.0, total_tokens=100)
        update_cache(pro_session, event)

        usage = pro_session.current_usage
        assert usage.period_cost == 0.0
        assert usage.period_tokens_total == 100
        assert usage.period_tokens_by_model["gpt-4o"] == 100


# ---------------------------------------------------------------------------
# Floating-point accumulation
# ---------------------------------------------------------------------------


class TestFloatAccumulation:
    """Guards against silent drift when many small-cost events accumulate.

    ``period_cost`` is summed with plain ``+=`` so every addition can introduce
    up to ~1 ULP of rounding error.  For 10,000 events at $0.0001 each the
    drift typically lands in the 10^-13 range — nowhere near breaking a hard
    gate, but worth asserting so a future change (e.g. switching to ``Decimal``
    or accidentally introducing a loss-compounding pattern) is caught.
    """

    def test_10k_small_events_accumulate_to_expected_total(
        self, pro_session: UserSession
    ):
        from paygent.models import UsageEvent

        pro_session.current_usage = CurrentUsage()
        per_event_cost = 0.0001

        for _ in range(10_000):
            event = UsageEvent(
                user_id="user_1",
                model="gpt-4o",
                cost_total=per_event_cost,
                cost_tokens=per_event_cost,
                cost_tools=0.0,
                total_tokens=1,
                input_tokens=1,
                output_tokens=0,
            )
            update_cache(pro_session, event)

        usage = pro_session.current_usage
        assert usage.period_tokens_total == 10_000
        # Exact count is integer — must be precise
        assert usage.period_tokens_by_model["gpt-4o"] == 10_000
        # Cost is float — allow ~1 ULP per add (~10k * 1e-16 ≈ 1e-12)
        expected = 1.0
        assert usage.period_cost == pytest.approx(expected, abs=1e-9), (
            f"period_cost drift > 1e-9: got {usage.period_cost!r}, "
            f"diff={usage.period_cost - expected!r}"
        )
        assert usage.period_cost_by_model["gpt-4o"] == pytest.approx(expected, abs=1e-9)

    def test_accumulated_total_does_not_wrap_past_limit_on_equal_boundary(
        self, pro_session: UserSession
    ):
        """A limit set exactly equal to the expected total must not be
        prematurely tripped by float drift.

        If ``period_cost`` over-runs by even a single ULP, a naive
        ``period_cost >= limit`` check could fire at the last event when the
        ideal real-number total would be exactly at the limit.  Asserts the
        accumulated value is not meaningfully above the expected total.
        """
        from paygent.models import UsageEvent

        pro_session.current_usage = CurrentUsage()
        for _ in range(1_000):
            update_cache(
                pro_session,
                UsageEvent(
                    user_id="u1",
                    model="gpt-4o",
                    cost_total=0.001,
                    cost_tokens=0.001,
                    total_tokens=1,
                ),
            )

        # Target is 1.0.  Drift should be well under 1e-12 for 1000 adds.
        assert abs(pro_session.current_usage.period_cost - 1.0) < 1e-12


# ---------------------------------------------------------------------------
# Model name edge cases
# ---------------------------------------------------------------------------


class TestModelNameEdgeCases:
    """Hostile / unusual model names must not crash the metering pipeline.

    Covers create_usage_event → normalize_model_name → update_cache for:
      - empty string
      - special characters (slash, colon, underscore)
      - very long strings
      - None (tool-only events)
    """

    def test_empty_string_model(self, pro_plan_config: PlanConfig):
        """Empty model name is treated like any other unknown model."""
        info = TokenInfo(model="", input_tokens=100, output_tokens=50, total_tokens=150)
        event = create_usage_event("u1", info, pro_plan_config)
        # Empty string stays empty — not rewritten to None
        assert event.model == ""
        assert event.total_tokens == 150
        # No cost rate for "" → zero cost, tokens still counted
        assert event.cost_tokens == 0.0

    def test_empty_string_model_cache_update(self, pro_session: UserSession):
        """Empty model name is treated like None by the cache update.

        ``update_cache`` uses a truthiness check (``if event.model``) before
        indexing into ``period_tokens_by_model``, so empty string is skipped
        alongside None.  Totals still accumulate — we just don't pollute the
        per-model breakdown with an empty-string bucket.
        """
        from paygent.models import UsageEvent
        pro_session.current_usage = CurrentUsage()
        update_cache(
            pro_session,
            UsageEvent(user_id="u1", model="", total_tokens=100, cost_total=0.0),
        )
        assert pro_session.current_usage.period_tokens_total == 100
        assert pro_session.current_usage.period_tokens_by_model == {}

    def test_special_characters_model(self, pro_plan_config: PlanConfig):
        """Models with slashes, colons, hyphens (e.g. fine-tuned names)."""
        name = "my-custom/model:v1.2_beta"
        info = TokenInfo(model=name, input_tokens=500, output_tokens=100, total_tokens=600)
        event = create_usage_event("u1", info, pro_plan_config)
        assert event.model == name
        assert event.total_tokens == 600

    def test_very_long_model_name(self, pro_plan_config: PlanConfig):
        """A 1000-char model name must not crash normalization or metering."""
        name = "x" * 1000
        info = TokenInfo(model=name, input_tokens=10, output_tokens=5, total_tokens=15)
        event = create_usage_event("u1", info, pro_plan_config)
        assert event.model == name
        assert len(event.model) == 1000
        assert event.total_tokens == 15

    def test_none_model_tool_only_event(self, pro_plan_config: PlanConfig):
        """Tool-only events (no LLM call) have model=None."""
        info = TokenInfo(model=None, input_tokens=0, output_tokens=0, total_tokens=0)
        event = create_usage_event(
            "u1",
            info,
            pro_plan_config,
            tool_calls=["web_search"],
        )
        assert event.model is None
        assert event.total_tokens == 0
        # Tool cost still applies
        assert event.cost_tools == pytest.approx(0.05)
        assert event.cost_total == pytest.approx(0.05)

    def test_none_model_cache_update_does_not_index_by_model(
        self, pro_session: UserSession
    ):
        """When model is None, period_tokens_by_model must not grow."""
        from paygent.models import UsageEvent
        pro_session.current_usage = CurrentUsage()
        update_cache(
            pro_session,
            UsageEvent(user_id="u1", model=None, total_tokens=0, cost_total=0.05),
        )
        # None model must not appear as a dict key
        assert None not in pro_session.current_usage.period_tokens_by_model
        assert pro_session.current_usage.period_cost == pytest.approx(0.05)

    def test_normalize_model_name_edge_cases(self, pro_plan_config: PlanConfig):
        """normalize_model_name handles empty / None / long / special strings."""
        # Empty string — no prefix match, returns unchanged
        assert normalize_model_name("", pro_plan_config) == ""
        # None — returned as-is
        assert normalize_model_name(None, pro_plan_config) is None
        # Very long — no prefix match, returned unchanged
        long_name = "x" * 1000
        assert normalize_model_name(long_name, pro_plan_config) == long_name
        # Special characters — no configured match
        weird = "my-custom/model:v1"
        assert normalize_model_name(weird, pro_plan_config) == weird
