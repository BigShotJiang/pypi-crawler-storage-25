"""Tests for multiple LLM calls with same and different providers.

Covers all three metering variants:
1. Wrap function (pg.wrap / pg.awrap)
2. Monkey-patching (create_sync_wrapper / create_async_wrapper)
3. Framework callbacks (LangChain / CrewAI)

Each section tests:
- Multiple calls with same provider & same model
- Multiple calls with same provider & different models
- Multiple calls with different providers (interleaved)
- Usage accumulation correctness across providers
- Per-event data integrity after mixed calls
- Guardrail triggers from cross-provider accumulated cost
"""

from __future__ import annotations

import os
import tempfile
from types import SimpleNamespace
from typing import Any, Dict, List, Optional
from unittest.mock import patch
from uuid import uuid4

import pytest

from paygent.context import paygent_context
from paygent.core import Paygent
from paygent.guardrails import PaygentLimitExceeded
from paygent.metering import create_usage_event, update_cache
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserSession,
)
from paygent.patcher import create_async_wrapper, create_sync_wrapper
from paygent.providers import (
    ProviderConfig,
    TokenInfo,
    extract_anthropic_tokens,
    extract_openai_tokens,
)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _tmp_db_path() -> str:
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return tmp.name


def _make_pg(**kwargs) -> Paygent:
    defaults = dict(
        db_path=_tmp_db_path(),
        auto_instrument=False,
        flush_interval=60.0,
    )
    defaults.update(kwargs)
    return Paygent.init(**defaults)


def _cleanup_pg(pg: Paygent) -> None:
    db_path = pg.storage.db_path
    pg.shutdown()
    try:
        os.unlink(db_path)
    except OSError:
        pass


MULTI_MODEL_CONFIG = PlanConfig(
    max_spend_per_period=100.00,
    max_spend_per_session=10.00,
    soft_gate_at=0.80,
    hard_gate_at=1.00,
    cost_rates={
        "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
        "gpt-4o-mini": ModelCostRate(input=0.00015, output=0.0006),
        "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
    },
    model_limits={
        "gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000),
        "claude-sonnet-4-20250514": ModelLimitConfig(max_tokens_per_period=30_000),
    },
)


def _openai_response(model="gpt-4o", input_tokens=100, output_tokens=50):
    """Simulate an OpenAI ChatCompletion response."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(
            prompt_tokens=input_tokens,
            completion_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        ),
        choices=[SimpleNamespace(message=SimpleNamespace(content="Hello"))],
    )


def _anthropic_response(model="claude-sonnet-4-20250514", input_tokens=80, output_tokens=40):
    """Simulate an Anthropic Messages response."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        ),
        content=[SimpleNamespace(text="Hello")],
    )


def _openai_provider():
    return ProviderConfig(
        name="openai",
        module_path="openai.resources.chat.completions",
        class_name="Completions",
        method_name="create",
        extract_tokens=extract_openai_tokens,
    )


def _anthropic_provider():
    return ProviderConfig(
        name="anthropic",
        module_path="anthropic.resources.messages",
        class_name="Messages",
        method_name="create",
        extract_tokens=extract_anthropic_tokens,
    )


def _make_session(user_id="user_1", config=None) -> UserSession:
    return UserSession(
        user_id=user_id,
        plan="pro",
        plan_config=config or MULTI_MODEL_CONFIG,
        current_usage=CurrentUsage(),
    )


# =========================================================================
# SECTION 1: Wrap Function — Multi-Call / Multi-Provider
# =========================================================================


class TestWrapMultiCallSameProviderSameModel:
    """pg.wrap(): multiple calls, same provider (OpenAI), same model."""

    def test_tokens_accumulate(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            for i in range(5):
                resp = _openai_response(model="gpt-4o", input_tokens=100, output_tokens=50)
                pg.wrap(lambda: resp, user_id="u1", model="gpt-4o")

            usage = pg.get_usage("u1")
            assert usage.period_tokens_total == 750  # 5 * 150
            assert usage.period_tokens_by_model["gpt-4o"] == 750
            assert pg.pending_events == 5
        finally:
            _cleanup_pg(pg)

    def test_cost_accumulates(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            for _ in range(3):
                resp = _openai_response(model="gpt-4o", input_tokens=1000, output_tokens=500)
                pg.wrap(lambda: resp, user_id="u1", model="gpt-4o")

            usage = pg.get_usage("u1")
            # Per call: (1000/1000)*0.0025 + (500/1000)*0.01 = 0.0075
            expected = 3 * 0.0075
            assert usage.period_cost == pytest.approx(expected, rel=0.01)
        finally:
            _cleanup_pg(pg)


class TestWrapMultiCallSameProviderDifferentModels:
    """pg.wrap(): same provider (OpenAI), different models (gpt-4o vs gpt-4o-mini)."""

    def test_per_model_tracking(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            for _ in range(2):
                pg.wrap(lambda: _openai_response("gpt-4o", 200, 100), user_id="u1", model="gpt-4o")

            pg.wrap(lambda: _openai_response("gpt-4o-mini", 300, 150), user_id="u1", model="gpt-4o-mini")

            usage = pg.get_usage("u1")
            assert usage.period_tokens_by_model["gpt-4o"] == 600       # 2 * 300
            assert usage.period_tokens_by_model["gpt-4o-mini"] == 450  # 1 * 450
            assert usage.period_tokens_total == 1050
        finally:
            _cleanup_pg(pg)

    def test_per_model_cost_differs(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            pg.wrap(lambda: _openai_response("gpt-4o", 1000, 500), user_id="u1", model="gpt-4o")
            pg.wrap(lambda: _openai_response("gpt-4o-mini", 1000, 500), user_id="u1", model="gpt-4o-mini")

            usage = pg.get_usage("u1")
            # gpt-4o is much more expensive
            assert usage.period_cost_by_model["gpt-4o"] > usage.period_cost_by_model["gpt-4o-mini"]
        finally:
            _cleanup_pg(pg)


class TestWrapMultiCallDifferentProviders:
    """pg.wrap(): interleaved OpenAI and Anthropic calls."""

    def test_interleaved_calls_tracked_separately(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            # OpenAI → Anthropic → OpenAI
            pg.wrap(lambda: _openai_response("gpt-4o", 100, 50), user_id="u1", provider="openai")
            pg.wrap(lambda: _anthropic_response("claude-sonnet-4-20250514", 200, 100), user_id="u1", provider="anthropic")
            pg.wrap(lambda: _openai_response("gpt-4o", 150, 75), user_id="u1", provider="openai")

            usage = pg.get_usage("u1")
            assert usage.period_tokens_by_model["gpt-4o"] == 375        # 150 + 225
            assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 300  # 200 + 100
            assert usage.period_tokens_total == 675
            assert pg.pending_events == 3
        finally:
            _cleanup_pg(pg)

    def test_cross_provider_cost_sums(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            pg.wrap(lambda: _openai_response("gpt-4o", 1000, 500), user_id="u1", provider="openai")
            pg.wrap(lambda: _anthropic_response("claude-sonnet-4-20250514", 1000, 500), user_id="u1", provider="anthropic")

            usage = pg.get_usage("u1")
            gpt_cost = usage.period_cost_by_model["gpt-4o"]
            claude_cost = usage.period_cost_by_model["claude-sonnet-4-20250514"]
            assert gpt_cost > 0
            assert claude_cost > 0
            assert usage.period_cost == pytest.approx(gpt_cost + claude_cost, rel=0.01)
        finally:
            _cleanup_pg(pg)

    def test_per_event_data_after_mixed_calls(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=MULTI_MODEL_CONFIG)

            pg.wrap(lambda: _openai_response("gpt-4o", 100, 50), user_id="u1", model="gpt-4o")
            pg.wrap(lambda: _anthropic_response("claude-sonnet-4-20250514", 80, 40), user_id="u1", model="claude-sonnet-4-20250514")

            pg.flush()
            events = pg.storage.get_unsynced_events_sync()
            assert len(events) == 2

            by_model = {e.model: e for e in events}
            gpt = by_model["gpt-4o"]
            assert gpt.input_tokens == 100
            assert gpt.output_tokens == 50
            assert gpt.cost_total > 0

            claude = by_model["claude-sonnet-4-20250514"]
            assert claude.input_tokens == 80
            assert claude.output_tokens == 40
            assert claude.cost_total > 0
        finally:
            _cleanup_pg(pg)

    def test_cross_provider_guardrail_trigger(self):
        """Accumulated cost across providers should trigger hard gate."""
        config = PlanConfig(
            max_spend_per_period=0.003,
            cost_rates={
                "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
                "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
            },
        )
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=config)

            # First call eats most of the budget
            pg.wrap(lambda: _openai_response("gpt-4o", 500, 200), user_id="u1", model="gpt-4o")

            # Second call from different provider should push past limit
            with pytest.raises(PaygentLimitExceeded) as exc_info:
                pg.wrap(lambda: _anthropic_response("claude-sonnet-4-20250514", 500, 200), user_id="u1", model="claude-sonnet-4-20250514")

            assert exc_info.value.guard_result.gate_reason == "total_spend"
        finally:
            _cleanup_pg(pg)


# =========================================================================
# SECTION 2: Monkey-Patching — Multi-Call / Multi-Provider
# =========================================================================


class TestPatcherMultiCallSameModel:
    """Sync wrapper: multiple calls, same model."""

    def test_tokens_accumulate_across_calls(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}

        def original(**kwargs):
            return _openai_response("gpt-4o", 100, 50)

        wrapper = create_sync_wrapper(
            original=original,
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="u1"):
            for _ in range(4):
                wrapper(model="gpt-4o", messages=[])

        assert len(events) == 4
        assert session.current_usage.period_tokens_total == 600  # 4 * 150
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 600

    def test_cost_accumulates(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}

        def original(**kwargs):
            return _openai_response("gpt-4o", 1000, 500)

        wrapper = create_sync_wrapper(
            original=original,
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="u1"):
            for _ in range(3):
                wrapper(model="gpt-4o", messages=[])

        expected = 3 * 0.0075
        assert session.current_usage.period_cost == pytest.approx(expected, rel=0.01)


class TestPatcherMultiCallSameProviderDifferentModels:
    """Sync wrapper: same provider, different models via different responses."""

    def test_per_model_tracking(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}

        call_count = 0

        def original(**kwargs):
            nonlocal call_count
            call_count += 1
            model = kwargs.get("model", "gpt-4o")
            if model == "gpt-4o-mini":
                return _openai_response("gpt-4o-mini", 300, 150)
            return _openai_response("gpt-4o", 200, 100)

        wrapper = create_sync_wrapper(
            original=original,
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="u1"):
            wrapper(model="gpt-4o", messages=[])
            wrapper(model="gpt-4o", messages=[])
            wrapper(model="gpt-4o-mini", messages=[])

        assert len(events) == 3
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 600
        assert session.current_usage.period_tokens_by_model["gpt-4o-mini"] == 450
        assert session.current_usage.period_tokens_total == 1050


class TestPatcherMultiCallDifferentProviders:
    """Two separate wrapped methods simulating OpenAI + Anthropic monkey-patches."""

    def test_interleaved_providers(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}
        sink = lambda e: events.append(e)

        def openai_original(**kwargs):
            return _openai_response("gpt-4o", 100, 50)

        def anthropic_original(**kwargs):
            return _anthropic_response("claude-sonnet-4-20250514", 200, 100)

        openai_wrapper = create_sync_wrapper(
            original=openai_original,
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        anthropic_wrapper = create_sync_wrapper(
            original=anthropic_original,
            provider=_anthropic_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        with paygent_context(user_id="u1"):
            openai_wrapper(model="gpt-4o", messages=[])
            anthropic_wrapper(model="claude-sonnet-4-20250514", messages=[])
            openai_wrapper(model="gpt-4o", messages=[])

        assert len(events) == 3
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 300
        assert session.current_usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 300
        assert session.current_usage.period_tokens_total == 600

    def test_cross_provider_cost_sums(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}
        sink = lambda e: events.append(e)

        openai_wrapper = create_sync_wrapper(
            original=lambda **kw: _openai_response("gpt-4o", 1000, 500),
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        anthropic_wrapper = create_sync_wrapper(
            original=lambda **kw: _anthropic_response("claude-sonnet-4-20250514", 1000, 500),
            provider=_anthropic_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        with paygent_context(user_id="u1"):
            openai_wrapper(model="gpt-4o", messages=[])
            anthropic_wrapper(model="claude-sonnet-4-20250514", messages=[])

        gpt_cost = session.current_usage.period_cost_by_model["gpt-4o"]
        claude_cost = session.current_usage.period_cost_by_model["claude-sonnet-4-20250514"]
        assert gpt_cost > 0
        assert claude_cost > 0
        assert session.current_usage.period_cost == pytest.approx(gpt_cost + claude_cost, rel=0.01)

    def test_per_event_data_integrity(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}
        sink = lambda e: events.append(e)

        openai_wrapper = create_sync_wrapper(
            original=lambda **kw: _openai_response("gpt-4o", 100, 50),
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        anthropic_wrapper = create_sync_wrapper(
            original=lambda **kw: _anthropic_response("claude-sonnet-4-20250514", 80, 40),
            provider=_anthropic_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        with paygent_context(user_id="u1"):
            openai_wrapper(model="gpt-4o", messages=[])
            anthropic_wrapper(model="claude-sonnet-4-20250514", messages=[])

        by_model = {e.model: e for e in events}
        assert by_model["gpt-4o"].input_tokens == 100
        assert by_model["gpt-4o"].output_tokens == 50
        assert by_model["claude-sonnet-4-20250514"].input_tokens == 80
        assert by_model["claude-sonnet-4-20250514"].output_tokens == 40

    def test_cross_provider_guardrail_trigger(self):
        """Hard gate from accumulated spend across two providers."""
        config = PlanConfig(
            max_spend_per_period=0.003,
            cost_rates={
                "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
                "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
            },
        )
        session = UserSession(
            user_id="u1", plan="pro", plan_config=config,
            current_usage=CurrentUsage(),
        )
        sessions = {"u1": session}
        events = []

        openai_wrapper = create_sync_wrapper(
            original=lambda **kw: _openai_response("gpt-4o", 500, 200),
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
            raise_on_hard_gate=True,
        )

        anthropic_wrapper = create_sync_wrapper(
            original=lambda **kw: _anthropic_response("claude-sonnet-4-20250514", 500, 200),
            provider=_anthropic_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
            raise_on_hard_gate=True,
        )

        with paygent_context(user_id="u1"):
            # First call — should succeed and eat most of the tiny budget
            openai_wrapper(model="gpt-4o", messages=[])

            # Second call from different provider — should hit hard gate
            with pytest.raises(PaygentLimitExceeded) as exc_info:
                anthropic_wrapper(model="claude-sonnet-4-20250514", messages=[])

            assert exc_info.value.guard_result.gate_reason == "total_spend"


class TestPatcherAsyncMultiProvider:
    """Async wrappers: interleaved OpenAI + Anthropic."""

    @pytest.mark.asyncio
    async def test_async_interleaved_providers(self):
        events = []
        session = _make_session()
        sessions = {"u1": session}
        sink = lambda e: events.append(e)

        async def openai_original(**kwargs):
            return _openai_response("gpt-4o", 100, 50)

        async def anthropic_original(**kwargs):
            return _anthropic_response("claude-sonnet-4-20250514", 200, 100)

        openai_wrapper = create_async_wrapper(
            original=openai_original,
            provider=_openai_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        anthropic_wrapper = create_async_wrapper(
            original=anthropic_original,
            provider=_anthropic_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=sink,
        )

        with paygent_context(user_id="u1"):
            await openai_wrapper(model="gpt-4o", messages=[])
            await anthropic_wrapper(model="claude-sonnet-4-20250514", messages=[])
            await openai_wrapper(model="gpt-4o", messages=[])

        assert len(events) == 3
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 300
        assert session.current_usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 300


# =========================================================================
# SECTION 3: Framework Callbacks — Multi-Call / Multi-Provider
# =========================================================================


# --- Mock LangChain types ---

class MockBaseCallbackHandler:
    pass


class MockLLMResult:
    def __init__(self, llm_output=None, generations=None):
        self.llm_output = llm_output or {}
        self.generations = generations or []


# --- Mock CrewAI types ---

class MockStepOutput:
    def __init__(self, token_usage=None, model=None, result=None):
        self.token_usage = token_usage
        self.model = model
        self.result = result


@pytest.fixture
def pg_framework(tmp_path):
    """Create a Paygent instance configured for framework callback tests."""
    instance = Paygent(
        db_path=str(tmp_path / "test.db"),
        auto_instrument=False,
    )
    instance._initialized = True
    config = PlanConfig(
        max_spend_per_period=100.0,
        cost_rates={
            "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
            "gpt-4o-mini": ModelCostRate(input=0.00015, output=0.0006),
            "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
        },
        model_limits={
            "gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000),
            "claude-sonnet-4-20250514": ModelLimitConfig(max_tokens_per_period=30_000),
        },
    )
    instance.start_session("user_fw", plan="pro", plan_config=config)
    yield instance
    Paygent._instance = None


@pytest.fixture(autouse=True)
def mock_langchain():
    """Mock langchain_core so the integration can be imported without it."""
    with patch(
        "paygent.integrations.langchain._get_base_handler",
        return_value=MockBaseCallbackHandler,
    ):
        yield


class TestLangChainMultiCall:
    """LangChain callback: multiple calls, same and different models."""

    def test_multiple_calls_same_model(self, pg_framework):
        from paygent.integrations.langchain import LangChainCallback

        cb = LangChainCallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        for _ in range(3):
            run_id = uuid4()
            cb.on_llm_start(
                serialized={}, prompts=["Hi"],
                run_id=run_id,
                invocation_params={"model": "gpt-4o"},
            )
            cb.on_llm_end(
                MockLLMResult(llm_output={
                    "token_usage": {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
                    "model_name": "gpt-4o",
                }),
                run_id=run_id,
            )

        assert len(events) == 3
        usage = pg_framework.get_usage("user_fw")
        assert usage.period_tokens_total == 450
        assert usage.period_tokens_by_model["gpt-4o"] == 450

    def test_multiple_calls_different_models(self, pg_framework):
        from paygent.integrations.langchain import LangChainCallback

        cb = LangChainCallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        # gpt-4o call
        run_id_1 = uuid4()
        cb.on_llm_start(
            serialized={}, prompts=["Hi"],
            run_id=run_id_1,
            invocation_params={"model": "gpt-4o"},
        )
        cb.on_llm_end(
            MockLLMResult(llm_output={
                "token_usage": {"prompt_tokens": 200, "completion_tokens": 100, "total_tokens": 300},
                "model_name": "gpt-4o",
            }),
            run_id=run_id_1,
        )

        # claude call
        run_id_2 = uuid4()
        cb.on_llm_start(
            serialized={}, prompts=["Hello"],
            run_id=run_id_2,
            invocation_params={"model": "claude-sonnet-4-20250514"},
        )
        cb.on_llm_end(
            MockLLMResult(llm_output={
                "token_usage": {"prompt_tokens": 150, "completion_tokens": 75, "total_tokens": 225},
                "model_name": "claude-sonnet-4-20250514",
            }),
            run_id=run_id_2,
        )

        # gpt-4o-mini call
        run_id_3 = uuid4()
        cb.on_llm_start(
            serialized={}, prompts=["Hey"],
            run_id=run_id_3,
            invocation_params={"model": "gpt-4o-mini"},
        )
        cb.on_llm_end(
            MockLLMResult(llm_output={
                "token_usage": {"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
                "model_name": "gpt-4o-mini",
            }),
            run_id=run_id_3,
        )

        assert len(events) == 3
        usage = pg_framework.get_usage("user_fw")
        assert usage.period_tokens_by_model["gpt-4o"] == 300
        assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 225
        assert usage.period_tokens_by_model["gpt-4o-mini"] == 150
        assert usage.period_tokens_total == 675

    def test_cross_model_cost_accumulation(self, pg_framework):
        from paygent.integrations.langchain import LangChainCallback

        cb = LangChainCallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        # gpt-4o
        run_id_1 = uuid4()
        cb.on_llm_start(serialized={}, prompts=["Hi"], run_id=run_id_1,
                         invocation_params={"model": "gpt-4o"})
        cb.on_llm_end(MockLLMResult(llm_output={
            "token_usage": {"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500},
            "model_name": "gpt-4o",
        }), run_id=run_id_1)

        # claude
        run_id_2 = uuid4()
        cb.on_llm_start(serialized={}, prompts=["Hi"], run_id=run_id_2,
                         invocation_params={"model": "claude-sonnet-4-20250514"})
        cb.on_llm_end(MockLLMResult(llm_output={
            "token_usage": {"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500},
            "model_name": "claude-sonnet-4-20250514",
        }), run_id=run_id_2)

        usage = pg_framework.get_usage("user_fw")
        gpt_cost = usage.period_cost_by_model["gpt-4o"]
        claude_cost = usage.period_cost_by_model["claude-sonnet-4-20250514"]
        assert gpt_cost > 0
        assert claude_cost > 0
        assert usage.period_cost == pytest.approx(gpt_cost + claude_cost, rel=0.01)


class TestCrewAIMultiCall:
    """CrewAI callback: multiple calls, same and different models."""

    def test_multiple_steps_same_model(self, pg_framework):
        from paygent.integrations.crewai import CrewAICallback

        cb = CrewAICallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        for _ in range(4):
            step = MockStepOutput(
                token_usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
                model="gpt-4o",
            )
            cb(step)

        assert len(events) == 4
        usage = pg_framework.get_usage("user_fw")
        assert usage.period_tokens_total == 600
        assert usage.period_tokens_by_model["gpt-4o"] == 600

    def test_multiple_steps_different_models(self, pg_framework):
        from paygent.integrations.crewai import CrewAICallback

        cb = CrewAICallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        # gpt-4o step
        cb(MockStepOutput(
            token_usage={"prompt_tokens": 200, "completion_tokens": 100, "total_tokens": 300},
            model="gpt-4o",
        ))

        # claude step
        cb(MockStepOutput(
            token_usage={"prompt_tokens": 150, "completion_tokens": 75, "total_tokens": 225},
            model="claude-sonnet-4-20250514",
        ))

        # gpt-4o-mini step
        cb(MockStepOutput(
            token_usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            model="gpt-4o-mini",
        ))

        assert len(events) == 3
        usage = pg_framework.get_usage("user_fw")
        assert usage.period_tokens_by_model["gpt-4o"] == 300
        assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 225
        assert usage.period_tokens_by_model["gpt-4o-mini"] == 150
        assert usage.period_tokens_total == 675

    def test_interleaved_models_cost(self, pg_framework):
        from paygent.integrations.crewai import CrewAICallback

        cb = CrewAICallback(pg_framework, user_id="user_fw")
        events = []
        pg_framework._event_sink = lambda e: events.append(e)

        cb(MockStepOutput(
            token_usage={"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500},
            model="gpt-4o",
        ))
        cb(MockStepOutput(
            token_usage={"prompt_tokens": 1000, "completion_tokens": 500, "total_tokens": 1500},
            model="claude-sonnet-4-20250514",
        ))

        usage = pg_framework.get_usage("user_fw")
        gpt_cost = usage.period_cost_by_model["gpt-4o"]
        claude_cost = usage.period_cost_by_model["claude-sonnet-4-20250514"]
        assert gpt_cost > 0
        assert claude_cost > 0
        assert gpt_cost != claude_cost  # Different rates
        assert usage.period_cost == pytest.approx(gpt_cost + claude_cost, rel=0.01)
