"""Tests for LocalCache — orchestrates local storage + backend sync.

Uses mock ApiClient and real SQLite storage (temp files).
"""

from __future__ import annotations

import os
import tempfile
from unittest.mock import MagicMock, patch

import pytest

from paygent.api_client import ApiClient, BatchResult
from paygent.local_cache import LocalCache, StoreResult
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
    UserSession,
)
from paygent.storage.sqlite import SQLiteStorage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tmp_storage() -> SQLiteStorage:
    """Create and initialize a temp SQLite storage."""
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    storage = SQLiteStorage(db_path=tmp.name)
    storage.initialize_sync()
    return storage


def _cleanup_storage(storage: SQLiteStorage) -> None:
    db_path = storage.db_path
    storage.close_sync()
    try:
        os.unlink(db_path)
    except OSError:
        pass


def _mock_api_client(
    session_response: UserSession | None = None,
    post_result: BatchResult | None = None,
    health: bool = True,
) -> MagicMock:
    """Create a mock ApiClient with configurable responses."""
    mock = MagicMock(spec=ApiClient)
    mock.fetch_session.return_value = session_response
    mock.post_events.return_value = post_result
    mock.health_check.return_value = health
    return mock


def _sample_session(user_id: str = "user_123") -> UserSession:
    """Create a sample UserSession for testing."""
    return UserSession(
        user_id=user_id,
        plan="pro",
        plan_config=PlanConfig(
            max_spend_per_period=49.00,
            model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50000)},
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        ),
        current_usage=CurrentUsage(period_cost=23.47),
    )


# ---------------------------------------------------------------------------
# Bootstrap Session
# ---------------------------------------------------------------------------


class TestBootstrapSession:
    def test_from_backend(self):
        """Should fetch session from backend when available."""
        storage = _tmp_storage()
        try:
            backend_session = _sample_session()
            api_client = _mock_api_client(session_response=backend_session)
            cache = LocalCache(storage=storage, api_client=api_client)

            session = cache.bootstrap_session("user_123")
            assert session.user_id == "user_123"
            assert session.plan == "pro"
            assert session.plan_config.max_spend_per_period == 49.00
            assert session.current_usage.period_cost == 23.47
            assert cache.backend_reachable is True
            api_client.fetch_session.assert_called_once_with("user_123")
        finally:
            _cleanup_storage(storage)

    def test_backend_returns_none(self):
        """Should fall back to local session when backend returns None."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(session_response=None)
            cache = LocalCache(storage=storage, api_client=api_client)

            config = PlanConfig(max_spend_per_period=10.00)
            session = cache.bootstrap_session(
                "user_123", fallback_plan="free", fallback_config=config
            )
            assert session.user_id == "user_123"
            assert session.plan == "free"
            assert session.plan_config.max_spend_per_period == 10.00
            assert session.current_usage.period_cost == 0.0
        finally:
            _cleanup_storage(storage)

    def test_backend_raises_error(self):
        """Should fall back gracefully on backend exception."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client()
            api_client.fetch_session.side_effect = Exception("Network error")
            cache = LocalCache(storage=storage, api_client=api_client)

            session = cache.bootstrap_session("user_123")
            assert session is not None
            assert session.user_id == "user_123"
            assert session.plan == "default"
            assert session.plan_config.max_spend_per_period == float("inf")
            assert cache.backend_reachable is False
        finally:
            _cleanup_storage(storage)

    def test_no_api_client(self):
        """Should create local session when no API client configured."""
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=None)
            assert not cache.has_backend

            session = cache.bootstrap_session("user_123", fallback_plan="local")
            assert session.user_id == "user_123"
            assert session.plan == "local"
        finally:
            _cleanup_storage(storage)

    def test_fallback_uses_permissive_defaults(self):
        """Default fallback should have infinite limits (fail-open)."""
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=None)
            session = cache.bootstrap_session("user_123")
            assert session.plan_config.max_spend_per_period == float("inf")
            assert session.plan_config.max_spend_per_session == float("inf")
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# Store and Sync
# ---------------------------------------------------------------------------


class TestStoreAndSync:
    def test_store_locally_only(self):
        """Without API client, events are stored locally only."""
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=None)
            events = [UsageEvent(user_id="user_1", model="gpt-4o") for _ in range(3)]

            result = cache.store_and_sync(events)
            assert result.stored_locally == 3
            assert result.synced_to_backend == 0

            # Verify stored in SQLite
            stored_events = storage.get_unsynced_events_sync()
            assert len(stored_events) == 3
        finally:
            _cleanup_storage(storage)

    def test_store_and_sync_to_backend(self):
        """With API client, events should be stored locally AND synced."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=3, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)
            events = [UsageEvent(user_id="user_1") for _ in range(3)]

            result = cache.store_and_sync(events)
            assert result.stored_locally == 3
            assert result.synced_to_backend == 3
            assert result.all_synced
            assert cache.backend_reachable is True

            api_client.post_events.assert_called_once()
        finally:
            _cleanup_storage(storage)

    def test_store_with_backend_failure(self):
        """Backend failure should not lose local events."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(post_result=None)  # Backend returns None
            cache = LocalCache(storage=storage, api_client=api_client)
            events = [UsageEvent(user_id="user_1") for _ in range(3)]

            result = cache.store_and_sync(events)
            assert result.stored_locally == 3
            assert result.synced_to_backend == 0
            assert not result.all_synced
            assert cache.backend_reachable is False

            # Events should still be in SQLite as unsynced
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 3
        finally:
            _cleanup_storage(storage)

    def test_store_with_backend_exception(self):
        """Backend exception should not lose local events."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client()
            api_client.post_events.side_effect = Exception("Network error")
            cache = LocalCache(storage=storage, api_client=api_client)
            events = [UsageEvent(user_id="user_1") for _ in range(2)]

            result = cache.store_and_sync(events)
            assert result.stored_locally == 2
            assert result.synced_to_backend == 0

            # Events are safe locally
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 2
        finally:
            _cleanup_storage(storage)

    def test_store_empty_list(self):
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage)
            result = cache.store_and_sync([])
            assert result.stored_locally == 0
            assert result.synced_to_backend == 0
        finally:
            _cleanup_storage(storage)

    def test_store_with_duplicates(self):
        """Backend reports duplicates — still counts toward all_synced."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=1, duplicates=2)
            )
            cache = LocalCache(storage=storage, api_client=api_client)
            events = [UsageEvent(user_id="user_1") for _ in range(3)]

            result = cache.store_and_sync(events)
            assert result.stored_locally == 3
            assert result.synced_to_backend == 1
            assert result.duplicates == 2
            assert result.all_synced  # 1 accepted + 2 dupes >= 3 stored
        finally:
            _cleanup_storage(storage)

    def test_synced_events_marked_in_sqlite(self):
        """After successful backend sync, events should be marked as synced."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=2, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)
            events = [UsageEvent(user_id="user_1") for _ in range(2)]

            cache.store_and_sync(events)

            # Events should now be synced — get_unsynced should return empty
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 0
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# Sync Pending
# ---------------------------------------------------------------------------


class TestSyncPending:
    def test_sync_pending_events(self):
        """Should sync previously unsynced events to backend."""
        storage = _tmp_storage()
        try:
            # Store events locally (no backend sync)
            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            storage.store_events_sync(events)

            # Now create cache with backend and sync
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=3, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)

            synced = cache.sync_pending()
            assert synced == 3
            assert cache.backend_reachable is True
            api_client.post_events.assert_called_once()

            # Events should now be marked as synced
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 0
        finally:
            _cleanup_storage(storage)

    def test_sync_pending_no_events(self):
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client()
            cache = LocalCache(storage=storage, api_client=api_client)

            synced = cache.sync_pending()
            assert synced == 0
            api_client.post_events.assert_not_called()
        finally:
            _cleanup_storage(storage)

    def test_sync_pending_no_backend(self):
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=None)
            synced = cache.sync_pending()
            assert synced == 0
        finally:
            _cleanup_storage(storage)

    def test_sync_pending_backend_failure(self):
        """Events should stay unsynced on backend failure."""
        storage = _tmp_storage()
        try:
            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            storage.store_events_sync(events)

            api_client = _mock_api_client(post_result=None)
            cache = LocalCache(storage=storage, api_client=api_client)

            synced = cache.sync_pending()
            assert synced == 0
            assert cache.backend_reachable is False

            # Events still unsynced
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 3
        finally:
            _cleanup_storage(storage)

    def test_sync_pending_with_duplicates(self):
        """Duplicates count as synced (they're already on backend)."""
        storage = _tmp_storage()
        try:
            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            storage.store_events_sync(events)

            api_client = _mock_api_client(
                post_result=BatchResult(accepted=1, duplicates=2)
            )
            cache = LocalCache(storage=storage, api_client=api_client)

            synced = cache.sync_pending()
            assert synced == 3  # 1 accepted + 2 duplicates
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# Health Check
# ---------------------------------------------------------------------------


class TestHealthCheck:
    def test_healthy_backend(self):
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(health=True)
            cache = LocalCache(storage=storage, api_client=api_client)

            assert cache.check_backend_health() is True
            assert cache.backend_reachable is True
        finally:
            _cleanup_storage(storage)

    def test_unhealthy_backend(self):
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(health=False)
            cache = LocalCache(storage=storage, api_client=api_client)

            assert cache.check_backend_health() is False
            assert cache.backend_reachable is False
        finally:
            _cleanup_storage(storage)

    def test_no_backend(self):
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=None)
            assert cache.check_backend_health() is False
        finally:
            _cleanup_storage(storage)

    def test_health_check_exception(self):
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client()
            api_client.health_check.side_effect = Exception("boom")
            cache = LocalCache(storage=storage, api_client=api_client)

            assert cache.check_backend_health() is False
            assert cache.backend_reachable is False
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


class TestProperties:
    def test_has_backend(self):
        storage = _tmp_storage()
        try:
            cache_with = LocalCache(storage=storage, api_client=_mock_api_client())
            assert cache_with.has_backend is True

            cache_without = LocalCache(storage=storage, api_client=None)
            assert cache_without.has_backend is False
        finally:
            _cleanup_storage(storage)

    def test_backend_reachable_initially_none(self):
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage, api_client=_mock_api_client())
            assert cache.backend_reachable is None
        finally:
            _cleanup_storage(storage)

    def test_get_pending_count(self):
        storage = _tmp_storage()
        try:
            cache = LocalCache(storage=storage)
            assert cache.get_pending_count() == 0

            storage.store_events_sync([UsageEvent(user_id="user_1")])
            assert cache.get_pending_count() >= 1
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# StoreResult
# ---------------------------------------------------------------------------


class TestStoreResult:
    def test_initial_state(self):
        r = StoreResult()
        assert r.stored_locally == 0
        assert r.synced_to_backend == 0
        assert r.duplicates == 0
        assert not r.all_synced

    def test_all_synced(self):
        r = StoreResult()
        r.stored_locally = 5
        r.synced_to_backend = 5
        assert r.all_synced

    def test_partial_sync(self):
        r = StoreResult()
        r.stored_locally = 5
        r.synced_to_backend = 3
        assert not r.all_synced

    def test_all_synced_with_duplicates(self):
        r = StoreResult()
        r.stored_locally = 5
        r.synced_to_backend = 2
        r.duplicates = 3
        assert r.all_synced

    def test_repr(self):
        r = StoreResult()
        r.stored_locally = 3
        assert "stored=3" in repr(r)


# ---------------------------------------------------------------------------
# End-to-End: Store → Fail → Retry → Sync
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_offline_then_sync(self):
        """Simulate: store offline, then sync when backend comes back."""
        storage = _tmp_storage()
        try:
            # Phase 1: Store events while backend is down
            api_client_down = _mock_api_client(post_result=None)
            cache = LocalCache(storage=storage, api_client=api_client_down)

            events = [UsageEvent(user_id="user_1", model="gpt-4o") for _ in range(5)]
            result = cache.store_and_sync(events)
            assert result.stored_locally == 5
            assert result.synced_to_backend == 0

            # Phase 2: Backend comes back — retry
            api_client_up = _mock_api_client(
                post_result=BatchResult(accepted=5, duplicates=0)
            )
            cache._api_client = api_client_up

            synced = cache.sync_pending()
            assert synced == 5

            # All events now synced
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 0
        finally:
            _cleanup_storage(storage)

    def test_idempotent_sync(self):
        """Syncing same events twice should be safe (backend dedup)."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=3, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)

            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            cache.store_and_sync(events)

            # sync_pending should find nothing (events already marked synced)
            synced = cache.sync_pending()
            assert synced == 0
        finally:
            _cleanup_storage(storage)

    def test_large_batch_full_failure_then_retry_succeeds(self):
        """100-event batch fails entirely on first attempt; all 100 are
        retried and succeed on the second attempt. None are lost.

        Guards the retry contract: when /events/batch returns None (5xx,
        timeout, or connect error) the events stay in SQLite marked
        unsynced, and the next sync cycle picks them up unchanged.
        """
        storage = _tmp_storage()
        try:
            # Phase 1: 100 events flushed, backend fails (full batch)
            failing_backend = _mock_api_client(post_result=None)
            cache = LocalCache(storage=storage, api_client=failing_backend)

            events = [
                UsageEvent(user_id="user_1", model="gpt-4o", total_tokens=100)
                for _ in range(100)
            ]
            result = cache.store_and_sync(events)
            assert result.stored_locally == 100
            assert result.synced_to_backend == 0
            assert not result.all_synced
            assert cache.backend_reachable is False
            failing_backend.post_events.assert_called_once()

            # All 100 are in SQLite, still unsynced
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 100
            original_ids = {e.id for e in unsynced}
            assert len(original_ids) == 100  # all unique

            # Phase 2: next sync cycle — backend recovered, accepts all 100
            recovered_backend = _mock_api_client(
                post_result=BatchResult(accepted=100, duplicates=0)
            )
            cache._api_client = recovered_backend

            synced = cache.sync_pending()
            assert synced == 100
            assert cache.backend_reachable is True

            # Verify the retried payload was the same 100 events — no loss, no split
            posted_events = recovered_backend.post_events.call_args[0][0]
            assert len(posted_events) == 100
            assert {e.id for e in posted_events} == original_ids

            # SQLite now shows zero unsynced
            assert len(storage.get_unsynced_events_sync()) == 0
        finally:
            _cleanup_storage(storage)

    def test_consecutive_failures_keep_events_queued(self):
        """Multiple consecutive flush cycles that all fail must not drop events."""
        storage = _tmp_storage()
        try:
            # Initial store, backend is down
            failing = _mock_api_client(post_result=None)
            cache = LocalCache(storage=storage, api_client=failing)

            events = [UsageEvent(user_id="user_1") for _ in range(50)]
            cache.store_and_sync(events)

            # Three more failed sync_pending cycles
            for _ in range(3):
                synced = cache.sync_pending()
                assert synced == 0

            # Events still intact — count unchanged
            assert len(storage.get_unsynced_events_sync()) == 50
        finally:
            _cleanup_storage(storage)


# ---------------------------------------------------------------------------
# Cleanup (retention policy)
# ---------------------------------------------------------------------------


class TestCleanupSynced:
    def test_cleanup_deletes_old_synced_events(self):
        """Old synced events should be deleted."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=3, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)

            # Store and sync 3 events
            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            cache.store_and_sync(events)

            # Manually backdate the created_at to 10 days ago
            import aiosqlite, asyncio

            async def backdate():
                db = await aiosqlite.connect(storage.db_path)
                await db.execute(
                    "UPDATE usage_events SET created_at = datetime('now', '-10 days')"
                )
                await db.commit()
                await db.close()

            asyncio.get_event_loop().run_until_complete(backdate())

            # Cleanup with 7-day retention
            deleted = cache.cleanup_synced(retention_days=7)
            assert deleted == 3

            # DB should be empty
            count = storage.store_events_sync([])  # Just to verify
            remaining = storage.get_unsynced_events_sync()
            assert len(remaining) == 0
        finally:
            _cleanup_storage(storage)

    def test_cleanup_preserves_unsynced_events(self):
        """Unsynced events should NEVER be deleted regardless of age."""
        storage = _tmp_storage()
        try:
            # No API client → events won't be synced
            cache = LocalCache(storage=storage, api_client=None)

            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            cache.store_and_sync(events)

            # Backdate to 30 days ago
            import aiosqlite, asyncio

            async def backdate():
                db = await aiosqlite.connect(storage.db_path)
                await db.execute(
                    "UPDATE usage_events SET created_at = datetime('now', '-30 days')"
                )
                await db.commit()
                await db.close()

            asyncio.get_event_loop().run_until_complete(backdate())

            # Cleanup — should delete nothing (all are synced=0)
            deleted = cache.cleanup_synced(retention_days=7)
            assert deleted == 0

            # All 3 events should still be there
            unsynced = storage.get_unsynced_events_sync()
            assert len(unsynced) == 3
        finally:
            _cleanup_storage(storage)

    def test_cleanup_preserves_recent_synced_events(self):
        """Synced events within retention period should be kept."""
        storage = _tmp_storage()
        try:
            api_client = _mock_api_client(
                post_result=BatchResult(accepted=3, duplicates=0)
            )
            cache = LocalCache(storage=storage, api_client=api_client)

            events = [UsageEvent(user_id="user_1") for _ in range(3)]
            cache.store_and_sync(events)

            # Don't backdate — events are fresh (just created)
            # Cleanup with 7-day retention — should delete nothing
            deleted = cache.cleanup_synced(retention_days=7)
            assert deleted == 0
        finally:
            _cleanup_storage(storage)

    def test_cleanup_no_storage_error(self):
        """Cleanup on closed storage should return 0, not crash."""
        storage = _tmp_storage()
        cache = LocalCache(storage=storage, api_client=None)
        _cleanup_storage(storage)

        # Should not raise
        deleted = cache.cleanup_synced(retention_days=7)
        assert deleted == 0
