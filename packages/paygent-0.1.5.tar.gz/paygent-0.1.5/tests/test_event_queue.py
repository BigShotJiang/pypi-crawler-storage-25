"""Tests for Paygent background event queue."""

from __future__ import annotations

import threading
import time

import pytest

from paygent.event_queue import EventQueue
from paygent.models import UsageEvent


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_event(user_id="user_1") -> UsageEvent:
    return UsageEvent(user_id=user_id, model="gpt-4o", input_tokens=100, output_tokens=50)


# ---------------------------------------------------------------------------
# Push (non-blocking)
# ---------------------------------------------------------------------------


class TestPush:
    def test_push_returns_true(self):
        flushed = []
        eq = EventQueue(flush_callback=lambda batch: flushed.extend(batch))
        assert eq.push(_make_event()) is True
        assert eq.pending_count == 1

    def test_push_when_full_drops_event(self):
        eq = EventQueue(
            flush_callback=lambda batch: None,
            max_queue_size=2,
        )
        assert eq.push(_make_event()) is True
        assert eq.push(_make_event()) is True
        assert eq.push(_make_event()) is False  # Dropped
        assert eq.stats["total_dropped"] == 1

    def test_push_multiple_events(self):
        eq = EventQueue(flush_callback=lambda batch: None)
        for _ in range(50):
            eq.push(_make_event())
        assert eq.pending_count == 50
        assert eq.stats["total_pushed"] == 50


# ---------------------------------------------------------------------------
# Manual flush
# ---------------------------------------------------------------------------


class TestFlushNow:
    def test_flush_now_drains_queue(self):
        flushed = []
        eq = EventQueue(flush_callback=lambda batch: flushed.extend(batch))

        for _ in range(5):
            eq.push(_make_event())

        count = eq.flush_now()
        assert count == 5
        assert len(flushed) == 5
        assert eq.pending_count == 0

    def test_flush_now_empty_queue(self):
        eq = EventQueue(flush_callback=lambda batch: None)
        count = eq.flush_now()
        assert count == 0

    def test_flush_now_respects_batch_size(self):
        """Events are flushed in batches of max_batch_size."""
        batches = []
        eq = EventQueue(
            flush_callback=lambda batch: batches.append(list(batch)),
            max_batch_size=3,
        )

        for _ in range(7):
            eq.push(_make_event())

        eq.flush_now()

        # Should have been flushed in batches of 3, 3, 1
        assert len(batches) == 3
        assert len(batches[0]) == 3
        assert len(batches[1]) == 3
        assert len(batches[2]) == 1

    def test_flush_callback_error_does_not_crash(self):
        """Flush callback error should be handled gracefully."""

        def bad_callback(batch):
            raise RuntimeError("DB down")

        eq = EventQueue(flush_callback=bad_callback)
        eq.push(_make_event())
        eq.push(_make_event())

        # Should not raise
        count = eq.flush_now()
        # Events are lost when callback fails (logged, not requeued)
        assert eq.pending_count == 0


# ---------------------------------------------------------------------------
# Background thread lifecycle
# ---------------------------------------------------------------------------


class TestBackgroundThread:
    def test_start_and_stop(self):
        eq = EventQueue(flush_callback=lambda batch: None, flush_interval=0.1)
        assert not eq.is_running

        eq.start()
        assert eq.is_running

        eq.stop(timeout=2.0)
        assert not eq.is_running

    def test_double_start_is_safe(self):
        eq = EventQueue(flush_callback=lambda batch: None, flush_interval=0.1)
        eq.start()
        eq.start()  # Should not create a second thread
        assert eq.is_running
        eq.stop()

    def test_stop_without_start_is_safe(self):
        eq = EventQueue(flush_callback=lambda batch: None)
        count = eq.stop()
        assert count == 0

    def test_background_flush_runs_automatically(self):
        """Background thread should flush events at the configured interval."""
        flushed = []
        eq = EventQueue(
            flush_callback=lambda batch: flushed.extend(batch),
            flush_interval=0.1,  # 100ms
        )
        eq.start()

        eq.push(_make_event())
        eq.push(_make_event())

        # Wait for the background flush to fire
        time.sleep(0.5)

        assert len(flushed) >= 2
        eq.stop()

    def test_stop_flushes_remaining(self):
        """Stop should flush remaining events before returning."""
        flushed = []
        eq = EventQueue(
            flush_callback=lambda batch: flushed.extend(batch),
            flush_interval=60.0,  # Very long interval — won't auto-flush
        )
        eq.start()

        for _ in range(10):
            eq.push(_make_event())

        # Stop should flush the remaining events
        count = eq.stop(timeout=2.0)
        assert count == 10
        assert len(flushed) == 10

    def test_daemon_thread(self):
        """Background thread should be a daemon (doesn't block process exit)."""
        eq = EventQueue(flush_callback=lambda batch: None, flush_interval=0.1)
        eq.start()
        assert eq._thread.daemon is True
        eq.stop()


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------


class TestStats:
    def test_initial_stats(self):
        eq = EventQueue(flush_callback=lambda batch: None)
        stats = eq.stats
        assert stats["total_pushed"] == 0
        assert stats["total_flushed"] == 0
        assert stats["total_dropped"] == 0
        assert stats["pending"] == 0
        assert stats["is_running"] is False

    def test_stats_after_push_and_flush(self):
        eq = EventQueue(flush_callback=lambda batch: None)
        eq.push(_make_event())
        eq.push(_make_event())
        eq.push(_make_event())
        eq.flush_now()

        stats = eq.stats
        assert stats["total_pushed"] == 3
        assert stats["total_flushed"] == 3
        assert stats["pending"] == 0


# ---------------------------------------------------------------------------
# Thread safety
# ---------------------------------------------------------------------------


class TestThreadSafety:
    def test_concurrent_pushes(self):
        """Multiple threads pushing concurrently should not lose events."""
        eq = EventQueue(flush_callback=lambda batch: None, max_queue_size=10_000)
        n_threads = 10
        n_events_per_thread = 100

        def pusher():
            for _ in range(n_events_per_thread):
                eq.push(_make_event())

        threads = [threading.Thread(target=pusher) for _ in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        expected = n_threads * n_events_per_thread
        assert eq.stats["total_pushed"] == expected
        assert eq.pending_count == expected

    def test_concurrent_push_and_flush(self):
        """Push and flush running concurrently should not crash."""
        flushed_count = {"n": 0}
        lock = threading.Lock()

        def flush_cb(batch):
            with lock:
                flushed_count["n"] += len(batch)

        eq = EventQueue(
            flush_callback=flush_cb,
            flush_interval=0.05,
            max_queue_size=10_000,
        )
        eq.start()

        # Push events while background flush is running
        for _ in range(200):
            eq.push(_make_event())
            time.sleep(0.001)

        eq.stop(timeout=5.0)

        # All pushed events should have been flushed
        total = flushed_count["n"]
        assert total == 200


# ---------------------------------------------------------------------------
# Periodic sync_pending
# ---------------------------------------------------------------------------


class TestSyncPending:
    def test_sync_pending_callback_fires_periodically(self):
        """sync_pending_callback should be called after sync_pending_interval."""
        sync_calls = []

        def sync_cb():
            sync_calls.append(time.monotonic())
            return 3

        eq = EventQueue(
            flush_callback=lambda batch: None,
            flush_interval=0.1,
            sync_pending_callback=sync_cb,
            sync_pending_interval=0.2,  # fire every 200ms
        )
        eq.start()

        # Wait enough for at least 2 sync_pending calls
        time.sleep(0.8)
        eq.stop(timeout=2.0)

        assert len(sync_calls) >= 2

    def test_sync_pending_not_called_without_callback(self):
        """No sync_pending_callback → no errors, no calls."""
        eq = EventQueue(
            flush_callback=lambda batch: None,
            flush_interval=0.1,
            sync_pending_callback=None,
        )
        eq.start()
        time.sleep(0.3)
        eq.stop(timeout=2.0)
        # Just verifying no crash

    def test_sync_pending_callback_error_does_not_crash(self):
        """sync_pending_callback raising should be handled gracefully."""

        def bad_sync():
            raise RuntimeError("Backend unreachable")

        eq = EventQueue(
            flush_callback=lambda batch: None,
            flush_interval=0.1,
            sync_pending_callback=bad_sync,
            sync_pending_interval=0.1,
        )
        eq.start()
        time.sleep(0.4)
        eq.stop(timeout=2.0)
        # Should not crash — errors are swallowed

    def test_sync_pending_respects_interval(self):
        """sync_pending should not fire more frequently than sync_pending_interval."""
        sync_calls = []

        def sync_cb():
            sync_calls.append(time.monotonic())
            return 0

        eq = EventQueue(
            flush_callback=lambda batch: None,
            flush_interval=0.05,  # flush every 50ms
            sync_pending_callback=sync_cb,
            sync_pending_interval=0.5,  # sync_pending every 500ms
        )
        eq.start()
        time.sleep(1.2)
        eq.stop(timeout=2.0)

        # With 1.2s and 500ms interval, should have ~2-3 calls (not 20+)
        assert len(sync_calls) <= 5
        assert len(sync_calls) >= 1
