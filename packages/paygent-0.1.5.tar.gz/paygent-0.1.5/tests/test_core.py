"""Tests for Paygent core — the main orchestrator class."""

from __future__ import annotations

import contextlib
import os
import tempfile
import time
import warnings

import pytest

from paygent.context import paygent_context
from paygent.core import Paygent
from paygent.guardrails import (
    PaygentAuthInvalid,
    PaygentBackendUnreachable,
    PaygentLimitExceeded,
)


@contextlib.contextmanager
def _no_warnings():
    """Capture warnings without failing if any fire (lets caller inspect them)."""
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        yield caught
from paygent.models import (
    CurrentUsage,
    GuardResult,
    ModelCostRate,
    ModelLimitConfig,
    ModelUsage,
    PlanConfig,
    UsageEvent,
    UserSession,
)
from paygent.providers import ProviderConfig, ProviderRegistry, TokenInfo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tmp_db_path() -> str:
    """Create a temporary database path."""
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return tmp.name


def _make_pg(**kwargs) -> Paygent:
    """Create a Paygent instance with sensible test defaults."""
    defaults = dict(
        db_path=_tmp_db_path(),
        auto_instrument=False,  # Don't try to patch real providers in tests
        flush_interval=60.0,    # Long interval — we flush manually in tests
    )
    defaults.update(kwargs)
    return Paygent.init(**defaults)


def _cleanup_pg(pg: Paygent) -> None:
    """Clean up a Paygent instance and its database."""
    db_path = pg.storage.db_path
    pg.shutdown()
    try:
        os.unlink(db_path)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


class TestInit:
    def test_basic_init(self):
        """Paygent.init() should create an initialized instance."""
        pg = _make_pg()
        try:
            assert pg.is_initialized
            assert pg.is_local_mode  # No API key
            assert pg.api_key is None
            assert pg.session_count == 0
        finally:
            _cleanup_pg(pg)

    def test_init_with_api_key(self):
        """Passing an API key should enable connected mode."""
        pg = _make_pg(api_key="pg_live_test_key")
        try:
            assert not pg.is_local_mode
            assert pg.api_key == "pg_live_test_key"
        finally:
            _cleanup_pg(pg)

    def test_init_creates_storage(self):
        """Init should create the SQLite database file."""
        db_path = _tmp_db_path()
        pg = _make_pg(db_path=db_path)
        try:
            assert os.path.exists(db_path)
        finally:
            _cleanup_pg(pg)

    def test_singleton_pattern(self):
        """Paygent.init() should set the singleton."""
        pg = _make_pg()
        try:
            assert Paygent.get_instance() is pg
        finally:
            _cleanup_pg(pg)

    def test_singleton_cleared_on_shutdown(self):
        """Shutdown should clear the singleton."""
        pg = _make_pg()
        _cleanup_pg(pg)
        assert Paygent.get_instance() is None

    def test_double_init_shuts_down_previous_instance(self):
        """Calling init() again should cleanly shut down the previous instance.

        This guards against resource leaks (event queue threads, monkey-patches,
        SQLite connections, httpx clients) when init() is called twice — a
        common pattern in notebooks, hot-reload servers, and test fixtures.
        """
        pg1 = _make_pg()
        assert pg1.is_initialized
        assert pg1.queue_stats["is_running"]

        pg2 = _make_pg()
        try:
            # New instance replaces the singleton
            assert pg1 is not pg2
            assert Paygent.get_instance() is pg2
            # Old instance was shut down: event queue stopped, no longer initialized
            assert not pg1.is_initialized
            assert not pg1.queue_stats["is_running"]
            # New instance is live
            assert pg2.is_initialized
            assert pg2.queue_stats["is_running"]
        finally:
            _cleanup_pg(pg2)

    def test_init_starts_event_queue(self):
        """Init should start the background event queue."""
        pg = _make_pg(flush_interval=0.1)
        try:
            assert pg.queue_stats["is_running"]
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Session Management
# ---------------------------------------------------------------------------


class TestSessionManagement:
    def test_start_session(self):
        """start_session should create and cache a UserSession."""
        pg = _make_pg()
        try:
            session = pg.start_session("user_1", plan="pro")
            assert session.user_id == "user_1"
            assert session.plan == "pro"
            assert pg.session_count == 1
        finally:
            _cleanup_pg(pg)

    def test_start_session_with_config(self):
        """start_session with plan_config should apply it."""
        pg = _make_pg()
        config = PlanConfig(max_spend_per_period=49.00)
        try:
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            assert session.plan_config.max_spend_per_period == 49.00
        finally:
            _cleanup_pg(pg)

    def test_start_session_default_config(self):
        """start_session without config should use permissive defaults."""
        pg = _make_pg()
        try:
            session = pg.start_session("user_1")
            assert session.plan_config.max_spend_per_period == float("inf")
            assert session.plan_config.max_spend_per_session == float("inf")
        finally:
            _cleanup_pg(pg)

    def test_start_session_preserves_usage(self):
        """Calling start_session again should update config but preserve usage."""
        pg = _make_pg()
        try:
            session = pg.start_session("user_1", plan="free")
            session.current_usage.period_cost = 3.50

            # "Upgrade" to pro — usage should persist
            session2 = pg.start_session(
                "user_1",
                plan="pro",
                plan_config=PlanConfig(max_spend_per_period=49.00),
            )
            assert session2 is session  # Same object
            assert session2.plan == "pro"
            assert session2.plan_config.max_spend_per_period == 49.00
            assert session2.current_usage.period_cost == 3.50
        finally:
            _cleanup_pg(pg)

    def test_get_session(self):
        """get_session should return cached session or None."""
        pg = _make_pg()
        try:
            assert pg.get_session("user_1") is None
            pg.start_session("user_1")
            assert pg.get_session("user_1") is not None
            assert pg.get_session("user_1").user_id == "user_1"
        finally:
            _cleanup_pg(pg)

    def test_remove_session(self):
        """remove_session should remove from cache."""
        pg = _make_pg()
        try:
            pg.start_session("user_1")
            assert pg.session_count == 1
            pg.remove_session("user_1")
            assert pg.session_count == 0
            assert pg.get_session("user_1") is None
        finally:
            _cleanup_pg(pg)

    def test_remove_nonexistent_session(self):
        """remove_session for unknown user should not error."""
        pg = _make_pg()
        try:
            pg.remove_session("nonexistent")  # Should not raise
        finally:
            _cleanup_pg(pg)

    def test_auto_create_session_on_lookup(self):
        """Internal session lookup should auto-create permissive sessions."""
        pg = _make_pg()
        try:
            # Simulate what the patcher does
            session = pg._session_lookup("auto_user")
            assert session is not None
            assert session.user_id == "auto_user"
            assert session.plan == "default"
            assert session.plan_config.max_spend_per_period == float("inf")
            assert pg.session_count == 1
        finally:
            _cleanup_pg(pg)

    def test_multiple_sessions(self):
        """Should handle multiple concurrent user sessions."""
        pg = _make_pg()
        try:
            for i in range(10):
                pg.start_session(f"user_{i}", plan="pro")
            assert pg.session_count == 10
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Usage Queries
# ---------------------------------------------------------------------------


class TestUsageQueries:
    def test_get_usage_auto_loads_for_unknown_user(self):
        """Unknown user triggers the fallback chain and returns an empty snapshot."""
        pg = _make_pg()
        try:
            usage = pg.get_usage("unknown")
            assert usage is not None
            assert usage.period_cost == 0.0
            assert usage.period_tokens_total == 0
            # Auto-load should have cached a default UserState
            assert "unknown" in pg._sessions
        finally:
            _cleanup_pg(pg)

    def test_get_usage_returns_current_usage(self):
        pg = _make_pg()
        try:
            session = pg.start_session("user_1")
            session.current_usage.period_cost = 12.50
            session.current_usage.period_tokens_total = 5000

            usage = pg.get_usage("user_1")
            assert usage is not None
            assert usage.period_cost == 12.50
            assert usage.period_tokens_total == 5000
        finally:
            _cleanup_pg(pg)

    def test_get_model_usage_empty(self):
        pg = _make_pg()
        try:
            assert pg.get_model_usage("unknown") == []
        finally:
            _cleanup_pg(pg)

    def test_get_model_usage_with_data(self):
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={
                    "gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000),
                    "claude-sonnet-4-20250514": ModelLimitConfig(max_tokens_per_period=30_000),
                },
            )
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 25000
            session.current_usage.period_cost_by_model["gpt-4o"] = 5.00

            model_usage = pg.get_model_usage("user_1")
            assert len(model_usage) == 2  # gpt-4o (used) + claude (configured)

            gpt4o = next(m for m in model_usage if m.model == "gpt-4o")
            assert gpt4o.tokens_used == 25000
            assert gpt4o.tokens_limit == 50_000
            assert gpt4o.cost == 5.00

            claude = next(m for m in model_usage if m.model == "claude-sonnet-4-20250514")
            assert claude.tokens_used == 0
            assert claude.tokens_limit == 30_000
        finally:
            _cleanup_pg(pg)

    def test_check_guard_no_session(self):
        """check_guard with no session should return ok (fail-open)."""
        pg = _make_pg()
        try:
            result = pg.check_guard("unknown", model="gpt-4o")
            assert result.status == "ok"
        finally:
            _cleanup_pg(pg)

    def test_check_guard_with_session(self):
        """check_guard should check limits against cached session."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 9.50  # 95% — soft gate at 80%

            result = pg.check_guard("user_1")
            assert result.status == "soft_gate"
            assert result.gate_reason == "total_spend"
        finally:
            _cleanup_pg(pg)

    def test_check_guard_hard_gate(self):
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 10.50  # Over limit

            result = pg.check_guard("user_1")
            assert result.status == "hard_gate"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Soft Gate Callbacks
# ---------------------------------------------------------------------------


class TestSoftGateCallbacks:
    def test_on_soft_gate_registers_callback(self):
        pg = _make_pg()
        try:
            results = []
            pg.on_soft_gate(lambda r: results.append(r))

            # Trigger via internal handler
            pg._soft_gate_handler(GuardResult(status="soft_gate", message="test"))
            assert len(results) == 1
            assert results[0].status == "soft_gate"
        finally:
            _cleanup_pg(pg)

    def test_multiple_soft_gate_callbacks(self):
        pg = _make_pg()
        try:
            results_a = []
            results_b = []
            pg.on_soft_gate(lambda r: results_a.append(r))
            pg.on_soft_gate(lambda r: results_b.append(r))

            pg._soft_gate_handler(GuardResult(status="soft_gate", message="test"))
            assert len(results_a) == 1
            assert len(results_b) == 1
        finally:
            _cleanup_pg(pg)

    def test_soft_gate_callback_error_does_not_propagate(self):
        pg = _make_pg()
        try:
            def bad_callback(r):
                raise RuntimeError("callback error")

            pg.on_soft_gate(bad_callback)
            # Should not raise
            pg._soft_gate_handler(GuardResult(status="soft_gate", message="test"))
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Event Queue Integration
# ---------------------------------------------------------------------------


class TestEventQueue:
    def test_event_sink_pushes_to_queue(self):
        pg = _make_pg()
        try:
            event = UsageEvent(user_id="user_1")
            pg._event_sink(event)
            assert pg.pending_events == 1
        finally:
            _cleanup_pg(pg)

    def test_manual_flush(self):
        pg = _make_pg()
        try:
            for _ in range(5):
                pg._event_sink(UsageEvent(user_id="user_1"))

            assert pg.pending_events == 5
            flushed = pg.flush()
            assert flushed == 5
            assert pg.pending_events == 0
        finally:
            _cleanup_pg(pg)

    def test_flush_stores_to_sqlite(self):
        pg = _make_pg()
        try:
            event = UsageEvent(user_id="user_1", model="gpt-4o")
            pg._event_sink(event)
            pg.flush()

            # Verify stored in SQLite via sync wrapper
            events = pg.storage.get_unsynced_events_sync()
            assert len(events) == 1
            assert events[0].user_id == "user_1"
        finally:
            _cleanup_pg(pg)

    def test_queue_stats(self):
        pg = _make_pg()
        try:
            stats = pg.queue_stats
            assert "total_pushed" in stats
            assert "total_flushed" in stats
            assert "total_dropped" in stats
            assert "pending" in stats
            assert "is_running" in stats
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Instrumentation Control
# ---------------------------------------------------------------------------


class TestInstrumentation:
    def test_auto_instrument_disabled(self):
        """With auto_instrument=False, no providers should be patched."""
        pg = _make_pg(auto_instrument=False)
        try:
            # No real providers installed in test env, so nothing to check
            # but it shouldn't crash
            assert pg.is_initialized
        finally:
            _cleanup_pg(pg)

    def test_manual_instrument(self):
        """instrument() should not crash even without providers installed."""
        pg = _make_pg(auto_instrument=False)
        try:
            result = pg.instrument()
            # Returns list (may be empty if no providers installed)
            assert isinstance(result, list)
        finally:
            _cleanup_pg(pg)

    def test_uninstrument(self):
        pg = _make_pg(auto_instrument=False)
        try:
            count = pg.uninstrument()
            assert count == 0  # Nothing was patched
            assert not pg.is_instrumented
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------


class TestShutdown:
    def test_shutdown_clears_state(self):
        pg = _make_pg()
        db_path = pg.storage.db_path
        try:
            pg.start_session("user_1")
            assert pg.session_count == 1

            pg.shutdown()
            assert not pg.is_initialized
            assert pg.session_count == 0
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_shutdown_flushes_events(self):
        db_path = _tmp_db_path()
        pg = _make_pg(db_path=db_path)
        try:
            for _ in range(5):
                pg._event_sink(UsageEvent(user_id="user_1"))

            pg.shutdown()

            # Verify events were persisted before shutdown
            from paygent.storage.sqlite import SQLiteStorage
            storage = SQLiteStorage(db_path=db_path)
            storage.initialize_sync()
            events = storage.get_unsynced_events_sync()
            storage.close_sync()
            assert len(events) == 5
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_double_shutdown_is_safe(self):
        pg = _make_pg()
        db_path = pg.storage.db_path
        try:
            pg.shutdown()
            pg.shutdown()  # Should not raise
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_shutdown_stops_event_queue(self):
        pg = _make_pg(flush_interval=0.1)
        db_path = pg.storage.db_path
        try:
            assert pg.queue_stats["is_running"]
            pg.shutdown()
            assert not pg.queue_stats["is_running"]
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Decorator (pg.track)
# ---------------------------------------------------------------------------


class TestTrackDecorator:
    def test_track_returns_decorator(self):
        pg = _make_pg()
        try:
            @pg.track(user_id="user_1")
            def my_func():
                return 42

            assert my_func() == 42
        finally:
            _cleanup_pg(pg)

    def test_track_with_user_id_param(self):
        pg = _make_pg()
        try:
            @pg.track(user_id_param="uid")
            def my_func(uid: str, query: str):
                from paygent.context import get_current_context
                ctx = get_current_context()
                return ctx.user_id if ctx else None

            result = my_func("user_abc", "test query")
            assert result == "user_abc"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# End-to-End: Simulated LLM Call Flow
# ---------------------------------------------------------------------------


class TestEndToEnd:
    """Simulate the full flow without real LLM providers."""

    def test_full_flow_local_mode(self):
        """Test the complete flow: init → session → event → flush → storage."""
        pg = _make_pg()
        try:
            # 1. Start session with config
            config = PlanConfig(
                max_spend_per_period=49.00,
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            # 2. Simulate metered event (as patcher would create)
            event = UsageEvent(
                user_id="user_1",
                model="gpt-4o",
                input_tokens=1000,
                output_tokens=500,
                total_tokens=1500,
                cost_tokens=0.0075,
                cost_total=0.0075,
            )

            # 3. Update cache (as patcher would)
            from paygent.metering import update_cache
            session = pg.get_session("user_1")
            update_cache(session, event)

            # 4. Push event (as patcher would)
            pg._event_sink(event)

            # 5. Verify cache updated
            usage = pg.get_usage("user_1")
            assert usage.period_cost == pytest.approx(0.0075)
            assert usage.period_tokens_by_model["gpt-4o"] == 1500

            # 6. Flush to storage
            pg.flush()

            # 7. Verify guard check still ok
            result = pg.check_guard("user_1", model="gpt-4o")
            assert result.status == "ok"
        finally:
            _cleanup_pg(pg)

    def test_full_flow_with_guard_trigger(self):
        """Test that guard triggers after usage accumulates."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=10.00,
                soft_gate_at=0.80,
                hard_gate_at=1.00,
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            # Simulate usage up to soft gate
            session = pg.get_session("user_1")
            session.current_usage.period_cost = 8.50  # 85% → soft gate

            soft_results = []
            pg.on_soft_gate(lambda r: soft_results.append(r))

            result = pg.check_guard("user_1")
            assert result.status == "soft_gate"

            # Push past hard gate
            session.current_usage.period_cost = 10.50
            result = pg.check_guard("user_1")
            assert result.status == "hard_gate"
        finally:
            _cleanup_pg(pg)

    def test_full_flow_multiple_users(self):
        """Multiple users with different plans."""
        pg = _make_pg()
        try:
            pro_config = PlanConfig(max_spend_per_period=49.00)
            free_config = PlanConfig(max_spend_per_period=5.00)

            pg.start_session("pro_user", plan="pro", plan_config=pro_config)
            pg.start_session("free_user", plan="free", plan_config=free_config)

            # Pro user at 45/49 → soft gate
            pg.get_session("pro_user").current_usage.period_cost = 45.00
            result = pg.check_guard("pro_user")
            assert result.status == "soft_gate"

            # Free user at 2/5 → ok
            pg.get_session("free_user").current_usage.period_cost = 2.00
            result = pg.check_guard("free_user")
            assert result.status == "ok"
        finally:
            _cleanup_pg(pg)

    def test_event_persistence_survives_shutdown(self):
        """Events should be persisted to SQLite and survive restarts."""
        db_path = _tmp_db_path()
        try:
            # First instance: push events and shut down
            pg1 = _make_pg(db_path=db_path)
            for i in range(3):
                pg1._event_sink(UsageEvent(user_id="user_1", model="gpt-4o"))
            pg1.shutdown()

            # Second instance: verify events are there
            from paygent.storage.sqlite import SQLiteStorage
            storage = SQLiteStorage(db_path=db_path)
            storage.initialize_sync()
            events = storage.get_unsynced_events_sync()
            storage.close_sync()
            assert len(events) == 3
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Fail-Open Behavior
# ---------------------------------------------------------------------------


class TestFailOpen:
    def test_session_lookup_auto_creates(self):
        """Internal lookup for unknown user should auto-create (not return None)."""
        pg = _make_pg()
        try:
            session = pg._session_lookup("never_seen_user")
            assert session is not None
            assert session.plan_config.max_spend_per_period == float("inf")
        finally:
            _cleanup_pg(pg)

    def test_event_sink_never_raises(self):
        """Event sink should never propagate exceptions."""
        pg = _make_pg()
        try:
            # Push after event queue is stopped (edge case)
            pg._event_queue.stop()
            # Should not raise even though queue is stopped
            pg._event_sink(UsageEvent(user_id="user_1"))
        finally:
            _cleanup_pg(pg)

    def test_soft_gate_handler_never_raises(self):
        """Soft gate handler should swallow callback errors."""
        pg = _make_pg()
        try:
            pg.on_soft_gate(lambda r: 1 / 0)  # Will raise ZeroDivisionError
            # Should not raise
            pg._soft_gate_handler(GuardResult(status="soft_gate"))
        finally:
            _cleanup_pg(pg)

    def test_flush_with_closed_storage(self):
        """Flush should not crash if storage is closed."""
        pg = _make_pg()
        try:
            pg._event_sink(UsageEvent(user_id="user_1"))
            pg.storage.close_sync()
            # Flush should handle the error gracefully
            pg.flush()  # Should not raise
        finally:
            db_path = pg.storage.db_path
            pg.shutdown()
            try:
                os.unlink(db_path)
            except OSError:
                pass


# ---------------------------------------------------------------------------
# Context Integration
# ---------------------------------------------------------------------------


class TestContextIntegration:
    def test_paygent_context_with_session(self):
        """Context manager should work alongside session management."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=49.00)
            pg.start_session("user_1", plan="pro", plan_config=config)

            with paygent_context(user_id="user_1"):
                from paygent.context import get_current_context
                ctx = get_current_context()
                assert ctx.user_id == "user_1"

                # Session should be accessible
                session = pg.get_session("user_1")
                assert session.plan == "pro"
        finally:
            _cleanup_pg(pg)

    def test_context_without_session_auto_creates(self):
        """Using context for unknown user triggers auto-create on lookup."""
        pg = _make_pg()
        try:
            with paygent_context(user_id="new_user"):
                session = pg._session_lookup("new_user")
                assert session is not None
                assert session.plan == "default"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# is_within_limit() convenience
# ---------------------------------------------------------------------------


class TestIsWithinLimit:
    def test_ok_status_returns_true(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=10.0,
            ))
            assert pg.is_within_limit("u1") is True
        finally:
            _cleanup_pg(pg)

    def test_soft_gate_counts_as_within_limit(self):
        """Soft gate is a warning, not a block — is_within_limit is True."""
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=10.0,
                soft_gate_at=0.80,
                hard_gate_at=1.00,
            ))
            session.current_usage.period_cost = 8.5  # 85% → soft gate
            assert pg.is_within_limit("u1") is True
        finally:
            _cleanup_pg(pg)

    def test_hard_gate_returns_false(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=10.0,
            ))
            session.current_usage.period_cost = 10.5  # 105% → hard gate
            assert pg.is_within_limit("u1") is False
        finally:
            _cleanup_pg(pg)

    def test_model_limit_hard_gate_returns_false(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},
            ))
            session.current_usage.period_tokens_by_model["gpt-4o"] = 1100
            assert pg.is_within_limit("u1", model="gpt-4o") is False
            # A model with no shared prefix and no configured limit is fine.
            # (Using "claude-3-opus" to avoid normalize_model_name's prefix
            # match collapsing "gpt-4o-mini" back onto "gpt-4o".)
            assert pg.is_within_limit("u1", model="claude-3-opus") is True
        finally:
            _cleanup_pg(pg)

    def test_unknown_user_auto_loads_and_returns_true(self):
        """Unknown user auto-loads with permissive defaults → within limit."""
        pg = _make_pg()
        try:
            assert pg.is_within_limit("never_seen_before") is True
            # Auto-load created the session
            assert "never_seen_before" in pg._sessions
        finally:
            _cleanup_pg(pg)

    def test_is_within_limit_is_fail_open(self, monkeypatch):
        """Exceptions inside the check must return True (don't block dev)."""
        pg = _make_pg()
        try:
            def boom(*a, **kw):
                raise RuntimeError("boom")
            monkeypatch.setattr(pg, "_get_user_state", boom)
            assert pg.is_within_limit("u1") is True
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# get_remaining_budget() convenience
# ---------------------------------------------------------------------------


class TestGetRemainingBudget:
    def test_all_limits_unbounded(self):
        """No configured limits → everything unbounded."""
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=PlanConfig())
            budget = pg.get_remaining_budget("u1")
            assert budget.period_spend_remaining == float("inf")
            assert budget.session_spend_remaining == float("inf")
            assert budget.model_tokens_remaining == {}
            assert budget.most_constrained == "unbounded"
        finally:
            _cleanup_pg(pg)

    def test_period_spend_remaining(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=49.00,
            ))
            session.current_usage.period_cost = 23.47
            budget = pg.get_remaining_budget("u1")
            assert budget.period_spend_remaining == pytest.approx(49.00 - 23.47)
            assert budget.most_constrained == "period_spend"
        finally:
            _cleanup_pg(pg)

    def test_session_spend_remaining(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=100.0,
                max_spend_per_session=5.0,
            ))
            # Session has spent more of its smaller cap than period has of its larger cap
            session.current_usage.period_cost = 10.0   # 10/100 = 10%
            session.current_usage.session_cost = 4.5   # 4.5/5 = 90%
            budget = pg.get_remaining_budget("u1")
            assert budget.period_spend_remaining == pytest.approx(90.0)
            assert budget.session_spend_remaining == pytest.approx(0.5)
            assert budget.most_constrained == "session_spend"
        finally:
            _cleanup_pg(pg)

    def test_model_tokens_remaining(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                model_limits={
                    "gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000),
                    "claude": ModelLimitConfig(max_tokens_per_period=None),  # unlimited
                },
            ))
            session.current_usage.period_tokens_by_model["gpt-4o"] = 31_200
            budget = pg.get_remaining_budget("u1")
            assert budget.model_tokens_remaining["gpt-4o"] == 50_000 - 31_200
            # Unlimited model is reported as None
            assert budget.model_tokens_remaining["claude"] is None
            # gpt-4o at 62% usage beats everything else → most constrained
            assert budget.most_constrained == "model_tokens"
        finally:
            _cleanup_pg(pg)

    def test_remaining_clamped_at_zero_when_overrun(self):
        """If the user is already over the limit, remaining is 0 (not negative)."""
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=10.0,
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},
            ))
            session.current_usage.period_cost = 15.0
            session.current_usage.period_tokens_by_model["gpt-4o"] = 2500
            budget = pg.get_remaining_budget("u1")
            assert budget.period_spend_remaining == 0.0
            assert budget.model_tokens_remaining["gpt-4o"] == 0
        finally:
            _cleanup_pg(pg)

    def test_most_constrained_picks_tightest_dimension(self):
        pg = _make_pg()
        try:
            session = pg.start_session("u1", plan="pro", plan_config=PlanConfig(
                max_spend_per_period=100.0,   # 20% used
                max_spend_per_session=10.0,   # 50% used
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},  # 90% used
            ))
            session.current_usage.period_cost = 20.0
            session.current_usage.session_cost = 5.0
            session.current_usage.period_tokens_by_model["gpt-4o"] = 900
            budget = pg.get_remaining_budget("u1")
            assert budget.most_constrained == "model_tokens"
        finally:
            _cleanup_pg(pg)

    def test_unknown_user_auto_loads(self):
        pg = _make_pg()
        try:
            budget = pg.get_remaining_budget("never_seen")
            # Permissive defaults → no limits
            assert budget.most_constrained == "unbounded"
            assert "never_seen" in pg._sessions
        finally:
            _cleanup_pg(pg)

    def test_fail_open_on_error(self, monkeypatch):
        pg = _make_pg()
        try:
            def boom(*a, **kw):
                raise RuntimeError("boom")
            monkeypatch.setattr(pg, "_get_user_state", boom)
            budget = pg.get_remaining_budget("u1")
            # Default BudgetRemaining — all unbounded
            assert budget.period_spend_remaining == float("inf")
            assert budget.most_constrained == "unbounded"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Public API surface (exports)
# ---------------------------------------------------------------------------


class TestPublicExports:
    """Guard the shape of what ``from paygent import *`` gives the developer.

    Public API is a contract.  Adding here is cheap; removing is breaking.
    This test fails loudly if either direction changes unintentionally.
    """

    def test_canonical_public_names_are_importable(self):
        import paygent
        # Every name we publicly commit to supporting
        expected = {
            "Paygent",
            "paygent_context",
            "paygent_track",
            "PaygentLimitExceeded",
            "PaygentBackendUnreachable",
            "PaygentAuthInvalid",
            "PlanConfig",
            "ModelCostRate",
            "ModelLimitConfig",
            "GuardResult",
            "UsageEvent",
            "CurrentUsage",
            "ModelUsage",
            "UserState",
            "BudgetRemaining",
            "MaxTokensAdvice",
            "BillingPeriod",
            "UserSession",  # deprecated but still exported this release
        }
        for name in expected:
            assert hasattr(paygent, name), f"Missing public export: {name}"

    def test_all_matches_expected_set(self):
        import paygent
        assert set(paygent.__all__) == {
            "Paygent",
            "paygent_context",
            "paygent_track",
            "PaygentLimitExceeded",
            "PaygentBackendUnreachable",
            "PaygentAuthInvalid",
            "PlanConfig",
            "ModelCostRate",
            "ModelLimitConfig",
            "GuardResult",
            "UsageEvent",
            "CurrentUsage",
            "ModelUsage",
            "UserState",
            "BudgetRemaining",
            "MaxTokensAdvice",
            "BillingPeriod",
            "UserSession",
        }

    def test_internals_not_reexported_at_top_level(self):
        """Internal helpers must not appear on the ``paygent`` top-level namespace.

        Devs should reach into ``paygent.guardrails``, ``paygent.metering``,
        etc. if they need these — with the understanding that those are
        unstable implementation details.
        """
        import paygent
        internal_names = [
            "SoftGateCallbackRegistry",
            "HardGateCallbackRegistry",
            "UsageCallbackRegistry",
            "SessionStartCallbackRegistry",
            "calculate_cost",
            "create_usage_event",
            "update_cache",
            "check_guard",
        ]
        for name in internal_names:
            assert not hasattr(paygent, name), (
                f"{name!r} is leaking at the top level of `paygent`. "
                "Keep it in its submodule only."
            )


# ---------------------------------------------------------------------------
# get_max_tokens() recommendation helper
# ---------------------------------------------------------------------------


class TestGetMaxTokens:
    """pg.get_max_tokens() recommends a safe max_tokens for the next call.

    The helper reads current usage + plan config and returns the largest
    output-token count that won't overshoot any hard gate.  Pure read —
    no guard callbacks, no metering.
    """

    def test_no_limits_returns_hard_cap(self):
        """Plan with no finite limits → hard_cap as the ceiling."""
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=PlanConfig())
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            assert advice.max_tokens == 4096  # default hard_cap
            assert advice.binding_limit == "unbounded"
        finally:
            _cleanup_pg(pg)

    def test_respects_custom_hard_cap(self):
        pg = _make_pg()
        try:
            pg.start_session("u1", plan="pro", plan_config=PlanConfig())
            advice = pg.get_max_tokens("u1", model="gpt-4o", hard_cap=100)
            assert advice.max_tokens == 100
        finally:
            _cleanup_pg(pg)

    def test_period_spend_is_binding(self):
        """When period spend is tightest, advice reports period_spend."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=1.0,  # $1
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 0.80  # $0.20 headroom
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # Output rate $0.01/1K → $0.20 buys 20k output tokens.
            # But hard_cap clamps to 4096.
            assert advice.max_tokens == 4096
            # Bump headroom down to force period_spend to be binding
            session.current_usage.period_cost = 0.98  # $0.02 headroom
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # $0.02 → 2000 output tokens → binding
            assert advice.max_tokens == 2000
            assert advice.binding_limit == "period_spend"
        finally:
            _cleanup_pg(pg)

    def test_session_spend_is_binding(self):
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=100.0,  # huge
                max_spend_per_session=0.10,  # small
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.session_cost = 0.09  # $0.01 headroom
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # $0.01 / $0.01-per-1K = 1000 output tokens
            assert advice.max_tokens == 1000
            assert advice.binding_limit == "session_spend"
        finally:
            _cleanup_pg(pg)

    def test_model_tokens_is_binding(self):
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 600
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # 400 tokens left in the cap → binding
            assert advice.max_tokens == 400
            assert advice.binding_limit == "model_tokens"
        finally:
            _cleanup_pg(pg)

    def test_input_tokens_eat_into_model_tokens(self):
        """estimated_input_tokens is subtracted from per-model headroom."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 600

            advice = pg.get_max_tokens(
                "u1", model="gpt-4o", estimated_input_tokens=200,
            )
            # 400 total tokens left - 200 input = 200 output tokens
            assert advice.max_tokens == 200
        finally:
            _cleanup_pg(pg)

    def test_input_tokens_eat_into_spend(self):
        """estimated_input_tokens cost is subtracted from dollar headroom."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=0.05,
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            # No prior spend → $0.05 full headroom
            # 2000 input tokens cost: (2000/1000)*0.0025 = $0.005
            # Remaining: $0.045
            # $0.045 / ($0.01/1K) = 4500 output tokens → clamped to hard_cap 4096
            advice = pg.get_max_tokens(
                "u1", model="gpt-4o", estimated_input_tokens=2000,
            )
            assert advice.max_tokens == 4096

            # Tighter: 4000 input tokens = $0.01 cost, leaves $0.04
            # $0.04 / ($0.01/1K) = 4000 output tokens
            # (Float arithmetic: 0.05 - 0.01 = 0.03999... → int() truncates
            # to 3999.  Accept either — we clamp at zero overshoot so the
            # recommendation stays safe even when float drift rounds down.)
            advice = pg.get_max_tokens(
                "u1", model="gpt-4o", estimated_input_tokens=4000,
            )
            assert advice.max_tokens in (3999, 4000)
            assert advice.binding_limit == "period_spend"
        finally:
            _cleanup_pg(pg)

    def test_messages_triggers_input_estimate(self):
        """Passing messages= uses the chars/4 heuristic for input tokens."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=0.05,
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            # ~100 chars → ~25 tokens (negligible cost)
            short = [{"role": "user", "content": "Hello " * 20}]
            advice_short = pg.get_max_tokens("u1", model="gpt-4o", messages=short)
            # Plenty of headroom — should hit hard_cap
            assert advice_short.max_tokens == 4096

            # A 40,000-char message → 10,000 tokens input → input cost
            # = (10_000/1000) * 0.0025 = $0.025 → leaves $0.025 → 2500 output
            long = [{"role": "user", "content": "x" * 40_000}]
            advice_long = pg.get_max_tokens("u1", model="gpt-4o", messages=long)
            assert advice_long.max_tokens == 2500
        finally:
            _cleanup_pg(pg)

    def test_explicit_input_tokens_wins_over_messages(self):
        """If estimated_input_tokens is set, messages= is ignored."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=0.05,
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            # long messages but explicit input=0 → use input=0
            long = [{"role": "user", "content": "x" * 40_000}]
            advice = pg.get_max_tokens(
                "u1", model="gpt-4o",
                estimated_input_tokens=1,  # non-zero so messages is ignored
                messages=long,
            )
            # (1/1000)*0.0025 = negligible; $0.05-ε → ~5000 output tokens → clamped
            assert advice.max_tokens == 4096
        finally:
            _cleanup_pg(pg)

    def test_already_hard_gated_returns_zero(self):
        """If the user is already over a hard gate, advice is 0 + blocked."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=1.0)
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 1.5  # already over
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            assert advice.max_tokens == 0
            assert advice.binding_limit == "blocked"
        finally:
            _cleanup_pg(pg)

    def test_unknown_user_auto_loads(self):
        """Unknown user → fallback chain populates permissive defaults."""
        pg = _make_pg()
        try:
            advice = pg.get_max_tokens("never_seen", model="gpt-4o")
            # Permissive defaults → unbounded
            assert advice.binding_limit == "unbounded"
            assert advice.max_tokens == 4096
        finally:
            _cleanup_pg(pg)

    def test_unknown_model_no_rate_falls_to_hard_cap(self):
        """Model with no cost rate and no model_limit → hard_cap applies."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=1.0)  # has spend limit
            pg.start_session("u1", plan="pro", plan_config=config)
            # No cost_rates → we can't price output tokens → spend
            # dimensions contribute nothing → fallback to hard_cap
            advice = pg.get_max_tokens("u1", model="some-weird-model")
            assert advice.max_tokens == 4096
            assert advice.binding_limit == "unbounded"
        finally:
            _cleanup_pg(pg)

    def test_respects_hard_gate_at_fraction(self):
        """hard_gate_at=0.9 means the 'cap' is 90% of the configured limit."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=1.0,
                hard_gate_at=0.9,  # tighter than default
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 0.80  # $0.10 to reach 0.9×$1
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # $0.10 / ($0.01/1K) = 10_000 output tokens → clamped to 4096
            assert advice.max_tokens == 4096
            # Tighter: spend up to $0.88 → $0.02 headroom → 2000 tokens
            session.current_usage.period_cost = 0.88
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            assert advice.max_tokens == 2000
        finally:
            _cleanup_pg(pg)

    def test_returns_smallest_binding_dimension(self):
        """When multiple dimensions are finite, the smallest wins."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=100.0,      # huge → ~10M tokens
                max_spend_per_session=10.0,       # medium → ~1M tokens
                model_limits={
                    "gpt-4o": ModelLimitConfig(max_tokens_per_period=500),  # tight
                },
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 100
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            # 500 - 100 = 400 tokens → clearly smallest
            assert advice.max_tokens == 400
            assert advice.binding_limit == "model_tokens"
        finally:
            _cleanup_pg(pg)

    def test_fail_closed_on_internal_error(self, monkeypatch):
        """Internal exception → returns 0 tokens + blocked (fail CLOSED,
        unlike is_within_limit which fails open).  Better to tell the dev
        'don't call' than to silently hand them a bypass."""
        pg = _make_pg()
        try:
            def boom(uid):
                raise RuntimeError("injected")
            monkeypatch.setattr(pg, "_get_user_state", boom)
            advice = pg.get_max_tokens("u1", model="gpt-4o")
            assert advice.max_tokens == 0
            assert advice.binding_limit == "blocked"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# pre_call_estimate default (Option A — tightened worst-case output)
# ---------------------------------------------------------------------------


class TestPreCallEstimateDefault:
    """When pre_call_estimate=True and max_tokens is absent, the estimate
    must use a sensible worst-case output value (pre_call_buffer_tokens).
    The default is 4096 — large enough that typical unbounded completions
    actually get caught pre-call."""

    def test_default_buffer_is_4096(self):
        config = PlanConfig()
        assert config.pre_call_buffer_tokens == 4096

    def test_estimate_without_max_tokens_uses_buffer(self):
        """Guard check with pre_call_estimate=True + no max_tokens projects
        the worst-case output via pre_call_buffer_tokens."""
        from paygent.guardrails import _estimate_call
        config = PlanConfig(
            pre_call_estimate=True,
            pre_call_buffer_tokens=4096,
            cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.002)},
        )
        cost, total = _estimate_call(
            "gpt-4o", config, estimated_input_tokens=100, max_tokens=None,
        )
        assert total == 100 + 4096
        # Cost = (100/1000)*0.001 + (4096/1000)*0.002 = 0.0001 + 0.008192
        assert cost == pytest.approx(0.0001 + (4096 / 1000.0) * 0.002)

    def test_estimate_with_explicit_max_tokens_uses_that(self):
        """When max_tokens IS specified, buffer is ignored."""
        from paygent.guardrails import _estimate_call
        config = PlanConfig(
            pre_call_estimate=True,
            pre_call_buffer_tokens=4096,
            cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.002)},
        )
        cost, total = _estimate_call(
            "gpt-4o", config, estimated_input_tokens=100, max_tokens=50,
        )
        assert total == 100 + 50  # NOT 100 + 4096
        assert cost == pytest.approx((100 / 1000.0) * 0.001 + (50 / 1000.0) * 0.002)


# ---------------------------------------------------------------------------
# Init-time backend health check
# ---------------------------------------------------------------------------


class TestInitBackendHealthCheck:
    """Paygent.init() in connected mode probes the backend synchronously.

    On failure it either warns (default) or raises (strict_backend=True).
    On success it sets pg.backend_reachable=True and stays silent.

    These tests patch ApiClient.diagnose_backend to avoid real network I/O.
    """

    def _patch_diagnose(self, monkeypatch, result):
        """Swap diagnose_backend to return (status, detail) without HTTP."""
        from paygent.api_client import ApiClient
        monkeypatch.setattr(
            ApiClient, "diagnose_backend",
            lambda self, timeout=3.0: result,
        )

    def test_local_only_mode_skips_health_check(self, monkeypatch):
        """No api_key → no HTTP, no warnings, backend_reachable stays False."""
        called = []
        from paygent.api_client import ApiClient
        monkeypatch.setattr(
            ApiClient, "diagnose_backend",
            lambda self, timeout=3.0: called.append(True) or ("ok", ""),
        )

        with pytest.warns() if False else _no_warnings():
            pg = _make_pg()  # no api_key → local-only
        try:
            assert called == []  # never invoked
            assert pg.backend_reachable is False  # local mode = not reachable
        finally:
            _cleanup_pg(pg)

    def test_healthy_backend_silent_and_sets_flag(self, monkeypatch):
        """Backend reachable + auth OK → no warning, backend_reachable=True."""
        self._patch_diagnose(monkeypatch, ("ok", ""))

        with _no_warnings() as caught:
            pg = _make_pg(api_key="pg_live_test")
        try:
            # Only non-matching warnings allowed (e.g. deprecation from deps)
            paygent_warnings = [
                w for w in caught
                if issubclass(w.category, (PaygentBackendUnreachable, PaygentAuthInvalid))
            ]
            assert paygent_warnings == []
            assert pg.backend_reachable is True
        finally:
            _cleanup_pg(pg)

    def test_unreachable_backend_warns_and_continues(self, monkeypatch):
        """ConnectError → PaygentBackendUnreachable warning, init succeeds."""
        self._patch_diagnose(
            monkeypatch, ("unreachable", "connect error: nodename unknown"),
        )

        with pytest.warns(PaygentBackendUnreachable) as caught:
            pg = _make_pg(api_key="pg_live_test")
        try:
            assert len(caught) == 1
            msg = str(caught[0].message)
            assert "OFFLINE mode" in msg
            assert "strict_backend=True" in msg
            assert pg.backend_reachable is False
            assert pg.is_initialized  # init still completed
        finally:
            _cleanup_pg(pg)

    def test_auth_invalid_warns_distinct_class(self, monkeypatch):
        """401/403 → PaygentAuthInvalid (not PaygentBackendUnreachable)."""
        self._patch_diagnose(monkeypatch, ("auth_invalid", "HTTP 401"))

        with pytest.warns(PaygentAuthInvalid) as caught:
            pg = _make_pg(api_key="pg_live_bad_key")
        try:
            assert len(caught) == 1
            msg = str(caught[0].message)
            assert "rejected the API key" in msg
            assert pg.backend_reachable is False
        finally:
            _cleanup_pg(pg)

    def test_unexpected_status_warns_as_unreachable(self, monkeypatch):
        """Non-200/401/403 response → PaygentBackendUnreachable (catch-all)."""
        self._patch_diagnose(monkeypatch, ("other", "HTTP 500"))

        with pytest.warns(PaygentBackendUnreachable) as caught:
            pg = _make_pg(api_key="pg_live_test")
        try:
            assert len(caught) == 1
            assert "unexpected response" in str(caught[0].message).lower()
            assert pg.backend_reachable is False
        finally:
            _cleanup_pg(pg)

    def test_strict_backend_raises_on_unreachable(self, monkeypatch):
        """strict_backend=True + unreachable → raises PaygentBackendUnreachable."""
        self._patch_diagnose(monkeypatch, ("unreachable", "DNS failed"))

        with pytest.raises(PaygentBackendUnreachable) as exc_info:
            _make_pg(api_key="pg_live_test", strict_backend=True)
        assert "OFFLINE mode" in str(exc_info.value)
        # Note: no pg to clean up — init() raised, instance was never assigned
        # to the singleton by the time we got here (exception from within
        # _initialize aborts the rest of init()).

    def test_strict_backend_raises_on_auth_invalid(self, monkeypatch):
        """strict_backend=True + 401 → raises PaygentAuthInvalid."""
        self._patch_diagnose(monkeypatch, ("auth_invalid", "HTTP 401"))

        with pytest.raises(PaygentAuthInvalid) as exc_info:
            _make_pg(api_key="pg_live_bad", strict_backend=True)
        assert "rejected the API key" in str(exc_info.value)

    def test_strict_backend_false_is_default(self, monkeypatch):
        """Default is strict_backend=False → warns, does not raise."""
        self._patch_diagnose(monkeypatch, ("unreachable", "x"))
        # Should NOT raise
        with pytest.warns(PaygentBackendUnreachable):
            pg = _make_pg(api_key="pg_live_test")  # no strict_backend passed
        try:
            assert pg.is_initialized
        finally:
            _cleanup_pg(pg)

    def test_diagnose_itself_raises_defensive(self, monkeypatch):
        """If diagnose_backend itself raises unexpectedly, init still completes
        (warning emitted, not a crash)."""
        from paygent.api_client import ApiClient
        def blowup(self, timeout=3.0):
            raise RuntimeError("unexpected")
        monkeypatch.setattr(ApiClient, "diagnose_backend", blowup)

        with pytest.warns(PaygentBackendUnreachable):
            pg = _make_pg(api_key="pg_live_test")
        try:
            assert pg.is_initialized
            assert pg.backend_reachable is False
        finally:
            _cleanup_pg(pg)

    def test_backend_reachable_property_reflects_probe_result(self, monkeypatch):
        """The `backend_reachable` property returns what the probe decided."""
        # Healthy
        self._patch_diagnose(monkeypatch, ("ok", ""))
        pg1 = _make_pg(api_key="pg_live_test")
        try:
            assert pg1.backend_reachable is True
        finally:
            _cleanup_pg(pg1)

        # Unreachable
        self._patch_diagnose(monkeypatch, ("unreachable", "x"))
        with pytest.warns(PaygentBackendUnreachable):
            pg2 = _make_pg(api_key="pg_live_test")
        try:
            assert pg2.backend_reachable is False
        finally:
            _cleanup_pg(pg2)

    def test_warnings_exported_from_top_level_paygent(self):
        """Both warning classes are exported from the ``paygent`` package
        so devs can import them directly for filtering / promotion."""
        import paygent
        assert paygent.PaygentBackendUnreachable is PaygentBackendUnreachable
        assert paygent.PaygentAuthInvalid is PaygentAuthInvalid

    def test_warnings_are_user_warnings_so_stderr_default(self):
        """Warning classes must subclass UserWarning so Python's default
        warning filter prints them to stderr without extra config."""
        assert issubclass(PaygentBackendUnreachable, UserWarning)
        assert issubclass(PaygentAuthInvalid, UserWarning)


# ---------------------------------------------------------------------------
# Cross-process session-identity continuity
#
# Regression suite: the bug this guards against is "every Python process
# restart mints a new session_id within the timeout window."  That breaks
# `max_spend_per_session` as a rate limit (reset on every worker recycle),
# and makes session-based analytics noisy (every cold start = a new
# "session" in the backend even though the user's window didn't close).
#
# The fix: when the SDK cold-starts and fetches from the backend, it
# peeks at the on-disk snapshot and carries over session_id /
# session_started_at / session_cost if present.  Natural rotation still
# happens via _maybe_rotate_session when session_started_at ages past
# session_timeout_minutes.
# ---------------------------------------------------------------------------


class TestSessionContinuityAcrossColdStarts:
    """The SDK must preserve session identity when a process restarts
    within the session_timeout_minutes window.

    We simulate a cold start by:
      1. Creating a Paygent instance against a backend stub.
      2. Triggering a fetch (populates in-memory + saves snapshot).
      3. Shutting that instance down (wipes in-memory cache).
      4. Creating a second Paygent instance pointing at the SAME db_path.
      5. Triggering another fetch (should reuse snapshot's session window).
    """

    def _stub_fetch_session(self, pg, user_id: str = "user_1"):
        """Install a stub on the api_client that returns a minimal UserState
        with session window fields cleared (as _parse_session_response now does).
        """
        from paygent.models import BillingPeriod, CurrentUsage, UserState

        def _stub(uid):
            return UserState(
                user_id=uid,
                plan="pro",
                plan_config=PlanConfig(
                    max_spend_per_period=49.00,
                    max_spend_per_session=5.00,
                    session_timeout_minutes=30.0,
                ),
                current_usage=CurrentUsage(
                    period_cost=1.23,
                    session_cost=0.0,
                    session_id=None,           # backend doesn't own these
                    session_started_at=None,
                ),
            )

        pg._api_client = type("_C", (), {"fetch_session": staticmethod(_stub)})()

    def test_second_cold_start_reuses_session_id_from_snapshot(self):
        """Two sequential SDK processes against the same db_path see the
        same session_id for the same user, within the timeout window."""
        db_path = _tmp_db_path()
        try:
            # --- Process 1: cold start, first call ---
            pg1 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg1)
                state1 = pg1._get_user_state("user_1")
                sid1 = state1.current_usage.session_id
                started1 = state1.current_usage.session_started_at
                assert sid1 is not None
                assert started1 is not None
            finally:
                pg1.shutdown()

            # --- Process 2: cold start, same db_path, within 30 min ---
            pg2 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg2)
                state2 = pg2._get_user_state("user_1")
                sid2 = state2.current_usage.session_id
                started2 = state2.current_usage.session_started_at

                assert sid2 == sid1, (
                    "session_id must be stable across process restarts "
                    "within session_timeout_minutes — this is the core "
                    "regression guard."
                )
                assert started2 == started1, (
                    "session_started_at must carry over so the rotation "
                    "clock keeps ticking from the original start."
                )
            finally:
                pg2.shutdown()
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_cold_start_preserves_session_cost(self):
        """session_cost is a rate-limiter counter.  A restart must not
        zero it out, otherwise `max_spend_per_session` can be bypassed by
        restart-spamming the process."""
        db_path = _tmp_db_path()
        try:
            pg1 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg1)
                state1 = pg1._get_user_state("user_1")
                # Simulate an LLM call having already spent some session money
                state1.current_usage.session_cost = 3.75
                pg1._storage.save_snapshot_sync(state1)
            finally:
                pg1.shutdown()

            pg2 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg2)
                state2 = pg2._get_user_state("user_1")
                assert state2.current_usage.session_cost == 3.75, (
                    "session_cost must survive process restart or the "
                    "session-spend rate limit can be bypassed by restarting."
                )
            finally:
                pg2.shutdown()
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_stale_snapshot_still_rotates_on_next_call(self):
        """If the carried-over session_started_at is older than the timeout,
        the next call must rotate cleanly — we're not keeping zombie sessions
        alive forever, just bridging legitimate continuity gaps."""
        from datetime import datetime, timedelta

        db_path = _tmp_db_path()
        try:
            pg1 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg1)
                state1 = pg1._get_user_state("user_1")
                sid1 = state1.current_usage.session_id
                # Backdate session_started_at by 2 hours — older than the
                # 30-min timeout on the plan.
                state1.current_usage.session_started_at = (
                    datetime.utcnow() - timedelta(hours=2)
                )
                pg1._storage.save_snapshot_sync(state1)
            finally:
                pg1.shutdown()

            pg2 = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg2)
                state2 = pg2._get_user_state("user_1")
                # Snapshot carried the stale session into memory.
                assert state2.current_usage.session_id == sid1

                # Now trigger the rotation path that runs on every guard
                # check / cache update.
                from paygent.metering import _maybe_rotate_session
                _maybe_rotate_session(
                    state2.current_usage,
                    state2.plan_config.session_timeout_minutes,
                )
                assert state2.current_usage.session_id != sid1, (
                    "Stale session must rotate — otherwise zombie session "
                    "ids persist past their timeout."
                )
                assert state2.current_usage.session_cost == 0.0
            finally:
                pg2.shutdown()
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass

    def test_no_snapshot_stamps_fresh_session(self):
        """First-ever run on a fresh machine (no snapshot anywhere) must
        still produce a valid session_id — we didn't break the cold-boot
        case by making snapshot-restore the primary path."""
        db_path = _tmp_db_path()
        try:
            pg = Paygent.init(db_path=db_path, auto_instrument=False)
            try:
                self._stub_fetch_session(pg)
                state = pg._get_user_state("brand_new_user")
                assert state.current_usage.session_id is not None
                assert state.current_usage.session_started_at is not None
            finally:
                pg.shutdown()
        finally:
            try:
                os.unlink(db_path)
            except OSError:
                pass
