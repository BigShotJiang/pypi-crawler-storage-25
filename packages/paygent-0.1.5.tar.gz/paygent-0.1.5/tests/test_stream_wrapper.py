"""Tests for Paygent streaming response wrapper."""

from __future__ import annotations

from types import SimpleNamespace
from typing import AsyncIterator

import pytest

from paygent.providers import TokenInfo
from paygent.stream_wrapper import (
    AsyncStreamWrapper,
    StreamWrapper,
    extract_anthropic_stream_tokens,
    extract_openai_stream_tokens,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_openai_stream_chunks(model="gpt-4o", n_content=3, include_usage=True):
    """Simulate OpenAI streaming chunks with optional final usage chunk."""
    chunks = []
    for i in range(n_content):
        chunks.append(SimpleNamespace(
            model=model,
            choices=[SimpleNamespace(delta=SimpleNamespace(content=f"chunk{i}"))],
            usage=None,
        ))
    if include_usage:
        chunks.append(SimpleNamespace(
            model=model,
            choices=[],
            usage=SimpleNamespace(
                prompt_tokens=100,
                completion_tokens=50,
                total_tokens=150,
            ),
        ))
    return chunks


def _make_anthropic_stream_chunks(model="claude-sonnet-4-20250514"):
    """Simulate Anthropic streaming events."""
    return [
        SimpleNamespace(
            type="message_start",
            message=SimpleNamespace(
                model=model,
                usage=SimpleNamespace(input_tokens=80),
            ),
        ),
        SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text="Hello")),
        SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text=" world")),
        SimpleNamespace(
            type="message_delta",
            usage=SimpleNamespace(output_tokens=40),
        ),
        SimpleNamespace(type="message_stop"),
    ]


# ---------------------------------------------------------------------------
# Sync StreamWrapper
# ---------------------------------------------------------------------------


class TestStreamWrapper:
    def test_yields_all_chunks(self):
        """Wrapper yields every chunk unchanged."""
        chunks = _make_openai_stream_chunks()
        completed = []

        wrapped = StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )

        collected = list(wrapped)
        assert len(collected) == len(chunks)
        assert collected[0].model == "gpt-4o"

    def test_on_complete_fires_after_iteration(self):
        """Callback fires once after all chunks are consumed."""
        chunks = _make_openai_stream_chunks(include_usage=True)
        completed = []

        wrapped = StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )
        list(wrapped)  # consume

        assert len(completed) == 1
        assert completed[0].input_tokens == 100
        assert completed[0].output_tokens == 50
        assert completed[0].total_tokens == 150
        assert completed[0].model == "gpt-4o"

    def test_on_complete_fires_only_once(self):
        """Multiple iterations or close calls should not re-fire."""
        chunks = _make_openai_stream_chunks()
        call_count = {"n": 0}

        def on_done(info, c):
            call_count["n"] += 1

        wrapped = StreamWrapper(stream=iter(chunks), on_complete=on_done)
        list(wrapped)
        wrapped.close()  # Extra close

        assert call_count["n"] == 1

    def test_context_manager(self):
        """Works as a context manager (OpenAI streams are context managers)."""
        chunks = _make_openai_stream_chunks()
        completed = []

        with StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        ) as wrapped:
            collected = list(wrapped)

        assert len(collected) == len(chunks)
        assert len(completed) == 1

    def test_no_usage_in_stream(self):
        """Stream without usage data — should still complete without error."""
        chunks = _make_openai_stream_chunks(include_usage=False)
        completed = []

        wrapped = StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )
        list(wrapped)

        assert len(completed) == 1
        assert completed[0].model == "gpt-4o"
        assert completed[0].total_tokens == 0

    def test_empty_stream(self):
        """Empty stream — callback fires with empty TokenInfo."""
        completed = []

        wrapped = StreamWrapper(
            stream=iter([]),
            on_complete=lambda info, c: completed.append(info),
        )
        list(wrapped)

        assert len(completed) == 1
        assert completed[0].total_tokens == 0

    def test_on_complete_error_swallowed(self):
        """Error in on_complete should not propagate (fail-open)."""
        chunks = _make_openai_stream_chunks()

        def bad_callback(info, c):
            raise RuntimeError("boom")

        wrapped = StreamWrapper(stream=iter(chunks), on_complete=bad_callback)
        collected = list(wrapped)  # should not raise
        assert len(collected) == len(chunks)

    def test_custom_extractor(self):
        """Custom stream token extractor is used if provided."""
        chunks = [SimpleNamespace(data="chunk1"), SimpleNamespace(data="chunk2")]
        completed = []

        def custom_extractor(c):
            return TokenInfo(model="custom", input_tokens=999, output_tokens=1, total_tokens=1000)

        wrapped = StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
            extract_stream_tokens=custom_extractor,
        )
        list(wrapped)

        assert completed[0].model == "custom"
        assert completed[0].input_tokens == 999

    def test_close_finalizes(self):
        """Calling close() triggers finalization."""
        chunks = _make_openai_stream_chunks()
        completed = []

        wrapped = StreamWrapper(
            stream=iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )
        # Don't consume — just close
        wrapped.close()
        assert len(completed) == 1


# ---------------------------------------------------------------------------
# Async StreamWrapper
# ---------------------------------------------------------------------------


class TestAsyncStreamWrapper:
    @staticmethod
    async def _async_iter(items):
        for item in items:
            yield item

    @pytest.mark.asyncio
    async def test_yields_all_chunks(self):
        chunks = _make_openai_stream_chunks()
        completed = []

        wrapped = AsyncStreamWrapper(
            stream=self._async_iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )

        collected = []
        async for chunk in wrapped:
            collected.append(chunk)

        assert len(collected) == len(chunks)

    @pytest.mark.asyncio
    async def test_on_complete_fires(self):
        chunks = _make_openai_stream_chunks(include_usage=True)
        completed = []

        wrapped = AsyncStreamWrapper(
            stream=self._async_iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        )

        async for _ in wrapped:
            pass

        assert len(completed) == 1
        assert completed[0].input_tokens == 100

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        chunks = _make_openai_stream_chunks()
        completed = []

        async with AsyncStreamWrapper(
            stream=self._async_iter(chunks),
            on_complete=lambda info, c: completed.append(info),
        ) as wrapped:
            async for _ in wrapped:
                pass

        assert len(completed) == 1

    @pytest.mark.asyncio
    async def test_on_complete_error_swallowed(self):
        chunks = _make_openai_stream_chunks()

        def bad_callback(info, c):
            raise RuntimeError("boom")

        wrapped = AsyncStreamWrapper(
            stream=self._async_iter(chunks),
            on_complete=bad_callback,
        )

        collected = []
        async for chunk in wrapped:
            collected.append(chunk)

        assert len(collected) == len(chunks)  # no error propagated


# ---------------------------------------------------------------------------
# OpenAI Stream Token Extractor
# ---------------------------------------------------------------------------


class TestOpenAIStreamExtractor:
    def test_with_usage_in_last_chunk(self):
        chunks = _make_openai_stream_chunks(include_usage=True)
        info = extract_openai_stream_tokens(chunks)
        assert info.input_tokens == 100
        assert info.output_tokens == 50
        assert info.model == "gpt-4o"

    def test_without_usage(self):
        chunks = _make_openai_stream_chunks(include_usage=False)
        info = extract_openai_stream_tokens(chunks)
        assert info.model == "gpt-4o"
        assert info.total_tokens == 0

    def test_empty_chunks(self):
        info = extract_openai_stream_tokens([])
        assert info.total_tokens == 0


# ---------------------------------------------------------------------------
# Anthropic Stream Token Extractor
# ---------------------------------------------------------------------------


class TestAnthropicStreamExtractor:
    def test_extracts_from_message_events(self):
        chunks = _make_anthropic_stream_chunks()
        info = extract_anthropic_stream_tokens(chunks)
        assert info.model == "claude-sonnet-4-20250514"
        assert info.input_tokens == 80
        assert info.output_tokens == 40
        assert info.total_tokens == 120

    def test_empty_chunks(self):
        info = extract_anthropic_stream_tokens([])
        assert info.total_tokens == 0

    def test_missing_usage_events(self):
        """Stream with content blocks but no usage events."""
        chunks = [
            SimpleNamespace(type="content_block_delta", delta=SimpleNamespace(text="Hello")),
        ]
        info = extract_anthropic_stream_tokens(chunks)
        assert info.total_tokens == 0
