"""Shared test fixtures for Paygent tests."""

import pytest

from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserSession,
)


@pytest.fixture
def pro_plan_config() -> PlanConfig:
    """A realistic Pro plan config with model-level limits."""
    return PlanConfig(
        max_spend_per_period=49.00,
        max_spend_per_session=5.00,
        soft_gate_at=0.80,
        hard_gate_at=1.00,
        model_limits={
            "gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000),
            "claude-sonnet-4-20250514": ModelLimitConfig(max_tokens_per_period=30_000),
            "gpt-4o-mini": ModelLimitConfig(max_tokens_per_period=20_000),
        },
        cost_rates={
            "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
            "gpt-4o-mini": ModelCostRate(input=0.00015, output=0.0006),
            "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
        },
        tool_costs={"web_search": 0.05, "code_exec": 0.10},
        default_tool_cost=0.02,
    )


@pytest.fixture
def free_plan_config() -> PlanConfig:
    """A realistic Free plan config."""
    return PlanConfig(
        max_spend_per_period=5.00,
        max_spend_per_session=0.50,
        soft_gate_at=0.80,
        hard_gate_at=1.00,
        model_limits={
            "gpt-4o": ModelLimitConfig(max_tokens_per_period=10_000),
        },
        cost_rates={
            "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
        },
    )


@pytest.fixture
def empty_usage() -> CurrentUsage:
    """Fresh usage with no consumption."""
    return CurrentUsage()


@pytest.fixture
def pro_session(pro_plan_config: PlanConfig, empty_usage: CurrentUsage) -> UserSession:
    """A Pro user session with no usage yet."""
    return UserSession(
        user_id="user_123",
        plan="pro",
        plan_config=pro_plan_config,
        current_usage=empty_usage,
    )


@pytest.fixture
def free_session(free_plan_config: PlanConfig, empty_usage: CurrentUsage) -> UserSession:
    """A Free user session with no usage yet."""
    return UserSession(
        user_id="user_456",
        plan="free",
        plan_config=free_plan_config,
        current_usage=empty_usage,
    )
