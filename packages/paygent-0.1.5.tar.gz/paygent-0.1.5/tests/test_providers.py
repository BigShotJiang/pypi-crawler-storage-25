"""Tests for Paygent provider registry and token extractors."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from paygent.providers import (
    ANTHROPIC_PROVIDER,
    OPENAI_PROVIDER,
    ProviderConfig,
    ProviderRegistry,
    TokenInfo,
    create_default_registry,
    extract_anthropic_tokens,
    extract_openai_tokens,
)


# ---------------------------------------------------------------------------
# OpenAI Token Extractor
# ---------------------------------------------------------------------------


class TestExtractOpenAITokens:
    def test_object_response(self):
        """Standard openai>=1.0 response with usage as object attributes."""
        response = SimpleNamespace(
            model="gpt-4o",
            usage=SimpleNamespace(
                prompt_tokens=1200,
                completion_tokens=340,
                total_tokens=1540,
            ),
        )
        info = extract_openai_tokens(response)
        assert info.model == "gpt-4o"
        assert info.input_tokens == 1200
        assert info.output_tokens == 340
        assert info.total_tokens == 1540

    def test_dict_response(self):
        """Response as a plain dict (legacy or custom client)."""
        response = {
            "model": "gpt-4o-mini",
            "usage": {
                "prompt_tokens": 500,
                "completion_tokens": 100,
                "total_tokens": 600,
            },
        }
        info = extract_openai_tokens(response)
        assert info.model == "gpt-4o-mini"
        assert info.input_tokens == 500
        assert info.output_tokens == 100
        assert info.total_tokens == 600

    def test_no_usage_field(self):
        """Response without usage data — should return model only."""
        response = SimpleNamespace(model="gpt-4o")
        info = extract_openai_tokens(response)
        assert info.model == "gpt-4o"
        assert info.input_tokens == 0
        assert info.output_tokens == 0

    def test_none_response(self):
        """None response — should not crash (fail-open)."""
        info = extract_openai_tokens(None)
        assert isinstance(info, TokenInfo)
        assert info.input_tokens == 0

    def test_garbage_response(self):
        """Totally unexpected response type — should not crash."""
        info = extract_openai_tokens(12345)
        assert isinstance(info, TokenInfo)

    def test_missing_total_tokens_calculated(self):
        """If total_tokens is missing, it should be calculated from input + output."""
        response = SimpleNamespace(
            model="gpt-4o",
            usage=SimpleNamespace(
                prompt_tokens=100,
                completion_tokens=50,
                total_tokens=0,
            ),
        )
        info = extract_openai_tokens(response)
        assert info.total_tokens == 150

    def test_usage_with_none_values(self):
        """Usage fields that are None should default to 0."""
        response = SimpleNamespace(
            model="gpt-4o",
            usage=SimpleNamespace(
                prompt_tokens=None,
                completion_tokens=None,
                total_tokens=None,
            ),
        )
        info = extract_openai_tokens(response)
        assert info.input_tokens == 0
        assert info.output_tokens == 0
        assert info.total_tokens == 0

    def test_new_style_input_output_tokens(self):
        """Newer OpenAI SDK versions use input_tokens/output_tokens."""
        response = SimpleNamespace(
            model="gpt-4o-mini",
            usage=SimpleNamespace(
                input_tokens=900,
                output_tokens=250,
                total_tokens=1150,
            ),
        )
        info = extract_openai_tokens(response)
        assert info.model == "gpt-4o-mini"
        assert info.input_tokens == 900
        assert info.output_tokens == 250
        assert info.total_tokens == 1150

    def test_new_style_dict_response(self):
        """Newer OpenAI SDK dict response with input_tokens/output_tokens."""
        response = {
            "model": "gpt-4o",
            "usage": {
                "input_tokens": 700,
                "output_tokens": 300,
                "total_tokens": 1000,
            },
        }
        info = extract_openai_tokens(response)
        assert info.input_tokens == 700
        assert info.output_tokens == 300
        assert info.total_tokens == 1000

    def test_both_old_and_new_names_prefers_new(self):
        """When both old and new attribute names exist, prefer new names."""
        response = SimpleNamespace(
            model="gpt-4o",
            usage=SimpleNamespace(
                prompt_tokens=100,
                completion_tokens=50,
                input_tokens=900,
                output_tokens=250,
                total_tokens=1150,
            ),
        )
        info = extract_openai_tokens(response)
        # New names (input_tokens/output_tokens) are preferred
        assert info.input_tokens == 900
        assert info.output_tokens == 250


# ---------------------------------------------------------------------------
# Anthropic Token Extractor
# ---------------------------------------------------------------------------


class TestExtractAnthropicTokens:
    def test_object_response(self):
        """Standard anthropic>=0.18 response with usage as object attributes."""
        response = SimpleNamespace(
            model="claude-sonnet-4-20250514",
            usage=SimpleNamespace(
                input_tokens=800,
                output_tokens=200,
            ),
        )
        info = extract_anthropic_tokens(response)
        assert info.model == "claude-sonnet-4-20250514"
        assert info.input_tokens == 800
        assert info.output_tokens == 200
        assert info.total_tokens == 1000

    def test_dict_response(self):
        """Response as a plain dict."""
        response = {
            "model": "claude-haiku-3",
            "usage": {
                "input_tokens": 300,
                "output_tokens": 50,
            },
        }
        info = extract_anthropic_tokens(response)
        assert info.model == "claude-haiku-3"
        assert info.input_tokens == 300
        assert info.output_tokens == 50
        assert info.total_tokens == 350

    def test_no_usage_field(self):
        """Response without usage — should return model only."""
        response = SimpleNamespace(model="claude-sonnet-4-20250514")
        info = extract_anthropic_tokens(response)
        assert info.model == "claude-sonnet-4-20250514"
        assert info.input_tokens == 0

    def test_none_response(self):
        """None response — fail-open."""
        info = extract_anthropic_tokens(None)
        assert isinstance(info, TokenInfo)

    def test_garbage_response(self):
        """Unexpected type — fail-open."""
        info = extract_anthropic_tokens([1, 2, 3])
        assert isinstance(info, TokenInfo)


# ---------------------------------------------------------------------------
# ProviderConfig
# ---------------------------------------------------------------------------


class TestProviderConfig:
    def test_openai_config(self):
        assert OPENAI_PROVIDER.name == "openai"
        assert OPENAI_PROVIDER.module_path == "openai.resources.chat.completions"
        assert OPENAI_PROVIDER.class_name == "Completions"
        assert OPENAI_PROVIDER.method_name == "create"
        assert OPENAI_PROVIDER.async_class_name == "AsyncCompletions"

    def test_anthropic_config(self):
        assert ANTHROPIC_PROVIDER.name == "anthropic"
        assert ANTHROPIC_PROVIDER.module_path == "anthropic.resources.messages"
        assert ANTHROPIC_PROVIDER.class_name == "Messages"


# ---------------------------------------------------------------------------
# ProviderRegistry
# ---------------------------------------------------------------------------


class TestProviderRegistry:
    def test_empty_registry(self):
        registry = ProviderRegistry()
        assert registry.names == []
        assert registry.all() == []
        assert registry.get("openai") is None

    def test_register_and_get(self):
        registry = ProviderRegistry()
        registry.register(OPENAI_PROVIDER)
        assert registry.get("openai") is OPENAI_PROVIDER
        assert "openai" in registry.names

    def test_default_registry(self):
        registry = create_default_registry()
        assert "openai" in registry.names
        assert "anthropic" in registry.names
        assert len(registry.all()) == 2

    def test_register_overwrites(self):
        """Re-registering the same provider name should overwrite."""
        registry = ProviderRegistry()
        custom = ProviderConfig(
            name="openai",
            module_path="custom.path",
            class_name="Custom",
            method_name="call",
        )
        registry.register(OPENAI_PROVIDER)
        registry.register(custom)
        assert registry.get("openai").module_path == "custom.path"

    def test_register_custom_provider(self):
        """Developers should be able to register custom providers."""
        registry = create_default_registry()
        custom = ProviderConfig(
            name="cohere",
            module_path="cohere.client",
            class_name="Client",
            method_name="chat",
        )
        registry.register(custom)
        assert "cohere" in registry.names
        assert len(registry.all()) == 3
