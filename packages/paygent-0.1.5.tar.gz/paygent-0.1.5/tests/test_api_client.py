"""Tests for ApiClient — HTTP client for the Paygent backend.

All tests use httpx mock transport — no real network calls.
"""

from __future__ import annotations

import json
from datetime import datetime

import httpx
import pytest

from paygent.api_client import (
    ApiClient,
    BatchResult,
    _parse_session_response,
    _serialize_event,
)
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
    UserSession,
)


# ---------------------------------------------------------------------------
# Mock HTTP Transport
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    """Mock transport that returns pre-configured responses."""

    def __init__(self):
        self.requests: list[httpx.Request] = []
        self._routes: dict[tuple[str, str], tuple[int, dict]] = {}
        self._error: Exception | None = None

    def add_route(
        self, method: str, path: str, status: int = 200, json_body: dict | list | None = None
    ):
        """Register a mock response for a method + path."""
        self._routes[(method.upper(), path)] = (status, json_body or {})

    def set_error(self, error: Exception):
        """Make all requests raise this error."""
        self._error = error

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)

        if self._error is not None:
            raise self._error

        key = (request.method, request.url.raw_path.decode())
        if key in self._routes:
            status, body = self._routes[key]
            return httpx.Response(
                status_code=status,
                json=body,
                request=request,
            )

        return httpx.Response(status_code=404, json={"error": "not found"}, request=request)


def _make_client(transport: MockTransport) -> ApiClient:
    """Create an ApiClient with a mock transport."""
    client = ApiClient(
        api_key="pg_live_test_123",
        base_url="https://api.paygent.dev",
        timeout=5.0,
    )
    # Replace the httpx client with one using our mock transport
    client._client = httpx.Client(
        base_url="https://api.paygent.dev",
        headers={
            "Authorization": "Bearer pg_live_test_123",
            "Content-Type": "application/json",
        },
        transport=transport,
    )
    return client


# ---------------------------------------------------------------------------
# Health Check
# ---------------------------------------------------------------------------


class TestHealthCheck:
    def test_healthy_backend(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/health", 200, {"status": "ok"})
        client = _make_client(transport)

        assert client.health_check() is True
        assert len(transport.requests) == 1
        client.close()

    def test_unhealthy_backend(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/health", 200, {"status": "degraded"})
        client = _make_client(transport)

        assert client.health_check() is False
        client.close()

    def test_server_error(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/health", 500, {"error": "internal"})
        client = _make_client(transport)

        assert client.health_check() is False
        client.close()

    def test_connection_error(self):
        transport = MockTransport()
        transport.set_error(httpx.ConnectError("Connection refused"))
        client = _make_client(transport)

        assert client.health_check() is False
        client.close()

    def test_timeout_error(self):
        transport = MockTransport()
        transport.set_error(httpx.TimeoutException("Timed out"))
        client = _make_client(transport)

        assert client.health_check() is False
        client.close()


# ---------------------------------------------------------------------------
# Fetch Session
# ---------------------------------------------------------------------------


SAMPLE_SESSION_RESPONSE = {
    "user_id": "user_123",
    "plan": "pro",
    "plan_config": {
        "max_spend_per_period": 49.00,
        "max_spend_per_session": 5.00,
        "soft_gate_at": 0.80,
        "hard_gate_at": 1.00,
        "model_limits": {
            "gpt-4o": {"max_tokens_per_period": 50000},
            "claude-sonnet-4-20250514": {"max_tokens_per_period": 30000},
        },
        "cost_rates": {
            "gpt-4o": {"input": 0.0025, "output": 0.01},
        },
        "tool_costs": {"web_search": 0.05},
        "default_tool_cost": 0.03,
    },
    "current_usage": {
        "period_cost": 23.47,
        "session_cost": 1.20,
        "period_tokens_total": 42000,
        "period_tokens_by_model": {
            "gpt-4o": 31200,
            "claude-sonnet-4-20250514": 8400,
        },
        "period_cost_by_model": {
            "gpt-4o": 15.00,
            "claude-sonnet-4-20250514": 8.47,
        },
    },
}


class TestFetchSession:
    def test_successful_fetch(self):
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200, SAMPLE_SESSION_RESPONSE
        )
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is not None
        assert session.user_id == "user_123"
        assert session.plan == "pro"
        assert session.plan_config.max_spend_per_period == 49.00
        assert session.plan_config.max_spend_per_session == 5.00
        assert session.plan_config.soft_gate_at == 0.80
        assert "gpt-4o" in session.plan_config.model_limits
        assert session.plan_config.model_limits["gpt-4o"].max_tokens_per_period == 50000
        assert "gpt-4o" in session.plan_config.cost_rates
        assert session.plan_config.cost_rates["gpt-4o"].input == 0.0025
        assert session.plan_config.tool_costs["web_search"] == 0.05
        assert session.plan_config.default_tool_cost == 0.03
        assert session.current_usage.period_cost == 23.47
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 31200
        client.close()

    def test_user_not_found(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/users/unknown/session", 404, {"error": "not found"})
        client = _make_client(transport)

        session = client.fetch_session("unknown")
        assert session is None
        client.close()

    def test_server_error_returns_none(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/users/user_123/session", 500, {})
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is None
        client.close()

    def test_connection_error_returns_none(self):
        transport = MockTransport()
        transport.set_error(httpx.ConnectError("Connection refused"))
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is None
        client.close()

    def test_timeout_returns_none(self):
        transport = MockTransport()
        transport.set_error(httpx.TimeoutException("Timed out"))
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is None
        client.close()

    def test_minimal_session_response(self):
        """Backend returns minimal data — should use defaults."""
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200,
            {"user_id": "user_123", "plan": "free"},
        )
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is not None
        assert session.user_id == "user_123"
        assert session.plan == "free"
        assert session.plan_config.max_spend_per_period == float("inf")
        assert session.current_usage.period_cost == 0.0
        client.close()


class TestFetchSessionBadSchema:
    """Hostile / malformed JSON responses must not crash the SDK.

    The api_client is on the fail-open path: if the backend returns garbage,
    we must return None so ``_get_user_state`` can fall through to SQLite or
    permissive defaults instead of propagating a pydantic / JSON error into
    the caller's LLM call path.
    """

    def test_missing_required_fields(self):
        """Response missing user_id and plan should either return None or
        a UserState with safe defaults — must not raise."""
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200,
            {"plan_config": {}},  # no user_id, no plan
        )
        client = _make_client(transport)

        # Must not raise.  Either None (rejection) or a UserState with
        # defaults is acceptable — both are fail-open.
        session = client.fetch_session("user_123")
        if session is not None:
            # If we did construct one, it must at least be usable.
            assert session.user_id  # something, even if fallback
        client.close()

    def test_extra_unknown_fields_ignored(self):
        """Pydantic should ignore extra fields the SDK doesn't know about."""
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200,
            {
                "user_id": "user_123",
                "plan": "pro",
                "future_feature_x": "some_value",
                "plan_config": {
                    "max_spend_per_period": 10.0,
                    "brand_new_gate_type": 0.5,  # unknown field
                },
                "current_usage": {
                    "period_cost": 1.5,
                    "mystery_metric": 42,
                },
            },
        )
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is not None
        assert session.user_id == "user_123"
        assert session.plan_config.max_spend_per_period == 10.0
        assert session.current_usage.period_cost == 1.5
        client.close()

    def test_wrong_type_for_numeric_field(self):
        """Numeric field sent as a string should not crash the SDK."""
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200,
            {
                "user_id": "user_123",
                "plan": "pro",
                "plan_config": {
                    # These should be numbers — send strings that are
                    # coercible.  Pydantic v2 will convert numeric strings.
                    "max_spend_per_period": "49.0",
                    "soft_gate_at": "0.8",
                },
                "current_usage": {},
            },
        )
        client = _make_client(transport)

        # Either succeeds with coerced values, or returns None.  Must not raise.
        session = client.fetch_session("user_123")
        if session is not None:
            # Coerced correctly
            assert session.plan_config.max_spend_per_period == 49.0
        client.close()

    def test_wrong_type_completely_invalid(self):
        """A field with a completely incompatible type returns None (fail-open)."""
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/session", 200,
            {
                "user_id": "user_123",
                "plan": "pro",
                "plan_config": {
                    # Should be a dict — sending a string that's not coercible
                    "model_limits": "this is not a dict",
                },
                "current_usage": {},
            },
        )
        client = _make_client(transport)

        # Invalid shape — SDK must not raise.  Returns None so the caller
        # falls through the fallback chain.
        session = client.fetch_session("user_123")
        # Either None or a session with defaults — must not raise
        assert session is None or session.plan_config is not None
        client.close()

    def test_non_json_body(self):
        """Response body that isn't JSON at all."""
        transport = MockTransport()
        # Register raw-text handler
        def handle(request):
            transport.requests.append(request)
            return httpx.Response(
                status_code=200,
                content=b"<html>not json</html>",
                headers={"content-type": "text/html"},
                request=request,
            )
        transport.handle_request = handle  # type: ignore[assignment]
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is None
        client.close()

    def test_empty_body(self):
        """Response body is empty (zero bytes)."""
        transport = MockTransport()
        def handle(request):
            transport.requests.append(request)
            return httpx.Response(status_code=200, content=b"", request=request)
        transport.handle_request = handle  # type: ignore[assignment]
        client = _make_client(transport)

        session = client.fetch_session("user_123")
        assert session is None
        client.close()

    def test_null_top_level(self):
        """Response body is the JSON literal null."""
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/users/user_123/session", 200, None)
        client = _make_client(transport)

        # None JSON body — should not be treated as a valid session
        session = client.fetch_session("user_123")
        assert session is None
        client.close()


# ---------------------------------------------------------------------------
# Post Events
# ---------------------------------------------------------------------------


class TestPostEvents:
    def test_successful_post(self):
        transport = MockTransport()
        transport.add_route(
            "POST", "/api/v1/events/batch", 200, {"accepted": 3, "duplicates": 0}
        )
        client = _make_client(transport)

        events = [UsageEvent(user_id="user_1", model="gpt-4o") for _ in range(3)]
        result = client.post_events(events)

        assert result is not None
        assert result.accepted == 3
        assert result.duplicates == 0
        assert result.total == 3

        # Verify request payload
        body = json.loads(transport.requests[0].content)
        assert len(body) == 3
        assert body[0]["user_id"] == "user_1"
        assert body[0]["model"] == "gpt-4o"
        client.close()

    def test_post_with_duplicates(self):
        transport = MockTransport()
        transport.add_route(
            "POST", "/api/v1/events/batch", 200, {"accepted": 2, "duplicates": 1}
        )
        client = _make_client(transport)

        events = [UsageEvent(user_id="user_1") for _ in range(3)]
        result = client.post_events(events)

        assert result is not None
        assert result.accepted == 2
        assert result.duplicates == 1
        client.close()

    def test_post_empty_list(self):
        transport = MockTransport()
        client = _make_client(transport)

        result = client.post_events([])
        assert result is not None
        assert result.accepted == 0
        assert len(transport.requests) == 0  # No HTTP call made
        client.close()

    def test_post_server_error(self):
        transport = MockTransport()
        transport.add_route("POST", "/api/v1/events/batch", 500, {})
        client = _make_client(transport)

        result = client.post_events([UsageEvent(user_id="user_1")])
        assert result is None
        client.close()

    def test_post_connection_error(self):
        transport = MockTransport()
        transport.set_error(httpx.ConnectError("Connection refused"))
        client = _make_client(transport)

        result = client.post_events([UsageEvent(user_id="user_1")])
        assert result is None
        client.close()

    def test_post_timeout(self):
        transport = MockTransport()
        transport.set_error(httpx.TimeoutException("Timed out"))
        client = _make_client(transport)

        result = client.post_events([UsageEvent(user_id="user_1")])
        assert result is None
        client.close()


# ---------------------------------------------------------------------------
# Fetch Usage
# ---------------------------------------------------------------------------


class TestFetchUsage:
    def test_successful_fetch(self):
        usage_data = {
            "total_cost": 23.47,
            "tokens_by_model": {"gpt-4o": 31200},
        }
        transport = MockTransport()
        transport.add_route(
            "GET", "/api/v1/users/user_123/usage?period=current_month&breakdown=model",
            200, usage_data,
        )
        client = _make_client(transport)

        result = client.fetch_usage("user_123")
        assert result is not None
        assert result["total_cost"] == 23.47
        client.close()

    def test_fetch_usage_error(self):
        transport = MockTransport()
        transport.set_error(httpx.ConnectError("Connection refused"))
        client = _make_client(transport)

        result = client.fetch_usage("user_123")
        assert result is None
        client.close()


# ---------------------------------------------------------------------------
# Client Lifecycle
# ---------------------------------------------------------------------------


class TestClientLifecycle:
    def test_open_and_close(self):
        client = ApiClient(api_key="pg_live_test")
        assert not client.is_open

        client.open()
        assert client.is_open

        client.close()
        assert not client.is_open

    def test_double_open_is_safe(self):
        client = ApiClient(api_key="pg_live_test")
        client.open()
        client.open()  # Should not raise
        assert client.is_open
        client.close()

    def test_double_close_is_safe(self):
        client = ApiClient(api_key="pg_live_test")
        client.open()
        client.close()
        client.close()  # Should not raise
        assert not client.is_open

    def test_context_manager(self):
        with ApiClient(api_key="pg_live_test") as client:
            assert client.is_open
        assert not client.is_open

    def test_lazy_open(self):
        """Client should open lazily on first request."""
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/health", 200, {"status": "ok"})
        client = ApiClient(api_key="pg_live_test")
        # Don't manually call open() — let it auto-open
        # We can't easily test this without a real transport, but verify the method exists
        assert not client.is_open

    def test_base_url_trailing_slash_stripped(self):
        client = ApiClient(api_key="pg_live_test", base_url="https://api.example.com/")
        assert client.base_url == "https://api.example.com"


# ---------------------------------------------------------------------------
# Auth Header
# ---------------------------------------------------------------------------


class TestAuthHeader:
    def test_auth_header_sent(self):
        transport = MockTransport()
        transport.add_route("GET", "/api/v1/health", 200, {"status": "ok"})
        client = _make_client(transport)

        client.health_check()
        request = transport.requests[0]
        assert request.headers["authorization"] == "Bearer pg_live_test_123"
        client.close()


# ---------------------------------------------------------------------------
# Serialization Helpers
# ---------------------------------------------------------------------------


class TestSerializeEvent:
    def test_serialize_basic_event(self):
        event = UsageEvent(
            id="evt_123",
            user_id="user_1",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            cost_total=0.005,
        )
        data = _serialize_event(event)

        assert data["id"] == "evt_123"
        assert data["user_id"] == "user_1"
        assert data["model"] == "gpt-4o"
        assert data["input_tokens"] == 100
        assert data["output_tokens"] == 50
        assert data["total_tokens"] == 150
        assert data["cost_total"] == 0.005
        assert "timestamp" in data

    def test_serialize_preserves_all_fields(self):
        event = UsageEvent(
            user_id="user_1",
            session_id="sess_1",
            model="gpt-4o",
            tool_calls=["web_search", "code_exec"],
            cost_tokens=0.01,
            cost_tools=0.07,
            cost_total=0.08,
            metadata={"key": "value"},
        )
        data = _serialize_event(event)

        assert data["session_id"] == "sess_1"
        assert data["tool_calls"] == ["web_search", "code_exec"]
        assert data["cost_tokens"] == 0.01
        assert data["cost_tools"] == 0.07
        assert data["metadata"] == {"key": "value"}


class TestParseSessionResponse:
    def test_parse_full_response(self):
        session = _parse_session_response(SAMPLE_SESSION_RESPONSE)
        assert session is not None
        assert session.user_id == "user_123"
        assert session.plan == "pro"
        assert session.plan_config.max_spend_per_period == 49.00
        assert len(session.plan_config.model_limits) == 2
        assert len(session.plan_config.cost_rates) == 1
        assert session.current_usage.period_cost == 23.47

    def test_parse_minimal_response(self):
        session = _parse_session_response({"user_id": "user_1"})
        assert session is not None
        assert session.user_id == "user_1"
        assert session.plan == "default"
        assert session.plan_config.max_spend_per_period == float("inf")

    def test_parse_empty_dict(self):
        """Missing user_id should fail gracefully."""
        session = _parse_session_response({})
        assert session is None

    def test_parse_garbage_data(self):
        session = _parse_session_response({"user_id": "u1", "plan_config": "garbage"})
        # Should handle gracefully
        assert session is None or session.user_id == "u1"

    def test_parse_default_cost_rate(self):
        """default_cost_rate should be parsed from plan_config."""
        data = {
            **SAMPLE_SESSION_RESPONSE,
            "plan_config": {
                **SAMPLE_SESSION_RESPONSE["plan_config"],
                "default_cost_rate": {"input": 0.002, "output": 0.008},
            },
        }
        session = _parse_session_response(data)
        assert session is not None
        assert session.plan_config.default_cost_rate is not None
        assert session.plan_config.default_cost_rate.input == 0.002
        assert session.plan_config.default_cost_rate.output == 0.008

    def test_parse_default_cost_rate_missing(self):
        """default_cost_rate should be None when not in response."""
        session = _parse_session_response(SAMPLE_SESSION_RESPONSE)
        assert session is not None
        assert session.plan_config.default_cost_rate is None

    def test_parse_pre_call_estimate(self):
        """pre_call_estimate and pre_call_buffer_tokens should be parsed."""
        data = {
            **SAMPLE_SESSION_RESPONSE,
            "plan_config": {
                **SAMPLE_SESSION_RESPONSE["plan_config"],
                "pre_call_estimate": True,
                "pre_call_buffer_tokens": 1000,
            },
        }
        session = _parse_session_response(data)
        assert session is not None
        assert session.plan_config.pre_call_estimate is True
        assert session.plan_config.pre_call_buffer_tokens == 1000

    def test_parse_pre_call_estimate_defaults(self):
        """pre_call_estimate defaults to False, pre_call_buffer_tokens defaults to 500."""
        session = _parse_session_response(SAMPLE_SESSION_RESPONSE)
        assert session is not None
        assert session.plan_config.pre_call_estimate is False
        assert session.plan_config.pre_call_buffer_tokens == 500

    def test_parse_default_cost_rate_invalid_type_ignored(self):
        """Non-dict default_cost_rate should be treated as None."""
        data = {
            **SAMPLE_SESSION_RESPONSE,
            "plan_config": {
                **SAMPLE_SESSION_RESPONSE["plan_config"],
                "default_cost_rate": "invalid",
            },
        }
        session = _parse_session_response(data)
        assert session is not None
        assert session.plan_config.default_cost_rate is None


# ---------------------------------------------------------------------------
# BatchResult
# ---------------------------------------------------------------------------


class TestBatchResult:
    def test_basic(self):
        r = BatchResult(accepted=5, duplicates=2)
        assert r.accepted == 5
        assert r.duplicates == 2
        assert r.total == 7
        assert "accepted=5" in repr(r)
