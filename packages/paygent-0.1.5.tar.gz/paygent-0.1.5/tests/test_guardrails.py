"""Tests for Paygent guardrails engine — limit checking + soft gate callbacks."""

from __future__ import annotations

import pytest

from paygent.guardrails import (
    PaygentLimitExceeded,
    SoftGateCallbackRegistry,
    check_guard,
    estimate_input_tokens,
)
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserSession,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session_with_usage(
    plan_config: PlanConfig,
    period_cost: float = 0.0,
    session_cost: float = 0.0,
    period_tokens_by_model: dict | None = None,
) -> UserSession:
    """Create a session with specific usage levels for testing."""
    return UserSession(
        user_id="test_user",
        plan="test",
        plan_config=plan_config,
        current_usage=CurrentUsage(
            period_cost=period_cost,
            session_cost=session_cost,
            period_tokens_total=sum((period_tokens_by_model or {}).values()),
            period_tokens_by_model=period_tokens_by_model or {},
        ),
    )


# ---------------------------------------------------------------------------
# Total Monthly Spend
# ---------------------------------------------------------------------------


class TestMonthlySpendGuard:
    def test_ok_well_under_limit(self, pro_plan_config: PlanConfig):
        """Usage well under limit — should return ok."""
        session = _session_with_usage(pro_plan_config, period_cost=10.00)
        result = check_guard(session)
        assert result.status == "ok"

    def test_soft_gate_at_80_percent(self, pro_plan_config: PlanConfig):
        """At 80% of $49 limit — should soft gate."""
        # 80% of 49.00 = 39.20
        session = _session_with_usage(pro_plan_config, period_cost=39.20)
        result = check_guard(session)
        assert result.status == "soft_gate"
        assert result.gate_reason == "total_spend"
        assert result.usage_pct == pytest.approx(0.80, abs=0.01)

    def test_soft_gate_at_90_percent(self, pro_plan_config: PlanConfig):
        """At 90% — still soft gate (between soft and hard threshold)."""
        session = _session_with_usage(pro_plan_config, period_cost=44.10)
        result = check_guard(session)
        assert result.status == "soft_gate"
        assert result.gate_reason == "total_spend"

    def test_hard_gate_at_100_percent(self, pro_plan_config: PlanConfig):
        """At 100% of limit — should hard gate."""
        session = _session_with_usage(pro_plan_config, period_cost=49.00)
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"
        assert result.usage_pct == pytest.approx(1.0)
        assert "$49.00" in result.message

    def test_hard_gate_over_limit(self, pro_plan_config: PlanConfig):
        """Over 100% — should hard gate."""
        session = _session_with_usage(pro_plan_config, period_cost=55.00)
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"

    def test_just_under_soft_gate(self, pro_plan_config: PlanConfig):
        """Just under 80% — should be ok."""
        # 79% of 49.00 = 38.71
        session = _session_with_usage(pro_plan_config, period_cost=38.71)
        result = check_guard(session)
        assert result.status == "ok"

    def test_infinite_limit_always_ok(self):
        """Plan with no monthly spend limit — always ok."""
        config = PlanConfig()  # defaults to inf
        session = _session_with_usage(config, period_cost=999_999.00)
        result = check_guard(session)
        assert result.status == "ok"


# ---------------------------------------------------------------------------
# Session Spend
# ---------------------------------------------------------------------------


class TestSessionSpendGuard:
    def test_ok_under_session_limit(self, pro_plan_config: PlanConfig):
        session = _session_with_usage(pro_plan_config, session_cost=1.00)
        result = check_guard(session)
        assert result.status == "ok"

    def test_session_soft_gate(self, pro_plan_config: PlanConfig):
        """Session cost at 80% of $5 limit = $4.00."""
        session = _session_with_usage(pro_plan_config, session_cost=4.00)
        result = check_guard(session)
        assert result.status == "soft_gate"
        assert result.gate_reason == "session_spend"

    def test_session_hard_gate(self, pro_plan_config: PlanConfig):
        """Session cost at 100% of $5 limit."""
        session = _session_with_usage(pro_plan_config, session_cost=5.00)
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "session_spend"

    def test_infinite_session_limit_always_ok(self):
        """No session limit — always ok."""
        config = PlanConfig(max_spend_per_period=100.0)  # session is inf
        session = _session_with_usage(config, session_cost=999.00)
        result = check_guard(session)
        assert result.status == "ok"


# ---------------------------------------------------------------------------
# Monthly Spend Takes Priority Over Session Spend
# ---------------------------------------------------------------------------


class TestGuardPriority:
    def test_monthly_hard_gate_beats_session_soft_gate(self, pro_plan_config: PlanConfig):
        """Monthly hard gate wins when it's the most restrictive."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=49.00,  # hard gate (100%)
            session_cost=4.00,  # would be soft gate (80%)
        )
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"

    def test_monthly_soft_gate_beats_session_ok(self, pro_plan_config: PlanConfig):
        """Monthly soft gate fires even when session is fine."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=40.00,  # soft gate (~82%)
            session_cost=1.00,  # ok
        )
        result = check_guard(session)
        assert result.status == "soft_gate"
        assert result.gate_reason == "total_spend"

    # -----------------------------------------------------------------------
    # "Most restrictive violation wins" regression guards.
    #
    # Before the fix, check_guard returned the FIRST violation it encountered
    # in code order (period → session → model).  That meant a period soft_gate
    # could mask a session hard_gate — the call proceeded instead of being
    # blocked.  These tests pin down the new semantics:
    #   hard > soft > ok; within same severity, higher usage_pct wins.
    # -----------------------------------------------------------------------

    def test_session_hard_gate_beats_period_soft_gate(self, pro_plan_config: PlanConfig):
        """Regression: period soft MUST NOT mask a session hard.

        Period at 82% (soft) and session at 100% (hard) → session hard_gate
        returned, not period soft_gate.
        """
        session = _session_with_usage(
            pro_plan_config,
            period_cost=40.00,   # 82% of $49 → soft_gate
            session_cost=5.00,   # 100% of $5 → hard_gate
        )
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "session_spend"

    def test_model_hard_gate_beats_period_soft_gate(self, pro_plan_config: PlanConfig):
        """Period soft MUST NOT mask a model-token hard."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=40.00,                       # 82% → soft_gate
            period_tokens_by_model={"gpt-4o": 50_000},  # 100% → hard_gate
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"

    def test_model_hard_gate_beats_session_soft_gate(self, pro_plan_config: PlanConfig):
        """Session soft MUST NOT mask a model-token hard."""
        session = _session_with_usage(
            pro_plan_config,
            session_cost=4.00,                       # 80% → soft_gate
            period_tokens_by_model={"gpt-4o": 55_000},  # 110% → hard_gate
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"

    def test_all_three_soft_gates_returns_highest_pct(self, pro_plan_config: PlanConfig):
        """All three dims in soft_gate zone → the one closest to its cap wins."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=40.00,                       # 40/49 ≈ 81.6%
            session_cost=4.50,                       # 4.50/5 = 90%
            period_tokens_by_model={"gpt-4o": 42_500},  # 42.5k/50k = 85%
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "soft_gate"
        # session_spend at 90% is the tightest — should be reported
        assert result.gate_reason == "session_spend"
        assert result.usage_pct == pytest.approx(0.90, abs=0.01)

    def test_all_three_hard_gates_returns_highest_pct(self, pro_plan_config: PlanConfig):
        """All three hit hard_gate → the one MOST over its cap wins.

        This is a stability property: the reported violation reflects the
        worst constraint, which is the most actionable information for the
        developer's error message / callback.
        """
        session = _session_with_usage(
            pro_plan_config,
            period_cost=50.00,                       # 50/49 ≈ 102%
            session_cost=7.50,                       # 7.50/5 = 150%
            period_tokens_by_model={"gpt-4o": 60_000},  # 60k/50k = 120%
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        # session_spend at 150% is the worst overage
        assert result.gate_reason == "session_spend"
        assert result.usage_pct == pytest.approx(1.50, abs=0.01)

    def test_single_violation_still_returned(self, pro_plan_config: PlanConfig):
        """Sanity: when only one dim violates, it's still returned correctly."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=40.00,  # 82% → soft
        )
        result = check_guard(session)
        assert result.status == "soft_gate"
        assert result.gate_reason == "total_spend"


# ---------------------------------------------------------------------------
# Model-Level Token Limits
# ---------------------------------------------------------------------------


class TestModelLimitGuard:
    def test_ok_under_model_limit(self, pro_plan_config: PlanConfig):
        """GPT-4o at 20K of 50K limit — ok."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"gpt-4o": 20_000},
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "ok"

    def test_model_soft_gate(self, pro_plan_config: PlanConfig):
        """GPT-4o at 80% of 50K = 40K tokens."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"gpt-4o": 40_000},
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "soft_gate"
        assert result.gate_reason == "model_limit:gpt-4o"
        assert result.current_value == 40_000
        assert result.limit_value == 50_000

    def test_model_hard_gate(self, pro_plan_config: PlanConfig):
        """GPT-4o at 100% of 50K limit."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"gpt-4o": 50_000},
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"
        assert "50,000" in result.message

    def test_model_over_limit(self, pro_plan_config: PlanConfig):
        """GPT-4o over limit — hard gate."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"gpt-4o": 55_000},
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"

    def test_different_models_independent(self, pro_plan_config: PlanConfig):
        """GPT-4o over limit, but Claude under limit — depends on model queried."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={
                "gpt-4o": 50_000,
                "claude-sonnet-4-20250514": 10_000,
            },
        )
        # GPT-4o should hard gate
        result_gpt = check_guard(session, model="gpt-4o")
        assert result_gpt.status == "hard_gate"
        assert result_gpt.gate_reason == "model_limit:gpt-4o"

        # Claude should be ok
        result_claude = check_guard(session, model="claude-sonnet-4-20250514")
        assert result_claude.status == "ok"

    def test_model_with_no_limit_config(self, pro_plan_config: PlanConfig):
        """Model not in model_limits — no model-level check, ok."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"llama-3-70b": 999_999},
        )
        result = check_guard(session, model="llama-3-70b")
        assert result.status == "ok"

    def test_no_model_skips_model_check(self, pro_plan_config: PlanConfig):
        """No model provided — skips model-level check."""
        session = _session_with_usage(
            pro_plan_config,
            period_tokens_by_model={"gpt-4o": 50_000},  # would hard gate if model checked
        )
        result = check_guard(session, model=None)
        assert result.status == "ok"

    def test_model_unlimited_tokens(self):
        """Model with max_tokens_per_period=None means unlimited."""
        config = PlanConfig(
            max_spend_per_period=100.0,
            model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=None)},
        )
        session = _session_with_usage(
            config, period_tokens_by_model={"gpt-4o": 999_999}
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "ok"

    def test_monthly_spend_gates_before_model_check(self, pro_plan_config: PlanConfig):
        """Monthly spend hard gate fires before model-level check."""
        session = _session_with_usage(
            pro_plan_config,
            period_cost=49.00,  # hard gate
            period_tokens_by_model={"gpt-4o": 20_000},  # would be ok
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"


# ---------------------------------------------------------------------------
# Free Plan (tighter limits)
# ---------------------------------------------------------------------------


class TestFreePlanGuard:
    def test_free_plan_hard_gate(self, free_plan_config: PlanConfig):
        """Free plan: $5/month hard gate."""
        session = _session_with_usage(free_plan_config, period_cost=5.00)
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"

    def test_free_plan_session_hard_gate(self, free_plan_config: PlanConfig):
        """Free plan: $0.50/session hard gate."""
        session = _session_with_usage(free_plan_config, session_cost=0.50)
        result = check_guard(session)
        assert result.status == "hard_gate"
        assert result.gate_reason == "session_spend"

    def test_free_plan_model_limit(self, free_plan_config: PlanConfig):
        """Free plan: 10K GPT-4o tokens."""
        session = _session_with_usage(
            free_plan_config,
            period_tokens_by_model={"gpt-4o": 10_000},
        )
        result = check_guard(session, model="gpt-4o")
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"


# ---------------------------------------------------------------------------
# Fail-Open
# ---------------------------------------------------------------------------


class TestGuardFailOpen:
    def test_none_session_returns_ok(self):
        """Broken/None session — fail-open."""
        result = check_guard(None, model="gpt-4o")  # type: ignore
        assert result.status == "ok"

    def test_missing_plan_config_returns_ok(self):
        """Session with broken internals — fail-open."""

        class BrokenSession:
            plan_config = None
            current_usage = None

        result = check_guard(BrokenSession(), model="gpt-4o")  # type: ignore
        assert result.status == "ok"


# ---------------------------------------------------------------------------
# PaygentLimitExceeded Exception
# ---------------------------------------------------------------------------


class TestPaygentLimitExceeded:
    def test_exception_carries_guard_result(self):
        from paygent.models import GuardResult

        result = GuardResult(
            status="hard_gate",
            gate_reason="total_spend",
            message="Spend limit reached",
        )
        exc = PaygentLimitExceeded(result)
        assert exc.guard_result is result
        assert str(exc) == "Spend limit reached"

    def test_exception_default_message(self):
        from paygent.models import GuardResult

        result = GuardResult(status="hard_gate")
        exc = PaygentLimitExceeded(result)
        assert str(exc) == "Usage limit exceeded"

    def test_exception_is_catchable(self):
        from paygent.models import GuardResult

        result = GuardResult(status="hard_gate", message="Limit hit")
        with pytest.raises(PaygentLimitExceeded) as exc_info:
            raise PaygentLimitExceeded(result)
        assert exc_info.value.guard_result.status == "hard_gate"


# ---------------------------------------------------------------------------
# Soft Gate Callback Registry
# ---------------------------------------------------------------------------


class TestSoftGateCallbackRegistry:
    def test_register_and_fire(self):
        from paygent.models import GuardResult

        registry = SoftGateCallbackRegistry()
        captured = []
        registry.register(lambda r: captured.append(r))

        result = GuardResult(status="soft_gate", gate_reason="total_spend")
        registry.fire(result)

        assert len(captured) == 1
        assert captured[0].gate_reason == "total_spend"

    def test_multiple_callbacks(self):
        from paygent.models import GuardResult

        registry = SoftGateCallbackRegistry()
        calls = {"a": 0, "b": 0}
        registry.register(lambda r: calls.update(a=calls["a"] + 1))
        registry.register(lambda r: calls.update(b=calls["b"] + 1))

        registry.fire(GuardResult(status="soft_gate"))
        assert calls["a"] == 1
        assert calls["b"] == 1

    def test_callback_error_swallowed(self):
        """A failing callback should not prevent other callbacks from firing."""
        from paygent.models import GuardResult

        registry = SoftGateCallbackRegistry()
        calls = []

        def bad_callback(r):
            raise RuntimeError("boom")

        registry.register(bad_callback)
        registry.register(lambda r: calls.append("ok"))

        # Should not raise
        registry.fire(GuardResult(status="soft_gate"))
        assert calls == ["ok"]

    def test_clear(self):
        registry = SoftGateCallbackRegistry()
        registry.register(lambda r: None)
        assert registry.count == 1
        registry.clear()
        assert registry.count == 0

    def test_empty_fire(self):
        """Firing with no callbacks should not raise."""
        from paygent.models import GuardResult

        registry = SoftGateCallbackRegistry()
        registry.fire(GuardResult(status="soft_gate"))  # no-op


# ---------------------------------------------------------------------------
# Pre-Call Token Estimation
# ---------------------------------------------------------------------------


class TestEstimateInputTokens:
    def test_dict_messages(self):
        msgs = [
            {"role": "system", "content": "You are helpful."},  # 15 chars
            {"role": "user", "content": "Hello world"},          # 11 chars
        ]
        # (15 + 11) / 4 = 6
        tokens = estimate_input_tokens(msgs)
        assert tokens == 6

    def test_empty_messages(self):
        assert estimate_input_tokens([]) == 0
        assert estimate_input_tokens(None) == 0

    def test_multipart_content(self):
        msgs = [
            {"role": "user", "content": [
                {"type": "text", "text": "Describe this image"},
            ]},
        ]
        tokens = estimate_input_tokens(msgs)
        assert tokens > 0

    def test_object_messages(self):
        class Msg:
            content = "Hello world test message"
        tokens = estimate_input_tokens([Msg()])
        assert tokens == len("Hello world test message") // 4


class TestPreCallEstimation:
    """Tests for the pre_call_estimate feature.

    When enabled, the guard check projects the cost/tokens of the upcoming
    call and checks (current + estimated) against limits.
    """

    def _estimation_config(self, **kwargs) -> PlanConfig:
        """Create a plan config with pre_call_estimate enabled."""
        defaults = dict(
            max_spend_per_period=10.00,
            max_spend_per_session=2.00,
            soft_gate_at=0.80,
            hard_gate_at=1.00,
            pre_call_estimate=True,
            pre_call_buffer_tokens=500,
            cost_rates={
                "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
            },
            model_limits={
                "gpt-4o": ModelLimitConfig(max_tokens_per_period=10_000),
            },
        )
        defaults.update(kwargs)
        return PlanConfig(**defaults)

    def test_estimation_off_no_projection(self):
        """With pre_call_estimate=False, 95% usage is just a soft gate."""
        config = PlanConfig(
            max_spend_per_period=10.00,
            pre_call_estimate=False,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        session = _session_with_usage(config, period_cost=9.50)  # 95%
        result = check_guard(session, model="gpt-4o")
        assert result.status == "soft_gate"

    def test_estimation_on_projects_cost_to_hard_gate(self):
        """With estimation on, 95% + estimated call cost → hard gate."""
        config = self._estimation_config()
        session = _session_with_usage(config, period_cost=9.50)  # 95%
        # Estimated: 1000 input tokens + 500 buffer output tokens
        # Cost: (1000/1000)*0.0025 + (500/1000)*0.01 = 0.0025 + 0.005 = 0.0075
        # Projected: 9.50 + 0.0075 = 9.5075 → 95.08% → still soft gate
        # Let's push it higher
        session2 = _session_with_usage(config, period_cost=9.99)  # 99.9%
        # Projected: 9.99 + 0.0075 = 9.9975 → 99.975% → still soft gate (< 100%)
        # Actually, any non-zero estimation will push 99.9% + cost over hard_gate
        # Let's use bigger input: 4000 chars = 1000 tokens
        result = check_guard(
            session2,
            model="gpt-4o",
            estimated_input_tokens=1000,
            max_tokens=500,
        )
        # 9.99 + (1000/1000*0.0025 + 500/1000*0.01) = 9.99 + 0.0075 = 9.9975
        # 9.9975 / 10.00 = 0.99975 < 1.0 → soft gate not hard gate
        assert result.status == "soft_gate"

    def test_estimation_pushes_over_hard_gate(self):
        """Estimation can push usage from soft gate to hard gate.

        Isolates the period-cost dimension by removing the per-model token
        limit — otherwise the huge estimated token count also trips the
        model limit, and under the "most restrictive wins" guard semantics
        the model-limit violation (bigger overage) wins instead of total_spend.
        This test is specifically about estimation projecting the COST limit.
        """
        config = self._estimation_config(model_limits={})
        session = _session_with_usage(config, period_cost=9.95)  # 99.5%
        # Large call: 10000 input tokens + 2000 output
        # Cost: (10000/1000)*0.0025 + (2000/1000)*0.01 = 0.025 + 0.02 = 0.045
        # Projected: 9.95 + 0.045 = 9.995 → 99.95% → still soft gate
        # Need bigger: 20000 input + 5000 output
        # Cost: 0.05 + 0.05 = 0.10
        # Projected: 9.95 + 0.10 = 10.05 → 100.5% → hard gate!
        result = check_guard(
            session,
            model="gpt-4o",
            estimated_input_tokens=20000,
            max_tokens=5000,
        )
        assert result.status == "hard_gate"
        assert result.gate_reason == "total_spend"

    def test_estimation_model_token_limit(self):
        """Estimation projects tokens for model-level limit check."""
        config = self._estimation_config()
        # 9500 tokens used out of 10000 limit = 95% → soft gate without estimation
        session = _session_with_usage(
            config,
            period_tokens_by_model={"gpt-4o": 9500},
        )
        # Without estimation (pre_call_estimate=False) this would be soft gate
        # With estimation: 9500 + 1000 input + 500 buffer = 11000 → 110% → hard gate
        result = check_guard(
            session,
            model="gpt-4o",
            estimated_input_tokens=1000,
            max_tokens=500,
        )
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"

    def test_estimation_uses_buffer_when_no_max_tokens(self):
        """When max_tokens not provided, uses pre_call_buffer_tokens for output estimate."""
        config = self._estimation_config(pre_call_buffer_tokens=1000)
        session = _session_with_usage(
            config,
            period_tokens_by_model={"gpt-4o": 9000},  # 90%
        )
        # With buffer=1000: 9000 + 0 input + 1000 buffer = 10000 → 100% → hard gate
        result = check_guard(
            session,
            model="gpt-4o",
            estimated_input_tokens=0,
            max_tokens=None,
        )
        assert result.status == "hard_gate"
        assert result.gate_reason == "model_limit:gpt-4o"

    def test_estimation_session_spend(self):
        """Estimation works for session spend limits too.

        Isolates the session-cost dimension — see note on
        test_estimation_pushes_over_hard_gate for why model_limits is
        cleared here.
        """
        config = self._estimation_config(max_spend_per_session=0.10, model_limits={})
        session = _session_with_usage(config, session_cost=0.09)  # 90%
        # Big call: 20000 input + 5000 output
        # Cost: 0.05 + 0.05 = 0.10
        # Projected session: 0.09 + 0.10 = 0.19 → 190% → hard gate
        result = check_guard(
            session,
            model="gpt-4o",
            estimated_input_tokens=20000,
            max_tokens=5000,
        )
        assert result.status == "hard_gate"
        assert result.gate_reason == "session_spend"

    def test_estimation_no_cost_rate_zero_cost(self):
        """Model without cost rate → estimated cost is 0, only token check applies."""
        config = self._estimation_config()
        session = _session_with_usage(config, period_cost=7.50)  # 75%
        # Model "llama" has no cost rate, so estimated cost = 0
        result = check_guard(
            session,
            model="llama",
            estimated_input_tokens=5000,
            max_tokens=2000,
        )
        assert result.status == "ok"

    def test_estimation_disabled_by_default(self):
        """Default PlanConfig has pre_call_estimate=False and uses a
        worst-case output assumption of 4096 tokens when ``max_tokens``
        is missing (bumped from the original 500, which was too small to
        catch realistic unbounded completions)."""
        config = PlanConfig()
        assert config.pre_call_estimate is False
        assert config.pre_call_buffer_tokens == 4096


# ---------------------------------------------------------------------------
# Session Timeout (Clock-Based Window Expiry)
# ---------------------------------------------------------------------------


class TestSessionTimeout:
    """Tests for clock-based session window expiry.

    Sessions have a fixed duration from ``session_started_at``. When the
    elapsed time exceeds ``session_timeout_minutes``, ``session_cost``
    resets to zero and ``session_id`` rotates to a new UUID.
    """

    def test_session_cost_resets_after_timeout(self):
        """Guard check should reset session_cost when clock window expires."""
        from datetime import datetime, timedelta

        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=30.0,
        )
        session = _session_with_usage(config, session_cost=4.50)
        # Session started 31 minutes ago — window has expired
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=31)
        session.current_usage.session_id = "old-session-id"

        result = check_guard(session)
        assert result.status == "ok"
        assert session.current_usage.session_cost == 0.0
        # session_id should have rotated
        assert session.current_usage.session_id != "old-session-id"

    def test_session_cost_preserved_within_timeout(self):
        """Guard check should NOT reset session_cost if still within window."""
        from datetime import datetime, timedelta

        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=30.0,
        )
        session = _session_with_usage(config, session_cost=4.50)
        # Session started 10 minutes ago — still within window
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=10)
        session.current_usage.session_id = "keep-this-id"

        result = check_guard(session)
        assert result.status == "soft_gate"  # 4.50/5.00 = 90% >= 80%
        assert session.current_usage.session_cost == 4.50
        assert session.current_usage.session_id == "keep-this-id"

    def test_session_cost_hard_gate_resets_after_timeout(self):
        """A user who was hard-gated should be OK after window expires."""
        from datetime import datetime, timedelta

        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=30.0,
        )
        session = _session_with_usage(config, session_cost=5.00)  # 100% → hard gate
        # First check — still within window
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=5)
        session.current_usage.session_id = "original-id"
        result = check_guard(session)
        assert result.status == "hard_gate"

        # Simulate window expiry
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=35)
        result = check_guard(session)
        assert result.status == "ok"
        assert session.current_usage.session_cost == 0.0
        assert session.current_usage.session_id != "original-id"

    def test_no_session_started_at_opens_window(self):
        """If session_started_at is None, first guard check opens a new window."""
        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=30.0,
        )
        session = _session_with_usage(config, session_cost=4.50)
        assert session.current_usage.session_started_at is None

        result = check_guard(session)
        # Window just opened — no reset, cost preserved
        assert result.status == "soft_gate"  # Normal check, no reset
        assert session.current_usage.session_cost == 4.50
        # session_started_at should now be set
        assert session.current_usage.session_started_at is not None

    def test_session_id_assigned_on_first_call(self):
        """If session_id is None, first guard check assigns one."""
        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=30.0,
        )
        session = _session_with_usage(config, session_cost=0.0)
        assert session.current_usage.session_id is None
        assert session.current_usage.session_started_at is None

        check_guard(session)
        assert session.current_usage.session_id is not None
        assert session.current_usage.session_started_at is not None

    def test_infinite_timeout_never_expires(self):
        """session_timeout_minutes=inf means session window never expires."""
        from datetime import datetime, timedelta

        config = PlanConfig(
            max_spend_per_session=5.00,
            session_timeout_minutes=float("inf"),
        )
        session = _session_with_usage(config, session_cost=4.50)
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(hours=24)
        session.current_usage.session_id = "forever-id"

        result = check_guard(session)
        assert result.status == "soft_gate"
        assert session.current_usage.session_cost == 4.50
        assert session.current_usage.session_id == "forever-id"

    def test_default_timeout_is_30_minutes(self):
        """Default session timeout should be 30 minutes."""
        config = PlanConfig()
        assert config.session_timeout_minutes == 30.0

    def test_metering_initializes_session_window(self):
        """update_cache() should initialize session_started_at and session_id."""
        from datetime import datetime
        from paygent.metering import update_cache
        from paygent.models import UsageEvent

        config = PlanConfig()
        session = _session_with_usage(config, session_cost=0.0)
        assert session.current_usage.session_started_at is None
        assert session.current_usage.session_id is None

        event = UsageEvent(
            user_id="test_user",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            cost_total=0.01,
        )
        before = datetime.utcnow()
        update_cache(session, event)
        after = datetime.utcnow()

        assert session.current_usage.session_started_at is not None
        assert before <= session.current_usage.session_started_at <= after
        assert session.current_usage.session_id is not None

    def test_metering_resets_session_cost_on_timeout(self):
        """update_cache() should reset session_cost if window expired, then add new cost."""
        from datetime import datetime, timedelta
        from paygent.metering import update_cache
        from paygent.models import UsageEvent

        config = PlanConfig(session_timeout_minutes=30.0)
        session = _session_with_usage(config, session_cost=3.00)
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=45)
        old_session_id = "old-metering-id"
        session.current_usage.session_id = old_session_id

        event = UsageEvent(
            user_id="test_user",
            model="gpt-4o",
            cost_total=0.05,
            total_tokens=100,
        )
        update_cache(session, event)

        # session_cost should be reset to 0 then +0.05
        assert session.current_usage.session_cost == 0.05
        # period_cost still accumulates (no reset)
        assert session.current_usage.period_cost == 0.05
        # session_id should have rotated
        assert session.current_usage.session_id != old_session_id

    def test_session_id_rotates_on_window_expiry(self):
        """Each new session window should get a unique session_id."""
        from datetime import datetime, timedelta
        from paygent.metering import update_cache
        from paygent.models import UsageEvent

        config = PlanConfig(session_timeout_minutes=30.0)
        session = _session_with_usage(config, session_cost=1.00)
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=31)
        session.current_usage.session_id = "window-1"

        event = UsageEvent(
            user_id="test_user",
            model="gpt-4o",
            cost_total=0.05,
            total_tokens=100,
        )
        update_cache(session, event)

        window_2_id = session.current_usage.session_id
        assert window_2_id != "window-1"

        # Expire again
        session.current_usage.session_started_at = datetime.utcnow() - timedelta(minutes=31)
        update_cache(session, event)

        window_3_id = session.current_usage.session_id
        assert window_3_id != window_2_id
