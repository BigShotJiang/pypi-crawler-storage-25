"""Tests for Paygent Pydantic data models."""

import json
from datetime import datetime

import pytest

from paygent.models import (
    CurrentUsage,
    GuardResult,
    ModelCostRate,
    ModelLimitConfig,
    ModelUsage,
    PlanConfig,
    UsageEvent,
    UserSession,
)


# ---------------------------------------------------------------------------
# UsageEvent
# ---------------------------------------------------------------------------


class TestUsageEvent:
    def test_defaults(self):
        """UsageEvent should auto-generate id and timestamp."""
        event = UsageEvent(user_id="user_1")
        assert event.id  # UUID string, not empty
        assert event.user_id == "user_1"
        assert isinstance(event.timestamp, datetime)
        assert event.input_tokens == 0
        assert event.output_tokens == 0
        assert event.total_tokens == 0
        assert event.cost_total == 0.0
        assert event.synced is False
        assert event.tool_calls == []
        assert event.metadata == {}

    def test_unique_ids(self):
        """Each event should get a unique id."""
        e1 = UsageEvent(user_id="u1")
        e2 = UsageEvent(user_id="u1")
        assert e1.id != e2.id

    def test_full_event(self):
        """UsageEvent with all fields populated."""
        event = UsageEvent(
            id="evt_custom",
            user_id="user_123",
            session_id="sess_abc",
            model="gpt-4o",
            input_tokens=1200,
            output_tokens=340,
            total_tokens=1540,
            tool_calls=["web_search", "code_exec"],
            cost_tokens=0.0064,
            cost_tools=0.15,
            cost_total=0.1564,
            metadata={"agent": "research_agent"},
            synced=True,
        )
        assert event.id == "evt_custom"
        assert event.model == "gpt-4o"
        assert event.total_tokens == 1540
        assert event.tool_calls == ["web_search", "code_exec"]
        assert event.cost_total == pytest.approx(0.1564)

    def test_serialization_roundtrip(self):
        """UsageEvent should survive JSON serialization."""
        event = UsageEvent(user_id="u1", model="gpt-4o", input_tokens=100)
        data = json.loads(event.model_dump_json())
        restored = UsageEvent(**data)
        assert restored.user_id == event.user_id
        assert restored.id == event.id


# ---------------------------------------------------------------------------
# GuardResult
# ---------------------------------------------------------------------------


class TestGuardResult:
    def test_default_ok(self):
        """Default GuardResult should be 'ok'."""
        result = GuardResult()
        assert result.status == "ok"
        assert result.gate_reason is None
        assert result.message is None

    def test_soft_gate(self):
        result = GuardResult(
            status="soft_gate",
            gate_reason="total_spend",
            usage_pct=0.85,
            current_value=42.50,
            limit_value=50.00,
            message="Approaching spend limit: 85% used",
        )
        assert result.status == "soft_gate"
        assert result.gate_reason == "total_spend"
        assert result.usage_pct == pytest.approx(0.85)

    def test_hard_gate_model_limit(self):
        result = GuardResult(
            status="hard_gate",
            gate_reason="model_limit:gpt-4o",
            usage_pct=1.02,
            current_value=51000,
            limit_value=50000,
            message="gpt-4o token limit reached",
        )
        assert result.status == "hard_gate"
        assert "gpt-4o" in result.gate_reason

    def test_invalid_status_rejected(self):
        """Invalid status values should be rejected by Pydantic."""
        with pytest.raises(Exception):
            GuardResult(status="invalid")


# ---------------------------------------------------------------------------
# ModelUsage
# ---------------------------------------------------------------------------


class TestModelUsage:
    def test_basic(self):
        usage = ModelUsage(model="gpt-4o", tokens_used=31200, tokens_limit=50000, cost=3.12)
        assert usage.model == "gpt-4o"
        assert usage.tokens_used == 31200
        assert usage.tokens_limit == 50000

    def test_unlimited(self):
        usage = ModelUsage(model="gpt-4o-mini")
        assert usage.tokens_limit is None
        assert usage.tokens_used == 0


# ---------------------------------------------------------------------------
# PlanConfig
# ---------------------------------------------------------------------------


class TestPlanConfig:
    def test_defaults_are_unlimited(self):
        """Default plan has no limits (inf spend, no model limits)."""
        config = PlanConfig()
        assert config.max_spend_per_period == float("inf")
        assert config.max_spend_per_session == float("inf")
        assert config.soft_gate_at == 0.80
        assert config.hard_gate_at == 1.00
        assert config.model_limits == {}
        assert config.cost_rates == {}

    def test_pro_plan(self, pro_plan_config: PlanConfig):
        """Pro plan fixture should have model limits and cost rates."""
        assert pro_plan_config.max_spend_per_period == 49.00
        assert "gpt-4o" in pro_plan_config.model_limits
        assert pro_plan_config.model_limits["gpt-4o"].max_tokens_per_period == 50_000
        assert "gpt-4o" in pro_plan_config.cost_rates
        assert pro_plan_config.cost_rates["gpt-4o"].input == 0.0025

    def test_tool_costs(self, pro_plan_config: PlanConfig):
        assert pro_plan_config.tool_costs["web_search"] == 0.05
        assert pro_plan_config.default_tool_cost == 0.02


# ---------------------------------------------------------------------------
# ModelLimitConfig & ModelCostRate
# ---------------------------------------------------------------------------


class TestModelLimitConfig:
    def test_unlimited_by_default(self):
        config = ModelLimitConfig()
        assert config.max_tokens_per_period is None

    def test_with_limit(self):
        config = ModelLimitConfig(max_tokens_per_period=50_000)
        assert config.max_tokens_per_period == 50_000


class TestModelCostRate:
    def test_cost_rate(self):
        rate = ModelCostRate(input=0.0025, output=0.01)
        assert rate.input == 0.0025
        assert rate.output == 0.01


# ---------------------------------------------------------------------------
# CurrentUsage
# ---------------------------------------------------------------------------


class TestCurrentUsage:
    def test_defaults_are_zero(self):
        usage = CurrentUsage()
        assert usage.period_cost == 0.0
        assert usage.session_cost == 0.0
        assert usage.period_tokens_total == 0
        assert usage.period_tokens_by_model == {}
        assert usage.period_cost_by_model == {}

    def test_mutable_update(self):
        """CurrentUsage dicts should be mutable for in-memory cache updates."""
        usage = CurrentUsage()
        usage.period_cost += 5.00
        usage.period_tokens_by_model["gpt-4o"] = 1000
        assert usage.period_cost == 5.00
        assert usage.period_tokens_by_model["gpt-4o"] == 1000


# ---------------------------------------------------------------------------
# UserSession
# ---------------------------------------------------------------------------


class TestUserSession:
    def test_construction(self, pro_session: UserSession):
        assert pro_session.user_id == "user_123"
        assert pro_session.plan == "pro"
        assert pro_session.plan_config.max_spend_per_period == 49.00
        assert pro_session.current_usage.period_cost == 0.0

    def test_session_with_existing_usage(self, pro_plan_config: PlanConfig):
        """Session bootstrap should accept pre-existing usage from backend."""
        usage = CurrentUsage(
            period_cost=23.47,
            period_tokens_total=51700,
            period_tokens_by_model={
                "gpt-4o": 31200,
                "claude-sonnet-4-20250514": 8400,
                "gpt-4o-mini": 12100,
            },
            period_cost_by_model={
                "gpt-4o": 15.60,
                "claude-sonnet-4-20250514": 5.04,
                "gpt-4o-mini": 2.83,
            },
        )
        session = UserSession(
            user_id="user_123",
            plan="pro",
            plan_config=pro_plan_config,
            current_usage=usage,
        )
        assert session.current_usage.period_cost == 23.47
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 31200

    def test_serialization_roundtrip(self, pro_session: UserSession):
        """UserSession should survive JSON roundtrip (for backend API responses)."""
        data = json.loads(pro_session.model_dump_json())
        restored = UserSession(**data)
        assert restored.user_id == pro_session.user_id
        assert restored.plan == pro_session.plan
        assert restored.plan_config.max_spend_per_period == pro_session.plan_config.max_spend_per_period
