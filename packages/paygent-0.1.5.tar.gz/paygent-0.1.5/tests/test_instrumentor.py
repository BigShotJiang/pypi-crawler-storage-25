"""Tests for Paygent instrumentor — orchestrates patching across providers."""

from __future__ import annotations

import sys
from types import ModuleType, SimpleNamespace
from typing import Any

import pytest

from paygent.context import paygent_context
from paygent.instrumentor import Instrumentor
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserSession,
)
from paygent.providers import (
    ProviderConfig,
    ProviderRegistry,
    TokenInfo,
    extract_openai_tokens,
)


# ---------------------------------------------------------------------------
# Helpers — Fake LLM module for testing
# ---------------------------------------------------------------------------


def _make_fake_openai_module():
    """Create a fake openai module tree that can be monkey-patched."""
    # Simulate: openai.resources.chat.completions.Completions.create
    class Completions:
        @staticmethod
        def create(**kwargs):
            return SimpleNamespace(
                model=kwargs.get("model", "gpt-4o"),
                usage=SimpleNamespace(
                    prompt_tokens=100,
                    completion_tokens=50,
                    total_tokens=150,
                ),
                choices=[SimpleNamespace(message=SimpleNamespace(content="Hi"))],
            )

    class AsyncCompletions:
        @staticmethod
        async def create(**kwargs):
            return SimpleNamespace(
                model=kwargs.get("model", "gpt-4o"),
                usage=SimpleNamespace(
                    prompt_tokens=100,
                    completion_tokens=50,
                    total_tokens=150,
                ),
                choices=[SimpleNamespace(message=SimpleNamespace(content="Hi"))],
            )

    # Build module hierarchy
    completions_mod = ModuleType("openai.resources.chat.completions")
    completions_mod.Completions = Completions
    completions_mod.AsyncCompletions = AsyncCompletions

    return completions_mod, Completions, AsyncCompletions


def _make_session(user_id="user_1", period_cost=0.0):
    return UserSession(
        user_id=user_id,
        plan="pro",
        plan_config=PlanConfig(
            max_spend_per_period=49.00,
            max_spend_per_session=5.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000)},
        ),
        current_usage=CurrentUsage(period_cost=period_cost),
    )


@pytest.fixture
def fake_openai():
    """Install a fake openai module and clean up after."""
    mod, sync_cls, async_cls = _make_fake_openai_module()
    module_key = "openai.resources.chat.completions"
    sys.modules[module_key] = mod
    yield mod, sync_cls, async_cls
    # Cleanup
    sys.modules.pop(module_key, None)


@pytest.fixture
def openai_provider():
    return ProviderConfig(
        name="openai",
        module_path="openai.resources.chat.completions",
        class_name="Completions",
        method_name="create",
        async_module_path="openai.resources.chat.completions",
        async_class_name="AsyncCompletions",
        async_method_name="create",
        extract_tokens=extract_openai_tokens,
    )


@pytest.fixture
def registry(openai_provider):
    reg = ProviderRegistry()
    reg.register(openai_provider)
    return reg


# ---------------------------------------------------------------------------
# Instrumentor basics
# ---------------------------------------------------------------------------


class TestInstrumentorBasics:
    def test_initial_state(self, registry):
        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )
        assert not inst.is_instrumented
        assert inst.patched_count == 0

    def test_instrument_with_no_providers_installed(self):
        """If no provider SDKs are installed, instrument succeeds with no patches."""
        reg = ProviderRegistry()
        reg.register(ProviderConfig(
            name="nonexistent",
            module_path="nonexistent.module.path",
            class_name="Client",
            method_name="call",
        ))

        inst = Instrumentor(
            registry=reg,
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )
        applied = inst.instrument()
        assert applied == []
        assert inst.patched_count == 0

    def test_instrument_patches_installed_provider(self, registry, fake_openai):
        """Should patch the fake openai module."""
        _, sync_cls, _ = fake_openai
        original_create = sync_cls.create

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )
        applied = inst.instrument()

        assert len(applied) >= 1  # at least sync patched
        assert inst.is_instrumented
        assert inst.patched_count >= 1
        # The create method should now be wrapped
        assert sync_cls.create is not original_create
        assert getattr(sync_cls.create, "_paygent_patched", False) is True

        # Cleanup
        inst.uninstrument()

    def test_uninstrument_restores_originals(self, registry, fake_openai):
        """Uninstrument should restore the original methods."""
        _, sync_cls, async_cls = fake_openai
        original_sync = sync_cls.create
        original_async = async_cls.create

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )
        inst.instrument()
        assert sync_cls.create is not original_sync

        count = inst.uninstrument()
        assert count >= 1
        assert not inst.is_instrumented
        assert sync_cls.create is original_sync
        assert async_cls.create is original_async

    def test_double_instrument_is_idempotent(self, registry, fake_openai):
        """Calling instrument() twice should not double-patch."""
        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )
        applied1 = inst.instrument()
        applied2 = inst.instrument()

        assert len(applied1) >= 1
        assert applied2 == []  # Already patched

        inst.uninstrument()


# ---------------------------------------------------------------------------
# End-to-end: Instrument → Call → Meter
# ---------------------------------------------------------------------------


class TestInstrumentorEndToEnd:
    def test_sync_call_is_metered(self, registry, fake_openai):
        """Patched sync method should meter usage when context is set."""
        _, sync_cls, _ = fake_openai
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )
        inst.instrument()

        with paygent_context(user_id="user_1"):
            result = sync_cls.create(model="gpt-4o", messages=[])

        assert result.model == "gpt-4o"
        assert len(events) == 1
        assert events[0].user_id == "user_1"
        assert events[0].model == "gpt-4o"
        assert events[0].input_tokens == 100
        assert events[0].cost_total > 0

        # Cache should be updated
        assert session.current_usage.period_cost > 0

        inst.uninstrument()

    def test_sync_call_without_context_passes_through(self, registry, fake_openai):
        """Without paygent_context, patched method works normally."""
        _, sync_cls, _ = fake_openai
        events = []

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: None,
            event_sink=lambda e: events.append(e),
        )
        inst.instrument()

        result = sync_cls.create(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"
        assert len(events) == 0  # No metering

        inst.uninstrument()

    @pytest.mark.asyncio
    async def test_async_call_is_metered(self, registry, fake_openai):
        """Patched async method should meter usage."""
        _, _, async_cls = fake_openai
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )
        inst.instrument()

        with paygent_context(user_id="user_1"):
            result = await async_cls.create(model="gpt-4o", messages=[])

        assert result.model == "gpt-4o"
        assert len(events) == 1
        assert events[0].user_id == "user_1"

        inst.uninstrument()

    def test_soft_gate_handler_invoked(self, registry, fake_openai):
        """Soft gate handler should fire when user approaches limit."""
        _, sync_cls, _ = fake_openai
        # 82% of $49 = ~$40
        session = _make_session(period_cost=40.00)
        sessions = {"user_1": session}
        soft_results = []

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
            soft_gate_handler=lambda r: soft_results.append(r),
        )
        inst.instrument()

        with paygent_context(user_id="user_1"):
            sync_cls.create(model="gpt-4o", messages=[])

        assert len(soft_results) == 1
        assert soft_results[0].status == "soft_gate"

        inst.uninstrument()

    def test_hard_gate_raises(self, registry, fake_openai):
        """Hard gate should raise PaygentLimitExceeded."""
        from paygent.guardrails import PaygentLimitExceeded

        _, sync_cls, _ = fake_openai
        session = _make_session(period_cost=49.00)
        sessions = {"user_1": session}

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
            raise_on_hard_gate=True,
        )
        inst.instrument()

        with pytest.raises(PaygentLimitExceeded):
            with paygent_context(user_id="user_1"):
                sync_cls.create(model="gpt-4o", messages=[])

        inst.uninstrument()

    def test_multiple_calls_accumulate(self, registry, fake_openai):
        """Multiple calls should accumulate in the cache."""
        _, sync_cls, _ = fake_openai
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        inst = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )
        inst.instrument()

        with paygent_context(user_id="user_1"):
            sync_cls.create(model="gpt-4o", messages=[])
            sync_cls.create(model="gpt-4o", messages=[])
            sync_cls.create(model="gpt-4o", messages=[])

        assert len(events) == 3
        assert session.current_usage.period_tokens_by_model["gpt-4o"] == 450  # 150 * 3

        inst.uninstrument()
