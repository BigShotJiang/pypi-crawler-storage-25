"""Tests for Paygent event callback system.

Covers the four callback hooks:
- on_soft_gate  — fires when approaching a limit
- on_hard_gate  — fires when a limit is exceeded (before exception)
- on_usage      — fires after every successful metering event
- on_session_start — fires when a user session starts
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from paygent.core import Paygent
from paygent.guardrails import (
    HardGateCallbackRegistry,
    PaygentLimitExceeded,
    SessionStartCallbackRegistry,
    SoftGateCallbackRegistry,
    UsageCallbackRegistry,
)
from paygent.models import (
    CurrentUsage,
    GuardResult,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
    UserSession,
)


# ---------------------------------------------------------------------------
# Callback Registry Unit Tests
# ---------------------------------------------------------------------------


class TestSoftGateCallbackRegistry:
    def test_register_and_fire(self):
        reg = SoftGateCallbackRegistry()
        calls = []
        reg.register(lambda r: calls.append(r))
        result = GuardResult(status="soft_gate", gate_reason="total_spend")
        reg.fire(result)
        assert len(calls) == 1
        assert calls[0].gate_reason == "total_spend"

    def test_multiple_callbacks(self):
        reg = SoftGateCallbackRegistry()
        a, b = [], []
        reg.register(lambda r: a.append(1))
        reg.register(lambda r: b.append(1))
        reg.fire(GuardResult(status="soft_gate"))
        assert len(a) == 1 and len(b) == 1

    def test_failing_callback_swallowed(self):
        reg = SoftGateCallbackRegistry()
        reg.register(lambda r: 1 / 0)
        reg.register(lambda r: None)
        # Should not raise
        reg.fire(GuardResult(status="soft_gate"))
        assert reg.count == 2

    def test_clear(self):
        reg = SoftGateCallbackRegistry()
        reg.register(lambda r: None)
        assert reg.count == 1
        reg.clear()
        assert reg.count == 0


class TestHardGateCallbackRegistry:
    def test_register_and_fire(self):
        reg = HardGateCallbackRegistry()
        calls = []
        reg.register(lambda r: calls.append(r))
        result = GuardResult(status="hard_gate", gate_reason="total_spend")
        reg.fire(result)
        assert len(calls) == 1
        assert calls[0].status == "hard_gate"

    def test_failing_callback_swallowed(self):
        reg = HardGateCallbackRegistry()
        reg.register(lambda r: (_ for _ in ()).throw(ValueError("boom")))
        reg.fire(GuardResult(status="hard_gate"))


class TestUsageCallbackRegistry:
    def test_register_and_fire(self):
        reg = UsageCallbackRegistry()
        events = []
        reg.register(lambda e: events.append(e))
        event = UsageEvent(user_id="u1", cost_total=0.05, total_tokens=100)
        reg.fire(event)
        assert len(events) == 1
        assert events[0].cost_total == 0.05

    def test_failing_callback_swallowed(self):
        reg = UsageCallbackRegistry()
        reg.register(lambda e: 1 / 0)
        reg.fire(UsageEvent(user_id="u1"))


class TestSessionStartCallbackRegistry:
    def test_register_and_fire(self):
        reg = SessionStartCallbackRegistry()
        sessions = []
        reg.register(lambda s: sessions.append(s))
        session = UserSession(
            user_id="u1", plan="pro",
            plan_config=PlanConfig(), current_usage=CurrentUsage(),
        )
        reg.fire(session)
        assert len(sessions) == 1
        assert sessions[0].user_id == "u1"


# ---------------------------------------------------------------------------
# Integration Tests via Paygent Core
# ---------------------------------------------------------------------------


def _make_pg(**kwargs) -> Paygent:
    """Create a Paygent instance for testing (no auto-instrument, no backend)."""
    pg = Paygent(
        auto_instrument=False,
        **kwargs,
    )
    pg._initialize()
    return pg


class TestOnHardGateViaWrap:
    """on_hard_gate fires before PaygentLimitExceeded in wrap()."""

    def test_hard_gate_callback_fires_before_exception(self):
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(
            max_spend_per_period=0.001,
            hard_gate_at=1.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)
        # Push usage past the limit
        pg._sessions["u1"].current_usage.period_cost = 0.002

        hard_gate_calls = []
        pg.on_hard_gate(lambda r: hard_gate_calls.append(r))

        with pytest.raises(PaygentLimitExceeded):
            pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

        assert len(hard_gate_calls) == 1
        assert hard_gate_calls[0].status == "hard_gate"
        assert hard_gate_calls[0].gate_reason == "total_spend"

    def test_hard_gate_callback_fires_even_when_not_raising(self):
        pg = _make_pg(raise_on_hard_gate=False)
        config = PlanConfig(
            max_spend_per_period=0.001,
            hard_gate_at=1.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        hard_gate_calls = []
        pg.on_hard_gate(lambda r: hard_gate_calls.append(r))

        # Should NOT raise, but callback should still fire
        result = pg.wrap(lambda: "ok", user_id="u1", model="gpt-4o")
        assert result == "ok"
        assert len(hard_gate_calls) == 1

    def test_hard_gate_callback_error_does_not_prevent_exception(self):
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(max_spend_per_period=0.001, hard_gate_at=1.00)
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        pg.on_hard_gate(lambda r: 1 / 0)  # Callback crashes

        with pytest.raises(PaygentLimitExceeded):
            pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

    def test_multiple_hard_gate_callbacks(self):
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(max_spend_per_period=0.001, hard_gate_at=1.00)
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        a, b = [], []
        pg.on_hard_gate(lambda r: a.append(1))
        pg.on_hard_gate(lambda r: b.append(1))

        with pytest.raises(PaygentLimitExceeded):
            pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

        assert len(a) == 1 and len(b) == 1


class TestOnHardGateViaAwrap:
    """on_hard_gate fires in async awrap() too."""

    @pytest.mark.asyncio
    async def test_hard_gate_callback_fires_in_awrap(self):
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(max_spend_per_period=0.001, hard_gate_at=1.00)
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        hard_gate_calls = []
        pg.on_hard_gate(lambda r: hard_gate_calls.append(r))

        async def fake_call():
            return "response"

        with pytest.raises(PaygentLimitExceeded):
            await pg.awrap(fake_call(), user_id="u1", model="gpt-4o")

        assert len(hard_gate_calls) == 1


class TestOnUsageViaWrap:
    """on_usage fires after every successful metering event."""

    def test_usage_callback_fires_after_wrap(self):
        pg = _make_pg()
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)

        usage_events = []
        pg.on_usage(lambda e: usage_events.append(e))

        # Mock response with usage data
        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        pg.wrap(lambda: response, user_id="u1", model="gpt-4o")

        assert len(usage_events) == 1
        assert usage_events[0].user_id == "u1"
        assert usage_events[0].model == "gpt-4o"
        assert usage_events[0].total_tokens == 150
        assert usage_events[0].cost_total > 0

    def test_usage_callback_fires_multiple_times(self):
        pg = _make_pg()
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)

        usage_events = []
        pg.on_usage(lambda e: usage_events.append(e))

        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        pg.wrap(lambda: response, user_id="u1", model="gpt-4o")
        pg.wrap(lambda: response, user_id="u1", model="gpt-4o")

        assert len(usage_events) == 2

    def test_usage_callback_error_does_not_break_response(self):
        pg = _make_pg()
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)

        pg.on_usage(lambda e: 1 / 0)  # Callback crashes

        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        # Should still return the response
        result = pg.wrap(lambda: response, user_id="u1", model="gpt-4o")
        assert result is response

    def test_usage_callback_not_fired_on_hard_gate(self):
        """Usage callback should NOT fire if the call is blocked."""
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(max_spend_per_period=0.001, hard_gate_at=1.00)
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        usage_events = []
        pg.on_usage(lambda e: usage_events.append(e))

        with pytest.raises(PaygentLimitExceeded):
            pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

        assert len(usage_events) == 0  # Call was blocked, no metering

    @pytest.mark.asyncio
    async def test_usage_callback_fires_in_awrap(self):
        pg = _make_pg()
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)

        usage_events = []
        pg.on_usage(lambda e: usage_events.append(e))

        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        async def fake_call():
            return response

        await pg.awrap(fake_call(), user_id="u1", model="gpt-4o")

        assert len(usage_events) == 1
        assert usage_events[0].total_tokens == 150


class TestOnSessionStart:
    """on_session_start fires when sessions are created."""

    def test_session_start_callback_fires_on_start_session(self):
        pg = _make_pg()
        sessions = []
        pg.on_session_start(lambda s: sessions.append(s))

        pg.start_session("u1", plan="pro", plan_config=PlanConfig())

        assert len(sessions) == 1
        assert sessions[0].user_id == "u1"
        assert sessions[0].plan == "pro"

    def test_session_start_callback_fires_on_auto_create(self):
        """Auto-created sessions (via session lookup) also trigger the callback."""
        pg = _make_pg()
        sessions = []
        pg.on_session_start(lambda s: sessions.append(s))

        # Trigger auto-creation via wrap
        pg.wrap(lambda: "response", user_id="u_new", model="gpt-4o")

        assert len(sessions) == 1
        assert sessions[0].user_id == "u_new"
        assert sessions[0].plan == "default"

    def test_existing_session_does_not_retrigger(self):
        """Refreshing an existing session should NOT fire session_start again."""
        pg = _make_pg()
        sessions = []
        pg.on_session_start(lambda s: sessions.append(s))

        pg.start_session("u1", plan="pro", plan_config=PlanConfig())
        pg.start_session("u1", plan="pro_v2", plan_config=PlanConfig())

        # Only the first call fires session_start
        assert len(sessions) == 1

    def test_session_start_callback_error_swallowed(self):
        pg = _make_pg()
        pg.on_session_start(lambda s: 1 / 0)

        # Should not raise
        session = pg.start_session("u1", plan="pro", plan_config=PlanConfig())
        assert session.user_id == "u1"

    def test_multiple_session_start_callbacks(self):
        pg = _make_pg()
        a, b = [], []
        pg.on_session_start(lambda s: a.append(s.user_id))
        pg.on_session_start(lambda s: b.append(s.plan))

        pg.start_session("u1", plan="pro", plan_config=PlanConfig())

        assert a == ["u1"]
        assert b == ["pro"]


class TestOnSoftGateViaWrap:
    """Verify existing on_soft_gate still works correctly with the new system."""

    def test_soft_gate_callback_fires(self):
        pg = _make_pg()
        config = PlanConfig(
            max_spend_per_period=1.00,
            soft_gate_at=0.80,
            hard_gate_at=1.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)
        # Push usage to 85% — triggers soft gate
        pg._sessions["u1"].current_usage.period_cost = 0.85

        soft_gate_calls = []
        pg.on_soft_gate(lambda r: soft_gate_calls.append(r))

        pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

        assert len(soft_gate_calls) == 1
        assert soft_gate_calls[0].status == "soft_gate"


class TestCombinedCallbacks:
    """Test multiple callback types working together."""

    def test_soft_gate_and_usage_both_fire(self):
        pg = _make_pg()
        config = PlanConfig(
            max_spend_per_period=1.00,
            soft_gate_at=0.80,
            hard_gate_at=1.00,
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.85

        soft_calls = []
        usage_calls = []
        pg.on_soft_gate(lambda r: soft_calls.append(r))
        pg.on_usage(lambda e: usage_calls.append(e))

        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        pg.wrap(lambda: response, user_id="u1", model="gpt-4o")

        assert len(soft_calls) == 1
        assert len(usage_calls) == 1

    def test_hard_gate_fires_but_usage_does_not(self):
        """Hard gate blocks the call, so usage callback should not fire."""
        pg = _make_pg(raise_on_hard_gate=True)
        config = PlanConfig(max_spend_per_period=0.001, hard_gate_at=1.00)
        pg.start_session("u1", plan="pro", plan_config=config)
        pg._sessions["u1"].current_usage.period_cost = 0.002

        hard_calls = []
        usage_calls = []
        pg.on_hard_gate(lambda r: hard_calls.append(r))
        pg.on_usage(lambda e: usage_calls.append(e))

        with pytest.raises(PaygentLimitExceeded):
            pg.wrap(lambda: "response", user_id="u1", model="gpt-4o")

        assert len(hard_calls) == 1
        assert len(usage_calls) == 0

    def test_session_start_and_usage_in_sequence(self):
        """Session start fires first, then usage on the LLM call."""
        pg = _make_pg()
        config = PlanConfig(
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )
        events_in_order = []
        pg.on_session_start(lambda s: events_in_order.append(("session_start", s.user_id)))
        pg.on_usage(lambda e: events_in_order.append(("usage", e.user_id)))

        pg.start_session("u1", plan="pro", plan_config=config)

        response = MagicMock()
        response.usage = MagicMock(
            prompt_tokens=100, completion_tokens=50, total_tokens=150,
        )
        response.model = "gpt-4o"

        pg.wrap(lambda: response, user_id="u1", model="gpt-4o")

        assert events_in_order == [
            ("session_start", "u1"),
            ("usage", "u1"),
        ]
