"""Tests for refresh merge logic — backend data merged without losing session state."""

from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

import pytest

from paygent.core import _merge_user_state
from paygent.models import (
    BillingPeriod,
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserState,
)


# ---------------------------------------------------------------------------
# _merge_user_state unit tests
# ---------------------------------------------------------------------------


def _make_state(
    user_id="user_1",
    plan="pro",
    period_cost=0.0,
    session_cost=0.0,
    session_id=None,
    session_started_at=None,
    period_tokens_total=0,
    period_tokens_by_model=None,
    period_cost_by_model=None,
    max_spend_per_period=49.0,
    billing_period=None,
    last_refreshed=None,
) -> UserState:
    return UserState(
        user_id=user_id,
        plan=plan,
        plan_config=PlanConfig(max_spend_per_period=max_spend_per_period),
        current_usage=CurrentUsage(
            period_cost=period_cost,
            session_cost=session_cost,
            session_id=session_id,
            session_started_at=session_started_at,
            period_tokens_total=period_tokens_total,
            period_tokens_by_model=period_tokens_by_model or {},
            period_cost_by_model=period_cost_by_model or {},
        ),
        billing_period=billing_period,
        last_refreshed=last_refreshed,
    )


class TestMergeUserState:
    """Test _merge_user_state updates in-place, preserves session window."""

    def test_modifies_in_place(self):
        """Merge should modify existing object, not create a new one."""
        existing = _make_state(session_cost=1.0)
        refreshed = _make_state(period_cost=10.0)

        _merge_user_state(existing, refreshed)

        # Same object, updated in place
        assert existing.current_usage.period_cost == 10.0
        assert existing.current_usage.session_cost == 1.0

    def test_preserves_session_cost(self):
        """Session cost should be kept from existing state."""
        existing = _make_state(session_cost=1.23, session_id="sess_abc")
        refreshed = _make_state(session_cost=0.0, session_id=None)

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.session_cost == 1.23

    def test_preserves_session_id(self):
        """Session ID should be kept from existing state."""
        existing = _make_state(session_id="sess_local_123")
        refreshed = _make_state(session_id=None)

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.session_id == "sess_local_123"

    def test_preserves_session_started_at(self):
        """Session start time should be kept from existing state."""
        started = datetime(2026, 4, 9, 10, 0, 0)
        existing = _make_state(session_started_at=started)
        refreshed = _make_state(session_started_at=None)

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.session_started_at == started

    def test_takes_backend_period_cost(self):
        """Period cost should come from refreshed (backend) data."""
        existing = _make_state(period_cost=5.0)
        refreshed = _make_state(period_cost=12.50)

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.period_cost == 12.50

    def test_takes_backend_period_tokens(self):
        """Period tokens should come from refreshed (backend) data."""
        existing = _make_state(
            period_tokens_total=1000,
            period_tokens_by_model={"gpt-4o": 1000},
        )
        refreshed = _make_state(
            period_tokens_total=5000,
            period_tokens_by_model={"gpt-4o": 3000, "claude-sonnet-4-20250514": 2000},
        )

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.period_tokens_total == 5000
        assert existing.current_usage.period_tokens_by_model == {
            "gpt-4o": 3000,
            "claude-sonnet-4-20250514": 2000,
        }

    def test_takes_backend_plan_config(self):
        """Plan config should come from refreshed (backend) data."""
        existing = _make_state(max_spend_per_period=49.0)
        refreshed = _make_state(max_spend_per_period=99.0)

        _merge_user_state(existing, refreshed)

        assert existing.plan_config.max_spend_per_period == 99.0

    def test_takes_backend_plan_name(self):
        """Plan name should come from refreshed data (e.g., plan upgrade)."""
        existing = _make_state(plan="free")
        refreshed = _make_state(plan="pro")

        _merge_user_state(existing, refreshed)

        assert existing.plan == "pro"

    def test_takes_backend_billing_period(self):
        """Billing period should come from refreshed data."""
        existing = _make_state(billing_period=None)
        new_bp = BillingPeriod(
            start=datetime(2026, 4, 1),
            end=datetime(2026, 5, 1),
        )
        refreshed = _make_state(billing_period=new_bp)

        _merge_user_state(existing, refreshed)

        assert existing.billing_period is not None
        assert existing.billing_period.start == datetime(2026, 4, 1)

    def test_updates_last_refreshed(self):
        """last_refreshed should be set to current time."""
        existing = _make_state(last_refreshed=datetime(2026, 4, 9, 8, 0, 0))
        refreshed = _make_state(last_refreshed=None)

        _merge_user_state(existing, refreshed)

        assert existing.last_refreshed is not None
        # Should be recent (within last few seconds)
        assert (datetime.utcnow() - existing.last_refreshed).total_seconds() < 5

    def test_full_merge_scenario(self):
        """Realistic scenario: backend has updated period data, local has active session."""
        started = datetime(2026, 4, 9, 14, 30, 0)
        existing = _make_state(
            plan="pro",
            period_cost=10.0,
            session_cost=2.50,
            session_id="sess_active",
            session_started_at=started,
            period_tokens_total=5000,
            period_tokens_by_model={"gpt-4o": 5000},
            max_spend_per_period=49.0,
        )
        original_id = id(existing)
        refreshed = _make_state(
            plan="pro",
            period_cost=15.0,  # other server instances added usage
            session_cost=0.0,  # backend doesn't know about sessions
            session_id=None,
            session_started_at=None,
            period_tokens_total=8000,
            period_tokens_by_model={"gpt-4o": 6000, "claude-sonnet-4-20250514": 2000},
            max_spend_per_period=49.0,
        )

        _merge_user_state(existing, refreshed)

        # Same object (in-place)
        assert id(existing) == original_id

        # Backend data for period
        assert existing.current_usage.period_cost == 15.0
        assert existing.current_usage.period_tokens_total == 8000
        assert existing.current_usage.period_tokens_by_model["gpt-4o"] == 6000

        # Local session data preserved
        assert existing.current_usage.session_cost == 2.50
        assert existing.current_usage.session_id == "sess_active"
        assert existing.current_usage.session_started_at == started

    def test_period_cost_by_model_from_backend(self):
        """period_cost_by_model should come from refreshed data."""
        existing = _make_state(period_cost_by_model={"gpt-4o": 1.0})
        refreshed = _make_state(period_cost_by_model={"gpt-4o": 3.0, "claude-sonnet-4-20250514": 2.0})

        _merge_user_state(existing, refreshed)

        assert existing.current_usage.period_cost_by_model == {
            "gpt-4o": 3.0,
            "claude-sonnet-4-20250514": 2.0,
        }

    def test_object_identity_preserved_in_sessions_dict(self):
        """Simulates the race condition fix: object in _sessions dict stays the same."""
        sessions = {}
        existing = _make_state(session_cost=5.0, session_id="sess_123")
        sessions["user_1"] = existing

        # A reference held by the patcher wrapper
        wrapper_ref = sessions["user_1"]

        # Background thread merges in-place
        refreshed = _make_state(period_cost=20.0)
        _merge_user_state(existing, refreshed)

        # The wrapper's reference still points to the same object
        assert wrapper_ref is sessions["user_1"]
        # And it sees the updated period data
        assert wrapper_ref.current_usage.period_cost == 20.0
        # And the session data is preserved
        assert wrapper_ref.current_usage.session_cost == 5.0


# ---------------------------------------------------------------------------
# Integration: _refresh_stale_states uses merge
# ---------------------------------------------------------------------------


class TestRefreshStaleStatesMerge:
    """Test that _refresh_stale_states merges in-place."""

    def test_refresh_preserves_session_window(self):
        """_refresh_stale_states should merge in-place, preserving session data."""
        from paygent.core import Paygent

        pg = Paygent.__new__(Paygent)
        pg._sessions = {}
        pg._api_client = MagicMock()
        pg._storage = MagicMock()
        pg._refresh_interval = 300.0

        # Set up existing state with active session
        started = datetime(2026, 4, 9, 14, 0, 0)
        existing_state = _make_state(
            period_cost=10.0,
            session_cost=3.0,
            session_id="sess_keep_me",
            session_started_at=started,
            last_refreshed=datetime.utcnow() - timedelta(seconds=600),  # stale
        )
        pg._sessions["user_1"] = existing_state
        original_id = id(existing_state)

        # Backend returns updated period data
        backend_state = _make_state(
            period_cost=20.0,
            session_cost=0.0,
            session_id=None,
            session_started_at=None,
        )
        pg._api_client.fetch_session.return_value = backend_state

        pg._refresh_stale_states()

        result = pg._sessions["user_1"]
        # Same object (in-place update, no replacement)
        assert id(result) == original_id
        # Backend period data applied
        assert result.current_usage.period_cost == 20.0
        # Session data preserved
        assert result.current_usage.session_cost == 3.0
        assert result.current_usage.session_id == "sess_keep_me"
        assert result.current_usage.session_started_at == started

    def test_refresh_skips_fresh_states(self):
        """States that were recently refreshed should be skipped."""
        from paygent.core import Paygent

        pg = Paygent.__new__(Paygent)
        pg._sessions = {}
        pg._api_client = MagicMock()
        pg._storage = MagicMock()
        pg._refresh_interval = 300.0

        fresh_state = _make_state(
            last_refreshed=datetime.utcnow(),  # just refreshed
        )
        pg._sessions["user_1"] = fresh_state

        pg._refresh_stale_states()

        # Should not have called fetch_session
        pg._api_client.fetch_session.assert_not_called()

    def test_refresh_user_merges_existing(self):
        """refresh_user() should merge in-place with existing state."""
        from paygent.core import Paygent

        pg = Paygent.__new__(Paygent)
        pg._sessions = {}
        pg._api_client = MagicMock()
        pg._storage = MagicMock()
        pg._plan_configs = {}
        pg._refresh_interval = 300.0

        started = datetime(2026, 4, 9, 14, 0, 0)
        existing_state = _make_state(
            session_cost=5.0,
            session_id="sess_xyz",
            session_started_at=started,
        )
        pg._sessions["user_1"] = existing_state
        original_id = id(existing_state)

        backend_state = _make_state(
            plan="enterprise",
            period_cost=50.0,
            max_spend_per_period=200.0,
        )
        pg._api_client.fetch_session.return_value = backend_state

        result = pg.refresh_user("user_1")

        # Same object (in-place)
        assert id(result) == original_id

        # Plan upgraded from backend
        assert result.plan == "enterprise"
        assert result.plan_config.max_spend_per_period == 200.0
        assert result.current_usage.period_cost == 50.0

        # Session preserved
        assert result.current_usage.session_cost == 5.0
        assert result.current_usage.session_id == "sess_xyz"
        assert result.current_usage.session_started_at == started

    def test_refresh_user_no_existing_state(self):
        """refresh_user() with no existing state should use backend state as-is."""
        from paygent.core import Paygent

        pg = Paygent.__new__(Paygent)
        pg._sessions = {}
        pg._api_client = MagicMock()
        pg._storage = MagicMock()
        pg._plan_configs = {}
        pg._refresh_interval = 300.0

        backend_state = _make_state(plan="pro", period_cost=10.0)
        pg._api_client.fetch_session.return_value = backend_state

        result = pg.refresh_user("user_1")

        assert result.plan == "pro"
        assert result.current_usage.period_cost == 10.0


# ---------------------------------------------------------------------------
# sdk_enabled merge tests
# ---------------------------------------------------------------------------


class TestSdkEnabledMerge:
    """Tests that sdk_enabled is properly merged from backend."""

    def test_sdk_enabled_merged_from_backend(self):
        """sdk_enabled is updated when backend sends a new value."""
        existing = _make_state(plan="pro")
        existing.sdk_enabled = True

        refreshed = _make_state(plan="pro")
        refreshed.sdk_enabled = False

        _merge_user_state(existing, refreshed)
        assert existing.sdk_enabled is False

    def test_sdk_enabled_toggled_back_on(self):
        """sdk_enabled can be re-enabled by backend."""
        existing = _make_state(plan="pro")
        existing.sdk_enabled = False

        refreshed = _make_state(plan="pro")
        refreshed.sdk_enabled = True

        _merge_user_state(existing, refreshed)
        assert existing.sdk_enabled is True

    def test_sdk_enabled_defaults_to_true(self):
        """New UserState defaults sdk_enabled=True."""
        state = _make_state()
        assert state.sdk_enabled is True
