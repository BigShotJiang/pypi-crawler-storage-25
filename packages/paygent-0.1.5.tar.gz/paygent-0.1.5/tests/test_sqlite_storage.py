"""Tests for Paygent SQLite storage backend."""

from __future__ import annotations

import os
import tempfile
from datetime import datetime

import pytest

from paygent.models import (
    BillingPeriod,
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
    UserState,
)
from paygent.storage.sqlite import SQLiteStorage


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
async def storage():
    """Create a temporary SQLite storage for each test."""
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    db_path = tmp.name

    s = SQLiteStorage(db_path=db_path)
    await s.initialize()
    yield s
    await s.close()

    # Cleanup
    try:
        os.unlink(db_path)
    except OSError:
        pass


def _make_event(
    user_id="user_1",
    model="gpt-4o",
    event_id=None,
    cost_total=0.10,
    synced=False,
) -> UsageEvent:
    kwargs = dict(
        user_id=user_id,
        session_id="sess_1",
        model=model,
        input_tokens=100,
        output_tokens=50,
        total_tokens=150,
        tool_calls=["web_search"],
        cost_tokens=0.08,
        cost_tools=0.02,
        cost_total=cost_total,
        metadata={"agent": "test"},
        synced=synced,
    )
    if event_id is not None:
        kwargs["id"] = event_id
    return UsageEvent(**kwargs)


# ---------------------------------------------------------------------------
# Initialize
# ---------------------------------------------------------------------------


class TestInitialize:
    @pytest.mark.asyncio
    async def test_creates_db_and_tables(self):
        """Initialize should create the DB file and tables."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()
        db_path = tmp.name

        s = SQLiteStorage(db_path=db_path)
        await s.initialize()

        assert os.path.exists(db_path)
        count = await s.get_event_count()
        assert count == 0

        await s.close()
        os.unlink(db_path)

    @pytest.mark.asyncio
    async def test_creates_parent_directory(self):
        """Should create parent directories if they don't exist."""
        tmp_dir = tempfile.mkdtemp()
        db_path = os.path.join(tmp_dir, "subdir", "nested", "test.db")

        s = SQLiteStorage(db_path=db_path)
        await s.initialize()
        assert os.path.exists(db_path)

        await s.close()
        # Cleanup
        import shutil
        shutil.rmtree(tmp_dir)

    @pytest.mark.asyncio
    async def test_idempotent_initialize(self, storage: SQLiteStorage):
        """Calling initialize multiple times should not fail."""
        await storage.initialize()
        await storage.initialize()
        count = await storage.get_event_count()
        assert count == 0


# ---------------------------------------------------------------------------
# Store Events
# ---------------------------------------------------------------------------


class TestStoreEvents:
    @pytest.mark.asyncio
    async def test_store_single_event(self, storage: SQLiteStorage):
        event = _make_event()
        stored = await storage.store_events([event])
        assert stored == 1
        assert await storage.get_event_count() == 1

    @pytest.mark.asyncio
    async def test_store_multiple_events(self, storage: SQLiteStorage):
        events = [_make_event(user_id=f"user_{i}") for i in range(5)]
        stored = await storage.store_events(events)
        assert stored == 5
        assert await storage.get_event_count() == 5

    @pytest.mark.asyncio
    async def test_dedup_by_event_id(self, storage: SQLiteStorage):
        """Duplicate event IDs should be ignored (INSERT OR IGNORE)."""
        event = _make_event(event_id="evt_fixed_id")
        stored1 = await storage.store_events([event])
        stored2 = await storage.store_events([event])
        assert stored1 == 1
        assert stored2 == 0  # Duplicate ignored
        assert await storage.get_event_count() == 1

    @pytest.mark.asyncio
    async def test_store_empty_list(self, storage: SQLiteStorage):
        stored = await storage.store_events([])
        assert stored == 0

    @pytest.mark.asyncio
    async def test_preserves_all_fields(self, storage: SQLiteStorage):
        """All event fields should survive storage and retrieval."""
        event = _make_event(user_id="user_1")
        await storage.store_events([event])

        events = await storage.get_events_by_user("user_1")
        assert len(events) == 1
        retrieved = events[0]

        assert retrieved.id == event.id
        assert retrieved.user_id == "user_1"
        assert retrieved.session_id == "sess_1"
        assert retrieved.model == "gpt-4o"
        assert retrieved.input_tokens == 100
        assert retrieved.output_tokens == 50
        assert retrieved.total_tokens == 150
        assert retrieved.tool_calls == ["web_search"]
        assert retrieved.cost_tokens == pytest.approx(0.08)
        assert retrieved.cost_tools == pytest.approx(0.02)
        assert retrieved.cost_total == pytest.approx(0.10)
        assert retrieved.metadata == {"agent": "test"}
        assert retrieved.synced is False


# ---------------------------------------------------------------------------
# Unsynced Events
# ---------------------------------------------------------------------------


class TestUnsyncedEvents:
    @pytest.mark.asyncio
    async def test_get_unsynced(self, storage: SQLiteStorage):
        """Should return only unsynced events."""
        unsynced = _make_event(event_id="evt_1", synced=False)
        synced = _make_event(event_id="evt_2", synced=True)
        await storage.store_events([unsynced, synced])

        events = await storage.get_unsynced_events()
        assert len(events) == 1
        assert events[0].id == "evt_1"

    @pytest.mark.asyncio
    async def test_unsynced_ordered_by_timestamp(self, storage: SQLiteStorage):
        """Unsynced events should be returned oldest first."""
        e1 = UsageEvent(
            id="evt_old", user_id="u1",
            timestamp=datetime(2026, 3, 1, 10, 0, 0),
        )
        e2 = UsageEvent(
            id="evt_new", user_id="u1",
            timestamp=datetime(2026, 3, 28, 10, 0, 0),
        )
        await storage.store_events([e2, e1])  # Insert out of order

        events = await storage.get_unsynced_events()
        assert events[0].id == "evt_old"
        assert events[1].id == "evt_new"

    @pytest.mark.asyncio
    async def test_unsynced_limit(self, storage: SQLiteStorage):
        events = [_make_event(event_id=f"evt_{i}") for i in range(10)]
        await storage.store_events(events)

        limited = await storage.get_unsynced_events(limit=3)
        assert len(limited) == 3

    @pytest.mark.asyncio
    async def test_empty_unsynced(self, storage: SQLiteStorage):
        events = await storage.get_unsynced_events()
        assert events == []


# ---------------------------------------------------------------------------
# Mark Synced
# ---------------------------------------------------------------------------


class TestMarkSynced:
    @pytest.mark.asyncio
    async def test_mark_synced(self, storage: SQLiteStorage):
        events = [_make_event(event_id=f"evt_{i}") for i in range(3)]
        await storage.store_events(events)

        count = await storage.mark_synced(["evt_0", "evt_1"])
        assert count == 2

        unsynced = await storage.get_unsynced_events()
        assert len(unsynced) == 1
        assert unsynced[0].id == "evt_2"

    @pytest.mark.asyncio
    async def test_mark_synced_empty_list(self, storage: SQLiteStorage):
        count = await storage.mark_synced([])
        assert count == 0

    @pytest.mark.asyncio
    async def test_mark_synced_nonexistent_id(self, storage: SQLiteStorage):
        """Marking a nonexistent ID should not error."""
        count = await storage.mark_synced(["nonexistent_id"])
        assert count == 0


# ---------------------------------------------------------------------------
# Get Events by User
# ---------------------------------------------------------------------------


class TestGetEventsByUser:
    @pytest.mark.asyncio
    async def test_returns_user_events_only(self, storage: SQLiteStorage):
        await storage.store_events([
            _make_event(user_id="user_a", event_id="evt_a"),
            _make_event(user_id="user_b", event_id="evt_b"),
            _make_event(user_id="user_a", event_id="evt_c"),
        ])

        events = await storage.get_events_by_user("user_a")
        assert len(events) == 2
        assert all(e.user_id == "user_a" for e in events)

    @pytest.mark.asyncio
    async def test_ordered_newest_first(self, storage: SQLiteStorage):
        e1 = UsageEvent(id="evt_old", user_id="u1", timestamp=datetime(2026, 3, 1))
        e2 = UsageEvent(id="evt_new", user_id="u1", timestamp=datetime(2026, 3, 28))
        await storage.store_events([e1, e2])

        events = await storage.get_events_by_user("u1")
        assert events[0].id == "evt_new"
        assert events[1].id == "evt_old"

    @pytest.mark.asyncio
    async def test_limit(self, storage: SQLiteStorage):
        events = [_make_event(user_id="u1", event_id=f"evt_{i}") for i in range(10)]
        await storage.store_events(events)

        limited = await storage.get_events_by_user("u1", limit=5)
        assert len(limited) == 5

    @pytest.mark.asyncio
    async def test_no_events_for_user(self, storage: SQLiteStorage):
        events = await storage.get_events_by_user("nonexistent_user")
        assert events == []


# ---------------------------------------------------------------------------
# Sync Wrappers
# ---------------------------------------------------------------------------


class TestSyncWrappers:
    def test_initialize_and_store_sync(self):
        """Sync wrappers should work from non-async code."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()

        s = SQLiteStorage(db_path=tmp.name)
        s.initialize_sync()

        event = _make_event()
        stored = s.store_events_sync([event])
        assert stored == 1

        unsynced = s.get_unsynced_events_sync()
        assert len(unsynced) == 1

        s.mark_synced_sync([unsynced[0].id])
        unsynced = s.get_unsynced_events_sync()
        assert len(unsynced) == 0

        s.close_sync()
        os.unlink(tmp.name)


# ---------------------------------------------------------------------------
# Edge Cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    @pytest.mark.asyncio
    async def test_close_and_reopen(self):
        """Should be able to close and reopen the database."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()

        s = SQLiteStorage(db_path=tmp.name)
        await s.initialize()
        await s.store_events([_make_event(event_id="evt_persist")])
        await s.close()

        # Reopen
        s2 = SQLiteStorage(db_path=tmp.name)
        await s2.initialize()
        count = await s2.get_event_count()
        assert count == 1

        events = await s2.get_unsynced_events()
        assert events[0].id == "evt_persist"

        await s2.close()
        os.unlink(tmp.name)

    @pytest.mark.asyncio
    async def test_operations_on_closed_storage(self):
        """Operations on closed storage should return empty/zero (fail-open)."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()

        s = SQLiteStorage(db_path=tmp.name)
        await s.initialize()
        await s.close()

        # These should not raise
        assert await s.store_events([_make_event()]) == 0
        assert await s.get_unsynced_events() == []
        assert await s.get_event_count() == 0
        assert await s.mark_synced(["x"]) == 0
        assert await s.get_events_by_user("u1") == []

        os.unlink(tmp.name)


# ---------------------------------------------------------------------------
# User Snapshots
# ---------------------------------------------------------------------------


def _make_state(
    user_id: str = "user_1",
    plan: str = "pro",
    with_billing_period: bool = False,
) -> UserState:
    config = PlanConfig(
        max_spend_per_period=50.0,
        cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50000)},
    )
    usage = CurrentUsage(
        period_cost=12.50,
        session_cost=2.00,
        period_tokens_total=5000,
        period_tokens_by_model={"gpt-4o": 5000},
        period_cost_by_model={"gpt-4o": 12.50},
    )
    bp = None
    if with_billing_period:
        bp = BillingPeriod(
            start=datetime(2026, 3, 15),
            end=datetime(2026, 4, 15),
        )
    return UserState(
        user_id=user_id,
        plan=plan,
        plan_config=config,
        current_usage=usage,
        billing_period=bp,
    )


class TestUserSnapshots:
    @pytest.mark.asyncio
    async def test_save_and_load_snapshot(self, storage: SQLiteStorage):
        """Should persist and restore a user state snapshot."""
        state = _make_state()
        await storage.save_snapshot(state)

        loaded = await storage.load_snapshot("user_1")
        assert loaded is not None
        assert loaded.user_id == "user_1"
        assert loaded.plan == "pro"
        assert loaded.plan_config.max_spend_per_period == 50.0
        assert loaded.current_usage.period_cost == pytest.approx(12.50)
        assert loaded.current_usage.period_tokens_total == 5000
        assert loaded.current_usage.period_tokens_by_model["gpt-4o"] == 5000

    @pytest.mark.asyncio
    async def test_snapshot_with_billing_period(self, storage: SQLiteStorage):
        """Should persist billing period dates."""
        state = _make_state(with_billing_period=True)
        await storage.save_snapshot(state)

        loaded = await storage.load_snapshot("user_1")
        assert loaded.billing_period is not None
        assert loaded.billing_period.start == datetime(2026, 3, 15)
        assert loaded.billing_period.end == datetime(2026, 4, 15)

    @pytest.mark.asyncio
    async def test_snapshot_without_billing_period(self, storage: SQLiteStorage):
        """Should handle None billing period."""
        state = _make_state(with_billing_period=False)
        await storage.save_snapshot(state)

        loaded = await storage.load_snapshot("user_1")
        assert loaded.billing_period is None

    @pytest.mark.asyncio
    async def test_upsert_snapshot(self, storage: SQLiteStorage):
        """Saving twice should update, not duplicate."""
        state = _make_state()
        await storage.save_snapshot(state)

        # Update usage
        state.current_usage.period_cost = 25.0
        state.current_usage.period_tokens_total = 10000
        await storage.save_snapshot(state)

        loaded = await storage.load_snapshot("user_1")
        assert loaded.current_usage.period_cost == pytest.approx(25.0)
        assert loaded.current_usage.period_tokens_total == 10000

    @pytest.mark.asyncio
    async def test_load_nonexistent_snapshot(self, storage: SQLiteStorage):
        """Loading a non-existent user should return None."""
        loaded = await storage.load_snapshot("no_such_user")
        assert loaded is None

    @pytest.mark.asyncio
    async def test_delete_snapshot(self, storage: SQLiteStorage):
        """Should delete a snapshot."""
        state = _make_state()
        await storage.save_snapshot(state)
        await storage.delete_snapshot("user_1")

        loaded = await storage.load_snapshot("user_1")
        assert loaded is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent_snapshot(self, storage: SQLiteStorage):
        """Deleting a non-existent snapshot should not error."""
        await storage.delete_snapshot("no_such_user")

    @pytest.mark.asyncio
    async def test_multiple_users(self, storage: SQLiteStorage):
        """Should store separate snapshots per user."""
        state_a = _make_state(user_id="user_a", plan="free")
        state_b = _make_state(user_id="user_b", plan="pro")
        await storage.save_snapshot(state_a)
        await storage.save_snapshot(state_b)

        loaded_a = await storage.load_snapshot("user_a")
        loaded_b = await storage.load_snapshot("user_b")
        assert loaded_a.plan == "free"
        assert loaded_b.plan == "pro"

    def test_snapshot_sync_wrappers(self):
        """Sync wrappers should work from non-async code."""
        tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        tmp.close()

        s = SQLiteStorage(db_path=tmp.name)
        s.initialize_sync()

        state = _make_state(with_billing_period=True)
        s.save_snapshot_sync(state)

        loaded = s.load_snapshot_sync("user_1")
        assert loaded is not None
        assert loaded.plan == "pro"
        assert loaded.billing_period is not None

        s.delete_snapshot_sync("user_1")
        assert s.load_snapshot_sync("user_1") is None

        s.close_sync()
        os.unlink(tmp.name)

    @pytest.mark.asyncio
    async def test_snapshot_preserves_model_limits(self, storage: SQLiteStorage):
        """Plan config model limits should survive serialization."""
        state = _make_state()
        await storage.save_snapshot(state)

        loaded = await storage.load_snapshot("user_1")
        assert "gpt-4o" in loaded.plan_config.model_limits
        assert loaded.plan_config.model_limits["gpt-4o"].max_tokens_per_period == 50000
        assert "gpt-4o" in loaded.plan_config.cost_rates
        assert loaded.plan_config.cost_rates["gpt-4o"].input == pytest.approx(0.0025)
