"""Tests for the CrewAI integration callback."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from paygent.core import Paygent
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    PlanConfig,
    UserSession,
)
from paygent.integrations.crewai import CrewAICallback


# ---------------------------------------------------------------------------
# Mock CrewAI step output objects
# ---------------------------------------------------------------------------


class MockStepOutput:
    """Stand-in for a CrewAI step output with token usage."""

    def __init__(
        self,
        token_usage: Optional[Dict] = None,
        model: Optional[str] = None,
        result: Optional[Dict] = None,
    ):
        self.token_usage = token_usage
        self.model = model
        self.result = result


class MockStepWithMetrics:
    """Stand-in for a CrewAI step output using usage_metrics."""

    def __init__(self, usage_metrics: Optional[Dict] = None, model_name: Optional[str] = None):
        self.usage_metrics = usage_metrics
        self.model_name = model_name


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def pg(tmp_path):
    """Create a Paygent instance for testing."""
    instance = Paygent(
        db_path=str(tmp_path / "test.db"),
        auto_instrument=False,
    )
    instance._initialized = True
    yield instance
    Paygent._instance = None


@pytest.fixture
def session(pg) -> UserSession:
    """Start a session with cost rates configured."""
    config = PlanConfig(
        max_spend_per_period=100.0,
        cost_rates={
            "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
        },
    )
    return pg.start_session("user_crew", plan="pro", plan_config=config)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_callback_creation(pg, session):
    """CrewAICallback can be created with a Paygent instance."""
    cb = CrewAICallback(pg, user_id="user_crew")
    assert cb.user_id == "user_crew"
    assert cb._pg is pg


def test_callback_is_callable(pg, session):
    """CrewAICallback should be callable (for step_callback)."""
    cb = CrewAICallback(pg, user_id="user_crew")
    assert callable(cb)


def test_callback_meters_tokens(pg, session):
    """Calling the callback with token_usage should create an event."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={
            "prompt_tokens": 200,
            "completion_tokens": 100,
            "total_tokens": 300,
        },
        model="gpt-4o",
    )
    cb(step)

    assert len(events) == 1
    event = events[0]
    assert event.user_id == "user_crew"
    assert event.model == "gpt-4o"
    assert event.input_tokens == 200
    assert event.output_tokens == 100
    assert event.total_tokens == 300
    assert event.metadata["source"] == "crewai"


def test_callback_calculates_cost(pg, session):
    """Should calculate cost using plan config rates."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={
            "prompt_tokens": 1000,
            "completion_tokens": 500,
            "total_tokens": 1500,
        },
        model="gpt-4o",
    )
    cb(step)

    event = events[0]
    # Cost: (1000/1000)*0.0025 + (500/1000)*0.01 = 0.0075
    assert event.cost_tokens == pytest.approx(0.0075, abs=0.0001)


def test_callback_updates_cache(pg, session):
    """Callback should update the in-memory usage cache."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={
            "prompt_tokens": 100,
            "completion_tokens": 50,
            "total_tokens": 150,
        },
        model="gpt-4o",
    )
    cb(step)

    usage = pg.get_usage("user_crew")
    assert usage.period_tokens_total == 150
    assert usage.period_tokens_by_model.get("gpt-4o") == 150


def test_callback_usage_metrics_attribute(pg, session):
    """Should handle usage_metrics attribute (alternate CrewAI format)."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepWithMetrics(
        usage_metrics={
            "input_tokens": 300,
            "output_tokens": 150,
            "total_tokens": 450,
        },
        model_name="gpt-4o",
    )
    cb(step)

    assert len(events) == 1
    assert events[0].input_tokens == 300
    assert events[0].output_tokens == 150
    assert events[0].model == "gpt-4o"


def test_callback_result_dict_fallback(pg, session):
    """Should extract usage from result dict if token_usage is absent."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage=None,
        model=None,
        result={
            "model": "gpt-4o",
            "usage": {
                "prompt_tokens": 50,
                "completion_tokens": 25,
                "total_tokens": 75,
            },
        },
    )
    cb(step)

    assert len(events) == 1
    assert events[0].total_tokens == 75
    assert events[0].model == "gpt-4o"


def test_callback_skips_non_llm_steps(pg, session):
    """Steps without tokens or model should be skipped."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    # Step with no usage info at all
    step = MockStepOutput(token_usage=None, model=None, result=None)
    cb(step)

    assert len(events) == 0


def test_callback_custom_metadata(pg, session):
    """Custom metadata should be included in events."""
    cb = CrewAICallback(pg, user_id="user_crew", metadata={"crew": "research"})
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        model="gpt-4o",
    )
    cb(step)

    assert events[0].metadata["crew"] == "research"
    assert events[0].metadata["source"] == "crewai"


def test_callback_session_id(pg, session):
    """Session ID should be included in events."""
    cb = CrewAICallback(pg, user_id="user_crew", session_id="sess_xyz")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        model="gpt-4o",
    )
    cb(step)

    assert events[0].session_id == "sess_xyz"


def test_callback_no_session_still_works(pg):
    """Callback should work even without a started session."""
    cb = CrewAICallback(pg, user_id="user_no_session")
    events = []
    pg._event_sink = lambda e: events.append(e)

    step = MockStepOutput(
        token_usage={"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75},
        model="gpt-4o",
    )
    cb(step)

    assert len(events) == 1
    assert events[0].cost_total == 0.0  # No session = no cost


def test_callback_fails_silently_on_error(pg, session):
    """Callback should never raise, even on unexpected input."""
    cb = CrewAICallback(pg, user_id="user_crew")
    # Passing None should not raise
    cb(None)
    # Passing a string should not raise
    cb("unexpected input")
    # Passing an int should not raise
    cb(42)


def test_multiple_steps_accumulate(pg, session):
    """Multiple callback calls should accumulate usage."""
    cb = CrewAICallback(pg, user_id="user_crew")
    events = []
    pg._event_sink = lambda e: events.append(e)

    for i in range(3):
        step = MockStepOutput(
            token_usage={"prompt_tokens": 100, "completion_tokens": 50, "total_tokens": 150},
            model="gpt-4o",
        )
        cb(step)

    assert len(events) == 3
    usage = pg.get_usage("user_crew")
    assert usage.period_tokens_total == 450


# ---------------------------------------------------------------------------
# Dedup: auto-instrumentation active → callback skips metering
# ---------------------------------------------------------------------------


class TestCrewAIDedup:
    """Smart de-dup ("Option A"): mirrors the LangChain integration —
    callback skips ONLY when both instrumentation is active AND a
    ``paygent_context`` is set (i.e. the patcher will actually meter).
    Otherwise the callback meters as the only path.

    See ``TestLangChainDedup`` for full rationale and truth table.
    """

    def _step(self, total: int = 300) -> MockStepOutput:
        return MockStepOutput(
            token_usage={
                "prompt_tokens": total - 100,
                "completion_tokens": 100,
                "total_tokens": total,
            },
            model="gpt-4o",
        )

    # --- 4-cell truth table ---

    def test_instrumented_with_context_skips_to_avoid_double_count(self, pg, session):
        """Patcher on + context set → callback skips."""
        from paygent.context import paygent_context

        pg._instrumentor._instrumented = True
        cb = CrewAICallback(pg, user_id="user_crew")
        events = []
        pg._event_sink = lambda e: events.append(e)

        with paygent_context(user_id="user_crew"):
            cb(self._step(total=300))

        assert events == [], (
            "Patcher would have already metered this call; CrewAI "
            "callback must skip to avoid double-counting."
        )

    def test_instrumented_without_context_still_meters(self, pg, session):
        """Patcher on + NO context → callback meters.

        Regression guard against the naive 'skip whenever instrumented'
        fix — that approach would zero-out metering for any dev who
        attaches a CrewAI callback without ``paygent_context()``.
        """
        pg._instrumentor._instrumented = True
        cb = CrewAICallback(pg, user_id="user_crew")
        events = []
        pg._event_sink = lambda e: events.append(e)

        # NOTE: deliberately no paygent_context() here.
        cb(self._step(total=300))

        assert len(events) == 1
        assert events[0].total_tokens == 300

    def test_not_instrumented_with_context_still_meters(self, pg, session):
        """Patcher off + context set → callback meters."""
        from paygent.context import paygent_context

        assert pg.is_instrumented is False
        cb = CrewAICallback(pg, user_id="user_crew")
        events = []
        pg._event_sink = lambda e: events.append(e)

        with paygent_context(user_id="user_crew"):
            cb(self._step(total=300))

        assert len(events) == 1

    def test_not_instrumented_without_context_still_meters(self, pg, session):
        """Patcher off + NO context → callback meters (the original
        callback-only path)."""
        assert pg.is_instrumented is False
        cb = CrewAICallback(pg, user_id="user_crew")
        events = []
        pg._event_sink = lambda e: events.append(e)

        cb(self._step(total=300))

        assert len(events) == 1
        assert events[0].user_id == "user_crew"

    # --- Hygiene & edge cases ---

    def test_dedup_with_missing_is_instrumented(self):
        """If pg doesn't expose _instrumentor (custom test pg, or future
        SDK refactor), the callback must fall through to metering — fail-open."""
        fake_pg = MagicMock(spec=[])
        fake_pg.get_user_state = MagicMock(return_value=None)
        fake_pg._event_sink = MagicMock()
        fake_pg._usage_handler = MagicMock()

        cb = CrewAICallback(fake_pg, user_id="user_crew")
        cb(self._step(total=75))

        fake_pg._event_sink.assert_called_once()

    # --- on_usage hook firing (the second bug fix) ---

    def test_on_usage_fires_when_callback_meters(self, pg, session):
        """When the CrewAI callback meters, registered ``pg.on_usage(...)``
        callbacks must fire — matching the patcher's contract."""
        captured = []
        pg.on_usage(lambda e: captured.append(e))

        cb = CrewAICallback(pg, user_id="user_crew")
        cb(self._step(total=42))

        assert len(captured) == 1
        assert captured[0].total_tokens == 42

    def test_on_usage_does_not_fire_when_callback_skips(self, pg, session):
        """When the callback skips (de-dup), it must NOT fire on_usage —
        the patcher's wrapper fires it for the real call."""
        from paygent.context import paygent_context

        pg._instrumentor._instrumented = True
        captured = []
        pg.on_usage(lambda e: captured.append(e))

        cb = CrewAICallback(pg, user_id="user_crew")
        with paygent_context(user_id="user_crew"):
            cb(self._step())

        assert captured == []
