"""Tests for Paygent monkey-patching engine."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from paygent.context import get_current_context, paygent_context
from paygent.guardrails import PaygentLimitExceeded
from paygent.models import (
    CurrentUsage,
    GuardResult,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UserSession,
)
from paygent.patcher import (
    PatchState,
    _post_call_processing,
    create_async_wrapper,
    create_sync_wrapper,
    resolve_class,
)
from paygent.providers import ProviderConfig, TokenInfo, extract_openai_tokens


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_openai_response(model="gpt-4o", input_tokens=100, output_tokens=50):
    """Simulate an OpenAI ChatCompletion response."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(
            prompt_tokens=input_tokens,
            completion_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        ),
        choices=[SimpleNamespace(message=SimpleNamespace(content="Hello"))],
    )


def _make_session(
    user_id="user_1",
    plan="pro",
    period_cost=0.0,
    session_cost=0.0,
    period_tokens_by_model=None,
) -> UserSession:
    return UserSession(
        user_id=user_id,
        plan=plan,
        plan_config=PlanConfig(
            max_spend_per_period=49.00,
            max_spend_per_session=5.00,
            soft_gate_at=0.80,
            hard_gate_at=1.00,
            model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=50_000)},
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        ),
        current_usage=CurrentUsage(
            period_cost=period_cost,
            session_cost=session_cost,
            period_tokens_by_model=period_tokens_by_model or {},
        ),
    )


def _make_provider() -> ProviderConfig:
    return ProviderConfig(
        name="test_openai",
        module_path="openai.resources.chat.completions",
        class_name="Completions",
        method_name="create",
        extract_tokens=extract_openai_tokens,
    )


# ---------------------------------------------------------------------------
# PatchState
# ---------------------------------------------------------------------------


class TestPatchState:
    def test_empty_state(self):
        state = PatchState()
        assert state.patched_count == 0
        assert not state.is_patched("some.key")

    def test_save_and_check(self):
        state = PatchState()

        class FakeClass:
            pass

        state.save("mod.Cls.method", FakeClass, "method", lambda: None)
        assert state.patched_count == 1
        assert state.is_patched("mod.Cls.method")

    def test_restore_all(self):
        state = PatchState()

        class FakeClass:
            original_method = lambda self: "original"

        original = FakeClass.original_method
        FakeClass.original_method = lambda self: "patched"
        state.save("mod.Cls.method", FakeClass, "original_method", original)

        count = state.restore_all()
        assert count == 1
        assert state.patched_count == 0
        assert FakeClass.original_method is original

    def test_restore_clears_state(self):
        state = PatchState()

        class FakeClass:
            m = None

        state.save("key", FakeClass, "m", "orig")
        state.restore_all()
        assert not state.is_patched("key")


# ---------------------------------------------------------------------------
# Sync Wrapper
# ---------------------------------------------------------------------------


class TestSyncWrapper:
    def test_passthrough_without_context(self):
        """Without paygent_context, wrapper calls original directly."""
        events = []
        sessions = {}

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        # No context — should pass through
        result = wrapper(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"
        assert len(events) == 0  # No metering

    def test_meters_with_context(self):
        """With context and session, wrapper meters the call."""
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[])

        assert result.model == "gpt-4o"
        assert len(events) == 1
        assert events[0].user_id == "user_1"
        assert events[0].model == "gpt-4o"
        assert events[0].input_tokens == 100
        assert events[0].output_tokens == 50

    def test_updates_cache_after_metering(self):
        """Cache should be updated with the metered event."""
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            wrapper(model="gpt-4o", messages=[])

        assert session.current_usage.period_cost > 0
        assert session.current_usage.period_tokens_by_model.get("gpt-4o", 0) > 0

    def test_hard_gate_raises(self):
        """Hard gate should raise PaygentLimitExceeded."""
        session = _make_session(period_cost=49.00)  # at 100% of limit
        sessions = {"user_1": session}

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
            raise_on_hard_gate=True,
        )

        with pytest.raises(PaygentLimitExceeded) as exc_info:
            with paygent_context(user_id="user_1"):
                wrapper(model="gpt-4o", messages=[])

        assert exc_info.value.guard_result.status == "hard_gate"

    def test_hard_gate_no_raise_passes_through(self):
        """With raise_on_hard_gate=False, hard gate lets call proceed."""
        session = _make_session(period_cost=49.00)
        sessions = {"user_1": session}

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
            raise_on_hard_gate=False,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"  # Call went through

    def test_soft_gate_fires_callback(self):
        """Soft gate should invoke the soft_gate_handler."""
        # 80% of $49 = $39.20
        session = _make_session(period_cost=40.00)
        sessions = {"user_1": session}
        soft_results = []

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
            soft_gate_handler=lambda r: soft_results.append(r),
        )

        with paygent_context(user_id="user_1"):
            wrapper(model="gpt-4o", messages=[])

        assert len(soft_results) == 1
        assert soft_results[0].status == "soft_gate"

    def test_no_session_still_works(self):
        """If session lookup returns None, call proceeds without guardrails."""
        events = []

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: None,  # No session
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[])

        assert result.model == "gpt-4o"
        # Event still created (but with no plan config, costs are 0)
        assert len(events) == 1

    def test_session_lookup_error_fails_open(self):
        """If session_lookup raises, call proceeds."""

        def broken_lookup(uid):
            raise RuntimeError("DB down")

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=broken_lookup,
            event_sink=lambda e: None,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"

    def test_event_sink_error_fails_open(self):
        """If event_sink raises, response is still returned."""
        session = _make_session()
        sessions = {"user_1": session}

        def broken_sink(event):
            raise RuntimeError("Queue full")

        def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=broken_sink,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"

    def test_preserves_wrapper_attributes(self):
        """Wrapper should have __wrapped__ and _paygent_patched."""

        def original_create(**kwargs):
            return None

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )

        assert wrapper._paygent_patched is True
        assert wrapper.__wrapped__ is original_create


# ---------------------------------------------------------------------------
# Async Wrapper
# ---------------------------------------------------------------------------


class TestAsyncWrapper:
    @pytest.fixture(autouse=True)
    def _setup(self):
        """Ensure clean context for each test."""
        yield

    @pytest.mark.asyncio
    async def test_passthrough_without_context(self):
        """Without context, async wrapper passes through."""
        events = []

        async def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_async_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: None,
            event_sink=lambda e: events.append(e),
        )

        result = await wrapper(model="gpt-4o", messages=[])
        assert result.model == "gpt-4o"
        assert len(events) == 0

    @pytest.mark.asyncio
    async def test_meters_with_context(self):
        """Async wrapper meters usage when context is set."""
        events = []
        session = _make_session()
        sessions = {"user_1": session}

        async def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_async_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            result = await wrapper(model="gpt-4o", messages=[])

        assert result.model == "gpt-4o"
        assert len(events) == 1
        assert events[0].user_id == "user_1"

    @pytest.mark.asyncio
    async def test_hard_gate_raises(self):
        """Async hard gate raises PaygentLimitExceeded."""
        session = _make_session(period_cost=49.00)
        sessions = {"user_1": session}

        async def original_create(**kwargs):
            return _make_openai_response()

        wrapper = create_async_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda e: None,
        )

        with pytest.raises(PaygentLimitExceeded):
            with paygent_context(user_id="user_1"):
                await wrapper(model="gpt-4o", messages=[])

    @pytest.mark.asyncio
    async def test_preserves_attributes(self):
        async def original_create(**kwargs):
            return None

        wrapper = create_async_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: None,
            event_sink=lambda e: None,
        )

        assert wrapper._paygent_patched is True
        assert wrapper.__wrapped__ is original_create


# ---------------------------------------------------------------------------
# resolve_class
# ---------------------------------------------------------------------------


class TestResolveClass:
    def test_resolve_builtin(self):
        """Should resolve classes from stdlib modules."""
        cls = resolve_class("collections", "OrderedDict")
        assert cls is not None

    def test_missing_module(self):
        """Missing module returns None (not installed)."""
        cls = resolve_class("nonexistent_module_xyz", "Foo")
        assert cls is None

    def test_missing_class(self):
        """Module exists but class doesn't — returns None."""
        cls = resolve_class("collections", "NonexistentClass")
        assert cls is None


# ---------------------------------------------------------------------------
# Post-call processing
# ---------------------------------------------------------------------------


class TestPostCallProcessing:
    def test_basic_processing(self):
        """Processes response and pushes event to sink."""
        events = []
        session = _make_session()
        response = _make_openai_response()

        _post_call_processing(
            response=response,
            provider=_make_provider(),
            session=session,
            ctx_user_id="user_1",
            ctx_session_id="sess_1",
            ctx_metadata={"key": "val"},
            event_sink=lambda e: events.append(e),
        )

        assert len(events) == 1
        assert events[0].user_id == "user_1"
        assert events[0].session_id == "sess_1"
        assert events[0].model == "gpt-4o"

    def test_broken_provider_extractor(self):
        """If extract_tokens fails, processing is skipped silently."""
        events = []

        def broken_extractor(resp):
            raise RuntimeError("Parse failed")

        provider = ProviderConfig(
            name="broken",
            module_path="x",
            class_name="X",
            method_name="create",
            extract_tokens=broken_extractor,
        )

        _post_call_processing(
            response="garbage",
            provider=provider,
            session=None,
            ctx_user_id="u1",
            ctx_session_id=None,
            ctx_metadata=None,
            event_sink=lambda e: events.append(e),
        )

        assert len(events) == 0  # Skipped

    def test_no_session_still_creates_event(self):
        """With no session, event is still created (zero cost)."""
        events = []
        response = _make_openai_response()

        _post_call_processing(
            response=response,
            provider=_make_provider(),
            session=None,
            ctx_user_id="u1",
            ctx_session_id=None,
            ctx_metadata=None,
            event_sink=lambda e: events.append(e),
        )

        assert len(events) == 1
        assert events[0].cost_total == 0.0  # No plan config → zero cost


# ---------------------------------------------------------------------------
# sdk_enabled Flag
# ---------------------------------------------------------------------------


class TestSdkEnabled:
    """Tests for sdk_enabled pass-through behavior."""

    def test_sdk_disabled_skips_guard_and_metering(self):
        """When sdk_enabled=False, LLM call executes but no guard/meter."""
        session = _make_session()
        session.sdk_enabled = False
        events: list = []
        guard_called = False

        def fake_guard_handler(result):
            nonlocal guard_called
            guard_called = True

        wrapper = create_sync_wrapper(
            original=lambda *a, **kw: _make_openai_response(),
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=lambda e: events.append(e),
            soft_gate_handler=fake_guard_handler,
            hard_gate_handler=fake_guard_handler,
        )

        with paygent_context(user_id="user_1"):
            response = wrapper(model="gpt-4o", messages=[])

        # Response is returned normally
        assert response.choices[0].message.content == "Hello"
        # But no events were created and no guard was called
        assert len(events) == 0
        assert guard_called is False
        # Usage unchanged
        assert session.current_usage.period_cost == 0.0
        assert session.current_usage.period_tokens_total == 0

    def test_sdk_enabled_true_meters_normally(self):
        """When sdk_enabled=True (default), normal metering occurs."""
        session = _make_session()
        assert session.sdk_enabled is True  # default
        events: list = []

        wrapper = create_sync_wrapper(
            original=lambda *a, **kw: _make_openai_response(),
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            wrapper(model="gpt-4o", messages=[])

        assert len(events) == 1
        assert session.current_usage.period_tokens_total > 0

    @pytest.mark.asyncio
    async def test_sdk_disabled_async_skips_guard_and_metering(self):
        """Async wrapper also respects sdk_enabled=False."""
        session = _make_session()
        session.sdk_enabled = False
        events: list = []

        async def fake_llm(*a, **kw):
            return _make_openai_response()

        wrapper = create_async_wrapper(
            original=fake_llm,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=lambda e: events.append(e),
        )

        with paygent_context(user_id="user_1"):
            response = await wrapper(model="gpt-4o", messages=[])

        assert response.choices[0].message.content == "Hello"
        assert len(events) == 0
        assert session.current_usage.period_cost == 0.0

    def test_sdk_disabled_does_not_block_hard_gate(self):
        """When sdk_enabled=False, even a user at limit is NOT blocked."""
        session = _make_session(period_cost=49.00)  # at hard gate
        session.sdk_enabled = False

        wrapper = create_sync_wrapper(
            original=lambda *a, **kw: _make_openai_response(),
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=lambda e: None,
            raise_on_hard_gate=True,
        )

        with paygent_context(user_id="user_1"):
            # Should NOT raise PaygentLimitExceeded
            response = wrapper(model="gpt-4o", messages=[])

        assert response.choices[0].message.content == "Hello"


# ---------------------------------------------------------------------------
# Stream integration
# ---------------------------------------------------------------------------


class _FakeStream:
    """Minimal Stream stand-in: iterable, has __next__, no .usage until consumed.

    Mimics the shape of openai.Stream / anthropic.Stream closely enough
    that ``_is_stream_response`` classifies it correctly.
    """

    def __init__(self, chunks):
        self._chunks = list(chunks)
        self._idx = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._idx >= len(self._chunks):
            raise StopIteration
        c = self._chunks[self._idx]
        self._idx += 1
        return c

    def close(self):
        pass


class _FakeAsyncStream:
    """Async Stream stand-in."""

    def __init__(self, chunks):
        self._chunks = list(chunks)
        self._idx = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._idx >= len(self._chunks):
            raise StopAsyncIteration
        c = self._chunks[self._idx]
        self._idx += 1
        return c

    async def aclose(self):
        pass


def _usage_chunk(input_tokens=10, output_tokens=5, model="gpt-4o"):
    """A trailing chunk that mimics OpenAI's include_usage=True payload."""
    return SimpleNamespace(
        model=model,
        usage=SimpleNamespace(
            prompt_tokens=input_tokens,
            completion_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        ),
        choices=[],
    )


def _content_chunk(content="x"):
    """A regular streaming content chunk — no usage on these."""
    return SimpleNamespace(
        choices=[SimpleNamespace(delta=SimpleNamespace(content=content))],
    )


class TestSyncStreamIntegration:
    """The patched sync wrapper must detect streams, defer metering
    until they finish, and return a StreamWrapper that yields every
    chunk unchanged."""

    def test_stream_response_returns_wrapper_and_defers_metering(self):
        events = []
        session = _make_session()

        def original_create(**kwargs):
            return _FakeStream([
                _content_chunk("he"),
                _content_chunk("llo"),
                _usage_chunk(input_tokens=12, output_tokens=7),
            ])

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=events.append,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(model="gpt-4o", messages=[], stream=True)

        # Not a raw Stream — the wrapper replaced it.
        from paygent.stream_wrapper import StreamWrapper
        assert isinstance(result, StreamWrapper)

        # BEFORE consumption: no metering has fired.
        assert events == []

        # Consume the stream — metering should fire exactly once at StopIteration.
        consumed = list(result)
        assert len(consumed) == 3
        assert len(events) == 1
        # The metered event uses tokens from the final include_usage chunk.
        event = events[0]
        assert event.input_tokens == 12
        assert event.output_tokens == 7
        assert event.total_tokens == 19

    def test_stream_chunks_pass_through_unchanged(self):
        """StreamWrapper must yield the exact chunks the dev would have
        received without Paygent (content-preserving middleware)."""
        session = _make_session()

        def original_create(**kwargs):
            return _FakeStream([
                _content_chunk("one"),
                _content_chunk("two"),
                _usage_chunk(),
            ])

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=lambda e: None,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(stream=True)

        out = list(result)
        assert out[0].choices[0].delta.content == "one"
        assert out[1].choices[0].delta.content == "two"
        assert out[2].usage.total_tokens == 15

    def test_non_stream_response_still_meters_inline(self):
        """Non-stream path is unchanged — regression guard."""
        events = []
        session = _make_session()

        def original_create(**kwargs):
            return _make_openai_response(input_tokens=100, output_tokens=50)

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=events.append,
        )

        with paygent_context(user_id="user_1"):
            response = wrapper()

        # Metering fired synchronously — no stream to defer on
        assert len(events) == 1
        assert events[0].total_tokens == 150
        # Non-stream response returned as-is (not wrapped)
        assert response is not None
        from paygent.stream_wrapper import StreamWrapper
        assert not isinstance(response, StreamWrapper)

    def test_stream_without_usage_chunk_meters_zero(self):
        """Stream with no usage data → meters with zero tokens (no crash)."""
        events = []
        session = _make_session()

        def original_create(**kwargs):
            return _FakeStream([_content_chunk("a"), _content_chunk("b")])

        wrapper = create_sync_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=events.append,
        )

        with paygent_context(user_id="user_1"):
            result = wrapper(stream=True)
            list(result)

        assert len(events) == 1
        assert events[0].total_tokens == 0


class TestAsyncStreamIntegration:
    """Async wrapper must wrap async streams and defer metering."""

    def test_async_stream_wrapper_defers_metering(self):
        import asyncio
        events = []
        session = _make_session()

        async def original_create(**kwargs):
            return _FakeAsyncStream([
                _content_chunk("hel"),
                _content_chunk("lo"),
                _usage_chunk(input_tokens=8, output_tokens=3),
            ])

        wrapper = create_async_wrapper(
            original=original_create,
            provider=_make_provider(),
            session_lookup=lambda uid: session,
            event_sink=events.append,
        )

        async def run():
            with paygent_context(user_id="user_1"):
                result = await wrapper(stream=True)
                from paygent.stream_wrapper import AsyncStreamWrapper
                assert isinstance(result, AsyncStreamWrapper)
                # Not metered yet
                assert events == []
                chunks = []
                async for chunk in result:
                    chunks.append(chunk)
                return chunks

        chunks = asyncio.get_event_loop().run_until_complete(run())
        assert len(chunks) == 3
        assert len(events) == 1
        assert events[0].total_tokens == 11
