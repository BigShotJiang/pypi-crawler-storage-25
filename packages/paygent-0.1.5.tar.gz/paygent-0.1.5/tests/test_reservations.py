"""Tests for the two-phase reservation pattern.

The reservation pattern protects concurrent calls for the same user from
overshooting the hard-gate boundary.  Key invariants:

1. Under concurrency, the number of calls that pass the guard is bounded
   by headroom / (reserved-per-call).  No "all 50 see fresh state and all
   pass" races.
2. On LLM call failure, the reservation is released so concurrent callers
   don't see a ghost hold.
3. On metering failure, reservation is released too.
4. Finalize replaces the reservation with the ACTUAL event cost — no
   net inflation of recorded spend.
5. ``pg.get_usage()`` returns real spend, not reservations.  (The
   CurrentUsage object carries reserved_* fields but they're zero
   between calls.)
6. The per-user lock is NOT held across the await boundary — multiple
   concurrent calls for one user still run their LLM network I/O in
   parallel.  Only the guard+reserve and finalize windows serialize.
"""

from __future__ import annotations

import asyncio
import os
import tempfile
import threading
import time
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from paygent import paygent_context
from paygent.core import Paygent
from paygent.guardrails import PaygentLimitExceeded
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tmp_db_path() -> str:
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return tmp.name


def _make_pg(**kwargs) -> Paygent:
    defaults = dict(
        db_path=_tmp_db_path(),
        auto_instrument=False,
        flush_interval=60.0,
    )
    defaults.update(kwargs)
    return Paygent.init(**defaults)


def _cleanup(pg: Paygent) -> None:
    db_path = pg.storage.db_path
    try:
        pg.shutdown()
    except Exception:
        pass
    try:
        os.unlink(db_path)
    except OSError:
        pass


class FakeResp:
    """Minimal OpenAI-shaped response."""

    def __init__(self, model="gpt-4o", input_tokens=100, output_tokens=50):
        self.model = model
        self.usage = SimpleNamespace(
            prompt_tokens=input_tokens,
            completion_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        )


# ---------------------------------------------------------------------------
# Scenario 4: asyncio.gather — all fit in budget
# ---------------------------------------------------------------------------


class TestAsyncGather:
    """Concurrent ``awrap`` calls for one user inside ``asyncio.gather``."""

    def test_all_fit_in_budget(self):
        """3 concurrent calls, plenty of headroom → all succeed, totals match."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=10.0,
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            async def fake_call(delay=0.01):
                await asyncio.sleep(delay)
                return FakeResp(model="gpt-4o", input_tokens=100, output_tokens=50)

            async def run():
                return await asyncio.gather(
                    pg.awrap(fake_call(), user_id="u1", model="gpt-4o"),
                    pg.awrap(fake_call(), user_id="u1", model="gpt-4o"),
                    pg.awrap(fake_call(), user_id="u1", model="gpt-4o"),
                )

            results = asyncio.run(run())
            assert len(results) == 3
            usage = pg.get_usage("u1")
            # 3 × 150 tokens = 450
            assert usage.period_tokens_total == 450
            # After all calls finalize, reservations are zero
            assert usage.reserved_cost == 0.0
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
        finally:
            _cleanup(pg)

    def test_one_busts_boundary_with_reservation(self):
        """User at boundary: 3 concurrent calls, budget for ~2.  The
        reservation pattern must cause the 3rd to be hard-gated at the
        guard check (because it sees the first two's reservations)."""
        pg = _make_pg()
        try:
            # Tight budget: $0.00015 remaining.  Each call estimates
            # ~100 input + 4096 buffer output = ~$0.004 with safety factor.
            # With reservations present, the 3rd+ calls see the hold.
            config = PlanConfig(
                max_spend_per_period=0.01,  # $0.01 cap
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
                reservation_safety_factor=1.2,
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            # Pre-seed so only ~1 call fits after safety factor
            session.current_usage.period_cost = 0.008  # $0.002 headroom

            # Use a slow fake call to force the first reservations to
            # register BEFORE the later guard checks read state.
            entry_order = []
            entry_barrier = asyncio.Event()

            async def slow_call(tag: str):
                entry_order.append(tag)
                await entry_barrier.wait()
                return FakeResp(model="gpt-4o", input_tokens=10, output_tokens=5)

            async def run():
                # Start 3 coroutines, then release them together after
                # all 3 have hit the guard+reserve step.
                # (The guard+reserve runs BEFORE the first await in awrap,
                # so by the time slow_call is entered, the reservation is
                # already applied.)
                tasks = [
                    asyncio.create_task(
                        pg.awrap(slow_call(f"c{i}"), user_id="u1", model="gpt-4o")
                    )
                    for i in range(3)
                ]
                # Let all 3 reach their awaits
                await asyncio.sleep(0.05)
                entry_barrier.set()
                # Collect results, swallowing PaygentLimitExceeded
                results = []
                for t in tasks:
                    try:
                        results.append(await t)
                    except PaygentLimitExceeded as e:
                        results.append(e)
                return results

            results = asyncio.run(run())

            # At least one call should have been hard-gated by reservation
            # visibility.  Without reservations, all 3 would have passed
            # the guard (seeing the same stale period_cost).
            blocked = [r for r in results if isinstance(r, PaygentLimitExceeded)]
            succeeded = [r for r in results if not isinstance(r, PaygentLimitExceeded)]

            assert len(blocked) >= 1, (
                f"Expected at least 1 call to be blocked by reservation; "
                f"all {len(succeeded)} succeeded (reservation pattern not working)."
            )
            # Blocked calls cite spend_limit
            for b in blocked:
                assert b.guard_result.status == "hard_gate"
                assert b.guard_result.gate_reason in (
                    "total_spend", "session_spend",
                )
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Scenario 5: threaded burst at a hard-gate boundary
# ---------------------------------------------------------------------------


class TestThreadedBurst:
    """Many threads, one user at the hard-gate boundary."""

    def test_burst_at_boundary_bounded_by_reservations(self):
        """User right at the boundary.  20 threads each call wrap().

        Before reservations: all 20 could pass the guard (all see the same
        pre-call state).  With reservations: some get through, the rest
        are blocked.  We assert the number that pass is bounded (much less
        than 20) and that no exception other than PaygentLimitExceeded
        bubbles up.
        """
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={
                    "gpt-4o": ModelLimitConfig(max_tokens_per_period=1000),
                },
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
                reservation_safety_factor=1.2,
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            # Right at the boundary: 900 of 1000 tokens used.
            # Each call estimates input + 4096 output ≈ 4196 tokens.
            # With factor 1.2, reservation ≈ 5035 tokens — already over.
            # First call: guard passes (sees 900 + 0 reserved < 1000).
            # That call reserves ~5035. Subsequent calls see 900 + 5035 > 1000 → blocked.
            session.current_usage.period_tokens_by_model["gpt-4o"] = 900

            succeeded = []
            blocked = []
            barrier = threading.Barrier(20)

            def worker():
                barrier.wait()  # ensure all threads hit the guard simultaneously
                try:
                    resp = pg.wrap(
                        lambda: FakeResp(model="gpt-4o", input_tokens=10, output_tokens=5),
                        user_id="u1",
                        model="gpt-4o",
                    )
                    succeeded.append(resp)
                except PaygentLimitExceeded:
                    blocked.append(True)

            threads = [threading.Thread(target=worker) for _ in range(20)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()

            # Reservation pattern bounds successes.  Without reservations,
            # all 20 would pass the initial guard (all see the same
            # pre-call state) — that's the Scenario 5 bug we're fixing.
            # With reservations, each reservation consumes ~5k tokens of
            # a 100-token headroom so only a handful slip through.
            # Threads that finalize early release their reservation, which
            # can let a few more through before the headroom is exhausted
            # again — hence this is bounded but not strict.
            assert len(succeeded) + len(blocked) == 20
            assert len(blocked) >= 10, (
                f"Expected many calls blocked by reservations; "
                f"{len(succeeded)} got through, {len(blocked)} blocked. "
                f"Without reservations this would be ~20 succeeded, 0 blocked."
            )
            # No ghost reservations left
            usage = pg.get_usage("u1")
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Reservation release on exception
# ---------------------------------------------------------------------------


class TestReservationRollback:
    """Reservations must be released when calls fail."""

    def test_llm_call_exception_releases_reservation_wrap(self):
        """wrap(): if the inner callable raises, reservation is released."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=1.0,
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            def failing_call():
                raise RuntimeError("upstream 429")

            with pytest.raises(RuntimeError):
                pg.wrap(failing_call, user_id="u1", model="gpt-4o")

            usage = pg.get_usage("u1")
            # No reservation lingering
            assert usage.reserved_cost == 0.0
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
            # No actual spend either
            assert usage.period_cost == 0.0
        finally:
            _cleanup(pg)

    def test_llm_call_exception_releases_reservation_awrap(self):
        """awrap(): same, for async."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=1.0,
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            async def failing_call():
                raise RuntimeError("upstream 500")

            async def run():
                await pg.awrap(failing_call(), user_id="u1", model="gpt-4o")

            with pytest.raises(RuntimeError):
                asyncio.run(run())

            usage = pg.get_usage("u1")
            assert usage.reserved_cost == 0.0
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
            assert usage.period_cost == 0.0
        finally:
            _cleanup(pg)

    def test_metering_failure_still_releases_reservation(self, monkeypatch):
        """If post-call metering (e.g. extract_tokens) raises, the
        reservation is still released — it doesn't leak."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=1.0,
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            # Monkeypatch the extractor to blow up
            def broken_extract(self, response, provider_name=None):
                raise RuntimeError("broken extractor")
            monkeypatch.setattr(
                Paygent, "_extract_tokens_for_wrap", broken_extract,
            )

            # Call succeeds (wrap is fail-open on metering errors)
            pg.wrap(
                lambda: FakeResp(), user_id="u1", model="gpt-4o",
            )

            usage = pg.get_usage("u1")
            # Reservation released even though metering failed
            assert usage.reserved_cost == 0.0
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Finalize accuracy: reservations don't inflate recorded spend
# ---------------------------------------------------------------------------


class TestFinalizeAccuracy:
    """After finalize, recorded spend == actual (not reservation-inflated)."""

    def test_finalize_records_actual_not_reservation(self):
        """Reserve $0.012 worst-case, actual is $0.008 → store $0.008."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
                reservation_safety_factor=2.0,  # inflate reservation heavily
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            pg.wrap(
                lambda: FakeResp(model="gpt-4o", input_tokens=100, output_tokens=50),
                user_id="u1",
                model="gpt-4o",
            )

            usage = pg.get_usage("u1")
            # 150 tokens × $0.001/1K = $0.00015 — the ACTUAL cost
            assert usage.period_tokens_total == 150
            assert usage.period_cost == pytest.approx(0.00015, rel=1e-6)
            # Reservation released after finalize
            assert usage.reserved_cost == 0.0
            assert usage.reserved_tokens_by_model.get("gpt-4o", 0) == 0
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Safety factor tuning
# ---------------------------------------------------------------------------


class TestSafetyFactor:
    """Higher safety factor blocks concurrent calls more aggressively."""

    def test_higher_factor_blocks_more_at_boundary(self):
        """With factor=2.0, fewer concurrent calls slip through than with 1.0."""
        # Scenario: 10 concurrent threads, per-model limit, some headroom.
        def run_with_factor(factor: float) -> int:
            pg = _make_pg()
            try:
                config = PlanConfig(
                    model_limits={
                        "gpt-4o": ModelLimitConfig(max_tokens_per_period=10_000),
                    },
                    cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
                    reservation_safety_factor=factor,
                )
                session = pg.start_session("u1", plan="pro", plan_config=config)
                session.current_usage.period_tokens_by_model["gpt-4o"] = 5_000

                succeeded = 0
                lock = threading.Lock()
                barrier = threading.Barrier(10)

                def worker():
                    nonlocal succeeded
                    barrier.wait()
                    try:
                        pg.wrap(
                            lambda: FakeResp(model="gpt-4o", input_tokens=10, output_tokens=5),
                            user_id="u1",
                            model="gpt-4o",
                        )
                        with lock:
                            succeeded += 1
                    except PaygentLimitExceeded:
                        pass

                threads = [threading.Thread(target=worker) for _ in range(10)]
                for t in threads: t.start()
                for t in threads: t.join()
                return succeeded
            finally:
                _cleanup(pg)

        low_factor = run_with_factor(1.0)
        high_factor = run_with_factor(2.0)

        # With the larger reservation multiplier, FEWER calls slip through.
        # (Each reservation consumes more of the headroom, so fewer fit.)
        assert high_factor <= low_factor, (
            f"Expected higher safety factor to block more calls; "
            f"low={low_factor}, high={high_factor}"
        )


# ---------------------------------------------------------------------------
# estimated_tokens kwarg on wrap/awrap
# ---------------------------------------------------------------------------


class TestEstimatedTokensKwarg:
    """Devs can pass explicit estimates to wrap/awrap for better reservations."""

    def test_wrap_accepts_estimated_kwargs_affects_reservation_size(self):
        """estimated_input_tokens/estimated_max_tokens kwargs control the
        reservation size seen by concurrent callers.  Larger estimates →
        larger reservation → more concurrent calls get blocked.

        Uses ``pre_call_estimate=True`` so the guard itself looks at the
        estimate (not just the reservation).  With a massive
        ``estimated_max_tokens``, the SAME call that would pass without
        estimate-hints should be blocked.
        """
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={
                    "gpt-4o": ModelLimitConfig(max_tokens_per_period=1000),
                },
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
                pre_call_estimate=True,  # so estimate feeds the guard
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 900

            # Without estimate hints, wrap() defaults to 0 input / 4096
            # buffer.  900 + 0 + 4096 = 4996 >> 1000 → hard gate.
            # With explicit small estimates (5/5), 900 + 5 + 5 = 910 < 1000
            # → passes.
            pg.wrap(
                lambda: FakeResp(model="gpt-4o", input_tokens=5, output_tokens=5),
                user_id="u1",
                model="gpt-4o",
                estimated_input_tokens=5,
                estimated_max_tokens=5,
            )

            # Now pass a massive estimated_max_tokens that puts us over
            # the cap at pre-call estimation.  Reset usage to the same
            # starting point so the actual spent tokens are the only var.
            session.current_usage.period_tokens_by_model["gpt-4o"] = 900
            with pytest.raises(PaygentLimitExceeded):
                pg.wrap(
                    lambda: FakeResp(),
                    user_id="u1",
                    model="gpt-4o",
                    estimated_input_tokens=50,
                    estimated_max_tokens=1000,  # 900 + 50 + 1000 > 1000
                )
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# get_usage does not surface reservations as "spend"
# ---------------------------------------------------------------------------


class TestGetUsageHidesReservations:
    """Reservations appear on the CurrentUsage object but are NOT what the
    dev thinks of as "spend".  The period_cost / period_tokens fields
    reflect finalized spend only."""

    def test_get_usage_period_cost_excludes_reservations(self):
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            session = pg.start_session("u1", plan="pro", plan_config=config)
            # Manually apply a reservation
            from paygent.metering import apply_reservation
            apply_reservation(session, "gpt-4o", cost=5.0, tokens=1000)

            usage = pg.get_usage("u1")
            # period_cost is what was ACTUALLY spent — not the reservation
            assert usage.period_cost == 0.0
            assert usage.period_tokens_total == 0
            # But reserved_* fields ARE visible on the snapshot for diagnostics
            assert usage.reserved_cost == 5.0
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Lock is NOT held across await (concurrency preserved)
# ---------------------------------------------------------------------------


class TestLockNotHeldAcrossAwait:
    """Critical invariant: the per-user lock is released before the LLM
    network call, so concurrent calls for the same user still run their
    network I/O in parallel.  Only the guard+reserve and finalize windows
    are serialized."""

    def test_concurrent_awrap_runs_in_parallel(self):
        """5 concurrent awrap calls for one user, each with a 0.1s fake
        delay.  If the lock were held across the await, total time would
        be ~0.5s.  With lock released, total is ~0.1s."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                max_spend_per_period=100.0,
                cost_rates={"gpt-4o": ModelCostRate(input=0.001, output=0.001)},
            )
            pg.start_session("u1", plan="pro", plan_config=config)

            async def fake_call():
                await asyncio.sleep(0.1)
                return FakeResp(model="gpt-4o", input_tokens=10, output_tokens=5)

            async def run():
                start = time.perf_counter()
                await asyncio.gather(
                    *[
                        pg.awrap(fake_call(), user_id="u1", model="gpt-4o")
                        for _ in range(5)
                    ]
                )
                return time.perf_counter() - start

            elapsed = asyncio.run(run())

            # Serialized would be ~0.5s.  Parallel is ~0.1s.
            # Allow generous headroom to account for lock contention
            # and event-loop overhead — the key is "much less than 0.5s".
            assert elapsed < 0.3, (
                f"Concurrent awrap appears serialized: {elapsed:.2f}s "
                f"for 5 × 0.1s calls (expected ~0.1s)"
            )
        finally:
            _cleanup(pg)


# ---------------------------------------------------------------------------
# Regression: reservation key must match between apply and finalize
#
# Originally observed by a user: after a clean LLM call,
# `current_usage.reserved_tokens_by_model` was left with leftover tokens:
#     reserved_cost=0.0  reserved_tokens_by_model={'gpt-4o-mini': 14}
#
# Root cause: apply_reservation stored the hold under the model NAME the
# user passed to the API (e.g. "gpt-4o-mini"), but finalize_reservation
# released using `event.model`, which is the provider's VERSIONED name
# after normalization through cost_rates/model_limits.  When the plan had
# no rate/limit entry for "gpt-4o-mini", normalize_model_name returned
# the versioned name as-is ("gpt-4o-mini-2024-07-18"), so release tried
# a different dict key and the hold leaked.
#
# On every subsequent call the hold grew — slow-burn DoS where the guard
# check's `reserved + estimated` inflates over time until it starts
# false-positive-blocking legitimate calls for a user well under the cap.
#
# Fix:
#   1. finalize_reservation accepts reservation_model explicitly; when
#      provided, it uses that key for release instead of event.model.
#   2. Patcher / wrap / awrap normalize model_hint ONCE at apply time
#      and pass the same normalized value through to finalize.
# ---------------------------------------------------------------------------


class TestReservationKeyConsistency:
    """Reservation apply/release must use the same dict key even when
    the provider's response has a versioned model name."""

    def _make_config_no_rate_for_mini(self) -> PlanConfig:
        """A realistic plan where gpt-4o-mini has NO cost rate — this is
        the trigger for the bug.  normalize_model_name only consults
        cost_rates + model_limits; with neither entry for gpt-4o-mini,
        the versioned response name wouldn't normalize back to the
        user-passed alias."""
        return PlanConfig(
            max_spend_per_period=10.00,
            max_spend_per_session=5.00,
            # Only gpt-4o has a rate — gpt-4o-mini is deliberately absent
            # so normalize_model_name can't bridge "gpt-4o-mini-2024-07-18"
            # back to "gpt-4o-mini".
            cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
        )

    def test_finalize_clears_reservation_when_provider_returns_versioned_model(self):
        """The bug the user reported.  Apply with 'gpt-4o-mini', event
        model is 'gpt-4o-mini-2024-07-18' — after finalize, reserved
        fields MUST be zero/empty."""
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
        )
        from paygent.models import UsageEvent, UserState

        state = UserState(
            user_id="user_bug",
            plan="free",
            plan_config=self._make_config_no_rate_for_mini(),
            current_usage=CurrentUsage(),
        )

        # Simulate what the patcher does: apply under the user-passed name
        apply_reservation(state, "gpt-4o-mini", cost=0.0, tokens=14)
        assert state.current_usage.reserved_tokens_by_model == {"gpt-4o-mini": 14}

        # Provider returns the versioned name in the response
        event = UsageEvent(
            user_id="user_bug",
            model="gpt-4o-mini-2024-07-18",
            input_tokens=5,
            output_tokens=2,
            total_tokens=7,
            cost_tokens=0.0,
            cost_total=0.0,
        )

        # Fixed finalize: pass the reservation_model (the key apply used)
        finalize_reservation(
            state, event,
            reserved_cost=0.0,
            reserved_tokens=14,
            reservation_model="gpt-4o-mini",
        )

        assert state.current_usage.reserved_cost == 0.0, (
            "reserved_cost should be released"
        )
        assert state.current_usage.reserved_tokens_by_model == {}, (
            f"reserved_tokens_by_model must be emptied on finalize — "
            f"instead got {state.current_usage.reserved_tokens_by_model}. "
            f"This is the exact user-reported leak."
        )

    def test_legacy_finalize_without_reservation_model_still_works_when_names_match(self):
        """Back-compat: if reservation_model isn't passed, finalize falls
        back to event.model — which is the previous behavior and works
        fine as long as the names happen to match."""
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
        )
        from paygent.models import UsageEvent, UserState

        state = UserState(
            user_id="user_match",
            plan="free",
            plan_config=self._make_config_no_rate_for_mini(),
            current_usage=CurrentUsage(),
        )
        apply_reservation(state, "gpt-4o", cost=0.01, tokens=100)
        event = UsageEvent(
            user_id="user_match",
            model="gpt-4o",  # same key — legacy path works
            input_tokens=50,
            output_tokens=20,
            total_tokens=70,
            cost_tokens=0.01,
            cost_total=0.01,
        )
        # No reservation_model kwarg — old callers still work
        finalize_reservation(state, event, reserved_cost=0.01, reserved_tokens=100)
        assert state.current_usage.reserved_cost == 0.0
        assert state.current_usage.reserved_tokens_by_model == {}

    def test_finalize_prefers_explicit_reservation_model_over_event_model(self):
        """When both are provided, the explicit reservation_model arg wins.
        This is the defense-in-depth against future callers who pass both
        by accident."""
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
        )
        from paygent.models import UsageEvent, UserState

        state = UserState(
            user_id="user_explicit",
            plan="free",
            plan_config=self._make_config_no_rate_for_mini(),
            current_usage=CurrentUsage(),
        )
        apply_reservation(state, "held-key", cost=0.0, tokens=50)
        event = UsageEvent(
            user_id="user_explicit",
            model="different-key",
            input_tokens=10,
            output_tokens=5,
            total_tokens=15,
            cost_tokens=0.0,
            cost_total=0.0,
        )
        finalize_reservation(
            state, event,
            reserved_cost=0.0,
            reserved_tokens=50,
            reservation_model="held-key",  # explicit — must win
        )
        assert state.current_usage.reserved_tokens_by_model == {}

    def test_no_leak_after_many_sequential_calls(self):
        """Monotonic-growth regression: before the fix, reserved_tokens
        grew unboundedly call-by-call.  Here we simulate 50 sequential
        calls with the bug's trigger conditions and assert it stays at 0."""
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
        )
        from paygent.models import UsageEvent, UserState

        state = UserState(
            user_id="user_loop",
            plan="free",
            plan_config=self._make_config_no_rate_for_mini(),
            current_usage=CurrentUsage(),
        )
        for i in range(50):
            apply_reservation(state, "gpt-4o-mini", cost=0.0, tokens=14)
            event = UsageEvent(
                user_id="user_loop",
                model="gpt-4o-mini-2024-07-18",
                input_tokens=5,
                output_tokens=2,
                total_tokens=7,
                cost_tokens=0.0,
                cost_total=0.0,
            )
            finalize_reservation(
                state, event,
                reserved_cost=0.0, reserved_tokens=14,
                reservation_model="gpt-4o-mini",
            )

        assert state.current_usage.reserved_cost == 0.0
        assert state.current_usage.reserved_tokens_by_model == {}, (
            f"After 50 sequential calls, reserved tokens should be 0 but got "
            f"{state.current_usage.reserved_tokens_by_model}. "
            f"Before the fix this was {{'gpt-4o-mini': 700}}."
        )

    def test_patcher_normalizes_reservation_key_end_to_end(self):
        """Integration: exercise the REAL patcher code path to confirm
        the patcher now normalizes reservation_model at apply and threads
        it through to finalize.  Uses pg.wrap() because that takes the
        same guard → reserve → finalize code path as auto-instrumented
        calls do, without requiring real OpenAI monkey-patching."""
        pg = _make_pg()
        try:
            # Seed a session with a plan that lacks a rate for gpt-4o-mini
            state = pg.start_session(
                "user_e2e",
                plan="free",
                plan_config=self._make_config_no_rate_for_mini(),
            )

            # Mock a call that returns a versioned model name
            def fake_llm_call():
                return FakeResp(
                    model="gpt-4o-mini-2024-07-18",  # provider's versioned name
                    input_tokens=100,
                    output_tokens=50,
                )

            # User passes the short alias
            pg.wrap(fake_llm_call, user_id="user_e2e", model="gpt-4o-mini")

            # After a clean call, reservations must be fully released
            assert state.current_usage.reserved_cost == 0.0
            assert state.current_usage.reserved_tokens_by_model == {}, (
                f"End-to-end: pg.wrap() leaked a reservation — "
                f"{state.current_usage.reserved_tokens_by_model}.  "
                f"This would inflate the guard's projected usage on "
                f"subsequent calls and eventually block a legitimate caller."
            )
        finally:
            _cleanup(pg)
