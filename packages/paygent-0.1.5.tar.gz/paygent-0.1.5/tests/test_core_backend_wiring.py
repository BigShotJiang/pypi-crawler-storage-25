"""Tests for core.py backend wiring — ApiClient + LocalCache integration.

Verifies that:
1. Paygent creates ApiClient when api_key is provided
2. Paygent does NOT create ApiClient in local-only mode
3. start_session() calls LocalCache.bootstrap_session() in connected mode
4. _flush_events() calls LocalCache.store_and_sync() instead of raw SQLite
5. shutdown() closes the API client and syncs pending events
6. base_url can be set via constructor or environment variable
7. All backend failures are handled gracefully (fail-open)
"""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from paygent.api_client import DEFAULT_BASE_URL
from paygent.core import Paygent
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    PlanConfig,
    UsageEvent,
    UserSession,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_singleton():
    """Ensure Paygent singleton is cleared before/after each test."""
    Paygent._instance = None
    yield
    Paygent._instance = None


@pytest.fixture
def tmp_db(tmp_path):
    """Return a temporary DB path."""
    return str(tmp_path / "test.db")


# ---------------------------------------------------------------------------
# ApiClient Creation
# ---------------------------------------------------------------------------


class TestApiClientCreation:
    """Tests for ApiClient wiring in __init__."""

    def test_no_api_client_in_local_mode(self, tmp_db):
        """No ApiClient should be created when api_key is None."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        assert pg._api_client is None
        assert pg.is_local_mode is True

    def test_api_client_created_with_key(self, tmp_db):
        """ApiClient should be created when api_key is provided."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        assert pg._api_client is not None
        assert pg._api_client.base_url == DEFAULT_BASE_URL
        assert pg.is_local_mode is False

    def test_custom_base_url(self, tmp_db):
        """base_url should be passed to ApiClient."""
        pg = Paygent(
            api_key="pg_live_test123",
            base_url="http://localhost:8000",
            db_path=tmp_db,
            auto_instrument=False,
        )
        assert pg._api_client.base_url == "http://localhost:8000"
        assert pg.base_url == "http://localhost:8000"

    def test_base_url_from_env(self, tmp_db):
        """base_url should fall back to PAYGENT_BASE_URL env var."""
        with patch.dict(os.environ, {"PAYGENT_BASE_URL": "http://staging:9000"}):
            pg = Paygent(
                api_key="pg_live_test123",
                db_path=tmp_db,
                auto_instrument=False,
            )
            assert pg.base_url == "http://staging:9000"
            assert pg._api_client.base_url == "http://staging:9000"

    def test_explicit_base_url_overrides_env(self, tmp_db):
        """Explicit base_url should override the env var."""
        with patch.dict(os.environ, {"PAYGENT_BASE_URL": "http://staging:9000"}):
            pg = Paygent(
                api_key="pg_live_test123",
                base_url="http://custom:7000",
                db_path=tmp_db,
                auto_instrument=False,
            )
            assert pg.base_url == "http://custom:7000"

    def test_default_base_url_when_no_env(self, tmp_db):
        """Should use DEFAULT_BASE_URL when no env var and no explicit URL."""
        env = os.environ.copy()
        env.pop("PAYGENT_BASE_URL", None)
        with patch.dict(os.environ, env, clear=True):
            pg = Paygent(
                api_key="pg_live_test123",
                db_path=tmp_db,
                auto_instrument=False,
            )
            assert pg.base_url == DEFAULT_BASE_URL


# ---------------------------------------------------------------------------
# LocalCache Wiring
# ---------------------------------------------------------------------------


class TestLocalCacheWiring:
    """Tests that LocalCache is properly wired."""

    def test_local_cache_created(self, tmp_db):
        """LocalCache should always be created."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        assert pg._local_cache is not None

    def test_local_cache_has_no_backend_in_local_mode(self, tmp_db):
        """LocalCache should have no backend in local-only mode."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        assert pg._local_cache.has_backend is False

    def test_local_cache_has_backend_with_key(self, tmp_db):
        """LocalCache should have a backend when api_key is set."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        assert pg._local_cache.has_backend is True


# ---------------------------------------------------------------------------
# Session Bootstrap via Backend
# ---------------------------------------------------------------------------


class TestSessionBootstrap:
    """Tests for start_session() with backend wiring."""

    def test_local_mode_creates_session_directly(self, tmp_db):
        """In local mode, start_session creates a session without backend call."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True

        config = PlanConfig(max_spend_per_period=10.0)
        session = pg.start_session("user_1", plan="free", plan_config=config)

        assert session.user_id == "user_1"
        assert session.plan == "free"
        assert session.plan_config.max_spend_per_period == 10.0

    def test_connected_mode_calls_bootstrap(self, tmp_db):
        """In connected mode, start_session should call LocalCache.bootstrap_session."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        pg._initialized = True

        # Mock the bootstrap to return a backend session
        backend_session = UserSession(
            user_id="user_1",
            plan="pro",
            plan_config=PlanConfig(max_spend_per_period=49.0),
            current_usage=CurrentUsage(period_cost=12.50),
        )
        pg._local_cache.bootstrap_session = MagicMock(return_value=backend_session)

        config = PlanConfig(max_spend_per_period=10.0)  # fallback config
        session = pg.start_session("user_1", plan="free", plan_config=config)

        # Should have called bootstrap with fallback
        pg._local_cache.bootstrap_session.assert_called_once_with(
            user_id="user_1",
            fallback_plan="free",
            fallback_config=config,
        )

        # Should use the backend session data
        assert session.plan == "pro"
        assert session.plan_config.max_spend_per_period == 49.0
        assert session.current_usage.period_cost == 12.50

    def test_connected_mode_fallback_on_error(self, tmp_db):
        """If bootstrap raises, should still create a minimal session (fail-open)."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        pg._initialized = True

        pg._local_cache.bootstrap_session = MagicMock(side_effect=RuntimeError("boom"))

        session = pg.start_session("user_1", plan="free")

        # Should get a fallback session (fail-open)
        assert session.user_id == "user_1"
        assert session.plan == "free"

    def test_existing_session_preserved(self, tmp_db):
        """Re-calling start_session should preserve existing usage."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        pg._initialized = True

        # Pre-populate a session with some usage
        existing = UserSession(
            user_id="user_1",
            plan="free",
            plan_config=PlanConfig(),
            current_usage=CurrentUsage(period_cost=5.0, period_tokens_total=1000),
        )
        pg._sessions["user_1"] = existing

        # Re-call start_session — should update plan but keep usage
        config = PlanConfig(max_spend_per_period=49.0)
        session = pg.start_session("user_1", plan="pro", plan_config=config)

        assert session.plan == "pro"
        assert session.plan_config.max_spend_per_period == 49.0
        assert session.current_usage.period_cost == 5.0  # preserved
        assert session.current_usage.period_tokens_total == 1000  # preserved


# ---------------------------------------------------------------------------
# Flush Events via LocalCache
# ---------------------------------------------------------------------------


class TestFlushEvents:
    """Tests for _flush_events() using LocalCache.store_and_sync."""

    def test_flush_calls_store_and_sync(self, tmp_db):
        """_flush_events should call LocalCache.store_and_sync."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True

        mock_result = MagicMock()
        mock_result.stored_locally = 2
        mock_result.synced_to_backend = 0
        mock_result.duplicates = 0
        pg._local_cache.store_and_sync = MagicMock(return_value=mock_result)

        events = [
            UsageEvent(user_id="u1", model="gpt-4o", total_tokens=100),
            UsageEvent(user_id="u1", model="gpt-4o", total_tokens=200),
        ]
        pg._flush_events(events)

        pg._local_cache.store_and_sync.assert_called_once_with(events)

    def test_flush_empty_is_noop(self, tmp_db):
        """_flush_events with empty list should be a no-op."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True
        pg._local_cache.store_and_sync = MagicMock()

        pg._flush_events([])

        pg._local_cache.store_and_sync.assert_not_called()

    def test_flush_error_doesnt_raise(self, tmp_db):
        """_flush_events should not raise on LocalCache error."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True
        pg._local_cache.store_and_sync = MagicMock(side_effect=RuntimeError("db error"))

        events = [UsageEvent(user_id="u1")]
        # Should not raise
        pg._flush_events(events)


# ---------------------------------------------------------------------------
# Shutdown
# ---------------------------------------------------------------------------


class TestShutdown:
    """Tests for shutdown() with backend wiring."""

    def test_shutdown_closes_api_client(self, tmp_db):
        """shutdown() should close the API client."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        pg._initialized = True
        pg._api_client.close = MagicMock()

        pg.shutdown()

        pg._api_client.close.assert_called_once()

    def test_shutdown_syncs_pending(self, tmp_db):
        """shutdown() should attempt to sync pending events."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True
        pg._local_cache.sync_pending = MagicMock(return_value=5)

        pg.shutdown()

        pg._local_cache.sync_pending.assert_called_once()

    def test_shutdown_handles_sync_error(self, tmp_db):
        """shutdown() should not fail if sync_pending raises."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._initialized = True
        pg._local_cache.sync_pending = MagicMock(side_effect=RuntimeError("boom"))

        # Should not raise
        pg.shutdown()


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


class TestProperties:
    """Tests for new properties."""

    def test_is_connected_false_in_local_mode(self, tmp_db):
        """is_connected should be False in local-only mode."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        assert pg.is_connected is False

    def test_is_connected_false_when_unreachable(self, tmp_db):
        """is_connected should be False when backend hasn't been reached."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        # backend_reachable is None (unknown) initially
        assert pg.is_connected is False

    def test_is_connected_true_after_success(self, tmp_db):
        """is_connected should be True after successful backend contact."""
        pg = Paygent(api_key="pg_live_test123", db_path=tmp_db, auto_instrument=False)
        pg._local_cache._backend_reachable = True
        assert pg.is_connected is True

    def test_sync_pending_method(self, tmp_db):
        """sync_pending() should delegate to LocalCache."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._local_cache.sync_pending = MagicMock(return_value=3)

        result = pg.sync_pending()
        assert result == 3

    def test_sync_pending_handles_error(self, tmp_db):
        """sync_pending() should return 0 on error."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        pg._local_cache.sync_pending = MagicMock(side_effect=RuntimeError("boom"))

        result = pg.sync_pending()
        assert result == 0

    def test_local_cache_property(self, tmp_db):
        """local_cache property should return the LocalCache instance."""
        pg = Paygent(db_path=tmp_db, auto_instrument=False)
        assert pg.local_cache is pg._local_cache
