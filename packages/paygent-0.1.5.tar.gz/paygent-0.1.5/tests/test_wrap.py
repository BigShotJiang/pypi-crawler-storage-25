"""Tests for pg.wrap() and pg.awrap() — explicit metering wrapper."""

from __future__ import annotations

import asyncio
import os
import tempfile

import pytest

from paygent.core import Paygent
from paygent.guardrails import PaygentLimitExceeded
from paygent.models import (
    CurrentUsage,
    GuardResult,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
)
from paygent.providers import TokenInfo


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tmp_db_path() -> str:
    tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
    tmp.close()
    return tmp.name


def _make_pg(**kwargs) -> Paygent:
    defaults = dict(
        db_path=_tmp_db_path(),
        auto_instrument=False,
        flush_interval=60.0,
    )
    defaults.update(kwargs)
    return Paygent.init(**defaults)


def _cleanup_pg(pg: Paygent) -> None:
    db_path = pg.storage.db_path
    pg.shutdown()
    try:
        os.unlink(db_path)
    except OSError:
        pass


class FakeResponse:
    """Simulates an OpenAI ChatCompletion response."""

    def __init__(self, model="gpt-4o", input_tokens=100, output_tokens=50):
        self.model = model
        self.usage = type("Usage", (), {
            "prompt_tokens": input_tokens,
            "completion_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
        })()


class FakeAnthropicResponse:
    """Simulates an Anthropic Messages response."""

    def __init__(self, model="claude-sonnet-4-20250514", input_tokens=80, output_tokens=40):
        self.model = model
        self.usage = type("Usage", (), {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        })()


# ---------------------------------------------------------------------------
# Basic wrap() tests
# ---------------------------------------------------------------------------


class TestWrapBasic:
    def test_wrap_returns_response(self):
        """wrap() should return the callable's response unchanged."""
        pg = _make_pg()
        try:
            fake = FakeResponse()
            result = pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")
            assert result is fake
        finally:
            _cleanup_pg(pg)

    def test_wrap_creates_session_if_missing(self):
        """wrap() should auto-create a session for unknown users."""
        pg = _make_pg()
        try:
            fake = FakeResponse()
            pg.wrap(lambda: fake, user_id="new_user", model="gpt-4o")
            assert pg.get_session("new_user") is not None
        finally:
            _cleanup_pg(pg)

    def test_wrap_meters_usage(self):
        """wrap() should update the in-memory usage cache."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            fake = FakeResponse(model="gpt-4o", input_tokens=1000, output_tokens=500)
            pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_total == 1500
            assert usage.period_tokens_by_model["gpt-4o"] == 1500
            assert usage.period_cost > 0
        finally:
            _cleanup_pg(pg)

    def test_wrap_pushes_event_to_queue(self):
        """wrap() should push a usage event to the background queue."""
        pg = _make_pg()
        try:
            fake = FakeResponse()
            pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")
            assert pg.pending_events == 1
        finally:
            _cleanup_pg(pg)

    def test_wrap_with_session_id_and_metadata(self):
        """wrap() should pass metadata to the usage event.

        Note: When a cached UserState exists with a clock-based session_id,
        that takes precedence over the caller-provided session_id. The
        caller-provided session_id is used as a fallback when no cached
        state exists.
        """
        pg = _make_pg()
        try:
            fake = FakeResponse()
            pg.wrap(
                lambda: fake,
                user_id="user_1",
                model="gpt-4o",
                session_id="sess_abc",
                metadata={"foo": "bar"},
            )

            # Flush and check the stored event
            pg.flush()
            events = pg.storage.get_unsynced_events_sync()
            assert len(events) == 1
            # session_id may be the cached state's clock-based ID or the
            # caller-provided fallback — either is valid
            assert events[0].session_id is not None
            assert events[0].metadata == {"foo": "bar"}
        finally:
            _cleanup_pg(pg)

    def test_wrap_without_model_extracts_from_response(self):
        """If model is not passed, wrap() should extract it from the response."""
        pg = _make_pg()
        try:
            fake = FakeResponse(model="gpt-4o-mini")
            pg.wrap(lambda: fake, user_id="user_1")

            usage = pg.get_usage("user_1")
            assert "gpt-4o-mini" in usage.period_tokens_by_model
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Provider detection
# ---------------------------------------------------------------------------


class TestWrapProviderDetection:
    def test_wrap_with_openai_response(self):
        """wrap() should correctly extract tokens from OpenAI response."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            fake = FakeResponse(model="gpt-4o", input_tokens=200, output_tokens=100)
            pg.wrap(lambda: fake, user_id="user_1", provider="openai")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_by_model["gpt-4o"] == 300
        finally:
            _cleanup_pg(pg)

    def test_wrap_with_anthropic_response(self):
        """wrap() should correctly extract tokens from Anthropic response."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            fake = FakeAnthropicResponse(input_tokens=80, output_tokens=40)
            pg.wrap(lambda: fake, user_id="user_1", provider="anthropic")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 120
        finally:
            _cleanup_pg(pg)

    def test_wrap_auto_detects_provider(self):
        """Without provider hint, wrap() should try all and pick one with tokens."""
        pg = _make_pg()
        try:
            fake = FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
            pg.wrap(lambda: fake, user_id="user_1")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_total == 150
        finally:
            _cleanup_pg(pg)

    def test_wrap_unknown_provider_falls_back(self):
        """Unknown provider name should fall back to trying all providers."""
        pg = _make_pg()
        try:
            fake = FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
            pg.wrap(lambda: fake, user_id="user_1", provider="unknown_provider")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_total == 150
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Guardrails in wrap()
# ---------------------------------------------------------------------------


class TestWrapGuardrails:
    def test_wrap_hard_gate_raises(self):
        """wrap() should raise PaygentLimitExceeded on hard gate."""
        pg = _make_pg(raise_on_hard_gate=True)
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 10.50  # Over limit

            call_count = 0

            def fake_call():
                nonlocal call_count
                call_count += 1
                return FakeResponse()

            with pytest.raises(PaygentLimitExceeded) as exc_info:
                pg.wrap(fake_call, user_id="user_1", model="gpt-4o")

            assert exc_info.value.guard_result.status == "hard_gate"
            assert call_count == 0  # Call should NOT have been made
        finally:
            _cleanup_pg(pg)

    def test_wrap_hard_gate_no_raise(self):
        """With raise_on_hard_gate=False, hard gate should still execute the call."""
        pg = _make_pg(raise_on_hard_gate=False)
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 10.50

            fake = FakeResponse()
            result = pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")
            assert result is fake
        finally:
            _cleanup_pg(pg)

    def test_wrap_soft_gate_fires_callback(self):
        """wrap() should fire soft gate callbacks."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 8.50  # 85% → soft gate

            soft_results = []
            pg.on_soft_gate(lambda r: soft_results.append(r))

            fake = FakeResponse()
            result = pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")

            assert result is fake
            assert len(soft_results) == 1
            assert soft_results[0].status == "soft_gate"
        finally:
            _cleanup_pg(pg)

    def test_wrap_ok_guard(self):
        """wrap() with usage within limits should proceed normally."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=100.00)
            pg.start_session("user_1", plan="pro", plan_config=config)

            fake = FakeResponse()
            result = pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")
            assert result is fake
        finally:
            _cleanup_pg(pg)

    def test_wrap_model_limit_hard_gate(self):
        """wrap() should enforce model-level token limits."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                model_limits={"gpt-4o": ModelLimitConfig(max_tokens_per_period=1000)},
            )
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_tokens_by_model["gpt-4o"] = 1100

            with pytest.raises(PaygentLimitExceeded) as exc_info:
                pg.wrap(lambda: FakeResponse(), user_id="user_1", model="gpt-4o")

            assert "model_limit:gpt-4o" in exc_info.value.guard_result.gate_reason
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Fail-open behavior
# ---------------------------------------------------------------------------


class TestWrapFailOpen:
    def test_wrap_callable_error_propagates(self):
        """If the user's callable raises, that error should propagate."""
        pg = _make_pg()
        try:
            def bad_call():
                raise ValueError("LLM API error")

            with pytest.raises(ValueError, match="LLM API error"):
                pg.wrap(bad_call, user_id="user_1", model="gpt-4o")
        finally:
            _cleanup_pg(pg)

    def test_wrap_metering_failure_still_returns_response(self):
        """If token extraction fails, response should still be returned."""
        pg = _make_pg()
        try:
            # Response with no usage data — token extraction will return zeros
            response = type("BadResponse", (), {"model": None, "usage": None})()
            result = pg.wrap(lambda: response, user_id="user_1", model="gpt-4o")
            assert result is response
        finally:
            _cleanup_pg(pg)

    def test_wrap_with_non_llm_response(self):
        """wrap() should handle non-standard responses gracefully."""
        pg = _make_pg()
        try:
            result = pg.wrap(lambda: "just a string", user_id="user_1", model="gpt-4o")
            assert result == "just a string"
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Usage accumulation
# ---------------------------------------------------------------------------


class TestWrapAccumulation:
    def test_wrap_multiple_calls_accumulate(self):
        """Multiple wrap() calls should accumulate usage."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            for _ in range(3):
                fake = FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
                pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_total == 450  # 3 * 150
            assert usage.period_tokens_by_model["gpt-4o"] == 450
            assert pg.pending_events == 3
        finally:
            _cleanup_pg(pg)

    def test_wrap_multi_model_tracking(self):
        """wrap() should track different models separately."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={
                    "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
                    "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
                },
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            gpt_resp = FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
            pg.wrap(lambda: gpt_resp, user_id="user_1", model="gpt-4o")

            claude_resp = FakeAnthropicResponse(input_tokens=80, output_tokens=40)
            pg.wrap(lambda: claude_resp, user_id="user_1", model="claude-sonnet-4-20250514")

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_by_model["gpt-4o"] == 150
            assert usage.period_tokens_by_model["claude-sonnet-4-20250514"] == 120
            assert usage.period_tokens_total == 270
        finally:
            _cleanup_pg(pg)

    def test_wrap_events_persist_to_sqlite(self):
        """Events from wrap() should be stored in SQLite after flush."""
        pg = _make_pg()
        try:
            fake = FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
            pg.wrap(lambda: fake, user_id="user_1", model="gpt-4o")
            pg.flush()

            events = pg.storage.get_unsynced_events_sync()
            assert len(events) == 1
            assert events[0].user_id == "user_1"
            assert events[0].model == "gpt-4o"
            assert events[0].input_tokens == 100
            assert events[0].output_tokens == 50
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Async wrap (awrap)
# ---------------------------------------------------------------------------


class TestAwrap:
    def test_awrap_returns_response(self):
        """awrap() should return the awaited response."""
        pg = _make_pg()
        try:
            fake = FakeResponse()

            async def fake_call():
                return fake

            async def run():
                return await pg.awrap(
                    fake_call(),
                    user_id="user_1",
                    model="gpt-4o",
                )

            result = asyncio.get_event_loop().run_until_complete(run())
            assert result is fake
        finally:
            _cleanup_pg(pg)

    def test_awrap_meters_usage(self):
        """awrap() should meter usage just like wrap()."""
        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("user_1", plan="pro", plan_config=config)

            fake = FakeResponse(model="gpt-4o", input_tokens=200, output_tokens=100)

            async def fake_call():
                return fake

            async def run():
                return await pg.awrap(
                    fake_call(),
                    user_id="user_1",
                    model="gpt-4o",
                )

            asyncio.get_event_loop().run_until_complete(run())

            usage = pg.get_usage("user_1")
            assert usage.period_tokens_total == 300
            assert pg.pending_events == 1
        finally:
            _cleanup_pg(pg)

    def test_awrap_hard_gate_raises(self):
        """awrap() should raise on hard gate."""
        pg = _make_pg()
        try:
            config = PlanConfig(max_spend_per_period=10.00)
            session = pg.start_session("user_1", plan="pro", plan_config=config)
            session.current_usage.period_cost = 10.50

            async def fake_call():
                return FakeResponse()

            async def run():
                return await pg.awrap(
                    fake_call(),
                    user_id="user_1",
                    model="gpt-4o",
                )

            with pytest.raises(PaygentLimitExceeded):
                asyncio.get_event_loop().run_until_complete(run())
        finally:
            _cleanup_pg(pg)


# ---------------------------------------------------------------------------
# Concurrent contextvars isolation
# ---------------------------------------------------------------------------


class TestConcurrentContextVarsIsolation:
    """Two coroutines running concurrently with different user_ids must
    keep their metering fully isolated.

    Python's contextvars are task-local in asyncio, so each coroutine sees
    its own ``paygent_context``.  This test is a regression guard against
    future changes (e.g. accidentally switching to thread-locals or a shared
    mutable holder) that would let user_A's events leak into user_B's totals.
    """

    def test_two_concurrent_users_do_not_cross_contaminate(self):
        from paygent import paygent_context

        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={
                    "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
                    "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
                },
            )
            pg.start_session("user_A", plan="pro", plan_config=config)
            pg.start_session("user_B", plan="pro", plan_config=config)

            # Each coroutine waits mid-call to guarantee interleaving.
            async def call_for(user_id: str, model: str, tokens: int):
                with paygent_context(user_id=user_id):
                    async def fake_call():
                        # Yield to the other task so interleaving is forced
                        await asyncio.sleep(0)
                        return FakeResponse(
                            model=model,
                            input_tokens=tokens,
                            output_tokens=tokens,
                        )
                    return await pg.awrap(
                        fake_call(),
                        user_id=user_id,
                        model=model,
                    )

            async def run_both():
                return await asyncio.gather(
                    call_for("user_A", "gpt-4o", 100),
                    call_for("user_B", "claude-sonnet-4-20250514", 200),
                    call_for("user_A", "gpt-4o", 50),
                    call_for("user_B", "claude-sonnet-4-20250514", 25),
                )

            asyncio.get_event_loop().run_until_complete(run_both())

            usage_a = pg.get_usage("user_A")
            usage_b = pg.get_usage("user_B")

            # user_A: 2 calls × (100 + 100) input+output from the first
            # + 2 × (50 + 50) from the second = 300 tokens total for gpt-4o
            assert usage_a.period_tokens_total == 300
            assert usage_a.period_tokens_by_model.get("gpt-4o") == 300
            # No leakage — A must not contain Claude tokens
            assert "claude-sonnet-4-20250514" not in usage_a.period_tokens_by_model

            # user_B: (200+200) + (25+25) = 450 tokens total for Claude
            assert usage_b.period_tokens_total == 450
            assert usage_b.period_tokens_by_model.get("claude-sonnet-4-20250514") == 450
            # No leakage — B must not contain gpt-4o tokens
            assert "gpt-4o" not in usage_b.period_tokens_by_model
        finally:
            _cleanup_pg(pg)

    def test_nested_context_inner_overrides_outer(self):
        """Inner ``paygent_context`` must shadow outer for nested coroutines."""
        from paygent import paygent_context

        pg = _make_pg()
        try:
            config = PlanConfig(
                cost_rates={"gpt-4o": ModelCostRate(input=0.0025, output=0.01)},
            )
            pg.start_session("outer_user", plan="pro", plan_config=config)
            pg.start_session("inner_user", plan="pro", plan_config=config)

            async def inner_call():
                with paygent_context(user_id="inner_user"):
                    async def fake():
                        return FakeResponse(model="gpt-4o", input_tokens=10, output_tokens=5)
                    return await pg.awrap(fake(), user_id="inner_user", model="gpt-4o")

            async def outer_call():
                with paygent_context(user_id="outer_user"):
                    async def fake():
                        return FakeResponse(model="gpt-4o", input_tokens=100, output_tokens=50)
                    # Outer meters its own call
                    await pg.awrap(fake(), user_id="outer_user", model="gpt-4o")
                    # Then awaits inner — inner must meter against inner_user
                    await inner_call()

            asyncio.get_event_loop().run_until_complete(outer_call())

            assert pg.get_usage("outer_user").period_tokens_total == 150
            assert pg.get_usage("inner_user").period_tokens_total == 15
        finally:
            _cleanup_pg(pg)
