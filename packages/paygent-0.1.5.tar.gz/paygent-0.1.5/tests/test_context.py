"""Tests for Paygent contextvars user identity system."""

from __future__ import annotations

import threading

import pytest

from paygent.context import (
    PaygentContext,
    get_current_context,
    paygent_context,
    paygent_track,
)


# ---------------------------------------------------------------------------
# paygent_context (context manager)
# ---------------------------------------------------------------------------


class TestPaygentContext:
    def test_no_context_by_default(self):
        """Without context manager, get_current_context returns None."""
        assert get_current_context() is None

    def test_basic_context(self):
        """Context manager sets and clears the context."""
        with paygent_context(user_id="user_123"):
            ctx = get_current_context()
            assert ctx is not None
            assert ctx.user_id == "user_123"

        # After exiting, context should be cleared
        assert get_current_context() is None

    def test_full_context(self):
        """All fields should be accessible inside the context."""
        with paygent_context(
            user_id="user_123",
            session_id="sess_abc",
            plan="pro",
            metadata={"agent": "research"},
        ) as ctx:
            assert ctx.user_id == "user_123"
            assert ctx.session_id == "sess_abc"
            assert ctx.plan == "pro"
            assert ctx.metadata == {"agent": "research"}

            # Also available via get_current_context
            fetched = get_current_context()
            assert fetched is ctx

    def test_optional_fields_default_to_none(self):
        with paygent_context(user_id="user_1") as ctx:
            assert ctx.session_id is None
            assert ctx.plan is None
            assert ctx.metadata is None

    def test_nested_contexts(self):
        """Inner context should shadow outer, then restore."""
        with paygent_context(user_id="outer_user"):
            assert get_current_context().user_id == "outer_user"

            with paygent_context(user_id="inner_user"):
                assert get_current_context().user_id == "inner_user"

            # Outer context restored
            assert get_current_context().user_id == "outer_user"

        assert get_current_context() is None

    def test_context_cleared_on_exception(self):
        """Context must be cleared even if an exception occurs."""
        with pytest.raises(ValueError):
            with paygent_context(user_id="user_err"):
                assert get_current_context() is not None
                raise ValueError("test error")

        assert get_current_context() is None

    def test_thread_isolation(self):
        """Each thread should have its own independent context."""
        results = {}

        def worker(name: str):
            with paygent_context(user_id=name):
                # Small delay to increase chance of interleaving
                import time
                time.sleep(0.01)
                ctx = get_current_context()
                results[name] = ctx.user_id if ctx else None

        t1 = threading.Thread(target=worker, args=("thread_1",))
        t2 = threading.Thread(target=worker, args=("thread_2",))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        assert results["thread_1"] == "thread_1"
        assert results["thread_2"] == "thread_2"

        # Main thread should have no context
        assert get_current_context() is None


# ---------------------------------------------------------------------------
# paygent_track (decorator)
# ---------------------------------------------------------------------------


class TestPaygentTrack:
    def test_static_user_id(self):
        """Decorator with static user_id sets context during function call."""
        captured = {}

        @paygent_track(user_id="user_abc")
        def my_handler():
            ctx = get_current_context()
            captured["user_id"] = ctx.user_id
            return "result"

        result = my_handler()
        assert result == "result"
        assert captured["user_id"] == "user_abc"

        # Context cleared after function returns
        assert get_current_context() is None

    def test_static_with_all_fields(self):
        """Decorator passes all fields to context."""
        captured = {}

        @paygent_track(
            user_id="user_1",
            session_id="sess_1",
            plan="free",
            metadata={"key": "val"},
        )
        def handler():
            ctx = get_current_context()
            captured.update({
                "user_id": ctx.user_id,
                "session_id": ctx.session_id,
                "plan": ctx.plan,
                "metadata": ctx.metadata,
            })

        handler()
        assert captured["user_id"] == "user_1"
        assert captured["session_id"] == "sess_1"
        assert captured["plan"] == "free"
        assert captured["metadata"] == {"key": "val"}

    def test_dynamic_user_id_from_kwarg(self):
        """Decorator with user_id_param reads user_id from function kwargs."""
        captured = {}

        @paygent_track(user_id_param="uid")
        def handler(query: str, uid: str = "default"):
            ctx = get_current_context()
            captured["user_id"] = ctx.user_id
            return query

        result = handler("hello", uid="dynamic_user")
        assert result == "hello"
        assert captured["user_id"] == "dynamic_user"

    def test_dynamic_user_id_from_positional_arg(self):
        """Decorator resolves user_id from positional arguments."""
        captured = {}

        @paygent_track(user_id_param="user_id")
        def handler(user_id: str, query: str):
            ctx = get_current_context()
            captured["user_id"] = ctx.user_id

        handler("pos_user", "some query")
        assert captured["user_id"] == "pos_user"

    def test_dynamic_user_id_missing_skips_tracking(self):
        """If user_id_param can't be resolved, function still runs (fail-open)."""
        called = {"count": 0}

        @paygent_track(user_id_param="nonexistent_param")
        def handler(query: str):
            called["count"] += 1
            ctx = get_current_context()
            assert ctx is None  # No context set
            return "ok"

        result = handler("test")
        assert result == "ok"
        assert called["count"] == 1

    def test_no_user_id_at_all_skips_tracking(self):
        """If neither user_id nor user_id_param is set, skip tracking."""
        called = {"count": 0}

        @paygent_track()
        def handler():
            called["count"] += 1
            ctx = get_current_context()
            assert ctx is None
            return "ok"

        result = handler()
        assert result == "ok"
        assert called["count"] == 1

    def test_preserves_function_name(self):
        """Decorated function should preserve its original name."""

        @paygent_track(user_id="u1")
        def my_special_function():
            pass

        assert my_special_function.__name__ == "my_special_function"

    def test_context_cleared_on_exception(self):
        """Context must be cleared even if decorated function raises."""

        @paygent_track(user_id="user_err")
        def failing_handler():
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            failing_handler()

        assert get_current_context() is None


# ---------------------------------------------------------------------------
# PaygentContext dataclass
# ---------------------------------------------------------------------------


class TestPaygentContextDataclass:
    def test_basic_construction(self):
        ctx = PaygentContext(user_id="u1")
        assert ctx.user_id == "u1"
        assert ctx.session_id is None
        assert ctx.plan is None
        assert ctx.metadata is None

    def test_full_construction(self):
        ctx = PaygentContext(
            user_id="u1",
            session_id="s1",
            plan="pro",
            metadata={"k": "v"},
        )
        assert ctx.user_id == "u1"
        assert ctx.session_id == "s1"
        assert ctx.plan == "pro"
        assert ctx.metadata == {"k": "v"}
