"""Tests for the LangChain integration callback."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest

from paygent.core import Paygent
from paygent.models import (
    CurrentUsage,
    ModelCostRate,
    PlanConfig,
    UserSession,
)


# ---------------------------------------------------------------------------
# Mock LangChain types (so we don't require langchain-core for tests)
# ---------------------------------------------------------------------------


class MockBaseCallbackHandler:
    """Stand-in for langchain_core.callbacks.BaseCallbackHandler."""
    pass


class MockLLMResult:
    """Stand-in for langchain_core.outputs.LLMResult."""

    def __init__(
        self,
        llm_output: Optional[Dict[str, Any]] = None,
        generations: Optional[List] = None,
    ):
        self.llm_output = llm_output or {}
        self.generations = generations or []


class MockGeneration:
    """Stand-in for a LangChain generation object."""

    def __init__(self, generation_info: Optional[Dict] = None):
        self.generation_info = generation_info or {}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def mock_langchain():
    """Mock langchain_core so the integration can be imported without it."""
    with patch(
        "paygent.integrations.langchain._get_base_handler",
        return_value=MockBaseCallbackHandler,
    ):
        yield


@pytest.fixture
def pg(tmp_path):
    """Create a Paygent instance for testing."""
    instance = Paygent(
        db_path=str(tmp_path / "test.db"),
        auto_instrument=False,
    )
    # Don't fully initialize — we just need session management
    instance._initialized = True
    yield instance
    Paygent._instance = None


@pytest.fixture
def session(pg) -> UserSession:
    """Start a session with cost rates configured."""
    config = PlanConfig(
        max_spend_per_period=100.0,
        cost_rates={
            "gpt-4o": ModelCostRate(input=0.0025, output=0.01),
            "claude-sonnet-4-20250514": ModelCostRate(input=0.003, output=0.015),
        },
    )
    return pg.start_session("user_lc", plan="pro", plan_config=config)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_callback_creation(pg, session):
    """LangChainCallback can be created with a Paygent instance."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    assert cb.user_id == "user_lc"
    assert cb._pg is pg


def test_callback_meters_tokens(pg, session):
    """on_llm_end should create a usage event and update the cache."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    events = []
    pg._event_sink = lambda e: events.append(e)

    run_id = uuid4()

    # Simulate LLM start
    cb.on_llm_start(
        serialized={"kwargs": {"model": "gpt-4o"}},
        prompts=["Hello"],
        run_id=run_id,
        invocation_params={"model": "gpt-4o"},
    )

    # Simulate LLM end with token usage
    response = MockLLMResult(
        llm_output={
            "token_usage": {
                "prompt_tokens": 100,
                "completion_tokens": 50,
                "total_tokens": 150,
            },
            "model_name": "gpt-4o",
        }
    )
    cb.on_llm_end(response, run_id=run_id)

    assert len(events) == 1
    event = events[0]
    assert event.user_id == "user_lc"
    assert event.model == "gpt-4o"
    assert event.input_tokens == 100
    assert event.output_tokens == 50
    assert event.total_tokens == 150
    assert event.metadata["source"] == "langchain"

    # Cache should be updated
    usage = pg.get_usage("user_lc")
    assert usage.period_tokens_total == 150


def test_callback_calculates_cost(pg, session):
    """on_llm_end should calculate cost from plan config rates."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    events = []
    pg._event_sink = lambda e: events.append(e)

    run_id = uuid4()
    cb.on_llm_start(
        serialized={},
        prompts=["Hello"],
        run_id=run_id,
        invocation_params={"model": "gpt-4o"},
    )

    response = MockLLMResult(
        llm_output={
            "token_usage": {
                "prompt_tokens": 1000,
                "completion_tokens": 500,
                "total_tokens": 1500,
            },
        }
    )
    cb.on_llm_end(response, run_id=run_id)

    event = events[0]
    # Cost: (1000/1000)*0.0025 + (500/1000)*0.01 = 0.0025 + 0.005 = 0.0075
    assert event.cost_tokens == pytest.approx(0.0075, abs=0.0001)
    assert event.cost_total == pytest.approx(0.0075, abs=0.0001)


def test_callback_handles_missing_usage(pg, session):
    """on_llm_end should handle responses without token usage gracefully."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    events = []
    pg._event_sink = lambda e: events.append(e)

    response = MockLLMResult(llm_output={})
    cb.on_llm_end(response, run_id=uuid4())

    assert len(events) == 1
    event = events[0]
    assert event.total_tokens == 0
    assert event.cost_total == 0.0


def test_callback_on_llm_error_cleans_up(pg, session):
    """on_llm_error should clean up pending run state."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    run_id = uuid4()

    cb.on_llm_start(
        serialized={},
        prompts=["Hello"],
        run_id=run_id,
    )
    assert str(run_id) in cb._pending_runs

    cb.on_llm_error(RuntimeError("API error"), run_id=run_id)
    assert str(run_id) not in cb._pending_runs


def test_callback_per_generation_usage(pg, session):
    """on_llm_end should extract usage from per-generation info."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")
    events = []
    pg._event_sink = lambda e: events.append(e)

    gen = MockGeneration(
        generation_info={
            "usage": {
                "prompt_tokens": 200,
                "completion_tokens": 100,
                "total_tokens": 300,
            }
        }
    )
    response = MockLLMResult(llm_output={}, generations=[[gen]])
    cb.on_llm_end(response, run_id=uuid4())

    event = events[0]
    assert event.input_tokens == 200
    assert event.output_tokens == 100
    assert event.total_tokens == 300


def test_callback_with_custom_metadata(pg, session):
    """Custom metadata should be included in events."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(
        pg, user_id="user_lc", metadata={"chain": "summarize"}
    )
    events = []
    pg._event_sink = lambda e: events.append(e)

    response = MockLLMResult(
        llm_output={
            "token_usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
        }
    )
    cb.on_llm_end(response, run_id=uuid4())

    assert events[0].metadata["chain"] == "summarize"
    assert events[0].metadata["source"] == "langchain"


def test_callback_with_session_id(pg, session):
    """Session ID should be included in events."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc", session_id="sess_abc")
    events = []
    pg._event_sink = lambda e: events.append(e)

    response = MockLLMResult(
        llm_output={
            "token_usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
        }
    )
    cb.on_llm_end(response, run_id=uuid4())

    assert events[0].session_id == "sess_abc"


def test_callback_no_session_still_works(pg):
    """Callback should work even without a started session (no cost calc)."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_no_session")
    events = []
    pg._event_sink = lambda e: events.append(e)

    response = MockLLMResult(
        llm_output={
            "token_usage": {"prompt_tokens": 50, "completion_tokens": 25, "total_tokens": 75},
            "model_name": "gpt-4o",
        }
    )
    cb.on_llm_end(response, run_id=uuid4())

    assert len(events) == 1
    assert events[0].total_tokens == 75
    # No session = no cost calculation
    assert events[0].cost_total == 0.0


def test_noop_methods_dont_raise(pg, session):
    """Chain/tool/agent callbacks should be no-ops that don't raise."""
    from paygent.integrations.langchain import LangChainCallback

    cb = LangChainCallback(pg, user_id="user_lc")

    # None of these should raise
    cb.on_chain_start({}, {})
    cb.on_chain_end({})
    cb.on_chain_error(RuntimeError())
    cb.on_tool_start({}, "input")
    cb.on_tool_end("output")
    cb.on_tool_error(RuntimeError())
    cb.on_text("text")
    cb.on_agent_action(MagicMock())
    cb.on_agent_finish(MagicMock())


# ---------------------------------------------------------------------------
# Dedup: auto-instrumentation active → callback skips metering
# ---------------------------------------------------------------------------


class TestLangChainDedup:
    """Smart de-dup ("Option A"): the callback skips metering only when the
    patcher will ALSO meter — i.e. instrumentation is active AND a
    ``paygent_context`` is set.  This avoids two different bugs:

      1. Naive "always meter" — double-counts when both paths fire on the
         same call.
      2. Naive "skip whenever instrumented" — silently breaks the
         ``auto_instrument=True`` + callback + no-context setup, where
         the patcher is on but won't record (no context) and the
         callback would mistakenly skip.

    The four scenarios below pin down the full truth table.
    """

    def _make_response(self, total: int = 150) -> "MockLLMResult":
        return MockLLMResult(
            llm_output={
                "token_usage": {
                    "prompt_tokens": total - 50,
                    "completion_tokens": 50,
                    "total_tokens": total,
                },
            }
        )

    def _drive(self, cb, response):
        run_id = uuid4()
        cb.on_llm_start(
            serialized={"kwargs": {"model": "gpt-4o"}},
            prompts=["Hello"],
            run_id=run_id,
            invocation_params={"model": "gpt-4o"},
        )
        cb.on_llm_end(response, run_id=run_id)
        return run_id

    # --- 4-cell truth table for de-dup ---

    def test_instrumented_with_context_skips_to_avoid_double_count(self, pg, session):
        """Patcher on + context set → callback skips (de-dup)."""
        from paygent.context import paygent_context
        from paygent.integrations.langchain import LangChainCallback

        pg._instrumentor._instrumented = True
        cb = LangChainCallback(pg, user_id="user_lc")
        events = []
        pg._event_sink = lambda e: events.append(e)

        with paygent_context(user_id="user_lc"):
            self._drive(cb, self._make_response(total=150))

        assert events == [], (
            "Patcher would have already metered this call (it's active "
            "and a context is set); callback must skip to avoid double-counting."
        )

    def test_instrumented_without_context_still_meters(self, pg, session):
        """Patcher on + NO context → callback meters.

        This is the regression guard against the naive 'skip whenever
        instrumented' fix — that approach would zero-out metering for
        any dev who attaches a callback but forgets ``paygent_context()``.
        """
        from paygent.integrations.langchain import LangChainCallback

        pg._instrumentor._instrumented = True
        cb = LangChainCallback(pg, user_id="user_lc")
        events = []
        pg._event_sink = lambda e: events.append(e)

        # NOTE: deliberately no paygent_context() here.
        self._drive(cb, self._make_response(total=150))

        assert len(events) == 1, (
            "Patcher is on but no context is set, so it won't record. "
            "Callback MUST meter — otherwise the call goes entirely unmetered."
        )
        assert events[0].total_tokens == 150

    def test_not_instrumented_with_context_still_meters(self, pg, session):
        """Patcher off + context set → callback meters (only path active)."""
        from paygent.context import paygent_context
        from paygent.integrations.langchain import LangChainCallback

        assert pg.is_instrumented is False
        cb = LangChainCallback(pg, user_id="user_lc")
        events = []
        pg._event_sink = lambda e: events.append(e)

        with paygent_context(user_id="user_lc"):
            self._drive(cb, self._make_response(total=150))

        assert len(events) == 1
        assert events[0].total_tokens == 150

    def test_not_instrumented_without_context_still_meters(self, pg, session):
        """Patcher off + NO context → callback meters (the original
        callback-only path; user_id comes from the callback's constructor)."""
        from paygent.integrations.langchain import LangChainCallback

        assert pg.is_instrumented is False
        cb = LangChainCallback(pg, user_id="user_lc")
        events = []
        pg._event_sink = lambda e: events.append(e)

        self._drive(cb, self._make_response(total=150))

        assert len(events) == 1
        assert events[0].total_tokens == 150
        assert events[0].user_id == "user_lc"

    # --- Hygiene: pending-run cleanup must happen even on skip ---

    def test_cleans_up_pending_run_when_skipping(self, pg, session):
        """When de-dup kicks in, _pending_runs must still be cleaned up to
        avoid an unbounded leak under load."""
        from paygent.context import paygent_context
        from paygent.integrations.langchain import LangChainCallback

        pg._instrumentor._instrumented = True
        cb = LangChainCallback(pg, user_id="user_lc")

        with paygent_context(user_id="user_lc"):
            run_id = uuid4()
            cb.on_llm_start(serialized={}, prompts=["Hello"], run_id=run_id)
            assert str(run_id) in cb._pending_runs
            cb.on_llm_end(self._make_response(), run_id=run_id)
            assert str(run_id) not in cb._pending_runs

    # --- on_usage hook firing (the second bug fix) ---

    def test_on_usage_fires_when_callback_meters(self, pg, session):
        """When the callback DOES meter, registered ``pg.on_usage(...)``
        callbacks must fire — matching the patcher's contract."""
        from paygent.integrations.langchain import LangChainCallback

        captured = []
        pg.on_usage(lambda e: captured.append(e))

        cb = LangChainCallback(pg, user_id="user_lc")
        self._drive(cb, self._make_response(total=42))

        assert len(captured) == 1, (
            "pg.on_usage(...) callbacks must fire on every metering "
            "event, regardless of which path produced it."
        )
        assert captured[0].total_tokens == 42

    def test_on_usage_does_not_fire_when_callback_skips(self, pg, session):
        """When the callback skips (de-dup), it must NOT fire on_usage —
        the patcher will fire its own on_usage from the patched call."""
        from paygent.context import paygent_context
        from paygent.integrations.langchain import LangChainCallback

        pg._instrumentor._instrumented = True
        captured = []
        pg.on_usage(lambda e: captured.append(e))

        cb = LangChainCallback(pg, user_id="user_lc")
        with paygent_context(user_id="user_lc"):
            self._drive(cb, self._make_response())

        # We don't fire on_usage from the skip path — the patcher's wrapper
        # fires it for the real call.  (In this unit test the patcher
        # doesn't actually run; we just verify the callback didn't fire it.)
        assert captured == []
