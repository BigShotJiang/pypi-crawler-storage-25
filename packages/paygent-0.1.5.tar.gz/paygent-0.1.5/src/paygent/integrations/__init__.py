"""Framework integrations for Paygent.

Provides callback handlers for popular AI frameworks:
- LangChain: LangChainCallback
- CrewAI: CrewAICallback

Each integration is lazily imported to avoid requiring the framework
as a hard dependency. Install the extras you need:

    pip install paygent[langchain]
    pip install paygent[crewai]
    pip install paygent[all]
"""

from __future__ import annotations


def __getattr__(name: str):
    """Lazy imports to avoid requiring optional dependencies at import time."""
    if name == "LangChainCallback":
        from paygent.integrations.langchain import LangChainCallback
        return LangChainCallback
    if name == "CrewAICallback":
        from paygent.integrations.crewai import CrewAICallback
        return CrewAICallback
    raise AttributeError(f"module 'paygent.integrations' has no attribute {name!r}")


__all__ = ["LangChainCallback", "CrewAICallback"]
