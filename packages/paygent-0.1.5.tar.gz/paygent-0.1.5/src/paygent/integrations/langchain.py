"""LangChain integration for Paygent.

Provides a callback handler that hooks into LangChain's callback system
to meter LLM usage per user. Works with any LangChain chain, agent, or
tool that uses the standard callback interface.

Usage:
    from paygent import Paygent
    from paygent.integrations import LangChainCallback

    pg = Paygent.init(api_key="pg_live_...")
    pg.start_session("user_123", plan="pro", plan_config=plan_config)

    callback = LangChainCallback(pg, user_id="user_123")
    result = chain.invoke({"input": "..."}, config={"callbacks": [callback]})

This callback does NOT require auto-instrumentation — it works alongside
or instead of monkey-patching.

De-duplication when both paths are active:
    The patcher fires only when ``paygent_context()`` is set; this
    callback fires whenever LangChain emits ``on_llm_end``.  When BOTH
    auto-instrumentation is active AND a ``paygent_context`` is set,
    the same call would otherwise be metered twice — once by the
    patcher's wrapper around ``Completions.create``, once by this
    callback.  We detect that situation and skip our own metering.

    When auto-instrumentation is on but no ``paygent_context`` is set,
    the patcher won't record anything — so this callback DOES meter,
    using the ``user_id`` from its constructor.  That's how a dev who
    only attaches the callback (without setting context) keeps getting
    metered events.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Union
from uuid import uuid4

logger = logging.getLogger("paygent")


def _get_base_handler():
    """Import BaseCallbackHandler lazily so paygent doesn't hard-depend on langchain."""
    try:
        from langchain_core.callbacks import BaseCallbackHandler
        return BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "langchain-core is required for the LangChain integration. "
            "Install it with: pip install paygent[langchain]"
        )


class LangChainCallback:
    """LangChain callback handler that meters LLM usage via Paygent.

    Tracks token usage and costs for each LLM call made within a
    LangChain chain or agent. Events are pushed to Paygent's event queue
    and synced to the backend asynchronously.

    Attributes:
        pg: The Paygent instance.
        user_id: The user to attribute usage to.
        session_id: Optional session identifier.
        metadata: Optional metadata attached to every event.
    """

    def __new__(cls, *args, **kwargs):
        """Dynamically inherit from LangChain's BaseCallbackHandler."""
        BaseHandler = _get_base_handler()

        # Create a new class that inherits from both
        if not issubclass(cls, BaseHandler):
            new_cls = type(
                cls.__name__,
                (cls, BaseHandler),
                dict(cls.__dict__),
            )
            instance = BaseHandler.__new__(new_cls)
            return instance
        return super().__new__(cls)

    def __init__(
        self,
        pg: Any,
        user_id: str,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize the LangChain callback handler.

        Args:
            pg: A Paygent instance (from Paygent.init()).
            user_id: The user to track usage for.
            session_id: Optional session identifier.
            metadata: Optional metadata to attach to all events.
        """
        # Only call super().__init__() once
        if not hasattr(self, '_pg'):
            try:
                super().__init__()
            except TypeError:
                pass
            self._pg = pg
            self._user_id = user_id
            self._session_id = session_id
            self._metadata = metadata or {}
            self._pending_runs: Dict[str, Dict[str, Any]] = {}

    @property
    def _patcher_will_meter(self) -> bool:
        """Whether the SDK's monkey-patcher will already meter this call.

        Two conditions must BOTH be true for the patcher to actually
        record an event for the underlying provider call:

        1. **Instrumentation is active.** ``auto_instrument=True`` on
           init, or ``pg._instrumentor.instrument()`` was called manually.
        2. **A ``paygent_context`` is set.** The patcher's wrapper
           early-returns to a pass-through when no user context is
           present — see ``patcher.create_sync_wrapper``.

        If either condition is false, the patcher won't record anything,
        and this callback MUST do the metering itself — otherwise the
        call goes entirely unmetered.

        That distinction is the reason a naive
        ``is_instrumented`` check causes silent breakage: a dev with
        ``auto_instrument=True`` but no ``paygent_context()`` block
        would see zero events.

        Re-evaluated on every event (not cached at construction) so
        runtime toggling works.  Fail-open on any exception (default
        to False = "do the metering ourselves") — under-counting is
        worse than double-counting from the user's perspective.
        """
        try:
            instr = getattr(self._pg, "_instrumentor", None)
            if instr is None or not instr.is_instrumented:
                return False
            from paygent.context import get_current_context
            return get_current_context() is not None
        except Exception:
            return False

    @property
    def user_id(self) -> str:
        """The user ID this callback tracks for."""
        return self._user_id

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM call starts. Records the model name."""
        try:
            model = kwargs.get("invocation_params", {}).get("model", None)
            if model is None:
                model = kwargs.get("invocation_params", {}).get("model_name", None)
            if model is None:
                model = serialized.get("kwargs", {}).get("model", None)
            if model is None:
                model = serialized.get("kwargs", {}).get("model_name", None)

            run_key = str(run_id) if run_id else str(uuid4())
            self._pending_runs[run_key] = {
                "model": model,
                "start_time": datetime.utcnow(),
            }
        except Exception:
            logger.debug("LangChainCallback: error in on_llm_start", exc_info=True)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM call completes. Meters the usage.

        De-duplication: when the SDK's monkey-patcher is active
        (``auto_instrument=True``), the underlying provider call
        (e.g. ``openai.Completions.create``) has already been metered
        by the patcher's wrapper.  Running this callback's metering
        too would double-count.  We detect that situation and exit
        early — but still clean up ``_pending_runs`` so we don't leak.
        """
        try:
            # Always pop pending state so we don't leak run IDs even when
            # we skip metering.  Done before the de-dup early-return.
            run_key = str(run_id) if run_id else None
            run_info = self._pending_runs.pop(run_key, {}) if run_key else {}

            if self._patcher_will_meter:
                logger.debug(
                    "LangChainCallback: skipping metering because the "
                    "patcher is active and a paygent_context is set "
                    "— the underlying provider call has already been "
                    "metered (de-dup)."
                )
                return

            from paygent.models import UsageEvent
            from paygent.metering import update_cache

            model = run_info.get("model")

            # Extract token usage from LangChain's LLMResult
            input_tokens = 0
            output_tokens = 0
            total_tokens = 0

            llm_output = getattr(response, "llm_output", None) or {}
            token_usage = llm_output.get("token_usage", {})

            if token_usage:
                input_tokens = token_usage.get("prompt_tokens", 0) or 0
                output_tokens = token_usage.get("completion_tokens", 0) or 0
                total_tokens = token_usage.get("total_tokens", 0) or 0
            else:
                # Try per-generation usage (newer LangChain)
                generations = getattr(response, "generations", [])
                for gen_list in generations:
                    for gen in gen_list:
                        gen_info = getattr(gen, "generation_info", {}) or {}
                        usage = gen_info.get("usage", {}) or gen_info.get("usage_metadata", {})
                        if usage:
                            input_tokens += usage.get("input_tokens", 0) or usage.get("prompt_tokens", 0) or 0
                            output_tokens += usage.get("output_tokens", 0) or usage.get("completion_tokens", 0) or 0
                            total_tokens += usage.get("total_tokens", 0) or 0

            if total_tokens == 0:
                total_tokens = input_tokens + output_tokens

            # Try to get model from response if not from start
            if not model:
                if "model_name" in llm_output:
                    model = llm_output["model_name"]
                elif "model" in llm_output:
                    model = llm_output["model"]

            # Calculate cost using the session's plan config
            session = self._pg.get_user_state(self._user_id)
            cost_tokens = 0.0
            cost_total = 0.0

            # Normalize model name (e.g. "gpt-4o-mini-2024-07-18" → "gpt-4o-mini")
            if session and model:
                from paygent.metering import normalize_model_name
                model = normalize_model_name(model, session.plan_config)

            rate = None
            if session and model:
                if model in session.plan_config.cost_rates:
                    rate = session.plan_config.cost_rates[model]
                elif session.plan_config.default_cost_rate is not None:
                    logger.warning(
                        "Model '%s' has no configured cost rate — using default_cost_rate.",
                        model,
                    )
                    rate = session.plan_config.default_cost_rate
                else:
                    logger.warning(
                        "Model '%s' has no configured cost rate and no default_cost_rate is set.",
                        model,
                    )

            if rate:
                cost_tokens = (input_tokens / 1000.0) * rate.input + (output_tokens / 1000.0) * rate.output
                cost_total = cost_tokens

            event = UsageEvent(
                id=str(uuid4()),
                user_id=self._user_id,
                session_id=self._session_id,
                timestamp=datetime.utcnow(),
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=total_tokens,
                cost_tokens=cost_tokens,
                cost_total=cost_total,
                metadata={**self._metadata, "source": "langchain"},
            )

            # Update in-memory cache
            if session:
                update_cache(session, event)

            # Push to event queue (background sync to backend / SQLite)
            self._pg._event_sink(event)

            # Fire registered pg.on_usage(...) callbacks.  The patcher's
            # wrapper does this too — without it, devs registering
            # on_usage hooks see no events when they're metering via
            # the LangChain callback path.
            try:
                self._pg._usage_handler(event)
            except Exception:
                logger.debug(
                    "LangChainCallback: usage_handler raised, swallowing",
                    exc_info=True,
                )

            logger.debug(
                "LangChainCallback: metered %d tokens (%s) for user %s",
                total_tokens, model, self._user_id,
            )
        except Exception:
            logger.debug("LangChainCallback: error in on_llm_end", exc_info=True)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Any = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM call errors. Cleans up pending run state."""
        try:
            run_key = str(run_id) if run_id else None
            if run_key:
                self._pending_runs.pop(run_key, None)
        except Exception:
            logger.debug("LangChainCallback: error in on_llm_error", exc_info=True)

    def on_chain_start(
        self, serialized: Dict[str, Any], inputs: Dict[str, Any], **kwargs: Any
    ) -> None:
        """Called when a chain starts. No-op."""
        pass

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        """Called when a chain ends. No-op."""
        pass

    def on_chain_error(self, error: BaseException, **kwargs: Any) -> None:
        """Called when a chain errors. No-op."""
        pass

    def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs: Any
    ) -> None:
        """Called when a tool starts. No-op."""
        pass

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Called when a tool ends. No-op."""
        pass

    def on_tool_error(self, error: BaseException, **kwargs: Any) -> None:
        """Called when a tool errors. No-op."""
        pass

    def on_text(self, text: str, **kwargs: Any) -> None:
        """Called on arbitrary text. No-op."""
        pass

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:
        """Called when agent takes an action. No-op."""
        pass

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:
        """Called when agent finishes. No-op."""
        pass
