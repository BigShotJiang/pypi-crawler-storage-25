"""CrewAI integration for Paygent.

Provides a step callback that hooks into CrewAI's task execution to
meter LLM usage per user. Works with CrewAI's Crew.kickoff() via
the step_callback parameter.

Usage:
    from paygent import Paygent
    from paygent.integrations import CrewAICallback

    pg = Paygent.init(api_key="pg_live_...")
    pg.start_session("user_123", plan="pro", plan_config=plan_config)

    callback = CrewAICallback(pg, user_id="user_123")
    crew = Crew(
        agents=[...],
        tasks=[...],
        step_callback=callback,
    )
    result = crew.kickoff()

This callback does NOT require auto-instrumentation — it works alongside
or instead of monkey-patching.

De-duplication when both paths are active:
    The patcher fires only when ``paygent_context()`` is set; this
    callback fires on every CrewAI step.  When BOTH
    auto-instrumentation is active AND a ``paygent_context`` is set,
    the same call would otherwise be metered twice.  We detect that
    situation and skip our own metering.

    When auto-instrumentation is on but no ``paygent_context`` is set,
    the patcher won't record anything — so this callback DOES meter,
    using the ``user_id`` from its constructor.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, Optional
from uuid import uuid4

logger = logging.getLogger("paygent")


class CrewAICallback:
    """CrewAI step callback that meters LLM usage via Paygent.

    Can be passed as `step_callback` to a CrewAI Crew, or called
    directly with a step output. Extracts token usage from the step
    output and pushes events to Paygent's event queue.

    Attributes:
        pg: The Paygent instance.
        user_id: The user to attribute usage to.
        session_id: Optional session identifier.
        metadata: Optional metadata attached to every event.
    """

    def __init__(
        self,
        pg: Any,
        user_id: str,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize the CrewAI callback.

        Args:
            pg: A Paygent instance (from Paygent.init()).
            user_id: The user to track usage for.
            session_id: Optional session identifier.
            metadata: Optional metadata to attach to all events.
        """
        self._pg = pg
        self._user_id = user_id
        self._session_id = session_id
        self._metadata = metadata or {}

    @property
    def user_id(self) -> str:
        """The user ID this callback tracks for."""
        return self._user_id

    @property
    def _patcher_will_meter(self) -> bool:
        """Whether the SDK's monkey-patcher will already meter this call.

        See ``LangChainCallback._patcher_will_meter`` for full rationale.
        Both conditions must hold for the patcher to actually record:
        instrumentation is active AND a ``paygent_context`` is set.
        Skipping when only the first is true would silently break
        ``auto_instrument=True`` + callback + no-context setups.
        """
        try:
            instr = getattr(self._pg, "_instrumentor", None)
            if instr is None or not instr.is_instrumented:
                return False
            from paygent.context import get_current_context
            return get_current_context() is not None
        except Exception:
            return False

    def __call__(self, step_output: Any) -> None:
        """Called by CrewAI after each agent step.

        Extracts token usage from the step output and creates a
        Paygent usage event. Fails silently on any error.

        When auto-instrumentation is active, skips metering entirely to
        avoid double-counting (the underlying ``Completions.create`` /
        ``Messages.create`` call has already been metered by the patcher).

        Args:
            step_output: The CrewAI step output object (TaskOutput or AgentAction).
        """
        try:
            if self._patcher_will_meter:
                logger.debug(
                    "CrewAICallback: skipping metering because the "
                    "patcher is active and a paygent_context is set "
                    "— the underlying provider call has already been "
                    "metered (de-dup)."
                )
                return
            self._process_step(step_output)
        except Exception:
            logger.debug("CrewAICallback: error processing step", exc_info=True)

    def _process_step(self, step_output: Any) -> None:
        """Extract usage from a CrewAI step and meter it."""
        from paygent.models import UsageEvent
        from paygent.metering import update_cache

        # CrewAI step outputs vary by version. Try common attributes.
        model = None
        input_tokens = 0
        output_tokens = 0
        total_tokens = 0

        # Try to extract from step_output attributes
        # CrewAI TaskOutput may have .token_usage or .usage_metrics
        usage = (
            getattr(step_output, "token_usage", None)
            or getattr(step_output, "usage_metrics", None)
            or getattr(step_output, "tokens", None)
        )

        if isinstance(usage, dict):
            input_tokens = usage.get("prompt_tokens", 0) or usage.get("input_tokens", 0) or 0
            output_tokens = usage.get("completion_tokens", 0) or usage.get("output_tokens", 0) or 0
            total_tokens = usage.get("total_tokens", 0) or 0

        # Try model extraction
        model = (
            getattr(step_output, "model", None)
            or getattr(step_output, "model_name", None)
        )

        # Also check if there's an llm_output or result dict
        result = getattr(step_output, "result", None)
        if isinstance(result, dict):
            if not model:
                model = result.get("model") or result.get("model_name")
            result_usage = result.get("usage", {})
            if result_usage and not input_tokens:
                input_tokens = result_usage.get("prompt_tokens", 0) or result_usage.get("input_tokens", 0) or 0
                output_tokens = result_usage.get("completion_tokens", 0) or result_usage.get("output_tokens", 0) or 0
                total_tokens = result_usage.get("total_tokens", 0) or 0

        if total_tokens == 0:
            total_tokens = input_tokens + output_tokens

        # Skip if no tokens were captured — likely not an LLM step
        if total_tokens == 0 and not model:
            return

        # Calculate cost
        session = self._pg.get_user_state(self._user_id)
        cost_tokens = 0.0
        cost_total = 0.0

        # Normalize model name (e.g. "gpt-4o-mini-2024-07-18" → "gpt-4o-mini")
        if session and model:
            from paygent.metering import normalize_model_name
            model = normalize_model_name(model, session.plan_config)

        rate = None
        if session and model:
            if model in session.plan_config.cost_rates:
                rate = session.plan_config.cost_rates[model]
            elif session.plan_config.default_cost_rate is not None:
                logger.warning(
                    "Model '%s' has no configured cost rate — using default_cost_rate.",
                    model,
                )
                rate = session.plan_config.default_cost_rate
            else:
                logger.warning(
                    "Model '%s' has no configured cost rate and no default_cost_rate is set.",
                    model,
                )

        if rate:
            cost_tokens = (input_tokens / 1000.0) * rate.input + (output_tokens / 1000.0) * rate.output
            cost_total = cost_tokens

        event = UsageEvent(
            id=str(uuid4()),
            user_id=self._user_id,
            session_id=self._session_id,
            timestamp=datetime.utcnow(),
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cost_tokens=cost_tokens,
            cost_total=cost_total,
            metadata={**self._metadata, "source": "crewai"},
        )

        # Update in-memory cache
        if session:
            update_cache(session, event)

        # Push to event queue (background sync to backend / SQLite)
        self._pg._event_sink(event)

        # Fire registered pg.on_usage(...) callbacks (matches the patcher's
        # contract — without this, devs registering on_usage hooks see no
        # events when metering goes through the CrewAI callback path).
        try:
            self._pg._usage_handler(event)
        except Exception:
            logger.debug(
                "CrewAICallback: usage_handler raised, swallowing",
                exc_info=True,
            )

        logger.debug(
            "CrewAICallback: metered %d tokens (%s) for user %s",
            total_tokens, model, self._user_id,
        )
