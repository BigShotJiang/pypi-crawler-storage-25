"""Local cache with backend sync orchestration.

This module bridges the gap between local SQLite storage and the Paygent
backend API. It handles:

1. **Session bootstrap with fallback**: Try backend first, fall back to
   local defaults if unreachable.
2. **Event sync**: Flush unsynced local events to backend, mark as synced.
3. **Offline mode**: Continue working with local storage when backend is
   down, auto-sync on reconnect.

The LocalCache is used by core.py's flush callback to add backend sync
on top of local SQLite persistence.

Sync Protocol:
  1. Events are always written to local SQLite first (fast, reliable)
  2. Background sync reads unsynced events from SQLite
  3. Posts batch to backend API
  4. On success, marks events as synced in SQLite
  5. On failure, events stay unsynced and retry on next cycle
"""

from __future__ import annotations

import logging
from typing import List, Optional

from paygent.api_client import ApiClient, BatchResult
from paygent.models import PlanConfig, CurrentUsage, UsageEvent, UserState
from paygent.storage.sqlite import SQLiteStorage

logger = logging.getLogger("paygent")

# Default number of events to sync per batch
DEFAULT_SYNC_BATCH_SIZE = 100


class LocalCache:
    """Orchestrates local storage + backend sync.

    Usage:
        cache = LocalCache(storage=sqlite_storage, api_client=api_client)
        session = cache.bootstrap_session("user_123")
        cache.store_and_sync(events)
        cache.sync_pending()
    """

    def __init__(
        self,
        storage: SQLiteStorage,
        api_client: Optional[ApiClient] = None,
        sync_batch_size: int = DEFAULT_SYNC_BATCH_SIZE,
    ) -> None:
        """
        Args:
            storage: Local SQLite storage instance.
            api_client: Backend API client. None = local-only mode.
            sync_batch_size: Max events per backend sync batch.
        """
        self._storage = storage
        self._api_client = api_client
        self._sync_batch_size = sync_batch_size
        self._backend_reachable: Optional[bool] = None  # None = unknown

    @property
    def has_backend(self) -> bool:
        """Whether a backend API client is configured."""
        return self._api_client is not None

    @property
    def backend_reachable(self) -> Optional[bool]:
        """Last known backend connectivity. None = not yet checked."""
        return self._backend_reachable

    # ------------------------------------------------------------------
    # Session Bootstrap
    # ------------------------------------------------------------------

    def bootstrap_session(
        self,
        user_id: str,
        fallback_plan: str = "default",
        fallback_config: Optional[PlanConfig] = None,
    ) -> UserState:
        """Bootstrap a user session, trying backend first then falling back.

        Flow:
        1. If backend configured, try GET /api/v1/users/{user_id}/session
        2. On success, return backend session data (source of truth)
        3. On failure, use fallback plan config (fail-open)

        Args:
            user_id: The user to bootstrap.
            fallback_plan: Plan name to use if backend is unreachable.
            fallback_config: Plan config to use if backend is unreachable.

        Returns:
            A UserState — always returns one, never None.
        """
        # Try backend first
        if self._api_client is not None:
            try:
                session = self._api_client.fetch_session(user_id)
                if session is not None:
                    self._backend_reachable = True
                    logger.debug(
                        "Bootstrapped session for %s from backend (plan=%s)",
                        user_id,
                        session.plan,
                    )
                    return session
                # fetch_session returned None — 404 or parse error
                # Fall through to create local session
                logger.debug(
                    "Backend returned no session for %s, using fallback",
                    user_id,
                )
            except Exception:
                self._backend_reachable = False
                logger.warning(
                    "Backend unreachable for session bootstrap, using local fallback",
                    exc_info=True,
                )

        # Fallback: create a local session with provided config
        config = fallback_config or PlanConfig()
        session = UserState(
            user_id=user_id,
            plan=fallback_plan,
            plan_config=config,
            current_usage=CurrentUsage(),
        )
        logger.debug(
            "Created local fallback session for %s (plan=%s)",
            user_id,
            fallback_plan,
        )
        return session

    # ------------------------------------------------------------------
    # Store + Sync Events
    # ------------------------------------------------------------------

    def store_and_sync(self, events: List[UsageEvent]) -> StoreResult:
        """Store events locally and attempt to sync to backend.

        This is the primary method called by the event queue flush callback.
        Events are ALWAYS stored locally first, then synced to backend if
        available.

        Args:
            events: List of usage events to persist.

        Returns:
            StoreResult with counts of stored, synced, and failed events.
        """
        result = StoreResult()

        if not events:
            return result

        # Step 1: Store locally (always)
        try:
            stored = self._storage.store_events_sync(events)
            result.stored_locally = stored
            logger.debug("Stored %d/%d events locally", stored, len(events))
        except Exception:
            logger.warning(
                "Failed to store %d events locally", len(events), exc_info=True
            )
            return result

        # Step 2: Sync to backend (if available)
        if self._api_client is not None:
            try:
                batch_result = self._api_client.post_events(events)
                if batch_result is not None:
                    result.synced_to_backend = batch_result.accepted
                    result.duplicates = batch_result.duplicates
                    self._backend_reachable = True

                    # Mark successfully synced events
                    event_ids = [e.id for e in events]
                    try:
                        self._storage.mark_synced_sync(event_ids)
                    except Exception:
                        logger.debug(
                            "Failed to mark events as synced", exc_info=True
                        )
                else:
                    self._backend_reachable = False
                    logger.debug("Backend returned None for event post")
            except Exception:
                self._backend_reachable = False
                logger.debug(
                    "Failed to sync events to backend, will retry later",
                    exc_info=True,
                )

        return result

    # ------------------------------------------------------------------
    # Sync Pending (catch-up)
    # ------------------------------------------------------------------

    def sync_pending(self) -> int:
        """Sync unsynced events from local storage to backend.

        Called periodically to catch up events that failed to sync
        on their initial flush (e.g., because backend was down).

        Returns:
            Number of events successfully synced.
        """
        if self._api_client is None:
            return 0

        total_synced = 0

        try:
            # Get unsynced events from local storage
            events = self._storage.get_unsynced_events_sync(
                limit=self._sync_batch_size
            )

            if not events:
                return 0

            logger.debug("Found %d unsynced events to sync", len(events))

            # Post to backend
            batch_result = self._api_client.post_events(events)

            if batch_result is not None:
                self._backend_reachable = True
                total_synced = batch_result.accepted + batch_result.duplicates

                # Mark all as synced (including duplicates — they're already on backend)
                event_ids = [e.id for e in events]
                try:
                    self._storage.mark_synced_sync(event_ids)
                except Exception:
                    logger.debug("Failed to mark synced after catch-up", exc_info=True)

                logger.debug(
                    "Synced %d events (accepted=%d, duplicates=%d)",
                    total_synced,
                    batch_result.accepted,
                    batch_result.duplicates,
                )
            else:
                self._backend_reachable = False
                logger.debug("Backend unreachable during sync_pending")

        except Exception:
            logger.debug("sync_pending failed", exc_info=True)

        return total_synced

    # ------------------------------------------------------------------
    # Cleanup (retention policy)
    # ------------------------------------------------------------------

    def cleanup_synced(self, retention_days: int = 7) -> int:
        """Delete synced events older than retention_days from local storage.

        Only removes events where synced=1 (already confirmed on the backend).
        Unsynced events are NEVER deleted regardless of age.

        Called periodically alongside sync_pending by the background thread.

        Args:
            retention_days: Keep synced events for this many days. Default 7.

        Returns:
            Number of deleted events.
        """
        try:
            deleted = self._storage.cleanup_synced_sync(retention_days)
            return deleted
        except Exception:
            logger.debug("cleanup_synced failed", exc_info=True)
            return 0

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def check_backend_health(self) -> bool:
        """Check if the backend is reachable.

        Updates the internal reachability state.
        Returns False if no API client is configured.
        """
        if self._api_client is None:
            return False

        try:
            healthy = self._api_client.health_check()
            self._backend_reachable = healthy
            return healthy
        except Exception:
            self._backend_reachable = False
            return False

    def get_pending_count(self) -> int:
        """Get the number of unsynced events in local storage."""
        try:
            events = self._storage.get_unsynced_events_sync(limit=1)
            # This is approximate — we'd need a count query for exact
            # But for status purposes, > 0 is what matters
            return len(events)
        except Exception:
            return 0


# ---------------------------------------------------------------------------
# Store Result
# ---------------------------------------------------------------------------


class StoreResult:
    """Result from a store_and_sync operation."""

    __slots__ = ("stored_locally", "synced_to_backend", "duplicates")

    def __init__(self) -> None:
        self.stored_locally: int = 0
        self.synced_to_backend: int = 0
        self.duplicates: int = 0

    @property
    def all_synced(self) -> bool:
        """Whether all locally stored events were synced to backend."""
        return self.stored_locally > 0 and (
            self.synced_to_backend + self.duplicates >= self.stored_locally
        )

    def __repr__(self) -> str:
        return (
            f"StoreResult(stored={self.stored_locally}, "
            f"synced={self.synced_to_backend}, duplicates={self.duplicates})"
        )
