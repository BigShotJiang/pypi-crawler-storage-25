"""Main Paygent class — wires all SDK modules together.

This is the single entry point for developers. It:
1. Initializes storage (local SQLite)
2. Sets up the event queue (background flush)
3. Instruments LLM providers (monkey-patching)
4. Manages user sessions (in-memory cache)
5. Provides the public API (track, get_usage, on_soft_gate, etc.)

Usage:
    from paygent import Paygent

    pg = Paygent.init(api_key="pg_live_...")

    with paygent_context(user_id="user_123"):
        response = openai.chat.completions.create(...)

    pg.shutdown()

Local mode (no backend):
    pg = Paygent.init()  # No API key → local-only mode
"""

from __future__ import annotations

import atexit
import logging
import os
import warnings
from typing import Any, Callable, List, Optional

from paygent.api_client import ApiClient, DEFAULT_BASE_URL
from paygent.context import paygent_context, paygent_track
from paygent.event_queue import EventQueue
from paygent.guardrails import (
    HardGateCallbackRegistry,
    PaygentAuthInvalid,
    PaygentBackendUnreachable,
    SessionStartCallbackRegistry,
    SoftGateCallbackRegistry,
    UsageCallbackRegistry,
    check_guard,
)
from paygent.instrumentor import Instrumentor
from paygent.local_cache import LocalCache
from paygent.metering import create_usage_event, update_cache
from paygent.models import (
    BillingPeriod,
    BudgetRemaining,
    CurrentUsage,
    GuardResult,
    MaxTokensAdvice,
    ModelUsage,
    PlanConfig,
    UsageEvent,
    UserState,
)
from paygent.providers import ProviderRegistry, TokenInfo, create_default_registry
from paygent.storage.sqlite import SQLiteStorage

logger = logging.getLogger("paygent")


def _merge_user_state(existing: UserState, refreshed: UserState) -> None:
    """Merge refreshed backend data into existing local state IN-PLACE.

    Updates the existing object's fields directly so that any code holding
    a reference to it (e.g. the patcher wrapper mid-call) sees the updated
    data.  Creating a new object would orphan the old reference and cause a
    race condition where metering updates the old object while _sessions
    points to the new one.

    Backend-authoritative data (plan, plan_config, period-level usage,
    billing_period) overwrites local values.  SDK-local session window
    data (session_cost, session_id, session_started_at) is preserved
    because the backend has no concept of clock-based session windows.
    """
    from datetime import datetime

    # Top-level fields from backend
    existing.plan = refreshed.plan
    existing.sdk_enabled = refreshed.sdk_enabled
    existing.plan_config = refreshed.plan_config
    existing.billing_period = refreshed.billing_period
    existing.last_refreshed = refreshed.last_refreshed or datetime.utcnow()

    # Period-level usage from backend (authoritative)
    existing.current_usage.period_cost = refreshed.current_usage.period_cost
    existing.current_usage.period_tokens_total = refreshed.current_usage.period_tokens_total
    existing.current_usage.period_tokens_by_model = dict(refreshed.current_usage.period_tokens_by_model)
    existing.current_usage.period_cost_by_model = dict(refreshed.current_usage.period_cost_by_model)

    # session_cost, session_id, session_started_at are NOT touched (preserved)
    # reserved_cost / reserved_tokens_by_model are ALSO preserved — they're
    # purely local in-flight state, the backend has no awareness of them.
    # Overwriting with refreshed.current_usage.reserved_* (which would be
    # zeros from a fresh fetch) would release every pending reservation
    # mid-flight — concurrent calls would stop seeing each other's holds.


class Paygent:
    """The economic brain for AI agents.

    Main orchestrator class that wires together:
    - Provider instrumentation (auto monkey-patching of LLM SDKs)
    - Session management (in-memory cache of user plans + usage)
    - Event queue (background flush to storage)
    - Local storage (SQLite fallback)
    - Guardrails (soft/hard gate callbacks)

    Usage:
        pg = Paygent.init(api_key="pg_live_...")
        # LLM calls are now automatically metered
        pg.shutdown()
    """

    # Class-level singleton — most apps only need one Paygent instance
    _instance: Optional["Paygent"] = None

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        db_path: str | None = None,
        flush_interval: float = 5.0,
        max_batch_size: int = 100,
        max_queue_size: int = 10_000,
        raise_on_hard_gate: bool = True,
        auto_instrument: bool = True,
        registry: ProviderRegistry | None = None,
        refresh_interval: float = 60.0,
        strict_backend: bool = False,
    ) -> None:
        """Create a Paygent instance. Prefer Paygent.init() for normal usage.

        Args:
            api_key: Paygent backend API key. None = local-only mode.
            base_url: Paygent backend URL. None = default (https://api.paygent.dev).
                Can also be set via PAYGENT_BASE_URL environment variable.
            db_path: Path for local SQLite database. None = default (~/.paygent/local.db).
            flush_interval: Seconds between background flush cycles.
            max_batch_size: Max events per flush batch.
            max_queue_size: Max queue depth before events are dropped.
            raise_on_hard_gate: Whether to raise PaygentLimitExceeded on hard gate.
            auto_instrument: Whether to automatically patch LLM providers on init.
            registry: Custom provider registry. None = default (OpenAI + Anthropic).
            strict_backend: If True, raise PaygentBackendUnreachable or
                PaygentAuthInvalid at init() when the backend is unreachable
                or rejects the API key.  Default False: emit a warning and
                continue in offline mode.  Set True for CI / production
                startup checks where silent degradation is unacceptable.
        """
        self._api_key = api_key
        self._base_url = base_url or os.environ.get("PAYGENT_BASE_URL", DEFAULT_BASE_URL)
        self._db_path = db_path
        self._raise_on_hard_gate = raise_on_hard_gate
        self._auto_instrument = auto_instrument
        self._refresh_interval = refresh_interval
        self._strict_backend = strict_backend

        # --- User state (in-memory cache) ---
        self._sessions: dict[str, UserState] = {}
        # --- Local plan configs (for local-only mode or assign_plan) ---
        self._plan_configs: dict[str, PlanConfig] = {}

        # --- Callback registries ---
        self._soft_gate_registry = SoftGateCallbackRegistry()
        self._hard_gate_registry = HardGateCallbackRegistry()
        self._usage_registry = UsageCallbackRegistry()
        self._session_start_registry = SessionStartCallbackRegistry()

        # --- Provider registry ---
        self._registry = registry or create_default_registry()

        # --- Storage (local SQLite) ---
        self._storage = SQLiteStorage(db_path=db_path)

        # --- API client (backend communication) ---
        self._api_client: Optional[ApiClient] = None
        if self._api_key:
            self._api_client = ApiClient(
                api_key=self._api_key,
                base_url=self._base_url,
            )

        # --- Local cache (bridges SQLite + backend sync) ---
        self._local_cache = LocalCache(
            storage=self._storage,
            api_client=self._api_client,
            sync_batch_size=max_batch_size,
        )

        # --- Event queue ---
        self._event_queue = EventQueue(
            flush_callback=self._flush_events,
            flush_interval=flush_interval,
            max_batch_size=max_batch_size,
            max_queue_size=max_queue_size,
            sync_pending_callback=self._sync_pending,
            sync_pending_interval=30.0,
            refresh_callback=self._refresh_stale_states if self._api_key else None,
            refresh_interval=refresh_interval,
        )

        # --- Instrumentor ---
        self._instrumentor = Instrumentor(
            registry=self._registry,
            session_lookup=self._session_lookup,
            event_sink=self._event_sink,
            soft_gate_handler=self._soft_gate_handler,
            hard_gate_handler=self._hard_gate_handler,
            usage_handler=self._usage_handler,
            raise_on_hard_gate=raise_on_hard_gate,
        )

        # Init-time backend-reachability state.  Set True after a successful
        # health check in _initialize(); stays False in local-only mode or
        # when the backend is unreachable / rejects the API key.  Can be
        # read by devs via ``pg.backend_reachable``.
        self._backend_reachable_at_init: bool = False

        self._initialized = False
        self._shutdown_registered = False

    # ------------------------------------------------------------------
    # Class-level init (preferred entry point)
    # ------------------------------------------------------------------

    @classmethod
    def init(
        cls,
        api_key: str | None = None,
        base_url: str | None = None,
        db_path: str | None = None,
        flush_interval: float = 5.0,
        max_batch_size: int = 100,
        max_queue_size: int = 10_000,
        raise_on_hard_gate: bool = True,
        auto_instrument: bool = True,
        registry: ProviderRegistry | None = None,
        refresh_interval: float = 60.0,
        strict_backend: bool = False,
    ) -> "Paygent":
        """Initialize Paygent. This is the recommended entry point.

        Creates the singleton instance, initializes local storage,
        starts the background event queue, and instruments LLM providers.

        When ``api_key`` is set, also runs a synchronous health check
        against the backend.  If the backend is unreachable or the API
        key is rejected, a warning is emitted and the SDK continues in
        offline mode.  Pass ``strict_backend=True`` to raise instead —
        useful for CI / production startup checks.

        Args:
            api_key: Paygent backend API key. None = local-only mode.
            base_url: Paygent backend URL. None = default (https://api.paygent.dev).
                Can also be set via PAYGENT_BASE_URL environment variable.
            db_path: Path for local SQLite database.
            flush_interval: Seconds between background flush cycles.
            max_batch_size: Max events per flush batch.
            max_queue_size: Max queue depth before events are dropped.
            raise_on_hard_gate: Whether to raise PaygentLimitExceeded on hard gate.
            auto_instrument: Whether to automatically patch LLM providers.
            registry: Custom provider registry.
            refresh_interval: Seconds between periodic UserState refreshes
                from backend (default 60s). Only active in connected mode.
                In multi-worker deployments this also bounds the maximum
                cache-drift window — see README "Known Limitations".
            strict_backend: If True, raise instead of warn when the backend
                check fails at init.  Default False (warn + continue).

        Returns:
            The Paygent singleton instance.
        """
        # Double-init guard: tear down any previous instance cleanly so we
        # don't leak its event queue thread, monkey-patches, SQLite connection,
        # or httpx client. Common in notebooks, hot-reload servers, and tests
        # that call init() per fixture.
        if cls._instance is not None:
            logger.warning(
                "Paygent.init() called while a previous instance is still "
                "active — shutting it down before re-initializing."
            )
            try:
                cls._instance.shutdown()
            except Exception:
                logger.debug("Error during previous-instance shutdown", exc_info=True)
            cls._instance = None

        instance = cls(
            api_key=api_key,
            base_url=base_url,
            db_path=db_path,
            flush_interval=flush_interval,
            max_batch_size=max_batch_size,
            max_queue_size=max_queue_size,
            raise_on_hard_gate=raise_on_hard_gate,
            auto_instrument=auto_instrument,
            registry=registry,
            refresh_interval=refresh_interval,
            strict_backend=strict_backend,
        )
        instance._initialize()
        cls._instance = instance
        return instance

    @classmethod
    def get_instance(cls) -> Optional["Paygent"]:
        """Get the current Paygent singleton, or None if not initialized."""
        return cls._instance

    # ------------------------------------------------------------------
    # Initialization (internal)
    # ------------------------------------------------------------------

    def _initialize(self) -> None:
        """Initialize storage, API client, event queue, and instrumentation.

        Called by init(). Safe to call multiple times (idempotent).
        """
        if self._initialized:
            return

        # Initialize local storage (sync — happens once at startup)
        try:
            self._storage.initialize_sync()
            logger.info("Local storage initialized at %s", self._storage.db_path)
        except Exception:
            logger.warning(
                "Failed to initialize local storage, events will be in-memory only",
                exc_info=True,
            )

        # Open API client connection (if configured)
        if self._api_client is not None:
            try:
                self._api_client.open()
                logger.info("API client connected to %s", self._base_url)
            except Exception:
                logger.warning(
                    "Failed to open API client (backend may be unreachable), "
                    "continuing in offline mode",
                    exc_info=True,
                )

        # Start background event queue
        try:
            self._event_queue.start()
            logger.debug("Event queue started")
        except Exception:
            logger.warning("Failed to start event queue", exc_info=True)

        # Auto-instrument LLM providers
        if self._auto_instrument:
            try:
                patched = self._instrumentor.instrument()
                if patched:
                    logger.info("Auto-instrumented: %s", patched)
            except Exception:
                logger.warning("Failed to auto-instrument providers", exc_info=True)

        # Register atexit handler for clean shutdown
        if not self._shutdown_registered:
            atexit.register(self._atexit_shutdown)
            self._shutdown_registered = True

        # Probe the backend so init() surfaces connectivity / auth issues
        # loudly (via warning, or raise if strict_backend=True).  Skipped
        # in local-only mode.
        if self._api_client is not None:
            self._check_backend_health()

        self._initialized = True
        mode = "connected" if self._api_key else "local-only"
        logger.info("Paygent initialized (mode=%s, base_url=%s)", mode, self._base_url)

    def _check_backend_health(self) -> None:
        """One-shot backend probe done at init() in connected mode.

        Delegates to ``ApiClient.diagnose_backend()`` to distinguish
        "backend unreachable" from "API key rejected" — so we can give
        the dev an actionable message rather than a generic "something
        failed."

        Default behavior: emit a ``UserWarning`` (printed to stderr by
        Python's ``warnings`` module) and set
        ``self._backend_reachable_at_init = False``.  SDK continues in
        offline mode.

        With ``self._strict_backend = True``: raise
        ``PaygentBackendUnreachable`` or ``PaygentAuthInvalid`` instead —
        useful for CI / production startup checks where silent
        degradation is unacceptable.
        """
        assert self._api_client is not None  # guarded at caller

        try:
            status, detail = self._api_client.diagnose_backend(timeout=3.0)
        except Exception:
            # Shouldn't happen — diagnose_backend has its own try/except —
            # but be defensive so init() never crashes on the probe.
            logger.debug("diagnose_backend itself raised unexpectedly", exc_info=True)
            status, detail = ("other", "internal error during health check")

        if status == "ok":
            self._backend_reachable_at_init = True
            logger.debug("Backend health check: ok (base_url=%s)", self._base_url)
            return

        self._backend_reachable_at_init = False

        if status == "unreachable":
            message = (
                f"Could not reach Paygent backend at {self._base_url} ({detail}). "
                "SDK is running in OFFLINE mode — events queue locally and will "
                "sync when the backend returns; guard checks use last-known "
                "cached state.\n"
                "To fail fast instead, use Paygent.init(..., strict_backend=True). "
                "To suppress this warning: "
                "warnings.filterwarnings('ignore', category=PaygentBackendUnreachable)"
            )
            if self._strict_backend:
                raise PaygentBackendUnreachable(message)
            warnings.warn(message, PaygentBackendUnreachable, stacklevel=4)
            return

        if status == "auth_invalid":
            message = (
                f"Paygent backend at {self._base_url} rejected the API key "
                f"({detail}). SDK will NOT sync to the backend and guardrails "
                "will NOT be enforced server-side until this is fixed. "
                "Check that your PAYGENT_API_KEY is correct and active.\n"
                "To fail fast instead, use Paygent.init(..., strict_backend=True)."
            )
            if self._strict_backend:
                raise PaygentAuthInvalid(message)
            warnings.warn(message, PaygentAuthInvalid, stacklevel=4)
            return

        # status == "other" — unexpected backend response.  Warn but treat
        # as PaygentBackendUnreachable so users have one warning class to
        # filter on for any init-time failure.
        message = (
            f"Paygent backend at {self._base_url} returned an unexpected "
            f"response ({detail}). SDK continues in offline mode."
        )
        if self._strict_backend:
            raise PaygentBackendUnreachable(message)
        warnings.warn(message, PaygentBackendUnreachable, stacklevel=4)

    # ------------------------------------------------------------------
    # Session Management
    # ------------------------------------------------------------------

    def start_session(
        self,
        user_id: str,
        plan: str = "default",
        plan_config: PlanConfig | None = None,
    ) -> UserState:
        """Pre-warm the session cache for a user (optional).

        This is optional — the SDK auto-fetches session data on first use
        of any user_id via paygent_context, wrap(), awrap(), or @track.
        Call this explicitly if you want to pre-warm the cache before the
        first LLM call (e.g. at request start) to avoid the small latency
        hit on the first call.

        In connected mode (API key set), tries to fetch the user's plan
        config and current usage from the backend. The provided plan_config
        is used as a fallback if the backend is unreachable.

        In local mode (no API key), creates a session from the provided
        plan_config directly.

        Args:
            user_id: The unique identifier for the end user.
            plan: Plan name (e.g. "free", "pro").
            plan_config: Plan configuration. If None, uses a permissive default.
                In connected mode, this serves as a fallback if the backend
                is unreachable.

        Returns:
            The cached UserState for this user.
        """
        try:
            from datetime import datetime

            if plan_config is None:
                plan_config = PlanConfig()  # Permissive defaults (inf limits)

            # Check for existing session — preserve accumulated usage
            existing = self._sessions.get(user_id)
            if existing is not None:
                # Update plan config but keep current usage
                existing.plan = plan
                existing.plan_config = plan_config
                return existing

            # In connected mode, try backend first via LocalCache
            if self._api_client is not None:
                session = self._local_cache.bootstrap_session(
                    user_id=user_id,
                    fallback_plan=plan,
                    fallback_config=plan_config,
                )
            else:
                # Local-only mode — use provided config directly
                session = UserState(
                    user_id=user_id,
                    plan=plan,
                    plan_config=plan_config,
                    current_usage=CurrentUsage(),
                )

            # Ensure session window is initialized
            self._ensure_session_window(session)

            self._sessions[user_id] = session
            logger.debug("Started session for user %s (plan=%s)", user_id, session.plan)
            self._session_start_handler(session)
            return session
        except Exception:
            logger.warning(
                "Failed to start session for %s, creating minimal session",
                user_id,
                exc_info=True,
            )
            session = UserState(
                user_id=user_id,
                plan=plan,
                plan_config=PlanConfig(),
                current_usage=CurrentUsage(),
            )
            self._sessions[user_id] = session
            self._session_start_handler(session)
            return session

    def get_session(self, user_id: str) -> Optional[UserState]:
        """Get the cached session for a user, or None if not found.

        Deprecated: use get_user_state() instead.
        """
        return self._sessions.get(user_id)

    def get_user_state(self, user_id: str) -> UserState:
        """Get the full user state, auto-loading if not cached.

        Uses the 5-step fallback chain (memory → backend → SQLite snapshot →
        expired snapshot → permissive defaults) so this always returns a
        UserState — callers never need to handle None.

        This is the power-user accessor — the returned object is the live
        cached instance, so mutations (e.g. in tests) are reflected in the
        SDK's subsequent guard checks and metering. For read-only dashboard
        or quota-check use cases, prefer get_usage() / get_model_usage().

        Note: first call for a new user_id may hit the backend.
        """
        return self._get_user_state(user_id)

    def remove_session(self, user_id: str) -> None:
        """Remove a user's session from the cache.

        Deprecated: use reset_user() instead.
        """
        self._sessions.pop(user_id, None)

    # ------------------------------------------------------------------
    # New API: Auto-loading User State
    # ------------------------------------------------------------------

    def _get_user_state(self, user_id: str) -> UserState:
        """Auto-load user state with 5-step fallback chain.

        This is the core internal method that ensures a UserState always
        exists for any user_id. Called by _session_lookup() and wrap().
        This makes start_session() optional — the SDK lazily fetches
        session data on first use of any user_id.

        Fallback chain:
        1. In-memory cache — check billing period validity
        2. Backend API — save snapshot to SQLite
        3. SQLite snapshot — check period validity
        4. Expired snapshot — keep plan config, reset usage counters
        5. No data at all — permissive defaults (inf limits)

        Always returns a UserState, never None (fail-open).
        """
        from datetime import datetime
        from uuid import uuid4

        # Step 1: In-memory cache
        state = self._sessions.get(user_id)
        if state is not None:
            if self._is_period_valid(state):
                return state
            # Period expired — try to refresh from backend so we pick up the
            # new billing window.  If the backend is unreachable, fall back
            # to a local reset: clear counters AND clear billing_period so
            # subsequent lookups don't re-enter this branch and wipe out
            # metering that happened in the meantime.
            logger.debug(
                "Billing period expired for %s, attempting backend refresh", user_id
            )
            refreshed = None
            if self._api_client is not None:
                try:
                    refreshed = self._api_client.fetch_session(user_id)
                except Exception:
                    logger.debug("Backend refresh after expiry failed for %s", user_id, exc_info=True)
            if refreshed is not None:
                _merge_user_state(state, refreshed)
                self._ensure_session_window(state)
                try:
                    self._storage.save_snapshot_sync(state)
                except Exception:
                    logger.debug("Failed to save snapshot after expiry refresh", exc_info=True)
                return state
            # Backend unreachable — local reset (band-aid to avoid re-loop)
            state.current_usage = CurrentUsage()
            state.billing_period = None
            self._ensure_session_window(state)
            return state

        # Step 2: Backend API
        if self._api_client is not None:
            try:
                state = self._api_client.fetch_session(user_id)
                if state is not None:
                    # --- Session-identity continuity across process restarts ---
                    # The backend doesn't own session_id / session_started_at /
                    # session_cost — they're purely SDK-local.  On a cold start
                    # (fresh Python process), in-memory _sessions is empty so
                    # we land here, but a snapshot on disk from a previous
                    # process may still hold a live session window.  Carry
                    # those fields over so that, e.g., a worker process rotating
                    # under Gunicorn or a script being re-run doesn't mint a
                    # new session_id every time.
                    #
                    # The rotation logic in _maybe_rotate_session handles stale
                    # snapshots correctly: if the carried-over session_started_at
                    # is older than session_timeout_minutes, the first guard
                    # check / cache update will rotate it cleanly.
                    self._restore_session_window_from_snapshot(user_id, state)
                    self._ensure_session_window(state)
                    self._sessions[user_id] = state
                    # Save snapshot (now reflecting the preserved session window)
                    try:
                        self._storage.save_snapshot_sync(state)
                    except Exception:
                        logger.debug("Failed to save snapshot after fetch", exc_info=True)
                    self._session_start_handler(state)
                    return state
            except Exception:
                logger.debug("Backend fetch failed for %s", user_id, exc_info=True)

        # Step 3: SQLite snapshot
        try:
            state = self._storage.load_snapshot_sync(user_id)
            if state is not None:
                if self._is_period_valid(state):
                    self._ensure_session_window(state)
                    self._sessions[user_id] = state
                    logger.debug("Loaded snapshot for %s", user_id)
                    self._session_start_handler(state)
                    return state
                # Step 4: Expired snapshot — keep config, reset usage
                state.current_usage = CurrentUsage()
                self._ensure_session_window(state)
                self._sessions[user_id] = state
                logger.debug("Loaded expired snapshot for %s, reset counters", user_id)
                self._session_start_handler(state)
                return state
        except Exception:
            logger.debug("Snapshot load failed for %s", user_id, exc_info=True)

        # Step 5: No data — permissive defaults
        plan_config = self._plan_configs.get("default", PlanConfig())
        state = UserState(
            user_id=user_id,
            plan="default",
            plan_config=plan_config,
            current_usage=CurrentUsage(),
        )
        self._ensure_session_window(state)
        self._sessions[user_id] = state
        logger.debug("Created permissive default state for %s", user_id)
        self._session_start_handler(state)
        return state

    def _ensure_session_window(self, state: UserState) -> None:
        """Initialize session window fields if not already set.

        Idempotent — if ``session_id`` / ``session_started_at`` are already
        populated (e.g. copied over from a snapshot in
        ``_restore_session_window_from_snapshot``), leaves them alone.
        Only stamps fresh UUIDs on the very first boot for this user when
        no prior state exists anywhere.
        """
        from datetime import datetime
        from uuid import uuid4

        usage = state.current_usage
        if usage.session_id is None:
            usage.session_id = str(uuid4())
        if usage.session_started_at is None:
            usage.session_started_at = datetime.utcnow()

    def _restore_session_window_from_snapshot(
        self, user_id: str, state: UserState
    ) -> None:
        """Carry over SDK-local session state from the on-disk snapshot.

        Session identity (``session_id`` / ``session_started_at``) and the
        running ``session_cost`` counter live only in the SDK's memory and
        on-disk snapshot — the backend doesn't track them.  On a cold start
        (fresh process), ``state`` comes from the backend with these fields
        cleared, so without this step every process restart would mint a
        new ``session_id`` and reset ``session_cost`` to zero — breaking
        session-based rate limits and analytics.

        This function looks up the snapshot, and if it exists and still has
        a session window recorded, copies those three fields onto ``state``.
        Stale snapshots (session older than ``session_timeout_minutes``)
        naturally rotate on first use via ``_maybe_rotate_session`` — there
        is no need to filter them out here.

        Silently no-ops on any error (fail-open).
        """
        try:
            snapshot = self._storage.load_snapshot_sync(user_id)
            if snapshot is None:
                return
            snap_usage = snapshot.current_usage
            if snap_usage.session_id is None or snap_usage.session_started_at is None:
                return
            state.current_usage.session_id = snap_usage.session_id
            state.current_usage.session_started_at = snap_usage.session_started_at
            # session_cost is a rate-limiter counter within the current
            # window — preserve it so that `max_spend_per_session` can't be
            # bypassed by restart-spamming the process.
            state.current_usage.session_cost = snap_usage.session_cost
            logger.debug(
                "Restored session window from snapshot for %s (session_id=%s)",
                user_id,
                snap_usage.session_id,
            )
        except Exception:
            logger.debug(
                "Failed to restore session window from snapshot for %s",
                user_id,
                exc_info=True,
            )

    def _is_period_valid(self, state: UserState) -> bool:
        """Check if the user's billing period is still valid."""
        from datetime import datetime, timezone

        if state.billing_period is None:
            return True  # No period = always valid (calendar-month or unlimited)

        now = datetime.now(timezone.utc)
        end = state.billing_period.end
        # Ensure both datetimes are timezone-aware for comparison
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        return now < end

    def refresh_user(self, user_id: str) -> UserState:
        """Force re-fetch user state from the backend.

        On-demand refresh (Approach C). Useful when the developer knows
        the backend state has changed (e.g., after a plan upgrade).

        Falls back to existing cached state if the backend is unreachable.
        """
        if self._api_client is not None:
            try:
                new_state = self._api_client.fetch_session(user_id)
                if new_state is not None:
                    existing = self._sessions.get(user_id)
                    if existing is not None:
                        _merge_user_state(existing, new_state)
                    else:
                        existing = new_state
                        self._sessions[user_id] = existing
                    try:
                        self._storage.save_snapshot_sync(existing)
                    except Exception:
                        logger.debug("Failed to save snapshot after refresh", exc_info=True)
                    return existing
            except Exception:
                logger.debug("refresh_user failed for %s", user_id, exc_info=True)

        # Fall back to existing state or auto-load
        return self._get_user_state(user_id)

    def reset_user(self, user_id: str) -> None:
        """Clear cached state for a user.

        The next LLM call for this user will trigger a fresh auto-load
        from the backend or SQLite snapshot.
        """
        self._sessions.pop(user_id, None)

    def configure_plan(self, plan_name: str, config: PlanConfig) -> None:
        """Store a plan configuration for local-only mode.

        In local mode (no backend), this provides plan configs that
        assign_plan() and the auto-load fallback chain can reference.
        """
        self._plan_configs[plan_name] = config

    def assign_plan(
        self,
        user_id: str,
        plan: str,
        billing_period: BillingPeriod | None = None,
    ) -> UserState:
        """Assign a plan to a user in local-only mode.

        Creates or updates the user's state with the named plan config
        (previously registered via configure_plan()). If the plan is not
        found, falls back to permissive defaults.

        Args:
            user_id: The user to assign the plan to.
            plan: Plan name (must be registered via configure_plan()).
            billing_period: Optional billing period dates.

        Returns:
            The updated UserState.
        """
        config = self._plan_configs.get(plan, PlanConfig())
        existing = self._sessions.get(user_id)

        if existing is not None:
            existing.plan = plan
            existing.plan_config = config
            existing.billing_period = billing_period
            return existing

        state = UserState(
            user_id=user_id,
            plan=plan,
            plan_config=config,
            current_usage=CurrentUsage(),
            billing_period=billing_period,
        )
        self._sessions[user_id] = state
        self._session_start_handler(state)
        return state

    # ------------------------------------------------------------------
    # Usage Queries
    # ------------------------------------------------------------------

    def get_usage(self, user_id: str) -> CurrentUsage:
        """Get current usage for a user, auto-loading if not cached.

        Returns a snapshot (deep copy) of the user's CurrentUsage — mutating
        it does not affect the SDK's internal state. Always returns a
        CurrentUsage object (never None); uses the same 5-step fallback
        chain as get_user_state() so the caller does not need to call
        start_session() first.

        This is the safe, read-only accessor for quota UIs, dashboards,
        and pre-call budget checks. For historical usage across billing
        periods, query the backend API directly.

        Note: first call for a new user_id may hit the backend.
        """
        session = self._get_user_state(user_id)
        return session.current_usage.model_copy(deep=True)

    def get_model_usage(self, user_id: str) -> list[ModelUsage]:
        """Get per-model usage breakdown for a user, auto-loading if needed.

        Returns a list of ModelUsage objects with token counts, costs,
        and limits (if configured). Uses the same 5-step fallback chain as
        get_user_state() — always returns a list (possibly empty when the
        user has no configured model limits and no metered usage yet).
        """
        session = self._get_user_state(user_id)

        usage = session.current_usage
        config = session.plan_config
        result = []

        # Collect all models from both usage and limits
        all_models = set(usage.period_tokens_by_model.keys())
        all_models.update(config.model_limits.keys())

        for model in sorted(all_models):
            tokens_used = usage.period_tokens_by_model.get(model, 0)
            cost = usage.period_cost_by_model.get(model, 0.0)
            model_limit = config.model_limits.get(model)
            tokens_limit = (
                model_limit.max_tokens_per_period if model_limit else None
            )
            result.append(
                ModelUsage(
                    model=model,
                    tokens_used=tokens_used,
                    tokens_limit=tokens_limit,
                    cost=cost,
                )
            )

        return result

    def check_guard(
        self,
        user_id: str,
        model: str | None = None,
    ) -> GuardResult:
        """Manually check guardrails for a user.

        Useful for pre-flight checks before starting an expensive operation.
        Returns GuardResult(status="ok") if no session exists (fail-open).
        """
        session = self._sessions.get(user_id)
        if session is None:
            return GuardResult(status="ok")
        return check_guard(session, model=model)

    def is_within_limit(
        self,
        user_id: str,
        model: str | None = None,
    ) -> bool:
        """Return True if the user is NOT hard-gated, False if they are.

        Thin convenience wrapper over ``check_guard``.  A soft gate state
        counts as "within limit" — soft gate is a warning, not a block —
        so this only returns False when the next call would be rejected.

        Auto-loads the user's session if not cached.  Fail-open on any
        error (returns True to avoid blocking the dev's app).

        Useful before starting an expensive operation::

            if pg.is_within_limit(user_id, model="gpt-4o"):
                response = openai.chat.completions.create(...)
            else:
                return "Budget exhausted — please upgrade."
        """
        try:
            session = self._get_user_state(user_id)
            result = check_guard(session, model=model)
            return result.status != "hard_gate"
        except Exception:
            logger.debug("is_within_limit failed for %s, returning True (fail-open)", user_id, exc_info=True)
            return True

    def get_remaining_budget(self, user_id: str) -> BudgetRemaining:
        """Multi-dimensional snapshot of the user's remaining budget.

        Returns a ``BudgetRemaining`` with:
        - ``period_spend_remaining``: dollars under the period cap
        - ``session_spend_remaining``: dollars under the session cap
        - ``model_tokens_remaining``: per-configured-model token budget
        - ``most_constrained``: which dimension is closest to its limit

        Unlimited dimensions return ``float('inf')`` (for spend) or
        ``None`` (for per-model tokens), matching PlanConfig semantics.

        Auto-loads the session if not cached.  Returns a safe default
        snapshot on any error.
        """
        try:
            session = self._get_user_state(user_id)
        except Exception:
            logger.debug("get_remaining_budget failed for %s", user_id, exc_info=True)
            return BudgetRemaining()

        config = session.plan_config
        usage = session.current_usage

        # Period spend remaining
        if config.max_spend_per_period == float("inf"):
            period_remaining = float("inf")
            period_pct = 0.0
        else:
            period_remaining = max(0.0, config.max_spend_per_period - usage.period_cost)
            period_pct = (
                usage.period_cost / config.max_spend_per_period
                if config.max_spend_per_period > 0
                else 0.0
            )

        # Session spend remaining
        if config.max_spend_per_session == float("inf"):
            session_remaining = float("inf")
            session_pct = 0.0
        else:
            session_remaining = max(0.0, config.max_spend_per_session - usage.session_cost)
            session_pct = (
                usage.session_cost / config.max_spend_per_session
                if config.max_spend_per_session > 0
                else 0.0
            )

        # Per-model token remaining
        model_tokens_remaining: dict[str, int | None] = {}
        model_tokens_pct_max = 0.0
        for model_name, limit in config.model_limits.items():
            if limit.max_tokens_per_period is None:
                model_tokens_remaining[model_name] = None
                continue
            used = usage.period_tokens_by_model.get(model_name, 0)
            remaining = max(0, limit.max_tokens_per_period - used)
            model_tokens_remaining[model_name] = remaining
            if limit.max_tokens_per_period > 0:
                pct = used / limit.max_tokens_per_period
                if pct > model_tokens_pct_max:
                    model_tokens_pct_max = pct

        # Determine most constrained dimension
        candidates = [
            ("period_spend", period_pct, config.max_spend_per_period != float("inf")),
            ("session_spend", session_pct, config.max_spend_per_session != float("inf")),
            ("model_tokens", model_tokens_pct_max, bool(model_tokens_remaining)),
        ]
        bounded = [(name, pct) for name, pct, has_limit in candidates if has_limit]
        if bounded:
            most_constrained = max(bounded, key=lambda x: x[1])[0]
        else:
            most_constrained = "unbounded"

        return BudgetRemaining(
            period_spend_remaining=period_remaining,
            session_spend_remaining=session_remaining,
            model_tokens_remaining=model_tokens_remaining,
            most_constrained=most_constrained,
        )

    def get_max_tokens(
        self,
        user_id: str,
        model: str,
        *,
        estimated_input_tokens: int = 0,
        messages: list | None = None,
        hard_cap: int = 4096,
    ) -> MaxTokensAdvice:
        """Recommend a safe ``max_tokens`` value for the next LLM call.

        Computes the largest output-token count that, combined with the
        given input estimate, will not push this user past any configured
        hard gate.  Checks all three dimensions (period spend, session spend,
        per-model token cap) and returns the minimum.

        Args:
            user_id: The end user the call will be attributed to.
            model: The model the dev intends to call.  Used for cost-rate
                lookup and to check any per-model token cap on the plan.
            estimated_input_tokens: If the dev already knows their input
                token count (or has a tighter estimate than chars/4), pass
                it here.  Takes precedence over ``messages``.
            messages: If set, Paygent estimates the input tokens using its
                internal heuristic.  Convenience for devs who don't want
                to tokenize themselves.  Ignored if ``estimated_input_tokens``
                is non-zero.
            hard_cap: Upper bound on the returned ``max_tokens`` regardless
                of headroom.  Prevents returning absurdly large numbers
                when limits are effectively unbounded.  Default 4096.

        Returns:
            A ``MaxTokensAdvice`` with ``max_tokens`` (0 = don't call),
            ``binding_limit`` (which dimension is tightest), and
            diagnostic ``*_remaining`` fields.

        Failure modes:
            - Unknown user → auto-loads via the fallback chain.
            - Unknown model, no cost rate → spend dimensions become
              unbounded (can't price output); falls back to model_tokens
              or hard_cap.
            - Any exception → returns a safe default with max_tokens=0
              and binding_limit="blocked" (fail-CLOSED here — better to
              tell the dev "don't call" than to silently bypass limits
              because of a bug in this helper).
        """
        try:
            session = self._get_user_state(user_id)
        except Exception:
            logger.debug("get_max_tokens failed for %s", user_id, exc_info=True)
            return MaxTokensAdvice(max_tokens=0, binding_limit="blocked")

        config = session.plan_config
        usage = session.current_usage

        # If the user is ALREADY over a hard gate (ignoring the new call),
        # refuse outright.  Don't even look at headroom.
        pre_check = check_guard(session, model=model)
        if pre_check.status == "hard_gate":
            return MaxTokensAdvice(
                max_tokens=0,
                binding_limit="blocked",
                period_spend_remaining=max(0.0, config.max_spend_per_period - usage.period_cost)
                    if config.max_spend_per_period != float("inf") else float("inf"),
                session_spend_remaining=max(0.0, config.max_spend_per_session - usage.session_cost)
                    if config.max_spend_per_session != float("inf") else float("inf"),
                model_tokens_remaining=self._model_tokens_remaining(config, usage, model),
            )

        # Resolve input estimate — explicit value wins over messages heuristic
        if estimated_input_tokens == 0 and messages is not None:
            try:
                from paygent.guardrails import estimate_input_tokens
                estimated_input_tokens = estimate_input_tokens(messages)
            except Exception:
                estimated_input_tokens = 0

        # Look up the cost rate we'd use for this model
        rate = config.cost_rates.get(model) or config.default_cost_rate

        # --- Compute output-token headroom from each dimension ---
        candidates: list[tuple[str, int]] = []

        # Spend dimensions — only compute if we have a rate (otherwise output
        # cost is unknown and spend doesn't constrain output tokens).
        if rate is not None and rate.output > 0:
            output_rate_per_token = rate.output / 1000.0
            input_cost = (estimated_input_tokens / 1000.0) * rate.input

            if config.max_spend_per_period != float("inf"):
                # Apply the plan's hard-gate fraction (usually 1.0 but some
                # plans tighten it) — use the SAME threshold the guard does.
                period_headroom_cost = (
                    config.max_spend_per_period * config.hard_gate_at
                    - usage.period_cost - input_cost
                )
                period_tokens = int(max(0, period_headroom_cost / output_rate_per_token))
                candidates.append(("period_spend", period_tokens))

            if config.max_spend_per_session != float("inf"):
                session_headroom_cost = (
                    config.max_spend_per_session * config.hard_gate_at
                    - usage.session_cost - input_cost
                )
                session_tokens = int(max(0, session_headroom_cost / output_rate_per_token))
                candidates.append(("session_spend", session_tokens))

        # Per-model token cap — input tokens eat into this too
        limit = config.model_limits.get(model)
        if limit is not None and limit.max_tokens_per_period is not None:
            used = usage.period_tokens_by_model.get(model, 0)
            cap = int(limit.max_tokens_per_period * config.hard_gate_at)
            remaining_tokens = max(0, cap - used - estimated_input_tokens)
            candidates.append(("model_tokens", remaining_tokens))

        # Diagnostic snapshots (always filled in — don't leak inf unnecessarily)
        period_remaining = (
            float("inf") if config.max_spend_per_period == float("inf")
            else max(0.0, config.max_spend_per_period - usage.period_cost)
        )
        session_remaining = (
            float("inf") if config.max_spend_per_session == float("inf")
            else max(0.0, config.max_spend_per_session - usage.session_cost)
        )
        model_tokens_remaining = self._model_tokens_remaining(config, usage, model)

        if not candidates:
            # No finite limits → hard_cap is the only ceiling
            return MaxTokensAdvice(
                max_tokens=hard_cap,
                binding_limit="unbounded",
                period_spend_remaining=period_remaining,
                session_spend_remaining=session_remaining,
                model_tokens_remaining=model_tokens_remaining,
            )

        binding, headroom = min(candidates, key=lambda x: x[1])
        max_out = min(headroom, hard_cap)
        return MaxTokensAdvice(
            max_tokens=max_out,
            binding_limit=binding,
            period_spend_remaining=period_remaining,
            session_spend_remaining=session_remaining,
            model_tokens_remaining=model_tokens_remaining,
        )

    @staticmethod
    def _model_tokens_remaining(
        config: PlanConfig, usage: CurrentUsage, model: str,
    ) -> int | None:
        """Helper: tokens left for a specific model, or None if unlimited."""
        limit = config.model_limits.get(model)
        if limit is None or limit.max_tokens_per_period is None:
            return None
        used = usage.period_tokens_by_model.get(model, 0)
        return max(0, limit.max_tokens_per_period - used)

    # ------------------------------------------------------------------
    # Event Callbacks
    # ------------------------------------------------------------------

    def on_soft_gate(self, callback: Callable[[GuardResult], None]) -> None:
        """Register a callback to be invoked when a soft gate triggers.

        The callback receives the ``GuardResult`` with details about which
        limit is approaching. Multiple callbacks can be registered.

        Example::

            def warn_user(result):
                print(f"Warning: {result.message}")

            pg.on_soft_gate(warn_user)
        """
        self._soft_gate_registry.register(callback)

    def on_hard_gate(self, callback: Callable[[GuardResult], None]) -> None:
        """Register a callback to be invoked when a hard gate triggers.

        The callback fires **before** ``PaygentLimitExceeded`` is raised.
        If ``raise_on_hard_gate=False``, the callback still fires but the
        LLM call proceeds. Multiple callbacks can be registered.

        Useful for logging, alerting, notifying end users, or triggering
        a plan-upgrade flow.

        Example::

            def on_limit_hit(result):
                log.error(f"Blocked: {result.message}")
                notify_user(result.gate_reason)

            pg.on_hard_gate(on_limit_hit)
        """
        self._hard_gate_registry.register(callback)

    def on_usage(self, callback: Callable[[UsageEvent], None]) -> None:
        """Register a callback to be invoked after every metering event.

        The callback receives the fully-costed ``UsageEvent`` with model,
        tokens, cost, and metadata. Fires for every successfully metered
        LLM call across all metering variants (auto-instrumentation, wrap,
        and framework callbacks).

        Useful for real-time dashboards, custom logging, or developer-defined
        threshold logic.

        Example::

            def log_usage(event):
                print(f"{event.model}: {event.total_tokens} tokens, ${event.cost_total:.4f}")

            pg.on_usage(log_usage)
        """
        self._usage_registry.register(callback)

    def on_session_start(self, callback: Callable[["UserState"], None]) -> None:
        """Register a callback to be invoked when a user session starts.

        The callback receives the ``UserState`` with plan configuration
        and current usage state. Fires when ``start_session()`` completes
        (including auto-created sessions).

        Example::

            def on_session(session):
                print(f"Session started for {session.user_id} on plan {session.plan}")

            pg.on_session_start(on_session)
        """
        self._session_start_registry.register(callback)

    # ------------------------------------------------------------------
    # Decorator
    # ------------------------------------------------------------------

    def track(
        self,
        user_id: str | None = None,
        session_id: str | None = None,
        plan: str | None = None,
        metadata: dict[str, Any] | None = None,
        *,
        user_id_param: str | None = None,
    ) -> Callable:
        """Decorator that wraps a function with Paygent user context.

        Convenience wrapper around paygent_track(). Also starts a session
        if one doesn't exist for the user.

        Usage:
            @pg.track(user_id="user_123")
            def handle_request(query):
                return openai.chat.completions.create(...)
        """
        return paygent_track(
            user_id=user_id,
            session_id=session_id,
            plan=plan,
            metadata=metadata,
            user_id_param=user_id_param,
        )

    # ------------------------------------------------------------------
    # Wrap (Explicit Metering)
    # ------------------------------------------------------------------

    def wrap(
        self,
        call: Callable[..., Any],
        *,
        user_id: str,
        model: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        provider: str | None = None,
        estimated_input_tokens: int | None = None,
        estimated_max_tokens: int | None = None,
    ) -> Any:
        """Execute an LLM call with Paygent metering and guardrails.

        This is the explicit wrapper alternative to auto-instrumentation.
        The developer passes a callable (typically a lambda wrapping an LLM
        call), and Paygent runs guard check → reserve → execute → extract
        tokens → finalize → return response.

        Usage:
            response = pg.wrap(
                lambda: openai.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "Hello"}],
                ),
                user_id="user_123",
                model="gpt-4o",
            )

        Args:
            call: A zero-argument callable that performs the LLM call.
            user_id: The end user to track usage for.
            model: The model being called. Used for guard checks and cost
                calculation. If None, extracted from the response.
            session_id: Optional session identifier.
            metadata: Optional key-value pairs attached to the usage event.
            provider: Provider name ("openai" or "anthropic") to select the
                right token extractor. If None, Paygent tries all registered
                providers and picks the first that returns tokens.
            estimated_input_tokens: Dev's estimate of prompt tokens.  Used
                for the reservation that protects concurrent calls.  If not
                provided, reservation assumes 0 input (under-reserves —
                less safe at cap boundaries under concurrency).
            estimated_max_tokens: Dev's output-token cap estimate (the
                ``max_tokens`` they intend to pass to the LLM).  Falls back
                to ``plan_config.pre_call_buffer_tokens`` if absent.

        Returns:
            The LLM response, unchanged.

        Raises:
            PaygentLimitExceeded: If a hard gate is hit and raise_on_hard_gate
                is True.
        """
        from paygent.guardrails import PaygentLimitExceeded, _estimate_call
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
            normalize_model_name,
            release_reservation,
        )

        # --- Ensure session exists ---
        session = self._session_lookup(user_id)

        # --- SDK enabled check ---
        if session is not None and not session.sdk_enabled:
            logger.debug("sdk_enabled=False for user %s, passing through in wrap()", user_id)
            return call()

        # --- Guard + reserve (under the per-user lock, atomic) ---
        reserved_cost = 0.0
        reserved_tokens = 0
        # Normalize the reservation key so apply + finalize use the same
        # dict entry even when the provider returns a versioned model
        # name in the response.  See finalize_reservation docstring.
        reservation_model = (
            normalize_model_name(model, session.plan_config)
            if session is not None
            else model
        )
        if session is not None:
            with session.lock:
                try:
                    guard_result = check_guard(
                        session,
                        model=model,
                        estimated_input_tokens=estimated_input_tokens,
                        max_tokens=estimated_max_tokens,
                    )

                    if guard_result.status == "hard_gate":
                        self._hard_gate_handler(guard_result)
                        if self._raise_on_hard_gate:
                            raise PaygentLimitExceeded(guard_result)
                        # If not raising, still execute the call (developer chose this)

                    if guard_result.status == "soft_gate":
                        self._soft_gate_handler(guard_result)

                    # Reserve estimated cost so concurrent calls see the hold.
                    # Skip if no model is known (can't reserve meaningfully).
                    if reservation_model is not None:
                        est_cost, est_tokens = _estimate_call(
                            model=reservation_model,
                            config=session.plan_config,
                            estimated_input_tokens=estimated_input_tokens,
                            max_tokens=estimated_max_tokens,
                        )
                        factor = session.plan_config.reservation_safety_factor
                        reserved_cost = est_cost * factor
                        reserved_tokens = int(est_tokens * factor)
                        apply_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except PaygentLimitExceeded:
                    raise
                except Exception:
                    logger.debug("Guard check/reserve failed in wrap(), proceeding (fail-open)", exc_info=True)

        # --- Execute the callable (LOCK NOT HELD) ---
        try:
            response = call()
        except Exception:
            # LLM call failed — release reservation so concurrent callers
            # don't see the ghost hold forever.
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                with session.lock:
                    release_reservation(
                        session, reservation_model,
                        reserved_cost, reserved_tokens,
                    )
            raise

        # --- Post-call: extract tokens, meter, finalize reservation ---
        metering_done = False
        try:
            token_info = self._extract_tokens_for_wrap(response, provider)

            # Use model from response if not provided
            if token_info.model and not model:
                model = token_info.model
            elif model and not token_info.model:
                token_info.model = model

            effective_session_id = (
                session.current_usage.session_id if session else None
            ) or session_id
            event = create_usage_event(
                user_id=user_id,
                token_info=token_info,
                plan_config=session.plan_config if session else PlanConfig(),
                session_id=effective_session_id,
                metadata=metadata,
            )

            if session is not None:
                with session.lock:
                    if reserved_cost > 0 or reserved_tokens > 0:
                        finalize_reservation(
                            session, event,
                            reserved_cost, reserved_tokens,
                            reservation_model=reservation_model,
                        )
                    else:
                        update_cache(session, event)
            metering_done = True

            self._event_sink(event)
            self._usage_handler(event)
        except Exception:
            logger.debug("Post-call processing failed in wrap(), skipping metering", exc_info=True)
            # If metering fell through before we could finalize, release the
            # reservation so it doesn't linger.
            if (
                not metering_done
                and session is not None
                and (reserved_cost > 0 or reserved_tokens > 0)
            ):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after metering failure also failed", exc_info=True)

        return response

    async def awrap(
        self,
        call: Any,
        *,
        user_id: str,
        model: str | None = None,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        provider: str | None = None,
        estimated_input_tokens: int | None = None,
        estimated_max_tokens: int | None = None,
    ) -> Any:
        """Async version of wrap(). Accepts a coroutine or awaitable.

        Usage:
            response = await pg.awrap(
                client.chat.completions.create(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "Hello"}],
                ),
                user_id="user_123",
                model="gpt-4o",
            )

        ``estimated_input_tokens`` / ``estimated_max_tokens`` mirror wrap() —
        used for the reservation hold that protects concurrent calls.
        """
        from paygent.guardrails import PaygentLimitExceeded, _estimate_call
        from paygent.metering import (
            apply_reservation,
            finalize_reservation,
            normalize_model_name,
            release_reservation,
        )

        session = self._session_lookup(user_id)

        # --- SDK enabled check ---
        if session is not None and not session.sdk_enabled:
            logger.debug("sdk_enabled=False for user %s, passing through in awrap()", user_id)
            return await call

        # --- Guard + reserve (under the per-user lock, atomic) ---
        # threading.Lock held briefly — no await inside the with block.
        reserved_cost = 0.0
        reserved_tokens = 0
        # Same normalization reason as wrap() — keeps apply/finalize in sync
        # on the same dict key even when provider returns versioned names.
        reservation_model = (
            normalize_model_name(model, session.plan_config)
            if session is not None
            else model
        )
        if session is not None:
            with session.lock:
                try:
                    guard_result = check_guard(
                        session,
                        model=model,
                        estimated_input_tokens=estimated_input_tokens,
                        max_tokens=estimated_max_tokens,
                    )

                    if guard_result.status == "hard_gate":
                        self._hard_gate_handler(guard_result)
                        if self._raise_on_hard_gate:
                            raise PaygentLimitExceeded(guard_result)

                    if guard_result.status == "soft_gate":
                        self._soft_gate_handler(guard_result)

                    if reservation_model is not None:
                        est_cost, est_tokens = _estimate_call(
                            model=reservation_model,
                            config=session.plan_config,
                            estimated_input_tokens=estimated_input_tokens,
                            max_tokens=estimated_max_tokens,
                        )
                        factor = session.plan_config.reservation_safety_factor
                        reserved_cost = est_cost * factor
                        reserved_tokens = int(est_tokens * factor)
                        apply_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except PaygentLimitExceeded:
                    raise
                except Exception:
                    logger.debug("Guard check/reserve failed in awrap(), proceeding (fail-open)", exc_info=True)

        # --- Await the LLM call (LOCK NOT HELD — concurrent callers can interleave) ---
        try:
            response = await call
        except Exception:
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                with session.lock:
                    release_reservation(
                        session, reservation_model,
                        reserved_cost, reserved_tokens,
                    )
            raise

        # --- Post-call: extract tokens, meter, finalize reservation ---
        metering_done = False
        try:
            token_info = self._extract_tokens_for_wrap(response, provider)

            if token_info.model and not model:
                model = token_info.model
            elif model and not token_info.model:
                token_info.model = model

            effective_session_id = (
                session.current_usage.session_id if session else None
            ) or session_id
            event = create_usage_event(
                user_id=user_id,
                token_info=token_info,
                plan_config=session.plan_config if session else PlanConfig(),
                session_id=effective_session_id,
                metadata=metadata,
            )

            if session is not None:
                with session.lock:
                    if reserved_cost > 0 or reserved_tokens > 0:
                        finalize_reservation(
                            session, event,
                            reserved_cost, reserved_tokens,
                            reservation_model=reservation_model,
                        )
                    else:
                        update_cache(session, event)
            metering_done = True

            self._event_sink(event)
            self._usage_handler(event)
        except Exception:
            logger.debug("Post-call processing failed in awrap(), skipping metering", exc_info=True)
            if (
                not metering_done
                and session is not None
                and (reserved_cost > 0 or reserved_tokens > 0)
            ):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after metering failure also failed", exc_info=True)

        return response

    def _extract_tokens_for_wrap(
        self, response: Any, provider_name: str | None = None
    ) -> "TokenInfo":
        """Extract tokens from an LLM response for the wrap() method.

        If provider is specified, uses that provider's extractor.
        Otherwise, tries all registered providers and returns the first
        result that has non-zero tokens.
        """
        from paygent.providers import TokenInfo

        if provider_name:
            prov = self._registry.get(provider_name)
            if prov:
                return prov.extract_tokens(response)
            logger.debug("Unknown provider '%s', trying all", provider_name)

        # Try all providers, return first with tokens
        best = TokenInfo()
        for prov in self._registry.all():
            try:
                info = prov.extract_tokens(response)
                if info.total_tokens > 0:
                    return info
                # Keep one with a model name at least
                if info.model and not best.model:
                    best = info
            except Exception:
                continue
        return best

    # ------------------------------------------------------------------
    # Instrumentation Control
    # ------------------------------------------------------------------

    def instrument(self) -> list[str]:
        """Manually instrument LLM providers.

        Only needed if auto_instrument=False was passed to init().
        Returns list of patch keys that were applied.
        """
        return self._instrumentor.instrument()

    def uninstrument(self) -> int:
        """Remove all monkey-patches and restore original LLM methods.

        Returns number of patches that were restored.
        """
        return self._instrumentor.uninstrument()

    @property
    def is_instrumented(self) -> bool:
        """Whether LLM providers are currently instrumented."""
        return self._instrumentor.is_instrumented

    # ------------------------------------------------------------------
    # Event Queue Control
    # ------------------------------------------------------------------

    def flush(self) -> int:
        """Manually flush all pending events. Returns count flushed.

        Useful for testing or before a graceful shutdown.
        """
        return self._event_queue.flush_now()

    @property
    def pending_events(self) -> int:
        """Number of events waiting to be flushed."""
        return self._event_queue.pending_count

    @property
    def queue_stats(self) -> dict:
        """Event queue statistics."""
        return self._event_queue.stats

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    def shutdown(self, timeout: float = 10.0) -> None:
        """Gracefully shut down Paygent.

        1. Removes all monkey-patches
        2. Flushes remaining events (to local storage + backend)
        3. Syncs any previously unsynced events to backend
        4. Closes API client and local storage

        Args:
            timeout: Max seconds to wait for event queue to drain.
        """
        logger.info("Shutting down Paygent...")

        # Remove patches first so no new events are generated
        try:
            restored = self._instrumentor.uninstrument()
            if restored:
                logger.debug("Restored %d patches", restored)
        except Exception:
            logger.debug("Error during uninstrument", exc_info=True)

        # Stop event queue (flushes remaining events via _flush_events → LocalCache)
        try:
            flushed = self._event_queue.stop(timeout=timeout)
            logger.debug("Flushed %d events during shutdown", flushed)
        except Exception:
            logger.debug("Error stopping event queue", exc_info=True)

        # Final sync of any previously unsynced events to backend
        try:
            synced = self._local_cache.sync_pending()
            if synced:
                logger.debug("Synced %d pending events to backend during shutdown", synced)
        except Exception:
            logger.debug("Error syncing pending events during shutdown", exc_info=True)

        # Close API client
        if self._api_client is not None:
            try:
                self._api_client.close()
                logger.debug("API client closed")
            except Exception:
                logger.debug("Error closing API client", exc_info=True)

        # Close storage
        try:
            self._storage.close_sync()
            logger.debug("Storage closed")
        except Exception:
            logger.debug("Error closing storage", exc_info=True)

        # Clear sessions
        self._sessions.clear()
        self._initialized = False

        # Clear singleton if this is the singleton
        if Paygent._instance is self:
            Paygent._instance = None

        logger.info("Paygent shut down")

    def _atexit_shutdown(self) -> None:
        """Called by atexit to ensure clean shutdown."""
        if self._initialized:
            try:
                self.shutdown(timeout=5.0)
            except Exception:
                pass  # Best effort at exit

    # ------------------------------------------------------------------
    # Internal Callbacks (wiring)
    # ------------------------------------------------------------------

    def _session_lookup(self, user_id: str) -> Optional[UserState]:
        """Session lookup callback for the patcher.

        Uses the 5-step fallback chain via _get_user_state() to ensure
        a UserState always exists. Never returns None (fail-open).
        """
        try:
            return self._get_user_state(user_id)
        except Exception:
            logger.debug("_session_lookup failed for %s, creating minimal state", user_id, exc_info=True)
            state = UserState(
                user_id=user_id,
                plan="default",
                plan_config=PlanConfig(),
                current_usage=CurrentUsage(),
            )
            self._sessions[user_id] = state
            return state

    def _event_sink(self, event: Any) -> None:
        """Event sink callback for the patcher.

        Pushes events to the background queue. Non-blocking, never raises.
        """
        try:
            self._event_queue.push(event)
        except Exception:
            logger.debug("Failed to push event to queue", exc_info=True)

    def _soft_gate_handler(self, result: GuardResult) -> None:
        """Soft gate handler callback for the patcher.

        Fires all registered soft gate callbacks. Never raises.
        """
        try:
            self._soft_gate_registry.fire(result)
        except Exception:
            logger.debug("Soft gate handler error", exc_info=True)

    def _hard_gate_handler(self, result: GuardResult) -> None:
        """Hard gate handler — fires before PaygentLimitExceeded is raised.

        Called from wrap(), awrap(), and the patcher wrappers. Never raises.
        """
        try:
            self._hard_gate_registry.fire(result)
        except Exception:
            logger.debug("Hard gate handler error", exc_info=True)

    def _usage_handler(self, event: UsageEvent) -> None:
        """Usage handler — fires after every successful metering event.

        Called from wrap(), awrap(), and the patcher _post_call_processing.
        Never raises.
        """
        try:
            self._usage_registry.fire(event)
        except Exception:
            logger.debug("Usage handler error", exc_info=True)

    def _session_start_handler(self, session: UserState) -> None:
        """Session start handler — fires when a session is created.

        Called from start_session() and auto-created sessions. Never raises.
        """
        try:
            self._session_start_registry.fire(session)
        except Exception:
            logger.debug("Session start handler error", exc_info=True)

    def _flush_events(self, events: List[UsageEvent]) -> None:
        """Flush callback for the event queue.

        Stores events to local SQLite and syncs to backend (if connected).
        Uses LocalCache which handles the store-then-sync flow and fallback.
        After flushing, saves snapshots for recently-updated users.
        """
        if not events:
            return

        try:
            result = self._local_cache.store_and_sync(events)
            logger.debug(
                "Flushed %d events (stored=%d, synced=%d, dupes=%d)",
                len(events),
                result.stored_locally,
                result.synced_to_backend,
                result.duplicates,
            )
        except Exception:
            logger.warning(
                "Failed to flush %d events, events may be lost",
                len(events),
                exc_info=True,
            )

        # Save snapshots for users with events in this batch
        user_ids = {e.user_id for e in events}
        for uid in user_ids:
            state = self._sessions.get(uid)
            if state is not None:
                try:
                    self._storage.save_snapshot_sync(state)
                except Exception:
                    logger.debug("Failed to save snapshot for %s", uid, exc_info=True)

    def _refresh_stale_states(self) -> None:
        """Refresh cached UserStates from the backend (Approach A).

        Called periodically by the background thread. Iterates all cached
        users and re-fetches their state if last_refreshed is older than
        refresh_interval. This keeps guardrails accurate when the backend
        state changes (e.g., usage from another server instance).

        Uses merge semantics: backend-authoritative data (plan_config,
        period usage, billing_period) overwrites local values, but
        SDK-local session window data (session_cost, session_id,
        session_started_at) is preserved since the backend knows nothing
        about clock-based session windows.
        """
        from datetime import datetime, timedelta

        if self._api_client is None:
            return

        threshold = datetime.utcnow() - timedelta(seconds=self._refresh_interval)

        for user_id, state in list(self._sessions.items()):
            try:
                if state.last_refreshed and state.last_refreshed > threshold:
                    continue  # Still fresh

                new_state = self._api_client.fetch_session(user_id)
                if new_state is not None:
                    _merge_user_state(state, new_state)
                    try:
                        self._storage.save_snapshot_sync(state)
                    except Exception:
                        logger.debug("Failed to save snapshot after refresh for %s", user_id, exc_info=True)
                    logger.debug("Refreshed state for %s from backend", user_id)
            except Exception:
                logger.debug("Failed to refresh state for %s", user_id, exc_info=True)

    def _sync_pending(self) -> int:
        """Sync pending callback for the event queue.

        Retries unsynced events from local SQLite storage to the backend,
        then cleans up old synced events (retention policy).
        Called periodically by the background thread (every sync_pending_interval).
        """
        synced = 0
        try:
            synced = self._local_cache.sync_pending()
        except Exception:
            logger.debug("sync_pending failed", exc_info=True)

        # Cleanup old synced events (retention: 7 days)
        try:
            self._local_cache.cleanup_synced(retention_days=7)
        except Exception:
            logger.debug("cleanup_synced failed", exc_info=True)

        return synced

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def api_key(self) -> str | None:
        """The configured API key (None in local-only mode)."""
        return self._api_key

    @property
    def base_url(self) -> str:
        """The backend URL the SDK connects to."""
        return self._base_url

    @property
    def is_local_mode(self) -> bool:
        """Whether running in local-only mode (no backend)."""
        return self._api_key is None

    @property
    def is_connected(self) -> bool:
        """Whether the SDK has a backend configured and it was last reachable."""
        if self._api_client is None:
            return False
        return self._local_cache.backend_reachable is True

    @property
    def backend_reachable(self) -> bool:
        """Result of the backend health check run during ``Paygent.init()``.

        Returns False in local-only mode (no ``api_key``).  Returns False
        when the init-time probe failed (backend unreachable or API key
        rejected) — even if the SDK continued in offline mode thanks to
        the default non-strict behavior.

        Use this to guard code that assumes server-side state, e.g.::

            pg = Paygent.init(api_key=...)
            if not pg.backend_reachable:
                raise StartupError("Paygent backend offline, refusing to start")

        For the *current* (post-init) reachability state, see ``is_connected``.
        """
        return self._backend_reachable_at_init

    @property
    def is_initialized(self) -> bool:
        """Whether Paygent has been initialized."""
        return self._initialized

    @property
    def storage(self) -> SQLiteStorage:
        """The local SQLite storage instance."""
        return self._storage

    @property
    def local_cache(self) -> LocalCache:
        """The local cache + sync orchestrator."""
        return self._local_cache

    @property
    def session_count(self) -> int:
        """Number of active user sessions."""
        return len(self._sessions)

    def sync_pending(self) -> int:
        """Manually sync unsynced events from local storage to backend.

        Returns the number of events synced. Returns 0 in local-only mode.
        """
        try:
            return self._local_cache.sync_pending()
        except Exception:
            logger.debug("Manual sync_pending failed", exc_info=True)
            return 0
