"""HTTP client for the Paygent backend API.

Handles all communication between the SDK and the Paygent backend:
- Session bootstrap (fetching user plan config + current usage)
- Batch event ingestion (posting usage events)
- Health checks (connectivity verification)

Design:
- Uses httpx for both sync and async HTTP
- All methods fail gracefully — network errors never crash the SDK
- Configurable base URL, timeout, and retry behavior
- API key sent via Authorization: Bearer header
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import httpx

from paygent.models import (
    BillingPeriod,
    CurrentUsage,
    ModelCostRate,
    ModelLimitConfig,
    PlanConfig,
    UsageEvent,
    UserState,
)

logger = logging.getLogger("paygent")

DEFAULT_BASE_URL = "https://api.paygent.dev"
DEFAULT_TIMEOUT = 10.0
DEFAULT_RETRY_COUNT = 2


class ApiClient:
    """HTTP client for communicating with the Paygent backend.

    Usage:
        client = ApiClient(api_key="pg_live_...", base_url="https://api.paygent.dev")
        session = client.fetch_session("user_123")
        result = client.post_events([event1, event2])
        client.close()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_RETRY_COUNT,
    ) -> None:
        """
        Args:
            api_key: Paygent API key (e.g. "pg_live_...").
            base_url: Backend API base URL.
            timeout: HTTP request timeout in seconds.
            max_retries: Number of retries on transient failures.
        """
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: Optional[httpx.Client] = None

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def is_open(self) -> bool:
        """Whether the HTTP client is open."""
        return self._client is not None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def open(self) -> None:
        """Create the HTTP client. Safe to call multiple times."""
        if self._client is not None:
            return

        transport = httpx.HTTPTransport(retries=self._max_retries)
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "User-Agent": "paygent-sdk/0.1.0",
            },
            timeout=self._timeout,
            transport=transport,
        )
        logger.debug("API client opened (base_url=%s)", self._base_url)

    def close(self) -> None:
        """Close the HTTP client. Safe to call multiple times."""
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                logger.debug("Error closing HTTP client", exc_info=True)
            self._client = None
            logger.debug("API client closed")

    def _ensure_client(self) -> httpx.Client:
        """Ensure the client is open, creating it lazily if needed."""
        if self._client is None:
            self.open()
        return self._client  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # Health Check
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """Check if the backend is reachable.

        Returns True if healthy, False on any error.
        """
        try:
            client = self._ensure_client()
            response = client.get("/api/v1/health")
            if response.status_code == 200:
                data = response.json()
                return data.get("status") == "ok"
            return False
        except Exception:
            logger.debug("Health check failed", exc_info=True)
            return False

    def diagnose_backend(self, timeout: float = 3.0) -> tuple[str, str]:
        """One-shot backend check for init-time feedback.

        Pings an authed endpoint so a single request tells us whether the
        backend is (a) reachable at all, (b) accepting our API key.

        Args:
            timeout: Per-request HTTP timeout in seconds.  Kept short so
                init() stays fast even against a stalled backend.

        Returns:
            ``(status, detail)`` where ``status`` is one of:

            - ``"ok"`` — backend reachable, API key accepted
            - ``"unreachable"`` — connect error, DNS failure, or timeout
            - ``"auth_invalid"`` — backend returned 401 or 403
            - ``"other"`` — unexpected status code or other error

            ``detail`` is a short human-readable string for warning messages.
        """
        try:
            client = self._ensure_client()
            # Hit an authed endpoint so we can distinguish "backend down"
            # (ConnectError) from "API key bad" (401/403).  /config/plans
            # is cheap — returns the caller's configured plans.
            response = client.get("/api/v1/config/plans", timeout=timeout)
            if response.status_code == 200:
                return ("ok", "")
            if response.status_code in (401, 403):
                return ("auth_invalid", f"HTTP {response.status_code}")
            return ("other", f"HTTP {response.status_code}")
        except httpx.ConnectError as e:
            return ("unreachable", f"connect error: {e}")
        except httpx.TimeoutException as e:
            return ("unreachable", f"timeout after {timeout}s: {type(e).__name__}")
        except Exception as e:
            return ("other", f"{type(e).__name__}: {e}")

    # ------------------------------------------------------------------
    # Session Bootstrap
    # ------------------------------------------------------------------

    def fetch_session(self, user_id: str) -> Optional[UserState]:
        """Fetch user session data from the backend.

        Calls GET /api/v1/users/{user_id}/session to get:
        - Plan configuration (limits, cost rates, model limits)
        - Current usage (monthly spend, tokens by model)

        Returns None on any error (fail-open).
        """
        try:
            client = self._ensure_client()
            response = client.get(f"/api/v1/users/{user_id}/session")

            if response.status_code == 200:
                return _parse_session_response(response.json())

            if response.status_code == 404:
                logger.debug("User %s not found in backend", user_id)
                return None

            logger.warning(
                "Unexpected status %d fetching session for %s",
                response.status_code,
                user_id,
            )
            return None

        except httpx.TimeoutException:
            logger.warning("Timeout fetching session for %s", user_id)
            return None
        except httpx.ConnectError:
            logger.warning("Cannot connect to backend for session fetch")
            return None
        except Exception:
            logger.debug("Failed to fetch session for %s", user_id, exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Event Ingestion
    # ------------------------------------------------------------------

    def post_events(self, events: List[UsageEvent]) -> Optional[BatchResult]:
        """Post a batch of usage events to the backend.

        Calls POST /api/v1/events/batch with a list of events.
        Backend is idempotent — duplicate event IDs are ignored.

        Returns BatchResult on success, None on failure.
        """
        if not events:
            return BatchResult(accepted=0, duplicates=0)

        try:
            client = self._ensure_client()
            payload = [_serialize_event(e) for e in events]
            response = client.post("/api/v1/events/batch", json=payload)

            if response.status_code == 200:
                data = response.json()
                return BatchResult(
                    accepted=data.get("accepted", 0),
                    duplicates=data.get("duplicates", 0),
                )

            logger.warning(
                "Unexpected status %d posting %d events",
                response.status_code,
                len(events),
            )
            return None

        except httpx.TimeoutException:
            logger.warning("Timeout posting %d events", len(events))
            return None
        except httpx.ConnectError:
            logger.warning("Cannot connect to backend for event post")
            return None
        except Exception:
            logger.debug("Failed to post %d events", len(events), exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Usage Query
    # ------------------------------------------------------------------

    def fetch_usage(
        self,
        user_id: str,
        period: str = "current_month",
        breakdown: str = "model",
    ) -> Optional[Dict[str, Any]]:
        """Fetch detailed usage data for a user.

        Calls GET /api/v1/users/{user_id}/usage with query params.
        Returns the raw response dict on success, None on failure.
        """
        try:
            client = self._ensure_client()
            response = client.get(
                f"/api/v1/users/{user_id}/usage",
                params={"period": period, "breakdown": breakdown},
            )

            if response.status_code == 200:
                return response.json()

            return None

        except Exception:
            logger.debug("Failed to fetch usage for %s", user_id, exc_info=True)
            return None

    # ------------------------------------------------------------------
    # Context Manager
    # ------------------------------------------------------------------

    def __enter__(self) -> "ApiClient":
        self.open()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Batch Result
# ---------------------------------------------------------------------------


class BatchResult:
    """Result from a batch event ingestion."""

    __slots__ = ("accepted", "duplicates")

    def __init__(self, accepted: int = 0, duplicates: int = 0) -> None:
        self.accepted = accepted
        self.duplicates = duplicates

    @property
    def total(self) -> int:
        return self.accepted + self.duplicates

    def __repr__(self) -> str:
        return f"BatchResult(accepted={self.accepted}, duplicates={self.duplicates})"


# ---------------------------------------------------------------------------
# Serialization / Parsing Helpers
# ---------------------------------------------------------------------------


def _serialize_event(event: UsageEvent) -> dict:
    """Serialize a UsageEvent to a JSON-compatible dict for the API."""
    return {
        "id": event.id,
        "user_id": event.user_id,
        "session_id": event.session_id,
        "timestamp": event.timestamp.isoformat(),
        "model": event.model,
        "input_tokens": event.input_tokens,
        "output_tokens": event.output_tokens,
        "total_tokens": event.total_tokens,
        "tool_calls": event.tool_calls,
        "cost_tokens": event.cost_tokens,
        "cost_tools": event.cost_tools,
        "cost_total": event.cost_total,
        "metadata": event.metadata,
    }


def _parse_session_response(data: dict) -> Optional[UserState]:
    """Parse the backend's session response into a UserState.

    Accepts both new (period_*) and old (month_*) field names from the
    backend for backward compatibility. New field names take precedence.

    Expected format:
    {
        "user_id": "user_123",
        "plan": "pro",
        "plan_config": {
            "max_spend_per_period": 49.00,  // or "max_spend_per_month"
            "max_spend_per_session": 5.00,
            "soft_gate_at": 0.80,
            "hard_gate_at": 1.00,
            "model_limits": {"gpt-4o": {"max_tokens_per_period": 50000}},
            "cost_rates": {"gpt-4o": {"input": 0.0025, "output": 0.01}},
            ...
        },
        "current_usage": {
            "period_cost": 23.47,  // or "month_cost"
            "period_tokens_by_model": {"gpt-4o": 31200},  // or "month_tokens_by_model"
            ...
        },
        "billing_period": {  // optional
            "start": "2026-03-15T00:00:00",
            "end": "2026-04-15T00:00:00"
        }
    }
    """
    try:
        # Parse plan config
        plan_data = data.get("plan_config", {})

        model_limits = {}
        for model_name, limit_data in plan_data.get("model_limits", {}).items():
            model_limits[model_name] = ModelLimitConfig(**limit_data)

        cost_rates = {}
        for model_name, rate_data in plan_data.get("cost_rates", {}).items():
            cost_rates[model_name] = ModelCostRate(**rate_data)

        default_cost_rate_data = plan_data.get("default_cost_rate")
        default_cost_rate = (
            ModelCostRate(**default_cost_rate_data)
            if isinstance(default_cost_rate_data, dict)
            else None
        )

        # Accept both new and old field names (new takes precedence)
        max_spend = plan_data.get(
            "max_spend_per_period",
            plan_data.get("max_spend_per_month", float("inf")),
        )

        plan_config = PlanConfig(
            max_spend_per_period=max_spend,
            max_spend_per_session=plan_data.get("max_spend_per_session", float("inf")),
            soft_gate_at=plan_data.get("soft_gate_at", 0.80),
            hard_gate_at=plan_data.get("hard_gate_at", 1.00),
            model_limits=model_limits,
            cost_rates=cost_rates,
            default_cost_rate=default_cost_rate,
            tool_costs=plan_data.get("tool_costs", {}),
            default_tool_cost=plan_data.get("default_tool_cost", 0.02),
            session_timeout_minutes=plan_data.get("session_timeout_minutes", 30.0),
            pre_call_estimate=plan_data.get("pre_call_estimate", False),
            pre_call_buffer_tokens=plan_data.get("pre_call_buffer_tokens", 500),
        )

        # Parse current usage — accept both new and old field names.
        #
        # session_id / session_started_at / session_cost are SDK-LOCAL state,
        # not backend-owned.  The caller (`_get_user_state` in core.py) is
        # responsible for deciding whether to:
        #   - carry them over from a SQLite snapshot (session continuity
        #     across process restarts within the timeout window), or
        #   - stamp fresh values via `_ensure_session_window` (first ever
        #     boot on this machine, or snapshot is stale / unreadable).
        #
        # We leave them as None here so that decision happens in exactly
        # one place.  Generating fresh IDs here broke session continuity —
        # every cold start produced a new session_id even when the snapshot
        # on disk still held a live one.
        usage_data = data.get("current_usage", {})
        current_usage = CurrentUsage(
            period_cost=usage_data.get("period_cost", usage_data.get("month_cost", 0.0)),
            session_cost=0.0,
            session_id=None,
            session_started_at=None,
            period_tokens_total=usage_data.get(
                "period_tokens_total", usage_data.get("month_tokens_total", 0)
            ),
            period_tokens_by_model=usage_data.get(
                "period_tokens_by_model", usage_data.get("month_tokens_by_model", {})
            ),
            period_cost_by_model=usage_data.get(
                "period_cost_by_model", usage_data.get("month_cost_by_model", {})
            ),
        )

        # Parse billing period (optional)
        billing_period = None
        bp_data = data.get("billing_period")
        if isinstance(bp_data, dict) and "start" in bp_data and "end" in bp_data:
            billing_period = BillingPeriod(
                start=datetime.fromisoformat(bp_data["start"]),
                end=datetime.fromisoformat(bp_data["end"]),
            )

        return UserState(
            user_id=data["user_id"],
            plan=data.get("plan", "default"),
            plan_config=plan_config,
            current_usage=current_usage,
            billing_period=billing_period,
            last_refreshed=datetime.utcnow() if billing_period else None,
        )

    except Exception:
        logger.warning("Failed to parse session response", exc_info=True)
        return None
