"""Instrumentor — orchestrates monkey-patching across all LLM providers.

The instrumentor is the single entry point for the patching system. It:
1. Takes a ProviderRegistry (which providers to patch)
2. Takes callbacks (session lookup, event sink, soft gate handler)
3. Applies patches for all installed providers
4. Provides a clean way to remove all patches

The Paygent core.py uses the instrumentor at init time:
    instrumentor = Instrumentor(registry, session_lookup, event_sink)
    instrumentor.instrument()  # patches all installed providers
    ...
    instrumentor.uninstrument()  # restores originals on shutdown
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional

from paygent.models import GuardResult, UserState
from paygent.patcher import (
    EventSink,
    HardGateHandler,
    PatchState,
    SessionLookup,
    SoftGateHandler,
    UsageHandler,
    apply_patch,
)
from paygent.providers import ProviderRegistry, create_default_registry

logger = logging.getLogger("paygent")


class Instrumentor:
    """Orchestrates monkey-patching across all registered LLM providers.

    Usage:
        registry = create_default_registry()
        instrumentor = Instrumentor(
            registry=registry,
            session_lookup=lambda uid: sessions.get(uid),
            event_sink=lambda event: queue.put(event),
        )
        instrumentor.instrument()    # patch all installed providers
        # ... app runs ...
        instrumentor.uninstrument()  # restore originals
    """

    def __init__(
        self,
        registry: ProviderRegistry,
        session_lookup: SessionLookup,
        event_sink: EventSink,
        soft_gate_handler: Optional[SoftGateHandler] = None,
        hard_gate_handler: Optional[HardGateHandler] = None,
        usage_handler: Optional[UsageHandler] = None,
        raise_on_hard_gate: bool = True,
    ) -> None:
        self._registry = registry
        self._session_lookup = session_lookup
        self._event_sink = event_sink
        self._soft_gate_handler = soft_gate_handler
        self._hard_gate_handler = hard_gate_handler
        self._usage_handler = usage_handler
        self._raise_on_hard_gate = raise_on_hard_gate
        self._patch_state = PatchState()
        self._instrumented = False

    @property
    def is_instrumented(self) -> bool:
        """Whether patches are currently active."""
        return self._instrumented

    @property
    def patched_count(self) -> int:
        """Number of methods currently patched."""
        return self._patch_state.patched_count

    def instrument(self) -> list[str]:
        """Apply monkey-patches for all registered providers.

        Only patches providers whose SDK is actually installed.
        Safe to call multiple times — already-patched methods are skipped.

        Returns:
            List of patch keys that were successfully applied.
        """
        all_applied = []

        for provider in self._registry.all():
            try:
                applied = apply_patch(
                    provider=provider,
                    patch_state=self._patch_state,
                    session_lookup=self._session_lookup,
                    event_sink=self._event_sink,
                    soft_gate_handler=self._soft_gate_handler,
                    hard_gate_handler=self._hard_gate_handler,
                    usage_handler=self._usage_handler,
                    raise_on_hard_gate=self._raise_on_hard_gate,
                )
                all_applied.extend(applied)
                if applied:
                    logger.info("Instrumented %s: %s", provider.name, applied)
                else:
                    logger.debug(
                        "Skipped %s (not installed or already patched)", provider.name
                    )
            except Exception:
                logger.warning(
                    "Failed to instrument %s, skipping", provider.name, exc_info=True
                )

        self._instrumented = len(all_applied) > 0 or self._instrumented

        if not all_applied:
            logger.info(
                "No providers instrumented. Install openai or anthropic to enable auto-tracking."
            )

        return all_applied

    def uninstrument(self) -> int:
        """Remove all monkey-patches and restore original methods.

        Returns:
            Number of patches that were restored.
        """
        count = self._patch_state.restore_all()
        self._instrumented = False
        if count > 0:
            logger.info("Removed %d patches", count)
        return count

    def update_session_lookup(self, session_lookup: SessionLookup) -> None:
        """Update the session lookup callback.

        Useful when the session cache changes (e.g., after bootstrap).
        Note: this only affects future patches. Existing wrappers hold
        a reference to the original callback. For dynamic lookup, pass
        a callback that itself delegates to the current cache.
        """
        self._session_lookup = session_lookup

    def update_soft_gate_handler(self, handler: Optional[SoftGateHandler]) -> None:
        """Update the soft gate callback."""
        self._soft_gate_handler = handler
