"""Monkey-patching engine for the Paygent SDK.

Replaces LLM client methods (e.g. `openai.chat.completions.create`) with
wrapped versions that automatically meter usage and enforce guardrails.

The patcher:
1. Resolves the target module and class from a ProviderConfig
2. Saves the original method
3. Replaces it with a wrapper that:
   a. Reads user context from contextvars
   b. Runs guard check (in-memory, sub-ms)
   c. Calls the original method
   d. Extracts tokens from response
   e. Meters usage and updates cache
   f. Pushes event to background queue
   g. Returns the original response unchanged

If ANY Paygent logic fails, the wrapper returns the original response
(or calls the original method) without modification. Fail-open is
non-negotiable.
"""

from __future__ import annotations

import asyncio
import importlib
import inspect
import logging
from typing import Any, Callable, Optional

from paygent.context import get_current_context
from paygent.guardrails import (
    PaygentLimitExceeded,
    _estimate_call,
    check_guard,
    estimate_input_tokens,
)
from paygent.metering import (
    apply_reservation,
    create_usage_event,
    finalize_reservation,
    normalize_model_name,
    release_reservation,
    update_cache,
)
from paygent.models import GuardResult, UserState
from paygent.providers import ProviderConfig, TokenInfo
from paygent.stream_wrapper import (
    AsyncStreamWrapper,
    StreamWrapper,
    extract_anthropic_stream_tokens,
    extract_openai_stream_tokens,
)

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Types for callbacks the patcher needs from the orchestrator
# ---------------------------------------------------------------------------

# Callable that looks up a UserState from the cache
SessionLookup = Callable[[str], Optional["UserState"]]

# Callable that receives a UsageEvent for background processing
EventSink = Callable[[Any], None]

# Callable invoked on soft gate
SoftGateHandler = Callable[["GuardResult"], None]

# Callable invoked on hard gate (before exception is raised)
HardGateHandler = Callable[["GuardResult"], None]

# Callable invoked after every successful metering event
UsageHandler = Callable[[Any], None]


# ---------------------------------------------------------------------------
# Patch State Tracking
# ---------------------------------------------------------------------------


class PatchState:
    """Tracks original methods so patches can be cleanly reversed."""

    def __init__(self) -> None:
        self._originals: dict[str, tuple[Any, str, Any]] = {}
        # key: "{module}.{class}.{method}"
        # value: (class_obj, method_name, original_method)

    def save(self, key: str, cls: Any, method_name: str, original: Any) -> None:
        """Save the original method before patching."""
        self._originals[key] = (cls, method_name, original)

    def restore_all(self) -> int:
        """Restore all saved originals. Returns count of restored patches."""
        count = 0
        for key, (cls, method_name, original) in self._originals.items():
            try:
                setattr(cls, method_name, original)
                count += 1
                logger.debug("Restored original: %s", key)
            except Exception:
                logger.debug("Failed to restore: %s", key, exc_info=True)
        self._originals.clear()
        return count

    @property
    def patched_count(self) -> int:
        return len(self._originals)

    def is_patched(self, key: str) -> bool:
        return key in self._originals


# ---------------------------------------------------------------------------
# Wrapper Factory (Sync)
# ---------------------------------------------------------------------------


def create_sync_wrapper(
    original: Callable,
    provider: ProviderConfig,
    session_lookup: SessionLookup,
    event_sink: EventSink,
    soft_gate_handler: SoftGateHandler | None = None,
    hard_gate_handler: HardGateHandler | None = None,
    usage_handler: UsageHandler | None = None,
    raise_on_hard_gate: bool = True,
) -> Callable:
    """Create a sync wrapper around an LLM method.

    The wrapper intercepts every call and adds Paygent's metering +
    guardrails without changing the method's signature or return type.
    """

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        # --- Step 1: Read user context ---
        try:
            ctx = get_current_context()
        except Exception:
            logger.debug("Failed to read context, passing through", exc_info=True)
            return original(*args, **kwargs)

        if ctx is None:
            # No Paygent context — pass through silently
            return original(*args, **kwargs)

        # --- Step 2: Look up session ---
        try:
            session = session_lookup(ctx.user_id)
        except Exception:
            logger.debug("Session lookup failed, passing through", exc_info=True)
            session = None

        # --- Step 2b: SDK enabled check ---
        if session is not None and not session.sdk_enabled:
            logger.debug("sdk_enabled=False for user %s, passing through", ctx.user_id)
            return original(*args, **kwargs)

        # --- Step 3: Guard + reserve (under per-user lock) ---
        model_hint = kwargs.get("model") or _extract_model_from_args(args)
        max_tok = kwargs.get("max_tokens") or kwargs.get("max_completion_tokens")
        messages = kwargs.get("messages")
        est_input = estimate_input_tokens(messages) if messages else None

        reserved_cost = 0.0
        reserved_tokens = 0
        # Normalize the model key ONCE, here — and use this same key for
        # apply / release / finalize.  Without this, apply could use
        # "gpt-4o-mini" while finalize used "gpt-4o-mini-2024-07-18"
        # (from the provider's versioned response), causing the
        # reservation to leak forever in reserved_tokens_by_model.
        reservation_model = (
            normalize_model_name(model_hint, session.plan_config)
            if session is not None
            else model_hint
        )
        if session is not None:
            with session.lock:
                try:
                    guard_result = check_guard(
                        session,
                        model=model_hint,
                        estimated_input_tokens=est_input,
                        max_tokens=max_tok,
                    )

                    if guard_result.status == "hard_gate":
                        if hard_gate_handler:
                            try:
                                hard_gate_handler(guard_result)
                            except Exception:
                                logger.debug("Hard gate handler failed", exc_info=True)
                        if raise_on_hard_gate:
                            raise PaygentLimitExceeded(guard_result)
                        else:
                            return original(*args, **kwargs)

                    if guard_result.status == "soft_gate" and soft_gate_handler:
                        try:
                            soft_gate_handler(guard_result)
                        except Exception:
                            logger.debug("Soft gate handler failed", exc_info=True)

                    # Reserve estimated cost + tokens so concurrent calls
                    # for this user see the pending hold.
                    if reservation_model is not None:
                        est_cost, est_tokens = _estimate_call(
                            model=reservation_model,
                            config=session.plan_config,
                            estimated_input_tokens=est_input,
                            max_tokens=max_tok,
                        )
                        factor = session.plan_config.reservation_safety_factor
                        reserved_cost = est_cost * factor
                        reserved_tokens = int(est_tokens * factor)
                        apply_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except PaygentLimitExceeded:
                    raise  # This is intentional — the only exception we propagate
                except Exception:
                    logger.debug("Guard check/reserve failed, proceeding (fail-open)", exc_info=True)

        # --- Step 4: Call original method (LOCK NOT HELD) ---
        try:
            response = original(*args, **kwargs)
        except Exception:
            # LLM call failed — release reservation so it doesn't leak.
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after LLM failure also failed", exc_info=True)
            raise

        # --- Step 5a: Streaming — defer metering until stream finishes ---
        try:
            if _is_stream_response(response):
                return _wrap_stream_for_metering(
                    response=response,
                    is_async=False,
                    provider=provider,
                    session=session,
                    ctx_user_id=ctx.user_id,
                    ctx_session_id=ctx.session_id,
                    ctx_metadata=ctx.metadata,
                    event_sink=event_sink,
                    usage_handler=usage_handler,
                    reserved_cost=reserved_cost,
                    reserved_tokens=reserved_tokens,
                    reservation_model=reservation_model,
                )
        except Exception:
            logger.debug("Stream detection/wrapping failed, returning raw response", exc_info=True)
            # Release reservation — stream wrapper would have done it.
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after stream wrap failure also failed", exc_info=True)
            return response

        # --- Step 5b: Non-stream — meter inline, finalize reservation ---
        _post_call_processing(
            response=response,
            provider=provider,
            session=session,
            ctx_user_id=ctx.user_id,
            ctx_session_id=ctx.session_id,
            ctx_metadata=ctx.metadata,
            event_sink=event_sink,
            usage_handler=usage_handler,
            reserved_cost=reserved_cost,
            reserved_tokens=reserved_tokens,
            reservation_model=reservation_model,
        )

        # --- Step 6: Return response unchanged ---
        return response

    # Preserve original method's signature for introspection
    wrapper.__name__ = getattr(original, "__name__", "create")
    wrapper.__qualname__ = getattr(original, "__qualname__", "create")
    wrapper.__wrapped__ = original  # type: ignore[attr-defined]
    wrapper._paygent_patched = True  # type: ignore[attr-defined]

    return wrapper


# ---------------------------------------------------------------------------
# Wrapper Factory (Async)
# ---------------------------------------------------------------------------


def create_async_wrapper(
    original: Callable,
    provider: ProviderConfig,
    session_lookup: SessionLookup,
    event_sink: EventSink,
    soft_gate_handler: SoftGateHandler | None = None,
    hard_gate_handler: HardGateHandler | None = None,
    usage_handler: UsageHandler | None = None,
    raise_on_hard_gate: bool = True,
) -> Callable:
    """Create an async wrapper around an async LLM method."""

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        # --- Step 1: Read user context ---
        try:
            ctx = get_current_context()
        except Exception:
            logger.debug("Failed to read context, passing through", exc_info=True)
            return await original(*args, **kwargs)

        if ctx is None:
            return await original(*args, **kwargs)

        # --- Step 2: Look up session ---
        try:
            session = session_lookup(ctx.user_id)
        except Exception:
            logger.debug("Session lookup failed, passing through", exc_info=True)
            session = None

        # --- Step 2b: SDK enabled check ---
        if session is not None and not session.sdk_enabled:
            logger.debug("sdk_enabled=False for user %s, passing through", ctx.user_id)
            return await original(*args, **kwargs)

        # --- Step 3: Guard + reserve (under per-user lock — held briefly) ---
        model_hint = kwargs.get("model") or _extract_model_from_args(args)
        max_tok = kwargs.get("max_tokens") or kwargs.get("max_completion_tokens")
        messages = kwargs.get("messages")
        est_input = estimate_input_tokens(messages) if messages else None

        reserved_cost = 0.0
        reserved_tokens = 0
        # See note above (sync patcher) on why we normalize here.
        reservation_model = (
            normalize_model_name(model_hint, session.plan_config)
            if session is not None
            else model_hint
        )
        if session is not None:
            with session.lock:
                try:
                    guard_result = check_guard(
                        session,
                        model=model_hint,
                        estimated_input_tokens=est_input,
                        max_tokens=max_tok,
                    )

                    if guard_result.status == "hard_gate":
                        if hard_gate_handler:
                            try:
                                hard_gate_handler(guard_result)
                            except Exception:
                                logger.debug("Hard gate handler failed", exc_info=True)
                        if raise_on_hard_gate:
                            raise PaygentLimitExceeded(guard_result)
                        else:
                            return await original(*args, **kwargs)

                    if guard_result.status == "soft_gate" and soft_gate_handler:
                        try:
                            soft_gate_handler(guard_result)
                        except Exception:
                            logger.debug("Soft gate handler failed", exc_info=True)

                    if reservation_model is not None:
                        est_cost, est_tokens = _estimate_call(
                            model=reservation_model,
                            config=session.plan_config,
                            estimated_input_tokens=est_input,
                            max_tokens=max_tok,
                        )
                        factor = session.plan_config.reservation_safety_factor
                        reserved_cost = est_cost * factor
                        reserved_tokens = int(est_tokens * factor)
                        apply_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except PaygentLimitExceeded:
                    raise
                except Exception:
                    logger.debug("Guard check/reserve failed, proceeding (fail-open)", exc_info=True)

        # --- Step 4: Call original async method (LOCK NOT HELD) ---
        try:
            response = await original(*args, **kwargs)
        except Exception:
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after async LLM failure also failed", exc_info=True)
            raise

        # --- Step 5a: Streaming (async) — defer metering until stream finishes ---
        try:
            if _is_async_stream_response(response):
                return _wrap_stream_for_metering(
                    response=response,
                    is_async=True,
                    provider=provider,
                    session=session,
                    ctx_user_id=ctx.user_id,
                    ctx_session_id=ctx.session_id,
                    ctx_metadata=ctx.metadata,
                    event_sink=event_sink,
                    usage_handler=usage_handler,
                    reserved_cost=reserved_cost,
                    reserved_tokens=reserved_tokens,
                    reservation_model=reservation_model,
                )
            # Also handle sync streams returned from an async method
            # (rare but possible with some SDK versions)
            if _is_stream_response(response):
                return _wrap_stream_for_metering(
                    response=response,
                    is_async=False,
                    provider=provider,
                    session=session,
                    ctx_user_id=ctx.user_id,
                    ctx_session_id=ctx.session_id,
                    ctx_metadata=ctx.metadata,
                    event_sink=event_sink,
                    usage_handler=usage_handler,
                    reserved_cost=reserved_cost,
                    reserved_tokens=reserved_tokens,
                    reservation_model=reservation_model,
                )
        except Exception:
            logger.debug("Async stream detection/wrapping failed, returning raw response", exc_info=True)
            if session is not None and (reserved_cost > 0 or reserved_tokens > 0):
                try:
                    with session.lock:
                        release_reservation(
                            session, reservation_model,
                            reserved_cost, reserved_tokens,
                        )
                except Exception:
                    logger.debug("Reservation release after async stream wrap failure also failed", exc_info=True)
            return response

        # --- Step 5b: Non-stream — meter inline, finalize reservation ---
        _post_call_processing(
            response=response,
            provider=provider,
            session=session,
            ctx_user_id=ctx.user_id,
            ctx_session_id=ctx.session_id,
            ctx_metadata=ctx.metadata,
            event_sink=event_sink,
            usage_handler=usage_handler,
            reserved_cost=reserved_cost,
            reserved_tokens=reserved_tokens,
            reservation_model=reservation_model,
        )

        # --- Step 6: Return response unchanged ---
        return response

    wrapper.__name__ = getattr(original, "__name__", "create")
    wrapper.__qualname__ = getattr(original, "__qualname__", "create")
    wrapper.__wrapped__ = original  # type: ignore[attr-defined]
    wrapper._paygent_patched = True  # type: ignore[attr-defined]

    return wrapper


# ---------------------------------------------------------------------------
# Post-Call Processing (shared by sync and async)
# ---------------------------------------------------------------------------


def _post_call_processing(
    response: Any,
    provider: ProviderConfig,
    session: UserState | None,
    ctx_user_id: str,
    ctx_session_id: str | None,
    ctx_metadata: dict | None,
    event_sink: EventSink,
    usage_handler: UsageHandler | None = None,
    reserved_cost: float = 0.0,
    reserved_tokens: int = 0,
    reservation_model: str | None = None,
) -> None:
    """Extract tokens from a non-stream response, then meter.

    If a reservation was placed before the call, it is finalized here
    (subtracted and replaced with the actual event).  On any failure the
    reservation is released so it doesn't leak.

    Entirely fail-open — any error is logged and swallowed.
    """
    has_reservation = reserved_cost > 0 or reserved_tokens > 0

    try:
        token_info = provider.extract_tokens(response)
    except Exception:
        logger.debug("Token extraction failed, skipping metering", exc_info=True)
        # Release any reservation so it doesn't linger past the call.
        if has_reservation and session is not None:
            try:
                with session.lock:
                    release_reservation(
                        session, reservation_model,
                        reserved_cost, reserved_tokens,
                    )
            except Exception:
                logger.debug("Reservation release after extract failure also failed", exc_info=True)
        return

    _meter_from_token_info(
        token_info=token_info,
        session=session,
        ctx_user_id=ctx_user_id,
        ctx_session_id=ctx_session_id,
        ctx_metadata=ctx_metadata,
        event_sink=event_sink,
        usage_handler=usage_handler,
        reserved_cost=reserved_cost,
        reserved_tokens=reserved_tokens,
        reservation_model=reservation_model,
    )


def _meter_from_token_info(
    token_info: TokenInfo,
    session: UserState | None,
    ctx_user_id: str,
    ctx_session_id: str | None,
    ctx_metadata: dict | None,
    event_sink: EventSink,
    usage_handler: UsageHandler | None = None,
    reserved_cost: float = 0.0,
    reserved_tokens: int = 0,
    reservation_model: str | None = None,
) -> None:
    """Create usage event, update cache (or finalize reservation), push to
    sink, fire callbacks.

    Shared by the non-stream and stream paths.  Entirely fail-open.
    """
    has_reservation = reserved_cost > 0 or reserved_tokens > 0

    try:
        plan_config = session.plan_config if session else None
        effective_session_id = (
            session.current_usage.session_id if session else None
        ) or ctx_session_id
        event = create_usage_event(
            user_id=ctx_user_id,
            token_info=token_info,
            plan_config=plan_config,
            session_id=effective_session_id,
            metadata=ctx_metadata,
        )
    except Exception:
        logger.debug("Event creation failed, skipping metering", exc_info=True)
        # Release any reservation.
        if has_reservation and session is not None:
            try:
                with session.lock:
                    release_reservation(
                        session, reservation_model,
                        reserved_cost, reserved_tokens,
                    )
            except Exception:
                logger.debug("Reservation release after event-creation failure also failed", exc_info=True)
        return

    if session is not None:
        try:
            with session.lock:
                if has_reservation:
                    # IMPORTANT: pass reservation_model (the key apply
                    # used) so release hits the same dict entry.  Do NOT
                    # rely on event.model — it may be the provider's
                    # versioned name and not match the key we held under.
                    finalize_reservation(
                        session, event, reserved_cost, reserved_tokens,
                        reservation_model=reservation_model,
                    )
                else:
                    update_cache(session, event)
        except Exception:
            logger.debug("Cache update/finalize failed", exc_info=True)

    try:
        event_sink(event)
    except Exception:
        logger.debug("Event sink push failed, dropping event", exc_info=True)

    if usage_handler:
        try:
            usage_handler(event)
        except Exception:
            logger.debug("Usage handler failed", exc_info=True)


# ---------------------------------------------------------------------------
# Stream Detection + Wrapping
# ---------------------------------------------------------------------------


def _is_stream_response(response: Any) -> bool:
    """Detect a sync streaming response that should be wrapped for metering.

    A non-streaming ChatCompletion / Message has a ``usage`` attribute with
    token counts.  A Stream is an iterable that hasn't been consumed yet —
    ``usage`` is absent.  We additionally require ``__next__`` to filter out
    plain iterables that happen to lack ``usage`` (e.g. dicts).
    """
    if response is None:
        return False
    # Easy out: if .usage is already populated, it's not a stream
    if getattr(response, "usage", None) is not None:
        return False
    # A stream must be a sync iterator
    return hasattr(response, "__iter__") and hasattr(response, "__next__")


def _is_async_stream_response(response: Any) -> bool:
    """Detect an async streaming response."""
    if response is None:
        return False
    if getattr(response, "usage", None) is not None:
        return False
    return hasattr(response, "__aiter__") and hasattr(response, "__anext__")


def _stream_extractor_for(provider: ProviderConfig) -> Callable[[list], TokenInfo]:
    """Return the provider-specific stream token extractor."""
    if provider.name == "openai":
        return extract_openai_stream_tokens
    if provider.name == "anthropic":
        return extract_anthropic_stream_tokens
    # Fallback — the default stream extractor in stream_wrapper.py
    from paygent.stream_wrapper import _default_stream_extractor
    return _default_stream_extractor


def _wrap_stream_for_metering(
    response: Any,
    *,
    is_async: bool,
    provider: ProviderConfig,
    session: UserState | None,
    ctx_user_id: str,
    ctx_session_id: str | None,
    ctx_metadata: dict | None,
    event_sink: EventSink,
    usage_handler: UsageHandler | None,
    reserved_cost: float = 0.0,
    reserved_tokens: int = 0,
    reservation_model: str | None = None,
) -> Any:
    """Wrap a stream response so that metering fires when it finishes.

    The returned object is a StreamWrapper / AsyncStreamWrapper that yields
    every chunk from the original stream unchanged, then invokes the
    metering pipeline exactly once after the stream terminates.

    If a reservation was placed before the call, it's finalized when the
    stream completes.  Note: the reservation is held for the ENTIRE
    duration of the stream (possibly seconds or minutes), which means
    concurrent calls for the same user see the hold throughout.  This
    is the correct behavior — it prevents bursts of streams from
    overrunning the cap.
    """
    extractor = _stream_extractor_for(provider)

    def on_complete(token_info: TokenInfo, chunks: list) -> None:
        _meter_from_token_info(
            token_info=token_info,
            session=session,
            ctx_user_id=ctx_user_id,
            ctx_session_id=ctx_session_id,
            ctx_metadata=ctx_metadata,
            event_sink=event_sink,
            usage_handler=usage_handler,
            reserved_cost=reserved_cost,
            reserved_tokens=reserved_tokens,
            reservation_model=reservation_model,
        )

    if is_async:
        return AsyncStreamWrapper(
            stream=response,
            on_complete=on_complete,
            extract_stream_tokens=extractor,
        )
    return StreamWrapper(
        stream=response,
        on_complete=on_complete,
        extract_stream_tokens=extractor,
    )


# ---------------------------------------------------------------------------
# Module/Class Resolution
# ---------------------------------------------------------------------------


def resolve_class(module_path: str, class_name: str) -> Any | None:
    """Import a module and return the target class, or None if not available.

    This is used to check if a provider SDK is installed before patching.
    For example, if `openai` is not installed, this returns None and we
    skip patching that provider.
    """
    try:
        module = importlib.import_module(module_path)
        return getattr(module, class_name, None)
    except (ImportError, ModuleNotFoundError):
        logger.debug("Module %s not available, skipping", module_path)
        return None
    except Exception:
        logger.debug("Failed to resolve %s.%s", module_path, class_name, exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Apply / Remove Patches
# ---------------------------------------------------------------------------


def apply_patch(
    provider: ProviderConfig,
    patch_state: PatchState,
    session_lookup: SessionLookup,
    event_sink: EventSink,
    soft_gate_handler: SoftGateHandler | None = None,
    hard_gate_handler: HardGateHandler | None = None,
    usage_handler: UsageHandler | None = None,
    raise_on_hard_gate: bool = True,
) -> list[str]:
    """Apply monkey-patches for a single provider (sync + async).

    Returns list of patch keys that were successfully applied.
    Skips if the provider's SDK is not installed.
    """
    applied = []

    # --- Sync patch ---
    sync_key = f"{provider.module_path}.{provider.class_name}.{provider.method_name}"
    if not patch_state.is_patched(sync_key):
        cls = resolve_class(provider.module_path, provider.class_name)
        if cls is not None:
            original = getattr(cls, provider.method_name, None)
            if original is not None and not getattr(original, "_paygent_patched", False):
                wrapper = create_sync_wrapper(
                    original=original,
                    provider=provider,
                    session_lookup=session_lookup,
                    event_sink=event_sink,
                    soft_gate_handler=soft_gate_handler,
                    hard_gate_handler=hard_gate_handler,
                    usage_handler=usage_handler,
                    raise_on_hard_gate=raise_on_hard_gate,
                )
                patch_state.save(sync_key, cls, provider.method_name, original)
                setattr(cls, provider.method_name, wrapper)
                applied.append(sync_key)
                logger.debug("Patched sync: %s", sync_key)

    # --- Async patch ---
    async_module = provider.async_module_path or provider.module_path
    async_class = provider.async_class_name
    async_method = provider.async_method_name or provider.method_name

    if async_class:
        async_key = f"{async_module}.{async_class}.{async_method}"
        if not patch_state.is_patched(async_key):
            cls = resolve_class(async_module, async_class)
            if cls is not None:
                original = getattr(cls, async_method, None)
                if original is not None and not getattr(original, "_paygent_patched", False):
                    wrapper = create_async_wrapper(
                        original=original,
                        provider=provider,
                        session_lookup=session_lookup,
                        event_sink=event_sink,
                        soft_gate_handler=soft_gate_handler,
                        hard_gate_handler=hard_gate_handler,
                        usage_handler=usage_handler,
                        raise_on_hard_gate=raise_on_hard_gate,
                    )
                    patch_state.save(async_key, cls, async_method, original)
                    setattr(cls, async_method, wrapper)
                    applied.append(async_key)
                    logger.debug("Patched async: %s", async_key)

    return applied


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_model_from_args(args: tuple) -> str | None:
    """Try to extract model name from positional args.

    Most LLM SDK methods accept model as a keyword arg, but some
    may pass it positionally. This is a best-effort fallback.
    """
    for arg in args:
        if isinstance(arg, str) and len(arg) < 100 and not arg.startswith("/"):
            # Heuristic: short string that's likely a model name
            return arg
    return None
