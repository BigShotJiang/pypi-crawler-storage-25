"""SQLite storage backend for the Paygent SDK.

Used as a local fallback when the Paygent backend is unreachable.
Events are stored locally and flushed to the backend on reconnect.

Also used in "local mode" for development — developers can pip install
paygent and start metering without any backend.

Design:
- Async via aiosqlite (non-blocking in async contexts)
- Also provides sync wrappers for use in the background thread
- Idempotent event storage (duplicate event IDs are ignored)
- Zero setup — creates the DB file automatically
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import List, Optional

import aiosqlite

from paygent.models import UsageEvent, UserState
from paygent.storage.base import BaseStorage

logger = logging.getLogger("paygent")

# Default path for the local SQLite database
DEFAULT_DB_PATH = os.path.join(os.path.expanduser("~"), ".paygent", "local.db")


# ---------------------------------------------------------------------------
# SQL Statements
# ---------------------------------------------------------------------------

CREATE_EVENTS_TABLE = """
CREATE TABLE IF NOT EXISTS usage_events (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    session_id TEXT,
    timestamp TEXT NOT NULL,
    model TEXT,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    total_tokens INTEGER DEFAULT 0,
    tool_calls TEXT DEFAULT '[]',
    cost_tokens REAL DEFAULT 0,
    cost_tools REAL DEFAULT 0,
    cost_total REAL DEFAULT 0,
    metadata TEXT DEFAULT '{}',
    synced INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);
"""

CREATE_INDEX_USER = """
CREATE INDEX IF NOT EXISTS idx_events_user
ON usage_events(user_id, timestamp);
"""

CREATE_INDEX_SYNCED = """
CREATE INDEX IF NOT EXISTS idx_events_synced
ON usage_events(synced);
"""

INSERT_EVENT = """
INSERT OR IGNORE INTO usage_events
    (id, user_id, session_id, timestamp, model, input_tokens, output_tokens,
     total_tokens, tool_calls, cost_tokens, cost_tools, cost_total, metadata, synced)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
"""

SELECT_UNSYNCED = """
SELECT id, user_id, session_id, timestamp, model, input_tokens, output_tokens,
       total_tokens, tool_calls, cost_tokens, cost_tools, cost_total, metadata, synced
FROM usage_events
WHERE synced = 0
ORDER BY timestamp ASC
LIMIT ?;
"""

MARK_SYNCED = """
UPDATE usage_events SET synced = 1 WHERE id = ?;
"""

SELECT_BY_USER = """
SELECT id, user_id, session_id, timestamp, model, input_tokens, output_tokens,
       total_tokens, tool_calls, cost_tokens, cost_tools, cost_total, metadata, synced
FROM usage_events
WHERE user_id = ?
ORDER BY timestamp DESC
LIMIT ?;
"""

COUNT_EVENTS = """
SELECT COUNT(*) FROM usage_events;
"""

DELETE_SYNCED_OLDER_THAN = """
DELETE FROM usage_events
WHERE synced = 1 AND created_at < datetime('now', ?);
"""

COUNT_SYNCED_OLDER_THAN = """
SELECT COUNT(*) FROM usage_events
WHERE synced = 1 AND created_at < datetime('now', ?);
"""

# ---------------------------------------------------------------------------
# User Snapshots SQL
# ---------------------------------------------------------------------------

CREATE_SNAPSHOTS_TABLE = """
CREATE TABLE IF NOT EXISTS user_snapshots (
    user_id TEXT PRIMARY KEY,
    plan TEXT NOT NULL,
    plan_config TEXT NOT NULL,
    current_usage TEXT NOT NULL,
    billing_period_start TEXT,
    billing_period_end TEXT,
    snapshot_at TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

UPSERT_SNAPSHOT = """
INSERT INTO user_snapshots
    (user_id, plan, plan_config, current_usage, billing_period_start, billing_period_end, snapshot_at)
VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
ON CONFLICT(user_id) DO UPDATE SET
    plan = excluded.plan,
    plan_config = excluded.plan_config,
    current_usage = excluded.current_usage,
    billing_period_start = excluded.billing_period_start,
    billing_period_end = excluded.billing_period_end,
    snapshot_at = excluded.snapshot_at;
"""

SELECT_SNAPSHOT = """
SELECT user_id, plan, plan_config, current_usage, billing_period_start, billing_period_end, snapshot_at
FROM user_snapshots
WHERE user_id = ?;
"""

DELETE_SNAPSHOT = """
DELETE FROM user_snapshots WHERE user_id = ?;
"""


# ---------------------------------------------------------------------------
# SQLite Storage
# ---------------------------------------------------------------------------


class SQLiteStorage(BaseStorage):
    """Local SQLite storage for Paygent usage events.

    Usage:
        storage = SQLiteStorage(db_path="/path/to/local.db")
        await storage.initialize()
        await storage.store_events([event1, event2])
        unsynced = await storage.get_unsynced_events()
        await storage.close()
    """

    def __init__(self, db_path: str | None = None) -> None:
        self._db_path = db_path or DEFAULT_DB_PATH
        self._db: Optional[aiosqlite.Connection] = None

    @property
    def db_path(self) -> str:
        return self._db_path

    async def initialize(self) -> None:
        """Create the database file and tables if they don't exist."""
        # Ensure directory exists
        db_dir = os.path.dirname(self._db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        # aiosqlite uses a background dispatcher thread that, by default,
        # is NOT a daemon.  Left alone, it blocks Python's interpreter
        # shutdown indefinitely — scripts that call Paygent.init() and
        # don't explicitly call pg.shutdown() hang forever on exit.
        #
        # aiosqlite.connect() returns a Connection BEFORE its thread
        # starts (start happens inside __await__).  We exploit that window
        # to flip daemon=True before the thread starts, since
        # threading.Thread forbids changing daemon after start().
        #
        # The internal API changed between aiosqlite versions:
        #   - <= 0.21: Connection extends Thread → ``conn.daemon = True``
        #   - >= 0.22: Connection holds thread at ``conn._thread``
        # Try both paths so we work across versions.  This reaches into
        # aiosqlite's internals (``_thread`` is private) — if upstream
        # changes again, we'll need to revisit.
        conn = aiosqlite.connect(self._db_path)
        inner_thread = getattr(conn, "_thread", None)
        if inner_thread is not None:
            inner_thread.daemon = True  # aiosqlite >= 0.22
        else:
            try:
                conn.daemon = True  # aiosqlite <= 0.21 (Connection IS a Thread)
            except (AttributeError, RuntimeError):
                # Fail open — worst case, non-daemon thread blocks shutdown,
                # which is the exact bug this code is trying to prevent.
                # Don't raise; user's script would still work, just hang on exit.
                logger.warning(
                    "Could not set aiosqlite dispatcher thread to daemon — "
                    "your script may hang on exit. Call pg.shutdown() explicitly "
                    "to work around. (aiosqlite internal API changed?)"
                )
        self._db = await conn  # __await__ calls start() on the daemon-marked thread
        await self._db.execute("PRAGMA journal_mode=WAL;")
        await self._db.execute("PRAGMA synchronous=NORMAL;")
        await self._db.execute(CREATE_EVENTS_TABLE)
        await self._db.execute(CREATE_INDEX_USER)
        await self._db.execute(CREATE_INDEX_SYNCED)
        await self._db.execute(CREATE_SNAPSHOTS_TABLE)
        await self._db.commit()
        logger.debug("SQLite storage initialized at %s", self._db_path)

    async def store_events(self, events: List[UsageEvent]) -> int:
        """Store events, ignoring duplicates (INSERT OR IGNORE on id).

        Returns the number of newly inserted events.
        """
        if not events or self._db is None:
            return 0

        stored = 0
        for event in events:
            try:
                cursor = await self._db.execute(
                    INSERT_EVENT,
                    (
                        event.id,
                        event.user_id,
                        event.session_id,
                        event.timestamp.isoformat(),
                        event.model,
                        event.input_tokens,
                        event.output_tokens,
                        event.total_tokens,
                        json.dumps(event.tool_calls),
                        event.cost_tokens,
                        event.cost_tools,
                        event.cost_total,
                        json.dumps(event.metadata),
                        1 if event.synced else 0,
                    ),
                )
                if cursor.rowcount > 0:
                    stored += 1
            except Exception:
                logger.debug("Failed to store event %s", event.id, exc_info=True)

        await self._db.commit()
        return stored

    async def get_unsynced_events(self, limit: int = 100) -> List[UsageEvent]:
        """Get events not yet synced to backend, oldest first."""
        if self._db is None:
            return []

        cursor = await self._db.execute(SELECT_UNSYNCED, (limit,))
        rows = await cursor.fetchall()
        return [self._row_to_event(row) for row in rows]

    async def mark_synced(self, event_ids: List[str]) -> int:
        """Mark events as synced after successful backend upload."""
        if not event_ids or self._db is None:
            return 0

        count = 0
        for eid in event_ids:
            try:
                cursor = await self._db.execute(MARK_SYNCED, (eid,))
                count += cursor.rowcount
            except Exception:
                logger.debug("Failed to mark event %s as synced", eid, exc_info=True)

        await self._db.commit()
        return count

    async def get_events_by_user(
        self,
        user_id: str,
        limit: int = 100,
    ) -> List[UsageEvent]:
        """Get events for a user, newest first."""
        if self._db is None:
            return []

        cursor = await self._db.execute(SELECT_BY_USER, (user_id, limit))
        rows = await cursor.fetchall()
        return [self._row_to_event(row) for row in rows]

    async def get_event_count(self) -> int:
        """Total number of events in the store."""
        if self._db is None:
            return 0

        cursor = await self._db.execute(COUNT_EVENTS)
        row = await cursor.fetchone()
        return row[0] if row else 0

    async def cleanup_synced(self, retention_days: int = 7) -> int:
        """Delete synced events older than retention_days.

        Only deletes events with synced=1 (already confirmed on backend).
        Returns the number of deleted rows.

        Args:
            retention_days: Keep synced events for this many days. Default 7.
        """
        if self._db is None:
            return 0

        modifier = f"-{retention_days} days"
        try:
            cursor = await self._db.execute(DELETE_SYNCED_OLDER_THAN, (modifier,))
            deleted = cursor.rowcount
            await self._db.commit()
            if deleted > 0:
                logger.debug(
                    "Cleaned up %d synced events older than %d days",
                    deleted,
                    retention_days,
                )
            return deleted
        except Exception:
            logger.debug("Failed to cleanup synced events", exc_info=True)
            return 0

    # ------------------------------------------------------------------
    # User Snapshots
    # ------------------------------------------------------------------

    async def save_snapshot(self, state: UserState) -> None:
        """Save or update a user state snapshot.

        Persists the user's current plan config and usage counters to SQLite
        so they can be recovered after a process restart.
        """
        if self._db is None:
            return

        bp_start = None
        bp_end = None
        if state.billing_period:
            bp_start = state.billing_period.start.isoformat()
            bp_end = state.billing_period.end.isoformat()

        # plan_config: dump to dict first so we can swap inf sentinels
        # (stdlib json can't encode float('inf')).
        plan_config_dict = state.plan_config.model_dump()
        for key in ("max_spend_per_period", "max_spend_per_session"):
            if plan_config_dict.get(key) == float("inf"):
                plan_config_dict[key] = "__INF__"

        # current_usage: use Pydantic's JSON serializer so datetime fields
        # (session_started_at) are encoded as ISO strings.  stdlib json
        # cannot serialize datetime objects.  load_snapshot already uses
        # CurrentUsage.model_validate_json() which parses them back.
        usage_json = state.current_usage.model_dump_json()

        await self._db.execute(
            UPSERT_SNAPSHOT,
            (
                state.user_id,
                state.plan,
                json.dumps(plan_config_dict),
                usage_json,
                bp_start,
                bp_end,
            ),
        )
        await self._db.commit()

    async def load_snapshot(self, user_id: str) -> Optional[UserState]:
        """Load a user state snapshot from SQLite.

        Returns None if no snapshot exists for this user.
        """
        if self._db is None:
            return None

        cursor = await self._db.execute(SELECT_SNAPSHOT, (user_id,))
        row = await cursor.fetchone()
        if row is None:
            return None

        return self._row_to_snapshot(row)

    async def delete_snapshot(self, user_id: str) -> None:
        """Delete a user state snapshot."""
        if self._db is None:
            return

        await self._db.execute(DELETE_SNAPSHOT, (user_id,))
        await self._db.commit()

    def save_snapshot_sync(self, state: UserState) -> None:
        """Sync wrapper for save_snapshot."""
        _run_async(self.save_snapshot(state))

    def load_snapshot_sync(self, user_id: str) -> Optional[UserState]:
        """Sync wrapper for load_snapshot."""
        return _run_async(self.load_snapshot(user_id))

    def delete_snapshot_sync(self, user_id: str) -> None:
        """Sync wrapper for delete_snapshot."""
        _run_async(self.delete_snapshot(user_id))

    @staticmethod
    def _row_to_snapshot(row: tuple) -> UserState:
        """Convert a database row to a UserState."""
        from paygent.models import BillingPeriod, CurrentUsage, PlanConfig
        from datetime import datetime

        user_id, plan, plan_config_json, usage_json, bp_start, bp_end, snapshot_at = row

        plan_config_dict = json.loads(plan_config_json)
        # Restore inf sentinel values
        for key in ("max_spend_per_period", "max_spend_per_session"):
            if plan_config_dict.get(key) == "__INF__":
                plan_config_dict[key] = float("inf")
            elif plan_config_dict.get(key) is None:
                plan_config_dict[key] = float("inf")

        plan_config = PlanConfig.model_validate(plan_config_dict)
        current_usage = CurrentUsage.model_validate_json(usage_json)

        billing_period = None
        if bp_start and bp_end:
            billing_period = BillingPeriod(
                start=datetime.fromisoformat(bp_start),
                end=datetime.fromisoformat(bp_end),
            )

        return UserState(
            user_id=user_id,
            plan=plan,
            plan_config=plan_config,
            current_usage=current_usage,
            billing_period=billing_period,
            last_refreshed=datetime.fromisoformat(snapshot_at) if snapshot_at else None,
        )

    async def close(self) -> None:
        """Close the database connection."""
        if self._db is not None:
            await self._db.close()
            self._db = None
            logger.debug("SQLite storage closed")

    # ------------------------------------------------------------------
    # Sync wrappers (for use in background thread)
    # ------------------------------------------------------------------

    def store_events_sync(self, events: List[UsageEvent]) -> int:
        """Sync wrapper for store_events. Runs in a new event loop."""
        return _run_async(self.store_events(events))

    def get_unsynced_events_sync(self, limit: int = 100) -> List[UsageEvent]:
        """Sync wrapper for get_unsynced_events."""
        return _run_async(self.get_unsynced_events(limit))

    def mark_synced_sync(self, event_ids: List[str]) -> int:
        """Sync wrapper for mark_synced."""
        return _run_async(self.mark_synced(event_ids))

    def cleanup_synced_sync(self, retention_days: int = 7) -> int:
        """Sync wrapper for cleanup_synced."""
        return _run_async(self.cleanup_synced(retention_days))

    def initialize_sync(self) -> None:
        """Sync wrapper for initialize."""
        _run_async(self.initialize())

    def close_sync(self) -> None:
        """Sync wrapper for close."""
        _run_async(self.close())

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_event(row: tuple) -> UsageEvent:
        """Convert a database row to a UsageEvent."""
        return UsageEvent(
            id=row[0],
            user_id=row[1],
            session_id=row[2],
            timestamp=row[3],
            model=row[4],
            input_tokens=row[5],
            output_tokens=row[6],
            total_tokens=row[7],
            tool_calls=json.loads(row[8]) if row[8] else [],
            cost_tokens=row[9],
            cost_tools=row[10],
            cost_total=row[11],
            metadata=json.loads(row[12]) if row[12] else {},
            synced=bool(row[13]),
        )


# ---------------------------------------------------------------------------
# Async runner helper
# ---------------------------------------------------------------------------


def _run_async(coro):
    """Run an async coroutine from sync code.

    Handles the case where an event loop is already running
    (e.g., inside an async framework) by creating a new thread.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is None:
        # No running loop — create one if needed (Python 3.9 compat for non-main threads)
        try:
            current_loop = asyncio.get_event_loop()
        except RuntimeError:
            current_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(current_loop)
        return current_loop.run_until_complete(coro)
    else:
        # Already in an async context — run in a new thread
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result(timeout=10)
