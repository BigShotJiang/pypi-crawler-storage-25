"""Abstract storage interface for the Paygent SDK.

All storage backends (SQLite, future Postgres, etc.) implement this
interface. The SDK interacts with storage only through these methods.
"""

from __future__ import annotations

import abc
from typing import List, Optional

from paygent.models import UsageEvent


class BaseStorage(abc.ABC):
    """Abstract base for Paygent event storage."""

    @abc.abstractmethod
    async def initialize(self) -> None:
        """Create tables / prepare the storage backend."""
        ...

    @abc.abstractmethod
    async def store_events(self, events: List[UsageEvent]) -> int:
        """Store a batch of events. Returns count of newly stored (deduped)."""
        ...

    @abc.abstractmethod
    async def get_unsynced_events(self, limit: int = 100) -> List[UsageEvent]:
        """Get events that haven't been synced to the backend yet."""
        ...

    @abc.abstractmethod
    async def mark_synced(self, event_ids: List[str]) -> int:
        """Mark events as synced. Returns count updated."""
        ...

    @abc.abstractmethod
    async def get_events_by_user(
        self,
        user_id: str,
        limit: int = 100,
    ) -> List[UsageEvent]:
        """Get events for a specific user, newest first."""
        ...

    @abc.abstractmethod
    async def get_event_count(self) -> int:
        """Get total number of stored events."""
        ...

    @abc.abstractmethod
    async def close(self) -> None:
        """Close the storage connection."""
        ...
