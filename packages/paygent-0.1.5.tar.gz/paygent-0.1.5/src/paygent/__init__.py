"""Paygent — The economic brain for AI agents.

Public API (stable contract).  Everything below ``__all__`` is what
developers should import directly.  Anything else — callback registries,
metering helpers, cost calculators, patcher internals — is implementation
detail and may change between minor versions.  If you need those, import
them from the specific submodule (``paygent.guardrails``, ``paygent.metering``,
etc.) and accept the churn risk.
"""

from paygent.context import paygent_context, paygent_track
from paygent.core import Paygent
from paygent.guardrails import (
    PaygentAuthInvalid,
    PaygentBackendUnreachable,
    PaygentLimitExceeded,
)
from paygent.models import (
    BillingPeriod,
    BudgetRemaining,
    CurrentUsage,
    GuardResult,
    MaxTokensAdvice,
    ModelCostRate,
    ModelLimitConfig,
    ModelUsage,
    PlanConfig,
    UsageEvent,
    UserSession,
    UserState,
)

__all__ = [
    # Core
    "Paygent",
    # Context management
    "paygent_context",
    "paygent_track",
    # Exceptions (hard-gate block)
    "PaygentLimitExceeded",
    # Init-time warnings (also usable as exceptions via strict_backend=True)
    "PaygentBackendUnreachable",
    "PaygentAuthInvalid",
    # Plan configuration (developer-facing models)
    "PlanConfig",
    "ModelCostRate",
    "ModelLimitConfig",
    # Runtime state / results (read-only models devs may inspect)
    "GuardResult",
    "UsageEvent",
    "CurrentUsage",
    "ModelUsage",
    "UserState",
    "BudgetRemaining",
    "MaxTokensAdvice",
    "BillingPeriod",
    # Deprecated alias (will be removed in Phase 2) — kept for backward compat
    "UserSession",
]
