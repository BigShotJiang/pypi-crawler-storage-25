"""Guardrails engine for the Paygent SDK.

The guard check is the most important code in the SDK. It runs BEFORE every
LLM call to decide whether to allow, warn, or block the request.

Design constraints:
- **In-memory only** — dict lookups + comparisons, zero I/O, zero network.
- **Sub-millisecond** — must never add perceptible latency.
- **Fail-open** — on any error, return GuardResult(status="ok") so the
  LLM call proceeds. Paygent must never break the developer's agent.

The guard checks three types of limits in order, returning the FIRST
violation found (most restrictive wins):

1. Total monthly spend vs plan limit
2. Per-session spend vs session limit
3. Per-model token usage vs model-specific token limit
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Callable

from paygent.models import GuardResult, UserState

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Custom Exception
# ---------------------------------------------------------------------------


class PaygentLimitExceeded(Exception):
    """Raised when a hard gate is hit and the developer wants exceptions.

    This is the ONLY Paygent exception that should ever propagate to the
    developer's code. It carries the full GuardResult for inspection.
    """

    def __init__(self, guard_result: GuardResult) -> None:
        self.guard_result = guard_result
        super().__init__(guard_result.message or "Usage limit exceeded")


# ---------------------------------------------------------------------------
# Init-time warnings — emitted by Paygent.init() when backend validation fails.
# ---------------------------------------------------------------------------
#
# These subclass UserWarning so they print to stderr by default (via Python's
# `warnings` module) without needing logging configured.  Because UserWarning
# inherits from Exception, they can ALSO be raised directly when the caller
# passes ``strict_backend=True`` to Paygent.init().
#
# Suppress with:
#     import warnings
#     warnings.filterwarnings("ignore", category=PaygentBackendUnreachable)
#
# Promote to hard error with:
#     python -W error::paygent.guardrails.PaygentBackendUnreachable script.py


class PaygentBackendUnreachable(UserWarning):
    """Emitted at init when the Paygent backend is not reachable.

    Causes: DNS resolution failure, connection refused, timeout, non-2xx
    response on the auth-check request.  SDK continues running in OFFLINE
    mode — guardrails use last-known cached state; events queue locally
    and sync when the backend returns.

    When ``Paygent.init(..., strict_backend=True)`` is set, this is raised
    instead of warned.
    """


class PaygentAuthInvalid(UserWarning):
    """Emitted at init when the backend returns 401/403 to the API key.

    Means the backend IS reachable but rejects the credentials.  SDK
    continues to run but will NOT be synced to the backend — guardrails
    are effectively local-only until the API key is fixed.

    When ``Paygent.init(..., strict_backend=True)`` is set, this is raised
    instead of warned.
    """


# ---------------------------------------------------------------------------
# Guard Check
# ---------------------------------------------------------------------------


def check_guard(
    session: UserState,
    model: str | None = None,
    estimated_input_tokens: int | None = None,
    max_tokens: int | None = None,
) -> GuardResult:
    """Check all applicable limits for a user before an LLM call.

    Runs ALL three checks (period spend, session spend, per-model tokens),
    then returns the **most-restrictive** violation — hard_gate beats
    soft_gate, and within the same severity the one closest to its limit
    (highest ``usage_pct``) wins.  This avoids the footgun where an earlier
    soft_gate masks a later hard_gate.

    If no checks fire, returns ``GuardResult(status="ok")``.

    Checks evaluated:
      1. Total period spend vs plan limit
      2. Session spend vs session limit (after clock-based window rotation)
      3. Per-model token usage vs model limit (if configured)

    When ``pre_call_estimate`` is enabled in the plan config, checks use
    *projected* values (current + reserved + estimated cost/tokens for
    this call) instead of just current usage.  This prevents a user at
    99% from getting a soft gate while the LLM call then overshoots the
    limit.

    Args:
        session: The cached UserState with plan config and current usage.
        model: The model about to be called (e.g. "gpt-4o"). Required for
               model-level limit checks.
        estimated_input_tokens: Rough token count of the prompt messages.
               Used only when ``pre_call_estimate`` is enabled.
        max_tokens: The ``max_tokens`` kwarg passed to the LLM call.
               Used as the output token estimate when ``pre_call_estimate``
               is enabled. Falls back to ``pre_call_buffer_tokens``.

    Returns:
        GuardResult with status "ok", "soft_gate", or "hard_gate".
        On any internal error, returns GuardResult(status="ok") (fail-open).
    """
    try:
        config = session.plan_config
        usage = session.current_usage

        # --- Normalize model name ---
        # So "gpt-4o-mini-2024-07-18" matches configured "gpt-4o-mini"
        if model:
            from paygent.metering import normalize_model_name
            model = normalize_model_name(model, config)

        # --- Pre-call estimation ---
        estimated_cost = 0.0
        estimated_tokens = 0
        if config.pre_call_estimate and model:
            estimated_cost, estimated_tokens = _estimate_call(
                model=model,
                config=config,
                estimated_input_tokens=estimated_input_tokens,
                max_tokens=max_tokens,
            )

        # In-flight reservations from concurrent calls for the same user.
        # Guard sees ``actual + reserved`` so two bursts at the boundary
        # can't both read the same pre-call state and both pass.
        reserved_cost = usage.reserved_cost
        reserved_model_tokens = (
            usage.reserved_tokens_by_model.get(model, 0) if model else 0
        )

        # Collect every triggered violation, then pick the worst.
        # Order of appends matters ONLY as a stable tiebreaker — we
        # sort by (severity, usage_pct) afterwards so "first wins"
        # doesn't leak back in.
        violations: list[GuardResult] = []

        # --- Session expiry: rotate window if clock-based timeout expired ---
        # Must happen BEFORE the session-spend check so session_cost is
        # accurate for a freshly-rotated window.
        from paygent.metering import _maybe_rotate_session
        _maybe_rotate_session(usage, config.session_timeout_minutes)

        # --- Check 1: Total period spend ---
        effective_period_cost = usage.period_cost + reserved_cost + estimated_cost
        r = _check_spend_limit(
            current=effective_period_cost,
            limit=config.max_spend_per_period,
            soft_gate_at=config.soft_gate_at,
            hard_gate_at=config.hard_gate_at,
            gate_reason="total_spend",
            hard_message=(
                f"Spend limit reached: "
                f"${usage.period_cost:.2f} of ${config.max_spend_per_period:.2f}"
                f" (estimated call cost: ${estimated_cost:.4f})"
                if estimated_cost > 0
                else f"Spend limit reached: "
                f"${usage.period_cost:.2f} of ${config.max_spend_per_period:.2f}"
            ),
            soft_message_fmt="Approaching spend limit: {pct:.0%} used",
        )
        if r is not None:
            violations.append(r)

        # --- Check 2: Session spend ---
        # Session also carries reservations implicitly via reserved_cost
        # (reservations aren't split period/session — they're a single
        # in-flight pool that applies to both checks).
        effective_session_cost = usage.session_cost + reserved_cost + estimated_cost
        r = _check_spend_limit(
            current=effective_session_cost,
            limit=config.max_spend_per_session,
            soft_gate_at=config.soft_gate_at,
            hard_gate_at=config.hard_gate_at,
            gate_reason="session_spend",
            hard_message="Session spend limit reached",
            soft_message_fmt="Approaching session limit: {pct:.0%} used",
        )
        if r is not None:
            violations.append(r)

        # --- Check 3: Model-specific token limit ---
        if model and model in config.model_limits:
            model_limit = config.model_limits[model]
            if model_limit.max_tokens_per_period is not None:
                tokens_used = (
                    usage.period_tokens_by_model.get(model, 0)
                    + reserved_model_tokens
                    + estimated_tokens
                )
                r = _check_spend_limit(
                    current=tokens_used,
                    limit=model_limit.max_tokens_per_period,
                    soft_gate_at=config.soft_gate_at,
                    hard_gate_at=config.hard_gate_at,
                    gate_reason=f"model_limit:{model}",
                    hard_message=(
                        f"{model} token limit reached: "
                        f"{tokens_used:,} of {model_limit.max_tokens_per_period:,}"
                    ),
                    soft_message_fmt=f"{model} approaching token limit: {{pct:.0%}} used",
                )
                if r is not None:
                    violations.append(r)

        if not violations:
            return GuardResult(status="ok")

        # Pick the most-restrictive violation:
        #   - hard_gate (severity 2) beats soft_gate (severity 1)
        #   - within the same severity, the one closest to its limit (highest
        #     usage_pct) wins — that's the "tightest" constraint
        _severity = {"hard_gate": 2, "soft_gate": 1, "ok": 0}
        return max(
            violations,
            key=lambda r: (_severity.get(r.status, 0), r.usage_pct),
        )

    except Exception:
        logger.debug("Guard check failed, returning ok (fail-open)", exc_info=True)
        return GuardResult(status="ok")


# ---------------------------------------------------------------------------
# Internal Helpers
# ---------------------------------------------------------------------------


def _estimate_call(
    model: str,
    config: "PlanConfig",
    estimated_input_tokens: int | None = None,
    max_tokens: int | None = None,
) -> tuple[float, int]:
    """Estimate the cost and token count of an upcoming LLM call.

    - ``estimated_input_tokens``: rough chars/4 approximation of the prompt
      (populated by the patcher via ``estimate_input_tokens(messages)``).
    - ``max_tokens``: the caller's explicit output cap.  When absent, we
      fall back to ``config.pre_call_buffer_tokens`` as the worst-case
      output assumption — tuned to cover realistic unbounded completions.

    Returns ``(estimated_cost, estimated_total_tokens)``.  Both are 0 if
    the model has no configured cost rate and no default_cost_rate.
    """
    from paygent.models import PlanConfig  # avoid circular at module level

    input_est = estimated_input_tokens or 0
    output_est = max_tokens if max_tokens is not None else config.pre_call_buffer_tokens
    total_est = input_est + output_est

    # Calculate estimated dollar cost if we have a rate for this model
    cost = 0.0
    rate = None
    if model in config.cost_rates:
        rate = config.cost_rates[model]
    elif config.default_cost_rate is not None:
        rate = config.default_cost_rate

    if rate:
        cost = (input_est / 1000.0) * rate.input + (output_est / 1000.0) * rate.output

    return cost, total_est


def estimate_input_tokens(messages: list | None) -> int:
    """Rough token estimate from a list of chat messages.

    Uses the heuristic of ~4 characters per token.  This is intentionally
    imprecise — it's a pre-call safety net, not a billing calculation.
    The real token count comes from the LLM response after the call.
    """
    if not messages:
        return 0
    total_chars = 0
    for msg in messages:
        if isinstance(msg, dict):
            content = msg.get("content", "")
            if isinstance(content, str):
                total_chars += len(content)
            elif isinstance(content, list):
                # Multi-part content (e.g. vision messages)
                for part in content:
                    if isinstance(part, dict):
                        total_chars += len(part.get("text", ""))
        elif hasattr(msg, "content"):
            content = getattr(msg, "content", "")
            if isinstance(content, str):
                total_chars += len(content)
    # ~4 chars per token is a rough average across models
    return max(total_chars // 4, 1) if total_chars > 0 else 0


def _check_spend_limit(
    current: float,
    limit: float,
    soft_gate_at: float,
    hard_gate_at: float,
    gate_reason: str,
    hard_message: str,
    soft_message_fmt: str,
) -> GuardResult | None:
    """Check a single spend/token limit. Returns GuardResult if violated, None if ok."""
    if limit == float("inf") or limit == 0:
        return None

    pct = current / limit

    if pct >= hard_gate_at:
        return GuardResult(
            status="hard_gate",
            gate_reason=gate_reason,
            usage_pct=pct,
            current_value=current,
            limit_value=limit,
            message=hard_message,
        )

    if pct >= soft_gate_at:
        return GuardResult(
            status="soft_gate",
            gate_reason=gate_reason,
            usage_pct=pct,
            current_value=current,
            limit_value=limit,
            message=soft_message_fmt.format(pct=pct),
        )

    return None


# ---------------------------------------------------------------------------
# Soft Gate Callback Registry
# ---------------------------------------------------------------------------


class _CallbackRegistry:
    """Base class for callback registries.

    Manages a list of callbacks that are invoked with a single argument.
    Errors in individual callbacks are logged and swallowed — a failing
    callback must never break the SDK.
    """

    _label: str = "callback"  # for log messages, overridden by subclasses

    def __init__(self) -> None:
        self._callbacks: list[Callable] = []

    def register(self, callback: Callable) -> None:
        """Register a callback."""
        self._callbacks.append(callback)

    def fire(self, arg: object) -> None:
        """Invoke all registered callbacks. Errors are logged and swallowed."""
        for cb in self._callbacks:
            try:
                cb(arg)
            except Exception:
                logger.debug("%s callback failed", self._label, exc_info=True)

    def clear(self) -> None:
        """Remove all registered callbacks."""
        self._callbacks.clear()

    @property
    def count(self) -> int:
        """Number of registered callbacks."""
        return len(self._callbacks)


class SoftGateCallbackRegistry(_CallbackRegistry):
    """Callbacks that fire when a soft gate triggers (approaching a limit).

    Callbacks receive a ``GuardResult`` with details about which limit
    is being approached.
    """

    _label = "Soft gate"

    def register(self, callback: Callable[[GuardResult], None]) -> None:  # type: ignore[override]
        """Register a callback to be invoked on soft gate."""
        super().register(callback)

    def fire(self, result: GuardResult) -> None:  # type: ignore[override]
        """Invoke all registered soft gate callbacks."""
        super().fire(result)


class HardGateCallbackRegistry(_CallbackRegistry):
    """Callbacks that fire when a hard gate triggers (limit exceeded).

    Callbacks fire *before* ``PaygentLimitExceeded`` is raised (if raising is
    enabled). If ``raise_on_hard_gate=False``, the callback still fires but
    the LLM call proceeds.

    Callbacks receive a ``GuardResult`` with details about which limit was hit.
    """

    _label = "Hard gate"

    def register(self, callback: Callable[[GuardResult], None]) -> None:  # type: ignore[override]
        """Register a callback to be invoked on hard gate."""
        super().register(callback)

    def fire(self, result: GuardResult) -> None:  # type: ignore[override]
        """Invoke all registered hard gate callbacks."""
        super().fire(result)


class UsageCallbackRegistry(_CallbackRegistry):
    """Callbacks that fire after every successful metering event.

    Callbacks receive a ``UsageEvent`` with the cost, tokens, model, and
    other details of the completed LLM call. Useful for real-time dashboards,
    custom logging, or developer-defined threshold logic.
    """

    _label = "Usage"


class SessionStartCallbackRegistry(_CallbackRegistry):
    """Callbacks that fire when a user session is started or bootstrapped.

    Callbacks receive a ``UserSession`` with the plan configuration and
    current usage state. Useful for custom initialization or logging.
    """

    _label = "Session start"
