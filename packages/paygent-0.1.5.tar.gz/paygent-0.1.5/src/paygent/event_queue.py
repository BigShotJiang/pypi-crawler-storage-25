"""Background event queue for the Paygent SDK.

Usage events are created synchronously after each LLM call, but persisting
them (to the backend or local SQLite) should never block the response.

The event queue:
1. Accepts events via `push()` (non-blocking, called from the wrapper)
2. Accumulates events in a thread-safe `queue.Queue`
3. Runs a background daemon thread that:
   - Wakes every `flush_interval` seconds
   - Drains all queued events into a batch
   - Calls the configured `flush_callback` with the batch
4. On shutdown (`stop()`), flushes remaining events

The flush_callback is provided by core.py and handles the actual
persistence — either sending to the backend API or writing to local SQLite.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Any, Callable, List, Optional

from paygent.models import UsageEvent

logger = logging.getLogger("paygent")

# Type for the callback that receives a batch of events
FlushCallback = Callable[[List["UsageEvent"]], None]
# Type for the periodic sync callback (retries unsynced events from local storage)
SyncPendingCallback = Callable[[], int]
# Type for the periodic refresh callback (refreshes stale UserStates from backend)
RefreshCallback = Callable[[], None]


class EventQueue:
    """Thread-safe event queue with background flush.

    Usage:
        eq = EventQueue(flush_callback=my_flush, flush_interval=5.0)
        eq.start()
        eq.push(event)   # non-blocking
        ...
        eq.stop()         # flushes remaining events
    """

    def __init__(
        self,
        flush_callback: FlushCallback,
        flush_interval: float = 5.0,
        max_batch_size: int = 100,
        max_queue_size: int = 10_000,
        sync_pending_callback: Optional[SyncPendingCallback] = None,
        sync_pending_interval: float = 30.0,
        refresh_callback: Optional[RefreshCallback] = None,
        refresh_interval: float = 60.0,
    ) -> None:
        """
        Args:
            flush_callback: Called with a list of UsageEvents on each flush cycle.
            flush_interval: Seconds between flush cycles (default 5s).
            max_batch_size: Maximum events per flush batch.
            max_queue_size: Maximum queue depth. Events are dropped if exceeded.
            sync_pending_callback: Called periodically to retry unsynced events
                from local storage. None = no periodic sync.
            sync_pending_interval: Seconds between sync_pending calls (default 30s).
            refresh_callback: Called periodically to refresh stale UserStates
                from the backend. None = no periodic refresh.
            refresh_interval: Seconds between refresh calls (default 60s).
        """
        self._flush_callback = flush_callback
        self._flush_interval = flush_interval
        self._max_batch_size = max_batch_size
        self._queue: queue.Queue = queue.Queue(maxsize=max_queue_size)
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._started = False
        self._total_pushed = 0
        self._total_flushed = 0
        self._total_dropped = 0
        self._sync_pending_callback = sync_pending_callback
        self._sync_pending_interval = sync_pending_interval
        self._last_sync_pending: float = 0.0
        self._refresh_callback = refresh_callback
        self._refresh_interval = refresh_interval
        self._last_refresh: float = 0.0

    @property
    def is_running(self) -> bool:
        """Whether the background flush thread is running."""
        return self._started and self._thread is not None and self._thread.is_alive()

    @property
    def pending_count(self) -> int:
        """Number of events waiting to be flushed."""
        return self._queue.qsize()

    @property
    def stats(self) -> dict:
        """Queue statistics."""
        return {
            "total_pushed": self._total_pushed,
            "total_flushed": self._total_flushed,
            "total_dropped": self._total_dropped,
            "pending": self.pending_count,
            "is_running": self.is_running,
        }

    def push(self, event: UsageEvent) -> bool:
        """Add an event to the queue. Non-blocking.

        Returns True if the event was queued, False if dropped
        (queue full or not started). Never raises.
        """
        try:
            self._queue.put_nowait(event)
            self._total_pushed += 1
            return True
        except queue.Full:
            self._total_dropped += 1
            logger.warning("Event queue full, dropping event %s", event.id)
            return False
        except Exception:
            self._total_dropped += 1
            logger.debug("Failed to push event", exc_info=True)
            return False

    def start(self) -> None:
        """Start the background flush thread."""
        if self._started:
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="paygent-event-queue",
            daemon=True,  # Dies when main thread exits
        )
        self._thread.start()
        self._started = True
        logger.debug("Event queue started (interval=%.1fs)", self._flush_interval)

    def stop(self, timeout: float = 10.0) -> int:
        """Stop the background thread and flush remaining events.

        Args:
            timeout: Max seconds to wait for the thread to finish.

        Returns:
            Number of events flushed during shutdown (including by background thread).
        """
        if not self._started:
            return 0

        flushed_before = self._total_flushed
        self._stop_event.set()

        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)

        # Final flush of anything the thread didn't get to
        self._flush_all()
        self._started = False
        total_flushed_during_stop = self._total_flushed - flushed_before
        logger.debug("Event queue stopped, flushed %d events during shutdown", total_flushed_during_stop)
        return total_flushed_during_stop

    def flush_now(self) -> int:
        """Manually trigger a flush. Returns number of events flushed.

        Useful for testing or graceful shutdown.
        """
        return self._flush_all()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Background thread loop: sleep → flush → maybe sync_pending → maybe refresh → repeat."""
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=self._flush_interval)
            if not self._stop_event.is_set() or not self._queue.empty():
                try:
                    self._flush_all()
                except Exception:
                    logger.debug("Flush cycle failed", exc_info=True)

            # Periodically retry unsynced events from local storage
            self._maybe_sync_pending()
            # Periodically refresh stale UserStates from backend
            self._maybe_refresh()

    def _flush_all(self) -> int:
        """Drain the queue and flush in batches. Returns total events flushed."""
        total = 0
        while not self._queue.empty():
            batch = self._drain_batch()
            if not batch:
                break
            try:
                self._flush_callback(batch)
                self._total_flushed += len(batch)
                total += len(batch)
            except Exception:
                logger.warning(
                    "Flush callback failed for %d events, events lost",
                    len(batch),
                    exc_info=True,
                )
        return total

    def _maybe_sync_pending(self) -> None:
        """Call sync_pending_callback if enough time has elapsed."""
        if self._sync_pending_callback is None:
            return
        now = time.monotonic()
        if now - self._last_sync_pending >= self._sync_pending_interval:
            try:
                synced = self._sync_pending_callback()
                if synced > 0:
                    logger.debug("Periodic sync_pending synced %d events", synced)
            except Exception:
                logger.debug("Periodic sync_pending failed", exc_info=True)
            self._last_sync_pending = now

    def _maybe_refresh(self) -> None:
        """Call refresh_callback if enough time has elapsed."""
        if self._refresh_callback is None:
            return
        now = time.monotonic()
        if now - self._last_refresh >= self._refresh_interval:
            try:
                self._refresh_callback()
            except Exception:
                logger.debug("Periodic refresh failed", exc_info=True)
            self._last_refresh = now

    def _drain_batch(self) -> list:
        """Pull up to max_batch_size events from the queue."""
        batch = []
        for _ in range(self._max_batch_size):
            try:
                event = self._queue.get_nowait()
                batch.append(event)
            except queue.Empty:
                break
        return batch
