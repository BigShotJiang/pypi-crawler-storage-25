"""Metering engine for the Paygent SDK.

Responsible for two things:

1. **Cost calculation** — Takes raw token counts + tool calls from an LLM
   response and computes the dollar cost using the developer's configured
   cost rates. Produces a fully-costed UsageEvent.

2. **Cache update** — After metering, updates the in-memory CurrentUsage
   cache (dict updates only, zero I/O) so that guard checks have fresh data.

Both operations are synchronous and fast. Persistence to the backend happens
asynchronously via the event queue (not this module's concern).
"""

from __future__ import annotations

import logging
from datetime import datetime
from uuid import uuid4

from paygent.models import CurrentUsage, PlanConfig, UsageEvent, UserState
from paygent.providers import TokenInfo

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Cost Calculation
# ---------------------------------------------------------------------------


def calculate_cost(
    token_info: TokenInfo,
    plan_config: PlanConfig,
    tool_calls: list[str] | None = None,
) -> tuple[float, float, float]:
    """Calculate the dollar cost for an LLM call.

    Args:
        token_info: Extracted token counts and model name from the LLM response.
        plan_config: The developer's plan configuration with cost rates.
        tool_calls: List of tool names invoked during this call.

    Returns:
        Tuple of (cost_tokens, cost_tools, cost_total).
        All values are 0.0 if calculation fails (fail-open).
    """
    try:
        cost_tokens = _calculate_token_cost(token_info, plan_config)
        cost_tools = _calculate_tool_cost(tool_calls or [], plan_config)
        cost_total = cost_tokens + cost_tools
        return cost_tokens, cost_tools, cost_total
    except Exception:
        logger.debug("Failed to calculate cost", exc_info=True)
        return 0.0, 0.0, 0.0


def normalize_model_name(model: str | None, plan_config: PlanConfig) -> str | None:
    """Normalize a model name returned by an LLM API to match configured names.

    LLM providers often return versioned model names in responses
    (e.g. ``gpt-4o-mini-2024-07-18``), while developers configure
    cost rates and limits using the short alias (``gpt-4o-mini``).

    This function checks if the response model is already a configured
    name. If not, it finds the configured name that is a prefix of the
    response model (longest prefix wins to avoid ``gpt-4o`` matching
    ``gpt-4o-mini-2024-07-18``).

    Returns the original model name if no match is found — the SDK
    still tracks tokens even without a matching cost rate.
    """
    if not model:
        return model

    # Exact match — fast path
    all_configured = set(plan_config.cost_rates.keys()) | set(plan_config.model_limits.keys())
    if model in all_configured:
        return model

    # Prefix match — longest wins (so "gpt-4o-mini" beats "gpt-4o")
    best_match: str | None = None
    for configured_name in all_configured:
        if model.startswith(configured_name):
            if best_match is None or len(configured_name) > len(best_match):
                best_match = configured_name

    return best_match or model


def _calculate_token_cost(token_info: TokenInfo, plan_config: PlanConfig) -> float:
    """Calculate cost from token usage using configured cost rates.

    Cost rates are per 1K tokens. Lookup order:
    1. Model-specific rate from ``cost_rates``
    2. ``default_cost_rate`` (if set) — used for unconfigured models
    3. Cost is 0 (tokens still tracked, but can't price without a rate)

    A warning is logged when a model is encountered that has no explicit
    cost rate configured, regardless of whether ``default_cost_rate`` is set.
    """
    if not token_info.model:
        return 0.0

    if token_info.model in plan_config.cost_rates:
        rate = plan_config.cost_rates[token_info.model]
    elif plan_config.default_cost_rate is not None:
        logger.warning(
            "Model '%s' has no configured cost rate — using default_cost_rate. "
            "Add an explicit rate via cost_rates to silence this warning.",
            token_info.model,
        )
        rate = plan_config.default_cost_rate
    else:
        logger.warning(
            "Model '%s' has no configured cost rate and no default_cost_rate is set — "
            "token cost will be $0. Spending guardrails will not account for this model's cost.",
            token_info.model,
        )
        return 0.0

    input_cost = (token_info.input_tokens / 1000.0) * rate.input
    output_cost = (token_info.output_tokens / 1000.0) * rate.output
    return input_cost + output_cost


def _calculate_tool_cost(tool_calls: list[str], plan_config: PlanConfig) -> float:
    """Calculate cost from tool invocations using configured tool costs."""
    if not tool_calls:
        return 0.0

    total = 0.0
    for tool_name in tool_calls:
        cost = plan_config.tool_costs.get(tool_name, plan_config.default_tool_cost)
        total += cost
    return total


# ---------------------------------------------------------------------------
# Create Usage Event
# ---------------------------------------------------------------------------


def create_usage_event(
    user_id: str,
    token_info: TokenInfo,
    plan_config: PlanConfig,
    session_id: str | None = None,
    tool_calls: list[str] | None = None,
    metadata: dict | None = None,
) -> UsageEvent:
    """Create a fully-costed UsageEvent from an LLM response.

    This is the main entry point for the metering engine. It:
    1. Calculates dollar cost from token counts + cost rates
    2. Packages everything into a UsageEvent with a unique ID

    Args:
        user_id: The end user this event belongs to.
        token_info: Extracted token data from the LLM response.
        plan_config: Developer's plan configuration with cost rates.
        session_id: Optional session identifier.
        tool_calls: Optional list of tool names invoked.
        metadata: Optional key-value pairs to attach to the event.

    Returns:
        A fully populated UsageEvent. On any error, returns an event
        with zero costs (fail-open).
    """
    try:
        # Normalize the model name so "gpt-4o-mini-2024-07-18" matches
        # the configured "gpt-4o-mini" rate and limit.
        if plan_config is not None:
            token_info = TokenInfo(
                model=normalize_model_name(token_info.model, plan_config),
                input_tokens=token_info.input_tokens,
                output_tokens=token_info.output_tokens,
                total_tokens=token_info.total_tokens,
            )

        cost_tokens, cost_tools, cost_total = calculate_cost(
            token_info, plan_config, tool_calls
        )

        total_tokens = token_info.total_tokens
        if total_tokens == 0:
            total_tokens = token_info.input_tokens + token_info.output_tokens

        return UsageEvent(
            id=str(uuid4()),
            user_id=user_id,
            session_id=session_id,
            timestamp=datetime.utcnow(),
            model=token_info.model,
            input_tokens=token_info.input_tokens,
            output_tokens=token_info.output_tokens,
            total_tokens=total_tokens,
            tool_calls=tool_calls or [],
            cost_tokens=cost_tokens,
            cost_tools=cost_tools,
            cost_total=cost_total,
            metadata=metadata or {},
            synced=False,
        )
    except Exception:
        logger.warning("Failed to create usage event, returning zero-cost event", exc_info=True)
        return UsageEvent(
            user_id=user_id,
            session_id=session_id,
            timestamp=datetime.utcnow(),
        )


# ---------------------------------------------------------------------------
# Cache Update (In-Memory, No I/O)
# ---------------------------------------------------------------------------


def _maybe_rotate_session(usage: "CurrentUsage", timeout: float) -> None:
    """Rotate the session window if the clock-based timeout has expired.

    Called before accumulating costs so that the new event lands in a
    fresh window.  Generates a new ``session_id`` and resets
    ``session_cost`` / ``session_started_at``.

    A *None* ``session_started_at`` means the very first call — the
    window is opened (not expired) and no rotation is needed.
    """
    from datetime import timedelta
    from uuid import uuid4

    if usage.session_started_at is None:
        # First call ever — open the window, assign session_id
        usage.session_started_at = datetime.utcnow()
        if usage.session_id is None:
            usage.session_id = str(uuid4())
        return

    if timeout == float("inf") or timeout <= 0:
        return  # No timeout configured

    elapsed = datetime.utcnow() - usage.session_started_at
    if elapsed > timedelta(minutes=timeout):
        logger.debug(
            "Session window expired (%.1f min > %.1f min), rotating",
            elapsed.total_seconds() / 60,
            timeout,
        )
        usage.session_cost = 0.0
        usage.session_started_at = datetime.utcnow()
        usage.session_id = str(uuid4())


def update_cache(session: UserState, event: UsageEvent) -> None:
    """Update the in-memory usage cache after a metering event.

    This MUST be fast — dict updates only, no I/O, no network calls.
    Called synchronously after every LLM call so that subsequent guard
    checks have accurate data.

    Fails silently on any error (fail-open). The event is still queued
    for backend sync regardless of whether the cache update succeeds.
    """
    try:
        usage = session.current_usage

        # Rotate session window if the clock-based timeout has expired.
        _maybe_rotate_session(usage, session.plan_config.session_timeout_minutes)

        # Update totals
        usage.period_cost += event.cost_total
        usage.session_cost += event.cost_total
        usage.period_tokens_total += event.total_tokens

        # Update per-model tracking
        if event.model:
            usage.period_tokens_by_model[event.model] = (
                usage.period_tokens_by_model.get(event.model, 0) + event.total_tokens
            )
            usage.period_cost_by_model[event.model] = (
                usage.period_cost_by_model.get(event.model, 0) + event.cost_tokens
            )
    except Exception:
        logger.debug("Failed to update cache after metering", exc_info=True)


# ---------------------------------------------------------------------------
# Reservations (concurrency protection — Scenarios 4 and 5)
# ---------------------------------------------------------------------------


def apply_reservation(
    session: UserState,
    model: str | None,
    cost: float,
    tokens: int,
) -> None:
    """Hold ``cost`` / ``tokens`` against the user's budget for an in-flight call.

    Called AFTER the guard check passes, BEFORE the network LLM call
    begins.  Inflates ``current_usage.reserved_cost`` and
    ``reserved_tokens_by_model[model]`` so subsequent guard checks for
    this user see the pending hold and can't all slip through at a cap
    boundary.

    Caller must hold the per-user lock.  Non-negative values only —
    negative inputs are clamped to 0 to protect against accidental
    float-math underflow.
    """
    try:
        usage = session.current_usage
        if cost > 0:
            usage.reserved_cost += cost
        if tokens > 0 and model:
            usage.reserved_tokens_by_model[model] = (
                usage.reserved_tokens_by_model.get(model, 0) + tokens
            )
    except Exception:
        logger.debug("apply_reservation failed", exc_info=True)


def release_reservation(
    session: UserState,
    model: str | None,
    cost: float,
    tokens: int,
) -> None:
    """Undo a previously-applied reservation without recording any actual usage.

    Called when the LLM call fails (network error, timeout, cancelled
    coroutine) or when post-call metering itself fails.  Subtracts the
    reservation amounts and clamps at 0 so repeated releases can't
    produce negative counters.

    Caller must hold the per-user lock.
    """
    try:
        usage = session.current_usage
        if cost > 0:
            usage.reserved_cost = max(0.0, usage.reserved_cost - cost)
        if tokens > 0 and model:
            current = usage.reserved_tokens_by_model.get(model, 0)
            new = max(0, current - tokens)
            if new == 0:
                usage.reserved_tokens_by_model.pop(model, None)
            else:
                usage.reserved_tokens_by_model[model] = new
    except Exception:
        logger.debug("release_reservation failed", exc_info=True)


def finalize_reservation(
    session: UserState,
    event: UsageEvent,
    reserved_cost: float,
    reserved_tokens: int,
    reservation_model: str | None = None,
) -> None:
    """Release the reservation and apply the actual usage from the response.

    Atomic swap (under lock): subtract the reservation placeholder, add
    the real cost / tokens from the event.  Net effect is the same as
    calling ``update_cache`` would have been without reservations — the
    user's stored usage reflects real spend, not the reservation.

    The ``reservation_model`` arg is the model key that was used at apply
    time.  It MUST match the key under which ``apply_reservation`` stored
    the hold — otherwise we'd try to release under ``event.model``, which
    may differ (e.g. user passed ``gpt-4o-mini``, provider returned
    ``gpt-4o-mini-2024-07-18``) and the hold would leak forever,
    monotonically inflating ``reserved_tokens_by_model[original_key]``
    until legitimate calls start hitting false-positive guard checks.

    For backward compat, if ``reservation_model`` is not supplied we fall
    back to ``event.model``.  New callers should always pass it explicitly.

    Caller must hold the per-user lock.
    """
    release_key = reservation_model if reservation_model is not None else event.model
    release_reservation(session, release_key, reserved_cost, reserved_tokens)
    update_cache(session, event)
