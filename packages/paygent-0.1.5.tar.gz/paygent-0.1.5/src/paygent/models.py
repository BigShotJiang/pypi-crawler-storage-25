"""Pydantic data models for the Paygent SDK.

These models define every data shape in the system: usage events, guard results,
plan configuration, user state, billing periods, and model-level tracking. All
other modules depend on these — they are the foundation of the SDK.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field, PrivateAttr, model_validator


# ---------------------------------------------------------------------------
# Usage Events
# ---------------------------------------------------------------------------


class UsageEvent(BaseModel):
    """A single metered event from an LLM call or tool execution.

    Every event has a unique `id` that serves as an idempotency key — the
    backend will ignore duplicate event IDs during batch ingestion.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    user_id: str
    session_id: str | None = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    model: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    tool_calls: list[str] = Field(default_factory=list)
    cost_tokens: float = 0.0
    cost_tools: float = 0.0
    cost_total: float = 0.0
    metadata: dict = Field(default_factory=dict)
    synced: bool = False


# ---------------------------------------------------------------------------
# Guard Results
# ---------------------------------------------------------------------------


class GuardResult(BaseModel):
    """Result of a guardrail check before an LLM call.

    `status` is one of:
    - "ok"        — within all limits, proceed normally
    - "soft_gate" — approaching a limit, warn but allow
    - "hard_gate" — over a limit, block the call

    `gate_reason` explains which limit was hit:
    - "total_spend"       — monthly spend limit
    - "session_spend"     — per-session spend limit
    - "model_limit:{model}" — per-model token limit (e.g. "model_limit:gpt-4o")
    """

    status: Literal["ok", "soft_gate", "hard_gate"] = "ok"
    gate_reason: str | None = None
    usage_pct: float = 0.0
    current_value: float = 0.0
    limit_value: float = 0.0
    message: str | None = None


# ---------------------------------------------------------------------------
# Model-Level Tracking
# ---------------------------------------------------------------------------


class ModelUsage(BaseModel):
    """Per-model usage snapshot for a single user."""

    model: str
    tokens_used: int = 0
    tokens_limit: int | None = None  # None = unlimited
    cost: float = 0.0


# ---------------------------------------------------------------------------
# Plan Configuration
# ---------------------------------------------------------------------------


class ModelLimitConfig(BaseModel):
    """Token limits for a specific model within a plan."""

    max_tokens_per_period: int | None = None  # None = unlimited

    @model_validator(mode="before")
    @classmethod
    def _remap_old_fields(cls, data: dict) -> dict:
        if isinstance(data, dict) and "max_tokens_per_month" in data:
            data.setdefault("max_tokens_per_period", data.pop("max_tokens_per_month"))
        return data


class ModelCostRate(BaseModel):
    """Cost per 1K tokens for a specific model."""

    input: float   # cost per 1K input tokens
    output: float  # cost per 1K output tokens


class PlanConfig(BaseModel):
    """Full configuration for a billing plan (e.g. Free, Pro).

    Developers define these via the Paygent API or config file upload.
    The SDK receives this on session bootstrap and uses it for guard checks.
    """

    max_spend_per_period: float = float("inf")
    max_spend_per_session: float = float("inf")
    soft_gate_at: float = 0.80
    hard_gate_at: float = 1.00
    model_limits: dict[str, ModelLimitConfig] = Field(default_factory=dict)
    cost_rates: dict[str, ModelCostRate] = Field(default_factory=dict)
    default_cost_rate: ModelCostRate | None = None
    tool_costs: dict[str, float] = Field(default_factory=dict)
    default_tool_cost: float = 0.02
    session_timeout_minutes: float = 30.0
    pre_call_estimate: bool = False
    # Worst-case output-token assumption for pre-call estimation when the
    # caller hasn't specified ``max_tokens``.  Must be large enough to cover
    # realistic unbounded completions so that the estimate doesn't silently
    # under-enforce.  Too small → overruns slip through; too large →
    # legitimate calls get blocked near the edge.  4096 covers most
    # gpt-4o-mini / Claude responses; bump for very long-form workloads.
    pre_call_buffer_tokens: int = 4096
    # Multiplier applied to reservation estimates before they are held
    # during the await window.  Only affects the TEMPORARY hold — the
    # final recorded spend uses the real cost from the response.  A value
    # above 1.0 absorbs tokenizer drift (chars/4 heuristic, missing tool
    # tokens, CJK under-counting) to prevent concurrent-burst overruns at
    # the hard-gate boundary.  Trade-off: higher values cause more
    # false-positive blocks near the cap.  1.2 = 20% headroom is a
    # reasonable middle-ground default.
    reservation_safety_factor: float = 1.2

    @model_validator(mode="before")
    @classmethod
    def _remap_old_fields(cls, data: dict) -> dict:
        if isinstance(data, dict):
            if "max_spend_per_month" in data:
                data.setdefault("max_spend_per_period", data.pop("max_spend_per_month"))
            if "max_tokens_per_month" in data:
                data.setdefault("max_tokens_per_period", data.pop("max_tokens_per_month"))
        return data


# ---------------------------------------------------------------------------
# Current Usage (In-Memory Cache)
# ---------------------------------------------------------------------------


class CurrentUsage(BaseModel):
    """Live usage counters for a user, kept in memory for fast guard checks.

    Updated synchronously after every metered LLM call (dict updates only,
    no I/O). This is the source of truth for guard decisions during a billing
    period.

    Session tracking uses a fixed clock-based window.  ``session_started_at``
    records when the current window opened.  When
    ``now - session_started_at > session_timeout_minutes`` the window expires:
    ``session_cost`` resets to 0 and ``session_id`` rotates so usage events
    can be grouped by session for historical queries.
    """

    period_cost: float = 0.0
    session_cost: float = 0.0
    session_id: str | None = None
    session_started_at: datetime | None = None
    period_tokens_total: int = 0
    period_tokens_by_model: dict[str, int] = Field(default_factory=dict)
    period_cost_by_model: dict[str, float] = Field(default_factory=dict)

    # --- In-flight reservations ---
    # Tentative cost / tokens held for calls currently in their network
    # wait.  Incremented on reserve, decremented on finalize / rollback.
    # Read by the guard check (so concurrent callers can't all slip
    # through a cap boundary).  Typically 0 between calls.  NOT surfaced
    # as "spend" in billing contexts — the finalized cost is what counts.
    reserved_cost: float = 0.0
    reserved_tokens_by_model: dict[str, int] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _remap_old_fields(cls, data: dict) -> dict:
        if isinstance(data, dict):
            if "month_cost" in data:
                data.setdefault("period_cost", data.pop("month_cost"))
            if "month_tokens_total" in data:
                data.setdefault("period_tokens_total", data.pop("month_tokens_total"))
            if "month_tokens_by_model" in data:
                data.setdefault("period_tokens_by_model", data.pop("month_tokens_by_model"))
            if "month_cost_by_model" in data:
                data.setdefault("period_cost_by_model", data.pop("month_cost_by_model"))
        return data


# ---------------------------------------------------------------------------
# Billing Period
# ---------------------------------------------------------------------------


class BillingPeriod(BaseModel):
    """Subscription-anchored billing period.

    Defines the start and end of a billing cycle. Unlike calendar-month
    billing, this supports mid-month signups and arbitrary period lengths.
    The backend determines these dates based on the user's subscription.
    """

    start: datetime
    end: datetime


# ---------------------------------------------------------------------------
# User State (SDK Cache)
# ---------------------------------------------------------------------------


class UserState(BaseModel):
    """Cached state for a user, fetched from backend or loaded from snapshot.

    Contains the user's plan configuration, current usage counters, and
    billing period. The SDK uses this for all guard checks and cache updates.
    Replaces the former UserSession model — "state" better reflects that this
    is cached data, not a lifecycle object.

    Carries a private per-user lock used by the reservation / finalize
    pattern to keep guard-check-and-reserve atomic across concurrent calls
    for the same user.  The lock is NOT serialized (travels as a
    PrivateAttr) so snapshots, merges, and JSON/dict conversions ignore
    it.  Held only for microseconds — never across the await boundary.
    """

    user_id: str
    plan: str
    sdk_enabled: bool = True
    plan_config: PlanConfig
    current_usage: CurrentUsage
    billing_period: BillingPeriod | None = None
    last_refreshed: datetime | None = None

    # Lazy-initialized threading.Lock.  We import inside a default_factory
    # so the models module doesn't pull in threading just for type hints
    # on systems where it isn't needed (mostly hypothetical, but clean).
    _lock: Any = PrivateAttr(default=None)

    @property
    def lock(self):
        """The per-user lock.  Lazy-initialized on first access.

        Used by the reservation pattern — hold while checking the guard
        and applying/releasing reservations, release before the network
        I/O of the LLM call.
        """
        if self._lock is None:
            import threading
            self._lock = threading.Lock()
        return self._lock


# Deprecated alias
UserSession = UserState


# ---------------------------------------------------------------------------
# Remaining Budget Snapshot
# ---------------------------------------------------------------------------


class MaxTokensAdvice(BaseModel):
    """Paygent's recommendation for ``max_tokens`` on the next LLM call.

    Returned by ``pg.get_max_tokens(user_id, model, ...)``.  The dev can
    pass ``advice.max_tokens`` directly as the ``max_tokens`` argument to
    their LLM call and trust that it won't overshoot any configured limit
    (period spend, session spend, or per-model token cap).

    Semantics:
      - ``max_tokens == 0`` means the call WOULD be hard-gated right now —
        the dev should not call; route to a budget-exhausted code path.
      - ``binding_limit`` names which dimension is tightest, so the dev
        can surface an actionable message (``"You're out of gpt-4o quota"``
        vs ``"You've hit your monthly cap"``).
      - ``*_remaining`` fields are diagnostic snapshots for logging /
        quota UIs; they match what ``get_remaining_budget`` returns.

    This is a pure read — no guard callbacks fire, no metering happens.
    """

    max_tokens: int = 0
    binding_limit: Literal[
        "period_spend", "session_spend", "model_tokens", "unbounded", "blocked"
    ] = "unbounded"
    period_spend_remaining: float = float("inf")
    session_spend_remaining: float = float("inf")
    # None = the model has no per-period token cap configured
    model_tokens_remaining: int | None = None


class BudgetRemaining(BaseModel):
    """Multi-dimensional snapshot of how much budget a user has left.

    A single scalar can't capture the full picture: a user might have plenty
    of dollar budget left but have hit a specific model's token cap, or vice
    versa.  This object exposes each dimension separately so callers can pick
    the one they care about, and surfaces ``most_constrained`` for a quick
    one-line answer to "am I close to any limit?".

    Unlimited dimensions use ``float('inf')`` for spend and ``None`` for
    per-model tokens — matching how PlanConfig represents "no limit".
    """

    period_spend_remaining: float = float("inf")
    session_spend_remaining: float = float("inf")
    # Per-model: None = unlimited for that model, int = tokens left.
    # Only models with a configured max_tokens_per_period appear here.
    model_tokens_remaining: dict[str, int | None] = Field(default_factory=dict)
    # Which dimension is closest to its limit.  "unbounded" means no
    # dimension has a finite limit configured.
    most_constrained: Literal[
        "period_spend", "session_spend", "model_tokens", "unbounded"
    ] = "unbounded"
