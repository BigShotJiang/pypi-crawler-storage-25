"""Streaming response wrapper for the Paygent SDK.

When developers use `stream=True` on LLM calls, the response is a generator
(sync) or async generator that yields chunks. We can't extract token counts
until the stream is fully consumed.

The stream wrapper:
1. Yields every chunk from the original stream unchanged (zero latency impact)
2. Accumulates token info from the final chunk (if available) or estimates
3. After the stream ends, fires the on_complete callback for metering

Both OpenAI and Anthropic include usage info in the final chunk (or via
`stream_options={"include_usage": True}` for OpenAI).
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Callable, Iterator

from paygent.providers import TokenInfo

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Sync Stream Wrapper
# ---------------------------------------------------------------------------


class StreamWrapper:
    """Wraps a sync streaming response to capture usage after completion.

    Yields all chunks unchanged. After the stream ends, invokes the
    on_complete callback with extracted TokenInfo.

    Usage:
        wrapped = StreamWrapper(original_stream, on_complete=meter_callback)
        for chunk in wrapped:
            process(chunk)  # identical to original stream
        # After loop: metering fires automatically
    """

    def __init__(
        self,
        stream: Iterator,
        on_complete: Callable[[TokenInfo, list], None],
        extract_stream_tokens: Callable[[list], TokenInfo] | None = None,
    ) -> None:
        self._stream = stream
        self._on_complete = on_complete
        self._extract_stream_tokens = extract_stream_tokens or _default_stream_extractor
        self._chunks: list = []
        self._completed = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._finalize()
            raise

    def _finalize(self) -> None:
        """Extract tokens and fire callback after stream ends."""
        if self._completed:
            return
        self._completed = True

        try:
            token_info = self._extract_stream_tokens(self._chunks)
            self._on_complete(token_info, self._chunks)
        except Exception:
            logger.debug("Stream finalization failed", exc_info=True)

    def __enter__(self):
        """Support `with` statement (OpenAI streams are context managers)."""
        return self

    def __exit__(self, *args):
        """Ensure finalization on context manager exit."""
        self._finalize()
        # Close the original stream if it has a close method
        if hasattr(self._stream, "close"):
            try:
                self._stream.close()
            except Exception:
                pass

    def close(self):
        """Close the stream and finalize."""
        self._finalize()
        if hasattr(self._stream, "close"):
            try:
                self._stream.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Async Stream Wrapper
# ---------------------------------------------------------------------------


class AsyncStreamWrapper:
    """Wraps an async streaming response to capture usage after completion.

    Yields all chunks unchanged. After the stream ends, invokes the
    on_complete callback with extracted TokenInfo.
    """

    def __init__(
        self,
        stream: AsyncIterator,
        on_complete: Callable[[TokenInfo, list], None],
        extract_stream_tokens: Callable[[list], TokenInfo] | None = None,
    ) -> None:
        self._stream = stream
        self._on_complete = on_complete
        self._extract_stream_tokens = extract_stream_tokens or _default_stream_extractor
        self._chunks: list = []
        self._completed = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            chunk = await self._stream.__anext__()
            self._chunks.append(chunk)
            return chunk
        except StopAsyncIteration:
            self._finalize()
            raise

    def _finalize(self) -> None:
        if self._completed:
            return
        self._completed = True

        try:
            token_info = self._extract_stream_tokens(self._chunks)
            self._on_complete(token_info, self._chunks)
        except Exception:
            logger.debug("Async stream finalization failed", exc_info=True)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        self._finalize()
        if hasattr(self._stream, "aclose"):
            try:
                await self._stream.aclose()
            except Exception:
                pass

    async def aclose(self):
        self._finalize()
        if hasattr(self._stream, "aclose"):
            try:
                await self._stream.aclose()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Token Extractors for Streaming
# ---------------------------------------------------------------------------


def _default_stream_extractor(chunks: list) -> TokenInfo:
    """Default extractor: tries to find usage in the last chunk.

    Both OpenAI (with stream_options) and Anthropic include a final
    message with usage data.
    """
    if not chunks:
        return TokenInfo()

    # Try the last chunk first (most common location)
    last = chunks[-1]
    info = _extract_from_chunk(last)
    if info.total_tokens > 0 or info.input_tokens > 0:
        return info

    # Fallback: scan all chunks for a usage summary
    for chunk in reversed(chunks):
        info = _extract_from_chunk(chunk)
        if info.total_tokens > 0 or info.input_tokens > 0:
            return info

    # No usage data found — try to get at least the model name
    model = None
    for chunk in chunks[:3]:  # Model usually in first few chunks
        model = getattr(chunk, "model", None)
        if model is None and isinstance(chunk, dict):
            model = chunk.get("model")
        if model:
            break

    return TokenInfo(model=model)


def _extract_from_chunk(chunk: Any) -> TokenInfo:
    """Try to extract usage info from a single stream chunk."""
    try:
        usage = getattr(chunk, "usage", None)
        if usage is None and isinstance(chunk, dict):
            usage = chunk.get("usage")

        if usage is None:
            return TokenInfo()

        model = getattr(chunk, "model", None) or (
            chunk.get("model") if isinstance(chunk, dict) else None
        )

        if isinstance(usage, dict):
            input_t = usage.get("prompt_tokens") or usage.get("input_tokens") or 0
            output_t = usage.get("completion_tokens") or usage.get("output_tokens") or 0
        else:
            input_t = getattr(usage, "prompt_tokens", 0) or getattr(usage, "input_tokens", 0) or 0
            output_t = getattr(usage, "completion_tokens", 0) or getattr(usage, "output_tokens", 0) or 0

        return TokenInfo(
            model=model,
            input_tokens=input_t,
            output_tokens=output_t,
            total_tokens=input_t + output_t,
        )
    except Exception:
        return TokenInfo()


# ---------------------------------------------------------------------------
# OpenAI-specific stream extractor
# ---------------------------------------------------------------------------


def extract_openai_stream_tokens(chunks: list) -> TokenInfo:
    """Extract tokens from an OpenAI streaming response.

    OpenAI includes usage in the final chunk when `stream_options={"include_usage": True}`.
    Falls back to default extraction.
    """
    return _default_stream_extractor(chunks)


# ---------------------------------------------------------------------------
# Anthropic-specific stream extractor
# ---------------------------------------------------------------------------


def extract_anthropic_stream_tokens(chunks: list) -> TokenInfo:
    """Extract tokens from an Anthropic streaming response.

    Anthropic's message_start event contains input_tokens, and
    message_delta contains output_tokens. We must scan all chunks
    to collect both pieces (they arrive in separate events).
    """
    if not chunks:
        return TokenInfo()

    model = None
    input_tokens = 0
    output_tokens = 0
    found_anthropic_events = False

    for chunk in chunks:
        event_type = getattr(chunk, "type", None)

        if event_type == "message_start":
            found_anthropic_events = True
            message = getattr(chunk, "message", None)
            if message:
                usage = getattr(message, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "input_tokens", 0) or 0
                if not model:
                    model = getattr(message, "model", None)

        elif event_type == "message_delta":
            found_anthropic_events = True
            usage = getattr(chunk, "usage", None)
            if usage:
                output_tokens = getattr(usage, "output_tokens", 0) or 0

        # Get model from any chunk that has it
        if not model:
            model = getattr(chunk, "model", None)

    # If we found Anthropic-style events, use the accumulated values
    if found_anthropic_events:
        return TokenInfo(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        )

    # Fallback: try generic extraction from last chunk
    return _default_stream_extractor(chunks)
