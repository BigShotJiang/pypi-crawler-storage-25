"""Contextvars-based user identity for Paygent.

The SDK needs to know which user is making an LLM call so it can:
- Apply the right guardrails (check their plan limits)
- Attribute metered usage to the correct user
- Track per-session costs

This module provides two ways to set user context:

1. Context manager:
    with paygent_context(user_id="user_123"):
        # All LLM calls here are tracked for user_123
        response = openai.chat.completions.create(...)

2. Decorator:
    @paygent_track(user_id="user_123")
    def handle_request(query):
        return openai.chat.completions.create(...)

The monkey-patched LLM methods read the current user from contextvars.
If no user context is set, Paygent skips all tracking (fail-open).
"""

from __future__ import annotations

import functools
import logging
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Context Data
# ---------------------------------------------------------------------------


@dataclass
class PaygentContext:
    """Identity and session info for the current LLM call context."""

    user_id: str
    session_id: str | None = None
    plan: str | None = None
    metadata: dict[str, Any] | None = None


# The contextvar that holds the current user's context.
# None means no Paygent context is active — all tracking is skipped.
_current_context: ContextVar[PaygentContext | None] = ContextVar(
    "paygent_context", default=None
)


# ---------------------------------------------------------------------------
# Read Context (used by patcher/instrumentor)
# ---------------------------------------------------------------------------


def get_current_context() -> PaygentContext | None:
    """Get the current Paygent context, or None if not set.

    This is called by the monkey-patched LLM methods to determine
    which user to track. Returns None if no context is active,
    which signals the patcher to skip all Paygent logic (fail-open).
    """
    return _current_context.get()


# ---------------------------------------------------------------------------
# Context Manager
# ---------------------------------------------------------------------------


@contextmanager
def paygent_context(
    user_id: str,
    session_id: str | None = None,
    plan: str | None = None,
    metadata: dict[str, Any] | None = None,
):
    """Set the Paygent user context for all LLM calls within this block.

    Usage:
        with paygent_context(user_id="user_123"):
            response = openai.chat.completions.create(...)
            # ^ automatically tracked for user_123

    Args:
        user_id: The unique identifier for the end user.
        session_id: Optional session identifier for per-session tracking.
        plan: Optional plan name override. If not set, the SDK uses the
              plan from the cached session data.
        metadata: Optional key-value pairs attached to usage events.
    """
    ctx = PaygentContext(
        user_id=user_id,
        session_id=session_id,
        plan=plan,
        metadata=metadata,
    )
    token = _current_context.set(ctx)
    try:
        yield ctx
    finally:
        _current_context.reset(token)


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------


def paygent_track(
    user_id: str | None = None,
    session_id: str | None = None,
    plan: str | None = None,
    metadata: dict[str, Any] | None = None,
    *,
    user_id_param: str | None = None,
) -> Callable:
    """Decorator that wraps a function with Paygent user context.

    Usage (static user_id):
        @paygent_track(user_id="user_123")
        def handle_request(query):
            return openai.chat.completions.create(...)

    Usage (dynamic user_id from function argument):
        @paygent_track(user_id_param="user_id")
        def handle_request(user_id: str, query: str):
            return openai.chat.completions.create(...)

    Args:
        user_id: Static user ID to use for all calls.
        session_id: Optional static session ID.
        plan: Optional plan name override.
        metadata: Optional metadata dict.
        user_id_param: Name of the function parameter that contains the user ID.
            If set, `user_id` is ignored and the value is read dynamically from
            the decorated function's arguments at call time.
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            resolved_user_id = _resolve_user_id(
                func, args, kwargs, user_id, user_id_param
            )
            if resolved_user_id is None:
                logger.warning(
                    "paygent_track: could not resolve user_id for %s, "
                    "skipping tracking",
                    func.__name__,
                )
                return func(*args, **kwargs)

            with paygent_context(
                user_id=resolved_user_id,
                session_id=session_id,
                plan=plan,
                metadata=metadata,
            ):
                return func(*args, **kwargs)

        return wrapper

    return decorator


def _resolve_user_id(
    func: Callable,
    args: tuple,
    kwargs: dict,
    static_user_id: str | None,
    user_id_param: str | None,
) -> str | None:
    """Resolve the user_id from either static value or function arguments.

    Returns None if resolution fails (fail-open: caller should skip tracking).
    """
    if user_id_param is not None:
        # Try kwargs first
        if user_id_param in kwargs:
            return str(kwargs[user_id_param])

        # Try positional args by inspecting function signature
        try:
            import inspect

            sig = inspect.signature(func)
            params = list(sig.parameters.keys())
            idx = params.index(user_id_param)
            if idx < len(args):
                return str(args[idx])
        except (ValueError, IndexError):
            pass

        logger.debug(
            "paygent_track: user_id_param='%s' not found in arguments for %s",
            user_id_param,
            func.__name__,
        )
        return None

    return static_user_id
