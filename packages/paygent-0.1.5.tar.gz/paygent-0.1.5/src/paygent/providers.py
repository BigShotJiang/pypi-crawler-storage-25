"""Provider registry for LLM providers (OpenAI, Anthropic).

Each provider has:
- A way to identify which module/class to monkey-patch
- A token extractor that pulls token counts from the LLM response
- A model name extractor

The registry is the single source of truth for how Paygent understands
different LLM providers. Adding a new provider means adding one entry here.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable

logger = logging.getLogger("paygent")


# ---------------------------------------------------------------------------
# Token Extraction Result
# ---------------------------------------------------------------------------


@dataclass
class TokenInfo:
    """Extracted token information from an LLM response."""

    model: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0


# ---------------------------------------------------------------------------
# Provider Definition
# ---------------------------------------------------------------------------


@dataclass
class ProviderConfig:
    """Configuration for a single LLM provider.

    Attributes:
        name: Human-readable provider name (e.g. "openai", "anthropic").
        module_path: The Python module that contains the client class
            (e.g. "openai.resources.chat.completions").
        class_name: The class to monkey-patch (e.g. "Completions").
        method_name: The sync method to wrap (e.g. "create").
        async_method_name: The async method to wrap (e.g. "create" on AsyncCompletions).
        async_class_name: The async class to monkey-patch.
        async_module_path: Module path for the async class (if different from sync).
        extract_tokens: Callable that takes the raw LLM response and returns TokenInfo.
    """

    name: str
    module_path: str
    class_name: str
    method_name: str
    async_class_name: str | None = None
    async_module_path: str | None = None
    async_method_name: str | None = None
    extract_tokens: Callable[[Any], TokenInfo] = field(default=lambda: _noop_extractor)


def _noop_extractor(response: Any) -> TokenInfo:
    """Fallback extractor when no provider-specific logic exists."""
    return TokenInfo()


def _unwrap_raw_response(response: Any) -> Any:
    """Unwrap raw-response envelopes (e.g. openai's LegacyAPIResponse / APIResponse).

    When a caller goes through ``client.chat.completions.with_raw_response.create``
    (which langchain-openai does by default to access response headers), the
    returned object is a LegacyAPIResponse / APIResponse that defers body parsing
    until ``.parse()`` is called.  The envelope itself has no ``.usage`` /
    ``.model`` attributes, so token extraction sees zeros.

    This helper detects the envelope pattern (a ``.parse()`` method with no
    ``.usage`` attribute) and calls ``.parse()`` to get the real response
    object.  Returns the original response unchanged if it isn't an envelope.

    Fails silently — any error returns the original response.
    """
    try:
        if hasattr(response, "parse") and not hasattr(response, "usage"):
            return response.parse()
    except Exception:
        logger.debug("Failed to unwrap raw response envelope", exc_info=True)
    return response


# ---------------------------------------------------------------------------
# OpenAI Token Extractor
# ---------------------------------------------------------------------------


def extract_openai_tokens(response: Any) -> TokenInfo:
    """Extract token info from an OpenAI ChatCompletion response.

    Works with both openai>=1.0 (pydantic model) and dict responses.
    Fails gracefully — returns empty TokenInfo on any error.
    """
    try:
        # Unwrap raw-response envelopes (langchain-openai uses
        # with_raw_response.create by default).
        response = _unwrap_raw_response(response)

        # openai>=1.0 returns a pydantic-like object
        usage = getattr(response, "usage", None)
        if usage is None and isinstance(response, dict):
            usage = response.get("usage")

        if usage is None:
            model = getattr(response, "model", None) or (
                response.get("model") if isinstance(response, dict) else None
            )
            return TokenInfo(model=model)

        # Extract from object or dict
        # OpenAI SDK historically uses prompt_tokens/completion_tokens,
        # but newer versions (v1.50+) may use input_tokens/output_tokens.
        # Check both, preferring the newer names.
        if isinstance(usage, dict):
            input_tokens = (
                usage.get("input_tokens")
                or usage.get("prompt_tokens")
                or 0
            )
            output_tokens = (
                usage.get("output_tokens")
                or usage.get("completion_tokens")
                or 0
            )
            total_tokens = usage.get("total_tokens", 0) or (input_tokens + output_tokens)
        else:
            input_tokens = (
                getattr(usage, "input_tokens", None)
                or getattr(usage, "prompt_tokens", None)
                or 0
            )
            output_tokens = (
                getattr(usage, "output_tokens", None)
                or getattr(usage, "completion_tokens", None)
                or 0
            )
            total_tokens = getattr(usage, "total_tokens", 0) or (input_tokens + output_tokens)

        model = getattr(response, "model", None) or (
            response.get("model") if isinstance(response, dict) else None
        )

        return TokenInfo(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
        )
    except Exception:
        logger.debug("Failed to extract OpenAI tokens", exc_info=True)
        return TokenInfo()


# ---------------------------------------------------------------------------
# Anthropic Token Extractor
# ---------------------------------------------------------------------------


def extract_anthropic_tokens(response: Any) -> TokenInfo:
    """Extract token info from an Anthropic Messages response.

    Works with anthropic>=0.18 (pydantic model) and dict responses.
    Fails gracefully — returns empty TokenInfo on any error.
    """
    try:
        # Unwrap raw-response envelopes, same pattern as OpenAI.
        response = _unwrap_raw_response(response)

        usage = getattr(response, "usage", None)
        if usage is None and isinstance(response, dict):
            usage = response.get("usage")

        if usage is None:
            model = getattr(response, "model", None) or (
                response.get("model") if isinstance(response, dict) else None
            )
            return TokenInfo(model=model)

        if isinstance(usage, dict):
            input_tokens = usage.get("input_tokens", 0) or 0
            output_tokens = usage.get("output_tokens", 0) or 0
        else:
            input_tokens = getattr(usage, "input_tokens", 0) or 0
            output_tokens = getattr(usage, "output_tokens", 0) or 0

        total_tokens = input_tokens + output_tokens

        model = getattr(response, "model", None) or (
            response.get("model") if isinstance(response, dict) else None
        )

        return TokenInfo(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
        )
    except Exception:
        logger.debug("Failed to extract Anthropic tokens", exc_info=True)
        return TokenInfo()


# ---------------------------------------------------------------------------
# Provider Registry
# ---------------------------------------------------------------------------


# Default provider configs. The patcher uses these to know what to monkey-patch.
OPENAI_PROVIDER = ProviderConfig(
    name="openai",
    module_path="openai.resources.chat.completions",
    class_name="Completions",
    method_name="create",
    async_module_path="openai.resources.chat.completions",
    async_class_name="AsyncCompletions",
    async_method_name="create",
    extract_tokens=extract_openai_tokens,
)

ANTHROPIC_PROVIDER = ProviderConfig(
    name="anthropic",
    module_path="anthropic.resources.messages",
    class_name="Messages",
    method_name="create",
    async_module_path="anthropic.resources.messages",
    async_class_name="AsyncMessages",
    async_method_name="create",
    extract_tokens=extract_anthropic_tokens,
)


class ProviderRegistry:
    """Registry of all known LLM providers.

    The SDK uses this to discover which modules to monkey-patch and how
    to extract tokens from each provider's response format.
    """

    def __init__(self) -> None:
        self._providers: dict[str, ProviderConfig] = {}

    def register(self, config: ProviderConfig) -> None:
        """Register a provider configuration."""
        self._providers[config.name] = config
        logger.debug("Registered provider: %s", config.name)

    def get(self, name: str) -> ProviderConfig | None:
        """Get a provider by name, or None if not registered."""
        return self._providers.get(name)

    def all(self) -> list[ProviderConfig]:
        """Return all registered providers."""
        return list(self._providers.values())

    @property
    def names(self) -> list[str]:
        """Return all registered provider names."""
        return list(self._providers.keys())


def create_default_registry() -> ProviderRegistry:
    """Create a registry with all built-in providers (OpenAI, Anthropic)."""
    registry = ProviderRegistry()
    registry.register(OPENAI_PROVIDER)
    registry.register(ANTHROPIC_PROVIDER)
    return registry
