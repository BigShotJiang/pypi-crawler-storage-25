"""Metadata discovery for AAuth."""

