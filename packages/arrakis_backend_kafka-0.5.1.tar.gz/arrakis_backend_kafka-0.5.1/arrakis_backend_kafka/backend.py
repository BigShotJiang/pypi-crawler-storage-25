# Copyright (c) 2022, California Institute of Technology and contributors
#
# You should have received a copy of the licensing terms for this
# software included in the file "LICENSE" located in the top-level
# directory of this package. If you did not, you can view a copy at
# https://git.ligo.org/ngdd/arrakis-server/-/raw/main/LICENSE

from __future__ import annotations

import argparse
import logging
import threading
from collections.abc import Iterable, Iterator
from dataclasses import replace
from pathlib import Path

import pyarrow
import pyarrow.compute
from arrakis import Channel
from arrakis.block import SeriesBlock
from arrakis.kafka import KafkaReader
from arrakis.mux import BlockMuxStream
from arrakis_server import errors
from arrakis_server.metadata import ChannelConfigBackend, is_publisher_config
from arrakis_server.partition import partition_channels
from arrakis_server.scope import Retention, ScopeInfo
from arrakis_server.traits import PublishServerBackend
from platformdirs import user_cache_dir

logger = logging.getLogger("arrakis")


class KafkaBackend(PublishServerBackend):
    """Backend serving timeseries data from Kafka."""

    def __init__(
        self, kafka_url: str, publisher_configs: list[Path] | None, retention_time: int
    ):
        self.kafka_url = kafka_url
        logger.info("kafka URL: %s", self.kafka_url)

        # cache file for self-updating publishers
        # FIXME: how better to manage who can do this
        cache_dir = Path(user_cache_dir("arrakis", "server"))
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / "metadata.toml"
        logger.info("channel cache file: %s", cache_file)

        # load publisher channels
        self.metadata = ChannelConfigBackend(
            cache_file=cache_file,
            enforce=["publisher", "partition_id", "stride", "max_latency"],
        )
        if publisher_configs:
            # expand directories to individual TOML files
            expanded: list[Path] = []
            for pconf in publisher_configs:
                if pconf.is_dir():
                    files = sorted(pconf.glob("*.toml"))
                    if not files:
                        raise FileNotFoundError(
                            f"no .toml files found in directory '{pconf}'"
                        )
                    expanded.extend(files)
                else:
                    expanded.append(pconf)

            for pconf in expanded:
                if not is_publisher_config(pconf):
                    raise ValueError(
                        f"publisher config '{pconf}' is missing the required "
                        "[publisher] section"
                    )
                logger.info("loading publisher config: %s", pconf)
                added = self.metadata.load(
                    pconf,
                    overwrite=True,
                )
                if logger.getEffectiveLevel() <= logging.DEBUG:
                    for channel in added:
                        assert channel.partition_id is not None, (
                            f"channel {channel.name} does not include partition_id"
                        )
                        assert channel.partition_index is not None, (
                            f"channel {channel.name} does not include partition_index"
                        )
                        assert channel.stride
                        assert channel.stride < 60_000_000_000, (
                            f"channel {channel.name} stride >60s"
                        )
                        assert channel.max_latency
                        assert channel.max_latency < 60_000_000_000, (
                            f"channel {channel.name} max_latency >60s"
                        )
                        logger.debug(
                            (
                                "  %s: %s %d %s partition_id=%s "
                                "stride=%sns max_latency=%sns"
                            ),
                            channel.publisher,
                            channel.name,
                            channel.sample_rate,
                            channel.data_type,
                            channel.partition_id,
                            channel.stride,
                            channel.max_latency,
                        )

        self._channels = set(self.metadata.metadata.values())

        retention = Retention(oldest=retention_time)
        self.scope_info = ScopeInfo(self.metadata.scopes, retention)

        # lock used for updating partition table
        self._lock = threading.Lock()

        # Optimize Arrow threading for concurrent client serving
        # single-threaded Arrow operations reduce thread pool contention
        # when serving many concurrent clients
        pyarrow.set_cpu_count(1)

        # Set global memory pool for all Arrow operations across all connections
        optimal_pool = self._get_optimal_memory_pool()
        pyarrow.set_memory_pool(optimal_pool)

    def _get_optimal_memory_pool(self):
        """Select best available memory pool for Arrow operations"""
        # Try high-performance allocators optimized for concurrent workloads
        try:
            pool = pyarrow.jemalloc_memory_pool()
            logger.info("Set jemalloc memory pool for Arrow operations")
            # Set 5 second decay time for dirty/muzzy pages from creation to purge
            # Optimized for batch processing cycles (~100ms) with memory retention
            # see: https://jemalloc.net/jemalloc.3.html#opt.dirty_decay_ms
            pyarrow.jemalloc_set_decay_ms(5000)
            return pool
        except NotImplementedError:
            pass

        try:
            pool = pyarrow.mimalloc_memory_pool()
            logger.info("Set mimalloc memory pool for Arrow operations")
            return pool
        except NotImplementedError:
            pass

        # Fallback to default system pool
        logger.info("Set default memory pool for Arrow operations")
        return pyarrow.default_memory_pool()

    @staticmethod
    def add_arguments(parser):
        parser.add_argument(
            "--kafka-url",
            type=str,
            metavar="URL",
            required=True,
            help="URL pointing to a running kafka pool",
        )
        parser.add_argument(
            "--publisher-config",
            dest="publisher_configs",
            type=Path,
            metavar="PATH",
            action="append",
            help="path to publisher config TOML file or directory",
        )
        parser.add_argument(
            "--retention-time",
            type=int,
            default=900,
            help="Set the data retention stored in Kafka. Default is 900 seconds.",
        )

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> KafkaBackend:
        return cls(
            kafka_url=args.kafka_url,
            publisher_configs=args.publisher_configs,
            retention_time=args.retention_time,
        )

    def find(
        self,
        *,
        pattern: str,
        data_type: list[str],
        min_rate: int,
        max_rate: int,
        publisher: list[str],
    ) -> Iterable[Channel]:
        """Retrieve metadata for the 'find' route."""
        assert isinstance(self.metadata, ChannelConfigBackend)
        return self.metadata.find(
            pattern=pattern,
            data_type=data_type,
            min_rate=min_rate,
            max_rate=max_rate,
            publisher=publisher,
        )

    def describe(self, *, channels: Iterable[str]) -> Iterable[Channel]:
        """Retrieve metadata for the 'find' route."""
        assert isinstance(self.metadata, ChannelConfigBackend)
        return self.metadata.describe(channels=channels)

    def stream(
        self, *, channels: Iterable[str], start: int, end: int
    ) -> Iterator[SeriesBlock]:
        """Retrieve timeseries data for the 'stream' route."""
        assert isinstance(self.metadata, ChannelConfigBackend)
        # query for channel metadata
        metadata = {channel: self.metadata.metadata[channel] for channel in channels}

        if not self.retention.in_range(start) or not self.retention.in_range(end):
            raise errors.TimeRangeUnavailableError(start, end)

        streamer = KafkaReader(
            self.kafka_url,
            metadata,
            start,
        )

        mux: BlockMuxStream = BlockMuxStream(
            streamer,
            start=start,
        )

        for block in mux.stream(end):
            yield block

    def publish(self, *, publisher_id: str) -> dict[str, str]:
        """Retrieve connection info for the 'publish' route."""
        # FIXME: incorporate the producer ID with auth verification
        return {"bootstrap.servers": self.kafka_url}

    def partition(
        self, *, publisher_id: str, channels: Iterable[Channel]
    ) -> Iterable[Channel]:
        assert isinstance(self.metadata, ChannelConfigBackend)

        pub_info = self.metadata.get_publisher_info(publisher_id)
        if pub_info is None:
            raise errors.PublisherUnknownError(publisher_id)
        if not pub_info.dynamic:
            raise errors.PublisherNotDynamicError(publisher_id)

        # apply publisher-level defaults to incoming channels
        channels = [
            replace(
                channel,
                stride=pub_info.stride,
                max_latency=pub_info.max_latency,
            )
            for channel in channels
        ]

        # assign any new partitions
        changed = set(channels) - self._channels
        if changed:
            partitioned = partition_channels(
                list(changed),
                metadata=self.metadata.metadata,
                partition_metadata=self.metadata.partition_metadata,
                publisher=publisher_id,
            )
            with self._lock:
                self.metadata.update(
                    partitioned,
                    partition_metadata=self.metadata.partition_metadata,
                    overwrite=True,
                )
                self.channels = {channel for channel in self.metadata.metadata.values()}
                # always limit our response to the input list.
                # always send something so that the partition field is set
                channels = [
                    self.metadata.metadata[channel.name] for channel in channels
                ]

        return channels
