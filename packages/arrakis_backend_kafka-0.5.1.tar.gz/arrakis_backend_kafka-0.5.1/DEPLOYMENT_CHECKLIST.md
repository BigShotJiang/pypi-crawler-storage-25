# Consumer Manager Deployment Checklist

## Pre-Deployment

### 1. Increase podman pids limit ✓
```bash
# Edit your podman run command or systemd service
--pids-limit=65536
```

### 2. Review system resources
```bash
# Check available memory (each client uses ~100MB for queues)
free -h

# Check current thread count
ps -eLf | wc -l

# Check Kafka connectivity
nc -zv <kafka-host> <kafka-port>
```

### 3. Backup current configuration
```bash
# Backup service file
sudo cp /etc/systemd/system/arrakis-server-kafka.service /etc/systemd/system/arrakis-server-kafka.service.bak

# Note current git commit
git log -1 --oneline
```

## Deployment Steps

### 1. Pull/update code
```bash
cd /home/olivia/workspace/projects/ligo/ngdd/arrakis-backend-kafka
git pull  # or copy files if not in git
```

### 2. Verify new files exist
```bash
ls -la arrakis_backend_kafka/consumer_manager.py
# Should see the new file
```

### 3. Test import (catches syntax errors)
```bash
python3 -c "from arrakis_backend_kafka.consumer_manager import get_consumer_manager; print('OK')"
```

### 4. Update podman pids limit
```bash
# If using systemd service:
sudo systemctl edit arrakis-server-kafka

# Add (or edit existing):
# [Service]
# ExecStart=  # Clear existing
# ExecStart=/usr/bin/podman run --pids-limit=65536 ...

# Or edit your docker-compose.yml / podman command directly
```

### 5. Restart service
```bash
sudo systemctl daemon-reload
sudo systemctl restart arrakis-server-kafka

# Verify it started
sudo systemctl status arrakis-server-kafka
```

### 6. Monitor logs
```bash
# Watch for ConsumerManager initialization
sudo journalctl -u arrakis-server-kafka -f

# Look for:
# "ConsumerManager initialized for <kafka-url>"
# "Started consumer for partition <id>"
```

## Post-Deployment Verification

### 1. Check thread count
```bash
# Should be ~10-30 threads regardless of client count
ps -eLf | grep arrakis-server-kafka | wc -l
```

### 2. Connect test client
```bash
# Use arrakis-python client to connect
python3 -c "
from arrakis import Client
client = Client('grpc://<server>:50051')
channels = client.find('*')
print(f'Found {len(channels)} channels')
"
```

### 3. Load test with multiple clients
```bash
# Run N clients in parallel
for i in {1..50}; do
    python3 test_client.py &
done

# Monitor thread count - should stay low
watch -n 1 "ps -eLf | grep arrakis-server-kafka | wc -l"
```

### 4. Check for errors
```bash
# Look for warnings/errors in logs
sudo journalctl -u arrakis-server-kafka -p warning --since "5 minutes ago"

# Common warnings to expect (OK):
# "Client stream queue full, dropping block" - slow client, normal backpressure

# Errors to investigate:
# "Error processing message on partition X" - Kafka/deserialization issue
# "Error reading from stream" - Client connection issue
```

### 5. Profile again (optional)
```bash
# Compare with previous profile
sudo /home/olivia.godwin/workspace/venv/arrakis-server/bin/py-spy record \
    --native --rate 20 -o /tmp/profile_after.svg \
    --pid $(pgrep -f arrakis-server-kafka)

# Run for 30-60 seconds with load, then Ctrl+C
```

## Monitoring Metrics

### Key indicators of success:

1. **Thread count**: Should be ~10-30, not 1000+
   ```bash
   ps -eLf | grep arrakis-server-kafka | wc -l
   ```

2. **No "Unable to create broker thread" errors**
   ```bash
   sudo journalctl -u arrakis-server-kafka | grep "Unable to create"
   # Should be empty
   ```

3. **Clients connecting successfully**
   ```bash
   # Monitor active connections (if you have metrics)
   # Or check logs for "Client subscribed to N partitions"
   sudo journalctl -u arrakis-server-kafka | grep "Client subscribed"
   ```

4. **CPU usage**: Should be lower or similar
   ```bash
   top -p $(pgrep -f arrakis-server-kafka)
   ```

5. **Memory usage**: May be slightly higher (queues), but stable
   ```bash
   ps aux | grep arrakis-server-kafka
   ```

## Rollback Procedure

If issues occur:

### 1. Quick rollback (restore old code)
```bash
cd /home/olivia/workspace/projects/ligo/ngdd/arrakis-backend-kafka
git revert <commit-hash>  # or restore backup

sudo systemctl restart arrakis-server-kafka
```

### 2. Verify rollback
```bash
# Thread count should go back up (per-client consumers)
ps -eLf | grep arrakis-server-kafka | wc -l
```

## Known Issues & Workarounds

### Issue: Historical data seeking
**Symptom**: Clients requesting old data (start time in past) may not receive correct data

**Workaround**: For now, this optimization is best for live streaming. Historical queries may need to use the old implementation.

**Fix**: Coming in follow-up PR

### Issue: Many consumer groups in Kafka
**Symptom**: Kafka shows many consumer groups `arrakis-manager-*`

**Impact**: Minimal - each partition gets one consumer group

**Workaround**: None needed, but monitor Kafka consumer group count

### Issue: High memory usage with many slow clients
**Symptom**: Memory grows with client count (100MB per client)

**Workaround**:
- Set queue size lower in `consumer_manager.py` line 434: `queue.Queue(maxsize=50)`
- Monitor "queue full" warnings - if frequent, clients are too slow

## Success Criteria

- ✅ Server starts without errors
- ✅ Thread count is <100 with 300+ clients
- ✅ No "Unable to create broker thread" errors
- ✅ Clients can connect and receive data
- ✅ No crashes or deadlocks after 1 hour of operation

## Support

If issues occur:
1. Check logs: `sudo journalctl -u arrakis-server-kafka -n 1000`
2. Check thread count and memory
3. Collect profile if CPU high
4. Rollback if critical
5. Report issues with logs and profile data
