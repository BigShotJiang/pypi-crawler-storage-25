#!/usr/bin/env python3
"""Diagnostic script to read raw Kafka messages for a single channel
and report per-block timestamps and latency.

Bypasses the muxer entirely to isolate whether gaps are from Kafka
delivery latency or from the mux/timeout machinery.

Usage:
    python debug_kafka_latency.py \
        --kafka-url arrakis-kafka1:9092 \
        --metadata /path/to/metadata.toml \
        --channel "H1:CAL-PCALY_OFS_ERR_SWREQ" \
        --duration 30
"""

import argparse
import time
from pathlib import Path

import gpstime
import numpy
from arrakis.block import Time, time_as_ns
from arrakis.kafka import KafkaReader
from arrakis_server.metadata import ChannelConfigBackend


def main():
    parser = argparse.ArgumentParser(description="Debug Kafka latency for a channel")
    parser.add_argument("--kafka-url", required=True, help="Kafka broker URL")
    parser.add_argument(
        "--metadata",
        type=Path,
        required=True,
        help="Path to metadata TOML (cache file or publisher config)",
    )
    parser.add_argument("--channel", required=True, help="Channel name to diagnose")
    parser.add_argument(
        "--duration",
        type=float,
        default=30,
        help="How long to listen in seconds (default: 30)",
    )
    args = parser.parse_args()

    # load channel metadata
    backend = ChannelConfigBackend()
    backend.load(args.metadata)

    if args.channel not in backend.metadata:
        print(f"ERROR: channel '{args.channel}' not found in loaded metadata")
        print(f"Available channels ({len(backend.metadata)}):")
        for name in sorted(backend.metadata.keys())[:20]:
            print(f"  {name}")
        if len(backend.metadata) > 20:
            print(f"  ... and {len(backend.metadata) - 20} more")
        return

    channel = backend.metadata[args.channel]
    metadata = {args.channel: channel}

    print(f"Channel:         {channel.name}")
    print(f"Sample rate:     {channel.sample_rate} Hz")
    print(f"Data type:       {channel.data_type}")
    print(f"Partition ID:    {channel.partition_id}")
    print(f"Partition index: {channel.partition_index}")
    print(
        f"Stride:          {channel.stride} ns ({channel.stride / Time.SECONDS:.4f} s)"
    )
    print(
        f"Max latency:     {channel.max_latency} ns ({channel.max_latency / Time.SECONDS:.4f} s)"
    )
    print(f"Kafka URL:       {args.kafka_url}")
    print(f"Kafka topic:     arrakis-{channel.partition_id}")
    print()

    now_gps = gpstime.gpsnow()
    start_ns = time_as_ns(now_gps)
    print(f"Starting at GPS {now_gps:.1f} for {args.duration}s")
    print(f"{'=' * 80}")

    reader = KafkaReader(args.kafka_url, metadata, start=start_ns)
    reader.enter()

    block_count = 0
    gap_count = 0
    latencies = []
    last_block_time = None
    wall_start = time.monotonic()

    try:
        while (time.monotonic() - wall_start) < args.duration:
            for stream_id, block in reader.read(convert_blocks=True):
                wall_now = time.monotonic()
                elapsed = wall_now - wall_start
                now_gps_ns = time_as_ns(gpstime.gpsnow())

                latency_ns = now_gps_ns - block.time_ns
                latency_s = latency_ns / Time.SECONDS
                latencies.append(latency_s)
                block_count += 1

                gap_str = ""
                if last_block_time is not None:
                    expected_gap = channel.stride
                    actual_gap = block.time_ns - last_block_time
                    if actual_gap != expected_gap:
                        gap_count += 1
                        gap_str = (
                            f" GAP! expected={expected_gap}ns actual={actual_gap}ns"
                        )

                print(
                    f"[{elapsed:7.2f}s] block time={block.time_ns}"
                    f" ({block.time_ns / Time.SECONDS:.4f}s)"
                    f" duration={block.duration_ns}ns"
                    f" latency={latency_s:.3f}s"
                    f"{gap_str}"
                )
                last_block_time = block.time_ns

                if elapsed >= args.duration:
                    break

    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        reader.close()

    print(f"{'=' * 80}")
    print("Summary:")
    print(f"  Blocks received: {block_count}")
    print(f"  Gaps detected:   {gap_count}")
    if latencies:
        print(f"  Latency min:     {min(latencies):.3f}s")
        print(f"  Latency max:     {max(latencies):.3f}s")
        print(f"  Latency mean:    {numpy.mean(latencies):.3f}s")
        print(f"  Latency median:  {numpy.median(latencies):.3f}s")
        max_latency_s = channel.max_latency / Time.SECONDS
        over_max = sum(1 for lat in latencies if lat > max_latency_s)
        print(f"  Over max_latency ({max_latency_s}s): {over_max}/{len(latencies)}")
    else:
        print("  No data received!")


if __name__ == "__main__":
    main()
