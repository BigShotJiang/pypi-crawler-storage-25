# Phase 2: Historical Consumer Support - Implementation Context

## Executive Summary

**Goal**: Enable historical data playback while maintaining efficient live streaming architecture.

**Strategy**: Hybrid consumer model with automatic transition from historical → live.

**Current Status** (as of this document):
- ✅ Phase 1 deployed: Live-only consumer manager (working)
- ⏳ Phase 2: Historical support (design complete, ready to implement)

---

## Why This Matters

**Problem**: Clients can request data from the past (e.g., start=1000 when now=2000).

**Current Behavior** (Phase 1): Clients get live data only, ignore start time.

**Desired Behavior** (Phase 2):
1. Client requests start=1000, now=2000
2. Create historical consumer seeking to Kafka offset @ time 1000
3. Stream: 1000 → 1500 → 1800 → 1950 → 1998 (approaching live)
4. **Automatically transition to shared live consumer when caught up**
5. Historical consumer shuts down (no more subscribers)

---

## Architecture Design

### Two-Tier Consumer Model

```
┌─────────────────────────────────────────────────────────────┐
│                    ConsumerManager                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  LIVE Consumers (long-lived, shared)                       │
│  ┌────────────────────────────────────┐                    │
│  │ partition-0 → [client1, client2,   │                    │
│  │               client3, client4...] │  (N clients)       │
│  │ partition-1 → [client1, client3]   │                    │
│  └────────────────────────────────────┘                    │
│       ↑ One consumer, many subscribers                     │
│       │ Polls latest Kafka messages                        │
│       │ Broadcasts to all                                  │
│                                                             │
│  HISTORICAL Consumers (temporary, bucketed)                │
│  ┌────────────────────────────────────┐                    │
│  │ (partition-0, t=1000) → [clientA]  │                    │
│  │ (partition-0, t=1060) → [clientB]  │                    │
│  │ (partition-1, t=1000) → [clientA]  │                    │
│  └────────────────────────────────────┘                    │
│       ↑ Seeks to historical offset                         │
│       │ Polls until caught up                              │
│       │ Transitions clients to LIVE                        │
│       │ Self-destructs when empty                          │
└─────────────────────────────────────────────────────────────┘
```

### Key Design Decisions

#### 1. **Time Bucketing** (Consumer Sharing)
```python
def _bucket_start_time(start_time: int, bucket_size: int = 60 * Time.SECONDS) -> int:
    """Bucket start time to enable consumer sharing.

    Example:
    - Client A requests start=1000ns
    - Client B requests start=1015ns
    - Both map to bucket=1000 (60s buckets)
    - Share the same historical consumer
    """
    return (start_time // bucket_size) * bucket_size
```

**Why?** Prevents creating N consumers for N clients with slightly different start times.

**Trade-off**: Clients may get data slightly before their requested start time (acceptable).

#### 2. **Historical vs Live Detection**
```python
def _is_historical_request(start: int | None, max_latency: timedelta) -> bool:
    """Determine if request needs historical consumer.

    Returns True if:
        start < (now - 2×max_latency)

    Example:
        now = 2000ns
        max_latency = 1s = 1,000,000,000ns
        threshold = 2000 - 2×1,000,000,000 = -1,998,000,000ns

        If start=1000 → historical (way in past)
        If start=1990 → live (within 2×latency buffer)
    """
    if start is None:
        return False

    now = int(gpstime.gpsnow() * Time.SECONDS)
    latency_ns = int(max_latency.total_seconds() * Time.SECONDS)

    return start < (now - 2 * latency_ns)
```

**Why 2×latency?** Buffer for processing lag and clock skew.

#### 3. **Catchup Detection & Transition**
```python
# In historical poll loop:
now_check = int(gpstime.gpsnow() * Time.SECONDS)
is_caught_up = time >= (now_check - 2 * Time.SECONDS)

if is_caught_up:
    # Signal client to transition
    stream._on_message(partition_id, time, batches, is_caught_up=True)
```

**Transition logic in ClientStream:**
```python
def _on_message(self, partition_id, time, batches, is_caught_up=False):
    # Process batches...

    if is_caught_up and self._is_historical:
        # Transition this stream to live
        manager = self._manager_ref()
        if manager:
            manager.transition_to_live(self)
```

**Why?** Seamless handoff prevents duplicate/missing messages.

#### 4. **Consumer Lifecycle**

```
Historical Consumer Lifecycle:

1. Created when first client subscribes to (partition, time_bucket)
2. Seeks to Kafka offset for that timestamp
3. Polls messages, broadcasts to subscribers
4. Monitors for catchup condition
5. Signals clients to transition to live
6. Self-destructs when last client transitions

Thread count impact:
    - Live: O(partitions) = ~10 threads
    - Historical: O(active_time_buckets) = 0-50 threads typically
    - Total: ~10-60 threads (vs 1000+ before)
```

---

## Implementation Checklist

### Data Structures to Add

```python
class ConsumerManager:
    def __init__(self, kafka_url: str):
        # ... existing live consumer dicts ...

        # ADD THESE:
        # Historical consumers: keyed by (partition_id, start_bucket)
        self._historical_consumers: dict[tuple[str, int], Consumer] = {}
        self._historical_threads: dict[tuple[str, int], threading.Thread] = {}
        self._historical_subscriptions: dict[tuple[str, int], list[ClientStream]] = defaultdict(list)
```

### Methods to Add/Modify

#### 1. **Helper Functions** (add to module level)
```python
def _is_historical_request(start: int | None, max_latency: timedelta) -> bool:
    """See design section above"""

def _bucket_start_time(start_time: int, bucket_size: int = 60 * Time.SECONDS) -> int:
    """See design section above"""

def _generate_groupid(partition_id: str, is_historical: bool = False) -> str:
    """Modified to distinguish historical from live"""
    prefix = "arrakis-historical" if is_historical else "arrakis-live"
    return f"{prefix}-{partition_id}-{random_suffix}"
```

#### 2. **ConsumerManager.subscribe()** - Modify
```python
def subscribe(self, partitions, channels, start, end, max_latency):
    # ADD THIS LOGIC:
    is_historical = _is_historical_request(start, max_latency)

    stream = ClientStream(
        ...,
        is_historical=is_historical,  # NEW PARAMETER
    )

    if is_historical:
        start_bucket = _bucket_start_time(start) if start else 0
        for partition_id in partitions.keys():
            key = (partition_id, start_bucket)

            if key not in self._historical_consumers:
                self._start_historical_consumer(partition_id, start, start_bucket)

            self._historical_subscriptions[key].append(stream)
    else:
        # ... existing live subscription logic ...
```

#### 3. **ConsumerManager Methods** - Add These

```python
def _start_historical_consumer(self, partition_id: str, start_time: int, start_bucket: int):
    """Start a historical consumer that seeks to a specific timestamp.

    See HISTORICAL_CONSUMER_METHODS.py for full implementation.
    """

def _stop_historical_consumer(self, key: tuple[str, int]):
    """Stop historical consumer when no more subscribers."""

def _historical_poll_loop(self, key: tuple[str, int]):
    """Poll loop for historical consumer.

    Key differences from live poll loop:
    1. Seeks to historical offset on startup
    2. Monitors for catchup condition
    3. Signals is_caught_up=True when detected
    """

def transition_to_live(self, stream: ClientStream):
    """Transition a client from historical to live consumer.

    Called when historical stream catches up.

    Steps:
    1. Remove stream from historical subscriptions
    2. Stop historical consumer if no more subscribers
    3. Add stream to live subscriptions
    4. Start live consumer if needed
    5. Update stream._is_historical = False
    """
```

#### 4. **ClientStream** - Add Parameters & Logic

```python
class ClientStream:
    def __init__(self, ..., is_historical: bool):
        # ... existing init ...

        # ADD THESE:
        self._is_historical = is_historical
        self._start_bucket = _bucket_start_time(start) if (is_historical and start) else None

    def _on_message(self, partition_id, time, batches, is_caught_up=False):
        # ... existing message processing ...

        # ADD THIS AT THE END:
        if is_caught_up and self._is_historical:
            logger.info("Historical stream caught up at time %d, transitioning to live", time)
            manager = self._manager_ref()
            if manager:
                manager.transition_to_live(self)
```

#### 5. **ConsumerManager.unsubscribe()** - Modify

```python
def unsubscribe(self, stream: ClientStream):
    with self._lock:
        if stream._is_historical:
            # Unsubscribe from historical consumers
            start_bucket = stream._start_bucket
            for partition_id in stream._partition_map.keys():
                key = (partition_id, start_bucket)
                if key in self._historical_subscriptions:
                    self._historical_subscriptions[key].remove(stream)

                    if not self._historical_subscriptions[key]:
                        self._stop_historical_consumer(key)
        else:
            # ... existing live unsubscribe logic ...
```

---

## Code References

### Full Method Implementations

See `HISTORICAL_CONSUMER_METHODS.py` for complete implementations of:
- `_start_historical_consumer()`
- `_stop_historical_consumer()`
- `_historical_poll_loop()`
- `transition_to_live()`

These can be copied directly into `consumer_manager.py`.

---

## Testing Strategy

### Unit Tests

```python
def test_is_historical_request():
    """Test historical vs live detection"""
    now = int(gpstime.gpsnow() * Time.SECONDS)
    latency = timedelta(seconds=1)

    # Way in past → historical
    assert _is_historical_request(now - 10*Time.SECONDS, latency) == True

    # Recent past → live
    assert _is_historical_request(now - 1*Time.SECONDS, latency) == False

    # None → live
    assert _is_historical_request(None, latency) == False

def test_bucket_start_time():
    """Test time bucketing"""
    # 60s buckets
    assert _bucket_start_time(1000) == 960  # Rounds down to minute
    assert _bucket_start_time(1059) == 1020

def test_historical_consumer_lifecycle():
    """Test consumer creation → transition → shutdown"""
    manager = ConsumerManager("localhost:9092")

    # Subscribe with historical start
    start = int(gpstime.gpsnow() * Time.SECONDS) - 100*Time.SECONDS
    stream = manager.subscribe(..., start=start, ...)

    # Should create historical consumer
    bucket = _bucket_start_time(start)
    key = (partition_id, bucket)
    assert key in manager._historical_consumers
    assert stream._is_historical == True

    # Simulate catchup
    manager.transition_to_live(stream)

    # Should be live now
    assert stream._is_historical == False
    assert partition_id in manager._live_consumers

    # Historical consumer should stop
    assert key not in manager._historical_consumers
```

### Integration Tests

```python
def test_historical_to_live_transition():
    """End-to-end test of historical → live transition"""

    # 1. Request historical data (start = 5 minutes ago)
    client = Client('grpc://localhost:50051')
    start = int(gpstime.gpsnow()) - 300  # 5 min ago

    # 2. Start streaming
    blocks = []
    for block in client.read(..., start=start):
        blocks.append(block)

        # Should receive historical data first
        if len(blocks) < 10:
            assert block.time_ns < int(gpstime.gpsnow() * Time.SECONDS)

        # Eventually catches up to live
        if len(blocks) > 100:
            assert abs(block.time_ns - int(gpstime.gpsnow() * Time.SECONDS)) < 2*Time.SECONDS
            break

    # 3. Verify no dropped/duplicated messages
    times = [b.time_ns for b in blocks]
    assert times == sorted(times)  # Monotonic
    assert len(set(times)) == len(times)  # No duplicates
```

### Load Tests

```python
def test_mixed_historical_and_live():
    """Test 100 historical + 100 live clients simultaneously"""

    clients_historical = [create_client(start=now-300) for _ in range(100)]
    clients_live = [create_client(start=None) for _ in range(100)]

    # Start all streams
    threads = []
    for client in clients_historical + clients_live:
        t = threading.Thread(target=lambda: list(client.read(...)))
        t.start()
        threads.append(t)

    # Check thread count on server
    server_threads = get_server_thread_count()

    # Should be ~10-60 threads (not 1000+)
    assert server_threads < 100, f"Too many threads: {server_threads}"

    # Wait for completion
    for t in threads:
        t.join(timeout=60)
```

---

## Edge Cases & Gotchas

### 1. **Message Deduplication at Transition**

**Problem**: During transition from historical → live, client might receive duplicate messages.

**Scenario**:
```
Time: 1998, 1999, 2000 (catchup detected!)
↓ Transition initiated
↓ Client switches to live consumer
Live consumer sends: 2000, 2001, 2002...
        ↑ DUPLICATE!
```

**Solution**: Track last seen timestamp in ClientStream:
```python
class ClientStream:
    def __init__(self, ...):
        self._last_time = None

    def _on_message(self, partition_id, time, batches, is_caught_up=False):
        # Deduplicate
        if self._last_time is not None and time <= self._last_time:
            logger.debug("Dropping duplicate message at time %d", time)
            return

        self._last_time = time
        # ... process batches ...
```

### 2. **Catchup Detection Timing**

**Problem**: Too eager → transitions before truly caught up (missing data)
Too conservative → never transitions (stuck in historical mode)

**Current Threshold**: `time >= (now - 2 * Time.SECONDS)`

**Tuning**: May need adjustment based on:
- Kafka message latency
- Server processing time
- Network delays

**Monitoring**: Add metrics:
```python
logger.info(
    "Catchup check: msg_time=%d, now=%d, diff=%dms, threshold=2s",
    time, now, (now - time) // 1_000_000,
)
```

### 3. **Kafka Offset Seeking Edge Cases**

**Problem**: Requested start time doesn't exist in Kafka (too old, purged).

**Behavior**: `offsets_for_times()` returns earliest available offset.

**Solution**: Log warning and proceed:
```python
requested_offset = consumer.offsets_for_times([partition])
actual_offset = requested_offset[0].offset

if actual_offset != expected_offset:
    logger.warning(
        "Requested start time %d not available, using earliest offset %d",
        start_time, actual_offset
    )
```

### 4. **Bucket Boundary Issues**

**Scenario**:
- Client A requests start=1000 → bucket=960
- Client B requests start=961 → bucket=960
- Both share consumer starting at 960
- Client B gets 1 second of unwanted data

**Impact**: Minimal (1 extra second)
**Mitigation**: Client-side filtering by start time if critical

### 5. **Multiple Partitions per Client**

**Complexity**: Client may request channels from multiple partitions.

**Behavior**:
- Client subscribes to partitions [P1, P2, P3]
- Each partition may have different historical consumers
- Transition happens per-partition (not globally)

**Solution**: Track transition state per-partition:
```python
class ClientStream:
    def __init__(self, ...):
        self._transitioned_partitions = set()

    def _on_message(self, partition_id, time, batches, is_caught_up=False):
        if is_caught_up and partition_id not in self._transitioned_partitions:
            self._transitioned_partitions.add(partition_id)

            # Only transition when ALL partitions caught up
            if len(self._transitioned_partitions) == len(self._partition_map):
                manager.transition_to_live(self)
```

---

## Performance Expectations

### Thread Count

| Scenario | Live-Only (Phase 1) | With Historical (Phase 2) |
|----------|---------------------|---------------------------|
| 300 live clients | ~10 threads | ~10 threads |
| 100 historical (various start times) | N/A | +10-30 threads |
| 200 live + 100 historical | ~10 threads | ~20-40 threads |

### Memory Usage

**Per historical consumer**: ~10MB
**Per client queue**: ~100MB (100 blocks × ~1MB)

**300 clients (200 live, 100 historical):**
- Historical consumers: 20 × 10MB = 200MB
- Client queues: 300 × 100MB = 30GB
- Total: ~30GB (same as Phase 1)

### CPU Impact

**Historical consumers**: Similar CPU profile to live (polling, deserializing)

**Transition overhead**: Negligible (one-time operation per client)

**Expected**: No significant CPU increase vs Phase 1

---

## Deployment Strategy

### Rollout Plan

1. **Phase 1** (DONE): Live-only version
   - Verify thread reduction
   - Verify no "Unable to create broker thread" errors
   - Run for 1 week in production

2. **Phase 2a**: Implement historical support
   - Add code from this document
   - Test in staging environment
   - Load test: 100 historical + 100 live clients

3. **Phase 2b**: Gradual production rollout
   - Deploy to single server
   - Monitor for 24 hours
   - Check metrics:
     - Thread count
     - Transition success rate
     - Memory usage
     - Client error rates

4. **Phase 2c**: Full deployment
   - Roll out to all servers
   - Monitor for 1 week
   - Document any issues

### Rollback Plan

If issues occur in Phase 2:

**Quick rollback**: Revert to Phase 1 code (live-only)

**Partial rollback**: Disable historical support via feature flag:
```python
ENABLE_HISTORICAL = os.getenv("ARRAKIS_ENABLE_HISTORICAL", "false").lower() == "true"

def subscribe(self, ...):
    if ENABLE_HISTORICAL:
        is_historical = _is_historical_request(start, max_latency)
    else:
        is_historical = False  # Force live-only
```

### Monitoring & Alerts

Add metrics:
```python
# Prometheus/Grafana metrics
arrakis_consumers_live_count{partition="X"}
arrakis_consumers_historical_count{partition="X", bucket="Y"}
arrakis_transitions_total
arrakis_transitions_failed_total
arrakis_historical_clients_stuck_total  # Clients that never transition

# Alerts
- name: too_many_historical_consumers
  expr: sum(arrakis_consumers_historical_count) > 100

- name: clients_stuck_in_historical
  expr: arrakis_historical_clients_stuck_total > 10
```

---

## Future Enhancements (Phase 3+)

### 1. **Message Caching / Replay Buffer**

Cache recent messages in memory for instant replay:
```python
class ConsumerManager:
    def __init__(self, ...):
        # Cache last N seconds of messages per partition
        self._message_cache: dict[str, deque] = defaultdict(lambda: deque(maxlen=100))

    def subscribe(self, ..., start, ...):
        # Check if start time is in cache
        if start in self._message_cache[partition]:
            # Instant replay from cache (no historical consumer needed!)
            return CachedStream(...)
```

**Benefits**: Instant historical replay for recent data (last 60s)

### 2. **Smart Consumer Consolidation**

Merge historical consumers with similar time ranges:
```
Current:
  (P1, t=1000) → [clientA]
  (P1, t=1020) → [clientB]

Optimized:
  (P1, t=1000-1020) → [clientA, clientB]
```

**Benefits**: Fewer historical consumers

### 3. **Adaptive Catchup Threshold**

Dynamically adjust catchup detection based on observed latency:
```python
# Track actual message latency
observed_latency = now - message_time
avg_latency = running_average(observed_latency)

# Adjust threshold
catchup_threshold = 2 * avg_latency  # Instead of fixed 2 seconds
```

**Benefits**: More accurate transitions

### 4. **Priority Queuing**

Give historical clients lower priority to avoid starving live clients:
```python
def _on_message(self, ...):
    if self._is_historical:
        # Use larger queue timeout (can wait longer)
        self._queue.put(block, timeout=5.0)
    else:
        # Live clients get priority
        self._queue.put(block, timeout=0.1)
```

**Benefits**: Live clients stay responsive even under load

---

## References

### Related Files

- `consumer_manager.py` - Main implementation
- `HISTORICAL_CONSUMER_METHODS.py` - Method implementations ready to copy
- `backend.py` - Uses ConsumerManager
- `CONSUMER_MANAGER_UPGRADE.md` - Phase 1 documentation
- `DEPLOYMENT_CHECKLIST.md` - Deployment guide

### External Documentation

- Kafka offset seeking: https://docs.confluent.io/platform/current/clients/consumer.html#offset-management
- librdkafka offsets_for_times: https://docs.confluent.io/kafka-clients/librdkafka/current/classRdKafka_1_1KafkaConsumer.html

### Design Discussion

- Original idea: User suggestion in conversation (historical → live transition)
- Profile analysis: `profile_partidx.svg` showing hotspots
- Thread limit issue: podman pids.max=2048

---

## Getting Started (When Ready for Phase 2)

### Step 1: Review This Document
Understand architecture and design decisions

### Step 2: Copy Method Implementations
From `HISTORICAL_CONSUMER_METHODS.py` into `consumer_manager.py`

### Step 3: Add Data Structures
Add the historical consumer dictionaries to `ConsumerManager.__init__()`

### Step 4: Modify Key Methods
- `subscribe()` - Add historical detection
- `unsubscribe()` - Handle both consumer types
- `ClientStream.__init__()` - Add `is_historical` parameter
- `ClientStream._on_message()` - Add `is_caught_up` handling

### Step 5: Test Locally
```bash
# Start server
python -m arrakis_backend_kafka ...

# Test historical request
python test_historical.py

# Verify transition in logs
sudo journalctl -u arrakis-server-kafka -f | grep "Transitioning"
```

### Step 6: Deploy to Staging
Follow deployment checklist, monitor carefully

### Step 7: Production Rollout
Gradual deployment with monitoring

---

**Questions?** Check the design discussion in this document or the original implementation conversation.

**Ready to implement?** Start with Step 1 above!
