"""
数据库 CLI 命令
"""

import json
import os
from dataclasses import asdict
from typing import Optional

import click
from rich.console import Console

# 默认路径
DEFAULT_MODEL_OUTPUT = "src/storage/database/shared/model.py"
DEFAULT_MODEL_IMPORT_PATH = "storage.database.shared.model"
DEFAULT_MODEL_PATH = "src"

console = Console()


def _get_workspace_path() -> str:
    """获取工作目录"""
    return os.getenv("WORKSPACE_PATH", os.getcwd())


@click.group()
def db():
    """Database management commands."""
    pass


@db.command()
@click.argument("output_path", required=False, default=None)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def generate_models(output_path: str, verbose: bool):
    """
    Generate ORM models from database.

    OUTPUT_PATH: Path to output model file (default: src/storage/database/shared/model.py)
    """
    from coze_coding_dev_sdk.database import generate_models as _generate_models

    if output_path is None:
        workspace = _get_workspace_path()
        output_path = os.path.join(workspace, DEFAULT_MODEL_OUTPUT)

    try:
        _generate_models(output_path, verbose=verbose)
        click.echo(f"Models generated at {output_path}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1)


@db.command()
@click.option(
    "--model-import-path",
    default=DEFAULT_MODEL_IMPORT_PATH,
    help=f"Model import path (default: {DEFAULT_MODEL_IMPORT_PATH})",
)
@click.option(
    "--model-path",
    default=None,
    help=f"Path to add to sys.path for model import (default: $WORKSPACE_PATH/{DEFAULT_MODEL_PATH})",
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
def upgrade(model_import_path: str, model_path: str, verbose: bool):
    """
    Run database migrations.

    Automatically generates migration and upgrades to head.
    """
    from coze_coding_dev_sdk.database import upgrade as _upgrade

    if model_path is None:
        workspace = _get_workspace_path()
        model_path = os.path.join(workspace, DEFAULT_MODEL_PATH)

    try:
        _upgrade(
            model_import_path=model_import_path,
            model_path=model_path,
            verbose=verbose,
        )
        click.echo("Database upgraded successfully")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1)


@db.command()
@click.option(
    "--env",
    "-e",
    type=click.Choice(["dev", "prod", "develop", "product"]),
    default=None,
    help="目标环境: dev/develop 或 prod/product，不传则使用 token 中的环境",
)
@click.option("--mock", is_flag=True, help="使用 mock 模式（测试运行，不会真正执行操作）")
@click.option(
    "--header",
    "-H",
    multiple=True,
    help="自定义 HTTP 请求头 (格式: 'Key: Value' 或 'Key=Value'，可多次使用)",
)
@click.option("--verbose", "-v", is_flag=True, help="显示详细的 HTTP 请求和响应日志")
def diagnose(env: Optional[str], mock: bool, header: tuple, verbose: bool):
    """获取数据库运行状态诊断报告。

    诊断内容包括：慢查询、连接状态、阻塞查询、长时间运行查询、数据库大小、表大小等。

    \b
    示例：
      coze-coding-ai db diagnose
      coze-coding-ai db diagnose --env dev
      coze-coding-ai db diagnose --env prod --verbose
    """
    try:
        from coze_coding_utils.runtime_ctx.context import new_context

        from ..core.config import Config
        from ..supabase import SupabaseClient
        from .constants import RUN_MODE_HEADER, RUN_MODE_TEST
        from .utils import parse_headers

        # normalize env aliases
        env_map = {"develop": "dev", "product": "prod"}
        if env in env_map:
            env = env_map[env]

        config = Config()
        ctx = None
        custom_headers = parse_headers(header) or {}

        if mock:
            ctx = new_context(method="db.diagnose", headers=custom_headers)
            custom_headers[RUN_MODE_HEADER] = RUN_MODE_TEST
            console.print("[yellow]🧪 Mock 模式已启用（测试运行）[/yellow]")

        client = SupabaseClient(config, ctx=ctx, custom_headers=custom_headers, verbose=verbose)
        response = client.diagnose_database(env=env)

        if response.code != 0:
            msg = response.msg or ""
            if "record not found" in msg.lower():
                env_label = env or "dev/prod"
                console.print(f"[red]✗ {env_label} 数据库还未创建，请先创建数据库后再进行诊断[/red]")
            else:
                console.print(f"[red]Error: {msg}[/red]")
            return

        console.print(json.dumps(asdict(response.report) if response.report else None, indent=2, ensure_ascii=False))

    except Exception as e:
        console.print(f"[red]✗ Error: {str(e)}[/red]")
        raise click.Abort()
