"""
对象存储 CLI 命令
"""

import json
import mimetypes
import sys
import tempfile
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path, PurePosixPath
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4

import click


def _normalize_prefix(prefix: str) -> str:
    if not prefix:
        return ""
    prefix = prefix.strip("/")
    return prefix + "/" if prefix else ""


def _build_object_key(prefix: str, name: str, use_uuid: bool, sanitize_fn) -> str:
    sanitized = sanitize_fn(name)
    if use_uuid:
        p = Path(sanitized)
        uniq = uuid4().hex[:8]
        if str(p.parent) != ".":
            sanitized = str(PurePosixPath(p.parent / f"{p.stem}_{uniq}{p.suffix}"))
        else:
            sanitized = f"{p.stem}_{uniq}{p.suffix}"
    return prefix + sanitized


def _resolve_paths(paths: Tuple[str, ...]) -> List[Tuple[Path, str]]:
    """解析目录为 (绝对路径, 相对key) 列表，保留目录名"""
    results: List[Tuple[Path, str]] = []
    seen: set = set()
    for path_str in paths:
        p = Path(path_str).resolve()
        if not p.exists() or not p.is_dir():
            continue
        for f in sorted(p.rglob("*")):
            if f.is_file() and f not in seen:
                seen.add(f)
                rel = f.relative_to(p.parent)
                results.append((f, str(PurePosixPath(rel))))
    return results


def _zip_directory(dir_path: Path) -> Path:
    """将目录打包为临时 zip 文件"""
    zip_name = f"{dir_path.name}.zip"
    tmp_dir = tempfile.mkdtemp()
    zip_path = Path(tmp_dir) / zip_name
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(dir_path.rglob("*")):
            if f.is_file():
                arcname = str(f.relative_to(dir_path.parent))
                zf.write(f, arcname)
    return zip_path


def _upload_file_to_s3(s3_client, bucket: str, file_path: Path, object_key: str, threshold: int) -> int:
    """上传单个文件到 S3，返回字节数"""
    content_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
    file_size = file_path.stat().st_size

    if file_size <= threshold:
        s3_client.put_object(
            Bucket=bucket,
            Key=object_key,
            Body=file_path.read_bytes(),
            ContentType=content_type,
        )
    else:
        from boto3.s3.transfer import TransferConfig
        config = TransferConfig(
            multipart_threshold=threshold,
            multipart_chunksize=threshold,
            max_concurrency=1,
            use_threads=False,
        )
        with open(file_path, "rb") as f:
            s3_client.upload_fileobj(
                Fileobj=f,
                Bucket=bucket,
                Key=object_key,
                ExtraArgs={"ContentType": content_type},
                Config=config,
            )
    return file_size


@click.group()
def storage():
    """Object storage commands."""
    pass


@storage.command()
@click.argument("paths", nargs=-1, required=True, type=click.Path())
@click.option("--prefix", "-p", default="", help="Target S3 key prefix (virtual directory)")
@click.option("--uuid", "use_uuid", is_flag=True, help="Append UUID suffix to filenames to avoid collisions")
@click.option("--expire", "-e", default=86400, type=int, help="Presigned URL expiration in seconds (default: 86400 = 24h)")
@click.option("--threshold", "-t", default=5 * 1024 * 1024, type=int, help="Size threshold (bytes) for streaming upload (default: 5MB)")
@click.option("--max-concurrency", "-c", default=4, type=int, help="Number of parallel upload threads (default: 4)")
def upload(paths, prefix, use_uuid, expire, threshold, max_concurrency):
    """Upload files and directories to object storage.

    PATHS: One or more file or directory paths to upload.
    Files are uploaded directly. Directories are uploaded recursively
    AND also zipped as a single archive.
    Outputs JSON with name-to-URL mappings to stdout.

    \b
    Examples:
      coze-coding-ai storage upload ./data --prefix my-project/
      coze-coding-ai storage upload file1.txt dir1/ dir2/ --prefix uploads/
      coze-coding-ai storage upload report.csv --prefix reports/ --expire 3600
    """
    from coze_coding_dev_sdk.s3 import S3SyncStorage

    # 1. 分离文件和目录
    files: List[Path] = []
    dirs: List[Path] = []

    for path_str in paths:
        p = Path(path_str).resolve()
        if not p.exists():
            print(f"Warning: {path_str} does not exist, skipping", file=sys.stderr)
            continue
        if p.is_file():
            files.append(p)
        elif p.is_dir():
            dirs.append(p)
        else:
            print(f"Warning: {path_str} is not a file or directory, skipping", file=sys.stderr)

    if not files and not dirs:
        print(json.dumps({"_error": "No files or directories found to upload."}))
        raise SystemExit(1)

    # 2. 规范化 prefix
    prefix = _normalize_prefix(prefix)

    # 3. 初始化 S3
    try:
        storage_client = S3SyncStorage()
        target_bucket = storage_client._resolve_bucket(None)
    except Exception as e:
        print(json.dumps({"_error": f"S3 configuration error: {e}"}))
        raise SystemExit(1)

    sanitize_fn = storage_client._sanitize_file_name

    # 4. 构建上传任务
    single_file_tasks: List[Tuple[Path, str, str]] = []
    for f in files:
        key = _build_object_key(prefix, f.name, use_uuid, sanitize_fn)
        single_file_tasks.append((f, key, f.name))

    dir_file_tasks: List[Tuple[Path, str, str]] = []
    for d in dirs:
        dir_files = _resolve_paths((str(d),))
        for file_path, relative_key in dir_files:
            key = _build_object_key(prefix, relative_key, use_uuid, sanitize_fn)
            dir_file_tasks.append((file_path, key, relative_key))

    zip_tasks: List[Tuple[Path, str, str]] = []
    for d in dirs:
        zip_name = f"{d.name}.zip"
        key = _build_object_key(prefix, zip_name, use_uuid, sanitize_fn)
        zip_tasks.append((d, key, f"{d.name}/"))

    all_file_tasks = single_file_tasks + dir_file_tasks

    # 5. 获取 boto3 client
    try:
        s3_client = storage_client._get_client()
    except Exception as e:
        print(json.dumps({"_error": f"Failed to initialize S3 client: {e}"}))
        raise SystemExit(1)

    result_map: Dict[str, str] = {}
    failures: List[Tuple[str, str]] = []
    single_file_names = {name for _, _, name in single_file_tasks}

    # 6. 并发上传文件
    def _do_upload(fp: Path, key: str, name: str):
        try:
            _upload_file_to_s3(s3_client, target_bucket, fp, key, threshold)
            if name in single_file_names:
                url = storage_client.generate_presigned_url(key=key, expire_time=expire)
                return (name, url, None)
            return (name, None, None)
        except Exception as e:
            return (name, None, str(e))

    if all_file_tasks:
        with ThreadPoolExecutor(max_workers=max_concurrency) as executor:
            futures = {
                executor.submit(_do_upload, fp, key, name): name
                for fp, key, name in all_file_tasks
            }
            for future in as_completed(futures):
                name, url, error = future.result()
                if error:
                    failures.append((name, error))
                elif url:
                    result_map[name] = url

    # 7. 打包并上传 zip
    for dir_path, object_key, display_name in zip_tasks:
        tmp_zip_path: Optional[Path] = None
        try:
            tmp_zip_path = _zip_directory(dir_path)
            _upload_file_to_s3(s3_client, target_bucket, tmp_zip_path, object_key, threshold)
            url = storage_client.generate_presigned_url(key=object_key, expire_time=expire)
            result_map[display_name] = url
        except Exception as e:
            failures.append((display_name, str(e)))
        finally:
            if tmp_zip_path and tmp_zip_path.exists():
                try:
                    tmp_zip_path.unlink()
                    tmp_zip_path.parent.rmdir()
                except OSError:
                    pass

    # 8. 输出 JSON
    output: Dict[str, Any] = dict(result_map)
    if failures:
        output["_failures"] = [{"name": n, "error": e} for n, e in failures]

    print(json.dumps(output, indent=2, ensure_ascii=False))

    if failures:
        raise SystemExit(1)
