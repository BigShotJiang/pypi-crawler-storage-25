from setuptools import setup


# Keep a tiny setup.py shim for legacy workflows that still invoke `python setup.py ...`.
# Project metadata is defined in pyproject.toml.
setup()
