import math
import random
from typing import Dict, Any, Generic, Tuple, TypeVar, Optional, List, Protocol, runtime_checkable

import numpy as np
from autotrainer.core import get_verbose_logger
from .configurable import configurable
from .training_protocols import class_to_dict, class_from_dict

T = TypeVar("T", covariant=True)
V = TypeVar("V")

logger = get_verbose_logger(__name__)


@runtime_checkable
class ValueProvider(Protocol[T]):

    def has_next_value(self) -> bool: ...

    def get_next_value(self) -> T: ...

    def to_dict(self): ...


class ShuffledValueProvider(Generic[V]):
    def __init__(self, value: V, count: Optional[int] = None, shuffle: bool = False, repeat: bool = True):
        self._rng = random.Random()
        self._original_value = value
        self._shuffle_enabled = shuffle
        self._repeat = repeat
        self._index = 0
        self._exhausted = False

        if count is not None:
            if count < 1:
                raise ValueError(f"'count' must be >= 1, got {count}.")

            self._values: Optional[List[V]] = self._generate_values(value, count)
            self._shuffle()
            self._constant = None
        else:
            self._values = None
            self._constant = value

    def _generate_values(self, value: V, count: int) -> List[V]:
        ...

    def _shuffle(self):
        if self._shuffle_enabled:
            self._rng.shuffle(self._values)
        self._index = 0

    def has_next_value(self) -> bool:
        if self._constant is not None or self._repeat:
            return True
        return not self._exhausted

    def get_next_value(self) -> V:
        if self._constant is not None:
            return self._constant

        if self._exhausted:
            return self._values[-1]

        result = self._values[self._index]
        self._index += 1
        if self._index >= len(self._values):
            if self._repeat:
                self._shuffle()
            else:
                self._exhausted = True
        return result


class BooleanValueProvider(ShuffledValueProvider[bool], ValueProvider[bool]):
    def __init__(self, value: bool, count: Optional[int] = None, percentage: Optional[float] = None,
                 shuffle: bool = False, repeat: bool = True):
        has_count = count is not None
        has_percentage = percentage is not None

        if has_count != has_percentage:
            raise ValueError(
                "Both 'count' and 'percentage' must be provided together, or neither."
            )

        if has_percentage and not (0.0 <= percentage <= 1.0):
            raise ValueError(f"'percentage' must be between 0.0 and 1.0, got {percentage}.")

        self._percentage = percentage
        super().__init__(value, count, shuffle, repeat)

    @property
    @configurable()
    def value(self) -> bool:
        return self._original_value

    @property
    @configurable(required=False)
    def count(self) -> Optional[int]:
        return len(self._values) if self._values is not None else None

    @property
    @configurable(required=False)
    def percentage(self) -> Optional[float]:
        return self._percentage

    @property
    @configurable(required=False, default=False)
    def shuffle(self) -> bool:
        return self._shuffle_enabled

    @property
    @configurable(required=False, default=True)
    def repeat(self) -> bool:
        return self._repeat

    def _generate_values(self, value: bool, count: int) -> List[bool]:
        value_count = round(count * self._percentage)
        opposite_count = count - value_count
        return [value] * value_count + [not value] * opposite_count

    def to_dict(self) -> Dict[str, Any]:
        props: Dict[str, Any] = {"value": self._original_value, "shuffle": self._shuffle_enabled,
                                 "repeat": self._repeat}
        if self._values is not None:
            props["count"] = len(self._values)
            props["percentage"] = self._percentage
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, props)

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> "BooleanValueProvider":
        return cls(value=data["value"], count=data.get("count"), percentage=data.get("percentage"),
                   shuffle=data.get("shuffle", False), repeat=data.get("repeat", True))


class CountedFloatValueProvider(ShuffledValueProvider[float], ValueProvider[float]):
    def __init__(self, value: float, count: int, value_range: Tuple[float, float], shuffle: bool = False,
                 repeat: bool = True):
        self._interval: float = 0.0
        self._value_range = value_range
        super().__init__(value, count, shuffle, repeat)

    @property
    @configurable()
    def value(self) -> float:
        return self._original_value

    @property
    @configurable()
    def count(self) -> int:
        return len(self._values)

    @property
    @configurable()
    def value_range(self) -> Tuple[float, float]:
        return self._value_range

    @property
    @configurable(required=False, default=False)
    def shuffle(self) -> bool:
        return self._shuffle_enabled

    @property
    @configurable(required=False, default=True)
    def repeat(self) -> bool:
        return self._repeat

    @property
    def interval(self) -> float:
        return self._interval

    def _generate_values(self, value: float, count: int) -> List[float]:
        values, step = np.linspace(self._value_range[0], self._value_range[1], num=count, retstep=True)
        self._interval = float(step)
        return values.tolist()

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, {
            "value": self._original_value, "count": len(self._values),
            "value_range": list(self._value_range), "shuffle": self._shuffle_enabled, "repeat": self._repeat
        })

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> "CountedFloatValueProvider":
        return cls(value=data["value"], count=data["count"], value_range=tuple(data["value_range"]),
                   shuffle=data.get("shuffle", False), repeat=data.get("repeat", True))


class IncrementedFloatValueProvider(ShuffledValueProvider[float], ValueProvider[float]):
    def __init__(self, value: float, increment: float, value_range: Tuple[float, float], shuffle: bool = False,
                 repeat: bool = True):
        self._increment = increment
        self._original_value_range = value_range
        steps = math.ceil((value_range[1] - value_range[0]) / increment)
        adjusted_end = value_range[0] + steps * increment
        self._value_range = (value_range[0], adjusted_end)
        super().__init__(value, steps + 1, shuffle, repeat)

    @property
    @configurable()
    def value(self) -> float:
        return self._original_value

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @property
    @configurable()
    def value_range(self) -> Tuple[float, float]:
        return self._original_value_range

    @property
    @configurable(required=False, default=False)
    def shuffle(self) -> bool:
        return self._shuffle_enabled

    @property
    @configurable(required=False, default=True)
    def repeat(self) -> bool:
        return self._repeat

    def _generate_values(self, value: float, count: int) -> List[float]:
        return np.linspace(self._value_range[0], self._value_range[1], num=count).tolist()

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, {
            "value": self._original_value, "increment": self._increment,
            "value_range": list(self._original_value_range), "shuffle": self._shuffle_enabled,
            "repeat": self._repeat
        })

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> "IncrementedFloatValueProvider":
        return cls(value=data["value"], increment=data["increment"], value_range=tuple(data["value_range"]),
                   shuffle=data.get("shuffle", False), repeat=data.get("repeat", True))
