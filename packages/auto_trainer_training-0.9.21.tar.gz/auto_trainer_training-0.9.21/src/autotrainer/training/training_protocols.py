import importlib
from dataclasses import dataclass
from enum import IntEnum
from typing import List, Protocol, Optional, Dict, Any, Tuple, runtime_checkable

import humps

from autotrainer.core.interfaces import CaptureAnalysisResult, PelletHardwareProtocol, BehaviorAlgorithmProtocol, \
    TunnelHardwareProtocol, RecordingEndingReason

from .training_progress import TrainingProgress


# Developer note: The use of protocols in this file name and contents is in reference to Python Protocols _not_ the
# user-facing/medical use of "protocol" in "training protocol".


class TrainingPhaseProtocol(Protocol):
    """
    Defined as a standalone protocol primarily to void circular imports between TrainingPhase and TrainingPredicate.
    """

    @property
    def progress(self) -> TrainingProgress: ...

    @property
    def magnet_intensity(self) -> Optional[float]: ...

    @property
    def is_pellet_cover_enabled(self) -> bool: ...

    @property
    def is_auto_clamp_enabled(self) -> bool: ...


class TrainingProgressState(IntEnum):
    Unknown = -1
    Initialized = 0
    Active = 10
    Paused = 20
    Failed = 30
    Complete = 40


class LoadProgressResult(IntEnum):
    OK = 0
    OUT_OF_DATE = 1
    UNKNOWN_ERROR = 2


class TrainingBehaviorAlgorithmProtocol(BehaviorAlgorithmProtocol):
    def start_session(self, *, reason: str = "NA"): ...

    def end_session(self, result: CaptureAnalysisResult): ...

    def end_capture_session(self, *, reason: RecordingEndingReason): ...

    def increase_pellets_consumed(self, increment: int = 1): ...

    def increase_pellets_presented(self, increment: int = 1): ...

    def increase_successful_reaches(self, increment: int = 1): ...


@dataclass
class PredicateContext:
    progress: Optional[TrainingProgress] = None
    algorithm: Optional[TrainingBehaviorAlgorithmProtocol] = None
    pellet_device: Optional[PelletHardwareProtocol] = None
    tunnel_device: Optional[TunnelHardwareProtocol] = None
    capture_analysis_result: Optional[CaptureAnalysisResult] = None

    def resolve_path(self, path: List[str]) -> Optional[Any]:
        if not path:
            return None
        target = self
        for part in path:
            if target is not None and hasattr(target, part):
                target = getattr(target, part)
            else:
                return None
        return target

    def resolve_path_parent(self, path: List[str]) -> Optional[Tuple[Any, str]]:
        if not path:
            return None
        target = self
        for part in path[:-1]:
            if target is not None and hasattr(target, part):
                target = getattr(target, part)
            else:
                return None
        attr = path[-1]
        if target is not None and hasattr(target, attr):
            return target, attr
        return None


@runtime_checkable
class TrainingActionProtocol(Protocol):
    """
    Defined as a standalone protocol primarily to void circular imports between TrainingPhase and TrainingAction.
    """

    @property
    def has_progress(self) -> bool: ...

    @property
    def is_complete(self) -> bool: ...

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None: ...

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None: ...

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool: ...

    def serialize_progress(self) -> Dict[str, Any]: ...

    def deserialize_progress(self, data: Dict[str, Any]) -> None: ...

    def to_dict(self) -> Dict[str, Any]: ...

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]): ...


@runtime_checkable
class TrainingPredicateProtocol(Protocol):

    @property
    def min_trials_to_evaluate(self) -> Optional[int]: ...

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool: ...

    def to_dict(self) -> Dict[str, Any]: ...

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]): ...


def class_to_dict(name: str, module: str, props: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    data: Dict[str, Any] = {
        "type": name,
        "module": module
    }

    if props is not None:
        data["properties"] = humps.camelize(props)

    return humps.camelize(data)


ALLOWED_MODULES = frozenset({
    "autotrainer.training.training_action",
    "autotrainer.training.training_predicate",
    "autotrainer.training.value_provider",
})


def class_from_dict(data: Optional[Dict[str, Any]]):
    if data is None:
        return None

    data = humps.decamelize(data)

    if data is None or data["module"] is None or data["type"] is None:
        return None

    if data["module"] not in ALLOWED_MODULES:
        raise ValueError(f"Module not allowed: {data['module']}")

    module = importlib.import_module(data["module"])
    class_ = getattr(module, data["type"])

    if "properties" in data and getattr(class_, "from_properties"):
        return class_.from_properties(humps.decamelize(data["properties"]))
    else:
        return class_()
