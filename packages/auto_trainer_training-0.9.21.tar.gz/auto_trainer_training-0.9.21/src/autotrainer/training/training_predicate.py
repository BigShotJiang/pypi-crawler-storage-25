from enum import IntEnum
from sys import float_info
from typing import List, Union, Dict, Any, Optional

from typing_extensions import Self

from autotrainer.core import get_verbose_logger
from autotrainer.core.reach_event import ReachEventMethod, ReachEventOutcome

from .configurable import configurable

logger = get_verbose_logger(__name__)
from .training_protocols import TrainingPredicateProtocol
from .training_protocols import PredicateContext, TrainingPhaseProtocol, class_from_dict, class_to_dict

_FLOAT_COMPARISON = float_info.epsilon * 2


class TrainingPredicate:
    def __init__(self, child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        self._child: Optional[TrainingPredicateProtocol] = child
        self._min_trials_to_evaluate: Optional[int] = min_trials_to_evaluate

    @property
    @configurable(required=False, envelope=True)
    def child(self) -> Optional[TrainingPredicateProtocol]:
        return self._child

    @child.setter
    def child(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._child = value

    @property
    @configurable(required=False, default=None)
    def min_trials_to_evaluate(self) -> Optional[int]:
        """Minimum number of sessions before this predicate can evaluate to True.
        Especially useful on fallback and advance predicates to prevent premature
        phase transitions before enough data has been collected."""
        return self._min_trials_to_evaluate

    @min_trials_to_evaluate.setter
    def min_trials_to_evaluate(self, value: Optional[int]) -> None:
        self._min_trials_to_evaluate = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if self._min_trials_to_evaluate is not None:
            if context.progress is None or context.progress.session_count < self._min_trials_to_evaluate:
                return False
        if self._child is not None:
            return self._child.evaluate(phase, context)
        return True

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {}
        if self._child is not None:
            result["child"] = self._child.to_dict()
        if self._min_trials_to_evaluate is not None:
            result["min_trials_to_evaluate"] = self._min_trials_to_evaluate
        return result if result else None

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, self._to_dict())

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]):
        return class_from_dict(data)


class CompoundPredicate(TrainingPredicate):
    class CompoundType(IntEnum):
        AND = 0
        OR = 1

    def __init__(self, compound_type: CompoundType, predicates: List[TrainingPredicate],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._compound_type = compound_type
        self._predicates = predicates

    @property
    @configurable()
    def compound_type(self) -> "CompoundPredicate.CompoundType":
        return self._compound_type

    @compound_type.setter
    def compound_type(self, value: "CompoundPredicate.CompoundType") -> None:
        self._compound_type = value

    @property
    @configurable(envelope=True)
    def predicates(self) -> List[TrainingPredicate]:
        return self._predicates

    @predicates.setter
    def predicates(self, value: List[TrainingPredicate]) -> None:
        self._predicates = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if not super().evaluate(phase, context):
            return False
        if self.compound_type == CompoundPredicate.CompoundType.AND:
            return all(predicate.evaluate(phase, context) for predicate in self.predicates)
        else:
            return any(predicate.evaluate(phase, context) for predicate in self.predicates)

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "compound_type": self.compound_type.name,
            "predicates": [predicate.to_dict() for predicate in self.predicates]
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        compound_type = CompoundPredicate.CompoundType[data["compound_type"]]
        predicates = [TrainingPredicate.from_dict(d) for d in data["predicates"]]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(compound_type, predicates, child, data.get("min_trials_to_evaluate"))


class NumberComparisonType(IntEnum):
    LT = 0
    LTE = 1
    EQ = 2
    GTE = 3
    GT = 4


def compare_numbers(comparison_type: NumberComparisonType,
                    resolved_value: Optional[Union[int, float]], compare_value: Union[int, float]) -> bool:
    if resolved_value is None:
        return False

    if comparison_type == NumberComparisonType.LT:
        return resolved_value < compare_value
    elif comparison_type == NumberComparisonType.LTE:
        return resolved_value <= compare_value
    elif comparison_type == NumberComparisonType.EQ:
        if isinstance(resolved_value, float) or isinstance(compare_value, float):
            return abs(resolved_value - compare_value) < _FLOAT_COMPARISON
        else:
            return resolved_value == compare_value
    elif comparison_type == NumberComparisonType.GTE:
        return resolved_value >= compare_value
    elif comparison_type == NumberComparisonType.GT:
        return resolved_value > compare_value

    return False


class NumberComparisonPredicate(TrainingPredicate):
    def __init__(self, comparison_type: NumberComparisonType, path: str, value: Union[int, float],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)
        self._comparison_type = comparison_type
        if not isinstance(path, list):
            self._path = path.split(".")
        else:
            self._path = path

        self._value = value

    @property
    @configurable()
    def comparison_type(self) -> NumberComparisonType:
        return self._comparison_type

    @comparison_type.setter
    def comparison_type(self, value: NumberComparisonType) -> None:
        self._comparison_type = value

    @property
    @configurable()
    def path(self) -> List[str]:
        return self._path

    @path.setter
    def path(self, value: List[str]) -> None:
        self._path = value

    @property
    @configurable()
    def value(self) -> Union[int, float]:
        return self._value

    @value.setter
    def value(self, value: Union[int, float]):
        self._value = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if not super().evaluate(phase, context):
            return False
        resolved = context.resolve_path(self.path)
        return compare_numbers(self.comparison_type, resolved, self.value)

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "comparison_type": self.comparison_type.name,
            "path": self.path,
            "value": self.value
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        comparison_type = NumberComparisonType[data["comparison_type"]]
        path = data["path"]
        value = data["value"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(comparison_type, path, value, child, data.get("min_trials_to_evaluate"))


class MathComparisonPredicate(NumberComparisonPredicate):
    _configurable_exclude = {"path"}

    class MathOperationType(IntEnum):
        ADD = 0
        SUBTRACT = 1
        MULTIPLY = 2
        DIVIDE = 3

    def __init__(self, comparison_type: NumberComparisonType,
                 left_path: str, math_operation: MathOperationType,
                 right_path: str, value: Union[int, float],
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(comparison_type, left_path, value, child, min_trials_to_evaluate)
        self._math_operation = math_operation
        if not isinstance(right_path, list):
            self._right_path = right_path.split(".")
        else:
            self._right_path = right_path

    @property
    @configurable()
    def left_path(self) -> List[str]:
        return self._path

    @left_path.setter
    def left_path(self, value: List[str]) -> None:
        self._path = value

    @property
    @configurable()
    def math_operation(self) -> "MathComparisonPredicate.MathOperationType":
        return self._math_operation

    @math_operation.setter
    def math_operation(self, value: "MathComparisonPredicate.MathOperationType") -> None:
        self._math_operation = value

    @property
    @configurable()
    def right_path(self) -> List[str]:
        return self._right_path

    @right_path.setter
    def right_path(self, value: List[str]) -> None:
        self._right_path = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if not TrainingPredicate.evaluate(self, phase, context):
            return False

        left_value = context.resolve_path(self.path)
        right_value = context.resolve_path(self.right_path)

        if left_value is None or right_value is None:
            return False

        if self.math_operation == MathComparisonPredicate.MathOperationType.ADD:
            result = left_value + right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.SUBTRACT:
            result = left_value - right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.MULTIPLY:
            result = left_value * right_value
        elif self.math_operation == MathComparisonPredicate.MathOperationType.DIVIDE:
            if right_value == 0:
                return False
            result = left_value / right_value
        else:
            return False

        return compare_numbers(self.comparison_type, result, self.value)

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "comparison_type": self.comparison_type.name,
            "left_path": self.path,
            "math_operation": self.math_operation.name,
            "right_path": self.right_path,
            "value": self.value
        }
        base = TrainingPredicate._to_dict(self)
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        comparison_type = NumberComparisonType[data["comparison_type"]]
        left_path = data["left_path"]
        math_operation = MathComparisonPredicate.MathOperationType[data["math_operation"]]
        right_path = data["right_path"]
        value = data["value"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(comparison_type, left_path, math_operation, right_path, value, child,
                   data.get("min_trials_to_evaluate"))


class PelletReachTimePredicate(TrainingPredicate):
    def __init__(self, max_reach_time: float, require_first: bool = False,
                 child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._max_reach_time = max_reach_time
        self._require_first = require_first

    @property
    @configurable()
    def max_reach_time(self) -> float:
        return self._max_reach_time

    @max_reach_time.setter
    def max_reach_time(self, value: float) -> None:
        self._max_reach_time = value

    @property
    @configurable()
    def require_first(self) -> bool:
        return self._require_first

    @require_first.setter
    def require_first(self, value: bool) -> None:
        self._require_first = value

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if not super().evaluate(phase, context):
            return False

        if context.algorithm is None:
            return False

        reaches = context.algorithm.trial_reaches

        for reach in reaches:
            if reach.outcome == ReachEventOutcome.EATEN and reach.method == ReachEventMethod.RIGHT_HAND:
                if reach.delay_since_presented <= self._max_reach_time:
                    return True
                if self._require_first:
                    return False

        return False

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "max_reach_time": self._max_reach_time,
            "require_first": self._require_first
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        max_reach_time = data["max_reach_time"]
        require_first = data["require_first"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(max_reach_time, require_first, child, data.get("min_trials_to_evaluate"))


class PythonPredicate(TrainingPredicate):
    def __init__(self, python_code: str, child: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_evaluate: Optional[int] = None):
        super().__init__(child, min_trials_to_evaluate)

        self._python_code = python_code
        self._compiled_eval = None
        self._compiled_exec = None
        self._use_exec = False

    @property
    @configurable()
    def python_code(self) -> str:
        return self._python_code

    @python_code.setter
    def python_code(self, value: str) -> None:
        self._python_code = value
        self._compiled_eval = None
        self._compiled_exec = None
        self._use_exec = False

    def _ensure_compiled(self) -> None:
        if self._compiled_eval is not None or self._compiled_exec is not None:
            return
        try:
            self._compiled_eval = compile(self._python_code, "<PythonPredicate>", "eval")
        except SyntaxError:
            self._compiled_exec = compile(self._python_code, "<PythonPredicate>", "exec")
            self._use_exec = True

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if not super().evaluate(phase, context):
            return False

        namespace = {"context": context, "phase": phase}
        try:
            self._ensure_compiled()
            if self._use_exec:
                exec(self._compiled_exec, namespace)
                return bool(namespace.get("result", False))
            else:
                return bool(eval(self._compiled_eval, namespace))
        except Exception:
            logger.error("PythonPredicate error evaluating: %s", self._python_code, exc_info=True)
            return False

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {
            "python_code": self.python_code
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        python_code = data["python_code"]
        child = TrainingPredicate.from_dict(data.get("child"))
        return cls(python_code, child, data.get("min_trials_to_evaluate"))
