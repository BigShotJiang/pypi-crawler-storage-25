import uuid
from enum import IntEnum
from typing import List, Dict, Any, Optional, Callable

from autotrainer.core import get_verbose_logger
from typing_extensions import Self

import humps

from .configurable import configurable
from .event_slot import EventSlot
from .training_protocols import PredicateContext, TrainingPhaseProtocol, TrainingActionProtocol, \
    TrainingPredicateProtocol
from .training_predicate import TrainingPredicate
from .training_action import TrainingAction
from .training_progress import TrainingProgress, ProgressKey

logger = get_verbose_logger(__name__)


class SessionResult(IntEnum):
    NONE = 0
    FALLBACK = 10
    ADVANCE = 20


class TrainingPhase(TrainingPhaseProtocol):
    def __init__(self, phase_id: Optional[str] = None):
        self._phase_id = phase_id or str(uuid.uuid4())
        self._name: str = ""
        self._description: str = ""
        self._fallback_condition: Optional[TrainingPredicateProtocol] = None
        self._advance_condition: Optional[TrainingPredicateProtocol] = None
        self._session_actions: List[TrainingActionProtocol] = []

        self._send_x: Optional[float] = None
        self._send_y: Optional[float] = None
        self._send_z: Optional[float] = None

        self._is_pellet_delivery_enabled: bool = False

        self._use_magnet_baseline_intensity: bool = False
        self._magnet_intensity: Optional[float] = None

        self._is_pellet_cover_enabled: bool = False

        self._is_pellet_shift_enabled: bool = False

        self._is_auto_clamp_enabled: bool = False
        self._auto_clamp_no_activity_release_delay: float = 0.0
        self._auto_clamp_release_load_count: int = 0

        self._version_id: int = 1

        self._progress = TrainingProgress()

        self._would_advance: bool = False
        self._would_fallback: bool = False

        self.property_changed = EventSlot()

    @property
    def phase_id(self) -> str:
        return self._phase_id

    @property
    @configurable(required=False, default=0)
    def version_id(self) -> int:
        return self._version_id

    @version_id.setter
    def version_id(self, value: int) -> None:
        self._version_id = value

    @property
    @configurable()
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    @configurable()
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: str) -> None:
        self._description = value

    @property
    @configurable(required=False, envelope=True, aliases=["fallback", "fallback condition"], default=None)
    def fallback_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._fallback_condition

    @fallback_predicate.setter
    def fallback_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._fallback_condition = value

    @property
    @configurable(required=False, envelope=True, aliases=["advance", "advance condition"], default=None)
    def advance_predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._advance_condition

    @advance_predicate.setter
    def advance_predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._advance_condition = value

    @property
    @configurable(required=False, envelope=True, aliases=["trial actions", "actions"], default=[])
    def session_actions(self) -> List[TrainingActionProtocol]:
        return self._session_actions

    @session_actions.setter
    def session_actions(self, value: List[Callable[[Self, PredicateContext], None]]) -> None:
        self._session_actions = value

    @property
    def progress(self) -> TrainingProgress:
        return self._progress

    @progress.setter
    def progress(self, value: TrainingProgress) -> None:
        self._progress = self._on_property_changed("progress", value, self._progress)

    @property
    @configurable(required=False, aliases=["pellet x", "pellet send x"], default=None)
    def send_x(self) -> Optional[float]:
        return self._send_x

    @send_x.setter
    def send_x(self, value: Optional[float]) -> None:
        self._send_x = value

    @property
    @configurable(required=False, aliases=["pellet y", "pellet send y"], default=None)
    def send_y(self) -> Optional[float]:
        return self._send_y

    @send_y.setter
    def send_y(self, value: Optional[float]) -> None:
        self._send_y = value

    @property
    @configurable(required=False, aliases=["pellet z", "pellet send z"], default=None)
    def send_z(self) -> Optional[float]:
        return self._send_z

    @send_z.setter
    def send_z(self, value: Optional[float]) -> None:
        self._send_z = value

    @property
    @configurable(required=False, aliases=["pellet delivery"], default=False)
    def is_pellet_delivery_enabled(self) -> bool:
        return self._is_pellet_delivery_enabled

    @is_pellet_delivery_enabled.setter
    def is_pellet_delivery_enabled(self, value: bool) -> None:
        self._is_pellet_delivery_enabled = value

    @property
    @configurable(required=False, aliases=["pellet cover", "cover"], default=False)
    def is_pellet_cover_enabled(self) -> bool:
        return self._is_pellet_cover_enabled

    @is_pellet_cover_enabled.setter
    def is_pellet_cover_enabled(self, value: bool) -> None:
        self._is_pellet_cover_enabled = value

    @property
    @configurable(required=False, aliases=["magnet baseline", "baseline", "baseline intensity"], default=False)
    def use_magnet_baseline_intensity(self) -> bool:
        """If True, takes priority over any magnet_intensity value."""
        return self._use_magnet_baseline_intensity

    @use_magnet_baseline_intensity.setter
    def use_magnet_baseline_intensity(self, value: bool) -> None:
        self._use_magnet_baseline_intensity = value

    @property
    @configurable(required=False, aliases=["magnet intensity", "head intensity", "head magnet"], default=None)
    def magnet_intensity(self) -> Optional[float]:
        return self._magnet_intensity

    @magnet_intensity.setter
    def magnet_intensity(self, value: Optional[float]) -> None:
        self._magnet_intensity = value

    @property
    @configurable(required=False, aliases=["pellet shift", "send location shift"], default=False)
    def is_pellet_shift_enabled(self) -> bool:
        return self._is_pellet_shift_enabled

    @is_pellet_shift_enabled.setter
    def is_pellet_shift_enabled(self, value: bool) -> None:
        self._is_pellet_shift_enabled = value

    @property
    @configurable(required=False, aliases=["head clamp", "head fixation", "auto-clamp"], default=False)
    def is_auto_clamp_enabled(self) -> bool:
        return self._is_auto_clamp_enabled

    @is_auto_clamp_enabled.setter
    def is_auto_clamp_enabled(self, value: bool) -> None:
        self._is_auto_clamp_enabled = value

    @property
    @configurable(required=False, aliases=["release delay", "head fixation duration"], default=2.0)
    def auto_clamp_no_activity_release_delay(self) -> float:
        return self._auto_clamp_no_activity_release_delay

    @auto_clamp_no_activity_release_delay.setter
    def auto_clamp_no_activity_release_delay(self, value: float) -> None:
        self._auto_clamp_no_activity_release_delay = value

    @property
    @configurable(required=False, default=5)
    def auto_clamp_release_load_count(self) -> int:
        return self._auto_clamp_release_load_count

    @auto_clamp_release_load_count.setter
    def auto_clamp_release_load_count(self, value: int) -> None:
        self._auto_clamp_release_load_count = value

    @property
    def would_advance(self) -> bool:
        return self._would_advance

    @property
    def would_fallback(self) -> bool:
        return self._would_fallback

    def enter(self, context: PredicateContext, is_resume: bool = False) -> None:
        # If is_resume is True, the phase was in progress before this call.  Most likely, it was the active phase when
        # the system was stopped and serialized.  is_resume should not be called as True when started due to fallback
        # or advance, even if it is not the first time in the phase.
        if context.algorithm is not None:
            context.algorithm.reset_configuration()
            context.algorithm.pellet_delivery_enabled = self.is_pellet_delivery_enabled
            context.algorithm.pellet_cover_enabled = self.is_pellet_cover_enabled
            context.algorithm.intersession_pellet_shift_enabled = self.is_pellet_shift_enabled

            context.algorithm.head_fixation_enabled = self.is_auto_clamp_enabled

            if self.auto_clamp_no_activity_release_delay > 0.0:
                context.algorithm.auto_clamp_no_activity_release_delay = self.auto_clamp_no_activity_release_delay

            if self._auto_clamp_release_load_count > 0:
                context.algorithm.auto_clamp_release_load_count = self._auto_clamp_release_load_count

        if context.pellet_device is not None:
            if self.send_x is not None:
                context.pellet_device.set_dcs_x(self.send_x)
            if self.send_y is not None:
                context.pellet_device.set_dcs_y(self.send_y)
            if self.send_z is not None:
                context.pellet_device.set_dcs_z(self.send_z)

        if context.tunnel_device is not None:
            if self._use_magnet_baseline_intensity and context.algorithm is not None:
                context.tunnel_device.update_head_magnet_intensity(context.algorithm.baseline_intensity)
            elif self.magnet_intensity is not None:
                context.tunnel_device.update_head_magnet_intensity(self.magnet_intensity)

        if not is_resume:
            if context.pellet_device is not None and context.pellet_device.last_dcs_set_position is not None:
                location = (context.pellet_device.last_dcs_set_position.x,
                            context.pellet_device.last_dcs_set_position.y,
                            context.pellet_device.last_dcs_set_position.z)
            else:
                location = None

            self.progress = TrainingProgress(self.progress.phase_attempts + 1, location)
            self._begin_session_actions(context)
        else:
            if context.pellet_device is not None and self.progress.pellet_start_location is not None:
                context.pellet_device.set_dcs_x(self.progress.pellet_start_location[0])
                context.pellet_device.set_dcs_y(self.progress.pellet_start_location[1])
                context.pellet_device.set_dcs_z(self.progress.pellet_start_location[2])
            self._resume_session_actions(context)

        self._evaluate_predicates(context)

    def exit(self, context: PredicateContext) -> None:
        pass

    def session_started(self) -> None:
        self.progress.session_count += 1
        self.progress.progress_resumed()

    def capture_ended(self) -> None:
        self.progress.progress_paused()

    def session_ended(self, context: PredicateContext) -> SessionResult:
        self._evaluate_session_actions(context)

        return self._evaluate_predicates(context)

    def attach(self, context: PredicateContext):
        if self.progress.phase_attempts == 0 and context.pellet_device.last_dcs_set_position is not None:
            self.progress.pellet_start_location = context.pellet_device.last_dcs_set_position
            self.progress.pellet_current_location = context.pellet_device.last_dcs_set_position

    def _evaluate_predicates(self, context: PredicateContext) -> SessionResult:
        self._would_advance = self._on_property_changed("would_advance", self._should_advance(context),
                                                        self._would_advance)

        self._would_fallback = self._on_property_changed("would_fallback", self._should_fallback(context),
                                                         self._would_fallback)

        if self._would_advance:
            return SessionResult.ADVANCE

        if self._would_fallback:
            return SessionResult.FALLBACK

        return SessionResult.NONE

    def _begin_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.begin(self, context)

    def _resume_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.resume(self, context)

    def _evaluate_session_actions(self, context: PredicateContext) -> None:
        context.progress = self.progress
        for action in self.session_actions:
            action.evaluate(self, context)

    def _should_fallback(self, context: PredicateContext) -> bool:
        # Check time elapsed too long without enough successful reaches and revert to the last phase, etc.
        context.progress = self.progress
        if self.fallback_predicate is not None:
            return self.fallback_predicate.evaluate(self, context)

        return False

    def _should_advance(self, context: PredicateContext) -> bool:
        context.progress = self.progress
        # Move to the next training phase when any required conditions are met
        if self.advance_predicate is not None:
            return self.advance_predicate.evaluate(self, context) and self._are_actions_complete()

        if any(action.has_progress for action in self.session_actions):
            return self._are_actions_complete()

        return False

    def _are_actions_complete(self):
        return all(((not action.has_progress) or action.is_complete) for action in self.session_actions)

    def _on_property_changed(self, property_name, new_value, old_value):
        if old_value == new_value:
            return old_value

        for listener in self.property_changed:
            listener(property_name, new_value, old_value)

        return new_value

    def serialize_progress(self) -> Dict[str, Any]:
        progress = self.progress.to_dict()

        progress[ProgressKey.PHASE_ID] = self.phase_id
        progress[ProgressKey.VERSION_ID] = self.version_id
        progress[ProgressKey.ACTION_CONTEXT] = [action.serialize_progress() for action in self.session_actions]

        return progress

    def deserialize_progress(self, progress_item: Dict[str, Any]) -> None:
        self.progress = TrainingProgress.from_dict(progress_item)

        if self.progress.action_context is not None:
            for idx, context in enumerate(self.progress.action_context):
                self.session_actions[idx].deserialize_progress(context)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON serialization"""
        data = {
            "phase_id": self.phase_id,
            "version_id": self.version_id,
            "name": self.name,
            "description": self.description,

            "fallback_predicate": self.fallback_predicate.to_dict() if self.fallback_predicate else None,
            "advance_predicate": self.advance_predicate.to_dict() if self.advance_predicate else None,
            "session_actions": [action.to_dict() for action in self.session_actions],

            "send_x": self.send_x,
            "send_y": self.send_y,
            "send_z": self.send_z,

            "is_pellet_delivery_enabled": self.is_pellet_delivery_enabled,
            "is_pellet_cover_enabled": self.is_pellet_cover_enabled,
            "use_magnet_baseline_intensity": self.use_magnet_baseline_intensity,
            "magnet_intensity": self.magnet_intensity,
            "is_pellet_shift_enabled": self.is_pellet_shift_enabled,
            "is_auto_clamp_enabled": self.is_auto_clamp_enabled,
            "auto_clamp_no_activity_release_delay": self.auto_clamp_no_activity_release_delay,
            "auto_clamp_release_load_count": self.auto_clamp_release_load_count
        }
        return humps.camelize(data)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        """Deserialize from dictionary"""
        data = humps.decamelize(data)
        phase = cls(data["phase_id"])
        phase.version_id = data.get("version_id", 0)
        phase.name = data["name"]
        phase.description = data["description"]

        phase.fallback_predicate = TrainingPredicate.from_dict(data.get("fallback_predicate", None))
        phase.advance_predicate = TrainingPredicate.from_dict(data.get("advance_predicate", None))
        if "session_actions" in data:
            phase.session_actions = [TrainingAction.from_dict(d) for d in data["session_actions"]]
        else:
            phase.session_actions = []

        phase.send_x = data.get("send_x", None)
        phase.send_y = data.get("send_y", None)
        phase.send_z = data.get("send_z", None)

        phase.is_pellet_delivery_enabled = data.get("is_pellet_delivery_enabled", False)
        phase.is_pellet_cover_enabled = data.get("is_pellet_cover_enabled", False)
        phase.use_magnet_baseline_intensity = data.get("use_magnet_baseline_intensity", False)
        phase.magnet_intensity = data.get("magnet_intensity", None)
        phase.is_pellet_shift_enabled = data.get("is_pellet_shift_enabled", False)
        phase.is_auto_clamp_enabled = data.get("is_auto_clamp_enabled", False)
        phase.auto_clamp_no_activity_release_delay = data.get("auto_clamp_no_activity_release_delay", 2.0)
        phase.auto_clamp_release_load_count = data.get("auto_clamp_release_load_count", 5)

        return phase

    def status(self) -> str:
        status = ""

        return status

    def progress_status(self) -> str:
        return self.progress.status()
