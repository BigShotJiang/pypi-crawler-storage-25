from typing import List, Optional


class _NoDefault:
    """Sentinel indicating no default was specified for a configurable property."""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return "_NO_DEFAULT"


_NO_DEFAULT = _NoDefault()


def configurable(aliases: Optional[List[str]] = None, required: bool = True, envelope: bool = False,
                 default=_NO_DEFAULT):
    """Decorator for @property getters marking them as JSON-configurable."""
    def decorator(func):
        func.__configurable__ = {
            "aliases": aliases or [],
            "required": required,
            "envelope": envelope,
            "default": default,
        }
        return func
    return decorator


def context_path(aliases: Optional[List[str]] = None):
    """Decorator for @property getters marking them as navigable runtime context paths."""
    def decorator(func):
        func.__context_path__ = {
            "aliases": aliases or [],
        }
        return func
    return decorator
