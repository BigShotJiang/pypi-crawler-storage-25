import time
from datetime import datetime, timezone
from typing import Dict, Tuple, Any, Optional, List
from typing_extensions import Self

from .configurable import context_path
from .event_slot import EventSlot


class ProgressKey:
    TIMESTAMP = "timestamp"
    TIME_IN_TRAINING = "time_in_training"
    SESSION_COUNT = "session_count"
    PELLETS_PRESENTED = "pellets_presented"
    PELLETS_CONSUMED = "pellets_consumed"
    PELLET_START_LOCATION = "pellet_start_location"
    PELLET_CURRENT_LOCATION = "pellet_current_location"
    SUCCESSFUL_REACHES = "successful_reaches"
    TOTAL_REACHES = "total_reaches"
    PHASE_ATTEMPTS = "phase_attempts"
    ACTION_CONTEXT = "action_context"
    USER_CONTEXT = "user_context"
    PHASE_ID = "phase_id"
    VERSION_ID = "version_id"


class TrainingProgress:
    _context_root = "progress"

    def __init__(self, phase_attempts: int = 0, pellet_start_location: Optional[Tuple[float, float, float]] = None):
        self._phase_attempts: int = phase_attempts
        self._timestamp: Optional[datetime] = None
        self._time_in_training: float = 0.0
        self._session_count: int = 0
        self._pellet_start_location: Optional[Tuple[float, float, float]] = pellet_start_location
        self._pellet_current_location: Optional[Tuple[float, float, float]] = pellet_start_location
        self._pellets_presented: int = 0
        self._pellets_consumed: int = 0
        self._successful_reaches: int = 0
        self._total_reaches: int = 0
        self._action_context: List[Dict[str, Any]] = []
        self._user_context: Dict[str, Any] = {}

        # TODO Timestamp for first attempt, another for current attempt if more than one.  Also, history of progress for
        #  each attempt.

        self._current_timer: float = 0.0

        self.property_changed = EventSlot()

    @property
    def timestamp(self) -> datetime:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value: datetime) -> None:
        self._timestamp = self._on_property_changed("timestamp", value, self._timestamp)

    @property
    @context_path()
    def time_in_training(self) -> float:
        """Seconds spent in training"""
        running = 0 if self._current_timer == 0.0 else time.time() - self._current_timer
        return self._time_in_training + running

    @time_in_training.setter
    def time_in_training(self, value: float) -> None:
        self._time_in_training = self._on_property_changed("time_in_training", value, self._time_in_training)

    @property
    @context_path()
    def session_count(self) -> int:
        """Number of trials (sessions) in the current phase"""
        return self._session_count

    @session_count.setter
    def session_count(self, value: int) -> None:
        self._session_count = self._on_property_changed("session_count", value, self._session_count)

    @property
    @context_path(aliases=["starting send location"])
    def pellet_start_location(self) -> Optional[Tuple[float, float, float]]:
        return self._pellet_start_location

    @pellet_start_location.setter
    def pellet_start_location(self, value: Tuple[float, float, float]) -> None:
        self._pellet_start_location = self._on_property_changed("pellet_start_location", value,
                                                                self._pellet_start_location)

    @property
    @context_path(aliases=["current send location"])
    def pellet_current_location(self) -> Optional[Tuple[float, float, float]]:
        return self._pellet_current_location

    @property
    @context_path()
    def pellets_presented(self) -> int:
        """Pellets presented in the current phase.  A pellet is presented when it is loaded and sent to the 'send' location."""
        return self._pellets_presented

    @pellets_presented.setter
    def pellets_presented(self, value: int) -> None:
        self._pellets_presented = self._on_property_changed("pellets_presented", value, self._pellets_presented)

    @property
    @context_path()
    def pellets_consumed(self) -> int:
        """Pellets consumed in the current phase.  This includes all methods of consumption, including licking and reaching."""
        return self._pellets_consumed

    @pellets_consumed.setter
    def pellets_consumed(self, value: int) -> None:
        self._pellets_consumed = self._on_property_changed("pellets_consumed", value, self._pellets_consumed)

    @pellet_current_location.setter
    def pellet_current_location(self, value: Tuple[float, float, float]) -> None:
        self._pellet_current_location = self._on_property_changed("pellet_current_location", value,
                                                                  self._pellet_current_location)

    @property
    @context_path()
    def successful_reaches(self) -> int:
        """Successful reaches in the current phase where pellets were consumed by a reach event."""
        return self._successful_reaches

    @successful_reaches.setter
    def successful_reaches(self, value: int) -> None:
        self._successful_reaches = self._on_property_changed("successful_reaches", value, self._successful_reaches)

    @property
    @context_path()
    def total_reaches(self) -> int:
        """Total reaches in the current phase inlcuding failed reach attempts where a pellet was not retrieved and consumed."""
        return self._total_reaches

    @total_reaches.setter
    def total_reaches(self, value: int) -> None:
        self._total_reaches = self._on_property_changed("total_reaches", value, self._total_reaches)

    @property
    @context_path(aliases=["attempt"])
    def phase_attempts(self) -> int:
        """Number of times the current phase has been attempted for this animal"""
        return self._phase_attempts

    @phase_attempts.setter
    def phase_attempts(self, value: int) -> None:
        self._phase_attempts = self._on_property_changed("phase_attempts", value, self._phase_attempts)

    @property
    def action_context(self) -> List[Dict[str, Any]]:
        return self._action_context

    @action_context.setter
    def action_context(self, value: List[Dict[str, Any]]) -> None:
        self._action_context = value

    @property
    def user_context(self) -> Dict[str, Any]:
        return self._user_context

    @user_context.setter
    def user_context(self, value: Dict[str, Any]) -> None:
        self._user_context = value

    def progress_resumed(self):
        if self._timestamp is None:
            self.timestamp = datetime.now(tz=timezone.utc)

        self._current_timer = time.time()

    def progress_paused(self):
        self.time_in_training += time.time() - self._current_timer

        self._current_timer = 0.0

    def _on_property_changed(self, property_name, new_value, old_value):
        if old_value == new_value:
            return old_value

        for listener in self.property_changed:
            listener(property_name, new_value, old_value)

        return new_value

    def to_dict(self) -> Dict[str, Any]:
        return {
            ProgressKey.TIMESTAMP: self.timestamp.isoformat() if self.timestamp else None,
            ProgressKey.TIME_IN_TRAINING: self.time_in_training,
            ProgressKey.SESSION_COUNT: self.session_count,
            ProgressKey.PELLETS_PRESENTED: self.pellets_presented,
            ProgressKey.PELLETS_CONSUMED: self.pellets_consumed,
            ProgressKey.PELLET_START_LOCATION: list(self.pellet_start_location) if self.pellet_start_location else None,
            ProgressKey.PELLET_CURRENT_LOCATION: list(
                self.pellet_current_location) if self.pellet_current_location else None,
            ProgressKey.SUCCESSFUL_REACHES: self.successful_reaches,
            ProgressKey.TOTAL_REACHES: self.total_reaches,
            ProgressKey.PHASE_ATTEMPTS: self.phase_attempts,
            ProgressKey.USER_CONTEXT: self.user_context,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> Self:
        progress = cls()
        progress.timestamp = (datetime.fromisoformat(data[ProgressKey.TIMESTAMP])
                              if data.get(ProgressKey.TIMESTAMP) else None)
        progress.time_in_training = float(data[ProgressKey.TIME_IN_TRAINING])
        progress.session_count = int(data[ProgressKey.SESSION_COUNT])
        progress.pellets_presented = int(data.get(ProgressKey.PELLETS_PRESENTED, 0))
        progress.pellets_consumed = int(data[ProgressKey.PELLETS_CONSUMED])

        location: List[float] = data.get(ProgressKey.PELLET_START_LOCATION)
        if location is not None:
            progress.pellet_start_location = tuple(location)
        else:
            progress.pellet_start_location = None

        location: List[float] = data.get(ProgressKey.PELLET_CURRENT_LOCATION)
        if location is not None:
            progress.pellet_current_location = tuple(location)
        else:
            progress.pellet_current_location = None

        progress.successful_reaches = int(data.get(ProgressKey.SUCCESSFUL_REACHES, 0))
        progress.total_reaches = int(data.get(ProgressKey.TOTAL_REACHES, 0))
        progress.phase_attempts = int(data.get(ProgressKey.PHASE_ATTEMPTS, 0))
        progress.action_context = data.get(ProgressKey.ACTION_CONTEXT, None)
        progress.user_context = data.get(ProgressKey.USER_CONTEXT, {})

        return progress

    def status(self) -> str:
        status = ""

        def add_line(line: str) -> None:
            nonlocal status
            status += f"{line}\n"

        def add_prop(line: str) -> None:
            add_line(f"  {line}")

        add_prop(f"Start: {self.timestamp}")
        add_prop(f"Attempts: {self.phase_attempts}")
        add_prop(f"Sessions: {self.session_count}")
        add_prop(f"Pellets presented: {self.pellets_presented}")
        add_prop(f"Pellets consumed: {self.pellets_consumed}")
        add_prop(f"Reaches: {self.successful_reaches}")
        add_prop(f"Total reaches: {self.total_reaches}")

        return status
