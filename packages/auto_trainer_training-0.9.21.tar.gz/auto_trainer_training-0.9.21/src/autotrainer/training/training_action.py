from sys import float_info
from typing import List, Optional, Dict, Any, Tuple, Union

from typing_extensions import Self

from autotrainer.core import get_verbose_logger

from .configurable import configurable
from .training_predicate import TrainingPredicate
from .training_protocols import (TrainingActionProtocol, TrainingPhaseProtocol, PredicateContext,
                                 class_from_dict, class_to_dict, TrainingPredicateProtocol)
from .value_provider import BooleanValueProvider, ValueProvider

logger = get_verbose_logger(__name__)

_FLOAT_COMPARISON = float_info.epsilon * 2


class TrainingAction(TrainingActionProtocol):
    def __init__(self, predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        self._predicate = predicate
        self._min_trials_to_complete = min_trials_to_complete

        self._is_complete: bool = False
        self._min_trials_met: bool = True
        self._trial_count_at_begin: int = 0

    @property
    @configurable(required=False, envelope=True, default=None)
    def predicate(self) -> Optional[TrainingPredicateProtocol]:
        return self._predicate

    @predicate.setter
    def predicate(self, value: Optional[TrainingPredicateProtocol]) -> None:
        self._predicate = value

    @property
    @configurable(required=False, default=0)
    def min_trials_to_complete(self) -> int:
        return self._min_trials_to_complete

    @min_trials_to_complete.setter
    def min_trials_to_complete(self, value: int) -> None:
        self._min_trials_to_complete = value

    @property
    def has_progress(self) -> bool:
        return self.predicate is not None or self.min_trials_to_complete > 0

    @property
    def is_complete(self) -> bool:
        if not self._min_trials_met:
            return False
        if self.predicate is None:
            return True
        return self._is_complete

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        if context.progress is not None:
            self._trial_count_at_begin = context.progress.session_count
        else:
            self._trial_count_at_begin = 0

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        pass

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        if self.min_trials_to_complete > 0:
            self._min_trials_met = (context.progress is not None
                                    and (context.progress.session_count - self._trial_count_at_begin)
                                    >= self.min_trials_to_complete)
        else:
            self._min_trials_met = True

        if self.predicate is not None:
            if self._min_trials_met:
                self._is_complete = self.predicate.evaluate(phase, context)
            else:
                self._is_complete = False
        return False

    def serialize_progress(self) -> Dict[str, Any]:
        return {"trial_count_at_begin": self._trial_count_at_begin}

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        self._trial_count_at_begin = data.get("trial_count_at_begin", 0)

    def _to_dict(self) -> Optional[Dict[str, Any]]:
        result = {}
        if self.predicate is not None:
            result["predicate"] = self.predicate.to_dict()
        if self.min_trials_to_complete > 0:
            result["min_trials_to_complete"] = self.min_trials_to_complete
        return result if result else None

    def to_dict(self) -> Dict[str, Any]:
        return class_to_dict(self.__class__.__name__, self.__class__.__module__, self._to_dict())

    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]]) -> Optional[Self]:
        return class_from_dict(data)

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(predicate=predicate, min_trials_to_complete=min_trials_to_complete)


class HeadMagnetIntensityAction(TrainingAction):
    def __init__(self, start: float, increment: float, end: float, pellet_delta: int,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._start = start
        self._increment = increment
        self._end = end
        self._pellet_delta = pellet_delta

        self.increment_start_pellet_count = 0
        self.current_intensity = 0

    @property
    @configurable()
    def start(self) -> float:
        return self._start

    @start.setter
    def start(self, value: float) -> None:
        self._start = value

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @increment.setter
    def increment(self, value: float) -> None:
        self._increment = value

    @property
    @configurable()
    def end(self) -> float:
        return self._end

    @end.setter
    def end(self, value: float) -> None:
        self._end = value

    @property
    @configurable(aliases=["pellet delta"])
    def pellet_delta(self) -> int:
        return self._pellet_delta

    @pellet_delta.setter
    def pellet_delta(self, value: int) -> None:
        self._pellet_delta = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        if not super().is_complete:
            return False
        return abs(self.current_intensity) >= self.end - _FLOAT_COMPARISON

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self.increment_start_pellet_count = context.progress.pellets_consumed
        self.current_intensity = self.start
        if context.tunnel_device is not None:
            context.tunnel_device.update_head_magnet_intensity(self.start)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if context.tunnel_device is not None:
            context.tunnel_device.update_head_magnet_intensity(self.current_intensity)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)
        if context.progress is None or context.tunnel_device is None:
            return False
        if context.progress.pellets_consumed - self.increment_start_pellet_count > self.pellet_delta:
            current = context.tunnel_device.head_magnet_intensity
            if current is None:
                current = self.current_intensity
            intensity = min(self.end, current + self.increment)
            self.current_intensity = intensity
            self.increment_start_pellet_count = context.progress.pellets_consumed
            context.tunnel_device.update_head_magnet_intensity(intensity)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "current_intensity": self.current_intensity,
            "increment_start_pellet_count": self.increment_start_pellet_count,
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self.current_intensity = data["current_intensity"]
        self.increment_start_pellet_count = data.get(
            "increment_start_pellet_count", data.get("pellet_start", 0)
        )

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "start": self.start,
            "increment": self.increment,
            "end": self.end,
            "pellet_delta": self.pellet_delta
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(data["start"], data["increment"], data["end"], data["pellet_delta"],
                   predicate, min_trials_to_complete)


class ReachDistanceAction(TrainingAction):
    def __init__(self, increment: float, distance: float, pellet_delta: int,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._increment = increment
        self._distance = distance
        self._pellet_delta = pellet_delta

        self.current_increment_pellet_count = 0
        self.initial_y = 0
        self.current_delta_y = 0
        self.distance_reached_pellet_count = 0

    @property
    @configurable()
    def increment(self) -> float:
        return self._increment

    @increment.setter
    def increment(self, value: float) -> None:
        self._increment = value

    @property
    @configurable(aliases=["reach distance"])
    def distance(self) -> float:
        return self._distance

    @distance.setter
    def distance(self, value: float) -> None:
        self._distance = value

    @property
    @configurable(aliases=["pellet delta"])
    def pellet_delta(self) -> int:
        return self._pellet_delta

    @pellet_delta.setter
    def pellet_delta(self, value: int) -> None:
        self._pellet_delta = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def _has_reached_distance(self) -> bool:
        return abs(self.current_delta_y) >= self.distance - _FLOAT_COMPARISON

    @property
    def is_complete(self) -> bool:
        if not super().is_complete:
            return False
        if not self._has_reached_distance:
            return False
        if self.distance_reached_pellet_count == 0:
            return False
        return self.current_increment_pellet_count - self.distance_reached_pellet_count >= self.pellet_delta

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self.current_increment_pellet_count = context.progress.pellets_consumed
        if context.pellet_device is not None and context.pellet_device.last_dcs_set_position is not None:
            self.initial_y = context.pellet_device.last_dcs_set_position.y
        self.current_delta_y = 0
        self.distance_reached_pellet_count = 0

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if context.pellet_device is not None:
            context.pellet_device.set_dcs_y(self.initial_y + self.current_delta_y)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)
        if context.progress is None or context.pellet_device is None:
            return False
        if context.progress.pellets_consumed - self.current_increment_pellet_count > self.pellet_delta:
            self.current_increment_pellet_count = context.progress.pellets_consumed
            if not self._has_reached_distance:
                last_position = context.pellet_device.last_dcs_set_position
                if last_position is None:
                    return False
                distance = min(self.initial_y + self.distance, last_position.y + self.increment)
                self.current_delta_y = distance - self.initial_y
                context.pellet_device.set_dcs_y(distance)
                if self._has_reached_distance:
                    self.distance_reached_pellet_count = self.current_increment_pellet_count
            elif self.distance_reached_pellet_count == 0:
                self.distance_reached_pellet_count = self.current_increment_pellet_count

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "current_increment_pellet_count": self.current_increment_pellet_count,
            "initial_y": self.initial_y,
            "current_delta_y": self.current_delta_y,
            "distance_reached_pellet_count": self.distance_reached_pellet_count
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self.current_increment_pellet_count = data.get("current_increment_pellet_count", 0)
        self.initial_y = data.get("initial_y", 0.0)
        self.current_delta_y = data.get("current_delta_y", 0.0)
        self.distance_reached_pellet_count = data.get("distance_reached_pellet_count", 0)

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "distance": self.distance,
            "increment": self.increment,
            "pellet_delta": self.pellet_delta
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(data["increment"], data["distance"], data["pellet_delta"],
                   predicate, min_trials_to_complete)


class CompoundTrainingAction(TrainingAction):
    def __init__(self, actions: Optional[List[TrainingAction]] = None,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._actions: List[TrainingAction] = list(actions) if actions else []
        self._active_index: int = 0

    @property
    @configurable(envelope=True)
    def actions(self) -> Tuple[TrainingAction, ...]:
        return tuple(self._actions)

    @actions.setter
    def actions(self, value: List[TrainingAction]) -> None:
        self._actions = list(value)
        self._active_index = 0

    def add_action(self, action: TrainingAction) -> None:
        self._actions.append(action)

    def remove_action(self, index: int) -> None:
        self._actions.pop(index)

    def clear_actions(self) -> None:
        self._actions.clear()
        self._active_index = 0

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        if not super().is_complete:
            return False
        if not self._actions:
            return True
        if self._active_index < len(self._actions) - 1:
            return False
        return self._actions[-1].is_complete

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        if self._actions:
            self._actions[0].begin(phase, context)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if self._actions and self._active_index < len(self._actions):
            self._actions[self._active_index].resume(phase, context)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)

        if not self._actions:
            return True

        active_action = self._actions[self._active_index]

        active_action.evaluate(phase, context)

        if active_action.is_complete:
            if self._active_index < len(self._actions) - 1:
                self._active_index += 1
                self._actions[self._active_index].begin(phase, context)
                return False
            return True

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "active_index": self._active_index,
            "action_progress": [action.serialize_progress() for action in self._actions]
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self._active_index = data["active_index"]
        action_progress = data["action_progress"]
        for idx, action in enumerate(self._actions):
            if idx < len(action_progress):
                action.deserialize_progress(action_progress[idx])

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "actions": [action.to_dict() for action in self._actions]
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        actions = [TrainingAction.from_dict(entry) for entry in data["actions"]]
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(actions, predicate, min_trials_to_complete)


class ShuffledPropertyEnabledAction(TrainingAction):
    def __init__(self, property_path: str, value: bool, count: int, percentage: float,
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0,
                 linked_property_paths: Optional[List[List[str]]] = None,
                 conditional_providers: Optional[List[Tuple[List[str], ValueProvider]]] = None):
        super().__init__(predicate, min_trials_to_complete)
        if not isinstance(property_path, list):
            self._property_path: List[str] = property_path.split(".")
        else:
            self._property_path = property_path
        self._value = value
        self._count = count
        self._percentage = percentage
        self._linked_property_paths: List[List[str]] = linked_property_paths if linked_property_paths else []
        self._conditional_providers: List[Tuple[List[str], ValueProvider]] = (
            conditional_providers if conditional_providers else [])
        self._provider = BooleanValueProvider(value, count, percentage, shuffle=True)

    @property
    @configurable()
    def property_path(self) -> List[str]:
        """Runtime context path to the property toggled each trial."""
        return self._property_path

    @property_path.setter
    def property_path(self, value: List[str]) -> None:
        self._property_path = value

    @property
    @configurable()
    def value(self) -> bool:
        return self._value

    @value.setter
    def value(self, val: bool) -> None:
        self._value = val

    @property
    @configurable()
    def count(self) -> int:
        return self._count

    @count.setter
    def count(self, value: int) -> None:
        self._count = value

    @property
    @configurable()
    def percentage(self) -> float:
        return self._percentage

    @percentage.setter
    def percentage(self, value: float) -> None:
        self._percentage = value

    @property
    @configurable(required=False)
    def linked_property_paths(self) -> List[List[str]]:
        return self._linked_property_paths

    @linked_property_paths.setter
    def linked_property_paths(self, value: List[List[str]]) -> None:
        self._linked_property_paths = value

    @property
    @configurable(required=False)
    def conditional_providers(self) -> List[Tuple[List[str], ValueProvider]]:
        """Each entry is a [propertyPath, valueProviderEnvelope] pair applied when the primary value matches."""
        return self._conditional_providers

    @conditional_providers.setter
    def conditional_providers(self, value: List[Tuple[List[str], ValueProvider]]) -> None:
        self._conditional_providers = value

    def _apply_provider_value(self, context: PredicateContext) -> None:
        next_value = self._provider.get_next_value()
        result = context.resolve_path_parent(self.property_path)
        if result is not None:
            setattr(result[0], result[1], next_value)
        else:
            logger.warning(f"failed to resolve property path {self.property_path} on context")
        for linked_path in self.linked_property_paths:
            linked_result = context.resolve_path_parent(linked_path)
            if linked_result is not None:
                setattr(linked_result[0], linked_result[1], next_value)
            else:
                logger.warning(f"failed to resolve linked property path {linked_path} on context")
        if next_value == self.value:
            for cp_path, cp_provider in self.conditional_providers:
                cp_result = context.resolve_path_parent(cp_path)
                if cp_result is not None:
                    setattr(cp_result[0], cp_result[1], cp_provider.get_next_value())
                else:
                    logger.warning(f"failed to resolve conditional provider path {cp_path} on context")

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self._apply_provider_value(context)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)
        self._apply_provider_value(context)
        return False

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "property_path": self.property_path,
            "value": self.value,
            "count": self.count,
            "percentage": self.percentage,
        }
        if self.linked_property_paths:
            result["linked_property_paths"] = self.linked_property_paths
        if self.conditional_providers:
            result["conditional_providers"] = [
                {"property_path": cp_path, "value_provider": cp_provider.to_dict()}
                for cp_path, cp_provider in self.conditional_providers
            ]
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        linked_property_paths = data.get("linked_property_paths", [])
        conditional_providers = [
            (entry["property_path"], class_from_dict(entry["value_provider"]))
            for entry in data.get("conditional_providers", [])
        ]
        return cls(data["property_path"], data["value"], data["count"], data["percentage"],
                   predicate, min_trials_to_complete, linked_property_paths, conditional_providers)


class RepeatedTrainingAction(TrainingAction):
    def __init__(self, action: TrainingAction, value_provider: ValueProvider, property_path: Union[List[str], str],
                 predicate: Optional[TrainingPredicateProtocol] = None, min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)

        if isinstance(property_path, list):
            self._property_path: List[str] = property_path
        else:
            self._property_path = property_path.split(".")

        self._value_provider = value_provider
        self._action_dict = action.to_dict()
        self._current_action: TrainingAction = action
        self._values_consumed: int = 0
        self._last_applied_value = None

    @property
    @configurable()
    def property_path(self) -> List[str]:
        """Runtime context path where each value from the provider is written."""
        return self._property_path

    @property_path.setter
    def property_path(self, value: List[str]) -> None:
        self._property_path = value

    @property
    @configurable(envelope=True)
    def action(self) -> TrainingAction:
        return self._current_action

    @action.setter
    def action(self, value: TrainingAction) -> None:
        self._current_action = value
        self._action_dict = value.to_dict()

    @property
    @configurable(envelope=True)
    def value_provider(self) -> ValueProvider:
        return self._value_provider

    @value_provider.setter
    def value_provider(self, value: ValueProvider) -> None:
        self._value_provider = value

    @property
    def has_progress(self) -> bool:
        return True

    @property
    def is_complete(self) -> bool:
        return self.is_iteration_complete and not self._value_provider.has_next_value()

    @property
    def is_iteration_complete(self) -> bool:
        return self._current_action.is_complete and super().is_complete

    def _apply_next_value(self, context: PredicateContext) -> None:
        self._last_applied_value = self._value_provider.get_next_value()
        self._values_consumed += 1
        result = context.resolve_path_parent(self.property_path)
        if result is not None:
            setattr(result[0], result[1], self._last_applied_value)

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self._apply_next_value(context)
        self._current_action.begin(phase, context)

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        if self._last_applied_value is not None:
            result = context.resolve_path_parent(self.property_path)
            if result is not None:
                setattr(result[0], result[1], self._last_applied_value)
        self._current_action.resume(phase, context)

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)

        self._current_action.evaluate(phase, context)

        if self.is_iteration_complete and self._value_provider.has_next_value():
            self._apply_next_value(context)
            self._current_action = TrainingAction.from_dict(self._action_dict)  # type: ignore
            self._current_action.begin(phase, context)

        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress.update({
            "values_consumed": self._values_consumed,
            "last_applied_value": self._last_applied_value,
            "action_progress": self._current_action.serialize_progress()
        })
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        values_consumed = data.get("values_consumed", 0)
        for _ in range(values_consumed):
            if self._value_provider.has_next_value():
                self._value_provider.get_next_value()
        self._values_consumed = values_consumed
        self._last_applied_value = data.get("last_applied_value")
        if values_consumed > 1:
            self._current_action = TrainingAction.from_dict(self._action_dict)  # type: ignore
        self._current_action.deserialize_progress(data.get("action_progress", {}))

    def _to_dict(self) -> Dict[str, Any]:
        result = {
            "action": self._action_dict,
            "value_provider": self._value_provider.to_dict(),
            "property_path": self.property_path
        }
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        action = TrainingAction.from_dict(data["action"])
        value_provider = class_from_dict(data["value_provider"])
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(action, value_provider, data["property_path"], predicate, min_trials_to_complete)


class PythonTrainingAction(TrainingAction):
    def __init__(self, python_code: str, predicate: Optional[TrainingPredicateProtocol] = None,
                 min_trials_to_complete: int = 0):
        super().__init__(predicate, min_trials_to_complete)
        self._python_code = python_code
        self._compiled_code = None
        self._state: Dict[str, Any] = {}

    @property
    @configurable()
    def python_code(self) -> str:
        return self._python_code

    @python_code.setter
    def python_code(self, value: str) -> None:
        self._python_code = value
        self._compiled_code = None

    def _ensure_compiled(self) -> None:
        if self._compiled_code is None:
            self._compiled_code = compile(self._python_code, "<PythonTrainingAction>", "exec")

    def begin(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().begin(phase, context)
        self._state = {}
        self._ensure_compiled()

    def resume(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> None:
        super().resume(phase, context)
        self._ensure_compiled()

    def evaluate(self, phase: TrainingPhaseProtocol, context: PredicateContext) -> bool:
        super().evaluate(phase, context)
        self._ensure_compiled()
        namespace = {"context": context, "phase": phase, "state": self._state}
        try:
            exec(self._compiled_code, namespace)
        except Exception:
            logger.error("PythonTrainingAction error evaluating: %s", self._python_code, exc_info=True)
        return False

    def serialize_progress(self) -> Dict[str, Any]:
        progress = super().serialize_progress()
        progress["state"] = self._state
        return progress

    def deserialize_progress(self, data: Dict[str, Any]) -> None:
        super().deserialize_progress(data)
        self._state = data.get("state", {})

    def _to_dict(self) -> Dict[str, Any]:
        result = {"python_code": self.python_code}
        base = super()._to_dict()
        if base is not None:
            result.update(base)
        return result

    @classmethod
    def from_properties(cls, data: Dict[str, Any]) -> Self:
        python_code = data["python_code"]
        predicate = TrainingPredicate.from_dict(data.get("predicate"))
        min_trials_to_complete = data.get("min_trials_to_complete", 0)
        return cls(python_code, predicate, min_trials_to_complete)
