"""Version information for eq-chatbot-core."""

__version__ = "1.7.0"
