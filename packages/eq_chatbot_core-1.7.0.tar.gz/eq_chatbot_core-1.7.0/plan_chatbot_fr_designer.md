# Plan: KI-Assistent im fr-designer via gebundeltem `eq_chatbot_core`-Sidecar

## Context

Der fr-designer (Avalonia 11.3 / .NET 10, eingebetteter FastReport-Designer) soll kontextbasierte KI-Assistenz direkt im Designer bekommen — Chat-Tool-Window neben dem Designer, mit Function-Calling damit die KI konkrete Designer-Aktionen vorschlagen kann (Expression einfügen, Band hinzufügen, Feldbinding setzen). Backend ist die bereits bei Equitania eingesetzte Python-Library `eq_chatbot_core` (`/Users/picard/gitbase/PyPi-Projects/eq_chatbot_core`), die LLM-Provider-Abstraktion (OpenAI, Anthropic, LangDock, …), Streaming, Tool-Calling und RAG mitbringt. Die Library bringt heute nur ein Stdin/Stdout-CLI mit — wir erweitern sie um einen FastAPI/SSE-Server-Mode (`eq-chatbot serve`), bundeln die Library mit der App als lokalen Sidecar (Python-Runtime via PyInstaller frozen ins jeweilige Plattform-Paket) und sprechen sie aus C# via `HttpClient` + SSE an. Zero-Install beim End-User, Provider/API-Key in Avalonia-Settings (DPAPI/AES-GCM dual-path wie `LicenseStore`), Tool-Calling mit User-Confirmation vor jeder Designer-Modifikation.

## Verifizierte Fakten (aus Phase-1-Exploration)

**eq_chatbot_core:**
- Public-API: `eq_chatbot_core.providers.get_provider("openai", api_key=...)` → `BaseLLMProvider` mit `chat_completion(messages, model, tools, ...)` und `stream_completion(...)` (synchroner Iterator über `StreamChunk`).
- Provider: OpenAI, Anthropic, Azure, Vertex, LangDock, OpenRouter, Mammouth, Local (LM-Studio/Ollama). Factory in `providers/__init__.py`.
- Tool-Calling vollständig durchgezogen (`LLMResponse.tool_calls`, `StreamChunk.tool_call_delta`).
- RAG-Pipeline mit Qdrant + `DocumentChunker` + `Embedder` + `ContextWindowManager` vorhanden.
- Bestehendes CLI: `eq-chatbot chat` (Single-Shot JSON in/out, kein Stream). Kein FastAPI-Server eingebaut.

**fr-designer:**
- FastReport-Designer ist eigenes Top-Level-`Window` (kein Container/DockSlot). Reflection-Hooks in `_report.Designer.MainMenu.miHelp.DropDownItems` bewährt (`AddAboutMenuItem`-Pattern).
- Kein Plugin-API in FastReport.Avalonia 2026.2.1.
- Kein `HttpClient`, kein Markdown-Renderer, kein WebView heute im Code.
- Report-Kontext lesbar via `_report.Dictionary` (Datasources/Fields/Parameters), `_report.AllObjects` (Bands/Objekte). `SelectedObjects` ist in der Avalonia-SKU **nicht öffentlich dokumentiert** — Reflection-Probe nötig, ungewiss.
- Existierende Patterns wiederverwendbar: `LicenseStore.cs` (DPAPI/AES-GCM), `AboutWindow.axaml` (Window-Template), `MessageBoxWindow.axaml` (Modal-Pattern), `ComponentVersions.cs` (Assembly-Reflection).

## Architektur

```
┌──────────────────────────────────────────────┐
│ fr-designer (.app / .deb / .exe)              │
│ ┌────────────────────┐  ┌──────────────────┐ │
│ │ Avalonia UI         │  │ AiSidecarManager │ │
│ │ - FR Designer-Win   │  │ - spawn process  │ │
│ │ - AiToolWindow      │  │ - port-discovery │ │
│ │   (Topmost, Owner=  │  │ - random auth    │ │
│ │    designerWindow)  │  │   token/session  │ │
│ │ - AiSettingsDialog  │  │ - health watchdog│ │
│ └────────────────────┘  └──────────────────┘ │
│         ↓ HttpClient + SSE (Authorization:    │
│            Bearer <random session token>)     │
│   http://127.0.0.1:<ephemeral port>           │
├────────────────────────────────────────────────┤
│ Gebundelter Sidecar (PyInstaller frozen):      │
│  - Python-Runtime + eq_chatbot_core + FastAPI  │
│  - Endpoints: /chat /chat/stream /providers    │
│    /models /tools/result /health               │
│  - Bind 127.0.0.1, port=0 (ephemeral),         │
│    --auth-token aus stdin                      │
│  - Parent-watchdog: SIGTERM bei Parent-Exit    │
└────────────────────────────────────────────────┘
```

**Sicherheits-Modell:** Sidecar hört nur auf 127.0.0.1, ephemeral Port (Port 0), per-Session Auth-Token (random GUID, von C# generiert, an Sidecar via `--auth-token-fd 0` über Stdin gepiped — landet nie auf Disk, nicht in Logs, nicht in Process-CmdLine). API-Keys werden per Request im Header mitgeschickt (nicht beim Sidecar-Start), so dass eine Sidecar-Memory-Inspection nur eine Session sieht.

## Kritische Files

### Neu zu erstellen

| Datei | Zweck |
|---|---|
| `eq_chatbot_core/server/__init__.py` | FastAPI-App mit `/chat`, `/chat/stream` (SSE), `/providers`, `/models`, `/tools/result`, `/health` |
| `eq_chatbot_core/server/auth.py` | Bearer-Token-Validation Middleware |
| `eq_chatbot_core/server/streaming.py` | `StreamChunk` → SSE-Events (`event: chunk`, `event: tool_call`, `event: done`, `event: error`) |
| `eq_chatbot_core/cli.py` (Erweiterung) | Neuer Subcommand `eq-chatbot serve --port 0 --auth-token-fd 0 --parent-pid <pid>` |
| `Packaging/sidecar/sidecar.spec` | PyInstaller-Spec (eq_chatbot_core + uvicorn + fastapi gefroren in eine Single-File-Binary) |
| `scripts/build-sidecar.sh` | Plattform-spezifischer Build der Sidecar-Binary, Output nach `Packaging/sidecar/{macos,linux,windows}/eq-chatbot-sidecar[.exe]` |
| `Odoo2FastReport.Designer.Avalonia/Ai/SidecarManager.cs` | Process-Spawn, Port-Discovery via Stdout-Read, Health-Loop, Shutdown-Hook |
| `Odoo2FastReport.Designer.Avalonia/Ai/AiClient.cs` | `HttpClient`-Wrapper mit SSE-Reader (`HttpResponseMessage.Content.ReadAsStream` + `StreamReader.ReadLineAsync`) |
| `Odoo2FastReport.Designer.Avalonia/Ai/Tools/ToolRegistry.cs` | C#-Tool-Implementierungen für AI-Function-Calls (insert_text, set_expression, add_band, suggest_field_binding) |
| `Odoo2FastReport.Designer.Avalonia/Ai/Tools/ToolConfirmDialog.axaml(.cs)` | User-Bestätigung mit Diff-Preview vor jeder Designer-Modifikation |
| `Odoo2FastReport.Designer.Avalonia/Ai/ReportContextProvider.cs` | Liest `_report.Dictionary` / `_report.AllObjects` und EqCoreFunctions-Signatur, baut System-Prompt-Prefix |
| `Odoo2FastReport.Designer.Avalonia/Ai/AiSettingsStore.cs` | Provider/API-Key-Storage (DPAPI/AES-GCM), gleiches Pattern wie `LicenseStore.cs` |
| `Odoo2FastReport.Designer.Avalonia/AiToolWindow.axaml(.cs)` | Non-modales Avalonia-Window: Chat-Historie, Input, Streaming-Output mit Markdown-Rendering, Tool-Call-Cards |
| `Odoo2FastReport.Designer.Avalonia/AiSettingsDialog.axaml(.cs)` | Provider-/Modell-/Token-Konfig |

### Zu ändern

| Datei | Änderung |
|---|---|
| `eq_chatbot_core/pyproject.toml` | Optional-Extra `[server]` (fastapi, uvicorn, sse-starlette) |
| `Odoo2FastReport.Designer.Avalonia/Odoo2FastReport.Designer.Avalonia.csproj` | NuGet `Markdown.Avalonia` für Chat-Rendering |
| `Odoo2FastReport.Designer.Avalonia/MainWindow.axaml.cs::StartDesigner()` | Nach `AddAboutMenuItem(designerWindow)` zusätzlich `AddAiAssistantMenuItem(designerWindow)` (gleiches Reflection-Pattern, `miHelp.DropDownItems`) — öffnet `AiToolWindow` non-modal mit `Owner = designerWindow` |
| `Odoo2FastReport.Designer.Avalonia/App.axaml.cs::OnFrameworkInitializationCompleted()` | Sidecar-Manager starten (early), Shutdown-Hook in Lifetime |
| `scripts/build-macos.sh` | Sidecar-Binary in `Contents/MacOS/eq-chatbot-sidecar` kopieren, Codesigning-Step für die Binary, Notarization-konform |
| `scripts/build-linux.sh` | Sidecar-Binary nach `usr/lib/odoo2fastreport-designer/eq-chatbot-sidecar` einbetten, dpkg-control-Größe anpassen |
| `scripts/build-windows.ps1` | Sidecar-Binary in ClickOnce-Drop, `signtool sign` auch für die `.exe` |
| `Packaging/macos/Info.plist.template` | Falls App-Sandbox aktiv: `com.apple.security.network.server` Entitlement (localhost-bind) — vermutlich nicht nötig wenn nicht sandbox-fähig |
| `RELEASE_NOTES.md` + `README.md` | Neue Sektion "AI Assistant", Sidecar-Anforderungen, Provider-Setup-Anleitung |

### Bestehende Funktionen wiederverwenden

| Pattern | Quelle | Wiederverwendung |
|---|---|---|
| Encrypted-storage dual-path (DPAPI/AES-GCM) | `LicenseStore.cs` | `AiSettingsStore.cs` für API-Key-Persistierung |
| Reflection-Hook in FR-Designer-Menü | `MainWindow.AddAboutMenuItem()` | `AddAiAssistantMenuItem()` analog |
| Avalonia-Window-Template + Logo | `AboutWindow.axaml` | `AiToolWindow.axaml`, `AiSettingsDialog.axaml` |
| Modal-Dialog-Pattern | `MessageBoxWindow.axaml` | `ToolConfirmDialog.axaml` für Diff-Preview |
| Assembly-Attribute-Reflection | `ComponentVersions.cs::Collect()` | `ReportContextProvider` für EqCoreFunctions-Signatur |
| Provider-Factory Python | `eq_chatbot_core.providers.get_provider()` | unverändert in Server aufrufen |
| Stream-Iterator Python | `provider.stream_completion()` | direkt nach SSE übersetzen |

## Phasing

| Phase | Inhalt | Aufwand | Liefert |
|---|---|---|---|
| **1** | `eq-chatbot serve`-Subcommand mit FastAPI/SSE in `eq_chatbot_core` | 3–5 Tage | Server lokal startbar, manuell mit `curl` testbar |
| **2** | Sidecar-Packaging (PyInstaller/pyoxidizer-Spec, Build-Skripts pro Plattform, Code-Signing) | 5–7 Tage | Single-File-Binary pro OS in `Packaging/sidecar/` |
| **3** | C# `SidecarManager` + `AiClient` (HTTP + SSE) | 3–5 Tage | App spawnt Sidecar, kann via `HttpClient` chatten (Console-Log-Smoke-Test) |
| **4** | `AiToolWindow` UI (Chat-History, Streaming, Markdown-Rendering, Settings-Dialog, encrypted Key-Store) | 5–7 Tage | Help-Menü → AI Assistant → funktionsfähiger Standalone-Chat |
| **5** | `ReportContextProvider` — System-Prompt mit Datasources/Fields/EqCoreFunctions-Signatur | 2–3 Tage | KI kennt den Report-Kontext und kann konkret zu vorhandenen Feldern antworten |
| **6** | Tool-Calling: Tool-Schema, ToolRegistry, ToolConfirmDialog, Reflection-basierte Designer-Mods (Text einfügen, Expression setzen, Band hinzufügen) | 7–10 Tage | KI darf Aktionen vorschlagen, User klickt Apply, Designer wird modifiziert |

**Gesamt für Voll-MVP:** ~5–7 Wochen.

**Inkrementelle Auslieferbarkeit:** Nach Phase 4 ist bereits ein nutzbares Feature da (Help-Menü → Chat). Phase 5 + 6 bauen darauf auf, jeder Phase-Abschluss wäre release-fähig.

## Risiken & Offene Punkte

| Risiko | Mitigierung / Plan |
|---|---|
| **PyInstaller-Bundle-Größe** (Python + uvicorn + provider SDKs ≈ 100–200 MB pro OS, macOS universal ≈ 250 MB) — verdoppelt die App-Distribution-Größe. | Akzeptieren als Kosten von "Zero-Install". Optional Provider-SDKs lazy-load (nur das ausgewählte Provider-Backend importieren) — kann Bundle um 30–50 MB reduzieren. Alternativ Bundle-Strip via `--exclude-module`. |
| **Sidecar-Lifecycle / Zombies** | Parent-PID an Sidecar via `--parent-pid`, Watchdog-Thread killt sich selbst bei Parent-Tod (Linux: `prctl(PR_SET_PDEATHSIG)`, macOS/Windows: 5s-Poll auf `psutil.pid_exists`). C#-Seite registriert `AppDomain.CurrentDomain.ProcessExit` → SIGTERM, dann SIGKILL nach 3s. |
| **Code-Signing der gebundelten Python-Runtime** auf macOS — Hardened Runtime + Notarization brauchen ggf. `com.apple.security.cs.allow-unsigned-executable-memory` Entitlement (für JIT-Komponenten in Python). | In Phase 2 mit Test-Notary-Build verifizieren. Falls Entitlement nicht akzeptiert wird → PyInstaller `--target-arch` + `codesign --deep` mit `--entitlements`-File. Backup: Sidecar-Binary separat neben `.app` ausliefern (Helper-Tool-Pattern wie 1Password's `op-helper`). |
| **`SelectedObjects` evtl. nicht in FR.Avalonia public** | In Phase 6: Reflection-Dump auf `_report.Designer` zur Laufzeit. Fallback wenn Property fehlt: Tool-Calls erwarten `target_object_name` als String-Parameter, AI muss aus dem Kontext den Namen ableiten. Funktional weniger smooth, aber implementierbar. |
| **Auth-Token-Übergabe an Sidecar** — Argv ist auf Linux/macOS lesbar. | Stdin-Übergabe (`--auth-token-fd 0`): C# spawnt mit Stdin-Pipe, schreibt das Token einmalig hinein, schließt Stdin. Sidecar liest beim Boot 32 Bytes von FD 0, vergleicht alle eingehenden `Authorization: Bearer …`-Header damit. Token landet nie in `ps`-Output. |
| **API-Key-Übergabe pro Request** — Plain-Text im Memory beim Sidecar | Provider-Object wird per Request gebaut (nicht gecached), GC räumt auf. C#-Seite hält den Key encrypted in Memory bis zum Senden. Akzeptabel für Localhost-Threat-Model. |
| **Markdown.Avalonia-Limitierungen** (Code-Blöcke, Tabellen, Syntax-Highlight) | Phase 4 in zwei Sub-Schritten: 4a Plain-Text+Newlines reicht für MVP, 4b Markdown-Rendering nachschieben. Falls `Markdown.Avalonia` nicht ausreicht, alternativ `Markdig` → `RichTextBox` selber bauen. |
| **Streaming-Latenz vs. Tool-Calling-Sequenzialisierung** | Tool-Call-Sequenzen blockieren Streaming naturgemäß (LLM streamt erst Reasoning, dann Tool-Call-JSON, dann nach Tool-Result wieder Reasoning). UI zeigt "AI denkt nach..." / "AI schlägt Aktion X vor" / "Wartet auf Bestätigung..." als Statusübergänge. |
| **eq_chatbot_core Pip-Install-Pfad** für End-User-Library-Updates | Sidecar-Binary ist gefroren — Lib-Update bedeutet App-Update. Wenn das nicht akzeptabel ist: später Hybrid-Modus (lokaler Sidecar als Default, Cloud-HTTP-Fallback konfigurierbar). |

## Verifikation

**Phase 1 (Sidecar-Server):**
```bash
cd /Users/picard/gitbase/PyPi-Projects/eq_chatbot_core
uv pip install -e ".[server]"
echo "test-token-123" | eq-chatbot serve --port 0 --auth-token-fd 0 --parent-pid $$ &
# Stdout zeigt "LISTENING ON port=NNNN"
curl -H "Authorization: Bearer test-token-123" \
     -H "Content-Type: application/json" \
     -d '{"messages":[{"role":"user","content":"Hi"}],"provider":"openai","model":"gpt-4o","api_key":"sk-..."}' \
     http://127.0.0.1:NNNN/chat
# erwartet JSON mit content
curl -N -H "Authorization: Bearer test-token-123" \
     -H "Content-Type: application/json" \
     -d '{"messages":[{"role":"user","content":"Erkläre Streaming in einem Satz"}],"provider":"openai","model":"gpt-4o","stream":true,"api_key":"sk-..."}' \
     http://127.0.0.1:NNNN/chat/stream
# erwartet SSE-Stream mit event: chunk, event: done
```
+ Pytest-Tests für `/chat`, `/chat/stream`, Auth-Reject (401), Tool-Call-Roundtrip.

**Phase 2 (Sidecar-Packaging):**
```bash
./scripts/build-sidecar.sh --platform macos --arch universal
file Packaging/sidecar/macos/eq-chatbot-sidecar  # Mach-O universal
codesign --verify --strict Packaging/sidecar/macos/eq-chatbot-sidecar
./Packaging/sidecar/macos/eq-chatbot-sidecar serve --port 0 --auth-token-fd 0 --parent-pid $$ <<< "x"  # smoke
```
Linux: `dpkg-deb --info dist/linux/odoo2fastreport-designer_*.deb | grep "Installed-Size"` — Größenwachstum dokumentieren.
Windows: `signtool verify /pa dist/windows/.../eq-chatbot-sidecar.exe`.

**Phase 3 (C# Sidecar Manager):**
- Console-Log "Sidecar listening on http://127.0.0.1:NNNN, auth-token=…"
- Health-Endpoint-Roundtrip
- App-Shutdown → `ps aux | grep eq-chatbot-sidecar` → leer

**Phase 4 (AiToolWindow):**
- Help-Menü → "AI Assistant" → Window öffnet
- "Hallo, was kannst du?" → Streaming-Antwort token-by-token
- API-Key in Settings ändern → encryptedfile geschrieben, Settings-Round-Trip
- App schließen + neu öffnen → Settings persistieren

**Phase 5 (Report-Context):**
- Report mit Datasource "customer" und Field "name" laden
- Chat: "Welche Felder hat customer?" → AI antwortet mit `name` + ggf. weiteren bekannten
- System-Prompt-Inspect via Debug-Toggle (Settings → "Show system prompt")

**Phase 6 (Tool-Calling):**
- Chat: "Füge ein TextObject mit dem Customer-Namen ins Page Header"
- AI emittiert tool-call `insert_text` → ToolConfirmDialog zeigt Preview "Will insert `[customer.name]` in PageHeader1"
- Apply → Designer hat das TextObject sichtbar
- Reject → kein Designer-State-Change

**Cross-Plattform-Regression:**
- Build & Run auf macOS (Universal), Linux (.deb auf Ubuntu 22.04 + 24.04 in Container), Windows (ClickOnce)
- Provider-Smoke-Test mit OpenAI + LangDock + Anthropic je einmal pro Plattform

## Out-of-Scope für diesen Plan (zukünftige Erweiterungen)

- **RAG über FR-YAML-Schema / FRX-Doku / Odoo-Modelle**: bleibt Phase 7+, eigener Plan. Qdrant müsste mit-gebundelt werden oder ein remote-Index existieren.
- **Multi-Modell-/Multi-Provider-Switching mid-conversation**: aktuell nur ein Provider/Modell pro Session.
- **Chat-Historie persistieren**: erstmal nur in-memory pro App-Session.
- **Sidecar-Auto-Update** ohne App-Update: erstmal akzeptieren dass Lib-Bumps App-Releases brauchen.
- **Token-Usage-Reporting / Cost-Dashboard**: nice-to-have für Phase 7+.
