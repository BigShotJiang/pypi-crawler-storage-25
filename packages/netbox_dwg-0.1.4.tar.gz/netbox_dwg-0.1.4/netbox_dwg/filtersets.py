import django_filters
from netbox.filtersets import NetBoxModelFilterSet
from .models import DiagramImage, Floor


class DiagramImageFilterSet(NetBoxModelFilterSet):
    class Meta:
        model = DiagramImage
        fields = ["id", "name"]


class FloorFilterSet(NetBoxModelFilterSet):
    site_id = django_filters.NumberFilter(field_name="site__id")
    level = django_filters.NumberFilter()
    is_default = django_filters.BooleanFilter()

    class Meta:
        model = Floor
        fields = ["id", "name", "site", "level", "is_default"]
