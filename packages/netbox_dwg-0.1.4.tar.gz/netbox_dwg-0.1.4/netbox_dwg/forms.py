from django.forms import ClearableFileInput
from netbox.forms import NetBoxModelForm
from utilities.forms.fields import CommentField
from utilities.forms.rendering import FieldSet
from dcim.models import Rack, Device
from .models import DiagramImage, Floor, _ALLOWED_IMAGE_EXTENSIONS


class DiagramImageForm(NetBoxModelForm):
    comments = CommentField()

    fieldsets = (
        FieldSet("name", "file", "external_url", "comments", name="General"),
        FieldSet("tags", name=""),
    )

    class Meta:
        model = DiagramImage
        fields = ["name", "file", "external_url", "comments", "tags"]
        widgets = {
            "file": ClearableFileInput(
                attrs={"accept": ",".join("." + e for e in _ALLOWED_IMAGE_EXTENSIONS)}
            )
        }


class FloorForm(NetBoxModelForm):
    comments = CommentField()

    fieldsets = (
        FieldSet("site", "name", "level", "is_default", name="Floor"),
        FieldSet("assigned_image", "width", "height", "measurement_unit", name="Diagram"),
        FieldSet("comments", "tags", name=""),
    )

    class Meta:
        model = Floor
        fields = [
            "site",
            "name",
            "level",
            "is_default",
            "assigned_image",
            "width",
            "height",
            "measurement_unit",
            "comments",
            "tags",
        ]


class FloorRackFilterForm(NetBoxModelForm):
    """Minimal form used for the rack sidebar table."""

    class Meta:
        model = Rack
        fields = ["name"]


class FloorDeviceFilterForm(NetBoxModelForm):
    """Minimal form used for the device sidebar table."""

    class Meta:
        model = Device
        fields = ["name"]
