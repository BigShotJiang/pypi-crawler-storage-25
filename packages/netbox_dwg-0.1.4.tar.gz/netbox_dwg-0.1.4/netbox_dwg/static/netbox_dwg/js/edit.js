/**
 * netbox_dwg — Interactive canvas editor (edit mode).
 *
 * Uses Fabric.js 6.x to provide:
 *  - Rack / device placement from sidebar
 *  - Location zone, zone (point-by-point polygon), circle, line, label drawing
 *  - Zoom (scroll-wheel), pan (Alt+drag), keyboard shortcuts
 *  - Rotation snap to 15° when Shift is held during rotate
 *  - All new objects spawn at the current viewport centre
 *  - Auto-save via PATCH to the REST API
 *
 * Depends on utils.js being loaded first (provides window.NetBoxDWG).
 */

(function () {
  'use strict';

  var U = window.NetBoxDWG;

  // -------------------------------------------------------------------------
  // Globals
  // -------------------------------------------------------------------------

  var csrf    = document.getElementById('csrf').value;
  var obj_pk  = document.getElementById('obj_pk').value;
  var site_id = document.getElementById('site_id').value;

  var canvas = new fabric.Canvas('canvas', {
    selection: true,
    preserveObjectStacking: true,
  });

  // -------------------------------------------------------------------------
  // Zoom, pan, resize
  // -------------------------------------------------------------------------

  U.resize_canvas(canvas, window);
  window.addEventListener('resize', function () {
    U.resize_canvas(canvas, window);
  });

  // setup_zoom attaches a native non-passive wheel listener so that
  // e.preventDefault() is respected — canvas.on('mouse:wheel') is passive in
  // modern browsers and cannot call preventDefault().
  U.setup_zoom(canvas);

  canvas.on('mouse:down', function (opt) { U.start_pan(opt, canvas); });
  canvas.on('mouse:move', function (opt) { U.move_pan(opt, canvas); });
  canvas.on('mouse:up',   function ()    { U.stop_pan(canvas); });

  window.resetZoom = function () { U.reset_zoom(canvas); };

  // -------------------------------------------------------------------------
  // Rotation snap — hold Shift while rotating to snap to 15° steps
  // -------------------------------------------------------------------------
  //
  // opt.e on 'object:rotating' is the PointerEvent from the initial mousedown,
  // NOT from the current mousemove, so opt.e.shiftKey only reflects the state
  // when the drag started and never updates mid-drag.  We track the live Shift
  // state with document keydown/keyup listeners instead.

  var _shiftPressed = false;
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Shift') _shiftPressed = true;
  });
  document.addEventListener('keyup', function (e) {
    if (e.key === 'Shift') _shiftPressed = false;
  });
  // Reset if window loses focus so the flag doesn't get stuck.
  window.addEventListener('blur', function () { _shiftPressed = false; });

  canvas.on('object:rotating', function (opt) {
    if (_shiftPressed || (opt.e && opt.e.shiftKey)) {
      // Shift held → hard-snap every 15° (snapping here is safe for 15° grid)
      opt.target.angle = Math.round(opt.target.angle / 15) * 15;
    }
    // NOTE: do NOT snap to 90° here — changing the angle mid-drag desyncs
    // Fabric's internal rotation origin and causes the object to fly away.
    // 90°-family snapping happens in object:modified (after mouse-up) below.
  });

  // After the rotation gesture ends, snap to nearest 90° (within ±8°) for
  // easy alignment. This fires post-drag so there is no floating-point desync.
  canvas.on('object:modified', function (opt) {
    if (opt.action !== 'rotate') return;
    // Normalise to [0, 360)
    var angle = ((opt.target.angle % 360) + 360) % 360;
    var stops = [0, 90, 180, 270, 360];
    for (var i = 0; i < stops.length; i++) {
      if (Math.abs(angle - stops[i]) <= 8) {
        opt.target.angle = stops[i] % 360;
        opt.target.setCoords();
        canvas.requestRenderAll();
        break;
      }
    }
  });

  // -------------------------------------------------------------------------
  // Viewport helpers
  // -------------------------------------------------------------------------

  /**
   * Return the canvas-space point at the centre of the current visible
   * viewport.  All new objects are placed here so they appear centred on
   * wherever the user has panned / zoomed to.
   *
   *   viewportTransform = [zoom, 0, 0, zoom, panX, panY]
   *   canvas_x = (screen_x - panX) / zoom
   *   screen centre = (canvas.width/2, canvas.height/2)
   */
  function _viewportCenter() {
    var vpt  = canvas.viewportTransform;
    var zoom = vpt[0];
    return {
      x: (canvas.getWidth()  / 2 - vpt[4]) / zoom,
      y: (canvas.getHeight() / 2 - vpt[5]) / zoom,
    };
  }

  /** Place obj so its visual centre lands at the current viewport centre. */
  function _placeAtViewportCenter(obj) {
    var c = _viewportCenter();
    obj.set({ left: c.x, top: c.y });
    obj.setCoords();
  }

  /**
   * Attach custom_meta to a Fabric object and override its toObject() so the
   * property is ALWAYS included in serialization regardless of which Fabric
   * version is in use or whether propertiesToInclude is forwarded correctly.
   *
   * Fabric 6 ignores the propertiesToInclude argument on canvas.toJSON() so
   * relying on that path alone is not reliable.  Overriding the instance
   * method is the only guaranteed path.
   *
   * Also assigns the active layer if no layer is already set.
   */
  function _attachMeta(obj, meta) {
    if (!meta.layer) meta.layer = _activeLayerId;
    obj.custom_meta = meta;
    var _orig = obj.toObject.bind(obj);
    obj.toObject = function (extra) {
      var serialized = _orig(extra);
      serialized.custom_meta = obj.custom_meta;
      return serialized;
    };
  }

  // -------------------------------------------------------------------------
  // Sidebar — load available racks & devices via REST API
  // -------------------------------------------------------------------------

  // Reliable placement tracking — initialised from the server-rendered lists
  // (which read directly from the saved canvas JSON via the model’s
  // mapped_racks / mapped_devices properties, bypassing loadFromJSON / reviver
  // entirely).  add_rack_to_canvas / add_device_to_canvas push new IDs in;
  // delete_selected removes them.  _placedIds() uses these lists.
  var _placedRackIds   = [];
  var _placedDeviceIds = [];

  (function () {
    var rEl = document.getElementById('placed_rack_ids');
    var dEl = document.getElementById('placed_device_ids');
    if (rEl && rEl.value) {
      _placedRackIds   = rEl.value.split(',').filter(Boolean).map(String);
    }
    if (dEl && dEl.value) {
      _placedDeviceIds = dEl.value.split(',').filter(Boolean).map(String);
    }
  }());

  function _placedIds(objectType) {
    return (objectType === 'rack' ? _placedRackIds : _placedDeviceIds).slice();
  }

  function _renderRackSidebar(racks) {
    var placed    = _placedIds('rack');
    var available = racks.filter(function (r) { return placed.indexOf(String(r.id)) === -1; });
    var card      = document.getElementById('rack-card');
    if (!card) return;

    if (!available.length) {
      card.querySelector('.card-body').innerHTML =
        '<p class="text-muted small">All racks are already placed.</p>';
      return;
    }

    var rows = available.map(function (r) {
      var color    = r.role_color ? '#' + r.role_color : '#000000';
      var roleName = r.role_name || '\u2014';
      var status   = r.status || '';
      var ow = (r.outer_width !== null && r.outer_width !== undefined) ? r.outer_width : 'null';
      var od = (r.outer_depth !== null && r.outer_depth !== undefined) ? r.outer_depth : 'null';
      var ou = r.outer_unit ? "'" + r.outer_unit + "'" : 'null';
      var safeName = r.name.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var onclick  = "add_rack_to_canvas(" +
        r.id + ",'" + safeName + "','" + status + "','" + color + "'," +
        ow + ',' + od + ',' + ou + ')';
      return '<tr id="sidebar_rack_' + r.id + '">' +
        '<td class="small">' + r.name + '</td>' +
        '<td class="small text-muted">' + roleName + '</td>' +
        '<td><button class="btn btn-xs btn-outline-secondary py-0 px-1" onclick="' + onclick + '">' +
        '<span class="mdi mdi-plus-thick"></span></button></td></tr>';
    }).join('');

    card.querySelector('.card-body').innerHTML =
      '<div class="table-responsive"><table class="table table-sm table-hover mb-0">' +
      '<thead><tr><th>Name</th><th>Role</th><th></th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table></div>';
  }

  function _renderDeviceSidebar(devices) {
    var placed    = _placedIds('device');
    var available = devices.filter(function (d) { return placed.indexOf(String(d.id)) === -1; });
    var card      = document.getElementById('device-card');
    if (!card) return;

    if (!available.length) {
      card.querySelector('.card-body').innerHTML =
        '<p class="text-muted small">All devices are already placed.</p>';
      return;
    }

    var rows = available.map(function (d) {
      var roleColor = d.role_color || '666666';
      var roleName  = d.role_name  || '\u2014';
      var status    = d.status     || '';
      var safeName  = d.name.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      var onclick   = "add_device_to_canvas(" +
        d.id + ",'" + safeName + "','" + status + "','#" + roleColor + "')";
      return '<tr id="sidebar_device_' + d.id + '">' +
        '<td class="small">' + d.name + '</td>' +
        '<td class="small text-muted">' + roleName + '</td>' +
        '<td><button class="btn btn-xs btn-outline-secondary py-0 px-1" onclick="' + onclick + '">' +
        '<span class="mdi mdi-plus-thick"></span></button></td></tr>';
    }).join('');

    card.querySelector('.card-body').innerHTML =
      '<div class="table-responsive"><table class="table table-sm table-hover mb-0">' +
      '<thead><tr><th>Name</th><th>Role</th><th></th></tr></thead>' +
      '<tbody>' + rows + '</tbody></table></div>';
  }

  var _allRacks   = [];
  var _allDevices = [];

  function _loadRackSidebar() {
    var el = document.getElementById('racks-data');
    if (!el) return;
    try { _allRacks = JSON.parse(el.textContent); } catch (e) { _allRacks = []; }
    _renderRackSidebar(_allRacks);
  }

  function _loadDeviceSidebar() {
    var el = document.getElementById('devices-data');
    if (!el) return;
    try { _allDevices = JSON.parse(el.textContent); } catch (e) { _allDevices = []; }
    _renderDeviceSidebar(_allDevices);
  }

  // Re-render both sidebars from cache (no extra API call). Called after add/delete.
  function _refreshSidebars() {
    if (_allRacks.length)   _renderRackSidebar(_allRacks);
    if (_allDevices.length) _renderDeviceSidebar(_allDevices);
  }

  // -------------------------------------------------------------------------
  // Modal helper
  // -------------------------------------------------------------------------

  function _hideModal(id) {
    var el = document.getElementById(id);
    if (!el) return;
    if (typeof $ !== 'undefined' && $.fn && $.fn.modal) { $(el).modal('hide'); return; }
    if (window.bootstrap && window.bootstrap.Modal) {
      var inst = window.bootstrap.Modal.getInstance(el);
      if (inst) { inst.hide(); return; }
    }
    var btn = el.querySelector('[data-bs-dismiss="modal"]');
    if (btn) btn.click();
  }

  function _showModal(id) {
    var el = document.getElementById(id);
    if (!el) return;
    if (typeof $ !== 'undefined' && $.fn && $.fn.modal) { $(el).modal('show'); return; }
    if (window.bootstrap && window.bootstrap.Modal) { new window.bootstrap.Modal(el).show(); }
  }

  // -------------------------------------------------------------------------
  // Rack placement
  // -------------------------------------------------------------------------

  window.add_rack_to_canvas = function (
    rackId, rackName, status, color, outerWidth, outerDepth, outerUnit
  ) {
    if (_placedIds('rack').indexOf(String(rackId)) !== -1) {
      console.warn('netbox_dwg: rack', rackId, 'already on canvas'); return;
    }

    var w = 60, h = 91;
    if (outerWidth && outerDepth && outerUnit) {
      var sc = 100;
      w = outerUnit === 'in' ? outerWidth * 0.0254 * sc : (outerWidth  / 1000) * sc;
      h = outerUnit === 'in' ? outerDepth * 0.0254 * sc : (outerDepth  / 1000) * sc;
    }

    var rect = new fabric.Rect({
      width: w, height: h, fill: color || '#333333', opacity: 0.7,
      stroke: '#000', strokeWidth: 1, rx: 3, ry: 3,
      originX: 'center', originY: 'center',
    });
    var lbl = new fabric.Textbox(rackName, {
      fontSize: 12, fill: '#fff', textAlign: 'center',
      originX: 'center', originY: 'center', width: w - 4,
    });
    var statusLbl = new fabric.Text(status || '', {
      fontSize: 9, fill: '#ccc', originX: 'center', originY: 'center', top: 14,
    });
    var group = new fabric.Group([rect, lbl, statusLbl], {
      hasRotatingPoint: true,
    });
    _attachMeta(group, { object_type: 'rack', object_id: rackId, object_name: rackName, status: status });
    _placeAtViewportCenter(group);
    canvas.add(group);
    canvas.setActiveObject(group);
    canvas.renderAll();
    _placedRackIds.push(String(rackId));
    _refreshSidebars();
  };

  // -------------------------------------------------------------------------
  // Device placement
  // -------------------------------------------------------------------------

  window.add_device_to_canvas = function (deviceId, deviceName, status, color) {
    if (_placedIds('device').indexOf(String(deviceId)) !== -1) {
      console.warn('netbox_dwg: device', deviceId, 'already on canvas'); return;
    }

    var w = 40, h = 30;
    var rect = new fabric.Rect({
      width: w, height: h, fill: color || '#666666', opacity: 0.8,
      stroke: '#000', strokeWidth: 1, rx: 2, ry: 2,
      originX: 'center', originY: 'center',
    });
    var lbl = new fabric.Textbox(deviceName, {
      fontSize: 10, fill: '#fff', textAlign: 'center',
      originX: 'center', originY: 'center', width: w - 4,
    });
    var statusLbl = new fabric.Text(status || '', {
      fontSize: 8, fill: '#ccc', originX: 'center', originY: 'center', top: 10,
    });
    var group = new fabric.Group([rect, lbl, statusLbl], {
      hasRotatingPoint: true,
    });
    _attachMeta(group, { object_type: 'device', object_id: deviceId, object_name: deviceName, status: status });
    _placeAtViewportCenter(group);
    canvas.add(group);
    canvas.setActiveObject(group);
    canvas.renderAll();
    _placedDeviceIds.push(String(deviceId));
    _refreshSidebars();
  };

  // -------------------------------------------------------------------------
  // Location Zone
  // -------------------------------------------------------------------------

  /**
   * A location zone is a simple scalable Group: one Rect + one Textbox.
   * We do NOT destroy/recreate the group on resize — Fabric 6 handles scaled
   * groups correctly in rendering and JSON serialization.  The only post-load
   * step needed is restoring the mid-edge resize handles via _applyZoneControls.
   */
  window.add_location_zone = function () {
    var rect = new fabric.Rect({
      width: 300, height: 200, fill: '#6ea8fe', opacity: 0.35,
      stroke: '#0d6efd', strokeWidth: 2, rx: 6, ry: 6,
      originX: 'center', originY: 'center',
    });
    var lbl = new fabric.Textbox('Location', {
      fontSize: 16, fill: '#000', fontWeight: 'bold', textAlign: 'center',
      originX: 'center', originY: 'center', width: 290,
    });
    var group = new fabric.Group([rect, lbl], {
      hasRotatingPoint: true, cornerSize: 12,
    });
    _attachMeta(group, { object_type: 'location_zone' });
    _applyZoneControls(group);
    _placeAtViewportCenter(group);
    canvas.add(group);
    canvas.setActiveObject(group);
    canvas.renderAll();
  };

  /** Show mid-edge resize handles on a zone group (new and restored from JSON). */
  function _applyZoneControls(group) {
    group.setControlsVisibility({ mt: true, mb: true, ml: true, mr: true, mtr: true });
  }

  // -------------------------------------------------------------------------
  // Zone — double-click to edit label text / font size
  // -------------------------------------------------------------------------

  canvas.on('mouse:dblclick', function (opt) {
    if (_zoneDrawing || _cableDrawing) return; // zone/cable drawing mode handles dblclick separately
    if (_cableEditing) return; // already editing a cable
    var target = opt.target;
    if (!target) return;
    var objType = target.custom_meta && target.custom_meta.object_type;

    // --- Cable: right-click or single dblclick opens properties modal ---
    if (objType === 'cable' && target.type === 'polyline') {
      // Populate modal with current cable properties
      var curColor = target.stroke || '#e91e63';
      if (typeof curColor !== 'string' || curColor.charAt(0) !== '#') curColor = '#e91e63';
      document.getElementById('cable_color_input').value = curColor.substring(0, 7);
      document.getElementById('cable_width_input').value = target.strokeWidth || 3;
      document.getElementById('cable_dotted_input').checked = !!(target.strokeDashArray && target.strokeDashArray.length);
      var curOp = Math.round((target.opacity != null ? target.opacity : 1) * 100);
      document.getElementById('cable_opacity_input').value = curOp;
      document.getElementById('cable_opacity_display').textContent = curOp;
      window._activeCableTarget = target;
      _showModal('cable_props_modal');
      return;
    }

    if (target.type !== 'group') return;

    // --- Location zone: edit label ---
    if (objType === 'location_zone') {
      var labelChild = null;
      target.getObjects().forEach(function (ch) {
        if (ch.type === 'textbox') labelChild = ch;
      });
      if (!labelChild) return;
      document.getElementById('zone_text_input').value    = labelChild.text    || '';
      document.getElementById('zone_font_size').value     = labelChild.fontSize || 16;
      document.getElementById('zone_text_rotation').value = labelChild.angle   || 0;
      window._activeZoneGroup = target;
      _showModal('zone_text_modal');
      return;
    }

    // --- Rack / Device: edit color + label ---
    if (objType === 'rack' || objType === 'device') {
      var currentColor = '#333333';
      var currentLabel = (target.custom_meta && target.custom_meta.object_name) || '';
      target.getObjects().forEach(function (ch) {
        if (ch.type === 'rect') currentColor = ch.fill || '#333333';
        if (ch.type === 'textbox' && ch.fontSize > 9) currentLabel = ch.text || currentLabel;
      });
      // color input requires #rrggbb format
      if (typeof currentColor !== 'string' || currentColor.charAt(0) !== '#' || currentColor.length !== 7) {
        currentColor = '#333333';
      }
      document.getElementById('rack_color_input').value   = currentColor;
      document.getElementById('rack_label_input').value   = currentLabel;
      document.getElementById('rack_opacity_input').value = Math.round((target.opacity != null ? target.opacity : 1) * 100);
      window._activeRackGroup = target;
      _showModal('rack_props_modal');
      return;
    }
  });

  window.apply_zone_text = function () {
    var group = window._activeZoneGroup;
    if (!group) return;

    var newText     = document.getElementById('zone_text_input').value || 'Location';
    var newFontSize = parseInt(document.getElementById('zone_font_size').value, 10) || 16;
    var newRotation = parseInt(document.getElementById('zone_text_rotation').value, 10) || 0;

    group.getObjects().forEach(function (ch) {
      if (ch.type === 'textbox') {
        ch.set({
          text:     newText,
          fontSize: Math.max(8, Math.min(72, newFontSize)),
          angle:    newRotation,
        });
      }
    });
    canvas.renderAll();
    window._activeZoneGroup = null;
    _hideModal('zone_text_modal');
  };

  // Apply changes from rack/device properties modal.
  window.apply_rack_props = function () {
    var group = window._activeRackGroup;
    if (!group) return;
    var newColor   = document.getElementById('rack_color_input').value;
    var newLabel   = document.getElementById('rack_label_input').value || '';
    var newOpacity = parseInt(document.getElementById('rack_opacity_input').value, 10) / 100;

    group.getObjects().forEach(function (ch) {
      if (ch.type === 'rect') ch.set('fill', newColor);
      // Only update the main label (larger font), not the small status text.
      if (ch.type === 'textbox' && ch.fontSize > 9) ch.set('text', newLabel);
    });
    group.set('opacity', Math.max(0.05, Math.min(1, newOpacity)));
    if (group.custom_meta) group.custom_meta.object_name = newLabel;

    canvas.renderAll();
    window._activeRackGroup = null;
    _hideModal('rack_props_modal');
  };

  // Apply changes from cable properties modal.
  window.apply_cable_props = function () {
    var cable = window._activeCableTarget;
    if (!cable) return;
    var newColor   = document.getElementById('cable_color_input').value;
    var newWidth   = parseInt(document.getElementById('cable_width_input').value, 10) || 3;
    var isDotted   = document.getElementById('cable_dotted_input').checked;
    var newOpacity = parseInt(document.getElementById('cable_opacity_input').value, 10) / 100;

    cable.set({
      stroke: newColor,
      strokeWidth: Math.max(1, Math.min(20, newWidth)),
      strokeDashArray: isDotted ? [8, 6] : null,
      opacity: Math.max(0.05, Math.min(1, newOpacity)),
    });
    cable.dirty = true;
    canvas.renderAll();
    window._activeCableTarget = null;
    _hideModal('cable_props_modal');
  };

  // Enter cable point-edit mode from properties modal.
  window.edit_cable_points = function () {
    var cable = window._activeCableTarget;
    if (!cable) return;
    _hideModal('cable_props_modal');
    window._activeCableTarget = null;
    _startCableEdit(cable);
    var editPanel = document.getElementById('cable_edit_panel');
    if (editPanel) editPanel.style.display = 'block';
  };

  // -------------------------------------------------------------------------
  // Other drawing tools
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // Zone drawing — interactive point-by-point zone creation
  // -------------------------------------------------------------------------

  var _zoneDrawing    = false;      // are we in zone-draw mode?
  var _zonePoints    = [];         // canvas-space {x, y} vertices
  var _zoneMarkers   = [];         // temporary fabric.Circle pointers on canvas
  var _zonePreview   = null;       // live-preview fabric.Polygon (placed pts + cursor)
  var _zoneRubberBand = null;      // dashed line from last point to cursor
  var _zoneCursorPos = null;       // latest cursor position in canvas coords
  var _zoneColor     = '#ffc10780'; // default zone fill (set from UI)
  var _zoneStroke    = '#ff9800';   // default zone stroke

  /** Enter zone-drawing mode. */
  window.start_zone_draw = function () {
    if (_zoneDrawing || _cableDrawing || _cableEditing) return;
    _zoneDrawing    = true;
    _zonePoints     = [];
    _zoneMarkers    = [];
    _zonePreview    = null;
    _zoneRubberBand = null;
    _zoneCursorPos  = null;
    canvas.selection = false; // disable rubber-band select during draw
    canvas.defaultCursor = 'crosshair';
    canvas.hoverCursor   = 'crosshair';
    // Read color from UI picker if available
    var colorEl = document.getElementById('zone_draw_color');
    if (colorEl) _zoneColor = colorEl.value + '80'; // append 50% alpha
    var strokeEl = document.getElementById('zone_draw_stroke');
    if (strokeEl) _zoneStroke = strokeEl.value;
    _showZoneDrawUI(true);
  };

  /** Add a vertex at the clicked canvas position. */
  function _addZonePoint(canvasX, canvasY) {
    _zonePoints.push({ x: canvasX, y: canvasY });

    // Draw a small marker circle at the point
    var marker = new fabric.Circle({
      left: canvasX, top: canvasY, radius: 5,
      fill: _zoneStroke, stroke: '#fff', strokeWidth: 1,
      originX: 'center', originY: 'center',
      selectable: false, evented: false, excludeFromExport: true,
    });
    canvas.add(marker);
    _zoneMarkers.push(marker);

    // Update live preview polygon
    _updateZonePreview();
  }

  /**
   * Redraw the translucent preview polygon from placed points + cursor.
   * When cursorPt is supplied the preview extends to the mouse position so
   * the user sees where the next edge will land before clicking.
   */
  function _updateZonePreview(cursorPt) {
    // Remove previous preview objects
    if (_zonePreview)    { canvas.remove(_zonePreview);    _zonePreview    = null; }
    if (_zoneRubberBand) { canvas.remove(_zoneRubberBand); _zoneRubberBand = null; }

    var pts = _zonePoints.slice();
    var cur = cursorPt || _zoneCursorPos;

    // Rubber-band line: last placed point → cursor
    if (pts.length >= 1 && cur) {
      var last = pts[pts.length - 1];
      _zoneRubberBand = new fabric.Line(
        [last.x, last.y, cur.x, cur.y],
        {
          stroke: _zoneStroke, strokeWidth: 2,
          strokeDashArray: [6, 4],
          selectable: false, evented: false,
          objectCaching: false, excludeFromExport: true,
        }
      );
      canvas.add(_zoneRubberBand);
    }

    // Filled preview polygon: all placed points + cursor
    if (cur) pts.push(cur);
    if (pts.length < 2) { canvas.renderAll(); return; }

    _zonePreview = new fabric.Polygon(pts, {
      fill: _zoneColor, stroke: _zoneStroke, strokeWidth: 2,
      opacity: 0.5, selectable: false, evented: false,
      objectCaching: false, excludeFromExport: true,
    });
    // Send preview behind markers but in front of background
    canvas.add(_zonePreview);
    canvas.sendObjectToBack(_zonePreview);
    // Bring rubber-band and markers to front
    if (_zoneRubberBand) canvas.bringObjectToFront(_zoneRubberBand);
    _zoneMarkers.forEach(function (m) { canvas.bringObjectToFront(m); });
    canvas.renderAll();
  }

  /** Finalize zone: create a permanent polygon from placed points. */
  window.finish_zone_draw = function () {
    if (!_zoneDrawing) return;
    if (_zonePoints.length < 3) {
      alert('Place at least 3 points to define a zone.');
      return;
    }

    // Clean up temporary objects
    _cleanupZoneDraw();

    // Normalise points relative to the centroid so the polygon's
    // left/top is its centre (easier to move/scale later).
    var cx = 0, cy = 0;
    _zonePoints.forEach(function (p) { cx += p.x; cy += p.y; });
    cx /= _zonePoints.length;
    cy /= _zonePoints.length;
    var relPts = _zonePoints.map(function (p) {
      return { x: p.x - cx, y: p.y - cy };
    });

    var poly = new fabric.Polygon(relPts, {
      left: cx, top: cy,
      fill: _zoneColor, stroke: _zoneStroke, strokeWidth: 2,
      objectCaching: false, hasRotatingPoint: true,
      originX: 'center', originY: 'center',
    });
    _attachMeta(poly, { object_type: 'zone' });
    canvas.add(poly);
    canvas.setActiveObject(poly);
    canvas.renderAll();

    _zoneDrawing = false;
    _zonePoints  = [];
    canvas.selection    = true;
    canvas.defaultCursor = 'default';
    canvas.hoverCursor   = 'move';
    _showZoneDrawUI(false);
  };

  /** Cancel zone-draw without creating anything. */
  window.cancel_zone_draw = function () {
    if (!_zoneDrawing) return;
    _cleanupZoneDraw();
    _zoneDrawing = false;
    _zonePoints  = [];
    canvas.selection    = true;
    canvas.defaultCursor = 'default';
    canvas.hoverCursor   = 'move';
    _showZoneDrawUI(false);
    canvas.renderAll();
  };

  /** Undo the last placed zone point. */
  window.undo_zone_point = function () {
    if (!_zoneDrawing || !_zonePoints.length) return;
    _zonePoints.pop();
    var marker = _zoneMarkers.pop();
    if (marker) canvas.remove(marker);
    _updateZonePreview();
  };

  /** Remove temporary markers, preview, and rubber-band from canvas. */
  function _cleanupZoneDraw() {
    _zoneMarkers.forEach(function (m) { canvas.remove(m); });
    _zoneMarkers = [];
    if (_zonePreview)    { canvas.remove(_zonePreview);    _zonePreview    = null; }
    if (_zoneRubberBand) { canvas.remove(_zoneRubberBand); _zoneRubberBand = null; }
    _zoneCursorPos = null;
  }

  /** Toggle visibility of zone-draw UI controls. */
  function _showZoneDrawUI(show) {
    var panel = document.getElementById('zone_draw_panel');
    if (panel) panel.style.display = show ? 'block' : 'none';
    var startBtn = document.getElementById('zone_draw_start_btn');
    if (startBtn) startBtn.style.display = show ? 'none' : '';
  }

  // Live mouse-move preview while drawing a zone or cable
  canvas.on('mouse:move', function (opt) {
    if (canvas.isDragging) return; // don't preview while panning
    if (_zoneDrawing) {
      _zoneCursorPos = canvas.getScenePoint(opt.e);
      _updateZonePreview(_zoneCursorPos);
    }
    if (_cableDrawing) {
      _cableCursorPos = canvas.getScenePoint(opt.e);
      _updateCablePreview(_cableCursorPos);
    }
  });

  // Intercept canvas clicks in zone-draw or cable-draw mode
  canvas.on('mouse:down', function (opt) {
    if (opt.e.altKey) return; // Alt+click = pan, not drawing
    if (_zoneDrawing) {
      var pointer = canvas.getScenePoint(opt.e);
      _addZonePoint(pointer.x, pointer.y);
    }
    if (_cableDrawing) {
      var pointer2 = canvas.getScenePoint(opt.e);
      _addCablePoint(pointer2.x, pointer2.y);
    }
  });

  // Double-click finishes the zone or cable (alternative to button)
  canvas.on('mouse:dblclick', function (opt) {
    if (_zoneDrawing && _zonePoints.length >= 3) {
      // Remove the duplicate point that the second click of dblclick added
      if (_zonePoints.length > 3) {
        _zonePoints.pop();
        var marker = _zoneMarkers.pop();
        if (marker) canvas.remove(marker);
      }
      window.finish_zone_draw();
      return;
    }
    if (_cableDrawing && _cablePoints.length >= 2) {
      if (_cablePoints.length > 2) {
        _cablePoints.pop();
        var marker2 = _cableMarkers.pop();
        if (marker2) canvas.remove(marker2);
      }
      window.finish_cable_draw();
      return;
    }
  });

  // -------------------------------------------------------------------------
  // Cable drawing — interactive point-by-point polyline creation
  // -------------------------------------------------------------------------

  var _cableDrawing     = false;     // are we in cable-draw mode?
  var _cablePoints      = [];        // canvas-space {x, y} vertices
  var _cableMarkers     = [];        // temporary fabric.Circle pointers on canvas
  var _cablePreview     = null;      // live-preview fabric.Polyline
  var _cableRubberBand  = null;      // dashed line from last point to cursor
  var _cableCursorPos   = null;      // latest cursor position in canvas coords
  var _cableStroke      = '#e91e63'; // default cable stroke colour
  var _cableStrokeWidth = 3;         // default cable stroke width
  var _cableDotted      = false;     // default: solid line

  /** Enter cable-drawing mode. */
  window.start_cable_draw = function () {
    if (_cableDrawing || _zoneDrawing) return;
    _cableDrawing     = true;
    _cablePoints      = [];
    _cableMarkers     = [];
    _cablePreview     = null;
    _cableRubberBand  = null;
    _cableCursorPos   = null;
    canvas.selection   = false;
    canvas.defaultCursor = 'crosshair';
    canvas.hoverCursor   = 'crosshair';
    var strokeEl = document.getElementById('cable_draw_stroke');
    if (strokeEl) _cableStroke = strokeEl.value;
    var widthEl = document.getElementById('cable_draw_width');
    if (widthEl) _cableStrokeWidth = parseInt(widthEl.value, 10) || 3;
    var dottedEl = document.getElementById('cable_draw_dotted');
    _cableDotted = dottedEl ? dottedEl.checked : false;
    _showCableDrawUI(true);
  };

  /** Add a vertex at the clicked canvas position. */
  function _addCablePoint(canvasX, canvasY) {
    _cablePoints.push({ x: canvasX, y: canvasY });

    var marker = new fabric.Circle({
      left: canvasX, top: canvasY, radius: 5,
      fill: _cableStroke, stroke: '#fff', strokeWidth: 1,
      originX: 'center', originY: 'center',
      selectable: false, evented: false, excludeFromExport: true,
    });
    canvas.add(marker);
    _cableMarkers.push(marker);

    _updateCablePreview();
  }

  /** Redraw the live preview polyline from placed points + cursor. */
  function _updateCablePreview(cursorPt) {
    if (_cablePreview)    { canvas.remove(_cablePreview);    _cablePreview    = null; }
    if (_cableRubberBand) { canvas.remove(_cableRubberBand); _cableRubberBand = null; }

    var pts = _cablePoints.slice();
    var cur = cursorPt || _cableCursorPos;

    // Rubber-band line: last placed point → cursor
    if (pts.length >= 1 && cur) {
      var last = pts[pts.length - 1];
      _cableRubberBand = new fabric.Line(
        [last.x, last.y, cur.x, cur.y],
        {
          stroke: _cableStroke, strokeWidth: _cableStrokeWidth,
          strokeDashArray: [6, 4],
          selectable: false, evented: false,
          objectCaching: false, excludeFromExport: true,
        }
      );
      canvas.add(_cableRubberBand);
    }

    // Polyline preview: all placed points + cursor
    if (cur) pts.push(cur);
    if (pts.length < 2) { canvas.renderAll(); return; }

    _cablePreview = new fabric.Polyline(pts, {
      fill: 'transparent', stroke: _cableStroke,
      strokeWidth: _cableStrokeWidth, opacity: 0.5,
      strokeDashArray: _cableDotted ? [8, 6] : null,
      selectable: false, evented: false,
      objectCaching: false, excludeFromExport: true,
    });
    canvas.add(_cablePreview);
    canvas.sendObjectToBack(_cablePreview);
    if (_cableRubberBand) canvas.bringObjectToFront(_cableRubberBand);
    _cableMarkers.forEach(function (m) { canvas.bringObjectToFront(m); });
    canvas.renderAll();
  }

  /** Finalize cable: create a permanent polyline from placed points. */
  window.finish_cable_draw = function () {
    if (!_cableDrawing) return;
    if (_cablePoints.length < 2) {
      alert('Place at least 2 points to define a cable.');
      return;
    }

    _cleanupCableDraw();

    // Normalise points relative to the centroid
    var cx = 0, cy = 0;
    _cablePoints.forEach(function (p) { cx += p.x; cy += p.y; });
    cx /= _cablePoints.length;
    cy /= _cablePoints.length;
    var relPts = _cablePoints.map(function (p) {
      return { x: p.x - cx, y: p.y - cy };
    });

    var cableOpts = {
      left: cx, top: cy,
      fill: 'transparent', stroke: _cableStroke,
      strokeWidth: _cableStrokeWidth,
      objectCaching: false, hasRotatingPoint: true,
      originX: 'center', originY: 'center',
      strokeLineCap: 'round', strokeLineJoin: 'round',
    };
    if (_cableDotted) cableOpts.strokeDashArray = [8, 6];
    var polyline = new fabric.Polyline(relPts, cableOpts);
    _attachMeta(polyline, { object_type: 'cable' });
    canvas.add(polyline);
    canvas.setActiveObject(polyline);
    canvas.renderAll();

    _cableDrawing = false;
    _cablePoints  = [];
    canvas.selection     = true;
    canvas.defaultCursor = 'default';
    canvas.hoverCursor   = 'move';
    _showCableDrawUI(false);
  };

  /** Cancel cable-draw without creating anything. */
  window.cancel_cable_draw = function () {
    if (!_cableDrawing) return;
    _cleanupCableDraw();
    _cableDrawing = false;
    _cablePoints  = [];
    canvas.selection     = true;
    canvas.defaultCursor = 'default';
    canvas.hoverCursor   = 'move';
    _showCableDrawUI(false);
    canvas.renderAll();
  };

  /** Undo the last placed cable point. */
  window.undo_cable_point = function () {
    if (!_cableDrawing || !_cablePoints.length) return;
    _cablePoints.pop();
    var marker = _cableMarkers.pop();
    if (marker) canvas.remove(marker);
    _updateCablePreview();
  };

  /** Remove temporary markers, preview, and rubber-band from canvas. */
  function _cleanupCableDraw() {
    _cableMarkers.forEach(function (m) { canvas.remove(m); });
    _cableMarkers = [];
    if (_cablePreview)    { canvas.remove(_cablePreview);    _cablePreview    = null; }
    if (_cableRubberBand) { canvas.remove(_cableRubberBand); _cableRubberBand = null; }
    _cableCursorPos = null;
  }

  /** Toggle visibility of cable-draw UI controls. */
  function _showCableDrawUI(show) {
    var panel = document.getElementById('cable_draw_panel');
    if (panel) panel.style.display = show ? 'block' : 'none';
    var startBtn = document.getElementById('cable_draw_start_btn');
    if (startBtn) startBtn.style.display = show ? 'none' : '';
  }

  // -------------------------------------------------------------------------
  // Cable point editing — double-click an existing cable to edit its vertices
  // -------------------------------------------------------------------------

  var _cableEditing       = false;  // are we editing an existing cable?
  var _cableEditTarget    = null;   // the fabric.Polyline being edited
  var _cableEditPoints    = [];     // the points array being modified
  var _cableEditMarkers   = [];     // draggable control circles
  var _cableEditMidpoints = [];     // add-point circles at midpoints
  var _cableEditPreview   = null;   // live preview polyline during edit

  /** Enter cable-editing mode for an existing polyline. */
  function _startCableEdit(target) {
    if (_cableEditing) _finishCableEdit(false);
    _cableEditing     = true;
    _cableEditTarget  = target;
    target.set({ selectable: false, evented: false, visible: false });

    // Extract absolute points from the polyline
    var pts = target.points || [];
    var ox = target.left || 0;
    var oy = target.top  || 0;
    // If origin is center, adjust offset to top-left by half bounding box
    var pathOffX = 0, pathOffY = 0;
    if (target.originX === 'center' || target.originY === 'center') {
      var bounds = target.getBoundingRect(true);
      pathOffX = bounds.left;
      pathOffY = bounds.top;
    } else {
      pathOffX = ox;
      pathOffY = oy;
    }

    _cableEditPoints = pts.map(function (p) {
      return { x: p.x + pathOffX, y: p.y + pathOffY };
    });

    canvas.selection = false;
    _renderCableEditControls();
  }

  /** Render control points and midpoint-add circles for cable editing. */
  function _renderCableEditControls() {
    // Remove old controls
    _cableEditMarkers.forEach(function (m) { canvas.remove(m); });
    _cableEditMidpoints.forEach(function (m) { canvas.remove(m); });
    if (_cableEditPreview) { canvas.remove(_cableEditPreview); _cableEditPreview = null; }
    _cableEditMarkers   = [];
    _cableEditMidpoints = [];

    // Draw the polyline preview
    if (_cableEditPoints.length >= 2) {
      _cableEditPreview = new fabric.Polyline(_cableEditPoints.slice(), {
        fill: 'transparent',
        stroke: _cableEditTarget.stroke || '#e91e63',
        strokeWidth: _cableEditTarget.strokeWidth || 3,
        strokeLineCap: 'round', strokeLineJoin: 'round',
        selectable: false, evented: false,
        objectCaching: false, excludeFromExport: true,
      });
      canvas.add(_cableEditPreview);
      canvas.sendObjectToBack(_cableEditPreview);
    }

    // Vertex control circles (draggable)
    _cableEditPoints.forEach(function (pt, idx) {
      var marker = new fabric.Circle({
        left: pt.x, top: pt.y, radius: 7,
        fill: '#1e88e5', stroke: '#fff', strokeWidth: 2,
        originX: 'center', originY: 'center',
        selectable: true, evented: true,
        hasControls: false, hasBorders: false,
        excludeFromExport: true,
      });
      marker._cableEditIdx = idx;
      marker._cableEditType = 'vertex';
      canvas.add(marker);
      _cableEditMarkers.push(marker);
    });

    // Midpoint circles (click to insert new point)
    for (var i = 0; i < _cableEditPoints.length - 1; i++) {
      var a = _cableEditPoints[i];
      var b = _cableEditPoints[i + 1];
      var mx = (a.x + b.x) / 2;
      var my = (a.y + b.y) / 2;
      var mid = new fabric.Circle({
        left: mx, top: my, radius: 5,
        fill: '#66bb6a', stroke: '#fff', strokeWidth: 1,
        originX: 'center', originY: 'center', opacity: 0.7,
        selectable: false, evented: true,
        hasControls: false, hasBorders: false,
        excludeFromExport: true,
        hoverCursor: 'pointer',
      });
      mid._cableEditInsertAfter = i;
      mid._cableEditType = 'midpoint';
      canvas.add(mid);
      _cableEditMidpoints.push(mid);
    }

    canvas.renderAll();
  }

  // Handle dragging of vertex markers
  canvas.on('object:moving', function (opt) {
    if (!_cableEditing) return;
    var obj = opt.target;
    if (obj._cableEditType !== 'vertex') return;
    var idx = obj._cableEditIdx;
    _cableEditPoints[idx] = { x: obj.left, y: obj.top };
    // Refresh preview line (not the control circles, to avoid jitter)
    if (_cableEditPreview) { canvas.remove(_cableEditPreview); _cableEditPreview = null; }
    if (_cableEditPoints.length >= 2) {
      _cableEditPreview = new fabric.Polyline(_cableEditPoints.slice(), {
        fill: 'transparent',
        stroke: _cableEditTarget.stroke || '#e91e63',
        strokeWidth: _cableEditTarget.strokeWidth || 3,
        strokeLineCap: 'round', strokeLineJoin: 'round',
        selectable: false, evented: false,
        objectCaching: false, excludeFromExport: true,
      });
      canvas.add(_cableEditPreview);
      canvas.sendObjectToBack(_cableEditPreview);
    }
  });

  // Handle click on midpoint circles to insert new vertices
  canvas.on('mouse:down', function (opt) {
    if (!_cableEditing) return;
    var obj = opt.target;
    if (!obj || obj._cableEditType !== 'midpoint') return;
    var idx = obj._cableEditInsertAfter;
    var newPt = { x: obj.left, y: obj.top };
    _cableEditPoints.splice(idx + 1, 0, newPt);
    _renderCableEditControls();
  });

  /** Finish cable editing — rebuild the polyline from edited points. */
  function _finishCableEdit(apply) {
    if (!_cableEditing) return;

    // Clean up edit controls
    _cableEditMarkers.forEach(function (m) { canvas.remove(m); });
    _cableEditMidpoints.forEach(function (m) { canvas.remove(m); });
    if (_cableEditPreview) { canvas.remove(_cableEditPreview); _cableEditPreview = null; }
    _cableEditMarkers   = [];
    _cableEditMidpoints = [];

    if (apply && _cableEditTarget && _cableEditPoints.length >= 2) {
      // Normalise points relative to centroid
      var cx = 0, cy = 0;
      _cableEditPoints.forEach(function (p) { cx += p.x; cy += p.y; });
      cx /= _cableEditPoints.length;
      cy /= _cableEditPoints.length;
      var relPts = _cableEditPoints.map(function (p) {
        return { x: p.x - cx, y: p.y - cy };
      });

      // Save properties from original
      var origStroke = _cableEditTarget.stroke;
      var origStrokeWidth = _cableEditTarget.strokeWidth;
      var origDash = _cableEditTarget.strokeDashArray ? _cableEditTarget.strokeDashArray.slice() : null;
      var origOpacity = _cableEditTarget.opacity;
      var origMeta = _cableEditTarget.custom_meta ? Object.assign({}, _cableEditTarget.custom_meta) : { object_type: 'cable' };

      // Remove original and create a new polyline
      canvas.remove(_cableEditTarget);

      var editOpts = {
        left: cx, top: cy,
        fill: 'transparent', stroke: origStroke,
        strokeWidth: origStrokeWidth,
        objectCaching: false, hasRotatingPoint: true,
        originX: 'center', originY: 'center',
        strokeLineCap: 'round', strokeLineJoin: 'round',
      };
      if (origDash) editOpts.strokeDashArray = origDash;
      if (origOpacity != null) editOpts.opacity = origOpacity;
      var newPolyline = new fabric.Polyline(relPts, editOpts);
      _attachMeta(newPolyline, origMeta);
      canvas.add(newPolyline);
      canvas.setActiveObject(newPolyline);
    } else if (_cableEditTarget) {
      // Cancelled — restore original visibility
      _cableEditTarget.set({ selectable: true, evented: true, visible: true });
    }

    _cableEditing     = false;
    _cableEditTarget  = null;
    _cableEditPoints  = [];
    canvas.selection  = true;
    canvas.renderAll();

    var editPanel = document.getElementById('cable_edit_panel');
    if (editPanel) editPanel.style.display = 'none';
  }

  window.finish_cable_edit = function () { _finishCableEdit(true); };
  window.cancel_cable_edit = function () { _finishCableEdit(false); };

  /** Remove the last point while editing a cable's vertices. */
  window.undo_cable_edit_point = function () {
    if (!_cableEditing || _cableEditPoints.length <= 2) return;
    _cableEditPoints.pop();
    _renderCableEditControls();
  };

  window.add_label = function () {
    var c    = _viewportCenter();
    var text = new fabric.Textbox('Label', {
      left: c.x, top: c.y,
      fontSize: 20, fill: '#212529', fontFamily: 'Arial',
      editable: true, width: 200,
    });
    _attachMeta(text, { object_type: 'label' });
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
  };

  window.add_line = function () {
    var c    = _viewportCenter();
    var line = new fabric.Line(
      [c.x - 125, c.y, c.x + 125, c.y],
      { stroke: '#dc3545', strokeWidth: 3, selectable: true, hasRotatingPoint: true }
    );
    _attachMeta(line, { object_type: 'line' });
    canvas.add(line);
    canvas.setActiveObject(line);
    canvas.renderAll();
  };

  window.add_circle = function () {
    var circle = new fabric.Circle({
      radius: 50, fill: '#0dcaf080', stroke: '#0dcaf0', strokeWidth: 2,
      hasRotatingPoint: true,
    });
    _attachMeta(circle, { object_type: 'circle' });
    _placeAtViewportCenter(circle);
    canvas.add(circle);
    canvas.setActiveObject(circle);
    canvas.renderAll();
  };

  // -------------------------------------------------------------------------
  // Copy & Paste — duplicate drawing objects (zone, line, location zone,
  //                pointer, circle, label)
  // -------------------------------------------------------------------------

  var _clipboard = null; // serialized object data for paste

  /**
   * Copy the currently selected object to the internal clipboard.
   * Racks and devices are excluded — they represent unique infrastructure
   * items and should not be duplicated on the canvas.
   */
  window.copy_selected = function () {
    var obj = canvas.getActiveObject();
    if (!obj) return;

    // Block copy of racks / devices (unique NetBox objects).
    var meta = obj.custom_meta;
    if (meta && (meta.object_type === 'rack' || meta.object_type === 'device')) {
      console.warn('netbox_dwg: copy is not supported for racks / devices');
      return;
    }

    // Clone via Fabric's built-in clone method which returns a Promise in v6.
    obj.clone().then(function (cloned) {
      _clipboard = cloned;
    });
  };

  /**
   * Paste the clipboard object onto the canvas, offset slightly from the
   * original position so the copy is visually distinguishable.
   */
  window.paste_clipboard = function () {
    if (!_clipboard) return;

    _clipboard.clone().then(function (cloned) {
      canvas.discardActiveObject();

      // Offset the clone so it doesn't land exactly on top of the original.
      cloned.set({
        left: (cloned.left || 0) + 20,
        top:  (cloned.top  || 0) + 20,
        evented: true,
      });

      // Re-attach custom_meta and toObject override.
      if (cloned.custom_meta) {
        // For pasted copies strip object_id so they're treated as new drawings.
        var newMeta = Object.assign({}, cloned.custom_meta);
        delete newMeta.object_id;
        _attachMeta(cloned, newMeta);
      }

      // Restore editor-specific controls (e.g. mid-edge handles on location zones).
      if (cloned.type === 'group' && cloned.custom_meta) {
        if (cloned.custom_meta.object_type === 'location_zone') {
          _applyZoneControls(cloned);
        }
      }

      canvas.add(cloned);
      canvas.setActiveObject(cloned);
      canvas.requestRenderAll();
    });
  };

  // -------------------------------------------------------------------------
  // Selection actions: delete, fill, stroke, opacity
  // -------------------------------------------------------------------------

  window.delete_selected = function () {
    var active = canvas.getActiveObjects();
    if (active.length) {
      active.forEach(function (obj) {
        // Keep placement tracking lists consistent so sidebar stays accurate.
        var meta = obj.custom_meta;
        if (meta && meta.object_id) {
          var id  = String(meta.object_id);
          var arr = meta.object_type === 'rack' ? _placedRackIds : _placedDeviceIds;
          var idx = arr.indexOf(id);
          if (idx !== -1) arr.splice(idx, 1);
        }
        canvas.remove(obj);
      });
      canvas.discardActiveObject();
      canvas.renderAll();
      _refreshSidebars();
    }
  };

  window.update_fill_color = function (color) {
    var obj = canvas.getActiveObject();
    if (!obj) return;
    if (obj.type === 'group') {
      obj.getObjects().forEach(function (child) {
        if (child.type !== 'textbox' && child.type !== 'text') child.set('fill', color);
      });
    } else {
      obj.set('fill', color);
    }
    canvas.renderAll();
  };

  window.update_stroke_color = function (color) {
    var obj = canvas.getActiveObject();
    if (!obj) return;
    obj.set('stroke', color);
    if (obj.type === 'group') {
      obj.getObjects().forEach(function (child) { child.set('stroke', color); });
    }
    canvas.renderAll();
  };

  window.update_opacity = function (val) {
    var obj = canvas.getActiveObject();
    if (!obj) return;
    obj.set('opacity', val / 100);
    canvas.renderAll();
  };

  // -------------------------------------------------------------------------
  // Layer order
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // Layers — named, reorderable, togglable visibility
  // -------------------------------------------------------------------------

  /** Canonical layer list.  Mutated in place; persisted via _getCanvasJSON. */
  var _layers = [{ id: U.DEFAULT_LAYER_ID, name: 'Default', visible: true }];

  /** The currently active layer that new objects are added to. */
  var _activeLayerId = U.DEFAULT_LAYER_ID;

  /** Populate _layers from saved canvas JSON (called after loadFromJSON). */
  function _initLayersFromCanvas(canvasJSON) {
    _layers = U.get_layers_from_json(canvasJSON);
    _activeLayerId = _layers.length ? _layers[0].id : U.DEFAULT_LAYER_ID;
    _renderLayerPanel();
  }

  // --- Layer panel rendering (sidebar) ---

  /** Track which layers are expanded (show object list). */
  var _expandedLayers = {};

  // Use shared display helpers from utils.js
  function _objDisplayName(obj) { return U.obj_display_name(obj); }

  function _renderLayerPanel() {
    var panel = document.getElementById('layers-panel');
    if (!panel) return;
    panel.innerHTML = '';

    _layers.forEach(function (layer) {
      var wrapper = document.createElement('div');
      wrapper.className = 'layer-group';
      wrapper.setAttribute('data-layer-id', layer.id);

      // --- Layer header row ---
      var div = document.createElement('div');
      div.className = 'layer-item' +
        (!layer.visible ? ' layer-hidden' : '') +
        (layer.id === _activeLayerId ? ' layer-active' : '');
      div.setAttribute('draggable', 'true');

      // Drag handle
      var grip = document.createElement('span');
      grip.className = 'mdi mdi-drag-vertical layer-grip';
      div.appendChild(grip);

      // Expand/collapse chevron
      var objsOnLayer = _getObjectsOnLayer(layer.id);
      var isExpanded = !!_expandedLayers[layer.id];
      var chevron = document.createElement('button');
      chevron.className = 'layer-btn layer-chevron';
      chevron.title = isExpanded ? 'Collapse' : 'Expand';
      chevron.innerHTML = isExpanded
        ? '<i class="mdi mdi-chevron-down"></i>'
        : '<i class="mdi mdi-chevron-right"></i>';
      chevron.addEventListener('click', function (e) {
        e.stopPropagation();
        _expandedLayers[layer.id] = !_expandedLayers[layer.id];
        _renderLayerPanel();
      });
      div.appendChild(chevron);

      // Name
      var nameSpan = document.createElement('span');
      nameSpan.className = 'layer-name';
      nameSpan.textContent = layer.name;
      nameSpan.title = 'Click to set active layer';
      nameSpan.style.cursor = 'pointer';
      nameSpan.addEventListener('click', function (e) {
        e.stopPropagation();
        _activeLayerId = layer.id;
        _renderLayerPanel();
      });
      div.appendChild(nameSpan);

      // Object count badge
      var badge = document.createElement('span');
      badge.className = 'badge text-bg-secondary me-1';
      badge.style.fontSize = '0.7rem';
      badge.textContent = objsOnLayer.length;
      badge.title = objsOnLayer.length + ' object(s)';
      div.appendChild(badge);

      // Visibility toggle
      var eyeBtn = document.createElement('button');
      eyeBtn.className = 'layer-btn';
      eyeBtn.title = layer.visible ? 'Hide layer' : 'Show layer';
      eyeBtn.innerHTML = layer.visible
        ? '<i class="mdi mdi-eye"></i>'
        : '<i class="mdi mdi-eye-off"></i>';
      eyeBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        layer.visible = !layer.visible;
        U.apply_layer_visibility(canvas, _layers);
        _renderLayerPanel();
      });
      div.appendChild(eyeBtn);

      // Rename
      var renameBtn = document.createElement('button');
      renameBtn.className = 'layer-btn';
      renameBtn.title = 'Rename layer';
      renameBtn.innerHTML = '<i class="mdi mdi-pencil"></i>';
      renameBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        document.getElementById('rename_layer_id').value = layer.id;
        document.getElementById('rename_layer_input').value = layer.name;
        _showModal('rename_layer_modal');
      });
      div.appendChild(renameBtn);

      // Delete (not for the last remaining layer)
      if (_layers.length > 1) {
        var delBtn = document.createElement('button');
        delBtn.className = 'layer-btn';
        delBtn.title = 'Delete layer (moves objects to Default)';
        delBtn.innerHTML = '<i class="mdi mdi-close"></i>';
        delBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          _deleteLayer(layer.id);
        });
        div.appendChild(delBtn);
      }

      // --- Layer-level drag & drop reorder ---
      div.addEventListener('dragstart', function (e) {
        // Only start layer drag from the grip handle
        if (!e.target.classList.contains('layer-grip')) {
          e.preventDefault(); return;
        }
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('application/x-layer-id', layer.id);
        div.style.opacity = '0.4';
      });
      div.addEventListener('dragend', function () {
        div.style.opacity = '';
        _clearDragOver();
      });
      div.addEventListener('dragover', function (e) {
        e.preventDefault();
        var hasLayerDrag = Array.prototype.indexOf.call(e.dataTransfer.types, 'application/x-layer-id') !== -1;
        var hasObjDrag   = Array.prototype.indexOf.call(e.dataTransfer.types, 'application/x-obj-index') !== -1;
        if (hasLayerDrag) {
          e.dataTransfer.dropEffect = 'move';
          _clearDragOver();
          div.classList.add('drag-over');
        } else if (hasObjDrag) {
          e.dataTransfer.dropEffect = 'move';
          _clearDragOver();
          div.classList.add('drag-over-obj');
        }
      });
      div.addEventListener('dragleave', function () {
        div.classList.remove('drag-over');
        div.classList.remove('drag-over-obj');
      });
      div.addEventListener('drop', function (e) {
        e.preventDefault();
        _clearDragOver();
        // Layer reorder
        var fromLayerId = e.dataTransfer.getData('application/x-layer-id');
        if (fromLayerId) {
          if (fromLayerId !== layer.id) _reorderLayer(fromLayerId, layer.id);
          return;
        }
        // Object dropped onto layer header → move to this layer
        var objIdx = e.dataTransfer.getData('application/x-obj-index');
        if (objIdx !== '') {
          _moveObjToLayer(parseInt(objIdx, 10), layer.id);
        }
      });

      wrapper.appendChild(div);

      // --- Expanded object list ---
      if (isExpanded && objsOnLayer.length > 0) {
        var listDiv = document.createElement('div');
        listDiv.className = 'layer-objects';

        objsOnLayer.forEach(function (entry) {
          var obj = entry.obj;
          var objIndex = entry.index;
          var info = _objDisplayName(obj);

          var row = document.createElement('div');
          row.className = 'layer-obj-row';
          row.setAttribute('draggable', 'true');
          row.title = info.type + (info.name ? ': ' + info.name : '');

          // Drag handle for object
          var objGrip = document.createElement('span');
          objGrip.className = 'mdi mdi-drag-horizontal layer-obj-grip';
          row.appendChild(objGrip);

          // Icon
          var ico = document.createElement('i');
          ico.className = 'mdi ' + info.icon + ' layer-obj-icon';
          row.appendChild(ico);

          // Label
          var lbl = document.createElement('span');
          lbl.className = 'layer-obj-label';
          lbl.textContent = info.name || info.type;
          row.appendChild(lbl);

          // Click → select on canvas
          row.addEventListener('click', function (e) {
            e.stopPropagation();
            canvas.discardActiveObject();
            canvas.setActiveObject(obj);
            canvas.requestRenderAll();
          });

          // Highlight if currently selected
          var activeObj = canvas.getActiveObject();
          if (activeObj === obj) row.classList.add('layer-obj-selected');

          // --- Object drag between layers ---
          row.addEventListener('dragstart', function (e) {
            e.stopPropagation();
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('application/x-obj-index', String(objIndex));
          });
          row.addEventListener('dragend', function () { _clearDragOver(); });

          listDiv.appendChild(row);
        });

        wrapper.appendChild(listDiv);
      } else if (isExpanded) {
        var emptyMsg = document.createElement('div');
        emptyMsg.className = 'layer-objects';
        emptyMsg.innerHTML = '<div class="text-muted small px-3 py-1">No objects</div>';
        wrapper.appendChild(emptyMsg);
      }

      panel.appendChild(wrapper);
    });
  }

  function _getObjectsOnLayer(layerId) { return U.get_objects_on_layer(canvas, layerId); }

  /** Move a canvas object (by index) to a different layer. */
  function _moveObjToLayer(objIndex, targetLayerId) {
    var objs = canvas.getObjects();
    if (objIndex < 0 || objIndex >= objs.length) return;
    var obj = objs[objIndex];
    if (obj.custom_meta) {
      obj.custom_meta.layer = targetLayerId;
    }
    U.apply_layer_visibility(canvas, _layers);
    _renderLayerPanel();
  }

  function _clearDragOver() {
    var items = document.querySelectorAll('#layers-panel .layer-item, #layers-panel .layer-obj-row');
    for (var i = 0; i < items.length; i++) {
      items[i].classList.remove('drag-over');
      items[i].classList.remove('drag-over-obj');
    }
  }

  // Re-render layer panel when selection changes so the highlight stays current.
  canvas.on('selection:created',  function () { _renderLayerPanel(); });
  canvas.on('selection:updated',  function () { _renderLayerPanel(); });
  canvas.on('selection:cleared',  function () { _renderLayerPanel(); });

  /** Reorder: move the layer with fromId to the position of toId. */
  function _reorderLayer(fromId, toId) {
    var fromIdx = -1, toIdx = -1;
    _layers.forEach(function (l, i) {
      if (l.id === fromId) fromIdx = i;
      if (l.id === toId) toIdx = i;
    });
    if (fromIdx === -1 || toIdx === -1) return;
    var moved = _layers.splice(fromIdx, 1)[0];
    _layers.splice(toIdx, 0, moved);
    _renderLayerPanel();
  }

  /** Delete a layer, moving all its objects to Default. */
  function _deleteLayer(layerId) {
    if (_layers.length <= 1) return;
    // Ensure there's a default layer to move to
    var defaultLayer = _layers.find(function (l) { return l.id === U.DEFAULT_LAYER_ID; });
    var targetId = defaultLayer ? U.DEFAULT_LAYER_ID : _layers[0].id;
    if (layerId === targetId && _layers.length > 1) {
      targetId = _layers[1].id;
    }

    // Move objects
    canvas.getObjects().forEach(function (obj) {
      if (U.get_object_layer(obj) === layerId) {
        if (obj.custom_meta) obj.custom_meta.layer = targetId;
      }
    });

    // Remove layer
    _layers = _layers.filter(function (l) { return l.id !== layerId; });
    if (_activeLayerId === layerId) _activeLayerId = targetId;

    U.apply_layer_visibility(canvas, _layers);
    _renderLayerPanel();
  }

  // --- Public layer functions (called from HTML / modals) ---

  window.add_layer = function () {
    var newId = U.new_layer_id();
    _layers.push({ id: newId, name: 'Layer ' + _layers.length, visible: true });
    _activeLayerId = newId;
    _renderLayerPanel();
  };

  window.apply_rename_layer = function () {
    var layerId = document.getElementById('rename_layer_id').value;
    var newName = document.getElementById('rename_layer_input').value.trim();
    if (!newName) return;
    _layers.forEach(function (l) {
      if (l.id === layerId) l.name = newName;
    });
    _hideModal('rename_layer_modal');
    _renderLayerPanel();
  };

  /** Show the "Move to Layer" modal for the selected object(s). */
  window.move_to_layer = function () {
    var active = canvas.getActiveObjects();
    if (!active.length) return;
    var sel = document.getElementById('move_layer_select');
    sel.innerHTML = '';
    _layers.forEach(function (l) {
      var opt = document.createElement('option');
      opt.value = l.id;
      opt.textContent = l.name;
      sel.appendChild(opt);
    });
    _showModal('move_layer_modal');
  };

  window.apply_move_to_layer = function () {
    var targetId = document.getElementById('move_layer_select').value;
    var active = canvas.getActiveObjects();
    active.forEach(function (obj) {
      if (obj.custom_meta) {
        obj.custom_meta.layer = targetId;
      }
    });
    U.apply_layer_visibility(canvas, _layers);
    _hideModal('move_layer_modal');
    _renderLayerPanel();
  };

  // -------------------------------------------------------------------------
  // Text-scaling normaliser
  // -------------------------------------------------------------------------
  //
  // Fabric.js scales objects (including Textbox) by changing scaleX/scaleY,
  // which visually stretches or compresses text glyphs when the aspect ratio
  // changes.  We intercept object:scaled (fires once after the drag ends) and
  // convert the accumulated scale into actual font-size and width changes,
  // then reset scaleX/scaleY to 1 so text always renders crisply.
  //
  // We only correct AFTER the drag ends (not live) because modifying object
  // dimensions mid-gesture causes Fabric to recalculate its bounding box,
  // which invalidates the in-progress scale ratio and produces jitter.
  //
  // NOTE: Fabric.js 6 removed the 'object:scaled' event. Scale gestures now
  // fire 'object:modified' with action 'scale', 'scaleX', or 'scaleY'.
  //
  // Covers:
  //   • Standalone labels (add_label returns a fabric.Textbox)
  //   • Groups that contain Rect + Textbox children (racks, devices, zones)

  canvas.on('object:modified', function (opt) {
    var action = opt.action || '';
    if (action !== 'scale' && action !== 'scaleX' && action !== 'scaleY') return;
    var obj = opt.target;
    if (!obj) return;

    // --- 1. Standalone Textbox / Text ---
    // Bake the drag-scale into font size + width and reset scale to 1 so
    // subsequent renders stay crisp rather than stretching glyphs.
    if (obj.type === 'textbox' || obj.type === 'text') {
      var newFontSize = Math.max(6, Math.round(obj.fontSize * obj.scaleY));
      var newWidth    = Math.max(20, Math.round(obj.width * obj.scaleX));
      obj.set({ fontSize: newFontSize, width: newWidth, scaleX: 1, scaleY: 1 });
      obj.dirty = true;
      obj.setCoords();
      canvas.requestRenderAll();
      return;
    }

    // --- 2. Groups (rack / device / location_zone / etc.) ---
    // Each child has coordinates in the group's centre-relative local space.
    // Multiply every dimension and offset by the respective axis scale, then
    // reset the group's own scaleX/Y to 1 and store the new logical size.
    if (obj.type === 'group' && (obj.scaleX !== 1 || obj.scaleY !== 1)) {
      var sX = obj.scaleX;
      var sY = obj.scaleY;
      var newW = Math.max(20, Math.round(obj.width  * sX));
      var newH = Math.max(20, Math.round(obj.height * sY));

      // Font scales by the SMALLER axis so shrinking width or height reduces
      // font size proportionally, preventing overflow when box is made narrower.
      var sFont = Math.min(sX, sY);

      // First pass: find new rect width to pin textbox width to it.
      var newRectW = newW;
      obj.getObjects().forEach(function (child) {
        if (child.type === 'rect') {
          newRectW = Math.max(4, Math.round(child.width * sX));
        }
      });

      obj.getObjects().forEach(function (child) {
        // Scale the child's offset from the group centre.
        child.left = (child.left || 0) * sX;
        child.top  = (child.top  || 0) * sY;

        if (child.type === 'rect') {
          child.set({
            width:  Math.max(4, Math.round(child.width  * sX)),
            height: Math.max(4, Math.round(child.height * sY)),
          });
        } else if (child.type === 'textbox') {
          child.set({
            fontSize: Math.max(6, Math.round(child.fontSize * sFont)),
            width:    Math.max(10, newRectW - 4),
          });
        } else if (child.type === 'text') {
          child.set({ fontSize: Math.max(6, Math.round(child.fontSize * sFont)) });
        }
        child.dirty = true;
      });

      // Bake group scale into its stored logical dimensions.
      obj.width  = newW;
      obj.height = newH;
      obj.scaleX = 1;
      obj.scaleY = 1;
      obj.dirty  = true;
      obj.setCoords();
      canvas.requestRenderAll();
    }
  });

  window.bring_to_front = function () {
    var obj = canvas.getActiveObject(); if (!obj) return;
    canvas.bringObjectToFront(obj); canvas.renderAll();
  };
  window.send_to_back = function () {
    var obj = canvas.getActiveObject(); if (!obj) return;
    canvas.sendObjectToBack(obj); canvas.renderAll();
  };
  window.bring_forward = function () {
    var obj = canvas.getActiveObject(); if (!obj) return;
    canvas.bringObjectForward(obj); canvas.renderAll();
  };
  window.send_backward = function () {
    var obj = canvas.getActiveObject(); if (!obj) return;
    canvas.sendObjectBackwards(obj); canvas.renderAll();
  };

  // -------------------------------------------------------------------------
  // Lock / unlock object position
  // -------------------------------------------------------------------------

  window.toggle_lock = function () {
    var obj = canvas.getActiveObject();
    if (!obj) return;
    var locked = !!(obj.lockMovementX && obj.lockMovementY);
    obj.set({ lockMovementX: !locked, lockMovementY: !locked });
    _updateLockButton(obj);
    canvas.renderAll();
  };

  function _updateLockButton(obj) {
    var btn = document.getElementById('lock_btn');
    if (!btn) return;
    var locked = obj && obj.lockMovementX && obj.lockMovementY;
    if (locked) {
      btn.innerHTML = '<i class="mdi mdi-lock"></i> Unlock Position';
      btn.className = 'btn btn-sm btn-warning w-100';
    } else {
      btn.innerHTML = '<i class="mdi mdi-lock-open-outline"></i> Lock Position';
      btn.className = 'btn btn-sm btn-outline-warning w-100';
    }
  }

  // Sync sidebar UI when selection changes.
  function _syncSelectionUI(obj) {
    _updateLockButton(obj);
    if (!obj) return;
    var opSlider = document.getElementById('opacity_slider');
    if (opSlider) opSlider.value = Math.round((obj.opacity != null ? obj.opacity : 1) * 100);
    var fillEl = document.getElementById('fill_color');
    if (fillEl) {
      var fill = obj.fill;
      if (obj.type === 'group') {
        obj.getObjects().forEach(function (ch) { if (ch.type === 'rect') fill = ch.fill; });
      }
      if (fill && typeof fill === 'string' && fill.charAt(0) === '#' && fill.length === 7) {
        fillEl.value = fill;
      }
    }
  }
  canvas.on('selection:created', function (opt) { _syncSelectionUI(opt.selected && opt.selected[0]); });
  canvas.on('selection:updated', function (opt) { _syncSelectionUI(opt.selected && opt.selected[0]); });
  canvas.on('selection:cleared', function ()    { _syncSelectionUI(null); });

  // -------------------------------------------------------------------------
  // Keyboard shortcuts
  // -------------------------------------------------------------------------

  document.addEventListener('keydown', function (e) {
    // Escape cancels zone drawing, cable drawing, or cable editing
    if (e.key === 'Escape' && _zoneDrawing) { window.cancel_zone_draw(); return; }
    if (e.key === 'Escape' && _cableDrawing) { window.cancel_cable_draw(); return; }
    if (e.key === 'Escape' && _cableEditing) { window.cancel_cable_edit(); return; }
    // Ctrl+Z undoes the last point while drawing
    if (e.key === 'z' && (e.ctrlKey || e.metaKey) && _zoneDrawing) { window.undo_zone_point(); e.preventDefault(); return; }
    if (e.key === 'z' && (e.ctrlKey || e.metaKey) && _cableDrawing) { window.undo_cable_point(); e.preventDefault(); return; }
    // Enter finishes cable drawing or cable editing
    if (e.key === 'Enter' && _cableDrawing && _cablePoints.length >= 2) { window.finish_cable_draw(); return; }
    if (e.key === 'Enter' && _cableEditing) { window.finish_cable_edit(); return; }

    // Ctrl+C / Ctrl+V — copy & paste
    if (e.key === 'c' && (e.ctrlKey || e.metaKey) && !_zoneDrawing) {
      window.copy_selected(); e.preventDefault(); return;
    }
    if (e.key === 'v' && (e.ctrlKey || e.metaKey) && !_zoneDrawing) {
      window.paste_clipboard(); e.preventDefault(); return;
    }

    var obj = canvas.getActiveObject();
    if (!obj) return;
    if (obj.isEditing) return;   // don't steal keys from textbox edit mode
    var step = 5;

    if (!e.shiftKey) {
      if      (e.keyCode === 37) { obj.set('left', obj.left - step); canvas.renderAll(); e.preventDefault(); }
      else if (e.keyCode === 39) { obj.set('left', obj.left + step); canvas.renderAll(); e.preventDefault(); }
      else if (e.keyCode === 38) { obj.set('top',  obj.top  - step); canvas.renderAll(); e.preventDefault(); }
      else if (e.keyCode === 40) { obj.set('top',  obj.top  + step); canvas.renderAll(); e.preventDefault(); }
    } else {
      if      (e.keyCode === 37) { obj.rotate((obj.angle || 0) - 15); canvas.renderAll(); }
      else if (e.keyCode === 39) { obj.rotate((obj.angle || 0) + 15); canvas.renderAll(); }
    }

    if (e.keyCode === 46) { window.delete_selected(); }
  });

  // -------------------------------------------------------------------------
  // Dimensions & background
  // -------------------------------------------------------------------------

  window.update_dimensions = function () {
    var width  = document.getElementById('width_value').value;
    var height = document.getElementById('height_value').value;
    var unit   = document.getElementById('measurement_unit').value;
    var scale  = 100;
    var w = unit === 'ft' ? (width  / 3.28) * scale : width  * scale;
    var h = unit === 'ft' ? (height / 3.28) * scale : height * scale;

    $.ajax({
      type: 'PATCH', url: '/api/plugins/dwg/floors/' + obj_pk + '/',
      dataType: 'json',
      headers: { 'X-CSRFToken': csrf, 'Content-Type': 'application/json' },
      data: JSON.stringify({
        canvas: _getCanvasJSON(), width: parseFloat(width),
        height: parseFloat(height), measurement_unit: unit,
      }),
      success: function () {
        canvas.setWidth(w); canvas.setHeight(h); canvas.renderAll();
        _hideModal('dimensions_modal');
      },
      error: function (err) { console.error('Error updating dimensions:', err); },
    });
  };

  window.update_background = function () {
    var sel           = document.getElementById('id_assigned_image');
    var assignedImage = sel ? sel.value : null;
    if (assignedImage === '') assignedImage = null;
    if (!assignedImage) {
      canvas.backgroundImage = null;
      U._hasBackgroundImage  = false;
      U.resize_canvas(canvas, window);
    }

    $.ajax({
      type: 'PATCH', url: '/api/plugins/dwg/floors/' + obj_pk + '/',
      dataType: 'json',
      headers: { 'X-CSRFToken': csrf, 'Content-Type': 'application/json' },
      data: JSON.stringify({ assigned_image: assignedImage, canvas: _getCanvasJSON() }),
      success: function (floor) {
        if (floor.assigned_image) {
          var imgUrl = floor.assigned_image.external_url || floor.assigned_image.file;
          if (imgUrl) { U.set_background(canvas, imgUrl).then(function () { _hideModal('background_modal'); }); return; }
        }
        _hideModal('background_modal');
      },
      error: function (err) { console.error('Error updating background:', err); },
    });
  };

  // -------------------------------------------------------------------------
  // Save
  // -------------------------------------------------------------------------

  window.save_floor = function () {
    $.ajax({
      type: 'PATCH', url: '/api/plugins/dwg/floors/' + obj_pk + '/',
      dataType: 'json',
      headers: { 'X-CSRFToken': csrf, 'Content-Type': 'application/json' },
      data: JSON.stringify({ canvas: _getCanvasJSON() }),
      error: function (err) { console.error('Error saving floor:', err); },
    });
  };

  window.save_and_redirect = function () {
    $.ajax({
      type: 'PATCH', url: '/api/plugins/dwg/floors/' + obj_pk + '/',
      dataType: 'json',
      headers: { 'X-CSRFToken': csrf, 'Content-Type': 'application/json' },
      data: JSON.stringify({ canvas: _getCanvasJSON() }),
      success: function () { window.location.href = '/plugins/dwg/floors/' + obj_pk + '/'; },
      error: function (err) { console.error('Error saving floor:', err); },
    });
  };

  // -------------------------------------------------------------------------
  // Helpers
  // -------------------------------------------------------------------------

  function _getCanvasJSON() {
    // Use toObject() explicitly — in Fabric 6, toJSON() ignores the
    // propertiesToInclude argument, so toObject() is the correct call.
    // Our _attachMeta override on each instance handles the primary path;
    // the index-injection below is a belt-and-suspenders fallback.
    var json = canvas.toObject([
      'id', 'text', '_controlsVisibility', 'custom_meta',
      'lockMovementX', 'lockMovementY', 'lockScalingX', 'lockScalingY',
      'evented', 'selectable',
    ]);

    var liveObjs = canvas.getObjects();
    (json.objects || []).forEach(function (serialObj, idx) {
      var live = liveObjs[idx];
      if (live && live.custom_meta) {
        serialObj.custom_meta = live.custom_meta;
      }
    });

    // Persist layers alongside the canvas objects
    json._layers = _layers;

    return json;
  }

  /**
   * After loadFromJSON, restore editor-specific UI state.
   * Location zone groups need their mid-edge resize handles re-enabled;
   * _controlsVisibility persists in JSON but the setControlsVisibility() call
   * ensures Fabric 6 applies it correctly on the live object.
   *
   * Also initializes the layers panel from saved canvas data.
   */
  function _restoreEditorState(canvasJSON) {
    // Initialize layers from the saved canvas JSON
    _initLayersFromCanvas(canvasJSON || {});
    canvas.getObjects().forEach(function (obj) {
      // Re-apply the toObject override for objects loaded from the database.
      // loadFromJSON sets obj.custom_meta via the reviver but does not add the
      // override.  Without it, a plain save (without removing/re-adding the
      // object) would rely solely on the post-process injection in _getCanvasJSON.
      // Re-applying here makes serialization reliable in all paths.
      if (obj.custom_meta) {
        _attachMeta(obj, obj.custom_meta);
      }

      if (obj.type === 'group' && obj.custom_meta) {
        if (obj.custom_meta.object_type === 'location_zone') {
          _applyZoneControls(obj);
        }
        // Clear legacy lockScalingX/Y set by older saves — racks and devices are resizable.
        if (obj.custom_meta.object_type === 'rack' || obj.custom_meta.object_type === 'device') {
          obj.set({ lockScalingX: false, lockScalingY: false });
        }
      }
    });
    // Apply layer visibility from saved state
    U.apply_layer_visibility(canvas, _layers);
    canvas.renderAll();
  }

  // -------------------------------------------------------------------------
  // Initialize
  // -------------------------------------------------------------------------

  document.addEventListener('DOMContentLoaded', function () {
    U.init_floor(obj_pk, canvas, 'edit', function (canvasJSON) {
      _restoreEditorState(canvasJSON);
      // Load sidebars AFTER canvas is populated so _placedIds() is accurate.
      _loadRackSidebar();
      _loadDeviceSidebar();
    });
  });

})();
