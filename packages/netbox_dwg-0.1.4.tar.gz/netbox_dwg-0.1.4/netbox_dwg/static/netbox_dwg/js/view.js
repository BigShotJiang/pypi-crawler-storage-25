/**
 * netbox_dwg — Read-only canvas viewer.
 *
 * Depends on utils.js being loaded first (provides window.NetBoxDWG).
 */

(function () {
  'use strict';

  var U = window.NetBoxDWG;

  var floor_id       = document.getElementById('floor_id').value;
  var highlightType  = (document.getElementById('highlight_type') || {}).value || '';
  var highlightId    = (document.getElementById('highlight_id')   || {}).value || '';

  var canvas = new fabric.Canvas('canvas', {
    selection: false,
    preserveObjectStacking: true,
  });

  U.resize_canvas(canvas, window);
  window.addEventListener('resize', function () {
    U.resize_canvas(canvas, window);
  });

  // Non-passive wheel listener (fixes zoom freeze in modern browsers)
  U.setup_zoom(canvas);

  canvas.on('mouse:down', function (opt) {
    U.start_pan(opt, canvas);
  });
  canvas.on('mouse:move', function (opt) {
    U.move_pan(opt, canvas);
  });
  canvas.on('mouse:up', function () {
    U.stop_pan(canvas);
  });

  // Export SVG button
  var exportBtn = document.getElementById('export_svg');
  if (exportBtn) {
    exportBtn.addEventListener('click', function () {
      U.export_svg(canvas);
    });
  }

  // ---------------------------------------------------------------------------
  // Double-click navigation — open rack/device detail page
  // ---------------------------------------------------------------------------

  var _NAVIGABLE_TYPES = {
    rack:   '/dcim/racks/',
    device: '/dcim/devices/',
  };

  canvas.on('mouse:dblclick', function (opt) {
    var target = opt.target;
    if (!target || !target.custom_meta) return;
    var meta = target.custom_meta;
    var basePath = _NAVIGABLE_TYPES[meta.object_type];
    if (basePath && meta.object_id) {
      window.location.href = basePath + encodeURIComponent(meta.object_id) + '/';
    }
  });

  /**
   * After loading, make rack/device objects interactive (evented) so they
   * receive double-click events, while keeping them non-selectable.
   */
  function _enableNavigableObjects() {
    canvas.getObjects().forEach(function (obj) {
      var meta = obj.custom_meta;
      if (meta && _NAVIGABLE_TYPES[meta.object_type] && meta.object_id) {
        obj.set({ evented: true, selectable: false, hoverCursor: 'pointer' });
      }
    });
    canvas.renderAll();
  }

  document.addEventListener('DOMContentLoaded', function () {
    U.init_floor(floor_id, canvas, 'readonly', function (canvasJSON) {
      _initViewLayers(canvasJSON);
      _enableNavigableObjects();
      if (highlightType && highlightId) {
        _highlightObject(highlightType, highlightId);
      }
    });
  });

  // ---------------------------------------------------------------------------
  // Layer panel — Photoshop-style expandable list with visibility toggles
  // ---------------------------------------------------------------------------

  var _viewLayers = [];
  var _expandedViewLayers = {};

  function _initViewLayers(canvasJSON) {
    _viewLayers = U.get_layers_from_json(canvasJSON || {});
    // Only show the panel if there are multiple layers
    if (_viewLayers.length <= 1) return;

    var col = document.getElementById('view-layers-col');
    if (col) col.style.display = '';

    // Expand all layers by default in view mode
    _viewLayers.forEach(function (l) { _expandedViewLayers[l.id] = true; });

    _renderViewLayerPanel();
  }

  function _renderViewLayerPanel() {
    var panel = document.getElementById('view-layers-panel');
    if (!panel) return;
    panel.innerHTML = '';

    _viewLayers.forEach(function (layer) {
      var group = document.createElement('div');
      group.className = 'view-layer-group';

      // --- Layer header ---
      var header = document.createElement('div');
      header.className = 'view-layer-item' + (!layer.visible ? ' layer-hidden' : '');

      // Expand/collapse chevron
      var objsOnLayer = U.get_objects_on_layer(canvas, layer.id);
      var isExpanded = !!_expandedViewLayers[layer.id];
      var chevron = document.createElement('button');
      chevron.className = 'view-layer-btn';
      chevron.title = isExpanded ? 'Collapse' : 'Expand';
      chevron.innerHTML = isExpanded
        ? '<i class="mdi mdi-chevron-down"></i>'
        : '<i class="mdi mdi-chevron-right"></i>';
      chevron.addEventListener('click', function (e) {
        e.stopPropagation();
        _expandedViewLayers[layer.id] = !_expandedViewLayers[layer.id];
        _renderViewLayerPanel();
      });
      header.appendChild(chevron);

      // Name
      var nameSpan = document.createElement('span');
      nameSpan.className = 'view-layer-name';
      nameSpan.textContent = layer.name;
      header.appendChild(nameSpan);

      // Object count badge
      var badge = document.createElement('span');
      badge.className = 'badge text-bg-secondary me-1';
      badge.style.fontSize = '0.7rem';
      badge.textContent = objsOnLayer.length;
      header.appendChild(badge);

      // Visibility toggle
      var eyeBtn = document.createElement('button');
      eyeBtn.className = 'view-layer-btn';
      eyeBtn.title = layer.visible ? 'Hide layer' : 'Show layer';
      eyeBtn.innerHTML = layer.visible
        ? '<i class="mdi mdi-eye"></i>'
        : '<i class="mdi mdi-eye-off"></i>';
      eyeBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        layer.visible = !layer.visible;
        U.apply_layer_visibility(canvas, _viewLayers);
        _renderViewLayerPanel();
      });
      header.appendChild(eyeBtn);

      group.appendChild(header);

      // --- Expanded object list ---
      if (isExpanded && objsOnLayer.length > 0) {
        var listDiv = document.createElement('div');
        listDiv.className = 'view-layer-objects';

        objsOnLayer.forEach(function (entry) {
          var info = U.obj_display_name(entry.obj);
          var row = document.createElement('div');
          row.className = 'view-obj-row';
          row.title = info.type + (info.name ? ': ' + info.name : '');

          var ico = document.createElement('i');
          ico.className = 'mdi ' + info.icon + ' view-obj-icon';
          row.appendChild(ico);

          var lbl = document.createElement('span');
          lbl.className = 'view-obj-label';
          lbl.textContent = info.name || info.type;
          row.appendChild(lbl);

          listDiv.appendChild(row);
        });

        group.appendChild(listDiv);
      } else if (isExpanded) {
        var emptyMsg = document.createElement('div');
        emptyMsg.className = 'view-layer-objects';
        emptyMsg.innerHTML = '<div class="text-muted small px-3 py-1">No objects</div>';
        group.appendChild(emptyMsg);
      }

      panel.appendChild(group);
    });
  }

  // ---------------------------------------------------------------------------
  // Highlight & zoom to a specific placed object
  // ---------------------------------------------------------------------------

  function _highlightObject(objectType, objectId) {
    var target = null;
    canvas.getObjects().forEach(function (obj) {
      var meta = obj.custom_meta;
      if (meta &&
          meta.object_type === objectType &&
          String(meta.object_id) === String(objectId)) {
        target = obj;
      }
    });

    if (!target) return;

    // 1. Pan & zoom so the object fills roughly 40 % of the viewport.
    var wrapper = document.getElementById('canvas-wrapper');
    var viewW   = wrapper ? wrapper.clientWidth  : canvas.getWidth();
    var viewH   = wrapper ? wrapper.clientHeight : canvas.getHeight();

    var objW    = (target.width  || 60) * (target.scaleX || 1);
    var objH    = (target.height || 60) * (target.scaleY || 1);
    var zoom    = Math.min(viewW / objW, viewH / objH) * 0.40;
    zoom        = Math.min(Math.max(zoom, 0.1), 4);

    // getCenterPoint() returns the true canvas-coordinate centre regardless of
    // the object's rotation, unlike a manual left+width/2 calculation which
    // breaks when the object has been rotated.
    var centerPt = target.getCenterPoint();
    var cx       = centerPt.x;
    var cy       = centerPt.y;
    var panX    = viewW / 2 - cx * zoom;
    var panY    = viewH / 2 - cy * zoom;

    canvas.setViewportTransform([zoom, 0, 0, zoom, panX, panY]);

    // 2. Draw a pulsing highlight ring around the object.
    var padding = 12;
    var ring = new fabric.Rect({
      left:          cx,
      top:           cy,
      width:         objW + padding * 2,
      height:        objH + padding * 2,
      originX:       'center',
      originY:       'center',
      fill:          'transparent',
      stroke:        '#f59e0b',
      strokeWidth:   4,
      rx:            6,
      ry:            6,
      selectable:    false,
      evented:       false,
      opacity:       1,
      angle:         target.angle || 0,
    });
    canvas.add(ring);
    canvas.renderAll();

    // 3. Pulse the ring opacity 3 times then leave it visible.
    var pulses    = 0;
    var maxPulses = 6;  // 3 full on/off cycles

    function _doPulse() {
      if (pulses >= maxPulses) {
        ring.opacity = 0.85;
        canvas.requestRenderAll();
        return;
      }
      var targetOpacity = (pulses % 2 === 0) ? 0.1 : 1;
      var startOpacity  = ring.opacity;
      fabric.util.animate({
        startValue: startOpacity,
        endValue:   targetOpacity,
        duration:   350,
        onChange: function (v) {
          ring.opacity = v;
          canvas.requestRenderAll();
        },
        onComplete: function () {
          pulses++;
          _doPulse();
        },
      });
    }
    _doPulse();
  }

})();
