/**
 * netbox_dwg — Fabric.js canvas utility functions.
 *
 * Shared between the editor (edit.js) and the read-only viewer (view.js).
 * Exposes helpers on the global window.NetBoxDWG namespace.
 */

(function (global) {
  'use strict';

  var ns = (global.NetBoxDWG = global.NetBoxDWG || {});

  // Track whether a background image controls the canvas size
  ns._hasBackgroundImage = false;

  // Logical canvas dimensions (from background image or manual)
  // These define the coordinate space even when the canvas element is smaller.
  ns._logicalWidth = 0;
  ns._logicalHeight = 0;

  // ---------------------------------------------------------------------------
  // Canvas sizing
  // ---------------------------------------------------------------------------

  /**
   * Fit canvas to the available container width.
   * Only applies when there is NO background image (which dictates size).
   */
  ns.resize_canvas = function (canvas, windowRef) {
    var wrapper = document.getElementById('canvas-wrapper');
    if (!wrapper) return;
    var w = wrapper.clientWidth;
    var h = Math.max(windowRef.innerHeight - 250, 500);
    canvas.setWidth(w);
    canvas.setHeight(h);
    if (ns._hasBackgroundImage) {
      ns.fit_to_view(canvas);
    } else {
      canvas.renderAll();
    }
  };

  // ---------------------------------------------------------------------------
  // Zoom (scroll-wheel)
  // ---------------------------------------------------------------------------

  /**
   * Attach a NON-PASSIVE native wheel listener to the canvas wrapper so that
   * e.preventDefault() is honoured by modern browsers (passive is the default
   * since Chrome 51 / Firefox 49, which silently ignores preventDefault() and
   * lets the page / overflow container scroll instead of zooming the canvas).
   *
   * Call this once after creating the Fabric canvas instead of using the Fabric
   * 'mouse:wheel' event.
   */
  ns.setup_zoom = function (canvas) {
    // Attach a non-passive wheel listener to #canvas-wrapper so that
    // e.preventDefault() is always honoured (passive:false must be declared at
    // registration time — it cannot be overridden from inside a passive handler).
    //
    // We use { passive: false } on the wrapper rather than upperCanvas because:
    //  a) the wrapper is always available and under our control;
    //  b) wheel events bubble up from the canvas elements to the wrapper;
    //  c) offsetX/offsetY on a canvas elem can be unreliable in some browsers
    //     — e.clientX minus getBoundingClientRect gives consistent results.
    //
    // NOTE: call this function AFTER the DOM is ready (inside DOMContentLoaded)
    // so that #canvas-wrapper is guaranteed to exist.
    var attachFn = function () {
      var wrapper = document.getElementById('canvas-wrapper');
      if (!wrapper) return;

      wrapper.addEventListener('wheel', function (e) {
        e.preventDefault();
        e.stopPropagation();

        // Resolve the interactive canvas element for accurate hit coordinates.
        var canvasEl = canvas.upperCanvas ||
                       wrapper.querySelector('canvas.upper-canvas') ||
                       wrapper.querySelector('canvas');
        var rect  = canvasEl
          ? canvasEl.getBoundingClientRect()
          : wrapper.getBoundingClientRect();

        var x = e.clientX - rect.left;
        var y = e.clientY - rect.top;

        var delta = e.deltaY;
        var zoom  = canvas.getZoom();
        zoom *= Math.pow(0.999, delta);
        zoom  = Math.min(Math.max(zoom, 0.05), 30);

        canvas.zoomToPoint({ x: x, y: y }, zoom);
        canvas.requestRenderAll();
      }, { passive: false });
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', attachFn);
    } else {
      attachFn();
    }
  };

  ns.reset_zoom = function (canvas) {
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    canvas.renderAll();
  };

  /**
   * Zoom and pan the viewport so the entire canvas content fits inside
   * the visible wrapper area, centered.
   */
  ns.fit_to_view = function (canvas) {
    var wrapper = document.getElementById('canvas-wrapper');
    if (!wrapper) return;
    var viewW = wrapper.clientWidth;
    var viewH = Math.max(window.innerHeight - 250, 500);

    // Use stored logical dimensions (from background image) when available,
    // otherwise fall back to the canvas element size.
    var contentW = ns._logicalWidth || canvas.getWidth();
    var contentH = ns._logicalHeight || canvas.getHeight();
    if (!contentW || !contentH) return;

    // Scale to fit with some padding
    var zoom = Math.min(viewW / contentW, viewH / contentH) * 0.95;
    zoom = Math.min(zoom, 1); // never zoom in past 1:1

    // Center offset
    var panX = (viewW - contentW * zoom) / 2;
    var panY = (viewH - contentH * zoom) / 2;

    canvas.setViewportTransform([zoom, 0, 0, zoom, panX, panY]);
    canvas.renderAll();
  };

  // ---------------------------------------------------------------------------
  // Pan (Alt + drag)
  // ---------------------------------------------------------------------------

  ns.start_pan = function (opt, canvas) {
    if (opt.e.altKey) {
      canvas.isDragging = true;
      canvas.selection = false;
      canvas.lastPosX = opt.e.clientX;
      canvas.lastPosY = opt.e.clientY;
    }
  };

  ns.move_pan = function (opt, canvas) {
    if (canvas.isDragging) {
      var vpt = canvas.viewportTransform;
      vpt[4] += opt.e.clientX - canvas.lastPosX;
      vpt[5] += opt.e.clientY - canvas.lastPosY;
      canvas.requestRenderAll();
      canvas.lastPosX = opt.e.clientX;
      canvas.lastPosY = opt.e.clientY;
    }
  };

  ns.stop_pan = function (canvas) {
    if (!canvas.isDragging) return;
    canvas.setViewportTransform(canvas.viewportTransform);
    canvas.isDragging = false;
    canvas.selection = true;
  };

  // ---------------------------------------------------------------------------
  // SVG export
  // ---------------------------------------------------------------------------

  ns.export_svg = function (canvas) {
    // Save current viewport state
    var savedVpt = canvas.viewportTransform.slice();
    var savedW   = canvas.getWidth();
    var savedH   = canvas.getHeight();

    // Export at 1:1 using the full logical (image) dimensions so the
    // background image and all objects are included at their true size.
    var logW = ns._logicalWidth  || savedW;
    var logH = ns._logicalHeight || savedH;

    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    canvas.setWidth(logW);
    canvas.setHeight(logH);
    canvas.renderAll();

    var svg = canvas.toSVG();

    // Restore viewport
    canvas.setWidth(savedW);
    canvas.setHeight(savedH);
    canvas.setViewportTransform(savedVpt);
    canvas.renderAll();

    var blob = new Blob([svg], { type: 'image/svg+xml' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'floor_diagram.svg';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ---------------------------------------------------------------------------
  // Image format support
  // ---------------------------------------------------------------------------

  var _imgExts = ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.bmp'];

  function _isRenderable(url) {
    if (!url) return false;
    var lower = url.split('?')[0].toLowerCase();
    return _imgExts.some(function (ext) { return lower.endsWith(ext); });
  }

  // ---------------------------------------------------------------------------
  // Background image
  // ---------------------------------------------------------------------------

  /**
   * Load a background image onto the canvas at 1:1 scale.
   * Returns a Promise that resolves when done (or immediately if unsupported).
   */
  ns.set_background = function (canvas, url) {
    if (!_isRenderable(url)) {
      console.warn('netbox_dwg: Unsupported background format:', url);
      return Promise.resolve();
    }
    return fabric.Image.fromURL(url, { crossOrigin: 'anonymous' }).then(function (img) {
      // Store logical dimensions (image pixel size) for coordinate-space.
      // The canvas element stays sized to the wrapper; the viewport transform
      // zooms/pans so the full image is visible.
      ns._logicalWidth = img.width;
      ns._logicalHeight = img.height;

      var wrapper = document.getElementById('canvas-wrapper');
      if (wrapper) {
        var viewW = wrapper.clientWidth;
        var viewH = Math.max(window.innerHeight - 250, 500);
        canvas.setWidth(viewW);
        canvas.setHeight(viewH);
      }

      img.scaleX = 1;
      img.scaleY = 1;
      canvas.backgroundImage = img;
      ns._hasBackgroundImage = true;
      // Fit the whole image into the visible area, centered
      ns.fit_to_view(canvas);
    }).catch(function (err) {
      console.error('netbox_dwg: Error loading background image:', err);
    });
  };

  // ---------------------------------------------------------------------------
  // Load floor canvas from the API
  // ---------------------------------------------------------------------------

  /**
   * Initialise a floor:
   *  1. Fetch the floor data from the REST API
   *  2. If a background image is assigned, load it first (sets canvas size)
   *  3. Then load the saved canvas JSON objects on top
   *  4. Fall back to manual dimensions or default window-fit
   */
  ns.init_floor = function (floor_id, canvas, mode, onLoad) {
    if (!floor_id) return;

    var apiUrl = '/api/plugins/dwg/floors/?id=' + floor_id;
    $.get(apiUrl).done(function (data) {
      data.results.forEach(function (floor) {
        var imgData = floor.assigned_image;
        var imgUrl = '';

        if (imgData) {
          if (imgData.external_url) {
            imgUrl = imgData.external_url;
          } else if (imgData.file) {
            imgUrl = imgData.file;
          }
        }

        // Step 1: load background image (if any), THEN load canvas objects
        var bgPromise;
        if (imgUrl && _isRenderable(imgUrl)) {
          bgPromise = ns.set_background(canvas, imgUrl);
        } else {
          bgPromise = Promise.resolve();
          // No image — apply manual dimensions or window-fit
          _applyDimensions(canvas, floor);
        }

        bgPromise.then(function () {
          // Step 2: load saved canvas objects on top of the background.
          // Fabric.js 6.x: loadFromJSON(json, reviver?) returns a Promise.
          // The old 3-argument form (json, callback, reviver) is NOT supported —
          // using it caused renderAll to be called per-object (the reviver slot)
          // and the readonly reviver was silently dropped.
          if (floor.canvas && Object.keys(floor.canvas).length > 0) {
            // Build an index of custom_meta from the raw saved data BEFORE
            // Fabric deserialises it.  This is our reliable fallback — if the
            // reviver call order differs between Fabric versions the post-load
            // pass below will still restore the property correctly.
            var rawObjects = (floor.canvas.objects || []);
            var customMetaByIndex = {};
            rawObjects.forEach(function (rawObj, idx) {
              if (rawObj && rawObj.custom_meta) {
                customMetaByIndex[idx] = rawObj.custom_meta;
              }
            });

            // Reviver: Fabric 6 calls reviver(serialisedJSON, fabricObject).
            var reviver = function (rawJSON, obj) {
              // Primary path — copy custom_meta via the reviver arguments.
              if (rawJSON && rawJSON.custom_meta) {
                obj.custom_meta = rawJSON.custom_meta;
              }
              if (mode === 'readonly') {
                obj.set({ selectable: false, evented: false });
              }
            };

            canvas.loadFromJSON(JSON.stringify(floor.canvas), reviver)
              .then(function () {
                // Fallback pass: any object that still lacks custom_meta gets
                // it from the index built above (handles edge cases where the
                // reviver argument order or timing differs).
                canvas.getObjects().forEach(function (obj, idx) {
                  if (!obj.custom_meta && customMetaByIndex[idx]) {
                    obj.custom_meta = customMetaByIndex[idx];
                  }
                });
                canvas.renderAll();
                if (typeof onLoad === 'function') onLoad(floor.canvas);
              })
              .catch(function (err) {
                console.error('netbox_dwg: loadFromJSON error', err);
                if (typeof onLoad === 'function') onLoad(floor.canvas);
              });
          } else {
            if (typeof onLoad === 'function') onLoad(floor.canvas);
          }
        });
      });
    });
  };

  /**
   * Apply manual width/height dimensions (only when no background image).
   */
  function _applyDimensions(canvas, floor) {
    if (floor.width && floor.height) {
      var scale = 100; // px per unit
      var unit = floor.measurement_unit;
      var w, h;
      if (unit === 'ft') {
        w = (floor.width / 3.28) * scale;
        h = (floor.height / 3.28) * scale;
      } else {
        w = floor.width * scale;
        h = floor.height * scale;
      }
      canvas.setWidth(Math.max(w, canvas.getWidth()));
      canvas.setHeight(Math.max(h, canvas.getHeight()));
    }
  }

  // ---------------------------------------------------------------------------
  // Layer helpers (shared between edit.js and view.js)
  // ---------------------------------------------------------------------------

  var DEFAULT_LAYER_ID = 'default';

  ns.DEFAULT_LAYER_ID = DEFAULT_LAYER_ID;

  /**
   * Return the layer ID for a Fabric object.  Falls back to 'default'.
   */
  ns.get_object_layer = function (obj) {
    return (obj.custom_meta && obj.custom_meta.layer) || DEFAULT_LAYER_ID;
  };

  /**
   * Extract the layers array from a canvas JSON object (or return a default).
   */
  ns.get_layers_from_json = function (canvasJSON) {
    if (canvasJSON && Array.isArray(canvasJSON._layers)) {
      return canvasJSON._layers;
    }
    return [{ id: DEFAULT_LAYER_ID, name: 'Default', visible: true }];
  };

  /**
   * Apply layer visibility to all objects on the canvas.
   * hiddenLayers is a Set (or array) of layer IDs that should be hidden.
   */
  ns.apply_layer_visibility = function (canvas, layers) {
    var hiddenSet = {};
    layers.forEach(function (l) {
      if (!l.visible) hiddenSet[l.id] = true;
    });
    canvas.getObjects().forEach(function (obj) {
      var lid = ns.get_object_layer(obj);
      obj.visible = !hiddenSet[lid];
      obj.evented = !hiddenSet[lid];
    });
    canvas.renderAll();
  };

  /**
   * Generate a short unique layer ID.
   */
  ns.new_layer_id = function () {
    return 'layer_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 4);
  };

  // ---------------------------------------------------------------------------
  // Object display helpers (shared between edit.js and view.js)
  // ---------------------------------------------------------------------------

  /** Icon + label mapping for object types. */
  ns.OBJ_TYPE_INFO = {
    rack:          { icon: 'mdi-server',           label: 'Rack' },
    device:        { icon: 'mdi-monitor',          label: 'Device' },
    location_zone: { icon: 'mdi-vector-rectangle', label: 'Location Zone' },
    zone:          { icon: 'mdi-vector-polygon',   label: 'Zone' },
    cable:         { icon: 'mdi-cable-data',       label: 'Cable' },
    label:         { icon: 'mdi-format-text',      label: 'Label' },
    line:          { icon: 'mdi-vector-line',       label: 'Line' },
    circle:        { icon: 'mdi-circle-outline',   label: 'Circle' },
  };

  /**
   * Return { icon, type, name } display info for a Fabric object.
   */
  ns.obj_display_name = function (obj) {
    var meta = obj.custom_meta || {};
    var info = ns.OBJ_TYPE_INFO[meta.object_type] || { icon: 'mdi-shape', label: 'Object' };
    var name = meta.object_name || '';
    if (!name && obj.type === 'textbox' && obj.text) {
      name = obj.text.length > 20 ? obj.text.substring(0, 20) + '\u2026' : obj.text;
    }
    return { icon: info.icon, type: info.label, name: name };
  };

  /**
   * Return array of {obj, index} for objects on a given layer.
   */
  ns.get_objects_on_layer = function (canvas, layerId) {
    var result = [];
    canvas.getObjects().forEach(function (obj, idx) {
      if (ns.get_object_layer(obj) === layerId) {
        result.push({ obj: obj, index: idx });
      }
    });
    return result;
  };

})(window);
