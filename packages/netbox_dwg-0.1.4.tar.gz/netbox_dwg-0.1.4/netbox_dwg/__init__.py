from netbox.plugins import PluginConfig
from .version import __version__


class NetBoxDWGConfig(PluginConfig):
    name = "netbox_dwg"
    verbose_name = "Diagrams"
    description = "NetBox plugin for site diagrams with DWG/SVG support, floor levels, rack placement, and location geometry"
    version = __version__
    base_url = "dwg"
    min_version = "4.0.0"


config = NetBoxDWGConfig
