from django.urls import include, path
from . import models, views
from netbox.views.generic import ObjectChangeLogView
from utilities.urls import get_model_urls

urlpatterns = (
    # Floors
    path("floors/", views.FloorListView.as_view(), name="floor_list"),
    path("floors/add/", views.FloorAddView.as_view(), name="floor_add"),
    path("floors/racks/", views.FloorRackListView.as_view(), name="floor_rack_list"),
    path("floors/devices/", views.FloorDeviceListView.as_view(), name="floor_device_list"),
    path("floors/<int:pk>/", views.FloorViewReadOnly.as_view(), name="floor"),
    path("floors/<int:pk>/edit/", views.FloorMapEditView.as_view(), name="floor_edit"),
    path("floors/<int:pk>/edit-form/", views.FloorEditFormView.as_view(), name="floor_edit_form"),
    path("floors/<int:pk>/delete/", views.FloorDeleteView.as_view(), name="floor_delete"),
    path(
        "floors/<int:pk>/changelog/",
        ObjectChangeLogView.as_view(),
        name="floor_changelog",
        kwargs={"model": models.Floor},
    ),
    # DiagramImages
    path(
        "diagramimages/",
        include(get_model_urls("netbox_dwg", "diagramimage", detail=False)),
    ),
    path(
        "diagramimages/<int:pk>/",
        include(get_model_urls("netbox_dwg", "diagramimage")),
    ),
)
