from netbox.plugins import PluginTemplateExtension
from django.urls import reverse
from django.utils.html import format_html
from .models import Floor


class SiteDiagramButton(PluginTemplateExtension):
    """Add a 'Diagrams' button to Site detail pages."""

    models = ("dcim.site",)

    def buttons(self):
        obj = self.context["object"]
        url = reverse("plugins:netbox_dwg:floor_list") + f"?site_id={obj.pk}"
        return format_html(
            '<a href="{}" class="btn btn-sm btn-primary" title="View Site Diagrams">'
            '<i class="mdi mdi-floor-plan"></i> View Diagrams'
            "</a>",
            url,
        )


class _ObjectLocationPanel(PluginTemplateExtension):
    """
    Shared base for Rack and Device: shows which floor the object is placed on
    and provides a direct "View on diagram" link that highlights it.
    """

    #: Override in subclasses — 'rack' or 'device'
    _object_type = ''

    def right_page(self):
        obj = self.context["object"]
        site = getattr(obj, 'site', None)
        floor = Floor.find_for_object(self._object_type, obj.pk, site=site)

        if floor is None:
            content = (
                '<div class="card mb-3">'
                '<h5 class="card-header"><i class="mdi mdi-floor-plan"></i> Floor Diagram</h5>'
                '<div class="card-body text-muted small">'
                'This {0} has not been placed on any floor diagram yet.'
                '</div></div>'
            ).format(self._object_type)
            return format_html(content)

        view_url = reverse('plugins:netbox_dwg:floor', kwargs={'pk': floor.pk})
        view_url += f'?highlight_type={self._object_type}&highlight_id={obj.pk}'

        return format_html(
            '<div class="card mb-3">'
            '<h5 class="card-header"><i class="mdi mdi-floor-plan"></i> Floor Diagram</h5>'
            '<div class="card-body">'
            '<table class="table table-sm"><tbody>'
            '<tr><th scope="row">Floor</th><td>{floor_name}</td></tr>'
            '<tr><th scope="row">Level</th><td>{level}</td></tr>'
            '<tr><th scope="row">Site</th><td>{site}</td></tr>'
            '</tbody></table>'
            '<a href="{url}" class="btn btn-sm btn-primary w-100">'
            '<i class="mdi mdi-crosshairs-gps"></i> View &amp; Highlight on Diagram'
            '</a>'
            '</div></div>',
            floor_name=floor.name,
            level=floor.level,
            site=floor.site.name,
            url=view_url,
        )


class RackLocationPanel(_ObjectLocationPanel):
    models = ("dcim.rack",)
    _object_type = 'rack'


class DeviceLocationPanel(_ObjectLocationPanel):
    models = ("dcim.device",)
    _object_type = 'device'


template_extensions = [SiteDiagramButton, RackLocationPanel, DeviceLocationPanel]
