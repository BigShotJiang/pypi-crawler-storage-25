import django_tables2 as tables
from netbox.tables import NetBoxTable
from .models import DiagramImage, Floor
from dcim.models import Rack, Device
from functools import cached_property


class DiagramImageTable(NetBoxTable):
    name = tables.Column(linkify=True)

    class Meta(NetBoxTable.Meta):
        model = DiagramImage
        fields = ("pk", "id", "name", "file")


class FloorTable(NetBoxTable):
    name = tables.Column(linkify=True)
    site = tables.Column(linkify=True)
    is_default = tables.BooleanColumn(verbose_name="Default")

    class Meta(NetBoxTable.Meta):
        model = Floor
        fields = ("pk", "site", "name", "level", "is_default", "assigned_image", "width", "height")
        default_columns = ("pk", "site", "name", "level", "is_default", "assigned_image")


class FloorRackTable(NetBoxTable):
    name = tables.LinkColumn()
    embedded = True

    role = tables.TemplateColumn(
        template_code="""
        {% if record.role %}
            {{ record.role.name }}
        {% else %}
            <span class="text-muted">None</span>
        {% endif %}
        """,
        verbose_name="Role",
    )

    actions = tables.TemplateColumn(
        template_code="""
    <div class="btn-group" role="group">
        {% if record.role and record.role.color %}
        <a type="button" class="btn btn-sm btn-outline-secondary"
           onclick="add_rack_to_canvas('{{ record.id }}', '{{ record.name }}', '{{ record.status }}', '#{{ record.role.color }}', {% if record.outer_width %}{{ record.outer_width }}{% else %}null{% endif %}, {% if record.outer_depth %}{{ record.outer_depth }}{% else %}null{% endif %}, {% if record.outer_unit %}'{{ record.outer_unit }}'{% else %}null{% endif %})">
            <span class="mdi mdi-plus-thick"></span> Add Rack
        </a>
        {% else %}
        <a type="button" class="btn btn-sm btn-outline-secondary"
           onclick="add_rack_to_canvas('{{ record.id }}', '{{ record.name }}', '{{ record.status }}', '#000000', {% if record.outer_width %}{{ record.outer_width }}{% else %}null{% endif %}, {% if record.outer_depth %}{{ record.outer_depth }}{% else %}null{% endif %}, {% if record.outer_unit %}'{{ record.outer_unit }}'{% else %}null{% endif %})">
            <span class="mdi mdi-plus-thick"></span> Add Rack
        </a>
        {% endif %}
    </div>
    """,
        orderable=False,
    )

    @cached_property
    def htmx_url(self):
        return "/plugins/dwg/floors/racks/"

    class Meta(NetBoxTable.Meta):
        model = Rack
        fields = ("pk", "name", "role", "actions")
        default_columns = ("pk", "name", "role", "actions")
        row_attrs = {
            "id": lambda record: "object_rack_{}".format(record.pk),
        }


class FloorDeviceTable(NetBoxTable):
    name = tables.LinkColumn()
    embedded = True

    role = tables.TemplateColumn(
        template_code="""
        {% if record.role %}
            {{ record.role.name }}
        {% else %}
            <span class="text-muted">None</span>
        {% endif %}
        """,
        verbose_name="Role",
    )

    actions = tables.TemplateColumn(
        template_code="""
    <div class="btn-group" role="group">
        <a type="button" class="btn btn-sm btn-outline-secondary"
           onclick="add_device_to_canvas('{{ record.id }}', '{{ record.name }}', '{{ record.status }}', '#{% if record.role and record.role.color %}{{ record.role.color }}{% else %}666666{% endif %}')">
            <span class="mdi mdi-plus-thick"></span> Add Device
        </a>
    </div>
    """,
        orderable=False,
    )

    @cached_property
    def htmx_url(self):
        return "/plugins/dwg/floors/devices/"

    class Meta(NetBoxTable.Meta):
        model = Device
        fields = ("pk", "name", "role", "actions")
        default_columns = ("pk", "name", "role", "actions")
        row_attrs = {
            "id": lambda record: "object_device_{}".format(record.pk),
        }
