# Generated migration for netbox_dwg

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("netbox_dwg", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="floor",
            name="is_default",
            field=models.BooleanField(
                default=False,
                help_text="If checked, this floor is shown by default when viewing the site's diagrams.",
            ),
        ),
    ]
