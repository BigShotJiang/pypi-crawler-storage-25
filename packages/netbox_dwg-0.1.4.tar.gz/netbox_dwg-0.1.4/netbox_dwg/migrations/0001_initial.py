# Generated migration for netbox_dwg

import django.db.models.deletion
from django.db import migrations, models
import netbox_dwg.utils
import taggit.managers
import utilities.json


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ("dcim", "0172_larger_power_draw_values"),
        ("extras", "0115_convert_dashboard_widgets"),
    ]

    operations = [
        migrations.CreateModel(
            name="DiagramImage",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                (
                    "created",
                    models.DateTimeField(auto_now_add=True, null=True),
                ),
                (
                    "last_updated",
                    models.DateTimeField(auto_now=True, null=True),
                ),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                ("name", models.CharField(max_length=256)),
                (
                    "file",
                    models.FileField(
                        blank=True, upload_to=netbox_dwg.utils.file_upload
                    ),
                ),
                (
                    "external_url",
                    models.URLField(blank=True, max_length=512),
                ),
                ("comments", models.TextField(blank=True)),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
            ],
            options={
                "ordering": ("name",),
            },
        ),
        migrations.CreateModel(
            name="Floor",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True, primary_key=True, serialize=False
                    ),
                ),
                (
                    "created",
                    models.DateTimeField(auto_now_add=True, null=True),
                ),
                (
                    "last_updated",
                    models.DateTimeField(auto_now=True, null=True),
                ),
                (
                    "custom_field_data",
                    models.JSONField(
                        blank=True,
                        default=dict,
                        encoder=utilities.json.CustomFieldJSONEncoder,
                    ),
                ),
                ("name", models.CharField(max_length=256)),
                ("level", models.IntegerField(default=0)),
                (
                    "width",
                    models.DecimalField(
                        blank=True, decimal_places=2, max_digits=10, null=True
                    ),
                ),
                (
                    "height",
                    models.DecimalField(
                        blank=True, decimal_places=2, max_digits=10, null=True
                    ),
                ),
                (
                    "measurement_unit",
                    models.CharField(
                        choices=[("m", "Meters"), ("ft", "Feet")],
                        default="m",
                        max_length=2,
                    ),
                ),
                ("canvas", models.JSONField(blank=True, default=dict)),
                ("comments", models.TextField(blank=True)),
                (
                    "site",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="dwg_floors",
                        to="dcim.site",
                    ),
                ),
                (
                    "assigned_image",
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        to="netbox_dwg.diagramimage",
                    ),
                ),
                (
                    "tags",
                    taggit.managers.TaggableManager(
                        through="extras.TaggedItem", to="extras.Tag"
                    ),
                ),
            ],
            options={
                "ordering": ("site", "level", "name"),
                "unique_together": {("site", "level")},
            },
        ),
    ]
