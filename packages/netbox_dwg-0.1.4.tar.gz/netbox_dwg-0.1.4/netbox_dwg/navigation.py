"""
Navigation sidebar entries for the plugin.
"""
from netbox.plugins import PluginMenu, PluginMenuItem, PluginMenuButton

_menu_items = (
    PluginMenuItem(
        link="plugins:netbox_dwg:floor_list",
        link_text="Floor Diagrams",
        buttons=(
            PluginMenuButton(
                link="plugins:netbox_dwg:floor_add",
                title="Add Floor",
                icon_class="mdi mdi-plus-thick",
            ),
        ),
    ),
    PluginMenuItem(
        link="plugins:netbox_dwg:diagramimage_list",
        link_text="Diagram Images",
        buttons=(
            PluginMenuButton(
                link="plugins:netbox_dwg:diagramimage_add",
                title="Add Image",
                icon_class="mdi mdi-plus-thick",
            ),
        ),
    ),
)

menu = PluginMenu(
    label="Diagrams",
    groups=(
        ("Diagrams", _menu_items),
    ),
    icon_class="mdi mdi-floor-plan",
)
