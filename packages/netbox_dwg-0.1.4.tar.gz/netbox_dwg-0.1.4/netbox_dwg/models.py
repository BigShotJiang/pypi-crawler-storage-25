from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from django.db import models
from django.urls import reverse
from netbox.models import NetBoxModel
from .utils import file_upload

_ALLOWED_IMAGE_EXTENSIONS = ['svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp']


class DiagramImage(NetBoxModel):
    """
    A reusable background image (DWG, SVG, PNG, etc.) that can be
    assigned to one or more Floor diagrams.
    """

    name = models.CharField(
        max_length=256,
        help_text="A descriptive name for this diagram image.",
    )

    file = models.FileField(
        upload_to=file_upload,
        blank=True,
        help_text="Upload a .svg, .png, .jpg, .jpeg, .gif, .webp, or .bmp file.",
        validators=[FileExtensionValidator(allowed_extensions=_ALLOWED_IMAGE_EXTENSIONS)],
    )

    external_url = models.URLField(
        blank=True,
        max_length=512,
        help_text="Alternatively, provide an external URL for the diagram.",
    )

    comments = models.TextField(blank=True)

    class Meta:
        ordering = ("name",)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("plugins:netbox_dwg:diagramimage", args=[self.pk])

    @property
    def filename(self):
        if self.file:
            return self.file.name.rsplit("/", 1)[-1]
        return ""

    @property
    def size(self):
        if self.file:
            try:
                return self.file.size
            except Exception:
                return 0
        return 0

    def clean(self):
        super().clean()
        if not self.file and not self.external_url:
            raise ValidationError(
                "A diagram image must have either an uploaded file or an external URL."
            )
        if self.file and self.external_url:
            raise ValidationError(
                "A diagram image cannot have both an uploaded file and an external URL."
            )

    def delete(self, *args, **kwargs):
        if self.file:
            _name = self.file.name
            super().delete(*args, **kwargs)
            self.file.delete(save=False)
            self.file.name = _name
        else:
            super().delete(*args, **kwargs)


class Floor(NetBoxModel):
    """
    A floor / level within a site. Each floor has its own canvas
    (fabric.js JSON) where racks, devices, locations, and custom geometry
    are drawn on top of an optional background diagram.
    """

    site = models.ForeignKey(
        to="dcim.Site",
        on_delete=models.CASCADE,
        related_name="dwg_floors",
    )

    name = models.CharField(
        max_length=256,
        help_text='Human-readable name, e.g. "Ground Floor", "Level 2".',
    )

    level = models.IntegerField(
        default=0,
        help_text="Numeric floor level (-1 for basement, 0 for ground, 1+ for upper).",
    )

    assigned_image = models.ForeignKey(
        to="DiagramImage",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        help_text="Background diagram image for this floor.",
    )

    width = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text="Canvas width in the chosen measurement unit.",
    )

    height = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        blank=True,
        null=True,
        help_text="Canvas height in the chosen measurement unit.",
    )

    MEASUREMENT_CHOICES = [
        ("m", "Meters"),
        ("ft", "Feet"),
    ]
    measurement_unit = models.CharField(
        max_length=2,
        choices=MEASUREMENT_CHOICES,
        default="m",
    )

    is_default = models.BooleanField(
        default=False,
        help_text="If checked, this floor is shown by default when viewing the site's diagrams.",
    )

    canvas = models.JSONField(
        default=dict,
        blank=True,
        help_text="Fabric.js canvas state (auto-managed by the editor).",
    )

    comments = models.TextField(blank=True)

    class Meta:
        ordering = ("site", "level", "name")
        unique_together = (("site", "level"),)

    def __str__(self):
        default_tag = " ★" if self.is_default else ""
        return f"{self.site.name} — {self.name} (Level {self.level}){default_tag}"

    def save(self, *args, **kwargs):
        # Ensure only one default floor per site
        if self.is_default:
            Floor.objects.filter(site=self.site, is_default=True).exclude(
                pk=self.pk
            ).update(is_default=False)
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("plugins:netbox_dwg:floor_edit", args=[self.pk])

    @property
    def mapped_racks(self):
        """Return IDs of racks already placed on the canvas."""
        return self._mapped_ids_for("rack")

    @property
    def mapped_devices(self):
        """Return IDs of devices already placed on the canvas."""
        return self._mapped_ids_for("device")

    def _mapped_ids_for(self, object_type):
        """Return IDs of a given object_type already placed on the canvas."""
        import json as _json
        canvas = self.canvas
        # Guard: canvas may have been stored as a raw JSON string if an older
        # version of the frontend sent a double-encoded value.
        if isinstance(canvas, str):
            try:
                canvas = _json.loads(canvas)
            except (ValueError, TypeError):
                return []
        ids = []
        if isinstance(canvas, dict):
            for obj in canvas.get("objects", []):
                meta = obj.get("custom_meta", {})
                if meta.get("object_type") == object_type:
                    try:
                        ids.append(int(meta["object_id"]))
                    except (KeyError, ValueError, TypeError):
                        pass
        return ids

    @classmethod
    def find_for_object(cls, object_type, object_id, site=None):
        """
        Return the Floor whose canvas contains a placed object of the given
        type and ID, or None if it hasn't been placed yet.

        Scoped to ``site`` when provided (much faster for large installs).
        """
        qs = cls.objects.all() if site is None else cls.objects.filter(site=site)
        for floor in qs:
            if int(object_id) in floor._mapped_ids_for(object_type):
                return floor
        return None

    def resync_canvas(self):
        """
        Walk the canvas JSON objects and update names / statuses from
        the current NetBox database state. Removes stale references.
        """
        from dcim.models import Rack, Device

        if not isinstance(self.canvas, dict):
            return

        objects = self.canvas.get("objects", [])
        updated_objects = []
        changed = False

        for obj in objects:
            meta = obj.get("custom_meta", {})
            obj_type = meta.get("object_type")
            obj_id = meta.get("object_id")

            if obj_type == "rack" and obj_id:
                try:
                    rack = Rack.objects.get(pk=int(obj_id))
                    if meta.get("object_name") != rack.name:
                        meta["object_name"] = rack.name
                        changed = True
                except Rack.DoesNotExist:
                    changed = True
                    continue  # drop stale rack from canvas

            elif obj_type == "device" and obj_id:
                try:
                    device = Device.objects.get(pk=int(obj_id))
                    if meta.get("object_name") != device.name:
                        meta["object_name"] = device.name
                        changed = True
                except Device.DoesNotExist:
                    changed = True
                    continue  # drop stale device from canvas

            updated_objects.append(obj)

        if changed:
            self.canvas["objects"] = updated_objects
            self.save(update_fields=["canvas"])
