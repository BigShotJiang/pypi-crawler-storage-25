from rest_framework import serializers
from netbox.api.serializers import NetBoxModelSerializer
from ..models import DiagramImage, Floor


class DiagramImageSerializer(NetBoxModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name="plugins-api:netbox_dwg-api:diagramimage-detail"
    )

    class Meta:
        model = DiagramImage
        fields = [
            "id",
            "url",
            "name",
            "file",
            "external_url",
            "filename",
            "comments",
            "tags",
            "custom_fields",
            "created",
            "last_updated",
        ]
        brief_fields = ["id", "url", "name", "file", "filename", "external_url"]


class FloorSerializer(NetBoxModelSerializer):
    url = serializers.HyperlinkedIdentityField(
        view_name="plugins-api:netbox_dwg-api:floor-detail"
    )
    assigned_image = DiagramImageSerializer(nested=True, required=False, allow_null=True)

    class Meta:
        model = Floor
        fields = [
            "id",
            "url",
            "site",
            "name",
            "level",
            "is_default",
            "assigned_image",
            "width",
            "height",
            "measurement_unit",
            "canvas",
            "comments",
            "tags",
            "custom_fields",
            "created",
            "last_updated",
        ]
