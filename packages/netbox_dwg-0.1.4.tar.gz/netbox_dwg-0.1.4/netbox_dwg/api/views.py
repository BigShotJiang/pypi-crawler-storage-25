from netbox.api.viewsets import NetBoxModelViewSet
from .. import filtersets, models
from .serializers import FloorSerializer, DiagramImageSerializer


class FloorViewSet(NetBoxModelViewSet):
    queryset = models.Floor.objects.all()
    serializer_class = FloorSerializer
    filterset_class = filtersets.FloorFilterSet


class DiagramImageViewSet(NetBoxModelViewSet):
    queryset = models.DiagramImage.objects.prefetch_related("tags")
    serializer_class = DiagramImageSerializer
    filterset_class = filtersets.DiagramImageFilterSet
