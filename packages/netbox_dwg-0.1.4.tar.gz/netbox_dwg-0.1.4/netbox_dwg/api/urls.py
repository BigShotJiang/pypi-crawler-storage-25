from netbox.api.routers import NetBoxRouter
from . import views

app_name = "netbox_dwg"

router = NetBoxRouter()
router.register("floors", views.FloorViewSet)
router.register("diagramimages", views.DiagramImageViewSet)
urlpatterns = router.urls
