import os
import uuid


def file_upload(instance, filename):
    """
    Generate a unique file path for uploaded diagram files.
    Files are stored under netbox_dwg/<uuid>_<filename>.
    """
    ext = os.path.splitext(filename)[1]
    unique_name = f"{uuid.uuid4().hex}{ext}"
    return os.path.join("netbox_dwg", unique_name)
