from netbox.views import generic
from . import forms, models, tables
from dcim.models import Site, Rack, Location, Device
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views import View
from django.shortcuts import render, redirect
from django.db.models import Q
from utilities.views import ViewTab, register_model_view


# ---------------------------------------------------------------------------
# Site tab – shows list of floors for this site
# ---------------------------------------------------------------------------

@register_model_view(Site, name="dwg-floors")
class SiteFloorTabView(generic.ObjectView):
    queryset = Site.objects.all()
    tab = ViewTab(
        label="Diagrams",
        hide_if_empty=False,
        permission="netbox_dwg.view_floor",
    )
    template_name = "netbox_dwg/site_floors.html"

    def get_extra_context(self, request, instance):
        floors = models.Floor.objects.filter(site=instance).order_by("level")
        return {"floors": floors}


# ---------------------------------------------------------------------------
# Floor CRUD
# ---------------------------------------------------------------------------

class FloorListView(generic.ObjectListView):
    queryset = models.Floor.objects.all()
    table = tables.FloorTable


class FloorAddView(generic.ObjectEditView):
    queryset = models.Floor.objects.all()
    form = forms.FloorForm
    template_name = "netbox_dwg/floor_form.html"


class FloorEditFormView(generic.ObjectEditView):
    """Standard form-based edit (for name, level, image, etc.)."""
    queryset = models.Floor.objects.all()
    form = forms.FloorForm
    template_name = "netbox_dwg/floor_form.html"


class FloorDeleteView(generic.ObjectDeleteView):
    queryset = models.Floor.objects.all()


class FloorMapEditView(LoginRequiredMixin, View):
    """Interactive canvas editor for a floor."""
    permission_required = "netbox_dwg.change_floor"

    def get(self, request, pk):
        floor = models.Floor.objects.get(pk=pk)
        floor.resync_canvas()
        site = Site.objects.get(id=floor.site_id)
        floor_form = forms.FloorForm

        # Collect placed rack/device IDs from ALL floors of this site so that
        # the editor sidebar hides objects already assigned to another floor.
        all_placed_rack_ids = []
        all_placed_device_ids = []
        for f in models.Floor.objects.filter(site=site):
            all_placed_rack_ids.extend(f.mapped_racks)
            all_placed_device_ids.extend(f.mapped_devices)

        # Build sidebar data directly from the database — no client-side API calls.
        racks = (
            Rack.objects.filter(site=site)
            .select_related("role")
            .order_by("name")
        )
        devices = (
            Device.objects.filter(site=site, rack__isnull=True)
            .select_related("role")
            .order_by("name")
        )

        racks_data = [
            {
                "id": r.id,
                "name": r.name,
                "role_color": r.role.color if r.role else "000000",
                "role_name": r.role.name if r.role else "",
                "status": r.status or "",
                "outer_width": float(r.outer_width) if r.outer_width else None,
                "outer_depth": float(r.outer_depth) if r.outer_depth else None,
                "outer_unit": r.outer_unit or "",
            }
            for r in racks
        ]

        devices_data = [
            {
                "id": d.id,
                "name": d.name,
                "role_color": d.role.color if d.role else "666666",
                "role_name": d.role.name if d.role else "",
                "status": d.status or "",
            }
            for d in devices
        ]

        return render(
            request,
            "netbox_dwg/floor_edit.html",
            {
                "form2": floor_form,
                "site": site,
                "obj": floor,
                "all_placed_rack_ids": all_placed_rack_ids,
                "all_placed_device_ids": all_placed_device_ids,
                "racks_data": racks_data,
                "devices_data": devices_data,
            },
        )


class FloorViewReadOnly(LoginRequiredMixin, View):
    """Read-only canvas view for a floor."""

    def get(self, request, pk):
        floor = models.Floor.objects.get(pk=pk)
        floor.resync_canvas()
        site = Site.objects.get(id=floor.site_id)
        return render(
            request,
            "netbox_dwg/floor_view.html",
            {
                "obj": floor,
                "site": site,
                "highlight_type": request.GET.get("highlight_type", ""),
                "highlight_id":   request.GET.get("highlight_id", ""),
            },
        )


# ---------------------------------------------------------------------------
# Rack sidebar (HTMX-loaded list of racks for the site)
# ---------------------------------------------------------------------------

class FloorRackListView(generic.ObjectListView):
    queryset = Rack.objects.all()
    table = tables.FloorRackTable

    def get(self, request):
        floor_id = request.GET.get("floor_id")
        if floor_id:
            fp = models.Floor.objects.get(pk=floor_id)
            self.queryset = (
                Rack.objects.filter(site=fp.site)
                .filter(~Q(id__in=fp.mapped_racks))
                .order_by("name")
            )
        return super().get(request)


# ---------------------------------------------------------------------------
# Device sidebar (HTMX-loaded list of devices for the site)
# ---------------------------------------------------------------------------

class FloorDeviceListView(generic.ObjectListView):
    queryset = Device.objects.all()
    table = tables.FloorDeviceTable

    def get(self, request):
        floor_id = request.GET.get("floor_id")
        if floor_id:
            fp = models.Floor.objects.get(pk=floor_id)
            self.queryset = (
                Device.objects.filter(site=fp.site)
                .filter(rack__isnull=True)
                .filter(~Q(id__in=fp.mapped_devices))
                .order_by("name")
            )
        return super().get(request)


# ---------------------------------------------------------------------------
# DiagramImage CRUD
# ---------------------------------------------------------------------------

@register_model_view(models.DiagramImage)
class DiagramImageView(generic.ObjectView):
    queryset = models.DiagramImage.objects.all()


@register_model_view(models.DiagramImage, "list", path="", detail=False)
class DiagramImageListView(generic.ObjectListView):
    queryset = models.DiagramImage.objects.all()
    table = tables.DiagramImageTable


@register_model_view(models.DiagramImage, "add", detail=False)
@register_model_view(models.DiagramImage, "edit")
class DiagramImageEditView(generic.ObjectEditView):
    queryset = models.DiagramImage.objects.all()
    form = forms.DiagramImageForm
    template_name = "netbox_dwg/diagramimage_edit.html"


@register_model_view(models.DiagramImage, "delete")
class DiagramImageDeleteView(generic.ObjectDeleteView):
    queryset = models.DiagramImage.objects.all()
