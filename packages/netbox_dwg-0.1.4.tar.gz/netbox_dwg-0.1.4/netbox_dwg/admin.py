from django.contrib import admin
from .models import Floor, DiagramImage


@admin.register(Floor)
class FloorAdmin(admin.ModelAdmin):
    list_display = ("pk", "site", "name", "level")


@admin.register(DiagramImage)
class DiagramImageAdmin(admin.ModelAdmin):
    list_display = ("pk", "name")
