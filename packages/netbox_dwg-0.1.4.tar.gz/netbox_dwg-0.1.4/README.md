# netbox-dwg

A [NetBox](https://github.com/netbox-community/netbox) plugin that adds interactive floor-plan diagrams to your sites. Place racks and devices on a canvas backed by your own SVG/PNG floor plans, and keep the diagrams in sync with your NetBox inventory.

---

## Screenshots

![Floor plan editor](images/image_01.png)

![Floor plan viewer](images/image_02.png)

---

## Features

- **Floor levels per site** — define multiple named floors (basement, ground, level 1 …) with numeric ordering
- **Interactive canvas editor** — drag-and-drop racks and devices from the site inventory onto a [fabric.js](http://fabricjs.com/) canvas
- **Read-only viewer** — a clean view of each floor with optional rack/device highlighting (useful for linking from other NetBox objects)
- **Background images** — upload SVG, PNG, JPG, GIF, WebP, or BMP files, or point to an external image URL
- **Automatic canvas sync** — stale rack/device references are resolved (renamed) or removed (deleted) automatically every time a floor is opened
- **Diagrams tab** — a *Diagrams* tab is injected into the standard NetBox Site detail page listing all floors
- **Default floor** — mark one floor per site as the default so it opens first
- **Canvas dimensions** — set canvas width/height with selectable units (meters or feet)
- **REST API** — full CRUD endpoints for `Floor` and `DiagramImage` at `/api/plugins/dwg/`

---

## Requirements

| Requirement | Version |
|-------------|---------|
| Python | ≥ 3.10 |
| NetBox | ≥ 4.0.0 |

---

## Installation

### From PyPI (recommended)

```bash
pip install netbox-dwg
```

### From source

```bash
git clone https://github.com/ITW-Welding-AB/netbox-dwg.git
cd netbox-dwg
pip install .
```

### Enable the plugin

Add the plugin to your NetBox `configuration.py`:

```python
PLUGINS = [
    "netbox_dwg",
]

PLUGINS_CONFIG = {
    "netbox_dwg": {},
}
```

### Apply database migrations

```bash
cd /opt/netbox
python netbox/manage.py migrate
```

### Collect static files

```bash
python netbox/manage.py collectstatic --no-input
```

Restart NetBox and the NetBox worker after these steps.

---

## Usage

### Diagram images

Before creating floors you can pre-load background images:

1. Navigate to **Plugins → DWG → Diagram Images → Add**
2. Either upload a file or provide an external URL
3. Give it a name — images are reusable across multiple floors

### Floors

1. Open any **Site** in NetBox and click the **Diagrams** tab
2. Click **Add Floor** and fill in the name, level, optional background image, and canvas dimensions
3. Click **Edit** on a floor to open the interactive canvas editor
4. Use the *Racks* and *Devices* side panels to drag objects onto the canvas
5. Save the canvas — the layout persists as JSON in the database

### Reading the canvas

- Use the **View** button on a floor to open the read-only viewer
- Append `?highlight_type=rack&highlight_id=<id>` (or `device`) to the view URL to highlight a specific object — handy for custom links in NetBox templates

---

## REST API

The plugin registers endpoints under `/api/plugins/dwg/`:

| Endpoint | Methods | Description |
|----------|---------|-------------|
| `/api/plugins/dwg/floors/` | GET, POST | List / create floors |
| `/api/plugins/dwg/floors/<id>/` | GET, PUT, PATCH, DELETE | Retrieve / update / delete a floor |
| `/api/plugins/dwg/diagram-images/` | GET, POST | List / create diagram images |
| `/api/plugins/dwg/diagram-images/<id>/` | GET, PUT, PATCH, DELETE | Retrieve / update / delete an image |

---

## Development

A Docker Compose environment is included for local development.

### Prerequisites

- Docker and Docker Compose

### Start the dev environment

```bash
docker compose up -d --build
```

NetBox will be available at <http://localhost:8000>.  
Default credentials: `admin` / `admin` (created by the entrypoint).

The plugin source is volume-mounted into the container so changes to Python files (models, views, etc.) are picked up after a container restart, and changes to templates/static files are reflected immediately.

### Running migrations inside the container

```bash
docker compose exec netbox python netbox/manage.py migrate
```

---

## License

[MIT](LICENSE) © 2026 ITW Welding AB
