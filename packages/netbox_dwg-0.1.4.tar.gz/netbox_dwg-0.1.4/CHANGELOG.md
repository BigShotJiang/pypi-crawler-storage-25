# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.4] - 2026-03-28

### Added
- Interactive point-by-point cable drawing tool — click on the canvas to place vertices, with live preview polyline and rubber-band line following the cursor
- Cable drawing UI panel with stroke color picker, width, dotted/solid toggle, Finish, Undo Last Point, and Cancel buttons
- Double-click on canvas to finish a cable (alternative to the Finish button)
- Cable properties modal — double-click an existing cable to edit color, width, dotted style, and opacity
- Cable point-editing mode — edit individual vertices of an existing cable with draggable control points and midpoint insertion
- Layers system — named, reorderable, togglable-visibility layers in the floor editor (Photoshop-style sidebar panel)
- Layer panel in the floor viewer with expand/collapse and per-layer visibility toggles (shown only when multiple layers exist)
- New objects are automatically assigned to the currently active layer
- Shared layer and object-display helpers in `utils.js` (`DEFAULT_LAYER_ID`, `get_layers_from_json`, `apply_layer_visibility`, `new_layer_id`, `obj_display_name`, `get_objects_on_layer`)
- Double-click navigation in the floor viewer — double-click a rack or device to open its NetBox detail page

### Changed
- `mouse:move`, `mouse:down`, and `mouse:dblclick` canvas handlers now support both zone and cable drawing modes simultaneously
- `_attachMeta` now auto-assigns the active layer ID to new objects when no layer is already set
- Floor viewer canvas column changed from fixed `col-md-12` to flexible `col` to accommodate the layers sidebar

## [0.1.3] - 2026-03-27

### Added
- Interactive point-by-point zone drawing tool — click on the canvas to place vertices, with live preview polygon and rubber-band line following the cursor
- Zone drawing UI panel with fill/stroke color pickers, Finish, Undo Last Point, and Cancel buttons
- Double-click on canvas to finish a zone (alternative to the Finish button)
- Copy & Paste for drawing objects (zones, lines, location zones, circles, labels) via toolbar buttons and Ctrl+C / Ctrl+V keyboard shortcuts
- Racks and devices are excluded from copy to prevent accidental duplication of unique infrastructure items
- Escape key cancels zone drawing; Ctrl+Z undoes the last placed zone point

### Changed
- Replaced the static "Add Polygon" tool with the new interactive "Draw Zone" workflow
- Zone objects are now stored with `object_type: 'zone'` instead of `'polygon'`

## [0.1.2] - 2026-03-27

### Changed
- Renamed plugin from "NetBox DWG" to "Diagrams" (`verbose_name`, navigation menu label, and menu group)
- Rack and device sidebar data in the floor editor is now rendered server-side via `json_script` instead of client-side REST API calls
- Placed rack/device IDs are now collected across **all** floors of the site, so objects already assigned to another floor are hidden in the sidebar
- Device sidebar and device-list endpoint now filter to rackless devices only (`rack__isnull=True`)
- Removed `License :: OSI Approved :: MIT License` Trove classifier from `pyproject.toml` (redundant with PEP 639 `license` field)

### Fixed
- `license = { text = "MIT" }` replaced with SPDX expression `license = "MIT"` and `license-files = ["LICENSE"]` (PEP 639) to resolve `400 Bad Request` on PyPI upload
- Bumped build-system `setuptools` requirement to `>=77` (minimum version supporting PEP 639 license fields)
- Zoom-to-object in the floor viewer now uses `getCenterPoint()` for correct centering on rotated objects

### Added
- GitHub Actions workflow (`.github/workflows/publish-to-pypi.yaml`) that builds and publishes to PyPI on GitHub Release using OIDC trusted publishing — no API token required

## [0.1.1] - 2026-03-27

### Fixed
- `pyproject.toml` missing `[project]` table caused `python -m build` to fail with a validation error
- `setup.py` reduced to a minimal shim to avoid metadata duplication between `setup.py` and `pyproject.toml`

## [0.1.0] - 2026-03-27

### Added
- Initial release
- `Floor` model: associate one or more named floor levels per NetBox site, each with an interactive fabric.js canvas
- `DiagramImage` model: manage reusable background images (SVG, PNG, JPG, GIF, WebP, BMP) or external image URLs
- Interactive canvas editor per floor — drag-and-drop placement of racks and devices directly from the site inventory
- Read-only floor viewer with optional object highlighting (rack / device)
- "Diagrams" tab injected into the NetBox **Site** detail page listing all floors
- Automatic canvas re-sync: stale rack/device references are cleaned up whenever a floor is opened
- Support for canvas dimensions with selectable measurement units (meters / feet)
- Default floor flag per site (shown first when viewing diagrams)
- REST API: full CRUD for `Floor` and `DiagramImage` via `/api/plugins/dwg/`
- Filtering and table views for `Floor` and `DiagramImage`
- Docker Compose development environment bundled in repository
- `pyproject.toml` with full PEP 517 build system declaration and `[project]` metadata table
- `MANIFEST.in` to ensure templates, static files, and migrations are included in source distributions
- `.gitignore` covering Python artefacts, virtual environments, build outputs, and editor files
