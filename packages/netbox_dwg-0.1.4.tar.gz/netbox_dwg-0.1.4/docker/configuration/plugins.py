PLUGINS = ["netbox_dwg"]
PLUGINS_CONFIG = {
    "netbox_dwg": {},
}
