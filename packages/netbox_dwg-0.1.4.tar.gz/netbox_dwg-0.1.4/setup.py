# setup.py is kept as a minimal shim for editable installs (pip install -e .).
# All project metadata lives in pyproject.toml.
from setuptools import setup

setup()
