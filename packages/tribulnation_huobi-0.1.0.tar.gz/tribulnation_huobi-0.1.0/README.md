# Tribulnation Huobi SDK

> An SDK to connect Huobi with the Tribulnation ecosystem.

🚧 Under construction.