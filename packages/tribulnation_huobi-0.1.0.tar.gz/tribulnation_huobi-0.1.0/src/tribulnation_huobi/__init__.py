"""
### Tribulnation Huobi
> An SDK to connect Huobi with the Tribulnation ecosystem.

- Details
"""