## 1.7.1.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 1.7.1.20260508 (2026-05-08)

Import some items from typing instead of typing_extensions ([#15711](https://github.com/python/typeshed/pull/15711))

Part of #13782

## 1.7.1.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 1.7.1.20251001 (2025-10-01)

Remove @override annotations ([#14806](https://github.com/python/typeshed/pull/14806))

## 1.7.1.20250828 (2025-08-28)

Add type stub for PySocks ([#14623](https://github.com/python/typeshed/pull/14623))

