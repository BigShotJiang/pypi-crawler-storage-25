"""Packaged default data files for Kard-X."""
