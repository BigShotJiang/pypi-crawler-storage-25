"""Kard-X terminal card battler."""
