"""Settings scene."""
