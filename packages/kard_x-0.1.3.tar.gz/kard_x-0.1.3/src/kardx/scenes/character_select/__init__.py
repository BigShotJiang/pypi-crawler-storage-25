"""Character selection scene."""
