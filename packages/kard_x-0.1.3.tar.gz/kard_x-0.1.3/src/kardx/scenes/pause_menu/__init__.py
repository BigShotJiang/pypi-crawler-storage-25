"""Pause menu scene."""
