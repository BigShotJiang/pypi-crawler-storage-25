"""Adventure mode scene package."""
