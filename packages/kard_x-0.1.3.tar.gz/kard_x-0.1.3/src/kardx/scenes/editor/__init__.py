"""Content editor scenes."""
