from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

MAX_PAYLOAD_SIZE = 64 * 1024  # 64 KB
CHUNK_TYPE = "event_replay_chunk"


class EventType(str, Enum):
    # Server -> Client events
    RUN_ACCEPTED = "run_accepted"
    STAGE_START = "stage_start"
    STAGE_COMPLETE = "stage_complete"
    STAGE_RETRY = "stage_retry"
    STAGE_FAILED = "stage_failed"
    ARTIFACT_VALIDATED = "artifact_validated"
    ROUTING_DECISION = "routing_decision"
    PIPELINE_ABORT = "pipeline_abort"
    RUN_COMPLETE = "run_complete"
    EVENT_REPLAY = "event_replay"
    EVENT_REPLAY_CHUNK = "event_replay_chunk"
    STOP_STAGE_UPDATED = "stop_stage_updated"
    PONG = "pong"
    ERROR = "error"
    # Client -> Server events (echoed back or trigger actions)
    RUN = "run"
    SET_STOP_STAGE = "set_stop_stage"
    CANCEL = "cancel"
    RESUME = "resume"
    PING = "ping"


@dataclass(slots=True)
class ServerEvent:
    type: str
    task_id: str
    timestamp: str = field(default_factory=lambda: datetime.now(tz=timezone.utc).isoformat())
    # Optional fields for specific event types
    stage_name: str | None = None
    attempt: int | None = None
    success: bool | None = None
    max_retries: int | None = None
    error: str | None = None
    artifact_status: str | None = None
    next_stage: str | None = None
    decision_source: str | None = None
    reason: str | None = None
    stage: str | None = None  # for stop_stage_updated
    code: str | None = None  # for error
    message: str | None = None  # for error
    events: list[dict[str, Any]] | None = None  # for event_replay
    live_resume: bool | None = None  # for event_replay
    # Chunking fields
    chunk_id: str | None = None
    chunk_index: int | None = None
    chunk_count: int | None = None
    # Tasks snapshot field for pong events
    tasks: list[dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "type": self.type,
            "task_id": self.task_id,
            "timestamp": self.timestamp,
        }
        # Add optional fields if they are set
        for field_name in (
            "stage_name",
            "attempt",
            "success",
            "max_retries",
            "error",
            "artifact_status",
            "next_stage",
            "decision_source",
            "reason",
            "stage",
            "code",
            "message",
            "events",
            "live_resume",
            "chunk_id",
            "chunk_index",
            "chunk_count",
        ):
            value = getattr(self, field_name)
            if value is not None:
                result[field_name] = value
        # tasks: always include when present, even as empty list (per protocol spec:
        # "When no tasks are active, tasks is an empty array []")
        if self.tasks is not None:
            result["tasks"] = self.tasks
        return result

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ServerEvent:
        return cls(
            type=str(data.get("type", "")),
            task_id=str(data.get("task_id", "")),
            timestamp=str(data.get("timestamp", datetime.now(tz=timezone.utc).isoformat())),
            stage_name=data.get("stage_name"),
            attempt=data.get("attempt"),
            success=data.get("success"),
            max_retries=data.get("max_retries"),
            error=data.get("error"),
            artifact_status=data.get("artifact_status"),
            next_stage=data.get("next_stage"),
            decision_source=data.get("decision_source"),
            reason=data.get("reason"),
            stage=data.get("stage"),
            code=data.get("code"),
            message=data.get("message"),
            events=data.get("events"),
            live_resume=data.get("live_resume"),
            chunk_id=data.get("chunk_id"),
            chunk_index=data.get("chunk_index"),
            chunk_count=data.get("chunk_count"),
            tasks=data.get("tasks"),
        )

    @classmethod
    def from_json(cls, raw: str | bytes) -> ServerEvent:
        data = json.loads(raw) if isinstance(raw, str) else json.loads(raw.decode("utf-8"))
        return cls.from_dict(data)


def chunk_payload(events: list[dict[str, Any]], max_size: int = MAX_PAYLOAD_SIZE) -> list[dict[str, Any]]:
    """Split replay events into protocol chunk frames when the payload exceeds max_size."""
    serialized = json.dumps(events)
    if len(serialized.encode("utf-8")) <= max_size:
        return [{"type": EventType.EVENT_REPLAY.value, "events": events}]

    chunks: list[list[dict[str, Any]]] = []
    current_chunk: list[dict[str, Any]] = []
    current_size = 0

    for event in events:
        event_json = json.dumps(event)
        event_size = len(event_json.encode("utf-8"))
        if current_size + event_size > max_size and current_chunk:
            chunks.append(current_chunk)
            current_chunk = []
            current_size = 0
        current_chunk.append(event)
        current_size += event_size

    if current_chunk:
        chunks.append(current_chunk)

    result: list[dict[str, Any]] = []
    for i, chunk in enumerate(chunks):
        result.append(
            {
                "type": CHUNK_TYPE,
                "events": chunk,
                "chunk_id": f"ch-{i}",
                "chunk_index": i,
                "chunk_count": len(chunks),
            }
        )
    return result


# Factory functions for common events
def run_accepted(task_id: str) -> ServerEvent:
    return ServerEvent(type=EventType.RUN_ACCEPTED.value, task_id=task_id)


def stage_start(task_id: str, stage_name: str, attempt: int) -> ServerEvent:
    return ServerEvent(type=EventType.STAGE_START.value, task_id=task_id, stage_name=stage_name, attempt=attempt)


def stage_complete(task_id: str, stage_name: str, success: bool, attempt: int) -> ServerEvent:
    return ServerEvent(type=EventType.STAGE_COMPLETE.value, task_id=task_id, stage_name=stage_name, success=success, attempt=attempt)


def stage_retry(task_id: str, stage_name: str, attempt: int, max_retries: int, error: str) -> ServerEvent:
    return ServerEvent(type=EventType.STAGE_RETRY.value, task_id=task_id, stage_name=stage_name, attempt=attempt, max_retries=max_retries, error=error)


def stage_failed(task_id: str, stage_name: str, attempt: int, error: str) -> ServerEvent:
    return ServerEvent(type=EventType.STAGE_FAILED.value, task_id=task_id, stage_name=stage_name, attempt=attempt, error=error)


def artifact_validated(task_id: str, stage_name: str, artifact_status: str) -> ServerEvent:
    return ServerEvent(type=EventType.ARTIFACT_VALIDATED.value, task_id=task_id, stage_name=stage_name, artifact_status=artifact_status)


def routing_decision(task_id: str, stage_name: str, next_stage: str, decision_source: str) -> ServerEvent:
    return ServerEvent(type=EventType.ROUTING_DECISION.value, task_id=task_id, stage_name=stage_name, next_stage=next_stage, decision_source=decision_source)


def pipeline_abort(task_id: str, reason: str, stage_name: str | None = None) -> ServerEvent:
    return ServerEvent(type=EventType.PIPELINE_ABORT.value, task_id=task_id, reason=reason, stage_name=stage_name)


def run_complete(task_id: str, success: bool) -> ServerEvent:
    return ServerEvent(type=EventType.RUN_COMPLETE.value, task_id=task_id, success=success)


def event_replay(task_id: str, events: list[dict[str, Any]], live_resume: bool) -> ServerEvent:
    return ServerEvent(type=EventType.EVENT_REPLAY.value, task_id=task_id, events=events, live_resume=live_resume)


def stop_stage_updated(task_id: str, stage: str) -> ServerEvent:
    return ServerEvent(type=EventType.STOP_STAGE_UPDATED.value, task_id=task_id, stage=stage)


def pong(tasks: list[dict[str, Any]] | None = None) -> ServerEvent:
    """Create a pong event. The task_id field is always empty per WebSocket protocol.

    Args:
        tasks: Optional list of task snapshot dicts with keys: task_id, active_stage, attempt, status.
               When non-None, the pong includes the tasks array for client-side status display.
               When None, the tasks field is omitted from serialization (backward compat with pre-feature daemons).
               When an empty list, tasks is serialized as `tasks: []` per protocol spec.
    """
    return ServerEvent(type=EventType.PONG.value, task_id="", tasks=tasks)


def error(task_id: str, code: str, message: str) -> ServerEvent:
    return ServerEvent(type=EventType.ERROR.value, task_id=task_id, code=code, message=message)
