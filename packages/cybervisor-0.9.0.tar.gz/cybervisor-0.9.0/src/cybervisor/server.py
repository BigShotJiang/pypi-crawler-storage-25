from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import websockets
import websockets.asyncio.server as ws_server
from websockets.asyncio.server import ServerConnection

from cybervisor import __version__
from cybervisor.adapters.base import AgentAdapter
from cybervisor.adapters.registry import get_adapter
from cybervisor.config import load_config
from cybervisor.global_config import GlobalConfig, load_global_config
from cybervisor.hooks import hook_socket_path, inject_hooks, remove_hooks
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline import EndStageRef, PipelineInterrupted, PipelineRunner
from cybervisor.server_events import (
    MAX_PAYLOAD_SIZE,
    EventType,
    ServerEvent,
    artifact_validated,
    chunk_payload,
    error,
    event_replay,
    pipeline_abort,
    pong,
    run_accepted,
    routing_decision,
    run_complete,
    stage_complete,
    stage_failed,
    stage_retry,
    stage_start,
    stop_stage_updated,
)
from cybervisor.server_signals import ServerSignalHandler
from cybervisor.signals import SignalHandler


# Instance lock path for daemon
DAEMON_LOCK_PATH = ".cybervisor/daemon.lock"
DEFAULT_CONFIG_PATH = "cybervisor.yaml"


def _daemon_lock_path() -> Path:
    return Path(DAEMON_LOCK_PATH)


def _read_daemon_lock() -> dict[str, object] | None:
    lock_path = _daemon_lock_path()
    if not lock_path.exists():
        return None
    try:
        content = lock_path.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            return data
    except (json.JSONDecodeError, OSError):
        return None
    return None


def _is_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _is_daemon_lock_alive(lock: dict[str, object]) -> bool:
    pid = lock.get("pid")
    if not isinstance(pid, int):
        return False
    cwd = lock.get("cwd")
    if not isinstance(cwd, str):
        return False
    if os.getcwd() != cwd:
        return False
    return _is_pid_running(pid)


def _normalize_workspace_config_path(config_path: str) -> str | None:
    normalized = config_path.strip()
    if not normalized:
        return None
    candidate = Path(normalized)
    if candidate.is_absolute():
        return None
    if any(part == ".." for part in candidate.parts):
        return None
    return normalized


class EventRingBuffer:
    """Thread-safe fixed-size ring buffer for server events."""

    def __init__(self, capacity: int) -> None:
        self._capacity = capacity
        self._buffer: list[ServerEvent] = []
        self._lock = asyncio.Lock()

    async def append_async(self, event: ServerEvent) -> None:
        """Async append for use from async context."""
        async with self._lock:
            if len(self._buffer) >= self._capacity:
                self._buffer.pop(0)
            self._buffer.append(event)

    async def get_all_async(self) -> list[ServerEvent]:
        """Async get_all for use from async context."""
        async with self._lock:
            return list(self._buffer)

    def __len__(self) -> int:
        return len(self._buffer)


@dataclass(slots=True)
class TaskState:
    """Holds the state of an active task."""

    task_id: str
    config_path: str
    prompt: str
    start_stage: str | None
    cancel_event: asyncio.Event
    valid_stage_names: frozenset[str] = field(default_factory=frozenset)
    end_stage_ref: EndStageRef | None = None
    cancelled: bool = False
    completed: bool = False
    success: bool = False
    events: EventRingBuffer = field(default_factory=lambda: EventRingBuffer(1000))
    last_activity: datetime = field(default_factory=lambda: datetime.now(tz=timezone.utc))
    active_stage: str | None = None
    attempt: int = 0
    server_signal_handler: ServerSignalHandler | None = None
    abort_sent: bool = False  # Tracks if pipeline_abort was already sent by _handle_cancel
    live_websocket: ServerConnection | None = None
    connection_generation: int = 0
    execution_generation: int = 0
    run_task: asyncio.Task[None] | None = None


class StaleExecutionError(RuntimeError):
    """Raised when a superseded task execution attempts to emit live events."""


class DeliverySuppressedError(RuntimeError):
    """Raised when a task event should be buffered but not delivered live."""


class TaskRegistry:
    """Manages active tasks by task_id."""

    def __init__(self, max_event_buffer: int = 1000) -> None:
        self._tasks: dict[str, TaskState] = {}
        self._lock = asyncio.Lock()
        self._max_event_buffer = max_event_buffer

    async def create_task(
        self,
        task_id: str,
        config_path: str,
        prompt: str,
        start_stage: str | None = None,
    ) -> TaskState:
        async with self._lock:
            if task_id in self._tasks:
                raise ValueError(f"Task {task_id} already exists")
            cancel_event = asyncio.Event()
            end_stage_ref = EndStageRef()
            task_state = TaskState(
                task_id=task_id,
                config_path=config_path,
                prompt=prompt,
                start_stage=start_stage,
                cancel_event=cancel_event,
                end_stage_ref=end_stage_ref,
                events=EventRingBuffer(self._max_event_buffer),
            )
            task_state.execution_generation = 1
            self._tasks[task_id] = task_state
            return task_state

    async def get_task(self, task_id: str) -> TaskState | None:
        async with self._lock:
            return self._tasks.get(task_id)

    async def remove_task(self, task_id: str) -> None:
        async with self._lock:
            self._tasks.pop(task_id, None)

    async def get_task_ids(self) -> list[str]:
        async with self._lock:
            return list(self._tasks.keys())

    async def has_active_task(self) -> bool:
        async with self._lock:
            return any(not task.completed for task in self._tasks.values())

    async def update_last_activity(self, task_id: str) -> None:
        async with self._lock:
            if task_id in self._tasks:
                self._tasks[task_id].last_activity = datetime.now(tz=timezone.utc)

    async def cleanup_abandoned(self, ttl_seconds: float) -> list[str]:
        """Remove tasks abandoned for longer than ttl_seconds. Returns removed task_ids."""
        removed: list[str] = []
        now = datetime.now(tz=timezone.utc)
        async with self._lock:
            for task_id, task in list(self._tasks.items()):
                elapsed = (now - task.last_activity).total_seconds()
                if elapsed > ttl_seconds:
                    removed.append(task_id)
            for task_id in removed:
                del self._tasks[task_id]
        return removed

    async def to_dict(self) -> dict[str, Any]:
        """Serialize the registry to a dict for persistence. Returns all task state."""
        async with self._lock:
            result: dict[str, Any] = {"tasks": {}, "max_event_buffer": self._max_event_buffer}
            for task_id, task in self._tasks.items():
                events_data: list[dict[str, Any]] = []
                for event in task.events._buffer:
                    events_data.append(event.to_dict())
                result["tasks"][task_id] = {
                    "task_id": task.task_id,
                    "config_path": task.config_path,
                    "prompt": task.prompt,
                    "start_stage": task.start_stage,
                    "cancelled": task.cancelled,
                    "completed": task.completed,
                    "success": task.success,
                    "active_stage": task.active_stage,
                    "attempt": task.attempt,
                    "valid_stage_names": list(task.valid_stage_names),
                    "events": events_data,
                }
            return result

    @classmethod
    async def from_dict(cls, data: dict[str, Any], max_event_buffer: int | None = None) -> TaskRegistry:
        """Reconstruct a TaskRegistry from a serialized dict."""
        buf_size = max_event_buffer if max_event_buffer is not None else data.get("max_event_buffer", 1000)
        registry = cls(max_event_buffer=buf_size)
        tasks_data: dict[str, Any] = data.get("tasks", {})

        for task_id, task_data in tasks_data.items():
            # Re-create asyncio primitives for runtime state
            cancel_event = asyncio.Event()
            if task_data.get("cancelled", False):
                cancel_event.set()
            end_stage_ref = EndStageRef()
            event_ring = EventRingBuffer(buf_size)
            # Restore events from serialized data
            events_list: list[dict[str, Any]] = task_data.get("events", [])
            event_ring._buffer = [ServerEvent.from_dict(e) for e in events_list]

            task_state = TaskState(
                task_id=task_data["task_id"],
                config_path=task_data["config_path"],
                prompt=task_data["prompt"],
                start_stage=task_data.get("start_stage"),
                cancel_event=cancel_event,
                valid_stage_names=frozenset(task_data.get("valid_stage_names", [])),
                end_stage_ref=end_stage_ref,
                cancelled=task_data.get("cancelled", False),
                completed=task_data.get("completed", False),
                success=task_data.get("success", False),
                events=event_ring,
                active_stage=task_data.get("active_stage"),
                attempt=task_data.get("attempt", 0),
            )
            registry._tasks[task_id] = task_state
        return registry


@dataclass(slots=True)
class DaemonConfig:
    """Server daemon configuration."""

    host: str = "127.0.0.1"
    port: int = 8765
    reconnect_ttl_seconds: float = 300.0
    max_event_buffer: int = 1000
    ping_interval_seconds: float = 30.0
    ping_timeout_seconds: float = 10.0


class DaemonServer:
    """WebSocket daemon server for cybervisor task execution."""

    def __init__(
        self,
        config: DaemonConfig,
        global_config: GlobalConfig,
        logger: CybervisorLogger,
    ) -> None:
        self.config = config
        self.global_config = global_config
        self.logger = logger
        self._registry = TaskRegistry(max_event_buffer=config.max_event_buffer)
        self._server: ws_server.Server | None = None
        self._shutdown_event = asyncio.Event()
        self._background_tasks: set[asyncio.Task[Any]] = set()
        self._instance_lock_fd: int | None = None

    async def start(self) -> None:
        """Start the WebSocket server."""
        self._write_daemon_log("daemon_start", {"host": self.config.host, "port": self.config.port})
        self._server = await ws_server.serve(
            self._handle_connection,
            self.config.host,
            self.config.port,
            ping_interval=self.config.ping_interval_seconds,
            ping_timeout=self.config.ping_timeout_seconds,
        )
        self.logger.log_to_stderr(f"Daemon listening on ws://{self.config.host}:{self.config.port}", "info")

    async def stop(self) -> None:
        """Stop the WebSocket server gracefully."""
        self.logger.log_to_stderr("Daemon shutting down...", "info")
        self._shutdown_event.set()
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        for task in self._background_tasks:
            task.cancel()
        self._release_instance_lock()
        self._write_daemon_log("daemon_stop", {})

    def _write_daemon_log(self, event: str, data: dict[str, Any]) -> None:
        entry = {
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
            "event": event,
            **data,
        }
        self.logger.log_to_json(entry, ".cybervisor/logs/cybervisor.log.jsonl")

    async def _handle_connection(self, websocket: ServerConnection) -> None:
        """Handle a new WebSocket connection."""
        client_id = id(websocket)
        self._write_daemon_log("client_connect", {"client_id": client_id})
        self.logger.log_to_stderr(f"Client connected: {client_id}", "info")
        connection_task_id: str | None = None

        try:
            async for raw_message in websocket:
                if raw_message is None:
                    continue
                try:
                    message = json.loads(raw_message)
                except json.JSONDecodeError:
                    await websocket.send(error("", "invalid_message", "Invalid JSON").to_json())
                    continue

                msg_type = message.get("type")
                task_id = message.get("task_id")

                # Track which task this connection is controlling
                if msg_type in (EventType.RUN.value, EventType.RESUME.value):
                    connection_task_id = task_id

                if msg_type == EventType.PING.value:
                    # Build task snapshot for pong response
                    task_snapshots: list[dict[str, Any]] = []
                    task_ids = await self._registry.get_task_ids()
                    for task_id in task_ids:
                        task_state = await self._registry.get_task(task_id)
                        if task_state is None:
                            continue
                        # Determine status: completed > cancelled > running
                        if task_state.completed:
                            status = "completed"
                        elif task_state.cancelled:
                            status = "cancelled"
                        else:
                            status = "running"
                        snapshot: dict[str, Any] = {
                            "task_id": task_state.task_id,
                            "active_stage": task_state.active_stage,
                            "attempt": task_state.attempt,
                            "status": status,
                        }
                        task_snapshots.append(snapshot)
                    await websocket.send(pong(tasks=task_snapshots).to_json())
                    continue

                if msg_type == EventType.RUN.value:
                    await self._handle_run(websocket, message)
                    continue

                if msg_type == EventType.SET_STOP_STAGE.value:
                    await self._handle_set_stop_stage(websocket, message)
                    continue

                if msg_type == EventType.CANCEL.value:
                    await self._handle_cancel(websocket, message)
                    continue

                if msg_type == EventType.RESUME.value:
                    await self._handle_resume(websocket, message)
                    continue

                # Unknown message type
                await websocket.send(error(task_id or "", "invalid_message", f"Unknown message type: {msg_type}").to_json())

        except websockets.exceptions.ConnectionClosed:
            self.logger.log_to_stderr(f"Client disconnected: {client_id}", "info")
        finally:
            await self._clear_live_connection(websocket, connection_task_id)
            self._write_daemon_log("client_disconnect", {"client_id": client_id})

    async def _send_to_websocket(
        self,
        websocket: ServerConnection,
        event: ServerEvent,
        task_state: TaskState | None = None,
        *,
        suppress_if_aborted: bool = False,
    ) -> None:
        """Send an event to the WebSocket, handling chunking if needed."""
        if task_state is not None and suppress_if_aborted and task_state.abort_sent:
            raise DeliverySuppressedError()
        payload = event.to_dict()
        if payload.get("type") == EventType.EVENT_REPLAY.value:
            events_to_chunk = payload.get("events", [])
            if events_to_chunk:
                chunks = chunk_payload(events_to_chunk)
                # Only skip chunking when chunk_payload returned a non-oversized
                # event_replay frame (small payload). In all other cases (including
                # single oversized chunks that come back as event_replay_chunk),
                # send the chunked frames directly.
                if not (len(chunks) == 1 and chunks[0]["type"] == EventType.EVENT_REPLAY.value):
                    for chunk in chunks:
                        chunk["task_id"] = event.task_id
                        chunk["timestamp"] = event.timestamp
                        await websocket.send(json.dumps(chunk))
                    return
        await websocket.send(event.to_json())

    async def _deliver_task_event(
        self,
        task_state: TaskState,
        event: ServerEvent,
        *,
        append: bool = True,
        suppress_if_aborted: bool = False,
        expected_generation: int | None = None,
    ) -> None:
        """Buffer an event and deliver it to the task's current live websocket if allowed."""
        if expected_generation is not None and expected_generation != task_state.execution_generation:
            raise StaleExecutionError()
        if append:
            await task_state.events.append_async(event)
        websocket = task_state.live_websocket
        if websocket is None:
            return
        await self._send_to_websocket(
            websocket,
            event,
            task_state,
            suppress_if_aborted=suppress_if_aborted,
        )

    async def _finalize_task_failure(self, task_state: TaskState, code: str, message: str) -> None:
        """Emit terminal failure events and free the task slot for new runs on the same connection."""
        task_state.completed = True
        task_state.success = False
        task_state.live_websocket = None
        error_evt = error(task_state.task_id, code, message)
        await self._deliver_task_event(task_state, error_evt)
        complete_evt = run_complete(task_state.task_id, False)
        await self._deliver_task_event(task_state, complete_evt)
        await self._registry.remove_task(task_state.task_id)

    async def _clear_live_connection(self, websocket: ServerConnection, task_id: str | None) -> None:
        if task_id is None:
            return
        task_state = await self._registry.get_task(task_id)
        if task_state is None:
            return
        if task_state.live_websocket is websocket:
            task_state.live_websocket = None
            task_state.connection_generation += 1
            await self._registry.update_last_activity(task_id)

    async def _run_resume_replay(self, websocket: ServerConnection, task_state: TaskState) -> None:
        events = await task_state.events.get_all_async()
        event_dicts = [e.to_dict() for e in events]
        live_resume = not task_state.completed
        if event_dicts:
            chunks = chunk_payload(event_dicts)
            if len(chunks) == 1 and chunks[0]["type"] == EventType.EVENT_REPLAY.value:
                await websocket.send(event_replay(task_state.task_id, event_dicts, live_resume).to_json())
                return
            timestamp = datetime.now(tz=timezone.utc).isoformat()
            for chunk in chunks:
                chunk["task_id"] = task_state.task_id
                chunk["timestamp"] = timestamp
                chunk["live_resume"] = live_resume
                await websocket.send(json.dumps(chunk))
            return
        await websocket.send(event_replay(task_state.task_id, [], live_resume).to_json())

    async def _switch_live_connection(self, task_state: TaskState, websocket: ServerConnection) -> None:
        task_state.live_websocket = websocket
        task_state.connection_generation += 1
        await self._registry.update_last_activity(task_state.task_id)
        await self._run_resume_replay(websocket, task_state)

    async def _detach_execution(self, task_state: TaskState, generation: int) -> None:
        if generation != task_state.execution_generation:
            return
        task_state.live_websocket = None
        task_state.connection_generation += 1
        await self._registry.update_last_activity(task_state.task_id)
        task_state.run_task = None

    async def _append_task_event(self, task_id: str, event: ServerEvent) -> None:
        """Append an event to the task's event buffer for resume replay with FIFO eviction."""
        task_state = await self._registry.get_task(task_id)
        if task_state is not None:
            await task_state.events.append_async(event)

    async def _handle_run(self, websocket: ServerConnection, message: dict[str, Any]) -> None:
        """Handle a run request."""
        # Check if a task is already in progress
        if await self._registry.has_active_task():
            await websocket.send(error("", "task_in_progress", "A task is already in progress").to_json())
            return

        task_id = message.get("task_id")
        if not isinstance(task_id, str) or not task_id.strip():
            await websocket.send(error("", "invalid_message", "Missing required string field: task_id").to_json())
            return
        task_id = task_id.strip()

        prompt = message.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            await websocket.send(error(task_id, "invalid_message", "Missing required string field: prompt").to_json())
            return
        prompt = prompt.strip()

        config_path = message.get("config", DEFAULT_CONFIG_PATH)
        if not isinstance(config_path, str) or not config_path.strip():
            await websocket.send(error(task_id, "invalid_message", "config must be a non-empty string when provided").to_json())
            return
        normalized_config_path = _normalize_workspace_config_path(config_path)
        if normalized_config_path is None:
            await websocket.send(
                error(
                    task_id,
                    "invalid_message",
                    "config must stay within the workspace using a relative path",
                ).to_json()
            )
            return
        config_path = normalized_config_path

        start_stage = message.get("start_stage")
        if start_stage is not None:
            if not isinstance(start_stage, str) or not start_stage.strip():
                await websocket.send(error(task_id, "invalid_message", "start_stage must be a non-empty string when provided").to_json())
                return
            start_stage = start_stage.strip()

        try:
            task_state = await self._registry.create_task(task_id, config_path, prompt, start_stage)
            task_config = load_config(config_path)
            task_state.valid_stage_names = frozenset(stage.name for stage in task_config.stages)
        except ValueError:
            await websocket.send(error(task_id, "task_in_progress", "Task already exists").to_json())
            return

        task_state.live_websocket = websocket

        # Send run_accepted
        await self._deliver_task_event(task_state, run_accepted(task_id))

        # Execute the task in background
        run_task = asyncio.create_task(self._execute_task(task_state))
        task_state.run_task = run_task
        self._background_tasks.add(run_task)
        run_task.add_done_callback(self._background_tasks.discard)

    async def _handle_set_stop_stage(self, websocket: ServerConnection, message: dict[str, Any]) -> None:
        """Handle a set_stop_stage request."""
        task_id = message.get("task_id")
        if not isinstance(task_id, str) or not task_id.strip():
            await websocket.send(error("", "invalid_message", "Missing required string field: task_id").to_json())
            return
        task_id = task_id.strip()

        stage = message.get("stage")
        if not isinstance(stage, str) or not stage.strip():
            await websocket.send(error(task_id, "invalid_message", "Missing required string field: stage").to_json())
            return
        stage = stage.strip()

        task_state = await self._registry.get_task(task_id)
        if task_state is None:
            await websocket.send(error(task_id, "unknown_task", "Task not found").to_json())
            return

        if task_state.completed:
            await websocket.send(error(task_id, "invalid_message", "Task already completed").to_json())
            return

        if stage not in task_state.valid_stage_names:
            await websocket.send(
                error(task_id, "invalid_message", f"Unknown stage: {stage}").to_json()
            )
            return

        # Update the end stage ref for dynamic mid-pipeline stop stage changes
        if task_state.end_stage_ref is not None:
            task_state.end_stage_ref.set(stage)
        await self._registry.update_last_activity(task_id)
        await self._deliver_task_event(task_state, stop_stage_updated(task_id, stage))

    async def _handle_cancel(self, websocket: ServerConnection, message: dict[str, Any]) -> None:
        """Handle a cancel request."""
        task_id = message.get("task_id")
        if task_id is None:
            await websocket.send(error("", "invalid_message", "Missing task_id").to_json())
            return

        task_state = await self._registry.get_task(task_id)
        if task_state is None:
            await websocket.send(error(task_id or "", "unknown_task", "Task not found").to_json())
            return

        # Check if task is in a cancellable state
        if task_state.completed or task_state.cancelled:
            await websocket.send(error(task_id, "not_cancellable", "Task is not in a cancellable state").to_json())
            return

        # Deliver SIGINT to interrupt the active subprocess
        # SC-003: Wait for termination (up to 2s) before sending pipeline_abort
        # Set cancel_event and abort_sent IMMEDIATELY so PipelineRunner and
        # scheduled callbacks see them before pipeline_abort is sent.
        task_state.cancel_event.set()
        task_state.cancelled = True
        task_state.abort_sent = True
        if task_state.server_signal_handler is not None:
            # Also set interrupted flag directly so PipelineRunner sees it during subprocess wait
            task_state.server_signal_handler._signal_handler.interrupted = True
            await task_state.server_signal_handler.deliver_signal(signal.SIGINT)

        evt = pipeline_abort(task_id, "cancelled_by_client", task_state.active_stage)
        await task_state.events.append_async(evt)
        await self._send_to_websocket(websocket, evt)

    async def _handle_resume(self, websocket: ServerConnection, message: dict[str, Any]) -> None:
        """Handle a resume request (reconnect and replay events)."""
        task_id = message.get("task_id")

        if not task_id:
            await websocket.send(error("", "invalid_message", "Missing task_id").to_json())
            return

        task_state = await self._registry.get_task(task_id)
        if task_state is None:
            await websocket.send(error(task_id, "unknown_task", "Task not found or TTL expired").to_json())
            return

        await self._switch_live_connection(task_state, websocket)

    async def _execute_task(self, task_state: TaskState) -> None:
        """Execute a task using the PipelineRunner."""
        task_id = task_state.task_id
        execution_generation = task_state.execution_generation
        await self._registry.update_last_activity(task_id)
        hook_listener: HookEventListener | None = None
        hooks_installed = False

        try:
            try:
                config = load_config(task_state.config_path)
            except FileNotFoundError as exc:
                await self._finalize_task_failure(task_state, "server_error", f"Config not found: {exc}")
                return

            try:
                agent_tool = self.global_config.agent_tool
            except Exception as exc:
                await self._finalize_task_failure(task_state, "server_error", f"Failed to resolve agent: {exc}")
                return

            agent: AgentAdapter = get_adapter(agent_tool)

            from cybervisor.preflight import run_preflight
            preflight_errors = run_preflight(agent_tool, config)
            if preflight_errors:
                await self._finalize_task_failure(task_state, "server_error", f"Preflight failed: {preflight_errors[0]}")
                return

            task_logger = CybervisorLogger()
            signal_handler = SignalHandler(task_logger, log_file=".cybervisor/logs/cybervisor.log.jsonl")
            server_signal_handler = ServerSignalHandler(signal_handler)
            server_signal_handler.set_cancel_event(task_state.cancel_event)
            task_state.server_signal_handler = server_signal_handler
            if agent.descriptor.capabilities.supports_hooks:
                try:
                    hook_listener = HookEventListener(task_logger, socket_path=hook_socket_path())
                    hook_listener.start()
                    inject_hooks(agent_tool, config.hook)
                    hooks_installed = True
                except Exception:
                    if hook_listener is not None:
                        hook_listener.stop()
                    raise

            _loop = asyncio.get_event_loop()

            def stage_event_callback(event: dict[str, Any]) -> None:
                if task_state.abort_sent:
                    return
                event_type = event.get("event_type")
                if event_type == "stage_start":
                    task_state.active_stage = event["stage_name"]
                    evt = stage_start(task_id, event["stage_name"], event["attempt"])
                elif event_type == "stage_complete":
                    evt = stage_complete(task_id, event["stage_name"], event["success"], event["attempt"])
                elif event_type == "stage_retry":
                    evt = stage_retry(task_id, event["stage_name"], event["attempt"], event["max_retries"], event["error"])
                elif event_type == "stage_failed":
                    evt = stage_failed(task_id, event["stage_name"], event["attempt"], event["error"])
                elif event_type == "artifact_validated":
                    evt = artifact_validated(task_id, event["stage_name"], event["artifact_status"])
                elif event_type == "routing_decision":
                    evt = routing_decision(task_id, event["stage_name"], event["next_stage"], event["decision_source"])
                else:
                    return
                future = asyncio.run_coroutine_threadsafe(
                    self._deliver_task_event(
                        task_state,
                        evt,
                        suppress_if_aborted=True,
                        expected_generation=execution_generation,
                    ),
                    _loop,
                )

                def _consume_result(done_future: Any) -> None:
                    try:
                        done_future.result()
                    except (DeliverySuppressedError, StaleExecutionError):
                        pass

                future.add_done_callback(_consume_result)

            loop = asyncio.get_event_loop()
            success = await loop.run_in_executor(
                None,
                self._run_pipeline_sync,
                task_state,
                task_state.prompt,
                config.stages,
                agent,
                task_logger,
                signal_handler,
                task_state.start_stage,
                task_state.end_stage_ref,
                stage_event_callback,
                hook_listener,
            )

            if execution_generation != task_state.execution_generation:
                return

            if task_state.cancel_event.is_set():
                task_state.completed = True
                task_state.success = False
                task_state.live_websocket = None
                if not task_state.abort_sent:
                    abort_evt = pipeline_abort(task_id, "cancelled_by_client", task_state.active_stage)
                    await self._deliver_task_event(task_state, abort_evt)
                await asyncio.sleep(0)
                complete_evt = run_complete(task_id, False)
                await self._deliver_task_event(task_state, complete_evt)
                await self._registry.remove_task(task_id)
                return

            task_state.completed = True
            task_state.success = success
            task_state.live_websocket = None
            evt = run_complete(task_id, success)
            await self._deliver_task_event(task_state, evt)
            await self._registry.remove_task(task_id)

        except PipelineInterrupted as exc:
            if execution_generation != task_state.execution_generation:
                return
            task_state.completed = True
            task_state.success = False
            task_state.live_websocket = None
            if not task_state.abort_sent:
                abort_evt = pipeline_abort(task_id, f"interrupted: {exc}", exc.stage_name)
                await self._deliver_task_event(task_state, abort_evt)
            complete_evt = run_complete(task_id, False)
            await self._deliver_task_event(task_state, complete_evt)
            await self._registry.remove_task(task_id)
        except Exception as exc:
            if execution_generation != task_state.execution_generation:
                return
            await self._finalize_task_failure(task_state, "server_error", str(exc))
        finally:
            if hook_listener is not None:
                hook_listener.stop()
            if hooks_installed:
                try:
                    restore_result = remove_hooks(agent_tool)
                    self.logger.log_to_json(
                        task_logger.make_entry(
                            "system",
                            "Cleanup",
                            "Removed runtime hooks",
                            cleanup_result=restore_result,
                        ),
                        ".cybervisor/logs/cybervisor.log.jsonl",
                    )
                except Exception as exc:
                    self.logger.log_to_stderr(f"Failed to remove runtime hooks: {exc}", "warning")
            await self._detach_execution(task_state, execution_generation)

    def _run_pipeline_sync(
        self,
        task_state: Any,
        prompt: str,
        stages: list[Any],  # StageConfig list
        agent: AgentAdapter,
        task_logger: CybervisorLogger,
        signal_handler: SignalHandler,
        start_stage_name: str | None,
        end_stage_ref: EndStageRef | None = None,
        stage_event_callback: Any = None,  # StageEventCallback | None
        hook_listener: HookEventListener | None = None,
    ) -> bool:
        """Synchronous wrapper to run PipelineRunner in executor.

        Checks task_state.cancel_event.is_set() at entry to detect cancellation
        requested before this executor started. Also checks after runner.run()
        returns - if cancel was set during the run, treat as interrupted.
        """
        # Check if cancel was requested before we started
        if task_state.cancel_event.is_set():
            raise PipelineInterrupted("", 0)
        runner = PipelineRunner()
        try:
            result = runner.run(
                prompt,
                stages,
                agent,
                task_logger,
                signal_handler=signal_handler,
                start_stage_name=start_stage_name,
                end_stage_ref=end_stage_ref,
                stage_event_callback=stage_event_callback,
                hook_listener=hook_listener,
            )
        except PipelineInterrupted:
            return False
        # Check if cancel was set during the run - if so, treat as interrupted
        if task_state.cancel_event.is_set():
            raise PipelineInterrupted("", 0)
        return result

    def _acquire_instance_lock(self) -> bool:
        """Acquire daemon instance lock. Returns True if acquired, False if already held."""
        lock_path = _daemon_lock_path()
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "pid": os.getpid(),
            "cwd": os.getcwd(),
            "started_at": datetime.now(tz=timezone.utc).isoformat(),
            "version": __version__,
        }

        for _attempt in range(2):
            try:
                fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
                self._instance_lock_fd = fd
                os.write(fd, json.dumps(payload).encode("utf-8"))
                return True
            except FileExistsError:
                lock = _read_daemon_lock()
                if lock is not None and _is_daemon_lock_alive(lock):
                    return False
                try:
                    lock_path.unlink()
                except FileNotFoundError:
                    continue
                except OSError:
                    return False
            except OSError:
                return False
        return False

    def _release_instance_lock(self) -> None:
        """Release the daemon instance lock."""
        lock_fd = self._instance_lock_fd
        self._instance_lock_fd = None
        if lock_fd is not None:
            try:
                os.close(lock_fd)
            except OSError:
                pass

        lock_path = _daemon_lock_path()
        lock = _read_daemon_lock()
        if lock_fd is None or lock is None:
            return

        pid = lock.get("pid")
        cwd = lock.get("cwd")
        if pid == os.getpid() and cwd == os.getcwd():
            lock_path.unlink(missing_ok=True)


async def serve(
    host: str | None = None,
    port: int | None = None,
    background: bool = False,
    logger: CybervisorLogger | None = None,
) -> None:
    """Entry point for the daemon server."""
    if logger is None:
        logger = CybervisorLogger()

    # Handle daemonization early, before any async operations
    if background:
        # Double-fork for proper Unix daemonization
        try:
            # First fork
            pid = os.fork()
            if pid > 0:
                # Parent exits
                os._exit(0)
        except OSError as exc:
            logger.log_to_stderr(f"First fork failed: {exc}", "error")
            return

        # Create new session and detach from terminal
        try:
            os.setsid()
        except OSError:
            pass

        try:
            # Second fork to prevent acquiring a new controlling terminal
            pid = os.fork()
            if pid > 0:
                os._exit(0)
        except OSError as exc:
            logger.log_to_stderr(f"Second fork failed: {exc}", "error")
            return

        # Redirect standard file descriptors to /dev/null
        devnull_fd = os.open("/dev/null", os.O_RDWR)
        try:
            os.dup2(devnull_fd, sys.stdin.fileno())
            os.dup2(devnull_fd, sys.stdout.fileno())
            os.dup2(devnull_fd, sys.stderr.fileno())
        finally:
            os.close(devnull_fd)

    # Load global config first to get server settings
    try:
        global_config = load_global_config()
    except Exception as exc:
        logger.log_to_stderr(f"Failed to load global config: {exc}", "error")
        return

    daemon_config = DaemonConfig(
        host=host if host is not None else global_config.server.host,
        port=port if port is not None else global_config.server.port,
        reconnect_ttl_seconds=global_config.server.reconnect_ttl_seconds,
        max_event_buffer=global_config.server.max_event_buffer,
    )

    server = DaemonServer(daemon_config, global_config, logger)

    # Acquire instance lock
    if not server._acquire_instance_lock():
        logger.log_to_stderr(f"Another daemon instance is already running. Check {DAEMON_LOCK_PATH}.", "error")
        return

    # Handle shutdown signals
    shutdown_event = asyncio.Event()

    def shutdown_handler(signum: int) -> None:
        logger.log_to_stderr(f"Received signal {signum}, shutting down...", "info")
        shutdown_event.set()

    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            asyncio.get_event_loop().add_signal_handler(signum, shutdown_handler, signum)
        except (NotImplementedError, ValueError):
            # Windows doesn't support add_signal_handler
            pass

    try:
        await server.start()

        # Start background cleanup task
        cleanup_task = asyncio.create_task(_cleanup_abandoned_tasks(server._registry, daemon_config.reconnect_ttl_seconds, logger))
        server._background_tasks.add(cleanup_task)
        cleanup_task.add_done_callback(server._background_tasks.discard)

        await shutdown_event.wait()
    except Exception as exc:
        logger.log_to_stderr(f"Daemon error: {exc}", "error")
    finally:
        await server.stop()


async def _cleanup_abandoned_tasks(registry: TaskRegistry, ttl_seconds: float, logger: CybervisorLogger) -> None:
    """Periodically cleanup abandoned tasks."""
    while True:
        await asyncio.sleep(ttl_seconds / 2)
        removed = await registry.cleanup_abandoned(ttl_seconds)
        for task_id in removed:
            logger.log_to_stderr(f"Removed abandoned task: {task_id}", "warning")
