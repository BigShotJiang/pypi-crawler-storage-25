from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import uuid
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError
from importlib.metadata import distribution
from pathlib import Path

from cybervisor import __version__
from cybervisor.adapters.base import AgentAdapter
from cybervisor.doctor import diagnose_global_llm_readiness
from cybervisor.adapters.registry import get_adapter
from cybervisor.config import (
    PipelineConfig,
    StageConfig,
    StrictValidationError,
    format_validation_issue,
    load_config,
    render_contract_guidance,
    validate_config_file,
    validate_prompt_templates,
)
from cybervisor.global_config import (
    GlobalConfigError,
    global_config_path,
    load_global_config,
    update_global_agent_tool,
)
from cybervisor.hooks import hook_socket_path, inject_hooks, remove_hooks
from cybervisor.init import run_init
from cybervisor.logging import CybervisorLogger, HookEventListener
from cybervisor.pipeline import PipelineInterrupted, PipelineRunner
from cybervisor.preflight import run_preflight
from cybervisor.signals import SignalHandler
from cybervisor.server import serve as run_serve
from cybervisor import client as client_module

RUN_LOG_PATH = ".cybervisor/logs/cybervisor.log.jsonl"


@dataclass(frozen=True, slots=True)
class DocsDocument:
    identifier: str
    source_path: Path
    aliases: tuple[str, ...] = ()
    replacement_for: tuple[str, ...] = ()


_DOCS_DOCUMENTS: tuple[DocsDocument, ...] = (
    DocsDocument(identifier="config", source_path=Path("docs/configuration.md")),
    DocsDocument(
        identifier="updating",
        source_path=Path("docs/updating.md"),
        aliases=("update", "upgrade"),
    ),
    DocsDocument(
        identifier="pipeline-authoring",
        source_path=Path("docs/cybervisor-pipeline-authoring-guide.md"),
        aliases=("pipeline", "cybervisor.yaml"),
        replacement_for=("config-authoring",),
    ),
)


def _docs_lookup() -> dict[str, DocsDocument]:
    lookup: dict[str, DocsDocument] = {}
    for document in _DOCS_DOCUMENTS:
        lookup[document.identifier] = document
        for alias in document.aliases:
            lookup[alias] = document
    return lookup


_DOCS_LOOKUP = _docs_lookup()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cybervisor")
    parser.add_argument("--version", action="store_true", help="Show version and exit")

    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Run the cybervisor pipeline")
    _add_run_arguments(run_parser)

    init_parser = subparsers.add_parser("init", help="Create a cybervisor.yaml scaffold")
    init_parser.add_argument("--template", default=None, choices=["simple", "speckit"], help="Select the scaffold template explicitly (accepted values: simple, speckit)")

    def _init_error(message: str) -> None:
        init_parser.exit(status=1, message=message)

    init_parser.error = _init_error  # type: ignore[method-assign, assignment]
    init_parser.add_argument("--force", action="store_true", help="Replace an existing cybervisor.yaml explicitly")
    serve_parser = subparsers.add_parser("serve", help="Start the cybervisor daemon server")
    serve_parser.add_argument("--host", default=None, help="Host to bind the server to (default: ~/.cybervisor/config.yaml server.host or 127.0.0.1)")
    serve_parser.add_argument("--port", type=int, default=None, help="Port to bind the server to (default: ~/.cybervisor/config.yaml server.port or 8765)")
    serve_parser.add_argument("--background", action="store_true", help="Run the server in the background")
    subparsers.add_parser("doctor", help="Verify LLM verifier credentials")
    validate_parser = subparsers.add_parser("validate", help="Validate one or more cybervisor config files")
    validate_parser.add_argument("paths", nargs="*", help="Config file paths to validate")
    validate_parser.add_argument(
        "--show-guidance",
        action="store_true",
        help="Print generated contract guidance prompts for contract-enabled stages",
    )
    docs_parser = subparsers.add_parser(
        "docs",
        help="Read canonical cybervisor documentation",
        usage="cybervisor docs <document>",
        description="Read canonical cybervisor documentation by document identifier.",
    )
    docs_parser.add_argument("document", nargs="?", help="Document identifier to read")
    use_parser = subparsers.add_parser("use", help="Set the global default runtime agent")
    use_parser.add_argument("agent_tool", help="Agent tool to remember in ~/.cybervisor/config.yaml")

    # status subcommand
    status_parser = subparsers.add_parser("status", help="Ping the daemon and report connectivity")
    status_parser.add_argument("--host", default=None, help="Host to connect to")
    status_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # submit subcommand
    submit_parser = subparsers.add_parser("submit", help="Submit a task to the daemon for async execution")
    submit_parser.add_argument("prompt", nargs="?", default=None, help="Task description to execute")
    submit_parser.add_argument("--config", default=None, help="Path to cybervisor.yaml")
    submit_parser.add_argument("--start-stage", default=None, help="Stage name to skip to and begin execution at")
    submit_parser.add_argument("--task-id", default=None, help="Explicit task ID (auto-generated if omitted)")
    submit_parser.add_argument("--host", default=None, help="Host to connect to")
    submit_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # attach subcommand
    attach_parser = subparsers.add_parser("attach", help="Reconnect to a running or completed task")
    attach_parser.add_argument("task_id", help="Task ID to attach to")
    attach_parser.add_argument("--host", default=None, help="Host to connect to")
    attach_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # cancel subcommand
    cancel_parser = subparsers.add_parser("cancel", help="Cancel an active task")
    cancel_parser.add_argument("task_id", help="Task ID to cancel")
    cancel_parser.add_argument("--host", default=None, help="Host to connect to")
    cancel_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # logs subcommand
    logs_parser = subparsers.add_parser("logs", help="Dump buffered events as JSON Lines")
    logs_parser.add_argument("task_id", help="Task ID to dump logs for")
    logs_parser.add_argument("--host", default=None, help="Host to connect to")
    logs_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    # stop-stage subcommand
    stop_stage_parser = subparsers.add_parser("stop-stage", help="Update the stop stage of a running task")
    stop_stage_parser.add_argument("task_id", help="Task ID to update")
    stop_stage_parser.add_argument("--stage", required=True, help="Stage name to stop at")
    stop_stage_parser.add_argument("--host", default=None, help="Host to connect to")
    stop_stage_parser.add_argument("--port", type=int, default=None, help="Port to connect to")

    return parser


def _add_run_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("prompt", nargs="?", help="Task description to execute")
    parser.add_argument("--config", default="cybervisor.yaml", help="Path to config YAML")
    parser.add_argument("--start-stage", help="Stage name to skip to and begin execution at")
    parser.add_argument("--end-stage", help="Stage name to stop after")
    parser.add_argument("--end-before", help="Stage name to stop before")


def _prepare_argv(argv: list[str] | None) -> list[str]:
    raw_args = list(argv) if argv is not None else sys.argv[1:]
    if not raw_args:
        if argv is None and not sys.stdin.isatty():
            return ["run"]
        return raw_args

    first = raw_args[0]
    if first in {
        "run",
        "init",
        "doctor",
        "validate",
        "docs",
        "use",
        "serve",
        "status",
        "submit",
        "attach",
        "cancel",
        "logs",
        "stop-stage",
        "-h",
        "--help",
        "--version",
    }:
        return raw_args
    return ["run", *raw_args]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = build_parser()
    return parser.parse_args(_prepare_argv(argv))


def _resolve_prompt(args: argparse.Namespace) -> tuple[str, str | None]:
    prompt = getattr(args, "prompt", None)
    if isinstance(prompt, str):
        return prompt, "positional prompt"

    stdin = sys.stdin
    try:
        stdin_is_tty = stdin.isatty()
    except OSError:
        stdin_is_tty = True

    if not stdin_is_tty:
        try:
            stdin_prompt = stdin.read()
        except OSError:
            return "", "config"
        if stdin_prompt.strip():
            return stdin_prompt, "stdin"

    return "", None


class StartupValidationError(Exception):
    def __init__(self, requested_stage_name: str, reason: str, valid_stage_names: list[str]) -> None:
        super().__init__(reason)
        self.requested_stage_name = requested_stage_name
        self.reason = reason
        self.valid_stage_names = valid_stage_names


def validate_stage_name_arg(requested: str | None, stages: list[StageConfig], flag_name: str) -> str | None:
    valid_names = [stage.name for stage in stages]

    seen = set()
    duplicates = set()
    for name in valid_names:
        if name in seen:
            duplicates.add(name)
        seen.add(name)

    if duplicates:
        raise StartupValidationError(
            requested or "",
            f"Duplicate stage name(s) found in config: {', '.join(sorted(duplicates))}. Cannot safely resolve starting stage.",
            valid_names,
        )

    if requested is None:
        return None
    normalized = requested.strip()
    if not normalized:
        raise StartupValidationError(requested, f"{flag_name} must not be empty.", valid_names)
    if normalized not in valid_names:
        raise StartupValidationError(normalized, f"Unknown stage '{normalized}'.", valid_names)
    return normalized


def validate_start_stage(requested: str | None, stages: list[StageConfig]) -> str | None:
    return validate_stage_name_arg(requested, stages, "--start-stage")


def _resolve_agent_tool() -> str:
    try:
        return load_global_config().agent_tool
    except GlobalConfigError as exc:
        raise ValueError(str(exc)) from exc


def _select_agent(agent_tool: str) -> AgentAdapter:
    return get_adapter(agent_tool)


def _set_process_title() -> None:
    if sys.platform.startswith("win"):
        return
    try:
        from setproctitle import setproctitle
    except ImportError:
        return
    setproctitle("cybervisor")


_INSTANCE_LOCK_PATH = ".cybervisor/instance.lock"


def _instance_lock_path() -> Path:
    return Path(_INSTANCE_LOCK_PATH)


def _read_instance_lock() -> dict[str, object] | None:
    lock_path = _instance_lock_path()
    if not lock_path.exists():
        return None
    try:
        content = lock_path.read_text(encoding="utf-8")
        data = json.loads(content)
        if isinstance(data, dict):
            return data
        return None
    except (json.JSONDecodeError, OSError):
        return None


def _write_instance_lock(pid: int) -> None:
    lock_path = _instance_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": pid,
        "cwd": os.getcwd(),
        "started_at": __import__("datetime").datetime.now().isoformat(),
    }
    # Use O_CREAT | O_EXCL for atomic lock acquisition
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    fd = os.open(lock_path, flags, 0o644)
    try:
        os.write(fd, json.dumps(payload).encode("utf-8"))
    finally:
        os.close(fd)


def _remove_instance_lock() -> None:
    _instance_lock_path().unlink(missing_ok=True)


def _is_instance_alive(lock: dict[str, object]) -> bool:
    pid = lock.get("pid")
    if not isinstance(pid, int):
        return False
    cwd = lock.get("cwd")
    if not isinstance(cwd, str):
        return False
    # Check if cwd matches current directory
    if os.getcwd() != cwd:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def _check_single_instance() -> bool:
    logger = CybervisorLogger()
    lock = _read_instance_lock()
    if lock is not None and _is_instance_alive(lock):
        pid = lock.get("pid")
        logger.log_to_stderr(
            f"Another cybervisor instance (pid={pid}) is already running in this directory. Exiting to prevent concurrent execution.",
            "error",
        )
        return False
    # Remove stale lock if present
    _remove_instance_lock()
    try:
        _write_instance_lock(os.getpid())
    except OSError as exc:
        logger.log_to_stderr(f"Failed to acquire instance lock: {exc}. Another instance may have been started concurrently.", "error")
        return False
    return True


def _runtime_dir() -> Path:
    return Path(".cybervisor")


def _process_id_file() -> Path:
    return _runtime_dir() / "process-id"


def _process_group_file() -> Path:
    return _runtime_dir() / "process-group-id"


def _process_group_id() -> int | None:
    if not hasattr(os, "getpgid"):
        return None
    return os.getpgid(os.getpid())


def _write_runtime_files() -> None:
    runtime_dir = _runtime_dir()
    runtime_dir.mkdir(parents=True, exist_ok=True)
    process_group_id = _process_group_id()
    _process_id_file().write_text(f"{os.getpid()}\n", encoding="utf-8")
    if process_group_id is not None:
        _process_group_file().write_text(f"{process_group_id}\n", encoding="utf-8")


def _remove_runtime_files() -> None:
    _process_id_file().unlink(missing_ok=True)
    _process_group_file().unlink(missing_ok=True)


def _effective_stage_slice(stages: list[StageConfig], start_stage_name: str | None) -> list[StageConfig]:
    if start_stage_name is None:
        return stages
    start_index = next(index for index, stage in enumerate(stages) if stage.name == start_stage_name)
    return stages[start_index:]


def _stages_requiring_objective(stages: list[StageConfig], start_stage_name: str | None) -> list[str]:
    return validate_prompt_templates(PipelineConfig(stages=_effective_stage_slice(stages, start_stage_name)))


def _run_pipeline(args: argparse.Namespace) -> int:
    logger = CybervisorLogger()

    # Check daemon for active tasks before acquiring instance lock.
    # If daemon is reachable and has a running task, yield to it.
    daemon_config = client_module._resolve_config(None, None)
    daemon_reachable, daemon_tasks = asyncio.run(client_module.ping_daemon(daemon_config))
    if daemon_reachable:
        running_tasks = [t for t in daemon_tasks if t.get("status") == "running"]
        if running_tasks:
            task = running_tasks[0]
            active_stage = task.get("active_stage")
            stage_label = active_stage if active_stage is not None else "initializing"
            logger.log_to_stderr(
                f"A task is already running (id: {task.get('task_id')}, stage: {stage_label}). "
                "Use 'cybervisor attach {task_id}' to view it, or 'cybervisor cancel {task_id}' to stop it.".replace(
                    "{task_id}", task.get("task_id") or ""
                ),
                "error",
            )
            return 1

    if not _check_single_instance():
        return 1

    resolved_prompt, prompt_source = _resolve_prompt(args)

    try:
        config = load_config(args.config)
    except FileNotFoundError as exc:
        logger.log_to_stderr(
            (
                f"Failed to load config: {exc}. "
                "Provide --config with a valid path or create cybervisor.yaml in the working directory."
            ),
            "error",
        )
        return 1
    except Exception as exc:  # pragma: no cover
        logger.log_to_stderr(f"Failed to load config: {exc}", "error")
        return 1

    try:
        start_stage_name = validate_stage_name_arg(args.start_stage, config.stages, "--start-stage")
        end_stage_name = validate_stage_name_arg(args.end_stage, config.stages, "--end-stage")
        end_before_stage_name = validate_stage_name_arg(args.end_before, config.stages, "--end-before")
    except StartupValidationError as exc:
        logger.log_to_stderr(
            f"Invalid stage selection: {exc.reason}\nValid stages are: {', '.join(exc.valid_stage_names)}",
            "error",
        )
        return 1
    try:
        agent_tool = _resolve_agent_tool()
    except ValueError as exc:
        logger.log_to_stderr(f"Failed to resolve runtime agent: {exc}", "error")
        return 1

    if end_stage_name is not None and end_before_stage_name is not None:
        logger.log_to_stderr(
            "Invalid stage selection: --end-stage and --end-before cannot be used together.",
            "error",
        )
        return 1

    prompt_from_config = False
    if not resolved_prompt:
        missing_objective_stages = _stages_requiring_objective(config.stages, start_stage_name)
        if missing_objective_stages:
            logger.log_to_stderr(
                "No prompt was provided, and the following stages still require one because they rely on the default objective-driven prompt_template: "
                + ", ".join(missing_objective_stages),
                "error",
            )
            return 1
        prompt_from_config = True
        prompt_source = "config"

    if prompt_source == "stdin":
        logger.log_to_stderr("Objective source: stdin.", "info")
    elif prompt_from_config:
        logger.log_to_stderr("No prompt provided; task context will come from the configured stage prompt_template values.", "info")
    elif prompt_source == "positional prompt":
        logger.log_to_stderr("Objective source: positional prompt.", "info")

    if start_stage_name is not None and prompt_from_config:
        logger.log_to_stderr(f"Promptless startup validated against the effective stage slice beginning at '{start_stage_name}'.", "info")

    if start_stage_name is not None and prompt_source == "stdin":
        logger.log_to_stderr(f"Using --start-stage '{start_stage_name}' with stdin-supplied task context.", "info")

    if start_stage_name is not None and prompt_source == "positional prompt":
        logger.log_to_stderr(f"Using --start-stage '{start_stage_name}' with positional prompt context.", "info")

    if prompt_source == "positional prompt":
        logger.log_to_stderr("Configured stage prompt_template values remain active; the positional prompt only supplies the objective context.", "info")

    if prompt_from_config:
        logger.log_to_stderr("Startup did not infer task context from repository state; only configured stage prompt_template values were used.", "info")
        resolved_prompt = ""

    if prompt_source == "stdin":
        logger.log_to_stderr("Configured stage prompt_template values remain active; stdin only supplies the objective context.", "info")

    errors = run_preflight(agent_tool, config)
    if errors:
        for error in errors:
            logger.log_to_stderr(error, "error")
        return 1

    logger.log_to_stderr(f"Using runtime agent '{agent_tool}'.", "info")
    agent = _select_agent(agent_tool)
    hook_listener: HookEventListener | None = None
    if agent.descriptor.capabilities.supports_hooks:
        hook_listener = HookEventListener(logger, socket_path=hook_socket_path())
        hook_listener.start()

    hooks_installed = False
    if agent.descriptor.capabilities.supports_hooks:
        try:
            inject_hooks(agent_tool, config.hook)
            hooks_installed = True
        except Exception as exc:
            if hook_listener is not None:
                hook_listener.stop()
            logger.log_to_stderr(f"Failed to install runtime hooks: {exc}", "error")
            return 1

    signal_handler = SignalHandler(logger, log_file=RUN_LOG_PATH)
    if hooks_installed:
        signal_handler.set_cleanup_callback(lambda: remove_hooks(agent_tool))
    signal_handler.register()
    _write_runtime_files()

    try:
        runner = PipelineRunner()
        try:
            ok = runner.run(
                resolved_prompt,
                config.stages,
                agent,
                logger,
                signal_handler=signal_handler,
                hook_listener=hook_listener,
                start_stage_name=start_stage_name,
                end_stage_name=end_stage_name,
                end_before_stage_name=end_before_stage_name,
            )
        except PipelineInterrupted:
            return 130
        return 0 if ok else 1
    finally:
        if hook_listener is not None:
            hook_listener.stop()
        if hooks_installed:
            try:
                restore_result = remove_hooks(agent_tool)
                logger.log_to_json(
                    logger.make_entry(
                        "system",
                        "Cleanup",
                        "Removed runtime hooks",
                        cleanup_result=restore_result,
                    ),
                    RUN_LOG_PATH,
                )
            except Exception as exc:
                logger.log_to_stderr(f"Failed to remove runtime hooks: {exc}", "warning")
        _remove_runtime_files()
        _remove_instance_lock()


async def _run_status_command(args: argparse.Namespace) -> int:
    return await client_module.run_status_command(host=args.host, port=args.port)


async def _run_submit_command(args: argparse.Namespace) -> int:
    return await client_module.run_submit_command(
        prompt=args.prompt,
        host=args.host,
        port=args.port,
        task_id=args.task_id,
        config_path=args.config,
        start_stage=args.start_stage,
    )


async def _run_attach_command(args: argparse.Namespace) -> int:
    return await client_module.run_attach_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_cancel_command(args: argparse.Namespace) -> int:
    return await client_module.run_cancel_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_logs_command(args: argparse.Namespace) -> int:
    return await client_module.run_logs_command(task_id=args.task_id, host=args.host, port=args.port)


async def _run_stop_stage_command(args: argparse.Namespace) -> int:
    return await client_module.run_stop_stage_command(
        task_id=args.task_id,
        stage=args.stage,
        host=args.host,
        port=args.port,
    )


async def _run_serve_command(args: argparse.Namespace) -> int:
    import asyncio
    logger = CybervisorLogger()
    try:
        await run_serve(
            host=args.host,
            port=args.port,
            background=args.background,
            logger=logger,
        )
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logger.log_to_stderr(f"Server error: {exc}", "error")
        return 1


def _run_doctor_command(_args: argparse.Namespace) -> int:
    logger = CybervisorLogger()
    result = diagnose_global_llm_readiness(timeout=15.0)
    if result.is_ready:
        logger.log_to_stderr(f"Doctor: verifier ready — {result.summary}", "info")
        logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "info")
        if result.status == "rate_limited":
            logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "info")
        return result.exit_code

    state = "needs attention" if result.failure_category == "remote_probe" else "blocked"
    logger.log_to_stderr(f"Doctor: verifier {state} — {result.summary}", "error")
    logger.log_to_stderr("Doctor: scope — verifier readiness only; this does not validate the full Cybervisor runtime.", "error")
    logger.log_to_stderr(f"Doctor: next step — {result.remediation}", "error")
    return result.exit_code


def _run_use_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger()
    try:
        agent_tool, config_path = update_global_agent_tool(args.agent_tool)
    except GlobalConfigError as exc:
        logger.log_to_stderr(f"Failed to save runtime agent: {exc}", "error")
        return 1
    logger.log_to_stderr(f"Saved global runtime agent '{agent_tool}' to {config_path}.", "info")
    return 0


def _valid_docs_identifiers() -> str:
    return ", ".join(document.identifier for document in _DOCS_DOCUMENTS)



def _render_docs_usage() -> str:
    return f"Usage: cybervisor docs <document>\nValid documents: {_valid_docs_identifiers()}"



def _read_docs_source(document: DocsDocument) -> str:
    return _resolve_docs_source_path(document).read_text(encoding="utf-8")


def _resolve_workspace_docs_source_path(document: DocsDocument) -> Path | None:
    repo_root = Path(__file__).resolve().parents[2]
    workspace_path = repo_root / document.source_path
    if workspace_path.is_file():
        return workspace_path.resolve()
    return None


def _resolve_docs_source_path(document: DocsDocument) -> Path:
    workspace_path = _resolve_workspace_docs_source_path(document)
    if workspace_path is not None:
        return workspace_path

    installed_data_path = Path(sys.prefix) / "share" / "cybervisor" / document.source_path
    if installed_data_path.is_file():
        return installed_data_path.resolve()

    installed_relative_path = Path("share/cybervisor") / document.source_path
    try:
        installed_distribution = distribution("cybervisor")
    except PackageNotFoundError as exc:
        raise FileNotFoundError(f"Unable to locate {document.source_path.as_posix()}.") from exc

    for package_file in installed_distribution.files or ():
        if Path(str(package_file)) != installed_relative_path:
            continue
        installed_path = Path(str(installed_distribution.locate_file(package_file)))
        if installed_path.is_file():
            return installed_path.resolve()

    raise FileNotFoundError(f"Unable to locate {document.source_path.as_posix()}.")



def _resolve_docs_document(requested: str) -> tuple[DocsDocument | None, str | None]:
    normalized = requested.strip().lower()
    document = _DOCS_LOOKUP.get(normalized)
    if document is not None:
        return document, None
    for candidate in _DOCS_DOCUMENTS:
        if normalized in candidate.replacement_for:
            return None, (
                f"Unknown document '{requested}'.\n"
                f"Use '{candidate.identifier}' instead.\n"
                f"{_render_docs_usage()}"
            )
    return None, f"Unknown document '{requested}'.\n{_render_docs_usage()}"



def _run_docs_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger()
    if not args.document:
        logger.log_to_stderr(_render_docs_usage(), "error")
        return 1
    document, error_message = _resolve_docs_document(args.document)
    if document is None:
        logger.log_to_stderr(error_message or _render_docs_usage(), "error")
        return 1
    try:
        source_path = _resolve_docs_source_path(document)
        contents = _read_docs_source(document)
    except FileNotFoundError as exc:
        logger.log_to_stderr(str(exc), "error")
        return 1
    print(f"SOURCE: {source_path}")
    print()
    print(contents, end="")
    return 0



def _run_validate_command(args: argparse.Namespace) -> int:
    logger = CybervisorLogger()
    paths: list[str] = list(args.paths) if args.paths else ["cybervisor.yaml"]
    failures = 0
    for raw_path in paths:
        display_path = Path(raw_path).resolve()
        try:
            resolved_path, config = validate_config_file(raw_path)
        except FileNotFoundError as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        except StrictValidationError as exc:
            issue_lines = "\n".join(f"  - {format_validation_issue(issue)}" for issue in exc.issues)
            logger.log_to_stderr(f"INVALID {exc.path.resolve()}\n{issue_lines}", "error")
            failures += 1
            continue
        except Exception as exc:
            logger.log_to_stderr(f"INVALID {display_path}\n  - {exc}", "error")
            failures += 1
            continue
        logger.log_to_stderr(f"VALID {resolved_path.resolve()}", "info")
        if args.show_guidance:
            for stage in config.stages:
                if stage.contract is None:
                    continue
                guidance = render_contract_guidance(stage.name, stage.contract).rstrip()
                logger.log_to_stderr(f"GUIDANCE {stage.name}:\n\n{guidance}\n", "info")
    return 0 if failures == 0 else 1


def main(argv: list[str] | None = None) -> int:
    _set_process_title()
    try:
        args = parse_args(argv)
    except SystemExit as exc:
        return int(exc.code) if exc.code else 0

    if args.version:
        print(__version__)
        return 0

    if args.command == "serve":
        return asyncio.run(_run_serve_command(args))
    if args.command == "status":
        return asyncio.run(_run_status_command(args))
    if args.command == "submit":
        logger = CybervisorLogger()
        args.prompt, prompt_source = _resolve_prompt(args)
        if prompt_source is None:
            logger.log_to_stderr("No prompt provided via argument or stdin.", "error")
            return 1
        if prompt_source == "stdin":
            logger.log_to_stderr("Objective source: stdin.", "info")
        else:
            logger.log_to_stderr("Objective source: positional prompt.", "info")
        return asyncio.run(_run_submit_command(args))
    if args.command == "attach":
        return asyncio.run(_run_attach_command(args))
    if args.command == "cancel":
        return asyncio.run(_run_cancel_command(args))
    if args.command == "logs":
        return asyncio.run(_run_logs_command(args))
    if args.command == "stop-stage":
        return asyncio.run(_run_stop_stage_command(args))
    if args.command == "init":
        return run_init(template=args.template, force=args.force)
    if args.command == "doctor":
        return _run_doctor_command(args)
    if args.command == "validate":
        return _run_validate_command(args)
    if args.command == "docs":
        return _run_docs_command(args)
    if args.command == "use":
        return _run_use_command(args)

    if args.command == "run":
        args.prompt, _ = _resolve_prompt(args)
        return _run_pipeline(args)

    return _run_pipeline(args)


if __name__ == "__main__":
    raise SystemExit(main())
