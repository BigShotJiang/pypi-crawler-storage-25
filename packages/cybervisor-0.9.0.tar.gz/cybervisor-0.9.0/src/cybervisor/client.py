from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass
from typing import Any, AsyncIterator

from websockets.asyncio.client import ClientConnection, connect

from cybervisor.global_config import GlobalServerConfig, load_global_config
from cybervisor.server_events import EventType, ServerEvent

CONNECT_TIMEOUT = 5.0


@dataclass(frozen=True, slots=True)
class ClientConfig:
    """Configuration for WebSocket client connections."""

    host: str
    port: int
    connect_timeout_seconds: float = CONNECT_TIMEOUT


def _default_config() -> ClientConfig:
    """Load server config from global config with defaults."""
    try:
        cfg = load_global_config()
        server: GlobalServerConfig = cfg.server
    except Exception:  # pragma: no cover
        server = GlobalServerConfig()
    return ClientConfig(host=server.host, port=server.port)


def _resolve_config(host: str | None, port: int | None) -> ClientConfig:
    """Resolve host/port from CLI args or global config defaults."""
    default = _default_config()
    return ClientConfig(
        host=host if host is not None else default.host,
        port=port if port is not None else default.port,
        connect_timeout_seconds=default.connect_timeout_seconds,
    )


async def _connect(uri: str, timeout: float) -> ClientConnection:
    """Open a WebSocket connection with a timeout."""

    async def _open_with_timeout() -> ClientConnection:
        ws = await connect(uri, open_timeout=timeout, close_timeout=2.0)
        return ws

    try:
        ws = await asyncio.wait_for(_open_with_timeout(), timeout=timeout)
        return ws
    except asyncio.TimeoutError as exc:
        raise ConnectionError(f"Connection timeout ({timeout}s) to {uri}") from exc
    except OSError as exc:
        raise ConnectionError(f"Cannot connect to {uri}: {exc}") from exc


async def _receive_events(ws: ClientConnection) -> AsyncIterator[ServerEvent]:
    """Yield parsed ServerEvent objects from a WebSocket connection."""
    try:
        async for raw in ws:
            try:
                data = json.loads(raw) if isinstance(raw, str) else json.loads(raw.decode("utf-8"))
                yield ServerEvent.from_dict(data)
            except (json.JSONDecodeError, KeyError):
                # Skip malformed messages
                continue
    except asyncio.CancelledError:
        await ws.close()
        raise


# ---------------------------------------------------------------------------
# Event rendering
# ---------------------------------------------------------------------------


def render_event(event: ServerEvent) -> tuple[str, str | None]:
    """
    Render a ServerEvent to a human-readable line.

    Returns:
        A tuple of (level, line) where level is "stdout" or "stderr".
        Returns ("skip", None) for events that should not be rendered.
    """
    evt_type = event.type
    if evt_type == EventType.STAGE_START.value:
        stage = event.stage_name or "?"
        attempt = event.attempt or 1
        max_retries = event.max_retries or 3
        line = f"[STAGE_START]    {stage} — attempt {attempt}/{max_retries}"
        return "stdout", line

    if evt_type == EventType.STAGE_COMPLETE.value:
        stage = event.stage_name or "?"
        success = event.success
        attempt = event.attempt or 1
        status = "success" if success else "failed"
        line = f"[STAGE_COMPLETE] {stage} — {status} (attempt {attempt})"
        return "stdout", line

    if evt_type == EventType.STAGE_RETRY.value:
        stage = event.stage_name or "?"
        attempt = event.attempt or 1
        max_retries = event.max_retries or 3
        error = event.error or "unknown error"
        line = f"[ERROR] {stage} retry {attempt}/{max_retries}: {error}"
        return "stderr", line

    if evt_type == EventType.STAGE_FAILED.value:
        stage = event.stage_name or "?"
        error = event.error or "unknown error"
        line = f"[ERROR] {stage} failed: {error}"
        return "stderr", line

    if evt_type == EventType.ARTIFACT_VALIDATED.value:
        stage = event.stage_name or "?"
        status = event.artifact_status or "?"
        line = f"[ARTIFACT_VALIDATED] {stage} — status: {status}"
        return "stdout", line

    if evt_type == EventType.ROUTING_DECISION.value:
        stage = event.stage_name or "?"
        next_stage = event.next_stage or "?"
        source = event.decision_source or "?"
        line = f"[ROUTING_DECISION] {stage} → {next_stage} ({source})"
        return "stdout", line

    if evt_type == EventType.PIPELINE_ABORT.value:
        reason = event.reason or "unknown reason"
        line = f"[ERROR] Pipeline aborted: {reason}"
        return "stderr", line

    if evt_type == EventType.RUN_COMPLETE.value:
        success = event.success
        line = f"[RUN_COMPLETE] success={str(success).lower()}"
        return "stdout", line

    if evt_type == EventType.RUN_ACCEPTED.value:
        task_id = event.task_id or "?"
        line = f"[RUN_ACCEPTED]   task-id: {task_id}"
        return "stdout", line

    if evt_type == EventType.ERROR.value:
        code = event.code or "?"
        message = event.message or "unknown error"
        line = f"[ERROR] Server error [{code}]: {message}"
        return "stderr", line

    if evt_type == EventType.PONG.value:
        return "skip", None

    if evt_type == EventType.EVENT_REPLAY.value:
        # Internal event — not rendered directly
        return "skip", None

    if evt_type == EventType.EVENT_REPLAY_CHUNK.value:
        # Internal chunk frame — not rendered directly; reassembled by caller
        return "skip", None

    if evt_type == EventType.STOP_STAGE_UPDATED.value:
        stage = event.stage or "?"
        line = f"[STOP_STAGE]    updated stop stage to: {stage}"
        return "stdout", line

    # Default: skip unknown event types
    return "skip", None


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


async def ping_daemon(config: ClientConfig) -> tuple[bool, list[dict[str, Any]]]:
    """Ping the daemon and retrieve active task snapshots.

    Returns (reachable, tasks) where:
    - reachable: True if daemon responded with PONG, False otherwise
    - tasks: list of active task snapshot dicts from the pong, or [] if unreachable
              or if the daemon predates this feature (pong has no tasks field)
    """
    uri = f"ws://{config.host}:{config.port}"
    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, []

    try:
        await ws.send(json.dumps({"type": EventType.PING.value, "task_id": ""}))
        async for event in _receive_events(ws):
            if event.type == EventType.PONG.value:
                # Return reachable=True and the tasks list from the pong.
                # If the daemon predates this feature, event.tasks will be None.
                return True, event.tasks if event.tasks is not None else []
            # Any non-pong event means the ping was not answered — daemon not reachable
            return False, []
        # Stream closed without receiving pong
        return False, []
    except Exception:  # pragma: no cover
        return False, []
    finally:
        await ws.close()


async def run_status_command(host: str | None, port: int | None) -> int:
    """Run the status command.

    Returns 0 if daemon is reachable, 1 otherwise.
    Prints active running tasks (excluding completed/cancelled) with task_id and stage.
    Displays 'initializing' for tasks with active_stage: null.
    """
    config = _resolve_config(host, port)
    reachable, tasks = await ping_daemon(config)
    if not reachable:
        print(f"Daemon not reachable at ws://{config.host}:{config.port}")
        return 1

    # Filter to only running tasks (protocol status value "running")
    running_tasks = [t for t in tasks if t.get("status") == "running"]

    if running_tasks:
        for task in running_tasks:
            active_stage = task.get("active_stage")
            stage_label = active_stage if active_stage is not None else "initializing"
            print(f"Running task: {task.get('task_id')} (stage: {stage_label})")
    else:
        print("No active tasks.")

    print(f"Daemon reachable at ws://{config.host}:{config.port}")
    return 0


# ---------------------------------------------------------------------------
# submit
# ---------------------------------------------------------------------------


async def submit_and_stream(
    prompt: str,
    config: ClientConfig,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
) -> int:
    """
    Submit a task and stream events until completion.

    Returns the pipeline exit code (0 on success, 1 on failure).
    """
    uri = f"ws://{config.host}:{config.port}"
    resolved_task_id = task_id or uuid.uuid4().hex[:12]

    msg: dict[str, Any] = {
        "type": EventType.RUN.value,
        "task_id": resolved_task_id,
        "prompt": prompt,
    }
    if config_path:
        msg["config_path"] = config_path
    if start_stage:
        msg["start_stage"] = start_stage

    reconnect_attempted = False

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        async for event in _receive_events(ws):
            level, line = render_event(event)
            if level == "stdout" and line is not None:
                print(line)
            elif level == "stderr" and line is not None:
                print(line, file=__import__("sys").stderr)
            if event.type == EventType.RUN_COMPLETE.value:
                return 0 if event.success else 1
        # No run_complete received — treat as failure
        return 1

    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        exit_code = await send_and_listen(ws)
        return exit_code
    except Exception as exc:  # pragma: no cover
        # Attempt reconnect on unexpected disconnection
        if not reconnect_attempted:
            reconnect_attempted = True
            try:
                ws = await _connect(uri, config.connect_timeout_seconds)
                exit_code = await send_and_listen(ws)
                return exit_code
            except Exception:  # pragma: no cover
                pass
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_submit_command(
    prompt: str,
    host: str | None,
    port: int | None,
    task_id: str | None = None,
    config_path: str | None = None,
    start_stage: str | None = None,
) -> int:
    """Run the submit command."""
    config = _resolve_config(host, port)
    try:
        return await submit_and_stream(
            prompt=prompt,
            config=config,
            task_id=task_id,
            config_path=config_path,
            start_stage=start_stage,
        )
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# attach
# ---------------------------------------------------------------------------


def _reassemble_events(event: ServerEvent) -> list[ServerEvent]:
    """Reassemble an event_replay ServerEvent into its child ServerEvents."""
    if event.type != EventType.EVENT_REPLAY.value:
        return [event]

    events = event.events
    if not events:
        return []

    return [ServerEvent.from_dict(e) for e in events]


async def attach_and_stream(task_id: str, config: ClientConfig) -> int:
    """
    Reconnect to a task and stream events until completion.

    Returns the pipeline exit code (0 on success, 1 on failure, 130 on SIGINT).
    """
    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    async def send_and_listen(ws: ClientConnection) -> int:
        await ws.send(json.dumps(msg))
        exit_code = 1
        # Buffer for collecting chunked event_replay_chunk frames
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}

        async for event in _receive_events(ws):
            # Handle event_replay_chunk frames: collect all chunks with matching
            # chunk_id, then reassemble once we have all of them.
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data: dict[str, Any] = event.to_dict()
                idx = chunk_data.get("chunk_index", 0)
                chunk_buffer[chunk_id][idx] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    # All chunks received — sort by index and flatten events
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            se = ServerEvent.from_dict(e)
                            level, line = render_event(se)
                            if level == "stdout" and line is not None:
                                print(line)
                            elif level == "stderr" and line is not None:
                                print(line, file=__import__("sys").stderr)
                            if se.type == EventType.RUN_COMPLETE.value:
                                exit_code = 0 if se.success else 1
                    del chunk_buffer[chunk_id]
                continue

            # Handle unchunked event_replay
            if event.type == EventType.EVENT_REPLAY.value:
                reassembled = _reassemble_events(event)
                for e in reassembled:
                    level, line = render_event(e)
                    if level == "stdout" and line is not None:
                        print(line)
                    elif level == "stderr" and line is not None:
                        print(line, file=__import__("sys").stderr)
                    if e.type == EventType.RUN_COMPLETE.value:
                        exit_code = 0 if e.success else 1
                continue

            level, line = render_event(event)
            if level == "stdout" and line is not None:
                print(line)
            elif level == "stderr" and line is not None:
                print(line, file=__import__("sys").stderr)
            if event.type == EventType.RUN_COMPLETE.value:
                return 0 if event.success else 1
        return exit_code

    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        return await send_and_listen(ws)
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_attach_command(task_id: str, host: str | None, port: int | None) -> int:
    """Run the attach command."""
    config = _resolve_config(host, port)
    try:
        return await attach_and_stream(task_id=task_id, config=config)
    except asyncio.CancelledError:
        return 130


# ---------------------------------------------------------------------------
# cancel
# ---------------------------------------------------------------------------


async def cancel_task(task_id: str, config: ClientConfig) -> tuple[bool, str]:
    """
    Cancel an active task.

    Returns (success, message) where success indicates whether cancellation
    was acknowledged by the daemon.
    """
    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.CANCEL.value,
        "task_id": task_id,
    }

    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in _receive_events(ws):
            if event.type == EventType.PIPELINE_ABORT.value:
                return True, "Task cancelled"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_cancel_command(task_id: str, host: str | None, port: int | None) -> int:
    """Run the cancel command."""
    config = _resolve_config(host, port)
    success, message = await cancel_task(task_id, config)
    if success:
        print(message)
        return 0
    print(message, file=__import__("sys").stderr)
    return 1


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------


async def dump_task_logs(task_id: str, config: ClientConfig) -> int:
    """
    Dump all buffered events for a task as JSON Lines.

    Returns 0 on success, 1 on failure.
    """
    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.RESUME.value,
        "task_id": task_id,
    }

    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        print(f"daemon not reachable at ws://{config.host}:{config.port}", file=__import__("sys").stderr)
        return 1

    try:
        await ws.send(json.dumps(msg))
        # Buffer for collecting chunked event_replay_chunk frames
        chunk_buffer: dict[str, dict[int, dict[str, Any]]] = {}
        async for event in _receive_events(ws):
            if event.type == EventType.EVENT_REPLAY_CHUNK.value:
                chunk_id = event.chunk_id or ""
                if not chunk_id:
                    continue
                if chunk_id not in chunk_buffer:
                    chunk_buffer[chunk_id] = {}
                chunk_data = event.to_dict()
                chunk_buffer[chunk_id][chunk_data.get("chunk_index", 0)] = chunk_data
                chunk_count = chunk_data.get("chunk_count", 1)
                if len(chunk_buffer[chunk_id]) == chunk_count:
                    sorted_chunks = sorted(chunk_buffer[chunk_id].items(), key=lambda x: x[0])
                    for _, chunk in sorted_chunks:
                        for e in chunk.get("events", []):
                            print(json.dumps(e))
                    del chunk_buffer[chunk_id]
                continue
            # Handle unchunked event_replay
            if event.type == EventType.EVENT_REPLAY.value and event.events:
                for e in event.events:
                    print(json.dumps(e))
        return 0
    except Exception as exc:  # pragma: no cover
        print(f"Connection error: {exc}", file=__import__("sys").stderr)
        return 1
    finally:
        await ws.close()


async def run_logs_command(task_id: str, host: str | None, port: int | None) -> int:
    """Run the logs command."""
    config = _resolve_config(host, port)
    return await dump_task_logs(task_id, config)


# ---------------------------------------------------------------------------
# stop-stage
# ---------------------------------------------------------------------------


async def update_stop_stage(task_id: str, stage: str, config: ClientConfig) -> tuple[bool, str]:
    """
    Update the stop stage of a running task.

    Returns (success, message).
    """
    uri = f"ws://{config.host}:{config.port}"

    msg: dict[str, Any] = {
        "type": EventType.SET_STOP_STAGE.value,
        "task_id": task_id,
        "stage": stage,
    }

    try:
        ws = await _connect(uri, config.connect_timeout_seconds)
    except ConnectionError:
        return False, f"daemon not reachable at ws://{config.host}:{config.port}"

    try:
        await ws.send(json.dumps(msg))
        async for event in _receive_events(ws):
            if event.type == EventType.STOP_STAGE_UPDATED.value:
                return True, f"Updated stop stage to: {event.stage}"
            if event.type == EventType.ERROR.value:
                code = event.code or "?"
                message = event.message or "unknown error"
                return False, f"[{code}] {message}"
        return False, "No response from daemon"
    except Exception as exc:  # pragma: no cover
        return False, f"Connection error: {exc}"
    finally:
        await ws.close()


async def run_stop_stage_command(
    task_id: str,
    stage: str,
    host: str | None,
    port: int | None,
) -> int:
    """Run the stop-stage command."""
    config = _resolve_config(host, port)
    success, message = await update_stop_stage(task_id, stage, config)
    if success:
        print(message)
        return 0
    print(message, file=__import__("sys").stderr)
    return 1
