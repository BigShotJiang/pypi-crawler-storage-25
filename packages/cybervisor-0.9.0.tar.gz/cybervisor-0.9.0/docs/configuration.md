# Configuration Reference

`cybervisor` is configured with a `cybervisor.yaml` file. The global agent and verifier settings reside in `~/.cybervisor/config.yaml`.

## Global Configuration (`~/.cybervisor/config.yaml`)

Manage the default agent with `cybervisor use <agent>`. Supported: `claude`, `gemini`, `mock`, `codex`.

```yaml
agent_tool: gemini
llm:
  api_key: your-api-key
  base_url: https://api.openai.com/v1 # Optional
  model: gpt-4o                     # Optional
server:
  host: 127.0.0.1        # Interface to bind; use 0.0.0.0 to expose externally
  port: 8765            # WebSocket port for daemon mode
  reconnect_ttl_seconds: 300.0   # How long completed/disconnected tasks are retained for resume
  max_event_buffer: 1000        # Maximum events buffered per task for replay
```

### Server Settings

The `server` block controls the `cybervisor serve` daemon:

| Setting | Default | Purpose |
|---------|---------|---------|
| `host` | `127.0.0.1` | Network interface to bind; `0.0.0.0` exposes on all interfaces |
| `port` | `8765` | WebSocket port for daemon connections |
| `reconnect_ttl_seconds` | `300.0` | Seconds a task is kept after the last activity before cleanup; also bounds how long a disconnected client can `resume` |
| `max_event_buffer` | `1000` | Maximum server events stored per task for `resume` replay; oldest events are evicted FIFO when the cap is hit |

Override on the command line: `cybervisor serve --host 0.0.0.0 --port 9000`.

### Codex Notes
- Requires the `codex` CLI on `PATH`.
- Blocked-start guidance: `Codex requires the codex CLI on PATH. Install it and verify with codex --version.`

## Scaffolding (`cybervisor init`)

Initialize a project scaffold. Overwrite protection is active by default.

- `cybervisor init`: Creates a `simple` 6-stage pipeline with `Design Delivery -> Review Delivery Docs -> Implement -> Review Code -> Review Docs -> Verify`.
- `cybervisor init --template speckit`: Creates a `speckit`-integrated pipeline.
- `--force`: Required to explicitly replace an existing `cybervisor.yaml`.

## Running the Pipeline (`cybervisor run`)

The positional `prompt` argument (or `stdin`) provides the `{objective}` for stage templates.

```bash
cybervisor run "Implement feature X"
cybervisor run --config custom.yaml        # Use specific config
cybervisor run --start-stage "Implement"   # Resume from stage
cybervisor run --end-before "Verify"       # Stop early
```

### Self-Contained Config Flow Example
If all active stages define an explicit `prompt_template`, the positional prompt may be omitted:

```bash
# Using stage templates
cybervisor run --config self-contained.yaml

# Overriding with stdin
printf 'hotfix retry handling\n' | cybervisor run --config self-contained.yaml

# Overriding with positional prompt
cybervisor run "ship the retry fix" --config self-contained.yaml
```

## Diagnostics & Validation

### `cybervisor doctor` (Verifier Readiness)
Validates `~/.cybervisor/config.yaml` connectivity and credentials.

- `Doctor: verifier ready` — Success.
- `Doctor: verifier blocked` — Local configuration error (e.g., missing API key).
- `Doctor: verifier needs attention` — Remote rejection (e.g., 401 Unauthorized).

### `cybervisor validate` (Config Safety)
Checks `cybervisor.yaml` for route safety and prompt synchronization.
- Use `--show-guidance` to preview the exact contract instructions generated for the agent.

## Stage Configuration

### Self-Refining Review Loop Example
This pattern enables autonomous correction loops without a separate fix stage.

```yaml
stages:
  - name: Implement

  - name: Review Code
    prompt_template: |
      Review the implementation and edit the code directly when focused fixes are needed.
      Do not route APPROVED if this run edited any code or tests.
      Route APPROVED only when the code is ready for verification and this run made no code or test edits.
      Route CHANGES_MADE when this review run changed the code and another review pass is required.
      Write the final result to .cybervisor/contracts/artifacts/Review Code.yaml.
    contract:
      fields:
        Findings:
          description: Key issues found during the review.
          example: |
            - Retry coverage does not assert the exhausted-attempts path.
        Required Changes:
          description: Concrete fixes required before approval.
          example: |
            - Add a regression test for the exhausted retry path.
      routes:
        APPROVED:
          description: The implementation passed review and move to verification.
          next_stage: Verify
        CHANGES_MADE:
          description: This review run applied focused fixes, so the updated implementation must be reviewed again.
          next_stage: Review Code

  - name: Verify
```

**Contract Rules:**
- **No Top-Level Next:** Contract stages MUST use `contract.routes` for branching.
- **Status Match:** Route keys MUST appear in the emitted YAML `Status` field.
- **Injections:** Injected fields MUST have a defined `example` in `contract.fields`.

### Stage Field: `keep_artifacts`

Declare `keep_artifacts: [list, of, paths]` on any stage to block it if the named artifacts are missing at hook invocation. The hook checks `Path.exists()` for each path before allowing the stage to complete. Missing files produce a `block` decision with a remediation message directing the agent to recreate them.

See the full reference in [Pipeline Authoring Guide](cybervisor-pipeline-authoring-guide.md#keep_artifacts) for path rules, deduplication, daemon-mode behavior, and failure-before-teardown isolation.
