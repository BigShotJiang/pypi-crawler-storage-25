"""Factory for constructing the production SearchPipeline.

Called once at startup. Resolves configuration, builds all protocol
implementations, and composes them into a SearchPipeline instance.

Tests construct SearchPipeline directly with fakes — this factory is
only for production wiring.

Process-lifetime memoisation: ``build_search_pipeline()`` caches its
result keyed by the resolved retrieval-config identity, so repeat calls
within the same process return instantly. Each rebuild costs ~2.3s +
~120 MB; memoising drops the second call to <1ms (#279).

Tests that need fresh state call ``reset_search_pipeline_cache()`` to clear
the cache between cases.
"""

from __future__ import annotations

import logging
import threading
from typing import TYPE_CHECKING, Any

from kairix.core.search.config import RetrievalConfig
from kairix.core.search.pipeline import SearchPipeline
from kairix.core.search.query_cache import (
    DEFAULT_MAX_AGE_S,
    DEFAULT_MAX_ENTRIES,
    QueryResultCache,
)

if TYPE_CHECKING:
    from kairix.providers import ProviderRegistry

logger = logging.getLogger(__name__)


# Process-lifetime cache for build_search_pipeline. Key: the resolved
# RetrievalConfig (frozen dataclass → hashable by field values), so
# distinct callers passing equal config values share one pipeline.
_PIPELINE_CACHE: dict[RetrievalConfig, SearchPipeline] = {}


# Process-shared QueryResultCache (#281). One instance per process,
# wired into every SearchPipeline constructed by build_search_pipeline.
# Lazy-initialised so the env-var bounds are read once at first use.
_QUERY_CACHE: QueryResultCache | None = None
_QUERY_CACHE_LOCK = threading.Lock()


def reset_search_pipeline_cache() -> None:
    """Clear the memoised pipeline cache. Tests use this between cases.

    Also clears the process-shared query cache so cached results from a
    previous fixture-built pipeline don't bleed across tests.
    """
    _PIPELINE_CACHE.clear()
    with _QUERY_CACHE_LOCK:
        if _QUERY_CACHE is not None:
            _QUERY_CACHE.clear()


def _get_or_create_query_cache() -> QueryResultCache:
    """Return the process-shared :class:`QueryResultCache`, building it lazily.

    Bounds are read from env vars on first construction (#281):
      - ``KAIRIX_QUERY_CACHE_MAX_ENTRIES`` (int, default 500)
      - ``KAIRIX_QUERY_CACHE_MAX_AGE_S`` (float seconds, default 300)

    F4-clean: env reads route through :mod:`kairix.paths`.
    """
    global _QUERY_CACHE
    with _QUERY_CACHE_LOCK:
        if _QUERY_CACHE is None:
            from kairix.paths import read_float_env, read_int_env

            max_entries = read_int_env("KAIRIX_QUERY_CACHE_MAX_ENTRIES", default=DEFAULT_MAX_ENTRIES)
            max_age_s = read_float_env("KAIRIX_QUERY_CACHE_MAX_AGE_S", default=DEFAULT_MAX_AGE_S)
            _QUERY_CACHE = QueryResultCache(max_entries=max_entries, max_age_s=max_age_s)
        return _QUERY_CACHE


def get_query_cache() -> QueryResultCache:
    """Return the process-shared query cache (lazily built on first call).

    Public accessor for the onboard check + any other diagnostic that
    wants to read :meth:`QueryResultCache.stats`. Going through this
    helper keeps the module-global hidden so callers can't accidentally
    rebind ``_QUERY_CACHE``.
    """
    return _get_or_create_query_cache()


def select_boosts(cfg: RetrievalConfig, graph: Any) -> list[Any]:
    """Build the production boost chain from a RetrievalConfig.

    Public helper so tests can pin which boosts the production pipeline
    actually wires for a given config — without spinning up Azure/Neo4j/SQLite.
    Each boost adapter is intent-gated internally (see kairix.core.search.boosts);
    this function only decides which adapters are *registered*, not when they
    fire.

    Args:
        cfg:   ``RetrievalConfig``. Each ``*_enabled`` flag opts the matching
               adapter into the chain.
        graph: ``GraphRepository`` for ``EntityBoost``. Other boosts ignore it.

    Returns:
        List of boost-strategy instances in registration order:
        EntityBoost → ProceduralBoost → TemporalDateBoost → ChunkDateBoost.
    """
    from kairix.core.search.boosts import (
        ChunkDateBoost,
        EntityBoost,
        ProceduralBoost,
        TemporalDateBoost,
    )

    boosts: list[Any] = []
    if cfg.entity.enabled:
        boosts.append(EntityBoost(graph=graph, config=cfg.entity))
    if cfg.procedural.enabled:
        boosts.append(ProceduralBoost(config=cfg.procedural))
    if cfg.temporal.date_path_boost_enabled:
        boosts.append(TemporalDateBoost(config=cfg.temporal))
    if cfg.temporal.chunk_date_boost_enabled:
        boosts.append(ChunkDateBoost(config=cfg.temporal))
    return boosts


def _resolve_retrieval_config(config: RetrievalConfig | None) -> RetrievalConfig:
    """Pick the explicit config or fall back to ``load_config`` (which itself
    falls back to ``RetrievalConfig.defaults()`` when no YAML is present).
    """
    if config is not None:
        return config
    from kairix.core.search.config_loader import load_config

    return load_config()


class _NullVectorRepository:
    """No-op VectorRepository fallback for degraded deployments.

    Production fallback when the usearch index is missing or fails to load.
    Returns empty result sets so the rest of the SearchPipeline can continue
    in BM25-only mode. Defined inline (not in ``tests/fakes.py``) because
    production code must never import from ``tests/`` — the directory is
    not shipped in the installable wheel.
    """

    def search(
        self,
        query_vec: list[float],
        k: int,
        collections: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        # Reference args so F19 (unused-params-named) sees them as used.
        # Names are fixed by the production caller (backends.py:94 uses
        # ``k=`` and ``collections=`` keyword arguments).
        _ = (query_vec, k, collections)
        return []

    def add_vectors(self, items: list[tuple[str, list[float]]]) -> int:
        _ = items
        return 0

    def count(self) -> int:
        return 0


class _NullGraphRepository:
    """No-op GraphRepository fallback for degraded deployments.

    Production fallback when Neo4j is unreachable or its driver fails.
    Reports ``available=False`` so entity-boost callers route around it.
    Defined inline for the same reason as :class:`_NullVectorRepository`.
    """

    @property
    def available(self) -> bool:
        return False

    def find_entity(self, name: str) -> dict[str, Any] | None:
        _ = name
        return None

    def entity_in_degrees(self) -> list[dict[str, Any]]:
        return []

    def cypher(self, query: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        _ = (query, params)
        return []


def _build_vector_repo() -> Any:
    """Construct the usearch vector repo, falling back to a null repo on failure."""
    from kairix.core.search.vector_repository import UsearchVectorRepository

    try:
        from kairix.core.search.vec_index import get_vector_index

        index = get_vector_index()
        if index is not None:
            return UsearchVectorRepository(index=index)
        logger.warning("factory: usearch index not available — vector search disabled")
    except Exception as e:
        logger.warning("factory: failed to load vector index — %s", e)
    return _NullVectorRepository()


def _build_graph() -> Any:
    """Construct the Neo4j graph repo, falling back to a null repo on failure."""
    try:
        from kairix.knowledge.graph.client import get_client
        from kairix.knowledge.graph.repository import Neo4jGraphRepository

        return Neo4jGraphRepository(client=get_client())
    except Exception as e:
        logger.warning("factory: Neo4j unavailable — %s", e)
        return _NullGraphRepository()


def _build_fusion(cfg: RetrievalConfig) -> Any:
    """Pick the fusion strategy by config name."""
    from kairix.core.search.fusion import BM25PrimaryFusion, RRFFusion

    if cfg.fusion_strategy == "rrf":
        return RRFFusion(k=cfg.rrf_k)
    return BM25PrimaryFusion()


def _build_search_logger() -> Any:
    """Construct the JSONL search logger, honouring docker-vs-host log paths.

    Path resolution lives at the boundary so business logic never reads env vars
    (G4). Query log is privacy-gated via KAIRIX_LOG_QUERIES (off by default).
    Env reads route through kairix.paths (F4).
    """
    from pathlib import Path

    from kairix.core.search.logger import JsonlSearchLogger, default_search_log_paths
    from kairix.paths import is_docker_env, log_queries_enabled

    log_base = Path("/data/kairix/logs") if is_docker_env() else Path.home() / ".cache" / "kairix" / "logs"
    search_log_path, query_log_path = default_search_log_paths(base=log_base)
    enable_query_log = log_queries_enabled()
    return JsonlSearchLogger(
        search_log_path=search_log_path,
        query_log_path=query_log_path if enable_query_log else None,
    )


def _build_collection_resolver() -> Any:
    """Construct the DefaultCollectionResolver from the on-disk YAML config.

    KAIRIX_EXTRA_COLLECTIONS is still honoured for ad-hoc deployments without
    a full config file.
    """
    from kairix.core.search.config_loader import load_collections, resolve_config_path
    from kairix.core.search.registry import parse_agent_registry
    from kairix.core.search.resolver import DefaultCollectionResolver
    from kairix.paths import extra_collections as _extra_collections

    collections_config = None
    try:
        collections_config = load_collections()
    except Exception as e:
        logger.warning("factory: load_collections failed — %s", e)

    agent_registry = None
    config_path = resolve_config_path()
    if config_path is not None:
        try:
            import yaml

            with config_path.open(encoding="utf-8") as f:
                raw_yaml = yaml.safe_load(f) or {}
            pattern = collections_config.agent_pattern if collections_config else "{agent}-memory"
            agent_registry = parse_agent_registry(raw_yaml, default_pattern=pattern)
        except Exception as e:
            logger.warning("factory: parse_agent_registry failed — %s", e)

    return DefaultCollectionResolver(
        collections_config=collections_config,
        extra_collections=_extra_collections(),
        agent_registry=agent_registry,
    )


def _resolve_provider_name(cfg: RetrievalConfig) -> str | None:
    """Return the configured provider plugin name or ``None``.

    Resolution order:

      1. ``cfg.provider`` — the value threaded through ``RetrievalConfig``
         (SWAP v2 added this field; ``load_config`` parses ``provider:``
         from ``kairix.config.yaml`` into it).
      2. :func:`kairix.paths.provider_name` fallback — re-reads the YAML
         directly. Covers ad-hoc test paths that construct
         ``RetrievalConfig`` instances by hand without going through
         ``load_config`` (so ``cfg.provider`` is ``None``) but still
         have a ``kairix.config.yaml`` on disk that names a plugin.
      3. ``None`` — no provider configured. The caller raises a typed
         ``ValueError`` so operators see a misconfiguration immediately
         rather than silently degrading to a legacy code path.
    """
    if cfg.provider:
        return cfg.provider
    from kairix.paths import provider_name

    return provider_name()


def _build_embedding_service(
    cfg: RetrievalConfig,
    registry: ProviderRegistry | None = None,
) -> Any:
    """Construct the production ``EmbeddingService`` for the pipeline.

    Plugin-driven path (v2026.5.17 onward): resolves the configured
    provider via :func:`kairix.providers.get_provider` and wraps the
    plugin in
    :class:`kairix.transport.embed_service.ProviderEmbeddingService` —
    the Protocol-shaped adapter that owns the cache + coalescer
    routing.

    When no provider is configured (no ``provider:`` in YAML, no
    ``cfg.provider``), raises a typed ``ValueError`` listing the
    installed plugins. Operators see the misconfiguration at
    pipeline-build time rather than discovering an inert embed surface
    at query time.

    F26 carve-out: this is the one core/ file allowed to import
    ``kairix.transport.embed_service`` and ``kairix.providers``. The
    factory is the wiring point named in
    ``docs/architecture/provider-plugin-architecture.md``; the
    domain Protocols still live in ``kairix.core.protocols``.
    See ``.architecture/baseline/f26-files.txt`` for the grandfathered
    entry covering this file.

    Args:
        cfg:       resolved ``RetrievalConfig`` carrying the
                   configured provider name (if any).
        registry:  optional ``ProviderRegistry`` for tests; production
                   resolves via the default ``EntryPointRegistry``.

    Returns:
        An object satisfying the ``EmbeddingService`` Protocol.
    """
    from kairix.providers import EntryPointRegistry, get_provider
    from kairix.transport.embed_service import ProviderEmbeddingService

    name = _resolve_provider_name(cfg)
    if name is None:
        available_registry = registry if registry is not None else EntryPointRegistry()
        try:
            available = sorted(available_registry.available())
        except Exception:  # pragma: no cover - registry pathologies surface via the message below
            available = []
        installed = ", ".join(available) if available else "<none>"
        raise ValueError(
            "kairix.config.yaml is missing the required 'provider:' field. "
            "fix: add 'provider: <name>' to kairix.config.yaml. "
            "run: kairix probe-config to see installed plugins. "
            f"installed plugins: {installed}."
        )

    provider = get_provider(name, registry=registry)
    return ProviderEmbeddingService(provider)


def build_search_pipeline(
    config: RetrievalConfig | None = None,
    *,
    registry: ProviderRegistry | None = None,
    fact_retriever: Any = None,
) -> SearchPipeline:
    """Construct the production search pipeline.

    Memoised per-config for the process lifetime. The first call pays the
    factory cost (~2.3s, ~120 MB); subsequent calls with the same config
    *value* return the cached instance instantly. Tests that need fresh state
    call ``reset_search_pipeline_cache()``.

    Cache key is the resolved RetrievalConfig itself (frozen dataclass →
    hashable by field values), not Python object identity. Two callers
    passing freshly-constructed RetrievalConfig instances with the same
    field values share one cached pipeline — the case the benchmark path
    hits when ``_retrieve_hybrid`` constructs a new config object per case.

    Resolves all dependencies from the environment (DB paths, configured
    provider plugin, Neo4j connection, usearch index). Each dependency is
    imported lazily to avoid hard dependency at module load.

    Args:
        config:    Explicit retrieval config. When ``None``, the factory
                   loads the top-level ``retrieval:`` section from
                   ``kairix.config.yaml`` via :func:`load_config`. If no
                   YAML is present, falls back to
                   ``RetrievalConfig.defaults()``.
        registry:  Optional ``ProviderRegistry`` for tests — pass a
                   ``FakeProviderRegistry`` from ``tests/fakes.py`` to
                   resolve plugin names against an in-memory mapping.
                   Production passes ``None``; the default
                   ``EntryPointRegistry`` is constructed inside
                   :func:`kairix.providers.get_provider`.
        fact_retriever:
                   Optional :class:`kairix.core.protocols.FactStore` for
                   Plan B-parity Capability #5 federation. When ``None``
                   the pipeline runs today's chunk-only behaviour
                   (regression-pinned). Callers wiring the fact layer
                   (ingest-chat → SQLiteFactStore) pass the same store
                   instance here so the SearchPipeline can federate
                   retrieval across chunks + facts.

    Returns:
        A fully wired SearchPipeline ready for search() calls.
    """
    cfg = _resolve_retrieval_config(config)

    # Cache key is the resolved config value (frozen dataclass → hashable by
    # field values). Critical that the key is the RESOLVED config, not the
    # raw arg: when config=None is passed, every call resolves to the same
    # default config object, so the cache hits.
    #
    # Memoisation is keyed on the config alone (not the registry): the
    # registry is a test seam, and within a single test the same registry
    # is reused. Tests that need a fresh build with a different registry
    # call ``reset_search_pipeline_cache()`` between cases.
    cached = _PIPELINE_CACHE.get(cfg)
    if cached is not None:
        return cached

    from kairix.core.search.intent import classify as _classify_fn

    class _RuleClassifier:
        def classify(self, query: str) -> Any:
            return _classify_fn(query)

    from kairix.core.db import get_db_path
    from kairix.core.db.repository import SQLiteDocumentRepository
    from kairix.core.search.backends import (
        BM25SearchBackend,
        VectorSearchBackend,
    )

    doc_repo = SQLiteDocumentRepository(db_path=get_db_path())
    bm25 = BM25SearchBackend(doc_repo)
    embed_service = _build_embedding_service(cfg, registry=registry)
    vector = VectorSearchBackend(embed_service, _build_vector_repo())
    graph = _build_graph()

    # Auto-wire the fact retriever when the operator's data dir contains a
    # facts table. The SQLiteFactStore uses the same SQLite database file as
    # the chunk store; if the operator has called ``kairix ingest-chat``,
    # the table exists and federation activates automatically. Vault-only
    # operators have no facts table → fact_retriever stays None → today's
    # chunk-only behaviour preserved. Explicit ``fact_retriever=`` kwarg
    # still wins (tests + future config-driven opt-in).
    resolved_fact_retriever = fact_retriever
    if resolved_fact_retriever is None:
        try:
            import sqlite3 as _sqlite3

            from kairix.core.facts.store import SQLiteFactStore

            db_path = get_db_path()
            if db_path.exists():
                with _sqlite3.connect(str(db_path)) as conn:
                    has_facts = bool(
                        conn.execute(
                            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='facts' LIMIT 1"
                        ).fetchone()
                    )
                if has_facts:
                    resolved_fact_retriever = SQLiteFactStore(db_path=db_path)
        except Exception:  # noqa: S110 — auto-wire is best-effort; absence falls back to chunk-only
            pass

    pipeline = SearchPipeline(
        classifier=_RuleClassifier(),
        bm25=bm25,
        vector=vector,
        graph=graph,
        fusion=_build_fusion(cfg),
        boosts=select_boosts(cfg, graph),
        logger=_build_search_logger(),
        resolver=_build_collection_resolver(),
        config=cfg,
        # #281 — wire the process-shared LRU so repeat queries from
        # teaming agents skip the Azure embed roundtrip.
        query_cache=_get_or_create_query_cache(),
        # Plan B-parity Capability #5 — opt-in fact federation. ``None``
        # preserves today's chunk-only behaviour for vault-only deployments.
        # Auto-wired above when the operator's data dir contains a facts table.
        fact_retriever=resolved_fact_retriever,
    )
    _PIPELINE_CACHE[cfg] = pipeline
    return pipeline
