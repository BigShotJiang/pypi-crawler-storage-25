"""DAI server routes package."""
