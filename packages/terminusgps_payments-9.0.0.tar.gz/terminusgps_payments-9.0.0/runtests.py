#!/usr/bin/env python
import os
import sys

import django
from django.conf import settings
from django.test.utils import get_runner


def main() -> None:
    os.environ["DJANGO_SETTINGS_MODULE"] = "src.settings"
    django.setup()
    TestRunner = get_runner(settings)
    test_runner = TestRunner()
    failures = test_runner.run_tests(["tests/terminusgps_payments/test_*.py"])
    sys.exit(bool(failures))


if __name__ == "__main__":
    main()
