# سجل التغييرات — WIDDX CLI

## [1.18.5] - 2026-05-24

### UI Polish
- Redesigned boot screen — centered logo with version number, clean keyboard hints with `│` separators

## [1.18.4] - 2026-05-24

### UI Modernization
- Task start now uses user bubble with timestamp (`YOU 14:30` + Panel)
- Result footer uses `╼ tokens · time · tools ╼` line
- Setup screen condensed into a clean Panel

## [1.18.3] - 2026-05-24

### Hotfix
- Fixed `ModuleNotFoundError: No module named 'widdx.repl.prompts'` in chat mode — changed relative import to absolute

## [1.18.2] - 2026-05-24

### Enriched Persona + Safety Rules
- Vibe prompt: added no-auto-commit rule, no-tests-unless-asked rule, no-flattery rule, package manager guidance, recovery-from-circles rule
- Spec prompt: added detailed task format (sub-bullets, requirement refs), no-implementation-during-planning rule
- Auto-commit disabled by default — user must opt-in via config
- ToolLoop: respects mode parameter to switch between Vibe/Spec prompts

## [1.18.1] - 2026-05-24

### Hotfix
- Fixed `MarkupError` in `elite_boot` — `muted="[/][dim]"` variable produced invalid Rich markup, causing crash on startup

## [1.18.0] - 2026-05-24

### Major — Intent-Aware Architecture
- **Mode Classifier** (`widdx/classifier.py`) — classifies every user input as `chat`, `do`, or `spec` mode
- **Vibe Persona** (`widdx/prompts/vibe.py`) — friendly developer tone, talks like a human, concise and warm
- **Spec Workflow** (`widdx/prompts/spec.py` + `widdx/spec_workflow/`) — structured Requirements → Design → Tasks → Execute cycle
  - Stores specs in `.widdx/specs/{feature_name}/`
  - `/spec` command: list specs or start a new one
- **/spec command** — list existing specs, start new feature planning
- **ToolLoop** now accepts `mode` parameter — uses Vibe prompt for `do` mode, Spec prompt for `spec` mode
- **Chat mode** — greetings and chat are handled directly without tool loop overhead
- **System prompt** — no longer "do exactly what you're told" — now encourages understanding intent first

## [1.17.0] - 2026-05-24

### UI Overhaul — Unified Modern Design
- Unified `WIDDX_THEME` and `ELITE` themes into a single modern professional palette (electric blue, teal, purple)
- Removed dual Console instances — single shared Console across the entire app
- Cleaner boot screen — minimal text logo, no ASCII box art overload
- Modernized REPL setup — less verbose, structured status display
- Cleaner prompt toolbar — minimal, key info only
- Professional tool execution display — cleaner icons and diff output
- Pipeline screen uses rich `Panel` instead of ASCII boxes

## [1.16.4] - 2026-05-24

### Hotfix
- Fixed `IndentationError` in `widdx/router/__init__.py` — `import re` inside `try` block was not indented, causing crash on `widdx` command after v1.16.3 upgrade

## [1.15.0] - 2026-05-23

### Major Changes
- Pipeline only activates for explicitly complex tasks (complexity>=4 + specific keywords)
- Simple tasks (create, fix, edit) go directly to ToolLoop — no multi-agent overhead
- Agent Guardrails: each agent must follow the plan, no redesigning or adding features
- Domain Skills Injection: each agent receives relevant skill documents (api-design, database-design, etc.)
- .env file support: project-level API keys via .env file (pure Python, no dependencies)
- Startup UX: removed confusing provider boot screen, added clear API key warning
- Rate limit handling: reduced wait time from 9s to 2s, helpful /key instructions

## [1.14.6] - 2026-05-23

### Semantic Search
- Pure Python semantic search using SQLite+numpy
- Removed chromadb dependency — no C++ compiler needed on Windows
- RAG is now truly built-in and works on all platforms without extra build tools

## [1.14.3] - 2026-05-23

### Code Quality
- Fixed 59 critical lint bugs (F821, F841, F401, E741, whitespace)
- 0 F/E errors — only cosmetic F541 f-strings remain

## [1.14.2] - 2026-05-23

### Hotfixes
- Fixed F821 undefined name in cli.py elite boot
- Fixed OpenAI SDK crash with empty API key

## [1.14.1] - 2026-05-23

### Hotfix
- Fixed OpenAI SDK crash with empty API key

## [1.14.0] - 2026-05-23

### Elite Terminal UI
- New professional design system in `widdx/ui/elite.py` — modern, dark, minimal
- Refined color palette: soft blues, greens, and grays (no neon overload)
- Elegant animated boot screen with centered logo
- Clean chat display with role indicators (You · AI)
- Professional tool call display with colored icons
- Unified status bar, spinner, panels, tables

## [1.13.7] - 2026-05-23

### Code Quality
- Resolved all 12 remaining lint issues (E402, F541, E128, E306)
- Fixed conditional imports placement in cli.py
- Fixed f-strings without placeholders in web/__init__.py

## [1.13.6] - 2026-05-23

### Dynamic Free Model Discovery
- Dynamic free model discovery from OpenCode Zen API
- Automatically fetches available FREE models at startup via `/_models/free` endpoint
- Falls back to hardcoded list when API is unavailable
- Continues to work offline with built-in model registry

### Previous Fix (v1.13.5)
- Fixed: OpenCode Zen requires real API key from opencode.ai/auth (not "public")
- Rate limits explained: free tier ~20-30 requests without key, unlimited with key

## [1.13.5] - 2026-05-23

### OpenCode Integration Fix
- Fixed: OpenCode Zen requires real API key from opencode.ai/auth (not "public")
- Rate limits explained: free tier ~20-30 requests without key, unlimited with key
- Clear guidance: get free API key at https://opencode.ai/auth and set via OPENCODE_API_KEY env var
- OPENCODE_API_KEY now also read from ~/.widdx/config.yaml (opencode_key field)

## [1.13.4] - 2026-05-23

### Router Reliability
- Automatic retry on rate limits (429) with exponential backoff (3s, 6s)
- Retry on server errors (500, 502, 503, overloaded)
- Better error messages: tells user to wait 60s or add API key when free models are rate-limited

## [1.13.3] - 2026-05-23

### Code Quality
- Fixed 38 lint issues across cli.py and web/__init__.py
- Removed 11 unused imports, 11 f-strings without placeholders, 3 unused variables
- Shortened 17 lines exceeding 120 characters
- Fixed 15 whitespace issues and 1 bad variable name

## [1.13.2] - 2026-05-23

### Web Security Hardening
- **Security Headers**: 7 headers added (X-Content-Type-Options, X-Frame-Options, X-XSS-Protection, Referrer-Policy, Permissions-Policy, CSP, Cache-Control)
- **Auth Coverage**: `/api/config/status` now requires authentication (was missing)
- **Audit Logging**: security events (auth failures, rate limit hits) logged via `widdx.web.security`

## [1.13.1] - 2026-05-23

### Security Fixes (P0)
- **Web API Path Traversal**: resolved paths with `.resolve()` before security checks on all 5 file endpoints
- **Auto-commit**: `include_all=False` (only tracked files) + user confirmation prompt before first commit
- **MCP Permission Bypass**: centralized MCP tool classification in PermissionManager with whitelist/destructive pattern sets
- **AgentFactory API Compat**: restored `execute_agent()` as deprecated compatibility wrapper

### Infrastructure Fixes
- MCP shutdown on REPL exit — no more orphaned stdio processes
- security_check.py and lint_check.py now accept both HookManager format and legacy format
- MCPHTTPClient uses dynamic `__import__("widdx").__version__`
- Node modules filter active in semantic index
- /self-check added to /help
- GitHub Actions replaced with local `run_tests.sh`

## [1.13.0] - 2026-05-23

### Semantic Search (RAG)
- Added local semantic code search using sentence-transformers + ChromaDB
- Zero API cost — all embeddings computed locally (80MB model)
- Auto-indexes project files on first `/index`, injects top 6 relevant chunks into ToolLoop system prompt
- Smart chunking: splits by function/class boundaries, falls back to fixed-size overlapping chunks
- Skips noise directories (node_modules, .git, __pycache__, venv, .venv)
- New module: `widdx/semantic_index.py` (350 lines)
- ChromaDB + sentence-transformers are core dependencies (not optional)

### Security Fixes (P0)
- **Web API Path Traversal**: resolved paths with `.resolve()` before security checks on all 5 file endpoints
- **Auto-commit**: `include_all=False` (only tracked files) + user confirmation prompt before first commit
- **MCP Permission Bypass**: centralized MCP tool classification in PermissionManager with whitelist/destructive pattern sets
- **AgentFactory API Compat**: restored `execute_agent()` as deprecated compatibility wrapper

### Infrastructure Fixes
- **MCP Shutdown**: MCPRegistry.disconnect() + ToolLoop.shutdown() called on REPL exit — no more orphaned stdio processes
- **Hooks Connection**: security_check.py and lint_check.py now accept both HookManager format and legacy format
- **MCP Client Version**: MCPHTTPClient now uses dynamic `__import__("widdx").__version__`
- **Node Modules Filter**: `_SKIP_GLOBS` now actually used in index_project() — no more indexing node_modules
- **/self-check in /help**: added missing command documentation
- **GitHub Actions**: disabled (private repo) → replaced with local `run_tests.sh`

### Agent Completeness
- Added emoji+vibe to all 12 built-in agents (backend, security, data, reviewer, laravel, systems, database)
- Comprehensive tests for all 12 agents + AgentRegistry (26 test cases)
- New test files: test_agents.py, test_cli.py, test_git_ops.py, test_web.py, test_semantic.py

## [1.12.1] - 2026-05-23

### Fixes
- Added emoji+vibe fields to 6 agents (backend, security, data, reviewer, laravel, systems, database)
- 4 new test files: test_agents.py, test_cli.py, test_git_ops.py, test_web.py
- 60 tests passing, 2 skipped (interactive)

## [1.12.0] - 2026-05-22

### Web UI Enhancements
- Git panel in web UI with context menu
- Quick actions bar
- Chat history panel
- Diff viewer with Monaco editor
- Smart model routing per-step in ToolLoop
- First-run setup screen with API key configuration
- WebSocket bidirectional chat + cancel support + SSE fallback
- Fix: missing closing brace in exitDiffMode

## [1.8.5] - 2026-05-19

### 🌐 واجهة ويب احترافية (Web UI)

- **`widdx web`** — يشغل سيرفر محلي على `localhost:8520` بواجهة متصفح كاملة
- واجهة مظلمة احترافية بتدرجات لونية وحركات انتقالية
- بطاقات أدوات قابلة للطي مع أيقونات ملونة (Write/Edit/Bash/Read)
- تبويبات جانبية: ملفات + Dashboard المشروع
- أزرار سريعة: Analyze · Fix Bugs · Add Tests · Refactor · README
- عارض ملفات مدمج داخل الصفحة
- تثبيت: `pip install widdx[web]`

### 🔧 تجربة مستخدم محسنة

- **معالج إعداد تفاعلي** عند أول تشغيل — لوحات Rich احترافية، جدول مقارنة المزودين، خطوات مرقمة
- **اختصارات لوحة مفاتيح**: Ctrl+L لمسح الشاشة
- **فحص تحديثات تلقائي** من PyPI كل 24 ساعة
- **استعادة الجلسة** بعد الانقطاع غير المتوقع
- **أمر `/self-check`** لتشخيص جميع مكونات WIDDX

### ✨ عرض احترافي للأكواد

- أيقونات إيموجي للأدوات: 📄 Reading · ✨ Creating · ✏ Editing · ⚙ Running
- مؤشر تفكير متعدد المراحل: 🧠 Analyzing → 💡 Generating → 🔧 Writing → 🔍 Reviewing
- دعم الطرفيات القديمة (cmd.exe) مع ASCII fallback تلقائي
- جدول Rich لعرض الملفات المنشأة والمعدلة

### 🔧 إصلاح تقني

- **مصدر واحد للإصدار** — `pyproject.toml` يغذي كل مكان ديناميكياً

## [1.8.4] - 2026-05-19

### 🤖 مزود Google Gemini (مدفوع + مجاني)

- **Google Gemini** متاح كمزود جديد عند تعيين `GOOGLE_API_KEY`
- النماذج: `gemini-2.5-pro` (معماري) + `gemini-2.0-flash` و `gemini-2.5-flash` (تنفيذ)
- مفتاح مجاني من https://aistudio.google.com
- دعم OpenAI-compatible endpoint عبر `generativelanguage.googleapis.com`

### 🧹 تنظيف الاختبارات من kilo

- إزالة كل مراجع `kilo` من ملفات الاختبار (28 اختباراً)
- تحديث التوقعات لتعكس المزودين الحاليين: deepseek + google + opencode

## [1.8.3] - 2026-05-18

### 🔒 أمان — إزالة shell=True من كل عمليات subprocess

- **`scaffolder/helpers.py`**: `_silent_cmd()` تستخدم `shlex.split()` بدل `shell=True`
- **`scaffolder/__init__.py`**: أوامر تثبيت الحزم تستخدم `shlex.split()` بدل `shell=True`
- **`pipeline/preflight.py`**: أوامر تثبيت الأدوات تستخدم `shlex.split()` بدل `shell=True`
- **`hooks/handlers.py`**: أوامر hooks تستخدم `shlex.split()` بدل `shell=True`

### 🪵 تسجيل الأخطاء الصامتة — إضافة logger.debug لجميع الـ except Exception

- **`router/__init__.py`**: تسجيل فشل حفظ حالة المزود
- **`scaffolder/helpers.py`**: تسجيل فشل اكتشاف إطار العمل
- **`repl/commands/__init__.py`**: تسجيل فشل حذف الملفات المؤقتة
- **`pipeline/preflight.py`**: تسجيل فشل محاولات التثبيت
- **`ui/prompt.py`**: تسجيل فشل prompt_toolkit
- **`ui/theme.py`**: تسجيل فشل تفعيل ANSI على ويندوز
- **`config.py`**: تسجيل فشل تحميل وحفظ الإعدادات والصلاحيات
- **`ui/arabic.py`**: تسجيل فشل تشكيل النص العربي
- **`verifier/__init__.py`**: تسجيل فشل فحص الصيغة

### 🛡️ حماية المسارات الحرجة

- **`hooks/session_log.py`**: إضافة `try/except OSError` لكل عمليات كتابة السجلات و `ensure_log_dir()`
- **`memory/__init__.py`**: `close()` محمي بـ `try/except sqlite3.Error` مع `finally` لتصفير المؤشر
- **`mcp/client.py`**: تصفير `self._process` عند فشل بدء العملية الفرعية

### 🧵 أمان الخيوط

- **`telegram_bot.py`**: تسجيل أخطاء إرسال الملفات بدل الابتلاع الصامت

## [1.8.2] - 2026-05-18

### 🔧 إصلاحات

- **إضافة كلمات تصنيف جديدة**: upgrade, make, add, scaffold → build | repair, correct, bug → fix | enhance, tune, clean → improve
- **رفع complexity العام من 1 → 2**: المهام غير المصنفة تستخدم ToolLoop مع الأدوات
- **إصلاح التبعيات**: جميع المكتبات مضافة في pyproject.toml (openai, rich, click, pyyaml, arabic-reshaper, python-bidi, prompt-toolkit, croniter)

## [1.8.1] - 2026-05-18

### 🔧 إصلاح التبعيات المفقودة

- إضافة جميع المكتبات المطلوبة إلى `[project.dependencies]`

## [1.8.0] - 2026-05-18

### 🧠 نظام توجيه ذكي متعدد المزودين (Intelligent Multi-Provider Routing)

- **خطة A (مع API Key)**: توجيه تسلسلي للمهام التخطيطية (`deepseek-v4-pro` يحلل → `big-pickle` يراجع) مع تنفيذ متوازي للمهام الثقيلة (`deepseek-v4-flash` يكتب + `qwen3.6-plus-free` يراجع في نفس الوقت)
- **خطة B (بدون API Key)**: توجيه تسلسلي للتخطيط (`big-pickle` → `qwen3.6-plus-free`) مع توجيه ذكي للتنفيذ حسب نوع المهمة (coding → `deepseek-v4-flash-free`, context طويل → `minimax-m2.5-free`, خوارزميات → `nemotron-3-super-free`)
- **سلسلة Fallback تلقائية**: عند خطأ 429 أو timeout → انتقال فوري للتالي بدون تدخل المستخدم
- **5 نماذج مجانية من opencode.ai**: `big-pickle`, `deepseek-v4-flash-free`, `qwen3.6-plus-free`, `minimax-m2.5-free`, `nemotron-3-super-free`
- إزالة مزود kilo — تم تبسيط المزودين إلى DeepSeek (مدفوع) + opencode (مجاني)

### 🌐 تحميل النماذج من API مباشرة (Dynamic Model Discovery)

- الاتصال بـ `opencode.ai/zen/v1/models` لاستكشاف النماذج المتاحة تلقائياً
- تصفية النماذج المجانية فقط (من صفحة التسعير الرسمية)
- تحديث قائمة النماذج ديناميكياً دون الحاجة لتعديل الكود

### 🤖 تشغيل آلي بالكامل (Fully Autonomous Shell)

- **أوامر Bash تنفذ تلقائياً** بدون طلب `/approve` من المستخدم
- `shell_require_approval: false` افتراضياً في config.yaml
- `PermissionManager` يقبل `auto_approve=True` افتراضياً
- يمكن للمستخدم تفعيل المصادقة اليدوية عبر `shell_require_approval: true` في config

### 🔧 إصلاحات الأخطاء

- إصلاح `cannot access local variable 'plan'` في pipeline — متغير plan كان غير معرف في مسار full_pipeline
- إصلاح استيراد `project_planner/indexer.py` — تم تغييره إلى `widdx.indexer`
- إصلاح استيراد `project_planner/agent_handoff.py` — تم تغييره إلى `widdx.agent_factory.spec`
- إصلاح استخدام AgentHandoff الخاطئ — تم استبداله بـ AgentRunner
- إصلاح `call_code_reviewer` غير الموجود في AIRouter — تم تغييره إلى `call_executor`
- إزالة FOREIGN KEY constraints من جداول memory (decisions, agent_runs) — كانت تسبب أخطاء متكررة
- إصلاح f-string backslash syntax لأجهزة Python 3.10/3.11
- إضافة dependencies ناقصة: `pyyaml`, `rich`, `click`
- إصلاح mypy errors: type annotations, no-any-return overrides

### 📦 تبعيات جديدة

- `pyyaml>=6.0` — قراءة ملفات YAML
- `rich>=13.0` — واجهة طرفية متقدمة
- `click>=8.0` — واجهة CLI

## [1.7.0] - 2026-05-17

### 🧠 نظام تعليمات مخصص لكل إطار عمل (Framework-Aware AI)

- **كشف 17 إطار عمل** من وصف المهمة: Laravel, Django, FastAPI, React, Next.js, Vue, Angular, Svelte, Express, Node, Spring, Rails, Go, Rust, Flutter, WordPress, Symfony
- **قواعد تطوير مخصصة** لكل إطار: MVC/Eloquent/Blade/Artisan لـ Laravel، MTV/ORM/Admin لـ Django، Pydantic/Depends/SQLAlchemy لـ FastAPI، Hooks/TypeScript/Router v6 لـ React، App Router/Server Components لـ Next.js
- **إزالة التعليمات العامة الخاطئة**: لم يعد يذكر "DeepSeek V4" أو "3-5 colors" أو "Mobile-first" أو "Semantic HTML"
- النظام يتكيف تلقائياً مع إطار العمل المطلوب في المهمة

### 🔧 إصلاح تنفيذ وإنشاء الملفات (File Creation Fix)

- **`_execute_simple` يستخدم ToolLoop** بدلاً من `route()` — النموذج الآن ينشئ ملفات فعلية عبر Write tool
- **لم يعد يكتفي بالكلام**: قبل الإصلاح كان النموذج يصف ما سيفعله فقط دون إنشاء ملفات. الآن ينشئ 10+ ملفات فعلية
- توجيه النموذج: *"Use the Write tool to create project files — do NOT just describe what to build"*

### 🏗️ إعداد البيئة قبل كل شيء (Environment-First Philosophy)

- **preflight قبل scaffolding**: فحص الأدوات وتثبيتها **قبل** السؤال عن إعدادات المشروع
- **scaffold يفحص الأدوات أولاً**: لا يسأل أسئلة عن Laravel/Django إلا بعد التأكد من وجود الأدوات
- **تثبيت متعدد المحاولات**: يجرب winget → choco → brew → apt بشكل متسلسل لكل أداة
- **بحث ذكي عن الأدوات**: يبحث في مجلدات winget/choco/Program Files حتى لو لم تكن في PATH
- مثال: PHP مثبت عبر winget في `AppData/Local/Microsoft/WinGet/Packages/` — WIDDX يجده الآن

### ⚙️ إصلاحات أخرى

- تصنيف مهام build: complexity 2 → 3 (مطابق للـ REPL)
- تنظيف hooks المعطلة (`$WIDDX_PROJECT_DIR` غير القابل للتوسيع)
- إصلاح 0 خطأ mypy
- كود ميت محذوف في `_handle_missing_tools`

## [1.6.0-1.6.1] - 2026-05-16

### 🤖 بوت تيليجرام (Telegram Bot)

- `widdx bot start` لتشغيل البوت
- أوامر: `/start`, `/help`, `/status`, `/providers`, `/key`, `/cd`
- إرسال الملفات المنشأة كمستندات Telegram
- `--project-dir` لتحديد مجلد العمل
- اختياري: `pip install widdx[telegram]`

### 🔑 إصلاحات المزودين

- إعادة تفعيل المزودين المجانيين (OpenCode + Kilo) — كانا معطلين في config
- إصلاح مفتاح DeepSeek API غير الصالح

## [1.5.0] - 2026-05-15

### ✅ إصلاحات الاستقرار

- **mypy**: إصلاح 52 خطأ نوعي عبر 19 ملفاً
- **CI/CD**: استعادة GitHub Actions (3 OS × 3 Python)
- **نشر PyPI**: 11 إصدار (1.4.0 → 1.6.1)
- **أمان**: `shlex.quote()` في scaffolder، فحص Path.cwd() في undo
- **تثبيت تلقائي**: إزالة `--silent` من winget، تحقق بعد التثبيت

### 🐛 إصلاحات متنوعة

- إصلاح السقالة المزدوجة (لم تعد تسأل مرتين)
- إصلاح ANSI على CMD (SetConsoleMode)
- إصلاح `ptpython` و PATH على Windows

## [1.4.0] - 2026-05-15

### 🚀 إعادة هيكلة المزودين (Provider Consolidation)

- تم دمج 5 مزودين مجانيين إلى **مزودين حقيقيين** (OpenCode + Kilo) بنماذج متعددة
- OpenCode: 3 نماذج (big-pickle, deepseek-v4-flash-free, nemotron-3-super-free)
- Kilo: 3 نماذج (kilo-auto/free, owl-alpha, stepfun-3.5-flash)
- Deduplication تلقائي للنماذج المتكررة
- حفظ تفضيلات المزودين تلقائياً في `~/.widdx/config.yaml`

### 🎨 تحسينات الواجهة (UX Overhaul)

- **مؤشر تفكير متحرك** — Rich spinner متحرك أثناء انتظار الـ AI
- **Toast notifications** — إشعارات نجاح/فشل مع صوت تنبيه للمهام الطويلة
- **StatusBar widget** — عرض tokens والاتصال بعد كل مهمة
- **شريط أدوات محسّن** — ألوان حية، عرض آخر مهمة مع وقتها
- **شاشة إقلاع المزودين** — اختيار تفاعلي للمزودين بعلامات ✓ عند أول تشغيل
- **مؤشر التعقيد** — نجوم ✦✧ توضح درجة تعقيد المهمة

### 🌐 دعم متعدد المنصات (Cross-Platform)

- **اكتشاف 14 محطة طرفية** عبر Windows/macOS/Linux للـ Arabic RTL
- **عرض نظام التشغيل** في البانر ورسالة البدء (Windows/macOS/Linux)
- Linux: دعم Gnome Terminal، KDE Konsole، Alacritty، Foot، وغيرها
- macOS: دعم Terminal.app، iTerm2، Warp

### 📝 إصلاحات العربية (Arabic Fixes)

- تكوين `arabic_reshaper` مع `support_zwj` و `delete_harakat: False`
- ربط الحروف العربية بشكل صحيح (لم تعد منفصلة)
- تطبيق RTL حسب نوع المحطة تلقائياً

### 🧪 اختبارات (Testing)

- **498 اختبار** (ارتفاع من 445) — 0 أخطاء
- اختبارات جديدة: 27 للـ router، 18 للـ Arabic UI، 6 للـ terminal detection
- تغطية كاملة لبناء المزودين، toggle/enable_only، forced provider، fallback

### 🔧 إصلاحات Type Checking

- إصلاح 52 خطأ mypy عبر 19 ملف
- إعادة تسمية `list()` إلى `list_schedules()` لحل تعارض مع builtin
- إصلاح تعارض `MCPClient | MCPHTTPClient` في MCP registry
- إصلاح prompt_toolkit Output override issues
- إصلاح `Traversable` attribute errors في templates

### 🗑️ تنظيف (Cleanup)

- إزالة مجلد `opencode-models/` (مشروع منفصل غير مرتبط)
- إزالة `mypy.txt` (ملف مؤقت) وإضافته لـ `.gitignore`
- إزالة `docs/gap_analysis.md` (جميع الفجوات مغلقة)

### ⚡ تحسينات الأداء والأمان

- `shell=True` مع `session_approved` يسمح بتمرير pipe `|` بعد موافقة المستخدم
- إضافة `tomli` للاعتماديات المفقودة في `requirements.txt`
- إلغاء `import time as _time` المكرر في REPL

### 📚 وثائق

- تحديث `README.md` — إضافة المزودين المجانيين، Super Agent، 498 اختبار، منصات متعددة
- تحديث `QUICKSTART.md` — إزالة شرط مفتاح DeepSeek، إضافة أوامر المزودين
- `config.yaml` — تفعيل `thinking: true` افتراضياً لـ Super Agent

---

## [1.3.1] - 2026-05-10

### 🧩 خوادم MCP مدمجة (Built-in MCP Servers)

**الملفات المنشأة/المعدّلة:**
- `widdx/mcp/builtin.py` — إطار خوادم مدمجة داخل العملية (280 سطر)
- `widdx/mcp/__init__.py` — إضافة `_load_builtin_servers()` ودعم `_disabled`
- `.widdx/mcp.json` — قالب إعدادات بـ 4 خوادم خارجية (filesystem مفعّل)
- `~/.widdx/mcp.json` — قالب إعدادات مستوى المستخدم

**ما تم تنفيذه:**
- خادم `project-info` بـ 3 أدوات: `project_stats`, `project_config`, `project_tree`
- خادم `utility` بـ 3 أدوات: `generate_uuid`, `timestamp_now`, `random_string`
- الخوادم المدمجة تُحمّل تلقائياً في كل جلسة — لا تحتاج إعدادات
- مفتاح `_disabled` في mcp.json لتعطيل أي خادم خارجي
- تفعيل خادم `filesystem` الخارجي جاهز للاستخدام

**الاختبارات:** `tests/test_mcp.py` — 10 اختبارات محدثة + `tests/test_integration.py` — 4 اختبارات MCP

---

### 🤖 PromptHandler مع استدعاء LLM فعلي

**الملفات المعدّلة:**
- `widdx/hooks/handlers.py` — PromptHandler يستدعي `router.call_executor()` فعلياً
- `widdx/hooks/__init__.py` — HookManager يقبل router ويمرره لـ PromptHandler
- `widdx/tool_loop/__init__.py` — ToolLoop يمرر router لـ HookManager تلقائياً

**ما تم تنفيذه:**
- PromptHandler يرسل prompt hooks إلى LLM لتقييم الأوامر قبل التنفيذ
- استبدال متغيرات `$KEY` و `${KEY}` من السياق
- إرجاع `ALLOW` للسماح أو `DENY` للمنع
- السقوط لـ `DENY` افتراضياً عند فشل اتصال LLM (safe default)
- دعم المسار القديم بدون router للتوافق مع الاختبارات

---

### 🧹 تنظيف الكود

**الملفات المعدّلة:**
- `widdx/agent_factory/__init__.py` — إزالة `_topological_sort()` غير المستخدمة (20 سطر)
- `widdx/ui/arabic.py` — استيراد `_d()` المركزي بدلاً من تعريف محلي

---

### 🧪 اختبارات التكامل

**الملفات المنشأة:**
- `tests/test_integration.py` — 20 اختبار تكامل جديد

**ما تم اختباره:**
- Pipeline: معالجة المهام وتحليل JSON
- AgentFactory: فرق متعددة الوكلاء، ترتيب التبعيات، كشف التكرار الدائري
- Hooks: منع الأدوات، السماح، تصفية matchers
- PromptHandler: استدعاء LLM، رفض/سماح، التعامل مع الأخطاء
- MCP مدمج: تحميل الخوادم، تنفيذ الأدوات، التسمية
- Skills: تحميل SkillManager وربطه بـ ToolLoop

---

## [1.3.0-claude-code-parity] - 2026-05-10

### 🚀 سد الفجوات مع Claude Code CLI

تنفيذ 6 ميزات رئيسية لمطابقة قدرات Claude Code CLI.

---

### GAP-5: ذاكرة المشروع (WIDDX.md)

**الملفات المنشأة/المعدّلة:**
- `widdx/tool_loop/system_prompt.py` — إضافة `_load_project_md()`
- `widdx/repl/commands.py` — إضافة معالج `/memory`

**ما تم تنفيذه:**
- قراءة `WIDDX.md` أو `CLAUDE.md` من جذر المشروع عند بدء كل جلسة
- حقن المحتوى في system prompt تلقائياً
- تحذير عند تجاوز الملف 10KB
- أمر `/memory` لعرض المحتوى المحمّل

**الاختبارات:** `tests/test_project_memory.py` — 35 اختبار

---

### GAP-3: عزل سياق الوكلاء

**الملفات المنشأة/المعدّلة:**
- `widdx/agent_factory/__init__.py` — إضافة `_build_isolated_context()`
- `widdx/agent_factory/spec.py` — إضافة `AgentHandoff.to_context_block()` مع حد الحجم

**ما تم تنفيذه:**
- كل وكيل يحصل على `ToolLoop` معزول خاص به
- `_build_isolated_context()` يبني سياقاً نظيفاً لكل وكيل
- `AgentHandoff.to_context_block()` يُحوّل نتيجة الوكيل السابق إلى block منظم مع حد أقصى للحجم

**الاختبارات:** `tests/test_agent_isolation.py` + `tests/test_agent_handoff.py` — 40 اختبار

---

### GAP-4: نظام المهارات (Skills System)

**الملفات المنشأة:**
- `widdx/skills/__init__.py`
- `widdx/skills/loader.py` — `SkillManager`
- `.widdx/skills/code-review.md` — مهارة مثال
- `.widdx/skills/tdd-workflow.md` — مهارة مثال

**الملفات المعدّلة:**
- `widdx/repl/commands.py` — إضافة `/skills` و `/<skill-name>`
- `widdx/tool_loop/system_prompt.py` — حقن auto-invoke skills

**ما تم تنفيذه:**
- `SkillManager` يقرأ ملفات `.md` مع YAML frontmatter
- المهارات ذات `auto_invoke: true` تُحقن في system prompt تلقائياً
- أمر `/skills` لعرض المهارات المتاحة
- `/<skill-name>` لتشغيل مهارة مباشرة

**الاختبارات:** `tests/test_skills.py` — 38 اختبار

---

### GAP-2: نظام الـ Hooks

**الملفات المنشأة:**
- `widdx/hooks/__init__.py`
- `widdx/hooks/events.py` — `HookEvent` enum
- `widdx/hooks/handlers.py` — `CommandHandler` / `PromptHandler`
- `.widdx/hooks.json` — إعداد hooks المشروع

**الملفات المعدّلة:**
- `widdx/repl/commands.py` — إضافة `/hooks`
- `widdx/tool_loop/__init__.py` — إطلاق PreToolUse/PostToolUse
- `widdx/repl/__init__.py` — إطلاق SessionStart/TaskCompleted

**ما تم تنفيذه:**
- `HookManager` يُحمّل hooks من JSON ويُشغّلها عند الأحداث
- `HookEvent` enum: `PreToolUse`, `PostToolUse`, `SessionStart`, `TaskCompleted`
- `CommandHandler` لتشغيل أوامر shell، `PromptHandler` لإرسال prompts للـ LLM
- دعم `async: true` للتشغيل غير المتزامن
- أمر `/hooks` لعرض الـ hooks المسجلة

**الاختبارات:** `tests/test_hooks.py` — 42 اختبار

---

### GAP-6: المهام المجدولة (Scheduled Tasks)

**الملفات المنشأة:**
- `widdx/scheduler.py` — `TaskScheduler`

**الملفات المعدّلة:**
- `widdx/cli.py` — إضافة subcommands `widdx schedule add/list/remove/run`

**ما تم تنفيذه:**
- `TaskScheduler` مع cron daemon يستخدم `croniter`
- الجدول محفوظ في `~/.widdx/schedules.json`
- نتائج التشغيل تُحفظ في `MemoryStore` (جدول `knowledge`)
- subcommands: `widdx schedule add/list/remove/run`

**الاختبارات:** `tests/test_scheduler.py` — 35 اختبار

---

### GAP-1: بروتوكول MCP

**الملفات المنشأة:**
- `widdx/mcp/__init__.py`
- `widdx/mcp/client.py` — `MCPClient` (stdio) + `MCPHTTPClient` (HTTP)
- `widdx/mcp/config.py` — `MCPRegistry` + `MCPConfig`

**الملفات المعدّلة:**
- `widdx/tool_loop/tools.py` — دمج أدوات MCP مع `TOOL_DEFINITIONS`، توجيه `mcp__*`
- `widdx/repl/commands.py` — إضافة `/mcp list/add/remove`
- `widdx/config.yaml` — إضافة قسم `mcp`

**ما تم تنفيذه:**
- `MCPRegistry` يُدير قائمة الخوادم المتصلة
- `MCPClient` للاتصال بخوادم stdio، `MCPHTTPClient` للاتصال بخوادم HTTP
- أدوات MCP تُدمج مع `TOOL_DEFINITIONS` وتظهر كـ `mcp__<server>__<tool>`
- توجيه تلقائي لاستدعاءات `mcp__*` للخادم المناسب
- إعادة اتصال تلقائية عند انقطاع الخادم
- أمر `/mcp` مع subcommands: `list`, `add`, `remove`

**الاختبارات:** `tests/test_mcp.py` — 45 اختبار

---

### 📊 إجمالي الاختبارات

| الإصدار | الاختبارات |
|---------|-----------|
| v1.2.0 | 118 اختبار |
| v1.3.0 (جديد) | +182 اختبار |
| **المجموع** | **300+ اختبار** |

---

### 📦 متطلبات جديدة

```
croniter>=2.0.0,<3.0    ← TaskScheduler
```

---

## [1.2.0-phase3-ux] - 2026-05-09

### 🎨 المرحلة الثالثة — تحسينات تجربة المستخدم (UX)

أربع تحسينات مرئية وعملية تُضاف مباشرة فوق البنية التحتية الموجودة.

---

### ✨ 1. Cost Tracking مرئي في كل رسالة

**الملف:** `widdx/tool_loop/display.py` — `_format_result()`

في نهاية كل رد يظهر الآن سطر واحد يحتوي على:
```
↳ 1.2k tokens · $0.0012 · 850ms
```

- **Tokens:** مجموع input + output للجلسة كاملة (تراكمي)
- **Cost:** التكلفة التراكمية للجلسة بالدولار
- **Latency:** وقت تنفيذ الطلب الحالي بالميلي ثانية

البيانات تُقرأ مباشرة من `_session_input_tokens` و `_session_output_tokens` و `_session_cost` الموجودة في `AIRouter` — لا infrastructure جديدة.

---

### 🔴🟢 2. Diff Viewer عند تعديل الملفات

**الملفات:** `widdx/tool_loop/tools.py` + `widdx/tool_loop/display.py` + `widdx/tool_loop/__init__.py`

عند كل `Edit` أو `Write` (overwrite)، يُعرض diff مختصر بألوان مباشرة في الـ terminal:

```
- old line removed
+ new line added
```

**التفاصيل التقنية:**
- `_execute_tool` يحفظ محتوى الملف قبل التعديل في `_diff_old` / `_diff_new` / `_diff_path`
- `_render_diff()` تستخدم `difflib.unified_diff` مع `n=1` (سطر context واحد)
- الحد الأقصى: 4 سطور محذوفة + 4 مضافة لإبقاء الـ output مختصراً
- المفاتيح `_diff_*` تُحذف من نتيجة الأداة قبل إرسالها للـ LLM (لا تُضاف للـ context)

---

### 🔄 3. أمر `/resume` — استئناف المهام المنقطعة

**الملفات:** `widdx/repl/commands.py` + `widdx/repl/__init__.py`

```
/resume
```

يجلب آخر مهمة غير مكتملة من SQLite ويُعيد تنفيذها مع سياقها:

1. يبحث في `recent_tasks(20)` عن أول مهمة بحالة غير `completed` أو `failed`
2. يعرض معلوماتها: ID، تاريخ الإنشاء، الأمر الأصلي
3. يُعيد بناء السياق من آخر 5 قرارات مسجلة في جدول `decisions`
4. يُحقن السياق كرسائل تاريخية synthetic للـ LLM
5. يُعيد تنفيذ الأمر الأصلي

---

### 🔧 4. إصلاح FastAPI Detection

**الملف:** `widdx/tool_loop/system_prompt.py`

**المشكلة:** أي مشروع Python يملك `main.py` كان يُكتشف خطأً كـ FastAPI.

**الحل:** استُبدل الفحص بدالة `_has_fastapi_dependency(cwd)` التي تفحص ثلاثة ملفات:
- `pyproject.toml`
- `requirements.txt`
- `requirements-dev.txt`

وتبحث عن كلمة `fastapi` (case-insensitive) في أي منها. إذا لم تجدها، يُتجاهل `main.py` ويستمر البحث عن frameworks أخرى.

---

### 📝 ملفات معدلة

| الملف | التغيير |
|---|---|
| `widdx/tool_loop/display.py` | `_format_result()` — سطر التكلفة · `_render_diff()` — diff ملون |
| `widdx/tool_loop/tools.py` | `_execute_tool()` — حفظ old/new content للـ diff |
| `widdx/tool_loop/__init__.py` | عرض الـ diff + تنظيف `_diff_*` قبل إرسال نتيجة الأداة للـ LLM |
| `widdx/repl/commands.py` | إضافة `_resume()` + تسجيله في `_handle_command()` + `/help` |
| `widdx/repl/__init__.py` | حقن `_resume` في `WIDDXRepl` |
| `widdx/tool_loop/system_prompt.py` | `_detect_framework()` + `_has_fastapi_dependency()` |

---

### ✅ الاختبارات

- 118 اختبار pytest — جميعها تجتاز بنجاح
- لا breaking changes

---

## [1.1.6-phase2-features] - 2026-05-09

### ⚡ المرحلة الثانية — أربع ميزات جوهرية

---

### 🧠 1. LLM-based Task Classification

**الملف:** `widdx/router/__init__.py`

استُبدل `classify()` الذي كان يعتمد على keyword matching (~65% دقة) بنظام ثنائي المستوى:

1. **المستوى الأول:** استدعاء DeepSeek flash بـ `max_tokens=5` و `temperature=0`:
   ```
   "You are a task classifier. Reply with exactly one word: architect or executor."
   ```
   التكلفة: ~50 token لكل مهمة. الدقة: ~90%.

2. **المستوى الثاني (fallback):** `_classify_with_keywords()` — الكود القديم يعمل تلقائياً عند فشل الـ API أو عدم توفر الاتصال.

الدوال المضافة:
- `_classify_with_llm()` — الاستدعاء السريع، يُعيد `None` عند أي فشل
- `_classify_with_keywords()` — الـ fallback الأصلي

---

### ✅ 2. Verification Loop بعد كل تنفيذ

**الملف:** `widdx/tool_loop/tools.py`

بعد كل `Write` أو `Edit` ناجح، تُشغَّل `_verify_file()` تلقائياً:

| نوع الملف | الفحص |
|---|---|
| `.py` | `python -m py_compile <file>` |
| `test_*.py` | `python -m pytest <file> -x -q --tb=short` |
| `.js` | `node --check <file>` |
| غيرها | لا فحص (يُعيد `None`) |

النتيجة تُضاف للـ tool output تحت مفتاح `"verification"`:
- نجاح: `{"verified": True}`
- فشل: `{"error": "...", "output": "..."}`

الـ LLM يرى النتيجة في الـ turn التالي ويُصحح الأخطاء تلقائياً (Build-Test-Fix loop حقيقي).

---

### ⚡ 3. Parallel Agent Execution

**الملف:** `widdx/agent_factory/__init__.py`

`execute_team()` يستخدم الآن **wave-based scheduler** بدلاً من التنفيذ التسلسلي:

```
Wave 1: [Backend, Frontend]  ← يبدآن معاً (لا يعتمد أحدهما على الآخر)
Wave 2: [QA]                 ← ينتظر اكتمال Wave 1
```

**التفاصيل:**
- كل iteration تجد جميع الـ agents التي اكتملت dependencies لها
- إذا كان عدد الـ agents في الـ wave > 1 → `ThreadPoolExecutor(max_workers=N)`
- إذا كان عدد الـ agents = 1 → تنفيذ مباشر بدون thread overhead
- فشل أي agent لا يوقف الـ wave — يُسجَّل الخطأ ويكمل الباقون

---

### 🔍 4. Context-aware Edit Tool (Fuzzy Fallback)

**الملف:** `widdx/tools/file_ops.py`

عند عدم تطابق `old_string` verbatim، تُشغَّل `_find_fuzzy_match()`:

1. تقسم الـ haystack إلى نوافذ بنفس عدد أسطر الـ needle
2. تحسب `difflib.SequenceMatcher.ratio()` لكل نافذة
3. إذا كانت أفضل نسبة ≥ 0.85 → تُعيد المقطع الأقرب

رسالة الخطأ تتضمن:
```json
{
  "error": "old_string not found in file",
  "fuzzy_match": "<أقرب مقطع موجود>",
  "hint": "Use that exact text as old_string and retry."
}
```

الـ LLM يستخدم `fuzzy_match` كـ `old_string` في المحاولة التالية بدون تخمين.

---

### 📝 ملفات معدلة

| الملف | التغيير |
|---|---|
| `widdx/router/__init__.py` | `classify()` + `_classify_with_llm()` + `_classify_with_keywords()` |
| `widdx/tool_loop/tools.py` | `_verify_file()` + ربطها بـ Write/Edit |
| `widdx/tool_loop/display.py` | `_tool_hint()` يعرض نتيجة الـ verification |
| `widdx/tool_loop/__init__.py` | عرض verification failures + import `_verify_file` |
| `widdx/agent_factory/__init__.py` | `execute_team()` بـ ThreadPoolExecutor |
| `widdx/tools/file_ops.py` | `tool_edit_file()` + `_find_fuzzy_match()` |

---

### ✅ الاختبارات

- 118 اختبار pytest — جميعها تجتاز بنجاح

---



### 🔗 تحسين تعاون الوكلاء (Agent Collaboration)

تم إضافة 4 ميزات جديدة لتحسين التواصل بين الوكلاء:

| الميزة | الوصف |
|---|---|
| `AgentHandoff` | هيكل منظم لنقل العمل بين الوكلاء (ملخص + ملفات + قرارات + الخطوات التالية) |
| `_summarize_for_handoff()` | ضغط مخرجات الوكيل الكبيرة إلى 600 حرف للوكيل التالي |
| `_detect_file_conflicts()` | كشف الملفات التي لمسها أكثر من وكيل ⚠ |
| `_synthesize_final()` | دمج جميع النتائج في تقرير نهائي مع ملف مانيفست وإحصائيات |

---

### 📝 ملفات معدلة

- `widdx/agent_factory/spec.py` — إضافة `AgentHandoff` dataclass
- `widdx/agent_factory/__init__.py` — `execute_team` مع handoffs + conflict detection + synthesis
- `widdx/agent_factory/runner.py` — دعم enriched prior context مع handoff blocks

---

## [1.1.4-stability] - 2026-05-09

### 🔴 إصلاحات استقرار

#### MemoryStore احترافي
- إضافة `logging` منظم بدلاً من `print` إلى stderr
- إضافة `is_connected` property
- إضافة `error_count` property لتتبع عدد الأخطاء
- إضافة `health_check()` — تقرير تشخيصي كامل
- حماية `_migrate()` بـ try/except مع logging

#### تثبيت الاعتماديات
- جميع المكتبات محصورة الإصدارات (`>=x,<y`)

#### تنظيف نقاط الدخول
- إزالة `orchestrator.chat()` المكرر
- تبسيط `cli.py` — إنشاء router/config/memory مباشرة بدون orchestrator كامل
- `cli.py` هو نقطة الدخول الوحيدة الآن

#### مجموعة اختبارات شاملة
- `test_fixes.py`: من 5 إلى 11 اختبار (77 assertion)
- `tests/`: 118 اختبار pytest احترافي
- المجموع: **195 اختبار**

---

### 📝 ملفات معدلة

- `widdx/memory.py` — logging احترافي + health check
- `widdx/orchestrator.py` — إزالة `chat()` المكرر
- `widdx/cli.py` — تبسيط `_start_repl`
- `pyproject.toml` — تثبيت الإصدارات + pytest config
- `test_fixes.py` — توسيع إلى 77 اختبار
- `tests/` — **جديد** — 118 اختبار pytest

---

## [1.1.3-agent-factory-split] - 2026-05-09

### 🏗️ تقسيم agent_factory.py إلى حزمة

| الملف القديم | الأسطر | الحزمة الجديدة | عدد الملفات |
|---|---|---|---|
| `widdx/agent_factory.py` | 308 | `widdx/agent_factory/` | 3 |

```
agent_factory/
├── __init__.py   — AgentFactory + _topological_sort + helpers
├── spec.py       — AgentSpec dataclass
└── runner.py     — AgentRunner class
```

---

### ✅ إجمالي الملفات المقسمة

| # | الملف القديم | الحزمة الجديدة |
|---|---|---|
| 1 | `ui.py` (430) | `ui/` (7 ملفات) |
| 2 | `repl.py` (419) | `repl/` (3 ملفات) |
| 3 | `router.py` (413) | `router/` (4 ملفات) |
| 4 | `tool_loop.py` (636) | `tool_loop/` (4 ملفات) |
| 5 | `agent_factory.py` (308) | `agent_factory/` (3 ملفات) |

**إجمالي: 2,206 سطر → 5 حزم / 21 ملف**

---

## [1.1.2-live-streaming] - 2026-05-09

### 🎨 المرحلة الثانية — Streaming ذكي وتكامل أعمق

| المكون | الوظيفة | الحالة |
|---|---|---|
| `LiveStreamRenderer` | تنسيق الـ streaming tokens أثناء التدفق مع markdown awareness | ✅ |
| `status_line()` في `/model` | عرض احترافي للموديل والتكلفة في Panel واحد | ✅ |
| `spinner()` في `/index` | مؤشر دوار أثناء فهرسة المشروع | ✅ |

---

### 📝 ملفات معدلة

- `widdx/ui/professional.py` — إضافة `LiveStreamRenderer`
- `widdx/tool_loop/__init__.py` — دمج LiveStreamRenderer في streaming
- `widdx/repl/commands.py` — `status_line()` في `/model`
- `widdx/repl/context.py` — `spinner()` في `/index`

---

## [1.1.1-professional-ui] - 2026-05-09

### 🎨 المرحلة الأولى — مكونات واجهة احترافية

تمت إضافة ملف جديد `widdx/ui/professional.py` يحتوي على 9 مكونات احترافية:

| المكون | الوظيفة | التقنية المستخدمة | الحالة |
|---|---|---|---|
| `render_markdown()` | عرض Markdown مع تلوين الكود | `rich.markdown.Markdown` | ✅ |
| `render_code()` | عرض كود مع syntax highlighting | `rich.syntax.Syntax` + `rich.panel.Panel` | ✅ |
| `spinner()` | مؤشر دوار أثناء العمليات الطويلة | `rich.progress.Progress` | ✅ |
| `progress_bar()` | شريط تقدم مع النسبة والوقت | `rich.progress` (BarColumn, TimeRemainingColumn) | ✅ |
| `render_diff()` | عرض unified diff ملون (+ أخضر / - أحمر) | `difflib` + Rich coloring | ✅ |
| `file_tree()` | عرض شجرة ملفات المشروع | `rich.tree.Tree` | ✅ |
| `confirm()` | حوار تأكيد نعم/لا | `input()` + Rich styling | ✅ |
| `status_line()` | شريط حالة مدمج (Tokens, Cost, Model) | `rich.panel.Panel` + `rich.text.Text` | ✅ |
| `create_layout()` | تخطيط متعدد الألواح | `rich.layout.Layout` | ✅ |

---

### 🔗 أماكن الدمج

| المكان | التغيير |
|---|---|
| `ui/__init__.py` | تصدير جميع المكونات الجديدة التسعة |
| `tool_loop/display.py` | `_format_result()` تستخدم `render_markdown` تلقائياً لعرض الردود |
| `repl/commands.py` | أمر `/clear` يسأل تأكيد قبل المسح |
| `repl/commands.py` | أمر `/agents` يستخدم `render_markdown` بدلاً من Markdown المباشر |

---

### 🔜 المرحلة الثانية — Streaming ذكي وتكامل أعمق (قيد التنفيذ)

| المهمة | الوصف | الأولوية |
|---|---|---|
| ⬜ `LiveStreamRenderer` | تنسيق الـ streaming tokens أثناء التدفق مع markdown awareness | 🔴 عالية |
| ⬜ `status_line` في `/model` | استبدال عرض `/model` الحالي بـ `status_line()` الاحترافي | 🟡 متوسطة |
| ⬜ `progress_bar` في `/index` | إظهار شريط تقدم أثناء فهرسة المشروع | 🟡 متوسطة |
| ⬜ `render_diff` في `/undo` | عرض diff ملون قبل التراجع عن التغييرات | 🟢 منخفضة |
| ⬜ `spinner` في ToolLoop | إظهار مؤشر دوار أثناء انتظار الـ LLM | 🟢 منخفضة |

---

### 📝 ملفات معدلة في هذه المرحلة

- `widdx/ui/professional.py` — **جديد** — 9 مكونات احترافية (337 سطر)
- `widdx/ui/__init__.py` — تصدير المكونات الجديدة
- `widdx/tool_loop/display.py` — markdown rendering في `_format_result`
- `widdx/repl/commands.py` — تأكيد `/clear` + markdown في `/agents`

---

### ⚠️ Breaking Changes

لا توجد — جميع الدوال القديمة (`rule()`, `done()`, `show_banner()`, إلخ) لا تزال تعمل كما هي.

---

## [1.1.0-modular] - 2026-05-09

### 🏗️ إعادة هيكلة — تقسيم الملفات الكبيرة إلى حزم Modular

تم تقسيم 4 ملفات كبيرة كانت تحتوي على مئات الأسطر إلى حزم منظمة في مجلدات:

| الملف القديم | الأسطر | الحزمة الجديدة | عدد الملفات | أكبر ملف |
|---|---|---|---|---|
| `widdx/ui.py` | 430 | `widdx/ui/` | 7 | 161 (drawing.py) |
| `widdx/repl.py` | 419 | `widdx/repl/` | 3 | 237 (commands.py) |
| `widdx/router.py` | 413 | `widdx/router/` | 4 | 192 (__init__.py) |
| `widdx/tool_loop.py` | 636 | `widdx/tool_loop/` | 4 | 249 (__init__.py) |

**إجمالي: 1,898 سطر → 4 حزم / 18 ملف (أكبر ملف 249 سطر فقط)**

---

### 📦 هياكل الحزم الجديدة

#### `widdx/ui/` — واجهة المستخدم
```
ui/
├── __init__.py   — إعادة تصدير جميع الرموز للتوافق العكسي
├── theme.py      — WIDDX_THEME, get_console()
├── arabic.py     — reshape, _is_arabic, _cp_is_arabic
├── drawing.py    — BANNER, rule, done, fail, warn, info, show_banner, task_start, task_done, table
├── chat.py       — chat_welcome, chat_user, chat_assistant, chat_streaming_token
├── prompt.py     — prompt (prompt_toolkit session)
└── views.py      — show_status, show_search, show_tools, show_index, show_git
```

#### `widdx/repl/` — حلقة القراءة التفاعلية
```
repl/
├── __init__.py   — WIDDXRepl core (حقن الدوال)
├── commands.py   — _handle_command, _show_help, _search, _undo, _run_agents, ...
└── context.py    — _expand_context_shortcuts, _index_project, _check_git_status, _estimate_complexity
```

#### `widdx/router/` — التوجيه الذكي للـ API
```
router/
├── __init__.py   — AIRouter core + session_tokens/session_cost (properties)
├── pricing.py    — PRICING dict, _track_usage, _estimate_tokens
├── tools_api.py  — call_with_tools, _build_api_tools
└── streaming.py  — call_streaming, call_with_tools_streaming
```

#### `widdx/tool_loop/` — حلقة الأدوات
```
tool_loop/
├── __init__.py   — ToolLoop core (حقن الدوال)
├── system_prompt.py — _detect_framework, _detect_package_manager, _build_system_prompt
├── tools.py      — TOOL_DEFINITIONS, _parse_args, _execute_tool, _tool_list_dir
└── display.py    — _tool_label, _tool_hint, _short_path, _reshape_line, _format_result, _summarize_final
```

---

### 🧩 نمط حقن الدوال (Method Injection Pattern)

اعتُمد نمط موحد لتقسيم الكلاسات دون كسر المراجع:
- الدوال تُعرّف كـ standalone functions في ملفات فرعية
- تُحقن في الكلاس الرئيسي كـ class attributes في `__init__.py`
- تستخدم `self` كأول parameter للوصول إلى حالة الكائن

مثال من `tool_loop/__init__.py`:
```python
from .tools import TOOL_DEFINITIONS, _parse_args, _execute_tool

class ToolLoop:
    _parse_args = _parse_args
    _execute_tool = _execute_tool
    TOOL_DEFINITIONS = TOOL_DEFINITIONS
```

---

### ✅ التحقق من السلامة

- جميع `import` الموجودة مسبقاً لا تزال تعمل دون تغيير (`from .ui import X`, `from .router import X`, إلخ)
- `__init__.py` في كل حزمة يُعيد تصدير جميع الرموز للتوافق العكسي الكامل
- تم التحقق: `ALL IMPORTS OK — System not broken`

---

### ⚠️ Breaking Changes

لا توجد — جميع المسارات القديمة (`from widdx.ui import ...`) لا تزال تعمل.

---

## [1.0.0-fixed] - 2026-05-09

### 🔴 إصلاحات حرجة

#### إصلاح reasoning_content في API calls
- **المشكلة:** كان `reasoning_content` يُرسل مع الرسائل التاريخية، مما يسبب رفض DeepSeek API للطلبات
- **الحل:** 
  - إضافة دالة `_strip_reasoning_content()` في `router.py` لتصفية الحقل قبل الإرسال
  - إزالة حفظ `reasoning_content` في الرسائل الوسيطة في `tool_loop.py`
- **التأثير:** إصلاح حرج — يمنع فشل جميع tool loops متعددة الخطوات

#### تطبيق whitelist الأوامر في shell.py
- **المشكلة:** قوائم `FORBIDDEN` و `ALLOWED_COMMANDS` كانت معرّفة لكن لا تُطبَّق فعلياً
- **الحل:**
  - إضافة دالة `_extract_base_command()` لاستخراج اسم الأمر
  - فحص كل أمر مقابل `FORBIDDEN` و `ALLOWED_COMMANDS` قبل التنفيذ
  - استخدام `shell=False` على Unix لمنع shell injection
  - الاحتفاظ بـ `shell=True` على Windows فقط (ضروري للأوامر المدمجة)
- **التأثير:** إصلاح أمني حرج — يمنع تنفيذ أوامر خطرة

#### إصلاح حساب الملفات في git status
- **المشكلة:** `"".split("\n")` يُعيد `[""]` بدلاً من `[]` عند stdout فارغ
- **الحل:** تصفية السطور الفارغة: `[l for l in stdout.split("\n") if l.strip()]`
- **التأثير:** إصلاح bug — يعرض عدد الملفات المعدلة بدقة

---

### 🟡 تحسينات مهمة

#### استبدال reasoning_effort بـ thinking_mode
- **المشكلة:** `reasoning_effort` غير موثق في DeepSeek V4 API
- **الحل:**
  - استبدال `reasoning_effort` بـ `thinking_mode`
  - دعم قيمتين: `"enabled"` (قياسي) و `"thinking_max"` (أقصى عمق)
  - تحديث `config.yaml` ليعكس التغيير
- **التأثير:** توافق أفضل مع API الرسمي

#### زيادة max_tokens
- **المشكلة:** القيم كانت محافظة جداً (4K-16K) بينما API يدعم 384K
- **الحل:**
  - `call_architect`: 4096 → 8192
  - `call_executor`: 16384 → 32768
  - `call_with_tools`: 16384 → 32768
  - تحديث `config.yaml`
- **التأثير:** استفادة أفضل من قدرات النموذج

#### إيقاف animations الافتراضية
- **المشكلة:** animations تضيف تأخيراً حقيقياً (~5 ثوانٍ عند البدء)
- **الحل:** تغيير `animated=True` إلى `animated=False` في:
  - `show_banner()`
  - `rule()`
  - `header()`
  - `done()`
  - `fail()`
  - `warn()`
  - `task_start()`
- **التأثير:** تحسين كبير في سرعة الاستجابة

#### تبسيط فحص الأمان في tool_loop
- **المشكلة:** تكرار منطق الأمان بين `tool_loop.py` و `shell.py`
- **الحل:** إزالة الفحص المكرر والاعتماد الكامل على `shell.tool_shell()`
- **التأثير:** كود أنظف وأسهل صيانة

---

### 📝 ملفات معدلة

- `widdx/router.py` — إصلاح reasoning_content + thinking_mode + max_tokens
- `widdx/tool_loop.py` — إصلاح reasoning_content + تبسيط الأمان
- `widdx/tools/shell.py` — تطبيق whitelist كامل
- `widdx/git_ops.py` — إصلاح حساب الملفات
- `widdx/ui.py` — إيقاف animations
- `widdx/config.yaml` — تحديث thinking_mode + max_tokens

---

### 🧪 اختبارات

- إضافة `test_fixes.py` — اختبارات للتحقق من جميع الإصلاحات

---

### 📚 توثيق

- مراجعة شاملة لوثائق DeepSeek API الرسمية
- تأكيد توافق أسماء النماذج: `deepseek-v4-pro`, `deepseek-v4-flash`
- توثيق thinking mode parameters الصحيحة
- توثيق context window limits (1M input, 384K output)

---

### ⚠️ Breaking Changes

لا توجد breaking changes — جميع التغييرات متوافقة مع الإصدار السابق.

---

### 🙏 شكر خاص

- DeepSeek Team على API ممتاز ووثائق واضحة
- المجتمع على feedback والمساهمات

---

## [1.0.0] - 2026-04-24

### الإصدار الأولي

- دعم DeepSeek V4 (Pro & Flash)
- REPL تفاعلي على طراز Claude Code
- Tool loop مع function calling
- Pipeline متعدد المراحل للمهام المعقدة
- Dynamic agent generation
- SQLite memory store
- Evolution engine للتحسين الذاتي
- دعم كامل للعربية/RTL
- Git integration
- Project indexing
- Web search

---

**للمزيد من المعلومات:** راجع [QUICKSTART.md](QUICKSTART.md)
