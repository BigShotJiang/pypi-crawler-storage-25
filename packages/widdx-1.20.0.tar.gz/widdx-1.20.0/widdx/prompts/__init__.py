"""System prompt modules — per-mode persona prompts."""

from .vibe import VIBE_PROMPT
from .spec import SPEC_WORKFLOW_PROMPT

__all__ = ["VIBE_PROMPT", "SPEC_WORKFLOW_PROMPT"]
