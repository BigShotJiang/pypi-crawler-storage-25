"""Router streaming — token streaming and streaming tool calls.

Smart model routing: each step is classified (coding/review/logic/context)
and routed to the most appropriate model, falling back on failure.
"""
from __future__ import annotations


def call_streaming(self, system_prompt: str, user_message: str, max_tokens: int = 4096):
    """Stream tokens from the first available provider, preferring specialized model."""
    step_type = self._classify_step(user_message)
    providers = self._reorder_providers_for_step(step_type)
    errors: list[str] = []
    for provider in providers:
        model = self._model_for_provider(provider, "executor")
        try:
            stream = provider["client"].chat.completions.create(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                stream=True,
            )
            self._remember_provider(provider["name"], model)
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
            return
        except Exception as exc:
            errors.append(f"{provider['name']}: {exc}")
            continue
    yield "\nNo AI provider available. Add an API key with /key sk-..."


def call_with_tools_streaming(self, system_prompt: str, messages: list[dict],
                               tools: list[dict], max_tokens: int = 32768):
    """Streaming Function Calling — yields typed events for live display.

    Applies smart model routing: each step is classified (coding/review/logic/context)
    and routed to the most appropriate free model, falling back to others on failure.

    Yields events:
      {"type": "text", "content": "..."}
      {"type": "tool_call", "name": "...", "arguments": "...", "id": "..."}
      {"type": "done", "usage": {...}, "latency_ms": ..., "model": ..., "text": "..."}
      {"type": "error", "content": "..."}
    """
    import time

    from .tools_api import _build_api_tools

    # ── Classify this step for smart routing ─────────────────────────
    latest_user = ""
    for m in reversed(messages):
        if m.get("role") == "user":
            latest_user = str(m.get("content", ""))
            break
    step_type = self._classify_step(latest_user, len(messages))

    api_tools = _build_api_tools(tools)
    full_messages = [{"role": "system", "content": system_prompt}] + messages
    start = time.perf_counter()
    errors: list[str] = []

    ordered = self._reorder_providers_for_step(step_type)

    for provider in ordered:
        model = self._model_for_provider(provider, "executor")
        kwargs: dict = dict(
            model=model,
            max_tokens=max_tokens,
            messages=full_messages,
            tools=api_tools,
            tool_choice="auto",
            stream=True,
        )
        if provider.get("supports_thinking"):
            kwargs["extra_body"] = {"thinking": {"type": "disabled"}}
        try:
            stream = provider["client"].chat.completions.create(**kwargs)
            self._remember_provider(provider["name"], model)
            break
        except Exception as exc:
            errors.append(f"{provider['name']}: {exc}")
            continue
    else:
        yield {"type": "error", "content": "No AI provider available. Add an API key with /key sk-..."}
        return

    accumulated_text = ""
    accumulated_tool_calls: dict[int, dict] = {}
    final_usage = {}

    try:
        for chunk in stream:
            if chunk.choices is None or len(chunk.choices) == 0:
                continue

            delta = chunk.choices[0].delta

            if delta.content:
                accumulated_text += delta.content
                yield {"type": "text", "content": delta.content}

            if delta.tool_calls:
                for tc_delta in delta.tool_calls:
                    idx = tc_delta.index
                    if idx not in accumulated_tool_calls:
                        accumulated_tool_calls[idx] = {
                            "id": tc_delta.id or "",
                            "name": "",
                            "arguments": "",
                        }
                    tc = accumulated_tool_calls[idx]
                    if tc_delta.id:
                        tc["id"] = tc_delta.id
                    if tc_delta.function:
                        if tc_delta.function.name:
                            tc["name"] = tc_delta.function.name
                        if tc_delta.function.arguments:
                            tc["arguments"] += tc_delta.function.arguments

            if chunk.usage:
                final_usage = {
                    "input": chunk.usage.prompt_tokens or 0,
                    "output": chunk.usage.completion_tokens or 0,
                }

    except Exception as exc:
        yield {"type": "error", "content": f"Stream error: {exc}"}
        return

    elapsed_ms = int((time.perf_counter() - start) * 1000)

    for idx in sorted(accumulated_tool_calls.keys()):
        tc = accumulated_tool_calls[idx]
        if tc["name"]:
            yield {
                "type": "tool_call",
                "id": tc["id"],
                "name": tc["name"],
                "arguments": tc["arguments"],
            }

    yield {
        "type": "done",
        "text": accumulated_text,
        "usage": final_usage,
        "latency_ms": elapsed_ms,
        "model": model,
        "provider": provider["name"],
        "step_type": step_type,
    }
