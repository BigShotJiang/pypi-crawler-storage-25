"""Intent classifier — routes user input to chat / do / spec mode."""

from __future__ import annotations

import re
from typing import Literal

Mode = Literal["chat", "do", "spec"]

_SPEC_TRIGGERS = [
    r"\bspec\b", r"\bspecification\b",
    r"\brequirements?\b", r"\bdesign document\b",
    r"\bimplementation plan\b", r"\btask list\b",
    r"\bplan for\b", r"\b(my|the|a|our) plan\b",
    r"\barchitecture\b",
    r"\bcreate a spec", r"\bstart (a |the )?spec",
    r"\bnew feature", r"\bfeature design",
    r"\bexecute task", r"\bnext task",
    r"\bplease confirm\b", r"\bhere.s my plan\b",
    r"\bconfirm so I can proceed\b",
]

_CHAT_TRIGGERS = [
    r"^(hi|hello|hey|yo|sup|howdy)\b",
    r"\bhow are you\b",
    r"\bwhat'?s up\b",
    r"\bwhat can you do\b",
    r"\bwho are you\b",
    r"\btell me about yourself\b",
    r"\bgood (morning|afternoon|evening)",
    r"^(thank|thanks|thx|ty)\b",
    r"^(ok|okay|k|got it|understood)\b",
    r"^(haha|lol|nice|great|awesome)\b",
    r"\bwhat do you think\b",
    r"\bjust (chatting|talking|saying|checking)\b",
]


def classify(text: str, *, history: list[str] | None = None) -> Mode:
    """Classify user intent into chat/do/spec based on the message and optional history.

    Args:
        text: The latest user message.
        history: Previous user messages for context (e.g., ongoing spec).

    Returns:
        "spec" if the user is working on or creating a spec.
        "chat" for greetings, small talk, opinions, questions without code.
        "do" for everything else (default).
    """
    cleaned = text.strip().lower()

    # ── Spec mode ──────────────────────────────────────────────────
    for pat in _SPEC_TRIGGERS:
        if re.search(pat, cleaned):
            return "spec"

    # If history has spec context and user is continuing
    if history:
        last = history[-1].lower() if history else ""
        if "spec" in last and any(pat in cleaned for pat in ["yes", "ok", "looks good", "approved", "continue", "next", "task"]):
            return "spec"

    # ── Chat mode ──────────────────────────────────────────────────
    for pat in _CHAT_TRIGGERS:
        if re.search(pat, cleaned):
            # But if it also looks like a code request, prioritize do
            if _looks_like_code_request(cleaned):
                return "do"
            return "chat"

    # Questions that are purely conversational
    if re.match(r"^(what|why|how|when|where|who|which|can|could|would|should|is|are|do|does)\b", cleaned):
        if not _looks_like_code_request(cleaned) and not _mentions_files(cleaned):
            return "chat"

    # ── Do mode (default) ──────────────────────────────────────────
    return "do"


def _looks_like_code_request(text: str) -> bool:
    """Detect if text is asking for code/implementation."""
    code_verbs = [
        r"\b(write|create|make|build|implement|add|fix|update|change|edit|refactor|delete|remove)\b",
        r"\b(install|setup|configure|deploy|generate|scaffold)\b",
        r"\b(show|print|display|list|find|search|grep|read)\b",
        r"\bcode\b", r"\bfunction\b", r"\bclass\b", r"\bfile\b", r"\bproject\b",
        r"\bapp\b", r"\bapi\b", r"\bendpoint\b", r"\broute\b",
        r"\btest\b", r"\bdebug\b", r"\blint\b", r"\bformat\b",
    ]
    return any(re.search(v, text) for v in code_verbs)


def _mentions_files(text: str) -> bool:
    """Detect if text mentions files, paths, or the workspace."""
    patterns = [
        r"\b(in|at|to|from|of)\s+[\w./\\-]+\.[a-z]{1,4}\b",
        r"\b(src|dist|build|node_modules|app|public|docs)\b",
        r"\.(py|js|ts|jsx|tsx|html|css|json|yaml|toml|md)\b",
    ]
    return any(re.search(p, text) for p in patterns)
