"""Spec Workflow Manager — structured feature planning.

Stores specs in .widdx/specs/{feature_name}/
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _specs_dir() -> Path:
    p = Path.cwd() / ".widdx" / "specs"
    p.mkdir(parents=True, exist_ok=True)
    return p


def list_specs() -> list[dict[str, Any]]:
    """List all specs with metadata."""
    specs = []
    for d in sorted(_specs_dir().iterdir()):
        if d.is_dir():
            req = d / "requirements.md"
            design = d / "design.md"
            tasks = d / "tasks.md"
            specs.append({
                "name": d.name,
                "has_requirements": req.exists(),
                "has_design": design.exists(),
                "has_tasks": tasks.exists(),
                "phase": _detect_phase(req, design, tasks),
            })
    return specs


def _detect_phase(req: Path, design: Path, tasks: Path) -> str:
    if tasks.exists():
        return "tasks"
    if design.exists():
        return "design"
    if req.exists():
        return "requirements"
    return "new"


def get_spec(name: str) -> dict[str, str] | None:
    """Read a spec's documents."""
    d = _specs_dir() / name
    if not d.is_dir():
        return None
    result: dict[str, str] = {}
    for f in ["requirements.md", "design.md", "tasks.md"]:
        p = d / f
        if p.exists():
            result[f.replace(".md", "")] = p.read_text(encoding="utf-8")
    return result if result else None


def ensure_spec_dir(name: str) -> Path:
    """Create and return the spec directory for a feature."""
    d = _specs_dir() / name
    d.mkdir(parents=True, exist_ok=True)
    return d
