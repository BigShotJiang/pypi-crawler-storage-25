"""Execution pipeline — adaptive depth-gated pipeline with lightweight shortcut.

Depth levels:
  0-1: Simple ToolLoop only (no planning)
  2:   Plan + Execute (skip review/docs/deploy)
  3:   Spec + Arch + Plan + Execute + Verify (recommended for complex)
  4:   Full pipeline (review, docs, deploy, evolution)
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_SCAFFOLD_ENABLED = True


@dataclass
class PipelineResult:
    task_id: str
    intent: str
    complexity: int
    pipeline_depth: int
    plan: dict | None = None
    agents_generated: list = field(default_factory=list)
    execution_output: str = ""
    review_feedback: str = ""
    evolution_report: dict | None = None
    total_latency_ms: int = 0


# ── Inject methods from submodules ────────────────────────────────
from .execution import _execute_simple, _simple_system_prompt, _get_project_context  # noqa: E402
from .preflight import _run_preflight, _handle_missing_tools, _get_install_commands, _run_scaffolding  # noqa: E402
from .review import (  # noqa: E402
    _run_integration_test, _run_final_code_review,
    _run_documentation, _run_deployment_setup,
    _review_output, _consolidate_memory, _evolution_patch,
)
from .files import _extract_and_save, _validate_extracted_code  # noqa: E402
from .verify import verify_project  # noqa: E402


class ExecutionPipeline:
    """Adaptive pipeline: lightweight for simple tasks, full pipeline for complex ones."""

    # ── Injected methods ───────────────────────────────────────────
    _run_preflight = _run_preflight
    _handle_missing_tools = _handle_missing_tools
    _get_install_commands = staticmethod(_get_install_commands)
    _run_scaffolding = _run_scaffolding
    _execute_simple = _execute_simple
    _simple_system_prompt = _simple_system_prompt
    _get_project_context = _get_project_context
    _run_integration_test = _run_integration_test
    _run_final_code_review = _run_final_code_review
    _run_documentation = _run_documentation
    _run_deployment_setup = _run_deployment_setup
    _review_output = _review_output
    _consolidate_memory = _consolidate_memory
    _evolution_patch = _evolution_patch
    _extract_and_save = _extract_and_save
    _validate_extracted_code = _validate_extracted_code
    _verify_project = staticmethod(verify_project)

    # Complexity scores keyed by task type
    _TASK_TYPE_COMPLEXITY: dict[str, int] = {
        "build": 3,
        "fix": 2,
        "improve": 3,
        "design": 3,
        "general": 2,
    }

    _HIGH_SCOPE_KEYWORDS = frozenset([
        "fullstack", "complete", "entire", "whole system", "multi-page",
        "saas", "platform",
    ])

    def __init__(self, router, agent_factory, memory, evolution, config: dict[str, Any] | None = None,
                 pipeline_depth: int = 0) -> None:
        """Initialise the pipeline with router, agent factory, memory, and evolution components.

        Args:
            pipeline_depth: 0=auto (based on complexity), 1=simple, 2=plan+exec, 3=spec+verify, 4=full
        """
        self._router = router
        self._agent_factory = agent_factory
        self._memory = memory
        self._evolution = evolution
        cfg = config or {}
        self._complex_threshold = cfg.get("pipeline", {}).get("complex_threshold", 3)
        self._max_retries = 2
        self._scaffold_enabled = cfg.get("pipeline", {}).get("scaffold_enabled", _DEFAULT_SCAFFOLD_ENABLED)
        self._pipeline_depth = pipeline_depth

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def run(self, command: str) -> PipelineResult:
        """Execute the full pipeline for a given command and return the result."""
        task_id = uuid.uuid4().hex[:12]
        start = time.perf_counter()

        intent, complexity = self._analyze_input(command)
        self._memory.create_task(task_id, command, intent, complexity)

        if self._scaffold_enabled:
            preflight_ok = self._run_preflight(command)
            if not preflight_ok:
                elapsed_ms = int((time.perf_counter() - start) * 1000)
                return PipelineResult(
                    task_id=task_id, intent=intent, complexity=complexity,
                    pipeline_depth=0,
                    execution_output="Pre-flight check failed \u2014 missing required tools.",
                    total_latency_ms=elapsed_ms,
                )

        if self._scaffold_enabled:
            self._run_scaffolding(command)

        is_creation_task = bool(re.search(r'(?i)(save\s+to|write\s+file|create\s+file|output\s+to)\s+\S+\.\w+', command))
        depth = self._pipeline_depth or (4 if (complexity >= self._complex_threshold) and not is_creation_task else 1)
        depth = max(1, min(4, depth))

        if depth >= 2:
            from widdx.project_planner import ProjectPlanner
            fast_mode = depth <= 2
            planner = ProjectPlanner(self._router, self._memory, fast_mode=fast_mode)

            if depth >= 3:
                from widdx import ui
                ui.get_console().print("\n  [brand]\u25c6[/] [bold]Requirements Analysis[/]")
                spec_result = planner.create_spec(command, self._agent_factory)

                ui.get_console().print("\n  [brand]\u25c6[/] [bold]Architecture Design[/]")
                arch_result = planner.create_architecture(command, spec_result, self._agent_factory)
            else:
                spec_result = planner.create_spec(command, self._agent_factory)
                arch_result = None

            project_plan = planner.create_plan(command, complexity, spec_result, arch_result)
            self._memory.log_decision(task_id, "planning", "task_plan", command, str(project_plan.to_dict())[:500], "deepseek")

            # ── Show plan overview ────────────────────────────────
            from widdx import ui
            c = ui.get_console()
            total_phases = len(project_plan.phases)
            if total_phases > 0:
                c.print()
                c.print(f"  [bold primary]Plan:[/] [t1]{total_phases} phases[/]")
                for ph in project_plan.phases:
                    c.print(f"  [dim]  Phase {ph.number}:[/] [t2]{ph.title}[/]")
                c.print()
                c.print(f"  [dim]Agents:[/] [t3]{self._agent_factory.list_agents() if self._agent_factory else 'auto-assigned'}[/]")
                provider = self._router._last_provider or "auto"
                model = self._router._last_model or "auto"
                c.print(f"  [dim]Provider:[/] [t3]{provider} / {model}[/]")
                c.print()

            planner.execute_plan(project_plan, self._agent_factory)
            done_count = sum(1 for p in project_plan.phases if p.status == "done")
            total_phases = len(project_plan.phases)
            execution_output = (
                f"Plan '{project_plan.id}': {done_count}/{total_phases} phases completed"
                + (" — all done" if done_count == total_phases else f" — {total_phases - done_count} remaining")
            )

            all_files = []
            for phase in project_plan.phases:
                all_files.extend(phase.files_created)
                all_files.extend(phase.files_edited)
            all_files = list(dict.fromkeys(all_files))

            if depth >= 3:
                from widdx.verifier import ProjectVerifier
                verifier = ProjectVerifier(router=self._router)
                verify_result = verifier.verify_pipeline(all_files)
                if not verify_result.passed:
                    execution_output += (
                        "\n\n## Verification\n"
                        f"Status: FAILED after {verify_result.fix_attempts} fix attempts\n"
                        f"Errors: {chr(10).join(verify_result.errors[:5])}"
                    )

                from widdx import ui
                c = ui.get_console()
                c.print("  [brand]\u25c6[/] [bold]Static Analysis[/]")
                issues = self._verify_project(Path.cwd())
                if issues:
                    error_count = sum(1 for i in issues if i.severity == "error")
                    warn_count = sum(1 for i in issues if i.severity == "warning")
                    c.print(f"  [warning]\u26a0[/] {error_count} error(s), {warn_count} warning(s)")
                    for issue in issues:
                        icon = "[error]\u2717[/]" if issue.severity == "error" else "[warning]\u26a0[/]"
                        c.print(f"    {icon} {issue.file}:{issue.line} — {issue.message}")
                    execution_output += (
                        "\n\n## Static Analysis\n"
                        f"Issues: {error_count} error(s), {warn_count} warning(s)\n"
                        + "\n".join(f"- [{i.severity}] {i.file}:{i.line}: {i.message}" for i in issues)
                    )
                else:
                    c.print("  [success]\u2713[/] No issues found")
            else:
                verifier = None

            if depth >= 3:
                self._run_integration_test(command)
                ui.get_console().print("  [success]\u2713[/] Integration tests passed")

                if verifier:
                    build_result = verifier.verify_build()
                    if build_result["passed"]:
                        pass
                    elif build_result["output"]:
                        execution_output += (
                            f"\n\n## Build Check\n"
                            f"Status: {build_result['status']}\n"
                            f"{build_result['output'][:500]}"
                        )

            review = ""
            evo_report = None
            if depth >= 4:
                review = self._run_final_code_review(command, all_files)
                self._run_documentation(command, project_plan)
                self._run_deployment_setup(command)

                self._consolidate_memory(task_id, command, execution_output, review)
                evo_report = self._evolution_patch(task_id, command, complexity)

            agents_generated: list = []
        else:
            result = self._execute_simple(command, task_id)
            plan = None
            agents_generated = []
            execution_output = result.get("text", "")
            review = ""
            evo_report = None

            if self._is_error(result):
                execution_output = f"API Error: {result.get('error', 'unknown error')}"
                self._memory.complete_task(task_id, "failed")
            else:
                self._memory.complete_task(task_id)

        saved_files = self._extract_and_save(command, execution_output)

        total_ms = int((time.perf_counter() - start) * 1000)
        plan_value = project_plan if depth >= 2 else plan
        return PipelineResult(
            task_id=task_id,
            intent=intent,
            complexity=complexity,
            pipeline_depth=depth,
            plan=plan_value,
            agents_generated=agents_generated,
            execution_output=execution_output if not saved_files else execution_output + "\n\n" + saved_files,
            review_feedback=review,
            evolution_report=evo_report,
            total_latency_ms=total_ms,
        )

    # ------------------------------------------------------------------
    # Core analysis helpers
    # ------------------------------------------------------------------

    def _analyze_input(self, command: str) -> tuple[str, int]:
        """Classify complexity using the router's existing keyword logic."""
        lowered = command.lower()

        if any(kw in lowered for kw in self._HIGH_SCOPE_KEYWORDS):
            return command, 4

        task_type = self._router.infer_task_type(command)
        complexity = self._TASK_TYPE_COMPLEXITY.get(task_type, 1)

        if task_type == "general":
            system = "Classify this request in <=5 words. Return JSON only: {\"intent\": \"...\", \"complexity\": 1-5}"
            result = self._router.call_executor(system, command, max_tokens=64)
            if not self._is_error(result):
                try:
                    data = json.loads(_extract_json(result["text"]))
                    return data.get("intent", command), min(5, max(1, data.get("complexity", 1)))
                except (json.JSONDecodeError, ValueError, KeyError):
                    pass

        return command, complexity

    def _is_error(self, result: dict) -> bool:
        """Check if a router result dict represents an error."""
        return "error" in result

    def _is_retryable(self, result: dict) -> bool:
        """Only retry on transient errors, not permanent ones like missing API keys."""
        msg = result.get("error", "")
        non_retryable = {"API_KEY not set", "Incorrect API key", "Authentication failed", "invalid api key"}
        return not any(indicator.lower() in msg.lower() for indicator in non_retryable)


# ------------------------------------------------------------------
# Standalone helper: JSON extraction from LLM output
# ------------------------------------------------------------------

def _extract_json(text: str) -> str:
    """Extract JSON from LLM output using brace-depth tracking."""
    cleaned = re.sub(
        r"```(?:json|javascript|python|yaml|toml)?\s*\n(.*?)\n\s*```",
        r"\1",
        text,
        flags=re.DOTALL,
    ).strip()
    cleaned = re.sub(
        r"```(?:json)?\s*(.*?)\s*```",
        r"\1",
        cleaned,
        flags=re.DOTALL,
    ).strip()

    brace_stack: list[str] = []
    json_start = -1
    for i, ch in enumerate(cleaned):
        if ch == "{":
            if not brace_stack:
                json_start = i
            brace_stack.append(ch)
        elif ch == "}":
            if brace_stack:
                brace_stack.pop()
                if not brace_stack and json_start >= 0:
                    candidate = cleaned[json_start : i + 1]
                    if "{" in candidate and "}" in candidate:
                        return candidate

    bracket_stack: list[str] = []
    json_start = -1
    for i, ch in enumerate(cleaned):
        if ch == "[":
            if not bracket_stack:
                json_start = i
            bracket_stack.append(ch)
        elif ch == "]":
            if bracket_stack:
                bracket_stack.pop()
                if not bracket_stack and json_start >= 0:
                    return cleaned[json_start : i + 1]

    return cleaned
