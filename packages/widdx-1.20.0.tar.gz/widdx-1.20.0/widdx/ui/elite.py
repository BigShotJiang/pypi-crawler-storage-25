"""WIDDX Elite — ultra-minimal professional terminal UI."""

from __future__ import annotations

import random
import time
from datetime import datetime

from rich.align import Align
from rich.box import ROUNDED, SIMPLE
from rich.columns import Columns
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.rule import Rule
from rich.spinner import Spinner
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from .theme import get_console


# ── Dividers ───────────────────────────────────────────────────────────

def hr(style: str = "dim") -> Rule:
    return Rule(style=style)

def gap(n: int = 1) -> None:
    for _ in range(n):
        get_console().print()


# ── Message Bubbles (minimal, clean) ──────────────────────────────────

def user_bubble(text: str) -> None:
    c = get_console()
    c.print(f"  [dim]──[/] [text]{text}[/]")

def ai_bubble(text: str, role: str = "") -> None:
    c = get_console()
    c.print(f"  {text}")

def system_bubble(text: str) -> None:
    c = get_console()
    c.print(f"  [warning]{text}[/]")


# ── Tool Execution ────────────────────────────────────────────────────

def tool_anim(tools: list[str]) -> None:
    c = get_console()
    for t in tools:
        with Live(Text(f"  {t}...", style="dim"), console=c,
                  refresh_per_second=10, transient=True):
            time.sleep(random.uniform(0.1, 0.3))

def thinking_spinner(seconds: float = 1.0) -> None:
    c = get_console()
    with Live(
        Spinner("dots", text=Text("thinking", style="dim"), style="brand"),
        console=c, refresh_per_second=10, transient=True,
    ):
        time.sleep(seconds)


# ── Live Dashboard ─────────────────────────────────────────────────────

def dashboard_layout() -> Layout:
    layout = Layout()
    layout.split_column(Layout(name="header", size=3), Layout(name="body"), Layout(name="footer", size=3))
    layout["body"].split_row(Layout(name="left"), Layout(name="right"))
    return layout

def dash_header(title: str = "") -> Panel:
    return Panel(Text(title, justify="center", style="bold brand"), style="brand")

def dash_metrics(data: dict) -> Panel:
    t = Table(box=None, show_header=False, padding=(0, 2))
    t.add_column("k", style="muted", min_width=12)
    t.add_column("v", style="bold text")
    for k, v in data.items():
        t.add_row(k, str(v))
    return Panel(t, title="[bold brand]Metrics[/]", border_style="brand")

def dash_log(lines: list[str]) -> Panel:
    txt = Text()
    for line in lines[-20:]:
        if "[ERROR]" in line:
            txt.append(line + "\n", style="error")
        elif "[WARN]" in line:
            txt.append(line + "\n", style="warning")
        else:
            txt.append(line + "\n", style="muted")
    return Panel(txt, title="[bold]Log[/]", border_style="dim")

def dash_board(items: list[dict]) -> Columns:
    panels = []
    for item in items:
        color = "success" if item.get("status") == "done" else "warning"
        content = Text()
        content.append("Status: ", style="muted")
        content.append(item.get("status", "?"), style=f"bold {color}")
        panels.append(Panel(content, title=f"[bold]{item['name']}[/]", border_style=color, width=24))
    return Columns(panels)

def dash_progress(tasks: list[dict]) -> Progress:
    return Progress(
        SpinnerColumn(), TextColumn("[bold]{task.description:<20}"), BarColumn(bar_width=30),
        TextColumn("{task.completed:>3}/{task.total}"), TimeElapsedColumn(),
        console=get_console(), refresh_per_second=10,
    )

def dash_run(update_fn, refresh: float = 0.25) -> None:
    layout = dashboard_layout()
    c = get_console()
    try:
        with Live(layout, refresh_per_second=4, screen=True, console=c) as live:
            while True:
                update_fn(layout)
                time.sleep(refresh)
    except (KeyboardInterrupt, SystemExit):
        c.print()
        c.print(hr(style="dim"))
        c.print(Align.center(Text("Dashboard closed", style="muted")))


# ── Boot Screen (ultra minimal) ────────────────────────────────────────

def elite_boot(framework: str = "python", files: int = 0,
               version: str = "1.15.0", model: str = "") -> None:
    c = get_console()
    c.print(f"  [brand]widdx[/] [dim]{version}[/]")
    c.print()


# ── Chat Welcome (minimal) ─────────────────────────────────────────────

def welcome(framework: str, files: int) -> None:
    c = get_console()
    c.print(f"  [dim]Ready. [/][brand]/help[/][dim] for commands.[/]")


# ── Status Messages ───────────────────────────────────────────────────

def ok(msg: str) -> None:
    get_console().print(f"  [success]{msg}[/]")

def fail(msg: str) -> None:
    get_console().print(f"  [error]{msg}[/]")

def warn(msg: str) -> None:
    get_console().print(f"  [warning]{msg}[/]")


# ── Tool Calling ──────────────────────────────────────────────────────

_TOOLS = {
    "read": ("r", "tool_read"),
    "write": ("w", "tool_write"),
    "shell": ("$", "tool_shell"),
    "web": ("@", "tool_web"),
    "search": ("s", "tool_read"),
    "git": ("g", "tool_write"),
}

def tool(name: str, detail: str = "") -> str:
    nl = name.lower()
    for k, (icon, color) in _TOOLS.items():
        if k in nl:
            return f"  [dim]{icon}[/] [{color}]{name}[/][dim]{' ' + detail if detail else ''}[/]"
    return f"  [dim]·[/] [info]{name}[/][dim]{' ' + detail if detail else ''}[/]"


# ── Syntax Highlighting ────────────────────────────────────────────────

def code(code_str: str, lang: str = "python", title: str = "") -> Panel:
    return Panel(Syntax(code_str, lang, theme="monokai", line_numbers=True),
                 title=f"[dim]{title}[/]" if title else None,
                 title_align="left", border_style="dim", box=ROUNDED, padding=(1, 2))


# ── Help Table ─────────────────────────────────────────────────────────

def help_table(commands: dict) -> None:
    c = get_console()
    t = Table(title="[bold brand]Commands[/]", border_style="dim", header_style="bold warning", box=SIMPLE)
    t.add_column("Command", style="bold brand", min_width=14)
    t.add_column("Description", style="text")
    for cmd, desc in commands.items():
        t.add_row(cmd, desc)
    c.print(t)


# ── File Tree ──────────────────────────────────────────────────────────

def file_tree(paths: list[str], root_name: str = "project") -> Tree:
    tree = Tree(f"[bold brand]{root_name}/[/]")
    by_dir: dict[str, list[str]] = {}
    for p in sorted(paths):
        parts = p.replace("\\", "/").split("/")
        d = "/".join(parts[:-1]) if len(parts) > 1 else "."
        by_dir.setdefault(d, []).append(parts[-1])
    for d, files in sorted(by_dir.items()):
        node = tree
        if d != ".":
            for part in d.split("/"):
                node = next((c for c in node.children if c.label and part in str(c.label)),
                           node.add(f"[info]{part}/[/]"))
        for f in files[:20]:
            ext = f.rsplit(".", 1)[-1] if "." in f else ""
            icon = {"py": ".py", "js": ".js", "ts": ".ts", "md": ".md", "json": ".json", "yaml": ".yaml"}.get(ext, ".")
            node.add(f"[muted]{icon}[/] {f}")
    return tree
