"""WIDDX Terminal UI — unified modern professional theme."""
from __future__ import annotations

import logging
import subprocess as _sp
import sys

logger = logging.getLogger(__name__)

from rich.console import Console
from rich.theme import Theme

# ── Unified modern palette ───────────────────────────────────────────
# Professional color system — no "bold" in values so components can
# apply bold selectively via [bold primary] or [bold success].
WIDDX_THEME = Theme({
    # Core brand colors
    "brand":      "#5E9EFF",    # Electric blue
    "primary":    "#5E9EFF",    # Same as brand
    "secondary":  "#A78BFA",    # Soft purple
    "highlight":  "#5E9EFF",    # Same as brand

    # Semantic
    "success":    "#00c896",    # Teal green
    "error":      "#F87171",    # Soft red
    "warning":    "#f5a623",    # Amber
    "info":       "#7b7bff",    # Periwinkle
    "accent":     "#A78BFA",    # Soft purple

    # Text hierarchy
    "text":       "#F1F5F9",    # Primary text (light)
    "muted":      "#94A3B8",    # Secondary text
    "dim":        "#64748B",    # Tertiary / muted

    # Syntax highlighting
    "code":       "#f9e2af",    # Yellow
    "keyword":    "#89b4fa",    # Blue
    "string":     "#a6e3a1",    # Green

    # Tool categories
    "tool_read":  "#7b7bff",    # Periwinkle
    "tool_write": "#00c896",    # Teal
    "tool_shell": "#f5a623",    # Amber
    "tool_web":   "#A78BFA",    # Purple
})

_console: Console | None = None
_no_color = False


def configure_console(no_color: bool = False) -> None:
    """Configure global console options before the first console is created."""
    global _console, _no_color
    _no_color = no_color
    _console = None


def _enable_windows_ansi() -> None:
    """Enable ANSI escape sequence processing on Windows terminals.

    On CMD and older terminals, ANSI codes appear as raw text unless
    ENABLE_VIRTUAL_TERMINAL_PROCESSING is set via the Windows API.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        for handle in (-11, -12):  # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            h = kernel32.GetStdHandle(handle)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(h, ctypes.byref(mode)):
                mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
                kernel32.SetConsoleMode(h, mode.value)
    except Exception:
        logger.debug("Failed to enable Windows ANSI virtual terminal processing", exc_info=True)


def get_console() -> Console:
    global _console
    if _console is None:
        if sys.platform == "win32":
            _enable_windows_ansi()
            _sp.run(["cmd", "/c", "chcp 65001"], check=False,
                    stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
            try:
                sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
                sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
            except Exception:
                pass
        _console = Console(
            theme=WIDDX_THEME,
            highlight=False,
            width=120,
            soft_wrap=True,
            force_terminal=True,
            no_color=_no_color,
            legacy_windows=False,
            color_system=None if _no_color else "truecolor",
            safe_box=True,
        )
    return _console
