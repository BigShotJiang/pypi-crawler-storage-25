"""Tool loop display — ultra-minimal professional terminal output."""

from __future__ import annotations

import difflib
import os
import sys

from ..ui.arabic import _d


def _get_console():
    from .. import ui
    return ui.get_console()


def _reshape_line(text: str) -> str:
    return _d(text)


def _short_path(path: str) -> str:
    parts = path.replace("\\", "/").split("/")
    return "/".join(parts[-2:]) if len(parts) > 2 else path


def _short_path_display(path: str) -> str:
    return _short_path(path)


# ── Terminal capability detection ──────────────────────────────────

def _supports_unicode() -> bool:
    term_prog = os.environ.get("TERM_PROGRAM", "")
    wt_session = os.environ.get("WT_SESSION", "")
    if wt_session:
        return True
    if any(p.lower() in term_prog.lower() for p in ("vscode", "WarpTerminal", "iTerm.app", "Windows Terminal", "Tabby", "Ghostty")):
        return True
    if sys.platform == "win32" and not wt_session:
        return False
    return True


_UNICODE_OK: bool | None = None

def _unicode_ok() -> bool:
    global _UNICODE_OK
    if _UNICODE_OK is None:
        _UNICODE_OK = _supports_unicode()
    return _UNICODE_OK


# ── Tool → icon mapping ────────────────────────────────────────────

_TOOL_META: dict[str, tuple[str, str, str]] = {
    "Read":      ("\u2192", "READ",  "tool_read"),
    "ListDir":   ("\u2192", "DIR",   "tool_read"),
    "Glob":      ("\u2192", "FIND",  "tool_read"),
    "Grep":      ("\u2192", "GREP",  "tool_read"),
    "WebSearch": ("\u2192", "WEB",   "tool_web"),
    "Write":     ("\u2192", "WRITE", "tool_write"),
    "Edit":      ("\u2192", "EDIT",  "tool_shell"),
    "Bash":      ("\u2192", "RUN",   "tool_shell"),
}

def _tool_icon(name: str) -> str:
    meta = _TOOL_META.get(name, ("\u2192", "TOOL", "brand"))
    return meta[0] if _unicode_ok() else f"[{meta[1]}]"

def _tool_style(name: str) -> str:
    return _TOOL_META.get(name, ("\u2192", "TOOL", "brand"))[2]


def _tool_label(name: str, args: dict) -> str:
    if name == "Read":
        fp = args.get("file_path", "")
        offset = args.get("offset", 0)
        limit = args.get("limit", -1)
        suffix = f":{offset}" if offset else ""
        suffix += f"+{limit}" if (limit and limit != -1) else ""
        return f"{_short_path(fp)}{suffix}"
    if name in ("Write", "Edit"):
        return _short_path(args.get("file_path", ""))
    if name == "Grep":
        pat = args.get("pattern", "")
        return f'"{pat[:40]}{"…" if len(pat) > 40 else ""}"'
    if name == "Glob":
        return args.get("pattern", "")
    if name == "Bash":
        cmd = args.get("command", "")
        return f'"{cmd[:50]}{"…" if len(cmd) > 50 else ""}"'
    if name == "WebSearch":
        q = args.get("query", "")
        return f'"{q[:40]}{"…" if len(q) > 40 else ""}"'
    if name == "ListDir":
        return _short_path(args.get("path", "."))
    if name.startswith("mcp__"):
        parts = name[5:].split("__", 1)
        return parts[1] if len(parts) > 1 else ""
    return ""


def print_tool_call(name: str, args: dict) -> None:
    """Single clean line for tool call."""
    c = _get_console()
    style = _tool_style(name)
    verb = _action_verb(name).lower()
    label = _tool_label(name, args)
    c.print(f"  [{style}]{verb}[/] [dim]{label}[/]")


def _action_verb(name: str) -> str:
    verbs = {
        "Read":  "read", "Write": "write", "Edit": "edit",
        "Bash":  "run", "Grep": "grep", "Glob": "glob",
        "ListDir": "list", "WebSearch": "search",
    }
    if name.startswith("mcp__"):
        return name[5:].split("__", 1)[0]
    return verbs.get(name, name)


def print_tool_result(name: str, output: dict) -> None:
    """Minimal result line."""
    c = _get_console()
    if "error" in output:
        c.print(f"  [error]! {output['error'][:100]}[/]")
        return
    hint = _tool_hint(name, output)
    if hint:
        c.print(f"  [dim]  {hint}[/]")


def _tool_hint(name: str, output: dict) -> str:
    if "error" in output:
        return f"Error: {output['error'][:100]}"
    if name == "Read":
        lines = output.get("total_lines", 0)
        return f"{lines} lines" if lines else ""
    if name == "Write":
        written = output.get("written", 0)
        return f"{_fmt_bytes(written)} · {output.get('status', 'created')}"
    if name == "Edit":
        n = output.get("replacements", 1)
        return f"{n} replacement{'s' if n != 1 else ''}"
    if name == "Grep":
        count = output.get("count", 0)
        return f"{count} matches" if count else ""
    if name == "Glob":
        count = output.get("count", 0)
        return f"{count} files" if count else ""
    if name == "Bash":
        code = output.get("exit_code", 0)
        stdout = (output.get("stdout") or "").strip()
        if code == 0 and not stdout:
            return "ok"
        if code == 0:
            return stdout.split("\n")[0][:100]
        stderr = (output.get("stderr") or "").strip()
        return f"exit {code}"
    if name == "WebSearch":
        count = output.get("count", 0)
        return f"{count} results" if count else ""
    if name == "ListDir":
        count = output.get("count", 0)
        return f"{count} items" if count else ""
    return ""


def _fmt_bytes(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f}KB"
    return f"{n / (1024 * 1024):.1f}MB"


def _render_diff(old_content: str, new_content: str, file_path: str) -> None:
    c = _get_console()
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = list(difflib.unified_diff(old_lines, new_lines,
                                     fromfile=file_path, tofile=file_path, n=2))
    if not diff:
        return

    removed = added = 0
    max_each = 5
    total_delta = sum(1 for ln in diff if ln.startswith(("+", "-")) and not ln.startswith(("---", "+++")))

    for line in diff:
        if line.startswith(("---", "+++", "@@")):
            continue
        stripped = line[1:].rstrip()[:100]
        if line.startswith("-") and removed < max_each:
            c.print(f"  [red]- {stripped}[/]")
            removed += 1
        elif line.startswith("+") and added < max_each:
            c.print(f"  [green]+ {stripped}[/]")
            added += 1

    total_shown = removed + added
    if total_delta > total_shown:
        c.print(f"  [dim]  … {total_delta - total_shown} more changes[/]")


def _summarize_final(self) -> str:
    for m in reversed(self._messages):
        if m["role"] == "assistant" and isinstance(m.get("content"), str) and m["content"]:
            return str(m["content"])
    return ""


def _format_result(self, text: str, elapsed: float, steps: int,
                   *, use_markdown: bool = True) -> str:
    """Clean metrics footer."""
    c = _get_console()

    if use_markdown and text:
        from .. import ui
        ui.render_markdown(_d(text))

    tokens_in  = getattr(self._router, "_session_input_tokens", 0)
    tokens_out = getattr(self._router, "_session_output_tokens", 0)
    total_tok  = tokens_in + tokens_out
    cost       = getattr(self._router, "_session_cost", 0.0)
    elapsed_ms = int(elapsed * 1000)
    n_tools    = getattr(self, "_tool_calls_count", 0)

    parts: list[str] = []
    if total_tok > 0:
        tok_str = f"{total_tok / 1000:.1f}k" if total_tok >= 1000 else str(total_tok)
        parts.append(f"{tok_str} tokens")
    if cost > 0:
        parts.append(f"${cost:.6f}")
    if elapsed_ms > 0:
        if elapsed_ms < 1000:
            parts.append(f"{elapsed_ms}ms")
        elif elapsed_ms < 60_000:
            parts.append(f"{elapsed_ms / 1000:.1f}s")
        else:
            parts.append(f"{elapsed_ms / 60_000:.1f}m")
    if n_tools > 0:
        parts.append(f"{n_tools} tool{'s' if n_tools != 1 else ''}")

    if parts:
        c.print(f"  [dim]── {' · '.join(parts)}[/]")

    return text
