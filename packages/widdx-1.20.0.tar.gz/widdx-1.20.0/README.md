<div align="center">

<img src="assets/widdx_logo.svg" alt="WIDDX CLI" width="550"/>

# ⚡ WIDDX CLI

### 🤖 Autonomous AI Software Engineering Terminal

**🚀 DeepSeek V4 + Google Gemini + 5 Free Models — No API Key Required**

<br/>

[![PyPI version](https://img.shields.io/pypi/v/widdx?style=flat-square&color=00e5a0&label=PyPI)](https://pypi.org/project/widdx/)
[![Python](https://img.shields.io/badge/Python-3.10+-blue?style=flat-square&logo=python&logoColor=white)](https://www.python.org/)
[![Version](https://img.shields.io/badge/Version-1.18.5-brightgreen?style=flat-square)](CHANGELOG.md)
[![License](https://img.shields.io/badge/License-Proprietary-red?style=flat-square)](LICENSE)
[![Tests](https://img.shields.io/badge/Tests-1,299%20passed-brightgreen?style=flat-square)](tests/)
[![Platforms](https://img.shields.io/badge/Platform-Windows%20%7C%20macOS%20%7C%20Linux-orange?style=flat-square)]()
[![Downloads](https://img.shields.io/pypi/dm/widdx?style=flat-square&color=blue)](https://pypi.org/project/widdx/)

<br/>

```bash
pip install widdx && python -m widdx
```

*✨ One command. No config. No API key needed.*

<br/>

[🌟 Features](#-features) · [📦 Install](#-installation) · [🖥️ Usage](#️-usage) · [🤖 Agents](#-agents) · [🛠️ Skills](#️-skills) · [🧠 Specs](#️-spec-driven-development) · [🏗️ Architecture](#️-architecture) · [🔒 Security](#-security) · [عربي](#arabic)

</div>

---

## 🌟 Overview

WIDDX is a fully autonomous AI software engineering environment that runs in your terminal. It orchestrates specialized AI agents to plan, build, test, and self-correct code — understanding your intent before executing.

- **🧠 Intent-aware** — classifies every message as `chat` / `do` / `spec` before responding
- **🎭 Vibe persona** — talks like a developer, not a bot; friendly, concise, professional
- **📋 Spec-driven development** — Requirements → Design → Tasks workflow for complex features
- **✅ Zero config** — works without an API key using 5 free models from opencode.ai

---

## ✨ Features

### 🧠 Intent-Aware Architecture (v1.18+)

Every user message is classified into one of three modes:

| Mode | Trigger | Behavior |
|------|---------|----------|
| 💬 **Chat** | Greetings, questions, opinions | Direct response, no tools, conversational |
| ⚡ **Do** | Code changes, commands, builds | Full tool loop with planning and verification |
| 📋 **Spec** | "create a spec", "plan the feature" | Structured Requirements → Design → Tasks workflow |

The system prompt adapts per-mode — Vibe persona for chat/do, Spec workflow for planning.

### 📋 Spec-Driven Development (`/spec`)

Build complex features with structured planning:

```
/spec auth-system          → Start a new spec

Phase 1: Requirements      → EARS format user stories + acceptance criteria
Phase 2: Design            → Architecture, components, data models, Mermaid diagrams
Phase 3: Tasks             → Numbered checklist with requirement references
Phase 4: Execute           → One task at a time with user review
```

All specs stored in `.widdx/specs/{feature_name}/` — requirements.md, design.md, tasks.md.

### 🔀 Intelligent Multi-Provider Routing

| Plan | Trigger | Models |
|------|---------|--------|
| 🟢 **Plan A** | DeepSeek key | `deepseek-v4-pro` + `deepseek-v4-flash` |
| 🟡 **Plan B** | Google key | `gemini-2.5-pro` + `gemini-2.5-flash` |
| 🔵 **Plan C** | No API key | 5 free models via opencode.ai |

Automatic fallback on rate limits, quota exhaustion, or server errors.

### ✅ Verification & Self-Correction

```
📝 Write/Edit Code
    └─► 🔍 Syntax Check ──FAIL──► 🔧 Auto-fix (max 3 attempts)
              │ PASS
         🧪 Run Tests ──FAIL──► 🔧 Fix + Retest (max 3 attempts)
              │ PASS
             ✅ Done
```

### 🖥️ Professional Terminal UI

- ⚡ **Unified modern theme** — electric blue, teal, purple palette
- 💬 Message bubbles with timestamps (user / AI / system)
- 📝 Live Markdown streaming with syntax highlighting
- 🔔 Toast notifications + bell on completion
- 🌍 Full Arabic RTL support
- 🖥️ Auto-detects 14 terminal types

### 🎁 Additional Capabilities

| Feature | Description |
|---------|-------------|
| 🧠 **Memory & Learning** | SQLite-backed memory, self-learning engine, cached fix patterns |
| 🔌 **MCP Protocol** | Built-in servers + external stdio & HTTP, GitHub integration |
| 🪝 **Hooks System** | PreToolUse / PostToolUse / SessionStart / TaskCompleted |
| ⏰ **Scheduler** | Cron-based task scheduling with persistence |
| 🔭 **Bootstrapper** | `/bootstrap <tech>` researches docs, generates skills + agents |
| 🌐 **Web UI** | FastAPI + SSE on `localhost:8520` (`pip install widdx[web]`) |
| 🧠 **Semantic Search** | Local RAG: sentence-transformers + SQLite — zero API cost |
| 💻 **Cross-Platform** | Windows · macOS · Linux |

---

## 📦 Installation

```bash
pip install widdx
python -m widdx
```

Optional: add API keys for higher quality via `/key` or environment variables:

```bash
export DEEPSEEK_API_KEY="sk-..."     # DeepSeek V4
export GOOGLE_API_KEY="AIza..."      # Google Gemini
```

---

## 🖥️ Usage

```bash
widdx                          # Interactive REPL
widdx "fix the auth bug"       # Run a task directly
```

### Commands

| Command | Description |
|---------|-------------|
| 📋 `/spec [name]` | List specs or start a new feature spec |
| 🔀 `/providers` | Interactive provider manager |
| 🎯 `/provider <name>` | Switch to one provider |
| 🔭 `/bootstrap <tech>` | Research + generate skills/agents/hooks |
| 👥 `/agents <task>` | Multi-agent team on complex task |
| 🗺️ `/plan <desc>` | Phased project plan |
| 🛠️ `/skills` | List available skills |
| 🪝 `/hooks` | Show registered hooks |
| 🔌 `/mcp` | Manage MCP servers |
| 📚 `/learn` | Self-learning ledger |
| 🔍 `/knowledge <query>` | Search project memory |
| 📦 `/compact` | Summarize conversation to save tokens |
| 🤖 `/model` | Current model and session cost |
| 📋 `/tasks` | Task execution history |
| 🌿 `/git` | Git status |
| 🔎 `/search <query>` | Search codebase |
| ↩️ `/undo` | Undo last file change |
| 💾 `/save <name>` | Save session |
| 🧹 `/clear` | Clear conversation |
| 🖥️ `widdx web` | Start Web UI |
| 🔄 `widdx self-upgrade` | Clean upgrade |
| ✅ `/self-check` | Full system diagnostics |
| ❓ `/help` | Show help |

---

## 🤖 Agents

12 specialized agents built in:

| Agent | Specialization |
|-------|----------------|
| 🏗️ Software Architect | System design, API contracts |
| ⚙️ Backend Developer | API development |
| 🎨 Frontend Developer | React, Vue, TypeScript |
| 🐘 Laravel Architect | PHP, Eloquent, Blade, Artisan |
| 🐳 DevOps Automator | Docker, CI/CD, Kubernetes |
| 🔬 QA Engineer | Testing, code review |
| 🛡️ Security Reviewer | OWASP Top 10 |
| 📊 Data Engineer | ETL, query optimization |
| 🗄️ Database Architect | Schema design, migrations |
| 🏛️ Systems Architect | Cross-service architecture |
| 👁️ Code Reviewer | Code feedback |
| ⚡ Full-Stack Developer | End-to-end features |

---

## 🛠️ Skills

17 built-in skills:

```
code-review  tdd-workflow  bugfix       feat-dev
security     api-design    deploy       db-migrate
ui-design    docs          refactor     debug
laravel      testing       database     caching
queue-jobs
```

Custom skills via `.widdx/skills/` or auto-generated via `/bootstrap`.

---

## 🏗️ Architecture

```
widdx-cli/
├── widdx/
│   ├── cli.py                 # CLI entry
│   ├── classifier.py           # Intent classifier (chat/do/spec)
│   ├── prompts/               # Mode-specific system prompts
│   │   ├── vibe.py            # Chat/do persona
│   │   └── spec.py            # Spec workflow prompt
│   ├── spec_workflow/         # Spec-driven development manager
│   ├── router/                # Multi-provider routing
│   ├── pipeline/              # 7-step execution pipeline
│   ├── memory/                # SQLite memory store
│   ├── agent_factory/         # Team generation + parallel execution
│   ├── skills/                # 17 built-in skills
│   ├── hooks/                 # Event system
│   ├── verifier/              # 3-level verification + auto-fix
│   ├── repl/                  # Interactive REPL
│   ├── tool_loop/             # Tool execution loop
│   ├── mcp/                   # MCP Protocol
│   ├── tools/                 # Local tools
│   ├── scaffolder/            # Project scaffolding
│   ├── ui/                    # Rich terminal UI (unified theme)
│   ├── web/                   # FastAPI + SSE frontend
│   ├── semantic_index.py      # Local RAG (sentence-transformers + SQLite)
│   └── repair_memory.py       # Cached fix patterns
└── tests/                     # 1,299+ tests
```

---

## ⚙️ Configuration

`~/.widdx/config.yaml`:

```yaml
models:
  architect:
    model: deepseek-v4-pro
  executor:
    model: deepseek-v4-flash
    max_tokens: 32768

pipeline:
  complex_threshold: 3

memory:
  db_path: ~/.widdx/memory.db
```

---

## 🧪 Testing

```bash
pytest tests/ -v
pytest tests/ --cov=widdx --cov-report=term-missing
```

---

## 🔒 Security

- 🚫 No `shell=True` — agent commands use parsed argument lists
- 🔐 Config files restricted to owner read/write (600)
- 🛡️ Hooks security checker blocks dangerous commands
- 📋 Full audit logging for traceability

---

## 📄 License

**Proprietary — All Rights Reserved.** &copy; 2026 Muhammad Muslih — Widdx.

- Personal use: free
- Commercial use: requires written license agreement
- Modification/redistribution: requires prior written permission

See [LICENSE](LICENSE). For commercial licensing: mem3071990@gmail.com

---

<div align="center">
🛠️ Built by [Muhammad Muslih](https://github.com/widdx1990) — [Widdx](https://widdx.com)
</div>

---

<div dir="rtl" id="arabic">

<div align="center">

# ⚡ WIDDX CLI

### 🤖 نظام تشغيل هندسة برمجيات ذاتي القيادة

**🚀 DeepSeek V4 + Google Gemini + 5 نماذج مجانية — بدون API Key**

</div>

---

## 🌟 نظرة عامة

WIDDX بيئة هندسة برمجيات ذاتية القيادة تعمل في الطرفية. تنسق وكلاء ذكيين للتخطيط والبناء والاختبار والتصحيح الذاتي — مع فهم النية قبل التنفيذ.

- **🧠 تصنيف النية** — يصنف كل رسالة: `chat` / `do` / `spec` قبل الرد
- **🎭 شخصية مطور** — يتحدث كمطور، ليس كبوت؛ ودود، مختصر، محترف
- **📋 تطوير بالمواصفات** — متطلبات → تصميم → مهام للميزات المعقدة
- **✅ صفر إعدادات** — يعمل بدون API Key بـ 5 نماذج مجانية

---

## ✨ المميزات

### 🧠 معمارية واعية بالنية (v1.18+)

| الوضع | المحفز | السلوك |
|-------|--------|--------|
| 💬 **دردشة** | تحية، أسئلة، آراء | رد مباشر، بدون أدوات |
| ⚡ **تنفيذ** | تعديلات، أوامر، بناء | حلقة أدوات كاملة مع تخطيط |
| 📋 **مواصفات** | "create a spec", "plan" | متطلبات → تصميم → مهام |

### 📋 تطوير بالمواصفات (`/spec`)

```
/spec auth-system          → بدء مواصفة جديدة

المرحلة 1: المتطلبات      → قصص مستخدم + معايير قبول EARS
المرحلة 2: التصميم         → معمارية، مكونات، نماذج بيانات
المرحلة 3: المهام          → قائمة مهام مرقمة مع إشارات للمتطلبات
المرحلة 4: التنفيذ         → مهمة واحدة في كل مرة مع مراجعة المستخدم
```

### 🔀 توجيه ذكي متعدد المزودين

| الخطة | الشرط | النماذج |
|-------|-------|---------|
| 🟢 A | مفتاح DeepSeek | `deepseek-v4-pro` + `deepseek-v4-flash` |
| 🟡 B | مفتاح Google | `gemini-2.5-pro` + `gemini-2.5-flash` |
| 🔵 C | بدون مفتاح | 5 نماذج مجانية من opencode.ai |

### ✅ التحقق والتصحيح الذاتي

ثلاثة مستويات: أداة → وكيل → خط أنابيب. إصلاح تلقائي حتى 3 محاولات.

### 🖥️ واجهة طرفية احترافية

- ⚡ **تصميم موحد حديث** — أزرق كهربائي، تيل، بنفسجي
- 💬 فقاعات رسائل مع طوابع زمنية
- 📝 Markdown مباشر مع تلوين الصيغة
- 🌍 دعم عربي كامل RTL

---

## 📦 التثبيت

```bash
pip install widdx
python -m widdx
```

---

## 📋 الأوامر

| الأمر | الوصف |
|-------|-------|
| 📋 `/spec [اسم]` | عرض المواصفات أو بدء مواصفة جديدة |
| 🔀 `/providers` | إدارة المزودين |
| 🎯 `/provider <اسم>` | تبديل المزود |
| 🔭 `/bootstrap <تقنية>` | بحث وتوليد مهارات/وكلاء |
| 👥 `/agents <مهمة>` | فريق وكلاء |
| 🗺️ `/plan <وصف>` | خطة مشروع |
| 🛠️ `/skills` | المهارات المتاحة |
| 🪝 `/hooks` | hooks المسجلة |
| 🔌 `/mcp` | إدارة MCP |
| 📚 `/learn` | سجل التعلم |
| 🔍 `/knowledge <استعلام>` | بحث في الذاكرة |
| 📦 `/compact` | تلخيص المحادثة |
| 🤖 `/model` | معلومات النموذج |
| 📋 `/tasks` | سجل المهام |
| 🌿 `/git` | حالة git |
| 🔎 `/search` | بحث في الكود |
| ↩️ `/undo` | تراجع |
| 💾 `/save <اسم>` | حفظ الجلسة |
| 🧹 `/clear` | مسح المحادثة |
| 🖥️ `widdx web` | واجهة الويب |
| ✅ `/self-check` | تشخيص النظام |
| ❓ `/help` | مساعدة |

---

## 🤖 الوكلاء

12 وكيلاً متخصصاً: Software Architect, Backend, Frontend, Laravel, DevOps, QA, Security, Data, Database, Systems, Code Reviewer, Full-Stack.

## 🛠️ المهارات

17 مهارة مدمجة: code-review, tdd-workflow, bugfix, feat-dev, security, api-design, deploy, db-migrate, ui-design, docs, refactor, debug, laravel, testing, database, caching, queue-jobs.

---

## 🏗️ الهيكل المعماري

```
widdx/
├── classifier.py           # مصنف النية (chat/do/spec)
├── prompts/               # برومبتات حسب الوضع
│   ├── vibe.py            # شخصية المحادثة/التنفيذ
│   └── spec.py            # برومبت المواصفات
├── spec_workflow/         # مدير المواصفات
├── router/                # توجيه متعدد المزودين
├── pipeline/              # خط أنابيب 7 خطوات
├── agent_factory/         # توليد الفرق
├── skills/                # 17 مهارة
├── hooks/                 # نظام الأحداث
├── verifier/              # تحقق 3 مستويات
├── repl/                  # واجهة تفاعلية
├── tool_loop/             # حلقة الأدوات
├── mcp/                   # بروتوكول MCP
├── ui/                    # واجهة Rich موحدة
├── web/                   # واجهة ويب
└── semantic_index.py      # بحث دلالي محلي
```

---

## 🔒 الأمان

- 🚫 لا `shell=True` — أوامر بقوائم وسائط آمنة
- 🔐 ملفات الإعدادات بصلاحيات 600
- 🛡️ مدقق أمني للـ Hooks
- 📋 تسجيل كامل للأخطاء

---

## 📄 الترخيص

**احتكاري — جميع الحقوق محفوظة.** &copy; 2026 محمد مصلح — Widdx.

للاستخدام التجاري: mem3071990@gmail.com

---

<div align="center">
🛠️ بناه [محمد مصلح](https://github.com/widdx1990) — [Widdx](https://widdx.com)
</div>

</div>
