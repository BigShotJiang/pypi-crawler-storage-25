"""LLM provider backends: Anthropic, OpenAI, Google GenAI.

Each provider function takes a standard set of arguments and returns the
response text as a string. No litellm — direct SDK calls only.
"""

import os


def _get_key(env_var):
    key = os.getenv(env_var)
    if not key:
        raise RuntimeError(f"Missing {env_var} in environment")
    return key


def route_provider(model):
    """Return the appropriate provider function for a model string."""
    model_lower = model.lower()
    if "claude" in model_lower or model_lower.startswith("anthropic/"):
        return call_anthropic
    elif "gpt" in model_lower or "o1" in model_lower or "o3" in model_lower or model_lower.startswith("openai/"):
        return call_openai
    elif "gemini" in model_lower or model_lower.startswith("google/"):
        return call_google
    else:
        raise ValueError(
            f"Cannot determine provider for model '{model}'. "
            f"Model name should contain 'claude', 'gpt', or 'gemini', "
            f"or use a prefix like 'anthropic/', 'openai/', or 'google/'."
        )


def _strip_prefix(model):
    """Remove provider prefix like 'anthropic/' or 'openai/' from model name."""
    for prefix in ("anthropic/", "openai/", "google/"):
        if model.lower().startswith(prefix):
            return model[len(prefix):]
    return model


def _build_messages(prompt, system_prompt=None):
    """Build a messages list from prompt and optional system prompt."""
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})
    return messages


def call_anthropic(prompt, model="claude-sonnet-4-20250514", system_prompt=None,
                   temperature=0.7, max_tokens=4096, **kwargs):
    """Call Anthropic's Claude API directly."""
    from anthropic import Anthropic

    client = Anthropic(api_key=_get_key("ANTHROPIC_API_KEY"))
    model = _strip_prefix(model)

    api_kwargs = dict(
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}],
    )
    if system_prompt:
        api_kwargs["system"] = system_prompt

    response = client.messages.create(**api_kwargs)
    return response.content[0].text


def call_openai(prompt, model="gpt-4o-mini", system_prompt=None,
                temperature=0.7, max_tokens=4096, **kwargs):
    """Call OpenAI's API directly."""
    from openai import OpenAI

    client = OpenAI(api_key=_get_key("OPENAI_API_KEY"))
    model = _strip_prefix(model)

    response = client.chat.completions.create(
        model=model,
        messages=_build_messages(prompt, system_prompt),
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return response.choices[0].message.content


def call_google(prompt, model="gemini-2.5-flash", system_prompt=None,
                temperature=0.7, max_tokens=4096, **kwargs):
    """Call Google's GenAI API directly."""
    from google import genai

    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise RuntimeError("Missing GEMINI_API_KEY or GOOGLE_API_KEY in environment")

    client = genai.Client(api_key=api_key)
    model = _strip_prefix(model)

    config = genai.types.GenerateContentConfig(
        temperature=temperature,
        max_output_tokens=max_tokens,
    )
    if system_prompt:
        config.system_instruction = system_prompt

    response = client.models.generate_content(
        model=model,
        contents=prompt,
        config=config,
    )
    return response.text


def check_api_keys(verbose=False):
    """Check which provider API keys are available in the environment."""
    keys = {
        "ANTHROPIC_API_KEY": os.getenv("ANTHROPIC_API_KEY"),
        "OPENAI_API_KEY": os.getenv("OPENAI_API_KEY"),
        "GEMINI_API_KEY": os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"),
    }
    available = {k: v for k, v in keys.items() if v}
    if verbose:
        for k, v in keys.items():
            status = "+" if v else "X"
            print(f"  {status} {k}")
    return available
