#include <pybind11/functional.h>
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <vector>

#include "acoustics.h"
#include "area_change.h"
#include "can_annular_solvers.h"
#include "combustion.h"
#include "common_names.h"
#include "compressible.h"
#include "cooling_correlations.h"
#include "correlation_status.h"
#include "equilibrium.h"
#include "friction.h"
#include "geometry.h"
#include "heat_transfer.h"
#include "humidair.h"
#include "incompressible.h"
#include "materials.h"
#include "orifice.h"
#include "registry.h"
#include "solver_interface.h"
#include "tee_junction.h"
#include "vatistas.h"
#include "stagnation.h"
#include "state.h"
#include "thermo.h"
#include "transport.h"
#include "units.h"
#include "utils.h"

namespace py = pybind11;
using namespace combaero;

static std::vector<double>
to_vec(py::array_t<double, py::array::c_style | py::array::forcecast> arr) {
  auto buf = arr.unchecked<1>();
  std::vector<double> v(buf.shape(0));
  for (py::ssize_t i = 0; i < buf.shape(0); ++i)
    v[static_cast<std::size_t>(i)] = buf(i);
  return v;
}

PYBIND11_MODULE(_core, m) {
  m.doc() = "Python bindings for combaero core";

  // Expose the CorrelationValidity enum
  py::enum_<solver::CorrelationValidity>(
      m, "CorrelationValidity", "Status flag for correlation evaluations.")
      .value("VALID", solver::CorrelationValidity::VALID)
      .value("EXTRAPOLATED", solver::CorrelationValidity::EXTRAPOLATED)
      .value("INVALID", solver::CorrelationValidity::INVALID)
      .export_values();

  // Expose the CorrelationResult struct for (f, J) tuples
  py::class_<solver::CorrelationResult<std::tuple<double, double>>>(
      m, "CorrelationResult",
      "Wrapper for correlation results, returning the (value, "
      "jacobian) tuple alongside validity status.")
      .def_readonly(
          "result",
          &solver::CorrelationResult<std::tuple<double, double>>::result)
      .def_readonly(
          "status",
          &solver::CorrelationResult<std::tuple<double, double>>::status)
      .def_readonly(
          "message",
          &solver::CorrelationResult<std::tuple<double, double>>::message)
      .def("__repr__",
           [](const solver::CorrelationResult<std::tuple<double, double>> &r) {
             std::string status_str = "VALID";
             if (r.status == solver::CorrelationValidity::EXTRAPOLATED)
               status_str = "EXTRAPOLATED";
             else if (r.status == solver::CorrelationValidity::INVALID)
               status_str = "INVALID";
             return "<CorrelationResult: (" +
                    std::to_string(std::get<0>(r.result)) + ", " +
                    std::to_string(std::get<1>(r.result)) +
                    "), status=" + status_str + ">";
           });

  py::class_<solver::Stream>(m, "MassStream", "Mass stream descriptor")
      .def(py::init<double, double, double, std::vector<double>>())
      .def_readwrite("m_dot", &solver::Stream::m_dot)
      .def_readwrite("T", &solver::Stream::T)
      .def_readwrite("P_total", &solver::Stream::P_total)
      .def_readwrite("Y", &solver::Stream::Y);

  py::class_<solver::StreamJacobian>(m, "StreamJacobian",
                                     "Derivatives w.r.t a stream")
      .def_readonly("d_mdot", &solver::StreamJacobian::d_mdot)
      .def_readonly("d_T", &solver::StreamJacobian::d_T)
      .def_readonly("d_P_total", &solver::StreamJacobian::d_P_total)
      .def_readonly("d_Y", &solver::StreamJacobian::d_Y);

  py::class_<MixtureState>(m, "MixtureState",
                           "High-level state for network components")
      .def(py::init([](double P, double P_total, double T, double T_total,
                       double m_dot, const std::vector<double> &Y) {
             MixtureState s;
             s.P = P;
             s.P_total = P_total;
             s.T = T;
             s.T_total = T_total;
             s.m_dot = m_dot;
             if (!Y.empty()) {
               s.Y = Y;
               double sum = 0.0;
               for (double y : Y)
                 sum += y;
               if (sum > 0.0) {
                 s.X = mass_to_mole(Y);
               } else {
                 s.X.assign(Y.size(), 0.0);
               }
             } else {
               std::size_t n = num_species();
               s.X.assign(n, 0.0);
               s.Y.assign(n, 0.0);
               if (n > 0) {
                 s.X[0] =
                     1.0; // Default to first species (usually N2 or similar)
                 s.Y[0] = 1.0;
               }
             }
             return s;
           }),
           py::arg("P") = 101325.0, py::arg("P_total") = 101325.0,
           py::arg("T") = 298.15, py::arg("T_total") = 298.15,
           py::arg("m_dot") = 0.0, py::arg("Y") = std::vector<double>{})
      .def_readwrite("P", &MixtureState::P)
      .def_readwrite("P_total", &MixtureState::P_total)
      .def_readwrite("T", &MixtureState::T)
      .def_readwrite("T_total", &MixtureState::T_total)
      .def_readwrite("m_dot", &MixtureState::m_dot)
      .def_property(
          "X", [](const MixtureState &s) { return s.X; },
          [](MixtureState &s, const std::vector<double> &v) {
            s.X = v;
            if (!v.empty())
              s.Y = mole_to_mass(v);
          })
      .def_property(
          "Y", [](const MixtureState &s) { return s.Y; },
          [](MixtureState &s, const std::vector<double> &v) {
            s.Y = v;
            if (!v.empty())
              s.X = mass_to_mole(v);
          })
      .def("density",
           [](const MixtureState &s) { return s.static_state().rho(); })
      .def("cp", [](const MixtureState &s) { return cp_mass(s.T, s.X); })
      .def("specific_heat",
           [](const MixtureState &s) { return cp_mass(s.T, s.X); })
      .def("h", [](const MixtureState &s) { return h_mass(s.T, s.X); })
      .def("enthalpy", [](const MixtureState &s) { return h_mass(s.T, s.X); })
      .def("mw", [](const MixtureState &s) { return s.static_state().mw(); })
      .def("molecular_weight",
           [](const MixtureState &s) { return s.static_state().mw(); })
      .def("static_state", &MixtureState::static_state)
      .def("total_state", &MixtureState::total_state);

  py::class_<solver::ChamberResult>(m, "ChamberResult",
                                    "Analytical node residuals")
      .def(py::init<>())
      .def_readonly("residuals", &solver::ChamberResult::residuals)
      .def_readonly("local_jacobian", &solver::ChamberResult::local_jacobian)
      .def_readonly("stream_jacobian", &solver::ChamberResult::stream_jacobian);

  py::class_<solver::MixerResult>(
      m, "MixerResult", "Output and internal gradients of stream mixes")
      .def_readonly("T_mix", &solver::MixerResult::T_mix)
      .def_readonly("P_total_mix", &solver::MixerResult::P_total_mix)
      .def_readonly("Y_mix", &solver::MixerResult::Y_mix)
      .def_readonly("dT_mix_d_delta_h", &solver::MixerResult::dT_mix_d_delta_h)
      .def_readonly("dT_mix_d_stream", &solver::MixerResult::dT_mix_d_stream)
      .def_readonly("dP_total_mix_d_stream",
                    &solver::MixerResult::dP_total_mix_d_stream)
      .def_readonly("dY_mix_d_stream", &solver::MixerResult::dY_mix_d_stream);

  m.def("mixer_from_streams_and_jacobians",
        &solver::mixer_from_streams_and_jacobians, py::arg("streams"),
        py::arg("Q") = 0.0, py::arg("fraction") = 0.0);
  m.def("adiabatic_T_complete_and_jacobian_T_from_streams",
        &solver::adiabatic_T_complete_and_jacobian_T_from_streams,
        py::arg("streams"), py::arg("P"), py::arg("Q") = 0.0,
        py::arg("fraction") = 0.0);
  m.def("adiabatic_T_equilibrium_and_jacobians_from_streams",
        &solver::adiabatic_T_equilibrium_and_jacobians_from_streams,
        py::arg("streams"), py::arg("P"), py::arg("Q") = 0.0,
        py::arg("fraction") = 0.0);
  m.def(
      "combustor_residuals_and_jacobians",
      [](const std::vector<solver::Stream> &streams, double P, double Q,
         double fraction, py::function py_loss, bool use_equilibrium) {
        PressureLossCorrelation cpp_loss =
            [py_loss](const PressureLossContext &ctx) -> std::tuple<double, double> {
          py::object res = py_loss(ctx);
          try {
            return res.cast<std::tuple<double, double>>();
          } catch (...) {
            return {res.cast<double>(), 0.0};
          }
        };
        return solver::combustor_residuals_and_jacobians(
            streams, P, Q, fraction, cpp_loss, use_equilibrium);
      },
      py::arg("streams"), py::arg("P"), py::arg("Q") = 0.0,
      py::arg("fraction") = 0.0, py::arg("pressure_loss"),
      py::arg("use_equilibrium") = false);

  py::class_<solver::OrificeResult>(
      m, "OrificeResult", "Result of orifice residual and Jacobian evaluation")
      .def_readonly("m_dot_calc", &solver::OrificeResult::m_dot_calc)
      .def_readonly("d_mdot_dP_total_up",
                    &solver::OrificeResult::d_mdot_dP_total_up)
      .def_readonly("d_mdot_dP_static_down",
                    &solver::OrificeResult::d_mdot_dP_static_down)
      .def_readonly("d_mdot_dP_static_up",
                    &solver::OrificeResult::d_mdot_dP_static_up)
      .def_readonly("d_mdot_dT_up", &solver::OrificeResult::d_mdot_dT_up)
      .def_readonly("d_mdot_dY_up", &solver::OrificeResult::d_mdot_dY_up);

  py::class_<solver::ChannelResult>(
      m, "ChannelSolverResult",
      "Result of channel residual and Jacobian evaluation")
      .def(py::init<>())
      .def_readonly("dP_calc", &solver::ChannelResult::dP_calc)
      .def_readonly("d_dP_d_mdot", &solver::ChannelResult::d_dP_d_mdot)
      .def_readonly("d_dP_dP_static_up",
                    &solver::ChannelResult::d_dP_dP_static_up)
      .def_readonly("d_dP_dT_up", &solver::ChannelResult::d_dP_dT_up)
      .def_readonly("d_dP_dY_up", &solver::ChannelResult::d_dP_dY_up);

  py::class_<solver::MomentumChamberResult>(
      m, "MomentumChamberResult",
      "Result of momentum chamber residual and Jacobian evaluation")
      .def_readonly("residual", &solver::MomentumChamberResult::residual)
      .def_readonly("d_res_dP", &solver::MomentumChamberResult::d_res_dP)
      .def_readonly("d_res_dP_total",
                    &solver::MomentumChamberResult::d_res_dP_total)
      .def_readonly("d_res_dmdot", &solver::MomentumChamberResult::d_res_dmdot);

  m.def("orifice_residuals_and_jacobian",
        &solver::orifice_residuals_and_jacobian, py::arg("m_dot"),
        py::arg("P_total_up"), py::arg("P_static_up"), py::arg("T_up"),
        py::arg("Y_up"), py::arg("P_static_down"), py::arg("Cd"),
        py::arg("area"), py::arg("beta") = 0.0);

  m.def("channel_residuals_and_jacobian",
        &solver::channel_residuals_and_jacobian, py::arg("m_dot"),
        py::arg("P_total_up"), py::arg("P_static_up"), py::arg("T_up"),
        py::arg("Y_up"), py::arg("P_static_down"), py::arg("L"), py::arg("D"),
        py::arg("roughness"), py::arg("friction_model"),
        py::arg("f_multiplier") = 1.0);

  // Compressible flow elements
  m.def("orifice_compressible_mdot_and_jacobian",
        &solver::orifice_compressible_mdot_and_jacobian, py::arg("T0"),
        py::arg("P0"), py::arg("P_back"), py::arg("X"), py::arg("Cd"),
        py::arg("area"), py::arg("beta") = 0.0,
        "Compressible orifice flow with smooth choked flow Jacobians.\n\n"
        "Returns: (mdot, d_mdot_dP0, d_mdot_dP_back, d_mdot_dT0)");

  m.def("orifice_compressible_residuals_and_jacobian",
        &solver::orifice_compressible_residuals_and_jacobian, py::arg("m_dot"),
        py::arg("P_total_up"), py::arg("T_up"), py::arg("Y_up"),
        py::arg("P_static_down"), py::arg("Cd"), py::arg("area"),
        py::arg("beta") = 0.0,
        "Compressible orifice for network solver with all derivatives.");

  m.def(
      "channel_compressible_mdot_and_jacobian",
      &solver::channel_compressible_mdot_and_jacobian, py::arg("T_in"),
      py::arg("P_in"), py::arg("u_in"), py::arg("X"), py::arg("L"),
      py::arg("D"), py::arg("roughness"), py::arg("friction_model"),
      py::arg("f_multiplier") = 1.0, py::arg("compute_jacobians") = true,
      "Compressible channel flow using Fanno model with variable friction.\n\n"
      "Returns: (dP, d_dP_dP_in, d_dP_dT_in, d_dP_du_in)");

  m.def("channel_compressible_residuals_and_jacobian",
        &solver::channel_compressible_residuals_and_jacobian, py::arg("m_dot"),
        py::arg("P_total_up"), py::arg("T_up"), py::arg("Y_up"),
        py::arg("P_static_down"), py::arg("L"), py::arg("D"),
        py::arg("roughness"), py::arg("friction_model"),
        py::arg("f_multiplier") = 1.0,
        "Compressible channel for network solver with all derivatives.");

  m.def("momentum_chamber_residual_and_jacobian",
        &solver::momentum_chamber_residual_and_jacobian, py::arg("P"),
        py::arg("P_total"), py::arg("m_dot"), py::arg("T"), py::arg("Y"),
        py::arg("area"),
        "Momentum chamber residual: P_total = P + 0.5*rho*v^2");

  // Area change elements
  py::class_<combaero::AreaChangeResult>(
      m, "AreaChangeResult",
      "Result of sharp_area_change: dP and Jacobian partials")
      .def_readonly("dP", &combaero::AreaChangeResult::dP)
      .def_readonly("dS_dm", &combaero::AreaChangeResult::dS_dm)
      .def_readonly("dS_drho", &combaero::AreaChangeResult::dS_drho)
      .def_readonly("dS_dmu", &combaero::AreaChangeResult::dS_dmu)
      .def_readonly("mach_clamped", &combaero::AreaChangeResult::mach_clamped);

  m.def("sharp_area_change", &combaero::sharp_area_change,
        py::arg("m_dot"), py::arg("rho"), py::arg("mu"),
        py::arg("F0"), py::arg("F1"),
        py::arg("Mach") = 0.0, py::arg("m_scale") = 1e-4,
        py::arg("D_h") = 0.0,
        "Sharp-edge area change: pressure drop and Jacobian partials.\n\n"
        "D_h overrides the circular hydraulic diameter when > 0.\n"
        "Returns AreaChangeResult with dP, dS_dm, dS_drho, dS_dmu.");

  m.def("conical_area_change", &combaero::conical_area_change,
        py::arg("m_dot"), py::arg("rho"), py::arg("mu"),
        py::arg("F0"), py::arg("F1"), py::arg("length"),
        py::arg("Mach") = 0.0, py::arg("m_scale") = 1e-4,
        "Conical (gradual) area change: pressure drop and Jacobian partials.\n\n"
        "Returns AreaChangeResult with dP, dS_dm, dS_drho, dS_dmu.");

  py::class_<solver::AreaChangeElementResult>(
      m, "AreaChangeElementResult",
      "Result of area_change_residuals_and_jacobian for network solver")
      .def(py::init<>())
      .def_readonly("dP_calc", &solver::AreaChangeElementResult::dP_calc)
      .def_readonly("d_dP_d_mdot", &solver::AreaChangeElementResult::d_dP_d_mdot)
      .def_readonly("d_dP_dP_static_up",
                    &solver::AreaChangeElementResult::d_dP_dP_static_up)
      .def_readonly("d_dP_dT_up", &solver::AreaChangeElementResult::d_dP_dT_up)
      .def_readonly("d_dP_dY_up", &solver::AreaChangeElementResult::d_dP_dY_up)
      .def_readonly("mach_clamped", &solver::AreaChangeElementResult::mach_clamped);

  m.def("area_change_residuals_and_jacobian",
        &solver::area_change_residuals_and_jacobian,
        py::arg("m_dot"), py::arg("P_total_up"), py::arg("P_static_up"),
        py::arg("T_up"), py::arg("Y_up"), py::arg("P_static_down"),
        py::arg("F0"), py::arg("F1"), py::arg("m_scale") = 1e-4,
        py::arg("D_h") = 0.0,
        "Network-level sharp-edge area change with all derivatives.");

  m.def("conical_area_change_residuals_and_jacobian",
        &solver::conical_area_change_residuals_and_jacobian,
        py::arg("m_dot"), py::arg("P_total_up"), py::arg("P_static_up"),
        py::arg("T_up"), py::arg("Y_up"), py::arg("P_static_down"),
        py::arg("F0"), py::arg("F1"), py::arg("length"),
        py::arg("m_scale") = 1e-4,
        "Network-level conical area change with all derivatives.");

  // Tee junction (Bassett 2001)
  py::class_<solver::TeeJunctionResult>(
      m, "TeeJunctionResult",
      "Result of merging/branching_tee_residuals_and_jacobian for network solver")
      .def(py::init<>())
      .def_readonly("R_straight", &solver::TeeJunctionResult::R_straight)
      .def_readonly("R_branch", &solver::TeeJunctionResult::R_branch)
      .def_readonly("dR_straight_d_mdot_com",
                    &solver::TeeJunctionResult::dR_straight_d_mdot_com)
      .def_readonly("dR_straight_d_mdot_branch",
                    &solver::TeeJunctionResult::dR_straight_d_mdot_branch)
      .def_readonly("dR_straight_dP_static_com",
                    &solver::TeeJunctionResult::dR_straight_dP_static_com)
      .def_readonly("dR_straight_dT_com",
                    &solver::TeeJunctionResult::dR_straight_dT_com)
      .def_readonly("dR_straight_dY_com",
                    &solver::TeeJunctionResult::dR_straight_dY_com)
      .def_readonly("dR_branch_d_mdot_com",
                    &solver::TeeJunctionResult::dR_branch_d_mdot_com)
      .def_readonly("dR_branch_d_mdot_branch",
                    &solver::TeeJunctionResult::dR_branch_d_mdot_branch)
      .def_readonly("dR_branch_dP_static_com",
                    &solver::TeeJunctionResult::dR_branch_dP_static_com)
      .def_readonly("dR_branch_dT_com",
                    &solver::TeeJunctionResult::dR_branch_dT_com)
      .def_readonly("dR_branch_dY_com",
                    &solver::TeeJunctionResult::dR_branch_dY_com)
      .def_readonly("K_straight", &solver::TeeJunctionResult::K_straight)
      .def_readonly("K_branch", &solver::TeeJunctionResult::K_branch)
      .def_readonly("q", &solver::TeeJunctionResult::q)
      .def_readonly("blend_w", &solver::TeeJunctionResult::blend_w)
      .def_readonly("topology_valid", &solver::TeeJunctionResult::topology_valid)
      .def_readonly("status", &solver::TeeJunctionResult::status);

  m.def("merging_tee_residuals_and_jacobian",
        &solver::merging_tee_residuals_and_jacobian,
        py::arg("m_dot_com"), py::arg("m_dot_branch"),
        py::arg("dP0_straight"), py::arg("dP0_branch"),
        py::arg("P_static_com"), py::arg("T_com"), py::arg("Y_com"),
        py::arg("theta"), py::arg("psi"), py::arg("F_C"),
        py::arg("blend_k") = 30.0,
        "MergingTee (joining flow, Bassett 2001 type 6) residuals and Jacobians.\n\n"
        "Parameters:\n"
        "  m_dot_com    : total outlet flow C [kg/s]\n"
        "  m_dot_branch : branch inlet flow B [kg/s]\n"
        "  dP0_straight : p0_A - p0_C [Pa]\n"
        "  dP0_branch   : p0_B - p0_C [Pa]\n"
        "  P_static_com : static pressure at port C [Pa] (for density)\n"
        "  T_com        : temperature at port C [K]\n"
        "  Y_com        : mass fractions at port C [-]\n"
        "  theta        : branch angle [rad] (valid: (0, pi/2])\n"
        "  psi          : area ratio F_C/F_B [-] (valid: >= 0.05)\n"
        "  F_C          : main duct area [m^2]\n"
        "  blend_k      : tanh blend sharpness (default 30.0)\n\n"
        "Returns: TeeJunctionResult");

  m.def("branching_tee_residuals_and_jacobian",
        &solver::branching_tee_residuals_and_jacobian,
        py::arg("m_dot_com"), py::arg("m_dot_branch"),
        py::arg("dP0_straight"), py::arg("dP0_branch"),
        py::arg("P_static_com"), py::arg("T_com"), py::arg("Y_com"),
        py::arg("theta"), py::arg("psi"), py::arg("F_C"),
        py::arg("blend_k") = 30.0,
        "BranchingTee (separating flow, Bassett 2001 type 3) residuals and Jacobians.\n\n"
        "Parameters:\n"
        "  m_dot_com    : total inlet flow C [kg/s]\n"
        "  m_dot_branch : branch outlet flow B [kg/s]\n"
        "  dP0_straight : p0_C - p0_A [Pa]\n"
        "  dP0_branch   : p0_C - p0_B [Pa]\n"
        "  P_static_com : static pressure at port C [Pa] (for density)\n"
        "  T_com        : temperature at port C [K]\n"
        "  Y_com        : mass fractions at port C [-]\n"
        "  theta        : branch angle [rad] (valid: (0, pi/2])\n"
        "  psi          : area ratio F_C/F_B [-] (valid: >= 0.05)\n"
        "  F_C          : main duct area [m^2]\n"
        "  blend_k      : tanh blend sharpness (default 30.0)\n\n"
        "Returns: TeeJunctionResult");

  // Tee junction pure K functions and helpers (for testing and diagnostics)
  m.def("tee_K5", &combaero::K5, py::arg("q"),
        "Bassett K5: straight-through loss, separating flow. K5(q) = q^2-1.5q+0.5");
  m.def("tee_K6", &combaero::K6, py::arg("q"), py::arg("psi"), py::arg("theta"),
        "Bassett K6: branch loss, separating flow type 3.");
  m.def("tee_K11", &combaero::K11, py::arg("q"), py::arg("psi"), py::arg("theta"),
        "Bassett K11: straight-to-outlet, joining flow type 6.");
  m.def("tee_K12", &combaero::K12, py::arg("q"), py::arg("psi"), py::arg("theta"),
        "Bassett K12: branch-to-outlet, joining flow type 6.");
  m.def("tee_blend_weight", &combaero::blend_weight,
        py::arg("r"), py::arg("k") = 30.0,
        "Smooth topology blend weight: 0.5*(1+tanh(k*r)).");
  m.def("tee_check_inputs",
        [](double q, double psi, double theta) {
            auto s = combaero::tee_check_inputs(q, psi, theta);
            return py::dict(py::arg("q_in_range") = s.q_in_range,
                            py::arg("psi_valid") = s.psi_valid,
                            py::arg("theta_valid") = s.theta_valid,
                            py::arg("valid") = s.valid());
        },
        py::arg("q"), py::arg("psi"), py::arg("theta"),
        "Check if tee junction inputs are in the Bassett 2001 validated range.\n"
        "Returns dict with q_in_range, psi_valid, theta_valid, valid keys.");
  m.def("merging_tee_K_straight", &combaero::merging_tee_K_straight,
        py::arg("q"), py::arg("psi"), py::arg("theta"), py::arg("blend_k") = 30.0,
        "MergingTee effective straight-path K (blended, with soft bounds).");
  m.def("merging_tee_K_branch", &combaero::merging_tee_K_branch,
        py::arg("q"), py::arg("psi"), py::arg("theta"), py::arg("blend_k") = 30.0,
        "MergingTee effective branch-path K (blended, with soft bounds).");
  m.def("branching_tee_K_straight", &combaero::branching_tee_K_straight,
        py::arg("q"), py::arg("psi"), py::arg("theta"), py::arg("blend_k") = 30.0,
        "BranchingTee effective straight-path K (blended, with soft bounds).");
  m.def("branching_tee_K_branch", &combaero::branching_tee_K_branch,
        py::arg("q"), py::arg("psi"), py::arg("theta"), py::arg("blend_k") = 30.0,
        "BranchingTee effective branch-path K (blended, with soft bounds).");

  // Species metadata helpers
  m.def("num_species", &num_species,
        "Number of thermo species in the internal tables.");

  m.def("species_name", &species_name, py::arg("index"),
        "Return the canonical species name for a given index.");

  m.def("species_index_from_name", &species_index_from_name, py::arg("name"),
        "Return the species index for a given canonical name.");

  m.def("species_molar_mass", &species_molar_mass, py::arg("index"),
        "Return the molar mass [g/mol] for a given species index.");

  m.def("species_molar_mass_from_name", &species_molar_mass_from_name,
        py::arg("name"),
        "Return the molar mass [g/mol] for a given species name.");

  // Common names for species symbols
  m.def(
      "formula_to_name", []() { return combaero::formula_to_name; },
      "Mapping from canonical species symbols (e.g. 'CH4') to human-readable "
      "common names (e.g. 'Methane').");

  m.def(
      "name_to_formula", []() { return combaero::name_to_formula; },
      "Mapping from human-readable common names (e.g. 'Methane') to canonical "
      "species symbols (e.g. 'CH4').");

  m.def("common_name", &combaero::common_name, py::arg("formula"),
        "Get common name from formula (e.g., 'CH4' -> 'Methane').");

  m.def("formula", &combaero::formula, py::arg("name"),
        "Get formula from common name (e.g., 'Methane' -> 'CH4').");

  m.def(
      "mass_to_mole",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> Y_arr) {
        return mass_to_mole(to_vec(Y_arr));
      },
      py::arg("Y"), "Convert mass fractions Y to mole fractions X");

  m.def(
      "mole_to_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        return mole_to_mass(to_vec(X_arr));
      },
      py::arg("X"), "Convert mole fractions X to mass fractions Y");

  m.def(
      "mixture_h",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return h(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mixture enthalpy at temperature T and mole fractions X.");

  // Thermodynamic mixture properties
  m.def(
      "cp",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return cp(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mixture isobaric heat capacity Cp(T, X) [J/(mol·K)].");

  m.def(
      "h",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return h(T, X);
      },
      py::arg("T"), py::arg("X"), "Mixture enthalpy h(T, X) [J/mol].");

  m.def(
      "s",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P, double P_ref) {
        auto X = to_vec(X_arr);
        return s(T, X, P, P_ref);
      },
      py::arg("T"), py::arg("X"), py::arg("P"), py::arg("P_ref") = 101325.0,
      "Mixture entropy s(T, X, P, P_ref) [J/(mol·K)].");

  m.def(
      "cv",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return cv(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mixture isochoric heat capacity Cv(T, X) [J/(mol*K)].");

  m.def(
      "u",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return u(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mixture internal energy u(T, X) [J/mol].\n\n"
      "For ideal gas: u = h - RT\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: internal energy [J/mol]");

  m.def(
      "density",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return density(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Mixture density rho(T, P, X) [kg/m^3].");

  m.def(
      "specific_gas_constant",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return specific_gas_constant(X);
      },
      py::arg("X"), "Mixture specific gas constant R_s(X) [J/(kg·K)].");

  m.def(
      "isentropic_expansion_coefficient",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return isentropic_expansion_coefficient(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Isentropic expansion coefficient gamma(T, X) = Cp/Cv.");

  m.def(
      "speed_of_sound",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return speed_of_sound(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Speed of sound [m/s].\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: speed of sound [m/s]");

  m.def(
      "cp_mass",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return cp_mass(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass-specific heat capacity at constant pressure.\n\n"
      "Cp_mass = Cp_molar / mwmix * 1000\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: heat capacity [J/(kg·K)]");

  m.def(
      "cv_mass",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return cv_mass(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass-specific heat capacity at constant volume.\n\n"
      "Cv_mass = Cv_molar / mwmix * 1000\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: heat capacity [J/(kg·K)]");

  m.def(
      "h_mass",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return h_mass(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass-specific enthalpy.\n\n"
      "h_mass = h_molar / mwmix * 1000\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: enthalpy [J/kg]");

  m.def(
      "s_mass",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P, double P_ref = 101325.0) {
        auto X = to_vec(X_arr);
        return s_mass(T, X, P, P_ref);
      },
      py::arg("T"), py::arg("X"), py::arg("P"), py::arg("P_ref") = 101325.0,
      "Mass-specific entropy.\n\n"
      "s_mass = s_molar / mwmix * 1000\n\n"
      "Parameters:\n"
      "  T     : temperature [K]\n"
      "  X     : mole fractions [mol/mol]\n"
      "  P     : pressure [Pa]\n"
      "  P_ref : reference pressure [Pa] (default: 101325)\n\n"
      "Returns: entropy [J/(kg*K)]");

  m.def(
      "u_mass",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return u_mass(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass-specific internal energy.\n\n"
      "u_mass = u_molar / mwmix * 1000\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  X : mole fractions [mol/mol]\n\n"
      "Returns: internal energy [J/kg]");

  m.def("molar_volume", &molar_volume, py::arg("T"), py::arg("P"),
        "Ideal gas molar volume V_m = R*T/P [m³/mol].");

  // Transport properties
  m.def(
      "viscosity",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return viscosity(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Dynamic viscosity mu(T, P, X) [Pa·s].");

  m.def(
      "thermal_conductivity",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return thermal_conductivity(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Thermal conductivity lambda(T, P, X) [W/(m·K)].");

  m.def(
      "kinematic_viscosity",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return kinematic_viscosity(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Kinematic viscosity nu(T, P, X) [m^2/s].");

  m.def(
      "prandtl",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return prandtl(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Prandtl number Pr(T, P, X) [-].");

  m.def(
      "thermal_diffusivity",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return thermal_diffusivity(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Thermal diffusivity alpha(T, P, X) [m^2/s].");

  m.def(
      "reynolds",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double V, double L) {
        auto X = to_vec(X_arr);
        return reynolds(T, P, X, V, L);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("V"), py::arg("L"),
      "Reynolds number Re = rho*V*L/mu [-].");

  m.def(
      "peclet",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double V, double L) {
        auto X = to_vec(X_arr);
        return peclet(T, P, X, V, L);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("V"), py::arg("L"),
      "Peclet number Pe = V*L/alpha (thermal) [-].");

  // TransportState struct binding - Bundle of transport properties
  py::class_<TransportState>(
      m, "TransportState",
      "Bundle of transport properties for a gas mixture.\n\n"
      "All properties are read-only attributes computed in a single call.\n"
      "Provides IDE autocomplete and type safety.\n\n"
      "Attributes:\n"
      "  T     : Temperature [K] (input, echoed back)\n"
      "  P     : Pressure [Pa] (input, echoed back)\n"
      "  rho   : Density [kg/m³]\n"
      "  mu    : Dynamic viscosity [Pa·s]\n"
      "  k     : Thermal conductivity [W/(m·K)]\n"
      "  nu    : Kinematic viscosity [m²/s]\n"
      "  alpha : Thermal diffusivity [m²/s]\n"
      "  Pr    : Prandtl number [-]\n"
      "  cp    : Specific heat at constant pressure [J/(kg·K)]\n"
      "  cv    : Specific heat at constant volume [J/(kg·K)]\n"
      "  gamma : Heat capacity ratio cp/cv [-]\n"
      "  a     : Speed of sound [m/s]")
      .def_readonly("T", &TransportState::T, "Temperature [K]")
      .def_readonly("P", &TransportState::P, "Pressure [Pa]")
      .def_readonly("rho", &TransportState::rho, "Density [kg/m³]")
      .def_readonly("mu", &TransportState::mu, "Dynamic viscosity [Pa·s]")
      .def_readonly("k", &TransportState::k, "Thermal conductivity [W/(m·K)]")
      .def_readonly("nu", &TransportState::nu, "Kinematic viscosity [m²/s]")
      .def_readonly("alpha", &TransportState::alpha,
                    "Thermal diffusivity [m²/s]")
      .def_readonly("Pr", &TransportState::Pr, "Prandtl number [-]")
      .def_readonly("cp", &TransportState::cp,
                    "Specific heat at constant pressure [J/(kg·K)]")
      .def_readonly("cv", &TransportState::cv,
                    "Specific heat at constant volume [J/(kg·K)]")
      .def_readonly("gamma", &TransportState::gamma,
                    "Heat capacity ratio cp/cv [-]")
      .def_readonly("a", &TransportState::a, "Speed of sound [m/s]")
      .def("__repr__", [](const TransportState &s) {
        return "<TransportState: T=" + std::to_string(s.T) +
               " K, "
               "P=" +
               std::to_string(s.P) +
               " Pa, "
               "mu=" +
               std::to_string(s.mu) +
               " Pa·s, "
               "k=" +
               std::to_string(s.k) +
               " W/(m·K), "
               "Pr=" +
               std::to_string(s.Pr) +
               ", "
               "gamma=" +
               std::to_string(s.gamma) +
               ", "
               "a=" +
               std::to_string(s.a) + " m/s>";
      });

  // EquilibriumResult struct binding
  py::class_<EquilibriumResult>(
      m, "EquilibriumResult",
      "Result of an equilibrium solve.\n\n"
      "Carries the final state plus solver diagnostics, suitable for use\n"
      "in network solvers where non-convergence must be detectable.\n\n"
      "Attributes:\n"
      "  state     : equilibrium State (T, P, X)\n"
      "  T_in      : input temperature [K]\n"
      "  delta_T   : state.T - T_in [K] (negative = endothermic)\n"
      "  converged : solver convergence flag")
      .def_readonly("state", &EquilibriumResult::state,
                    "Equilibrium State (T, P, X)")
      .def_readonly("T_in", &EquilibriumResult::T_in, "Input temperature [K]")
      .def_readonly("delta_T", &EquilibriumResult::delta_T,
                    "state.T - T_in [K]")
      .def_readonly("converged", &EquilibriumResult::converged,
                    "Solver convergence flag")
      .def("__repr__", [](const EquilibriumResult &r) {
        return "<EquilibriumResult: T=" + std::to_string(r.state.T) +
               " K, delta_T=" + std::to_string(r.delta_T) +
               " K, converged=" + (r.converged ? "True" : "False") + ">";
      });

  m.def(
      "transport_state",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        if (T <= 0.0) throw std::invalid_argument("Temperature must be strictly positive");
        if (P <= 0.0) throw std::invalid_argument("Pressure must be strictly positive");
        auto X = to_vec(X_arr);
        return transport_state(T, P, X);
      },
      py::arg("T"), py::arg("P"), py::arg("X"),
      "Compute all transport properties at once.\n\n"
      "Convenience function that computes all transport properties\n"
      "for a gas mixture in a single call. Returns TransportState struct\n"
      "with read-only attributes for IDE autocomplete support.\n\n"
      "Parameters:\n"
      "  T : temperature [K]\n"
      "  P : pressure [Pa]\n"
      "  X : mole fractions [-]\n\n"
      "Returns: TransportState object with attributes:\n"
      "  T, P, rho, mu, k, nu, alpha, Pr, cp\n\n"
      "Example:\n"
      "  >>> X = cb.species.dry_air()\n"
      "  >>> state = cb.transport_state(T=300, P=101325, X=X)\n"
      "  >>> print(state.mu)  # IDE autocomplete works!\n"
      "  1.85e-05\n"
      "  >>> print(state.Pr)\n"
      "  0.707");

  // CompleteState struct binding - Bundle of thermo + transport properties
  py::class_<CompleteState>(
      m, "CompleteState",
      "Bundle of thermodynamic and transport properties for a gas mixture.\n\n"
      "All properties are read-only attributes computed in a single call.\n"
      "Provides IDE autocomplete and type safety.\n\n"
      "Attributes:\n"
      "  thermo    : ThermoState with all 16 thermodynamic properties\n"
      "  transport : TransportState with all 9 transport properties")
      .def_readonly("thermo", &CompleteState::thermo,
                    "ThermoState with all thermodynamic properties")
      .def_readonly("transport", &CompleteState::transport,
                    "TransportState with all transport properties")
      .def("__repr__", [](const CompleteState &s) {
        return "<CompleteState: T=" + std::to_string(s.thermo.T) +
               " K, "
               "P=" +
               std::to_string(s.thermo.P) +
               " Pa, "
               "rho=" +
               std::to_string(s.thermo.rho) +
               " kg/m³, "
               "mu=" +
               std::to_string(s.transport.mu) + " Pa·s>";
      });

  m.def(
      "complete_state",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P_ref) {
        auto X = to_vec(X_arr);
        return complete_state(T, P, X, P_ref);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("P_ref") = 101325.0,
      "Compute all thermodynamic and transport properties at once.\n\n"
      "Convenience function that computes all thermodynamic and transport\n"
      "properties for a gas mixture in a single call. Returns CompleteState\n"
      "struct with nested thermo and transport states.\n\n"
      "Parameters:\n"
      "  T     : temperature [K]\n"
      "  P     : pressure [Pa]\n"
      "  X     : mole fractions [-]\n"
      "  P_ref : reference pressure for entropy [Pa] (default: 101325.0)\n\n"
      "Returns: CompleteState object with nested attributes:\n"
      "  thermo.T, thermo.P, thermo.rho, thermo.cp, thermo.h, etc. (16 "
      "properties)\n"
      "  transport.mu, transport.k, transport.Pr, etc. (9 properties)\n\n"
      "Example:\n"
      "  >>> X = cb.species.dry_air()\n"
      "  >>> state = cb.complete_state(T=300, P=101325, X=X)\n"
      "  >>> print(state.thermo.h)      # Thermodynamic property\n"
      "  -103.6\n"
      "  >>> print(state.transport.mu)  # Transport property\n"
      "  1.68e-05");

  // Humid air utilities
  m.def("dry_air", &dry_air,
        "Get standard dry air composition (mole fractions) as a vector of size "
        "num_species().\n\n"
        "Orders determined by NASA-9 thermo data index.");

  // Alias for backward compatibility
  m.def("standard_dry_air_composition", &dry_air,
        "Alias for dry_air(). Returns standard dry air mole fractions.");

  m.def("humid_air_composition", &humid_air_composition, py::arg("T"),
        py::arg("P"), py::arg("RH"),
        "Humid air mole-fraction composition for temperature T [K], pressure P "
        "[Pa], and relative humidity RH (0-1).");

  m.def("dewpoint", &dewpoint, py::arg("T"), py::arg("P"), py::arg("RH"),
        "Dewpoint temperature [K] for ambient T [K], pressure P [Pa], and RH "
        "(0-1).");

  m.def("relative_humidity_from_dewpoint", &relative_humidity_from_dewpoint,
        py::arg("T"), py::arg("Tdp"), py::arg("P"),
        "Relative humidity (0-1) from dry-bulb T [K], dewpoint Tdp [K], and "
        "pressure P [Pa].\n\n"
        "P is accepted for API symmetry but not used (dewpoint is "
        "pressure-independent\n"
        "at atmospheric conditions).");

  m.def("saturation_vapor_pressure", &saturation_vapor_pressure, py::arg("T"),
        "Water vapor saturation pressure [Pa] using Huang (2018) formula.\n\n"
        "Validated range: -100\u00b0C to +100\u00b0C (173.15\u2013373.15 K).\n"
        "Extrapolation up to 5% of range span (~10 K) is allowed silently.\n"
        "Raises RuntimeError beyond that.\n\n"
        "T : temperature [K]\n\n"
        "Returns: saturation vapor pressure [Pa]");

  m.def("vapor_pressure", &vapor_pressure, py::arg("T"), py::arg("RH"),
        "Actual vapor pressure [Pa] from temperature and relative humidity.\n\n"
        "T  : temperature [K]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: vapor pressure [Pa]");

  m.def("humidity_ratio", &humidity_ratio, py::arg("T"), py::arg("P"),
        py::arg("RH"),
        "Humidity ratio (kg water vapor / kg dry air).\n\n"
        "T  : temperature [K]\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: humidity ratio W [-]");

  m.def("water_vapor_mole_fraction", &water_vapor_mole_fraction, py::arg("T"),
        py::arg("P"), py::arg("RH"),
        "Mole fraction of water vapor in humid air.\n\n"
        "T  : temperature [K]\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: mole fraction of H2O [-]");

  m.def("wet_bulb_temperature", &wet_bulb_temperature, py::arg("T"),
        py::arg("P"), py::arg("RH"),
        "Wet-bulb temperature [K] via Newton-Raphson on the psychrometric "
        "equation.\n\n"
        "Solves: cp_air*(T - Twb) = hfg(Twb)*(Ws(Twb) - W)\n"
        "where hfg(Twb) = 2501000 - 2381*(Twb - 273.15) J/kg (ASHRAE linear "
        "fit).\n\n"
        "T  : dry-bulb temperature [K]\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: wet-bulb temperature [K]");

  m.def("humid_air_enthalpy", &humid_air_enthalpy, py::arg("T"), py::arg("P"),
        py::arg("RH"),
        "Enthalpy of humid air [J/kg dry air] using ASHRAE psychrometric "
        "constants.\n\n"
        "h = cp_air*(T - 273.15) + W*(2501000 + 1860*(T - 273.15))\n"
        "where cp_air=1005, h_fg=2501000, cp_wv=1860 J/(kg\u00b7K).\n\n"
        "T  : temperature [K]\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: enthalpy [J/kg dry air]");

  m.def("humid_air_enthalpy_nasa9", &humid_air_enthalpy_nasa9, py::arg("T"),
        py::arg("P"), py::arg("RH"),
        "Enthalpy of humid air [J/kg dry air] using NASA-9 thermodynamic "
        "data.\n\n"
        "More accurate than humid_air_enthalpy() at non-ambient temperatures.\n"
        "Computes h(T, X) from the NASA-9 polynomial database and converts\n"
        "to J/kg dry air basis.\n\n"
        "T  : temperature [K] (valid range: 200-6000 K)\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: enthalpy [J/kg dry air]");

  m.def("humid_air_density", &humid_air_density, py::arg("T"), py::arg("P"),
        py::arg("RH"),
        "Density of humid air [kg/m\u00b3] using ideal gas law.\n\n"
        "R_ha = R_da * (1 + W/0.621945) / (1 + W), rho = P / (R_ha * T)\n\n"
        "T  : temperature [K]\n"
        "P  : total pressure [Pa]\n"
        "RH : relative humidity (0-1)\n\n"
        "Returns: density [kg/m\u00b3]");

  // Composition conversion helpers
  m.def(
      "mole_to_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return mole_to_mass(X);
      },
      py::arg("X"), "Convert mole fractions X to mass fractions Y.");

  m.def(
      "mass_to_mole",
      [](py::array_t<double> Y) { return mass_to_mole(to_vec(Y)); },
      py::arg("Y"), "Convert mass fractions to mole fractions.");

  m.def(
      "mwmix", [](py::array_t<double> X) { return mwmix(to_vec(X)); },
      py::arg("X"),
      "Calculate mixture molecular weight [g/mol] from mole fractions.");

  // Fraction utilities
  m.def(
      "normalize_fractions",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> arr) {
        auto v = to_vec(arr);
        return normalize_fractions(v);
      },
      py::arg("fractions"),
      "Normalize a vector of fractions so it sums to 1.0 (or return all zeros "
      "if input is all zeros).");

  m.def(
      "convert_to_dry_fractions",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> arr) {
        auto v = to_vec(arr);
        return convert_to_dry_fractions(v);
      },
      py::arg("mole_fractions"),
      "Convert mole fractions to dry fractions by removing water vapor and "
      "renormalizing.");

  // Equivalence ratio (mole basis)
  m.def(
      "equivalence_ratio_mole",
      [](py::array_t<double, py::array::c_style | py::array::forcecast>
             X_mix_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             X_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             X_ox_arr) {
        auto X_mix = to_vec(X_mix_arr);
        auto X_fuel = to_vec(X_fuel_arr);
        auto X_ox = to_vec(X_ox_arr);
        return equivalence_ratio_mole(X_mix, X_fuel, X_ox);
      },
      py::arg("X_mix"), py::arg("X_fuel"), py::arg("X_ox"),
      "Equivalence ratio phi (mole basis) for mixture X_mix formed from fuel "
      "X_fuel and oxidizer X_ox.");

  m.def(
      "set_equivalence_ratio_mole",
      [](double phi,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             X_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             X_ox_arr) {
        auto X_fuel = to_vec(X_fuel_arr);
        auto X_ox = to_vec(X_ox_arr);
        return set_equivalence_ratio_mole(phi, X_fuel, X_ox);
      },
      py::arg("phi"), py::arg("X_fuel"), py::arg("X_ox"),
      "Construct mole-fraction mixture X_mix with target phi from fuel X_fuel "
      "and oxidizer X_ox.");

  // Equivalence ratio (mass basis)
  m.def(
      "equivalence_ratio_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_mix_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_ox_arr) {
        auto Y_mix = to_vec(Y_mix_arr);
        auto Y_fuel = to_vec(Y_fuel_arr);
        auto Y_ox = to_vec(Y_ox_arr);
        return equivalence_ratio_mass(Y_mix, Y_fuel, Y_ox);
      },
      py::arg("Y_mix"), py::arg("Y_fuel"), py::arg("Y_ox"),
      "Equivalence ratio phi (mass basis) for mixture Y_mix formed from fuel "
      "Y_fuel and oxidizer Y_ox.");

  m.def(
      "set_equivalence_ratio_mass",
      [](double phi,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_ox_arr) {
        auto Y_fuel = to_vec(Y_fuel_arr);
        auto Y_ox = to_vec(Y_ox_arr);
        return set_equivalence_ratio_mass(phi, Y_fuel, Y_ox);
      },
      py::arg("phi"), py::arg("Y_fuel"), py::arg("Y_ox"),
      "Construct mass-fraction mixture Y_mix with target phi from fuel Y_fuel "
      "and oxidizer Y_ox.");

  // Bilger-based helpers (mass basis)
  m.def(
      "bilger_stoich_mixture_fraction_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_ox_arr) {
        auto Y_fuel = to_vec(Y_fuel_arr);
        auto Y_ox = to_vec(Y_ox_arr);
        return bilger_stoich_mixture_fraction_mass(Y_fuel, Y_ox);
      },
      py::arg("Y_fuel"), py::arg("Y_ox"),
      "Stoichiometric Bilger mixture fraction Z_st (mass basis) for fuel "
      "Y_fuel and oxidizer Y_ox.");

  m.def(
      "bilger_Z_from_equivalence_ratio_mass",
      [](double phi,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_ox_arr) {
        auto Y_fuel = to_vec(Y_fuel_arr);
        auto Y_ox = to_vec(Y_ox_arr);
        return bilger_Z_from_equivalence_ratio_mass(phi, Y_fuel, Y_ox);
      },
      py::arg("phi"), py::arg("Y_fuel"), py::arg("Y_ox"),
      "Convert mass-basis equivalence ratio phi to Bilger mixture fraction Z "
      "for fuel/oxidizer streams.");

  m.def(
      "equivalence_ratio_from_bilger_Z_mass",
      [](double Z,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_fuel_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             Y_ox_arr) {
        auto Y_fuel = to_vec(Y_fuel_arr);
        auto Y_ox = to_vec(Y_ox_arr);
        return equivalence_ratio_from_bilger_Z_mass(Z, Y_fuel, Y_ox);
      },
      py::arg("Z"), py::arg("Y_fuel"), py::arg("Y_ox"),
      "Convert Bilger mixture fraction Z to mass-basis equivalence ratio phi "
      "for fuel/oxidizer streams.");

  // Inverse temperature calculations
  m.def(
      "calc_T_from_h",
      [](double h_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_h(h_target, X, T_guess, tol, max_iter);
      },
      py::arg("h_target"), py::arg("X"), py::arg("T_guess") = 300.0,
      py::arg("tol") = 1.0e-6, py::arg("max_iter") = 50,
      "Solve for temperature T given target molar enthalpy h_target [J/mol] "
      "and composition X.");

  m.def(
      "calc_T_from_h_mass",
      [](double h_mass_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_h_mass(h_mass_target, X, T_guess, tol, max_iter);
      },
      py::arg("h_mass_target"), py::arg("X"), py::arg("T_guess") = 300.0,
      py::arg("tol") = 1.0e-6, py::arg("max_iter") = 50,
      "Solve for temperature T given target mass enthalpy h_mass_target [J/kg] "
      "and composition X.");

  m.def(
      "calc_T_from_s",
      [](double s_target, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_s(s_target, P, X, T_guess, tol, max_iter);
      },
      py::arg("s_target"), py::arg("P"), py::arg("X"),
      py::arg("T_guess") = 300.0, py::arg("tol") = 1.0e-6,
      py::arg("max_iter") = 50,
      "Solve for temperature T given target entropy s_target, pressure P, and "
      "composition X.");

  m.def(
      "calc_T_from_cp",
      [](double cp_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_cp(cp_target, X, T_guess, tol, max_iter);
      },
      py::arg("cp_target"), py::arg("X"), py::arg("T_guess") = 300.0,
      py::arg("tol") = 1.0e-6, py::arg("max_iter") = 50,
      "Solve for temperature T given target Cp cp_target and composition X.");

  m.def(
      "calc_T_from_u",
      [](double u_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_u(u_target, X, T_guess, tol, max_iter);
      },
      py::arg("u_target"), py::arg("X"), py::arg("T_guess") = 300.0,
      py::arg("tol") = 1.0e-6, py::arg("max_iter") = 50,
      "Solve for temperature T given target molar internal energy u_target [J/mol] "
      "and composition X.");

  m.def(
      "calc_T_from_s_mass",
      [](double s_mass_target, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_s_mass(s_mass_target, P, X, T_guess, tol, max_iter);
      },
      py::arg("s_mass_target"), py::arg("P"), py::arg("X"),
      py::arg("T_guess") = 300.0, py::arg("tol") = 1.0e-6,
      py::arg("max_iter") = 50,
      "Solve for temperature T given target mass entropy s_mass_target [J/(kg*K)], "
      "pressure P [Pa], and composition X.");

  m.def(
      "calc_T_from_u_mass",
      [](double u_mass_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_u_mass(u_mass_target, X, T_guess, tol, max_iter);
      },
      py::arg("u_mass_target"), py::arg("X"), py::arg("T_guess") = 300.0,
      py::arg("tol") = 1.0e-6, py::arg("max_iter") = 50,
      "Solve for temperature T given target mass internal energy u_mass_target [J/kg] "
      "and composition X.");

  m.def(
      "calc_T_from_sv_mass",
      [](double s_mass_target, double v_mass_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_sv_mass(s_mass_target, v_mass_target, X, T_guess, tol, max_iter);
      },
      py::arg("s_mass_target"), py::arg("v_mass_target"), py::arg("X"),
      py::arg("T_guess") = 300.0, py::arg("tol") = 1.0e-6,
      py::arg("max_iter") = 50,
      "Solve for temperature T given target mass entropy s_mass_target [J/(kg*K)], "
      "mass specific volume v_mass_target [m^3/kg], and composition X.");

  m.def(
      "calc_T_from_sh_mass",
      [](double s_mass_target, double h_mass_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double T_guess, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return calc_T_from_sh_mass(s_mass_target, h_mass_target, X, T_guess, tol, max_iter);
      },
      py::arg("s_mass_target"), py::arg("h_mass_target"), py::arg("X"),
      py::arg("T_guess") = 300.0, py::arg("tol") = 1.0e-6,
      py::arg("max_iter") = 50,
      "Solve for temperature T given target mass entropy s_mass_target [J/(kg*K)], "
      "mass enthalpy h_mass_target [J/kg], and composition X.");

  // Thermodynamic derivatives
  m.def(
      "dh_dT",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return dh_dT(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass enthalpy derivative dh/dT [J/(kg*K)] at temperature T and composition X.");

  m.def(
      "ds_dT",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return ds_dT(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass entropy derivative ds/dT [J/(kg*K^2)] at temperature T and composition X.");

  m.def(
      "dcp_dT",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return dcp_dT(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Mass specific heat derivative dcp/dT [J/(kg*K^2)] at temperature T and composition X.");

  m.def(
      "dg_over_RT_dT",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return dg_over_RT_dT(T, X);
      },
      py::arg("T"), py::arg("X"),
      "Derivative of dimensionless Gibbs energy g/RT with respect to T [1/K] "
      "at temperature T and composition X.");

  // Oxygen requirement helpers (scalar fuel index and mixtures)
  m.def("oxygen_required_per_mol_fuel", &oxygen_required_per_mol_fuel,
        py::arg("fuel_index"),
        "Moles O2 required per mole of pure fuel species (by index).");

  m.def("oxygen_required_per_kg_fuel", &oxygen_required_per_kg_fuel,
        py::arg("fuel_index"),
        "Mass of O2 [kg] required per kg of pure fuel species (by index).");

  m.def(
      "oxygen_required_per_mol_mixture",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return oxygen_required_per_mol_mixture(X);
      },
      py::arg("X"),
      "Moles O2 required per mole of fuel mixture with mole fractions X.");

  m.def(
      "oxygen_required_per_kg_mixture",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        auto X = to_vec(X_arr);
        return oxygen_required_per_kg_mixture(X);
      },
      py::arg("X"),
      "Mass of O2 [kg] required per kg of fuel mixture with mole fractions X.");

  m.def(
      "fuel_lhv_molar",
      [](py::array_t<double, py::array::c_style | py::array::forcecast>
             X_fuel_arr,
         double reference_temperature) {
        auto X_fuel = to_vec(X_fuel_arr);
        return fuel_lhv_molar(X_fuel, reference_temperature);
      },
      py::arg("X_fuel"), py::arg("reference_temperature") = 298.15,
      "Fuel lower heating value (LHV) on molar basis [J/mol fuel mixture].\n\n"
      "Computed from complete combustion to CO2 + H2O(g) at reference "
      "temperature.");

  m.def(
      "fuel_lhv_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast>
             X_fuel_arr,
         double reference_temperature) {
        auto X_fuel = to_vec(X_fuel_arr);
        return fuel_lhv_mass(X_fuel, reference_temperature);
      },
      py::arg("X_fuel"), py::arg("reference_temperature") = 298.15,
      "Fuel lower heating value (LHV) on mass basis [J/kg fuel mixture].\n\n"
      "Computed from complete combustion to CO2 + H2O(g) at reference "
      "temperature.");

  // Complete combustion helper
  m.def(
      "complete_combustion_to_CO2_H2O",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         bool smooth) {
        auto X = to_vec(X_arr);
        return complete_combustion_to_CO2_H2O(X, smooth);
      },
      py::arg("X"), py::arg("smooth") = false,
      "Complete combustion of mixture X to CO2 and H2O (returns product mole "
      "fractions).");

  m.def(
      "complete_combustion_to_CO2_H2O_with_fraction",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         bool smooth) {
        auto X = to_vec(X_arr);
        double f = 0.0;
        auto X_out = complete_combustion_to_CO2_H2O(X, f, smooth);
        return py::make_tuple(X_out, f);
      },
      py::arg("X"), py::arg("smooth") = false,
      "Complete combustion of mixture X to CO2 and H2O, returning (product "
      "mole fractions, fuel burn fraction f).");

  m.def(
      "adiabatic_T_wgs",
      [](double T_in,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             X_in_arr,
         double P) {
        auto X_in = to_vec(X_in_arr);
        if (X_in.empty())
          throw std::runtime_error("X_in must be non-empty");

        State in;
        in.T = T_in;
        in.P = P;
        in.X = X_in;

        EquilibriumResult out = wgs_equilibrium_adiabatic(in);
        return out.state.T;
      },
      py::arg("T_in"), py::arg("X_in"), py::arg("P") = 101325.0,
      "Adiabatic flame temperature with WGS limited equilibrium.\n\n"
      "T_in : inlet temperature [K]\n"
      "X_in : inlet mole fractions (1D NumPy array)\n"
      "P    : pressure [Pa] (default 101325)");

  // State struct binding - Pythonic property-based API
  py::class_<State>(m, "State")
      .def(py::init<>())
      // Mutable state variables (read/write properties)
      .def_readwrite("T", &State::T, "Temperature [K]")
      .def_readwrite("P", &State::P, "Pressure [Pa]")
      .def_property(
          "X", [](const State &s) { return s.X; },
          [](State &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 X_arr) { s.set_X(to_vec(X_arr)); },
          "Mole fractions [-]")
      .def_property(
          "Y", [](const State &s) { return s.Y; },
          [](State &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 Y_arr) { s.set_Y(to_vec(Y_arr)); },
          "Mass fractions [-]")
      // Computed thermodynamic properties (read-only)
      .def_property_readonly("mw", &State::mw, "Molecular weight [g/mol]")
      .def_property_readonly("cp", &State::cp,
                             "Specific heat at constant pressure [J/(kg·K)]")
      .def_property_readonly("h", &State::h, "Specific enthalpy [J/kg]")
      .def_property_readonly("s", &State::s, "Specific entropy [J/(kg·K)]")
      .def_property_readonly("cv", &State::cv,
                             "Specific heat at constant volume [J/(kg·K)]")
      .def_property_readonly("u", &State::u, "Specific internal energy [J/kg]")
      .def_property_readonly("rho", &State::rho, "Density [kg/m³]")
      .def_property_readonly("R", &State::R, "Specific gas constant [J/(kg·K)]")
      .def_property_readonly("gamma", &State::gamma,
                             "Isentropic expansion coefficient [-]")
      .def_property_readonly("a", &State::a, "Speed of sound [m/s]")
      // Transport properties (read-only)
      .def_property_readonly("mu", &State::mu, "Dynamic viscosity [Pa·s]")
      .def_property_readonly("k", &State::k, "Thermal conductivity [W/(m·K)]")
      .def_property_readonly("nu", &State::nu, "Kinematic viscosity [m²/s]")
      .def_property_readonly("Pr", &State::Pr, "Prandtl number [-]")
      .def_property_readonly("alpha", &State::alpha,
                             "Thermal diffusivity [m²/s]")
      // Fluent setters (return self for chaining)
      .def("set_T", &State::set_T, py::arg("T"),
           "Set temperature [K], returns self")
      .def("set_P", &State::set_P, py::arg("P"),
           "Set pressure [Pa], returns self")
      .def(
          "set_X",
          [](State &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 X_arr) -> State & { return s.set_X(to_vec(X_arr)); },
          py::arg("X"), "Set mole fractions [-], returns self")
      .def(
          "set_Y",
          [](State &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 Y_arr) -> State & { return s.set_Y(to_vec(Y_arr)); },
          py::arg("Y"), "Set mass fractions [-], returns self")
      .def(
          "set_TPX",
          [](State &s, double T, double P,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 X_arr) -> State & { return s.set_TPX(T, P, to_vec(X_arr)); },
          py::arg("T"), py::arg("P"), py::arg("X"),
          "Set temperature, pressure, and mole fractions, returns self")
      .def(
          "set_TPY",
          [](State &s, double T, double P,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 Y_arr) -> State & { return s.set_TPY(T, P, to_vec(Y_arr)); },
          py::arg("T"), py::arg("P"), py::arg("Y"),
          "Set temperature, pressure, and mass fractions, returns self")
      .def("set_TP", &State::set_TP, py::arg("T"), py::arg("P"),
           "Set temperature and pressure, returns self")
      .def("set_DP_mass", &State::set_DP_mass, py::arg("rho"), py::arg("P"),
           "Set density and pressure, returns self")
      .def("set_HP_mass", &State::set_HP_mass, py::arg("h"), py::arg("P"),
           "Set mass enthalpy and pressure, returns self")
      .def("set_SP_mass", &State::set_SP_mass, py::arg("s"), py::arg("P"),
           "Set mass entropy and pressure, returns self")
      .def("set_UV_mass", &State::set_UV_mass, py::arg("u"), py::arg("v"),
           "Set mass internal energy and mass specific volume, returns self")
      .def("set_SV_mass", &State::set_SV_mass, py::arg("s"), py::arg("v"),
           "Set mass entropy and mass specific volume, returns self")
      .def("set_PV_mass", &State::set_PV_mass, py::arg("P"), py::arg("v"),
           "Set pressure and mass specific volume, returns self")
      .def("set_UP_mass", &State::set_UP_mass, py::arg("u"), py::arg("P"),
           "Set mass internal energy and pressure, returns self")
      .def("set_VH_mass", &State::set_VH_mass, py::arg("v"), py::arg("h"),
           "Set mass specific volume and mass enthalpy, returns self")
      .def("set_SH_mass", &State::set_SH_mass, py::arg("s"), py::arg("h"),
           "Set mass entropy and mass enthalpy, returns self")
      // Pythonic tuple properties
      .def_property(
          "TPX", [](const State &s) { return py::make_tuple(s.T, s.P, s.X); },
          [](State &s, py::tuple t) {
            if (t.size() != 3)
              throw std::invalid_argument("TPX must be a 3-tuple (T, P, X)");
            auto X_arr =
                t[2].cast<py::array_t<double, py::array::c_style |
                                                  py::array::forcecast>>();
            s.set_TPX(t[0].cast<double>(), t[1].cast<double>(), to_vec(X_arr));
          },
          "Get/Set Temperature [K], Pressure [Pa], and Mole Fractions as a "
          "tuple (T, P, X)")
      .def_property(
          "TPY",
          [](const State &s) {
            return py::make_tuple(s.T, s.P, mole_to_mass(s.X));
          },
          [](State &s, py::tuple t) {
            if (t.size() != 3)
              throw std::invalid_argument("TPY must be a 3-tuple (T, P, Y)");
            auto Y_arr =
                t[2].cast<py::array_t<double, py::array::c_style |
                                                  py::array::forcecast>>();
            s.set_TPY(t[0].cast<double>(), t[1].cast<double>(), to_vec(Y_arr));
          },
          "Get/Set Temperature [K], Pressure [Pa], and Mass Fractions as a "
          "tuple (T, P, Y)")
      .def_property(
          "TP", [](const State &s) { return py::make_tuple(s.T, s.P); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("TP must be a 2-tuple (T, P)");
            s.set_TP(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Temperature [K] and Pressure [Pa] as a tuple (T, P)")
      .def_property(
          "DP", [](const State &s) { return py::make_tuple(s.rho(), s.P); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("DP must be a 2-tuple (rho, P)");
            s.set_DP_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Density [kg/m³] and Pressure [Pa] as a tuple (rho, P)")
      .def_property(
          "HP", [](const State &s) { return py::make_tuple(s.h(), s.P); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("HP must be a 2-tuple (h, P)");
            s.set_HP_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Enthalpy [J/kg] and Pressure [Pa] as a tuple (h, P)")
      .def_property(
          "SP", [](const State &s) { return py::make_tuple(s.s(), s.P); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("SP must be a 2-tuple (s, P)");
            s.set_SP_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Entropy [J/(kg K)] and Pressure [Pa] as a tuple (s, P)")
      .def_property(
          "UV",
          [](const State &s) {
            double v_mass = 1.0 / s.rho();
            return py::make_tuple(s.u(), v_mass);
          },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("UV must be a 2-tuple (u, v)");
            s.set_UV_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Internal Energy [J/kg] and Mass Specific Volume "
          "[m³/kg] as a tuple (u, v)")
      .def_property(
          "SV",
          [](const State &s) {
            double v_mass = 1.0 / s.rho();
            return py::make_tuple(s.s(), v_mass);
          },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("SV must be a 2-tuple (s, v)");
            s.set_SV_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Entropy [J/(kg K)] and Mass Specific Volume [m³/kg] as "
          "a tuple (s, v)")
      .def_property(
          "PV",
          [](const State &s) {
            double v_mass = 1.0 / s.rho();
            return py::make_tuple(s.P, v_mass);
          },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("PV must be a 2-tuple (P, v)");
            s.set_PV_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Pressure [Pa] and Mass Specific Volume [m³/kg] as a tuple "
          "(P, v)")
      .def_property(
          "UP", [](const State &s) { return py::make_tuple(s.u(), s.P); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("UP must be a 2-tuple (u, P)");
            s.set_UP_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Internal Energy [J/kg] and Pressure [Pa] as a tuple "
          "(u, P)")
      .def_property(
          "VH",
          [](const State &s) {
            double v_mass = 1.0 / s.rho();
            return py::make_tuple(v_mass, s.h());
          },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("VH must be a 2-tuple (v, h)");
            s.set_VH_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Specific Volume [m³/kg] and Mass Enthalpy [J/kg] as a "
          "tuple (v, h)")
      .def_property(
          "SH", [](const State &s) { return py::make_tuple(s.s(), s.h()); },
          [](State &s, py::tuple t) {
            if (t.size() != 2)
              throw std::invalid_argument("SH must be a 2-tuple (s, h)");
            s.set_SH_mass(t[0].cast<double>(), t[1].cast<double>());
          },
          "Get/Set Mass Entropy [J/(kg K)] and Mass Enthalpy [J/kg] as a tuple "
          "(s, h)");

  // AirProperties is a type alias for TransportState (same C++ type).
  // Expose as a module attribute for backward compatibility.
  m.attr("AirProperties") = m.attr("TransportState");

  m.def("air_properties", &air_properties, py::arg("T"), py::arg("P"),
        py::arg("humidity") = 0.0,
        "Compute all air properties at once.\n\n"
        "Convenience function that computes all thermodynamic and transport\n"
        "properties of air in a single call. Returns a TransportState\n"
        "(also accessible as AirProperties) with read-only attributes.\n\n"
        "Parameters:\n"
        "  T        : temperature [K]\n"
        "  P        : pressure [Pa]\n"
        "  humidity : relative humidity [0-1] (default: 0.0 = dry air)\n\n"
        "Returns: TransportState with attributes:\n"
        "  T, P, rho, mu, k, nu, alpha, Pr, cp, cv, gamma, a\n\n"
        "Example:\n"
        "  >>> props = cb.air_properties(T=300, P=101325, humidity=0.5)\n"
        "  >>> print(props.rho)  # IDE autocomplete works!\n"
        "  1.177\n"
        "  >>> print(props.gamma)\n"
        "  1.4");

  // ThermoState struct binding - Bundle of thermodynamic properties
  py::class_<ThermoState>(
      m, "ThermoState",
      "Bundle of thermodynamic properties for a gas mixture.\n\n"
      "All properties are read-only attributes computed in a single call.\n"
      "Provides IDE autocomplete and type safety.\n\n"
      "Attributes:\n"
      "  T        : Temperature [K] (input, echoed back)\n"
      "  P        : Pressure [Pa] (input, echoed back)\n"
      "  rho      : Density [kg/m³]\n"
      "  cp       : Specific heat at constant pressure [J/(kg·K)]\n"
      "  cv       : Specific heat at constant volume [J/(kg·K)]\n"
      "  h        : Specific enthalpy [J/kg]\n"
      "  s        : Specific entropy [J/(kg·K)]\n"
      "  u        : Specific internal energy [J/kg]\n"
      "  gamma    : Isentropic expansion coefficient [-]\n"
      "  a        : Speed of sound [m/s]\n"
      "  cp_mole  : Molar cp [J/(mol·K)]\n"
      "  cv_mole  : Molar cv [J/(mol·K)]\n"
      "  h_mole   : Molar enthalpy [J/mol]\n"
      "  s_mole   : Molar entropy [J/(mol·K)]\n"
      "  u_mole   : Molar internal energy [J/mol]\n"
      "  mw       : Molecular weight [g/mol]")
      .def_readonly("T", &ThermoState::T, "Temperature [K]")
      .def_readonly("P", &ThermoState::P, "Pressure [Pa]")
      .def_readonly("rho", &ThermoState::rho, "Density [kg/m³]")
      .def_readonly("cp", &ThermoState::cp,
                    "Specific heat at constant pressure [J/(kg·K)]")
      .def_readonly("cv", &ThermoState::cv,
                    "Specific heat at constant volume [J/(kg·K)]")
      .def_readonly("h", &ThermoState::h, "Specific enthalpy [J/kg]")
      .def_readonly("s", &ThermoState::s, "Specific entropy [J/(kg·K)]")
      .def_readonly("u", &ThermoState::u, "Specific internal energy [J/kg]")
      .def_readonly("gamma", &ThermoState::gamma,
                    "Isentropic expansion coefficient [-]")
      .def_readonly("a", &ThermoState::a, "Speed of sound [m/s]")
      .def_readonly("cp_mole", &ThermoState::cp_mole, "Molar cp [J/(mol·K)]")
      .def_readonly("cv_mole", &ThermoState::cv_mole, "Molar cv [J/(mol·K)]")
      .def_readonly("h_mole", &ThermoState::h_mole, "Molar enthalpy [J/mol]")
      .def_readonly("s_mole", &ThermoState::s_mole, "Molar entropy [J/(mol·K)]")
      .def_readonly("u_mole", &ThermoState::u_mole,
                    "Molar internal energy [J/mol]")
      .def_readonly("mw", &ThermoState::mw, "Molecular weight [g/mol]")
      .def("__repr__", [](const ThermoState &s) {
        return "<ThermoState: T=" + std::to_string(s.T) +
               " K, "
               "P=" +
               std::to_string(s.P) +
               " Pa, "
               "rho=" +
               std::to_string(s.rho) + " kg/m³>";
      });

  m.def("thermo_state", &thermo_state, py::arg("T"), py::arg("P"), py::arg("X"),
        py::arg("P_ref") = 101325.0,
        "Compute all thermodynamic properties at once.\n\n"
        "Convenience function that computes all thermodynamic properties\n"
        "for a gas mixture in a single call. Returns ThermoState struct\n"
        "with read-only attributes for IDE autocomplete support.\n\n"
        "Parameters:\n"
        "  T     : temperature [K]\n"
        "  P     : pressure [Pa]\n"
        "  X     : mole fractions [-]\n"
        "  P_ref : reference pressure for entropy [Pa] (default: 101325.0)\n\n"
        "Returns: ThermoState object with attributes:\n"
        "  T, P, rho, cp, cv, h, s, u, gamma, a,\n"
        "  cp_mole, cv_mole, h_mole, s_mole, u_mole, mw\n\n"
        "Example:\n"
        "  >>> X = cb.species.dry_air()\n"
        "  >>> state = cb.thermo_state(T=300, P=101325, X=X)\n"
        "  >>> print(state.h)  # IDE autocomplete works!\n"
        "  8682.5\n"
        "  >>> print(state.gamma)\n"
        "  1.400");

  // Stream struct binding - Pythonic property-based API
  py::class_<Stream>(m, "Stream")
      .def(py::init<>())
      .def_readwrite("state", &Stream::state, "Thermodynamic state")
      // Mutable state (read/write properties)
      .def_property(
          "T", [](const Stream &s) { return s.T(); },
          [](Stream &s, double T) { s.set_T(T); }, "Temperature [K]")
      .def_property(
          "P", [](const Stream &s) { return s.P(); },
          [](Stream &s, double P) { s.set_P(P); }, "Pressure [Pa]")
      .def_property(
          "X", [](const Stream &s) { return s.X(); },
          [](Stream &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 X_arr) { s.set_X(to_vec(X_arr)); },
          "Mole fractions [-]")
      .def_readwrite("mdot", &Stream::mdot, "Mass flow rate [kg/s]")
      // Computed properties (read-only)
      .def_property_readonly("mw", &Stream::mw, "Molecular weight [g/mol]")
      .def_property_readonly("cp", &Stream::cp,
                             "Specific heat at constant pressure [J/(kg·K)]")
      .def_property_readonly("h", &Stream::h, "Specific enthalpy [J/kg]")
      .def_property_readonly("s", &Stream::s, "Specific entropy [J/(kg·K)]")
      .def_property_readonly("rho", &Stream::rho, "Density [kg/m³]")
      // Fluent setters (return self for chaining)
      .def("set_T", &Stream::set_T, py::arg("T"),
           "Set temperature [K], returns self")
      .def("set_P", &Stream::set_P, py::arg("P"),
           "Set pressure [Pa], returns self")
      .def(
          "set_X",
          [](Stream &s,
             py::array_t<double, py::array::c_style | py::array::forcecast>
                 X_arr) -> Stream & { return s.set_X(to_vec(X_arr)); },
          py::arg("X"), "Set mole fractions [-], returns self")
      .def("set_mdot", &Stream::set_mdot, py::arg("mdot"),
           "Set mass flow rate [kg/s], returns self");

  // -------------------------------------------------------------
  // HumidAir State Object
  // -------------------------------------------------------------
  py::class_<HumidAir>(m, "HumidAir")
      .def(py::init<>())
      .def_readwrite("state", &HumidAir::state,
                     "Core CombAero thermodynamic state")
      // Properties
      .def_property(
          "rh", &HumidAir::RH,
          [](HumidAir &h, double rh) { h.set_TP_RH(h.state.T, h.state.P, rh); },
          "Relative humidity [0-1]")
      .def_property_readonly("dewpoint", &HumidAir::dewpoint,
                             "Dewpoint temperature [K]")
      .def_property_readonly("wet_bulb", &HumidAir::wet_bulb,
                             "Wet-bulb temperature [K]")
      .def_property_readonly("humidity_ratio", &HumidAir::humidity_ratio,
                             "Humidity ratio [-]")
      .def_property_readonly(
          "h_mass", &HumidAir::h_mass,
          "ASHRAE psychrometric specific enthalpy [J/kg dry air]")
      // Tuple-like properties
      .def_property(
          "TP_RH", [](const HumidAir &h) { return h.TP_RH(); },
          [](HumidAir &h, std::tuple<double, double, double> tp_rh) {
            h.set_TP_RH(std::get<0>(tp_rh), std::get<1>(tp_rh),
                        std::get<2>(tp_rh));
          },
          "Get/Set T, P, RH tuple")
      .def_property(
          "TP_dewpoint", [](const HumidAir &h) { return h.TP_dewpoint(); },
          [](HumidAir &h, std::tuple<double, double, double> tp_tdp) {
            h.set_TP_dewpoint(std::get<0>(tp_tdp), std::get<1>(tp_tdp),
                              std::get<2>(tp_tdp));
          },
          "Get/Set T, P, dewpoint tuple")
      // Fluent setters (return self for chaining)
      .def("set_TP_RH", &HumidAir::set_TP_RH, py::arg("T"), py::arg("P"),
           py::arg("RH"), "Set T, P, RH, returns self")
      .def("set_TP_dewpoint", &HumidAir::set_TP_dewpoint, py::arg("T"),
           py::arg("P"), py::arg("Tdp"), "Set T, P, dewpoint, returns self")
      .def("set_TP_omega", &HumidAir::set_TP_omega, py::arg("T"), py::arg("P"),
           py::arg("w"), "Set T, P, humidity ratio, returns self");

  // Stream mixing function
  m.def(
      "mix",
      [](const std::vector<Stream> &streams, double P_out) {
        return mix(streams, P_out);
      },
      py::arg("streams"), py::arg("P_out") = -1.0,
      "Mix multiple streams, solving mass and enthalpy balance.\n\n"
      "streams : list of Stream objects\n"
      "P_out   : output pressure [Pa] (default: minimum inlet pressure)\n\n"
      "Returns mixed Stream.");

  // -------------------------------------------------------------
  // Inverse solvers for fuel/oxidizer streams (complete combustion only)
  // -------------------------------------------------------------

  // --- Find fuel stream (oxidizer mdot fixed) ---

  m.def("set_fuel_stream_for_phi", &set_fuel_stream_for_phi, py::arg("phi"),
        py::arg("fuel"), py::arg("oxidizer"),
        "Find fuel stream mass flow rate for target equivalence ratio phi.\n\n"
        "This is a direct algebraic helper (no iteration):\n"
        "  fuel.mdot = phi * fuel_stoich_mdot(oxidizer stream)\n\n"
        "Parameters:\n"
        "  phi      : target equivalence ratio [-]\n"
        "  fuel     : fuel Stream (T, P, X set; mdot ignored)\n"
        "  oxidizer : oxidizer Stream (with mdot set)\n\n"
        "Returns: fuel Stream with mdot set for requested phi.");

  m.def(
      "set_fuel_stream_for_Tad",
      [](double T_ad_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter, bool lean, double phi_max) {
        return set_fuel_stream_for_Tad(T_ad_target, fuel, oxidizer, tol,
                                       max_iter, lean, phi_max);
      },
      py::arg("T_ad_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1.0, py::arg("max_iter") = 100, py::arg("lean") = true,
      py::arg("phi_max") = 10.0,
      "Find fuel mass flow rate to achieve target adiabatic flame "
      "temperature.\n\n"
      "Uses complete combustion to CO2/H2O (no WGS).\n\n"
      "T_ad_target : target adiabatic flame temperature [K] (must be > "
      "oxidizer T)\n"
      "fuel        : fuel Stream (T, P, X set; mdot ignored)\n"
      "oxidizer    : oxidizer Stream (with mdot set)\n"
      "tol         : temperature tolerance [K] (default: 1.0)\n"
      "max_iter    : maximum iterations (default: 100)\n"
      "lean        : if True (default), search on lean side; if False, search "
      "on rich side\n"
      "phi_max     : maximum equivalence ratio for rich side search (default: "
      "10.0)\n\n"
      "Returns fuel Stream with mdot set to achieve target T_ad.");

  m.def(
      "set_fuel_stream_for_O2",
      [](double X_O2_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_fuel_stream_for_O2(X_O2_target, fuel, oxidizer, tol,
                                      max_iter);
      },
      py::arg("X_O2_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find fuel mass flow rate to achieve target O2 mole fraction in burned "
      "products (wet basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.");

  m.def(
      "set_fuel_stream_for_O2_dry",
      [](double X_O2_dry_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_fuel_stream_for_O2_dry(X_O2_dry_target, fuel, oxidizer, tol,
                                          max_iter);
      },
      py::arg("X_O2_dry_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find fuel mass flow rate to achieve target O2 mole fraction in burned "
      "products (dry basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.\n"
      "Dry basis: water vapor removed from products before computing mole "
      "fraction.");

  m.def(
      "set_fuel_stream_for_CO2",
      [](double X_CO2_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_fuel_stream_for_CO2(X_CO2_target, fuel, oxidizer, tol,
                                       max_iter);
      },
      py::arg("X_CO2_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find fuel mass flow rate to achieve target CO2 mole fraction in burned "
      "products (wet basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.");

  m.def(
      "set_fuel_stream_for_CO2_dry",
      [](double X_CO2_dry_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_fuel_stream_for_CO2_dry(X_CO2_dry_target, fuel, oxidizer,
                                           tol, max_iter);
      },
      py::arg("X_CO2_dry_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find fuel mass flow rate to achieve target CO2 mole fraction in burned "
      "products (dry basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.\n"
      "Dry basis: water vapor removed from products before computing mole "
      "fraction.");

  // --- Find oxidizer stream (fuel mdot fixed) ---

  m.def(
      "set_oxidizer_stream_for_Tad",
      [](double T_ad_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter, bool lean, double phi_max) {
        return set_oxidizer_stream_for_Tad(T_ad_target, fuel, oxidizer, tol,
                                           max_iter, lean, phi_max);
      },
      py::arg("T_ad_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1.0, py::arg("max_iter") = 100, py::arg("lean") = true,
      py::arg("phi_max") = 10.0,
      "Find oxidizer mass flow rate to achieve target adiabatic flame "
      "temperature.\n\n"
      "Uses complete combustion to CO2/H2O (no WGS).\n\n"
      "T_ad_target : target adiabatic flame temperature [K] (must be > fuel "
      "T)\n"
      "fuel        : fuel Stream (with mdot set)\n"
      "oxidizer    : oxidizer Stream (T, P, X set; mdot ignored)\n"
      "tol         : temperature tolerance [K] (default: 1.0)\n"
      "max_iter    : maximum iterations (default: 100)\n"
      "lean        : if True (default), search on lean side; if False, search "
      "on rich side\n"
      "phi_max     : maximum equivalence ratio for search range (default: "
      "10.0)\n\n"
      "Returns oxidizer Stream with mdot set to achieve target T_ad.");

  m.def(
      "set_oxidizer_stream_for_O2",
      [](double X_O2_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_oxidizer_stream_for_O2(X_O2_target, fuel, oxidizer, tol,
                                          max_iter);
      },
      py::arg("X_O2_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find oxidizer mass flow rate to achieve target O2 mole fraction in "
      "burned products (wet basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.");

  m.def(
      "set_oxidizer_stream_for_O2_dry",
      [](double X_O2_dry_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_oxidizer_stream_for_O2_dry(X_O2_dry_target, fuel, oxidizer,
                                              tol, max_iter);
      },
      py::arg("X_O2_dry_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find oxidizer mass flow rate to achieve target O2 mole fraction in "
      "burned products (dry basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.\n"
      "Dry basis: water vapor removed from products before computing mole "
      "fraction.");

  m.def(
      "set_oxidizer_stream_for_CO2",
      [](double X_CO2_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_oxidizer_stream_for_CO2(X_CO2_target, fuel, oxidizer, tol,
                                           max_iter);
      },
      py::arg("X_CO2_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find oxidizer mass flow rate to achieve target CO2 mole fraction in "
      "burned products (wet basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.");

  m.def(
      "set_oxidizer_stream_for_CO2_dry",
      [](double X_CO2_dry_target, const Stream &fuel, const Stream &oxidizer,
         double tol, std::size_t max_iter) {
        return set_oxidizer_stream_for_CO2_dry(X_CO2_dry_target, fuel, oxidizer,
                                               tol, max_iter);
      },
      py::arg("X_CO2_dry_target"), py::arg("fuel"), py::arg("oxidizer"),
      py::arg("tol") = 1e-6, py::arg("max_iter") = 100,
      "Find oxidizer mass flow rate to achieve target CO2 mole fraction in "
      "burned products (dry basis).\n\n"
      "Uses complete combustion to CO2/H2O (no WGS). Lean combustion only.\n"
      "Dry basis: water vapor removed from products before computing mole "
      "fraction.");

  // State-based combustion functions
  m.def(
      "complete_combustion",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P, bool smooth_phi0, bool smooth_phi1, double k0, double k1) {
        State in;
        in.T = T;
        in.P = P;
        in.X = to_vec(X_arr);
        return complete_combustion(in, smooth_phi0, smooth_phi1, k0, k1);
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      py::arg("smooth_phi0") = true, py::arg("smooth_phi1") = true,
      py::arg("k0") = combaero::SMOOTHING_K_PHI0,
      py::arg("k1") = combaero::SMOOTHING_K_PHI1,
      "Adiabatic complete combustion to CO2 and H2O.\n\n"
      "Returns State with adiabatic flame temperature and burned composition.");

  m.def(
      "complete_combustion_isothermal",
      [](double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P, bool smooth_phi0, bool smooth_phi1, double k0, double k1) {
        State in;
        in.T = T;
        in.P = P;
        in.X = to_vec(X_arr);
        return complete_combustion_isothermal(in, smooth_phi0, smooth_phi1, k0,
                                              k1);
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      py::arg("smooth_phi0") = true, py::arg("smooth_phi1") = true,
      py::arg("k0") = combaero::SMOOTHING_K_PHI0,
      py::arg("k1") = combaero::SMOOTHING_K_PHI1,
      "Isothermal complete combustion to CO2 and H2O.\n\n"
      "Returns State with reactant temperature and burned composition.");

  // Helper: construct State from (T, P, X_arr) — avoids 4-line boilerplate in
  // every binding
  auto make_state =
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        State s;
        s.T = T;
        s.P = P;
        s.X = to_vec(X_arr);
        return s;
      };

  // State-based WGS equilibrium functions
  m.def(
      "wgs_equilibrium",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) { return wgs_equilibrium(make_state(T, P, X_arr)); },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Isothermal WGS equilibrium (CO + H2O <-> CO2 + H2).\n\n"
      "Returns EquilibriumResult with equilibrium composition at input "
      "temperature.");

  m.def(
      "wgs_equilibrium_adiabatic",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) {
        return wgs_equilibrium_adiabatic(make_state(T, P, X_arr));
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Adiabatic WGS equilibrium (CO + H2O <-> CO2 + H2).\n\n"
      "Returns EquilibriumResult with equilibrium temperature and "
      "composition.");

  // SMR+WGS equilibrium (CH4 only) — deprecated, use reforming_equilibrium
  // instead
  m.def(
      "smr_wgs_equilibrium",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) { return smr_wgs_equilibrium(make_state(T, P, X_arr)); },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Isothermal SMR+WGS equilibrium for CH4 (deprecated).\n\n"
      "Use reforming_equilibrium instead — it handles CH4 and all other "
      "hydrocarbons.\n\n"
      "Returns EquilibriumResult with equilibrium composition at input "
      "temperature.");

  m.def(
      "smr_wgs_equilibrium_adiabatic",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) {
        return smr_wgs_equilibrium_adiabatic(make_state(T, P, X_arr));
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Adiabatic SMR+WGS equilibrium for CH4 (deprecated).\n\n"
      "Use reforming_equilibrium_adiabatic instead.\n\n"
      "Returns EquilibriumResult with equilibrium temperature and "
      "composition.");

  // General reforming + WGS equilibrium (all hydrocarbons)
  m.def(
      "reforming_equilibrium",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) { return reforming_equilibrium(make_state(T, P, X_arr)); },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Isothermal steam reforming + WGS equilibrium for all hydrocarbons.\n\n"
      "General reforming: CnHm + n*H2O <-> n*CO + (n + m/2)*H2\n"
      "Water-Gas Shift: CO + H2O <-> CO2 + H2\n\n"
      "Handles all hydrocarbons: CH4, C2H6, C3H8, iC4H10, nC5H12, etc.\n"
      "Returns EquilibriumResult with equilibrium composition at input "
      "temperature.");

  m.def(
      "reforming_equilibrium_adiabatic",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P) {
        return reforming_equilibrium_adiabatic(make_state(T, P, X_arr));
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      "Adiabatic steam reforming + WGS equilibrium for all hydrocarbons.\n\n"
      "General reforming: CnHm + n*H2O <-> n*CO + (n + m/2)*H2\n"
      "Water-Gas Shift: CO + H2O <-> CO2 + H2\n\n"
      "Handles all hydrocarbons: CH4, C2H6, C3H8, iC4H10, nC5H12, etc.\n"
      "Returns EquilibriumResult with equilibrium temperature and "
      "composition.");

  // Combustion + Equilibrium (convenience function)
  m.def(
      "combustion_equilibrium",
      [make_state](
          double T,
          py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
          double P, bool smooth, double k0) {
        return combustion_equilibrium(make_state(T, P, X_arr), smooth, k0);
      },
      py::arg("T"), py::arg("X"), py::arg("P") = 101325.0,
      py::arg("smooth") = true, py::arg("k0") = combaero::SMOOTHING_K_PHI0,
      "Combustion + equilibrium in one step.\n\n"
      "Combines complete combustion with reforming + WGS equilibrium.\n"
      "Use this when starting from an unburned fuel+air mixture.\n\n"
      "Workflow:\n"
      "  1. Complete combustion (fuel + O2 -> CO2 + H2O)\n"
      "  2. Reforming + WGS equilibrium on products\n\n"
      "Returns State with equilibrium temperature and composition.");

  // -------------------------------------------------------------
  // Friction factor correlations
  // -------------------------------------------------------------

  m.def("friction_haaland", &friction_haaland, py::arg("Re"), py::arg("e_D"),
        "Haaland friction factor correlation (1983).\n\n"
        "Explicit approximation to Colebrook-White equation.\n"
        "Accuracy: ~2-3% vs Colebrook-White.\n\n"
        "f = 1 / [-1.8 * log10((e_D/3.7)^1.11 + 6.9/Re)]^2\n\n"
        "Parameters:\n"
        "  Re  : Reynolds number [-] (must be > 0)\n"
        "  e_D : relative roughness ε/D [-] (must be >= 0)\n\n"
        "Returns: Darcy friction factor f [-] (dimensionless)\n\n"
        "Valid for turbulent flow (Re > ~2300).\n"
        "For laminar flow, use f = 64/Re.");

  m.def("friction_serghides", &friction_serghides, py::arg("Re"),
        py::arg("e_D"),
        "Serghides friction factor correlation (1984).\n\n"
        "Explicit approximation using Steffensen acceleration.\n"
        "Accuracy: <0.3% vs Colebrook-White (very accurate).\n\n"
        "Parameters:\n"
        "  Re  : Reynolds number [-] (must be > 0)\n"
        "  e_D : relative roughness ε/D [-] (must be >= 0)\n\n"
        "Returns: Darcy friction factor f [-] (dimensionless)\n\n"
        "Valid for turbulent flow (Re > ~2300).");

  m.def("friction_colebrook", &friction_colebrook, py::arg("Re"),
        py::arg("e_D"), py::arg("tol") = 1e-10, py::arg("max_iter") = 20,
        "Colebrook-White friction factor equation (1939).\n\n"
        "Implicit equation solved iteratively using Newton-Raphson.\n"
        "The reference standard for turbulent friction factor.\n\n"
        "1/√f = -2 * log10(ε/D/3.7 + 2.51/(Re*√f))\n\n"
        "Parameters:\n"
        "  Re       : Reynolds number [-] (must be > 0)\n"
        "  e_D      : relative roughness ε/D [-] (must be >= 0)\n"
        "  tol      : convergence tolerance [-] (default: 1e-10)\n"
        "  max_iter : maximum iterations (default: 20)\n\n"
        "Returns: Darcy friction factor f [-] (dimensionless)\n\n"
        "Uses Haaland correlation as initial guess.");

  m.def("friction_petukhov", &friction_petukhov, py::arg("Re"),
        "Petukhov friction factor correlation (1970).\n\n"
        "For smooth channels only (zero roughness).\n"
        "f = [0.790 * ln(Re) - 1.64]^(-2)\n\n"
        "Parameters:\n"
        "  Re : Reynolds number [-] (must be > 0)\n\n"
        "Returns: Darcy friction factor f [-] (dimensionless)\n\n"
        "Valid for: 3000 < Re < 5x10^6\n"
        "Often used with Gnielinski/Petukhov heat transfer correlations.");

  // -------------------------------------------------------------
  // Vatistas n-vortex model
  // Reference: Vatistas, Kozel, Mih (1991), Exp. Fluids 11, 73-76.
  // -------------------------------------------------------------

  m.def("vatistas_v0_bar", &solver::vatistas_v0_bar, py::arg("r_bar"),
        py::arg("n") = vatistas::n_default,
        "Normalised tangential velocity profile V0_bar(r_bar; n).\n\n"
        "V0_bar = r_bar / (1 + r_bar^{2n})^{1/n}  [Eq. 2]\n\n"
        "Peak at r_bar = 1 with value 2^{-1/n} for all n >= 1.\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (must be >= 1, default 2)\n\n"
        "Returns: V0_bar [-] (dimensionless)");

  m.def("vatistas_dv0_bar_drbar", &solver::vatistas_dv0_bar_drbar,
        py::arg("r_bar"), py::arg("n") = vatistas::n_default,
        "Analytical d(V0_bar)/d(r_bar).\n\n"
        "= (1 - r_bar^{2n}) / (1 + r_bar^{2n})^{1 + 1/n}\n\n"
        "Positive for r_bar < 1, zero at r_bar = 1, negative for r_bar > 1.\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (default 2)\n\n"
        "Returns: d(V0_bar)/d(r_bar) [-]");

  m.def("vatistas_vr_bar", &solver::vatistas_vr_bar, py::arg("r_bar"),
        py::arg("n") = vatistas::n_default,
        "Normalised radial velocity Vr_bar = V_r * r_c / nu  [Eq. 3].\n\n"
        "= -2*(1+n)*r_bar^{2n-1} / (1 + r_bar^{2n})\n\n"
        "Negative by definition (inward flow toward vortex axis).\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (default 2)\n\n"
        "Returns: Vr_bar [-] (dimensionless, negative)");

  m.def("vatistas_dvr_bar_drbar", &solver::vatistas_dvr_bar_drbar,
        py::arg("r_bar"), py::arg("n") = vatistas::n_default,
        "Analytical d(Vr_bar)/d(r_bar).\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (default 2)\n\n"
        "Returns: d(Vr_bar)/d(r_bar) [-]");

  m.def("vatistas_pressure_integral", &solver::vatistas_pressure_integral,
        py::arg("r_bar"), py::arg("n") = vatistas::n_default,
        "Raw pressure integral I(r_bar; n) = integral_0^{r_bar} V0_bar^2/r' dr'.\n\n"
        "Closed form for n=1 and n=2; composite Simpson quadrature otherwise.\n"
        "  n = 1: r_bar^2 / (2*(1 + r_bar^2))\n"
        "  n = 2: arctan(r_bar^2) / 2\n\n"
        "Dimensional delta_P = (Gamma/(2*pi*r_c))^2 * rho * I(r/r_c; n)\n\n"
        "For the normalised form (0 to 1 as r_bar -> inf):\n"
        "  n=2: delta_P_bar = I / (pi/4)  =  (2/pi)*arctan(r_bar^2)  [Eq. 11]\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (default 2)\n\n"
        "Returns: I(r_bar; n) [-]");

  m.def("vatistas_d_pressure_integral_drbar",
        &solver::vatistas_d_pressure_integral_drbar, py::arg("r_bar"),
        py::arg("n") = vatistas::n_default,
        "Analytical d(I)/d(r_bar) = V0_bar(r_bar)^2 / r_bar  [FTC, all n].\n\n"
        "Parameters:\n"
        "  r_bar : normalised radius r/r_c [-]\n"
        "  n     : shape parameter [-] (default 2)\n\n"
        "Returns: d(I)/d(r_bar) [-]");

  m.def("vatistas_v_theta",
        py::overload_cast<double, double, double, double>(
            &solver::vatistas_v_theta),
        py::arg("r"), py::arg("Gamma"), py::arg("r_c"),
        py::arg("n") = vatistas::n_default,
        "Tangential velocity V_theta(r; Gamma, r_c, n) [m/s].\n\n"
        "V_theta = [Gamma/(2*pi*r_c)] * V0_bar(r/r_c; n)\n\n"
        "Parameters:\n"
        "  r     : radius [m] (>= 0)\n"
        "  Gamma : vortex circulation [m^2/s] (must be > 0)\n"
        "  r_c   : core radius [m] (must be > 0)\n"
        "  n     : shape parameter [-] (must be >= 1, default 2)\n\n"
        "Returns: V_theta [m/s]");

  m.def("vatistas_v_theta_and_jacobians",
        py::overload_cast<double, double, double, double>(
            &solver::vatistas_v_theta_and_jacobians),
        py::arg("r"), py::arg("Gamma"), py::arg("r_c"),
        py::arg("n") = vatistas::n_default,
        "V_theta and its partial derivatives (all analytical).\n\n"
        "Parameters:\n"
        "  r, Gamma, r_c, n : same as vatistas_v_theta\n\n"
        "Returns: tuple (V_theta [m/s], dV/dr [1/s],\n"
        "                dV/dGamma [(m/s)/(m^2/s)], dV/dr_c [(m/s)/m])");

  m.def("vatistas_delta_p",
        py::overload_cast<double, double, double, double, double>(
            &solver::vatistas_delta_p),
        py::arg("r"), py::arg("rho"), py::arg("Gamma"), py::arg("r_c"),
        py::arg("n") = vatistas::n_default,
        "Static pressure rise P(r) - P(0) [Pa].\n\n"
        "delta_P = (Gamma/(2*pi*r_c))^2 * rho * I(r/r_c; n)\n\n"
        "Parameters:\n"
        "  r     : radius [m]\n"
        "  rho   : fluid density [kg/m^3]\n"
        "  Gamma : vortex circulation [m^2/s] (must be > 0)\n"
        "  r_c   : core radius [m] (must be > 0)\n"
        "  n     : shape parameter [-] (must be >= 1, default 2)\n\n"
        "Returns: delta_P [Pa]");

  m.def("vatistas_delta_p_and_jacobians",
        py::overload_cast<double, double, double, double, double>(
            &solver::vatistas_delta_p_and_jacobians),
        py::arg("r"), py::arg("rho"), py::arg("Gamma"), py::arg("r_c"),
        py::arg("n") = vatistas::n_default,
        "delta_P and its partial derivatives (all analytical).\n\n"
        "Parameters:\n"
        "  r, rho, Gamma, r_c, n : same as vatistas_delta_p\n\n"
        "Returns: tuple (delta_P [Pa], d_delta_P/dr [Pa/m],\n"
        "                d_delta_P/dGamma [Pa/(m^2/s)],\n"
        "                d_delta_P/dr_c [Pa/m])");

  // -------------------------------------------------------------
  // Heat transfer correlations
  // -------------------------------------------------------------

  m.def(
      "nusselt_dittus_boelter",
      [](double Re, double Pr, bool heating) {
        return nusselt_dittus_boelter(Re, Pr, heating, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("heating") = true,
      "Dittus-Boelter Nusselt number correlation (1930).\n\n"
      "Nu = 0.023 * Re^0.8 * Pr^n\n"
      "where n = 0.4 for heating, n = 0.3 for cooling.\n\n"
      "Parameters:\n"
      "  Re      : Reynolds number [-] (validated: Re > 10,000; warns and "
      "extrapolates outside)\n"
      "  Pr      : Prandtl number [-] (validated: 0.6 < Pr < 160; warns and "
      "extrapolates outside)\n"
      "  heating : True if fluid is being heated, False if cooled (default: "
      "True)\n\n"
      "Returns: Nusselt number Nu [-] (dimensionless)\n\n"
      "Valid for fully developed turbulent flow with L/D > 10.\n"
      "Heat transfer coefficient: h = Nu * k / L [W/(m^2*K)]");

  m.def(
      "nusselt_gnielinski",
      [](double Re, double Pr, double f) {
        if (f < 0.0) {
          return nusselt_gnielinski(Re, Pr, nullptr);
        }
        return nusselt_gnielinski(Re, Pr, f, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("f") = -1.0,
      "Gnielinski Nusselt number correlation (1976).\n\n"
      "Nu = (f/8) * (Re - 1000) * Pr / (1 + 12.7 * sqrt(f/8) * (Pr^(2/3) - "
      "1))\n\n"
      "More accurate than Dittus-Boelter, especially in transition region.\n"
      "Below Re=2300 uses a C1-smooth Hermite blend to laminar Nu (3.66).\n\n"
      "Parameters:\n"
      "  Re : Reynolds number [-] (validated: 2300-5e6; warns and extrapolates "
      "outside)\n"
      "  Pr : Prandtl number [-] (validated: 0.5-2000; warns and extrapolates "
      "outside)\n"
      "  f  : Darcy friction factor [-] (if < 0, uses Petukhov "
      "auto-friction)\n\n"
      "Returns: Nusselt number Nu [-] (dimensionless)");

  m.def(
      "nusselt_sieder_tate",
      [](double Re, double Pr, double mu_ratio) {
        return nusselt_sieder_tate(Re, Pr, mu_ratio, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("mu_ratio") = 1.0,
      "Sieder-Tate Nusselt number correlation (1936).\n\n"
      "Nu = 0.027 * Re^0.8 * Pr^(1/3) * (mu_bulk / mu_wall)^0.14\n\n"
      "Accounts for viscosity variation between bulk and wall temperatures.\n\n"
      "Parameters:\n"
      "  Re       : Reynolds number at bulk temperature [-] (validated: Re > "
      "10,000; warns outside)\n"
      "  Pr       : Prandtl number at bulk temperature [-] (validated: "
      "0.7-16700; warns outside)\n"
      "  mu_ratio : mu_bulk / mu_wall [-] (default: 1.0, typically 0.5-2.0)\n\n"
      "Returns: Nusselt number Nu [-] (dimensionless)\n\n"
      "Valid for L/D > 10.");

  m.def("htc_from_nusselt", &htc_from_nusselt, py::arg("Nu"), py::arg("k"),
        py::arg("L"),
        "Heat transfer coefficient from Nusselt number.\n\n"
        "h = Nu * k / L\n\n"
        "Parameters:\n"
        "  Nu : Nusselt number [-] (dimensionless)\n"
        "  k  : thermal conductivity [W/(m·K)]\n"
        "  L  : characteristic length [m] (diameter for circular channel "
        "flow)\n\n"
        "Returns: heat transfer coefficient h [W/(m²·K)]");

  m.def(
      "nusselt_circular_channel",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double diameter, const std::string &correlation,
         bool heating, double mu_ratio, double roughness) {
        auto X = to_vec(X_arr);
        auto [h, Nu, Re] =
            htc_circular_channel(T, P, X, velocity, diameter, correlation,
                                 heating, mu_ratio, roughness);
        return Nu;
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("diameter"), py::arg("correlation") = "gnielinski",
      py::arg("heating") = true, py::arg("mu_ratio") = 1.0,
      py::arg("roughness") = 0.0,
      "Composite Nusselt number for circular channel flow [-].");

  m.def(
      "htc_circular_channel",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double diameter, const std::string &correlation,
         bool heating, double mu_ratio, double roughness) {
        auto X = to_vec(X_arr);
        return htc_circular_channel(T, P, X, velocity, diameter, correlation,
                                    heating, mu_ratio, roughness);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("diameter"), py::arg("correlation") = "gnielinski",
      py::arg("heating") = true, py::arg("mu_ratio") = 1.0,
      py::arg("roughness") = 0.0,
      "Composite heat transfer coefficient for circular channel flow.\n\n"
      "Computes HTC, Nusselt number, and Reynolds number from thermodynamic "
      "state.\n"
      "Automatically calculates density, viscosity, thermal conductivity, and "
      "Prandtl number.\n\n"
      "Parameters:\n"
      "  T           : temperature [K]\n"
      "  P           : pressure [Pa]\n"
      "  X           : mole fractions [mol/mol]\n"
      "  velocity    : flow velocity [m/s]\n"
      "  diameter    : channel diameter [m]\n"
      "  correlation : 'gnielinski' (default), 'dittus_boelter', "
      "'sieder_tate', 'petukhov'\n"
      "  heating     : True for heating, False for cooling (affects "
      "Dittus-Boelter)\n"
      "  mu_ratio    : μ_bulk / μ_wall for Sieder-Tate viscosity correction "
      "(default: 1.0)\n"
      "  roughness   : absolute roughness [m] (default: 0.0 = smooth "
      "channel)\n\n"
      "Returns: tuple (h, Nu, Re)\n"
      "  h  : heat transfer coefficient [W/(m²·K)]\n"
      "  Nu : Nusselt number [-]\n"
      "  Re : Reynolds number [-]\n\n"
      "Correlations:\n"
      "  - gnielinski    : 2300 < Re < 5e6, 0.5 < Pr < 2000 (best "
      "general-purpose)\n"
      "  - dittus_boelter: Re > 10000, 0.6 < Pr < 160 (simple, fast)\n"
      "  - sieder_tate   : Re > 10000, 0.7 < Pr < 16700 (viscosity "
      "correction)\n"
      "  - petukhov      : Re > 10000, 0.5 < Pr < 2000 (high accuracy)\n\n"
      "Automatically handles laminar flow (Re < 2300) with constant Nu.");

  m.def("lmtd", &lmtd, py::arg("dT1"), py::arg("dT2"),
        "Log mean temperature difference (LMTD) for heat exchangers.\n\n"
        "LMTD = (ΔT1 - ΔT2) / ln(ΔT1 / ΔT2)\n\n"
        "For counter-flow:\n"
        "  ΔT1 = T_hot_in - T_cold_out\n"
        "  ΔT2 = T_hot_out - T_cold_in\n\n"
        "For parallel-flow:\n"
        "  ΔT1 = T_hot_in - T_cold_in\n"
        "  ΔT2 = T_hot_out - T_cold_out\n\n"
        "Parameters:\n"
        "  dT1 : temperature difference at one end [K]\n"
        "  dT2 : temperature difference at other end [K]\n\n"
        "Returns: log mean temperature difference [K]\n\n"
        "Note: If dT1 ≈ dT2, returns arithmetic mean to avoid 0/0.");

  // -------------------------------------------------------------
  // Geometry utilities
  // -------------------------------------------------------------

  m.def("hydraulic_diameter", &hydraulic_diameter, py::arg("A"),
        py::arg("P_wetted"),
        "Hydraulic diameter for arbitrary cross-section.\n\n"
        "Dh = 4 * A / P_wetted\n\n"
        "Parameters:\n"
        "  A        : cross-sectional area [m²]\n"
        "  P_wetted : wetted perimeter [m]\n\n"
        "Returns: hydraulic diameter Dh [m]");

  m.def("hydraulic_diameter_rect", &hydraulic_diameter_rect, py::arg("a"),
        py::arg("b"),
        "Hydraulic diameter for rectangular duct.\n\n"
        "Dh = 2*a*b / (a + b)\n\n"
        "Parameters:\n"
        "  a : side length [m]\n"
        "  b : side length [m]\n\n"
        "Returns: hydraulic diameter Dh [m]");

  m.def("hydraulic_diameter_annulus", &hydraulic_diameter_annulus,
        py::arg("D_outer"), py::arg("D_inner"),
        "Hydraulic diameter for annular duct (concentric cylinders).\n\n"
        "Dh = D_outer - D_inner\n\n"
        "Parameters:\n"
        "  D_outer : outer diameter [m]\n"
        "  D_inner : inner diameter [m]\n\n"
        "Returns: hydraulic diameter Dh [m]");

  m.def("residence_time", py::overload_cast<double, double>(&residence_time),
        py::arg("V"), py::arg("Q"),
        "Residence time from volumetric flow rate.\n\n"
        "τ = V / Q̇\n\n"
        "Time for fluid to pass through a volume.\n"
        "Used in reactor design (Damköhler number), combustor sizing.\n\n"
        "Parameters:\n"
        "  V : volume [m³]\n"
        "  Q : volumetric flow rate [m³/s]\n\n"
        "Returns: residence time τ [s]");

  m.def("residence_time_mdot",
        py::overload_cast<double, double, double>(&residence_time_mdot),
        py::arg("V"), py::arg("mdot"), py::arg("rho"),
        "Residence time from mass flow rate.\n\n"
        "τ = V·ρ / ṁ\n\n"
        "Parameters:\n"
        "  V    : volume [m³]\n"
        "  mdot : mass flow rate [kg/s]\n"
        "  rho  : density [kg/m³]\n\n"
        "Returns: residence time τ [s]");

  m.def("channel_mdot", &channel_mdot, py::arg("v"), py::arg("D"),
        py::arg("rho"),
        "Channel mass flow rate from velocity.\n\n"
        "mdot = rho * v * pi * D^2 / 4\n\n"
        "Parameters:\n"
        "  v   : velocity [m/s]\n"
        "  D   : diameter [m]\n"
        "  rho : density [kg/m^3]\n\n"
        "Returns: mass flow rate [kg/s]");

  // Composite channel flow function
  m.def(
      "pressure_drop_channel",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double v, double D, double L, double roughness,
         const std::string &correlation) {
        auto X = to_vec(X_arr);
        return channel_pressure_drop(T, P, X, v, D, L, roughness, correlation);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("v"), py::arg("D"),
      py::arg("L"), py::arg("roughness") = 0.0,
      py::arg("correlation") = "haaland",
      "Composite pressure drop calculation for channel flow.\n\n"
      "Combines thermodynamic properties, Reynolds number, friction factor,\n"
      "and Darcy-Weisbach equation in one call.\n\n"
      "Steps:\n"
      "  1. Calculate density and viscosity from (T, P, X)\n"
      "  2. Calculate Reynolds number: Re = rho * v * D / mu\n"
      "  3. Calculate friction factor using specified correlation\n"
      "  4. Calculate pressure drop: dP = f * (L/D) * (rho * v^2 / 2)\n\n"
      "Parameters:\n"
      "  T           : temperature [K]\n"
      "  P           : pressure [Pa]\n"
      "  X           : mole fractions [mol/mol]\n"
      "  v           : velocity [m/s]\n"
      "  D           : diameter [m]\n"
      "  L           : length [m]\n"
      "  roughness   : absolute roughness [m] (default: 0.0 = smooth)\n"
      "  correlation : friction correlation (default: 'haaland')\n"
      "                Options: 'haaland', 'serghides', 'colebrook', "
      "'petukhov'\n\n"
      "Returns: tuple of (dP [Pa], Re [-], f [-])\n\n"
      "Example:\n"
      "  >>> dP, Re, f = channel_pressure_drop(300, 101325, X_air, 10.0, 0.1, "
      "100.0)\n"
      "  >>> print(f'Pressure drop: {dP:.1f} Pa, Re: {Re:.0f}, f: {f:.4f}')");

  m.def(
      "channel_pressure_drop",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double v, double D, double L, double roughness,
         const std::string &correlation) {
        auto X = to_vec(X_arr);
        return channel_pressure_drop(T, P, X, v, D, L, roughness, correlation);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("v"), py::arg("D"),
      py::arg("L"), py::arg("roughness") = 0.0,
      py::arg("correlation") = "haaland");

  m.def("space_velocity", &space_velocity, py::arg("Q"), py::arg("V"),
        "Space velocity (inverse of residence time).\n\n"
        "SV = Q̇ / V = 1/τ\n\n"
        "Parameters:\n"
        "  Q : volumetric flow rate [m³/s]\n"
        "  V : volume [m³]\n\n"
        "Returns: space velocity SV [1/s]");

  m.def("circular_area", &circular_area, py::arg("D"),
        "Circular cross-sectional area.\n\n"
        "A = π * (D/2)²\n\n"
        "Parameters:\n"
        "  D : diameter [m]\n\n"
        "Returns: area [m²]");

  m.def("annular_area", &annular_area, py::arg("D_outer"), py::arg("D_inner"),
        "Annular cross-sectional area.\n\n"
        "A = π * ((D_outer/2)² - (D_inner/2)²)\n\n"
        "Parameters:\n"
        "  D_outer : outer diameter [m]\n"
        "  D_inner : inner diameter [m]\n\n"
        "Returns: area [m²]");

  m.def("cylinder_volume", &cylinder_volume, py::arg("D"), py::arg("L"),
        "Cylindrical volume.\n\n"
        "V = π * (D/2)² * L\n\n"
        "Parameters:\n"
        "  D : diameter [m]\n"
        "  L : length [m]\n\n"
        "Returns: volume [m³]");

  // -------------------------------------------------------------
  // Compressible flow
  // -------------------------------------------------------------

  // Bind structures
  py::class_<IncompressibleStation>(
      m, "IncompressibleStation",
      "Spatial state data point for incompressible channel flow")
      .def(py::init<>())
      .def_readwrite("x", &IncompressibleStation::x, "Distance from inlet [m]")
      .def_readwrite("P", &IncompressibleStation::P, "Static Pressure [Pa]")
      .def_readwrite("T", &IncompressibleStation::T, "Static Temperature [K]")
      .def_readwrite("rho", &IncompressibleStation::rho, "Density [kg/m³]")
      .def_readwrite("u", &IncompressibleStation::v, "Velocity [m/s]")
      .def_readwrite("M", &IncompressibleStation::M, "Mach Number [-]")
      .def_readwrite("h", &IncompressibleStation::h, "Enthalpy [J/kg]")
      .def("__repr__", [](const IncompressibleStation &s) {
        std::ostringstream oss;
        oss << "<IncompressibleStation x=" << s.x << "m P=" << s.P
            << "Pa T=" << s.T << "K>";
        return oss.str();
      });

  py::class_<IncompressibleFlowSolution>(m, "IncompressibleFlowSolution",
                                         "Result of incompressible flow solver")
      .def(py::init<>())
      .def_readonly("mdot", &IncompressibleFlowSolution::mdot,
                    "Mass flow rate [kg/s]")
      .def_readonly("v", &IncompressibleFlowSolution::v, "Velocity [m/s]")
      .def_readonly("dP", &IncompressibleFlowSolution::dP, "Pressure drop [Pa]")
      .def_readonly("Re", &IncompressibleFlowSolution::Re,
                    "Reynolds number [-]")
      .def_readwrite("rho", &IncompressibleFlowSolution::rho, "Density [kg/m³]")
      .def_readwrite("f", &IncompressibleFlowSolution::f,
                     "Friction factor / Discharge coefficient [-]")
      .def_readwrite("profile", &IncompressibleFlowSolution::profile,
                     "Optional spatial profile along the channel (props(L))")
      .def("__repr__", [](const IncompressibleFlowSolution &s) {
        std::ostringstream oss;
        oss << "IncompressibleFlowSolution(mdot=" << s.mdot << ", v=" << s.v
            << ", dP=" << s.dP << ", Re=" << s.Re << ")";
        return oss.str();
      });

  // CompressibleFlowSolution struct
  py::class_<CompressibleFlowSolution>(m, "CompressibleFlowSolution")
      .def(py::init<>())
      .def_readonly("stagnation", &CompressibleFlowSolution::stagnation,
                    "Stagnation state")
      .def_readonly("outlet", &CompressibleFlowSolution::outlet,
                    "Outlet static state")
      .def_readonly("v", &CompressibleFlowSolution::v, "Outlet velocity [m/s]")
      .def_readonly("M", &CompressibleFlowSolution::M, "Outlet Mach number [-]")
      .def_readonly("mdot", &CompressibleFlowSolution::mdot,
                    "Mass flow rate [kg/s]")
      .def_readonly("choked", &CompressibleFlowSolution::choked,
                    "True if flow is choked");

  // NozzleStation struct
  py::class_<NozzleStation>(m, "NozzleStation")
      .def(py::init<>())
      .def_readonly("x", &NozzleStation::x, "Axial position [m]")
      .def_readonly("A", &NozzleStation::A, "Area [m²]")
      .def_readonly("P", &NozzleStation::P, "Static pressure [Pa]")
      .def_readonly("T", &NozzleStation::T, "Static temperature [K]")
      .def_readonly("rho", &NozzleStation::rho, "Density [kg/m³]")
      .def_readonly("u", &NozzleStation::u, "Velocity [m/s]")
      .def_readonly("M", &NozzleStation::M, "Mach number [-]")
      .def_readonly("h", &NozzleStation::h, "Specific enthalpy [J/kg]");

  // NozzleSolution struct
  py::class_<NozzleSolution>(m, "NozzleSolution")
      .def(py::init<>())
      .def_readonly("inlet", &NozzleSolution::inlet, "Inlet state")
      .def_readonly("outlet", &NozzleSolution::outlet, "Outlet state")
      .def_readonly("mdot", &NozzleSolution::mdot, "Mass flow rate [kg/s]")
      .def_readonly("h0", &NozzleSolution::h0, "Stagnation enthalpy [J/kg]")
      .def_readonly("T0", &NozzleSolution::T0, "Stagnation temperature [K]")
      .def_readonly("P0", &NozzleSolution::P0, "Stagnation pressure [Pa]")
      .def_readonly("choked", &NozzleSolution::choked,
                    "True if throat is sonic")
      .def_readonly("x_throat", &NozzleSolution::x_throat,
                    "Throat position [m]")
      .def_readonly("A_throat", &NozzleSolution::A_throat, "Throat area [m²]")
      .def_readonly("profile", &NozzleSolution::profile, "Axial profile");

  // ThrustResult struct
  py::class_<ThrustResult>(m, "ThrustResult")
      .def(py::init<>())
      .def_readwrite("thrust", &ThrustResult::thrust, "Thrust force [N]")
      .def_readwrite("specific_impulse", &ThrustResult::specific_impulse,
                     "Specific impulse Isp [s]")
      .def_readwrite("thrust_coefficient", &ThrustResult::thrust_coefficient,
                     "Thrust coefficient C_F [-]")
      .def_readwrite("mdot", &ThrustResult::mdot, "Mass flow rate [kg/s]")
      .def_readwrite("u_exit", &ThrustResult::u_exit, "Exit velocity [m/s]")
      .def_readwrite("P_exit", &ThrustResult::P_exit, "Exit pressure [Pa]");

  // FannoStation struct
  py::class_<FannoStation>(m, "FannoStation")
      .def(py::init<>())
      .def_readonly("x", &FannoStation::x, "Position [m]")
      .def_readonly("P", &FannoStation::P, "Static pressure [Pa]")
      .def_readonly("T", &FannoStation::T, "Static temperature [K]")
      .def_readonly("rho", &FannoStation::rho, "Density [kg/m³]")
      .def_readonly("u", &FannoStation::u, "Velocity [m/s]")
      .def_readonly("M", &FannoStation::M, "Mach number [-]")
      .def_readonly("h", &FannoStation::h, "Specific enthalpy [J/kg]")
      .def_readonly("s", &FannoStation::s, "Specific entropy [J/(kg·K)]")
      .def_readonly("f", &FannoStation::f, "Local Darcy friction factor [-]")
      .def_readonly("Re", &FannoStation::Re, "Local Reynolds number [-]");

  // FannoSolution struct
  py::class_<FannoSolution>(m, "FannoSolution")
      .def(py::init<>())
      .def_readonly("inlet", &FannoSolution::inlet, "Inlet state")
      .def_readonly("outlet", &FannoSolution::outlet, "Outlet state")
      .def_readonly("mdot", &FannoSolution::mdot, "Mass flow rate [kg/s]")
      .def_readonly("h0", &FannoSolution::h0, "Stagnation enthalpy [J/kg]")
      .def_readonly("L", &FannoSolution::L, "Channel length [m]")
      .def_readonly("D", &FannoSolution::D, "Channel diameter [m]")
      .def_readonly("f", &FannoSolution::f,
                    "Darcy friction factor (constant-f) [-]")
      .def_readonly("f_avg", &FannoSolution::f_avg,
                    "Average Darcy friction factor [-]")
      .def_readonly("Re_in", &FannoSolution::Re_in, "Inlet Reynolds number [-]")
      .def_readonly("choked", &FannoSolution::choked,
                    "True if flow reached M=1")
      .def_readonly("L_choke", &FannoSolution::L_choke, "Length to choking [m]")
      .def_readonly("profile", &FannoSolution::profile, "Axial profile");

  // Isentropic nozzle flow
  m.def(
      "nozzle_flow",
      [](double T0, double P0, double P_back, double A_eff,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return nozzle_flow(T0, P0, P_back, A_eff, X, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P_back"), py::arg("A_eff"),
      py::arg("X"), py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Isentropic nozzle flow.\n\n"
      "T0     : stagnation temperature [K]\n"
      "P0     : stagnation pressure [Pa]\n"
      "P_back : back pressure [Pa]\n"
      "A_eff  : effective flow area [m²]\n"
      "X      : mole fractions\n\n"
      "Returns CompressibleFlowSolution.");

  // Inverse solvers
  m.def(
      "solve_A_eff_from_mdot",
      [](double T0, double P0, double P_back, double mdot_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return solve_A_eff_from_mdot(T0, P0, P_back, mdot_target, X, tol,
                                     max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P_back"), py::arg("mdot_target"),
      py::arg("X"), py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Find effective area for given mass flow rate.");

  m.def(
      "solve_P_back_from_mdot",
      [](double T0, double P0, double A_eff, double mdot_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return solve_P_back_from_mdot(T0, P0, A_eff, mdot_target, X, tol,
                                      max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("A_eff"), py::arg("mdot_target"),
      py::arg("X"), py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Find back pressure for given mass flow rate.");

  m.def(
      "solve_P0_from_mdot",
      [](double T0, double P_back, double A_eff, double mdot_target,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return solve_P0_from_mdot(T0, P_back, A_eff, mdot_target, X, tol,
                                  max_iter);
      },
      py::arg("T0"), py::arg("P_back"), py::arg("A_eff"),
      py::arg("mdot_target"), py::arg("X"), py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50,
      "Find stagnation pressure for given mass flow rate.");

  // Utility functions
  m.def(
      "critical_pressure_ratio",
      [](double T0, double P0,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return critical_pressure_ratio(T0, P0, X, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("X"), py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50, "Critical (sonic) pressure ratio P*/P0.");

  m.def(
      "mach_from_pressure_ratio",
      [](double T0, double P0, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return mach_from_pressure_ratio(T0, P0, P, X, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P"), py::arg("X"),
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Mach number from pressure ratio P/P0 (isentropic).");

  m.def(
      "mass_flux_isentropic",
      [](double T0, double P0, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return mass_flux_isentropic(T0, P0, P, X, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P"), py::arg("X"),
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Mass flux G = rho*v [kg/(m²·s)] at given pressure (isentropic).");

  // Quasi-1D nozzle with C-D geometry
  m.def(
      "nozzle_cd",
      [](double T0, double P0, double P_exit, double A_inlet, double A_throat,
         double A_exit, double x_throat, double x_exit,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         std::size_t n_stations, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return nozzle_cd(T0, P0, P_exit, A_inlet, A_throat, A_exit, x_throat,
                         x_exit, X, n_stations, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P_exit"), py::arg("A_inlet"),
      py::arg("A_throat"), py::arg("A_exit"), py::arg("x_throat"),
      py::arg("x_exit"), py::arg("X"), py::arg("n_stations") = 100,
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Converging-diverging nozzle flow.\n\n"
      "Uses smooth cosine area profile between inlet, throat, and exit.\n\n"
      "Returns NozzleSolution with axial profile.");

  // Fanno flow
  m.def(
      "fanno_channel",
      [](double T_in, double P_in, double u_in, double L, double D, double f,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         std::size_t n_steps, bool store_profile) {
        auto X = to_vec(X_arr);
        return fanno_channel(T_in, P_in, u_in, L, D, f, X, n_steps,
                             store_profile);
      },
      py::arg("T_in"), py::arg("P_in"), py::arg("u_in"), py::arg("L"),
      py::arg("D"), py::arg("f"), py::arg("X"), py::arg("n_steps") = 100,
      py::arg("store_profile") = false,
      "Fanno flow (adiabatic channel with friction).\n\n"
      "T_in : inlet temperature [K]\n"
      "P_in : inlet pressure [Pa]\n"
      "u_in : inlet velocity [m/s]\n"
      "L    : channel length [m]\n"
      "D    : channel diameter [m]\n"
      "f    : Darcy friction factor [-]\n\n"
      "Returns FannoSolution.");

  m.def(
      "fanno_max_length",
      [](double T_in, double P_in, double u_in, double D, double f,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return fanno_max_length(T_in, P_in, u_in, D, f, X, tol, max_iter);
      },
      py::arg("T_in"), py::arg("P_in"), py::arg("u_in"), py::arg("D"),
      py::arg("f"), py::arg("X"), py::arg("tol") = 1e-6,
      py::arg("max_iter") = 100, "Maximum channel length before choking (L*).");

  // -------------------------------------------------------------
  // Heat transfer correlations
  // -------------------------------------------------------------

  m.def(
      "nusselt_dittus_boelter",
      [](double Re, double Pr, bool heating) {
        return nusselt_dittus_boelter(Re, Pr, heating, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("heating") = true,
      "Dittus-Boelter correlation for turbulent channel flow.\n\n"
      "Nu = 0.023 * Re^0.8 * Pr^n\n"
      "n = 0.4 (heating) or 0.3 (cooling)\n\n"
      "Warns and extrapolates outside validated range (Re > 10000, 0.6 < Pr < "
      "160).");

  m.def(
      "nusselt_gnielinski",
      [](double Re, double Pr, double f) {
        if (f < 0.0) {
          return nusselt_gnielinski(Re, Pr, nullptr);
        }
        return nusselt_gnielinski(Re, Pr, f, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("f") = -1.0,
      "Gnielinski correlation for transitional/turbulent channel flow.\n\n"
      "Below Re=2300 uses C1-smooth Hermite blend to laminar Nu.\n"
      "Warns and extrapolates outside validated range (2300 < Re < 5e6, 0.5 < "
      "Pr < 2000).\n\n"
      "f : friction factor (if < 0, uses Petukhov correlation)");

  m.def(
      "nusselt_sieder_tate",
      [](double Re, double Pr, double mu_ratio) {
        return nusselt_sieder_tate(Re, Pr, mu_ratio, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("mu_ratio") = 1.0,
      "Sieder-Tate correlation with viscosity correction.\n\n"
      "Nu = 0.027 * Re^0.8 * Pr^(1/3) * (mu/mu_w)^0.14\n\n"
      "Warns and extrapolates outside validated range (Re > 10000, 0.7 < Pr < "
      "16700).\n\n"
      "mu_ratio : mu_bulk / mu_wall");

  m.def(
      "nusselt_petukhov",
      [](double Re, double Pr, double f) {
        if (f < 0.0) {
          return nusselt_petukhov(Re, Pr, nullptr);
        }
        return nusselt_petukhov(Re, Pr, f, nullptr);
      },
      py::arg("Re"), py::arg("Pr"), py::arg("f") = -1.0,
      "Petukhov correlation for turbulent channel flow.\n\n"
      "Warns and extrapolates outside validated range (1e4 < Re < 5e6, 0.5 < "
      "Pr < 2000).\n\n"
      "f : friction factor (if < 0, uses Petukhov correlation)");

  m.def("htc_from_nusselt", &htc_from_nusselt, py::arg("Nu"), py::arg("k"),
        py::arg("L"),
        "Heat transfer coefficient from Nusselt number.\n\n"
        "h = Nu * k / L  [W/(m^2*K)]\n\n"
        "Nu : Nusselt number [-]\n"
        "k  : thermal conductivity [W/(m*K)]\n"
        "L  : characteristic length [m]");

  // Warning handler and validity utility
  m.def(
      "set_warning_handler",
      [](py::object handler) {
        if (handler.is_none()) {
          combaero::set_warning_handler({});
        } else {
          combaero::set_warning_handler([handler](const std::string &msg) {
            py::gil_scoped_acquire gil;
            handler(msg);
          });
        }
      },
      py::arg("handler"),
      "Set the global warning handler for out-of-range correlation "
      "extrapolations.\n\n"
      "handler : callable(str) or None\n"
      "  If None, resets to the default (prints to stderr).\n"
      "  Pass a no-op lambda to suppress all warnings.\n\n"
      "Example:\n"
      "  import combaero\n"
      "  combaero.set_warning_handler(lambda msg: None)  # suppress\n"
      "  combaero.set_warning_handler(None)              # restore default");

  m.def(
      "get_warning_handler",
      []() -> py::object {
        // Return the current C++ handler wrapped as a Python callable.
        // Used by suppress_warnings() to save/restore the handler.
        auto h = combaero::get_warning_handler();
        return py::cpp_function([h](const std::string &msg) { h(msg); });
      },
      "Return the current warning handler as a Python callable.\n\n"
      "Used internally by suppress_warnings() to save and restore the "
      "handler.");

  m.def(
      "is_well_behaved",
      [](double v, double lo, double hi) {
        return combaero::is_well_behaved(v, lo, hi);
      },
      py::arg("v"), py::arg("lo") = 1e-12, py::arg("hi") = 1e15,
      "Check whether a correlation result is safe for use in a Jacobian-based "
      "solver.\n\n"
      "Returns True if v is finite, v > lo, and v < hi.\n\n"
      "v  : scalar result to check\n"
      "lo : lower bound (default 1e-12)\n"
      "hi : upper bound (default 1e15)");

  m.def(
      "overall_htc",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> h_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto h_values = to_vec(h_arr);
        auto t_over_k = to_vec(tk_arr);
        return overall_htc(h_values, t_over_k);
      },
      py::arg("h_values"), py::arg("t_over_k") = py::array_t<double>(),
      "Overall HTC from thermal resistance network.\n\n"
      "1/U = Σ(1/h_i) + Σ(t_j/k_j)\n\n"
      "h_values : convective HTCs [W/(m²·K)]\n"
      "t_over_k : thickness/conductivity ratios [m²·K/W]");

  m.def("overall_htc_wall",
        py::overload_cast<double, double, double, double, double>(&overall_htc_wall),
        py::arg("h_inner"), py::arg("h_outer"), py::arg("t_wall"),
        py::arg("k_wall"), py::arg("R_fouling") = 0.0,
        "Overall HTC for single-layer wall.\n\n"
        "1/U = 1/h_inner + t_wall/k_wall + 1/h_outer");

  m.def(
      "overall_htc_wall_multilayer",
      [](double h_inner, double h_outer,
         py::array_t<double, py::array::c_style | py::array::forcecast> tk_arr,
         double R_fouling) {
        auto layers = to_vec(tk_arr);
        if (R_fouling >= 0) {
          return overall_htc_wall(h_inner, h_outer, layers, R_fouling);
        }
        return overall_htc_wall(h_inner, h_outer, layers);
      },
      py::arg("h_inner"), py::arg("h_outer"), py::arg("t_over_k_layers"),
      py::arg("R_fouling") = -1.0,
      "Overall HTC for multi-layer wall.\n\n"
      "1/U = 1/h_inner + Σ(t_i/k_i) + 1/h_outer [+ R_fouling]\n\n"
      "Example: steel + insulation\n"
      "  overall_htc_wall_multilayer(500, 10, [0.003/50, 0.05/0.04])");

  m.def("thermal_resistance", &thermal_resistance, py::arg("h"), py::arg("A"),
        "Thermal resistance for convection.\n\n"
        "R = 1/(h*A) [K/W]");

  m.def("thermal_resistance_wall", &thermal_resistance_wall,
        py::arg("thickness"), py::arg("k"), py::arg("A"),
        "Thermal resistance for conduction through wall.\n\n"
        "R = t/(k*A) [K/W]");

  m.def("lmtd", &lmtd, py::arg("dT1"), py::arg("dT2"),
        "Log Mean Temperature Difference.\n\n"
        "LMTD = (ΔT1 - ΔT2) / ln(ΔT1/ΔT2)\n\n"
        "Handles equal ΔT gracefully (returns arithmetic mean).");

  m.def("lmtd_counterflow", &lmtd_counterflow, py::arg("T_hot_in"),
        py::arg("T_hot_out"), py::arg("T_cold_in"), py::arg("T_cold_out"),
        "LMTD for counter-flow heat exchanger.\n\n"
        "ΔT1 = T_hot_in - T_cold_out\n"
        "ΔT2 = T_hot_out - T_cold_in");

  m.def("lmtd_parallelflow", &lmtd_parallelflow, py::arg("T_hot_in"),
        py::arg("T_hot_out"), py::arg("T_cold_in"), py::arg("T_cold_out"),
        "LMTD for parallel-flow heat exchanger.\n\n"
        "ΔT1 = T_hot_in - T_cold_in\n"
        "ΔT2 = T_hot_out - T_cold_out");

  m.def("heat_rate", &heat_rate, py::arg("U"), py::arg("A"), py::arg("dT"),
        "Heat transfer rate Q = U * A * ΔT [W]");

  m.def("heat_flux", &heat_flux, py::arg("U"), py::arg("dT"),
        "Heat flux q = U * ΔT [W/m²]");

  m.def("heat_transfer_area", &heat_transfer_area, py::arg("Q"), py::arg("U"),
        py::arg("dT"), "Required area A = Q / (U * ΔT) [m²]");

  m.def("heat_transfer_dT", &heat_transfer_dT, py::arg("Q"), py::arg("U"),
        py::arg("A"), "Temperature difference ΔT = Q / (U * A) [K]");

  m.def(
      "wall_temperature_profile",
      [](double T_hot, double T_cold, double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast> tk_arr,
         double R_fouling) {
        auto t_over_k = to_vec(tk_arr);
        double q = 0.0;
        auto temps = wall_temperature_profile(T_hot, T_cold, h_hot, h_cold,
                                              t_over_k, R_fouling, q);
        return py::make_tuple(temps, q);
      },
      py::arg("T_hot"), py::arg("T_cold"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("t_over_k"), py::arg("R_fouling") = 0.0,
      "Temperature profile through multi-layer wall.\n\n"
      "Returns (temps, q) where:\n"
      "  temps : interface temperatures [K]\n"
      "  q     : heat flux [W/m²]");

  m.def("ntu", &ntu, py::arg("U"), py::arg("A"), py::arg("C_min"),
        "Number of Transfer Units: NTU = U * A / C_min");

  m.def("capacity_ratio", &capacity_ratio, py::arg("C_min"), py::arg("C_max"),
        "Heat capacity ratio: C_r = C_min / C_max");

  m.def("effectiveness_counterflow", &effectiveness_counterflow, py::arg("NTU"),
        py::arg("C_r"),
        "Effectiveness for counter-flow heat exchanger.\n\n"
        "ε = (1 - exp(-NTU*(1-C_r))) / (1 - C_r*exp(-NTU*(1-C_r)))");

  m.def("effectiveness_parallelflow", &effectiveness_parallelflow,
        py::arg("NTU"), py::arg("C_r"),
        "Effectiveness for parallel-flow heat exchanger.\n\n"
        "ε = (1 - exp(-NTU*(1+C_r))) / (1 + C_r)");

  m.def("heat_rate_from_effectiveness", &heat_rate_from_effectiveness,
        py::arg("epsilon"), py::arg("C_min"), py::arg("T_hot_in"),
        py::arg("T_cold_in"),
        "Heat rate from effectiveness: Q = ε * C_min * (T_hot_in - T_cold_in) "
        "[W]");

  m.def(
      "heat_flux_from_T_at_edge",
      [](double T_measured, std::size_t edge_idx, double T_hot, double T_cold,
         double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto t_over_k = to_vec(tk_arr);
        return heat_flux_from_T_at_edge(T_measured, edge_idx, T_hot, T_cold,
                                        h_hot, h_cold, t_over_k);
      },
      py::arg("T_measured"), py::arg("edge_idx"), py::arg("T_hot"),
      py::arg("T_cold"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("t_over_k"),
      "Heat flux from temperature measured at wall edge.\n\n"
      "Edge indexing: 0 = hot surface, N = cold surface.\n"
      "Returns heat flux q [W/m²].");

  m.def(
      "heat_flux_from_T_at_depth",
      [](double T_measured, double depth_from_hot, double T_hot, double T_cold,
         double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast> t_arr,
         py::array_t<double, py::array::c_style | py::array::forcecast> k_arr) {
        auto thicknesses = to_vec(t_arr);
        auto conductivities = to_vec(k_arr);
        return heat_flux_from_T_at_depth(T_measured, depth_from_hot, T_hot,
                                         T_cold, h_hot, h_cold, thicknesses,
                                         conductivities);
      },
      py::arg("T_measured"), py::arg("depth_from_hot"), py::arg("T_hot"),
      py::arg("T_cold"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("thicknesses"), py::arg("conductivities"),
      "Heat flux from temperature measured at depth from hot surface.\n\n"
      "Useful when thermocouple is embedded slightly into wall.\n"
      "Returns heat flux q [W/m²].");

  m.def(
      "bulk_T_from_edge_T_and_q",
      [](double T_measured, std::size_t edge_idx, double q, double h_hot,
         double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast> tk_arr,
         const std::string &solve_for) {
        auto t_over_k = to_vec(tk_arr);
        return bulk_T_from_edge_T_and_q(T_measured, edge_idx, q, h_hot, h_cold,
                                        t_over_k, solve_for);
      },
      py::arg("T_measured"), py::arg("edge_idx"), py::arg("q"),
      py::arg("h_hot"), py::arg("h_cold"), py::arg("t_over_k"),
      py::arg("solve_for"),
      "Infer bulk fluid temperature from edge temperature and known heat "
      "flux.\n\n"
      "solve_for: 'hot' or 'cold'\n"
      "Returns inferred bulk temperature [K].");

  m.def(
      "dT_edge_dT_hot",
      [](std::size_t edge_idx, double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto t_over_k = to_vec(tk_arr);
        return dT_edge_dT_hot(edge_idx, h_hot, h_cold, t_over_k);
      },
      py::arg("edge_idx"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("t_over_k"),
      "Sensitivity of edge temperature to hot-side bulk temperature.\n\n"
      "Returns ∂T_edge/∂T_hot [-] (0 to 1).");

  m.def(
      "dT_edge_dT_cold",
      [](std::size_t edge_idx, double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto t_over_k = to_vec(tk_arr);
        return dT_edge_dT_cold(edge_idx, h_hot, h_cold, t_over_k);
      },
      py::arg("edge_idx"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("t_over_k"),
      "Sensitivity of edge temperature to cold-side bulk temperature.\n\n"
      "Returns ∂T_edge/∂T_cold [-] (0 to 1).");

  m.def(
      "dT_edge_dT_bulk",
      [](std::size_t edge_idx, double h_hot, double h_cold,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto t_over_k = to_vec(tk_arr);
        auto [dT_hot, dT_cold] =
            dT_edge_dT_bulk(edge_idx, h_hot, h_cold, t_over_k);
        return py::make_tuple(dT_hot, dT_cold);
      },
      py::arg("edge_idx"), py::arg("h_hot"), py::arg("h_cold"),
      py::arg("t_over_k"),
      "Both sensitivities at once.\n\n"
      "Returns (∂T_edge/∂T_hot, ∂T_edge/∂T_cold).");

  m.def(
      "dT_edge_dq",
      [](std::size_t edge_idx, double h_hot,
         py::array_t<double, py::array::c_style | py::array::forcecast>
             tk_arr) {
        auto t_over_k = to_vec(tk_arr);
        return dT_edge_dq(edge_idx, h_hot, t_over_k);
      },
      py::arg("edge_idx"), py::arg("h_hot"), py::arg("t_over_k"),
      "Sensitivity of edge temperature to heat flux.\n\n"
      "Returns ∂T_edge/∂q [K·m²/W] (negative).");

  // =========================================================================
  // Combustion Method enum + Combustion State
  // =========================================================================

  py::enum_<CombustionMethod>(
      m, "CombustionMethod",
      "Product model for combustion_state / combustion_state_from_streams.\n\n"
      "  Complete    : complete combustion to CO2 + H2O (fast, default)\n"
      "  Equilibrium : complete combustion + reforming + WGS equilibrium\n"
      "                (slower, physically correct for rich or high-T "
      "conditions)")
      .value("Complete", CombustionMethod::Complete)
      .value("Equilibrium", CombustionMethod::Equilibrium)
      .export_values();

  py::class_<CombustionState>(
      m, "CombustionState",
      "Bundle of combustion properties with nested CompleteState objects.\n\n"
      "Contains reactant and product states with all thermodynamic and "
      "transport properties.\n\n"
      "Attributes:\n"
      "  phi                : equivalence ratio [-]\n"
      "  fuel_name          : optional fuel label (string)\n"
      "  method             : CombustionMethod used for products\n"
      "  reactants          : CompleteState at reactant conditions\n"
      "  products           : CompleteState at product conditions (T_ad)\n"
      "  mixture_fraction   : Bilger mixture fraction [-]\n"
      "  fuel_burn_fraction : fraction of fuel burned [0-1]")
      .def_readonly("phi", &CombustionState::phi, "Equivalence ratio [-]")
      .def_readonly("fuel_name", &CombustionState::fuel_name,
                    "Fuel label (e.g., 'CH4', 'Natural Gas')")
      .def_readonly("method", &CombustionState::method,
                    "CombustionMethod used for products")
      .def_readonly("reactants", &CombustionState::reactants,
                    "Reactant CompleteState (all thermo + transport)")
      .def_readonly("products", &CombustionState::products,
                    "Product CompleteState at T_ad (all thermo + transport)")
      .def_readonly("mixture_fraction", &CombustionState::mixture_fraction,
                    "Bilger mixture fraction [-]")
      .def_readonly("fuel_burn_fraction", &CombustionState::fuel_burn_fraction,
                    "Fraction of fuel burned [0-1]")
      .def("__repr__", [](const CombustionState &s) {
        std::string method_str = (s.method == CombustionMethod::Equilibrium)
                                     ? "Equilibrium"
                                     : "Complete";
        return "<CombustionState: phi=" + std::to_string(s.phi) +
               ", method=" + method_str +
               ", T_reactants=" + std::to_string(s.reactants.thermo.T) + " K" +
               ", T_products=" + std::to_string(s.products.thermo.T) + " K" +
               (s.fuel_name.empty() ? "" : ", fuel='" + s.fuel_name + "'") +
               ">";
      });

  using CombustionStateBaseFn = CombustionState (*)(
      const std::vector<double> &, const std::vector<double> &, double, double,
      double, const std::string &, CombustionMethod, bool, bool, double,
      double);
  m.def("combustion_state",
        static_cast<CombustionStateBaseFn>(&combustion_state),
        py::arg("X_fuel"), py::arg("X_ox"), py::arg("phi"),
        py::arg("T_reactants"), py::arg("P"), py::arg("fuel_name") = "",
        py::arg("method") = CombustionMethod::Complete,
        py::arg("smooth_phi0") = false, py::arg("smooth_phi1") = false,
        py::arg("k0") = combaero::SMOOTHING_K_PHI0,
        py::arg("k1") = combaero::SMOOTHING_K_PHI1,
        "Compute combustion state from equivalence ratio.\n\n"
        "Parameters:\n"
        "  X_fuel       : fuel composition (mole fractions) [-]\n"
        "  X_ox         : oxidizer composition (mole fractions) [-]\n"
        "  phi          : equivalence ratio [-]\n"
        "  T_reactants  : reactant temperature [K]\n"
        "  P            : pressure [Pa]\n"
        "  fuel_name    : optional fuel label (default: '')\n"
        "  method       : CombustionMethod.Complete (default) or "
        "CombustionMethod.Equilibrium\n\n"
        "Returns: CombustionState with reactants, products, phi, "
        "mixture_fraction\n\n"
        "Example:\n"
        "  >>> state = cb.combustion_state(X_CH4, X_air, phi=1.0, "
        "T_reactants=300, P=101325)\n"
        "  >>> state_eq = cb.combustion_state(X_CH4, X_air, phi=1.2, "
        "T_reactants=300, P=101325,\n"
        "  ...                               "
        "method=cb.CombustionMethod.Equilibrium)");

  using CombustionStreamsBaseFn =
      CombustionState (*)(const Stream &, const Stream &, const std::string &,
                          CombustionMethod, bool, bool, double, double);
  m.def("combustion_state_from_streams",
        static_cast<CombustionStreamsBaseFn>(&combustion_state_from_streams),
        py::arg("fuel_stream"), py::arg("ox_stream"), py::arg("fuel_name") = "",
        py::arg("method") = CombustionMethod::Complete,
        py::arg("smooth_phi0") = false, py::arg("smooth_phi1") = false,
        py::arg("k0") = combaero::SMOOTHING_K_PHI0,
        py::arg("k1") = combaero::SMOOTHING_K_PHI1,
        "Compute combustion state from measured streams.\n\n"
        "Phi is COMPUTED from mass flow rates (output, not input).\n\n"
        "Parameters:\n"
        "  fuel_stream : fuel stream with mdot, T, X\n"
        "  ox_stream   : oxidizer stream with mdot, T, X\n"
        "  fuel_name   : optional fuel label (default: '')\n"
        "  method      : CombustionMethod.Complete (default) or "
        "CombustionMethod.Equilibrium\n\n"
        "Returns: CombustionState with phi computed from flow rates");

  // PressureLossContext — read-only view passed to user pressure-loss callables
  py::class_<PressureLossContext>(
      m, "PressureLossContext",
      "Context passed to user pressure-loss correlations.\n"
      "All fields are loop-free (no dependence on unknown outlet pressure).\n"
      "Return value of the callable: fractional dP/P_in [-].")
      .def_readonly("phi", &PressureLossContext::phi, "Equivalence ratio [-]")
      .def_readonly("T_ad", &PressureLossContext::T_ad,
                    "Adiabatic flame temperature [K]")
      .def_readonly("theta", &PressureLossContext::theta,
                    "Dimensionless temperature rise T_ad/T_in - 1 [-]")
      .def_readonly("mdot_fuel", &PressureLossContext::mdot_fuel,
                    "Fuel mass flow [kg/s] (0 for phi-based calls)")
      .def_readonly("mdot_air", &PressureLossContext::mdot_air,
                    "Air mass flow [kg/s] (0 for phi-based calls)")
      .def_readonly("mdot_total", &PressureLossContext::mdot_total,
                    "Total inlet mass flow [kg/s]")
      .def_property_readonly(
          "Y_products",
          [](const PressureLossContext &c) { return c.Y_products; },
          "Burned gas mass fractions [-]")
      .def_property_readonly(
          "T_in", [](const PressureLossContext &c) { return c.state_in.T; },
          "Inlet temperature [K]")
      .def_property_readonly(
          "P_in", [](const PressureLossContext &c) { return c.state_in.P; },
          "Inlet pressure [Pa]")
      .def_property_readonly(
          "X_in", [](const PressureLossContext &c) { return c.state_in.X; },
          "Inlet mole fractions [-]")
      .def_property_readonly(
          "X_products",
          [](const PressureLossContext &c) { return c.X_products; },
          "Burned gas mole fractions [-]");

  // combustion_state with pressure-loss hook
  // Use explicit function pointer cast to resolve overload ambiguity.
  using CombustionStateHookFn = CombustionState (*)(
      const std::vector<double> &, const std::vector<double> &, double, double,
      double, const std::string &, CombustionMethod,
      const PressureLossCorrelation &, bool, bool, double, double);
  m.def(
      "combustion_state",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_fuel,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_ox,
         double phi, double T_reactants, double P, const std::string &fuel_name,
         CombustionMethod method, py::function pressure_loss, bool smooth_phi0,
         bool smooth_phi1, double k0, double k1) {
        PressureLossCorrelation fn =
            [pressure_loss](
                const PressureLossContext &ctx) -> std::tuple<double, double> {
          py::object res = pressure_loss(ctx);
          try {
            return res.cast<std::tuple<double, double>>();
          } catch (...) {
            return {res.cast<double>(), 0.0};
          }
        };
        CombustionStateHookFn hook_fn = &combustion_state;
        return hook_fn(to_vec(X_fuel), to_vec(X_ox), phi, T_reactants, P,
                       fuel_name, method, fn, smooth_phi0, smooth_phi1, k0, k1);
      },
      py::arg("X_fuel"), py::arg("X_ox"), py::arg("phi"),
      py::arg("T_reactants"), py::arg("P"), py::arg("fuel_name") = "",
      py::arg("method") = CombustionMethod::Complete, py::arg("pressure_loss"),
      py::arg("smooth_phi0") = false, py::arg("smooth_phi1") = false,
      py::arg("k0") = combaero::SMOOTHING_K_PHI0,
      py::arg("k1") = combaero::SMOOTHING_K_PHI1,
      "combustion_state with user-supplied pressure-loss callable.\n\n"
      "pressure_loss(ctx: PressureLossContext) -> float\n"
      "  Returns fractional dP/P_in [-]. All ctx fields are loop-free.\n\n"
      "Example:\n"
      "  result = cb.combustion_state(X_fuel, X_ox, phi=0.8, T_reactants=700,\n"
      "      P=500000, pressure_loss=lambda c: 0.03 + 0.005*c.theta)");

  // combustion_state_from_streams with pressure-loss hook
  using CombustionStreamsHookFn = CombustionState (*)(
      const Stream &, const Stream &, const std::string &, CombustionMethod,
      const PressureLossCorrelation &, bool, bool, double, double);
  m.def(
      "combustion_state_from_streams",
      [](const Stream &fuel_stream, const Stream &ox_stream,
         const std::string &fuel_name, CombustionMethod method,
         py::function pressure_loss, bool smooth_phi0, bool smooth_phi1,
         double k0, double k1) {
        PressureLossCorrelation fn =
            [pressure_loss](
                const PressureLossContext &ctx) -> std::tuple<double, double> {
          py::object res = pressure_loss(ctx);
          try {
            return res.cast<std::tuple<double, double>>();
          } catch (...) {
            return {res.cast<double>(), 0.0};
          }
        };
        CombustionStreamsHookFn hook_fn = &combustion_state_from_streams;
        return hook_fn(fuel_stream, ox_stream, fuel_name, method, fn,
                       smooth_phi0, smooth_phi1, k0, k1);
      },
      py::arg("fuel_stream"), py::arg("ox_stream"), py::arg("fuel_name") = "",
      py::arg("method") = CombustionMethod::Complete, py::arg("pressure_loss"),
      py::arg("smooth_phi0") = false, py::arg("smooth_phi1") = false,
      py::arg("k0") = combaero::SMOOTHING_K_PHI0,
      py::arg("k1") = combaero::SMOOTHING_K_PHI1,
      "combustion_state_from_streams with user-supplied pressure-loss "
      "callable.\n\n"
      "pressure_loss(ctx: PressureLossContext) -> float\n"
      "  Returns fractional dP/P_in [-].\n"
      "  ctx.mdot_fuel and ctx.mdot_air are populated from stream mass flows.");

  m.def("linear_pressure_loss", [](double k, double c) {
    return py::cpp_function(
        [k, c](const PressureLossContext &ctx) -> std::tuple<double, double> {
          return {k * ctx.theta + c, k};
        });
  });

  // =========================================================================
  // Acoustics & Geometry
  // =========================================================================

  py::module geom = m.def_submodule(
      "geometry", "Geometric primitives representing flow areas and volumes.");

  // Tube struct
  py::class_<Tube>(geom, "Tube",
                   "Cylindrical tube geometry for acoustic analysis")
      .def(py::init<double, double>(), py::arg("L"), py::arg("D"),
           "Create tube with length L [m] and diameter D [m]")
      .def_readwrite("L", &Tube::L, "Length [m]")
      .def_readwrite("D", &Tube::D, "Diameter [m]")
      .def("area", &Tube::area, "Cross-sectional area [m²]")
      .def("volume", &Tube::volume, "Volume [m³]")
      .def("perimeter", &Tube::perimeter, "Circumference [m]");

  // CdCorrelation enum (early binding for default arguments)
  py::enum_<CdCorrelation>(m, "CdCorrelation",
                           "Orifice discharge coefficient correlations")
      .value("ReaderHarrisGallagher", CdCorrelation::ReaderHarrisGallagher,
             "ISO 5167-2 / ASME MFC-3M")
      .value("Stolz", CdCorrelation::Stolz, "ISO 5167:1980 (older)")
      .value("Miller", CdCorrelation::Miller, "Miller (1996) simplified");

  // Annulus struct
  py::class_<Annulus>(geom, "Annulus",
                      "Annular duct geometry for acoustic analysis")
      .def(py::init<>())
      .def(py::init<double, double, double>(), py::arg("L"), py::arg("D_inner"),
           py::arg("D_outer"),
           "Create annulus with length L [m], inner diameter D_inner [m], "
           "outer diameter D_outer [m]")
      .def_readwrite("L", &Annulus::L, "Length [m]")
      .def_readwrite("D_inner", &Annulus::D_inner, "Inner diameter [m]")
      .def_readwrite("D_outer", &Annulus::D_outer, "Outer diameter [m]")
      .def_readwrite("n_azimuthal_max", &Annulus::n_azimuthal_max,
                     "Maximum azimuthal mode number to search")
      .def("D_mean", &Annulus::D_mean, "Mean diameter [m]")
      .def("gap", &Annulus::gap, "Annular gap [m]")
      .def("area", &Annulus::area, "Cross-sectional area [m²]")
      .def("volume", &Annulus::volume, "Volume [m³]")
      .def("circumference", &Annulus::circumference, "Mean circumference [m]")
      // Backward-compat properties for AnnularDuctGeometry API (settable radius
      // accessors)
      .def_property(
          "length", [](const Annulus &g) { return g.L; },
          [](Annulus &g, double v) { g.L = v; },
          "Axial length [m] (alias for L)")
      .def_property(
          "radius_inner", [](const Annulus &g) { return g.radius_inner(); },
          [](Annulus &g, double v) { g.D_inner = v * 2.0; }, "Inner radius [m]")
      .def_property(
          "radius_outer", [](const Annulus &g) { return g.radius_outer(); },
          [](Annulus &g, double v) { g.D_outer = v * 2.0; },
          "Outer radius [m]");

  py::class_<CanAnnularFlowGeometry>(
      geom, "CanAnnularFlowGeometry",
      "Parameterized can-annular flow geometry with primary, transition, and "
      "annular sections")
      .def(py::init<double, double, double, double, double, double>(),
           py::arg("L"), py::arg("D_inner"), py::arg("D_outer"),
           py::arg("L_primary"), py::arg("D_primary"), py::arg("L_transition"),
           "Create geometry with annular section and dedicated can transition "
           "parameters.")
      .def_readwrite("L", &CanAnnularFlowGeometry::L,
                     "Annular section length [m]")
      .def_readwrite("D_inner", &CanAnnularFlowGeometry::D_inner,
                     "Annular inner diameter [m]")
      .def_readwrite("D_outer", &CanAnnularFlowGeometry::D_outer,
                     "Annular outer diameter [m]")
      .def_readwrite("L_primary", &CanAnnularFlowGeometry::L_primary,
                     "Primary zone length [m]")
      .def_readwrite("D_primary", &CanAnnularFlowGeometry::D_primary,
                     "Primary zone diameter [m]")
      .def_readwrite("L_transition", &CanAnnularFlowGeometry::L_transition,
                     "Transition length [m]")
      .def("D_mean", &CanAnnularFlowGeometry::D_mean,
           "Annular mean diameter [m]")
      .def("gap", &CanAnnularFlowGeometry::gap, "Annular gap [m]")
      .def("area", &CanAnnularFlowGeometry::area,
           "Annular cross-sectional area [m²]")
      .def("volume", &CanAnnularFlowGeometry::volume,
           "Annular section volume [m³]")
      .def("circumference", &CanAnnularFlowGeometry::circumference,
           "Annular mean circumference [m]")
      .def("area_primary", &CanAnnularFlowGeometry::area_primary,
           "Primary circular area [m²]")
      .def("volume_primary", &CanAnnularFlowGeometry::volume_primary,
           "Primary zone volume [m³]")
      .def("volume_transition", &CanAnnularFlowGeometry::volume_transition,
           "Transition volume [m³]")
      .def("volume_total", &CanAnnularFlowGeometry::volume_total,
           "Total geometry volume [m³]")
      .def("length_total", &CanAnnularFlowGeometry::length_total,
           "Total geometry length [m]");

  // BoundaryCondition enum
  py::enum_<BoundaryCondition>(m, "BoundaryCondition",
                               "Acoustic boundary condition")
      .value("Open", BoundaryCondition::Open, "Pressure release (p'=0)")
      .value("Closed", BoundaryCondition::Closed, "Rigid wall (u'=0)");

  // AcousticMode struct
  py::class_<AcousticMode>(m, "AcousticMode",
                           "Acoustic mode with frequency and indices")
      .def_readonly("n_axial", &AcousticMode::n_axial,
                    "Longitudinal mode number")
      .def_readonly("n_azimuthal", &AcousticMode::n_azimuthal,
                    "Azimuthal mode number")
      .def_readonly("frequency", &AcousticMode::frequency,
                    "Natural frequency [Hz]")
      .def("label", &AcousticMode::label,
           "Mode label (e.g., '1L', '2T', '1L1T')")
      .def("__repr__", [](const AcousticMode &m) {
        return "<AcousticMode " + m.label() + " @ " +
               std::to_string(m.frequency) + " Hz>";
      });

  // Tube modes
  m.def("tube_axial_modes", &tube_axial_modes, py::arg("tube"), py::arg("c"),
        py::arg("upstream"), py::arg("downstream"), py::arg("n_max") = 5,
        "Compute axial acoustic modes of a tube.\n\n"
        "tube      : Tube geometry\n"
        "c         : Speed of sound [m/s]\n"
        "upstream  : Boundary condition at x=0\n"
        "downstream: Boundary condition at x=L\n"
        "n_max     : Maximum mode number (default: 5)\n\n"
        "Returns list of AcousticMode sorted by frequency.");

  // Annulus modes
  m.def("annulus_axial_modes", &annulus_axial_modes, py::arg("annulus"),
        py::arg("c"), py::arg("upstream"), py::arg("downstream"),
        py::arg("n_max") = 5, "Compute axial acoustic modes of an annulus.");

  m.def("annulus_azimuthal_modes", &annulus_azimuthal_modes, py::arg("annulus"),
        py::arg("c"), py::arg("m_max") = 4,
        "Compute azimuthal (tangential) acoustic modes of an annulus.\n\n"
        "f_m = m * c / (π * D_mean)");

  m.def("annulus_modes", &annulus_modes, py::arg("annulus"), py::arg("c"),
        py::arg("upstream"), py::arg("downstream"), py::arg("n_max") = 5,
        py::arg("m_max") = 4,
        "Compute all acoustic modes (axial, azimuthal, combined) of an "
        "annulus.\n\n"
        "Returns list of AcousticMode sorted by frequency.");

  // Utility functions
  m.def("modes_in_range", &modes_in_range, py::arg("modes"), py::arg("f_min"),
        py::arg("f_max"),
        "Filter modes within a frequency range [f_min, f_max] Hz.");

  m.def(
      "closest_mode",
      [](const std::vector<AcousticMode> &modes,
         double f_target) -> py::object {
        const auto *m = closest_mode(modes, f_target);
        if (m)
          return py::cast(*m);
        return py::none();
      },
      py::arg("modes"), py::arg("f_target"),
      "Find the mode closest to a target frequency.\n\n"
      "Returns AcousticMode or None if modes is empty.");

  m.def("min_mode_separation", &min_mode_separation, py::arg("modes"),
        "Minimum frequency separation between adjacent modes [Hz].");

  // Mean flow correction
  m.def("axial_mode_upstream", &axial_mode_upstream, py::arg("f0"),
        py::arg("M"),
        "Upstream-propagating wave frequency with mean flow.\n\n"
        "f+ = f0 / (1 - M)\n\n"
        "f0 : quiescent frequency [Hz]\n"
        "M  : Mach number [-]");

  m.def("axial_mode_downstream", &axial_mode_downstream, py::arg("f0"),
        py::arg("M"),
        "Downstream-propagating wave frequency with mean flow.\n\n"
        "f- = f0 / (1 + M)");

  m.def("axial_mode_split", &axial_mode_split, py::arg("f0"), py::arg("M"),
        "Frequency split due to mean flow.\n\n"
        "Returns (f_upstream, f_downstream).");

  // Helmholtz resonator
  m.def("helmholtz_frequency", &helmholtz_frequency, py::arg("V"),
        py::arg("A_neck"), py::arg("L_neck"), py::arg("c"),
        py::arg("end_correction") = 0.85,
        "Helmholtz resonator frequency.\n\n"
        "f = (c / 2π) * √(A / (V * L_eff))\n\n"
        "V              : cavity volume [m³]\n"
        "A_neck         : neck area [m²]\n"
        "L_neck         : neck length [m]\n"
        "c              : speed of sound [m/s]\n"
        "end_correction : end correction factor (default: 0.85 flanged)");

  // Strouhal
  m.def("strouhal", &strouhal, py::arg("f"), py::arg("L"), py::arg("u"),
        "Strouhal number: St = f * L / u");

  m.def("frequency_from_strouhal", &frequency_from_strouhal, py::arg("St"),
        py::arg("L"), py::arg("u"),
        "Frequency from Strouhal number: f = St * u / L");

  // Convenience
  m.def("quarter_wave_frequency", &quarter_wave_frequency, py::arg("L"),
        py::arg("c"), "Quarter-wave resonator fundamental: f = c / (4L)");

  m.def("half_wave_frequency", &half_wave_frequency, py::arg("L"), py::arg("c"),
        "Half-wave resonator fundamental: f = c / (2L)");

  // Viscothermal boundary layers
  m.def("stokes_layer", &stokes_layer, py::arg("nu"), py::arg("f"),
        "Stokes (viscous) boundary layer thickness: δ_ν = √(2ν/ω)\n\n"
        "nu : kinematic viscosity [m²/s]\n"
        "f  : frequency [Hz]");

  m.def("thermal_layer", &thermal_layer, py::arg("alpha"), py::arg("f"),
        "Thermal penetration depth: δ_κ = √(2α/ω)\n\n"
        "alpha : thermal diffusivity [m²/s]\n"
        "f     : frequency [Hz]");

  m.def("effective_viscothermal_layer", &effective_viscothermal_layer,
        py::arg("delta_nu"), py::arg("delta_kappa"), py::arg("gamma"),
        "Effective viscothermal layer: δ_eff = δ_ν + (γ-1)·δ_κ");

  // Quality factor screening
  m.def("helmholtz_Q", &helmholtz_Q, py::arg("V"), py::arg("A_neck"),
        py::arg("L_neck"), py::arg("nu"), py::arg("alpha"), py::arg("gamma"),
        py::arg("f"),
        "Helmholtz resonator Q factor (viscothermal losses).\n\n"
        "Screening estimate - expect ±50% accuracy.\n"
        "Real designs require experimental validation.");

  m.def("tube_Q", &tube_Q, py::arg("L"), py::arg("D"), py::arg("nu"),
        py::arg("alpha"), py::arg("gamma"), py::arg("f"),
        "Quarter/half-wave tube Q factor (viscothermal losses).\n\n"
        "Screening estimate - expect ±50% accuracy.");

  m.def("damping_ratio", &damping_ratio, py::arg("Q"),
        "Damping ratio from quality factor: ζ = 1/(2Q)");

  m.def("bandwidth", &bandwidth, py::arg("f0"), py::arg("Q"),
        "Half-power bandwidth: Δf = f₀/Q [Hz]");

  // AcousticProperties struct binding - Bundle of acoustic properties
  py::class_<AcousticProperties>(
      m, "AcousticProperties",
      "Bundle of acoustic properties computed from (f, rho, c, p_rms).\n\n"
      "All properties are read-only attributes computed in a single call.\n"
      "Provides IDE autocomplete and type safety.\n\n"
      "Attributes:\n"
      "  wavelength        : Acoustic wavelength [m]\n"
      "  frequency         : Frequency [Hz]\n"
      "  impedance         : Characteristic acoustic impedance [Pa·s/m]\n"
      "  particle_velocity : Particle velocity amplitude [m/s]\n"
      "  spl               : Sound pressure level [dB]")
      .def_readonly("wavelength", &AcousticProperties::wavelength,
                    "Acoustic wavelength [m]")
      .def_readonly("frequency", &AcousticProperties::frequency,
                    "Frequency [Hz]")
      .def_readonly("impedance", &AcousticProperties::impedance,
                    "Characteristic acoustic impedance [Pa·s/m]")
      .def_readonly("particle_velocity", &AcousticProperties::particle_velocity,
                    "Particle velocity amplitude [m/s]")
      .def_readonly("spl", &AcousticProperties::spl,
                    "Sound pressure level [dB]")
      .def("__repr__", [](const AcousticProperties &p) {
        return "<AcousticProperties: f=" + std::to_string(p.frequency) +
               " Hz, "
               "λ=" +
               std::to_string(p.wavelength) +
               " m, "
               "SPL=" +
               std::to_string(p.spl) + " dB>";
      });

  m.def(
      "acoustic_properties", &acoustic_properties, py::arg("f"), py::arg("rho"),
      py::arg("c"), py::arg("p_rms") = 20e-6, py::arg("p_ref") = 20e-6,
      "Compute all acoustic properties at once.\n\n"
      "Convenience function that computes all acoustic properties in a\n"
      "single call. Returns AcousticProperties struct with read-only "
      "attributes\n"
      "for IDE autocomplete support.\n\n"
      "Parameters:\n"
      "  f     : frequency [Hz]\n"
      "  rho   : density [kg/m³]\n"
      "  c     : speed of sound [m/s]\n"
      "  p_rms : RMS pressure amplitude [Pa] (default: 20e-6 Pa = 0 dB "
      "reference)\n"
      "  p_ref : reference pressure for SPL [Pa] (default: 20e-6 Pa in air)\n\n"
      "Returns: AcousticProperties object with attributes:\n"
      "  wavelength, frequency, impedance, particle_velocity, spl\n\n"
      "Example:\n"
      "  >>> props = cb.acoustic_properties(f=1000, rho=1.2, c=340, "
      "p_rms=1.0)\n"
      "  >>> print(f'Wavelength: {props.wavelength:.3f} m')\n"
      "  >>> print(f'Impedance: {props.impedance:.1f} Pa·s/m')\n"
      "  >>> print(f'SPL: {props.spl:.1f} dB')");

  // =========================================================================
  // Transfer Matrix Method - Advanced Thermoacoustics
  // =========================================================================

  py::class_<TransferMatrix>(m, "TransferMatrix")
      .def(py::init<>())
      .def_readwrite("T11", &TransferMatrix::T11)
      .def_readwrite("T12", &TransferMatrix::T12)
      .def_readwrite("T21", &TransferMatrix::T21)
      .def_readwrite("T22", &TransferMatrix::T22)
      .def("__mul__", &TransferMatrix::operator*);

  py::class_<AcousticMedium>(m, "AcousticMedium")
      .def(py::init<>())
      .def_readwrite("rho", &AcousticMedium::rho)
      .def_readwrite("c", &AcousticMedium::c);

  py::class_<LinerOrificeGeometry>(m, "LinerOrificeGeometry")
      .def(py::init<>())
      .def_readwrite("d_orifice", &LinerOrificeGeometry::d_orifice)
      .def_readwrite("l_orifice", &LinerOrificeGeometry::l_orifice)
      .def_readwrite("porosity", &LinerOrificeGeometry::porosity)
      .def_readwrite("Cd", &LinerOrificeGeometry::Cd);

  py::class_<LinerFlowState>(m, "LinerFlowState")
      .def(py::init<>())
      .def_readwrite("u_bias", &LinerFlowState::u_bias)
      .def_readwrite("u_grazing", &LinerFlowState::u_grazing);

  py::class_<LinerCavity>(m, "LinerCavity")
      .def(py::init<>())
      .def_readwrite("depth", &LinerCavity::depth);

  m.def("absorption_from_impedance_norm", &absorption_from_impedance_norm,
        py::arg("z_norm"));

  m.def("liner_sdof_impedance_norm", &liner_sdof_impedance_norm,
        py::arg("freq"), py::arg("orifice"), py::arg("cavity"), py::arg("flow"),
        py::arg("medium"));

  m.def("liner_sdof_absorption", &liner_sdof_absorption, py::arg("freq"),
        py::arg("orifice"), py::arg("cavity"), py::arg("flow"),
        py::arg("medium"));

  m.def("sweep_liner_sdof_absorption", &sweep_liner_sdof_absorption,
        py::arg("freqs"), py::arg("orifice"), py::arg("cavity"),
        py::arg("flow"), py::arg("medium"));

  m.def("liner_2dof_serial_impedance_norm", &liner_2dof_serial_impedance_norm,
        py::arg("freq"), py::arg("face_orifice"), py::arg("septum_orifice"),
        py::arg("depth_1"), py::arg("depth_2"), py::arg("face_flow"),
        py::arg("septum_flow"), py::arg("medium"));

  m.def("liner_2dof_serial_absorption", &liner_2dof_serial_absorption,
        py::arg("freq"), py::arg("face_orifice"), py::arg("septum_orifice"),
        py::arg("depth_1"), py::arg("depth_2"), py::arg("face_flow"),
        py::arg("septum_flow"), py::arg("medium"));

  m.def("sweep_liner_2dof_serial_absorption",
        &sweep_liner_2dof_serial_absorption, py::arg("freqs"),
        py::arg("face_orifice"), py::arg("septum_orifice"), py::arg("depth_1"),
        py::arg("depth_2"), py::arg("face_flow"), py::arg("septum_flow"),
        py::arg("medium"));

  m.def("orifice_impedance_with_flow", &orifice_impedance_with_flow,
        py::arg("freq"), py::arg("u_bias"), py::arg("u_grazing"),
        py::arg("d_orifice"), py::arg("l_orifice"), py::arg("porosity"),
        py::arg("Cd"), py::arg("rho"), py::arg("c"));

  m.def("quarter_wave_resonator_tmm", &quarter_wave_resonator_tmm,
        py::arg("freq"), py::arg("L_tube"), py::arg("A_duct"),
        py::arg("A_tube"), py::arg("d_orifice"), py::arg("l_orifice"),
        py::arg("porosity"), py::arg("Cd"), py::arg("u_bias"),
        py::arg("u_grazing"), py::arg("rho"), py::arg("c"));

  m.def("is_whistling_risk", &is_whistling_risk, py::arg("freq"),
        py::arg("u_bias"), py::arg("d_orifice"));

  // =========================================================================
  // Can-Annular Combustor Acoustics (Bloch-Floquet Theory)
  // =========================================================================

  py::class_<CanAnnularGeometry>(m, "CanAnnularGeometry")
      .def(py::init<>())
      .def_readwrite("n_cans", &CanAnnularGeometry::n_cans)
      .def_readwrite("length_can", &CanAnnularGeometry::length_can)
      .def_readwrite("area_can", &CanAnnularGeometry::area_can)
      .def_readwrite("radius_plenum", &CanAnnularGeometry::radius_plenum)
      .def_readwrite("area_plenum", &CanAnnularGeometry::area_plenum)
      .def("__repr__", [](const CanAnnularGeometry &g) {
        return "CanAnnularGeometry(n_cans=" + std::to_string(g.n_cans) +
               ", length_can=" + std::to_string(g.length_can) +
               ", area_can=" + std::to_string(g.area_can) +
               ", radius_plenum=" + std::to_string(g.radius_plenum) +
               ", area_plenum=" + std::to_string(g.area_plenum) + ")";
      });

  py::class_<BlochMode>(m, "BlochMode")
      .def(py::init<>())
      .def_readwrite("m_azimuthal", &BlochMode::m_azimuthal)
      .def_readwrite("frequency", &BlochMode::frequency)
      .def_readwrite("n_cans", &BlochMode::n_cans)
      .def("symmetry_type", &BlochMode::symmetry_type)
      .def("__repr__", [](const BlochMode &m) {
        return "BlochMode(m=" + std::to_string(m.m_azimuthal) +
               ", f=" + std::to_string(m.frequency) + " Hz, " +
               m.symmetry_type() + ")";
      });

  m.def(
      "can_annular_eigenmodes", &can_annular_eigenmodes, py::arg("geom"),
      py::arg("c_can"), py::arg("c_plenum"), py::arg("rho_can"),
      py::arg("rho_plenum"), py::arg("f_max") = 2000.0,
      py::arg("bc_can_top") = BoundaryCondition::Closed,
      "Find all can-annular combustor eigenmodes using Bloch-Floquet "
      "theory.\n\n"
      "Solves the dispersion relation D(omega) = Y_can + Y_annulus = 0\n"
      "for a system of N cans coupled by an annular plenum.\n\n"
      "Uses magnitude minimization + Muller refinement (fast, reliable).\n"
      "For research-grade Argument Principle, use "
      "can_annular_eigenmodes_with_method.\n\n"
      "Parameters:\n"
      "  geom       : CanAnnularGeometry with N cans, lengths, areas\n"
      "  c_can      : speed of sound in can [m/s]\n"
      "  c_plenum   : speed of sound in plenum [m/s] (often different!)\n"
      "  rho_can    : density in can [kg/m^3]\n"
      "  rho_plenum : density in plenum [kg/m^3]\n"
      "  f_max      : maximum frequency to search [Hz] (default: 2000)\n"
      "  bc_can_top : boundary condition at can top (default: Closed)\n\n"
      "Returns: List of BlochMode sorted by frequency\n\n"
      "Method: Continuous sliding window scan + magnitude minimization\n"
      "Accuracy: Finds modes wherever they occur (no harmonic assumptions)\n\n"
      "References:\n"
      "  - Noiray et al. (2011): Unified framework for combustion instability\n"
      "  - Evesque & Polifke (2005): Low-order acoustic modelling\n\n"
      "Example:\n"
      "  >>> geom = cb.CanAnnularGeometry()\n"
      "  >>> geom.n_cans = 24\n"
      "  >>> geom.length_can = 0.5  # m\n"
      "  >>> geom.area_can = 0.01   # m^2\n"
      "  >>> geom.radius_plenum = 0.5  # m\n"
      "  >>> geom.area_plenum = 0.02   # m^2\n"
      "  >>> modes = cb.can_annular_eigenmodes(geom, c_can=500, c_plenum=600,\n"
      "  ...                                    rho_can=1.0, rho_plenum=1.2)\n"
      "  >>> for mode in modes[:5]:\n"
      "  ...     print(f'm={mode.m_azimuthal}, f={mode.frequency:.1f} Hz')");

  // Adapter function to convert CanAnnularFlowGeometry to CanAnnularGeometry
  m.def(
      "to_acoustic_geometry", &to_acoustic_geometry, py::arg("flow_geom"),
      py::arg("n_cans"), py::arg("L_can"), py::arg("D_can"),
      "Convert CanAnnularFlowGeometry to CanAnnularGeometry for acoustic "
      "solvers.\n\n"
      "This adapter bridges flow geometry (with primary/transition/annular "
      "sections)\n"
      "to acoustic geometry (cans + annular plenum).\n\n"
      "Parameters:\n"
      "  flow_geom : CanAnnularFlowGeometry from geometry.h\n"
      "  n_cans    : Number of cans (required for acoustic model)\n"
      "  L_can     : Can length [m] (acoustic model uses single section)\n"
      "  D_can     : Can diameter [m] (for circular cross-section)\n\n"
      "Returns: CanAnnularGeometry for can_annular_eigenmodes()\n\n"
      "Notes:\n"
      "  - Plenum radius derived from flow_geom.D_mean() / 2\n"
      "  - Plenum area from flow_geom.area()\n"
      "  - Can area computed as π*(D_can/2)²\n\n"
      "Example:\n"
      "  >>> flow_geom = cb.CanAnnularFlowGeometry(L=0.3, D_inner=0.4, "
      "D_outer=0.6,\n"
      "  ...                                        L_primary=0.2, "
      "D_primary=0.1,\n"
      "  ...                                        L_transition=0.05)\n"
      "  >>> geom = cb.to_acoustic_geometry(flow_geom, n_cans=24, L_can=0.5, "
      "D_can=0.1)\n"
      "  >>> modes = cb.can_annular_eigenmodes(geom, c_can=500, c_plenum=550,\n"
      "  ...                                    rho_can=1.2, rho_plenum=1.0)");

  // Annular Duct Geometry and Modes
  // AnnularDuctGeometry is a Python-level alias for Annulus (backward
  // compatibility)
  m.attr("AnnularDuctGeometry") = geom.attr("Annulus");

  py::class_<AnnularMode>(m, "AnnularMode")
      .def(py::init<>())
      .def_readwrite("m_azimuthal", &AnnularMode::m_azimuthal)
      .def_readwrite("n_axial", &AnnularMode::n_axial)
      .def_readwrite("frequency", &AnnularMode::frequency)
      .def("mode_type", &AnnularMode::mode_type)
      .def("__repr__", [](const AnnularMode &mode) {
        return "AnnularMode(m=" + std::to_string(mode.m_azimuthal) +
               ", n=" + std::to_string(mode.n_axial) +
               ", f=" + std::to_string(mode.frequency) + " Hz, " +
               mode.mode_type() + ")";
      });

  m.def("annular_duct_eigenmodes", &annular_duct_eigenmodes, py::arg("geom"),
        py::arg("c"), py::arg("rho"), py::arg("f_max"),
        py::arg("bc_ends") = BoundaryCondition::Closed,
        "Find all annular duct eigenmodes using Argument Principle.\n\n"
        "Pure annular waveguide (no cans) with Bloch-Floquet periodic BCs.\n"
        "Uses Nyquist contour integration for robust root finding.\n\n"
        "Parameters:\n"
        "  geom    : Annulus geometry (from geometry.h)\n"
        "  c       : speed of sound [m/s]\n"
        "  rho     : density [kg/m^3]\n"
        "  f_max   : maximum frequency [Hz]\n"
        "  bc_ends : boundary condition at duct ends (default: Closed)\n\n"
        "Returns: List of AnnularMode sorted by frequency\n\n"
        "Method: Argument Principle (gold standard for finding ALL roots)\n"
        "Guarantees: No missed modes, handles complex frequencies\n\n"
        "Example:\n"
        "  >>> geom = cb.Annulus(L=1.0, D_inner=0.4, D_outer=1.0)\n"
        "  >>> geom.n_azimuthal_max = 5\n"
        "  >>> modes = cb.annular_duct_eigenmodes(geom, c=500, rho=1.2, "
        "f_max=1000)\n"
        "  >>> for mode in modes[:5]:\n"
        "  ...     print(f'm={mode.m_azimuthal}, n={mode.n_axial}, "
        "f={mode.frequency:.1f} Hz')");

  m.def("annular_duct_modes_analytical", &annular_duct_modes_analytical,
        py::arg("geom"), py::arg("c"), py::arg("f_max"),
        py::arg("bc_ends") = BoundaryCondition::Closed);

  // Utility functions
  m.def("wavelength", &wavelength, py::arg("f"), py::arg("c"),
        "Acoustic wavelength from frequency.\n\n"
        "λ = c / f\n\n"
        "Parameters:\n"
        "  f : frequency [Hz]\n"
        "  c : speed of sound [m/s]\n\n"
        "Returns: wavelength [m]");

  m.def("frequency_from_wavelength", &frequency_from_wavelength,
        py::arg("lambda"), py::arg("c"),
        "Frequency from wavelength.\n\n"
        "f = c / λ\n\n"
        "Parameters:\n"
        "  lambda : wavelength [m]\n"
        "  c      : speed of sound [m/s]\n\n"
        "Returns: frequency [Hz]");

  m.def("acoustic_impedance", &acoustic_impedance, py::arg("rho"), py::arg("c"),
        "Characteristic acoustic impedance.\n\n"
        "Z = ρ · c\n\n"
        "Parameters:\n"
        "  rho : density [kg/m³]\n"
        "  c   : speed of sound [m/s]\n\n"
        "Returns: impedance [Pa·s/m]");

  m.def("sound_pressure_level", &sound_pressure_level, py::arg("p_rms"),
        py::arg("p_ref") = 20e-6,
        "Sound pressure level in dB.\n\n"
        "SPL = 20 · log₁₀(p_rms / p_ref)\n\n"
        "Parameters:\n"
        "  p_rms : RMS pressure amplitude [Pa]\n"
        "  p_ref : reference pressure [Pa] (default: 20e-6 Pa in air)\n\n"
        "Returns: SPL [dB]");

  m.def("particle_velocity", &particle_velocity, py::arg("p"), py::arg("rho"),
        py::arg("c"),
        "Particle velocity from pressure amplitude.\n\n"
        "u = p / (ρ · c)\n\n"
        "Parameters:\n"
        "  p   : pressure amplitude [Pa]\n"
        "  rho : density [kg/m³]\n"
        "  c   : speed of sound [m/s]\n\n"
        "Returns: particle velocity [m/s]");

  // Residence time
  m.def("residence_time", py::overload_cast<double, double>(&residence_time),
        py::arg("V"), py::arg("Q"),
        "Residence time τ = V / Q̇ [s].\n\n"
        "V : volume [m³]\n"
        "Q : volumetric flow rate [m³/s]");

  m.def("residence_time_tube",
        py::overload_cast<const Tube &, double>(&residence_time),
        py::arg("tube"), py::arg("Q"), "Residence time for a tube [s].");

  m.def("residence_time_annulus",
        py::overload_cast<const Annulus &, double>(&residence_time),
        py::arg("annulus"), py::arg("Q"), "Residence time for an annulus [s].");

  m.def("residence_time_can_annular",
        py::overload_cast<const CanAnnularFlowGeometry &, double>(
            &residence_time),
        py::arg("geom"), py::arg("Q"),
        "Residence time for CanAnnularFlowGeometry based on total volume [s].");

  m.def("residence_time_mdot",
        py::overload_cast<double, double, double>(&residence_time_mdot),
        py::arg("V"), py::arg("mdot"), py::arg("rho"),
        "Residence time from mass flow: τ = V·ρ / ṁ [s].\n\n"
        "V    : volume [m³]\n"
        "mdot : mass flow rate [kg/s]\n"
        "rho  : density [kg/m³]");

  m.def("residence_time_mdot_can_annular",
        py::overload_cast<const CanAnnularFlowGeometry &, double, double>(
            &residence_time_mdot),
        py::arg("geom"), py::arg("mdot"), py::arg("rho"),
        "Residence time for CanAnnularFlowGeometry from mass flow [s].");

  m.def("space_velocity", &space_velocity, py::arg("Q"), py::arg("V"),
        "Space velocity SV = Q̇ / V = 1/τ [1/s].");

  // Nozzle thrust (from NozzleSolution)
  m.def("nozzle_thrust",
        py::overload_cast<const NozzleSolution &, double>(&nozzle_thrust),
        py::arg("sol"), py::arg("P_amb"),
        "Calculate rocket nozzle thrust from nozzle solution.\n\n"
        "F = mdot * u_e + (P_e - P_amb) * A_e\n\n"
        "sol   : NozzleSolution from nozzle_cd()\n"
        "P_amb : Ambient pressure [Pa]\n\n"
        "Returns ThrustResult with thrust, Isp, and C_F.");

  // Nozzle thrust (convenience, from parameters)
  m.def(
      "nozzle_thrust_cd",
      [](double T0, double P0, double P_design, double P_amb, double A_inlet,
         double A_throat, double A_exit, double x_throat, double x_exit,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         std::size_t n_stations, double tol, std::size_t max_iter) {
        auto X = to_vec(X_arr);
        return nozzle_thrust(T0, P0, P_design, P_amb, A_inlet, A_throat, A_exit,
                             x_throat, x_exit, X, n_stations, tol, max_iter);
      },
      py::arg("T0"), py::arg("P0"), py::arg("P_design"), py::arg("P_amb"),
      py::arg("A_inlet"), py::arg("A_throat"), py::arg("A_exit"),
      py::arg("x_throat"), py::arg("x_exit"), py::arg("X"),
      py::arg("n_stations") = 100, py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50,
      "Calculate rocket nozzle thrust directly from geometry.\n\n"
      "P_design: nozzle exit design pressure for Mach profile (must be > 0).\n"
      "P_amb: ambient pressure for thrust equation (may be 0 for vacuum).\n"
      "Convenience function that calls nozzle_cd() then nozzle_thrust().\n\n"
      "Returns ThrustResult with thrust, Isp, and C_F.");

  // =========================================================================
  // Incompressible flow
  // =========================================================================

  // Bernoulli equation
  m.def("bernoulli_P2", &bernoulli_P2, py::arg("P1"), py::arg("v1"),
        py::arg("v2"), py::arg("rho"), py::arg("dz") = 0.0,
        py::arg("g") = 9.80665,
        "Bernoulli equation: solve for downstream pressure P2.\n\n"
        "P1 + ½ρv1² + ρgh1 = P2 + ½ρv2² + ρgh2\n\n"
        "P1  : upstream pressure [Pa]\n"
        "v1  : upstream velocity [m/s]\n"
        "v2  : downstream velocity [m/s]\n"
        "rho : fluid density [kg/m³]\n"
        "dz  : elevation change z2-z1 [m] (positive=up)\n"
        "g   : gravitational acceleration [m/s²]");

  m.def("bernoulli_v2", &bernoulli_v2, py::arg("P1"), py::arg("P2"),
        py::arg("v1"), py::arg("rho"), py::arg("dz") = 0.0,
        py::arg("g") = 9.80665,
        "Bernoulli equation: solve for downstream velocity v2.\n\n"
        "P1  : upstream pressure [Pa]\n"
        "P2  : downstream pressure [Pa]\n"
        "v1  : upstream velocity [m/s]\n"
        "rho : fluid density [kg/m³]\n"
        "dz  : elevation change z2-z1 [m]\n"
        "g   : gravitational acceleration [m/s²]");

  // Orifice flow
  m.def("orifice_mdot",
        static_cast<double (*)(double, double, double, double, double)>(
            &orifice_mdot),
        py::arg("P1"), py::arg("P2"), py::arg("A"), py::arg("Cd"),
        py::arg("rho"),
        "Orifice mass flow rate (incompressible).\n\n"
        "ṁ = Cd · A · √(2 · ρ · ΔP)\n\n"
        "P1  : upstream pressure [Pa]\n"
        "P2  : downstream pressure [Pa]\n"
        "A   : orifice area [m²]\n"
        "Cd  : discharge coefficient [-] (typically 0.6-0.65)\n"
        "rho : fluid density [kg/m³]\n\n"
        "Returns: mass flow rate [kg/s]");

  m.def("orifice_Q", &orifice_Q, py::arg("P1"), py::arg("P2"), py::arg("A"),
        py::arg("Cd"), py::arg("rho"),
        "Orifice volumetric flow rate.\n\n"
        "Q = Cd · A · √(2 · ΔP / ρ)\n\n"
        "Returns: volumetric flow rate [m³/s]");

  m.def("orifice_velocity", &orifice_velocity, py::arg("P1"), py::arg("P2"),
        py::arg("rho"),
        "Ideal orifice velocity (no losses).\n\n"
        "v = √(2 · ΔP / ρ)\n\n"
        "Returns: velocity [m/s]");

  m.def("orifice_area", &orifice_area, py::arg("mdot"), py::arg("P1"),
        py::arg("P2"), py::arg("Cd"), py::arg("rho"),
        "Solve for required orifice area given mass flow.\n\n"
        "A = ṁ / (Cd · √(2 · ρ · ΔP))\n\n"
        "Returns: orifice area [m²]");

  m.def("orifice_dP",
        static_cast<double (*)(double, double, double, double)>(&orifice_dP),
        py::arg("mdot"), py::arg("A"), py::arg("Cd"), py::arg("rho"),
        "Solve for pressure drop given mass flow and area.\n\n"
        "ΔP = (ṁ / (Cd · A))² / (2 · ρ)\n\n"
        "Returns: pressure drop P1-P2 [Pa]");

  // Channel flow
  m.def("channel_dP", &channel_dP, py::arg("v"), py::arg("L"), py::arg("D"),
        py::arg("f"), py::arg("rho"),
        "Channel pressure drop (Darcy-Weisbach).\n\n"
        "ΔP = f · (L/D) · (ρ · v² / 2)\n\n"
        "v   : flow velocity [m/s]\n"
        "L   : channel length [m]\n"
        "D   : channel diameter [m]\n"
        "f   : Darcy friction factor [-]\n"
        "rho : fluid density [kg/m³]\n\n"
        "Returns: pressure drop [Pa]");

  m.def("channel_dP", &channel_dP, py::arg("v"), py::arg("L"), py::arg("D"),
        py::arg("f"), py::arg("rho"), "Channel pressure drop [Pa].");

  m.def("channel_dP_mdot", &channel_dP_mdot, py::arg("mdot"), py::arg("L"),
        py::arg("D"), py::arg("f"), py::arg("rho"),
        "Channel pressure drop from mass flow rate.\n\n"
        "Returns: pressure drop [Pa]");

  m.def("channel_velocity", &channel_velocity, py::arg("mdot"), py::arg("D"),
        py::arg("rho"),
        "Channel velocity from mass flow rate.\n\n"
        "v = ṁ / (ρ · π · D² / 4)\n\n"
        "Returns: velocity [m/s]");

  m.def("channel_mdot", &channel_mdot, py::arg("v"), py::arg("D"),
        py::arg("rho"),
        "Channel mass flow from velocity.\n\n"
        "ṁ = ρ · v · π · D² / 4\n\n"
        "Returns: mass flow rate [kg/s]");

  // Hydraulic utilities
  m.def("dynamic_pressure", &dynamic_pressure, py::arg("v"), py::arg("rho"),
        "Dynamic pressure (velocity head).\n\n"
        "q = ½ · ρ · v²\n\n"
        "Returns: dynamic pressure [Pa]");

  m.def("velocity_from_q", &velocity_from_q, py::arg("q"), py::arg("rho"),
        "Velocity from dynamic pressure.\n\n"
        "v = √(2 · q / ρ)\n\n"
        "Returns: velocity [m/s]");

  m.def("hydraulic_diameter", &hydraulic_diameter, py::arg("A"),
        py::arg("P_wetted"),
        "Hydraulic diameter for non-circular cross-sections.\n\n"
        "Dh = 4 · A / P_wetted\n\n"
        "A        : cross-sectional area [m²]\n"
        "P_wetted : wetted perimeter [m]\n\n"
        "Returns: hydraulic diameter [m]");

  m.def("hydraulic_diameter_rect", &hydraulic_diameter_rect, py::arg("a"),
        py::arg("b"),
        "Hydraulic diameter for rectangular duct.\n\n"
        "Dh = 2·a·b / (a + b)\n\n"
        "Returns: hydraulic diameter [m]");

  m.def("hydraulic_diameter_annulus", &hydraulic_diameter_annulus,
        py::arg("D_outer"), py::arg("D_inner"),
        "Hydraulic diameter for annulus.\n\n"
        "Dh = D_outer - D_inner\n\n"
        "Returns: hydraulic diameter [m]");

  // =========================================================================
  // Orifice Cd Correlations
  // =========================================================================

  // OrificeGeometry struct
  py::class_<OrificeGeometry>(m, "OrificeGeometry",
                              "Orifice geometry for Cd correlations.\n\n"
                              "Attributes:\n"
                              "  d : orifice bore diameter [m]\n"
                              "  D : channel diameter [m]\n"
                              "  t : plate thickness [m] (for thick plate)\n"
                              "  r : inlet edge radius [m] (for rounded entry)")
      .def(py::init<>())
      .def_readwrite("d", &OrificeGeometry::d, "Orifice bore diameter [m]")
      .def_readwrite("D", &OrificeGeometry::D, "Channel diameter [m]")
      .def_readwrite("t", &OrificeGeometry::t, "Plate thickness [m]")
      .def_readwrite("r", &OrificeGeometry::r, "Inlet edge radius [m]")
      .def_readwrite("bevel", &OrificeGeometry::bevel, "Bevel angle [rad]")
      .def_property_readonly("beta", &OrificeGeometry::beta,
                             "Diameter ratio d/D [-]")
      .def_property_readonly("area", &OrificeGeometry::area,
                             "Orifice area [m²]")
      .def_property_readonly("t_over_d", &OrificeGeometry::t_over_d,
                             "Thickness ratio t/d [-]")
      .def_property_readonly("r_over_d", &OrificeGeometry::r_over_d,
                             "Radius ratio r/d [-]")
      .def("is_valid", &OrificeGeometry::is_valid,
           "Check if geometry is valid");

  // OrificeState struct
  py::class_<OrificeState>(m, "OrificeState",
                           "Flow state at orifice for Cd correlations.\n\n"
                           "Attributes:\n"
                           "  Re_D : channel Reynolds number (based on D) [-]\n"
                           "  dP   : differential pressure [Pa]\n"
                           "  rho  : fluid density [kg/m³]\n"
                           "  mu   : dynamic viscosity [Pa·s]")
      .def(py::init<>())
      .def_readwrite("Re_D", &OrificeState::Re_D, "Channel Reynolds number [-]")
      .def_readwrite("dP", &OrificeState::dP, "Differential pressure [Pa]")
      .def_readwrite("rho", &OrificeState::rho, "Fluid density [kg/m³]")
      .def_readwrite("mu", &OrificeState::mu, "Dynamic viscosity [Pa·s]")
      .def("Re_d", &OrificeState::Re_d, py::arg("beta"),
           "Orifice Reynolds number (based on d)");

  // Cd correlation functions
  m.def("Cd_sharp_thin_plate", &Cd_sharp_thin_plate, py::arg("geom"),
        py::arg("state"),
        "Discharge coefficient for sharp thin-plate orifice (ISO 5167-2).\n\n"
        "Uses Reader-Harris/Gallagher correlation.\n"
        "Valid for: 0.1 <= beta <= 0.75, Re_D >= 5000, D >= 50mm");

  m.def("Cd_thick_plate", &Cd_thick_plate, py::arg("geom"), py::arg("state"),
        "Discharge coefficient for thick-plate orifice.\n\n"
        "Applies Idelchik thickness correction to thin-plate Cd.\n"
        "Valid for: 0 < t/d < ~3");

  m.def("Cd_rounded_entry", &Cd_rounded_entry, py::arg("geom"),
        py::arg("state"),
        "Discharge coefficient for rounded-entry orifice.\n\n"
        "Based on Idelchik contraction loss coefficients.\n"
        "Valid for: 0 < r/d <= 0.2 (typical)");

  m.def("Cd_orifice", &Cd, py::arg("geom"), py::arg("state"),
        "Discharge coefficient with auto-selected correlation.\n\n"
        "Selects correlation based on geometry:\n"
        "  - r/d > 0.01: rounded entry\n"
        "  - t/d > 0.02: thick plate\n"
        "  - otherwise: sharp thin plate");

  m.def("solve_orifice_mdot", &solve_orifice_mdot, py::arg("geom"),
        py::arg("dP"), py::arg("rho"), py::arg("mu"),
        py::arg("P_upstream") = 101325.0, py::arg("kappa") = 0.0,
        py::arg("correlation") = CdCorrelation::ReaderHarrisGallagher,
        py::arg("tol") = 1e-6, py::arg("max_iter") = 20,
        "Iterative solver for orifice mass flow with Cd-Re coupling.\n\n"
        "Solves the coupled system:\n"
        "  mdot = ε · Cd(Re_D) · A · √(2 · ρ · ΔP)\n"
        "  Re_D = 4 · mdot / (π · D · μ)\n\n"
        "Iterates until mdot converges (typically 3-5 iterations).\n\n"
        "Parameters:\n"
        "  geom        : OrificeGeometry\n"
        "  dP          : differential pressure [Pa]\n"
        "  rho         : upstream density [kg/m³]\n"
        "  mu          : dynamic viscosity [Pa·s]\n"
        "  P_upstream  : absolute upstream pressure [Pa] (default: 101325)\n"
        "  kappa       : isentropic exponent cp/cv (0 = incompressible)\n"
        "  correlation : Cd correlation (default: ReaderHarrisGallagher)\n"
        "  tol         : relative convergence tolerance (default: 1e-6)\n"
        "  max_iter    : maximum iterations (default: 20)\n\n"
        "Returns: converged mass flow rate [kg/s]\n\n"
        "Raises: RuntimeError if fails to converge\n\n"
        "Example:\n"
        "  >>> geom = OrificeGeometry(d=0.05, D=0.1)\n"
        "  >>> mdot = solve_orifice_mdot(geom, 10000, 1.2, 1.8e-5)\n"
        "  >>> print(f'Mass flow: {mdot:.4f} kg/s')");

  // Orifice flow calculations with Cd
  m.def("orifice_mdot_Cd",
        static_cast<double (*)(const OrificeGeometry &, double, double, double,
                               double)>(&orifice_mdot),
        py::arg("geom"), py::arg("Cd"), py::arg("dP"), py::arg("rho"),
        py::arg("epsilon") = 1.0,
        "Mass flow through orifice given Cd.\n\n"
        "mdot = Cd * E * epsilon * A * sqrt(2 * rho * dP)\n\n"
        "Returns: mass flow rate [kg/s]");

  m.def("orifice_dP_Cd",
        static_cast<double (*)(const OrificeGeometry &, double, double, double,
                               double)>(&orifice_dP),
        py::arg("geom"), py::arg("Cd"), py::arg("mdot"), py::arg("rho"),
        py::arg("epsilon") = 1.0,
        "Pressure drop for given mass flow and Cd.\n\n"
        "dP = (mdot / (Cd * E * epsilon * A))² / (2 * rho)\n\n"
        "Returns: pressure drop [Pa]");

  m.def("orifice_Cd_from_measurement", &orifice_Cd_from_measurement,
        py::arg("geom"), py::arg("mdot"), py::arg("dP"), py::arg("rho"),
        "Solve for discharge coefficient from measurement.\n\n"
        "Cd = mdot / (E * A * sqrt(2 * rho * dP))\n\n"
        "Parameters:\n"
        "  geom : OrificeGeometry\n"
        "  mdot : mass flow rate [kg/s]\n"
        "  dP   : pressure drop [Pa]\n"
        "  rho  : density [kg/m^3]\n\n"
        "Returns: discharge coefficient Cd [-]");

  m.def("expansibility_factor", &expansibility_factor, py::arg("beta"),
        py::arg("dP"), py::arg("P_upstream"), py::arg("kappa"),
        "Expansibility factor for compressible gas flow through orifices.\n\n"
        "Accounts for gas expansion as it accelerates through the orifice.\n"
        "Formula from ISO 5167-2:2003, Section 5.3.2.2.\n\n"
        "ε = 1 - (0.351 + 0.256·β⁴ + 0.93·β⁸) · [1 - (1 - τ)^(1/κ)]\n\n"
        "where τ = ΔP/P_upstream, β = d/D, κ = cp/cv\n\n"
        "Usage: mdot = ε · Cd · A · √(2 · ρ_upstream · ΔP)\n\n"
        "Parameters:\n"
        "  beta        : diameter ratio d/D [-]\n"
        "  dP          : differential pressure [Pa]\n"
        "  P_upstream  : absolute upstream pressure [Pa]\n"
        "  kappa       : isentropic exponent cp/cv [-]\n\n"
        "Returns: expansibility factor ε [-] (0 < ε ≤ 1)\n\n"
        "Valid for: 0.1 ≤ β ≤ 0.75, τ ≤ 0.25, ideal gas");

  // Namespace functions
  m.def("orifice_K_from_Cd", &orifice::K_from_Cd, py::arg("Cd"),
        py::arg("beta"),
        "Loss coefficient K from discharge coefficient Cd.\n\n"
        "K = (1/Cd² - 1) * (1 - beta⁴)");

  m.def("orifice_Cd_from_K", &orifice::Cd_from_K, py::arg("K"), py::arg("beta"),
        "Discharge coefficient Cd from loss coefficient K.\n\n"
        "Cd = 1 / sqrt(1 + K / (1 - beta⁴))");

  m.def("orifice_thickness_correction", &orifice::thickness_correction,
        py::arg("t_over_d"), py::arg("beta"), py::arg("Re_d"),
        "Thickness correction factor for thick-plate orifices.\n\n"
        "Idelchik model: Cd rises (reattachment) then falls (friction).\n\n"
        "Multiplies thin-plate Cd to account for flow reattachment.\n"
        "Returns 1.0 for t/d <= 0.02 (thin plate).");

  // OrificeFlowResult struct binding - Bundle of orifice flow properties
  py::class_<OrificeFlowResult>(
      m, "OrificeFlowResult",
      "Bundle of orifice flow properties computed from (geom, dP, T, P, mu, "
      "Z).\n\n"
      "All properties are read-only attributes computed in a single call.\n"
      "Provides IDE autocomplete and type safety.\n\n"
      "Attributes:\n"
      "  mdot          : Mass flow rate [kg/s]\n"
      "  v             : Velocity through orifice throat [m/s]\n"
      "  Re_D          : Channel Reynolds number (based on D) [-]\n"
      "  Re_d          : Orifice Reynolds number (based on d) [-]\n"
      "  Cd            : Discharge coefficient [-]\n"
      "  epsilon       : Expansibility factor [-] (1.0 for incompressible)\n"
      "  rho_corrected : Density corrected for compressibility [kg/m³]")
      .def_readonly("mdot", &OrificeFlowResult::mdot, "Mass flow rate [kg/s]")
      .def_readonly("v", &OrificeFlowResult::v,
                    "Velocity through orifice throat [m/s]")
      .def_readonly("Re_D", &OrificeFlowResult::Re_D,
                    "Channel Reynolds number (based on D) [-]")
      .def_readonly("Re_d", &OrificeFlowResult::Re_d,
                    "Orifice Reynolds number (based on d) [-]")
      .def_readonly("Cd", &OrificeFlowResult::Cd, "Discharge coefficient [-]")
      .def_readonly("epsilon", &OrificeFlowResult::epsilon,
                    "Expansibility factor [-]")
      .def_readonly("rho_corrected", &OrificeFlowResult::rho_corrected,
                    "Density corrected for compressibility [kg/m³]")
      .def("__repr__", [](const OrificeFlowResult &r) {
        return "<OrificeFlowResult: mdot=" + std::to_string(r.mdot) +
               " kg/s, "
               "v=" +
               std::to_string(r.v) +
               " m/s, "
               "Cd=" +
               std::to_string(r.Cd) +
               ", "
               "Re_d=" +
               std::to_string(r.Re_d) + ">";
      });

  m.def(
      "orifice_flow", &orifice_flow, py::arg("geom"), py::arg("dP"),
      py::arg("T"), py::arg("P"), py::arg("mu"), py::arg("Z") = 1.0,
      py::arg("X") = std::vector<double>(), py::arg("kappa") = 0.0,
      py::arg("correlation") = CdCorrelation::ReaderHarrisGallagher,
      "Compute all orifice flow properties at once with real gas "
      "correction.\n\n"
      "Convenience function that computes all orifice flow properties in a\n"
      "single call. Returns OrificeFlowResult struct with read-only "
      "attributes\n"
      "for IDE autocomplete support.\n\n"
      "Parameters:\n"
      "  geom        : OrificeGeometry\n"
      "  dP          : differential pressure [Pa]\n"
      "  T           : temperature [K]\n"
      "  P           : absolute upstream pressure [Pa]\n"
      "  mu          : dynamic viscosity [Pa·s]\n"
      "  Z           : compressibility factor [-] (default: 1.0 = ideal gas)\n"
      "  X           : mole fractions [-] (optional, uses air if empty)\n"
      "  kappa       : isentropic exponent cp/cv [-] (default: 0.0 = "
      "incompressible)\n"
      "  correlation : Cd correlation (default: ReaderHarrisGallagher)\n\n"
      "Returns: OrificeFlowResult object with attributes:\n"
      "  mdot, v, Re_D, Re_d, Cd, epsilon, rho_corrected\n\n"
      "Real Gas Support:\n"
      "  The compressibility factor Z corrects density for non-ideal "
      "behavior:\n"
      "    rho_corrected = rho_ideal / Z\n"
      "  For ideal gas: Z = 1.0 (default)\n"
      "  For real gas: Z typically ranges 0.7-1.0 depending on P, T, "
      "composition\n"
      "  Users can obtain Z from REFPROP, Peng-Robinson, or other EOS "
      "libraries\n\n"
      "Example:\n"
      "  >>> geom = cb.OrificeGeometry()\n"
      "  >>> geom.d = 0.05  # 50 mm orifice\n"
      "  >>> geom.D = 0.1   # 100 mm channel\n"
      "  >>> result = cb.orifice_flow(geom, dP=50000, T=300, P=10e6, "
      "mu=1.1e-5, Z=0.85)\n"
      "  >>> print(f'Mass flow: {result.mdot:.3f} kg/s')\n"
      "  >>> print(f'Velocity: {result.v:.2f} m/s')\n"
      "  >>> print(f'Cd: {result.Cd:.3f}')");

  // Convenience wrapper: computes mu from thermodynamic state
  m.def(
      "orifice_flow_state",
      [](const OrificeGeometry &geom, double dP, double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double Z, double kappa, CdCorrelation correlation) {
        auto X = to_vec(X_arr);
        double mu = viscosity(T, P, X);
        return orifice_flow(geom, dP, T, P, mu, Z, X, kappa, correlation);
      },
      py::arg("geom"), py::arg("dP"), py::arg("T"), py::arg("P"), py::arg("X"),
      py::arg("Z") = 1.0, py::arg("kappa") = 0.0,
      py::arg("correlation") = CdCorrelation::ReaderHarrisGallagher,
      "Compute all orifice flow properties from thermodynamic state.\n\n"
      "Convenience wrapper around orifice_flow() that computes dynamic "
      "viscosity\n"
      "internally from (T, P, X) using the built-in transport correlations.\n\n"
      "Parameters:\n"
      "  geom        : OrificeGeometry\n"
      "  dP          : differential pressure [Pa]\n"
      "  T           : temperature [K]\n"
      "  P           : absolute upstream pressure [Pa]\n"
      "  X           : mole fractions [-]\n"
      "  Z           : compressibility factor [-] (default: 1.0 = ideal gas)\n"
      "  kappa       : isentropic exponent cp/cv [-] (default: 0.0 = "
      "incompressible)\n"
      "  correlation : Cd correlation (default: ReaderHarrisGallagher)\n\n"
      "Returns: OrificeFlowResult with mdot, v, Re_D, Re_d, Cd, epsilon, "
      "rho_corrected\n\n"
      "Example:\n"
      "  >>> geom = cb.OrificeGeometry()\n"
      "  >>> geom.d = 0.05\n"
      "  >>> geom.D = 0.1\n"
      "  >>> X_air = cb.species.dry_air()\n"
      "  >>> result = cb.orifice_flow_state(geom, dP=10000, T=300, P=101325, "
      "X=X_air)\n"
      "  >>> print(f'Mass flow: {result.mdot:.4f} kg/s')");

  // Utility functions
  m.def("orifice_velocity_from_mdot", &orifice_velocity_from_mdot,
        py::arg("mdot"), py::arg("rho"), py::arg("d"), py::arg("Z") = 1.0,
        "Velocity through orifice from mass flow rate with real gas "
        "correction.\n\n"
        "v = mdot / (rho_corrected * A)\n"
        "where rho_corrected = rho / Z, A = π·d²/4\n\n"
        "Parameters:\n"
        "  mdot : mass flow rate [kg/s]\n"
        "  rho  : density [kg/m³]\n"
        "  d    : orifice diameter [m]\n"
        "  Z    : compressibility factor [-] (default: 1.0 = ideal gas)\n\n"
        "Returns: velocity [m/s]");

  // Aliases for backward compatibility in roughness DB
  m.def("channel_roughness", &channel_roughness, py::arg("material"),
        "Lookup absolute roughness [m] from material name.");

  m.def("orifice_area_from_beta", &orifice_area_from_beta, py::arg("D"),
        py::arg("beta"),
        "Orifice area from beta ratio.\n\n"
        "A = π·(D·beta/2)²\n\n"
        "Parameters:\n"
        "  D    : channel diameter [m]\n"
        "  beta : diameter ratio d/D [-]\n\n"
        "Returns: orifice area [m²]");

  m.def("beta_from_diameters", &beta_from_diameters, py::arg("d"), py::arg("D"),
        "Beta ratio from diameters.\n\n"
        "beta = d / D\n\n"
        "Parameters:\n"
        "  d : orifice diameter [m]\n"
        "  D : channel diameter [m]\n\n"
        "Returns: beta ratio [-]");

  m.def("orifice_Re_d_from_mdot", &orifice_Re_d_from_mdot, py::arg("mdot"),
        py::arg("d"), py::arg("mu"),
        "Orifice Reynolds number from mass flow rate.\n\n"
        "Re_d = 4·mdot / (π·d·μ)\n\n"
        "Parameters:\n"
        "  mdot : mass flow rate [kg/s]\n"
        "  d    : orifice diameter [m]\n"
        "  mu   : dynamic viscosity [Pa·s]\n\n"
        "Returns: Reynolds number [-]");

  // =========================================================================
  // Channel Roughness Database
  // =========================================================================

  m.def("channel_roughness", &channel_roughness, py::arg("material"),
        "Get absolute roughness for a standard channel material.\n\n"
        "Returns the absolute roughness ε [m] for common channel materials.\n"
        "Material names are case-insensitive.\n\n"
        "Parameters:\n"
        "  material : channel material name (str)\n\n"
        "Returns: absolute roughness ε [m]\n\n"
        "Available materials:\n"
        "  - 'smooth', 'drawn_tubing', 'pvc', 'plastic'\n"
        "  - 'commercial_steel', 'new_steel', 'wrought_iron'\n"
        "  - 'galvanized_iron', 'galvanized_steel', 'rusted_steel'\n"
        "  - 'cast_iron', 'asphalted_cast_iron'\n"
        "  - 'concrete', 'rough_concrete'\n"
        "  - 'riveted_steel', 'wood_stave', 'corrugated_metal'\n\n"
        "Raises: ValueError if material not found\n\n"
        "References:\n"
        "  - Moody (1944), Colebrook (1939), White (2011),\n"
        "    Munson (2013), Crane (2009)\n\n"
        "Example:\n"
        "  >>> eps = channel_roughness('commercial_steel')\n"
        "  >>> print(f'Roughness: {eps*1e6:.1f} μm')  # 45.0 μm");

  m.def("standard_channel_roughness", &standard_channel_roughness,
        "Get all standard channel roughness values.\n\n"
        "Returns a dictionary mapping material names to absolute\n"
        "roughness values [m].\n\n"
        "Returns: dict[str, float] - material -> roughness [m]\n\n"
        "Example:\n"
        "  >>> roughness_db = standard_channel_roughness()\n"
        "  >>> for material, eps in sorted(roughness_db.items()):\n"
        "  ...     print(f'{material:20s}: {eps*1e6:8.2f} μm')");

  m.def("standard_channel_roughness", &standard_channel_roughness,
        "Returns the map of standard material roughness values.");

  // =========================================================================
  // Materials Database
  // =========================================================================

  // Material thermal conductivity functions
  m.def("k_inconel718", &combaero::materials::k_inconel718, py::arg("T"),
        "Thermal conductivity of Inconel 718 [W/(m·K)].\n\n"
        "Ni-based superalloy commonly used in turbine applications.\n\n"
        "Parameters:\n"
        "  T : temperature [K]\n\n"
        "Valid range: 300-1200 K\n"
        "Source: Haynes International, Special Metals Corporation");

  m.def("k_haynes230", &combaero::materials::k_haynes230, py::arg("T"),
        "Thermal conductivity of Haynes 230 [W/(m·K)].\n\n"
        "Ni-Cr-W-Mo alloy with high-temperature oxidation resistance.\n\n"
        "Parameters:\n"
        "  T : temperature [K]\n\n"
        "Valid range: 300-1400 K\n"
        "Source: Haynes International Technical Data");

  m.def("k_stainless_steel_316", &combaero::materials::k_stainless_steel_316,
        py::arg("T"),
        "Thermal conductivity of Stainless Steel 316 [W/(m·K)].\n\n"
        "Austenitic stainless steel with corrosion resistance.\n\n"
        "Parameters:\n"
        "  T : temperature [K]\n\n"
        "Valid range: 300-1200 K\n"
        "Source: NIST, ASM Handbook");

  m.def("k_aluminum_6061", &combaero::materials::k_aluminum_6061, py::arg("T"),
        "Thermal conductivity of Aluminum 6061 [W/(m·K)].\n\n"
        "Aluminum alloy, limited to <300°C due to T6 temper stability.\n\n"
        "Parameters:\n"
        "  T : temperature [K]\n\n"
        "Valid range: 200-600 K\n"
        "Source: ASM Handbook, Aluminum Association");

  m.def(
      "k_tbc_ysz", &combaero::materials::k_tbc_ysz, py::arg("T"),
      py::arg("hours") = 0.0, py::arg("is_ebpvd") = false,
      "Thermal conductivity of YSZ thermal barrier coating [W/(m·K)].\n\n"
      "7-8 wt% Y2O3 stabilized zirconia with sintering model.\n"
      "Conductivity increases over time at high temperature (>1073 K) due to "
      "pore closure.\n\n"
      "Parameters:\n"
      "  T        : temperature [K]\n"
      "  hours    : operating hours at temperature (default: 0 = as-sprayed)\n"
      "  is_ebpvd : True for EB-PVD coating, False for APS (default: False)\n\n"
      "Valid range: 300-1700 K\n"
      "Source: NASA TM-2010-216765 (Zhu/Miller sintering model)\n\n"
      "Coating types:\n"
      "  - APS (Atmospheric Plasma Spray): Lower initial k, splat boundaries\n"
      "  - EB-PVD (Electron Beam PVD): Higher initial k, columnar structure\n\n"
      "Example:\n"
      "  >>> k_aps_fresh = cb.k_tbc_ysz(T=1500)  # APS as-sprayed\n"
      "  >>> k_aps_aged = cb.k_tbc_ysz(T=1500, hours=1000)  # APS after 1000h\n"
      "  >>> k_ebpvd = cb.k_tbc_ysz(T=1500, is_ebpvd=True)  # EB-PVD "
      "as-sprayed");

  m.def("list_materials", &combaero::materials::list_materials,
        "List all available materials in the database.\n\n"
        "Returns: List of material names (strings)\n\n"
        "Example:\n"
        "  >>> materials = cb.list_materials()\n"
        "  >>> print(materials)\n"
        "  ['inconel718', 'haynes230', 'ss316', 'al6061', 'ysz']");

  m.def(
      "get_material_conductivity",
      [](const std::string &name, double T) {
        const auto &mat = combaero::materials::get_material(name);
        // Clamp temperature to material valid range for solver robustness
        double T_clamped = std::clamp(T, mat.T_min, mat.T_max);
        // Evaluate k(T) and clamp to physically positive value
        double k = mat.k_func(T_clamped);
        return std::max(1e-3, k);
      },
      py::arg("name"), py::arg("T"),
      "Get thermal conductivity [W/(m·K)] for a named material at temperature T "
      "[K].\n"
      "Automatically clamps T to the material's valid range and ensures k > 0 "
      "for numerical stability.");

  // =========================================================================
  // Advanced Cooling Correlations
  // =========================================================================

  // Rib-enhanced cooling
  m.def("rib_enhancement_factor",
        static_cast<double (*)(double, double, double)>(
            &combaero::cooling::rib_enhancement_factor),
        py::arg("e_D"), py::arg("pitch_to_height"), py::arg("alpha_deg"),
        "Rib enhancement factor for heat transfer [-] (geometry only, "
        "Re-independent).\n\n"
        "Parameters:\n"
        "  e_D            : rib height / hydraulic diameter [-]\n"
        "  pitch_to_height: rib pitch / rib height [-]\n"
        "  alpha_deg      : rib angle [deg]\n\n"
        "Valid range: e_D = 0.02-0.1, pitch_to_height = 5-20, alpha_deg = "
        "30-90 deg\n"
        "Source: Han et al. (1988)\n\n"
        "Returns: Enhancement factor Nu_rib/Nu_smooth [-]");

  m.def("rib_enhancement_factor_high_re",
        &combaero::cooling::rib_enhancement_factor_high_re, py::arg("e_D"),
        py::arg("pitch_to_height"), py::arg("alpha_deg"), py::arg("Re"),
        "Rib enhancement factor - high-Re direct empirical fit (Singh & Ekkad "
        "2017).\n\n"
        "Nu/Nu0 = 40.0 * Re^(-0.12) * (e/D)^0.38 * (P/e)^(-0.11) * F(alpha)\n"
        "F(alpha) = 1.0 + 0.15*sin(2*alpha_rad)  -- peaks at 45 deg (~1.15), "
        "1.0 at 90 deg.\n\n"
        "Parameters:\n"
        "  e_D            : rib height / hydraulic diameter [-]\n"
        "  pitch_to_height: rib pitch / rib height [-]\n"
        "  alpha_deg      : rib angle [deg]\n"
        "  Re             : channel Reynolds number [-]\n\n"
        "Valid range: Re = 30000-400000, e_D = 0.04-0.10, pitch_to_height = "
        "8-12, alpha_deg = 45-90\n"
        "Source: Singh & Ekkad (2017) ASME GT2016-56363\n\n"
        "Returns: Nu_rib/Nu_smooth [-]");

  m.def("rib_friction_multiplier_high_re",
        &combaero::cooling::rib_friction_multiplier_high_re, py::arg("e_D"),
        py::arg("pitch_to_height"),
        "Rib friction multiplier - high-Re direct empirical fit (Singh & Ekkad "
        "2017).\n\n"
        "f/f0 = 125.0 * (e/D)^0.85 * (P/e)^(-0.25)  (Re-independent, "
        "fully-rough regime).\n\n"
        "Parameters:\n"
        "  e_D            : rib height / hydraulic diameter [-]\n"
        "  pitch_to_height: rib pitch / rib height [-]\n\n"
        "Valid range: e_D = 0.04-0.10, pitch_to_height = 8-12\n"
        "Source: Singh & Ekkad (2017) ASME GT2016-56363\n\n"
        "Returns: f_rib/f_smooth [-]");

  m.def("thermal_performance_factor",
        &combaero::cooling::thermal_performance_factor, py::arg("Nu_ratio"),
        py::arg("f_ratio"),
        "Thermal-hydraulic performance factor (Webb & Eckert 1972).\n\n"
        "eta = (Nu/Nu0) / (f/f0)^(1/3)\n"
        "Compares heat transfer gain against pumping power penalty at equal "
        "velocity.\n"
        "eta > 1: net improvement over smooth; eta < 1: pressure-drop "
        "generator.\n"
        "Generic: works for ribs, dimples, pin fins, impingement, or any "
        "surface.\n\n"
        "Parameters:\n"
        "  Nu_ratio: Nu_enhanced / Nu_smooth [-]\n"
        "  f_ratio : f_enhanced  / f_smooth  [-]\n\n"
        "Source: Webb & Eckert (1972) Int. J. Heat Mass Transfer 15(8), "
        "1647-1658\n\n"
        "Returns: thermal-hydraulic performance factor eta [-]");

  m.def("rib_friction_multiplier", &combaero::cooling::rib_friction_multiplier,
        py::arg("e_D"), py::arg("pitch_to_height"),
        "Rib friction factor multiplier [-].\n\n"
        "Accounts for increased pressure drop from ribs.\n\n"
        "Parameters:\n"
        "  e_D            : rib height / hydraulic diameter [-]\n"
        "  pitch_to_height: rib pitch / rib height [-]\n\n"
        "Valid range: e_D = 0.02-0.1, pitch_to_height = 5-20\n"
        "Source: Han et al. (1988)\n\n"
        "Returns: Friction multiplier f_rib/f_smooth [-]");

  // Impingement cooling
  m.def("impingement_nusselt", &combaero::cooling::impingement_nusselt,
        py::arg("Re_jet"), py::arg("Pr"), py::arg("z_D"), py::arg("x_D") = 0.0,
        py::arg("y_D") = 0.0,
        "Impingement jet Nusselt number correlation [-].\n\n"
        "For single jet or jet array impinging on flat plate.\n\n"
        "Parameters:\n"
        "  Re_jet : Reynolds number based on jet diameter [-]\n"
        "  Pr     : Prandtl number [-]\n"
        "  z_D    : jet-to-plate distance / jet diameter [-]\n"
        "  x_D    : streamwise spacing / jet diameter [-] (default: 0 for "
        "single jet)\n"
        "  y_D    : spanwise spacing / jet diameter [-] (default: 0 for single "
        "jet)\n\n"
        "Valid range: Re_jet = 5000-80000, z_D = 1-12, x_D/y_D = 4-16\n"
        "Source: Florschuetz et al. (1981), Martin (1977)\n\n"
        "Returns: Average Nusselt number [-]");

  // Film cooling
  m.def(
      "film_cooling_effectiveness",
      &combaero::cooling::film_cooling_effectiveness, py::arg("x_D"),
      py::arg("M"), py::arg("DR"), py::arg("alpha_deg"),
      "Adiabatic film cooling effectiveness [-].\n\n"
      "Measures how well coolant film protects surface from hot gas.\n\n"
      "Parameters:\n"
      "  x_D       : downstream distance / hole diameter [-]\n"
      "  M         : blowing ratio (rho_c*v_c)/(rho_inf*v_inf) [-]\n"
      "  DR        : density ratio rho_c/rho_inf [-]\n"
      "  alpha_deg : injection angle [degrees]\n\n"
      "Valid range: M = 0.3-2.5, DR = 1.2-2.0, alpha = 20-90 deg, x_D >= 0\n"
      "Source: Baldauf et al. (2002)\n\n"
      "Returns: Adiabatic effectiveness eta [-] (0 = no cooling, 1 = perfect)");

  m.def("film_cooling_effectiveness_avg",
        &combaero::cooling::film_cooling_effectiveness_avg, py::arg("x_D"),
        py::arg("M"), py::arg("DR"), py::arg("alpha_deg"), py::arg("s_D") = 3.0,
        "Laterally averaged film cooling effectiveness [-].\n\n"
        "Averaged across span for design calculations.\n\n"
        "Parameters:\n"
        "  x_D       : downstream distance / hole diameter [-]\n"
        "  M         : blowing ratio [-]\n"
        "  DR        : density ratio [-]\n"
        "  alpha_deg : injection angle [degrees]\n"
        "  s_D       : hole spacing / hole diameter [-] (default: 3.0)\n\n"
        "Valid range: M = 0.3-2.5, DR = 1.2-2.0, s_D = 2-6\n"
        "Source: Baldauf et al. (2002)\n\n"
        "Returns: Laterally averaged effectiveness eta_avg [-]");

  m.def(
      "film_cooling_multirow_sellers",
      &combaero::cooling::film_cooling_multirow_sellers,
      py::arg("row_positions_xD"), py::arg("eval_xD"), py::arg("M"),
      py::arg("DR"), py::arg("alpha_deg"),
      "Multi-row film cooling using Sellers (1963) superposition.\n\n"
      "Combines effectiveness from multiple upstream rows using the\n"
      "Sellers superposition principle: eta_total = 1 - product(1 - eta_i).\n\n"
      "Parameters:\n"
      "  row_positions_xD : streamwise positions of hole rows [x/D]\n"
      "  eval_xD          : evaluation location [x/D]\n"
      "  M                : blowing ratio [-]\n"
      "  DR               : density ratio [-]\n"
      "  alpha_deg        : injection angle [deg]\n\n"
      "Returns: total adiabatic effectiveness [-]\n\n"
      "References:\n"
      "  - Sellers (1963): Superposition principle for multiple rows\n"
      "  - Baldauf et al. (2002): Single-row effectiveness correlation\n\n"
      "Accuracy: +/-15-20% (flat plate; curvature requires Ito correction)\n\n"
      "Example:\n"
      "  >>> rows = [0, 10, 20]  # Three rows at x/D = 0, 10, 20\n"
      "  >>> eta = cb.film_cooling_multirow_sellers(rows, eval_xD=30, M=0.5, "
      "DR=1.8, alpha_deg=30)\n"
      "  >>> print(eta)  # Combined effectiveness at x/D = 30");

  m.def(
      "effusion_effectiveness", &combaero::cooling::effusion_effectiveness,
      py::arg("x_D"), py::arg("M"), py::arg("DR"), py::arg("porosity"),
      py::arg("s_D"), py::arg("alpha_deg"),
      "Effusion cooling effectiveness for high-density hole arrays.\n\n"
      "Used in combustor liners with continuous coolant injection.\n"
      "Based on Lefebvre (1984) momentum flux ratio approach with\n"
      "crossflow accumulation effects (L'Ecuyer & Matsuura 1985).\n\n"
      "Parameters:\n"
      "  x_D      : streamwise distance from first row / hole diameter [-]\n"
      "  M        : blowing ratio (rho_c*v_c)/(rho_inf*v_inf) [-]\n"
      "  DR       : density ratio rho_c/rho_inf [-]\n"
      "  porosity : hole area / total surface area [-]\n"
      "  s_D      : hole pitch / hole diameter [-]\n"
      "  alpha_deg: injection angle [degrees]\n\n"
      "Returns: adiabatic effectiveness eta [-] (0 = no cooling, 1 = "
      "perfect)\n\n"
      "Valid ranges:\n"
      "  M = 1-4, DR = 1.2-2.0, porosity = 0.02-0.10\n"
      "  s_D = 4-8, alpha = 20-45 deg\n\n"
      "Accuracy: +/-20-25% (high-density arrays, combustor liner geometry)\n\n"
      "References:\n"
      "  - Lefebvre (1984): Gas Turbine Combustion\n"
      "  - L'Ecuyer & Matsuura (1985): Crossflow effects\n\n"
      "Example:\n"
      "  >>> eta = cb.effusion_effectiveness(x_D=10, M=2.0, DR=1.8, "
      "porosity=0.05, s_D=6.0, alpha_deg=30)\n"
      "  >>> print(eta)  # Effectiveness at x/D = 10");

  m.def("effusion_discharge_coefficient",
        &combaero::cooling::effusion_discharge_coefficient, py::arg("Re_d"),
        py::arg("P_ratio"), py::arg("alpha_deg"), py::arg("L_D") = 4.0,
        "Effusion hole discharge coefficient.\n\n"
        "Accounts for compressibility, inclination, and hole geometry.\n"
        "Uses isentropic flow relations for subsonic flow.\n\n"
        "Parameters:\n"
        "  Re_d      : hole Reynolds number based on diameter [-]\n"
        "  P_ratio   : plenum/mainstream pressure ratio [-]\n"
        "  alpha_deg : hole inclination angle [degrees]\n"
        "  L_D       : hole length / diameter [-] (default: 4.0)\n\n"
        "Returns: discharge coefficient Cd [-]\n\n"
        "Valid ranges:\n"
        "  Re_d > 3000, 1.02 < P_ratio < 1.15\n"
        "  20 < alpha < 45 deg, 2 < L_D < 8\n\n"
        "Accuracy: +/-10-15%\n\n"
        "References:\n"
        "  - Hay & Spencer (1992): Compressible flow through inclined holes\n"
        "  - Gritsch et al. (1998): Shaped hole discharge\n\n"
        "Example:\n"
        "  >>> Cd = cb.effusion_discharge_coefficient(Re_d=10000, "
        "P_ratio=1.05, alpha_deg=30, L_D=4.0)\n"
        "  >>> print(Cd)  # Discharge coefficient");

  m.def("pin_fin_nusselt", &combaero::cooling::pin_fin_nusselt, py::arg("Re_d"),
        py::arg("Pr"), py::arg("L_D"), py::arg("S_D"), py::arg("X_D"),
        py::arg("is_staggered") = true,
        "Pin fin array Nusselt number for internal cooling.\n\n"
        "Staggered or inline arrangements of cylindrical pins.\n"
        "Based on Metzger et al. (1982) correlations.\n\n"
        "Parameters:\n"
        "  Re_d         : Reynolds number based on pin diameter [-]\n"
        "  Pr           : Prandtl number [-]\n"
        "  L_D          : pin length / diameter [-]\n"
        "  S_D          : spanwise spacing / diameter [-]\n"
        "  X_D          : streamwise spacing / diameter [-]\n"
        "  is_staggered : True for staggered, False for inline (default: "
        "True)\n\n"
        "Returns: Average Nusselt number Nu_d [-]\n\n"
        "Valid ranges:\n"
        "  Re_d = 3000-90000, Pr = 0.5-1.0, L_D = 0.5-4.0\n"
        "  S_D = 1.5-4.0, X_D = 1.5-4.0\n\n"
        "Accuracy: +/-15-20%\n\n"
        "References:\n"
        "  - Metzger et al. (1982): Effects of Pin Shape and Array "
        "Orientation\n\n"
        "Example:\n"
        "  >>> Nu = cb.pin_fin_nusselt(Re_d=20000, Pr=0.7, L_D=2.0, S_D=2.5, "
        "X_D=2.5)\n"
        "  >>> print(Nu)  # Nusselt number for staggered array");

  m.def("dimple_nusselt_enhancement",
        &combaero::cooling::dimple_nusselt_enhancement, py::arg("Re_Dh"),
        py::arg("d_Dh"), py::arg("h_d"), py::arg("S_d"),
        "Dimpled surface heat transfer enhancement factor.\n\n"
        "Semi-spherical indentations for internal cooling.\n"
        "Returns enhancement ratio Nu_dimple/Nu_smooth.\n\n"
        "Parameters:\n"
        "  Re_Dh : Reynolds number based on channel hydraulic diameter [-]\n"
        "  d_Dh  : dimple diameter / channel height [-]\n"
        "  h_d   : dimple depth / diameter [-]\n"
        "  S_d   : dimple spacing / diameter [-]\n\n"
        "Returns: Enhancement factor Nu_dimple/Nu_smooth [-]\n\n"
        "Valid ranges:\n"
        "  Re_Dh = 10000-80000, d_Dh = 0.1-0.3\n"
        "  h_d = 0.1-0.3, S_d = 1.5-3.0\n\n"
        "Accuracy: +/-20%\n\n"
        "References:\n"
        "  - Chyu et al. (1997): Heat Transfer of Arrays of Semi-Spherical "
        "Indentations\n\n"
        "Key advantage: Lower friction penalty than ribs (1.5-2x vs 6-10x)\n\n"
        "Example:\n"
        "  >>> enhancement = cb.dimple_nusselt_enhancement(Re_Dh=30000, "
        "d_Dh=0.2, h_d=0.2, S_d=2.0)\n"
        "  >>> print(enhancement)  # Typically 1.8-2.5x");

  m.def("dimple_friction_multiplier",
        &combaero::cooling::dimple_friction_multiplier, py::arg("Re_Dh"),
        py::arg("d_Dh"), py::arg("h_d"),
        "Dimpled surface friction multiplier.\n\n"
        "Friction penalty for dimpled surfaces (f_dimple/f_smooth).\n\n"
        "Parameters:\n"
        "  Re_Dh : Reynolds number based on channel hydraulic diameter [-]\n"
        "  d_Dh  : dimple diameter / channel height [-]\n"
        "  h_d   : dimple depth / diameter [-]\n\n"
        "Returns: Friction multiplier f_dimple/f_smooth [-]\n\n"
        "Valid ranges:\n"
        "  Re_Dh = 10000-80000, d_Dh = 0.1-0.3, h_d = 0.1-0.3\n\n"
        "Accuracy: +/-15%\n\n"
        "References:\n"
        "  - Chyu et al. (1997)\n\n"
        "Typical range: 1.3-2.2x (much lower than ribs)\n\n"
        "Example:\n"
        "  >>> f_ratio = cb.dimple_friction_multiplier(Re_Dh=30000, d_Dh=0.2, "
        "h_d=0.2)\n"
        "  >>> print(f_ratio)  # Typically 1.5-2.0x");

  m.def("adiabatic_wall_temperature",
        &combaero::cooling::adiabatic_wall_temperature, py::arg("T_hot"),
        py::arg("T_coolant"), py::arg("eta"),
        "Adiabatic wall temperature from cooling effectiveness.\n\n"
        "Uses: eta = (T_hot - T_aw) / (T_hot - T_coolant).\n\n"
        "Parameters:\n"
        "  T_hot     : mainstream hot-gas temperature [K]\n"
        "  T_coolant : coolant supply temperature [K]\n"
        "  eta       : adiabatic effectiveness [-]\n\n"
        "Returns: adiabatic wall temperature T_aw [K]");

  m.def("cooled_wall_heat_flux", &combaero::cooling::cooled_wall_heat_flux,
        py::arg("T_hot"), py::arg("T_coolant"), py::arg("h_hot"),
        py::arg("h_coolant"), py::arg("eta"), py::arg("t_wall"),
        py::arg("k_wall"),
        "Film/effusion-cooled wall heat flux with single wall layer.\n\n"
        "Computes q = U * (T_aw - T_coolant), where T_aw is from cooling\n"
        "effectiveness and U includes both convection sides plus wall "
        "conduction.\n\n"
        "Parameters:\n"
        "  T_hot      : mainstream hot-gas temperature [K]\n"
        "  T_coolant  : coolant supply temperature [K]\n"
        "  h_hot      : hot-side HTC [W/(m^2*K)]\n"
        "  h_coolant  : coolant-side HTC [W/(m^2*K)]\n"
        "  eta        : adiabatic effectiveness [-]\n"
        "  t_wall     : wall thickness [m]\n"
        "  k_wall     : wall thermal conductivity [W/(m*K)]\n\n"
        "Returns: wall heat flux q [W/m^2]");

  // =========================================================================
  // Units System
  // =========================================================================

  py::class_<combaero::units::UnitInfo>(m, "UnitInfo")
      .def_readonly("input", &combaero::units::UnitInfo::input,
                    "Input units description")
      .def_readonly("output", &combaero::units::UnitInfo::output,
                    "Output units description")
      .def("__repr__", [](const combaero::units::UnitInfo &u) {
        return "UnitInfo(input='" + std::string(u.input) + "', output='" +
               std::string(u.output) + "')";
      });

  m.def(
      "get_units",
      [](const std::string &name) -> py::object {
        auto u = combaero::units::get_units(name);
        if (u) {
          return py::cast(combaero::units::UnitInfo{u->input, u->output});
        }
        return py::none();
      },
      py::arg("function_name"),
      "Get input/output units for a function by name.\n\n"
      "Returns UnitInfo with 'input' and 'output' fields, or None if not "
      "found.\n\n"
      "Example:\n"
      "    >>> combaero.get_units('density')\n"
      "    UnitInfo(input='T: K, P: Pa, X: mol/mol', output='kg/m^3')");

  m.def(
      "input_units",
      [](const std::string &name) {
        return std::string(combaero::units::input_units(name));
      },
      py::arg("function_name"),
      "Get input units string for a function (empty string if not found).");

  m.def(
      "output_units",
      [](const std::string &name) {
        return std::string(combaero::units::output_units(name));
      },
      py::arg("function_name"),
      "Get output units string for a function (empty string if not found).");

  m.def(
      "has_units",
      [](const std::string &name) { return combaero::units::has_units(name); },
      py::arg("function_name"), "Check if a function has registered units.");

  m.def(
      "list_functions_with_units",
      []() {
        std::vector<std::string> names;
        for (auto it = combaero::units::begin(); it != combaero::units::end();
             ++it) {
          names.emplace_back(it->name);
        }
        return names;
      },
      "List all function names that have registered units.");

  m.def(
      "all_units",
      []() {
        py::dict result;
        for (auto it = combaero::units::begin(); it != combaero::units::end();
             ++it) {
          py::dict entry;
          entry["input"] = std::string(it->input);
          entry["output"] = std::string(it->output);
          result[py::str(std::string(it->name))] = entry;
        }
        return result;
      },
      "Get all registered units as a dictionary.\n\n"
      "Returns: dict mapping function_name -> {'input': ..., 'output': ...}");

  // =========================================================================
  // Incompressible flow — scalar primitives
  // =========================================================================

  m.def(
      "orifice_mdot",
      [](double P1, double P2, double A, double Cd, double rho) {
        return orifice_mdot(P1, P2, A, Cd, rho);
      },
      py::arg("P1"), py::arg("P2"), py::arg("A"), py::arg("Cd"), py::arg("rho"),
      "Incompressible orifice mass flow rate [kg/s].\n"
      "mdot = Cd * A * sqrt(2 * rho * (P1 - P2))");

  m.def(
      "orifice_Q",
      [](double P1, double P2, double A, double Cd, double rho) {
        return orifice_Q(P1, P2, A, Cd, rho);
      },
      py::arg("P1"), py::arg("P2"), py::arg("A"), py::arg("Cd"), py::arg("rho"),
      "Incompressible orifice volumetric flow rate [m^3/s].");

  m.def(
      "orifice_velocity",
      [](double P1, double P2, double rho) {
        return orifice_velocity(P1, P2, rho);
      },
      py::arg("P1"), py::arg("P2"), py::arg("rho"),
      "Ideal orifice velocity v = sqrt(2*dP/rho) [m/s].");

  m.def(
      "orifice_area",
      [](double mdot, double P1, double P2, double Cd, double rho) {
        return orifice_area(mdot, P1, P2, Cd, rho);
      },
      py::arg("mdot"), py::arg("P1"), py::arg("P2"), py::arg("Cd"),
      py::arg("rho"), "Orifice area for given mass flow [m^2].");

  m.def(
      "orifice_dP",
      [](double mdot, double A, double Cd, double rho) {
        return orifice_dP(mdot, A, Cd, rho);
      },
      py::arg("mdot"), py::arg("A"), py::arg("Cd"), py::arg("rho"),
      "Pressure drop for given orifice mass flow [Pa].");

  m.def(
      "channel_area", [](double D) { return circular_area(D); }, py::arg("D"),
      "Channel cross-sectional area [m^2].");

  m.def(
      "channel_velocity",
      [](double mdot, double D, double rho) {
        return channel_velocity(mdot, D, rho);
      },
      py::arg("mdot"), py::arg("D"), py::arg("rho"),
      "Channel velocity from mass flow [m/s].");

  m.def(
      "channel_volume",
      [](double D, double L) { return cylinder_volume(D, L); }, py::arg("D"),
      py::arg("L"), "Channel volume [m^3].");

  m.def(
      "channel_mdot",
      [](double v, double D, double rho) { return channel_mdot(v, D, rho); },
      py::arg("v"), py::arg("D"), py::arg("rho"),
      "Channel mass flow from velocity [kg/s].");

  m.def(
      "bernoulli_P2",
      [](double P1, double v1, double v2, double rho, double dz, double g) {
        return bernoulli_P2(P1, v1, v2, rho, dz, g);
      },
      py::arg("P1"), py::arg("v1"), py::arg("v2"), py::arg("rho"),
      py::arg("dz") = 0.0, py::arg("g") = 9.80665,
      "Bernoulli downstream pressure P2 [Pa].");

  m.def(
      "bernoulli_v2",
      [](double P1, double P2, double v1, double rho, double dz, double g) {
        return bernoulli_v2(P1, P2, v1, rho, dz, g);
      },
      py::arg("P1"), py::arg("P2"), py::arg("v1"), py::arg("rho"),
      py::arg("dz") = 0.0, py::arg("g") = 9.80665,
      "Bernoulli downstream velocity v2 [m/s].");

  m.def(
      "dynamic_pressure",
      [](double v, double rho) { return dynamic_pressure(v, rho); },
      py::arg("v"), py::arg("rho"),
      "Dynamic pressure q = 0.5 * rho * v^2 [Pa].");

  m.def(
      "velocity_from_q",
      [](double q, double rho) { return velocity_from_q(q, rho); },
      py::arg("q"), py::arg("rho"), "Velocity from dynamic pressure [m/s].");

  m.def(
      "pressure_loss",
      [](double v, double rho, double zeta) {
        return pressure_loss(v, rho, zeta);
      },
      py::arg("v"), py::arg("rho"), py::arg("zeta"),
      "Pressure drop from loss coefficient: dP = zeta * 0.5 * rho * v^2 [Pa].");

  m.def(
      "velocity_from_pressure_loss",
      [](double dP, double rho, double zeta) {
        return velocity_from_pressure_loss(dP, rho, zeta);
      },
      py::arg("dP"), py::arg("rho"), py::arg("zeta"),
      "Velocity from pressure drop and loss coefficient [m/s].");

  m.def(
      "zeta_from_Cd", [](double Cd) { return zeta_from_Cd(Cd); }, py::arg("Cd"),
      "Loss coefficient from discharge coefficient: zeta = 1/Cd^2 [-].");

  m.def(
      "Cd_from_zeta", [](double zeta) { return Cd_from_zeta(zeta); },
      py::arg("zeta"),
      "Discharge coefficient from loss coefficient: Cd = 1/sqrt(zeta) [-].");

  // =========================================================================
  // Incompressible flow — thermo-aware high-level API
  // =========================================================================

  m.def(
      "orifice_flow_thermo",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P_back, double A, double Cd) {
        return orifice_flow_thermo(T, P, to_vec(X_arr), P_back, A, Cd);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("P_back"), py::arg("A"),
      py::arg("Cd") = 1.0,
      "Thermo-aware incompressible orifice flow.\n"
      "Evaluates rho from (T, P, X) internally.\n"
      "Returns IncompressibleFlowSolution.");

  m.def(
      "orifice_flow_thermo",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double P_back, double A, py::function cd_fn) {
        auto vec = to_vec(X_arr);
        IncompressibleCdFn fn = [cd_fn, vec](double T_, double P_,
                                             const std::vector<double> &,
                                             double Re) {
          return cd_fn(T_, P_, vec, Re).cast<double>();
        };
        return orifice_flow_thermo(T, P, vec, P_back, A, fn);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("P_back"), py::arg("A"),
      py::arg("cd_fn"),
      "Thermo-aware orifice flow with user-supplied Cd callable.\n\n"
      "cd_fn(T, P, X, Re) -> float  (must return Cd in (0, 1])\n"
      "Re is computed from the ideal throat velocity (loop-free).\n"
      "Returns IncompressibleFlowSolution.");

  m.def(
      "channel_flow",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double u, double L, double D, double f, std::size_t n_steps,
         bool store_profile) {
        return channel_flow(T, P, to_vec(X_arr), u, L, D, f, n_steps,
                            store_profile);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("u"), py::arg("L"),
      py::arg("D"), py::arg("f"), py::arg("n_steps") = 10,
      py::arg("store_profile") = false,
      "Thermo-aware incompressible channel flow with explicit friction "
      "factor.\n"
      "Returns IncompressibleFlowSolution.");

  m.def(
      "channel_flow_rough",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double u, double L, double D, double roughness,
         const std::string &correlation, std::size_t n_steps,
         bool store_profile) {
        return channel_flow_rough(T, P, to_vec(X_arr), u, L, D, roughness,
                                  correlation, n_steps, store_profile);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("u"), py::arg("L"),
      py::arg("D"), py::arg("roughness") = 0.0,
      py::arg("correlation") = "haaland", py::arg("n_steps") = 10,
      py::arg("store_profile") = false,
      "Thermo-aware incompressible channel flow with roughness-based friction "
      "factor.\n"
      "Returns IncompressibleFlowSolution.");

  m.def(
      "channel_flow_rough",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double u, double L, double D, double roughness,
         const std::string &correlation, py::function k_loss_fn) {
        auto vec = to_vec(X_arr);
        IncompressibleKLossFn fn = [k_loss_fn, vec](double T_, double P_,
                                                    const std::vector<double> &,
                                                    double Re) {
          return k_loss_fn(T_, P_, vec, Re).cast<double>();
        };
        return channel_flow_rough(T, P, vec, u, L, D, roughness, correlation,
                                  fn);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("u"), py::arg("L"),
      py::arg("D"), py::arg("roughness") = 0.0,
      py::arg("correlation") = "haaland", py::arg("k_loss_fn"),
      "Channel flow with additional K-loss callable (bends, fittings, "
      "etc.).\n\n"
      "k_loss_fn(T, P, X, Re) -> float  (returns K [-])\n"
      "Extra dP = K * 0.5 * rho * u^2 is added to Darcy-Weisbach friction "
      "loss.\n"
      "Returns IncompressibleFlowSolution.");

  m.def(
      "channel_pressure_drop",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double v, double D, double L, double roughness,
         const std::string &correlation) {
        return channel_pressure_drop(T, P, to_vec(X_arr), v, D, L, roughness,
                                     correlation);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("v"), py::arg("D"),
      py::arg("L"), py::arg("roughness") = 0.0,
      py::arg("correlation") = "haaland",
      "Composite channel pressure drop.\n"
      "Returns tuple (dP [Pa], Re [-], f [-]).");

  // =========================================================================
  // Compressible flow — new functions
  // =========================================================================

  m.def(
      "fanno_channel",
      [](double T_in, double P_in, double u_in, double L, double D, double f,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         std::size_t n_steps, bool store_profile) {
        return fanno_channel(T_in, P_in, u_in, L, D, f, to_vec(X_arr), n_steps,
                             store_profile);
      },
      py::arg("T_in"), py::arg("P_in"), py::arg("u_in"), py::arg("L"),
      py::arg("D"), py::arg("f"), py::arg("X"), py::arg("n_steps") = 100,
      py::arg("store_profile") = false,
      "Fanno flow (adiabatic compressible channel flow with constant friction "
      "factor).\n"
      "Returns FannoSolution.");

  m.def(
      "fanno_channel_rough",
      [](double T_in, double P_in, double u_in, double L, double D,
         double roughness,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         const std::string &correlation, double f_multiplier,
         std::size_t n_steps, bool store_profile) {
        return fanno_channel_rough(T_in, P_in, u_in, L, D, roughness,
                                   to_vec(X_arr), correlation, f_multiplier,
                                   n_steps, store_profile);
      },
      py::arg("T_in"), py::arg("P_in"), py::arg("u_in"), py::arg("L"),
      py::arg("D"), py::arg("roughness"), py::arg("X"),
      py::arg("correlation") = "haaland", py::arg("f_multiplier") = 1.0,
      py::arg("n_steps") = 100, py::arg("store_profile") = false,
      "Fanno flow with roughness-based variable friction factor f(x).\n"
      "Recomputes f at each RK4 stage from local Re and roughness.\n"
      "Returns FannoSolution with f_avg and Re_in populated.");

  m.def(
      "fanno_max_length",
      [](double T_in, double P_in, double u_in, double D, double f,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return fanno_max_length(T_in, P_in, u_in, D, f, to_vec(X_arr), tol,
                                max_iter);
      },
      py::arg("T_in"), py::arg("P_in"), py::arg("u_in"), py::arg("D"),
      py::arg("f"), py::arg("X"), py::arg("tol") = 1e-6,
      py::arg("max_iter") = 100,
      "Maximum channel length before choking (Fanno L*) [m].");

  // =========================================================================
  // Stagnation / static conversion utilities  (stagnation.h)
  // =========================================================================

  m.def("kinetic_energy", &kinetic_energy, py::arg("v"),
        "Specific kinetic energy v^2/2 [J/kg].");

  m.def("h0_from_static", &h0_from_static, py::arg("h_static_J_per_kg"),
        py::arg("v"),
        "Stagnation enthalpy from static enthalpy [J/kg] and velocity [m/s].\n"
        "h0 = h_static + v^2/2  [J/kg].");

  m.def("v_from_h0", &v_from_h0, py::arg("h0"), py::arg("h_static_J_per_kg"),
        "Velocity [m/s] from stagnation and static enthalpy [J/kg].\n"
        "v = sqrt(2*(h0 - h_static)). Returns 0 if h0 <= h_static.");

  m.def(
      "mach_number",
      [](double v, double T,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        return mach_number(v, T, to_vec(X_arr));
      },
      py::arg("v"), py::arg("T"), py::arg("X"),
      "Mach number from velocity [m/s] and static temperature [K].\n"
      "M = v / a(T, X).");

  m.def(
      "T0_from_static",
      [](double T, double M,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return T0_from_static(T, M, to_vec(X_arr), tol, max_iter);
      },
      py::arg("T"), py::arg("M"), py::arg("X"), py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50,
      "Stagnation temperature T0 [K] from static T [K] and Mach number.\n"
      "Iterative for variable cp(T) (thermally perfect gas).");

  m.def(
      "T0_from_static_v",
      [](double T, double v,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return T0_from_static_v(T, v, to_vec(X_arr), tol, max_iter);
      },
      py::arg("T"), py::arg("v"), py::arg("X"), py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50,
      "Stagnation temperature T0 [K] from static T [K] and velocity v [m/s].\n"
      "Iterative for variable cp(T).");

  m.def(
      "T_from_stagnation",
      [](double T0, double M,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return T_from_stagnation(T0, M, to_vec(X_arr), tol, max_iter);
      },
      py::arg("T0"), py::arg("M"), py::arg("X"), py::arg("tol") = 1e-8,
      py::arg("max_iter") = 50,
      "Static temperature T [K] from stagnation T0 [K] and Mach number.\n"
      "Iterative for variable cp(T).");

  m.def(
      "P0_from_static",
      [](double P, double T, double M,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return P0_from_static(P, T, M, to_vec(X_arr), tol, max_iter);
      },
      py::arg("P"), py::arg("T"), py::arg("M"), py::arg("X"),
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Stagnation pressure P0 [Pa] from static P [Pa], T [K] and Mach number.\n"
      "Uses isentropic entropy conservation (variable cp).");

  m.def(
      "P_from_stagnation",
      [](double P0, double T0, double M,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return P_from_stagnation(P0, T0, M, to_vec(X_arr), tol, max_iter);
      },
      py::arg("P0"), py::arg("T0"), py::arg("M"), py::arg("X"),
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Static pressure P [Pa] from stagnation P0 [Pa], T0 [K] and Mach "
      "number.\n"
      "Uses isentropic entropy conservation (variable cp).");

  m.def("recovery_factor", &recovery_factor, py::arg("Pr"),
        py::arg("turbulent") = true,
        "Recovery factor r [-] for adiabatic wall temperature.\n"
        "r = Pr^(1/3) for turbulent (default), Pr^(1/2) for laminar.");

  m.def(
      "T_adiabatic_wall",
      [](double T_static, double v, double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         bool turbulent) {
        return T_adiabatic_wall(T_static, v, T, P, to_vec(X_arr), turbulent);
      },
      py::arg("T_static"), py::arg("v"), py::arg("T"), py::arg("P"),
      py::arg("X"), py::arg("turbulent") = true,
      "Adiabatic wall temperature T_aw [K] from static T [K] and velocity v "
      "[m/s].\n"
      "T_aw = T_static + r * v^2 / (2*cp)  where r = Pr^(1/3) turbulent.\n"
      "Use T_aw (not T_static or T_total) as the hot-side driving temperature\n"
      "in channel evaluations and cooled_wall_heat_flux() for M > 0.3.");

  m.def(
      "T_adiabatic_wall_mach",
      [](double T_static, double M, double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         bool turbulent) {
        return T_adiabatic_wall_mach(T_static, M, T, P, to_vec(X_arr),
                                     turbulent);
      },
      py::arg("T_static"), py::arg("M"), py::arg("T"), py::arg("P"),
      py::arg("X"), py::arg("turbulent") = true,
      "Adiabatic wall temperature T_aw [K] from static T [K] and Mach number.\n"
      "Computes v = M * a(T, X) internally, then applies recovery factor "
      "correction.");

  m.def(
      "stagnation_from_static",
      [](double T, double P, double v,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double tol, std::size_t max_iter) {
        return stagnation_from_static(T, P, v, to_vec(X_arr), tol, max_iter);
      },
      py::arg("T"), py::arg("P"), py::arg("v"), py::arg("X"),
      py::arg("tol") = 1e-8, py::arg("max_iter") = 50,
      "Combined stagnation state (Tt, Pt) from static (T, P) and velocity v.\n"
      "Returns tuple (Tt [K], Pt [Pa]).\n"
      "Preferred over calling T0_from_static_v + P0_from_static separately\n"
      "as it uses a single Newton loop and avoids redundant physics calls.");

  m.def("bulk_velocity", &bulk_velocity, py::arg("m_dot"), py::arg("rho"),
        py::arg("area"),
        "Bulk velocity v = m_dot / (rho * area)  [m/s].");

  m.def("reynolds_from_state", &reynolds_from_state, py::arg("rho"),
        py::arg("v"), py::arg("L"), py::arg("mu"),
        "Reynolds number Re = rho * v * L / mu  [-].\n"
        "Use when rho and mu are already available from CompleteState or\n"
        "TransportState to avoid recomputing mixture properties.");

  // -----------------------------------------------------------------
  // ChannelResult struct
  // -----------------------------------------------------------------
  py::class_<ChannelResult>(
      m, "ChannelResult",
      "Combined convective heat transfer + pressure loss result.\n\n"
      "Returned by channel_smooth, channel_ribbed, channel_dimpled,\n"
      "channel_pin_fin, and channel_impingement.\n\n"
      "All fluid properties are evaluated in a single pass from (T, P, X).\n\n"
      "T_aw is always computed continuously for all M:\n"
      "  T_aw = T_static + r * v^2 / (2*cp)  (r = Pr^1/3 turbulent)\n"
      "  At v=0: T_aw = T_static exactly. No threshold, no discontinuity.\n\n"
      "q = h * (T_aw - T_hot) when T_hot is supplied, else nan.\n\n"
      "f meaning depends on geometry:\n"
      "  smooth/ribbed/dimpled : Darcy friction factor [-]\n"
      "  pin_fin               : pin-array friction coefficient [-]\n"
      "  impingement           : jet-plate loss coefficient 1/Cd^2 [-]")
      .def(py::init<>())
      .def_readonly("h", &ChannelResult::h, "Convective HTC [W/(m^2*K)]")
      .def_readonly("Nu", &ChannelResult::Nu, "Nusselt number [-]")
      .def_readonly("Re", &ChannelResult::Re, "Reynolds number [-]")
      .def_readonly("Pr", &ChannelResult::Pr, "Prandtl number [-]")
      .def_readonly("f", &ChannelResult::f, "Friction / loss coefficient [-]")
      .def_readonly("dP", &ChannelResult::dP, "Pressure drop [Pa]")
      .def_readonly("M", &ChannelResult::M, "Mach number [-]")
      .def_readonly("T_aw", &ChannelResult::T_aw,
                    "Adiabatic wall temperature [K]")
      .def_readonly("q", &ChannelResult::q,
                    "Heat flux [W/m^2] (nan if T_hot not supplied)")
      .def_readonly("dh_dmdot", &ChannelResult::dh_dmdot,
                    "Jacobian: dh/dmdot [W/(m^2*K*kg/s)]")
      .def_readonly("dh_dT", &ChannelResult::dh_dT,
                    "Jacobian: dh/dT [W/(m^2*K^2)]")
      .def_readonly("ddP_dmdot", &ChannelResult::ddP_dmdot,
                    "Jacobian: d(dP)/dmdot [Pa*s/kg]")
      .def_readonly("ddP_dT", &ChannelResult::ddP_dT,
                    "Jacobian: d(dP)/dT [Pa/K]")
      .def_readonly("dT_aw_dmdot", &ChannelResult::dT_aw_dmdot,
                    "Jacobian: dT_aw/dmdot [K*s/kg]")
      .def_readonly("dT_aw_dT", &ChannelResult::dT_aw_dT,
                    "Jacobian: dT_aw/dT [-] (approx 1 at low Mach)")
      .def_readonly("dq_dmdot", &ChannelResult::dq_dmdot,
                    "Jacobian: dq/dmdot [W*s/(m^2*kg)]")
      .def_readonly("dq_dT", &ChannelResult::dq_dT,
                    "Jacobian: dq/dT [W/(m^2*K)]")
      .def_readonly("dq_dT_hot", &ChannelResult::dq_dT_hot,
                    "Jacobian: dq/dT_hot [W/(m^2*K)]")
      .def("__repr__", [](const ChannelResult &r) {
        auto fmt = [](double v) {
          if (std::isnan(v))
            return std::string("nan");
          char buf[32];
          std::snprintf(buf, sizeof(buf), "%.6g", v);
          return std::string(buf);
        };
        return "ChannelResult(h=" + fmt(r.h) + ", Nu=" + fmt(r.Nu) +
               ", Re=" + fmt(r.Re) + ", dP=" + fmt(r.dP) +
               ", T_aw=" + fmt(r.T_aw) + ", q=" + fmt(r.q) + ")";
      });

  // -----------------------------------------------------------------
  // WallCouplingResult struct
  // -----------------------------------------------------------------
  py::class_<WallCouplingResult>(
      m, "WallCouplingResult",
      "Heat transfer through a wall between two elements.\n\n"
      "Returned by wall_coupling_and_jacobian.\n\n"
      "Q is positive when heat flows from side A to side B.\n"
      "T_hot is the hot-side surface temperature.\n"
      "Jacobians enable proper Newton coupling in the network solver.")
      .def_readonly("Q", &WallCouplingResult::Q,
                    "Heat transfer rate [W] (positive A->B)")
      .def_readonly("T_hot", &WallCouplingResult::T_hot,
                    "Hot-side wall surface temperature [K].")
      .def_readonly("dQ_dh_a", &WallCouplingResult::dQ_dh_a,
                    "Jacobian: dQ/dh_a [W*m^2*K/W]")
      .def_readonly("dQ_dh_b", &WallCouplingResult::dQ_dh_b,
                    "Jacobian: dQ/dh_b [W*m^2*K/W]")
      .def_readonly("dQ_dT_aw_a", &WallCouplingResult::dQ_dT_aw_a,
                    "Jacobian: dQ/dT_aw_a [W/K]")
      .def_readonly("dQ_dT_aw_b", &WallCouplingResult::dQ_dT_aw_b,
                    "Jacobian: dQ/dT_aw_b [W/K]")
      .def("__repr__",
           [](const WallCouplingResult &r) {
             auto fmt = [](double v) {
               char buf[32];
               std::snprintf(buf, sizeof(buf), "%.6g", v);
               return std::string(buf);
             };
             return "WallCouplingResult(Q=" + fmt(r.Q) +
                    ", T_hot=" + fmt(r.T_hot) + ")";
           })
      .def("__iter__", [](const WallCouplingResult &r) {
        return py::iter(py::make_tuple(r.Q, r.T_hot));
      });

  // -----------------------------------------------------------------
  // wall_coupling_and_jacobian
  // -----------------------------------------------------------------
  m.def(
      "wall_coupling_and_jacobian",
      py::overload_cast<double, double, double, double, double, double>(
          &wall_coupling_and_jacobian),
      py::arg("h_a"), py::arg("T_aw_a"), py::arg("h_b"), py::arg("T_aw_b"),
      py::arg("t_over_k"), py::arg("A"),
      "Compute heat transfer and Jacobians for single-layer wall coupling.\n\n"
      "Parameters:\n"
      "  h_a, h_b       : convective HTCs on sides A and B [W/(m^2*K)]\n"
      "  T_aw_a, T_aw_b : adiabatic wall temperatures on sides A and B [K]\n"
      "  t_over_k       : wall_thickness / wall_conductivity [m^2*K/W]\n"
      "  A              : effective heat transfer area [m^2]\n\n"
      "Returns: WallCouplingResult with Q and analytical Jacobians");

  m.def("wall_coupling_and_jacobian_multilayer",
        py::overload_cast<double, double, double, double,
                          const std::vector<double> &, double, double>(
            &wall_coupling_and_jacobian),
        py::arg("h_a"), py::arg("T_aw_a"), py::arg("h_b"), py::arg("T_aw_b"),
        py::arg("t_over_k_layers"), py::arg("A"), py::arg("R_fouling") = 0.0,
        "Compute heat transfer and Jacobians for multi-layer wall coupling.\n\n"
        "Parameters:\n"
        "  h_a, h_b       : convective HTCs on sides A and B [W/(m^2*K)]\n"
        "  T_aw_a, T_aw_b : adiabatic wall temperatures on sides A and B [K]\n"
        "  t_over_k_layers: thicknesses / conductivities for each layer "
        "[m^2*K/W]\n"
        "  A              : effective heat transfer area [m^2]\n"
        "  R_fouling      : additional fouling resistance [m^2*K/W]\n\n"
        "Returns: WallCouplingResult with Q and analytical Jacobians");

  // -----------------------------------------------------------------
  // channel_smooth
  // -----------------------------------------------------------------
  m.def(
      "channel_smooth",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double diameter, double length, double T_hot,
         const std::string &correlation, bool heating, double mu_ratio,
         double roughness, double Nu_multiplier, double f_multiplier) {
        return channel_smooth(T, P, to_vec(X_arr), velocity, diameter, length,
                              T_hot, correlation, heating, mu_ratio, roughness,
                              Nu_multiplier, f_multiplier);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("diameter"), py::arg("length"),
      py::arg("T_hot") = std::numeric_limits<double>::quiet_NaN(),
      py::arg("correlation") = "gnielinski", py::arg("heating") = true,
      py::arg("mu_ratio") = 1.0, py::arg("roughness") = 0.0,
      py::arg("Nu_multiplier") = 1.0, py::arg("f_multiplier") = 1.0,
      "Smooth channel/duct: combined HTC + pressure drop.\n\n"
      "Parameters:\n"
      "  T, P, X    : bulk static thermodynamic state\n"
      "  velocity   : bulk velocity [m/s]\n"
      "  diameter   : hydraulic diameter [m]\n"
      "  length     : channel length [m]\n"
      "  T_hot      : wall temperature [K] (nan to skip q)\n"
      "  correlation: 'gnielinski' (default), 'dittus_boelter', 'sieder_tate', "
      "'petukhov'\n"
      "  heating    : True = fluid heated\n"
      "  mu_ratio   : mu_bulk/mu_wall for Sieder-Tate\n"
      "  roughness  : absolute wall roughness [m]\n"
      "  Nu_multiplier : empirical correction factor on Nu (default 1.0)\n"
      "  f_multiplier  : empirical correction factor on f (default 1.0)\n\n"
      "Returns: ChannelResult with Jacobian fields populated");

  // -----------------------------------------------------------------
  // channel_ribbed
  // -----------------------------------------------------------------
  m.def(
      "channel_ribbed",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double diameter, double length, double e_D,
         double pitch_to_height, double alpha_deg, double T_hot, bool heating,
         double Nu_multiplier, double f_multiplier) {
        return channel_ribbed(T, P, to_vec(X_arr), velocity, diameter, length,
                              e_D, pitch_to_height, alpha_deg, T_hot, heating,
                              Nu_multiplier, f_multiplier);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("diameter"), py::arg("length"), py::arg("e_D"),
      py::arg("pitch_to_height"), py::arg("alpha_deg"),
      py::arg("T_hot") = std::numeric_limits<double>::quiet_NaN(),
      py::arg("heating") = true, py::arg("Nu_multiplier") = 1.0,
      py::arg("f_multiplier") = 1.0,
      "Rib-enhanced cooling channel (Han et al. 1988).\n\n"
      "Applies rib_enhancement_factor to Nu and rib_friction_multiplier to f\n"
      "from a smooth-channel Gnielinski baseline.\n\n"
      "Parameters:\n"
      "  e_D            : rib height / hydraulic diameter [-]  (valid: "
      "0.02-0.1)\n"
      "  pitch_to_height: rib pitch / rib height [-]           (valid: 5-20)\n"
      "  alpha_deg      : rib angle [deg]                      (valid: "
      "30-90)\n\n"
      "Returns: ChannelResult");

  // -----------------------------------------------------------------
  // channel_dimpled
  // -----------------------------------------------------------------
  m.def(
      "channel_dimpled",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double diameter, double length, double d_Dh,
         double h_d, double S_d, double T_hot, bool heating,
         double Nu_multiplier, double f_multiplier) {
        return channel_dimpled(T, P, to_vec(X_arr), velocity, diameter, length,
                               d_Dh, h_d, S_d, T_hot, heating, Nu_multiplier,
                               f_multiplier);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("diameter"), py::arg("length"), py::arg("d_Dh"), py::arg("h_d"),
      py::arg("S_d"),
      py::arg("T_hot") = std::numeric_limits<double>::quiet_NaN(),
      py::arg("heating") = true, py::arg("Nu_multiplier") = 1.0,
      py::arg("f_multiplier") = 1.0,
      "Dimpled surface cooling channel (Chyu et al. 1997).\n\n"
      "Applies dimple_nusselt_enhancement to Nu and dimple_friction_multiplier "
      "to f\n"
      "from a smooth-channel Gnielinski baseline.\n\n"
      "Parameters:\n"
      "  d_Dh : dimple diameter / channel height [-]  (valid: 0.1-0.3)\n"
      "  h_d  : dimple depth / diameter [-]           (valid: 0.1-0.3)\n"
      "  S_d  : dimple spacing / diameter [-]         (valid: 1.5-3.0)\n\n"
      "Returns: ChannelResult");

  // -----------------------------------------------------------------
  // channel_pin_fin
  // -----------------------------------------------------------------
  m.def(
      "channel_pin_fin",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double velocity, double channel_height, double pin_diameter,
         double S_D, double X_D, int N_rows, double T_hot, bool is_staggered,
         double Nu_multiplier, double f_multiplier) {
        return channel_pin_fin(T, P, to_vec(X_arr), velocity, channel_height,
                               pin_diameter, S_D, X_D, N_rows, T_hot,
                               is_staggered, Nu_multiplier, f_multiplier);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("velocity"),
      py::arg("channel_height"), py::arg("pin_diameter"), py::arg("S_D"),
      py::arg("X_D"), py::arg("N_rows"),
      py::arg("T_hot") = std::numeric_limits<double>::quiet_NaN(),
      py::arg("is_staggered") = true, py::arg("Nu_multiplier") = 1.0,
      py::arg("f_multiplier") = 1.0,
      "Pin-fin array cooling channel (Metzger et al. 1982).\n\n"
      "Re and Nu are based on pin diameter d.\n"
      "dP = N_rows * f_pin * (rho * v_max^2 / 2)\n"
      "  v_max = velocity * S_D / (S_D - 1)  (minimum cross-section)\n\n"
      "Parameters:\n"
      "  velocity       : approach velocity [m/s]\n"
      "  channel_height : pin length H [m]\n"
      "  pin_diameter   : pin diameter d [m]\n"
      "  S_D            : spanwise pitch / d [-]   (valid: 1.5-4.0)\n"
      "  X_D            : streamwise pitch / d [-] (valid: 1.5-4.0)\n"
      "  N_rows         : number of pin rows\n"
      "  is_staggered   : True = staggered (default), False = inline\n\n"
      "Returns: ChannelResult");

  // -----------------------------------------------------------------
  // channel_impingement
  // -----------------------------------------------------------------
  m.def(
      "channel_impingement",
      [](double T, double P,
         py::array_t<double, py::array::c_style | py::array::forcecast> X_arr,
         double mdot_jet, double d_jet, double z_D, double x_D, double y_D,
         double A_target, double T_hot, double Cd_jet, double Nu_multiplier,
         double f_multiplier) {
        return channel_impingement(T, P, to_vec(X_arr), mdot_jet, d_jet, z_D,
                                   x_D, y_D, A_target, T_hot, Cd_jet,
                                   Nu_multiplier, f_multiplier);
      },
      py::arg("T"), py::arg("P"), py::arg("X"), py::arg("mdot_jet"),
      py::arg("d_jet"), py::arg("z_D"), py::arg("x_D") = 0.0,
      py::arg("y_D") = 0.0, py::arg("A_target"),
      py::arg("T_hot") = std::numeric_limits<double>::quiet_NaN(),
      py::arg("Cd_jet") = 0.65, py::arg("Nu_multiplier") = 1.0,
      py::arg("f_multiplier") = 1.0,
      "Impingement jet array cooling (Florschuetz et al. 1981 / Martin "
      "1977).\n\n"
      "Re and Nu are based on jet diameter d_jet.\n"
      "dP = (1/Cd_jet^2) * rho * v_jet^2 / 2  (jet-plate orifice loss)\n\n"
      "Parameters:\n"
      "  mdot_jet : total jet mass flow [kg/s]\n"
      "  d_jet    : jet hole diameter [m]\n"
      "  z_D      : jet-to-target distance / d_jet [-]  (valid: 1-12)\n"
      "  x_D      : streamwise jet spacing / d_jet [-]  (0 = single jet)\n"
      "  y_D      : spanwise jet spacing / d_jet [-]    (0 = single jet)\n"
      "  A_target : target surface area [m^2]\n"
      "  Cd_jet   : jet hole discharge coefficient [-]  (default 0.65)\n\n"
      "Returns: ChannelResult");

  // -----------------------------------------------------------------
  // pin_fin_friction (scalar, low-level)
  // -----------------------------------------------------------------
  m.def("pin_fin_friction", &combaero::cooling::pin_fin_friction,
        py::arg("Re_d"), py::arg("is_staggered") = true,
        "Pin-fin array pressure drop friction coefficient.\n\n"
        "For use in: dP = N_rows * f_pin * (rho * v_max^2 / 2)\n\n"
        "Parameters:\n"
        "  Re_d         : Reynolds number based on pin diameter [-]\n"
        "  is_staggered : True = staggered (default), False = inline\n\n"
        "Returns: friction coefficient f_pin [-]\n\n"
        "Source: Metzger et al. (1982), Simoneau & VanFossen (1984)");
  // -----------------------------------------------------------------
  // Internal Solver Tools (f, J) exact Jacobians
  // -----------------------------------------------------------------
  m.def("orifice_mdot_and_jacobian", &solver::orifice_mdot_and_jacobian,
        py::arg("dP"), py::arg("rho"), py::arg("Cd"), py::arg("area"),
        py::arg("beta") = 0.0,
        "Fast-path orifice flow and analytic derivative (mdot, "
        "d(mdot)/d(dP)).\n\n"
        "Parameters:\n"
        "  dP   : Pressure drop [Pa]\n"
        "  rho  : Density [kg/m³]\n"
        "  Cd   : Discharge coefficient [-]\n"
        "  area : Orifice area [m²]\n"
        "  beta : Diameter ratio beta = d/D [-] (default 0.0)\n\n"
        "Returns: tuple(mass_flow [kg/s], derivative [kg/(s*Pa)])");

  m.def("pressure_loss_and_jacobian", &solver::pressure_loss_and_jacobian,
        py::arg("v"), py::arg("rho"), py::arg("K"),
        "Fast-path K-factor pressure loss and analytic derivative (dP, "
        "d(dP)/d(v)).\n\n"
        "Parameters:\n"
        "  v   : Velocity [m/s]\n"
        "  rho : Density [kg/m³]\n"
        "  K   : Loss coefficient [-]\n\n"
        "Returns: tuple(dP [Pa], derivative [Pa/(m/s)])");

  m.def("lossless_pressure_and_jacobian",
        &solver::lossless_pressure_and_jacobian, py::arg("P_in"),
        py::arg("P_out"),
        "Calculate ideal lossless outlet pressure P_out = P_in and its "
        "Jacobian dP_out/dP_in.");

  // Heat Transfer (f, J) tuples
  m.def("nusselt_and_jacobian_dittus_boelter",
        &solver::nusselt_and_jacobian_dittus_boelter, py::arg("Re"),
        py::arg("Pr"), py::arg("heating") = true,
        "Calculate Nusselt number and its Jacobian w.r.t Re using "
        "Dittus-Boelter.");

  m.def("nusselt_and_jacobian_gnielinski",
        &solver::nusselt_and_jacobian_gnielinski, py::arg("Re"), py::arg("Pr"),
        py::arg("f"),
        "Calculate Nusselt number and its Jacobian w.r.t Re using Gnielinski.");

  m.def(
      "nusselt_and_jacobian_sieder_tate",
      &solver::nusselt_and_jacobian_sieder_tate, py::arg("Re"), py::arg("Pr"),
      py::arg("mu_ratio"),
      "Calculate Nusselt number and its Jacobian w.r.t Re using Sieder-Tate.");

  m.def("nusselt_and_jacobian_petukhov", &solver::nusselt_and_jacobian_petukhov,
        py::arg("Re"), py::arg("Pr"), py::arg("f"),
        "Calculate Nusselt number and its Jacobian w.r.t Re using Petukhov.");

  // Cooling Correlations (f, J) tuples
  m.def("pin_fin_nusselt_and_jacobian", &solver::pin_fin_nusselt_and_jacobian,
        py::arg("Re_d"), py::arg("Pr"), py::arg("L_D"), py::arg("S_D"),
        py::arg("X_D"), py::arg("is_staggered") = true,
        "Calculate Pin Fin Nusselt number and its Jacobian w.r.t Re_d.");

  m.def("pin_fin_friction_and_jacobian", &solver::pin_fin_friction_and_jacobian,
        py::arg("Re_d"), py::arg("is_staggered") = true,
        "Calculate Pin Fin Friction factor and its Jacobian w.r.t Re_d.");

  m.def("dimple_nusselt_enhancement_and_jacobian",
        &solver::dimple_nusselt_enhancement_and_jacobian, py::arg("Re_Dh"),
        py::arg("d_Dh"), py::arg("h_d"), py::arg("S_d"),
        "Calculate Dimple Nusselt enhancement and its Jacobian w.r.t Re_Dh.");

  m.def("dimple_friction_multiplier_and_jacobian",
        &solver::dimple_friction_multiplier_and_jacobian, py::arg("Re_Dh"),
        py::arg("d_Dh"), py::arg("h_d"),
        "Calculate Dimple Friction multiplier and its Jacobian w.r.t Re_Dh.");

  m.def("rib_enhancement_factor_high_re_and_jacobian",
        &solver::rib_enhancement_factor_high_re_and_jacobian, py::arg("e_D"),
        py::arg("pitch_to_height"), py::arg("alpha_deg"), py::arg("Re"),
        "Calculate Rib enhancement factor and its Jacobian w.r.t Re.");

  m.def("impingement_nusselt_and_jacobian",
        &solver::impingement_nusselt_and_jacobian, py::arg("Re_jet"),
        py::arg("Pr"), py::arg("z_D"), py::arg("x_D") = 0.0,
        py::arg("y_D") = 0.0,
        "Calculate Impingement Nusselt number and its Jacobian w.r.t Re_jet.");

  m.def("film_cooling_effectiveness_and_jacobian",
        &solver::film_cooling_effectiveness_and_jacobian, py::arg("x_D"),
        py::arg("M"), py::arg("DR"), py::arg("alpha_deg"),
        "Calculate Film cooling effectiveness and its Jacobian w.r.t Blowing "
        "Ratio M.");

  m.def("effusion_effectiveness_and_jacobian",
        &solver::effusion_effectiveness_and_jacobian, py::arg("x_D"),
        py::arg("M"), py::arg("DR"), py::arg("porosity"), py::arg("s_D"),
        py::arg("alpha_deg"),
        "Calculate Effusion effectiveness and its Jacobian w.r.t Blowing Ratio "
        "M.");

  // Stagnation (f, J) tuples
  m.def("mach_number_and_jacobian_v", &solver::mach_number_and_jacobian_v,
        py::arg("v"), py::arg("T"), py::arg("X"),
        "Calculate Mach number and its Jacobian w.r.t Velocity.");

  m.def(
      "T_adiabatic_wall_and_jacobian_v",
      &solver::T_adiabatic_wall_and_jacobian_v, py::arg("T_static"),
      py::arg("v"), py::arg("T"), py::arg("P"), py::arg("X"),
      py::arg("turbulent") = true,
      "Calculate Adiabatic Wall Temperature and its Jacobian w.r.t Velocity.");

  m.def("T0_from_static_and_jacobian_M", &solver::T0_from_static_and_jacobian_M,
        py::arg("T"), py::arg("M"), py::arg("X"),
        "Calculate Stagnation Temperature from Static and its Jacobian w.r.t "
        "Mach.");

  m.def(
      "P0_from_static_and_jacobian_M", &solver::P0_from_static_and_jacobian_M,
      py::arg("P"), py::arg("T"), py::arg("M"), py::arg("X"),
      "Calculate Stagnation Pressure from Static and its Jacobian w.r.t Mach.");

  m.def("friction_and_jacobian_haaland", &solver::friction_and_jacobian_haaland,
        py::arg("Re"), py::arg("e_D"),
        "Fast-path Haaland channel friction and analytic derivative (f, "
        "d(f)/d(Re)).\n\n"
        "Parameters:\n"
        "  Re  : Reynolds number [-]\n"
        "  e_D : Relative roughness eps/D [-]\n\n"
        "Returns: tuple(friction_factor [-], derivative [-])");

  m.def("friction_and_jacobian_serghides",
        &solver::friction_and_jacobian_serghides, py::arg("Re"), py::arg("e_D"),
        "Fast-path Serghides channel friction and analytic derivative (f, "
        "d(f)/d(Re)).\n\n"
        "Parameters:\n"
        "  Re  : Reynolds number [-]\n"
        "  e_D : Relative roughness eps/D [-]\n\n"
        "Returns: tuple(friction_factor [-], derivative [-])");

  m.def("friction_and_jacobian_colebrook",
        &solver::friction_and_jacobian_colebrook, py::arg("Re"), py::arg("e_D"),
        "Fast-path Colebrook-White channel friction and implicit derivative "
        "(f, "
        "d(f)/d(Re)).\n\n"
        "Parameters:\n"
        "  Re  : Reynolds number [-]\n"
        "  e_D : Relative roughness eps/D [-]\n\n"
        "Returns: tuple(friction_factor [-], derivative [-])");

  m.def("friction_and_jacobian_petukhov",
        &solver::friction_and_jacobian_petukhov, py::arg("Re"),
        "Fast-path Petukhov smooth-channel friction and analytic derivative "
        "(f, "
        "d(f)/d(Re)).\n\n"
        "Parameters:\n"
        "  Re : Reynolds number [-]\n\n"
        "Returns: tuple(friction_factor [-], derivative [-])");

  m.def("friction_and_jacobian", &solver::friction_and_jacobian, py::arg("tag"),
        py::arg("Re"), py::arg("e_D"),
        "Dispatcher: selects friction_and_jacobian_* by tag string.\n\n"
        "tag must be one of: 'haaland', 'serghides', 'colebrook', "
        "'petukhov'\n\n"
        "Parameters:\n"
        "  tag : friction model name\n"
        "  Re  : Reynolds number [-]\n"
        "  e_D : Relative roughness eps/D [-]\n\n"
        "Returns: tuple(friction_factor [-], d(f)/d(Re) [-])");

  m.def("density_and_jacobians", &solver::density_and_jacobians, py::arg("T"),
        py::arg("P"), py::arg("X"),
        "Fast-path density and analytic derivatives (rho, d(rho)/d(T), "
        "d(rho)/d(P)).\n\n"
        "Parameters:\n"
        "  T : Temperature [K]\n"
        "  P : Pressure [Pa]\n"
        "  X : Mole fractions [-]\n\n"
        "Returns: tuple(rho [kg/m³], d_rho_d_T [(kg/m³)/K], d_rho_d_P "
        "[(kg/m³)/Pa])");

  m.def("enthalpy_and_jacobian", &solver::enthalpy_and_jacobian, py::arg("T"),
        py::arg("X"),
        "Fast-path enthalpy and analytic derivative (h, d(h)/d(T)).\n\n"
        "Parameters:\n"
        "  T : Temperature [K]\n"
        "  X : Mole fractions [-]\n\n"
        "Returns: tuple(h [J/kg], cp_mass [J/(kg*K)])");

  m.def("viscosity_and_jacobians", &solver::viscosity_and_jacobians,
        py::arg("T"), py::arg("P"), py::arg("X"),
        "Fast-path viscosity and central difference derivatives (mu, "
        "d(mu)/d(T), d(mu)/d(P)).\n\n"
        "Parameters:\n"
        "  T : Temperature [K]\n"
        "  P : Pressure [Pa]\n"
        "  X : Mole fractions [-]\n\n"
        "Returns: tuple(mu [Pa*s], d_mu_d_T [(Pa*s)/K], d_mu_d_P "
        "[(Pa*s)/Pa])");

  m.def(
      "equivalence_ratio",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> X_arr) {
        return equivalence_ratio(to_vec(X_arr));
      },
      py::arg("X"),
      "Calculate the equivalence ratio (phi) of a mixture based on its "
      "elemental composition.\n\n"
      "Phi = O2_required / O2_available\n\n"
      "Parameters:\n"
      "  X : Mole fractions [-]\n\n"
      "Returns: Phi [-]");

  m.def(
      "equivalence_ratio_mass",
      [](py::array_t<double, py::array::c_style | py::array::forcecast> Y_arr) {
        return equivalence_ratio_mass(to_vec(Y_arr));
      },
      py::arg("Y"),
      "Calculate the equivalence ratio (phi) of a mixture based on its "
      "elemental composition (mass basis).\n\n"
      "Parameters:\n"
      "  Y : Mass fractions [-]\n\n"
      "Returns: Phi [-]");

  m.def("adiabatic_T_complete_and_jacobian_T",
        &solver::adiabatic_T_complete_and_jacobian_T, py::arg("T_in"),
        py::arg("P"), py::arg("X_in"),
        "Fast-path adiabatic flame temperature (complete combustion) and "
        "analytic derivative.\n\n"
        "Parameters:\n"
        "  T_in : Inlet Temperature [K]\n"
        "  P    : Pressure [Pa]\n"
        "  X_in : Inlet Mole fractions [-]\n\n"
        "Returns: tuple(T_ad [K], dT_ad_dT_in [-], X_products [-])");

  m.def("adiabatic_T_equilibrium_and_jacobians",
        &solver::adiabatic_T_equilibrium_and_jacobians, py::arg("T_in"),
        py::arg("P"), py::arg("X_in"),
        "Fast-path adiabatic flame temperature (equilibrium combustion) and "
        "analytic derivatives.\n\n"
        "Parameters:\n"
        "  T_in : Inlet Temperature [K]\n"
        "  P    : Pressure [Pa]\n"
        "  X_in : Inlet Mole fractions [-]\n\n"
        "Returns: tuple(T_ad [K], dT_ad_dT_in [-], dT_ad_dP [K/Pa], X_products "
        "[-])");

  // Registry bindings
  py::class_<Registry>(m, "Registry",
                       "Global function registry for C++ physics models")
      .def_static("get", &Registry::get, py::return_value_policy::reference,
                  "Get the singleton registry instance")
      .def("has_friction_model", &Registry::has_friction_model, py::arg("name"),
           "Check if friction model is registered")
      .def("available_friction_models", &Registry::available_friction_models,
           "List all available friction models");
}
