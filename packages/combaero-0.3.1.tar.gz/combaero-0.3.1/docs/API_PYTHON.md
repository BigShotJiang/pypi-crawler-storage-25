# CombAero Python API Reference

This document provides the high-level reference for the `combaero` Python package. For the C++ technical reference, see [API_CPP.md](API_CPP.md).

## Table of Contents
- [Core Thermodynamics](#core-thermodynamics)
- [Combustion & Equilibrium](#combustion--equilibrium)
- [Flow Regimes (Symmetric API)](#flow-regimes-symmetric-api)
- [Advanced Flow Functions](#advanced-flow-functions)
- [Comprehensive Orifice Functions](#comprehensive-orifice-functions)
- [Heat Transfer](#heat-transfer)
  - [Correlations](#correlations)
  - [Network Heat Transfer](#network-heat-transfer)
- [Acoustics](#acoustics)
- [Network Solver](#network-solver)
- [NetworkRunner (GUI-JSON Programmatic Driver)](#networkrunner-gui-json-programmatic-driver)
- [Geometry & Materials](#geometry--materials)
- [Advanced Thermodynamics](#advanced-thermodynamics)
- [Psychrometrics (Humid Air)](#psychrometrics-humid-air)

---

## Core Thermodynamics

### State Object
The `State` object is the central data structure, managing T [K], P [Pa], and composition.

```python
import combaero as cb

state = cb.State()
state.TPX = (300.0, 101325.0, "O2:0.21, N2:0.79")
# OR setting mass fractions directly
state.Y = y_vector

print(f"Mole fractions: {state.X}")
print(f"Mass fractions: {state.Y}")

print(f"Density: {state.rho} kg/m³")
print(f"Enthalpy: {state.h} J/mol")
print(f"Viscosity: {state.mu} Pa·s")
```

### MixtureState (Network Data)
The `MixtureState` struct is used for network node properties and carries both static and stagnation conditions.
**Units**: P [Pa], T [K], m_dot [kg/s].

```python
# Constructor: MixtureState(P, P_total, T, T_total, m_dot, Y)
node_state = cb.MixtureState(1e5, 1.1e5, 300, 300, 1.5, y_vec)

print(node_state.P)       # Static [Pa]
print(node_state.m_dot)   # Mass flow [kg/s]
print(node_state.density()) # Static density [kg/m³]
```

### Species Module
The `combaero.species` module provides high-level helpers for composition vectors.

```python
import combaero as cb

# Get standard compositions (returns numpy array)
X_air = cb.species.dry_air()        # Mole fractions
Y_air = cb.mole_to_mass(X_air)   # Mass fractions (standard for network)

# Humid air at T [K], P [Pa], RH [0-1]
Y_humid = cb.species.humid_air_mass(300, 101325, 0.5)

# Pure species or from mapping
Y_ch4 = cb.species.pure_species("CH4")
Y_mix = cb.species.from_mapping({"O2": 0.20, "N2": 78, "AR": 0.02})

# Explicit conversion
Y = cb.species.to_mass(X_air)
X = cb.species.to_mole(Y_air)
```

### Species Lookup (Legacy)
```python
# Low-level metadata from core
num = cb.num_species()
name = cb.species_name(0)
idx = cb.species_index_from_name("H2O")
```

---

## Combustion & Equilibrium

### Complete Combustion
```python
# ADIABATIC flame temperature and products
# smooth=True ensures a continuous Jacobian for root-finding near Phi=0
burned = cb.complete_combustion(state, smooth=True)
print(f"Adiabatic T: {burned.T} K")

# Isothermal products
products = cb.complete_combustion_isothermal(state, smooth=True)
```

### Chemical Equilibrium
```python
# T, P constant equilibrium
eq_state = cb.combustion_equilibrium(state, smooth=True)

# Water-gas shift
wgs = cb.wgs_equilibrium(state)
```

---

## Flow Regimes (Symmetric API)

CombAero provides symmetric submodules for incompressible and compressible flow.

```python
from combaero import incompressible as flow   # OR: from combaero import compressible as flow

sol = flow.channel_flow(T=400, P=2e5, X=air, u=10.0, L=2.0, D=0.05, f=0.02)
print(f"Pressure drop: {sol.dP} Pa")
print(f"Outlet Mach: {sol.M}") # nan for incompressible
```

### FlowSolution Fields
- `mdot`: Mass flow rate [kg/s]
- `v`: bulk velocity [m/s]
- `dP`: Pressure drop [Pa]
- `M`: Mach number
- `choked`: Boolean flag

---

## Advanced Flow Functions

### Inverse Solvers
```python
# Solve for unknown given mass flow rate
A_eff = cb.solve_A_eff_from_mdot(T0=300, P0=2e5, P_back=1e5, mdot_target=0.1, X=air)
P_back = cb.solve_P_back_from_mdot(T0=300, P0=2e5, A_eff=1e-4, mdot_target=0.1, X=air)
P0 = cb.solve_P0_from_mdot(T0=300, P_back=1e5, A_eff=1e-4, mdot_target=0.1, X=air)
```

### Utility Functions
```python
# Critical pressure ratio and Mach number
P_crit_ratio = cb.critical_pressure_ratio(T0=300, P0=2e5, X=air)
Mach = cb.mach_from_pressure_ratio(T0=300, P0=2e5, P=1.5e5, X=air)

# Mass flux and flow analysis
G = cb.mass_flux_isentropic(T0=300, P0=2e5, P=1.5e5, X=air)
L_max = cb.fanno_max_length(T_in=300, P_in=2e5, u_in=50, D=0.05, f=0.02, X=air)
```

### Rocket Nozzle Functions
```python
# Converging-diverging nozzle analysis
sol = cb.nozzle_cd(T0=300, P0=2e5, P_design=1e5, P_amb=101325,
                   A_inlet=1e-3, A_throat=5e-4, A_exit=2e-3,
                   x_throat=0.1, x_exit=0.2, X=air)

# Thrust calculations
thrust = cb.nozzle_thrust_cd(T0=300, P0=2e5, P_design=1e5, P_amb=101325,
                             A_inlet=1e-3, A_throat=5e-4, A_exit=2e-3,
                             x_throat=0.1, x_exit=0.2, X=air)
print(f"Thrust: {thrust.thrust} N")
print(f"Specific impulse: {thrust.specific_impulse} s")
```

---

## Comprehensive Orifice Functions

### Discharge Coefficient Correlations
```python
# Individual correlations
Cd = cb.Cd_sharp_thin_plate(geom, state)
Cd = cb.Cd_thick_plate(geom, state)
Cd = cb.Cd_rounded_entry(geom, state)

# Auto-selection based on geometry
Cd = cb.Cd_orifice(geom, state)
```

### Geometry and Flow Analysis
```python
# Area calculations
area = cb.orifice_area(d=0.01)
area = cb.orifice_area_from_beta(beta=0.5, D=0.02)

# Cd-K conversions
K = cb.orifice_K_from_Cd(Cd=0.65)
Cd = cb.orifice_Cd_from_K(K=0.5)

# Flow state analysis
state = cb.orifice_flow_state(P1=2e5, P2=1e5, rho=1.2, mu=1.8e-5, d=0.01, D=0.02)
Re_d = cb.orifice_Re_d_from_mdot(mdot=0.1, d=0.01, mu=1.8e-5)
```

### Advanced Flow Functions
```python
# Thermodynamic orifice flow
sol = cb.orifice_flow_thermo(T=300, P=2e5, X=air, m_dot=0.1, area=1e-4, Cd=0.65)

# Impedance with flow effects
Z = cb.orifice_impedance_with_flow(mdot=0.1, area=1e-4, Cd=0.65, rho=1.2, c=340)

# Thickness corrections
Cd_corrected = cb.orifice_thickness_correction(Cd=0.65, t_over_d=0.1)
```

### Pressure and Flow Calculations
```python
# Pressure drop
dP = cb.orifice_dP(mdot=0.1, area=1e-4, Cd=0.65, rho=1.2)
dP = cb.orifice_dP_Cd(mdot=0.1, area=1e-4, Cd=0.65, rho=1.2)

# Mass flow
mdot = cb.orifice_mdot(P1=2e5, P2=1e5, area=1e-4, Cd=0.65, rho=1.2)
mdot = cb.orifice_mdot_Cd(P1=2e5, P2=1e5, area=1e-4, Cd=0.65, rho=1.2)

# Velocity and heat transfer
v = cb.orifice_velocity(mdot=0.1, area=1e-4, rho=1.2)
v = cb.orifice_velocity_from_mdot(mdot=0.1, area=1e-4, rho=1.2)
Q = cb.orifice_Q(mdot=0.1, h1=3e5, h2=2.8e5)
```

---

## Heat Transfer

### Correlations
```python
Nu = cb.nusselt_gnielinski(Re=1e5, Pr=0.7)
h = cb.htc_from_nusselt(Nu, k=0.026, L=0.05)

# Multi-layer wall temperature profile
temps, q = cb.wall_temperature_profile(T_hot=1200, T_cold=300, h_hot=200, h_cold=20, t_over_k=[0.01/50, 0.05/0.5])
```

### Network Heat Transfer

#### ConvectiveSurface
Defines convective heat transfer properties on network elements. Supports different channel models.

```python
from combaero.heat_transfer import ConvectiveSurface, SmoothModel, RibbedModel, DimpledModel, PinFinModel, ImpingementModel

# Smooth channel with Gnielinski correlation (default)
surface = ConvectiveSurface(
    area=np.pi * 0.04 * 1.0,  # Surface area [m²]
    model=SmoothModel(correlation="gnielinski")
)

# Ribbed surface with geometry parameters
ribbed = ConvectiveSurface(
    area=2.5,
    model=RibbedModel(
        e_D=0.05,      # Rib height / hydraulic diameter
        p_e=10.0,     # Pitch / height
        w_e=0.5,      # Rib width / height
        correlation="gnielinski"
    )
)

# Pin fin array
pin_fin = ConvectiveSurface(
    area=3.0,
    model=PinFinModel(
        L_H=1.0,       # Fin height / hydraulic diameter
        S_H=2.0,       # Spanwise spacing / height
        S_L=2.0,       # Streamwise spacing / height
        t_D=0.1,       # Fin thickness / diameter
        correlation="gnielinski"
    )
)
```

#### WallConnection
Thermal coupling between two network elements through a shared wall.

```python
from combaero.heat_transfer import WallConnection

# Couple hot and cold channels through a wall
wall = WallConnection(
    id="coupling_wall",
    element_a="hot_channel",      # First element ID
    element_b="cold_channel",     # Second element ID
    wall_thickness=0.002,      # Wall thickness [m]
    wall_conductivity=25.0,    # Wall thermal conductivity [W/(m·K)]
    contact_area=None          # Optional: override surface area
)

# Add to network
network.add_wall(wall)
```

#### Element Integration
Elements with convective surfaces support heat transfer calculations.

```python
from combaero.network import ChannelElement

# Channel with convective heat transfer
channel = ChannelElement(
    id="heated_channel",
    from_node="inlet",
    to_node="outlet",
    diameter=0.04,
    length=1.0,
    roughness=0.0,
    surface=surface  # ConvectiveSurface instance
)

# Get heat transfer coefficient and temperature
h, T = channel.htc_and_T(state)  # Returns (htc [W/(m²·K)], T [K])
```

#### Thermal Coupling Toggle
Enable/disable thermal coupling globally for debugging or fast solves.

```python
network = FlowNetwork()
network.thermal_coupling_enabled = True   # Enable wall heat transfer
network.thermal_coupling_enabled = False  # Disable (faster, no heat transfer)
```

---

## Acoustics

```python
# Acoustic properties bundle
props = cb.acoustic_properties(f=1000, rho=1.2, c=340, p_rms=1.0)
print(f"SPL: {props.spl} dB")

# Cavity resonators
f_helm = cb.helmholtz_frequency(V=0.001, A_neck=1e-4, L_neck=0.01, c=340)

# Duct modes
tube = cb.Tube(L=1.0, D=0.1)
modes = cb.tube_axial_modes(tube, c=340, bc1=cb.BoundaryCondition.Closed, bc2=cb.BoundaryCondition.Open)
```

---

## Programmatic Network Design

For automated design and agents, `combaero.network` provides a pure-Python interface to build and solve networks without the GUI.

```python
from combaero.network import FlowNetwork, NetworkSolver, OrificeElement, PressureBoundary, PlenumNode
import combaero.species as species

# 1. Initialize Network
net = FlowNetwork()

# 2. Define Boundaries & Nodes
net.add_node(PressureBoundary("inlet", P_total=5e5, T_total=400, Y=species.dry_air_mass()))
net.add_node(PlenumNode("plenum", P=4e5, T=400))
net.add_node(PressureBoundary("outlet", P_total=1e5, T_total=300))

# 3. Add Elements
net.add_element(OrificeElement("feed", "inlet", "plenum", diameter=0.01, Cd=0.65))
net.add_element(OrificeElement("exhaust", "plenum", "outlet", diameter=0.015, Cd=0.62))

# 4. Solve
solver = NetworkSolver(net)
results = solver.solve(method="hybr")

# 5. Access Results
print(f"Plenum Pressure: {results.nodes['plenum'].P} Pa")
print(f"System Mass Flow: {results.elements['feed'].m_dot} kg/s")
```

> [!TIP]
> **Agent Hint**: Use `net.to_dict()` to get a JSON-serializable representation of the network, which can be saved or sent to the GUI.

---

## Network Solver

### Basic Usage
```python
from combaero.network import FlowNetwork, NetworkSolver, OrificeElement

graph = FlowNetwork()
graph.add_element(OrificeElement("ori1", "nodeA", "nodeB", Cd=0.6, diameter=0.011284))

solver = NetworkSolver(graph)
# init_strategy options: "default", "incompressible_warmstart", "homotopy"
results = solver.solve(method="hybr", init_strategy="homotopy")
```

### Network Nodes
```python
from combaero.network import (
    PressureBoundary, MassFlowBoundary, PlenumNode,
    CombustorNode, MomentumChamberNode, MomentumBoundary, EnergyBoundary
)

# Boundary conditions
inlet = PressureBoundary("inlet", P_total=2e5, T_total=300)
outlet = PressureBoundary("outlet", P_total=1e5, T_total=300)
mass_in = MassFlowBoundary("mass_in", m_dot=0.1, T_total=400, Y=air)
mom_in = MomentumBoundary("mom_in", P_total=2e5, T_total=300, area=1e-4)

# Internal nodes
junction = PlenumNode("junction", P=1.5e5, T=350, Y=air)
combustor = CombustorNode("combustor", P=2e5, T=1800, Y=products)
momentum = MomentumChamberNode("momentum", P=2e5, T=1800, Y=products, regime="compressible")
energy = EnergyBoundary("energy", Q=50000)  # Heat addition [W]
```

### Network Elements
```python
from combaero.network import (
    OrificeElement, ChannelElement, EffectiveAreaConnectionElement,
    LosslessConnectionElement, DiameterDischargeCoefficientConnectionElement,
    TeeJunctionElement, VortexElement,
)

# Flow elements
orifice = OrificeElement("orifice", "node1", "node2", Cd=0.65, diameter=0.011284, regime="compressible")
channel = ChannelElement("channel", "node2", "node3", length=2.0, diameter=0.05, roughness=1e-4, regime="compressible")

# Connection elements
effective_area = EffectiveAreaConnectionElement("ea", "node3", "node4", diameter=0.015958)
lossless = LosslessConnectionElement("lossless", "node4", "node5")
area_cd = DiameterDischargeCoefficientConnectionElement("area_cd", "node5", "node6", diameter=0.011284, Cd=0.7)

# Three-port tee junction (Bassett 2001 pressure-loss model)
import math
# Merging tee: two inlets (straight_node, branch_node) -> one outlet (common_node)
tee_merge = TeeJunctionElement(
    "tee", common_node="outlet", straight_node="inlet_s", branch_node="inlet_b",
    theta=math.pi / 2.0, F_C=0.01, psi=1.0, tee_type="merging",
)
# Branching tee: one inlet (common_node) -> two outlets (straight_node, branch_node)
tee_branch = TeeJunctionElement(
    "tee", common_node="inlet", straight_node="outlet_s", branch_node="outlet_b",
    theta=math.pi / 2.0, F_C=0.01, psi=1.0, tee_type="branching",
)
# Solved unknowns: tee.m_dot_com (total), tee.m_dot_branch (branch arm)
# Straight flow is implicit: m_dot_straight = m_dot_com - m_dot_branch

# Rotating cavity / disc-pump pressure rise (Vatistas n-vortex model)
vortex = VortexElement(
    "vortex", "node_in", "node_out",
    r_c=0.02,       # vortex core radius [m]
    r_out=0.10,     # outer evaluation radius [m]
    r_in=0.0,       # inner evaluation radius [m] (0 = on-axis)
    omega_rpm=3000, # shaft speed [rpm]
    n=2.0,          # Vatistas shape parameter (>= 1, default n=2)
)
# Residual: Pt_out - Pt_in - dP_vortex = 0
# dP_vortex = vatistas_delta_p(r_out, ...) - vatistas_delta_p(r_in, ...)
# Gamma is derived from omega so that V_theta(r_c) = omega * r_c exactly (solid-body core).
# Diagnostics include: m_dot, omega_rpm, dP_vortex [Pa], Pt_in, Pt_out.
# If omega_rpm=0 the element is lossless (transparent); r_in=0 omits the on-axis term.
```

### Combustion Integration
```python
from combaero.network.combustion import (
    combustion_from_streams, combustion_from_phi, mix_streams, stoichiometric_products
)

# Create combustion from streams
fuel_stream = cb.Stream(m_dot=0.01, T=300, P_total=2e5, Y=fuel_y)
oxidizer_stream = cb.Stream(m_dot=0.2, T=300, P_total=2e5, Y=air_y)

result = combustion_from_streams([fuel_stream, oxidizer_stream], phi=1.0)
print(f"Products: {result.products.Y}")
print(f"Adiabatic T: {result.T_ad} K")

# Or from equivalence ratio
result = combustion_from_phi(phi=0.8, T=300, P=2e5, fuel="CH4", oxidizer="air")
```

### MixtureState for Network Data
```python
from combaero.network import MixtureState

# Constructor: MixtureState(P, P_total, T, T_total, m_dot, Y)
node_state = MixtureState(1e5, 1.1e5, 300, 300, 1.5, air_vec)

print(f"Static pressure: {node_state.P} Pa")
print(f"Total pressure: {node_state.P_total} Pa")
print(f"Mass flow: {node_state.m_dot} kg/s")
print(f"Static density: {node_state.density()} kg/m³")
```

### Advanced (f, J) Interface
High-accuracy analytical Jacobians are available for performance-critical solver loops.
```python
# Exact residuals and derivatives wrt (P_tot, P_static, T, Y)
res_ori = cb.orifice_residuals_and_jacobian(m_dot, P_tot, P_stat, T, Y, P_down, Cd, area)
res_chan = cb.channel_residuals_and_jacobian(m_dot, P_tot, P_stat, T, Y, P_down, L, D, roughness, correlation)
res_comb = cb.combustor_residuals_and_jacobians(m_dot, P_tot, P_stat, T, Y, Q_comb, method, smooth, pressure_loss_func)
res_plen = cb.plenum_residuals_and_jacobian(m_dot_vec, P_target, T_target, Y_target)
```

Combustor results return mapping specific to `(m_dot, P_total, T, Y)` state vectors.

### Tee Junction Interface
Bassett 2001 tee junction K-factor model with full Jacobians for the network solver.

Port convention: MAIN_INLET (A), BRANCH (B), MAIN_OUTLET (C).
`m_dot_com` = common-port mass flow [kg/s], `m_dot_branch` = branch mass flow [kg/s],
`F_C` = common-port cross-sectional area [m^2], `psi` = A_branch/A_com, `theta` = branch angle [rad].

```python
import combaero._core as _core
import math

Y = [0.0] * 15
Y[0] = 0.767  # N2
Y[1] = 0.233  # O2

# Check input validity (non-throwing)
status = _core.tee_check_inputs(q=0.5, psi=1.0, theta=math.pi/2)
# status.valid, status.q_in_range, status.psi_valid, status.theta_valid

# Raw K-coefficient functions (Bassett 2001)
k5  = _core.tee_K5(q)               # straight arm, separating tee
k6  = _core.tee_K6(q, psi, theta)   # branch arm, separating tee
k11 = _core.tee_K11(q, psi, theta)  # straight arm, joining tee
k12 = _core.tee_K12(q, psi, theta)  # branch arm, joining tee

# Blended K functions (always finite, smooth at q=0 and across topology reversal)
ks = _core.merging_tee_K_straight(q, psi, theta)
kb = _core.merging_tee_K_branch(q, psi, theta)

# Solver residuals and full Jacobians
res = _core.merging_tee_residuals_and_jacobian(
    m_dot_com=0.5, m_dot_branch=0.2,
    dP0_straight=150.0, dP0_branch=200.0,
    P_static_com=2e5, T_com=600.0, Y_com=Y,
    theta=math.pi/2, psi=1.0, F_C=0.01,
)
# res.R_straight, res.R_branch
# res.dR_straight_d_mdot_com, res.dR_straight_d_mdot_branch
# res.dR_straight_dP_static_com, res.dR_straight_dT_com
# res.topology_valid, res.status  (CorrelationValidity.VALID or EXTRAPOLATED)

res = _core.branching_tee_residuals_and_jacobian(
    m_dot_com=0.5, m_dot_branch=0.15,
    dP0_straight=100.0, dP0_branch=180.0,
    P_static_com=1.5e5, T_com=500.0, Y_com=Y,
    theta=math.pi/3, psi=1.2, F_C=0.008,
)
```

---

## Vatistas n-Vortex Model

Reference: Vatistas, Kozel, Mih (1991), *Exp. Fluids* 11, 73–76.

Shape parameter `n >= 1` (default 2.0). `n=2` gives the best fit to most
experimental swirl data.  Closed-form antiderivatives for the pressure integral
are used for `n=1` and `n=2`; composite Simpson quadrature for general `n`.
All Jacobians are analytical.

### Free functions

```python
import combaero as cb

# Normalised shape functions (no units, r_bar = r / r_c)
v0   = cb.vatistas_v0_bar(r_bar, n)           # tangential velocity shape
dv0  = cb.vatistas_dv0_bar_drbar(r_bar, n)    # d(V0_bar)/d(r_bar)
vr   = cb.vatistas_vr_bar(r_bar, n)           # radial velocity shape (< 0)
dvr  = cb.vatistas_dvr_bar_drbar(r_bar, n)    # d(Vr_bar)/d(r_bar)
I    = cb.vatistas_pressure_integral(r_bar, n) # integral_0^r V0^2/r' dr'
dI   = cb.vatistas_d_pressure_integral_drbar(r_bar, n)  # V0_bar^2/r_bar (FTC)

# Dimensional functions (Gamma [m^2/s], r_c [m], rho [kg/m^3])
Vt   = cb.vatistas_v_theta(r, Gamma, r_c, n)  # [m/s]
Vt, dVt_dr, dVt_dG, dVt_drc = cb.vatistas_v_theta_and_jacobians(r, Gamma, r_c, n)

dP   = cb.vatistas_delta_p(r, rho, Gamma, r_c, n)  # P(r)-P(0) [Pa]
dP, ddP_dr, ddP_dG, ddP_drc = cb.vatistas_delta_p_and_jacobians(r, rho, Gamma, r_c, n)
```

### `VatistasVortex` class

```python
import numpy as np
import combaero as cb

vortex = cb.VatistasVortex(Gamma=0.5, r_c=0.05, n=2.0)

r = np.linspace(0, 0.2, 200)
V  = vortex.V_theta(r)          # [m/s], vectorised
dV = vortex.dV_theta_dr(r)      # [1/s], vectorised

Vmax = vortex.V_theta_max()     # peak tangential velocity at r = r_c

dP   = vortex.delta_P(r=0.1, rho=1.2)    # [Pa], scalar
dPbar = vortex.delta_P_bar(r=0.1)        # normalised [0, 1)
```

---

## NetworkRunner (GUI-JSON Programmatic Driver)

`NetworkRunner` loads a network saved from the GUI and runs it from Python
scripts or Jupyter notebooks — no web server required.

### Loading a network

```python
from gui.backend.runner import NetworkRunner

# From a file downloaded from the GUI
runner = NetworkRunner.from_file("my_network.json")

# From an already-loaded dict (normalises GUI camelCase keys automatically)
import json
with open("my_network.json") as f:
    runner = NetworkRunner.from_dict(json.load(f))
```

Node labels are read from the GUI's label field.  If a node has no label the
node ID is used as the fallback key for overrides and result lookup.

### Single solve with boundary-condition overrides

```python
# Override format: "<label>.<attribute>": value
result = runner.solve({
    "air_inlet.m_dot": 1.2,   # kg/s
    "air_inlet.Tt": 650.0,    # K
    "outlet.Pt": 200_000.0,   # Pa
})

print(result.success, result.final_norm)

# Scalar result by label.quantity (resolves label → node ID automatically)
T_combustor = result.get("combustor.T")         # K
phi          = result.get("combustor.phi")
m_dot_out    = result.get("hot_channel.m_dot")  # kg/s

# Full thermodynamic state dict for a node
state = result.node_state("combustor")
# {"T": 1738.0, "P": 195000.0, "Pt": 200000.0, "Tt": 1760.0, ...}

# Full-detail DataFrame (matches GUI CSV export, unit-annotated columns)
df = result.to_dataframe()
```

### Parametric sweep

```python
import pandas as pd

params = pd.DataFrame({
    "fuel_inlet.m_dot": [0.020, 0.025, 0.030, 0.035],
})

# Compact: one row per solve, only requested metrics
sweep_df = runner.sweep(params, metrics=["combustor.T", "combustor.phi"])
# columns: fuel_inlet.m_dot | combustor.T | combustor.phi | success | final_norm

# Full detail: complete to_dataframe() output for each solve, stacked
full_df = runner.sweep(params)
# columns: _sweep_index | fuel_inlet.m_dot | <all entity columns> | success | final_norm
```

### Injecting labels for unlabelled networks

GUI exports may omit node labels.  Inject them before constructing the runner:

```python
import json

with open("network.json") as f:
    schema = json.load(f)

label_map = {
    "node_1778698958490": "air_inlet",
    "node_1778698961265": "fuel_inlet",
    "node_1778699014636": "combustor",
}
for node in schema["nodes"]:
    if node["id"] in label_map:
        node["data"]["label"] = label_map[node["id"]]

runner = NetworkRunner.from_dict(schema)
```

### NetworkResult attributes

| Attribute | Type | Description |
|---|---|---|
| `success` | `bool` | True when solver converged |
| `message` | `str` | Human-readable solver status |
| `final_norm` | `float \| None` | Residual norm at convergence |

| Method | Returns | Description |
|---|---|---|
| `get(key)` | `float` | Scalar by `<id>.<qty>` or `<label>.<qty>` |
| `node_state(label)` | `dict` | Full state dict for a node |
| `to_dataframe()` | `DataFrame` | Unit-annotated full-detail export |
| `swap_boundary(label, new_type)` | `NetworkRunner` | Retype a boundary node (mass ↔ pressure) and return a new runner pre-seeded with the full solved state |

### Boundary condition swap

```python
result = runner.solve({"air_inlet.m_dot": 1.0})

# Re-run the same point with a pressure BC (Pt auto-populated from solved state)
p_runner = result.swap_boundary("air_inlet", "pressure_boundary")
result2 = p_runner.solve()  # starts from solved state, converges immediately

# Sweep inlet pressure around the design point
import pandas as pd, numpy as np
design_Pt = result.node_state("air_inlet")["Pt"]
params = pd.DataFrame({"air_inlet.Pt": design_Pt * np.linspace(0.90, 1.10, 11)})
sweep_df = p_runner.sweep(params, metrics=["combustor.T"])
```

Only `mass_boundary` ↔ `pressure_boundary` swaps are supported.  The returned
runner carries the full solved state (pressures, flows, junction states) as a
warm start so `solve()` requires no additional `init_strategy`.

---

## Geometry & Materials

### Geometry Classes
```python
# Basic geometry
tube = cb.Tube(L=1.0, D=0.1)
annulus = cb.Annulus(R_outer=0.1, R_inner=0.05)

# Can-annular geometry
can_geo = cb.CanAnnularFlowGeometry(
    N_cans=12, R_can=0.05, L_can=0.3,
    R_annulus_inner=0.06, R_annulus_outer=0.1
)
```

### Material Properties
```python
# List available materials
materials = cb.list_materials()

# Thermal conductivity [W/(m·K)]
k_al = cb.k_aluminum_6061
k_ss = cb.k_stainless_steel_316
k_inconel = cb.k_inconel718
k_haynes = cb.k_haynes230
k_tbc = cb.k_tbc_ysz
```

### Advanced Geometry Functions
```python
# Annular areas
area_ann = cb.annular_area(R_outer=0.1, R_inner=0.05)

# Residence times
t_res = cb.residence_time(V=0.01, Q=0.1)
t_res_ann = cb.residence_time_annulus(V=0.01, Q=0.1, R_outer=0.1, R_inner=0.05)
t_res_can = cb.residence_time_can_annular(V=0.01, Q=0.1, N_cans=12, R_can=0.05)
```

### Pin Fin Heat Transfer
```python
# Pin fin correlations
Nu_pin = cb.pin_fin_nusselt(Re=1e4, Pr=0.7, height=0.01, diameter=0.001)
f_pin = cb.pin_fin_friction(Re=1e4, height=0.01, diameter=0.001, spacing=0.02)
```

---

## Advanced Thermodynamics

### Complete State Functions
```python
# Air properties bundle
air = cb.air_properties(T=300, P=101325, humidity=0.0)
print(f"Density: {air.density} kg/m³")
print(f"Viscosity: {air.viscosity} Pa·s")
print(f"Thermal conductivity: {air.thermal_conductivity} W/(m·K)")

# Complete thermodynamic state
thermo = cb.thermo_state(T=300, P=101325, X=air)
complete = cb.complete_state(T=300, P=101325, X=air)
```

### Derivatives
```python
# Temperature derivatives
dh_dT = cb.dh_dT(T=300, X=air)
ds_dT = cb.ds_dT(T=300, X=air)
dcp_dT = cb.dcp_dT(T=300, X=air)
dg_dT = cb.dg_over_RT_dT(T=300, X=air)
```

### Advanced Inverse Solvers
```python
# Molar-basis inverses (targets in J/mol or J/(mol*K))
T_from_h   = cb.calc_T_from_h(h_target=3e5, X=air)            # J/mol -> K
T_from_s   = cb.calc_T_from_s(s_target=7000, P=101325, X=air) # J/(mol*K), Pa -> K
T_from_cp  = cb.calc_T_from_cp(cp_target=29, X=air)           # J/(mol*K) -> K
T_from_u   = cb.calc_T_from_u(u_target=2.2e5, X=air)          # J/mol -> K

# Mass-specific inverses (targets in J/kg or J/(kg*K))
T_from_h_m = cb.calc_T_from_h_mass(h_mass_target=3e5, X=air)
T_from_s_m = cb.calc_T_from_s_mass(s_mass_target=7000, P=101325, X=air)
T_from_u_m = cb.calc_T_from_u_mass(u_mass_target=2.2e5, X=air)

# Flash calculations — solve T from two independent properties
T_from_sv  = cb.calc_T_from_sv_mass(s_mass_target=7000, v_mass_target=0.8, X=air)
T_from_sh  = cb.calc_T_from_sh_mass(s_mass_target=7000, h_mass_target=3e5, X=air)
```

### Flow Analysis
```python
# Bulk velocity and kinetic energy
v = cb.bulk_velocity(m_dot=0.5, rho=1.2, area=1e-3)   # m/s
KE = cb.kinetic_energy(v=v)                             # J/kg

# Dimensionless numbers
# From full mixture state (recomputes rho, mu internally):
Re = cb.reynolds(T=300, P=101325, X=air, V=v, L=0.05)
# From pre-computed state properties (use when CompleteState is available):
Re = cb.reynolds_from_state(rho=1.2, v=v, L=0.05, mu=1.8e-5)

# Stagnation conditions from static state and velocity
Tt, Pt = cb.stagnation_from_static(T=300, P=101325, v=v, X=air)  # (K, Pa)
```

---

## Psychrometrics (Humid Air)

```python
air = cb.HumidAir()
air.set_TP_RH(300.0, 101325.0, 0.5)

print(f"Humidity ratio: {air.humidity_ratio} kg/kg")
print(f"Dewpoint: {air.dewpoint} K")
print(f"Underlying state P: {air.state.P} Pa")
```
