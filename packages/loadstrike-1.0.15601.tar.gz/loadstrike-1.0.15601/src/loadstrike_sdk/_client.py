from __future__ import annotations

import json
import base64
import hashlib
import os
import re
import socket
import threading
import time
import platform
import subprocess
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple, Union
from urllib.parse import quote
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from .contracts import LoadStrikeRunRequest, LoadStrikeRunResponse
from .correlation import (
    CorrelationReportRegistry,
    CorrelationReportRow,
    CrossPlatformTrackingRuntime,
    FailedResponseReportRegistry,
    FailedResponseReportRow,
    RedisCorrelationStore,
    TrackingFieldSelector,
)
from .transports import (
    DelegateEndpointOptions,
    EndpointAdapterFactory,
    EndpointDefinition,
    HttpAuthOptions,
    HttpEndpointOptions,
    HttpOAuth2ClientCredentialsOptions,
)

_BUILT_IN_WORKER_PLUGIN_NAMES = {
    "loadstrike failed responses",
    "loadstrike correlation",
}

_SINK_FEATURE_BY_KIND = {
    "influxdb": "extensions.reporting_sinks.influxdb",
    "timescaledb": "extensions.reporting_sinks.timescaledb",
    "grafanaloki": "extensions.reporting_sinks.grafana_loki",
    "datadog": "extensions.reporting_sinks.datadog",
    "splunk": "extensions.reporting_sinks.splunk",
    "otelcollector": "extensions.reporting_sinks.otel_collector",
}

_TRACKING_FEATURE_BY_KIND = {
    "http": "endpoint.http",
    "kafka": "endpoint.kafka",
    "rabbitmq": "endpoint.rabbitmq",
    "azureeventhubs": "endpoint.azure_event_hubs",
    "pushdiffusion": "endpoint.push_diffusion",
    "delegatestream": "endpoint.delegate_stream",
    "nats": "endpoint.nats",
    "redisstreams": "endpoint.redis_streams",
}

_CI_ENVIRONMENT_VARIABLES = (
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "TF_BUILD",
    "BUILD_BUILDID",
    "JENKINS_URL",
    "TEAMCITY_VERSION",
    "CIRCLECI",
    "BUILDKITE",
    "TRAVIS",
    "APPVEYOR",
    "BITBUCKET_BUILD_NUMBER",
    "CODEBUILD_BUILD_ID",
    "DRONE",
    "SEMAPHORE",
    "HEROKU_TEST_RUN_ID",
)

_DEFAULT_LICENSING_API_BASE_URL = "https://licensing.loadstrike.com"
_development_licensing_api_base_url_override: Optional[str] = None


def _read_text_member(target: Any, *names: str) -> str:
    for name in names:
        member = getattr(target, name, None)
        if member is None:
            continue
        if callable(member):
            try:
                member = member()
            except TypeError:
                continue
            except Exception:  # noqa: BLE001
                member = None
        text = str(member or "").strip()
        if text:
            return text
    return ""


@dataclass
class _LicenseKeyRecord:
    key_id: str
    algorithm: str
    issuer: str = ""
    audience: str = ""
    public_key_pem: str = ""
    expires_at_utc_ms: int = 0


@dataclass
class _LicenseValidationSession:
    run_token: str = ""
    session_id: str = ""
    device_hash: str = ""
    machine_name: str = ""
    environment_classification: int = 0
    heartbeat_stop_event: Optional[threading.Event] = None
    heartbeat_thread: Optional[threading.Thread] = None


class LoadStrikeLocalClient:
    def __init__(
        self,
        *,
        license_validation_timeout_seconds: float = 10.0,
    ) -> None:
        self._licensing_api_base_url = self._resolve_base_url()
        self._license_validation_timeout_seconds = (
            float(license_validation_timeout_seconds)
            if license_validation_timeout_seconds and license_validation_timeout_seconds > 0
            else 10.0
        )
        self._signing_key_cache: Dict[str, _LicenseKeyRecord] = {}

    def run(self, request: LoadStrikeRunRequest | Dict[str, Any]) -> LoadStrikeRunResponse:
        if isinstance(request, LoadStrikeRunRequest):
            payload = request.to_payload()
        else:
            payload = request

        sanitized = self._sanitize_request(payload)
        license_session = self._validate_license_if_required(sanitized)

        try:
            created_utc = datetime.now(timezone.utc)
            scenarios = sanitized.get("Scenarios", [])
            all_request_count = 0
            all_ok_count = 0
            all_fail_count = 0
            threshold_results: list[dict[str, Any]] = []
            scenario_rows: list[dict[str, Any]] = []

            for sort_index, scenario_item in enumerate(scenarios):
                scenario = scenario_item if isinstance(scenario_item, dict) else {}
                scenario_name = str(scenario.get("Name", "unknown"))
                started_ms = int(time.time() * 1000)
                scenario_outcome = self._evaluate_scenario_outcome(
                    scenario,
                    self._compute_scenario_request_count(scenario),
                    sanitized.get("Context", {}),
                )
                duration_ms = max(int(time.time() * 1000) - started_ms, 0)
                request_count = self._as_int(scenario_outcome.get("requestCount"))
                ok_count = scenario_outcome["okCount"]
                fail_count = scenario_outcome["failCount"]

                all_request_count += request_count
                all_ok_count += ok_count
                all_fail_count += fail_count
                threshold_results.extend(
                    self._evaluate_thresholds(
                        scenario,
                        scenario_name,
                        request_count,
                        ok_count,
                        fail_count,
                        duration_ms,
                    )
                )

                scenario_rows.append(
                    self._build_scenario_stats_contract_row(
                        scenario_name,
                        sort_index,
                        request_count,
                        ok_count,
                        fail_count,
                        duration_ms,
                    )
                )

            completed_utc = datetime.now(timezone.utc)
            return LoadStrikeRunResponse.from_payload(
                {
                    "CompletedUtc": completed_utc,
                    "Stats": self._build_node_stats_contract(
                        sanitized.get("Context", {}),
                        created_utc,
                        completed_utc,
                        all_request_count,
                        all_ok_count,
                        all_fail_count,
                        scenario_rows,
                        threshold_results,
                    ),
                }
            )
        finally:
            self._stop_license_lease_if_required(license_session, sanitized)

    def _sanitize_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        context = payload.get("Context")
        if not isinstance(context, dict):
            context = {}

        scenarios = payload.get("Scenarios")
        if not isinstance(scenarios, list):
            scenarios = []

        run_args = payload.get("RunArgs")
        if not isinstance(run_args, list):
            run_args = []

        return {
            "Context": context,
            "Scenarios": scenarios,
            "RunArgs": run_args,
        }

    def _validate_license_if_required(self, payload: Dict[str, Any]) -> _LicenseValidationSession:
        context = payload.get("Context", {})
        if not isinstance(context, dict):
            return _LicenseValidationSession()

        node_type = self._normalize_node_type(self._pick_value(context, "NodeType", "nodeType"))
        if node_type == "agent":
            return _LicenseValidationSession()

        runner_key = str(context.get("RunnerKey", "")).strip()
        if not runner_key:
            raise RuntimeError(
                "Runner key is required. Set Context.RunnerKey before run."
            )

        session_id = str(context.get("SessionId", "")).strip() or hashlib.sha256(
            f"{time.time_ns()}:{runner_key}".encode("utf-8")
        ).hexdigest()[:32]
        context["SessionId"] = session_id

        machine_name = socket.gethostname()
        device_hash = self._compute_device_hash()
        environment_classification = self._detect_environment_classification(node_type)

        request_payload = {
            "RunnerKey": runner_key,
            "RequestedFeatures": self._collect_requested_features(payload),
            "SessionId": session_id,
            "TestSuite": str(context.get("TestSuite", "")),
            "TestName": str(context.get("TestName", "")),
            "NodeType": str(context.get("NodeType") or node_type.title()),
            "MachineName": machine_name,
            "EnvironmentClassification": environment_classification,
            "DeviceHash": device_hash,
        }

        try:
            status_code, parsed = self._post_licensing_request("/api/v1/licenses/validate", request_payload)
            if status_code >= 400 or self._pick_value(parsed, "IsValid", "isValid") is not True:
                denial_code = self._pick_value(parsed, "DenialCode", "denialCode") or "unknown_denial"
                message = self._pick_value(parsed, "Message", "message") or "Runner key validation failed."
                raise RuntimeError(
                    f"Runner key validation denied. DenialCode={denial_code}, Message={message}"
                )

            run_token = str(
                self._pick_value(parsed, "RunToken", "SignedRunToken", "Token", "runToken")
                or ""
            ).strip()
            if not run_token:
                raise RuntimeError(
                    "Runner key validation failed: run token is missing."
                )
            self._verify_signed_run_token(
                run_token,
                payload,
                request_payload["RequestedFeatures"],
                runner_key,
                session_id,
                device_hash,
            )

            self._send_run_token_heartbeat(
                run_token=run_token,
                session_id=session_id,
                device_hash=device_hash,
                machine_name=machine_name,
                environment_classification=environment_classification,
            )
            heartbeat_interval_seconds = max(
                self._as_int(
                    self._pick_value(parsed, "HeartbeatIntervalSeconds", "heartbeatIntervalSeconds")
                ),
                1,
            )
            heartbeat_stop_event = threading.Event()

            def _heartbeat_loop() -> None:
                while not heartbeat_stop_event.wait(heartbeat_interval_seconds):
                    try:
                        self._send_run_token_heartbeat(
                            run_token=run_token,
                            session_id=session_id,
                            device_hash=device_hash,
                            machine_name=machine_name,
                            environment_classification=environment_classification,
                        )
                    except Exception:  # noqa: BLE001
                        # Best-effort heartbeat: server-side lease expiration is authoritative.
                        continue

            heartbeat_thread = threading.Thread(
                target=_heartbeat_loop,
                name="loadstrike-license-heartbeat",
                daemon=True,
            )
            heartbeat_thread.start()
            return _LicenseValidationSession(
                run_token=run_token,
                session_id=session_id,
                device_hash=device_hash,
                machine_name=machine_name,
                environment_classification=environment_classification,
                heartbeat_stop_event=heartbeat_stop_event,
                heartbeat_thread=heartbeat_thread,
            )
        except HTTPError as error:
            body = error.read().decode("utf-8") if error.fp else ""
            parsed = json.loads(body) if body else {}
            denial_code = self._pick_value(parsed, "DenialCode", "denialCode") or "unknown_denial"
            message = self._pick_value(parsed, "Message", "message") or str(error)
            raise RuntimeError(
                f"Runner key validation denied. DenialCode={denial_code}, Message={message}"
            ) from error
        except URLError as error:
            raise RuntimeError(f"Runner key validation failed: {error}") from error

    def _verify_signed_run_token(
        self,
        run_token: str,
        payload: Dict[str, Any],
        requested_features: List[str],
        runner_key: str,
        session_id: str,
        device_hash: str,
    ) -> None:
        header, claims, signing_input, signature = self._parse_jwt(run_token)
        key_id = str(header.get("kid") or "default")
        algorithm = str(header.get("alg") or "RS256").upper()
        if algorithm != "RS256":
            raise RuntimeError(
                "Runner key validation denied. DenialCode=invalid_run_token_signature, Message=Invalid run token signature."
            )
        key_record = self._get_signing_key(key_id, algorithm)
        if not self._verify_jwt_signature(algorithm, key_record, signing_input, signature):
            raise RuntimeError(
                "Runner key validation denied. DenialCode=invalid_run_token_signature, Message=Invalid run token signature."
            )
        self._enforce_jwt_lifetime(claims)

        token_issuer = str(claims.get("iss", "")).strip()
        if not key_record.issuer or token_issuer != key_record.issuer:
            raise RuntimeError(
                "Runner key validation failed: run token issuer does not match."
            )

        raw_audience = claims.get("aud")
        token_audiences: List[str] = []
        if isinstance(raw_audience, list):
            token_audiences = [str(item).strip() for item in raw_audience if str(item).strip()]
        elif isinstance(raw_audience, str) and raw_audience.strip():
            token_audiences = [raw_audience.strip()]
        if not key_record.audience or key_record.audience not in token_audiences:
            raise RuntimeError(
                "Runner key validation failed: run token audience does not match."
            )

        token_runner_key = str(claims.get("runner_key", "")).strip()
        if token_runner_key != runner_key:
            raise RuntimeError(
                "Runner key validation failed: run token runner key does not match."
            )
        token_session_id = str(claims.get("session_id", "")).strip()
        if token_session_id != session_id:
            raise RuntimeError(
                "Runner key validation failed: run token session id does not match."
            )
        token_device_hash = str(claims.get("device_hash", "")).strip()
        if token_device_hash != device_hash:
            raise RuntimeError(
                "Runner key validation failed: run token device hash does not match."
            )

        self._enforce_entitlement_claims(claims, requested_features)
        self._enforce_runtime_policy_claims(claims, payload)

    def _get_signing_key(self, key_id: str, algorithm: str) -> _LicenseKeyRecord:
        normalized_key_id = str(key_id or "default").strip() or "default"
        normalized_algorithm = str(algorithm or "RS256").upper()
        cache_key = f"{self._licensing_api_base_url.lower()}|{normalized_algorithm}:{normalized_key_id}"
        now_ms = int(time.time() * 1000)
        cached = self._signing_key_cache.get(cache_key)
        if cached and cached.expires_at_utc_ms > now_ms:
            return cached

        status_code, payload = self._get_licensing_request(
            f"/api/v1/licenses/signing-public-key?kid={quote(normalized_key_id, safe='')}"
        )
        if status_code >= 400:
            raise RuntimeError(
                f"Runner key validation denied. DenialCode=signing_key_lookup_failed, Message=Failed to resolve signing key (status={status_code})."
            )

        resolved_key_id = str(self._pick_value(payload, "KeyId", "Kid", "kid") or normalized_key_id).strip() or normalized_key_id
        if resolved_key_id != normalized_key_id:
            raise RuntimeError(
                "Runner key validation failed: signing key response key id does not match requested key id."
            )
        record = _LicenseKeyRecord(
            key_id=resolved_key_id,
            algorithm=str(self._pick_value(payload, "Algorithm", "alg") or normalized_algorithm).upper(),
            issuer=str(self._pick_value(payload, "Issuer", "issuer") or "").strip(),
            audience=str(self._pick_value(payload, "Audience", "audience") or "").strip(),
            public_key_pem=self._normalize_pem_text(
                self._pick_value(payload, "PublicKeyPem", "publicKeyPem", "PublicKey", "publicKey", "Pem", "pem") or ""
            ),
            expires_at_utc_ms=now_ms + (15 * 60 * 1000),
        )
        self._signing_key_cache[cache_key] = record
        return record

    def _verify_jwt_signature(
        self,
        algorithm: str,
        key_record: _LicenseKeyRecord,
        signing_input: str,
        signature: bytes,
    ) -> bool:
        normalized = algorithm.upper()
        if normalized != "RS256":
            return False
        if not key_record.public_key_pem:
            return False
        try:
            public_key = serialization.load_pem_public_key(
                key_record.public_key_pem.encode("utf-8")
            )
            public_key.verify(
                signature,
                signing_input.encode("utf-8"),
                padding.PKCS1v15(),
                hashes.SHA256(),
            )
            return True
        except Exception:  # noqa: BLE001
            return False

    def _enforce_jwt_lifetime(self, claims: Dict[str, Any]) -> None:
        clock_skew_seconds = 30
        now_seconds = int(time.time())
        exp = self._read_epoch_claim(claims, "exp", "Exp")
        if exp is None or exp <= 0:
            raise RuntimeError("Runner key validation failed: run token expiration is missing.")
        if now_seconds > (exp + clock_skew_seconds):
            raise RuntimeError("Runner key validation failed: run token is expired.")

        nbf = self._read_epoch_claim(claims, "nbf", "Nbf")
        if nbf is not None and nbf > 0 and (now_seconds + clock_skew_seconds) < nbf:
            raise RuntimeError("Runner key validation failed: run token is not yet valid.")

    def _read_epoch_claim(self, claims: Dict[str, Any], *keys: str) -> Optional[int]:
        value = self._pick_value(claims, *keys)
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return int(value)
        text = str(value).strip()
        if not text:
            return None
        try:
            return int(float(text))
        except ValueError:
            return None

    def _enforce_entitlement_claims(self, claims: Dict[str, Any], requested_features: List[str]) -> None:
        entitlements = self._collect_claim_strings(
            claims,
            "entitlements",
            "Entitlements",
            "features",
            "Features",
            "feature",
            "Feature",
        )
        normalized = {item.lower() for item in entitlements}
        for feature in requested_features:
            if str(feature).lower() not in normalized:
                raise RuntimeError(
                    f"Runner key validation denied. DenialCode=missing_entitlement, Message=Missing entitlement for {feature}."
                )

    def _enforce_runtime_policy_claims(self, claims: Dict[str, Any], payload: Dict[str, Any]) -> None:
        policy = self._resolve_runtime_policy(claims)
        if not policy:
            return

        context = self._as_dict(payload.get("Context"))

        max_scenarios = self._as_int(self._pick_value(policy, "maxScenarios", "MaxScenarios"))
        scenarios = payload.get("Scenarios", [])
        scenario_count = len(scenarios) if isinstance(scenarios, list) else 0
        if max_scenarios > 0 and scenario_count > max_scenarios:
            raise RuntimeError(
                    f"Runner key validation denied. DenialCode=max_scenarios_exceeded, Message=Scenario count {scenario_count} exceeds policy limit {max_scenarios}."
                )

        max_agents = self._as_int(self._pick_value(policy, "maxAgentsCount", "MaxAgentsCount"))
        agents_count = max(
            self._as_int(self._pick_value(context, "AgentsCount", "agentsCount")),
            1,
        )
        if max_agents > 0 and agents_count > max_agents:
            raise RuntimeError(
                f"Runner key validation denied. DenialCode=max_agents_exceeded, Message=Agents count {agents_count} exceeds policy limit {max_agents}."
            )

        max_custom_worker_plugins = self._as_int(
            self._pick_value(policy, "maxCustomWorkerPlugins", "MaxCustomWorkerPlugins")
        )
        custom_worker_plugins_count = self._count_custom_worker_plugins(context)
        if (
            max_custom_worker_plugins > 0
            and custom_worker_plugins_count > max_custom_worker_plugins
        ):
            raise RuntimeError(
                "Runner key validation denied. DenialCode=max_custom_worker_plugins_exceeded, "
                f"Message=Custom worker plugin count {custom_worker_plugins_count} exceeds policy limit {max_custom_worker_plugins}."
            )

        max_reporting_sinks = self._as_int(
            self._pick_value(policy, "maxReportingSinks", "MaxReportingSinks")
        )
        reporting_sinks_count = len(
            self._as_list(self._pick_value(context, "ReportingSinks", "reportingSinks"))
        )
        if max_reporting_sinks > 0 and reporting_sinks_count > max_reporting_sinks:
            raise RuntimeError(
                "Runner key validation denied. DenialCode=max_reporting_sinks_exceeded, "
                f"Message=Reporting sink count {reporting_sinks_count} exceeds policy limit {max_reporting_sinks}."
            )

        max_target_scenarios = self._as_int(
            self._pick_value(policy, "maxTargetScenarioCount", "MaxTargetScenarioCount")
        )
        targeted_scenario_count = self._count_targeted_scenarios(context)
        if max_target_scenarios > 0 and targeted_scenario_count > max_target_scenarios:
            raise RuntimeError(
                "Runner key validation denied. DenialCode=max_target_scenarios_exceeded, "
                f"Message=Targeted scenario count {targeted_scenario_count} exceeds policy limit {max_target_scenarios}."
            )

        max_cluster_command_timeout_seconds = self._as_int(
            self._pick_value(
                policy,
                "maxClusterCommandTimeoutSeconds",
                "MaxClusterCommandTimeoutSeconds",
            )
        )
        cluster_command_timeout_seconds = self._resolve_timeout_seconds(
            context,
            "ClusterCommandTimeoutSeconds",
            "clusterCommandTimeoutSeconds",
            "ClusterCommandTimeoutMs",
            "clusterCommandTimeoutMs",
            default_seconds=120.0,
        )
        if (
            max_cluster_command_timeout_seconds > 0
            and cluster_command_timeout_seconds > max_cluster_command_timeout_seconds
        ):
            raise RuntimeError(
                "Runner key validation denied. DenialCode=cluster_command_timeout_exceeded, "
                "Message=Cluster command timeout "
                f"{cluster_command_timeout_seconds:.3f}s exceeds policy limit {max_cluster_command_timeout_seconds}s."
            )

        max_scenario_completion_timeout_seconds = self._as_int(
            self._pick_value(
                policy,
                "maxScenarioCompletionTimeoutSeconds",
                "MaxScenarioCompletionTimeoutSeconds",
            )
        )
        scenario_completion_timeout_seconds = self._resolve_timeout_seconds(
            context,
            "ScenarioCompletionTimeoutSeconds",
            "scenarioCompletionTimeoutSeconds",
            "ScenarioCompletionTimeoutMs",
            "scenarioCompletionTimeoutMs",
            default_seconds=30.0,
        )
        if (
            max_scenario_completion_timeout_seconds > 0
            and scenario_completion_timeout_seconds > max_scenario_completion_timeout_seconds
        ):
            raise RuntimeError(
                "Runner key validation denied. DenialCode=scenario_completion_timeout_exceeded, "
                "Message=Scenario completion timeout "
                f"{scenario_completion_timeout_seconds:.3f}s exceeds policy limit {max_scenario_completion_timeout_seconds}s."
            )

    def _collect_claim_strings(self, claims: Dict[str, Any], *keys: str) -> List[str]:
        values: List[str] = []
        for key in keys:
            if key not in claims:
                continue
            values.extend(self._normalize_string_list(claims.get(key)))
        deduped: List[str] = []
        seen = set()
        for value in values:
            lowered = value.lower()
            if lowered in seen:
                continue
            seen.add(lowered)
            deduped.append(value)
        return deduped

    def _collect_requested_features(self, payload: Dict[str, Any]) -> List[str]:
        context = self._as_dict(payload.get("Context"))
        scenarios = payload.get("Scenarios", [])

        features = {
            "core.runtime",
            "reporting.formats.standard",
        }

        if self._as_bool(self._pick_value(context, "LocalDevClusterEnabled", "localDevClusterEnabled"), False):
            features.add("cluster.local_dev")
        if str(self._pick_value(context, "NatsServerUrl", "natsServerUrl") or "").strip():
            features.add("cluster.distributed.nats")

        if (
            self._normalize_string_list(self._pick_value(context, "AgentTargetScenarios", "agentTargetScenarios"))
            or self._normalize_string_list(
                self._pick_value(context, "CoordinatorTargetScenarios", "coordinatorTargetScenarios")
            )
            or self._resolve_timeout_seconds(
                context,
                "ClusterCommandTimeoutSeconds",
                "clusterCommandTimeoutSeconds",
                "ClusterCommandTimeoutMs",
                "clusterCommandTimeoutMs",
                default_seconds=120.0,
            ) != 120.0
        ):
            features.add("cluster.targeting_and_tuning.advanced")

        worker_plugins = self._as_list(self._pick_value(context, "WorkerPlugins", "workerPlugins"))
        for plugin in worker_plugins:
            plugin_map = self._as_dict(plugin)
            plugin_name = str(
                self._pick_value(plugin_map, "PluginName", "pluginName")
                or _read_text_member(plugin, "plugin_name", "pluginName", "PluginName")
            ).strip().lower()
            if plugin_name and plugin_name not in _BUILT_IN_WORKER_PLUGIN_NAMES:
                features.add("extensions.worker_plugins.custom")
                break

        reporting_sinks = self._as_list(self._pick_value(context, "ReportingSinks", "reportingSinks"))
        has_custom_sink = False
        for sink in reporting_sinks:
            sink_map = self._as_dict(sink)
            mapped = str(
                self._pick_value(sink_map, "LicenseFeature", "licenseFeature", "Feature", "feature")
                or _read_text_member(sink, "license_feature", "licenseFeature", "LicenseFeature")
            ).strip()
            if mapped:
                features.add(mapped)
                continue

            sink_kind = str(self._pick_value(sink_map, "Kind", "kind") or "").strip()
            normalized_kind = re.sub(r"[^a-z0-9]+", "", sink_kind.lower())
            mapped = _SINK_FEATURE_BY_KIND.get(normalized_kind)
            if mapped:
                features.add(mapped)
                continue

            has_custom_sink = True
        if has_custom_sink:
            features.add("extensions.reporting_sinks.custom")

        if isinstance(scenarios, list):
            for scenario in scenarios:
                scenario = self._as_dict(scenario)
                if not scenario:
                    continue

                thresholds = scenario.get("Thresholds")
                if isinstance(thresholds, list) and len(thresholds) > 0:
                    features.add("policy.report_finalizer_and_threshold_controls")

                tracking = self._as_dict(scenario.get("Tracking"))
                if not tracking:
                    continue

                source = self._as_dict(tracking.get("Source"))
                if source:
                    feature = _TRACKING_FEATURE_BY_KIND.get(
                        str(self._pick_value(source, "Kind", "kind") or "").strip().lower()
                    )
                    if feature:
                        features.add(feature)

                destination = self._as_dict(tracking.get("Destination"))
                if destination:
                    feature = _TRACKING_FEATURE_BY_KIND.get(
                        str(self._pick_value(destination, "Kind", "kind") or "").strip().lower()
                    )
                    if feature:
                        features.add(feature)
                else:
                    features.add("crossplatform.source_only_reporting")

                if source or destination:
                    features.add("crossplatform.tracking.selectors")
                    features.add("reporting.correlation.grouped")

                store = self._as_dict(tracking.get("CorrelationStore"))
                if store:
                    kind = str(self._pick_value(store, "Kind", "kind") or "").strip().lower()
                    if kind == "redis":
                        features.add("correlation.store.redis")

        return sorted({str(value).strip().lower() for value in features if str(value).strip()})

    def _resolve_runtime_policy(self, claims: Dict[str, Any]) -> Dict[str, Any]:
        policy = self._as_dict(
            self._pick_value(claims, "runtimePolicy", "RuntimePolicy", "policy", "Policy")
        )

        # Backend-issued signed tokens carry flat claim names (policy.*) alongside nested payloads.
        policy["maxAgentsCount"] = self._pick_positive_int(
            policy,
            claims,
            "maxAgentsCount",
            "MaxAgentsCount",
            "policy.max_agents_count",
        )
        policy["maxScenarios"] = self._pick_positive_int(
            policy,
            claims,
            "maxScenarios",
            "MaxScenarios",
            "maxScenarioCount",
            "MaxScenarioCount",
            "policy.max_scenario_count",
        )
        policy["maxCustomWorkerPlugins"] = self._pick_positive_int(
            policy,
            claims,
            "maxCustomWorkerPlugins",
            "MaxCustomWorkerPlugins",
            "policy.max_custom_worker_plugins",
        )
        policy["maxReportingSinks"] = self._pick_positive_int(
            policy,
            claims,
            "maxReportingSinks",
            "MaxReportingSinks",
            "policy.max_reporting_sinks",
        )
        policy["maxTargetScenarioCount"] = self._pick_positive_int(
            policy,
            claims,
            "maxTargetScenarioCount",
            "MaxTargetScenarioCount",
            "policy.max_target_scenario_count",
        )
        policy["maxClusterCommandTimeoutSeconds"] = self._pick_positive_int(
            policy,
            claims,
            "maxClusterCommandTimeoutSeconds",
            "MaxClusterCommandTimeoutSeconds",
            "policy.max_cluster_command_timeout_seconds",
        )
        policy["maxScenarioCompletionTimeoutSeconds"] = self._pick_positive_int(
            policy,
            claims,
            "maxScenarioCompletionTimeoutSeconds",
            "MaxScenarioCompletionTimeoutSeconds",
            "policy.max_scenario_completion_timeout_seconds",
        )
        return policy

    def _pick_positive_int(
        self,
        primary: Dict[str, Any],
        secondary: Dict[str, Any],
        *keys: str,
    ) -> int:
        value = self._pick_value(primary, *keys)
        if value is None:
            value = self._pick_value(secondary, *keys)
        parsed = self._as_int(value)
        return parsed if parsed > 0 else 0

    def _count_targeted_scenarios(self, context: Dict[str, Any]) -> int:
        values: List[str] = []
        values.extend(
            self._normalize_string_list(
                self._pick_value(context, "TargetScenarios", "targetScenarios")
            )
        )
        values.extend(
            self._normalize_string_list(
                self._pick_value(context, "AgentTargetScenarios", "agentTargetScenarios")
            )
        )
        values.extend(
            self._normalize_string_list(
                self._pick_value(
                    context, "CoordinatorTargetScenarios", "coordinatorTargetScenarios"
                )
            )
        )
        unique = {
            value.strip().lower()
            for value in values
            if value and value.strip()
        }
        return len(unique)

    def _count_custom_worker_plugins(self, context: Dict[str, Any]) -> int:
        worker_plugins = self._as_list(self._pick_value(context, "WorkerPlugins", "workerPlugins"))
        count = 0
        for plugin in worker_plugins:
            if isinstance(plugin, dict):
                plugin_name = str(self._pick_value(plugin, "PluginName", "pluginName") or "").strip().lower()
            else:
                plugin_name = _read_text_member(plugin, "plugin_name", "pluginName", "PluginName").lower()
            if not plugin_name or plugin_name in _BUILT_IN_WORKER_PLUGIN_NAMES:
                continue
            count += 1
        return count

    def _resolve_timeout_seconds(
        self,
        context: Dict[str, Any],
        seconds_key: str,
        seconds_key_alias: str,
        milliseconds_key: str,
        milliseconds_key_alias: str,
        default_seconds: float = 0.0,
    ) -> float:
        seconds = self._as_float(
            self._pick_value(context, seconds_key, seconds_key_alias)
        )
        if seconds > 0:
            return seconds
        milliseconds = self._as_float(
            self._pick_value(context, milliseconds_key, milliseconds_key_alias)
        )
        if milliseconds > 0:
            return milliseconds / 1000.0
        return default_seconds

    @staticmethod
    def _normalize_node_type(value: Any) -> str:
        normalized = str(value or "single").strip().lower()
        if normalized in {"0", "single", "singlenode"}:
            return "single"
        if normalized in {"1", "coordinator"}:
            return "coordinator"
        if normalized in {"2", "agent"}:
            return "agent"
        return normalized

    @classmethod
    def _to_contract_node_type(cls, value: Any) -> str:
        normalized = cls._normalize_node_type(value)
        if normalized == "coordinator":
            return "Coordinator"
        if normalized == "agent":
            return "Agent"
        if normalized == "single":
            return "SingleNode"
        text = str(value or "").strip()
        return text or "SingleNode"

    @staticmethod
    def _as_list(value: Any) -> List[Any]:
        return list(value) if isinstance(value, list) else []

    def _send_run_token_heartbeat(
        self,
        *,
        run_token: str,
        session_id: str,
        device_hash: str,
        machine_name: str,
        environment_classification: int,
    ) -> None:
        heartbeat = {
            "RunToken": run_token,
            "SessionId": session_id,
            "DeviceHash": device_hash,
            "MachineName": machine_name,
            "EnvironmentClassification": environment_classification,
        }
        status_code, _ = self._post_licensing_request("/api/v1/licenses/heartbeat", heartbeat)
        if status_code >= 400:
            raise RuntimeError(
                f"Runner key validation denied. DenialCode=run_token_heartbeat_failed, Message=Run token heartbeat failed with status {status_code}."
            )

    def _compute_device_hash(self) -> str:
        components: List[str] = []
        self._add_if_not_blank(components, platform.platform())
        self._add_if_not_blank(components, platform.machine())
        self._add_if_not_blank(components, socket.gethostname())

        system = platform.system().strip().lower()
        if system == "windows":
            self._add_if_not_blank(components, self._read_windows_machine_guid())
        elif system == "linux":
            self._add_if_not_blank(components, self._read_linux_machine_id())
        elif system == "darwin":
            self._add_if_not_blank(components, self._read_mac_platform_uuid())

        if not components:
            components.append(socket.gethostname())

        raw = "|".join(item.strip().lower() for item in components if item and item.strip())
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _add_if_not_blank(values: List[str], value: Optional[str]) -> None:
        if value and str(value).strip():
            values.append(str(value))

    @staticmethod
    def _read_windows_machine_guid() -> str:
        try:
            import winreg  # type: ignore

            with winreg.OpenKey(  # type: ignore[attr-defined]
                winreg.HKEY_LOCAL_MACHINE,  # type: ignore[attr-defined]
                r"SOFTWARE\Microsoft\Cryptography",
            ) as key:
                value, _ = winreg.QueryValueEx(key, "MachineGuid")  # type: ignore[attr-defined]
                return str(value).strip()
        except Exception:  # noqa: BLE001
            return ""

    @staticmethod
    def _read_linux_machine_id() -> str:
        for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    value = handle.read().strip()
                if value:
                    return value
            except Exception:  # noqa: BLE001
                continue
        return ""

    @staticmethod
    def _read_mac_platform_uuid() -> str:
        try:
            result = subprocess.run(
                ["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
            match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', result.stdout or "")
            return match.group(1).strip() if match else ""
        except Exception:  # noqa: BLE001
            return ""

    def _stop_license_lease_if_required(
        self,
        session: _LicenseValidationSession,
        payload: Dict[str, Any],
    ) -> None:
        _ = payload
        if session.heartbeat_stop_event is not None:
            session.heartbeat_stop_event.set()
        if session.heartbeat_thread is not None and session.heartbeat_thread.is_alive():
            session.heartbeat_thread.join(timeout=self._license_validation_timeout_seconds)

        if not session.run_token:
            return
        stop_payload = {
            "RunToken": session.run_token,
            "SessionId": session.session_id,
            "DeviceHash": session.device_hash,
        }
        try:
            self._post_licensing_request("/api/v1/licenses/stop", stop_payload)
        except Exception:  # noqa: BLE001
            return

    def _post_licensing_request(
        self,
        path: str,
        payload: Dict[str, Any],
    ) -> Tuple[int, Dict[str, Any]]:
        endpoint = f"{self._licensing_api_base_url.rstrip('/')}{path}"
        request = Request(
            endpoint,
            method="POST",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )
        try:
            with urlopen(request, timeout=self._license_validation_timeout_seconds) as response:
                body = response.read().decode("utf-8")
                parsed = json.loads(body) if body else {}
                if not isinstance(parsed, dict):
                    parsed = {}
                return int(response.status), parsed
        except HTTPError as error:
            body = error.read().decode("utf-8") if error.fp else ""
            parsed = json.loads(body) if body else {}
            if not isinstance(parsed, dict):
                parsed = {}
            return int(error.code), parsed

    def _get_licensing_request(
        self,
        path: str,
    ) -> Tuple[int, Dict[str, Any]]:
        endpoint = f"{self._licensing_api_base_url.rstrip('/')}{path}"
        request = Request(
            endpoint,
            method="GET",
            headers={
                "Accept": "application/json",
            },
        )
        try:
            with urlopen(request, timeout=self._license_validation_timeout_seconds) as response:
                body = response.read().decode("utf-8")
                parsed = json.loads(body) if body else {}
                if not isinstance(parsed, dict):
                    parsed = {}
                return int(response.status), parsed
        except HTTPError as error:
            body = error.read().decode("utf-8") if error.fp else ""
            parsed = json.loads(body) if body else {}
            if not isinstance(parsed, dict):
                parsed = {}
            return int(error.code), parsed

    def _parse_jwt(self, token: str) -> Tuple[Dict[str, Any], Dict[str, Any], str, bytes]:
        parts = token.split(".")
        if len(parts) != 3:
            raise RuntimeError("Invalid run token format.")
        header_segment, payload_segment, signature_segment = parts
        header = self._decode_jwt_json_segment(header_segment)
        claims = self._decode_jwt_json_segment(payload_segment)
        signing_input = f"{header_segment}.{payload_segment}"
        signature = self._decode_base64_url(signature_segment)
        return header, claims, signing_input, signature

    @staticmethod
    def _decode_jwt_json_segment(segment: str) -> Dict[str, Any]:
        raw = LoadStrikeLocalClient._decode_base64_url(segment).decode("utf-8")
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            raise RuntimeError("Invalid run token payload.")
        return parsed

    @staticmethod
    def _decode_base64_url(value: str) -> bytes:
        normalized = value.replace("-", "+").replace("_", "/")
        remainder = len(normalized) % 4
        if remainder:
            normalized = normalized + ("=" * (4 - remainder))
        return base64.b64decode(normalized.encode("ascii"))

    @staticmethod
    def _normalize_string_list(value: Any) -> List[str]:
        if isinstance(value, list):
            return [str(x).strip() for x in value if str(x).strip()]
        if isinstance(value, str) and value.strip():
            return [item.strip() for item in value.split(",") if item.strip()]
        return []

    def _map_environment_classification(self, value: str) -> int:
        normalized = value.strip().lower()
        if normalized == "ci":
            return 1
        if normalized == "kubernetes":
            return 2
        if normalized == "clustercontroller":
            return 3
        return 0

    def _detect_environment_classification(self, node_type: str) -> int:
        if self._is_ci_host():
            return 1
        if self._is_kubernetes_host():
            return 2
        if self._is_local_host():
            return 0
        return 3 if node_type == "coordinator" else 1

    def _is_ci_host(self) -> bool:
        if self._has_truthy_env("CI"):
            return True
        return any(self._has_non_blank_env(name) for name in _CI_ENVIRONMENT_VARIABLES)

    def _is_kubernetes_host(self) -> bool:
        return (
            self._has_non_blank_env("KUBERNETES_SERVICE_HOST")
            or self._has_non_blank_env("KUBERNETES_PORT")
            or os.path.exists("/var/run/secrets/kubernetes.io/serviceaccount/token")
        )

    def _is_local_host(self) -> bool:
        system = platform.system().strip().lower()
        if system == "windows":
            return not self._is_windows_server_product(self._read_windows_product_name())
        if system == "darwin":
            return True
        if system == "linux":
            return self._is_linux_local_host()

        os_description = self._os_description().lower()
        return any(token in os_description for token in ("android", "ios", "iphone", "ipad"))

    def _is_linux_local_host(self) -> bool:
        if self._is_wsl_host():
            return not self._is_windows_server_product(self._read_wsl_windows_product_name())
        if self._is_container_host():
            return False

        os_description = self._os_description().lower()
        if "android" in os_description:
            return True
        return self._has_linux_desktop_session()

    def _is_container_host(self) -> bool:
        return (
            self._has_truthy_env("container")
            or os.path.exists("/.dockerenv")
            or os.path.exists("/run/.containerenv")
            or self._file_contains("/proc/1/cgroup", "docker", "containerd", "podman", "kubepods", "lxc")
            or self._file_contains("/proc/self/cgroup", "docker", "containerd", "podman", "kubepods", "lxc")
        )

    def _is_wsl_host(self) -> bool:
        return (
            self._has_non_blank_env("WSL_INTEROP")
            or self._has_non_blank_env("WSL_DISTRO_NAME")
            or self._file_contains("/proc/version", "microsoft")
            or self._file_contains("/proc/sys/kernel/osrelease", "microsoft")
        )

    def _has_linux_desktop_session(self) -> bool:
        if any(self._has_non_blank_env(name) for name in ("DISPLAY", "WAYLAND_DISPLAY", "XDG_CURRENT_DESKTOP", "DESKTOP_SESSION", "MIR_SOCKET")):
            return True
        session_type = os.environ.get("XDG_SESSION_TYPE", "").strip().lower()
        return session_type in {"x11", "wayland"}

    def _has_non_blank_env(self, name: str) -> bool:
        return bool(str(os.environ.get(name, "")).strip())

    def _has_truthy_env(self, name: str) -> bool:
        value = str(os.environ.get(name, "")).strip().lower()
        return bool(value) and value not in {"0", "false", "no"}

    def _file_contains(self, path: str, *markers: str) -> bool:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                content = handle.read().lower()
            return any(marker.lower() in content for marker in markers)
        except Exception:  # noqa: BLE001
            return False

    @staticmethod
    def _is_windows_server_product(product_name: str) -> bool:
        return "server" in str(product_name or "").strip().lower()

    @staticmethod
    def _os_description() -> str:
        return platform.platform()

    @staticmethod
    def _read_windows_product_name() -> str:
        try:
            import winreg  # type: ignore

            with winreg.OpenKey(  # type: ignore[attr-defined]
                winreg.HKEY_LOCAL_MACHINE,  # type: ignore[attr-defined]
                r"SOFTWARE\Microsoft\Windows NT\CurrentVersion",
            ) as key:
                value, _ = winreg.QueryValueEx(key, "ProductName")  # type: ignore[attr-defined]
                return str(value).strip()
        except Exception:  # noqa: BLE001
            return ""

    @staticmethod
    def _read_wsl_windows_product_name() -> str:
        try:
            result = subprocess.run(
                ["cmd.exe", "/c", "reg", "query", r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion", "/v", "ProductName"],
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
            )
            match = re.search(r"ProductName\s+REG_\w+\s+([^\r\n]+)", result.stdout or "", re.IGNORECASE)
            return match.group(1).strip() if match else ""
        except Exception:  # noqa: BLE001
            return ""

    def _evaluate_scenario_outcome(
        self,
        scenario: Dict[str, Any],
        request_count: int,
        context: Dict[str, Any],
    ) -> Dict[str, int]:
        tracking = scenario.get("Tracking", {})
        if not isinstance(tracking, dict):
            tracking = {}

        source_spec = tracking.get("Source", {})
        if not isinstance(source_spec, dict) or not source_spec:
            return {"requestCount": request_count, "okCount": request_count, "failCount": 0}

        source_endpoint = self._map_endpoint_spec(source_spec)
        destination_spec = tracking.get("Destination", {})
        destination_endpoint = (
            self._map_endpoint_spec(destination_spec)
            if isinstance(destination_spec, dict) and destination_spec
            else None
        )
        if source_endpoint.gather_by_field:
            raise ValueError("GatherByField is supported on destination endpoint only.")

        correlation_timeout_raw = self._pick_value(
            tracking,
            "CorrelationTimeoutSeconds",
            "correlationTimeoutSeconds",
            "CorrelationTimeout",
        )
        timeout_seconds = (
            self._as_float(correlation_timeout_raw)
            if correlation_timeout_raw is not None
            else 30.0
        )
        if timeout_seconds <= 0:
            raise ValueError("CorrelationTimeout must be greater than zero.")
        timeout_sweep_raw = self._pick_value(
            tracking,
            "TimeoutSweepIntervalSeconds",
            "timeoutSweepIntervalSeconds",
            "TimeoutSweepInterval",
        )
        timeout_sweep_interval_seconds = (
            self._as_float(timeout_sweep_raw)
            if timeout_sweep_raw is not None
            else 1.0
        )
        if timeout_sweep_interval_seconds <= 0:
            raise ValueError("TimeoutSweepInterval must be greater than zero.")
        timeout_batch_raw = self._pick_value(tracking, "TimeoutBatchSize", "timeoutBatchSize")
        timeout_batch_size = self._as_int(timeout_batch_raw) if timeout_batch_raw is not None else 200
        if timeout_batch_size <= 0:
            raise ValueError("TimeoutBatchSize must be greater than zero.")
        timeout_counts_as_failure = self._as_bool(
            self._pick_value(tracking, "TimeoutCountsAsFailure", "timeoutCountsAsFailure"),
            True,
        )
        timeout_sweep_interval_ms = (
            max(int(timeout_sweep_interval_seconds * 1000), 1)
            if timeout_sweep_interval_seconds > 0
            else None
        )
        correlation_store = self._map_correlation_store(tracking)
        scenario_name = str(self._pick_value(scenario, "Name", "name") or "")
        run_mode_text = str(self._pick_value(tracking, "RunMode", "runMode") or "GenerateAndCorrelate").strip()
        run_mode_text = run_mode_text or "GenerateAndCorrelate"
        run_mode = run_mode_text.lower()
        metric_prefix = str(self._pick_value(tracking, "MetricPrefix", "metricPrefix") or "tracking").strip()
        if not metric_prefix:
            raise ValueError("MetricPrefix must be provided.")
        if run_mode not in {"generateandcorrelate", "sourceonly", "correlateexistingtraffic"}:
            raise ValueError("Unsupported tracking run mode.")
        if run_mode in {"generateandcorrelate", "sourceonly"}:
            if source_endpoint.mode != "Produce":
                raise ValueError("Source endpoint mode must be Produce for GenerateAndCorrelate mode.")
            if destination_endpoint is not None and destination_endpoint.mode != "Consume":
                raise ValueError("Destination endpoint mode must be Consume for GenerateAndCorrelate mode.")
        elif run_mode == "correlateexistingtraffic":
            if destination_endpoint is None:
                raise ValueError("Destination endpoint must be provided for CorrelateExistingTraffic mode.")
            if source_endpoint.mode != "Consume":
                raise ValueError("Source endpoint mode must be Consume for CorrelateExistingTraffic mode.")
            if destination_endpoint.mode != "Consume":
                raise ValueError("Destination endpoint mode must be Consume for CorrelateExistingTraffic mode.")

        source_adapter = EndpointAdapterFactory.create(source_endpoint)
        destination_adapter = EndpointAdapterFactory.create(destination_endpoint) if destination_endpoint else None
        if hasattr(source_adapter, "initialize"):
            source_adapter.initialize()
        if destination_adapter is not None and hasattr(destination_adapter, "initialize"):
            destination_adapter.initialize()

        gather_selector = (
            TrackingFieldSelector.parse(destination_endpoint.gather_by_field)
            if destination_endpoint and destination_endpoint.gather_by_field
            else None
        )

        def _utc_from_ms(value: Optional[Union[int, float]]) -> Optional[datetime]:
            if value is None:
                return None
            return datetime.fromtimestamp(max(float(value), 0.0) / 1000.0, timezone.utc)

        def _record_failed_response(
            *,
            status_code: str,
            tracking_id: Optional[str],
            event_id: Optional[str] = None,
            message: Optional[str] = None,
            source_timestamp_utc: Optional[datetime] = None,
            destination_timestamp_utc: Optional[datetime] = None,
            latency_ms: Optional[float] = None,
        ) -> None:
            FailedResponseReportRegistry.add(
                FailedResponseReportRow(
                    occurred_utc=datetime.now(timezone.utc),
                    scenario_name=scenario_name,
                    source_endpoint=source_endpoint.name,
                    destination_endpoint=destination_endpoint.name if destination_endpoint else "",
                    run_mode=run_mode_text,
                    status_code=status_code,
                    tracking_id=tracking_id,
                    event_id=event_id,
                    message=message,
                    source_timestamp_utc=source_timestamp_utc,
                    destination_timestamp_utc=destination_timestamp_utc,
                    latency_ms=latency_ms,
                )
            )

        def _record_correlation_row(
            *,
            status_code: str,
            tracking_id: Optional[str],
            is_success: bool,
            is_failure: bool,
            event_id: Optional[str] = None,
            gather_by_value: Optional[str] = None,
            message: Optional[str] = None,
            source_timestamp_utc: Optional[datetime] = None,
            destination_timestamp_utc: Optional[datetime] = None,
            latency_ms: Optional[float] = None,
        ) -> None:
            CorrelationReportRegistry.add(
                CorrelationReportRow(
                    occurred_utc=datetime.now(timezone.utc),
                    scenario_name=scenario_name,
                    source_endpoint=source_endpoint.name,
                    destination_endpoint=destination_endpoint.name if destination_endpoint else "",
                    run_mode=run_mode_text,
                    status_code=status_code,
                    tracking_id=tracking_id,
                    event_id=event_id,
                    gather_by_field=destination_endpoint.gather_by_field if destination_endpoint else None,
                    gather_by_value=gather_by_value,
                    message=message,
                    source_timestamp_utc=source_timestamp_utc,
                    destination_timestamp_utc=destination_timestamp_utc,
                    latency_ms=latency_ms,
                    is_success=is_success,
                    is_failure=is_failure,
                )
            )

        class _CorrelationReportPlugin:
            def on_matched(  # noqa: N805
                self,
                tracking_id: str,
                _source_payload: Dict[str, Any],
                destination_payload: Dict[str, Any],
                latency_ms: int,
                gather_key: Optional[str] = None,
            ) -> None:
                destination_timestamp = datetime.now(timezone.utc)
                source_timestamp = destination_timestamp - timedelta(milliseconds=max(int(latency_ms), 0))
                gather_by_value = (
                    gather_key
                    if gather_key is not None
                    else (gather_selector.extract(destination_payload) if gather_selector else None)
                )
                _record_correlation_row(
                    status_code="matched",
                    tracking_id=tracking_id,
                    event_id=tracking_id,
                    is_success=True,
                    is_failure=False,
                    gather_by_value=gather_by_value,
                    source_timestamp_utc=source_timestamp,
                    destination_timestamp_utc=destination_timestamp,
                    latency_ms=float(latency_ms),
                )

            def on_timeout(self, tracking_id: str, _source_payload: Dict[str, Any]) -> None:
                message = f"TrackingId `{tracking_id}` timed out."
                _record_failed_response(
                    status_code="timeout",
                    tracking_id=tracking_id,
                    event_id=tracking_id,
                    message=message,
                )
                _record_correlation_row(
                    status_code="timeout",
                    tracking_id=tracking_id,
                    event_id=tracking_id,
                    is_success=False,
                    is_failure=timeout_counts_as_failure,
                    message=message,
                )

        runtime = CrossPlatformTrackingRuntime(
            source_tracking_field=source_endpoint.tracking_field,
            destination_tracking_field=destination_endpoint.tracking_field if destination_endpoint else None,
            destination_gather_by_field=destination_endpoint.gather_by_field if destination_endpoint else None,
            tracking_field_value_case_sensitive=self._as_bool(
                self._pick_value(
                    tracking,
                    "TrackingFieldValueCaseSensitive",
                    "trackingFieldValueCaseSensitive",
                ),
                True,
            ),
            gather_by_field_value_case_sensitive=self._as_bool(
                self._pick_value(
                    tracking,
                    "GatherByFieldValueCaseSensitive",
                    "gatherByFieldValueCaseSensitive",
                ),
                True,
            ),
            correlation_timeout_ms=max(int(timeout_seconds * 1000), 1),
            timeout_counts_as_failure=timeout_counts_as_failure,
            store=correlation_store,
            plugins=[_CorrelationReportPlugin()],
        )
        source_only_mode = run_mode == "sourceonly"
        restart_on_fail = self._as_bool(
            self._pick_value(scenario, "RestartIterationOnFail", "restartIterationOnFail"),
            False,
        )
        restart_max_attempts = max(
            self._as_int(
                self._pick_value(
                    context,
                    "RestartIterationMaxAttempts",
                    "restartIterationMaxAttempts",
                )
            ),
            0,
        )
        max_fail_count = max(
            self._as_int(self._pick_value(scenario, "MaxFailCount", "maxFailCount")),
            0,
        )
        scenario_completion_timeout_seconds = max(
            self._as_float(
                self._pick_value(
                    context,
                    "ScenarioCompletionTimeoutSeconds",
                    "scenarioCompletionTimeoutSeconds",
                )
            ),
            0.0,
        )
        scenario_deadline_ms = (
            int(time.time() * 1000) + int(scenario_completion_timeout_seconds * 1000)
            if scenario_completion_timeout_seconds > 0
            else None
        )

        actual_request_count = 0
        ok_count = 0
        fail_count = 0
        now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        last_sweep_ms = now_ms

        def _apply_timeout_expired(expired_count: int) -> None:
            nonlocal actual_request_count, ok_count, fail_count
            if expired_count <= 0:
                return
            actual_request_count += expired_count
            if timeout_counts_as_failure:
                fail_count += expired_count
            else:
                ok_count += expired_count

        for i in range(request_count):
            if scenario_deadline_ms is not None and int(time.time() * 1000) > scenario_deadline_ms:
                break

            restart_attempts_left = restart_max_attempts
            iteration_complete = False
            while not iteration_complete:
                if scenario_deadline_ms is not None and int(time.time() * 1000) > scenario_deadline_ms:
                    iteration_complete = True
                    break

                source_payload = (
                    source_adapter.consume()
                    if run_mode == "correlateexistingtraffic"
                    else source_adapter.produce()
                )
                if isinstance(source_payload, dict) and source_payload.get("__delegateSuccess") is False:
                    if restart_on_fail and restart_attempts_left > 0:
                        restart_attempts_left -= 1
                        now_ms += 1
                        continue

                    source_error = str(
                        source_payload.get("__delegateErrorMessage")
                        or "Delegate stream producer reported an unknown failure."
                    )
                    _record_failed_response(
                        status_code="source_error",
                        tracking_id=None,
                        message=source_error,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    _record_correlation_row(
                        status_code="source_error",
                        tracking_id=None,
                        is_success=False,
                        is_failure=True,
                        message=source_error,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    actual_request_count += 1
                    fail_count += 1
                    iteration_complete = True
                    now_ms += 1
                    break
                normalized_source = self._normalize_payload(source_payload, source_endpoint, i)
                if source_only_mode or destination_adapter is None or destination_endpoint is None:
                    source_tracking_id = self._read_tracking_id(
                        normalized_source,
                        source_endpoint.tracking_field,
                    )
                else:
                    source_tracking_id = runtime.on_source_produced(normalized_source, now_ms)
                if not source_tracking_id:
                    if restart_on_fail and restart_attempts_left > 0:
                        restart_attempts_left -= 1
                        now_ms += 1
                        continue

                    source_error = "Source endpoint did not produce a valid tracking id."
                    _record_failed_response(
                        status_code="source_error",
                        tracking_id=None,
                        message=source_error,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    _record_correlation_row(
                        status_code="source_error",
                        tracking_id=None,
                        is_success=False,
                        is_failure=True,
                        message=source_error,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    actual_request_count += 1
                    fail_count += 1
                    iteration_complete = True
                    now_ms += 1
                    break

                if source_only_mode or destination_adapter is None or destination_endpoint is None:
                    _record_correlation_row(
                        status_code="source_success",
                        tracking_id=source_tracking_id,
                        event_id=source_tracking_id,
                        is_success=True,
                        is_failure=False,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    actual_request_count += 1
                    ok_count += 1
                    iteration_complete = True
                    now_ms += 1
                    break

                deadline_ms = now_ms + max(int(timeout_seconds * 1000), 1)
                matched = False
                normalized_destination: Optional[Dict[str, Any]] = None
                while int(time.time() * 1000) <= deadline_ms:
                    destination_payload = destination_adapter.consume()
                    if destination_payload is None:
                        now_ms += 1
                        continue
                    normalized_destination = self._normalize_payload(destination_payload, destination_endpoint, i)
                    if runtime.on_destination_consumed(normalized_destination, now_ms + 1):
                        actual_request_count += 1
                        ok_count += 1
                        iteration_complete = True
                        matched = True
                        break
                    break

                if matched:
                    now_ms += 1
                    continue

                if normalized_destination is None:
                    if restart_on_fail and restart_attempts_left > 0:
                        restart_attempts_left -= 1
                        now_ms += 1
                        continue

                    timeout_message = "Timeout waiting for correlated destination event."
                    _record_failed_response(
                        status_code="timeout",
                        tracking_id=source_tracking_id,
                        message=timeout_message,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    _record_correlation_row(
                        status_code="timeout",
                        tracking_id=source_tracking_id,
                        is_success=False,
                        is_failure=True,
                        message=timeout_message,
                        source_timestamp_utc=_utc_from_ms(now_ms),
                    )
                    actual_request_count += 1
                    fail_count += 1
                    iteration_complete = True
                    now_ms += 1
                    continue

                if restart_on_fail and restart_attempts_left > 0:
                    restart_attempts_left -= 1
                    now_ms += 2
                    continue

                destination_tracking_id = self._read_tracking_id(
                    normalized_destination,
                    destination_endpoint.tracking_field,
                )
                gather_by_value = gather_selector.extract(normalized_destination) if gather_selector else None
                unmatched_message = (
                    f"Destination event `{destination_tracking_id or ''}` had no matching source event."
                )
                _record_failed_response(
                    status_code="unmatched_destination",
                    tracking_id=destination_tracking_id,
                    message=unmatched_message,
                    destination_timestamp_utc=_utc_from_ms(now_ms + 1),
                )
                _record_correlation_row(
                    status_code="unmatched_destination",
                    tracking_id=destination_tracking_id,
                    is_success=False,
                    is_failure=True,
                    gather_by_value=gather_by_value,
                    message=unmatched_message,
                    destination_timestamp_utc=_utc_from_ms(now_ms + 1),
                )
                actual_request_count += 1
                fail_count += 1
                iteration_complete = True
                now_ms += 2

            if (
                timeout_sweep_interval_ms is not None
                and (now_ms - last_sweep_ms) >= timeout_sweep_interval_ms
            ):
                expired = runtime.sweep_timeouts(
                    now_ms,
                    timeout_batch_size if timeout_batch_size > 0 else None,
                )
                _apply_timeout_expired(expired)
                last_sweep_ms = now_ms
            if max_fail_count > 0 and fail_count >= max_fail_count:
                break

        timeout_cutoff_ms = now_ms + int(timeout_seconds * 1000) + 1
        if timeout_batch_size > 0:
            while True:
                expired = runtime.sweep_timeouts(timeout_cutoff_ms, timeout_batch_size)
                _apply_timeout_expired(expired)
                if expired <= 0 or expired < timeout_batch_size:
                    break
        else:
            expired = runtime.sweep_timeouts(timeout_cutoff_ms)
            _apply_timeout_expired(expired)

        return {"requestCount": actual_request_count, "okCount": ok_count, "failCount": fail_count}

    def _map_endpoint_spec(self, spec: Dict[str, Any]) -> EndpointDefinition:
        poll_interval_seconds = self._as_float(
            self._pick_value(spec, "PollIntervalSeconds", "pollIntervalSeconds")
        )
        poll_interval_ms = (
            int(poll_interval_seconds * 1000)
            if poll_interval_seconds > 0
            else self._as_int(self._pick_value(spec, "PollIntervalMs", "pollIntervalMs")) or 250
        )

        http_spec = self._as_dict(self._pick_value(spec, "Http", "http"))
        http_options = None
        if http_spec:
            http_auth_spec = self._as_dict(self._pick_value(http_spec, "Auth", "auth"))
            oauth_spec = self._as_dict(
                self._pick_value(
                    http_auth_spec,
                    "OAuth2ClientCredentials",
                    "oauth2ClientCredentials",
                )
            )
            oauth_scopes = self._normalize_string_list(
                self._pick_value(oauth_spec, "Scopes", "scopes")
            )
            auth_scopes = self._normalize_string_list(
                self._pick_value(http_auth_spec, "Scopes", "scopes")
            )
            resolved_scopes = oauth_scopes or auth_scopes
            additional_form_fields = self._as_string_map(
                self._pick_value(oauth_spec, "AdditionalFormFields", "additionalFormFields")
            )
            raw_tracking_payload_source = str(
                self._pick_value(
                    http_spec,
                    "TrackingPayloadSource",
                    "trackingPayloadSource",
                )
                or ""
            ).strip()
            raw_response_source = str(
                self._pick_value(
                    http_spec,
                    "ResponseSource",
                    "responseSource",
                )
                or ""
            ).strip()
            response_source = raw_response_source or "None"
            tracking_payload_source = raw_tracking_payload_source or "Request"
            if not raw_response_source and raw_tracking_payload_source.lower() in {
                "none",
                "responsebody",
                "responseheaders",
                "responsestatuscode",
            }:
                # Backward compatibility: older configs used TrackingPayloadSource
                # for what is now the dedicated ResponseSource option.
                response_source = raw_tracking_payload_source
                tracking_payload_source = "Request"

            http_options = HttpEndpointOptions(
                url=str(self._pick_value(http_spec, "Url", "url") or ""),
                method=str(self._pick_value(http_spec, "Method", "method") or "POST"),
                body_type=str(self._pick_value(http_spec, "BodyType", "bodyType") or "Json"),
                response_source=response_source,
                tracking_payload_source=tracking_payload_source,
                consume_array_path=str(
                    self._pick_value(http_spec, "ConsumeArrayPath", "consumeArrayPath") or ""
                )
                or None,
                consume_json_array_response=self._as_bool(
                    self._pick_value(
                        http_spec,
                        "ConsumeJsonArrayResponse",
                        "consumeJsonArrayResponse",
                    ),
                    False,
                ),
                request_timeout_seconds=self._as_float(
                    self._pick_value(
                        http_spec,
                        "RequestTimeoutSeconds",
                        "requestTimeoutSeconds",
                    )
                )
                or None,
                auth=(
                    HttpAuthOptions(
                        mode=str(
                            self._pick_value(http_auth_spec, "Type", "type", "Mode", "mode")
                            or "None"
                        ),
                        type=str(
                            self._pick_value(http_auth_spec, "Type", "type", "Mode", "mode")
                            or "None"
                        ),
                        username=str(
                            self._pick_value(http_auth_spec, "Username", "username") or ""
                        )
                        or None,
                        password=str(
                            self._pick_value(http_auth_spec, "Password", "password") or ""
                        )
                        or None,
                        bearer_token=str(
                            self._pick_value(
                                http_auth_spec,
                                "BearerToken",
                                "bearerToken",
                            )
                            or ""
                        )
                        or None,
                        token_url=str(
                            self._pick_value(
                                oauth_spec,
                                "TokenEndpoint",
                                "tokenEndpoint",
                                "TokenUrl",
                                "tokenUrl",
                            )
                            or self._pick_value(http_auth_spec, "TokenUrl", "tokenUrl")
                            or ""
                        )
                        or None,
                        client_id=str(
                            self._pick_value(oauth_spec, "ClientId", "clientId")
                            or self._pick_value(http_auth_spec, "ClientId", "clientId")
                            or ""
                        )
                        or None,
                        client_secret=str(
                            self._pick_value(oauth_spec, "ClientSecret", "clientSecret")
                            or self._pick_value(http_auth_spec, "ClientSecret", "clientSecret")
                            or ""
                        )
                        or None,
                        scope=str(self._pick_value(http_auth_spec, "Scope", "scope") or "") or None,
                        scopes=resolved_scopes or None,
                        audience=str(self._pick_value(http_auth_spec, "Audience", "audience") or "")
                        or None,
                        additional_form_fields=additional_form_fields,
                        oauth2_client_credentials=(
                            HttpOAuth2ClientCredentialsOptions(
                                token_endpoint=str(
                                    self._pick_value(oauth_spec, "TokenEndpoint", "tokenEndpoint")
                                    or ""
                                )
                                or None,
                                client_id=str(
                                    self._pick_value(oauth_spec, "ClientId", "clientId")
                                    or ""
                                )
                                or None,
                                client_secret=str(
                                    self._pick_value(oauth_spec, "ClientSecret", "clientSecret")
                                    or ""
                                )
                                or None,
                                scopes=resolved_scopes or None,
                                additional_form_fields=additional_form_fields,
                            )
                            if oauth_spec
                            else None
                        ),
                    )
                    if http_auth_spec
                    else None
                ),
            )

        delegate_spec = self._as_dict(self._pick_value(spec, "delegate", "Delegate", "DelegateStream"))
        delegate_options = None
        delegate_produce = self._pick_value(delegate_spec, "produce", "Produce")
        delegate_consume = self._pick_value(delegate_spec, "consume", "Consume")
        delegate_produce_async = self._pick_value(delegate_spec, "ProduceAsync", "produceAsync")
        delegate_consume_async = self._pick_value(delegate_spec, "ConsumeAsync", "consumeAsync")
        if (
            callable(delegate_produce)
            or callable(delegate_consume)
            or callable(delegate_produce_async)
            or callable(delegate_consume_async)
        ):
            delegate_options = DelegateEndpointOptions(
                produce=delegate_produce if callable(delegate_produce) else None,
                consume=delegate_consume if callable(delegate_consume) else None,
                produce_async=delegate_produce_async if callable(delegate_produce_async) else None,
                consume_async=delegate_consume_async if callable(delegate_consume_async) else None,
            )
        payload_type = str(self._pick_value(spec, "MessagePayloadType", "messagePayloadType") or "").strip()
        serializer_settings = self._as_dict(
            self._pick_value(spec, "JsonSerializerSettings", "jsonSerializerSettings", "JsonSettings")
        )
        convert_settings = self._as_dict(
            self._pick_value(spec, "JsonConvertSettings", "jsonConvertSettings", "ConvertSettings")
        )

        endpoint = EndpointDefinition(
            kind=str(self._pick_value(spec, "Kind", "kind") or "DelegateStream"),
            mode=str(self._pick_value(spec, "Mode", "mode") or "Produce"),
            name=str(self._pick_value(spec, "Name", "name") or "endpoint"),
            tracking_field=str(
                self._pick_value(spec, "TrackingField", "trackingField") or "header:x-correlation-id"
            ),
            gather_by_field=(
                str(self._pick_value(spec, "GatherByField", "gatherByField") or "").strip() or None
            ),
            auto_generate_tracking_id_when_missing=self._as_bool(
                self._pick_value(
                    spec,
                    "AutoGenerateTrackingIdWhenMissing",
                    "autoGenerateTrackingIdWhenMissing",
                ),
                True,
            ),
            poll_interval_ms=poll_interval_ms,
            message_headers=self._as_string_map(self._pick_value(spec, "MessageHeaders", "messageHeaders")),
            message_payload=self._normalize_payload_value(
                self._pick_value(spec, "MessagePayload", "messagePayload"),
                payload_type,
                serializer_settings,
                convert_settings,
            ),
            message_payload_type=payload_type or None,
            json_serializer_settings=serializer_settings,
            json_convert_settings=convert_settings,
            content_type=str(self._pick_value(spec, "ContentType", "contentType") or "application/json"),
            http=http_options,
            kafka=self._as_dict(self._pick_value(spec, "Kafka", "kafka")) or None,
            rabbit_mq=self._as_dict(self._pick_value(spec, "RabbitMq", "rabbitMq")) or None,
            nats=self._as_dict(self._pick_value(spec, "Nats", "nats")) or None,
            redis_streams=self._as_dict(self._pick_value(spec, "RedisStreams", "redisStreams")) or None,
            azure_event_hubs=self._as_dict(self._pick_value(spec, "AzureEventHubs", "azureEventHubs")) or None,
            push_diffusion=self._as_dict(self._pick_value(spec, "PushDiffusion", "pushDiffusion")) or None,
            delegate=delegate_options,
            connection_metadata=self._as_string_map(
                self._pick_value(spec, "ConnectionMetadata", "connectionMetadata")
                or self._pick_value(delegate_spec, "ConnectionMetadata", "connectionMetadata")
            ),
        )

        return endpoint

    def _normalize_payload(
        self,
        payload: Optional[Dict[str, Any]],
        endpoint: EndpointDefinition,
        index: int,
    ) -> Dict[str, Any]:
        normalized_payload: Dict[str, Any] = {
            "headers": {
                **(endpoint.message_headers or {}),
                **((payload or {}).get("headers", {}) if isinstance(payload, dict) else {}),
            },
            "body": (
                (payload or {}).get("body")
                if isinstance(payload, dict)
                else endpoint.message_payload
            ),
            "producedUtc": (payload or {}).get("producedUtc") if isinstance(payload, dict) else None,
            "contentType": (
                (payload or {}).get("contentType")
                if isinstance(payload, dict)
                else endpoint.content_type
            ),
        }
        if normalized_payload["body"] is None:
            normalized_payload["body"] = endpoint.message_payload
        normalized_payload["body"] = self._normalize_payload_value(
            normalized_payload.get("body"),
            endpoint.message_payload_type,
            endpoint.json_serializer_settings,
            endpoint.json_convert_settings,
        )

        selector = endpoint.tracking_field.strip()
        if not selector:
            return normalized_payload

        existing = self._read_tracking_id(normalized_payload, selector)
        if existing or not endpoint.auto_generate_tracking_id_when_missing:
            return normalized_payload

        generated = f"{endpoint.name}-auto-{index + 1}"
        selector_lower = selector.lower()
        if selector_lower.startswith("header:"):
            header_name = selector[len("header:") :].strip()
            if header_name:
                headers = normalized_payload.get("headers", {})
                if not isinstance(headers, dict):
                    headers = {}
                headers[header_name] = generated
                normalized_payload["headers"] = headers
            return normalized_payload

        if selector_lower.startswith("json:"):
            path = selector[len("json:") :].strip()
            if path.startswith("$."):
                path = path[2:]
            normalized_payload["body"] = self._set_json_path_value(
                normalized_payload.get("body"),
                path,
                generated,
            )

        return normalized_payload

    def _read_tracking_id(self, payload: Dict[str, Any], selector: str) -> Optional[str]:
        selector_lower = selector.strip().lower()

        if selector_lower.startswith("header:"):
            expected = selector[len("header:") :].strip()
            headers = payload.get("headers", {})
            if isinstance(headers, dict):
                for key, value in headers.items():
                    if str(key) == expected:
                        parsed = str(value).strip()
                        if parsed:
                            return parsed
            return None

        if selector_lower.startswith("json:"):
            path = selector[len("json:") :].strip()
            if path.startswith("$."):
                path = path[2:]
            body = self._parse_json_body_object(payload.get("body"))
            if not isinstance(body, dict):
                return None

            current: Any = body
            for segment in [x for x in path.split(".") if x]:
                if isinstance(current, dict) and segment in current:
                    current = current[segment]
                else:
                    return None
            if current is None:
                return None
            return str(current)

        return None

    @staticmethod
    def _set_json_path_value(body: Any, path: str, value: str) -> Dict[str, Any]:
        if isinstance(body, dict):
            target: Dict[str, Any] = dict(body)
        else:
            target = {}

        segments = [x for x in path.split(".") if x]
        if not segments:
            return target

        current: Dict[str, Any] = target
        for segment in segments[:-1]:
            node = current.get(segment)
            if not isinstance(node, dict):
                node = {}
                current[segment] = node
            current = node

        current[segments[-1]] = value
        return target

    def _map_correlation_store(self, tracking: Dict[str, Any]) -> Optional[RedisCorrelationStore]:
        store_spec = self._as_dict(self._pick_value(tracking, "CorrelationStore", "correlationStore"))
        kind = str(self._pick_value(store_spec, "Kind", "kind") or "").strip().lower()
        redis_spec = self._as_dict(self._pick_value(store_spec, "Redis", "redis"))
        use_redis = kind in {"redis", "rediscorrelationstore"} or bool(redis_spec)
        if not use_redis:
            return None

        key_prefix = str(self._pick_value(redis_spec, "KeyPrefix", "keyPrefix") or "loadstrike")
        ttl_seconds = max(
            self._as_float(self._pick_value(redis_spec, "EntryTtlSeconds", "entryTtlSeconds", "EntryTtl", "entryTtl")),
            0.0,
        )
        return RedisCorrelationStore(
            prefix=key_prefix,
            entry_ttl_ms=int(ttl_seconds * 1000) if ttl_seconds > 0 else 0,
        )

    def _normalize_payload_value(
        self,
        value: Any,
        payload_type: Optional[str] = None,
        serializer_settings: Optional[Dict[str, Any]] = None,
        convert_settings: Optional[Dict[str, Any]] = None,
    ) -> Any:
        if value is None:
            return None

        normalized_type = str(payload_type or "").strip().lower()
        serializer_settings = dict(serializer_settings or {})
        convert_settings = dict(convert_settings or {})

        if isinstance(value, bytes):
            try:
                value = value.decode("utf-8")
            except Exception:  # noqa: BLE001
                return value

        if isinstance(value, str):
            text = value.strip()
            if not text:
                return value
            if normalized_type in {"text", "string"}:
                return value
            if normalized_type == "number":
                try:
                    return float(text)
                except ValueError:
                    return value
            if normalized_type == "boolean":
                lowered = text.lower()
                if lowered in {"true", "1", "yes"}:
                    return True
                if lowered in {"false", "0", "no"}:
                    return False
                return value
            if normalized_type == "base64":
                try:
                    return base64.b64decode(text.encode("ascii")).decode("utf-8")
                except Exception:  # noqa: BLE001
                    return value

            prefers_json = normalized_type in {"json", "object", "auto", ""}
            if not prefers_json:
                return value

            strict = self._try_parse_json(text)
            if strict is not None:
                return strict

            allow_relaxed = self._as_bool(
                self._pick_value(
                    serializer_settings,
                    "AllowTrailingCommas",
                    "allowTrailingCommas",
                    "AllowSingleQuotes",
                    "allowSingleQuotes",
                ),
                True,
            ) or self._as_bool(
                self._pick_value(
                    convert_settings,
                    "AllowTrailingCommas",
                    "allowTrailingCommas",
                    "AllowSingleQuotes",
                    "allowSingleQuotes",
                ),
                True,
            )
            if not allow_relaxed:
                return value
            relaxed = self._sanitize_loose_json(text)
            parsed = self._try_parse_json(relaxed)
            return parsed if parsed is not None else value

        return value

    def _parse_json_body_object(self, value: Any) -> Optional[Dict[str, Any]]:
        if isinstance(value, dict):
            return value
        parsed = self._normalize_payload_value(value, "json")
        if isinstance(parsed, dict):
            return parsed
        return None

    @staticmethod
    def _try_parse_json(value: str) -> Any:
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return None

    @staticmethod
    def _sanitize_loose_json(value: str) -> str:
        text = value.strip()
        text = re.sub(r",\s*([}\]])", r"\1", text)
        text = re.sub(
            r"'([^']*)'",
            lambda match: '"' + match.group(1).replace('"', '\\"') + '"',
            text,
        )
        return text

    def _compute_scenario_request_count(self, scenario: Dict[str, Any]) -> int:
        simulations = scenario.get("LoadSimulations", [])
        if not isinstance(simulations, list):
            return 0

        total = 0
        for item in simulations:
            simulation = item if isinstance(item, dict) else {}
            kind = str(simulation.get("Kind", ""))
            rate = self._as_int(simulation.get("Rate"))
            min_rate = self._as_int(simulation.get("MinRate"))
            max_rate = self._as_int(simulation.get("MaxRate"))
            copies = max(self._as_int(simulation.get("Copies")), 1)
            iterations = max(self._as_int(simulation.get("Iterations")), 0)
            interval_seconds = max(self._as_float(simulation.get("IntervalSeconds")), 1.0)
            during_seconds = max(self._as_float(simulation.get("DuringSeconds")), 0.0)

            if kind == "IterationsForConstant":
                total += copies * iterations
            elif kind == "IterationsForInject":
                total += iterations
            elif kind == "Inject":
                total += int((during_seconds / interval_seconds) * max(rate, 0) + 0.999999)
            elif kind == "InjectRandom":
                total += int(
                    (during_seconds / interval_seconds) * ((max(min_rate, 0) + max(max_rate, 0)) / 2.0)
                    + 0.999999
                )
            elif kind == "RampingInject":
                total += int((during_seconds / interval_seconds) * max(rate, 0) * 0.5 + 0.999999)
            elif kind == "KeepConstant":
                total += int(during_seconds + 0.999999) * copies
            elif kind == "RampingConstant":
                total += int(during_seconds + 0.999999) * max(int(copies * 0.5 + 0.999999), 1)

        return max(total, 0)

    def _build_node_stats_contract(
        self,
        context: Dict[str, Any],
        created_utc: datetime,
        completed_utc: datetime,
        all_request_count: int,
        all_ok_count: int,
        all_fail_count: int,
        scenario_rows: List[Dict[str, Any]],
        threshold_results: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        duration_ms = max((completed_utc - created_utc).total_seconds() * 1000.0, 0.0)
        return {
            "AllBytes": 0,
            "AllRequestCount": all_request_count,
            "AllOkCount": all_ok_count,
            "AllFailCount": all_fail_count,
            "DurationMs": duration_ms,
            "NodeInfo": self._build_node_info_contract(context),
            "TestInfo": self._build_test_info_contract(context, created_utc),
            "Metrics": {
                "DurationMs": 0.0,
                "Counters": [],
                "Gauges": [],
            },
            "Scenarios": scenario_rows,
            "Thresholds": threshold_results,
            "Plugins": [],
        }

    def _build_scenario_stats_contract_row(
        self,
        scenario_name: str,
        sort_index: int,
        request_count: int,
        ok_count: int,
        fail_count: int,
        duration_ms: int,
    ) -> Dict[str, Any]:
        return {
            "ScenarioName": scenario_name,
            "SortIndex": sort_index,
            "AllBytes": 0,
            "AllRequestCount": request_count,
            "AllOkCount": ok_count,
            "AllFailCount": fail_count,
            "CurrentOperation": "Complete",
            "DurationMs": float(duration_ms),
            "Ok": self._build_measurement_stats_contract(ok_count, request_count, duration_ms),
            "Fail": self._build_measurement_stats_contract(fail_count, request_count, duration_ms),
            "Steps": [],
        }

    def _build_measurement_stats_contract(
        self,
        count: int,
        total_count: int,
        duration_ms: int,
    ) -> Dict[str, Any]:
        percent = int(round((100.0 * count) / total_count)) if total_count > 0 else 0
        return {
            "Request": {
                "Count": count,
                "Percent": percent,
                "Rps": 0.0 if duration_ms <= 0 else count / (duration_ms / 1000.0),
            },
            "Latency": {
                "MinMs": 0.0,
                "MeanMs": 0.0,
                "MaxMs": 0.0,
                "StdDev": 0.0,
                "Percent50": 0.0,
                "Percent75": 0.0,
                "Percent95": 0.0,
                "Percent99": 0.0,
            },
            "DataTransfer": {
                "AllBytes": 0,
                "MinBytes": 0,
                "MeanBytes": 0,
                "MaxBytes": 0,
                "StdDev": 0.0,
                "Percent50": 0,
                "Percent75": 0,
                "Percent95": 0,
                "Percent99": 0,
            },
            "StatusCodes": [],
        }

    def _build_node_info_contract(self, context: Dict[str, Any]) -> Dict[str, Any]:
        cores_count = os.cpu_count() or 1
        os_name = platform.system().strip()
        os_release = platform.release().strip()
        operating_system = os_name if not os_release else (os_name + " " + os_release if os_name else os_release)
        processor = (platform.processor() or platform.machine() or "unknown").strip() or "unknown"
        return {
            "CoresCount": max(int(cores_count), 1),
            "CurrentOperation": "Complete",
            "DotNetVersion": platform.python_version(),
            "MachineName": socket.gethostname(),
            "EngineVersion": "loadstrike-py-sdk",
            "NodeType": self._to_contract_node_type(self._pick_value(context, "NodeType", "nodeType")),
            "OS": operating_system,
            "Processor": processor,
        }

    def _build_test_info_contract(self, context: Dict[str, Any], created_utc: datetime) -> Dict[str, Any]:
        return {
            "ClusterId": str(self._pick_value(context, "ClusterId", "clusterId") or "local"),
            "CreatedUtc": created_utc,
            "SessionId": str(self._pick_value(context, "SessionId", "sessionId") or ""),
            "TestName": str(self._pick_value(context, "TestName", "testName") or ""),
            "TestSuite": str(self._pick_value(context, "TestSuite", "testSuite") or ""),
        }

    def _evaluate_thresholds(
        self,
        scenario: Dict[str, Any],
        scenario_name: str,
        request_count: int,
        ok_count: int,
        fail_count: int,
        duration_ms: int,
    ) -> List[Dict[str, Any]]:
        thresholds = scenario.get("Thresholds", [])
        if not isinstance(thresholds, list):
            return []

        results: List[Dict[str, Any]] = []
        for item in thresholds:
            threshold = item if isinstance(item, dict) else {}
            scope = str(threshold.get("Scope", "")).lower()
            step_name = str(threshold.get("StepName", ""))
            field = str(threshold.get("Field", "")).lower()
            operator = str(threshold.get("Operator", "")).lower()
            expected = self._as_float(threshold.get("Value"))
            abort_when_error_count = threshold.get("AbortWhenErrorCount")
            start_check_after_seconds = max(
                self._as_float(self._pick_value(threshold, "StartCheckAfterSeconds", "startCheckAfterSeconds")),
                0.0,
            )
            check_expression = self._build_threshold_expression(scope, step_name)

            if start_check_after_seconds > 0 and duration_ms < int(start_check_after_seconds * 1000):
                results.append(
                    {
                        "ScenarioName": scenario_name,
                        "StepName": step_name,
                        "CheckExpression": check_expression,
                        "ErrorCount": 0,
                        "IsFailed": False,
                        "ExceptionMessage": "",
                    }
                )
                continue

            if field == "allokcount":
                actual = float(ok_count)
            elif field == "allfailcount":
                actual = float(fail_count)
            elif field == "durationms":
                actual = float(duration_ms)
            else:
                actual = float(request_count)

            if scope == "step" and step_name.strip():
                error_count = 1
            else:
                failed = False
                if operator == "gt":
                    failed = not (actual > expected)
                elif operator == "gte":
                    failed = not (actual >= expected)
                elif operator == "lt":
                    failed = not (actual < expected)
                elif operator == "lte":
                    failed = not (actual <= expected)
                elif operator == "eq":
                    failed = actual != expected
                elif operator == "neq":
                    failed = actual == expected
                error_count = 1 if failed else 0
            is_failed = error_count > 0
            if abort_when_error_count is not None and error_count >= self._as_int(abort_when_error_count):
                is_failed = True

            results.append(
                {
                    "ScenarioName": scenario_name,
                    "StepName": step_name,
                    "CheckExpression": check_expression,
                    "ErrorCount": error_count,
                    "IsFailed": is_failed,
                    "ExceptionMessage": "",
                }
            )

        return results

    @staticmethod
    def _build_threshold_expression(scope: str, step_name: str) -> str:
        if scope == "step" or step_name.strip():
            return f"step-threshold:{step_name}"
        if scope == "metric":
            return "metric-threshold"
        if scope == "scenario":
            return "scenario-threshold"
        return "threshold"

    @staticmethod
    def _as_int(value: Any) -> int:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            return int(value)
        if value is None:
            return 0
        try:
            return int(str(value))
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _as_float(value: Any) -> float:
        if isinstance(value, bool):
            return float(value)
        if isinstance(value, (int, float)):
            return float(value)
        if value is None:
            return 0.0
        try:
            return float(str(value))
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _as_bool(value: Any, fallback: bool) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"true", "1", "yes"}:
                return True
            if normalized in {"false", "0", "no"}:
                return False
        return fallback

    @staticmethod
    def _as_dict(value: Any) -> Dict[str, Any]:
        if isinstance(value, dict):
            return dict(value)

        for method_name in ("to_payload", "to_dict"):
            method = getattr(value, method_name, None)
            if callable(method):
                try:
                    payload = method()
                except Exception:  # noqa: BLE001
                    payload = None
                if isinstance(payload, dict):
                    return dict(payload)

        if hasattr(value, "items") and callable(getattr(value, "items", None)):
            try:
                return {str(key): item for key, item in value.items()}
            except Exception:  # noqa: BLE001
                return {}

        return {}

    @staticmethod
    def _as_string_map(value: Any) -> Dict[str, str]:
        if not isinstance(value, dict):
            return {}
        return {str(key): str(item) for key, item in value.items() if item is not None}

    @staticmethod
    def _pick_value(record: Dict[str, Any], *keys: str) -> Any:
        for key in keys:
            if key in record:
                return record[key]
        if not isinstance(record, dict):
            return None
        normalized_lookup = {
            LoadStrikeLocalClient._normalize_key_name(str(actual_key)): actual_key
            for actual_key in record.keys()
        }
        for key in keys:
            actual_key = normalized_lookup.get(LoadStrikeLocalClient._normalize_key_name(key))
            if actual_key is not None:
                return record[actual_key]
        return None

    @staticmethod
    def _normalize_key_name(value: Any) -> str:
        return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())

    @staticmethod
    def _normalize_pem_text(value: Any) -> str:
        text = str(value or "").strip()
        if not text:
            return ""
        if len(text) >= 2 and text.startswith('"') and text.endswith('"'):
            text = text[1:-1].strip()
        text = text.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\r").strip()
        if len(text) >= 2 and text.startswith('"') and text.endswith('"'):
            text = text[1:-1].strip()
        return text

    @staticmethod
    def _normalize_base_url(configured_base_url: str) -> str:
        base_url = configured_base_url.strip() if configured_base_url else ""
        if base_url:
            return base_url
        return _DEFAULT_LICENSING_API_BASE_URL

    @classmethod
    def _resolve_base_url(cls) -> str:
        return cls._normalize_base_url(
            os.environ.get("LOADSTRIKE_LICENSING_API_BASE_URL")
            or _development_licensing_api_base_url_override
        )


def _set_internal_dev_licensing_api_base_url_override_for_tests(value: Optional[str]) -> None:
    global _development_licensing_api_base_url_override
    _development_licensing_api_base_url_override = value
