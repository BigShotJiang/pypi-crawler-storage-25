"""
mubit-adk — Google ADK BaseMemoryService backed by MuBit.

This adapter now routes MuBit calls through the canonical Python SDK transport
instead of maintaining its own raw HTTP client.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any, Optional

from .mubit_client import MubitControlClient, normalize_metadata

try:
    from google.adk.memory.base_memory_service import (
        BaseMemoryService,
        SearchMemoryResponse,
    )
    from google.adk.memory.memory_entry import MemoryEntry
    from google.adk.sessions.session import Session
    from google.adk.events.event import Event
    from google.genai import types as genai_types
except ImportError as e:
    raise ImportError("google-adk is required: pip install mubit-adk[adk]") from e


def _scope_component(value: Optional[str], fallback: str) -> str:
    component = (value or fallback).strip() or fallback
    return "-".join(component.split())


def _memory_run_id(app_name: str, user_id: str) -> str:
    app = _scope_component(app_name, "adk-agent")
    user = _scope_component(user_id, "anonymous")
    return f"adk:{app}:{user}:memory"


def _item_component(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_") else "-" for ch in value)


def _truncate(value: Any, limit: int = 2000) -> str:
    text = str(value)
    if len(text) <= limit:
        return text
    return f"{text[:limit]}... [truncated]"


def _field(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, Mapping):
        return value.get(name, default)
    return getattr(value, name, default)


def _mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(exclude_none=True)
        return dumped if isinstance(dumped, dict) else {}
    if hasattr(value, "dict"):
        dumped = value.dict(exclude_none=True)
        return dumped if isinstance(dumped, dict) else {}
    return {}


def _safe_arg_items(args: Mapping[str, Any]) -> list[str]:
    unsafe_names = ("secret", "token", "password", "credential", "key")
    sql_names = {"query", "sql", "statement"}
    items: list[str] = []
    for key, value in args.items():
        key_lower = key.lower()
        if key_lower in sql_names or any(name in key_lower for name in unsafe_names):
            continue
        if isinstance(value, (str, int, float, bool)):
            items.append(f"{key}={_truncate(value, 200)}")
    return items


def _summarize_function_call(function_call: Any) -> str:
    name = _field(function_call, "name", "tool") or "tool"
    args = _mapping(_field(function_call, "args", {}))
    lines = [f"Tool call: {name}"]
    sql = args.get("query") or args.get("sql") or args.get("statement")
    if isinstance(sql, str) and sql.strip():
        lines.append(f"SQL: {_truncate(sql)}")
    safe_args = _safe_arg_items(args)
    if safe_args:
        lines.append(f"Args: {', '.join(safe_args)}")
    return "\n".join(lines)


def _find_rows(value: Any, depth: int = 0) -> Optional[list[Any]]:
    if depth > 3:
        return None
    if isinstance(value, list):
        return value
    if isinstance(value, Mapping):
        for key in ("rows", "records", "results", "data"):
            rows = value.get(key)
            if isinstance(rows, list):
                return rows
        for nested in value.values():
            rows = _find_rows(nested, depth + 1)
            if rows is not None:
                return rows
    return None


def _row_columns(rows: list[Any]) -> list[str]:
    if not rows:
        return []
    first = rows[0]
    if isinstance(first, Mapping):
        return [str(key) for key in first.keys()]
    return []


def _summarize_function_response(function_response: Any) -> str:
    name = _field(function_response, "name", "tool") or "tool"
    response = _mapping(_field(function_response, "response", {}))
    lines = [f"Tool response: {name}"]

    status = response.get("status") or response.get("outcome")
    if status:
        lines.append(f"status={_truncate(status, 100)}")

    error = (
        response.get("error")
        or response.get("error_message")
        or response.get("exception")
    )
    if error:
        lines.append(f"error={_truncate(error)}")

    rows = _find_rows(response)
    if rows is not None:
        lines.append(f"row_count={len(rows)}")
        columns = _row_columns(rows)
        if columns:
            lines.append(f"columns={','.join(columns)}")

    for key in ("job_id", "total_rows", "total_bytes_processed", "bytes_processed"):
        value = response.get(key)
        if value is not None:
            lines.append(f"{key}={_truncate(value, 100)}")

    if len(lines) == 1 and response:
        lines.append(f"response_keys={','.join(str(key) for key in response.keys())}")

    return "\n".join(lines)


def _event_to_text(event: Event) -> str:
    parts: list[str] = []
    if hasattr(event, "content") and event.content:
        content = event.content
        if hasattr(content, "parts") and content.parts:
            for part in content.parts:
                if hasattr(part, "text") and part.text:
                    parts.append(part.text)
                function_call = getattr(part, "function_call", None)
                if function_call:
                    parts.append(_summarize_function_call(function_call))
                function_response = getattr(part, "function_response", None)
                if function_response:
                    parts.append(_summarize_function_response(function_response))
    if not parts and hasattr(event, "text") and event.text:
        parts.append(event.text)
    return "\n".join(parts)


def _memory_entry_to_text(entry: MemoryEntry) -> str:
    if hasattr(entry, "content") and entry.content:
        content = entry.content
        if hasattr(content, "parts") and content.parts:
            texts = [part.text for part in content.parts if getattr(part, "text", None)]
            if texts:
                return "\n".join(texts)
    return str(entry)


def _memory_result_text(evidence: Mapping[str, Any], metadata: Mapping[str, Any]) -> str:
    text = str(evidence.get("content") or "")
    hints: list[str] = []
    if evidence.get("score") is not None:
        hints.append(f"score={evidence.get('score')}")
    if evidence.get("evidence_type"):
        hints.append(f"type={evidence.get('evidence_type')}")
    if evidence.get("id"):
        hints.append(f"id={evidence.get('id')}")
    for key in ("source", "channel", "tool", "dataset", "table"):
        value = metadata.get(key)
        if value:
            hints.append(f"{key}={_truncate(value, 120)}")
    if not hints:
        return text
    return f"[MuBit memory: {' '.join(hints)}]\n{text}"


def _memory_timestamp(evidence: Mapping[str, Any], metadata: Mapping[str, Any]) -> Optional[str]:
    value = evidence.get("timestamp") or metadata.get("timestamp")
    return str(value) if value else None


class MubitMemoryService(BaseMemoryService):
    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:3000",
        api_key: str = "",
        mubit_client: Optional[Any] = None,
    ) -> None:
        self._client = mubit_client or MubitControlClient(
            endpoint=endpoint.rstrip("/"), api_key=api_key
        )

    async def add_session_to_memory(self, session: Session) -> None:
        if not session.events:
            return

        items: list[dict[str, Any]] = []
        for idx, event in enumerate(session.events):
            text = _event_to_text(event)
            if not text.strip():
                continue
            author = getattr(event, "author", None) or "unknown"
            item: dict[str, Any] = {
                "item_id": f"adk-{session.id}-{idx}",
                "content_type": "text/plain",
                "text": text,
                "metadata": {
                    "author": author,
                    "event_index": idx,
                    "session_id": session.id,
                },
                "user_id": session.user_id or "",
            }
            if author == "user":
                item["intent"] = "context"
            elif author == "tool":
                item["intent"] = "tool_output"
            else:
                item["intent"] = "trace"
            items.append(item)

        if not items:
            return

        self._client.ingest_items(
            session_id=session.id,
            agent_id=session.app_name or "adk-agent",
            idempotency_key=f"session-{session.id}",
            items=items,
        )

    async def search_memory(
        self,
        *,
        app_name: str,
        user_id: str,
        query: str,
    ) -> SearchMemoryResponse:
        data = self._client.recall(
            session_id=_memory_run_id(app_name, user_id),
            user_id=user_id,
            query=query,
            limit=10,
            include_working_memory=True,
            agent_id=app_name or "adk-agent",
        )
        memories: list[MemoryEntry] = []
        for ev in data.get("evidence", []):
            metadata = normalize_metadata(ev)
            content = genai_types.Content(
                parts=[genai_types.Part(text=_memory_result_text(ev, metadata))],
                role="model",
            )
            memories.append(
                MemoryEntry(
                    content=content,
                    author=metadata.get("author", "memory"),
                    timestamp=_memory_timestamp(ev, metadata),
                )
            )
        return SearchMemoryResponse(memories=memories)

    async def add_events_to_memory(
        self,
        *,
        app_name: str,
        user_id: str,
        events: Sequence[Event],
        session_id: Optional[str] = None,
        custom_metadata: Optional[Mapping[str, object]] = None,
    ) -> None:
        items: list[dict[str, Any]] = []
        for idx, event in enumerate(events):
            text = _event_to_text(event)
            if not text.strip():
                continue
            author = getattr(event, "author", None) or "unknown"
            metadata: dict[str, Any] = {"author": author, "event_index": idx}
            if custom_metadata:
                metadata.update(custom_metadata)
            item_scope = _item_component(
                session_id or _memory_run_id(app_name, user_id)
            )
            item: dict[str, Any] = {
                "item_id": f"adk-{item_scope}-evt-{idx}",
                "content_type": "text/plain",
                "text": text,
                "metadata": metadata,
                "user_id": user_id,
            }
            if author == "tool":
                item["intent"] = "tool_output"
            elif author == "user":
                item["intent"] = "context"
            else:
                item["intent"] = "trace"
            items.append(item)

        if not items:
            return

        target_session_id = session_id or _memory_run_id(app_name, user_id)
        self._client.ingest_items(
            session_id=target_session_id,
            agent_id=app_name or "adk-agent",
            idempotency_key=f"events-{target_session_id}",
            items=items,
        )

    async def add_memory(
        self,
        *,
        app_name: str,
        user_id: str,
        memories: Sequence[MemoryEntry],
        custom_metadata: Optional[Mapping[str, object]] = None,
    ) -> None:
        items: list[dict[str, Any]] = []
        for idx, entry in enumerate(memories):
            text = _memory_entry_to_text(entry)
            if not text.strip():
                continue
            metadata: dict[str, Any] = dict(getattr(entry, "custom_metadata", None) or {})
            if custom_metadata:
                metadata.update(custom_metadata)
            if entry.author:
                metadata["author"] = entry.author
            if getattr(entry, "timestamp", None):
                metadata["timestamp"] = entry.timestamp
            items.append(
                {
                    "item_id": getattr(entry, "id", None) or f"adk-mem-{idx}",
                    "content_type": "text/plain",
                    "text": text,
                    "metadata": metadata,
                    "user_id": user_id,
                    "intent": "fact",
                }
            )

        if not items:
            return

        target_session_id = _memory_run_id(app_name, user_id)
        self._client.ingest_items(
            session_id=target_session_id,
            agent_id=app_name or "adk-agent",
            idempotency_key=f"memory-{target_session_id}",
            items=items,
        )

    async def checkpoint(
        self,
        *,
        app_name: str,
        user_id: str,
        snapshot: str,
        session_id: Optional[str] = None,
        label: str = "",
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        return self._client.checkpoint(
            session_id=session_id or "default",
            user_id=user_id,
            snapshot=snapshot,
            label=label,
            metadata=metadata,
            agent_id=app_name or "adk-agent",
        )

    async def record_outcome(
        self,
        *,
        app_name: str,
        user_id: str,
        reference_id: str,
        outcome: str,
        signal: Optional[float] = None,
        rationale: str = "",
        session_id: Optional[str] = None,
    ) -> dict[str, Any]:
        return self._client.record_outcome(
            session_id=session_id or "default",
            user_id=user_id,
            reference_id=reference_id,
            outcome=outcome,
            signal=signal,
            rationale=rationale,
            agent_id=app_name or "adk-agent",
        )

    async def record_step_outcome(
        self,
        *,
        app_name: str,
        user_id: str,
        step_id: str,
        step_name: str,
        outcome: str,
        signal: Optional[float] = None,
        rationale: str = "",
        directive_hint: str = "",
        session_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        return self._client.record_step_outcome(
            session_id=session_id or _memory_run_id(app_name, user_id),
            user_id=user_id,
            step_id=step_id,
            step_name=step_name,
            outcome=outcome,
            signal=signal,
            rationale=rationale,
            directive_hint=directive_hint,
            agent_id=app_name or "adk-agent",
            metadata=metadata,
        )

    async def archive(
        self,
        *,
        app_name: str,
        user_id: str,
        content: str,
        artifact_kind: str,
        session_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
        agent_id: Optional[str] = None,
        origin_agent_id: Optional[str] = None,
        source_attempt_id: Optional[str] = None,
        source_tool: Optional[str] = None,
        labels: Optional[list[str]] = None,
        family: Optional[str] = None,
        importance: Optional[str] = None,
    ) -> dict[str, Any]:
        return self._client.archive(
            session_id=session_id or "default",
            user_id=user_id,
            content=content,
            artifact_kind=artifact_kind,
            metadata=metadata,
            agent_id=agent_id or app_name or "adk-agent",
            origin_agent_id=origin_agent_id,
            source_attempt_id=source_attempt_id,
            source_tool=source_tool,
            labels=labels,
            family=family,
            importance=importance,
        )

    async def dereference(
        self,
        *,
        user_id: str,
        reference_id: str,
        session_id: Optional[str] = None,
        agent_id: Optional[str] = None,
    ) -> dict[str, Any]:
        return self._client.dereference(
            session_id=session_id or "default",
            user_id=user_id,
            reference_id=reference_id,
            agent_id=agent_id,
        )

    async def surface_strategies(
        self,
        *,
        session_id: Optional[str] = None,
        lesson_types: Optional[list[str]] = None,
        max_strategies: int = 5,
    ) -> dict[str, Any]:
        return self._client.surface_strategies(
            session_id=session_id or "default",
            lesson_types=lesson_types,
            max_strategies=max_strategies,
        )

    async def get_context(
        self,
        *,
        app_name: str,
        user_id: str,
        query: str,
        session_id: Optional[str] = None,
        **kwargs,
    ):
        return self._client.get_context(
            session_id=session_id or "default",
            user_id=user_id,
            query=query,
            agent_id=app_name or "adk-agent",
            mode=kwargs.get("mode"),
            sections=kwargs.get("sections"),
            entry_types=kwargs.get("entry_types"),
            limit=kwargs.get("limit"),
            max_token_budget=kwargs.get("max_token_budget"),
        )

    async def memory_health(
        self,
        *,
        user_id: str,
        session_id: Optional[str] = None,
        limit: int = 100,
    ):
        return self._client.memory_health(
            session_id=session_id or "default",
            user_id=user_id,
            limit=limit,
        )

    async def diagnose(
        self,
        *,
        user_id: str,
        error_text: str,
        session_id: Optional[str] = None,
        error_type: Optional[str] = None,
        limit: int = 10,
    ):
        return self._client.diagnose(
            session_id=session_id or "default",
            user_id=user_id,
            error_text=error_text,
            error_type=error_type,
            limit=limit,
        )

    async def register_agent(
        self,
        *,
        user_id: str,
        session_id: Optional[str] = None,
        agent_id: str,
        role: Optional[str] = None,
        **kwargs,
    ):
        return self._client.register_agent(
            session_id=session_id or "default",
            user_id=user_id,
            agent_id=agent_id,
            role=role,
            status=kwargs.get("status"),
            read_scopes=kwargs.get("read_scopes"),
            write_scopes=kwargs.get("write_scopes"),
            shared_memory_lanes=kwargs.get("shared_memory_lanes"),
            capabilities=kwargs.get("capabilities"),
        )

    async def list_agents(self, *, user_id: str, session_id: Optional[str] = None):
        return self._client.list_agents(
            session_id=session_id or "default",
            user_id=user_id,
        )

    async def handoff(
        self,
        *,
        user_id: str,
        session_id: Optional[str] = None,
        from_agent_id: str,
        to_agent_id: str,
        content: str,
        **kwargs,
    ):
        task_id = kwargs.get("task_id") or f"{from_agent_id}-to-{to_agent_id}"
        return self._client.handoff(
            session_id=session_id or "default",
            user_id=user_id,
            task_id=task_id,
            from_agent_id=from_agent_id,
            to_agent_id=to_agent_id,
            content=content,
            requested_action=kwargs.get("requested_action"),
            metadata=kwargs.get("metadata"),
        )

    async def feedback(
        self,
        *,
        user_id: str,
        session_id: Optional[str] = None,
        handoff_id: str,
        verdict: str,
        **kwargs,
    ):
        return self._client.feedback(
            session_id=session_id or "default",
            user_id=user_id,
            handoff_id=handoff_id,
            verdict=verdict,
            comments=kwargs.get("comments"),
            from_agent_id=kwargs.get("from_agent_id"),
            metadata=kwargs.get("metadata"),
        )

    async def close(self) -> None:
        return None


def _callback_invocation_context(callback_context: Any) -> Any:
    return getattr(callback_context, "_invocation_context", None)


def _callback_memory_service(callback_context: Any, memory_service: Any) -> Any:
    if memory_service is not None:
        return memory_service
    invocation_context = _callback_invocation_context(callback_context)
    return getattr(invocation_context, "memory_service", None)


def _callback_scope(callback_context: Any) -> tuple[str, str, str]:
    invocation_context = _callback_invocation_context(callback_context)
    session = getattr(invocation_context, "session", None)
    app_name = getattr(invocation_context, "app_name", None) or "adk-agent"
    user_id = getattr(invocation_context, "user_id", None) or ""
    session_id = getattr(session, "id", None) or _memory_run_id(app_name, user_id)
    return app_name, user_id, session_id


def _tool_name(tool: Any) -> str:
    return (
        getattr(tool, "name", None)
        or getattr(tool, "__name__", None)
        or tool.__class__.__name__
    )


def _looks_like_bigquery_tool(tool_name: str, args: Mapping[str, Any]) -> bool:
    name = tool_name.lower()
    known_names = (
        "bigquery",
        "execute_sql",
        "sql",
        "query",
        "dataset",
        "table",
    )
    if any(known in name for known in known_names):
        return True
    return any(key.lower() in {"query", "sql", "statement"} for key in args.keys())


def _response_error(response: Any) -> Optional[str]:
    data = _mapping(response)
    status = str(data.get("status") or data.get("outcome") or "").lower()
    error = data.get("error") or data.get("error_message") or data.get("exception")
    if error:
        return _truncate(error)
    if status in {"error", "failed", "failure"}:
        return status
    return None


def _response_rationale(tool_name: str, response: Any, error: Optional[str]) -> str:
    if error:
        return f"{tool_name} failed: {error}"
    data = _mapping(response)
    rows = _find_rows(data)
    facts: list[str] = []
    if rows is not None:
        facts.append(f"row_count={len(rows)}")
    for key in ("total_bytes_processed", "bytes_processed"):
        if data.get(key) is not None:
            facts.append(f"{key}={data[key]}")
    suffix = f" ({', '.join(facts)})" if facts else ""
    return f"{tool_name} completed successfully{suffix}."


def make_session_memory_callback(
    memory_service: Optional[MubitMemoryService] = None,
    *,
    raise_on_error: bool = False,
):
    """Build an ADK ``after_agent_callback`` that persists the current session.

    The callback is fail-open by default so MuBit memory issues do not break
    the customer's ADK agent run.
    """

    async def after_agent_callback(callback_context: Any):
        try:
            invocation_context = _callback_invocation_context(callback_context)
            session = getattr(invocation_context, "session", None)
            service = _callback_memory_service(callback_context, memory_service)
            if session is not None and service is not None:
                await service.add_session_to_memory(session)
        except Exception:
            if raise_on_error:
                raise
        return None

    return after_agent_callback


def make_bigquery_tool_callback(
    memory_service: Optional[MubitMemoryService] = None,
    *,
    raise_on_error: bool = False,
):
    """Build an ADK ``after_tool_callback`` for BigQuery learning signals.

    The callback stores redacted tool summaries as durable app/user memory and
    records per-step outcomes against the current ADK session.
    """

    async def after_tool_callback(
        tool: Any,
        args: dict[str, Any],
        tool_context: Any,
        tool_response: dict[str, Any],
    ):
        try:
            tool_name = _tool_name(tool)
            tool_args = dict(args or {})
            if not _looks_like_bigquery_tool(tool_name, tool_args):
                return None

            service = _callback_memory_service(tool_context, memory_service)
            if service is None:
                return None

            app_name, user_id, session_id = _callback_scope(tool_context)
            call_summary = _summarize_function_call(
                {"name": tool_name, "args": tool_args}
            )
            response_summary = _summarize_function_response(
                {"name": tool_name, "response": tool_response or {}}
            )
            lesson_text = "\n".join(
                [
                    "BigQuery tool observation",
                    call_summary,
                    response_summary,
                ]
            )
            error = _response_error(tool_response)
            outcome = "failure" if error else "success"
            signal = -1.0 if error else 0.7
            rationale = _response_rationale(tool_name, tool_response, error)
            directive_hint = (
                "Adjust the SQL using the BigQuery error and prior MuBit lessons."
                if error
                else "Prefer the BigQuery query patterns that produced this result."
            )

            entry = MemoryEntry(
                content=genai_types.Content(
                    parts=[genai_types.Part(text=lesson_text)],
                    role="model",
                ),
                author="mubit",
            )
            await service.add_memory(
                app_name=app_name,
                user_id=user_id,
                memories=[entry],
                custom_metadata={
                    "source": "adk_after_tool_callback",
                    "tool": tool_name,
                },
            )
            await service.record_step_outcome(
                app_name=app_name,
                user_id=user_id,
                session_id=session_id,
                step_id=getattr(tool_context, "function_call_id", None) or tool_name,
                step_name=f"BigQuery {tool_name}",
                outcome=outcome,
                signal=signal,
                rationale=rationale,
                directive_hint=directive_hint,
                metadata={"tool": tool_name, "source": "adk_after_tool_callback"},
            )
        except Exception:
            if raise_on_error:
                raise
        return None

    return after_tool_callback
