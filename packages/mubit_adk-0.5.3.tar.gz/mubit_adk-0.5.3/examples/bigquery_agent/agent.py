"""Customer-ready Google ADK BigQuery agent with MuBit learning.

This mirrors the standard ADK BigQueryToolset setup and adds:
- PreloadMemoryTool for MuBit recall before each model turn.
- A fail-open after_agent_callback for session persistence.
- A fail-open after_tool_callback for redacted BigQuery lessons and outcomes.
"""

from __future__ import annotations

import os
import warnings

import google.auth
from google.adk.agents import Agent
from google.adk.apps import App
from google.adk.tools.bigquery import BigQueryCredentialsConfig, BigQueryToolset
from google.adk.tools.bigquery.config import BigQueryToolConfig, WriteMode
from google.adk.tools.preload_memory_tool import PreloadMemoryTool

from mubit_adk import (
    MubitMemoryService,
    make_bigquery_tool_callback,
    make_session_memory_callback,
)

warnings.filterwarnings("ignore", message="App name mismatch detected")
warnings.filterwarnings("ignore", message=".*EXPERIMENTAL.*BaseAuthenticatedTool.*")

APP_NAME = os.environ.get("ADK_APP_NAME", "bigquery_agent")
MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.0-flash")
MUBIT_ENDPOINT = os.environ.get("MUBIT_ENDPOINT", "http://127.0.0.1:3000")
MUBIT_API_KEY = os.environ.get("MUBIT_API_KEY", "")


credentials, _ = google.auth.default()
credentials_config = BigQueryCredentialsConfig(credentials=credentials)
tool_config = BigQueryToolConfig(write_mode=WriteMode.BLOCKED)
bigquery_toolset = BigQueryToolset(
    credentials_config=credentials_config,
    bigquery_tool_config=tool_config,
)

mubit_memory = MubitMemoryService(
    endpoint=MUBIT_ENDPOINT,
    api_key=MUBIT_API_KEY,
)

bigquery_agent = Agent(
    name=APP_NAME,
    description="Read-only BigQuery agent with MuBit self-improvement memory.",
    model=MODEL,
    instruction=(
        "Answer questions about BigQuery data using the available read-only "
        "tools. Use prior MuBit lessons when they are relevant. Prefer safe, "
        "bounded SQL, explain assumptions, and learn from BigQuery errors."
    ),
    tools=[
        PreloadMemoryTool(),
        bigquery_toolset,
    ],
    after_agent_callback=make_session_memory_callback(mubit_memory),
    after_tool_callback=make_bigquery_tool_callback(mubit_memory),
)

root_agent = bigquery_agent
app = App(name=APP_NAME, root_agent=root_agent)


try:
    from vertexai.agent_engines import AdkApp

    agent_engine_id = os.environ.get("GOOGLE_CLOUD_AGENT_ENGINE_ID")
    project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("PROJECT_ID")
    session_location = os.environ.get("ADK_SESSION_LOCATION", "us-central1")

    if agent_engine_id and project:
        from google.adk.sessions.vertex_ai_session_service import (
            VertexAiSessionService,
        )

        session_service = VertexAiSessionService(
            project=project,
            location=session_location,
            agent_engine_id=agent_engine_id,
        )
    else:
        from google.adk.sessions import InMemorySessionService

        session_service = InMemorySessionService()

    adk_app = AdkApp(
        agent=root_agent,
        session_service_builder=lambda: session_service,
        memory_service_builder=lambda: mubit_memory,
        enable_tracing=True,
    )
except Exception:
    adk_app = None
