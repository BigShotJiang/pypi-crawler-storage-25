# Google ADK BigQuery Agent With MuBit

This example is the recommended customer setup for a read-only ADK BigQuery
agent that learns from successful and failed queries.

Key pieces:

- `PreloadMemoryTool()` makes ADK call MuBit memory before each model turn.
- `make_session_memory_callback()` persists the ADK session without breaking the
  agent if MuBit is temporarily unavailable.
- `make_bigquery_tool_callback()` records redacted BigQuery tool summaries and
  per-step outcomes. It stores row counts, columns, bytes processed, SQL text,
  and errors, but not raw result rows.
- `AdkApp(..., memory_service_builder=lambda: mubit_memory)` wires the same
  MuBit service into Vertex AI Agent Engine.

Required environment:

```bash
export MUBIT_API_KEY="mbt_..."
export MUBIT_ENDPOINT="https://api.mubit.ai"  # or local http://127.0.0.1:3000
export GOOGLE_CLOUD_PROJECT="<gcp-project>"
export GEMINI_MODEL="gemini-2.0-flash"
```

Run or deploy `agent.py` the same way as any ADK app.
