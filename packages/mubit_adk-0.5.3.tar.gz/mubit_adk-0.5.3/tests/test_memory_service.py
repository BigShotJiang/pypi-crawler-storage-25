from __future__ import annotations

import importlib
import sys
import types
import unittest
from dataclasses import dataclass, field
from pathlib import Path


def install_google_adk_stub() -> None:
    try:
        import google.adk  # noqa: F401
        import google.genai.types  # noqa: F401

        return
    except Exception:
        pass

    google = types.ModuleType("google")
    adk = types.ModuleType("google.adk")
    memory = types.ModuleType("google.adk.memory")
    sessions = types.ModuleType("google.adk.sessions")
    events = types.ModuleType("google.adk.events")
    genai = types.ModuleType("google.genai")
    genai_types = types.ModuleType("google.genai.types")

    class BaseMemoryService:
        pass

    @dataclass
    class SearchMemoryResponse:
        memories: list

    @dataclass
    class Part:
        text: str = ""
        function_call: object | None = None
        function_response: object | None = None

    @dataclass
    class FunctionCall:
        name: str = ""
        args: dict | None = None

    @dataclass
    class FunctionResponse:
        name: str = ""
        response: dict | None = None

    @dataclass
    class Content:
        parts: list[Part]
        role: str = "model"

    @dataclass
    class MemoryEntry:
        content: Content
        author: str | None = None
        timestamp: str | None = None

    @dataclass
    class Session:
        id: str
        user_id: str
        app_name: str
        events: list

    @dataclass
    class Event:
        author: str | None = None
        content: Content | None = None
        text: str | None = None

    memory.base_memory_service = types.ModuleType("google.adk.memory.base_memory_service")
    memory.base_memory_service.BaseMemoryService = BaseMemoryService
    memory.base_memory_service.SearchMemoryResponse = SearchMemoryResponse
    memory.memory_entry = types.ModuleType("google.adk.memory.memory_entry")
    memory.memory_entry.MemoryEntry = MemoryEntry
    sessions.session = types.ModuleType("google.adk.sessions.session")
    sessions.session.Session = Session
    events.event = types.ModuleType("google.adk.events.event")
    events.event.Event = Event

    genai.types = genai_types
    genai_types.Part = Part
    genai_types.FunctionCall = FunctionCall
    genai_types.FunctionResponse = FunctionResponse
    genai_types.Content = Content

    google.adk = adk
    google.genai = genai
    adk.memory = memory
    adk.sessions = sessions
    adk.events = events

    sys.modules["google"] = google
    sys.modules["google.adk"] = adk
    sys.modules["google.adk.memory"] = memory
    sys.modules["google.adk.memory.base_memory_service"] = memory.base_memory_service
    sys.modules["google.adk.memory.memory_entry"] = memory.memory_entry
    sys.modules["google.adk.sessions"] = sessions
    sys.modules["google.adk.sessions.session"] = sessions.session
    sys.modules["google.adk.events"] = events
    sys.modules["google.adk.events.event"] = events.event
    sys.modules["google.genai"] = genai
    sys.modules["google.genai.types"] = genai_types


class MockClient:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []

    def ingest_items(self, **payload):
        self.calls.append(("ingest_items", payload))
        return {"accepted": True, "job_id": "job-1"}

    def recall(self, **payload):
        self.calls.append(("recall", payload))
        return {
            "evidence": [
                {
                    "id": "memory-1",
                    "content": "Stored memory",
                    "metadata_json": '{"author":"planner","channel":"incident"}',
                    "score": 0.82,
                    "evidence_type": "lesson",
                }
            ]
        }

    def checkpoint(self, **payload):
        self.calls.append(("checkpoint", payload))
        return {"success": True}

    def record_outcome(self, **payload):
        self.calls.append(("record_outcome", payload))
        return {"success": True}

    def record_step_outcome(self, **payload):
        self.calls.append(("record_step_outcome", payload))
        return {"success": True}

    def surface_strategies(self, **payload):
        self.calls.append(("surface_strategies", payload))
        return {"strategies": []}

    def get_context(self, **payload):
        self.calls.append(("get_context", payload))
        return {"context_block": "assembled"}

    def archive(self, **payload):
        self.calls.append(("archive", payload))
        return {"success": True, "reference_id": "archive-1"}

    def dereference(self, **payload):
        self.calls.append(("dereference", payload))
        return {"found": True, "evidence": {"id": "archive-1"}}

    def memory_health(self, **payload):
        self.calls.append(("memory_health", payload))
        return {"entry_counts": {"lesson": 1}}

    def diagnose(self, **payload):
        self.calls.append(("diagnose", payload))
        return {"failure_lessons": []}

    def register_agent(self, **payload):
        self.calls.append(("register_agent", payload))
        return {"success": True}

    def list_agents(self, **payload):
        self.calls.append(("list_agents", payload))
        return {"agents": []}

    def handoff(self, **payload):
        self.calls.append(("handoff", payload))
        return {"success": True, "handoff_id": "handoff-1"}

    def feedback(self, **payload):
        self.calls.append(("feedback", payload))
        return {"success": True, "feedback_id": "feedback-1"}


class TestMubitAdkMemoryService(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls) -> None:
        install_google_adk_stub()
        package_root = Path(__file__).resolve().parents[1]
        if str(package_root) not in sys.path:
            sys.path.insert(0, str(package_root))
        cls.module = importlib.import_module("mubit_adk")
        cls.genai_types = sys.modules["google.genai.types"]
        cls.session_cls = sys.modules["google.adk.sessions.session"].Session
        cls.event_cls = sys.modules["google.adk.events.event"].Event
        cls.memory_entry_cls = sys.modules["google.adk.memory.memory_entry"].MemoryEntry

    async def test_add_events_to_memory_routes_through_sdk_client(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)
        event = self.event_cls(
            author="tool",
            content=self.genai_types.Content(parts=[self.genai_types.Part(text="built release manifest")]),
        )

        await service.add_events_to_memory(
            app_name="deploy-agent",
            user_id="user-1",
            events=[event],
            session_id="session-1",
            custom_metadata={"phase": "release"},
        )

        self.assertEqual(
            client.calls[0],
            (
                "ingest_items",
                {
                    "session_id": "session-1",
                    "agent_id": "deploy-agent",
                    "idempotency_key": "events-session-1",
                    "items": [
                        {
                            "item_id": "adk-session-1-evt-0",
                            "content_type": "text/plain",
                            "text": "built release manifest",
                            "metadata": {
                                "author": "tool",
                                "event_index": 0,
                                "phase": "release",
                            },
                            "user_id": "user-1",
                            "intent": "tool_output",
                        }
                    ],
                },
            ),
        )

    async def test_search_memory_uses_app_user_scope_and_current_memory_entry_shape(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)

        response = await service.search_memory(
            app_name="deploy-agent",
            user_id="user-1",
            query="release memory",
        )

        self.assertEqual(len(response.memories), 1)
        memory = response.memories[0]
        self.assertEqual(memory.author, "planner")
        self.assertIsNone(memory.timestamp)
        text = memory.content.parts[0].text
        self.assertIn("Stored memory", text)
        self.assertIn("score=0.82", text)
        self.assertIn("type=lesson", text)
        self.assertIn("channel=incident", text)
        self.assertEqual(client.calls[0][1]["session_id"], "adk:deploy-agent:user-1:memory")
        self.assertEqual(client.calls[0][1]["agent_id"], "deploy-agent")

    async def test_add_memory_accepts_current_google_adk_memory_entry(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)
        entry = self.memory_entry_cls(
            content=self.genai_types.Content(
                parts=[
                    self.genai_types.Part(
                        text="Use dry runs before expensive BigQuery queries."
                    )
                ],
                role="user",
            ),
            author="analyst",
        )

        await service.add_memory(
            app_name="bigquery-agent",
            user_id="user-1",
            memories=[entry],
        )

        call_name, payload = client.calls[0]
        self.assertEqual(call_name, "ingest_items")
        self.assertEqual(payload["session_id"], "adk:bigquery-agent:user-1:memory")
        self.assertEqual(payload["agent_id"], "bigquery-agent")
        self.assertEqual(
            payload["idempotency_key"], "memory-adk:bigquery-agent:user-1:memory"
        )
        self.assertEqual(payload["items"][0]["metadata"]["author"], "analyst")

    async def test_bigquery_tool_events_capture_shape_without_raw_rows(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)
        call = self.genai_types.FunctionCall(
            name="execute_sql",
            args={"query": "SELECT customer_email, revenue FROM mart.orders LIMIT 100"},
        )
        response = self.genai_types.FunctionResponse(
            name="execute_sql",
            response={
                "rows": [
                    {"customer_email": "a@example.com", "revenue": 12.5},
                    {"customer_email": "b@example.com", "revenue": 20.0},
                ],
                "total_bytes_processed": 1234,
            },
        )
        event = self.event_cls(
            author="tool",
            content=self.genai_types.Content(
                parts=[
                    self.genai_types.Part(function_call=call),
                    self.genai_types.Part(function_response=response),
                ],
            ),
        )

        await service.add_events_to_memory(
            app_name="bigquery-agent",
            user_id="user-1",
            events=[event],
            session_id="session-1",
        )

        text = client.calls[0][1]["items"][0]["text"]
        self.assertIn("Tool call: execute_sql", text)
        self.assertIn(
            "SQL: SELECT customer_email, revenue FROM mart.orders LIMIT 100", text
        )
        self.assertIn("Tool response: execute_sql", text)
        self.assertIn("row_count=2", text)
        self.assertIn("columns=customer_email,revenue", text)
        self.assertIn("total_bytes_processed=1234", text)
        self.assertNotIn("a@example.com", text)
        self.assertNotIn("b@example.com", text)

    async def test_bigquery_after_tool_callback_records_lesson_and_step_outcome(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)
        callback = self.module.make_bigquery_tool_callback(service)

        class Tool:
            name = "execute_sql"

        invocation_context = types.SimpleNamespace(
            app_name="bigquery-agent",
            user_id="user-1",
            session=types.SimpleNamespace(id="session-1"),
        )
        tool_context = types.SimpleNamespace(
            _invocation_context=invocation_context,
            function_call_id="call-1",
        )

        result = await callback(
            Tool(),
            {"query": "SELECT email, revenue FROM mart.orders"},
            tool_context,
            {
                "rows": [{"email": "a@example.com", "revenue": 10}],
                "total_bytes_processed": 2048,
            },
        )

        self.assertIsNone(result)
        call_names = [name for name, _payload in client.calls]
        self.assertEqual(call_names, ["ingest_items", "record_step_outcome"])
        lesson_text = client.calls[0][1]["items"][0]["text"]
        self.assertIn("Tool call: execute_sql", lesson_text)
        self.assertIn("row_count=1", lesson_text)
        self.assertNotIn("a@example.com", lesson_text)
        outcome_payload = client.calls[1][1]
        self.assertEqual(outcome_payload["session_id"], "session-1")
        self.assertEqual(outcome_payload["step_id"], "call-1")
        self.assertEqual(outcome_payload["step_name"], "BigQuery execute_sql")
        self.assertEqual(outcome_payload["outcome"], "success")
        self.assertEqual(outcome_payload["signal"], 0.7)

    def test_customer_style_agent_engine_setup_smoke(self) -> None:
        try:
            from google.adk.agents import Agent
            from google.adk.apps import App
            from google.adk.tools.preload_memory_tool import PreloadMemoryTool
            import vertexai
            from vertexai.agent_engines import AdkApp
        except Exception as exc:
            self.skipTest(f"google-adk or vertexai Agent Engine unavailable: {exc}")

        service = self.module.MubitMemoryService(mubit_client=MockClient())
        agent = Agent(
            name="bigquery_agent",
            description="Read-only BigQuery agent with MuBit memory.",
            model="gemini-2.0-flash",
            instruction="Answer BigQuery questions using prior MuBit lessons.",
            tools=[PreloadMemoryTool()],
            after_agent_callback=self.module.make_session_memory_callback(service),
            after_tool_callback=self.module.make_bigquery_tool_callback(service),
        )
        app = App(name="bigquery_agent", root_agent=agent)
        vertexai.init(project="mubit-test", location="us-central1")
        adk_app = AdkApp(
            app=app,
            memory_service_builder=lambda: service,
            enable_tracing=True,
        )

        self.assertIsNotNone(adk_app)

    async def test_current_helper_surface_is_available(self) -> None:
        client = MockClient()
        service = self.module.MubitMemoryService(mubit_client=client)

        await service.get_context(
            app_name="deploy-agent",
            user_id="user-1",
            query="release status",
            session_id="session-1",
        )
        await service.archive(
            app_name="deploy-agent",
            user_id="user-1",
            session_id="session-1",
            content="pytest failure summary",
            artifact_kind="failing_test_summary",
            source_tool="pytest",
        )
        await service.dereference(
            user_id="user-1",
            session_id="session-1",
            reference_id="archive-1",
        )
        await service.memory_health(
            user_id="user-1",
            session_id="session-1",
            limit=50,
        )
        await service.diagnose(
            user_id="user-1",
            error_text="kubectl apply failed",
            session_id="session-1",
        )
        await service.register_agent(
            user_id="user-1",
            session_id="session-1",
            agent_id="planner",
            role="planner",
        )
        await service.list_agents(user_id="user-1", session_id="session-1")
        await service.handoff(
            user_id="user-1",
            session_id="session-1",
            from_agent_id="planner",
            to_agent_id="reviewer",
            content="Review the release notes.",
        )
        await service.feedback(
            user_id="user-1",
            session_id="session-1",
            handoff_id="handoff-1",
            verdict="approve",
        )

        self.assertEqual(
            [name for name, _payload in client.calls],
            [
                "get_context",
                "archive",
                "dereference",
                "memory_health",
                "diagnose",
                "register_agent",
                "list_agents",
                "handoff",
                "feedback",
            ],
        )


if __name__ == "__main__":
    unittest.main()
