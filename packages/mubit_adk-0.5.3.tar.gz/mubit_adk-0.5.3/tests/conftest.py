"""Install a minimal `google.adk` stub before any test module loads.

`mubit_adk/__init__.py` eagerly imports from `google.adk` and raises on
failure. Tests shouldn't require a real google-adk install, so we seed
`sys.modules` with stubs here. pytest loads conftest.py before the test
modules, so subsequent `from mubit_adk... import ...` top-level imports
resolve cleanly.

The stub mirrors what `install_google_adk_stub` in `test_memory_service.py`
sets up; we keep a minimal copy here so conftest doesn't need a relative
import from the tests dir (which isn't a package).
"""

from __future__ import annotations

import sys
import types
from dataclasses import dataclass


def _install_google_adk_stub() -> None:
    if "google.adk" in sys.modules:
        return
    try:
        import google.adk  # noqa: F401
        import google.genai.types  # noqa: F401

        return
    except Exception:
        pass

    # Trigger real `google` namespace package resolution first so
    # `from google.protobuf import ...` (used by the mubit SDK) still works
    # after we attach our fake `google.adk` submodule. Without this, setting
    # `sys.modules["google"]` to a ModuleType would shadow the namespace
    # package and break protobuf imports.
    try:
        import google  # noqa: F401
    except Exception:
        pass
    google = sys.modules.get("google") or types.ModuleType("google")
    adk = types.ModuleType("google.adk")
    memory = types.ModuleType("google.adk.memory")
    sessions = types.ModuleType("google.adk.sessions")
    events = types.ModuleType("google.adk.events")
    genai = types.ModuleType("google.genai")
    genai_types = types.ModuleType("google.genai.types")

    class BaseMemoryService:
        pass

    @dataclass
    class SearchMemoryResponse:
        memories: list

    @dataclass
    class Part:
        text: str = ""
        function_call: object | None = None
        function_response: object | None = None

    @dataclass
    class FunctionCall:
        name: str = ""
        args: dict | None = None

    @dataclass
    class FunctionResponse:
        name: str = ""
        response: dict | None = None

    @dataclass
    class Content:
        parts: list
        role: str = "model"

    @dataclass
    class MemoryEntry:
        content: object
        author: str | None = None
        timestamp: str | None = None

    @dataclass
    class Session:
        id: str
        user_id: str
        app_name: str
        events: list

    @dataclass
    class Event:
        author: str | None = None
        content: object | None = None
        text: str | None = None

    memory.base_memory_service = types.ModuleType("google.adk.memory.base_memory_service")
    memory.base_memory_service.BaseMemoryService = BaseMemoryService
    memory.base_memory_service.SearchMemoryResponse = SearchMemoryResponse
    memory.memory_entry = types.ModuleType("google.adk.memory.memory_entry")
    memory.memory_entry.MemoryEntry = MemoryEntry
    sessions.session = types.ModuleType("google.adk.sessions.session")
    sessions.session.Session = Session
    events.event = types.ModuleType("google.adk.events.event")
    events.event.Event = Event

    genai.types = genai_types
    genai_types.Part = Part
    genai_types.FunctionCall = FunctionCall
    genai_types.FunctionResponse = FunctionResponse
    genai_types.Content = Content

    google.adk = adk
    google.genai = genai
    adk.memory = memory
    adk.sessions = sessions
    adk.events = events

    # Only seed `sys.modules["google"]` if nothing is there yet — preserves
    # the real `google` namespace package when it's already loaded.
    sys.modules.setdefault("google", google)
    sys.modules["google.adk"] = adk
    sys.modules["google.adk.memory"] = memory
    sys.modules["google.adk.memory.base_memory_service"] = memory.base_memory_service
    sys.modules["google.adk.memory.memory_entry"] = memory.memory_entry
    sys.modules["google.adk.sessions"] = sessions
    sys.modules["google.adk.sessions.session"] = sessions.session
    sys.modules["google.adk.events"] = events
    sys.modules["google.adk.events.event"] = events.event
    sys.modules["google.genai"] = genai
    sys.modules["google.genai.types"] = genai_types


_install_google_adk_stub()
