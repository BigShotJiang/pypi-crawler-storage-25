from __future__ import annotations

import unittest

from mubit_adk.mubit_client import MubitControlClient


class FakeSdkClient:
    """Stand-in for `mubit.Client`. Integration base calls `ingest` +
    `get_ingest_job` at top level, so expose both as methods that log to
    `.calls`.
    """

    def __init__(self) -> None:
        self.calls: list[tuple[str, dict]] = []
        self._polls = 0

    def ingest(self, payload):
        self.calls.append(("ingest", payload))
        return {"accepted": True, "job_id": "job-1"}

    def get_ingest_job(self, payload):
        self.calls.append(("get_ingest_job", payload))
        self._polls += 1
        return {"done": self._polls >= 1}

    def record_step_outcome(self, payload):
        self.calls.append(("record_step_outcome", payload))
        return {"success": True}

    def create_handoff(self, payload):
        self.calls.append(("create_handoff", payload))
        return {"success": True, "handoff_id": "handoff-1"}


class TestMubitControlClient(unittest.TestCase):
    def test_ingest_items_waits_for_ingest_completion(self) -> None:
        sdk_client = FakeSdkClient()
        client = MubitControlClient(sdk_client=sdk_client)

        client.ingest_items(
            session_id="session-1",
            agent_id="adk-agent",
            items=[{"item_id": "evt-1", "text": "release note"}],
        )

        self.assertEqual(len(sdk_client.calls), 2)
        self.assertEqual(sdk_client.calls[0][0], "ingest")
        self.assertEqual(sdk_client.calls[1][0], "get_ingest_job")

    def test_record_step_outcome_uses_current_control_contract(self) -> None:
        sdk_client = FakeSdkClient()
        client = MubitControlClient(sdk_client=sdk_client)

        client.record_step_outcome(
            session_id="session-1",
            step_id="query-1",
            step_name="BigQuery execute_sql",
            outcome="failure",
            signal=-0.8,
            rationale="Query scanned too much data.",
            directive_hint="Add a partition filter before execution.",
            agent_id="bigquery-agent",
            user_id="user-1",
            metadata={"tool": "execute_sql"},
        )

        self.assertEqual(
            sdk_client.calls[0],
            (
                "record_step_outcome",
                {
                    "run_id": "session-1",
                    "step_id": "query-1",
                    "step_name": "BigQuery execute_sql",
                    "outcome": "failure",
                    "signal": -0.8,
                    "rationale": "Query scanned too much data.",
                    "directive_hint": "Add a partition filter before execution.",
                    "agent_id": "bigquery-agent",
                    "user_id": "user-1",
                    "metadata_json": '{"tool": "execute_sql"}',
                },
            ),
        )

    def test_handoff_sends_task_id(self) -> None:
        sdk_client = FakeSdkClient()
        client = MubitControlClient(sdk_client=sdk_client)

        client.handoff(
            session_id="session-1",
            task_id="review-query-plan",
            from_agent_id="planner",
            to_agent_id="reviewer",
            content="Review the BigQuery query plan.",
        )

        self.assertEqual(sdk_client.calls[0][0], "create_handoff")
        self.assertEqual(sdk_client.calls[0][1]["task_id"], "review-query-plan")


if __name__ == "__main__":
    unittest.main()
