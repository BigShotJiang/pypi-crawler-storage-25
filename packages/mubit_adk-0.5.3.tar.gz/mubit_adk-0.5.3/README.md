# `mubit-adk`

Google ADK `BaseMemoryService` backed by [MuBit](https://mubit.ai).

This adapter now uses the canonical Python SDK transport internally instead of raw `httpx`, while preserving the ADK memory-service contract and adding MuBit-specific helpers for checkpointing, observability, and multi-agent coordination.

## Install

```bash
pip install mubit-adk[adk]
```

## Basic usage

```python
from google.adk.agents import Agent
from google.adk.tools.preload_memory_tool import PreloadMemoryTool

from mubit_adk import (
    MubitMemoryService,
    make_bigquery_tool_callback,
    make_session_memory_callback,
)

memory = MubitMemoryService(
    endpoint="http://127.0.0.1:3000",
    api_key="mbt_...",
)

agent = Agent(
    name="bigquery_agent",
    description="Read-only BigQuery agent with MuBit memory.",
    model="gemini-2.0-flash",
    instruction="Use BigQuery tools and prior MuBit lessons to answer safely.",
    tools=[
        PreloadMemoryTool(),  # ADK calls memory.search_memory() before each turn.
        bigquery_toolset,     # Your ADK BigQueryToolset.
    ],
    after_agent_callback=make_session_memory_callback(memory),
    after_tool_callback=make_bigquery_tool_callback(memory),
)
```

For Vertex AI Agent Engine, pass the same memory service through `AdkApp`:

```python
from vertexai.agent_engines import AdkApp

adk_app = AdkApp(
    agent=agent,
    memory_service_builder=lambda: memory,
    enable_tracing=True,
)
```

## ADK to MuBit mapping

| ADK concept | MuBit mapping |
| --- | --- |
| `app_name` | `agent_id` |
| `user_id` | `user_id` |
| `session.id` | isolated raw session `run_id` |
| `adk:<app_name>:<user_id>:memory` | durable app/user lesson `run_id` |
| session/event ingest | control ingest items with safe tool summaries |
| `PreloadMemoryTool()` | calls `search_memory()` for prompt injection |
| `search_memory()` | control query over the durable app/user memory run |

## MuBit extension methods

Existing MAS helpers:

- `checkpoint()`
- `record_outcome()`
- `record_step_outcome()`
- `surface_strategies()`

Current observability and coordination helpers:

- `get_context()`
- `memory_health()`
- `diagnose()`
- `archive()`
- `dereference()`
- `register_agent()`
- `list_agents()`
- `handoff()`
- `feedback()`
- `make_session_memory_callback()` for fail-open ADK session ingestion
- `make_bigquery_tool_callback()` for redacted BigQuery tool lessons and step outcomes

## Config

| Parameter | Default | Purpose |
| --- | --- | --- |
| `endpoint` | `http://127.0.0.1:3000` | MuBit HTTP endpoint |
| `api_key` | `""` | MuBit API key |

For tests or advanced embedding, you can inject `mubit_client` directly.

## Development

```bash
PYTHONPATH=sdk/python/mubit-sdk/src:integrations/python/mubit_adk:integrations/python/mubit_integration_base \
python3 -m unittest integrations.python.mubit_adk.tests.test_memory_service integrations.python.mubit_adk.tests.test_mubit_client -v
```

## License

Apache-2.0
