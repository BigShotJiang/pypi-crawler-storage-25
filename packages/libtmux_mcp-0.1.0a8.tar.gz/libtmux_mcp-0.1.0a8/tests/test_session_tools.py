"""Tests for libtmux MCP session tools."""

from __future__ import annotations

import typing as t

import pytest
from fastmcp.exceptions import ToolError

from libtmux_mcp.tools.session_tools import (
    create_window,
    get_session_info,
    kill_session,
    list_windows,
    rename_session,
    select_window,
)

if t.TYPE_CHECKING:
    from libtmux.server import Server
    from libtmux.session import Session


def test_list_windows(mcp_server: Server, mcp_session: Session) -> None:
    """list_windows returns a list of WindowInfo models."""
    result = list_windows(
        session_name=mcp_session.session_name,
        socket_name=mcp_server.socket_name,
    )
    assert isinstance(result, list)
    assert len(result) >= 1
    assert result[0].window_id is not None


def test_list_windows_by_id(mcp_server: Server, mcp_session: Session) -> None:
    """list_windows can find session by ID."""
    result = list_windows(
        session_id=mcp_session.session_id,
        socket_name=mcp_server.socket_name,
    )
    assert len(result) >= 1


def test_get_session_info(mcp_server: Server, mcp_session: Session) -> None:
    """get_session_info returns a SessionInfo for a single session."""
    result = get_session_info(
        session_id=mcp_session.session_id,
        socket_name=mcp_server.socket_name,
    )
    assert result.session_id == mcp_session.session_id
    assert result.session_name == mcp_session.session_name
    assert result.window_count >= 1


def test_get_session_info_by_name(mcp_server: Server, mcp_session: Session) -> None:
    """get_session_info resolves by session_name when no ID is given."""
    assert mcp_session.session_name is not None
    result = get_session_info(
        session_name=mcp_session.session_name,
        socket_name=mcp_server.socket_name,
    )
    assert result.session_id == mcp_session.session_id


def test_create_window(mcp_server: Server, mcp_session: Session) -> None:
    """create_window creates a new window in a session."""
    result = create_window(
        session_name=mcp_session.session_name,
        window_name="mcp_test_win",
        socket_name=mcp_server.socket_name,
    )
    assert result.window_name == "mcp_test_win"


def test_create_window_invalid_direction(
    mcp_server: Server, mcp_session: Session
) -> None:
    """create_window raises ToolError on invalid direction."""
    with pytest.raises(ToolError, match="Invalid direction"):
        create_window(
            session_name=mcp_session.session_name,
            window_name="bad_dir",
            direction="sideways",  # type: ignore[arg-type]
            socket_name=mcp_server.socket_name,
        )


def test_rename_session(mcp_server: Server, mcp_session: Session) -> None:
    """rename_session renames an existing session."""
    original_name = mcp_session.session_name
    result = rename_session(
        new_name="mcp_renamed",
        session_name=original_name,
        socket_name=mcp_server.socket_name,
    )
    assert result.session_name == "mcp_renamed"


class ListWindowsFilterFixture(t.NamedTuple):
    """Test fixture for list_windows with filters."""

    test_id: str
    provide_session: bool
    filters: dict[str, str] | None
    expected_min_count: int
    expect_error: bool


LIST_WINDOWS_FILTER_FIXTURES: list[ListWindowsFilterFixture] = [
    ListWindowsFilterFixture(
        test_id="no_filters_scoped",
        provide_session=True,
        filters=None,
        expected_min_count=1,
        expect_error=False,
    ),
    ListWindowsFilterFixture(
        test_id="no_filters_all_sessions",
        provide_session=False,
        filters=None,
        expected_min_count=1,
        expect_error=False,
    ),
    ListWindowsFilterFixture(
        test_id="filter_by_name",
        provide_session=True,
        filters={"window_name": "<window_name>"},
        expected_min_count=1,
        expect_error=False,
    ),
    ListWindowsFilterFixture(
        test_id="filter_by_name_contains",
        provide_session=False,
        filters={"window_name__contains": "<partial_window>"},
        expected_min_count=1,
        expect_error=False,
    ),
    ListWindowsFilterFixture(
        test_id="filter_active",
        provide_session=True,
        filters={"window_active": "1"},
        expected_min_count=1,
        expect_error=False,
    ),
    ListWindowsFilterFixture(
        test_id="invalid_operator",
        provide_session=True,
        filters={"window_name__badop": "test"},
        expected_min_count=0,
        expect_error=True,
    ),
    ListWindowsFilterFixture(
        test_id="cross_session_filter",
        provide_session=False,
        filters={"window_name": "<cross_window_name>"},
        expected_min_count=1,
        expect_error=False,
    ),
]


@pytest.mark.parametrize(
    ListWindowsFilterFixture._fields,
    LIST_WINDOWS_FILTER_FIXTURES,
    ids=[f.test_id for f in LIST_WINDOWS_FILTER_FIXTURES],
)
def test_list_windows_with_filters(
    mcp_server: Server,
    mcp_session: Session,
    test_id: str,
    provide_session: bool,
    filters: dict[str, str] | None,
    expected_min_count: int,
    expect_error: bool,
) -> None:
    """list_windows supports QueryList filtering and scope broadening."""
    # Create a second session with a named window for cross-session tests
    second_session = mcp_server.new_session(session_name="mcp_filter_second")
    cross_win = second_session.new_window(window_name="cross_target_win")

    window = mcp_session.active_window
    window_name = window.window_name
    assert window_name is not None

    if filters is not None:
        resolved: dict[str, str] = {}
        for k, v in filters.items():
            if v == "<window_name>":
                resolved[k] = window_name
            elif v == "<partial_window>":
                resolved[k] = window_name[:3]
            elif v == "<cross_window_name>":
                resolved[k] = "cross_target_win"
            else:
                resolved[k] = v
        filters = resolved

    kwargs: dict[str, t.Any] = {
        "socket_name": mcp_server.socket_name,
        "filters": filters,
    }
    if provide_session:
        kwargs["session_name"] = mcp_session.session_name

    if expect_error:
        with pytest.raises(ToolError, match="Invalid filter operator"):
            list_windows(**kwargs)
    else:
        result = list_windows(**kwargs)
        assert isinstance(result, list)
        assert len(result) >= expected_min_count

    # Cleanup
    cross_win.kill()
    second_session.kill()


# ---------------------------------------------------------------------------
# select_window tests
# ---------------------------------------------------------------------------


def test_select_window_by_id(mcp_server: Server, mcp_session: Session) -> None:
    """select_window focuses a window by ID."""
    win1 = mcp_session.active_window
    mcp_session.new_window(window_name="select_target")

    result = select_window(
        window_id=win1.window_id,
        socket_name=mcp_server.socket_name,
    )
    assert result.window_id == win1.window_id


def test_select_window_by_index(mcp_server: Server, mcp_session: Session) -> None:
    """select_window focuses a window by index."""
    win1 = mcp_session.active_window
    mcp_session.new_window(window_name="select_idx")

    result = select_window(
        window_index=win1.window_index,
        session_name=mcp_session.session_name,
        socket_name=mcp_server.socket_name,
    )
    assert result.window_id == win1.window_id


def test_select_window_direction_next(mcp_server: Server, mcp_session: Session) -> None:
    """select_window navigates to next window."""
    win1 = mcp_session.active_window
    win2 = mcp_session.new_window(window_name="next_win")

    # Make win1 active
    win1.select()
    result = select_window(
        direction="next",
        session_name=mcp_session.session_name,
        socket_name=mcp_server.socket_name,
    )
    assert result.window_id == win2.window_id


def test_select_window_requires_target(mcp_server: Server) -> None:
    """select_window raises ToolError without target or direction."""
    with pytest.raises(ToolError, match="Provide"):
        select_window(socket_name=mcp_server.socket_name)


def test_select_window_last_on_single_window_session_raises(
    mcp_server: Server, mcp_session: Session
) -> None:
    """select_window last with no prior window must surface the tmux error.

    Regression guard: ``Session.last_window`` on a session that has
    never had a previously-active window raises ``LibTmuxException``
    with tmux's "no last window" stderr; the tool previously discarded
    the return value and returned the unchanged active window as if
    the navigation had worked.
    """
    # The fixture session is freshly created: there is no previously-
    # active window for last-window to jump back to.
    with pytest.raises(ToolError, match="no last window"):
        select_window(
            direction="last",
            session_name=mcp_session.session_name,
            socket_name=mcp_server.socket_name,
        )


def test_kill_session_requires_target(mcp_server: Server) -> None:
    """kill_session refuses to kill without an explicit target."""
    with pytest.raises(ToolError, match="Refusing to kill"):
        kill_session(socket_name=mcp_server.socket_name)


def test_kill_session(mcp_server: Server) -> None:
    """kill_session kills a session."""
    mcp_server.new_session(session_name="mcp_kill_me")
    result = kill_session(
        session_name="mcp_kill_me",
        socket_name=mcp_server.socket_name,
    )
    assert "killed" in result.lower()
    assert not mcp_server.has_session("mcp_kill_me")
