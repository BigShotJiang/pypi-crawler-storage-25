import numpy as np
from scipy.stats import norm

from .vec_recycle import vec_recycle_common

###############################################################################
# Normal

def dnorm(x, mean = 0., sd = 1., log = False):
    """
    Density function for the normal distribution.
    dnorm(x, mean = 0., sd = 1., log = False)
    """

    x, mean, sd = vec_recycle_common(x, mean, sd)
    if log:
        return norm.logpdf(x, loc=mean, scale=sd)
    else:
        return norm.pdf(x, loc=mean, scale=sd)
   

def pnorm(q, mean = 0., sd = 1., lower_tail = True, log_p = False):
    """
    Cumulative Density Function (CDF) for the normal distribution.
    pnorm(q, mean = 0., sd = 1., lower_tail = True, log_p = False)
    """
    
    q, mean, sd = vec_recycle_common(q, mean, sd)
    if lower_tail:
        if log_p:
            return norm.logcdf(q, loc=mean, scale=sd)
        else:
            return norm.cdf(q, loc=mean, scale=sd)
    else:
        if log_p:
            return norm.logsf(q, loc=mean, scale=sd)
        else:
            return norm.sf(q, loc=mean, scale=sd)
    

def qnorm(p, mean = 0., sd = 1., lower_tail = True, log_p = False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the normal distribution.
    qnorm(p, mean = 0, sd = 1, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1., p)
    p, mean, sd = vec_recycle_common(p, mean, sd)
    q = norm.ppf(p, loc=mean, scale=sd)
    return q


def rnorm(n=None, mean = 0., sd = 1.):
    """
    Random number generator for the normal distribution.
    rnorm(n=None, mean = 0, sd = 1)
    """

    mean, sd = vec_recycle_common(mean, sd, n=n)
    return norm.rvs(loc=mean, scale=sd, size=n)

