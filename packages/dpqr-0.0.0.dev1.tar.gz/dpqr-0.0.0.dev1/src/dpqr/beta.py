import numpy as np
from scipy.stats import beta

from .vec_recycle import vec_recycle_common

###############################################################################
# Beta

# TODO: ncp version not yet implemented
# dbeta(x, shape1, shape2, ncp = 0, log = FALSE)
# pbeta(q, shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE)
# qbeta(p, shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE)
# rbeta(n, shape1, shape2, ncp = 0)

def dbeta(x, shape1, shape2, log = False):
    """
    Density function for the Beta distribution.
    dbeta(x, shape1, shape2, log = False)
    """

    x, shape1, shape2 = vec_recycle_common(x, shape1, shape2)
    if log:
        return beta.logpdf(x, a=shape1, b=shape2)
    else:
        return beta.pdf(x, a=shape1, b=shape2)
   
def pbeta(q, shape1, shape2, lower_tail = True, log_p = False):
    """
    Cumulative Density Function (CDF) for the Beta distribution.
    pbeta(q, shape1, shape2, lower_tail = True, log_p = False):
    """

    q, shape1, shape2 = vec_recycle_common(q, shape1, shape2)

    if lower_tail:
        if log_p:
            return beta.logcdf(q, a=shape1, b=shape2)
        else:
            return beta.cdf(q, a=shape1, b=shape2)
    else:
        cdf = np.subtract(1.,beta.cdf(q, a=shape1, b=shape2))
        if log_p:
            return beta.logsf(q, a=shape1, b=shape2)
        else:
            return beta.sf(q, a=shape1, b=shape2)


def qbeta(p, shape1, shape2, lower_tail = True, log_p = False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the Beta distribution.
    qbeta(p, shape1, shape2, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1.,p)
    p, shape1, shape2 = vec_recycle_common(p, shape1, shape2)
    q = beta.ppf(p, shape1, shape2)
    return q


def rbeta(n, shape1, shape2):
    """
    Random number generator for the Beta distribution.
    rbeta(n, shape1, shape2)
    """

    shape1, shape2 = vec_recycle_common(shape1, shape2, n=n)
    return beta.rvs(shape1, shape2, size=n)

