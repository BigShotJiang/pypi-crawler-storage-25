import numpy as np
from collections.abc import Sized

#from itertools import islice

###############################################################################
# common functions

# TODO: more complicated scenarios:
# > dnorm(matrix(c(1,2,3,4),2),sd=c(0.1,10))
#              [,1]          [,2]
# [1,] 7.694599e-22 1.473646e-195
# [2,] 3.910427e-02  3.682701e-02
# ??? allow numpy broadcasting rules or R's???
# dnorm([[1,3],[2,4]],sd=[.1,10])
# array([[7.69459863e-22, 3.81387815e-02],
#       [5.52094836e-87, 3.68270140e-02]])
#
# unclear how recycling/broadcasting is working here.


# test cases:
# - 1, n=5
# - 1., n=5
# - [1], n=5
# - [1,2], n=5
# - array([1,2]), n=5
# - np.array([1,2]), n=5
# - np.ndarray([1,2]), n=5
#
def vec_recycle(x, n):
    """
    Recycle vector values to a specified length.
    """

    # check if resize is needed.
#    if isinstance(x, Sized):
#        if len(x) != n:
#            x = np.resize(x, n)
#    else:
#        if n > 1:
#            x = np.resize(x, n)
    if n > 1:
        x = np.resize(x, n)
    return x

    
#    if isinstance(x, Sized) and len(x) > 1 and len(x) != n:
#        x = np.atleast_1d(x)
#from itertools import islice
#        x = np.fromiter(islice(cycle(x), n), dtype=x.dtype, count=n) # 3x slower
#    return x

# mix and match dtypes
# - scalar
# - list
# - array Module
# - np.array
# - np.ndarray
# - some kind of matrix.
# TODO: does not convert list to np.array if already correct length.
# does this have performance issues ???

#  vec_recycle_common([1], [1,2], [1,2,3], n=2)

def vec_recycle_common( *xs, n=None):
    """
    Recycle multiple vectors to a common length.
    """

    # ensure all scalars or vectors.
    if any( [isinstance(x, Sized) for x in xs] ):
        xs = np.atleast_1d(*xs)
        
    # if n is missing, calculate it.
    if n is None:
        n = max([ len(x) if isinstance(x, Sized) else 1 for x in xs] )

    return tuple([vec_recycle(x, n) for x in xs])



#    if not any( [isinstance(x, Sized) for x in xs] ) and n is None:
#        return xs
#    if n is None:
#        n = max([len(x) for x in xs if isinstance(x, Sized)])
#    return tuple([vec_recycle(x, n) for x in xs])

