"""
R style distribution and random variable functions.

This module provides R style distribution functions.

Currently is mainly a wrapper for SciPy distribution functions,
eventually may convert to Boost C++ functions directly for improved
vec_recycling performance.
"""

from .vec_recycle import *

from .beta import *
from .binom import *
from .gamma import *
from .invgamma import *
from .nbinom import *
from .norm import *

