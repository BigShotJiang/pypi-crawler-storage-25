#from operator import ne

import numpy as np
from scipy.stats import gamma

from .vec_recycle import vec_recycle_common

################################################################################
# Gamma
# TODO: add shape + scale paramaterization

# dgamma(x, shape, rate = 1, scale = 1/rate, log = FALSE)
# pgamma(q, shape, rate = 1, scale = 1/rate, lower.tail = TRUE, log.p = FALSE)
# qgamma(p, shape, rate = 1, scale = 1/rate, lower.tail = TRUE, log.p = FALSE)
# rgamma(n, shape, rate = 1, scale = 1/rate)

def dgamma(x, shape = 1., rate = 1., log = False):
    """
    Density function for the Gamma distribution.
    dgamma(x, shape, rate, log = False)
    """

    x, shape, scale = vec_recycle_common(x, shape, 1./rate)
    if log:
        x = gamma.logpdf(x, a=shape, scale=scale)
        return np.nan_to_num(x,nan=-np.inf,posinf=np.inf,neginf=-np.inf )
    else:
        x = gamma.pdf(x, a=shape, scale=scale)
        return np.nan_to_num(x,nan=0,posinf=np.inf,neginf=-np.inf )
  

def pgamma(q, shape=1., rate=1., lower_tail = True, log_p = False):
    """
    Cumulative Density Function (CDF) for the Gamma distribution.
    pgamma(q, shape1, shape2, lower_tail = True, log_p = False):
    """

    q, shape, scale = vec_recycle_common(q, shape, 1./rate)
    if lower_tail:
        if log_p:
            with np.errstate(divide='ignore', invalid='ignore'):
                return gamma.logcdf(q, a=shape, scale=scale)
        else:
            return gamma.cdf(q, a=shape, scale=scale)
    else:
        if log_p:
            return gamma.logsf(q, a=shape, scale=scale)
        else:
            return gamma.sf(q, a=shape, scale=scale)


def qgamma(p, shape=1., rate=1., lower_tail = True, log_p = False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the Gamma distribution.
    qgamma(p, shape, rate, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1.,p)
    p, shape, scale = vec_recycle_common(p, shape, 1./rate)
    q = gamma.ppf(p, shape, scale=scale)
    return q


def rgamma(n, shape, rate=1.):
    """
    Random number generator for the Gamma distribution.
    rgamma(n, shape, rate)
    """

    shape, scale = vec_recycle_common(shape, 1./rate, n=n)
    return gamma.rvs(shape, scale=scale, size=n)

