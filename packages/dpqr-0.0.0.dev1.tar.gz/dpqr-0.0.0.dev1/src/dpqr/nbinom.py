import numpy as np
from scipy.stats import nbinom

from .vec_recycle import vec_recycle_common

###############################################################################
# Negative Binomial

# dnbinom(x, size, prob, mu, log = FALSE)
# pnbinom(q, size, prob, mu, lower.tail = TRUE, log.p = FALSE)
# qnbinom(p, size, prob, mu, lower.tail = TRUE, log.p = FALSE)
# rnbinom(n, size, prob, mu)


def dnbinom(x, size, prob, log=False):
    """
    Density function for the Negative Binomial distribution.
    dnbinom(x, size, prob, log = False)
    """

    x, size, prob = vec_recycle_common(x, size, prob)
    if log:

        with np.errstate(divide='ignore', invalid='ignore'):
            x = nbinom.logpmf(x, size, prob)
        return np.nan_to_num(x, nan=-np.inf) #posinf=-1,neginf=-1 )
    else:
        x = nbinom.pmf(x, size, prob)
        return np.nan_to_num(x)


def pnbinom(q, size, prob, lower_tail=True, log_p=False):
    """
    Cumulative Density Function (CDF) for the Negative Binomial distribution.
    pnbinom(q, size, prob, lower_tail = True, log_p = False)
    """

    q, size, prob = vec_recycle_common(q, size, prob)
    if lower_tail:
        if log_p:
            return nbinom.logcdf(q, size, prob)
        else:
            return nbinom.cdf(q, size, prob)
    else:
        cdf = 1 - nbinom.cdf(q, size, prob)
        if log_p:
            return nbinom.logsf(q, size, prob)
        else:
            return nbinom.sf(q, size, prob)


def qnbinom(p, size, prob, lower_tail=True, log_p=False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the Negative Binomial distribution.
    qnbinom(p, size, prob, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1.0, p)
    p, size, prob = vec_recycle_common(p, size, prob)
    q = nbinom.ppf(p, size, prob)
    # np.place(q,q==-1.,0)
    if q == -1:
        q = 0
    return q


def rnbinom(n, size, prob):
    """
    Random number generator for the Negative Binomial distribution.
    rnbinom(n, size, prob)
    """

    size, prob = vec_recycle_common(size, prob, n=n)
    #print("nbinom.rvs(n=" + str(size) + ",p=" + str(prob) + ",size=" + str(n) + ")")
    return nbinom.rvs(n=size, p=prob, size=n)

