import numpy as np
from scipy.stats import invgamma

from .vec_recycle import vec_recycle_common

###############################################################################
# Beta

# note, invgamma not part of the base R definitions.
# using paramaterization from R library MCMCpack, not invgamma
# dinvgamma(x, shape, scale = 1, log = FALSE)
# pinvgamma(q, shape, scale = 1, lower.tail = TRUE, log.p = FALSE)
# qinvgamma(p, shape, scale = 1, lower.tail = TRUE, log.p = FALSE)
# rinvgamma(n, shape, scale = 1)

# only scale or rate can be defined.
#scale = 1., rate = 1./scale
# or just skip rate definition
#def dinvgamma(x, shape = 1., scale = None, rate = None, log = False):
def dinvgamma(x, shape = 1., scale = 1., log = False):
    """
    Density function for the Inverse Gamma distribution.
    dinvgamma(x, shape, scale, log = False)
    """

    x, shape, scale = vec_recycle_common(x, shape, scale)
    if log:
        x = invgamma.logpdf(x, a=shape, scale=scale)
        return np.nan_to_num(x, posinf=np.inf,neginf=-np.inf )
    else:
        x = invgamma.pdf(x, a=shape, scale=scale)
        return np.nan_to_num(x, posinf=np.inf,neginf=-np.inf )

   
def pinvgamma(q, shape=1., scale=1., lower_tail = True, log_p = False):
    """
    Cumulative Density Function (CDF) for the Inv Gamma distribution.
    pinvgamma(q, shape, scale, lower_tail = True, log_p = False):
    """
    
    q, shape, scale = vec_recycle_common(q, shape, scale)
    if lower_tail:
        if log_p:
            return invgamma.logcdf(q, a=shape, scale=scale)
        else:
            return invgamma.cdf(q, a=shape, scale=scale)
    else:
        if log_p:
            return invgamma.logsf(q, a=shape, scale=scale)
        else:
            return invgamma.sf(q, a=shape, scale=scale)


def qinvgamma(p, shape=1., scale=1., lower_tail = True, log_p = False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the Inv Gamma distribution.
    qinvgamma(p, shape, scale, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1., p)
    p, shape, scale = vec_recycle_common(p, shape, scale)
    q = invgamma.ppf(p, shape, scale=scale)
    return q


def rinvgamma(n, shape, scale):
    """
    Random number generator for the Inv Gamma distribution.
    rinvgamma(n, shape, scale)
    """

    shape, scale = vec_recycle_common(shape, scale, n=n)
    return invgamma.rvs(shape, scale=scale, size=n)

