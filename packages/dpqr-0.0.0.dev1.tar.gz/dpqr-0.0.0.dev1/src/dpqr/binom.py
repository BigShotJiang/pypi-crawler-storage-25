import numpy as np
from scipy.stats import binom

from .vec_recycle import vec_recycle_common

###############################################################################
# Binomial

# dbinom(x, size, prob, log = FALSE)
# pbinom(q, size, prob, lower_tail = True, log_p = False)
# qbinom(p, size, prob, lower_tail = True, log_p = False)
# rbinom(n, size, prob)


def dbinom(x, size, prob, log=False):
    """
    Density function for the Binomial distribution.
    dbinom(x, size, prob, log = False)
    """

    x, size, prob = vec_recycle_common(x, size, prob)
    if log:
        x = binom.logpmf(x, size, prob)
        return x
    else:
        x = binom.pmf(x, size, prob)
        return x


def pbinom(q, size, prob, lower_tail=True, log_p=False):
    """
    Cumulative Density Function (CDF) for the Binomial distribution.
    pbinom(q, size, prob, lower_tail = True, log_p = False)
    """

    q, size, prob = vec_recycle_common(q, size, prob)
    if lower_tail:
        if log_p:
            return binom.logcdf(q, size, prob)
        else:
            return binom.cdf(q, size, prob)
    else:
        if log_p:
            return binom.logsf(q, size, prob)
        else:
            return binom.sf(q, size, prob)


def qbinom(p, size, prob, lower_tail=True, log_p=False):
    """
    Inverse Cumulative Density Function (CDF^-1) for the Binomial distribution.
    qbinom(p, size, prob, lower_tail = True, log_p = False)
    """

    if log_p:
        p = np.exp(p)
    if not lower_tail:
        p = np.subtract(1.0, p)
    p, size, prob = vec_recycle_common(p, size, prob)
    q = binom.ppf(p, size, prob)
    # np.place(q,q==-1.,0)
    if q == -1:
        q = 0
    return q


def rbinom(n, size, prob):
    """
    Random number generator for the Binomial distribution.
    rbinom(n, size, prob)
    """

    size, prob = vec_recycle_common(size, prob, n=n)
    #print("binom.rvs(n=" + str(size) + ",p=" + str(prob) + ",size=" + str(n) + ")")
    return binom.rvs(n=size, p=prob, size=n)

