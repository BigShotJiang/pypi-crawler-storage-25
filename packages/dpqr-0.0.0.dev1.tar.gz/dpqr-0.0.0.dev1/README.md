# dpqr
R style dpqr distribution functions.

# NOTE: this is still experimental / in development.
version 0.0.0dev0

