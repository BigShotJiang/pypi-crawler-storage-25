from sys import version_info
from threading import Lock
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Sequence,
    Type,
    Union,
    cast,
    get_origin,
    get_type_hints,
    overload,
)

from denial import InnerNoneType
from locklib import ContextLockProtocol
from printo import superrepr
from sigmatch import PossibleCallMatcher, SignatureError, SignatureMismatchError
from simtypes import check

from skelet.sources.abstract import AbstractSource, ExpectedType
from skelet.sources.collection import SourcesCollection
from skelet.storage import Storage
from skelet.types import ChangeAction, EllipsisType, StorageType, ValueType

if version_info < (3, 9):  # pragma: no cover
    SequenceWithStrings = Sequence
else:  # pragma: no cover
    SequenceWithStrings = Sequence[str]  # type: ignore[misc, assignment]

sentinel = InnerNoneType()


class FieldDescriptor(Generic[ValueType, StorageType]):
    def __init__(  # noqa: PLR0913
        self,
        default: Union[ValueType, InnerNoneType] = sentinel,
        /,
        default_factory: Optional[Callable[[], ValueType]] = None,
        doc: Optional[str] = None,
        alias: Optional[str] = None,
        sources: Optional[List[Union[AbstractSource[ExpectedType], EllipsisType]]] = None,
        read_only: bool = False,
        validation: Optional[Union[Dict[str, Callable[[ValueType], bool]], Callable[[ValueType], bool]]] = None,
        validate_default: bool = True,
        hide: bool = False,
        action: Optional[ChangeAction[ValueType, StorageType]] = None,
        read_lock: bool = False,
        conflicts: Optional[Dict[str, Callable[[ValueType, ValueType, Any, Any], bool]]] = None,
        reverse_conflicts: bool = True,
        conversion: Optional[Callable[[ValueType], ValueType]] = None,
        share_mutex_with: Optional[SequenceWithStrings] = None,  # type: ignore[type-arg]
    ) -> None:
        if default_factory is not None:
            if default is not sentinel:
                raise ValueError('You can define a default value or a factory for default values, but not all at the same time.')
            self.check_callback_signature(default_factory, PossibleCallMatcher(), 'default_factory', 'with no arguments')

        if validation is not None:
            validation_matcher = PossibleCallMatcher('.')
            if isinstance(validation, dict):
                for validator_message, validator in validation.items():
                    self.check_callback_signature(validator, validation_matcher, f'validation item with key {superrepr(validator_message)}', 'with one positional argument: value is the field value being validated')
            else:
                self.check_callback_signature(validation, validation_matcher, 'validation', 'with one positional argument: value is the field value being validated')

        if action is not None:
            self.check_callback_signature(action, PossibleCallMatcher('...'), 'action', 'with three positional arguments: old_value is the previous field value, new_value is the assigned field value, and storage is the Storage instance')

        if conflicts is not None:
            conflict_checker_matcher = PossibleCallMatcher('....')
            for potentially_conflicting_field_name, conflict_checker in conflicts.items():
                self.check_callback_signature(conflict_checker, conflict_checker_matcher, f'conflicts item for field {superrepr(potentially_conflicting_field_name)}', "with four positional arguments: old is this field's previous value, new is this field's candidate value, other_old is the conflicting field's previous value, and other_new is the conflicting field's candidate value")

        if conversion is not None:
            self.check_callback_signature(conversion, PossibleCallMatcher('.'), 'conversion', 'with one positional argument: value is the raw field value before conversion')
            if default is not sentinel:
                self._default_before_conversion: Union[ValueType, InnerNoneType] = default
                self._default: Union[ValueType, InnerNoneType] = sentinel
            else:
                self._default_before_conversion = sentinel
                self._default = default
        else:
            self._default_before_conversion = sentinel
            self._default = default

        self._default_factory = default_factory
        self.read_only = read_only
        self.doc = doc
        self.alias = alias
        self.sources = sources
        self.validation = validation
        self.validate_default = validate_default
        self.hide = hide
        self.change_action: Optional[ChangeAction[ValueType, StorageType]] = action
        self.conflicts = conflicts
        self.reverse_conflicts_on = reverse_conflicts
        self.conversion = conversion
        self.share_mutex_with = share_mutex_with

        self.name: Optional[str] = None
        self.base_class: Optional[Type[Storage]] = None
        self.exception: Optional[BaseException] = None
        self.type_hint = Any

        self.lock: ContextLockProtocol = Lock()

        if read_lock:
            self.real_get = self.locked_get  # type: ignore[method-assign]
        else:
            self.real_get = self.unlocked_get  # type: ignore[method-assign]

    def __set_name__(self, owner: Type[Storage], name: str) -> None:
        if name.startswith('_'):
            self.raise_exception_in_storage(ValueError(f'Field name "{name}" cannot start with an underscore.'), raising_on=False)

        with self.lock:
            self.name = name
            if self.alias is None:
                self.alias = self.name
            self.type_hint = get_type_hints(owner).get(name, Any)

            if self.base_class is not None:
                self.raise_exception_in_storage(TypeError(f'{self.get_field_name_representation()} cannot be used in {owner.__name__} because it is already used in {self.base_class.__name__}.'), raising_on=False)

            if not issubclass(owner, Storage):
                self.raise_exception_in_storage(TypeError(f'{self.get_field_name_representation()} can only be used in Storage subclasses.'), raising_on=True)

            self.base_class = owner

            self.set_field_names(owner, name)
            if self._default_before_conversion is not sentinel:
                raw_default = self._default_before_conversion
            else:
                raw_default = self._default

            if raw_default is not sentinel:
                try:
                    exception_before = self.exception
                    prepared_default = self.prepare_value(cast(ValueType, raw_default), strict=False, validate=self.validate_default, raise_all=False)
                    if self.exception is not exception_before:
                        self._default = sentinel
                    else:
                        self._default = prepared_default
                except Exception as e:  # noqa: BLE001
                    self.exception = e
                    self._default = sentinel

    def __get__(self, instance: Storage, instance_class: Type[Storage]) -> ValueType:
        if instance is None:
            return self

        return self.real_get(instance, instance_class)

    def real_get(self, instance: Storage, instance_class: Type[Storage]) -> ValueType:
        raise NotImplementedError('If you see this error, it means something is broken.')  # pragma: no cover

    def locked_get(self, instance: Storage, instance_class: Type[Storage]) -> ValueType:
        with self.get_field_lock(instance):
            return self.unlocked_get(instance, instance_class)

    def unlocked_get(self, instance: Storage, instance_class: Type[Storage]) -> ValueType:  #noqa: ARG002
        return cast(ValueType, instance.__values__.get(cast(str, self.name)))

    def __set__(self, instance: StorageType, value: ValueType) -> None:
        if self.read_only:
            raise AttributeError(f'{self.get_field_name_representation()} is read-only.')

        value = self.prepare_value(value, strict=False, validate=True, raise_all=True)

        with self.get_field_lock(instance):
            old_value = self.unlocked_get(instance, type(instance))
            if self.conflicts is not None:
                for other_field_name, checker in self.conflicts.items():
                    other_field = getattr(type(instance), other_field_name)
                    other_field_value = other_field.unlocked_get(instance, type(instance))
                    if checker(old_value, value, other_field_value, other_field_value):
                        raise ValueError(f'The new {self.get_value_representation(value)} value of the {self.get_field_name_representation()} conflicts with the {other_field.get_value_representation(other_field_value)} value of the {other_field.get_field_name_representation()}.')

            if self.name in instance.__reverse_conflicts__:
                for other_field_name in instance.__reverse_conflicts__[self.name]:
                    other_field = getattr(type(instance), other_field_name)
                    other_field_value = other_field.unlocked_get(instance, type(instance))
                    other_field_checker = other_field.conflicts[self.name]
                    if other_field_checker(other_field_value, other_field_value, old_value, value):
                        raise ValueError(f'The new {self.get_value_representation(value)} value of the {self.get_field_name_representation()} conflicts with the {other_field.get_value_representation(other_field_value)} value of the {other_field.get_field_name_representation()}.')

            instance.__values__[cast(str, self.name)] = value
            if self.change_action is not None and value != old_value:
                self.change_action(old_value, value, instance)

    def __delete__(self, instance: Any) -> None:
        raise AttributeError(f"You can't delete the {self.get_field_name_representation()} value.")

    def set_field_names(self, owner: Type[Storage], name: str) -> None:
        if '__field_names__' not in owner.__dict__:
            owner.__field_names__ = []
            known_names = set()
            for parent in owner.__mro__:  # pragma: no branch
                if parent is owner:
                    continue
                if parent is Storage:
                    break
                for field_name in getattr(parent, '__field_names__', ()):
                    if field_name not in known_names:
                        known_names.add(field_name)
                        owner.__field_names__.append(field_name)
        else:
            known_names = set(owner.__field_names__)

        if name not in known_names:  # pragma: no branch
            cast(List[str], owner.__field_names__).append(name)

    def prepare_value(self, value: ValueType, strict: bool = False, validate: bool = True, raise_all: bool = False) -> ValueType:
        if strict:
            raw_type_check_passed = self.check_type_hints(value, strict=True, raise_all=raise_all)
        else:
            raw_type_check_passed = self.check_type_hints(value, raise_all=raise_all)

        if not raw_type_check_passed:
            return value

        if validate and not self.check_value(value, raise_all=raise_all):
            return value

        if self.conversion is None:
            return value

        value = self.conversion(value)
        if strict:
            converted_type_check_passed = self.check_type_hints(value, strict=True, raise_all=raise_all)
        else:
            converted_type_check_passed = self.check_type_hints(value, raise_all=raise_all)

        if not converted_type_check_passed:
            return value

        if validate:
            self.check_value(value, raise_all=raise_all)

        return value

    def check_type_hints(self, value: ValueType, strict: bool = False, raise_all: bool = False) -> bool:
        if not check(value, self.type_hint, strict=strict):  # type: ignore[arg-type, unused-ignore]
            origin = get_origin(self.type_hint)
            type_hint_name = self.type_hint.__name__ if origin is None else origin.__name__ if hasattr(origin, '__name__') else repr(origin)  # type: ignore[attr-defined, unused-ignore]
            self.raise_exception_in_storage(TypeError(f'The value {self.get_value_representation(value)} of the {self.get_field_name_representation()} does not match the type {type_hint_name}.'), raise_all)
            return False
        return True

    def get_field_name_representation(self) -> str:
        if self.doc is None:
            return f'"{self.name}" field'
        return f'"{self.name}" field ({self.doc})'

    def check_value(self, value: ValueType, raise_all: bool = False) -> bool:
        if self.validation is not None:
            if isinstance(self.validation, dict):
                for message, validator in self.validation.items():
                    if not validator(value):
                        self.raise_exception_in_storage(ValueError(message), raise_all)
                        return False
            elif not self.validation(value):
                self.raise_exception_in_storage(ValueError(f'The value {self.get_value_representation(value)} of the {self.get_field_name_representation()} does not match the validation.'), raise_all)
                return False
        return True

    def get_field_lock(self, instance: Storage) -> ContextLockProtocol:
        return instance.__locks__[cast(str, self.name)]

    def get_value_representation(self, value: ValueType) -> str:
        base = '***' if self.hide else f'{value!r}'
        return f'{base} ({type(value).__name__})'

    def raise_exception_in_storage(self, exception: BaseException, raising_on: bool) -> None:
        if raising_on:
            raise exception
        self.exception = exception

    def get_sources(self, instance: Storage) -> SourcesCollection[ExpectedType]:
        instance_sources_raw = instance.__instance_sources__

        if instance_sources_raw is None:
            return self._get_normal_sources(instance)

        has_ellipsis = False
        instance_only: List[AbstractSource[ExpectedType]] = []
        for source in instance_sources_raw:
            if source is Ellipsis:
                has_ellipsis = True
            else:
                instance_only.append(cast(AbstractSource[ExpectedType], source))

        if not has_ellipsis:
            return cast(SourcesCollection[ExpectedType], SourcesCollection(instance_only))

        normal_sources: SourcesCollection[ExpectedType] = self._get_normal_sources(instance)
        combined: List[AbstractSource[ExpectedType]] = list(instance_only) + list(normal_sources.sources)
        return cast(SourcesCollection[ExpectedType], SourcesCollection(combined))

    def _get_normal_sources(self, instance: Storage) -> SourcesCollection[ExpectedType]:
        if self.sources is None:
            return instance.__sources__

        result: List[AbstractSource[ExpectedType]] = []
        there_is_ellipsis = False

        for source in self.sources:
            if source is Ellipsis:
                there_is_ellipsis = True
            else:
                result.append(cast(AbstractSource[ExpectedType], source))

        if there_is_ellipsis:
            result.extend(instance.__sources__.sources)

        return cast(SourcesCollection[ExpectedType], SourcesCollection(result))

    def check_callback_signature(self, callback: Callable[..., Any], matcher: PossibleCallMatcher, callback_setting: str, call_description: str) -> None:
        try:
            matcher.match(callback, raise_exception=True)
        except (SignatureError, ValueError, RuntimeError) as exception:
            raise SignatureMismatchError(f'Callback configured in {callback_setting} is invalid: skelet calls it {call_description}, but {superrepr(callback)} cannot be called in that form.') from exception


@overload
def Field(
    default: Union[ValueType, InnerNoneType] = sentinel,
    /,
    default_factory: Optional[Callable[[], ValueType]] = None,
    doc: Optional[str] = None,
    alias: Optional[str] = None,
    sources: Optional[List[Union[AbstractSource[ExpectedType], EllipsisType]]] = None,
    read_only: bool = False,
    validation: Optional[Union[Dict[str, Callable[[ValueType], bool]], Callable[[ValueType], bool]]] = None,
    validate_default: bool = True,
    hide: bool = False,
    action: Optional[ChangeAction[ValueType, StorageType]] = None,
    read_lock: bool = False,
    conflicts: Optional[Dict[str, Callable[[ValueType, ValueType, Any, Any], bool]]] = None,
    reverse_conflicts: bool = True,
    conversion: None = None,
    share_mutex_with: Optional[Sequence[str]] = None,
) -> ValueType:
    ...  # pragma: no cover


@overload
def Field(
    default: Union[ValueType, InnerNoneType] = sentinel,
    /,
    default_factory: Optional[Callable[[], ValueType]] = None,
    doc: Optional[str] = None,
    alias: Optional[str] = None,
    sources: Optional[List[Union[AbstractSource[ExpectedType], EllipsisType]]] = None,
    read_only: bool = False,
    validation: Optional[Union[Dict[str, Callable[[ValueType], bool]], Callable[[ValueType], bool]]] = None,
    validate_default: bool = True,
    hide: bool = False,
    action: Optional[ChangeAction[ValueType, StorageType]] = None,
    read_lock: bool = False,
    conflicts: Optional[Dict[str, Callable[[ValueType, ValueType, Any, Any], bool]]] = None,
    reverse_conflicts: bool = True,
    *,
    conversion: Callable[[ValueType], ValueType],
    share_mutex_with: Optional[Sequence[str]] = None,
) -> ValueType:
    ...  # pragma: no cover


def Field(  # noqa: PLR0913, N802
    default: Union[Any, InnerNoneType] = sentinel,
    /,
    default_factory: Optional[Callable[[], Any]] = None,
    doc: Optional[str] = None,
    alias: Optional[str] = None,
    sources: Optional[List[Union[AbstractSource[ExpectedType], EllipsisType]]] = None,
    read_only: bool = False,
    validation: Optional[Union[Dict[str, Callable[[Any], bool]], Callable[[Any], bool]]] = None,
    validate_default: bool = True,
    hide: bool = False,
    action: Optional[ChangeAction[Any, StorageType]] = None,
    read_lock: bool = False,
    conflicts: Optional[Dict[str, Callable[[Any, Any, Any, Any], bool]]] = None,
    reverse_conflicts: bool = True,
    conversion: Optional[Callable[[Any], Any]] = None,
    share_mutex_with: Optional[Sequence[str]] = None,
) -> Any:
    return FieldDescriptor(
        default,
        default_factory=default_factory,
        doc=doc,
        alias=alias,
        sources=sources,
        read_only=read_only,
        validation=validation,
        validate_default=validate_default,
        hide=hide,
        action=action,
        read_lock=read_lock,
        conflicts=conflicts,
        reverse_conflicts=reverse_conflicts,
        conversion=conversion,
        share_mutex_with=share_mutex_with,
    )
