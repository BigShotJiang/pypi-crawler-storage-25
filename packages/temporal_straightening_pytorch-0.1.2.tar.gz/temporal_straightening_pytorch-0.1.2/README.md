## Temporal Straightening for Latent Planning, in Pytorch

Implementation of [Temporal Straightening for Latent Planning](https://arxiv.org/abs/2603.12231) (Wang et al., 2026) in Pytorch.

Learns a world model (encoder + predictor) with a curvature regularizer that encourages locally-straight latent trajectories. In this straightened representation space, Euclidean distance is a more faithful proxy for geodesic distance, making gradient-based planning significantly more stable and effective — improving open-loop success rates by 20–60% over frozen DINOv2 baselines.

[![PyPI version](https://badge.fury.io/py/temporal-straightening-pytorch.svg)](https://badge.fury.io/py/temporal-straightening-pytorch)

## Install

```bash
$ pip install temporal-straightening-pytorch
```

## Usage

### With ResNet encoder (trained from scratch)

```python
import torch
from temporal_straightening_pytorch import ResNetEncoder, TemporalStraightening, Trainer

encoder = ResNetEncoder(
    image_channels = 3,
    dim_out        = 8,     # spatial feature channels (paper uses 8)
    depths         = (1, 2, 2, 2),
    dims           = (32, 64, 128, 256),
)

model = TemporalStraightening(
    encoder,
    action_dim      = 2,    # raw action dimensionality
    num_patches     = 196,  # spatial tokens from encoder (e.g. 14×14)
    visual_dim      = 8,
    history_len     = 3,    # K past frames fed to predictor
    lambda_curv     = 0.1,  # straightening strength λ
)

# training forward
obs_seq    = torch.rand(4, 10, 3, 112, 112)  # (B, T, C, H, W)
action_seq = torch.rand(4,  9, 2)            # (B, T-1, action_dim)

losses = model(obs_seq, action_seq)
losses.total.backward()

print(f'pred: {losses.pred.item():.4f}  curv: {losses.curv.item():.4f}')
```

### With frozen DINOv2 backbone + CNN projector

```python
import torch
from temporal_straightening_pytorch import CNNProjector, TemporalStraightening

# wrap your frozen backbone with a trainable projector
class DINOv2WithProjector(torch.nn.Module):
    def __init__(self, backbone, projector):
        super().__init__()
        self.backbone  = backbone   # frozen
        self.projector = projector  # trainable

    def forward(self, x):
        with torch.no_grad():
            patch_tokens = self.backbone(x)   # (B, 196, 384) for DINOv2-small
        return self.projector(patch_tokens)   # (B, 196, 8)

projector = CNNProjector(
    backbone_dim = 384,   # DINOv2-small
    dim_out      = 8,
    grid_size    = 14,    # 14×14 = 196 patches for 224×224 input
)

encoder = DINOv2WithProjector(your_dinov2_backbone, projector)

model = TemporalStraightening(
    encoder,
    action_dim  = 2,
    num_patches = 196,
    visual_dim  = 8,
)
```

### Training

```python
from temporal_straightening_pytorch import Trainer

trainer = Trainer(
    model,
    dataset,                      # yields (obs_seq, action_seq) or (obs_seq, action_seq, prop_seq)
    train_batch_size = 32,
    train_lr         = 5e-4,      # predictor / heads
    encoder_lr       = 1e-5,      # encoder (lower, from paper)
    train_num_steps  = 100_000,
    ema_decay        = 0.995,
    amp              = True,
    save_every       = 1000,
    results_folder   = './results',
)

trainer.train()
```

Checkpoints are saved to `./results/model-{N}.pt` every `save_every` steps.

### Multi-GPU

```bash
$ accelerate config
$ accelerate launch train.py
```

### Gradient-based planning

```python
import torch
from temporal_straightening_pytorch import GradientPlanner

planner = GradientPlanner(
    model,
    action_dim    = 2,
    horizon       = 5,       # planning horizon H
    lr            = 0.01,    # Adam lr (from paper)
    num_steps     = 100,     # optimization steps (from paper)
    action_bounds = (-1, 1), # optional action clipping
)

# encode recent history
z_context = model.encode(obs_history)              # (B, K, P, D)

# optimize action sequence towards goal
actions, cost = planner.plan(z_context, obs_goal, verbose = True)
# actions: (B, H, action_dim)
```

## Architecture

```
obs_t ──► SensoryEncoder ──► z_t ∈ R^(P × D)
                                │
                         (stop-gradient)
                                │
[z_{t-K}..z_{t-1}] ──► Predictor (ViT, causal) ──► ẑ_t
                   +
[a_{t-K}..a_{t-1}] ──► ActionEncoder

Loss = MSE(ẑ_t, sg(z_t))
     + λ · (1 − cos(agg(v_t), agg(v_{t+1})))

where v_t = z_{t+1} − z_t  (latent velocity)
      agg = learnable MLP pooling head
```

## Citation

```bibtex
@article{Wang2026TemporalStraightening,
    title   = {Temporal Straightening for Latent Planning},
    author  = {Ying Wang and Oumayma Bounou and Gaoyue Zhou and Randall Balestriero and Tim G. J. Rudner and Yann LeCun and Mengye Ren},
    journal = {arXiv},
    year    = {2026},
    url     = {https://arxiv.org/abs/2603.12231}
}
```
