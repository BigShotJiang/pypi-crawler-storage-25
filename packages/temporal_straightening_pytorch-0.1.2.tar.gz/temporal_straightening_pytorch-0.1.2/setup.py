from setuptools import setup, find_packages

exec(open('temporal_straightening_pytorch/version.py').read())

setup(
    name = 'temporal-straightening-pytorch',
    packages = find_packages(),
    version = __version__,
    license = 'MIT',
    description = 'Temporal Straightening for Latent Planning - Pytorch',
    author = 'MohamedFarag21',
    url = 'https://github.com/MohamedFarag21/temporal-straightening-pytorch',
    long_description_content_type = 'text/markdown',
    keywords = [
        'artificial intelligence',
        'deep learning',
        'world models',
        'latent planning',
        'representation learning',
    ],
    install_requires = [
        'accelerate',
        'einops>=0.7',
        'ema-pytorch>=0.4.2',
        'torch>=2.0',
        'tqdm',
    ],
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3.6',
    ],
)
