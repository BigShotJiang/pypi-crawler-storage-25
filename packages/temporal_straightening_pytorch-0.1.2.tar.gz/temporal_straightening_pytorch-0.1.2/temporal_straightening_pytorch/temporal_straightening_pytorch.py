import math
from pathlib import Path
from collections import namedtuple
from multiprocessing import cpu_count

import torch
from torch import nn, einsum
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.optim import Adam

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from tqdm.auto import tqdm
from ema_pytorch import EMA
from accelerate import Accelerator

# ──────────────────────────────────────────────
# constants
# ──────────────────────────────────────────────

LossBreakdown = namedtuple('LossBreakdown', ['total', 'pred', 'curv'])

# ──────────────────────────────────────────────
# helpers
# ──────────────────────────────────────────────

def exists(x):
    return x is not None

def default(val, d):
    if exists(val):
        return val
    return d() if callable(d) else d

def cycle(dl):
    while True:
        for data in dl:
            yield data

def divisible_by(numer, denom):
    return (numer % denom) == 0

def num_to_groups(num, divisor):
    groups = num // divisor
    remainder = num % divisor
    arr = [divisor] * groups
    if remainder > 0:
        arr.append(remainder)
    return arr

def l2norm(t, dim = -1):
    return F.normalize(t, dim = dim)

def cosine_sim(a, b, dim = -1):
    return (l2norm(a, dim = dim) * l2norm(b, dim = dim)).sum(dim = dim)

# ──────────────────────────────────────────────
# small helper modules
# ──────────────────────────────────────────────

class RMSNorm(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.scale = dim ** 0.5
        self.gamma = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        return F.normalize(x, dim = -1) * self.scale * self.gamma


class FeedForward(nn.Module):
    def __init__(self, dim, mult = 4, dropout = 0.):
        super().__init__()
        inner_dim = int(dim * mult)
        self.net = nn.Sequential(
            RMSNorm(dim),
            nn.Linear(dim, inner_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = heads * dim_head
        self.heads = heads
        self.scale = dim_head ** -0.5

        self.norm    = RMSNorm(dim)
        self.to_qkv  = nn.Linear(dim, inner_dim * 3, bias = False)
        self.to_out  = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x, mask = None):
        x   = self.norm(x)
        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

        dots = einsum('b h i d, b h j d -> b h i j', q, k) * self.scale

        if exists(mask):
            dots = dots.masked_fill(~mask, -torch.finfo(dots.dtype).max)

        attn = dots.softmax(dim = -1)
        out  = einsum('b h i j, b h j d -> b h i d', attn, v)
        out  = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)


class TransformerBlock(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, ff_mult = 4, dropout = 0.):
        super().__init__()
        self.attn = Attention(dim, heads = heads, dim_head = dim_head, dropout = dropout)
        self.ff   = FeedForward(dim, mult = ff_mult, dropout = dropout)

    def forward(self, x, mask = None):
        x = self.attn(x, mask = mask) + x
        x = self.ff(x) + x
        return x

# ──────────────────────────────────────────────
# ResNet encoder (from scratch)
# ──────────────────────────────────────────────

class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride = 1):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, stride = stride, padding = 1, bias = False),
            nn.GroupNorm(min(32, out_channels), out_channels),
            nn.GELU(),
            nn.Conv2d(out_channels, out_channels, 3, padding = 1, bias = False),
            nn.GroupNorm(min(32, out_channels), out_channels),
        )
        self.skip = (
            nn.Conv2d(in_channels, out_channels, 1, stride = stride, bias = False)
            if (in_channels != out_channels or stride != 1) else nn.Identity()
        )

    def forward(self, x):
        return F.gelu(self.conv(x) + self.skip(x))


class ResNetEncoder(nn.Module):
    """
    Lightweight ResNet encoder trained from scratch.

    Maps (B, C, H, W) → (B, num_patches, dim_out) spatial features,
    where num_patches = (H / 2^(len(depths)-1))^2.

    Args:
        image_channels: input image channels (default 3 for RGB)
        dim_out:        output feature dimension per spatial token
        depths:         number of residual blocks per stage
        dims:           channel widths per stage
    """
    def __init__(
        self,
        image_channels = 3,
        dim_out = 8,
        depths = (1, 2, 2, 2),
        dims = (32, 64, 128, 256),
    ):
        super().__init__()

        stages = []
        in_ch  = image_channels

        for i, (depth, dim) in enumerate(zip(depths, dims)):
            stride = 2 if i > 0 else 1
            stage  = [ResidualBlock(in_ch, dim, stride = stride)]
            stage += [ResidualBlock(dim, dim) for _ in range(depth - 1)]
            stages.append(nn.Sequential(*stage))
            in_ch = dim

        self.stages = nn.ModuleList(stages)
        self.proj   = nn.Conv2d(dims[-1], dim_out, 1)

    def forward(self, x):
        for stage in self.stages:
            x = stage(x)
        x = self.proj(x)                                 # (B, dim_out, h, w)
        x = rearrange(x, 'b d h w -> b (h w) d')        # (B, num_patches, dim_out)
        return x

# ──────────────────────────────────────────────
# CNN projector (for frozen backbone features)
# ──────────────────────────────────────────────

class CNNProjector(nn.Module):
    """
    Lightweight CNN projector applied on top of a frozen visual backbone.

    Maps (B, num_patches, backbone_dim) → (B, num_patches, dim_out).
    Assumes patches form a square grid of side grid_size.

    Use this on top of DINOv2 or any ViT backbone that returns patch tokens.

    Args:
        backbone_dim:   input feature dimension (e.g. 384 for DINOv2-small)
        dim_out:        output feature dimension (paper uses 8)
        grid_size:      spatial grid side length (e.g. 14 for DINOv2 with 224×224 input)
        hidden_dim:     intermediate channel width
    """
    def __init__(
        self,
        backbone_dim = 384,
        dim_out = 8,
        grid_size = 14,
        hidden_dim = 64,
    ):
        super().__init__()
        self.grid_size = grid_size
        self.proj = nn.Sequential(
            Rearrange('b (h w) d -> b d h w', h = grid_size, w = grid_size),
            nn.Conv2d(backbone_dim, hidden_dim, 1),
            nn.GELU(),
            nn.Conv2d(hidden_dim, dim_out, 1),
            Rearrange('b d h w -> b (h w) d'),
        )

    def forward(self, x):
        # x: (B, num_patches, backbone_dim) — patch tokens from frozen backbone
        return self.proj(x)

# ──────────────────────────────────────────────
# aggregation head (for curvature)
# ──────────────────────────────────────────────

class AggregationHead(nn.Module):
    """
    Learnable pooling head: (B, num_patches, dim) → (B, dim_out).

    Used to aggregate spatial velocity vectors before computing cosine similarity
    for the curvature loss. This is the 'agg' variant from Section B.5, which
    achieves the best planning performance.

    Args:
        dim_in:      per-patch feature dimension
        num_patches: number of spatial patches (e.g. 196 for 14×14 grid)
        dim_out:     pooled feature dimension (paper uses 128)
    """
    def __init__(self, dim_in, num_patches, dim_out = 128):
        super().__init__()
        self.net = nn.Sequential(
            Rearrange('b n d -> b (n d)'),
            nn.Linear(num_patches * dim_in, dim_out * 2),
            nn.GELU(),
            nn.Linear(dim_out * 2, dim_out),
        )

    def forward(self, x):
        return self.net(x)

# ──────────────────────────────────────────────
# action encoder
# ──────────────────────────────────────────────

class ActionEncoder(nn.Module):
    """
    Maps raw actions (B, action_dim) → (B, dim_out).

    Args:
        action_dim:  raw action dimensionality
        dim_out:     output dimensionality (should match predictor_dim)
        hidden_dim:  MLP hidden width
    """
    def __init__(self, action_dim, dim_out, hidden_dim = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(action_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, dim_out),
        )

    def forward(self, x):
        return self.net(x)

# ──────────────────────────────────────────────
# predictor (ViT with causal temporal attention)
# ──────────────────────────────────────────────

class Predictor(nn.Module):
    """
    ViT-based dynamics predictor with causal temporal attention.

    Takes a history of K (visual, [prop,] action) token sets and predicts
    the visual tokens of the next step.

    Causal masking: tokens at step t can only attend to tokens from steps < t,
    i.e. they cannot attend within their own timestep.

    Args:
        num_patches:    number of spatial visual tokens per frame
        visual_dim:     per-patch visual feature dimension
        action_dim:     encoded action dimension (output of ActionEncoder)
        prop_dim:       optional proprioceptive feature dimension
        history_len:    number of past frames K fed as context
        predictor_dim:  transformer hidden dimension
        depth:          number of transformer blocks
        heads:          number of attention heads
        dim_head:       per-head dimension
        ff_mult:        feedforward expansion factor
        dropout:        dropout rate
    """
    def __init__(
        self,
        num_patches,
        visual_dim,
        action_dim,
        *,
        prop_dim = None,
        history_len = 3,
        predictor_dim = 256,
        depth = 4,
        heads = 8,
        dim_head = 32,
        ff_mult = 4,
        dropout = 0.,
    ):
        super().__init__()
        self.num_patches  = num_patches
        self.history_len  = history_len
        has_prop          = exists(prop_dim)

        # tokens per timestep: visual patches + action + optional prop
        self.tokens_per_step = num_patches + 1 + (1 if has_prop else 0)

        # input projections
        self.visual_proj = nn.Linear(visual_dim, predictor_dim)
        self.action_proj = nn.Linear(action_dim, predictor_dim)
        self.prop_proj   = nn.Linear(prop_dim, predictor_dim) if has_prop else None

        # positional embeddings
        self.token_pos = nn.Embedding(self.tokens_per_step, predictor_dim)
        self.step_pos  = nn.Embedding(history_len, predictor_dim)

        # transformer
        self.layers = nn.ModuleList([
            TransformerBlock(
                predictor_dim,
                heads    = heads,
                dim_head = dim_head,
                ff_mult  = ff_mult,
                dropout  = dropout,
            )
            for _ in range(depth)
        ])
        self.norm     = RMSNorm(predictor_dim)
        self.out_proj = nn.Linear(predictor_dim, visual_dim)

        # causal mask: step t attends only to steps < t
        total = self.tokens_per_step * history_len
        mask  = torch.ones(total, total, dtype = torch.bool).tril()

        for step in range(history_len):
            s = step * self.tokens_per_step
            e = s + self.tokens_per_step
            mask[s:e, s:e] = False   # block self-step attention

        self.register_buffer('causal_mask', mask)

    def forward(self, visual_hist, action_hist, prop_hist = None):
        """
        Args:
            visual_hist: (B, K, num_patches, visual_dim)
            action_hist: (B, K, action_dim)   — already encoded
            prop_hist:   (B, K, prop_dim) or None

        Returns:
            pred: (B, num_patches, visual_dim)
        """
        b, k   = visual_hist.shape[:2]
        device = visual_hist.device

        v = self.visual_proj(visual_hist)               # (B, K, P, D)
        a = self.action_proj(action_hist)               # (B, K, D)
        a = rearrange(a, 'b k d -> b k 1 d')

        if exists(prop_hist) and exists(self.prop_proj):
            p            = self.prop_proj(prop_hist)    # (B, K, D)
            p            = rearrange(p, 'b k d -> b k 1 d')
            step_tokens  = torch.cat([v, p, a], dim = 2)
        else:
            step_tokens  = torch.cat([v, a], dim = 2)  # (B, K, P+1, D)

        tok_pos  = self.token_pos(torch.arange(self.tokens_per_step, device = device))
        step_pos = self.step_pos(torch.arange(k, device = device))
        step_pos = rearrange(step_pos, 'k d -> k 1 d')

        step_tokens = step_tokens + tok_pos + step_pos  # (B, K, P+1, D)

        x = rearrange(step_tokens, 'b k n d -> b (k n) d')

        seq_len = x.shape[1]
        mask    = self.causal_mask[:seq_len, :seq_len]
        mask    = rearrange(mask, 'i j -> 1 1 i j')

        for layer in self.layers:
            x = layer(x, mask = mask)

        x = self.norm(x)

        # extract visual token predictions from the last step's tokens
        last = x[:, -self.tokens_per_step:]             # (B, P+1, D)
        return self.out_proj(last[:, :self.num_patches]) # (B, P, visual_dim)

# ──────────────────────────────────────────────
# main wrapper
# ──────────────────────────────────────────────

class TemporalStraightening(nn.Module):
    """
    Temporal Straightening for Latent Planning — PyTorch implementation.

    Paper: "Temporal Straightening for Latent Planning"
    Wang et al., arXiv:2603.12231 (2026)
    https://agenticlearning.ai/temporal-straightening

    Learns a world model (encoder + predictor) with a curvature regularizer
    that encourages locally-straight latent trajectories. Straighter trajectories
    make Euclidean distance a better proxy for geodesic distance and improve
    the conditioning of gradient-based planners.

    Training loss:
        L_total = L_pred + λ · L_curv
        L_pred  = MSE(z_pred, sg(z_target))          — stop-grad on target
        L_curv  = 1 − cos(agg(v_t), agg(v_{t+1}))   — cosine of pooled velocities

    Args:
        encoder:         sensory encoder module.
                         Accepts (B, C, H, W) and returns (B, num_patches, visual_dim).
                         Use ResNetEncoder for from-scratch, or CNNProjector on top
                         of a frozen backbone (e.g. DINOv2).
        action_dim:      raw action dimensionality.
        num_patches:     number of spatial tokens output by the encoder.
        visual_dim:      per-token feature dimension (paper uses 8).
        history_len:     number of past frames K fed to the predictor.
        prop_dim:        optional proprioceptive state dimensionality.
        lambda_curv:     straightening regularization strength λ (paper: 0.1).
        agg_dim:         output dimension of the aggregation head (paper: 128).
        predictor_dim:   transformer hidden dimension.
        predictor_depth: number of transformer blocks.
        predictor_heads: number of attention heads.
        predictor_dim_head: per-head dimension.
    """
    def __init__(
        self,
        encoder,
        *,
        action_dim,
        num_patches,
        visual_dim = 8,
        history_len = 3,
        prop_dim = None,
        lambda_curv = 0.1,
        agg_dim = 128,
        predictor_dim = 256,
        predictor_depth = 4,
        predictor_heads = 8,
        predictor_dim_head = 32,
    ):
        super().__init__()
        self.encoder     = encoder
        self.num_patches = num_patches
        self.visual_dim  = visual_dim
        self.history_len = history_len
        self.lambda_curv = lambda_curv

        self.action_encoder = ActionEncoder(
            action_dim = action_dim,
            dim_out    = predictor_dim,
        )

        self.predictor = Predictor(
            num_patches   = num_patches,
            visual_dim    = visual_dim,
            action_dim    = predictor_dim,
            prop_dim      = prop_dim,
            history_len   = history_len,
            predictor_dim = predictor_dim,
            depth         = predictor_depth,
            heads         = predictor_heads,
            dim_head      = predictor_dim_head,
        )

        self.agg_head = AggregationHead(
            dim_in      = visual_dim,
            num_patches = num_patches,
            dim_out     = agg_dim,
        )

    @property
    def device(self):
        return next(self.parameters()).device

    @torch.no_grad()
    def encode(self, obs):
        """Encode observations. obs: (B, C, H, W) → (B, num_patches, visual_dim)."""
        return self.encoder(obs)

    def _curvature_loss(self, z_seq):
        """
        Straightening loss over a latent sequence.

        z_seq: (B, T, num_patches, visual_dim)
        Uses the learnable aggregation head on consecutive velocity vectors.
        """
        v = z_seq[:, 1:] - z_seq[:, :-1]   # (B, T-1, P, D)  latent velocities

        if v.shape[1] < 2:
            return z_seq.new_tensor(0.)

        b, t = v.shape[:2]
        v_flat = rearrange(v, 'b t p d -> (b t) p d')
        v_agg  = self.agg_head(v_flat)                            # (B*T, agg_dim)
        v_agg  = rearrange(v_agg, '(b t) d -> b t d', b = b)

        # cosine similarity of consecutive aggregated velocities (Eq. 4 + pooling head)
        sim = cosine_sim(v_agg[:, :-1], v_agg[:, 1:], dim = -1)  # (B, T-2)
        return (1. - sim).mean()

    def forward(self, obs_seq, action_seq, prop_seq = None):
        """
        Training forward pass.

        Args:
            obs_seq:    (B, T, C, H, W)      sequence of observations
            action_seq: (B, T-1, action_dim)  actions taken between frames
            prop_seq:   (B, T, prop_dim) or None

        Returns:
            LossBreakdown(total, pred, curv)
        """
        b, t = obs_seq.shape[:2]

        # encode all frames
        obs_flat = rearrange(obs_seq, 'b t c h w -> (b t) c h w')
        z_flat   = self.encoder(obs_flat)                               # (B*T, P, D)
        z_seq    = rearrange(z_flat, '(b t) p d -> b t p d', b = b)

        # encode all actions
        a_flat = rearrange(action_seq, 'b t d -> (b t) d')
        a_flat = self.action_encoder(a_flat)
        a_seq  = rearrange(a_flat, '(b t) d -> b t d', b = b)

        # prediction loss — teacher-forcing over every valid step
        pred_losses = []

        for i in range(self.history_len, t):
            z_hist = z_seq[:, i - self.history_len : i]   # (B, K, P, D)
            a_hist = a_seq[:, i - self.history_len : i]   # (B, K, D)
            p_hist = prop_seq[:, i - self.history_len : i] if exists(prop_seq) else None

            z_pred   = self.predictor(z_hist, a_hist, p_hist)
            z_target = z_seq[:, i].detach()                # stop-gradient on target (Eq. 5)

            pred_losses.append(F.mse_loss(z_pred, z_target))

        pred_loss = torch.stack(pred_losses).mean() if pred_losses else z_seq.new_tensor(0.)
        curv_loss = self._curvature_loss(z_seq)

        total = pred_loss + self.lambda_curv * curv_loss
        return LossBreakdown(total, pred_loss, curv_loss)

# ──────────────────────────────────────────────
# gradient-based planner
# ──────────────────────────────────────────────

class GradientPlanner(nn.Module):
    """
    Open-loop gradient-based planner (Algorithm 1 / Section B.1).

    Optimizes an action sequence by unrolling the learned dynamics and
    minimizing MSE between the predicted terminal latent and the goal latent.
    Uses Adam with a fixed learning rate (paper: lr=0.01, 100 steps).

    Args:
        world_model:   trained TemporalStraightening model
        action_dim:    raw action dimensionality
        horizon:       planning horizon H (paper uses H=5 with frameskip=5)
        lr:            Adam learning rate (paper: 0.01)
        num_steps:     number of optimization steps (paper: 100)
        action_bounds: optional (lo, hi) tuple to clamp actions after each step
    """
    def __init__(
        self,
        world_model,
        *,
        action_dim,
        horizon = 5,
        lr = 0.01,
        num_steps = 100,
        action_bounds = None,
    ):
        super().__init__()
        self.world_model   = world_model
        self.action_dim    = action_dim
        self.horizon       = horizon
        self.lr            = lr
        self.num_steps     = num_steps
        self.action_bounds = action_bounds

    def plan(self, z_context, obs_goal, *, verbose = False):
        """
        Run gradient-based planning.

        Args:
            z_context: (B, K, num_patches, visual_dim)  recent history of latents
            obs_goal:  (B, C, H, W)                     goal observation

        Returns:
            actions:    (B, H, action_dim)  optimized action sequence
            final_cost: float               terminal planning cost
        """
        b      = z_context.shape[0]
        device = z_context.device
        world  = self.world_model

        with torch.no_grad():
            z_goal     = world.encoder(obs_goal)       # (B, P, D)
            z_goal_agg = world.agg_head(z_goal)        # (B, agg_dim)

        actions   = torch.zeros(b, self.horizon, self.action_dim, device = device, requires_grad = True)
        optimizer = Adam([actions], lr = self.lr)

        pbar = tqdm(range(self.num_steps), desc = 'planning', leave = False, disable = not verbose)

        for _ in pbar:
            optimizer.zero_grad()

            # encode actions
            a_flat = rearrange(actions, 'b h d -> (b h) d')
            a_enc  = world.action_encoder(a_flat)
            a_seq  = rearrange(a_enc, '(b h) d -> b h d', b = b)

            # unroll dynamics
            z_curr = z_context.clone()                 # (B, K, P, D)

            for step in range(self.horizon):
                # slide context window to always feed K steps
                step_a = a_seq[:, max(0, step - world.history_len + 1) : step + 1]
                step_z = z_curr[:, -(step_a.shape[1]):]

                z_pred = world.predictor(step_z, step_a)
                z_curr = torch.cat([z_curr[:, 1:], z_pred.unsqueeze(1)], dim = 1)

            z_terminal     = z_curr[:, -1]             # (B, P, D)
            z_terminal_agg = world.agg_head(z_terminal)# (B, agg_dim)

            cost = F.mse_loss(z_terminal_agg, z_goal_agg.detach())
            cost.backward()

            if exists(self.action_bounds):
                lo, hi = self.action_bounds
                with torch.no_grad():
                    actions.clamp_(lo, hi)

            optimizer.step()

            if verbose:
                pbar.set_description(f'planning cost: {cost.item():.5f}')

        return actions.detach(), cost.item()

# ──────────────────────────────────────────────
# trainer
# ──────────────────────────────────────────────

class Trainer:
    """
    Full training loop for TemporalStraightening.

    Handles EMA, mixed-precision, multi-GPU via 🤗 Accelerate,
    separate learning rates for encoder and rest of the model,
    checkpointing, and loss logging.

    Your dataset should yield either:
        (obs_seq, action_seq)
        (obs_seq, action_seq, prop_seq)

    where:
        obs_seq:    (T, C, H, W)         observation sequence
        action_seq: (T-1, action_dim)    actions between frames
        prop_seq:   (T, prop_dim)        optional proprioception

    Args:
        model:                    TemporalStraightening instance
        dataset:                  torch Dataset (see above)
        train_batch_size:         batch size
        train_lr:                 learning rate for predictor / heads (paper: 5e-4)
        encoder_lr:               learning rate for encoder (paper: 1e-5)
        train_num_steps:          total number of training steps
        gradient_accumulate_every: gradient accumulation steps
        ema_decay:                EMA decay rate
        ema_update_every:         EMA update frequency in steps
        save_every:               checkpoint interval in steps
        results_folder:           directory for checkpoints
        amp:                      enable mixed-precision training
        mixed_precision_type:     'fp16' or 'bf16'
        max_grad_norm:            gradient clipping norm
    """
    def __init__(
        self,
        model,
        dataset,
        *,
        train_batch_size = 32,
        train_lr = 5e-4,
        encoder_lr = 1e-5,
        train_num_steps = 100_000,
        gradient_accumulate_every = 1,
        ema_decay = 0.995,
        ema_update_every = 10,
        save_every = 1000,
        results_folder = './results',
        amp = False,
        mixed_precision_type = 'fp16',
        split_batches = True,
        max_grad_norm = 1.,
    ):
        super().__init__()

        self.accelerator = Accelerator(
            split_batches   = split_batches,
            mixed_precision = mixed_precision_type if amp else 'no',
        )

        self.model = model

        # separate learning rates: encoder gets lower lr (Table 4 in paper)
        encoder_params     = list(model.encoder.parameters())
        encoder_param_ids  = {id(p) for p in encoder_params}
        other_params       = [p for p in model.parameters() if id(p) not in encoder_param_ids]

        self.opt = Adam([
            {'params': encoder_params, 'lr': encoder_lr},
            {'params': other_params,   'lr': train_lr},
        ])

        self.train_num_steps           = train_num_steps
        self.batch_size                = train_batch_size
        self.gradient_accumulate_every = gradient_accumulate_every
        self.save_every                = save_every
        self.max_grad_norm             = max_grad_norm

        dl = DataLoader(
            dataset,
            batch_size  = train_batch_size,
            shuffle     = True,
            pin_memory  = True,
            num_workers = cpu_count(),
        )

        self.model, self.opt, dl = self.accelerator.prepare(self.model, self.opt, dl)
        self.dl   = cycle(dl)
        self.ema  = EMA(model, beta = ema_decay, update_every = ema_update_every)
        self.ema.to(self.device)

        self.results_folder = Path(results_folder)
        self.results_folder.mkdir(exist_ok = True)

        self.step = 0

    @property
    def device(self):
        return self.accelerator.device

    def save(self, milestone):
        if not self.accelerator.is_local_main_process:
            return
        data = {
            'step':   self.step,
            'model':  self.accelerator.get_state_dict(self.model),
            'opt':    self.opt.state_dict(),
            'ema':    self.ema.state_dict(),
            'scaler': self.accelerator.scaler.state_dict() if exists(self.accelerator.scaler) else None,
        }
        torch.save(data, str(self.results_folder / f'model-{milestone}.pt'))

    def load(self, milestone):
        device = self.accelerator.device
        data   = torch.load(
            str(self.results_folder / f'model-{milestone}.pt'),
            map_location  = device,
            weights_only  = True,
        )
        model = self.accelerator.unwrap_model(self.model)
        model.load_state_dict(data['model'])
        self.step = data['step']
        self.opt.load_state_dict(data['opt'])
        self.ema.load_state_dict(data['ema'])
        if exists(self.accelerator.scaler) and exists(data['scaler']):
            self.accelerator.scaler.load_state_dict(data['scaler'])

    def train(self):
        accelerator = self.accelerator

        with tqdm(
            initial = self.step,
            total   = self.train_num_steps,
            disable = not accelerator.is_main_process,
        ) as pbar:

            while self.step < self.train_num_steps:
                total_loss = total_pred = total_curv = 0.

                for _ in range(self.gradient_accumulate_every):
                    batch = next(self.dl)

                    if len(batch) == 3:
                        obs_seq, action_seq, prop_seq = batch
                    else:
                        (obs_seq, action_seq), prop_seq = batch, None

                    obs_seq    = obs_seq.to(self.device)
                    action_seq = action_seq.to(self.device)
                    prop_seq   = prop_seq.to(self.device) if exists(prop_seq) else None

                    with self.accelerator.autocast():
                        losses = self.model(obs_seq, action_seq, prop_seq)
                        loss   = losses.total / self.gradient_accumulate_every

                    total_loss += loss.item()
                    total_pred += losses.pred.item() / self.gradient_accumulate_every
                    total_curv += losses.curv.item() / self.gradient_accumulate_every

                    self.accelerator.backward(loss)

                accelerator.wait_for_everyone()
                accelerator.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                self.opt.step()
                self.opt.zero_grad()
                accelerator.wait_for_everyone()

                self.step += 1

                if accelerator.is_main_process:
                    self.ema.update()

                    pbar.set_description(
                        f'loss: {total_loss:.4f}  '
                        f'pred: {total_pred:.4f}  '
                        f'curv: {total_curv:.4f}'
                    )

                    if self.step != 0 and divisible_by(self.step, self.save_every):
                        self.save(self.step // self.save_every)

                pbar.update(1)

        accelerator.print('training complete')
