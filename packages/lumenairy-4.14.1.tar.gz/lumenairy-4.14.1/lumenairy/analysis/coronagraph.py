"""
lumenairy.analysis.coronagraph -- coronagraph performance analysis.

Post-processing analysis for coronagraphic systems: the
``contrast_curve`` style radial reduction comparing a coronagraphed
PSF to its un-coronagraphed reference.

The element-side coronagraph builders (Lyot focal-plane mask, vortex
phase mask, Lyot stop, apodized pupil) live in
:mod:`lumenairy.elements`.  This module is the analysis counterpart.

Moved here in 4.3.0 from ``lumenairy.elements.elements``;
``lumenairy.coronagraph_contrast_curve`` and the
``elements`` re-export path continue to work.
"""

from __future__ import annotations

import numpy as np


def coronagraph_contrast_curve(psf_coro, psf_ref, dx_focal, wavelength,
                                  f_eff, *, pupil_diameter_m=None,
                                  n_radii=64, max_lam_over_D=20.0,
                                  center=None, azimuthal='mean'):
    """Compute the post-coronagraph contrast curve vs angular separation.

    Given a coronagraphed PSF (e.g. the output of the
    apply_aperture -> Fraunhofer-MFT -> vortex / Lyot-FPM -> back-MFT
    -> Lyot stop -> compute_psf pipeline) and the un-coronagraphed
    reference PSF of the same pupil, returns the **radial contrast**
    -- the local mean coronagraphed intensity divided by the
    reference peak intensity -- as a function of angular separation
    in units of ``lambda * f / D``.

    Parameters
    ----------
    psf_coro : ndarray (real, N x N)
        Intensity PSF of the coronagraphed system at the final
        detector plane.
    psf_ref : ndarray (real, N x N)
        Intensity PSF of the same pupil WITHOUT the coronagraph
        masks (used to set the contrast denominator at the on-axis
        peak).  Both PSFs should be computed with the same
        normalisation (typically ``normalize='none'`` so the
        intensities are directly comparable).
    dx_focal : float
        Focal-plane grid spacing [m].
    wavelength : float
        Operating wavelength [m].
    f_eff : float
        Effective focal length [m].
    pupil_diameter_m : float, optional but recommended
        Entrance-pupil diameter [m].  Together with ``wavelength``,
        ``f_eff``, and ``dx_focal`` this sets the absolute λ·f/D
        scale via ``pix_per_lam_over_D = λ · f_eff / (D · dx_focal)``.
        Pre-4.9 the function assumed ``pix_per_lam_over_D = N`` (the
        FFT-natural pitch with no zero-padding), which is correct
        only for that one geometry and produces incorrect angular
        scales for the oversampled / MFT-zoomed focal grids typical
        in coronagraphy.  When ``pupil_diameter_m`` is omitted,
        a ``RuntimeWarning`` is emitted and the legacy ``N``
        approximation is used.
    n_radii : int, default 64
        Number of radial bins.
    max_lam_over_D : float, default 20.0
        Outer radius of the contrast curve in units of
        ``lambda * f_eff / D``.  Past this point the bins overflow
        the grid for typical setups.
    center : tuple ``(xc_pix, yc_pix)``, optional
        Pixel coordinates of the coronagraphic chief.  Defaults to
        the brightest pixel of ``psf_ref`` (the un-blocked chief).
    azimuthal : ``'mean'`` (default) / ``'median'`` / ``'rms'`` / ``'std'``
        Per-radius reduction over the azimuth.  ``'mean'`` is the
        textbook "average contrast curve"; ``'median'`` is robust
        against bright residual speckles; ``'rms'`` reports the raw
        ``sqrt(mean(I^2))``; ``'std'`` reports the mean-subtracted
        ``sqrt(mean((I - mean(I))^2))`` -- the actual 1-sigma
        speckle-noise floor metric.  4.10: pre-4.10 mis-described
        ``'rms'`` as the 1-sigma metric (it includes any non-zero
        residual bias).

    Returns
    -------
    result : dict with keys
        * ``'r_lam_over_D'`` -- ``(n_radii,)`` array of radial bin
          centres in units of ``lambda * f_eff / D``.
        * ``'contrast'`` -- ``(n_radii,)`` array of radial contrast
          values.
        * ``'r_pixels'`` -- raw radial bin centres in pixels.
        * ``'peak_ref'`` -- the reference peak intensity used as
          denominator.
        * ``'center'`` -- pixel coordinates of the chief.

    Notes
    -----
    For a vortex coronagraph with a 0.85 * D Lyot stop the curve
    should drop by 3-4 orders of magnitude inside ``~3 lambda/D``
    and asymptote to the residual-speckle floor outside that.

    Examples
    --------
    >>> import lumenairy as la
    >>> # Build coronagraphed and reference PSFs (see
    >>> # Function-Reference-Coronagraphs for the pipeline)
    >>> psf_coro, dx = la.compute_psf(E_after_coro, wl, f, dx_pupil,
    ...                                  normalize='none')
    >>> psf_ref, _   = la.compute_psf(E_pupil_clean, wl, f, dx_pupil,
    ...                                  normalize='none')
    >>> curve = la.coronagraph_contrast_curve(
    ...     psf_coro, psf_ref, dx, wl, f)
    >>> import matplotlib.pyplot as plt
    >>> plt.loglog(curve['r_lam_over_D'], curve['contrast'])
    """
    psf_coro = np.asarray(psf_coro, dtype=float)
    psf_ref = np.asarray(psf_ref, dtype=float)
    if psf_coro.shape != psf_ref.shape:
        raise ValueError(
            f"coronagraph_contrast_curve: coro {psf_coro.shape} "
            f"and ref {psf_ref.shape} must have the same shape.")

    Ny, Nx = psf_ref.shape
    if center is None:
        idx = int(np.argmax(psf_ref))
        cy_pix = idx // Nx
        cx_pix = idx % Nx
    else:
        cx_pix, cy_pix = center

    peak_ref = float(psf_ref.max())
    if peak_ref <= 0:
        raise ValueError("psf_ref has no positive intensity.")

    # 4.9 fix (audit #2.3): compute the correct λ·f/D pixel scale
    # from the supplied physical parameters.  Pre-4.9 hard-coded
    # ``pix_per_lam_over_D = N`` which is right only for the natural
    # FFT pitch geometry (no zero-padding, no oversampling); for the
    # MFT-zoomed / oversampled focal grids typical in coronagraphy
    # this was off by a factor of (D · dx_focal)/(λ · f) -- often
    # several × and quietly mis-labelling the contrast-curve x-axis.
    if pupil_diameter_m is not None:
        D = float(pupil_diameter_m)
        pix_per_lam_over_D = float(wavelength) * float(f_eff) / (
            D * float(dx_focal))
    else:
        import warnings
        warnings.warn(
            "coronagraph_contrast_curve: pupil_diameter_m not supplied; "
            "falling back to the pre-4.9 ``pix_per_lam_over_D = N`` "
            "approximation, which is only correct for the natural FFT "
            "pitch (no zero-padding, no MFT zoom).  Pass "
            "pupil_diameter_m=... to get the correct λ·f/D scaling.",
            RuntimeWarning, stacklevel=2,
        )
        pix_per_lam_over_D = float(Nx)

    y_grid = np.arange(Ny) - cy_pix
    x_grid = np.arange(Nx) - cx_pix
    YY, XX = np.meshgrid(y_grid, x_grid, indexing='ij')
    r_pix = np.sqrt(XX ** 2 + YY ** 2)

    r_max_pix = max_lam_over_D * pix_per_lam_over_D
    r_max_pix = min(r_max_pix, min(Nx, Ny) / 2 - 1)

    edges = np.linspace(0.0, r_max_pix, n_radii + 1)
    centres_pix = 0.5 * (edges[:-1] + edges[1:])
    contrast = np.full(n_radii, np.nan, dtype=float)
    for i in range(n_radii):
        m = (r_pix >= edges[i]) & (r_pix < edges[i + 1])
        if not m.any():
            continue
        vals = psf_coro[m]
        if azimuthal == 'mean':
            agg = float(np.mean(vals))
        elif azimuthal == 'median':
            agg = float(np.median(vals))
        elif azimuthal == 'rms':
            agg = float(np.sqrt(np.mean(vals ** 2)))
        elif azimuthal == 'std':
            # 4.10: true 1-sigma metric -- variance about the mean,
            # not the raw moment.
            mu = float(np.mean(vals))
            agg = float(np.sqrt(np.mean((vals - mu) ** 2)))
        else:
            raise ValueError(
                f"azimuthal must be 'mean'/'median'/'rms'/'std'; got {azimuthal!r}")
        contrast[i] = agg / peak_ref

    return {
        'r_lam_over_D': centres_pix / pix_per_lam_over_D,
        'contrast': contrast,
        'r_pixels': centres_pix,
        'peak_ref': peak_ref,
        'center': (cx_pix, cy_pix),
    }


__all__ = ['coronagraph_contrast_curve']
