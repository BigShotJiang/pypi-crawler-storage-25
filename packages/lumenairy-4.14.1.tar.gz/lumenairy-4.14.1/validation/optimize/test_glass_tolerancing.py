"""Glass dispersion and tolerancing / Monte Carlo tests.

From:
- physics_extended_test.py (BK7 Sellmeier, achromat EFL variation,
  tolerance tilt, form error, Monte Carlo Strehl stats)
- deep_audit.py (tolerancing + biconic, Monte Carlo tolerancing)
"""
from __future__ import annotations

import sys

import numpy as np

import sys as _sys, pathlib as _pathlib
_sys.path.insert(0, str(_pathlib.Path(__file__).resolve().parent.parent))
from _harness import Harness

import lumenairy as la
from lumenairy.raytrace import (
    surfaces_from_prescription, system_abcd,
)


H = Harness('glass_tolerancing')


# ---------------------------------------------------------------------
H.section('Glass dispersion')


def t_bk7_dispersion():
    reference = {
        0.5876e-6: 1.51680,
        0.6563e-6: 1.51432,
        0.4861e-6: 1.52238,
        1.0140e-6: 1.50731,
    }
    max_err = 0.0
    for wl, n_ref in reference.items():
        n_calc = la.get_glass_index('N-BK7', wl)
        max_err = max(max_err, abs(n_calc - n_ref))
    return max_err < 0.002, f'max index error = {max_err:.5f}'


H.run('Glass: N-BK7 Sellmeier dispersion accuracy',
      t_bk7_dispersion)


def t_achromat_correction():
    pres = la.thorlabs_lens('AC254-100-C')
    wvs = np.linspace(1.0e-6, 1.6e-6, 7)
    efls, _, _ = la.chromatic_focal_shift(pres, wvs)
    efl_pv = efls.max() - efls.min()
    efl_mean = efls.mean()
    variation_pct = efl_pv / efl_mean * 100
    return variation_pct < 5, \
        f'EFL PV = {efl_pv*1e3:.3f}mm ({variation_pct:.2f}%)'


H.run('Achromat: EFL variation < 5% across 1.0-1.6 um',
      t_achromat_correction)


# ---------------------------------------------------------------------
H.section('Tolerancing: tilt / form error')


def t_tolerance_tilt_shifts_centroid():
    N = 256; dx = 8e-6; lam = 1.31e-6
    pres = la.make_singlet(50e-3, np.inf, 4e-3, 'N-BK7',
                           aperture=3e-3)
    E_in = np.ones((N, N), dtype=np.complex128)
    surfs = surfaces_from_prescription(pres)
    _, _, bfl, _ = system_abcd(surfs, lam)
    E_nom = la.apply_real_lens(E_in, prescription=pres, wavelength=lam, dx=dx)
    E_focus_nom = la.angular_spectrum_propagate(E_nom, bfl, lam, dx)
    cx_nom, _ = la.beam_centroid(E_focus_nom, dx)
    pres_pert = la.apply_perturbations(pres, [
        la.Perturbation(surface_index=0, tilt=(1e-3, 0), name='tilt')])
    E_pert = la.apply_real_lens(E_in, prescription=pres_pert, wavelength=lam, dx=dx)
    E_focus_pert = la.angular_spectrum_propagate(E_pert, bfl, lam, dx)
    cx_pert, _ = la.beam_centroid(E_focus_pert, dx)
    shift = abs(cx_pert - cx_nom)
    return shift > 1e-6, \
        f'centroid shift = {shift*1e6:.2f} um'


H.run('Tolerance: tilt shifts focal-plane centroid',
      t_tolerance_tilt_shifts_centroid)


def t_tolerance_form_error_degrades():
    N = 256; dx = 8e-6; lam = 1.31e-6
    pres = la.make_singlet(50e-3, np.inf, 4e-3, 'N-BK7',
                           aperture=3e-3)
    surfs = surfaces_from_prescription(pres)
    _, _, bfl, _ = system_abcd(surfs, lam)
    E_in = np.ones((N, N), dtype=np.complex128)
    E_nom = la.apply_real_lens(E_in, prescription=pres, wavelength=lam, dx=dx)
    ideal = la.diffraction_limited_peak(E_nom, lam, bfl, dx)
    E_focus_nom = la.angular_spectrum_propagate(E_nom, bfl, lam, dx)
    strehl_nom = float(np.abs(E_focus_nom).max()**2 / ideal)
    pres_pert = la.apply_perturbations(pres, [
        la.Perturbation(surface_index=0, form_error_rms=200e-9,
                        random_seed=42, name='form')],
        N=N, dx=dx)
    E_pert = la.apply_real_lens(E_in, prescription=pres_pert, wavelength=lam, dx=dx)
    E_focus_pert = la.angular_spectrum_propagate(E_pert, bfl, lam, dx)
    strehl_pert = float(np.abs(E_focus_pert).max()**2 / ideal)
    return strehl_pert < strehl_nom, \
        f'nominal={strehl_nom:.4f}, perturbed={strehl_pert:.4f}'


H.run('Tolerance: form error degrades Strehl',
      t_tolerance_form_error_degrades)


def t_tolerancing_with_biconic():
    pres = la.make_biconic(50e-3, 60e-3, -60e-3, -70e-3, 3e-3,
                           'N-BK7', aperture=3e-3)
    E = np.ones((128, 128), dtype=np.complex128)
    perts = [la.Perturbation(surface_index=0, tilt=(1e-4, 0),
                             name='p1')]
    results = la.tolerancing_sweep(
        pres, 1.31e-6, 128, 16e-6, E, perts,
        focal_length=50e-3, aperture=3e-3, verbose=False)
    return len(results) == 2, f'{len(results)} sweep points'


H.run('Tolerancing sweep with biconic lens',
      t_tolerancing_with_biconic)


# ---------------------------------------------------------------------
H.section('Monte Carlo tolerancing')


def t_monte_carlo_strehl_stats():
    pres = la.make_singlet(50e-3, np.inf, 4e-3, 'N-BK7',
                           aperture=3e-3)
    surfs = surfaces_from_prescription(pres)
    _, _, bfl, _ = system_abcd(surfs, 1.31e-6)
    E_in = np.ones((64, 64), dtype=np.complex128)
    stats = la.monte_carlo_tolerancing(
        pres, 1.31e-6, 64, 32e-6, E_in,
        perturbation_spec=[{'surface_index': 0, 'tilt_std': 5e-3}],
        focal_length=bfl, aperture=3e-3,
        n_trials=5, seed=0, verbose=False)
    mean = stats['strehl_peak_mean']
    std = stats['strehl_peak_std']
    return (0 < mean <= 1.5 and std > 0), \
        f'Strehl mean={mean:.4f}, std={std:.4f}'


H.run('Monte Carlo: Strehl stats are physically reasonable',
      t_monte_carlo_strehl_stats)


def t_monte_carlo_tolerancing_basic():
    pres = la.make_singlet(50e-3, float('inf'), 4e-3, 'N-BK7',
                           aperture=3e-3)
    E = np.ones((128, 128), dtype=np.complex128)
    stats = la.monte_carlo_tolerancing(
        pres, 1.31e-6, 128, 16e-6, E,
        perturbation_spec=[{'surface_index': 0,
                            'tilt_std': 1e-4,
                            'decenter_std': 1e-5}],
        focal_length=100e-3, aperture=3e-3,
        n_trials=3, seed=1, verbose=False)
    return 'strehl_peak_mean' in stats, \
        f'keys: {sorted(stats.keys())[:6]}'


H.run('monte_carlo_tolerancing returns expected stats',
      t_monte_carlo_tolerancing_basic)


def t_monte_carlo_seed_reproducibility():
    """Two runs with the same seed should produce identical Strehl
    arrays.  Catches any unseeded RNG / global-state leak.
    """
    pres = la.make_singlet(50e-3, np.inf, 4e-3, 'N-BK7',
                           aperture=3e-3)
    E = np.ones((64, 64), dtype=np.complex128)
    common = dict(prescription=pres, wavelength=1.31e-6, N=64, dx=32e-6,
                  E_source=E,
                  perturbation_spec=[{'surface_index': 0,
                                      'tilt_std': 1e-4}],
                  focal_length=100e-3, aperture=3e-3,
                  n_trials=8, verbose=False)
    a = la.monte_carlo_tolerancing(seed=42, **common)
    b = la.monte_carlo_tolerancing(seed=42, **common)
    arr_a = np.asarray(a['strehl_array'])
    arr_b = np.asarray(b['strehl_array'])
    return np.allclose(arr_a, arr_b), (
        f'max |a - b| = {float(np.max(np.abs(arr_a - arr_b))):.2e}')


def t_monte_carlo_std_grows_with_perturbation():
    """Larger tilt-std perturbations should produce larger Strehl-peak
    std (the yield distribution gets wider as tolerance loosens).
    """
    pres = la.make_singlet(50e-3, np.inf, 4e-3, 'N-BK7',
                           aperture=3e-3)
    E = np.ones((64, 64), dtype=np.complex128)
    common = dict(prescription=pres, wavelength=1.31e-6, N=64, dx=32e-6,
                  E_source=E,
                  focal_length=100e-3, aperture=3e-3,
                  n_trials=10, seed=7, verbose=False)
    tight = la.monte_carlo_tolerancing(
        perturbation_spec=[{'surface_index': 0, 'tilt_std': 5e-5}],
        **common)
    loose = la.monte_carlo_tolerancing(
        perturbation_spec=[{'surface_index': 0, 'tilt_std': 5e-3}],
        **common)
    return loose['strehl_peak_std'] > tight['strehl_peak_std'], (
        f'std tight={tight["strehl_peak_std"]:.4e}, '
        f'loose={loose["strehl_peak_std"]:.4e}')


H.run('Monte Carlo tolerancing seed gives reproducible results',
      t_monte_carlo_seed_reproducibility)
H.run('Monte Carlo tolerancing std grows with perturbation magnitude',
      t_monte_carlo_std_grows_with_perturbation)


if __name__ == '__main__':
    sys.exit(H.summary())
