# Releasing Confumo

Confumo releases are driven from the workstation, not from forge-hosted CI.

Versions come from git tags via `setuptools-scm`, but building and publishing are explicit local steps.

## Validation

Run the normal package check before cutting a tag:

```bash
scripts/ci/check
```

For a tagged release candidate, validate the exact versioned artifacts:

```bash
scripts/ci/release-check v0.1.1
```

## Build artifacts locally

Build release artifacts into `artifacts/release/<repo>/`:

```bash
scripts/release/build pypi v0.1.1
```

Build the TestPyPI variant if needed:

```bash
scripts/release/build testpypi v0.1.1
```

## Publish from the workstation

Upload to the default PyPI endpoint:

```bash
scripts/release/publish pypi v0.1.1
```

The canonical release build/publish entrypoints refuse to run unless:

- `HEAD` is exactly checked out at the requested tag
- the working tree is clean

That keeps the workstation-driven flow aligned with the old tag-triggered GitHub release contract.

Upload to TestPyPI:

```bash
scripts/release/publish testpypi v0.1.1
```

`TWINE_REPOSITORY_URL` may be set to override the upload endpoint for manual or staging flows.

## Suggested release order

1. Run `scripts/ci/check`.
2. Run `scripts/ci/release-check vX.Y.Z`.
3. Tag locally with `git tag -a vX.Y.Z -m "vX.Y.Z"`.
4. Run `scripts/release/build ...` and inspect the artifacts under `artifacts/release/`.
5. Run `scripts/release/publish ...` from the workstation when ready.
6. Push the tag after the local release artifacts are confirmed.

There is no GitHub Trusted Publishing requirement in the canonical flow anymore.
