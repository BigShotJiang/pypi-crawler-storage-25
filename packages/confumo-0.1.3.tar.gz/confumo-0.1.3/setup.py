"""Legacy shim.

Confumo is built via PEP 517 using pyproject.toml (setuptools.build_meta).
This file is kept only for users who still run `python setup.py ...`.
"""

from setuptools import setup


def main() -> None:
    setup()


if __name__ == "__main__":
    main()
