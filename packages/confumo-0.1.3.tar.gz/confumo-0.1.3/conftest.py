# Confumo — Python config framework
# Copyright (C) 2025 Aaron Colichia
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# See <https://www.gnu.org/licenses/> for details.

import pytest
import os
import tempfile

@pytest.fixture(scope="session")
def temp_dir():
    """
    Create a temporary directory for use in tests.
    
    The directory is automatically removed after the test session is done.
    """
    dirpath = tempfile.mkdtemp()
    yield dirpath
    os.rmdir(dirpath)

@pytest.fixture(scope="session")
def setup_environment():
    """
    Set up any environment variables or configurations needed for the tests.
    
    This fixture runs once per test session.
    """
    os.environ['APP_ENV'] = 'test'
    yield
    # Cleanup environment variables after test session
    del os.environ['APP_ENV']

