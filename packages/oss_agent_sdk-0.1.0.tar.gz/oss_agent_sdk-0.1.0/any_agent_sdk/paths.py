"""Filesystem layout for any-agent-sdk persistent state.

Mirrors Claude Code's ``~/.claude/`` directory 1:1 so a user's mental
model — and any tooling that introspects the on-disk state — carries over
unchanged. Anything Claude stores under ``.claude/X`` lives under
``.anyagent/X`` here.

Layout
------

    ~/.anyagent/
      settings.json              global settings (permission rules, hooks…)
      MEMORY.md                  top-level memory index (loaded every session)
      memory/                    individual memory entries
        {slug}.md                  one entry, frontmatter + markdown body
        {topic}/                   branched topic (promoted once 3+ entries)
          INDEX.md                   sub-index, same format as MEMORY.md
        sessions/                  per-session digests (auto-written; read-only)
          {date}-{id}.md
      sessions/                  full session transcripts
        {session_id}.jsonl         one JSON-encoded SDKMessage per line
      projects/                  per-cwd state
        {path_hash}/
          session-state.json       last-resumable session id, mode, etc.
      agents/                    user-defined agents
        {name}.md                  agent system prompt + tool list

Overrides
---------

* ``$ANYAGENT_HOME`` — base dir (default ``~/.anyagent``).
* ``$ANYAGENT_PROJECT_ROOT`` — explicit project root to derive ``projects/{hash}``
  from. Defaults to the current working directory.
"""

from __future__ import annotations

import hashlib
import os
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Final

__all__ = [
    "ensure_dir",
    "get_agents_dir",
    "get_anyagent_dir",
    "get_memory_dir",
    "get_memory_index",
    "get_project_dir",
    "get_session_path",
    "get_sessions_dir",
    "get_settings_path",
    "iter_sessions",
    "sanitize_session_id",
]


# ---------------------------------------------------------------------------
# Root resolution
# ---------------------------------------------------------------------------


_DEFAULT_DIRNAME: Final = ".anyagent"


def get_anyagent_dir() -> Path:
    """Return the resolved ``~/.anyagent`` directory.

    Honors ``$ANYAGENT_HOME`` for portable installs / containerized runs.
    The directory is *not* created here — call :func:`ensure_dir` on the
    specific subdir you need (lazy creation keeps test isolation clean).
    """

    override = os.environ.get("ANYAGENT_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return Path.home() / _DEFAULT_DIRNAME


# ---------------------------------------------------------------------------
# Subdirectories
# ---------------------------------------------------------------------------


def get_settings_path() -> Path:
    return get_anyagent_dir() / "settings.json"


def get_memory_index() -> Path:
    """The single ``MEMORY.md`` file at the root. Always loaded by the agent
    at session start (cheap; capped at ~150 lines by convention)."""
    return get_anyagent_dir() / "MEMORY.md"


def get_memory_dir() -> Path:
    return get_anyagent_dir() / "memory"


def get_sessions_dir() -> Path:
    return get_anyagent_dir() / "sessions"


def get_agents_dir() -> Path:
    return get_anyagent_dir() / "agents"


def get_project_dir(cwd: str | Path | None = None) -> Path:
    """Per-project state dir, keyed by a stable hash of the project root.

    Honors ``$ANYAGENT_PROJECT_ROOT`` then falls back to ``cwd`` then
    ``os.getcwd()``. We hash the absolute path so two projects with the
    same basename don't collide.
    """

    explicit = os.environ.get("ANYAGENT_PROJECT_ROOT")
    root = Path(explicit or cwd or os.getcwd()).expanduser().resolve()
    digest = hashlib.sha1(str(root).encode("utf-8")).hexdigest()[:12]
    return get_anyagent_dir() / "projects" / digest


# ---------------------------------------------------------------------------
# Session files
# ---------------------------------------------------------------------------


def get_session_path(session_id: str) -> Path:
    """Path of one session's JSONL transcript."""
    return get_sessions_dir() / f"{sanitize_session_id(session_id)}.jsonl"


_SAFE_ID = re.compile(r"[^A-Za-z0-9._-]")


def sanitize_session_id(session_id: str) -> str:
    """Strip filesystem-hostile characters from a user-supplied session id.

    Real session ids are UUIDs so this is a defense in depth: callers can
    pass `"my-session-2026-05-16"` and it will land at a predictable path.
    """

    return _SAFE_ID.sub("_", session_id) or "_"


def iter_sessions() -> Iterable[Path]:
    """Yield every persisted session JSONL file in chronological order
    (by mtime). Skips anything that doesn't end in ``.jsonl``."""

    d = get_sessions_dir()
    if not d.exists():
        return
    paths = sorted(d.glob("*.jsonl"), key=lambda p: p.stat().st_mtime)
    yield from paths


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def ensure_dir(path: Path) -> Path:
    """Create ``path`` (and parents) if missing. Returns ``path`` for chaining."""

    path.mkdir(parents=True, exist_ok=True)
    return path
