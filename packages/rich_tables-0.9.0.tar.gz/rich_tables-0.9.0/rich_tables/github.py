"""Functionality to display data from GitHub API."""

from __future__ import annotations

import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from functools import cached_property
from itertools import islice
from typing import (
    TYPE_CHECKING,
    Any,
    Literal,
    Protocol,
    Union,
    get_args,
    get_origin,
    get_type_hints,
)

from rich import box
from typing_extensions import Self, TypedDict

from .fields import FIELDS_MAP, get_val
from .generic import flexitable
from .types import GithubReaction, get_renderable
from .utils import (
    border_panel,
    console,
    fmt_time,
    format_with_color,
    format_with_color_on_black,
    human_dt,
    list_table,
    md_panel,
    new_table,
    predictably_random_color,
    simple_panel,
    sortgroup_by,
    syntax,
    timestamp2datetime,
    wrap,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping

    from rich.console import ConsoleRenderable, RenderableType
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.table import Table

    from .utils import JSONDict

SECONDS_PER_DAY = 86400


def b_green(text: str) -> str:
    """Make the text bold green."""
    return wrap(text, "b green")


def b_red(text: str) -> str:
    """Make the text bold red."""
    return wrap(text, "b red")


def diff_dt(timestamp: str | float, acc: int = 2) -> str:
    try:
        datetime = timestamp2datetime(timestamp)
    except ValueError:
        return str(timestamp)

    diff = datetime.timestamp() - time.time()
    fmted = " ".join(islice(fmt_time(int(diff)), acc))

    strtime = datetime.strftime("%F" if abs(diff) >= SECONDS_PER_DAY else "%T")

    return f"{(b_red if diff < 0 else b_green)(fmted)} {strtime}"


def fmt_add_del(added: int, deleted: int) -> list[str]:
    """Format added and deleted diff counts."""
    additions = f"+{added}" if added else ""
    deletions = f"-{deleted}" if deleted else ""
    return [b_green(additions.rjust(5)), b_red(deletions.rjust(3))]


def gh_md_panel(body: str, *args: Any, **kwargs: Any) -> Panel:
    return md_panel(
        body,
        # console.render_str(
        #     body.replace(":rofl:", ":rolling_on_the_floor_laughing:").replace(
        #         ":ballot_box_with_check:", "☑ "
        #     ),
        #     highlight=False,
        #     markup=False,
        # ).markup,
        *args,
        **kwargs,
    )


COLOR_BY_STATE = defaultdict(
    lambda: "default",
    {
        "True": "green",
        True: "green",
        "APPROVED": "green",
        "RESOLVED": "s green",
        "OPEN": "green",
        "MERGED": "magenta",
        "CLOSED": "b red",
        "PENDING": "yellow",
        "OUTDATED": "yellow",
        "COMMENTED": "yellow",
        "CHANGES_REQUESTED": "b red",
        "REVIEW_REQUIRED": "red",
        "DISMISSED": "gray42",
        "False": "red",
    },
)


def fmt_state(state: str) -> str:
    return wrap(state, f"b {COLOR_BY_STATE[state]}")


def diff_panel(title: str, rows: list[list[str]]) -> Panel:
    return border_panel(
        new_table(rows=rows),
        title=title,
        border_style=f"dim {predictably_random_color(title)}",
    )


PR_FIELDS_MAP: Mapping[str, Callable[..., RenderableType]] = {
    "statusCheckRollup": lambda x: {
        "SUCCESS": ":green_square:",
        "FAILURE": ":red_square:",
        "PENDING": ":yellow_square:",
        "None": "",
    }[x],
    "state": lambda x: wrap(fmt_state(x), "b"),
    "reviewDecision": lambda x: wrap(fmt_state(x), "b"),
    "dates": lambda x: new_table(
        rows=[
            [b_green(r" ⬤ "), human_dt(x[0])],
            [wrap(r" ◯ ", "b yellow"), human_dt(x[1])],
        ]
    ),
    "path": lambda x: wrap(x, "b"),
    "message": lambda x: wrap(x, "i"),
    "files": lambda files: diff_panel(
        "files",
        [
            [*fmt_add_del(f["additions"], f["deletions"]), get_val(f, "path")]
            for f in files
        ],
    ),
    "reviewRequests": format_with_color_on_black,
    "participants": lambda x: " ".join(map(format_with_color_on_black, x)),
}


class Diff(TypedDict):
    additions: int
    deletions: int


class File(Diff):
    path: str


def convert(type_: Any, value: Any) -> Any:
    """Pre-process field value if required."""
    type_origin = get_origin(type_)

    if type_origin is list:
        subtype, *_ = get_args(type_)
        return [convert(subtype, v) for v in value]

    if (
        isinstance(type_, type)
        and issubclass(type_, Entity)
        and not isinstance(value, Entity)
    ):
        return type_.make(value)

    return value


@dataclass
class Entity:
    @classmethod
    def make(cls, data: JSONDict) -> Self:
        """Select the fields defined on the class and create an Entity instance."""
        data = {f: convert(_type, data[f]) for f, _type in get_type_hints(cls).items()}
        return cls(**data)


@dataclass
class Commit(Entity):
    additions: int
    deletions: int
    committedDate: str
    message: str
    statusCheckRollup: str

    @property
    def diff(self) -> list[str]:
        return fmt_add_del(self.additions, self.deletions)

    @property
    def parts(self) -> list[str]:
        return [
            *self.diff,
            get_val(self, "statusCheckRollup"),
            get_val(self, "message"),
            get_val(self, "committedDate"),
        ]


class CreatedMixin(Protocol):
    @property
    def created(self) -> str:
        raise NotImplementedError


@dataclass
class PanelMixin(Entity):
    def get_title(self, fields: list[str]) -> str:
        return " ".join(get_val(self, f) for f in fields)

    @property
    def panel(self) -> Panel:
        raise NotImplementedError


@dataclass
class CreatedPanelMixin(CreatedMixin, PanelMixin):
    pass


@dataclass
class Content(CreatedPanelMixin):
    createdAt: str
    author: str
    body: str

    @property
    def created_at(self) -> str:
        return self.createdAt

    @property
    def created(self) -> str:
        return self.created_at


@dataclass
class Comment(Content):
    reactions: list[GithubReaction]

    def get_state(self) -> str:
        return "COMMENTED"

    def get_body(self) -> str:
        return self.body

    @property
    def panel(self) -> ConsoleRenderable:
        return get_renderable(
            "GithubComment",
            author=self.author,
            created_at=self.created_at,
            reactions=self.reactions,
            state=self.get_state(),
            body=self.get_body(),
        )


@dataclass
class DiffHunk(Entity):
    diffHunk: str = field(repr=False)
    line: int  # line number in the file
    position: Union[int, None]  # position in the diff hunk, if applicable
    startLine: int  # line number in the file
    # as above but before the diff hunk was changed
    originalLine: int
    originalPosition: int
    originalStartLine: Union[int, None]

    @cached_property
    def focus_start(self) -> int:
        return self.originalStartLine or self.originalLine or 0

    @cached_property
    def lines(self) -> list[str]:
        return self.diffHunk.splitlines()

    @cached_property
    def before(self) -> str:
        return "\n".join(
            re.sub(r"^[+-]", "", ln) for ln in self.lines[self.focus_start :]
        )

    @cached_property
    def panel(self) -> Syntax:
        line_count = len(self.lines)
        return syntax(
            self.diffHunk,
            "diff",
            line_numbers=True,
            start_line=0,
            highlight_lines=set(range(self.focus_start, line_count + 1)),
            line_range=(max(line_count - 5, 0), None),
            padding=1,
            theme="paraiso-dark",
        )


@dataclass
class ReviewComment(Comment):
    outdated: bool
    path: str
    pullRequestReview: str
    before: str

    def get_body(self) -> str:
        return re.sub(
            r"(?<=```)suggestion(.*?)(?=\n```)",
            lambda m: (
                "diff\n-" + self.before.replace("\n", "\n-") + m[1].replace("\n", "\n+")
            ),
            self.body,
            flags=re.DOTALL,
        )

    @property
    def review_id(self) -> str:
        return self.pullRequestReview


class ResolvedMixin:
    @property
    def resolved(self) -> bool:
        raise NotImplementedError

    @property
    def border_color(self) -> str:
        return "green" if self.resolved else "yellow"


@dataclass
class ReviewThread(CreatedPanelMixin, ResolvedMixin):
    path: str
    isResolved: bool
    isOutdated: bool
    resolvedBy: str
    diffHunk: DiffHunk
    comments: list[ReviewComment]
    verbose: bool

    @property
    def resolved(self) -> bool:
        return self.isResolved

    @classmethod
    def make(cls, kwargs: JSONDict) -> ReviewThread:
        diff_hunk = DiffHunk.make(kwargs["comments"][0])
        kwargs["diffHunk"] = diff_hunk
        for comment in kwargs["comments"]:
            comment["before"] = diff_hunk.before

        return super().make(kwargs)

    @property
    def review_id(self) -> str:
        return self.comments[0].review_id

    @property
    def created(self) -> str:
        return self.comments[0].created_at

    @property
    def formatted_state(self) -> str:
        return (
            (
                fmt_state("RESOLVED")
                + wrap(" by ", "white")
                + format_with_color(self.resolvedBy)
            )
            if self.isResolved
            else fmt_state("PENDING")
        )

    @property
    def title(self) -> str:
        return " ".join(
            [
                wrap(self.path, "b magenta"),
                self.formatted_state,
                fmt_state("OUTDATED") if self.isOutdated else "",
            ]
        )

    @property
    def panel(self) -> Panel:
        comments = self.comments
        content: RenderableType
        if self.verbose or not self.resolved:
            comments_col = list_table((c.panel for c in comments), padding=(1, 0, 0, 0))
            content = new_table(
                rows=[[self.diffHunk.panel, simple_panel(comments_col)]],
                highlight=False,
            )
        else:
            content = ""
        return border_panel(
            content,
            highlight=False,
            border_style=self.border_color,
            title=self.title,
        )


@dataclass
class Review(Comment, ResolvedMixin):
    id: str
    state: str
    threads: list[ReviewThread]
    comments: list[ReviewComment]

    verbose: bool

    def get_state(self) -> str:
        return self.state

    @property
    def resolved(self) -> bool:
        return all(t.resolved for t in self.threads)

    @property
    def panel(self) -> Panel:
        rows = []
        if self.body:
            rows.append(super().panel)

        if not self.resolved or self.verbose:
            self.threads.sort(key=lambda t: t.resolved)
            rows.extend(t.panel for t in self.threads)

        return border_panel(
            list_table(rows),
            subtitle=self.state,
            border_style=self.border_color,
            title=self.title,
            box=box.HEAVY,
        )

    @property
    def status(self) -> str:
        resolved_count = sum(t.isResolved for t in self.threads)
        if total_count := len(self.threads):
            return (
                wrap("RESOLVED", COLOR_BY_STATE["RESOLVED"])
                if total_count == resolved_count
                else b_green(" ⬤ " * resolved_count)
                + b_red(" ◯ " * (total_count - resolved_count))
            )
        return ""

    @property
    def title(self) -> str:
        return self.get_title(["state", "status"])


@dataclass
class Issue(Entity):
    number: int
    title: str
    state: Literal["OPEN", "CLOSED"]
    url: str

    @property
    def status(self) -> str:
        return {"OPEN": "[b green][/]", "CLOSED": "[b magenta][/]"}[self.state]

    @property
    def fmt(self) -> str:
        return f"{self.title} {self.url}"


@dataclass
class PullRequest(Entity):
    id: str
    number: int
    createdAt: str
    author: str
    body: str
    additions: int
    commits: list[Commit]
    deletions: int
    files: list[File]
    headRefName: str
    labels: list[str]
    participants: list[str]
    repository: str
    reviewDecision: str
    reviewRequests: list[str]
    reviews: list[Review]
    comments: list[Comment]
    state: str
    title: str
    updatedAt: str
    url: str
    issues: list[Issue]

    verbose: bool

    @property
    def dates(self) -> tuple[str, str]:
        return self.createdAt, self.updatedAt


@dataclass
class PullRequestTable(PullRequest):
    @classmethod
    def make(cls, kwargs: JSONDict) -> PullRequestTable:
        threads = [
            ReviewThread.make({**rt, "verbose": kwargs["verbose"]})
            for rt in kwargs["reviewThreads"]
        ]
        comments_by_review_id = dict(
            sortgroup_by(
                (c for t in threads for c in t.comments), lambda c: c.review_id
            )
        )
        threads_by_review_id = dict(sortgroup_by(threads, lambda t: t.review_id))

        kwargs.update(
            reviews=[
                {
                    **r,
                    "verbose": kwargs["verbose"],
                    "threads": threads_by_review_id.pop(r["id"], []),
                    "comments": comments_by_review_id.pop(r["id"], []),
                }
                for r in kwargs["reviews"]
                if (r["id"] in threads_by_review_id or r["body"])
            ],
            issues=kwargs.pop("closingIssuesReferences", []),
        )
        return super().make(kwargs)

    @property
    def name(self) -> str:
        return wrap(f"{wrap(f'#{self.number}', 'dim')} {self.title}", "b white")

    @property
    def repo(self) -> str:
        return wrap(self.repository, f"b {predictably_random_color(self.repository)}")

    @property
    def pr_state(self) -> str:
        return "MERGED" if self.state == "MERGED" else self.reviewDecision

    @property
    def fixed_issues(self) -> RenderableType:
        return list_table([i.fmt for i in self.issues])

    @property
    def info(self) -> Panel:
        fields = (
            "author",
            "dates",
            "headRefName",
            "participants",
            "reviewRequests",
            "fixed_issues",
        )
        pairs = {f: v for f in fields if (v := getattr(self, f))}
        field_rows = flexitable(pairs)
        return border_panel(
            new_table(
                rows=[[field_rows], [gh_md_panel(self.body)], [self.files_commits]]
            ),
            title=f"{self.name} @ {self.repo}",
            box=box.DOUBLE_EDGE,
            border_style=COLOR_BY_STATE[self.pr_state],
            subtitle=(
                wrap(
                    " ".join(
                        [
                            fmt_state(self.reviewDecision),
                            wrap("//", "white"),
                            fmt_state(self.state),
                        ]
                    ),
                    "b",
                )
            ),
            vertical_align="middle",
            title_align="center",
            subtitle_align="center",
        )

    @property
    def files_commits(self) -> Table:
        return new_table(
            rows=[
                [
                    get_val(self, "files"),
                    diff_panel("commits", [commit.parts for commit in self.commits]),
                ]
            ]
        )

    @property
    def timestamped_contents(self) -> list[CreatedPanelMixin]:
        return [*self.reviews, *self.comments]

    @property
    def panels(self) -> Iterable[Panel]:
        for content in sorted(self.timestamped_contents, key=lambda c: c.created):
            yield content.panel


def pulls_table(
    data: list[Mapping[str, Any]], **kwargs: Any
) -> Iterable[str | ConsoleRenderable]:
    FIELDS_MAP.update(PR_FIELDS_MAP)

    pr = {**data[0], "verbose": kwargs.get("verbose", False)}
    pr_table = PullRequestTable.make(pr)
    yield pr_table.info
    yield from pr_table.panels
