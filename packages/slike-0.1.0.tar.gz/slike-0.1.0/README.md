# slike

Python SDK and CLI for the [Slike](https://sli.ke) platform.

Supports **chunked file upload** (4 MiB chunks), **editor-video registration**, **publish-by-URL** (Google Drive, YouTube, direct links), and two auth flows: **direct Slike token** or **Denmark JWT** (exchanged at `/login`).

Requires Python 3.7+.

---

## Install

```bash
pip3 install slike
```

---

## Python SDK

The SDK is a client class. Construct with credentials, call `initialize()` once to validate them, then call methods.

### Quick start (direct Slike token)

```python
from slike import SlikeMedia

client = SlikeMedia(token="your-slike-token", environment="prod")
client.initialize()   # validates the token via user.me; raises SlikeAPIError on failure

# Upload a local file
result = client.register_media(
    file_path="/path/to/video.mp4",
    title="My Video",
    description="Description",
    on_progress=lambda done, total: print(f"{done}/{total} chunks"),
)
print(result["id"])
```

### Quick start (Denmark JWT)

```python
from slike import SlikeMedia

client = SlikeMedia(
    denmark_token="<jwt>",       # exchanged for a Slike session token at /login
    service="slike",             # optional, default: "slike"
    environment="prod",
)
client.initialize()              # exchanges the JWT; raises SlikeAPIError on failure

print(client.token)              # the resolved Slike session token
```

You must provide exactly one of `token` or `denmark_token`.

### Methods

#### `register_media`

Register media on Slike. Provide exactly one of `file_path` (chunked file upload) or `editor_settings` (editor-generated video — no bytes uploaded; the asset server renders from the spec).

```python
# File mode
client.register_media(
    file_path="/path/to/video.mp4",
    title="My Video",
    description="Description",
    asset_type="video",                          # optional, default: "video"
    tags=["news", "sports"],                     # optional
    preset_config={"meta": "", "social": ""},   # optional
    on_progress=lambda done, total: print(f"{done}/{total} chunks"),
)

# Editor mode
client.register_media(
    title="My Editor Video",
    description="Description",
    editor_settings={
        "clips": [...],
        "background_music": {...},
        "source_width": 1080,
        "source_height": 1920,
    },
)
```

#### `publish_media`

Publish media by URL (Google Drive, YouTube, direct link).

```python
client.publish_media(
    url="https://drive.google.com/file/d/FILE_ID/view",
    title="My Video",
    description="Description",
    type="gdrive",              # gdrive | youtube | url
    asset_type="video",         # optional
    tags=["news", "sports"],    # optional
    auto_publish=True,          # optional, default: True
)
```

### Error handling

```python
from slike import SlikeMedia, SlikeAPIError

try:
    client = SlikeMedia(token="...", environment="prod")
    client.initialize()
    result = client.register_media(file_path="video.mp4", title="T", description="D")
except ValueError as e:
    print(f"Bad input: {e}")
except SlikeAPIError as e:
    print(f"API / auth error: {e}")
```

---

## Configuration (CLI only)

The CLI accepts the token + environment inline, falls back to env vars and a config file. The Python SDK takes them as constructor arguments — no file reads.

### Priority (highest wins)

1. CLI flags (`--token`, `--denmark-token`, `--env`, `--config`)
2. Environment variables (`SLIKE_TOKEN`, `SLIKE_ENVIRONMENT`, `SLIKE_CONFIG`)
3. `./config.toml` (current directory), then `~/.slike/config.toml`

### Config file format

```toml
token       = "your-token-here"
environment = "prod"              # "dev" or "prod"
```

### Environment variables

| Variable            | Description                             |
|---------------------|-----------------------------------------|
| `SLIKE_TOKEN`       | Slike auth token                        |
| `SLIKE_ENVIRONMENT` | `dev` or `prod`                         |
| `SLIKE_CONFIG`      | Path to a specific config file          |

---

## CLI

```bash
# Upload a local file
slike-upload video.mp4 --title "My Video" --desc "Description"

# Publish by URL (Google Drive)
slike-upload --url https://drive.google.com/file/d/FILE_ID/view \
             --type gdrive --title "My Video" --desc "Description"

# Use a Denmark JWT instead of a Slike token
slike-upload video.mp4 --title "T" --desc "D" --denmark-token <jwt>
```

### Publish by URL

```
slike-upload --url <URL> --type <gdrive|youtube|url>
             --title "Title" --desc "Description"
             [--asset-type video|shorts]
             [--tags tag1,tag2]
             [--no-publish]
             [--token <token> | --denmark-token <jwt> [--service <name>]]
             [--env dev|prod] [--config <path>]
```

| Flag              | Required | Description                                              |
|-------------------|----------|----------------------------------------------------------|
| `--url`           | yes      | Media URL to ingest                                      |
| `--type`          | no       | `gdrive`, `youtube`, or `url` (default: `url`)           |
| `--title`         | yes      | Media title                                              |
| `--desc`          | yes      | Media description                                        |
| `--asset-type`    | no       | Asset type, e.g. `video`, `shorts` (default: `video`)   |
| `--tags`          | no       | Comma-separated tags                                     |
| `--no-publish`    | no       | Save as draft, skip auto-publish                         |
| `--token`         | no       | Slike auth token                                         |
| `--denmark-token` | no       | Denmark JWT (exchanged for a Slike session token)        |
| `--service`       | no       | Service name for Denmark auth (default: `slike`)         |
| `--env`           | no       | `dev` or `prod` (overrides config)                       |
| `--config`        | no       | Path to config file                                      |

### Upload a local file

```
slike-upload <file>
             --title "Title" --desc "Description"
             [--asset-type video|shorts]
             [--tags tag1,tag2]
             [--payload '<JSON>']
             [--token <token> | --denmark-token <jwt>]
             [--env dev|prod] [--config <path>]
```

#### Using `--payload` JSON

Pass all metadata as a single JSON string instead of individual flags. CLI flags take precedence when both are given.

| Field           | Type         | Default       | Notes                              |
|-----------------|--------------|---------------|------------------------------------|
| `title`         | string       | required      |                                    |
| `desc`          | string       | required      |                                    |
| `asset_type`    | string       | `"video"`     | e.g. `"video"`, `"shorts"`         |
| `tags`          | list[string] | `null`        | e.g. `["news", "sports"]`          |
| `preset_config` | object       | `null`        | `{"meta": "...", "social": "..."}` |
| `downloads`     | object       | `null`        | `{"url": "https://..."}`           |
| `islive`        | int          | `0`           | `0` or `1`                         |
| `type`          | int          | `0`           | Media type integer                 |
| `source`        | string       | `"uploadsdk"` | Upload source identifier           |

---

## Environments

| Environment | RPC endpoint                 | Upload endpoint                   | Auth endpoint                       |
|-------------|------------------------------|-----------------------------------|-------------------------------------|
| `prod`      | `https://b2b.sli.ke/rpc`     | `https://asset.sli.ke/upload`     | `https://accounts.sli.ke/login`     |
| `dev`       | `https://app-dev.sli.ke/rpc` | `https://asset-dev.sli.ke/upload` | `https://accounts-dev.sli.ke/login` |

---

## How it works

**Auth (`initialize()`)**:
- With `token`: calls `user.me` RPC to verify the token is valid.
- With `denmark_token`: POSTs `{type: 4, jwt: <jwt>, service}` to `/login` and reads `data.token` from the response.

**Chunked file upload (`register_media(file_path=...)`)**:
1. `media.register` RPC → returns `media_id` + short-lived upload JWT
2. File is split into **4 MiB chunks**, each POSTed as `multipart/form-data` with the JWT in the `token` header
3. The asset server assembles and processes the file. Failed chunks retry up to **3 times** with exponential backoff.

**Editor video (`register_media(editor_settings=...)`)**:
- `media.register` RPC with `type: "videoeditor"` and the editor spec. No bytes are uploaded — the asset server renders from the spec.

---

## Development

```bash
git clone <repo>
cd slike-media-package
python3 -m pip install -e .

# Run tests
python3 -m unittest test_slike -v

# Build wheel
pip install hatch && hatch build
```

---

## License

MIT
