"""
Slike Media SDK
A Python client for the Slike platform — supports direct Slike tokens or
Denmark JWT tokens (exchanged at /login for a Slike session token).

Usage:
    from slike import SlikeMedia

    client = SlikeMedia(token="...", environment="prod")
    client.initialize()                       # validates token (raises on failure)

    client.publish_media(url="...", title="T", description="D", type="gdrive")
    client.register_media(file_path="x.mp4", title="T", description="D")
    client.register_media(editor_settings={...}, title="T", description="D")
"""

__version__ = "0.1.0"
__all__ = [
    "SlikeMedia",
    "SlikeAPIError",
    "SlikeConfig",
    "load_config",
    "PRODUCTION_URL",
    "DEVELOPMENT_URL",
    "PRODUCTION_UPLOAD_URL",
    "DEVELOPMENT_UPLOAD_URL",
    "PRODUCTION_AUTH_URL",
    "DEVELOPMENT_AUTH_URL",
    "DENMARK_LOGIN_TYPE",
    "DEFAULT_AUTH_SERVICE",
]

import json
import logging
import os
import sys
import argparse
import uuid
import requests
from typing import Dict, Optional, Any, List
from dataclasses import dataclass

try:
    import tomllib          # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PRODUCTION_URL = "https://b2b.sli.ke/rpc"
DEVELOPMENT_URL = "https://app-dev.sli.ke/rpc"

PRODUCTION_UPLOAD_URL = "https://asset.sli.ke/upload"
DEVELOPMENT_UPLOAD_URL = "https://asset-dev.sli.ke/upload"

PRODUCTION_AUTH_URL = "https://accounts.sli.ke/login"
DEVELOPMENT_AUTH_URL = "https://accounts-dev.sli.ke/login"

# Chunk size: 4 MiB — mirrors Resumable.js default
CHUNK_SIZE = 4 * 1024 * 1024

# Denmark auth (mirrors the JS SDK)
DENMARK_LOGIN_TYPE = 4
DEFAULT_AUTH_SERVICE = "slike"


_session = requests.Session()


class SlikeAPIError(Exception):
    """Custom exception for Slike API errors."""
    pass


# ---------------------------------------------------------------------------
# Config (used by the CLI)
# ---------------------------------------------------------------------------

@dataclass
class SlikeConfig:
    token: str = ""
    environment: str = "prod"
    file: str = ""
    title: str = ""
    desc: str = ""
    asset_type: str = ""


def load_config(config_path: Optional[str] = None) -> SlikeConfig:
    """
    Load config from (in priority order):
      1. Explicit path argument
      2. SLIKE_CONFIG env var
      3. ./config.toml (cwd) or ~/.slike/config.toml

    Environment variable overrides (always win over file):
        SLIKE_TOKEN, SLIKE_ENVIRONMENT
    """
    cfg = SlikeConfig()

    path = (
        config_path
        or os.environ.get("SLIKE_CONFIG")
        or (os.path.join(os.getcwd(), "config.toml") if os.path.isfile(os.path.join(os.getcwd(), "config.toml")) else None)
        or os.path.expanduser("~/.slike/config.toml")
    )

    if os.path.isfile(path):
        logger.debug("Loaded config from %s", path)
        if tomllib is not None:
            with open(path, "rb") as f:
                data = tomllib.load(f)
        else:
            data = {}
            with open(path) as f:
                for raw in f:
                    line = raw.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    data[key.strip().lower()] = value.strip().strip('"').strip("'")
        cfg.token       = data.get("token", "")
        cfg.environment = data.get("environment", "prod")
        cfg.file        = data.get("file", "")
        cfg.title       = data.get("title", "")
        cfg.desc        = data.get("desc", "")
        cfg.asset_type  = data.get("asset_type", "")

    if os.environ.get("SLIKE_TOKEN"):
        cfg.token = os.environ["SLIKE_TOKEN"]
    if os.environ.get("SLIKE_ENVIRONMENT"):
        cfg.environment = os.environ["SLIKE_ENVIRONMENT"]

    return cfg


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _normalize_env(environment: Optional[str]) -> str:
    if not environment:
        return "prod"
    env = environment.lower()
    if env in ("dev", "prod"):
        return env
    raise ValueError(f"Invalid environment: '{environment}'. Must be 'dev' or 'prod'")


def _get_api_url(environment: str) -> str:
    return DEVELOPMENT_URL if environment == "dev" else PRODUCTION_URL


def _get_auth_url(environment: str) -> str:
    return DEVELOPMENT_AUTH_URL if environment == "dev" else PRODUCTION_AUTH_URL


def _build_headers() -> Dict[str, str]:
    return {"Content-Type": "application/json"}


def _build_cookies(token: str, environment: str) -> Dict[str, str]:
    """Auth cookie name differs between envs (server reads token from cookie)."""
    return {"token-dev": token} if environment == "dev" else {"token": token}


def _make_request(api_url: str, payload: Dict[str, Any], headers: Dict[str, str],
                  cookies: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    try:
        logger.debug("POST %s method=%s", api_url, payload.get("method"))
        response = _session.post(api_url, json=payload, headers=headers,
                                 cookies=cookies or {}, verify=True, timeout=30)
        result = _parse_response(response)
        _check_for_errors(response, result)
        return result
    except SlikeAPIError:
        raise
    except requests.exceptions.RequestException as e:
        raise SlikeAPIError(f"Request to Slike failed: {str(e)}")


def _parse_response(response: requests.Response) -> Dict[str, Any]:
    try:
        return response.json()
    except ValueError:
        raise SlikeAPIError(f"Invalid JSON response: {response.text}")


def _check_for_errors(response: requests.Response, result: Dict[str, Any]) -> None:
    if response.status_code >= 400:
        msg = _extract_error_message(result.get("error") if isinstance(result, dict) else None,
                                     response.text)
        raise SlikeAPIError(f"HTTP {response.status_code}: {msg}")

    if isinstance(result, dict) and "error" in result:
        error_obj = result.get("error")
        if not error_obj:
            return
        if isinstance(error_obj, dict):
            error_msg = error_obj.get("message", "Unknown JSON-RPC error")
            error_code = error_obj.get("code", "N/A")
            error_data = error_obj.get("data", "")
            full_error = f"{error_msg} (code: {error_code})"
            if error_data:
                full_error += f" - {error_data}"
        else:
            full_error = str(error_obj)
        raise SlikeAPIError(f"JSON-RPC error: {full_error}")


def _extract_error_message(error_obj: Any, default: str) -> str:
    if isinstance(error_obj, dict):
        return error_obj.get("message", default)
    return str(error_obj) if error_obj else default


def _validate_required_params(url: str, title: str, description: str, token: str) -> None:
    if not url or not isinstance(url, str):
        raise ValueError("url parameter is required and must be a non-empty string")
    if not title or not isinstance(title, str):
        raise ValueError("title parameter is required and must be a non-empty string")
    if not description or not isinstance(description, str):
        raise ValueError("description parameter is required and must be a non-empty string")
    if not token:
        raise ValueError("token is required")


def _build_publish_payload(
    url: str, title: str, description: str, type: str,
    tags: Optional[List[str]], preset_meta: Optional[str],
    asset_type: Optional[str], auto_publish: bool,
) -> Dict[str, Any]:
    params: Dict[str, Any] = {
        "title": title, "desc": description, "url": url,
        "type": type, "auto_publish": auto_publish,
    }
    if tags:
        if not isinstance(tags, list):
            raise ValueError("tags parameter must be a list of strings")
        params["tags"] = tags
    if preset_meta:
        params["preset_meta"] = preset_meta
    if asset_type:
        params["asset_type"] = asset_type
    return {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().int & 0x7FFFFFFF,
        "method": "media.publish",
        "params": params,
    }


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

def _validate_slike_token(environment: str, token: str) -> None:
    """Call user.me to verify the token is valid. Raises SlikeAPIError on failure."""
    payload = {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().int & 0x7FFFFFFF,
        "method": "user.me",
        "params": {},
    }
    _make_request(
        _get_api_url(environment),
        payload,
        _build_headers(),
        _build_cookies(token, environment),
    )


def _authenticate_with_denmark(environment: str, denmark_token: str, service: str) -> str:
    """Exchange a Denmark JWT for a Slike session token via the /login endpoint."""
    auth_url = _get_auth_url(environment)
    body = {
        "type": DENMARK_LOGIN_TYPE,
        "jwt": denmark_token,
        "service": service,
    }
    try:
        response = _session.post(auth_url, json=body, headers=_build_headers(), timeout=30)
    except requests.exceptions.RequestException as e:
        raise SlikeAPIError(f"Auth network error: {str(e)}")

    try:
        data = response.json()
    except ValueError:
        raise SlikeAPIError(f"Auth returned non-JSON response: {response.text}")

    if not response.ok:
        msg = (
            (data.get("message") if isinstance(data, dict) else None)
            or (data.get("msg") if isinstance(data, dict) else None)
            or response.reason
            or "unknown"
        )
        raise SlikeAPIError(f"Auth failed: HTTP {response.status_code}: {msg}")

    payload = data.get("data") if isinstance(data, dict) else None
    token = payload.get("token") if isinstance(payload, dict) else None
    if not isinstance(token, str) or not token:
        raise SlikeAPIError("Auth failed: response missing 'data.token'")
    return token


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class SlikeMedia:
    """
    Slike Media SDK client.

    Initialize with either a direct Slike `token` or a `denmark_token` (JWT,
    which gets exchanged at /login for a Slike session token), plus the
    `environment`. Call `initialize()` once before invoking any method —
    it validates the token (or performs the Denmark exchange) and raises
    `SlikeAPIError` on failure.
    """

    VERSION = __version__

    def __init__(
        self,
        *,
        token: Optional[str] = None,
        denmark_token: Optional[str] = None,
        service: Optional[str] = None,
        environment: Optional[str] = None,
    ):
        if not token and not denmark_token:
            raise TypeError("SlikeMedia: token or denmark_token is required")
        self.environment = _normalize_env(environment)
        self._input_token = (token or "").strip() or None
        self._denmark_token = (denmark_token or "").strip() or None
        if token and not self._input_token:
            raise TypeError("SlikeMedia: token cannot be empty")
        if denmark_token and not self._denmark_token:
            raise TypeError("SlikeMedia: denmark_token cannot be empty")
        self._service = service or DEFAULT_AUTH_SERVICE
        self._token: Optional[str] = None
        self._initialized = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def initialize(self) -> None:
        """Validate the token (or exchange the Denmark JWT). Raises on failure."""
        if self._initialized:
            return
        if self._input_token:
            _validate_slike_token(self.environment, self._input_token)
            self._token = self._input_token
        else:
            assert self._denmark_token
            self._token = _authenticate_with_denmark(
                self.environment, self._denmark_token, self._service
            )
        self._initialized = True

    @property
    def initialized(self) -> bool:
        return self._initialized

    @property
    def token(self) -> Optional[str]:
        """The active Slike session token (None until `initialize()` succeeds)."""
        return self._token

    def _require_token(self) -> str:
        if not self._initialized or not self._token:
            raise SlikeAPIError(
                "SlikeMedia is not initialized. Call initialize() before using SDK methods."
            )
        return self._token

    # ------------------------------------------------------------------
    # Methods
    # ------------------------------------------------------------------

    def publish_media(
        self,
        *,
        url: str,
        title: str,
        description: str,
        type: str = "url",
        asset_type: Optional[str] = None,
        tags: Optional[List[str]] = None,
        preset_meta: Optional[str] = None,
        auto_publish: bool = True,
    ) -> Dict[str, Any]:
        """Publish media by URL (Google Drive, YouTube, direct link)."""
        token = self._require_token()
        _validate_required_params(url, title, description, token)
        payload = _build_publish_payload(
            url, title, description, type, tags, preset_meta, asset_type, auto_publish,
        )
        return _make_request(
            _get_api_url(self.environment),
            payload,
            _build_headers(),
            _build_cookies(token, self.environment),
        )

    def register_media(
        self,
        *,
        title: str,
        description: str,
        file_path: Optional[str] = None,
        editor_settings: Optional[Dict[str, Any]] = None,
        asset_type: str = "video",
        tags: Optional[List[str]] = None,
        preset_config: Optional[Dict] = None,
        downloads: Optional[Dict] = None,
        islive: int = 0,
        media_type: Any = None,
        source: Optional[str] = None,
        fid: Optional[str] = None,
        on_progress: Optional[Any] = None,
    ) -> Dict[str, Any]:
        """
        Register media on Slike. Provide exactly one of:
          - `file_path`       → register + chunked upload of a local file
          - `editor_settings` → register an editor-generated video (no bytes)
        """
        token = self._require_token()
        from slikeupload import _do_register_media
        return _do_register_media(
            token=token,
            environment=self.environment,
            title=title,
            description=description,
            file_path=file_path,
            editor_settings=editor_settings,
            asset_type=asset_type,
            tags=tags,
            preset_config=preset_config,
            downloads=downloads,
            islive=islive,
            media_type=media_type,
            source=source,
            fid=fid,
            on_progress=on_progress,
        )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli_progress(done: int, total: int) -> None:
    pct = int(done / total * 100)
    bar = "#" * (pct // 2)
    print(f"\r  [{bar:<50}] {done}/{total} chunks ({pct}%)", end="", flush=True)
    if done == total:
        print()


def main() -> None:
    """slike-upload — CLI for uploading media to Slike."""
    parser = argparse.ArgumentParser(
        prog="slike-upload",
        description="Upload a media file to the Slike platform.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Upload using config file
  slike-upload video.mp4 --title "My Video" --desc "A description"

  # Override environment on the fly
  slike-upload video.mp4 --title "Test" --desc "Test" --env dev

  # Pass token directly (skips config file)
  slike-upload video.mp4 --title "My Video" --desc "Desc" --token abc123

  # Use a Denmark JWT instead of a Slike token
  slike-upload video.mp4 --title "T" --desc "D" --denmark-token <jwt>

  # Publish by URL (no file upload)
  slike-upload --url https://drive.google.com/file/d/... --type gdrive \\
               --title "My Video" --desc "Desc"
        """,
    )

    parser.add_argument("file", nargs="?", help="Local file path to upload")
    parser.add_argument("--url", help="Remote media URL (for publish-by-URL mode)")
    parser.add_argument("--type", default="url", dest="media_type",
                        help="Media type for URL mode: gdrive, youtube, url (default: url)")

    parser.add_argument("--title", default=None, help="Media title")
    parser.add_argument("--desc", default=None, help="Media description")
    parser.add_argument("--asset-type", default=None, help="Asset type, e.g. video, shorts")
    parser.add_argument("--tags", default=None, help="Comma-separated tags")
    parser.add_argument("--no-publish", action="store_true",
                        help="Do not auto-publish after URL publish")
    parser.add_argument("--payload", default=None,
                        help='JSON metadata for file upload '
                             '(title, desc, asset_type, tags, preset_config, '
                             'downloads, islive, type, source). '
                             'CLI flags take precedence over payload values.')

    parser.add_argument("--token", default=None, help="Slike auth token (overrides config)")
    parser.add_argument("--denmark-token", default=None, dest="denmark_token",
                        help="Denmark JWT (exchanged for a Slike session token)")
    parser.add_argument("--service", default=None,
                        help=f"Service name for Denmark auth (default: {DEFAULT_AUTH_SERVICE})")
    parser.add_argument("--env", default=None, dest="environment",
                        help="Environment: dev or prod (overrides config)")
    parser.add_argument("--config", default=None, help="Path to config file")

    args = parser.parse_args()

    cfg = load_config(args.config)
    token = args.token or (cfg.token if not args.denmark_token else None)
    env = args.environment or cfg.environment

    if not token and not args.denmark_token:
        print("Error: auth required. Set --token or --denmark-token, "
              "SLIKE_TOKEN, or token in config.toml")
        sys.exit(1)

    payload_data: Dict[str, Any] = {}
    if args.payload:
        try:
            payload_data = json.loads(args.payload)
        except json.JSONDecodeError as e:
            print(f"Error: --payload is not valid JSON: {e}")
            sys.exit(1)

    title       = args.title      or payload_data.get("title", "")
    desc        = args.desc       or payload_data.get("desc", "")
    asset_type  = args.asset_type or payload_data.get("asset_type", "video")
    tags        = ([t.strip() for t in args.tags.split(",")] if args.tags
                   else payload_data.get("tags"))
    preset_config = payload_data.get("preset_config")
    downloads     = payload_data.get("downloads")
    islive        = payload_data.get("islive", 0)
    media_type    = payload_data.get("type", 0)
    source        = payload_data.get("source", "uploadsdk")

    client = SlikeMedia(
        token=token,
        denmark_token=args.denmark_token,
        service=args.service,
        environment=env,
    )
    try:
        client.initialize()
    except SlikeAPIError as e:
        print(f"Error: failed to initialize SlikeMedia: {e}")
        sys.exit(1)

    if args.url:
        if not title or not desc:
            print("Error: --title and --desc are required for URL publish mode")
            sys.exit(1)
        print(f"Publishing via URL ({env})…")
        result = client.publish_media(
            url=args.url, title=title, description=desc,
            type=args.media_type, asset_type=asset_type, tags=tags,
            auto_publish=not args.no_publish,
        )
        r = result.get("result") or result
        print(f"Done. Media ID: {r.get('id', '?')}")
        return

    if not args.file:
        parser.error("Provide a file path or --url")
    if not title or not desc:
        print("Error: title and desc are required (via --title/--desc or --payload)")
        sys.exit(1)
    if not os.path.isfile(args.file):
        print(f"Error: file not found: {args.file}")
        sys.exit(1)

    print(f"Uploading {os.path.basename(args.file)} ({env})…")
    result = client.register_media(
        file_path=args.file,
        title=title,
        description=desc,
        asset_type=asset_type,
        tags=tags,
        preset_config=preset_config,
        downloads=downloads,
        islive=islive,
        media_type=media_type,
        source=source,
        on_progress=_cli_progress,
    )
    print(f"Done. Media ID: {result.get('id', '?')}")


if __name__ == "__main__":
    main()
