"""
Internal: chunked file upload + media.register payload assembly.

Used by `SlikeMedia.register_media`. Not part of the public API.
"""

import math
import mimetypes
import os
import re
import time
import uuid
from typing import Any, Dict, List, Optional

import requests

from slike import (
    CHUNK_SIZE,
    DEVELOPMENT_UPLOAD_URL,
    PRODUCTION_UPLOAD_URL,
    SlikeAPIError,
    _build_cookies,
    _build_headers,
    _get_api_url,
    _make_request,
    _session,
    logger,
)

__all__: List[str] = []


# ---------------------------------------------------------------------------
# URL + payload builders
# ---------------------------------------------------------------------------

def _get_upload_url(environment: str) -> str:
    return DEVELOPMENT_UPLOAD_URL if environment == "dev" else PRODUCTION_UPLOAD_URL


def _build_register_payload(
    title: str,
    description: str,
    asset_type: str,
    tags: Optional[List[str]],
    preset_config: Optional[Dict],
    downloads: Optional[Dict],
    islive: int,
    source: Optional[str],
    media_type: Any,
    fid: Optional[str],
    file_path: Optional[str],
    editor_settings: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    if file_path:
        filename = os.path.basename(file_path)
        file_size = os.path.getsize(file_path)
        params: Dict[str, Any] = {
            "fid": fid or f"{file_size}{filename}",
            "title": title,
            "desc": description,
            "source": source or "uploadsdk",
            "name": "media",
            "type": 0 if media_type is None else media_type,
            "islive": islive,
            "asset_type": asset_type,
        }
    else:
        params = {
            "name": "media",
            "type": "videoeditor" if media_type is None else media_type,
            "source": source or "videoeditor",
            "islive": islive,
            "title": title,
            "desc": description,
            "fid": fid or str(int(time.time() * 1000)),
            "asset_type": asset_type,
            "editor_settings": editor_settings,
        }

    if tags:
        if not isinstance(tags, list):
            raise ValueError("tags parameter must be a list of strings")
        params["tags"] = tags
    if preset_config:
        params["preset_config"] = preset_config
    if downloads:
        params["downloads"] = downloads

    return {
        "jsonrpc": "2.0",
        "id": uuid.uuid4().int & 0x7FFFFFFF,
        "method": "media.register",
        "params": params,
    }


# ---------------------------------------------------------------------------
# Chunk upload
# ---------------------------------------------------------------------------

def _build_resumable_identifier(filename: str, file_size: int) -> str:
    """Build a deterministic Resumable.js uniqueIdentifier, matching the frontend logic."""
    sanitized = re.sub(r"[.\s]", "", filename)
    return f"{file_size}-{sanitized}"


def _detect_mime_type(file_path: str) -> str:
    mime, _ = mimetypes.guess_type(file_path)
    return mime or "application/octet-stream"


def _upload_chunk(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    chunk_data: bytes,
    chunk_number: int,
    total_chunks: int,
    file_size: int,
    filename: str,
    mime_type: str,
    identifier: str,
) -> None:
    """Upload a single chunk using Resumable.js-compatible multipart form-data."""
    files = [
        ("resumableChunkNumber",      (None, str(chunk_number))),
        ("resumableChunkSize",        (None, str(CHUNK_SIZE))),
        ("resumableCurrentChunkSize", (None, str(len(chunk_data)))),
        ("resumableTotalSize",        (None, str(file_size))),
        ("resumableType",             (None, mime_type)),
        ("resumableIdentifier",       (None, identifier)),
        ("resumableFilename",         (None, filename)),
        ("resumableRelativePath",     (None, filename)),
        ("resumableTotalChunks",      (None, str(total_chunks))),
        ("method",                    (None, "asset.file")),
        ("entity",                    (None, media_id)),
        ("key",                       (None, "media")),
        ("file",                      (filename, chunk_data, mime_type)),
    ]
    try:
        response = _session.post(
            upload_url,
            files=files,
            headers={"token": upload_jwt},
            verify=True,
            timeout=120,
        )
        if response.status_code >= 400:
            raise SlikeAPIError(
                f"Chunk {chunk_number}/{total_chunks} upload failed: "
                f"HTTP {response.status_code} — {response.text}"
            )
    except SlikeAPIError:
        raise
    except requests.exceptions.RequestException as e:
        raise SlikeAPIError(f"Chunk {chunk_number}/{total_chunks} upload failed: {str(e)}")


_RETRY_ATTEMPTS = 3


def _upload_chunk_with_retry(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    chunk_data: bytes,
    chunk_number: int,
    total_chunks: int,
    file_size: int,
    filename: str,
    mime_type: str,
    identifier: str,
) -> None:
    """Retry wrapper around _upload_chunk with exponential backoff."""
    last_exc: Optional[Exception] = None
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            _upload_chunk(
                upload_url, media_id, upload_jwt,
                chunk_data, chunk_number, total_chunks,
                file_size, filename, mime_type, identifier,
            )
            return
        except SlikeAPIError as exc:
            last_exc = exc
            if attempt < _RETRY_ATTEMPTS:
                wait = 2 ** (attempt - 1)
                logger.warning(
                    "Chunk %d/%d failed (attempt %d/%d), retrying in %ds: %s",
                    chunk_number, total_chunks, attempt, _RETRY_ATTEMPTS, wait, exc,
                )
                time.sleep(wait)
    raise SlikeAPIError(
        f"Chunk {chunk_number}/{total_chunks} failed after {_RETRY_ATTEMPTS} attempts: {last_exc}"
    ) from last_exc


def _upload_file_chunks(
    upload_url: str,
    media_id: str,
    upload_jwt: str,
    file_path: str,
    on_progress: Optional[Any],
) -> None:
    """Read file and upload it in CHUNK_SIZE pieces sequentially."""
    file_size = os.path.getsize(file_path)
    filename = os.path.basename(file_path)
    mime_type = _detect_mime_type(file_path)
    total_chunks = math.ceil(file_size / CHUNK_SIZE)
    identifier = _build_resumable_identifier(filename, file_size)

    with open(file_path, "rb") as fh:
        for chunk_number in range(1, total_chunks + 1):
            chunk_data = fh.read(CHUNK_SIZE)
            if not chunk_data:
                break
            logger.debug("Uploading chunk %d/%d", chunk_number, total_chunks)
            _upload_chunk_with_retry(
                upload_url, media_id, upload_jwt,
                chunk_data, chunk_number, total_chunks,
                file_size, filename, mime_type, identifier,
            )
            if callable(on_progress):
                on_progress(chunk_number, total_chunks)


# ---------------------------------------------------------------------------
# Internal entry point — called from SlikeMedia.register_media
# ---------------------------------------------------------------------------

def _do_register_media(
    *,
    token: str,
    environment: str,
    title: str,
    description: str,
    file_path: Optional[str] = None,
    editor_settings: Optional[Dict[str, Any]] = None,
    asset_type: str = "video",
    tags: Optional[List[str]] = None,
    preset_config: Optional[Dict] = None,
    downloads: Optional[Dict] = None,
    islive: int = 0,
    media_type: Any = None,
    source: Optional[str] = None,
    fid: Optional[str] = None,
    on_progress: Optional[Any] = None,
) -> Dict[str, Any]:
    if not title or not isinstance(title, str):
        raise ValueError("title parameter is required and must be a non-empty string")
    if not description or not isinstance(description, str):
        raise ValueError("description parameter is required and must be a non-empty string")
    if bool(file_path) == bool(editor_settings):
        raise ValueError("Provide exactly one of file_path or editor_settings")

    if file_path:
        if not isinstance(file_path, str):
            raise ValueError("file_path must be a string")
        if not os.path.isfile(file_path):
            raise ValueError(f"file_path does not exist or is not a file: '{file_path}'")
    else:
        if not isinstance(editor_settings, dict) or not editor_settings:
            raise ValueError("editor_settings must be a non-empty dict")

    payload = _build_register_payload(
        title=title,
        description=description,
        asset_type=asset_type,
        tags=tags,
        preset_config=preset_config,
        downloads=downloads,
        islive=islive,
        source=source,
        media_type=media_type,
        fid=fid,
        file_path=file_path,
        editor_settings=editor_settings,
    )
    api_url = _get_api_url(environment)
    headers = _build_headers()
    cookies = _build_cookies(token, environment)
    result = _make_request(api_url, payload, headers, cookies)

    result_data = result.get("result") or {}
    media_id = result_data.get("id")
    upload_jwt = result_data.get("jwt")
    if not media_id or not upload_jwt:
        raise SlikeAPIError("media.register did not return expected 'id' and 'jwt' fields")

    if file_path:
        upload_url = _get_upload_url(environment)
        _upload_file_chunks(upload_url, media_id, upload_jwt, file_path, on_progress)

    return result_data
