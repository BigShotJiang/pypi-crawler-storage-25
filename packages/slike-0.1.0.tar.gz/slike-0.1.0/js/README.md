# Slike Upload SDK — JavaScript

Browser SDK for uploading media to the Slike platform.

---

## Setup

### Build

```bash
cd js
npm install
npm run build
# Output: dist/slike-upload-sdk.js
```

### Include in your page

```html
<script src="slike-upload-sdk.js"></script>
```

All exports are available under `window.SlikeSDK`.

---

## Initialize

```js
const { SlikeMedia } = SlikeSDK;

const slike = new SlikeMedia({
  token: 'your-api-token',
  environment: 'prod',           // 'prod' (default) | 'dev'
});

await slike.initialize();
```

`initialize()` is required before using any SDK method. If you call `publishMedia`, `registerMedia`, `uploadChunks`, or `uploadMedia` before initialization completes, the SDK throws an error.

### Auth options

You can initialize the SDK with either:

```js
const sdk = new SlikeMedia({
  token: 'your-slike-token',
  environment: 'prod',
});

await sdk.initialize();
```

or:

```js
const sdk = new SlikeMedia({
  denmarkToken: 'your-denmark-jwt',
  environment: 'prod',
});

await sdk.initialize();
```

### Auth behavior

- If `token` is passed to the constructor, `initialize()` validates it using `user.me`.
- If `denmarkToken` is passed to the constructor, `initialize()` exchanges it with `slikeauth /login` and uses the returned Slike token.
- Only direct constructor `token` values are validated.
- The SDK authenticates API requests with the `token` header. It does not write auth cookies from browser JavaScript.
- If you need the shared Slike auth cookie, issue it through `slikeauth` server endpoints such as `/login` or `/set-cookie`, which apply the required `HttpOnly` cookie policy.

---

## Option 1 — One-step upload (`uploadMedia`)

Register and upload in a single call.

```js
const file = document.getElementById('file').files[0];

const result = await slike.uploadMedia({
  file,
  title: 'My Video',
  description: 'Uploaded via SDK',
  onProgress(done, total) {
    console.log(`${done}/${total} chunks uploaded`);
  },
});

console.log('Media ID:', result.id);
```

### Options

| Option | Type | Required | Description |
|---|---|---|---|
| `file` | `File` | Yes | File object from `<input type="file">` |
| `title` | `string` | Yes | Media title |
| `description` | `string` | Yes | Media description |
| `assetType` | `string` | No | Asset type identifier |
| `tags` | `string[]` | No | Array of tags |
| `onProgress` | `function` | No | `(uploadedChunks, totalChunks) => void` |

### Returns: `RegisterMediaResult`

| Field | Type | Description |
|---|---|---|
| `id` | `string` | Unique media ID |
| `jwt` | `string` | Upload JWT |
| `media` | `object` | Full media metadata |
| `exists` | `boolean` | `true` if already registered |

---

## Option 2 — Two-step upload (`registerMedia` + `uploadChunks`)

Use this when you need control over each step — e.g. store the media ID before uploading.

### Step 1 — Register

```js
const file = document.getElementById('file').files[0];

const reg = await slike.registerMedia({
  file,
  title: 'My Video',
  description: 'Step 1 — register',
});

console.log('Media ID:', reg.id);
console.log('Upload JWT:', reg.jwt);
```

### Step 2 — Upload chunks

```js
await slike.uploadChunks({
  file,
  mediaId: reg.id,
  uploadJwt: reg.jwt,
  onProgress(done, total) {
    const pct = Math.round((done / total) * 100);
    console.log(`Progress: ${pct}%`);
  },
});
```

### `uploadChunks` options

| Option | Type | Required | Description |
|---|---|---|---|
| `file` | `File` | Yes | The file to upload |
| `mediaId` | `string` | Yes | Media ID from `registerMedia` |
| `uploadJwt` | `string` | Yes | JWT from `registerMedia` |
| `onProgress` | `function` | No | `(uploadedChunks, totalChunks) => void` |

> Files are split into **4 MiB chunks**. Each chunk is retried up to **3 times** on failure.

---

## Error Handling

```js
const { SlikeMedia, SlikeAPIError, CancelError } = SlikeSDK;

try {
  await slike.initialize();
  await slike.uploadMedia({ file, title, description });
} catch (err) {
  if (err instanceof CancelError) {
    console.log('Upload cancelled');
  } else if (err instanceof SlikeAPIError) {
    console.error('API error:', err.message);
  }
}
```

### Cancel an upload

Throw `new CancelError()` inside `onProgress` to abort:

```js
let cancelled = false;

cancelButton.addEventListener('click', () => { cancelled = true; });

await slike.uploadChunks({
  file,
  mediaId: reg.id,
  uploadJwt: reg.jwt,
  onProgress(done, total) {
    if (cancelled) throw new CancelError();
  },
});
```

---

## Full Example

```html
<!DOCTYPE html>
<html>
<body>

<input type="file" id="file" accept="video/*,audio/*,image/*" />
<button id="upload">Upload</button>
<button id="cancel">Cancel</button>
<progress id="bar" max="100" value="0"></progress>
<p id="status"></p>

<script src="slike-upload-sdk.js"></script>
<script>
  const { SlikeMedia, SlikeAPIError, CancelError } = SlikeSDK;
  let cancelled = false;

  document.getElementById('cancel').addEventListener('click', () => {
    cancelled = true;
  });

  document.getElementById('upload').addEventListener('click', async () => {
    const file = document.getElementById('file').files[0];
    if (!file) return;

    cancelled = false;
    document.getElementById('status').textContent = 'Uploading…';

    try {
      const slike = new SlikeMedia({ token: 'your-api-token' });
      await slike.initialize();

      const result = await slike.uploadMedia({
        file,
        title: file.name,
        description: 'Uploaded via SDK',
        onProgress(done, total) {
          if (cancelled) throw new CancelError();
          document.getElementById('bar').value = Math.round((done / total) * 100);
          document.getElementById('status').textContent = `${done}/${total} chunks`;
        },
      });
      document.getElementById('status').textContent = `Done! Media ID: ${result.id}`;
    } catch (err) {
      if (err instanceof CancelError) {
        document.getElementById('status').textContent = 'Cancelled.';
      } else {
        document.getElementById('status').textContent = `Error: ${err.message}`;
      }
    }
  });
</script>

</body>
</html>
```

---

## Environments

| | RPC | Upload | Auth Login |
|---|---|---|---|
| `prod` | `https://b2b.sli.ke/rpc` | `https://asset.sli.ke/upload` | `https://accounts.sli.ke/login` |
| `dev` | `https://app-dev.sli.ke/rpc` | `https://asset-dev.sli.ke/upload` | `https://accounts-dev.sli.ke/login` |

## Notes

- `new SlikeMedia(...)` is synchronous.
- `initialize()` is the required async step.
- `uploadChunks()` still requires `registerMedia()` output: `mediaId` and `uploadJwt`.
- Upload chunks are `4 MiB` and each chunk is retried up to `3` times.

---

## Version

```js
console.log(SlikeSDK.SlikeMedia.version); // '0.1.2'
```
