"""
CGPA Calculator - Calculate GPA, CGPA, and SGPA in Python
https://gpacalc.app
"""

__version__ = "1.0.0"

GRADE_SCALES = {
    "4.0": {
        "A+": 4.0, "A": 4.0, "A-": 3.7,
        "B+": 3.3, "B": 3.0, "B-": 2.7,
        "C+": 2.3, "C": 2.0, "C-": 1.7,
        "D+": 1.3, "D": 1.0, "D-": 0.7,
        "F": 0.0,
    },
    "5.0": {
        "A+": 5.0, "A": 5.0, "A-": 4.5,
        "B+": 4.0, "B": 3.5, "B-": 3.0,
        "C+": 2.5, "C": 2.0, "C-": 1.5,
        "D": 1.0, "F": 0.0,
    },
}


def get_grade_point(grade: str, scale: str = "4.0") -> float:
    scale_map = GRADE_SCALES.get(scale)
    if not scale_map:
        raise ValueError(f"Unsupported scale: {scale}. Use '4.0' or '5.0'.")
    upper = grade.upper().strip()
    if upper not in scale_map:
        raise ValueError(f"Unknown grade: {grade}")
    return scale_map[upper]


def calculate_gpa(courses: list[dict], scale: str = "4.0") -> float:
    if not courses:
        return 0.0

    total_points = 0.0
    total_credits = 0.0

    for course in courses:
        credits = course.get("credits", course.get("credit_hours", 3))
        grade = course["grade"]

        if isinstance(grade, (int, float)):
            grade_point = float(grade)
        else:
            grade_point = get_grade_point(grade, scale)

        total_points += grade_point * credits
        total_credits += credits

    if total_credits == 0:
        return 0.0
    return round(total_points / total_credits, 2)


def calculate_cgpa(semesters: list[list[dict]], scale: str = "4.0") -> float:
    all_courses = [c for sem in semesters for c in sem]
    return calculate_gpa(all_courses, scale)


def calculate_sgpa(courses: list[dict], scale: str = "4.0") -> float:
    return calculate_gpa(courses, scale)


def percentage_to_gpa(percentage: float, scale: str = "4.0") -> float:
    if scale == "4.0":
        if percentage >= 90:
            return 4.0
        if percentage >= 80:
            return 3.0 + (percentage - 80) / 10
        if percentage >= 70:
            return 2.0 + (percentage - 70) / 10
        if percentage >= 60:
            return 1.0 + (percentage - 60) / 10
        return 0.0
    if scale == "5.0":
        if percentage >= 90:
            return 5.0
        if percentage >= 80:
            return 4.0 + (percentage - 80) / 10
        if percentage >= 70:
            return 3.0 + (percentage - 70) / 10
        if percentage >= 60:
            return 2.0 + (percentage - 60) / 10
        if percentage >= 50:
            return 1.0 + (percentage - 50) / 10
        return 0.0
    raise ValueError(f"Unsupported scale: {scale}")


def gpa_to_letter(gpa: float) -> str:
    if gpa >= 3.7:
        return "A"
    if gpa >= 3.3:
        return "B+"
    if gpa >= 3.0:
        return "B"
    if gpa >= 2.7:
        return "B-"
    if gpa >= 2.3:
        return "C+"
    if gpa >= 2.0:
        return "C"
    if gpa >= 1.0:
        return "D"
    return "F"
