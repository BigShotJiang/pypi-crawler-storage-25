# CGPA Calculator

A lightweight JavaScript library for calculating GPA (Grade Point Average), CGPA (Cumulative GPA), and SGPA (Semester GPA).

Try the online version at [gpacalc.app](https://gpacalc.app)

## Installation

```bash
npm install cgpa-calculator
```

## Quick Start

```javascript
const { calculateGPA, calculateCGPA, gpaToLetter } = require('cgpa-calculator');

// Calculate semester GPA
const gpa = calculateGPA([
  { grade: 'A', credits: 4 },
  { grade: 'B+', credits: 3 },
  { grade: 'A-', credits: 3 },
  { grade: 'B', credits: 2 }
]);

console.log(gpa); // 3.58
console.log(gpaToLetter(gpa)); // 'B+'
```

## API

### calculateGPA(courses, options?)

Calculate GPA from a list of courses.

```javascript
const gpa = calculateGPA([
  { grade: 'A', credits: 3 },
  { grade: 'B', credits: 4 }
], { scale: '4.0' });
```

**Parameters:**
- `courses` - Array of `{ grade: string | number, credits: number }`
- `options.scale` - Grading scale: `'4.0'` (default) or `'5.0'`

### calculateCGPA(semesters, options?)

Calculate cumulative GPA across multiple semesters.

```javascript
const cgpa = calculateCGPA([
  [{ grade: 'A', credits: 3 }, { grade: 'B', credits: 4 }],
  [{ grade: 'A-', credits: 3 }, { grade: 'B+', credits: 3 }]
]);
```

### calculateSGPA(courses, options?)

Alias for `calculateGPA`. Calculate a single semester's GPA.

### percentageToGPA(percentage, scale)

Convert percentage score to GPA.

```javascript
percentageToGPA(85, '4.0'); // 3.5
percentageToGPA(92, '5.0'); // 5.0
```

### gpaToLetter(gpa)

Convert numeric GPA to letter grade.

```javascript
gpaToLetter(3.5); // 'B+'
gpaToLetter(4.0); // 'A'
```

### getGradePoint(grade, scale)

Get the numeric value for a letter grade.

```javascript
getGradePoint('A', '4.0'); // 4.0
getGradePoint('B+', '5.0'); // 4.0
```

## Supported Grade Scales

### 4.0 Scale
| Grade | Points |
|-------|--------|
| A+/A  | 4.0    |
| A-    | 3.7    |
| B+    | 3.3    |
| B     | 3.0    |
| B-    | 2.7    |
| C+    | 2.3    |
| C     | 2.0    |
| C-    | 1.7    |
| D+    | 1.3    |
| D     | 1.0    |
| F     | 0.0    |

### 5.0 Scale
| Grade | Points |
|-------|--------|
| A+/A  | 5.0    |
| A-    | 4.5    |
| B+    | 4.0    |
| B     | 3.5    |
| C+    | 2.5    |
| C     | 2.0    |
| D     | 1.0    |
| F     | 0.0    |

## Online Calculator

For a visual, interactive GPA calculator, visit [gpacalc.app](https://gpacalc.app).

## License

MIT
