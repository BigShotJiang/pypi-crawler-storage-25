import importlib
import pytest

main_module = importlib.import_module("contexara.main")


def test_ask_orchestrates_retrieve_enhance_call_llm(monkeypatch: pytest.MonkeyPatch):
    calls = []

    def fake_retrieve(query: str, **kwargs):
        calls.append(("retrieve", query))
        return ["memory one"]

    def fake_enhance(query: str, memories: list, **kwargs):
        calls.append(("enhance", query, memories))
        return "ENHANCED_PROMPT"

    def fake_call_llm(prompt: str, return_usage: bool = False):
        calls.append(("call_llm", prompt))
        return ("MODEL_RESPONSE", {"input_tokens": 10, "output_tokens": 5}) if return_usage else "MODEL_RESPONSE"

    def fake_ingest_turn(query: str, response: str, **kwargs):
        calls.append(("ingest_turn", query, response))
        return {"extracted": 1, "inserted": 1, "updated": 0, "skipped": 0}

    monkeypatch.setattr(main_module, "retrieve", fake_retrieve)
    monkeypatch.setattr(main_module, "enhance", fake_enhance)
    monkeypatch.setattr(main_module, "call_llm", fake_call_llm)
    monkeypatch.setattr(main_module, "ingest_turn", fake_ingest_turn)

    result = main_module.ask("What am I building?")

    assert result == "MODEL_RESPONSE"
    assert calls[0] == ("retrieve", "What am I building?")
    assert calls[1] == ("enhance", "What am I building?", ["memory one"])
    assert calls[2] == ("call_llm", "ENHANCED_PROMPT")
    assert calls[3] == ("ingest_turn", "What am I building?", "MODEL_RESPONSE")


def test_ask_rejects_empty_query():
    with pytest.raises(ValueError, match="cannot be empty"):
        main_module.ask("  ")


def test_ask_does_not_fail_when_ingest_errors(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(main_module, "retrieve", lambda _query, **kw: [])
    monkeypatch.setattr(main_module, "enhance", lambda _query, _memories, **kw: "P")
    monkeypatch.setattr(main_module, "call_llm", lambda _prompt, return_usage=False: ("OK", None) if return_usage else "OK")

    def failing_ingest(_query: str, _response: str, **kwargs):
        raise RuntimeError("ingest failure")

    monkeypatch.setattr(main_module, "ingest_turn", failing_ingest)

    assert main_module.ask("hello") == "OK"
