"""Tests for contexara.evals — LLM-as-judge scoring."""
from __future__ import annotations

import importlib
import json
from unittest.mock import patch
from uuid import uuid4

import pytest

telemetry_module = importlib.import_module("contexara.telemetry")
evals_module = importlib.import_module("contexara.evals")


@pytest.fixture(autouse=True)
def isolated_db(monkeypatch, tmp_path):
    metrics_db = tmp_path / f"metrics_{uuid4().hex}.db"
    monkeypatch.setattr(telemetry_module, "DB_PATH", metrics_db)
    telemetry_module.initialize_telemetry_db()
    yield


def _insert_ask_trace(query: str, memories: list[str] | None = None, scored: bool = False):
    """Helper: insert a minimal ask trace, optionally pre-scored."""
    telemetry_module.record_trace(
        "ask",
        namespace="default",
        latency_ms=100.0,
        query_text=query,
        retrieved_memories=json.dumps(memories or []),
    )
    if scored:
        conn = telemetry_module._get_connection()
        trace_id = conn.execute(
            "SELECT id FROM traces WHERE query_text = ? ORDER BY id DESC LIMIT 1", (query,)
        ).fetchone()[0]
        conn.close()
        telemetry_module.write_eval(trace_id, 1.0, "relevant")


# ---------------------------------------------------------------------------
# eval_status
# ---------------------------------------------------------------------------

def test_eval_status_empty():
    status = evals_module.eval_status()
    assert status["total_ask_traces"] == 0
    assert status["scored"] == 0
    assert status["unscored"] == 0


def test_eval_status_counts_correctly():
    _insert_ask_trace("query 1", scored=True)
    _insert_ask_trace("query 2", scored=False)
    _insert_ask_trace("query 3", scored=False)

    status = evals_module.eval_status()
    assert status["total_ask_traces"] == 3
    assert status["scored"] == 1
    assert status["unscored"] == 2


def test_eval_status_namespace_filter():
    telemetry_module.record_trace("ask", namespace="ns1", latency_ms=50.0, query_text="q1")
    telemetry_module.record_trace("ask", namespace="ns2", latency_ms=50.0, query_text="q2")

    status = evals_module.eval_status(namespace="ns1")
    assert status["total_ask_traces"] == 1


# ---------------------------------------------------------------------------
# write_eval
# ---------------------------------------------------------------------------

def test_write_eval_updates_row():
    telemetry_module.record_trace("ask", namespace="default", latency_ms=50.0, query_text="hello")
    conn = telemetry_module._get_connection()
    trace_id = conn.execute("SELECT id FROM traces ORDER BY id DESC LIMIT 1").fetchone()[0]
    conn.close()

    telemetry_module.write_eval(trace_id, 0.5, "partial")

    conn = telemetry_module._get_connection()
    row = conn.execute("SELECT eval_score, eval_label, eval_at FROM traces WHERE id = ?", (trace_id,)).fetchone()
    conn.close()

    assert row["eval_score"] == 0.5
    assert row["eval_label"] == "partial"
    assert row["eval_at"] is not None


def test_write_eval_bad_id_does_not_raise():
    telemetry_module.write_eval(99999, 1.0, "relevant")


# ---------------------------------------------------------------------------
# run_evals
# ---------------------------------------------------------------------------

def test_run_evals_empty_db():
    result = evals_module.run_evals()
    assert result["attempted"] == 0
    assert result["scored"] == 0


def test_run_evals_scores_unscored_traces():
    _insert_ask_trace("what is my project deadline?", ["deadline is friday", "sprint ends friday"])
    _insert_ask_trace("who is my manager?", ["manager is Alice"])

    with patch("contexara.evals._judge_trace") as mock_judge:
        mock_judge.return_value = (1.0, "relevant")
        result = evals_module.run_evals()

    assert result["attempted"] == 2
    assert result["scored"] == 2
    assert result["relevant"] == 2
    assert result["failed"] == 0


def test_run_evals_skips_already_scored():
    _insert_ask_trace("already scored query", scored=True)
    _insert_ask_trace("new unscored query", ["some memory"])

    with patch("contexara.evals._judge_trace") as mock_judge:
        mock_judge.return_value = (0.5, "partial")
        result = evals_module.run_evals()

    assert result["attempted"] == 1


def test_run_evals_handles_judge_failure():
    _insert_ask_trace("query that fails", ["memory"])

    with patch("contexara.evals._judge_trace") as mock_judge:
        mock_judge.return_value = None
        result = evals_module.run_evals()

    assert result["failed"] == 1
    assert result["scored"] == 0


def test_run_evals_respects_limit():
    for i in range(5):
        _insert_ask_trace(f"query {i}", ["some memory"])

    with patch("contexara.evals._judge_trace") as mock_judge:
        mock_judge.return_value = (1.0, "relevant")
        result = evals_module.run_evals(limit=3)

    assert result["attempted"] == 3


def test_run_evals_label_counts():
    _insert_ask_trace("q1", ["m1"])
    _insert_ask_trace("q2", ["m2"])
    _insert_ask_trace("q3", ["m3"])

    labels = ["relevant", "partial", "irrelevant"]
    call_count = 0

    def judge_side_effect(*_args, **_kwargs):
        nonlocal call_count
        label = labels[call_count % len(labels)]
        score = evals_module._LABEL_TO_SCORE[label]
        call_count += 1
        return score, label

    with patch("contexara.evals._judge_trace", side_effect=judge_side_effect):
        result = evals_module.run_evals()

    assert result["relevant"] == 1
    assert result["partial"] == 1
    assert result["irrelevant"] == 1


# ---------------------------------------------------------------------------
# get_eval_summary
# ---------------------------------------------------------------------------

def test_get_eval_summary_empty():
    summary = evals_module.get_eval_summary()
    assert summary["total_scored"] == 0
    assert summary["avg_score"] is None
    assert summary["recent"] == []


def test_get_eval_summary_after_scoring():
    _insert_ask_trace("q1", scored=True)  # score=1.0, label=relevant
    telemetry_module.record_trace("ask", namespace="default", latency_ms=50.0, query_text="q2")
    conn = telemetry_module._get_connection()
    tid = conn.execute("SELECT id FROM traces WHERE query_text='q2'").fetchone()[0]
    conn.close()
    telemetry_module.write_eval(tid, 0.0, "irrelevant")

    summary = evals_module.get_eval_summary()
    assert summary["total_scored"] == 2
    assert summary["avg_score"] == 0.5
    assert summary["by_label"]["relevant"] == 1
    assert summary["by_label"]["irrelevant"] == 1
    assert len(summary["recent"]) == 2
