"""Tests for Contexara REST API — v2.0.0"""
from __future__ import annotations

import importlib
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient

telemetry_module = importlib.import_module("contexara.telemetry")
session_module = importlib.import_module("contexara.session")


@pytest.fixture(autouse=True)
def isolated_dbs(monkeypatch, tmp_path):
    metrics_db = tmp_path / f"metrics_{uuid4().hex}.db"
    sess_db = tmp_path / f"sess_{uuid4().hex}.db"

    monkeypatch.setattr(telemetry_module, "DB_PATH", metrics_db)
    monkeypatch.setattr(session_module, "DB_PATH", sess_db)

    telemetry_module.initialize_telemetry_db()
    session_module.initialize_session_db()
    yield


@pytest.fixture()
def client():
    from contexara.server import app
    return TestClient(app)


# ---------------------------------------------------------------------------
# /health
# ---------------------------------------------------------------------------

def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert data["version"] == "2.0.0"
    assert "timestamp" in data


# ---------------------------------------------------------------------------
# /metrics/summary
# ---------------------------------------------------------------------------

def test_metrics_summary_empty(client):
    r = client.get("/api/metrics/summary")
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
    assert data["total_traces"] == 0
    assert data["by_op"] == {}


def test_metrics_summary_with_traces(client):
    telemetry_module.record_trace("retrieve", namespace="ns1", latency_ms=10.0, results_count=3)
    telemetry_module.record_trace("retrieve", namespace="ns1", latency_ms=20.0, results_count=1)
    telemetry_module.record_trace("ingest", namespace="ns1", latency_ms=5.0)

    r = client.get("/api/metrics/summary")
    data = r.json()
    assert data["total_traces"] == 3
    assert data["by_op"]["retrieve"] == 2
    assert data["by_op"]["ingest"] == 1
    assert data["avg_latency_by_op"]["retrieve"] == 15.0
    assert "ns1" in data["namespaces_active"]


def test_metrics_summary_namespace_filter(client):
    telemetry_module.record_trace("retrieve", namespace="ns_a", latency_ms=10.0)
    telemetry_module.record_trace("retrieve", namespace="ns_b", latency_ms=20.0)

    r = client.get("/api/metrics/summary?namespace=ns_a")
    data = r.json()
    assert data["total_traces"] == 1
    assert "ns_a" in data["namespaces_active"]
    assert "ns_b" not in data["namespaces_active"]


def test_metrics_summary_token_totals(client):
    telemetry_module.record_trace("ask", namespace="default", token_input=100, token_output=50)
    telemetry_module.record_trace("ask", namespace="default", token_input=200, token_output=80)

    r = client.get("/api/metrics/summary")
    data = r.json()
    assert data["total_token_input"] == 300
    assert data["total_token_output"] == 130


# ---------------------------------------------------------------------------
# /metrics/traces
# ---------------------------------------------------------------------------

def test_metrics_traces_empty(client):
    r = client.get("/api/metrics/traces")
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
    assert data["traces"] == []
    assert data["total"] == 0


def test_metrics_traces_pagination(client):
    for i in range(10):
        telemetry_module.record_trace("retrieve", namespace="default", latency_ms=float(i))

    r = client.get("/api/metrics/traces?page=1&page_size=5")
    data = r.json()
    assert data["count"] == 5
    assert data["total"] == 10
    assert data["page"] == 1

    r2 = client.get("/api/metrics/traces?page=2&page_size=5")
    data2 = r2.json()
    assert data2["count"] == 5
    assert data2["page"] == 2


def test_metrics_traces_filter_by_op(client):
    telemetry_module.record_trace("retrieve", namespace="default")
    telemetry_module.record_trace("ingest", namespace="default")
    telemetry_module.record_trace("ask", namespace="default")

    r = client.get("/api/metrics/traces?op=retrieve")
    data = r.json()
    assert data["total"] == 1
    assert data["traces"][0]["op"] == "retrieve"


def test_metrics_traces_filter_by_namespace(client):
    telemetry_module.record_trace("retrieve", namespace="ns_x")
    telemetry_module.record_trace("retrieve", namespace="ns_y")

    r = client.get("/api/metrics/traces?namespace=ns_x")
    data = r.json()
    assert data["total"] == 1
    assert data["traces"][0]["namespace"] == "ns_x"


# ---------------------------------------------------------------------------
# /metrics/latency
# ---------------------------------------------------------------------------

def test_metrics_latency_empty(client):
    r = client.get("/api/metrics/latency")
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
    assert data["latency"] == []


def test_metrics_latency_aggregated(client):
    telemetry_module.record_trace("retrieve", namespace="default", latency_ms=10.0)
    telemetry_module.record_trace("retrieve", namespace="default", latency_ms=30.0)
    telemetry_module.record_trace("ingest", namespace="default", latency_ms=5.0)

    r = client.get("/api/metrics/latency")
    data = r.json()
    by_op = {entry["op"]: entry for entry in data["latency"]}
    assert by_op["retrieve"]["avg_latency_ms"] == 20.0
    assert by_op["retrieve"]["min_latency_ms"] == 10.0
    assert by_op["retrieve"]["max_latency_ms"] == 30.0
    assert by_op["retrieve"]["count"] == 2
    assert by_op["ingest"]["count"] == 1


# ---------------------------------------------------------------------------
# /namespaces
# ---------------------------------------------------------------------------

def test_namespaces_list_empty(client):
    r = client.get("/api/namespaces")
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
    assert data["count"] == 0


def test_namespaces_create_and_list(client):
    r = client.post("/api/namespaces", json={"name": "my_agent"})
    assert r.status_code == 201
    data = r.json()
    assert data["ok"] is True
    assert data["name"] == "my_agent"

    r2 = client.get("/api/namespaces")
    names = [n["name"] for n in r2.json()["namespaces"]]
    assert "my_agent" in names


def test_namespaces_create_empty_name(client):
    r = client.post("/api/namespaces", json={"name": "  "})
    assert r.status_code == 422


def test_namespaces_delete(client):
    client.post("/api/namespaces", json={"name": "temp_ns"})
    r = client.delete("/api/namespaces/temp_ns")
    assert r.status_code == 200
    data = r.json()
    assert data["ok"] is True
    assert data["name"] == "temp_ns"


def test_namespaces_delete_default_blocked(client):
    r = client.delete("/api/namespaces/default")
    assert r.status_code == 400


def test_namespaces_delete_nonexistent(client):
    r = client.delete("/api/namespaces/ghost_ns")
    assert r.status_code == 404
