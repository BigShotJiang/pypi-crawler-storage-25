"""Tests for v1.1.0 telemetry instrumentation layer."""
from __future__ import annotations

import importlib
import time
from pathlib import Path
from uuid import uuid4

import pytest

telemetry_module = importlib.import_module("contexara.telemetry")
store_module = importlib.import_module("contexara.store")
retrieve_module = importlib.import_module("contexara.retrieve")
session_module = importlib.import_module("contexara.session")


@pytest.fixture(autouse=True)
def isolated_dbs(monkeypatch, tmp_path):
    metrics_db = tmp_path / f"metrics_{uuid4().hex}.db"
    mem_db = tmp_path / f"mem_{uuid4().hex}.db"
    sess_db = tmp_path / f"sess_{uuid4().hex}.db"

    monkeypatch.setattr(telemetry_module, "DB_PATH", metrics_db)
    monkeypatch.setattr(store_module, "DB_PATH", mem_db)
    monkeypatch.setattr(retrieve_module, "DB_PATH", mem_db)
    monkeypatch.setattr(session_module, "DB_PATH", sess_db)

    store_module._initialize_db()
    store_module.clear_all()
    session_module.initialize_session_db()
    telemetry_module.initialize_telemetry_db()
    yield


def _fake_embed(monkeypatch):
    import numpy as np
    import hashlib

    def fake_embed(text: str) -> np.ndarray:
        seed = int(hashlib.md5(text.encode()).hexdigest(), 16) % (2**31)
        rng = np.random.default_rng(seed)
        v = rng.random(1536).astype(np.float32)
        v /= np.linalg.norm(v)
        return v

    monkeypatch.setattr(store_module, "embed", fake_embed)
    monkeypatch.setattr(retrieve_module, "embed", fake_embed)


def _read_traces(tmp_path_fixture=None):
    conn = telemetry_module._get_connection()
    rows = conn.execute("SELECT * FROM traces ORDER BY id ASC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# record_trace — core behavior
# ---------------------------------------------------------------------------

def test_record_trace_writes_row():
    telemetry_module.record_trace("retrieve", namespace="ns1", latency_ms=12.5, results_count=3, top_k=5)
    rows = _read_traces()
    assert len(rows) == 1
    r = rows[0]
    assert r["op"] == "retrieve"
    assert r["namespace"] == "ns1"
    assert r["latency_ms"] == 12.5
    assert r["results_count"] == 3
    assert r["top_k"] == 5
    assert r["status"] == "ok"


def test_record_trace_error_status():
    telemetry_module.record_trace("retrieve", namespace="ns1", status="error", error="boom")
    rows = _read_traces()
    assert rows[0]["status"] == "error"
    assert rows[0]["error"] == "boom"


def test_record_trace_never_raises():
    # Even with a bad DB path, record_trace must not raise
    import tempfile, os
    original = telemetry_module.DB_PATH
    telemetry_module.DB_PATH = Path("/nonexistent_dir/metrics.db")
    try:
        telemetry_module.record_trace("retrieve")  # must not raise
    finally:
        telemetry_module.DB_PATH = original


def test_record_trace_multiple_ops():
    telemetry_module.record_trace("retrieve", namespace="a", latency_ms=10.0)
    telemetry_module.record_trace("ingest", namespace="a", latency_ms=20.0)
    telemetry_module.record_trace("ask", namespace="a", latency_ms=300.0)
    telemetry_module.record_trace("crystallize", namespace="a", latency_ms=500.0)
    rows = _read_traces()
    ops = [r["op"] for r in rows]
    assert ops == ["retrieve", "ingest", "ask", "crystallize"]


def test_record_trace_all_fields():
    telemetry_module.record_trace(
        "ask",
        namespace="test",
        latency_ms=250.0,
        session_id="sess-abc",
        token_input=100,
        token_output=50,
    )
    rows = _read_traces()
    r = rows[0]
    assert r["token_input"] == 100
    assert r["token_output"] == 50
    assert r["session_id"] == "sess-abc"


def test_record_trace_created_at_set():
    telemetry_module.record_trace("retrieve")
    rows = _read_traces()
    assert rows[0]["created_at"] is not None
    assert "T" in rows[0]["created_at"]  # ISO format


# ---------------------------------------------------------------------------
# retrieve() instrumentation
# ---------------------------------------------------------------------------

def test_retrieve_writes_trace(monkeypatch):
    _fake_embed(monkeypatch)
    store_module.upsert_memory("Python is great", kind="note", namespace="default")
    retrieve_module.retrieve("Python", namespace="default")
    rows = _read_traces()
    retrieve_rows = [r for r in rows if r["op"] == "retrieve"]
    assert len(retrieve_rows) >= 1
    r = retrieve_rows[-1]
    assert r["latency_ms"] is not None
    assert r["results_count"] is not None
    assert r["top_k"] is not None


def test_retrieve_empty_writes_trace(monkeypatch):
    _fake_embed(monkeypatch)
    retrieve_module.retrieve("anything", namespace="empty_ns")
    rows = _read_traces()
    retrieve_rows = [r for r in rows if r["op"] == "retrieve"]
    assert len(retrieve_rows) == 1
    assert retrieve_rows[0]["results_count"] == 0


def test_retrieve_mean_similarity_populated(monkeypatch):
    _fake_embed(monkeypatch)
    store_module.upsert_memory("Python is great", kind="note", namespace="default")
    store_module.upsert_memory("Java is verbose", kind="note", namespace="default")
    retrieve_module.retrieve("Python programming", namespace="default")
    rows = _read_traces()
    r = [r for r in rows if r["op"] == "retrieve"][-1]
    assert r["mean_similarity"] is not None
    assert 0.0 <= r["mean_similarity"] <= 1.0


# ---------------------------------------------------------------------------
# ingest() instrumentation
# ---------------------------------------------------------------------------

def test_ingest_writes_trace(monkeypatch):
    _fake_embed(monkeypatch)
    from contexara.ingest import ingest_turn
    session_id = session_module.get_or_create_session(namespace="default")
    ingest_turn("hello world this is a real message", "great to hear from you", session_id=session_id, namespace="default")
    rows = _read_traces()
    ingest_rows = [r for r in rows if r["op"] == "ingest"]
    assert len(ingest_rows) == 1
    r = ingest_rows[0]
    assert r["latency_ms"] is not None
    assert r["session_id"] == session_id


def test_ingest_stats_in_trace(monkeypatch):
    _fake_embed(monkeypatch)
    from contexara.ingest import ingest_turn
    ingest_turn("I love building memory engines", "That sounds amazing", session_id=None, namespace="default")
    rows = _read_traces()
    ingest_rows = [r for r in rows if r["op"] == "ingest"]
    assert len(ingest_rows) == 1
    r = ingest_rows[0]
    assert r["extracted"] is not None


# ---------------------------------------------------------------------------
# crystallize() instrumentation
# ---------------------------------------------------------------------------

def test_crystallize_writes_trace(monkeypatch):
    _fake_embed(monkeypatch)
    import io, json
    from unittest.mock import MagicMock
    mock_client = MagicMock()
    mock_client.invoke_model.return_value = {
        "body": io.BytesIO(json.dumps({
            "content": [{"text": '{"title":"test","actions":[],"outcomes":[],"open_items":[]}'}],
            "usage": {"input_tokens": 100, "output_tokens": 20},
        }).encode())
    }
    llm = importlib.import_module("contexara.llm")
    monkeypatch.setattr(llm, "_get_client", lambda *a, **kw: mock_client)

    from contexara.ingest import ingest_turn
    from contexara._crystallize import _crystallize
    session_id = session_module.get_or_create_session(namespace="default")
    ingest_turn("built a feature", "nice work", session_id=session_id, namespace="default")
    _crystallize(session_id)

    rows = _read_traces()
    crys_rows = [r for r in rows if r["op"] == "crystallize"]
    assert len(crys_rows) == 1
    r = crys_rows[0]
    assert r["session_id"] == session_id
    assert r["latency_ms"] is not None
    assert r["turn_count"] == 2  # user + assistant turns
