from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from contexara.embedder import cosine_similarity, deserialize, embed

DB_PATH = Path.home() / ".contexara" / "memory.db"

# RRF constant — 60 is the standard value from the original paper.
_RRF_K = 60

STOPWORDS = {
    "a", "am", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "how", "i", "in", "is", "it", "me", "my", "of", "on", "or", "that",
    "the", "this", "to", "was", "what", "when", "where", "which", "who",
    "why", "you", "your", "now", "currently",
}

CALENDAR_HINTS = {
    "date", "day", "time", "today", "tomorrow", "yesterday",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
    "january", "february", "march", "april", "may", "june", "july", "august",
    "september", "october", "november", "december",
}


def _get_connection():
    return sqlite3.connect(DB_PATH)


def _normalize(text: str) -> str:
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    return " ".join(tokens)


def _tokenize(text: str) -> set[str]:
    normalized = _normalize(text)
    return {t for t in normalized.split() if t and t not in STOPWORDS}


def _keyword_score(query: str, content: str) -> int:
    query_tokens = _tokenize(query)
    content_tokens = _tokenize(content)

    score = len(query_tokens & content_tokens)

    normalized_query = _normalize(query)
    normalized_content = _normalize(content)

    if normalized_query and normalized_query in normalized_content:
        score += 3

    if "name" in query_tokens and ("name" in content_tokens or "call me" in normalized_content):
        score += 3

    if "work" in query_tokens and ("working" in normalized_content or "building" in normalized_content):
        score += 1

    if query_tokens & {"date", "day", "time"} and content_tokens & CALENDAR_HINTS:
        score += 3

    return score


def _rrf_score(rank_semantic: int, rank_keyword: int) -> float:
    return 1.0 / (_RRF_K + rank_semantic) + 1.0 / (_RRF_K + rank_keyword)


def _format_episode(ep: dict) -> str:
    """Convert a raw episode dict (with JSON summary) into readable text for LLM context."""
    import json as _json
    try:
        data = _json.loads(ep["summary"])
        lines = [f"Session ({ep.get('started_at', '')[:10]}): {data.get('title', '')}"]
        if data.get("actions"):
            lines.append("Actions: " + "; ".join(data["actions"]))
        if data.get("outcomes"):
            lines.append("Outcomes: " + "; ".join(data["outcomes"]))
        if data.get("open_items"):
            lines.append("Open items: " + "; ".join(data["open_items"]))
        if data.get("facts"):
            lines.append("Key facts: " + "; ".join(data["facts"]))
        return " | ".join(lines)
    except Exception:
        return ep.get("summary", "")


def retrieve_episodes(query: str, top_k: int = 3, namespace: str = "default") -> list[str]:
    """
    Episode retrieval — semantic cosine search over all episodes, with temporal
    filtering as an additional signal when the query contains time expressions.

    1. Always fetch all episodes for the namespace and rank by cosine similarity.
    2. If a temporal window is detected, boost episodes that fall within the window.
    Returns top_k episode summary strings.
    """
    from .session import _get_connection as _sess_conn
    from .embedder import cosine_similarity, deserialize, embed

    try:
        conn = _sess_conn()
        rows = conn.execute(
            """
            SELECT session_id, summary, started_at, ended_at, embedding
            FROM episodes
            WHERE namespace = ?
            ORDER BY started_at DESC
            """,
            (namespace,),
        ).fetchall()
        conn.close()
    except Exception:
        return []

    if not rows:
        return []

    episodes = [dict(r) for r in rows]

    # Detect temporal window for boost (optional — doesn't gate retrieval)
    temporal_session_ids: set[str] = set()
    try:
        from .temporal import detect_temporal_intent
        from .session import retrieve_episodes_by_time
        window = detect_temporal_intent(query)
        if window:
            temporal_eps = retrieve_episodes_by_time(window.start, window.end, namespace=namespace)
            temporal_session_ids = {ep["session_id"] for ep in temporal_eps}
    except Exception:
        pass

    try:
        query_vec = embed(query)
        scored = []
        for ep in episodes:
            if ep["embedding"]:
                vec = deserialize(ep["embedding"])
                sim = cosine_similarity(query_vec, vec)
            else:
                sim = 0.0
            # Boost episodes that fall within the detected temporal window
            if ep["session_id"] in temporal_session_ids:
                sim += 0.15
            scored.append((sim, ep))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [_format_episode(ep) for _, ep in scored[:top_k]]
    except Exception:
        return [_format_episode(ep) for ep in episodes[:top_k]]


def _retrieve_cold_fts(query: str, namespace: str, top_k: int) -> list[tuple[float, str]]:
    """
    FTS5 keyword search over cold_archive.db (turns older than 30 days).
    Returns (score, formatted_content) pairs using a fixed low base score
    so cold results only surface when hot+memory results are sparse.
    """
    from .archive import search_cold_archive

    hits = search_cold_archive(query, limit=top_k * 2, namespace=namespace)
    if not hits:
        return []

    # Cold hits get a fixed low RRF-equivalent score so they rank below
    # hot and memory results but still appear when those pools are empty.
    _COLD_BASE_SCORE = 1.0 / (_RRF_K + top_k + 1)
    results: list[tuple[float, str]] = []
    for i, hit in enumerate(hits):
        score = _COLD_BASE_SCORE * (1.0 / (i + 1))  # decay by FTS rank
        role = hit.get("role", "user").upper()
        date = (hit.get("created_at") or "")[:10]
        content = hit.get("content", "")
        formatted = f"[archived turn {date} {role}] {content}"
        results.append((score, formatted))

    return results


def _retrieve_hot_hybrid(query: str, namespace: str, top_k: int, query_vector) -> list[tuple[float, str]]:
    """
    Hybrid search over raw_turns (hot active memory).

    1. FTS5 keyword pass — pull up to top_k*3 candidates from raw_turns_fts.
    2. Cosine re-rank — embed candidates and compute similarity against query vector.
    3. RRF merge — combine FTS rank and cosine rank into a single score.

    Returns list of (rrf_score, formatted_content) sorted descending.
    """
    from .session import search_hot_turns

    fts_hits = search_hot_turns(query, namespace=namespace, limit=top_k * 3)
    if not fts_hits:
        return []

    # Cosine re-rank over FTS candidates (small set — cheap)
    cosine_scored: list[tuple[float, dict]] = []
    for hit in fts_hits:
        try:
            vec = embed(hit["content"])
            sim = cosine_similarity(query_vector, vec)
        except Exception:
            sim = 0.0
        cosine_scored.append((sim, hit))
    cosine_scored.sort(key=lambda x: x[0], reverse=True)

    # FTS rank is just the original order (FTS5 rank is implicit in search_hot_turns result order)
    fts_rank = {hit["content"]: i + 1 for i, hit in enumerate(fts_hits)}
    cosine_rank = {hit["content"]: i + 1 for i, (_, hit) in enumerate(cosine_scored)}

    fused: list[tuple[float, str]] = []
    for hit in fts_hits:
        content = hit["content"]
        r_fts = fts_rank.get(content, len(fts_hits) + 1)
        r_cos = cosine_rank.get(content, len(fts_hits) + 1)
        rrf = _rrf_score(r_cos, r_fts)
        # Format as "role [date]: content" for readability in LLM context
        role = hit.get("role", "user").upper()
        date = hit.get("date") or hit.get("created_at", "")[:10]
        formatted = f"[recent turn {date} {role}] {content}"
        fused.append((rrf, formatted))

    fused.sort(key=lambda x: x[0], reverse=True)
    return fused[:top_k]


def retrieve(query: str, top_k: int = 5, namespace: str = "default") -> list[str]:
    if not query or not query.strip():
        return []

    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT content, embedding, source, compression_level, kind, created_at FROM memories WHERE namespace = ? ORDER BY created_at DESC", (namespace,))
        rows = cursor.fetchall()
        conn.close()
    except sqlite3.OperationalError:
        rows = []

    # Embed once — reused for both memory retrieval and hot-turn cosine scoring
    query_vector = embed(query)
    now = datetime.now(timezone.utc)

    # ── Hot-turn hybrid results (FTS5 + cosine) ──────────────────────────────
    hot_results = _retrieve_hot_hybrid(query, namespace=namespace, top_k=top_k, query_vector=query_vector)

    # ── Cold archive FTS results (turns >30 days old) ────────────────────────
    cold_results = _retrieve_cold_fts(query, namespace=namespace, top_k=top_k)

    if not rows:
        combined = sorted(hot_results + cold_results, key=lambda x: x[0], reverse=True)
        return [content for _, content in combined[:top_k]]

    # --- Semantic ranking ---
    semantic_scored: list[tuple[float, str]] = []
    for content, blob, _, _, _, _ in rows:
        if blob is not None:
            vec = deserialize(blob)
            sim = cosine_similarity(query_vector, vec)
        else:
            sim = 0.0
        semantic_scored.append((sim, content))
    semantic_scored.sort(key=lambda x: x[0], reverse=True)

    # --- Keyword ranking ---
    keyword_scored: list[tuple[int, str]] = []
    for content, _, _, _, _, _ in rows:
        score = _keyword_score(query, content)
        keyword_scored.append((score, content))
    keyword_scored.sort(key=lambda x: x[0], reverse=True)

    # Build rank lookup (1-based)
    semantic_rank = {content: i + 1 for i, (_, content) in enumerate(semantic_scored)}
    keyword_rank = {content: i + 1 for i, (_, content) in enumerate(keyword_scored)}

    source_map = {content: source for content, _, source, _, _, _ in rows}
    level_map = {content: (level or 0) for content, _, _, level, _, _ in rows}
    kind_map = {content: kind for content, _, _, _, kind, _ in rows}

    # Temporal: kinds that decay fast vs kinds that are stable
    _DECAY_WEIGHT = {"task": 0.30, "constraint": 0.20, "note": 0.15, "preference": 0.05, "profile": 0.0}

    def _recency_score(created_at_str: str, kind: str) -> float:
        try:
            created = datetime.fromisoformat(created_at_str)
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            days_old = max(0, (now - created).days)
            decay = _DECAY_WEIGHT.get(kind, 0.10)
            if decay == 0.0:
                return 1.0
            return max(0.0, 1.0 - days_old / 365) * decay
        except Exception:
            return 0.0

    created_map = {content: created_at for content, _, _, _, _, created_at in rows}

    # --- RRF fusion with temporal weighting ---
    all_contents = {content for content, _, _, _, _, _ in rows}
    fused: list[tuple[float, str]] = []
    for content in all_contents:
        r_sem = semantic_rank.get(content, len(rows) + 1)
        r_kw = keyword_rank.get(content, len(rows) + 1)
        rrf = _rrf_score(r_sem, r_kw)

        # compression level penalty (5% per level)
        level = level_map.get(content, 0)
        if level > 0:
            rrf *= (0.95 ** level)

        # temporal boost — recent memories score higher for time-sensitive kinds
        recency = _recency_score(created_map.get(content, ""), kind_map.get(content, "note"))
        score = rrf + recency

        fused.append((score, content))

    # ── Merge hot-turn results into fused pool ────────────────────────────────
    # Cap hot contribution to ceil(top_k/2) slots.
    _MAX_HOT_SLOTS = max(1, (top_k + 1) // 2)
    hot_contents_added: set[str] = set()
    for hot_score, hot_content in hot_results:
        if len(hot_contents_added) >= _MAX_HOT_SLOTS:
            break
        fused.append((hot_score, hot_content))
        hot_contents_added.add(hot_content)

    # ── Merge cold archive FTS results ───────────────────────────────────────
    # Cold results have a low base score — they only win slots when memory and
    # hot pools are sparse. Cap at 1 slot to avoid flooding with old turns.
    _MAX_COLD_SLOTS = 1
    cold_added = 0
    for cold_score, cold_content in cold_results:
        if cold_added >= _MAX_COLD_SLOTS:
            break
        fused.append((cold_score, cold_content))
        cold_added += 1

    fused.sort(key=lambda x: x[0], reverse=True)

    # ── Intent classification — adaptive retrieval strategy ──────────────────
    # Run after initial fused sort so we can pass scored results for confidence
    # check. This avoids an LLM call when retrieval is already clear.
    try:
        from .intent import classify_intent
        from .telemetry import record_trace as _record_trace
        intent, intent_source = classify_intent(query, scored_results=fused)
        _record_trace("intent", namespace=namespace, status=intent, error=intent_source)
    except Exception:
        intent, intent_source = "semantic", "error"

    if intent == "historical" and rows:
        # For historical queries: find earliest memory with meaningful similarity.
        # Dynamic floor = top semantic score * 0.7 — avoids pulling loosely
        # related junk while adapting to the query's similarity distribution.
        top_sim = semantic_scored[0][0] if semantic_scored else 0.0
        _HISTORICAL_SIM_FLOOR = max(0.40, top_sim * 0.7)
        historically_scored: list[tuple[str, str]] = []  # (created_at, content)
        for content, blob, _, _, _, created_at in rows:
            if blob is not None:
                vec = deserialize(blob)
                sim = cosine_similarity(query_vector, vec)
            else:
                sim = 0.0
            if sim >= _HISTORICAL_SIM_FLOOR:
                historically_scored.append((created_at, content))
        # Sort oldest first — historical results always dominate top slots
        historically_scored.sort(key=lambda x: x[0])
        if historically_scored:
            historical_results = [c for _, c in historically_scored[:top_k]]
            historical_set = set(historical_results)
            # Pad remaining slots with fused results — but never displace
            # a historical result; padding starts at index len(historical_results)
            for _, c in fused:
                if len(historical_results) >= top_k:
                    break
                if c not in historical_set:
                    historical_results.append(c)
            return historical_results

    elif intent == "recent":
        # For recent queries: apply a recency multiplier to fused scores,
        # pushing newer memories to the top.
        _RECENCY_BOOST = 0.20
        reboosted: list[tuple[float, str]] = []
        for score, content in fused:
            created_at = created_map.get(content, "")
            try:
                created = datetime.fromisoformat(created_at)
                if created.tzinfo is None:
                    created = created.replace(tzinfo=timezone.utc)
                days_old = max(0, (now - created).days)
                boost = _RECENCY_BOOST * max(0.0, 1.0 - days_old / 30)
            except Exception:
                boost = 0.0
            reboosted.append((score + boost, content))
        reboosted.sort(key=lambda x: x[0], reverse=True)
        fused = reboosted

    # #1: margin-based raw preference — raw wins only when scores are within epsilon
    _RAW_PREFERENCE_EPSILON = 0.03
    preferred: list[tuple[float, str]] = []
    for score, content in fused:
        if source_map.get(content) != "raw":
            # check if any raw result scores within epsilon of this compressed one
            raw_scores = [s for s, c in fused if source_map.get(c) == "raw"]
            if raw_scores and (raw_scores[0] - score) <= _RAW_PREFERENCE_EPSILON:
                continue  # skip this compressed entry; a raw alternative is close enough
        preferred.append((score, content))

    # #2: cap compressed results at 40% of top_k
    max_compressed = max(1, round(top_k * 0.4))
    result: list[str] = []
    compressed_count = 0
    for score, content in preferred:
        if len(result) >= top_k:
            break
        if source_map.get(content) == "compressed":
            if compressed_count >= max_compressed:
                continue
            compressed_count += 1
        result.append(content)

    return result
