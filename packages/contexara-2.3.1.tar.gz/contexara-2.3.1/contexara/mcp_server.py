"""
Contexara MCP Server — 13 tools across 4 domains.

Launch (stdio, default):
    contexara mcp
    python -m contexara.mcp_server

Launch (SSE, for HTTP agents):
    contexara mcp --sse --port 8000
"""
from __future__ import annotations

import asyncio
import sys
from typing import Any

# ---------------------------------------------------------------------------
# Server bootstrap
# ---------------------------------------------------------------------------

def _get_server():
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        print(
            "ERROR: 'mcp' package not installed. Run: pip install mcp",
            file=sys.stderr,
        )
        sys.exit(1)
    return FastMCP(
        name="contexara",
        instructions=(
            "Contexara is a three-tier memory engine. "
            "Use memory_search and chat_context before answering questions. "
            "Use memory_store when you learn facts worth remembering long-term. "
            "Use chat_ingest after every response. "
            "Use session_checkpoint when a major task completes."
        ),
    )


mcp = _get_server()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ok(data: dict) -> dict:
    return {"ok": True, **data}


def _err(msg: str) -> dict:
    return {"ok": False, "error": msg}


def _cap(items: list, limit: int) -> tuple[list, bool]:
    """Return (capped_list, more_results_exist)."""
    if len(items) > limit:
        return items[:limit], True
    return items, False


async def _run(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, lambda: fn(*args, **kwargs))


# ---------------------------------------------------------------------------
# Domain: Chat (Tier 1)
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Save a user↔assistant conversation turn to memory. "
        "Call this after every response you generate so the conversation "
        "is available for future context retrieval."
    )
)
async def chat_ingest(
    user_text: str,
    assistant_text: str,
    namespace: str = "default",
) -> dict:
    """
    Args:
        user_text: The user's message.
        assistant_text: Your (the assistant's) response.
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .ingest import ingest_turn
        from .session import get_or_create_session
        session_id, _ = await _run(get_or_create_session, namespace)
        result = await _run(ingest_turn, user_text, assistant_text, session_id, namespace)
        return _ok({"session_id": session_id, "stored": result})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Get the last N turns of the current conversation session. "
        "Call at session start or whenever you need recent context to answer accurately."
    )
)
async def chat_context(
    n: int = 10,
    namespace: str = "default",
) -> dict:
    """
    Args:
        n: Number of recent turns to retrieve (default 10, max 50).
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .session import get_or_create_session, get_recent_turns
        n = min(n, 50)
        session_id, episode_summary = await _run(get_or_create_session, namespace)
        turns = await _run(get_recent_turns, session_id, n)
        return _ok({"session_id": session_id, "turns": turns, "count": len(turns), "episode_summary": episode_summary})
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Domain: Episodes (Tier 2)
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Search past work sessions by time expression. "
        "Use for temporal questions like 'what did I build last week?' or "
        "'what was I working on yesterday?'. Query must contain a time expression."
    )
)
async def episodes_search(
    query: str,
    top_k: int = 5,
    namespace: str = "default",
) -> dict:
    """
    Args:
        query: Natural language query with time expression (e.g. 'what did I work on today?').
        top_k: Max results to return (default 5, max 10).
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .retrieve import retrieve_episodes
        top_k = min(top_k, 10)
        episodes = await _run(retrieve_episodes, query, top_k, namespace)
        results, more = _cap(episodes, top_k)
        return _ok({"episodes": results, "count": len(results), "more_results": more})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Get the most recent crystallized session summary. "
        "Fast — no query needed. Use to quickly orient yourself to what happened last session."
    )
)
async def episodes_latest(namespace: str = "default") -> dict:
    """
    Args:
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .session import get_last_episode
        summary = await _run(get_last_episode, namespace)
        if summary:
            return _ok({"summary": summary, "found": True})
        return _ok({"summary": None, "found": False})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Immediately crystallize (summarize) the current session into a durable episode. "
        "Call this when a major task, feature, or conversation arc is complete. "
        "Protects against memory loss if the process is killed before the 60-minute auto-timeout."
    )
)
async def session_checkpoint(namespace: str = "default") -> dict:
    """
    Args:
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .session import _get_connection, initialize_session_db
        from ._crystallize import _crystallize

        def _do():
            initialize_session_db()
            conn = _get_connection()
            row = conn.execute(
                "SELECT session_id FROM active_sessions WHERE status = 'open' AND namespace = ? ORDER BY last_action_at DESC LIMIT 1",
                (namespace,),
            ).fetchone()
            conn.close()
            return row["session_id"] if row else None

        session_id = await _run(_do)
        if not session_id:
            return _ok({"crystallized": False, "reason": "No open session found."})

        await _run(_crystallize, session_id)
        return _ok({"crystallized": True, "session_id": session_id})
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Domain: Memory (Tier 3)
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Store a fact, preference, task, constraint, or profile note in long-term memory. "
        "Use when you learn something worth remembering across sessions. "
        "Automatically deduplicates — safe to call multiple times with similar content."
    )
)
async def memory_store(
    content: str,
    kind: str = "note",
    importance: int = 1,
    ttl_days: int | None = None,
    namespace: str = "default",
) -> dict:
    """
    Args:
        content: The fact or note to store.
        kind: One of 'note', 'task', 'preference', 'profile', 'constraint'.
        importance: Priority 1–5. Higher surfaces sooner in retrieval (default 1).
        ttl_days: Optional expiry in days. Omit for permanent storage.
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .store import upsert_memory
        from .session import _register_namespace
        await _run(_register_namespace, namespace)
        result = await _run(
            upsert_memory,
            content=content,
            kind=kind,
            importance=importance,
            ttl_days=ttl_days,
            namespace=namespace,
        )
        return _ok({"result": result, "content": content, "kind": kind, "importance": importance})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Retrieve semantically relevant memories for a query. "
        "Call before answering questions that may rely on past context, preferences, or constraints. "
        "Returns ranked results — top result is most relevant."
    )
)
async def memory_search(
    query: str,
    top_k: int = 10,
    namespace: str = "default",
) -> dict:
    """
    Args:
        query: Natural language search query.
        top_k: Max results to return (default 10, max 20).
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .retrieve import retrieve
        from .session import _register_namespace
        await _run(_register_namespace, namespace)
        top_k = min(top_k, 20)
        memories = await _run(retrieve, query, top_k + 1, namespace)
        results, more = _cap(memories, top_k)
        return _ok({"memories": results, "count": len(results), "more_results": more})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "List all stored memories, optionally filtered by date. "
        "Use for auditing what's stored or showing the user their memory contents."
    )
)
async def memory_list(
    since: str | None = None,
    before: str | None = None,
    namespace: str = "default",
) -> dict:
    """
    Args:
        since: Optional ISO date filter e.g. '2025-01-01'. Returns memories created on or after.
        before: Optional ISO date filter. Returns memories created on or before.
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .store import list_all
        memories = await _run(list_all, since=since, before=before, namespace=namespace)
        results, more = _cap(memories, 50)
        return _ok({"memories": results, "count": len(results), "more_results": more})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Hard-delete a memory by ID. "
        "Use when the user explicitly says to forget something. "
        "This is permanent — use memory_deprecate instead if you're unsure."
    )
)
async def memory_forget(
    memory_id: int,
    namespace: str = "default",
) -> dict:
    """
    Args:
        memory_id: The integer ID from memory_list or memory_search results.
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .store import _get_connection, _initialize_db

        def _do():
            _initialize_db()
            conn = _get_connection()
            cursor = conn.execute(
                "DELETE FROM memories WHERE id = ? AND namespace = ?",
                (memory_id, namespace),
            )
            deleted = cursor.rowcount > 0
            conn.commit()
            conn.close()
            return deleted

        deleted = await _run(_do)
        return _ok({"deleted": deleted, "memory_id": memory_id})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Soft-retire a memory — keeps it stored but stops surfacing it in retrieval. "
        "Use when information is outdated but might still be historically relevant. "
        "Safer than memory_forget when you're unsure."
    )
)
async def memory_deprecate(
    memory_id: int,
    namespace: str = "default",
) -> dict:
    """
    Args:
        memory_id: The integer ID from memory_list or memory_search results.
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .store import _get_connection, _initialize_db

        def _do():
            _initialize_db()
            conn = _get_connection()
            cursor = conn.execute(
                "UPDATE memories SET compression_level = 10 WHERE id = ? AND namespace = ?",
                (memory_id, namespace),
            )
            updated = cursor.rowcount > 0
            conn.commit()
            conn.close()
            return updated

        updated = await _run(_do)
        return _ok({"deprecated": updated, "memory_id": memory_id})
    except Exception as e:
        return _err(str(e))


@mcp.tool(
    description=(
        "Get memory statistics for this namespace: total count, breakdown by kind and source. "
        "Use for agent self-monitoring or when the user asks about their memory state."
    )
)
async def memory_stats(namespace: str = "default") -> dict:
    """
    Args:
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .store import _get_connection, _initialize_db

        def _do():
            _initialize_db()
            conn = _get_connection()
            rows = conn.execute(
                "SELECT kind, source, importance FROM memories WHERE namespace = ? AND compression_level < 10",
                (namespace,),
            ).fetchall()
            conn.close()
            return [{"kind": r["kind"], "source": r["source"]} for r in rows]

        rows = await _run(_do)
        total = len(rows)
        by_kind: dict[str, int] = {}
        by_source: dict[str, int] = {}
        for r in rows:
            by_kind[r["kind"]] = by_kind.get(r["kind"], 0) + 1
            by_source[r["source"]] = by_source.get(r["source"], 0) + 1

        return _ok({"total": total, "by_kind": by_kind, "by_source": by_source, "namespace": namespace})
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Domain: Archive (Tier 4)
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "Full-text search across cold historical conversation turns. "
        "Use for deep history queries: 'find that bug we fixed last month', "
        "'what did we decide about X?'. Searches compressed older sessions."
    )
)
async def archive_search(
    query: str,
    limit: int = 10,
    namespace: str = "default",
) -> dict:
    """
    Args:
        query: Full-text search query.
        limit: Max results (default 10, max 20).
        namespace: Memory namespace. Default: 'default'.
    """
    try:
        from .archive import search_cold_archive
        limit = min(limit, 20)
        hits = await _run(search_cold_archive, query, limit + 1, namespace)
        results, more = _cap(hits, limit)
        return _ok({"hits": results, "count": len(results), "more_results": more})
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Domain: Meta
# ---------------------------------------------------------------------------

@mcp.tool(
    description=(
        "List all available memory namespaces. "
        "Use when working across multiple projects or agents to know which namespaces exist."
    )
)
async def namespace_list() -> dict:
    try:
        from .session import list_namespaces
        namespaces = await _run(list_namespaces)
        return _ok({"namespaces": namespaces, "count": len(namespaces)})
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_stdio():
    """Run MCP server over stdio (default — for Claude Desktop, agent SDKs)."""
    mcp.run(transport="stdio")


def run_sse(port: int = 8000, token: str | None = None):
    """Run MCP server over SSE (for HTTP-based agents)."""
    import secrets
    from mcp.server.fastmcp.server import TransportSecuritySettings

    _token = token or secrets.token_urlsafe(24)
    print(f"\n  Access URL: http://0.0.0.0:{port}/sse?token={_token}\n", flush=True)

    mcp.settings.host = "0.0.0.0"
    mcp.settings.port = port
    mcp.settings.transport_security = TransportSecuritySettings(
        enable_dns_rebinding_protection=False
    )

    # Wrap the SSE app with token validation middleware
    _patch_sse_with_token(mcp, _token)
    mcp.run(transport="sse")


def _patch_sse_with_token(server, token: str) -> None:
    """Monkey-patch sse_app to reject requests missing the correct token."""
    from starlette.applications import Starlette
    from starlette.responses import Response
    from starlette.middleware.base import BaseHTTPMiddleware

    original_sse_app = server.sse_app

    def patched_sse_app(mount_path=None):
        app = original_sse_app(mount_path)

        class TokenMiddleware(BaseHTTPMiddleware):
            async def dispatch(self, request, call_next):
                if request.query_params.get("token") != token:
                    return Response("Unauthorized", status_code=401)
                return await call_next(request)

        app.add_middleware(TokenMiddleware)
        return app

    server.sse_app = patched_sse_app


if __name__ == "__main__":
    run_stdio()
