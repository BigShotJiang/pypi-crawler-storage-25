from __future__ import annotations

import json
import re
from typing import Any

_LOW_SIGNAL_TOKENS = {
    "ok", "okay", "sure", "yes", "no", "yeah", "yep", "nope",
    "thanks", "thank", "you", "great", "cool", "nice", "good",
    "got", "it", "fine", "alright", "right", "perfect", "sounds",
    "lol", "haha", "hmm", "ah", "oh", "wow", "awesome",
}


def should_extract(text: str) -> bool:
    """Return False for low-signal turns that are not worth sending to the LLM."""
    if not text or not text.strip():
        return False
    if len(text.strip()) < 15:
        return False
    tokens = set(text.lower().split())
    if tokens.issubset(_LOW_SIGNAL_TOKENS):
        return False
    return True


MEMORY_IMPORTANCE = {
    "profile": 5,
    "correction": 5,
    "preference": 4,
    "constraint": 4,
    "tech_preference": 4,
    "style": 3,
    "pattern": 3,
    "task": 3,
    "note": 1,
}

VALID_KINDS = set(MEMORY_IMPORTANCE.keys())

LOW_SIGNAL_PREFIXES = (
    "hi",
    "hello",
    "thanks",
    "thank you",
    "ok",
    "okay",
    "cool",
    "great",
)

_EXTRACTION_SYSTEM_PROMPT = """\
You are a long-term memory extraction engine. Output ONLY a raw JSON array — no markdown, no prose, no explanation.

Extract distinct, durable facts about the user from the conversation turn below.
Be selective — prefer 2-5 high-quality memories over many overlapping ones.

KIND taxonomy (use the most specific kind that fits):
- profile         — name, role, company, location, background (importance 5)
- correction      — user corrected the assistant's output, approach, or assumption (importance 5)
- preference      — stated likes/dislikes, destinations, options being considered, workflows the user favours (importance 4)
- constraint      — hard limits: time, budget, team size, rules they operate under (importance 4)
- tech_preference — specific tech choices: languages, libraries, tools, patterns preferred or avoided (importance 4)
- style           — communication or output style: format preferences, level of detail, tone (importance 3)
- pattern         — recurring behaviour observed across this conversation: how user works, iterates, decides (importance 3)
- task            — current active work item (importance 3, ttl 30 days)
- note            — anything else worth remembering but not fitting above (importance 1)

Extraction rules:
- Include: name, role, completions, stated preferences, constraints, corrections, tech choices, style signals.
- Preferences: extract ANY option, destination, product, or choice the user is actively considering — even if not yet decided. "Thinking about Greece and Italy" is a preference worth storing.
- Use the assistant's response as a signal: if the assistant references something the user said (e.g. "you mentioned Greece and Italy"), extract that as a preference memory even if the user's message alone was vague.
- Corrections: if the user says "no", "not that", "actually", "I meant", "but I was", "stop doing X", "don't", "you said I didn't but I did", extract what they corrected AS a correction memory.
- Style signals: if user asks for bullets, shorter answers, more detail, code only, etc., extract as style.
- Tech preferences: if user picks one tool over another or rejects a library, extract as tech_preference.
- Patterns: if user mentions how they always/never do something, extract as pattern.
- Task details: if a task memory already exists and this turn adds specifics (destination, timeline, budget detail), store those specifics as new preference or constraint memories — do not skip just because a related task exists.
- Skip: pure filler, one-word replies, generic questions with no user-specific content, anything already captured verbatim in existing memories.
- Do NOT paraphrase an existing memory — skip it entirely if already covered.
- Write in third person (e.g. "User is considering Greece and Italy as destination options for their EU trip").

Output format (strictly):
[{"content": "...", "kind": "...", "importance": N}, ...]

If nothing new is worth remembering output exactly: []
"""


_CORRECTION_SIGNALS = re.compile(
    r"\b(no[,\s]|not that|actually[,\s]|i meant|but i (?:was|did|said|have)|"
    r"stop doing|don'?t do|please don'?t|"
    r"wrong[,\s]|incorrect[,\s]|that'?s not|not what i|never do that|"
    r"you said i didn'?t|you're wrong|that is wrong|"
    r"avoid that|don'?t use|instead use|use .{1,30} not)\b",
    re.IGNORECASE,
)


def _has_correction_signal(user_text: str) -> bool:
    """Return True if the user message contains a correction signal."""
    return bool(_CORRECTION_SIGNALS.search(user_text))


def _call_llm_for_extraction(
    user_text: str,
    assistant_text: str,
    existing_memories: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Extract memories via provider-agnostic LLM judge. Returns [] on any failure."""
    try:
        from contexara.llm import call_llm_judge

        existing_block = ""
        if existing_memories:
            items = "\n".join(f"- {m}" for m in existing_memories[:20])
            existing_block = f"\n\nAlready stored memories (do NOT re-extract these):\n{items}\n"

        correction_hint = (
            "\n⚠️ CORRECTION SIGNAL DETECTED: The user message likely corrects the assistant. "
            "Prioritise extracting a 'correction' kind memory capturing what was wrong and what the user wants instead.\n"
            if _has_correction_signal(user_text) else ""
        )

        turn = (
            f"{_EXTRACTION_SYSTEM_PROMPT}"
            f"{existing_block}{correction_hint}"
            f"\nConversation turn:\nUser: {user_text.strip()}\nAssistant: {assistant_text.strip()}"
        )

        raw_text = str(call_llm_judge(turn)).strip()

        # Strip markdown code fences if model wraps output in ```json ... ```
        raw_text = re.sub(r"^```(?:json)?\s*", "", raw_text)
        raw_text = re.sub(r"\s*```$", "", raw_text).strip()

        candidates = json.loads(raw_text)
        if not isinstance(candidates, list):
            return []

        memories = []
        for item in candidates:
            if not isinstance(item, dict):
                continue
            content = str(item.get("content", "")).strip()
            kind = str(item.get("kind", "note")).strip().lower()
            importance = item.get("importance", 1)

            if not content:
                continue
            if kind not in VALID_KINDS:
                kind = "note"
            try:
                importance = max(1, min(5, int(importance)))
            except (TypeError, ValueError):
                importance = MEMORY_IMPORTANCE.get(kind, 1)

            memories.append({"content": content, "kind": kind, "importance": importance, "ttl_days": None})

        return memories

    except Exception:
        return []


# ---------------------------------------------------------------------------
# Regex fallback (V1 logic — used when LLM extraction fails)
# ---------------------------------------------------------------------------

def _clean_text(text: str) -> str:
    return " ".join(text.strip().split())


def _split_into_segments(text: str) -> list[str]:
    if not text:
        return []
    normalized = _clean_text(text)
    punctuation_parts = re.split(r"[.;]\s+|\n+", normalized)
    segments: list[str] = []
    for part in punctuation_parts:
        chunk = part.strip()
        if not chunk:
            continue
        chunk = re.sub(
            r"\s+and\s+(?=(i\s+(?:am|m|will)|my\s+|first\s+task|tomorrow\b))",
            " ||| ",
            chunk,
            flags=re.IGNORECASE,
        )
        sub_parts = [p.strip() for p in chunk.split("|||") if p.strip()]
        segments.extend(sub_parts)
    return segments


def _extract_profile(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    name_match = re.search(r"\bmy name is\s+([A-Za-z][A-Za-z'\-\s]{1,50})", text, re.IGNORECASE)
    if name_match:
        name = _clean_text(name_match.group(1)).rstrip(".,!?")
        items.append({"content": f"User name is {name}", "kind": "profile", "importance": 5, "ttl_days": None})
    role_match = re.search(r"\bi am\s+(a|an)\s+([A-Za-z][A-Za-z'\-\s]{1,80})", text, re.IGNORECASE)
    if role_match:
        role = _clean_text(role_match.group(2)).rstrip(".,!?")
        if len(role.split()) <= 8:
            items.append({"content": f"User role is {role}", "kind": "profile", "importance": 5, "ttl_days": None})
    return items


def _extract_preferences(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    patterns = [
        r"\bi prefer\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi like\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi love\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi dislike\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
        r"\bi hate\s+(.+?)(?=$|\bbut\b|\bhowever\b)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        detail = _clean_text(match.group(1)).rstrip(".,!?")
        if not detail or detail.lower().startswith(LOW_SIGNAL_PREFIXES):
            continue
        items.append({"content": f"User preference: {detail}", "kind": "preference", "importance": 4, "ttl_days": None})
    return items


def _extract_tasks(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    task_patterns = [
        r"\bi am building\s+(.+)",
        r"\bi'?m building\s+(.+)",
        r"\bi am working on\s+(.+)",
        r"\bi'?m working on\s+(.+)",
        r"\bi am creating\s+(.+)",
        r"\bi'?m creating\s+(.+)",
        r"\bi (?:just\s+)?built\s+(.+)",
        r"\bi (?:just\s+)?finished\s+(.+)",
        r"\bi (?:just\s+)?completed\s+(.+)",
        r"\bi (?:just\s+)?shipped\s+(.+)",
        r"\bi(?:'?m|'m| am) (?:now\s+)?testing\s+(.+)",
        r"\bi will (?:start\s+)?(?:work on|build|implement|create)\s+(.+)",
        r"\btomorrow(?:\s+i)?\s+will\s+(?:start\s+)?(?:work on|build|implement|create)\s+(.+)",
        r"\bfirst task(?:\s+tomorrow)?\s+will\s+be\s+(?:implementing|building|creating|working on)\s+(.+)",
    ]
    for pattern in task_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if not match:
            continue
        task = _clean_text(match.group(1)).rstrip(".,!?")
        if task:
            items.append({"content": f"User is working on {task}", "kind": "task", "importance": 3, "ttl_days": 30})
    return items


def _extract_constraints(text: str) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    if re.search(r"\b(i need|must|should|do not|don't|cannot|can't)\b", text, re.IGNORECASE):
        cleaned = _clean_text(text).rstrip(".,!?")
        if cleaned and not cleaned.endswith("?"):
            items.append({"content": f"User constraint: {cleaned}", "kind": "constraint", "importance": 4, "ttl_days": 14})
    return items


def _regex_extract(user_text: str) -> list[dict[str, Any]]:
    extracted: list[dict[str, Any]] = []
    for segment in _split_into_segments(user_text):
        cleaned = _clean_text(segment)
        if not cleaned or cleaned.endswith("?"):
            continue
        extracted.extend(_extract_profile(cleaned))
        extracted.extend(_extract_preferences(cleaned))
        extracted.extend(_extract_tasks(cleaned))
        extracted.extend(_extract_constraints(cleaned))
    return extracted


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_memories(
    user_text: str,
    assistant_text: str = "",
    existing_memories: list[str] | None = None,
) -> list[dict[str, Any]]:
    """
    Extract high-signal memories from a conversation turn.

    Strategy: LLM extraction (Bedrock) analysing both user and assistant text,
    with existing memories passed as context so the LLM skips already-known facts.
    Falls back to deterministic regex on user text if LLM call fails.
    """
    llm_results = _call_llm_for_extraction(user_text or "", assistant_text or "", existing_memories)

    if llm_results:
        candidates = llm_results
    else:
        candidates = _regex_extract(user_text or "")

    # Deduplicate within this extraction call
    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in candidates:
        key = (item["kind"], item["content"].lower())
        if key not in seen:
            seen.add(key)
            deduped.append(item)

    return deduped
