"""
Embedding interface for Contexara — routes to the configured provider.

Set CONTEXARA_PROVIDER in .env to switch providers.
"""
from __future__ import annotations

import io
from functools import lru_cache

import numpy as np
from dotenv import load_dotenv

load_dotenv()


@lru_cache(maxsize=1)
def _embedder():
    from .providers import get_embedding_provider
    return get_embedding_provider()


def embed(text: str) -> np.ndarray:
    """Return a normalized float32 embedding vector via the configured provider."""
    return _embedder().embed(text)


def serialize(vector: np.ndarray) -> bytes:
    buf = io.BytesIO()
    np.save(buf, vector)
    return buf.getvalue()


def deserialize(blob: bytes) -> np.ndarray:
    buf = io.BytesIO(blob)
    return np.load(buf)


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity for pre-normalized vectors (dot product suffices)."""
    return float(np.dot(a, b))
