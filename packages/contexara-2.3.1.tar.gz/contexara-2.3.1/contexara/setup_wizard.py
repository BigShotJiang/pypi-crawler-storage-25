"""Interactive setup wizard for Contexara."""
from __future__ import annotations

import os
from pathlib import Path

from rich.console import Console
from rich.rule import Rule

console = Console()

_CONFIG_DIR = Path.home() / ".contexara"
_CONFIG_FILE = _CONFIG_DIR / ".env"

_PROVIDERS = {
    "1": "bedrock",
    "2": "openai",
    "3": "anthropic",
    "4": "gemini",
    "5": "openrouter",
}

_PROVIDER_LABELS = {
    "bedrock":    "AWS Bedrock        (Claude via AWS — needs IAM keys + model access)",
    "openai":     "OpenAI             (GPT models + text-embedding-3-small)",
    "anthropic":  "Anthropic + Voyage (Claude API + Voyage AI embeddings)",
    "gemini":     "Google Gemini      (Gemini models + built-in embeddings)",
    "openrouter": "OpenRouter         (any LLM via OpenRouter + OpenAI embeddings)",
}

_REQUIRED_KEYS: dict[str, list[dict]] = {
    "bedrock": [
        {"key": "AWS_ACCESS_KEY_ID",     "label": "AWS_ACCESS_KEY_ID",      "secret": False},
        {"key": "AWS_SECRET_ACCESS_KEY", "label": "AWS_SECRET_ACCESS_KEY",  "secret": True},
        {"key": "AWS_REGION",            "label": "AWS_REGION [us-east-1]", "secret": False, "default": "us-east-1"},
        {"key": "BEDROCK_MODEL_ID",      "label": "BEDROCK_MODEL_ID",       "secret": False,
         "hint": "Paste inference profile ARN or plain model ID.\n"
                 "  Example: anthropic.claude-haiku-4-5-20251001-v1:0"},
    ],
    "openai": [
        {"key": "OPENAI_API_KEY", "label": "OPENAI_API_KEY", "secret": True},
    ],
    "anthropic": [
        {"key": "ANTHROPIC_API_KEY", "label": "ANTHROPIC_API_KEY",              "secret": True},
        {"key": "VOYAGE_API_KEY",    "label": "VOYAGE_API_KEY (voyageai.com)",  "secret": True},
    ],
    "gemini": [
        {"key": "GEMINI_API_KEY", "label": "GEMINI_API_KEY", "secret": True},
    ],
    "openrouter": [
        {"key": "OPENROUTER_API_KEY", "label": "OPENROUTER_API_KEY",               "secret": True},
        {"key": "OPENAI_API_KEY",     "label": "OPENAI_API_KEY (for embeddings)",  "secret": True},
    ],
}

_PROVIDER_DOCS = {
    "bedrock":    "https://docs.aws.amazon.com/bedrock/latest/userguide/security-iam.html",
    "openai":     "https://platform.openai.com/api-keys",
    "anthropic":  "https://console.anthropic.com/keys  |  voyageai.com",
    "gemini":     "https://aistudio.google.com/app/apikey",
    "openrouter": "https://openrouter.ai/keys",
}


# ── Public API ────────────────────────────────────────────────────────────────

def is_configured() -> bool:
    """Return True if the active provider's required keys are all present."""
    _load_config()
    provider = os.getenv("CONTEXARA_PROVIDER", "bedrock").lower()
    return _keys_present(provider)


def load_config() -> None:
    _load_config()


def run_setup() -> None:
    """Run the interactive multi-provider setup wizard."""
    console.print()
    console.print(Rule("[bold bright_cyan]Contexara Setup[/bold bright_cyan]", style="cyan"))
    console.print()
    console.print("  Credentials are saved to [bright_cyan]~/.contexara/.env[/bright_cyan]")
    console.print()

    # ── Show current config if already set ───────────────────────────────────
    _load_config()
    current_provider = os.getenv("CONTEXARA_PROVIDER")
    if current_provider and _keys_present(current_provider):
        console.print(f"  [bright_cyan]Current provider:[/bright_cyan] [bright_white]{current_provider}[/bright_white]  [bright_green](configured)[/bright_green]")
        console.print()
        val = _prompt("Overwrite existing credentials? (y/N)")
        if val is None or val.lower() not in {"y", "yes"}:
            console.print("  [bright_cyan]·[/bright_cyan]  No changes made.")
            console.print()
            return
        console.print()

    # ── Step 1: choose provider ───────────────────────────────────────────────
    console.print("  [bright_white]Choose your AI provider:[/bright_white]")
    console.print()
    for num, pid in _PROVIDERS.items():
        console.print(f"    [bright_cyan]{num}.[/bright_cyan]  {_PROVIDER_LABELS[pid]}")
    console.print()

    provider = None
    while provider is None:
        val = _prompt("Enter number [1]")
        if val is None:
            _cancelled()
            return
        val = val.strip() or "1"
        if val in _PROVIDERS:
            provider = _PROVIDERS[val]
        else:
            console.print("  [bright_cyan]·[/bright_cyan]  Enter a number between 1 and 5.")

    console.print()
    console.print(f"  [bright_cyan]Provider:[/bright_cyan] {provider}")
    doc = _PROVIDER_DOCS.get(provider)
    if doc:
        console.print(f"  [bright_cyan]Docs:[/bright_cyan]    {doc}")
    console.print()
    console.print(Rule(style="cyan"))
    console.print("  [bright_cyan]Type 'exit' at any prompt to cancel.[/bright_cyan]")
    console.print()

    # ── Step 2: collect keys ──────────────────────────────────────────────────
    collected: dict[str, str] = {}
    for field in _REQUIRED_KEYS[provider]:
        hint = field.get("hint")
        if hint:
            console.print(f"  [bright_cyan]{field['key']}[/bright_cyan] — {hint}")
            console.print()

        value = ""
        while not value:
            val = _prompt(field["label"], secret=field.get("secret", False))
            if val is None:
                _cancelled()
                return
            default = field.get("default", "")
            value = val if val else default
            if not value:
                console.print("  [bright_cyan]·[/bright_cyan]  Cannot be empty.")

        collected[field["key"]] = value

    # ── Step 3: test connection ───────────────────────────────────────────────
    console.print()
    with console.status("[cyan]Testing connection…[/cyan]", spinner="dots"):
        error = _test_connection(provider, collected)

    if error:
        console.print(f"  [bright_red]✗[/bright_red]  Connection failed: {error}")
        if "No module named" in error:
            console.print(f"  [bright_cyan]·[/bright_cyan]  Missing package — run: [bright_white]pip install contexara[{provider}][/bright_white]")
        else:
            console.print("  [bright_cyan]·[/bright_cyan]  Check your credentials then run [bright_white]contexara setup[/bright_white] again.")
        console.print()
        return

    console.print(f"  [bright_green]✓[/bright_green]  Connected to {provider}.")

    # ── Step 4: save ──────────────────────────────────────────────────────────
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [f"CONTEXARA_PROVIDER={provider}\n"]
    for k, v in collected.items():
        lines.append(f"{k}={v}\n")
    _CONFIG_FILE.write_text("".join(lines), encoding="utf-8")

    for k, v in collected.items():
        os.environ[k] = v
    os.environ["CONTEXARA_PROVIDER"] = provider

    console.print(f"  [bright_green]✓[/bright_green]  Saved to [bright_cyan]~/.contexara/.env[/bright_cyan]")
    console.print()
    console.print("  Run [bright_white]contexara ask \"hello\"[/bright_white] to get started.")
    console.print()


# ── Namespace helpers ─────────────────────────────────────────────────────────

def get_default_namespace() -> str:
    """Return the active default namespace (from env or saved config)."""
    _load_config()
    return os.getenv("CONTEXARA_DEFAULT_NAMESPACE", "default")


def set_default_namespace(name: str) -> None:
    """Persist CONTEXARA_DEFAULT_NAMESPACE to ~/.contexara/.env."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    if _CONFIG_FILE.exists():
        for line in _CONFIG_FILE.read_text(encoding="utf-8").splitlines():
            if not line.startswith("CONTEXARA_DEFAULT_NAMESPACE="):
                lines.append(line)
    lines.append(f"CONTEXARA_DEFAULT_NAMESPACE={name}")
    _CONFIG_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.environ["CONTEXARA_DEFAULT_NAMESPACE"] = name


# ── Internals ─────────────────────────────────────────────────────────────────

def _load_config() -> None:
    if not _CONFIG_FILE.exists():
        return
    for line in _CONFIG_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip()
        if key and value and not os.getenv(key):
            os.environ[key] = value


def _keys_present(provider: str) -> bool:
    fields = _REQUIRED_KEYS.get(provider, [])
    return all(bool(os.getenv(f["key"])) for f in fields if not f.get("default"))


def _prompt(label: str, secret: bool = False) -> str | None:
    try:
        if secret:
            import getpass
            value = getpass.getpass(f"  {label}: ").strip()
        else:
            value = console.input(f"  [bright_cyan]{label}[/bright_cyan]: ").strip()
        if value.lower() == "exit":
            return None
        return value
    except (KeyboardInterrupt, EOFError):
        return None


def _cancelled() -> None:
    console.print("\n  [bright_cyan]·[/bright_cyan]  Setup cancelled.")
    console.print()


def _test_connection(provider: str, keys: dict[str, str]) -> str | None:
    """Fire a minimal request to verify credentials. Returns error string or None."""
    try:
        if provider == "bedrock":
            import boto3
            import json
            client = boto3.client(
                "bedrock-runtime",
                region_name=keys.get("AWS_REGION", "us-east-1"),
                aws_access_key_id=keys["AWS_ACCESS_KEY_ID"],
                aws_secret_access_key=keys["AWS_SECRET_ACCESS_KEY"],
            )
            payload = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "messages": [{"role": "user", "content": [{"type": "text", "text": "hi"}]}],
                "max_tokens": 10,
                "temperature": 0.0,
            })
            client.invoke_model(
                modelId=keys["BEDROCK_MODEL_ID"],
                body=payload,
                contentType="application/json",
                accept="application/json",
            )

        elif provider == "openai":
            from openai import OpenAI
            c = OpenAI(api_key=keys["OPENAI_API_KEY"])
            c.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "hi"}],
                max_tokens=5,
            )

        elif provider == "anthropic":
            import anthropic
            c = anthropic.Anthropic(api_key=keys["ANTHROPIC_API_KEY"])
            c.messages.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=5,
                messages=[{"role": "user", "content": "hi"}],
            )

        elif provider == "gemini":
            import google.generativeai as genai
            genai.configure(api_key=keys["GEMINI_API_KEY"])
            m = genai.GenerativeModel(
                "gemini-2.0-flash",
                generation_config={"max_output_tokens": 5},
            )
            m.generate_content("hi")

        elif provider == "openrouter":
            from openai import OpenAI
            c = OpenAI(
                api_key=keys["OPENROUTER_API_KEY"],
                base_url="https://openrouter.ai/api/v1",
            )
            c.chat.completions.create(
                model="meta-llama/llama-3.1-8b-instruct:free",
                messages=[{"role": "user", "content": "hi"}],
                max_tokens=5,
            )

        return None
    except Exception as exc:
        return str(exc)
