"""
Contexara Evals — LLM-as-judge relevance scoring for ask traces.

Usage:
    from contexara.evals import run_evals, eval_status
    run_evals()          # scores all unscored ask traces
    eval_status()        # returns dict with scored/unscored counts
"""
from __future__ import annotations

import json
from typing import Any

from .telemetry import _get_connection, initialize_telemetry_db, write_eval

_JUDGE_SYSTEM = (
    "You are an evaluator for a memory retrieval system. "
    "Given a user query and a list of retrieved memory snippets, "
    "rate how relevant the retrieved memories are to answering the query. "
    "Reply with ONLY a JSON object — no explanation, no markdown fences. "
    'Format: {"label": "relevant"|"partial"|"irrelevant", "reason": "<one sentence>"}'
)

_LABEL_TO_SCORE = {"relevant": 1.0, "partial": 0.5, "irrelevant": 0.0}


def _build_judge_prompt(query: str, memories: list[str]) -> str:
    memories_block = "\n".join(f"- {m}" for m in memories) if memories else "(no memories retrieved)"
    return (
        f"{_JUDGE_SYSTEM}\n\nUser:\n"
        f"Query: {query}\n\n"
        f"Retrieved memories:\n{memories_block}\n\n"
        "Rate the relevance of the retrieved memories to the query."
    )


def _judge_trace(query: str, retrieved_memories_json: str | None) -> tuple[float, str] | None:
    """Call LLM judge. Returns (score, label) or None on failure."""
    from .llm import call_llm_judge

    try:
        memories: list[str] = json.loads(retrieved_memories_json) if retrieved_memories_json else []
    except Exception:
        memories = []

    prompt = _build_judge_prompt(query, memories)
    try:
        raw = str(call_llm_judge(prompt))
        # Strip accidental markdown fences
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        data = json.loads(raw.strip())
        label = data.get("label", "").lower()
        if label not in _LABEL_TO_SCORE:
            return None
        return _LABEL_TO_SCORE[label], label
    except Exception:
        return None


def eval_status(namespace: str | None = None) -> dict[str, Any]:
    """Return counts of scored vs unscored ask traces."""
    initialize_telemetry_db()
    conn = _get_connection()
    try:
        where_ns = "AND namespace = ?" if namespace else ""
        params: list[Any] = [namespace] if namespace else []

        total = conn.execute(
            f"SELECT COUNT(*) FROM traces WHERE op = 'ask' {where_ns}", params
        ).fetchone()[0]
        scored = conn.execute(
            f"SELECT COUNT(*) FROM traces WHERE op = 'ask' AND eval_score IS NOT NULL {where_ns}", params
        ).fetchone()[0]
    finally:
        conn.close()

    return {
        "total_ask_traces": total,
        "scored": scored,
        "unscored": total - scored,
    }


def run_evals(namespace: str | None = None, limit: int = 100) -> dict[str, Any]:
    """
    Score all unscored ask traces using LLM-as-judge.
    Returns a summary dict with counts.
    """
    initialize_telemetry_db()
    conn = _get_connection()
    try:
        where_ns = "AND namespace = ?" if namespace else ""
        params: list[Any] = [namespace] if namespace else []

        rows = conn.execute(
            f"""
            SELECT id, query_text, retrieved_memories
            FROM traces
            WHERE op = 'ask'
              AND eval_score IS NULL
              AND query_text IS NOT NULL
              {where_ns}
            ORDER BY created_at DESC
            LIMIT ?
            """,
            params + [limit],
        ).fetchall()
    finally:
        conn.close()

    results = {"attempted": len(rows), "scored": 0, "failed": 0,
               "relevant": 0, "partial": 0, "irrelevant": 0}

    for row in rows:
        result = _judge_trace(row["query_text"], row["retrieved_memories"])
        if result is None:
            results["failed"] += 1
            continue
        score, label = result
        write_eval(row["id"], score, label)
        results["scored"] += 1
        results[label] = results.get(label, 0) + 1

    return results


def get_eval_summary(namespace: str | None = None) -> dict[str, Any]:
    """Aggregate eval scores for the API/dashboard."""
    initialize_telemetry_db()
    conn = _get_connection()
    try:
        where_ns = "AND namespace = ?" if namespace else ""
        params: list[Any] = [namespace] if namespace else []

        rows = conn.execute(
            f"""
            SELECT eval_label, eval_score, created_at, query_text, namespace, id, retrieved_memories
            FROM traces
            WHERE op = 'ask' AND eval_score IS NOT NULL {where_ns}
            ORDER BY eval_at DESC
            """,
            params,
        ).fetchall()

        total_ask = conn.execute(
            f"SELECT COUNT(*) FROM traces WHERE op = 'ask' {where_ns}", params
        ).fetchone()[0]

        # Daily avg score for last 30 days
        daily_rows = conn.execute(
            f"""
            SELECT date(created_at) as day, AVG(eval_score) as avg_score
            FROM traces
            WHERE op = 'ask' AND eval_score IS NOT NULL
              AND created_at >= date('now', '-30 days')
              {where_ns}
            GROUP BY day
            ORDER BY day ASC
            """,
            params,
        ).fetchall()

        # Worst 5 traces by score
        worst_rows = conn.execute(
            f"""
            SELECT id, query_text, eval_label, eval_score, namespace, retrieved_memories, created_at
            FROM traces
            WHERE op = 'ask' AND eval_score IS NOT NULL {where_ns}
            ORDER BY eval_score ASC
            LIMIT 5
            """,
            params,
        ).fetchall()

    finally:
        conn.close()

    counts: dict[str, int] = {"relevant": 0, "partial": 0, "irrelevant": 0}
    total_score = 0.0
    recent: list[dict[str, Any]] = []

    for r in rows:
        label = r["eval_label"] or "irrelevant"
        counts[label] = counts.get(label, 0) + 1
        total_score += r["eval_score"] or 0.0
        if len(recent) < 20:
            recent.append({
                "id": r["id"],
                "namespace": r["namespace"],
                "query_text": r["query_text"],
                "eval_label": label,
                "eval_score": r["eval_score"],
                "created_at": r["created_at"],
            })

    total = len(rows)

    worst: list[dict[str, Any]] = []
    for r in worst_rows:
        try:
            snippets = json.loads(r["retrieved_memories"] or "[]")
            if not isinstance(snippets, list):
                snippets = []
        except Exception:
            snippets = []
        worst.append({
            "id": r["id"],
            "query_text": r["query_text"],
            "eval_label": r["eval_label"] or "irrelevant",
            "eval_score": r["eval_score"],
            "namespace": r["namespace"],
            "created_at": r["created_at"],
            "snippets": snippets[:3],
        })

    return {
        "total_scored": total,
        "total_ask": total_ask,
        "avg_score": round(total_score / total, 3) if total else None,
        "by_label": counts,
        "recent": recent,
        "score_over_time": [{"date": r["day"], "avg_score": round(r["avg_score"], 3)} for r in daily_rows],
        "worst_traces": worst,
    }
