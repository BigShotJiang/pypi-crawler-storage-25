"""
LLM interface for Contexara — routes to the configured provider.

Public functions (unchanged interface, now provider-agnostic):
  call_llm(prompt)        — chat/completion call
  call_llm_judge(prompt)  — quality/judge call (deterministic, higher-capability model)

Set CONTEXARA_PROVIDER in .env to switch providers:
  bedrock (default) | openai | anthropic | gemini | openrouter
"""
from __future__ import annotations

from functools import lru_cache

from dotenv import load_dotenv

load_dotenv()


@lru_cache(maxsize=1)
def _llm():
    from .providers import get_llm_provider
    return get_llm_provider()


def call_llm(prompt: str) -> str:
    """Send a prompt using the chat model. Returns response text or '[LLM ERROR] ...'."""
    if not prompt or not prompt.strip():
        return "[LLM ERROR] Prompt cannot be empty."
    return _llm().complete(prompt)


def call_llm_judge(prompt: str) -> str:
    """Send a prompt using the judge model (deterministic, quality-sensitive ops)."""
    if not prompt or not prompt.strip():
        return "[LLM ERROR] Prompt cannot be empty."
    return _llm().complete_judge(prompt)


# ── Backward compatibility ────────────────────────────────────────────────────
# BedrockConfig is kept so any external code that imports it doesn't break.
# New code should use call_llm / call_llm_judge directly.

class BedrockConfig:
    """Deprecated: use CONTEXARA_PROVIDER=bedrock and call_llm() instead."""
    @staticmethod
    def from_env():
        from .providers.bedrock import BedrockLLMProvider
        p = BedrockLLMProvider()
        return p

    @staticmethod
    def judge_from_env():
        from .providers.bedrock import BedrockLLMProvider
        p = BedrockLLMProvider()
        return p
