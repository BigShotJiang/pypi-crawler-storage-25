"""OpenAI provider — LLM (GPT) + Embeddings (text-embedding-3-small)."""
from __future__ import annotations

import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider, LLMProvider

load_dotenv()

_EMBED_MODEL = "text-embedding-3-small"
_EMBED_DIM = 1536
_DEFAULT_CHAT_MODEL = "gpt-4o-mini"
_DEFAULT_JUDGE_MODEL = "gpt-4o"


class OpenAILLMProvider(LLMProvider):
    """
    Required env vars:
      OPENAI_API_KEY
      OPENAI_CHAT_MODEL   (default: gpt-4o-mini)
      OPENAI_JUDGE_MODEL  (default: gpt-4o)
    """

    def __init__(self) -> None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError("OPENAI_API_KEY is not set.")
        from openai import OpenAI
        self._client = OpenAI(api_key=api_key)
        self._chat_model = os.getenv("OPENAI_CHAT_MODEL", _DEFAULT_CHAT_MODEL)
        self._judge_model = os.getenv("OPENAI_JUDGE_MODEL", _DEFAULT_JUDGE_MODEL)

    def _call(self, prompt: str, model: str, max_tokens: int, temperature: float) -> str:
        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=temperature,
            )
            return response.choices[0].message.content.strip()
        except Exception as exc:
            return f"[LLM ERROR] {exc}"

    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        return self._call(prompt, self._chat_model, max_tokens, temperature)

    def complete_judge(self, prompt: str) -> str:
        return self._call(prompt, self._judge_model, max_tokens=2048, temperature=0.0)


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """
    Required env vars:
      OPENAI_API_KEY
      OPENAI_EMBED_MODEL  (default: text-embedding-3-small)
    """

    def __init__(self) -> None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError("OPENAI_API_KEY is not set.")
        from openai import OpenAI
        self._client = OpenAI(api_key=api_key)
        self._model = os.getenv("OPENAI_EMBED_MODEL", _EMBED_MODEL)

    @property
    def dimensions(self) -> int:
        return _EMBED_DIM

    def embed(self, text: str) -> np.ndarray:
        response = self._client.embeddings.create(input=text.strip(), model=self._model)
        return np.array(response.data[0].embedding, dtype="float32")
