"""Voyage AI embedding provider — used with CONTEXARA_PROVIDER=anthropic."""
from __future__ import annotations

import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider

load_dotenv()

_DEFAULT_MODEL = "voyage-3"
_EMBED_DIM = 1024


class VoyageEmbeddingProvider(EmbeddingProvider):
    """
    Required env vars:
      VOYAGE_API_KEY
      VOYAGE_EMBED_MODEL  (default: voyage-3)
    """

    def __init__(self) -> None:
        self._api_key = os.getenv("VOYAGE_API_KEY")
        if not self._api_key:
            raise EnvironmentError(
                "VOYAGE_API_KEY is not set. Anthropic provider requires Voyage AI for embeddings. "
                "Get a key at voyageai.com"
            )
        self._model = os.getenv("VOYAGE_EMBED_MODEL", _DEFAULT_MODEL)

    @property
    def dimensions(self) -> int:
        return _EMBED_DIM

    def embed(self, text: str) -> np.ndarray:
        import voyageai
        client = voyageai.Client(api_key=self._api_key)
        result = client.embed([text.strip()], model=self._model)
        return np.array(result.embeddings[0], dtype="float32")
