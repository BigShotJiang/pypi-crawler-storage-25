"""AWS Bedrock provider — LLM (Claude) + Embeddings (Titan V2)."""
from __future__ import annotations

import io
import json
import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider, LLMProvider

load_dotenv()

_TITAN_MODEL = "amazon.titan-embed-text-v2:0"
_TITAN_DIM = 1024


def _bedrock_client(region: str):
    import boto3
    if os.getenv("AWS_ACCESS_KEY") and not os.getenv("AWS_ACCESS_KEY_ID"):
        os.environ["AWS_ACCESS_KEY_ID"] = os.environ["AWS_ACCESS_KEY"]
    return boto3.client("bedrock-runtime", region_name=region)


def _invoke(client, model_id: str, prompt: str, max_tokens: int, temperature: float) -> str:
    if "\n\nUser:\n" in prompt:
        system_part, user_part = prompt.split("\n\nUser:\n", 1)
        user_text = user_part.replace("\n\nAssistant:", "").strip()
    else:
        system_part = ""
        user_text = prompt.strip()

    body: dict = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [{"role": "user", "content": [{"type": "text", "text": user_text}]}],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if system_part.strip():
        body["system"] = system_part.strip()

    response = client.invoke_model(
        modelId=model_id,
        body=json.dumps(body),
        contentType="application/json",
        accept="application/json",
    )
    result = json.loads(response["body"].read())
    return result["content"][0]["text"].strip()


class BedrockLLMProvider(LLMProvider):
    """
    Required env vars:
      BEDROCK_MODEL_ID       — chat model (e.g. Haiku)
      BEDROCK_EVAL_MODEL_ID  — judge model (e.g. Sonnet), falls back to BEDROCK_MODEL_ID
      AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY
      AWS_REGION             (default: us-east-1)
    """

    def __init__(self) -> None:
        self._region = os.getenv("AWS_REGION", "us-east-1")
        self._chat_model = os.getenv("BEDROCK_MODEL_ID")
        self._judge_model = os.getenv("BEDROCK_EVAL_MODEL_ID") or self._chat_model
        if not self._chat_model:
            raise EnvironmentError("BEDROCK_MODEL_ID is not set.")
        self._client = _bedrock_client(self._region)

    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        try:
            return _invoke(self._client, self._chat_model, prompt, max_tokens, temperature)
        except Exception as exc:
            return f"[LLM ERROR] {exc}"

    def complete_judge(self, prompt: str) -> str:
        try:
            return _invoke(self._client, self._judge_model, prompt, max_tokens=2048, temperature=0.0)
        except Exception as exc:
            return f"[LLM ERROR] {exc}"


class BedrockEmbeddingProvider(EmbeddingProvider):
    """
    Required env vars: same AWS credentials as BedrockLLMProvider.
    """

    def __init__(self) -> None:
        self._region = os.getenv("AWS_REGION", "us-east-1")
        self._client = _bedrock_client(self._region)

    @property
    def dimensions(self) -> int:
        return _TITAN_DIM

    def embed(self, text: str) -> np.ndarray:
        payload = json.dumps({"inputText": text.strip(), "dimensions": _TITAN_DIM, "normalize": True})
        response = self._client.invoke_model(
            modelId=_TITAN_MODEL,
            body=payload,
            contentType="application/json",
            accept="application/json",
        )
        result = json.loads(response["body"].read())
        return np.array(result["embedding"], dtype="float32")
