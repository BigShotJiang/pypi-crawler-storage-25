"""Anthropic provider — LLM (Claude API). Pair with Voyage for embeddings."""
from __future__ import annotations

import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider, LLMProvider

load_dotenv()

_DEFAULT_CHAT_MODEL = "claude-haiku-4-5-20251001"
_DEFAULT_JUDGE_MODEL = "claude-sonnet-4-6"


class AnthropicLLMProvider(LLMProvider):
    """
    Required env vars:
      ANTHROPIC_API_KEY
      ANTHROPIC_CHAT_MODEL   (default: claude-haiku-4-5-20251001)
      ANTHROPIC_JUDGE_MODEL  (default: claude-sonnet-4-6)
    """

    def __init__(self) -> None:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError("ANTHROPIC_API_KEY is not set.")
        import anthropic
        self._client = anthropic.Anthropic(api_key=api_key)
        self._chat_model = os.getenv("ANTHROPIC_CHAT_MODEL", _DEFAULT_CHAT_MODEL)
        self._judge_model = os.getenv("ANTHROPIC_JUDGE_MODEL", _DEFAULT_JUDGE_MODEL)

    def _call(self, prompt: str, model: str, max_tokens: int, temperature: float) -> str:
        try:
            message = self._client.messages.create(
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=[{"role": "user", "content": prompt}],
            )
            return message.content[0].text.strip()
        except Exception as exc:
            return f"[LLM ERROR] {exc}"

    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        return self._call(prompt, self._chat_model, max_tokens, temperature)

    def complete_judge(self, prompt: str) -> str:
        return self._call(prompt, self._judge_model, max_tokens=2048, temperature=0.0)
