"""OpenRouter provider — any LLM via OpenAI-compatible API + configurable embeddings."""
from __future__ import annotations

import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider, LLMProvider

load_dotenv()

_BASE_URL = "https://openrouter.ai/api/v1"
_DEFAULT_CHAT_MODEL = "meta-llama/llama-3.1-8b-instruct:free"
_DEFAULT_JUDGE_MODEL = "anthropic/claude-3.5-haiku"
_DEFAULT_EMBED_MODEL = "text-embedding-3-small"
_EMBED_DIM = 1536


class OpenRouterLLMProvider(LLMProvider):
    """
    Required env vars:
      OPENROUTER_API_KEY
      OPENROUTER_CHAT_MODEL   (default: meta-llama/llama-3.1-8b-instruct:free)
      OPENROUTER_JUDGE_MODEL  (default: anthropic/claude-3.5-haiku)
    """

    def __init__(self) -> None:
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise EnvironmentError("OPENROUTER_API_KEY is not set.")
        from openai import OpenAI
        self._client = OpenAI(api_key=api_key, base_url=_BASE_URL)
        self._chat_model = os.getenv("OPENROUTER_CHAT_MODEL", _DEFAULT_CHAT_MODEL)
        self._judge_model = os.getenv("OPENROUTER_JUDGE_MODEL", _DEFAULT_JUDGE_MODEL)

    def _call(self, prompt: str, model: str, max_tokens: int, temperature: float) -> str:
        try:
            response = self._client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=max_tokens,
                temperature=temperature,
            )
            return response.choices[0].message.content.strip() # type: ignore
        except Exception as exc:
            return f"[LLM ERROR] {exc}"

    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        return self._call(prompt, self._chat_model, max_tokens, temperature)

    def complete_judge(self, prompt: str) -> str:
        return self._call(prompt, self._judge_model, max_tokens=2048, temperature=0.0)


class OpenRouterEmbeddingProvider(EmbeddingProvider):
    """
    OpenRouter doesn't serve embeddings — falls back to OpenAI embeddings API.

    Required env vars:
      OPENAI_API_KEY         — for embeddings
      OPENROUTER_EMBED_MODEL (default: text-embedding-3-small)
    """

    def __init__(self) -> None:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "OPENAI_API_KEY is required for embeddings when using OpenRouter. "
                "OpenRouter does not serve embedding models."
            )
        from openai import OpenAI
        self._client = OpenAI(api_key=api_key)
        self._model = os.getenv("OPENROUTER_EMBED_MODEL", _DEFAULT_EMBED_MODEL)

    @property
    def dimensions(self) -> int:
        return _EMBED_DIM

    def embed(self, text: str) -> np.ndarray:
        response = self._client.embeddings.create(input=text.strip(), model=self._model)
        return np.array(response.data[0].embedding, dtype="float32")
