"""Abstract base interfaces for LLM and Embedding providers."""
from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np


class LLMProvider(ABC):
    """Unified interface for LLM completions."""

    @abstractmethod
    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        """Return the assistant text for a given prompt."""

    @abstractmethod
    def complete_judge(self, prompt: str) -> str:
        """
        Return the assistant text using a quality/judge model.
        Used for crystallization, extraction, and evals.
        Temperature is always 0.0 for determinism.
        """


class EmbeddingProvider(ABC):
    """Unified interface for text embeddings."""

    @abstractmethod
    def embed(self, text: str) -> np.ndarray:
        """Return a normalized float32 embedding vector."""

    @property
    @abstractmethod
    def dimensions(self) -> int:
        """Embedding vector dimensionality."""
