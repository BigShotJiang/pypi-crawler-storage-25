"""Google Gemini provider — LLM + Embeddings."""
from __future__ import annotations

import os

import numpy as np
from dotenv import load_dotenv

from .base import EmbeddingProvider, LLMProvider

load_dotenv()

_DEFAULT_CHAT_MODEL = "gemini-2.0-flash"
_DEFAULT_JUDGE_MODEL = "gemini-2.0-flash"
_DEFAULT_EMBED_MODEL = "models/text-embedding-004"
_EMBED_DIM = 768


class GeminiLLMProvider(LLMProvider):
    """
    Required env vars:
      GEMINI_API_KEY
      GEMINI_CHAT_MODEL   (default: gemini-2.0-flash)
      GEMINI_JUDGE_MODEL  (default: gemini-2.0-flash)
    """

    def __init__(self) -> None:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise EnvironmentError("GEMINI_API_KEY is not set.")
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self._genai = genai
        self._chat_model = os.getenv("GEMINI_CHAT_MODEL", _DEFAULT_CHAT_MODEL)
        self._judge_model = os.getenv("GEMINI_JUDGE_MODEL", _DEFAULT_JUDGE_MODEL)

    def _call(self, prompt: str, model: str, max_tokens: int, temperature: float) -> str:
        try:
            m = self._genai.GenerativeModel(
                model,
                generation_config={"max_output_tokens": max_tokens, "temperature": temperature},
            )
            response = m.generate_content(prompt)
            return response.text.strip()
        except Exception as exc:
            return f"[LLM ERROR] {exc}"

    def complete(self, prompt: str, max_tokens: int = 512, temperature: float = 0.7) -> str:
        return self._call(prompt, self._chat_model, max_tokens, temperature)

    def complete_judge(self, prompt: str) -> str:
        return self._call(prompt, self._judge_model, max_tokens=2048, temperature=0.0)


class GeminiEmbeddingProvider(EmbeddingProvider):
    """
    Required env vars:
      GEMINI_API_KEY
      GEMINI_EMBED_MODEL  (default: models/text-embedding-004)
    """

    def __init__(self) -> None:
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise EnvironmentError("GEMINI_API_KEY is not set.")
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        self._genai = genai
        self._model = os.getenv("GEMINI_EMBED_MODEL", _DEFAULT_EMBED_MODEL)

    @property
    def dimensions(self) -> int:
        return _EMBED_DIM

    def embed(self, text: str) -> np.ndarray:
        result = self._genai.embed_content(model=self._model, content=text.strip())
        return np.array(result["embedding"], dtype="float32")
