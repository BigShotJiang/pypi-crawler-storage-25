"""
Provider abstraction for Contexara.

Set CONTEXARA_PROVIDER in your .env to one of:
  bedrock    — AWS Bedrock (default)
  openai     — OpenAI
  anthropic  — Anthropic API + Voyage AI embeddings
  gemini     — Google Gemini
  openrouter — OpenRouter (any LLM) + configurable embeddings
"""
from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base import LLMProvider, EmbeddingProvider


def get_provider() -> str:
    return os.getenv("CONTEXARA_PROVIDER", "bedrock").lower().strip()


def get_llm_provider() -> "LLMProvider":
    p = get_provider()
    if p == "bedrock":
        from .bedrock import BedrockLLMProvider
        return BedrockLLMProvider()
    if p == "openai":
        from .openai import OpenAILLMProvider
        return OpenAILLMProvider()
    if p == "anthropic":
        from .anthropic import AnthropicLLMProvider
        return AnthropicLLMProvider()
    if p == "gemini":
        from .gemini import GeminiLLMProvider
        return GeminiLLMProvider()
    if p == "openrouter":
        from .openrouter import OpenRouterLLMProvider
        return OpenRouterLLMProvider()
    raise ValueError(f"Unknown CONTEXARA_PROVIDER: '{p}'. Choose: bedrock, openai, anthropic, gemini, openrouter")


def get_embedding_provider() -> "EmbeddingProvider":
    p = get_provider()
    if p == "bedrock":
        from .bedrock import BedrockEmbeddingProvider
        return BedrockEmbeddingProvider()
    if p == "openai":
        from .openai import OpenAIEmbeddingProvider
        return OpenAIEmbeddingProvider()
    if p == "anthropic":
        from .voyage import VoyageEmbeddingProvider
        return VoyageEmbeddingProvider()
    if p == "gemini":
        from .gemini import GeminiEmbeddingProvider
        return GeminiEmbeddingProvider()
    if p == "openrouter":
        from .openrouter import OpenRouterEmbeddingProvider
        return OpenRouterEmbeddingProvider()
    raise ValueError(f"Unknown CONTEXARA_PROVIDER: '{p}'. Choose: bedrock, openai, anthropic, gemini, openrouter")
