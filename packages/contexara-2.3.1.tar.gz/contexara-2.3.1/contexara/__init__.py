"""Contexara public package API."""

from .client import ContextaraClient
from .enhance import enhance
from .ingest import ingest_turn
from .main import ask
from .retrieve import retrieve
from .store import clear_all, compress_old_memories, consolidate, delete_memory, get_stats, list_all, search_memories, store

__all__ = [
    "ContextaraClient",
    "ask", "store", "list_all", "clear_all", "delete_memory", "search_memories",
    "get_stats", "consolidate", "compress_old_memories", "retrieve", "enhance", "ingest_turn",
]

__version__ = "2.3.1"
