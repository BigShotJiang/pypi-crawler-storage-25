"""
Cold archive sweep — Phase 6.

Moves raw_turns older than 30 days from active_state.db to cold_archive.db.
cold_archive.db uses FTS5 for fast full-text search across years of history.

Triggered by the crystallization worker (background, once every 7 days).
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

_ACTIVE_DB = Path.home() / ".contexara" / "active_state.db"
_COLD_DB = Path.home() / ".contexara" / "cold_archive.db"
_SWEEP_INTERVAL_DAYS = 7
_ARCHIVE_AFTER_DAYS = 30


# ── Cold DB bootstrap ─────────────────────────────────────────────────────────

def initialize_cold_db() -> None:
    """Create cold_archive.db schema with FTS5 virtual table."""
    _COLD_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(_COLD_DB)
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS historical_turns (
        id                INTEGER PRIMARY KEY AUTOINCREMENT,
        original_id       INTEGER,
        session_id        TEXT NOT NULL,
        namespace         TEXT NOT NULL DEFAULT 'default',

        -- message core
        role              TEXT NOT NULL,
        content           TEXT NOT NULL,

        -- temporal metadata (carried from raw_turns)
        created_at        TEXT NOT NULL,
        archived_at       TEXT NOT NULL,
        date              TEXT,
        time_of_day       TEXT,
        day_of_week       TEXT,
        hour_of_day       INTEGER,
        week_number       INTEGER,
        is_weekend        INTEGER DEFAULT 0,

        -- conversation structure (carried from raw_turns)
        turn_number       INTEGER,
        word_count        INTEGER,
        char_count        INTEGER,
        is_question       INTEGER DEFAULT 0,
        has_code          INTEGER DEFAULT 0,
        prev_turn_id      INTEGER
    )
    """)
    # Migrate existing cold DBs — add any missing columns
    cursor.execute("PRAGMA table_info(historical_turns)")
    existing_cols = {r[1] for r in cursor.fetchall()}
    _new_hist_cols = [
        ("namespace",    "TEXT NOT NULL DEFAULT 'default'"),
        ("date",         "TEXT"),
        ("time_of_day",  "TEXT"),
        ("day_of_week",  "TEXT"),
        ("hour_of_day",  "INTEGER"),
        ("week_number",  "INTEGER"),
        ("is_weekend",   "INTEGER DEFAULT 0"),
        ("turn_number",  "INTEGER"),
        ("word_count",   "INTEGER"),
        ("char_count",   "INTEGER"),
        ("is_question",  "INTEGER DEFAULT 0"),
        ("has_code",     "INTEGER DEFAULT 0"),
        ("prev_turn_id", "INTEGER"),
    ]
    for col, col_type in _new_hist_cols:
        if col not in existing_cols:
            cursor.execute(f"ALTER TABLE historical_turns ADD COLUMN {col} {col_type}")

    cursor.execute("CREATE INDEX IF NOT EXISTS idx_hist_session ON historical_turns(session_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_hist_created ON historical_turns(created_at)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_hist_ns      ON historical_turns(namespace)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_hist_date    ON historical_turns(date)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_hist_dow     ON historical_turns(day_of_week)")

    cursor.execute("""
    CREATE VIRTUAL TABLE IF NOT EXISTS historical_turns_fts
    USING fts5(
        content,
        role,
        day_of_week UNINDEXED,
        date        UNINDEXED,
        session_id  UNINDEXED,
        namespace   UNINDEXED,
        content='historical_turns',
        content_rowid='id'
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sweep_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        swept_at TEXT NOT NULL,
        rows_moved INTEGER NOT NULL
    )
    """)

    conn.commit()
    conn.close()


# ── Sweep logic ───────────────────────────────────────────────────────────────

def is_sweep_due() -> bool:
    """Return True if no sweep has run in the last 7 days."""
    if not _COLD_DB.exists():
        return True
    conn = sqlite3.connect(_COLD_DB)
    row = conn.execute(
        "SELECT swept_at FROM sweep_log ORDER BY swept_at DESC LIMIT 1"
    ).fetchone()
    conn.close()
    if not row:
        return True
    last_sweep = datetime.fromisoformat(row[0])
    if last_sweep.tzinfo is None:
        last_sweep = last_sweep.replace(tzinfo=timezone.utc)
    days_since = (datetime.now(timezone.utc) - last_sweep).days
    return days_since >= _SWEEP_INTERVAL_DAYS


def run_sweep(force: bool = False) -> int:
    """
    Move raw_turns older than 30 days from active_state.db to cold_archive.db.
    Returns number of rows moved. Skips if sweep not due (unless force=True).
    """
    if not force and not is_sweep_due():
        return 0

    initialize_cold_db()

    cutoff = (datetime.now(timezone.utc) - timedelta(days=_ARCHIVE_AFTER_DAYS)).isoformat()
    now = datetime.now(timezone.utc).isoformat()

    active_conn = sqlite3.connect(_ACTIVE_DB)
    active_conn.row_factory = sqlite3.Row

    rows = active_conn.execute(
        """
        SELECT id, session_id, namespace, role, content, created_at,
               date, time_of_day, day_of_week, hour_of_day, week_number, is_weekend,
               turn_number, word_count, char_count, is_question, has_code, prev_turn_id
        FROM raw_turns WHERE created_at < ?
        """,
        (cutoff,),
    ).fetchall()

    if not rows:
        active_conn.close()
        _log_sweep(0, now)
        return 0

    cold_conn = sqlite3.connect(_COLD_DB)

    try:
        cold_conn.execute("BEGIN")
        active_conn.execute("BEGIN")

        for row in rows:
            cold_conn.execute(
                """
                INSERT INTO historical_turns (
                    original_id, session_id, namespace, role, content,
                    created_at, archived_at,
                    date, time_of_day, day_of_week, hour_of_day, week_number, is_weekend,
                    turn_number, word_count, char_count, is_question, has_code, prev_turn_id
                ) VALUES (
                    ?, ?, ?, ?, ?,
                    ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?
                )
                """,
                (
                    row["id"], row["session_id"], row["namespace"], row["role"], row["content"],
                    row["created_at"], now,
                    row["date"], row["time_of_day"], row["day_of_week"], row["hour_of_day"],
                    row["week_number"], row["is_weekend"],
                    row["turn_number"], row["word_count"], row["char_count"],
                    row["is_question"], row["has_code"], row["prev_turn_id"],
                ),
            )

        cold_conn.execute("INSERT INTO historical_turns_fts(historical_turns_fts) VALUES('rebuild')")

        ids = [row["id"] for row in rows]
        active_conn.execute(
            "DELETE FROM raw_turns WHERE id IN ({})".format(",".join("?" * len(ids))),
            ids,
        )

        cold_conn.execute("COMMIT")
        active_conn.execute("COMMIT")

    except Exception:
        cold_conn.execute("ROLLBACK")
        active_conn.execute("ROLLBACK")
        cold_conn.close()
        active_conn.close()
        raise

    cold_conn.close()
    active_conn.close()

    _log_sweep(len(rows), now)
    return len(rows)


def _log_sweep(rows_moved: int, now: str) -> None:
    cold_conn = sqlite3.connect(_COLD_DB)
    cold_conn.execute(
        "INSERT INTO sweep_log (swept_at, rows_moved) VALUES (?, ?)",
        (now, rows_moved),
    )
    cold_conn.commit()
    cold_conn.close()


# ── FTS5 search ───────────────────────────────────────────────────────────────

def search_cold_archive(query: str, limit: int = 10, namespace: str = "default") -> list[dict]:
    """
    Full-text search across cold_archive.db using FTS5, scoped to namespace.
    Returns list of matching turns with metadata.
    """
    if not _COLD_DB.exists():
        return []

    conn = sqlite3.connect(_COLD_DB)
    conn.row_factory = sqlite3.Row

    try:
        rows = conn.execute(
            """
            SELECT h.session_id, h.role, h.content, h.created_at, h.namespace
            FROM historical_turns_fts f
            JOIN historical_turns h ON h.id = f.rowid
            WHERE historical_turns_fts MATCH ? AND h.namespace = ?
            ORDER BY rank
            LIMIT ?
            """,
            (query, namespace, limit),
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()
