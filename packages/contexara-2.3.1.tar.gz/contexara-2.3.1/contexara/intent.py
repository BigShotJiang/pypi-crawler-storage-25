"""
Query intent classification for adaptive retrieval.

Funnel (cheapest first):
  1. Heuristic hard override  — keyword match → instant, no LLM
  2. LRU+TTL cache            — seen this pattern recently → reuse
  3. Confidence check         — score + gap signal → skip LLM if clear
  4. Haiku classification     — only when retrieval is genuinely ambiguous

Intent values:
  "historical"  — user wants earliest matching fact
  "recent"      — user wants latest / current state
  "semantic"    — pure relevance, no time bias (default)

Trigger reasons (logged to telemetry):
  "heuristic"   — matched a keyword pattern, hard override
  "cache"       — reused a cached high-confidence classification
  "confident"   — two-signal confidence passed, defaulted to semantic
  "low_score"   — top result score too weak, called LLM
  "low_gap"     — gap between #1 and #2 too small, called LLM
"""
from __future__ import annotations

import re
import time
from collections import OrderedDict
from typing import Literal

IntentType = Literal["historical", "recent", "semantic"]

# ── Heuristic patterns (hard overrides — no LLM needed) ──────────────────────

_HISTORICAL_PATTERNS = re.compile(
    r"\b("
    r"first|earliest|originally|initially|at first|"
    r"day\s*1|day\s*one|when did i|when i (first|started|began|said|mentioned|told)|"
    r"what was the first|what did i (first|originally|initially)|"
    r"how did (this|it) start|from the beginning|"
    r"the original|my initial|the very first|back when|"
    r"early on|at the start|from day one"
    r")\b",
    re.IGNORECASE,
)

_RECENT_PATTERNS = re.compile(
    r"\b("
    r"latest|current|now|currently|recent|recently|"
    r"last (update|change|time|decision|message|thing)|"
    r"most recent|right now|at this point|as of|"
    r"what (is|are) my (current|latest)|today|"
    r"just (now|said|mentioned|told)"
    r")\b",
    re.IGNORECASE,
)

# ── LRU cache with TTL ────────────────────────────────────────────────────────

_CACHE_MAX_SIZE = 2048
_CACHE_TTL_SECONDS = 7200  # 2 hours

# OrderedDict as LRU: key → (intent, timestamp, trigger_reason)
_intent_cache: OrderedDict[str, tuple[IntentType, float, str]] = OrderedDict()


def _cache_key(query: str) -> str:
    return re.sub(r"\s+", " ", query.strip().lower())


def _cache_get(query: str) -> tuple[IntentType, str] | None:
    key = _cache_key(query)
    entry = _intent_cache.get(key)
    if entry is None:
        return None
    intent, ts, reason = entry
    if time.monotonic() - ts > _CACHE_TTL_SECONDS:
        del _intent_cache[key]
        return None
    _intent_cache.move_to_end(key)
    return intent, "cache"


def _cache_set(query: str, intent: IntentType, reason: str) -> None:
    key = _cache_key(query)
    _intent_cache[key] = (intent, time.monotonic(), reason)
    _intent_cache.move_to_end(key)
    if len(_intent_cache) > _CACHE_MAX_SIZE:
        _intent_cache.popitem(last=False)


# ── Confidence signals ────────────────────────────────────────────────────────

# Single threshold — no dead zone. LLM fires whenever _is_confident() is False.
_CONFIDENT_SCORE_THRESHOLD = 0.55   # top result must clear this
_CONFIDENT_GAP_THRESHOLD = 0.05     # gap between #1 and #2 must exceed this


def _confidence_check(scored: list[tuple[float, str]]) -> tuple[bool, str]:
    """
    Two-signal confidence check.
    Returns (is_confident, trigger_reason).
    trigger_reason explains WHY confidence failed, for telemetry.
    """
    if not scored:
        return False, "low_score"
    top_score = scored[0][0]
    if top_score < _CONFIDENT_SCORE_THRESHOLD:
        return False, "low_score"
    if len(scored) < 2:
        return True, "confident"
    gap = top_score - scored[1][0]
    if gap < _CONFIDENT_GAP_THRESHOLD:
        return False, "low_gap"
    return True, "confident"


# ── Haiku LLM classification ──────────────────────────────────────────────────

_CLASSIFICATION_PROMPT = """\
Classify the temporal intent of this user query for a memory retrieval system.
Reply with exactly one word: historical, recent, or semantic.

- historical: user wants the earliest/first/original version of something
- recent: user wants the latest/current/most recent state
- semantic: user wants the most relevant match regardless of time

Query: {query}

Intent:"""


def _classify_with_llm(query: str) -> IntentType:
    try:
        from .llm import call_llm_judge
        raw = call_llm_judge(_CLASSIFICATION_PROMPT.format(query=query)).strip().lower()
        if "historical" in raw:
            return "historical"
        if "recent" in raw:
            return "recent"
        return "semantic"
    except Exception:
        return "semantic"


# ── Public entry point ────────────────────────────────────────────────────────

def classify_intent(
    query: str,
    scored_results: list[tuple[float, str]] | None = None,
) -> tuple[IntentType, str]:
    """
    Classify query intent using the cheapest available signal.

    Returns (intent, trigger_reason) where trigger_reason is one of:
        "heuristic"  — hard override from keyword pattern
        "cache"      — reused a cached classification
        "confident"  — two-signal confidence passed, no LLM needed
        "low_score"  — top result score too weak, called LLM
        "low_gap"    — gap between #1 and #2 too small, called LLM
    """
    # 1. Heuristic hard override
    if _HISTORICAL_PATTERNS.search(query):
        return "historical", "heuristic"
    if _RECENT_PATTERNS.search(query):
        return "recent", "heuristic"

    # 2. Cache lookup
    cached = _cache_get(query)
    if cached is not None:
        return cached

    # 3. Two-signal confidence check — unified, no dead zone
    if scored_results is not None:
        is_confident, trigger_reason = _confidence_check(scored_results)
        if is_confident:
            return "semantic", "confident"
    else:
        trigger_reason = "low_score"

    # 4. LLM classification — only fires when confidence check failed
    intent = _classify_with_llm(query)

    # Cache only high-confidence non-default results to avoid poisoning
    if intent in ("historical", "recent"):
        _cache_set(query, intent, trigger_reason)

    return intent, trigger_reason
