from __future__ import annotations

import time as _time

from .extract import extract_memories, should_extract
from .retrieve import retrieve
from .store import upsert_memory
from .telemetry import record_trace

_EXISTING_MEMORY_CONTEXT_K = 20
_EXTRACTION_BATCH_SIZE = 10  # extract once every N turns (user + assistant combined)


def _get_session_turn_count(session_id: str) -> int:
    """Return total number of turns saved for this session so far."""
    try:
        from .session import _get_connection
        conn = _get_connection()
        row = conn.execute(
            "SELECT COUNT(*) FROM raw_turns WHERE session_id = ?", (session_id,)
        ).fetchone()
        conn.close()
        return row[0] if row else 0
    except Exception:
        return 0


def _get_session_batch_turns(session_id: str, n: int) -> list[dict]:
    """Return the last N raw turns for this session, oldest first."""
    try:
        from .session import _get_connection
        conn = _get_connection()
        rows = conn.execute(
            """
            SELECT role, content FROM raw_turns
            WHERE session_id = ?
            ORDER BY turn_number DESC LIMIT ?
            """,
            (session_id, n),
        ).fetchall()
        conn.close()
        return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]
    except Exception:
        return []


def flush_extraction(session_id: str, namespace: str = "default") -> dict[str, int]:
    """
    Extract memories from any unprocessed turns since the last batch boundary.
    Call this on session exit to ensure turns 1-9 (or N%10 remainder) are not lost.
    No-op if turn count is exactly at a batch boundary (already extracted).
    """
    stats = {"extracted": 0, "inserted": 0, "updated": 0, "skipped": 0}

    turn_count = _get_session_turn_count(session_id)
    remainder = turn_count % _EXTRACTION_BATCH_SIZE
    if remainder == 0:
        return stats  # last batch already processed, nothing to flush

    batch_turns = _get_session_batch_turns(session_id, remainder)
    if not batch_turns:
        return stats

    batch_text = "\n".join(f"{t['role'].upper()}: {t['content']}" for t in batch_turns)
    existing = retrieve(batch_turns[-1]["content"] if batch_turns else "", top_k=_EXISTING_MEMORY_CONTEXT_K, namespace=namespace)

    candidates = extract_memories(
        user_text=batch_text,
        assistant_text="",
        existing_memories=existing,
    )
    stats["extracted"] = len(candidates)

    for memory in candidates:
        try:
            action = upsert_memory(
                content=memory["content"],
                kind=memory["kind"],
                importance=memory["importance"],
                ttl_days=memory.get("ttl_days"),
                namespace=namespace,
            )
            stats[action] += 1
        except Exception:
            stats["skipped"] += 1

    return stats


def ingest_turn(
    user_text: str,
    assistant_text: str,
    session_id: str | None = None,
    namespace: str = "default",
) -> dict[str, int]:
    """
    Ingest one conversation turn:
    1. Save raw turns to Tier 1 (raw_turns) if session_id provided.
    2. Every _EXTRACTION_BATCH_SIZE turns, extract semantic memories from the
       full batch — not just the current turn — for higher quality and lower cost.

    Returns ingestion stats.
    """
    _t0 = _time.perf_counter()
    stats = {
        "extracted": 0,
        "inserted": 0,
        "updated": 0,
        "skipped": 0,
    }

    _BAD_RESPONSE_PREFIXES = ("[LLM ERROR]", "I don't have records", "I don't have information")

    # Tier 1: always save raw turns if we have a session
    if session_id:
        try:
            from .session import save_turn
            if user_text and user_text.strip():
                save_turn(session_id, "user", user_text, namespace=namespace)
            if assistant_text and assistant_text.strip():
                save_turn(session_id, "assistant", assistant_text, namespace=namespace)
        except Exception:
            pass

    # Tier 3: skip extraction if assistant response is a known failure
    if assistant_text and any(assistant_text.strip().startswith(p) for p in _BAD_RESPONSE_PREFIXES):
        return stats

    # Tier 3: batch extraction — fire every _EXTRACTION_BATCH_SIZE turns
    if session_id:
        turn_count = _get_session_turn_count(session_id)
        should_run_batch = (turn_count > 0 and turn_count % _EXTRACTION_BATCH_SIZE == 0)
    else:
        # No session — fall back to per-turn extraction if high signal
        should_run_batch = should_extract(user_text) or should_extract(assistant_text)

    if not should_run_batch:
        return stats

    # Build batch text — last N turns if session, otherwise just current turn
    if session_id:
        batch_turns = _get_session_batch_turns(session_id, _EXTRACTION_BATCH_SIZE)
        if batch_turns:
            batch_user = "\n".join(
                f"{t['role'].upper()}: {t['content']}" for t in batch_turns
            )
            batch_assistant = ""  # all turns already included in batch_user
        else:
            batch_user = user_text
            batch_assistant = assistant_text
    else:
        batch_user = user_text
        batch_assistant = assistant_text

    existing = retrieve(user_text, top_k=_EXISTING_MEMORY_CONTEXT_K, namespace=namespace)
    candidates = extract_memories(
        user_text=batch_user,
        assistant_text=batch_assistant,
        existing_memories=existing,
    )
    stats["extracted"] = len(candidates)

    for memory in candidates:
        try:
            action = upsert_memory(
                content=memory["content"],
                kind=memory["kind"],
                importance=memory["importance"],
                ttl_days=memory.get("ttl_days"),
                namespace=namespace,
            )
            stats[action] += 1
        except Exception:
            stats["skipped"] += 1

    record_trace(
        "ingest",
        namespace=namespace,
        latency_ms=round((_time.perf_counter() - _t0) * 1000, 2),
        session_id=session_id,
        extracted=stats["extracted"],
        inserted=stats["inserted"],
        updated=stats["updated"],
        skipped=stats["skipped"],
    )
    return stats
