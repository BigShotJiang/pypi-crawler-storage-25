from __future__ import annotations

import time

from .retrieve import retrieve, retrieve_episodes
from .enhance import enhance
from .ingest import ingest_turn
from .llm import call_llm


def ask(query: str, namespace: str = "default") -> str:
    """Main entry point for Contexara — full three-tier context injection."""
    if not query or not query.strip():
        raise ValueError("Query cannot be empty")

    from rich.console import Console
    console = Console()

    session_id = None
    recent_turns = None
    episode_anchor = None
    is_new_session = False

    try:
        from .session import get_recent_turns, retry_pending_sessions
        retry_pending_sessions()
        session_id, is_new_session, episode_anchor = _get_session_with_flag()
        recent_turns = get_recent_turns(session_id) if session_id else None
    except Exception:
        pass

    t0 = time.monotonic()
    with console.status("[cyan]Thinking…[/cyan]", spinner="dots"):
        memories = retrieve(query, namespace=namespace)
        episode_hits = []
        try:
            episode_hits = retrieve_episodes(query, namespace=namespace)
        except Exception:
            pass
        prompt = enhance(query, memories, recent_turns=recent_turns, episode_anchor=episode_anchor, episode_hits=episode_hits)
        response = call_llm(prompt)
    latency_ms = (time.monotonic() - t0) * 1000

    try:
        ingest_turn(query, response, session_id=session_id)
    except Exception:
        pass

    try:
        import json
        from .telemetry import record_trace
        record_trace(
            op="ask",
            namespace=namespace,
            latency_ms=latency_ms,
            status="ok" if not response.startswith("[LLM ERROR]") else "error",
            query_text=query,
            retrieved_memories=json.dumps(memories),
        )
    except Exception:
        pass

    return response


def ask_plain(query: str, namespace: str = "default") -> str:
    """ask() without rich output — for programmatic / SDK use."""
    if not query or not query.strip():
        raise ValueError("Query cannot be empty")

    session_id = None
    recent_turns = None
    episode_anchor = None
    is_new_session = False

    try:
        from .session import get_recent_turns, retry_pending_sessions
        retry_pending_sessions()
        session_id, is_new_session, episode_anchor = _get_session_with_flag()
        recent_turns = get_recent_turns(session_id) if session_id else None
    except Exception:
        pass

    memories = retrieve(query, namespace=namespace)
    episode_hits = []
    try:
        episode_hits = retrieve_episodes(query, namespace=namespace)
    except Exception:
        pass
    prompt = enhance(query, memories, recent_turns=recent_turns, episode_anchor=episode_anchor, episode_hits=episode_hits)
    response = call_llm(prompt)

    try:
        ingest_turn(query, response, session_id=session_id, namespace=namespace)
    except Exception:
        pass

    return response


def _get_session_with_flag() -> tuple[str, bool, str | None]:
    """
    Returns (session_id, is_new_session, episode_summary).
    is_new_session=True and episode_summary is set when a new session was started.
    """
    from .session import get_or_create_session

    session_id, episode_summary = get_or_create_session()
    is_new_session = episode_summary is not None or _is_first_session(session_id)
    return session_id, is_new_session, episode_summary


def _is_first_session(session_id: str) -> bool:
    """True if this session has no turns yet (brand new)."""
    from .session import _get_connection
    conn = _get_connection()
    row = conn.execute(
        "SELECT COUNT(*) FROM raw_turns WHERE session_id = ?", (session_id,)
    ).fetchone()
    conn.close()
    return row[0] == 0
