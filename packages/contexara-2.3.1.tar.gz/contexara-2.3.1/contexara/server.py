"""
Contexara REST API — v1.2.0

Start with: contexara serve --port 8000
Docs at:    http://localhost:8000/docs
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel

app = FastAPI(
    title="Contexara API",
    description="REST API for Contexara memory engine — telemetry, namespaces, memories.",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

api = app  # all routes below use @api.get etc — alias for clarity


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: str


class TraceRow(BaseModel):
    id: int
    op: str
    namespace: str
    latency_ms: float | None
    status: str
    error: str | None
    results_count: int | None
    top_k: int | None
    mean_similarity: float | None
    tiers_hit: str | None
    extracted: int | None
    inserted: int | None
    updated: int | None
    skipped: int | None
    token_input: int | None
    token_output: int | None
    query_text: str | None = None
    retrieved_memories: str | None = None
    eval_score: float | None = None
    eval_label: str | None = None
    eval_at: str | None = None
    turn_count: int | None
    session_id: str | None
    created_at: str


class TracesResponse(BaseModel):
    ok: bool
    traces: list[TraceRow]
    count: int
    total: int
    page: int
    page_size: int


class LatencySummary(BaseModel):
    op: str
    avg_latency_ms: float
    min_latency_ms: float
    max_latency_ms: float
    count: int


class MetricsSummary(BaseModel):
    ok: bool
    total_traces: int
    by_op: dict[str, int]
    avg_latency_by_op: dict[str, float]
    total_token_input: int
    total_token_output: int
    namespaces_active: list[str]


class LatencyResponse(BaseModel):
    ok: bool
    latency: list[LatencySummary]


class NamespaceRow(BaseModel):
    name: str
    created_at: str


class NamespacesResponse(BaseModel):
    ok: bool
    namespaces: list[NamespaceRow]
    count: int


class CreateNamespaceRequest(BaseModel):
    name: str


class CreateNamespaceResponse(BaseModel):
    ok: bool
    name: str


class DeleteNamespaceResponse(BaseModel):
    ok: bool
    name: str
    counts: dict[str, int]


class EvalTrace(BaseModel):
    id: int
    namespace: str
    query_text: str | None
    eval_label: str
    eval_score: float
    created_at: str


class EvalScorePoint(BaseModel):
    date: str
    avg_score: float


class EvalWorstTrace(BaseModel):
    id: int
    query_text: str | None
    eval_label: str
    eval_score: float
    namespace: str
    created_at: str
    snippets: list[str]


class EvalsResponse(BaseModel):
    ok: bool
    total_scored: int
    total_ask: int
    avg_score: float | None
    by_label: dict[str, int]
    recent: list[EvalTrace]
    score_over_time: list[EvalScorePoint]
    worst_traces: list[EvalWorstTrace]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _telemetry_conn():
    from .telemetry import _get_connection, initialize_telemetry_db
    initialize_telemetry_db()
    return _get_connection()


def _session_conn():
    from .session import _get_connection, initialize_session_db
    initialize_session_db()
    return _get_connection()


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/api/health", response_model=HealthResponse, tags=["System"])
def health():
    return HealthResponse(
        status="ok",
        version="2.0.0",
        timestamp=datetime.now(timezone.utc).isoformat(),
    )


@app.get("/api/metrics/summary", response_model=MetricsSummary, tags=["Metrics"])
def metrics_summary(namespace: str | None = Query(None, description="Filter by namespace")):
    conn = _telemetry_conn()
    try:
        where = "WHERE namespace = ?" if namespace else ""
        params: list[Any] = [namespace] if namespace else []

        rows = conn.execute(
            f"SELECT op, namespace, latency_ms, token_input, token_output FROM traces {where}",
            params,
        ).fetchall()
    finally:
        conn.close()

    total = len(rows)
    by_op: dict[str, int] = {}
    latency_sum: dict[str, float] = {}
    latency_count: dict[str, int] = {}
    total_input = 0
    total_output = 0
    namespaces: set[str] = set()

    for r in rows:
        op = r["op"]
        by_op[op] = by_op.get(op, 0) + 1
        if r["latency_ms"] is not None:
            latency_sum[op] = latency_sum.get(op, 0.0) + r["latency_ms"]
            latency_count[op] = latency_count.get(op, 0) + 1
        if r["token_input"]:
            total_input += r["token_input"]
        if r["token_output"]:
            total_output += r["token_output"]
        namespaces.add(r["namespace"])

    avg_latency = {
        op: round(latency_sum[op] / latency_count[op], 2)
        for op in latency_sum
    }

    return MetricsSummary(
        ok=True,
        total_traces=total,
        by_op=by_op,
        avg_latency_by_op=avg_latency,
        total_token_input=total_input,
        total_token_output=total_output,
        namespaces_active=sorted(namespaces),
    )


@app.get("/api/metrics/traces", response_model=TracesResponse, tags=["Metrics"])
def metrics_traces(
    namespace: str | None = Query(None),
    op: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
):
    conn = _telemetry_conn()
    try:
        conditions = []
        params: list[Any] = []
        if namespace:
            conditions.append("namespace = ?")
            params.append(namespace)
        if op:
            conditions.append("op = ?")
            params.append(op)

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        total = conn.execute(f"SELECT COUNT(*) FROM traces {where}", params).fetchone()[0]

        offset = (page - 1) * page_size
        rows = conn.execute(
            f"SELECT * FROM traces {where} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            params + [page_size, offset],
        ).fetchall()
    finally:
        conn.close()

    return TracesResponse(
        ok=True,
        traces=[TraceRow(**dict(r)) for r in rows],
        count=len(rows),
        total=total,
        page=page,
        page_size=page_size,
    )


@app.get("/api/metrics/latency", response_model=LatencyResponse, tags=["Metrics"])
def metrics_latency(namespace: str | None = Query(None)):
    conn = _telemetry_conn()
    try:
        where = "WHERE latency_ms IS NOT NULL AND namespace = ?" if namespace else "WHERE latency_ms IS NOT NULL"
        params: list[Any] = [namespace] if namespace else []
        rows = conn.execute(
            f"""
            SELECT op,
                   AVG(latency_ms) as avg_ms,
                   MIN(latency_ms) as min_ms,
                   MAX(latency_ms) as max_ms,
                   COUNT(*) as count
            FROM traces {where}
            GROUP BY op
            """,
            params,
        ).fetchall()
    finally:
        conn.close()

    return LatencyResponse(
        ok=True,
        latency=[
            LatencySummary(
                op=r["op"],
                avg_latency_ms=round(r["avg_ms"], 2),
                min_latency_ms=round(r["min_ms"], 2),
                max_latency_ms=round(r["max_ms"], 2),
                count=r["count"],
            )
            for r in rows
        ],
    )


@app.get("/api/metrics/evals", response_model=EvalsResponse, tags=["Metrics"])
def metrics_evals(namespace: str | None = Query(None)):
    from .evals import get_eval_summary
    data = get_eval_summary(namespace=namespace)
    return EvalsResponse(
        ok=True,
        total_scored=data["total_scored"],
        total_ask=data["total_ask"],
        avg_score=data["avg_score"],
        by_label=data["by_label"],
        recent=[EvalTrace(**r) for r in data["recent"]],
        score_over_time=[EvalScorePoint(**p) for p in data["score_over_time"]],
        worst_traces=[EvalWorstTrace(**t) for t in data["worst_traces"]],
    )


@app.post("/api/metrics/evals/run", tags=["Metrics"])
def run_evals_endpoint(namespace: str | None = Query(None), limit: int = Query(100)):
    from .evals import run_evals
    result = run_evals(namespace=namespace, limit=limit)
    return {"ok": True, **result}


@app.get("/api/namespaces", response_model=NamespacesResponse, tags=["Namespaces"])
def list_namespaces():
    conn = _session_conn()
    try:
        rows = conn.execute(
            "SELECT name, created_at FROM namespaces ORDER BY created_at ASC"
        ).fetchall()
    finally:
        conn.close()

    return NamespacesResponse(
        ok=True,
        namespaces=[NamespaceRow(name=r["name"], created_at=r["created_at"]) for r in rows],
        count=len(rows),
    )


@app.post("/api/namespaces", response_model=CreateNamespaceResponse, status_code=201, tags=["Namespaces"])
def create_namespace(body: CreateNamespaceRequest):
    from .session import create_namespace as _create
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Namespace name cannot be empty.")
    try:
        _create(name)
    except Exception as e:
        raise HTTPException(status_code=409, detail=str(e))
    return CreateNamespaceResponse(ok=True, name=name)


@app.delete("/api/namespaces/{name}", response_model=DeleteNamespaceResponse, tags=["Namespaces"])
def delete_namespace(name: str):
    from .session import remove_namespace
    if name == "default":
        raise HTTPException(status_code=400, detail="Cannot remove the 'default' namespace.")
    conn = _session_conn()
    try:
        row = conn.execute("SELECT name FROM namespaces WHERE name = ?", (name,)).fetchone()
    finally:
        conn.close()
    if not row:
        raise HTTPException(status_code=404, detail=f"Namespace '{name}' not found.")
    try:
        counts = remove_namespace(name)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return DeleteNamespaceResponse(ok=True, name=name, counts=counts)


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------

def _mount_static() -> None:
    from pathlib import Path
    from fastapi.staticfiles import StaticFiles
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")


# ---------------------------------------------------------------------------
# Server entry point
# ---------------------------------------------------------------------------

def run_server(host: str = "127.0.0.1", port: int = 8000, dashboard: bool = False) -> None:
    import uvicorn
    if dashboard:
        _mount_static()
    uvicorn.run(app, host=host, port=port)
