"""
Contexara Telemetry — v1.1.0 instrumentation layer.

Writes trace records to metrics.db. Every key operation (retrieve, ingest,
ask, crystallize) calls record_trace() with op name, latency, and op-specific
metadata. The DB is append-only from the instrumentation side; reads happen
via the v1.2.0 REST API.
"""
from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_PATH = Path("database/metrics.db")

_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS traces (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    op            TEXT    NOT NULL,
    namespace     TEXT    NOT NULL DEFAULT 'default',
    latency_ms    REAL,
    status        TEXT    NOT NULL DEFAULT 'ok',
    error         TEXT,
    -- retrieve fields
    results_count INTEGER,
    top_k         INTEGER,
    mean_similarity REAL,
    tiers_hit     TEXT,
    -- ingest fields
    extracted     INTEGER,
    inserted      INTEGER,
    updated       INTEGER,
    skipped       INTEGER,
    -- ask fields
    token_input   INTEGER,
    token_output  INTEGER,
    query_text    TEXT,
    retrieved_memories TEXT,
    -- eval fields
    eval_score    REAL,
    eval_label    TEXT,
    eval_at       TEXT,
    -- crystallize fields
    turn_count    INTEGER,
    session_id    TEXT,
    created_at    TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_traces_op        ON traces (op);
CREATE INDEX IF NOT EXISTS idx_traces_namespace ON traces (namespace);
CREATE INDEX IF NOT EXISTS idx_traces_created   ON traces (created_at);
"""


def _get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


_MIGRATE_SQL = """
ALTER TABLE traces ADD COLUMN query_text TEXT;
ALTER TABLE traces ADD COLUMN retrieved_memories TEXT;
ALTER TABLE traces ADD COLUMN eval_score REAL;
ALTER TABLE traces ADD COLUMN eval_label TEXT;
ALTER TABLE traces ADD COLUMN eval_at TEXT;
"""

_MIGRATE_COLUMNS = ["query_text", "retrieved_memories", "eval_score", "eval_label", "eval_at"]


def initialize_telemetry_db() -> None:
    conn = _get_connection()
    conn.executescript(_CREATE_SQL)
    # Migrate existing DBs that predate eval columns
    existing = {row[1] for row in conn.execute("PRAGMA table_info(traces)").fetchall()}
    for col in _MIGRATE_COLUMNS:
        if col not in existing:
            try:
                conn.execute(f"ALTER TABLE traces ADD COLUMN {col} {'REAL' if col == 'eval_score' else 'TEXT'}")
            except Exception:
                pass
    conn.commit()
    conn.close()


def write_eval(trace_id: int, score: float, label: str) -> None:
    """Write eval result back to an existing trace row. Never raises."""
    try:
        conn = _get_connection()
        conn.execute(
            "UPDATE traces SET eval_score = ?, eval_label = ?, eval_at = ? WHERE id = ?",
            (score, label, datetime.now(timezone.utc).isoformat(), trace_id),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def record_trace(
    op: str,
    namespace: str = "default",
    latency_ms: float | None = None,
    status: str = "ok",
    error: str | None = None,
    **kwargs: Any,
) -> None:
    """Write one trace row. Never raises — telemetry must not break the caller."""
    try:
        initialize_telemetry_db()
        conn = _get_connection()
        fields = ["op", "namespace", "latency_ms", "status", "error", "created_at"]
        values: list[Any] = [
            op,
            namespace,
            latency_ms,
            status,
            error,
            datetime.now(timezone.utc).isoformat(),
        ]
        allowed = {
            "results_count", "top_k", "mean_similarity", "tiers_hit",
            "extracted", "inserted", "updated", "skipped",
            "token_input", "token_output", "query_text", "retrieved_memories",
            "eval_score", "eval_label", "eval_at",
            "turn_count", "session_id",
        }
        for k, v in kwargs.items():
            if k in allowed:
                fields.append(k)
                values.append(v)

        placeholders = ", ".join("?" * len(values))
        col_list = ", ".join(fields)
        conn.execute(f"INSERT INTO traces ({col_list}) VALUES ({placeholders})", values)
        conn.commit()
        conn.close()
    except Exception:
        pass


@contextmanager
def _timed():
    """Context manager that yields a dict; caller populates it, we fill elapsed_ms."""
    ctx: dict[str, Any] = {}
    t0 = time.perf_counter()
    try:
        yield ctx
    finally:
        ctx["elapsed_ms"] = round((time.perf_counter() - t0) * 1000, 2)
