"""
ContextaraClient — the primary SDK interface for Python applications.

Usage:
    from contexara import ContextaraClient

    mem = ContextaraClient(namespace="my-agent")

    # At the start of every turn
    context = mem.context()          # recent turns + episode anchor if new session

    # After generating a response
    mem.ingest(user_text, assistant_text)

    # Store a fact explicitly
    mem.store("User prefers bullet-point responses")

    # Search memory before answering
    results = mem.retrieve("what does the user prefer?")
"""
from __future__ import annotations

from typing import Any


class ContextaraClient:
    """
    Namespace-scoped Contexara memory client.

    All operations are scoped to the namespace passed at construction.
    Session lifecycle (detection, episode injection) is managed automatically.

    Args:
        namespace: Logical partition for memory isolation. Use one namespace
                   per agent, application, or user. Default: "default".
    """

    def __init__(self, namespace: str = "default") -> None:
        if not namespace or not namespace.strip():
            raise ValueError("namespace cannot be empty")
        self.namespace = namespace.strip()
        self._session_id: str | None = None
        self._episode_summary: str | None = None

    # ── Session ──────────────────────────────────────────────────────────────

    def _ensure_session(self) -> str:
        """Return active session_id, refreshing if needed. Auto-surfaces episode on new session."""
        from .session import get_or_create_session
        session_id, episode_summary = get_or_create_session(self.namespace)
        self._session_id = session_id
        # Only keep episode_summary for the first call of a new session
        if episode_summary is not None:
            self._episode_summary = episode_summary
        return session_id

    def checkpoint(self) -> dict[str, Any]:
        """
        Immediately crystallize the current session into a durable episode summary.
        Call at the end of a major task or conversation arc.
        Returns {"crystallized": bool, "session_id": str}.
        """
        from .session import _get_connection, initialize_session_db
        from ._crystallize import _crystallize

        initialize_session_db()
        conn = _get_connection()
        row = conn.execute(
            "SELECT session_id FROM active_sessions WHERE status = 'open' AND namespace = ? ORDER BY last_action_at DESC LIMIT 1",
            (self.namespace,),
        ).fetchone()
        conn.close()

        if not row:
            return {"crystallized": False, "reason": "No open session found."}

        sid = row["session_id"]
        _crystallize(sid)
        return {"crystallized": True, "session_id": sid}

    # ── Core API ─────────────────────────────────────────────────────────────

    def context(self, n: int = 10) -> dict[str, Any]:
        """
        Get context for the start of a turn.

        Returns:
            {
                "session_id": str,
                "turns": list[dict],          # last N raw turns this session
                "episode_summary": str | None  # last episode, only on new session start
            }

        Call this at the beginning of every session/turn so the agent is never
        blind to recent conversation history.
        """
        from .session import get_recent_turns

        session_id = self._ensure_session()
        turns = get_recent_turns(session_id, n=min(n, 50))

        # Consume episode_summary — only returned once per new session
        episode = self._episode_summary
        self._episode_summary = None

        return {
            "session_id": session_id,
            "turns": turns,
            "episode_summary": episode,
        }

    def ingest(self, user_text: str, assistant_text: str) -> dict[str, int]:
        """
        Ingest one conversation turn — saves to L0 (raw turns) and extracts
        long-term memories to L2 (semantic store).

        Call after every response. Returns ingestion stats:
        {"extracted": N, "inserted": N, "updated": N, "skipped": N}
        """
        from .ingest import ingest_turn

        session_id = self._ensure_session()
        return ingest_turn(user_text, assistant_text, session_id=session_id, namespace=self.namespace)

    def retrieve(self, query: str, top_k: int = 5) -> list[str]:
        """
        Hybrid search over memory scoped to this namespace.
        Searches L2 (semantic store) + L0 hot turns (FTS5+cosine) + cold archive (FTS5).

        Returns ranked list of memory strings, most relevant first.
        """
        from .retrieve import retrieve as _retrieve

        return _retrieve(query, top_k=top_k, namespace=self.namespace)

    def store(
        self,
        content: str,
        kind: str = "note",
        importance: int = 3,
        ttl_days: int | None = None,
    ) -> str:
        """
        Explicitly store a memory fact.

        Args:
            content:    The fact to store.
            kind:       One of: profile, correction, preference, constraint,
                        tech_preference, style, pattern, task, note.
            importance: 1–5. profile/correction=5, preference/constraint=4,
                        style/pattern/task=3, note=1.
            ttl_days:   Days until this memory expires. None = never expires.

        Returns "inserted" or "updated".
        """
        from .store import upsert_memory

        return upsert_memory(
            content=content,
            kind=kind,
            importance=importance,
            ttl_days=ttl_days,
            namespace=self.namespace,
        )

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """
        Semantic search returning full memory records (id, content, kind, importance, created_at).
        Use retrieve() for plain strings; use search() when you need metadata.
        """
        from .store import search_memories

        return search_memories(query, top_k=top_k, namespace=self.namespace)

    def history(self, memory_id: int) -> list[dict]:
        """
        Return the version history of a memory — all previous values before the current one.
        Each entry has: version, content, kind, importance, valid_from, replaced_at.
        """
        from .store import get_memory_history

        return get_memory_history(memory_id)

    def stats(self) -> dict:
        """Return summary statistics about memories in this namespace."""
        from .store import get_stats

        return get_stats(namespace=self.namespace)
