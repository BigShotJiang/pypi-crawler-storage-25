"""
Detached background worker — crystallizes a session into an episode.
Invoked as: python -m contexara._crystallize <session_id>
"""
from __future__ import annotations

import json
import sys
import time as _time


def _crystallize(session_id: str) -> None:
    from .session import (
        _get_connection,
        _utc_now,
        get_recent_turns,
        get_session_time_range,
        initialize_session_db,
    )
    from .llm import call_llm_judge as call_llm
    from .embedder import embed, serialize

    initialize_session_db()
    _t0 = _time.perf_counter()

    # Pull all raw turns for this session
    conn = _get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT role, content, created_at FROM raw_turns WHERE session_id = ? ORDER BY created_at ASC",
        (session_id,),
    )
    turns = cursor.fetchall()
    conn.close()

    if not turns:
        _mark_crystallized(session_id)
        return

    # Build transcript
    transcript = "\n".join(
        f"{row['role'].upper()} [{row['created_at']}]: {row['content']}"
        for row in turns
    )

    summary = _summarize_with_fact_check(transcript, call_llm)

    # Embed the summary
    embed_text = summary_raw if len(summary_raw) < 2000 else summary_raw[:2000]
    try:
        vector = embed(embed_text)
        blob = serialize(vector)
    except Exception:
        blob = None

    # Get session time range
    time_range = get_session_time_range(session_id)
    started_at = time_range[0] if time_range else _utc_now()
    ended_at = time_range[1] if time_range else _utc_now()

    # Store episode
    conn = _get_connection()
    conn.execute(
        """
        INSERT INTO episodes (session_id, summary, started_at, ended_at, embedding, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (session_id, summary, started_at, ended_at, blob, _utc_now()),
    )
    conn.commit()
    conn.close()

    _mark_crystallized(session_id)

    from .session import _get_connection as _sess_conn
    _ns_row = _sess_conn().execute(
        "SELECT namespace FROM active_sessions WHERE session_id = ?", (session_id,)
    ).fetchone()
    _ns = _ns_row["namespace"] if _ns_row else "default"

    from .telemetry import record_trace
    record_trace(
        "crystallize",
        namespace=_ns,
        latency_ms=round((_time.perf_counter() - _t0) * 1000, 2),
        session_id=session_id,
        turn_count=len(turns),
    )
    _run_sweep_if_due()


def _parse_json_response(raw: str) -> dict:
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
    try:
        return json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        return {}


def _summarize_with_fact_check(transcript: str, call_llm) -> str:
    """
    Two-pass zero-fact-loss summarization.

    Pass 1: Generate structured summary (title, actions, outcomes, open_items, facts).
    Pass 2: Verify no facts from the transcript were dropped. If gaps found, regenerate
            with the missing facts list injected as a hard constraint.
    Returns a JSON string.
    """
    _PASS1_PROMPT = """\
You are a memory crystallization engine. Summarize the session transcript below into a structured manifest.

Output a JSON object with exactly these fields:
- "title": one sentence describing the main task (max 10 words)
- "actions": list of concrete things done (max 6 items)
- "outcomes": list of results achieved or decisions made (max 4 items)
- "open_items": list of unresolved tasks or next steps (max 4 items)
- "facts": list of specific named facts that MUST be preserved verbatim — file names, variable names, \
version numbers, numeric values, error messages, URLs, key decisions. Include everything a reader \
would need to resume work without re-reading the transcript.

Rules:
- Factual and technical. No narrative. No "the user said".
- Every item in "facts" must be extractable from the transcript as-is.
- Output ONLY valid JSON. No markdown, no explanation.

Transcript:
{transcript}"""

    _PASS2_VERIFY_PROMPT = """\
You are a fact-loss auditor for a memory crystallization system.

Given the original session transcript and a generated summary, identify any important facts that \
appear in the transcript but are MISSING or ALTERED in the summary.

Important facts include: file names, function names, variable names, version numbers, numeric values, \
error messages, URLs, commands, key decisions, unresolved errors, configuration values.

Output a JSON object with exactly one field:
- "missing_facts": list of missing/altered fact strings (empty list if nothing is missing)

Output ONLY valid JSON. No markdown, no explanation.

Transcript:
{transcript}

Summary:
{summary}"""

    _PASS2_REPAIR_PROMPT = """\
You are a memory crystallization engine. A fact-loss audit found that the summary below is missing \
important facts from the original transcript.

Regenerate the summary incorporating ALL missing facts into the appropriate fields.

Output a JSON object with exactly these fields:
- "title": one sentence describing the main task (max 10 words)
- "actions": list of concrete things done (max 6 items)
- "outcomes": list of results achieved or decisions made (max 4 items)
- "open_items": list of unresolved tasks or next steps (max 4 items)
- "facts": list of specific named facts preserved verbatim (names, values, versions, commands, decisions)

Output ONLY valid JSON. No markdown, no explanation.

Original transcript:
{transcript}

Previous summary (incomplete):
{summary}

Missing facts that MUST appear in the regenerated summary:
{missing}"""

    # ── Pass 1: initial summary ───────────────────────────────────────────────
    raw1 = call_llm(_PASS1_PROMPT.format(transcript=transcript))
    parsed1 = _parse_json_response(raw1)
    if not parsed1:
        return json.dumps({"title": "Session summary", "actions": [raw1[:500]], "outcomes": [], "open_items": [], "facts": []})

    summary1 = json.dumps(parsed1)

    # ── Pass 2: fact-loss audit ───────────────────────────────────────────────
    # Truncate transcript for audit prompt to stay within token budget
    audit_transcript = transcript if len(transcript) < 6000 else transcript[:6000] + "\n[transcript truncated]"
    raw2 = call_llm(_PASS2_VERIFY_PROMPT.format(transcript=audit_transcript, summary=summary1))
    parsed2 = _parse_json_response(raw2)
    missing = parsed2.get("missing_facts", []) if isinstance(parsed2, dict) else []

    if not missing:
        return summary1

    # ── Pass 3 (conditional): repair with missing facts injected ─────────────
    missing_str = "\n".join(f"- {f}" for f in missing)
    raw3 = call_llm(_PASS2_REPAIR_PROMPT.format(
        transcript=audit_transcript,
        summary=summary1,
        missing=missing_str,
    ))
    parsed3 = _parse_json_response(raw3)
    if not parsed3:
        # Repair failed — fall back to pass 1 summary but append missing facts
        parsed1.setdefault("facts", [])
        parsed1["facts"].extend(missing)
        return json.dumps(parsed1)

    return json.dumps(parsed3)


def _run_sweep_if_due() -> None:
    """Run cold archive sweep if 7 days have passed since last sweep."""
    try:
        from .archive import run_sweep
        run_sweep()
    except Exception:
        pass


def _mark_crystallized(session_id: str) -> None:
    from .session import _get_connection, _utc_now
    conn = _get_connection()
    conn.execute(
        "UPDATE active_sessions SET status = 'crystallized', last_action_at = ? WHERE session_id = ?",
        (_utc_now(), session_id),
    )
    conn.commit()
    conn.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(1)
    _crystallize(sys.argv[1])
