from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./warp.db"
    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "info"
    cors_origins: list[str] = []
    max_login_attempts: int = 5
    lockout_duration_minutes: int = 30
    reload: bool = False
    debug: bool = False
    bndb_storage_dir: str = "./bndb_storage"
    # IPs of trusted reverse proxies allowed to set X-Forwarded-For
    trusted_proxies: list[str] = []

    model_config = {"env_prefix": "WARP_"}


settings = Settings()
