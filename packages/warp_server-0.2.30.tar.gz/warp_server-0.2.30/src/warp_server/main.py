import gzip
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from warp_server.config import settings
from warp_server.database import engine
from warp_server.models import Base
from warp_server.routers import (
    auth,
    bndbs,
    commits,
    files,
    functions,
    search,
    sources,
    status,
    symbols,
    targets,
    types,
    users,
)

logger = logging.getLogger("warp_server")


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    Path(settings.bndb_storage_dir).mkdir(parents=True, exist_ok=True)
    yield
    await engine.dispose()


app = FastAPI(
    title="warp-server",
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
    openapi_url="/openapi.json" if settings.debug else None,
)


@app.middleware("http")
async def decompress_gzip_request(request: Request, call_next):
    if request.headers.get("content-encoding") == "gzip":
        body = await request.body()
        try:
            decompressed = gzip.decompress(body)
        except Exception:
            pass
        else:
            scope = request.scope

            # Replace body with decompressed data
            async def receive():
                return {
                    "type": "http.request",
                    "body": decompressed,
                    "more_body": False,
                }

            request = Request(scope, receive)
            # Remove content-encoding so downstream doesn't re-process
            if "content-encoding" in request.headers.keys():
                raw_headers = [
                    (k, v) for k, v in scope["headers"] if k != b"content-encoding"
                ]
                scope["headers"] = raw_headers
    return await call_next(request)


@app.middleware("http")
async def log_request_duration(request: Request, call_next):
    start = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "%s %s → %d (%.1f ms)",
        request.method,
        request.url.path,
        response.status_code,
        elapsed_ms,
    )
    return response


app.include_router(status.router)
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(sources.router)
app.include_router(commits.router)
app.include_router(targets.router)
app.include_router(symbols.router)
app.include_router(functions.router)
app.include_router(files.router)
app.include_router(types.router)
app.include_router(search.router)
app.include_router(bndbs.router)

# -- Static web UI ---------------------------------------------------------
_static_dir = Path(__file__).parent / "static"

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["GET", "POST", "DELETE", "PATCH", "PUT"],
    allow_headers=["Authorization", "Content-Type"],
)

if _static_dir.is_dir():
    app.mount("/web-ui/static", StaticFiles(directory=_static_dir), name="static")

    @app.get("/web-ui", response_class=HTMLResponse)
    async def web_ui():
        return HTMLResponse((_static_dir / "index.html").read_text())


def run():
    logging.basicConfig(
        level=getattr(logging, settings.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    uvicorn.run(
        "warp_server.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.reload,
    )


if __name__ == "__main__":
    run()
