import asyncio
import logging
import re
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path

import click
from sqlalchemy import delete, inspect, select, text, update

from warp_server.auth import hash_api_key
from warp_server.database import async_session, engine
from warp_server.models import (
    ApiKey,
    Base,
    Commit,
    Function,
    FunctionComment,
    FunctionConstraint,
    LoginAttempt,
    Source,
    SourceTag,
    SourceUser,
    Symbol,
    User,
)

logger = logging.getLogger(__name__)


@click.group(name="warp-ctl", help="WARP server management CLI.")
def app():
    pass


@app.group(help="Manage users.")
def user():
    pass


@app.group(help="Manage API keys.")
def key():
    pass


@app.group(help="Manage sources.")
def source():
    pass


def _run(coro):
    return asyncio.run(coro)


async def _ensure_tables():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


# ── Users ────────────────────────────────────────────────────────────


@user.command("create")
@click.option("--email", required=True, help="User email address.")
@click.option(
    "--username", default=None, help="Username (defaults to email local part)."
)
@click.option("--role", default="User", help="Role: User or Admin.")
def user_create(email, username, role):
    """Create a new user."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            name = username or email.split("@")[0]
            u = User(email=email, username=name, role=role)
            db.add(u)
            await db.flush()
            raw_key = secrets.token_urlsafe(32)
            db.add(ApiKey(user_id=u.id, key=hash_api_key(raw_key), name="default"))
            await db.commit()
            await db.refresh(u)
            click.echo(f"Created user id={u.id} username={u.username} role={u.role}")
            click.echo(f"API key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_create())


@user.command("list")
def user_list():
    """List all users."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).order_by(User.id))
            users = result.scalars().all()
            if not users:
                click.echo("No users found.")
                return
            click.echo(
                f"{'ID':<6} {'Username':<20} {'Email':<30} {'Role':<10} {'Locked':<8} {'Created'}"
            )
            click.echo("-" * 88)
            for u in users:
                locked_str = "YES" if u.locked else ""
                click.echo(
                    f"{u.id:<6} {u.username:<20} {u.email:<30} {u.role:<10} {locked_str:<8} {u.created_at}"
                )

    _run(_list())


@user.command("delete")
@click.argument("user_id", type=int)
def user_delete(user_id):
    """Delete a user by ID."""

    async def _delete():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.id == user_id))
            u = result.scalar_one_or_none()
            if u is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)
            await db.delete(u)
            await db.commit()
            click.echo(f"Deleted user id={user_id} username={u.username}")

    _run(_delete())


@user.command("unlock")
@click.argument("user_id", type=int)
def user_unlock(user_id):
    """Unlock a locked user account."""

    async def _unlock():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.id == user_id))
            u = result.scalar_one_or_none()
            if u is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)
            if not u.locked:
                click.echo(f"User {u.username} (id={u.id}) is not locked.")
                return
            u.locked = 0
            u.failed_login_count = 0
            u.locked_at = None
            await db.commit()
            click.echo(f"Unlocked user {u.username} (id={u.id}).")

    _run(_unlock())


# ── API Keys ─────────────────────────────────────────────────────────


@key.command("create")
@click.option(
    "--user-id", default=None, type=int, help="User ID to create the key for."
)
@click.option("--username", default=None, help="Username to create the key for.")
@click.option("--email", default=None, help="Email to create the key for.")
@click.option("--name", default="default", help="Key name/label.")
def key_create(user_id, username, email, name):
    """Create an API key for a user."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            if user_id is not None:
                query = select(User).where(User.id == user_id)
            elif username is not None:
                query = select(User).where(User.username == username)
            elif email is not None:
                query = select(User).where(User.email == email)
            else:
                click.echo(
                    "Provide one of --user-id, --username, or --email.", err=True
                )
                raise SystemExit(1)
            result = await db.execute(query)
            u = result.scalar_one_or_none()
            if u is None:
                click.echo("User not found.", err=True)
                raise SystemExit(1)
            raw_key = secrets.token_urlsafe(32)
            api_key = ApiKey(
                user_id=u.id,
                key=hash_api_key(raw_key),
                name=name,
                created_at=datetime.now(timezone.utc),
            )
            db.add(api_key)
            await db.commit()
            await db.refresh(api_key)
            click.echo(f"Created API key for user={u.username}")
            click.echo(f"Key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_create())


@key.command("list")
@click.option("--user-id", default=None, type=int, help="Filter keys by user ID.")
def key_list(user_id):
    """List API keys."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            query = (
                select(ApiKey, User)
                .join(User, ApiKey.user_id == User.id)
                .order_by(ApiKey.id)
            )
            if user_id is not None:
                query = query.where(ApiKey.user_id == user_id)
            result = await db.execute(query)
            rows = result.all()
            if not rows:
                click.echo("No API keys found.")
                return
            click.echo(
                f"{'ID':<6} {'User ID':<8} {'Username':<20} {'Name':<16} {'Key (prefix)':<14} {'Created':<26} {'Last Used'}"
            )
            click.echo("-" * 100)
            for k, u in rows:
                click.echo(
                    f"{k.id:<6} {k.user_id:<8} {u.username:<20} {k.name:<16} {k.key[:12] + '…':<14} {str(k.created_at):<26} {k.last_used_at or '—'}"
                )

    _run(_list())


@key.command("revoke")
@click.argument("key_id", type=int)
def key_revoke(key_id):
    """Revoke (delete) an API key."""

    async def _revoke():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(ApiKey).where(ApiKey.id == key_id))
            api_key = result.scalar_one_or_none()
            if api_key is None:
                click.echo(f"API key {key_id} not found.", err=True)
                raise SystemExit(1)
            await db.delete(api_key)
            await db.commit()
            click.echo(f"Revoked API key id={key_id}")

    _run(_revoke())


# ── Sources ──────────────────────────────────────────────────────────


@source.command("create")
@click.option("--name", required=True, help="Source name.")
@click.option("--user-id", default=None, type=int, help="User ID to add as owner.")
def source_create(name, user_id):
    """Create a new source."""

    async def _create():
        await _ensure_tables()
        async with async_session() as db:
            src = Source(name=name)
            db.add(src)
            await db.flush()
            if user_id is not None:
                db.add(SourceUser(source_id=src.id, user_id=user_id))
            db.add(SourceTag(source_id=src.id, tag="trusted"))
            await db.commit()
            await db.refresh(src)
            click.echo(f"Created source id={src.id} name={src.name}")

    _run(_create())


@source.command("list")
def source_list():
    """List all sources."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(Source).order_by(Source.name))
            sources = result.scalars().all()
            if not sources:
                click.echo("No sources found.")
                return
            click.echo(f"{'ID':<38} {'Name':<30} {'Created'}")
            click.echo("-" * 80)
            for s in sources:
                click.echo(f"{str(s.id):<38} {s.name:<30} {s.created_at}")

    _run(_list())


@source.command("add-user")
@click.option("--source", "source_name", required=True, help="Source name or UUID.")
@click.option("--user-id", required=True, type=int, help="User ID to add.")
def source_add_user(source_name, user_id):
    """Add a user to a source (grants push access)."""

    async def _add():
        from uuid import UUID as _UUID

        await _ensure_tables()
        async with async_session() as db:
            # Resolve source
            try:
                source_uuid = _UUID(source_name)
                result = await db.execute(
                    select(Source).where(Source.id == source_uuid)
                )
            except ValueError:
                result = await db.execute(
                    select(Source).where(Source.name == source_name)
                )
            src = result.scalar_one_or_none()
            if src is None:
                click.echo(f"Source '{source_name}' not found.", err=True)
                raise SystemExit(1)

            # Check user exists
            result = await db.execute(select(User).where(User.id == user_id))
            if result.scalar_one_or_none() is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)

            # Check not already a member
            result = await db.execute(
                select(SourceUser).where(
                    SourceUser.source_id == src.id, SourceUser.user_id == user_id
                )
            )
            if result.scalar_one_or_none() is not None:
                click.echo(
                    f"User {user_id} is already a member of source '{src.name}'."
                )
                return

            db.add(SourceUser(source_id=src.id, user_id=user_id))
            await db.commit()
            click.echo(f"Added user {user_id} to source '{src.name}' ({src.id}).")

    _run(_add())


@source.command("remove-user")
@click.option("--source", "source_name", required=True, help="Source name or UUID.")
@click.option("--user-id", required=True, type=int, help="User ID to remove.")
def source_remove_user(source_name, user_id):
    """Remove a user from a source (revokes push access)."""

    async def _remove():
        from uuid import UUID as _UUID

        await _ensure_tables()
        async with async_session() as db:
            try:
                source_uuid = _UUID(source_name)
                result = await db.execute(
                    select(Source).where(Source.id == source_uuid)
                )
            except ValueError:
                result = await db.execute(
                    select(Source).where(Source.name == source_name)
                )
            src = result.scalar_one_or_none()
            if src is None:
                click.echo(f"Source '{source_name}' not found.", err=True)
                raise SystemExit(1)

            result = await db.execute(
                select(SourceUser).where(
                    SourceUser.source_id == src.id, SourceUser.user_id == user_id
                )
            )
            su = result.scalar_one_or_none()
            if su is None:
                click.echo(
                    f"User {user_id} is not a member of source '{src.name}'.", err=True
                )
                raise SystemExit(1)

            await db.delete(su)
            await db.commit()
            click.echo(f"Removed user {user_id} from source '{src.name}'.")

    _run(_remove())


# ── Quick bootstrap ──────────────────────────────────────────────────


@app.command("bootstrap")
@click.option("--email", default="admin@localhost", help="Admin email.")
@click.option("--username", default="admin", help="Admin username.")
def bootstrap(email, username):
    """Create an admin user with an API key in one step."""

    async def _bootstrap():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(User).where(User.username == username))
            existing = result.scalar_one_or_none()
            if existing is not None:
                click.echo(
                    f"User '{username}' already exists (id={existing.id}), skipping creation."
                )
                return
            u = User(email=email, username=username, role="Admin")
            db.add(u)
            await db.flush()
            raw_key = secrets.token_urlsafe(32)
            db.add(ApiKey(user_id=u.id, key=hash_api_key(raw_key), name="bootstrap"))
            await db.commit()
            await db.refresh(u)
            click.echo(f"Created admin user id={u.id} username={u.username}")
            click.echo(f"API key: {raw_key}")
            click.echo("Store this key securely — it cannot be retrieved later.")

    _run(_bootstrap())


# ── Ingest ───────────────────────────────────────────────────────────


@app.command("ingest")
@click.argument("files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option("--source", required=True, help="Source name (created if missing).")
@click.option("--user-id", required=True, type=int, help="User ID for the commit.")
@click.option("--name", default=None, help="Commit name (defaults to filename).")
@click.option("--description", default=None, help="Commit description.")
def ingest(files, source, user_id, name, description):
    """Ingest .warp files directly into the database (no server needed)."""

    async def _ingest():
        from uuid import UUID as _UUID

        from warp_server.routers.files import _ingest_chunks
        from warp_server.warp_parser import parse_warp_file

        await _ensure_tables()
        async with async_session() as db:
            # Validate user
            result = await db.execute(select(User).where(User.id == user_id))
            user = result.scalar_one_or_none()
            if user is None:
                click.echo(f"User {user_id} not found.", err=True)
                raise SystemExit(1)

            # Find or create source (accept UUID or name)
            try:
                source_uuid = _UUID(source)
                result = await db.execute(
                    select(Source).where(Source.id == source_uuid)
                )
                src = result.scalar_one_or_none()
                if src is None:
                    click.echo(f"Source {source} not found.", err=True)
                    raise SystemExit(1)
            except ValueError:
                result = await db.execute(select(Source).where(Source.name == source))
                rows = result.scalars().all()
                if len(rows) > 1:
                    click.echo(f"Multiple sources named '{source}':", err=True)
                    for s in rows:
                        click.echo(f"  {s.id}  {s.name}", err=True)
                    click.echo("Use --source with the source UUID instead.", err=True)
                    raise SystemExit(1)
                src = rows[0] if rows else None
                if src is None:
                    src = Source(name=source)
                    db.add(src)
                    await db.flush()
                    db.add(SourceTag(source_id=src.id, tag="trusted"))
                    click.echo(f"Created source id={src.id} name={src.name}")

            for filepath in files:
                path = Path(filepath)
                commit_name = name or path.name
                file_bytes = path.read_bytes()
                click.echo(f"Ingesting {path.name} ({len(file_bytes):,} bytes)...")

                t0 = time.perf_counter()
                try:
                    chunks = parse_warp_file(file_bytes)
                except Exception as exc:
                    click.echo(f"  Failed to parse: {exc}", err=True)
                    continue
                t_parse = time.perf_counter()

                n_funcs = sum(len(c.functions) for c in chunks)
                n_types = sum(len(c.types) for c in chunks)
                click.echo(
                    f"  Parsed {len(chunks)} chunks, {n_funcs} functions, "
                    f"{n_types} types in {(t_parse - t0) * 1000:.0f} ms"
                )

                commit = Commit(
                    source_id=src.id,
                    user_id=user.id,
                    name=commit_name,
                    description=description,
                )
                db.add(commit)
                await db.flush()

                await _ingest_chunks(db, chunks, commit.id, src.id)
                await db.commit()
                await db.refresh(commit)
                t_end = time.perf_counter()

                click.echo(
                    f"  Committed id={commit.id} in {(t_end - t0) * 1000:.0f} ms"
                )

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-5s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    _run(_ingest())


# ── Migrations ────────────────────────────────────────────────────────

_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")


async def _get_table_columns(conn, table_name: str) -> set[str]:
    """Return column names for a table using the inspector."""
    cols = await conn.run_sync(
        lambda sync_conn: {
            c["name"] for c in inspect(sync_conn).get_columns(table_name)
        }
        if inspect(sync_conn).has_table(table_name)
        else set()
    )
    return cols


async def _migration_hash_keys(db, apply: bool) -> bool:
    """Hash any plaintext API keys. Returns True if work was done/needed."""
    result = await db.execute(select(ApiKey))
    keys = result.scalars().all()

    to_update: list[tuple[int, str]] = []
    for k in keys:
        if _SHA256_HEX_RE.match(k.key):
            pass
        else:
            hashed = hash_api_key(k.key)
            to_update.append((k.id, hashed))

    if not to_update:
        return False

    click.echo(f"  hash-keys: {len(to_update)} plaintext key(s) found")
    if apply:
        for key_id, hashed in to_update:
            await db.execute(
                update(ApiKey).where(ApiKey.id == key_id).values(key=hashed)
            )
        await db.commit()
        click.echo(f"  hash-keys: migrated {len(to_update)} key(s)")
    return True


async def _migration_lockout_columns(conn, db, apply: bool) -> bool:
    """Add locked/failed_login_count/locked_at columns to users table."""
    columns = await _get_table_columns(conn, "users")
    needed = {"locked", "failed_login_count", "locked_at"} - columns
    if not needed:
        return False

    click.echo(f"  lockout-columns: users table missing {', '.join(sorted(needed))}")
    if apply:
        for col in needed:
            if col == "locked":
                await conn.execute(
                    text(
                        "ALTER TABLE users ADD COLUMN locked INTEGER NOT NULL DEFAULT 0"
                    )
                )
            elif col == "failed_login_count":
                await conn.execute(
                    text(
                        "ALTER TABLE users ADD COLUMN failed_login_count INTEGER NOT NULL DEFAULT 0"
                    )
                )
            elif col == "locked_at":
                await conn.execute(
                    text("ALTER TABLE users ADD COLUMN locked_at DATETIME")
                )
        await conn.commit()
        click.echo(f"  lockout-columns: added {', '.join(sorted(needed))}")
    return True


_IGNORED_NAME_PREFIXES = (
    "sub_",
    "nullsub",
    "j_sub_",
    "outlined_sub_",
    "_OUTLINED_FUNCTION",
)


async def _migration_purge_auto_names(db, apply: bool) -> bool:
    """Delete functions/symbols with auto-generated names (sub_, nullsub, etc.)."""
    sym_sub = (
        select(Symbol.id)
        .where(
            Symbol.name.like("sub_%")
            | Symbol.name.like("nullsub%")
            | Symbol.name.like("j_sub_%")
            | Symbol.name.like("outlined_sub_%")
            | Symbol.name.like("_OUTLINED_FUNCTION%")
        )
        .scalar_subquery()
    )

    func_sub = (
        select(Function.id).where(Function.symbol_id.in_(sym_sub)).scalar_subquery()
    )

    result = await db.execute(
        select(
            select(Symbol.id).where(Symbol.id.in_(sym_sub)).count(),
            select(Function.id).where(Function.id.in_(func_sub)).count(),
        )
    )
    n_symbols, n_functions = result.one()

    if n_symbols == 0:
        return False

    click.echo(
        f"  purge-auto-names: {n_symbols} symbol(s), {n_functions} function(s) to purge"
    )
    if apply:
        await db.execute(
            delete(FunctionComment).where(FunctionComment.function_id.in_(func_sub))
        )
        await db.execute(
            delete(FunctionConstraint).where(
                FunctionConstraint.function_id.in_(func_sub)
            )
        )
        await db.execute(delete(Function).where(Function.symbol_id.in_(sym_sub)))
        await db.execute(delete(Symbol).where(Symbol.id.in_(sym_sub)))
        await db.commit()
        click.echo(
            f"  purge-auto-names: purged {n_functions} function(s) "
            f"and {n_symbols} symbol(s)"
        )
    return True


@app.command("migrate")
@click.option(
    "--apply", is_flag=True, help="Actually write changes (default is dry-run)."
)
def migrate(apply):
    """Run all pending database migrations.

    By default runs in dry-run mode and only prints what would change.
    Pass --apply to commit the changes.
    """

    async def _migrate():
        await _ensure_tables()
        pending = 0

        async with engine.begin() as conn:
            async with async_session() as db:
                click.echo("Checking migrations...")

                if await _migration_hash_keys(db, apply):
                    pending += 1

                if await _migration_lockout_columns(conn, db, apply):
                    pending += 1

                if await _migration_purge_auto_names(db, apply):
                    pending += 1

        if pending == 0:
            click.echo("Everything up to date — no migrations needed.")
        elif not apply:
            click.echo(
                f"\nDry run: {pending} migration(s) pending. "
                "Re-run with --apply to commit."
            )
        else:
            click.echo(f"\nApplied {pending} migration(s).")

    _run(_migrate())


# ── Lockout management ───────────────────────────────────────────────


@app.group(help="Manage IP lockouts.")
def lockout():
    pass


@lockout.command("list")
def lockout_list():
    """List all locked IPs."""

    async def _list():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(select(LoginAttempt).order_by(LoginAttempt.id))
            rows = result.scalars().all()
            locked = [r for r in rows if r.locked]
            if not locked:
                click.echo("No locked IPs.")
                return
            click.echo(f"{'ID':<6} {'IP Address':<40} {'Attempts':<10} {'Locked At'}")
            click.echo("-" * 80)
            for r in locked:
                click.echo(
                    f"{r.id:<6} {r.ip_address:<40} {r.failed_count:<10} {r.locked_at}"
                )

    _run(_list())


@lockout.command("unlock")
@click.argument("ip_address")
def lockout_unlock(ip_address):
    """Unlock a locked IP address."""

    async def _unlock():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(
                select(LoginAttempt).where(LoginAttempt.ip_address == ip_address)
            )
            attempt = result.scalar_one_or_none()
            if attempt is None:
                click.echo(f"No record for IP {ip_address}.", err=True)
                raise SystemExit(1)
            if not attempt.locked:
                click.echo(f"IP {ip_address} is not locked.")
                return
            attempt.locked = 0
            attempt.failed_count = 0
            attempt.locked_at = None
            attempt.last_attempt_at = None
            await db.commit()
            click.echo(f"Unlocked IP {ip_address}.")

    _run(_unlock())


@lockout.command("unlock-all")
def lockout_unlock_all():
    """Unlock all locked IP addresses."""

    async def _unlock_all():
        await _ensure_tables()
        async with async_session() as db:
            result = await db.execute(
                select(LoginAttempt).where(LoginAttempt.locked == 1)
            )
            locked = result.scalars().all()
            if not locked:
                click.echo("No locked IPs.")
                return
            for attempt in locked:
                attempt.locked = 0
                attempt.failed_count = 0
                attempt.locked_at = None
                attempt.last_attempt_at = None
            await db.commit()
            click.echo(f"Unlocked {len(locked)} IP(s).")

    _run(_unlock_all())


if __name__ == "__main__":
    app()
