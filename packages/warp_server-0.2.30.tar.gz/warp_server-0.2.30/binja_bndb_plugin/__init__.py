# WARP BNDB Manager – Binary Ninja Plugin
#
# Reads the server URL and API key from existing WARP settings:
#   warp.container.serverUrl
#   warp.container.serverApiKey
#
# Registers three commands under WARP\BNDB:
#   - List & Download   – query the server, pick a BNDB, download and open it
#   - Save & Upload     – save the current database and upload it
#

from .plugin import register_commands

register_commands()
