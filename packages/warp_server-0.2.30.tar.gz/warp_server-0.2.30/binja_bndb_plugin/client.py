"""Thin HTTP client for the WARP server BNDB endpoints."""

import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from binaryninja import Settings, log_info

_CHUNK = 256 * 1024

# Setting keys – the WARP Rust plugin may or may not be loaded.
# We try our own keys first, then fall back to the WARP plugin keys.
_SETTING_SERVER_URL = "warp.bndb.serverUrl"
_SETTING_API_KEY = "warp.bndb.serverApiKey"
_WARP_SETTING_SERVER_URL = "warp.container.serverUrl"
_WARP_SETTING_API_KEY = "warp.container.serverApiKey"


def _register_settings() -> None:
    s = Settings()
    s.register_group("warp", "WARP")
    s.register_setting(
        _SETTING_SERVER_URL,
        json.dumps(
            {
                "title": "WARP BNDB Server URL",
                "type": "string",
                "default": "",
                "description": "URL of the WARP server for BNDB management. "
                "If empty, falls back to the main WARP server URL setting.",
            }
        ),
    )
    s.register_setting(
        _SETTING_API_KEY,
        json.dumps(
            {
                "title": "WARP BNDB API Key",
                "type": "string",
                "default": "",
                "description": "API key for the WARP server BNDB endpoints. "
                "If empty, falls back to the main WARP server API key.",
            }
        ),
    )


_register_settings()


def _get_setting(our_key: str, warp_key: str) -> str:
    """Return *our_key* if set, else try the shared WARP key."""
    s = Settings()
    val = (s.get_string(our_key) or "").strip()
    if val:
        return val
    return (s.get_string(warp_key) or "").strip()


def _server_url() -> str:
    url = _get_setting(_SETTING_SERVER_URL, _WARP_SETTING_SERVER_URL).rstrip("/")
    # Normalise common typo: https:///host → https://host
    while ":///" in url:
        url = url.replace(":///", "://")
    if not url or not url.startswith(("http://", "https://")):
        raise RuntimeError(
            "No WARP server URL configured. "
            "Set 'warp.bndb.serverUrl' (or 'warp.container.serverUrl') "
            "in Binary Ninja settings."
        )
    return url


def _api_key() -> str | None:
    return _get_setting(_SETTING_API_KEY, _WARP_SETTING_API_KEY) or None


def _auth_headers() -> dict[str, str]:
    headers: dict[str, str] = {"User-Agent": "BinaryNinja-WARP-BNDB/0.1"}
    key = _api_key()
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


# ── JSON helpers ────────────────────────────────────────────────────


def _json_request(method: str, path: str, body: dict | None = None) -> dict:
    url = f"{_server_url()}{path}"
    headers = _auth_headers()
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = Request(url, data=data, headers=headers, method=method)
    with urlopen(req) as resp:
        return json.loads(resp.read())


# ── Public API ──────────────────────────────────────────────────────


def query_bndbs(
    name: str | None = None,
    page: int = 1,
    limit: int = 50,
) -> dict:
    """POST /api/v1/bndbs/query – returns paginated list of BNDBs."""
    payload: dict = {"limit": limit, "page": page}
    if name:
        payload["name"] = name
    return _json_request("POST", "/api/v1/bndbs/query", payload)


def download_bndb(bndb_uuid: str, dest_path: str) -> None:
    """GET /api/v1/bndbs/{uuid}/download – stream file to *dest_path*."""
    url = f"{_server_url()}/api/v1/bndbs/{bndb_uuid}/download"
    req = Request(url, headers=_auth_headers(), method="GET")
    with urlopen(req) as resp, open(dest_path, "wb") as fh:
        while True:
            chunk = resp.read(_CHUNK)
            if not chunk:
                break
            fh.write(chunk)


def upload_bndb(
    file_path: str,
    name: str,
    description: str | None = None,
    chunk_size: int = 10 * 1024 * 1024,  # 10 MB per chunk
) -> dict:
    """Upload a BNDB via chunked upload. Returns BndbMdl JSON."""
    file_size = os.path.getsize(file_path)
    total_chunks = max(1, -(-file_size // chunk_size))  # ceil division

    # 1. Init
    init_resp = _json_request(
        "POST",
        "/api/v1/bndbs/upload/init",
        {"name": name, "description": description, "total_chunks": total_chunks},
    )
    upload_id = init_resp["upload_id"]

    # 2. Upload each chunk
    with open(file_path, "rb") as fh:
        for i in range(total_chunks):
            data = fh.read(chunk_size)
            boundary = f"----chunk{i}"
            filename = os.path.basename(file_path)
            body_parts = [
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
                f"Content-Type: application/octet-stream\r\n\r\n".encode(),
                data,
                f"\r\n--{boundary}--\r\n".encode(),
            ]
            body = b"".join(body_parts)
            headers = _auth_headers()
            headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"

            url = f"{_server_url()}/api/v1/bndbs/upload/{upload_id}/{i}"
            req = Request(url, data=body, headers=headers, method="PUT")
            with urlopen(req) as resp:
                resp.read()
            log_info(
                f"[WARP BNDB] Chunk {i + 1}/{total_chunks} uploaded "
                f"({len(data)} bytes)"
            )

    # 3. Complete
    result = _json_request(
        "POST", f"/api/v1/bndbs/upload/{upload_id}/complete"
    )
    return result["bndb"]
