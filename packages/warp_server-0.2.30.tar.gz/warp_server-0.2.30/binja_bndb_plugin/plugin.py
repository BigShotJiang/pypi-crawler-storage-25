"""Binary Ninja commands: list, download, upload BNDBs via the WARP server."""

import os
from urllib.error import HTTPError, URLError

from binaryninja import (
    BinaryView,
    BackgroundTaskThread,
    log_error,
    log_info,
)
from binaryninja.filemetadata import FileMetadata
from binaryninja.enums import MessageBoxButtonSet, MessageBoxIcon
from binaryninja.interaction import (
    get_choice_input,
    get_save_filename_input,
    get_text_line_input,
    show_message_box,
)
from binaryninja.plugin import PluginCommand

from .client import download_bndb, query_bndbs, upload_bndb


# ── Helpers ─────────────────────────────────────────────────────────


def _to_str(value) -> str:
    """Normalise Binary Ninja interaction values (may be bytes or str)."""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value) if value else ""


def _show_error(title: str, exc: Exception) -> None:
    if isinstance(exc, HTTPError):
        body = exc.read().decode("utf-8", errors="replace")
        msg = f"Server error {exc.code}: {body}"
    elif isinstance(exc, URLError):
        msg = f"Connection error: {exc.reason}"
    else:
        msg = str(exc)
    log_error(f"[WARP BNDB] {msg}")
    show_message_box(
        title, msg, MessageBoxButtonSet.OKButtonSet, MessageBoxIcon.ErrorIcon
    )


# ── List & Download ─────────────────────────────────────────────────


class _DownloadTask(BackgroundTaskThread):
    def __init__(self, bndb_uuid: str, name: str, dest: str):
        super().__init__(f"Downloading BNDB {name}...", can_cancel=False)
        self.bndb_uuid = bndb_uuid
        self.name = name
        self.dest = dest

    def run(self):
        try:
            download_bndb(self.bndb_uuid, self.dest)
            log_info(f"[WARP BNDB] Downloaded '{self.name}' → {self.dest}")
            FileMetadata().open_existing_database(self.dest)
        except Exception as exc:
            _show_error("WARP BNDB Download", exc)


def _cmd_list_and_download(bv: BinaryView) -> None:
    try:
        # Fetch all BNDBs from the server immediately.
        all_items: list[dict] = []
        page = 1
        while True:
            result = query_bndbs(page=page, limit=200)
            items = result.get("items", [])
            all_items.extend(items)
            if page >= result.get("total_pages", 1):
                break
            page += 1

        if not all_items:
            show_message_box(
                "WARP BNDB",
                "No BNDBs found on the server.",
                MessageBoxButtonSet.OKButtonSet,
                MessageBoxIcon.InformationIcon,
            )
            return

        choices = []
        for item in all_items:
            size_mb = item["size_original"] / (1024 * 1024)
            user = item.get("username") or "unknown"
            choices.append(f"{item['name']}  ({size_mb:.1f} MB, by {user})")

        idx = get_choice_input(
            "Select a BNDB to download:", "WARP BNDB Download", choices
        )
        if idx is None:
            return

        selected = all_items[idx]
        default_name = selected["name"]
        if not default_name.endswith(".bndb"):
            default_name += ".bndb"

        dest = get_save_filename_input("Save BNDB as:", "bndb", default_name)
        if not dest:
            return
        dest = _to_str(dest)

        task = _DownloadTask(selected["uuid"], selected["name"], dest)
        task.start()

    except Exception as exc:
        _show_error("WARP BNDB List", exc)


# ── Save & Upload ───────────────────────────────────────────────────


class _UploadTask(BackgroundTaskThread):
    def __init__(self, bndb_path: str, name: str, description: str | None):
        super().__init__(f"Uploading BNDB {name}...", can_cancel=False)
        self.bndb_path = bndb_path
        self.name = name
        self.description = description

    def run(self):
        try:
            result = upload_bndb(self.bndb_path, self.name, self.description)
            log_info(
                f"[WARP BNDB] Uploaded '{result['name']}' "
                f"uuid={result['uuid']} sha256={result['sha256']}"
            )
            show_message_box(
                "WARP BNDB Upload",
                f"Uploaded successfully!\n\n"
                f"Name: {result['name']}\n"
                f"UUID: {result['uuid']}\n"
                f"SHA256: {result['sha256']}",
                MessageBoxButtonSet.OKButtonSet,
                MessageBoxIcon.InformationIcon,
            )
        except Exception as exc:
            _show_error("WARP BNDB Upload", exc)


def _cmd_save_and_upload(bv: BinaryView) -> None:
    try:
        filename = bv.file.filename or ""

        # Determine the BNDB path – reuse existing database or create one.
        if filename.endswith(".bndb"):
            bndb_path = filename
            bv.file.save_auto_snapshot()
        else:
            default_name = (os.path.basename(filename) + ".bndb") if filename else "untitled.bndb"
            bndb_path = get_save_filename_input("Save BNDB as:", "bndb", default_name)
            if not bndb_path:
                return
            bndb_path = _to_str(bndb_path)
            bv.create_database(bndb_path)

        name = os.path.basename(bndb_path)

        raw = get_text_line_input("Description (optional):", "WARP BNDB Upload")
        if raw is None:
            return
        description = _to_str(raw).strip() or None

        task = _UploadTask(bndb_path, name, description)
        task.start()

    except Exception as exc:
        _show_error("WARP BNDB Upload", exc)


# ── Registration ────────────────────────────────────────────────────


def register_commands() -> None:
    PluginCommand.register(
        r"WARP\BNDB\List && Download",
        "List BNDBs from the WARP server and download one to open",
        _cmd_list_and_download,
        is_valid=lambda bv: True,
    )
    PluginCommand.register(
        r"WARP\BNDB\Save && Upload",
        "Save the current analysis database and upload it to the WARP server",
        _cmd_save_and_upload,
    )
