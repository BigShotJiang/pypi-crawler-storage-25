#!/usr/bin/env python
# -*- coding: utf-8 -*-


import threading
import time
import pandas as pd
from openctp_ctp import mdapi


cmes_instrument_ids = []

class MarketDataSpi(mdapi.CThostFtdcMdSpi):
    
    def __init__(self, api):
        super().__init__()
        self.api = api
        self._bar_callback = None
        self._tick_fields = None
        self._skip_tick_fields = frozenset({"this", "thisown"})
        
    def OnFrontConnected(self):
        print("行情服务器连接成功")
        req = mdapi.CThostFtdcReqUserLoginField()
        req.UserID = ""
        req.Password = ""
        req.BrokerID = ""
        self.api.ReqUserLogin(req, 0)
        
    def OnRspUserLogin(self, pRspUserLogin, pRspInfo, nRequestID, bIsLast):
        if pRspInfo and pRspInfo.ErrorID != 0:
            print(f"登录失败: {pRspInfo.ErrorMsg}")
        else:
            print("登录成功，开始订阅行情")
            global cmes_instrument_ids
            instrument_ids = cmes_instrument_ids
            result = self.api.SubscribeMarketData([i.encode('utf-8') for i in instrument_ids], len(instrument_ids))
                
            print(f"✓ 订阅成功！")
        
    def OnRtnDepthMarketData(self, pDepthMarketData):
        # 或df = pd.DataFrame([vars(pDepthMarketData)])
        if self._bar_callback is not None:
            try:
                if self._tick_fields is None:
                    fields = []
                    for attr in dir(pDepthMarketData):
                        if attr.startswith("_"):
                            continue
                        if attr in self._skip_tick_fields:
                            continue
                        try:
                            value = getattr(pDepthMarketData, attr)
                        except Exception:
                            continue
                        if callable(value):
                            continue
                        # 过滤 SWIG 内部指针对象（避免打印出 CThostFtdcDepthMarketDataField * / thisown）
                        if type(value).__name__ == "SwigPyObject":
                            continue
                        if isinstance(value, mdapi.CThostFtdcDepthMarketDataField):
                            continue
                        if hasattr(value, "this") and hasattr(value, "thisown"):
                            continue
                        if not callable(value):
                            fields.append(attr)
                    self._tick_fields = tuple(fields)

                tick_dict = {}
                for attr in self._tick_fields:
                    try:
                        tick_dict[attr] = getattr(pDepthMarketData, attr)
                    except Exception:
                        continue

                df = pd.DataFrame([tick_dict])
                self._bar_callback(df)
            except Exception as e:
                print(f"调用客户回调函数时出错: {e}")

    
    def register_bar_callback(self, callback):
        if callable(callback):
            self._bar_callback = callback
        else:
            raise ValueError("回调函数必须是可调用对象")

_global_spi = None
_pending_callback = None


def subscribe_market_data():
    from cmesdata.stock import fu_autu_token
    if ':' not in fu_autu_token:
        print('您未开通接口权限或已到期，请先开通期货权限')
        return
    global _global_spi, _pending_callback
    api = mdapi.CThostFtdcMdApi.CreateFtdcMdApi()
    spi = MarketDataSpi(api)
    _global_spi = spi
    tocken_mes_sdr = 'tcp:'
    if _pending_callback is not None:
        spi.register_bar_callback(_pending_callback)
        _pending_callback = None
    api.RegisterSpi(spi)
    api.RegisterFront(f"{tocken_mes_sdr}//{fu_autu_token.split(':')[0]}:{fu_autu_token.split(':')[1]}")
    api.Init()
    api.Join()

def subscribe_future_code(code_list):
    global cmes_instrument_ids
    cmes_instrument_ids = code_list
    thread = threading.Thread(target=subscribe_market_data, daemon=True)
    thread.start()
    time.sleep(1)


def register_push_callback(callback):
    global _global_spi, _pending_callback
    if _global_spi is not None:
        _global_spi.register_bar_callback(callback)
    else:
        _pending_callback = callback


def onbar_test_cmes(df):
    print('收到行情推送')
    print(df.to_string())

if __name__ == "__main__":
    subscribe_future_code(['ag2601'])
    register_push_callback(onbar_test_cmes)
    while True:
        time.sleep(5)


