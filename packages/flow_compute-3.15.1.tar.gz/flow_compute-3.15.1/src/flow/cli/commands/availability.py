"""GPU availability command.

Shows current GPU availability across regions, grouped by GPU type and region.
Designed for quick capacity checks: "what's available right now?"
"""

import json
from contextlib import nullcontext
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

import click

from flow.cli.commands._pricing_data import parse_gpu_spec
from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.ui.presentation.table_styles import (
    create_flow_table,
    should_show_region_column,
    wrap_table_in_panel,
)
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.theme_manager import theme_manager
from flow.domain.parsers.instance_parser import extract_gpu_info
from flow.errors import AuthenticationError

# Display timezone for snapshot timestamps. Matches `flow pricing`'s
# convention so users see the same wall clock across pricing surfaces.
_DISPLAY_TZ = ZoneInfo("America/Los_Angeles")
_AVAILABILITY_FETCH_LIMIT = 1000
_AVAILABILITY_REGION_MIN_COLS = 88


def _format_as_of(now_utc: datetime) -> str:
    """Render a snapshot wall clock like ``14:23 PDT``.

    The timezone abbreviation comes from the local zone, so it shifts
    between PST and PDT automatically with daylight saving.
    """
    local = now_utc.astimezone(_DISPLAY_TZ)
    return local.strftime("%H:%M %Z")


class AvailabilityCommand(BaseCommand):
    """Show current GPU availability across regions."""

    @property
    def name(self) -> str:
        return "availability"

    @property
    def help(self) -> str:
        return "Show current GPU availability across regions"

    def get_command(self) -> click.Command:
        from flow.cli.completion import complete_gpu_families as _complete_gpu_families

        @click.command(name=self.name, help=self.help)
        @click.option(
            "--gpu",
            help="Filter by GPU type or config (e.g., b200, h100, 8xh100)",
            shell_complete=_complete_gpu_families,
        )
        @click.option(
            "--gpu-count",
            type=click.IntRange(min=1),
            help="Filter by GPU count (e.g., 1, 8)",
        )
        @click.option("--region", help="Filter by region (e.g., us-central5-a)")
        @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def availability(
            gpu: str | None = None,
            gpu_count: int | None = None,
            region: str | None = None,
            as_json: bool = False,
        ):
            self._execute(gpu=gpu, gpu_count=gpu_count, region=region, as_json=as_json)

        return availability

    def _execute(
        self,
        *,
        gpu: str | None,
        gpu_count: int | None = None,
        region: str | None = None,
        as_json: bool = False,
    ) -> None:
        # Fetch instances via SDK
        import flow.sdk.factory as sdk_factory

        try:
            client = sdk_factory.create_client(auto_init=True)
        except AuthenticationError:
            render_auth_required_message(console, output_json=as_json)
            return

        gpu_filter = (gpu or "").lower().strip()
        if gpu_filter:
            gpu_filter, parsed_count = parse_gpu_spec(gpu_filter)
            if parsed_count is not None and gpu_count is None:
                gpu_count = parsed_count

        req: dict[str, Any] = {}
        if region:
            req["region"] = region
        if gpu_filter:
            req["gpu_type"] = gpu_filter
        if gpu_count is not None:
            req["gpu_count"] = gpu_count

        progress = (
            nullcontext()
            if as_json
            else AnimatedEllipsisProgress(
                console, "Checking GPU availability", transient=True, start_immediately=True
            )
        )
        with progress:
            instances = client.find_instances(req, limit=_AVAILABILITY_FETCH_LIMIT)

        # Capture snapshot wall-clock once, after the network call returns,
        # so the timestamp reflects the data the user actually sees.
        now_utc = datetime.now(tz=timezone.utc)
        as_of_label = _format_as_of(now_utc)

        if not instances:
            if as_json:
                click.echo(
                    json.dumps(
                        {"availability": [], "as_of": now_utc.isoformat()},
                        indent=2,
                    )
                )
            else:
                console.print(f"[dim]No instances found • as of {as_of_label}.[/dim]")
            return

        # Build raw rows from SDK response
        raw_rows: list[dict[str, Any]] = []
        for inst in instances:
            gpu_type = (inst.gpu_type or "") or extract_gpu_info(inst.instance_type)[0]
            raw_rows.append(
                {
                    "region": inst.region,
                    "gpu_type": gpu_type,
                    "gpu_count": inst.gpu_count,
                    "price_per_hour": inst.price_per_hour,
                    "instance_type": inst.instance_type,
                    "available_quantity": inst.available_quantity,
                    "available_gpus": (inst.available_quantity or 0) * (inst.gpu_count or 1),
                }
            )

        # Filter out zero-availability entries — this is an availability view.
        raw_rows = [r for r in raw_rows if (r.get("available_quantity") or 0) > 0]

        # Apply GPU filter as a local guard in case a provider cannot enforce it.
        if gpu_filter:
            raw_rows = [r for r in raw_rows if (r.get("gpu_type") or "").lower() == gpu_filter]
        if gpu_count is not None:
            raw_rows = [r for r in raw_rows if int(r.get("gpu_count") or 0) == gpu_count]

        if not raw_rows:
            if as_json:
                click.echo(
                    json.dumps(
                        {"availability": [], "as_of": now_utc.isoformat()},
                        indent=2,
                    )
                )
            else:
                console.print(f"[dim]No matching instances found • as of {as_of_label}.[/dim]")
            return

        # JSON output: return raw listings
        if as_json:
            click.echo(
                json.dumps(
                    {"availability": raw_rows, "as_of": now_utc.isoformat()},
                    indent=2,
                )
            )
            return

        show_region = should_show_region_column(
            region_filter=region,
            min_cols=_AVAILABILITY_REGION_MIN_COLS,
        )

        # Group by (gpu_type, visible region). The API's available_quantity is an
        # instance count (server already divides resource_gpus // instance_gpus).
        groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for r in raw_rows:
            actual_region = r.get("region", "")
            display_region = actual_region if show_region else ""
            key = (r.get("gpu_type", ""), display_region)
            config_gpu_count = r.get("gpu_count") or 1
            avail = r.get("available_quantity") or 0
            price = r.get("price_per_hour")
            price_per_gpu = None
            if isinstance(price, int | float) and price > 0 and config_gpu_count > 0:
                price_per_gpu = price / config_gpu_count
            groups.setdefault(key, []).append(
                {
                    "gpu_count": config_gpu_count,
                    "price_per_gpu": price_per_gpu,
                    "available_gpus": avail * config_gpu_count,
                    "actual_region": actual_region,
                }
            )

        # Build display rows. When per-GPU prices within a (gpu_type, region)
        # diverge by more than 2x, split into separate rows so users see the
        # real price for each config instead of a misleading min().
        _PRICE_DIVERGENCE_RATIO = 2.0
        _PRICE_DIVERGENCE_MIN_DIFF = 0.50  # Don't split over trivial differences
        display_rows: list[dict[str, Any]] = []

        for (gpu_type, rgn), configs in groups.items():
            prices = [
                c["price_per_gpu"]
                for c in configs
                if c["price_per_gpu"] is not None and c["price_per_gpu"] > 0
            ]
            should_split = (
                len(prices) >= 2
                and max(prices) / min(prices) > _PRICE_DIVERGENCE_RATIO
                and (max(prices) - min(prices)) > _PRICE_DIVERGENCE_MIN_DIFF
            )

            if should_split:
                split_by_count: dict[int, dict[str, Any]] = {}
                for c in configs:
                    if show_region:
                        split_by_count[id(c)] = {
                            "gpu_count": c["gpu_count"],
                            "price_per_gpu": c["price_per_gpu"],
                            "available_gpus": c["available_gpus"],
                        }
                        continue

                    entry = split_by_count.setdefault(
                        c["gpu_count"],
                        {
                            "gpu_count": c["gpu_count"],
                            "price_per_gpu": c["price_per_gpu"],
                            "available_by_region": {},
                        },
                    )
                    if c["price_per_gpu"] is not None:
                        existing_price = entry["price_per_gpu"]
                        if existing_price is None or c["price_per_gpu"] < existing_price:
                            entry["price_per_gpu"] = c["price_per_gpu"]
                    by_region = entry["available_by_region"]
                    region_key = c.get("actual_region") or ""
                    by_region[region_key] = max(
                        by_region.get(region_key, 0),
                        c["available_gpus"],
                    )

                for c in split_by_count.values():
                    available_gpus = c.get("available_gpus")
                    if available_gpus is None:
                        available_gpus = sum(c.get("available_by_region", {}).values())
                    display_rows.append(
                        {
                            "gpu_type": gpu_type,
                            "region": rgn,
                            "gpu_count": c["gpu_count"],
                            "sizes_str": f"{c['gpu_count']}x",
                            "price_per_gpu": c["price_per_gpu"] or float("inf"),
                            "available_gpus": available_gpus,
                        }
                    )
            else:
                sizes = sorted({c["gpu_count"] for c in configs if c["gpu_count"] > 0})
                sizes_str = ", ".join(f"{s}x" for s in sizes) if sizes else "-"
                # Merged row spans multiple config sizes that share a GPU pool.
                # Show total GPUs as the common unit. If regions are hidden,
                # sum per-region pools after de-duping config sizes within each
                # region; otherwise preserve the old single-region max.
                if show_region:
                    pool_gpus = max((c["available_gpus"] for c in configs), default=0)
                else:
                    by_region: dict[str, int] = {}
                    for c in configs:
                        region_key = c.get("actual_region") or ""
                        by_region[region_key] = max(
                            by_region.get(region_key, 0),
                            c["available_gpus"],
                        )
                    pool_gpus = sum(by_region.values())
                min_price = min(prices) if prices else float("inf")
                display_rows.append(
                    {
                        "gpu_type": gpu_type,
                        "region": rgn,
                        "gpu_count": sizes[0] if sizes else 0,
                        "sizes_str": sizes_str,
                        "price_per_gpu": min_price,
                        "available_gpus": pool_gpus,
                    }
                )

        display_rows.sort(key=lambda r: (r["gpu_type"], r["price_per_gpu"], r["gpu_count"]))

        # Render table
        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")
        table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
        table.add_column("GPU", style=accent, no_wrap=True)
        if show_region:
            table.add_column("Region", style=muted, no_wrap=True)
        table.add_column("GPU Configs", style=muted, no_wrap=True)
        table.add_column("Price/GPU", justify="right", no_wrap=True)
        table.add_column("Avail GPUs", justify="right")

        for row in display_rows:
            price = row["price_per_gpu"]
            price_str = f"${price:.2f}/hr" if price < float("inf") else "-"
            avail_str = str(row["available_gpus"])
            row_cells = [row["gpu_type"]]
            if show_region:
                row_cells.append(row["region"])
            row_cells.extend([row["sizes_str"], price_str, avail_str])
            table.add_row(*row_cells)

        # Bullet-separated subtitle: filters, then snapshot wall clock at the
        # end. Matches the `flow pricing` panel chrome convention so users
        # build a single mental model across pricing surfaces.
        title_parts = ["GPU Availability"]
        if gpu_filter:
            # Canonical lowercase family — matches `flow submit -i` and the
            # table body. Count is not known at the filter level; it appears
            # separately in the "GPU Configs" column per row.
            title_parts.append(gpu_filter.lower())
        if gpu_count is not None and not (gpu_filter and f"{gpu_count}x" in (gpu or "").lower()):
            title_parts.append(f"{gpu_count} GPUs")
        if region:
            title_parts.append(region)
        elif not show_region:
            title_parts.append("all regions")
        title_parts.append(f"updated {as_of_label}")
        wrap_table_in_panel(table, " • ".join(title_parts), console)

        if show_region and display_rows:
            first_row = display_rows[0]
            gpu_count_hint = int(first_row["gpu_count"])
            gpu_type_hint = str(first_row["gpu_type"])
            region_hint = str(first_row["region"])
            if gpu_count_hint > 0 and gpu_type_hint and region_hint:
                instance_hint = f"{gpu_count_hint}x{gpu_type_hint}"
                console.print(
                    "\n[muted]Try:[/muted] "
                    f"[accent]flow submit -i {instance_hint} -r {region_hint} -- nvidia-smi[/accent]"
                )


command = AvailabilityCommand()
