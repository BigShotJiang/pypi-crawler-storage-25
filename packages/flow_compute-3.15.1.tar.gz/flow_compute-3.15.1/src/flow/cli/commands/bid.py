"""Spot bid management — list, update price, pause, and unpause bids.

Examples:
    # List active bids
    $ flow bid list

    # Update the limit price on a running instance
    $ flow bid update eb1-gateway-2d37c0 800

    # Pause / unpause a bid
    $ flow bid pause eb1-gateway-2d37c0
    $ flow bid unpause eb1-gateway-2d37c0
"""

from __future__ import annotations

import json
from contextlib import nullcontext
from typing import Any

import click

from flow.cli.commands.base import BaseCommand, console
from flow.cli.ui.presentation.animated_progress import AnimatedEllipsisProgress
from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel
from flow.cli.utils.error_handling import cli_error_guard, render_auth_required_message
from flow.cli.utils.theme_manager import theme_manager
from flow.errors import AuthenticationError


def _parse_price(raw: str) -> str:
    """Normalize a user-supplied price into the API format ``$NNN.NN``.

    Accepts ``800``, ``800.00``, ``$800``, ``$800.00``, etc.
    """
    cleaned = raw.strip().lstrip("$").strip()
    try:
        value = float(cleaned)
    except ValueError:
        raise click.BadParameter(f"Invalid price: {raw!r}. Use a number like 800 or $800.00")
    if value <= 0:
        raise click.BadParameter("Price must be positive")
    return f"${value:.2f}"


def _resolve_bid(bids: list[dict[str, Any]], identifier: str) -> dict[str, Any]:
    """Find a bid by FID or task name.

    Raises click.ClickException when no match or multiple matches are found.
    """
    # Exact FID match (fast path when user passes a bid_xxx identifier)
    if identifier.startswith("bid_"):
        for bid in bids:
            if bid.get("fid") == identifier:
                return bid
        raise click.ClickException(f"Bid {identifier} not found.")

    # Name match (case-insensitive)
    matches = [b for b in bids if (b.get("name") or "").lower() == identifier.lower()]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        fids = ", ".join(m["fid"] for m in matches)
        raise click.ClickException(
            f"Multiple bids match name {identifier!r}: {fids}. Use the bid FID instead."
        )

    # Partial / substring match as fallback
    partials = [b for b in bids if identifier.lower() in (b.get("name") or "").lower()]
    if len(partials) == 1:
        return partials[0]
    if len(partials) > 1:
        names = ", ".join(p.get("name", p["fid"]) for p in partials)
        raise click.ClickException(
            f"Ambiguous: {identifier!r} matches multiple bids: {names}. Be more specific."
        )

    raise click.ClickException(
        f"No bid found matching {identifier!r}. Run 'flow bid list' to see active bids."
    )


def _status_style(status: str) -> str:
    """Return a Rich markup style for a bid status string."""
    s = status.lower()
    if s == "allocated":
        return "[bold green]"
    if s == "open":
        return "[yellow]"
    if s == "preempting":
        return "[bold red]"
    return "[dim]"


def _fetch_active_bids(api_client: Any, project_id: str | None = None) -> list[dict[str, Any]]:
    """Fetch bids scoped to a project and return non-terminated ones."""
    params: dict[str, Any] = {}
    if project_id:
        params["project"] = project_id
    resp = api_client.list_bids(params)
    all_bids: list[dict[str, Any]] = resp if isinstance(resp, list) else resp.get("data", [])
    return [b for b in all_bids if b.get("status", "").lower() != "terminated"]


class BidCommand(BaseCommand):
    """Manage spot bids — view and update limit prices."""

    @property
    def name(self) -> str:
        return "bid"

    @property
    def help(self) -> str:
        return "Manage spot bids (list, update price, pause, unpause)"

    def get_command(self) -> click.Command:
        @click.group(name=self.name, help=self.help, invoke_without_command=True)
        @click.pass_context
        def bid_group(ctx: click.Context) -> None:
            if ctx.invoked_subcommand is None:
                click.echo(ctx.get_help())

        # ── list ─────────────────────────────────────────────
        @bid_group.command("list")
        @click.option("--all", "show_all", is_flag=True, help="Include terminated bids")
        @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def list_bids(show_all: bool = False, as_json: bool = False) -> None:
            """List spot bids and their current limit prices."""
            self._execute_list(show_all=show_all, as_json=as_json)

        # ── update ───────────────────────────────────────────
        @bid_group.command("update")
        @click.argument("task")
        @click.argument("price")
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        @click.option("--json", "as_json", is_flag=True, help="Output as JSON")
        @cli_error_guard(self)
        def update_bid(
            task: str,
            price: str,
            yes: bool = False,
            as_json: bool = False,
        ) -> None:
            """Update the limit price of a spot bid.

            TASK is the instance name or bid FID.
            PRICE is the new limit price (e.g., 800 or $800.00).
            """
            self._execute_update(task=task, price=price, yes=yes, as_json=as_json)

        # ── pause ────────────────────────────────────────────
        @bid_group.command("pause")
        @click.argument("task")
        @click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
        @cli_error_guard(self)
        def pause_bid(task: str, yes: bool = False) -> None:
            """Pause a spot bid (instance will be preempted)."""
            self._execute_pause(task=task, yes=yes, unpause=False)

        # ── unpause ──────────────────────────────────────────
        @bid_group.command("unpause")
        @click.argument("task")
        @cli_error_guard(self)
        def unpause_bid(task: str) -> None:
            """Unpause a paused spot bid."""
            self._execute_pause(task=task, yes=True, unpause=True)

        return bid_group

    # ── Implementation ───────────────────────────────────────

    def _get_ctx(self) -> Any:
        """Return the Mithril provider context, handling auth errors."""
        import flow.sdk.factory as sdk_factory

        client = sdk_factory.create_client(auto_init=True)
        provider = client.provider
        # Access the underlying MithrilContext via provider
        ctx = getattr(provider, "ctx", None) or getattr(provider, "_ctx", None)
        if ctx is None:
            raise click.ClickException(
                "Bid management requires the Mithril provider. "
                "Ensure your provider is set to 'mithril' in ~/.flow/config.yaml"
            )
        return ctx

    def _execute_list(self, *, show_all: bool, as_json: bool) -> None:
        try:
            ctx = self._get_ctx()
        except AuthenticationError:
            render_auth_required_message(console, output_json=as_json)
            return

        api = ctx.api
        project_id = ctx.get_project_id()

        progress = (
            nullcontext()
            if as_json
            else AnimatedEllipsisProgress(
                console, "Fetching bids", transient=True, start_immediately=True
            )
        )
        with progress:
            if show_all:
                params: dict[str, Any] = {}
                if project_id:
                    params["project"] = project_id
                resp = api.list_bids(params)
                all_bids: list[dict[str, Any]] = (
                    resp if isinstance(resp, list) else resp.get("data", [])
                )
            else:
                all_bids = _fetch_active_bids(api, project_id=project_id)

        if not all_bids:
            if as_json:
                click.echo(json.dumps({"bids": []}, indent=2))
            else:
                console.print("[dim]No active bids found.[/dim]")
            return

        # Sort: allocated first, then open, then others; within group by name
        status_order = {"allocated": 0, "open": 1, "preempting": 2}
        all_bids.sort(
            key=lambda b: (
                status_order.get(b.get("status", "").lower(), 9),
                b.get("name", ""),
            )
        )

        if as_json:
            click.echo(json.dumps({"bids": all_bids}, indent=2))
            return

        accent = theme_manager.get_color("accent")
        muted = theme_manager.get_color("muted")
        table = create_flow_table(title=None, show_borders=True, padding=1, expand=False)
        table.add_column("#", style=muted, width=3, justify="right")
        table.add_column("Name", style=accent, no_wrap=True, min_width=16)
        table.add_column("Status", no_wrap=True, width=12, justify="center")
        table.add_column("Limit Price", justify="right", no_wrap=True)
        table.add_column("Region", style=muted, no_wrap=True)
        table.add_column("Bid ID", style=muted, no_wrap=True)

        for i, bid in enumerate(all_bids, 1):
            status = bid.get("status", "unknown")
            style_open = _status_style(status)
            table.add_row(
                str(i),
                bid.get("name", "-"),
                f"{style_open}{status}[/]",
                bid.get("limit_price", "-"),
                bid.get("region") or "-",
                bid.get("fid", "-"),
            )

        wrap_table_in_panel(table, "Spot Bids", console)

        console.print()
        console.print("  [dim]flow bid update <name> <price>[/dim] — change limit price")

    def _execute_update(self, *, task: str, price: str, yes: bool, as_json: bool) -> None:
        new_price = _parse_price(price)

        try:
            ctx = self._get_ctx()
        except AuthenticationError:
            render_auth_required_message(console, output_json=as_json)
            return

        api = ctx.api
        project_id = ctx.get_project_id()

        progress = (
            nullcontext()
            if as_json
            else AnimatedEllipsisProgress(
                console, "Looking up bid", transient=True, start_immediately=True
            )
        )
        with progress:
            active_bids = _fetch_active_bids(api, project_id=project_id)

        bid = _resolve_bid(active_bids, task)
        old_price = bid.get("limit_price", "unknown")
        bid_name = bid.get("name", bid["fid"])
        bid_fid = bid["fid"]

        if not as_json and not yes:
            console.print(
                f"\n  Bid:    [bold]{bid_name}[/bold]\n"
                f"  Price:  {old_price} → [bold]{new_price}[/bold]\n"
            )
            if not click.confirm("  Proceed?", default=True):
                console.print("[dim]Cancelled[/dim]")
                return

        with (
            nullcontext()
            if as_json
            else AnimatedEllipsisProgress(
                console, "Updating bid", transient=True, start_immediately=True
            )
        ):
            result = api.patch_bid(bid_fid, {"limit_price": new_price})
            ctx.http.invalidate_task_cache()

        if as_json:
            click.echo(json.dumps(result, indent=2))
            return

        confirmed_price = (
            result.get("limit_price", new_price) if isinstance(result, dict) else new_price
        )
        console.print(
            f"\n  [bold green]Updated[/bold green] [bold]{bid_name}[/bold]: "
            f"{old_price} → [bold]{confirmed_price}[/bold]\n"
        )

    def _execute_pause(self, *, task: str, yes: bool, unpause: bool) -> None:
        action = "unpause" if unpause else "pause"

        try:
            ctx = self._get_ctx()
        except AuthenticationError:
            render_auth_required_message(console)
            return

        api = ctx.api
        project_id = ctx.get_project_id()

        with AnimatedEllipsisProgress(
            console, "Looking up bid", transient=True, start_immediately=True
        ):
            active_bids = _fetch_active_bids(api, project_id=project_id)

        bid = _resolve_bid(active_bids, task)
        bid_name = bid.get("name", bid["fid"])
        bid_fid = bid["fid"]

        if not yes:
            console.print(f"\n  {action.capitalize()} bid [bold]{bid_name}[/bold]?\n")
            if not click.confirm("  Proceed?", default=True):
                console.print("[dim]Cancelled[/dim]")
                return

        with AnimatedEllipsisProgress(
            console,
            f"{action.capitalize().rstrip('e')}ing bid",
            transient=True,
            start_immediately=True,
        ):
            payload = {"paused": not unpause}
            api.patch_bid(bid_fid, payload)
            ctx.http.invalidate_task_cache()

        verb = "Unpaused" if unpause else "Paused"
        console.print(f"\n  [bold green]{verb}[/bold green] [bold]{bid_name}[/bold]\n")


command = BidCommand()
