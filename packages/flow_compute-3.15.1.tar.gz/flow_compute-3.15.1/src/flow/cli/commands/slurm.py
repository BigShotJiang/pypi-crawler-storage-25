"""Slurm subcommands for reservations.

Implements ``flow slurm`` for submitting, listing, and canceling jobs on
Slurm-enabled reservations via slurmrestd. Overlay cluster management
lives on its own surface at ``flow cluster``.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from typing import Any

import click
from pydantic import ValidationError

import flow.sdk.factory as sdk_factory
from flow.cli.commands._slurmrestd_models import (
    JobCancelResponse,
    JobStatusResponse,
    JobSubmitRequest,
    JobSubmitResponse,
    SlurmJob,
)
from flow.cli.commands.base import BaseCommand, console
from flow.cli.commands.input_types import EnvItem
from flow.cli.commands.utils import env_items_to_dict
from flow.cli.utils.error_handling import cli_error_guard
from flow.cli.utils.theme_manager import theme_manager

_DEFAULT_SLURMRESTD_API_VERSION = "v0.0.41"


def _slurmrestd_request(
    slurm: dict[str, Any],
    method: str,
    path: str,
    *,
    ctx: click.Context,
    json_body: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Send a request to slurmrestd, reading TLS options from ctx.obj.

    Returns the raw JSON response as a ``dict``. Callers should immediately
    validate the shape using one of the Pydantic models in
    :mod:`flow.cli.commands._slurmrestd_models`.
    """
    from flow.sdk.http import HttpClient as _Http

    restd_url = slurm.get("restd_url", "")
    ca_pem = slurm.get("ca_pem")

    tls = ctx.obj or {}
    insecure = tls.get("insecure", False)
    ca_cert = tls.get("ca_cert")
    api_version = tls.get("api_version", _DEFAULT_SLURMRESTD_API_VERSION)

    verify_param: object = True
    caf_path: str | None = None
    try:
        if insecure:
            verify_param = False
        elif ca_cert:
            verify_param = ca_cert
        elif ca_pem:
            with tempfile.NamedTemporaryFile("w", delete=False) as caf:
                caf.write(ca_pem)
                caf.flush()
                caf_path = caf.name
                verify_param = caf_path

        http = _Http(base_url=restd_url.rstrip("/"), verify=verify_param)
        full_path = path.format(api_version=api_version)
        kwargs: dict[str, Any] = {"timeout_seconds": 30}
        if json_body is not None:
            kwargs["json"] = json_body
        if params is not None:
            kwargs["params"] = params
        response = http.request(method, full_path, **kwargs)
        if response is None:
            return {}
        if not isinstance(response, dict):
            raise click.ClickException(
                f"slurmrestd returned unexpected non-object response: {type(response).__name__}"
            )
        return response
    except click.ClickException:
        raise
    except Exception as e:
        raise _map_slurmrestd_error(e, restd_url) from e
    finally:
        if caf_path:
            try:
                os.unlink(caf_path)
            except OSError:
                # Best-effort cleanup; a leaked temp file is not fatal.
                pass


def _map_slurmrestd_error(error: Exception, restd_url: str) -> click.ClickException:
    """Translate a low-level HTTP/TLS failure into a user-facing error.

    Dispatches on exception type first (Flow's typed error hierarchy from
    ``flow.errors``) so that well-structured failures are classified
    precisely. Falls back to a walk of the exception cause chain looking
    for TLS / timeout / connection substrings for bare ``Exception``
    instances that skip the :class:`HttpClient` classification layer.
    """
    category = _classify_slurmrestd_error(error)
    if category == "tls":
        message = (
            f"TLS verification failed contacting slurmrestd at {restd_url}. "
            f"Hint: pass --ca-cert <pem> or --insecure. Error: {error}"
        )
    elif category == "timeout":
        message = (
            f"Timeout contacting slurmrestd at {restd_url}. "
            f"Try again or check network. Error: {error}"
        )
    elif category == "connection":
        message = (
            f"Failed to contact slurmrestd at {restd_url}. "
            f"Ensure the reservation is active and Slurm is provisioned. Error: {error}"
        )
    else:
        message = f"slurmrestd error: {error}"
    return click.ClickException(message)


def _classify_slurmrestd_error(error: BaseException) -> str:
    """Return ``tls`` | ``timeout`` | ``connection`` | ``other`` for a failure."""
    from flow.errors.api import APIError, FlowTimeoutError, NetworkError
    from flow.errors.auth import AuthenticationError

    if isinstance(error, FlowTimeoutError | TimeoutError):
        return "timeout"
    if isinstance(error, NetworkError):
        return "tls" if _cause_chain_has_tls(error) else "connection"
    if isinstance(error, AuthenticationError | APIError):
        return "connection"
    if _cause_chain_has_tls(error):
        return "tls"
    lowered = str(error).lower()
    if "timeout" in lowered or "timed out" in lowered:
        return "timeout"
    if (
        "connect" in lowered
        or "connection" in lowered
        or "unauthorized" in lowered
        or "http 5" in lowered
    ):
        return "connection"
    return "other"


def _cause_chain_has_tls(error: BaseException) -> bool:
    """Walk ``__cause__``/``__context__`` looking for an SSL/TLS failure."""
    import ssl

    current: BaseException | None = error
    depth = 0
    while current is not None and depth < 10:
        if isinstance(current, ssl.SSLError):
            return True
        lowered = str(current).lower()
        if "ssl" in lowered or "certificate" in lowered or "tls" in lowered:
            return True
        current = current.__cause__ or current.__context__
        depth += 1
    return False


class SlurmCommand(BaseCommand):
    """Submit jobs to Slurm-enabled reservations."""

    @property
    def name(self) -> str:
        return "slurm"

    @property
    def help(self) -> str:
        return "Submit jobs to Slurm-enabled reservations"

    def get_command(self) -> click.Command:
        @click.group(name=self.name, help=self.help)
        @click.option(
            "--insecure",
            is_flag=True,
            default=False,
            help="Disable TLS verification for slurmrestd (or set FLOW_SLURM_INSECURE=1)",
        )
        @click.option(
            "--ca-cert",
            type=click.Path(exists=True, dir_okay=False, readable=True, path_type=str),
            default=None,
            help="CA certificate PEM for slurmrestd (or set FLOW_SLURM_CA_CERT)",
        )
        @click.option(
            "--api-version",
            type=str,
            default=None,
            help=f"slurmrestd API version (default: {_DEFAULT_SLURMRESTD_API_VERSION})",
        )
        @click.pass_context
        @cli_error_guard(self)
        def grp(
            ctx: click.Context, insecure: bool, ca_cert: str | None, api_version: str | None
        ) -> None:
            ca_cert = ca_cert or os.getenv("FLOW_SLURM_CA_CERT")
            insecure = insecure or (
                os.getenv("FLOW_SLURM_INSECURE", "").strip() in {"1", "true", "yes"}
            )
            api_version = api_version or os.getenv(
                "FLOW_SLURM_API_VERSION", _DEFAULT_SLURMRESTD_API_VERSION
            )
            ctx.ensure_object(dict)
            ctx.obj["insecure"] = insecure
            ctx.obj["ca_cert"] = ca_cert
            ctx.obj["api_version"] = api_version

        def _get_slurm_meta(reservation_id: str) -> dict[str, Any]:
            flow = sdk_factory.create_client(auto_init=True)
            res = flow.get_reservation(reservation_id)
            meta = getattr(res, "provider_metadata", {}) or {}
            slurm = meta.get("slurm") or {}
            if not slurm:
                self.handle_error(
                    "Reservation is not Slurm-enabled. Recreate with --with-slurm or contact support."
                )
                raise click.Abort()
            return slurm

        def _require_restd_url(slurm: dict[str, Any]) -> str:
            restd_url = slurm.get("restd_url")
            if not restd_url:
                self.handle_error("Slurm REST endpoint is not available for this reservation")
                raise click.Abort()
            return restd_url

        @grp.command(name="submit", help="Submit a SLURM script to a reservation")
        @click.argument("reservation_id")
        @click.argument("script_path")
        @click.option(
            "--env",
            "env_items",
            type=EnvItem(),
            multiple=True,
            help="Env variables KEY=VALUE (repeatable)",
        )
        @click.option("--account", default=None)
        @click.option("--partition", default=None)
        @click.option("--array", default=None)
        @click.option("--name", default=None)
        @click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
        @click.pass_context
        def submit_cmd(
            ctx: click.Context,
            reservation_id: str,
            script_path: str,
            env_items: tuple[tuple[str, str], ...],
            account: str | None,
            partition: str | None,
            array: str | None,
            name: str | None,
            as_json: bool,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            try:
                with open(script_path, encoding="utf-8") as f:
                    content = f.read()
            except OSError as e:
                self.handle_error(f"Could not read script {script_path}: {e}")
                return

            env_dict = {str(k): str(v) for k, v in env_items_to_dict(env_items).items()}
            try:
                submit_request = JobSubmitRequest(
                    script=content,
                    environment=env_dict,
                    account=account,
                    partition=partition,
                    array=array,
                    name=name,
                )
            except ValidationError as e:
                self.handle_error(f"Invalid slurm submit request: {e}")
                return

            try:
                raw = _slurmrestd_request(
                    slurm,
                    "POST",
                    "/slurm/{api_version}/job/submit",
                    ctx=ctx,
                    json_body=submit_request.to_wire(),
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return

            try:
                response = JobSubmitResponse.model_validate(raw)
            except ValidationError as e:
                self.handle_error(f"Malformed slurmrestd submit response: {e}")
                return

            if response.has_errors():
                self.handle_error(f"Submit failed: {response.error_summary()}")
                return

            if as_json:
                console.print(json.dumps(raw))
                return

            accent = theme_manager.get_color("accent")
            if response.job_id:
                console.print(
                    f"\n[{accent}]Job {response.job_id}[/{accent}] submitted to {reservation_id}\n"
                )
                console.print(f"  [dim]flow slurm status {reservation_id}[/dim]")
                console.print(
                    f"  [dim]flow slurm cancel {reservation_id} {response.job_id}[/dim]\n"
                )
            else:
                console.print(json.dumps(raw, indent=2))

        @grp.command(name="status", help="List jobs on a Slurm-enabled reservation")
        @click.argument("reservation_id")
        @click.option("--user", default=None)
        @click.option("--state", default=None)
        @click.option("--json", "as_json", is_flag=True, help="Output raw JSON")
        @click.pass_context
        def status_cmd(
            ctx: click.Context,
            reservation_id: str,
            user: str | None,
            state: str | None,
            as_json: bool,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            params: dict[str, Any] = {}
            if user:
                params["user_name"] = user
            if state:
                params["job_state"] = state

            try:
                raw = _slurmrestd_request(
                    slurm,
                    "GET",
                    "/slurm/{api_version}/jobs",
                    ctx=ctx,
                    params=params,
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return

            try:
                response = JobStatusResponse.model_validate(raw)
            except ValidationError as e:
                self.handle_error(f"Malformed slurmrestd status response: {e}")
                return

            if response.has_errors():
                self.handle_error(f"Status fetch failed: {response.error_summary()}")
                return

            if as_json:
                console.print(
                    json.dumps(
                        {
                            "reservation_id": reservation_id,
                            "jobs": [j.to_display_dict() for j in response.jobs],
                            "raw_slurmrestd_response": raw,
                        }
                    )
                )
                return

            if not response.jobs:
                console.print("[dim]No jobs found.[/dim]")
                return

            _render_status_table(reservation_id, response.jobs)

        @grp.command(name="cancel", help="Cancel a Slurm job")
        @click.argument("reservation_id")
        @click.argument("job_id", type=click.IntRange(min=1))
        @click.pass_context
        def cancel_cmd(
            ctx: click.Context,
            reservation_id: str,
            job_id: int,
        ) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            _require_restd_url(slurm)

            try:
                raw = _slurmrestd_request(
                    slurm,
                    "DELETE",
                    f"/slurm/{{api_version}}/job/{job_id}",
                    ctx=ctx,
                )
            except click.ClickException as e:
                self.handle_error(e.format_message())
                return

            try:
                response = JobCancelResponse.model_validate(raw)
            except ValidationError as e:
                self.handle_error(f"Malformed slurmrestd cancel response: {e}")
                return

            if response.has_errors():
                self.handle_error(f"Cancel failed for job {job_id}: {response.error_summary()}")
                return

            accent = theme_manager.get_color("accent")
            console.print(f"[{accent}]Cancelled[/{accent}] job {job_id} on {reservation_id}")

        @grp.command(name="ssh", help="SSH to a reservation's Slurm login node")
        @click.argument("reservation_id")
        @click.option("--show", is_flag=True, help="Print SSH command without executing")
        def ssh_cmd(reservation_id: str, show: bool) -> None:
            try:
                slurm = _get_slurm_meta(reservation_id)
            except click.Abort:
                return
            host = slurm.get("login_host")
            if not host:
                self.handle_error("No login_host available on this reservation")
                return

            ssh_argv = ["ssh", host]
            if show:
                console.print(" ".join(ssh_argv))
            else:
                subprocess.run(ssh_argv, check=False)

        return grp


def _render_status_table(reservation_id: str, jobs: list[SlurmJob]) -> None:
    """Render the human-friendly status table for ``flow slurm status``."""
    from flow.cli.ui.presentation.slurm_colors import SLURM_JOB_STATE_COLORS
    from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel

    accent = theme_manager.get_color("accent")
    muted = theme_manager.get_color("muted")
    table = create_flow_table(show_borders=True, expand=False)
    table.add_column("JobID", style=accent, no_wrap=True)
    table.add_column("Name", style="white", no_wrap=True)
    table.add_column("User", style=muted, no_wrap=True)
    table.add_column("State", no_wrap=True)
    table.add_column("Nodes", justify="right", no_wrap=True)

    for job in jobs[:50]:
        state = job.job_state or "UNKNOWN"
        color = SLURM_JOB_STATE_COLORS.get(state.upper(), "white")
        table.add_row(
            str(job.job_id) if job.job_id is not None else "",
            (job.name or "")[:30],
            job.user_name or "",
            f"[{color}]{state}[/{color}]",
            str(job.node_count) if job.node_count is not None else "",
        )

    wrap_table_in_panel(table, f"Jobs on {reservation_id}", console)


command = SlurmCommand()
