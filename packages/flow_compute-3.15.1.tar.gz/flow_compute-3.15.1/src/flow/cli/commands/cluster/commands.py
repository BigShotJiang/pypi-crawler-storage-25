"""``flow cluster`` subcommands for Slurm overlay management.

Each subcommand creates, modifies, inspects, or dissolves a Slurm overlay
on existing Flow instances. Shared colour palettes live in
:mod:`flow.cli.ui.presentation.slurm_colors` so this module and
``flow slurm`` cannot drift on state colouring.
"""

from __future__ import annotations

import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

import click

from flow.cli.app import OrderedDYMGroup
from flow.cli.ui.presentation.slurm_colors import (
    HEALTH_STATUS_COLORS,
    SLURM_JOB_STATE_COLORS,
)
from flow.cli.utils.theme_manager import theme_manager as _tm

if TYPE_CHECKING:
    from flow.application.slurm_overlay import SlurmOverlayOrchestrator

__all__ = ["cluster_group"]


def _get_orchestrator() -> SlurmOverlayOrchestrator:
    """Lazily import and construct the overlay orchestrator.

    Lazy because :class:`SlurmOverlayOrchestrator` transitively imports the
    SSH stack and pydantic models — keeping it out of the ``flow --help``
    cold-import path.
    """
    import flow.sdk.factory as sdk_factory
    from flow.application.slurm_overlay import SlurmOverlayOrchestrator

    flow_client = sdk_factory.create_client(auto_init=True)
    return SlurmOverlayOrchestrator(provider=flow_client.provider)


def _handle_error(console, error: Exception) -> None:
    """Handle and display errors."""
    from pydantic import ValidationError

    from flow.application.slurm_overlay import (
        ClusterExistsError,
        InstanceNotFoundError,
        InstanceNotReadyError,
        SlurmOverlayError,
        SSHExecutionError,
    )

    if isinstance(error, click.UsageError):
        console.print(f"[error]Invalid command usage:[/error] {error.format_message()}")
    elif isinstance(error, ValidationError):
        console.print(f"[error]Invalid Slurm overlay configuration:[/error] {error}")
    elif isinstance(error, InstanceNotFoundError):
        console.print(f"[error]Instance not found:[/error] {error}")
        console.print("[dim]Use 'flow status' to list available instances.[/dim]")
    elif isinstance(error, InstanceNotReadyError):
        console.print(f"[error]Instance not ready:[/error] {error}")
    elif isinstance(error, ClusterExistsError):
        console.print(f"[error]Cluster conflict:[/error] {error}")
    elif isinstance(error, SSHExecutionError):
        console.print(f"[error]SSH command failed:[/error] {error}")
        if error.stderr:
            console.print(f"[dim]{error.stderr[:500]}[/dim]")
    elif isinstance(error, SlurmOverlayError):
        console.print(f"[error]Error:[/error] {error}")
    else:
        console.print(f"[error]Unexpected error:[/error] {error}")
    sys.exit(1)


def _read_public_key_for_private_key(private_key_path: str) -> str | None:
    """Return the local public key paired with ``private_key_path`` if present."""
    pub_path = Path(f"{Path(private_key_path).expanduser()}.pub")
    try:
        for line in pub_path.read_text().splitlines():
            key = line.strip()
            if key and not key.startswith("#"):
                return key
    except OSError:
        return None
    return None


@click.group(name="cluster", cls=OrderedDYMGroup)
def cluster_group():
    """Manage Slurm overlay clusters on existing instances.

    \b
    Overlay clusters let you organize running Flow instances into Slurm clusters
    for batch job submission. Unlike provisioned clusters, overlays are applied
    to existing instances and can be dissolved without terminating them.

    \b
    Examples:
      flow cluster create training --controller my-gpu-box --workers worker-1,worker-2
      flow cluster add training new-worker
      flow cluster remove training old-worker
      flow cluster dissolve training
    """
    pass


@cluster_group.command(name="create")
@click.argument("name", required=False)
@click.option(
    "--controller",
    "-c",
    help="Instance to use as Slurm controller (slurmctld)",
)
@click.option(
    "--workers",
    "-w",
    default=None,
    help="Comma-separated list of worker instances",
)
@click.option(
    "--partition",
    "-p",
    default=None,
    help="Slurm partition name (default: gpu, or auto-detected from GPU type)",
)
@click.option(
    "--max-time",
    default=None,
    help="Maximum job time (default: 7-00:00:00)",
)
@click.option(
    "--accounting/--no-accounting",
    default=None,
    help=(
        "Request Slurm accounting support. Overlay clusters currently reject "
        "accounting explicitly because slurmdbd-backed accounting is not implemented."
    ),
)
@click.option(
    "--config",
    "config_path",
    type=click.Path(exists=True),
    help="Load configuration from YAML file",
)
@click.option("--json", "output_json", is_flag=True, help="Output JSON")
def create_cluster(
    name: str | None,
    controller: str | None,
    workers: str | None,
    partition: str | None,
    max_time: str | None,
    accounting: bool | None,
    config_path: str | None,
    output_json: bool,
) -> None:
    """Create a Slurm overlay cluster from existing instances.

    \b
    Examples:
      # Create with explicit instances
      flow cluster create training \\
          --controller well-marsupial \\
          --workers interactive-ee06d3,interactive-3895a5

      # Create from YAML config
      flow cluster create --config cluster.yaml
    """
    console = _tm.create_console()

    try:
        from flow.application.slurm_overlay import SlurmOverlayConfig

        if config_path:
            config = SlurmOverlayConfig.from_yaml(config_path)
            overrides: dict[str, object] = {}
            if name is not None:
                overrides["name"] = name
            if controller is not None:
                overrides["controller"] = controller
            if workers is not None:
                overrides["workers"] = [w.strip() for w in workers.split(",") if w.strip()]
            if partition is not None:
                overrides["partition"] = partition
            if max_time is not None:
                overrides["max_time"] = max_time
            if accounting is not None:
                overrides["accounting"] = accounting
            if overrides:
                config = SlurmOverlayConfig.model_validate(
                    config.model_dump(exclude_none=False) | overrides
                )
        else:
            if not name:
                raise click.UsageError("NAME is required unless --config is provided.")
            if not controller:
                raise click.UsageError("--controller is required unless --config is provided.")
            worker_list = [w.strip() for w in (workers or "").split(",") if w.strip()]
            config = SlurmOverlayConfig(
                name=name,
                controller=controller,
                workers=worker_list,
                partition=partition or "gpu",
                max_time=max_time or "7-00:00:00",
                accounting=False if accounting is None else accounting,
            )

        console.print(
            f"\n[bold]Creating Slurm overlay cluster '[accent]{config.name}[/accent]'[/bold]\n"
        )
        console.print(f"  Controller: {config.controller}")
        console.print(f"  Workers:    {len(config.workers)}")
        console.print(f"  Partition:  {config.partition}")
        console.print()

        orchestrator = _get_orchestrator()

        with console.status("[bold]Setting up cluster...[/bold]"):
            state = orchestrator.create(config)

        if output_json:
            import json

            print(json.dumps(state.model_dump(mode="json"), indent=2, default=str))
        else:
            console.print(f"\n[success]Cluster '{state.name}' is ready![/success]\n")
            console.print(f"  Controller: {state.controller_ip}")
            console.print(f"  Workers:    {len(state.worker_fids)}")
            console.print()
            console.print("[dim]Next steps:[/dim]")
            console.print(
                f"  [accent]flow cluster ssh {state.name}[/accent]           # SSH to controller"
            )
            console.print(
                f"  [accent]flow cluster info {state.name}[/accent]          # View cluster status"
            )
            console.print(
                f"  [accent]ssh ubuntu@{state.controller_ip} sbatch job.sh[/accent]   # Submit a job"
            )
            console.print()

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="add")
@click.argument("cluster")
@click.argument("instances", nargs=-1, required=True)
def add_workers(cluster: str, instances: tuple[str, ...]) -> None:
    """Add workers to an existing overlay cluster.

    This command is idempotent - adding an already-joined instance will rejoin it.
    Use this for both initial additions and rejoining after preemption.

    \b
    Examples:
      flow cluster add training new-worker-1 new-worker-2
      flow cluster add training preempted-worker  # Rejoin after preemption
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()

        console.print(
            f"\nAdding {len(instances)} worker(s) to cluster '[accent]{cluster}[/accent]'...\n"
        )

        state = orchestrator.add_workers(cluster, list(instances))

        console.print("[success]Workers added successfully.[/success]")
        console.print(f"Cluster now has {len(state.worker_fids)} workers.\n")

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="remove")
@click.argument("cluster")
@click.argument("instances", nargs=-1, required=True)
@click.option("--force", is_flag=True, help="Skip job drain")
@click.option(
    "--timeout",
    default=300,
    type=click.IntRange(min=1),
    help="Drain timeout in seconds (default: 300)",
)
def remove_workers(cluster: str, instances: tuple[str, ...], force: bool, timeout: int) -> None:
    """Remove workers from an overlay cluster.

    By default, this drains running jobs before removal. Use --force to skip.
    The instances are not terminated, only removed from the Slurm cluster.

    \b
    Examples:
      flow cluster remove training old-worker
      flow cluster remove training worker-1 worker-2 --force
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()

        if not force:
            console.print(
                f"\nRemoving {len(instances)} worker(s) from cluster '[accent]{cluster}[/accent]'..."
            )
            console.print("[dim]Draining jobs first (use --force to skip)[/dim]\n")
        else:
            console.print(
                f"\nForce-removing {len(instances)} worker(s) from cluster '[accent]{cluster}[/accent]'...\n"
            )

        state = orchestrator.remove_workers(
            cluster, list(instances), force=force, drain_timeout=timeout
        )

        console.print("[success]Workers removed successfully.[/success]")
        console.print(f"Cluster now has {len(state.worker_fids)} workers.")
        console.print("[dim]Instances are still running (not terminated).[/dim]\n")

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="dissolve")
@click.argument("cluster")
@click.option("--force", is_flag=True, help="Skip confirmation and job drain")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
def dissolve_cluster(cluster: str, force: bool, yes: bool) -> None:
    """Dissolve an overlay cluster.

    Removes Slurm from all instances but keeps them running. This is reversible -
    you can create a new overlay on the same instances later.

    \b
    Examples:
      flow cluster dissolve training
      flow cluster dissolve training --force  # Skip drain
    """
    console = _tm.create_console()

    try:
        if not (force or yes) and not click.confirm(
            f"Dissolve cluster '{cluster}'? Instances will keep running."
        ):
            console.print("[dim]Cancelled.[/dim]")
            return

        orchestrator = _get_orchestrator()

        console.print(f"\nDissolving cluster '[accent]{cluster}[/accent]'...\n")

        orchestrator.dissolve(cluster, force=force)

        console.print(f"[success]Cluster '{cluster}' dissolved.[/success]")
        console.print("[dim]All instances are still running (Slurm removed).[/dim]\n")

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="list")
@click.option("--json", "output_json", is_flag=True, help="Output JSON")
def list_clusters(output_json: bool) -> None:
    """List all overlay clusters.

    \b
    Examples:
      flow cluster list
      flow cluster list --json
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()
        clusters = orchestrator.list_clusters()

        if output_json:
            import json

            data = [c.model_dump(mode="json") for c in clusters]
            print(json.dumps(data, indent=2, default=str))
            return

        if not clusters:
            console.print("\n[dim]No overlay clusters found.[/dim]")
            console.print(
                "[dim]Create one with: flow cluster create <name> --controller <instance>[/dim]\n"
            )
            return

        from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel

        accent = _tm.get_color("accent")
        muted = _tm.get_color("muted")
        status_colors = {
            "ready": "green",
            "creating": "yellow",
            "degraded": "yellow",
            "dissolving": "dim",
        }

        table = create_flow_table(show_borders=True, expand=False)
        table.add_column("#", style=muted, width=4, justify="right")
        table.add_column("Name", style=accent, no_wrap=True)
        table.add_column("Status", no_wrap=True)
        table.add_column("Controller", style=muted, no_wrap=True)
        table.add_column("Workers", justify="right", no_wrap=True)
        table.add_column("Partition", style=muted, no_wrap=True)

        for idx, cluster in enumerate(clusters, start=1):
            sc = status_colors.get(cluster.status, "white")
            table.add_row(
                str(idx),
                cluster.name,
                f"[{sc}]{cluster.status}[/{sc}]",
                cluster.controller_fid,
                str(len(cluster.worker_fids)),
                cluster.partition,
            )

        wrap_table_in_panel(table, "Clusters", console)

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="info")
@click.argument("cluster")
@click.option("--json", "output_json", is_flag=True, help="Output JSON")
def cluster_info(cluster: str, output_json: bool) -> None:
    """Show detailed information and health status of an overlay cluster.

    Displays cluster configuration, health status, provisioned users,
    node availability, and running jobs.

    \b
    Examples:
      flow cluster info training
      flow cluster info training --json
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()
        state = orchestrator.get_cluster(cluster)

        if state is None:
            console.print(f"[error]Cluster '{cluster}' not found.[/error]")
            console.print("[dim]Use 'flow cluster list' to see available clusters.[/dim]")
            sys.exit(1)

        # Get health status
        try:
            health_report = orchestrator.get_cluster_health(cluster)
        except Exception:  # noqa: BLE001
            health_report = None

        if output_json:
            import json
            from dataclasses import asdict

            # Get additional info from controller
            try:
                controller = orchestrator.resolve_instance(state.controller_fid)
                slurm_info = orchestrator.get_cluster_info(controller)
            except Exception:  # noqa: BLE001
                slurm_info = {}

            data = state.model_dump(mode="json")
            data["slurm"] = slurm_info
            if health_report:
                data["health"] = asdict(health_report)
            print(json.dumps(data, indent=2, default=str))
            return

        from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel

        # Health status display
        if health_report:
            status_color = HEALTH_STATUS_COLORS.get(health_report.overall_status, "white")
            health_display = (
                f"[{status_color}]{health_report.overall_status.upper()}[/{status_color}]"
            )
        else:
            health_display = "[dim]unknown[/dim]"

        # Cluster info table
        table = create_flow_table(show_borders=True, expand=False)
        table.add_column("Property", style="accent", width=20)
        table.add_column("Value", style="white", width=50)

        table.add_row("Name", state.name)
        table.add_row("Health", health_display)
        table.add_row("Controller", f"{state.controller_fid} ({state.controller_ip})")
        table.add_row("Workers", str(len(state.worker_fids)))
        table.add_row("Partition", state.partition)
        if state.project_id:
            table.add_row("Project", state.project_id)

        wrap_table_in_panel(table, f"Overlay Cluster: {state.name}", console)

        if health_report and health_report.overall_status != "healthy":
            if health_report.issues:
                console.print("\n[bold]Issues:[/bold]")
                for issue in health_report.issues:
                    console.print(f"  [warning]-[/warning] {issue}")
            if health_report.suggested_actions:
                console.print("\n[bold]Suggested Actions:[/bold]")
                for action in health_report.suggested_actions:
                    console.print(f"  [accent]-[/accent] {action}")

        if state.users:
            console.print(f"\n[bold]Users ({len(state.users)}):[/bold]")
            for user in state.users:
                creator_marker = (
                    " (creator)" if user.linux_username == state.created_by_username else ""
                )
                email_display = f"  {user.flow_email}" if user.flow_email else ""
                console.print(f"  {user.linux_username}{email_display}{creator_marker}")

        try:
            controller = orchestrator.resolve_instance(state.controller_fid)
            slurm_info = orchestrator.get_cluster_info(controller)
            console.print("\n[bold]Nodes (sinfo):[/bold]")
            console.print(f"[dim]{slurm_info.get('sinfo', 'No data')}[/dim]")
            console.print("\n[bold]Jobs (squeue):[/bold]")
            console.print(f"[dim]{slurm_info.get('squeue', 'No jobs')}[/dim]")
        except Exception as e:  # noqa: BLE001
            console.print(f"\n[dim]Could not fetch live Slurm info: {e}[/dim]")

        if health_report and health_report.overall_status != "healthy":
            console.print(f"\n[dim]To attempt repair: flow cluster repair {cluster}[/dim]")
        console.print(f"[dim]SSH: flow cluster ssh {cluster}[/dim]\n")

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="ssh")
@click.argument("cluster")
@click.argument("remote_cmd", nargs=-1)
@click.option("--show", is_flag=True, help="Display SSH command without executing")
@click.option("-i", "--identity", type=click.Path(exists=True), help="SSH private key file")
@click.option("--user", "-u", help="SSH as specific user (default: auto-detect from Flow identity)")
def ssh_to_cluster(
    cluster: str,
    remote_cmd: tuple[str, ...],
    show: bool,
    identity: str | None,
    user: str | None,
) -> None:
    """SSH to the controller node of an overlay cluster.

    By default, connects as your Flow username (derived from your identity).
    If your user doesn't exist on the cluster yet, it will be created automatically.

    \b
    Examples:
      flow cluster ssh training                    # Interactive shell
      flow cluster ssh training -- squeue          # Run command
      flow cluster ssh training -- sbatch job.sh   # Submit job
      flow cluster ssh training --show             # Show SSH command
      flow cluster ssh training --user ubuntu      # Use ubuntu user
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()
        state = orchestrator.get_cluster(cluster)

        if state is None:
            console.print(f"[error]Cluster '{cluster}' not found.[/error]")
            sys.exit(1)

        controller = orchestrator.resolve_instance(state.controller_fid)

        key_path = identity if identity else str(controller.ssh_key_path)
        ssh_user = user
        if not ssh_user:
            current_user = orchestrator.get_current_user()
            flow_user_id = (
                current_user.get("fid") or current_user.get("id") or current_user.get("user_id")
            )
            existing = state.get_user_by_flow_id(str(flow_user_id)) if flow_user_id else None
            public_key = _read_public_key_for_private_key(key_path)
            if existing is None and public_key is None:
                raise click.ClickException(
                    f"Could not find public key for {key_path}; cannot create "
                    "your cluster user without cloning ubuntu's SSH keys."
                )
            ssh_user = orchestrator.ensure_user_on_cluster(
                state,
                current_user,
                authorized_keys=[public_key] if public_key else None,
            )

        from flow.cli.utils.ssh_helpers import build_ssh_argv, ssh_command_string

        ssh_argv = build_ssh_argv(
            user=ssh_user,
            host=controller.host,
            port=controller.ssh_port,
            key_path=key_path,
            extra_ssh_args=None,
            remote_command=list(remote_cmd) if remote_cmd else None,
        )

        if show:
            console.print(ssh_command_string(ssh_argv))
            return

        if not remote_cmd:
            os.execvp(ssh_argv[0], ssh_argv)
        else:
            subprocess.run(ssh_argv, check=False)

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="repair")
@click.argument("cluster")
@click.option("--json", "output_json", is_flag=True, help="Output JSON")
def repair_cluster(cluster: str, output_json: bool) -> None:
    """Attempt to automatically repair cluster issues.

    Syncs users (adds new teammates), restarts stopped Slurm services,
    resumes nodes in DOWN state, and reconfigures the controller.

    \b
    Examples:
      flow cluster repair training
      flow cluster repair training --json
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()

        console.print(
            f"\n[bold]Attempting to repair cluster '[accent]{cluster}[/accent]'...[/bold]\n"
        )

        with console.status("[bold]Running repairs...[/bold]"):
            report = orchestrator.repair_cluster(cluster)

        if output_json:
            import json
            from dataclasses import asdict

            print(json.dumps(asdict(report), indent=2, default=str))
            return

        # Display repair results
        status_color = HEALTH_STATUS_COLORS.get(report.overall_status, "white")

        console.print(
            f"[bold]Post-repair Status: [{status_color}]{report.overall_status.upper()}[/{status_color}][/bold]\n"
        )

        # Show repair actions taken
        repairs = [i for i in report.issues if i.startswith("[Repaired]")]
        failures = [i for i in report.issues if i.startswith("[Repair failed]")]
        other_issues = [i for i in report.issues if not i.startswith("[Repair")]

        if repairs:
            console.print("[bold]Repairs completed:[/bold]")
            for repair in repairs:
                console.print(f"  [success]+[/success] {repair.replace('[Repaired] ', '')}")

        if failures:
            console.print("\n[bold]Repair failures:[/bold]")
            for failure in failures:
                console.print(f"  [error]-[/error] {failure.replace('[Repair failed] ', '')}")

        if other_issues:
            console.print("\n[bold]Remaining issues:[/bold]")
            for issue in other_issues:
                console.print(f"  [warning]-[/warning] {issue}")

        if report.overall_status == "healthy":
            console.print("\n[success]Cluster is now healthy![/success]")
        else:
            console.print("\n[dim]Some issues may require manual intervention.[/dim]")
            console.print(f"[dim]Run 'flow cluster info {cluster}' for details.[/dim]")

        console.print()

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="jobs")
@click.argument("cluster")
@click.option(
    "-n",
    "--limit",
    default=20,
    type=click.IntRange(min=1),
    help="Number of recent jobs to show",
)
@click.option("--json", "output_json", is_flag=True, help="Output JSON")
def list_jobs(cluster: str, limit: int, output_json: bool) -> None:
    """List recent Slurm jobs on the cluster.

    Shows job ID, name, user, state, and exit code.
    Overlay clusters rely on job completion logs and the active queue; sacct
    output is only used if an operator has enabled accounting separately.

    \b
    Examples:
      flow cluster jobs training
      flow cluster jobs training -n 50
      flow cluster jobs training --json
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()
        state = orchestrator.get_cluster(cluster)

        if state is None:
            console.print(f"[error]Cluster '{cluster}' not found.[/error]")
            sys.exit(1)

        controller = orchestrator.resolve_instance(state.controller_fid)

        # Try sacct first if the environment happens to support it, then fall back to squeue.
        sacct_cmd = (
            "sacct -n -X --format=JobID,JobName%30,User,State,ExitCode,Start,End "
            f"-S now-7days | head -n {limit}"
        )
        squeue_cmd = "squeue -h --format='%i|%j|%u|%T|%M|%N'"

        try:
            # Try sacct first when available.
            jobs_output = orchestrator.run_ssh_command(controller, sacct_cmd, timeout=30)
            source = "sacct"
        except Exception:  # noqa: BLE001
            # Fall back to squeue
            jobs_output = orchestrator.run_ssh_command(controller, squeue_cmd, timeout=30)
            source = "squeue"

        if output_json:
            import json

            data = {
                "cluster": cluster,
                "source": source,
                "raw_output": jobs_output,
            }
            print(json.dumps(data, indent=2))
            return

        if not jobs_output.strip():
            console.print("[dim]No jobs found.[/dim]\n")
            return

        # Parse pipe-delimited squeue or space-delimited sacct into a table
        from flow.cli.ui.presentation.table_styles import create_flow_table, wrap_table_in_panel

        accent = _tm.get_color("accent")
        muted = _tm.get_color("muted")
        lines = [ln.strip() for ln in jobs_output.strip().splitlines() if ln.strip()]

        if source == "squeue" and lines and "|" in lines[0]:
            # squeue pipe-delimited: JobID|Name|User|State|Time|Node
            table = create_flow_table(show_borders=True, expand=False)
            table.add_column("JobID", style=accent, no_wrap=True)
            table.add_column("Name", no_wrap=True)
            table.add_column("User", style=muted, no_wrap=True)
            table.add_column("State", no_wrap=True)
            table.add_column("Time", style=muted, no_wrap=True)
            table.add_column("Node", style=muted, no_wrap=True)

            for line in lines:
                parts = line.split("|")
                if len(parts) >= 4:
                    state = parts[3].strip()
                    sc = SLURM_JOB_STATE_COLORS.get(state.upper(), "white")
                    table.add_row(
                        parts[0].strip(),
                        parts[1].strip()[:30],
                        parts[2].strip(),
                        f"[{sc}]{state}[/{sc}]",
                        parts[4].strip() if len(parts) > 4 else "",
                        parts[5].strip() if len(parts) > 5 else "",
                    )

            wrap_table_in_panel(table, f"Jobs on {cluster}", console)
        else:
            # sacct or unrecognized format — show as-is with header
            console.print(
                f"\n[bold]Jobs on cluster '[accent]{cluster}[/accent]'[/bold] (from {source})\n"
            )
            console.print(f"[dim]{jobs_output}[/dim]")

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)


@cluster_group.command(name="logs")
@click.argument("cluster")
@click.option(
    "--job",
    "-j",
    "job_id",
    required=True,
    type=click.IntRange(min=1),
    help="Slurm job ID",
)
@click.option("--node", help="Fetch logs from a specific worker (name or FID)")
@click.option("--follow", "-f", is_flag=True, help="Follow log output (tail -f)")
@click.option(
    "--lines",
    "-n",
    default=100,
    type=click.IntRange(min=1),
    help="Number of lines to show",
)
def show_logs(cluster: str, job_id: int, node: str | None, follow: bool, lines: int) -> None:
    """Show output logs for a Slurm job.

    By default, fetches logs from the controller (where sbatch submissions
    write output). For multi-node jobs, use --node to target a specific worker.

    \b
    Examples:
      flow cluster logs training -j 12345
      flow cluster logs training -j 12345 --follow
      flow cluster logs training -j 12345 --node worker-1
      flow cluster logs training -j 12345 -n 500
    """
    console = _tm.create_console()

    try:
        orchestrator = _get_orchestrator()
        state = orchestrator.get_cluster(cluster)

        if state is None:
            console.print(f"[error]Cluster '{cluster}' not found.[/error]")
            sys.exit(1)

        # Target the specified node or default to controller
        if node:
            target = orchestrator.resolve_instance(node)
            target_label = node
        else:
            target = orchestrator.resolve_instance(state.controller_fid)
            target_label = "controller"

        safe_id = str(job_id)
        find_log_cmd = f"""
            WORKDIR=$(sacct -j {safe_id} -n -X -o WorkDir 2>/dev/null | head -1 | xargs)
            if [[ -z "$WORKDIR" || ! -d "$WORKDIR" ]]; then WORKDIR="$HOME"; fi
            found=$(find "$WORKDIR" -maxdepth 2 -name "slurm-{safe_id}*.out" 2>/dev/null | head -1)
            echo "${{found:-$WORKDIR/slurm-{safe_id}.out}}"
        """

        log_output = orchestrator.run_ssh_command(target, find_log_cmd, timeout=30)
        log_path = next((line.strip() for line in log_output.splitlines() if line.strip()), "")
        if not log_path:
            raise click.ClickException("Could not resolve Slurm log path")
        safe_log_path = shlex.quote(log_path)

        if follow:
            console.print(f"[dim]Tailing {log_path} on {target_label}...[/dim]\n")
            console.print("[dim]Press Ctrl+C to stop[/dim]\n")

            from flow.cli.utils.ssh_helpers import build_ssh_argv

            ssh_argv = build_ssh_argv(
                user=target.ssh_user,
                host=target.host,
                port=target.ssh_port,
                key_path=str(target.ssh_key_path),
                extra_ssh_args=None,
                remote_command=f"tail -f -- {safe_log_path}",
            )
            os.execvp(ssh_argv[0], ssh_argv)
        else:
            missing_msg = f"[Log file not found: {log_path}]"
            cat_cmd = (
                f"tail -n {lines} -- {safe_log_path} 2>/dev/null || echo {shlex.quote(missing_msg)}"
            )
            log_content = orchestrator.run_ssh_command(target, cat_cmd, timeout=60)

            console.print(f"[bold]Job {job_id} logs[/bold] ({target_label}: {log_path}):\n")
            console.print(log_content)

    except Exception as e:  # noqa: BLE001
        _handle_error(console, e)
