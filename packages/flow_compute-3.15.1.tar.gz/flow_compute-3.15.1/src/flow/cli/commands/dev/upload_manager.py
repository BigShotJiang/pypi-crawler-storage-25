"""Handles code synchronization (rsync) for the dev command."""

import logging
import posixpath as _pp
from pathlib import Path
from typing import Protocol

from rich.text import Text

from flow.application.dev.executor import sanitize_env_name
from flow.cli.commands.base import console
from flow.cli.utils.step_progress import StepTimeline, UploadProgressReporter
from flow.cli.utils.upload_validation import ensure_remote_target
from flow.core.code_upload.targets import UploadTargetError, UploadTargetPlan, plan_for_dev
from flow.errors import CodeTransferError, FlowError, TransferError

logger = logging.getLogger(__name__)


class _FlowClient(Protocol):
    def get_remote_operations(self) -> object: ...

    def upload_code_to_task(
        self,
        task_id: str,
        *,
        source_dir: Path,
        timeout: int,
        console: object | None,
        target_dir: str,
        progress_reporter: object | None,
    ) -> object: ...


class _TaskLike(Protocol):
    task_id: str


class DevUploadManager:
    """Handles synchronization of local code to the dev VM."""

    def __init__(
        self,
        flow_client: _FlowClient,
        vm_task: _TaskLike,
        timeline: StepTimeline,
        *,
        upload_mode: str = "nested",
        upload_path: str | None = None,
    ):
        self.flow_client = flow_client
        self.vm_task = vm_task
        self.timeline = timeline
        self.upload_mode = upload_mode
        self.upload_path = upload_path

    def upload(self, upload_path: str, env_name: str) -> tuple[str, str | None]:
        """Validates the path and uploads code.

        Returns:
            (vm_target_dir, container_workdir_or_none)
        """
        upload_path_resolved = Path(upload_path).resolve()
        if not upload_path_resolved.exists():
            console.print(f"[error]Error: Upload path does not exist: {upload_path}[/error]")
            raise SystemExit(1)

        if not upload_path_resolved.is_dir():
            console.print(f"[error]Error: Upload path must be a directory: {upload_path}[/error]")
            raise SystemExit(1)

        try:
            if env_name == "default":
                vm_dir = self._upload_to_default(upload_path_resolved)
                return (vm_dir, None)
            return self._upload_to_env(upload_path_resolved, env_name)
        except (
            TransferError,
            CodeTransferError,
            FlowError,
            UploadTargetError,
            OSError,
            TimeoutError,
            RuntimeError,
        ) as e:
            self._handle_upload_error(e)
            return ("~", None)

    def _upload_to_default(self, source_dir: Path) -> str:
        plan = plan_for_dev(
            source_dir=source_dir,
            env_name="default",
            upload_mode=self.upload_mode,
            parent_override=self.upload_path or "~",
        )

        step_idx_upload = self.timeline.add_step("Establishing SSH connection", show_bar=False)
        self.timeline.start_step(step_idx_upload)
        self.timeline.set_active_hint_text(
            Text("Waiting for instance to be ready for code upload...")
        )

        ensure_remote_target(
            self.flow_client.get_remote_operations(),
            self.vm_task.task_id,
            UploadTargetPlan(
                remote_parent=plan.remote_parent,
                remote_target=plan.remote_target,
                container_workdir=None,
                mode=self.upload_mode,
            ),
        )

        reporter = self._build_flip_reporter(step_idx_upload)
        result = self.flow_client.upload_code_to_task(
            task_id=self.vm_task.task_id,
            source_dir=source_dir,
            target_dir=plan.remote_target,
            timeout=1200,
            console=None,
            progress_reporter=reporter,
        )

        actual_dir = getattr(result, "final_target", plan.remote_target) or plan.remote_target
        if (
            getattr(result, "files_transferred", 0) == 0
            and getattr(result, "bytes_transferred", 0) == 0
        ):
            self.timeline.complete_step(note="No changes")
        else:
            reporter.set_completion_note(f"→ {actual_dir}")

        self._maybe_show_nested_notice_once(actual_dir)
        return actual_dir

    def _upload_to_env(self, source_dir: Path, env_name: str) -> tuple[str, str | None]:
        from flow.cli.utils.step_progress import build_sync_check_hint

        env = sanitize_env_name(env_name)
        project_name = source_dir.name or "project"
        plan = plan_for_dev(source_dir=source_dir, env_name=env, upload_mode=self.upload_mode)

        self.flow_client.get_remote_operations().execute_command(
            self.vm_task.task_id, f"mkdir -p {plan.remote_parent}"
        )

        step_idx_upload = self.timeline.add_step("Checking for changes", show_bar=False)
        self.timeline.start_step(step_idx_upload)
        self.timeline.set_active_hint_text(build_sync_check_hint())

        reporter = self._build_flip_reporter(step_idx_upload)
        result = self.flow_client.upload_code_to_task(
            task_id=self.vm_task.task_id,
            source_dir=source_dir,
            target_dir=plan.remote_target,
            timeout=1500,
            console=None,
            progress_reporter=reporter,
        )

        actual_dir = _pp.normpath(
            getattr(result, "final_target", plan.remote_target) or plan.remote_target
        )
        if (
            getattr(result, "files_transferred", 0) == 0
            and getattr(result, "bytes_transferred", 0) == 0
        ):
            self.timeline.complete_step(note="No changes")
        elif actual_dir == plan.remote_target:
            reporter.set_completion_note(
                f"→ {plan.remote_target} (container: /workspace/{project_name})"
            )
        else:
            reporter.set_completion_note(f"→ {actual_dir}")

        env_parent_norm = _pp.normpath(plan.remote_parent)
        container_dir = plan.container_workdir if actual_dir.startswith(env_parent_norm) else None
        return (actual_dir, container_dir)

    def _build_flip_reporter(self, initial_step_index: int) -> UploadProgressReporter:
        """Build a reporter that flips to a fresh 'Uploading code' step on transfer start.

        The reporter's ``step_index`` is rebound when the flip fires so that
        progress updates and the post-upload completion note both target the
        new step instead of the completed pre-flight step.
        """
        reporter = UploadProgressReporter(self.timeline, initial_step_index)

        def _flip() -> None:
            self.timeline.complete_step()
            new_idx = self.timeline.add_step("Uploading code", show_bar=True)
            self.timeline.start_step(new_idx)
            reporter.step_index = new_idx

        reporter.set_on_start(_flip)
        return reporter

    def _maybe_show_nested_notice_once(self, actual_dir: str) -> None:
        if self.upload_mode != "nested":
            return
        notices_dir = Path.home() / ".flow"
        notices_dir.mkdir(parents=True, exist_ok=True)
        marker = notices_dir / ".notice_dev_nested_upload"
        if marker.exists():
            return
        marker.write_text("1")
        console.print(
            f"[dim]Uploaded to {actual_dir}; use --flat to expand into parent.[/dim]"
        )

    def _handle_upload_error(self, e: Exception) -> None:
        msg = str(e)
        console.print(f"[error]Error uploading code: {msg}[/error]")
        low = msg.lower()

        # Heuristic guidance based on common rsync/SSH errors. Most FlowError
        # subclasses already include suggestions in str(e); these tips add
        # CLI-specific remediation with accent markup.
        if "permission denied" in low or "publickey" in low:
            console.print("\n[warning]SSH authentication failed[/warning]")
            console.print(
                "  • Ensure your SSH key is registered: [accent]flow ssh-key list[/accent]"
            )
            console.print(
                "  • Upload a key if missing: [accent]flow ssh-key upload ~/.ssh/id_ed25519.pub[/accent]"
            )
            console.print("  • Or set MITHRIL_SSH_KEYS env to your private key path")
            return

        if "rsync: command not found" in low or "rsync not found" in low or (
            "command not found" in low and "rsync" in low
        ):
            console.print("\n[warning]rsync missing[/warning]")
            console.print(
                "  • Local: macOS [accent]brew install rsync[/accent]; Ubuntu [accent]sudo apt-get install rsync[/accent]"
            )
            console.print(
                "  • Remote VM: attach with [accent]flow dev[/accent] and run [accent]sudo apt-get update && sudo apt-get install -y rsync[/accent]"
            )
            return

        if (
            "connection closed by" in low
            or "banner exchange" in low
            or "timed out" in low
            or "connection refused" in low
            or "network is unreachable" in low
        ):
            console.print("\n[warning]SSH connection unstable[/warning]")
            console.print(
                "  • Instance may still be initializing. Wait 60–90s and retry: [accent]flow dev[/accent]"
            )
            console.print(
                "  • If it persists, cancel and recreate the dev VM: [accent]flow cancel :dev && flow dev --force-new[/accent]"
            )
            return

        if "no space left on device" in low:
            console.print("\n[warning]Remote disk is full[/warning]")
            console.print(
                "  • Clean up large files on the VM or reduce what you upload via [.flowignore]"
            )
            console.print(
                "  • Check disk usage: [accent]flow dev[/accent] then [accent]df -h[/accent]"
            )
            return

        if "file name too long" in low or "argument list too long" in low:
            console.print("\n[warning]Too many files or paths too long[/warning]")
            console.print("  • Add more patterns to [.flowignore] to limit uploads")
            console.print("  • Consider excluding build artifacts, venvs, node_modules")
            return

        console.print(
            "\n[dim]Tips:[/dim] Use [.flowignore] to exclude large directories; run [accent]flow upload-code[/accent] for manual sync."
        )
