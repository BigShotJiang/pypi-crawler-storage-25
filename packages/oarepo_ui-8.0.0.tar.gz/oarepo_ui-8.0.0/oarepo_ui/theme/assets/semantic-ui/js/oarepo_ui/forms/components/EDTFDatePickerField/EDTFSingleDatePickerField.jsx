import React, { useState } from "react";
import { useField, useFormikContext } from "formik";
import PropTypes from "prop-types";
import { Form } from "semantic-ui-react";
import {
  serializeDate,
  deserializeDate,
  getDateFormatStringFromEdtfFormat,
  getInitialEdtfDateFormat,
} from "./utils";
import { useFieldData } from "../../hooks";
import { EDTFDatePickerWrapper } from "./EDTFDatePickerWrapper";
import { FieldLabel } from "react-invenio-forms";
import { mergeFieldData } from "../../util";

export const EDTFSingleDatePicker = ({
  fieldPath,
  label,
  helpText,
  required,
  placeholder,
  datePickerProps = {},
  customInputProps = {},
  icon = "calendar",
  width = 16,
}) => {
  const { setFieldValue } = useFormikContext();
  const { getFieldData } = useFieldData();

  const [field] = useField(fieldPath);
  const initialEdtfDateFormat = getInitialEdtfDateFormat(field?.value);
  const [dateEdtfFormat, setDateEdtfFormat] = useState(initialEdtfDateFormat);
  const date = field?.value ? deserializeDate(field?.value) : null;
  const handleChange = (date) => {
    setFieldValue(fieldPath, serializeDate(date, dateEdtfFormat));
  };
  const handleClear = () => {
    handleChange(null);
  };
  const fieldData = mergeFieldData(
    getFieldData({ fieldPath, icon, fieldRepresentation: "text" }),
    { label, required, helpText, placeholder }
  );
  return (
    <Form.Field
      className="ui datepicker field"
      required={fieldData.required}
      width={width}
    >
      <FieldLabel htmlFor={fieldPath} icon={icon} label={fieldData.label} />
      <EDTFDatePickerWrapper
        fieldPath={fieldPath}
        handleClear={handleClear}
        placeholder={fieldData.placeholder}
        dateEdtfFormat={dateEdtfFormat}
        setDateEdtfFormat={setDateEdtfFormat}
        dateFormat={getDateFormatStringFromEdtfFormat(dateEdtfFormat)}
        datePickerProps={{
          selected: date,
          onChange: handleChange,
          ...datePickerProps,
        }}
        customInputProps={customInputProps}
      />
      {fieldData.helpText && (
        <label className="helptext rel-mt-1">{fieldData.helpText}</label>
      )}
    </Form.Field>
  );
};

EDTFSingleDatePicker.propTypes = {
  fieldPath: PropTypes.string.isRequired,
  /* eslint-disable react/require-default-props */
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]),
  helpText: PropTypes.string,
  datePickerProps: PropTypes.object,
  required: PropTypes.bool,
  placeholder: PropTypes.string,
  customInputProps: PropTypes.object,
  icon: PropTypes.string,
  width: PropTypes.number,
  /* eslint-enable react/require-default-props */
};
