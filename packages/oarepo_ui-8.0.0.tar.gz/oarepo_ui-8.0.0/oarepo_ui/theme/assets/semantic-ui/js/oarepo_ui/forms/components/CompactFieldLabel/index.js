export * from "./CompactFieldLabel";
