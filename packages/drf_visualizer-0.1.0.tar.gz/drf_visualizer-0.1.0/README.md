# DRF Visualizer

DRF Visualizer is a comprehensive Django app that provides visualization and analysis of your Django REST Framework (DRF) backend architecture. 
It includes tools for analyzing URLs, models, serializers, views, security, and query optimization, making it easier to understand, document, and optimize your API.

## Features
- **URL Analysis**: View all your API endpoints, methods, and associated views.
- **Model Visualization**: Auto-generate graphs of your database models and their relationships.
- **Serializer Inspection**: Inspect serializers and their nested fields/relationships.
- **View Analysis**: Analyze views for authentication, permissions, pagination, and more.
- **Security Audit**: Identify endpoints lacking proper authentication, permission, or throttling.
- **Query Optimization**: Detect N+1 query issues and get suggestions for `select_related` and `prefetch_related`.
- **Exporting**: Export your architecture as JSON or Markdown.

## Quick Start

1. Install the package:
   ```bash
   pip install drf-visualizer
   ```

2. Add `"drf_visualizer"` to your `INSTALLED_APPS` setting like this:
   ```python
   INSTALLED_APPS = [
       ...
       "drf_visualizer",
   ]
   ```

3. Include the drf_visualizer URLconf in your project `urls.py` like this:
   ```python
   from django.urls import path, include

   urlpatterns = [
       ...
       path("drf-visualizer/", include("drf_visualizer.urls")),
   ]
   ```

4. Visit `http://127.0.0.1:8000/drf-visualizer/` to view the dashboard.

## License
MIT License
