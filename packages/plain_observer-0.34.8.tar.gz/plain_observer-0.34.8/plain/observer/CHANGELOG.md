# plain-observer changelog

## [0.34.8](https://github.com/dropseed/plain/releases/plain-observer@0.34.8) (2026-04-24)

### What's changed

- Added an `ObserverIndexView` at `/observer/` that redirects to the traces list, so visiting the observer root no longer 404s. ([2116e54976d2](https://github.com/dropseed/plain/commit/2116e54976d2))

### Upgrade instructions

- No changes required.

## [0.34.7](https://github.com/dropseed/plain/releases/plain-observer@0.34.7) (2026-04-23)

### What's changed

- `ObserverTracesView.after_response` annotates against `Response` after plain 0.135.0 merged `ResponseBase` into `Response`. ([f5007281d7fa](https://github.com/dropseed/plain/commit/f5007281d7fa))

### Upgrade instructions

- Requires `plain>=0.135.0`.

## [0.34.6](https://github.com/dropseed/plain/releases/plain-observer@0.34.6) (2026-04-22)

### What's changed

- `ObserverTraceDetailView.get` now returns a `JsonResponse` for JSON content negotiation instead of a bare dict, matching the narrowed `View` handler return type in plain 0.134.0. ([1935f3f](https://github.com/dropseed/plain/commit/1935f3f))

### Upgrade instructions

- Requires `plain>=0.134.0` and `plain-postgres>=0.98.0`.

## [0.34.5](https://github.com/dropseed/plain/releases/plain-observer@0.34.5) (2026-04-21)

### What's changed

- Migrated `ObserverTracesView` to the new `View.after_response` hook for the `X-Frame-Options: SAMEORIGIN` header (so the trace viewer loads inside the toolbar iframe). ([0da5639d17e2](https://github.com/dropseed/plain/commit/0da5639d17e2), [48effac976a9](https://github.com/dropseed/plain/commit/48effac976a9))

### Upgrade instructions

- Requires `plain>=0.133.0`.

## [0.34.4](https://github.com/dropseed/plain/releases/plain-observer@0.34.4) (2026-04-17)

### What's changed

- Changed `Span.span_data` from `default=dict` to `default={}` — callable `default=` values are banned in plain-postgres 0.96.0. ([091bac7](https://github.com/dropseed/plain/commit/091bac7))

### Upgrade instructions

- Requires `plain-postgres>=0.96.0`.

## [0.34.3](https://github.com/dropseed/plain/releases/plain-observer@0.34.3) (2026-04-14)

### What's changed

- **Fixed observer panel main content scrolling.** Added `h-full` to `<html>`, `<body>`, and `#main-content` so the traces panel now scrolls correctly inside the viewport. ([163f6220191b](https://github.com/dropseed/plain/commit/163f6220191b))
- Updated `observer clear` to the new `QuerySet.delete()` return type. The confirmation message now reads `✓ Cleared N traces (and cascaded spans/logs)` since the reported count is parents only — spans and logs are cascaded by Postgres. ([29e10dba51d9](https://github.com/dropseed/plain/commit/29e10dba51d9))
- Added explicit `plain.postgres>=0.95.0` dependency — the package has always imported `plain.postgres` APIs but previously relied on it being present transitively.

### Upgrade instructions

- Requires `plain-postgres>=0.95.0`.

## [0.34.2](https://github.com/dropseed/plain/releases/plain-observer@0.34.2) (2026-04-13)

### What's changed

- Updated internal references to use the fixed `app.users.models.User` convention. ([0861c9915cb6](https://github.com/dropseed/plain/commit/0861c9915cb6))
- Migrated type suppression comments to `ty: ignore` for the new ty checker version. ([4ec631a7ef51](https://github.com/dropseed/plain/commit/4ec631a7ef51))

### Upgrade instructions

- No changes required.

## [0.34.1](https://github.com/dropseed/plain/releases/plain-observer@0.34.1) (2026-04-05)

### What's changed

- **Fixed cookie/header reading from OTel context.** Switched from `baggage.get_baggage()` to `context.get_value()` to match the producer side, which now uses process-local context values instead of baggage. ([b56a9edc9c7d](https://github.com/dropseed/plain/commit/b56a9edc9c7d))

### Upgrade instructions

- No changes required.

## [0.34.0](https://github.com/dropseed/plain/releases/plain-observer@0.34.0) (2026-04-01)

### What's changed

- **Added "Record this page" button to the observer toolbar.** When in summary mode, a record dot appears next to the observer pill. Clicking it enables `persist_once` mode — the next page load is fully traced and saved to the database, then the mode reverts to summary automatically. ([6f30760fe40c](https://github.com/dropseed/plain/commit/6f30760fe40c))

### Upgrade instructions

- No changes required.

## [0.33.1](https://github.com/dropseed/plain/releases/plain-observer@0.33.1) (2026-03-29)

### What's changed

- Removed `AddIndex` and `RenameIndex` operations from migrations — indexes are now managed by convergence. ([c58b4ba1fec9](https://github.com/dropseed/plain/commit/c58b4ba1fec9))
- Updated docs to reference `plain postgres sync` instead of `plain migrate`. ([b026895edc4c](https://github.com/dropseed/plain/commit/b026895edc4c))

### Upgrade instructions

- No changes required.

## [0.33.0](https://github.com/dropseed/plain/releases/plain-observer@0.33.0) (2026-03-28)

### What's changed

- Replaced `CharField` with `TextField` in models and migration files to match plain-postgres 0.90.0 ([5062ee4dd1fd](https://github.com/dropseed/plain/commit/5062ee4dd1fd))

### Upgrade instructions

- Requires `plain-postgres>=0.90.0`
- Replace `CharField` with `TextField` in migration files that reference this package's models

## [0.32.1](https://github.com/dropseed/plain/releases/plain-observer@0.32.1) (2026-03-27)

### What's changed

- Changed `observer clear` confirmation flag from `--force` to `--yes`/`-y` for consistency across all CLI commands ([0af36e101f03](https://github.com/dropseed/plain/commit/0af36e101f03))

### Upgrade instructions

- If you use `plain observer clear --force` in scripts, change it to `plain observer clear --yes`.

## [0.32.0](https://github.com/dropseed/plain/releases/plain-observer@0.32.0) (2026-03-25)

### What's changed

- Removed `db_index=False` from `Span.trace` and `Log.trace` FK fields — the `db_index` parameter no longer exists on `ForeignKeyField`. Both are already covered by existing composite indexes/constraints. ([061b97f5d538](https://github.com/dropseed/plain/commit/061b97f5d538))
- Added explicit `Index` on `Log.span` FK field — replaces the old auto-created index. Migration drops the orphan auto-index and creates the new named index. ([061b97f5d538](https://github.com/dropseed/plain/commit/061b97f5d538))

### Upgrade instructions

- Requires `plain-postgres>=0.89.0`. Run `uv run plain postgres migrate`.

## [0.31.3](https://github.com/dropseed/plain/releases/plain-observer@0.31.3) (2026-03-25)

### What's changed

- Renamed indexes to use readable `{table}_{column}_idx` naming convention, replacing the old truncated hash-based names. Includes a migration with `RenameIndex` operations (instant `ALTER INDEX RENAME`, no locks). ([74aa8b76aa40](https://github.com/dropseed/plain/commit/74aa8b76aa40))

### Upgrade instructions

- Run `plain migrate` to apply the index rename migration. This is an instant metadata-only operation with no performance impact.

## [0.31.2](https://github.com/dropseed/plain/releases/plain-observer@0.31.2) (2026-03-25)

### What's changed

- Removed duplicate indexes on `Span` and `Log` models — dropped redundant `trace` and `(trace, span_id)` indexes that were covered by existing composite indexes, and set `db_index=False` on the `trace` FK fields ([262ad569d5df](https://github.com/dropseed/plain/commit/262ad569d5df))

### Upgrade instructions

- Run `uv run plain postgres migrate` to apply the migration.

## [0.31.1](https://github.com/dropseed/plain/releases/plain-observer@0.31.1) (2026-03-24)

### What's changed

- Improved `plain-optimize` skill description to better trigger on performance-related queries ([669e52eda37d](https://github.com/dropseed/plain/commit/669e52eda37d))

### Upgrade instructions

- No changes required.

## [0.31.0](https://github.com/dropseed/plain/releases/plain-observer@0.31.0) (2026-03-20)

### What's changed

- **New `plain observer request` command** — makes a request with tracing enabled and returns structured JSON analysis including query counts, duplicate detection, issue analysis, and a span tree. Supports `--user` (ID or email), `--method`, and `--data` options ([aa54f27d95](https://github.com/dropseed/plain/commit/aa54f27d95))
- **Replaced `psutil` dependency with stdlib metrics** — the toolbar now uses container-aware helpers from `plain.utils.os` (`get_process_cpu_percent()`, `get_memory_usage()`) instead of `psutil`, removing the external dependency ([40482feb2b](https://github.com/dropseed/plain/commit/40482feb2b))
- Toolbar system stats now display conditionally (CPU and memory shown only when available) with improved tooltips ([40482feb2b](https://github.com/dropseed/plain/commit/40482feb2b))

### Upgrade instructions

- `psutil` is no longer a dependency — you can remove it from your own dependencies if you only had it via plain-observer.

## [0.30.0](https://github.com/dropseed/plain/releases/plain-observer@0.30.0) (2026-03-20)

### What's changed

- Redesigned the observer toolbar button as a two-pill layout: a request pill (observer state, query count, request duration, response body size) and a system pill (CPU and memory usage), with color-coded warning/danger levels ([44d226b886e1](https://github.com/dropseed/plain/commit/44d226b886e1))
- Added live system CPU and memory stats to the toolbar, powered by a new `psutil` dependency ([98b50749e958](https://github.com/dropseed/plain/commit/98b50749e958))
- Response body size is now captured from OpenTelemetry spans and displayed in the toolbar (via the Navigation Timing API) and in persisted trace summaries ([46f981ff80fb](https://github.com/dropseed/plain/commit/46f981ff80fb))
- Renamed `get_current_trace_summary` / `get_trace_summary` to `get_current_trace_stats` / `get_trace_stats`, which now return structured `dict` data instead of a formatted string ([44d226b886e1](https://github.com/dropseed/plain/commit/44d226b886e1))

### Upgrade instructions

- If you called `Observer.get_current_trace_summary()`, rename to `get_current_trace_stats()` — it now returns a `dict` with keys `query_count`, `duplicate_count`, `duration_ms`, and `response_body_size` instead of a formatted string.
- Add `psutil>=5.9` to your dependencies if you pin observer's transitive deps.

## [0.29.1](https://github.com/dropseed/plain/releases/plain-observer@0.29.1) (2026-03-19)

### What's changed

- **Trend cards** — traces (grouped by app version), spans (grouped by kind), and logs (grouped by level) list views now include trend charts ([2df536722ddf](https://github.com/dropseed/plain/commit/2df536722ddf))
- **Styled span fields** — span `kind` and `status` are displayed as colored badges in the list view ([2df536722ddf](https://github.com/dropseed/plain/commit/2df536722ddf))

### Upgrade instructions

- No changes required.

## [0.29.0](https://github.com/dropseed/plain/releases/plain-observer@0.29.0) (2026-03-12)

### What's changed

- Updated all imports from `plain.models` to `plain.postgres` in admin, models, otel, views, and migrations.

### Upgrade instructions

- Update imports: `from plain.models` to `from plain.postgres`, `from plain import models` to `from plain import postgres`.

## [0.28.1](https://github.com/dropseed/plain/releases/plain-observer@0.28.1) (2026-03-04)

### What's changed

- Added minimum `plain>=0.113.0` version constraint in dependencies ([217751b866](https://github.com/dropseed/plain/commit/217751b866))

### Upgrade instructions

- No changes required.

## [0.28.0](https://github.com/dropseed/plain/releases/plain-observer@0.28.0) (2026-03-04)

### What's changed

- Updated `Observer.__init__` to accept `Mapping` instead of `dict` for `cookies` and `headers` parameters, matching the new `RequestHeaders` type from plain 0.113.0 ([acec7dfd89be](https://github.com/dropseed/plain/commit/acec7dfd89be))

### Upgrade instructions

- Requires plain >= 0.113.0.

## [0.27.5](https://github.com/dropseed/plain/releases/plain-observer@0.27.5) (2026-02-26)

### What's changed

- Removed redundant `allow_global_search = False` from trace, span, and log admin views — this is now the default in plain-admin ([05d6fa2764](https://github.com/dropseed/plain/commit/05d6fa2764))

### Upgrade instructions

- No changes required.

## [0.27.4](https://github.com/dropseed/plain/releases/plain-observer@0.27.4) (2026-02-26)

### What's changed

- Auto-formatted JavaScript assets and config files with updated linter configuration ([028bb95c3ae3](https://github.com/dropseed/plain/commit/028bb95c3ae3))

### Upgrade instructions

- No changes required.

## [0.27.3](https://github.com/dropseed/plain/releases/plain-observer@0.27.3) (2026-02-04)

### What's changed

- Added `__all__` exports to `__init__`, `core`, and `models` modules for explicit public API boundaries ([f26a63a5c941](https://github.com/dropseed/plain/commit/f26a63a5c941))
- `Observer` and `ObserverMode` are now exported from the top-level `plain.observer` module ([f26a63a5c941](https://github.com/dropseed/plain/commit/f26a63a5c941))

### Upgrade instructions

- No changes required.

## [0.27.2](https://github.com/dropseed/plain/releases/plain-observer@0.27.2) (2026-01-28)

### What's changed

- Converted the `plain-optimize` skill location from `skills/` to `agents/.claude/skills/` and added a passive `.claude/rules/` file for observer commands ([512040ac51](https://github.com/dropseed/plain/commit/512040ac51))

### Upgrade instructions

- Run `plain agent install` to update your `.claude/` directory.

## [0.27.1](https://github.com/dropseed/plain/releases/plain-observer@0.27.1) (2026-01-28)

### What's changed

- Updated admin views to use the new `get_initial_queryset` and `filter_queryset` hooks instead of `get_objects` and `get_initial_queryset` ([99d6f042b8](https://github.com/dropseed/plain/commit/99d6f042b8))
- Renamed `presets` to `filters` and `self.preset` to `self.filter` in admin views ([99d6f042b8](https://github.com/dropseed/plain/commit/99d6f042b8))
- Removed unused `filters` attribute from `LogViewset.ListView` ([99d6f042b8](https://github.com/dropseed/plain/commit/99d6f042b8))
- Added Settings section to README ([803fee1ad5](https://github.com/dropseed/plain/commit/803fee1ad5))

### Upgrade instructions

- No changes required.

## [0.27.0](https://github.com/dropseed/plain/releases/plain-observer@0.27.0) (2026-01-15)

### What's changed

- Improved mobile support with text truncation and constrained button width on smaller screens ([ee7acaa6](https://github.com/dropseed/plain/commit/ee7acaa67c))

### Upgrade instructions

- No changes required

## [0.26.0](https://github.com/dropseed/plain/releases/plain-observer@0.26.0) (2026-01-15)

### What's changed

- Updated admin icons: Trace viewset now uses `diagram-3` icon and Log viewset now uses `journal-text` icon instead of `activity` ([0fc4dd3](https://github.com/dropseed/plain/commit/0fc4dd345f))
- Added descriptions to admin list views for Traces, Spans, and Logs to explain what each model represents ([0fc4dd3](https://github.com/dropseed/plain/commit/0fc4dd345f))

### Upgrade instructions

- No changes required

## [0.25.0](https://github.com/dropseed/plain/releases/plain-observer@0.25.0) (2026-01-13)

### What's changed

- Expanded README documentation with comprehensive usage examples, settings reference, and FAQs ([da37a78](https://github.com/dropseed/plain/commit/da37a78fbb))

### Upgrade instructions

- No changes required

## [0.24.0](https://github.com/dropseed/plain/releases/plain-observer@0.24.0) (2026-01-13)

### What's changed

- Replaced AGENTS.md with a structured SKILL.md file providing a step-by-step performance optimization workflow for AI agents ([b592c32](https://github.com/dropseed/plain/commit/b592c32cb9))

### Upgrade instructions

- No changes required

## [0.23.2](https://github.com/dropseed/plain/releases/plain-observer@0.23.2) (2025-12-22)

### What's changed

- Fixed HTMX URL handling in traces template to use explicit named URLs instead of relative paths for improved reliability when observer is mounted at non-root paths ([6096411](https://github.com/dropseed/plain/commit/6096411765299a9ffa5c4af4b93eb15fedb97c82))

### Upgrade instructions

- No changes required

## [0.23.1](https://github.com/dropseed/plain/releases/plain-observer@0.23.1) (2025-12-12)

### What's changed

- Added CSP nonce support to the observer.js script tag in trace templates for improved Content Security Policy compatibility ([2961042](https://github.com/dropseed/plain/commit/2961042e1cb50e851499a9fef989664934d530fd))

### Upgrade instructions

- No changes required

## [0.23.0](https://github.com/dropseed/plain/releases/plain-observer@0.23.0) (2025-12-09)

### What's changed

- The trace sharing feature has been removed, including the share URL generation and public shared trace view ([5fba11a](https://github.com/dropseed/plain/commit/5fba11a7748ba2f6309c167be44501a79141e7a4))
- Added a "Copy JSON" button to the trace detail view that fetches and copies the trace data as formatted JSON to the clipboard ([44a9d62](https://github.com/dropseed/plain/commit/44a9d62ad7c9a1ea7d4b9e1b6ca56316dd9d7375))
- The "Clear Traces" action now deletes all traces instead of only unshared ones ([5fba11a](https://github.com/dropseed/plain/commit/5fba11a7748ba2f6309c167be44501a79141e7a4))

### Upgrade instructions

- No changes required

## [0.22.0](https://github.com/dropseed/plain/releases/plain-observer@0.22.0) (2025-12-04)

### What's changed

- Improved type annotations in OTel sampler to use proper `Attributes` type from OpenTelemetry ([ac1eeb0](https://github.com/dropseed/plain/commit/ac1eeb0ea05b26dfc7e32c50f2a5a5bc7e098ceb))
- Added explicit foreign key ID field annotations for `Log` model to improve type safety ([ac1eeb0](https://github.com/dropseed/plain/commit/ac1eeb0ea05b26dfc7e32c50f2a5a5bc7e098ceb))

### Upgrade instructions

- No changes required

## [0.21.0](https://github.com/dropseed/plain/releases/plain-observer@0.21.0) (2025-11-24)

### What's changed

- Updated views to use `AuthView` and `HTMXView` base classes instead of mixins for improved type safety ([569afd6](https://github.com/dropseed/plain/commit/569afd606d9eb0c4d805b17487ee4a26477b3fb9))
- Updated request data access to use `request.form_data` instead of `request.data` for form submissions ([90332a9](https://github.com/dropseed/plain/commit/90332a9c21364644732159a539d362a7108214ac))

### Upgrade instructions

- No changes required

## [0.20.0](https://github.com/dropseed/plain/releases/plain-observer@0.20.0) (2025-11-21)

### What's changed

- Internal model field type updated from `ForeignKey` to `ForeignKeyField` to align with the Plain framework naming conventions ([8010204](https://github.com/dropseed/plain/commit/8010204b360a170433ee081385d2311a1631805c))

### Upgrade instructions

- No changes required

## [0.19.1](https://github.com/dropseed/plain/releases/plain-observer@0.19.1) (2025-11-17)

### What's changed

- QuerySet type annotations no longer use `ClassVar`, reverting to direct annotations for improved compatibility ([1c624ff](https://github.com/dropseed/plain/commit/1c624ff29ebc750650c051094041a242c06b759d))

### Upgrade instructions

- No changes required

## [0.19.0](https://github.com/dropseed/plain/releases/plain-observer@0.19.0) (2025-11-14)

### What's changed

- Models now use explicit reverse relationship descriptors (e.g., `Trace.spans`, `Trace.logs`) instead of `related_name` parameters, providing better type hints and IDE support ([a4b6309](https://github.com/dropseed/plain/commit/a4b630969dbbfa5189d357647fd06a2207929b7c))
- Removed unnecessary type ignore comments that are no longer needed with explicit reverse descriptors ([a4b6309](https://github.com/dropseed/plain/commit/a4b630969dbbfa5189d357647fd06a2207929b7c))

### Upgrade instructions

- No changes required

## [0.18.0](https://github.com/dropseed/plain/releases/plain-observer@0.18.0) (2025-11-13)

### What's changed

- QuerySet type annotations now use `ClassVar` for improved type checking and IDE support ([c3b00a6](https://github.com/dropseed/plain/commit/c3b00a693c5869ce4861ea1eb5b953ccd1a77ef8))

### Upgrade instructions

- No changes required

## [0.17.0](https://github.com/dropseed/plain/releases/plain-observer@0.17.0) (2025-11-13)

### What's changed

- Model fields now use type stubs (from `plain.models.types`) with proper type annotations for improved IDE support and type checking ([c8f40fc](https://github.com/dropseed/plain/commit/c8f40fc75aeb8f6a69f44cbe4a62b08bda45a425))
- Removed unnecessary type casts in CLI code that are no longer needed with proper field type annotations ([c8f40fc](https://github.com/dropseed/plain/commit/c8f40fc75aeb8f6a69f44cbe4a62b08bda45a425))

### Upgrade instructions

- No changes required

## [0.16.0](https://github.com/dropseed/plain/releases/plain-observer@0.16.0) (2025-11-12)

### What's changed

- Fixed type checking errors and warnings by adding type ignore comments for ORM operations that are inherently difficult to type ([f4dbcef](https://github.com/dropseed/plain/commit/f4dbcefa929058be517cb1d4ab35bd73a89f26b8))

### Upgrade instructions

- No changes required

## [0.15.0](https://github.com/dropseed/plain/releases/plain-observer@0.15.0) (2025-11-03)

### What's changed

- The `plain observer diagnose` command has been removed ([fdb9e80](https://github.com/dropseed/plain/commit/fdb9e8010386b45e843676119e929a566e3612f4))
- CLI command descriptions updated for consistency and brevity ([fdb9e80](https://github.com/dropseed/plain/commit/fdb9e8010386b45e843676119e929a566e3612f4))
- Updated AGENTS.md to reflect removal of diagnose command ([786b7a0](https://github.com/dropseed/plain/commit/786b7a0ca156392b301125b653e88874f3e727b8))

### Upgrade instructions

- No changes required

## [0.14.0](https://github.com/dropseed/plain/releases/plain-observer@0.14.0) (2025-10-29)

### What's changed

- Updated CSP configuration example in documentation to use the new `DEFAULT_RESPONSE_HEADERS` format with string templates instead of callable functions ([5199383](https://github.com/dropseed/plain/commit/519938312835b73dfd9be8c93abae6e896094fc2))

### Upgrade instructions

- No changes required

## [0.13.0](https://github.com/dropseed/plain/releases/plain-observer@0.13.0) (2025-10-29)

### What's changed

- Inline JavaScript and CSS extracted to separate asset files for Content Security Policy (CSP) compatibility ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Added CSP nonce support to inline scripts for improved security ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Added comprehensive CSP configuration documentation in README, including required `frame-ancestors 'self'` directive for toolbar panel ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Span and log indentation now uses CSS classes with data attributes instead of inline styles ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Timeline bar positioning now uses CSS custom properties set via JavaScript instead of inline styles ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Copy share URL button now uses data attributes and event delegation instead of inline onclick handlers ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))
- Toolbar iframe now uses HTML attributes instead of inline styles ([784f3dd](https://github.com/dropseed/plain/commit/784f3dd972))

### Upgrade instructions

- No changes required

## [0.12.0](https://github.com/dropseed/plain/releases/plain-observer@0.12.0) (2025-10-24)

### What's changed

- Admin viewsets now use `presets` instead of `displays` for predefined queryset filters ([0ecc60f](https://github.com/dropseed/plain/commit/0ecc60f19e))
- Removed `logger` field from Log admin interface for simplified display ([ae43138](https://github.com/dropseed/plain/commit/ae43138863))
- Removed `/admin/.*` from default ignored URL patterns, allowing admin pages to be traced ([daadf1a](https://github.com/dropseed/plain/commit/daadf1a53d))

### Upgrade instructions

- If you have custom admin viewsets using the `displays` attribute, rename it to `presets`
- If you reference the `display` property in custom admin code (e.g., `self.display`), rename it to `self.preset`

## [0.11.2](https://github.com/dropseed/plain/releases/plain-observer@0.11.2) (2025-10-20)

### What's changed

- Package configuration migrated from `tool.uv.dev-dependencies` to the standard `dependency-groups.dev` format ([1b43a3a](https://github.com/dropseed/plain/commit/1b43a3a272))

### Upgrade instructions

- No changes required

## [0.11.1](https://github.com/dropseed/plain/releases/plain-observer@0.11.1) (2025-10-10)

### What's changed

- Trace list items now update the URL when clicked, allowing direct linking to specific traces ([9f29b68](https://github.com/dropseed/plain/commit/9f29b68a87))
- Improved trace sidebar layout by moving the timestamp to the bottom right and creating better visual hierarchy ([9f29b68](https://github.com/dropseed/plain/commit/9f29b68a87))
- Updated diagnose command prompt text to be less personal in tone ([c82d67b](https://github.com/dropseed/plain/commit/c82d67bfcf))

### Upgrade instructions

- No changes required

## [0.11.0](https://github.com/dropseed/plain/releases/plain-observer@0.11.0) (2025-10-08)

### What's changed

- Observer can now be enabled in DEBUG mode using an `Observer` HTTP header (e.g., `Observer: persist` or `Observer: summary`), which takes precedence over cookies ([cba149a](https://github.com/dropseed/plain/commit/cba149a40e))
- Added validation for observer mode values that raises helpful errors in DEBUG mode when invalid values are provided ([cba149a](https://github.com/dropseed/plain/commit/cba149a40e))
- Refactored `Observer` class to accept cookies and headers as constructor parameters, with new `from_request()` and `from_otel_context()` factory methods for improved testability ([cba149a](https://github.com/dropseed/plain/commit/cba149a40e))
- Added AGENTS.md file with helpful commands for AI agents working with Plain Observer ([cba149a](https://github.com/dropseed/plain/commit/cba149a40e))

### Upgrade instructions

- No changes required

## [0.10.1](https://github.com/dropseed/plain/releases/plain-observer@0.10.1) (2025-10-08)

### What's changed

- Fixed content negotiation priority in trace detail and shared views to prefer HTML over JSON by default ([00212835aa](https://github.com/dropseed/plain/commit/00212835aa))

### Upgrade instructions

- No changes required

## [0.10.0](https://github.com/dropseed/plain/releases/plain-observer@0.10.0) (2025-10-07)

### What's changed

- Model configuration now uses `model_options` descriptor instead of `class Meta` for improved consistency with Plain framework patterns ([17a378d](https://github.com/dropseed/plain/commit/17a378dcfb))
- Custom QuerySet classes are now defined as descriptors on the model class instead of being configured in Meta ([2578301](https://github.com/dropseed/plain/commit/2578301819))
- Internal model metadata split into separate `model_options` and `_model_meta` attributes for better organization ([73ba469](https://github.com/dropseed/plain/commit/73ba469ba0))

### Upgrade instructions

- No changes required

## [0.9.1](https://github.com/dropseed/plain/releases/plain-observer@0.9.1) (2025-10-06)

### What's changed

- Added comprehensive type annotations throughout the package for improved IDE support and type checking ([ffb8624](https://github.com/dropseed/plain/commit/ffb8624d6f))
- Package has been validated with 100% type coverage and added to the type validation script ([ffb8624](https://github.com/dropseed/plain/commit/ffb8624d6f))

### Upgrade instructions

- No changes required

## [0.9.0](https://github.com/dropseed/plain/releases/plain-observer@0.9.0) (2025-09-30)

### What's changed

- Settings renamed from `APP_NAME` to `NAME` and `APP_VERSION` to `VERSION` for consistency with Plain conventions ([4c5f216](https://github.com/dropseed/plain/commit/4c5f2166c1))
- Trace detail and shared views now use `request.get_preferred_type()` for improved content negotiation ([b105ba4](https://github.com/dropseed/plain/commit/b105ba4dd0))

### Upgrade instructions

- No changes required

## [0.8.0](https://github.com/dropseed/plain/releases/plain-observer@0.8.0) (2025-09-30)

### What's changed

- The toolbar panel class has been renamed from `ToolbarPanel` to `ToolbarItem` for better clarity and consistency ([79654db](https://github.com/dropseed/plain/commit/79654db))
- The `template_name` attribute has been renamed to `panel_template_name` in toolbar items ([79654db](https://github.com/dropseed/plain/commit/79654db))
- The registration decorator has been renamed from `register_toolbar_panel` to `register_toolbar_item` ([79654db](https://github.com/dropseed/plain/commit/79654db))

### Upgrade instructions

- If you have custom toolbar panels, rename your class from inheriting `ToolbarPanel` to `ToolbarItem`
- If you use the `template_name` attribute in your toolbar items, rename it to `panel_template_name`
- If you use the `@register_toolbar_panel` decorator, change it to `@register_toolbar_item`

## [0.7.0](https://github.com/dropseed/plain/releases/plain-observer@0.7.0) (2025-09-12)

### What's changed

- Model manager renamed from `objects` to `query` throughout the codebase for consistency with Plain framework conventions ([037a239](https://github.com/dropseed/plain/commit/037a239ef4))
- Updated internal QuerySet configuration to use `queryset_class` instead of `manager_class` in model Meta ([bbaee93](https://github.com/dropseed/plain/commit/bbaee93839))
- Simplified manager initialization by removing explicit `objects` assignment in favor of Meta configuration ([6b60a00](https://github.com/dropseed/plain/commit/6b60a00731))

### Upgrade instructions

- Replace any direct usage of `Trace.objects` with `Trace.query` in your code
- Replace any direct usage of `Span.objects` with `Span.query` in your code
- Replace any direct usage of `Log.objects` with `Log.query` in your code

## [0.6.2](https://github.com/dropseed/plain/releases/plain-observer@0.6.2) (2025-09-09)

### What's changed

- Improved traces sidebar layout by simplifying the display structure and making better use of space ([da789d19](https://github.com/dropseed/plain/commit/da789d1926))

### Upgrade instructions

- No changes required

## [0.6.1](https://github.com/dropseed/plain/releases/plain-observer@0.6.1) (2025-09-09)

### What's changed

- Log messages are now stored in their formatted form instead of as raw log records, improving display consistency and performance ([b646699](https://github.com/dropseed/plain/commit/b646699e46))
- Observer log handler now copies the formatter from the app logger to ensure consistent log formatting ([b646699](https://github.com/dropseed/plain/commit/b646699e46))
- Simplified log display template by removing redundant level display element ([b646699](https://github.com/dropseed/plain/commit/b646699e46))

### Upgrade instructions

- No changes required

## [0.6.0](https://github.com/dropseed/plain/releases/plain-observer@0.6.0) (2025-09-09)

### What's changed

- Added comprehensive log capture and display during trace recording, with logs shown in a unified timeline alongside spans ([9bfe938](https://github.com/dropseed/plain/commit/9bfe938f64))
- Added new Log model with admin interface for managing captured log entries ([9bfe938](https://github.com/dropseed/plain/commit/9bfe938f64))
- Observer now automatically enables debug logging during trace recording to capture more detailed information ([731196](https://github.com/dropseed/plain/commit/731196086f))
- Added app_name and app_version fields to trace records for better application identification ([2870636](https://github.com/dropseed/plain/commit/2870636944))
- Added span count display in trace detail views ([4d22c10](https://github.com/dropseed/plain/commit/4d22c1058d))
- Enhanced database query counting to only include queries with actual query text, providing more accurate metrics ([3d102d3](https://github.com/dropseed/plain/commit/3d102d3796))
- Improved trace limit cleanup logic to properly maintain the configured trace limit ([e9d124b](https://github.com/dropseed/plain/commit/e9d124bccd))
- Added source code location attributes support for spans with file path, line number, and function information ([da36a17](https://github.com/dropseed/plain/commit/da36a17dab))
- Updated Python version requirement to 3.13 minimum ([d86e307](https://github.com/dropseed/plain/commit/d86e307efb))

### Upgrade instructions

- No changes required

## [0.5.0](https://github.com/dropseed/plain/releases/plain-observer@0.5.0) (2025-09-03)

### What's changed

- Extended observer summary mode cookie duration from 1 day to 1 week for improved user experience ([bbe8a8a](https://github.com/dropseed/plain/commit/bbe8a8ad54))
- Changed admin navigation icon for Spans from "diagram-3" to "activity" ([2aac07d](https://github.com/dropseed/plain/commit/2aac07de4e))

### Upgrade instructions

- No changes required

## [0.4.0](https://github.com/dropseed/plain/releases/plain-observer@0.4.0) (2025-08-27)

### What's changed

- Toolbar functionality has been moved to a new `plain.toolbar` package, with observer-specific toolbar code now in a dedicated `toolbar.py` file ([e49d54b](https://github.com/dropseed/plain/commit/e49d54bfea))

### Upgrade instructions

- No changes required

## [0.3.7](https://github.com/dropseed/plain/releases/plain-observer@0.3.7) (2025-08-22)

### What's changed

- Improved admin interface code organization by reordering navigation icon and model field declarations ([5a6479a](https://github.com/dropseed/plain/commit/5a6479ac79))

### Upgrade instructions

- No changes required

## [0.3.6](https://github.com/dropseed/plain/releases/plain-observer@0.3.6) (2025-07-31)

### What's changed

- Added database index on `span_id` field in the Span model for improved query performance ([f836542](https://github.com/dropseed/plain/commit/f836542df6))
- Database tracing is now suppressed when querying for span links to prevent recursive tracing loops ([f836542](https://github.com/dropseed/plain/commit/f836542df6))

### Upgrade instructions

- No changes required

## [0.3.5](https://github.com/dropseed/plain/releases/plain-observer@0.3.5) (2025-07-30)

### What's changed

- Improved observer toolbar button text clarity for empty states - "Recording" now shows as "Recording (no summary)" and "Summary" shows as "No summary" ([143c2a6](https://github.com/dropseed/plain/commit/143c2a61a7))
- Fixed observer auto-enable functionality by adding POST handler for summary mode actions ([cc415e0](https://github.com/dropseed/plain/commit/cc415e0af7))

### Upgrade instructions

- No changes required

## [0.3.4](https://github.com/dropseed/plain/releases/plain-observer@0.3.4) (2025-07-30)

### What's changed

- Fixed URL configuration examples in installation documentation to use `ObserverRouter` instead of string path ([f55ac7d](https://github.com/dropseed/plain/commit/f55ac7d491))
- Enhanced README with table of contents, PyPI installation link, and post-installation usage instructions ([4ebecd1](https://github.com/dropseed/plain/commit/4ebecd1856))

### Upgrade instructions

- No changes required

## [0.3.3](https://github.com/dropseed/plain/releases/plain-observer@0.3.3) (2025-07-25)

### What's changed

- Added `--print` option to the `plain observer diagnose` command to print prompts without running agents ([9721331](https://github.com/dropseed/plain/commit/9721331e40))
- The `plain observer diagnose` command now uses the shared `prompt_agent` utility for better consistency ([de1fa72](https://github.com/dropseed/plain/commit/de1fa7253a))
- Added comprehensive installation instructions to the README including package installation, URL configuration, and migration steps ([950939b](https://github.com/dropseed/plain/commit/950939b619))

### Upgrade instructions

- No changes required

## [0.3.2](https://github.com/dropseed/plain/releases/plain-observer@0.3.2) (2025-07-25)

### What's changed

- The diagnose agent command now instructs the AI to examine the codebase before making suggestions ([f5ae388](https://github.com/dropseed/plain/commit/f5ae388833))

### Upgrade instructions

- No changes required

## [0.3.1](https://github.com/dropseed/plain/releases/plain-observer@0.3.1) (2025-07-23)

### What's changed

- Added delete actions to the admin interface for both Traces and Spans, allowing bulk deletion of selected items ([0d85670](https://github.com/dropseed/plain/commit/0d85670412))
- Added bootstrap icons to admin navigation (activity icon for Traces, diagram-3 icon for Spans) ([9e9f8b0](https://github.com/dropseed/plain/commit/9e9f8b0e2c))

### Upgrade instructions

- No changes required

## [0.3.0](https://github.com/dropseed/plain/releases/plain-observer@0.3.0) (2025-07-22)

### What's changed

- Database models now use the new `PrimaryKeyField` instead of `BigAutoField` for primary keys ([4b8fa6a](https://github.com/dropseed/plain/commit/4b8fa6aef1))
- Admin interface updated to use `id` instead of `pk` for ordering and references ([4b8fa6a](https://github.com/dropseed/plain/commit/4b8fa6aef1))

### Upgrade instructions

- No changes required

## [0.2.0](https://github.com/dropseed/plain/releases/plain-observer@0.2.0) (2025-07-21)

### What's changed

- Added comprehensive CLI commands for trace management including `plain observer traces`, `plain observer trace <id>`, and `plain observer spans` ([90f916b](https://github.com/dropseed/plain/commit/90f916b676))
- Added trace sharing functionality allowing traces to be shared via public URLs ([90f916b](https://github.com/dropseed/plain/commit/90f916b676))
- Added `plain observer diagnose` command with JSON and URL output options for troubleshooting ([71936e88a5](https://github.com/dropseed/plain/commit/71936e88a5))
- Improved trace detail UI with better formatting and navigation ([90f916b](https://github.com/dropseed/plain/commit/90f916b676))
- Removed the custom trace detail UI from the admin interface, now uses standard admin detail view ([0c277fc](https://github.com/dropseed/plain/commit/0c277fc076))
- Enhanced raw agent prompt output styling ([684f208](https://github.com/dropseed/plain/commit/684f2087fc))

### Upgrade instructions

- No changes required

## [0.1.0](https://github.com/dropseed/plain/releases/plain-observer@0.1.0) (2025-07-19)

### What's changed

- Initial release of plain-observer package providing OpenTelemetry-based observability and monitoring for Plain applications ([b0224d0](https://github.com/dropseed/plain/commit/b0224d0418))
- Added real-time trace monitoring with summary and persist modes via signed cookies ([b0224d0](https://github.com/dropseed/plain/commit/b0224d0418))
- Added admin interface for viewing detailed trace information and spans ([b0224d0](https://github.com/dropseed/plain/commit/b0224d0418))
- Added toolbar integration showing performance summaries for current requests ([b0224d0](https://github.com/dropseed/plain/commit/b0224d0418))
- Observer can now combine with existing OpenTelemetry trace providers instead of replacing them ([7e55779](https://github.com/dropseed/plain/commit/7e55779548))

### Upgrade instructions

- No changes required
