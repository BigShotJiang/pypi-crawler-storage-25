import json

# import logging
import pathlib
import ssl
from typing import Iterator

import httpx
from httpx import HTTPStatusError

from vault_migrate import log
from vault_migrate.config import Config, VaultConn, KVMappingSide
from vault_migrate.types import _JsonObj, _KVMountVersion

# log = logging.getLogger(__name__)


class Vault(httpx.Client):
    def __init__(self, config: VaultConn):
        verify = True  # Default: rely on TLS security measures
        if not config.tls_verify:
            verify = False
        elif config.ca_bundle_path:
            verify = ssl.create_default_context(cafile=str(config.ca_bundle_path))

        # NOTE: For consistency, we only specify namespace as a prefix to the
        # URI path, not as an HTTP header. This provides the clearest
        # visibility of what is happening when an error is encountered.
        super().__init__(
            base_url=f"{config.address}/v1",
            headers={
                # TODO: Include add'l headers for fine-tuning comms with Vault
                "X-Vault-Token": config.token,
                "X-Vault-Request": "true",
                # "Accept": "application/json",
            },
            verify=verify,
        )

    def list(self, *args, **kwargs) -> httpx.Response:
        """
        A logical list operation fronted by a custom HTTP method, LIST.

        For maximum compatibility, since some reverse proxies only support
        well-known HTTP verbs, we use the GET request with `?list=true`
        workaround as a way of making the equivalent LIST request.
        """
        if "params" in kwargs:
            kwargs["params"]["list"] = "true"
        else:
            kwargs["params"] = {"list": "true"}
        return self.get(*args, **kwargs)

    def sys_mount_read(self, *, mount_path: str = "", namespace: str = "") -> _JsonObj:
        """
        Reads details of mount information via the `sys/mounts` API. For best
        results, specify the mount path you wish to retrieve information about
        as an argument to this method instead of leaving it off and parsing all
        mount information directly.

        NOTE: For this endpoint it is EXTREMELY important to differentiate what
        is the mount path from what is the namespace. We do NOT want namespaces
        to be prefixed to paths here since it will result in different
        endpoints being invoked.
        """
        if not mount_path:
            # If retrieving all mounts in the namespace, ignore the rest of the
            # logic and keep it simple.
            resp = self.get(
                f"{namespace}/sys/mounts".replace("//", "/")
            ).raise_for_status()
            return resp.json()["data"]

        # Try the most specific mount path first, given the smaller payload and
        # clearer audit trail.
        resp = self.get(f"{namespace}/sys/mounts/{mount_path}".replace("//", "/"))
        try:
            resp.raise_for_status()
            return resp.json()["data"]
        except httpx.HTTPStatusError:
            if resp.status_code != 403:
                raise

        # Maybe we don't have permissions to `sys/mounts/{my_mount_path}` and
        # we do have permissions to `sys/mounts`.
        resp = self.get(f"{namespace}/sys/mounts".replace("//", "/")).raise_for_status()
        obj = resp.json()["data"]

        try:
            return obj[f"{mount_path.strip('/')}/"]
        except KeyError:
            raise ValueError(
                f"No mount exists at {mount_path!r} (Namespace: {namespace!r})"
            )

    def kv_walk(
        self,
        mount_path: str,
        path_prefix: str = "",
        namespace: str = "",
        kv_type: _KVMountVersion = "2",
    ) -> Iterator[str]:
        """
        Recursively list all keys in a KV mount. Entries are lazy-loaded from
        the base of `path_prefix` (if provided), returned in an arbitrary
        order.

        Supports KVv1, KVv2, or generic secrets engines
        """
        kv_prefix = path_prefix.strip("/")
        if kv_prefix == "/":
            kv_prefix = ""

        mount = "/".join([namespace, mount_path]).strip("/")
        if kv_type == "2":
            resp = self.list(f"{mount}/metadata/{kv_prefix}".replace("//", "/"))
        else:
            resp = self.list(f"{mount}/{kv_prefix}".replace("//", "/"))

        try:
            out = resp.raise_for_status().json()
        except HTTPStatusError:
            if resp.status_code == 404:
                return
            if resp.status_code == 403:
                # We must not have permission to see this, log it as an error
                # and move on.
                log.error(
                    "Unable to recurse deeper than '%s' in KV mount '%s' "
                    "(Namespace: '%s') due to a permission denied response",
                    path_prefix,
                    mount_path,
                    namespace,
                )
                return
            if resp.status_code == 400:
                try:
                    log.error("Unable to recurse deeper", details=resp.json())
                except Exception:
                    log.error("Unable to recurse deeper", details=resp.text)
            raise

        recurse_deeper = set([])
        for item in out["data"]["keys"]:
            if item[-1] == "/":
                recurse_deeper.add(item)
                continue

            yield "/".join([path_prefix.strip("/"), item])

        for path in recurse_deeper:
            child_path = f"{path_prefix}/{path}".replace("//", "/").strip("/")

            yield from self.kv_walk(
                mount_path, path_prefix=child_path, namespace=namespace, kv_type=kv_type
            )

    def kv_metadata_get(
        self,
        mount_path: str,
        path: str,
        namespace: str = "",
    ):
        resp = self.get(
            f"{namespace}/{mount_path}/metadata/{path}".replace("//", "/")
        ).raise_for_status()
        return resp.json()["data"]


class Migrator:
    """
    A context for source and destination HashiCorp Vault clients, including setup and teardown
    """

    config: Config
    _mapping: dict[str, str]

    old: Vault = None
    new: Vault = None

    def __init__(self, config: Config) -> None:
        self.config = config
        self._mapping = {}
        _ensure_base_dir(config.settings.mapping_file)

    def __enter__(self) -> "Migrator":
        log.debug("Setting up migration resources")
        self.old = Vault(self.config.settings.source)
        self.new = Vault(self.config.settings.target)

        mapping_file = self.config.settings.mapping_file
        if mapping_file.exists():
            log.debug("Reading pre-existing mapping file")
            try:
                with mapping_file.open("r") as f:
                    obj = json.load(f)
                    if obj["vault"]["source"] != self.config.settings.source.address:
                        raise ValueError
                    if obj["vault"]["target"] != self.config.settings.target.address:
                        raise ValueError
                    self._mapping = obj["paths"]
            except (ValueError, OSError, KeyError):
                log.warning(
                    "Existing map file was corrupted. Starting fresh.",
                    details=mapping_file,
                )
                self._mapping = dict()
        else:
            self._mapping = dict()

        return self

    def __exit__(self, *_) -> None:
        log.debug("Cleaning up migration resources")
        self.old.close()
        self.new.close()
        log.debug("Persisting mapped changes to file")
        with self.config.settings.mapping_file.open("w") as f:
            obj = {
                "vault": {
                    "source": self.config.settings.source.address,
                    "target": self.config.settings.target.address,
                },
                "paths": self._mapping,
            }
            json.dump(obj, f)

    def __repr__(self) -> str:
        return "<Migrator>"

    def map_change(self, old_path: str, new_path: str):
        self._mapping[old_path] = new_path


def _get_kv_version(http: Vault, config: KVMappingSide) -> _KVMountVersion:
    out = http.sys_mount_read(namespace=config.namespace, mount_path=config.mount)
    if out["type"] == "kv-v2":
        return "2"
    elif out["type"] == "kv":
        try:
            return "2" if out["options"]["version"] == "2" else "1"
        except KeyError:
            return "1"
    elif out["type"] == "generic":
        # NOTE: While there are some API differences, the obscure "generic"
        # secrets engine is close enough to KVv1 for our purposes
        log.warning(
            "Found use of the long-since deprecated 'generic' secrets engine. "
            "Please discontinue use of this feature as soon as possible."
        )
        return "1"
    else:
        raise ValueError(
            f"Unable to get KV secrets engine version for {config.mount!r} "
            f"(Namespace: {config.namespace!r}) from mount type {out['type']!r}"
        )


def _ensure_base_dir(path: pathlib.Path):
    base_dir = path.resolve().parent
    base_dir.mkdir(mode=0o755, parents=True, exist_ok=True)
