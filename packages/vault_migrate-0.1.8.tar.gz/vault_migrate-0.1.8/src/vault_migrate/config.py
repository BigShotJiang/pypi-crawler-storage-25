import pathlib
from dataclasses import dataclass, field

from vault_migrate.types import _JsonObj


@dataclass
class VaultConn:
    """
    A Vault connection block, useful for connecting ends of the secrets
    ETL process.
    """

    address: str
    token: str

    tls_verify: bool = True
    ca_bundle_path: pathlib.Path = None

    @classmethod
    def from_dict(cls, data: _JsonObj) -> "VaultConn":
        if "ca_bundle_path" in data:
            bundle_path = pathlib.Path(data)
            if not bundle_path.exists():
                raise ValueError(
                    f"Certificate Authority trust bundle not found at {bundle_path!r}"
                )
            data["ca_bundle_path"] = bundle_path.resolve()

        return cls(**data)

    def __str__(self):
        return self.address


@dataclass
class Settings:
    """
    Miscellaneous settings that fit only in the interstitial area between
    source and destination of the ETL process.
    """

    source: VaultConn
    target: VaultConn

    mapping_file: pathlib.Path = field(
        default_factory=lambda: pathlib.Path("out/mapping.json")
    )
    timeout: int = 10

    @classmethod
    def from_dict(cls, data: _JsonObj) -> "Settings":
        if "timeout" in data and data["timeout"] < 0:
            raise ValueError("Configured timeout must be greater than 0")

        if "mapping_file" in data and data["mapping_file"]:
            data["mapping_file"] = pathlib.Path(data["mapping_file"])

        data["source"] = VaultConn.from_dict(data["source"])
        data["target"] = VaultConn.from_dict(data["target"])

        return cls(**data)


@dataclass
class KVMappingSide:
    namespace: str
    mount: str
    path_prefix: str

    @classmethod
    def from_dict(cls, data: _JsonObj) -> "KVMappingSide":
        return cls(**data)

    def log_coords(self) -> _JsonObj:
        """
        Helper context for logging
        """
        out = {"mount": self.mount}
        if self.namespace:
            out["namespace"] = self.namespace
        if self.path_prefix:
            out["base_path"] = self.path_prefix
        return out
        # return "(Namespace: {ns!r}, Mount: {m!r}, Path prefix: {p!r})".format(
        #     ns=self.namespace,
        #     m=self.mount,
        #     p=self.path_prefix,
        # )


@dataclass
class KVMapping:
    source: KVMappingSide
    target: KVMappingSide

    @classmethod
    def from_dict(cls, data: _JsonObj) -> "KVMapping":
        return cls(
            source=KVMappingSide.from_dict(data["from"]),
            target=KVMappingSide.from_dict(data["to"]),
        )

    def log_coords(self) -> _JsonObj:
        """
        Helper context for logging
        """
        return {
            "from": self.source.log_coords(),
            "to": self.target.log_coords(),
        }
        # return "(Source: {src!r}, Target: {dest!r})".format(
        #     src="/".join(
        #         [self.source.namespace, self.source.mount, self.source.path_prefix]
        #     ),
        #     dest="/".join(
        #         [self.target.namespace, self.target.mount, self.target.path_prefix]
        #     ),
        # )


@dataclass
class Config:
    settings: Settings

    kv: list[KVMapping] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: _JsonObj) -> "Config":
        kv = []
        if "kv" in data and isinstance(data["kv"], list):
            for item in data["kv"]:
                kv.append(KVMapping.from_dict(item))

        return cls(
            settings=Settings.from_dict(data["settings"]),
            kv=kv,
        )
