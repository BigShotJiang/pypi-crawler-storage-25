import copy
from typing import Set

from httpx import HTTPStatusError

from vault_migrate import log
from vault_migrate.client import Migrator, Vault, _get_kv_version
from vault_migrate.config import KVMapping
from vault_migrate.types import _KVMountVersion, _KVPath, _KVPathSegments


class NotMigratedError(Exception):
    """
    A wrapper for very specific exceptions in very specific circumstances so we
    can catch them, log them with context, and recover.
    """


def _assert_path_has_prefix(path: str, prefix: str):
    """
    This is a helper function to sanity-check something that should never
    happen. If it ever does happen, make the program blow up spectacularly.
    """
    # NOTE: Do not use `assert`. https://docs.astral.sh/ruff/rules/assert/
    if not path.startswith(prefix):
        raise RuntimeError(
            "FAILED ASSERTION: expected and actual prefixes are not the same."
        )


def _kv_path_segments(
    mount: str,
    path: str,
    kv_type: _KVMountVersion,
    path_prefix: str = "",
    namespace: str = "",
    kvv2_segment: str = "data",
) -> _KVPathSegments:
    """
    Normalizes how various attributes get joined together into a URI segment,
    allowing `"/".join(parts)` to be used on it.
    """
    return (
        list(filter(bool, [namespace, mount])),  # Before KVv2 identifier
        kvv2_segment if kv_type == "2" else "",
        list(filter(bool, [path_prefix, path])),  # After KVv2 identifier
    )


def _kv_path_join(segments: _KVPathSegments, kvv2_segment: str = "data") -> str:
    """
    Joins the output of `_kv_path_segments()` into a cohesive string
    """
    parts = list(copy.copy(segments))
    if parts[1]:
        parts[1] = kvv2_segment
    uri_parts = filter(bool, ["/".join(parts[0]), parts[1], "/".join(parts[2])])
    uri = "/".join(uri_parts).replace("//", "/").lstrip("/")
    return uri


def _kv_path_formatter(*args, **kwargs) -> str:
    """
    Helper function that composes and normalizes the URI for a Vault path,
    specifically around KV engine usage. The result should be a string that
    meets the following criteria:

    1. No leading or trailing "/" characters
    2. No more than 1 consecutive "/" character
    3. Includes the KVv2 path segment (e.g., "data", "subkeys") only if KVv2
       engine is targetted, else removes this segment for KVv1 support.
    """
    return _kv_path_join(_kv_path_segments(*args, **kwargs))


def migrate_kv_entry(
    path: str,
    http_src: Vault,
    http_dest: Vault,
    segments_src: _KVPathSegments,
    segments_dest: _KVPathSegments,
    type_src: _KVMountVersion,
    type_dest: _KVMountVersion,
) -> None:
    """
    Migrates a single KV entry from source to target.
    """

    try:
        if type_src == "2":
            # Get metadata to know what versions need to be migrated
            log.debug("Reading metadata")
            resp = http_src.get(_kv_path_join(segments_src, "metadata"))
            meta = resp.raise_for_status().json()["data"]
            del resp

            skip_versions, all_versions = set([]), set([])
            for version, data in meta["versions"].items():
                all_versions.add(int(version))
                if data["destroyed"]:
                    skip_versions.add(int(version))
                elif "deletion_time" in data and data["deletion_time"]:
                    skip_versions.add(int(version))

            if type_dest == "1" and len(skip_versions) != len(all_versions):
                # Start with _something_ as the latest version, initially
                latest = all_versions[0]
                # Skip all but the latest version, since KVv1 doesn't have versions
                for version in all_versions:
                    if latest == version:
                        continue
                    if latest < version:
                        skip_versions.add(latest)
                        latest = version
                        continue

            active_versions = [x for x in all_versions if x not in skip_versions]

            # Push versions to destination
            for i, version in enumerate(active_versions):
                log.debug("Reading secret data", details={"version": version})
                resp = http_src.get(
                    _kv_path_join(segments_src, "data"),
                    params={"version": str(version)},
                )
                old = resp.raise_for_status().json()["data"]

                if type_dest == "1":
                    log.debug("Writing secret data")
                    http_dest.post(
                        _kv_path_join(segments_dest, "data"), json=old["data"]
                    ).raise_for_status()
                elif type_dest == "2":
                    log.debug("Writing secret data", details={"version": i})
                    http_dest.post(
                        _kv_path_join(segments_dest, "data"),
                        json={
                            "options": {"cas": i},
                            "data": old["data"],
                        },
                    ).raise_for_status()

            if type_dest == "2":
                target = {}
                if "max_versions" in meta:
                    target["max_versions"] = meta["max_versions"]
                if "cas_required" in meta:
                    target["cas_required"] = meta["cas_required"]
                if "delete_version_after" in meta:
                    target["delete_version_after"] = meta["delete_version_after"]
                if "custom_metadata" in meta:
                    target["custom_metadata"] = copy.copy(meta["custom_metadata"])
                log.debug("Migrating metadata and settings", details=target)
                http_dest.post(
                    _kv_path_join(segments_dest, "metadata"), json=target
                ).raise_for_status()

        elif type_src == "1":
            log.debug("Reading secret data")
            resp = http_src.get(_kv_path_join(segments_src, "data"))
            old = resp.raise_for_status().json()["data"]
            del resp

            if type_dest == "1":
                log.debug("Writing secret data")
                http_dest.post(
                    _kv_path_join(segments_dest, "data"), json=old
                ).raise_for_status()
            elif type_dest == "2":
                log.debug("Writing secret data", details={"version": 1})
                http_dest.post(
                    _kv_path_join(segments_dest, "data"),
                    json={
                        "options": {"cas": 0},
                        "data": old,
                    },
                ).raise_for_status()

    except HTTPStatusError as e:
        raise NotMigratedError() from e


def migrate_kv(action: Migrator, mapping: KVMapping):
    """
    For use with a context manager around an instance of `Migrator`, used to
    migrate any KV entries
    """
    # have_warned_of_recourse_for_already_migrated = False

    # Verify mount types by calling `sys/mount/{mount_path}` and reading the
    # mount type
    type_src = _get_kv_version(http=action.old, config=mapping.source)
    type_dest = _get_kv_version(http=action.new, config=mapping.target)
    log.info(
        "Migrating KV mount",
        details={
            "from": {
                "vault": action.old.base_url,
                "kv_version": type_src,
                **mapping.source.log_coords(),
            },
            "to": {
                "vault": action.new.base_url,
                "kv_version": type_dest,
                **mapping.target.log_coords(),
            },
        },
    )

    log.info("Enumerating already migrated secrets")
    exists_at_dest: Set[_KVPath] = set([])
    for path in action.new.kv_walk(
        mount_path=mapping.target.mount,
        path_prefix=mapping.target.path_prefix,
        namespace=mapping.target.namespace,
        kv_type=type_dest,
    ):
        # Trim known path prefix
        _assert_path_has_prefix(path, mapping.target.path_prefix)
        sanitized_path = path[len(mapping.target.path_prefix) :]

        # Add the path under the path_prefix to a manifest of already-migrated
        # paths to secrets
        exists_at_dest.add(sanitized_path)

    log.info("Enumerating secrets to be migrated")
    for path in action.old.kv_walk(
        mount_path=mapping.source.mount,
        path_prefix=mapping.source.path_prefix,
        namespace=mapping.source.namespace,
        kv_type=type_src,
    ):
        # Trim known path prefix
        _assert_path_has_prefix(path, mapping.source.path_prefix)
        sanitized_path: _KVPath = path[len(mapping.source.path_prefix) :]

        segments_src = _kv_path_segments(
            namespace=mapping.source.namespace,
            mount=mapping.source.mount,
            path_prefix=mapping.source.path_prefix,
            path=sanitized_path,
            kv_type=type_src,
        )
        segments_dest = _kv_path_segments(
            namespace=mapping.target.namespace,
            mount=mapping.target.mount,
            path_prefix=mapping.target.path_prefix,
            path=sanitized_path,
            kv_type=type_dest,
        )

        if sanitized_path in exists_at_dest:
            log.warning(
                "Secret has already been migrated. To refresh, delete it and rerun the migration",
                details={
                    "command": f"vault delete {
                        _kv_path_join(segments_dest, 'metadata')
                    }",
                },
            )
            action.map_change(
                old_path=_kv_path_join(segments_src, "data"),
                new_path=_kv_path_join(segments_dest, "data"),
            )
            continue

        try:
            log.info("Migrating secret", details=sanitized_path)
            migrate_kv_entry(
                path=sanitized_path,
                http_src=action.old,
                http_dest=action.new,
                segments_src=segments_src,
                segments_dest=segments_dest,
                type_src=type_src,
                type_dest=type_dest,
            )
            log.info("Secret successfully migrated", details=sanitized_path)
            action.map_change(
                old_path=_kv_path_join(segments_src, "data"),
                new_path=_kv_path_join(segments_dest, "data"),
            )
        except NotMigratedError:
            log.error(
                "Unable to migrate secret", details=sanitized_path, print_exception=True
            )

    log.info("Migration complete")
