import json

from vault_migrate import log
from vault_migrate.config import Config
from vault_migrate.client import Migrator
from vault_migrate.kv_migrate import migrate_kv


def run(config_file: str):
    log.info("Starting migration")
    with open(config_file, "r") as f:
        config = Config.from_dict(json.load(f))

    with Migrator(config) as action:
        for mapping in config.kv:
            migrate_kv(action, mapping)

    log.info("Migration complete")
