from typing import Any, Literal, Tuple, Union

_JsonObj = dict[str, Any]
_KVMountVersion = Union[Literal["1"], Literal["2"]]
_KVPath = str
_KVPathSegments = Tuple[list[str], str, list[str]]
