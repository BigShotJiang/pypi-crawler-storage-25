#!/usr/bin/env python3

# import logging
import sys

from vault_migrate.run import run


def main():
    # logging.basicConfig()
    # logging.getLogger('vault_migrate').setLevel(logging.DEBUG)
    run(sys.argv[1])


if __name__ == "__main__":
    main()
