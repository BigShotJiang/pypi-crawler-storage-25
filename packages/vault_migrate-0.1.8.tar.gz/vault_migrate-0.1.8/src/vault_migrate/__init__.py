from pretty_pie_log import PieLogger, PieLogLevel

log = PieLogger(
    logger_name="vault_migrate",
    minimum_log_level=PieLogLevel.INFO,
    # log_to_file=True,
    global_context=False,
)
