"""
NoneBot2 森空岛 COS 图插件
通过森空岛社区 API 获取明日方舟同人板块帖子中的图片并随机发送

使用:
  /cos            随机发送一张COS图
  /cos 3          随机发送3张COS图 (最多9张)
  /cos 雷电将军    搜索含关键词的COS图
  /cos 雷电将军 3  搜索关键词并发送3张

配置 (在 .env 中填写):
  SKLAND_CRED=你的森空岛 cred token
  SKLAND_DID=你的 Shumei 设备ID (可选，不填会用通用值)

获取方式: 浏览器登录 www.skland.com → F12 → Application → Local Storage:
  - SKLAND_CRED: 取 SK_OAUTH_CRED_KEY 的值
  - SKLAND_DID:  取 SK_SHUMEI_DEVICE_ID_KEY 的 id 字段的值
"""

import json
import hmac
import hashlib
import random
import string
import time

import httpx
from nonebot import get_plugin_config, on_command, logger, get_driver
from nonebot.adapters.onebot.v11 import MessageSegment, Message, Bot, Event
from nonebot.params import CommandArg
from nonebot.plugin import PluginMetadata
from pydantic import BaseModel


class Config(BaseModel):
    skland_cred: str = ""
    skland_did: str = ""


__plugin_meta__ = PluginMetadata(
    name="森空岛COS图",
    description="从森空岛社区获取明日方舟COS图并随机发送",
    usage="/cos  - 随机发送一张COS图\n/cos 3 - 随机发送3张COS图(最多9张)\n/cos 关键词 - 搜索含关键词的COS图\n/cos 关键词 3 - 搜索关键词并发送3张",
    type="application",
    homepage="",
    supported_adapters={"~onebot.v11"},
    config=Config,
)

plugin_config = get_plugin_config(Config)

# ===================== 配置 =====================

BASE_URL = "https://zonai.skland.com"
GAME_ID = "1"   # 明日方舟
CATE_ID = "3"   # 同人板块
PAGE_SIZE = 50
TIMEOUT = 15
MAX_IMAGES = 9
PLATFORM = "3"
V_NAME = "1.0.0"

_BASE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Referer": "https://www.skland.com/",
    "Accept": "application/json, text/plain, */*",
    "Origin": "https://www.skland.com",
}

# 运行时缓存的签名 token（通过 /web/v1/auth/refresh 获取）
_sign_token: str = ""

# tag 名称 → tag ID 缓存（从 tag/index 帖子的顶层 tags 字段积累）
_tag_cache: dict[str, int] = {}
_tag_cache_seeded: bool = False


# ===================== 签名工具 =====================

def _make_sign(token: str, did: str, path: str, method: str,
               query: str, body: str, ts: str) -> str:
    """
    Skland 请求签名算法（逆向自前端 JS）:
    sign = MD5( HMAC-SHA256(token, path + query/body + ts + JSON_headers) )
    JSON_headers = {"platform":"3","timestamp":ts,"dId":did,"vName":"1.0.0"}
    """
    msg = path
    msg += (query or "") if method.upper() == "GET" else (body or "")
    msg += ts
    hdr: dict = {}
    for k, v in [("platform", PLATFORM), ("timestamp", ts), ("dId", did), ("vName", V_NAME)]:
        if v:
            hdr[k] = v
    msg += json.dumps(hdr, separators=(",", ":"))
    raw = hmac.new(token.encode(), msg.encode(), hashlib.sha256).hexdigest()
    return hashlib.md5(raw.encode()).hexdigest()


async def _refresh_token(client: httpx.AsyncClient, cred: str) -> str:
    """调用 /web/v1/auth/refresh 获取新的 sign token"""
    global _sign_token
    try:
        resp = await client.get(
            f"{BASE_URL}/web/v1/auth/refresh",
            headers={**_BASE_HEADERS, "cred": cred},
            timeout=TIMEOUT,
        )
        data = resp.json()
        if data.get("code") == 0:
            _sign_token = data["data"]["token"]
            logger.info(f"[skland_cos] sign token 刷新成功: {_sign_token[:12]}...")
        else:
            logger.warning(f"[skland_cos] token 刷新失败: {data.get('message')}")
    except Exception as e:
        logger.warning(f"[skland_cos] token 刷新异常: {e}")
    return _sign_token


async def _signed_get(client: httpx.AsyncClient, cred: str, did: str,
                      path: str, params: dict) -> dict:
    """发送带签名的 GET 请求，token 过期时自动刷新一次"""
    global _sign_token

    async def _do_request(token: str) -> httpx.Response:
        req = client.build_request("GET", f"{BASE_URL}{path}", params=params)
        query = str(req.url).split("?", 1)[1] if "?" in str(req.url) else ""
        ts = str(int(time.time()))
        sign = _make_sign(token, did, path, "GET", query, "", ts)
        headers = {
            **_BASE_HEADERS,
            "cred": cred,
            "platform": PLATFORM,
            "vName": V_NAME,
            "timestamp": ts,
            "dId": did,
            "sign": sign,
        }
        return await client.get(f"{BASE_URL}{path}", params=params, headers=headers)

    if not _sign_token:
        await _refresh_token(client, cred)

    resp = await _do_request(_sign_token)
    data = resp.json()

    # code=10000 表示 token 失效，刷新后重试一次
    if data.get("code") == 10000:
        logger.info("[skland_cos] token 失效，自动刷新重试")
        await _refresh_token(client, cred)
        resp = await _do_request(_sign_token)
        data = resp.json()

    return data


driver = get_driver()


@driver.on_startup
async def _init_token() -> None:
    cred = plugin_config.skland_cred
    if not cred:
        logger.warning("[skland_cos] 未配置 SKLAND_CRED，插件将无法工作")
        return
    async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
        await _refresh_token(client, cred)
        # 预热 tag 缓存：拉一页 cosplay 板块帖子，从中提取角色名→tagId 映射
        await _seed_tag_cache(client, cred, plugin_config.skland_did or "")


# ===================== API 层 =====================

# cosplay 板块 tagId，用于启动时预热 tag 名称缓存
_COSPLAY_TAG_ID = 451

def _random_list_id() -> str:
    """生成 16 位随机字母数字 listId（分页游标）"""
    return "".join(random.choices(string.ascii_letters + string.digits, k=16))


def _absorb_tags(tags: list) -> None:
    """将 tag/index 返回的帖子顶层 tags 列表吸收进缓存"""
    global _tag_cache
    for t in tags:
        if isinstance(t, dict):
            tid = t.get("id")
            name = t.get("name", "")
            if tid and name:
                _tag_cache[name.lower()] = int(tid)


def _extract_images_from_post_list(post_list: list) -> list[dict]:
    """从 tag/index 帖子列表提取图片，同时更新 tag 缓存"""
    result: list[dict] = []
    for entry in post_list:
        if not isinstance(entry, dict):
            continue
        # 顶层 tags 含 {id, name}，吸收进缓存
        _absorb_tags(entry.get("tags", []))
        user = entry.get("user", {})
        author = user.get("nickname", user.get("name", "")) if isinstance(user, dict) else ""
        item = entry.get("item", {})
        if not isinstance(item, dict):
            continue
        post_id = item.get("id", "")
        post_url = f"https://www.skland.com/article?id={post_id}" if post_id else ""
        title = item.get("title", "") or ""
        tag_names = [t.get("name", "") for t in entry.get("tags", []) if isinstance(t, dict)]
        img_slice = item.get("imageListSlice", [])
        for img in img_slice:
            url = img.get("url", "") if isinstance(img, dict) else str(img)
            if url and url.startswith("http"):
                result.append({
                    "url": url,
                    "author": author,
                    "post_url": post_url,
                    "title": title,
                    "tags": tag_names,
                })
    return result


async def _fetch_tag_index_page(
    client: httpx.AsyncClient, cred: str, did: str, tag_id: int, list_id: str
) -> tuple[list[dict], bool]:
    """拉一页 tag/index，返回 (post_list, has_more)"""
    data = await _signed_get(
        client, cred, did,
        "/web/v1/tag/index",
        {
            "tagId": str(tag_id),
            "sortType": "1",
            "pageSize": "10",
            "listId": list_id,
            "gameId": "0",
        },
    )
    if data.get("code") != 0:
        logger.warning(f"[skland_cos] tag/index code={data.get('code')} msg={data.get('message')}")
        return [], False
    payload = data.get("data", {})
    return payload.get("list", []), bool(payload.get("hasMore"))


async def _seed_tag_cache(client: httpx.AsyncClient, cred: str, did: str) -> None:
    """预热：从 cosplay 板块拉 5 页帖子，把出现的 tag name→id 存入缓存（只执行一次）"""
    global _tag_cache_seeded
    if _tag_cache_seeded:
        return
    list_id = _random_list_id()
    for _ in range(5):
        posts, has_more = await _fetch_tag_index_page(client, cred, did, _COSPLAY_TAG_ID, list_id)
        if not posts:
            break
        _extract_images_from_post_list(posts)  # 触发 _absorb_tags
        if not has_more:
            break
    _tag_cache_seeded = True
    logger.info(f"[skland_cos] tag 缓存预热完成，已知 {len(_tag_cache)} 个 tag")


def _lookup_tag_id(keyword: str) -> int | None:
    """在缓存中查找 keyword 对应的 tagId，优先精确匹配，次之子串匹配"""
    kw = keyword.lower().strip()
    if kw in _tag_cache:
        return _tag_cache[kw]
    for name, tid in _tag_cache.items():
        if kw == name:
            return tid
    for name, tid in _tag_cache.items():
        if kw in name:
            return tid
    return None


async def fetch_cos_images(keyword: str = "") -> list[dict]:
    """
    从森空岛同人板块拉取帖子图片
    keyword: 可选关键词，先从 tag 缓存查 tagId 走角色板块，未命中则 feed/index 文本匹配
    返回: [{"url": str, "author": str, "post_url": str, "title": str, "tags": list}, ...]
    """
    cred = plugin_config.skland_cred
    if not cred:
        return []

    did = plugin_config.skland_did or ""

    async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as client:
        # ── 有关键词：查 tag 缓存 ──
        if keyword:
            tag_id = _lookup_tag_id(keyword)

            # 缓存未命中：拉一轮 cosplay tag 补充缓存再试
            if tag_id is None:
                await _seed_tag_cache(client, cred, did)
                tag_id = _lookup_tag_id(keyword)

            if tag_id is not None:
                logger.info(f"[skland_cos] 关键词={keyword!r} → tagId={tag_id}，使用 tag/index")
                result: list[dict] = []
                list_id = _random_list_id()
                for _ in range(5):
                    posts, has_more = await _fetch_tag_index_page(client, cred, did, tag_id, list_id)
                    if not posts:
                        break
                    result.extend(_extract_images_from_post_list(posts))
                    if not has_more:
                        break
                if result:
                    logger.info(f"[skland_cos] tag={tag_id} 共获取 {len(result)} 张图片")
                    return result
                logger.info("[skland_cos] tag/index 无图片，回落到 feed/index")

        # ── 无关键词 或 tag 未命中：feed/index ──
        limit = PAGE_SIZE * 2 if keyword else PAGE_SIZE
        data = await _signed_get(
            client, cred, did,
            "/web/v1/feed/index",
            {"gameId": GAME_ID, "cateId": CATE_ID, "limit": str(limit)},
        )

        if data.get("code") != 0:
            logger.warning(f"[skland_cos] feed/index code={data.get('code')} msg={data.get('message')}")
            return []

        payload = data.get("data", {})
        post_list = []
        for key in ("list", "posts", "items"):
            v = payload.get(key)
            if isinstance(v, list) and v:
                post_list = v
                break

        result = []
        for entry in post_list:
            user = entry.get("user", {})
            author = user.get("nickname", user.get("name", ""))
            item = entry.get("item", {})
            post_id = item.get("id", "")
            post_url = f"https://www.skland.com/article?id={post_id}" if post_id else ""
            title = item.get("title", "") or ""
            content = item.get("content", "") or ""
            if isinstance(content, dict):
                content = content.get("text", content.get("html", "")) or ""

            if keyword:
                kw = keyword.lower()
                if not (kw in title.lower() or kw in author.lower() or kw in content.lower()):
                    continue

            img_slice = item.get("imageListSlice", [])
            for img in img_slice:
                url = img.get("url", "") if isinstance(img, dict) else str(img)
                if url and url.startswith("http"):
                    result.append({
                        "url": url,
                        "author": author,
                        "post_url": post_url,
                        "title": title,
                        "tags": [],
                    })

    logger.info(f"[skland_cos] 关键词={keyword!r} 共获取 {len(result)} 张图片")
    return result


# ===================== 指令 =====================

cos_cmd = on_command(
    "cos",
    aliases={"skcos", "方舟cos", "森空岛cos"},
    priority=10,
    block=True,
)


@cos_cmd.handle()
async def handle_cos(bot: Bot, event: Event, args: Message = CommandArg()) -> None:
    num = 1
    keyword = ""
    text = args.extract_plain_text().strip()

    if text:
        parts = text.split()
        # 最后一个 token 是纯数字则视为数量，其余为关键词
        if parts[-1].isdigit():
            num = int(parts[-1])
            keyword = " ".join(parts[:-1])
        else:
            keyword = text

    num = max(1, min(num, MAX_IMAGES))

    hint = f"正在从森空岛搜索「{keyword}」的COS图, 请稍候~" if keyword else "正在从森空岛获取COS图, 请稍候~"
    await cos_cmd.send(hint)

    try:
        images = await fetch_cos_images(keyword)
    except Exception as e:
        logger.exception("[skland_cos] fetch error")
        await cos_cmd.finish(f"获取失败: {e}")
        return

    if not images:
        if not plugin_config.skland_cred:
            await cos_cmd.finish(
                "未配置森空岛账号\n"
                "请在 .env 中添加:\n"
                "  SKLAND_CRED=SK_OAUTH_CRED_KEY 的值\n"
                "  SKLAND_DID=SK_SHUMEI_DEVICE_ID_KEY 的 id 字段\n"
                "获取方式: 登录 www.skland.com → F12 → Application → Local Storage"
            )
        elif keyword:
            await cos_cmd.finish(f"没有找到关键词「{keyword}」相关的COS图 orz\n换个关键词试试？")
        else:
            await cos_cmd.finish(
                "没有获取到COS图 orz\n"
                "可能是 cred 已过期，请重新获取 SKLAND_CRED"
            )
        return

    selected = random.sample(images, min(num, len(images)))

    async def _download_image(url: str) -> bytes | None:
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT, verify=False) as c:
                r = await c.get(url, headers={"Referer": "https://www.skland.com/"})
                if r.status_code == 200:
                    return r.content
        except Exception:
            pass
        return None

    if num == 1:
        img = selected[0]
        data = await _download_image(img["url"])
        parts: list[str] = []
        if img["author"]:
            parts.append(f"作者: {img['author']}")
        if img["post_url"]:
            parts.append(img["post_url"])
        footer = ("\n" + "\n".join(parts)) if parts else ""
        if data:
            msg = MessageSegment.image(data)
            if footer:
                msg += MessageSegment.text(footer)
            await cos_cmd.finish(msg)
        else:
            await cos_cmd.finish(f"图片获取失败，链接: {img['url']}{footer}")
    else:
        for img in selected:
            data = await _download_image(img["url"])
            if data:
                await cos_cmd.send(MessageSegment.image(data))
            else:
                await cos_cmd.send(f"[图片获取失败] {img['url']}")
        authors = list({i["author"] for i in selected if i["author"]})
        footer = "来源: 森空岛 同人板块"
        if authors:
            footer += f" | {', '.join(authors[:3])}"
        await cos_cmd.finish(footer)
