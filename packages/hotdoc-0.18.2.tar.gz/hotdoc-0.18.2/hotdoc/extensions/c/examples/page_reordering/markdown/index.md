# Simple C example
