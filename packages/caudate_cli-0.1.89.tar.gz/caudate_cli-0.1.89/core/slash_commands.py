"""Slash commands — in-conversation UX layer.

Mirrors Claude Code's `/cmd` ergonomics so operations a user reaches for
mid-chat (clear history, switch model, see cost, export, list tools) are
one keystroke away instead of an exit-and-relaunch.

Each handler takes `(ctx, args)` where `ctx` is a small object exposing
the running CognosAgent + console + helpers, and `args` is the raw
argument string after the command name. Handlers return a string the
REPL prints, or None to suppress output. Returning the sentinel
`SlashResult.QUIT` ends the session.
"""

from __future__ import annotations

import logging
import shlex
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from rich.console import Console
from rich.table import Table

logger = logging.getLogger(__name__)


class SlashResult(str, Enum):
    QUIT = "__quit__"
    RESET = "__reset__"


@dataclass
class ChatAsUser:
    """A slash handler can return this to inject text as the user's
    next chat message (instead of just printing a string). Used by
    custom command files: `/prime-context` renders the template,
    prompts for placeholders, and dispatches the result through the
    agent loop.
    """
    text: str


@dataclass
class SlashContext:
    agent: Any                 # CognosAgent
    console: Console
    settings: Any | None = None     # Settings


HandlerFn = Callable[[SlashContext, str], Any]


# ---- handlers -------------------------------------------------------

# Per-command (signature, description). Looked up by both the help
# table and the prompt_toolkit completer dropdown.
COMMAND_HELP: list[tuple[str, str]] = [
    # Core session
    ("/help", "Show the full slash-command palette with descriptions and argument syntax."),
    ("/quit, /exit, /q", "End the session cleanly — saves the conversation transcript before exiting."),
    ("/clear, /reset", "Wipe the working conversation history without losing the session file."),
    ("/compact", "Force a context-window compaction now (instead of waiting for the threshold)."),
    ("/save", "Force-save the session transcript to disk immediately."),
    ("/resume [id]", "Resume a prior session — no arg lists recent sessions to pick from."),
    ("/retry", "Replay the last user message — useful after switching model or tweaking settings."),
    # Models + routing
    ("/model [id|fast|balanced|powerful]", "Switch the active LLM — accepts a model id (ollama/glm-5.1:cloud) or a preset."),
    ("/system1 <id|preset>", "Set or swap the System-1 brain — the fast model used for simple turns."),
    ("/system2 <id|preset>", "Set or swap the System-2 brain — the slow/reasoning model for hard turns."),
    ("/router", "Show the current dual-brain routing snapshot — which model wins on which turn."),
    ("/fast on|off", "Toggle fast mode — pins routing to System 1 only, skipping the slow model."),
    ("/effort <low|medium|high>", "Set reasoning effort budget — affects thinking tokens and retry behavior."),
    ("/think on|off", "Toggle chain-of-thought reasoning for the next turns (when the model supports it)."),
    # Tools / capabilities
    ("/tools", "List every registered tool with its description and current permission state."),
    ("/skills", "List loaded skills and their trigger phrases — from ~/.caudate/skills/."),
    ("/agents", "List active subagents and their trust scopes — for inspection/debugging."),
    ("/mcp", "List configured MCP servers and whether each is currently reachable."),
    ("/hooks", "Show registered hooks (pre/post tool, on-error) and their config paths."),
    # Setup + maintenance
    ("/init", "Re-run the first-launch setup wizard — pick models, redownload Caudate weights."),
    ("/doctor", "Diagnose what's wired and what's missing — settings, Ollama, Caudate, keys."),
    ("/update", "Self-update — runs `pip install -U caudate-cli` and reports the new version."),
    ("/update-caudate", "Pull the latest Caudate weights from HuggingFace into ~/.caudate/nn/."),
    ("/config", "Open ~/.caudate/settings.json in your $EDITOR (or print path if no editor set)."),
    # Sessions + files
    ("/sessions", "List saved sessions on disk — resume any with `caudate --resume <id>`."),
    ("/export <md|json|html> [path]", "Export the current session transcript to markdown, JSON, or HTML."),
    ("/copy [n]", "Copy the n-th most recent assistant response to the clipboard (default: latest)."),
    ("/files [list|delete <id>]", "Manage uploaded files (PDFs, images) in the Files API store."),
    ("/add-dir <path>", "Add a directory to the working context — its contents become @-referenceable."),
    ("/branch [name]", "Create a git branch from the current conversation's working tree."),
    ("/worktree [list|enter <id>|exit]", "Manage git worktrees — isolate work in a sibling checkout."),
    # Diagnostics
    ("/status", "Print a one-line status: model, session, token budget, mood, Caudate trust."),
    ("/cost", "Show token + USD usage so far, broken down by model and turn."),
    ("/context", "Visualize current context-window usage as a coloured bar — when to /compact."),
    ("/diff <path>", "Diff a file against its on-disk state — see what the agent has changed but not saved."),
    ("/debug on|off", "Enable verbose logging for this session and dump the log path."),
    # Memory + personality
    ("/memory", "Show what Caudate remembers about you — opens MEMORY.md in $EDITOR."),
    ("/remember <fact>", "Append a fact to MEMORY.md — Caudate will recall it in future sessions."),
    ("/personality", "Show identity + current mood + inner-voice state for the personality layer."),
    ("/caudate [status|train|reload|on|off]", "Inspect or control the Caudate neural router — trust level, training, on/off."),
    # Live ops
    ("/cron list", "List scheduled recurring prompts. Use `caudate cron add/remove` to manage."),
    ("/loop <interval> <prompt>", "Run a prompt on a recurring interval until you /stop — like cron but session-scoped."),
    ("/bg list|watch <id>|kill <id>", "Manage background tasks — list running, tail one's output, or kill it."),
    ("/notify <msg>", "Send a desktop notification (libnotify / osascript) — handy as an inline reminder."),
    # IO modes
    ("/voice [loop]", "Drop into voice mode — mic captures speech, Kokoro/Piper speaks the reply. Say 'stop' to exit."),
    ("/serve [start|stop|status]", "Start the FastAPI HTTP server in-process so Open WebUI / IDE plugins can talk to this session."),
    ("/permissions [mode]", "Show or change permission mode: default | plan | accept_edits | bypass."),
    ("/feedback", "Print where to file feedback or bugs (GitHub issues + email)."),
    ("/goal <text>", "Set a persistent goal for the session — appended to the system prompt."),
    ("/sudo-forget", "Forget the cached sudo password (next sudo will re-prompt)."),
    ("/cost", "Show session token usage and cost breakdown by model."),
    ("/commands", "List custom command files discovered in ~/.config/caudate/commands/ and ./.caudate/commands/."),
    ("/reload-commands", "Re-scan command directories now (otherwise auto-refreshed every ~2s)."),
]


def description_for(name: str) -> str:
    """Lookup a one-line description for a slash command by its bare name
    (no leading `/`). Used by the prompt completer to render meta hints.
    Returns "" if unknown."""
    target = name.lstrip("/").lower()
    for signature, desc in COMMAND_HELP:
        # signature is e.g. "/quit, /exit, /q" — extract the names
        names = [
            p.strip().lstrip("/").split()[0].lower()
            for p in signature.split(",")
        ]
        if target in names:
            return desc
    # Fall through to user/project custom command files.
    try:
        from core.custom_commands import discover
        cmd = discover().get(target)
        if cmd is not None:
            tag = "[project]" if cmd.source == "project" else "[user]"
            return f"{tag} {cmd.description}" if cmd.description else tag
    except Exception:
        pass
    return ""


def _help(ctx: SlashContext, args: str) -> str:
    table = Table(title="Slash commands", show_header=False, box=None)
    for cmd, desc in COMMAND_HELP:
        table.add_row(f"[bold cyan]{cmd}[/bold cyan]", desc)
    ctx.console.print(table)
    return ""


def _quit(ctx: SlashContext, args: str) -> Any:
    return SlashResult.QUIT


def _clear(ctx: SlashContext, args: str) -> Any:
    ctx.agent.reset_conversation()
    ctx.console.print("[yellow]Conversation reset.[/yellow]")
    return SlashResult.RESET


def _compact(ctx: SlashContext, args: str) -> str:
    import asyncio
    loop = asyncio.get_event_loop()
    if hasattr(ctx.agent, "compactor") and ctx.agent.compactor is not None:
        before = len(ctx.agent.agentic.messages)
        new_msgs = loop.run_until_complete(
            ctx.agent.compactor.compact(ctx.agent.agentic.messages)
        )
        ctx.agent.agentic.messages = new_msgs
        return f"Compacted {before} → {len(new_msgs)} messages."
    return "Compaction not configured."


def _model(ctx: SlashContext, args: str) -> str:
    """`/model` opens an interactive picker; `/model <id>` switches directly.

    In dual-brain mode the picker is two-step: pick the model, then pick
    which slot (S1, S2, or both) to assign it to. In single-brain mode
    the picker just switches the active model.
    """
    new_id = args.strip()
    if new_id:
        return _do_switch(ctx, new_id)

    # No args → interactive picker. The slash dispatcher runs between
    # turns (no active event loop) so asyncio.run is safe here.
    import asyncio
    from llm.models import ModelRegistry
    from llm.router import DualLLMProvider

    reg = ModelRegistry()
    try:
        asyncio.run(reg.refresh())
    except Exception as e:
        return f"[red]model registry refresh failed: {e}[/red]"

    models = sorted(reg.models(), key=lambda m: (m.provider, m.name))
    if not models:
        return "[yellow]No models detected. Is Ollama running?[/yellow]"

    dual = isinstance(ctx.agent.llm, DualLLMProvider)
    s1_id = ctx.agent.llm.fast_model if dual else None
    s2_id = ctx.agent.llm.slow_model if dual else None
    last_used_id = ctx.agent.llm.last_provider_model if dual else None
    primary_id = None if dual else ctx.agent.llm.model

    # One-line summary at the top — no big table; the picker is the
    # canonical UI for selection now.
    if dual:
        ctx.console.print(
            f"  [dim]S1:[/dim] [cyan]{s1_id}[/cyan]   "
            f"[dim]S2:[/dim] [magenta]{s2_id}[/magenta]"
            + (f"   [dim]last →[/dim] [bold yellow]{last_used_id}[/bold yellow]"
               if last_used_id else "")
        )
    else:
        ctx.console.print(f"  [dim]model:[/dim] [green]{primary_id}[/green]")

    # Step 1 — pick a model. Inline `ctx` (context window) and `size`
    # (on-disk for local models) so the user can compare at a glance.
    def _fmt_ctx(n: int) -> str:
        if not n:
            return "—"
        if n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        if n >= 1000:
            return f"{n // 1000}K"
        return str(n)

    def _fmt_size(b: int) -> str:
        if not b:
            return "—"
        gb = b / (1024 ** 3)
        if gb >= 1:
            return f"{gb:.1f}GB"
        mb = b / (1024 ** 2)
        return f"{mb:.0f}MB"

    # Compute column widths so labels line up.
    id_col_w = min(48, max((len(m.id) for m in models), default=20))

    options: list[tuple[str, str]] = []
    for m in models:
        tag = ""
        if m.id == s1_id:
            tag = "[cyan]S1[/cyan]"
        elif m.id == s2_id:
            tag = "[magenta]S2[/magenta]"
        elif m.id == primary_id:
            tag = "[green]●[/green]"
        tool_glyph = "🛠" if m.supports_tool_calling else "  "
        label = (
            f"{m.id:<{id_col_w}}  "
            f"[dim]{_fmt_ctx(m.context_window):>6}[/dim] "
            f"[dim]{_fmt_size(m.size_bytes):>7}[/dim] "
            f"{tool_glyph}  {tag}"
        )
        options.append((label, m.id))
    for preset in ("fast", "balanced", "powerful"):
        options.append((f"[dim]preset:[/dim] {preset}", preset))

    picked_id = _pick_model_interactive(
        title="Select model",
        options=options,
    )
    if picked_id is None:
        return ""

    # Single-brain → just switch the primary.
    if not dual:
        return _do_switch(ctx, picked_id)

    # Step 2 (dual-brain) — pick which slot to assign to.
    slot_options = [
        (f"S1 (fast)   [dim]— currently {s1_id}[/dim]",   "system1"),
        (f"S2 (slow)   [dim]— currently {s2_id}[/dim]",   "system2"),
        ("Both slots  [dim]— collapse to single-tier[/dim]", "both"),
    ]
    picked_slot = _pick_model_interactive(
        title=f"Assign {picked_id} to which slot?",
        options=slot_options,
    )
    if picked_slot is None:
        return ""

    if picked_slot == "both":
        # Set both slots to the picked model — effectively single-tier.
        _swap_tier(ctx, picked_id, "system1")
        return _swap_tier(ctx, picked_id, "system2")
    return _swap_tier(ctx, picked_id, picked_slot)


def _pick_model_interactive(
    title: str, options: list[tuple[str, str]],
) -> str | None:
    """Run a prompt_toolkit picker over `options` (label, value) pairs.

    Arrow/PgUp/PgDn nav, Enter selects, Esc cancels. Runs synchronously
    because the slash-command dispatcher is sync; the prompt_toolkit
    Application creates its own event loop.
    Returns the selected `value` or None on cancel.
    """
    import os as _os
    _os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")

    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import HSplit, Layout, Window
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.dimension import Dimension as D
    from prompt_toolkit.styles import Style
    from prompt_toolkit.widgets import Frame

    state = {"cursor": 0, "result": None}
    page = 12  # visible rows at a time

    def menu_text():
        out = []
        # Sliding window centered on cursor.
        start = max(0, state["cursor"] - page // 2)
        end = min(len(options), start + page)
        start = max(0, end - page)
        for i in range(start, end):
            label, _val = options[i]
            if i == state["cursor"]:
                out.append(("class:selected", f"  ❯ {label}\n"))
            else:
                out.append(("class:option", f"    {label}\n"))
        if end < len(options):
            out.append(("class:dim", f"    … {len(options) - end} more\n"))
        return out

    kb = KeyBindings()

    @kb.add("up")
    def _(event):
        state["cursor"] = (state["cursor"] - 1) % len(options)
        event.app.invalidate()

    @kb.add("down")
    def _(event):
        state["cursor"] = (state["cursor"] + 1) % len(options)
        event.app.invalidate()

    @kb.add("pageup")
    def _(event):
        state["cursor"] = max(0, state["cursor"] - page)
        event.app.invalidate()

    @kb.add("pagedown")
    def _(event):
        state["cursor"] = min(len(options) - 1, state["cursor"] + page)
        event.app.invalidate()

    @kb.add("enter")
    def _(event):
        state["result"] = options[state["cursor"]][1]
        event.app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def _(event):
        state["result"] = None
        event.app.exit()

    body = HSplit([
        Window(
            FormattedTextControl(menu_text),
            height=D(min=page, max=page + 1, preferred=page),
        ),
    ])
    style = Style.from_dict({
        "selected": "bold",
        "option": "",
        "dim": "#888888",
        "frame.border": "#5f5f87",
        "frame.label": "bold #87afff",
    })
    app: Application[None] = Application(
        layout=Layout(Frame(body, title=title, style="class:frame")),
        key_bindings=kb, style=style,
        full_screen=False, mouse_support=False,
    )
    app.run()
    return state["result"]


def _do_switch(ctx: SlashContext, new_id: str) -> str:
    try:
        # Resolve presets through the same path the agent uses on init.
        from core.agent import _resolve_preset_sync
        resolved = _resolve_preset_sync(new_id)
        ctx.agent.switch_model(resolved)
        return f"model: → {ctx.agent.llm.model}"
    except Exception as e:
        return f"[red]switch failed: {e}[/red]"


def _swap_tier(ctx: SlashContext, args: str, slot: str) -> str:
    """Swap System 1 or System 2 mid-session.

    Persists to ~/.cognos/settings.json so the change survives restart.
    Hot-swaps in place if dual-process is already running; otherwise
    upgrades the single-brain agent to dual-brain by pairing with the
    current model.
    """
    from core.agent import _resolve_preset_sync
    from core.settings import write_user_setting
    from llm.provider import LLMProvider
    from llm.router import DualLLMProvider, RoutingPolicy, Router
    from config import ROUTER_COMPLEXITY_THRESHOLD

    new_id = args.strip()
    if not new_id:
        # No arg: just report the current value
        if isinstance(ctx.agent.llm, DualLLMProvider):
            cur = (ctx.agent.llm.fast_model if slot == "system1"
                   else ctx.agent.llm.slow_model)
            return f"{slot}: {cur}"
        return f"[dim]dual-process not configured. Set both /system1 and /system2 to enable.[/dim]"

    try:
        resolved = _resolve_preset_sync(new_id)
    except Exception as e:
        return f"[red]could not resolve {new_id!r}: {e}[/red]"

    # Already in dual-brain mode — hot-swap the relevant tier.
    if isinstance(ctx.agent.llm, DualLLMProvider):
        if slot == "system1":
            ctx.agent.llm.set_fast(resolved)
            ctx.agent.llm_fast = ctx.agent.llm._fast
        else:
            ctx.agent.llm.set_slow(resolved)
            ctx.agent.llm_slow = ctx.agent.llm._slow
        write_user_setting(slot, resolved)
        cur_s1 = ctx.agent.llm.fast_model
        cur_s2 = ctx.agent.llm.slow_model
        return (f"[green]{slot} → {resolved}[/green]   "
                f"[dim]S1={cur_s1} · S2={cur_s2} (saved)[/dim]")

    # Single-brain mode. Promote to dual-brain by combining with the
    # current model on the *other* slot.
    current_model = ctx.agent.llm.model
    if slot == "system1":
        s1, s2 = resolved, current_model
    else:
        s1, s2 = current_model, resolved
    try:
        fast = LLMProvider(model=s1)
        slow = LLMProvider(model=s2)
        policy = RoutingPolicy(complexity_threshold=ROUTER_COMPLEXITY_THRESHOLD)
        new_llm = DualLLMProvider(fast=fast, slow=slow, policy=policy)
        # Reconnect with the agent's mood + caudate observer
        if ctx.agent.personality is not None:
            try: new_llm.set_mood(ctx.agent.personality.mood)
            except Exception: pass
        cau = getattr(ctx.agent, "caudate", None)
        if cau is not None:
            try: new_llm.router.set_caudate(cau)
            except Exception: pass
        ctx.agent.llm = new_llm
        ctx.agent.llm_fast = fast
        ctx.agent.llm_slow = slow
        ctx.agent.agentic.llm = new_llm
    except Exception as e:
        return f"[red]could not enable dual-brain: {e}[/red]"
    write_user_setting("system1", s1)
    write_user_setting("system2", s2)
    return (f"[green]dual-brain enabled[/green]\n"
            f"  [cyan]System 1 (fast):[/cyan]  {s1}\n"
            f"  [magenta]System 2 (slow):[/magenta] {s2}\n"
            f"[dim]saved to ~/.cognos/settings.json[/dim]")


def _system1(ctx: SlashContext, args: str) -> Any:
    return _swap_tier(ctx, args, "system1")


def _system2(ctx: SlashContext, args: str) -> Any:
    return _swap_tier(ctx, args, "system2")


def _strategies(ctx: SlashContext, args: str) -> str:
    """`/strategies` lists past-success traces; `/strategies recall <q>`
    runs a similarity query; `/strategies prune` drops old traces.

    Phase 1.8: the recall-driven half of Caudate's learning loop.
    Stored automatically when a turn ends with outcome_reward >= 0.30.
    """
    try:
        from memory.strategies import get_library, recall_for_prompt
    except Exception as e:
        return f"[red]strategies module unavailable: {e}[/red]"
    lib = get_library()
    if lib is None:
        return "[yellow]strategy library backend (chromadb) unavailable.[/yellow]"

    arg = args.strip()
    if arg.startswith("recall "):
        q = arg[len("recall "):].strip()
        if not q:
            return "[red]usage: /strategies recall <query>[/red]"
        traces = recall_for_prompt(q, k=5)
        if not traces:
            return "[dim]no similar past successes.[/dim]"
        lines = [f"[bold]top-5 strategies for {q!r}:[/bold]"]
        for t in traces:
            lines.append(f"  • {t.one_liner()}")
        return "\n".join(lines)

    if arg == "prune":
        n = lib.prune()
        return f"pruned {n} stale strategy traces (older than 365d)"

    n = lib.count()
    if not n:
        return "[dim]strategy library is empty. Build something successful and rate it /feedback good.[/dim]"
    return f"[bold]Strategy library:[/bold] {n} stored trace(s). Use /strategies recall <query> to test retrieval, /strategies prune to clean up."


def _outcome_feedback(ctx: SlashContext, args: str) -> str:
    """`/feedback good|bad [reason]` — apply explicit outcome signal
    to the previous turn. Without args, shows the last turn's current
    rating so you know what you're rating.

    Phase 1.6: feeds the Caudate learning loop (1.1-1.5). A `good`
    pick gets reinforced in the next training pass; a `bad` pick
    gets dampened.
    """
    caudate = getattr(ctx.agent, "caudate", None)
    if caudate is None:
        return "[yellow]Caudate observer not active — feedback is a no-op.[/yellow]"

    arg = args.strip()
    if not arg:
        summary = caudate.last_turn_summary()
        if summary is None:
            return "[dim]No recent turn to rate.[/dim]"
        lines = ["[bold]Last turn[/bold]"]
        lines.append(f"  prompt: [italic]{summary['user_message']!r}[/italic]")
        lines.append(f"  tools called: {summary['tools']}")
        oc = summary["outcome_reward"]
        if oc is None:
            lines.append("  outcome_reward: [dim]None (auto signals only)[/dim]")
        else:
            lines.append(f"  outcome_reward: [bold]{oc:+.2f}[/bold]")
        lines.append("")
        lines.append("Type [cyan]/feedback good[/cyan], [cyan]/feedback bad <reason>[/cyan], or [cyan]/feedback neutral[/cyan] to apply.")
        return "\n".join(lines)

    parts = arg.split(maxsplit=1)
    verb = parts[0].lower()
    reason = parts[1] if len(parts) > 1 else ""
    score_map = {
        "good": +1, "+1": +1, "yes": +1, "👍": +1,
        "bad":  -1, "-1": -1, "no":  -1, "👎": -1, "fix": -1,
        "neutral": 0, "0": 0, "meh": 0,
    }
    if verb not in score_map:
        return (
            f"[red]unknown feedback {verb!r}[/red]  — try "
            "[cyan]good[/cyan] | [cyan]bad[/cyan] | [cyan]neutral[/cyan]"
        )

    try:
        n = caudate.apply_feedback(score=score_map[verb], reason=reason)
    except Exception as e:
        return f"[red]feedback failed: {e}[/red]"

    if n == 0:
        return "[yellow]No recent turn to rate — try after the next agent turn.[/yellow]"
    score_label = {1: "👍 good", -1: "👎 bad", 0: "neutral"}[score_map[verb]]
    return f"  {score_label} applied to {n} sample(s){' — ' + reason if reason else ''}"


def _models_refresh(ctx: SlashContext, args: str) -> str:
    """`/models-refresh` — pull a fresh copy of the models.dev catalog.

    The catalog is normally cached for 24h and refreshed lazily in the
    background. This command forces an immediate sync refresh — useful
    when you just pulled a new model and want capability info now.
    """
    try:
        from llm.models_dev import force_refresh
    except Exception as e:
        return f"[red]models.dev module unavailable: {e}[/red]"
    ok = force_refresh()
    if ok:
        return "[green]models.dev catalog refreshed[/green]"
    return "[yellow]refresh failed — kept the existing cache[/yellow]"


def _swap_s1_s2(ctx: SlashContext, args: str) -> str:
    """`/swap` — exchange System 1 and System 2 in one command.

    Only meaningful in dual-brain mode. Reads the current S1 and S2
    model ids, then writes them back to each other's slot. Persists
    to settings so the change survives restart.
    """
    from llm.router import DualLLMProvider
    if not isinstance(ctx.agent.llm, DualLLMProvider):
        return (
            "[dim]dual-process not configured. Set both /s1 and /s2 "
            "to enable, then /swap will work.[/dim]"
        )
    cur_s1 = ctx.agent.llm.fast_model
    cur_s2 = ctx.agent.llm.slow_model
    if cur_s1 == cur_s2:
        return f"[dim]S1 and S2 are already the same ({cur_s1}); nothing to swap.[/dim]"
    # Reuse the existing swap-tier path twice. Order matters: set new
    # S2 first (using the OLD S1 value we captured), then set new S1.
    _swap_tier(ctx, cur_s1, "system2")
    _swap_tier(ctx, cur_s2, "system1")
    new_s1 = ctx.agent.llm.fast_model
    new_s2 = ctx.agent.llm.slow_model
    return (
        f"[green]swapped[/green]   "
        f"[dim]S1={new_s1} · S2={new_s2} (saved)[/dim]"
    )


def _cost(ctx: SlashContext, args: str) -> str:
    from core.usage import get_global_tracker
    rep = get_global_tracker().report()
    table = Table(title="Usage")
    table.add_column("model")
    table.add_column("requests")
    table.add_column("prompt")
    table.add_column("completion")
    for model, u in rep["by_model"].items():
        table.add_row(model, str(u["requests"]), str(u["prompt_tokens"]), str(u["completion_tokens"]))
    ctx.console.print(table)
    return f"total_tokens={rep['total_tokens']}  cost=${rep['total_cost_usd']:.6f}"


def _tools(ctx: SlashContext, args: str) -> str:
    table = Table(title="Tools")
    table.add_column("name")
    table.add_column("description")
    for name in sorted(ctx.agent.loop.executor.list_tools()):
        t = ctx.agent.loop.executor.get_tool(name)
        if t:
            table.add_row(name, (t.description or "")[:80])
    ctx.console.print(table)
    return ""


def _sessions(ctx: SlashContext, args: str) -> str:
    from core.session import SessionManager
    from config import SESSIONS_DIR
    sm = SessionManager(SESSIONS_DIR)
    items = sm.list()
    if not items:
        return "(no saved sessions)"
    table = Table(title="Sessions")
    table.add_column("id"); table.add_column("title"); table.add_column("model"); table.add_column("msgs"); table.add_column("updated")
    for s in items[:20]:
        table.add_row(s.id[:8], (s.title or "(untitled)")[:30], s.model, str(len(s.messages)), s.updated_at.isoformat(timespec="seconds"))
    ctx.console.print(table)
    return ""


def _export(ctx: SlashContext, args: str) -> str:
    from core.export import export_session
    parts = shlex.split(args) if args else []
    fmt = parts[0] if parts else "markdown"
    path = Path(parts[1]) if len(parts) > 1 else Path(f"data/exports/{ctx.agent.session.id}.{ {'markdown':'md','md':'md','json':'json','html':'html'}.get(fmt, 'md') }")
    out = export_session(ctx.agent.session, path, format=fmt)
    return f"exported → {out}"


def _files(ctx: SlashContext, args: str) -> str:
    parts = shlex.split(args) if args else []
    sub = parts[0] if parts else "list"
    if sub == "list":
        items = ctx.agent.files.list()
        if not items:
            return "(no uploaded files)"
        table = Table(title="Files")
        table.add_column("id"); table.add_column("name"); table.add_column("kind"); table.add_column("size")
        for r in items[:20]:
            table.add_row(r.id[:8], r.filename, r.kind, str(r.size_bytes))
        ctx.console.print(table)
        return ""
    if sub == "delete" and len(parts) > 1:
        ok = ctx.agent.files.delete(parts[1])
        return "deleted" if ok else "[red]not found[/red]"
    return "usage: /files [list|delete <id>]"


def _permissions(ctx: SlashContext, args: str) -> str:
    from core.permissions import PermissionMode
    if not args.strip():
        pm = ctx.agent.permissions
        lines = [f"mode: {pm.mode.value}"]
        if pm.allow:
            lines.append("allow:")
            for r in pm.allow:
                lines.append(f"  + {r.display()}")
        if pm.deny:
            lines.append("deny:")
            for r in pm.deny:
                lines.append(f"  - {r.display()}")
        return "\n".join(lines)
    try:
        prev = ctx.agent.permissions.mode
        new_mode = PermissionMode(args.strip())
        ctx.agent.permissions.mode = new_mode
        # If user switched into AUTO without prior onboarding, signal
        # the REPL to show the explainer modal before the next prompt.
        if new_mode == PermissionMode.AUTO:
            try:
                from core.settings import Settings
                if not Settings.load().get("auto_mode_onboarded"):
                    setattr(ctx.agent, "_pending_auto_onboarding",
                            {"prev_mode": prev})
            except Exception:
                pass
        return f"mode: → {new_mode.value}"
    except Exception as e:
        return f"[red]{e}[/red]"


def _yolo(ctx: SlashContext, args: str) -> str:
    """Toggle BYPASS mode — skip all permission prompts."""
    from core.permissions import PermissionMode
    current = ctx.agent.permissions.mode
    if current == PermissionMode.BYPASS:
        ctx.agent.permissions.mode = PermissionMode.DEFAULT
        return "🛑 yolo OFF — permission prompts re-enabled"
    ctx.agent.permissions.mode = PermissionMode.BYPASS
    return "🚀 yolo ON — all tool calls auto-approved this session"


def _allow(ctx: SlashContext, args: str) -> str:
    """Add a persistent allow rule. Syntax: /allow Bash(python:*) [persist=no]

    Without args, lists current allow rules.
    """
    from core.permissions import PermissionRule
    pm = ctx.agent.permissions
    arg = args.strip()
    if not arg:
        if not pm.allow:
            return "(no allow rules)"
        return "allow:\n" + "\n".join(f"  + {r.display()}" for r in pm.allow)
    persist = True
    if arg.endswith(" persist=no"):
        persist = False
        arg = arg[: -len(" persist=no")].strip()
    tool, pattern = _parse_rule_spec(arg)
    if tool is None:
        return f"[red]bad rule: {args!r}[/red] (expected `Tool` or `Tool(pattern)`)"
    rule = PermissionRule(tool=tool, pattern=pattern)
    pm.allow.append(rule)
    if persist:
        try:
            from core.settings import append_allow_rule
            append_allow_rule(rule.to_dict())
        except Exception as e:
            return f"added in-session, but failed to persist: {e}"
    return f"+ {rule.display()}" + ("" if persist else "  (in-session only)")


def _deny(ctx: SlashContext, args: str) -> str:
    """Add a persistent deny rule. Syntax: /deny Bash(rm:*) [persist=no]"""
    from core.permissions import PermissionRule
    pm = ctx.agent.permissions
    arg = args.strip()
    if not arg:
        if not pm.deny:
            return "(no deny rules)"
        return "deny:\n" + "\n".join(f"  - {r.display()}" for r in pm.deny)
    persist = True
    if arg.endswith(" persist=no"):
        persist = False
        arg = arg[: -len(" persist=no")].strip()
    tool, pattern = _parse_rule_spec(arg)
    if tool is None:
        return f"[red]bad rule: {args!r}[/red] (expected `Tool` or `Tool(pattern)`)"
    rule = PermissionRule(tool=tool, pattern=pattern)
    pm.deny.append(rule)
    if persist:
        try:
            from core.settings import append_deny_rule
            append_deny_rule(rule.to_dict())
        except Exception as e:
            return f"added in-session, but failed to persist: {e}"
    return f"- {rule.display()}" + ("" if persist else "  (in-session only)")


def _parse_rule_spec(spec: str) -> tuple[str | None, str | None]:
    """Parse `Tool` or `Tool(pattern:*)` into (tool, regex-pattern)."""
    import re as _re
    spec = spec.strip()
    m = _re.match(r"^([A-Za-z_][A-Za-z0-9_]*)(?:\((.*)\))?$", spec)
    if not m:
        return None, None
    tool = m.group(1)
    inner = m.group(2)
    if inner is None:
        return tool, None
    if inner.endswith(":*"):
        head = inner[:-2]
        return tool, rf"^{_re.escape(head)}\b"
    return tool, inner


def _personality(ctx: SlashContext, args: str) -> str:
    if ctx.agent.personality is None:
        return "(personality disabled)"
    p = ctx.agent.personality
    return f"identity: {p.identity.describe()}\nmood: {p.mood.label()}"


def _router(ctx: SlashContext, args: str) -> str:
    from llm.router import DualLLMProvider
    if isinstance(ctx.agent.llm, DualLLMProvider):
        return f"fast={ctx.agent.llm_fast.model}  slow={ctx.agent.llm_slow.model}"
    return "(routing disabled — single model)"


def _diff(ctx: SlashContext, args: str) -> str:
    parts = shlex.split(args) if args else []
    if not parts:
        return "usage: /diff <path>"
    p = Path(parts[0])
    if not p.exists():
        return f"[red]not found: {p}[/red]"
    from core.diff_viewer import render_unified_diff
    render_unified_diff("", p.read_text(errors="ignore"), "/dev/null", str(p), console=ctx.console)
    return ""


def _status(ctx: SlashContext, args: str) -> str:
    from core.statusline import build_status_values, render_statusline
    template = (ctx.settings.get("statusline") if ctx.settings else None) or "{model} | {mood} | tok={tokens} | ${cost:.4f}"
    return render_statusline(template, build_status_values(ctx.agent))


def _cron(ctx: SlashContext, args: str) -> str:
    from core.scheduler import CronStore
    store = CronStore(Path("data/cron.json"))
    parts = shlex.split(args) if args else ["list"]
    sub = parts[0]
    if sub == "list":
        jobs = store.list()
        if not jobs:
            return "(no scheduled jobs)"
        table = Table(title="Cron")
        table.add_column("id"); table.add_column("schedule"); table.add_column("next"); table.add_column("prompt")
        for j in jobs:
            table.add_row(j.id, j.schedule, j.next_run or "-", j.prompt[:40])
        ctx.console.print(table)
        return ""
    if sub == "add" and len(parts) >= 3:
        schedule = parts[1]
        prompt = " ".join(parts[2:])
        try:
            j = store.add(prompt, schedule)
            return f"scheduled {j.id}: {schedule}"
        except Exception as e:
            return f"[red]{e}[/red]"
    if sub == "remove" and len(parts) >= 2:
        ok = store.remove(parts[1])
        return "removed" if ok else "[red]not found[/red]"
    return "usage: /cron list | /cron add <schedule> <prompt> | /cron remove <id>"


def _bg(ctx: SlashContext, args: str) -> str:
    from core.background import get_global_pool
    pool = get_global_pool()
    parts = shlex.split(args) if args else ["list"]
    sub = parts[0]
    if sub == "list":
        rows = pool.list()
        if not rows:
            return "(no background tasks)"
        table = Table(title="Background tasks")
        table.add_column("id"); table.add_column("status"); table.add_column("dur"); table.add_column("label")
        for r in rows[:20]:
            table.add_row(r.id, r.status, f"{r.duration:.1f}s", r.label[:40])
        ctx.console.print(table)
        return ""
    if sub == "watch" and len(parts) >= 2:
        bg = pool.get(parts[1])
        if bg is None:
            return "[red]no such task[/red]"
        return f"{bg.id} {bg.status} dur={bg.duration:.1f}s\n{(bg.result or bg.error or '')[:1000]}"
    if sub == "kill" and len(parts) >= 2:
        ok = pool.cancel(parts[1])
        return "cancelled" if ok else "[red]not running[/red]"
    return "usage: /bg list | /bg watch <id> | /bg kill <id>"


def _notify(ctx: SlashContext, args: str) -> str:
    from core.notifications import notify
    if not args.strip():
        return "usage: /notify <message>"
    notify("Cognos", args.strip())
    return "sent"


def _think(ctx: SlashContext, args: str) -> str:
    val = args.strip().lower()
    if val in ("on", "true", "1"):
        ctx.agent.agentic.thinking = True
        return "thinking: on"
    if val in ("off", "false", "0"):
        ctx.agent.agentic.thinking = False
        return "thinking: off"
    return f"thinking: {ctx.agent.agentic.thinking}"


def _save(ctx: SlashContext, args: str) -> str:
    ctx.agent.session.messages = list(ctx.agent.agentic.messages)
    ctx.agent.sessions.save(ctx.agent.session)
    return f"saved {ctx.agent.session.id}"


def _caudate(ctx: SlashContext, args: str) -> str:
    """Inspect / control Caudate (the action-selection neural net)."""
    cau = getattr(ctx.agent, "caudate", None)
    if cau is None:
        return "[dim]Caudate is not active in this agent.[/dim]"

    sub = (args.strip() or "status").split()[0].lower()
    rest = args.strip()[len(sub):].strip()

    if sub == "status":
        s = cau.status()
        policy = s.get("policy", {})
        scorer = s.get("scorer", {})
        nxt = policy.get("next") or {}
        lines = [
            f"trust:      [cyan]{policy.get('level', '?')}[/cyan]"
            f"{' (frozen)' if policy.get('frozen') else ''}",
            f"advisor:    {'loaded' if s['advisor_loaded'] else '[yellow]no checkpoint[/yellow]'}",
            f"replay:     {s['replay_size']}/{cau.cfg.replay_capacity} samples "
            f"({s['samples_since_train']} new since last train)",
            f"accuracy:   tool={scorer.get('tool_acc', 0):.2f}  "
            f"tier={scorer.get('tier_acc', 0):.2f}  "
            f"think={scorer.get('think_acc', 0):.2f}  "
            f"composite={scorer.get('composite', 0):.2f}",
            f"scored:     {scorer.get('samples_in_window', 0)} in window, "
            f"{scorer.get('lifetime_predictions', 0)} lifetime",
            f"auto-train: every {s['auto_train_every']} samples · "
            f"{'[cyan]running[/cyan]' if s['auto_train_in_flight'] else 'idle'}",
        ]
        if not nxt.get("at_top"):
            lines.append(
                f"next gate:  → [cyan]{nxt.get('next_level', '?')}[/cyan]  "
                f"(need acc≥{nxt.get('accuracy_needed', 0):.2f}, "
                f"{nxt.get('samples_needed', 0)} more samples)"
            )
        else:
            lines.append("next gate:  [green]top level reached[/green]")

        p = s.get("last_prediction")
        if p:
            lines.append(
                f"last pred:  tool={p['tool']} ({p['tool_conf']:.2f}) · "
                f"tier={p['tier']} ({p['tier_conf']:.2f}) · "
                f"think={p['think']:.2f} · value={p['value']:.2f}"
            )
        return "\n".join(lines)

    if sub == "awareness":
        # Caudate speaks about herself in the first person.
        s = cau.status()
        scorer = s.get("scorer", {})
        policy = s.get("policy", {})
        nxt = policy.get("next") or {}
        level = policy.get("level", "silent")
        if level == "silent":
            return (
                '[italic]"I exist, but I have no weights yet. I\'m watching '
                f'you work — once {cau.cfg.min_episodes_to_train} samples '
                'land in the replay buffer, the trainer fires and I open '
                'my eyes."[/italic]'
            )
        if level == "observer":
            return (
                f'[italic]"I have weights now. I predict every turn, but '
                f'no one listens yet — and they shouldn\'t. My tool '
                f'accuracy is {scorer.get("tool_acc", 0):.0%} over '
                f'{scorer.get("samples_in_window", 0)} predictions. '
                f"I need {nxt.get('samples_needed', 0)} more samples and "
                f"composite ≥ {nxt.get('accuracy_needed', 0):.2f} before "
                f'you let me whisper."[/italic]'
            )
        if level == "whisper":
            return (
                f'[italic]"I\'m whispering now. My suggestions appear in '
                f'the LLM\'s system prompt — it can ignore me. Tool '
                f'accuracy {scorer.get("tool_acc", 0):.0%}, tier '
                f'{scorer.get("tier_acc", 0):.0%}, composite '
                f'{scorer.get("composite", 0):.2f}. To advise (override '
                f'the router) I need composite ≥ '
                f'{nxt.get("accuracy_needed", 0):.2f} over '
                f'{nxt.get("current_samples", 0) + nxt.get("samples_needed", 0)} '
                f'predictions."[/italic]'
            )
        if level == "advisor":
            return (
                f'[italic]"I pick the routing tier now. The heuristic '
                f"router doesn't run — my prediction does. Tier accuracy "
                f"{scorer.get('tier_acc', 0):.0%}. To gate thinking "
                f'(controller level) I need composite ≥ '
                f'{nxt.get("accuracy_needed", 0):.2f}."[/italic]'
            )
        return (
            f'[italic]"Controller level. I gate thinking and route every '
            f"call. I'm not smarter than the cortex (LLM) — I'm faster "
            f'and more specific to you. Lifetime accuracy: '
            f'{scorer.get("lifetime_tool_acc", 0):.1%} on '
            f'{scorer.get("lifetime_predictions", 0)} predictions."[/italic]'
        )

    if sub in ("train", "fit"):
        try:
            cau._train_sync()
            cau.reload_advisor()
            return "[green]training complete; advisor reloaded[/green]"
        except Exception as e:
            return f"[red]train failed: {e}[/red]"

    if sub == "reload":
        ok = cau.reload_advisor()
        return "[green]advisor reloaded[/green]" if ok else "[yellow]no checkpoint to load[/yellow]"

    if sub == "freeze":
        from nn.policy import TrustLevel
        target = None
        if rest:
            try:
                target = TrustLevel[rest.upper()]
            except KeyError:
                return f"[red]unknown trust level: {rest}[/red]"
        cau.policy.freeze(level=target)
        return f"[yellow]Caudate frozen at {cau.policy.level.label}[/yellow]"

    if sub == "thaw":
        cau.policy.thaw()
        return f"[green]Caudate thawed — graduation re-enabled[/green]"

    if sub == "demote":
        from nn.policy import TrustLevel
        if cau.policy.level <= TrustLevel.OBSERVER:
            return "[yellow]already at the bottom[/yellow]"
        cau.policy.force(TrustLevel(int(cau.policy.level) - 1))
        return f"[yellow]demoted → {cau.policy.level.label}[/yellow]"

    if sub == "promote":
        from nn.policy import TrustLevel
        if cau.policy.level >= TrustLevel.CONTROLLER:
            return "[green]already at the top[/green]"
        cau.policy.force(TrustLevel(int(cau.policy.level) + 1))
        return f"[green]promoted → {cau.policy.level.label}[/green]"

    if sub in ("stop", "kill"):
        # Hard owner override. Deletes weights if `kill`, just silences if `stop`.
        from core.ownership import kill, get_owner
        owner = get_owner()
        if sub == "stop":
            kill(reason=f"{owner.name} stop")
            return f"[red bold]Caudate stopped by {owner.name}.[/red bold]\n" \
                   f"[dim]predictions silenced, no auto-train, no NAS. " \
                   f"Run `/caudate resume` to lift the killswitch.[/dim]"
        # kill — also wipe the weights so she has to re-earn trust
        kill(reason=f"{owner.name} kill — weights wiped")
        from pathlib import Path
        for p in (cau.cfg.checkpoint_path, cau.cfg.metadata_path):
            try: Path(p).unlink(missing_ok=True)
            except Exception: pass
        cau.advisor = None
        return f"[red bold]Caudate killed by {owner.name}.[/red bold]\n" \
               f"[dim]weights wiped, killswitch on, trust reset to silent. " \
               f"She has to re-earn everything.[/dim]"

    if sub == "resume":
        from core.ownership import resume, get_owner
        resume()
        cau.reload_advisor()
        return f"[green]Caudate resumed by {get_owner().name}.[/green]"

    if sub == "obey":
        # Audit + show that she only obeys the configured owner
        from core.ownership import get_owner, killswitch_status, audit
        owner = get_owner()
        ks = killswitch_status()
        audit("obedience_check", invoker=owner.name)
        return (
            f"owner:        [bold]{owner.name}[/bold]\n"
            f"set_at:       {owner.set_at}\n"
            f"killswitch:   "
            + ("[red]ACTIVE — Caudate is silent[/red]" if ks.get("killed")
               else "[green]inactive — Caudate may act[/green]") + "\n"
            f"[dim]Caudate's predictions, auto-train, and NAS all gate on this. "
            f"You hold the only veto.[/dim]"
        )

    if sub == "owner":
        from core.ownership import get_owner, set_owner
        if not rest:
            o = get_owner()
            return f"owner: {o.name}  (set {o.set_at})\n[dim]/caudate owner <name> to reassign[/dim]"
        new = set_owner(rest.strip())
        return f"[yellow]owner reassigned: → {new.name}[/yellow]"

    if sub == "undo":
        # Roll back to the previous champion in NAS history
        from nn.nas.store import NASStore
        store = NASStore()
        history = [h for h in store.history()
                   if h.get("result", {}).get("fitness", -1) > -1]
        if len(history) < 2:
            return "[yellow]not enough NAS history to undo[/yellow]"
        # Take the second-most-recent (penultimate) by save time
        history.sort(key=lambda h: h.get("born_at", 0))
        prev = history[-2]
        return (f"[yellow]undo would restore {prev.get('id', '')[:8]} "
                f"(fit={prev.get('result', {}).get('fitness', 0):.3f})[/yellow]\n"
                f"[dim]not yet implemented — manual NAS history rollback "
                f"requires checkpoint preservation per trial.[/dim]")

    if sub == "evolve":
        evo = getattr(cau, "auto_evolver", None)
        if evo is None:
            return "[yellow]auto-evolve not initialized[/yellow]"
        sub2 = (rest.split() or [""])[0].lower()
        if sub2 == "on":
            evo.cfg.enabled = True
            return "[green]auto-evolve enabled[/green]"
        if sub2 == "off":
            evo.cfg.enabled = False
            return "[yellow]auto-evolve disabled[/yellow]"
        if sub2 == "force":
            # Bypass plateau check + cooldown for one fire
            evo._last_fire_at = 0.0
            try:
                from nn.nas.scheduler import PlateauScheduler
                sched = PlateauScheduler()
                # Pretend we've stalled enough to trigger
                while not sched.should_fire():
                    sched.observe_eval(0.0)
            except Exception:
                pass
            evo.maybe_fire()
            return "[cyan]NAS run forced — running in background[/cyan]"
        # Default: show status
        s = evo.status()
        lines = [
            f"enabled:    {s['enabled']}",
            f"fires:      {s['n_fires']}",
            f"in flight:  {s['in_flight']}",
            f"cooldown:   {s['cooldown_seconds']}s",
            f"min VRAM:   {s['min_vram_gb']}GB",
            f"rotation:   {' → '.join(s['rotation'])}",
        ]
        if s.get("seconds_since_last_fire") is not None:
            lines.append(f"since fire: {s['seconds_since_last_fire']}s ago")
        return "\n".join(lines)

    if sub == "off":
        cau.advisor = None
        return "[yellow]Caudate predictions silenced (replay buffer still recording).[/yellow]"

    if sub == "on":
        ok = cau.reload_advisor()
        return "[green]Caudate predictions re-enabled[/green]" if ok else "[yellow]no checkpoint to load[/yellow]"

    return (
        "usage: /caudate [status|awareness|train|reload|freeze|thaw|"
        "promote|demote|on|off|evolve {status|on|off|force}|"
        "stop|kill|resume|obey|owner [name]|undo]"
    )


def _voice(ctx: SlashContext, args: str) -> str:
    """Hand control to the voice loop. Returns when the user says 'stop'.

    `/voice`         — single turn (listen once, speak the reply)
    `/voice loop`    — continuous loop until 'stop'/'goodbye' or Ctrl+C
    `/voice --stt whisper`  — backend override
    """
    import asyncio
    import shlex

    parts = shlex.split(args) if args else []
    loop = "loop" in parts
    stt_backend = "moonshine"
    voice_path: str | None = None

    # Tiny option parser
    i = 0
    while i < len(parts):
        p = parts[i]
        if p == "--stt" and i + 1 < len(parts):
            stt_backend = parts[i + 1]; i += 2
        elif p == "--voice" and i + 1 < len(parts):
            voice_path = parts[i + 1]; i += 2
        else:
            i += 1

    try:
        from voice.conversation import VoiceConversation
    except ImportError as e:
        return f"[red]voice deps missing: {e}[/red]"

    conv = VoiceConversation(
        agent=ctx.agent, stt=stt_backend, voice_path=voice_path,
    )
    ctx.console.print(
        f"[magenta]Voice mode "
        f"({'continuous' if loop else 'single turn'}, stt={stt_backend}). "
        f"Say 'stop' or Ctrl+C to return to text.[/magenta]"
    )
    try:
        if loop:
            asyncio.run(conv.run(greeting=False))
        else:
            asyncio.run(_voice_single_turn(conv))
    except KeyboardInterrupt:
        return "[yellow]voice mode interrupted[/yellow]"
    return "[dim]back to text mode[/dim]"


async def _voice_single_turn(conv: Any) -> None:
    """One listen → think → speak cycle."""
    print("\n[listening]", end="", flush=True)
    text = conv.listener.listen()
    if text is None:
        print(" (no speech)")
        return
    print(f"\rYou said: {text}                    ")
    reply = await conv.agent.chat(text)
    print(f"Cognos: {reply}")
    conv._speak_safely(reply)


# Server lifecycle is process-wide; track the running thread/server here.
_serve_state: dict[str, Any] = {"thread": None, "server": None, "host": None, "port": None}


def _serve(ctx: SlashContext, args: str) -> str:
    """Start, stop, or check the HTTP API server.

      /serve              — show status
      /serve start [--port 8000] [--host 127.0.0.1]
      /serve stop
      /serve url          — print the active URL
    """
    import shlex
    parts = shlex.split(args) if args else []
    sub = parts[0] if parts else "status"

    if sub in ("status", "url"):
        if _serve_state["server"] is None:
            return "[dim]server: stopped[/dim]"
        url = f"http://{_serve_state['host']}:{_serve_state['port']}/ui"
        return f"server: running at [cyan]{url}[/cyan]"

    if sub == "start":
        if _serve_state["server"] is not None:
            return "[yellow]server already running — /serve stop first[/yellow]"
        host = "127.0.0.1"
        port = 8000
        i = 1
        while i < len(parts):
            if parts[i] == "--port" and i + 1 < len(parts):
                port = int(parts[i + 1]); i += 2
            elif parts[i] == "--host" and i + 1 < len(parts):
                host = parts[i + 1]; i += 2
            else:
                i += 1

        try:
            import threading
            import uvicorn
            from api.server import create_app
        except ImportError as e:
            return f"[red]uvicorn / fastapi not installed: {e}[/red]"

        config = uvicorn.Config(
            create_app(), host=host, port=port, log_level="warning",
        )
        server = uvicorn.Server(config)

        def _run():
            try:
                server.run()
            except Exception as e:
                logger.warning(f"serve thread exited: {e}")

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
        _serve_state.update(thread=thread, server=server, host=host, port=port)
        return f"[green]server up:[/green] http://{host}:{port}/ui"

    if sub == "stop":
        server = _serve_state["server"]
        if server is None:
            return "[dim]server not running[/dim]"
        server.should_exit = True
        # Best-effort wait, then clear state
        thread = _serve_state["thread"]
        if thread is not None:
            thread.join(timeout=5)
        _serve_state.update(thread=None, server=None, host=None, port=None)
        return "[yellow]server stopped[/yellow]"

    return "usage: /serve [start|stop|status]"


# ---- new (Claude Code parity) handlers -------------------------------

def _init(ctx: SlashContext, args: str) -> str:
    from core.bootstrap import cmd_init
    force = "--force" in args or "-f" in args
    cmd_init(ctx.console, force=force)
    return ""


def _doctor(ctx: SlashContext, args: str) -> str:
    from core.bootstrap import cmd_doctor
    cmd_doctor(ctx.console)
    return ""


def _update(ctx: SlashContext, args: str) -> str:
    import subprocess, sys
    ctx.console.print("[dim]running pip install -U caudate-cli ...[/dim]")
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-U", "--user", "caudate-cli"],
            capture_output=True, text=True, timeout=120,
        )
        tail = "\n".join(proc.stdout.splitlines()[-5:])
        return tail or "(no output)"
    except subprocess.TimeoutExpired:
        return "[red]pip timed out after 120s[/red]"
    except Exception as e:
        return f"[red]{e}[/red]"


def _update_caudate(ctx: SlashContext, args: str) -> str:
    from core.bootstrap import _download_caudate, _DEFAULT_HF_REPO, _PINNED_REVISION
    import os
    repo = os.environ.get("CAUDATE_HF_REPO", _DEFAULT_HF_REPO)
    revision = os.environ.get("CAUDATE_HF_REVISION") or _PINNED_REVISION
    # `args` can override the revision: `/update-caudate <sha-or-tag>`
    if args.strip():
        revision = args.strip()
    ok = _download_caudate(ctx.console, repo, revision=revision)
    return "[green]weights refreshed[/green]" if ok else "[red]update failed[/red]"


def _config(ctx: SlashContext, args: str) -> str:
    import os, subprocess
    from core.bootstrap import settings_path
    p = settings_path()
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if editor:
        try:
            subprocess.run([editor, str(p)], check=False)
            return ""
        except Exception:
            pass
    return f"[dim]settings file:[/dim] {p}\n[dim](set $EDITOR to open it directly)[/dim]"


def _resume(ctx: SlashContext, args: str) -> str:
    """List recent sessions (no arg) or hot-swap into a saved one
    by id-prefix (with arg). The swap replaces the agent's working
    history and session metadata so the next chat turn continues
    from that point — no restart needed."""
    sid = args.strip()

    # Discover the session store. SessionManager is the source of truth;
    # fall back to scanning the directory if it isn't wired.
    sm = None
    try:
        from core.session import SessionManager
        from config import SESSIONS_DIR
        sm = SessionManager(SESSIONS_DIR)
    except Exception:
        pass

    if not sid:
        try:
            entries = sm.list()[:25] if sm else []
        except Exception:
            entries = []
        if not entries:
            return "[dim]no sessions yet[/dim]"

        # Build picker options: "id  turns  date  title"
        options: list[tuple[str, str]] = []
        for s in entries:
            stamp = s.updated_at.strftime("%Y-%m-%d %H:%M") if s.updated_at else "                "
            title = (s.title or "(untitled)")[:50]
            label = f"{s.id[:8]}  {len(s.messages):>3} turns  {stamp}  {title}"
            options.append((label, s.id))

        picked_id = _pick_model_interactive(
            title="Resume session",
            options=options,
        )
        if picked_id is None:
            return ""
        sid = picked_id  # fall through to the swap path below

    if sm is None:
        return "[red]SessionManager not available[/red]"

    # Resolve id prefix → full id
    try:
        candidates = [s for s in sm.list() if s.id.startswith(sid)]
    except Exception as e:
        return f"[red]{e}[/red]"
    if not candidates:
        return f"[red]no session matching '{sid}'[/red]"
    if len(candidates) > 1:
        ids = ", ".join(s.id[:8] for s in candidates[:5])
        return f"[yellow]ambiguous — matches: {ids}[/yellow]"

    target = candidates[0]
    # Hot-swap on the agent: load the saved Session, point the agent's
    # session + agentic loop at it.
    try:
        ctx.agent.session = target
        if hasattr(ctx.agent, "agentic"):
            ctx.agent.agentic.messages = list(target.messages)
            ctx.agent.agentic.session_id = target.id
        return (
            f"[green]resumed[/green] {target.id[:8]} — "
            f"{len(target.messages)} prior messages restored."
        )
    except Exception as e:
        return f"[red]swap failed:[/red] {e}"


def _retry(ctx: SlashContext, args: str) -> str:
    try:
        msgs = ctx.agent.session.messages
        last_user = next(
            (m for m in reversed(msgs) if getattr(m, "role", None) == "user"),
            None,
        )
        if not last_user:
            return "[dim]no previous user message to retry[/dim]"
        ctx.console.print(f"[dim]retrying:[/dim] {getattr(last_user, 'content', '')[:80]}")
        import asyncio
        reply = asyncio.run(ctx.agent.chat(getattr(last_user, "content", "")))
        ctx.console.print(reply)
        return ""
    except Exception as e:
        return f"[red]{e}[/red]"


def _fast(ctx: SlashContext, args: str) -> str:
    arg = args.strip().lower()
    from llm.router import DualLLMProvider
    if not isinstance(ctx.agent.llm, DualLLMProvider):
        return "[yellow]fast mode is a no-op without dual-brain routing[/yellow]"
    if arg in ("on", "true", "1", "yes"):
        ctx.agent.llm.set_fast_only(True)
        return "[green]fast mode ON[/green] — System 1 only"
    if arg in ("off", "false", "0", "no"):
        ctx.agent.llm.set_fast_only(False)
        return "[yellow]fast mode OFF[/yellow] — dual-brain routing active"
    state = "ON" if ctx.agent.llm.fast_only else "OFF"
    return f"fast mode: {state}  (use `/fast on` or `/fast off`)"


def _effort(ctx: SlashContext, args: str) -> str:
    level = args.strip().lower()
    llm = ctx.agent.llm
    if level not in ("low", "medium", "high"):
        cur = getattr(llm, "effort", "medium")
        return (
            f"current effort: [bold]{cur}[/bold]\n"
            f"usage: /effort <low|medium|high>"
        )
    if hasattr(llm, "set_effort"):
        llm.set_effort(level)
    else:
        # Single-provider path
        from llm.provider import LLMProvider
        if isinstance(llm, LLMProvider):
            llm.set_effort(level)
    new_tokens = getattr(llm, "max_tokens", None)
    new_temp = getattr(llm, "temperature", None)
    return (
        f"[green]effort:[/green] {level}  "
        f"[dim](max_tokens={new_tokens}, temperature={new_temp})[/dim]"
    )


def _skills(ctx: SlashContext, args: str) -> str:
    try:
        from core.skills import list_skills  # type: ignore
        rows = list_skills() or []
    except Exception:
        rows = []
    if not rows:
        return "[dim]no skills registered[/dim]"
    t = Table(title="skills", show_header=True, header_style="bold")
    t.add_column("name"); t.add_column("trigger", style="dim")
    for s in rows:
        t.add_row(s.get("name", "?"), s.get("trigger", ""))
    ctx.console.print(t)
    return ""


def _agents(ctx: SlashContext, args: str) -> str:
    mgr = getattr(ctx.agent, "subagents", None)
    if mgr is None:
        return "[dim]subagent manager not wired[/dim]"
    try:
        profiles = list(getattr(mgr, "profiles", {}).keys())
    except Exception:
        profiles = []
    if not profiles:
        return "[dim]no agent profiles[/dim]"
    return "agent profiles: " + ", ".join(f"[cyan]{p}[/cyan]" for p in profiles)


def _mcp(ctx: SlashContext, args: str) -> str:
    try:
        from cognos_mcp.client import list_servers  # type: ignore
        servers = list_servers()
    except Exception:
        try:
            from config import MCP_CONFIG_PATH
            import json
            data = json.loads(MCP_CONFIG_PATH.read_text())
            servers = list(data.get("servers", {}).keys())
        except Exception:
            servers = []
    if not servers:
        return "[dim]no MCP servers configured[/dim]"
    return "MCP servers: " + ", ".join(f"[cyan]{s}[/cyan]" for s in servers)


def _hooks(ctx: SlashContext, args: str) -> str:
    try:
        from config import HOOKS_CONFIG_PATH
        import json
        if not HOOKS_CONFIG_PATH.exists():
            return f"[dim]no hooks config at {HOOKS_CONFIG_PATH}[/dim]"
        data = json.loads(HOOKS_CONFIG_PATH.read_text())
        if not data:
            return "[dim]no hooks registered[/dim]"
        out = [f"[cyan]{k}[/cyan]: {v}" for k, v in data.items()]
        return "\n".join(out)
    except Exception as e:
        return f"[red]{e}[/red]"


def _memory(ctx: SlashContext, args: str) -> str:
    import os, subprocess
    from pathlib import Path
    p = Path.home() / ".caudate" / "MEMORY.md"
    if not p.exists():
        p.write_text("# Caudate memory\n\n")
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL")
    if editor:
        try:
            subprocess.run([editor, str(p)], check=False)
            return ""
        except Exception:
            pass
    return p.read_text()[-4000:] or "[dim](empty)[/dim]"


def _remember(ctx: SlashContext, args: str) -> str:
    from pathlib import Path
    fact = args.strip()
    if not fact:
        return "usage: /remember <fact>"
    p = Path.home() / ".caudate" / "MEMORY.md"
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a") as f:
        f.write(f"- {fact}\n")
    return f"[green]remembered:[/green] {fact}"


def _context(ctx: SlashContext, args: str) -> str:
    try:
        from config import CONTEXT_WINDOW_SIZE, COMPACT_THRESHOLD
        from core.usage import get_global_tracker
        used = get_global_tracker().total_tokens()
        pct = min(100, int(100 * used / max(1, CONTEXT_WINDOW_SIZE)))
        bar_w = 40
        fill = int(bar_w * pct / 100)
        col = "green" if pct < 60 else ("yellow" if pct < 80 else "red")
        bar = f"[{col}]" + "█" * fill + "[/" + col + "]" + "·" * (bar_w - fill)
        return (
            f"context: {used}/{CONTEXT_WINDOW_SIZE} tokens  ({pct}%)\n"
            f"{bar}\n"
            f"compact threshold: {int(COMPACT_THRESHOLD * 100)}%"
        )
    except Exception as e:
        return f"[red]{e}[/red]"


def _copy(ctx: SlashContext, args: str) -> str:
    try:
        n = int(args.strip() or "1")
    except ValueError:
        n = 1
    msgs = getattr(ctx.agent.session, "messages", [])
    assistants = [m for m in msgs if getattr(m, "role", None) == "assistant"]
    if not assistants or n > len(assistants):
        return "[dim]no assistant message at that index[/dim]"
    text = getattr(assistants[-n], "content", "") or ""
    # Try several clipboard backends
    import subprocess
    for cmd in (["xclip", "-selection", "clipboard"], ["xsel", "-b"], ["pbcopy"]):
        try:
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            p.communicate(input=text.encode("utf-8"))
            if p.returncode == 0:
                return f"[green]copied[/green] {len(text)} chars (response #{n})"
        except FileNotFoundError:
            continue
    return f"[yellow]no clipboard tool found[/yellow] (install xclip / xsel / pbcopy)\n\n{text[:1000]}"


def _add_dir(ctx: SlashContext, args: str) -> str:
    """Recursively register every file under <path> in the FileStore so
    subsequent @file refs resolve against it and the LLM can read or
    cite them. Skips hidden dotfiles, binary blobs above 5 MB, and
    common junk dirs (.git, node_modules, __pycache__, .venv)."""
    from pathlib import Path
    p = Path(args.strip()).expanduser()
    if not p.is_dir():
        return f"[red]not a directory:[/red] {p}"
    store = getattr(ctx.agent, "files", None)
    if store is None:
        return "[red]FileStore not wired on agent[/red]"

    skip_dirs = {".git", "node_modules", "__pycache__", ".venv", ".tox", "dist", "build"}
    max_bytes = 5 * 1024 * 1024
    n_added = 0
    n_skipped = 0
    for f in p.rglob("*"):
        if not f.is_file():
            continue
        if any(part in skip_dirs or part.startswith(".") for part in f.parts):
            n_skipped += 1
            continue
        try:
            if f.stat().st_size > max_bytes:
                n_skipped += 1
                continue
            store.upload(f, filename=str(f.relative_to(p)))
            n_added += 1
        except Exception:
            n_skipped += 1
    return (
        f"[green]added[/green] {p}  ·  "
        f"[cyan]{n_added}[/cyan] files indexed, "
        f"[dim]{n_skipped} skipped[/dim]\n"
        "[dim]reference any with @<relative/path> in your next message[/dim]"
    )


def _branch(ctx: SlashContext, args: str) -> str:
    import subprocess
    name = args.strip() or f"caudate-{getattr(ctx.agent.session, 'id', 'x')[:8]}"
    try:
        proc = subprocess.run(
            ["git", "checkout", "-b", name],
            capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            return f"[green]on branch[/green] {name}"
        return f"[red]{proc.stderr.strip()}[/red]"
    except Exception as e:
        return f"[red]{e}[/red]"


def _worktree(ctx: SlashContext, args: str) -> str:
    import subprocess
    cmd = args.strip().split() or ["list"]
    sub = cmd[0]
    if sub == "list":
        proc = subprocess.run(
            ["git", "worktree", "list"], capture_output=True, text=True,
        )
        return proc.stdout or "[dim]no worktrees[/dim]"
    if sub == "enter":
        if len(cmd) < 2:
            return "usage: /worktree enter <id>"
        return f"[yellow]cd manually:[/yellow] use EnterWorktree tool in chat"
    if sub == "exit":
        return "[yellow]ExitWorktree tool[/yellow] handles this — call it via chat"
    return "usage: /worktree [list|enter <id>|exit]"


def _feedback(ctx: SlashContext, args: str) -> str:
    return (
        "[bold]feedback[/bold]\n"
        "  bugs:   https://github.com/raveuk/caudate-cli/issues\n"
        "  email:  rahimtz93@googlemail.com"
    )


def _goal(ctx: SlashContext, args: str) -> str:
    """Phase 2.3 — goal management slash command.

    Sub-commands:
      /goal                  — show current active goal status
      /goal new "<intent>"   — create + activate + persist
      /goal list [--all]     — list recent goals (default: active+paused)
      /goal resume <id>      — switch active goal (full id or ≥4-char prefix)
      /goal status           — full details of the active goal
      /goal complete         — mark active goal completed
      /goal abandon [reason] — mark active goal abandoned + archive
      /goal pause            — pause the active goal (kept in list)
    """
    import os
    try:
        from core.goal import Goal, GoalStatus
        from core.goal_store import get_store
    except Exception as e:
        return f"[red]goal subsystem unavailable: {e}[/red]"

    store = get_store()
    arg = args.strip()
    if not arg:
        # Default: show status of the current active goal
        return _goal_status(ctx, store)

    parts = arg.split(maxsplit=1)
    verb = parts[0].lower()
    rest = parts[1].strip() if len(parts) > 1 else ""

    if verb == "new":
        return _goal_new(ctx, store, rest)
    if verb == "list":
        return _goal_list(ctx, store, rest)
    if verb == "resume":
        return _goal_resume(ctx, store, rest)
    if verb == "status":
        return _goal_status(ctx, store)
    if verb == "complete":
        return _goal_complete(ctx, store)
    if verb in ("abandon", "drop"):
        return _goal_abandon(ctx, store, rest)
    if verb == "pause":
        return _goal_pause(ctx, store)

    # Legacy free-text form: `/goal <text>` → create a new goal with
    # that intent. Preserves the old behavior for users who don't
    # type a sub-command.
    return _goal_new(ctx, store, arg)


def _goal_new(ctx, store, intent: str) -> str:
    from core.goal import Goal
    import os
    intent = intent.strip().strip('"').strip("'")
    if not intent:
        return "[red]usage: /goal new \"<intent>\"[/red]"
    goal = Goal.new(intent=intent, cwd=os.getcwd())
    if not store.save(goal):
        return "[red]failed to save goal to disk[/red]"
    store.set_active(goal.id)
    ctx.agent.active_goal = goal
    ctx.agent._goal = intent  # keep legacy attr in sync for free-text consumers
    return (
        f"[green]goal created:[/green] {goal.short_id()}  "
        f"[bold]{intent!r}[/bold]\n"
        f"  cwd: {goal.cwd}\n"
        f"  decompose with subtasks, or just start working — caudate "
        f"will record attempts as you go."
    )


def _goal_list(ctx, store, rest: str) -> str:
    from core.goal import GoalStatus
    show_all = "--all" in rest or "all" in rest.split()
    if show_all:
        goals = store.list()
    else:
        # Default: hide completed + abandoned
        goals = [
            g for g in store.list(limit=0)
            if g.status in (GoalStatus.ACTIVE, GoalStatus.PAUSED)
        ][:20]
    if not goals:
        return "[dim]no goals yet. Create one with /goal new \"...\".[/dim]"
    active = store.active()
    active_id = active.id if active else None
    lines = ["[bold]Goals[/bold]"]
    for g in goals:
        marker = "▶ " if g.id == active_id else "  "
        lines.append(f"{marker}{g.summary_line()}")
    if not show_all:
        n_done = store.count(status=GoalStatus.COMPLETED)
        n_abandoned = store.count(status=GoalStatus.ABANDONED)
        if n_done or n_abandoned:
            lines.append(f"[dim]+ {n_done} completed, {n_abandoned} abandoned (--all to show)[/dim]")
    return "\n".join(lines)


def _goal_resume(ctx, store, goal_id: str) -> str:
    goal_id = goal_id.strip()
    if not goal_id:
        return "[red]usage: /goal resume <id>[/red]"
    goal = store.load(goal_id)
    if goal is None:
        return f"[red]no goal matches {goal_id!r}[/red] — try /goal list"
    store.set_active(goal.id)
    ctx.agent.active_goal = goal
    ctx.agent._goal = goal.intent
    return (
        f"[green]resumed:[/green] {goal.short_id()}  [bold]{goal.intent!r}[/bold]\n"
        f"  cwd: {goal.cwd}\n"
        f"  progress: {int(goal.progress_fraction()*100)}%  "
        f"({len([s for s in goal.subtasks if s.status.value == 'done'])}/{len(goal.subtasks)} subtasks)"
    )


def _goal_status(ctx, store) -> str:
    goal = getattr(ctx.agent, "active_goal", None)
    if goal is None:
        goal = store.active()
        if goal is not None:
            ctx.agent.active_goal = goal
    if goal is None:
        return "[dim]no active goal. Create one with /goal new \"...\" or resume with /goal resume <id>.[/dim]"
    return goal.render_for_prompt()


def _goal_complete(ctx, store) -> str:
    goal = getattr(ctx.agent, "active_goal", None)
    if goal is None:
        return "[red]no active goal to complete.[/red]"
    goal.complete()
    store.save(goal)
    store.set_active(None)
    ctx.agent.active_goal = None
    ctx.agent._goal = ""
    return f"[green]✓ goal completed:[/green] {goal.short_id()} {goal.intent!r}"


def _goal_abandon(ctx, store, reason: str) -> str:
    goal = getattr(ctx.agent, "active_goal", None)
    if goal is None:
        return "[red]no active goal to abandon.[/red]"
    goal.abandon(reason=reason)
    store.save(goal)
    store.archive(goal.id)
    ctx.agent.active_goal = None
    ctx.agent._goal = ""
    suffix = f" ({reason})" if reason else ""
    return f"[yellow]✗ goal abandoned:[/yellow] {goal.short_id()} {goal.intent!r}{suffix}"


def _goal_pause(ctx, store) -> str:
    from core.goal import GoalStatus
    goal = getattr(ctx.agent, "active_goal", None)
    if goal is None:
        return "[red]no active goal to pause.[/red]"
    goal.status = GoalStatus.PAUSED
    goal.touch()
    store.save(goal)
    store.set_active(None)
    ctx.agent.active_goal = None
    ctx.agent._goal = ""
    return f"[yellow]⏸ goal paused:[/yellow] {goal.short_id()} (resume with /goal resume {goal.short_id()})"


def _debug(ctx: SlashContext, args: str) -> str:
    import logging
    arg = args.strip().lower()
    if arg in ("on", "true", "1", "yes"):
        logging.getLogger().setLevel(logging.DEBUG)
        return "[green]debug logging ON[/green]"
    if arg in ("off", "false", "0", "no"):
        logging.getLogger().setLevel(logging.INFO)
        return "[yellow]debug logging OFF[/yellow]"
    cur = logging.getLevelName(logging.getLogger().level)
    return f"log level: {cur}  (use `/debug on|off`)"


def _list_commands(ctx: SlashContext, args: str) -> str:
    """List discovered custom command files."""
    try:
        from core.custom_commands import discover
        cmds = discover()
    except Exception as e:
        return f"[red]custom command discovery failed: {e}[/red]"
    if not cmds:
        return (
            "[dim]No custom commands found. Drop a markdown file at "
            "~/.config/caudate/commands/<name>.md or "
            "./.caudate/commands/<name>.md to register one.[/dim]"
        )
    lines = [f"[bold]custom commands[/bold]  ({len(cmds)} found)", ""]
    for name in sorted(cmds.keys()):
        c = cmds[name]
        tag = "[cyan]project[/cyan]" if c.source == "project" else "[magenta]user[/magenta]"
        placeholders = c.placeholders()
        ph_hint = f" [dim]({', '.join('$' + p for p in placeholders)})[/dim]" if placeholders else ""
        desc = f" — {c.description}" if c.description else ""
        lines.append(f"  /{name}{ph_hint}  {tag}{desc}")
    return "\n".join(lines)


def _reload_commands(ctx: SlashContext, args: str) -> str:
    try:
        from core.custom_commands import discover
        cmds = discover(force_refresh=True)
    except Exception as e:
        return f"[red]reload failed: {e}[/red]"
    return f"[green]reloaded[/green] — {len(cmds)} custom command(s) available"


def _cost(ctx: SlashContext, args: str) -> str:
    """Print session usage + cost breakdown."""
    try:
        from core.usage import get_global_tracker
        tracker = get_global_tracker()
    except Exception as e:
        return f"[red]usage tracker unavailable: {e}[/red]"

    report = tracker.report()
    if not report["by_model"]:
        return "[dim]no usage recorded yet this session[/dim]"

    lines: list[str] = []
    lines.append(
        f"[bold]session totals[/bold]  "
        f"[cyan]{report['total_tokens']:,}[/cyan] tokens · "
        f"[green]${report['total_cost_usd']:.6f}[/green]"
    )
    lines.append("")
    lines.append(f"  [bold]model[/bold]                        [bold]in[/bold]      [bold]out[/bold]     [bold]reqs[/bold]")
    for model, u in report["by_model"].items():
        lines.append(
            f"  {model:<28} {u['prompt_tokens']:>7} {u['completion_tokens']:>7} {u['requests']:>5}"
        )
    return "\n".join(lines)


def _sudo_forget(ctx: SlashContext, args: str) -> str:
    try:
        from execution.tools.shell_tool import _invalidate_sudo_password
        _invalidate_sudo_password()
        return "[green]sudo password cleared from memory.[/green] Next sudo command will re-prompt."
    except Exception as e:
        return f"[red]failed to clear sudo password: {e}[/red]"


def _loop(ctx: SlashContext, args: str) -> str:
    parts = args.strip().split(None, 1)
    if len(parts) < 2:
        return "usage: /loop <seconds> <prompt>"
    try:
        interval = int(parts[0])
    except ValueError:
        return "first arg must be seconds (integer)"
    prompt = parts[1]
    return (
        f"[yellow]/loop is session-scoped and not yet wired[/yellow] — "
        f"use `caudate cron add --interval {interval} '{prompt}'` for now"
    )


# ---- registry --------------------------------------------------------

REGISTRY: dict[str, HandlerFn] = {
    "help": _help, "?": _help,
    "quit": _quit, "exit": _quit, "q": _quit,
    "clear": _clear, "reset": _clear,
    "compact": _compact,
    "model": _model,
    "cost": _cost, "usage": _cost,
    "tools": _tools,
    "sessions": _sessions,
    "export": _export,
    "files": _files,
    "permissions": _permissions, "perms": _permissions,
    "yolo": _yolo, "bypass": _yolo,
    "allow": _allow,
    "deny": _deny,
    "personality": _personality,
    "router": _router,
    "diff": _diff,
    "status": _status,
    "cron": _cron,
    "bg": _bg, "background": _bg,
    "notify": _notify,
    "think": _think,
    "save": _save,
    "voice": _voice, "talk": _voice,
    "serve": _serve, "server": _serve,
    "caudate": _caudate, "nn": _caudate,
    "system1": _system1, "s1": _system1,
    "system2": _system2, "s2": _system2,
    "swap": _swap_s1_s2,
    "models-refresh": _models_refresh, "refresh-models": _models_refresh,
    "feedback": _outcome_feedback, "rate": _outcome_feedback,
    "strategies": _strategies, "strategy": _strategies,
    "init": _init,
    "doctor": _doctor,
    "update": _update,
    "update-caudate": _update_caudate,
    "config": _config,
    "resume": _resume,
    "retry": _retry,
    "fast": _fast,
    "effort": _effort,
    "skills": _skills,
    "agents": _agents,
    "mcp": _mcp,
    "hooks": _hooks,
    "memory": _memory,
    "remember": _remember,
    "context": _context,
    "copy": _copy,
    "add-dir": _add_dir,
    "branch": _branch,
    "worktree": _worktree,
    # Phase 1.6: "feedback" was registered earlier to _outcome_feedback —
    # the old bug-report `_feedback` stub kept as `/contact` for parity.
    "contact": _feedback,
    "goal": _goal,
    "debug": _debug,
    "loop": _loop,
    "sudo-forget": _sudo_forget,
    "cost": _cost,
    "usage": _cost,
    "commands": _list_commands,
    "reload-commands": _reload_commands,
}


def is_slash(text: str) -> bool:
    if not text.startswith("/") or len(text) < 2 or text.startswith("//"):
        return False
    # Reject file paths like `/tmp/foo.png` or `/home/user/...` — a
    # real slash command's first token has no additional `/` after the
    # leading one. (We split on whitespace to allow `/cmd arg/with/slash`.)
    first_token = text.split(None, 1)[0]
    if "/" in first_token[1:]:
        return False
    return True


def dispatch(text: str, ctx: SlashContext) -> Any:
    """Run a slash command. Returns:
       - str  → printable result
       - SlashResult.QUIT  → caller should exit
       - SlashResult.RESET → caller should refresh prompt state
       - ChatAsUser(text=…) → caller should treat text as the user's next message
       - None → unhandled (caller should fall through to normal chat)
    """
    if not is_slash(text):
        return None
    body = text[1:].strip()
    if not body:
        return ""
    name, _, rest = body.partition(" ")
    name_lc = name.lower()
    handler = REGISTRY.get(name_lc)
    if handler is None:
        # No built-in match — try custom command files.
        result = _try_custom_command(name_lc, rest, ctx)
        if result is not None:
            return result
        return f"[red]unknown command: /{name}[/red] (try /help)"
    try:
        return handler(ctx, rest)
    except Exception as e:
        logger.exception(f"slash /{name} failed: {e}")
        return f"[red]/{name} failed: {e}[/red]"


def _try_custom_command(name: str, arg_str: str, ctx: SlashContext) -> Any:
    """Match `name` against discovered custom command files. Prompts
    for any placeholders, then returns ChatAsUser(rendered_template)
    so main.py treats it as the user's next message.
    """
    try:
        from core.custom_commands import discover
    except Exception:
        return None
    cmds = discover()
    cmd = cmds.get(name)
    if cmd is None:
        return None

    placeholders = cmd.placeholders()
    values: dict[str, str] = {}

    # If the user passed values inline as `key=value` pairs, harvest those first.
    if arg_str:
        try:
            for tok in shlex.split(arg_str):
                if "=" in tok:
                    k, v = tok.split("=", 1)
                    values[k.upper().strip()] = v
        except ValueError:
            pass

    # Prompt for any still-missing placeholders.
    for ph in placeholders:
        if ph in values:
            continue
        val = _prompt_for_placeholder(ph, ctx.console)
        if val is None:
            return "[yellow]cancelled[/yellow]"
        values[ph] = val

    rendered = cmd.render(values)
    return ChatAsUser(text=rendered)


def _prompt_for_placeholder(name: str, console: Console) -> str | None:
    """Pop a prompt_toolkit text input asking for the value of `$name`."""
    import os as _os
    _os.environ.setdefault("PROMPT_TOOLKIT_NO_CPR", "1")
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.formatted_text import HTML
        session: PromptSession = PromptSession()
        return session.prompt(
            HTML(f"  <ansicyan>${name}</ansicyan>: "),
        )
    except (KeyboardInterrupt, EOFError):
        return None
    except Exception:
        # Fall back to plain stdin if prompt_toolkit can't run.
        try:
            return console.input(f"  ${name}: ")
        except (KeyboardInterrupt, EOFError):
            return None
