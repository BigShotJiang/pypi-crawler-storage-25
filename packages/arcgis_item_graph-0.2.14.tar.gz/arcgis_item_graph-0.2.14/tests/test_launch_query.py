# tests/test_launch_query.py
"""Tests for launch_query.py — the zero-friction user launcher."""
import json
import sys
from pathlib import Path

import pytest

# launch_query.py lives in the project root, not inside a package.
# Add project root to sys.path so pytest can import it.
sys.path.insert(0, str(Path(__file__).parent.parent))

from launch_query import (
    build_portal_menu,
    validate_item_id,
    append_audit_record,
    update_last_audit_record,
)


class TestBuildPortalMenu:
    def test_wraps_portals_list(self):
        portals = [{"name": "L48", "url": "https://l48.example.com"}]
        menu = build_portal_menu(portals)
        assert menu[0] == ("L48", "https://l48.example.com")

    def test_appends_other_at_end(self):
        menu = build_portal_menu([])
        assert menu[-1] == ("Other", None)

    def test_preserves_order(self):
        portals = [
            {"name": "L48", "url": "https://l48.example.com"},
            {"name": "Alaska", "url": "https://alaska.example.com"},
        ]
        menu = build_portal_menu(portals)
        assert menu[0][0] == "L48"
        assert menu[1][0] == "Alaska"
        assert menu[2] == ("Other", None)

    def test_empty_portals_still_has_other(self):
        menu = build_portal_menu([])
        assert len(menu) == 1
        assert menu[0] == ("Other", None)


class TestValidateItemId:
    def test_valid_lowercase_hex(self):
        assert validate_item_id("abc123def456abc123def456abc123de") is True

    def test_valid_uppercase_hex(self):
        assert validate_item_id("ABC123DEF456ABC123DEF456ABC123DE") is True

    def test_valid_mixed_case(self):
        assert validate_item_id("Abc123DeF456abc123def456abc123de") is True

    def test_too_short(self):
        assert validate_item_id("abc123") is False

    def test_too_long(self):
        assert validate_item_id("abc123def456abc123def456abc123de00") is False

    def test_31_chars(self):
        assert validate_item_id("abc123def456abc123def456abc123d") is False

    def test_non_hex_chars(self):
        assert validate_item_id("gggggggggggggggggggggggggggggggg") is False

    def test_empty_string(self):
        assert validate_item_id("") is False

    def test_whitespace_stripped(self):
        # Users may paste with trailing space
        assert validate_item_id("  abc123def456abc123def456abc123de  ") is True


class TestAppendAuditRecord:
    def test_creates_file_on_first_write(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        append_audit_record(log, {"status": "pending", "item_id": "abc"})
        assert log.exists()

    def test_record_is_valid_json(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        append_audit_record(log, {"status": "pending"})
        data = json.loads(log.read_text().strip())
        assert data["status"] == "pending"

    def test_appends_multiple_records(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        append_audit_record(log, {"status": "success"})
        append_audit_record(log, {"status": "failed"})
        lines = [l for l in log.read_text().splitlines() if l.strip()]
        assert len(lines) == 2

    def test_creates_parent_directories(self, tmp_path):
        log = tmp_path / "nested" / "dir" / "query_audit.jsonl"
        append_audit_record(log, {"status": "pending"})
        assert log.exists()


class TestUpdateLastAuditRecord:
    def test_updates_status_on_last_line(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        log.write_text('{"status": "pending"}\n')
        update_last_audit_record(log, status="success")
        last = json.loads(log.read_text().splitlines()[-1])
        assert last["status"] == "success"

    def test_updates_multiple_fields(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        log.write_text('{"status": "pending", "duration_sec": null}\n')
        update_last_audit_record(log, status="success", duration_sec=12.3, exit_code=0)
        last = json.loads(log.read_text().splitlines()[-1])
        assert last["status"] == "success"
        assert last["duration_sec"] == 12.3
        assert last["exit_code"] == 0

    def test_preserves_existing_fields(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        log.write_text('{"item_id": "abc123", "status": "pending"}\n')
        update_last_audit_record(log, status="success")
        last = json.loads(log.read_text().splitlines()[-1])
        assert last["item_id"] == "abc123"

    def test_only_modifies_last_line(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        log.write_text('{"status": "success"}\n{"status": "pending"}\n')
        update_last_audit_record(log, status="success")
        lines = [l for l in log.read_text().splitlines() if l.strip()]
        first = json.loads(lines[0])
        assert first["status"] == "success"  # first line unchanged

    def test_noop_when_file_missing(self, tmp_path):
        log = tmp_path / "nonexistent.jsonl"
        # Must not raise
        update_last_audit_record(log, status="success")

    def test_noop_when_file_empty(self, tmp_path):
        log = tmp_path / "query_audit.jsonl"
        log.write_text("")
        update_last_audit_record(log, status="success")  # Must not raise


import subprocess as _subprocess  # alias to avoid shadowing in monkeypatch


class TestRunQuery:
    """run_query(item_id, portal_url, username, password, config_path) → (exit_code, duration)"""

    def test_returns_zero_exit_code_on_success(self, monkeypatch):
        mock_result = _subprocess.CompletedProcess(args=[], returncode=0)
        monkeypatch.setattr(_subprocess, "run", lambda *a, **kw: mock_result)

        from launch_query import run_query
        exit_code, duration = run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="secret",
            config_path=Path("config/config.yaml"),
        )
        assert exit_code == 0

    def test_returns_nonzero_on_failure(self, monkeypatch):
        mock_result = _subprocess.CompletedProcess(args=[], returncode=1)
        monkeypatch.setattr(_subprocess, "run", lambda *a, **kw: mock_result)

        from launch_query import run_query
        exit_code, _ = run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="secret",
            config_path=Path("config/config.yaml"),
        )
        assert exit_code == 1

    def test_duration_is_non_negative(self, monkeypatch):
        mock_result = _subprocess.CompletedProcess(args=[], returncode=0)
        monkeypatch.setattr(_subprocess, "run", lambda *a, **kw: mock_result)

        from launch_query import run_query
        _, duration = run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="secret",
            config_path=Path("config/config.yaml"),
        )
        assert duration >= 0

    def test_password_not_in_command_args(self, monkeypatch):
        captured = {}

        def mock_run(cmd, env=None, **kw):
            captured["cmd"] = cmd
            captured["env"] = env
            return _subprocess.CompletedProcess(args=cmd, returncode=0)

        monkeypatch.setattr(_subprocess, "run", mock_run)

        from launch_query import run_query
        run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="mysecret",
            config_path=Path("config/config.yaml"),
        )
        cmd_str = " ".join(str(a) for a in captured["cmd"])
        assert "mysecret" not in cmd_str

    def test_credentials_injected_as_env_vars(self, monkeypatch):
        captured = {}

        def mock_run(cmd, env=None, **kw):
            captured["env"] = env
            return _subprocess.CompletedProcess(args=cmd, returncode=0)

        monkeypatch.setattr(_subprocess, "run", mock_run)

        from launch_query import run_query
        run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://portal.example.com",
            username="jsmith",
            password="mysecret",
            config_path=Path("config/config.yaml"),
        )
        assert captured["env"]["ARCGIS_URL"] == "https://portal.example.com"
        assert captured["env"]["ARCGIS_USER"] == "jsmith"
        assert captured["env"]["ARCGIS_PASSWORD"] == "mysecret"

    def test_config_path_passed_to_subprocess(self, monkeypatch):
        captured = {}

        def mock_run(cmd, env=None, **kw):
            captured["cmd"] = cmd
            return _subprocess.CompletedProcess(args=cmd, returncode=0)

        monkeypatch.setattr(_subprocess, "run", mock_run)

        from launch_query import run_query
        run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="secret",
            config_path=Path("/shared/config/config.yaml"),
        )
        cmd_str = " ".join(str(a) for a in captured["cmd"])
        assert "/shared/config/config.yaml" in cmd_str

    def test_serve_flag_included_in_command(self, monkeypatch):
        captured = {}

        def mock_run(cmd, env=None, **kw):
            captured["cmd"] = cmd
            return _subprocess.CompletedProcess(args=cmd, returncode=0)

        monkeypatch.setattr(_subprocess, "run", mock_run)

        from launch_query import run_query
        run_query(
            item_id="abc123def456abc123def456abc123de",
            portal_url="https://test.example.com",
            username="jsmith",
            password="secret",
            config_path=Path("config/config.yaml"),
        )
        assert "--serve" in captured["cmd"]


class TestPromptPortal:
    """prompt_portal(menu) → (env_name, url)"""

    def test_valid_first_choice(self, monkeypatch):
        monkeypatch.setattr("builtins.input", lambda _: "1")
        from launch_query import prompt_portal
        menu = [("L48", "https://l48.example.com"), ("Other", None)]
        name, url = prompt_portal(menu)
        assert name == "L48"
        assert url == "https://l48.example.com"

    def test_empty_input_defaults_to_first(self, monkeypatch):
        monkeypatch.setattr("builtins.input", lambda _: "")
        from launch_query import prompt_portal
        menu = [("L48", "https://l48.example.com"), ("Other", None)]
        name, url = prompt_portal(menu)
        assert name == "L48"

    def test_other_option_prompts_for_url(self, monkeypatch):
        # First call: choice "2" (Other); second call: custom URL
        calls = iter(["2", "https://custom.example.com"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        from launch_query import prompt_portal
        menu = [("L48", "https://l48.example.com"), ("Other", None)]
        name, url = prompt_portal(menu)
        assert name == "Other"
        assert url == "https://custom.example.com"

    def test_invalid_choice_reprompts(self, monkeypatch):
        # "99" is invalid, then "1" is valid
        calls = iter(["99", "1"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        from launch_query import prompt_portal
        menu = [("L48", "https://l48.example.com"), ("Other", None)]
        name, url = prompt_portal(menu)
        assert name == "L48"

    def test_non_numeric_reprompts(self, monkeypatch):
        calls = iter(["abc", "1"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        from launch_query import prompt_portal
        menu = [("L48", "https://l48.example.com"), ("Other", None)]
        name, url = prompt_portal(menu)
        assert name == "L48"


class TestMain:
    """Integration test for main() — mocks I/O and subprocess."""

    def _make_config(self, tmp_path: Path) -> Path:
        """Write a minimal valid config.yaml under tmp_path."""
        import yaml
        config = {
            "portals": [{"name": "L48", "url": "https://l48.example.com"}],
            "paths": {
                "gml_file": str(tmp_path / "graph.gml"),
                "timestamp_file": str(tmp_path / "graph.timestamp"),
                "output_dir": str(tmp_path / "outputs"),
                "run_log": "",
            },
            "cache": {"update_warn_hours": 24, "query_cache_hours": 24},
            "query": {"max_depth": None, "output_formats": ["excel", "html"]},
        }
        config_path = tmp_path / "config" / "config.yaml"
        config_path.parent.mkdir(parents=True)
        config_path.write_text(yaml.dump(config))
        return config_path

    def test_successful_query_writes_success_audit_record(
        self, monkeypatch, tmp_path
    ):
        import subprocess as sp
        config_path = self._make_config(tmp_path)

        # Portal=1, username, item_id
        calls = iter(["1", "jsmith", "abc123def456abc123def456abc123de"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        monkeypatch.setattr("getpass.getpass", lambda _: "password")
        monkeypatch.setattr(sp, "run", lambda *a, **kw: sp.CompletedProcess([], 0))

        from launch_query import main
        main(config_path=config_path)

        log_path = tmp_path / "outputs" / "query_audit.jsonl"
        assert log_path.exists()
        last = json.loads(log_path.read_text().splitlines()[-1])
        assert last["status"] == "success"
        assert last["arcgis_user"] == "jsmith"
        assert last["item_id"] == "abc123def456abc123def456abc123de"
        assert last["portal_env"] == "L48"

    def test_failed_query_writes_failed_audit_record(
        self, monkeypatch, tmp_path
    ):
        import subprocess as sp
        config_path = self._make_config(tmp_path)

        calls = iter(["1", "jsmith", "abc123def456abc123def456abc123de"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        monkeypatch.setattr("getpass.getpass", lambda _: "badpassword")
        monkeypatch.setattr(sp, "run", lambda *a, **kw: sp.CompletedProcess([], 1))

        from launch_query import main
        with pytest.raises(SystemExit) as exc:
            main(config_path=config_path)
        assert exc.value.code == 1

        log_path = tmp_path / "outputs" / "query_audit.jsonl"
        last = json.loads(log_path.read_text().splitlines()[-1])
        assert last["status"] == "failed"

    def test_windows_user_and_machine_captured(self, monkeypatch, tmp_path):
        import subprocess as sp
        config_path = self._make_config(tmp_path)

        monkeypatch.setenv("USERNAME", "testuser")
        monkeypatch.setenv("COMPUTERNAME", "TESTMACHINE")
        calls = iter(["1", "testuser", "abc123def456abc123def456abc123de"])
        monkeypatch.setattr("builtins.input", lambda _: next(calls))
        monkeypatch.setattr("getpass.getpass", lambda _: "password")
        monkeypatch.setattr(sp, "run", lambda *a, **kw: sp.CompletedProcess([], 0))

        from launch_query import main
        main(config_path=config_path)

        log_path = tmp_path / "outputs" / "query_audit.jsonl"
        last = json.loads(log_path.read_text().splitlines()[-1])
        assert last["windows_user"] == "testuser"
        assert last["machine"] == "TESTMACHINE"
