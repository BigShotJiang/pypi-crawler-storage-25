__version__ = "1.9.1"


def print_version():
    print(f"v{__version__}")


if __name__ == "__main__":
    print_version()
