# -*- coding: utf-8 -*-
# source.py - SQL 数据源类
# author: JohnLui
# date: 2026-04-29

"""
SqlDataSource - SQL 数据源类（管理配置文件）

职责：
- 读取 sqldata.conf 配置
- 工厂方法 get() 返回 SqlDataModel 实例
- 管理多个 SqlDataModel 实例缓存

语义：Source = 源头，数据从哪里来
"""

import os
import configparser
from .sqldata_model import SqlDataModel


class SqlDataSource:
    """SQL 数据源类
    
    管理 sqldata.conf 配置文件，提供工厂方法获取 SqlDataModel 实例。
    
    Example:
        source = SqlDataSource('/data/sqldata.conf')
        source.list_sources()  # ['findata', 'fundamentals']
        model = source.get('findata')  # SqlDataModel 实例
    """
    
    def __init__(self, config_path):
        """初始化 SQL 数据源
        
        Args:
            config_path: 配置文件路径（sqldata.conf）
        
        Raises:
            FileNotFoundError: 配置文件不存在
        """
        if not os.path.exists(config_path):
            raise FileNotFoundError(f'Config file not found: {config_path}')
        
        self._config_path = config_path
        self._config = configparser.ConfigParser()
        self._config.read(config_path)
        
        # 缓存已创建的 SqlDataModel 实例
        self._models = {}  # {数据源名: SqlDataModel}
    
    def get(self, source_name='findata'):
        """获取数据模型实例
        
        Args:
            source_name: 数据源名（配置小节名，默认 'findata'）
        
        Returns:
            SqlDataModel 实例
        
        Raises:
            ValueError: 数据源未配置
        
        Example:
            model = source.get('findata')
            model = source.get('fundamentals')
        """
        if source_name not in self._config.sections():
            raise ValueError(f'Data source "{source_name}" not configured')
        
        # 缓存
        if source_name not in self._models:
            self._models[source_name] = SqlDataModel(self._config[source_name], source_name)
        
        return self._models[source_name]
    
    def list_sources(self):
        """列出所有配置的数据源名
        
        Returns:
            list: 数据源名列表
        
        Example:
            source.list_sources()  # ['findata', 'fundamentals']
        """
        return self._config.sections()
    
    def close_all(self):
        """断开所有数据模型连接"""
        for model in self._models.values():
            model.close()
        self._models.clear()
    
    def __repr__(self):
        return f"<SqlDataSource config='{self._config_path}' sources={self.list_sources()}>"