# -*- coding: utf-8 -*-

from .wraps import *
from .quote_base import *
from .quote_data import *
from .quote_archive import *
from .sqldata_source import SqlDataSource
from .sqldata_model import SqlDataModel
# from .technical_analysis import *
import multiprocessing

try:
    if multiprocessing.get_start_method() != 'spawn':
        multiprocessing.set_start_method('spawn')
except:
    pass

__version__ = '0.9.1'

# NOTE: QuoteFactor deprecated in v0.8.2 (BREAK CHANGE)
# Use QuoteData.get_factors(), get_factor_data(), get_factor_static() instead

# NOTE: sqldata 模块使用说明
# ORM Query 构建：使用 model._session.query(model.table) 或 SQLAlchemy select() 语句
# 示例：q = model._session.query(model.stk_mt_total).filter(model.stk_mt_total.date >= '2024-01-01')
#      df = model.run_query(q)

__all__ = [
    'JQWraps',
    'QuoteData',
    'QuoteArchive',
    'SqlDataSource',
    'SqlDataModel',
    '__version__'
]