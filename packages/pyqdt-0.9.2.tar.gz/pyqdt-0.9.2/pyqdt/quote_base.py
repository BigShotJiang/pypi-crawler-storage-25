# -*- coding: utf-8 -*-
import os, sys
import math
import numpy as np
import pandas as pd

from io import BytesIO
from functools import lru_cache, wraps

from .utils import *

def assert_quote_init(func):
    @wraps(func)
    def _wrapper(*args, **kwargs):
        data_path = args[0].get_data_path()
        if not data_path or not os.path.exists(data_path):
            print("Quote is not initialized.")
        else:
            return func(*args, **kwargs)

    return _wrapper

class QuoteBase(object):
    def __init__(self, data_path=None, cache_maxsize=32):
        """本地行情数据类

        参数:
            data_path: 数据目录
            cache_maxsize: 缓存条目上限，默认 32

        """
        if not hasattr(self, '_data_path'):
            self._data_path = ''
        if data_path:
            self.init(data_path)
        if not hasattr(self, '_options'):
            self._options = {
                'debug': False,
                'cache_maxsize': cache_maxsize,
            }
        # 动态创建带缓存的数据获取方法
        if not hasattr(self, '_cached_fetch'):
            self._cached_fetch = lru_cache(maxsize=cache_maxsize)(self._fetch_data_impl)
        # 动态创建板块快照缓存方法
        if not hasattr(self, '_cached_block_snapshot'):
            self._cached_block_snapshot = lru_cache(maxsize=8)(self._get_block_snapshot_impl)

    def _fetch_data_impl(self, filename, date_columns=None, iostream=None):
        """获取数据（实际逻辑）

        参数:
            filename: 数据文件名
            date_columns: 日期字段
            iostream: BytesIO 流

        返回值: DataFrame

        """
        if not iostream:
            data_file = os.path.join(self._data_path, filename)
            if not os.path.exists(data_file):
                return
            iostream = data_file

        result = None
        extname = os.path.splitext(filename)[-1][1:].lower()
        if extname == 'csv':
            if not date_columns:
                parse_dates = False
            elif type(date_columns) is list:
                parse_dates = date_columns
            elif type(date_columns) is tuple:
                parse_dates = list(date_columns)
            elif type(date_columns) is str:
                parse_dates = [date_columns]
            else:
                raise ValueError('date_columns is error.')
            result = pd.read_csv(iostream, dtype={'code': str}, parse_dates=parse_dates)
        elif extname == 'txt':
            with open(iostream, 'r') as f:
                result = f.readlines()
        return result

    @assert_quote_init
    def _fetch_data(self, filename, date_columns=None, iostream=None):
        """获取数据（带缓存）

        参数:
            filename: 数据文件名
            date_columns: 日期字段
            iostream: BytesIO 流

        返回值: DataFrame

        """
        return self._cached_fetch(filename, date_columns, iostream)

    def clear_cache(self):
        """清理数据缓存

        清理 _fetch_data 方法的 LRU 缓存，释放内存。

        """
        self._cached_fetch.cache_clear()

    @classmethod
    def _get_price_precision(cls, security) -> int:
        """获取价格精度

        参数:
            security: 字符串或列表

        返回值: 精度或精度列表

        """
        if type(security) is str:
            n = 2
            p = security.find('.')
            if p >= 0:
                code = security[:p]
                exch = security[p + 1:]
                if exch == 'SZ':
                    if code[0] == '1':
                        n = 3
                    elif code[0:3] == '399' or code[0:4] == '9000':
                        n = 4
                elif exch == 'SH':
                    if code[0] == '5':
                        n = 3
                    elif code[0:3] == '000' or code[0:4] == '1000':
                        n = 4
            return n
        elif type(security) is list:
            r = []
            for s in security:
                r.append(cls._get_price_precision(s))
            return r

    @classmethod
    def _parse_period_str(cls, period) -> (str, int):
        """分析周期字串

        参数:
            period: 周期

        返回值: 类型，间隔

        """
        if period in ['day', 'daily', '1d', 'week', '1w', 'mon', 'month', '1M', 'season', 'year']:
            period_type = 'day'
            period_step = 0
        elif period[-1] == 'm' and period[:-1].isdecimal():
            period_type = 'mn1'
            period_step = int(period[:-1])
        elif period[0:2] == 'mn' and period[2:].isdecimal():
            period_type = 'mn1'
            period_step = int(period[2:])
        else:
            raise Exception('period is invalid.')
        return period_type, period_step

    def _parse_period_start(self, period, date, count):
        """分析周期开始时间

        参数:
            period: 周期
            date: 参考时间
            count: 数量

        返回值:
            参考时间 - count 个周期后的开始时间

        """
        year_minimum = 1990
        start = datetime.datetime(2005, 1, 1).date()
        if period in ['day', 'daily', '1d']:
            trade_list = self.get_trade_days(end_date=date, count=count)
            if trade_list:
                start = trade_list[0].timetuple()
        elif period in ['week', '1w']:
            trade_list = self.get_trade_days(end_date=date, count=count * 5)
            if trade_list:
                week_maps = [x.isocalendar()[0] * 100 + x.isocalendar()[1] for x in trade_list]
                week_list = list(set(week_maps))
                week_list.sort()
                w = week_list[-count]
                start = trade_list[week_maps.index(w)].timetuple()
        elif period in ['mon', 'month', '1M']:
            y = date.tm_year
            m = date.tm_mon + 1 - count
            while m <= 0:
                y -= 1
                m += 12
            y = max(y, year_minimum)
            start = datetime.datetime(y, m, 1).timetuple()
        elif period == 'season':
            y = date.tm_year
            s = (date.tm_mon - 1) // 3 + 1 - count
            while s < 0:
                y -= 1
                s += 4
            y = max(y, year_minimum)
            start = datetime.datetime(y, s * 3 + 1, 1).timetuple()
        elif period == 'year':
            y = date.tm_year + 1 - count
            y = max(y, year_minimum)
            start = datetime.datetime(y, 1, 1).timetuple()
        else:
            t, n = self._parse_period_str(period)
            if t != 'mn1':
                return
            days = math.ceil(count * n / 240)
            trade_list = self.get_trade_days(end_date=date, count=days)
            if trade_list:
                start = trade_list[0].timetuple()
        return start

    def trace(self, *args):
        if self._options.get('debug', False):
            print(time.strftime('%Y-%m-%d %H:%M:%S'), *args)

    def get_option(self, name):
        """获取可选项值

        参数:
            name: 可选项名

        返回值:
            可选项值

        """
        if name not in self._options:
            raise ValueError('option %s is not exists.' % name)

    def set_option(self, name, value):
        """设置可选项值

        参数:
            name: 可选项名
            value: 可选项值

        """
        if name not in self._options:
            raise ValueError('option %s is not exists.' % name)
        self._options[name] = value

    def init(self, data_path):
        """初始化

        参数:
            data_path: 数据目录

        """
        if not data_path or not os.path.exists(data_path):
            raise Exception('initialization failed. data_path %s is not exists.' % data_path)
        self._data_path = data_path

    def get_data_path(self):
        """获取数据目录

        返回值: 数据目录

        """
        return self._data_path

    @assert_quote_init
    def get_quote_date(self) -> datetime.date:
        """获取行情日期

        返回值:
            最新行情日期

        """
        filename = 'ckvalid.txt'
        txt = self._fetch_data(filename)
        if not txt:
            raise Exception('fetch data from %s failed.' % filename)

        result = dict()
        for s in txt:
            s = s.strip()
            if not s:
                continue
            p = s.find('=')
            if p <= 0:
                continue
            k = s[0:p].strip()
            v = s[p + 1:].strip()
            if not k or not v:
                continue
            result[k] = v
        # self.trace(result)
        stime = result.get('last_date')
        if not stime:
            raise Exception('the quote_data not found.')
        last_date = datetime.datetime.strptime(stime, '%Y-%m-%d').date()
        tdays = self.get_trade_days(end_date=last_date, count=1)
        if not tdays:
            raise Exception('trade-days is empty.')
        return tdays[0]

    @assert_quote_init
    def get_trade_days(self, start_date=None, end_date=None, count=None) -> list:
        """获取交易日列表

        参数:
            start_date: 开始日期，与 count 二选一；类型 str/struct_time/datetime.date/datetime.datetime
            end_date: 结束日期；类型 str/struct_time/datetime.date/datetime.datetime；默认值 datetime.date.today()
            count: 结果集行数，与 start_date 二选一

        返回值:
            交易日列表；类型 [datetime.date]

        """

        start_date = formatter_st(start_date) if start_date else None
        end_date = formatter_st(end_date) if end_date else None
        dt_start = np.datetime64(
            datetime.datetime.fromtimestamp(time.mktime(start_date))) if start_date else None
        dt_end = np.datetime64(datetime.datetime.fromtimestamp(time.mktime(end_date))) if end_date else None

        filename = 'quote-tdays.csv'
        df = self._fetch_data(filename, date_columns='date')
        if df is None:
            raise Exception('fetch data from %s failed.' % filename)

        # 确保日期列为 datetime64 类型
        if df['date'].dtype == 'object':
            df['date'] = pd.to_datetime(df['date'])
        
        result = df['date'].values
        if dt_start or dt_end or count:
            if not dt_end:
                dt_end = np.datetime64(datetime.date.today())
            if dt_start:
                result = result[np.where(result >= dt_start)]
            if dt_end:
                result = result[np.where(result <= dt_end)]
            if count and count > 0:
                result = result[-count:]
        
        # 使用 pd.Timestamp 转换为 date 对象
        result = [pd.Timestamp(x).date() for x in result]
        return result



    # ==================== 板块全量快照缓存层 ====================

    def _get_block_snapshot(self, date=None) -> pd.DataFrame:
        """获取指定日期的板块全量快照（带 LRU 缓存）

        替代原来固定读 quote-block-data.csv 的逻辑。
        返回当日全市场板块成分股数据，缓存按日期 key，不同板块/类型查询共享缓存。

        参数:
            date: 查询日期；类型 str/struct_time/datetime.date/datetime.datetime；
                  默认值 None（最新数据）

        返回值:
            DataFrame: block, security, weight, type（全量，未筛选）
        """
        if date:
            cache_date = time.strftime('%Y-%m-%d', formatter_st(date))
        else:
            cache_date = '__latest__'
        return self._cached_block_snapshot(cache_date)

    def _get_block_snapshot_impl(self, cache_date) -> pd.DataFrame:
        """全量快照 I/O 实现

        使用 dict + itertuples 优化（参考 idsut/pyqdt_synchronizer），
        避免 DataFrame.concat 逐行拼接，性能提升 10-100x。

        参数:
            cache_date: 日期字符串 'YYYY-MM-DD' 或 '__latest__'

        注意:
            返回的是全市场数据，由调用方自行按 block/types 筛选。
        """
        if cache_date == '__latest__':
            df = self._fetch_data('quote-block-data.csv')
            if df is None:
                return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])
            return df.copy().reset_index(drop=True)

        # 历史查询
        target_date = datetime.datetime.strptime(cache_date, '%Y-%m-%d').date()

        # 1. 找到最近的月末快照
        snapshot_date, snapshot_file = self._find_nearest_snapshot(target_date)
        if snapshot_file is None:
            return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])

        # 2. 加载全量快照
        df = self._fetch_data(snapshot_file)
        if df is None:
            return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])
        df = df.copy()

        # 3. 快照日期等于目标日期，无需应用 diff
        if snapshot_date == target_date:
            return df.reset_index(drop=True)

        # 4. 构建 dict: key='block|security' → (weight, type)
        snapshot_dict = {}
        for row in df.itertuples(index=False):
            snapshot_dict[f"{row.block}|{row.security}"] = (row.weight, row.type)

        # 5. 收集并合并所有 diff 文件
        diff_files = self._collect_diff_files(snapshot_date, target_date)
        if not diff_files:
            if not snapshot_dict:
                return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])
            return pd.DataFrame([
                {'block': k.split('|')[0], 'security': k.split('|')[1],
                 'weight': v[0], 'type': v[1]}
                for k, v in snapshot_dict.items()
            ])

        dfs = []
        for diff_file in diff_files:
            df_d = self._fetch_data(diff_file, date_columns='date')
            if df_d is not None:
                df_d = df_d.copy()
                df_d = df_d[
                    (df_d['date'].dt.date > snapshot_date) &
                    (df_d['date'].dt.date <= target_date)
                ]
                if not df_d.empty:
                    dfs.append(df_d)

        if not dfs:
            if not snapshot_dict:
                return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])
            return pd.DataFrame([
                {'block': k.split('|')[0], 'security': k.split('|')[1],
                 'weight': v[0], 'type': v[1]}
                for k, v in snapshot_dict.items()
            ])

        # 一次性 concat 并排序
        df_diff_all = pd.concat(dfs, ignore_index=True).sort_values('date')

        # 6. 遍历 diff，用 itertuples 修改 dict（全量，不过滤）
        for row in df_diff_all.itertuples(index=False):
            key = f"{row.block}|{row.security}"
            if row.opt == 'A':
                snapshot_dict[key] = (row.weight, row.type)
            elif row.opt == 'D':
                snapshot_dict.pop(key, None)
            elif row.opt == 'C':
                if key in snapshot_dict:
                    snapshot_dict[key] = (row.weight, snapshot_dict[key][1])

        if not snapshot_dict:
            return pd.DataFrame(columns=['block', 'security', 'weight', 'type'])
        return pd.DataFrame([
            {'block': k.split('|')[0], 'security': k.split('|')[1],
             'weight': v[0], 'type': v[1]}
            for k, v in snapshot_dict.items()
        ])

    def _find_nearest_snapshot(self, target_date) -> tuple:
        """找到 ≤ target_date 的最近月末快照

        从最近年份回溯查找，找到第一个符合的快照即返回（优化：避免全量扫描）。

        返回值:
            (snapshot_date: datetime.date, snapshot_path: str)
            如果找不到返回 (None, None)
        """
        block_dir = os.path.join(self._data_path, 'block')
        if not os.path.exists(block_dir):
            return None, None

        for year in range(target_date.year, 2004, -1):
            year_dir = os.path.join(block_dir, str(year))
            if not os.path.exists(year_dir):
                continue

            dates = [
                (os.path.join('block', str(year), f),
                 datetime.datetime.strptime(
                     f.replace('quote-block-data-', '').replace('.csv', ''),
                     '%Y%m%d'
                 ).date())
                for f in os.listdir(year_dir)
                if f.startswith('quote-block-data-') and f.endswith('.csv')
            ]
            # 筛选 ≤ target_date
            dates = [(p, d) for p, d in dates if d <= target_date]
            if dates:
                # 取最近的（返回 date, path）
                best = max(dates, key=lambda x: x[1])
                return (best[1], best[0])

        return None, None

    def _collect_diff_files(self, from_date, to_date) -> list:
        """收集 from_date（不含）到 to_date（含）之间的 block-diff 文件

        返回值:
            diff 文件路径列表（相对于 data_path）
        """
        diff_files = []
        for y in range(from_date.year, to_date.year + 1):
            start_m = from_date.month + 1 if y == from_date.year else 1
            end_m = to_date.month if y == to_date.year else 12
            for m in range(start_m, end_m + 1):
                diff_file = os.path.join('block', str(y), f'quote-block-diff-{y}{m:02d}.csv')
                full_path = os.path.join(self._data_path, diff_file)
                if os.path.exists(full_path):
                    diff_files.append(diff_file)
        return diff_files

    @assert_quote_init
    def get_block_info(self, block=None, types=None, date=None) -> pd.DataFrame:
        """获取板块列表

        参数:
            block: 板块代码或者板块代码的 list
            types: 板块类型；类型 字符串 list；默认值 None 获取所有板块
                   可选值: 'index', 'industry', 'concept' 等；
            date: 查询日期；类型 str/struct_time/datetime.date/datetime.datetime；
                  默认值 None 获取所有板块；指定时只返回在该日期存续中的板块
                  （start_date <= date <= end_date）

        返回值:
            DataFrame 对象：
                block（索引）：板块代码
                name：板块名称
                start_date：类型 datetime.date；启用日期
                end_date：类型 datetime.date；结束日期，可能为 None
                type：证券类型；stock（股票）, index（指数），etf（ETF基金），fja（分级A），fjb（分级B）
                sub_type：行业子分类，可能为 None

        说明:
            兼容两种 CSV 格式：
            - 老格式：block,name,date,type → 自动转换为 start_date + end_date(None) + sub_type(None)
            - 新格式：block,name,start_date,end_date,type,sub_type → 直接使用

        """
        block = formatter_list(block)
        types = formatter_list(types)
        dt_date = datetime.date.fromtimestamp(time.mktime(formatter_st(date))) if date else None

        filename = 'quote-block-map.csv'
        df = self._fetch_data(filename)
        if df is None:
            raise Exception('fetch data from %s failed.' % filename)

        # 兼容两种格式：老格式 date 列 → 新格式 start_date + end_date + sub_type
        if 'date' in df.columns and 'start_date' not in df.columns:
            # 老格式：date → start_date, 添加 end_date=None, sub_type=None
            df.rename(columns={'date': 'start_date'}, inplace=True)
            df.insert(3, 'end_date', None)    # 插入到 start_date 之后、type 之前
            df.insert(5, 'sub_type', None)    # 插入到 type 之后
            # 老格式中 type='industry' 的 sub_type 默认设置为 'zjw'
            df.loc[df['type'] == 'industry', 'sub_type'] = 'zjw'

        # 确保日期类型正确（pd.to_datetime 对已是 datetime 的列幂等）
        df['start_date'] = pd.to_datetime(df['start_date'])
        df['end_date'] = pd.to_datetime(df['end_date'])

        if types:
            df = df[df['type'].isin(types)]
        if block:
            df = df[df['block'].isin(block)]
        # 按日期过滤存续中的板块
        if dt_date:
            df = df[(df['start_date'].dt.date <= dt_date) &
                    (df['end_date'].isna() | (df['end_date'].dt.date >= dt_date))]
        result = df.copy()
        result.set_index('block', inplace=True)
        return result


    @assert_quote_init
    def get_industries(self, name='zjw', date=None) -> pd.DataFrame:
        """获取行业列表

        参数:
            name: 行业分类标准，用于筛选 sub_type 字段；默认值 'zjw'（证监会行业）；可选值：
                - 'sw_l1': 申万一级行业
                - 'sw_l2': 申万二级行业
                - 'sw_l3': 申万三级行业
                - 'jq_l1': 聚宽一级行业
                - 'jq_l2': 聚宽二级行业
                - 'zjw': 证监会行业
            date: 查询日期；默认值 None 获取所有行业；指定时只返回在该日期存续中的行业

        说明：
            本方法等同 get_block_info(types='industry', date=date)
            返回值移除索引名称
            默认筛选 sub_type == 'zjw'

        """
        result = self.get_block_info(types='industry', date=date)
        result.index.name = None
        result = result[result['sub_type'] == name]
        return result


    @assert_quote_init
    def get_concepts(self, date=None) -> pd.DataFrame:
        """获取概念列表

        参数:
            date: 查询日期；默认值 None 获取所有概念；指定时只返回在该日期存续中的概念

        说明：
            本方法等同 get_block_info(types='concept', date=date)
            返回值移除索引名称

        """
        result = self.get_block_info(types='concept', date=date)
        result.index.name = None
        return result


    @assert_quote_init
    def get_block_securities(self, block, types=None, date=None) -> list:
        """获取板块成份股（支持历史查询）

        参数:
            block: 板块代码，字符串
            types: 板块类型；类型 字符串 list；默认值 None
                   可选值: 'index', 'industry', 'concept' 等；
            date: 查询日期；类型 str/struct_time/datetime.date/datetime.datetime；
                  默认值 None（最新数据）

        返回值:
            证券代码列表

        """

        if not block:
            raise ValueError('block need be provided.')
        if not type(block) is str:
            raise ValueError('block is invalid.')
        types = formatter_list(types)

        # 获取全量快照，由调用方自行筛选
        df = self._get_block_snapshot(date)
        if block:
            df = df[df['block'] == block]
        if types:
            df = df[df['type'].isin(types)]
        if df.empty:
            return []
        return df['security'].tolist()


    @assert_quote_init
    def get_index_weights(self, index_code, date=None) -> pd.DataFrame:
        """获取指数成份股权重（支持历史查询）

        参数:
            index_code: 指数代码，字符串
            date: 查询日期；类型 str/struct_time/datetime.date/datetime.datetime；
                  默认值 None（最新数据）

        返回值:
            DataFrame 对象：
                code（索引）：证券代码
                date：数据日期（快照日期）
                weight：权重值
                display_name：证券名称

        """

        if not index_code:
            raise ValueError('index_code need be provided.')
        if not type(index_code) is str:
            raise ValueError('index_code is invalid.')

        # 获取全量快照，自行筛选指数 + index 类型
        df = self._get_block_snapshot(date)
        df = df[(df['block'] == index_code) & (df['type'] == 'index')]
        if df.empty:
            return pd.DataFrame(columns=['date', 'weight', 'display_name'])

        result = df.copy()
        result.drop(columns=['block', 'type'], inplace=True)
        result.set_index('security', inplace=True)
        result.index.name = 'code'

        # date 列为快照查询日期
        if date:
            result.insert(0, 'date', datetime.date.fromtimestamp(time.mktime(formatter_st(date))))
        else:
            result.insert(0, 'date', self.get_quote_date())

        # 获取证券名称
        sec_info = self.get_security_info()
        result['display_name'] = sec_info['display_name']
        return result


    @assert_quote_init
    def get_index_stocks(self, index_code, date=None) -> list:
        """获取指数成份股（支持历史查询）

        参数:
            index_code: 指数代码，字符串
            date: 查询日期；默认值 None（最新数据）

        说明：
            本方法等同 get_block_securities(<block>, types='index', date=date)

        """
        return self.get_block_securities(index_code, types='index', date=date)


    @assert_quote_init
    def get_industry_stocks(self, industry_code, date=None) -> list:
        """获取行业成份股（支持历史查询）

        参数:
            industry_code: 行业代码，字符串
            date: 查询日期；默认值 None（最新数据）

        说明：
            本方法等同 get_block_securities(<block>, types='industry', date=date)

        """
        return self.get_block_securities(industry_code, types='industry', date=date)


    @assert_quote_init
    def get_concept_stocks(self, concept_code, date=None) -> list:
        """获取概念成份股（支持历史查询）

        参数:
            concept_code: 概念代码，字符串
            date: 查询日期；默认值 None（最新数据）

        说明：
            本方法等同 get_block_securities(<block>, types='concept', date=date)

        """
        return self.get_block_securities(concept_code, types='concept', date=date)


    @assert_quote_init
    def get_security_info(self, security=None, fields=None, types=None) -> pd.DataFrame:
        """获取证券信息数据

        参数:
            security: 一支股票代码或者一个股票代码的 list
            fields: 获取的字段；类型 字符串 list；默认值 None 获取所有字段
            types: 获取证券类型；类型 字符串 list；默认值 stock；
                   可选值: 'stock', 'fund', 'index', 'futures', 'options', 'etf', 'lof' 等；

        返回值:
            DataFrame 对象，包含 fields 指定的字段：
                code（索引）：证券代码
                display_name：中文名称
                name：缩写简称
                start_date：上市日期；类型 datetime.date
                end_date: 退市日期；类型 datetime.date；如没有退市为 2200-01-01
                type：证券类型；stock（股票）, index（指数），etf（ETF基金），fja（分级A），fjb（分级B）

        """
        security = formatter_list(security)
        fields = formatter_list(fields)
        types = formatter_list(types, 'stock')

        result = pd.DataFrame()
        filename = 'quote-ctb.csv'
        df = self._fetch_data(filename, date_columns=('start_date', 'end_date'))
        df = df.copy()
        if df is None:
            raise Exception('fetch data from %s failed.' % filename)
        if types:
            df = df[df['type'].isin(types)]
        if security:
            df = df[df['code'].isin(security)]
        if fields:
            cols_retain = ['code'] + fields
            cols_all = list(df.columns)
            cols_drop = [x for x in cols_all if x not in cols_retain]
            df.drop(columns=cols_drop, inplace=True)
        result = pd.concat([result, df], sort=False, ignore_index=True)
        result.set_index('code', inplace=True)
        return result

    @assert_quote_init
    def get_security_xrxd(self, security, start_date=None, end_date=None, count=None) -> pd.DataFrame:
        """获取证券除权除息数据

        参数:
            security: 一支股票代码或者一个股票代码的 list
            start_date: 开始日期，与 count 二选一；类型 str/struct_time/datetime.date/datetime.datetime
            end_date: 结束日期；类型 str/struct_time/datetime.date/datetime.datetime；默认值 datetime.date.today()
            count: 结果集行数，与 start_date 二选一

        返回值:
            DataFrame 对象，包含字段：
                date: 实施日期
                code：证券代码
                dividend_ratio：送股比例，每 10 股送 X 股
                transfer_ratio：转赠比例，每 10 股转增 X 股
                bonus_ratio：派息比例，每 10 股派 X 元

        """
        security = formatter_list(security)
        if not security:
            raise ValueError('security need be provided.')

        filename = 'quote-xrxd.csv'
        df = self._fetch_data(filename, date_columns='date')
        if df is None:
            raise Exception('fetch data from %s failed.' % filename)
        df = df.copy()
        df = df[df['code'].isin(security)]
        tdays = self.get_trade_days(start_date, end_date, count)
        df = df[df['date'].dt.date.isin(tdays)]
        df.sort_values(['code', 'date'], axis=0, ascending=True, inplace=True)
        df.reset_index(drop=True, inplace=True)
        return df
