# -*- coding: utf-8 -*-
# sqldata_model.py - SQL 数据模型类
# author: JohnLui
# date: 2026-04-29

"""
SqlDataModel - SQL 数据模型类（单个数据源的 ORM 映射）

职责：
- ORM 类访问（automap 自动生成）
- run_query 查询接口
- 连接管理

语义：Model = 模型，数据如何表示
"""

import pandas as pd
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine


class SqlDataModel:
    """SQL 数据模型类
    
    单个数据源的 ORM 映射，提供表 ORM 类访问和 run_query 查询接口。
    
    Attributes:
        表名: ORM 类（automap 自动生成）
    
    Example:
        model = qf.get_sqldata('findata')
        model.stk_mt_total  # ORM 类
        df = model.run_query(query(model.stk_mt_total).filter(...))
    """
    
    def __init__(self, config_section, source_name):
        """初始化 SQL 数据模型
        
        Args:
            config_section: ConfigParser section 对象
            source_name: 数据源名（配置小节名）
        """
        self._source_name = source_name
        self._config = config_section
        self._engine = None
        self._base = None
        self._session = None
        self._classes = None
        self._prepared = False
        self._prefix = ''  # 表名前缀
    
    def _prepare(self):
        """准备 ORM 映射（懒加载）
        
        首次访问表名时才连接数据库、反射表结构。
        """
        if self._prepared:
            return
        
        # 获取配置
        dialect_raw = self._config.get('dialect')
        
        # dialect 自适应识别
        dialect_map = {
            'postgres': 'postgresql',
            'postgresql': 'postgresql',
            'pgsql': 'postgresql',
            'mysql': 'mysql',
            'sqlite': 'sqlite',
            'mssql': 'mssql',
        }
        dialect = dialect_map.get(dialect_raw.lower(), dialect_raw) if dialect_raw else None
        
        # 获取 schema（默认值）
        if dialect == 'postgresql':
            schema = self._config.get('schema', 'public')
        elif dialect == 'mssql':
            schema = self._config.get('schema', 'dbo')
        else:
            schema = self._config.get('schema', '')
        
        # 获取 prefix（默认空）
        self._prefix = self._config.get('prefix', '')
        
        # 构建 URI：优先使用 uri 配置
        uri = self._config.get('uri')
        if not uri:
            # 未配置 uri，从分散字段构建
            if not dialect:
                raise ValueError('Either "uri" or "dialect" must be configured')
            host = self._config.get('host')
            port = self._config.get('port')
            username = self._config.get('username')
            password = self._config.get('password')
            database = self._config.get('database')
            uri = f"{dialect}://{username}:{password}@{host}:{port}/{database}"
        
        # 创建 engine
        self._engine = create_engine(uri)
        
        # 创建 automap_base
        self._base = automap_base()
        self._base.prepare(autoload_with=self._engine)
        self._classes = self._base.classes
        
        # 创建 session
        self._session = Session(self._engine)
        self._prepared = True
    
    def __getattr__(self, name):
        """访问 ORM 类
        
        Args:
            name: 表名（用户侧名称）
        
        Returns:
            ORM 类
        
        Raises:
            AttributeError: 表不存在
        
        Example:
            model.stk_mt_total  # 返回 stk_mt_total 表的 ORM 类
            # 如果 prefix='jq_'，实际查找 jq_stk_mt_total 表
        """
        if name.startswith('_'):
            raise AttributeError(f'Private attribute {name} not accessible')
        
        # 懒加载
        self._prepare()
        
        # 处理 prefix
        actual_name = self._prefix + name if self._prefix else name
        
        if hasattr(self._classes, actual_name):
            return getattr(self._classes, actual_name)
        raise AttributeError(f'Table "{actual_name}" not found in data source "{self._source_name}"')
    
    def run_query(self, query_obj):
        """执行 SQLAlchemy Query，返回 DataFrame
        
        Args:
            query_obj: sqlalchemy.orm.Query 对象
        
        Returns:
            DataFrame
        
        Example:
            q = model._session.query(model.stk_mt_total).filter(model.stk_mt_total.date >= '2024-01-01')
            df = model.run_query(q)
        """
        # 懒加载
        self._prepare()
        
        # 执行查询
        result = query_obj.all()
        
        # 转换为 DataFrame
        if not result:
            return pd.DataFrame()
        
        # 如果返回的是 ORM 对象列表，转换为 DataFrame
        if hasattr(result[0], '__table__'):
            data = [{col: getattr(row, col) for col in row.__table__.columns.keys()}
                    for row in result]
            return pd.DataFrame(data)
        else:
            # 如果是 tuple（指定了 fields），直接转 DataFrame
            return pd.DataFrame(result)
    
    def list_tables(self):
        """列出所有表名
        
        Returns:
            list: 表名列表（去掉 prefix 后的用户侧名称）
        
        Note:
            如果设置了 prefix，只返回以 prefix 开头的表，
            其他表（不匹配 prefix）不返回。
        
        Example:
            model.list_tables()  # ['stk_mt_total', 'finance_income', ...]
        """
        self._prepare()
        tables = [name for name in dir(self._classes) if not name.startswith('_')]
        
        # 如果设置了 prefix，只返回匹配 prefix 的表
        if self._prefix:
            # 过滤：只保留以 prefix 开头的表
            tables = [name for name in tables if name.startswith(self._prefix)]
            # 去掉 prefix 返回用户侧名称
            tables = [name[len(self._prefix):] for name in tables]
        
        return tables
    
    def get_prefix(self):
        """获取当前配置的表名前缀
        
        Returns:
            str: 表名前缀
        """
        return self._prefix
    
    def close(self):
        """断开连接
        
        关闭 Session 并释放 Engine 连接池。
        """
        if self._session:
            self._session.close()
            self._session = None
        if self._engine:
            self._engine.dispose()
            self._engine = None
        self._prepared = False
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器退出（自动断连）"""
        self.close()
        return False
    
    def __del__(self):
        """析构时自动断连（兜底）"""
        try:
            self.close()
        except:
            pass
    
    def __repr__(self):
        return f"<SqlDataModel source='{self._source_name}' prefix='{self._prefix}' prepared={self._prepared}>"