"""
The magic about detecting what is going on
in a video. Analyzing the topic, the tone,
the subtitles...
"""