# Youtube Autonomous Editorial Decision Module

The module that is able to detect the topic, emotions and data from a video and make decisions about the changes to make on it to edit it professionally.