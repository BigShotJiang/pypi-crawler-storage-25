#!/usr/bin/env python3
"""
DEMO_SCRIPT_FINAL.py — TinyFish Accelerator x Google for Startups video demo.

This script demonstrates Lutflow's GPU Financial Firewall capabilities:
1. TinyFish GPU price lookup (works with cached fallback)
2. Budget enforcement with Google Gemini
3. Cost tracking across multiple API calls

REQUIREMENTS:
- pip install lutflow[gemini]
- GOOGLE_API_KEY environment variable (for Gemini API calls)
- TINYFISH_API_KEY environment variable (optional, for live prices)

CONTINGENCY PLAN (if something fails in live demo):
- If TinyFish fails: cached prices will be shown (still looks good)
- If Gemini fails: the budget enforcement still works with simulation
- If budget doesn't trigger: lower the budget_usd

Run: python DEMO_SCRIPT_FINAL.py
"""

import os
import sys

# ==============================================================================
# CONFIGURATION — Adjust these for the demo
# ==============================================================================
DEMO_BUDGET_USD = 0.05  # $0.05 budget to trigger enforcement
DEMO_MODEL = "gemini-2.5-flash"  # Latest fast model for demo
DEMO_MAX_CALLS = 20  # Safety limit

# ==============================================================================
# PART 1: TinyFish GPU Price Lookup
# ==============================================================================
def demo_tinyfish_lookup():
    """Demonstrate TinyFish GPU price discovery."""
    print()
    print("=" * 55)
    print("  Step 1/3: GPU Price Lookup (powered by TinyFish)")
    print("=" * 55)
    print()
    
    from lutflow.tinyfish import TinyFishClient
    
    tf = TinyFishClient()
    
    # Use quick=True for instant results (cached prices)
    # Set quick=False and increase timeout for live prices (takes 1-3 min/provider)
    result = tf.fetch_all_prices(gpu_type="nvidia-l4", quick=True)
    
    mode = "LIVE" if result.is_live else "CACHED"
    print(f"  Source: {mode} prices")
    print()
    
    for p in result.prices:
        marker = " <- CHEAPEST" if p == result.cheapest else ""
        print(f"  {p.provider:<12} ${p.spot_usd_per_hour:.2f}/hr{marker}")
    
    print()
    if result.cheapest:
        runtime = result.budget_runtime_minutes(0.05)
        print(f"  $0.05 budget = ~{runtime:.0f} min on {result.cheapest.provider}")
    print()
    
    return result


# ==============================================================================
# PART 2: Budget Enforcement with Gemini
# ==============================================================================
def demo_budget_enforcement():
    """Demonstrate budget enforcement with Google Gemini."""
    print("=" * 55)
    print("  Step 2/3: Budget Enforcement with Google Gemini")
    print("=" * 55)
    print()
    
    if not os.environ.get("GOOGLE_API_KEY"):
        print("  GOOGLE_API_KEY not set - running in simulation mode")
        print()
        return demo_budget_enforcement_simulated()
    
    try:
        import google.generativeai as genai
    except ImportError:
        print("  google-generativeai not installed")
        print("  Run: pip install lutflow[gemini]")
        print()
        return demo_budget_enforcement_simulated()
    
    from lutflow import Client, BudgetStrategy, BudgetExceededError
    
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
    model = genai.GenerativeModel(DEMO_MODEL)
    
    print(f"  Budget: ${DEMO_BUDGET_USD:.2f}")
    print(f"  Model: {DEMO_MODEL}")
    print(f"  Strategy: RAISE_ERROR")
    print()
    
    client = Client(
        tenant_id="tinyfish-demo",
        budget_usd=DEMO_BUDGET_USD,
        on_budget_exceeded=BudgetStrategy.RAISE_ERROR,
    )
    
    wrapped = client.wrap(model)
    
    print(f"  {'Call':<6} {'Spent':<12} {'Remaining':<12} Response")
    print("  " + "-" * 50)
    
    try:
        for i in range(1, DEMO_MAX_CALLS + 1):
            response = wrapped.generate_content(
                f"In one sentence, what is the number {i}?"
            )
            
            text = response.text[:40].replace("\n", " ") if response.text else ""
            print(
                f"  {i:<6} "
                f"${client.accumulated_cost_usd:<11.6f} "
                f"${client.remaining_budget_usd:<11.6f} "
                f"{text}..."
            )
            
    except BudgetExceededError as e:
        print()
        print("  " + "=" * 50)
        print("  BUDGET ENFORCED")
        print(f"  Spent:  ${e.spent_usd:.6f}")
        print(f"  Budget: ${e.budget_usd:.2f}")
        print("  " + "=" * 50)
        print()
        return True
        
    except Exception as e:
        print(f"\n  Error: {type(e).__name__}: {e}")
        return False
    
    print("\n  Budget was not exceeded within the call limit.")
    return False


def demo_budget_enforcement_simulated():
    """Simulated budget enforcement without real API calls."""
    from lutflow import Client, BudgetStrategy, BudgetExceededError
    
    print(f"  Budget: ${DEMO_BUDGET_USD:.2f}")
    print(f"  Strategy: RAISE_ERROR")
    print()
    
    client = Client(
        tenant_id="tinyfish-demo",
        budget_usd=DEMO_BUDGET_USD,
        on_budget_exceeded=BudgetStrategy.RAISE_ERROR,
    )
    
    print("  Simulating Gemini API calls...")
    print()
    print(f"  {'Call':<6} {'Spent':<12} {'Remaining':<12} Status")
    print("  " + "-" * 40)
    
    # Simulate costs similar to gemini-2.0-flash
    simulated_cost_per_call = 0.003  # ~$0.003 per call
    
    try:
        for i in range(1, DEMO_MAX_CALLS + 1):
            client.add_cost(simulated_cost_per_call)
            
            status = "OK" if client.budget_utilization_percent < 80 else "WARNING"
            
            print(
                f"  {i:<6} "
                f"${client.accumulated_cost_usd:<11.6f} "
                f"${client.remaining_budget_usd:<11.6f} "
                f"{status}"
            )
            
    except BudgetExceededError as e:
        print()
        print("  " + "=" * 40)
        print("  BUDGET ENFORCED (simulated)")
        print(f"  Spent:  ${e.spent_usd:.6f}")
        print(f"  Budget: ${e.budget_usd:.2f}")
        print("  " + "=" * 40)
        print()
        return True
    
    return False


# ==============================================================================
# PART 3: Summary
# ==============================================================================
def demo_summary():
    """Print demo summary."""
    print("=" * 55)
    print("  Step 3/3: Summary")
    print("=" * 55)
    print()
    print("  What you just saw:")
    print("    - TinyFish found cheapest GPU provider")
    print("    - Gemini tracked every token automatically")
    print("    - Budget enforced before damage occurred")
    print()
    print("  Lookup -> Flow -> Value")
    print()
    print("  pip install lutflow[gemini]")
    print("  pypi.org/project/lutflow")
    print()


# ==============================================================================
# MAIN
# ==============================================================================
def main():
    print()
    print("=" * 55)
    print("  LUTFLOW — GPU Financial Firewall")
    print("  TinyFish Accelerator x Google for Startups")
    print("=" * 55)
    
    # Part 1: TinyFish lookup
    demo_tinyfish_lookup()
    
    # Part 2: Budget enforcement
    success = demo_budget_enforcement()
    
    # Part 3: Summary
    demo_summary()
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
