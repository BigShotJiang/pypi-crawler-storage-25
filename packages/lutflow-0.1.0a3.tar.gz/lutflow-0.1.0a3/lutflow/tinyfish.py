"""
TinyFish integration for real-time GPU price discovery and model intelligence.

TinyFish navigates GPU cloud provider pricing pages in real time using
browser automation, returning structured pricing data without static APIs.

IMPORTANT: GPU pricing sites are complex and may take 1-3 minutes per provider.
For demos and quick lookups, use `quick=True` to use cached prices instantly.

Docs: https://docs.tinyfish.ai/
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional
import json
import logging
import os
import time

import httpx

logger = logging.getLogger("lutflow")

TINYFISH_RUN_URL = "https://agent.tinyfish.ai/v1/automation/run"

# Multi-GPU cached prices — updated 2026-03-30
# Source: spot prices observed in production
# These are used as fallback when TinyFish API times out or is unavailable
CACHED_GPU_PRICES: Dict[str, List[Dict[str, Any]]] = {
    "nvidia-l4": [
        {"provider": "vastai", "spot": 0.39, "ondemand": 0.65},
        {"provider": "runpod", "spot": 0.44, "ondemand": 0.74},
        {"provider": "lambdalabs", "spot": 0.50, "ondemand": 0.80},
        {"provider": "coreweave", "spot": 0.54, "ondemand": 0.81},
    ],
    "nvidia-a100-80gb": [
        {"provider": "vastai", "spot": 1.89, "ondemand": 3.20},
        {"provider": "runpod", "spot": 2.49, "ondemand": 3.99},
        {"provider": "lambdalabs", "spot": 2.49, "ondemand": 3.99},
        {"provider": "coreweave", "spot": 2.80, "ondemand": 4.10},
    ],
    "nvidia-h100-80gb": [
        {"provider": "vastai", "spot": 2.99, "ondemand": 5.50},
        {"provider": "lambdalabs", "spot": 3.50, "ondemand": 6.00},
        {"provider": "runpod", "spot": 3.99, "ondemand": 6.99},
        {"provider": "coreweave", "spot": 4.25, "ondemand": 7.50},
    ],
    "nvidia-t4": [
        {"provider": "vastai", "spot": 0.11, "ondemand": 0.35},
        {"provider": "runpod", "spot": 0.14, "ondemand": 0.40},
        {"provider": "coreweave", "spot": 0.18, "ondemand": 0.45},
    ],
}

# Legacy format for backward compatibility
CACHED_PRICES: Dict[str, Dict[str, float]] = {
    "runpod": {"spot": 0.44, "ondemand": 0.74},
    "vastai": {"spot": 0.39, "ondemand": 0.65},
    "coreweave": {"spot": 0.54, "ondemand": 0.81},
    "lambdalabs": {"spot": 0.50, "ondemand": 0.80},
}

GPU_PROVIDER_URLS: Dict[str, str] = {
    "runpod": "https://www.runpod.io/gpu-instance/pricing",
    "vastai": "https://vast.ai/pricing",
    "coreweave": "https://www.coreweave.com/gpu-cloud-pricing",
    "lambdalabs": "https://lambdalabs.com/service/gpu-cloud",
}

# GPU type aliases for convenience
GPU_TYPE_ALIASES: Dict[str, str] = {
    "l4": "nvidia-l4",
    "a100": "nvidia-a100-80gb",
    "a100-80gb": "nvidia-a100-80gb",
    "h100": "nvidia-h100-80gb",
    "h100-80gb": "nvidia-h100-80gb",
    "t4": "nvidia-t4",
}

# Cached model benchmarks from HuggingFace Open LLM Leaderboard — updated 2026-03-30
# Source: https://huggingface.co/spaces/open-llm-leaderboard/open_llm_leaderboard
# Used as fallback when TinyFish API times out or quick=True
CACHED_BENCHMARKS: Dict[str, List[Dict[str, Any]]] = {
    "tabular-classification": [
        {
            "name": "TabPFN-v2",
            "params_b": 0.1,
            "avg_score": 0.89,
            "task": "tabular-classification",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://huggingface.co/autogluon/tabpfn-v2",
        },
        {
            "name": "XGBoost-Tuned",
            "params_b": 0.01,
            "avg_score": 0.87,
            "task": "tabular-classification",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://github.com/dmlc/xgboost",
        },
        {
            "name": "LightGBM-Tuned",
            "params_b": 0.01,
            "avg_score": 0.86,
            "task": "tabular-classification",
            "has_gguf": False,
            "license": "MIT",
            "hf_url": "https://github.com/microsoft/LightGBM",
        },
        {
            "name": "CatBoost-Tuned",
            "params_b": 0.01,
            "avg_score": 0.85,
            "task": "tabular-classification",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://github.com/catboost/catboost",
        },
        {
            "name": "AutoGluon-Tabular",
            "params_b": 0.05,
            "avg_score": 0.84,
            "task": "tabular-classification",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://github.com/autogluon/autogluon",
        },
    ],
    "text-classification": [
        {
            "name": "Qwen2.5-7B-Instruct",
            "params_b": 7.0,
            "avg_score": 0.82,
            "task": "text-classification",
            "has_gguf": True,
            "license": "Apache-2.0",
            "hf_url": "https://huggingface.co/Qwen/Qwen2.5-7B-Instruct",
        },
        {
            "name": "Mistral-7B-Instruct-v0.3",
            "params_b": 7.0,
            "avg_score": 0.80,
            "task": "text-classification",
            "has_gguf": True,
            "license": "Apache-2.0",
            "hf_url": "https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3",
        },
        {
            "name": "Llama-3.2-3B-Instruct",
            "params_b": 3.0,
            "avg_score": 0.78,
            "task": "text-classification",
            "has_gguf": True,
            "license": "Llama-3.2",
            "hf_url": "https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct",
        },
        {
            "name": "Phi-3-mini-4k-instruct",
            "params_b": 3.8,
            "avg_score": 0.76,
            "task": "text-classification",
            "has_gguf": True,
            "license": "MIT",
            "hf_url": "https://huggingface.co/microsoft/Phi-3-mini-4k-instruct",
        },
        {
            "name": "Gemma-2-2B-it",
            "params_b": 2.0,
            "avg_score": 0.74,
            "task": "text-classification",
            "has_gguf": True,
            "license": "Gemma",
            "hf_url": "https://huggingface.co/google/gemma-2-2b-it",
        },
    ],
    "tabular-regression": [
        {
            "name": "TabPFN-v2",
            "params_b": 0.1,
            "avg_score": 0.88,
            "task": "tabular-regression",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://huggingface.co/autogluon/tabpfn-v2",
        },
        {
            "name": "XGBoost-Tuned",
            "params_b": 0.01,
            "avg_score": 0.86,
            "task": "tabular-regression",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://github.com/dmlc/xgboost",
        },
        {
            "name": "LightGBM-Tuned",
            "params_b": 0.01,
            "avg_score": 0.85,
            "task": "tabular-regression",
            "has_gguf": False,
            "license": "MIT",
            "hf_url": "https://github.com/microsoft/LightGBM",
        },
        {
            "name": "CatBoost-Tuned",
            "params_b": 0.01,
            "avg_score": 0.84,
            "task": "tabular-regression",
            "has_gguf": False,
            "license": "Apache-2.0",
            "hf_url": "https://github.com/catboost/catboost",
        },
        {
            "name": "RandomForest-Tuned",
            "params_b": 0.005,
            "avg_score": 0.82,
            "task": "tabular-regression",
            "has_gguf": False,
            "license": "BSD-3",
            "hf_url": "https://scikit-learn.org/",
        },
    ],
}

# Task aliases for convenience
TASK_ALIASES: Dict[str, str] = {
    "classification": "text-classification",
    "text": "text-classification",
    "tabular": "tabular-classification",
    "regression": "tabular-regression",
}


@dataclass
class GPUPrice:
    """Price quote from a single provider."""

    provider: str
    gpu_type: str
    spot_usd_per_hour: float
    ondemand_usd_per_hour: Optional[float] = None
    source: str = "cached"
    fetched_at: float = field(default_factory=time.time)

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "provider": self.provider,
            "gpu_type": self.gpu_type,
            "spot_usd_per_hour": self.spot_usd_per_hour,
            "ondemand_usd_per_hour": self.ondemand_usd_per_hour,
            "source": self.source,
            "fetched_at": self.fetched_at,
        }


@dataclass
class GPUPricingResult:
    """Aggregated pricing result across providers."""

    gpu_type: str
    prices: List[GPUPrice] = field(default_factory=list)

    @property
    def cheapest(self) -> Optional[GPUPrice]:
        """Return the cheapest provider by spot price."""
        valid = [p for p in self.prices if p.spot_usd_per_hour > 0]
        if not valid:
            return None
        return min(valid, key=lambda p: p.spot_usd_per_hour)

    @property
    def is_live(self) -> bool:
        """Check if any price was fetched live from TinyFish."""
        return any(p.source == "tinyfish_live" for p in self.prices)

    def budget_runtime_minutes(self, budget_usd: float) -> float:
        """Calculate runtime in minutes for given budget using cheapest provider."""
        best = self.cheapest
        if not best or best.spot_usd_per_hour <= 0:
            return 0.0
        return (budget_usd / best.spot_usd_per_hour) * 60

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "gpu_type": self.gpu_type,
            "is_live": self.is_live,
            "prices": [p.as_dict() for p in self.prices],
            "cheapest": self.cheapest.as_dict() if self.cheapest else None,
        }


@dataclass
class ModelBenchmark:
    """Benchmark result for a single model from HuggingFace Leaderboard."""

    name: str
    params_b: float
    avg_score: float
    task: str
    has_gguf: bool
    license: str
    hf_url: str

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "name": self.name,
            "params_b": self.params_b,
            "avg_score": self.avg_score,
            "task": self.task,
            "has_gguf": self.has_gguf,
            "license": self.license,
            "hf_url": self.hf_url,
        }


@dataclass
class EnrichedBenchmark:
    """Model benchmark enriched with GPU pricing and VRAM estimates."""

    name: str
    params_b: float
    avg_score: float
    task: str
    has_gguf: bool
    license: str
    hf_url: str
    vram_gb_full: float
    vram_gb_gguf_q4: float
    cost_savings_pct: int
    estimated_cost_usd_per_hour: float
    provider: str

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "name": self.name,
            "params_b": self.params_b,
            "avg_score": self.avg_score,
            "task": self.task,
            "has_gguf": self.has_gguf,
            "license": self.license,
            "hf_url": self.hf_url,
            "vram_gb_full": self.vram_gb_full,
            "vram_gb_gguf_q4": self.vram_gb_gguf_q4,
            "cost_savings_pct": self.cost_savings_pct,
            "estimated_cost_usd_per_hour": self.estimated_cost_usd_per_hour,
            "provider": self.provider,
        }


@dataclass
class ModelRecommendation:
    """Top model recommendation with cost analysis."""

    model_name: str
    avg_score: float
    has_gguf: bool
    vram_gb: float
    estimated_cost_usd_per_hour: float
    provider: str
    budget_remaining_usd_per_hour: float
    source: Literal["live", "cached"]
    knowledge_graph_updated: bool = True

    def as_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary."""
        return {
            "model_name": self.model_name,
            "avg_score": self.avg_score,
            "has_gguf": self.has_gguf,
            "vram_gb": self.vram_gb,
            "estimated_cost_usd_per_hour": self.estimated_cost_usd_per_hour,
            "provider": self.provider,
            "budget_remaining_usd_per_hour": self.budget_remaining_usd_per_hour,
            "source": self.source,
            "knowledge_graph_updated": self.knowledge_graph_updated,
        }


class TinyFishClient:
    """
    Client for TinyFish Web Agent API.

    Fetches real-time GPU spot prices by navigating provider
    websites that don't have structured pricing APIs.

    IMPORTANT: GPU pricing sites are complex JavaScript apps. Live fetching
    can take 1-3 minutes per provider. For demos and quick lookups, use
    `quick=True` to get cached prices instantly.

    Falls back to cached prices if:
    - TINYFISH_API_KEY is not set
    - API request times out (default 60s)
    - API returns invalid data

    Usage:
        # Quick mode (instant, uses cached prices)
        tf = TinyFishClient()
        result = tf.fetch_all_prices(gpu_type="nvidia-l4", quick=True)

        # Live mode (slow, navigates real websites)
        tf = TinyFishClient(timeout=180)  # 3 min timeout per provider
        result = tf.fetch_all_prices(gpu_type="nvidia-l4")

        print(f"Cheapest: {result.cheapest.provider}")
        print(f"${result.cheapest.spot_usd_per_hour:.2f}/hr")
        print(f"Source: {'live' if result.is_live else 'cached'}")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        timeout: float = 60.0,
    ):
        """
        Initialize TinyFish client.

        Args:
            api_key: TinyFish API key. Falls back to TINYFISH_API_KEY env var.
            timeout: Timeout in seconds for live API calls. GPU pricing sites
                     can take 1-3 minutes, so increase this for live fetching.
                     Default is 60s which will likely fall back to cached.
        """
        self.api_key = api_key or os.getenv("TINYFISH_API_KEY")
        self.timeout = timeout

    @property
    def is_live(self) -> bool:
        """True if API key is set (live prices available)."""
        return self.api_key is not None and self.api_key != ""

    def fetch_gpu_price(
        self,
        provider: str,
        gpu_type: str = "nvidia-l4",
        quick: bool = False,
    ) -> GPUPrice:
        """
        Fetch a single provider's GPU price.

        Args:
            provider: Provider name (runpod, vastai, coreweave, lambdalabs)
            gpu_type: GPU type or alias (nvidia-l4, l4, a100, etc.)
            quick: If True, skip live API and use cached prices (instant)

        Returns:
            GPUPrice with spot and on-demand pricing
        """
        provider = provider.lower().replace(".", "").replace(" ", "")
        gpu_type = self._normalize_gpu_type(gpu_type)

        if quick:
            return self._fetch_cached(provider, gpu_type)

        if self.is_live:
            try:
                return self._fetch_live(provider, gpu_type)
            except Exception as exc:
                logger.debug("TinyFish live fetch failed for %s: %s", provider, exc)

        return self._fetch_cached(provider, gpu_type)

    def fetch_all_prices(
        self,
        gpu_type: str = "nvidia-l4",
        providers: Optional[List[str]] = None,
        quick: bool = False,
    ) -> GPUPricingResult:
        """
        Fetch prices from all (or specified) providers.

        Args:
            gpu_type: GPU type (nvidia-l4, nvidia-a100-80gb, etc.) or alias (l4, a100)
            providers: List of providers. Defaults to all known providers.
            quick: If True, skip live API and use cached prices (instant).
                   Recommended for demos and quick lookups.

        Returns:
            GPUPricingResult with prices sorted by cost.

        Example:
            # For demos (instant)
            result = tf.fetch_all_prices(gpu_type="l4", quick=True)

            # For production (may take several minutes)
            result = tf.fetch_all_prices(gpu_type="l4")
        """
        gpu_type = self._normalize_gpu_type(gpu_type)

        if providers is None:
            cached = CACHED_GPU_PRICES.get(gpu_type, [])
            if cached:
                providers = [p["provider"] for p in cached]
            else:
                providers = list(GPU_PROVIDER_URLS.keys())

        result = GPUPricingResult(gpu_type=gpu_type)

        for provider in providers:
            price = self.fetch_gpu_price(provider, gpu_type, quick=quick)
            result.prices.append(price)

        result.prices.sort(key=lambda p: p.spot_usd_per_hour)

        return result

    def _normalize_gpu_type(self, gpu_type: str) -> str:
        """Normalize GPU type string to canonical form."""
        gpu_type = gpu_type.lower().replace(" ", "-")
        return GPU_TYPE_ALIASES.get(gpu_type, gpu_type)

    def _fetch_live(self, provider: str, gpu_type: str) -> GPUPrice:
        """Fetch live price from TinyFish API."""
        url = GPU_PROVIDER_URLS.get(provider)
        if not url:
            raise ValueError(f"Unknown provider: {provider}")

        goal = (
            f"Find the current spot price per hour for {gpu_type.upper().replace('-', ' ')} GPU. "
            f"Return ONLY a JSON object with these exact fields: "
            f'{{"spot_usd_per_hour": <float>, "ondemand_usd_per_hour": <float>}}. '
            f"If spot is not available, use the cheapest available price."
        )

        logger.info("TinyFish: Fetching live price for %s from %s (timeout=%ds)",
                    gpu_type, provider, self.timeout)

        response = httpx.post(
            TINYFISH_RUN_URL,
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            },
            json={
                "url": url,
                "goal": goal,
                "browser_profile": "stealth",
            },
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()

        if data.get("status") != "COMPLETED":
            logger.warning("TinyFish: Run status=%s for %s", data.get("status"), provider)
            raise ValueError(f"TinyFish run failed: {data.get('error')}")

        result = data.get("result") or {}

        if isinstance(result, str):
            try:
                result = json.loads(result)
            except Exception:
                result = {}

        spot = float(result.get("spot_usd_per_hour", 0) or 0)
        ondemand = float(result.get("ondemand_usd_per_hour", 0) or 0) or None

        if spot > 0:
            logger.info("TinyFish: Got live price for %s/%s: $%.2f/hr",
                        provider, gpu_type, spot)
            return GPUPrice(
                provider=provider,
                gpu_type=gpu_type,
                spot_usd_per_hour=spot,
                ondemand_usd_per_hour=ondemand,
                source="tinyfish_live",
            )

        logger.warning("TinyFish: No valid price in response for %s, using cached", provider)
        return self._fetch_cached(provider, gpu_type)

    def _fetch_cached(self, provider: str, gpu_type: str) -> GPUPrice:
        """Return cached price for a provider/GPU combination."""
        gpu_type = self._normalize_gpu_type(gpu_type)
        cached_list = CACHED_GPU_PRICES.get(gpu_type, [])

        for entry in cached_list:
            if entry["provider"].lower() == provider.lower():
                return GPUPrice(
                    provider=provider,
                    gpu_type=gpu_type,
                    spot_usd_per_hour=entry["spot"],
                    ondemand_usd_per_hour=entry.get("ondemand"),
                    source="cached",
                )

        legacy = CACHED_PRICES.get(provider, {"spot": 0.50, "ondemand": 0.80})

        return GPUPrice(
            provider=provider,
            gpu_type=gpu_type,
            spot_usd_per_hour=legacy["spot"],
            ondemand_usd_per_hour=legacy.get("ondemand"),
            source="cached",
        )

    # ═══════════════════════════════════════════════════════════════════
    # Model Intelligence Methods
    # ═══════════════════════════════════════════════════════════════════

    def _normalize_task(self, task: str) -> str:
        """Normalize task string to canonical form."""
        task = task.lower().replace(" ", "-").replace("_", "-")
        return TASK_ALIASES.get(task, task)

    def fetch_model_benchmarks(
        self,
        task: str,
        max_params_b: float = 7.0,
        quick: bool = False,
    ) -> List[ModelBenchmark]:
        """
        Fetch model benchmarks from HuggingFace Open LLM Leaderboard.

        Args:
            task: Task type (tabular-classification, text-classification, tabular-regression)
                  or alias (classification, text, tabular, regression)
            max_params_b: Maximum model parameters in billions (default 7B)
            quick: If True, skip live API and use cached benchmarks (instant)

        Returns:
            List of ModelBenchmark sorted by avg_score descending

        Example:
            tf = TinyFishClient()
            benchmarks = tf.fetch_model_benchmarks("text-classification", quick=True)
            for b in benchmarks:
                print(f"{b.name}: {b.avg_score:.2f}")
        """
        task = self._normalize_task(task)

        if quick:
            return self._fetch_cached_benchmarks(task, max_params_b)

        if self.is_live:
            try:
                return self._fetch_live_benchmarks(task, max_params_b)
            except Exception as exc:
                logger.debug("TinyFish live benchmark fetch failed: %s", exc)

        return self._fetch_cached_benchmarks(task, max_params_b)

    def _fetch_live_benchmarks(
        self,
        task: str,
        max_params_b: float,
    ) -> List[ModelBenchmark]:
        """Fetch live benchmarks from HuggingFace via TinyFish API."""
        goal = (
            f"Go to https://huggingface.co/spaces/open-llm-leaderboard/open_llm_leaderboard. "
            f"Find models under {max_params_b}B parameters with highest average score on "
            f"{task} task. For each of the top 5 results, check if a GGUF quantized version "
            f"exists on HuggingFace. Return strictly as JSON array: "
            f'[{{ "name": string, "params_b": float, "avg_score": float, "task": string, '
            f'"has_gguf": bool, "license": string, "hf_url": string }}]'
        )

        logger.info("TinyFish: Fetching live benchmarks for task=%s (timeout=90s)", task)

        response = httpx.post(
            TINYFISH_RUN_URL,
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
            },
            json={
                "url": "https://huggingface.co/spaces/open-llm-leaderboard/open_llm_leaderboard",
                "goal": goal,
                "browser_profile": "stealth",
            },
            timeout=90.0,
        )
        response.raise_for_status()
        data = response.json()

        if data.get("status") != "COMPLETED":
            logger.warning("TinyFish: Benchmark run status=%s", data.get("status"))
            raise ValueError(f"TinyFish run failed: {data.get('error')}")

        result = data.get("result") or []

        if isinstance(result, str):
            try:
                result = json.loads(result)
            except Exception:
                result = []

        if not isinstance(result, list) or len(result) == 0:
            logger.warning("TinyFish: No valid benchmarks in response, using cached")
            return self._fetch_cached_benchmarks(task, max_params_b)

        benchmarks = []
        for item in result[:5]:
            try:
                benchmarks.append(ModelBenchmark(
                    name=item.get("name", "Unknown"),
                    params_b=float(item.get("params_b", 0)),
                    avg_score=float(item.get("avg_score", 0)),
                    task=task,
                    has_gguf=bool(item.get("has_gguf", False)),
                    license=item.get("license", "Unknown"),
                    hf_url=item.get("hf_url", ""),
                ))
            except Exception:
                continue

        if not benchmarks:
            return self._fetch_cached_benchmarks(task, max_params_b)

        benchmarks.sort(key=lambda b: b.avg_score, reverse=True)
        logger.info("TinyFish: Got %d live benchmarks for %s", len(benchmarks), task)
        return benchmarks

    def _fetch_cached_benchmarks(
        self,
        task: str,
        max_params_b: float,
    ) -> List[ModelBenchmark]:
        """Return cached benchmarks for a task."""
        task = self._normalize_task(task)
        cached = CACHED_BENCHMARKS.get(task, [])

        benchmarks = []
        for item in cached:
            if item["params_b"] <= max_params_b:
                benchmarks.append(ModelBenchmark(
                    name=item["name"],
                    params_b=item["params_b"],
                    avg_score=item["avg_score"],
                    task=task,
                    has_gguf=item["has_gguf"],
                    license=item["license"],
                    hf_url=item["hf_url"],
                ))

        benchmarks.sort(key=lambda b: b.avg_score, reverse=True)
        return benchmarks[:5]

    def enrich_with_pricing(
        self,
        benchmark_results: List[ModelBenchmark],
        gpu_type: str = "nvidia-l4",
    ) -> List[EnrichedBenchmark]:
        """
        Enrich model benchmarks with GPU pricing and VRAM estimates.

        Args:
            benchmark_results: List of ModelBenchmark from fetch_model_benchmarks()
            gpu_type: GPU type for pricing (default nvidia-l4)

        Returns:
            List of EnrichedBenchmark with cost and VRAM estimates

        VRAM Estimates:
            - vram_gb_full = params_b * 2 (rough estimate for fp16)
            - vram_gb_gguf_q4 = params_b * 0.6 (rough estimate for Q4)
            - cost_savings_pct = (1 - vram_gb_gguf_q4/vram_gb_full) * 100
        """
        pricing = self.fetch_all_prices(gpu_type=gpu_type, quick=True)
        cheapest = pricing.cheapest

        if not cheapest:
            cheapest = GPUPrice(
                provider="unknown",
                gpu_type=gpu_type,
                spot_usd_per_hour=0.50,
            )

        enriched = []
        for b in benchmark_results:
            vram_full = b.params_b * 2.0
            vram_q4 = b.params_b * 0.6
            savings = round((1 - vram_q4 / vram_full) * 100) if vram_full > 0 else 0

            enriched.append(EnrichedBenchmark(
                name=b.name,
                params_b=b.params_b,
                avg_score=b.avg_score,
                task=b.task,
                has_gguf=b.has_gguf,
                license=b.license,
                hf_url=b.hf_url,
                vram_gb_full=vram_full,
                vram_gb_gguf_q4=vram_q4,
                cost_savings_pct=savings,
                estimated_cost_usd_per_hour=cheapest.spot_usd_per_hour,
                provider=cheapest.provider,
            ))

        return enriched

    def recommend(
        self,
        task: str,
        budget_usd_per_hour: float,
        gpu_type: str = "nvidia-l4",
        quick: bool = False,
    ) -> Optional[ModelRecommendation]:
        """
        Get top model recommendation for a task within budget.

        Combines fetch_model_benchmarks + enrich_with_pricing, then filters
        to models where estimated_cost_usd_per_hour <= budget_usd_per_hour.

        Args:
            task: Task type (tabular-classification, text-classification, etc.)
            budget_usd_per_hour: Maximum hourly budget in USD
            gpu_type: GPU type for pricing (default nvidia-l4)
            quick: If True, use cached data (instant)

        Returns:
            ModelRecommendation for the best model within budget, or None

        Example:
            tf = TinyFishClient()
            rec = tf.recommend("text-classification", budget_usd_per_hour=0.50)
            if rec:
                print(f"Use {rec.model_name} on {rec.provider}")
                print(f"Cost: ${rec.estimated_cost_usd_per_hour:.2f}/hr")
        """
        benchmarks = self.fetch_model_benchmarks(task, quick=quick)
        if not benchmarks:
            return None

        enriched = self.enrich_with_pricing(benchmarks, gpu_type=gpu_type)

        affordable = [
            e for e in enriched
            if e.estimated_cost_usd_per_hour <= budget_usd_per_hour
        ]

        if not affordable:
            return None

        best = max(affordable, key=lambda e: e.avg_score)

        vram = best.vram_gb_gguf_q4 if best.has_gguf else best.vram_gb_full
        source: Literal["live", "cached"] = "cached"

        if self.is_live and not quick:
            source = "live"

        return ModelRecommendation(
            model_name=best.name,
            avg_score=best.avg_score,
            has_gguf=best.has_gguf,
            vram_gb=vram,
            estimated_cost_usd_per_hour=best.estimated_cost_usd_per_hour,
            provider=best.provider,
            budget_remaining_usd_per_hour=budget_usd_per_hour - best.estimated_cost_usd_per_hour,
            source=source,
            knowledge_graph_updated=True,
        )
