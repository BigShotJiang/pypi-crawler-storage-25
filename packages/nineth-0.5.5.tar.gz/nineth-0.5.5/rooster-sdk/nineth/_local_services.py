"""Local service loading and execution helpers for SDK-managed callbacks."""

from __future__ import annotations

import ast
import asyncio
import hashlib
import importlib.util
import inspect
import os
import sys
from functools import lru_cache
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Tuple


Handler = Callable[..., Any]

_IGNORED_DISCOVERY_DIRS = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "site-packages",
    "target",
    "venv",
}


def _is_shorthand_reference(value: str) -> bool:
    return not any(sep in value for sep in (os.sep, "/", "\\")) and not value.endswith(".py")


def _resolve_schema_path(raw_path: str) -> Optional[Path]:
    raw_value = str(raw_path).strip()
    if not raw_value:
        return None
    path = Path(raw_value).expanduser()
    if not path.is_absolute():
        path = (Path.cwd() / path).resolve()
    if path.is_dir():
        path = path / "schema.py"
    if not path.exists():
        return None
    if path.name != "schema.py" or not path.is_file():
        raise ValueError(
            f"Local include_service path '{raw_path}' must point to a schema.py file or a directory containing schema.py."
        )
    return path.resolve()


def _resolve_schema_path_from_reference(reference: Any) -> Optional[Path]:
    module: Optional[ModuleType]
    if inspect.ismodule(reference):
        module = reference
    else:
        module = inspect.getmodule(reference)

    module_file = getattr(module, "__file__", None) if module is not None else None
    if not module_file:
        try:
            module_file = inspect.getsourcefile(reference) or inspect.getfile(reference)
        except (OSError, TypeError):
            module_file = None
    if not module_file:
        return None

    module_path = Path(module_file).resolve()
    if module_path.name == "schema.py" and module_path.is_file():
        return module_path

    sibling_schema = module_path.parent / "schema.py"
    if sibling_schema.is_file():
        return sibling_schema.resolve()
    return None


def _iter_candidate_schema_paths(root: Path) -> Iterable[Path]:
    if not root.exists() or not root.is_dir():
        return []

    candidates: List[Path] = []
    for current_root, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            name
            for name in dirnames
            if name not in _IGNORED_DISCOVERY_DIRS and not name.startswith(".")
        ]
        if "schema.py" not in filenames:
            continue
        candidates.append((Path(current_root) / "schema.py").resolve())

    candidates.sort(
        key=lambda path: (
            0 if "services" in path.parts else 1,
            len(path.parts),
            str(path),
        )
    )
    return candidates


def _extract_service_names(node: ast.AST) -> Set[str]:
    names: Set[str] = set()
    if not isinstance(node, ast.Dict):
        return names

    for key_node, value_node in zip(node.keys, node.values):
        if isinstance(key_node, ast.Constant) and isinstance(key_node.value, str):
            names.add(key_node.value)
        if not isinstance(value_node, ast.Dict):
            continue
        for nested_key, nested_value in zip(value_node.keys, value_node.values):
            if (
                isinstance(nested_key, ast.Constant)
                and nested_key.value == "name"
                and isinstance(nested_value, ast.Constant)
                and isinstance(nested_value.value, str)
            ):
                names.add(nested_value.value)
    return names


@lru_cache(maxsize=256)
def _inspect_schema_source(schema_path_str: str) -> Dict[str, Set[str]]:
    schema_path = Path(schema_path_str)
    try:
        source = schema_path.read_text(encoding="utf-8")
    except OSError:
        return {"class_names": set(), "manager_names": set(), "service_names": set(), "aliases": set()}

    try:
        tree = ast.parse(source, filename=str(schema_path))
    except SyntaxError:
        return {"class_names": set(), "manager_names": set(), "service_names": set(), "aliases": set()}

    class_names: Set[str] = set()
    manager_names: Set[str] = set()
    service_names: Set[str] = set()
    aliases: Set[str] = {schema_path.parent.name}

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            class_names.add(node.name)
            if node.name.endswith("ServiceManager"):
                manager_names.add(node.name)
            continue

        if not isinstance(node, ast.Assign):
            continue

        target_names = {
            target.id
            for target in node.targets
            if isinstance(target, ast.Name)
        }
        if any(name == "services" or name.endswith("_services") for name in target_names):
            service_names.update(_extract_service_names(node.value))

    return {
        "class_names": class_names,
        "manager_names": manager_names,
        "service_names": service_names,
        "aliases": aliases,
    }


def _schema_match_score(token: str, schema_path: Path) -> int:
    token_lower = token.lower()
    metadata = _inspect_schema_source(str(schema_path))

    manager_names = {name.lower() for name in metadata["manager_names"]}
    class_names = {name.lower() for name in metadata["class_names"]}
    service_names = {name.lower() for name in metadata["service_names"]}
    aliases = {name.lower() for name in metadata["aliases"]}

    if token_lower in manager_names:
        return 5
    if token_lower in class_names:
        return 4
    if token_lower in service_names:
        return 3
    if token_lower in aliases:
        return 2
    return 0


def _discover_schema_path(token: str) -> Optional[Path]:
    matches: List[Tuple[int, Path]] = []
    for schema_path in _iter_candidate_schema_paths(Path.cwd().resolve()):
        score = _schema_match_score(token, schema_path)
        if score > 0:
            matches.append((score, schema_path))

    if not matches:
        return None

    best_score = max(score for score, _ in matches)
    best_paths = sorted({path for score, path in matches if score == best_score}, key=str)
    if len(best_paths) > 1:
        rendered_paths = ", ".join(str(path) for path in best_paths)
        raise ValueError(
            f"Local include_service reference '{token}' matched multiple schema.py files: {rendered_paths}. "
            "Pass an explicit schema.py path or pass the manager class/object directly."
        )
    return best_paths[0]


def _resolve_local_schema_reference(raw_item: Any) -> Tuple[Optional[Path], Optional[str]]:
    if isinstance(raw_item, str):
        local_path = _resolve_schema_path(raw_item)
        if local_path is not None:
            return local_path, None

        token = str(raw_item).strip()
        if not token:
            return None, None
        if not _is_shorthand_reference(token):
            return None, None

        discovered_path = _discover_schema_path(token)
        if discovered_path is not None:
            return discovered_path, None
        return None, token

    local_path = _resolve_schema_path_from_reference(raw_item)
    if local_path is not None:
        return local_path, None

    raise ValueError(
        "Unsupported include_service reference. Pass a schema.py path, a directory containing schema.py, "
        "a service manager class/object defined from that schema module, or a shorthand name discoverable from a local schema.py file."
    )


class LocalServiceRegistry:
    def __init__(self, schemas: Dict[str, Dict[str, Any]], handlers: Dict[str, Handler]):
        self._schemas = schemas
        self._handlers = handlers
        self._context_id: Optional[str] = None

    @classmethod
    def from_paths(cls, include_service: Optional[List[Any]]) -> Tuple["LocalServiceRegistry", List[str]]:
        schemas: Dict[str, Dict[str, Any]] = {}
        handlers: Dict[str, Handler] = {}
        server_paths: List[str] = []
        schema_sources: Dict[str, Path] = {}
        seen_schema_paths: Set[Path] = set()

        for raw_item in include_service or []:
            local_path, unresolved_token = _resolve_local_schema_reference(raw_item)
            if local_path is None:
                if unresolved_token is not None:
                    raise ValueError(
                        f"Could not resolve local include_service reference '{unresolved_token}'. "
                        "Pass a schema.py path, a directory containing schema.py, a service manager class/object, "
                        "or place the schema under a local services/ directory. If you intended a server-hosted include, "
                        "pass the schema.py path explicitly."
                    )
                server_paths.append(str(raw_item).strip())
                continue

            if local_path in seen_schema_paths:
                continue
            seen_schema_paths.add(local_path)

            loaded_schemas, loaded_handlers = cls._load_schema_module(local_path)
            overlap = set(schemas).intersection(loaded_schemas)
            if overlap:
                collisions = ", ".join(
                    f"{name} ({schema_sources[name]} vs {local_path})"
                    for name in sorted(overlap)
                )
                raise ValueError(
                    f"Duplicate local service names are not allowed: {collisions}. "
                    "Rename one of the local services or pass only one schema source for that name."
                )
            schemas.update(loaded_schemas)
            handlers.update(loaded_handlers)
            for service_name in loaded_schemas:
                schema_sources[service_name] = local_path

        return cls(schemas, handlers), server_paths

    @staticmethod
    def _load_schema_module(schema_path: Path) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Handler]]:
        module_name = f"nineth_local_service_{hashlib.sha1(str(schema_path).encode('utf-8')).hexdigest()}"
        spec = importlib.util.spec_from_file_location(module_name, schema_path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Could not load local service schema from {schema_path}.")

        module = importlib.util.module_from_spec(spec)
        module_dir = str(schema_path.parent)
        project_dir = str(schema_path.parent.parent)
        added_paths: List[str] = []
        for candidate in (module_dir, project_dir):
            if candidate not in sys.path:
                sys.path.append(candidate)
                added_paths.append(candidate)
        try:
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
        finally:
            for candidate in added_paths:
                if candidate in sys.path:
                    sys.path.remove(candidate)

        service_dicts: List[Dict[str, Dict[str, Any]]] = []
        implementation_dicts: List[Dict[str, Any]] = []
        manager_candidates: List[type] = []

        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if (attr_name == "services" or attr_name.endswith("_services")) and isinstance(attr, dict):
                service_dicts.append(attr)
            if (attr_name == "implementations" or attr_name.endswith("_implementations")) and isinstance(attr, dict):
                implementation_dicts.append(attr)
            if attr_name.endswith("ServiceManager") and isinstance(attr, type):
                manager_candidates.append(attr)

        if not service_dicts:
            raise ValueError(f"Local service schema '{schema_path}' did not define any *_services dictionary.")

        manager = None
        if manager_candidates:
            manager = manager_candidates[0]()

        implementation_lookup: Dict[str, Any] = {}
        for mapping in implementation_dicts:
            implementation_lookup.update(mapping)

        schemas: Dict[str, Dict[str, Any]] = {}
        handlers: Dict[str, Handler] = {}
        for mapping in service_dicts:
            for service_name, schema in mapping.items():
                implementation = implementation_lookup.get(service_name)
                if implementation is None and manager is not None and hasattr(manager, service_name):
                    implementation = getattr(manager, service_name)
                if implementation is None and hasattr(module, service_name):
                    implementation = getattr(module, service_name)
                handler = LocalServiceRegistry._bind_handler(service_name, implementation, manager)
                schema_payload = dict(schema)
                schema_payload.setdefault("name", service_name)
                schemas[service_name] = schema_payload
                handlers[service_name] = handler

        return schemas, handlers

    @staticmethod
    def _bind_handler(service_name: str, implementation: Any, manager: Any) -> Handler:
        handler = implementation
        if manager is not None and callable(implementation):
            try:
                signature = inspect.signature(implementation)
            except (TypeError, ValueError):
                signature = None
            if signature and len(signature.parameters) == 1 and not inspect.iscoroutinefunction(implementation):
                try:
                    candidate = implementation(manager)
                    if callable(candidate):
                        handler = candidate
                except TypeError:
                    handler = implementation

        if callable(handler):
            return handler

        raise ValueError(f"Local service '{service_name}' does not have a callable implementation.")

    @property
    def schemas(self) -> List[Dict[str, Any]]:
        return [dict(schema) for schema in self._schemas.values()]

    @property
    def has_services(self) -> bool:
        return bool(self._schemas)

    def set_context_id(self, context_id: Optional[str]) -> None:
        self._context_id = context_id

    def _prepare_params(self, handler: Handler, params: Dict[str, Any]) -> Dict[str, Any]:
        prepared = dict(params)
        try:
            signature = inspect.signature(handler)
        except (TypeError, ValueError):
            return prepared
        if "context_id" in signature.parameters and "context_id" not in prepared:
            prepared["context_id"] = self._context_id or ""
        if "session_id" in signature.parameters and "session_id" not in prepared:
            prepared["session_id"] = self._context_id or ""
        return prepared

    def execute(self, service_name: str, params: Dict[str, Any]) -> Any:
        if service_name not in self._handlers:
            raise ValueError(f"Unknown local service: {service_name}")
        handler = self._handlers[service_name]
        prepared = self._prepare_params(handler, params)
        if inspect.iscoroutinefunction(handler):
            return asyncio.run(handler(**prepared))
        result = handler(**prepared)
        if inspect.isawaitable(result):
            return asyncio.run(result)
        return result

    async def aexecute(self, service_name: str, params: Dict[str, Any]) -> Any:
        if service_name not in self._handlers:
            raise ValueError(f"Unknown local service: {service_name}")
        handler = self._handlers[service_name]
        prepared = self._prepare_params(handler, params)
        if inspect.iscoroutinefunction(handler):
            return await handler(**prepared)
        result = handler(**prepared)
        if inspect.isawaitable(result):
            return await result
        return result