"""Internal streaming helpers — service labels and delta coalescing."""

from __future__ import annotations

from typing import Any, Dict, Iterator, Optional


_SERVICE_LABELS: Dict[str, str] = {
    "search_web":            "Browsing the web",
    "search_news":           "Checking the news",
    "search_discussions":    "Searching discussions",
    "search_unified":        "Searching",
    "search_knowledge":      "Searching knowledge base",
    "deepsearch":            "Deep searching",
    "read":                  "Reading page",
    "create_sandbox":        "Setting up sandbox",
    "run":                   "Running code",
    "destroy_sandbox":       "Cleaning up",
    "sandbox":               "In sandbox",
    "volume_write_file":     "Writing file",
    "volume_read_file":      "Reading file",
    "volume_search_replace": "Editing file",
    "volume_list":           "Listing files",
    "get_account_snapshot":  "Checking account",
    "get_open_positions":    "Checking positions",
    "get_current_price":     "Getting price",
    "trade_market_buy":      "Placing buy order",
    "trade_market_sell":     "Placing sell order",
    "recall_media":          "Loading image",
    "media_list":            "Listing media",
    "send_message":          "Sending message",
    "send_photo":            "Sending photo",
    "set_alarm":             "Setting alarm",
    "schedule_at":           "Scheduling task",
    "cancel_alarm":          "Cancelling alarm",
}


def _service_status_delta(service_name: str) -> Optional[Dict[str, Any]]:
    if service_name == "done":
        return None
    label = _SERVICE_LABELS.get(service_name, service_name.replace("_", " ").capitalize())
    return {"type": "model_delta", "data": {"text": f"\n  \u25b8 {label}\n"}}


def _coalesce_deltas(events: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
    """Merge consecutive model_delta events; batch repeated service status lines."""
    text_buf = ""
    svc_batch: list = []

    def _flush_svc() -> Iterator[Dict[str, Any]]:
        if not svc_batch:
            return
        groups: list = []
        for label, _ in svc_batch:
            if label is None:
                continue
            if groups and groups[-1][0] == label:
                groups[-1][1] += 1
            else:
                groups.append([label, 1])
        for label, count in groups:
            suffix = f" \u00d7{count}" if count > 1 else ""
            yield {"type": "model_delta", "data": {"text": f"\n  \u25b8 {label}{suffix}\n"}}
        for _, ev in svc_batch:
            yield ev
        svc_batch.clear()

    for event in events:
        etype = event.get("type")
        if etype == "model_delta":
            yield from _flush_svc()
            text_buf += event.get("data", {}).get("text", "")
            if text_buf and (text_buf[-1] in " \n\t" or len(text_buf) >= 80):
                yield {"type": "model_delta", "data": {"text": text_buf}}
                text_buf = ""
        elif etype == "service_call":
            if text_buf:
                yield {"type": "model_delta", "data": {"text": text_buf}}
                text_buf = ""
            svc = event.get("data", {}).get("service_name", "")
            label = None if svc == "done" else _SERVICE_LABELS.get(
                svc, svc.replace("_", " ").capitalize()
            )
            svc_batch.append([label, event])
        else:
            yield from _flush_svc()
            if text_buf:
                yield {"type": "model_delta", "data": {"text": text_buf}}
                text_buf = ""
            yield event

    yield from _flush_svc()
    if text_buf:
        yield {"type": "model_delta", "data": {"text": text_buf}}
