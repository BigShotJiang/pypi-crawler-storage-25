"""
RAMJET Ultralytics Integration

Automatically hooks into ultralytics YOLO training to report
progress (epoch, step, loss, samples/sec) to the RAMJET dashboard.

Usage (automatic via ramjetio.train()):
    import ramjetio
    from ultralytics import YOLO

    ramjetio.init()
    model = YOLO('yolov8n.pt')
    ramjetio.train(model, data='data.yaml', epochs=5)

Usage (manual):
    from ramjetio.integrations.ultralytics import attach
    attach(model)
    model.train(data='data.yaml', epochs=5)
"""

import time
import logging

logger = logging.getLogger(__name__)


def attach(model):
    """
    Attach RAMJET progress callbacks to an ultralytics YOLO model.

    Registers callbacks for:
    - on_train_start: marks training phase started
    - on_train_batch_end: reports step progress + loss
    - on_train_epoch_end: reports epoch completion
    - on_train_end: marks training completed

    Only rank 0 reports to the dashboard to avoid duplicate updates
    in DDP multi-GPU training.

    Args:
        model: ultralytics.YOLO instance
    """
    import os
    import ramjetio

    # Only rank 0 reports progress to dashboard
    rank = int(os.environ.get('RANK', 0))
    is_main = (rank == 0)

    _state = {
        'epoch_start_time': 0.0,
        'epoch_samples': 0,
    }

    def on_train_start(trainer):
        if not is_main:
            return
        try:
            ramjetio.start_training(
                task=f'YOLO {trainer.args.model or ""}',
                total_epochs=trainer.epochs,
            )
            logger.debug("RAMJET: training started callback fired")
        except Exception as e:
            logger.debug(f"RAMJET on_train_start error: {e}")

    def on_train_epoch_start(trainer):
        _state['epoch_start_time'] = time.time()
        _state['epoch_samples'] = 0

    def on_train_batch_end(trainer):
        if not is_main:
            return
        try:
            nb = len(trainer.train_loader) if hasattr(trainer, 'train_loader') else 0
            step = (trainer.batch_i + 1) if hasattr(trainer, 'batch_i') else 0
            loss_val = None
            if hasattr(trainer, 'tloss') and trainer.tloss is not None:
                loss_val = float(trainer.tloss)

            # Calculate samples/sec (multiply by world_size for total throughput)
            batch_size = trainer.batch_size if hasattr(trainer, 'batch_size') else 0
            world_size = int(os.environ.get('WORLD_SIZE', 1))
            _state['epoch_samples'] += batch_size * world_size
            elapsed = time.time() - _state['epoch_start_time']
            sps = _state['epoch_samples'] / elapsed if elapsed > 0 else 0.0

            ramjetio.update_step(
                epoch=trainer.epoch + 1,
                step=step,
                total_steps=nb,
                loss=loss_val,
                samples_per_second=sps,
            )
        except Exception as e:
            logger.debug(f"RAMJET on_train_batch_end error: {e}")

    def on_train_epoch_end(trainer):
        if not is_main:
            return
        try:
            ramjetio.set_training_status(
                is_training=True,
                phase='training',
                current_epoch=trainer.epoch + 1,
                total_epochs=trainer.epochs,
            )
            logger.debug(f"RAMJET: epoch {trainer.epoch + 1}/{trainer.epochs} done")
        except Exception as e:
            logger.debug(f"RAMJET on_train_epoch_end error: {e}")

    def on_train_end(trainer):
        if not is_main:
            return
        try:
            # Send final epoch/loss before marking completed
            final_epoch = trainer.epoch + 1 if hasattr(trainer, 'epoch') else 0
            total_epochs = trainer.epochs if hasattr(trainer, 'epochs') else 0
            final_loss = float(trainer.tloss) if hasattr(trainer, 'tloss') and trainer.tloss is not None else None
            
            # Update with final values so dashboard has accurate numbers
            if final_epoch > 0:
                ramjetio.set_training_status(
                    is_training=True,
                    phase='training',
                    current_epoch=final_epoch,
                    total_epochs=total_epochs,
                    loss=final_loss,
                )
            
            ramjetio.end_training()
            logger.info("RAMJET: training completed")
        except Exception as e:
            logger.debug(f"RAMJET on_train_end error: {e}")

    model.add_callback('on_train_start', on_train_start)
    model.add_callback('on_train_epoch_start', on_train_epoch_start)
    model.add_callback('on_train_batch_end', on_train_batch_end)
    model.add_callback('on_train_epoch_end', on_train_epoch_end)
    model.add_callback('on_train_end', on_train_end)

    logger.info("RAMJET: ultralytics callbacks attached")
