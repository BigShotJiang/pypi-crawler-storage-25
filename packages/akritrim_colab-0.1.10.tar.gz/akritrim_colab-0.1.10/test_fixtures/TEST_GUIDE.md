# Diff-Link Manual Test Guide

Run the TUI from the `akritrim-colab/` directory:

```
cd akritrim-colab
akritrim-colab   # or: python -m akritrim_colab
```

At the startup prompt choose **fresh** or **resume** (either works for a clean test).

---

## Test 1 — Diff links persist across turns

Type into Master Input:

```
/ask claude Add type annotations to every function in test_fixtures/calculator.py. Edit the file.
```

Wait for Claude to finish.

- ✅ `▶ [DIFF] test_fixtures/calculator.py` should appear in the Claude pane.

Now send a second message so Claude takes another turn:

```
/ask claude Now add a module-level docstring to test_fixtures/calculator.py explaining what it does.
```

Wait for Claude to finish.

- ✅ The first `▶ [DIFF]` link must **still be visible** above the new message.
- ✅ Clicking it must open the diff modal showing the type annotation patch.

---

## Test 2 — Same file edited twice: distinct historical diffs

Continuing from Test 1 (or fresh session):

- Click the **first** `▶ [DIFF] test_fixtures/calculator.py` → should show type-hint changes (`+` lines for annotations).
- Click the **second** `▶ [DIFF] test_fixtures/calculator.py` → should show the docstring addition.
- ✅ The two modals must show **different** diffs.

---

## Test 3 — DiffModal copy button

1. Open any diff modal by clicking a `▶ [DIFF]` link.
2. Click the `⎘ Copy` button in the top-right of the modal.
3. ✅ Title changes to `Diff: calculator.py  ✓ Copied!`
4. Paste into a text editor — ✅ the raw unified diff text should arrive.
5. Wait ~2 seconds — ✅ title resets back to `Diff: test_fixtures/calculator.py`

---

## Test 4 — Theme switch does not wipe diff links

While a `▶ [DIFF]` link is visible in a pane, type:

```
/theme nord
```

- ✅ Diff link must **still be present** after the theme switch.
- ✅ Clicking it still opens the correct modal.

Restore with `/theme akritrim` if preferred.

---

## Test 5 — New-file and deletion diffs

**Step A — create a new file:**

```
/ask codex Create a new file test_fixtures/utils.py with a single function: `clamp(value, lo, hi)` that clamps value between lo and hi.
```

Wait for Codex to finish.

- ✅ `▶ [DIFF] test_fixtures/utils.py` appears in the Codex pane.
- ✅ Clicking it shows a **pure addition** patch (all `+` lines, no `-` lines except the `---/+++` header).

**Step B — delete the file in a later turn:**

```
/ask codex Delete test_fixtures/utils.py entirely.
```

Wait for Codex to finish.

- ✅ A **second** `▶ [DIFF] test_fixtures/utils.py` appears below the first.
- ✅ Clicking the **first** (create) link → still shows pure addition patch.
- ✅ Clicking the **second** (delete) link → shows pure deletion patch (all `-` lines).
- ✅ Both modals are distinct — historical correctness confirmed.

---

## All five pass?

Feature is materially closed. Reset the fixture file with:

```
git checkout test_fixtures/calculator.py
git clean -f test_fixtures/utils.py   # if it still exists
```
