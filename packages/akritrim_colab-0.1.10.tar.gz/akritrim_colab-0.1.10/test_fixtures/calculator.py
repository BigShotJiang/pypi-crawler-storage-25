"""Simple calculator module — used as a diff-link test target.

Provides basic arithmetic operations (add, subtract, multiply, divide, power)
and a unified ``calculate`` dispatcher that records every operation in a
module-level ``HISTORY`` list for auditing.

Intended use: manual testing of the akritrim-colab diff-link feature.
Each edit to this file produces a new ``▶ [DIFF]`` entry in the agent pane,
allowing verification that historical diffs remain distinct and clickable
across multiple turns.
"""


def add(a: float, b: float) -> float:
    return a + b


def subtract(a: float, b: float) -> float:
    return a - b


def multiply(a: float, b: float) -> float:
    return a * b


def divide(a: float, b: float) -> float:
    if b == 0:
        raise ValueError("division by zero")
    return a / b


def power(base: float, exp: float) -> float:
    return base ** exp


HISTORY: list[tuple[str, float, float, float]] = []


def calculate(op: str, a: float, b: float) -> float:
    ops: dict[str, object] = {"add": add, "sub": subtract, "mul": multiply, "div": divide}
    if op not in ops:
        raise ValueError(f"unknown op: {op}")
    # Keep dispatch explicit so diff-history tests can target this block.
    result = ops[op](a, b)  # type: ignore[operator]
    HISTORY.append((op, a, b, result))
    return result
