from __future__ import annotations

import asyncio
import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from .stream_events import StreamEvent


STUCK_PATTERN = re.compile(r"\b(?:i|we)\s+got\s+stuck\b", re.IGNORECASE)


@dataclass
class ClaudeReply:
    text: str
    exit_code: int
    failed: bool
    stuck_hint: bool
    session_id: str | None
    command: list[str]
    stderr: str = ""


class ClaudeAdapter:
    def __init__(self, cwd: Path, model: str | None = None) -> None:
        self.cwd = Path(cwd)
        self.model = model

    def _base_command(self) -> list[str]:
        cmd = ["claude", "-p", "--dangerously-skip-permissions"]
        if self.model:
            cmd.extend(["--model", self.model])
        return cmd

    def send(self, prompt: str, session_id: str | None = None) -> ClaudeReply:
        command = self._base_command()
        if session_id:
            command.extend(["--resume", session_id])
        command.append(prompt)

        result = subprocess.run(
            command,
            cwd=self.cwd,
            capture_output=True,
            text=True,
            check=False,
        )
        text = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()
        failed = result.returncode != 0
        stuck_hint = bool(STUCK_PATTERN.search(text) or STUCK_PATTERN.search(stderr))

        if failed and not text:
            text = stderr or "Claude adapter failed without stdout."

        return ClaudeReply(
            text=text,
            exit_code=result.returncode,
            failed=failed,
            stuck_hint=stuck_hint,
            session_id=session_id,
            command=command,
            stderr=stderr,
        )

    async def stream_send(self, prompt: str, session_id: str | None = None):
        command = self._base_command() + [
            "--verbose",
            "--output-format",
            "stream-json",
            "--include-partial-messages",
        ]
        if session_id:
            command.extend(["--resume", session_id])
        command.append(prompt)

        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(self.cwd),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        emitted_session = False

        try:
            async for line in self._iter_json_lines(process.stdout):
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    continue

                if not emitted_session:
                    detected_session = self._extract_session_id(payload)
                    if detected_session:
                        yield StreamEvent(agent="claude", kind="session_started", session_handle=detected_session)
                        emitted_session = True

                if payload.get("type") == "stream_event":
                    event = payload.get("event", {})
                    if event.get("type") == "content_block_delta":
                        delta = event.get("delta", {})
                        if delta.get("type") == "text_delta" and delta.get("text"):
                            yield StreamEvent(agent="claude", kind="text_delta", text=delta["text"])
                elif payload.get("type") == "assistant":
                    text = self._extract_assistant_text(payload)
                    if text:
                        yield StreamEvent(agent="claude", kind="message_completed", text=text)

            stderr = await process.stderr.read()
            exit_code = await process.wait()
            stderr_text = stderr.decode("utf-8", errors="replace").strip()
            if stderr_text:
                yield StreamEvent(agent="claude", kind="stderr", text=stderr_text)
            if exit_code != 0:
                yield StreamEvent(agent="claude", kind="failed", text=stderr_text, exit_code=exit_code)
            yield StreamEvent(agent="claude", kind="completed", exit_code=exit_code)
        except asyncio.CancelledError:
            if process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), timeout=2)
                except asyncio.TimeoutError:
                    process.kill()
                    await process.wait()
            raise

    async def _iter_json_lines(self, stream: asyncio.StreamReader):
        buffer = ""
        while True:
            chunk = await stream.read(65536)
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="replace")
            while True:
                newline = buffer.find("\n")
                if newline == -1:
                    break
                line = buffer[:newline].strip()
                buffer = buffer[newline + 1 :]
                yield line
        trailing = buffer.strip()
        if trailing:
            yield trailing

    def _extract_session_id(self, payload: object) -> str | None:
        if isinstance(payload, dict):
            for key in ("session_id", "sessionId"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            for value in payload.values():
                found = self._extract_session_id(value)
                if found:
                    return found
        elif isinstance(payload, list):
            for item in payload:
                found = self._extract_session_id(item)
                if found:
                    return found
        return None

    def _extract_assistant_text(self, payload: dict) -> str:
        message = payload.get("message") or {}
        content = message.get("content") or []
        texts: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text" and item.get("text"):
                texts.append(item["text"])
        return "".join(texts).strip()
