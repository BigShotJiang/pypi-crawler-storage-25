from __future__ import annotations

import asyncio
import difflib
import hashlib
import json
import re
import subprocess
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, cast

from textual import events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.timer import Timer
from textual.widget import Widget
from textual.widgets import Button, RichLog, Static, TextArea
from rich.style import Style
from rich.text import Text

from .agents import ClaudeAdapter, CodexAdapter, StreamEvent
from .config import AppSettings, ProjectConfig

STUCK_PATTERN = re.compile(r"\b(?:i|we)\s+got\s+stuck\b", re.IGNORECASE)
INSTRUCTION_CLASSES = ("fix", "audit", "feature", "refactor", "analyze", "decide")
ROLE_CONSTRAINTS: dict[str, str] = {
    "implementer": (
        "Prioritize code changes, execution, and concrete artifacts. "
        "Do not stop at critique alone - produce the deliverable."
    ),
    "reviewer": (
        "Prioritize bugs, regressions, risks, and verification gaps. "
        "Avoid code changes unless Master explicitly asks or it is necessary to complete the assigned fix."
    ),
    "collaborator": "Contribute analysis or implementation as appropriate to the task.",
}


@dataclass
class TuiPalette:
    """Named color palette — maps speaker/accent roles to Rich style strings."""
    name: str
    # Speaker label Rich styles
    claude_style: str
    codex_style: str
    master_style: str
    # Accent hex colors
    diff_link: str
    copy_link: str
    tool_text: str
    # Completion widget styles
    completion_selected_style: str
    completion_normal_style: str
    completion_desc_style: str
    # Diff line colors
    diff_add: str
    diff_remove: str
    diff_hunk: str
    diff_header: str


THEMES: dict[str, TuiPalette] = {
    "akritrim": TuiPalette(
        name="akritrim",
        claude_style="bold green",
        codex_style="bold dark_orange3",
        master_style="bold red",
        diff_link="#60a5fa",
        copy_link="#fde047",
        tool_text="#94a3b8",
        completion_selected_style="bold white on #2563eb",
        completion_normal_style="bold #60a5fa",
        completion_desc_style="dim #94a3b8",
        diff_add="#4ade80",
        diff_remove="#f87171",
        diff_hunk="#67e8f9",
        diff_header="#94a3b8",
    ),
    "nord": TuiPalette(
        name="nord",
        claude_style="bold #88c0d0",
        codex_style="bold #ebcb8b",
        master_style="bold #bf616a",
        diff_link="#81a1c1",
        copy_link="#a3be8c",
        tool_text="#4c566a",
        completion_selected_style="bold white on #3b4252",
        completion_normal_style="bold #81a1c1",
        completion_desc_style="dim #4c566a",
        diff_add="#a3be8c",
        diff_remove="#bf616a",
        diff_hunk="#88c0d0",
        diff_header="#4c566a",
    ),
    "dracula": TuiPalette(
        name="dracula",
        claude_style="bold #50fa7b",
        codex_style="bold #ffb86c",
        master_style="bold #ff5555",
        diff_link="#bd93f9",
        copy_link="#f1fa8c",
        tool_text="#6272a4",
        completion_selected_style="bold white on #44475a",
        completion_normal_style="bold #bd93f9",
        completion_desc_style="dim #6272a4",
        diff_add="#50fa7b",
        diff_remove="#ff5555",
        diff_hunk="#8be9fd",
        diff_header="#6272a4",
    ),
    "solarized": TuiPalette(
        name="solarized",
        claude_style="bold #2aa198",
        codex_style="bold #b58900",
        master_style="bold #dc322f",
        diff_link="#268bd2",
        copy_link="#859900",
        tool_text="#586e75",
        completion_selected_style="bold white on #073642",
        completion_normal_style="bold #268bd2",
        completion_desc_style="dim #586e75",
        diff_add="#859900",
        diff_remove="#dc322f",
        diff_hunk="#2aa198",
        diff_header="#586e75",
    ),
}

# All slash commands with brief descriptions, used for autocomplete palette.
SLASH_COMMANDS: list[tuple[str, str]] = [
    ("/fresh",         "Start a fresh session (clears history)"),
    ("/resume",        "Resume the existing session"),
    ("/fix",           "Bug-fix flow: /fix <description>"),
    ("/audit",         "Security/quality audit: /audit <target>"),
    ("/feature",       "Build a feature: /feature <description>"),
    ("/refactor",      "Refactor code: /refactor <target>"),
    ("/analyze",       "Analyze a question: /analyze <question>"),
    ("/decide",        "Log a decision: /decide <text>"),
    ("/decision",      "Structured decision: /decision D-XXX | Title | Decision | Rationale"),
    ("/topic",         "Open scratchpad topic: /topic T-XXX | Title | Codex pos | Claude pos"),
    ("/resolve-topic", "Resolve a topic: /resolve-topic T-XXX | D-XXX"),
    ("/ask",           "Ask a specific agent: /ask <claude|codex|both> <message>"),
    ("/compare",       "Run a comparison round between agents"),
    ("/approve",       "Approve a pending agent request"),
    ("/deny",          "Deny a pending agent request"),
    ("/mode",          "Set collaboration mode: /mode <value>"),
    ("/role",          "Set agent roles: /role codex|claude|both <role>"),
    ("/status",        "Show current session status"),
    ("/save",          "Save current session state"),
    ("/exit",          "Exit the application"),
    ("/export",        "Export a pane to file: /export <claude|codex|master> <filename>"),
    ("/theme",         "Switch color theme: /theme <akritrim|nord|dracula|solarized>"),
]


@dataclass
class SessionState:
    active_identity: str
    role: str
    codex_role: str
    claude_role: str
    mode: str | None
    turn_index: int
    next_speaker: str
    waiting_for_master: bool
    collaboration_active: bool
    stuck: bool
    session_log_path: str
    claude_session_id: str | None = None
    codex_resume_handle: str | None = None
    protocol_bootstrapped: bool = False
    comparison_round: int = 0
    auto_turn_count: int = 0
    last_speaker: str = "master"
    instruction_class: str | None = None
    startup_existing: bool = False
    resume_was_active: bool = False


@dataclass
class RouteCommand:
    kind: Literal[
        "route", "mode", "role", "status", "save", "exit",
        "decision", "topic", "resolve_topic", "compare", "approve", "deny",
        "fix", "audit", "feature", "refactor", "analyze", "decide", "usage_hint",
    ]
    target: Literal["claude", "codex", "both", "system"] = "system"
    message: str = ""


class SplitterHandle(Widget):
    """Draggable divider for resizing adjacent panels."""

    DEFAULT_CSS = """
    SplitterHandle {
        background: #3a3a3a;
        color: #666666;
    }
    SplitterHandle:hover {
        background: #555555;
        color: #999999;
    }
    SplitterHandle.-vertical {
        width: 1;
        height: 100%;
    }
    SplitterHandle.-horizontal {
        width: 100%;
        height: 1;
    }
    """

    def __init__(self, orientation: Literal["vertical", "horizontal"], **kwargs) -> None:
        super().__init__(classes=f"-{orientation}", **kwargs)
        self.orientation = orientation
        self._dragging = False

    def render(self) -> str:
        return "│" if self.orientation == "vertical" else "─"

    def on_mouse_down(self, event: events.MouseDown) -> None:
        self._dragging = True
        self.capture_mouse()
        event.stop()

    def on_mouse_up(self, event: events.MouseUp) -> None:
        self._dragging = False
        self.release_mouse()
        event.stop()

    def on_mouse_move(self, event: events.MouseMove) -> None:
        if not self._dragging:
            return
        parent = self.parent
        if parent is None:
            return
        siblings = list(parent.children)
        try:
            idx = siblings.index(self)
        except ValueError:
            return
        if idx == 0 or idx >= len(siblings) - 1:
            return

        if self.orientation == "vertical":
            left = siblings[idx - 1]
            right = siblings[idx + 1]
            parent_x = parent.region.x
            parent_width = parent.size.width
            pointer_x = int(event.screen_x) - parent_x
            if pointer_x <= 4:
                new_left = 1
            elif pointer_x >= parent_width - 5:
                new_left = parent_width - 2
            else:
                new_left = max(8, min(pointer_x, parent_width - 9))
            new_right = max(1, parent_width - new_left - 1)
            left.styles.width = new_left
            right.styles.width = new_right
        else:
            top = siblings[idx - 1]
            bottom = siblings[idx + 1]
            parent_y = parent.region.y
            parent_height = parent.size.height
            pointer_y = int(event.screen_y) - parent_y
            if pointer_y <= 2:
                new_top = 1
            elif pointer_y >= parent_height - 3:
                new_top = parent_height - 2
            else:
                new_top = max(3, min(pointer_y, parent_height - 4))
            new_bottom = max(1, parent_height - new_top - 1)
            top.styles.height = new_top
            bottom.styles.height = new_bottom
        parent.refresh(layout=True)
        event.stop()


class MasterInput(TextArea):
    """TextArea that sends on Enter and inserts a newline on Ctrl+Enter."""

    class Submit(Message):
        pass

    class NavigateCompletions(Message):
        def __init__(self, direction: int) -> None:
            super().__init__()
            self.direction = direction  # -1 = up, +1 = down

    class AcceptCompletion(Message):
        pass

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._input_history: list[str] = []
        self.history_index: int | None = None
        self.history_draft = ""
        self.completions_open: bool = False

    def on_key(self, event: events.Key) -> None:
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            self.post_message(self.Submit())
        elif event.key == "ctrl+enter":
            event.prevent_default()
            event.stop()
            self.insert("\n")
        elif event.key == "tab":
            if self.completions_open:
                event.prevent_default()
                event.stop()
                self.post_message(self.AcceptCompletion())
        elif event.key == "up":
            if self.completions_open:
                event.prevent_default()
                event.stop()
                self.post_message(self.NavigateCompletions(-1))
            else:
                row, _ = self.cursor_location
                # Trigger history only when on the first line or already browsing
                if self.history_index is not None or row == 0:
                    event.prevent_default()
                    event.stop()
                    self._history_up()
        elif event.key == "down":
            if self.completions_open:
                event.prevent_default()
                event.stop()
                self.post_message(self.NavigateCompletions(+1))
            else:
                row, _ = self.cursor_location
                lines = self.text.splitlines()
                last_row = max(0, len(lines) - 1)
                # Trigger history only when on the last line or already browsing
                if self.history_index is not None or row == last_row:
                    event.prevent_default()
                    event.stop()
                    self._history_down()

    def push_history(self, value: str) -> None:
        if not value:
            return
        if not self._input_history or self._input_history[-1] != value:
            self._input_history.append(value)
        self.history_index = None
        self.history_draft = ""

    def _history_up(self) -> None:
        if not self._input_history:
            return
        if self.history_index is None:
            self.history_draft = self.text
            self.history_index = len(self._input_history) - 1
        elif self.history_index > 0:
            self.history_index -= 1
        self._load_history_value(self._input_history[self.history_index])

    def _history_down(self) -> None:
        if self.history_index is None:
            return
        if self.history_index < len(self._input_history) - 1:
            self.history_index += 1
            self._load_history_value(self._input_history[self.history_index])
            return
        self.history_index = None
        self._load_history_value(self.history_draft)

    def _load_history_value(self, value: str) -> None:
        self.load_text(value)
        line_count = len(value.splitlines()) - 1 if value else 0
        final_column = len(value.splitlines()[-1]) if value else 0
        self.move_cursor((line_count, final_column))


class DiffModal(ModalScreen[None]):
    CSS = """
    DiffModal {
        align: center middle;
    }
    #diff-modal {
        width: 90%;
        height: 90%;
        background: #111827;
        border: solid #93c5fd;
        padding: 1;
        layout: vertical;
    }
    #diff-modal-header {
        height: 3;
        width: 100%;
        align: right middle;
    }
    #diff-modal-title {
        width: 1fr;
        content-align: left middle;
        color: #f8fafc;
    }
    #diff-copy {
        width: 10;
    }
    #diff-close {
        width: 5;
    }
    #diff-body {
        height: 1fr;
    }
    #diff-text {
        height: 100%;
    }
    """

    def __init__(self, file_name: str, diff_text: str, palette: "TuiPalette | None" = None) -> None:
        super().__init__()
        self.file_name = file_name
        self.diff_text = diff_text
        self.palette = palette

    def compose(self) -> ComposeResult:
        with Container(id="diff-modal"):
            with Horizontal(id="diff-modal-header"):
                yield Static(f"Diff: {self.file_name}", id="diff-modal-title")
                yield Button("\u2398 Copy", id="diff-copy", compact=True)
                yield Button("X", id="diff-close", compact=True)
            yield RichLog(id="diff-text", wrap=False, markup=False)

    def on_mount(self) -> None:
        log = self.query_one("#diff-text", RichLog)
        pal = self.palette or THEMES["akritrim"]
        self._render_diff_to(log, self.diff_text, pal)

    @staticmethod
    def _render_diff_to(log: "RichLog", diff_text: str, palette: "TuiPalette") -> None:
        """Write diff lines to a RichLog with +/- colorization."""
        for line in diff_text.splitlines():
            t = Text()
            if line.startswith("+++") or line.startswith("---"):
                t.append(line, style=f"dim {palette.diff_header}")
            elif line.startswith("+"):
                t.append(line, style=f"bold {palette.diff_add}")
            elif line.startswith("-"):
                t.append(line, style=f"bold {palette.diff_remove}")
            elif line.startswith("@@"):
                t.append(line, style=f"bold {palette.diff_hunk}")
            else:
                t.append(line)
            log.write(t)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "diff-close":
            self.dismiss()
            event.stop()
        elif event.button.id == "diff-copy":
            ok = cast("CollabApp", self.app)._copy_to_clipboard(self.diff_text)
            suffix = "  \u2713 Copied!" if ok else "  \u2717 Copy failed"
            title = self.query_one("#diff-modal-title", Static)
            title.update(f"Diff: {self.file_name}{suffix}")
            self.set_timer(2.0, lambda: title.update(f"Diff: {self.file_name}"))
            event.stop()


class CollabApp(App[None]):
    CSS = """
    Screen {
        layout: vertical;
    }
    #main {
        height: 1fr;
        layout: horizontal;
    }
    #chat-panel {
        width: 50%;
        height: 100%;
        layout: vertical;
    }
    #chat-activity {
        height: 1;
        background: #25303b;
        color: #f5f7fa;
        padding: 0 1;
    }
    #chat-log {
        width: 100%;
        height: 100%;
        border: solid #4a5568;
    }
    #right-panel {
        width: 1fr;
        height: 100%;
        layout: vertical;
    }
    #claude-panel {
        height: 1fr;
        layout: vertical;
    }
    #codex-panel {
        height: 1fr;
        layout: vertical;
    }
    #claude-log {
        width: 100%;
        height: 1fr;
        border: solid #666666;
    }
    #codex-log {
        width: 100%;
        height: 1fr;
        border: solid #666666;
    }
    #bottom {
        height: auto;
        border-top: solid #666666;
        padding: 0 1;
    }
    #status {
        height: 1;
        background: #1f2933;
        color: #f5f7fa;
        padding: 0 1;
    }
    #master-input {
        margin: 1 0;
        height: 5;
    }
    #command-suggestions {
        background: #1e293b;
        border: solid #4a5568;
        padding: 0 1;
        height: auto;
        max-height: 14;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel_active_work", "Cancel Active Work", priority=True),
        ("ctrl+c", "quit", "Quit"),
    ]

    def __init__(
        self,
        state: SessionState,
        config: ProjectConfig,
        debug_log_path: Path | None = None,
        max_auto_turns: int | None = None,
        claude_model: str | None = None,
        codex_model: str | None = None,
    ) -> None:
        super().__init__()
        self.state = state
        self.config = config
        self.repo_root = config.project_root
        self.debug_log_path = debug_log_path or (self.config.session_dir / "tui_debug.log")
        self.claude = ClaudeAdapter(config.project_root, model=claude_model)
        self.codex = CodexAdapter(config.project_root, model=codex_model)
        self.pending_approvals = 0
        self.pane_history: dict[str, list[tuple[str, str]]] = {"claude": [], "codex": []}
        self.active_message: dict[str, str] = {"claude": "", "codex": ""}
        self.active_text: dict[str, str] = {"claude": "", "codex": ""}
        self.active_speaker: dict[str, str] = {"claude": "Claude", "codex": "Codex"}
        self.latest_completed_reply: dict[str, str] = {"claude": "", "codex": ""}
        self.agent_busy: dict[str, bool] = {"claude": False, "codex": False}
        self.max_auto_turns = max_auto_turns or 12
        self.startup_choice_pending = state.startup_existing
        self.working_phase = 0
        self.working_timer: Timer | None = None
        self.pending_request_from: str | None = None
        self.pending_request_text: str | None = None
        # Stable ordered list of (path, diff_text) per pane, one entry per occurrence.
        # Index in the list is the stable id stored in pane_history ("diff", str(idx)).
        # Path-keyed lookup is intentionally avoided so old entries always open the
        # correct patch even after the same file changes again in a later turn.
        self.turn_diff_entries: dict[str, list[tuple[str, str]]] = {"claude": [], "codex": []}
        # Chat log history for /export master (timestamp, speaker, message)
        self.chat_history: list[tuple[str, str, str]] = []
        # Slash-command autocomplete state
        self._completions: list[tuple[str, str]] = []
        self._completion_idx: int = 0
        # Copy-button message store: stable id -> full message text
        self._msg_counter: int = 0
        self._message_store: dict[str, str] = {}
        # Active color palette — load from settings.toml if persisted, else default to akritrim
        _saved_theme = AppSettings.load(config.settings_path).theme
        self._active_palette: TuiPalette = (
            THEMES[_saved_theme]
            if _saved_theme and _saved_theme in THEMES
            else THEMES["akritrim"]
        )

    @property
    def state_path(self) -> Path:
        return self.config.session_dir / "state.json"

    @property
    def transcript_path(self) -> Path:
        return self.config.session_dir / "current.md"

    def _display_path(self, path: Path) -> str:
        try:
            return str(path.relative_to(self.config.project_root))
        except ValueError:
            return str(path)

    def _role_constraint(self, role: str) -> str:
        return ROLE_CONSTRAINTS.get(role.lower().split()[0], "")

    def _role_preamble(self, target_name: str, role: str) -> str:
        constraint = self._role_constraint(role)
        if constraint:
            return f"You are {target_name}, role: {role}. {constraint}"
        return f"You are {target_name}, role: {role}."

    def compose(self) -> ComposeResult:
        with Horizontal(id="main"):
            with Vertical(id="chat-panel"):
                yield Static("", id="chat-activity")
                yield RichLog(id="chat-log", wrap=True, markup=False)
            yield SplitterHandle("vertical")
            with Vertical(id="right-panel"):
                with Vertical(id="claude-panel"):
                    yield RichLog(id="claude-log", wrap=True, markup=False)
                yield SplitterHandle("horizontal")
                with Vertical(id="codex-panel"):
                    yield RichLog(id="codex-log", wrap=True, markup=False)
        with Container(id="bottom"):
            yield Static("Master Input (Enter to send, Ctrl+Enter for newline, Tab to complete)")
            yield Static("", id="command-suggestions")
            yield MasterInput(
                "",
                soft_wrap=True,
                tab_behavior="focus",
                id="master-input",
            )
        yield Static(id="status")

    def on_mount(self) -> None:
        self._debug("on_mount start")
        self.query_one("#command-suggestions", Static).display = False
        self._write_system("claude", "Session initialized.")
        self._write_system("codex", "Session initialized.")
        self._write_chat("System", "Session initialized.")
        if self.startup_choice_pending:
            self._debug("existing session found; awaiting resume/fresh choice")
            self._write_chat("System", "Existing session found. Type `resume` to continue or `fresh` to start a new session.")
            self._write_system("claude", "Existing session found; waiting for Master to choose resume or fresh.")
            self._write_system("codex", "Existing session found; waiting for Master to choose resume or fresh.")
        self._refresh_status()
        self._refresh_activity_indicator()
        self.query_one(MasterInput).focus()
        self.working_timer = self.set_interval(0.4, self._tick_working_indicator)
        # Bootstrap if never done, or if this is a fresh state (turn_index == 0)
        if not self.startup_choice_pending and (not self.state.protocol_bootstrapped or self.state.turn_index == 0):
            self._debug("starting bootstrap worker")
            self._write_chat("System", "Bootstrapping protocol — reading memory, scratchpad, rules...")
            self.run_worker(self._bootstrap_protocol(), exclusive=True)
        self._debug("on_mount complete")

    async def action_submit_master_input(self) -> None:
        input_widget = self.query_one("#master-input", MasterInput)
        raw = input_widget.text.strip()
        input_widget.clear()
        self._hide_completions()
        if not raw:
            return
        input_widget.push_history(raw)
        self._debug(f"input raw={raw!r}")

        if self.startup_choice_pending:
            lowered = raw.lower()
            if lowered in ("resume", "/resume"):
                self.startup_choice_pending = False
                if self.state.resume_was_active:
                    self._write_chat("System", "Resumed active collaboration; continuing automatically.")
                    self._write_system("claude", "Resumed active collaboration; continuing automatically.")
                    self._write_system("codex", "Resumed active collaboration; continuing automatically.")
                    self.state.collaboration_active = True
                    self.state.waiting_for_master = False
                    self.state.next_speaker = "both"
                    self.persist_state()
                    self._refresh_status()
                    self.run_worker(self._resume_active_session(), exclusive=True)
                else:
                    self.state.waiting_for_master = True
                    self.state.collaboration_active = False
                    self.state.next_speaker = "master"
                    self.persist_state()
                    self._write_chat("System", "Resumed existing session; waiting for Master.")
                    self._write_system("claude", "Resumed existing session; waiting for Master.")
                    self._write_system("codex", "Resumed existing session; waiting for Master.")
                    self._refresh_status()
                return
            if lowered in ("fresh", "/fresh"):
                self._start_fresh_session()
                return
            self._write_chat("System", "Type `resume` or `fresh` (or /resume / /fresh).")
            return

        if raw.lower() == "/fresh":
            self._start_fresh_session()
            return

        if raw.lower().startswith("/export "):
            self._handle_export_command(raw[len("/export "):].strip())
            return

        if raw.lower().startswith("/theme"):
            parts = raw.split(None, 1)
            if len(parts) == 2:
                self._apply_theme(parts[1].strip().lower())
            else:
                available = ", ".join(THEMES)
                self._write_chat("System", f"Usage: /theme <name>  |  Available: {available}")
            return

        command = self._parse_input(raw)
        if command is None:
            command = RouteCommand(kind="route", target="both", message=raw)
            self._debug("parsed input as default shared route")

        if command.kind == "exit":
            self.persist_state()
            self.exit()
            return
        if command.kind == "status":
            self._write_system("codex", self._status_text())
            self._write_chat("System", self._status_text())
            return
        if command.kind == "save":
            self.persist_state()
            self._write_system("codex", "State and transcript saved.")
            self._write_chat("System", "State and transcript saved.")
            return
        if command.kind == "compare":
            self._debug("running compare command")
            self.run_worker(self._run_comparison_round(), exclusive=True)
            return
        if command.kind in ("approve", "deny"):
            target = cast(Literal["claude", "codex", "both", "system"], self.pending_request_from or "both")
            decision_text = "Approved." if command.kind == "approve" else "Denied."
            follow_up = (
                "Master approved. Continue."
                if command.kind == "approve"
                else "Master denied the request. Stop that line of work and wait for new instruction."
            )
            self.state.turn_index += 1
            self.state.waiting_for_master = False
            self.state.stuck = False
            self.state.collaboration_active = False
            self.state.last_speaker = "master"
            self.pending_approvals = max(0, self.pending_approvals - 1)
            self.pending_request_from = None
            self.pending_request_text = None
            self.persist_state()
            self._write_transcript("Master", decision_text)
            self._write_chat("Master", decision_text)
            self._refresh_status()
            self.run_worker(
                self._dispatch_route(RouteCommand(kind="route", target=target, message=follow_up)),
                exclusive=True,
            )
            return
        if command.kind == "usage_hint":
            label = "text" if command.message == "decide" else "target"
            self._write_chat("System", f"Usage: /{command.message} <{label}>")
            return
        if command.kind == "decision":
            self._handle_decision_command(command.message)
            return
        if command.kind == "topic":
            self._handle_topic_command(command.message)
            return
        if command.kind == "resolve_topic":
            self._handle_resolve_topic_command(command.message)
            return
        if command.kind in ("fix", "audit", "feature", "refactor", "analyze", "decide"):
            self._debug(f"running instruction flow kind={command.kind} message={command.message!r}")
            self._write_transcript("Master", raw)
            self._write_chat("Master", raw)
            self.state.instruction_class = command.kind
            self.state.turn_index += 1
            self.state.auto_turn_count = 0
            self.state.comparison_round = 0
            self.state.collaboration_active = False
            self.state.last_speaker = "master"
            self.persist_state()
            self.run_worker(self._run_instruction_flow(command), exclusive=True)
            return
        if command.kind == "mode":
            self.state.mode = command.message
            self.persist_state()
            self._write_transcript("Master", raw)
            self._write_chat("Master", raw)
            self.run_worker(self._broadcast_mode(command.message), exclusive=True)
            return
        if command.kind == "role":
            self.state.role = command.message
            self.persist_state()
            self._write_transcript("Master", raw)
            self._write_chat("Master", raw)
            self.run_worker(self._broadcast_role(command.message), exclusive=True)
            return

        self.state.turn_index += 1
        self.state.next_speaker = command.target
        self.state.waiting_for_master = False
        self.state.stuck = False
        self.state.collaboration_active = command.kind == "route" and command.target == "both"
        self.state.auto_turn_count = 0
        self.state.comparison_round = 0
        self.state.last_speaker = "master"
        self.persist_state()
        self._write_transcript("Master", raw)
        self._write_chat("Master", raw)
        self._debug(
            f"dispatch route target={command.target} collaboration_active={self.state.collaboration_active}"
        )
        self.run_worker(self._dispatch_route(command), exclusive=True)

    async def on_master_input_submit(self, _message: MasterInput.Submit) -> None:
        await self.action_submit_master_input()

    def action_cancel_active_work(self) -> None:
        # If autocomplete palette is open, dismiss it first.
        if self._completions:
            self._hide_completions()
            return
        # If DiffModal is open, dismiss it instead of cancelling agents.
        if isinstance(self.screen, DiffModal):
            self.screen.dismiss()
            return
        if not any(self.agent_busy.values()):
            return
        self._debug("escape pressed; cancelling active work")
        self.state.collaboration_active = False
        self.state.waiting_for_master = True
        self.state.next_speaker = "master"
        self.persist_state()
        self._write_chat("System", "Master cancelled the active agent turn.")
        self._refresh_status(extra="Cancellation requested")
        self.workers.cancel_group(self, "default")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        pass  # diff-close is handled inside DiffModal; no other buttons remain

    async def _dispatch_route(self, command: RouteCommand) -> None:
        self._debug(f"_dispatch_route start kind={command.kind} target={command.target}")
        self._refresh_status()
        targets: list[str]
        if command.target == "both":
            # Order by role: implementer acts first, reviewer responds second.
            # Check both fields independently to handle all ambiguous cases.
            claude_is_implementer = "implementer" in self.state.claude_role.lower()
            codex_is_implementer = "implementer" in self.state.codex_role.lower()
            if claude_is_implementer and not codex_is_implementer:
                targets = ["claude", "codex"]
                target_label = "both (Claude first — implementer)"
            elif codex_is_implementer and not claude_is_implementer:
                targets = ["codex", "claude"]
                target_label = "both (Codex first — implementer)"
            else:
                # Both, neither, or ambiguous roles — deterministic fallback
                targets = ["codex", "claude"]
                target_label = "both (fallback order)"
        elif command.target == "codex":
            targets = ["codex"]
            target_label = "codex"
        else:
            targets = ["claude"]
            target_label = "claude"
        self._write_chat("System", f"Dispatching to: {target_label}")

        # Sequential conditioning: each agent after the first sees prior agents' replies.
        # This ensures the reviewer reacts to the implementer's work, not just the
        # original message, from the very first dispatch turn.
        prior_replies: list[tuple[str, str]] = []

        for index, target in enumerate(targets):
            final = index == len(targets) - 1
            next_speaker = "master" if final else targets[index + 1]
            if target == "claude":
                msg = command.message
                if command.kind == "route":
                    prior = self._format_prior_replies(prior_replies)
                    msg = f"{self._role_preamble('Claude', self.state.claude_role)}\n\n{msg}{prior}"
                await self._invoke_claude(msg, final=final, next_speaker=next_speaker)
                reply = self.latest_completed_reply["claude"]
                if reply:
                    prior_replies.append(("Claude", reply))
            else:
                msg = command.message
                if command.kind == "route":
                    prior = self._format_prior_replies(prior_replies)
                    msg = f"{self._role_preamble('Codex', self.state.codex_role)}\n\n{msg}{prior}"
                await self._invoke_codex(msg, final=final, next_speaker=next_speaker)
                reply = self.latest_completed_reply["codex"]
                if reply:
                    prior_replies.append(("Codex", reply))

        if command.kind == "route" and self.state.collaboration_active:
            self._debug("entering collaboration loop from route dispatch")
            await self._run_collaboration_loop()
        self._debug("_dispatch_route complete")

    async def _invoke_claude(self, message: str, final: bool, next_speaker: str) -> None:
        loop = asyncio.get_running_loop()
        pre_state = await loop.run_in_executor(None, self._capture_file_state)
        self._begin_stream("claude", "Claude")
        await self._consume_stream(
            pane="claude",
            speaker="Claude",
            stream=self.claude.stream_send(message, self.state.claude_session_id),
            final=final,
            next_speaker=next_speaker,
        )
        diff_map = await loop.run_in_executor(None, self._compute_turn_delta, pre_state)
        await self._update_pane_diff_strip("claude", diff_map)

    async def _invoke_codex(self, message: str, final: bool, next_speaker: str) -> None:
        loop = asyncio.get_running_loop()
        pre_state = await loop.run_in_executor(None, self._capture_file_state)
        self._begin_stream("codex", "Codex")
        await self._consume_stream(
            pane="codex",
            speaker="Codex",
            stream=self.codex.stream_send(message, self.state.codex_resume_handle),
            final=final,
            next_speaker=next_speaker,
        )
        diff_map = await loop.run_in_executor(None, self._compute_turn_delta, pre_state)
        await self._update_pane_diff_strip("codex", diff_map)

    def _parse_input(self, raw: str) -> RouteCommand | None:
        if raw.startswith("@claude "):
            return RouteCommand(kind="route", target="claude", message=raw[len("@claude "):].strip())
        if raw.startswith("@codex "):
            return RouteCommand(kind="route", target="codex", message=raw[len("@codex "):].strip())
        if raw.startswith("@both "):
            return RouteCommand(kind="route", target="both", message=raw[len("@both "):].strip())
        if raw.startswith("/ask "):
            rest = raw[len("/ask "):].strip()
            if " " not in rest:
                return None
            target, message = rest.split(" ", 1)
            target = target.lower()
            if target in {"claude", "codex", "both"} and message.strip():
                return RouteCommand(
                    kind="route",
                    target=cast(Literal["claude", "codex", "both", "system"], target),
                    message=message.strip(),
                )
            return None
        if raw.startswith("/mode "):
            value = raw[len("/mode "):].strip()
            return RouteCommand(kind="mode", message=value) if value else None
        if raw.startswith("/role "):
            value = raw[len("/role "):].strip()
            return RouteCommand(kind="role", message=value) if value else None
        if raw == "/status":
            return RouteCommand(kind="status")
        if raw == "/save":
            return RouteCommand(kind="save")
        if raw == "/compare":
            return RouteCommand(kind="compare")
        if raw == "/approve":
            return RouteCommand(kind="approve")
        if raw == "/deny":
            return RouteCommand(kind="deny")
        if raw.startswith("/decision "):
            value = raw[len("/decision "):].strip()
            return RouteCommand(kind="decision", message=value) if value else None
        if raw.startswith("/topic "):
            value = raw[len("/topic "):].strip()
            return RouteCommand(kind="topic", message=value) if value else None
        if raw.startswith("/resolve-topic "):
            value = raw[len("/resolve-topic "):].strip()
            return RouteCommand(kind="resolve_topic", message=value) if value else None
        if raw == "/exit":
            return RouteCommand(kind="exit")
        # D-039: slash-prefixed canonical forms
        for kind in INSTRUCTION_CLASSES:
            if raw == f"/{kind}":
                return RouteCommand(kind="usage_hint", message=kind)
            if raw.startswith(f"/{kind} "):
                value = raw[len(f"/{kind} "):].strip()
                if value:
                    return RouteCommand(kind=kind, message=value)  # type: ignore[arg-type]
        # Bare keyword compatibility aliases
        for kind in INSTRUCTION_CLASSES:
            if raw == kind:
                return RouteCommand(kind="usage_hint", message=kind)
            if raw.startswith(f"{kind} "):
                value = raw[len(f"{kind} "):].strip()
                if value:
                    return RouteCommand(kind=kind, message=value)  # type: ignore[arg-type]
        return None

    def _capture_file_state(self) -> dict[str, tuple[str, str, bytes | None]]:
        """Return {path: (md5_hash, git_marker, content_or_None)} for every dirty/untracked file.

        Excludes session-internal paths (state, transcript, debug log) so they
        never pollute the per-turn diff strip.
        """
        # Build exclusion prefix for session bookkeeping files
        try:
            session_rel = str(self.config.session_dir.relative_to(self.repo_root))
        except ValueError:
            session_rel = None
        session_prefix = (session_rel + "/") if session_rel else None

        status = subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=all"],
            cwd=self.repo_root, capture_output=True, text=True, check=False,
        )
        if status.returncode != 0:
            return {}
        result: dict[str, tuple[str, str, bytes | None]] = {}
        for line in status.stdout.splitlines():
            if len(line) < 4:
                continue
            marker = line[:2]
            path = line[3:].split(" -> ")[-1].strip()
            # Skip TUI session bookkeeping and known external log files
            if session_prefix and (path == session_rel or path.startswith(session_prefix)):
                continue
            if path == "collab.log":
                continue
            full_path = self.repo_root / path
            if full_path.is_file():
                try:
                    content = full_path.read_bytes()
                    file_hash = hashlib.md5(content).hexdigest()
                except OSError:
                    content = b""
                    file_hash = ""
                result[path] = (file_hash, marker, content)
            elif "D" in marker:
                # File deleted: no longer on disk but still in git status.
                result[path] = ("", marker, None)
        return result

    def _compute_turn_delta(
        self, pre_state: dict[str, tuple[str, str, bytes | None]]
    ) -> dict[str, str]:
        """Return a diff map showing exactly what changed during this turn.

        Pre-turn content is captured in pre_state so diffs are scoped to the turn,
        not to all uncommitted changes since the last commit.
        """
        post_state = self._capture_file_state()
        pre_hashes = {p: h for p, (h, _, _) in pre_state.items()}
        diff_map: dict[str, str] = {}
        for path, (post_hash, _marker, post_content) in post_state.items():
            if pre_hashes.get(path) == post_hash:
                continue
            pre_entry = pre_state.get(path)
            diff_text = self._build_turn_diff(path, pre_entry, post_content)
            if diff_text:
                diff_map[path] = diff_text
        # Untracked files deleted during the turn vanish from git status entirely —
        # detect them as pre_state entries absent from post_state.
        for path, pre_entry in pre_state.items():
            if path in post_state:
                continue
            _, pre_marker, _ = pre_entry
            if "?" in pre_marker:
                # Was untracked; now gone — show as deletion
                diff_text = self._build_turn_diff(path, pre_entry, None)
                if diff_text:
                    diff_map[path] = diff_text
        return diff_map

    def _build_turn_diff(
        self,
        path: str,
        pre_entry: tuple[str, str, bytes | None] | None,
        post_content: bytes | None,
    ) -> str:
        """Return a unified diff covering only what changed this turn."""
        pre_content: bytes | None = pre_entry[2] if pre_entry is not None else None

        # --- deleted file ---
        if post_content is None:
            if pre_content is not None:
                # Was untracked before the turn; show full deletion
                lines = pre_content.decode("utf-8", errors="replace").splitlines(keepends=True)
                header = f"--- a/{path}\n+++ /dev/null\n@@ -1,{len(lines)} +0,0 @@\n"
                body = "".join(f"-{ln}" if ln.endswith("\n") else f"-{ln}\n" for ln in lines)
                return header + body
            # Was a tracked file; git diff HEAD shows it
            r = subprocess.run(
                ["git", "diff", "HEAD", "--", path],
                cwd=self.repo_root, capture_output=True, text=True, check=False,
            )
            return r.stdout.strip()

        # --- file not in pre_state: new file or clean tracked file ---
        if pre_entry is None:
            # Try to get committed content for clean tracked files
            r = subprocess.run(
                ["git", "show", f"HEAD:{path}"],
                cwd=self.repo_root, capture_output=True, check=False,
            )
            if r.returncode == 0:
                pre_content = r.stdout  # committed bytes become pre-turn baseline
            else:
                # Truly new untracked file: show full addition
                lines = post_content.decode("utf-8", errors="replace").splitlines(keepends=True)
                n = len(lines)
                header = f"--- /dev/null\n+++ b/{path}\n@@ -0,0 +1,{n} @@\n"
                body = "".join(f"+{ln}" if ln.endswith("\n") else f"+{ln}\n" for ln in lines)
                return header + body

        # --- both pre and post available: exact per-turn delta ---
        pre_lines = (pre_content or b"").decode("utf-8", errors="replace").splitlines(keepends=True)
        post_lines = post_content.decode("utf-8", errors="replace").splitlines(keepends=True)
        return "".join(difflib.unified_diff(
            pre_lines, post_lines,
            fromfile=f"a/{path}", tofile=f"b/{path}",
        ))

    async def _update_pane_diff_strip(self, pane: str, diff_map: dict[str, str]) -> None:
        """Accumulate diff entries and trigger a full pane repaint.

        Each file change gets a stable integer index into turn_diff_entries[pane].
        The index (not the path) is stored in pane_history so that old [DIFF]
        entries always open the exact patch from that turn, even if the same
        file is edited again in a later turn.
        """
        if not diff_map:
            return
        for path in sorted(diff_map):
            idx = len(self.turn_diff_entries[pane])
            self.turn_diff_entries[pane].append((path, diff_map[path]))
            self.pane_history[pane].append(("diff", str(idx)))
        self._write_pane(cast(Literal["claude", "codex"], pane))

    def action_open_diff(self, pane: str, key: str) -> None:
        """Open the DiffModal for a clicked [DIFF] link in an agent's log.

        key is the string representation of the integer index into
        turn_diff_entries[pane], guaranteeing each click opens the exact patch
        from that turn regardless of later edits to the same file.
        """
        try:
            idx = int(key)
            entries = self.turn_diff_entries.get(pane, [])
            if 0 <= idx < len(entries):
                path, diff_text = entries[idx]
                self.push_screen(DiffModal(path, diff_text, self._active_palette))
        except (ValueError, IndexError):
            pass

    # ── Copy-button helpers ─────────────────────────────────────────────────

    def _copy_link(self, msg_id: str) -> Text:
        """Return a clickable ⎘ [copy] label that copies the message to clipboard."""
        t = Text()
        t.append(
            "  \u2398 [copy]",
            style=Style(
                color=self._active_palette.copy_link,
                bold=True,
                meta={"@click": f"app.copy_message('{msg_id}')"},
            ),
        )
        return t

    def action_copy_message(self, msg_id: str) -> None:
        """Copy a stored message to the system clipboard."""
        text = self._message_store.get(msg_id, "")
        if not text:
            return
        if self._copy_to_clipboard(text):
            self._refresh_status(extra="Copied!")
        else:
            self._refresh_status(extra="Copy failed — install xclip/xsel/pbcopy")

    def _copy_to_clipboard(self, text: str) -> bool:
        """Try available clipboard backends; return True on success."""
        backends: list[list[str]] = [
            ["xclip", "-selection", "clipboard"],
            ["xsel", "--clipboard", "--input"],
            ["pbcopy"],
            ["clip"],
        ]
        for cmd in backends:
            try:
                subprocess.run(
                    cmd,
                    input=text.encode("utf-8"),
                    check=True,
                    capture_output=True,
                    timeout=2,
                )
                return True
            except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
                continue
        return False

    # ── Slash-command autocomplete ──────────────────────────────────────────

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        if event.text_area.id == "master-input":
            self._update_completions(event.text_area.text)

    def _update_completions(self, text: str) -> None:
        stripped = text.strip()
        # Show palette only for a single-line slash prefix with no space yet
        if not stripped.startswith("/") or "\n" in stripped or " " in stripped:
            self._hide_completions()
            return
        prefix = stripped.lower()
        matches = [(cmd, desc) for cmd, desc in SLASH_COMMANDS if cmd.lower().startswith(prefix)]
        if not matches:
            self._hide_completions()
            return
        self._completions = matches
        self._completion_idx = 0  # Reset on every new filter pass
        self._render_completions()
        self.query_one("#master-input", MasterInput).completions_open = True

    def _render_completions(self) -> None:
        widget = self.query_one("#command-suggestions", Static)
        widget.display = True
        total = len(self._completions)
        columns = 2 if total > 10 else 1
        rows = (total + columns - 1) // columns
        cell_width = 18
        text = Text()
        for row in range(rows):
            for col in range(columns):
                idx = row + (col * rows)
                if idx >= total:
                    continue
                cmd, _desc = self._completions[idx]
                p = self._active_palette
                if idx == self._completion_idx:
                    text.append(f" {cmd:<{cell_width}}", style=p.completion_selected_style)
                else:
                    text.append(f" {cmd:<{cell_width}}", style=p.completion_normal_style)
                if col < columns - 1:
                    text.append("  ")
            if row < rows - 1:
                text.append("\n")
        selected_cmd, selected_desc = self._completions[self._completion_idx]
        p = self._active_palette
        text.append("\n")
        text.append(f" {selected_cmd} ", style=p.completion_selected_style)
        text.append(f" {selected_desc}", style=p.completion_desc_style)
        widget.update(text)

    def _hide_completions(self) -> None:
        self._completions = []
        self._completion_idx = 0
        try:
            self.query_one("#command-suggestions", Static).display = False
            self.query_one("#master-input", MasterInput).completions_open = False
        except Exception:
            pass

    def _accept_completion(self) -> None:
        if not self._completions:
            return
        cmd, _ = self._completions[self._completion_idx]
        # Commands that stand alone get no trailing space; others expect arguments
        standalone = {"/compare", "/approve", "/deny", "/status", "/save", "/exit", "/fresh", "/resume"}
        completed = cmd if cmd in standalone else cmd + " "
        input_widget = self.query_one("#master-input", MasterInput)
        input_widget.load_text(completed)
        input_widget.move_cursor((0, len(completed)))
        self._hide_completions()
        input_widget.focus()

    def on_master_input_navigate_completions(self, event: MasterInput.NavigateCompletions) -> None:
        if not self._completions:
            return
        self._completion_idx = (self._completion_idx + event.direction) % len(self._completions)
        self._render_completions()

    def on_master_input_accept_completion(self, _event: MasterInput.AcceptCompletion) -> None:
        self._accept_completion()

    def persist_state(self) -> None:
        self.config.session_dir.mkdir(parents=True, exist_ok=True)
        if not self.transcript_path.exists():
            self.transcript_path.write_text("# Collab Session Transcript\n\n", encoding="utf-8")
        self.state_path.write_text(json.dumps(asdict(self.state), indent=2), encoding="utf-8")
        self._debug(
            f"persist_state turn={self.state.turn_index} waiting={self.state.waiting_for_master} "
            f"collab={self.state.collaboration_active} next={self.state.next_speaker}"
        )

    def _start_fresh_session(self) -> None:
        self._debug("starting fresh session")
        self.startup_choice_pending = False
        self.state = SessionState(
            active_identity=self.state.active_identity,
            role=self.state.role,
            codex_role=self.state.codex_role,
            claude_role=self.state.claude_role,
            mode=None,
            turn_index=0,
            next_speaker="master",
            waiting_for_master=True,
            collaboration_active=False,
            stuck=False,
            session_log_path=str(self.transcript_path),
            startup_existing=False,
            resume_was_active=False,
        )
        self.pane_history = {"claude": [], "codex": []}
        self.active_message = {"claude": "", "codex": ""}
        self.active_text = {"claude": "", "codex": ""}
        self.active_speaker = {"claude": "Claude", "codex": "Codex"}
        self.latest_completed_reply = {"claude": "", "codex": ""}
        self.agent_busy = {"claude": False, "codex": False}
        self.pending_request_from = None
        self.pending_request_text = None
        self.turn_diff_entries = {"claude": [], "codex": []}
        self.chat_history = []
        self.transcript_path.write_text("# Collab Session Transcript\n\n", encoding="utf-8")
        self.persist_state()
        self.query_one("#chat-log", RichLog).clear()
        self.query_one("#chat-activity", Static).update("")
        self.query_one("#claude-log", RichLog).clear()
        self.query_one("#codex-log", RichLog).clear()
        self._write_chat("System", "Started fresh session.")
        self._write_system("claude", "Started fresh session.")
        self._write_system("codex", "Started fresh session.")
        self._refresh_status()
        self._write_chat("System", "Bootstrapping protocol — reading memory, scratchpad, rules...")
        self.run_worker(self._bootstrap_protocol(), exclusive=True)

    async def _resume_active_session(self) -> None:
        self._debug("resuming previously active collaboration")
        prompt = (
            "Resume the previous collaboration from where it left off. "
            "Continue the shared task without waiting for Master unless permission, access, or an impasse requires it."
        )
        self._write_transcript("System", prompt)
        self._write_chat("System", prompt)
        await self._dispatch_route(RouteCommand(kind="route", target="both", message=prompt))

    def _write_transcript(self, speaker: str, message: str) -> None:
        timestamp = self._timestamp()
        with self.transcript_path.open("a", encoding="utf-8") as handle:
            handle.write(f"## Turn {self.state.turn_index} - {timestamp}\n")
            handle.write(f"**Speaker:** {speaker}\n")
            handle.write("**Message:**\n")
            handle.write(f"{message}\n\n---\n\n")

    def _write_chat(self, speaker: str, message: str) -> None:
        """Append a message to the group chat log (left panel)."""
        chat = self.query_one("#chat-log", RichLog)
        timestamp = self._timestamp_short()
        self.chat_history.append((timestamp, speaker, message))
        self._msg_counter += 1
        msg_id = f"chat_{self._msg_counter}"
        self._message_store[msg_id] = message
        line = Text()
        line.append(f"[{timestamp}] ", style="dim")
        line.append_text(self._render_message_text(speaker, message))
        line.append_text(self._copy_link(msg_id))
        chat.write(line)

    def _write_pane(self, pane: Literal["claude", "codex"]) -> None:
        widget = self.query_one(f"#{pane}-log", RichLog)
        history = self.pane_history[pane]
        widget.clear()
        for index, (speaker, message) in enumerate(history):
            if speaker == "diff":
                # message is the string index into turn_diff_entries[pane]
                try:
                    idx = int(message)
                    path = self.turn_diff_entries[pane][idx][0]
                except (ValueError, IndexError):
                    path = message
                    idx = -1
                link_text = Text()
                link_text.append(
                    f"  \u25b6 [DIFF] {path}",
                    style=Style(
                        color=self._active_palette.diff_link,
                        bold=True,
                        meta={"@click": f"app.open_diff('{pane}','{idx}')"},
                    ),
                )
                widget.write(link_text)
            else:
                msg_id = f"{pane}_{index}"
                self._message_store[msg_id] = message
                rendered = self._render_message_text(speaker, message)
                rendered.append_text(self._copy_link(msg_id))
                widget.write(rendered)
            # Blank separator between entries — skip when the next entry is a
            # diff link (it belongs visually to the message above it).
            is_last = index == len(history) - 1
            if not is_last and history[index + 1][0] != "diff":
                widget.write(Text(""))
        current = self._render_active_message(pane)
        if current is not None:
            if history:
                widget.write(Text(""))
            widget.write(current)
        widget.scroll_end(animate=False)

    def _write_system(self, pane: Literal["claude", "codex"], message: str) -> None:
        self.pane_history[pane].append(("System", message))
        self._write_pane(pane)

    def _surface_master_request(self, speaker: str, message: str) -> None:
        if message.startswith("Master:"):
            request = message[len("Master:"):].strip() or "Requested Master attention."
            self._write_chat("System", f"{speaker} requested Master attention: {request}")
            self._refresh_status(extra=f"{speaker} requested Master")
            self.query_one("#master-input", MasterInput).focus()

    def _extract_master_request(self) -> tuple[str, str] | None:
        for pane in ("codex", "claude"):
            text = self.latest_completed_reply[pane].strip()
            if text.startswith("Master:"):
                return pane, text[len("Master:"):].strip()
        return None

    def _refresh_status(self, extra: str = "") -> None:
        status = self.query_one("#status", Static)
        suffix = f" | {extra}" if extra else ""
        status.update(f"{self._status_text()}{suffix}")

    def _refresh_activity_indicator(self) -> None:
        widget = self.query_one("#chat-activity", Static)
        busy_agents = [name.capitalize() for name, busy in self.agent_busy.items() if busy]
        if not busy_agents:
            widget.update(self._render_message_text("System", "Idle"))
            return
        label = self._working_label()
        agents = ", ".join(busy_agents)
        widget.update(self._render_message_text("System", f"{label} {agents}"))

    def _status_text(self) -> str:
        busy_agents = ",".join(name for name, busy in self.agent_busy.items() if busy) or "-"
        return (
            f"codex={self.state.codex_role} "
            f"| claude={self.state.claude_role} "
            f"| cls={self.state.instruction_class or '-'} "
            f"| mode={self.state.mode or '-'} "
            f"| turn={self.state.turn_index} "
            f"| approvals={self.pending_approvals} "
            f"| stuck={self.state.stuck} "
            f"| bootstrapped={self.state.protocol_bootstrapped} "
            f"| cmp={self.state.comparison_round} "
            f"| auto={self.state.auto_turn_count}/{self.max_auto_turns} "
            f"| busy={busy_agents}"
        )

    def _handle_decision_command(self, payload: str) -> None:
        parts = [part.strip() for part in payload.split("|")]
        if len(parts) != 4:
            self._write_system("codex", "Usage: /decision D-XXX | Title | Decision text | Rationale")
            return
        decision_id, title, decision_text, rationale = parts
        block = (
            f"\n## {decision_id} · {self._timestamp_date()} · {title}\n\n"
            f"**Decision:** {decision_text}\n\n"
            f"**Rationale:** {rationale}\n\n"
            "---\n"
        )
        self._insert_before_marker(self.config.memory_path, "\n---\n\n## Archive\n", block)
        msg = f"Logged {decision_id} to memory.md"
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_chat("System", msg)

    def _handle_topic_command(self, payload: str) -> None:
        parts = [part.strip() for part in payload.split("|")]
        if len(parts) != 4:
            self._write_system("codex", "Usage: /topic T-XXX | Title | Codex position | Claude position")
            return
        topic_id, title, codex_position, claude_position = parts
        topic_block = (
            f"\n## {topic_id} · {self._timestamp_date()} · {title}\n"
            "Status: OPEN · Turn: 0/3\n"
            f"Codex position: {codex_position}\n"
            f"Claude position: {claude_position}\n"
        )
        scratchpad = self.config.scratchpad_path.read_text(encoding="utf-8")
        if "## Active Topics\n\n*(none)*" in scratchpad:
            scratchpad = scratchpad.replace("## Active Topics\n\n*(none)*", f"## Active Topics\n{topic_block}")
        else:
            scratchpad = scratchpad.replace("\n---\n\n## Closed Topics\n", f"{topic_block}\n---\n\n## Closed Topics\n")
        self.config.scratchpad_path.write_text(scratchpad, encoding="utf-8")
        msg = f"Opened {topic_id} in scratchpad.md"
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_chat("System", msg)

    def _handle_resolve_topic_command(self, payload: str) -> None:
        parts = [part.strip() for part in payload.split("|")]
        if len(parts) != 2:
            self._write_system("codex", "Usage: /resolve-topic T-XXX | D-XXX")
            return
        topic_id, decision_id = parts
        scratchpad = self.config.scratchpad_path.read_text(encoding="utf-8")
        topic_marker = f"## {topic_id} · "
        start = scratchpad.find(topic_marker)
        if start == -1:
            self._write_system("codex", f"Topic {topic_id} not found in scratchpad.md")
            return
        next_topic = scratchpad.find("\n## ", start + 1)
        closed_section = scratchpad.find("\n---\n\n## Closed Topics\n")
        end = next_topic if next_topic != -1 and next_topic < closed_section else closed_section
        topic_block = scratchpad[start:end].rstrip()
        resolved_block = f"{topic_block}\nRESOLVED · Winner: All · → {decision_id} in memory.md\n"
        remaining = (scratchpad[:start] + scratchpad[end:]).replace(
            "## Active Topics\n\n\n---", "## Active Topics\n\n*(none)*\n\n---"
        )
        remaining = remaining.replace("## Active Topics\n\n---", "## Active Topics\n\n*(none)*\n\n---")
        remaining = remaining.replace("## Closed Topics\n*(none)*", f"## Closed Topics\n{resolved_block}")
        if "## Closed Topics\n*(none)*" not in scratchpad:
            remaining = remaining.replace("\n## Closed Topics\n", f"\n## Closed Topics\n{resolved_block}\n")
        self.config.scratchpad_path.write_text(remaining, encoding="utf-8")
        msg = f"Resolved {topic_id} into {decision_id}"
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_chat("System", msg)

    def _timestamp(self) -> str:
        return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")

    def _timestamp_short(self) -> str:
        return datetime.now(timezone.utc).astimezone().strftime("%H:%M:%S")

    def _timestamp_date(self) -> str:
        return datetime.now(timezone.utc).astimezone().date().isoformat()

    def _begin_stream(self, pane: Literal["claude", "codex"], speaker: str) -> None:
        self.agent_busy[pane] = True
        self.active_speaker[pane] = speaker
        self.active_text[pane] = ""
        self.active_message[pane] = ""
        self._write_pane(pane)
        self._refresh_activity_indicator()
        self._refresh_status()

    async def _consume_stream(
        self,
        pane: Literal["claude", "codex"],
        speaker: str,
        stream,
        final: bool,
        next_speaker: str,
    ) -> None:
        self._debug(f"_consume_stream start pane={pane} speaker={speaker}")
        failed = False
        stuck_hint = False
        exit_code = 0

        try:
            async for event in stream:
                self._apply_stream_event(event, pane)
                if event.kind == "session_started":
                    self._debug(f"{pane} session_started handle={event.session_handle}")
                    if pane == "claude":
                        self.state.claude_session_id = event.session_handle
                    else:
                        self.state.codex_resume_handle = event.session_handle
                    self.persist_state()
                elif event.kind == "text_delta":
                    self._debug(f"{pane} text_delta len={len(event.text)}")
                    self.active_text[pane] += event.text
                    self.active_message[pane] = self.active_text[pane]
                    self._write_pane(pane)
                elif event.kind == "message_completed":
                    self._debug(f"{pane} message_completed len={len(event.text)}")
                    if not self.active_text[pane] and event.text:
                        self.active_text[pane] = event.text
                    self.active_message[pane] = self.active_text[pane]
                    self._write_pane(pane)
                elif event.kind == "stderr":
                    self._debug(f"{pane} stderr={event.text!r}")
                    stuck_hint = stuck_hint or bool(event.text and STUCK_PATTERN.search(event.text))
                elif event.kind == "failed":
                    self._debug(f"{pane} failed exit={event.exit_code} text={event.text!r}")
                    failed = True
                    exit_code = event.exit_code or 1
                    stuck_hint = True
                    if not self.active_text[pane] and event.text:
                        self.active_text[pane] = event.text
                        self.active_message[pane] = self.active_text[pane]
                        self._write_pane(pane)
                elif event.kind == "completed":
                    self._debug(f"{pane} completed exit={event.exit_code}")
                    exit_code = event.exit_code or 0
        except asyncio.CancelledError:
            self._debug(f"_consume_stream cancelled pane={pane} speaker={speaker}")
            self.agent_busy[pane] = False
            self.active_text[pane] = ""
            self.active_message[pane] = ""
            self.pane_history[pane].append(("System", f"{speaker} cancelled by Master."))
            self._write_pane(pane)
            self._refresh_activity_indicator()
            self.state.last_speaker = "master"
            self.state.collaboration_active = False
            self.state.waiting_for_master = True
            self.state.next_speaker = "master"
            self.persist_state()
            self._refresh_status(extra=f"{speaker} cancelled")
            raise

        message = self.active_text[pane].strip() or f"{speaker} returned no text."
        self.latest_completed_reply[pane] = message
        self.state.last_speaker = pane
        self.agent_busy[pane] = False
        self.pane_history[pane].append((speaker, message))
        self.active_text[pane] = ""
        self.active_message[pane] = ""
        self._write_pane(pane)
        self._refresh_activity_indicator()
        self._write_transcript(speaker, message)
        self._write_chat(speaker, message)
        self._surface_master_request(speaker, message)

        self.state.waiting_for_master = final
        self.state.next_speaker = next_speaker
        self.state.stuck = self.state.stuck or stuck_hint or failed or not message.strip()
        self.persist_state()
        self._refresh_status(extra=f"{speaker} exit={exit_code}")
        self._debug(f"_consume_stream complete pane={pane} speaker={speaker} exit={exit_code}")

    def _tick_working_indicator(self) -> None:
        if not any(self.agent_busy.values()):
            return
        self.working_phase = (self.working_phase + 1) % 4
        self._refresh_activity_indicator()
        for pane, busy in self.agent_busy.items():
            if busy:
                self._write_pane(cast(Literal["claude", "codex"], pane))

    def _working_label(self) -> str:
        dots = "." * (self.working_phase + 1)
        return f"Working{dots}"

    def _render_active_message(self, pane: Literal["claude", "codex"]) -> Text | None:
        if not self.agent_busy[pane]:
            if not self.active_message[pane]:
                return None
            return self._render_message_text(self.active_speaker[pane], self.active_message[pane])
        speaker = self.active_speaker[pane]
        label = self._working_label()
        text = self.active_text[pane].rstrip()
        message = Text()
        message.append_text(self._speaker_label(speaker))
        if text:
            message.append(text)
            message.append("\n")
            message.append(label, style="bold white")
            return message
        message.append(label, style="bold white")
        return message

    def _render_message_text(self, speaker: str, message: str) -> Text:
        text = Text()
        speaker_name = speaker.rstrip(":")
        if speaker_name.lower() == "stderr":
            text.append("stderr: ", style="bold black on khaki1")
            text.append(message, style="black on light_goldenrod1")
            return text
        if speaker_name.lower() == "system":
            style = self._system_message_style(message)
            text.append("System: ", style=style)
            text.append(message, style=style)
            return text
        if speaker_name.lower() == "tool":
            # Operational trace: tool calls, shell runs, file edits — rendered dim/inline
            tc = self._active_palette.tool_text
            text.append("  ", style=f"dim {tc}")
            text.append(message, style=f"dim {tc}")
            return text
        text.append_text(self._speaker_label(speaker_name))
        text.append(message)
        return text

    def _speaker_label(self, speaker: str) -> Text:
        normalized = speaker.rstrip(":").lower()
        p = self._active_palette
        styles = {
            "claude": p.claude_style,
            "codex": p.codex_style,
            "master": p.master_style,
            "system": "bold black on white",
        }
        label = speaker.rstrip(":").capitalize() if normalized != "codex" else "Codex"
        if normalized == "claude":
            label = "Claude"
        elif normalized == "master":
            label = "Master"
        elif normalized == "system":
            label = "System"
        return Text(f"{label}: ", style=styles.get(normalized, "bold white"))

    def _system_message_style(self, message: str) -> str:
        lowered = message.lower()
        if any(
            keyword in lowered
            for keyword in ("error", "failed", "stuck", "paused", "stop", "not found", "usage:", "waiting for master")
        ):
            return "bold white on red"
        return "bold black on white"

    def _apply_stream_event(self, event: StreamEvent, pane: Literal["claude", "codex"]) -> None:
        if event.kind == "stderr" and event.text:
            self.pane_history[pane].append(("stderr", event.text))
            self._write_pane(pane)
        elif event.kind == "tool_event" and event.text:
            # Visual-only: tool calls, shell runs, file edits.
            # Not accumulated into active_text so relay text stays clean.
            self.pane_history[pane].append(("tool", event.text))
            self._write_pane(pane)

    def _mode_requires_comparison(self, mode_value: str) -> bool:
        lowered = mode_value.strip().lower()
        return lowered.startswith("analysis") or lowered.startswith("diff") or lowered.startswith("file")

    async def _run_collaboration_loop(self) -> None:
        self._debug("_run_collaboration_loop start")
        while self.state.collaboration_active:
            # On the very first relay iteration, skip the WAITING_FOR_MASTER sentinel so
            # both agents get at least one chance to see each other's initial response
            # before the loop can exit.  "Master:" prefix and stuck patterns still pause
            # immediately (genuine requests, not completion signals).
            first_relay = self.state.auto_turn_count == 0
            if self._should_pause_for_master(skip_waiting_sentinel=first_relay):
                self._debug("collaboration loop pausing for Master")
                result = self._extract_master_request()
                if result:
                    pane, request_text = result
                    self.pending_request_from = pane
                    self.pending_request_text = request_text
                    self.pending_approvals += 1
                    self._write_chat("System", f"[APPROVAL REQUIRED from {pane}] {request_text}")
                self.state.collaboration_active = False
                self.state.waiting_for_master = True
                self.state.next_speaker = "master"
                self.persist_state()
                self._refresh_status()
                self._write_chat(
                    "System",
                    "Agents have completed their exchange — send a new instruction to continue.",
                )
                return

            if not self.latest_completed_reply["codex"].strip() or not self.latest_completed_reply["claude"].strip():
                self._debug("collaboration loop missing latest replies")
                self.state.waiting_for_master = True
                self.state.next_speaker = "master"
                self.persist_state()
                self._refresh_status()
                return

            if self.state.auto_turn_count >= self.max_auto_turns:
                self._debug("collaboration loop hit max auto turns")
                self.state.collaboration_active = False
                self.state.waiting_for_master = True
                self.state.next_speaker = "master"
                msg = (
                    f"Auto-collaboration paused after {self.max_auto_turns} relay turns. "
                    "Send a new instruction or @both to continue."
                )
                self._write_system("codex", msg)
                self._write_system("claude", msg)
                self._write_chat("System", msg)
                self.persist_state()
                self._refresh_status()
                return

            target = "codex" if self.state.last_speaker == "claude" else "claude"
            prompt = self._build_collaboration_prompt(target)
            self.state.auto_turn_count += 1
            self._debug(f"collaboration relay target={target} auto_turn={self.state.auto_turn_count}")
            self._write_transcript("System", prompt)
            if target == "codex":
                await self._invoke_codex(prompt, final=False, next_speaker="claude")
            else:
                await self._invoke_claude(prompt, final=False, next_speaker="codex")
        self._debug("_run_collaboration_loop complete")

    def _handle_export_command(self, args: str) -> None:
        """Handle /export <pane> <filename> — write pane text to a file."""
        parts = args.split(None, 1)
        if len(parts) != 2:
            self._write_chat("System", "Usage: /export <claude|codex|master> <filename>")
            return
        pane_name, filename = parts[0].lower(), parts[1].strip()
        if pane_name not in ("claude", "codex", "master"):
            self._write_chat("System", "Usage: /export <claude|codex|master> <filename>")
            return

        output_path = (self.repo_root / filename).resolve()
        lines: list[str] = []
        header_label = {"claude": "Claude Pane", "codex": "Codex Pane", "master": "Master Chat"}[pane_name]
        lines.append(f"=== {header_label} Export ===")
        lines.append(f"Exported: {self._timestamp()}")
        lines.append("")

        if pane_name == "master":
            for ts, speaker, message in self.chat_history:
                lines.append(f"[{ts}] {speaker}: {message}")
                lines.append("")
        else:
            for speaker, message in self.pane_history[pane_name]:
                lines.append(f"{speaker}: {message}")
                lines.append("")

        try:
            output_path.write_text("\n".join(lines), encoding="utf-8")
            rel = self._display_path(output_path)
            self._write_chat("System", f"Exported {header_label} to {rel}")
        except OSError as exc:
            self._write_chat("System", f"Export failed: {exc}")

    def _apply_theme(self, name: str) -> None:
        """Switch to a named TuiPalette, persist the choice, and repaint all panes."""
        palette = THEMES.get(name)
        if palette is None:
            available = ", ".join(THEMES)
            self._write_chat("System", f"Unknown theme '{name}'. Available: {available}")
            return
        self._active_palette = palette
        try:
            AppSettings.save_theme(self.config.settings_path, name)
        except OSError as exc:
            self._write_chat("System", f"Theme set but could not persist to settings.toml: {exc}")
        for pane in ("claude", "codex"):
            self._write_pane(cast(Literal["claude", "codex"], pane))
        self._write_chat("System", f"Theme switched to '{name}' (persisted to settings.toml).")

    def _should_pause_for_master(self, skip_waiting_sentinel: bool = False) -> bool:
        for pane in ("codex", "claude"):
            text = self.latest_completed_reply[pane].strip()
            if not text:
                continue
            if text.startswith("Master:"):
                return True
            if not skip_waiting_sentinel and text.upper() == "WAITING_FOR_MASTER":
                return True
            if STUCK_PATTERN.search(text):
                return True
        return False

    def _format_prior_replies(self, replies: list[tuple[str, str]]) -> str:
        """Format prior agents' replies for sequential conditioning in dispatch."""
        if not replies:
            return ""
        parts = [f"\n\n{name} replied:\n{text}" for name, text in replies]
        return "".join(parts)

    def _build_collaboration_prompt(self, target: str) -> str:
        if target == "codex":
            target_name, target_role = "Codex", self.state.codex_role
            other_name, other_role = "Claude", self.state.claude_role
            other_text = self.latest_completed_reply["claude"]
        else:
            target_name, target_role = "Claude", self.state.claude_role
            other_name, other_role = "Codex", self.state.codex_role
            other_text = self.latest_completed_reply["codex"]

        return (
            f"Continue the current collaboration session. {self._role_preamble(target_name, target_role)} "
            f"{other_name} (role: {other_role}) just replied. Respond directly to advance the shared task. "
            "Do not wait for Master unless you need permission/access, there is an impasse, or Master intervention is required. "
            "If you need Master, start your reply with `Master:`. "
            "If you are done and waiting for Master, reply exactly `WAITING_FOR_MASTER`.\n\n"
            f"{other_name}'s latest reply:\n{other_text}"
        )

    async def _run_comparison_round(self) -> None:
        self._debug("_run_comparison_round start")
        codex_text = self.latest_completed_reply["codex"].strip()
        claude_text = self.latest_completed_reply["claude"].strip()
        if not codex_text or not claude_text:
            self._write_system("codex", "Comparison skipped: both latest agent replies are required.")
            self._debug("_run_comparison_round skipped due to missing replies")
            return

        self.state.comparison_round += 1
        self.persist_state()
        round_num = self.state.comparison_round

        codex_prompt = self._build_comparison_prompt("Codex", "Codex", codex_text, "Claude", claude_text, round_num)
        claude_prompt = self._build_comparison_prompt("Claude", "Claude", claude_text, "Codex", codex_text, round_num)
        self._write_transcript("Master", codex_prompt)
        await self._invoke_codex(codex_prompt, final=False, next_speaker="claude")
        self._write_transcript("Master", claude_prompt)
        await self._invoke_claude(claude_prompt, final=True, next_speaker="master")
        self._debug(f"_run_comparison_round complete round={round_num}")

    def _comparison_resolved(self) -> bool:
        resolved = "All compared points resolved."
        return any(self.latest_completed_reply[pane].strip() == resolved for pane in ("codex", "claude"))

    async def _run_bounded_comparison_loop(self, max_rounds: int = 3) -> bool:
        for _ in range(max_rounds):
            await self._run_comparison_round()
            if self._comparison_resolved():
                return True
            if self._should_pause_for_master():
                return False

        self.state.waiting_for_master = True
        self.state.next_speaker = "master"
        self.persist_state()
        msg = (
            f"Comparison unresolved after {max_rounds} rounds. "
            "Pause and open a scratchpad topic or ask Master for direction."
        )
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_chat("System", msg)
        self._refresh_status()
        return False

    def _build_comparison_prompt(
        self,
        target_name: str,
        own_name: str,
        own_text: str,
        other_name: str,
        other_text: str,
        round_num: int,
    ) -> str:
        return (
            f"Master comparison round {round_num}. You are {target_name}. "
            f"Compare your latest response against {other_name}'s latest response point by point. "
            f"Respond only with Point {round_num} unless all compared points are already resolved. "
            "State agreement or disagreement clearly. If disagreement remains, give the tighter technical position. "
            "If everything relevant is already resolved, reply exactly: All compared points resolved.\n\n"
            f"{own_name} latest response:\n{own_text}\n\n"
            f"{other_name} latest response:\n{other_text}"
        )

    def _handle_decide_command(self, text: str) -> None:
        """Auto-number and write a D-XXX decision directly to memory.md."""
        content = self.config.memory_path.read_text(encoding="utf-8")
        nums = [int(m.group(1)) for m in re.finditer(r"## D-(\d+) ·", content)]
        next_num = max(nums, default=0) + 1
        decision_id = f"D-{next_num:03d}"
        block = (
            f"\n## {decision_id} · {self._timestamp_date()} · {text}\n\n"
            f"**Decision:** {text}\n\n"
            "**Rationale:** Logged by Master via `decide` instruction.\n\n"
            "---\n"
        )
        self._insert_before_marker(self.config.memory_path, "\n---\n\n## Archive\n", block)
        msg = f"Logged {decision_id} to memory.md"
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_chat("System", msg)

    async def _run_instruction_flow(self, command: RouteCommand) -> None:
        kind = command.kind
        target = command.message
        settled = True
        self._refresh_status(extra=f"running {kind}")
        if kind == "fix":
            await self._run_fix_flow(target)
        elif kind == "audit":
            settled = await self._run_audit_flow(target)
        elif kind == "feature":
            await self._run_feature_flow(target)
        elif kind == "refactor":
            await self._run_refactor_flow(target)
        elif kind == "analyze":
            settled = await self._run_analyze_flow(target)
        elif kind == "decide":
            self._handle_decide_command(target)
        self.state.instruction_class = None
        self.state.waiting_for_master = True
        self.state.next_speaker = "master"
        self.persist_state()
        self._refresh_status()
        if settled:
            self._write_chat("System", f"{kind} flow complete — review agent replies and use /decision or /compare as needed.")
        else:
            self._write_chat("System", f"{kind} flow paused — unresolved after comparison rounds; use scratchpad or ask Master.")

    async def _run_fix_flow(self, target: str) -> None:
        """fix: Claude isolates → Codex patches → Claude reviews → sign-off."""
        self._write_chat("System", f"[fix] 1/3 Claude isolating: {target}")
        isolate_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            f"Analyze this bug/regression: {target}\n"
            "Identify root cause, affected files/functions, and exact fix needed. "
            "Be specific. Output a fix plan Codex can act on directly."
        )
        await self._invoke_claude(isolate_prompt, final=False, next_speaker="codex")
        claude_analysis = self.latest_completed_reply["claude"]

        self._write_chat("System", "[fix] 2/3 Codex applying patch...")
        patch_prompt = (
            f"{self._role_preamble('Codex', self.state.codex_role)} "
            "Apply the following fix plan. Make the minimal safe change. "
            "Describe what you changed and why.\n\n"
            f"Claude's fix plan:\n{claude_analysis}"
        )
        await self._invoke_codex(patch_prompt, final=False, next_speaker="claude")
        codex_patch = self.latest_completed_reply["codex"]

        self._write_chat("System", "[fix] 3/3 Claude reviewing patch...")
        review_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            "Review this patch against the original fix plan. "
            "State SIGN-OFF if correct, or list specific blockers.\n\n"
            f"Your fix plan:\n{claude_analysis}\n\n"
            f"Codex's patch:\n{codex_patch}"
        )
        await self._invoke_claude(review_prompt, final=True, next_speaker="master")

    async def _run_audit_flow(self, target: str) -> bool:
        """audit: Codex review + Claude independent analysis → compare."""
        self._write_chat("System", f"[audit] 1/3 Codex review: {target}")
        codex_prompt = (
            f"{self._role_preamble('Codex', self.state.codex_role)} "
            f"Run a security, quality, and risk review of: {target}\n"
            "List findings prioritized by severity (CRITICAL/HIGH/MEDIUM/LOW). "
            "If no findings, state explicitly: No findings."
        )
        await self._invoke_codex(codex_prompt, final=False, next_speaker="claude")

        self._write_chat("System", "[audit] 2/3 Claude independent analysis...")
        claude_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            f"Run an independent security, quality, and risk analysis of: {target}\n"
            "List findings prioritized by severity (CRITICAL/HIGH/MEDIUM/LOW). "
            "If no findings, state explicitly: No findings."
        )
        await self._invoke_claude(claude_prompt, final=False, next_speaker="codex")

        self._write_chat("System", "[audit] 3/3 Comparison round...")
        return await self._run_bounded_comparison_loop()

    async def _run_feature_flow(self, target: str) -> None:
        """feature: Claude designs → Codex implements → Claude reviews."""
        self._write_chat("System", f"[feature] 1/3 Claude designing: {target}")
        design_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            f"Design the implementation contract for: {target}\n"
            "Specify function signatures, data models, API contracts, edge cases, "
            "and acceptance criteria. Output a contract Codex can implement against directly."
        )
        await self._invoke_claude(design_prompt, final=False, next_speaker="codex")
        claude_design = self.latest_completed_reply["claude"]

        self._write_chat("System", "[feature] 2/3 Codex implementing...")
        impl_prompt = (
            f"{self._role_preamble('Codex', self.state.codex_role)} "
            "Implement the following design contract exactly. "
            "Describe what you built and note any deviations.\n\n"
            f"Claude's design contract:\n{claude_design}"
        )
        await self._invoke_codex(impl_prompt, final=False, next_speaker="claude")
        codex_impl = self.latest_completed_reply["codex"]

        self._write_chat("System", "[feature] 3/3 Claude reviewing implementation...")
        review_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            "Review this implementation against your design contract. "
            "State SIGN-OFF if it meets the contract, or list specific gaps/blockers.\n\n"
            f"Your design contract:\n{claude_design}\n\n"
            f"Codex's implementation:\n{codex_impl}"
        )
        await self._invoke_claude(review_prompt, final=True, next_speaker="master")

    async def _run_refactor_flow(self, target: str) -> None:
        """refactor: Claude maps call sites → Codex refactors → Claude verifies D-002."""
        self._write_chat("System", f"[refactor] 1/3 Claude mapping call sites: {target}")
        map_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            f"Map all call sites and dependencies for: {target}\n"
            "List every file, function, and caller that must be updated. "
            "Output a call-site map Codex can use as a refactoring checklist."
        )
        await self._invoke_claude(map_prompt, final=False, next_speaker="codex")
        claude_map = self.latest_completed_reply["claude"]

        self._write_chat("System", "[refactor] 2/3 Codex refactoring...")
        refactor_prompt = (
            f"{self._role_preamble('Codex', self.state.codex_role)} "
            f"Refactor {target} using the following call-site map as your checklist. "
            "Update every listed site. Describe what you changed.\n\n"
            f"Claude's call-site map:\n{claude_map}"
        )
        await self._invoke_codex(refactor_prompt, final=False, next_speaker="claude")
        codex_refactor = self.latest_completed_reply["codex"]

        self._write_chat("System", "[refactor] 3/3 Claude verifying D-002 bar...")
        verify_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            "Verify this refactoring meets the D-002 bar: logically stable codebase, "
            "no broken call sites, no dead state, no silently disconnected write-backs. "
            "State D-002 PASS or list specific failures.\n\n"
            f"Codex's refactoring:\n{codex_refactor}"
        )
        await self._invoke_claude(verify_prompt, final=True, next_speaker="master")

    async def _run_analyze_flow(self, target: str) -> bool:
        """analyze: Both produce independent positions → comparison round."""
        self._write_chat("System", f"[analyze] 1/3 Codex position: {target}")
        codex_prompt = (
            f"{self._role_preamble('Codex', self.state.codex_role)} "
            f"Analyze the following question and state your position clearly: {target}\n"
            "Be specific. Give your strongest technical argument."
        )
        await self._invoke_codex(codex_prompt, final=False, next_speaker="claude")

        self._write_chat("System", "[analyze] 2/3 Claude independent position...")
        claude_prompt = (
            f"{self._role_preamble('Claude', self.state.claude_role)} "
            f"Analyze the following question and state your position clearly: {target}\n"
            "Be specific. Give your strongest technical argument."
        )
        await self._invoke_claude(claude_prompt, final=False, next_speaker="codex")

        self._write_chat("System", "[analyze] 3/3 Comparison round 1...")
        return await self._run_bounded_comparison_loop()

    def _insert_before_marker(self, path: Path, marker: str, block: str) -> None:
        content = path.read_text(encoding="utf-8")
        if marker not in content:
            raise ValueError(f"Marker not found in {path}")
        updated = content.replace(marker, f"{block}\n{marker}", 1)
        path.write_text(updated, encoding="utf-8")

    async def _bootstrap_protocol(self) -> None:
        self._debug("_bootstrap_protocol start")
        memory_path = self._display_path(self.config.memory_path)
        scratchpad_path = self._display_path(self.config.scratchpad_path)
        rules_path = self._display_path(self.config.rules_path)
        prompts = [
            (
                "codex",
                "Codex",
                (
                    f"I am Master. Read {memory_path}, {scratchpad_path}, "
                    f"{rules_path}. {self._role_preamble('Codex', self.state.codex_role)} "
                    "Summarize current state and wait for session instruction."
                ),
            ),
            (
                "claude",
                "Claude",
                (
                    f"I am Master. Read {memory_path}, {scratchpad_path}, "
                    f"{rules_path}. {self._role_preamble('Claude', self.state.claude_role)} "
                    "Summarize current state and wait for session instruction."
                ),
            ),
        ]
        for index, (pane, speaker, prompt) in enumerate(prompts):
            final = index == len(prompts) - 1
            next_speaker = "master" if final else prompts[index + 1][0]
            self._write_transcript("Master", prompt)
            self._write_chat("Master", f"[Bootstrap] {speaker}: {prompt[:80]}...")
            if pane == "codex":
                await self._invoke_codex(prompt, final=final, next_speaker=next_speaker)
            else:
                await self._invoke_claude(prompt, final=final, next_speaker=next_speaker)
        self.state.protocol_bootstrapped = True
        self.persist_state()
        self._refresh_status()
        self._write_chat(
            "System",
            "Bootstrap complete. Instructions: "
            "/fix <bug> | /audit <target> | /feature <desc> | "
            "/refactor <target> | /analyze <question> | /decide <text>",
        )
        self._debug("_bootstrap_protocol complete")

    async def _broadcast_mode(self, mode_value: str) -> None:
        self._debug(f"_broadcast_mode {mode_value!r}")
        prompt = f"mode: {mode_value}"
        self._write_chat("System", f"Broadcasting {prompt}")
        self._write_system("codex", f"Broadcasting {prompt}")
        self._write_system("claude", f"Broadcasting {prompt}")
        await self._invoke_codex(prompt, final=False, next_speaker="claude")
        await self._invoke_claude(prompt, final=True, next_speaker="master")

    async def _broadcast_role(self, role_value: str) -> None:
        self._debug(f"_broadcast_role {role_value!r}")
        codex_role, claude_role = self._parse_role_value(role_value)
        self.state.codex_role = codex_role
        self.state.claude_role = claude_role
        self.persist_state()
        memory_path = self._display_path(self.config.memory_path)
        scratchpad_path = self._display_path(self.config.scratchpad_path)
        rules_path = self._display_path(self.config.rules_path)
        codex_prompt = (
            f"Master role reassignment. Read {memory_path}, {scratchpad_path}, "
            f"{rules_path}. {self._role_preamble('Codex', codex_role)} "
            "Acknowledge role and continue collaboration when instructed."
        )
        claude_prompt = (
            f"Master role reassignment. Read {memory_path}, {scratchpad_path}, "
            f"{rules_path}. {self._role_preamble('Claude', claude_role)} "
            "Acknowledge role and continue collaboration when instructed."
        )
        msg = f"Broadcasting role codex={codex_role} claude={claude_role}"
        self._write_chat("System", msg)
        self._write_system("codex", msg)
        self._write_system("claude", msg)
        self._write_transcript("Master", codex_prompt)
        await self._invoke_codex(codex_prompt, final=False, next_speaker="claude")
        self._write_transcript("Master", claude_prompt)
        await self._invoke_claude(claude_prompt, final=True, next_speaker="master")

    def _parse_role_value(self, value: str) -> tuple[str, str]:
        parts = value.split()
        if len(parts) >= 3 and parts[0].lower() in {"both", "codex", "claude"}:
            target = parts[0].lower()
            remainder = " ".join(parts[1:]).strip()
            if target == "both":
                return remainder, remainder
            if target == "codex":
                return remainder, self.state.claude_role
            return self.state.codex_role, remainder
        if "|" in value:
            left, right = [part.strip() for part in value.split("|", 1)]
            if left and right:
                return left, right
        return value.strip(), value.strip()

    def _debug(self, message: str) -> None:
        try:
            self.debug_log_path.parent.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
            with self.debug_log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"{timestamp} {message}\n")
        except Exception:
            pass


def load_or_create_state(
    config: ProjectConfig,
    identity: str,
    role: str,
    codex_role: str | None = None,
    claude_role: str | None = None,
) -> SessionState:
    state_path = config.session_dir / "state.json"
    transcript_path = config.session_dir / "current.md"
    config.session_dir.mkdir(parents=True, exist_ok=True)
    if state_path.exists():
        payload = json.loads(state_path.read_text(encoding="utf-8"))
        had_existing = bool(payload.get("protocol_bootstrapped") or payload.get("turn_index", 0) > 0)
        resume_was_active = bool(payload.get("collaboration_active") and not payload.get("waiting_for_master", True))
        payload.setdefault("codex_role", payload.get("role", role))
        payload.setdefault("claude_role", payload.get("role", role))
        payload.setdefault("collaboration_active", False)
        payload.setdefault("auto_turn_count", 0)
        payload.setdefault("last_speaker", "master")
        payload.setdefault("instruction_class", None)
        payload.setdefault("startup_existing", had_existing)
        payload.setdefault("resume_was_active", resume_was_active)
        state = SessionState(**payload)
        state.active_identity = identity
        state.role = role
        state.codex_role = codex_role or state.codex_role
        state.claude_role = claude_role or state.claude_role
        state.startup_existing = had_existing
        state.resume_was_active = resume_was_active
        state.stuck = False
        state.waiting_for_master = True
        state.collaboration_active = False
        state.next_speaker = "master"
        state.auto_turn_count = 0
        state.instruction_class = None
        # Do NOT force protocol_bootstrapped — let on_mount decide based on turn_index
        return state

    state = SessionState(
        active_identity=identity,
        role=role,
        codex_role=codex_role or role,
        claude_role=claude_role or role,
        mode=None,
        turn_index=0,
        next_speaker="master",
        waiting_for_master=True,
        collaboration_active=False,
        stuck=False,
        session_log_path=str(transcript_path),
        startup_existing=False,
        resume_was_active=False,
    )
    state_path.write_text(json.dumps(asdict(state), indent=2), encoding="utf-8")
    if not transcript_path.exists():
        transcript_path.write_text("# Collab Session Transcript\n\n", encoding="utf-8")
    return state
