"""
Tests for collaboration handoff and Codex incomplete reply handling.

Scenario 1 — Handoff collaboration:
  When @both dispatches Codex (implementer) then Claude (reviewer),
  Claude's prompt must include Codex's completed reply as sequential
  conditioning. The first agent must receive no prior-reply block.

Scenario 2 — Codex incomplete reply:
  When Codex's stream yields no text content, the fallback message is
  recorded. When it yields a `failed` event, stuck is set. tool_event
  entries must never leak into the relay text.
"""
from __future__ import annotations

import types
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from akritrim_colab.agents.stream_events import StreamEvent
from akritrim_colab.app import CollabApp, RouteCommand, SessionState, THEMES
from akritrim_colab.config import ProjectConfig


# ── Helpers ───────────────────────────────────────────────────────────────────

def _state(**overrides) -> SessionState:
    defaults = dict(
        active_identity="claude",
        role="collaborator",
        codex_role="implementer",
        claude_role="reviewer",
        mode=None,
        turn_index=1,
        next_speaker="both",
        waiting_for_master=False,
        collaboration_active=False,  # keep dispatch tests isolated
        stuck=False,
        session_log_path="",
    )
    defaults.update(overrides)
    return SessionState(**defaults)


def _config(tmp_path: Path) -> ProjectConfig:
    (tmp_path / "session").mkdir(parents=True)
    (tmp_path / "session" / "current.md").write_text("# Transcript\n\n")
    return ProjectConfig(
        project_root=tmp_path,
        memory_path=tmp_path / "memory.md",
        scratchpad_path=tmp_path / "scratchpad.md",
        rules_path=tmp_path / "rules.md",
        session_dir=tmp_path / "session",
        settings_path=tmp_path / "settings.toml",
    )


def _fake_app(tmp_path: Path, **state_overrides) -> types.SimpleNamespace:
    """Minimal namespace with attributes needed by _consume_stream and _dispatch_route."""
    config = _config(tmp_path)
    state = _state(**state_overrides)
    app = types.SimpleNamespace()
    app.state = state
    app.config = config
    app.transcript_path = config.session_dir / "current.md"
    app.state_path = config.session_dir / "state.json"
    # Agent runtime state
    app.latest_completed_reply = {"claude": "", "codex": ""}
    app.active_text = {"claude": "", "codex": ""}
    app.active_message = {"claude": "", "codex": ""}
    app.active_speaker = {"claude": "Claude", "codex": "Codex"}
    app.pane_history = {"claude": [], "codex": []}
    app.agent_busy = {"claude": False, "codex": False}
    # Silence all Textual / UI calls
    app._write_pane = MagicMock()
    app._refresh_status = MagicMock()
    app._refresh_activity_indicator = MagicMock()
    app._write_chat = MagicMock()
    app._write_transcript = MagicMock()
    app._surface_master_request = MagicMock()
    app._debug = MagicMock()
    app.persist_state = MagicMock()
    # Bind pure helpers that only touch state / pane_history, not Textual widgets
    app._apply_stream_event = lambda e, p: CollabApp._apply_stream_event(app, e, p)
    app._role_constraint = lambda role: CollabApp._role_constraint(app, role)
    app._role_preamble = lambda n, r: CollabApp._role_preamble(app, n, r)
    app._format_prior_replies = lambda rs: CollabApp._format_prior_replies(app, rs)
    return app


async def _stream(*events: StreamEvent):
    """Async generator yielding a fixed sequence of StreamEvents. Pass no args for empty."""
    for event in events:
        yield event


# ── Scenario 1: Handoff collaboration ─────────────────────────────────────────

class TestHandoff:
    """Sequential dispatch — second agent receives first agent's completed reply."""

    @pytest.mark.asyncio
    async def test_codex_runs_first_when_codex_is_implementer(self, tmp_path):
        """Dispatch order: codex_role=implementer → Codex before Claude."""
        app = _fake_app(tmp_path, codex_role="implementer", claude_role="reviewer")
        call_order: list[str] = []

        async def mock_codex(msg, final, next_speaker):
            call_order.append("codex")
            app.latest_completed_reply["codex"] = "codex done"

        async def mock_claude(msg, final, next_speaker):
            call_order.append("claude")

        app._invoke_codex = mock_codex
        app._invoke_claude = mock_claude
        app._run_collaboration_loop = AsyncMock()

        await CollabApp._dispatch_route(
            app, RouteCommand(kind="route", target="both", message="Implement X.")
        )

        assert call_order == ["codex", "claude"], (
            f"Expected codex first, got {call_order}"
        )

    @pytest.mark.asyncio
    async def test_second_agent_receives_first_agent_reply(self, tmp_path):
        """Claude's prompt includes Codex's completed reply as conditioning."""
        app = _fake_app(tmp_path, codex_role="implementer", claude_role="reviewer")
        codex_reply = "I've applied the patch to auth.py."
        captured_claude_msg: list[str] = []

        async def mock_codex(msg, final, next_speaker):
            app.latest_completed_reply["codex"] = codex_reply

        async def mock_claude(msg, final, next_speaker):
            captured_claude_msg.append(msg)

        app._invoke_codex = mock_codex
        app._invoke_claude = mock_claude
        app._run_collaboration_loop = AsyncMock()

        await CollabApp._dispatch_route(
            app, RouteCommand(kind="route", target="both", message="Fix the login bug.")
        )

        assert captured_claude_msg, "Claude was never invoked"
        assert codex_reply in captured_claude_msg[0], (
            "Claude's prompt must contain Codex's completed reply"
        )
        assert "Codex replied:" in captured_claude_msg[0], (
            "Prior-reply block must have the 'Codex replied:' header"
        )

    @pytest.mark.asyncio
    async def test_first_agent_has_no_prior_conditioning(self, tmp_path):
        """The first dispatched agent gets no prior-reply block."""
        app = _fake_app(tmp_path, codex_role="implementer", claude_role="reviewer")
        captured_codex_msg: list[str] = []

        async def mock_codex(msg, final, next_speaker):
            captured_codex_msg.append(msg)
            app.latest_completed_reply["codex"] = "codex reply"

        async def mock_claude(msg, final, next_speaker):
            pass

        app._invoke_codex = mock_codex
        app._invoke_claude = mock_claude
        app._run_collaboration_loop = AsyncMock()

        await CollabApp._dispatch_route(
            app, RouteCommand(kind="route", target="both", message="Task.")
        )

        assert " replied:" not in captured_codex_msg[0], (
            "First agent must not receive any prior-reply conditioning"
        )

    @pytest.mark.asyncio
    async def test_single_agent_target_skips_conditioning(self, tmp_path):
        """@claude target — Claude receives no prior-reply block."""
        app = _fake_app(tmp_path)
        captured: list[str] = []

        async def mock_claude(msg, final, next_speaker):
            captured.append(msg)

        app._invoke_claude = mock_claude
        app._run_collaboration_loop = AsyncMock()

        await CollabApp._dispatch_route(
            app, RouteCommand(kind="route", target="claude", message="Explain auth.py.")
        )

        assert captured, "Claude was never invoked"
        assert " replied:" not in captured[0]


# ── Scenario 2: Codex incomplete / failed reply ────────────────────────────────

class TestCodexIncompleteReply:
    """Stream-level handling of empty or failed Codex output."""

    @pytest.mark.asyncio
    async def test_empty_stream_sets_fallback_message(self, tmp_path):
        """No text events → fallback 'Codex returned no text.' is recorded."""
        app = _fake_app(tmp_path)

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(),
            final=True,
            next_speaker="master",
        )

        assert app.latest_completed_reply["codex"] == "Codex returned no text."

    @pytest.mark.asyncio
    async def test_empty_stream_clears_busy_flag(self, tmp_path):
        """agent_busy must be False after stream ends, even on empty stream."""
        app = _fake_app(tmp_path)
        app.agent_busy["codex"] = True

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(),
            final=True,
            next_speaker="master",
        )

        assert app.agent_busy["codex"] is False

    @pytest.mark.asyncio
    async def test_failed_event_sets_stuck_flag(self, tmp_path):
        """`failed` stream event must set state.stuck = True."""
        app = _fake_app(tmp_path)

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(
                StreamEvent(agent="codex", kind="failed", text="CLI exited 1", exit_code=1)
            ),
            final=True,
            next_speaker="master",
        )

        assert app.state.stuck is True

    @pytest.mark.asyncio
    async def test_failed_event_captures_error_text(self, tmp_path):
        """Error text from `failed` event becomes the completed reply."""
        app = _fake_app(tmp_path)
        error_text = "codex: command not found"

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(
                StreamEvent(agent="codex", kind="failed", text=error_text, exit_code=127)
            ),
            final=True,
            next_speaker="master",
        )

        assert app.latest_completed_reply["codex"] == error_text

    @pytest.mark.asyncio
    async def test_text_delta_accumulates_into_reply(self, tmp_path):
        """Multiple text_delta events are concatenated into the final reply."""
        app = _fake_app(tmp_path)

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(
                StreamEvent(agent="codex", kind="text_delta", text="Part 1. "),
                StreamEvent(agent="codex", kind="text_delta", text="Part 2."),
                StreamEvent(agent="codex", kind="message_completed", text=""),
                StreamEvent(agent="codex", kind="completed", exit_code=0),
            ),
            final=True,
            next_speaker="master",
        )

        assert app.latest_completed_reply["codex"] == "Part 1. Part 2."

    @pytest.mark.asyncio
    async def test_tool_events_do_not_pollute_relay_text(self, tmp_path):
        """tool_event entries appear in pane_history but must NOT enter latest_completed_reply."""
        app = _fake_app(tmp_path)

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(
                StreamEvent(agent="codex", kind="tool_event", text="⚙ edit(auth.py)"),
                StreamEvent(agent="codex", kind="text_delta", text="Done."),
                StreamEvent(agent="codex", kind="message_completed", text=""),
            ),
            final=True,
            next_speaker="master",
        )

        assert app.latest_completed_reply["codex"] == "Done."
        tool_entries = [e for e in app.pane_history["codex"] if e[0] == "tool"]
        assert len(tool_entries) == 1, "tool_event must appear in pane_history"

    @pytest.mark.asyncio
    async def test_empty_reply_recorded_in_pane_history(self, tmp_path):
        """Fallback message is appended to pane_history with the correct speaker."""
        app = _fake_app(tmp_path)

        await CollabApp._consume_stream(
            app,
            pane="codex",
            speaker="Codex",
            stream=_stream(),
            final=True,
            next_speaker="master",
        )

        assert ("Codex", "Codex returned no text.") in app.pane_history["codex"]


# ── Helpers for _write_pane tests ─────────────────────────────────────────────

def _fake_app_for_write_pane(tmp_path: Path) -> tuple[types.SimpleNamespace, MagicMock]:
    """Fake app that runs the real _write_pane with a mock RichLog widget.

    Returns (app, mock_widget) so tests can inspect widget.write() calls.
    """
    mock_widget = MagicMock()
    mock_widget.write = MagicMock()
    mock_widget.clear = MagicMock()
    mock_widget.scroll_end = MagicMock()

    app = types.SimpleNamespace()
    app.state = _state()
    app.pane_history = {"claude": [], "codex": []}
    # Indexed list of (path, diff_text) — each occurrence has a stable index.
    app.turn_diff_entries = {"claude": [], "codex": []}
    app.agent_busy = {"claude": False, "codex": False}
    app.active_text = {"claude": "", "codex": ""}
    app.active_message = {"claude": "", "codex": ""}
    app.active_speaker = {"claude": "Claude", "codex": "Codex"}
    app._message_store = {}
    app._active_palette = THEMES["akritrim"]
    app.query_one = lambda selector, widget_type=None: mock_widget
    # Bind all rendering helpers that _write_pane calls indirectly
    app._system_message_style = lambda m: CollabApp._system_message_style(app, m)
    app._speaker_label = lambda s: CollabApp._speaker_label(app, s)
    app._render_message_text = lambda s, m: CollabApp._render_message_text(app, s, m)
    app._copy_link = lambda mid: CollabApp._copy_link(app, mid)
    app._render_active_message = lambda p: None  # no active stream in these tests
    return app, mock_widget


def _written_texts(mock_widget: MagicMock) -> list[str]:
    """Collect plain string representations of all Text objects written to the widget."""
    results = []
    for call in mock_widget.write.call_args_list:
        arg = call.args[0] if call.args else None
        if arg is not None:
            results.append(str(arg))
    return results


# ── Scenario 3: Diff link repaint ─────────────────────────────────────────────

class TestDiffLinkRepaint:
    """
    Diff links must survive any full repaint of the pane widget AND each entry
    must always open the exact patch from its own turn.

    turn_diff_entries is a stable indexed list: index 0 is the first diff ever
    recorded, index 1 the second, etc.  pane_history stores ("diff", str(idx))
    so each link carries a permanent pointer that is unaffected by later edits
    to the same file.
    """

    @pytest.mark.asyncio
    async def test_update_diff_strip_stores_entry_and_calls_write_pane(self, tmp_path):
        """`_update_pane_diff_strip` must append to turn_diff_entries, add idx to pane_history, call _write_pane."""
        app = _fake_app(tmp_path)
        app.turn_diff_entries = {"claude": [], "codex": []}

        await CollabApp._update_pane_diff_strip(
            app, "codex", {"src/auth.py": "diff content"}
        )

        assert app.turn_diff_entries["codex"][0] == ("src/auth.py", "diff content")
        assert ("diff", "0") in app.pane_history["codex"]
        app._write_pane.assert_called_with("codex")

    @pytest.mark.asyncio
    async def test_update_diff_strip_accumulates_across_turns(self, tmp_path):
        """Successive calls accumulate entries; earlier entries are not lost."""
        app = _fake_app(tmp_path)
        app.turn_diff_entries = {"claude": [], "codex": []}

        await CollabApp._update_pane_diff_strip(app, "codex", {"file_a.py": "diff1"})
        await CollabApp._update_pane_diff_strip(app, "codex", {"file_b.py": "diff2"})

        paths = [p for p, _ in app.turn_diff_entries["codex"]]
        assert "file_a.py" in paths
        assert "file_b.py" in paths
        indices = [idx for spk, idx in app.pane_history["codex"] if spk == "diff"]
        assert "0" in indices
        assert "1" in indices

    @pytest.mark.asyncio
    async def test_same_file_edited_twice_has_distinct_indices(self, tmp_path):
        """Editing the same file in two turns creates two entries with distinct stable indices."""
        app = _fake_app(tmp_path)
        app.turn_diff_entries = {"claude": [], "codex": []}

        await CollabApp._update_pane_diff_strip(app, "codex", {"app.py": "first diff"})
        await CollabApp._update_pane_diff_strip(app, "codex", {"app.py": "second diff"})

        assert len(app.turn_diff_entries["codex"]) == 2
        assert app.turn_diff_entries["codex"][0] == ("app.py", "first diff")
        assert app.turn_diff_entries["codex"][1] == ("app.py", "second diff")
        diff_indices = [idx for spk, idx in app.pane_history["codex"] if spk == "diff"]
        assert len(diff_indices) == 2
        assert diff_indices[0] != diff_indices[1], "each occurrence must have a distinct index"

    def test_write_pane_emits_diff_links_from_pane_history(self, tmp_path):
        """`_write_pane` resolves [DIFF] path via index and writes a clickable link."""
        app, mock_widget = _fake_app_for_write_pane(tmp_path)
        app.turn_diff_entries["codex"].append(("src/auth.py", "--- a\n+++ b\n@@ -1 +1 @@\n-old\n+new"))
        app.pane_history["codex"].append(("diff", "0"))

        CollabApp._write_pane(app, "codex")

        written = _written_texts(mock_widget)
        assert any("[DIFF]" in t and "src/auth.py" in t for t in written), (
            f"Expected [DIFF] src/auth.py in written output, got: {written}"
        )

    def test_write_pane_emits_all_accumulated_diff_links(self, tmp_path):
        """All accumulated paths must be rendered, not just the most recent."""
        app, mock_widget = _fake_app_for_write_pane(tmp_path)
        app.turn_diff_entries["codex"] = [
            ("src/auth.py", "diff1"),
            ("src/models.py", "diff2"),
        ]
        app.pane_history["codex"].extend([
            ("diff", "0"),
            ("diff", "1"),
        ])

        CollabApp._write_pane(app, "codex")

        written = _written_texts(mock_widget)
        assert any("auth.py" in t for t in written), "auth.py link missing"
        assert any("models.py" in t for t in written), "models.py link missing"

    def test_write_pane_clears_then_repaints_so_no_duplication(self, tmp_path):
        """Calling _write_pane twice must not double the diff links."""
        app, mock_widget = _fake_app_for_write_pane(tmp_path)
        app.turn_diff_entries["codex"].append(("src/auth.py", "diff"))
        app.pane_history["codex"].append(("diff", "0"))

        CollabApp._write_pane(app, "codex")
        mock_widget.write.reset_mock()
        mock_widget.clear.reset_mock()
        CollabApp._write_pane(app, "codex")

        written = _written_texts(mock_widget)
        diff_writes = [t for t in written if "[DIFF]" in t and "auth.py" in t]
        assert len(diff_writes) == 1, (
            f"Expected exactly 1 diff link on second repaint, got {len(diff_writes)}: {diff_writes}"
        )
