# akritrim-colab

A three-pane collaboration TUI that puts you between Claude and Codex inside any repository. You direct, they implement and review.

> Requires [Claude CLI](https://docs.anthropic.com/en/docs/claude-code) and [Codex CLI](https://github.com/openai/codex) installed and authenticated.

## Install

```bash
pip install akritrim-colab
```

Or, for an isolated CLI install:

```bash
pipx install akritrim-colab
```

## Quick Start

```bash
cd /path/to/your-repo
akritrim-colab
```

On first run, collaboration files are scaffolded into `.collab/`. Then the TUI launches.

## Layout

| Pane | Contents |
|------|----------|
| Left | Shared session chat |
| Upper right | Claude |
| Lower right | Codex |
| Bottom | Master input |

Panes are resizable — drag the dividers between them.

## Input

| Key | Action |
|-----|--------|
| `Enter` | Send message |
| `Ctrl+Enter` | Insert newline |
| `Tab` | Accept autocomplete suggestion |
| `↑` / `↓` | Browse command history or navigate autocomplete |
| `Escape` | Cancel active agent work |
| `Ctrl+C` | Quit |

Type `/` to open the command autocomplete palette.

## Routing

Direct a message to a specific agent:

```
@claude propose a UI improvement
@codex review the current changes
@both compare these two approaches
```

Or use `/ask` for one-off direct messages:

```
/ask claude explain this function
/ask codex run the tests
/ask both what are the risks here
```

## Work Flows

Structured multi-agent flows that coordinate Claude and Codex automatically:

```
/fix <bug>           isolate → patch → review
/audit <target>      independent dual review + comparison
/feature <desc>      design → implement
/refactor <target>   map call sites → refactor → verify
/analyze <question>  dual analysis + position comparison
/decide <text>       log a decision to collaboration memory
```

## Session Commands

```
/fresh                   start a new session (clears history)
/resume                  resume from last saved state
/status                  show current session state
/save                    persist session state to disk
/exit                    exit the TUI
```

## Agent Control

```
/approve                 approve a pending agent request
/deny                    deny a pending agent request
/compare                 run a manual comparison round between agents
/mode <value>            broadcast a mode change to both agents
/role <target> <role>    reassign agent roles at runtime
```

Role targets: `claude`, `codex`, `both`. Role values: `implementer`, `reviewer`, `collaborator`.

Example:
```
/role codex implementer
/role both reviewer
```

## Collaboration Memory

```
/decision D-XXX | Title | Decision | Rationale    log a structured decision
/topic T-XXX | Title | Codex pos | Claude pos      open a scratchpad topic
/resolve-topic T-XXX | D-XXX                       mark a topic resolved
```

## Export

```
/export claude session_claude.txt     export Claude pane to file
/export codex session_codex.txt       export Codex pane to file
/export master session_chat.txt       export the shared chat to file
```

## Diff Viewer

After each agent turn, `▶ [DIFF] <file>` links appear inline for every file the agent changed. Each link is permanently bound to the exact patch from that turn — later edits to the same file do not overwrite earlier history.

- Click a link to open a full-screen diff overlay (color-coded: `+` green, `-` red, `@@` cyan)
- Click `⎘ Copy` to copy the raw diff to the clipboard
- Click `X` to close

## Themes

```
/theme akritrim    (default)
/theme nord
/theme dracula
/theme solarized
```

The active theme is saved to `settings.toml` and restored on next launch.

## Run Options

```bash
akritrim-colab run --codex-role reviewer --claude-role implementer
akritrim-colab run --claude-model claude-opus-4-5
akritrim-colab run --debug-log .collab/session/tui_debug.log
```
