"""Transformer encoder blocks."""

from __future__ import annotations

import torch
import torch.nn as nn


class TransformerEncoderBlock(nn.Module):
    """
    Wrapper around ``nn.TransformerEncoderLayer`` + ``nn.TransformerEncoder``.

    Parameters
    ----------
    d_model : int
        Model dimensionality.
    num_layers : int
        Number of stacked encoder layers.
    num_heads : int
        Number of attention heads.
    dim_feedforward : int
        Dimension of the feed-forward network inside each layer.
    dropout : float
        Dropout probability.
    activation : str
        Activation function in the feed-forward network.
    batch_first : bool
        If ``True``, input shape is ``[B, S, D]``.
    norm_first : bool
        If ``True``, uses pre-norm (LayerNorm before attention / FFN).
    """

    def __init__(
        self,
        d_model: int = 128,
        num_layers: int = 2,
        num_heads: int = 4,
        dim_feedforward: int = 256,
        dropout: float = 0.1,
        activation: str = "gelu",
        batch_first: bool = True,
        norm_first: bool = True,
    ) -> None:
        super().__init__()

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=num_heads,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            activation=activation,
            batch_first=batch_first,
            norm_first=norm_first,
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer=encoder_layer,
            num_layers=num_layers,
        )
        self.d_model = d_model

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: ``[B, S, D]``

        Returns:
            ``[B, S, D]`` — same shape, transformed by the encoder.
        """
        return self.encoder(x)
