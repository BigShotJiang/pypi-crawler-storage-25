"""Single-trial CNN-Transformer encoder."""

from __future__ import annotations

import torch
import torch.nn as nn

from eemoclas.model.cnn_blocks import ChannelTemporalCNN
from eemoclas.model.token_embedding import ChannelBandTokenEmbedding
from eemoclas.model.transformer_blocks import TransformerEncoderBlock


class TrialCNNTransformer(nn.Module):
    """
    Single-trial encoder: ``[B, C_eff, 2500]`` -> ``[B, D]``.

    Pipeline
    --------
    1. Per-channel 1-D CNN  (shared across channels)
    2. Channel / band token embedding + optional CLS token
    3. Transformer encoder
    4. Pooling (CLS token or mean) -> trial embedding

    Parameters
    ----------
    input_channels : int
        Number of effective channels (``C_eff``).
    input_length : int
        Temporal length of each channel signal (default 2500).
    projection_dim : int
        Dimensionality ``D`` of projected tokens.
    cnn_channels, kernel_sizes, strides, cnn_dropout
        Passed through to :class:`ChannelTemporalCNN`.
    transformer_num_layers, transformer_num_heads, transformer_dim_feedforward,
    transformer_dropout
        Passed through to :class:`TransformerEncoderBlock`.
    use_cls_token : bool
        Whether to use a CLS token for pooling.
    pooling : str
        ``"cls"`` or ``"mean"``.
    use_channel_embedding, use_band_embedding
        Passed through to :class:`ChannelBandTokenEmbedding`.
    """

    def __init__(
        self,
        input_channels: int,
        input_length: int = 2500,
        projection_dim: int = 128,
        cnn_channels: list[int] | None = None,
        kernel_sizes: list[int] | None = None,
        strides: list[int] | None = None,
        cnn_dropout: float = 0.1,
        transformer_num_layers: int = 2,
        transformer_num_heads: int = 4,
        transformer_dim_feedforward: int = 256,
        transformer_dropout: float = 0.1,
        use_cls_token: bool = True,
        pooling: str = "cls",
        use_channel_embedding: bool = True,
        use_band_embedding: bool = True,
        channel_names: list[str] | None = None,
        band_names: list[str] | None = None,
    ) -> None:
        super().__init__()

        self.input_channels = input_channels
        self.input_length = input_length
        self.projection_dim = projection_dim
        self.use_cls_token = use_cls_token
        self.pooling = pooling

        if cnn_channels is None:
            cnn_channels = [16, 32, 64]
        if kernel_sizes is None:
            kernel_sizes = [15, 9, 5]
        if strides is None:
            strides = [2, 2, 2]

        # 1. Per-channel CNN (weights shared across all channels).
        self.channel_cnn = ChannelTemporalCNN(
            cnn_channels=cnn_channels,
            kernel_sizes=kernel_sizes,
            strides=strides,
            projection_dim=projection_dim,
            dropout=cnn_dropout,
        )

        # 2. Channel / band embeddings + CLS token.
        self.token_embedding = ChannelBandTokenEmbedding(
            embedding_dim=projection_dim,
            channel_names=channel_names,
            band_names=band_names,
            use_channel_embedding=use_channel_embedding,
            use_band_embedding=use_band_embedding,
            use_cls_token=use_cls_token,
        )

        # 3. Transformer encoder.
        self.transformer = TransformerEncoderBlock(
            d_model=projection_dim,
            num_layers=transformer_num_layers,
            num_heads=transformer_num_heads,
            dim_feedforward=transformer_dim_feedforward,
            dropout=transformer_dropout,
        )

    def forward(
        self,
        x: torch.Tensor,
        token_meta: list[dict] | None = None,
    ) -> torch.Tensor:
        """
        Args:
            x: ``[B, C_eff, 2500]``
            token_meta: list of ``C_eff`` dicts (channel / band metadata).

        Returns:
            Trial embedding ``[B, D]``.
        """
        B, C_eff, T = x.shape

        # Step 1: Reshape -> per-channel CNN.
        h = x.reshape(B * C_eff, 1, T)           # [B*C_eff, 1, T]
        h = self.channel_cnn(h)                    # [B*C_eff, D]
        h = h.reshape(B, C_eff, self.projection_dim)  # [B, C_eff, D]

        # Step 2: Token embedding (channel/band + CLS).
        h = self.token_embedding(h, token_meta)    # [B, C_eff(+cls), D]

        # Step 3: Transformer.
        h = self.transformer(h)                    # [B, C_eff(+cls), D]

        # Step 4: Pooling.
        if self.use_cls_token and self.pooling == "cls":
            # CLS token is at position 0.
            h = h[:, 0, :]                         # [B, D]
        else:
            # Mean over all token positions.
            h = h.mean(dim=1)                      # [B, D]

        return h
