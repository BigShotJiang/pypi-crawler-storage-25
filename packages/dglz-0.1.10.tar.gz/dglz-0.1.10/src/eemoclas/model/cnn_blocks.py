"""Per-channel 1D CNN temporal encoder blocks."""

from __future__ import annotations

import torch
import torch.nn as nn


def _get_activation(name: str) -> nn.Module:
    """Return an activation module by name."""
    activations = {
        "gelu": nn.GELU,
        "relu": nn.ReLU,
        "elu": nn.ELU,
        "silu": nn.SiLU,
    }
    if name not in activations:
        raise ValueError(f"Unknown activation: {name}. Choose from {list(activations)}")
    return activations[name]()


def _get_norm(name: str, num_features: int) -> nn.Module:
    """Return a normalization module by name."""
    if name == "batchnorm":
        return nn.BatchNorm1d(num_features)
    elif name == "layernorm":
        return nn.LayerNorm(num_features)
    else:
        raise ValueError(f"Unknown norm: {name}. Choose from ['batchnorm', 'layernorm']")


class ChannelTemporalCNN(nn.Module):
    """
    Per-channel 1D CNN temporal encoder.

    Input:  ``[B * C_eff, 1, T]``
    Output: ``[B * C_eff, projection_dim]``

    Architecture
    ------------
    A stack of ``(Conv1d -> Norm -> Activation -> Dropout)`` blocks followed by
    global average pooling and a linear projection layer.
    """

    def __init__(
        self,
        cnn_channels: list[int] | None = None,
        kernel_sizes: list[int] | None = None,
        strides: list[int] | None = None,
        projection_dim: int = 128,
        dropout: float = 0.1,
        activation: str = "gelu",
        norm: str = "batchnorm",
    ) -> None:
        super().__init__()

        if cnn_channels is None:
            cnn_channels = [16, 32, 64]
        if kernel_sizes is None:
            kernel_sizes = [15, 9, 5]
        if strides is None:
            strides = [2, 2, 2]

        if not (len(cnn_channels) == len(kernel_sizes) == len(strides)):
            raise ValueError(
                "cnn_channels, kernel_sizes, and strides must have the same length"
            )

        in_channels = 1
        layers: list[nn.Module] = []

        for out_channels, kernel_size, stride in zip(cnn_channels, kernel_sizes, strides):
            layers.append(
                nn.Conv1d(
                    in_channels=in_channels,
                    out_channels=out_channels,
                    kernel_size=kernel_size,
                    stride=stride,
                    padding=kernel_size // 2,
                )
            )
            layers.append(_get_norm(norm, out_channels))
            layers.append(_get_activation(activation))
            layers.append(nn.Dropout(p=dropout))
            in_channels = out_channels

        self.conv_blocks = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.projection = nn.Linear(cnn_channels[-1], projection_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: ``[B * C_eff, 1, T]`` where T is typically 2500.

        Returns:
            ``[B * C_eff, projection_dim]``
        """
        # Conv blocks: [B*C_eff, 1, T] -> [B*C_eff, last_cnn_ch, T']
        h = self.conv_blocks(x)
        # Global average pool: [B*C_eff, last_cnn_ch, T'] -> [B*C_eff, last_cnn_ch, 1]
        h = self.pool(h)
        # Squeeze: [B*C_eff, last_cnn_ch, 1] -> [B*C_eff, last_cnn_ch]
        h = h.squeeze(-1)
        # Project: [B*C_eff, last_cnn_ch] -> [B*C_eff, projection_dim]
        h = self.projection(h)
        return h
