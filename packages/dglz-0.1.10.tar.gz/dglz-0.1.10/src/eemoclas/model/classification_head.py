"""Lightweight MLP classification head."""

from __future__ import annotations

import torch
import torch.nn as nn


class ClassificationHead(nn.Module):
    """
    Multi-layer perceptron classification head.

    Architecture
    ------------
    ``LayerNorm -> (Linear -> GELU -> Dropout) * N -> Linear (output)``

    Parameters
    ----------
    input_dim : int
        Dimensionality of the input features.
    num_classes : int
        Number of output classes.
    hidden_dims : list[int]
        Sizes of hidden layers.  Each entry adds a ``Linear -> GELU -> Dropout``
        block.
    dropout : float
        Dropout probability applied after each hidden layer.
    """

    def __init__(
        self,
        input_dim: int = 128,
        num_classes: int = 2,
        hidden_dims: list[int] | None = None,
        dropout: float = 0.3,
    ) -> None:
        super().__init__()

        if hidden_dims is None:
            hidden_dims = [128]

        layers: list[nn.Module] = [nn.LayerNorm(input_dim)]

        prev_dim = input_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.GELU())
            layers.append(nn.Dropout(p=dropout))
            prev_dim = hidden_dim

        # Final output projection (no activation — raw logits).
        layers.append(nn.Linear(prev_dim, num_classes))

        self.head = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: ``[B, input_dim]``

        Returns:
            ``[B, num_classes]`` — raw logits.
        """
        return self.head(x)
