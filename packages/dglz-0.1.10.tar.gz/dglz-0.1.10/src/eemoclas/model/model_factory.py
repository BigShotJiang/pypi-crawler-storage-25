"""Factory function for creating model instances by name."""

from __future__ import annotations

import torch.nn as nn

from eemoclas.model.subject_state_cnn_transformer import SubjectStateCNNTransformer
from eemoclas.model.normal_emotion_cnn_transformer import NormalEmotionCNNTransformer
from eemoclas.model.depression_emotion_cnn_transformer import DepressionEmotionCNNTransformer

_REGISTRY: dict[str, type[nn.Module]] = {
    "subject_state": SubjectStateCNNTransformer,
    "normal_emotion": NormalEmotionCNNTransformer,
    "depression_emotion": DepressionEmotionCNNTransformer,
}


def create_model(name: str, config: dict) -> nn.Module:
    """
    Instantiate a model by name.

    Parameters
    ----------
    name : str
        One of ``"subject_state"``, ``"normal_emotion"``,
        ``"depression_emotion"``.
    config : dict
        Configuration dictionary forwarded to the model constructor.

    Returns
    -------
    nn.Module
        The instantiated model.

    Raises
    ------
    ValueError
        If *name* is not recognised.
    """
    if name not in _REGISTRY:
        raise ValueError(
            f"Unknown model: {name!r}. Available models: {list(_REGISTRY)}"
        )
    return _REGISTRY[name](config)
