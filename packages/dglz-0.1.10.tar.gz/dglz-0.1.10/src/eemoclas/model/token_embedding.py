"""Channel / band token embeddings and CLS token management."""

from __future__ import annotations

import torch
import torch.nn as nn


# Default channel names based on the international 10-20 system (30 channels).
_DEFAULT_CHANNEL_NAMES: list[str] = [
    "FP1", "FP2", "F7", "F3", "FZ", "F4", "F8", "FT7", "FC3", "FCZ",
    "FC4", "FT8", "T3", "C3", "CZ", "C4", "T4", "TP7", "CP3", "CPZ",
    "CP4", "TP8", "T5", "P3", "PZ", "P4", "T6", "O1", "OZ", "O2",
]

# Default frequency band names.
_DEFAULT_BAND_NAMES: list[str] = ["delta", "theta", "alpha", "beta", "gamma"]


class ChannelBandTokenEmbedding(nn.Module):
    """
    Add channel embedding and band embedding to tokens based on *token_meta*.
    Optionally prepend a learnable CLS token.

    Parameters
    ----------
    embedding_dim : int
        Dimensionality of token vectors (``D``).
    channel_names : list[str] | None
        Ordered list of all EEG channel names.  Used to build a name-to-index
        mapping so that ``token_meta`` can reference channels by name.
    band_names : list[str] | None
        Ordered list of all frequency-band names.
    use_channel_embedding : bool
        Whether to add channel-wise positional embeddings.
    use_band_embedding : bool
        Whether to add band-wise positional embeddings.
    use_cls_token : bool
        Whether to prepend a learnable CLS token.
    """

    def __init__(
        self,
        embedding_dim: int = 128,
        channel_names: list[str] | None = None,
        band_names: list[str] | None = None,
        use_channel_embedding: bool = True,
        use_band_embedding: bool = True,
        use_cls_token: bool = True,
    ) -> None:
        super().__init__()

        self.embedding_dim = embedding_dim
        self.use_channel_embedding = use_channel_embedding
        self.use_band_embedding = use_band_embedding
        self.use_cls_token = use_cls_token

        # Resolve defaults.
        if channel_names is None:
            channel_names = list(_DEFAULT_CHANNEL_NAMES)
        if band_names is None:
            band_names = list(_DEFAULT_BAND_NAMES)

        self.channel_name_to_idx: dict[str, int] = {
            name.upper(): idx for idx, name in enumerate(channel_names)
        }
        self.band_name_to_idx: dict[str, int] = {
            name.lower(): idx for idx, name in enumerate(band_names)
        }

        num_channels = len(channel_names)
        num_bands = len(band_names)

        # Learnable embeddings.
        if self.use_channel_embedding:
            self.channel_embedding = nn.Embedding(num_channels, embedding_dim)
        if self.use_band_embedding:
            self.band_embedding = nn.Embedding(num_bands, embedding_dim)
        if self.use_cls_token:
            self.cls_token = nn.Parameter(torch.zeros(embedding_dim))
            nn.init.trunc_normal_(self.cls_token, std=0.02)

    def forward(
        self,
        tokens: torch.Tensor,
        token_meta: list[dict] | None = None,
    ) -> torch.Tensor:
        """
        Add channel/band embeddings based on *token_meta* and optionally
        prepend a CLS token.

        Args:
            tokens: ``[B, C_eff, D]``
            token_meta: list of ``C_eff`` dicts, each with keys
                ``"source_channel"`` (str) and ``"band_name"`` (str).
                If ``None``, embeddings are not added.

        Returns:
            ``[B, C_eff (+ 1 if cls), D]``
        """
        B, C_eff, D = tokens.shape
        device = tokens.device

        if token_meta is not None:
            # Build index tensors from token_meta.
            channel_indices: list[int] = []
            band_indices: list[int] = []

            for meta in token_meta:
                ch_name = meta.get("source_channel", "")
                bd_name = meta.get("band_name", "")
                channel_indices.append(
                    self.channel_name_to_idx.get(ch_name.upper(), 0)
                )
                band_indices.append(
                    self.band_name_to_idx.get(bd_name.lower(), 0)
                )

            ch_idx_tensor = torch.tensor(
                channel_indices, dtype=torch.long, device=device
            )  # [C_eff]
            bd_idx_tensor = torch.tensor(
                band_indices, dtype=torch.long, device=device
            )  # [C_eff]

            # Add channel embedding: broadcast over batch dimension.
            if self.use_channel_embedding:
                tokens = tokens + self.channel_embedding(ch_idx_tensor).unsqueeze(0)
                # [B, C_eff, D]

            # Add band embedding.
            if self.use_band_embedding:
                tokens = tokens + self.band_embedding(bd_idx_tensor).unsqueeze(0)
                # [B, C_eff, D]

        # Prepend CLS token.
        if self.use_cls_token:
            cls = self.cls_token.view(1, 1, D).expand(B, -1, -1)
            # [B, 1, D]
            tokens = torch.cat([cls, tokens], dim=1)
            # [B, C_eff + 1, D]

        return tokens
