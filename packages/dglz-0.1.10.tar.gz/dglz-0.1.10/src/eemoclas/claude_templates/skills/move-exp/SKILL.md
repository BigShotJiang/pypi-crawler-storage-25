---
name: move-exp
description: |
  Archive completed DGLZ experiments. Extracts metrics into history_batch.json,
  moves experiments to _Done/batch{N}/, and moves configs to configs/_Done/.
  Supports dry-run mode.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/move_exp.py
  outputs: "JSON archive summary + updated history_batch.json"
---

# Move Exp Skill

## When to Use

When dglztr needs to archive experiments and populate history (Step 5: Archive).

## Usage

```bash
# Dry run first
python .claude/skills/move-exp/scripts/move_exp.py \
    --batch 1 --stage stage1 --exp-names b1-subj,b1-subj-kfold --dry-run

# Actual archive
python .claude/skills/move-exp/scripts/move_exp.py \
    --batch 1 --stage stage1 --exp-names b1-subj,b1-subj-kfold
```

## Key Behaviors

1. Extracts metrics into `history_batch.json` (append-only)
2. Moves `experiments/{name}/` to `experiments/_Done/batch{N}/{name}/`
3. Moves `configs/{name}.yaml` to `configs/_Done/batch{N}/{name}.yaml`
4. Handles both holdout and k-fold metrics
