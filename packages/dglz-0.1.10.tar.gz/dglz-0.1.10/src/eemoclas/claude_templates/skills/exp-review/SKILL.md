---
name: exp-review
description: |
  Coordinate experiment result analysis workflow.
  Extracts metrics via get-results, calls dglzvr sub-agent for deep analysis,
  saves review report. No script — pure workflow specification.
allowed-tools:
  - bash
  - Agent
metadata:
  language: zh-CN
---

# Exp Review Skill

## When to Use

When dglztr needs to review experiment results (Step 4 of workflow).

## Workflow

1. Update agent state to "review":
   ```bash
   bash .claude/skills/agent-state/scripts/update_step.sh review
   ```

2. Extract metrics:
   ```bash
   python .claude/skills/get-results/scripts/get_results.py \
       --experiments-dir experiments \
       --exp-names {exp_names} --stage {stage}
   ```

3. Read experiment configs from `configs/{exp_name}.yaml` for parameter analysis

4. Call dglzvr sub-agent via Agent tool with:
   - Extracted metrics JSON
   - Experiment configs (key parameters)
   - Previous batch history from `history_batch.json`
   - Current stage targets

5. dglzvr returns structured analysis report (markdown)

6. dglztr performs critical review of dglzvr suggestions:
   - Are suggestions data-backed?
   - Do they consider overfitting risk?
   - Are suggested parameter ranges reasonable?

7. Save report:
   ```bash
   bash .claude/skills/agent-state/scripts/save_review.sh {batch_num} {report_file}
   ```

8. Check stage targets:
   - If met → report to user
   - If not met → generate next batch plan based on recommendations

## dglzvr Analysis Framework

dglzvr should analyze:
1. **Overall performance ranking** — which experiment performed best
2. **Per-model parameter analysis** — bottleneck identification
3. **Parameter-performance correlation** — single & interaction effects
4. **Overfitting detection** — train-val gap analysis
5. **Tuning recommendations** — specific, actionable, confidence-scored
6. **Dead-end warnings** — data-backed directions to avoid
7. **K-fold stability** — cross-fold variance analysis (if k-fold)

## Output Format

Structured markdown with tables:
- Overall performance table
- Per-experiment analysis
- Parameter correlation findings
- Overfitting indicators
- Tuning suggestions (with confidence: HIGH/MEDIUM/LOW)
- Next-round experiment plan suggestions
