---
name: configs-runner
description: |
  Sequential batch execution of DGLZ training experiments.
  Reads batch TXT file, runs eemo train for each config with --models and --experiment-name.
  Max 3 configs per run, 3-day timeout per config.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/configs_runner.py
  outputs: "JSON execution statistics to stdout"
---

# Configs Runner Skill

## When to Use

When dglztr needs to execute training experiments (Step 3 of workflow).

## Usage

```bash
python .claude/skills/configs-runner/scripts/configs_runner.py \
    --file .agent/dglztr/exp_conf_tsv/batch1.txt \
    --model subject_state --verbose
```

## Key Flags

- `--file`: Batch TXT file (required)
- `--timeout`: Seconds per experiment (default: 259200 = 3 days)
- `--model`: Target model override (default: auto-detect from exp_name)
- `--max`: Max experiments (default: 3)
- `--verbose`: Print progress

## Auto-Detection

If `--model` is not specified:
- exp_name contains `-normal` → normal_emotion
- exp_name contains `-depression` → depression_emotion
- Otherwise → subject_state
