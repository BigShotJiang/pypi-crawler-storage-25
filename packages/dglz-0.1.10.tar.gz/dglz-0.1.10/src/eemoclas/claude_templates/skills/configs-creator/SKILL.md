---
name: configs-creator
description: |
  Batch create DGLZ experiment configs from TSV plan.
  Generates YAML configs via deep merge into train_full.yaml base template.
  Stage-aware (stage1: subject_state, stage2: emotion models).
  Outputs batch TXT file for configs-runner.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/configs_creator.py
  outputs: "configs/{exp_name}.yaml + .agent/dglztr/exp_conf_tsv/{batch}.txt"
---

# Configs Creator Skill

## When to Use

When dglztr needs to generate experiment configs from a TSV plan (Step 2 of workflow).

## Usage

```bash
python .claude/skills/configs-creator/scripts/configs_creator.py \
    --base configs/base/train_full.yaml \
    --input .agent/dglztr/exp_conf_tsv/batch1.tsv \
    --name batch1 --stage stage1 --output configs/
```

## TSV Format

6 columns (tab-separated):
- `exp_name` — experiment name (e.g. b1-subj-lr3e4)
- `task_conf` — JSON to merge into `models.{target}.task` (usually `{}`)
- `model_conf` — JSON to merge into `models.{target}.model`
- `train_conf` — JSON to merge into `models.{target}.training`
- `split_conf` — JSON to merge into `models.{target}.splitting`
- `aug_conf` — JSON to merge into `models.{target}.augmentation`

JSON content represents INNER keys of the section (not wrapped in section name).

## Key Behaviors

- Injects `experiment.name` = exp_name in each config
- Stage 1: generates 1 config per row (subject_state)
- Stage 2: generates 2 configs per row (normal_emotion + depression_emotion, suffixed -normal/-depression)
- Outputs batch TXT file listing generated config paths
- Failed configs saved to `.agent/dglztr/failed/configs/`
