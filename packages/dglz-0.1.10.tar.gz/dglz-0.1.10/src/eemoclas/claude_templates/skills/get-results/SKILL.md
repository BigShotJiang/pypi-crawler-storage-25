---
name: get-results
description: |
  Extract structured metrics from DGLZ experiment outputs.
  Reads training_state.yaml, metrics CSV, and kfold_summary.yaml.
  Auto-identifies best experiment per stage.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/get_results.py
  outputs: "JSON with per-experiment metrics + best_experiment"
---

# Get Results Skill

## When to Use

When dglztr needs to extract experiment results for analysis (Step 4: Review).

## Usage

```bash
python .claude/skills/get-results/scripts/get_results.py \
    --experiments-dir experiments \
    --exp-names b1-subj-lr3e4,b1-subj-kfold \
    --stage stage1
```

## Output

JSON with:
- `experiments`: list of per-experiment metrics (holdout or k-fold)
- `best_experiment`: name of experiment with highest val_balanced_accuracy
- `stage`: current stage name
