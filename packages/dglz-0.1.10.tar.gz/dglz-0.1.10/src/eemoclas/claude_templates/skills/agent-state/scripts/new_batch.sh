#!/usr/bin/env bash
# new_batch.sh - Create a new training batch.
# Usage: bash .claude/skills/agent-state/scripts/new_batch.sh <batch_number> <stage> [model]
# Example: bash .claude/skills/agent-state/scripts/new_batch.sh 1 stage1 subject_state
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_DIR="$ROOT/.agent"

BATCH_NUM="${1:?Usage: new_batch.sh <batch_number> <stage> [model]}"
STAGE="${2:?Usage: new_batch.sh <batch_number> <stage> [model]}"
MODEL="${3:-}"

# Validate batch number is positive integer
if ! [[ "$BATCH_NUM" =~ ^[0-9]+$ ]] || [ "$BATCH_NUM" -lt 1 ]; then
    echo "ERROR: batch_number must be a positive integer, got: $BATCH_NUM" >&2
    exit 1
fi

# Validate stage
if [[ "$STAGE" != "stage1" && "$STAGE" != "stage2" ]]; then
    echo "ERROR: stage must be 'stage1' or 'stage2', got: $STAGE" >&2
    exit 1
fi

# Determine default model from stage
if [ -z "$MODEL" ]; then
    if [ "$STAGE" = "stage1" ]; then
        MODEL="subject_state"
    else
        MODEL="normal_emotion,depression_emotion"
    fi
fi

# Determine stage target
if [ "$STAGE" = "stage1" ]; then
    TARGET_BA="0.95"
    TARGET_AUC="0.97"
else
    TARGET_BA="0.95"
    TARGET_AUC="0.97"
fi

# Read previous current_batch for stage_completion if exists
STAGE1_DONE="false"
STAGE1_BA="0.0"
STAGE1_AUC="0.0"
STAGE1_EXP="null"
STAGE2_DONE="false"
STAGE2_BA="0.0"
STAGE2_AUC="0.0"
STAGE2_EXP="null"

if [ -f "$AGENT_DIR/dglztr/current_batch.json" ]; then
    EXISTING=$(python3 -c "
import json, sys
try:
    with open('$AGENT_DIR/dglztr/current_batch.json') as f:
        data = json.load(f)
    sc = data.get('stage_completion', {})
    s1 = sc.get('stage1', {})
    s2 = sc.get('stage2', {})
    print(json.dumps({
        's1_done': str(s1.get('completed', False)).lower(),
        's1_ba': s1.get('best_balanced_acc', 0.0),
        's1_auc': s1.get('best_auc', 0.0),
        's1_exp': s1.get('best_exp_name'),
        's2_done': str(s2.get('completed', False)).lower(),
        's2_ba': s2.get('best_balanced_acc', 0.0),
        's2_auc': s2.get('best_auc', 0.0),
        's2_exp': s2.get('best_exp_name'),
    }))
except: pass
" 2>/dev/null || echo '{}')
    STAGE1_DONE=$(echo "$EXISTING" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('s1_done','false'))" 2>/dev/null || echo "false")
    STAGE2_DONE=$(echo "$EXISTING" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('s2_done','false'))" 2>/dev/null || echo "false")
fi

# Write new current_batch.json
cat > "$AGENT_DIR/dglztr/current_batch.json" << ENDJSON
{
  "batch": $BATCH_NUM,
  "stage": "$STAGE",
  "target_models": "$MODEL",
  "stage_target": {
    "balanced_acc": $TARGET_BA,
    "auc": $TARGET_AUC
  },
  "stage_completion": {
    "stage1": {"completed": $STAGE1_DONE, "best_balanced_acc": $STAGE1_BA, "best_auc": $STAGE1_AUC, "best_exp_name": $STAGE1_EXP},
    "stage2": {"completed": $STAGE2_DONE, "best_balanced_acc": $STAGE2_BA, "best_auc": $STAGE2_AUC, "best_exp_name": $STAGE2_EXP}
  },
  "current_best": {
    "balanced_acc": 0.0,
    "auc": 0.0,
    "exp_name": null
  },
  "experiments": {
    "total": 0,
    "completed": [],
    "pending": []
  },
  "step": "plan",
  "round": 1,
  "status": "planning"
}
ENDJSON

echo "Created batch $BATCH_NUM (stage=$STAGE, model=$MODEL)"
cat "$AGENT_DIR/dglztr/current_batch.json"
