---
name: agent-state
description: |
  Manage DGLZ training agent state files and directory structure.
  Initialize .agent/ directories, create new batches, update workflow steps,
  and save review reports.
allowed-tools:
  - bash
metadata:
  language: zh-CN
  entrypoint: scripts/
---

# Agent State Skill

## When to Use

- Before starting any agent workflow (initialize state)
- When creating a new training batch
- When updating the current workflow step
- When saving a dglzvr analysis report

## Scripts

### init_state.sh
```bash
bash .claude/skills/agent-state/scripts/init_state.sh
```
Initializes `.agent/` directory structure. Idempotent — skips existing files.

### new_batch.sh
```bash
bash .claude/skills/agent-state/scripts/new_batch.sh <batch_number> <stage> [model]
```
Creates a new `current_batch.json`. Stage must be `stage1` or `stage2`.

### update_step.sh
```bash
bash .claude/skills/agent-state/scripts/update_step.sh <step> [status]
```
Updates current workflow step. Valid steps: `plan`, `config`, `train`, `review`, `archive`.

### save_review.sh
```bash
bash .claude/skills/agent-state/scripts/save_review.sh <batch_number> <report_file>
```
Copies review report to `.agent/dglzvr/reviews/batch{N}_review.md`.
