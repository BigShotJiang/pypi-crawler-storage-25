#!/usr/bin/env bash
# init_state.sh - Initialize .agent/ directory structure for DGLZ training agents.
# Usage: bash .claude/skills/agent-state/scripts/init_state.sh
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
AGENT_DIR="$ROOT/.agent"

echo "Initializing agent state at: $AGENT_DIR"

# Create directory structure (idempotent)
mkdir -p "$AGENT_DIR/dglztr/exp_conf_tsv"
mkdir -p "$AGENT_DIR/dglztr/failed/configs"
mkdir -p "$AGENT_DIR/dglztr/failed/training"
mkdir -p "$AGENT_DIR/dglzvr/reviews"

# Initialize history_batch.json if missing
if [ ! -f "$AGENT_DIR/dglztr/history_batch.json" ]; then
    echo '[]' > "$AGENT_DIR/dglztr/history_batch.json"
    echo "Created history_batch.json"
else
    echo "history_batch.json already exists, skipping"
fi

# Initialize current_batch.json if missing
if [ ! -f "$AGENT_DIR/dglztr/current_batch.json" ]; then
    echo '{}' > "$AGENT_DIR/dglztr/current_batch.json"
    echo "Created current_batch.json"
else
    echo "current_batch.json already exists, skipping"
fi

echo "Agent state initialized."
