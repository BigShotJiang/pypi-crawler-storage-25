#!/usr/bin/env bash
# save_review.sh - Save dglzvr analysis report.
# Usage: bash .claude/skills/agent-state/scripts/save_review.sh <batch_number> <report_file>
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
REVIEWS_DIR="$ROOT/.agent/dglzvr/reviews"

BATCH_NUM="${1:?Usage: save_review.sh <batch_number> <report_file>}"
REPORT_FILE="${2:?Usage: save_review.sh <batch_number> <report_file>}"

mkdir -p "$REVIEWS_DIR"

if [ ! -f "$REPORT_FILE" ]; then
    echo "ERROR: Report file not found: $REPORT_FILE" >&2
    exit 1
fi

DEST="$REVIEWS_DIR/batch${BATCH_NUM}_review.md"
cp "$REPORT_FILE" "$DEST"
echo "Review saved to: $DEST"
