#!/usr/bin/env bash
# update_step.sh - Update current workflow step.
# Usage: bash .claude/skills/agent-state/scripts/update_step.sh <step> [status]
# Steps: plan, config, train, review, archive
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
STATE_FILE="$ROOT/.agent/dglztr/current_batch.json"

STEP="${1:?Usage: update_step.sh <step> [status]}"
STATUS="${2:-running}"

# Validate step name
case "$STEP" in
    plan|config|train|review|archive) ;;
    *) echo "ERROR: Invalid step '$STEP'. Must be: plan, config, train, review, archive" >&2; exit 1 ;;
esac

if [ ! -f "$STATE_FILE" ]; then
    echo "ERROR: current_batch.json not found at $STATE_FILE" >&2
    exit 1
fi

python3 -c "
import json
with open('$STATE_FILE') as f:
    data = json.load(f)
data['step'] = '$STEP'
data['status'] = '$STATUS'
with open('$STATE_FILE', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
print(f'Updated step to: $STEP (status: $STATUS)')
"
