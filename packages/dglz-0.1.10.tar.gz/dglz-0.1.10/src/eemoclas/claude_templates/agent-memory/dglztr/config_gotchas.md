# Config Gotchas

## DGLZ 配置注意事项

1. **experiment.name 必须唯一**: configs_creator 自动注入，configs_runner 也传 --experiment-name。双重保障防止实验覆盖。

2. **--models 必须传递**: 不传则训练所有模型，超出 GPU 限制。

3. **TSV 列 JSON 是内部键**: `train_conf` 内容如 `{"learning_rate":0.0003}`，不是 `{"training":{"learning_rate":0.0003}}`。合并目标是 `models.{target_model}.{section}`。

4. **splitting.method 值**: holdout 用默认值（配置文件中已设定），k-fold 用 `"StratifiedGroupKFold"`。

5. **Stage 2 双配置**: Stage 2 每行 TSV 生成两个 YAML（-normal 和 -depression 后缀）。

6. **early_stopping_patience**: 配置字段在 training 层级，默认值 15。读取方式：`config["training"].get("early_stopping_patience", 15)`。
