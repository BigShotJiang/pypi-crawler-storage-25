# Training Strategy

## Stage 1: subject_state

**目标**: balanced_acc ≥ 95%, AUC ≥ 97%

**调参维度**:
- learning_rate: 搜索范围 [1e-4, 1e-3]
- weight_decay: 搜索范围 [0.01, 0.1]
- optimizer: adam, adamw
- epochs: 50-200 (with early stopping)
- scheduler: cosine, reduce_on_plateau

**策略**: 先宽后窄 — 前几批搜索大范围，后续根据 dglzvr 分析微调

## Stage 2: Emotion Classifiers

**前提**: Stage 1 达标

**模型**: normal_emotion + depression_emotion（串行训练，GPU 12GB 限制）

**调参维度**: 同 Stage 1，但需注意数据不平衡问题
