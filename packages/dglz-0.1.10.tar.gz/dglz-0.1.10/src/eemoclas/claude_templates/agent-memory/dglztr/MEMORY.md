# dglztr Agent Memory

## 关键约束

- GPU: 12GB → 串行训练，不可并行
- 每批最多 3 个配置，超时 259200s (3天)
- 指标优先级: balanced_accuracy > AUC > macro_f1 (USER MANDATED)
- Conda env: `dglz` — 始终用 `conda run -n dglz`
- history_batch.json 只追加不删除

## 阶段目标

- Stage 1: subject_state → balanced_acc ≥ 95%, AUC ≥ 97%
- Stage 2: normal_emotion + depression_emotion → 同上
- Stage 2 需 Stage 1 达标（用户可覆盖）

## 当前进度

- 尚未开始训练
- 等待用户指定阶段

## 已知问题

- 无

## 相关文档

- [training_strategy.md](training_strategy.md) — 调参策略
- [config_gotchas.md](config_gotchas.md) — 配置陷阱
