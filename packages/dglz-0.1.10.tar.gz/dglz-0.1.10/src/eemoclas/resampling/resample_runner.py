"""Runner that dispatches to the correct resampler based on config."""

from __future__ import annotations

import logging
from pathlib import Path

import yaml

from eemoclas.resampling.subject_state_resampler import SubjectStateResampler
from eemoclas.resampling.normal_emotion_resampler import NormalEmotionResampler
from eemoclas.resampling.depression_emotion_resampler import DepressionEmotionResampler

logger = logging.getLogger(__name__)

# Mapping from task name to resampler class.
_TASK_REGISTRY = {
    "subject_state": SubjectStateResampler,
    "normal_emotion": NormalEmotionResampler,
    "depression_emotion": DepressionEmotionResampler,
}


def run_resample(config_path: str) -> None:
    """Load a YAML config, instantiate the correct resampler, and run it.

    Parameters
    ----------
    config_path : str
        Path to a YAML configuration file.  The file must contain at least::

            task:
              name: subject_state | normal_emotion | depression_emotion
            data:
              output_dir: /path/to/output

    Raises
    ------
    FileNotFoundError
        If *config_path* does not exist.
    KeyError
        If the config does not contain a valid ``task.name``.
    ValueError
        If the task name is not recognised.
    """
    config_path_obj = Path(config_path)
    if not config_path_obj.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(config_path_obj, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    task_name = config.get("task", {}).get("name")
    if not task_name:
        raise KeyError(
            "Config must contain 'task.name'. "
            f"Available tasks: {list(_TASK_REGISTRY.keys())}"
        )

    resampler_cls = _TASK_REGISTRY.get(task_name)
    if resampler_cls is None:
        raise ValueError(
            f"Unknown task '{task_name}'. "
            f"Available tasks: {list(_TASK_REGISTRY.keys())}"
        )

    logger.info("Running resampler '%s' with config %s", task_name, config_path)
    resampler = resampler_cls(config)
    resampler.run()
    logger.info("Resampler '%s' finished successfully.", task_name)
