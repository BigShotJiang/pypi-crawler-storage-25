"""Statistics computation for resampled datasets."""

from __future__ import annotations

from collections import Counter
from typing import Any


def compute_resample_stats(rows: list[dict], task_name: str) -> dict[str, Any]:
    """Compute summary statistics for a resampling run.

    Parameters
    ----------
    rows : list[dict]
        Manifest rows (one dict per sample).
    task_name : str
        Name of the task (e.g. ``"subject_state"``, ``"normal_emotion"``,
        ``"depression_emotion"``).

    Returns
    -------
    dict[str, Any]
        Statistics dictionary suitable for ``stats.json``.
    """
    total_samples = len(rows)

    if total_samples == 0:
        return {
            "task_name": task_name,
            "total_samples": 0,
            "num_subjects": 0,
            "label_distribution": {},
            "c_eff": None,
            "length": None,
        }

    # Unique subjects.
    subject_ids: set[str] = set()
    for row in rows:
        subject_ids.add(str(row.get("subject_id", "")))

    # Label distribution depends on task type.
    label_distribution: dict[str, int] = {}
    if task_name == "subject_state":
        key = "group_label"
    else:
        key = "emotion_label"

    counter: Counter = Counter()
    for row in rows:
        label_val = row.get(key)
        if label_val is not None:
            counter[str(label_val)] += 1
    label_distribution = dict(counter)

    # Grab c_eff and length from the first row (they are constant across the
    # dataset by design).
    c_eff = rows[0].get("c_eff")
    length = rows[0].get("length")

    stats: dict[str, Any] = {
        "task_name": task_name,
        "total_samples": total_samples,
        "num_subjects": len(subject_ids),
        "subjects": sorted(subject_ids),
        "label_distribution": label_distribution,
        "c_eff": c_eff,
        "length": length,
    }

    # Add per-subject sample count for subject_state task.
    if task_name == "subject_state":
        per_subject: dict[str, int] = {}
        for row in rows:
            sid = str(row.get("subject_id", ""))
            per_subject[sid] = per_subject.get(sid, 0) + 1
        stats["samples_per_subject"] = per_subject

    # Add per-emotion sample count for emotion tasks.
    if task_name in ("normal_emotion", "depression_emotion"):
        per_emotion: dict[str, int] = {}
        for row in rows:
            lbl = str(row.get("emotion_label", ""))
            per_emotion[lbl] = per_emotion.get(lbl, 0) + 1
        stats["samples_per_emotion"] = per_emotion

    return stats
