"""Truncated Gaussian window sampler for EEG segment cropping."""

from __future__ import annotations

import numpy as np
from scipy.stats import truncnorm


class TruncatedGaussianWindowSampler:
    """Sample window centers from a truncated Gaussian distribution.

    The centre of each window (in seconds) is drawn from a truncated normal
    distribution :math:`TN(\\mu, \\sigma, a, b)` where *a* and *b* are the
    lower and upper bounds.  The window is then converted to sample indices and
    clamped so that it stays within the segment boundaries.

    Parameters
    ----------
    fs : int
        Sampling frequency in Hz.
    window_seconds : float
        Duration of the cropping window in seconds.
    mu_seconds : float
        Mean of the underlying (un-truncated) Gaussian in seconds.
    sigma_seconds : float
        Standard deviation of the underlying Gaussian in seconds.
    lower_seconds : float
        Lower truncation bound in seconds.
    upper_seconds : float
        Upper truncation bound in seconds.
    seed : int | None
        Random seed for reproducibility.
    """

    def __init__(
        self,
        fs: int = 250,
        window_seconds: float = 10.0,
        mu_seconds: float = 25.0,
        sigma_seconds: float = 8.0,
        lower_seconds: float = 5.0,
        upper_seconds: float = 45.0,
        seed: int | None = None,
    ) -> None:
        self.fs = fs
        self.window_seconds = window_seconds
        self.mu_seconds = mu_seconds
        self.sigma_seconds = sigma_seconds
        self.lower_seconds = lower_seconds
        self.upper_seconds = upper_seconds
        self.window_points = int(window_seconds * fs)
        self.rng = np.random.default_rng(seed)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sample_window(self, segment_points: int) -> dict:
        """Sample a window centre and return start/end sample indices.

        Parameters
        ----------
        segment_points : int
            Total number of samples in the source segment.

        Returns
        -------
        dict
            ``center_seconds`` (float), ``start_sample`` (int),
            ``end_sample`` (int).
        """
        if segment_points <= 0:
            raise ValueError(
                f"segment_points must be positive, got {segment_points}"
            )
        if self.window_points > segment_points:
            raise ValueError(
                f"window_points ({self.window_points}) > segment_points "
                f"({segment_points}); window is longer than the segment"
            )

        # Draw centre from truncated normal in *seconds*.
        a_scaled = (self.lower_seconds - self.mu_seconds) / self.sigma_seconds
        b_scaled = (self.upper_seconds - self.mu_seconds) / self.sigma_seconds
        center_seconds: float = float(
            truncnorm.rvs(
                a_scaled,
                b_scaled,
                loc=self.mu_seconds,
                scale=self.sigma_seconds,
                random_state=self.rng,
            )
        )

        # Convert to sample index.
        center_sample = round(center_seconds * self.fs)

        # Derive window boundaries.
        start = center_sample - self.window_points // 2
        end = start + self.window_points

        # Clamp so the window stays inside the segment.
        if start < 0:
            end -= start  # shift right
            start = 0
        if end > segment_points:
            start -= end - segment_points  # shift left
            end = segment_points
        # Final safety clamp (should not be needed but guards edge cases).
        start = max(start, 0)
        end = min(end, segment_points)

        return {
            "center_seconds": center_seconds,
            "start_sample": int(start),
            "end_sample": int(end),
        }

    def crop(self, eeg: np.ndarray, window: dict) -> np.ndarray:
        """Crop an EEG array according to a window dictionary.

        Parameters
        ----------
        eeg : np.ndarray
            Shape ``(C, segment_points)``.
        window : dict
            Must contain ``start_sample`` and ``end_sample`` keys.

        Returns
        -------
        np.ndarray
            Shape ``(C, window_points)``.
        """
        start = window["start_sample"]
        end = window["end_sample"]
        return eeg[:, start:end].copy()
