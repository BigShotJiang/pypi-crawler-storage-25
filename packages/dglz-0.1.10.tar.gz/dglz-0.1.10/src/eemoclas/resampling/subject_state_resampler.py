"""Subject-state resampler for Classifier 1 (normal vs depression)."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
import torch

from eemoclas.data.eeg_io import load_train_mat
from eemoclas.data.eeg_splitter import split_train_emotion
from eemoclas.data.preprocessing import (
    channel_select,
    clip_signal,
    z_score,
)
from eemoclas.resampling.base_resampler import BaseResampler
from eemoclas.resampling.manifest import build_subject_state_manifest_row
from eemoclas.resampling.stats import compute_resample_stats
from eemoclas.resampling.truncated_gaussian import TruncatedGaussianWindowSampler
from eemoclas.utils.seeding import set_split_seed

logger = logging.getLogger(__name__)

# Emotion label constants.
EMOTION_NEU = 0  # neutral
EMOTION_POS = 1  # positive


def _subject_state_worker(item: tuple) -> list[dict]:
    """Process a single subject for subject-state resampling.

    Picklable top-level function for :class:`ProcessPoolExecutor`.
    Receives all state via *item* tuple so no ``self`` reference is needed.
    """
    subject_entry, params, global_offset, samples_dir_str = item
    samples_dir = Path(samples_dir_str)

    subject_id = subject_entry["subject_id"]
    group_label = int(subject_entry["group_label"])
    mat_path = subject_entry["mat_path"]

    fs = params["fs"]
    samples_per_subject = params["samples_per_subject"]
    base_seed = params["base_seed"]
    channel_set = params["channel_set"]
    mu_seconds = params["mu_seconds"]
    sigma_seconds = params["sigma_seconds"]
    lower_seconds = params["lower_seconds"]
    upper_seconds = params["upper_seconds"]
    window_seconds = params["window_seconds"]
    c_eff = params["c_eff"]
    token_meta = params["token_meta"]

    raw = load_train_mat(mat_path)
    neu_segments = split_train_emotion(raw["EEG_data_neu"])
    pos_segments = split_train_emotion(raw["EEG_data_pos"])

    # 8 segments: 4 neutral + 4 positive.
    all_segments = list(neu_segments) + list(pos_segments)
    emotion_labels = [EMOTION_NEU] * 4 + [EMOTION_POS] * 4
    segment_ids = [f"neu_{i}" for i in range(4)] + [
        f"pos_{i}" for i in range(4)
    ]

    manifest_rows: list[dict] = []

    for repeat in range(samples_per_subject):
        seed = base_seed + global_offset + repeat
        rng = np.random.default_rng(seed)

        sampler = TruncatedGaussianWindowSampler(
            fs=fs,
            window_seconds=window_seconds,
            mu_seconds=mu_seconds,
            sigma_seconds=sigma_seconds,
            lower_seconds=lower_seconds,
            upper_seconds=upper_seconds,
            seed=seed,
        )

        trials = []
        centers_sec: list[float] = []
        starts: list[int] = []
        ends: list[int] = []

        for seg_idx, seg in enumerate(all_segments):
            segment_points = seg.shape[1]
            window = sampler.sample_window(segment_points)
            cropped = sampler.crop(seg, window)  # (30, window_points)

            # Preprocessing: channel select + bandpass → z-score → clip.
            processed = channel_select(cropped, channel_set=channel_set)
            processed = z_score(processed)
            processed = clip_signal(processed)

            trials.append(processed)  # (C_eff, window_points)
            centers_sec.append(window["center_seconds"])
            starts.append(window["start_sample"])
            ends.append(window["end_sample"])

        # Random permutation of the 8 trials.
        perm = rng.permutation(8).tolist()
        trials = [trials[i] for i in perm]
        perm_emotion_labels = [emotion_labels[i] for i in perm]
        perm_segment_ids = [segment_ids[i] for i in perm]
        perm_centers = [centers_sec[i] for i in perm]
        perm_starts = [starts[i] for i in perm]
        perm_ends = [ends[i] for i in perm]

        # Stack as [8, C_eff, window_points].
        x = np.stack(trials, axis=0)
        x_tensor = torch.from_numpy(x).float()

        sample_id = f"ss_{subject_id}_{repeat:04d}"

        # Validate token_meta length.
        if len(token_meta) != x_tensor.shape[-2]:
            raise ValueError(
                f"token_meta length {len(token_meta)} != C_eff {x_tensor.shape[-2]}"
            )

        sample = {
            "x": x_tensor,
            "y": torch.LongTensor([group_label]),
            "subject_id": subject_id,
            "group_label": group_label,
            "trial_emotion_labels": torch.LongTensor(perm_emotion_labels),
            "trial_segment_ids": perm_segment_ids,
            "token_meta": token_meta,
            "meta": {
                "sampler": "truncated_gaussian",
                "mu_seconds": mu_seconds,
                "sigma_seconds": sigma_seconds,
                "window_seconds": window_seconds,
                "permutation": perm,
                "center_seconds": perm_centers,
                "start_sample": perm_starts,
                "end_sample": perm_ends,
            },
        }

        path = str(samples_dir / f"{sample_id}.pt")
        torch.save(sample, path)

        row = build_subject_state_manifest_row(
            sample_id=sample_id,
            sample_path=path,
            subject_id=subject_id,
            group_label=group_label,
            num_trials=8,
            c_eff=c_eff,
            length=x_tensor.shape[-1],
            seed=seed,
            source_segments=json.dumps(segment_ids),
            trial_segment_ids=json.dumps(perm_segment_ids),
            trial_emotion_labels=json.dumps(perm_emotion_labels),
        )
        manifest_rows.append(row)

    return manifest_rows


class SubjectStateResampler(BaseResampler):
    """Generate the resampled dataset for Classifier 1.

    For each subject the 50-second neutral and positive recordings are split
    into 8 segments (4 neutral + 4 positive).  For each repeated draw the
    sampler crops a random 10-second window from every segment, applies
    preprocessing, randomly permutes the 8 trials, and stacks them into a
    single ``[8, C_eff, 2500]`` tensor.

    The resulting sample encodes a **subject-level** state (normal /
    depression) rather than an emotion-level label.
    """

    def run(self) -> None:
        """Execute the full resampling pipeline."""
        self.save_config_snapshot()

        cfg = self.config
        data_cfg = cfg["data"]
        resample_cfg = cfg.get("resample", {})

        # Config parameters with defaults.
        fs: int = data_cfg.get("fs", 250)
        samples_per_subject: int = resample_cfg.get("samples_per_subject", 20)
        base_seed: int = cfg.get("seed", 42)
        channel_set: str = data_cfg.get("channel_set", "standard")

        mu_seconds: float = resample_cfg.get("mu_seconds", 25.0)
        sigma_seconds: float = resample_cfg.get("sigma_seconds", 8.0)
        lower_seconds: float = resample_cfg.get("lower_seconds", 5.0)
        upper_seconds: float = resample_cfg.get("upper_seconds", 45.0)
        window_seconds: float = resample_cfg.get("window_seconds", 10.0)

        # Load subject list from train_subjects.csv.
        subjects_csv = data_cfg.get("index_file", data_cfg.get("subjects_csv", "train_subjects.csv"))
        subject_list = self._load_subject_list(subjects_csv)

        # Resolve c_eff from channel set.
        from eemoclas.utils.config import resolve_c_eff

        c_eff = resolve_c_eff(cfg)

        # Build token_meta for the selected channel set.
        # Use a sufficiently large dummy so that bandpass filter padlen is satisfied.
        _, token_meta = channel_select(
            np.zeros((30, 2500)),  # dummy to get channel names + token_meta
            channel_set=channel_set,
            return_meta=True,
        )

        _cfg = {
            "fs": fs,
            "samples_per_subject": samples_per_subject,
            "base_seed": base_seed,
            "channel_set": channel_set,
            "mu_seconds": mu_seconds,
            "sigma_seconds": sigma_seconds,
            "lower_seconds": lower_seconds,
            "upper_seconds": upper_seconds,
            "window_seconds": window_seconds,
            "c_eff": c_eff,
            "token_meta": token_meta,
        }

        # Assign a deterministic global sample offset per subject so that
        # seeds are stable regardless of process scheduling.
        samples_per_subject_count = samples_per_subject
        subject_offsets: dict[str, int] = {}
        offset = 0
        for entry in subject_list:
            subject_offsets[entry["subject_id"]] = offset
            offset += samples_per_subject_count

        items = [
            (entry, _cfg, subject_offsets[entry["subject_id"]], str(self.samples_dir))
            for entry in subject_list
        ]

        manifest_rows = self._parallel_map(
            _subject_state_worker,
            items,
            desc="subject_state",
        )

        # Write manifest and stats.
        self.write_manifest(manifest_rows)
        stats = compute_resample_stats(manifest_rows, task_name="subject_state")
        self.write_stats(stats)

        logger.info(
            "Subject-state resampling complete: %d samples from %d subjects.",
            len(manifest_rows),
            len(subject_list),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _load_subject_list(csv_path: str) -> list[dict]:
        """Load the subject list from a CSV file.

        Expected columns: ``subject_id``, ``group_label``, ``mat_path``.

        Returns
        -------
        list[dict]
            One dict per subject.
        """
        import pandas as pd
        from pathlib import Path

        path = Path(csv_path)
        if not path.exists():
            raise FileNotFoundError(f"Subjects CSV not found: {csv_path}")

        df = pd.read_csv(path)
        required = {"subject_id", "group_label", "mat_path"}
        missing = required - set(df.columns)
        if missing:
            raise ValueError(
                f"Subjects CSV missing required columns: {missing}"
            )

        return df.to_dict(orient="records")
