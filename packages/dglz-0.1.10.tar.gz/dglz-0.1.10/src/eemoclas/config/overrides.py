"""Dotted-key override system for Config dataclasses.

Applies CLI-style ``key=value`` overrides to a :class:`~eemoclas.config.dataclasses.Config`
instance in-place, walking nested dataclasses and dicts along dotted paths.

Example overrides::

    ["experiment.name=exp002",
     "models.subject_state.training.optimizer.lr=0.002",
     "signal.fs=512"]

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import ast
import dataclasses
from typing import Any

from eemoclas.config.dataclasses import Config


# ---------------------------------------------------------------------------
# Value parsing
# ---------------------------------------------------------------------------

def _parse_value(raw: str) -> Any:
    """Parse a raw string into an appropriate Python type.

    Tries the following coercions in order:

    1. ``bool`` -- ``"true"`` / ``"false"`` (case-insensitive)
    2. ``None`` -- ``"null"`` / ``"none"`` (case-insensitive)
    3. ``int`` -- e.g. ``"42"``
    4. ``float`` -- e.g. ``"3.14"``
    5. ``list`` / ``dict`` via :func:`ast.literal_eval`
    6. ``str`` -- fallback

    Parameters
    ----------
    raw:
        The raw string value from the override expression.

    Returns
    -------
    Any
        The parsed value.
    """
    # Bool (must come before int/float checks because "true" is not numeric)
    if raw.lower() == "true":
        return True
    if raw.lower() == "false":
        return False

    # None
    if raw.lower() in ("null", "none"):
        return None

    # Int
    try:
        val = int(raw)
        return val
    except ValueError:
        pass

    # Float
    try:
        val = float(raw)
        return val
    except ValueError:
        pass

    # List / dict via literal_eval (e.g. "[1, 2, 3]", "{'a': 1}")
    try:
        evaluated = ast.literal_eval(raw)
        if isinstance(evaluated, (list, dict)):
            return evaluated
        # If literal_eval succeeded but produced a non-collection, fall through
        # to str. This handles edge cases like literal_eval("()") -> tuple.
        _ = evaluated  # suppress unused warning
    except (ValueError, SyntaxError):
        pass

    # Fallback: plain string
    return raw


# ---------------------------------------------------------------------------
# Nested attribute setting
# ---------------------------------------------------------------------------

def _set_nested(obj: Any, parts: list[str], value: Any) -> None:
    """Recursively walk *parts* on *obj* and set the final attribute.

    Supports nested dataclasses and dicts.  When a dict is encountered, the
    remaining path is treated as dict keys.

    Parameters
    ----------
    obj:
        Root object (typically a :class:`Config` instance).
    parts:
        Dotted-key segments, e.g. ``["experiment", "name"]``.
    value:
        The value to assign to the final attribute.

    Raises
    ------
    ValueError
        If a dataclass field does not exist.
    AttributeError
        If an intermediate attribute cannot be resolved.
    """
    for i, part in enumerate(parts[:-1]):
        if isinstance(obj, dict):
            obj = obj[part]
        elif dataclasses.is_dataclass(obj):
            if not hasattr(obj, part):
                field_names = {f.name for f in dataclasses.fields(obj)}
                raise ValueError(
                    f"Unknown field {part!r} on {type(obj).__name__}. "
                    f"Available fields: {sorted(field_names)}"
                )
            obj = getattr(obj, part)
        else:
            raise AttributeError(
                f"Cannot traverse into {type(obj).__name__} at segment {part!r}"
            )

    # Set the final attribute
    final_part = parts[-1]
    if isinstance(obj, dict):
        obj[final_part] = value
    elif dataclasses.is_dataclass(obj):
        if not hasattr(obj, final_part):
            field_names = {f.name for f in dataclasses.fields(obj)}
            raise ValueError(
                f"Unknown field {final_part!r} on {type(obj).__name__}. "
                f"Available fields: {sorted(field_names)}"
            )
        setattr(obj, final_part, value)
    else:
        raise AttributeError(
            f"Cannot set {final_part!r} on {type(obj).__name__}"
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def apply_overrides(config: Config, overrides: list[str]) -> Config:
    """Apply dotted-key overrides to a :class:`Config` in-place.

    Each override has the format ``key=value`` where *key* is a dot-separated
    path through the nested dataclass / dict structure and *value* is parsed
    automatically (int, float, bool, None, list, or str).

    Examples::

        apply_overrides(cfg, ["experiment.name=exp002"])
        apply_overrides(cfg, ["signal.fs=512", "signal.zscore.enabled=false"])

    Parameters
    ----------
    config:
        The :class:`Config` instance to mutate.
    overrides:
        List of ``key=value`` strings.

    Returns
    -------
    Config
        The same *config* instance (mutated in-place).

    Raises
    ------
    ValueError
        If an override string is malformed or references an unknown field.
    """
    for override in overrides:
        if "=" not in override:
            raise ValueError(
                f"Invalid override format (expected key=value): {override!r}"
            )
        key, raw_value = override.split("=", 1)
        parts = key.strip().split(".")
        if not parts or any(p == "" for p in parts):
            raise ValueError(
                f"Invalid override key (empty segment): {key!r}"
            )
        value = _parse_value(raw_value)
        _set_nested(config, parts, value)
    return config
