"""Dataclass definitions for the DGLZ typed configuration system.

Every configuration section used by the EEG emotion recognition pipeline is
represented as a ``@dataclass`` with sensible defaults, so that a complete
pipeline can be instantiated from code without any YAML file.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _dataclass_to_dict(obj: Any) -> Any:
    """Recursively convert a dataclass (or dict/list/primitive) to a plain dict.

    Parameters
    ----------
    obj:
        A dataclass instance, dict, list, or primitive value.

    Returns
    -------
    Any
        A JSON-serialisable representation.
    """
    if hasattr(obj, "__dataclass_fields__"):
        return {k: _dataclass_to_dict(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, dict):
        return {k: _dataclass_to_dict(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_dataclass_to_dict(v) for v in obj]
    if isinstance(obj, Path):
        return str(obj)
    return obj


def _flatten_dict(d: dict, parent_key: str = "", sep: str = ".") -> dict[str, Any]:
    """Flatten a nested dict to dotted-key format.

    Example: ``{"optimizer": {"type": "adamw", "lr": 0.001}}``
    → ``{"optimizer.type": "adamw", "optimizer.lr": 0.001}``
    """
    items: dict[str, Any] = {}
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.update(_flatten_dict(v, new_key, sep))
        else:
            items[new_key] = v
    return items


def _flatten_training_config(tc: TrainingConfig) -> dict[str, Any]:
    """Flatten TrainingConfig to dotted keys for display."""
    raw = _dataclass_to_dict(tc)
    return _flatten_dict(raw)


def _flatten_model_config(mc: ModelConfig) -> dict[str, Any]:
    """Flatten ModelConfig to dotted keys, showing key architecture params."""
    raw = _dataclass_to_dict(mc)
    return _flatten_dict(raw)


# ---------------------------------------------------------------------------
# Project
# ---------------------------------------------------------------------------

@dataclass
class ProjectConfig:
    """Project-level metadata."""

    repo_name: str = "DGLZ"
    package_name: str = "eemoclas"
    cli_name: str = "eemo"
    experiment_family: str = "default"


# ---------------------------------------------------------------------------
# Signal
# ---------------------------------------------------------------------------

@dataclass
class ZscoreConfig:
    """Z-score normalisation settings."""

    enabled: bool = True
    eps: float = 1e-6


@dataclass
class SignalConfig:
    """Signal processing parameters."""

    fs: int = 250
    train_segment_points: int = 12500
    window_points: int = 2500
    clip_std: float = 5.0
    zscore: ZscoreConfig = field(default_factory=ZscoreConfig)


# ---------------------------------------------------------------------------
# Channels
# ---------------------------------------------------------------------------

@dataclass
class ChannelsConfig:
    """Channel selection settings."""

    mode: str = "by_name"
    selected: Any = "all"  # "all" or list[str]


# ---------------------------------------------------------------------------
# Band
# ---------------------------------------------------------------------------

_DEFAULT_BAND_DEFINITIONS: dict[str, list[float]] = {
    "delta": [1.0, 4.0],
    "theta": [4.0, 7.0],
    "alpha": [8.0, 13.0],
    "beta": [13.0, 30.0],
    "low_gamma": [30.0, 45.0],
    "broadband": [1.0, 45.0],
}


@dataclass
class BandConfig:
    """Frequency-band definitions and per-channel band assignments."""

    band_definitions: dict[str, list[float]] = field(
        default_factory=lambda: dict(_DEFAULT_BAND_DEFINITIONS),
    )
    default_bands: list[str] = field(
        default_factory=lambda: ["broadband"],
    )
    per_channel: dict[str, list[str]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Resample / Sampling
# ---------------------------------------------------------------------------

@dataclass
class GaussianSamplingConfig:
    """Truncated-Gaussian sampling parameters."""

    mu_seconds: float = 25.0
    sigma_seconds: float = 8.0
    lower_seconds: float = 5.0
    upper_seconds: float = 45.0


@dataclass
class SamplingConfig:
    """Window-sampling strategy."""

    method: str = "truncated_gaussian"
    fs: int = 250
    window_seconds: float = 10.0
    gaussian: GaussianSamplingConfig = field(default_factory=GaussianSamplingConfig)


@dataclass
class ResampleConfig:
    """Resample pipeline configuration."""

    targets: Any = None  # list[str] or None
    samples_per_subject: int = 16
    samples_per_segment: int = 8
    permute_trials: bool = True
    save_format: str = "pt"
    seed: int = 42
    save_config_snapshot: bool = True
    save_stats: bool = True
    sampling: SamplingConfig = field(default_factory=SamplingConfig)
    filter_group_label: Optional[int] = None


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class DataConfig:
    """Data-path configuration."""

    index_dir: str = ""
    resample_output_dir: str = ""
    test_dir: str = ""
    manifests: dict[str, Any] = field(default_factory=dict)
    config_snapshots: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Model sub-configs
# ---------------------------------------------------------------------------

@dataclass
class TokenEmbeddingConfig:
    """Token embedding settings for the trial encoder."""

    use_channel_embedding: bool = True
    use_band_embedding: bool = True
    use_cls_token: bool = True
    embedding_dim: int = 128


@dataclass
class TransformerConfig:
    """Transformer encoder hyper-parameters."""

    num_layers: int = 2
    num_heads: int = 4
    dim_feedforward: int = 256
    dropout: float = 0.1
    activation: str = "gelu"
    norm_first: bool = True
    batch_first: bool = True


@dataclass
class TrialEncoderConfig:
    """Single-trial CNN-Transformer encoder settings."""

    projection_dim: int = 128
    cnn_channels: list[int] = field(default_factory=lambda: [16, 32, 64])
    kernel_sizes: list[int] = field(default_factory=lambda: [15, 9, 5])
    strides: list[int] = field(default_factory=lambda: [2, 2, 2])
    cnn_dropout: float = 0.1
    pooling: str = "cls"
    token_embedding: TokenEmbeddingConfig = field(default_factory=TokenEmbeddingConfig)
    transformer: TransformerConfig = field(default_factory=TransformerConfig)


@dataclass
class SubjectTransformerConfig:
    """Subject-level Transformer encoder settings."""

    use_cls_token: bool = True
    use_trial_position_embedding: bool = True
    embedding_dim: int = 128
    num_layers: int = 2
    num_heads: int = 4
    dim_feedforward: int = 256
    dropout: float = 0.1
    activation: str = "gelu"
    norm_first: bool = True
    batch_first: bool = True


@dataclass
class ClassificationHeadConfig:
    """Classification head MLP settings."""

    hidden_dims: list[int] = field(default_factory=lambda: [128])
    dropout: float = 0.3


@dataclass
class ModelConfig:
    """Full model architecture definition."""

    class_name: str = ""
    input_num_trials: int = 8
    input_length: int = 2500
    input_channels: int = 0
    num_classes: int = 2
    trial_encoder: TrialEncoderConfig = field(default_factory=TrialEncoderConfig)
    subject_transformer: Optional[SubjectTransformerConfig] = None
    classification_head: ClassificationHeadConfig = field(
        default_factory=ClassificationHeadConfig,
    )


# ---------------------------------------------------------------------------
# Training sub-configs
# ---------------------------------------------------------------------------

@dataclass
class OptimizerConfig:
    """Optimizer hyper-parameters."""

    type: str = "adamw"
    lr: float = 1e-3
    weight_decay: float = 1e-4
    betas: list[float] = field(default_factory=lambda: [0.9, 0.999])
    eps: float = 1e-8
    momentum: float = 0.9
    nesterov: bool = False
    amsgrad: bool = False


@dataclass
class SchedulerConfig:
    """Learning-rate scheduler hyper-parameters.

    Only a subset of fields are relevant for each scheduler *type*.
    """

    type: str = "cosine"
    min_lr: float = 1e-6
    warmup_epochs: int = 5
    cosine_t_max: int = 0
    cosine_eta_min: float = 0.0
    warmrestart_t0: int = 10
    warmrestart_t_mult: int = 2
    step_size: int = 0
    step_gamma: float = 0.1
    plateau_factor: float = 0.5
    plateau_patience: int = 5
    plateau_mode: str = "max"
    onecycle_pct_start: float = 0.3


@dataclass
class GaussianNoiseConfig:
    """Gaussian-noise augmentation settings."""

    enabled: bool = False
    std: float = 0.01


@dataclass
class TimeMaskConfig:
    """Time-mask augmentation settings."""

    enabled: bool = False
    max_mask_ratio: float = 0.1


@dataclass
class ChannelDropoutConfig:
    """Channel-dropout augmentation settings."""

    enabled: bool = False
    drop_prob: float = 0.1


@dataclass
class AugmentationConfig:
    """Augmentation pipeline settings."""

    enabled: bool = False
    gaussian_noise: GaussianNoiseConfig = field(default_factory=GaussianNoiseConfig)
    time_mask: TimeMaskConfig = field(default_factory=TimeMaskConfig)
    channel_dropout: ChannelDropoutConfig = field(default_factory=ChannelDropoutConfig)


@dataclass
class SplittingConfig:
    """Train/val splitting strategy."""

    method: str = "StratifiedGroupKFold"
    n_splits: int = 5
    group_key: str = "subject_id"
    stratify_key: str = ""
    seed: int = 42


@dataclass
class SeedingConfig:
    """Random seed configuration."""

    random_seed: int = 42
    split_seed: int = 42
    init_seed: int = 42


@dataclass
class EarlyStopConfig:
    """Early stopping configuration."""

    enable: bool = True
    patience: int = 15
    early_metric: str = "val_balanced_accuracy"
    metric_mode: str = "max"
    up_delta: float = 1e-6


@dataclass
class MonitorBestConfig:
    """Best-checkpoint monitoring configuration."""

    monitor_metric: str = "val_balanced_accuracy"
    metric_mode: str = "max"
    save_latest: bool = True
    save_best_auc: bool = False
    save_best_acc: bool = True


@dataclass
class TrainingConfig:
    """Training loop hyper-parameters."""

    epochs: int = 100
    batch_size: int = 16
    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    scheduler: SchedulerConfig = field(default_factory=SchedulerConfig)
    loss: str = "cross_entropy"
    focal_gamma: float = 2.0
    class_weight: Optional[Any] = None
    gradient_clip_val: float = 0.0
    accumulate_grad_batches: int = 1
    mixed_precision: bool = False
    num_workers: int = 4
    early_stop: EarlyStopConfig = field(default_factory=EarlyStopConfig)
    monitor_best: MonitorBestConfig = field(default_factory=MonitorBestConfig)
    # Legacy flat keys (kept for backward compat, overridden by nested config)
    early_stopping_patience: int = 15
    checkpoint_metric: str = ""
    save_latest: bool = True
    save_best: bool = True


# ---------------------------------------------------------------------------
# Task & ModelGroup
# ---------------------------------------------------------------------------

@dataclass
class TaskConfig:
    """Dataset / task definition."""

    name: str = ""
    dataset_class: str = ""
    num_classes: int = 2
    label_names: list[str] = field(default_factory=list)


@dataclass
class ModelGroupConfig:
    """A complete model-group (task + architecture + training + data)."""

    task: TaskConfig = field(default_factory=TaskConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    training: TrainingConfig = field(default_factory=TrainingConfig)
    augmentation: AugmentationConfig = field(default_factory=AugmentationConfig)
    splitting: SplittingConfig = field(default_factory=SplittingConfig)
    seeding: SeedingConfig = field(default_factory=SeedingConfig)
    data: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Infrastructure
# ---------------------------------------------------------------------------

@dataclass
class LoggingConfig:
    """Logging settings."""

    level: str = "INFO"
    format: str = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    log_every_n_steps: int = 10


@dataclass
class ExperimentConfig:
    """Experiment directory and checkpoint settings."""

    name: str = "default"
    save_dir: str = "experiments"
    save_best: bool = True
    save_latest: bool = True
    checkpoint_metric: str = ""
    monitor_metrics: list[str] = field(default_factory=list)

    @property
    def experiment_dir(self) -> Path:
        return Path(self.save_dir) / self.name

    @property
    def checkpoint_dir(self) -> Path:
        return self.experiment_dir / "checkpoints"

    @property
    def log_dir(self) -> Path:
        return self.experiment_dir / "logs"

    @property
    def result_dir(self) -> Path:
        return self.experiment_dir / "results"

    @property
    def metrics_dir(self) -> Path:
        return self.experiment_dir / "metrics"


@dataclass
class InferenceModelConfig:
    """Single inference model entry."""

    checkpoint: str = ""
    config: str = ""


@dataclass
class InferenceConfig:
    """Multi-model inference routing settings."""

    routing: str = "hard"
    use_4_4_constraint: bool = True
    positive_label: int = 1
    neutral_label: int = 0
    output_format: str = "xlsx"
    test_dir: str = "dataset/公开测试集"
    test_index_file: str = "data/index/test_subjects.csv"
    models: dict[str, InferenceModelConfig] = field(default_factory=dict)


@dataclass
class MetricConfig:
    """Evaluation metric settings."""

    primary: str = "balanced_accuracy"
    report: list[str] = field(
        default_factory=lambda: [
            "accuracy",
            "balanced_accuracy",
            "f1_macro",
            "precision_macro",
            "recall_macro",
        ],
    )


# ---------------------------------------------------------------------------
# Top-level Config
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """Root configuration object aggregating all sub-configs.

    Methods
    -------
    get_model_config(name)
        Return the ``ModelConfig`` for a named model group.
    model_names()
        List all model-group names.
    config_snapshot()
        Serialize the entire config to a plain dict.
    runtime_config_display_sections()
        Return sections of the config for CLI display.
    """

    project: ProjectConfig = field(default_factory=ProjectConfig)
    signal: SignalConfig = field(default_factory=SignalConfig)
    channels: ChannelsConfig = field(default_factory=ChannelsConfig)
    band: BandConfig = field(default_factory=BandConfig)
    resample: ResampleConfig = field(default_factory=ResampleConfig)
    data: DataConfig = field(default_factory=DataConfig)
    models: dict[str, ModelGroupConfig] = field(default_factory=dict)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    experiment: ExperimentConfig = field(default_factory=ExperimentConfig)
    inference: InferenceConfig = field(default_factory=InferenceConfig)
    metrics: MetricConfig = field(default_factory=MetricConfig)

    # -- accessors -----------------------------------------------------------

    def get_model_config(self, name: str) -> "ModelGroupConfig":
        """Return the full :class:`ModelGroupConfig` for model group *name*.

        Parameters
        ----------
        name:
            Model-group name (key in ``self.models``).

        Returns
        -------
        ModelGroupConfig

        Raises
        ------
        KeyError
            If *name* is not in ``self.models``.
        """
        if name not in self.models:
            raise KeyError(
                f"Unknown model group '{name}'. "
                f"Available: {list(self.models.keys())}"
            )
        return self.models[name]

    def model_names(self) -> list[str]:
        """Return model-group names in insertion order (Python 3.7+ guarantees dict ordering)."""
        return list(self.models.keys())

    def config_snapshot(self) -> dict[str, Any]:
        """Serialize the full config to a JSON-compatible dict."""
        return _dataclass_to_dict(self)

    def runtime_config_display_sections(self) -> dict[str, Any]:
        """Return a dict of sections suitable for CLI display.

        Includes global sections and per-model configuration panels.
        Nested configs (optimizer, scheduler, model architecture) are
        flattened to dotted-key format for readability.
        """
        sections: dict[str, Any] = {
            "project": _dataclass_to_dict(self.project),
            "signal": _dataclass_to_dict(self.signal),
            "channels": _dataclass_to_dict(self.channels),
            "band": _dataclass_to_dict(self.band),
            "experiment": _dataclass_to_dict(self.experiment),
            "logging": _dataclass_to_dict(self.logging),
            "metrics": _dataclass_to_dict(self.metrics),
        }

        for name, mc in self.models.items():
            sections[f"{name} - task"] = _dataclass_to_dict(mc.task)
            sections[f"{name} - model"] = _flatten_model_config(mc.model)
            sections[f"{name} - training"] = _flatten_training_config(mc.training)
            sections[f"{name} - splitting"] = _dataclass_to_dict(mc.splitting)
            sections[f"{name} - seeding"] = _dataclass_to_dict(mc.seeding)
            sections[f"{name} - augmentation"] = _dataclass_to_dict(mc.augmentation)

        return sections
