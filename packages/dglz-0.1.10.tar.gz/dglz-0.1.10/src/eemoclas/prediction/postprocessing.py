import torch


def apply_4_4_constraint(pos_probs: torch.Tensor) -> torch.Tensor:
    """
    Apply 4:4 constraint: exactly 4 positive, 4 neutral.

    Args:
        pos_probs: [8] tensor of positive probabilities

    Returns:
        labels: [8] tensor of 0/1 labels, exactly 4 ones

    Implementation:
    1. Sort by positive probability descending
    2. Top 4 indices get label 1
    3. Rest get label 0
    """
    if pos_probs.numel() != 8:
        raise ValueError(f"Expected 8 trials, got {pos_probs.numel()}")

    top4_indices = torch.argsort(pos_probs, descending=True)[:4]
    labels = torch.zeros(8, dtype=torch.long)
    labels[top4_indices] = 1
    return labels
