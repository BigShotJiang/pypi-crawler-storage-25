import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from pathlib import Path


class Predictor:
    """Single-model predictor for debugging."""

    def __init__(self, model: nn.Module, device: torch.device, config: dict):
        self.model = model
        self.device = device
        self.config = config

    def predict(self, dataloader) -> pd.DataFrame:
        """
        Run inference on a DataLoader.
        Returns DataFrame with columns: sample_id, y_pred, y_prob_0, y_prob_1
        """
        self.model.eval()
        results = []

        with torch.no_grad():
            for batch in dataloader:
                x = batch["x"].to(self.device)
                token_meta = batch.get("token_meta", None)

                logits = self.model(x, token_meta=token_meta)
                probs = torch.softmax(logits, dim=-1)
                preds = torch.argmax(logits, dim=-1)

                # Collect results
                for i in range(len(preds)):
                    results.append({
                        "y_pred": preds[i].item(),
                        "y_prob_0": probs[i, 0].item(),
                        "y_prob_1": probs[i, 1].item(),
                    })

        return pd.DataFrame(results)
