"""Channel selection utilities.

Maps human-readable channel specifications (names, 1-based indices, or
0-based indices) to the 0-based integer indices used throughout the
pipeline, then slices an EEG array accordingly.
"""

from __future__ import annotations

from typing import Any

import numpy as np

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CHANNEL_NAMES: list[str] = [
    "FP1", "FP2", "F7", "F3", "FZ", "F4", "F8", "FT7", "FC3", "FCZ",
    "FC4", "FT8", "T3", "C3", "CZ", "C4", "T4", "TP7", "CP3", "CPZ",
    "CP4", "TP8", "T5", "P3", "PZ", "P4", "T6", "O1", "OZ", "O2",
]
"""30 standard EEG channel names in the order used by the DGLZ dataset."""

_CHANNEL_COUNT: int = len(CHANNEL_NAMES)  # 30

_NAME_TO_INDEX: dict[str, int] = {name.upper(): idx for idx, name in enumerate(CHANNEL_NAMES)}

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def resolve_channels(config: dict[str, Any]) -> tuple[list[int], list[str]]:
    """Resolve channel selection from a pipeline configuration dict.

    The *config* dictionary is expected to contain a ``"channels"`` key
    with the following sub-keys:

    * ``mode`` -- one of ``"by_name"``, ``"by_index_1based"``,
      ``"by_index_0based"``.
    * ``selected`` -- ``"all"`` or a list of channel identifiers whose
      type depends on *mode*.

    Parameters
    ----------
    config : dict
        Full or partial pipeline configuration.  Must contain
        ``config["channels"]["mode"]`` and
        ``config["channels"]["selected"]``.

    Returns
    -------
    tuple[list[int], list[str]]
        ``(selected_indices_0based, selected_names)`` in the same order
        as specified by the user.

    Raises
    ------
    KeyError
        If required configuration keys are missing.
    ValueError
        If a channel name or index is invalid.
    """
    ch_cfg = config["channels"]
    mode: str = ch_cfg["mode"]
    selected: Any = ch_cfg["selected"]

    # Shortcut: all channels
    if selected == "all":
        return list(range(_CHANNEL_COUNT)), list(CHANNEL_NAMES)

    if not isinstance(selected, list) or len(selected) == 0:
        raise ValueError(
            f"'channels.selected' must be 'all' or a non-empty list, got {selected!r}."
        )

    indices: list[int] = []
    names: list[str] = []

    if mode == "by_name":
        for name in selected:
            key = name.upper()
            if key not in _NAME_TO_INDEX:
                raise ValueError(
                    f"Unknown channel name '{name}'.  "
                    f"Available: {CHANNEL_NAMES}."
                )
            idx = _NAME_TO_INDEX[key]
            indices.append(idx)
            names.append(CHANNEL_NAMES[idx])

    elif mode == "by_index_1based":
        for raw in selected:
            idx = int(raw) - 1
            if not 0 <= idx < _CHANNEL_COUNT:
                raise ValueError(
                    f"1-based index {raw} is out of range [1, {_CHANNEL_COUNT}]."
                )
            indices.append(idx)
            names.append(CHANNEL_NAMES[idx])

    elif mode == "by_index_0based":
        for raw in selected:
            idx = int(raw)
            if not 0 <= idx < _CHANNEL_COUNT:
                raise ValueError(
                    f"0-based index {idx} is out of range [0, {_CHANNEL_COUNT - 1}]."
                )
            indices.append(idx)
            names.append(CHANNEL_NAMES[idx])

    else:
        raise ValueError(
            f"Unknown channels.mode '{mode}'.  "
            f"Expected one of: 'by_name', 'by_index_1based', 'by_index_0based'."
        )

    return indices, names


def select_channels(
    eeg: np.ndarray,
    selected_indices: list[int],
) -> np.ndarray:
    """Select a subset of channels from an EEG array.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(30, T)`` (or ``(C, T)`` where ``C >= max(selected_indices)``).
    selected_indices : list[int]
        0-based channel indices to keep, in the desired output order.

    Returns
    -------
    np.ndarray
        Shape ``(C_selected, T)`` containing only the selected channels.

    Raises
    ------
    ValueError
        If *eeg* is not 2-D, or any index is out of range.
    """
    if eeg.ndim != 2:
        raise ValueError(f"Expected 2-D array, got {eeg.ndim}-D (shape {eeg.shape}).")
    if len(selected_indices) == 0:
        raise ValueError("selected_indices must be a non-empty list.")

    max_ch = eeg.shape[0]
    for idx in selected_indices:
        if not 0 <= idx < max_ch:
            raise ValueError(
                f"Channel index {idx} is out of range for array with "
                f"{max_ch} channels."
            )

    return eeg[selected_indices, :].copy()
