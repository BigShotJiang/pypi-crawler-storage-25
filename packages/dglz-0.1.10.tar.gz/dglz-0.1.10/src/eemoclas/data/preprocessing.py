"""Unified preprocessing API for the resampling pipeline.

This module exposes high-level helpers that combine channel selection,
band-pass filtering, z-score normalisation, and clipping into a single
callable interface used by all three resamplers.

The underlying implementations live in:
- :mod:`eemoclas.data.channel_selector` -- channel resolution and slicing
- :mod:`eemoclas.data.band_filter` -- Butterworth band-pass with virtual-channel expansion
- :mod:`eemoclas.data.eeg_transform` -- z-score + clip

Only the *resamplers* import from this module.  Downstream training /
inference code should use the lower-level modules directly so that each
step can be configured independently.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from eemoclas.data.channel_selector import CHANNEL_NAMES, resolve_channels, select_channels
from eemoclas.data.band_filter import apply_channel_band_filter
from eemoclas.data.eeg_transform import preprocess_trial


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# Default band definitions and channel-band config used when the caller
# does not supply explicit ones.
DEFAULT_BAND_DEFINITIONS: dict[str, list[float]] = {
    "delta": [1, 4],
    "theta": [4, 7],
    "alpha": [8, 13],
    "beta": [13, 30],
    "low_gamma": [30, 45],
    "broadband": [1, 45],
}

DEFAULT_CHANNEL_BAND_CONFIG: dict[str, Any] = {
    "default_bands": ["broadband"],
    "per_channel": {},
}


def channel_select(
    eeg: np.ndarray,
    channel_set: str = "all",
    *,
    return_meta: bool = False,
    config: dict | None = None,
    band_definitions: dict[str, list[float]] | None = None,
    channel_band_config: dict[str, Any] | None = None,
    fs: int = 250,
    filter_order: int = 4,
) -> np.ndarray | tuple[np.ndarray, list[dict]]:
    """Select channels, apply band-pass filters, and optionally return token_meta.

    When *return_meta* is ``True`` the function returns
    ``(filtered_array, token_meta)`` where *token_meta* is the list of
    virtual-channel metadata dicts produced by
    :func:`~eemoclas.data.band_filter.apply_channel_band_filter`.

    When *return_meta* is ``False`` (default) only the filtered array is
    returned.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(30, T)`` -- full-channel EEG data.
    channel_set : str
        ``"all"`` to keep all 30 channels, or ``"standard"`` (also all 30).
        For custom channel selection pass a *config* dict with a
        ``"channels"`` key.
    return_meta : bool
        Whether to also return the token_meta list.
    config : dict | None
        Full pipeline config.  Used only when *channel_set* is not
        ``"all"``/``"standard"`` to resolve custom channel selection.
    band_definitions : dict | None
        Frequency band definitions.  Defaults to
        :data:`DEFAULT_BAND_DEFINITIONS`.
    channel_band_config : dict | None
        Per-channel band selection.  Defaults to
        :data:`DEFAULT_CHANNEL_BAND_CONFIG`.
    fs : int
        Sampling frequency in Hz.
    filter_order : int
        Butterworth filter order.

    Returns
    -------
    np.ndarray | tuple[np.ndarray, list[dict]]
    """
    if band_definitions is None:
        band_definitions = DEFAULT_BAND_DEFINITIONS
    if channel_band_config is None:
        channel_band_config = DEFAULT_CHANNEL_BAND_CONFIG

    # Resolve selected channels.
    if channel_set in ("all", "standard"):
        selected_indices = list(range(len(CHANNEL_NAMES)))
        selected_names = list(CHANNEL_NAMES)
    elif config is not None:
        selected_indices, selected_names = resolve_channels(config)
    else:
        # Fallback: all channels.
        selected_indices = list(range(len(CHANNEL_NAMES)))
        selected_names = list(CHANNEL_NAMES)

    # Step 1: select physical channels.
    selected = select_channels(eeg, selected_indices)

    # Step 2: apply band-pass filter -> virtual channels.
    filtered, token_meta = apply_channel_band_filter(
        selected,
        selected_channel_names=selected_names,
        selected_indices=selected_indices,
        band_definitions=band_definitions,
        channel_band_config=channel_band_config,
        fs=fs,
        filter_order=filter_order,
    )

    if return_meta:
        return filtered, token_meta
    return filtered


def bandpass_filter(
    eeg: np.ndarray,
    fs: int = 250,
    *,
    config: dict | None = None,
    band_definitions: dict[str, list[float]] | None = None,
    channel_band_config: dict[str, Any] | None = None,
    selected_channel_names: list[str] | None = None,
    selected_indices: list[int] | None = None,
    filter_order: int = 4,
) -> np.ndarray:
    """Apply band-pass filtering on an already channel-selected EEG array.

    This is a thin wrapper around
    :func:`~eemoclas.data.band_filter.apply_channel_band_filter` that
    discards the token_meta (only returns the filtered array).

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(C_selected, T)``.
    fs : int
        Sampling frequency.

    Returns
    -------
    np.ndarray
        Shape ``(C_eff, T)``.
    """
    if band_definitions is None:
        band_definitions = DEFAULT_BAND_DEFINITIONS
    if channel_band_config is None:
        channel_band_config = DEFAULT_CHANNEL_BAND_CONFIG

    if selected_channel_names is None or selected_indices is None:
        # Assume all channels in order.
        n_ch = eeg.shape[0]
        selected_channel_names = list(CHANNEL_NAMES[:n_ch])
        selected_indices = list(range(n_ch))

    filtered, _ = apply_channel_band_filter(
        eeg,
        selected_channel_names=selected_channel_names,
        selected_indices=selected_indices,
        band_definitions=band_definitions,
        channel_band_config=channel_band_config,
        fs=fs,
        filter_order=filter_order,
    )
    return filtered


def z_score(
    eeg: np.ndarray,
    eps: float = 1e-6,
) -> np.ndarray:
    """Per-channel z-score normalisation along the time axis.

    Equivalent to the first step of
    :func:`~eemoclas.data.eeg_transform.preprocess_trial` but returns a
    NumPy array instead of a Torch tensor and does **not** apply clipping.
    """
    x = eeg.astype(np.float64)
    ch_means = x.mean(axis=1, keepdims=True)
    ch_stds = x.std(axis=1, keepdims=True)
    return (x - ch_means) / (ch_stds + eps)


def clip_signal(
    eeg: np.ndarray,
    clip_std: float = 5.0,
) -> np.ndarray:
    """Symmetric clipping to ``[-clip_std, clip_std]``."""
    return np.clip(eeg, -clip_std, clip_std)
