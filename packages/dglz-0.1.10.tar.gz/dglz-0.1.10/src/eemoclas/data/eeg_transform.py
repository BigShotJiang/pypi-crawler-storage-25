"""Per-trial EEG preprocessing: z-score normalisation and clipping.

The standard preprocessing order is:

1. **Per-channel z-score** along the time axis.
2. **Clip** to a symmetric range ``[-clip_std, clip_std]``.
3. **Convert** to a ``torch.FloatTensor``.
"""

from __future__ import annotations

import numpy as np
import torch

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def preprocess_trial(
    eeg: np.ndarray,
    clip_std: float = 5.0,
    zscore_eps: float = 1e-6,
    zscore_enabled: bool = True,
) -> torch.FloatTensor:
    """Preprocess a single trial for model input.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(C_eff, T)`` where *C_eff* is the effective (virtual)
        channel count and *T* is the number of time samples.
    clip_std : float, optional
        Symmetric clipping threshold applied after z-scoring.
        Default ``5.0``.
    zscore_eps : float, optional
        Small constant added to the standard deviation to avoid division
        by zero.  Default ``1e-6``.
    zscore_enabled : bool, optional
        If *False*, skip z-scoring and only apply clipping.  Default
        *True*.

    Returns
    -------
    torch.FloatTensor
        Shape ``(C_eff, T)``, ready for model consumption.

    Raises
    ------
    ValueError
        If *eeg* is not 2-D.
    """
    if eeg.ndim != 2:
        raise ValueError(f"Expected 2-D array, got {eeg.ndim}-D (shape {eeg.shape}).")

    x = eeg.astype(np.float64)

    # 1) Per-channel z-score along the time axis
    if zscore_enabled:
        ch_means = x.mean(axis=1, keepdims=True)
        ch_stds = x.std(axis=1, keepdims=True)
        x = (x - ch_means) / (ch_stds + zscore_eps)

    # 2) Clip
    x = np.clip(x, -clip_std, clip_std)

    # 3) To torch tensor
    return torch.from_numpy(x).float()
