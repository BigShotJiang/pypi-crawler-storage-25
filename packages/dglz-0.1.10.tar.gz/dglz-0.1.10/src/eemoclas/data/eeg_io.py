"""EEG .mat file I/O with auto-transpose support.

Reads MATLAB .mat files produced by the DGLZ EEG emotion recognition
pipeline.  All returned arrays follow the convention
``(channels, time_samples)`` regardless of how the data is stored on disk.
"""

from __future__ import annotations

import re
from typing import Optional

import numpy as np
from scipy.io import loadmat

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CHANNEL_COUNT: int = 30
"""Expected number of EEG channels in every recording."""

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_IGNORE_KEYS = frozenset({
    "__header__", "__version__", "__globals__",
    "__dict__", "__function__",
})


def _is_data_key(key: str) -> bool:
    """Return *True* if *key* looks like a MATLAB data variable (not metadata)."""
    return key not in _IGNORE_KEYS and not key.startswith("_")


def _auto_transpose(arr: np.ndarray, expected_channels: int) -> np.ndarray:
    """Transpose *arr* so that ``axis-0 == expected_channels``.

    Accepts shapes ``(expected_channels, T)`` or ``(T, expected_channels)``.
    Raises ``ValueError`` when neither dimension matches *expected_channels*.
    """
    if arr.ndim != 2:
        raise ValueError(
            f"Expected a 2-D array, got array with {arr.ndim} dimensions "
            f"(shape {arr.shape})."
        )
    rows, cols = arr.shape
    if rows == expected_channels:
        return arr.astype(np.float64)
    if cols == expected_channels:
        return arr.T.astype(np.float64)
    raise ValueError(
        f"Neither dimension matches expected channel count {expected_channels}: "
        f"array shape is {arr.shape}."
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_train_mat(
    mat_path: str,
    neu_key: str = "EEG_data_neu",
    pos_key: str = "EEG_data_pos",
) -> dict[str, np.ndarray]:
    """Load a training .mat file and return neutral / positive arrays.

    Parameters
    ----------
    mat_path : str
        Path to the ``.mat`` file on disk.
    neu_key : str, optional
        Variable name for the neutral-emotion EEG block inside the .mat
        file.  Defaults to ``"EEG_data_neu"``.
    pos_key : str, optional
        Variable name for the positive-emotion EEG block.  Defaults to
        ``"EEG_data_pos"``.

    Returns
    -------
    dict[str, np.ndarray]
        ``{"EEG_data_neu": ndarray[30, 50000], "EEG_data_pos": ndarray[30, 50000]}``

    Raises
    ------
    FileNotFoundError
        If *mat_path* does not exist.
    KeyError
        If either *neu_key* or *pos_key* is absent from the file.
    ValueError
        If the loaded arrays cannot be reconciled to ``(30, T)``.
    """
    result: dict[str, np.ndarray] = {}

    # Try scipy.io.loadmat first (works for MATLAB < v7.3).
    try:
        mat = loadmat(mat_path)

        missing = [k for k in (neu_key, pos_key) if k not in mat]
        if missing:
            available = [k for k in mat if _is_data_key(k)]
            raise KeyError(
                f"Key(s) {missing} not found in '{mat_path}'.  "
                f"Available data keys: {available}"
            )

        for key in (neu_key, pos_key):
            arr = np.asarray(mat[key], dtype=np.float64)
            result[key] = _auto_transpose(arr, CHANNEL_COUNT)

        return result

    except NotImplementedError:
        # MATLAB v7.3 (HDF5) files -- fall back to h5py.
        pass

    # h5py fallback for MATLAB v7.3 files.
    try:
        import h5py
    except ImportError:
        raise ImportError(
            "h5py is required to read MATLAB v7.3 .mat files.  "
            "Install it with: pip install h5py"
        )

    with h5py.File(mat_path, "r") as f:
        missing = [k for k in (neu_key, pos_key) if k not in f]
        if missing:
            available = list(f.keys())
            raise KeyError(
                f"Key(s) {missing} not found in '{mat_path}'.  "
                f"Available keys: {available}"
            )

        for key in (neu_key, pos_key):
            arr = np.asarray(f[key], dtype=np.float64)
            result[key] = _auto_transpose(arr, CHANNEL_COUNT)

    return result


def load_test_mat(
    mat_path: str,
    candidate_keys: Optional[list[str]] = None,
    auto_detect: bool = True,
) -> np.ndarray:
    """Load a test .mat file and return the EEG matrix.

    Parameters
    ----------
    mat_path : str
        Path to the ``.mat`` file on disk.
    candidate_keys : list[str] | None, optional
        Ordered list of variable names to try.  The first key whose value
        is a 2-D array with one dimension equal to ``30`` is returned.
    auto_detect : bool, optional
        If *True* and none of *candidate_keys* matched, scan **all**
        top-level keys in the .mat file for a compatible 2-D array.

    Returns
    -------
    np.ndarray
        Shape ``(30, T)`` -- typically ``(30, 20000)``.

    Raises
    ------
    FileNotFoundError
        If *mat_path* does not exist.
    ValueError
        If no suitable EEG matrix can be located.
    """
    # Try scipy.io.loadmat first.
    try:
        mat = loadmat(mat_path)
    except NotImplementedError:
        # MATLAB v7.3 -- use h5py.
        return _load_test_hdf5(mat_path, candidate_keys, auto_detect)

    def _try_keys(keys: list[str]) -> Optional[np.ndarray]:
        for key in keys:
            if key not in mat:
                continue
            arr = np.asarray(mat[key])
            if arr.ndim != 2:
                continue
            try:
                return _auto_transpose(arr, CHANNEL_COUNT)
            except ValueError:
                continue
        return None

    # 1) Try candidate keys first
    if candidate_keys:
        result = _try_keys(candidate_keys)
        if result is not None:
            return result

    # 2) Auto-detect: scan every data-like key
    if auto_detect:
        all_keys = [k for k in mat if _is_data_key(k)]
        result = _try_keys(all_keys)
        if result is not None:
            return result

    available = [k for k in mat if _is_data_key(k)]
    raise ValueError(
        f"Could not find a {CHANNEL_COUNT}-channel EEG matrix in '{mat_path}'.  "
        f"Available data keys: {available}.  Try passing explicit candidate_keys."
    )


def _load_test_hdf5(
    mat_path: str,
    candidate_keys: Optional[list[str]] = None,
    auto_detect: bool = True,
) -> np.ndarray:
    """Load a test .mat file using h5py (MATLAB v7.3)."""
    import h5py

    def _try_keys(f: h5py.File, keys: list[str]) -> Optional[np.ndarray]:
        for key in keys:
            if key not in f:
                continue
            arr = np.asarray(f[key], dtype=np.float64)
            if arr.ndim != 2:
                continue
            try:
                return _auto_transpose(arr, CHANNEL_COUNT)
            except ValueError:
                continue
        return None

    with h5py.File(mat_path, "r") as f:
        if candidate_keys:
            result = _try_keys(f, candidate_keys)
            if result is not None:
                return result

        if auto_detect:
            all_keys = list(f.keys())
            result = _try_keys(f, all_keys)
            if result is not None:
                return result

        available = list(f.keys())
        raise ValueError(
            f"Could not find a {CHANNEL_COUNT}-channel EEG matrix in '{mat_path}'.  "
            f"Available keys: {available}.  Try passing explicit candidate_keys."
        )
