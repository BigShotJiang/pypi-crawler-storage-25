"""EEG array splitting utilities.

Training recordings ``(30, 50000)`` are split into 4 emotion segments.
Test recordings ``(30, 20000)`` are split into 8 short trials.
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TRAIN_TOTAL_SAMPLES: int = 50_000
TRAIN_SEGMENTS: int = 4
TRAIN_SEGMENT_LENGTH: int = TRAIN_TOTAL_SAMPLES // TRAIN_SEGMENTS  # 12 500

TEST_TOTAL_SAMPLES: int = 20_000
TEST_TRIALS: int = 8
TEST_TRIAL_LENGTH: int = TEST_TOTAL_SAMPLES // TEST_TRIALS  # 2 500

CHANNEL_COUNT: int = 30

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def split_train_emotion(eeg: np.ndarray) -> list[np.ndarray]:
    """Split a training EEG recording into 4 equal emotion segments.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(30, 50000)`` -- the full training recording.

    Returns
    -------
    list[np.ndarray]
        Four arrays, each of shape ``(30, 12500)``:
        segment 0 covers time ``0:12500``, segment 1 covers
        ``12500:25000``, etc.

    Raises
    ------
    ValueError
        If *eeg* does not have shape ``(30, 50000)``.
    """
    if eeg.ndim != 2:
        raise ValueError(f"Expected 2-D array, got {eeg.ndim}-D (shape {eeg.shape}).")
    if eeg.shape[0] != CHANNEL_COUNT:
        raise ValueError(
            f"Expected {CHANNEL_COUNT} channels (axis-0), got {eeg.shape[0]}."
        )
    if eeg.shape[1] != TRAIN_TOTAL_SAMPLES:
        raise ValueError(
            f"Expected {TRAIN_TOTAL_SAMPLES} time samples (axis-1), "
            f"got {eeg.shape[1]}."
        )

    segments: list[np.ndarray] = []
    for i in range(TRAIN_SEGMENTS):
        start = i * TRAIN_SEGMENT_LENGTH
        end = start + TRAIN_SEGMENT_LENGTH
        segments.append(eeg[:, start:end].copy())

    return segments


def split_test_trials(eeg: np.ndarray) -> list[np.ndarray]:
    """Split a test EEG recording into 8 short trials.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(30, 20000)`` -- the full test recording.

    Returns
    -------
    list[np.ndarray]
        Eight arrays, each of shape ``(30, 2500)``.

    Raises
    ------
    ValueError
        If *eeg* does not have shape ``(30, 20000)``.
    """
    if eeg.ndim != 2:
        raise ValueError(f"Expected 2-D array, got {eeg.ndim}-D (shape {eeg.shape}).")
    if eeg.shape[0] != CHANNEL_COUNT:
        raise ValueError(
            f"Expected {CHANNEL_COUNT} channels (axis-0), got {eeg.shape[0]}."
        )
    if eeg.shape[1] != TEST_TOTAL_SAMPLES:
        raise ValueError(
            f"Expected {TEST_TOTAL_SAMPLES} time samples (axis-1), "
            f"got {eeg.shape[1]}."
        )

    trials: list[np.ndarray] = []
    for i in range(TEST_TRIALS):
        start = i * TEST_TRIAL_LENGTH
        end = start + TEST_TRIAL_LENGTH
        trials.append(eeg[:, start:end].copy())

    return trials
