"""Per-channel Butterworth band-pass filter with virtual-channel expansion.

Each (physical-channel, frequency-band) pair is treated as a separate
*virtual channel*, expanding the channel dimension of the EEG array.
A ``token_meta`` list is produced alongside the filtered data so that
downstream modules can trace every virtual channel back to its source.
"""

from __future__ import annotations

from typing import Any

import numpy as np
from scipy.signal import butter, sosfiltfilt

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NYQUIST_FACTOR = 0.5  # fs / 2

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_bands_for_channel(
    channel_name: str,
    band_definitions: dict[str, list[float]],
    channel_band_config: dict[str, Any],
) -> list[tuple[str, float, float]]:
    """Return ``[(band_name, low, high), ...]`` for a single channel.

    Lookup order:
    1. ``channel_band_config["per_channel"][channel_name]`` (if present).
    2. ``channel_band_config["default_bands"]``.

    Each band name is resolved against *band_definitions* to obtain the
    ``(low, high)`` frequency pair.
    """
    per_channel: dict[str, list[str]] = channel_band_config.get("per_channel", {})
    default_bands: list[str] = channel_band_config.get("default_bands", ["broadband"])

    band_names: list[str] = per_channel.get(channel_name, default_bands)

    resolved: list[tuple[str, float, float]] = []
    for bname in band_names:
        if bname not in band_definitions:
            raise ValueError(
                f"Band '{bname}' referenced for channel '{channel_name}' "
                f"is not defined in band_definitions.  "
                f"Available: {list(band_definitions.keys())}."
            )
        lo, hi = band_definitions[bname]
        resolved.append((bname, float(lo), float(hi)))
    return resolved


def _validate_band(low: float, high: float, fs: int) -> None:
    """Raise ``ValueError`` if a band definition is physically invalid."""
    nyq = fs * _NYQUIST_FACTOR
    if not (0 < low < high < nyq):
        raise ValueError(
            f"Invalid band [{low}, {high}] for fs={fs}.  "
            f"Requirement: 0 < low < high < fs/2 ({nyq})."
        )


def _bandpass_filter(
    signal_1d: np.ndarray,
    low: float,
    high: float,
    fs: int,
    order: int,
) -> np.ndarray:
    """Zero-phase Butterworth band-pass filter for a single 1-D signal.

    Uses ``scipy.signal.butter(output="sos")`` followed by
    ``scipy.signal.sosfiltfilt`` for zero-phase (causality-preserving)
    filtering.
    """
    nyq = fs * _NYQUIST_FACTOR
    sos = butter(order, [low / nyq, high / nyq], btype="band", output="sos")
    return sosfiltfilt(sos, signal_1d)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_channel_band_filter(
    eeg: np.ndarray,
    selected_channel_names: list[str],
    selected_indices: list[int],
    band_definitions: dict[str, list[float]],
    channel_band_config: dict[str, Any],
    fs: int = 250,
    filter_order: int = 4,
) -> tuple[np.ndarray, list[dict[str, Any]]]:
    """Apply per-channel Butterworth band-pass filters.

    Each physical channel is filtered in one or more frequency bands.
    The resulting filtered signals are concatenated along the channel
    axis as *virtual channels*.

    Parameters
    ----------
    eeg : np.ndarray
        Shape ``(C_selected, T)`` -- EEG data with only the selected
        physical channels.
    selected_channel_names : list[str]
        Names of the selected channels (same length as axis-0 of *eeg*).
    selected_indices : list[int]
        Original 0-based indices of the selected channels.
    band_definitions : dict[str, list[float]]
        Mapping ``{band_name: [low_hz, high_hz]}``.
        Example::

            {"delta": [1, 4], "theta": [4, 7], "alpha": [8, 13],
             "beta": [13, 30], "gamma": [30, 45], "broadband": [1, 45]}
    channel_band_config : dict
        ``{"default_bands": ["broadband"], "per_channel": {}}``.
        Controls which bands are applied to each channel.
    fs : int, optional
        Sampling frequency in Hz.  Default ``250``.
    filter_order : int, optional
        Butterworth filter order.  Default ``4``.

    Returns
    -------
    tuple[np.ndarray, list[dict]]
        * **filtered** -- ``(C_eff, T)`` where ``C_eff`` is the total
          number of virtual channels (sum of bands across physical
          channels).
        * **token_meta** -- one dict per virtual channel::

              {"source_channel": str,
               "source_channel_index": int,
               "band_name": str,
               "low": float,
               "high": float}

    Raises
    ------
    ValueError
        If input shapes are inconsistent or a band definition is invalid.
    """
    if eeg.ndim != 2:
        raise ValueError(f"Expected 2-D array, got {eeg.ndim}-D (shape {eeg.shape}).")

    n_channels, n_times = eeg.shape
    if n_channels != len(selected_channel_names):
        raise ValueError(
            f"eeg has {n_channels} channels but selected_channel_names has "
            f"{len(selected_channel_names)} entries."
        )
    if n_channels != len(selected_indices):
        raise ValueError(
            f"eeg has {n_channels} channels but selected_indices has "
            f"{len(selected_indices)} entries."
        )

    virtual_channels: list[np.ndarray] = []
    token_meta: list[dict[str, Any]] = []

    for ch_offset in range(n_channels):
        ch_name = selected_channel_names[ch_offset]
        ch_idx = selected_indices[ch_offset]
        ch_signal = eeg[ch_offset, :]

        bands = _resolve_bands_for_channel(ch_name, band_definitions, channel_band_config)

        for band_name, low, high in bands:
            _validate_band(low, high, fs)

            filtered_signal = _bandpass_filter(ch_signal, low, high, fs, filter_order)

            virtual_channels.append(filtered_signal.reshape(1, -1))
            token_meta.append({
                "source_channel": ch_name,
                "source_channel_index": ch_idx,
                "band_name": band_name,
                "low": low,
                "high": high,
            })

    filtered = np.concatenate(virtual_channels, axis=0)

    return filtered, token_meta
