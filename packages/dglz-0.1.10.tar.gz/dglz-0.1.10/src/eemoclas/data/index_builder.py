"""Build CSV index files for training and test .mat files.

Scans the raw data directories, extracts subject metadata from filenames,
and writes index CSVs that downstream Dataset classes can consume.
"""

from __future__ import annotations

import os
import re
from glob import glob, iglob
from typing import Any

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_MAT_PATTERN = re.compile(r"\.mat$", re.IGNORECASE)

# Common patterns found in DGLZ filenames:
#   sub001_normal.mat  -> group_label = 0 (normal)
#   sub001_depression.mat -> group_label = 1 (depression)
# Directory names: 正常人/HC -> 0, 抑郁症患者/DEP -> 1
_NORMAL_RE = re.compile(r"normal|HC|健康|正常", re.IGNORECASE)
_DEPRESSION_RE = re.compile(r"depress|DEP|抑郁", re.IGNORECASE)


def _derive_group_label(filename_stem: str, config: dict[str, Any],
                        parent_dir: str = "") -> int:
    """Derive group label (0=normal, 1=depression) for a training file.

    Resolution order:
    1. An explicit mapping in ``config["label_mapping"]`` keyed by the
       full filename stem.
    2. Heuristic: scan the stem or parent directory name for ``"normal"``
       (label 0) or ``"depress"`` (label 1).
    3. Default to 0 if neither matches.
    """
    label_mapping: dict[str, int] = config.get("label_mapping", {})

    if filename_stem in label_mapping:
        return int(label_mapping[filename_stem])

    # Check both filename and parent directory for label hints.
    search_text = f"{parent_dir} {filename_stem}"

    if _DEPRESSION_RE.search(search_text):
        return 1
    if _NORMAL_RE.search(search_text):
        return 0

    # Default: treat as normal
    return 0


def _write_csv(path: str, header: str, rows: list[str]) -> str:
    """Write a simple CSV file and return the path."""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(header + "\n")
        for row in rows:
            fh.write(row + "\n")
    return path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_train_index(
    raw_train_dir: str,
    index_dir: str,
    config: dict[str, Any],
) -> str:
    """Scan ``raw/train/*.mat`` and produce ``train_subjects.csv``.

    Parameters
    ----------
    raw_train_dir : str
        Directory containing training ``.mat`` files.
    index_dir : str
        Output directory for the generated CSV.  Created if it does not
        exist.
    config : dict
        Pipeline configuration.  May contain:

        * ``label_mapping`` -- ``{filename_stem: int_label}`` for
          explicit subject-to-label mappings.

    Returns
    -------
    str
        Absolute path to the generated
        ``<index_dir>/train_subjects.csv``.

    Raises
    ------
    FileNotFoundError
        If *raw_train_dir* does not exist.
    ValueError
        If no ``.mat`` files are found.
    """
    if not os.path.isdir(raw_train_dir):
        raise FileNotFoundError(f"Raw train directory not found: {raw_train_dir}")

    os.makedirs(index_dir, exist_ok=True)

    mat_files = sorted(
        glob(os.path.join(raw_train_dir, "*.mat"))
        + glob(os.path.join(raw_train_dir, "*.MAT"))
        + glob(os.path.join(raw_train_dir, "**", "*.mat"), recursive=True)
        + glob(os.path.join(raw_train_dir, "**", "*.MAT"), recursive=True)
    )

    if not mat_files:
        raise ValueError(f"No .mat files found in '{raw_train_dir}'.")

    rows: list[str] = []
    for mat_path in mat_files:
        filename = os.path.basename(mat_path)
        stem = os.path.splitext(filename)[0]
        parent = os.path.basename(os.path.dirname(mat_path))
        label = _derive_group_label(stem, config, parent)
        rows.append(f"{stem},{mat_path},{label}")

    csv_path = os.path.join(index_dir, "train_subjects.csv")
    _write_csv(csv_path, "subject_id,mat_path,group_label", rows)
    return os.path.abspath(csv_path)


def build_test_index(
    raw_test_dir: str,
    index_dir: str,
    config: dict[str, Any],
) -> str:
    """Scan ``raw/test/*.mat`` and produce ``test_subjects.csv``.

    Parameters
    ----------
    raw_test_dir : str
        Directory containing test ``.mat`` files.
    index_dir : str
        Output directory for the generated CSV.  Created if it does not
        exist.
    config : dict
        Pipeline configuration (currently unused, reserved for future
        extensions).

    Returns
    -------
    str
        Absolute path to the generated
        ``<index_dir>/test_subjects.csv``.

    Raises
    ------
    FileNotFoundError
        If *raw_test_dir* does not exist.
    ValueError
        If no ``.mat`` files are found.
    """
    if not os.path.isdir(raw_test_dir):
        raise FileNotFoundError(f"Raw test directory not found: {raw_test_dir}")

    os.makedirs(index_dir, exist_ok=True)

    mat_files = sorted(
        glob(os.path.join(raw_test_dir, "*.mat"))
        + glob(os.path.join(raw_test_dir, "*.MAT"))
    )

    if not mat_files:
        raise ValueError(f"No .mat files found in '{raw_test_dir}'.")

    rows: list[str] = []
    for mat_path in mat_files:
        filename = os.path.basename(mat_path)
        stem = os.path.splitext(filename)[0]
        rows.append(f"{stem},{mat_path}")

    csv_path = os.path.join(index_dir, "test_subjects.csv")
    _write_csv(csv_path, "user_id,mat_path", rows)
    return os.path.abspath(csv_path)
