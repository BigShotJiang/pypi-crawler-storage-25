"""Enhanced Rich terminal display for DGLZ V0.1.4.

Provides high-level display helpers for experiment management:

* **Training config panel**  -- grouped config summary with blue border
* **Epoch summary table**    -- per-epoch Train/Val metrics table
* **Training results panel** -- green-bordered completion summary
* **Multi-model summary**    -- compare all models in one table
* **DualPanelDisplay**       -- two-panel live display (progress + log)

Colour convention:
* **Blue**   -- configuration panels
* **Green**  -- results panels
* **Cyan**   -- table headers
* **Yellow** -- warnings
* **Red**    -- errors

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Any

# Rich is an optional dependency -- guard every public function.
try:
    from rich.console import Console, Group  # type: ignore[import-untyped]
    from rich.live import Live  # type: ignore[import-untyped]
    from rich.panel import Panel  # type: ignore[import-untyped]
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn, MofNCompleteColumn  # type: ignore[import-untyped]
    from rich.table import Table  # type: ignore[import-untyped]

    _RICH_AVAILABLE = True
except ImportError:
    _RICH_AVAILABLE = False


# ---------------------------------------------------------------------------
# Shared console  (stderr so it doesn't interfere with piped stdout)
# ---------------------------------------------------------------------------

if _RICH_AVAILABLE:
    console = Console(stderr=True)
else:
    console = None  # type: ignore[assignment]

_REFRESH_RATE = 4  # Hz


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _require_rich() -> None:
    """Raise RuntimeError if Rich is not available."""
    if not _RICH_AVAILABLE:
        raise RuntimeError(
            "Rich is required for display helpers.  Install it with: pip install rich"
        )


def _fmt(value: Any) -> str:
    """Format a scalar for display in config panels.

    Rules:

    * Native ``int`` — shown as integer (no decimal point).
    * Floats with ``abs(value) < 0.01`` and ``value != 0`` — scientific
      notation with 2 significant digits (e.g. ``1.0e-03``, ``3.0e-04``).
    * Other floats — up to 6 decimal places with trailing zeros stripped.
    """
    if isinstance(value, int):
        return str(value)
    if not isinstance(value, float):
        return str(value)
    if value != 0.0 and abs(value) < 0.01:
        return f"{value:.1e}"
    s = f"{value:.6f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


# ---------------------------------------------------------------------------
# 1. Training config panel (blue border, grouped sections)
# ---------------------------------------------------------------------------

def print_training_config_panel(
    config_sections: dict[str, dict[str, Any]],
    title: str = "Training Config",
) -> None:
    """Pretty-print grouped configuration as a Rich panel with blue border.

    Parameters
    ----------
    config_sections:
        Mapping of section names to key-value dicts.
        Example::

            {
                "Model": {"name": "EEGNet", "n_classes": 3},
                "Training": {"lr": 0.001, "epochs": 100},
            }
    title:
        Panel title.
    """
    _require_rich()
    parts: list[Any] = []
    for section_name, section_items in config_sections.items():
        table = Table(show_header=False, show_lines=False, pad_edge=False, border_style="dim")
        table.add_column("Key", style="bold cyan", justify="left", no_wrap=True)
        table.add_column("Value", justify="left")
        for key, value in section_items.items():
            table.add_row(str(key), _fmt(value))
        parts.append(Panel(table, title=section_name, border_style="dim", expand=False))

    group = Group(*parts)
    panel = Panel(group, title=title, border_style="blue", expand=False)
    console.print(panel)


# ---------------------------------------------------------------------------
# 2. Epoch summary table
# ---------------------------------------------------------------------------

_EPOCH_METRIC_COLS = ("Loss", "Acc", "Bal_Acc", "F1", "AUC")


def print_epoch_summary_table(
    model_name: str,
    epoch: int,
    total_epochs: int,
    train_metrics: dict[str, float],
    val_metrics: dict[str, float],
    lr: float | None = None,
    epoch_time: float | None = None,
) -> None:
    """Print a Rich table with Train/Val rows for a single epoch.

    Parameters
    ----------
    model_name:
        Name of the model being trained.
    epoch:
        Current epoch number (1-based).
    total_epochs:
        Total number of epochs.
    train_metrics:
        Training metrics dict (keys: loss, acc, bal_acc, f1, auc).
    val_metrics:
        Validation metrics dict (keys: loss, acc, bal_acc, f1, auc).
    lr:
        Current learning rate (displayed in table title if given).
    epoch_time:
        Epoch wall-clock time in seconds (displayed in table footer if given).
    """
    _require_rich()

    title = f"{model_name}  [Epoch {epoch}/{total_epochs}]"
    if lr is not None:
        title += f"  lr={_fmt(lr)}"

    table = Table(title=title, show_header=True, border_style="cyan")
    table.add_column("Phase", style="bold cyan", justify="left")
    for col in _EPOCH_METRIC_COLS:
        table.add_column(col, justify="right")

    def _row_values(metrics: dict[str, float]) -> list[str]:
        lowered = {k.lower(): v for k, v in metrics.items()}
        col_map = {
            "Loss": ("loss",),
            "Acc": ("acc", "accuracy"),
            "Bal_Acc": ("bal_acc", "balanced_acc", "balanced_accuracy"),
            "F1": ("f1", "f1_score"),
            "AUC": ("auc", "roc_auc"),
        }
        values: list[str] = []
        for col_name in _EPOCH_METRIC_COLS:
            found = None
            for key_variant in col_map.get(col_name, (col_name.lower(),)):
                if key_variant in lowered:
                    found = lowered[key_variant]
                    break
            values.append(_fmt(found) if found is not None else "-")
        return values

    table.add_row("Train", *_row_values(train_metrics))
    table.add_row("Val", *_row_values(val_metrics))

    console.print(table)
    if epoch_time is not None:
        console.print(f"  [dim]Epoch time: {epoch_time:.2f}s[/dim]")


# ---------------------------------------------------------------------------
# 3. Training results panel (green border)
# ---------------------------------------------------------------------------

def print_training_results_panel(
    model_name: str,
    results: dict[str, Any],
    title: str = "Training Results",
) -> None:
    """Pretty-print training completion results as a Rich panel with green border.

    Parameters
    ----------
    model_name:
        Name of the trained model.
    results:
        Mapping of metric names to final values.
    title:
        Panel title.
    """
    _require_rich()
    table = Table(show_header=False, show_lines=False, pad_edge=False)
    table.add_column("Metric", style="bold cyan", justify="left", no_wrap=True)
    table.add_column("Value", justify="left")

    table.add_row("Model", model_name)
    for key, value in results.items():
        table.add_row(str(key), _fmt(value))

    panel = Panel(table, title=title, border_style="green", expand=False)
    console.print(panel)


# ---------------------------------------------------------------------------
# 4. Multi-model summary table
# ---------------------------------------------------------------------------

_SUMMARY_METRICS = ("acc", "f1", "auc", "bal_acc")


def print_multi_model_summary(results: dict[str, dict[str, Any]]) -> None:
    """Print a comparison table across multiple models.

    Parameters
    ----------
    results:
        Mapping of model names to their result dicts.
        Example::

            {
                "EEGNet": {"acc": 0.85, "f1": 0.83, "auc": 0.91},
                "CNNTransformer": {"acc": 0.87, "f1": 0.86, "auc": 0.93},
            }
    """
    _require_rich()

    # Determine which columns are actually present across all models
    all_keys: set[str] = set()
    for model_results in results.values():
        all_keys.update(k.lower() for k in model_results.keys())

    # Use standard order for known metrics, then add any extras
    ordered_cols: list[str] = [m for m in _SUMMARY_METRICS if m in all_keys]
    extras = sorted(all_keys - set(_SUMMARY_METRICS))
    ordered_cols.extend(extras)

    table = Table(title="Multi-Model Summary", show_header=True, border_style="cyan")
    table.add_column("Model", style="bold cyan", justify="left")
    for col in ordered_cols:
        table.add_column(col.upper(), justify="right")

    for model_name, model_results in results.items():
        lowered = {k.lower(): v for k, v in model_results.items()}
        row = [model_name] + [
            _fmt(lowered.get(col, "-")) if col in lowered else "-"
            for col in ordered_cols
        ]
        table.add_row(*row)

    console.print(table)


# ---------------------------------------------------------------------------
# 5. DualPanelDisplay -- two-panel live display
# ---------------------------------------------------------------------------

class DualPanelDisplay:
    """Two-panel live display: progress info (top) + scrollable log (bottom).

    Usage::

        display = DualPanelDisplay(total_epochs=100)
        display.start()
        for epoch in range(1, 101):
            display.update("EEGNet", epoch, {"loss": 0.42, "acc": 0.87})
            display.add_log("some message")
        display.stop()

    Parameters
    ----------
    total_epochs:
        Total number of training epochs.
    model_name:
        Initial model name shown in the progress panel.
    """

    def __init__(
        self,
        total_epochs: int,
        model_name: str = "Training",
    ) -> None:
        _require_rich()
        self._total = total_epochs
        self._model_name = model_name
        self._current_epoch = 0
        self._current_metrics: dict[str, float] = {}
        self._logs: list[str] = []
        self._live: Live | None = None

        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            refresh_per_second=_REFRESH_RATE,
        )
        self._task_id: Any = None

    # -- context manager ----------------------------------------------------

    def __enter__(self) -> DualPanelDisplay:
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    # -- public API ---------------------------------------------------------

    def start(self) -> None:
        """Start the dual-panel live display."""
        self._task_id = self._progress.add_task(
            self._model_name, total=self._total
        )
        self._live = Live(
            self._build_renderable(),
            refresh_per_second=_REFRESH_RATE,
            console=console,
        )
        self._live.start()

    def update(
        self,
        model_name: str,
        epoch: int,
        metrics: dict[str, float] | None = None,
    ) -> None:
        """Update the progress panel.

        Parameters
        ----------
        model_name:
            Current model name.
        epoch:
            Current epoch (1-based).
        metrics:
            Optional metrics dict to display.
        """
        self._model_name = model_name
        self._current_epoch = epoch
        if metrics is not None:
            self._current_metrics = metrics

        if self._task_id is not None:
            self._progress.update(
                self._task_id,
                completed=epoch,
                description=model_name,
            )

        if self._live is not None:
            self._live.update(self._build_renderable())

    def add_log(self, message: str) -> None:
        """Append a message to the scrollable log panel.

        Parameters
        ----------
        message:
            Text to append.
        """
        self._logs.append(message)
        if self._live is not None:
            self._live.update(self._build_renderable())

    def stop(self) -> None:
        """Stop the live display."""
        if self._live is not None:
            self._live.stop()
            self._live = None

    # -- internal -----------------------------------------------------------

    def _build_renderable(self) -> Any:
        """Compose progress info panel + log panel."""
        from rich.text import Text

        # Top panel: progress bar + current metrics
        metrics_text = ""
        if self._current_metrics:
            parts = [f"{k}={_fmt(v)}" for k, v in self._current_metrics.items()]
            metrics_text = "  ".join(parts)

        top_body = Group(
            self._progress,
            Text(metrics_text) if metrics_text else Text(""),
        )
        top_panel = Panel(
            top_body,
            title=f"[bold]{self._model_name}[/bold]  Epoch {self._current_epoch}/{self._total}",
            border_style="blue",
        )

        # Bottom panel: scrollable log (last 20 lines)
        from rich.text import Text as RichText

        log_text = RichText("\n".join(self._logs[-20:]))
        bottom_panel = Panel(log_text, title="Log", border_style="dim")

        return Group(top_panel, bottom_panel)
