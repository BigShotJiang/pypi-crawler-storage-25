"""Three-level seed management for reproducibility.

* **Global seed** -- sets Python ``random``, NumPy, and PyTorch seeds.
* **Split seed** -- deterministic seed for data splitting operations.
* **Init seed** -- deterministic seed for model weight initialization.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import random
from typing import Any

import numpy as np
import torch


def set_global_seed(seed: int) -> None:
    """Set the global random seed across all backends.

    This affects ``random``, ``numpy.random``, and ``torch`` (both CPU
    and all CUDA devices).

    Parameters
    ----------
    seed:
        Integer seed value.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # Ensure deterministic CUDA convolution where possible
    torch.backends.cudnn.deterministic = True  # type: ignore[attr-defined]
    torch.backends.cudnn.benchmark = False  # type: ignore[attr-defined]


def set_split_seed(seed: int) -> None:
    """Set the seed used for data splitting.

    Call this before any train/val/test split to ensure reproducibility
    of dataset partitioning.

    Parameters
    ----------
    seed:
        Integer seed value.
    """
    random.seed(seed)
    np.random.seed(seed)


def set_init_seed(seed: int) -> None:
    """Set the seed used for model weight initialization.

    Call this before model construction to ensure reproducible parameter
    initialisation.

    Parameters
    ----------
    seed:
        Integer seed value.
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
