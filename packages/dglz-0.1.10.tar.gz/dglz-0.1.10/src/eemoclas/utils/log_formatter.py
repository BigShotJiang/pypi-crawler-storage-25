"""ASCII box formatting utilities for log files.

Provides helper functions for drawing simple ASCII boxes, metric lines,
and epoch separators -- all designed to remain readable in plain-text
log files without any terminal colour support.

Floats are rendered with 4 decimal places; integers have no decimal
point.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_WIDTH = 60
_DEFAULT_SEP_WIDTH = 50


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _format_value(value: Any) -> str:
    """Format a single value: 4 decimal places for floats, plain for rest."""
    if isinstance(value, float):
        return f"{value:.4f}"
    return str(value)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def box_header(title: str, width: int = _DEFAULT_WIDTH) -> str:
    """Return an ASCII box header line.

    Example (width=60)::

        +----------------------------------------------------------+
        |  Training Config                                         |
        +----------------------------------------------------------+

    Parameters
    ----------
    title:
        Text displayed inside the header.
    width:
        Total box width including borders.

    Returns
    -------
    str
        Three-line header string (trailing newline included).
    """
    inner = width - 4  # "+ " and " +"
    sep = "+" + "-" * (width - 2) + "+"
    content = f"|  {title:<{inner}} |"
    return f"{sep}\n{content}\n{sep}"


def box_line(key: str, value: str, width: int = _DEFAULT_WIDTH) -> str:
    """Return a single ASCII box content line.

    Example (width=60)::

        |  learning_rate               0.0010                        |

    Parameters
    ----------
    key:
        Label on the left.
    value:
        Value text on the right.
    width:
        Total box width including borders.

    Returns
    -------
    str
        Single line string (no trailing newline).
    """
    inner = width - 4
    text = f"{key}: {_format_value(value)}"
    return f"|  {text:<{inner}} |"


def box_footer(width: int = _DEFAULT_WIDTH) -> str:
    """Return the bottom border of an ASCII box.

    Example (width=60)::

        +----------------------------------------------------------+

    Parameters
    ----------
    width:
        Total box width.

    Returns
    -------
    str
        Single border line.
    """
    return "+" + "-" * (width - 2) + "+"


def metrics_line(prefix: str, metrics: dict[str, Any]) -> str:
    """Format a metrics dictionary as a single log line.

    Example::

        train: loss=0.1234 | acc=0.5678 | f1=0.9012

    Floats are rendered with 4 decimal places; integers are plain.

    Parameters
    ----------
    prefix:
        Leading label (e.g. ``"train"`` or ``"val"``).
    metrics:
        Mapping of metric names to scalar values.

    Returns
    -------
    str
        Formatted metrics line.
    """
    parts = [f"{k}={_format_value(v)}" for k, v in metrics.items()]
    return f"{prefix}: {' | '.join(parts)}"


def epoch_title(epoch: int, total: int) -> str:
    """Return an epoch header string.

    Example::

        [Epoch 12/100]

    Parameters
    ----------
    epoch:
        Current epoch number (1-based for display).
    total:
        Total number of epochs.

    Returns
    -------
    str
        Epoch header string.
    """
    return f"[Epoch {epoch}/{total}]"


def epoch_separator(width: int = _DEFAULT_SEP_WIDTH) -> str:
    """Return a horizontal dash separator.

    Example (width=50)::

        --------------------------------------------------

    Parameters
    ----------
    width:
        Number of dash characters.

    Returns
    -------
    str
        Separator string.
    """
    return "-" * width
