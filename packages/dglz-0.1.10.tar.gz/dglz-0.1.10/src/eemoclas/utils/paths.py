"""Path resolution helpers for the DGLZ project.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from pathlib import Path


def resolve_project_root() -> Path:
    """Return the project root directory.

    The root is identified by the presence of a ``pyproject.toml`` file.
    Walks upward from the current working directory until ``pyproject.toml``
    is found.

    Returns
    -------
    Path
        Absolute path to the project root.

    Raises
    ------
    FileNotFoundError
        If no ``pyproject.toml`` is found in any parent directory.
    """
    current = Path.cwd().resolve()
    for parent in [current, *current.parents]:
        if (parent / "pyproject.toml").is_file():
            return parent
    raise FileNotFoundError("Cannot locate project root (pyproject.toml not found)")


def ensure_dir(path: str | Path) -> Path:
    """Create a directory (and parents) if it does not exist.

    Parameters
    ----------
    path:
        Target directory path.

    Returns
    -------
    Path
        The resolved ``Path`` object.
    """
    p = Path(path).resolve()
    p.mkdir(parents=True, exist_ok=True)
    return p


def find_config_snapshot(resampled_dir: str | Path) -> Path:
    """Locate the config snapshot inside a resampled data directory.

    Resampled directories produced by the DGLZ preprocessing pipeline
    contain a ``config_snapshot.yaml`` file that records the exact
    configuration used for that particular resampling run.

    Parameters
    ----------
    resampled_dir:
        Path to the resampled output directory.

    Returns
    -------
    Path
        Absolute path to ``config_snapshot.yaml``.

    Raises
    ------
    FileNotFoundError
        If the snapshot file does not exist inside the directory.
    """
    d = Path(resampled_dir).resolve()
    # Try the expected filename first
    candidate = d / "config_snapshot.yaml"
    if candidate.is_file():
        return candidate

    # Fall back to any YAML file in the directory
    yaml_files = sorted(d.glob("*.yaml")) + sorted(d.glob("*.yml"))
    if yaml_files:
        return yaml_files[0]

    raise FileNotFoundError(f"No config snapshot found in {d}")
