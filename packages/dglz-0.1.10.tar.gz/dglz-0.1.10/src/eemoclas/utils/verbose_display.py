"""Verbose display modes for training progress.

* ``VerboseLiveDisplay``  -- progress bar + real-time log panel (``--verbose ON``)
* ``SilentProgressBar``   -- standalone progress bar (``--verbose OFF``)

Both use Rich internally.  Progress bars refresh at 4 updates per second.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Any

try:
    from rich.progress import (
        Progress,
        SpinnerColumn,
        BarColumn,
        TextColumn,
        TimeElapsedColumn,
        TimeRemainingColumn,
        MofNCompleteColumn,
    )
    from rich.live import Live  # type: ignore[import-untyped]
    from rich.panel import Panel  # type: ignore[import-untyped]
    from rich.console import Group  # type: ignore[import-untyped]

    _RICH_AVAILABLE = True
except ImportError:
    _RICH_AVAILABLE = False


_REFRESH_RATE = 4  # updates per second


# ---------------------------------------------------------------------------
# Metric value formatting
# ---------------------------------------------------------------------------

def _fmt_value(key: str, value) -> str:
    """Format a metric value for log display.

    Rules:

    * ``epoch``  — integer (no decimal point).
    * ``lr``     — scientific notation when < 0.001 (e.g. ``3.00e-04``),
      regular decimal otherwise (up to 8 significant digits).
    * ``time_s`` — two decimal places.
    * Native ``int`` values — shown as integer (no decimal point).
    * All other floats — up to 8 decimal places with trailing zeros stripped.
    """
    # Native integers and epoch key always shown without decimal point
    if isinstance(value, int) or key == "epoch":
        return str(int(value))
    if not isinstance(value, float):
        return str(value)
    if key == "lr":
        if value == 0:
            return "0"
        if abs(value) < 0.001:
            return f"{value:.2e}"
        return f"{value:.8g}"
    if key == "time_s":
        return f"{value:.2f}"
    # General metrics: up to 8 decimals, strip trailing zeros
    s = f"{value:.8f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


# ---------------------------------------------------------------------------
# Helper to build a standard progress bar
# ---------------------------------------------------------------------------

def _make_progress(*, show_speed: bool = True) -> "Progress":
    """Build a Rich ``Progress`` instance with the standard column layout."""
    if not _RICH_AVAILABLE:
        raise RuntimeError("Rich is required for display helpers.")
    return Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        refresh_per_second=_REFRESH_RATE,
    )


# ---------------------------------------------------------------------------
# VerboseLiveDisplay
# ---------------------------------------------------------------------------

class VerboseLiveDisplay:
    """Progress bar combined with a live log panel.

    Usage::

        display = VerboseLiveDisplay(total_epochs=100)
        display.start()
        for epoch in range(1, 101):
            # ... training ...
            display.update(epoch, metrics={"loss": 0.42, "acc": 0.87})
        display.stop()

    Parameters
    ----------
    total_epochs:
        Total number of training epochs.
    description:
        Label for the progress bar (default ``"Training"``).
    """

    def __init__(
        self,
        total_epochs: int,
        description: str = "Training",
    ) -> None:
        if not _RICH_AVAILABLE:
            raise RuntimeError("Rich is required for VerboseLiveDisplay.")

        self._total = total_epochs
        self._desc = description
        self._progress = _make_progress()
        self._logs: list[str] = []
        self._live: Live | None = None
        self._task_id: Any = None

    # -- context manager ----------------------------------------------------

    def __enter__(self) -> "VerboseLiveDisplay":
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    # -- public API ---------------------------------------------------------

    def start(self) -> None:
        """Start the live display."""
        self._task_id = self._progress.add_task(self._desc, total=self._total)
        self._live = Live(
            self._build_renderable(),
            refresh_per_second=_REFRESH_RATE,
        )
        self._live.start()

    def update(self, epoch: int, metrics: dict[str, float] | None = None) -> None:
        """Advance the progress bar and optionally append a log line.

        Parameters
        ----------
        epoch:
            Current epoch number (1-based).
        metrics:
            Optional mapping of metric names to values appended to the log
            panel.
        """
        if self._task_id is None:
            return

        self._progress.update(self._task_id, completed=epoch)

        if metrics:
            parts = [f"{k}={_fmt_value(k, v)}" for k, v in metrics.items()]
            line = f"[Epoch {epoch}/{self._total}] {' | '.join(parts)}"
            self._logs.append(line)

        if self._live is not None:
            self._live.update(self._build_renderable())

    def log(self, message: str) -> None:
        """Append an arbitrary message to the log panel."""
        self._logs.append(message)
        if self._live is not None:
            self._live.update(self._build_renderable())

    def stop(self) -> None:
        """Stop the live display."""
        if self._live is not None:
            self._live.stop()
            self._live = None

    # -- internal -----------------------------------------------------------

    def _build_renderable(self) -> Any:
        """Compose the progress bar + log panel into a single renderable."""
        from rich.console import Group
        from rich.panel import Panel
        from rich.text import Text

        log_text = Text("\n".join(self._logs[-30:]))  # keep last 30 lines
        log_panel = Panel(log_text, title="Log", border_style="dim")
        return Group(self._progress, log_panel)


# ---------------------------------------------------------------------------
# SilentProgressBar
# ---------------------------------------------------------------------------

class SilentProgressBar:
    """Standalone progress bar without the log panel.

    Suitable for non-verbose mode where only a progress indicator is
    desired.

    Usage::

        bar = SilentProgressBar(total_epochs=100)
        bar.start()
        for epoch in range(1, 101):
            bar.update(epoch)
        bar.stop()

    Parameters
    ----------
    total_epochs:
        Total number of training epochs.
    description:
        Label for the progress bar (default ``"Training"``).
    """

    def __init__(
        self,
        total_epochs: int,
        description: str = "Training",
    ) -> None:
        if not _RICH_AVAILABLE:
            raise RuntimeError("Rich is required for SilentProgressBar.")

        self._total = total_epochs
        self._desc = description
        self._progress = _make_progress()
        self._task_id: Any = None

    # -- context manager ----------------------------------------------------

    def __enter__(self) -> "SilentProgressBar":
        self.start()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.stop()

    # -- public API ---------------------------------------------------------

    def start(self) -> None:
        """Start the progress bar."""
        self._task_id = self._progress.add_task(self._desc, total=self._total)
        self._progress.start()

    def update(self, epoch: int, metrics: dict[str, float] | None = None) -> None:
        """Advance to *epoch*.

        Parameters
        ----------
        epoch:
            Current epoch number (1-based).
        metrics:
            Ignored (accepted for API parity with :class:`VerboseLiveDisplay`).
        """
        if self._task_id is not None:
            self._progress.update(self._task_id, completed=epoch)

    def stop(self) -> None:
        """Stop the progress bar."""
        self._progress.stop()
