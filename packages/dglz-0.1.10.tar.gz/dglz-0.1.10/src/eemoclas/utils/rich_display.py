"""Rich terminal display helpers.

Colour convention:
* **Blue**  -- configuration panels
* **Green** -- results panels
* **Cyan**  -- table headers
* **Yellow** -- warnings
* **Red**   -- errors

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Any

# Rich is an optional dependency -- guard every public function.
try:
    from rich.panel import Panel  # type: ignore[import-untyped]
    from rich.table import Table  # type: ignore[import-untyped]
    from rich.console import Console  # type: ignore[import-untyped]

    _RICH_AVAILABLE = True
except ImportError:
    _RICH_AVAILABLE = False

import torch.nn as nn


# ---------------------------------------------------------------------------
# Shared console
# ---------------------------------------------------------------------------

def _get_console() -> "Console":
    if not _RICH_AVAILABLE:
        raise RuntimeError("Rich is required for display helpers.  Install it with: pip install rich")
    from rich.console import Console
    return Console()


# ---------------------------------------------------------------------------
# Config panel
# ---------------------------------------------------------------------------

def print_config_panel(config: dict[str, Any], title: str = "Training Config") -> None:
    """Pretty-print a configuration dictionary as a Rich panel with blue border.

    Parameters
    ----------
    config:
        Configuration mapping (typically flat or one-level deep).
    title:
        Panel title.
    """
    if not _RICH_AVAILABLE:
        _fallback_dict(config, title)
        return

    console = _get_console()
    table = Table(show_header=False, show_lines=False, pad_edge=False)
    table.add_column("Key", style="bold cyan", justify="left")
    table.add_column("Value", justify="left")

    for key, value in _flatten_dict(config):
        table.add_row(str(key), _format_value(value))

    panel = Panel(table, title=title, border_style="blue", expand=False)
    console.print(panel)


# ---------------------------------------------------------------------------
# Model summary
# ---------------------------------------------------------------------------

def print_model_summary(model: nn.Module) -> None:
    """Print total, trainable, and frozen parameter counts.

    Parameters
    ----------
    model:
        A ``torch.nn.Module``.
    """
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    frozen = total - trainable

    if _RICH_AVAILABLE:
        console = _get_console()
        table = Table(title="Model Summary", show_header=True, border_style="cyan")
        table.add_column("Category", style="bold cyan")
        table.add_column("Parameters", justify="right")
        table.add_row("Total", f"{total:,}")
        table.add_row("Trainable", f"{trainable:,}", style="green")
        table.add_row("Frozen", f"{frozen:,}", style="yellow")
        console.print(table)
    else:
        print(f"Model Summary: total={total:,}  trainable={trainable:,}  frozen={frozen:,}")


# ---------------------------------------------------------------------------
# Results panel
# ---------------------------------------------------------------------------

def print_results_panel(results: dict[str, Any], title: str = "Training Results") -> None:
    """Pretty-print results as a Rich panel with green border.

    Parameters
    ----------
    results:
        Mapping of metric/result names to values.
    title:
        Panel title.
    """
    if not _RICH_AVAILABLE:
        _fallback_dict(results, title)
        return

    console = _get_console()
    table = Table(show_header=False, show_lines=False, pad_edge=False)
    table.add_column("Metric", style="bold cyan", justify="left")
    table.add_column("Value", justify="left")

    for key, value in _flatten_dict(results):
        table.add_row(str(key), _format_value(value))

    panel = Panel(table, title=title, border_style="green", expand=False)
    console.print(panel)


# ---------------------------------------------------------------------------
# Metrics table
# ---------------------------------------------------------------------------

_METRIC_NAMES = ("auc", "acc", "f1", "precision", "recall")


def print_metrics_table(metrics: dict[str, float]) -> None:
    """Print a metrics table with standard evaluation columns.

    Expected keys (case-insensitive prefix match): ``auc``, ``acc``,
    ``f1``, ``precision``, ``recall``.

    Parameters
    ----------
    metrics:
        Mapping of metric names to float values.
    """
    if not _RICH_AVAILABLE:
        print("Metrics:", " | ".join(f"{k}={v:.4f}" for k, v in metrics.items()))
        return

    console = _get_console()
    table = Table(title="Evaluation Metrics", show_header=True, border_style="cyan")
    table.add_column("Metric", style="bold cyan")
    table.add_column("Value", justify="right")

    lowered = {k.lower(): v for k, v in metrics.items()}
    for name in _METRIC_NAMES:
        value = lowered.get(name)
        if value is not None:
            table.add_row(name.upper(), f"{value:.4f}")

    # Add any extra metrics not covered by the standard names
    covered = {n for n in _METRIC_NAMES}
    for key, value in metrics.items():
        if key.lower() not in covered:
            table.add_row(key, f"{value:.4f}" if isinstance(value, float) else str(value))

    console.print(table)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _flatten_dict(d: dict[str, Any], prefix: str = "") -> list[tuple[str, Any]]:
    """Flatten a nested dict into ``( dotted_key, value )`` pairs."""
    items: list[tuple[str, Any]] = []
    for key, value in d.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            items.extend(_flatten_dict(value, full_key))
        else:
            items.append((full_key, value))
    return items


def _format_value(value: Any) -> str:
    """Pretty-format a scalar value for display.

    Rules:

    * Native ``int`` — shown as integer (no decimal point).
    * Floats with ``abs(value) < 0.01`` and ``value != 0`` — scientific
      notation with 2 significant digits (e.g. ``1.0e-03``, ``3.0e-04``).
    * Other floats — up to 6 decimal places with trailing zeros stripped.
    """
    if isinstance(value, int):
        return str(value)
    if not isinstance(value, float):
        return str(value)
    if value != 0.0 and abs(value) < 0.01:
        return f"{value:.1e}"
    s = f"{value:.6f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


def _fallback_dict(d: dict[str, Any], title: str) -> None:
    """Plain-text fallback when Rich is unavailable."""
    print(f"=== {title} ===")
    for key, value in _flatten_dict(d):
        print(f"  {key}: {_format_value(value)}")
