"""Multi-layer YAML configuration loading with C_eff resolution.

Supports hierarchical YAML configs with ``include`` directives, automatic
effective-channel count (C_eff) computation, and basic schema validation.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

# ---------------------------------------------------------------------------
# Channel table (30 channels, 0-based index)
# ---------------------------------------------------------------------------
CHANNEL_TABLE: dict[str, int] = {
    "FP1": 0, "FP2": 1,
    "F7": 2, "F3": 3, "FZ": 4, "F4": 5, "F8": 6,
    "FT7": 7, "FC3": 8, "FCZ": 9, "FC4": 10, "FT8": 11,
    "T3": 12, "C3": 13, "CZ": 14, "C4": 15, "T4": 16,
    "TP7": 17, "CP3": 18, "CPZ": 19, "CP4": 20, "TP8": 21,
    "T5": 22, "P3": 23, "PZ": 24, "P4": 25, "T6": 26,
    "O1": 27, "OZ": 28, "O2": 29,
}

ALL_CHANNEL_NAMES: list[str] = list(CHANNEL_TABLE.keys())


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------

def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base* (in-place) and return *base*."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


def load_config(path: str | Path, *, _seen: set[str] | None = None) -> dict[str, Any]:
    """Load a YAML config file and recursively resolve ``include`` directives.

    Parameters
    ----------
    path:
        Path to the YAML configuration file.
    _seen:
        Internal guard against circular includes.

    Returns
    -------
    dict
        Merged configuration dictionary.
    """
    path = Path(path).resolve()
    if _seen is None:
        _seen = set()

    key = str(path)
    if key in _seen:
        raise ValueError(f"Circular include detected: {path}")
    _seen.add(key)

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    # Resolve includes (relative to current file's parent)
    includes = data.pop("include", [])
    if isinstance(includes, str):
        includes = [includes]

    merged: dict[str, Any] = {}
    for inc in includes:
        inc_path = path.parent / inc
        inc_data = load_config(inc_path, _seen=_seen)
        _deep_merge(merged, inc_data)

    # Current file overrides anything pulled from includes
    _deep_merge(merged, data)
    return merged


# ---------------------------------------------------------------------------
# C_eff resolution
# ---------------------------------------------------------------------------

def resolve_c_eff(config: dict[str, Any]) -> int:
    """Compute the effective channel count (*C_eff*).

    C_eff = sum of ``len(bands)`` for every selected channel.

    The algorithm reads:
    * ``band_definitions`` -- maps band names to (low, high) Hz ranges.
    * ``channels.selected`` -- ``"all"`` or an explicit list of channel names.
    * ``channel_band_config.per_channel`` -- maps channel names to lists of
      band names.
    * ``channel_band_config.default_bands`` -- fallback band list for channels
      not present in ``per_channel``.

    Parameters
    ----------
    config:
        Fully-merged configuration dictionary.

    Returns
    -------
    int
        The effective number of input channels (C_eff).
    """
    band_defs: dict[str, Any] = config.get("band_definitions", {})
    ch_cfg: dict[str, Any] = config.get("channels", {})
    cb_cfg: dict[str, Any] = config.get("channel_band_config", {})

    # Determine selected channels
    selected = ch_cfg.get("selected", "all")
    if selected == "all":
        channel_names = ALL_CHANNEL_NAMES
    else:
        channel_names = list(selected)

    per_channel: dict[str, list[str]] = cb_cfg.get("per_channel", {})
    default_bands: list[str] = cb_cfg.get("default_bands", list(band_defs.keys()))

    c_eff = 0
    for ch in channel_names:
        bands = per_channel.get(ch, default_bands)
        c_eff += len(bands)

    return c_eff


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _detect_config_role(config: dict[str, Any]) -> str:
    """Detect the role/purpose of a config dict based on its keys.

    Returns one of: ``"training"``, ``"inference"``, ``"resample"``,
    ``"preprocess"``, or ``"unknown"``.
    """
    models = config.get("models")
    if isinstance(models, dict) and models:
        first_entry = next(iter(models.values()))
        if isinstance(first_entry, dict):
            if "model" in first_entry:
                return "training"
            return "inference"

    # Explicit inference section without models dict
    if "inference" in config and "test_data" in config:
        return "inference"

    if "resample" in config and "signal" in config:
        return "resample"

    if "data" in config and "signal" in config:
        return "preprocess"

    return "unknown"


def validate_config(config: dict[str, Any]) -> None:
    """Validate required fields in *config* based on its detected role.

    V0.1.4 defines four standard config formats (see ``configs/base/``).
    The function auto-detects the role from top-level keys and applies
    the appropriate checks:

    * **training** — each model group must have ``model.num_classes`` and
      ``training.epochs``.
    * **inference** — ``inference.routing`` and ``models`` with
      ``checkpoint`` entries must be present.
    * **resample** — ``resample.targets`` and ``signal.fs`` must be present.
    * **preprocess** — ``data.index_dir`` and ``signal.fs`` must be present.

    Raises ``ValueError`` with a human-readable message on failure.
    """
    role = _detect_config_role(config)

    if role == "training":
        _validate_training_config(config)
    elif role == "inference":
        _validate_inference_config(config)
    elif role == "resample":
        _validate_resample_config(config)
    elif role == "preprocess":
        _validate_preprocess_config(config)
    else:
        raise ValueError(
            "无法识别配置文件类型。"
            "标准格式为: training (含 models 段), inference, resample, preprocess"
        )

    # Validate C_eff computability when band info is present
    if "band_definitions" in config or "channel_band_config" in config:
        try:
            resolve_c_eff(config)
        except Exception as exc:
            raise ValueError(f"Cannot resolve C_eff: {exc}") from exc


def _validate_training_config(config: dict[str, Any]) -> None:
    """Validate unified training configs (models dict with model/training)."""
    models_section = config.get("models")
    if not isinstance(models_section, dict) or not models_section:
        raise ValueError("训练配置缺少 'models' 段")

    for name, mgroup in models_section.items():
        if not isinstance(mgroup, dict):
            continue
        model = mgroup.get("model", {})
        if "num_classes" not in model:
            raise ValueError(
                f"模型组 '{name}' 缺少 'model.num_classes'"
            )
        train = mgroup.get("training", {})
        if "epochs" not in train:
            raise ValueError(
                f"模型组 '{name}' 缺少 'training.epochs'"
            )


def _validate_inference_config(config: dict[str, Any]) -> None:
    """Validate inference configs."""
    inference = config.get("inference", {})
    if "routing" not in inference:
        raise ValueError("推理配置缺少 'inference.routing'")

    models_section = config.get("models", {})
    if not isinstance(models_section, dict) or not models_section:
        raise ValueError("推理配置缺少 'models' 段")

    for name, mentry in models_section.items():
        if not isinstance(mentry, dict):
            continue
        if "checkpoint" not in mentry:
            raise ValueError(f"推理模型 '{name}' 缺少 'checkpoint' 路径")


def _validate_resample_config(config: dict[str, Any]) -> None:
    """Validate resample configs."""
    resample = config.get("resample", {})
    if not resample:
        raise ValueError("重采样配置缺少 'resample' 段")

    if "targets" not in resample:
        raise ValueError("重采样配置缺少 'resample.targets'")

    signal = config.get("signal", {})
    if "fs" not in signal:
        raise ValueError("重采样配置缺少 'signal.fs'")

    workers = resample.get("workers", 1)
    if not isinstance(workers, int) or workers < 1:
        raise ValueError(
            f"重采样配置 'resample.workers' 必须为正整数，当前值: {workers}"
        )


def _validate_preprocess_config(config: dict[str, Any]) -> None:
    """Validate preprocess configs."""
    data = config.get("data", {})
    if "index_dir" not in data:
        raise ValueError("预处理配置缺少 'data.index_dir'")

    signal = config.get("signal", {})
    if "fs" not in signal:
        raise ValueError("预处理配置缺少 'signal.fs'")


# ---------------------------------------------------------------------------
# Config wrapper
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """Typed convenience wrapper around the raw configuration dictionary.

    The raw dict is accessible via ``cfg.raw``.  Convenience properties
    delegate to commonly-accessed sub-dictionaries.
    """

    raw: dict[str, Any] = field(default_factory=dict)

    # -- factories ----------------------------------------------------------

    @classmethod
    def from_file(cls, path: str | Path) -> "Config":
        """Load, validate, and return a ``Config`` from a YAML file."""
        data = load_config(path)
        validate_config(data)
        return cls(raw=data)

    # -- convenience accessors -----------------------------------------------

    @property
    def dataset(self) -> dict[str, Any]:
        return self.raw.get("dataset", {})

    @property
    def model(self) -> dict[str, Any]:
        return self.raw.get("model", {})

    @property
    def training(self) -> dict[str, Any]:
        return self.raw.get("training", {})

    @property
    def c_eff(self) -> int:
        return resolve_c_eff(self.raw)

    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def __contains__(self, key: str) -> bool:
        return key in self.raw

    def get(self, key: str, default: Any = None) -> Any:
        return self.raw.get(key, default)

    def __repr__(self) -> str:
        return f"Config(keys={sorted(self.raw.keys())})"
