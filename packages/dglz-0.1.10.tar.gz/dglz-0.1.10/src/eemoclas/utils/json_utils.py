"""JSON serialization helpers with NumPy type support.

Provides:

* ``NumpyEncoder`` -- JSON encoder that handles NumPy scalars and arrays.
* ``save_json`` / ``load_json`` -- convenience wrappers with pretty
  indentation.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """JSON encoder that transparently converts NumPy types.

    Supported conversions:

    * ``np.integer`` -> ``int``
    * ``np.floating`` -> ``float``
    * ``np.bool_`` -> ``bool``
    * ``np.ndarray`` -> ``list``
    * ``np.complexfloating`` -> ``str`` (via ``repr``)
    """

    def default(self, obj: Any) -> Any:  # noqa: D401
        """Convert *obj* to a JSON-serialisable Python type."""
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.bool_):
            return bool(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.complexfloating):
            return repr(obj)
        return super().default(obj)


def save_json(data: Any, path: str | Path) -> Path:
    """Serialize *data* as JSON and write to *path*.

    The output uses ``indent=2`` for readability.

    Parameters
    ----------
    data:
        Any JSON-serialisable object (NumPy types are handled by
        ``NumpyEncoder``).
    path:
        Destination file path.

    Returns
    -------
    Path
        Resolved path to the written file.
    """
    p = Path(path).resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, cls=NumpyEncoder, ensure_ascii=False)
    return p


def load_json(path: str | Path) -> dict[str, Any]:
    """Read a JSON file and return the parsed object.

    Parameters
    ----------
    path:
        Source file path.

    Returns
    -------
    dict
        Parsed JSON data.
    """
    p = Path(path).resolve()
    with open(p, "r", encoding="utf-8") as fh:
        return json.load(fh)
