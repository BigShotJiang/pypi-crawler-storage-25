"""Dual logger: Rich console handler + ASCII-box file handler.

* When **verbose** is ``True`` the console gets Rich-formatted output.
* The file handler always writes plain ASCII-box formatted lines so that
  log files remain readable without a terminal.

A new log file is created per training session with a timestamp embedded
in the filename.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import TextIO


# ---------------------------------------------------------------------------
# ASCII-box file formatter
# ---------------------------------------------------------------------------

class _BoxFileFormatter(logging.Formatter):
    """Formats log records as plain text with ``YYYY-MM-DD HH:MM:SS - LEVEL - msg``."""

    def __init__(self) -> None:
        super().__init__(fmt="%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")


class _BoxFileHandler(logging.FileHandler):
    """File handler that uses ASCII-box formatting."""

    def __init__(self, path: Path, mode: str = "a", encoding: str = "utf-8") -> None:
        super().__init__(str(path), mode=mode, encoding=encoding)
        self.setFormatter(_BoxFileFormatter())


# ---------------------------------------------------------------------------
# Rich console handler (optional dependency)
# ---------------------------------------------------------------------------

def _make_rich_handler() -> logging.Handler | None:
    """Try to create a Rich console handler; return ``None`` if unavailable."""
    try:
        from rich.logging import RichHandler  # type: ignore[import-untyped]

        return RichHandler(
            level=logging.DEBUG,
            show_path=False,
            markup=True,
            rich_tracebacks=True,
        )
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def setup_logger(
    name: str = "dglz",
    log_dir: str | Path = "logs",
    verbose: bool = True,
) -> logging.Logger:
    """Create and return a dual-output logger.

    Parameters
    ----------
    name:
        Logger name (usually ``"dglz"`` or a sub-module name).
    log_dir:
        Directory in which log files are stored.  Created if it does not
        exist.
    verbose:
        When ``True`` a Rich console handler is attached.  When ``False``
        the logger only writes to the file.

    Returns
    -------
    logging.Logger
        Configured logger instance.
    """
    logger = logging.getLogger(name)
    # Avoid duplicate handlers on repeated calls
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # -- File handler (always active) --
    log_dir = Path(log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"{name}_{timestamp}.log"

    file_handler = _BoxFileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    # -- Console handler (optional) --
    if verbose:
        rich_handler = _make_rich_handler()
        if rich_handler is not None:
            rich_handler.setLevel(logging.INFO)
            logger.addHandler(rich_handler)
        else:
            # Fallback to a plain stream handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_handler.setFormatter(_BoxFileFormatter())
            logger.addHandler(console_handler)

    return logger


# ---------------------------------------------------------------------------
# Experiment-specific logger
# ---------------------------------------------------------------------------

def setup_experiment_logger(
    name: str,
    log_path: str | Path,
    verbose: bool = True,
) -> logging.Logger:
    """Create a logger that writes to a specific experiment log file.

    Parameters
    ----------
    name:
        Logger name (e.g. "dglz.subject_state").
    log_path:
        Full path to the log file (e.g. experiments/exp001/logs/subject_state.log).
    verbose:
        When ``True`` the logger writes only to the file.  Terminal output
        is handled by the ``VerboseLiveDisplay`` log panel instead of a
        console handler, avoiding duplicate output above the Rich Live
        display.

    Returns
    -------
    logging.Logger
    """
    logger = logging.getLogger(name)
    logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    file_handler = _BoxFileHandler(log_path)
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)

    # Console output is intentionally skipped here.  During training the
    # VerboseLiveDisplay log panel (progress bar + log box) handles all
    # terminal visualisation.  Adding a RichHandler would produce
    # duplicate lines above the Live display.

    return logger
