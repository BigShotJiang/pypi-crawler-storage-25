"""Training module for DGLZ EEG emotion recognition.

Apache-2.0  --  SuShuHeng
"""
