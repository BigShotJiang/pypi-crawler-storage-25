"""Checkpoint save / load utilities for DGLZ training.

Checkpoint files use the ``.ckpt`` extension and contain the model state dict,
optimizer state dict, epoch number, metrics, and a full configuration snapshot.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import copy
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim

import yaml


def save_checkpoint(
    model: nn.Module,
    optimizer: optim.Optimizer,
    epoch: int,
    metrics: dict,
    config: dict,
    path: str | Path,
) -> None:
    """Save a training checkpoint.

    Parameters
    ----------
    model:
        The model whose ``state_dict`` will be saved.
    optimizer:
        The optimizer whose ``state_dict`` will be saved.
    epoch:
        Current epoch number (1-based).
    metrics:
        Dictionary of current metrics (e.g. ``{"val_loss": 0.42, ...}``).
    config:
        Full configuration dictionary (stored as a snapshot for reproducibility).
    path:
        Destination file path.  Must end with ``.ckpt``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    checkpoint = {
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "epoch": epoch,
        "metrics": copy.deepcopy(metrics),
        "config_snapshot": save_config_in_checkpoint(config),
    }
    torch.save(checkpoint, str(path))


def load_checkpoint(
    path: str | Path,
    model: nn.Module,
    device: str | torch.device = "cpu",
) -> dict:
    """Load a training checkpoint.

    Parameters
    ----------
    path:
        Path to the ``.ckpt`` file.
    model:
        Model instance to load weights into.
    device:
        Device to map tensors to when loading.

    Returns
    -------
    dict
        ``{"epoch": int, "metrics": dict, "config_snapshot": dict}``

    Raises
    ------
    FileNotFoundError
        If the checkpoint file does not exist.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {path}")

    device = torch.device(device)
    checkpoint = torch.load(str(path), map_location=device, weights_only=False)

    model.load_state_dict(checkpoint["model_state_dict"])

    return {
        "epoch": checkpoint["epoch"],
        "metrics": checkpoint.get("metrics", {}),
        "config_snapshot": checkpoint.get("config_snapshot", {}),
    }


def save_config_in_checkpoint(config: dict) -> dict:
    """Extract a serialisable config snapshot for checkpoint storage.

    Performs a deep copy and strips non-serialisable entries (e.g. objects,
    callables).  The result is safe to pass to ``torch.save``.

    Parameters
    ----------
    config:
        Full configuration dictionary.

    Returns
    -------
    dict
        A deep-copied, YAML-serialisable configuration snapshot.
    """
    snapshot = copy.deepcopy(config)
    # Ensure the snapshot is YAML-serialisable by round-tripping
    try:
        yaml_str = yaml.dump(snapshot, allow_unicode=True, default_flow_style=False)
        snapshot = yaml.safe_load(yaml_str)
    except Exception:
        # If YAML round-trip fails, return the deep copy as-is
        pass
    return snapshot
