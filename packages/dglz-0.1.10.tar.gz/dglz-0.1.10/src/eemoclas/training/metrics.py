"""Training-stage metric computation.

Separates train metrics (lightweight) from validation metrics (full suite).

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    roc_auc_score,
)


def compute_train_metrics(loss: float, y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Compute training metrics: loss, accuracy.

    Parameters
    ----------
    loss:
        Average training loss for the epoch.
    y_true:
        Ground-truth labels (1-D).
    y_pred:
        Predicted class labels (1-D).

    Returns
    -------
    dict
        ``{"loss": float, "accuracy": float}`` rounded to 4 decimal places.
    """
    return {
        "loss": round(loss, 4),
        "accuracy": round(accuracy_score(y_true, y_pred), 4),
    }


def compute_val_metrics(
    loss: float,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray | None = None,
) -> dict:
    """Compute validation metrics: loss, accuracy, balanced_accuracy, macro_f1, auc.

    Parameters
    ----------
    loss:
        Average validation loss for the epoch.
    y_true:
        Ground-truth labels (1-D).
    y_pred:
        Predicted class labels (1-D).
    y_prob:
        Optional predicted probabilities with shape ``(n_samples, n_classes)``
        or ``(n_samples,)`` for binary classification.

    Returns
    -------
    dict
        Dictionary with keys ``loss``, ``accuracy``, ``balanced_accuracy``,
        ``macro_f1``, and optionally ``auc`` -- all rounded to 4 decimal places.
    """
    y_true_arr = np.asarray(y_true)
    y_pred_arr = np.asarray(y_pred)

    metrics: dict = {
        "loss": round(loss, 4),
        "accuracy": round(accuracy_score(y_true_arr, y_pred_arr), 4),
        "balanced_accuracy": round(balanced_accuracy_score(y_true_arr, y_pred_arr), 4),
        "macro_f1": round(f1_score(y_true_arr, y_pred_arr, average="macro", zero_division=0), 4),
    }
    if y_prob is not None:
        y_prob_arr = np.asarray(y_prob)
        try:
            n_classes = len(np.unique(y_true_arr))
            if n_classes <= 2:
                if y_prob_arr.ndim == 2:
                    y_prob_arr = y_prob_arr[:, 1]
                metrics["auc"] = round(float(roc_auc_score(y_true_arr, y_prob_arr)), 4)
            else:
                metrics["auc"] = round(
                    float(roc_auc_score(y_true_arr, y_prob_arr, multi_class="ovr", average="macro")),
                    4,
                )
        except ValueError:
            metrics["auc"] = 0.0
    return metrics
