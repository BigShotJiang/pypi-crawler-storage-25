"""Early stopping callback for DGLZ training.

Stops training when a monitored metric ceases to improve for a configurable
number of epochs.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import logging

logger = logging.getLogger("dglz.training")


class EarlyStopping:
    """Early stopping based on a scalar metric.

    Parameters
    ----------
    patience:
        Number of consecutive non-improving epochs before stopping.
    mode:
        ``"max"`` for metrics that should increase (e.g. accuracy, AUC) or
        ``"min"`` for metrics that should decrease (e.g. loss).
    min_delta:
        Minimum absolute change to qualify as an improvement.

    Examples
    --------
    >>> es = EarlyStopping(patience=15, mode="max")
    >>> es.step(0.85)   # improves
    False
    >>> es.step(0.84)   # does not improve
    False
    >>> # ... 14 more non-improving steps ...
    >>> es.step(0.80)   # patience exceeded
    True
    """

    def __init__(self, patience: int = 15, mode: str = "max", min_delta: float = 0.0) -> None:
        if mode not in ("max", "min"):
            raise ValueError(f"mode must be 'max' or 'min', got '{mode}'")
        if patience < 1:
            raise ValueError(f"patience must be >= 1, got {patience}")

        self.patience = patience
        self.mode = mode
        self.min_delta = min_delta
        self.counter = 0
        self.best_score: float | None = None

    def step(self, score: float) -> bool:
        """Evaluate whether training should stop.

        Parameters
        ----------
        score:
            Current value of the monitored metric.

        Returns
        -------
        bool
            ``True`` if training should stop (patience exhausted).
        """
        if self.best_score is None:
            # First evaluation -- always accept
            self.best_score = score
            return False

        improved = self._is_improvement(score)

        if improved:
            self.best_score = score
            self.counter = 0
        else:
            self.counter += 1
            logger.debug(
                "EarlyStopping: no improvement for %d/%d epoch(s) "
                "(best=%.4f, current=%.4f)",
                self.counter,
                self.patience,
                self.best_score,
                score,
            )

        if self.counter >= self.patience:
            logger.info(
                "Early stopping triggered: no improvement for %d epoch(s) "
                "(best=%.4f).",
                self.patience,
                self.best_score,
            )
            return True

        return False

    def _is_improvement(self, score: float) -> bool:
        """Check whether *score* is an improvement over the current best."""
        if self.mode == "max":
            return score > self.best_score + self.min_delta
        else:
            return score < self.best_score - self.min_delta
