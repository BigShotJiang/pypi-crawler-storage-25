"""Experiment folder management for DGLZ.

Centralizes all outputs under experiments/{name}/:
- config.yaml (config snapshot)
- training_state.yaml (progress tracking)
- logs/ (training logs)
- checkpoints/ (per-model checkpoints, with fold support)
- metrics/ (CSV history)
- results/ (inference outputs)

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from eemoclas.config.dataclasses import ExperimentConfig


class ExperimentManager:
    """Create and manage the experiment directory tree.

    Parameters
    ----------
    config:
        An :class:`ExperimentConfig` instance that defines the experiment
        name, base save directory, and derived sub-directory paths.
    """

    def __init__(self, config: ExperimentConfig) -> None:
        self.config = config
        self._ensure_dirs()

    # ------------------------------------------------------------------
    # Directory helpers
    # ------------------------------------------------------------------

    def _ensure_dirs(self) -> None:
        """Create all standard sub-directories if they do not exist."""
        for d in (
            self.config.experiment_dir,
            self.config.checkpoint_dir,
            self.config.log_dir,
            self.config.result_dir,
            self.config.metrics_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)

    def model_checkpoint_dir(self, model_name: str) -> Path:
        """Return ``checkpoints/{model_name}/``, creating it if necessary."""
        d = self.config.checkpoint_dir / model_name
        d.mkdir(parents=True, exist_ok=True)
        return d

    def model_log_path(self, model_name: str) -> Path:
        """Return ``logs/{model_name}.log``."""
        return self.config.log_dir / f"{model_name}.log"

    def training_log_path(self) -> Path:
        """Return ``logs/training.log``."""
        return self.config.log_dir / "training.log"

    def metrics_csv_path(self, model_name: str) -> Path:
        """Return ``metrics/{model_name}_history.csv``."""
        return self.config.metrics_dir / f"{model_name}_history.csv"

    # ------------------------------------------------------------------
    # Fold-aware directory helpers
    # ------------------------------------------------------------------

    def model_fold_checkpoint_dir(self, model_name: str, fold_idx: int) -> Path:
        """Return ``checkpoints/{model_name}/fold_{i}/``, creating it if necessary."""
        d = self.config.checkpoint_dir / model_name / f"fold_{fold_idx}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def model_fold_best_dir(self, model_name: str) -> Path:
        """Return ``checkpoints/{model_name}/fold_best/``, creating it if necessary."""
        d = self.config.checkpoint_dir / model_name / "fold_best"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def model_fold_log_dir(self, model_name: str, fold_idx: int) -> Path:
        """Return ``logs/{model}_fold_{i}/``, creating it if necessary."""
        d = self.config.log_dir / f"{model_name}_fold_{fold_idx}"
        d.mkdir(parents=True, exist_ok=True)
        return d

    # ------------------------------------------------------------------
    # Config snapshot
    # ------------------------------------------------------------------

    def save_config_snapshot(self, config_dict: dict[str, Any]) -> Path:
        """Write *config_dict* to ``config.yaml`` in the experiment root.

        Parameters
        ----------
        config_dict:
            A serialisable configuration dictionary.

        Returns
        -------
        Path
            The path the snapshot was written to.
        """
        path = self.config.experiment_dir / "config.yaml"
        path.write_text(
            yaml.dump(config_dict, allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )
        return path

    # ------------------------------------------------------------------
    # Training state
    # ------------------------------------------------------------------

    @staticmethod
    def _state_path(experiment_dir: Path) -> Path:
        return experiment_dir / "training_state.yaml"

    def load_training_state(self) -> dict[str, Any]:
        """Load the training state from ``training_state.yaml``.

        Returns
        -------
        dict
            The stored state, or ``{"models": {}}`` when the file does not
            yet exist.
        """
        path = self._state_path(self.config.experiment_dir)
        if path.exists():
            return yaml.safe_load(path.read_text(encoding="utf-8")) or {"models": {}}
        return {"models": {}}

    def save_training_state(self, state: dict[str, Any]) -> None:
        """Persist *state* to ``training_state.yaml``."""
        path = self._state_path(self.config.experiment_dir)
        path.write_text(
            yaml.dump(state, allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )

    def init_training_state(self, model_names: list[str]) -> dict[str, Any]:
        """Initialise a fresh training state with every model set to ``pending``.

        Parameters
        ----------
        model_names:
            The model identifiers to track.

        Returns
        -------
        dict
            A state dictionary of the form::

                {
                    "models": {
                        "model_a": {"status": "pending", ...},
                        ...
                    }
                }
        """
        state: dict[str, Any] = {
            "models": {
                name: {
                    "status": "pending",
                    "best_epoch": 0,
                    "best_metric": 0.0,
                }
                for name in model_names
            },
        }
        self.save_training_state(state)
        return state

    def update_model_state(
        self,
        model_name: str,
        status: str,
        best_epoch: int = 0,
        best_metric: float = 0.0,
        *,
        method: str | None = None,
        n_splits: int | None = None,
        fold_idx: int | None = None,
    ) -> None:
        """Update a single model's entry in ``training_state.yaml``.

        Parameters
        ----------
        model_name:
            The model to update.
        status:
            New status string (e.g. ``"training"``, ``"completed"``,
            ``"failed"``).
        best_epoch:
            Best epoch seen so far.
        best_metric:
            Best metric value seen so far.
        method:
            Splitting method (``"holdout"`` or ``"StratifiedGroupKFold"``).
            When provided, stored in the model's state entry.
        n_splits:
            Number of folds (only meaningful when *method* is kfold).
        fold_idx:
            When provided, update a specific fold entry instead of the
            model-level entry.  Requires *method* to be kfold.
        """
        state = self.load_training_state()
        state.setdefault("models", {})
        models = state["models"]

        if fold_idx is not None:
            # Fold-level update for kfold mode
            entry = models.setdefault(model_name, {})
            entry["method"] = method or entry.get("method", "StratifiedGroupKFold")
            if n_splits is not None:
                entry["n_splits"] = n_splits
            entry.setdefault("folds", {})
            entry["folds"][str(fold_idx)] = {
                "status": status,
                "best_epoch": best_epoch,
                "best_metric": best_metric,
            }
            # Update overall model status
            entry["status"] = status
        else:
            # Holdout or model-level update
            entry: dict[str, Any] = {
                "status": status,
                "best_epoch": best_epoch,
                "best_metric": best_metric,
            }
            if method is not None:
                entry["method"] = method
            if n_splits is not None:
                entry["n_splits"] = n_splits
            models[model_name] = entry

        self.save_training_state(state)

    # ------------------------------------------------------------------
    # K-fold summary
    # ------------------------------------------------------------------

    def save_kfold_summary(self, model_name: str, summary: dict[str, Any]) -> None:
        """Write ``kfold_summary.yaml`` to ``checkpoints/{model_name}/``.

        Parameters
        ----------
        model_name:
            The model identifier.
        summary:
            The kfold summary dictionary (method, n_splits, folds, aggregated).
        """
        path = self.model_checkpoint_dir(model_name) / "kfold_summary.yaml"
        path.write_text(
            yaml.dump(summary, allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )
