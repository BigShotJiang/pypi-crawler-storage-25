"""Training callbacks: MultiMetricCheckpoint.

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from eemoclas.training.checkpoint import save_checkpoint


def _safe_metric_name(name: str) -> str:
    """Convert a metric name to a filesystem-safe string."""
    return name.replace("/", "_").replace(" ", "_")


class MultiMetricCheckpoint:
    """Save the best checkpoint for each monitored metric.

    Whenever a new best value is observed for a tracked metric, a checkpoint
    named ``best_{metric_name}.ckpt`` is written.  In addition,
    ``latest.ckpt`` is saved every epoch.

    Parameters
    ----------
    monitor_metrics:
        Metric keys to track (e.g. ``["val_accuracy", "val_f1"]``).
    checkpoint_dir:
        Directory where checkpoint files are written.
    mode:
        ``"max"`` if higher is better, ``"min"`` if lower is better.
    """

    def __init__(
        self,
        monitor_metrics: list[str],
        checkpoint_dir: Path,
        mode: str = "max",
    ) -> None:
        if mode not in ("max", "min"):
            raise ValueError(f"mode must be 'max' or 'min', got '{mode}'")

        self.monitor_metrics = monitor_metrics
        self.checkpoint_dir = Path(checkpoint_dir)
        self.mode = mode

        init_val = -math.inf if mode == "max" else math.inf
        self.best_values: dict[str, float] = {
            metric: init_val for metric in monitor_metrics
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _is_improvement(self, metric: str, value: float) -> bool:
        """Return *True* if *value* beats the current best for *metric*."""
        if self.mode == "max":
            return value > self.best_values[metric]
        return value < self.best_values[metric]

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def __call__(
        self,
        model: Any,
        optimizer: Any,
        epoch: int,
        metrics: dict[str, float],
        config: dict[str, Any],
    ) -> list[str]:
        """Check metrics, save checkpoints when a new best is found.

        Parameters
        ----------
        model:
            The model to checkpoint.
        optimizer:
            The optimizer to checkpoint.
        epoch:
            Current epoch number (1-based).
        metrics:
            Dictionary of current metric values.
        config:
            Full configuration dictionary stored inside the checkpoint.

        Returns
        -------
        list[str]
            Paths of all checkpoint files written this call.
        """
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        saved_paths: list[str] = []

        # 1. Always save latest.ckpt
        latest_path = self.checkpoint_dir / "latest.ckpt"
        save_checkpoint(model, optimizer, epoch, metrics, config, latest_path)
        saved_paths.append(str(latest_path))

        # 2. For each monitored metric, save best_{safe_name}.ckpt on improvement
        for metric in self.monitor_metrics:
            if metric not in metrics:
                continue
            value = float(metrics[metric])
            if self._is_improvement(metric, value):
                self.best_values[metric] = value
                safe = _safe_metric_name(metric)
                best_path = self.checkpoint_dir / f"best_{safe}.ckpt"
                save_checkpoint(
                    model, optimizer, epoch, metrics, config, best_path,
                )
                saved_paths.append(str(best_path))

        return saved_paths
