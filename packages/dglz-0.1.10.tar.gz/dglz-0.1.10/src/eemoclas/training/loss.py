"""Loss function factory for DGLZ training.

Supports cross-entropy with optional class weighting (manual or auto-computed
from manifest label distribution).

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    """Focal Loss for addressing class imbalance.

    FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)

    Parameters
    ----------
    gamma : float
        Focusing parameter. gamma=0 reduces to standard cross-entropy.
        Typical range: 1.0-5.0, default 2.0.
        Higher gamma -> more focus on hard-to-classify examples.
    alpha : torch.Tensor or None
        Per-class weight tensor (same as CrossEntropyLoss weight).
        When provided, applied as alpha_t to the focal term.
    label_smoothing : float
        Label smoothing coefficient (same as CrossEntropyLoss).
    """

    def __init__(self, gamma: float = 2.0, alpha: torch.Tensor | None = None,
                 label_smoothing: float = 0.0):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.label_smoothing = label_smoothing

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        ce = F.cross_entropy(
            logits, targets, weight=self.alpha,
            label_smoothing=self.label_smoothing, reduction="none",
        )
        pt = torch.exp(-ce)
        focal_loss = ce * ((1 - pt) ** self.gamma)
        return focal_loss.mean()


def create_criterion(config: dict, class_weights: torch.Tensor | None = None) -> nn.Module:
    """Create a loss function from training configuration.

    Parameters
    ----------
    config:
        Full configuration dictionary.  Reads ``training.loss`` (default
        ``"cross_entropy"``) and ``training.class_weight``.
    class_weights:
        Pre-computed class-weight tensor.  When supplied and
        ``training.class_weight`` is ``"auto"``, this tensor is used.
        Ignored when ``training.class_weight`` is an explicit list or ``None``.

    Returns
    -------
    nn.Module
        Instantiated loss function.

    Raises
    ------
    ValueError
        If ``training.loss`` names an unsupported loss function.
    """
    loss_name = config["training"].get("loss", "cross_entropy")
    class_weight_cfg = config["training"].get("class_weight", None)

    if loss_name == "cross_entropy":
        weight = _resolve_weight(class_weight_cfg, class_weights)
        label_smoothing = config["training"].get("label_smoothing", 0.0)
        return nn.CrossEntropyLoss(weight=weight, label_smoothing=label_smoothing)
    elif loss_name == "focal":
        weight = _resolve_weight(class_weight_cfg, class_weights)
        gamma = float(config["training"].get("focal_gamma", 2.0))
        label_smoothing = float(config["training"].get("label_smoothing", 0.0))
        return FocalLoss(gamma=gamma, alpha=weight, label_smoothing=label_smoothing)
    else:
        raise ValueError(f"Unknown loss: {loss_name}")


def _resolve_weight(
    class_weight_cfg,
    auto_weights: torch.Tensor | None,
) -> torch.Tensor | None:
    """Resolve the class weight specification to a tensor or ``None``.

    Parameters
    ----------
    class_weight_cfg:
        One of ``"auto"``, ``None``, or a list of floats.
    auto_weights:
        Pre-computed inverse-frequency weights (used when cfg is ``"auto"``).

    Returns
    -------
    torch.Tensor or None
    """
    if class_weight_cfg == "auto":
        if auto_weights is not None:
            return auto_weights
        # No auto weights available yet -- fall back to unweighted
        return None
    elif class_weight_cfg is not None:
        return torch.tensor(class_weight_cfg, dtype=torch.float32)
    return None


def compute_class_weights(manifest_df, label_col: str = "y") -> torch.Tensor:
    """Compute inverse-frequency class weights from a manifest DataFrame.

    The weight for class *c* is::

        w_c = N_total / (K * N_c)

    where *K* is the number of classes and *N_c* is the count of class *c*.

    Parameters
    ----------
    manifest_df:
        Pandas DataFrame containing at least the label column.
    label_col:
        Name of the column holding integer class labels.

    Returns
    -------
    torch.Tensor
        1-D float32 tensor of class weights, indexed by class label.
    """
    labels = manifest_df[label_col].values
    classes, counts = np.unique(labels, return_counts=True)
    total = counts.sum()
    n_classes = len(classes)
    weights = total / (n_classes * counts.astype(np.float64))
    weight_tensor = torch.zeros(int(classes.max()) + 1, dtype=torch.float32)
    for cls, w in zip(classes, weights):
        weight_tensor[int(cls)] = w
    return weight_tensor
