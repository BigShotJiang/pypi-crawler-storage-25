"""Optimizer factory for DGLZ training.

Supports AdamW (default), Adam, and SGD.  Accepts either a plain
``dict`` configuration (legacy) or an :class:`OptimizerConfig` dataclass
(new V0.1.4 typed path).

Apache-2.0  --  SuShuHeng
"""

from __future__ import annotations

from typing import Union

import torch.optim as optim

from eemoclas.config.dataclasses import OptimizerConfig


# ---------------------------------------------------------------------------
# Internal resolver
# ---------------------------------------------------------------------------

def _resolve_optimizer_config(
    config: Union[dict, OptimizerConfig],
) -> OptimizerConfig:
    """Normalise *config* into an :class:`OptimizerConfig`.

    Accepts:

    * :class:`OptimizerConfig` -- returned as-is.
    * ``dict`` with a ``"training"`` key -- reads the optimizer sub-dict or
      string and builds an :class:`OptimizerConfig`.
    * ``dict`` that *is* the optimizer config (no ``"training"`` key) --
      builds an :class:`OptimizerConfig` directly from the top-level keys.

    Returns
    -------
    OptimizerConfig
    """
    if isinstance(config, OptimizerConfig):
        return config

    # --- dict path ---
    if not isinstance(config, dict):
        raise TypeError(
            f"config must be a dict or OptimizerConfig, got {type(config).__name__}"
        )

    # Determine whether the dict is a full config (has "training") or already
    # the optimizer-level config.
    if "training" in config:
        section = config["training"]
        opt_val = section.get("optimizer", "adamw")
    else:
        # Assume this dict IS the optimizer config already.
        section = config
        opt_val = section.get("type", section.get("optimizer", "adamw"))

    # opt_val may be a string ("adamw") or a nested dict with optimizer params.
    if isinstance(opt_val, dict):
        return OptimizerConfig(
            type=opt_val.get("type", "adamw"),
            lr=float(opt_val.get("lr", opt_val.get("learning_rate", 1e-3))),
            weight_decay=float(opt_val.get("weight_decay", 1e-4)),
            betas=opt_val.get("betas", [0.9, 0.999]),
            eps=float(opt_val.get("eps", 1e-8)),
            momentum=float(opt_val.get("momentum", 0.9)),
            nesterov=bool(opt_val.get("nesterov", False)),
            amsgrad=bool(opt_val.get("amsgrad", False)),
        )

    # opt_val is a plain string naming the optimizer.
    opt_name = str(opt_val).lower()
    lr = float(section.get("lr", section.get("learning_rate", 1e-3)))
    weight_decay = float(section.get("weight_decay", 1e-4))
    betas = section.get("betas", [0.9, 0.999])
    eps = float(section.get("eps", 1e-8))
    momentum = float(section.get("momentum", 0.9))
    nesterov = bool(section.get("nesterov", False))
    amsgrad = bool(section.get("amsgrad", False))

    return OptimizerConfig(
        type=opt_name,
        lr=lr,
        weight_decay=weight_decay,
        betas=betas,
        eps=eps,
        momentum=momentum,
        nesterov=nesterov,
        amsgrad=amsgrad,
    )


# ---------------------------------------------------------------------------
# Public factory
# ---------------------------------------------------------------------------

def create_optimizer(model, config) -> optim.Optimizer:
    """Create an optimizer from configuration.

    Parameters
    ----------
    model:
        A ``torch.nn.Module`` whose parameters will be optimised.
    config:
        One of:

        * :class:`OptimizerConfig` dataclass (V0.1.4+)
        * Full configuration ``dict`` with a ``"training"`` section (legacy)
        * Optimizer-level ``dict`` (no ``"training"`` key)

    Returns
    -------
    optim.Optimizer
        Instantiated optimizer.

    Raises
    ------
    ValueError
        If the optimizer *type* names an unsupported optimiser.
    """
    opt_cfg = _resolve_optimizer_config(config)

    if opt_cfg.type == "adamw":
        return optim.AdamW(
            model.parameters(),
            lr=opt_cfg.lr,
            weight_decay=opt_cfg.weight_decay,
            betas=tuple(opt_cfg.betas),
            eps=opt_cfg.eps,
            amsgrad=opt_cfg.amsgrad,
        )
    elif opt_cfg.type == "adam":
        return optim.Adam(
            model.parameters(),
            lr=opt_cfg.lr,
            weight_decay=opt_cfg.weight_decay,
            betas=tuple(opt_cfg.betas),
            eps=opt_cfg.eps,
            amsgrad=opt_cfg.amsgrad,
        )
    elif opt_cfg.type == "sgd":
        return optim.SGD(
            model.parameters(),
            lr=opt_cfg.lr,
            momentum=opt_cfg.momentum,
            weight_decay=opt_cfg.weight_decay,
            nesterov=opt_cfg.nesterov,
        )
    else:
        raise ValueError(f"Unknown optimizer: {opt_cfg.type}")
