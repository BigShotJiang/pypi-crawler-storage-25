"""DGLZ: EEG emotion recognition with CNN-Transformer encoders."""

from eemoclas.__version__ import __version__

__all__ = ["__version__"]
