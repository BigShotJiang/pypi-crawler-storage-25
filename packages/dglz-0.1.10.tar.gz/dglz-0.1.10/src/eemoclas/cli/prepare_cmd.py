"""``eemo prepare`` -- scan raw data and generate index CSVs."""

from __future__ import annotations

import os
from typing import Optional

import typer

from eemoclas.cli.utils import console, print_cli_header, print_cli_success, print_cli_error

app = typer.Typer(help="扫描原始数据目录并生成索引 CSV 文件")


@app.callback(invoke_without_command=True)
def prepare(
    train_dir: str = typer.Option("data/raw/train", "--train-dir", help="训练集 .mat 文件所在目录"),
    test_dir: str = typer.Option("data/raw/test", "--test-dir", help="测试集 .mat 文件所在目录"),
    output_dir: str = typer.Option("data/index", "--output-dir", help="索引 CSV 输出目录"),
    config: str = typer.Option("configs/preprocess.yaml", "--config", help="预处理配置 YAML 文件路径"),
) -> None:
    """扫描 raw/train 和 raw/test，生成 train_subjects.csv 和 test_subjects.csv。"""
    print_cli_header("数据准备 -- 扫描原始数据目录")

    from eemoclas.data.index_builder import build_train_index, build_test_index
    from eemoclas.utils.config import load_config

    # Load config (optional -- fallback to empty dict)
    if os.path.isfile(config):
        cfg = load_config(config)
        console.print(f"  已加载配置文件 [cyan]{config}[/cyan]")
    else:
        cfg = {}
        console.print(f"  配置文件未找到 [yellow]{config}[/yellow]，使用默认值")

    # Build train index
    try:
        train_csv = build_train_index(train_dir, output_dir, cfg)
        print_cli_success(f"训练集索引已写入 {train_csv}")
    except (FileNotFoundError, ValueError) as exc:
        print_cli_error(f"训练集索引构建失败: {exc}")

    # Build test index
    try:
        test_csv = build_test_index(test_dir, output_dir, cfg)
        print_cli_success(f"测试集索引已写入 {test_csv}")
    except (FileNotFoundError, ValueError) as exc:
        print_cli_error(f"测试集索引构建失败: {exc}")

    console.print()
