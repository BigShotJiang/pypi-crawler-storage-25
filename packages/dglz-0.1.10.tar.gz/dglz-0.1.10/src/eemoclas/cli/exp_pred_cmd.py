"""``eemo exp-pred`` -- inference result management.

Provides subcommands for viewing, comparing, and exporting inference results
stored under the ``outputs/`` directory.
"""

from __future__ import annotations

import os
from pathlib import Path

import pandas as pd

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)

app = typer.Typer(help="推理结果管理")


@app.command()
def summary_pred(
    dir: str = typer.Option(..., "--dir", help="推理输出目录"),
) -> None:
    """查看推理结果摘要。"""
    print_cli_header("推理结果摘要")

    output_dir = Path(dir)
    if not output_dir.is_dir():
        print_cli_error(f"目录未找到: {output_dir}")
        raise typer.Exit(code=1)

    # Find submission files
    csv_path = output_dir / "submission.csv"
    xlsx_path = output_dir / "submission.xlsx"
    routing_path = output_dir / "routing_summary.csv"

    # Load submission
    sub_df = None
    if csv_path.is_file():
        sub_df = pd.read_csv(str(csv_path))
    elif xlsx_path.is_file():
        sub_df = pd.read_excel(str(xlsx_path))

    if sub_df is not None:
        console.print(f"  提交文件已加载: [cyan]{len(sub_df)}[/cyan] 行")
        console.print(f"  被试数: [cyan]{sub_df['user_id'].nunique()}[/cyan]")

        # Emotion label distribution
        label_counts = sub_df["Emotion_label"].value_counts().sort_index()
        for label, count in label_counts.items():
            name = "中性" if label == 0 else "积极"
            console.print(f"    {name} (标签={label}): [cyan]{count}[/cyan]")

        # Check 4:4 constraint per subject
        _validate_4_4_constraint(sub_df)
    else:
        print_cli_warning("未找到提交文件")

    # Load routing summary
    if routing_path.is_file():
        routing_df = pd.read_csv(str(routing_path))
        console.print(f"\n  路由汇总: [cyan]{len(routing_df)}[/cyan] 名被试")
        if "routed_model" in routing_df.columns:
            route_counts = routing_df["routed_model"].value_counts()
            for model, count in route_counts.items():
                console.print(f"    {model}: [cyan]{count}[/cyan] 名被试")
    else:
        print_cli_warning("未找到 routing_summary.csv")

    console.print()


@app.command()
def compare_pred(
    dirs: str = typer.Option(..., "--dirs", help="逗号分隔的推理输出目录列表"),
) -> None:
    """比较多次推理结果。"""
    print_cli_header("推理结果比较")

    dir_list = [d.strip() for d in dirs.split(",")]

    from rich.table import Table

    table = Table(title="推理结果对比", show_header=True, border_style="cyan")
    table.add_column("指标", style="bold")

    data_frames: list[pd.DataFrame] = []
    valid_dirs: list[str] = []

    for d in dir_list:
        path = Path(d)
        csv_path = path / "submission.csv"
        xlsx_path = path / "submission.xlsx"

        df = None
        if csv_path.is_file():
            df = pd.read_csv(str(csv_path))
        elif xlsx_path.is_file():
            df = pd.read_excel(str(xlsx_path))

        if df is None:
            print_cli_warning(f"未找到提交文件: {d}")
            continue

        data_frames.append(df)
        valid_dirs.append(d)
        table.add_column(Path(d).name, justify="right")

    if not valid_dirs:
        print_cli_error("无有效的推理目录可比较")
        raise typer.Exit(code=1)

    # Compare statistics
    rows = []
    for i, (df, dname) in enumerate(zip(data_frames, valid_dirs)):
        n_subjects = df["user_id"].nunique() if "user_id" in df.columns else 0
        n_positive = int(df["Emotion_label"].sum()) if "Emotion_label" in df.columns else 0
        n_total = len(df)

        if i == 0:
            rows.append(("被试数", []))
            rows.append(("总行数", []))
            rows.append(("积极标签数", []))
            rows.append(("积极比例", []))

        rows[0][1].append(str(n_subjects))
        rows[1][1].append(str(n_total))
        rows[2][1].append(str(n_positive))
        rows[3][1].append(f"{n_positive / max(1, n_total):.4f}")

    for metric_name, values in rows:
        table.add_row(metric_name, *values)

    # Agreement analysis between first two results
    if len(data_frames) >= 2:
        df1, df2 = data_frames[0], data_frames[1]
        if "Emotion_label" in df1.columns and "Emotion_label" in df2.columns:
            if len(df1) == len(df2):
                agree = (df1["Emotion_label"].values == df2["Emotion_label"].values).sum()
                total = len(df1)
                console.print(f"\n  一致性 ({valid_dirs[0]} vs {valid_dirs[1]}): "
                              f"[cyan]{agree}/{total} ({agree/total:.2%})[/cyan]")

    console.print(table)
    console.print()


@app.command()
def export_pred(
    dir: str = typer.Option(..., "--dir", help="推理输出目录"),
    format: str = typer.Option("csv", "--format", help="导出格式: csv, xlsx, json"),
) -> None:
    """导出推理结果。"""
    print_cli_header("导出推理结果")

    output_dir = Path(dir)
    if not output_dir.is_dir():
        print_cli_error(f"目录未找到: {output_dir}")
        raise typer.Exit(code=1)

    # Find submission
    csv_path = output_dir / "submission.csv"
    xlsx_path = output_dir / "submission.xlsx"

    df = None
    if csv_path.is_file():
        df = pd.read_csv(str(csv_path))
    elif xlsx_path.is_file():
        df = pd.read_excel(str(xlsx_path))

    if df is None:
        print_cli_error("未找到可导出的提交文件")
        raise typer.Exit(code=1)

    # Export in requested format
    export_dir = output_dir / "export"
    export_dir.mkdir(parents=True, exist_ok=True)

    format_lower = format.lower()
    if format_lower == "csv":
        dest = export_dir / "submission_export.csv"
        df.to_csv(str(dest), index=False)
    elif format_lower == "xlsx":
        dest = export_dir / "submission_export.xlsx"
        df.to_excel(str(dest), index=False)
    elif format_lower == "json":
        dest = export_dir / "submission_export.json"
        df.to_json(str(dest), orient="records", indent=2)
    else:
        print_cli_error(f"不支持的格式: {format}，请使用 csv, xlsx 或 json")
        raise typer.Exit(code=1)

    print_cli_success(f"已导出到 {dest}")
    console.print()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _validate_4_4_constraint(df: pd.DataFrame) -> None:
    """Check that every subject has exactly 4 positive and 4 neutral labels."""
    for user_id, group in df.groupby("user_id"):
        n = len(group)
        pos = int(group["Emotion_label"].sum())
        if n != 8 or pos != 4:
            print_cli_warning(
                f"被试 {user_id}: {pos} 积极 / {n} 个试次 (期望 4/8)"
            )
            return
    print_cli_success("所有被试的 4:4 约束校验通过")
