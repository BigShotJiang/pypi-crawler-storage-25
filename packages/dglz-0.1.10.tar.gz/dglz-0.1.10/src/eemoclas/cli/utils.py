"""Shared CLI utilities: Rich-powered terminal output helpers."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def print_cli_header(title: str) -> None:
    """Print a command header with a blue border.

    Parameters
    ----------
    title:
        Header text to display.
    """
    console.print()
    console.print(Panel(title, border_style="blue", expand=False))
    console.print()


def print_cli_success(message: str) -> None:
    """Print a success message with a green checkmark.

    Parameters
    ----------
    message:
        Success text to display.
    """
    console.print(f"[bold green]\u2714[/bold green]  {message}")


def print_cli_error(message: str) -> None:
    """Print an error message with a red X.

    Parameters
    ----------
    message:
        Error text to display.
    """
    console.print(f"[bold red]\u2718[/bold red]  {message}")


def print_cli_warning(message: str) -> None:
    """Print a warning with a yellow exclamation mark.

    Parameters
    ----------
    message:
        Warning text to display.
    """
    console.print(f"[bold yellow]![/bold yellow]  {message}")


def print_doctor_result(checks: list[dict]) -> None:
    """Print doctor check results as a Rich table.

    Each dict in *checks* should have:
    * ``name`` -- check description
    * ``status`` -- one of ``"pass"``, ``"warn"``, ``"fail"``
    * ``detail`` -- optional extra information

    Parameters
    ----------
    checks:
        List of check result dictionaries.
    """
    table = Table(title="Environment Doctor", show_header=True, border_style="cyan")
    table.add_column("Check", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Detail")

    _status_style = {
        "pass": "[bold green]PASS[/bold green]",
        "warn": "[bold yellow]WARN[/bold yellow]",
        "fail": "[bold red]FAIL[/bold red]",
    }

    for check in checks:
        status = check.get("status", "fail")
        icon = _status_style.get(status, status)
        detail = check.get("detail", "")
        table.add_row(check.get("name", ""), icon, detail)

    console.print(table)
