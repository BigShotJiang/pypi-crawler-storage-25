"""``eemo helpme`` -- export HELP.md to the specified directory."""

from __future__ import annotations

from importlib import resources
from pathlib import Path

import typer

from eemoclas.cli.utils import console, print_cli_header, print_cli_success, print_cli_error

app = typer.Typer(help="导出 HELP.md 帮助文档")

# ---------------------------------------------------------------------------
# HELP.md source: bundled inside the eemoclas package
# ---------------------------------------------------------------------------

try:
    _help_ref = resources.files("eemoclas").joinpath("HELP.md")
except AttributeError:
    # Python < 3.9 fallback
    _help_ref = None


@app.callback(invoke_without_command=True)
def helpme(
    path: str = typer.Option("./docs/", "--path", help="HELP.md 导出目录"),
) -> None:
    """导出 HELP.md 帮助文档到指定目录。"""
    print_cli_header("导出 HELP.md")

    if _help_ref is None or not _help_ref.is_file():
        print_cli_error("HELP.md 源文件不存在（包内未找到）")
        raise typer.Exit(code=1)

    content = _help_ref.read_text(encoding="utf-8")

    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)
    dest = target / "HELP.md"

    if dest.exists():
        console.print(f"  [yellow]跳过[/yellow] {dest}（文件已存在）")
    else:
        dest.write_text(content, encoding="utf-8")
        print_cli_success(f"已创建 {dest}")

    console.print()
