"""``eemo pred`` -- single model prediction for debugging."""

from __future__ import annotations

import typer

app = typer.Typer(help="单模型预测（调试用）")


@app.callback(invoke_without_command=True)
def pred(
    name: str = typer.Argument(..., help="模型名称: subject_state, normal_emotion, depression_emotion"),
    config: str = typer.Option(..., "--config", help="配置 YAML 文件路径"),
    model_path: str = typer.Option(..., "--model", help="模型检查点文件路径 (.ckpt)"),
    data: str = typer.Option(..., "--data", help="数据清单 CSV 或数据目录路径"),
    output: str = typer.Option("outputs/pred.csv", "--output", help="预测结果输出 CSV 路径"),
) -> None:
    """运行单模型预测。"""
    from eemoclas.cli.predict_impl import run_predict

    run_predict(name, config, model_path, data, output)
