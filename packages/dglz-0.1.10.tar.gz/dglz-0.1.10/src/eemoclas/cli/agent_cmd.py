"""``eemo agent`` -- manage DGLZ training agents.

Provides ``claude`` subcommand to deploy Claude Code agent templates
(agents, skills, memory files, settings) to a target project directory.
"""

from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
)

app = typer.Typer(help="训练智能体管理")


def _get_template_dir() -> Path:
    """Resolve the bundled claude_templates directory."""
    try:
        import importlib.resources as ir
        # Python >= 3.9: files() returns Traversable
        ref = ir.files("eemoclas").joinpath("claude_templates")
        if ref.is_dir():
            return Path(str(ref))
    except Exception:
        pass
    # Fallback: relative to this file's package
    fallback = Path(__file__).resolve().parent.parent / "claude_templates"
    if fallback.is_dir():
        return fallback
    raise FileNotFoundError(
        "claude_templates directory not found in eemoclas package. "
        "Ensure the package is installed correctly."
    )


def _copy_tree(src: Path, dst: Path, base: Path | None = None) -> list[str]:
    """Recursively copy src to dst. Returns list of created/updated files.

    Parameters
    ----------
    src:
        Source file or directory.
    dst:
        Destination file or directory.
    base:
        The root target directory (``.claude/``) used for computing relative
        paths in the returned list.  Automatically captured on the first call.
    """
    created = []
    if base is None:
        # On first call dst is the top-level item inside .claude (e.g. .claude/agents)
        base = dst.parent
    if src.is_dir():
        dst.mkdir(parents=True, exist_ok=True)
        for item in sorted(src.iterdir()):
            sub_dst = dst / item.name
            created.extend(_copy_tree(item, sub_dst, base=base))
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src), str(dst))
        created.append(str(dst.relative_to(base)))
    return created


@app.command()
def claude(
    path: str = typer.Option(
        ".claude/", "--path", "-p",
        help="目标 .claude 目录路径（默认: .claude/）",
    ),
) -> None:
    """部署 Claude Code 训练智能体模板文件。

    将 dglztr/dglzvr agent 定义、7 个 skill、记忆模板和配置文件
    复制到指定的 .claude/ 目录。
    """
    print_cli_header("DGLZ 训练智能体部署")

    target = Path(path).resolve()
    if target.exists() and not target.is_dir():
        print_cli_error(f"目标路径已存在但不是目录: {target}")
        raise typer.Exit(code=1)

    # Get template source
    try:
        template_dir = _get_template_dir()
    except FileNotFoundError as exc:
        print_cli_error(str(exc))
        raise typer.Exit(code=1)

    console.print(f"  模板源: [cyan]{template_dir}[/cyan]")
    console.print(f"  目标路径: [cyan]{target}[/cyan]")
    console.print()

    # Copy each top-level item
    total_files = 0
    for item in sorted(template_dir.iterdir()):
        dst = target / item.name
        files = _copy_tree(item, dst)
        total_files += len(files)
        name = item.name
        if item.is_dir():
            console.print(f"  [green]{name}/[/green] ({len(files)} 个文件)")
        else:
            console.print(f"  [green]{name}[/green]")

    # Make shell scripts executable
    scripts_dir = target / "skills" / "agent-state" / "scripts"
    if scripts_dir.is_dir():
        for sh in scripts_dir.glob("*.sh"):
            sh.chmod(sh.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    print_cli_success(f"部署完成: {total_files} 个文件已复制到 {target}")
    console.print()
    console.print("  后续步骤:")
    console.print("  1. 在目标项目目录运行: [cyan]bash .claude/skills/agent-state/scripts/init_state.sh[/cyan]")
    console.print("  2. 启动 Claude Code 并使用 dglztr agent 开始训练")
    console.print()
