"""Prediction implementation for ``eemo pred``.

Loads a model checkpoint, creates a dataset from a manifest, runs inference,
and saves the predictions to a CSV file.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
    print_cli_warning,
)
from eemoclas.utils.config import load_config, resolve_c_eff


def run_predict(
    name: str,
    config_path: str,
    model_path: str,
    data_path: str,
    output_path: str,
) -> None:
    """Load model checkpoint, create dataset, run prediction, save results.

    Parameters
    ----------
    name:
        Model name (``"subject_state"``, ``"normal_emotion"``,
        ``"depression_emotion"``).
    config_path:
        Path to the YAML configuration file.
    model_path:
        Path to the ``.ckpt`` checkpoint file.
    data_path:
        Path to a manifest CSV or a directory of resampled data.
    output_path:
        Destination path for the prediction CSV.
    """
    print_cli_header(f"Pred -- {name}")

    # --- Validate inputs ---
    if not os.path.isfile(config_path):
        print_cli_error(f"Config file not found: {config_path}")
        raise SystemExit(1)
    if not os.path.isfile(model_path):
        print_cli_error(f"Checkpoint not found: {model_path}")
        raise SystemExit(1)

    # --- Resolve manifest ---
    manifest_path = _resolve_manifest(data_path)
    if manifest_path is None:
        print_cli_error(f"No manifest found in: {data_path}")
        raise SystemExit(1)

    console.print(f"  Manifest: [cyan]{manifest_path}[/cyan]")
    console.print(f"  Checkpoint: [cyan]{model_path}[/cyan]")

    # --- Load config ---
    cfg = load_config(config_path)
    c_eff = resolve_c_eff(cfg)

    # --- Device ---
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    console.print(f"  Device: [cyan]{device}[/cyan]")

    # --- Create model and load checkpoint ---
    from eemoclas.model.model_factory import create_model
    from eemoclas.training.checkpoint import load_checkpoint

    model = create_model(name, cfg)
    ckpt_data = load_checkpoint(model_path, model, device)
    model = model.to(device)
    console.print(f"  Checkpoint loaded from epoch {ckpt_data['epoch']}")

    # --- Create dataset and dataloader ---
    from eemoclas.datasets.resampled_dataset import ResampledTensorDataset
    from eemoclas.datasets.collate import collate_fn
    from torch.utils.data import DataLoader

    dataset = ResampledTensorDataset(manifest_path)
    loader = DataLoader(
        dataset,
        batch_size=cfg.get("training", {}).get("batch_size", 16),
        shuffle=False,
        collate_fn=collate_fn,
        num_workers=0,
    )
    console.print(f"  Dataset: [cyan]{len(dataset)}[/cyan] samples")

    # --- Run prediction ---
    from eemoclas.prediction.predictor import Predictor

    predictor = Predictor(model, device, cfg)
    results_df = predictor.predict(loader)

    # --- Save ---
    output_dir = Path(output_path).parent
    output_dir.mkdir(parents=True, exist_ok=True)
    results_df.to_csv(output_path, index=False)

    print_cli_success(f"Predictions saved to {output_path}")
    console.print(f"  Total samples: [cyan]{len(results_df)}[/cyan]")
    console.print()


def _resolve_manifest(data_path: str) -> str | None:
    """Resolve data_path to a manifest CSV path.

    Parameters
    ----------
    data_path:
        Either a direct path to a manifest CSV, or a directory containing
        ``manifest.csv``.

    Returns
    -------
    str or None
        Absolute path to the manifest, or None if not found.
    """
    if os.path.isfile(data_path):
        return os.path.abspath(data_path)

    # Try convention: <data_path>/manifest.csv
    candidate = os.path.join(data_path, "manifest.csv")
    if os.path.isfile(candidate):
        return os.path.abspath(candidate)

    return None
