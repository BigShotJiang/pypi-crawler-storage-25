"""``eemo doctor`` -- environment and dependency health check."""

from __future__ import annotations

import importlib
import platform
import sys

import typer

from eemoclas.cli.utils import console, print_cli_header, print_cli_success, print_cli_error, print_cli_warning

app = typer.Typer(help="环境健康检查")


@app.callback(invoke_without_command=True)
def doctor() -> None:
    """运行环境健康检查并报告状态。"""
    print_cli_header("环境检查")
    checks_passed = 0
    checks_total = 0

    # --- Python 版本 ---
    checks_total += 1
    py_ver = sys.version.split()[0]
    py_major, py_minor = sys.version_info[:2]
    if py_major >= 3 and py_minor >= 11:
        console.print(f"  [green]通过[/green]  Python {py_ver}")
        checks_passed += 1
    else:
        console.print(f"  [red]失败[/red]  Python {py_ver} (需要 >= 3.11)")

    # --- 核心依赖 ---
    core_deps = [
        ("numpy", "NumPy"),
        ("torch", "PyTorch"),
        ("scipy", "SciPy"),
        ("pandas", "Pandas"),
        ("typer", "Typer"),
        ("rich", "Rich"),
        ("sklearn", "scikit-learn"),
    ]

    for mod_name, display_name in core_deps:
        checks_total += 1
        try:
            mod = importlib.import_module(mod_name)
            ver = getattr(mod, "__version__", "unknown")
            console.print(f"  [green]通过[/green]  {display_name} {ver}")
            checks_passed += 1
        except ImportError:
            console.print(f"  [red]失败[/red]  {display_name} 未安装")

    # --- CUDA 检查 ---
    checks_total += 1
    try:
        import torch

        if torch.cuda.is_available():
            device_name = torch.cuda.get_device_name(0)
            cuda_ver = torch.version.cuda or "N/A"
            console.print(f"  [green]通过[/green]  CUDA {cuda_ver} ({device_name})")
            checks_passed += 1
        else:
            console.print("  [yellow]警告[/yellow]  CUDA 不可用（CPU 模式）")
            checks_passed += 1
    except Exception:
        console.print("  [yellow]警告[/yellow]  CUDA 检查失败")

    # --- 平台信息 ---
    console.print(f"  平台: {platform.system()} {platform.release()}")

    # --- 汇总 ---
    console.print()
    if checks_passed == checks_total:
        print_cli_success(f"全部 {checks_total} 项检查通过")
    elif checks_passed > 0:
        print_cli_warning(
            f"{checks_passed}/{checks_total} 项检查通过 -- 请修复上述失败项"
        )
    else:
        print_cli_error("所有检查均未通过 -- 环境可能存在问题")
    console.print()
