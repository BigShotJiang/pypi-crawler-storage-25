"""``eemo resample`` -- offline resample datasets for classifiers."""

from __future__ import annotations

import os

import typer

from eemoclas.cli.utils import console, print_cli_header, print_cli_success, print_cli_error

app = typer.Typer(help="离线重采样生成分类器训练数据集")


@app.callback(invoke_without_command=True)
def resample(
    config: str = typer.Option(..., "--config", help="重采样配置 YAML 文件路径"),
    workers: int = typer.Option(
        None, "--workers", "-w",
        min=1,
        help="并行工作线程数 (覆盖配置文件中的 resample.workers)",
    ),
    verbose: bool = typer.Option(False, "--verbose", help="启用详细输出模式"),
) -> None:
    """运行离线重采样，生成分类器训练数据集。"""
    print_cli_header("重采样 -- 生成分类器训练数据集")

    if not os.path.isfile(config):
        print_cli_error(f"配置文件未找到: {config}")
        raise typer.Exit(code=1)

    # Load unified config
    from eemoclas.config.loader import load_config
    from eemoclas.config.dataclasses import _dataclass_to_dict

    typed_cfg = load_config(config)
    cfg = _dataclass_to_dict(typed_cfg)
    # Ensure the resample section is available at the expected key
    if "resample" in cfg and "resampling" not in cfg:
        cfg["resampling"] = cfg["resample"]

    # Bridge config: resample.yaml uses a different structure than what
    # the resampler classes expect.  Flatten/merge into the shapes they need.
    signal_cfg = cfg.get("signal", {})
    resample_cfg = cfg.get("resample", cfg.get("resampling", {}))
    sampling_cfg = resample_cfg.get("sampling", {})
    gaussian_cfg = sampling_cfg.get("gaussian", {})
    channels_cfg = cfg.get("channels", {})

    # Build data section for resamplers
    data_cfg = cfg.setdefault("data", {})
    if not data_cfg.get("fs"):
        data_cfg["fs"] = signal_cfg.get("fs", 250)
    if not data_cfg.get("index_dir"):
        data_cfg["index_dir"] = "data/index"
    if not data_cfg.get("subjects_csv"):
        data_cfg["subjects_csv"] = os.path.join(data_cfg["index_dir"], "train_subjects.csv")
    # Channel set mapping
    if channels_cfg.get("mode") == "by_name" and channels_cfg.get("selected") == "all":
        data_cfg.setdefault("channel_set", "standard")

    # Flatten sampling params into resample section for resamplers
    resample_cfg.setdefault("window_seconds", sampling_cfg.get("window_seconds", 10.0))
    resample_cfg.setdefault("mu_seconds", gaussian_cfg.get("mu_seconds", 25.0))
    resample_cfg.setdefault("sigma_seconds", gaussian_cfg.get("sigma_seconds", 8.0))
    resample_cfg.setdefault("lower_seconds", gaussian_cfg.get("lower_seconds", 5.0))
    resample_cfg.setdefault("upper_seconds", gaussian_cfg.get("upper_seconds", 45.0))

    # CLI --workers overrides config file value
    if workers is not None:
        resample_cfg = cfg.setdefault("resample", {})
        resample_cfg["workers"] = workers

    if verbose:
        console.print(f"  已加载配置文件 [cyan]{config}[/cyan]")
        console.print(f"  数据集: {cfg.get('dataset', {}).get('name', 'N/A')}")
        actual_workers = cfg.get("resample", {}).get("workers", 1)
        console.print(f"  工作线程数: {actual_workers}")

    # Import and run the resample pipeline
    try:
        from eemoclas.resampling.subject_state_resampler import SubjectStateResampler
        from eemoclas.resampling.normal_emotion_resampler import NormalEmotionResampler
        from eemoclas.resampling.depression_emotion_resampler import DepressionEmotionResampler

        resamplers = {
            "subject_state": SubjectStateResampler,
            "normal_emotion": NormalEmotionResampler,
            "depression_emotion": DepressionEmotionResampler,
        }

        # Determine which classifiers to resample
        targets = cfg.get("resampling", cfg.get("resample", {})).get("targets", ["subject_state", "normal_emotion", "depression_emotion"])
        if isinstance(targets, str):
            targets = [targets]

        for target in targets:
            if target not in resamplers:
                print_cli_warning(f"未知的重采样目标: {target}，跳过")
                continue

            # Set per-target output_dir: data/resampled/{target}/{version}/
            output_cfg = resample_cfg.get("output", {})
            version = output_cfg.get("version", "version_001")
            cfg["data"]["output_dir"] = os.path.join("data/resampled", target, version)

            # Flatten per-target sampling params for this target
            per_target = resample_cfg.get("per_target", {}).get(target, {})
            for key, value in per_target.items():
                resample_cfg.setdefault(key, value)

            if verbose:
                console.print(f"  正在重采样 [cyan]{target}[/cyan] ...")

            resampler = resamplers[target](cfg)
            resampler.run()

            print_cli_success(f"{target} 重采样完成")

    except ImportError as exc:
        print_cli_error(f"缺少模块: {exc}")
        raise typer.Exit(code=1)
    except Exception as exc:
        print_cli_error(f"重采样失败: {exc}")
        raise typer.Exit(code=1)

    print_cli_success("所有重采样任务已完成")
    console.print()


def print_cli_warning(message: str) -> None:
    """Print a warning message (local helper to avoid circular import issues)."""
    from eemoclas.cli.utils import print_cli_warning as _warn
    _warn(message)
