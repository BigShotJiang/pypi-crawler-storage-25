"""``eemo config`` -- config management commands.

Provides ``validate`` and ``show`` subcommands for inspecting configuration
files.  Template export is handled by ``eemo get``.
"""

from __future__ import annotations

import os

import typer

from eemoclas.cli.utils import (
    console,
    print_cli_error,
    print_cli_header,
    print_cli_success,
)

app = typer.Typer(help="配置文件管理")


@app.command()
def validate(
    config: str = typer.Option(..., "--config", help="待校验的配置 YAML 文件路径"),
) -> None:
    """校验配置文件完整性。"""
    print_cli_header("配置文件校验")

    if not os.path.isfile(config):
        print_cli_error(f"配置文件未找到: {config}")
        raise typer.Exit(code=1)

    from eemoclas.utils.config import load_config, validate_config

    try:
        cfg = load_config(config)
        validate_config(cfg)
        print_cli_success(f"配置文件有效: {config}")

        # Show resolved C_eff
        from eemoclas.utils.config import resolve_c_eff
        c_eff = resolve_c_eff(cfg)
        console.print(f"  有效通道数 (C_eff): [cyan]{c_eff}[/cyan]")

    except (FileNotFoundError, ValueError) as exc:
        print_cli_error(str(exc))
        raise typer.Exit(code=1)

    console.print()


@app.command()
def show(
    config: str = typer.Option(..., "--config", help="待显示的配置 YAML 文件路径"),
    model: str = typer.Option(None, "--model", help="筛选指定模型配置段"),
) -> None:
    """显示生效的配置内容。"""
    print_cli_header("配置内容显示")

    if not os.path.isfile(config):
        print_cli_error(f"配置文件未找到: {config}")
        raise typer.Exit(code=1)

    from eemoclas.utils.config import load_config, resolve_c_eff
    from eemoclas.utils.rich_display import print_config_panel

    cfg = load_config(config)

    if model is not None:
        section = cfg.get(model)
        if section is None:
            print_cli_error(f"配置段 '{model}' 未找到。"
                            f"可用的段: {list(cfg.keys())}")
            raise typer.Exit(code=1)
        print_config_panel(section, title=f"配置段: {model}")
    else:
        print_config_panel(cfg, title=f"生效配置: {config}")

    c_eff = resolve_c_eff(cfg)
    console.print(f"  有效通道数 (C_eff): [cyan]{c_eff}[/cyan]")
    console.print()
