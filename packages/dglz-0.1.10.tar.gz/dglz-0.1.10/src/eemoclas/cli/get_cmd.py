"""``eemo get`` -- export config templates from bundled configs/base/."""

from __future__ import annotations

import importlib.resources as resources
from pathlib import Path

import typer

from eemoclas.cli.utils import console, print_cli_header, print_cli_success

app = typer.Typer(help="导出默认配置模板文件")

TEMPLATE_FILES = [
    "train_full.yaml",
    "resample.yaml",
    "infer_three_stage.yaml",
    "preprocess.yaml",
]


@app.callback(invoke_without_command=True)
def get(
    path: str = typer.Option("configs", "--path", help="配置模板导出目录"),
) -> None:
    """导出默认配置模板文件到指定目录。"""
    print_cli_header("导出配置模板")

    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)

    pkg = resources.files("eemoclas")

    for filename in TEMPLATE_FILES:
        src = pkg.joinpath("configs", "base", filename)
        dest = target / filename
        if dest.exists():
            console.print(f"  [yellow]跳过[/yellow] {dest}（文件已存在）")
            continue
        if not src.is_file():
            console.print(f"  [red]缺失[/red] 模板源文件: {src}")
            continue
        dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        print_cli_success(f"已创建 {dest}")

    console.print()
