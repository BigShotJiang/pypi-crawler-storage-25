"""``eemo version`` -- show version information."""

from __future__ import annotations

import typer


def register(app: typer.Typer) -> None:
    """Register the ``version`` command on the top-level Typer app.

    Parameters
    ----------
    app:
        The main ``eemo`` Typer application.
    """

    @app.command()
    def version() -> None:
        """显示版本号。"""
        from eemoclas.__version__ import __version__

        typer.echo(f"eemo (DGLZ) 版本 {__version__}")
