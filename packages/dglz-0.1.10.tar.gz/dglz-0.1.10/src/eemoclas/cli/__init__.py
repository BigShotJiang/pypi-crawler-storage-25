"""CLI module for the DGLZ EEG emotion recognition toolkit."""
