"""Optional in-memory caching layer for resampled datasets.

The :class:`MemoryPreloader` eagerly loads every ``.pt`` sample into RAM so
that subsequent epochs do not pay disk-I/O costs.  It is designed to be
**transparent**: the output format is identical to what the underlying
:class:`ResampledTensorDataset` produces, and it does not interfere with
``token_meta`` collation validation.
"""

from __future__ import annotations

import logging
from typing import Optional

from .resampled_dataset import ResampledTensorDataset

logger = logging.getLogger(__name__)


class MemoryPreloader:
    """Cache all ``.pt`` samples of a dataset in memory.

    Usage::

        dataset = ResampledTensorDataset(manifest_file)
        preloader = MemoryPreloader(dataset)
        preloader.preload()          # reads every sample once
        sample = preloader[0]        # served from RAM

    The object is **not** a :class:`torch.utils.data.Dataset` subclass on
    purpose -- it is a thin wrapper that delegates ``__len__`` and
    ``__getitem__`` to the wrapped dataset while transparently caching
    results.

    Parameters
    ----------
    dataset:
        The underlying dataset to cache.
    """

    def __init__(self, dataset: ResampledTensorDataset) -> None:
        self.dataset = dataset
        self._cache: dict[int, dict] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def preload(self) -> None:
        """Load every sample into the in-memory cache.

        This is a one-time cost proportional to the number of samples.
        Subsequent ``__getitem__`` calls will be served from RAM.
        """
        n = len(self.dataset)
        logger.info("Preloading %d samples into memory ...", n)
        for idx in range(n):
            self._cache[idx] = self.dataset[idx]
        logger.info("Preloading complete (%d samples cached).", n)

    # ------------------------------------------------------------------
    # Dataset-like interface
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.dataset)

    def __getitem__(self, idx: int) -> dict:
        """Return the cached sample if available, otherwise load from disk."""
        if idx in self._cache:
            return self._cache[idx]
        return self.dataset[idx]
