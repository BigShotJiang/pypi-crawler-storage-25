"""Custom collate functions for resampled EEG datasets."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import torch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TENSOR_KEYS = {"x", "y"}
_STRING_KEYS = {"subject_id"}
_LIST_DICT_KEYS = {"meta"}


def _stack_tensors(values: list[torch.Tensor]) -> torch.Tensor:
    """Stack a list of tensors along a new leading dimension."""
    return torch.stack(values, dim=0)


def _validate_token_meta_consistency(batch: list[dict]) -> None:
    """Ensure every sample in *batch* shares identical ``token_meta``.

    The ``token_meta`` encodes the channel layout that the model depends on.
    Mixing incompatible layouts inside a single batch would silently produce
    wrong results, so this check is **mandatory**.
    """
    if len(batch) <= 1:
        return

    reference = batch[0]["token_meta"]
    for i, sample in enumerate(batch[1:], start=1):
        other = sample["token_meta"]
        if reference != other:
            raise ValueError(
                f"token_meta mismatch between sample 0 and sample {i}. "
                f"Reference: {reference!r}, sample {i}: {other!r}"
            )


# ---------------------------------------------------------------------------
# Generic collate
# ---------------------------------------------------------------------------

def collate_fn(batch: list[dict]) -> dict:
    """Default collate function for :class:`ResampledTensorDataset`.

    Collation rules
    ---------------
    * ``x``, ``y`` and other tensor-valued keys: stacked into a single tensor
      along a new leading batch dimension.
    * ``token_meta``: taken from ``batch[0]`` after an **all-equal** check.
    * ``meta``: returned as a ``list[dict]`` (no stacking).
    * ``subject_id`` and other string-valued keys: returned as ``list[str]``.
    """
    _validate_token_meta_consistency(batch)

    collated: dict[str, Any] = {}

    # Gather all keys across the batch (union)
    all_keys: set[str] = set()
    for sample in batch:
        all_keys.update(sample.keys())

    for key in sorted(all_keys):
        values = [s[key] for s in batch]

        # token_meta -- take from first sample (already validated)
        if key == "token_meta":
            collated[key] = batch[0]["token_meta"]
            continue

        # meta -- list of dicts
        if key == "meta":
            collated[key] = values
            continue

        # Strings -> list of strings
        if isinstance(values[0], str):
            collated[key] = values
            continue

        # Tensors -> stacked
        if isinstance(values[0], torch.Tensor):
            collated[key] = _stack_tensors(values)
            continue

        # Lists (e.g. list[int], list[str]) -> keep as list
        if isinstance(values[0], list):
            collated[key] = values
            continue

        # Scalars (int, float) -> tensor
        if isinstance(values[0], (int, float)):
            collated[key] = torch.tensor(values)
            continue

        # Fallback -- keep as plain list
        collated[key] = values

    return collated


# ---------------------------------------------------------------------------
# Specialized collate functions
# ---------------------------------------------------------------------------

def collate_subject_state(batch: list[dict]) -> dict:
    """Collate function for :class:`SubjectStateDataset`.

    Extends the base :func:`collate_fn` with special handling for:

    * ``trial_segment_ids``    -- list of lists of ints
    * ``trial_emotion_labels`` -- list of lists
    * ``group_label``          -- stacked tensor
    """
    result = collate_fn(batch)

    # Ensure group_label is a stacked tensor if present
    if "group_label" in result and isinstance(result["group_label"], list):
        result["group_label"] = torch.tensor(result["group_label"])

    # trial_segment_ids and trial_emotion_labels stay as list-of-lists
    # (variable-length per trial) -- already handled by fallback in collate_fn

    return result


def collate_emotion(batch: list[dict]) -> dict:
    """Collate function for :class:`NormalEmotionDataset` and
    :class:`DepressionEmotionDataset`.

    Extends the base :func:`collate_fn` with special handling for:

    * ``emotion_label`` -- stacked tensor
    * ``segment_id``    -- list of strings / ints
    """
    result = collate_fn(batch)

    # Ensure emotion_label is a stacked tensor if present
    if "emotion_label" in result and isinstance(result["emotion_label"], list):
        result["emotion_label"] = torch.tensor(result["emotion_label"])

    return result
