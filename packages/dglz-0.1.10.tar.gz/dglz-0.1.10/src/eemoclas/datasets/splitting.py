"""Subject-level dataset splitting utilities.

The core principle is **data-leakage prevention**: every sample belonging to
the same subject must end up in the same fold so that no information about a
subject in the training set can leak into the validation set.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold, train_test_split


def build_group_splits(
    manifest_file: str,
    group_key: str = "subject_id",
    stratify_key: str | None = None,
    n_splits: int = 5,
    seed: int = 42,
    method: str = "StratifiedGroupKFold",
    train_ratio: float = 0.8,
    val_ratio: float = 0.2,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Split a manifest CSV into train / validation folds.

    Supports two splitting methods:

    * ``"StratifiedGroupKFold"`` (default): K-fold cross-validation with
      subject-level grouping and label stratification.  Returns *n_splits*
      fold pairs.
    * ``"holdout"``: Single train/val split by ratio.  Returns one fold pair.

    **Critical**: splitting is done at the *subject* level, **not** at the
    sample level.  All samples belonging to the same ``group_key`` value will
    always appear in the same fold.

    Parameters
    ----------
    manifest_file:
        Path to the manifest CSV file.
    group_key:
        Column used for grouping (default ``"subject_id"``).  Every unique
        value is treated as an indivisible group.
    stratify_key:
        Optional column used for stratification (e.g. ``"group_label"`` or
        ``"emotion_label"``).  When provided, the distribution of this
        column's values is kept approximately equal across folds.  The
        stratification label for a group is taken from the *first* row of
        that group in the manifest.
    n_splits:
        Number of folds (only used when ``method="StratifiedGroupKFold"``).
    seed:
        Random seed for reproducibility.
    method:
        Splitting method: ``"StratifiedGroupKFold"`` or ``"holdout"``.
    train_ratio:
        Training set ratio (only used when ``method="holdout"``).
    val_ratio:
        Validation set ratio (only used when ``method="holdout"``).

    Returns
    -------
    list[tuple[np.ndarray, np.ndarray]]
        A list of ``(train_indices, val_indices)`` tuples.  Each index array
        contains **positional** (integer) indices into the manifest
        ``DataFrame``.
    """
    df = pd.read_csv(manifest_file)

    if group_key not in df.columns:
        raise ValueError(
            f"Manifest is missing group_key column {group_key!r}. "
            f"Available columns: {list(df.columns)}"
        )

    # Build a subject-level table: one row per unique group_key value.
    # The stratify label for each subject is taken from its first row.
    subjects = df.groupby(group_key, sort=False).first().reset_index()

    # Determine stratification labels (at the subject level)
    if stratify_key and stratify_key in subjects.columns:
        stratify_labels = subjects[stratify_key].values
    else:
        stratify_labels = np.ones(len(subjects), dtype=int)

    if method == "holdout":
        return _holdout_split(
            df, subjects, stratify_labels,
            group_key=group_key,
            train_ratio=train_ratio,
            val_ratio=val_ratio,
            seed=seed,
        )

    # Default: StratifiedGroupKFold
    sgkf = StratifiedGroupKFold(
        n_splits=n_splits, shuffle=True, random_state=seed
    )

    splits: list[tuple[np.ndarray, np.ndarray]] = []
    for train_subject_idx, val_subject_idx in sgkf.split(
        subjects,
        stratify_labels,
        groups=subjects[group_key].values,
    ):
        train_subjects = set(subjects.iloc[train_subject_idx][group_key].values)
        val_subjects = set(subjects.iloc[val_subject_idx][group_key].values)

        train_indices = df.index[df[group_key].isin(train_subjects)].values.copy()
        val_indices = df.index[df[group_key].isin(val_subjects)].values.copy()

        # Sort for determinism
        train_indices.sort()
        val_indices.sort()

        splits.append((train_indices, val_indices))

    return splits


def _holdout_split(
    df: pd.DataFrame,
    subjects: pd.DataFrame,
    stratify_labels: np.ndarray,
    *,
    group_key: str,
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> list[tuple[np.ndarray, np.ndarray]]:
    """Perform a single train/val holdout split at the subject level."""
    subject_indices = np.arange(len(subjects))

    # Try stratified split first
    try:
        train_idx, val_idx = train_test_split(
            subject_indices,
            train_size=train_ratio,
            test_size=val_ratio,
            stratify=stratify_labels,
            random_state=seed,
        )
    except ValueError:
        # Fall back to non-stratified if too few samples per class
        train_idx, val_idx = train_test_split(
            subject_indices,
            train_size=train_ratio,
            test_size=val_ratio,
            random_state=seed,
        )

    train_subjects = set(subjects.iloc[train_idx][group_key].values)
    val_subjects = set(subjects.iloc[val_idx][group_key].values)

    train_indices = df.index[df[group_key].isin(train_subjects)].values.copy()
    val_indices = df.index[df[group_key].isin(val_subjects)].values.copy()
    train_indices.sort()
    val_indices.sort()

    return [(train_indices, val_indices)]
