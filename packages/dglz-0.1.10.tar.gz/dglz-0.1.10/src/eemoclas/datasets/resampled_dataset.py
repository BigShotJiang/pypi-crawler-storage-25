"""Base dataset that reads .pt samples via manifest.csv."""

from __future__ import annotations

import torch
import pandas as pd
from torch.utils.data import Dataset
from pathlib import Path

_REQUIRED_FIELDS = ("x", "y", "subject_id", "token_meta", "meta")


class ResampledTensorDataset(Dataset):
    """Base dataset that reads ``.pt`` sample files listed in a manifest CSV.

    Each row in the manifest must contain at least a ``sample_path`` column
    pointing to a ``.pt`` file.  The loaded sample must be a ``dict`` with the
    keys ``x``, ``y``, ``subject_id``, ``token_meta``, and ``meta``.

    Parameters
    ----------
    manifest_file:
        Path to the manifest CSV file.
    """

    def __init__(self, manifest_file: str) -> None:
        self.manifest_path = Path(manifest_file)
        if not self.manifest_path.exists():
            raise FileNotFoundError(f"Manifest file not found: {manifest_file}")

        self.manifest = pd.read_csv(manifest_file)

        # Validate required columns exist
        required_columns = {"sample_path", "subject_id"}
        missing = required_columns - set(self.manifest.columns)
        if missing:
            raise ValueError(
                f"Manifest is missing required columns: {sorted(missing)}"
            )

    # ------------------------------------------------------------------
    # Dataset protocol
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self.manifest)

    def __getitem__(self, idx: int) -> dict:
        """Load a ``.pt`` sample from the manifest's ``sample_path`` column."""
        row = self.manifest.iloc[idx]
        sample_path = row["sample_path"]
        sample: dict = torch.load(sample_path, weights_only=False)
        self._validate_sample(sample)
        return sample

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def _validate_sample(self, sample: dict) -> None:
        """Validate that *sample* contains every required top-level field.

        Subclasses should call ``super()._validate_sample(sample)`` first and
        then perform their own additional checks.
        """
        for field in _REQUIRED_FIELDS:
            if field not in sample:
                raise ValueError(
                    f"Sample missing required field: {field!r}. "
                    f"Present keys: {sorted(sample.keys())}"
                )

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def get_subject_ids(self) -> list[str]:
        """Return the sorted unique ``subject_id`` values in the manifest."""
        return sorted(self.manifest["subject_id"].unique().tolist())
