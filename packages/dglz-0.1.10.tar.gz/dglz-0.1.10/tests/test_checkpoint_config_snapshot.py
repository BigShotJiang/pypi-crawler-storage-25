"""Test checkpoint contains config snapshot."""

import os
import tempfile

import pytest
import torch

from eemoclas.training.checkpoint import save_checkpoint, load_checkpoint


class TestCheckpointConfigSnapshot:
    """Tests for checkpoint save/load with config snapshot."""

    def test_checkpoint_contains_config_snapshot(self):
        """Test that saved checkpoint includes config_snapshot."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            model = torch.nn.Linear(10, 2)
            optimizer = torch.optim.Adam(model.parameters())
            config = {"test": True, "nested": {"key": "value"}}
            metrics = {"accuracy": 0.95}

            ckpt_path = os.path.join(tmp_dir, "test.ckpt")
            save_checkpoint(
                model=model,
                optimizer=optimizer,
                epoch=1,
                metrics=metrics,
                config=config,
                path=ckpt_path,
            )

            assert os.path.exists(ckpt_path)

            fresh_model = torch.nn.Linear(10, 2)
            result = load_checkpoint(ckpt_path, fresh_model)

            assert "config_snapshot" in result
            assert result["config_snapshot"]["test"] is True
            assert result["config_snapshot"]["nested"]["key"] == "value"

    def test_checkpoint_preserves_metrics(self):
        """Test that metrics are preserved in checkpoint."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            model = torch.nn.Linear(10, 2)
            optimizer = torch.optim.Adam(model.parameters())
            metrics = {"val_loss": 0.42, "val_accuracy": 0.91}

            ckpt_path = os.path.join(tmp_dir, "test.ckpt")
            save_checkpoint(
                model=model,
                optimizer=optimizer,
                epoch=5,
                metrics=metrics,
                config={},
                path=ckpt_path,
            )

            fresh_model = torch.nn.Linear(10, 2)
            result = load_checkpoint(ckpt_path, fresh_model)

            assert result["metrics"]["val_loss"] == 0.42
            assert result["metrics"]["val_accuracy"] == 0.91

    def test_checkpoint_preserves_epoch(self):
        """Test that epoch number is preserved."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            model = torch.nn.Linear(10, 2)
            optimizer = torch.optim.Adam(model.parameters())

            ckpt_path = os.path.join(tmp_dir, "test.ckpt")
            save_checkpoint(
                model=model,
                optimizer=optimizer,
                epoch=42,
                metrics={},
                config={},
                path=ckpt_path,
            )

            fresh_model = torch.nn.Linear(10, 2)
            result = load_checkpoint(ckpt_path, fresh_model)

            assert result["epoch"] == 42

    def test_checkpoint_loads_weights(self):
        """Test that model weights are correctly loaded."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            model = torch.nn.Linear(10, 2)
            torch.nn.init.ones_(model.weight)
            torch.nn.init.zeros_(model.bias)
            optimizer = torch.optim.Adam(model.parameters())

            ckpt_path = os.path.join(tmp_dir, "test.ckpt")
            save_checkpoint(
                model=model,
                optimizer=optimizer,
                epoch=1,
                metrics={},
                config={},
                path=ckpt_path,
            )

            fresh_model = torch.nn.Linear(10, 2)
            load_checkpoint(ckpt_path, fresh_model)

            # Verify weights were loaded
            assert torch.allclose(fresh_model.weight, model.weight)
            assert torch.allclose(fresh_model.bias, model.bias)

    def test_checkpoint_missing_file_raises(self):
        """Test that loading a missing checkpoint raises FileNotFoundError."""
        fresh_model = torch.nn.Linear(10, 2)
        with pytest.raises(FileNotFoundError):
            load_checkpoint("/nonexistent/path.ckpt", fresh_model)

    def test_checkpoint_config_snapshot_is_yaml_serializable(self):
        """Test that config_snapshot only contains YAML-serializable data."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            model = torch.nn.Linear(10, 2)
            optimizer = torch.optim.Adam(model.parameters())

            # Config with various types
            config = {
                "string": "value",
                "integer": 42,
                "float": 3.14,
                "list": [1, 2, 3],
                "nested": {"inner": True},
            }

            ckpt_path = os.path.join(tmp_dir, "test.ckpt")
            save_checkpoint(
                model=model,
                optimizer=optimizer,
                epoch=1,
                metrics={},
                config=config,
                path=ckpt_path,
            )

            fresh_model = torch.nn.Linear(10, 2)
            result = load_checkpoint(ckpt_path, fresh_model)

            # All values should be YAML-compatible (no tensors, etc.)
            snapshot = result["config_snapshot"]
            assert isinstance(snapshot["string"], str)
            assert isinstance(snapshot["integer"], int)
            assert isinstance(snapshot["float"], float)
