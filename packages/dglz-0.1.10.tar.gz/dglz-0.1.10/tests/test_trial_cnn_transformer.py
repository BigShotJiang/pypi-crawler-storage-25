"""Test TrialCNNTransformer."""

import pytest
import torch

from eemoclas.model.trial_cnn_transformer import TrialCNNTransformer


class TestTrialCNNTransformerForwardShape:
    """Tests for TrialCNNTransformer forward output shape."""

    def test_trial_cnn_transformer_forward_shape(self):
        """Test [B, C_eff, 2500] -> [B, D]."""
        model = TrialCNNTransformer(
            input_channels=30,
            input_length=2500,
            projection_dim=128,
        )
        x = torch.randn(2, 30, 2500)
        out = model(x)

        assert out.shape == (2, 128)

    def test_trial_cnn_transformer_forward_shape_small(self):
        """Test with smaller projection dim."""
        model = TrialCNNTransformer(
            input_channels=10,
            input_length=2500,
            projection_dim=64,
        )
        x = torch.randn(4, 10, 2500)
        out = model(x)

        assert out.shape == (4, 64)

    def test_trial_cnn_transformer_cls_pooling(self):
        """Test with CLS token pooling (default)."""
        model = TrialCNNTransformer(
            input_channels=6,
            input_length=2500,
            projection_dim=32,
            use_cls_token=True,
            pooling="cls",
        )
        x = torch.randn(1, 6, 2500)
        out = model(x)

        assert out.shape == (1, 32)

    def test_trial_cnn_transformer_mean_pooling(self):
        """Test with mean pooling."""
        model = TrialCNNTransformer(
            input_channels=6,
            input_length=2500,
            projection_dim=32,
            use_cls_token=False,
            pooling="mean",
        )
        x = torch.randn(1, 6, 2500)
        out = model(x)

        assert out.shape == (1, 32)

    def test_trial_cnn_transformer_with_token_meta(self):
        """Test forward pass with token_meta."""
        model = TrialCNNTransformer(
            input_channels=3,
            input_length=2500,
            projection_dim=64,
        )
        x = torch.randn(2, 3, 2500)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
            {"source_channel": "FP2", "band_name": "alpha"},
            {"source_channel": "FZ", "band_name": "alpha"},
        ]
        out = model(x, token_meta=token_meta)

        assert out.shape == (2, 64)

    def test_trial_cnn_transformer_gradient_flow(self):
        """Test that gradients flow through the model."""
        model = TrialCNNTransformer(
            input_channels=6,
            input_length=2500,
            projection_dim=32,
        )
        x = torch.randn(1, 6, 2500, requires_grad=True)
        out = model(x)
        loss = out.sum()
        loss.backward()

        assert x.grad is not None
        assert x.grad.shape == x.shape
