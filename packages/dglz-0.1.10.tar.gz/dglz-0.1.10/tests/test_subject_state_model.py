"""Test SubjectStateCNNTransformer."""

import pytest
import torch

from eemoclas.model.subject_state_cnn_transformer import SubjectStateCNNTransformer


def _minimal_subject_state_config(
    projection_dim=64,
    input_channels=10,
    input_length=2500,
    num_classes=2,
):
    """Build a minimal config that produces a valid SubjectStateCNNTransformer."""
    return {
        "trial_encoder": {
            "input_channels": input_channels,
            "input_length": input_length,
            "projection_dim": projection_dim,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_cls_token": True,
            "pooling": "cls",
            "use_channel_embedding": True,
            "use_band_embedding": True,
            "transformer_num_layers": 1,
            "transformer_num_heads": 2,
            "transformer_dim_feedforward": 128,
            "transformer_dropout": 0.1,
        },
        "subject_encoder": {
            "num_layers": 1,
            "num_heads": 2,
            "dim_feedforward": 128,
            "dropout": 0.1,
        },
        "classification_head": {
            "input_dim": projection_dim,
            "num_classes": num_classes,
            "hidden_dims": [projection_dim],
            "dropout": 0.3,
        },
        "num_trials": 8,
    }


class TestSubjectStateCNNTransformer:
    """Tests for SubjectStateCNNTransformer."""

    def test_subject_state_cnn_transformer_forward_shape(self):
        """Test [B, 8, C_eff, 2500] -> [B, 2]."""
        config = _minimal_subject_state_config(
            projection_dim=64,
            input_channels=10,
        )
        model = SubjectStateCNNTransformer(config)
        x = torch.randn(2, 8, 10, 2500)
        out = model(x)

        assert out.shape == (2, 2)

    def test_subject_state_cnn_transformer_batch_size_1(self):
        """Test with batch size 1."""
        config = _minimal_subject_state_config(input_channels=6)
        model = SubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, 6, 2500)
        out = model(x)

        assert out.shape == (1, 2)

    def test_subject_state_cnn_transformer_gradient_flow(self):
        """Test that gradients flow through the full model."""
        config = _minimal_subject_state_config(
            projection_dim=32,
            input_channels=4,
        )
        model = SubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, 4, 2500, requires_grad=True)
        out = model(x)
        loss = out.sum()
        loss.backward()

        assert x.grad is not None

    def test_subject_state_cnn_transformer_with_token_meta(self):
        """Test forward pass with token_meta."""
        c_eff = 3
        config = _minimal_subject_state_config(
            projection_dim=32,
            input_channels=c_eff,
        )
        model = SubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, c_eff, 2500)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
            {"source_channel": "FP2", "band_name": "alpha"},
            {"source_channel": "FZ", "band_name": "alpha"},
        ]
        out = model(x, token_meta=token_meta)

        assert out.shape == (1, 2)

    def test_subject_state_cnn_transformer_num_classes(self):
        """Test with a custom number of classes."""
        config = _minimal_subject_state_config(
            projection_dim=32,
            input_channels=4,
            num_classes=3,
        )
        model = SubjectStateCNNTransformer(config)
        x = torch.randn(1, 8, 4, 2500)
        out = model(x)

        assert out.shape == (1, 3)

    @pytest.mark.skipif(not torch.cuda.is_available(), reason="No GPU available")
    def test_subject_state_cnn_transformer_cuda(self):
        """Test forward pass on CUDA."""
        config = _minimal_subject_state_config(
            projection_dim=32,
            input_channels=4,
        )
        model = SubjectStateCNNTransformer(config).cuda()
        x = torch.randn(1, 8, 4, 2500, device="cuda")
        out = model(x)

        assert out.shape == (1, 2)
        assert out.device.type == "cuda"
