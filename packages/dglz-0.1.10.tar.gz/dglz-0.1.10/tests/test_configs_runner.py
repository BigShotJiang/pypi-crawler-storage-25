# tests/test_configs_runner.py
"""Tests for configs_runner.py."""
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


def _import_runner():
    """Import configs_runner module."""
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("cr", "src/eemoclas/claude_templates/skills/configs-runner/scripts/configs_runner.py")
    mod = module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


class TestBuildCommand:
    def test_basic_command(self):
        mod = _import_runner()
        cmd = mod.build_command("configs/b1.yaml", "b1-subj-lr3e4", "subject_state")
        assert "conda" in cmd[0] or "conda" in " ".join(cmd)
        assert "--config" in cmd
        assert "configs/b1.yaml" in cmd
        assert "--models" in cmd
        assert "subject_state" in cmd
        assert "--experiment-name" in cmd
        assert "b1-subj-lr3e4" in cmd

    def test_command_with_stage2(self):
        mod = _import_runner()
        cmd = mod.build_command("configs/b2.yaml", "b2-emo-normal", "normal_emotion")
        assert "normal_emotion" in cmd


class TestRunSingleExperiment:
    @patch("subprocess.run")
    def test_success(self, mock_run):
        mod = _import_runner()
        mock_run.return_value = MagicMock(returncode=0, stdout="Training complete", stderr="")
        result = mod.run_single_experiment("configs/b1.yaml", "b1-subj", "subject_state", timeout=60)
        assert result["status"] == "success"

    @patch("subprocess.run")
    def test_failure(self, mock_run):
        mod = _import_runner()
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="Error")
        result = mod.run_single_experiment("configs/b1.yaml", "b1-subj", "subject_state", timeout=60)
        assert result["status"] == "failed"

    @patch("subprocess.run")
    def test_timeout(self, mock_run):
        import subprocess
        mod = _import_runner()
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="test", timeout=60)
        result = mod.run_single_experiment("configs/b1.yaml", "b1-subj", "subject_state", timeout=60)
        assert result["status"] == "timeout"


class TestReadBatchFile:
    def test_valid_batch_file(self, tmp_path):
        mod = _import_runner()
        batch = tmp_path / "batch1.txt"
        batch.write_text("configs/a.yaml,a\nconfigs/b.yaml,b\n")
        experiments = mod.read_batch_file(str(batch))
        assert len(experiments) == 2
        assert experiments[0] == ("configs/a.yaml", "a")

    def test_empty_batch_file(self, tmp_path):
        mod = _import_runner()
        batch = tmp_path / "empty.txt"
        batch.write_text("")
        experiments = mod.read_batch_file(str(batch))
        assert len(experiments) == 0

    def test_comments_and_blanks(self, tmp_path):
        mod = _import_runner()
        batch = tmp_path / "batch.txt"
        batch.write_text("# comment\n\nconfigs/a.yaml,a\n")
        experiments = mod.read_batch_file(str(batch))
        assert len(experiments) == 1
