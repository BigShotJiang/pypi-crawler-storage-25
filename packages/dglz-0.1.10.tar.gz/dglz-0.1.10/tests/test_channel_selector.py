"""Test channel selection."""

import numpy as np
import pytest

from eemoclas.data.channel_selector import (
    resolve_channels,
    select_channels,
    CHANNEL_NAMES,
)


class TestResolveChannels:
    """Tests for resolve_channels."""

    def test_channel_select_by_name(self):
        """Test selecting channels by name."""
        config = {
            "channels": {
                "mode": "by_name",
                "selected": ["FP1", "FP2", "FZ"],
            }
        }
        indices, names = resolve_channels(config)

        assert indices == [0, 1, 4]
        assert names == ["FP1", "FP2", "FZ"]

    def test_channel_select_by_name_case_insensitive(self):
        """Test that channel name lookup is case-insensitive."""
        config = {
            "channels": {
                "mode": "by_name",
                "selected": ["fp1", "fp2", "fz"],
            }
        }
        indices, names = resolve_channels(config)

        assert indices == [0, 1, 4]
        assert names == ["FP1", "FP2", "FZ"]

    def test_channel_select_by_1based_index(self):
        """Test selecting channels by 1-based index."""
        config = {
            "channels": {
                "mode": "by_index_1based",
                "selected": [1, 2, 5],
            }
        }
        indices, names = resolve_channels(config)

        assert indices == [0, 1, 4]

    def test_channel_select_by_0based_index(self):
        """Test selecting channels by 0-based index."""
        config = {
            "channels": {
                "mode": "by_index_0based",
                "selected": [0, 1, 4],
            }
        }
        indices, names = resolve_channels(config)

        assert indices == [0, 1, 4]

    def test_channel_select_all(self):
        """Test selecting all 30 channels."""
        config = {
            "channels": {
                "mode": "by_name",
                "selected": "all",
            }
        }
        indices, names = resolve_channels(config)

        assert len(indices) == 30
        assert len(names) == 30
        assert indices == list(range(30))

    def test_channel_select_all_returns_standard_order(self):
        """Test that 'all' returns channels in standard order."""
        config = {
            "channels": {
                "mode": "by_name",
                "selected": "all",
            }
        }
        indices, names = resolve_channels(config)

        assert names == CHANNEL_NAMES

    def test_channel_select_invalid_name(self):
        """Test that an unknown channel name raises ValueError."""
        config = {
            "channels": {
                "mode": "by_name",
                "selected": ["INVALID_CHANNEL"],
            }
        }
        with pytest.raises(ValueError, match="Unknown channel name"):
            resolve_channels(config)

    def test_channel_select_invalid_1based_index(self):
        """Test that an out-of-range 1-based index raises ValueError."""
        config = {
            "channels": {
                "mode": "by_index_1based",
                "selected": [0],  # 1-based 0 is invalid
            }
        }
        with pytest.raises(ValueError, match="out of range"):
            resolve_channels(config)

    def test_channel_select_invalid_mode(self):
        """Test that an unknown mode raises ValueError."""
        config = {
            "channels": {
                "mode": "invalid_mode",
                "selected": ["FP1"],
            }
        }
        with pytest.raises(ValueError, match="Unknown channels.mode"):
            resolve_channels(config)


class TestSelectChannels:
    """Tests for select_channels."""

    def test_channel_select_slice(self):
        """Test that select_channels correctly slices EEG array."""
        eeg = np.random.randn(30, 2500)
        selected = select_channels(eeg, [0, 4, 14])

        assert selected.shape == (3, 2500)
        np.testing.assert_array_equal(selected[0], eeg[0])
        np.testing.assert_array_equal(selected[1], eeg[4])
        np.testing.assert_array_equal(selected[2], eeg[14])

    def test_channel_select_returns_copy(self):
        """Test that select_channels returns a copy, not a view."""
        eeg = np.random.randn(30, 2500)
        selected = select_channels(eeg, [0, 1, 2])

        assert not np.shares_memory(selected, eeg)

    def test_channel_select_preserves_order(self):
        """Test that output channel order matches the input index order."""
        eeg = np.random.randn(30, 2500)
        # Request in non-sorted order
        selected = select_channels(eeg, [14, 0, 4])

        assert selected.shape == (3, 2500)
        np.testing.assert_array_equal(selected[0], eeg[14])
        np.testing.assert_array_equal(selected[1], eeg[0])
        np.testing.assert_array_equal(selected[2], eeg[4])

    def test_channel_select_out_of_range(self):
        """Test that an out-of-range index raises ValueError."""
        eeg = np.random.randn(30, 2500)
        with pytest.raises(ValueError, match="out of range"):
            select_channels(eeg, [0, 30])  # index 30 is out of range for 30 channels

    def test_channel_select_empty_indices(self):
        """Test that empty indices raises ValueError."""
        eeg = np.random.randn(30, 2500)
        with pytest.raises(ValueError, match="non-empty"):
            select_channels(eeg, [])

    def test_channel_select_non_2d(self):
        """Test that a non-2D array raises ValueError."""
        eeg = np.random.randn(30, 2500, 1)
        with pytest.raises(ValueError, match="2-D"):
            select_channels(eeg, [0])
