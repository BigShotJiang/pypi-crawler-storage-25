"""Tests for the dotted-key override system (config/overrides.py).

Apache-2.0  --  SuShuHeng
"""

import pytest

from eemoclas.config.dataclasses import (
    Config,
    ExperimentConfig,
    ModelConfig,
    ModelGroupConfig,
    OptimizerConfig,
    ProjectConfig,
    TrainingConfig,
)
from eemoclas.config.overrides import _parse_value, apply_overrides


# ---------------------------------------------------------------------------
# _parse_value
# ---------------------------------------------------------------------------

class TestParseValue:
    """Verify _parse_value() type coercion."""

    def test_int(self):
        assert _parse_value("42") == 42
        assert isinstance(_parse_value("42"), int)

    def test_negative_int(self):
        assert _parse_value("-7") == -7
        assert isinstance(_parse_value("-7"), int)

    def test_float(self):
        assert _parse_value("3.14") == pytest.approx(3.14)
        assert isinstance(_parse_value("3.14"), float)

    def test_negative_float(self):
        assert _parse_value("-0.001") == pytest.approx(-0.001)
        assert isinstance(_parse_value("-0.001"), float)

    def test_scientific_float(self):
        assert _parse_value("1e-3") == pytest.approx(1e-3)
        assert isinstance(_parse_value("1e-3"), float)

    def test_bool_true(self):
        assert _parse_value("true") is True
        assert _parse_value("True") is True
        assert _parse_value("TRUE") is True

    def test_bool_false(self):
        assert _parse_value("false") is False
        assert _parse_value("False") is False
        assert _parse_value("FALSE") is False

    def test_none(self):
        assert _parse_value("null") is None
        assert _parse_value("None") is None
        assert _parse_value("none") is None

    def test_string(self):
        assert _parse_value("hello") == "hello"
        assert isinstance(_parse_value("hello"), str)

    def test_string_with_spaces(self):
        assert _parse_value("hello world") == "hello world"

    def test_list(self):
        assert _parse_value("[1, 2, 3]") == [1, 2, 3]

    def test_list_of_floats(self):
        assert _parse_value("[0.9, 0.999]") == [0.9, 0.999]

    def test_empty_list(self):
        assert _parse_value("[]") == []

    def test_zero(self):
        assert _parse_value("0") == 0
        assert isinstance(_parse_value("0"), int)

    def test_zero_float(self):
        assert _parse_value("0.0") == pytest.approx(0.0)
        assert isinstance(_parse_value("0.0"), float)


# ---------------------------------------------------------------------------
# apply_overrides -- shallow fields
# ---------------------------------------------------------------------------

class TestApplyOverridesShallow:
    """Test overrides on top-level Config fields."""

    def test_experiment_name(self):
        cfg = Config()
        apply_overrides(cfg, ["experiment.name=exp002"])
        assert cfg.experiment.name == "exp002"

    def test_signal_fs(self):
        cfg = Config()
        apply_overrides(cfg, ["signal.fs=512"])
        assert cfg.signal.fs == 512

    def test_project_repo_name(self):
        cfg = Config()
        apply_overrides(cfg, ["project.repo_name=MyRepo"])
        assert cfg.project.repo_name == "MyRepo"

    def test_signal_zscore_enabled(self):
        cfg = Config()
        apply_overrides(cfg, ["signal.zscore.enabled=false"])
        assert cfg.signal.zscore.enabled is False

    def test_signal_zscore_eps(self):
        cfg = Config()
        apply_overrides(cfg, ["signal.zscore.eps=1e-4"])
        assert cfg.signal.zscore.eps == pytest.approx(1e-4)

    def test_logging_level(self):
        cfg = Config()
        apply_overrides(cfg, ["logging.level=DEBUG"])
        assert cfg.logging.level == "DEBUG"


# ---------------------------------------------------------------------------
# apply_overrides -- nested model group overrides
# ---------------------------------------------------------------------------

class TestApplyOverridesNested:
    """Test overrides on nested model-group structures."""

    @staticmethod
    def _make_config() -> Config:
        return Config(
            models={
                "subject_state": ModelGroupConfig(
                    task=None,
                    model=ModelConfig(class_name="SubjectStateModel", num_classes=2),
                    training=TrainingConfig(
                        optimizer=OptimizerConfig(lr=1e-3),
                    ),
                ),
            },
        )

    def test_model_training_lr(self):
        cfg = self._make_config()
        apply_overrides(cfg, ["models.subject_state.training.optimizer.lr=0.002"])
        assert cfg.models["subject_state"].training.optimizer.lr == pytest.approx(0.002)

    def test_model_class_name(self):
        cfg = self._make_config()
        apply_overrides(cfg, ["models.subject_state.model.class_name=NewModel"])
        assert cfg.models["subject_state"].model.class_name == "NewModel"

    def test_model_num_classes(self):
        cfg = self._make_config()
        apply_overrides(cfg, ["models.subject_state.model.num_classes=4"])
        assert cfg.models["subject_state"].model.num_classes == 4

    def test_training_epochs(self):
        cfg = self._make_config()
        apply_overrides(cfg, ["models.subject_state.training.epochs=200"])
        assert cfg.models["subject_state"].training.epochs == 200

    def test_training_batch_size(self):
        cfg = self._make_config()
        apply_overrides(cfg, ["models.subject_state.training.batch_size=32"])
        assert cfg.models["subject_state"].training.batch_size == 32


# ---------------------------------------------------------------------------
# apply_overrides -- multiple overrides at once
# ---------------------------------------------------------------------------

class TestApplyOverridesMultiple:
    """Test applying several overrides in a single call."""

    def test_multiple_overrides(self):
        cfg = Config()
        apply_overrides(cfg, [
            "experiment.name=multi_test",
            "signal.fs=512",
            "signal.zscore.enabled=false",
            "logging.level=WARNING",
        ])
        assert cfg.experiment.name == "multi_test"
        assert cfg.signal.fs == 512
        assert cfg.signal.zscore.enabled is False
        assert cfg.logging.level == "WARNING"


# ---------------------------------------------------------------------------
# apply_overrides -- returns same instance
# ---------------------------------------------------------------------------

class TestApplyOverridesReturnsSame:
    """Verify apply_overrides returns the same Config instance."""

    def test_returns_same_instance(self):
        cfg = Config()
        result = apply_overrides(cfg, ["experiment.name=test"])
        assert result is cfg


# ---------------------------------------------------------------------------
# apply_overrides -- error cases
# ---------------------------------------------------------------------------

class TestApplyOverridesErrors:
    """Verify error handling for malformed overrides."""

    def test_no_equals_sign(self):
        cfg = Config()
        with pytest.raises(ValueError, match="Invalid override format"):
            apply_overrides(cfg, ["no_equals_here"])

    def test_unknown_field_on_dataclass(self):
        cfg = Config()
        with pytest.raises(ValueError, match="Unknown field"):
            apply_overrides(cfg, ["experiment.nonexistent_field=42"])

    def test_unknown_top_level_field(self):
        cfg = Config()
        with pytest.raises(ValueError, match="Unknown field"):
            apply_overrides(cfg, ["nonexistent_section.foo=bar"])

    def test_empty_key_segment(self):
        cfg = Config()
        with pytest.raises(ValueError, match="empty segment"):
            apply_overrides(cfg, ["experiment..name=test"])

    def test_empty_override(self):
        cfg = Config()
        with pytest.raises(ValueError, match="empty segment"):
            apply_overrides(cfg, ["=value"])
