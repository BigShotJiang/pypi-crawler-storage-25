"""Test config loading and C_eff resolution."""

import os
import tempfile

import pytest
import yaml

from eemoclas.utils.config import resolve_c_eff, load_config, validate_config


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


# ---------------------------------------------------------------------------
# Tests for resolve_c_eff
# ---------------------------------------------------------------------------

class TestResolveCEff:
    """Tests for resolve_c_eff."""

    def test_resolve_c_eff_all_channels_broadband(self):
        """C_eff should be 30 when all channels use broadband."""
        config = {
            "channels": {"mode": "by_name", "selected": "all"},
            "band_definitions": {"broadband": [1, 45]},
            "channel_band_config": {"default_bands": ["broadband"], "per_channel": {}},
        }
        assert resolve_c_eff(config) == 30

    def test_resolve_c_eff_subset_channels(self):
        """C_eff should match sum of bands per selected channel."""
        config = {
            "channels": {"mode": "by_name", "selected": ["FP1", "FP2", "FZ"]},
            "band_definitions": {"alpha": [8, 13], "beta": [13, 30]},
            "channel_band_config": {"default_bands": ["alpha", "beta"], "per_channel": {}},
        }
        # 3 channels * 2 bands = 6
        assert resolve_c_eff(config) == 6

    def test_resolve_c_eff_single_channel_multi_band(self):
        """Test single channel with multiple bands."""
        config = {
            "channels": {"mode": "by_name", "selected": ["FP1"]},
            "band_definitions": {"delta": [1, 4], "theta": [4, 7], "alpha": [8, 13]},
            "channel_band_config": {"default_bands": ["delta", "theta", "alpha"], "per_channel": {}},
        }
        # 1 channel * 3 bands = 3
        assert resolve_c_eff(config) == 3

    def test_resolve_c_eff_per_channel_override(self):
        """Test per_channel band overrides."""
        config = {
            "channels": {"mode": "by_name", "selected": ["FP1", "FP2"]},
            "band_definitions": {"alpha": [8, 13], "beta": [13, 30], "gamma": [30, 45]},
            "channel_band_config": {
                "default_bands": ["alpha"],
                "per_channel": {"FP1": ["alpha", "beta", "gamma"]},
            },
        }
        # FP1: 3 bands, FP2: 1 band (default) => 4
        assert resolve_c_eff(config) == 4

    def test_resolve_c_eff_empty_config(self):
        """Test with minimal config (no channels or bands specified)."""
        config = {}
        # No band_definitions => default_bands becomes []
        # ALL_CHANNEL_NAMES with empty bands => 0
        # Actually: default_bands = list(band_defs.keys()) = [] when band_defs is empty
        result = resolve_c_eff(config)
        assert isinstance(result, int)
        assert result == 0

    def test_resolve_c_eff_all_channels_5_bands(self):
        """Test all 30 channels with 5 bands each."""
        config = {
            "channels": {"mode": "by_name", "selected": "all"},
            "band_definitions": {
                "delta": [1, 4], "theta": [4, 7], "alpha": [8, 13],
                "beta": [13, 30], "gamma": [30, 45],
            },
            "channel_band_config": {
                "default_bands": ["delta", "theta", "alpha", "beta", "gamma"],
                "per_channel": {},
            },
        }
        # 30 channels * 5 bands = 150
        assert resolve_c_eff(config) == 150


# ---------------------------------------------------------------------------
# Tests for load_config
# ---------------------------------------------------------------------------

class TestLoadConfig:
    """Tests for load_config."""

    def test_load_config_simple(self, tmp_dir):
        """Test loading a simple YAML config."""
        config_data = {"key": "value", "nested": {"a": 1}}
        config_path = os.path.join(tmp_dir, "test.yaml")
        with open(config_path, "w") as f:
            yaml.dump(config_data, f)

        loaded = load_config(config_path)
        assert loaded["key"] == "value"
        assert loaded["nested"]["a"] == 1

    def test_load_config_with_include(self, tmp_dir):
        """Test loading config with include directive."""
        base_data = {"base_key": "base_value"}
        base_path = os.path.join(tmp_dir, "base.yaml")
        with open(base_path, "w") as f:
            yaml.dump(base_data, f)

        main_data = {"include": "base.yaml", "main_key": "main_value"}
        main_path = os.path.join(tmp_dir, "main.yaml")
        with open(main_path, "w") as f:
            yaml.dump(main_data, f)

        loaded = load_config(main_path)
        assert loaded["base_key"] == "base_value"
        assert loaded["main_key"] == "main_value"

    def test_load_config_not_found(self):
        """Test that FileNotFoundError is raised for missing file."""
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path/config.yaml")

    def test_load_config_circular_include_raises(self, tmp_dir):
        """Test that circular includes raise ValueError."""
        path_a = os.path.join(tmp_dir, "a.yaml")
        path_b = os.path.join(tmp_dir, "b.yaml")

        with open(path_a, "w") as f:
            yaml.dump({"include": "b.yaml"}, f)
        with open(path_b, "w") as f:
            yaml.dump({"include": "a.yaml"}, f)

        with pytest.raises(ValueError, match="Circular include"):
            load_config(path_a)


# ---------------------------------------------------------------------------
# Tests for validate_config
# ---------------------------------------------------------------------------

class TestValidateConfig:
    """Tests for validate_config."""

    # -- Role detection -------------------------------------------------------

    def test_detect_training(self):
        from eemoclas.utils.config import _detect_config_role
        config = {"models": {"m1": {"model": {"num_classes": 2}, "training": {"epochs": 10}}}}
        assert _detect_config_role(config) == "training"

    def test_detect_inference(self):
        from eemoclas.utils.config import _detect_config_role
        config = {"models": {"m1": {"checkpoint": "a.ckpt", "config": "a.yaml"}}, "inference": {"routing": "hard"}}
        assert _detect_config_role(config) == "inference"

    def test_detect_resample(self):
        from eemoclas.utils.config import _detect_config_role
        config = {"resample": {"targets": ["a"]}, "signal": {"fs": 250}}
        assert _detect_config_role(config) == "resample"

    def test_detect_preprocess(self):
        from eemoclas.utils.config import _detect_config_role
        config = {"data": {"index_dir": "data/index"}, "signal": {"fs": 250}}
        assert _detect_config_role(config) == "preprocess"

    def test_detect_unknown(self):
        from eemoclas.utils.config import _detect_config_role
        config = {"foo": "bar"}
        assert _detect_config_role(config) == "unknown"

    def test_detect_legacy_training_is_unknown(self):
        """Legacy single-model format without 'models' dict is unknown."""
        from eemoclas.utils.config import _detect_config_role
        config = {"model": {"num_classes": 2}, "training": {"epochs": 10}}
        assert _detect_config_role(config) == "unknown"

    # -- Training validation --------------------------------------------------

    def test_validate_training_valid(self):
        config = {
            "models": {
                "m1": {"model": {"num_classes": 2}, "training": {"epochs": 10}},
            },
        }
        validate_config(config)

    def test_validate_training_missing_num_classes(self):
        config = {
            "models": {
                "m1": {"model": {"class_name": "X"}, "training": {"epochs": 10}},
            },
        }
        with pytest.raises(ValueError, match="model.num_classes"):
            validate_config(config)

    def test_validate_training_missing_epochs(self):
        config = {
            "models": {
                "m1": {"model": {"num_classes": 2}, "training": {"batch_size": 32}},
            },
        }
        with pytest.raises(ValueError, match="training.epochs"):
            validate_config(config)

    def test_validate_training_no_models_section(self):
        config = {"model": {"num_classes": 2}, "training": {"epochs": 10}}
        with pytest.raises(ValueError, match="无法识别"):
            validate_config(config)

    # -- Inference validation -------------------------------------------------

    def test_validate_inference_valid(self):
        config = {
            "inference": {"routing": "hard"},
            "models": {"m1": {"checkpoint": "a.ckpt", "config": "a.yaml"}},
        }
        validate_config(config)

    def test_validate_inference_missing_routing(self):
        config = {
            "inference": {"use_4_4_constraint": True},
            "models": {"m1": {"checkpoint": "a.ckpt"}},
        }
        with pytest.raises(ValueError, match="routing"):
            validate_config(config)

    def test_validate_inference_missing_checkpoint(self):
        config = {
            "inference": {"routing": "hard"},
            "models": {"m1": {"config": "a.yaml"}},
        }
        with pytest.raises(ValueError, match="checkpoint"):
            validate_config(config)

    # -- Resample validation --------------------------------------------------

    def test_validate_resample_valid(self):
        config = {
            "resample": {"targets": ["subject_state"]},
            "signal": {"fs": 250},
        }
        validate_config(config)

    def test_validate_resample_valid_with_workers(self):
        config = {
            "resample": {"targets": ["subject_state"], "workers": 4},
            "signal": {"fs": 250},
        }
        validate_config(config)

    def test_validate_resample_workers_default_one(self):
        """When workers is not specified, validation passes (defaults to 1)."""
        config = {
            "resample": {"targets": ["subject_state"]},
            "signal": {"fs": 250},
        }
        validate_config(config)

    def test_validate_resample_invalid_workers_zero(self):
        config = {
            "resample": {"targets": ["subject_state"], "workers": 0},
            "signal": {"fs": 250},
        }
        with pytest.raises(ValueError, match="workers"):
            validate_config(config)

    def test_validate_resample_invalid_workers_negative(self):
        config = {
            "resample": {"targets": ["subject_state"], "workers": -1},
            "signal": {"fs": 250},
        }
        with pytest.raises(ValueError, match="workers"):
            validate_config(config)

    def test_validate_resample_invalid_workers_string(self):
        config = {
            "resample": {"targets": ["subject_state"], "workers": "four"},
            "signal": {"fs": 250},
        }
        with pytest.raises(ValueError, match="workers"):
            validate_config(config)

    def test_validate_resample_missing_targets(self):
        config = {
            "resample": {"seed": 42},
            "signal": {"fs": 250},
        }
        with pytest.raises(ValueError, match="targets"):
            validate_config(config)

    # -- Preprocess validation ------------------------------------------------

    def test_validate_preprocess_valid(self):
        config = {
            "data": {"index_dir": "data/index"},
            "signal": {"fs": 250},
        }
        validate_config(config)

    def test_validate_preprocess_missing_index_dir(self):
        config = {
            "data": {"raw_train_dir": "data/raw"},
            "signal": {"fs": 250},
        }
        with pytest.raises(ValueError, match="index_dir"):
            validate_config(config)

    # -- Unknown config -------------------------------------------------------

    def test_validate_unknown_raises(self):
        config = {"foo": "bar"}
        with pytest.raises(ValueError, match="无法识别"):
            validate_config(config)
