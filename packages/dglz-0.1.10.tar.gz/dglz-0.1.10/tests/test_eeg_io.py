"""Test EEG .mat reading with auto-transpose."""

import numpy as np
import pytest
from scipy.io import savemat
import tempfile
import os

from eemoclas.data.eeg_io import load_train_mat, load_test_mat, CHANNEL_COUNT


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    """Provide a temporary directory that is cleaned up after the test."""
    with tempfile.TemporaryDirectory() as d:
        yield d


def _make_train_mat(path, neu_shape=(30, 50000), pos_shape=(30, 50000),
                    neu_key="EEG_data_neu", pos_key="EEG_data_pos"):
    """Helper: create a synthetic training .mat file."""
    savemat(path, {
        neu_key: np.random.randn(*neu_shape),
        pos_key: np.random.randn(*pos_shape),
    })


def _make_test_mat(path, data, key="EEG_data"):
    """Helper: create a synthetic test .mat file."""
    savemat(path, {key: data})


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestAutoTranspose:
    """Tests for the auto-transpose logic."""

    def test_eeg_io_auto_transpose(self, tmp_dir):
        """Test auto-transpose from [T, C] to [C, T]."""
        mat_path = os.path.join(tmp_dir, "train.mat")
        # Store as [50000, 30] -- transposed from expected [30, 50000]
        _make_train_mat(mat_path, neu_shape=(50000, 30), pos_shape=(50000, 30))

        result = load_train_mat(mat_path)

        assert result["EEG_data_neu"].shape == (30, 50000)
        assert result["EEG_data_pos"].shape == (30, 50000)

    def test_eeg_io_no_transpose_needed(self, tmp_dir):
        """Test that [C, T] arrays are left as-is."""
        mat_path = os.path.join(tmp_dir, "train.mat")
        _make_train_mat(mat_path, neu_shape=(30, 50000), pos_shape=(30, 50000))

        result = load_train_mat(mat_path)

        assert result["EEG_data_neu"].shape == (30, 50000)
        assert result["EEG_data_pos"].shape == (30, 50000)


class TestTrainLoad:
    """Tests for load_train_mat."""

    def test_eeg_io_train_load(self, tmp_dir):
        """Test loading training mat with EEG_data_neu and EEG_data_pos."""
        mat_path = os.path.join(tmp_dir, "train.mat")
        _make_train_mat(mat_path)

        result = load_train_mat(mat_path)

        assert "EEG_data_neu" in result
        assert "EEG_data_pos" in result
        assert isinstance(result["EEG_data_neu"], np.ndarray)
        assert isinstance(result["EEG_data_pos"], np.ndarray)
        assert result["EEG_data_neu"].dtype == np.float64
        assert result["EEG_data_pos"].dtype == np.float64

    def test_eeg_io_train_load_missing_key(self, tmp_dir):
        """Test that missing keys raise KeyError."""
        mat_path = os.path.join(tmp_dir, "bad.mat")
        # Only save one key instead of both
        savemat(mat_path, {"EEG_data_neu": np.random.randn(30, 50000)})

        with pytest.raises(KeyError, match="EEG_data_pos"):
            load_train_mat(mat_path)

    def test_eeg_io_train_load_custom_keys(self, tmp_dir):
        """Test loading with custom key names."""
        mat_path = os.path.join(tmp_dir, "custom.mat")
        savemat(mat_path, {
            "neutral": np.random.randn(30, 50000),
            "positive": np.random.randn(30, 50000),
        })

        result = load_train_mat(mat_path, neu_key="neutral", pos_key="positive")
        assert "neutral" in result
        assert "positive" in result


class TestTestLoad:
    """Tests for load_test_mat."""

    def test_eeg_io_test_auto_detect(self, tmp_dir):
        """Test auto-detection of test EEG matrix."""
        mat_path = os.path.join(tmp_dir, "test.mat")
        data = np.random.randn(30, 20000)
        _make_test_mat(mat_path, data, key="EEG_data")

        result = load_test_mat(mat_path)
        assert result.shape == (30, 20000)
        assert result.dtype == np.float64

    def test_eeg_io_test_auto_detect_transposed(self, tmp_dir):
        """Test auto-detection with transposed test matrix."""
        mat_path = os.path.join(tmp_dir, "test.mat")
        # Store as [20000, 30] -- needs transpose
        data = np.random.randn(20000, 30)
        _make_test_mat(mat_path, data, key="EEG_data")

        result = load_test_mat(mat_path)
        assert result.shape == (30, 20000)

    def test_eeg_io_test_candidate_keys(self, tmp_dir):
        """Test loading with explicit candidate keys."""
        mat_path = os.path.join(tmp_dir, "test.mat")
        data = np.random.randn(30, 20000)
        _make_test_mat(mat_path, data, key="my_eeg")

        result = load_test_mat(mat_path, candidate_keys=["my_eeg"])
        assert result.shape == (30, 20000)

    def test_eeg_io_test_no_valid_matrix(self, tmp_dir):
        """Test that ValueError is raised when no valid matrix exists."""
        mat_path = os.path.join(tmp_dir, "bad.mat")
        # Save data that does NOT have 30 in either dimension
        savemat(mat_path, {"bad_data": np.random.randn(10, 20)})

        with pytest.raises(ValueError, match="30-channel"):
            load_test_mat(mat_path)


class TestInvalidChannelCount:
    """Tests for invalid channel counts."""

    def test_eeg_io_invalid_channel_count(self, tmp_dir):
        """Test that wrong channel count raises ValueError."""
        mat_path = os.path.join(tmp_dir, "bad.mat")
        # Neither dimension is 30
        savemat(mat_path, {
            "EEG_data_neu": np.random.randn(20, 50000),
            "EEG_data_pos": np.random.randn(30, 50000),
        })

        with pytest.raises(ValueError, match="Neither dimension matches"):
            load_train_mat(mat_path)

    def test_eeg_io_non_2d_array(self, tmp_dir):
        """Test that a 1-D or 3-D array raises ValueError."""
        mat_path = os.path.join(tmp_dir, "bad.mat")
        savemat(mat_path, {
            "EEG_data_neu": np.random.randn(30, 50000),
            "EEG_data_pos": np.random.randn(30, 50000, 2),
        })

        with pytest.raises(ValueError, match="2-D"):
            load_train_mat(mat_path)
