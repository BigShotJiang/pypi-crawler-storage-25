"""Tests for the dataclass configuration system.

Apache-2.0  --  SuShuHeng
"""

from pathlib import Path

import pytest

from eemoclas.config.dataclasses import (
    AugmentationConfig,
    BandConfig,
    ChannelDropoutConfig,
    ChannelsConfig,
    ClassificationHeadConfig,
    Config,
    DataConfig,
    ExperimentConfig,
    GaussianNoiseConfig,
    GaussianSamplingConfig,
    InferenceConfig,
    InferenceModelConfig,
    LoggingConfig,
    MetricConfig,
    ModelConfig,
    ModelGroupConfig,
    OptimizerConfig,
    ProjectConfig,
    ResampleConfig,
    SamplingConfig,
    SchedulerConfig,
    SeedingConfig,
    SignalConfig,
    SplittingConfig,
    SubjectTransformerConfig,
    TaskConfig,
    TimeMaskConfig,
    TokenEmbeddingConfig,
    TrainingConfig,
    TransformerConfig,
    TrialEncoderConfig,
    ZscoreConfig,
    _dataclass_to_dict,
)


# ---------------------------------------------------------------------------
# Default-value tests
# ---------------------------------------------------------------------------

class TestProjectConfigDefaults:
    """Verify ProjectConfig defaults."""

    def test_defaults(self):
        cfg = ProjectConfig()
        assert cfg.repo_name == "DGLZ"
        assert cfg.package_name == "eemoclas"
        assert cfg.cli_name == "eemo"
        assert cfg.experiment_family == "default"


class TestSignalConfigDefaults:
    """Verify SignalConfig defaults."""

    def test_defaults(self):
        cfg = SignalConfig()
        assert cfg.fs == 250
        assert cfg.train_segment_points == 12500
        assert cfg.window_points == 2500
        assert cfg.clip_std == 5.0
        assert isinstance(cfg.zscore, ZscoreConfig)
        assert cfg.zscore.enabled is True
        assert cfg.zscore.eps == 1e-6


class TestOptimizerConfigDefaults:
    """Verify OptimizerConfig defaults."""

    def test_defaults(self):
        cfg = OptimizerConfig()
        assert cfg.type == "adamw"
        assert cfg.lr == 1e-3
        assert cfg.weight_decay == 1e-4
        assert cfg.betas == [0.9, 0.999]
        assert cfg.eps == 1e-8
        assert cfg.momentum == 0.9
        assert cfg.nesterov is False
        assert cfg.amsgrad is False


class TestSchedulerConfigDefaults:
    """Verify SchedulerConfig defaults."""

    def test_defaults(self):
        cfg = SchedulerConfig()
        assert cfg.type == "cosine"
        assert cfg.min_lr == 1e-6
        assert cfg.warmup_epochs == 5
        assert cfg.cosine_t_max == 0
        assert cfg.cosine_eta_min == 0.0
        assert cfg.warmrestart_t0 == 10
        assert cfg.warmrestart_t_mult == 2
        assert cfg.step_size == 0
        assert cfg.step_gamma == 0.1
        assert cfg.plateau_factor == 0.5
        assert cfg.plateau_patience == 5
        assert cfg.plateau_mode == "max"
        assert cfg.onecycle_pct_start == 0.3


class TestTrainingConfigDefaults:
    """Verify TrainingConfig defaults."""

    def test_defaults(self):
        cfg = TrainingConfig()
        assert cfg.epochs == 100
        assert cfg.batch_size == 16
        assert isinstance(cfg.optimizer, OptimizerConfig)
        assert isinstance(cfg.scheduler, SchedulerConfig)
        assert cfg.loss == "cross_entropy"
        assert cfg.class_weight is None
        assert cfg.gradient_clip_val == 0.0
        assert cfg.accumulate_grad_batches == 1
        assert cfg.mixed_precision is False
        assert cfg.num_workers == 4
        assert cfg.early_stopping_patience == 15
        assert cfg.save_latest is True
        assert cfg.save_best is True


# ---------------------------------------------------------------------------
# ExperimentConfig path properties
# ---------------------------------------------------------------------------

class TestExperimentConfigPaths:
    """Verify ExperimentConfig path properties."""

    def test_experiment_dir(self):
        cfg = ExperimentConfig(name="my_exp", save_dir="/tmp/runs")
        assert cfg.experiment_dir == Path("/tmp/runs/my_exp")

    def test_checkpoint_dir(self):
        cfg = ExperimentConfig(name="my_exp", save_dir="/tmp/runs")
        assert cfg.checkpoint_dir == Path("/tmp/runs/my_exp/checkpoints")

    def test_log_dir(self):
        cfg = ExperimentConfig(name="my_exp", save_dir="/tmp/runs")
        assert cfg.log_dir == Path("/tmp/runs/my_exp/logs")

    def test_result_dir(self):
        cfg = ExperimentConfig(name="my_exp", save_dir="/tmp/runs")
        assert cfg.result_dir == Path("/tmp/runs/my_exp/results")

    def test_metrics_dir(self):
        cfg = ExperimentConfig(name="my_exp", save_dir="/tmp/runs")
        assert cfg.metrics_dir == Path("/tmp/runs/my_exp/metrics")

    def test_default_values(self):
        cfg = ExperimentConfig()
        assert cfg.name == "default"
        assert cfg.save_dir == "experiments"
        assert cfg.save_best is True
        assert cfg.save_latest is True
        assert cfg.checkpoint_metric == ""
        assert cfg.monitor_metrics == []


# ---------------------------------------------------------------------------
# Config.get_model_config
# ---------------------------------------------------------------------------

class TestConfigGetModelConfig:
    """Verify Config.get_model_config() behaviour."""

    @staticmethod
    def _make_config() -> Config:
        return Config(
            models={
                "emotion_cnn": ModelGroupConfig(
                    task=TaskConfig(name="emotion", num_classes=3),
                    model=ModelConfig(
                        class_name="NormalEmotionCNNTransformer",
                        num_classes=3,
                    ),
                ),
                "depression_cnn": ModelGroupConfig(
                    task=TaskConfig(name="depression", num_classes=2),
                    model=ModelConfig(
                        class_name="SubjectStateCNNTransformer",
                        num_classes=2,
                    ),
                ),
            },
        )

    def test_returns_correct_model_config(self):
        cfg = self._make_config()
        mc = cfg.get_model_config("emotion_cnn")
        assert isinstance(mc, ModelGroupConfig)
        assert mc.model.class_name == "NormalEmotionCNNTransformer"
        assert mc.model.num_classes == 3

    def test_returns_second_model(self):
        cfg = self._make_config()
        mc = cfg.get_model_config("depression_cnn")
        assert mc.model.class_name == "SubjectStateCNNTransformer"
        assert mc.model.num_classes == 2

    def test_raises_for_unknown_model(self):
        cfg = self._make_config()
        with pytest.raises(KeyError, match="Unknown model group 'nonexistent'"):
            cfg.get_model_config("nonexistent")


# ---------------------------------------------------------------------------
# Config.config_snapshot roundtrip
# ---------------------------------------------------------------------------

class TestConfigSnapshot:
    """Verify Config.config_snapshot() roundtrip."""

    def test_snapshot_is_dict(self):
        cfg = Config()
        snap = cfg.config_snapshot()
        assert isinstance(snap, dict)

    def test_snapshot_contains_all_top_level_keys(self):
        cfg = Config()
        snap = cfg.config_snapshot()
        expected_keys = {
            "project", "signal", "channels", "band", "resample",
            "data", "models", "logging", "experiment", "inference", "metrics",
        }
        assert set(snap.keys()) == expected_keys

    def test_snapshot_nested_values(self):
        cfg = Config(
            project=ProjectConfig(repo_name="TestRepo"),
            signal=SignalConfig(fs=512),
        )
        snap = cfg.config_snapshot()
        assert snap["project"]["repo_name"] == "TestRepo"
        assert snap["signal"]["fs"] == 512
        assert snap["signal"]["zscore"]["enabled"] is True

    def test_snapshot_preserves_models(self):
        cfg = Config(
            models={
                "test_model": ModelGroupConfig(
                    model=ModelConfig(class_name="MyModel", num_classes=4),
                ),
            },
        )
        snap = cfg.config_snapshot()
        assert snap["models"]["test_model"]["model"]["class_name"] == "MyModel"
        assert snap["models"]["test_model"]["model"]["num_classes"] == 4

    def test_snapshot_no_dataclass_objects(self):
        """Ensure snapshot contains only plain dicts, not dataclass instances."""
        cfg = Config()
        snap = cfg.config_snapshot()
        # Recursively check that no value is a dataclass instance
        def _check(obj):
            if isinstance(obj, dict):
                for v in obj.values():
                    _check(v)
            elif isinstance(obj, list):
                for v in obj:
                    _check(v)
            else:
                assert not hasattr(obj, "__dataclass_fields__"), (
                    f"Found dataclass in snapshot: {type(obj)}"
                )
        _check(snap)


# ---------------------------------------------------------------------------
# Config.model_names
# ---------------------------------------------------------------------------

class TestConfigModelNames:
    """Verify Config.model_names() behaviour."""

    def test_empty(self):
        cfg = Config()
        assert cfg.model_names() == []

    def test_returns_insertion_ordered_names(self):
        cfg = Config(
            models={
                "beta_model": ModelGroupConfig(),
                "alpha_model": ModelGroupConfig(),
                "gamma_model": ModelGroupConfig(),
            },
        )
        assert cfg.model_names() == ["beta_model", "alpha_model", "gamma_model"]


# ---------------------------------------------------------------------------
# Additional coverage: nested dataclass defaults
# ---------------------------------------------------------------------------

class TestNestedDefaults:
    """Verify that nested dataclasses are independent between instances."""

    def test_model_config_defaults(self):
        mc = ModelConfig()
        assert mc.class_name == ""
        assert mc.input_num_trials == 8
        assert mc.input_length == 2500
        assert mc.input_channels == 0
        assert mc.num_classes == 2
        assert isinstance(mc.trial_encoder, TrialEncoderConfig)
        assert mc.subject_transformer is None
        assert isinstance(mc.classification_head, ClassificationHeadConfig)

    def test_trial_encoder_defaults(self):
        te = TrialEncoderConfig()
        assert te.projection_dim == 128
        assert te.cnn_channels == [16, 32, 64]
        assert te.kernel_sizes == [15, 9, 5]
        assert te.strides == [2, 2, 2]
        assert te.cnn_dropout == 0.1
        assert te.pooling == "cls"
        assert isinstance(te.token_embedding, TokenEmbeddingConfig)
        assert isinstance(te.transformer, TransformerConfig)

    def test_transformer_defaults(self):
        t = TransformerConfig()
        assert t.num_layers == 2
        assert t.num_heads == 4
        assert t.dim_feedforward == 256
        assert t.dropout == 0.1
        assert t.activation == "gelu"
        assert t.norm_first is True
        assert t.batch_first is True

    def test_augmentation_defaults(self):
        a = AugmentationConfig()
        assert a.enabled is False
        assert isinstance(a.gaussian_noise, GaussianNoiseConfig)
        assert isinstance(a.time_mask, TimeMaskConfig)
        assert isinstance(a.channel_dropout, ChannelDropoutConfig)
        assert a.gaussian_noise.enabled is False
        assert a.time_mask.enabled is False
        assert a.channel_dropout.enabled is False

    def test_splitting_defaults(self):
        s = SplittingConfig()
        assert s.method == "StratifiedGroupKFold"
        assert s.n_splits == 5
        assert s.group_key == "subject_id"
        assert s.seed == 42

    def test_seeding_defaults(self):
        s = SeedingConfig()
        assert s.random_seed == 42
        assert s.split_seed == 42
        assert s.init_seed == 42

    def test_band_config_defaults(self):
        b = BandConfig()
        assert "delta" in b.band_definitions
        assert "broadband" in b.band_definitions
        assert b.default_bands == ["broadband"]

    def test_resample_defaults(self):
        r = ResampleConfig()
        assert r.samples_per_subject == 16
        assert r.samples_per_segment == 8
        assert r.permute_trials is True
        assert r.save_format == "pt"
        assert r.seed == 42
        assert isinstance(r.sampling, SamplingConfig)
        assert isinstance(r.sampling.gaussian, GaussianSamplingConfig)

    def test_dataclass_independence(self):
        """Two instances must not share mutable defaults."""
        a = ModelConfig()
        b = ModelConfig()
        a.trial_encoder.cnn_channels.append(999)
        assert b.trial_encoder.cnn_channels == [16, 32, 64]
