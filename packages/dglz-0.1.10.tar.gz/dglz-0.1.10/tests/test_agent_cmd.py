# tests/test_agent_cmd.py
"""Tests for eemo agent claude command."""
import os
from pathlib import Path

import pytest
from typer.testing import CliRunner

runner = CliRunner()


def _import_app():
    """Import the CLI app."""
    from eemoclas.cli.main import app
    return app


class TestAgentClaudeDeploy:
    def test_deploy_creates_files(self, tmp_path):
        """Deploy templates to a target directory."""
        app = _import_app()
        target = tmp_path / ".claude"

        result = runner.invoke(app, ["agent", "claude", "--path", str(target)])
        assert result.exit_code == 0, f"CLI failed: {result.output}"

        # Verify key files exist
        assert (target / "settings.local.json").exists()
        assert (target / "agents" / "dglztr.md").exists()
        assert (target / "agents" / "dglzvr.md").exists()
        assert (target / "agent-memory" / "dglztr" / "MEMORY.md").exists()
        assert (target / "agent-memory" / "dglzvr" / "MEMORY.md").exists()

        # Verify skills
        assert (target / "skills" / "train-workflow" / "SKILL.md").exists()
        assert (target / "skills" / "configs-creator" / "SKILL.md").exists()
        assert (target / "skills" / "configs-creator" / "scripts" / "configs_creator.py").exists()
        assert (target / "skills" / "configs-runner" / "SKILL.md").exists()
        assert (target / "skills" / "configs-runner" / "scripts" / "configs_runner.py").exists()
        assert (target / "skills" / "get-results" / "SKILL.md").exists()
        assert (target / "skills" / "get-results" / "scripts" / "get_results.py").exists()
        assert (target / "skills" / "exp-review" / "SKILL.md").exists()
        assert (target / "skills" / "agent-state" / "SKILL.md").exists()
        assert (target / "skills" / "move-exp" / "SKILL.md").exists()
        assert (target / "skills" / "move-exp" / "scripts" / "move_exp.py").exists()

        # Verify shell scripts
        assert (target / "skills" / "agent-state" / "scripts" / "init_state.sh").exists()
        assert (target / "skills" / "agent-state" / "scripts" / "new_batch.sh").exists()
        assert (target / "skills" / "agent-state" / "scripts" / "update_step.sh").exists()
        assert (target / "skills" / "agent-state" / "scripts" / "save_review.sh").exists()

    def test_deploy_idempotent(self, tmp_path):
        """Running deploy twice should not fail."""
        app = _import_app()
        target = tmp_path / ".claude"

        result1 = runner.invoke(app, ["agent", "claude", "--path", str(target)])
        assert result1.exit_code == 0

        result2 = runner.invoke(app, ["agent", "claude", "--path", str(target)])
        assert result2.exit_code == 0

    def test_shell_scripts_executable(self, tmp_path):
        """Deployed shell scripts should be executable."""
        app = _import_app()
        target = tmp_path / ".claude"

        result = runner.invoke(app, ["agent", "claude", "--path", str(target)])
        assert result.exit_code == 0

        for sh in (target / "skills" / "agent-state" / "scripts").glob("*.sh"):
            mode = sh.stat().st_mode
            assert mode & os.X_OK, f"{sh.name} should be executable"

    def test_deploy_to_existing_dir(self, tmp_path):
        """Deploy to an existing directory with pre-existing files."""
        app = _import_app()
        target = tmp_path / ".claude"
        target.mkdir()

        # Create a pre-existing file
        (target / "existing_file.txt").write_text("keep me")

        result = runner.invoke(app, ["agent", "claude", "--path", str(target)])
        assert result.exit_code == 0
        assert (target / "existing_file.txt").exists()
        assert (target / "agents" / "dglztr.md").exists()
