"""Test token_meta consistency."""

import numpy as np
import pytest

from eemoclas.data.band_filter import apply_channel_band_filter


class TestTokenMetaFields:
    """Tests for token_meta entry fields."""

    def test_token_meta_fields(self):
        """Test each token_meta entry has required fields."""
        meta = {
            "source_channel": "FP1",
            "source_channel_index": 0,
            "band_name": "alpha",
            "low": 8.0,
            "high": 13.0,
        }
        assert "source_channel" in meta
        assert "band_name" in meta
        assert "low" in meta
        assert "high" in meta

    def test_token_meta_from_band_filter(self):
        """Test that apply_channel_band_filter produces valid token_meta."""
        eeg = np.random.randn(3, 2500)
        bands = {"alpha": [8, 13], "beta": [13, 30]}
        _, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2", "FZ"],
            selected_indices=[0, 1, 4],
            band_definitions=bands,
            channel_band_config={"default_bands": ["alpha", "beta"], "per_channel": {}},
            fs=250,
        )

        required_keys = {"source_channel", "source_channel_index", "band_name", "low", "high"}
        for meta in token_meta:
            assert required_keys.issubset(set(meta.keys()))
            assert isinstance(meta["source_channel"], str)
            assert isinstance(meta["source_channel_index"], int)
            assert isinstance(meta["band_name"], str)
            assert isinstance(meta["low"], float)
            assert isinstance(meta["high"], float)
            assert meta["low"] < meta["high"]

    def test_token_meta_channel_index_consistency(self):
        """Test that source_channel_index matches the provided indices."""
        eeg = np.random.randn(3, 2500)
        bands = {"broadband": [1, 45]}
        indices = [5, 14, 29]
        names = ["F4", "CZ", "O2"]

        _, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=names,
            selected_indices=indices,
            band_definitions=bands,
            channel_band_config={"default_bands": ["broadband"], "per_channel": {}},
            fs=250,
        )

        for i, meta in enumerate(token_meta):
            assert meta["source_channel_index"] == indices[i]
            assert meta["source_channel"] == names[i]
