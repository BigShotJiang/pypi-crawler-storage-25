"""Test truncated Gaussian sampling."""

import numpy as np
import pytest

from eemoclas.resampling.truncated_gaussian import TruncatedGaussianWindowSampler


class TestTruncatedGaussianWindowShape:
    """Tests for cropped window shape."""

    def test_truncated_gaussian_window_shape(self):
        """Test that cropped window has correct shape."""
        sampler = TruncatedGaussianWindowSampler(fs=250, window_seconds=10)
        eeg = np.random.randn(30, 12500)
        window = sampler.sample_window(12500)
        crop = sampler.crop(eeg, window)

        assert crop.shape == (30, 2500)

    def test_truncated_gaussian_window_shape_custom_fs(self):
        """Test with custom sampling frequency."""
        sampler = TruncatedGaussianWindowSampler(fs=500, window_seconds=5)
        eeg = np.random.randn(30, 25000)
        window = sampler.sample_window(25000)
        crop = sampler.crop(eeg, window)

        assert crop.shape == (30, 2500)  # 500 * 5 = 2500

    def test_truncated_gaussian_window_longer_segment(self):
        """Test with a segment longer than default."""
        sampler = TruncatedGaussianWindowSampler(fs=250, window_seconds=10)
        eeg = np.random.randn(30, 50000)
        window = sampler.sample_window(50000)
        crop = sampler.crop(eeg, window)

        assert crop.shape == (30, 2500)


class TestTruncatedGaussianBounds:
    """Tests for window center bounds."""

    def test_truncated_gaussian_bounds(self):
        """Test that window center stays within bounds."""
        sampler = TruncatedGaussianWindowSampler(
            mu_seconds=25, sigma_seconds=8, lower_seconds=5, upper_seconds=45
        )
        for seed in range(100):
            sampler.rng = np.random.default_rng(seed)
            window = sampler.sample_window(12500)
            assert window["center_seconds"] >= 5
            assert window["center_seconds"] <= 45

    def test_truncated_gaussian_start_end_within_segment(self):
        """Test that start_sample >= 0 and end_sample <= segment_points."""
        sampler = TruncatedGaussianWindowSampler(
            mu_seconds=25, sigma_seconds=8, lower_seconds=5, upper_seconds=45
        )
        for seed in range(100):
            sampler.rng = np.random.default_rng(seed)
            window = sampler.sample_window(12500)
            assert window["start_sample"] >= 0
            assert window["end_sample"] <= 12500
            assert window["end_sample"] - window["start_sample"] == sampler.window_points


class TestTruncatedGaussianManifestFields:
    """Tests for window dict field names."""

    def test_truncated_gaussian_manifest_field_names(self):
        """Test that window dict uses correct field names."""
        sampler = TruncatedGaussianWindowSampler()
        window = sampler.sample_window(12500)

        assert "center_seconds" in window
        assert "start_sample" in window
        assert "end_sample" in window

    def test_truncated_gaussian_no_forbidden_field_names(self):
        """Ensure forbidden names are NOT present."""
        sampler = TruncatedGaussianWindowSampler()
        window = sampler.sample_window(12500)

        assert "source_start_sample" not in window
        assert "source_end_sample" not in window

    def test_truncated_gaussian_field_types(self):
        """Test that field types are correct."""
        sampler = TruncatedGaussianWindowSampler()
        window = sampler.sample_window(12500)

        assert isinstance(window["center_seconds"], float)
        assert isinstance(window["start_sample"], int)
        assert isinstance(window["end_sample"], int)


class TestTruncatedGaussianEdgeCases:
    """Tests for edge cases."""

    def test_window_longer_than_segment_raises(self):
        """Test that window longer than segment raises ValueError."""
        sampler = TruncatedGaussianWindowSampler(fs=250, window_seconds=60)
        with pytest.raises(ValueError, match="window_points"):
            sampler.sample_window(12500)  # segment only 50 seconds

    def test_zero_segment_points_raises(self):
        """Test that zero segment_points raises ValueError."""
        sampler = TruncatedGaussianWindowSampler()
        with pytest.raises(ValueError, match="positive"):
            sampler.sample_window(0)

    def test_reproducible_with_seed(self):
        """Test that results are reproducible with the same seed."""
        sampler1 = TruncatedGaussianWindowSampler(seed=42)
        window1 = sampler1.sample_window(12500)

        sampler2 = TruncatedGaussianWindowSampler(seed=42)
        window2 = sampler2.sample_window(12500)

        assert window1["center_seconds"] == window2["center_seconds"]
        assert window1["start_sample"] == window2["start_sample"]
        assert window1["end_sample"] == window2["end_sample"]
