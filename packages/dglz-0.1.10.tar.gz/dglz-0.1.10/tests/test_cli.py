"""Test CLI commands."""

import pytest

# The CLI module imports sub-commands that may reference modules not yet
# implemented (e.g. pred_cmd, infer_three_stage_cmd).  We guard against
# ImportError by checking whether the main app can be imported.
try:
    from eemoclas.cli.main import app
    CLI_AVAILABLE = True
except ImportError:
    CLI_AVAILABLE = False

from eemoclas.__version__ import __version__


@pytest.mark.skipif(not CLI_AVAILABLE, reason="CLI module not fully importable")
class TestCLI:
    """Tests for CLI commands."""

    def test_cli_eemo_version(self):
        """Test that the version command outputs the correct version."""
        from typer.testing import CliRunner
        runner = CliRunner()
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert __version__ in result.output

    def test_cli_eemo_help(self):
        """Test that --help works."""
        from typer.testing import CliRunner
        runner = CliRunner()
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_cli_eemo_get_help(self):
        """Test that the get subcommand help works."""
        from typer.testing import CliRunner
        runner = CliRunner()
        result = runner.invoke(app, ["get", "--help"])
        assert result.exit_code == 0

    def test_cli_train_help(self):
        """Test that the train subcommand help works."""
        from typer.testing import CliRunner
        runner = CliRunner()
        result = runner.invoke(app, ["train", "--help"])
        assert result.exit_code == 0


class TestVersionModule:
    """Tests for the version module itself."""

    def test_version_string(self):
        """Test that __version__ is a valid version string (PEP 440)."""
        assert isinstance(__version__, str)
        import re
        assert re.match(
            r"^\d+\.\d+\.\d+(\.(post|dev|rc|a|b)\d*)?$",
            __version__,
        ), f"Invalid version string: {__version__}"
