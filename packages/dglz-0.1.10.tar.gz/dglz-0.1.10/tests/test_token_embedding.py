"""Test token embedding module."""

import pytest
import torch

from eemoclas.model.token_embedding import ChannelBandTokenEmbedding


class TestTokenEmbeddingForwardShape:
    """Tests for ChannelBandTokenEmbedding output shape."""

    def test_token_embedding_forward_shape_with_cls(self):
        """Test output shape with CLS token: [B, C_eff+1, D]."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=128,
            use_channel_embedding=True,
            use_band_embedding=True,
            use_cls_token=True,
        )
        tokens = torch.randn(2, 10, 128)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
        ] * 10

        out = embed(tokens, token_meta)

        assert out.shape == (2, 11, 128)

    def test_token_embedding_forward_shape_without_cls(self):
        """Test output shape without CLS token: [B, C_eff, D]."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=128,
            use_channel_embedding=True,
            use_band_embedding=True,
            use_cls_token=False,
        )
        tokens = torch.randn(2, 10, 128)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
        ] * 10

        out = embed(tokens, token_meta)

        assert out.shape == (2, 10, 128)

    def test_token_embedding_forward_no_meta(self):
        """Test forward pass without token_meta (only CLS token added)."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=64,
            use_cls_token=True,
        )
        tokens = torch.randn(3, 8, 64)

        out = embed(tokens, token_meta=None)

        assert out.shape == (3, 9, 64)

    def test_token_embedding_forward_no_meta_no_cls(self):
        """Test forward pass without token_meta and no CLS token."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=64,
            use_cls_token=False,
        )
        tokens = torch.randn(3, 8, 64)

        out = embed(tokens, token_meta=None)

        assert out.shape == (3, 8, 64)

    def test_token_embedding_different_embedding_dims(self):
        """Test with various embedding dimensions."""
        for dim in [32, 64, 128, 256]:
            embed = ChannelBandTokenEmbedding(
                embedding_dim=dim,
                use_cls_token=True,
            )
            tokens = torch.randn(2, 5, dim)
            token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * 5

            out = embed(tokens, token_meta)
            assert out.shape == (2, 6, dim)

    def test_token_embedding_only_channel_embedding(self):
        """Test with only channel embedding (no band embedding)."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=64,
            use_channel_embedding=True,
            use_band_embedding=False,
            use_cls_token=True,
        )
        tokens = torch.randn(2, 5, 64)
        token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * 5

        out = embed(tokens, token_meta)
        assert out.shape == (2, 6, 64)

    def test_token_embedding_only_band_embedding(self):
        """Test with only band embedding (no channel embedding)."""
        embed = ChannelBandTokenEmbedding(
            embedding_dim=64,
            use_channel_embedding=False,
            use_band_embedding=True,
            use_cls_token=True,
        )
        tokens = torch.randn(2, 5, 64)
        token_meta = [{"source_channel": "FP1", "band_name": "alpha"}] * 5

        out = embed(tokens, token_meta)
        assert out.shape == (2, 6, 64)

    def test_token_embedding_custom_channel_band_names(self):
        """Test with custom channel and band name lists."""
        channel_names = ["FP1", "FP2", "FZ"]
        band_names = ["alpha", "beta"]

        embed = ChannelBandTokenEmbedding(
            embedding_dim=32,
            channel_names=channel_names,
            band_names=band_names,
            use_cls_token=False,
        )
        tokens = torch.randn(1, 3, 32)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
            {"source_channel": "FP2", "band_name": "beta"},
            {"source_channel": "FZ", "band_name": "alpha"},
        ]

        out = embed(tokens, token_meta)
        assert out.shape == (1, 3, 32)
