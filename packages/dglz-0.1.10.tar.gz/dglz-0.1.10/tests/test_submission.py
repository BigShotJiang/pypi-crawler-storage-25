"""Test submission output."""

import os
import tempfile

import pandas as pd
import pytest

from eemoclas.prediction.submission import save_submission, validate_submission


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def _valid_submission_df(n_subjects=2):
    """Create a valid submission DataFrame with 8 trials per subject, 4 positive."""
    rows = []
    for s in range(n_subjects):
        for t in range(8):
            rows.append({
                "user_id": f"sub_{s:03d}",
                "trial_id": t + 1,
                "Emotion_label": 1 if t < 4 else 0,
            })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestSubmissionColumns:
    """Tests for submission column requirements."""

    def test_submission_columns(self):
        """Test that submission has only user_id, trial_id, Emotion_label."""
        df = _valid_submission_df()
        required = {"user_id", "trial_id", "Emotion_label"}
        assert required.issubset(set(df.columns))

    def test_save_submission_creates_files(self, tmp_dir):
        """Test that save_submission creates both .xlsx and .csv files."""
        df = _valid_submission_df()
        output_path = os.path.join(tmp_dir, "submission")
        save_submission(df, output_path)

        assert os.path.exists(output_path + ".xlsx")
        assert os.path.exists(output_path + ".csv")

    def test_save_submission_xlsx_has_three_columns(self, tmp_dir):
        """Test that the xlsx output has exactly the 3 required columns."""
        df = _valid_submission_df()
        # Add an extra column to verify it gets stripped
        df["extra"] = "should_be_removed"

        output_path = os.path.join(tmp_dir, "submission")
        save_submission(df, output_path)

        loaded = pd.read_excel(output_path + ".xlsx")
        assert set(loaded.columns) == {"user_id", "trial_id", "Emotion_label"}

    def test_save_submission_csv_has_three_columns(self, tmp_dir):
        """Test that the csv output has exactly the 3 required columns."""
        df = _valid_submission_df()
        df["extra"] = "should_be_removed"

        output_path = os.path.join(tmp_dir, "submission")
        save_submission(df, output_path)

        loaded = pd.read_csv(output_path + ".csv")
        assert set(loaded.columns) == {"user_id", "trial_id", "Emotion_label"}


class TestSubmissionValidation:
    """Tests for validate_submission."""

    def test_submission_validates_4_positive(self):
        """Test that validate_submission checks 4 positive per subject."""
        df = _valid_submission_df()
        assert validate_submission(df) is True

    def test_submission_invalidates_wrong_count(self):
        """Test that wrong number of positive labels fails validation."""
        rows = []
        for t in range(8):
            rows.append({
                "user_id": "sub_000",
                "trial_id": t + 1,
                "Emotion_label": 1 if t < 3 else 0,  # only 3 positive
            })
        df = pd.DataFrame(rows)

        assert validate_submission(df) is False

    def test_submission_invalidates_wrong_trial_count(self):
        """Test that wrong number of trials fails validation."""
        rows = []
        for t in range(6):  # only 6 trials instead of 8
            rows.append({
                "user_id": "sub_000",
                "trial_id": t + 1,
                "Emotion_label": 1 if t < 3 else 0,
            })
        df = pd.DataFrame(rows)

        assert validate_submission(df) is False

    def test_submission_missing_columns(self):
        """Test that missing columns fails validation."""
        df = pd.DataFrame({"user_id": ["s1"], "trial_id": [1]})
        assert validate_submission(df) is False

    def test_submission_multiple_subjects(self):
        """Test validation with multiple subjects, all valid."""
        df = _valid_submission_df(n_subjects=5)
        assert validate_submission(df) is True

    def test_submission_multiple_subjects_one_invalid(self):
        """Test validation fails when one subject has wrong count."""
        df = _valid_submission_df(n_subjects=2)
        # Corrupt the second subject: make all labels 0
        mask = df["user_id"] == "sub_001"
        df.loc[mask, "Emotion_label"] = 0

        assert validate_submission(df) is False

    def test_save_submission_missing_columns_raises(self, tmp_dir):
        """Test that saving with missing columns raises ValueError."""
        df = pd.DataFrame({"col_a": [1], "col_b": [2]})
        output_path = os.path.join(tmp_dir, "submission")

        with pytest.raises(ValueError, match="Submission must have columns"):
            save_submission(df, output_path)
