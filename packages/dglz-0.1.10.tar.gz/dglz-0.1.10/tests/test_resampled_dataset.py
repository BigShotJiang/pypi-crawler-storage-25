"""Test dataset loading."""

import os
import tempfile

import pandas as pd
import pytest
import torch

from eemoclas.datasets.resampled_dataset import ResampledTensorDataset


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def _create_sample_pt(path, x_shape=(30, 2500), y=0, subject_id="sub001"):
    """Create a minimal .pt sample file with required fields."""
    sample = {
        "x": torch.randn(*x_shape),
        "y": torch.LongTensor([y]),
        "subject_id": subject_id,
        "token_meta": [
            {"source_channel": "FP1", "band_name": "broadband", "low": 1.0, "high": 45.0}
        ] * x_shape[0],
        "meta": {
            "sampler": "truncated_gaussian",
            "center_seconds": 25.0,
            "start_sample": 5000,
            "end_sample": 7500,
        },
    }
    torch.save(sample, path)
    return sample


def _create_manifest(tmp_dir, n_samples=3):
    """Create a manifest.csv and corresponding .pt sample files."""
    samples_dir = os.path.join(tmp_dir, "samples")
    os.makedirs(samples_dir, exist_ok=True)

    rows = []
    for i in range(n_samples):
        sample_id = f"sample_{i:04d}"
        pt_path = os.path.join(samples_dir, f"{sample_id}.pt")
        _create_sample_pt(pt_path, subject_id=f"sub{i:03d}")
        rows.append({
            "sample_id": sample_id,
            "sample_path": pt_path,
            "subject_id": f"sub{i:03d}",
            "group_label": i % 2,
        })

    manifest_path = os.path.join(tmp_dir, "manifest.csv")
    df = pd.DataFrame(rows)
    df.to_csv(manifest_path, index=False)
    return manifest_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestResampledDatasetLoad:
    """Tests for loading .pt samples via ResampledTensorDataset."""

    def test_resampled_dataset_load_pt(self, tmp_dir):
        """Test loading a .pt sample via ResampledTensorDataset."""
        manifest_path = _create_manifest(tmp_dir)
        dataset = ResampledTensorDataset(manifest_path)

        assert len(dataset) == 3

        sample = dataset[0]
        assert "x" in sample
        assert "y" in sample
        assert "subject_id" in sample
        assert "token_meta" in sample
        assert "meta" in sample
        assert isinstance(sample["x"], torch.Tensor)
        assert sample["x"].shape == (30, 2500)

    def test_resampled_dataset_length(self, tmp_dir):
        """Test that dataset length matches manifest rows."""
        manifest_path = _create_manifest(tmp_dir, n_samples=5)
        dataset = ResampledTensorDataset(manifest_path)

        assert len(dataset) == 5

    def test_resampled_dataset_get_subject_ids(self, tmp_dir):
        """Test get_subject_ids returns sorted unique IDs."""
        manifest_path = _create_manifest(tmp_dir, n_samples=3)
        dataset = ResampledTensorDataset(manifest_path)

        subject_ids = dataset.get_subject_ids()
        assert len(subject_ids) == 3
        assert subject_ids == sorted(subject_ids)


class TestResampledDatasetValidation:
    """Tests for validation and error handling."""

    def test_resampled_dataset_missing_field_raises(self, tmp_dir):
        """Test that missing required field raises ValueError."""
        samples_dir = os.path.join(tmp_dir, "samples")
        os.makedirs(samples_dir, exist_ok=True)

        # Create a .pt file WITHOUT the required "y" field
        bad_sample = {
            "x": torch.randn(30, 2500),
            "subject_id": "sub001",
            "token_meta": [],
            "meta": {},
        }
        pt_path = os.path.join(samples_dir, "bad_sample.pt")
        torch.save(bad_sample, pt_path)

        # Create manifest pointing to the bad sample
        manifest_path = os.path.join(tmp_dir, "manifest.csv")
        pd.DataFrame([{
            "sample_id": "bad_sample",
            "sample_path": pt_path,
            "subject_id": "sub001",
        }]).to_csv(manifest_path, index=False)

        dataset = ResampledTensorDataset(manifest_path)
        with pytest.raises(ValueError, match="missing required field"):
            dataset[0]

    def test_resampled_dataset_missing_manifest_raises(self, tmp_dir):
        """Test that a nonexistent manifest file raises FileNotFoundError."""
        fake_path = os.path.join(tmp_dir, "nonexistent.csv")
        with pytest.raises(FileNotFoundError):
            ResampledTensorDataset(fake_path)

    def test_resampled_dataset_missing_columns_raises(self, tmp_dir):
        """Test that manifest without required columns raises ValueError."""
        manifest_path = os.path.join(tmp_dir, "manifest.csv")
        pd.DataFrame([{"sample_id": "s1"}]).to_csv(manifest_path, index=False)

        with pytest.raises(ValueError, match="missing required columns"):
            ResampledTensorDataset(manifest_path)

    def test_resampled_dataset_all_required_fields(self, tmp_dir):
        """Verify that all required fields are present in loaded sample."""
        manifest_path = _create_manifest(tmp_dir, n_samples=1)
        dataset = ResampledTensorDataset(manifest_path)
        sample = dataset[0]

        required = {"x", "y", "subject_id", "token_meta", "meta"}
        assert required.issubset(set(sample.keys()))
