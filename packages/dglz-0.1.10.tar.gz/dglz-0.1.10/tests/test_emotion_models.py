"""Test NormalEmotionCNNTransformer and DepressionEmotionCNNTransformer."""

import pytest
import torch

from eemoclas.model.normal_emotion_cnn_transformer import NormalEmotionCNNTransformer
from eemoclas.model.depression_emotion_cnn_transformer import DepressionEmotionCNNTransformer


def _minimal_emotion_config(projection_dim=64, input_channels=10, num_classes=2):
    """Build a minimal config that produces a valid emotion model."""
    return {
        "trial_encoder": {
            "input_channels": input_channels,
            "input_length": 2500,
            "projection_dim": projection_dim,
            "cnn_channels": [16, 32],
            "kernel_sizes": [7, 5],
            "strides": [2, 2],
            "cnn_dropout": 0.1,
            "use_cls_token": True,
            "pooling": "cls",
            "use_channel_embedding": True,
            "use_band_embedding": True,
            "transformer_num_layers": 1,
            "transformer_num_heads": 2,
            "transformer_dim_feedforward": 128,
            "transformer_dropout": 0.1,
        },
        "classification_head": {
            "input_dim": projection_dim,
            "num_classes": num_classes,
            "hidden_dims": [projection_dim],
            "dropout": 0.3,
        },
    }


class TestNormalEmotionCNNTransformer:
    """Tests for NormalEmotionCNNTransformer."""

    def test_normal_emotion_cnn_transformer_forward_shape(self):
        """Test [B, C_eff, 2500] -> [B, 2]."""
        config = _minimal_emotion_config(
            projection_dim=64,
            input_channels=10,
        )
        model = NormalEmotionCNNTransformer(config)
        x = torch.randn(2, 10, 2500)
        out = model(x)

        assert out.shape == (2, 2)

    def test_normal_emotion_forward_batch_1(self):
        """Test with batch size 1."""
        config = _minimal_emotion_config(input_channels=6)
        model = NormalEmotionCNNTransformer(config)
        x = torch.randn(1, 6, 2500)
        out = model(x)

        assert out.shape == (1, 2)

    def test_normal_emotion_forward_with_token_meta(self):
        """Test forward pass with token_meta."""
        config = _minimal_emotion_config(input_channels=3)
        model = NormalEmotionCNNTransformer(config)
        x = torch.randn(2, 3, 2500)
        token_meta = [
            {"source_channel": "FP1", "band_name": "alpha"},
            {"source_channel": "FP2", "band_name": "beta"},
            {"source_channel": "FZ", "band_name": "alpha"},
        ]
        out = model(x, token_meta=token_meta)

        assert out.shape == (2, 2)

    def test_normal_emotion_gradient_flow(self):
        """Test gradient flow."""
        config = _minimal_emotion_config(
            projection_dim=32,
            input_channels=4,
        )
        model = NormalEmotionCNNTransformer(config)
        x = torch.randn(1, 4, 2500, requires_grad=True)
        out = model(x)
        loss = out.sum()
        loss.backward()

        assert x.grad is not None

    def test_normal_emotion_num_classes(self):
        """Test with custom number of classes."""
        config = _minimal_emotion_config(
            projection_dim=32,
            input_channels=4,
            num_classes=3,
        )
        model = NormalEmotionCNNTransformer(config)
        x = torch.randn(1, 4, 2500)
        out = model(x)

        assert out.shape == (1, 3)


class TestDepressionEmotionCNNTransformer:
    """Tests for DepressionEmotionCNNTransformer."""

    def test_depression_emotion_cnn_transformer_forward_shape(self):
        """Test [B, C_eff, 2500] -> [B, 2]."""
        config = _minimal_emotion_config(
            projection_dim=64,
            input_channels=10,
        )
        model = DepressionEmotionCNNTransformer(config)
        x = torch.randn(2, 10, 2500)
        out = model(x)

        assert out.shape == (2, 2)

    def test_depression_emotion_forward_batch_1(self):
        """Test with batch size 1."""
        config = _minimal_emotion_config(input_channels=6)
        model = DepressionEmotionCNNTransformer(config)
        x = torch.randn(1, 6, 2500)
        out = model(x)

        assert out.shape == (1, 2)

    def test_depression_emotion_independent_parameters(self):
        """Test that depression and normal models have independent parameters."""
        config = _minimal_emotion_config(input_channels=6)

        model_normal = NormalEmotionCNNTransformer(config)
        model_depr = DepressionEmotionCNNTransformer(config)

        # Parameters should be distinct Python objects (not shared)
        params_normal = dict(model_normal.named_parameters())
        params_depr = dict(model_depr.named_parameters())

        assert set(params_normal.keys()) == set(params_depr.keys())
        for name in params_normal:
            # Each parameter must be a different tensor object
            assert params_normal[name].data_ptr() != params_depr[name].data_ptr(), (
                f"Parameter '{name}' is shared between normal and depression models"
            )

    @pytest.mark.skipif(not torch.cuda.is_available(), reason="No GPU available")
    def test_depression_emotion_cuda(self):
        """Test forward pass on CUDA."""
        config = _minimal_emotion_config(
            projection_dim=32,
            input_channels=4,
        )
        model = DepressionEmotionCNNTransformer(config).cuda()
        x = torch.randn(1, 4, 2500, device="cuda")
        out = model(x)

        assert out.shape == (1, 2)
        assert out.device.type == "cuda"
