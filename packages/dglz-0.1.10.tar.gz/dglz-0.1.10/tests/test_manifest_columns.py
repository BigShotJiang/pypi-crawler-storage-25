"""Test manifest column requirements."""

import json
import os
import tempfile

import pandas as pd
import pytest

from eemoclas.resampling.manifest import (
    build_subject_state_manifest_row,
    build_emotion_manifest_row,
)


# ---------------------------------------------------------------------------
# Required columns
# ---------------------------------------------------------------------------

SUBJECT_STATE_COLUMNS = [
    "sample_id", "sample_path", "subject_id", "group_label",
    "num_trials", "c_eff", "length", "seed",
    "source_segments", "trial_segment_ids", "trial_emotion_labels",
]

EMOTION_COLUMNS = [
    "sample_id", "sample_path", "subject_id", "group_label",
    "emotion_label", "segment_id",
    "center_seconds", "start_sample", "end_sample",
    "c_eff", "length", "seed",
]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    with tempfile.TemporaryDirectory() as d:
        yield d


def _subject_state_row(**overrides):
    """Build a minimal subject_state manifest row."""
    defaults = dict(
        sample_id="ss_sub001_0000",
        sample_path="/tmp/sample.pt",
        subject_id="sub001",
        group_label=0,
        num_trials=8,
        c_eff=30,
        length=2500,
        seed=42,
        source_segments="[]",
        trial_segment_ids="[]",
        trial_emotion_labels="[]",
    )
    defaults.update(overrides)
    return build_subject_state_manifest_row(**defaults)


def _emotion_row(**overrides):
    """Build a minimal emotion manifest row."""
    defaults = dict(
        sample_id="ne_sub001_neu_0_0000",
        sample_path="/tmp/sample.pt",
        subject_id="sub001",
        group_label=0,
        emotion_label=0,
        segment_id="neu_0",
        center_seconds=25.0,
        start_sample=5000,
        end_sample=7500,
        c_eff=30,
        length=2500,
        seed=42,
    )
    defaults.update(overrides)
    return build_emotion_manifest_row(**defaults)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestManifestColumnsSubjectState:
    """Tests for subject_state manifest columns."""

    def test_manifest_columns_subject_state(self):
        """Verify subject_state manifest has all required columns."""
        row = _subject_state_row()
        for col in SUBJECT_STATE_COLUMNS:
            assert col in row, f"Missing column: {col}"

    def test_subject_state_manifest_to_csv_roundtrip(self, tmp_dir):
        """Test that subject_state manifest can be written and read as CSV."""
        rows = [_subject_state_row(sample_id=f"ss_sub{i:03d}_0000")
                for i in range(3)]
        csv_path = os.path.join(tmp_dir, "manifest.csv")

        df = pd.DataFrame(rows)
        df.to_csv(csv_path, index=False)
        loaded = pd.read_csv(csv_path)

        for col in SUBJECT_STATE_COLUMNS:
            assert col in loaded.columns

    def test_subject_state_manifest_row_count(self, tmp_dir):
        """Test manifest has correct number of rows."""
        n = 5
        rows = [_subject_state_row(sample_id=f"ss_sub{i:03d}_0000")
                for i in range(n)]
        csv_path = os.path.join(tmp_dir, "manifest.csv")

        pd.DataFrame(rows).to_csv(csv_path, index=False)
        loaded = pd.read_csv(csv_path)

        assert len(loaded) == n


class TestManifestColumnsEmotion:
    """Tests for emotion manifest columns."""

    def test_manifest_columns_emotion(self):
        """Verify emotion manifest has all required columns."""
        row = _emotion_row()
        for col in EMOTION_COLUMNS:
            assert col in row, f"Missing column: {col}"

    def test_emotion_manifest_to_csv_roundtrip(self, tmp_dir):
        """Test that emotion manifest can be written and read as CSV."""
        rows = [_emotion_row(sample_id=f"ne_sub{i:03d}_0000")
                for i in range(3)]
        csv_path = os.path.join(tmp_dir, "manifest.csv")

        df = pd.DataFrame(rows)
        df.to_csv(csv_path, index=False)
        loaded = pd.read_csv(csv_path)

        for col in EMOTION_COLUMNS:
            assert col in loaded.columns


class TestEmotionManifestFieldNames:
    """Tests ensuring correct field names and absence of forbidden names."""

    def test_emotion_manifest_uses_correct_field_names(self):
        """Ensure emotion manifest uses center_seconds, NOT source_start_sample."""
        for col in EMOTION_COLUMNS:
            assert "source_start" not in col, f"Forbidden pattern in column: {col}"
            assert "source_end" not in col, f"Forbidden pattern in column: {col}"

    def test_emotion_manifest_has_center_seconds_not_source(self):
        """Explicitly check for center_seconds field."""
        row = _emotion_row()
        assert "center_seconds" in row
        assert "source_start_sample" not in row
        assert "source_end_sample" not in row
