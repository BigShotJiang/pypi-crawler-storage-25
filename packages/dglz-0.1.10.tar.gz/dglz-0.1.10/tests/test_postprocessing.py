"""Test 4:4 constraint postprocessing."""

import pytest
import torch

from eemoclas.prediction.postprocessing import apply_4_4_constraint


class TestApply44Constraint:
    """Tests for the 4:4 constraint postprocessing."""

    def test_4_4_postprocessing_exact_four_positive(self):
        """Test that exactly 4 trials are labeled positive."""
        pos_probs = torch.tensor([0.9, 0.8, 0.7, 0.6, 0.3, 0.2, 0.1, 0.05])
        labels = apply_4_4_constraint(pos_probs)

        assert labels.sum().item() == 4
        assert labels[0] == 1  # highest prob
        assert labels[7] == 0  # lowest prob

    def test_4_4_postprocessing_top_4_highest(self):
        """Test that the 4 highest probability trials get label 1."""
        pos_probs = torch.tensor([0.1, 0.9, 0.2, 0.8, 0.3, 0.7, 0.4, 0.6])
        labels = apply_4_4_constraint(pos_probs)

        # Top 4 probs: indices 1 (0.9), 3 (0.8), 5 (0.7), 7 (0.6)
        assert labels.sum().item() == 4
        assert labels[1] == 1
        assert labels[3] == 1
        assert labels[5] == 1
        assert labels[7] == 1

    def test_4_4_postprocessing_all_same_prob(self):
        """Test with uniform probabilities still gives 4 positive."""
        pos_probs = torch.tensor([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5])
        labels = apply_4_4_constraint(pos_probs)

        assert labels.sum().item() == 4

    def test_4_4_postprocessing_extreme_probs(self):
        """Test with very small probability differences."""
        pos_probs = torch.tensor([0.51, 0.52, 0.53, 0.54, 0.45, 0.46, 0.47, 0.48])
        labels = apply_4_4_constraint(pos_probs)

        assert labels.sum().item() == 4
        # Top 4: indices 3 (0.54), 2 (0.53), 1 (0.52), 0 (0.51)
        assert labels[3] == 1
        assert labels[2] == 1
        assert labels[1] == 1
        assert labels[0] == 1

    def test_4_4_postprocessing_output_dtype(self):
        """Test that output is long tensor."""
        pos_probs = torch.tensor([0.9, 0.8, 0.7, 0.6, 0.3, 0.2, 0.1, 0.05])
        labels = apply_4_4_constraint(pos_probs)

        assert labels.dtype == torch.long

    def test_4_4_postprocessing_output_values(self):
        """Test that output only contains 0 and 1."""
        pos_probs = torch.tensor([0.9, 0.8, 0.7, 0.6, 0.3, 0.2, 0.1, 0.05])
        labels = apply_4_4_constraint(pos_probs)

        unique_vals = set(labels.tolist())
        assert unique_vals.issubset({0, 1})

    def test_4_4_postprocessing_wrong_length_raises(self):
        """Test that non-8 length raises ValueError."""
        pos_probs = torch.tensor([0.9, 0.8, 0.7])
        with pytest.raises(ValueError, match="8"):
            apply_4_4_constraint(pos_probs)

    def test_4_4_postprocessing_too_many_raises(self):
        """Test that 10 elements raises ValueError."""
        pos_probs = torch.ones(10) * 0.5
        with pytest.raises(ValueError, match="8"):
            apply_4_4_constraint(pos_probs)

    def test_4_4_postprocessing_all_ones(self):
        """Test with all probabilities being 1."""
        pos_probs = torch.ones(8)
        labels = apply_4_4_constraint(pos_probs)

        assert labels.sum().item() == 4

    def test_4_4_postprocessing_all_zeros(self):
        """Test with all probabilities being 0."""
        pos_probs = torch.zeros(8)
        labels = apply_4_4_constraint(pos_probs)

        assert labels.sum().item() == 4
