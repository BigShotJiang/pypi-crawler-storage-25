"""Test resampler output.

NOTE: The full resampler classes (SubjectStateResampler, NormalEmotionResampler,
DepressionEmotionResampler) import eemoclas.data.preprocessing which may not
exist yet.  Tests here focus on what can be tested without that module:
manifest row builders and subject-filtering logic.
"""

import json
import os
import tempfile

import numpy as np
import pandas as pd
import pytest
import torch
from scipy.io import savemat

from eemoclas.resampling.manifest import (
    build_subject_state_manifest_row,
    build_emotion_manifest_row,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_dir():
    """Provide a temporary directory."""
    with tempfile.TemporaryDirectory() as d:
        yield d


@pytest.fixture
def synthetic_subjects_csv(tmp_dir):
    """Create a synthetic subjects CSV with normal and depression groups."""
    csv_path = os.path.join(tmp_dir, "subjects.csv")

    subjects = []
    for sid in ["sub_001", "sub_002", "sub_003", "sub_004"]:
        mat_path = os.path.join(tmp_dir, f"{sid}.mat")
        neu = np.random.randn(30, 50000)
        pos = np.random.randn(30, 50000)
        savemat(mat_path, {"EEG_data_neu": neu, "EEG_data_pos": pos})

        group = 0 if sid in ["sub_001", "sub_002"] else 1
        subjects.append({
            "subject_id": sid,
            "group_label": group,
            "mat_path": mat_path,
        })

    df = pd.DataFrame(subjects)
    df.to_csv(csv_path, index=False)
    return csv_path


# ---------------------------------------------------------------------------
# Subject filtering logic -- tested inline to avoid importing the resampler
# classes that depend on the (not-yet-existing) preprocessing module.
# ---------------------------------------------------------------------------

def _filter_by_group(csv_path: str, group_label: int) -> list[dict]:
    """Load subjects from CSV and filter by group_label (mirrors resampler logic)."""
    path = os.path.join("", csv_path) if os.path.isabs(csv_path) else csv_path
    from pathlib import Path

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Subjects CSV not found: {csv_path}")

    df = pd.read_csv(csv_path)
    required = {"subject_id", "group_label", "mat_path"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Subjects CSV missing required columns: {missing}")

    df = df[df["group_label"] == group_label]
    return df.to_dict(orient="records")


class TestNormalEmotionResamplerFilter:
    """Test that only group_label=0 subjects are used."""

    def test_normal_emotion_resampler_filter_group0(self, synthetic_subjects_csv):
        """Test that only group_label=0 subjects are used."""
        subjects = _filter_by_group(synthetic_subjects_csv, group_label=0)

        assert all(s["group_label"] == 0 for s in subjects)
        assert len(subjects) == 2  # sub_001 and sub_002

    def test_normal_emotion_resampler_no_depression(self, synthetic_subjects_csv):
        """Verify no depression subjects are included."""
        subjects = _filter_by_group(synthetic_subjects_csv, group_label=0)

        subject_ids = [s["subject_id"] for s in subjects]
        assert "sub_003" not in subject_ids
        assert "sub_004" not in subject_ids


class TestDepressionEmotionResamplerFilter:
    """Test that only group_label=1 subjects are used."""

    def test_depression_emotion_resampler_filter_group1(self, synthetic_subjects_csv):
        """Test that only group_label=1 subjects are used."""
        subjects = _filter_by_group(synthetic_subjects_csv, group_label=1)

        assert all(s["group_label"] == 1 for s in subjects)
        assert len(subjects) == 2  # sub_003 and sub_004

    def test_depression_emotion_resampler_no_normal(self, synthetic_subjects_csv):
        """Verify no normal subjects are included."""
        subjects = _filter_by_group(synthetic_subjects_csv, group_label=1)

        subject_ids = [s["subject_id"] for s in subjects]
        assert "sub_001" not in subject_ids
        assert "sub_002" not in subject_ids


# ---------------------------------------------------------------------------
# Tests for manifest rows
# ---------------------------------------------------------------------------

class TestSubjectStateManifest:
    """Tests for subject_state manifest row building."""

    def test_subject_state_manifest_contains_trial_segment_ids(self):
        """Test manifest has trial_segment_ids column."""
        row = build_subject_state_manifest_row(
            sample_id="ss_sub001_0000",
            sample_path="/tmp/sample.pt",
            subject_id="sub001",
            group_label=0,
            num_trials=8,
            c_eff=30,
            length=2500,
            seed=42,
            source_segments=json.dumps(["neu_0", "neu_1", "neu_2", "neu_3",
                                         "pos_0", "pos_1", "pos_2", "pos_3"]),
            trial_segment_ids=json.dumps(["neu_0", "pos_0", "neu_1", "pos_1",
                                           "neu_2", "pos_2", "neu_3", "pos_3"]),
            trial_emotion_labels=json.dumps([0, 1, 0, 1, 0, 1, 0, 1]),
        )

        assert "trial_segment_ids" in row
        assert "trial_emotion_labels" in row
        assert "source_segments" in row

    def test_subject_state_manifest_contains_trial_emotion_labels(self):
        """Test manifest has trial_emotion_labels column."""
        row = build_subject_state_manifest_row(
            sample_id="ss_sub001_0000",
            sample_path="/tmp/sample.pt",
            subject_id="sub001",
            group_label=0,
            num_trials=8,
            c_eff=30,
            length=2500,
            seed=42,
            source_segments="[]",
            trial_segment_ids="[]",
            trial_emotion_labels=json.dumps([0, 0, 0, 0, 1, 1, 1, 1]),
        )

        labels = json.loads(row["trial_emotion_labels"])
        assert labels.count(0) == 4
        assert labels.count(1) == 4


class TestEmotionManifest:
    """Tests for emotion manifest row building."""

    def test_emotion_manifest_has_center_seconds(self):
        """Test manifest uses center_seconds field name."""
        row = build_emotion_manifest_row(
            sample_id="ne_sub001_neu_0_0000",
            sample_path="/tmp/sample.pt",
            subject_id="sub001",
            group_label=0,
            emotion_label=0,
            segment_id="neu_0",
            center_seconds=25.0,
            start_sample=5000,
            end_sample=7500,
            c_eff=30,
            length=2500,
            seed=42,
        )

        assert "center_seconds" in row
        assert "start_sample" in row
        assert "end_sample" in row

    def test_emotion_manifest_no_source_start(self):
        """Test that manifest does NOT use source_start_sample."""
        row = build_emotion_manifest_row(
            sample_id="ne_sub001_neu_0_0000",
            sample_path="/tmp/sample.pt",
            subject_id="sub001",
            group_label=0,
            emotion_label=0,
            segment_id="neu_0",
            center_seconds=25.0,
            start_sample=5000,
            end_sample=7500,
            c_eff=30,
            length=2500,
            seed=42,
        )

        assert "source_start_sample" not in row
        assert "source_end_sample" not in row
