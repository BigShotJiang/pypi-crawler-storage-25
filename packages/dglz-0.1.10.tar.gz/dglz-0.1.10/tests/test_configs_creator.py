# tests/test_configs_creator.py
"""Tests for configs_creator.py."""
import json
import os
import tempfile
from pathlib import Path

import pytest
import yaml


# ---------------------------------------------------------------------------
# Helper to create a minimal base config for testing
# ---------------------------------------------------------------------------

def _write_base_config(tmp_path: Path) -> Path:
    """Create a minimal train_full.yaml base config."""
    base = {
        "experiment": {"name": "default", "description": "", "seed": 42},
        "dataset": {"manifest": "manifest.csv", "data_dir": "data/"},
        "models": {
            "subject_state": {
                "task": {"name": "subject_state", "num_classes": 2, "label_names": ["normal", "depression"]},
                "model": {"class_name": "EEGChannelTransformer", "input_num_trials": 8, "input_length": 250},
                "training": {"epochs": 50, "batch_size": 32, "learning_rate": 0.0001, "weight_decay": 0.01, "optimizer": "adam"},
                "augmentation": {"enabled": False},
                "splitting": {"method": "holdout", "train_ratio": 0.8, "val_ratio": 0.2, "seed": 42},
                "seeding": {"random_seed": 42, "split_seed": 42},
            },
            "normal_emotion": {
                "task": {"name": "normal_emotion", "num_classes": 2},
                "model": {"class_name": "EEGChannelTransformer"},
                "training": {"epochs": 50, "learning_rate": 0.0001},
                "augmentation": {"enabled": False},
                "splitting": {"method": "holdout"},
                "seeding": {"random_seed": 42},
            },
            "depression_emotion": {
                "task": {"name": "depression_emotion", "num_classes": 2},
                "model": {"class_name": "EEGChannelTransformer"},
                "training": {"epochs": 50, "learning_rate": 0.0001},
                "augmentation": {"enabled": False},
                "splitting": {"method": "holdout"},
                "seeding": {"random_seed": 42},
            },
        },
    }
    tmp_path.mkdir(parents=True, exist_ok=True)
    base_path = tmp_path / "train_full.yaml"
    base_path.write_text(yaml.dump(base, allow_unicode=True, default_flow_style=False, sort_keys=False))
    return base_path


def _write_tsv(tmp_path: Path, rows: list[str]) -> Path:
    """Write a TSV file with header + rows."""
    tsv_path = tmp_path / "experiments.tsv"
    header = "exp_name\ttask_conf\tmodel_conf\ttrain_conf\tsplit_conf\taug_conf"
    tsv_path.write_text(header + "\n" + "\n".join(rows) + "\n")
    return tsv_path


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestDeepMerge:
    def test_scalar_override(self):
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("cc", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)
        base = {"a": 1, "b": 2}
        result = mod.deep_merge(base, {"a": 10})
        assert result["a"] == 10
        assert result["b"] == 2

    def test_nested_merge(self):
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("cc", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)
        base = {"training": {"lr": 0.001, "wd": 0.01}}
        result = mod.deep_merge(base, {"training": {"lr": 0.0003}})
        assert result["training"]["lr"] == 0.0003
        assert result["training"]["wd"] == 0.01

    def test_list_replacement(self):
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("cc", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)
        base = {"layers": [1, 2, 3]}
        result = mod.deep_merge(base, {"layers": [4, 5]})
        assert result["layers"] == [4, 5]

    def test_no_mutation(self):
        from importlib.util import spec_from_file_location, module_from_spec
        spec = spec_from_file_location("cc", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py")
        mod = module_from_spec(spec)
        spec.loader.exec_module(mod)
        base = {"x": {"y": 1}}
        original = json.loads(json.dumps(base))
        mod.deep_merge(base, {"x": {"y": 2}})
        assert base == original


class TestConfigsCreator:
    def test_basic_holdout_config(self, tmp_path):
        """Generate a single holdout config and verify experiment.name is set."""
        base_path = _write_base_config(tmp_path / "base")
        tsv_path = _write_tsv(tmp_path, [
            'b1-subj-lr3e4\t{}\t{}\t{"learning_rate":0.0003}\t{}\t{}',
        ])
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        import subprocess
        result = subprocess.run(
            ["python", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py",
             "--base", str(base_path), "--input", str(tsv_path),
             "--name", "batch1", "--stage", "stage1", "--output", str(output_dir)],
            capture_output=True, text=True, cwd="/home/ubuntu/GitHub/DGLZ",
        )
        assert result.returncode == 0, f"Failed: {result.stderr}"
        output = json.loads(result.stdout)
        assert output["successful"] == 1
        assert output["failed"] == 0

        # Verify config file exists
        config_file = output_dir / "b1-subj-lr3e4.yaml"
        assert config_file.exists()
        config = yaml.safe_load(config_file.read_text())
        assert config["experiment"]["name"] == "b1-subj-lr3e4"
        assert config["models"]["subject_state"]["training"]["learning_rate"] == 0.0003
        # Base values should be preserved
        assert config["models"]["subject_state"]["training"]["epochs"] == 50

    def test_kfold_config(self, tmp_path):
        """Generate a k-fold config with StratifiedGroupKFold."""
        base_path = _write_base_config(tmp_path / "base")
        tsv_path = _write_tsv(tmp_path, [
            'b1-subj-kfold\t{}\t{}\t{"learning_rate":0.0001}\t{"method":"StratifiedGroupKFold","n_splits":3}\t{}',
        ])
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        import subprocess
        result = subprocess.run(
            ["python", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py",
             "--base", str(base_path), "--input", str(tsv_path),
             "--name", "batch1", "--stage", "stage1", "--output", str(output_dir)],
            capture_output=True, text=True, cwd="/home/ubuntu/GitHub/DGLZ",
        )
        assert result.returncode == 0
        config_file = output_dir / "b1-subj-kfold.yaml"
        config = yaml.safe_load(config_file.read_text())
        assert config["models"]["subject_state"]["splitting"]["method"] == "StratifiedGroupKFold"
        assert config["models"]["subject_state"]["splitting"]["n_splits"] == 3

    def test_stage2_dual_config(self, tmp_path):
        """Stage 2 generates two configs (normal + depression)."""
        base_path = _write_base_config(tmp_path / "base")
        tsv_path = _write_tsv(tmp_path, [
            'b2-emo-lr3e4\t{}\t{}\t{"learning_rate":0.0003}\t{}\t{}',
        ])
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        import subprocess
        result = subprocess.run(
            ["python", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py",
             "--base", str(base_path), "--input", str(tsv_path),
             "--name", "batch2", "--stage", "stage2", "--output", str(output_dir)],
            capture_output=True, text=True, cwd="/home/ubuntu/GitHub/DGLZ",
        )
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["successful"] == 2  # Two configs generated

        # Verify both configs exist
        assert (output_dir / "b2-emo-lr3e4-normal.yaml").exists()
        assert (output_dir / "b2-emo-lr3e4-depression.yaml").exists()

    def test_batch_txt_output(self, tmp_path):
        """Verify batch TXT file is generated with config paths."""
        base_path = _write_base_config(tmp_path / "base")
        tsv_path = _write_tsv(tmp_path, [
            'b1-subj-a\t{}\t{}\t{"learning_rate":0.0003}\t{}\t{}',
            'b1-subj-b\t{}\t{}\t{"learning_rate":0.0001}\t{}\t{}',
        ])
        output_dir = tmp_path / "output"
        output_dir.mkdir()
        agent_dir = tmp_path / "agent" / "dglztr" / "exp_conf_tsv"
        agent_dir.mkdir(parents=True)

        import subprocess
        result = subprocess.run(
            ["python", "src/eemoclas/claude_templates/skills/configs-creator/scripts/configs_creator.py",
             "--base", str(base_path), "--input", str(tsv_path),
             "--name", "batch1", "--stage", "stage1",
             "--output", str(output_dir),
             "--agent-dir", str(tmp_path / "agent")],
            capture_output=True, text=True, cwd="/home/ubuntu/GitHub/DGLZ",
        )
        assert result.returncode == 0
        batch_file = agent_dir / "batch1.txt"
        assert batch_file.exists()
        lines = batch_file.read_text().strip().split("\n")
        assert len(lines) == 2
        assert "b1-subj-a.yaml" in lines[0]
        assert "b1-subj-b.yaml" in lines[1]
