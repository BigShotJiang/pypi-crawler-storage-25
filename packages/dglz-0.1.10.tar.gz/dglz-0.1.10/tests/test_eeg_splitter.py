"""Test train/test EEG splitting."""

import numpy as np
import pytest

from eemoclas.data.eeg_splitter import (
    split_train_emotion,
    split_test_trials,
    TRAIN_SEGMENTS,
    TRAIN_SEGMENT_LENGTH,
    TEST_TRIALS,
    TEST_TRIAL_LENGTH,
    CHANNEL_COUNT,
)


class TestSplitTrainEmotion:
    """Tests for split_train_emotion."""

    def test_split_train_50000_to_four_12500(self):
        """Test that a [30, 50000] array is split into 4 segments of [30, 12500]."""
        eeg = np.random.randn(30, 50000)
        segments = split_train_emotion(eeg)

        assert len(segments) == TRAIN_SEGMENTS
        assert all(s.shape == (30, TRAIN_SEGMENT_LENGTH) for s in segments)

    def test_split_train_segments_are_contiguous(self):
        """Verify that segments cover the full recording without overlap or gaps."""
        eeg = np.random.randn(30, 50000)
        segments = split_train_emotion(eeg)

        # Reconstruct by concatenation
        reconstructed = np.concatenate(segments, axis=1)
        np.testing.assert_array_equal(reconstructed, eeg)

    def test_split_train_wrong_time_length(self):
        """Test that wrong time dimension raises ValueError."""
        eeg = np.random.randn(30, 40000)
        with pytest.raises(ValueError, match="50000"):
            split_train_emotion(eeg)

    def test_split_train_wrong_channels(self):
        """Test that wrong channel count raises ValueError."""
        eeg = np.random.randn(20, 50000)
        with pytest.raises(ValueError, match="30"):
            split_train_emotion(eeg)

    def test_split_train_not_2d(self):
        """Test that a non-2D array raises ValueError."""
        eeg = np.random.randn(30, 50000, 1)
        with pytest.raises(ValueError, match="2-D"):
            split_train_emotion(eeg)

    def test_split_train_segments_are_copies(self):
        """Verify that returned segments are copies, not views."""
        eeg = np.random.randn(30, 50000)
        segments = split_train_emotion(eeg)

        for seg in segments:
            assert not np.shares_memory(seg, eeg)


class TestSplitTestTrials:
    """Tests for split_test_trials."""

    def test_split_test_20000_to_eight_2500(self):
        """Test that a [30, 20000] array is split into 8 trials of [30, 2500]."""
        eeg = np.random.randn(30, 20000)
        trials = split_test_trials(eeg)

        assert len(trials) == TEST_TRIALS
        assert all(t.shape == (30, TEST_TRIAL_LENGTH) for t in trials)

    def test_split_test_trials_are_contiguous(self):
        """Verify that trials cover the full recording without overlap or gaps."""
        eeg = np.random.randn(30, 20000)
        trials = split_test_trials(eeg)

        reconstructed = np.concatenate(trials, axis=1)
        np.testing.assert_array_equal(reconstructed, eeg)

    def test_split_test_wrong_time_length(self):
        """Test that wrong time dimension raises ValueError."""
        eeg = np.random.randn(30, 15000)
        with pytest.raises(ValueError, match="20000"):
            split_test_trials(eeg)

    def test_split_test_wrong_channels(self):
        """Test that wrong channel count raises ValueError."""
        eeg = np.random.randn(15, 20000)
        with pytest.raises(ValueError, match="30"):
            split_test_trials(eeg)

    def test_split_test_trials_are_copies(self):
        """Verify that returned trials are copies, not views."""
        eeg = np.random.randn(30, 20000)
        trials = split_test_trials(eeg)

        for trial in trials:
            assert not np.shares_memory(trial, eeg)
