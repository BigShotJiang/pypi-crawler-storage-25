"""Test bandpass filtering and token_meta generation."""

import numpy as np
import pytest

from eemoclas.data.band_filter import apply_channel_band_filter


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_config(bands, default_bands, per_channel=None):
    """Build a minimal config dict for apply_channel_band_filter."""
    return {
        "band_definitions": bands,
        "channel_band_config": {
            "default_bands": default_bands,
            "per_channel": per_channel or {},
        },
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestChannelBandOutputShape:
    """Tests for output shape of apply_channel_band_filter."""

    def test_channel_band_output_shape(self):
        """Test that output shape is [C_eff, T]."""
        eeg = np.random.randn(3, 2500)
        bands = {"alpha": [8, 13], "beta": [13, 30]}
        cfg = _make_config(bands, ["alpha", "beta"])

        filtered, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2", "FZ"],
            selected_indices=[0, 1, 4],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        # C_eff = 3 channels * 2 bands = 6
        assert filtered.shape == (6, 2500)

    def test_channel_band_output_broadband(self):
        """Test with a single broadband per channel."""
        eeg = np.random.randn(5, 2500)
        bands = {"broadband": [1, 45]}
        cfg = _make_config(bands, ["broadband"])

        filtered, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2", "FZ", "C3", "CZ"],
            selected_indices=[0, 1, 4, 13, 14],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        # 5 channels * 1 band = 5
        assert filtered.shape == (5, 2500)


class TestTokenMeta:
    """Tests for token_meta generation."""

    def test_token_meta_length_equals_c_eff(self):
        """Test token_meta length matches C_eff."""
        eeg = np.random.randn(3, 2500)
        bands = {"alpha": [8, 13], "beta": [13, 30]}
        cfg = _make_config(bands, ["alpha", "beta"])

        filtered, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2", "FZ"],
            selected_indices=[0, 1, 4],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        assert len(token_meta) == filtered.shape[0]

    def test_token_meta_order_matches_x(self):
        """Test token_meta order matches virtual channel order in x."""
        eeg = np.random.randn(2, 2500)
        bands = {"alpha": [8, 13], "beta": [13, 30]}
        cfg = _make_config(bands, ["alpha", "beta"])

        filtered, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2"],
            selected_indices=[0, 1],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        # Order: FP1-alpha, FP1-beta, FP2-alpha, FP2-beta
        assert token_meta[0]["source_channel"] == "FP1"
        assert token_meta[0]["band_name"] == "alpha"
        assert token_meta[1]["source_channel"] == "FP1"
        assert token_meta[1]["band_name"] == "beta"
        assert token_meta[2]["source_channel"] == "FP2"
        assert token_meta[2]["band_name"] == "alpha"
        assert token_meta[3]["source_channel"] == "FP2"
        assert token_meta[3]["band_name"] == "beta"

    def test_token_meta_has_required_fields(self):
        """Test each token_meta entry has all required fields."""
        eeg = np.random.randn(2, 2500)
        bands = {"alpha": [8, 13]}
        cfg = _make_config(bands, ["alpha"])

        _, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2"],
            selected_indices=[0, 1],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        required_keys = {"source_channel", "source_channel_index", "band_name", "low", "high"}
        for meta in token_meta:
            assert required_keys.issubset(set(meta.keys()))

    def test_token_meta_frequency_values(self):
        """Test that frequency values in token_meta match band_definitions."""
        eeg = np.random.randn(1, 2500)
        bands = {"alpha": [8, 13], "gamma": [30, 45]}
        cfg = _make_config(bands, ["alpha", "gamma"])

        _, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1"],
            selected_indices=[0],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        assert token_meta[0]["low"] == 8.0
        assert token_meta[0]["high"] == 13.0
        assert token_meta[1]["low"] == 30.0
        assert token_meta[1]["high"] == 45.0

    def test_token_meta_per_channel_override(self):
        """Test per_channel band overrides."""
        eeg = np.random.randn(2, 2500)
        bands = {"alpha": [8, 13], "beta": [13, 30], "gamma": [30, 45]}
        cfg = _make_config(
            bands,
            default_bands=["alpha", "beta"],
            per_channel={"FP2": ["gamma"]},
        )

        filtered, token_meta = apply_channel_band_filter(
            eeg=eeg,
            selected_channel_names=["FP1", "FP2"],
            selected_indices=[0, 1],
            band_definitions=cfg["band_definitions"],
            channel_band_config=cfg["channel_band_config"],
            fs=250,
        )

        # FP1 gets alpha+beta (2), FP2 gets gamma (1) => C_eff=3
        assert filtered.shape[0] == 3
        assert token_meta[0]["band_name"] == "alpha"
        assert token_meta[1]["band_name"] == "beta"
        assert token_meta[2]["band_name"] == "gamma"


class TestBandFilterValidation:
    """Tests for input validation."""

    def test_band_filter_invalid_band_raises(self):
        """Test that invalid band (low >= high) raises ValueError."""
        eeg = np.random.randn(1, 2500)
        bands = {"bad_band": [30, 10]}  # low > high
        cfg = _make_config(bands, ["bad_band"])

        with pytest.raises(ValueError, match="Invalid band"):
            apply_channel_band_filter(
                eeg=eeg,
                selected_channel_names=["FP1"],
                selected_indices=[0],
                band_definitions=cfg["band_definitions"],
                channel_band_config=cfg["channel_band_config"],
                fs=250,
            )

    def test_band_filter_undefined_band_raises(self):
        """Test that referencing an undefined band raises ValueError."""
        eeg = np.random.randn(1, 2500)
        bands = {"alpha": [8, 13]}
        cfg = _make_config(bands, ["nonexistent_band"])

        with pytest.raises(ValueError, match="not defined"):
            apply_channel_band_filter(
                eeg=eeg,
                selected_channel_names=["FP1"],
                selected_indices=[0],
                band_definitions=cfg["band_definitions"],
                channel_band_config=cfg["channel_band_config"],
                fs=250,
            )

    def test_band_filter_mismatched_names_length(self):
        """Test that mismatched channel names length raises ValueError."""
        eeg = np.random.randn(3, 2500)
        bands = {"alpha": [8, 13]}
        cfg = _make_config(bands, ["alpha"])

        with pytest.raises(ValueError, match="selected_channel_names"):
            apply_channel_band_filter(
                eeg=eeg,
                selected_channel_names=["FP1"],  # 1 name but 3 channels in eeg
                selected_indices=[0],
                band_definitions=cfg["band_definitions"],
                channel_band_config=cfg["channel_band_config"],
                fs=250,
            )
