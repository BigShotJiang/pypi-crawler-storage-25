"""Test that training stage never reads raw .mat files."""

import ast
import os


class TestTrainStageNoRawMat:
    """Tests to ensure training code does NOT import eeg_io or load .mat files."""

    def test_train_stage_never_reads_raw_mat(self):
        """
        Verify that train_cmd.py does NOT import eeg_io or load .mat files.
        Training should only read manifest.csv and .pt files.
        """
        train_cmd_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "src", "eemoclas", "cli", "train_cmd.py",
        )

        if not os.path.exists(train_cmd_path):
            pytest.skip("train_cmd.py not found")

        with open(train_cmd_path, "r") as f:
            source = f.read()

        # Parse the source to check imports
        tree = ast.parse(source)

        forbidden_imports = [
            "eeg_io",
            "load_train_mat",
            "load_test_mat",
            "loadmat",
            "savemat",
        ]

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    for forbidden in forbidden_imports:
                        assert forbidden not in alias.name, (
                            f"Forbidden import '{forbidden}' found in train_cmd.py"
                        )
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    for forbidden in forbidden_imports:
                        assert forbidden not in node.module, (
                            f"Forbidden import '{forbidden}' found in train_cmd.py "
                            f"(from {node.module})"
                        )

        # Also check that .mat is never referenced as a string literal
        assert ".mat" not in source, (
            "Reference to '.mat' files found in train_cmd.py -- "
            "training should only read .pt files via manifest.csv"
        )

    def test_train_impl_no_mat_imports(self):
        """Check that train_impl.py (if it exists) does not import eeg_io."""
        train_impl_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "src", "eemoclas", "cli", "train_impl.py",
        )

        if not os.path.exists(train_impl_path):
            pytest.skip("train_impl.py not found")

        with open(train_impl_path, "r") as f:
            source = f.read()

        forbidden_imports = [
            "eeg_io",
            "load_train_mat",
            "load_test_mat",
            "loadmat",
            "savemat",
        ]

        tree = ast.parse(source)

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    for forbidden in forbidden_imports:
                        assert forbidden not in alias.name, (
                            f"Forbidden import '{forbidden}' found in train_impl.py"
                        )
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    for forbidden in forbidden_imports:
                        assert forbidden not in node.module, (
                            f"Forbidden import '{forbidden}' found in train_impl.py"
                        )
