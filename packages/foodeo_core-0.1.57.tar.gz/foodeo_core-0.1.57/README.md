# foodeo-core
Proyecto de librería de clase de dominio de foodeo


### 1- Correr tests:

```bash
python3 -m unittest
```

### 2- Enlazarlo al entorno de `foodeo-backend`

Para desarrollo local no tiene sentido publicar una versión a PyPI por cada cambio.
Dejá `foodeo-core` instalado en modo editable dentro del virtualenv de `foodeo-backend`:

```bash
./scripts/link_backend_env.sh
```

Si el virtualenv de `foodeo-backend` está en otra ruta:

```bash
./scripts/link_backend_env.sh /ruta/al/venv
```

Eso ejecuta `pip install -e` sobre este repo dentro del otro entorno. A partir de ahí,
cada cambio que hagas en `foodeo-core` queda disponible en `foodeo-backend` sin volver
a subir el paquete a PyPI. Solo necesitás correrlo de nuevo si recreás el virtualenv.
