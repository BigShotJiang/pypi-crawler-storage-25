"""Tests for json-memory."""

import json
import pytest
from json_memory import Memory, Synapse, Schema, WeightGate, compress, decompress, savings_report


# ── Memory Tests ──────────────────────────────────────────────────

class TestMemory:
    def test_create_empty(self):
        mem = Memory(max_chars=500)
        assert mem.export() == "{}"
        assert mem.stats()["entries"] == 0

    def test_set_and_get(self):
        mem = Memory()
        mem.set("u.name", "Alice")
        mem.set("u.tz", "UTC")
        assert mem.get("u.name") == "Alice"
        assert mem.get("u.tz") == "UTC"

    def test_nested_set(self):
        mem = Memory()
        mem.set("bot.binance.rst", "kill && nohup ./bot > log")
        mem.set("bot.binance.wl", "BNB,KITE")
        assert mem.get("bot.binance.rst") == "kill && nohup ./bot > log"
        assert mem.get("bot.binance.wl") == "BNB,KITE"

    def test_deep_nesting(self):
        mem = Memory()
        mem.set("a.b.c.d.e", "deep")
        assert mem.get("a.b.c.d.e") == "deep"

    def test_get_default(self):
        mem = Memory()
        assert mem.get("missing.path", "default") == "default"
        assert mem.get("missing.path") is None

    def test_delete(self):
        mem = Memory()
        mem.set("x.y", "val")
        assert mem.has("x.y")
        mem.delete("x.y")
        assert not mem.has("x.y")

    def test_has(self):
        mem = Memory()
        mem.set("x", 1)
        assert mem.has("x")
        assert not mem.has("y")

    def test_keys(self):
        mem = Memory()
        mem.set("a.x", 1)
        mem.set("a.y", 2)
        mem.set("b.z", 3)
        assert sorted(mem.keys("a")) == ["x", "y"]

    def test_paths(self):
        mem = Memory()
        mem.set("a.b", 1)
        mem.set("a.c", 2)
        mem.set("d", 3)
        assert sorted(mem.paths()) == ["a.b", "a.c", "d"]

    def test_export_minified(self):
        mem = Memory()
        mem.set("u.name", "Alice")
        exported = mem.export()
        assert " " not in exported  # minified
        assert json.loads(exported) == {"u": {"name": "Alice"}}

    def test_from_json(self):
        mem = Memory.from_json('{"u":{"name":"Alice"}}')
        assert mem.get("u.name") == "Alice"

    def test_merge(self):
        mem = Memory()
        data = {"u": {"name": "Alice", "tz": "UTC"}, "bot": {"bal": "$12K"}}
        count = mem.merge(data)
        assert count == 3
        assert mem.get("u.name") == "Alice"
        assert mem.get("bot.bal") == "$12K"

    def test_merge_with_prefix(self):
        mem = Memory()
        mem.merge({"name": "Alice"}, prefix="u")
        assert mem.get("u.name") == "Alice"

    def test_max_chars_overflow(self):
        mem = Memory(max_chars=20)
        with pytest.raises(ValueError, match="Memory overflow"):
            mem.set("key", "a" * 50)

    def test_overflow_does_not_corrupt(self):
        """Critical: failed set() must not leave dirty data."""
        mem = Memory(max_chars=50)
        mem.set("x", "hello")
        original = mem.export()

        # Try to set something that exceeds budget
        with pytest.raises(ValueError):
            mem.set("y", "a" * 100)

        # Data must be unchanged after failed set
        assert mem.export() == original
        assert not mem.has("y")

    def test_overflow_new_path_does_not_corrupt(self):
        """Failed set on a new nested path must not create intermediate dicts."""
        mem = Memory(max_chars=50)
        mem.set("x", "hi")
        original = mem.export()

        with pytest.raises(ValueError):
            mem.set("new.nested.path", "a" * 100)

        assert mem.export() == original
        assert not mem.has("new")

    def test_overflow_replacement_does_not_corrupt(self):
        """Failed replacement of existing key must restore old value."""
        mem = Memory(max_chars=50)
        mem.set("x", "hello")

        with pytest.raises(ValueError):
            mem.set("x", "a" * 100)

        assert mem.get("x") == "hello"  # old value restored

    def test_stats(self):
        mem = Memory(max_chars=1000)
        mem.set("x", 1)
        stats = mem.stats()
        assert stats["entries"] == 1
        assert stats["chars_used"] > 0
        assert stats["chars_max"] == 1000

    def test_to_dict(self):
        mem = Memory()
        mem.set("x.y", 1)
        d = mem.to_dict()
        assert d == {"x": {"y": 1}}

    def test_getitem_setitem(self):
        mem = Memory()
        mem["u.name"] = "Alice"
        assert mem["u.name"] == "Alice"

    def test_contains(self):
        mem = Memory()
        mem.set("x", 1)
        assert "x" in mem
        assert "y" not in mem

    def test_len(self):
        mem = Memory()
        mem.set("x", 1)
        assert len(mem) == len(mem.export())

    def test_repr(self):
        mem = Memory()
        mem.set("x", 1)
        r = repr(mem)
        assert "Memory" in r
        assert "leafs=1" in r


# ── Synapse Tests ─────────────────────────────────────────────────

class TestSynapse:
    def test_create(self):
        s = Synapse()
        assert repr(s) == "Synapse(concepts=0, links=0)"

    def test_link(self):
        s = Synapse()
        s.link("trading", ["binance", "strategy"])
        assert "binance" in s.activate("trading")
        assert "strategy" in s.activate("trading")

    def test_bidirectional(self):
        s = Synapse()
        s.link("trading", ["binance"], bidirectional=True)
        assert "trading" in s.activate("binance")

    def test_unidirectional(self):
        s = Synapse()
        s.link("trading", ["binance"], bidirectional=False)
        assert "binance" in s.activate("trading")
        assert "trading" not in s.activate("binance")

    def test_depth_traversal(self):
        s = Synapse()
        s.link("trading", ["binance"])
        s.link("binance", ["api", "demo"])
        result = s.activate("trading", depth=1)
        assert "binance" in result
        assert "api" not in result

        result = s.activate("trading", depth=2)
        assert "api" in result
        assert "demo" in result

    def test_connections(self):
        s = Synapse()
        s.link("hub", ["a", "b", "c", "d", "e"])
        info = s.connections("hub")
        assert info["count"] == 5
        assert info["is_hub"] is True

    def test_find_path(self):
        s = Synapse()
        s.link("a", ["b"])
        s.link("b", ["c"])
        path = s.find_path("a", "c")
        assert path == ["a", "b", "c"]

    def test_find_path_no_connection(self):
        s = Synapse()
        s.link("a", ["b"])
        s.link("c", ["d"])
        assert s.find_path("a", "d") is None

    def test_hubs(self):
        s = Synapse()
        s.link("hub1", ["a", "b", "c", "d"])
        s.link("hub2", ["x", "y", "z"])
        s.link("small", ["a"])
        hubs = s.hubs(min_connections=3)
        assert hubs[0][0] == "hub1"
        assert hubs[0][1] == 4  # 4 children

    def test_export_import(self):
        s = Synapse()
        s.link("a", ["b", "c"])
        exported = s.export()
        s2 = Synapse.from_json(exported)
        assert s2.activate("a") == s.activate("a")

    def test_no_cycles(self):
        s = Synapse()
        s.link("a", ["b"])
        s.link("b", ["c"])
        s.link("c", ["a"])  # cycle
        result = s.activate("a", depth=10)
        assert len(result) == len(set(result))  # no duplicates


class TestSynapseWeights:
    def test_weighted_link(self):
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano", "espresso"],
               weights={"cappuccino": 0.9, "americano": 0.3, "espresso": 0.6})
        assert s.get_weight("coffee", "cappuccino") == 0.9
        assert s.get_weight("coffee", "americano") == 0.3
        assert s.get_weight("coffee", "espresso") == 0.6

    def test_default_weight(self):
        s = Synapse()
        s.link("coffee", ["latte"])  # no weight specified
        assert s.get_weight("coffee", "latte") == 0.5  # default

    def test_activate_sorted_by_weight(self):
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano", "espresso"],
               weights={"cappuccino": 0.9, "americano": 0.3, "espresso": 0.6})
        result = s.activate("coffee", depth=1)
        assert result[0] == "cappuccino"  # highest weight first
        assert result[1] == "espresso"
        assert result[2] == "americano"

    def test_unweighted_activate(self):
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano"],
               weights={"cappuccino": 0.9, "americano": 0.3})
        result = s.activate("coffee", depth=1, weighted=False)
        # Original insertion order
        assert result == ["cappuccino", "americano"]

    def test_strengthen(self):
        s = Synapse()
        s.link("coffee", ["cappuccino"], weights={"cappuccino": 0.5})
        new_w = s.strengthen("coffee", "cappuccino", boost=0.2)
        assert new_w == 0.7
        assert s.get_weight("coffee", "cappuccino") == 0.7

    def test_strengthen_cap(self):
        s = Synapse()
        s.link("coffee", ["cappuccino"], weights={"cappuccino": 0.9})
        new_w = s.strengthen("coffee", "cappuccino", boost=0.5)
        assert new_w == 1.0  # capped at 1.0

    def test_weaken(self):
        s = Synapse()
        s.link("coffee", ["americano"], weights={"americano": 0.5})
        new_w = s.weaken("coffee", "americano", decay=0.2)
        assert new_w == 0.3
        assert s.get_weight("coffee", "americano") == 0.3

    def test_weaken_floor(self):
        s = Synapse()
        s.link("coffee", ["americano"], weights={"americano": 0.1})
        new_w = s.weaken("coffee", "americano", decay=0.5)
        assert new_w == 0.0  # floored at 0.0

    def test_frequency_tracking(self):
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano"])
        s.activate("coffee", depth=1)  # first activation
        s.activate("coffee", depth=1)  # second
        s.activate("coffee", depth=1)  # third
        assert s.get_frequency("coffee", "cappuccino") == 3
        assert s.get_frequency("coffee", "americano") == 3

    def test_top_associations(self):
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano", "espresso", "latte"],
               weights={"cappuccino": 0.9, "americano": 0.3, "espresso": 0.6, "latte": 0.7})
        top = s.top_associations("coffee", limit=2)
        assert top[0] == ("cappuccino", 0.9)
        assert top[1] == ("latte", 0.7)

    def test_learning_simulation(self):
        """Simulate learning: user always picks cappuccino, rarely picks americano."""
        s = Synapse()
        s.link("coffee", ["cappuccino", "americano"],
               weights={"cappuccino": 0.5, "americano": 0.5})

        # User picks cappuccino 10 times → strengthens
        for _ in range(10):
            s.strengthen("coffee", "cappuccino", boost=0.05)

        # User never picks americano → weakens
        for _ in range(10):
            s.weaken("coffee", "americano", decay=0.03)

        # Now cappuccino should be dominant
        assert s.get_weight("coffee", "cappuccino") > s.get_weight("coffee", "americano")
        top = s.top_associations("coffee", limit=1)
        assert top[0][0] == "cappuccino"

    def test_export_import_preserves_weights(self):
        s = Synapse()
        s.link("coffee", ["cappuccino"], weights={"cappuccino": 0.8})
        s.strengthen("coffee", "cappuccino", boost=0.1)

        exported = s.export()
        s2 = Synapse.from_json(exported)
        assert s2.get_weight("coffee", "cappuccino") == s.get_weight("coffee", "cappuccino")

    def test_personalization_scenario(self):
        """Two people with different coffee preferences."""
        # Person A: loves cappuccino
        person_a = Synapse()
        person_a.link("coffee", ["cappuccino", "americano", "espresso"],
                      weights={"cappuccino": 0.95, "americano": 0.2, "espresso": 0.5})

        # Person B: loves americano
        person_b = Synapse()
        person_b.link("coffee", ["cappuccino", "americano", "espresso"],
                      weights={"cappuccino": 0.2, "americano": 0.9, "espresso": 0.4})

        # Same concept, different recall order
        a_first = person_a.activate("coffee", depth=1)[0]
        b_first = person_b.activate("coffee", depth=1)[0]

        assert a_first == "cappuccino"
        assert b_first == "americano"


# ── Schema Tests ──────────────────────────────────────────────────

class TestSchema:
    def test_validate_simple(self):
        schema = Schema({"u": {"n": "str", "tz": "str"}})
        assert schema.validate({"u": {"n": "Alice", "tz": "UTC"}})
        assert not schema.validate({"u": {"n": 123}})

    def test_defaults(self):
        schema = Schema({"u": {"n": "str", "tz": "str"}})
        d = schema.defaults()
        assert d == {"u": {"n": None, "tz": None}}

    def test_diff(self):
        schema = Schema({"u": {"n": "str", "tz": "str", "email": "str"}})
        diff = schema.diff({"u": {"n": "Alice", "extra": 1}})
        assert "u.tz" in diff["missing"]
        assert "u.email" in diff["missing"]
        assert "u.extra" in diff["extra"]

    def test_strict(self):
        schema = Schema({"u": {"n": "str"}})
        assert schema.validate({"u": {"n": "Alice"}}, strict=True)
        assert not schema.validate({"u": {"n": "Alice", "extra": 1}}, strict=True)

    def test_export(self):
        schema = Schema({"x": "str"})
        assert schema.export() == '{"x":"str"}'


# ── Compress Tests ────────────────────────────────────────────────

class TestCompress:
    def test_compress_dict(self):
        data = {"user": {"name": "Alice"}, "server": {"restart": "cmd"}}
        compressed = compress(data)
        assert "u" in compressed
        assert "n" in compressed["u"]
        assert "srv" in compressed
        assert "rst" in compressed["srv"]

    def test_decompress_roundtrip(self):
        original = {"user": {"name": "Alice"}, "watchlist": ["BTC"]}
        compressed = compress(original)
        decompressed = decompress(compressed)
        assert decompressed == original

    def test_savings_report(self):
        report = savings_report("hello world", "hw")
        assert report["original_chars"] == 11
        assert report["compressed_chars"] == 2
        assert report["chars_saved"] == 9
        assert report["savings_pct"] > 80

    def test_prose_to_json(self):
        prose = "name: Alice\ntz: UTC\nplatform: Telegram"
        result = json.loads(json.dumps(
            __import__("json_memory.compress", fromlist=["prose_to_json"]).prose_to_json(prose)
        ))
        assert result["name"] == "Alice"
        assert result["tz"] == "UTC"


# ── WeightGate Tests ─────────────────────────────────────────────

class TestWeightGate:
    def _make_gate(self, tmp_path, enabled=True):
        path = str(tmp_path / "test_synapse.json")
        gate = WeightGate(path, enabled=enabled)
        gate.add_concept("coffee", {"cappuccino": 0.9, "americano": 0.3, "espresso": 0.6})
        gate.add_concept("debug", {"check_logs": 0.9, "ask_user": 0.2})
        return gate

    def test_disabled_by_default(self):
        from json_memory import WeightGate
        gate = WeightGate("/tmp/test_gate.json")
        assert gate.enabled is False

    def test_enable_disable(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=False)
        assert gate.enabled is False
        gate.enable()
        assert gate.enabled is True
        gate.disable()
        assert gate.enabled is False

    def test_toggle(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=False)
        assert gate.toggle() is True
        assert gate.toggle() is False

    def test_disabled_is_noop(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=False)
        result = gate.process_input("I love cappuccino")
        assert result == {}
        result = gate.process_output("making cappuccino")
        assert result == {}

    def test_process_input_strengthen(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        gate.process_input("I love cappuccino coffee")
        weights = gate.get_weights("coffee")
        assert weights["cappuccino"] > 0.9  # strengthened

    def test_process_input_decay(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        # Concept + one association mentioned → competition → unmentioned decay
        gate.process_input("I love coffee cappuccino")
        weights = gate.get_weights("coffee")
        assert weights["cappuccino"] > 0.5  # boosted (mentioned)
        assert weights["americano"] < 0.3   # decayed (competition — lost to cappuccino)

    def test_process_input_no_decay_without_competition(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        # Concept mentioned but no association → no competition → no decay
        gate.process_input("I love coffee so much")
        weights = gate.get_weights("coffee")
        assert weights["americano"] == 0.3  # unchanged — no competition

    def test_process_output_strengthen(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        gate.process_output("Let me check logs for errors")
        weights = gate.get_weights("debug")
        assert weights["check_logs"] > 0.9  # mentioned in output

    def test_process_conversation(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        result = gate.process_conversation(
            "check the logs",
            "Looking at logs now, found the error"
        )
        assert "input" in result
        assert "output" in result
        assert result["total_interactions"] == 1

    def test_disabled_process_conversation(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=False)
        result = gate.process_conversation("test", "response")
        assert result == {}

    def test_context_manager(self, tmp_path):
        path = str(tmp_path / "ctx_synapse.json")
        with WeightGate(path) as gate:
            gate.add_concept("x", {"a": 0.5})
            assert gate.enabled is True
        assert gate.enabled is False

    def test_add_remove_concept(self, tmp_path):
        gate = self._make_gate(tmp_path)
        gate.add_concept("new", {"a": 0.5, "b": 0.3})
        assert gate.get_weights("new") == {"a": 0.5, "b": 0.3}
        assert gate.remove_concept("new") is True
        assert gate.get_weights("new") == {}

    def test_top_associations(self, tmp_path):
        gate = self._make_gate(tmp_path)
        top = gate.top_associations("coffee", limit=2)
        assert top[0][0] == "cappuccino"
        assert top[1][0] == "espresso"

    def test_manual_strengthen_weaken(self, tmp_path):
        gate = self._make_gate(tmp_path)
        new = gate.strengthen("coffee", "americano", boost=0.2)
        assert abs(new - 0.5) < 0.001  # 0.3 + 0.2
        new = gate.weaken("coffee", "cappuccino", decay=0.3)
        assert abs(new - 0.6) < 0.001  # 0.9 - 0.3

    def test_export_compact(self, tmp_path):
        gate = self._make_gate(tmp_path)
        compact = gate.export_compact()
        data = json.loads(compact)
        assert "coffee" in data
        assert "cappuccino" in data["coffee"]

    def test_learning_simulation(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        # User always asks about cappuccino
        for _ in range(50):
            gate.process_input("make me a cappuccino coffee")
        top = gate.top_associations("coffee", limit=1)
        assert top[0][0] == "cappuccino"
        assert top[0][1] > 0.95

    def test_repr(self, tmp_path):
        gate = self._make_gate(tmp_path, enabled=True)
        r = repr(gate)
        assert "[ON]" in r
        gate.disable()
        r = repr(gate)
        assert "[OFF]" in r


# ── New Feature & Bug Fix Tests ───────────────────────────────────

def test_schema_strict_with_required_fields():
    """Test bug fix for strict mode failing with '!' prefix keys."""
    schema = Schema({"!user": {"!name": "str"}})
    # This should now pass in strict mode
    assert schema.validate({"user": {"name": "Alice"}}, strict=True) is True
    # Extra keys should still fail
    assert schema.validate({"user": {"name": "Alice", "age": 30}}, strict=True) is False

def test_memory_clear_edge_cases():
    mem = Memory()
    mem.set("a.b", 1)
    # Clear non-existent path should be a no-op
    mem.clear("x.y.z")
    assert mem.get("a.b") == 1
    # Clear empty string should wipe everything
    mem.clear("")
    assert mem.export() == "{}"

def test_synapse_mutation_safety():
    """Test that to_dict() returns deep copies of nested structures."""
    s = Synapse()
    s.link("a", ["b"])
    data = s.to_dict()
    # Mutate the returned dict
    data["links"]["a"].append("c")
    # Original should NOT be changed
    assert "c" not in s._links["a"]

def test_synapse_rename_concept():
    s = Synapse()
    s.link("a", ["b"], weights={"b": 0.8})
    s._frequencies["a"]["b"] = 5
    s._metadata["a"] = {"note": "test"}
    
    success = s.rename_concept("a", "alpha")
    assert success is True
    assert "a" not in s._links
    assert "alpha" in s._links
    assert "b" in s._links["alpha"]
    assert s.get_weight("alpha", "b") == 0.8
    assert s._frequencies["alpha"]["b"] == 5
    assert s._metadata["alpha"]["note"] == "test"
    # Check that neighbor's reference is updated
    assert "alpha" in s._links["b"]
    assert "a" not in s._links["b"]

def test_synapse_subgraph():
    s = Synapse()
    s.link("a", ["b", "c"], bidirectional=False)
    s.link("b", ["c"], bidirectional=False)
    s.link("c", ["d"], bidirectional=False)
    
    sub = s.subgraph(["a", "b", "c"])
    assert "a" in sub._links
    assert "b" in sub._links
    assert "c" in sub._links
    assert "d" not in sub._links
    # 'a' should only link to 'b' and 'c' (both in subgraph)
    assert sorted(sub._links["a"]) == ["b", "c"]
    # 'c' should link to NOTHING (since 'd' is not in subgraph)
    assert sub._links["c"] == []

def test_memory_get_or_set():
    mem = Memory()
    val = mem.get_or_set("user.name", "Alice")
    assert val == "Alice"
    assert mem.get("user.name") == "Alice"
    
    val2 = mem.get_or_set("user.name", "Bob")
    assert val2 == "Alice"  # Already set

def test_memory_increment():
    mem = Memory()
    assert mem.increment("hits") == 1
    assert mem.increment("hits") == 2
    assert mem.increment("hits", delta=5) == 7
    
    # Test on non-numeric
    mem.set("label", "text")
    assert mem.increment("label") == 1

def test_memory_batch_get():
    mem = Memory()
    mem.set("a", 1).set("b", 2)
    results = mem.batch_get(["a", "b", "c"], default=0)
    assert results == {"a": 1, "b": 2, "c": 0}

def test_schema_validate_memory():
    mem = Memory()
    mem.set("u.n", "Alice")
    schema = Schema({"u": {"n": "str"}})
    assert schema.validate_memory(mem) is True
    mem.set("u.n", 123)
    assert schema.validate_memory(mem) is False


# ── Phase 3: Advanced Architecture Tests ─────────────────────────

def test_memory_watchers():
    mem = Memory()
    events = []
    
    def on_change(path, val):
        events.append((path, val))
        
    mem.watch("user.profile", on_change)
    
    # Trigger on exact match
    mem.set("user.profile", {"name": "Alice"})
    assert len(events) == 1
    assert events[-1] == ("user.profile", {"name": "Alice"})
    
    # Trigger on child update (non-exact)
    mem.set("user.profile.age", 30)
    assert len(events) == 2
    assert events[-1] == ("user.profile.age", 30)
    
    # Exact watch
    exact_events = []
    mem.watch("status", lambda p, v: exact_events.append(v), exact=True)
    mem.set("status.active", True)
    assert len(exact_events) == 0  # Should not trigger (it's a child)
    mem.set("status", "ready")
    assert len(exact_events) == 1
    assert exact_events[0] == "ready"

def test_synapse_strongest_path():
    s = Synapse()
    # Path 1: a -> b -> c (weights: 0.1, 0.1) -> weak
    # Path 2: a -> d -> c (weights: 0.9, 0.9) -> strong
    s.link("a", ["b", "d"], bidirectional=False, weights={"b": 0.1, "d": 0.9})
    s.link("b", ["c"], bidirectional=False, weights={"c": 0.1})
    s.link("d", ["c"], bidirectional=False, weights={"c": 0.9})
    
    # BFS find_path might return either 2-hop path (non-deterministic if order same)
    # find_strongest_path MUST return [a, d, c]
    path = s.find_strongest_path("a", "c")
    assert path == ["a", "d", "c"]

def test_weightgate_ngrams():
    s = Synapse()
    s.link("machine learning", ["ai", "python"])
    # Default ngram_size=1 would miss "machine learning"
    gate = WeightGate(synapse=s, enabled=True, ngram_size=2)
    
    # Process text mentioning the bigram + an association to trigger a change
    changes = gate.process_input("I work on machine learning and ai")
    assert "machine learning" in changes
    assert "ai↑" in changes["machine learning"]

def test_schema_typed_lists():
    # List of strings
    schema = Schema({"tags": ["str"]})
    assert schema.validate({"tags": ["a", "b", "c"]}) is True
    assert schema.validate({"tags": ["a", 1, "c"]}) is False
    
    # List of objects
    schema_nested = Schema({"users": [{"name": "str", "!age": "int"}]})
    assert schema_nested.validate({"users": [{"name": "A", "age": 1}]}) is True
    assert schema_nested.validate({"users": [{"name": "A"}]}) is False  # Missing required '!age'
    
    # Default skeleton for lists
    assert schema.defaults() == {"tags": []}


# ── Phase 4: Ephemeral Memory (TTL) Tests ───────────────────────

def test_memory_ttl_expiry():
    import time
    mem = Memory()
    mem.set("temp", "value", ttl=0.1)
    assert mem.get("temp") == "value"
    
    time.sleep(0.15)
    assert mem.get("temp") is None
    assert "temp" not in mem._data

def test_memory_ttl_parent_expiry():
    import time
    mem = Memory()
    mem.set("session", {"user": "Alice", "token": "123"}, ttl=0.1)
    assert mem.get("session.user") == "Alice"
    
    time.sleep(0.15)
    # Accessing child should trigger parent expiry check
    assert mem.get("session.user") is None
    assert "session" not in mem._data

def test_memory_ttl_persistence():
    mem = Memory()
    mem.set("key", "val", ttl=100)
    
    state = mem.get_state()
    
    mem2 = Memory()
    mem2.set_state(state)
    assert mem2.get("key") == "val"
    assert "key" in mem2._ttls

def test_memory_purge_expired():
    import time
    mem = Memory()
    mem.set("a", 1, ttl=0.1)
    mem.set("b", 2, ttl=100)
    
    time.sleep(0.15)
    removed = mem.purge_expired()
    assert removed == 1
    assert "a" not in mem._data
    assert "b" in mem._data

def test_memory_export_purges():
    import time
    mem = Memory()
    mem.set("temp", "secret", ttl=0.1)
    time.sleep(0.15)
    
    # Export should not include expired key
    out = mem.export()
    assert "secret" not in out
    assert mem.get("temp") is None

# ── Phase 5: Advanced Search & Transactions Tests ───────────────

def test_memory_find_regex():
    mem = Memory()
    mem.set("users.alice.health", 100)
    mem.set("users.bob.health", 80)
    mem.set("users.charlie.status", "idle")
    mem.set("system.config.health", "ok")
    
    # 1. Match one segment
    results = mem.find("users.*.health")
    assert len(results) == 2
    assert "users.alice.health" in results
    assert "users.bob.health" in results
    assert "users.charlie.status" not in results

    # 2. Exact match
    results = mem.find("system.config.health")
    assert len(results) == 1
    assert results["system.config.health"] == "ok"

def test_memory_find_double_wildcard():
    mem = Memory()
    mem.set("status", "global_ok")
    mem.set("job.status", "running")
    mem.set("job.task.subtask.status", "pending")
    mem.set("other.config", 1)
    
    results = mem.find("**.status")
    assert len(results) == 3
    assert "status" in results
    assert "job.status" in results
    assert "job.task.subtask.status" in results
    assert "other.config" not in results

def test_memory_snapshot_rollback():
    mem = Memory()
    mem.set("user.name", "Alice", ttl=100)
    mem.set("user.score", 50)
    
    # Take snapshot
    mem.snapshot("pre_trial")
    
    # Mutate
    mem.set("user.name", "Bob")
    mem.delete("user.score")
    mem.set("trial.data", [1, 2, 3])
    
    assert mem.get("user.name") == "Bob"
    assert mem.has("trial.data")
    
    # Rollback
    success = mem.rollback("pre_trial")
    assert success is True
    assert mem.get("user.name") == "Alice"
    assert mem.get("user.score") == 50
    assert "trial.data" not in mem._data
    assert "user.name" in mem._ttls  # Meta preserved

def test_memory_rollback_not_found():
    mem = Memory()
    assert mem.rollback("non_existent") is False

# ── Phase 6: Memory Fading & Persistence Tests ──────────────────

def test_lru_eviction():
    # max_chars=100, policy="lru"
    mem = Memory(max_chars=100, eviction_policy="lru")
    
    # Fill up memory
    mem.set("a", "old_and_stale") # ~20 chars
    mem.set("b", "accessing_now")
    
    import time
    time.sleep(0.01)
    mem.get("b") # b is now newer than a
    
    # This big update should force 'a' out
    mem.set("c", "X" * 60)
    
    assert mem.has("c")
    assert mem.has("b")
    assert not mem.has("a") # a should be evicted

def test_lru_native_overflow():
    mem = Memory(max_chars=50, eviction_policy="lru")
    import pytest
    with pytest.raises(ValueError):
        # Even with eviction, this single key is too big
        mem.set("giant", "Z" * 100)

def test_auto_flush_persistence():
    import os
    flush_file = "/www/wwwroot/json-memory/tests/test_flush.json"
    if os.path.exists(flush_file):
        os.remove(flush_file)
        
    try:
        mem = Memory(max_chars=1000, auto_flush_path=flush_file)
        mem.set("persistent.key", "value")
        
        # Verify file exists and has content
        assert os.path.exists(flush_file)
        with open(flush_file, "r") as f:
            data = json.load(f)
            assert data["data"]["persistent"]["key"] == "value"
            
        # Verify changes flush automatically
        mem.set("persistent.other", 123)
        with open(flush_file, "r") as f:
            data = json.load(f)
            assert data["data"]["persistent"]["other"] == 123
            
    finally:
        if os.path.exists(flush_file):
            os.remove(flush_file)

# ── Phase 7: Enterprise & Concurrency Tests ────────────────────

def test_thread_safety():
    import threading
    mem = Memory(max_chars=1000)
    mem.set("counter", 0)
    
    def worker():
        for _ in range(10):
            mem.increment("counter")
            
    threads = [threading.Thread(target=worker) for _ in range(5)]
    for t in threads: t.start()
    for t in threads: t.join()
    
    assert mem.get("counter") == 50

def test_audit_history():
    mem = Memory(track_history=True)
    mem.set("user.name", "Alice")
    mem.set("user.age", 30)
    mem.delete("user.name")
    
    hist = mem.history()
    assert len(hist) == 3
    assert hist[0]["action"] == "set"
    assert hist[0]["path"] == "user.name"
    assert hist[0]["value"] == "Alice"
    assert hist[2]["action"] == "delete"
    assert hist[2]["path"] == "user.name"

def test_openai_tool_export():
    schema = Schema({
        "!user": {
            "name": "str",
            "age": "int"
        },
        "tasks": ["str"]
    })
    
    tools = schema.to_openai_tools("update_memory", "Update the agent memory")
    
    assert len(tools) == 1
    assert tools[0]["type"] == "function"
    assert tools[0]["function"]["name"] == "update_memory"
    
    params = tools[0]["function"]["parameters"]
    assert params["type"] == "object"
    assert "user" in params["properties"]
    assert "user" in params["required"]
    assert params["properties"]["tasks"]["type"] == "array"
    assert params["properties"]["tasks"]["items"]["type"] == "string"

# ── Phase 8: Framework Maturity Tests ──────────────────────────

def test_sqlite_adapter():
    import os
    from json_memory.adapters import SQLiteAdapter
    db_file = "/www/wwwroot/json-memory/tests/test_brain.db"
    if os.path.exists(db_file): os.remove(db_file)
    
    try:
        adapter = SQLiteAdapter(db_file)
        mem = Memory(storage_adapter=adapter)
        mem.set("user.name", "SQLite User")
        
        # Verify it saved
        state = adapter.load()
        assert state["data"]["user"]["name"] == "SQLite User"
        
        # Reload into new memory
        mem2 = Memory(storage_adapter=adapter)
        assert mem2.get("user.name") == "SQLite User"
    finally:
        if os.path.exists(db_file): os.remove(db_file)

def test_data_redaction():
    mem = Memory(track_history=True, redact_keys=["api_key", "password"])
    mem.set("services.openai.api_key", "sk-12345")
    mem.set("user.password", "secret_pass")
    mem.set("user.email", "alice@example.com")
    
    # 1. Test history redaction
    hist = mem.history()
    keys_in_hist = [entry["path"] for entry in hist]
    assert "services.openai.api_key" in keys_in_hist
    # Find the specific entry
    api_key_entry = next(e for e in hist if e["path"] == "services.openai.api_key")
    assert api_key_entry["value"] == "***REDACTED***"
    
    # 2. Test export redaction
    pretty = mem.export_pretty(redact=True)
    assert "sk-12345" not in pretty
    assert "secret_pass" not in pretty
    assert "***REDACTED***" in pretty
    assert "alice@example.com" in pretty
    
    # 3. Test to_dict redaction
    d = mem.to_dict(redact=True)
    assert d["services"]["openai"]["api_key"] == "***REDACTED***"
    assert d["user"]["password"] == "***REDACTED***"
    assert d["user"]["email"] == "alice@example.com"

def test_adapter_auto_config():
    import os
    file_path = "/www/wwwroot/json-memory/tests/test_auto.json"
    if os.path.exists(file_path): os.remove(file_path)
    
    try:
        mem = Memory(auto_flush_path=file_path)
        from json_memory.adapters import FileAdapter
        assert isinstance(mem.storage_adapter, FileAdapter)
        mem.set("key", "val")
        assert os.path.exists(file_path)
    finally:
        if os.path.exists(file_path): os.remove(file_path)
