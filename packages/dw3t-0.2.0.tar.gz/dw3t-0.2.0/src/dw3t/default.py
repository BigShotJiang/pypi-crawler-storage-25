DEFAULT_LAYER = {
    "simulation": {
        "output_dir": "unset",
        "prodimo_dir": "unset",
        "simulation_files_only": False,
        "processing": {
            "mode": "identity",
        },
    },
    "dust": {
        "temperature": {
            "mode":"unset",
            "value":"unset",
        },
        "opacity": {
            "mix": {
                "extrapolate_lambda_micron": {},
            },
            "rho": "unset",
            "smoothing": False,
        },
    },
    "gas": {
        "abundance": {
            "mode":"unset",
            "value":"unset",
        },
        "number_density": {
            "mode":"unset",
            "value":"unset",
        },
        "temperature": {
            "mode":"unset",
            "value":"unset",
        },
    },
    "radmc3d": {},
    "stars": {
        "M_star": "unset",
        "mu_star": 1.37,
    },
    "wavelength_micron": {
        "min": 0.1,
        "max": 10_000,
        "N": 200,
    },
}

MANDATORY_SET = {
    "unit_length_au",
    "unit_mass_msun",
    "component",
    "R_star",
    "T_star",
}
