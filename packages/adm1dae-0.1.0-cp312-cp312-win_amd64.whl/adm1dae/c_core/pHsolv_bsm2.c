/*
 * adm1_ODE_bsm2.c is a C-file S-function for IAWQ AD Model No 1. 
 * In addition to the ADM1, temperature dependency and dummy states are added.
 * Some details are adjusted for BSM2 (pH inhibition, gas flow output etc).
 *
 * Copyright (2006):
 * Dr Christian Rosen, Dr Darko Vrecko and Dr Ulf Jeppsson
 * Dept. Industrial Electrical Engineering and Automation (IEA)
 * Lund University, Sweden
 * http://www.iea.lth.se/ 
 *
 * Modified by Dr Xavier Flores-Alsina
 * Dept. Industrial Electrical Engineering and Automation (IEA)
 * Lund University, Sweden
 * http://www.iea.lth.se/ 
 * May 2013
 */

#include "pHsolv_bsm2.h"
#include <math.h>

void pHsolv_bsm2_initialize(double *x0, const double *XINIT)
{

int i;

for (i = 0; i < 7; i++) {
   x0[i] = XINIT[i];
}
}

void pHsolv_bsm2_outputs(double *y, const double *x)
{

int i;

    for (i = 0; i < 7; i++) {
        y[i] = x[i]; /* state variables are passed on as output variables */
    }  
 
}

void pHsolv_bsm2_update(double *x, const double *u, const double *PAR, const double *XINIT)
{
    
    /* Newton-Raphson algorithm */
    
     double K_w, pK_w_base, K_a_va, pK_a_va_base, K_a_bu, pK_a_bu_base, K_a_pro, pK_a_pro_base, K_a_ac, pK_a_ac_base, K_a_co2, pK_a_co2_base, K_a_IN, pK_a_IN_base, T_base, T_op, R, factor;
     double Equ;
     double gradEqu;
             
     double delta;
     double S_H_ion0;
     double TOL, MaxSteps;
     
     int j;
     
     j = 1; 
     delta = 1.0;
     
     TOL = 1e-12;
     MaxSteps= 1000;
     S_H_ion0 = XINIT[0];
     
     while ( (delta > TOL || delta < -TOL) && (j <= MaxSteps) ) {
 
     R = PAR[77];
     T_base = PAR[78];
     T_op = PAR[79];
     pK_w_base = PAR[80];
     pK_a_va_base = PAR[81];
     pK_a_bu_base = PAR[82];
     pK_a_pro_base = PAR[83];
     pK_a_ac_base = PAR[84];
     pK_a_co2_base = PAR[85];
     pK_a_IN_base = PAR[86];
     
     factor = (1.0/T_base - 1.0/T_op)/(100.0*R);
     K_w = pow(10,-pK_w_base)*exp(55900.0*factor); /* T adjustment for K_w */
     K_a_va = pow(10,-pK_a_va_base);
     K_a_bu = pow(10,-pK_a_bu_base);
     K_a_pro = pow(10,-pK_a_pro_base);
     K_a_ac = pow(10,-pK_a_ac_base);
     K_a_co2 = pow(10,-pK_a_co2_base)*exp(7646.0*factor); /* T adjustment for K_a_co2 */
     K_a_IN = pow(10,-pK_a_IN_base)*exp(51965.0*factor);  /* T adjustment for K_a_IN */
     
     x[1] = K_a_va*(u[3])/(K_a_va+x[0]);   /* Sva- */
     x[2] = K_a_bu*(u[4])/(K_a_bu+x[0]);   /* Sbu- */
     x[3] = K_a_pro*(u[5])/(K_a_pro+x[0]); /* Spro- */
     x[4] = K_a_ac*(u[6])/(K_a_ac+x[0]);   /* Sac- */
     x[5] = K_a_co2*(u[9])/(K_a_co2+x[0]); /* SHCO3- */
     x[6] = K_a_IN*(u[10])/(K_a_IN+x[0]);  /* SNH3 */
     
     /* SH+ equation */ 
     
     Equ = u[74]+(u[10]-x[6])+x[0]      -x[5] -x[4]/64 -x[3]/112 -x[2]/160 -x[1]/208 -K_w/x[0] -u[76];  
     
     /* Gradient of SH+ equation */
     
     gradEqu =  1+K_a_IN*(u[10])/((K_a_IN+x[0])*(K_a_IN+x[0]))           
           +K_a_co2*(u[9])/((K_a_co2+x[0])*(K_a_co2+x[0]))          
           +1/64.0*K_a_ac*(u[6])/((K_a_ac+x[0])*(K_a_ac+x[0]))
           +1/112.0*K_a_pro*(u[5])/((K_a_pro+x[0])*(K_a_pro+x[0]))
           +1/160.0*K_a_bu*(u[4])/((K_a_bu+x[0])*(K_a_bu+x[0]))
           +1/208.0*K_a_va*(u[3])/((K_a_va+x[0])*(K_a_va+x[0]))
           +K_w/(x[0]*x[0]);
    
    /* iteration loop */
        
        delta = Equ;
    
        x[0] = S_H_ion0 - delta/gradEqu; /* Calculate the new SH+ */
        
        if (x[0] <= 0) {
            x[0] = 1e-12; /* to avoid numerical problems */
        }
        
        S_H_ion0 = x[0];
        ++j;
        
    } 

}
