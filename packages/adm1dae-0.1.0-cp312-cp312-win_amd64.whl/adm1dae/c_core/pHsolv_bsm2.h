#ifndef PHSOLV_BSM2_H
#define PHSOLV_BSM2_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    PHSOLV_BSM2_NX = 7,
    PHSOLV_BSM2_NU = 150,
    PHSOLV_BSM2_NY = 7
};

/*
 * Line-by-line refactor of the original Simulink S-function (pHsolv_bsm2.c)
 * into a standalone C core API.
 */

void pHsolv_bsm2_initialize(double *x0, const double *XINIT);

void pHsolv_bsm2_outputs(double *y, const double *x);

/*
 * Mirrors mdlUpdate:
 *  - x is updated in place via Newton-Raphson
 *  - XINIT is used as in the original code (initial guess XINIT[0])
 */
void pHsolv_bsm2_update(double *x, const double *u, const double *PAR, const double *XINIT);

#ifdef __cplusplus
}
#endif

#endif /* PHSOLV_BSM2_H */
