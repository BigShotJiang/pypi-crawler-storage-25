/*
 * Sh2solv_bsm2.c is a C-file S-function for IAWQ AD Model No 1. 
 * 
 * Copyright (2006):
 * Dr Christian Rosen, Dr Darko Vrecko and Dr Ulf Jeppsson
 * Dept. Industrial Electrical Engineering and Automation (IEA)
 * Lund University, Sweden
 * http://www.iea.lth.se/ 
 *
 * Modified by Xavier Flores-Alsina in order to include PC corrections
 * A speciation model is included according to the pples stated in Flores-Alsina et al., 2015 
 * Ion strengh, ion pairing and activity corrections are included within the calculations
 * Xc is removed from the list of state variables. Decay process is automatically mapped into Xch, Xli, Xpro, Xi and Si
 * May 2015
 */

#include "Sh2solv_adm1.h"
#include <math.h>

void Sh2solv_adm1_initialize(double *x0, const double *XINIT)
{

 x0[0] = XINIT[0];

}

void Sh2solv_adm1_outputs(double *y, const double *x)
{

    y[0] = x[0]; /* state variable is passed on as output variable */   
 
}

void Sh2solv_adm1_update(double *x, const double *u, const double *PAR, const double *V)
{ 
     /* Newton-Raphson algorithm */
    
     double eps, f_h2_su, Y_su, f_h2_aa, Y_aa, Y_fa, Y_c4, Y_pro, K_S_IN, k_m_su, K_S_su, pH_UL_aa, pH_LL_aa, k_m_aa;
     double K_S_aa, k_m_fa, K_S_fa, K_Ih2_fa, k_m_c4, K_S_c4, K_Ih2_c4, k_m_pro, K_S_pro, K_Ih2_pro;
     double pH_UL_ac, pH_LL_ac, k_m_h2, K_S_h2, pH_UL_h2, pH_LL_h2, R, T_base, T_op, kLa, K_H_h2, K_H_h2_base, V_liq, pH_op,I_pH_aa;
     double I_pH_h2, I_IN_lim, I_h2_fa, I_h2_c4, I_h2_pro, inhib[6]; 
     double proc5, proc6, proc7, proc8, proc9, proc10, proc12, p_gas_h2, procT8, reac8;
     double pHLim_aa, pHLim_h2, a_aa, a_h2, S_H_ion, n_aa, n_h2;
     double Equ;
     double gradEqu;
     
     double delta;
     double Sh20;
     int j;
    
     double TOL = 1e-12;
     double MaxSteps= 1000;

     eps = 0.000001;
     Sh20 = x[0]; /* Sh2 */
    
     j = 1; 
     delta = 1.0;
     
     while ( (delta > TOL || delta < -TOL) && (j <= MaxSteps) ) {
         
     f_h2_su = PAR[18];
     Y_su = PAR[27];
     f_h2_aa = PAR[28];
     Y_aa = PAR[34];
     Y_fa = PAR[35];
     Y_c4 = PAR[36];
     Y_pro = PAR[37];
     K_S_IN = PAR[45];
     k_m_su = PAR[46];
     K_S_su = PAR[47];
     pH_UL_aa = PAR[48];
     pH_LL_aa = PAR[49];
     k_m_aa = PAR[50];
     K_S_aa = PAR[51];
     k_m_fa = PAR[52];
     K_S_fa = PAR[53];
     K_Ih2_fa = PAR[54];
     k_m_c4 = PAR[55];
     K_S_c4 = PAR[56];
     K_Ih2_c4 = PAR[57];
     k_m_pro = PAR[58];
     K_S_pro = PAR[59];
     K_Ih2_pro = PAR[60];
     pH_UL_ac = PAR[64];
     pH_LL_ac = PAR[65];
     k_m_h2 = PAR[66];
     K_S_h2 = PAR[67];
     pH_UL_h2 = PAR[68];
     pH_LL_h2 = PAR[69];
     R = PAR[77];
     T_base = PAR[78]; 
     T_op = PAR[79]; 
     kLa = PAR[94];
     K_H_h2_base = PAR[98];
     V_liq = V[0];
  
     K_H_h2 = K_H_h2_base*exp(-4180.0*(1.0/T_base - 1.0/T_op)/(100.0*R));     /* T adjustment for K_H_h2 */
     
     pH_op = u[27];   /* pH */
     S_H_ion = u[28]; /* SH+ */
   
/* Hill function on SH+ used within BSM2, ADM1 Workshop, Copenhagen 2005. */
     pHLim_aa = pow(10,(-(pH_UL_aa + pH_LL_aa)/2.0));
     pHLim_h2 = pow(10,(-(pH_UL_h2 + pH_LL_h2)/2.0));
     n_aa=3.0/(pH_UL_aa-pH_LL_aa);
     n_h2=3.0/(pH_UL_h2-pH_LL_h2);
     I_pH_aa = pow(pHLim_aa,n_aa)/(pow(S_H_ion,n_aa)+pow(pHLim_aa ,n_aa));
     I_pH_h2 = pow(pHLim_h2,n_h2)/(pow(S_H_ion,n_h2)+pow(pHLim_h2 ,n_h2));

     I_IN_lim = 1.0/(1.0+K_S_IN/(u[10]));
     I_h2_fa = 1.0/(1.0+x[0]/K_Ih2_fa);
     I_h2_c4 = 1.0/(1.0+x[0]/K_Ih2_c4);
     I_h2_pro = 1.0/(1.0+x[0]/K_Ih2_pro);
          
     inhib[0] = I_pH_aa*I_IN_lim;
     inhib[1] = inhib[0]*I_h2_fa;
     inhib[2] = inhib[0]*I_h2_c4;
     inhib[3] = inhib[0]*I_h2_pro;
     inhib[5] = I_pH_h2*I_IN_lim;
     
     proc5 = k_m_su*u[0]/(K_S_su+u[0])*u[16]*inhib[0];
     proc6 = k_m_aa*u[1]/(K_S_aa+u[1])*u[17]*inhib[0];
     proc7 = k_m_fa*u[2]/(K_S_fa+u[2])*u[18]*inhib[1];
     proc8 = k_m_c4*u[3]/(K_S_c4+u[3])*u[19]*u[3]/(u[3]+u[4]+eps)*inhib[2];
     proc9 = k_m_c4*u[4]/(K_S_c4+u[4])*u[19]*u[4]/(u[3]+u[4]+eps)*inhib[2];
     proc10 = k_m_pro*u[5]/(K_S_pro+u[5])*u[20]*inhib[3];
     
     proc12 = k_m_h2*x[0]/(K_S_h2+x[0])*u[22]*inhib[5];
     
     p_gas_h2 = u[29]*R*T_op/16.0; 
     procT8 = kLa*(x[0]-16.0*K_H_h2*p_gas_h2);
     
     reac8 = (1.0-Y_su)*f_h2_su*proc5+(1.0-Y_aa)*f_h2_aa*proc6+(1.0-Y_fa)*0.3*proc7+(1.0-Y_c4)*0.15*proc8+(1.0-Y_c4)*0.2*proc9+(1.0-Y_pro)*0.43*proc10-proc12-procT8; 
     
     /* Sh2 equation */ 
     
     Equ = 1/V_liq*u[24]*(u[26]-x[0])+reac8;    
     
     /* Gradient of Sh2 equation */
     
     gradEqu =  -1/V_liq*u[24]
            -3.0/10.0*(1-Y_fa)*k_m_fa*u[2]/(K_S_fa+u[2])*u[18]*I_pH_aa/(1+K_S_IN/(u[10]))/((1+x[0]/K_Ih2_fa)*(1+x[0]/K_Ih2_fa))/K_Ih2_fa
            -3.0/20.0*(1-Y_c4)*k_m_c4*u[3]*u[3]/(K_S_c4+u[3])*u[19]/(u[4]+u[3]+eps)*I_pH_aa/(1+K_S_IN/(u[10]))/((1+x[0]/K_Ih2_c4)*(1+x[0]/K_Ih2_c4))/K_Ih2_c4
            -1.0/5.0*(1-Y_c4)*k_m_c4*u[4]*u[4]/(K_S_c4+u[4])*u[19]/(u[4]+u[3]+eps)*I_pH_aa/(1+K_S_IN/(u[10]))/((1+x[0]/K_Ih2_c4)*(1+x[0]/K_Ih2_c4))/K_Ih2_c4
            -43.0/100.0*(1-Y_pro)*k_m_pro*u[5]/(K_S_pro+u[5])*u[20]*I_pH_aa/(1+K_S_IN/(u[10]))/((1+x[0]/K_Ih2_pro)*(1+x[0]/K_Ih2_pro))/K_Ih2_pro
            -k_m_h2/(K_S_h2+x[0])*u[22]*I_pH_h2/(1+K_S_IN/(u[10]))+k_m_h2*x[0]/((K_S_h2+x[0])*(K_S_h2+x[0]))*u[22]*I_pH_h2/(1+K_S_IN/(u[10]))
            -kLa;  
    
    /*iteration loop*/
   
        delta = Equ;
        x[0] = Sh20-delta/gradEqu;     /* Calculate the new Sh2 */ 
        
        if (x[0] <= 0) {
            x[0] = 1e-12; /* to avoid numerical problems */
        }
        
        Sh20 = x[0];
        ++j;
    } 
}
