#ifndef SH2SOLV_ADM1_H
#define SH2SOLV_ADM1_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    SH2SOLV_ADM1_NX = 1,
    SH2SOLV_ADM1_NU = 150,
    SH2SOLV_ADM1_NY = 1
};

/*
 * Line-by-line refactor of the original Simulink S-function (Sh2solv_adm1.c)
 * into a standalone C core API.
 */

void Sh2solv_adm1_initialize(double *x0, const double *XINIT);

void Sh2solv_adm1_outputs(double *y, const double *x);

void Sh2solv_adm1_update(double *x, const double *u, const double *PAR, const double *V);

#ifdef __cplusplus
}
#endif

#endif /* SH2SOLV_ADM1_H */
