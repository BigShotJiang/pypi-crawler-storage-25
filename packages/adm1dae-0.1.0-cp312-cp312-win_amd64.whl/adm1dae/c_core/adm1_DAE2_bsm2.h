#ifndef ADM1_DAE2_BSM2_H
#define ADM1_DAE2_BSM2_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

enum {
    ADM1_DAE2_BSM2_NX = 105,
    ADM1_DAE2_BSM2_NU = 101,
    ADM1_DAE2_BSM2_NY = 150
};

/*
 * Line-by-line refactor of the original Simulink S-function into a standalone C core API.
 *
 * The API mirrors the Simulink callbacks:
 *  - adm1_DAE2_bsm2_initialize()  ~ mdlInitializeConditions
 *  - adm1_DAE2_bsm2_outputs()     ~ mdlOutputs
 *  - adm1_DAE2_bsm2_derivatives() ~ mdlDerivatives
 */

void adm1_DAE2_bsm2_initialize(double *x0, const double *XINIT);

void adm1_DAE2_bsm2_outputs(
    double *y,
    const double *x,
    const double *u,
    const double *PAR,
    const double *V
);

void adm1_DAE2_bsm2_derivatives(
    double *dx,
    const double *x,
    const double *u,
    const double *PAR,
    const double *V
);

#ifdef __cplusplus
}
#endif

#endif /* ADM1_DAE2_BSM2_H */
