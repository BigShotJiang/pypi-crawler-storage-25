# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False

import numpy as np
cimport numpy as cnp

from cdefs cimport adm1_DAE2_bsm2_initialize, adm1_DAE2_bsm2_outputs, adm1_DAE2_bsm2_derivatives

ctypedef cnp.float64_t DTYPE_t

_DEF_NX = 105
_DEF_NU = 101
_DEF_NY = 150


def initialize(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x0,
               cnp.ndarray[DTYPE_t, ndim=1, mode="c"] xinit):
    """Mirror of mdlInitializeConditions.

    x0: state vector to be initialized (len=105)
    xinit: initial state values (len>=105)
    """
    if x0.shape[0] != _DEF_NX:
        raise ValueError(f"x0 must have length {_DEF_NX}")
    if xinit.shape[0] < _DEF_NX:
        raise ValueError(f"xinit must have length >= {_DEF_NX}")
    adm1_DAE2_bsm2_initialize(<double*>x0.data, <const double*>xinit.data)


def outputs(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] y,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] u,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] par,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] V):
    """Mirror of mdlOutputs.

    y: outputs (len=150)
    x: states  (len=105)
    u: inputs  (len>=101)
    par: parameter vector (len>=100)
    V: volume vector (len>=1)
    """
    if y.shape[0] != _DEF_NY:
        raise ValueError(f"y must have length {_DEF_NY}")
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    if u.shape[0] < _DEF_NU:
        raise ValueError(f"u must have length >= {_DEF_NU}")
    if par.shape[0] < 100:
        raise ValueError("par must have length >= 100")
    if V.shape[0] < 1:
        raise ValueError("V must have length >= 1")

    adm1_DAE2_bsm2_outputs(<double*>y.data,
                          <const double*>x.data,
                          <const double*>u.data,
                          <const double*>par.data,
                          <const double*>V.data)


def derivatives(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] dx,
                cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x,
                cnp.ndarray[DTYPE_t, ndim=1, mode="c"] u,
                cnp.ndarray[DTYPE_t, ndim=1, mode="c"] par,
                cnp.ndarray[DTYPE_t, ndim=1, mode="c"] V):
    """Mirror of mdlDerivatives.

    dx: derivatives (len=105)
    x:  states      (len=105)
    u:  inputs      (len>=101)
    par: parameter vector (len>=100)
    V: volume vector (len>=2 in original model; here checked >=2 for safety)
    """
    if dx.shape[0] != _DEF_NX:
        raise ValueError(f"dx must have length {_DEF_NX}")
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    if u.shape[0] < _DEF_NU:
        raise ValueError(f"u must have length >= {_DEF_NU}")
    if par.shape[0] < 100:
        raise ValueError("par must have length >= 100")
    if V.shape[0] < 2:
        raise ValueError("V must have length >= 2 (V_liq, V_gas)")

    adm1_DAE2_bsm2_derivatives(<double*>dx.data,
                              <const double*>x.data,
                              <const double*>u.data,
                              <const double*>par.data,
                              <const double*>V.data)
