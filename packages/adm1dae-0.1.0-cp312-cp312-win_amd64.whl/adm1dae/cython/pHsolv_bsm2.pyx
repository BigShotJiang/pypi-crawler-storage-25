# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False

import numpy as np
cimport numpy as cnp

from cdefs cimport pHsolv_bsm2_initialize, pHsolv_bsm2_outputs, pHsolv_bsm2_update

ctypedef cnp.float64_t DTYPE_t

_DEF_NX = 7
_DEF_NU = 150
_DEF_NY = 7


def initialize(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x0,
               cnp.ndarray[DTYPE_t, ndim=1, mode="c"] xinit):
    """Mirror of mdlInitializeConditions.

    x0: solver state vector to be initialized (len=7)
    xinit: initial values (len>=7)
    """
    if x0.shape[0] != _DEF_NX:
        raise ValueError(f"x0 must have length {_DEF_NX}")
    if xinit.shape[0] < _DEF_NX:
        raise ValueError(f"xinit must have length >= {_DEF_NX}")
    pHsolv_bsm2_initialize(<double*>x0.data, <const double*>xinit.data)


def outputs(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] y,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x):
    """Mirror of mdlOutputs.

    y: outputs (len=7)
    x: states  (len=7)
    """
    if y.shape[0] != _DEF_NY:
        raise ValueError(f"y must have length {_DEF_NY}")
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    pHsolv_bsm2_outputs(<double*>y.data, <const double*>x.data)


def update(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] u,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] par,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] xinit):
    """Mirror of mdlUpdate (Newton-Raphson).

    This refactor preserves original behavior:
      - uses XINIT[0] as initial guess each call, exactly like the S-function.

    x: solver state vector (len=7), updated in-place
    u: adm1 outputs vector (len>=150)
    par: parameter vector (len>=87)
    xinit: XINIT parameter (len>=7)
    """
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    if u.shape[0] < _DEF_NU:
        raise ValueError(f"u must have length >= {_DEF_NU}")
    if par.shape[0] < 87:
        raise ValueError("par must have length >= 87")
    if xinit.shape[0] < _DEF_NX:
        raise ValueError(f"xinit must have length >= {_DEF_NX}")

    pHsolv_bsm2_update(<double*>x.data,
                      <const double*>u.data,
                      <const double*>par.data,
                      <const double*>xinit.data)
