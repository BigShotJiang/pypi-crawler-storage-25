# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False

import numpy as np
cimport numpy as cnp

from cdefs cimport Sh2solv_adm1_initialize, Sh2solv_adm1_outputs, Sh2solv_adm1_update

ctypedef cnp.float64_t DTYPE_t

_DEF_NX = 1
_DEF_NU = 150
_DEF_NY = 1


def initialize(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x0,
               cnp.ndarray[DTYPE_t, ndim=1, mode="c"] xinit):
    """Mirror of mdlInitializeConditions."""
    if x0.shape[0] != _DEF_NX:
        raise ValueError(f"x0 must have length {_DEF_NX}")
    if xinit.shape[0] < _DEF_NX:
        raise ValueError(f"xinit must have length >= {_DEF_NX}")
    Sh2solv_adm1_initialize(<double*>x0.data, <const double*>xinit.data)


def outputs(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] y,
            cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x):
    """Mirror of mdlOutputs: pass discrete state as output."""
    if y.shape[0] != _DEF_NY:
        raise ValueError(f"y must have length {_DEF_NY}")
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    Sh2solv_adm1_outputs(<double*>y.data, <const double*>x.data)


def update(cnp.ndarray[DTYPE_t, ndim=1, mode="c"] x,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] u,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] par,
           cnp.ndarray[DTYPE_t, ndim=1, mode="c"] V):
    """Mirror of mdlUpdate (Newton-Raphson)."""
    if x.shape[0] != _DEF_NX:
        raise ValueError(f"x must have length {_DEF_NX}")
    if u.shape[0] < _DEF_NU:
        raise ValueError(f"u must have length >= {_DEF_NU}")
    if par.shape[0] < 99:
        raise ValueError("par must have length >= 99")
    if V.shape[0] < 1:
        raise ValueError("V must have length >= 1")

    Sh2solv_adm1_update(<double*>x.data,
                       <const double*>u.data,
                       <const double*>par.data,
                       <const double*>V.data)
