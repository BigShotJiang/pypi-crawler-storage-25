# distutils: language = c

cdef extern from "adm1_DAE2_bsm2.h":
    void adm1_DAE2_bsm2_initialize(double *x0, const double *XINIT)
    void adm1_DAE2_bsm2_outputs(double *y, const double *x, const double *u, const double *PAR, const double *V)
    void adm1_DAE2_bsm2_derivatives(double *dx, const double *x, const double *u, const double *PAR, const double *V)

cdef extern from "pHsolv_bsm2.h":
    void pHsolv_bsm2_initialize(double *x0, const double *XINIT)
    void pHsolv_bsm2_outputs(double *y, const double *x)
    void pHsolv_bsm2_update(double *x, const double *u, const double *PAR, const double *XINIT)

cdef extern from "Sh2solv_adm1.h":
    void Sh2solv_adm1_initialize(double *x0, const double *XINIT)
    void Sh2solv_adm1_outputs(double *y, const double *x)
    void Sh2solv_adm1_update(double *x, const double *u, const double *PAR, const double *V)
