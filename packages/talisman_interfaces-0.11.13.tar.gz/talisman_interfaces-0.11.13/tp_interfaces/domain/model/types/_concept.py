from tdm.abstract.json_schema import generate_model
from tdm.datamodel.domain import AccountType, ConceptType, PlatformType
from tdm.datamodel.domain.types import DocumentType

from tp_interfaces.domain.types import StoryType

generate_model(label='concept')(ConceptType)
generate_model(label='document')(DocumentType)
generate_model(label='account')(AccountType)
generate_model(label='platform')(PlatformType)
generate_model(label='story')(StoryType)
