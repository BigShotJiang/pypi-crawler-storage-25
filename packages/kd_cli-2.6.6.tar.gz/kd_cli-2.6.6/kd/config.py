"""YAML-based configuration with hierarchical resolution.

Flat-key resolution chain (first match wins per key):

1. CLI flags
2. Local config — ``.kd/config.yaml`` found by walking up from cwd
3. Global config — ``~/.config/kd/config.yaml``
4. Built-in default

Command-option resolution chain (10-level, via :func:`resolve_command_defaults`):

1. CLI flag (caller skips options already in ``raw_options``)
2. Env var (N/A for command options)
3. Project command default — ``projects.<PROJ>.defaults.<cmd>.<opt>``
4. Local command default — ``defaults.<cmd>.<opt>`` in local config
5. Local flat key — ``limit``/``output`` in local config
6. Connection command default — ``connections.<name>.defaults.<cmd>.<opt>``
7. Connection flat key — ``limit``/``output`` on the active connection
8. Global command default — ``defaults.<cmd>.<opt>`` in global config
9. Global flat key — ``limit``/``output`` in global config
10. Built-in default — from ``OptionDeclaration.default``

Use :func:`resolve_config` to get a :class:`ResolvedConfig` with per-key
source tracking.  Lower-level :func:`load_config` / :func:`save_config`
remain available for single-file operations.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, NamedTuple, get_origin

import yaml
from pydantic import BaseModel, Field, ValidationError

from kd.connection import ConnectionConfig
from kd.debug import DebugLog
from kd.exceptions import ConfigError

_CONNECTION_HINT = "Connection requires 'url' and one of 'token_cmd' or 'token_env'."

if TYPE_CHECKING:
    from kd.cli.core.option_registry import OptionDeclaration

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "kd" / "config.yaml"

# Environment variable names for config keys that support env override.
# url/token moved to per-connection auth (token_cmd / token_env).
_ENV_MAP: dict[str, str] = {
    "default_connection": "KD_CONNECTION",
}

# Origin labels for flag-sourced entries (overrides "--{key}" default).
_FLAG_ORIGINS: dict[str, str] = {
    "default_connection": "-c",
}


# ---------------------------------------------------------------------------
# Resolution types
# ---------------------------------------------------------------------------


class ConfigSource(StrEnum):
    """Where a resolved config value came from."""

    FLAG = "flag"
    ENV = "env"
    LOCAL = "local"
    GLOBAL = "global"
    DEFAULT = "default"


class ResolvedValue(NamedTuple):
    """A config value together with its provenance."""

    value: str
    source: ConfigSource
    origin: str  # e.g. "-c", "KD_CONNECTION", "/path/.kd/config.yaml"


@dataclass(frozen=True)
class ConnectionKeyOrigin:
    """Provenance of a single key inside a merged connection block."""

    source: str  # "local" or "global"
    path: str  # absolute path to the file that contributed the key


@dataclass(frozen=True)
class ConnectionOrigin:
    """Provenance of a connection entry resolved across config files.

    ``source`` / ``path`` name the *primary* contributing file — "local" if
    any key came from local config, otherwise "global".  ``keys`` carries
    per-key attribution so ``config list`` can render mixed-origin rows.
    """

    source: str
    path: str
    keys: dict[str, ConnectionKeyOrigin] = field(default_factory=dict)


class ResolvedConfig:
    """Config resolved from all sources with per-key source tracking.

    Flat keys are resolved via the standard chain (flag > local > global > default).
    Structured sections (defaults, projects, connections) are stored as raw dicts
    from each config file, enabling the 10-level command-option resolution chain.
    """

    def __init__(
        self,
        entries: dict[str, ResolvedValue],
        *,
        local_defaults: dict[str, dict[str, Any]] | None = None,
        global_defaults: dict[str, dict[str, Any]] | None = None,
        local_projects: dict[str, Any] | None = None,
        global_projects: dict[str, Any] | None = None,
        local_flat: dict[str, Any] | None = None,
        global_flat: dict[str, Any] | None = None,
        local_aliases: dict[str, str] | None = None,
        global_aliases: dict[str, str] | None = None,
        connections: dict[str, ConnectionConfig] | None = None,
        connection_origins: dict[str, ConnectionOrigin] | None = None,
        default_connection_name: str | None = None,
        connection_defaults: dict[str, dict[str, Any]] | None = None,
        connection_flat: dict[str, Any] | None = None,
    ) -> None:
        self._entries = dict(entries)
        self._local_defaults = local_defaults or {}
        self._global_defaults = global_defaults or {}
        self._local_projects = local_projects or {}
        self._global_projects = global_projects or {}
        self._local_flat = local_flat or {}
        self._global_flat = global_flat or {}
        self._local_aliases = local_aliases or {}
        self._global_aliases = global_aliases or {}
        self._connections = connections or {}
        self._connection_origins = connection_origins or {}
        self._default_connection_name = default_connection_name
        self._connection_defaults = connection_defaults or {}
        self._connection_flat = connection_flat or {}

    # -- flat key accessors --------------------------------------------------

    @property
    def default_project(self) -> str | None:
        rv = self._entries.get("default_project")
        return rv.value if rv else None

    @property
    def output(self) -> str:
        rv = self._entries.get("output")
        return rv.value if rv else "table"

    @property
    def limit(self) -> int:
        rv = self._entries.get("limit")
        if rv:
            try:
                return int(rv.value)
            except (ValueError, TypeError):
                return 50
        return 50

    @property
    def debug(self) -> bool:
        rv = self._entries.get("debug")
        if rv:
            return rv.value.lower() in ("true", "1", "yes")
        return False

    # -- dict-like access ----------------------------------------------------

    def get(self, key: str) -> ResolvedValue | None:
        return self._entries.get(key)

    @property
    def entries(self) -> dict[str, ResolvedValue]:
        """Read-only view of all resolved entries."""
        return dict(self._entries)

    # -- connection accessors -----------------------------------------------

    @property
    def connections(self) -> dict[str, ConnectionConfig]:
        return self._connections

    @property
    def connection_origins(self) -> dict[str, ConnectionOrigin]:
        """Provenance per connection: ``source`` (local/global) and ``path``."""
        return self._connection_origins

    @property
    def default_connection_name(self) -> str | None:
        return self._default_connection_name

    @property
    def connection_defaults(self) -> dict[str, dict[str, Any]]:
        return self._connection_defaults

    @property
    def connection_flat(self) -> dict[str, Any]:
        return self._connection_flat

    # -- structured section accessors ----------------------------------------

    @property
    def local_defaults(self) -> dict[str, dict[str, Any]]:
        return self._local_defaults

    @property
    def global_defaults(self) -> dict[str, dict[str, Any]]:
        return self._global_defaults

    @property
    def local_projects(self) -> dict[str, Any]:
        return self._local_projects

    @property
    def global_projects(self) -> dict[str, Any]:
        return self._global_projects

    @property
    def local_flat(self) -> dict[str, Any]:
        return self._local_flat

    @property
    def global_flat(self) -> dict[str, Any]:
        return self._global_flat

    @property
    def local_aliases(self) -> dict[str, str]:
        return self._local_aliases

    @property
    def global_aliases(self) -> dict[str, str]:
        return self._global_aliases

    @property
    def aliases(self) -> dict[str, str]:
        """Merged aliases: global first, local overrides."""
        merged = dict(self._global_aliases)
        merged.update(self._local_aliases)
        return merged

    def field_aliases_for(self, project_key: str) -> dict[str, str]:
        """Return the ``field_aliases`` map for *project_key*.

        Local-first, global-fallback — first tier with a dict entry for the
        project whose ``field_aliases`` is a dict wins. Empty dict when neither
        tier has the project or its ``field_aliases`` set. Current semantics
        are first-tier-wins, not merge.
        """
        for source in (self._local_projects, self._global_projects):
            proj_cfg = source.get(project_key)
            if isinstance(proj_cfg, dict):
                aliases = proj_cfg.get("field_aliases")
                if isinstance(aliases, dict):
                    return {str(k): str(v) for k, v in aliases.items()}
        return {}

    # -- derived views -------------------------------------------------------

    def with_active_connection(self, name: str) -> "ResolvedConfig":
        """Return a derived ResolvedConfig with *name* as the active connection.

        Reuses the existing connection map and per-connection origins — only
        ``default_connection_name``, ``connection_defaults``, and
        ``connection_flat`` change, reflecting the layer 6/7 view under the
        requested connection. Used by ``kd /system/config which --connection``
        for what-if exploration.

        Raises :class:`KeyError` when *name* is not a known connection; callers
        that need a user-facing message are expected to translate.
        """
        conn = self._connections[name]
        conn_flat: dict[str, Any] = {}
        if conn.output is not None:
            conn_flat["output"] = conn.output
        if conn.limit is not None:
            conn_flat["limit"] = conn.limit
        return ResolvedConfig(
            self._entries,
            local_defaults=self._local_defaults,
            global_defaults=self._global_defaults,
            local_projects=self._local_projects,
            global_projects=self._global_projects,
            local_flat=self._local_flat,
            global_flat=self._global_flat,
            local_aliases=self._local_aliases,
            global_aliases=self._global_aliases,
            connections=self._connections,
            connection_origins=self._connection_origins,
            default_connection_name=name,
            connection_defaults=conn.defaults,
            connection_flat=conn_flat,
        )


# ---------------------------------------------------------------------------
# Directory walk
# ---------------------------------------------------------------------------


def find_local_config(start: Path | None = None) -> Path | None:
    """Walk up from *start* to filesystem root, return first ``.kd/config.yaml`` found."""
    current = (start or Path.cwd()).resolve()
    while True:
        candidate = current / ".kd" / "config.yaml"
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:  # filesystem root
            return None
        current = parent


# ---------------------------------------------------------------------------
# Data model (single-file)
# ---------------------------------------------------------------------------


class ProjectConfig(BaseModel):
    """Per-project configuration: field aliases and scoped defaults."""

    field_aliases: dict[str, str] = Field(
        default_factory=dict,
        description="Map semantic CLI names to project-specific YouTrack field names",
    )
    defaults: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Per-command defaults scoped to this project",
    )


class HistoryConfig(BaseModel):
    """Copy-on-write snapshot settings."""

    retention: int = Field(
        default=20,
        description="Max snapshots to keep per file before pruning the oldest",
    )


class YtctlConfig(BaseModel):
    """Configuration model.

    Connection-first: ``default_connection`` + ``connections:`` replace
    the former flat ``url``/``token``/``default_project`` keys.
    Global ``output``/``limit``/``debug`` are fallbacks for connections
    that don't specify their own.
    """

    # Connection routing
    default_connection: str | None = Field(
        default=None,
        description="Active connection name",
    )
    connections: dict[str, ConnectionConfig] = Field(
        default_factory=dict,
        description="Named connections keyed by identifier",
    )

    # Global flat keys (fallbacks for all connections)
    output: str = Field(
        default="table",
        description="Default output format: table, json, yaml, md",
    )
    limit: int = Field(
        default=50,
        description="Default result limit for list commands",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug output (equivalent to -D)",
    )

    # Structured sections
    defaults: dict[str, dict[str, Any]] = Field(
        default_factory=dict,
        description="Per-command defaults keyed by namespace_command identifier",
    )
    projects: dict[str, ProjectConfig] = Field(
        default_factory=dict,
        description="Per-project field aliases and scoped defaults",
    )
    aliases: dict[str, str] = Field(
        default_factory=dict,
        description="Named command shortcuts that expand to full command strings",
    )
    history: HistoryConfig = Field(
        default_factory=HistoryConfig,
        description="Copy-on-write snapshot settings for config and primer files",
    )


def load_config(path: Path | None = None) -> YtctlConfig:
    """Load config from YAML file. Returns empty config if file doesn't exist."""
    config_path = path or DEFAULT_CONFIG_PATH
    if not config_path.exists():
        return YtctlConfig()
    try:
        raw = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
        return YtctlConfig(**raw)
    except (yaml.YAMLError, TypeError, ValueError) as e:
        raise ConfigError(f"Invalid config at {config_path}: {e}") from e


def save_config(config: YtctlConfig, path: Path | None = None) -> None:
    """Save config to YAML file. Creates parent directories if needed.

    Snapshots the current file before writing (copy-on-write) and uses
    atomic writes to prevent partial-write corruption.
    """
    from kd.history import atomic_write_text, snapshot_before_write

    config_path = path or DEFAULT_CONFIG_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    snapshot_before_write(config_path, retention=config.history.retention)
    data = config.model_dump(exclude_none=True)
    # Exclude history section when at default to keep config files clean
    if data.get("history") == HistoryConfig().model_dump():
        data.pop("history", None)
    atomic_write_text(config_path, yaml.dump(data, default_flow_style=False, sort_keys=False))


def _derive_flat_keys() -> tuple[str, ...]:
    """Top-level scalar fields of ``YtctlConfig`` — the flat-key set.

    Driven by the schema so adding a new top-level scalar field to
    ``YtctlConfig`` extends ``config set`` / ``get`` / resolution without
    a parallel edit here.
    """
    flat: list[str] = []
    for name, field_info in YtctlConfig.model_fields.items():
        annotation = field_info.annotation
        if get_origin(annotation) is dict:
            continue
        if isinstance(annotation, type) and issubclass(annotation, BaseModel):
            continue
        flat.append(name)
    return tuple(flat)


# Flat keys settable via `config set` (excludes structured sections and connections)
FLAT_KEYS: tuple[str, ...] = _derive_flat_keys()


def update_config(key: str, value: str, path: Path | None = None) -> None:
    """Update a single flat config key and save.

    Validates that the key is a known flat key (not a structured section).
    Connection-level values are not settable through this function.
    """
    config = load_config(path)
    if key not in FLAT_KEYS:
        valid_keys = ", ".join(FLAT_KEYS)
        raise ConfigError(f"Unknown config key: {key}. Valid keys: {valid_keys}")
    # Coerce types for non-string flat keys
    if key == "limit":
        try:
            setattr(config, key, int(value))
        except ValueError:
            raise ConfigError(f"Invalid integer for limit: {value}") from None
    elif key == "debug":
        setattr(config, key, value.lower() in ("true", "1", "yes"))
    else:
        setattr(config, key, value)
    save_config(config, path)


def update_config_path(path: str, value: str, config_path: Path) -> tuple[str, Any]:
    """Set a dotted config path in a single config file.

    Walks the config schema to validate the path, coerces *value* via
    ``TypeAdapter(annotation)``, writes to *config_path* as a raw YAML
    dict (no Pydantic round-trip; partial files are preserved),
    snapshots first and rolls back on post-write revalidation failure.

    Returns ``(path, coerced_value)``. Raises :class:`ConfigError` for
    unknown paths, coercion failures, and cross-field invariants that
    only surface after the whole config is re-parsed.
    """
    from pydantic import TypeAdapter

    from kd.config_schema import resolve_path
    from kd.history import DEFAULT_RETENTION, atomic_write_text, snapshot_before_write

    entry = resolve_path(path)
    if entry is None:
        raise ConfigError(
            f"Unknown config path: {path}. Run 'kd /system/config keys' to list available paths."
        )

    # Leaf coercion. ``Any`` leaves (defaults.<cmd>.<opt>) passthrough as string.
    if entry.annotation is Any:
        coerced: Any = value
    else:
        try:
            coerced = TypeAdapter(entry.annotation).validate_python(value)
        except ValidationError as e:
            details = _format_validation_errors(e)
            raise ConfigError(f"Invalid value for {path} in {config_path}: {details}") from e

    # Load raw YAML, capture original text for rollback.
    raw = _load_raw_yaml(config_path)
    original_text: str | None
    original_text = config_path.read_text(encoding="utf-8") if config_path.exists() else None

    retention = _retention_from_raw(raw, DEFAULT_RETENTION)
    snapshot_before_write(config_path, retention=retention)

    _set_nested_path(raw, path.split("."), coerced)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(config_path, yaml.dump(raw, default_flow_style=False, sort_keys=False))

    # Post-write revalidation: catches cross-field invariants
    # (e.g. ConnectionConfig's token_cmd-or-token_env rule) against the
    # *merged* view of local + global, matching S2's deep-merge semantics.
    try:
        _revalidate_merged(config_path)
    except (ValidationError, ConfigError) as e:
        _rollback_file(config_path, original_text)
        if isinstance(e, ConfigError):
            raise ConfigError(
                f"Config would be invalid after setting {path}: {e}",
                suggestion=e.suggestion,
            ) from e
        details = _format_validation_errors(e)
        raise ConfigError(
            f"Config would be invalid after setting {path} in {config_path}: {details}",
        ) from e

    return path, coerced


def _revalidate_merged(config_path: Path) -> None:
    """Re-validate the merged local+global config after a targeted write.

    Connections deep-merge across tiers (S2), so a local-only connection
    override (e.g. just ``default_project``) is valid even though the local
    file alone would fail the ``token_cmd``/``token_env`` invariant. This
    walker mirrors :func:`resolve_config`'s connection merge and validates
    each merged connection once, then parses each tier's non-connection
    sections in isolation.
    """
    from kd.debug import DebugLog

    if config_path == DEFAULT_CONFIG_PATH:
        global_raw = _load_raw_yaml(config_path)
        local_path = find_local_config()
        local_raw = _load_raw_yaml(local_path) if local_path else {}
    else:
        local_raw = _load_raw_yaml(config_path)
        global_raw = _load_raw_yaml(DEFAULT_CONFIG_PATH)
        local_path = config_path

    _resolve_connections(global_raw, local_raw, DEFAULT_CONFIG_PATH, local_path, DebugLog())

    # Validate non-connection fields on the target file. Connections are
    # already validated above; stripping them avoids re-triggering the
    # cross-field invariant on partial local overrides.
    target_raw = _load_raw_yaml(config_path)
    no_connections = {k: v for k, v in target_raw.items() if k != "connections"}
    YtctlConfig(**no_connections)


def _set_nested_path(raw: dict[str, Any], segments: list[str], value: Any) -> None:
    """Walk *raw* by *segments*, creating intermediate dicts, and set the leaf."""
    current: dict[str, Any] = raw
    for seg in segments[:-1]:
        existing = current.get(seg)
        if not isinstance(existing, dict):
            existing = {}
            current[seg] = existing
        current = existing
    current[segments[-1]] = value


def _retention_from_raw(raw: dict[str, Any], default: int) -> int:
    """Read ``history.retention`` from a raw config dict, or fall back to *default*."""
    history = raw.get("history")
    if not isinstance(history, dict):
        return default
    retention = history.get("retention")
    try:
        return int(retention) if retention is not None else default
    except (ValueError, TypeError):
        return default


def _rollback_file(path: Path, original_text: str | None) -> None:
    """Restore *path* to its pre-write state after a failed update."""
    from kd.history import atomic_write_text

    if original_text is None:
        try:
            path.unlink()
        except FileNotFoundError:
            pass
    else:
        atomic_write_text(path, original_text)


# ---------------------------------------------------------------------------
# Hierarchical resolution
# ---------------------------------------------------------------------------


def _load_raw_yaml(path: Path) -> dict[str, Any]:
    """Load raw YAML dict from a config file. Returns empty dict if missing."""
    if not path.exists():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML in {path}: {e}") from e
    return data or {}


def resolve_config(
    *,
    flags: dict[str, str] | None = None,
    start_path: Path | None = None,
    debug_log: DebugLog | None = None,
) -> ResolvedConfig:
    """Resolve config from all sources in priority order.

    Per flat key: CLI flag → local config → global config → default.
    Connections are merged from global then local (local overrides by name).
    The active connection's ``default_project`` is injected into entries.
    """
    flags = flags or {}
    d = debug_log or DebugLog()

    # Load raw YAML dicts (not Pydantic) to distinguish explicit values from defaults
    local_path = find_local_config(start_path)
    local_raw = _load_raw_yaml(local_path) if local_path else {}
    global_raw = _load_raw_yaml(DEFAULT_CONFIG_PATH)

    d.trace("config", f"local config path: {local_path or 'not found'}")
    d.trace("config", f"global config path: {DEFAULT_CONFIG_PATH}")

    # Flat keys that have built-in defaults
    _DEFAULTS: dict[str, str] = {
        "output": "table",
        "limit": "50",
        "debug": "false",
    }

    # Only resolve flat keys (not structured sections or connections)
    _FLAT_KEYS = set(FLAT_KEYS)

    entries: dict[str, ResolvedValue] = {}

    for key in _FLAT_KEYS:
        # 1. CLI flag
        if key in flags and flags[key]:
            d.trace("config", f"flag: {key} -> {flags[key]}")
            origin = _FLAG_ORIGINS.get(key, f"--{key}")
            entries[key] = ResolvedValue(flags[key], ConfigSource.FLAG, origin)
            _log_resolved(d, key, flags[key], ConfigSource.FLAG)
            continue
        d.trace("config", f"flag: {key} -> not set")

        # 2. Environment variable
        env_var = _ENV_MAP.get(key)
        if env_var:
            env_val = os.environ.get(env_var)
            if env_val:
                d.trace("config", f"env: {env_var} -> {env_val}")
                entries[key] = ResolvedValue(env_val, ConfigSource.ENV, env_var)
                _log_resolved(d, key, env_val, ConfigSource.ENV)
                continue
            d.trace("config", f"env: {env_var} -> not set")
        else:
            d.trace("config", f"env: (no env var for {key})")

        # 3. Local config (raw YAML — only keys explicitly in the file)
        if key in local_raw and local_raw[key] is not None:
            val = str(local_raw[key])
            d.trace("config", f"local: {local_path} -> {key}={val}")
            entries[key] = ResolvedValue(val, ConfigSource.LOCAL, str(local_path))
            _log_resolved(d, key, val, ConfigSource.LOCAL)
            continue
        d.trace("config", f"local: {key} -> not set")

        # 4. Global config (raw YAML)
        if key in global_raw and global_raw[key] is not None:
            val = str(global_raw[key])
            d.trace("config", f"global: {DEFAULT_CONFIG_PATH} -> {key}={val}")
            entries[key] = ResolvedValue(val, ConfigSource.GLOBAL, str(DEFAULT_CONFIG_PATH))
            _log_resolved(d, key, val, ConfigSource.GLOBAL)
            continue
        d.trace("config", f"global: {key} -> not set")

        # 5. Built-in default
        if key in _DEFAULTS:
            default_val = _DEFAULTS[key]
            d.trace("config", f"default: {key}={default_val}")
            entries[key] = ResolvedValue(default_val, ConfigSource.DEFAULT, "default")
            _log_resolved(d, key, default_val, ConfigSource.DEFAULT)

    # -- Connections: merge global then local (local overrides by name) ------
    connections, connection_origins = _resolve_connections(
        global_raw, local_raw, DEFAULT_CONFIG_PATH, local_path, d
    )
    default_conn_name = entries.get("default_connection")
    default_conn_name_str = default_conn_name.value if default_conn_name else None

    # Inject default_project from active connection into entries
    conn_defaults: dict[str, dict[str, Any]] = {}
    conn_flat: dict[str, Any] = {}
    if connections and default_conn_name_str:
        active = connections.get(default_conn_name_str)
        if active:
            if active.default_project:
                entries["default_project"] = ResolvedValue(
                    active.default_project,
                    ConfigSource.GLOBAL,
                    f"connection:{default_conn_name_str}",
                )
            conn_defaults = active.defaults
            if active.output is not None:
                conn_flat["output"] = active.output
            if active.limit is not None:
                conn_flat["limit"] = active.limit
    elif connections and not default_conn_name_str and len(connections) == 1:
        # Single connection — use it implicitly
        single_name = next(iter(connections))
        default_conn_name_str = single_name
        active = connections[single_name]
        if active.default_project:
            entries["default_project"] = ResolvedValue(
                active.default_project, ConfigSource.GLOBAL, f"connection:{single_name}"
            )
        conn_defaults = active.defaults
        if active.output is not None:
            conn_flat["output"] = active.output
        if active.limit is not None:
            conn_flat["limit"] = active.limit

    # Extract structured sections from raw YAML
    local_defaults = _extract_defaults(local_raw)
    global_defaults = _extract_defaults(global_raw)
    local_projects = _extract_projects(local_raw)
    global_projects = _extract_projects(global_raw)
    local_aliases = _extract_aliases(local_raw)
    global_aliases = _extract_aliases(global_raw)

    # Extract flat-only keys for command option resolution (levels 5/9)
    local_flat = {k: v for k, v in local_raw.items() if k in _FLAT_KEYS and v is not None}
    global_flat = {k: v for k, v in global_raw.items() if k in _FLAT_KEYS and v is not None}

    if local_defaults or local_projects:
        d.debug(
            "config",
            f"local structured: {len(local_defaults)} defaults, {len(local_projects)} projects",
        )
    if global_defaults or global_projects:
        d.debug(
            "config",
            f"global structured: {len(global_defaults)} defaults, {len(global_projects)} projects",
        )
    if local_aliases or global_aliases:
        d.debug(
            "config",
            f"aliases: {len(local_aliases)} local, {len(global_aliases)} global",
        )
    if connections:
        d.debug("config", f"connections: {len(connections)} ({', '.join(connections)})")

    return ResolvedConfig(
        entries,
        local_defaults=local_defaults,
        global_defaults=global_defaults,
        local_projects=local_projects,
        global_projects=global_projects,
        local_flat=local_flat,
        global_flat=global_flat,
        local_aliases=local_aliases,
        global_aliases=global_aliases,
        connections=connections,
        connection_origins=connection_origins,
        default_connection_name=default_conn_name_str,
        connection_defaults=conn_defaults,
        connection_flat=conn_flat,
    )


def _log_resolved(d: DebugLog, key: str, value: str, source: ConfigSource) -> None:
    """Log the winning resolution for a config key."""
    if key == "default_connection":
        d.info("config", f"{key}={value} ({source})")
    else:
        d.debug("config", f"{key}={value} ({source})")


_DEEP_MERGE_KEYS = frozenset({"defaults", "compatibility"})


def _connection_blocks(raw: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Extract ``connections:`` dict-of-dict, dropping non-dict entries."""
    conns = raw.get("connections")
    if not isinstance(conns, dict):
        return {}
    return {str(name): data for name, data in conns.items() if isinstance(data, dict)}


def _compose_connection(
    name: str,
    global_data: dict[str, Any] | None,
    local_data: dict[str, Any] | None,
    global_path: Path,
    local_path: Path | None,
    d: DebugLog,
) -> tuple[dict[str, Any], dict[str, ConnectionKeyOrigin]]:
    """Per-key deep merge of one connection across global + local.

    Top-level scalar/dict keys: local replaces global. ``defaults`` and
    ``compatibility`` recurse one level and merge by inner key. Returns the
    merged dict and a per-top-level-key origin map (source + path).
    """
    global_data = global_data or {}
    local_data = local_data or {}
    global_origin = ConnectionKeyOrigin(source="global", path=str(global_path))
    local_origin = ConnectionKeyOrigin(source="local", path=str(local_path)) if local_path else None

    merged: dict[str, Any] = {}
    key_origins: dict[str, ConnectionKeyOrigin] = {}

    for key, g_val in global_data.items():
        merged[str(key)] = g_val
        key_origins[str(key)] = global_origin

    for key, l_val in local_data.items():
        key = str(key)
        if (
            key in _DEEP_MERGE_KEYS
            and isinstance(l_val, dict)
            and isinstance(merged.get(key), dict)
        ):
            inner: dict[str, Any] = dict(merged[key])
            any_local = False
            for sub_key, sub_val in l_val.items():
                if (
                    key == "defaults"
                    and isinstance(sub_val, dict)
                    and isinstance(inner.get(str(sub_key)), dict)
                ):
                    combined = dict(inner[str(sub_key)])
                    combined.update(sub_val)
                    inner[str(sub_key)] = combined
                else:
                    inner[str(sub_key)] = sub_val
                any_local = True
            merged[key] = inner
            if any_local and local_origin is not None:
                key_origins[key] = local_origin
        else:
            merged[key] = l_val
            if local_origin is not None:
                key_origins[key] = local_origin

    if d:
        sources = sorted({o.source for o in key_origins.values()})
        d.trace("config", f"connection '{name}' composed from {', '.join(sources) or 'none'}")
    return merged, key_origins


def _resolve_connections(
    global_raw: dict[str, Any],
    local_raw: dict[str, Any],
    global_path: Path,
    local_path: Path | None,
    d: DebugLog,
) -> tuple[dict[str, ConnectionConfig], dict[str, ConnectionOrigin]]:
    """Deep-merge connections from global + local, validate each once.

    Per-key merge: scalars replace, ``defaults``/``compatibility`` recurse
    one level. Returns validated connections and per-connection origins
    (with per-key attribution inside) so ``config list`` can report mixed
    provenance for a single connection.
    """
    global_conns = _connection_blocks(global_raw)
    local_conns = _connection_blocks(local_raw)
    if not global_conns and not local_conns:
        return {}, {}

    names = list(dict.fromkeys([*global_conns, *local_conns]))

    result: dict[str, ConnectionConfig] = {}
    origins: dict[str, ConnectionOrigin] = {}
    for name in names:
        merged, key_origins = _compose_connection(
            name,
            global_conns.get(name),
            local_conns.get(name),
            global_path,
            local_path,
            d,
        )
        has_local = any(o.source == "local" for o in key_origins.values())
        primary_path = str(local_path) if has_local and local_path is not None else str(global_path)
        primary_source = "local" if has_local else "global"
        origins[name] = ConnectionOrigin(source=primary_source, path=primary_path, keys=key_origins)

        try:
            result[name] = ConnectionConfig(**merged)
        except (TypeError, ValueError) as e:
            where = f" in {primary_path}"
            if isinstance(e, ValidationError):
                d.trace("config", f"connection '{name}' validation error: {e!r}")
                details = _format_validation_errors(e, key_origins)
            else:
                details = str(e)
            message = f"Invalid connection '{name}'{where}: {details}"
            raise ConfigError(message, suggestion=_CONNECTION_HINT) from e

    return result, origins


def _format_validation_errors(
    err: ValidationError,
    key_origins: dict[str, ConnectionKeyOrigin] | None = None,
) -> str:
    """Render a Pydantic ``ValidationError`` as a user-facing summary.

    Drops the ``input_value=...`` dump and the ``errors.pydantic.dev`` URL,
    keeping only ``<dotted-loc>: <msg>`` parts joined by ``; ``.

    When *key_origins* is supplied, each locus is annotated with the config
    file that contributed its top-level key, e.g.
    ``default_project: Input should be a string (from /path/.kd/config.yaml)``.
    Origin tracking is per-top-level-key because deep merges on
    ``defaults`` and ``compatibility`` replace the whole sub-dict from
    whichever tier wrote last.
    """
    parts: list[str] = []
    for item in err.errors():
        loc_parts = item.get("loc", ())
        loc = ".".join(str(p) for p in loc_parts)
        msg = item.get("msg", "")
        origin_suffix = ""
        if key_origins and loc_parts:
            top_key = str(loc_parts[0])
            if top_key in key_origins:
                origin_suffix = f" (from {key_origins[top_key].path})"
        parts.append(f"{loc}: {msg}{origin_suffix}" if loc else msg)
    return "; ".join(parts) if parts else str(err)


def _extract_defaults(raw: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Extract the ``defaults:`` section from raw YAML, validating structure."""
    defaults = raw.get("defaults")
    if not isinstance(defaults, dict):
        return {}
    result: dict[str, dict[str, Any]] = {}
    for cmd_key, opts in defaults.items():
        if isinstance(opts, dict):
            result[str(cmd_key)] = {str(k): v for k, v in opts.items()}
    return result


def _extract_projects(raw: dict[str, Any]) -> dict[str, Any]:
    """Extract the ``projects:`` section from raw YAML, validating structure."""
    projects = raw.get("projects")
    if not isinstance(projects, dict):
        return {}
    result: dict[str, Any] = {}
    for proj_key, proj_data in projects.items():
        if isinstance(proj_data, dict):
            result[str(proj_key)] = proj_data
    return result


def _extract_aliases(raw: dict[str, Any]) -> dict[str, str]:
    """Extract the ``aliases:`` section from raw YAML, validating structure."""
    aliases = raw.get("aliases")
    if not isinstance(aliases, dict):
        return {}
    result: dict[str, str] = {}
    for name, command in aliases.items():
        if isinstance(command, str):
            result[str(name)] = command
    return result


# Keys that exist as both flat config keys and command/output options.
# These participate in levels 5/7 of the command option resolution chain.
_FLAT_OPTION_KEYS = {"limit", "output"}


def resolve_command_defaults(
    command_key: str,
    project: str | None,
    raw_options: dict[str, Any],
    config: ResolvedConfig,
    declarations: list[OptionDeclaration],
    *,
    debug_log: DebugLog | None = None,
) -> dict[str, Any]:
    """Resolve command option defaults from the config hierarchy.

    Returns a dict of option values for options **not** present in
    *raw_options* (CLI flags always win — level 1).

    Resolution per option (first non-None wins):

    1. CLI flag — skipped (present in *raw_options*)
    2. Env var — N/A for command options
    3. Project command default — ``projects.<proj>.defaults.<cmd>.<opt>``
    4. Local command default — ``defaults.<cmd>.<opt>`` in local config
    5. Local flat key — for ``limit``/``output`` only
    6. Connection command default — ``connections.<name>.defaults.<cmd>.<opt>``
    7. Connection flat key — for ``limit``/``output`` only
    8. Global command default — ``defaults.<cmd>.<opt>`` in global config
    9. Global flat key — for ``limit``/``output`` only
    10. Built-in default — from ``OptionDeclaration.default``
    """
    d = debug_log or DebugLog()
    resolved: dict[str, Any] = {}

    for decl in declarations:
        opt = decl.name

        # Level 1: CLI flag already set — skip
        if opt in raw_options:
            continue

        value = _resolve_single_option(opt, command_key, project, config, d)
        if value is not None:
            resolved[opt] = value

    return resolved


@dataclass(frozen=True)
class LayerState:
    """State of a single layer in the 10-layer command-option resolution chain.

    ``value`` is ``None`` when the layer does not contribute — either because
    the option is not configured there, or because the layer never applies to
    this option class (e.g. flat layers 5/7/9 for non-flat options). ``status``
    disambiguates those cases and marks which layer wins vs. is shadowed.
    """

    layer: int
    source: str
    origin: str | None
    value: Any
    status: str  # "winning" | "shadowed" | "not set" | "n/a"


def walk_option_layers(
    opt: str,
    command_key: str,
    project: str | None,
    config: ResolvedConfig,
    *,
    cli_value: Any = None,
    builtin_default: Any = None,
    local_config_path: str | None = None,
    global_config_path: str | None = None,
) -> list[LayerState]:
    """Walk the 10-layer command-option resolution chain for *opt*.

    Returns one :class:`LayerState` per layer in priority order (1..10). The
    first layer with a non-``None`` value has ``status="winning"``; subsequent
    non-``None`` layers have ``status="shadowed"``. Layers that never apply
    (flat layers 5/7/9 for options outside ``_FLAT_OPTION_KEYS``, layer 2 for
    command options, layer 6/7 when no active connection) have ``status="n/a"``.
    Populated-eligible layers with no value are ``"not set"``.
    """
    if local_config_path is None:
        _lp = find_local_config()
        local_config_path = str(_lp) if _lp else None
    if global_config_path is None:
        global_config_path = str(DEFAULT_CONFIG_PATH)

    conn_name = config.default_connection_name
    conn_origin = config.connection_origins.get(conn_name) if conn_name else None
    is_flat = opt in _FLAT_OPTION_KEYS

    def _conn_key_origin(key: str) -> str | None:
        if conn_origin is None:
            return None
        ko = conn_origin.keys.get(key)
        return ko.path if ko is not None else conn_origin.path

    # (layer, source, origin, value, applicable) in priority order.
    raw: list[tuple[int, str, str | None, Any, bool]] = []

    # Layer 1 — CLI flag
    raw.append((1, f"cli.{opt}", None, cli_value, True))

    # Layer 2 — env var (always n/a for command options)
    raw.append((2, "env", None, None, False))

    # Layer 3 — project command default (local-first then global, same layer)
    proj_val: Any = None
    proj_source = f"project.defaults.{command_key}"
    proj_origin: str | None = None
    if project:
        v = _project_command_default(project, command_key, opt, config.local_projects)
        if v is not None:
            proj_val = v
            proj_source = f"project({project}).local.{command_key}"
            proj_origin = local_config_path
        else:
            v = _project_command_default(project, command_key, opt, config.global_projects)
            if v is not None:
                proj_val = v
                proj_source = f"project({project}).global.{command_key}"
                proj_origin = global_config_path
    raw.append((3, proj_source, proj_origin, proj_val, project is not None))

    # Layer 4 — local command default
    raw.append(
        (
            4,
            f"local.defaults.{command_key}",
            local_config_path,
            config.local_defaults.get(command_key, {}).get(opt),
            True,
        )
    )

    # Layer 5 — local flat key (limit/output only)
    raw.append(
        (
            5,
            "local.flat",
            local_config_path,
            config.local_flat.get(opt) if is_flat else None,
            is_flat,
        )
    )

    # Layer 6 — connection command default
    raw.append(
        (
            6,
            f"connection.defaults.{command_key}",
            _conn_key_origin("defaults"),
            config.connection_defaults.get(command_key, {}).get(opt),
            conn_name is not None,
        )
    )

    # Layer 7 — connection flat key (limit/output only)
    raw.append(
        (
            7,
            "connection.flat",
            _conn_key_origin(opt),
            config.connection_flat.get(opt) if is_flat else None,
            is_flat and conn_name is not None,
        )
    )

    # Layer 8 — global command default
    raw.append(
        (
            8,
            f"global.defaults.{command_key}",
            global_config_path,
            config.global_defaults.get(command_key, {}).get(opt),
            True,
        )
    )

    # Layer 9 — global flat key (limit/output only)
    raw.append(
        (
            9,
            "global.flat",
            global_config_path,
            config.global_flat.get(opt) if is_flat else None,
            is_flat,
        )
    )

    # Layer 10 — built-in default
    raw.append((10, "built-in", None, builtin_default, builtin_default is not None))

    # Stamp statuses: first non-None wins, later non-Nones are shadowed.
    winner_found = False
    out: list[LayerState] = []
    for layer, source, origin, value, applicable in raw:
        if value is None:
            status = "not set" if applicable else "n/a"
        elif not winner_found:
            status = "winning"
            winner_found = True
        else:
            status = "shadowed"
        out.append(
            LayerState(layer=layer, source=source, origin=origin, value=value, status=status)
        )
    return out


def _resolve_single_option(
    opt: str,
    command_key: str,
    project: str | None,
    config: ResolvedConfig,
    d: DebugLog,
) -> Any:
    """Walk levels 3–9 for a single option. Returns None if no config value found."""
    for state in walk_option_layers(opt, command_key, project, config):
        if state.status == "winning":
            d.debug("config", f"option {opt}: {state.source} -> {state.value}")
            return state.value
    return None


def _project_command_default(
    project: str,
    command_key: str,
    opt: str,
    projects_raw: dict[str, Any],
) -> Any:
    """Look up a project command default from a raw projects dict."""
    proj_data = projects_raw.get(project)
    if not isinstance(proj_data, dict):
        return None
    defaults = proj_data.get("defaults")
    if not isinstance(defaults, dict):
        return None
    cmd_defaults = defaults.get(command_key)
    if not isinstance(cmd_defaults, dict):
        return None
    return cmd_defaults.get(opt)


# ---------------------------------------------------------------------------
# Shadow detection — post-write check against the 10-layer chain
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ShadowWarning:
    """Result of :func:`detect_shadow` — a written value is shadowed.

    ``written`` names the layer and source the write landed at; ``winning``
    names the higher-priority layer whose value continues to resolve.
    ``option`` is ``"<command_key>.<option>"``. ``hint_path`` suggests a
    dotted path that would actually override the winning layer, or None
    when no such path exists below the winning tier.
    """

    written: dict[str, Any]
    winning: dict[str, Any]
    option: str
    hint_path: str | None


def detect_shadow(
    path: str,
    tier: str,
    rc: ResolvedConfig,
    *,
    default_lookup: Callable[[str, str], Any] | None = None,
) -> ShadowWarning | None:
    """Return a :class:`ShadowWarning` when *path* (just written in *tier*)
    is shadowed by a higher-priority layer in *rc*, else ``None``.

    Returns ``None`` when the path is not part of the command-option chain,
    when the write landed at the winning layer, or when the post-write walker
    reports no higher-priority layer with a value. Paths that don't map to a
    specific ``<command_key>.<option>`` target — flat top-level writes and
    connection-level flat writes — are cross-command by nature and are not
    flagged here.

    *rc* must be a freshly-resolved config (post-write); callers are
    responsible for reloading. *default_lookup*, when provided, is called
    as ``default_lookup(command_key, option_name)`` to obtain the layer-10
    built-in default (typically the caller reaches into the CLI option
    registry); ``None`` or a lookup returning ``None`` means layer 10 stays
    unpopulated, which is fine for shadow comparison.
    """
    classified = _classify_set_path(path, tier, rc.default_connection_name)
    if classified is None:
        return None
    written_layer, command_key, option_name = classified

    builtin_default = default_lookup(command_key, option_name) if default_lookup else None

    states = walk_option_layers(
        option_name,
        command_key,
        rc.default_project,
        rc,
        builtin_default=builtin_default,
    )
    winner = next((s for s in states if s.status == "winning"), None)
    if winner is None or winner.layer >= written_layer:
        return None  # write is active (equal) or nothing set (impossible post-write)

    written = next((s for s in states if s.layer == written_layer), None)
    hint_path = _shadow_hint_path(winner, command_key, option_name, rc)
    return ShadowWarning(
        written={
            "layer": written_layer,
            "value": written.value if written else None,
            "source": written.source if written else "",
        },
        winning={
            "layer": winner.layer,
            "value": winner.value,
            "source": winner.source,
            "origin": winner.origin,
        },
        option=f"{command_key}.{option_name}",
        hint_path=hint_path,
    )


def _classify_set_path(
    path: str, tier: str, active_connection: str | None
) -> tuple[int, str, str] | None:
    """Map a written config path to a chain layer + (command_key, option)."""
    segs = path.split(".")
    # defaults.<cmd>.<opt> — layer 4 (local) / 8 (global)
    if len(segs) == 3 and segs[0] == "defaults":
        layer = 4 if tier == "local" else 8
        return layer, segs[1], segs[2]
    # connections.<name>.defaults.<cmd>.<opt> — layer 6 when <name> is active
    if (
        len(segs) == 5
        and segs[0] == "connections"
        and segs[2] == "defaults"
        and active_connection is not None
        and segs[1] == active_connection
    ):
        return 6, segs[3], segs[4]
    return None


def _shadow_hint_path(
    winner: LayerState, command_key: str, option_name: str, rc: ResolvedConfig
) -> str | None:
    """Suggest a path that would actually override the winning layer, if any.

    For a winning connection-flat value, suggest
    ``connections.<name>.defaults.<cmd>.<opt>`` which sits at layer 6 —
    one step above layer 7 and scoped per-command.
    """
    if winner.layer == 7 and rc.default_connection_name is not None:
        return f"connections.{rc.default_connection_name}.defaults.{command_key}.{option_name}"
    return None


# ---------------------------------------------------------------------------
# Project init
# ---------------------------------------------------------------------------


class InitResult(NamedTuple):
    """Result of init_project_config()."""

    created: Path
    gitignore_action: str  # "added", "already_ignored", "no_git", "created", "not_applicable"


def _find_git_root(start: Path) -> Path | None:
    """Walk up from *start* looking for a ``.git`` directory."""
    current = start.resolve()
    while True:
        if (current / ".git").is_dir():
            return current
        parent = current.parent
        if parent == current:
            return None
        current = parent


_GITIGNORE_PATTERNS = {".kd/", ".kd", "/.kd/", "/.kd"}


def _manage_gitignore(directory: Path) -> str:
    """Ensure ``.kd/`` is in ``.gitignore``. Returns action taken."""
    git_root = _find_git_root(directory)
    if git_root is None:
        return "no_git"

    gitignore = git_root / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        lines = {line.strip() for line in content.splitlines()}
        if lines & _GITIGNORE_PATTERNS:
            return "already_ignored"
        # Append with a trailing newline if file doesn't end with one
        sep = "" if content.endswith("\n") else "\n"
        gitignore.write_text(f"{content}{sep}\n# kd local config\n.kd/\n", encoding="utf-8")
        return "added"

    gitignore.write_text("# kd local config\n.kd/\n", encoding="utf-8")
    return "created"


def init_project_config(
    directory: Path | None = None,
    url: str | None = None,
    global_tier: bool = False,
) -> InitResult:
    """Scaffold a kd config file.

    Local tier (default): writes ``.kd/config.yaml`` in *directory* (or cwd)
    and manages ``.gitignore`` for the nearest git root.

    Global tier (``global_tier=True``): writes ``~/.config/kd/config.yaml``
    (``DEFAULT_CONFIG_PATH``), creating the parent directory if needed.
    ``.gitignore`` is not applicable. *directory* must be None at the global
    tier; passing it is a caller bug.

    Raises ConfigError if the target file already exists.
    """
    import importlib.resources

    if global_tier:
        if directory is not None:
            raise ValueError("directory is not accepted when global_tier=True")
        config_path = DEFAULT_CONFIG_PATH
        config_dir = config_path.parent
    else:
        target_dir = (directory or Path.cwd()).resolve()
        config_dir = target_dir / ".kd"
        config_path = config_dir / "config.yaml"

    if config_path.exists():
        raise ConfigError(f"Config already exists at {config_path}")

    # Load template from package resources
    template = (
        importlib.resources.files("kd.resources")
        .joinpath("config-template.yaml")
        .read_text(encoding="utf-8")
    )

    # Pre-fill URL: uncomment connection block and fill URL
    if url:
        template = template.replace("# default_connection: main", "default_connection: main")
        template = template.replace(
            "# connections:\n"
            "#   main:\n"
            "#     provider: youtrack\n"
            "#     url: https://your-instance.youtrack.cloud\n"
            "#     # token_cmd: gopass show -o path/to/token\n"
            "#     token_env: KD_TOKEN",
            "connections:\n"
            "  main:\n"
            "    provider: youtrack\n"
            f"    url: {url}\n"
            "    # token_cmd: gopass show -o path/to/token\n"
            "    token_env: KD_TOKEN",
        )

    config_dir.mkdir(parents=True, exist_ok=True)
    config_path.write_text(template, encoding="utf-8")

    if global_tier:
        gitignore_action = "not_applicable"
    else:
        gitignore_action = _manage_gitignore(target_dir)

    return InitResult(created=config_path, gitignore_action=gitignore_action)
