"""Cache namespace: ``/cache`` — disposable upstream-mirror cache."""

from __future__ import annotations

import dataclasses
from typing import Any

from kd.cache import (
    CONNECTIONS_DIRNAME,
    DEFAULT_SEARCH_LIMIT,
    DEFAULT_STALE_AFTER_DAYS,
    SEARCHABLE_KINDS,
    cache_dir,
    clear_all_scopes,
    clear_cache,
    compute_cache_status,
    refresh_article,
    refresh_epic_with_children,
    refresh_issue,
    refresh_milestone,
    refresh_primer_scope,
    refresh_query,
    search_cache,
    slug_for_connection_name,
)
from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    project_option,
)
from kd.connection import resolve_active_connection_name
from kd.exceptions import ConfigError, ValidationError


class CacheClearCommand(Command):
    """Wipe a cache scope (active connection by default) and report what was removed."""

    def __init__(self) -> None:
        super().__init__(
            "clear",
            "Wipe the active connection's cache scope (or --all to wipe everything).",
            requires_config=True,
            usage="kd /cache clear [--all]",
            long_description=(
                "Default: removes the active connection's scope at "
                ".kd/cache/connections/<slug>/, then removes the scope "
                "directory itself. The active scope is selected by the "
                "global -c NAME flag (or default_connection); switch "
                "scope with `kd -c NAME /cache clear`. --all wipes the "
                "entire .kd/cache/ tree, sweeping every scope plus any "
                "legacy flat directories (articles/issues/queries) "
                "left over from older workspaces. Per KDCLI-A-18 §Cache "
                "contract the cache is rehydratable upstream-mirror "
                "data — deletion is always safe and there is no "
                "--confirm flag (confirms exist for upstream-destructive "
                "operations only). This command is local-only and does "
                "not resolve a tracker token; clearing works even if the "
                "active connection's token_env is unset or token_cmd "
                "fails. Best-effort: per-path failures collect into the "
                "structured `errors` field rather than aborting the sweep."
            ),
            examples=[
                "kd /cache clear",
                "kd -c kb /cache clear",
                "kd /cache clear --all",
                "kd /cache clear -o yaml",
            ],
            see_also=["/cache refresh", "/primer show"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Wipe the entire .kd/cache/ tree (every scope plus "
                    "any legacy flat directories). Default scope is "
                    "the active connection only."
                ),
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if bool(options.command.get("all")):
            report = clear_all_scopes()
            return dataclasses.asdict(report)
        config = self.config
        assert config is not None  # requires_config=True
        connection_name = resolve_active_connection_name(
            config.connections, config.default_connection_name
        )
        scope_root = cache_dir() / CONNECTIONS_DIRNAME / slug_for_connection_name(connection_name)
        report = clear_cache(cache_root=scope_root)
        return dataclasses.asdict(report)


class CacheRefreshCommand(Command):
    """Hydrate ``.kd/cache/`` from upstream — the explicit refresh verb.

    Mutually-exclusive selector group: exactly one of
    ``--primer-scope`` / ``--issue ID`` / ``--article ID`` /
    ``--query NAME`` / ``--milestone VALUE`` / ``--epic ID
    --include-children`` per call.
    """

    def __init__(self) -> None:
        super().__init__(
            "refresh",
            (
                "Hydrate .kd/cache/ from upstream (--primer-scope, "
                "--issue, --article, --query, --milestone, or "
                "--epic --include-children)."
            ),
            requires_client=True,
            usage=(
                "kd /cache refresh (--primer-scope | --issue ID | "
                "--article ID | --query NAME [--limit N] | "
                "--milestone VALUE [--project KEY] [--limit N] | "
                "--epic ID --include-children)"
            ),
            long_description=(
                "Per KDCLI-A-18 §Cache contract refresh is the explicit "
                "hydration verb — the cache is rehydratable upstream-"
                "mirror data and no command silently reads through it. "
                "Selectors are mutually exclusive: --primer-scope "
                "hydrates primer-pinned articles, primer-pinned issues "
                "(via the same single-issue projection at "
                ".kd/cache/issues/<id>.yaml; comments not projected), "
                "plus the primer-scope tag-entities query; --issue ID "
                "hydrates a single issue "
                "into .kd/cache/issues/<id>.yaml; --article ID hydrates "
                "a single article; --query NAME runs a saved query and "
                "writes the issue list to .kd/cache/queries/<slug>.yaml "
                "(slug derived from the saved-query name); --milestone "
                "VALUE runs a milestone-scoped query and writes the "
                "issue list to .kd/cache/queries/milestone-<slug>.yaml "
                "with the actual upstream field name recorded in "
                "source.field_name (e.g. 'Milestone' in KDCLI vs. "
                "'Stage' in a project that aliased 'milestone' → "
                "'Stage' via projects.<KEY>.field_aliases.milestone); "
                "--epic ID --include-children hydrates the epic plus "
                "every direct Subtask-OUTWARD child, writing one "
                ".kd/cache/issues/<ID>.yaml per issue and one manifest "
                "at .kd/cache/queries/epic-<slug>-children.yaml that "
                "records the link relationship and per-child cache "
                "status. --include-comments (only valid with --issue) "
                "projects issue comments into the cache file — the "
                "upstream rich-fetch always reads comments, so the "
                "flag toggles cache projection only, not wire cost. "
                "--limit N (valid with --query or --milestone, default "
                "50) caps the rows fetched; the cached file flags "
                "source.truncated when the cap was reached. --project "
                "KEY is only valid with --milestone (defaults from the "
                "active connection's default_project) — saved queries "
                "already encode their own project filter, so --query "
                "does not accept --project. Per-entity APIError "
                "subclasses isolate to the structured report so a "
                "single 404 or 403 does not abort the run; AuthError "
                "and ConfigError propagate."
            ),
            examples=[
                "kd /cache refresh --primer-scope",
                "kd /cache refresh --issue KDCLI-105",
                "kd /cache refresh --issue KDCLI-105 --include-comments",
                "kd /cache refresh --article KDCLI-A-18",
                'kd /cache refresh --query "All Bugs"',
                'kd /cache refresh --query "All Bugs" --limit 100',
                "kd /cache refresh --milestone M008",
                "kd /cache refresh --milestone M008 -p KDCLI",
                "kd /cache refresh --milestone M008 -p KDCLI --limit 100",
                "kd /cache refresh --epic KDCLI-30 --include-children",
                "kd /cache refresh --primer-scope -o yaml",
            ],
            see_also=[
                "/cache clear",
                "/primer show",
                "/tag entities",
                "/query issues",
                "/project/field list",
            ],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="primer-scope",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Hydrate primer-pinned articles and the primer-scope "
                    "tag-entities query into .kd/cache/."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="issue",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text="Hydrate a single issue (e.g. KDCLI-42).",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="article",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text="Hydrate a single article (e.g. KDCLI-A-18).",
            )
        )
        self.register_option(
            OptionDeclaration(
                name="include-comments",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Project issue comments into the cache file. Only "
                    "valid with --issue. Toggles the cache projection "
                    "only — the upstream rich-fetch already reads "
                    "comments."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="query",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    "Hydrate a saved query result into "
                    ".kd/cache/queries/<slug>.yaml (slug derived from "
                    "the saved-query name)."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="limit",
                layer=OptionLayer.COMMAND,
                type=int,
                default=None,
                help_text=(
                    "Cap the rows fetched by --query or --milestone "
                    "(default 50). The cached file flags "
                    "source.truncated when the cap was reached. Only "
                    "valid with --query or --milestone."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="milestone",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    "Hydrate a milestone-scoped query into "
                    ".kd/cache/queries/milestone-<slug>.yaml. The "
                    "actual upstream field name (Milestone, Stage, ...) "
                    "is discovered from the project's field roster via "
                    "projects.<KEY>.field_aliases.milestone (defaults "
                    "to 'Milestone') and recorded in source.field_name."
                ),
            )
        )
        self.register_option(
            project_option(
                help_text=(
                    "Project key for --milestone (defaults to "
                    "default_project from the active connection). Only "
                    "valid with --milestone."
                )
            )
        )
        self.register_option(
            OptionDeclaration(
                name="epic",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    "Hydrate an epic plus its direct Subtask-OUTWARD "
                    "children. Requires --include-children. Writes "
                    "the epic and each child to .kd/cache/issues/ and "
                    "a manifest to .kd/cache/queries/epic-<slug>-"
                    "children.yaml."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="include-children",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text=(
                    "Hydrate the children of --epic ID. Required pair "
                    "with --epic; only valid with --epic."
                ),
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        primer_scope = bool(options.command.get("primer-scope"))
        issue_id = options.command.get("issue")
        article_id = options.command.get("article")
        query_name = options.command.get("query")
        milestone_value = options.command.get("milestone")
        epic_id = options.command.get("epic")
        include_children = bool(options.command.get("include-children"))
        project_key = options.command.get("project")
        include_comments = bool(options.command.get("include-comments"))
        limit_raw = options.command.get("limit")
        limit = limit_raw if limit_raw is not None else 50

        if epic_id and not include_children:
            raise ValidationError(
                "--epic ID requires --include-children. For single-issue hydration use --issue ID."
            )
        if include_children and not epic_id:
            raise ValidationError("--include-children is only valid with --epic ID.")

        passed: list[str] = []
        if primer_scope:
            passed.append("--primer-scope")
        if issue_id:
            passed.append("--issue")
        if article_id:
            passed.append("--article")
        if query_name:
            passed.append("--query")
        if milestone_value:
            passed.append("--milestone")
        if epic_id and include_children:
            passed.append("--epic --include-children")

        if not passed:
            raise ValidationError(
                "kd /cache refresh requires a selector. Use "
                "--primer-scope, --issue ID, --article ID, --query "
                "NAME, --milestone VALUE, or --epic ID "
                "--include-children."
            )
        if len(passed) > 1:
            raise ValidationError(
                "kd /cache refresh accepts exactly one selector at a "
                f"time. Got: {', '.join(passed)}."
            )
        if include_comments and not issue_id:
            raise ValidationError("--include-comments is only valid with --issue.")
        if milestone_value and not project_key:
            raise ValidationError(
                "--milestone VALUE requires a project. Pass --project KEY or "
                "configure default_project on the active connection (kd "
                "/system/config which shows the resolved value)."
            )
        # Note: --project and --limit are silently ignored for selectors that
        # do not consume them. Both are subject to dispatcher defaulting from
        # the active connection (default_project, flat-key limit) — declaring
        # them as options applies those defaults to every selector, not just
        # --milestone / --query. Rejecting "--project without --milestone" or
        # "--limit without --query|--milestone" would break the other
        # selectors in any workspace that sets default_project or a
        # connection-level limit. Only the consumers (refresh_milestone,
        # refresh_query) read these values; refresh_issue / refresh_article /
        # refresh_primer_scope / refresh_epic_with_children never see them.
        # Saved queries (--query) keep their own project filter regardless
        # of the defaulted value (refresh_query never reads it), preserving
        # the "--query does not rewrite query semantics" guarantee.

        connection = client.connection
        if primer_scope:
            report = refresh_primer_scope(client, connection=connection)
            return dataclasses.asdict(report)
        if issue_id:
            issue_report = refresh_issue(
                client, issue_id, connection=connection, include_comments=include_comments
            )
            return {"issues": dataclasses.asdict(issue_report)}
        if article_id:
            article_report = refresh_article(client, article_id, connection=connection)
            return {"articles": dataclasses.asdict(article_report)}
        if query_name:
            query_report = refresh_query(client, query_name, connection=connection, limit=limit)
            return {"queries": dataclasses.asdict(query_report)}
        if epic_id and include_children:
            epic_report = refresh_epic_with_children(client, epic_id, connection=connection)
            return {"epic": dataclasses.asdict(epic_report)}
        assert milestone_value and project_key  # enforced above
        milestone_report = refresh_milestone(
            client,
            milestone_value,
            connection=connection,
            project_key=project_key,
            limit=limit,
        )
        return {"queries": dataclasses.asdict(milestone_report)}


class CacheStatusCommand(Command):
    """Report what is in ``.kd/cache/`` — counts, latest fetch, staleness."""

    def __init__(self) -> None:
        super().__init__(
            "status",
            "Read-only health surface for .kd/cache/ (counts, latest fetch, staleness).",
            requires_config=True,
            usage="kd /cache status [--scope NAME] [--stale-after-days N]",
            long_description=(
                "Walks every connection-scoped directory under "
                ".kd/cache/connections/ and reports per-scope counts of "
                "cached articles / issues / queries, the latest and "
                "oldest fetch timestamps, and how many entries are "
                "older than the staleness threshold. Default scope is "
                "the entire workspace cache (every scope plus legacy "
                "flat content under unscoped); --scope NAME focuses "
                "on a single scope, matched against each manifest's "
                "connection field (slug fallback only when unique). "
                "--stale-after-days N overrides the threshold for one "
                "call; the workspace default is "
                "defaults.cache_status.stale_after_days, falling back to "
                f"{DEFAULT_STALE_AFTER_DAYS} days. The active scope is "
                "flagged following the global -c NAME selector or "
                "default_connection. Status is local-only and does not "
                "resolve a tracker token; it works even when the active "
                "connection's token_env is unset. Per-file parse "
                "failures (banner / sidecar) collect into the scope's "
                "warnings list rather than aborting the sweep; a "
                "schema-invalid scope.yaml is the only manifest-related "
                "failure that exits non-zero."
            ),
            examples=[
                "kd /cache status",
                "kd /cache status -o yaml",
                "kd /cache status --scope support",
                "kd /cache status --stale-after-days 0",
                "kd /cache status --scope kb --stale-after-days 14",
            ],
            see_also=["/cache refresh", "/cache clear", "/primer show"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="scope",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    "Focus on one scope. Matched against each manifest's "
                    "connection field; slug fallback only when unique. "
                    "Unknown name lists every known connection."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="stale-after-days",
                layer=OptionLayer.COMMAND,
                type=int,
                default=DEFAULT_STALE_AFTER_DAYS,
                help_text=(
                    "Threshold in days for the per-scope stale_count and "
                    "the cache_stale warning. 0 flags every cached entry "
                    "as stale (inclusive boundary)."
                ),
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        focus_scope = options.command.get("scope")
        stale_after_days_raw = options.command.get("stale-after-days")
        stale_after_days = (
            int(stale_after_days_raw)
            if stale_after_days_raw is not None
            else DEFAULT_STALE_AFTER_DAYS
        )
        if stale_after_days < 0:
            raise ValidationError(f"--stale-after-days must be >= 0, got {stale_after_days}.")

        config = self.config
        assert config is not None  # requires_config=True
        try:
            active_connection_name: str | None = resolve_active_connection_name(
                config.connections, config.default_connection_name
            )
        except ConfigError:
            # Bare config (no connections) or no default_connection set —
            # the scan still runs; active_scope reports as null.
            active_connection_name = None

        report = compute_cache_status(
            stale_after_days=stale_after_days,
            active_connection_name=active_connection_name,
            focus_scope=focus_scope,
        )
        return dataclasses.asdict(report)


class CacheSearchCommand(Command):
    """Read-only substring search across hydrated cache content."""

    def __init__(self) -> None:
        super().__init__(
            "search",
            "Local case-insensitive substring search across hydrated cache content.",
            requires_config=True,
            usage="kd /cache search TEXT [--scope NAME] [--kind article|issue|query] [--limit N]",
            long_description=(
                "Walks every connection-scoped cache directory under "
                ".kd/cache/connections/ and reports files whose payload "
                "fields contain TEXT (case-insensitive substring match). "
                "Default scope is the entire workspace cache (every "
                "scope plus legacy flat content under unscoped); "
                "--scope NAME focuses one scope, matched against each "
                "manifest's connection field with slug fallback. The "
                "global -c NAME selector is informational and does NOT "
                "narrow the search — same workspace-wide walk as "
                "/cache status. --kind restricts to one kind. --limit "
                "caps total matches (default 200) and short-circuits "
                "the walk; meta.truncated flags the cap was hit. "
                "Searched fields per kind: article (summary, body); "
                "issue (summary, description, comment.text); query "
                "(saved-query/milestone source.query_name + "
                "source.query_text + issue.summary; primer-scope "
                "result.summary + result.id_readable; epic-children "
                "source.epic_summary + child.summary). The first "
                "matching field per file sets matched_field and "
                "supplies the snippet (deterministic precedence). "
                "Search is local-only and does not resolve a tracker "
                "token; it works even when the active connection's "
                "token_env is unset. Per-file parse failures (banner / "
                "payload) collect into meta.warnings rather than "
                "aborting the sweep."
            ),
            examples=[
                'kd /cache search "doctrine"',
                'kd /cache search "milestone" --scope support',
                'kd /cache search "doctrine" --kind article',
                'kd /cache search "the" --limit 50',
                'kd /cache search "M008" -o yaml',
            ],
            see_also=["/cache status", "/cache refresh"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="scope",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    "Focus on one scope. Matched against each manifest's "
                    "connection field; slug fallback only when unique. "
                    "Unknown name lists every known connection."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="kind",
                layer=OptionLayer.COMMAND,
                type=str,
                default=None,
                help_text=(
                    f"Restrict to one kind. One of {{{', '.join(SEARCHABLE_KINDS)}}}. "
                    "Default searches every kind."
                ),
            )
        )
        self.register_option(
            OptionDeclaration(
                name="limit",
                layer=OptionLayer.COMMAND,
                type=int,
                default=DEFAULT_SEARCH_LIMIT,
                help_text=(
                    f"Cap total matches (default {DEFAULT_SEARCH_LIMIT}). "
                    "When reached, the walk short-circuits and "
                    "meta.truncated is true."
                ),
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError(
                'kd /cache search requires a TEXT argument. Example: kd /cache search "doctrine"'
            )
        if len(args) > 1:
            raise ValidationError(
                f"kd /cache search expects exactly one TEXT argument, got {len(args)}. "
                'Quote multi-word searches: kd /cache search "two words".'
            )
        text = args[0]
        if not text:
            raise ValidationError("Search query must be a non-empty string.")

        scope_filter = options.command.get("scope")
        kind_filter = options.command.get("kind")
        limit_raw = options.command.get("limit")
        limit = int(limit_raw) if limit_raw is not None else DEFAULT_SEARCH_LIMIT

        report = search_cache(
            text,
            scope_filter=scope_filter,
            kind_filter=kind_filter,
            limit=limit,
        )
        return dataclasses.asdict(report)


def create_cache_namespace() -> Namespace:
    """Build the ``/cache`` namespace tree."""
    namespace = Namespace(
        "cache",
        "Disposable upstream-mirror cache (.kd/cache/).",
        path="cache",
    )
    namespace.register_command("clear", CacheClearCommand())
    namespace.register_command("refresh", CacheRefreshCommand())
    namespace.register_command("status", CacheStatusCommand())
    namespace.register_command("search", CacheSearchCommand())
    return namespace
