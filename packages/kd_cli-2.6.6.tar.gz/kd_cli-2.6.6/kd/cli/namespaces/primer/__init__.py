"""Primer namespace: /primer, /primer/note, /primer/tag, /primer/issue, /primer/article.

Project-local knowledge capsule for LLM consumers.  Stores conventions,
key article/issue references, and do's/don'ts in ``.kd/primer.yaml``.
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    project_option,
)
from kd.cli.input import resolve_text_input
from kd.cli.output import emit_warning
from kd.exceptions import KdError, NotFoundError, ValidationError
from kd.primer import (
    add_article,
    add_issue,
    add_note,
    add_tag,
    clear_articles,
    clear_issues,
    clear_notes,
    clear_tags,
    init_primer,
    load_primer,
    parse_refs,
    remove_article,
    remove_issue,
    remove_note,
    remove_tag,
    update_article,
    update_issue,
    update_note,
    update_tag,
)


def _refs_for(text: str | None) -> list[dict[str, Any]]:
    """Run :func:`parse_refs` and return plain dicts for command output."""
    return [ref.model_dump() for ref in parse_refs(text)]


def _assert_workspace_project(command: Command, options: ResolvedOptions) -> None:
    """Enforce the ``--project`` assertion on workspace-scoped primer commands.

    The primer lives in ``.kd/primer.yaml`` and has no project dimension:
    every workspace owns exactly one primer, and any entity (tag, article,
    issue) from any project the token can see can be pinned from that
    workspace.  ``--project`` is therefore accepted as an **assertion** of
    which workspace's primer the caller thinks it's editing, not an
    override that selects a different primer file.  Matches
    ``default_project`` → silent no-op; mismatches → raise so an agent
    running from the wrong workspace fails loud.
    """
    asserted = options.command.get("project")
    if not asserted:
        return
    # Read commands (/primer show, /primer/*/list) declare the flag for
    # symmetry with write commands but do not declare requires_config=True
    # so they work in a fresh workspace before `kd init`.  When no config
    # is loaded the assertion silently passes — the flag is accepted, the
    # user sees no "unknown option" rejection (KDCLI-84 symptom).
    if command._resolved_config is None:
        return
    current = command.config.default_project
    if current and asserted != current:
        raise ValidationError(
            f"Primer is workspace-scoped (one .kd/primer.yaml per workspace). "
            f"--project={asserted} does not match this workspace's "
            f"default_project={current}. Primer pinning does not restrict "
            f"which project an entity can belong to — you can pin {asserted} "
            f"entities from this workspace.  To edit a *different* workspace's "
            f"primer, run from that workspace."
        )


# ---------------------------------------------------------------------------
# /primer show (root default)
# ---------------------------------------------------------------------------


class PrimerShowCommand(Command):
    """Show the full project primer."""

    def __init__(self) -> None:
        super().__init__(
            "show",
            "Show project primer",
            usage="kd /primer show",
            long_description="Displays the full project primer in canonical "
            "order — notes, pinned tags, pinned issues, pinned articles. "
            "Returns an empty primer if none exists yet. JSON / YAML output "
            "carries a derived ``refs: [...]`` array on every prose-bearing "
            "row (parsed inline ``tag:``, ``issue:``, ``article:`` markers); "
            "table / md keep the markers inline in the prose itself.",
            examples=[
                "kd /primer show",
                "kd /primer show --output json",
            ],
            see_also=[
                "/primer/note list",
                "/primer/tag list",
                "/primer/issue list",
                "/primer/article list",
            ],
        )
        self.display_hint = "primer_show"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this shows"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        # Canonical section order — notes (prose narrative) first, tags
        # (cross-entity discovery lens) next, issues (active execution
        # anchors), articles (deep references) last.  Refs are derived
        # render-time metadata; they appear on every prose-bearing row of
        # the read surfaces only.  Mutation envelopes never carry refs.
        return {
            "notes": [
                {"#": i + 1, "note": n, "refs": _refs_for(n)} for i, n in enumerate(data.notes)
            ],
            "tags": [
                {"name": t.name, "summary": t.summary or "", "refs": _refs_for(t.summary)}
                for t in data.tags
            ],
            "issues": [
                {"id": i.id, "summary": i.summary or "", "refs": _refs_for(i.summary)}
                for i in data.issues
            ],
            "articles": [
                {"id": a.id, "summary": a.summary or "", "refs": _refs_for(a.summary)}
                for a in data.articles
            ],
        }


# ---------------------------------------------------------------------------
# /primer init
# ---------------------------------------------------------------------------


class PrimerInitCommand(Command):
    """Scaffold ``.kd/primer.yaml`` from a packaged template."""

    def __init__(self) -> None:
        super().__init__(
            "init",
            "Scaffold .kd/primer.yaml from a template",
            usage="kd /primer init [TEMPLATE]",
            long_description=(
                "Creates .kd/primer.yaml from a packaged template.  Default "
                "template is `hitl` — a human-in-the-loop session workflow "
                "scaffold with placeholder prose in the scope-guard, session-"
                "workflow, and canonical-reference slots.  The template is "
                "copied through unchanged so its banner and example-shape "
                "comments survive.  Refuses if a primer already exists; "
                "there is no --force (deletion is explicit operator work)."
            ),
            examples=[
                "kd /primer init",
                "kd /primer init hitl",
            ],
            see_also=["/primer show", "/primer/note list"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        template = args[0] if args else "hitl"
        created = init_primer(template)
        return {
            "ok": True,
            "action": "init",
            "template": template,
            "created": str(created),
            "next": "kd /primer show -o yaml",
        }


# ---------------------------------------------------------------------------
# /primer/note
# ---------------------------------------------------------------------------


class PrimerNoteListCommand(Command):
    """List all primer notes."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List primer notes",
            usage="kd /primer/note list",
            long_description="Lists all notes in the project primer with their 1-based index.",
            examples=["kd /primer/note list"],
            see_also=["/primer/note add", "/primer/note remove"],
        )
        self.display_hint = "primer_list"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [
            {"index": i + 1, "note": note, "refs": _refs_for(note)}
            for i, note in enumerate(data.notes)
        ]


class PrimerNoteAddCommand(Command):
    """Add a note to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Add a primer note",
            requires_config=True,
            usage="kd /primer/note add TEXT",
            long_description="Appends a note to the project primer.  TEXT can be inline, "
            "@file to read from a file, or - to read from stdin.",
            examples=[
                'kd /primer/note add "Sprint field is called Board"',
                "kd /primer/note add @conventions.txt",
            ],
            see_also=["/primer/note list", "/primer/note remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/note add TEXT")
        text = resolve_text_input(" ".join(args))
        if not text:
            raise ValidationError("Note text cannot be empty")
        index = add_note(text)
        return {"ok": True, "action": "add", "index": index, "note": text}


class PrimerNoteRemoveCommand(Command):
    """Remove a note by index, or all notes with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Remove a primer note by index or all notes",
            requires_config=True,
            usage="kd /primer/note remove INDEX | --all",
            long_description="Removes the note at the given 1-based index, or all notes "
            "if --all is passed.  Use '/primer/note list' to see current indices.",
            examples=[
                "kd /primer/note remove 2",
                "kd /primer/note remove --all",
            ],
            see_also=["/primer/note list", "/primer/note add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all notes",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_notes()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/note remove INDEX | --all")
        try:
            index = int(args[0])
        except ValueError:
            raise ValidationError(f"INDEX must be a number, got: {args[0]}") from None
        removed = remove_note(index)
        return {"ok": True, "action": "remove", "index": index, "note": removed}


class PrimerNoteUpdateCommand(Command):
    """Replace a note by index."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Replace a primer note by index",
            requires_config=True,
            usage="kd /primer/note update INDEX TEXT",
            long_description="Replaces the note at the given 1-based index with new text.  "
            "TEXT can be inline, @file to read from a file, or - to read from stdin.  "
            "Use '/primer/note list' to see current indices.",
            examples=[
                'kd /primer/note update 1 "Updated convention"',
                "kd /primer/note update 2 @updated.txt",
            ],
            see_also=["/primer/note list", "/primer/note remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/note update INDEX TEXT")
        try:
            index = int(args[0])
        except ValueError:
            raise ValidationError(f"INDEX must be a number, got: {args[0]}") from None
        if len(args) < 2:
            raise ValidationError("Usage: kd /primer/note update INDEX TEXT")
        text = resolve_text_input(" ".join(args[1:]))
        if not text:
            raise ValidationError("Note text cannot be empty")
        old = update_note(index, text)
        return {"ok": True, "action": "update", "index": index, "old": old, "new": text}


# ---------------------------------------------------------------------------
# /primer/article
# ---------------------------------------------------------------------------


class PrimerArticleListCommand(Command):
    """List pinned articles."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List pinned articles",
            usage="kd /primer/article list",
            long_description="Lists all articles pinned in the project primer.",
            examples=["kd /primer/article list"],
            see_also=["/primer/article add", "/primer/article remove"],
        )
        self.display_hint = "primer_list"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [
            {"id": a.id, "summary": a.summary or "", "refs": _refs_for(a.summary)}
            for a in data.articles
        ]


class PrimerArticleAddCommand(Command):
    """Pin an article to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Pin an article to the primer",
            requires_config=True,
            usage="kd /primer/article add ARTICLE_ID [--summary S]",
            long_description="Adds a YouTrack article reference to the project primer.  "
            "Use --summary to store a description alongside the ID.",
            examples=[
                "kd /primer/article add FB-A-42",
                'kd /primer/article add FB-A-42 --summary "Architecture Overview"',
            ],
            see_also=["/primer/article list", "/primer/article remove"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="Description to store with the article reference",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/article add ARTICLE_ID")
        article_id = args[0]
        summary = options.command.get("summary")
        article = add_article(article_id, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "add", "id": article.id}
        if article.summary:
            result["summary"] = article.summary
        return result


class PrimerArticleUpdateCommand(Command):
    """Update the summary on a pinned article."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Update the summary on a pinned article",
            requires_config=True,
            usage="kd /primer/article update ARTICLE_ID --summary S",
            long_description=(
                "Replaces the summary on an existing pinned article in place "
                "(entry position preserved).  Local-only edit; no upstream "
                "validation is performed (article add and update are both "
                "local-only — kd does not check the article ID against "
                'upstream).  Pass --summary "" to clear an existing summary.  '
                "To re-key an article, use `remove` then `add` (identity "
                "changes are rare and may need cross-reference updates)."
            ),
            examples=[
                'kd /primer/article update FB-A-42 --summary "Updated overview"',
                'kd /primer/article update FB-A-42 --summary ""',
            ],
            see_also=[
                "/primer/article list",
                "/primer/article add",
                "/primer/article remove",
            ],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="New summary (pass empty string to clear)",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/article update ARTICLE_ID --summary S")
        article_id = args[0]
        if "summary" not in options.command:
            raise ValidationError(
                'kd /primer/article update requires --summary (pass --summary "" to clear)'
            )
        raw = options.command.get("summary")
        summary = raw if raw else None
        article = update_article(article_id, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "update", "id": article.id}
        if article.summary:
            result["summary"] = article.summary
        return result


class PrimerArticleRemoveCommand(Command):
    """Unpin an article by ID, or all articles with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Unpin an article or all articles",
            requires_config=True,
            usage="kd /primer/article remove ARTICLE_ID | --all",
            long_description="Removes the article with the given ID from the primer, "
            "or all pinned articles if --all is passed.",
            examples=[
                "kd /primer/article remove FB-A-42",
                "kd /primer/article remove --all",
            ],
            see_also=["/primer/article list", "/primer/article add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all pinned articles",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_articles()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/article remove ARTICLE_ID | --all")
        removed = remove_article(args[0])
        return {"ok": True, "action": "remove", "id": removed.id}


# ---------------------------------------------------------------------------
# /primer/tag
# ---------------------------------------------------------------------------


class PrimerTagListCommand(Command):
    """List pinned tags."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List pinned tags",
            usage="kd /primer/tag list",
            long_description="Lists all tags pinned in the project primer.  Pinned "
            "tags act as the OR scope for `kd /tag entities --primer-scope`.",
            examples=["kd /primer/tag list"],
            see_also=["/primer/tag add", "/primer/tag remove", "/tag entities"],
        )
        self.display_hint = "primer_list"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [
            {"name": t.name, "summary": t.summary or "", "refs": _refs_for(t.summary)}
            for t in data.tags
        ]


class PrimerTagAddCommand(Command):
    """Pin a tag to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Pin a tag to the primer",
            requires_config=True,
            requires_client=True,
            usage="kd /primer/tag add TAG_NAME [--summary S]",
            long_description="Adds a tag to the project primer.  Upstream existence "
            "is validated via the tag namespace: tags not found upstream are still "
            "written but return a `tag_not_found` warning — this supports declaring "
            "tag intent before the tag is created.  A failed validation call "
            "(network / auth / timeout) writes the entry with a "
            "`tag_validation_skipped` warning so a local primer edit is not "
            "silently blocked by an unreachable server.",
            examples=[
                "kd /primer/tag add kind:incident",
                'kd /primer/tag add kind:incident --summary "Active incidents"',
            ],
            see_also=["/primer/tag list", "/primer/tag remove", "/tag entities"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="Description to store with the tag reference",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/tag add TAG_NAME")
        name = args[0]
        summary = options.command.get("summary")

        warning: dict[str, Any] | None = None
        try:
            client.tags.get(name)
        except NotFoundError as exc:
            warning = emit_warning(
                "tag_not_found",
                f"Tag '{name}' not found upstream — pinning anyway (declare-intent).",
                name=name,
                detail=str(exc),
            )
        except KdError as exc:
            warning = emit_warning(
                "tag_validation_skipped",
                f"Could not validate tag '{name}' upstream ({type(exc).__name__}) — "
                "pinning the entry; verify the name when the upstream is reachable.",
                name=name,
                error_code=type(exc).__name__,
                detail=str(exc),
            )

        tag = add_tag(name, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "add", "name": tag.name}
        if tag.summary:
            result["summary"] = tag.summary
        if warning is not None:
            result["warnings"] = [warning]
        return result


class PrimerTagUpdateCommand(Command):
    """Update the summary on a pinned tag."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Update the summary on a pinned tag",
            requires_config=True,
            usage="kd /primer/tag update TAG_NAME --summary S",
            long_description=(
                "Replaces the summary on an existing pinned tag in place "
                "(entry position preserved).  Local-only edit — no upstream "
                "call, no re-validation; the original `add` already validated.  "
                'Pass --summary "" to clear an existing summary.  To rename a '
                "tag, use `remove` then `add` (identity changes are rare and "
                "may need cross-reference updates)."
            ),
            examples=[
                'kd /primer/tag update kind:incident --summary "Active investigations"',
                'kd /primer/tag update kind:incident --summary ""',
            ],
            see_also=["/primer/tag list", "/primer/tag add", "/primer/tag remove"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="New summary (pass empty string to clear)",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/tag update TAG_NAME --summary S")
        name = args[0]
        if "summary" not in options.command:
            raise ValidationError(
                'kd /primer/tag update requires --summary (pass --summary "" to clear)'
            )
        raw = options.command.get("summary")
        summary = raw if raw else None
        tag = update_tag(name, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "update", "name": tag.name}
        if tag.summary:
            result["summary"] = tag.summary
        return result


class PrimerTagRemoveCommand(Command):
    """Unpin a tag by name, or all tags with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Unpin a tag or all tags",
            requires_config=True,
            usage="kd /primer/tag remove TAG_NAME | --all",
            long_description="Removes the tag with the given name from the primer, "
            "or all pinned tags if --all is passed.  Local-only edit — no upstream "
            "call.",
            examples=[
                "kd /primer/tag remove kind:incident",
                "kd /primer/tag remove --all",
            ],
            see_also=["/primer/tag list", "/primer/tag add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all pinned tags",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_tags()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/tag remove TAG_NAME | --all")
        removed = remove_tag(args[0])
        return {"ok": True, "action": "remove", "name": removed.name}


# ---------------------------------------------------------------------------
# /primer/issue
# ---------------------------------------------------------------------------


class PrimerIssueListCommand(Command):
    """List pinned issues."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List pinned issues",
            usage="kd /primer/issue list",
            long_description="Lists all issues pinned in the project primer.",
            examples=["kd /primer/issue list"],
            see_also=["/primer/issue add", "/primer/issue remove"],
        )
        self.display_hint = "primer_list"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [
            {"id": i.id, "summary": i.summary or "", "refs": _refs_for(i.summary)}
            for i in data.issues
        ]


class PrimerIssueAddCommand(Command):
    """Pin an issue to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Pin an issue to the primer",
            requires_config=True,
            requires_client=True,
            usage="kd /primer/issue add ISSUE_ID [--summary S]",
            long_description="Adds a YouTrack issue reference to the project primer.  "
            "Upstream existence is validated via the issues namespace: issues not "
            "found upstream are still written but return an `issue_not_found` "
            "warning — this supports declaring intent before the issue is created.  "
            "A failed validation call (network / auth / timeout) writes the entry "
            "with an `issue_validation_skipped` warning so a local primer edit is "
            "not silently blocked by an unreachable server.",
            examples=[
                "kd /primer/issue add KDCLI-175",
                'kd /primer/issue add KDCLI-175 --summary "Pinned issues + refs"',
            ],
            see_also=["/primer/issue list", "/primer/issue remove"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="Description to store with the issue reference",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/issue add ISSUE_ID")
        issue_id = args[0]
        summary = options.command.get("summary")

        warning: dict[str, Any] | None = None
        try:
            client.issues.get(issue_id, detail="brief")
        except NotFoundError as exc:
            warning = emit_warning(
                "issue_not_found",
                f"Issue '{issue_id}' not found upstream — pinning anyway (declare-intent).",
                id=issue_id,
                detail=str(exc),
            )
        except KdError as exc:
            warning = emit_warning(
                "issue_validation_skipped",
                f"Could not validate issue '{issue_id}' upstream ({type(exc).__name__}) — "
                "pinning the entry; verify the ID when the upstream is reachable.",
                id=issue_id,
                error_code=type(exc).__name__,
                detail=str(exc),
            )

        issue = add_issue(issue_id, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "add", "id": issue.id}
        if issue.summary:
            result["summary"] = issue.summary
        if warning is not None:
            result["warnings"] = [warning]
        return result


class PrimerIssueUpdateCommand(Command):
    """Update the summary on a pinned issue."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Update the summary on a pinned issue",
            requires_config=True,
            usage="kd /primer/issue update ISSUE_ID --summary S",
            long_description=(
                "Replaces the summary on an existing pinned issue in place "
                "(entry position preserved).  Local-only edit — no upstream "
                "call, no re-validation; the original `add` already validated.  "
                'Pass --summary "" to clear an existing summary.  To re-key an '
                "issue, use `remove` then `add` (identity changes are rare and "
                "may need cross-reference updates)."
            ),
            examples=[
                'kd /primer/issue update KDCLI-175 --summary "Pinned issues + refs"',
                'kd /primer/issue update KDCLI-175 --summary ""',
            ],
            see_also=["/primer/issue list", "/primer/issue add", "/primer/issue remove"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="New summary (pass empty string to clear)",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/issue update ISSUE_ID --summary S")
        issue_id = args[0]
        if "summary" not in options.command:
            raise ValidationError(
                'kd /primer/issue update requires --summary (pass --summary "" to clear)'
            )
        raw = options.command.get("summary")
        summary = raw if raw else None
        issue = update_issue(issue_id, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "update", "id": issue.id}
        if issue.summary:
            result["summary"] = issue.summary
        return result


class PrimerIssueRemoveCommand(Command):
    """Unpin an issue by ID, or all issues with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Unpin an issue or all issues",
            requires_config=True,
            usage="kd /primer/issue remove ISSUE_ID | --all",
            long_description="Removes the issue with the given ID from the primer, "
            "or all pinned issues if --all is passed.  Local-only edit — no "
            "upstream call.",
            examples=[
                "kd /primer/issue remove KDCLI-175",
                "kd /primer/issue remove --all",
            ],
            see_also=["/primer/issue list", "/primer/issue add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all pinned issues",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_issues()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/issue remove ISSUE_ID | --all")
        removed = remove_issue(args[0])
        return {"ok": True, "action": "remove", "id": removed.id}


# ---------------------------------------------------------------------------
# Namespace factory
# ---------------------------------------------------------------------------


def create_primer_namespace() -> Namespace:
    """Build the /primer namespace with /primer/note, /primer/tag,
    /primer/issue, and /primer/article sub-namespaces."""
    ns = Namespace(
        "primer",
        "Project primer — local knowledge for LLM consumers",
        path="primer",
    )
    ns.register_command("show", PrimerShowCommand())
    ns.register_command("init", PrimerInitCommand())

    # /primer/note
    note_ns = Namespace("note", "Primer notes and conventions", path="primer/note")
    note_ns.register_command("list", PrimerNoteListCommand())
    note_ns.register_command("add", PrimerNoteAddCommand())
    note_ns.register_command("remove", PrimerNoteRemoveCommand())
    note_ns.register_command("update", PrimerNoteUpdateCommand())
    ns.register_sub_namespace(note_ns)

    # /primer/tag
    tag_ns = Namespace(
        "tag",
        "Pinned tag references",
        path="primer/tag",
    )
    tag_ns.register_command("list", PrimerTagListCommand())
    tag_ns.register_command("add", PrimerTagAddCommand())
    tag_ns.register_command("remove", PrimerTagRemoveCommand())
    tag_ns.register_command("update", PrimerTagUpdateCommand())
    ns.register_sub_namespace(tag_ns)

    # /primer/issue
    issue_ns = Namespace(
        "issue",
        "Pinned issue references",
        path="primer/issue",
    )
    issue_ns.register_command("list", PrimerIssueListCommand())
    issue_ns.register_command("add", PrimerIssueAddCommand())
    issue_ns.register_command("remove", PrimerIssueRemoveCommand())
    issue_ns.register_command("update", PrimerIssueUpdateCommand())
    ns.register_sub_namespace(issue_ns)

    # /primer/article
    article_ns = Namespace(
        "article",
        "Pinned article references",
        path="primer/article",
    )
    article_ns.register_command("list", PrimerArticleListCommand())
    article_ns.register_command("add", PrimerArticleAddCommand())
    article_ns.register_command("remove", PrimerArticleRemoveCommand())
    article_ns.register_command("update", PrimerArticleUpdateCommand())
    ns.register_sub_namespace(article_ns)

    return ns
