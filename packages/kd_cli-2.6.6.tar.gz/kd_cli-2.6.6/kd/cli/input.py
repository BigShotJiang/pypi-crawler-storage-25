"""Shared text input resolution.

Provides a single function for resolving text values that may reference
a file (``@path``), stdin (``-`` or ``@-``). Used by any CLI command
that accepts free-text input such as descriptions or comments.
"""

from __future__ import annotations

import sys
from pathlib import Path

from kd.exceptions import ValidationError


def resolve_text_input(value: str | None) -> str | None:
    """Resolve a text value that may reference a file or stdin.

    - ``None`` or empty string: returned as-is
    - ``@path``: reads file at *path* and returns its contents
    - ``@-``: reads all of stdin (raises on empty input)
    - ``-``: reads all of stdin and returns it
    - anything else: returned as-is (plain text)
    """
    if not value:
        return value
    if value == "-":
        try:
            return sys.stdin.read()
        except UnicodeDecodeError as e:
            raise ValidationError(
                f"Stdin input could not be decoded as UTF-8: {e.reason}",
                suggestion="Ensure the upstream shell pipes UTF-8 bytes "
                "(heredoc, pipe, or redirected file).",
            ) from e
    if value == "@-":
        try:
            text = sys.stdin.read()
        except UnicodeDecodeError as e:
            raise ValidationError(
                f"Stdin input could not be decoded as UTF-8: {e.reason}",
                suggestion="Ensure the upstream shell pipes UTF-8 bytes "
                "(heredoc, pipe, or redirected file).",
            ) from e
        if not text:
            raise ValidationError("No input received from stdin")
        return text
    if value.startswith("@"):
        file_path = Path(value[1:])
        if not file_path.is_file():
            raise ValidationError(f"File not found: {file_path}")
        try:
            text = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError as e:
            raise ValidationError(
                f"File {file_path} could not be decoded as UTF-8: {e.reason}",
                suggestion="Save the file as UTF-8 (without a BOM) and retry.",
            ) from e
        if not text:
            raise ValidationError(f"File is empty: {file_path}")
        return text
    return value
