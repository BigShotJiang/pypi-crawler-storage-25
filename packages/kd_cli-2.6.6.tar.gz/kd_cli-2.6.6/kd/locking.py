"""Advisory file locking for read-modify-write transactions on kd-managed files.

Provides :func:`file_transaction` — a context manager that acquires an
exclusive advisory lock on a sidecar lockfile (``<path>.lock``) for the
duration of a load → mutate → save cycle.  Concurrent kd processes that
enter the same transaction serialize rather than clobber each other.

Backed by :mod:`filelock`, which abstracts over ``fcntl.flock`` on POSIX
and ``msvcrt.locking`` on Windows.  Behavior is identical on both:

* **Sidecar lockfile, not the target file.**  Atomic writes elsewhere in
  kd use ``tempfile.mkstemp`` + ``os.replace``, which changes the target
  file's inode on every write.  Holding an advisory lock on the target
  inode would not protect a second writer that opens the freshly-replaced
  file.  Locking a separate sidecar that nobody rewrites keeps the lock
  stable across atomic replaces of the data file.

* **Sidecar lifecycle is filelock-managed.**  filelock owns sidecar
  creation and removal: it unlinks the sidecar on release on both POSIX
  and Windows.  The kd contract is the *behavior* of the lock —
  concurrent enterers serialize — not the on-disk artifact.  Existence
  of the sidecar is not evidence of an active lock; absence is not
  evidence of release.  Removing the sidecar under contention is a
  two-inode race and is not part of any recovery recipe.
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock, Timeout

from kd.exceptions import ConfigError

LOCK_SUFFIX = ".lock"


@contextmanager
def file_transaction(path: Path, *, timeout: float = 30.0) -> Generator[None, None, None]:
    """Hold an exclusive advisory lock on ``<path>.lock`` for the ``with`` body.

    Acquisition blocks up to *timeout* seconds.  On timeout, raises
    :class:`ConfigError` naming the contested file.  filelock unlinks
    the sidecar on release; the kd contract is the lock behavior, not
    the on-disk artifact.
    """
    lock_path = path.with_name(path.name + LOCK_SUFFIX)
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    lock = FileLock(str(lock_path))
    try:
        lock.acquire(timeout=timeout)
    except Timeout:
        raise ConfigError(
            f"Another kd process is writing to {path}; retry in a moment.",
            suggestion=(
                "If the wait persists, verify no other kd process is mutating "
                "this file and check parent-directory permissions. Do not "
                "delete the sidecar lockfile while another process may be "
                "running."
            ),
        ) from None
    try:
        yield
    finally:
        lock.release()
