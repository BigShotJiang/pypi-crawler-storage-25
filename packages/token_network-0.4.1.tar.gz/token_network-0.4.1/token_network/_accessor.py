"""Attribute-based access to network and token config: network.bitcoin, network.bsc.usdt."""

from __future__ import annotations

from typing import Any

from ._loader import load_all
from ._models import NetworkConfigDto, NetworkDataDto, TokenDto, TokenOnNetworkDto


class TokenNetworkError(Exception):
    """Raised when a network or token is unknown or invalid."""


def _to_token_on_network(data: dict[str, Any]) -> TokenOnNetworkDto:
    """Build TokenOnNetwork Pydantic model from internal dict."""
    return TokenOnNetworkDto(
        network=NetworkConfigDto(**(data.get("network") or {})),
        token=TokenDto(**(data.get("token") or {})),
        contract_address=data.get("contract_address"),
        decimal=data.get("decimal") or data.get("decimals", 0),
        native=bool(data.get("native", False)),
        type=str(data.get("type", "TOKEN")),
    )


class _NetworkNode:
    """
    Represents one network. Supports .config, .tokens (list of TokenOnNetwork),
    .decimal, .confirmation_number, .__dict__(), and .<token_symbol> (e.g. .usdt).
    """

    __slots__ = ("_net_key", "_network_tokens", "_token_on_network")

    def __init__(
        self,
        net_key: str,
        network_tokens: dict[str, dict[str, Any]],
        token_on_network: dict[tuple[str, str], dict[str, Any]],
    ) -> None:
        self._net_key = net_key
        self._network_tokens = network_tokens
        self._token_on_network = token_on_network

    def _ensure_network(self) -> dict[str, Any]:
        if self._net_key not in self._network_tokens:
            raise TokenNetworkError(f"Unknown network: {self._net_key!r}")
        return self._network_tokens[self._net_key]

    @property
    def config(self) -> NetworkConfigDto:
        """Network config for this network (Pydantic model)."""
        return NetworkConfigDto(**self._ensure_network()["config"])

    @property
    def decimal(self) -> int:
        """Base token decimal for this network (e.g. 8 for Bitcoin, 18 for Ethereum)."""
        return self.config.base_token_decimal

    @property
    def confirmation_number(self) -> int:
        """Required number of confirmations for this network."""
        return self.config.confirmation_number

    @property
    def tokens(self) -> list[TokenOnNetworkDto]:
        """List of token objects on this network (Pydantic TokenOnNetwork models)."""
        data = self._ensure_network()
        return [
            _to_token_on_network(self._token_on_network[(self._net_key, t["token"])])
            for t in data["tokens"]
            if (self._net_key, t["token"]) in self._token_on_network
        ]

    def _tokens_raw(self) -> list[dict[str, Any]]:
        """Raw list of token bindings (dicts). Used for to_dict and backward compatibility."""
        return list(self._ensure_network()["tokens"])

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        token_sym = name.upper()
        key = (self._net_key, token_sym)
        if key not in self._token_on_network:
            raise TokenNetworkError(
                f"Token {token_sym!r} is not defined on network {self._net_key!r}. "
                f"Available tokens: {[t['token'] for t in self._tokens_raw()]}"
            )
        return _to_token_on_network(self._token_on_network[key])

    def __dict__(self) -> dict[str, Any]:
        """Return all network data: config plus tokens (each as full dict)."""
        return {
            "config": self.config.model_dump(),
            "tokens": [t.model_dump() for t in self.tokens],
        }

    def to_dict(self) -> dict[str, Any]:
        """Return full network data: config and tokens (same as __dict__() for compatibility)."""
        return {"config": self.config.model_dump(), "tokens": self._tokens_raw()}


class NetworkAccessor:
    """
    Attribute-based access to token network config.
    - network.bitcoin  -> network node (use .config, .tokens, or .to_dict() for full config)
    - network.bsc.usdt -> dict with network config, token info, contract_address, decimal, native
    """

    __slots__ = ("_network_tokens", "_token_on_network", "_tokens")

    def __init__(self, testnet: bool = False) -> None:
        self._network_tokens, self._token_on_network, _, self._tokens = load_all(testnet=testnet)

    def get_networks(self) -> list[str]:
        """Return list of all network ids (e.g. ['bitcoin', 'bsc', 'ethereum', ...])."""
        return sorted(self._network_tokens.keys())

    def get_tokens(self) -> list[str]:
        """Return list of all token symbols (e.g. ['AAVE', 'BNB', 'BTC', ...])."""
        return sorted(self._tokens.keys())

    def get_token(self, identifier: str) -> TokenDto:
        """
        Get token object by symbol, slug, or name (case-insensitive).
        Returns Token Pydantic model (slug, symbol, standard_symbol, name, precision, factor).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Token identifier cannot be empty")
        key_upper = raw.upper()
        key_lower = raw.lower()
        if key_upper in self._tokens:
            return TokenDto(**self._tokens[key_upper])
        for sym, info in self._tokens.items():
            if (info.get("slug") or "").strip().lower() == key_lower:
                return TokenDto(**info)
            if (info.get("name") or "").strip().lower() == key_lower:
                return TokenDto(**info)
        raise TokenNetworkError(
            f"Unknown token: {identifier!r}. Known tokens: {self.get_tokens()}"
        )

    def get_network(self, identifier: str) -> NetworkDataDto:
        """
        Get network object by network name/id (case-insensitive).
        Returns NetworkData Pydantic model with config (NetworkConfig) and tokens (list of TokenOnNetwork).
        Raises TokenNetworkError if not found.
        """
        raw = (identifier or "").strip()
        if not raw:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {identifier!r}. Known networks: {self.get_networks()}"
            )
        data = self._network_tokens[net_key]
        config = NetworkConfigDto(**data["config"])
        tokens = [
            _to_token_on_network(self._token_on_network[(net_key, t["token"])])
            for t in data["tokens"]
            if (net_key, t["token"]) in self._token_on_network
        ]
        return NetworkDataDto(config=config, tokens=tokens)

    def get_token_network(self, token_identifier: str, network_identifier: str) -> TokenOnNetworkDto:
        """
        Get token_network by token (symbol/slug/name) and network name (case-insensitive).
        Returns TokenOnNetwork Pydantic model.
        Raises TokenNetworkError if not found or token not on network.
        """
        token_model = self.get_token(token_identifier)
        symbol = (token_model.symbol or "").strip().upper()
        if not symbol:
            raise TokenNetworkError("Token has no symbol")
        raw_net = (network_identifier or "").strip()
        if not raw_net:
            raise TokenNetworkError("Network identifier cannot be empty")
        net_key = raw_net.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {network_identifier!r}. Known networks: {self.get_networks()}"
            )
        key = (net_key, symbol)
        if key not in self._token_on_network:
            tokens_on_net = [t["token"] for t in self._network_tokens[net_key]["tokens"]]
            raise TokenNetworkError(
                f"Token {symbol!r} is not on network {net_key!r}. "
                f"Available on this network: {tokens_on_net}"
            )
        return _to_token_on_network(self._token_on_network[key])

    def __call__(self, name: str) -> _NetworkNode:
        """Return network object by name: bitcoin = network('bitcoin')."""
        raw = (name or "").strip()
        if not raw:
            raise TokenNetworkError("Network name cannot be empty")
        net_key = raw.lower()
        if net_key not in self._network_tokens:
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {self.get_networks()}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def __getattr__(self, name: str) -> _NetworkNode:
        if name.startswith("_"):
            raise AttributeError(name)
        net_key = name.lower()
        if net_key not in self._network_tokens:
            known = ", ".join(self.get_networks())
            raise TokenNetworkError(
                f"Unknown network: {name!r}. Known networks: {known}"
            )
        return _NetworkNode(
            net_key,
            self._network_tokens,
            self._token_on_network,
        )

    def get_token_on_network(self, *, network: str, token_abbr: str) -> TokenOnNetworkDto:
        """
        Get token-on-network object by network and token symbol/slug (e.g. USDT).
        Returns TokenOnNetwork Pydantic model with .contract_address, .model_dump(), etc.
        """
        return self.get_token_network(token_abbr, network)


# Singleton used as `network`
network = NetworkAccessor()
