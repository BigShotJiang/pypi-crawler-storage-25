"""Pydantic models for token and network config."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, computed_field


class TokenDto(BaseModel):
    """Token definition (from tokens.yaml): slug, symbol, name, precision, factor."""

    model_config = ConfigDict(extra="allow")

    slug: str = ""
    symbol: str = ""
    standard_symbol: str = ""
    name: str = ""
    precision: int = 0
    factor: int | float = 0

    def get(self, key: str, default: Any = None) -> Any:
        """Dict-like .get() for compatibility."""
        return self.model_dump().get(key, default)

    def __getitem__(self, key: str) -> Any:
        """Dict-like access (e.g. token['symbol'])."""
        d = self.model_dump()
        if key in d:
            return d[key]
        raise KeyError(key)


class NetworkConfigDto(BaseModel):
    """Network/chain config (from networks.yaml): slug, name, network_type, base_token, etc."""

    model_config = ConfigDict(extra="allow")

    slug: str = ""
    name: str = ""
    network_type: str = ""
    token_standard: str = ""
    base_token: str = ""
    base_token_decimal: int = 0
    confirmation_number: int = 0
    confirmation_check_time: int = 0
    resource_providing_amount: float = 0.0
    resource_providing_below_threshold: float = 0.0
    is_tag_based: bool = False

    def __getitem__(self, key: str) -> Any:
        """Dict-like access (e.g. config['network_type'])."""
        return self.model_dump()[key]


class TokenOnNetworkDto(BaseModel):
    """Token on a specific network (e.g. USDT on Ethereum): contract_address, decimal, network, token."""

    model_config = ConfigDict(extra="allow")

    network: NetworkConfigDto
    token: TokenDto
    contract_address: str | None = None
    decimal: int = 0
    native: bool = False
    type: str = "TOKEN"

    @computed_field
    @property
    def decimals(self) -> int:
        """Alias for decimal."""
        return self.decimal

    def to_dict(self) -> dict[str, Any]:
        """Return all token-on-network data as a dict."""
        return self.model_dump()

    def __getitem__(self, key: str) -> Any:
        """Dict-like access (e.g. obj['contract_address'], obj['token_info'])."""
        d = self.model_dump()
        if key == "token_info":
            return d.get("token", {})
        if key in d:
            return d[key]
        raise KeyError(key)


class NetworkDataDto(BaseModel):
    """Result of get_network(): config and list of token-on-network bindings."""

    config: NetworkConfigDto
    tokens: list[TokenOnNetworkDto]

    def to_dict(self) -> dict[str, Any]:
        """Return dict with config and tokens (each as dict)."""
        return {
            "config": self.config.model_dump(),
            "tokens": [t.model_dump() for t in self.tokens],
        }
