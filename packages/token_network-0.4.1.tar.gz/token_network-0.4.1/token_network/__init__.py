"""
token_network: validate input and return token network config.

Usage:
    from token_network import network, get_token_on_network

    # Network by name (callable)
    bitcoin = network("bitcoin")
    bitcoin.decimal              # 8 (base token decimals)
    bitcoin.confirmation_number  # 2
    bitcoin.__dict__()           # all network data: {"config": {...}, "tokens": [...]}
    bitcoin.config
    bitcoin.tokens               # list of TokenOnNetwork objects

    # Attribute access works too
    network.bitcoin.decimal
    network.ethereum.confirmation_number

    # Tokens on a network (list of token objects)
    ethereum = network("ethereum")
    ethereum.tokens              # list of TokenOnNetwork (contract_address, decimal, etc.)

    # Token on network by symbol
    token_on_network = get_token_on_network(network="ethereum", token_abbr="USDT")
    token_on_network.contract_address   # "0x..."
    token_on_network.__dict__()         # all token-on-network data
    # Or: network.ethereum.usdt (returns TokenOnNetwork, dict-like too)

    # List all networks / tokens
    get_networks()   # ['bitcoin', 'bsc', 'ethereum', ...]
    get_tokens()     # ['AAVE', 'BNB', 'BTC', 'ETH', ...]

    # Get token/network/token_network by identifier (Pydantic models)
    get_token('USDT')       # Token model
    get_network('bitcoin')  # NetworkData model (config + tokens)
    get_token_network('USDT', 'bsc')  # TokenOnNetwork model

Unknown network or token raises token_network.TokenNetworkError.
"""

from ._accessor import TokenNetworkError, NetworkAccessor, TokenOnNetworkDto, network as _network
from ._models import NetworkConfigDto, NetworkDataDto, TokenDto


# Public singleton: use "network" in user-facing docs; accessor is _network internally to avoid shadowing.
network = _network


def get_networks() -> list[str]:
    """Return list of all network ids (e.g. ['bitcoin', 'bsc', 'ethereum', ...])."""
    return _network.get_networks()


def get_tokens() -> list[str]:
    """Return list of all token symbols (e.g. ['AAVE', 'BNB', 'BTC', ...])."""
    return _network.get_tokens()


def get_token(identifier: str) -> TokenDto:
    """
    Get token object by symbol, slug, or name (case-insensitive).
    Returns Token Pydantic model (slug, symbol, standard_symbol, name, precision, factor).
    """
    return _network.get_token(identifier)


def get_network(identifier: str) -> NetworkDataDto:
    """
    Get network object by network name/id (case-insensitive).
    Returns NetworkData Pydantic model with config (NetworkConfig) and tokens (list of TokenOnNetwork).
    """
    return _network.get_network(identifier)


def get_token_network(token_identifier: str, network_identifier: str) -> TokenOnNetworkDto:
    """
    Get token_network by token (symbol/slug/name) and network name (case-insensitive).
    Returns TokenOnNetwork Pydantic model.
    """
    return _network.get_token_network(token_identifier, network_identifier)


def get_token_on_network(*, network: str, token_abbr: str) -> TokenOnNetworkDto:
    """
    Get token-on-network object by network and token symbol/slug (e.g. USDT).
    Returns TokenOnNetwork with .contract_address, .decimal, .__dict__(), etc.

    Example:
        token_on_network = get_token_on_network(network="ethereum", token_abbr="USDT")
        token_on_network.contract_address  # "0x..."
        token_on_network.__dict__()       # all token data
    """
    return _network.get_token_on_network(network=network, token_abbr=token_abbr)


__all__ = [
    "network",
    "get_networks",
    "get_tokens",
    "get_token",
    "get_network",
    "get_token_network",
    "get_token_on_network",
    "TokenNetworkError",
    "NetworkAccessor",
    "TokenOnNetworkDto",
    "TokenDto",
    "NetworkConfigDto",
    "NetworkDataDto",
]
__version__ = "0.1.0"
