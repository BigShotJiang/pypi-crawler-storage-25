"""DeepL processor"""

__version__ = "1.8.39"
