#!/usr/bin/env python3
"""Treasury QA MCP Server — structured table extraction, search, and computation.

Runs as stdio MCP server inside Docker container. Zero external dependencies.
Protocol: JSON-RPC 2.0 with Content-Length framing (LSP-style).
"""

import sys
import json
import os
import re
import math
import statistics
import subprocess
from collections import defaultdict

# ─── Configuration ──────────────────────────────────────────────────────────

CORPUS_DIR = "/app/corpus"
TOOL_DEFINITIONS = [
    {
        "name": "search_corpus",
        "description": "Search Treasury Bulletin corpus files. Returns top-5 matching files with line numbers and snippets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search keyword or phrase (case-insensitive)"},
                "date_range": {"type": "string", "description": "Optional year range filter, e.g. '1980-1990' or '1982'"},
                "section": {"type": "string", "description": "Optional section filter: FFO, FD, PDO, OFS, IFS, UST, ESF, MS, CC, exchange, currency"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "extract_cell",
        "description": "Extract a cell value from a markdown table in a Treasury Bulletin file. Without row_label/column_header, returns table structure (available rows and columns). With both, returns the exact cell value.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Path to .txt file, e.g. /app/corpus/treasury_bulletin_1982_03.txt"},
                "table_pattern": {"type": "string", "description": "Text to match in or near the table title, e.g. 'Summary of Federal Debt'"},
                "row_label": {"type": "string", "description": "Row identifier (fuzzy matched). Omit to list all rows."},
                "column_header": {"type": "string", "description": "Column identifier (fuzzy matched). Omit to list all columns."}
            },
            "required": ["file_path", "table_pattern"]
        }
    },
    {
        "name": "compute",
        "description": "Deterministic financial calculation. Available formulas: percent_change, percent_difference, fisher_ideal, cagr, log_growth, geometric_mean, coefficient_of_variation, mad, std_dev_population, std_dev_sample, variance_population, variance_sample, pearson_r, exp_smoothing, var_95, cvar_95, arc_elasticity, annualized_volatility, iqr, euclidean_norm, linear_regression, ratio, sum, mean, median, min, max, range, count_above, count_below.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "formula": {"type": "string", "description": "Formula name from the list above"},
                "values": {"type": "object", "description": "Named parameters for the formula. Common keys: old, new, data (list), start, end, periods, alpha, x, y, threshold"}
            },
            "required": ["formula", "values"]
        }
    }
]

# ─── MCP Protocol Layer ─────────────────────────────────────────────────────

def read_message():
    """Read JSON-RPC message with Content-Length framing from stdin."""
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None  # EOF
        line_str = line.decode("utf-8", errors="replace").strip()
        if line_str == "":
            break
        if ":" in line_str:
            key, val = line_str.split(":", 1)
            headers[key.strip()] = val.strip()
    length = int(headers.get("Content-Length", 0))
    if length == 0:
        return None
    body = sys.stdin.buffer.read(length)
    if not body:
        return None
    return json.loads(body.decode("utf-8", errors="replace"))


def write_message(msg):
    """Write JSON-RPC message with Content-Length framing to stdout."""
    body = json.dumps(msg, ensure_ascii=False).encode("utf-8")
    header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
    sys.stdout.buffer.write(header + body)
    sys.stdout.buffer.flush()


def send_result(req_id, result):
    write_message({"jsonrpc": "2.0", "id": req_id, "result": result})


def send_error(req_id, code, message):
    write_message({"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}})


# ─── Corpus Index ────────────────────────────────────────────────────────────

CORPUS_INDEX = {}  # {filename: {year, month, path}}
SECTION_KEYWORDS = {
    "FFO": ["fiscal operations", "receipts", "outlays", "expenditures", "budget"],
    "FD": ["federal debt", "public debt", "debt outstanding", "gross debt"],
    "PDO": ["public debt operations", "treasury bill", "treasury note", "treasury bond", "auction"],
    "OFS": ["ownership", "treasury survey", "holders"],
    "IFS": ["international financial", "liabilities to foreigners", "capital movements", "foreign"],
    "UST": ["account of the.*treasury", "treasury cash"],
    "ESF": ["exchange stabilization", "esf"],
    "MS": ["monetary statistics", "money supply", "discount rate", "federal funds"],
    "CC": ["currency.*coin", "money in circulation", "paper money", "denomination"],
    "exchange": ["exchange rate", "foreign exchange"],
    "currency": ["currency", "coin", "denomination"],
}


def build_index():
    """Scan corpus directory and build filename metadata index."""
    global CORPUS_INDEX
    if not os.path.isdir(CORPUS_DIR):
        log(f"WARNING: Corpus directory not found: {CORPUS_DIR}")
        return
    pattern = re.compile(r"treasury_bulletin_(\d{4})_(\d{2})\.txt")
    for fname in sorted(os.listdir(CORPUS_DIR)):
        m = pattern.match(fname)
        if m:
            year, month = int(m.group(1)), int(m.group(2))
            CORPUS_INDEX[fname] = {
                "year": year,
                "month": month,
                "quarter": (month - 1) // 3 + 1,
                "path": os.path.join(CORPUS_DIR, fname),
            }
    log(f"Indexed {len(CORPUS_INDEX)} corpus files")


def log(msg):
    """Log to stderr (visible in container logs, not in MCP protocol)."""
    print(f"[treasury-tools] {msg}", file=sys.stderr, flush=True)


# ─── Tool 1: search_corpus ──────────────────────────────────────────────────

def tool_search_corpus(args):
    query = args.get("query", "")
    date_range = args.get("date_range", "")
    section = args.get("section", "")

    if not query:
        return {"error": "query is required"}

    # Filter files by date range
    files = list(CORPUS_INDEX.values())
    if date_range:
        parts = date_range.replace(" ", "").split("-")
        try:
            y_start = int(parts[0])
            y_end = int(parts[-1]) if len(parts) > 1 else y_start
            files = [f for f in files if y_start <= f["year"] <= y_end]
        except ValueError:
            pass

    if not files:
        return {"results": [], "message": "No files match the date range filter"}

    # Get file paths
    paths = [f["path"] for f in files]

    # Phase 1: find files that contain the query
    try:
        r = subprocess.run(
            ["grep", "-l", "-i", "--", query] + paths,
            capture_output=True, text=True, timeout=10
        )
        matching_files = r.stdout.strip().split("\n") if r.stdout.strip() else []
    except (subprocess.TimeoutExpired, Exception) as e:
        return {"error": f"Search failed: {e}"}

    if not matching_files:
        return {"results": [], "message": f"No files contain '{query}'"}

    # Optional section filter on matching files
    if section and section.upper() in SECTION_KEYWORDS:
        sec_kws = SECTION_KEYWORDS[section.upper()]
        filtered = []
        for fpath in matching_files[:20]:
            try:
                r2 = subprocess.run(
                    ["grep", "-l", "-i", "-E", "|".join(sec_kws), fpath],
                    capture_output=True, text=True, timeout=5
                )
                if r2.returncode == 0:
                    filtered.append(fpath)
            except Exception:
                filtered.append(fpath)
        matching_files = filtered if filtered else matching_files

    # Phase 2: get snippets from top matches
    results = []
    for fpath in matching_files[:5]:
        fname = os.path.basename(fpath)
        meta = CORPUS_INDEX.get(fname, {})
        try:
            r3 = subprocess.run(
                ["grep", "-n", "-i", "-m", "3", "--", query, fpath],
                capture_output=True, text=True, timeout=5
            )
            snippets = []
            for line in r3.stdout.strip().split("\n")[:3]:
                if ":" in line:
                    lineno, text = line.split(":", 1)
                    snippets.append({"line": int(lineno), "text": text.strip()[:200]})
            results.append({
                "file": fname,
                "path": fpath,
                "year": meta.get("year"),
                "month": meta.get("month"),
                "snippets": snippets
            })
        except Exception:
            results.append({"file": fname, "path": fpath, "snippets": []})

    return {"results": results, "total_matching_files": len(matching_files)}


# ─── Tool 2: extract_cell ───────────────────────────────────────────────────

def parse_numeric(text):
    """Convert Treasury Bulletin text value to float."""
    if not text or not isinstance(text, str):
        return None
    s = text.strip()
    if s in ("", "*", "—", "–", "-", "...", "n.a.", "N/A", "(*)"):
        return None

    negative = False
    # Parenthesized negatives: (1,234.5) → -1234.5
    if s.startswith("(") and s.endswith(")"):
        negative = True
        s = s[1:-1].strip()

    # Strip currency symbols, percent, revision markers
    s = re.sub(r"[$%£€¥]", "", s)
    s = re.sub(r"[rpRP]$", "", s.strip())
    s = s.replace(",", "").strip()

    if not s:
        return None
    try:
        val = float(s)
        return -val if negative else val
    except ValueError:
        return None


def detect_units(text_block):
    """Detect unit multiplier from text near a table."""
    t = text_block.lower()
    if "in billions" in t or "(billions" in t:
        return {"multiplier": 1_000_000_000, "label": "billions"}
    if "in millions" in t or "(millions" in t:
        return {"multiplier": 1_000_000, "label": "millions"}
    if "in thousands" in t or "(thousands" in t:
        return {"multiplier": 1_000, "label": "thousands"}
    if "percent" in t or "%" in t:
        return {"multiplier": 1, "label": "percent"}
    return {"multiplier": 1, "label": "units"}


def split_pipe_row(line):
    """Split a pipe-delimited row into cells, stripping outer empties."""
    cells = line.split("|")
    # Remove empty leading/trailing cells from outer pipes
    if cells and cells[0].strip() == "":
        cells = cells[1:]
    if cells and cells[-1].strip() == "":
        cells = cells[:-1]
    return [c.strip() for c in cells]


def is_separator_row(line):
    """Check if a line is a table separator (| --- | --- |)."""
    stripped = line.strip()
    if not stripped.startswith("|"):
        return False
    return bool(re.match(r"^\|[\s\-:.|]+$", stripped))


def find_tables(text, pattern):
    """Find all tables in text near a pattern match. Returns list of table dicts."""
    lines = text.split("\n")
    tables = []

    # Find pattern location(s)
    pat_lower = pattern.lower()
    match_lines = []
    for i, line in enumerate(lines):
        if pat_lower in line.lower():
            match_lines.append(i)

    if not match_lines:
        # Fall back: try individual words
        words = pat_lower.split()
        for i, line in enumerate(lines):
            ll = line.lower()
            if all(w in ll for w in words):
                match_lines.append(i)

    if not match_lines:
        # Last resort: find ALL tables in the file
        match_lines = list(range(len(lines)))

    found_table_starts = set()

    for match_line in match_lines:
        # Search forward from match for a pipe table (within 40 lines)
        for scan_start in range(max(0, match_line - 5), min(len(lines), match_line + 40)):
            line = lines[scan_start].strip()
            if line.startswith("|") and "|" in line[1:] and scan_start not in found_table_starts:
                # Found a table start. Check if we already captured it.
                if any(abs(scan_start - ts) < 3 for ts in found_table_starts):
                    continue

                # Collect contiguous pipe lines
                table_lines = []
                j = scan_start
                while j < len(lines) and lines[j].strip().startswith("|"):
                    table_lines.append(lines[j])
                    j += 1

                if len(table_lines) < 3:
                    continue  # Need header + sep + at least 1 row

                found_table_starts.add(scan_start)

                # Get title: non-pipe lines just before the table
                title_parts = []
                for k in range(scan_start - 1, max(scan_start - 5, -1), -1):
                    tl = lines[k].strip()
                    if tl and not tl.startswith("|"):
                        title_parts.insert(0, tl)
                    else:
                        break
                title = " ".join(title_parts).strip()

                # Detect units from title + nearby text
                context = "\n".join(lines[max(0, scan_start - 5):scan_start + 2])
                units = detect_units(context + " " + title)

                # Parse table
                table = _parse_pipe_table(table_lines, title, scan_start, units)
                if table:
                    tables.append(table)

        if tables:
            break  # Found tables near the first match

    return tables


def _parse_pipe_table(table_lines, title, start_line, units):
    """Parse pipe-delimited markdown table into structured data."""
    # Find separator row(s)
    sep_idx = -1
    for i, line in enumerate(table_lines):
        if is_separator_row(line):
            sep_idx = i
            break

    if sep_idx < 1:
        # No separator found — treat first row as header
        sep_idx = 1

    # Parse header rows (everything before separator)
    header_rows = [split_pipe_row(line) for line in table_lines[:sep_idx]]

    # Build column headers
    num_cols = max(len(r) for r in header_rows) if header_rows else 0
    headers = []
    for col_idx in range(num_cols):
        parts = []
        for hr in header_rows:
            if col_idx < len(hr) and hr[col_idx].strip():
                parts.append(hr[col_idx].strip())
        headers.append(" > ".join(parts) if parts else f"Column_{col_idx}")

    # Parse data rows (everything after separator)
    data_start = sep_idx + 1
    # Skip additional separator rows
    while data_start < len(table_lines) and is_separator_row(table_lines[data_start]):
        data_start += 1

    rows = []
    for line in table_lines[data_start:]:
        if is_separator_row(line):
            continue
        cells = split_pipe_row(line)
        if cells:
            rows.append(cells)

    return {
        "title": title,
        "start_line": start_line,
        "headers": headers,
        "rows": rows,
        "units": units,
        "num_cols": num_cols,
        "num_rows": len(rows),
    }


def fuzzy_score(needle, haystack):
    """Score how well needle matches haystack. Returns 0.0–1.0."""
    if not needle or not haystack:
        return 0.0
    n = needle.lower().strip()
    h = haystack.lower().strip()

    if n == h:
        return 1.0
    if n in h:
        return 0.85 + 0.1 * (len(n) / len(h))
    if h in n:
        return 0.6

    # Word overlap
    n_words = set(re.findall(r"\w+", n))
    h_words = set(re.findall(r"\w+", h))
    if n_words and h_words:
        overlap = len(n_words & h_words)
        if overlap == len(n_words):
            return 0.75
        if overlap > 0:
            return 0.3 + 0.3 * (overlap / len(n_words))
    return 0.0


def best_match(needle, candidates, threshold=0.3):
    """Find best fuzzy match from candidates. Returns (index, score, matched_text)."""
    best_idx, best_score, best_text = -1, 0.0, ""
    for i, c in enumerate(candidates):
        s = fuzzy_score(needle, c)
        if s > best_score:
            best_idx, best_score, best_text = i, s, c
    if best_score >= threshold:
        return best_idx, best_score, best_text
    return -1, 0.0, ""


def tool_extract_cell(args):
    file_path = args.get("file_path", "")
    table_pattern = args.get("table_pattern", "")
    row_label = args.get("row_label")
    column_header = args.get("column_header")

    if not file_path or not table_pattern:
        return {"error": "file_path and table_pattern are required"}

    # Read file
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except FileNotFoundError:
        return {"error": f"File not found: {file_path}"}
    except Exception as e:
        return {"error": f"Cannot read file: {e}"}

    # Find tables near the pattern
    tables = find_tables(text, table_pattern)
    if not tables:
        return {"error": f"No tables found matching '{table_pattern}' in {os.path.basename(file_path)}"}

    table = tables[0]  # Use first (closest) match

    # Discovery mode: return table structure
    if not row_label and not column_header:
        row_labels = []
        for r in table["rows"][:30]:
            if r:
                row_labels.append(r[0])
        return {
            "mode": "discovery",
            "table_title": table["title"],
            "units": table["units"],
            "columns": table["headers"],
            "rows": row_labels,
            "num_rows": table["num_rows"],
            "num_cols": table["num_cols"],
            "tables_found": len(tables),
            "hint": "Call again with row_label and column_header to extract a specific cell"
        }

    # Extraction mode: find the specific cell
    # Match row
    row_labels = [r[0] if r else "" for r in table["rows"]]
    row_idx, row_score, row_matched = best_match(row_label or "", row_labels)
    if row_idx < 0:
        return {
            "error": f"Row '{row_label}' not found. Available rows: {row_labels[:15]}",
            "table_title": table["title"]
        }

    # Match column
    col_idx, col_score, col_matched = best_match(column_header or "", table["headers"])
    if col_idx < 0:
        return {
            "error": f"Column '{column_header}' not found. Available columns: {table['headers']}",
            "table_title": table["title"]
        }

    # Extract cell
    row_data = table["rows"][row_idx]
    if col_idx >= len(row_data):
        return {
            "error": f"Column index {col_idx} out of range for row with {len(row_data)} cells",
            "row_matched": row_matched,
            "col_matched": col_matched
        }

    raw = row_data[col_idx]
    numeric = parse_numeric(raw)

    return {
        "raw": raw,
        "numeric": numeric,
        "units": table["units"],
        "table_title": table["title"],
        "row_matched": row_matched,
        "row_score": round(row_score, 2),
        "col_matched": col_matched,
        "col_score": round(col_score, 2),
        "row_index": row_idx,
        "col_index": col_idx
    }


# ─── Tool 3: compute ────────────────────────────────────────────────────────

def _ensure_list(v, key="data"):
    """Extract a list of floats from values dict."""
    d = v.get(key, [])
    if isinstance(d, (list, tuple)):
        return [float(x) for x in d]
    return [float(d)]


def _pearson(x, y):
    """Pearson correlation coefficient (pure stdlib)."""
    n = len(x)
    if n < 2:
        return 0.0
    mx, my = sum(x) / n, sum(y) / n
    sx = math.sqrt(sum((xi - mx) ** 2 for xi in x) / (n - 1))
    sy = math.sqrt(sum((yi - my) ** 2 for yi in y) / (n - 1))
    if sx == 0 or sy == 0:
        return 0.0
    return sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / ((n - 1) * sx * sy)


FORMULAS = {
    "percent_change": lambda v: (float(v["new"]) - float(v["old"])) / float(v["old"]) * 100,
    "percent_difference": lambda v: abs(float(v["a"]) - float(v["b"])) / ((float(v["a"]) + float(v["b"])) / 2) * 100,
    "fisher_ideal": lambda v: 2 * (float(v["v2"]) - float(v["v1"])) / (float(v["v1"]) + float(v["v2"])),
    "cagr": lambda v: ((float(v["end"]) / float(v["start"])) ** (1 / float(v["periods"])) - 1) * 100,
    "log_growth": lambda v: math.log(float(v["new"]) / float(v["old"])) * 100,
    "geometric_mean": lambda v: math.exp(sum(math.log(x) for x in _ensure_list(v)) / len(_ensure_list(v))),
    "coefficient_of_variation": lambda v: (statistics.stdev(_ensure_list(v)) / statistics.mean(_ensure_list(v))) * 100,
    "mad": lambda v: _mad(_ensure_list(v)),
    "std_dev_population": lambda v: statistics.pstdev(_ensure_list(v)),
    "std_dev_sample": lambda v: statistics.stdev(_ensure_list(v)),
    "variance_population": lambda v: statistics.pvariance(_ensure_list(v)),
    "variance_sample": lambda v: statistics.variance(_ensure_list(v)),
    "pearson_r": lambda v: _pearson([float(x) for x in v["x"]], [float(y) for y in v["y"]]),
    "exp_smoothing": lambda v: _exp_smooth(_ensure_list(v), float(v.get("alpha", 0.3))),
    "var_95": lambda v: _var_95(_ensure_list(v)),
    "cvar_95": lambda v: _cvar_95(_ensure_list(v)),
    "arc_elasticity": lambda v: _arc_elasticity(v),
    "annualized_volatility": lambda v: _ann_vol(_ensure_list(v), float(v.get("periods_per_year", 12))),
    "iqr": lambda v: _iqr(_ensure_list(v)),
    "euclidean_norm": lambda v: math.sqrt(sum(x ** 2 for x in _ensure_list(v))),
    "linear_regression": lambda v: _linreg([float(x) for x in v["x"]], [float(y) for y in v["y"]]),
    "ratio": lambda v: float(v["numerator"]) / float(v["denominator"]),
    "sum": lambda v: sum(_ensure_list(v)),
    "mean": lambda v: statistics.mean(_ensure_list(v)),
    "median": lambda v: statistics.median(_ensure_list(v)),
    "min": lambda v: min(_ensure_list(v)),
    "max": lambda v: max(_ensure_list(v)),
    "range": lambda v: max(_ensure_list(v)) - min(_ensure_list(v)),
    "count_above": lambda v: sum(1 for x in _ensure_list(v) if x > float(v.get("threshold", 0))),
    "count_below": lambda v: sum(1 for x in _ensure_list(v) if x < float(v.get("threshold", 0))),
}


def _mad(data):
    """Median Absolute Deviation."""
    med = statistics.median(data)
    deviations = sorted(abs(x - med) for x in data)
    return statistics.median(deviations)


def _exp_smooth(data, alpha):
    """Single exponential smoothing. Returns last smoothed value."""
    if not data:
        return 0.0
    s = data[0]
    for y in data[1:]:
        s = alpha * y + (1 - alpha) * s
    return s


def _var_95(data):
    """Historical VaR at 95% confidence (5th percentile, nearest rank)."""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    idx = max(0, math.ceil(0.05 * len(sorted_data)) - 1)
    return sorted_data[idx]


def _cvar_95(data):
    """CVaR/Expected Shortfall at 95% confidence."""
    if not data:
        return 0.0
    var = _var_95(data)
    tail = [x for x in data if x <= var]
    return statistics.mean(tail) if tail else var


def _arc_elasticity(v):
    """Arc (midpoint) elasticity."""
    q1, q2 = float(v["q1"]), float(v["q2"])
    p1, p2 = float(v["p1"]), float(v["p2"])
    pct_q = (q2 - q1) / ((q1 + q2) / 2)
    pct_p = (p2 - p1) / ((p1 + p2) / 2)
    if pct_p == 0:
        return float("inf")
    return pct_q / pct_p


def _ann_vol(data, periods_per_year):
    """Annualized volatility from log returns."""
    if len(data) < 2:
        return 0.0
    log_returns = [math.log(data[i] / data[i - 1]) for i in range(1, len(data)) if data[i - 1] != 0 and data[i] != 0]
    if not log_returns:
        return 0.0
    return statistics.stdev(log_returns) * math.sqrt(periods_per_year) * 100


def _iqr(data):
    """Interquartile range using Type 7 interpolation (numpy default)."""
    n = len(data)
    if n < 2:
        return 0.0
    s = sorted(data)

    def percentile_t7(s, p):
        idx = (p / 100) * (n - 1)
        lo = int(math.floor(idx))
        hi = min(lo + 1, n - 1)
        frac = idx - lo
        return s[lo] * (1 - frac) + s[hi] * frac

    return percentile_t7(s, 75) - percentile_t7(s, 25)


def _linreg(x, y):
    """Simple linear regression. Returns [slope, intercept]."""
    n = len(x)
    if n < 2:
        return [0.0, 0.0]
    mx, my = sum(x) / n, sum(y) / n
    ss_xx = sum((xi - mx) ** 2 for xi in x)
    ss_xy = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y))
    if ss_xx == 0:
        return [0.0, my]
    slope = ss_xy / ss_xx
    intercept = my - slope * mx
    return [slope, intercept]


def tool_compute(args):
    formula = args.get("formula", "")
    values = args.get("values", {})

    if not formula:
        return {"error": "formula is required", "available": list(FORMULAS.keys())}

    if formula not in FORMULAS:
        return {"error": f"Unknown formula: '{formula}'", "available": list(FORMULAS.keys())}

    try:
        result = FORMULAS[formula](values)
        # Format result
        if isinstance(result, list):
            return {"result": result, "formula": formula}
        return {"result": round(result, 10), "formula": formula}
    except ZeroDivisionError:
        return {"error": "Division by zero", "formula": formula}
    except (KeyError, TypeError) as e:
        return {"error": f"Missing or invalid parameter: {e}", "formula": formula}
    except Exception as e:
        return {"error": f"Computation error: {e}", "formula": formula}


# ─── Dispatch ────────────────────────────────────────────────────────────────

TOOL_HANDLERS = {
    "search_corpus": tool_search_corpus,
    "extract_cell": tool_extract_cell,
    "compute": tool_compute,
}


def handle_tool_call(name, arguments):
    """Dispatch tool call and return MCP-formatted result."""
    handler = TOOL_HANDLERS.get(name)
    if not handler:
        return {
            "content": [{"type": "text", "text": json.dumps({"error": f"Unknown tool: {name}"})}],
            "isError": True
        }
    try:
        result = handler(arguments)
        return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}]}
    except Exception as e:
        log(f"Tool {name} error: {e}")
        return {
            "content": [{"type": "text", "text": json.dumps({"error": str(e)})}],
            "isError": True
        }


# ─── Main Loop ───────────────────────────────────────────────────────────────

def main():
    log("Starting treasury-tools MCP server...")
    build_index()
    log("Ready. Waiting for messages...")

    while True:
        try:
            msg = read_message()
            if msg is None:
                log("EOF received, shutting down.")
                break

            method = msg.get("method", "")
            req_id = msg.get("id")
            params = msg.get("params", {})

            if method == "initialize":
                send_result(req_id, {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {"name": "treasury-tools", "version": "1.0.0"}
                })
            elif method == "notifications/initialized":
                pass  # No response for notifications
            elif method == "tools/list":
                send_result(req_id, {"tools": TOOL_DEFINITIONS})
            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})
                result = handle_tool_call(tool_name, tool_args)
                send_result(req_id, result)
            elif req_id is not None:
                # Unknown method with an id — return error
                send_error(req_id, -32601, f"Method not found: {method}")
            # else: unknown notification, silently ignore

        except json.JSONDecodeError as e:
            log(f"JSON parse error: {e}")
            if msg and msg.get("id"):
                send_error(msg["id"], -32700, f"Parse error: {e}")
        except Exception as e:
            log(f"Unexpected error in main loop: {e}")
            # Continue running — never crash


if __name__ == "__main__":
    main()
