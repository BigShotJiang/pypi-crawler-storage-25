# Milestones

## v12.0 FXView Forex — Portcullis Bars (Shipped: 2026-04-06)

**Phases completed:** 9 phases (50-58), 19 plans, 27 tasks

**Definition shipped:** Novel Portcullis breach mode for forex — contra-quote threshold detection that filters illiquid regimes via bid-ask spread resistance. Live streaming of EURUSD and XAUUSD alongside crypto with 38 spread features per bar, week-mode reset boundaries, and Stathera continuity across the backfill-to-live junction.

**Key accomplishments:**

- **Portcullis breach mode (50-51)** — Novel contra-quote breach: bid tests upper threshold, ask tests lower. Mid-price OHLCV. Tick struct gains `best_bid`/`best_ask` `Option<FixedPoint>` while remaining `Copy`. Per-market `breach_mode` field in registry.
- **Week ouroboros mode (52)** — Gap-based weekly reset (>4h tick gap triggers `reset_at_ouroboros`). Data-driven, no hardcoded UTC times. Forex symbols declare `ouroboros_mode = "week"`.
- **SpreadAccumulator (53-54)** — 26 base + 11 advanced spread statistics computed O(1) per tick via Welford M1-M4. 37 total `Option<f64>` features with mathematically justified N-guards. `compute_advanced` tier toggle for research/ML consumers.
- **FXView Parquet adapter (55)** — Rust adapter converts `(time_msc, bid, ask)` → ODB `Tick` with mid-price OHLCV, `best_bid=Some(bid)`, `best_ask=Some(ask)`, synthetic monotonic IDs (`timestamp_us * 1000 + sequence`). 36 unit tests covering edge cases.
- **ClickHouse 37 spread columns (56)** — Idempotent migration adds 37 `Nullable(Float64)` columns with COMMENTs documenting meaning, formula, unit, N-guard, academic reference. Arrow export, dict export, INSERT, and SELECT paths all wired.
- **Historical backfill (57)** — 4,199,001 forex bars across 6 partitions: EURUSD (4.1M, 2,145 days, 3 thresholds) + XAUUSD (65K, 2,035 days, 3 thresholds). Zero time-based overlaps verified.
- **Live streaming service (58)** — Standalone `forex_streaming.py` (NOT sidecar extension) with one daemon thread per symbol. Reads `/dev/shm/tick_ring_{SYMBOL}` via mmap, processes through Portcullis with Week mode, writes bars to CH. End-to-end verified on bigblack: 7 live bars across all 6 partitions in 6 minutes after market open.
- **Cross-repo bug fixes** — Phase 50 `first_ref_id`/`last_ref_id` rename was incomplete in 7 crates + PyO3 bindings + `bulk_operations.py`; all fixed during execution. mql5 `tick_writer.dll` had `ring-ipc` infrastructure but never wired into FFI write path; fixed in mql5 commit `1e6e132`, cross-compiled with `cargo-xwin`, hot-reloaded MT5 in 9s.

**Requirements:** 28/28 satisfied (BM-01..05, WK-01..04, SA-01..04, FX-01..03, REG-01..03, CH-01..02, HB-01..02, LS-01..02, VAL-01..03)

---

## v11.0 Native Microsecond Timestamps (Shipped: 2026-04-01)

**Phases completed:** 7 phases, 13 plans, 16 tasks

**Key accomplishments:**

- Market-level endpoint sections in symbols.toml with MarketConfig frozen dataclass and symbol-to-market resolution functions
- LiveEngineConfig carries ws_base_url, ws_params, rest_base_url, rest_headers -- threaded through start_ws() and fill_from_rest() to eliminate hardcoded Binance endpoints
- PyO3 REST fetch functions now accept registry-resolved endpoints and microsecond timestamps, eliminating the us->ms->us round-trip in backfill and kintsugi paths
- Keep `prevent_same_timestamp_close=True`
- Byte-stable golden tests for ms/us-era bars plus era-aware timestamp validation helper with MarketConfig registry integration
- 1. [Rule 2 - Missing] Fixed 2 additional hardcoded URLs in Python library code
- 11 empirical Binance endpoint tests using symbol_registry, with network-aware skip for offline CI

---

## v10.0 API Refactoring — BarKey + Option Objects (Shipped: 2026-03-30)

**Phases completed:** 5 phases (39, 40, 40.1, 41, 42), 5 plans
**Git range:** 18 commits, 21 files, +936/-396 lines

**Key accomplishments:**

- Extracted `BarKey(symbol, threshold_decimal_bps, ouroboros_mode)` frozen dataclass, eliminating data clump across 37 functions (#337)
- Updated 27 ClickHouse layer functions with expand-contract migration (Phase 39)
- Propagated BarKey to orchestration layer + added `Shard.bar_key` property (Phase 40)
- Fixed kintsugi writer-boundary orphan misclassification with 3-bar merge strategy (#339, Phase 40.1)
- Created `ProcessingOptions` + `CacheOptions` structured API types replacing 10 boolean params (#338, Phase 41)
- Full backward compatibility via expand-contract — old callers work unchanged

**Archive:** [ROADMAP](milestones/v10.0-ROADMAP.md) | [REQUIREMENTS](milestones/v10.0-REQUIREMENTS.md)

---

## v7.3 Exchange Gap Classification -- Permanent Stathera Resolution (Shipped: 2026-03-28)

**Phases completed:** 0 phases, 0 plans, 0 tasks

**Key accomplishments:**

- (none recorded)

---

## v7.2 Memory Efficiency -- Zero-OOM Sidecar (Shipped: 2026-03-27)

**Phases completed:** 10 phases, 17 plans, 27 tasks

**Key accomplishments:**

- OuroborosMode.AION enum variant with symbols.toml wiring, crypto-only validation, and boundary function dispatch
- Expanded all public Python API ouroboros_mode parameters from Literal["day"] to Literal["day", "aion"] with matching type stubs
- 4 gap awareness fields on OpenDeviationBar with TID-based gap detection in update_with_trade, exported through Arrow and PyO3 dict paths
- 1. [Rule 3 - Blocking] Fixed duplicate import conflict
- 1. [Rule 3 - Blocking] OuroborosMode not re-exported from streaming crate
- Per-symbol ouroboros_mode wired through all 6 kintsugi call sites with conditional today-guard for Aion symbols
- TID-range gap repair for Aion symbols via \_repair_aion() with Parquet-first sourcing and single continuous processor
- Per-symbol mode-aware pre-write gate filtering only day-mode cross-midnight bars, with Aion exclusion in Stathera cross-midnight oracle
- Rolling-window freshness check for Aion symbols replacing meaningless crossover_tid orphan check, with configurable AION_FRESHNESS_WINDOW_MIN and safe day-mode fallback
- Diagnostic scripts, deploy config, and schema comments updated to support Aion ouroboros mode with per-symbol registry auto-detection
- Coordinated stop-drop-wipe-recompute script with 3-phase CLI (preflight/execute/verify), dynamic partition discovery, and Stathera audit for bigblack Aion migration
- Crossover-TID max-seed + targeted today-DELETE for Aion symbols to eliminate 8 midnight-boundary Stathera gaps
- Per-symbol ouroboros_mode wired into all 6 store_bars_batch call sites across backfill.py, dead_letter.py, and count_bounded.py -- eliminating global get_operational_ouroboros_mode() fallback for crypto write paths
- Aion freshness query filters by ouroboros_mode='aion' (MON-04) and both store methods warn on mode mismatch (SCHEMA-01)
- Sidecar restart root cause identified as operator-induced (v7.0 deploy); PID age + restart count telemetry added to heartbeat

---

## v7.1 Aion Hardening -- Footgun Elimination + Startup Fix (Shipped: 2026-03-27)

**Phases completed:** 11 phases, 17 plans, 27 tasks

**Key accomplishments:**

- OuroborosMode.AION enum variant with symbols.toml wiring, crypto-only validation, and boundary function dispatch
- Expanded all public Python API ouroboros_mode parameters from Literal["day"] to Literal["day", "aion"] with matching type stubs
- 4 gap awareness fields on OpenDeviationBar with TID-based gap detection in update_with_trade, exported through Arrow and PyO3 dict paths
- 1. [Rule 3 - Blocking] Fixed duplicate import conflict
- 1. [Rule 3 - Blocking] OuroborosMode not re-exported from streaming crate
- Per-symbol ouroboros_mode wired through all 6 kintsugi call sites with conditional today-guard for Aion symbols
- TID-range gap repair for Aion symbols via \_repair_aion() with Parquet-first sourcing and single continuous processor
- Per-symbol mode-aware pre-write gate filtering only day-mode cross-midnight bars, with Aion exclusion in Stathera cross-midnight oracle
- Rolling-window freshness check for Aion symbols replacing meaningless crossover_tid orphan check, with configurable AION_FRESHNESS_WINDOW_MIN and safe day-mode fallback
- Diagnostic scripts, deploy config, and schema comments updated to support Aion ouroboros mode with per-symbol registry auto-detection
- Coordinated stop-drop-wipe-recompute script with 3-phase CLI (preflight/execute/verify), dynamic partition discovery, and Stathera audit for bigblack Aion migration
- Crossover-TID max-seed + targeted today-DELETE for Aion symbols to eliminate 8 midnight-boundary Stathera gaps
- Per-symbol ouroboros_mode wired into all 6 store_bars_batch call sites across backfill.py, dead_letter.py, and count_bounded.py -- eliminating global get_operational_ouroboros_mode() fallback for crypto write paths
- Aion freshness query filters by ouroboros_mode='aion' (MON-04) and both store methods warn on mode mismatch (SCHEMA-01)
- Sidecar restart root cause identified as operator-induced (v7.0 deploy); PID age + restart count telemetry added to heartbeat

---

## v7.0 Aion Mode -- Genesis-Continuous for Crypto (Shipped: 2026-03-27)

**Phases completed:** 15 phases, 20 plans, 32 tasks

**Key accomplishments:**

- Replaced broken SEED-001 "skip Parquet range" with "process Parquet ticks into bars via Rust processor, seed with last_completed_bar_tid"
- Merged Yesterday + Junction heartbeat sections into exception-only Per-Symbol Health display with per-symbol TID delta computation
- Rust SHA-256 checksum bindings proven callable from Python with correct results, 13.5% overhead (HTTP-bound, acceptable), and graceful edge case handling (404/timeout soft-skip, mismatch/invalid hard-fail)
- ChecksumRegistry with per-file SHA-256 verification state, upsert dict storage, and atomic JSON persistence
- SHA-256 checksum verification wired into tick_cache_seeder Vision download pipeline with retry, LOUD alerts, and ChecksumRegistry persistence
- Retroactive Parquet cache auditing via Vision ZIP SHA-256 verification with incremental registry tracking and concurrent downloads
- Checksum verification health monitoring in heartbeat with JSONL telemetry log and LOUD Telegram alerts on integrity failures
- OuroborosMode.AION enum variant with symbols.toml wiring, crypto-only validation, and boundary function dispatch
- Expanded all public Python API ouroboros_mode parameters from Literal["day"] to Literal["day", "aion"] with matching type stubs
- 4 gap awareness fields on OpenDeviationBar with TID-based gap detection in update_with_trade, exported through Arrow and PyO3 dict paths
- 1. [Rule 3 - Blocking] Fixed duplicate import conflict
- 1. [Rule 3 - Blocking] OuroborosMode not re-exported from streaming crate
- Per-symbol ouroboros_mode wired through all 6 kintsugi call sites with conditional today-guard for Aion symbols
- TID-range gap repair for Aion symbols via \_repair_aion() with Parquet-first sourcing and single continuous processor
- Per-symbol mode-aware pre-write gate filtering only day-mode cross-midnight bars, with Aion exclusion in Stathera cross-midnight oracle
- Rolling-window freshness check for Aion symbols replacing meaningless crossover_tid orphan check, with configurable AION_FRESHNESS_WINDOW_MIN and safe day-mode fallback
- Diagnostic scripts, deploy config, and schema comments updated to support Aion ouroboros mode with per-symbol registry auto-detection
- Coordinated stop-drop-wipe-recompute script with 3-phase CLI (preflight/execute/verify), dynamic partition discovery, and Stathera audit for bigblack Aion migration

---

## v6.0 v6.0 (Shipped: 2026-03-26)

**Phases completed:** 8 phases, 7 plans, 13 tasks

**Key accomplishments:**

- Replaced broken SEED-001 "skip Parquet range" with "process Parquet ticks into bars via Rust processor, seed with last_completed_bar_tid"
- Merged Yesterday + Junction heartbeat sections into exception-only Per-Symbol Health display with per-symbol TID delta computation
- Rust SHA-256 checksum bindings proven callable from Python with correct results, 13.5% overhead (HTTP-bound, acceptable), and graceful edge case handling (404/timeout soft-skip, mismatch/invalid hard-fail)
- ChecksumRegistry with per-file SHA-256 verification state, upsert dict storage, and atomic JSON persistence
- SHA-256 checksum verification wired into tick_cache_seeder Vision download pipeline with retry, LOUD alerts, and ChecksumRegistry persistence
- Retroactive Parquet cache auditing via Vision ZIP SHA-256 verification with incremental registry tracking and concurrent downloads
- Checksum verification health monitoring in heartbeat with JSONL telemetry log and LOUD Telegram alerts on integrity failures

---

## v5.0 Seeder Day-Boundary Completeness + Kintsugi Parquet Trust (Shipped: 2026-03-25)

**Phases completed:** 6 phases, 5 plans, 7 tasks

**Key accomplishments:**

- Shared get_crossover_tid(symbol, date) utility extracted from sidecar internals with 2-tier CH+REST lookup, date parameterization, and backward-compatible sidecar wrapper
- Post-midnight backfill of yesterday's Parquet file to crossover_tid - 1 using shared crossover utility, with state marker dedup and 5 unit tests
- Parquet completeness gate via crossover TID boundary check and orphan bar marking in both Parquet and Vision kintsugi repair paths
- Yesterday completion check expanded from 2 hardcoded symbols to all enabled Binance spot symbols via registry lookup with graceful fallback
- v5.0 day-boundary completeness documented across 5 CLAUDE.md files: seeder backfill, kintsugi Parquet trust gate, heartbeat dynamic symbols, crossover.py module mapping, and L9 monitoring layer

---

## v4.0 Microsecond Column Rename + Deploy Gap Repair (Shipped: 2026-03-25)

**Phases completed:** 6 phases, 5 plans, 8 tasks

**Key accomplishments:**

- BarOutputSchema columns renamed from \_ms to \_us and dead test_heal_scoping.py deleted -- 17 tests pass green
- Renamed open_time_ms/close_time_ms to open_time_us/close_time_us in helpers.rs PyO3 dict export -- truthful keys matching actual microsecond values
- ClickHouse schema DDL and migration script updated from \_ms to \_us column naming with idempotent dry-run-default migration for bigblack
- Mechanical bulk rename of 244 close_time_ms/open_time_ms/last_close_time_ms occurrences to \_us across 38 Python/SQL files, verified by grep and full test suite
- Fixed backfill_gap() ms-to-us unit mismatch that caused negative gap_seconds and broke all trailing-edge repairs

---

## v4.0 Microsecond Column Rename + Deploy Gap Repair (Shipped: 2026-03-25)

**Phases completed:** 6 phases, 5 plans, 8 tasks

**Key accomplishments:**

- BarOutputSchema columns renamed from \_ms to \_us and dead test_heal_scoping.py deleted -- 17 tests pass green
- Renamed open_time_ms/close_time_ms to open_time_us/close_time_us in helpers.rs PyO3 dict export -- truthful keys matching actual microsecond values
- ClickHouse schema DDL and migration script updated from \_ms to \_us column naming with idempotent dry-run-default migration for bigblack
- Mechanical bulk rename of 244 close_time_ms/open_time_ms/last_close_time_ms occurrences to \_us across 38 Python/SQL files, verified by grep and full test suite
- Fixed backfill_gap() ms-to-us unit mismatch that caused negative gap_seconds and broke all trailing-edge repairs

---

## v3.0 Streaming Reliability + Pipeline Cleanup (Shipped: 2026-03-24)

**Phases completed:** 7 phases, 10 plans, 20 tasks

**Key accomplishments:**

- Per-partition lock replaces global \_replace_lock enabling concurrent kintsugi workers; sidecar pre-fill migrated to O(1) DELETE IN PARTITION per pair
- Migrated all remaining open_deviation_bars DELETE call sites to partition-scoped DELETE IN PARTITION across 8 files, with kintsugi_log exception documented
- Stathera continuity validation and dropped_bars diagnostic in sidecar fill pipeline, with junction telemetry enrichment and STREAM-01 contract documentation
- ws_first_tid one-shot tracking in \_main_loop with full REST-to-WS junction telemetry exposed via /status endpoint
- Sidecar startup reads max(agg_trade_id) from today's Parquet tick cache per symbol, advancing REST fill start point past cached data to reduce API weight from ~500 to ~50
- WsMode enum with 2-connection combined split (volume-ranked) and per-symbol fallback, plumbed end-to-end from OPENDEVIATIONBAR_STREAMING_WS_MODE env var through Python config and PyO3 to Rust LiveEngineConfig
- Full quality gate validation (1094 tests, cargo deny, Python smoke test) confirms combined WS 2-connection split is deployment-ready with per-symbol rollback via OPENDEVIATIONBAR_STREAMING_WS_MODE env var
- 79 stale scripts removed (35,476 LOC) -- research patterns, one-off benchmarks, superseded maintenance -- verified unreachable via cross-reference audit against mise tasks, systemd units, and Python imports
- Removed ~1094 LOC dead streaming modules (indicators, stats), unused workspace deps (rolling-stats, tdigests), and stale TODOs referencing closed issues #59/#197
- /health endpoint now exposes ws_mode and expected_ws_connections; test helper \_make_bar() keys corrected from open_time_us to open_time_ms matching production Rust output

---

## v1.0 v1.0 (Shipped: 2026-03-24)

**Phases completed:** 7 phases, 12 plans, 24 tasks

**Key accomplishments:**

- Split 2,436-line live_engine.rs monolith into 5 focused submodules under live_engine/ directory with zero test regressions
- Split 2,188-line checkpoint.py monolith into 4-file checkpoint/ package (models, storage, engine, orchestrators) with full backward compatibility
- Extracted 3 orthogonal concerns (rectification, memory guard, vision cache) from backfill.py into sibling modules, reducing it from 1423 to 980 lines with full backward compatibility
- 1. [Rule 3 - Blocking] Renamed signal.py to yesterday_signal.py
- 10 Exness forex symbols registered in symbols.toml with ExnessSeederConfig pydantic-settings class for env-driven configuration
- Exness forex tick cache seeder downloading daily ZIPs from ticks.ex2archive.com with 3-column Parquet output, idempotent operation, and Telegram reporting
- systemd oneshot service with 1h timer, monit 2h freshness monitor, and 4 CLAUDE.md files updated for Exness forex seeder deployment infrastructure
- Kintsugi consumes sidecar's yesterday-repair signal file, injects flagged symbols at HEAD of repair queue with dedup, and clears signal after all shards processed
- 4 CLAUDE.md spokes for highest-complexity directories (src/, sidecar/, kintsugi/, checkpoint/) with source-derived file tables, domain-specific flow diagrams, and bidirectional parent links
- 4 new CLAUDE.md spoke files for validation (intermediate parent), processors, heartbeat, and heartbeat/checks (14-module index), plus day_mode parent chain fix
- Three CLAUDE.md spokes for compat (alpha-forge panel/manifest/availability), notify (Telegram @obdpy_bot integration), and ratelimit (file-based 6000 weight/min coordinator) with source-derived content
- Root CLAUDE.md hub table expanded from 13 to 24 entries with source-derived SSoT descriptions, full network verification: 24 files, 0 orphans, 0 broken parent links
- Plan:

---

## v1.4 Zero-Gap Zero-Overlap Guarantee (Shipped: 2026-03-23)

**Phases completed:** 6 phases, 16 plans, 32 tasks

**Key accomplishments:**

- Added last_completed_bar_tid field to OpenDeviationBarProcessor and Checkpoint, tracking completed bar trade IDs separately from forming bar tail for dedup floor initialization
- Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition
- Binance REST midnight crossover query and ClickHouse orphan verification for Stathera continuity at day boundaries
- \_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries
- Unified per-symbol Stathera continuity check replacing intra-day/adjacent-day classification, with LOUD Telegram alert on new today gaps
- Per-symbol yesterday orphan completion via crossover TID validation, junction telemetry from sidecar HTTP+journal, both visible in Telegram heartbeat
- Client-side ping with real 10s pong deadline, Binance 429/ban error classification, and CONNECT/FIRST_DATA/DISCONNECT stream signal emission on both per-symbol and combined WebSocket paths
- Sidecar /health endpoint with WS connection lifecycle tracking (CONNECT/FIRST_DATA/DISCONNECT) and heartbeat Telegram alerts with 429-fatal vs transient-disconnect classification
- Trade-ID continuity validation in write_ticks(), seeder routed through dedup path, systemd overlap prevention via Conflicts=
- File-based RateLimitCoordinator + PyAdaptiveRateLimiter PyO3 binding + kintsugi rate limit gating + per-process systemd ceiling env vars
- REST API fallback for yesterday's Vision gaps using two-step fetch, 6-symbol batch rotation with BTCUSDT priority, and kintsugi-processed day guard
- Aggregate REST utilization monitoring with sustained-90% LOUD alert, seeder days-behind metric, and weekly Vision vs REST oracle check
- Captured bit-exact golden snapshot fixtures (46 bars each) for BTCUSDT 2024-01-01 at threshold=250 in both Rust (JSON) and Python (Parquet) before any memory refactoring changes
- AggTrade Copy derive, zero-copy Arrow iterator adapter, and FormingBar 1 Hz throttle -- three Rust-side P0 memory optimizations with bit-exact oracle verification
- GIL released via py.detach() during pure Rust computation in process_trades_arrow() and process_trades_arrow_native() -- Python threads unblocked during 50-200ms bar processing
- Skip plugin Polars-Pandas roundtrip, footer-only Parquet row counting, Arrow REST fallback, and merged with_columns calls

---

## v1.4 v1.4 (Shipped: 2026-03-21)

**Phases completed:** 3 phases, 6 plans, 11 tasks

**Key accomplishments:**

- Added last_completed_bar_tid field to OpenDeviationBarProcessor and Checkpoint, tracking completed bar trade IDs separately from forming bar tail for dedup floor initialization
- Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition
- Binance REST midnight crossover query and ClickHouse orphan verification for Stathera continuity at day boundaries
- \_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries
- Unified per-symbol Stathera continuity check replacing intra-day/adjacent-day classification, with LOUD Telegram alert on new today gaps
- Per-symbol yesterday orphan completion via crossover TID validation, junction telemetry from sidecar HTTP+journal, both visible in Telegram heartbeat

---

## v1.4 Zero-Gap Zero-Overlap Guarantee (In Progress)

**Goal:** Eliminate ALL Stathera gaps and overlaps -- both intra-day junction gaps (committed_floors bug) and midnight boundary gaps (multi-processor seam) -- with full telemetry to validate.

**Phases:** 3 phases

| Phase | Name                            | Requirements     |
| ----- | ------------------------------- | ---------------- |
| 1     | Dedup Floor Fix                 | RUST-01, RUST-02 |
| 2     | Midnight Preflight Verification | PREFLIGHT-01..03 |
| 3     | Heartbeat Telemetry Overhaul    | TELEM-01..04     |

---

## v1.3 Atomic Restart Recovery (Shipped: 2026-03-21)

**Phases completed:** 2 phases, 4 plans, 6 tasks

**Key accomplishments:**

- Atomic DELETE+INSERT via store_bars_replacing() in \_sync_flush_rest_bars() with Polars conversion, Redis lock, and \_write_batch_with_retry fallback
- Today-only date filter on \_heal_day_boundary_gaps() Stathera query and valid_pairs passthrough for overlap heal call site
- Verified \_inline_startup_backfill(), \_startup_tid_reconciliation(), and \_gap_fill() watchdog call are already absent from sidecar.py -- all three PRUNE requirements satisfied
- Removed dead gap_fill_on_startup field from SidecarConfig, type stubs, CLI --no-gap-fill flag, and 9 test constructions

---

## v1.2 Performance (Shipped: 2026-03-20)

**Phases completed:** 4 phases, 5 plans, 8 tasks

**Key accomplishments:**

- Bounded ThreadPoolExecutor(max_workers=2) replaces unbounded threading.Thread in Telegram log sink, with dedicated 3s timeout to prevent thread exhaustion during kintsugi batch repairs
- Thread-local CH cache eliminates per-call fd churn in kintsugi workers, and 3-tier concurrency control prevents REST-only shards from diluting Parquet/Vision throughput
- Zero-allocation FixedPoint::from_f64() eliminates 4M allocs/day, cached CSV decompression removes O(N^2) ZIP re-parsing in IntraDayChunkIterator
- Eliminate per-iteration Vec::with_capacity(32) allocation in WS select loop via clear()+reuse pattern (RUST-03)
- Cached kintsugi config per repair (3 instantiations eliminated), dynamic Vision 404 TTL (15min for T-2 dates), and removed redundant DataFrame copy in bulk operations
