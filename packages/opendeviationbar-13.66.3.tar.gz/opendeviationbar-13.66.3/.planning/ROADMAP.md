# Roadmap: opendeviationbar-py v12.0

## Milestone: v12.0 FXView Forex -- Portcullis Bars

**Goal:** Novel Portcullis breach mode for forex bid/ask data -- contra-quote threshold detection that naturally filters illiquid regimes. Week ouroboros mode for weekend-void segregation. 38 streaming microstructure features per bar.
**Previous:** v11.0 Native Microsecond Timestamps (Phases 43-49, shipped 2026-04-01)

## Phases

- [x] **Phase 50: BreachMode Foundation** - Rust BreachMode enum, AggTrade bid/ask extension, PyO3 wiring, registry breach_mode field (completed 2026-04-04)
- [x] **Phase 51: Portcullis Breach Logic + Checkpoint** - Contra-quote threshold dispatch and checkpoint serialization (completed 2026-04-05)
- [x] **Phase 52: Week Ouroboros Mode** - Gap-based weekly reset for forex (data-driven, no hardcoded times), kintsugi weekend gap awareness (completed 2026-04-05)
- [x] **Phase 53: SpreadAccumulator Core** - 26 base streaming spread statistics with Option guards (completed 2026-04-05)
- [x] **Phase 54: SpreadAccumulator Advanced** - 12 advanced features with tier toggle (completed 2026-04-06)
- [x] **Phase 55: FXView Adapter + Registry** - Parquet adapter, synthetic trade IDs, forex symbol registration (completed 2026-04-06)
- [x] **Phase 56: ClickHouse Schema + End-to-End Wiring** - 37 spread columns, COMMENTs, full pipeline verification (completed 2026-04-06)
- [x] **Phase 57: Historical Backfill** - Full EURUSD + XAUUSD backfill with Stathera verification (completed 2026-04-06)
- [x] **Phase 58: Live Streaming** - Ring buffer consumer, standalone forex streaming service (completed 2026-04-06)

## Phase Details

### Phase 50: BreachMode Foundation

**Goal**: Processor can be constructed with any breach mode, AggTrade carries bid/ask quotes, and the registry declares which mode each market uses
**Depends on**: Nothing (foundation phase)
**Requirements**: BM-01, BM-02, BM-03, REG-03, VAL-01
**Success Criteria** (what must be TRUE):

1. `BreachMode` enum with `Last`, `Portcullis`, `Mid`, `Directional` variants compiles and is exhaustively matched in the processor hot path
2. `AggTrade` struct carries `best_bid: Option<FixedPoint>` and `best_ask: Option<FixedPoint>` while remaining `Copy`
3. `PyOpenDeviationBarProcessor(breach_mode="portcullis")` constructs successfully from Python with default "last" preserving backward compatibility
4. `MarketConfig.breach_mode` field exists and `get_market_config()` resolves it per symbol
5. Golden tests for BreachMode::Last produce bit-exact bars matching existing output (no regression)
   **Plans:** 4/4 plans complete

Plans:

- [x] 50-00-PLAN.md -- Wave 0: Golden test baseline capture + test stub scaffolding
- [x] 50-01-PLAN.md -- Rust core: BreachMode enum + AggTrade->Tick rename + bid/ask fields + workspace propagation
- [x] 50-02-PLAN.md -- PyO3 bindings + Python layer + registry + ClickHouse boundary mapping + all scripts
- [x] 50-03-PLAN.md -- Validation tests + full regression suite

### Phase 51: Portcullis Breach Logic + Checkpoint

**Goal**: Portcullis mode produces bars where wider spreads naturally resist breaches, filtering illiquid regimes
**Depends on**: Phase 50
**Requirements**: BM-04, BM-05
**Success Criteria** (what must be TRUE):

1. In Portcullis mode, bid tests upper threshold and ask tests lower threshold -- a bar with spread wider than threshold never breaches
2. Mid-price is used for OHLCV tracking in Portcullis mode (not last price)
3. Checkpoint serialization includes `breach_mode` and a Portcullis processor restored from checkpoint continues producing identical bars
4. Golden tests cover edge cases: 1-tick bar, 2-tick bar, wide-spread (no breach), zero-spread (behaves like Last), rollover bar, weekend gap bar
   **Plans:** 1/1 plans complete

Plans:

- [x] 51-01-PLAN.md -- Portcullis breach logic (dual price extraction, mid-price OHLCV) + checkpoint breach_mode persistence + PyO3 helpers

### Phase 52: Week Ouroboros Mode

**Goal**: Forex symbols use gap-based weekly reset boundaries driven by the natural weekend data void from FXView, with DST-correct session detection preserved as complementary infrastructure
**Depends on**: Nothing (independent of BreachMode)
**Requirements**: WK-01, WK-02, WK-03, WK-04
**Success Criteria** (what must be TRUE):

1. `OuroborosMode::Week` resets the processor when inter-trade gap exceeds 4 hours (data-driven, not hardcoded times), using `reset_at_ouroboros()` to emit orphan bars
2. Forex symbols in symbols.toml declare `ouroboros_mode = "week"` and bars never span the weekend void
3. Checkpoint save at week boundary discards the forming bar; restore on Sunday open creates a fresh processor
4. Kintsugi gap discovery classifies Friday-close-to-Sunday-open gaps as structural (not actionable) while detecting genuine within-week pipeline gaps
   **Plans:** 2/2 plans complete

Plans:

- [x] 52-01-PLAN.md -- Rust streaming: OuroborosMode::Week variant, gap-based reset, symbol_task wiring
- [x] 52-02-PLAN.md -- Python enum, registry parsing, symbols.toml update, PyO3 boundary

### Phase 53: SpreadAccumulator Core

**Goal**: Every Portcullis bar carries 26 streaming spread statistics computed in O(1) per tick with mathematically correct None guards
**Depends on**: Phase 50 (AggTrade bid/ask fields)
**Requirements**: SA-01, SA-03, VAL-02
**Success Criteria** (what must be TRUE):

1. `SpreadAccumulator` computes all 26 base statistics (spread OHLC, TWAS, Welford M1-M4, quote asymmetry, bid-ask imbalance, time-at-wide/tight, bid/ask OHLC, Kaufman ER) in a single streaming pass
2. Every statistic returns `Option<f64>` -- `None` when mathematical precondition fails (Welford variance: N>=2, skewness: N>=3 AND M2>0, kurtosis: N>=4 AND M2>0, TWAS: sum(dt)>0)
3. Feature tests verify `None` returns for all insufficient-N cases and M2=0 degenerate cases
4. Memory footprint is at most ~592 bytes per accumulator (no heap allocation)
   **Plans**: 3 plans

Plans:

- [x] 53-01-PLAN.md -- SpreadAccumulator struct + SpreadFeatures + update/finalize + comprehensive TDD tests
- [x] 53-02-PLAN.md -- Integration: 26 bar fields + processor hot path + checkpoint persistence
- [x] 53-03-PLAN.md -- Gap closure: fix compilation errors + wire SpreadAccumulator::update() into hot path

### Phase 54: SpreadAccumulator Advanced

**Goal**: 12 advanced spread features available behind a tier toggle for research/ML consumers
**Depends on**: Phase 53
**Requirements**: SA-02, SA-04
**Success Criteria** (what must be TRUE):

1. All 12 advanced features (spread_at_breach, spread_variance, quote_side_imbalance, quote_staleness_ratio, signed_tick_ratio, spread_price_correlation, tick_arrival_cv, spread_trajectory_shape, spread_autocorrelation, mid_momentum_ratio, executable_spread_ratio, worst_spread) compute correctly
2. `compute_spread_advanced: bool` constructor flag controls Tier 2+3 computation -- when false, advanced features return None without computing
3. `spread_at_breach` correctly reports the spread-to-average-spread ratio at the moment of bar breach
   **Plans:** 1/1 plans complete

Plans:

- [x] 54-01-PLAN.md -- SpreadAccumulator advanced state + 11 features + toggle + processor wiring + OpenDeviationBar fields

### Phase 55: FXView Adapter + Registry

**Goal**: FXView Parquet tick data flows into the ODB pipeline with globally monotonic trade IDs and proper forex symbol registration
**Depends on**: Phase 50 (BreachMode), Phase 53 (SpreadAccumulator)
**Requirements**: FX-01, FX-02, FX-03, REG-01, REG-02
**Success Criteria** (what must be TRUE):

1. FXView Parquet adapter converts `(time_msc, bid, ask)` to canonical ODB tick format at 39M+ ticks/sec via Polars->Arrow path
2. Synthetic trade IDs are globally monotonic across sessions (timestamp_us-based, not per-file row counter) and satisfy Stathera invariant
3. Edge cases handled: backward timestamp clamping, zero-spread pass-through, stale quote detection, weekend gap handling
4. `[markets.fxview_forex]` section in symbols.toml with tick cache path, spread tolerance, and breach_mode config
5. EURUSD ([10, 25, 50] dbps) and XAUUSD ([200, 500, 1000] dbps) enabled with correct forex thresholds
   **Plans:** 2/2 plans complete

Plans:

- [x] 55-01-PLAN.md -- FXView Rust adapter: types, conversion, synthetic ID generator, batch API + TDD tests
- [x] 55-02-PLAN.md -- Registry: [markets.fxview_forex] section + EURUSD/XAUUSD symbol entries in symbols.toml

### Phase 56: ClickHouse Schema + End-to-End Wiring

**Goal**: All 37 spread features flow from Rust processor through ClickHouse and back to Python query results
**Depends on**: Phase 54 (all SA features finalized)
**Requirements**: CH-01, CH-02, VAL-03
**Success Criteria** (what must be TRUE):

1. 37 new `Nullable(Float64)` columns exist on `open_deviation_bars` table via idempotent ALTER TABLE ADD COLUMN
2. Every new column has a COMMENT documenting meaning, formula, unit, min-N guard, and academic reference
3. End-to-end test: FXView Parquet -> Portcullis processor -> ClickHouse INSERT -> query returns spread features populated (non-null for bars with sufficient ticks)
   **Plans:** 2/2 plans complete

Plans:

- [x] 56-01-PLAN.md -- Arrow export + dict export + constants + schema.sql + column_comments (37 spread columns)
- [x] 56-02-PLAN.md -- INSERT/SELECT wiring + schema migration + end-to-end integration tests

### Phase 57: Historical Backfill

**Goal**: Complete forex bar history exists in ClickHouse with zero gaps and zero overlaps
**Depends on**: Phase 55 (adapter), Phase 56 (CH schema)
**Requirements**: HB-01, HB-02
**Success Criteria** (what must be TRUE):

1. EURUSD (~2,151 days) and XAUUSD (~2,042 days) fully backfilled from FXView Parquet tick cache using Portcullis breach mode
2. Stathera continuity audit reports 0 gaps and 0 overlaps for all forex partitions (6 partitions: 2 symbols x 3 thresholds each)
3. Week-mode boundaries verified: no bars span the weekend void
   **Plans:** 2/2 plans complete

Plans:

- [x] 57-01-PLAN.md -- Rust Arrow bid/ask extension + forex backfill script
- [x] 57-02-PLAN.md -- Run backfill on bigblack + Stathera verification

### Phase 58: Live Streaming

**Goal**: Standalone forex streaming service reads ring buffer ticks and writes Portcullis bars to ClickHouse with Stathera continuity
**Depends on**: Phase 57 (backfill proves pipeline)
**Requirements**: LS-01, LS-02
**Success Criteria** (what must be TRUE):

1. Ring buffer consumer reads FXView `/dev/shm/tick_ring_{SYMBOL}` ticks and feeds to StreamingOpenDeviationBarProcessor in Portcullis mode
2. Standalone forex streaming service runs alongside crypto sidecar with per-symbol breach mode resolved from registry
3. Bars written to ClickHouse maintain Stathera continuity across the backfill-to-live junction
   **Plans:** 2/2 plans complete

Plans:

- [x] 58-01-PLAN.md -- Ring buffer consumer + tick conversion + streaming service + unit tests
- [x] 58-02-PLAN.md -- systemd service unit + deployment readiness verification

## Progress

**Execution Order:** 50 -> 51 -> 52 (parallel with 50-51) -> 53 -> 54 -> 55 -> 56 -> 57 -> 58

| Phase                                     | Plans Complete | Status      | Completed  |
| ----------------------------------------- | -------------- | ----------- | ---------- |
| 50. BreachMode Foundation                 | 4/4            | Complete    | 2026-04-04 |
| 51. Portcullis Breach Logic + Checkpoint  | 1/1            | Complete    | 2026-04-05 |
| 52. Week Ouroboros Mode                   | 2/2            | Complete    | 2026-04-05 |
| 53. SpreadAccumulator Core                | 3/3            | Complete    | 2026-04-05 |
| 54. SpreadAccumulator Advanced            | 1/1            | Complete    | 2026-04-06 |
| 55. FXView Adapter + Registry             | 2/2            | Complete    | 2026-04-06 |
| 56. ClickHouse Schema + End-to-End Wiring | 2/2            | Complete    | 2026-04-06 |
| 57. Historical Backfill                   | 2/2            | Complete    | 2026-04-06 |
| 58. Live Streaming                        | 2/2 | Complete    | 2026-04-06 |

## Coverage Matrix

| Requirement | Phase | Description                                                                |
| ----------- | ----- | -------------------------------------------------------------------------- |
| BM-01       | 50    | BreachMode enum with 4 variants, exhaustive match                          |
| BM-02       | 50    | AggTrade best_bid/best_ask Option<FixedPoint> fields                       |
| BM-03       | 50    | PyO3 breach_mode keyword param (default "last")                            |
| BM-04       | 51    | Portcullis breach logic: bid upper, ask lower, mid OHLCV                   |
| BM-05       | 51    | Checkpoint serialization includes breach_mode                              |
| WK-01       | 52    | OuroborosMode::Week with gap-based reset (data-driven, no hardcoded times) |
| WK-02       | 52    | Forex symbols use ouroboros_mode = "week"                                  |
| WK-03       | 52    | Checkpoint save/restore for week-mode processor                            |
| WK-04       | 52    | Kintsugi gap discovery respects week boundaries                            |
| SA-01       | 53    | SpreadAccumulator 26 base statistics                                       |
| SA-02       | 54    | 12 advanced spread features                                                |
| SA-03       | 53    | All stats Option<f64> with math N-guards                                   |
| SA-04       | 54    | compute_spread_advanced tier toggle                                        |
| FX-01       | 55    | FXView Parquet adapter (time_msc, bid, ask) -> ODB                         |
| FX-02       | 55    | Globally monotonic synthetic trade IDs                                     |
| FX-03       | 55    | Edge cases: monotonicity, zero-spread, stale, weekend                      |
| REG-01      | 55    | [markets.fxview_forex] in symbols.toml                                     |
| REG-02      | 55    | EURUSD + XAUUSD enabled with forex thresholds                              |
| REG-03      | 50    | MarketConfig.breach_mode field                                             |
| CH-01       | 56    | 37 Nullable(Float64) columns via ALTER TABLE                               |
| CH-02       | 56    | Column COMMENTs: meaning, formula, unit, N-guard, ref                      |
| HB-01       | 57    | Full EURUSD + XAUUSD history backfill                                      |
| HB-02       | 57    | Stathera continuity: 0 gaps, 0 overlaps post-backfill                      |
| LS-01       | 58    | Ring buffer consumer -> Portcullis processor                               |
| LS-02       | 58    | Standalone forex streaming service alongside crypto sidecar                |
| VAL-01      | 50    | Golden tests for BreachMode::Last + serde backward compat                  |
| VAL-02      | 53    | SpreadAccumulator None-return tests                                        |
| VAL-03      | 56    | End-to-end: FXView -> Portcullis -> CH -> query                            |

**Coverage: 28/28 v12.0 requirements mapped. 0 orphans.**
