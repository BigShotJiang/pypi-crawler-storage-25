# Requirements: v12.0 FXView Forex — Portcullis Bars

**Defined:** 2026-04-03
**Core Value:** Novel Portcullis breach mode for forex bid/ask data — contra-quote threshold detection that naturally filters illiquid regimes. Week ouroboros mode for natural weekend-void segregation. 38 streaming microstructure features per bar, zero magic numbers.

## v12.0 Requirements

### Breach Mode Architecture

- [ ] **BM-01**: Rust `BreachMode` enum with `Last`, `Portcullis`, `Mid`, `Directional` variants and exhaustive match dispatch in processor hot path
- [ ] **BM-02**: `AggTrade` extended with `best_bid: Option<FixedPoint>` and `best_ask: Option<FixedPoint>` (16 bytes added, stays Copy)
- [ ] **BM-03**: PyO3 constructor accepts `breach_mode: str` keyword param (default "last", backward compatible)
- [ ] **BM-04**: Portcullis breach logic: bid tests upper threshold, ask tests lower threshold, mid-price for OHLCV tracking
- [ ] **BM-05**: Checkpoint serialization includes `breach_mode` for cross-session continuity

### Week Ouroboros Mode

- [ ] **WK-01**: `OuroborosMode::Week` variant implemented in Rust — processor resets at weekly boundary (Friday 17:00 ET / Sunday 17:00 ET, DST-correct via IANA timezone)
- [ ] **WK-02**: Forex symbols in symbols.toml use `ouroboros_mode = "week"` — bars never span the weekend void
- [ ] **WK-03**: Checkpoint save/restore handles week-mode processor state (forming bar discarded at week boundary, fresh processor on Sunday open)
- [ ] **WK-04**: Kintsugi gap discovery respects week boundaries — gaps across weekends are structural (not actionable), gaps within a week are pipeline gaps

### Spread Accumulator

- [ ] **SA-01**: `SpreadAccumulator` struct with 26 base statistics (spread OHLC, TWAS, Welford M1-M4, quote asymmetry, bid-ask imbalance, time-at-wide/tight, bid/ask OHLC, Kaufman ER)
- [ ] **SA-02**: 12 advanced features (spread_at_breach, spread_variance, quote_side_imbalance, quote_staleness_ratio, signed_tick_ratio, spread_price_correlation, tick_arrival_cv, spread_trajectory_shape, spread_autocorrelation, mid_momentum_ratio, executable_spread_ratio, worst_spread)
- [ ] **SA-03**: All statistics return `Option<f64>` with mathematically justified N-guards — no magic numbers (Welford: N>=2, skewness: N>=3 AND M2>0, kurtosis: N>=4 AND M2>0, TWAS: sum(dt)>0)
- [ ] **SA-04**: Feature toggle: Tier 2+3 features behind `compute_spread_advanced: bool` constructor flag

### FXView Adapter

- [ ] **FX-01**: Parquet adapter converts FXView `(time_msc, bid, ask)` → canonical ODB tick format with synthetic mid-price and monotonic trade IDs via Polars→Arrow path (39M ticks/sec validated)
- [ ] **FX-02**: Globally monotonic synthetic trade IDs for Stathera continuity across sessions (timestamp_us as ID base, not per-file row counter)
- [ ] **FX-03**: Edge case handling: timestamp monotonicity enforcement (clamp backwards ticks), zero-spread pass-through, stale quote detection, weekend gap handling

### Registry Integration

- [ ] **REG-01**: `[markets.fxview_forex]` section in symbols.toml with FXView-specific config (tick cache path pattern, spread tolerance, breach_mode)
- [ ] **REG-02**: EURUSD and XAUUSD symbol entries enabled with forex thresholds (EURUSD: [10, 25, 50] dbps; XAUUSD: [200, 500, 1000] dbps)
- [ ] **REG-03**: `MarketConfig` extended with `breach_mode` field — registry declares which mode each market uses

### ClickHouse Schema

- [ ] **CH-01**: 38 new Nullable(Float64) columns for spread microstructure features added to `open_deviation_bars` table via ALTER TABLE ADD COLUMN
- [ ] **CH-02**: Column COMMENTs on all new columns documenting meaning, formula, unit, min-N guard, and academic reference

### Historical Backfill

- [ ] **HB-01**: Full history backfill for EURUSD (~2,151 days) and XAUUSD (~2,042 days) from FXView Parquet tick cache using Portcullis breach mode
- [ ] **HB-02**: Stathera continuity verified after backfill: 0 gaps, 0 overlaps for all forex partitions

### Live Streaming

- [ ] **LS-01**: Ring buffer consumer reads FXView `/dev/shm/tick_ring_{SYMBOL}` ticks and feeds to StreamingOpenDeviationBarProcessor in Portcullis mode
- [ ] **LS-02**: Sidecar integration: forex symbols stream alongside crypto with per-symbol breach mode from registry

### Validation

- [x] **VAL-01**: Golden tests for Portcullis breach mode (edge cases: 1-tick, 2-tick, 3-tick, wide-spread, zero-spread, rollover, weekend gap bars)
- [ ] **VAL-02**: SpreadAccumulator feature tests verifying `None` returns for all insufficient-N cases and M2=0 degenerate cases
- [ ] **VAL-03**: End-to-end: FXView Parquet → Portcullis processor → ClickHouse → query with spread features populated

## Future Requirements

### Additional Forex Brokers

- **FUT-01**: Exness forex integration using existing exness_tick_cache_seeder (different tick format)
- **FUT-02**: Additional breach modes as enum variants

### Advanced Features

- **FUT-03**: P2 median spread estimator (100-byte streaming state)
- **FUT-04**: Spread-duration correlation (48-byte Welford co-moment)

## Out of Scope

| Feature                          | Reason                                                                     |
| -------------------------------- | -------------------------------------------------------------------------- |
| Microprice computation           | Requires order book depth (bid_size, ask_size) — not in FXView/Exness data |
| Futures forex integration        | No futures data source currently                                           |
| Cross-instrument spread features | Single-instrument focus; cross-instrument is separate milestone            |
| Pre-2022 FXView data             | Data starts 2022-01-03; Exness archives (2020+) are separate adapter       |

## Traceability

| Requirement | Phase | Status  |
| ----------- | ----- | ------- |
| BM-01       | 50    | Pending |
| BM-02       | 50    | Pending |
| BM-03       | 50    | Pending |
| BM-04       | 51    | Pending |
| BM-05       | 51    | Pending |
| WK-01       | 52    | Pending |
| WK-02       | 52    | Pending |
| WK-03       | 52    | Pending |
| WK-04       | 52    | Pending |
| SA-01       | 53    | Pending |
| SA-02       | 54    | Pending |
| SA-03       | 53    | Pending |
| SA-04       | 54    | Pending |
| FX-01       | 55    | Pending |
| FX-02       | 55    | Pending |
| FX-03       | 55    | Pending |
| REG-01      | 55    | Pending |
| REG-02      | 55    | Pending |
| REG-03      | 50    | Pending |
| CH-01       | 56    | Pending |
| CH-02       | 56    | Pending |
| HB-01       | 57    | Pending |
| HB-02       | 57    | Pending |
| LS-01       | 58    | Pending |
| LS-02       | 58    | Pending |
| VAL-01      | 50    | Complete |
| VAL-02      | 53    | Pending |
| VAL-03      | 56    | Pending |

**Coverage:** 28/28 requirements mapped. 0 orphans.

---

_Requirements defined: 2026-04-03_
