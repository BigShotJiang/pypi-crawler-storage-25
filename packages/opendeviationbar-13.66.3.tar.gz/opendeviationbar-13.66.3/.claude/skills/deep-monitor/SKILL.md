---
name: deep-monitor
description: >-
  Adversarial 9-perspective deep monitoring for the ODB pipeline on bigblack.
  Runs bit-exact Stathera trade-ID audits, sidecar crash-loop detection,
  kintsugi convergence analysis, junction integrity checks, data source
  verification, ClickHouse write path health, temporal freshness, genesis
  backfill progress, and registry compliance. Use whenever checking production
  health, diagnosing pipeline issues, investigating gaps or overlaps, verifying
  deploys, or running periodic monitoring. Also use when the user says "check
  bigblack", "run the monitor", "deep monitor", "how is the system", "any gaps",
  "is bigblack healthy", or "check services". This skill provides post-analysis
  telemetry on top of the existing heartbeat system.
allowed-tools: Read, Bash, Grep, Glob, Agent
---

# Deep Monitor: Adversarial Pipeline Health Audit

ultrathink

Multi-perspective production health check that catches failures the heartbeat system misses. Each perspective is designed to detect a different class of failure — a clean bill of health requires passing ALL 9.

## When to Use

- **Periodic monitoring**: Run every 10 minutes via cron, or on-demand
- **Post-deploy verification**: After any Tier 1/2/3 deploy via `/odb-ship`
- **Post-repair verification**: After `repair_direct_parquet.py` or kintsugi bulk reprocess
- **Incident investigation**: When heartbeat alerts fire, when gaps or overlaps are reported
- **User asks about system health**: "check bigblack", "any gaps?", "is the system healthy?"

## How to Run

The monitoring script lives at `.claude/skills/deep-monitor/scripts/deep_monitor.py` and runs **on bigblack** (not locally). It needs the ODB Python environment and ClickHouse access.

```bash
# Deploy script to bigblack (if not already there)
scp .claude/skills/deep-monitor/scripts/deep_monitor.py bigblack:/tmp/deep_monitor.py

# Run the monitor
ssh bigblack 'cd ~/opendeviationbar-py && .venv/bin/python3 /tmp/deep_monitor.py'
```

For recurring monitoring, use `/loop`:

```
/loop 10m Run the deep adversarial monitor on bigblack
```

## The 9 Perspectives

Each perspective answers a specific adversarial question. The system is healthy only when ALL 9 are green.

### 1. STATHERA ORACLE — "Is the ground truth clean?"

**What it checks**: Bit-exact trade-ID continuity across all 64 (symbol, threshold) partitions using the Stathera invariant: `bar[i].last_agg_trade_id + 1 == bar[i+1].first_agg_trade_id`.

**Normal**: `CLEAN — 0 gaps, 0 overlaps across 64 partitions`

**Concerning**:

- **Gaps > 0**: Missing trades between consecutive bars. Pipeline-induced (restart, crash-loop) or data source (Vision/REST).
- **Overlaps > 0**: Duplicate bars from different writers (sidecar, kintsugi, blaster). Expected temporarily after `repair_direct_parquet.py` — resolved by `OPTIMIZE TABLE FINAL`.

**Corrective actions**:

- Gaps with sidecar running: Kintsugi heals autonomously via stop→reprocess→restart
- Overlaps: Run `OPTIMIZE TABLE FINAL` on bigblack, or wait for kintsugi to trigger it
- Gaps diverging pass-over-pass: Check Perspective 3 (kintsugi creating residuals)

### 2. SIDECAR STABILITY — "Is the sidecar crash-looping?"

**What it checks**: Health endpoint (`localhost:8081/health`), PID churn over 10m/1h windows, crash vs planned restart distinction, error count.

**Normal**: `healthy (all subsystems OK)`, `Restarts (10m): 0 — STABLE`, `Errors (10m): 0`

**Concerning**:

- **UNREACHABLE**: Sidecar is down (mid-startup, crash-loop, or kintsugi stopped it for bulk reprocess)
- **CRASH-LOOP** (3+ crashes in 1h): Code bug — check journal for TypeError, ImportError, etc.
- **Errors > 0**: Check error messages — TypeError usually means v10.0 `symbol_or_key` regression

**Corrective actions**:

- UNREACHABLE during kintsugi bulk reprocess: Expected, wait for kintsugi to restart it
- CRASH-LOOP: Read journal (`journalctl --user -u opendeviationbar-sidecar -n 50`), fix the code bug, deploy via Tier 1/2
- Kintsugi's liveness check auto-starts downed sidecars — if it doesn't, restart kintsugi

### 3. KINTSUGI EFFECTIVENESS — "Is healing converging or diverging?"

**What it checks**: Last 5 kintsugi passes from NDJSON telemetry. Separates genesis (historical backfill) from pipeline gaps. Computes convergence trend.

**Normal**: `NO PIPELINE GAPS (genesis-only backfill)`, `Kintsugi errors (10m): 0`

**Concerning**:

- **Pipeline > 0**: Gaps created by sidecar restarts or code bugs. Should converge to 0 within 1-2 passes.
- **DIVERGING**: Gap count increasing pass-over-pass. Kintsugi's repair is creating new gaps (the #340 writer-boundary merge residual problem).
- **Failed > 0**: Repair failures (CH timeout, REST rate limit, Parquet missing).

**Corrective actions**:

- Pipeline gaps: Kintsugi handles autonomously — bulk reprocess if sidecar was running
- DIVERGING: Check if writer-boundary merge is enabled (should be disabled when sidecar active)
- Failed: Check if Parquet ticks exist for the failed symbol/date

### 4. JUNCTION INTEGRITY — "Did the last restart produce clean handoffs?"

**What it checks**: Post-restart junction telemetry (#342) — checkpoints loaded, REST bars produced, per-threshold resume TIDs, Parquet coverage.

**Normal**: `Checkpoints loaded: 62`, `REST bars produced: >0`, all symbols show `parquet_advanced=True`

**Concerning**:

- **Checkpoints loaded: 0**: No repair checkpoints found — sidecar starts with max() resume (fewer junction gaps but no forming bar state)
- **REST bars produced: 0**: `fill_from_rest` failed or returned no bars (API issue?)
- **parquet_advanced=False**: Parquet prefill didn't advance this symbol (seeder may not have data for today)

**Corrective actions**:

- Missing checkpoints: Run `repair_direct_parquet.py --all --execute` to generate them
- REST failure: Check Binance API rate limits, sidecar logs for REST errors

### 5. DATA SOURCE PURITY — "Is the raw tick data clean?"

**What it checks**: Parquet tick cache for today — trade-ID continuity within each symbol's daily file.

**Normal**: `CLEAN — 16 symbols, N ticks, 0 source gaps`

**Concerning**:

- **Source gaps > 0**: Vision or REST data has trade-ID discontinuities. This means Binance itself has gaps (exchange maintenance, API issues).
- **No Parquet files for today**: Seeder timer not running or failed

**Corrective actions**:

- Source gaps: These become exchange_gap entries in kintsugi_log — permanent and expected
- Missing Parquet: Check `systemctl --user is-active opendeviationbar-seeder.timer`

### 6. WRITE PATH HEALTH — "Is ClickHouse accepting writes?"

**What it checks**: Mutation queue (active vs stale >5min), active parts count, disk usage.

**Normal**: `Mutations: 0 active — idle` or `N active (all fresh — kintsugi healing)`, reasonable disk size

**Concerning**:

- **Stale mutations > 0**: Mutations stuck >5 minutes — possible CH contention, lock, or crash
- **Parts > 2000**: Too many unmerged parts — `OPTIMIZE TABLE FINAL` needed
- **Disk > 20 GiB**: Storage growing unexpectedly (duplicate bars, no merge)

**Corrective actions**:

- Stale mutations: `KILL MUTATION WHERE database = 'opendeviationbar_cache'`
- High parts: `OPTIMIZE TABLE opendeviationbar_cache.open_deviation_bars FINAL`

### 7. TEMPORAL FRESHNESS — "Are all symbols streaming?"

**What it checks**: Per-symbol latest bar time (stale if >30min), throughput (bars/min), newest bar age.

**Normal**: `All 16 symbols fresh (<30 min)`, `Throughput (10m): >50 bars`, `Newest bar: <60s ago`

**Concerning**:

- **Stale symbols**: Sidecar not streaming for those symbols (check sidecar config, WS connections)
- **Throughput 0/min**: Sidecar is down or in startup phase
- **Newest bar > 5min**: Sidecar alive but no bars being produced (low volatility or WS disconnected)

**Corrective actions**:

- All stale: Sidecar is down — check Perspective 2
- Some stale: Check if those symbols are in sidecar env var and registry
- Low throughput during kintsugi bulk reprocess: Expected (sidecar stopped temporarily)

### 8. GENESIS BACKFILL — "How far back does history go?"

**What it checks**: Per-symbol oldest bar date vs `effective_start` from `symbols.toml`. Shows coverage percentage.

**Normal**: `All 16 symbols have >99% historical coverage`

**Concerning**:

- **Incomplete history (<99%)**: Genesis backfill hasn't reached `effective_start` yet
- **Exchange gaps: N**: Permanent gaps where Binance never issued those trade IDs

**Corrective actions**:

- Incomplete: Run `repair_direct_parquet.py --all --execute` for one-shot full-history fill
- Exchange gaps are expected and permanent — no action needed

### 9. REGISTRY COMPLIANCE — "Does reality match symbols.toml?"

**What it checks**: Cross-references `symbols.toml` (SSoT) against ClickHouse bars and sidecar streaming state.

**Normal**: `Coverage: all enabled pairs have bars in ClickHouse`, `Streaming: all N symbols with fresh bars`

**Concerning**:

- **MISSING pairs**: Enabled in registry but 0 bars in CH — symbol never processed
- **NOT STREAMING**: Enabled in registry but sidecar not producing bars — check sidecar env var

**Corrective actions**:

- Missing pairs: Run blaster for that symbol
- Not streaming: Check `OPENDEVIATIONBAR_STREAMING_SYMBOLS` in `deploy/opendeviationbar.local.env`

## Interpreting the Final Verdict

```
VERDICT: ALL GREEN — system healthy across all 9 perspectives
```

System is fully operational. No action needed.

```
VERDICT: N CONCERN(S)
  STATHERA: X gaps + Y overlaps
  FRESHNESS: Z symbols stale
```

Each concern maps to a perspective above. Address in priority order:

1. **STATHERA** — ground truth. If this is dirty, everything else is suspect.
2. **SIDECAR** — if crash-looping, fix the code bug first.
3. **KINTSUGI** — if diverging, disable the writer-boundary merge.
4. **FRESHNESS** — if stale, check sidecar health.
5. **WRITES** — if stale mutations, kill them.
6. **SOURCE** — if Parquet gaps, check seeder.

## Context: Why 9 Perspectives?

The ODB pipeline has 4 interacting services (sidecar, kintsugi, heartbeat, seeder) writing to shared ClickHouse storage. A failure in any one can cascade to others. The existing heartbeat system uses boolean health gates with suppression logic that hides real problems (e.g., kintsugi healing suppresses Stathera alerts). This deep monitor shows raw truth without suppression — every anomaly is visible, classified, and actionable.

The 9 perspectives were chosen because each catches a different failure class:

- Perspectives 1-2: **Is the system running?** (ground truth + crash detection)
- Perspectives 3-4: **Is healing working?** (kintsugi convergence + restart quality)
- Perspective 5: **Is input data clean?** (source verification)
- Perspectives 6-7: **Is output working?** (write path + freshness)
- Perspectives 8-9: **Is coverage complete?** (history + registry compliance)

## Post-Execution Reflection

After running the monitor and presenting results, reflect before closing:

0. **Locate yourself.** Find this SKILL.md at `.claude/skills/deep-monitor/SKILL.md` before editing. All corrections target THIS file and `scripts/deep_monitor.py`.
1. **What failed?** If the script errored (SSH timeout, CH connection refused, Parquet read failure), fix the script to handle that case gracefully. If the interpretation was wrong (false positive, missed real issue), update the interpretation guidelines above.
2. **What worked better than expected?** If a perspective caught something the others missed, note it as a strength. If the user's feedback revealed a new failure class, add a new perspective.
3. **What drifted?** If ClickHouse schema changed, if new services were added, if thresholds or symbol counts changed — update the "Normal" baselines in each perspective section.
4. **Log it.** Update the script's docstring with the change date and reason.

Do NOT defer. The next invocation inherits whatever you leave behind.
