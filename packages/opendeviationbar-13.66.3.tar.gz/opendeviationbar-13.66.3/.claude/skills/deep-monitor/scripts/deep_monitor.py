# FILE-SIZE-OK: Single-file monitor script deployed to bigblack /tmp
"""Adversarial deep-dive monitor — production-ready post-analysis telemetry.

Checks the system from 8 adversarial perspectives, each designed to catch
a different class of failure. Outputs a self-documenting report that a
newcomer can read and understand without prior ODB knowledge.

Perspectives:
1. STATHERA ORACLE      — Bit-exact trade-ID continuity (the ground truth)
2. SIDECAR STABILITY    — Crash-loop detection, health endpoint, throughput
3. KINTSUGI EFFECTIVENESS — Is it healing or creating gaps? Convergence trend
4. JUNCTION INTEGRITY   — Post-restart REST→WS handoff quality (#342)
5. DATA SOURCE PURITY   — Parquet tick continuity (Vision/REST/WS)
6. WRITE PATH HEALTH    — ClickHouse mutations, parts, disk
7. TEMPORAL FRESHNESS   — Per-symbol staleness, bars/min throughput
8. GENESIS PROGRESS     — Historical backfill progress toward effective_start
"""

import json
import os
import subprocess
import time
from collections import Counter
from datetime import UTC, datetime, timedelta
from pathlib import Path


def _run(cmd, timeout=15):
    """Run a shell command, return stdout. Empty string on failure."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        return r.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return ""


def _journal_pids(service, since):
    """Extract distinct PIDs from journalctl for a service."""
    journal = _run(["journalctl", "--user", "-u", service, "--since", since, "--no-pager", "-o", "short"])
    pids = set()
    tag = f"{service}["
    for line in journal.split("\n"):
        if tag in line:
            try:
                start = line.index(tag) + len(tag)
                end = line.index("]", start)
                pids.add(line[start:end])
            except ValueError:
                pass
    return pids


def _journal_exit_codes(service, since):
    """Extract exit reasons from journalctl (code=exited, status=X)."""
    journal = _run(["journalctl", "--user", "-u", service, "--since", since, "--no-pager"])
    exits = {"clean": 0, "crash": 0}
    for line in journal.split("\n"):
        if "code=exited, status=0" in line:
            exits["clean"] += 1
        elif "code=exited" in line and "status=0" not in line:
            exits["crash"] += 1
        elif "code=killed" in line or "code=dumped" in line:
            exits["crash"] += 1
    return exits


ts = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")
print(f"{'='*72}")
print(f" DEEP ADVERSARIAL MONITOR — {ts}")
print(f"{'='*72}")

from opendeviationbar.clickhouse.cache import OpenDeviationBarCache
cache = OpenDeviationBarCache()

# =========================================================================
# 1. STATHERA ORACLE
# =========================================================================
print(f"\n{'─'*72}")
print("1. STATHERA ORACLE — Trade-ID Continuity (ground truth)")
print(f"{'─'*72}")

stathera = cache.client.query("""
SELECT symbol, threshold_decimal_bps,
    countIf(tid_delta > 0 AND NOT is_first) as gaps,
    countIf(tid_delta < 0 AND NOT is_first) as overlaps,
    count() as total_bars
FROM (
    SELECT symbol, threshold_decimal_bps,
        first_agg_trade_id - lagInFrame(last_agg_trade_id, 1) OVER (
            PARTITION BY symbol, threshold_decimal_bps
            ORDER BY first_agg_trade_id
        ) - 1 AS tid_delta,
        row_number() OVER (
            PARTITION BY symbol, threshold_decimal_bps
            ORDER BY first_agg_trade_id
        ) = 1 AS is_first
    FROM opendeviationbar_cache.open_deviation_bars FINAL
    WHERE first_agg_trade_id > 0
) GROUP BY symbol, threshold_decimal_bps
ORDER BY symbol, threshold_decimal_bps
""")

total_bars = sum(r[4] for r in stathera.result_rows)
anomalies = [(r[0], r[1], r[2], r[3]) for r in stathera.result_rows if r[2] > 0 or r[3] > 0]
n_partitions = len(stathera.result_rows)

if not anomalies:
    print(f"   CLEAN — 0 gaps, 0 overlaps across {n_partitions} partitions")
else:
    total_g = sum(a[2] for a in anomalies)
    total_o = sum(a[3] for a in anomalies)
    print(f"   ANOMALIES: {total_g} gaps + {total_o} overlaps in {len(anomalies)} partitions")
    for sym, thr, g, o in anomalies:
        print(f"     {sym}@{thr}: {g} gaps, {o} overlaps")
print(f"   Bars: {total_bars:,} across {n_partitions} partitions")

# =========================================================================
# 2. SIDECAR STABILITY
# =========================================================================
print(f"\n{'─'*72}")
print("2. SIDECAR STABILITY — Crash Detection & Health")
print(f"{'─'*72}")

# Health endpoint
try:
    import urllib.request
    resp = urllib.request.urlopen("http://localhost:8081/health", timeout=5)
    health = json.loads(resp.read())
    h_status = health["status"]
    checks = health.get("checks", {})
    failed_checks = [k for k, v in checks.items() if v is not True and v != "closed"]
    if failed_checks:
        print(f"   Health: {h_status} (FAILING: {', '.join(failed_checks)})")
    else:
        print(f"   Health: {h_status} (all subsystems OK)")
except Exception as e:
    print(f"   Health: UNREACHABLE — {e}")

# PID stability with crash vs planned restart distinction
for label, since in [("10m", "10 minutes ago"), ("1h", "1 hour ago")]:
    pids = _journal_pids("opendeviationbar-sidecar", since)
    exits = _journal_exit_codes("opendeviationbar-sidecar", since)
    n_restarts = max(0, len(pids) - 1)
    if n_restarts == 0:
        print(f"   Restarts ({label}): 0 — STABLE")
    else:
        detail = f"{exits['clean']} planned, {exits['crash']} crashes"
        severity = "CRASH-LOOP" if exits["crash"] >= 3 else "RESTART" if exits["crash"] > 0 else "planned"
        print(f"   Restarts ({label}): {n_restarts} ({detail}) — {severity}")

# Errors
journal_10m = _run(["journalctl", "--user", "-u", "opendeviationbar-sidecar",
                     "--since", "10 minutes ago", "--no-pager"])
errors = [l for l in journal_10m.split("\n") if "ERROR" in l or "TypeError" in l or "Traceback" in l]
if errors:
    print(f"   Errors (10m): {len(errors)}")
    for e in errors[:3]:
        print(f"     {e.strip()[:110]}")
else:
    print(f"   Errors (10m): 0")

# =========================================================================
# 3. KINTSUGI EFFECTIVENESS
# =========================================================================
print(f"\n{'─'*72}")
print("3. KINTSUGI EFFECTIVENESS — Convergence Trend")
print(f"{'─'*72}")

ndjson_path = Path("/home/tca/opendeviationbar-py/logs/kintsugi.ndjson")
passes = []
if ndjson_path.exists():
    for line in ndjson_path.open():
        try:
            e = json.loads(line)
            if e.get("event") == "pass_complete":
                passes.append(e)
        except (json.JSONDecodeError, KeyError):
            pass

kj_errors_10m = _run(["journalctl", "--user", "-u", "opendeviationbar-kintsugi",
                       "--since", "10 minutes ago", "--no-pager"])
kj_err_count = sum(1 for l in kj_errors_10m.split("\n") if "ERROR" in l or "TypeError" in l)

if passes:
    recent = passes[-5:]
    # Separate genesis (zero_trade) from pipeline gaps
    for p in recent:
        gd = p.get("gap_distribution", {})
        genesis = gd.get("zero_trade", 0)
        pipeline = p.get("total_discovered", 0) - genesis
        healed = p.get("healed", 0)
        failed = p.get("failed", 0)
        bars = p.get("total_bars", 0)
        dur = p.get("duration_s", 0)
        print(f"   {p.get('ts','?')[11:19]} genesis={genesis} pipeline={pipeline} "
              f"healed={healed} failed={failed} bars={bars:,} ({dur:.0f}s)")

    # Trend: are pipeline gaps converging?
    if len(passes) >= 3:
        last3 = passes[-3:]
        pipeline_counts = []
        for p in last3:
            gd = p.get("gap_distribution", {})
            pipeline_counts.append(p.get("total_discovered", 0) - gd.get("zero_trade", 0))
        trend = pipeline_counts[-1] - pipeline_counts[0]
        if all(c == 0 for c in pipeline_counts):
            print(f"   Trend: NO PIPELINE GAPS (genesis-only backfill)")
        elif trend > 0:
            print(f"   Trend: DIVERGING (+{trend} pipeline gaps) — investigate")
        elif trend < 0:
            print(f"   Trend: CONVERGING ({trend} pipeline gaps)")
        else:
            print(f"   Trend: FLAT ({pipeline_counts[-1]} pipeline gaps)")

    if any(p.get("failed", 0) > 0 for p in passes[-3:]):
        print(f"   WARNING: repair failures in recent passes")
else:
    print("   No kintsugi pass data")
print(f"   Kintsugi errors (10m): {kj_err_count}")

# =========================================================================
# 4. JUNCTION INTEGRITY — #342 telemetry
# =========================================================================
print(f"\n{'─'*72}")
print("4. JUNCTION INTEGRITY — REST→WS Handoff (#342)")
print(f"{'─'*72}")

events_path = Path("/home/tca/opendeviationbar-py/logs/events.jsonl")
junction_events = []
if events_path.exists():
    for line in events_path.open():
        try:
            e = json.loads(line)
            if e.get("event") == "junction_telemetry":
                junction_events.append(e)
        except (json.JSONDecodeError, KeyError):
            pass

if junction_events:
    # Group by timestamp (same restart) — take the most recent restart batch
    latest_ts = junction_events[-1].get("timestamp", "")[:19]
    latest_batch = [j for j in junction_events if j.get("timestamp", "")[:19] == latest_ts]

    print(f"   Last restart junction ({latest_ts}):")
    print(f"   Checkpoints loaded: {latest_batch[0].get('checkpoints_loaded', '?')}")
    print(f"   REST bars produced: {latest_batch[0].get('rest_bars_produced', '?')}")

    # Check for REST→WS gaps: ws_first_tid should be close to rest_last_tid
    # (The actual ws_first_tid is captured in _junction_state, not in NDJSON yet)
    for j in latest_batch[:3]:
        sym = j.get("symbol", "?")
        rest_last = j.get("rest_last_tid")
        resume = j.get("resume_tid")
        coverage = j.get("parquet_coverage")
        print(f"     {sym}: rest_last={rest_last} resume={resume} parquet_advanced={coverage}")

    if len(latest_batch) > 3:
        print(f"     ... +{len(latest_batch) - 3} more symbols")
else:
    print("   No junction events — sidecar hasn't restarted with new telemetry yet")

# =========================================================================
# 5. DATA SOURCE PURITY
# =========================================================================
print(f"\n{'─'*72}")
print("5. DATA SOURCE — Parquet Tick Continuity (today)")
print(f"{'─'*72}")

today = datetime.now(UTC).strftime("%Y-%m-%d")
ticks_base = Path(os.path.expanduser("~/.cache/opendeviationbar/ticks"))
checked = 0
source_gaps = 0
total_ticks = 0
if ticks_base.exists():
    for sym_dir in sorted(ticks_base.iterdir()):
        pq = sym_dir / f"{today}.parquet"
        if not pq.exists():
            continue
        try:
            import polars as pl
            df = pl.read_parquet(str(pq))
            tids = df.select("agg_trade_id").to_series().sort()
            diffs = tids.diff().drop_nulls()
            gaps = diffs.filter(diffs > 1)
            checked += 1
            total_ticks += len(df)
            if len(gaps) > 0:
                source_gaps += 1
                print(f"   {sym_dir.name}: {len(df):,} ticks, {len(gaps)} TID gaps (max={gaps.max()})")
        except Exception as exc:
            print(f"   {sym_dir.name}: read failed ({type(exc).__name__})")

if checked > 0 and source_gaps == 0:
    print(f"   CLEAN — {checked} symbols, {total_ticks:,} ticks, 0 source gaps")
elif source_gaps > 0:
    print(f"   {source_gaps}/{checked} symbols have source gaps — investigate Vision data")
else:
    print(f"   No Parquet files for today")

# =========================================================================
# 6. WRITE PATH HEALTH
# =========================================================================
print(f"\n{'─'*72}")
print("6. WRITE PATH — ClickHouse Mutations & Storage")
print(f"{'─'*72}")

# Mutations — distinguish active kintsugi healing (normal) from stale stuck mutations
mut_result = cache.client.query("""
SELECT count() as total,
       countIf(is_done = 0) as active,
       countIf(is_done = 0 AND create_time < now() - INTERVAL 5 MINUTE) as stale
FROM system.mutations
WHERE database = 'opendeviationbar_cache'
""")
total_mut, active_mut, stale_mut = mut_result.result_rows[0]

if stale_mut > 0:
    print(f"   Mutations: {active_mut} active ({stale_mut} STALE >5min) — investigate")
elif active_mut > 0:
    print(f"   Mutations: {active_mut} active (all fresh — kintsugi healing)")
else:
    print(f"   Mutations: 0 active — idle")

# Storage
parts = cache.client.query("""
SELECT count(), sum(rows), formatReadableSize(sum(bytes_on_disk))
FROM system.parts
WHERE database = 'opendeviationbar_cache' AND table = 'open_deviation_bars' AND active = 1
""")
p = parts.result_rows[0]
print(f"   Parts: {p[0]}, rows: {p[1]:,}, disk: {p[2]}")

# =========================================================================
# 7. TEMPORAL FRESHNESS
# =========================================================================
print(f"\n{'─'*72}")
print("7. TEMPORAL FRESHNESS — Per-Symbol Staleness & Throughput")
print(f"{'─'*72}")

now_us = int(time.time() * 1_000_000)
freshness = cache.client.query("""
SELECT symbol,
       max(close_time_us) as latest_close,
       count() as bar_count
FROM opendeviationbar_cache.open_deviation_bars FINAL
WHERE first_agg_trade_id > 0
GROUP BY symbol ORDER BY symbol
""")

stale = []
for row in freshness.result_rows:
    sym, latest, cnt = row
    age_min = (now_us - latest) / 1_000_000 / 60
    if age_min > 30:
        stale.append((sym, age_min))

if stale:
    print(f"   STALE (>30min): {len(stale)} symbols")
    for sym, age in stale:
        print(f"     {sym}: {age:.0f}min old")
else:
    print(f"   All {len(freshness.result_rows)} symbols fresh (<30 min)")

# Throughput: bars written in last 10 min
bars_10m = cache.client.query(f"""
SELECT count()
FROM opendeviationbar_cache.open_deviation_bars FINAL
WHERE first_agg_trade_id > 0
  AND close_time_us > {now_us - 600_000_000}
""")
bars_recent = bars_10m.result_rows[0][0]
bars_per_min = bars_recent / 10
print(f"   Throughput (10m): {bars_recent:,} bars ({bars_per_min:.0f}/min)")

# Newest bar
latest_all = cache.client.query("""
SELECT max(close_time_us) FROM opendeviationbar_cache.open_deviation_bars FINAL
WHERE first_agg_trade_id > 0
""")
latest_us = latest_all.result_rows[0][0]
latest_dt = datetime.fromtimestamp(latest_us / 1_000_000, tz=UTC)
age_s = (now_us - latest_us) / 1_000_000
print(f"   Newest bar: {latest_dt.strftime('%H:%M:%S UTC')} ({age_s:.0f}s ago)")

# =========================================================================
# 8. GENESIS BACKFILL PROGRESS
# =========================================================================
print(f"\n{'─'*72}")
print("8. GENESIS BACKFILL — Historical Coverage Progress")
print(f"{'─'*72}")

# Oldest bar per (symbol, threshold) — genesis backfill targets the youngest threshold
oldest = cache.client.query("""
SELECT symbol, threshold_decimal_bps,
       min(toDate(intDiv(open_time_us, 1000000), 'UTC')) as oldest_date
FROM opendeviationbar_cache.open_deviation_bars FINAL
WHERE first_agg_trade_id > 0
GROUP BY symbol, threshold_decimal_bps
ORDER BY symbol, threshold_decimal_bps
""")

try:
    from opendeviationbar.symbol_registry import get_symbol_entries
    entries = dict(get_symbol_entries())
except ImportError:
    entries = {}

today_date = datetime.now(UTC).date()
# Use the YOUNGEST oldest_date per symbol (the threshold furthest behind)
sym_youngest_oldest = {}
for row in oldest.result_rows:
    sym, thr, oldest_date = row
    if sym not in sym_youngest_oldest or oldest_date > sym_youngest_oldest[sym][1]:
        sym_youngest_oldest[sym] = (thr, oldest_date)

backfill_incomplete = []
for sym, (thr, oldest_date) in sorted(sym_youngest_oldest.items()):
    entry = entries.get(sym)
    if not entry:
        continue
    effective = getattr(entry, "effective_start", None) or getattr(entry, "listing_date", None)
    if not effective:
        continue
    total_days = (today_date - effective).days
    covered_days = (today_date - oldest_date).days
    pct = (covered_days / total_days * 100) if total_days > 0 else 100
    if pct < 99:
        backfill_incomplete.append((sym, oldest_date, effective, covered_days, total_days, pct))

if backfill_incomplete:
    print(f"   {len(backfill_incomplete)} symbols with incomplete history:")
    for sym, oldest_date, effective, covered, total, pct in backfill_incomplete[:8]:
        print(f"     {sym}: {oldest_date} → today ({covered}/{total} days = {pct:.0f}%, "
              f"effective_start={effective})")
    if len(backfill_incomplete) > 8:
        print(f"     ... +{len(backfill_incomplete) - 8} more")
else:
    print(f"   All {len(sym_youngest_oldest)} symbols have >99% historical coverage")

# Exchange gap inventory
exchange_gaps = cache.client.query("""
SELECT count() FROM opendeviationbar_cache.kintsugi_log
WHERE result = 'exchange_gap'
""")
eg_count = exchange_gaps.result_rows[0][0]
print(f"   Exchange gaps (permanent, expected): {eg_count}")

# =========================================================================
# 9. REGISTRY COMPLIANCE — symbols.toml SSoT cross-check
# =========================================================================
print(f"\n{'─'*72}")
print("9. REGISTRY COMPLIANCE — symbols.toml vs Reality")
print(f"{'─'*72}")

try:
    from opendeviationbar.symbol_registry import (
        get_registered_symbols,
        get_thresholds_for_symbol,
    )
    from opendeviationbar.threshold import get_min_threshold_for_symbol

    enabled = sorted(get_registered_symbols(enabled_only=True))
    print(f"   Registry: {len(enabled)} enabled symbols")

    # Check: every enabled symbol × valid threshold has bars in CH
    missing_pairs = []
    for sym in enabled:
        min_thr = get_min_threshold_for_symbol(sym)
        for thr in get_thresholds_for_symbol(sym):
            if thr < min_thr:
                continue
            # Check if this pair has any bars
            found = any(
                r[0] == sym and r[1] == thr
                for r in stathera.result_rows
            )
            if not found:
                missing_pairs.append((sym, thr))

    if missing_pairs:
        print(f"   MISSING: {len(missing_pairs)} (symbol, threshold) pairs have 0 bars in CH:")
        for sym, thr in missing_pairs[:10]:
            print(f"     {sym}@{thr}")
        if len(missing_pairs) > 10:
            print(f"     ... +{len(missing_pairs) - 10} more")
    else:
        print(f"   Coverage: all enabled pairs have bars in ClickHouse")

    # Check: sidecar is streaming all enabled symbols
    sidecar_syms_str = _run(["journalctl", "--user", "-u", "opendeviationbar-sidecar",
                              "-n", "200", "--no-pager"])
    streaming_syms = set()
    for line in sidecar_syms_str.split("\n"):
        if "symbols=" in line and "starting sidecar" in line:
            # Extract symbol list from startup log
            try:
                start = line.index("symbols=[") + len("symbols=[")
                end = line.index("]", start)
                syms_raw = line[start:end].replace("'", "").replace(" ", "")
                streaming_syms = set(syms_raw.split(","))
            except ValueError:
                pass
            break  # Only need the most recent startup

    if streaming_syms:
        not_streaming = set(enabled) - streaming_syms
        extra = streaming_syms - set(enabled)
        if not_streaming:
            print(f"   NOT STREAMING: {sorted(not_streaming)} (enabled but sidecar not configured)")
        elif extra:
            print(f"   EXTRA: {sorted(extra)} (streaming but not in registry)")
        else:
            print(f"   Streaming: all {len(enabled)} enabled symbols active in sidecar")
    else:
        # Fallback: check sidecar env var
        env_syms = os.environ.get("OPENDEVIATIONBAR_STREAMING_SYMBOLS", "")
        if env_syms:
            streaming_syms = set(s.strip() for s in env_syms.split(",") if s.strip())
            not_streaming = set(enabled) - streaming_syms
            if not_streaming:
                print(f"   NOT STREAMING: {sorted(not_streaming)} (env var missing these)")
            else:
                print(f"   Streaming: all {len(enabled)} symbols (from env var)")
        else:
            # Check health endpoint for symbol count
            # Check freshness query: symbols with bars in last 30 min = streaming
            streaming_count = sum(
                1 for r in freshness.result_rows
                if (now_us - r[1]) / 1_000_000 < 1800
            )
            streaming_unique = set(
                r[0] for r in freshness.result_rows
                if (now_us - r[1]) / 1_000_000 < 1800
            )
            not_streaming = set(enabled) - streaming_unique
            if not_streaming:
                print(f"   NOT STREAMING: {sorted(not_streaming)} (no bars in last 30min)")
            else:
                print(f"   Streaming: {len(streaming_unique)} symbols with fresh bars (matches registry)")


except ImportError as exc:
    print(f"   Registry check failed: {exc}")

cache.close()

# =========================================================================
# FINAL VERDICT
# =========================================================================
print(f"\n{'='*72}")
issues = []
if anomalies:
    issues.append(f"STATHERA: {sum(a[2] for a in anomalies)} gaps + {sum(a[3] for a in anomalies)} overlaps")
if errors:
    issues.append(f"SIDECAR: {len(errors)} errors in 10m")
if kj_err_count > 0:
    issues.append(f"KINTSUGI: {kj_err_count} errors in 10m")
if source_gaps > 0:
    issues.append(f"SOURCE: {source_gaps} symbols with Parquet gaps")
if stale_mut > 0:
    issues.append(f"WRITES: {stale_mut} stale mutations (>5min)")
if stale:
    issues.append(f"FRESHNESS: {len(stale)} symbols stale (>30min)")

if not issues:
    print(" VERDICT: ALL GREEN — system healthy across all 9 perspectives")
else:
    print(f" VERDICT: {len(issues)} CONCERN(S)")
    for i in issues:
        print(f"   {i}")
print(f"{'='*72}")
