---
name: gitnexus
description: GitNexus codebase intelligence — index, explore, debug, refactor, and impact analysis.
---

# GitNexus Skills Index

Route to the appropriate sub-skill based on the task:

| Task | Sub-Skill |
|---|---|
| Explore architecture / "How does X work?" | `gitnexus-exploring` |
| Blast radius / "What breaks if I change X?" | `gitnexus-impact-analysis` |
| Trace bugs / "Why is X failing?" | `gitnexus-debugging` |
| Rename / extract / split / refactor | `gitnexus-refactoring` |
| Tools, resources, schema reference | `gitnexus-guide` |
| Index, status, clean, wiki CLI commands | `gitnexus-cli` |
