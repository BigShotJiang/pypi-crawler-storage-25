#!/usr/bin/env bun
/**
 * PreToolUse:Bash — Sidecar lifecycle guard
 *
 * Blocks manual `systemctl stop/start/restart opendeviationbar-sidecar` on bigblack.
 * Kintsugi owns the sidecar lifecycle (stop→reprocess→checkpoint→restart).
 * Manual intervention creates race conditions with kintsugi's bulk reprocess cycle.
 *
 * ALLOWS: kintsugi restart (Tier 1/2 deploy pattern)
 * ALLOWS: heartbeat/seeder timer restart
 * ALLOWS: systemctl is-active (read-only status checks)
 * ALLOWS: Python scripts that manage their own lifecycle (repair_direct_parquet.py)
 *
 * Learned 2026-03-31: 124 sidecar PIDs in 24h from crash-loop + manual intervention
 * creating race conditions with kintsugi. Post-#342 architecture: kintsugi owns
 * sidecar lifecycle, odb-ship delivers code only.
 *
 * @see CLAUDE.md "Writer Ownership Model (#280)"
 */

interface PreToolUseInput {
  tool_name: string;
  tool_input: {
    command?: string;
    [key: string]: unknown;
  };
}

function ask(reason: string): string {
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: "ask",
      permissionDecisionReason: reason,
    },
  });
}

async function main(): Promise<void> {
  const stdin = await Bun.stdin.text();
  if (!stdin.trim()) return process.exit(0);

  let input: PreToolUseInput;
  try {
    input = JSON.parse(stdin);
  } catch {
    return process.exit(0); // Fail open
  }

  if (input.tool_name !== "Bash") return process.exit(0);
  const cmd = input.tool_input?.command || "";

  // Skip git commands (commit messages may contain blocked keywords)
  if (/^\s*git\s+(commit|log|diff|show|tag)/m.test(cmd)) return process.exit(0);

  // Only check ssh bigblack commands
  if (!/ssh\s+bigblack/i.test(cmd)) return process.exit(0);

  // Only block stop/start/restart (not is-active, status, etc.)
  if (!/systemctl\s+--user\s+(stop|start|restart)/i.test(cmd)) return process.exit(0);

  // Only block sidecar lifecycle
  if (!/opendeviationbar-sidecar/i.test(cmd)) return process.exit(0);

  // Exception: running a Python script that handles its own lifecycle
  if (/python3?\s+scripts\//i.test(cmd)) return process.exit(0);

  console.log(ask(
    "[SIDECAR-GUARD] Blocked: manual systemctl stop/start/restart on opendeviationbar-sidecar\n\n" +
    "Kintsugi owns the sidecar lifecycle. Manual intervention creates race conditions.\n\n" +
    "Correct patterns:\n" +
    "  Tier 1/2 deploy: rsync + systemctl --user restart opendeviationbar-kintsugi\n" +
    "  Full repair:     python3 scripts/repair_direct_parquet.py --all --execute\n" +
    "  Emergency only:  Stop kintsugi FIRST, then restart sidecar, then restart kintsugi"
  ));
  return process.exit(0);
}

void main();
