#pylint:disable=R0904, C0415, W1203
import sys
import getopt
import cmd
import os
import os.path
import logging
import configparser
# from argparse import ArgumentParser
from pathlib  import Path
import pyuac
from natlinkcore.configure import extensions_and_folders
from natlinkcore.configure import natlinkconfigfunctions
from platformdirs import  user_log_dir

# packages that should go with the do_p or do_P command, upgrading with pip
# is packages is already there:  todoDoug
packages_to_pip = ['natlinkcore', 'dragonfly', 'unimacro', 'vocola2']  ## 'caster' wanted here??]
appname="natlink"
logdir =  Path(user_log_dir(appname=appname,ensure_exists=True))
logfilename=logdir/"cli_log.txt"
file_handler = logging.FileHandler(logfilename)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logfile_logger = logging.getLogger()

handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.DEBUG)
logfile_logger.addHandler(handler)

file_handler.setLevel(logging.DEBUG)
logfile_logger.addHandler(file_handler)
logfile_logger.setLevel(logging.DEBUG) 


def _main(Options=None):
    """Catch the options and perform the resulting command line functions

    options: -i, --info: give status info
            --pre   enable prerelease options

             -I, --reginfo: give the info in the registry about Natlink
             etc., usage above...

    """


    shortOptions = "DVNOHKaAiIxXbBuqepPfF"
    shortArgOptions = "d:v:n:o:h:k:"
    if Options:
        if isinstance(Options, str):
            Options = Options.split(" ", 1)
        Options = [_.strip() for _ in  Options]
    else:
        Options = sys.argv[1:]

    try:
        options, args = getopt.getopt(Options, shortOptions+shortArgOptions,["pre"])
    except getopt.GetoptError:
        print(f'invalid option: {Options}')
        # cli.usage()
        return

    if args:
        print(f'should not have extraneous arguments: {args}')
    
    extra_pip_options = []
    if "--pre" in options:
        extra_pip_options.append("--pre")
        logging.info("pip extra option --pre")
        options.remove("--pre")
    cli = CLI(extra_pip_options=extra_pip_options)
    cli.Config = natlinkconfigfunctions.NatlinkConfig(cli.extra_pip_options)

    for o, v in options:
        o = o.lstrip('-')
        funcName = f'do_{o}'
        func = getattr(cli, funcName, None)
        if not func:
            print(f'option "{o}" not found in cli functions: "{funcName}"')
            cli.usage()
            continue
        if o in shortOptions:
            func(None) # dummy arg
        elif o in shortArgOptions:
            func(v)
        else:
            print('options should not come here')
            cli.usage()
    return cli

          
class CLI(cmd.Cmd):
    """provide interactive shell control for the different options.
    """
    def __init__(self, Config=None,extra_pip_options=None):
        cmd.Cmd.__init__(self)
        self.extra_pip_options=extra_pip_options or []
        self.pip_force_elevated = None  # command f or F
        self.prompt = '\nNatlink config> '
        self.info = "type 'u' for usage"
        self.Config = None
        self.message = ''
        self.accept_pip_commands = None
        # if __name__ == "__main__":
        #     print("Type 'u' for usage ")

    def stripCheckDirectory(self, dirName):
        """allow quotes in input, and strip them.
        
        Return "" if directory is not valid
        """
        if not dirName:
            return ""
        n = dirName.strip()
        while n and n.startswith('"'):
            n = n.strip('"')
        while n and n.startswith("'"):
            n = n.strip("'")
        if n:
            n.strip()
        
        if os.path.isdir(n):    
            return n
        print(f'not a valid directory: "{n}" ({dirName})')
        return ''

    def usage(self):
        """gives the usage of the command line options or options when
        the command line interface  (CLI) is used
        """
        print('-'*60)
        print(r"""Use either from the command line like 'natlinkconfigfunctions.py -i'
or in an interactive session using the CLI (command line interface). 

[Status]

i       - info, print information about the Natlink status
I       - show the natlink.ini file (in Notepad), you can manually edit.
j       - print PythonPath variable

[Natlink]

x/X     - enable/disable debug output of Natlink

[Vocola]

v/V     - enable/disable Vocola by setting/clearing VocolaUserDirectory,
          where the Vocola Command Files (.vcl) will be located.
          (~ or %HOME% are allowed, for example "~/.natlink/VocolaUser")

b/B     - enable/disable distinction between languages for Vocola user files
a/A     - enable/disable the possibility to use Unimacro actions in Vocola

[Unimacro]

o/O     - enable/disable Unimacro, by setting/clearing the UnimacroUserDirectory, where
          the Unimacro user INI files are located, and several other directories (~ or %HOME% allowed)

[DragonflyDirectory]
d/D     - enable/disable the DragonflyDirectory, the directory where
          you can put your Dragonfly scripts (UserDirectory can also be used)

[Install/configure]
f/F     - Force (thinking this process is) in elevated mode for installing packages (F), or force normal mode (f).
          

[UserDirectory]
n/N     - enable/disable UserDirectory, the directory where
          User Natlink grammar files are located (e.g., "~\UserDirectory")

[AutoHotkey]
h/H     - set/clear the AutoHotkey exe directory.
k/K     - set/clear the User Directory for AutoHotkey scripts.
[Extensions]
e       - give a list of python modules registered as extensions.
[Other]

u/usage - give this list
q       - quit

help <command>: give more explanation on <command>
        """)
        print('='*60)

    # info----------------------------------------------------------
    def do_i(self, arg):
        # self.Config.status()
        try:
            S = self.Config.status.getNatlinkStatusString()
            if self.pip_force_elevated is not None:
                if self.pip_force_elevated:
                    S = S + '\n--  Pip commands will need User Admin mode (elevated)'
                else:
                    S = S + '\n--  Pip commands will need normal mode (non elevated)'
            S = S + '\n\nIf you changed things, you must restart Dragon'
            print(S)
        except configparser.NoSectionError:
            print('No directories specified (yet). \nPlease specify one or more directories that Natlink should visit for grammar files')
            
    def do_I(self, arg):
        # inifile natlinkstatus.ini settings:

        self.Config.openConfigFile()
        
    def do_j(self, arg):
        # print PythonPath:
        
        self.Config.printPythonPath()

    def do_p(self, arg):
        """do pip packages
         
        Pass as parameter one of natlinkcore, dragonfly, unimacro, vocola2 or dtactions,
        
        or "all" to do them all.
        
        Check if elevated mode is required and prompt the user to restart in
        the correct mode if necessary.
        
        """
        result = self.check_elevated_mode()
        if not result:
            return False
        # packages_to_pip is global, see at top of thist file.
        if not arg:
            print(f'Please pass one of the packages {packages_to_pip}, or "all" to do them all.')
            return False
        
        wanted = arg.lower()
        if wanted == "all":
            packageslist = packages_to_pip
        elif wanted in packages_to_pip:
            packageslist = [wanted]
        else:
            print(f'Please pass one of the packages {packages_to_pip}, or "all" to do them all.')
            print(f'You passed: {arg}')
            return False
        
        for package in packageslist:   ## global variable
            logging.info(f'==== instal with --update {package} ===\n')
            params = ["--upgrade"]
                # self.config.do_pip_with_pre set to False for the moment. Not implemented
            result = self.Config.pip_package(package, params, False)
            if result:
                logging.info(f' ===\nsuccesfully pip installed with --upgrade: {package}\n====\n')
            else:
                logging.info(f' ===\nCould not pip install --upgrade: {package}\n====\n')
            return result
        
    def do_P(self, arg):
        """Upgrade pip packags with --pre mode on
            
            Not implemented here, because --pre does not not exist as a pip option.
            Send a message instead...
       
        """
        L = ['The command "P", pip with development updates, does not work as was expected.','',
             'If you need this option, go to "pypi.org", find your package,'
            'click on Releases, and on the wanted "pre" release.', '',
             'You will then find the pip command, which you',
             'can paste into "Windows Powershell" or "Command Prompt".', ''
            ]
        print('\n'.join(L))
        if self.want_elevated():
            print('Please start one of these programs in Elevated mode ("Run as Administrator"')
        else:
            print('You can start one of these programs in Normal mode (NOT as Administator)')
        # self.do_p("--pre")

    def check_elevated_mode(self):
        """Check if you are in correct mode, for doing pip commands
        """
        if self.pip_force_elevated is not None:
            # set to True of False by the "f" or "F" command...
            self.accept_pip_commands = None
        if self.accept_pip_commands is not None:
            return self.accept_pip_commands


        
        I_am_elevated = self.am_elevated() 
        I_want_elevated = self.want_elevated()
        print(f'check_elevated_mode: I_am_elevated: {I_am_elevated}, I_want_elevated: {I_want_elevated}')
        if I_am_elevated is I_want_elevated:
            self.accept_pip_commands = True
            return True
        # TODO QH
        self.accept_pip_commands = False
        if I_want_elevated:
            message = '\n'.join(["You need elevated mode for this function.",
                                "Please quit this process and restart the config program in elevated mode.",
                                "",
                                "The checking can be wrong.",
                                'If you still want to proceed in this process (normal mode), use the command "f" to do so'])
            print(message)
            return False

        # need non elevated, normal mode
        message = '\n'.join(["You do NOT need elevated mode for this function.",
                            "Please quit this process and restart the config program in normal mode.",
                            "",
                            'The checking can be wrong.',
                            'If you want to proceed in this "elevated" process, use the command "F" to do so'])
        print(message)
        return False
        



    def am_elevated(self):
        return pyuac.isUserAdmin()
    def want_elevated(self):
        r"""check if sys.executable has "\Users" in its path, then not elevated.
        
        """
        if self.pip_force_elevated in (True, False):
            # option "f" or "F" has been used:
            return self.pip_force_elevated
        exestr = sys.executable
        return exestr.lower().find(r'\users') == -1
        

    def do_f(self, arg):
        """normal mode for pip commands
        only needed if the default check does not give the wanted result
        """
        self.accept_pip_commands = None
        self.pip_force_elevated = False
        
    def do_F(self, arg):
        """want elevated mode for pip commands
        only needed if the default check does not give the wanted result
        """
        self.accept_pip_commands = None
        self.pip_force_elevated = True

    def help_f(self):
        print('-'*60)
        T = ["Normally the configure program (GUI or CLI) decides correct",
             "whether you need elevated mode or not.",
             'Non elevated when Python is installed in your user area.', '',
             r'The check is whether the path of "python.exe" starts with "\Users" (case insensitive).',
             '(If so: normal (non elevated) mode.)', '',
             'Only if this check does not give the correct result,',
             'you will need the options "f" or "F", for overriding above check.',
             'Do this command before you install (or update) pip modules,',
             'for example when you configure one of the packages,',
             'like Dragonfly, Vocola or Unimacro.', '',
             'So: option "f" for non-elevated mode,',
             'and option "F" for elevated (User Admin) mode.']
        print('\n'.join(T))

    help_F = help_f

    def help_p(self):
        print(''*60)
        print("""The commands "p" and "P" will pip upgrade the installed packages,
like natlinkcore, dragonfly, vocola2, unimacro.
Other modules will follow as dependencies.
(lower case) "p" will take only major releases,
(upper case) "P" will also take so called "pre" releases. This function does NOT WORK at the moment.

If you need elevated mode, and are not, of vice versa, the program will prompt you
to start in the correct mode.
              """)

    def do_e(self,arg):
        print("extensions and folders for registered natlink extensions:")
        ef=""
        for n,f in extensions_and_folders():
            ef+= f"\n{n} {f}" 
        print(ef)

    def help_i(self):
        print('-'*60)
        print("""The command info (i) gives an overview of the settings that are
currently set inside the Natlink system.

With command (I), you open the file "natlink.ini"

The command (j) gives the PythonPath variable which should contain several
Natlink directories after the config GUI runs succesfully

Settings are set by either the Natlink/Vocola/Unimacro installer
or by functions that are called by the CLI (command line interface).

After you change settings, restart Dragon.
""")
        print('='*60)
    help_j = help_I = help_i
    
    # User Directory, Dragonfly directory -------------------------------------------------
    # for easier remembering, change n to d (DragonFly)
    def do_d(self, arg):
        self.Config.enable_dragonfly(arg)
    
    def do_D(self, arg):
        self.Config.disable_dragonfly(arg)

    def do_n(self, arg):
        self.Config.setDirectory('UserDirectory', arg)
    
    def do_N(self, arg):
        self.Config.clearDirectory('UserDirectory')
    
    def help_n(self):
        print('-'*60)
        print('''Sets (n [<path>]) or clears (N) the "UserDirectory" of Natlink.
This is the folder where your own python grammar files are/will be located.
''')
    def help_d(self):
        print('-'*60)
        print('''Sets (d [<path>]) or clears (D) the "DragonflyUserDirectory".
This is the folder where your own Dragonfly python grammar files are/will be located.
''')
        
    help_N = help_n
    help_D = help_d
    
    # Unimacro User directory and Editor or Unimacro INI files-----------------------------------
    def do_o(self, arg):
        self.Config.enable_unimacro(arg)
        
            
    def do_O(self, arg):
        self.Config.disable_unimacro()

    def help_o(self):
        print('-'*60)
        print(r"""set/clear UnimacroUserDirectory (o <path>/O)


Setting this directory also enables Unimacro. Clearing it disables Unimacro

In this directory, your user INI files (and possibly other user
dependent files) will be put.

You can use (if entered through the CLI) "~" for user home directory, or
another environment variable (%%...%%). (example: "o ~\Documents\UnimacroUser")
""")
        print('='*60)

    help_O = help_o

    ### possibly in future re-wanted functions:
    # Unimacro Vocola features-----------------------------------------------
    # managing the include file wrapper business.
    # can be called from the Vocola compatibility button in the config GUI.
#     def do_l(self, arg):
#         self.message = "Copy include file Unimacro.vch into Vocola User Directory"
#         print(f'do action: {self.message}')
#         self.Config.copyUnimacroIncludeFile()
# 
#     def help_l(self):
#         print('-'*60)
#         print("""Copy Unimacro.vch header file into Vocola User Files directory      (l)
# 
# Insert/remove 'include Unimacro.vch' lines into/from each Vocola 
# command file                                                        (m/M)
# 
# Using Unimacro.vch, you can call Unimacro shorthand commands from a
# Vocola command.
# """)
#         print('='*60)
# 
#     def do_m(self, arg):
#         self.message = 'Insert "include Unimacro.vch" line in each Vocola Command File'
#         print(f'do action: {self.message}')
#         self.Config.enableVocolaTakesUnimacroActions()
#         
#     def do_M(self, arg):
#         self.message = 'Remove "include Unimacro.vch" line from each Vocola Command File'
#         print(f'do action: {self.message}')
#         self.Config.removeUnimacroVchLineInVocolaFiles()
#         print('and do action: disableVocolaTakesUnimacroActions')
#         self.Config.disableVocolaTakesUnimacroActions()
#         
#     help_m = help_M = help_l
    
    
    # Vocola and Vocola User directory------------------------------------------------
    def do_v(self, arg):
        """specify the VocolaUserDirectory,
        
        but the config needs also the VocolaDirectory and the VocolaGrammarsDirectory
        """
        self.Config.enable_vocola(arg)
                    
    def do_V(self, arg):
        """disable Vocola, arg not needed
        """
        self.Config.disable_vocola(arg)
        

    def help_v(self):
        print('-'*60)
        print(r"""Enable/disable Vocola by setting/clearing the VocolaUserDirectory
(v <path>/V).

In this VocolaUserDirectory your Vocola Command File are/will be located.

""")
        print('='*60)

    help_V = help_v
    

    # enable/disable Natlink debug output...
    def do_x(self, arg):
        self.message = 'Print debug output to "Messages from Natlink" window'
        print(f'do action: {self.message}')

        self.Config.setLogging('DEBUG')
    def do_X(self, arg):
        self.message = 'Disable printing debug output to "Messages from Natlink" window'
        print(f'do action: {self.message}')
        self.Config.setLogging('INFO')

    def help_x(self):
        print('-'*60)
        print("""Enable (x)/disable (X) Natlink debug output

This sends (sometimes lengthy) debug messages to the
"Messages from Natlink" window. Effectively this sets the
logging variable to "DEBUG" or "INFO"
""")
        print('='*60)

    help_X = help_x
    
    # different Vocola options
    def do_b(self, arg):
        self.message = "Enable Vocola different user directories for different languages"
        print(f'do action: {self.message}')
        self.Config.enableVocolaTakesLanguages()
    def do_B(self, arg):
        self.message = "Disable Vocola different user directories for different languages"
        print(f'do action: {self.message}')
        self.Config.disableVocolaTakesLanguages()

    def do_a(self, arg):
        self.message = "Enable Vocola taking Unimacro actions"
        print(f'do action: {self.message}')
        self.Config.enableVocolaTakesUnimacroActions()
        
    def do_A(self, arg):
        self.message = "Disable Vocola taking Unimacro actions"
        print(f'do action: {self.message}')
        self.Config.disableVocolaTakesUnimacroActions()

    def help_a(self):
        print('-'*60)
        print("""----Enable (a)/disable (A) Vocola taking Unimacro actions.
        
These actions (Unimacro Shorthand Commands) and "meta actions" are processed by
the Unimacro actions module (really dtactions)
""")
        print('='*60)
        
    def help_b(self):
        print('-'*60)
        print("""----Enable (b)/disable (B) different Vocola User Directories

If enabled, Vocola will look into a subdirectory "xxx" of
VocolaUserDirectory IF the language code of the current user speech
profile is "xxx" and  is NOT "enx".

So for English users this option will have no effect.

The first time a command file is opened in, for example, a
Dutch speech profile (language code "nld"), a subdirectory "nld" 
is created, and all existing Vocola Command files for this Dutch speech profile are copied into this folder.

When you use your English speech profile again, ("enx") the Vocola Command files in the VocolaUserDirectory are taken again.
""")
        print('='*60)

    help_B = help_b
    help_A = help_a

    # autohotkey settings:
    def do_h(self, arg):
        self.message = f'set directory of AutoHotkey.exe to: "{arg}"'
        print(f'do action: {self.message}')
        self.Config.setAhkExeDir(arg)

    def do_H(self, arg):
        self.message = 'clear directory of AutoHotkey.exe, return to default'
        print(f'do action: {self.message}')
        self.Config.clearAhkExeDir()

    def do_k(self, arg):
        self.message = f'set user directory for AutoHotkey scripts to: "{arg}"'
        print(f'do action: {self.message}')
        self.Config.setAhkUserDir(arg)

    def do_K(self, arg):
        self.message = 'clear user directory of AutoHotkey scripts, return to default'
        print(f'do action: {self.message}')
        self.Config.clearAhkUserDir()
            
    def help_h(self):
        print('-'*60)
        print("""----Set (h)/clear (return to default) (H) the AutoHotkey exe directory.
       Assume autohotkey.exe is found there (if not AutoHotkey support will not be there)
       If set to a invalid directory, AutoHotkey support will be switched off.
       
       Set (k)/clear (return to default) (K) the User Directory for AutoHotkey scripts.
       
       Note: currently these options can only be run from the natlinkconfigfunctions.py script.
""")
        print('='*60)

    help_H = help_k = help_K = help_h

    # enable/disable Natlink debug output...

    def default(self, line):
        print(f'no valid entry: "{line}", type "u" or "usage" for list of commands')
        print()

    def do_quit(self, arg):
        sys.exit()
    do_q = do_quit
    def do_usage(self, arg):
        self.usage()
    do_u = do_usage
    def help_u(self):
        print('-'*60)
        print("""u and usage give the list of commands
lowercase commands usually set/enable something
uppercase commands usually clear/disable something
Informational commands: i and I
""")
    help_usage = help_u


def main_cli():
    #a hack until we switch to ArgParse from getopt, check for --pre
    extra_pip_options = []
    if len(sys.argv) == 2 and sys.argv[1]=="--pre":
        extra_pip_options.append("--pre")
    
    if len(sys.argv) == 1 or ( len(sys.argv) == 2 and sys.argv[1]=="--pre"):
        if extra_pip_options:
            Cli = CLI(extra_pip_options=extra_pip_options)
        else:
            Cli = CLI()
            
        Cli.Config = natlinkconfigfunctions.NatlinkConfig(extra_pip_options=extra_pip_options)
        Cli.info = ""
        print('\nWelcome to the NatlinkConfig Command Line Interface\n')
        print('Type "I" for manual editing the "natlink.ini" config file\n')
        print('Type "u" for Usage\n')
        try:
            Cli.cmdloop()
        except (KeyboardInterrupt, SystemExit):
            pass

if __name__ == "__main__":
    main_cli()
else:
    _main()
    