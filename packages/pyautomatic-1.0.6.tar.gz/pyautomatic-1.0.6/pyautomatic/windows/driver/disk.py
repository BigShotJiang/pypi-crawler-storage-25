import struct
import ctypes
import os
import random
import ctypes
from ctypes import wintypes
import win32file
import win32api
import win32con
import winerror
import win32security
from typing import Union, Optional, BinaryIO, List, Tuple, Dict, Any
import binascii
import hashlib
import zlib
import time
from enum import Enum
from dataclasses import dataclass



# ==================== 常量和枚举 ====================
class DiskAccess(Enum):
    """磁盘访问权限"""
    READ_ONLY = 1
    READ_WRITE = 2
    WRITE_ONLY = 3

class DiskSectorSize(Enum):
    """磁盘扇区大小"""
    SECTOR_512 = 512
    SECTOR_4096 = 4096
    SECTOR_8192 = 8192

class DiskType(Enum):
    """磁盘类型"""
    PHYSICAL_DISK = 1
    LOGICAL_VOLUME = 2
    REMOVABLE_DISK = 3
    NETWORK_DRIVE = 4
    RAM_DISK = 5
    CDROM = 6

@dataclass
class DiskGeometry:
    """磁盘几何结构信息"""
    cylinders: int
    tracks_per_cylinder: int
    sectors_per_track: int
    bytes_per_sector: int
    disk_size: int
    media_type: int

@dataclass
class PartitionInfo:
    """分区信息"""
    partition_number: int
    partition_type: int
    start_offset: int
    partition_length: int
    hidden_sectors: int
    partition_bootable: bool
    file_system: str

# ==================== 磁盘操作常量 ====================
GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
FILE_SHARE_DELETE = 0x00000004
OPEN_EXISTING = 3
CREATE_ALWAYS = 2
FILE_ATTRIBUTE_NORMAL = 0x00000080
FILE_ATTRIBUTE_DEVICE = 0x00000040
FILE_FLAG_NO_BUFFERING = 0x20000000
FILE_FLAG_RANDOM_ACCESS = 0x10000000
FILE_FLAG_WRITE_THROUGH = 0x80000000
INVALID_HANDLE_VALUE = -1
FILE_BEGIN = 0
FILE_CURRENT = 1
FILE_END = 2

# IOCTL控制代码
IOCTL_DISK_GET_DRIVE_GEOMETRY = 0x00070000
IOCTL_DISK_GET_PARTITION_INFO = 0x00074004
IOCTL_DISK_GET_DRIVE_LAYOUT = 0x0007400C
IOCTL_DISK_GET_LENGTH_INFO = 0x00074018
IOCTL_DISK_VERIFY = 0x00070014
IOCTL_DISK_UPDATE_PROPERTIES = 0x00070140
IOCTL_DISK_EJECT_MEDIA = 0x00074808
IOCTL_DISK_LOAD_MEDIA = 0x0007480C
IOCTL_DISK_MEDIA_REMOVAL = 0x00074804
IOCTL_DISK_CHECK_VERIFY = 0x00074800
IOCTL_DISK_IS_WRITABLE = 0x00070024
IOCTL_STORAGE_GET_MEDIA_TYPES = 0x002D0C00
IOCTL_STORAGE_QUERY_PROPERTY = 0x002D1400
IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS = 0x00560000

# 错误代码
ERROR_SUCCESS = 0
ERROR_INVALID_FUNCTION = 1
ERROR_ACCESS_DENIED = 5
ERROR_INVALID_HANDLE = 6
ERROR_NOT_ENOUGH_MEMORY = 8
ERROR_INVALID_PARAMETER = 87
ERROR_WRITE_PROTECT = 19
ERROR_NOT_READY = 21
ERROR_CRC = 23
ERROR_SEEK = 25
ERROR_SECTOR_NOT_FOUND = 27
ERROR_WRITE_FAULT = 29
ERROR_READ_FAULT = 30
ERROR_GEN_FAILURE = 31
ERROR_SHARING_VIOLATION = 32
ERROR_LOCK_VIOLATION = 33
ERROR_WRONG_DISK = 34
ERROR_SHARING_BUFFER_EXCEEDED = 36
ERROR_HANDLE_EOF = 38
ERROR_HANDLE_DISK_FULL = 39
ERROR_NOT_SUPPORTED = 50

# ==================== 结构体定义 ====================
class STORAGE_PROPERTY_QUERY(ctypes.Structure):
    _fields_ = [
        ("PropertyId", ctypes.c_int),
        ("QueryType", ctypes.c_int),
        ("AdditionalParameters", ctypes.c_byte * 1)
    ]

class STORAGE_DEVICE_DESCRIPTOR(ctypes.Structure):
    _fields_ = [
        ("Version", ctypes.c_ulong),
        ("Size", ctypes.c_ulong),
        ("DeviceType", ctypes.c_byte),
        ("DeviceTypeModifier", ctypes.c_byte),
        ("RemovableMedia", ctypes.c_byte),
        ("CommandQueueing", ctypes.c_byte),
        ("VendorIdOffset", ctypes.c_ulong),
        ("ProductIdOffset", ctypes.c_ulong),
        ("ProductRevisionOffset", ctypes.c_ulong),
        ("SerialNumberOffset", ctypes.c_ulong),
        ("BusType", ctypes.c_int),
        ("RawPropertiesLength", ctypes.c_ulong),
        ("RawDeviceProperties", ctypes.c_byte * 1)
    ]

class DISK_GEOMETRY(ctypes.Structure):
    _fields_ = [
        ("Cylinders", ctypes.c_longlong),
        ("MediaType", ctypes.c_int),
        ("TracksPerCylinder", ctypes.c_ulong),
        ("SectorsPerTrack", ctypes.c_ulong),
        ("BytesPerSector", ctypes.c_ulong)
    ]

class PARTITION_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("StartingOffset", ctypes.c_longlong),
        ("PartitionLength", ctypes.c_longlong),
        ("HiddenSectors", ctypes.c_ulong),
        ("PartitionNumber", ctypes.c_ulong),
        ("PartitionType", ctypes.c_byte),
        ("BootIndicator", ctypes.c_byte),
        ("RecognizedPartition", ctypes.c_byte),
        ("RewritePartition", ctypes.c_byte)
    ]

# ==================== 异常类 ====================
class DiskError(Exception):
    """磁盘操作异常基类"""
    def __init__(self, error_code: int = 0, message: str = "磁盘操作错误"):
        self.error_code = error_code
        self.message = message
        super().__init__(f"[错误代码: {error_code}] {message}")

class DiskAccessDeniedError(DiskError):
    """磁盘访问被拒绝"""
    def __init__(self, error_code: int = 0, message: str = "磁盘访问被拒绝"):
        super().__init__(error_code, message)

class DiskWriteProtectedError(DiskError):
    """磁盘写保护"""
    def __init__(self, error_code: int = 0, message: str = "磁盘写保护"):
        super().__init__(error_code, message)

class DiskNotReadyError(DiskError):
    """磁盘未就绪"""
    def __init__(self, error_code: int = 0, message: str = "磁盘未就绪"):
        super().__init__(error_code, message)

class DiskSectorError(DiskError):
    """扇区操作错误"""
    def __init__(self, error_code: int = 0, message: str = "扇区操作错误"):
        super().__init__(error_code, message)

class DiskIOError(DiskError):
    """磁盘IO错误"""
    def __init__(self, error_code: int = 0, message: str = "磁盘IO错误"):
        super().__init__(error_code, message)

class DiskGeometryError(DiskError):
    """磁盘几何信息错误"""
    def __init__(self, error_code: int = 0, message: str = "磁盘几何信息错误"):
        super().__init__(error_code, message)

# ==================== 磁盘操作函数 ====================
def get_last_error() -> int:
    """获取最后的错误代码"""
    return win32api.GetLastError()

def format_error_code(error_code: int) -> str:
    """格式化错误代码为可读信息"""
    try:
        return win32api.FormatMessage(error_code)
    except:
        return f"错误代码: {error_code}"

def check_disk_access() -> bool:
    """检查是否有管理员权限"""
    try:
        return win32security.IsUserAnAdmin()
    except:
        return False

def is_physical_disk(device_path: str) -> bool:
    """检查是否为物理磁盘"""
    return device_path.startswith(r"\\.\PhysicalDrive")

def is_logical_volume(device_path: str) -> bool:
    """检查是否为逻辑卷"""
    return device_path.startswith(r"\\\\.\\") and len(device_path) == 6 and device_path[4].isalpha()

# ==================== 磁盘设备类 ====================
class DiskDevice:
    """增强的磁盘设备类，提供完整的磁盘操作功能"""

    def __init__(self, device_name: str):
        """
        初始化磁盘设备
        Args:
            device_name: 设备名，如 "\\\\.\\PhysicalDrive0" 或 "\\\\.\\C:"
        """
        self.device_name = device_name
        self.handle = None
        self.sector_size = 512
        self.total_sectors = 0
        self.total_bytes = 0
        self.geometry = None
        self.is_physical = is_physical_disk(device_name)
        self.is_logical = is_logical_volume(device_name)
        self.opened = False
        self.read_only = True
        self._lock_count = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __str__(self):
        return f"DiskDevice({self.device_name}, sectors={self.total_sectors}, size={self.get_human_readable_size()})"

    def __repr__(self):
        return str(self)

    def open(self, access: DiskAccess = DiskAccess.READ_ONLY, exclusive: bool = False) -> bool:
        """
        打开磁盘设备
        Args:
            access: 访问权限
            exclusive: 是否独占访问
        Returns:
            bool: 是否成功打开
        """
        if self.opened:
            return True

        try:
            desired_access = 0
            share_mode = 0

            if access in [DiskAccess.READ_ONLY, DiskAccess.READ_WRITE]:
                desired_access |= GENERIC_READ
                share_mode |= FILE_SHARE_READ

            if access in [DiskAccess.READ_WRITE, DiskAccess.WRITE_ONLY]:
                desired_access |= GENERIC_WRITE
                share_mode |= FILE_SHARE_WRITE

            if not exclusive:
                share_mode |= FILE_SHARE_READ | FILE_SHARE_WRITE

            flags = FILE_ATTRIBUTE_NORMAL
            if self.is_physical:
                flags |= FILE_FLAG_NO_BUFFERING | FILE_FLAG_WRITE_THROUGH

            self.handle = win32file.CreateFile(
                self.device_name,
                desired_access,
                share_mode,
                None,
                OPEN_EXISTING,
                flags,
                None
            )

            if self.handle == INVALID_HANDLE_VALUE:
                error = get_last_error()
                if error == ERROR_ACCESS_DENIED:
                    raise DiskAccessDeniedError(f"访问被拒绝: {self.device_name}")
                elif error == ERROR_SHARING_VIOLATION:
                    raise DiskAccessDeniedError(f"设备被其他进程占用: {self.device_name}")
                else:
                    raise DiskError(f"打开设备失败: {format_error_code(error)}")

            self._get_disk_info()
            self.opened = True
            self.read_only = (access == DiskAccess.READ_ONLY)
            return True

        except Exception as e:
            self.close()
            raise

    def close(self):
        """关闭磁盘设备"""
        if self.handle and self.handle != INVALID_HANDLE_VALUE:
            win32file.CloseHandle(self.handle)

        self.handle = None
        self.opened = False
        self._lock_count = 0

    def _get_disk_info(self):
        """获取磁盘信息"""
        try:
            geometry = DISK_GEOMETRY()
            bytes_returned = wintypes.DWORD()

            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                IOCTL_DISK_GET_DRIVE_GEOMETRY,
                None, 0,
                ctypes.byref(geometry), ctypes.sizeof(geometry),
                ctypes.byref(bytes_returned),
                None
            )

            if result:
                self.sector_size = geometry.BytesPerSector
                self.geometry = DiskGeometry(
                    cylinders=geometry.Cylinders,
                    tracks_per_cylinder=geometry.TracksPerCylinder,
                    sectors_per_track=geometry.SectorsPerTrack,
                    bytes_per_sector=geometry.BytesPerSector,
                    disk_size=geometry.Cylinders * geometry.TracksPerCylinder *
                               geometry.SectorsPerTrack * geometry.BytesPerSector,
                    media_type=geometry.MediaType
                )

                length_info = ctypes.c_ulonglong(0)
                bytes_returned = wintypes.DWORD()

                result = ctypes.windll.kernel32.DeviceIoControl(
                    self.handle,
                    IOCTL_DISK_GET_LENGTH_INFO,
                    None, 0,
                    ctypes.byref(length_info), ctypes.sizeof(length_info),
                    ctypes.byref(bytes_returned),
                    None
                )

                if result:
                    self.total_bytes = length_info.value
                else:
                    self.total_bytes = self.geometry.disk_size

                self.total_sectors = self.total_bytes // self.sector_size

        except Exception:
            try:
                _, total_bytes, _ = win32api.GetDiskFreeSpaceEx(self.device_name)
                self.total_bytes = total_bytes
                self.total_sectors = total_bytes // self.sector_size
            except:
                pass

    def get_human_readable_size(self) -> str:
        """获取人类可读的磁盘大小"""
        return format_size(self.total_bytes)

    def seek(self, offset: int, whence: int = FILE_BEGIN) -> int:
        """
        移动文件指针
        Args:
            offset: 偏移量
            whence: 起始位置
        Returns:
            int: 新的文件指针位置
        """
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        new_ptr = win32file.SetFilePointer(self.handle, offset, whence)
        if new_ptr == 0xFFFFFFFF:
            error = get_last_error()
            if error != ERROR_SUCCESS:
                raise DiskError(f"移动文件指针失败: {format_error_code(error)}")

        return new_ptr

    def tell(self) -> int:
        """获取当前文件指针位置"""
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        return self.seek(0, FILE_CURRENT)

    def lock_volume(self) -> bool:
        """锁定卷（防止其他进程访问）"""
        if not self.opened:
            return False

        try:
            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                0x00090018,
                None, 0, None, 0, None, None
            )
            if result:
                self._lock_count += 1
            return bool(result)
        except:
            return False

    def unlock_volume(self) -> bool:
        """解锁卷"""
        if not self.opened or self._lock_count == 0:
            return False

        try:
            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                0x0009001C,
                None, 0, None, 0, None, None
            )
            if result:
                self._lock_count = max(0, self._lock_count - 1)
            return bool(result)
        except:
            return False

    def dismount_volume(self) -> bool:
        """卸载卷"""
        if not self.opened:
            return False

        try:
            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                0x00090020,
                None, 0, None, 0, None, None
            )
            return bool(result)
        except:
            return False

    def is_write_protected(self) -> bool:
        """检查磁盘是否写保护"""
        if not self.opened:
            return False

        try:
            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                IOCTL_DISK_IS_WRITABLE,
                None, 0, None, 0, None, None
            )
            return not bool(result)
        except:
            return False

    def read_sectors(self, start_sector: int, num_sectors: int = 1) -> bytes:
        """
        读取磁盘扇区
        Args:
            start_sector: 起始扇区号
            num_sectors: 要读取的扇区数
        Returns:
            bytes: 读取的数据
        """
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        if start_sector < 0 or num_sectors <= 0:
            raise ValueError("起始扇区号必须>=0，扇区数必须>0")

        if start_sector + num_sectors > self.total_sectors:
            raise ValueError(f"读取范围超出磁盘边界: {start_sector}+{num_sectors} > {self.total_sectors}")

        offset = start_sector * self.sector_size
        size = num_sectors * self.sector_size

        self.seek(offset, FILE_BEGIN)

        try:
            hr, data = win32file.ReadFile(self.handle, size)
            if hr != 0:
                raise DiskIOError(f"读取扇区失败: {format_error_code(hr)}")

            if len(data) != size:
                raise DiskIOError(f"读取数据不完整: 期望{size}字节，实际{len(data)}字节")

            return data

        except Exception as e:
            if isinstance(e, DiskIOError):
                raise
            raise DiskIOError(f"读取扇区失败: {str(e)}")

    def write_sectors(self, start_sector: int, data: bytes) -> bool:
        """
        写入磁盘扇区
        Args:
            start_sector: 起始扇区号
            data: 要写入的数据
        Returns:
            bool: 是否成功
        """
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        if self.read_only:
            raise DiskWriteProtectedError("磁盘以只读方式打开")

        if self.is_write_protected():
            raise DiskWriteProtectedError("磁盘写保护")

        if start_sector < 0:
            raise ValueError("起始扇区号必须>=0")

        data_len = len(data)
        if data_len % self.sector_size != 0:
            raise ValueError(f"数据长度({data_len})必须是扇区大小({self.sector_size})的整数倍")

        if start_sector + (data_len // self.sector_size) > self.total_sectors:
            raise ValueError(f"写入范围超出磁盘边界")

        offset = start_sector * self.sector_size
        self.seek(offset, FILE_BEGIN)

        try:
            hr, bytes_written = win32file.WriteFile(self.handle, data)
            if hr != 0:
                raise DiskIOError(f"写入扇区失败: {format_error_code(hr)}")

            win32file.FlushFileBuffers(self.handle)
            return bytes_written == data_len

        except Exception as e:
            raise DiskIOError(f"写入扇区失败: {str(e)}")

    def read_bytes(self, offset: int, size: int) -> bytes:
        """
        读取指定字节
        Args:
            offset: 字节偏移
            size: 要读取的大小
        Returns:
            bytes: 读取的数据
        """
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        if offset < 0 or size <= 0:
            raise ValueError("偏移必须>=0，大小必须>0")

        if offset + size > self.total_bytes:
            raise ValueError(f"读取范围超出磁盘边界")

        self.seek(offset, FILE_BEGIN)

        try:
            hr, data = win32file.ReadFile(self.handle, size)
            if hr != 0:
                raise DiskIOError(f"读取字节失败: {format_error_code(hr)}")

            return data

        except Exception as e:
            raise DiskIOError(f"读取字节失败: {str(e)}")

    def write_bytes(self, offset: int, data: bytes) -> bool:
        """
        写入指定字节
        Args:
            offset: 字节偏移
            data: 要写入的数据
        Returns:
            bool: 是否成功
        """
        if not self.opened:
            raise DiskError("磁盘设备未打开")

        if self.read_only:
            raise DiskWriteProtectedError("磁盘以只读方式打开")

        if self.is_write_protected():
            raise DiskWriteProtectedError("磁盘写保护")

        if offset < 0:
            raise ValueError("偏移必须>=0")

        if offset + len(data) > self.total_bytes:
            raise ValueError(f"写入范围超出磁盘边界")

        self.seek(offset, FILE_BEGIN)

        try:
            hr, bytes_written = win32file.WriteFile(self.handle, data)
            if hr != 0:
                raise DiskIOError(f"写入字节失败: {format_error_code(hr)}")

            win32file.FlushFileBuffers(self.handle)
            return bytes_written == len(data)

        except Exception as e:
            raise DiskIOError(f"写入字节失败: {str(e)}")

    def verify_sectors(self, start_sector: int, num_sectors: int = 1) -> bool:
        """
        验证扇区可读性
        Args:
            start_sector: 起始扇区
            num_sectors: 扇区数
        Returns:
            bool: 是否可读
        """
        if not self.opened:
            return False

        try:
            verify_info = struct.pack("<QQ", start_sector * self.sector_size,
                                      num_sectors * self.sector_size)

            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                IOCTL_DISK_VERIFY,
                verify_info, len(verify_info),
                None, 0, None, None
            )

            return bool(result)
        except:
            return False

    def get_partition_info(self) -> List[PartitionInfo]:
        """
        获取分区信息
        Returns:
            List[PartitionInfo]: 分区信息列表
        """
        if not self.opened or not self.is_physical:
            return []

        partitions = []
        try:
            buffer_size = 1024 * 1024
            buffer = ctypes.create_string_buffer(buffer_size)
            bytes_returned = wintypes.DWORD()

            result = ctypes.windll.kernel32.DeviceIoControl(
                self.handle,
                IOCTL_DISK_GET_DRIVE_LAYOUT,
                None, 0,
                buffer, buffer_size,
                ctypes.byref(bytes_returned),
                None
            )
        except Exception:
            pass

        return partitions

    def get_disk_signature(self) -> int:
        """
        获取磁盘签名
        Returns:
            int: 磁盘签名
        """
        try:
            mbr = self.read_sectors(0, 1)
            if len(mbr) >= 440:
                signature = struct.unpack("<I", mbr[440:444])[0]
                return signature
        except:
            pass
        return 0

    def calculate_hash(self, algorithm: str = "md5") -> str:
        """
        计算整个磁盘的哈希值
        Args:
            algorithm: 哈希算法(md5, sha1, sha256)
        Returns:
            str: 哈希值
        """
        if not self.opened:
            return ""

        chunk_size = 1024 * 1024
        total_read = 0
        hasher = hashlib.new(algorithm)
        self.seek(0, FILE_BEGIN)

        while total_read < self.total_bytes:
            to_read = min(chunk_size, self.total_bytes - total_read)
            try:
                data = self.read_bytes(total_read, to_read)
                hasher.update(data)
                total_read += len(data)
            except Exception:
                break

        return hasher.hexdigest()

    def create_backup(self, output_file: str, sectors: List[Tuple[int, int]] = None) -> bool:
        """
        创建磁盘备份
        Args:
            output_file: 输出文件路径
            sectors: 要备份的扇区列表
        Returns:
            bool: 是否成功
        """
        if not self.opened:
            return False

        try:
            with open(output_file, 'wb') as f:
                if sectors is None:
                    chunk_size = 1024 * 1024
                    total_written = 0
                    while total_written < self.total_bytes:
                        to_read = min(chunk_size, self.total_bytes - total_written)
                        data = self.read_bytes(total_written, to_read)
                        f.write(data)
                        total_written += len(data)
                else:
                    for start_sector, num_sectors in sectors:
                        data = self.read_sectors(start_sector, num_sectors)
                        f.write(data)
            return True
        except Exception:
            return False

    def restore_backup(self, input_file: str, start_sector: int = 0) -> bool:
        """
        从备份文件恢复
        Args:
            input_file: 输入文件路径
            start_sector: 起始扇区
        Returns:
            bool: 是否成功
        """
        if not self.opened or self.read_only:
            return False

        try:
            file_size = os.path.getsize(input_file)
            with open(input_file, 'rb') as f:
                chunk_size = 1024 * 1024
                total_written = 0
                current_sector = start_sector

                while total_written < file_size:
                    data = f.read(chunk_size)
                    if not data:
                        break

                    remainder = len(data) % self.sector_size
                    if remainder > 0:
                        data += b'\x00' * (self.sector_size - remainder)

                    num_sectors = len(data) // self.sector_size
                    self.write_sectors(current_sector, data)

                    current_sector += num_sectors
                    total_written += len(data)

            return True
        except Exception:
            return False

    def fill_pattern(self, pattern: bytes, start_sector: int = 0,
                     num_sectors: int = None) -> bool:
        """
        用模式填充磁盘
        Args:
            pattern: 填充模式
            start_sector: 起始扇区
            num_sectors: 扇区数
        Returns:
            bool: 是否成功
        """
        if not self.opened or self.read_only:
            return False

        if not pattern:
            raise ValueError("模式不能为空")

        if num_sectors is None:
            num_sectors = self.total_sectors - start_sector

        if start_sector < 0 or num_sectors <= 0:
            raise ValueError("起始扇区必须>=0，扇区数必须>0")

        if start_sector + num_sectors > self.total_sectors:
            raise ValueError(f"填充范围超出磁盘边界")

        pattern_len = len(pattern)
        if pattern_len % self.sector_size != 0:
            repeat_count = (self.sector_size // pattern_len) + 1
            pattern = (pattern * repeat_count)[:self.sector_size]

        try:
            self.write_sectors(start_sector, pattern * num_sectors)
            return True
        except Exception:
            return False

    def secure_erase(self, passes: int = 1) -> bool:
        """
        安全擦除磁盘
        Args:
            passes: 覆盖次数
        Returns:
            bool: 是否成功
        """
        if not self.opened or self.read_only:
            return False

        try:
            for pass_num in range(passes):
                if pass_num % 3 == 0:
                    pattern = b'\xFF' * self.sector_size
                elif pass_num % 3 == 1:
                    pattern = b'\x00' * self.sector_size
                else:
                    pattern = bytes(random.getrandbits(8) for _ in range(self.sector_size))

                self.fill_pattern(pattern, 0, self.total_sectors)
            return True
        except Exception:
            return False

    def scan_for_pattern(self, pattern: bytes, start_sector: int = 0,
                         max_sectors: int = 1000) -> List[Tuple[int, int]]:
        """
        扫描磁盘查找模式
        Args:
            pattern: 要查找的模式
            start_sector: 起始扇区
            max_sectors: 最大扫描扇区数
        Returns:
            List[Tuple[int, int]]: 找到的位置列表
        """
        if not self.opened or not pattern:
            return []

        results = []
        pattern_len = len(pattern)
        end_sector = min(start_sector + max_sectors, self.total_sectors)

        for sector in range(start_sector, end_sector):
            try:
                data = self.read_sectors(sector, 1)
                pos = 0
                while True:
                    found = data.find(pattern, pos)
                    if found == -1:
                        break
                    absolute_offset = sector * self.sector_size + found
                    results.append((sector, found, absolute_offset))
                    pos = found + pattern_len
            except Exception:
                continue

        return results

    def get_detailed_info(self) -> Dict[str, Any]:
        """
        获取磁盘详细信息
        Returns:
            Dict: 磁盘信息字典
        """
        info = {
            "device_name": self.device_name,
            "sector_size": self.sector_size,
            "total_sectors": self.total_sectors,
            "total_bytes": self.total_bytes,
            "human_readable_size": self.get_human_readable_size(),
            "is_physical": self.is_physical,
            "is_logical": self.is_logical,
            "opened": self.opened,
            "read_only": self.read_only,
            "write_protected": self.is_write_protected(),
            "disk_signature": hex(self.get_disk_signature()) if self.opened else 0
        }

        if self.geometry:
            info["geometry"] = {
                "cylinders": self.geometry.cylinders,
                "tracks_per_cylinder": self.geometry.tracks_per_cylinder,
                "sectors_per_track": self.geometry.sectors_per_track,
                "bytes_per_sector": self.geometry.bytes_per_sector,
                "media_type": self.geometry.media_type
            }

        return info

# ==================== 高级磁盘操作函数 ====================
def OpenDisk(device_name: str, read_only: bool = True, exclusive: bool = False) -> DiskDevice:
    """
    打开磁盘设备
    Args:
        device_name: 设备名
        read_only: 是否只读
        exclusive: 是否独占访问
    Returns:
        DiskDevice: 磁盘设备对象
    """
    access = DiskAccess.READ_ONLY if read_only else DiskAccess.READ_WRITE
    disk = DiskDevice(device_name)
    disk.open(access, exclusive)
    return disk

def ReadDisk(handle: Union[DiskDevice, int], start_sector: int, num_sectors: int = 1) -> bytes:
    """
    读取磁盘扇区
    Args:
        handle: 磁盘句柄或DiskDevice对象
        start_sector: 起始扇区
        num_sectors: 扇区数
    Returns:
        bytes: 读取的数据
    """
    if isinstance(handle, DiskDevice):
        return handle.read_sectors(start_sector, num_sectors)
    disk = DiskDevice("")
    disk.handle = handle
    disk.opened = True
    return disk.read_sectors(start_sector, num_sectors)

def WriteDisk(handle: Union[DiskDevice, int], start_sector: int, data: Union[bytes, str]) -> bool:
    """
    写入磁盘扇区
    Args:
        handle: 磁盘句柄或DiskDevice对象
        start_sector: 起始扇区
        data: 要写入的数据
    Returns:
        bool: 是否成功
    """
    if isinstance(data, str):
        data = hex_string_to_bytes(data)

    if isinstance(handle, DiskDevice):
        return handle.write_sectors(start_sector, data)
    disk = DiskDevice("")
    disk.handle = handle
    disk.opened = True
    return disk.write_sectors(start_sector, data)

def hex_string_to_bytes(hex_str: str) -> bytes:
    """将十六进制字符串转换为字节"""
    hex_str = hex_str.strip()
    prefixes = ["0x", "\\x", "x"]
    for prefix in prefixes:
        if hex_str.startswith(prefix):
            hex_str = hex_str[len(prefix):]

    hex_str = hex_str.replace(" ", "").replace("\n", "").replace("\r", "").replace("\t", "")
    if len(hex_str) % 2 != 0:
        hex_str = "0" + hex_str

    try:
        return bytes.fromhex(hex_str)
    except ValueError:
        raise ValueError(f"无效的十六进制字符串: {hex_str}")

def bytes_to_hex_string(data: bytes, bytes_per_line: int = 16,
                        show_offset: bool = True, show_ascii: bool = True) -> str:
    """将字节转换为十六进制字符串"""
    lines = []
    for i in range(0, len(data), bytes_per_line):
        chunk = data[i:i + bytes_per_line]
        offset_str = f"{i:08X}:  " if show_offset else ""
        hex_parts = []
        for j in range(bytes_per_line):
            hex_parts.append(f"{chunk[j]:02X}" if j < len(chunk) else "  ")

        hex_str = ""
        for k in range(0, len(hex_parts), 8):
            hex_str += " ".join(hex_parts[k:k+8]) + "  "

        ascii_str = ""
        if show_ascii:
            ascii_str = "  "
            for b in chunk:
                ascii_str += chr(b) if 32 <= b <= 126 else "."

        lines.append(f"{offset_str}{hex_str}{ascii_str}")
    return "\n".join(lines)

def get_all_physical_disks() -> List[Tuple[str, str]]:
    """获取所有物理磁盘"""
    disks = []
    for i in range(256):
        device_path = f"\\\\.\\PhysicalDrive{i}"
        try:
            with win32file.CreateFile(
                device_path,
                GENERIC_READ,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                None,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                None
            ) as handle:
                if handle != INVALID_HANDLE_VALUE:
                    geometry = DISK_GEOMETRY()
                    bytes_returned = wintypes.DWORD()
                    result = ctypes.windll.kernel32.DeviceIoControl(
                        handle,
                        IOCTL_DISK_GET_DRIVE_GEOMETRY,
                        None, 0,
                        ctypes.byref(geometry), ctypes.sizeof(geometry),
                        ctypes.byref(bytes_returned),
                        None
                    )
                    if result:
                        total_size = (geometry.Cylinders * geometry.TracksPerCylinder *
                                     geometry.SectorsPerTrack * geometry.BytesPerSector)
                        description = f"物理磁盘{i} ({format_size(total_size)})"
                    else:
                        description = f"物理磁盘{i}"
                    disks.append((device_path, description))
        except:
            break
    return disks

def get_all_logical_volumes() -> List[Tuple[str, str]]:
    """获取所有逻辑卷"""
    volumes = []
    logical_drives = win32api.GetLogicalDriveStrings().split('\x00')[:-1]
    for drive in logical_drives:
        drive_letter = drive[0]
        device_path = f"\\\\.\\{drive_letter}:"
        try:
            label, serial, max_len, flags, fs = win32api.GetVolumeInformation(drive)
            _, total, free = win32api.GetDiskFreeSpaceEx(drive)
            description = f"{drive_letter}: ({label or '无卷标'}, {fs}, {format_size(total)})"
            volumes.append((device_path, description))
        except:
            volumes.append((device_path, f"{drive_letter}:"))
    return volumes

def get_all_disk_devices() -> List[Tuple[str, str]]:
    """获取所有磁盘设备"""
    physical = get_all_physical_disks()
    logical = get_all_logical_volumes()
    return physical + logical

def format_size(bytes_size: int) -> str:
    """格式化字节大小为易读的格式"""
    if bytes_size == 0:
        return "0 B"
    size_names = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']
    i = 0
    size = float(bytes_size)
    while size >= 1024 and i < len(size_names) - 1:
        size /= 1024.0
        i += 1
    return f"{size:.2f} {size_names[i]}"

# 模块导出控制
__all__ = [
    # 枚举
    "DiskAccess", "DiskSectorSize", "DiskType",
    # 数据类
    "DiskGeometry", "PartitionInfo",
    # 异常
    "DiskError", "DiskAccessDeniedError", "DiskWriteProtectedError",
    "DiskNotReadyError", "DiskSectorError", "DiskIOError", "DiskGeometryError",
    # 核心类
    "DiskDevice",
    # 工具函数
    "OpenDisk", "ReadDisk", "WriteDisk", "hex_string_to_bytes",
    "bytes_to_hex_string", "get_all_physical_disks", "get_all_logical_volumes",
    "get_all_disk_devices", "format_size", "check_disk_access"
]