import ctypes
from ctypes import wintypes
from typing import Optional, TypeAlias, Tuple, List

# 定义必要的Windows类型和常量
NTSTATUS = wintypes.LONG
PVOID = wintypes.LPVOID
ULONG = wintypes.ULONG
ULONG_PTR = wintypes.WPARAM  # 兼容32/64位
PIO_APC_ROUTINE = wintypes.LPVOID
HANDLE = wintypes.HANDLE
DWORD = wintypes.DWORD
WORD = wintypes.WORD
BYTE = wintypes.BYTE
SIZE_T = ctypes.c_size_t
LPVOID = wintypes.LPVOID
LPCVOID = wintypes.LPCVOID

# ctypes.wintypes 在某些 Python 版本中没有 LPOVERLAPPED
if hasattr(wintypes, 'LPOVERLAPPED'):
    LPOVERLAPPED = wintypes.LPOVERLAPPED
else:
    LPOVERLAPPED = wintypes.LPVOID

BOOL = wintypes.BOOL
PULONG = ctypes.POINTER(wintypes.ULONG)
PDWORD = ctypes.POINTER(DWORD)
PHANDLE = ctypes.POINTER(HANDLE)

# 权限常量
SE_DEBUG_PRIVILEGE = 0x14
SE_SHUTDOWN_PRIVILEGE = 0x13

# 内存分配类型
MEM_COMMIT = 0x1000
MEM_RESERVE = 0x2000
MEM_RELEASE = 0x8000
MEM_DECOMMIT = 0x4000

# 内存保护常量
PAGE_NOACCESS = 0x01
PAGE_READONLY = 0x02
PAGE_READWRITE = 0x04
PAGE_WRITECOPY = 0x08
PAGE_EXECUTE = 0x10
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80

# 创建处置常量
FILE_SUPERSEDE = 0x00000000
FILE_OPEN = 0x00000001
FILE_CREATE = 0x00000002
FILE_OPEN_IF = 0x00000003
FILE_OVERWRITE = 0x00000004
FILE_OVERWRITE_IF = 0x00000005

# 对象信息类常量
ObjectBasicInformation = 0
ObjectNameInformation = 1
ObjectTypeInformation = 2

# 进程信息类常量
ProcessBasicInformation = 0
ProcessDebugPort = 7
ProcessWow64Information = 26
ProcessImageFileName = 27
ProcessBreakOnTermination = 29

# 系统信息类常量
SystemBasicInformation = 0
SystemProcessInformation = 5
SystemHandleInformation = 16
SystemModuleInformation = 11

# 直接加载 ntdll.dll，供所有函数复用（避免重复加载）
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

# NTSTATUS常量
STATUS_SUCCESS = 0x00000000
STATUS_PRIVILEGE_NOT_HELD = 0xC0000061
STATUS_ACCESS_DENIED = 0xC0000022
STATUS_INFO_LENGTH_MISMATCH = 0xC0000004
STATUS_BUFFER_TOO_SMALL = 0xC0000023
STATUS_OBJECT_NAME_NOT_FOUND = 0xC0000034
STATUS_OBJECT_NAME_COLLISION = 0xC0000035

# 文件访问权限常量
FILE_GENERIC_READ = 0x120089
FILE_GENERIC_WRITE = 0x120016
FILE_GENERIC_EXECUTE = 0x1200A0
DELETE = 0x00010000
READ_CONTROL = 0x00020000
WRITE_DAC = 0x00040000
WRITE_OWNER = 0x00080000
SYNCHRONIZE = 0x00100000

# 文件共享模式常量
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
FILE_SHARE_DELETE = 0x00000004

# 文件创建选项常量
FILE_NON_DIRECTORY_FILE = 0x00000040
FILE_SYNCHRONOUS_IO_ALERT = 0x00000010
FILE_SYNCHRONOUS_IO_NONALERT = 0x00000020
FILE_DELETE_ON_CLOSE = 0x00000400
FILE_OPEN_REPARSE_POINT = 0x00200000
FILE_OPEN_NO_RECALL = 0x00100000

# 定义IO_STATUS_BLOCK结构体
class IO_STATUS_BLOCK(ctypes.Structure):
    _fields_ = [
        ("Status", NTSTATUS),
        ("Information", ULONG_PTR),  # 改为ULONG_PTR兼容64位
    ]

PIO_STATUS_BLOCK: TypeAlias = ctypes.POINTER(IO_STATUS_BLOCK)

# 定义UNICODE_STRING结构体
class UNICODE_STRING(ctypes.Structure):
    _fields_ = [
        ("Length", wintypes.USHORT),
        ("MaximumLength", wintypes.USHORT),
        ("Buffer", wintypes.LPWSTR),
    ]

PUNICODE_STRING = ctypes.POINTER(UNICODE_STRING)

# 定义OBJECT_ATTRIBUTES结构体
class OBJECT_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ("Length", ULONG),
        ("RootDirectory", HANDLE),
        ("ObjectName", PUNICODE_STRING),
        ("Attributes", ULONG),
        ("SecurityDescriptor", PVOID),
        ("SecurityQualityOfService", PVOID),
    ]

POBJECT_ATTRIBUTES = ctypes.POINTER(OBJECT_ATTRIBUTES)

# 定义CLIENT_ID结构体（用于NtOpenProcess）
class CLIENT_ID(ctypes.Structure):
    _fields_ = [
        ("UniqueProcess", HANDLE),
        ("UniqueThread", HANDLE),
    ]

PCLIENT_ID = ctypes.POINTER(CLIENT_ID)

# 定义PROCESS_BASIC_INFORMATION结构体
class PROCESS_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("ExitStatus", NTSTATUS),
        ("PebBaseAddress", PVOID),
        ("AffinityMask", ULONG_PTR),
        ("BasePriority", ULONG),
        ("UniqueProcessId", ULONG_PTR),
        ("InheritedFromUniqueProcessId", ULONG_PTR),
    ]

PPROCESS_BASIC_INFORMATION = ctypes.POINTER(PROCESS_BASIC_INFORMATION)

# -------------------------- 基础工具函数 --------------------------
def InitializeObjectAttributes(
    ObjectName: Optional[str] = None,
    RootDirectory: HANDLE = None,
    Attributes: ULONG = 0,
    SecurityDescriptor: PVOID = None,
    SecurityQualityOfService: PVOID = None
) -> OBJECT_ATTRIBUTES:
    """
    初始化OBJECT_ATTRIBUTES结构体（完善内存管理，避免指针失效）

    参数:
        ObjectName: 对象名称
        RootDirectory: 根目录句柄
        Attributes: 对象属性（如OBJ_CASE_INSENSITIVE=0x00000040）
        SecurityDescriptor: 安全描述符
        SecurityQualityOfService: 安全服务质量

    返回:
        初始化好的OBJECT_ATTRIBUTES结构体
    """
    obj_attr = OBJECT_ATTRIBUTES()
    obj_attr.Length = ctypes.sizeof(OBJECT_ATTRIBUTES)
    obj_attr.RootDirectory = RootDirectory or 0
    obj_attr.Attributes = Attributes
    obj_attr.SecurityDescriptor = SecurityDescriptor or 0
    obj_attr.SecurityQualityOfService = SecurityQualityOfService or 0

    if ObjectName:
        # 创建Unicode缓冲区，确保生命周期与obj_attr一致
        unicode_str = UNICODE_STRING()
        buffer = ctypes.create_unicode_buffer(ObjectName)
        unicode_str.Buffer = buffer
        unicode_str.Length = len(ObjectName) * ctypes.sizeof(wintypes.WCHAR)
        unicode_str.MaximumLength = unicode_str.Length + ctypes.sizeof(wintypes.WCHAR)
        obj_attr.ObjectName = ctypes.pointer(unicode_str)
        
        # 保存引用，防止GC回收导致指针失效
        obj_attr._buffer = buffer
        obj_attr._unicode_str = unicode_str
    else:
        obj_attr.ObjectName = None

    return obj_attr

def RtlInitUnicodeString(
    DestinationString: PUNICODE_STRING,
    SourceString: Optional[str]
) -> None:
    """初始化 UNICODE_STRING 结构体（完善类型定义）"""
    ntdll.RtlInitUnicodeString.argtypes = [PUNICODE_STRING, wintypes.LPCWSTR]
    ntdll.RtlInitUnicodeString.restype = None
    ntdll.RtlInitUnicodeString(DestinationString, SourceString)

def RtlNtStatusToDosError(Status: NTSTATUS) -> ULONG:
    """将 NTSTATUS 转换为 DOS/Win32 错误代码"""
    ntdll.RtlNtStatusToDosError.argtypes = [NTSTATUS]
    ntdll.RtlNtStatusToDosError.restype = ULONG
    return ntdll.RtlNtStatusToDosError(Status)

def NT_SUCCESS(status: NTSTATUS) -> bool:
    """
    检查NTSTATUS是否表示成功

    参数:
        status: NTSTATUS状态码

    返回:
        如果状态表示成功返回True，否则返回False
    """
    return status >= 0

def GetLastErrorAsString() -> str:
    """获取最后错误的字符串描述"""
    err_code = ctypes.get_last_error()
    buf = ctypes.create_unicode_buffer(256)
    kernel32.FormatMessageW(
        0x1000,  # FORMAT_MESSAGE_FROM_SYSTEM
        None,
        err_code,
        0,
        buf,
        ctypes.sizeof(buf) // ctypes.sizeof(wintypes.WCHAR),
        None
    )
    return f"错误码 {err_code}: {buf.value.strip()}"

# -------------------------- 文件操作函数 --------------------------
def NtOpenFile(
    FileHandle: PHANDLE,
    DesiredAccess: ULONG,
    ObjectAttributes: OBJECT_ATTRIBUTES,
    IoStatusBlock: PIO_STATUS_BLOCK,
    ShareAccess: ULONG,
    OpenOptions: ULONG
) -> NTSTATUS:
    """打开文件/设备句柄（完善参数校验）"""
    if not FileHandle:
        raise ValueError("FileHandle 不能为空指针")
    
    ntdll.NtOpenFile.argtypes = [
        PHANDLE,
        ULONG,
        POBJECT_ATTRIBUTES,
        PIO_STATUS_BLOCK,
        ULONG,
        ULONG
    ]
    ntdll.NtOpenFile.restype = NTSTATUS
    
    status = ntdll.NtOpenFile(
        FileHandle,
        DesiredAccess,
        ctypes.byref(ObjectAttributes),
        IoStatusBlock,
        ShareAccess,
        OpenOptions
    )
    return status

def NtReadFile(
    FileHandle: HANDLE,
    Event: HANDLE = None,
    ApcRoutine: PIO_APC_ROUTINE = None,
    ApcContext: PVOID = None,
    IoStatusBlock: PIO_STATUS_BLOCK = None,
    Buffer: PVOID = None,
    Length: ULONG = 0,
    ByteOffset: PVOID = None,
    Key: PVOID = None
) -> Tuple[NTSTATUS, IO_STATUS_BLOCK]:
    """读取文件/设备数据（返回完整的IO_STATUS_BLOCK）"""
    if FileHandle == 0:
        raise ValueError("FileHandle 无效")
    
    io_status_block = IO_STATUS_BLOCK()
    local_io_status = IoStatusBlock or ctypes.byref(io_status_block)

    ntdll.NtReadFile.argtypes = [
        HANDLE,
        HANDLE,
        PIO_APC_ROUTINE,
        PVOID,
        PIO_STATUS_BLOCK,
        PVOID,
        ULONG,
        PVOID,
        PVOID
    ]
    ntdll.NtReadFile.restype = NTSTATUS

    status = ntdll.NtReadFile(
        FileHandle,
        Event or 0,
        ApcRoutine or 0,
        ApcContext or 0,
        local_io_status,
        Buffer,
        Length,
        ByteOffset,
        Key
    )
    return status, io_status_block if not IoStatusBlock else IoStatusBlock.contents

def NtWriteFile(
    FileHandle: HANDLE,
    Event: HANDLE = None,
    ApcRoutine: PIO_APC_ROUTINE = None,
    ApcContext: PVOID = None,
    IoStatusBlock: PIO_STATUS_BLOCK = None,
    Buffer: PVOID = None,
    Length: ULONG = 0,
    ByteOffset: PVOID = None,
    Key: PVOID = None
) -> Tuple[NTSTATUS, IO_STATUS_BLOCK]:
    """写入文件/设备数据（优化重复加载问题，返回IO_STATUS_BLOCK）"""
    if FileHandle == 0:
        raise ValueError("FileHandle 无效")
    if Buffer is None and Length > 0:
        raise ValueError("Buffer 不能为空（Length>0时）")
    
    io_status_block = IO_STATUS_BLOCK()
    local_io_status = IoStatusBlock or ctypes.byref(io_status_block)

    ntdll.NtWriteFile.argtypes = [
        HANDLE,
        HANDLE,
        PIO_APC_ROUTINE,
        PVOID,
        PIO_STATUS_BLOCK,
        PVOID,
        ULONG,
        PVOID,
        PVOID
    ]
    ntdll.NtWriteFile.restype = NTSTATUS

    status = ntdll.NtWriteFile(
        FileHandle,
        Event or 0,
        ApcRoutine or 0,
        ApcContext or 0,
        local_io_status,
        Buffer,
        Length,
        ByteOffset,
        Key
    )
    return status, io_status_block if not IoStatusBlock else IoStatusBlock.contents

def NtCreateFile(
    DesiredAccess: ULONG,
    ObjectAttributes: OBJECT_ATTRIBUTES,
    IoStatusBlock: PIO_STATUS_BLOCK = None,
    AllocationSize: Optional[SIZE_T] = None,
    FileAttributes: ULONG = 0,
    ShareAccess: ULONG = 0,
    CreateDisposition: ULONG = FILE_CREATE,
    CreateOptions: ULONG = 0,
    EaBuffer: PVOID = None,
    EaLength: ULONG = 0
) -> Tuple[NTSTATUS, HANDLE]:
    """
    创建文件（完善AllocationSize参数，修复句柄初始化）

    返回:
        (NTSTATUS状态码, 文件句柄)
    """
    file_handle = HANDLE(0)
    io_status_block = IO_STATUS_BLOCK()
    local_io_status = IoStatusBlock or ctypes.byref(io_status_block)
    
    # 处理分配大小
    alloc_size = ctypes.c_ulonglong(0)
    if AllocationSize is not None:
        alloc_size = ctypes.c_ulonglong(AllocationSize)

    ntdll.NtCreateFile.argtypes = [
        PHANDLE,
        ULONG,
        POBJECT_ATTRIBUTES,
        PIO_STATUS_BLOCK,
        ctypes.POINTER(ctypes.c_ulonglong),  # AllocationSize
        ULONG,
        ULONG,
        ULONG,
        ULONG,
        PVOID,
        ULONG
    ]
    ntdll.NtCreateFile.restype = NTSTATUS

    status = ntdll.NtCreateFile(
        ctypes.byref(file_handle),
        DesiredAccess,
        ctypes.byref(ObjectAttributes),
        local_io_status,
        ctypes.byref(alloc_size) if AllocationSize else None,
        FileAttributes,
        ShareAccess,
        CreateDisposition,
        CreateOptions,
        EaBuffer,
        EaLength
    )
    return status, file_handle

def NtDeviceIoControlFile(
    FileHandle: HANDLE,
    Event: HANDLE = None,
    ApcRoutine: PIO_APC_ROUTINE = None,
    ApcContext: PVOID = None,
    IoStatusBlock: PIO_STATUS_BLOCK = None,
    IoControlCode: ULONG = 0,
    InputBuffer: PVOID = None,
    InputBufferLength: ULONG = 0,
    OutputBuffer: PVOID = None,
    OutputBufferLength: ULONG = 0
) -> Tuple[NTSTATUS, IO_STATUS_BLOCK]:
    """执行设备I/O控制（返回IO_STATUS_BLOCK）"""
    if FileHandle == 0:
        raise ValueError("FileHandle 无效")
    
    io_status_block = IO_STATUS_BLOCK()
    local_io_status = IoStatusBlock or ctypes.byref(io_status_block)

    ntdll.NtDeviceIoControlFile.argtypes = [
        HANDLE,
        HANDLE,
        PIO_APC_ROUTINE,
        PVOID,
        PIO_STATUS_BLOCK,
        ULONG,
        PVOID,
        ULONG,
        PVOID,
        ULONG
    ]
    ntdll.NtDeviceIoControlFile.restype = NTSTATUS

    status = ntdll.NtDeviceIoControlFile(
        FileHandle,
        Event or 0,
        ApcRoutine or 0,
        ApcContext or 0,
        local_io_status,
        IoControlCode,
        InputBuffer,
        InputBufferLength,
        OutputBuffer,
        OutputBufferLength
    )
    return status, io_status_block if not IoStatusBlock else IoStatusBlock.contents

def NtQueryInformationFile(
    FileHandle: HANDLE,
    IoStatusBlock: PIO_STATUS_BLOCK,
    FileInformation: PVOID,
    Length: ULONG,
    FileInformationClass: ULONG
) -> NTSTATUS:
    """查询文件信息（完善参数校验）"""
    if FileHandle == 0:
        raise ValueError("FileHandle 无效")
    if FileInformation is None or Length == 0:
        raise ValueError("FileInformation 和 Length 不能为空/0")
    
    ntdll.NtQueryInformationFile.argtypes = [
        HANDLE,
        PIO_STATUS_BLOCK,
        PVOID,
        ULONG,
        ULONG
    ]
    ntdll.NtQueryInformationFile.restype = NTSTATUS
    return ntdll.NtQueryInformationFile(
        FileHandle,
        IoStatusBlock,
        FileInformation,
        Length,
        FileInformationClass
    )

def NtClose(Handle: HANDLE) -> NTSTATUS:
    """关闭对象句柄（优化重复加载）"""
    if Handle == 0 or Handle == -1:
        return STATUS_SUCCESS  # 无效句柄直接返回成功
    
    ntdll.NtClose.argtypes = [HANDLE]
    ntdll.NtClose.restype = NTSTATUS
    return ntdll.NtClose(Handle)

# -------------------------- 进程操作函数 --------------------------
def NtOpenProcess(
    ProcessId: DWORD,
    DesiredAccess: ULONG = PROCESS_ALL_ACCESS,
) -> Tuple[NTSTATUS, HANDLE]:
    """
    简化版NtOpenProcess（根据PID打开进程句柄）

    参数:
        ProcessId: 进程ID
        DesiredAccess: 期望的访问权限

    返回:
        (NTSTATUS状态码, 进程句柄)
    """
    process_handle = HANDLE(0)
    client_id = CLIENT_ID()
    client_id.UniqueProcess = HANDLE(ProcessId)
    client_id.UniqueThread = HANDLE(0)

    # 初始化对象属性
    obj_attr = InitializeObjectAttributes()

    ntdll.NtOpenProcess.argtypes = [
        PHANDLE,
        ULONG,
        POBJECT_ATTRIBUTES,
        PCLIENT_ID
    ]
    ntdll.NtOpenProcess.restype = NTSTATUS
    
    status = ntdll.NtOpenProcess(
        ctypes.byref(process_handle),
        DesiredAccess,
        ctypes.byref(obj_attr),
        ctypes.byref(client_id)
    )
    return status, process_handle

def NtQueryInformationProcess(
    ProcessHandle: HANDLE,
    ProcessInformationClass: ULONG,
    ProcessInformation: PVOID,
    ProcessInformationLength: ULONG,
    ReturnLength: PULONG = None
) -> NTSTATUS:
    """查询进程信息（完善参数校验）"""
    if ProcessHandle == 0:
        raise ValueError("ProcessHandle 无效")
    
    ntdll.NtQueryInformationProcess.argtypes = [
        HANDLE,
        ULONG,
        PVOID,
        ULONG,
        PULONG
    ]
    ntdll.NtQueryInformationProcess.restype = NTSTATUS
    return ntdll.NtQueryInformationProcess(
        ProcessHandle,
        ProcessInformationClass,
        ProcessInformation,
        ProcessInformationLength,
        ReturnLength
    )

def GetProcessBasicInfo(ProcessHandle: HANDLE) -> Tuple[NTSTATUS, Optional[PROCESS_BASIC_INFORMATION]]:
    """获取进程基础信息（封装ProcessBasicInformation查询）"""
    pbi = PROCESS_BASIC_INFORMATION()
    return_length = ULONG(0)
    
    status = NtQueryInformationProcess(
        ProcessHandle,
        ProcessBasicInformation,
        ctypes.byref(pbi),
        ctypes.sizeof(pbi),
        ctypes.byref(return_length)
    )
    if NT_SUCCESS(status):
        return status, pbi
    return status, None

def NtAllocateVirtualMemory(
    ProcessHandle: HANDLE,
    Size: SIZE_T,
    AllocationType: ULONG = MEM_COMMIT | MEM_RESERVE,
    Protect: ULONG = PAGE_READWRITE
) -> Tuple[NTSTATUS, PVOID]:
    """
    简化版内存分配（为指定进程分配虚拟内存）

    返回:
        (NTSTATUS状态码, 分配的内存基地址)
    """
    base_address = PVOID(0)
    region_size = ULONG(Size)

    ntdll.NtAllocateVirtualMemory.argtypes = [
        HANDLE,
        ctypes.POINTER(PVOID),
        ULONG,
        ctypes.POINTER(ULONG),
        ULONG,
        ULONG
    ]
    ntdll.NtAllocateVirtualMemory.restype = NTSTATUS
    
    status = ntdll.NtAllocateVirtualMemory(
        ProcessHandle,
        ctypes.byref(base_address),
        0,
        ctypes.byref(region_size),
        AllocationType,
        Protect
    )
    return status, base_address

def NtFreeVirtualMemory(
    ProcessHandle: HANDLE,
    BaseAddress: PVOID,
    FreeType: ULONG = MEM_RELEASE
) -> Tuple[NTSTATUS, ULONG]:
    """
    简化版内存释放

    返回:
        (NTSTATUS状态码, 释放的内存大小)
    """
    region_size = ULONG(0)

    ntdll.NtFreeVirtualMemory.argtypes = [
        HANDLE,
        ctypes.POINTER(PVOID),
        ctypes.POINTER(ULONG),
        ULONG
    ]
    ntdll.NtFreeVirtualMemory.restype = NTSTATUS
    
    status = ntdll.NtFreeVirtualMemory(
        ProcessHandle,
        ctypes.byref(BaseAddress),
        ctypes.byref(region_size),
        FreeType
    )
    return status, region_size

def NtWriteVirtualMemory(
    ProcessHandle: HANDLE,
    BaseAddress: PVOID,
    Buffer: PVOID,
    Length: SIZE_T
) -> Tuple[NTSTATUS, SIZE_T]:
    """
    写入进程虚拟内存（新增函数）

    返回:
        (NTSTATUS状态码, 实际写入的字节数)
    """
    bytes_written = SIZE_T(0)
    
    ntdll.NtWriteVirtualMemory.argtypes = [
        HANDLE,
        PVOID,
        LPCVOID,
        SIZE_T,
        ctypes.POINTER(SIZE_T)
    ]
    ntdll.NtWriteVirtualMemory.restype = NTSTATUS
    
    status = ntdll.NtWriteVirtualMemory(
        ProcessHandle,
        BaseAddress,
        Buffer,
        Length,
        ctypes.byref(bytes_written)
    )
    return status, bytes_written.value

def NtReadVirtualMemory(
    ProcessHandle: HANDLE,
    BaseAddress: PVOID,
    Buffer: PVOID,
    Length: SIZE_T
) -> Tuple[NTSTATUS, SIZE_T]:
    """
    读取进程虚拟内存（新增函数）

    返回:
        (NTSTATUS状态码, 实际读取的字节数)
    """
    bytes_read = SIZE_T(0)
    
    ntdll.NtReadVirtualMemory.argtypes = [
        HANDLE,
        LPCVOID,
        PVOID,
        SIZE_T,
        ctypes.POINTER(SIZE_T)
    ]
    ntdll.NtReadVirtualMemory.restype = NTSTATUS
    
    status = ntdll.NtReadVirtualMemory(
        ProcessHandle,
        BaseAddress,
        Buffer,
        Length,
        ctypes.byref(bytes_read)
    )
    return status, bytes_read.value

def NtProtectVirtualMemory(
    ProcessHandle: HANDLE,
    BaseAddress: PVOID,
    Length: SIZE_T,
    NewProtect: ULONG,
    OldProtect: PULONG
) -> NTSTATUS:
    """
    修改内存保护属性（新增函数）
    """
    region_size = ULONG(Length)
    
    ntdll.NtProtectVirtualMemory.argtypes = [
        HANDLE,
        ctypes.POINTER(PVOID),
        ctypes.POINTER(ULONG),
        ULONG,
        PULONG
    ]
    ntdll.NtProtectVirtualMemory.restype = NTSTATUS
    
    status = ntdll.NtProtectVirtualMemory(
        ProcessHandle,
        ctypes.byref(BaseAddress),
        ctypes.byref(region_size),
        NewProtect,
        OldProtect
    )
    return status

# -------------------------- 系统信息与权限函数 --------------------------
def NtQuerySystemInformation(
    SystemInformationClass: ULONG,
    SystemInformation: PVOID,
    SystemInformationLength: ULONG,
    ReturnLength: PULONG = None
) -> NTSTATUS:
    """查询系统信息（完善错误处理）"""
    ntdll.NtQuerySystemInformation.argtypes = [
        ULONG,
        PVOID,
        ULONG,
        PULONG
    ]
    ntdll.NtQuerySystemInformation.restype = NTSTATUS
    return ntdll.NtQuerySystemInformation(
        SystemInformationClass,
        SystemInformation,
        SystemInformationLength,
        ReturnLength
    )

def RtlAdjustPrivilege(
    Privilege: ULONG,
    Enable: BOOL = True,
    CurrentThread: BOOL = False,
    PreviousValue: PVOID = None
) -> NTSTATUS:
    """
    调整权限（修复重复加载，完善参数）
    
    参数:
        Privilege: 权限编号（如SE_DEBUG_PRIVILEGE=0x14）
        Enable: 是否启用（True=启用，False=禁用）
        CurrentThread: True=调整线程权限，False=调整进程权限
        PreviousValue: 输出之前的权限状态
    """
    # 确保参数类型正确
    enable = BOOL(Enable)
    current_thread = BOOL(CurrentThread)
    
    ntdll.RtlAdjustPrivilege.argtypes = [
        ULONG,
        BOOL,
        BOOL,
        PVOID
    ]
    ntdll.RtlAdjustPrivilege.restype = NTSTATUS
    
    status = ntdll.RtlAdjustPrivilege(
        Privilege,
        enable,
        current_thread,
        PreviousValue
    )
    return status

def NtQueryObject(
    Handle: HANDLE,
    ObjectInformationClass: ULONG,
    ObjectInformation: PVOID,
    ObjectInformationLength: ULONG,
    ReturnLength: PULONG = None
) -> NTSTATUS:
    """查询对象信息（完善参数校验）"""
    if Handle == 0:
        raise ValueError("Handle 无效")
    
    ntdll.NtQueryObject.argtypes = [
        HANDLE,
        ULONG,
        PVOID,
        ULONG,
        PULONG
    ]
    ntdll.NtQueryObject.restype = NTSTATUS
    return ntdll.NtQueryObject(
        Handle,
        ObjectInformationClass,
        ObjectInformation,
        ObjectInformationLength,
        ReturnLength
    )

def NtRaiseHardError(
    ErrorStatus: NTSTATUS,
    NumberOfParameters: ULONG = 0,
    UnicodeStringParameterMask: ULONG = 0,
    Parameters: PVOID = None,
    Action: ULONG = 0,
    Response: PULONG = None
) -> NTSTATUS:
    """引发硬错误（完善参数默认值）"""
    ntdll.NtRaiseHardError.argtypes = [
        NTSTATUS,
        ULONG,
        ULONG,
        PVOID,
        ULONG,
        PULONG
    ]
    ntdll.NtRaiseHardError.restype = NTSTATUS
    
    status = ntdll.NtRaiseHardError(
        ErrorStatus,
        NumberOfParameters,
        UnicodeStringParameterMask,
        Parameters,
        Action,
        Response
    )
    return status

def RtlSetProcessIsCritical(
    IsCritical: BOOL = True,
    BreakAwayOk: BOOL = True,
    UserAffinity: PVOID = None
) -> NTSTATUS:
    """设置进程为关键进程（修复重复加载）"""
    is_critical = BOOL(IsCritical)
    break_away_ok = BOOL(BreakAwayOk)
    
    ntdll.RtlSetProcessIsCritical.argtypes = [
        BOOL,
        BOOL,
        PVOID
    ]
    ntdll.RtlSetProcessIsCritical.restype = NTSTATUS
    
    status = ntdll.RtlSetProcessIsCritical(
        is_critical,
        break_away_ok,
        UserAffinity
    )
    return status

# -------------------------- 线程操作函数（新增） --------------------------
def NtCreateThreadEx(
    ProcessHandle: HANDLE,
    StartAddress: PVOID,
    Parameter: PVOID = None
) -> Tuple[NTSTATUS, HANDLE]:
    """
    创建远程线程（新增函数）
    
    返回:
        (NTSTATUS状态码, 线程句柄)
    """
    thread_handle = HANDLE(0)
    stack_size = SIZE_T(0)
    creation_flags = ULONG(0)
    
    # NtCreateThreadEx 函数签名（简化版）
    ntdll.NtCreateThreadEx.argtypes = [
        PHANDLE,
        ULONG,
        PVOID,
        HANDLE,
        PVOID,
        PVOID,
        BOOL,
        ULONG,
        SIZE_T,
        SIZE_T,
        PVOID
    ]
    ntdll.NtCreateThreadEx.restype = NTSTATUS
    
    status = ntdll.NtCreateThreadEx(
        ctypes.byref(thread_handle),
        0x1FFFFF,  # THREAD_ALL_ACCESS
        None,
        ProcessHandle,
        StartAddress,
        Parameter,
        False,
        0,
        0,
        0,
        None
    )
    return status, thread_handle

def NtWaitForSingleObject(
    Handle: HANDLE,
    Alertable: BOOL = False,
    Timeout: PVOID = None
) -> NTSTATUS:
    """
    等待对象（新增函数）
    """
    alertable = BOOL(Alertable)
    
    ntdll.NtWaitForSingleObject.argtypes = [
        HANDLE,
        BOOL,
        PVOID
    ]
    ntdll.NtWaitForSingleObject.restype = NTSTATUS
    
    status = ntdll.NtWaitForSingleObject(
        Handle,
        alertable,
        Timeout
    )
    return status