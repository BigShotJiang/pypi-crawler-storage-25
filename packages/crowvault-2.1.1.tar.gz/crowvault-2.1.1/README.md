# crowvault

Python SDK for [CrowVault](https://crowvault.ai) — MCP-native SDK for 327 AI dev tools — code generation via Model Context Protocol. Zero dependencies.

## Install

```bash
pip install crowvault
```

## Quick Start

```python
from crowvault import CrowVaultClient

client = CrowVaultClient(api_key="cv_your_key_here")

# Generate a database schema
result = client.call("database-mcp", "design_schema",
                     aggregate="Order", database="postgresql")
print(result.text)

# Generate a Dockerfile
result = client.call("devops-mcp", "generate_dockerfile",
                     runtime="node", version="20")
print(result.text)
```

## Authentication

```python
# Option 1: Pass directly
client = CrowVaultClient(api_key="cv_...")

# Option 2: Environment variable
# export CROWVAULT_API_KEY=cv_...
client = CrowVaultClient()
```

## API Reference

### Call a Tool

```python
result = client.call("database-mcp", "design_schema",
                     aggregate="Order",
                     database="postgresql",
                     outputFormat="prisma")

print(result.text)       # Generated code
print(result.success)    # True/False
print(result.meta)       # {server, tool, durationMs, ...}
```

### Call with Dict Args

Use `call_raw()` when arg names conflict with Python keywords:

```python
result = client.call_raw("api-mcp", "generate_openapi_spec", {
    "service": "users",
    "version": "v1",
    "format": "yaml",   # "format" is a Python builtin
})
```

### List Servers & Tools

```python
# All servers
servers = client.servers()
for s in servers:
    print(f"{s['name']} — {s['toolCount']} tools")

# All tools (or filter)
tools = client.tools(server="database-mcp")
tools = client.tools(search="schema")
```

### Batch Execution

Execute up to 10 tools in parallel:

```python
result = client.batch([
    {"server": "database-mcp", "tool": "design_schema",
     "args": {"aggregate": "Order", "database": "postgresql"}},
    {"server": "devops-mcp", "tool": "generate_dockerfile",
     "args": {"runtime": "node", "version": "20"}},
    {"server": "devops-mcp", "tool": "generate_k8s_deployment",
     "args": {"name": "order-service"}},
])

print(f"{result.succeeded}/{len(result.results)} succeeded")
for r in result.results:
    print(r.text[:100])
```

### Workflows

Run multi-step pipelines that chain tools together:

```python
# List available workflows
workflows = client.workflows()
for wf in workflows:
    print(f"{wf['id']} — {wf['stepCount']} steps")

# Run a workflow
result = client.run_workflow("microservice-scaffold",
                             name="orders",
                             language="node",
                             database="postgresql")

print(result)  # Step-by-step summary
print(result.success)
print(result.total_duration_ms)

for step in result.results:
    print(f"{step['tool']} — {step['durationMs']}ms")
```

**Available workflows:**
- `microservice-scaffold` — Microservice + schema + migration + Docker + K8s (5 steps)
- `api-full-stack` — OpenAPI + endpoint + tests + contracts (4 steps)
- `ddd-complete` — Bounded context + model + aggregate + entity + repo + schema (6 steps)
- `event-driven` — Kafka + event handler + DLQ (3 steps)
- `deploy-stack` — Dockerfile + Compose + K8s + Helm (4 steps)
- `database-setup` — Schema + ORM + migration + seed (4 steps)

## 9 Servers, 327 Tools

| Server | Tools | Coverage |
|--------|-------|----------|
| AWS | 53 | EC2, S3, Lambda, RDS, ECS, CloudFormation, IAM |
| GCP | 41 | Compute, GKE, Cloud Run, BigQuery, Pub/Sub |
| Full Stack | 40 | Express, NestJS, React, Vue, Next.js, FastAPI |
| Frontend | 36 | Components, state, routing, forms, accessibility |
| Database | 34 | PostgreSQL, MySQL, MongoDB, Prisma, migrations |
| Testing | 31 | Jest, Vitest, Cypress, load tests, mocks |
| Security | 31 | Auth, RBAC, encryption, OWASP, scanning |
| DevOps | 31 | Docker, K8s, Terraform, Helm, CI/CD, Prometheus |
| API | 30 | OpenAPI, GraphQL, gRPC, Kafka, webhooks, OAuth |

## Error Handling

```python
from crowvault import CrowVaultClient
from crowvault.client import CrowVaultError

client = CrowVaultClient()

try:
    result = client.call("database-mcp", "design_schema",
                         aggregate="Order", database="postgresql")
    print(result.text)
except CrowVaultError as e:
    print(f"Error: {e} (HTTP {e.status})")
```

## Pricing

- **Free**: 50 calls/month, 2 API keys — [Sign up free](https://crowvault.ai/register?plan=free)
- **Developer**: $49/month, 1,000 calls, 5 keys
- **Team**: $199/month, 10,000 calls, 10 keys
- **Enterprise**: Custom

## License

MIT. Copyright TechSynergy Corp.
