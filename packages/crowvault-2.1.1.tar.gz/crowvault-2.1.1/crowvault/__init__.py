# Copyright (c) 2026 TechSynergy Corp. All rights reserved.
# https://crowvault.ai

"""CrowVault Python SDK — MCP-native SDK for 327 AI dev tools — code generation via Model Context Protocol."""

from crowvault.client import CrowVaultClient

__version__ = "2.1.1"
__all__ = ["CrowVaultClient"]
