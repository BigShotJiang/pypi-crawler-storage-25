# Copyright (c) 2026 TechSynergy Corp. All rights reserved.
# https://crowvault.ai

"""CrowVault API client — zero external dependencies (uses urllib)."""

import json
import os
import urllib.request
import urllib.error
from typing import Any, Optional


class CrowVaultError(Exception):
    """Raised when the CrowVault API returns an error."""

    def __init__(self, message: str, status: int = 0, meta: Optional[dict] = None):
        super().__init__(message)
        self.status = status
        self.meta = meta or {}


class CrowVaultClient:
    """Client for the CrowVault API.

    Usage:
        from crowvault import CrowVaultClient

        client = CrowVaultClient(api_key="cv_...")
        result = client.call("database-mcp", "design_schema", aggregate="Order", database="postgresql")
        print(result.text)
    """

    DEFAULT_URL = "https://api.crowvault.ai"
    TIMEOUT = 60

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        timeout: Optional[int] = None,
    ):
        self.api_key = api_key or os.environ.get("CROWVAULT_API_KEY", "")
        self.api_url = (api_url or os.environ.get("CROWVAULT_API_URL", self.DEFAULT_URL)).rstrip("/")
        self.timeout = timeout or self.TIMEOUT

        if not self.api_key:
            raise CrowVaultError("API key required. Pass api_key or set CROWVAULT_API_KEY env var.")

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = f"{self.api_url}{path}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "crowvault-python/2.1.1",
        }
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            try:
                err_body = json.loads(e.read().decode())
                msg = err_body.get("error", f"HTTP {e.code}")
            except Exception:
                msg = f"HTTP {e.code}"
            raise CrowVaultError(msg, status=e.code) from None
        except urllib.error.URLError as e:
            raise CrowVaultError(f"Connection error: {e.reason}") from None

    # ── Servers & Tools ──────────────────────────────────────────────────

    def servers(self) -> dict:
        """List all MCP servers with tool counts.

        Returns:
            Dict mapping server ID to server info (displayName, tools, status).
        """
        return self._request("GET", "/v1/servers")

    def tools(self, server: Optional[str] = None, search: Optional[str] = None) -> list[dict]:
        """List tools, optionally filtered by server or search query."""
        params = []
        if server:
            params.append(f"server={server}")
        if search:
            params.append(f"search={urllib.request.quote(search)}")
        qs = f"?{'&'.join(params)}" if params else ""
        data = self._request("GET", f"/v1/tools{qs}")
        return data.get("tools", [])

    # ── Tool Execution ───────────────────────────────────────────────────

    def call(self, server: str, tool: str, **args: Any) -> "ToolResult":
        """Call a single tool.

        Args:
            server: Server ID (e.g., "database-mcp")
            tool: Tool name (e.g., "design_schema")
            **args: Tool arguments as keyword args

        Returns:
            ToolResult with .text, .success, .meta

        Example:
            result = client.call("database-mcp", "design_schema",
                                 aggregate="Order", database="postgresql")
        """
        data = self._request("POST", "/v1/tools/call", {
            "server": server, "tool": tool, "args": args,
        })
        return ToolResult(data)

    def call_raw(self, server: str, tool: str, args: Optional[dict] = None) -> "ToolResult":
        """Call a single tool with a dict of args (instead of kwargs).

        Useful when arg names conflict with Python keywords.
        """
        data = self._request("POST", "/v1/tools/call", {
            "server": server, "tool": tool, "args": args or {},
        })
        return ToolResult(data)

    def batch(self, requests: list[dict]) -> "BatchResult":
        """Execute multiple tools in parallel (max 10).

        Args:
            requests: List of {"server": str, "tool": str, "args": dict}

        Returns:
            BatchResult with .results, .succeeded, .failed
        """
        if len(requests) > 10:
            raise CrowVaultError("Maximum 10 requests per batch")
        data = self._request("POST", "/v1/tools/batch", {"requests": requests})
        return BatchResult(data)

    # ── Workflows ────────────────────────────────────────────────────────

    def workflows(self) -> list[dict]:
        """List available workflows."""
        data = self._request("GET", "/v1/workflows")
        return data.get("workflows", [])

    def run_workflow(self, workflow: str, **args: Any) -> "WorkflowResult":
        """Execute a multi-step workflow.

        Args:
            workflow: Workflow ID (e.g., "microservice-scaffold")
            **args: Input arguments as keyword args

        Returns:
            WorkflowResult with .success, .results, .total_duration_ms
        """
        data = self._request("POST", "/v1/workflows/execute", {
            "workflow": workflow, "args": args,
        })
        return WorkflowResult(data)


class ToolResult:
    """Result from a single tool call."""

    def __init__(self, data: dict):
        self._data = data
        self.success = data.get("success", not data.get("error"))
        self.text = data.get("result", data.get("text", ""))
        self.error = data.get("error")
        self.meta = data.get("meta", {})

    def __str__(self) -> str:
        return self.text if self.success else f"Error: {self.error}"

    def __repr__(self) -> str:
        return f"ToolResult(success={self.success}, length={len(self.text)})"


class BatchResult:
    """Result from a batch execution."""

    def __init__(self, data: dict):
        self._data = data
        self.results = [ToolResult(r) for r in data.get("results", [])]
        self.meta = data.get("meta", {})
        self.succeeded = self.meta.get("succeeded", 0)
        self.failed = self.meta.get("failed", 0)
        self.total_duration_ms = self.meta.get("totalDurationMs", 0)

    def __repr__(self) -> str:
        return f"BatchResult(succeeded={self.succeeded}, failed={self.failed})"


class WorkflowResult:
    """Result from a workflow execution."""

    def __init__(self, data: dict):
        self._data = data
        self.success = data.get("success", False)
        self.workflow = data.get("workflow", "")
        self.failed_step = data.get("failedStep")
        self.total_duration_ms = data.get("totalDurationMs", 0)
        self.results = data.get("results", [])

    def __repr__(self) -> str:
        steps = len(self.results)
        return f"WorkflowResult(success={self.success}, steps={steps}, duration={self.total_duration_ms}ms)"

    def __str__(self) -> str:
        lines = []
        for i, r in enumerate(self.results):
            icon = "+" if r.get("success") else "x"
            lines.append(f"  [{icon}] {i+1}. {r.get('tool', '?')} — {r.get('durationMs', 0)}ms")
        status = "OK" if self.success else f"FAILED at {self.failed_step}"
        return f"Workflow: {self.workflow} ({status}, {self.total_duration_ms}ms)\n" + "\n".join(lines)
