# eml-graph

Equivalence-class graph over corpora of SymPy expressions. Cluster a
codebase's mathematical content by Pfaffian cost class; optionally
add cost-monotone rewrite edges; render to Graphviz DOT for
visualization.

## Quick start

```bash
pip install eml-graph
```

```python
from eml_graph import build_graph, to_dot
import sympy as sp

x, y = sp.symbols("x y")
corpus = [
    sp.sin(x),
    sp.sin(y),                    # collapses with sin(x) by axes
    sp.exp(x),
    sp.cos(y),                    # collapses with sin(*) by axes
    sp.exp(x) / (1 + sp.exp(x)),  # textbook sigmoid
    1 / (1 + sp.exp(-x)),         # canonical sigmoid
]

g = build_graph(corpus, label_with_discover=True)
print(g.num_nodes(), "nodes across", g.num_classes(), "Pfaffian-cost classes")

# Save as DOT, then render with graphviz:
with open("corpus.dot", "w") as f:
    f.write(to_dot(g, include_edges=True))
# $ dot -Tsvg corpus.dot -o corpus.svg
```

## What does this do that nothing else does?

Software architects have **call graphs**. Mathematicians have
**equivalence classes**. `eml-graph` is the first tool to give you
*both at once* for a real corpus of code.

Open `numpy/`, `scipy/`, `torch/`, or your own pipeline; scrape every
SymPy expression (or build them from your symbolic layer); feed the
list to `build_graph()`. You get back:

- **Cost-class clusters.** All expressions sharing the same Pfaffian
  profile (`pfaffian_r`, `max_path_r`, `eml_depth`, correction sum)
  collapse into one cluster. You see immediately which mathematical
  shapes the codebase actually uses.
- **Rewrite edges (optional).** Within a cluster, two expressions
  are connected if the `eml-rewrite` library can walk one into the
  other under monotone-decreasing cost. Edge weights are the rewrite
  step counts.
- **Named labels (optional).** When `eml-discover` is installed and
  `label_with_discover=True`, nodes that match a registry formula
  (sigmoid, GELU, Pythagorean identity, ...) get the canonical name.

## Output

`to_dot(graph)` returns a Graphviz DOT-format string. No binary deps;
pipe through `dot`, `neato`, `sfdp`, or paste into a DOT web viewer.
For SVG: `dot -Tsvg input.dot -o output.svg`.

## Status

Beta. v0.1.0 is the MVP — clustering + DOT rendering + lazy
path-based edges. Roadmap:

- v0.2: matplotlib renderer (no graphviz binary needed)
- v0.3: streaming graph for corpora that don't fit in memory
- v0.4: per-class summary statistics (entropy, modularity, ...)
- v1.0: stable API + first public release with paper

## License

PROPRIETARY-PRE-RELEASE. Patent pending. Do not redistribute.
