"""p4net: a P4Runtime-native SDN simulation framework."""

from p4net.network import Network

__all__ = ["Network", "__version__"]
__version__ = "0.2.0"
