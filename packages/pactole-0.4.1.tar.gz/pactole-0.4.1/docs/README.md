[Documentation](./README.md)

# Documentation

Pactole is a Python library for managing lottery results.

> This is the Python version. A TypeScript version is also available: [pactole-js](https://github.com/cerbernetix/pactole-js).

## Pages

- [Overview](./overview.md): Core concepts and quick usage examples.
- [Installation](./install.md): Runtime and development installation steps.
- [Usage](./usage/README.md): Practical guides for combinations and lottery classes.
    - [Combinations](./usage/combinations.md): Create, compare, and rank combinations.
    - [Lottery classes](./usage/lotteries.md): Handle draw days, generate combinations, and query history.
- [Environment variables](./environment.md): Configuration variables for built-in lotteries.
- [Developer overview](./developer_overview.md): Architecture and implementation notes.
- [API reference](./api/README.md): Generated API documentation by module.

## Changes

For the changelog, see [CHANGELOG.md](https://github.com/cerbernetix/pactole/blob/main/CHANGELOG.md).

## License

MIT License - See [LICENSE](https://github.com/cerbernetix/pactole/blob/main/LICENSE) file for details.
