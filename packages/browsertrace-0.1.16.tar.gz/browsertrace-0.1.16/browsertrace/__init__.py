"""BrowserTrace — see what your AI browser agent did and why it failed."""

from .tracer import Run, Tracer, trace

__version__ = "0.1.16"
__all__ = ["Tracer", "Run", "trace"]
