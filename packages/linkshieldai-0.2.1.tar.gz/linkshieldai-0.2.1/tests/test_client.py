from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from linkshieldai import LinkShieldAI
from linkshieldai.errors import APIConnectionError, APIResponseError, APIStatusError, AuthenticationError, RateLimitError


def make_client(handler):
    transport = httpx.MockTransport(handler)
    http_client = httpx.Client(transport=transport)
    return LinkShieldAI(api_key="test-key", client=http_client, backoff_factor=0)


def test_requires_api_key(monkeypatch):
    monkeypatch.delenv("LINKSHIELDAI_API_KEY", raising=False)
    with pytest.raises(AuthenticationError):
        LinkShieldAI()


def test_basic_check_malicious_builds_query():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = request.url
        return httpx.Response(200, json={"result": "Might be malicious"})

    client = make_client(handler)
    result = client.basic_check("https://bad.test/login")

    assert result.is_malicious is True
    assert result.is_safe is False
    assert seen["url"].path == "/"
    assert seen["url"].params["key"] == "test-key"
    assert seen["url"].params["url"] == "https://bad.test/login"


def test_basic_check_safe_response():
    client = make_client(lambda request: httpx.Response(200, json={"result": "likely safe"}))

    result = client.basic_check("https://example.com")

    assert result.is_malicious is False
    assert result.is_safe is True
    assert result.raw == {"result": "likely safe"}


def test_detailed_check_normalizes_screenshot_url_and_tag():
    payload = {
        "result": "Might be malicious",
        "screenshot url": "https://api.linkshieldai.com/screenshot/abc.png",
        "tag": "Yahoo",
    }
    client = make_client(lambda request: httpx.Response(200, json=payload))

    result = client.detailed_check("https://phish.test")

    assert result.is_malicious is True
    assert result.screenshot_url == "https://api.linkshieldai.com/screenshot/abc.png"
    assert result.tag == "Yahoo"
    assert result.raw == payload


def test_screenshot_downloads_bytes_and_writes_file(tmp_path: Path):
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/screenshot/abc.png"
        return httpx.Response(200, content=b"PNGDATA")

    client = make_client(handler)
    output = tmp_path / "shot.png"

    content = client.get_screenshot("https://api.linkshieldai.com/screenshot/abc.png", output)

    assert content == b"PNGDATA"
    assert output.read_bytes() == b"PNGDATA"


def test_nsfw_check_converts_string_boolean():
    client = make_client(lambda request: httpx.Response(200, json={"result": "True"}))

    result = client.nsfw_check("https://adult.test")

    assert result.is_nsfw is True


def test_chimera_parses_ai_response():
    payload = {
        "detection_method": "ai-model",
        "matched_signatures": 0,
        "probability": 0.9947241392537983,
        "result": "malicious",
        "url": "https://steamcomun1ty.com/id=5944478616",
    }
    client = make_client(lambda request: httpx.Response(200, json=payload))

    result = client.chimera("https://steamcomun1ty.com/id=5944478616")

    assert result.is_malicious is True
    assert result.probability == pytest.approx(0.9947241392537983)
    assert result.detection_method == "ai-model"
    assert result.matched_signatures == 0


def test_error_payload_raises_response_error():
    client = make_client(lambda request: httpx.Response(200, json={"Error": "Unable to reach the site"}))

    with pytest.raises(APIResponseError, match="Unable to reach the site"):
        client.detailed_check("https://down.test")


def test_rate_limit_raises_rate_limit_error():
    client = LinkShieldAI(
        api_key="test-key",
        client=httpx.Client(transport=httpx.MockTransport(lambda request: httpx.Response(429, json={"error": "Too many requests"}))),
        max_retries=0,
    )

    with pytest.raises(RateLimitError):
        client.basic_check("https://example.com")


def test_http_error_raises_status_error():
    client = make_client(lambda request: httpx.Response(500, json={"error": "Invalid or unreachable URL."}))

    with pytest.raises(APIStatusError) as exc:
        client.chimera("https://bad.test")

    assert exc.value.status_code == 500


def test_retries_transient_status_then_succeeds():
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        if calls["count"] == 1:
            return httpx.Response(503, json={"error": "temporary"})
        return httpx.Response(200, json={"result": "likely safe"})

    client = make_client(handler)

    result = client.basic_check("https://example.com")

    assert result.is_safe is True
    assert calls["count"] == 2


def test_invalid_html_response_includes_preview():
    client = make_client(lambda request: httpx.Response(200, text="<html>oops</html>", headers={"content-type": "text/html"}))

    with pytest.raises(APIResponseError, match="Body preview"):
        client.basic_check("https://example.com")


def test_connection_error_after_retries():
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        raise httpx.ConnectTimeout("timeout", request=request)

    client = make_client(handler)

    with pytest.raises(APIConnectionError):
        client.basic_check("https://example.com")

    assert calls["count"] == 3
