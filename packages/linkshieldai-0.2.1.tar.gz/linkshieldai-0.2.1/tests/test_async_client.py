from __future__ import annotations

import httpx

from linkshieldai import AsyncLinkShieldAI


def make_async_client(handler):
    transport = httpx.MockTransport(handler)
    http_client = httpx.AsyncClient(transport=transport)
    return AsyncLinkShieldAI(api_key="test-key", client=http_client, backoff_factor=0)


async def test_async_basic_check():
    client = make_async_client(lambda request: httpx.Response(200, json={"result": "Might be malicious"}))

    result = await client.basic_check("https://bad.test")
    await client.close()

    assert result.is_malicious is True


async def test_async_chimera_safe():
    client = make_async_client(
        lambda request: httpx.Response(
            200,
            json={
                "detection_method": "ai-model",
                "matched_signatures": 0,
                "probability": 0.13061513415575468,
                "result": "benign",
                "url": "https://google.com",
            },
        )
    )

    result = await client.chimera("https://google.com")
    await client.close()

    assert result.is_malicious is False
    assert result.result == "benign"


async def test_async_retries_transient_status_then_succeeds():
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        if calls["count"] == 1:
            return httpx.Response(504, json={"error": "temporary"})
        return httpx.Response(200, json={"result": "likely safe"})

    client = make_async_client(handler)

    result = await client.basic_check("https://example.com")
    await client.close()

    assert result.is_safe is True
    assert calls["count"] == 2
