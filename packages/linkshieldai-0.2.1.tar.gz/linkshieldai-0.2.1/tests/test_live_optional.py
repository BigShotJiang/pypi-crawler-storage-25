from __future__ import annotations

import os

import pytest

from linkshieldai import LinkShieldAI


@pytest.mark.skipif(not os.getenv("LINKSHIELDAI_API_KEY"), reason="Set LINKSHIELDAI_API_KEY to run live API smoke tests.")
def test_live_basic_check_smoke():
    client = LinkShieldAI(max_retries=1)

    result = client.basic_check("https://google.com")

    assert result.raw
    assert result.result is not None
