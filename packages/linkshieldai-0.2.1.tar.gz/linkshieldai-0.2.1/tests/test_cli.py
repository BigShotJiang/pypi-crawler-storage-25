from __future__ import annotations

import json

import httpx

from linkshieldai.cli import main


def test_cli_basic_outputs_json(monkeypatch, capsys):
    class FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return None

        def basic_check(self, url):
            from linkshieldai.types import BasicCheckResult

            return BasicCheckResult(result="likely safe", is_malicious=False, is_safe=True, raw={"result": "likely safe"})

    monkeypatch.setattr("linkshieldai.cli.LinkShieldAI", FakeClient)

    exit_code = main(["--api-key", "test-key", "basic", "https://example.com"])

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    assert output["is_safe"] is True
