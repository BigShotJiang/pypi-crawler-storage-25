from __future__ import annotations

import httpx

from linkshieldai import LinkShieldAI


def test_main_example_detailed_check_uses_client_without_live_api_call():
    seen = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["url"] = request.url
        return httpx.Response(
            200,
            json={
                "result": "likely safe",
                "screenshot url": "https://api.linkshieldai.com/screenshot/google.png",
                "tag": "Google",
            },
        )

    client = LinkShieldAI(
        api_key="test-key",
        client=httpx.Client(transport=httpx.MockTransport(handler)),
        backoff_factor=0,
    )

    response = client.detailed_check("https://www.google.com")

    assert seen["url"].params["key"] == "test-key"
    assert seen["url"].params["url"] == "https://www.google.com"
    assert response.is_malicious is False
    assert response.screenshot_url == "https://api.linkshieldai.com/screenshot/google.png"
    assert response.tag == "Google"
