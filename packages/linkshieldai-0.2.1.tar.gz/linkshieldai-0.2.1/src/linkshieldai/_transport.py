from __future__ import annotations

import json
import logging
import time
from typing import Any

import httpx

from .errors import APIConnectionError, APIResponseError, APIStatusError, RateLimitError, error_message_from_payload


RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


def parse_retry_after(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return max(float(value), 0.0)
    except ValueError:
        return None


def parse_json_response(response: httpx.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError as exc:
        content_type = response.headers.get("content-type", "")
        preview = response.text.strip().replace("\n", " ")[:300]
        message = "LinkShieldAI API returned invalid JSON."
        if preview:
            message = f"{message} Content-Type: {content_type or 'unknown'}. Body preview: {preview}"
        raise APIResponseError(message) from exc
    if not isinstance(payload, dict):
        raise APIResponseError("LinkShieldAI API returned a non-object JSON response.", payload=payload)
    return payload


def handle_status_error(response: httpx.Response) -> None:
    if response.status_code < 400:
        return
    payload = None
    try:
        payload = response.json()
    except ValueError:
        pass
    if response.status_code == 429:
        retry_after = parse_retry_after(response.headers.get("retry-after"))
        raise RateLimitError(retry_after=retry_after)
    message = error_message_from_payload(payload, f"LinkShieldAI API returned HTTP {response.status_code}.")
    raise APIStatusError(message, status_code=response.status_code, response=response, payload=payload)


def retry_delay(attempt: int, backoff_factor: float, response: httpx.Response | None = None) -> float:
    if response is not None:
        retry_after = parse_retry_after(response.headers.get("retry-after"))
        if retry_after is not None:
            return retry_after
    return backoff_factor * (2 ** attempt)


def should_retry_response(response: httpx.Response, attempt: int, max_retries: int) -> bool:
    return attempt < max_retries and response.status_code in RETRYABLE_STATUS_CODES


def should_retry_exception(exc: httpx.RequestError, attempt: int, max_retries: int) -> bool:
    return attempt < max_retries and isinstance(exc, (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout, httpx.PoolTimeout))


def log_request(logger: logging.Logger, method: str, url: str) -> None:
    logger.debug("LinkShieldAI request: %s %s", method, url)


def log_retry(logger: logging.Logger, attempt: int, delay: float, reason: str) -> None:
    logger.debug("LinkShieldAI retry %s in %.2fs: %s", attempt + 1, delay, reason)
