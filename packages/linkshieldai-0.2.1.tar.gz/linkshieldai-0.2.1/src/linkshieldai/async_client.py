from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import httpx

from ._utils import (
    DEFAULT_BASE_URL,
    normalize_base_url,
    parse_basic,
    parse_chimera,
    parse_detailed,
    parse_nsfw,
    resolve_api_key,
    screenshot_file_name,
)
from ._transport import handle_status_error, log_request, log_retry, parse_json_response, retry_delay, should_retry_exception, should_retry_response
from .errors import APIConnectionError
from .types import BasicCheckResult, ChimeraResult, DetailedCheckResult, NSFWCheckResult


class AsyncLinkShieldAI:
    """Asynchronous client for the LinkShieldAI API."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout = 10.0,
        max_retries: int = 2,
        backoff_factor: float = 0.5,
        logger: logging.Logger | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.api_key = resolve_api_key(api_key)
        self.base_url = normalize_base_url(base_url)
        self.max_retries = max(0, max_retries)
        self.backoff_factor = max(0.0, backoff_factor)
        self.logger = logger or logging.getLogger("linkshieldai")
        self._owns_client = client is None
        self._client = client or httpx.AsyncClient(timeout=timeout)

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncLinkShieldAI":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def basic_check(self, url: str) -> BasicCheckResult:
        payload = await self._get_json("/", params={"key": self.api_key, "url": url})
        return parse_basic(payload)

    async def detailed_check(self, url: str) -> DetailedCheckResult:
        payload = await self._get_json("/classify_link", params={"key": self.api_key, "url": url})
        return parse_detailed(payload)

    async def nsfw_check(self, url: str) -> NSFWCheckResult:
        payload = await self._get_json("/nsfw/site", params={"key": self.api_key, "url": url})
        return parse_nsfw(payload)

    async def chimera(self, url: str) -> ChimeraResult:
        payload = await self._get_json("/chimera", params={"key": self.api_key, "url": url})
        return parse_chimera(payload)

    async def is_malicious(self, url: str) -> bool:
        return (await self.basic_check(url)).is_malicious

    async def is_nsfw(self, url: str) -> bool:
        return (await self.nsfw_check(url)).is_nsfw

    async def get_screenshot(self, file_name_or_url: str, output_path: str | Path | None = None) -> bytes:
        file_name = screenshot_file_name(file_name_or_url)
        response = await self._request("GET", f"/screenshot/{file_name}")
        content = response.content
        if output_path is not None:
            Path(output_path).write_bytes(content)
        return content

    async def _get_json(self, path: str, *, params: dict[str, object]) -> dict[str, object]:
        response = await self._request("GET", path, params=params)
        payload = parse_json_response(response)
        from ._utils import ensure_json_payload

        return ensure_json_payload(payload)

    async def _request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        url = f"{self.base_url}{path}"
        for attempt in range(self.max_retries + 1):
            log_request(self.logger, method, url)
            try:
                response = await self._client.request(method, url, **kwargs)
            except httpx.RequestError as exc:
                if should_retry_exception(exc, attempt, self.max_retries):
                    delay = retry_delay(attempt, self.backoff_factor)
                    log_retry(self.logger, attempt, delay, str(exc))
                    await asyncio.sleep(delay)
                    continue
                raise APIConnectionError(f"Could not connect to LinkShieldAI API: {exc}") from exc
            if should_retry_response(response, attempt, self.max_retries):
                delay = retry_delay(attempt, self.backoff_factor, response)
                log_retry(self.logger, attempt, delay, f"HTTP {response.status_code}")
                await asyncio.sleep(delay)
                continue
            handle_status_error(response)
            return response
        raise APIConnectionError("Could not connect to LinkShieldAI API after retries.")
