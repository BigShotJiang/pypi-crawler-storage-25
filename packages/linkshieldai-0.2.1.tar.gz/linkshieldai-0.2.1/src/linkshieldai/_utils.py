from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse

from .errors import APIResponseError, AuthenticationError, error_message_from_payload
from .types import BasicCheckResult, ChimeraResult, DetailedCheckResult, NSFWCheckResult, RawJSON


DEFAULT_BASE_URL = "https://api.linkshieldai.com"


def normalize_base_url(base_url: str) -> str:
    return base_url.rstrip("/")


def resolve_api_key(api_key: str | None) -> str:
    resolved = api_key or os.getenv("LINKSHIELDAI_API_KEY")
    if not resolved:
        raise AuthenticationError(
            "LinkShieldAI API key is required. Pass api_key=... or set LINKSHIELDAI_API_KEY."
        )
    return resolved


def ensure_json_payload(payload: Any) -> RawJSON:
    if not isinstance(payload, dict):
        raise APIResponseError("LinkShieldAI API returned a non-object JSON response.", payload=payload)
    if payload.get("Error") or payload.get("error"):
        raise APIResponseError(error_message_from_payload(payload), payload=payload)
    return payload


def is_malicious_text(result: Any) -> bool:
    value = str(result or "").strip().lower()
    safe_phrases = ("didn't detect", "did not detect", "no malicious", "not malicious")
    if any(phrase in value for phrase in safe_phrases):
        return False
    return value in {"might be malicious", "malicious", "true"} or "malicious" in value


def is_safe_text(result: Any) -> bool:
    value = str(result or "").strip().lower()
    return value in {
        "likely safe",
        "the system didn't detect anything malicious.",
        "false",
        "benign",
    } or "safe" in value or "benign" in value


def parse_basic(payload: Mapping[str, Any]) -> BasicCheckResult:
    raw = dict(payload)
    result = raw.get("result")
    return BasicCheckResult(
        result=str(result) if result is not None else None,
        is_malicious=is_malicious_text(result),
        is_safe=is_safe_text(result),
        raw=raw,
    )


def parse_detailed(payload: Mapping[str, Any]) -> DetailedCheckResult:
    raw = dict(payload)
    result = raw.get("result")
    screenshot_url = raw.get("screenshot url") or raw.get("screenshot_url")
    tag = raw.get("tag")
    return DetailedCheckResult(
        result=str(result) if result is not None else None,
        screenshot_url=str(screenshot_url) if screenshot_url else None,
        tag=str(tag) if tag is not None else None,
        is_malicious=is_malicious_text(result),
        raw=raw,
    )


def parse_nsfw(payload: Mapping[str, Any]) -> NSFWCheckResult:
    raw = dict(payload)
    result = raw.get("result")
    is_nsfw = str(result or "").strip().lower() == "true"
    return NSFWCheckResult(
        result=str(result) if result is not None else None,
        is_nsfw=is_nsfw,
        raw=raw,
    )


def parse_chimera(payload: Mapping[str, Any]) -> ChimeraResult:
    raw = dict(payload)
    result = raw.get("result")
    probability = raw.get("probability")
    matched_signatures = raw.get("matched_signatures")
    try:
        probability_value = float(probability) if probability is not None else None
    except (TypeError, ValueError):
        probability_value = None
    try:
        matched_value = int(matched_signatures) if matched_signatures is not None else None
    except (TypeError, ValueError):
        matched_value = None
    return ChimeraResult(
        result=str(result) if result is not None else None,
        probability=probability_value,
        detection_method=str(raw["detection_method"]) if raw.get("detection_method") is not None else None,
        matched_signatures=matched_value,
        url=str(raw["url"]) if raw.get("url") is not None else None,
        is_malicious=is_malicious_text(result),
        raw=raw,
    )


def screenshot_file_name(file_name_or_url: str) -> str:
    parsed = urlparse(file_name_or_url)
    if parsed.scheme and parsed.path:
        candidate = Path(parsed.path).name
    else:
        candidate = Path(file_name_or_url).name
    if not candidate:
        raise ValueError("A screenshot file name or screenshot URL is required.")
    return candidate
