from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


RawJSON = Dict[str, Any]


@dataclass(frozen=True)
class BasicCheckResult:
    result: Optional[str]
    is_malicious: bool
    is_safe: bool
    raw: RawJSON


@dataclass(frozen=True)
class DetailedCheckResult:
    result: Optional[str]
    screenshot_url: Optional[str]
    tag: Optional[str]
    is_malicious: bool
    raw: RawJSON


@dataclass(frozen=True)
class NSFWCheckResult:
    result: Optional[str]
    is_nsfw: bool
    raw: RawJSON


@dataclass(frozen=True)
class ChimeraResult:
    result: Optional[str]
    probability: Optional[float]
    detection_method: Optional[str]
    matched_signatures: Optional[int]
    url: Optional[str]
    is_malicious: bool
    raw: RawJSON
