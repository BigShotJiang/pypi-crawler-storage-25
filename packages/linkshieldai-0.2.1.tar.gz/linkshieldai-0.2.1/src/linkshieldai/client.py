from __future__ import annotations

import logging
import time
from pathlib import Path

import httpx

from ._utils import (
    DEFAULT_BASE_URL,
    normalize_base_url,
    parse_basic,
    parse_chimera,
    parse_detailed,
    parse_nsfw,
    resolve_api_key,
    screenshot_file_name,
)
from ._transport import handle_status_error, log_request, log_retry, parse_json_response, retry_delay, should_retry_exception, should_retry_response
from .errors import APIConnectionError
from .types import BasicCheckResult, ChimeraResult, DetailedCheckResult, NSFWCheckResult


class LinkShieldAI:
    """Synchronous client for the LinkShieldAI API."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float | httpx.Timeout = 10.0,
        max_retries: int = 2,
        backoff_factor: float = 0.5,
        logger: logging.Logger | None = None,
        client: httpx.Client | None = None,
    ) -> None:
        self.api_key = resolve_api_key(api_key)
        self.base_url = normalize_base_url(base_url)
        self.max_retries = max(0, max_retries)
        self.backoff_factor = max(0.0, backoff_factor)
        self.logger = logger or logging.getLogger("linkshieldai")
        self._owns_client = client is None
        self._client = client or httpx.Client(timeout=timeout)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "LinkShieldAI":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def basic_check(self, url: str) -> BasicCheckResult:
        payload = self._get_json("/", params={"key": self.api_key, "url": url})
        return parse_basic(payload)

    def detailed_check(self, url: str) -> DetailedCheckResult:
        payload = self._get_json("/classify_link", params={"key": self.api_key, "url": url})
        return parse_detailed(payload)

    def nsfw_check(self, url: str) -> NSFWCheckResult:
        payload = self._get_json("/nsfw/site", params={"key": self.api_key, "url": url})
        return parse_nsfw(payload)

    def chimera(self, url: str) -> ChimeraResult:
        payload = self._get_json("/chimera", params={"key": self.api_key, "url": url})
        return parse_chimera(payload)

    def is_malicious(self, url: str) -> bool:
        return self.basic_check(url).is_malicious

    def is_nsfw(self, url: str) -> bool:
        return self.nsfw_check(url).is_nsfw

    def get_screenshot(self, file_name_or_url: str, output_path: str | Path | None = None) -> bytes:
        file_name = screenshot_file_name(file_name_or_url)
        response = self._request("GET", f"/screenshot/{file_name}")
        content = response.content
        if output_path is not None:
            Path(output_path).write_bytes(content)
        return content

    def _get_json(self, path: str, *, params: dict[str, object]) -> dict[str, object]:
        response = self._request("GET", path, params=params)
        payload = parse_json_response(response)
        from ._utils import ensure_json_payload

        return ensure_json_payload(payload)

    def _request(self, method: str, path: str, **kwargs: object) -> httpx.Response:
        url = f"{self.base_url}{path}"
        for attempt in range(self.max_retries + 1):
            log_request(self.logger, method, url)
            try:
                response = self._client.request(method, url, **kwargs)
            except httpx.RequestError as exc:
                if should_retry_exception(exc, attempt, self.max_retries):
                    delay = retry_delay(attempt, self.backoff_factor)
                    log_retry(self.logger, attempt, delay, str(exc))
                    time.sleep(delay)
                    continue
                raise APIConnectionError(f"Could not connect to LinkShieldAI API: {exc}") from exc
            if should_retry_response(response, attempt, self.max_retries):
                delay = retry_delay(attempt, self.backoff_factor, response)
                log_retry(self.logger, attempt, delay, f"HTTP {response.status_code}")
                time.sleep(delay)
                continue
            handle_status_error(response)
            return response
        raise APIConnectionError("Could not connect to LinkShieldAI API after retries.")
