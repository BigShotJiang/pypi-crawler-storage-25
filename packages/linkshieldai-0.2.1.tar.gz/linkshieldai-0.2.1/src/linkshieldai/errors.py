from __future__ import annotations

from typing import Any, Optional


class LinkShieldAIError(Exception):
    """Base exception for all SDK errors."""


class AuthenticationError(LinkShieldAIError):
    """Raised when an API key is missing or rejected."""


class RateLimitError(LinkShieldAIError):
    """Raised when the API reports a rate limit response."""

    def __init__(self, message: str = "LinkShieldAI API rate limit exceeded.", *, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class APIConnectionError(LinkShieldAIError):
    """Raised when the SDK cannot connect to the API."""


class APIStatusError(LinkShieldAIError):
    """Raised for non-success HTTP responses."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response: Any | None = None,
        payload: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response
        self.payload = payload


class APIResponseError(LinkShieldAIError):
    """Raised when the API returns a JSON error payload."""

    def __init__(self, message: str, *, payload: Any | None = None) -> None:
        super().__init__(message)
        self.payload = payload


def error_message_from_payload(payload: Any, fallback: Optional[str] = None) -> str:
    if isinstance(payload, dict):
        for key in ("Error", "error", "message", "detail"):
            value = payload.get(key)
            if value:
                return str(value)
    return fallback or "LinkShieldAI API request failed."
