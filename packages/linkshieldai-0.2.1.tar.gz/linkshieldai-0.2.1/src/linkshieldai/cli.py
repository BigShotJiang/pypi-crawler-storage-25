from __future__ import annotations

import argparse
import dataclasses
import json
import logging
import sys
from typing import Any

from .client import LinkShieldAI
from .errors import LinkShieldAIError


def result_to_jsonable(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    if isinstance(value, bytes):
        return {"bytes": len(value)}
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="linkshieldai", description="Command line client for the LinkShieldAI API.")
    parser.add_argument("--api-key", help="LinkShieldAI API key. Defaults to LINKSHIELDAI_API_KEY.")
    parser.add_argument("--base-url", default="https://api.linkshieldai.com", help="API base URL.")
    parser.add_argument("--timeout", type=float, default=10.0, help="Request timeout in seconds.")
    parser.add_argument("--max-retries", type=int, default=2, help="Retry attempts for transient failures.")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging.")

    subparsers = parser.add_subparsers(dest="command", required=True)

    basic = subparsers.add_parser("basic", help="Run a basic URL safety check.")
    basic.add_argument("url")

    detailed = subparsers.add_parser("detailed", help="Run a detailed URL safety check.")
    detailed.add_argument("url")

    nsfw = subparsers.add_parser("nsfw", help="Run an NSFW URL check.")
    nsfw.add_argument("url")

    chimera = subparsers.add_parser("chimera", help="Run Chimera AI classification.")
    chimera.add_argument("url")

    screenshot = subparsers.add_parser("screenshot", help="Download a screenshot by file name or screenshot URL.")
    screenshot.add_argument("file_name_or_url")
    screenshot.add_argument("--output", "-o", required=True, help="Output image path.")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.WARNING)

    try:
        with LinkShieldAI(
            api_key=args.api_key,
            base_url=args.base_url,
            timeout=args.timeout,
            max_retries=args.max_retries,
        ) as client:
            if args.command == "basic":
                result = client.basic_check(args.url)
            elif args.command == "detailed":
                result = client.detailed_check(args.url)
            elif args.command == "nsfw":
                result = client.nsfw_check(args.url)
            elif args.command == "chimera":
                result = client.chimera(args.url)
            elif args.command == "screenshot":
                client.get_screenshot(args.file_name_or_url, args.output)
                result = {"saved": args.output}
            else:
                parser.error(f"Unknown command: {args.command}")
                return 2
    except LinkShieldAIError as exc:
        print(json.dumps({"error": str(exc)}, indent=2), file=sys.stderr)
        return 1

    print(json.dumps(result_to_jsonable(result), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
