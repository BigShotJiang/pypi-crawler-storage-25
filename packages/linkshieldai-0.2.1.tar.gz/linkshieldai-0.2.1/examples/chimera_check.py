from linkshieldai import LinkShieldAI


client = LinkShieldAI(api_key="test-key")
result = client.chimera("https://google.com")

print("result:", result.result)
print("probability:", result.probability)
print("method:", result.detection_method)
