from linkshieldai import LinkShieldAI


client = LinkShieldAI()
result = client.detailed_check("https://example.com")

print("result:", result.result)
print("tag:", result.tag)
print("screenshot:", result.screenshot_url)

if result.screenshot_url:
    client.get_screenshot(result.screenshot_url, "screenshot.png")
    print("saved screenshot.png")
