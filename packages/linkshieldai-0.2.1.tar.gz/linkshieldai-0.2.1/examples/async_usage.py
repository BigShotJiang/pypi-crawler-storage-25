import asyncio

from linkshieldai import AsyncLinkShieldAI


async def main():
    async with AsyncLinkShieldAI() as client:
        result = await client.chimera("https://google.com")
        print(result.result, result.probability)


asyncio.run(main())
