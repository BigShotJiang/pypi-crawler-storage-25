from linkshieldai import LinkShieldAI


client = LinkShieldAI()
result = client.basic_check("https://example.com")

print(result.result)
print("malicious:", result.is_malicious)
