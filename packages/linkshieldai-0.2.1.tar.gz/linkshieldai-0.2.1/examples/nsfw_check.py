from linkshieldai import LinkShieldAI


client = LinkShieldAI(api_key="test-key")
result = client.nsfw_check("https://example.com")

print("nsfw:", result.is_nsfw)
