<div align="center">

# 🛡️ PIIFILL CLI `v0.1.8`

**Secure your data. Mask sensitive information. Stay fully offline.**

[![PyPI version](https://badge.fury.io/py/piifill-cli.svg)](https://badge.fury.io/py/piifill-cli)
[![Python versions](https://img.shields.io/pypi/pyversions/piifill-cli.svg)](https://pypi.org/project/piifill-cli/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/piifill-cli)](https://pepy.tech/project/piifill-cli)

*Built with precision by [Bhavin Sachaniya](https://bhavinsachaniya.in)*

[Overview](#-overview) • [Installation](#-quick-start) • [Basic Usage](#-usage-guide) • [Security Analytics](#-security--risk-analytics) • [Supported Formats](#-supported-file-formats)

</div>

---

## 📖 Overview

**PIIFILL** is a high-performance command-line utility designed to automatically detect and redact **P**ersonally **I**dentifiable **I**nformation (PII) from your documents, datasets, and images. 

Whether you are a developer sanitizing logs, a researcher preparing datasets, or a professional sharing sensitive files, PIIFILL provides a "security-first" workflow to ensure privacy compliance.

> [!IMPORTANT]
> **100% Offline Processing:** PIIFILL is built for privacy. All detection, masking, and OCR processing happen locally on your machine. Your data is never uploaded to any cloud service.

### 🛡️ What PII can it detect?
*   📱 **Personal Identifiers:** Phone numbers, Email addresses.
*   📄 **Government IDs:** Social Security Numbers (SSN), Aadhaar Card details.
*   💳 **Financial Data:** Credit/Debit card numbers.
*   🏠 **Location Info:** Physical addresses and ZIP codes.
*   ...and much more through intelligent pattern matching.

---

## 🚀 Quick Start

### Installation

Ensure you have Python 3.8+ installed. You can install PIIFILL directly via `pip`:

```bash
pip install piifill-cli==0.1.8
```

---

## 🛠️ Usage Guide

PIIFILL follows a simple two-phase workflow: **Scan** (To identify) and **Mask** (To protect).

### 1. Identify Privacy Risks (`scan`)
Use the `scan` command to audit your files. This is a read-only operation that provides a detailed report of potential PII without modifying your source files.

```bash
# Scan a single document
piifill scan sensitive_data.pdf

# Perform a deep search in a folder (recursive)
piifill scan ./private_docs/ --recursive
```

### 2. Protect Your Files (`mask`)
Once verified, use `mask` to generate sanitized versions of your files. By default, it creates an `out/` directory with the protected copies.

```bash
# Mask a single file
piifill mask user_records.csv

# Mask all files in a directory
piifill mask ./raw_logs/
```

---

## 📂 Working with Folders

Want to clean up an entire folder of data? PIIFILL makes it easy.

**Example: Mask every file in a folder**
```bash
piifill mask ./data_dump/
```
*   PIIFILL will scan every file in `./data_dump/`.
*   It will create a new folder called `./data_dump/out/`.
*   All your safe, cleaned-up files will be waiting for you inside the `out` folder!

**Example: Save the safe files somewhere specific**
```bash
piifill mask ./private_files/ -o ./safe_backup/
```
*   This takes everything from `private_files` and puts the safe versions in `safe_backup`.

---

## ⚙️ Command Reference

| Command | Description | Key Options |
| :--- | :--- | :--- |
| `scan` | Detects PII and generates a risk report. | `--recursive`, `--format` |
| `mask` | Redacts PII and creates safe file copies. | `-o` (output), `--mode` |
| `config` | Displays current PIIFILL configuration. | N/A |
| `version` | Displays version and environment info. | N/A |

### 🎭 Masking Modes
You can customize how PII is hidden using the `--mode` flag:

*   **`mask` (Default):** Replaces data with descriptive placeholders (e.g., `[REDACTED]`).
*   **`redact`:** Completely removes the sensitive data from the file.
*   **`tokenize`:** Replaces data with unique, trackable tokens (e.g., `<EMAIL_123>`).

---

## 📊 Security & Risk Analytics

PIIFILL doesn't just hide data—it helps you understand your privacy posture through integrated analytics:

*   **Security Grade:** A standardized rating (A to F) based on PII density.
*   **Risk Score (0-100):** A quantitative metric representing the severity of data exposure.
*   **Frequency Analysis:** A detailed breakdown of detected entities (e.g., "5 Credit Cards, 12 Emails found").

---

## 📂 Supported File Formats

PIIFILL supports a wide range of formats, including advanced OCR support for image-based documents.

| Category | Extensions |
| :--- | :--- |
| **Structured Data** | `.csv`, `.json`, `.sql`, `.xlsx` |
| **Documents** | `.txt`, `.pdf`, `.docx` |
| **Images (OCR)** | `.png`, `.jpg`, `.jpeg` |

> [!TIP]
> **Image Detection:** PIIFILL uses built-in OCR capabilities to detect and mask text hidden inside screenshots and scanned documents.

---

## 👤 Author

**Bhavin Sachaniya**
*   **Web:** [bhavinsachaniya.in](https://bhavinsachaniya.in)
*   **GitHub:** [@BHAVIN-S-V](https://github.com/BHAVIN-S-V)

---

## 📜 License

This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file for details.

