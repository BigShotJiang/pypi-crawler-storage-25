# mlx-server — Unified Launch Plan

Goal: make `mlx-server` behave like `ollama launch claude` — one command
in one terminal that boots the LiteLLM proxy, waits for it to be ready,
and spawns `claude` as a child process with the right environment, so
the user sees a single Claude Code session in the same terminal they
launched from. Ctrl-C tears everything down.

This plan replaces the "run server + open second terminal" UX from
`plan/plan-option-b.md`. The proxy architecture itself (LiteLLM +
`MLXProvider` custom handler) stays exactly the same.

## 1. Reference pattern — how Ollama does it

From reading `repo/ollama/`:

- **CLI subcommand**: `ollama launch claude [--model X]` — see
  `cmd/launch/claude.go` (`Claude.Run`). This is the user-facing
  entrypoint; there is no separate "start the server first" step the
  user has to remember.
- **Lifecycle** (`cmd/cmd.go` around `ensureServerRunning`):
  1. `checkServerHeartbeat()` — is `ollama serve` already listening?
  2. If not, spawn it as a background process and poll
     `client.Heartbeat()` every 500 ms until it responds.
  3. Only then call `LaunchIntegration()` which dispatches to the
     Claude runner.
- **Child process** (`cmd/launch/claude.go`):
  ```go
  cmd := exec.Command(claudePath, args...)
  cmd.Stdin  = os.Stdin
  cmd.Stdout = os.Stdout
  cmd.Stderr = os.Stderr
  cmd.Env = append(os.Environ(),
      "ANTHROPIC_BASE_URL="+host,
      "ANTHROPIC_API_KEY=",
      "ANTHROPIC_AUTH_TOKEN=ollama",
      "CLAUDE_CODE_ATTRIBUTION_HEADER=0",
      "ANTHROPIC_DEFAULT_OPUS_MODEL="+model,
      "ANTHROPIC_DEFAULT_SONNET_MODEL="+model,
      "ANTHROPIC_DEFAULT_HAIKU_MODEL="+model,
      "CLAUDE_CODE_SUBAGENT_MODEL="+model,
  )
  cmd.Run()  // blocks until Claude Code exits
  ```
  Stdio is wired straight through, so the child owns the TTY and
  Claude Code's UI draws normally. SIGINT on the terminal reaches the
  child first (it's in the foreground group), which lets Claude Code
  shut itself down cleanly; the parent then finishes its own cleanup.

The two things to take from this pattern verbatim:

1. **Stdio pass-through.** The proxy runs silently in the background;
   the terminal belongs to Claude Code.
2. **Env-var override of model slots.** `ANTHROPIC_DEFAULT_*_MODEL` and
   `CLAUDE_CODE_SUBAGENT_MODEL` are set so Claude Code sends one stable
   model name. Our wildcard route in LiteLLM already catches anything,
   but setting these makes logs clean and is "what ollama does."

## 2. New `mlx-server` CLI shape

Default invocation runs everything:

```
mlx-server [--model PATH_OR_REPO] [--host 127.0.0.1] [--port 8080]
           [--models-dir DIR] [--list] [--log-level LEVEL]
           [--serve-only] [--no-claude] [--claude-path PATH]
           [-- ...passed through to claude...]
```

Behavior:

- **No flags beyond model selection** → boot proxy, wait for ready,
  spawn `claude` with stdio piped through. This is the new default and
  the main UX.
- `--serve-only` → old behavior: run only the proxy in the foreground
  and block (for users who want to point a non-Claude-Code client at
  it, or run under systemd / launchd).
- `--no-claude` → alias of `--serve-only`, more discoverable name.
- `--claude-path PATH` → override which `claude` binary to launch
  (falls back to `shutil.which("claude")`).
- Everything after `--` is forwarded as argv to the `claude` child,
  mirroring `ollama launch claude -- --resume` etc.

Model resolution (unchanged from current CLI):

1. `--model` if given.
2. Else if local models exist under `~/.mlxserver/models` → TUI picker.
3. Else → print hint and exit.

## 3. Process architecture

Python equivalent of the Go pattern:

```
main thread                       proxy thread (daemon)
-----------                       ---------------------
parse args
resolve model                     (not started yet)
start uvicorn in thread  ───►     uvicorn.Server(config).run()
poll /health until ready
build env, spawn `claude`  ───►   child process owns the TTY
subprocess.wait()                 (serving requests)
on exit → server.should_exit=True ─► uvicorn shuts down
join proxy thread
return child's exit code
```

Key points:

- **Uvicorn in a daemon thread.** Use `uvicorn.Server(config)` (not
  `uvicorn.run`) so we get a handle with `should_exit` and `started`
  flags. Run `server.run()` in `threading.Thread(daemon=True)`. Drop
  uvicorn's log level to `warning` so its startup noise doesn't
  clobber Claude Code's UI.
- **Readiness probe.** After starting the thread, poll
  `http://host:port/health/readiness` (LiteLLM exposes this) up to
  ~30 s at 100 ms intervals. Fail fast with a clear error if the
  proxy never comes up — most likely cause is model-load failure
  inside `MLXProvider._ensure_loaded`, which we currently trigger
  lazily on first request. Fix: call `_ensure_loaded()` from the
  handler shim at import time so load errors surface during proxy
  startup, not on the first Claude Code request.
- **Child process.** `subprocess.Popen([claude, *extra_args],
  stdin=None, stdout=None, stderr=None, env=env)` — passing `None`
  inherits the parent's stdio, which is exactly what we want (child
  owns the TTY). Parent calls `proc.wait()` and blocks.
- **Env vars set on the child**:
  ```python
  env = {
      **os.environ,
      "ANTHROPIC_BASE_URL": f"http://{host}:{port}",
      "ANTHROPIC_API_KEY": "mlx-local",      # any non-empty
      "ANTHROPIC_AUTH_TOKEN": "mlx-local",
      "ANTHROPIC_DEFAULT_OPUS_MODEL": "mlx-local",
      "ANTHROPIC_DEFAULT_SONNET_MODEL": "mlx-local",
      "ANTHROPIC_DEFAULT_HAIKU_MODEL": "mlx-local",
      "CLAUDE_CODE_SUBAGENT_MODEL": "mlx-local",
      "CLAUDE_CODE_ATTRIBUTION_HEADER": "0",
  }
  ```
  `mlx-local` is our LiteLLM alias; combined with the existing
  wildcard route, this means both "Claude Code sends a stable name"
  and "any new Claude Code slot still works" are true.
- **Shutdown**:
  - Ctrl-C in the terminal hits the child first (foreground group).
    Claude Code catches it and exits. `proc.wait()` returns.
  - In the `finally` block, set `server.should_exit = True` and
    `thread.join(timeout=5)`. The daemon flag guarantees we can't
    hang the process even if uvicorn misbehaves on shutdown.
  - If the user instead Ctrl-C's twice or SIGTERMs the parent, we
    catch `KeyboardInterrupt` around `proc.wait()`, send SIGINT to
    the child, wait ≤5 s, SIGKILL if necessary, then shut the proxy
    down the same way.
- **Return code**: parent exits with `proc.returncode` so shell
  scripts that wrap `mlx-server` see the right status.

## 4. File-level changes

New module `src/mlxserver/launcher.py`:

```python
def launch_claude(model_path: str, host: str, port: int,
                  claude_path: str | None, extra_args: list[str]) -> int:
    ...
```

Owns: proxy thread setup, readiness probe, env construction,
subprocess spawn, signal handling, shutdown. Tiny — mostly glue.

`src/mlxserver/proxy.py`:

- Split `run()` into:
  - `build_server(model_path, host, port, log_level) -> uvicorn.Server`
    (configures LiteLLM, returns the server without calling `run()`)
  - `run(...)` — keeps current blocking behavior for `--serve-only`.
- `launcher.launch_claude` calls `build_server` and runs the returned
  server on a thread.

`src/mlxserver/handler.py` (shim written into the temp config dir):

- After constructing `MLXProvider(model_path)`, call
  `handler._ensure_loaded()` immediately so any load failure is raised
  during proxy startup, not on first request. This makes the
  readiness probe meaningful.

`src/mlxserver/cli.py`:

- Add `--serve-only` / `--no-claude`, `--claude-path`, and the
  trailing `--` passthrough.
- Default branch: call `launcher.launch_claude(...)`.
- `--serve-only` branch: call `proxy.run(...)` (current behavior).
- If `claude` can't be found on PATH and `--claude-path` wasn't given,
  print a clear error with install instructions and fall back to
  serve-only with a one-line hint.

`README.md`:

- Rewrite the "Point Claude Code at it" section to just show
  `mlx-server --model ...`. Move the manual `ANTHROPIC_BASE_URL` flow
  into an advanced "run as a standalone proxy" section keyed off
  `--serve-only`.

## 5. Edge cases

- **`claude` not installed.** Catch `FileNotFoundError` from
  `subprocess.Popen`, print a one-liner pointing at the Claude Code
  install docs, exit non-zero without starting the proxy.
- **Port already in use.** LiteLLM/uvicorn will raise during
  `Server.run()` on the thread. The readiness probe will time out; we
  surface the thread's exception (stored via a `captured_error`
  container the thread writes on failure) instead of a generic
  "proxy never came up".
- **Model load failure.** Because the handler shim now calls
  `_ensure_loaded()` at import time, LiteLLM's proxy startup raises
  before binding the port. The launcher sees the thread die, prints
  the traceback, exits.
- **Claude Code crash / non-zero exit.** Propagate the exit code. Do
  not restart automatically.
- **User runs `mlx-server --serve-only --model X` and `mlx-server
  --model X` in parallel.** The second one fails at bind time on
  8080. Error message already clear from uvicorn. Out of scope to
  reuse a running proxy — that's an ollama-daemon design and adds
  significant complexity; we keep one proxy per invocation.

## 6. Implementation order

1. Refactor `proxy.py` into `build_server` + `run`. Verify
   `--serve-only` (alias the current default) still passes the
   existing curl smoke tests.
2. Move eager model load into the handler shim. Smoke test proxy
   startup with a bogus model path — must fail fast with a clear
   traceback, not hang.
3. Add `launcher.py` with thread + readiness probe + subprocess
   spawn. Test with `echo 'print hello' | claude` style invocation
   first; confirm env vars reach the child and it talks to the
   proxy.
4. Wire `cli.py`: default path calls launcher, `--serve-only` calls
   the old entry, `--` passthrough forwards argv.
5. Shutdown test: start `mlx-server --model ...`, interact in
   Claude Code, Ctrl-C. Verify no orphan uvicorn processes
   (`lsof -i :8080` should be empty) and that the launcher exits
   with Claude Code's exit code.
6. README rewrite.

## 7. Validation checklist

- [ ] `mlx-server --model mlx-community/gemma-3-4b-it-4bit` launches
      Claude Code in the same terminal with no additional setup.
- [ ] Claude Code sees `ANTHROPIC_BASE_URL` pointing at our proxy and
      sends requests successfully (streaming + tool-less chat).
- [ ] Ctrl-C in Claude Code exits cleanly; `lsof -i :<port>` is empty
      afterwards.
- [ ] `mlx-server --serve-only --model ...` still runs the bare proxy
      (backwards compat for the "put it behind another client" use
      case).
- [ ] `mlx-server --model X -- --resume` forwards `--resume` to
      `claude`.
- [ ] Bogus `--model /does/not/exist` fails during startup with the
      MLX load traceback, not after Claude Code's first request.
- [ ] `mlx-server` with `claude` not on PATH prints a clear hint and
      exits non-zero instead of starting a silent proxy.

## 8. Out of scope

- Reusing a long-running background proxy across multiple launches
  (the ollama-daemon model). Every `mlx-server` invocation is still
  one process that owns its own LiteLLM + MLX model load.
- Restarting Claude Code on crash.
- Windows support. Unix signal/process model is assumed throughout.
