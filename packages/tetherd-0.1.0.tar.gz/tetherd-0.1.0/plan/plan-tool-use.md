# mlx-server — Tool-Use Plan (Gemma 4 native)

Goal: make Claude Code's tool calls (Write, Edit, Bash, Glob, Grep, …)
actually execute against our local Gemma 4 E2B backend. Today our
provider drops `optional_params["tools"]` on the floor and only emits
plain-text assistant content, so Claude Code never sees a `tool_use`
block and never runs the tool.

This plan is scoped to **Gemma 4** (the model we're running). A
different model would need a different format; we'll structure the code
so the per-model pieces are swappable but won't build generic
multi-model support in v1.

## 1. Research recap (what we have to work with)

**Ollama's approach** (from `repo/ollama/`):
- Tool schemas are passed *through* to the model's chat template — no
  hand-rolled prefix. `middleware/anthropic.go` → `api.ChatRequest.Tools`
  → the Jinja template injects them.
- Output parsing is handled by `tools/tools.go::Parser`, a stateful
  token-stream parser that finds a model-specific opening marker
  (detected via `parseTag` reading the template source), buffers until
  a complete tool call is formed, returns an `api.ToolCall`.
- Streaming: Ollama *does not* stream partial JSON tokens. It
  accumulates one complete tool call, then emits Anthropic SSE events
  (`content_block_start` with empty `tool_use`, a single
  `content_block_delta` with `input_json_delta` containing the full
  JSON arguments, `content_block_stop`). We should do the same — real
  streaming of partial JSON is a footgun we don't need.
- Server tools (`web_search`) are hardcoded in middleware; client
  tools pass through. We'll only handle client tools for v1.

**Gemma 4's native template** (confirmed by probing
`processor.tokenizer.chat_template`):
- **Declaration** (injected into the system turn when `tools=` is
  passed to `apply_chat_template`):
  ```
  <|tool>declaration:ToolName{parameters:{…}}<tool|>
  ```
- **Call** (what the assistant emits when it wants to invoke a tool):
  ```
  <|tool_call>call:ToolName{arg1:<|"|>value<|"|>,arg2:42}<tool_call|>
  ```
- **Response** (what we feed back after tool execution):
  ```
  <|tool_response>response:ToolName{…}<tool_response|>
  ```
- String values are quoted with a custom escape token `<|"|>` instead
  of `"`, turning arguments into a **pseudo-JSON DSL**, not real JSON.
  This is the main parsing complication.

**The key insight**: Gemma 4 ships with a Jinja template that already
knows the OpenAI-style `message['tool_calls']` /
`message['tool_responses']` schema and encodes it into its own
DSL. We **do not need to emit the DSL ourselves** — we feed structured
OpenAI-shaped messages to `apply_chat_template(tools=…)` and the
template produces the right text. We only need a DSL **parser** for
the output direction.

## 2. Architecture — where the new pieces live

Three discrete responsibilities, three files:

```
src/mlxserver/
├── provider.py           # already exists; wire in the new pieces
├── tools/
│   ├── __init__.py
│   ├── schemas.py        # Anthropic/OpenAI tool schema utilities
│   ├── gemma.py          # Gemma-4 DSL encoder + streaming parser
│   └── streaming.py      # Convert parsed tool calls → GenericStreamingChunk
```

Keeping tools under a subpackage means that when we add a second model
(Qwen, Llama, etc.) we add `tools/qwen.py` and dispatch in
`provider.py` by model family — no refactor of the provider.

## 3. Tool schema injection (easy path)

`provider._render_prompt` needs to accept a `tools` kwarg and forward
it to `apply_chat_template`. The only glue needed:

- LiteLLM passes tools in `optional_params["tools"]` as OpenAI format:
  ```json
  {"type": "function", "function": {"name": "Write", "description": "...", "parameters": {...}}}
  ```
- Gemma 4's template expects `tools=[{…}]` in the same shape it's
  baked to consume. Empirical test earlier today confirmed that
  passing LiteLLM's structure through works — the rendered prompt
  contained a `<|tool>declaration:Write{…}<tool|>` block for every
  tool.
- For the messages history, we also need to pass any prior
  assistant-with-tool-calls turns and user-with-tool-results turns in
  the shape the template expects. Claude Code's incoming messages
  already use Anthropic's `tool_use` / `tool_result` content blocks
  — we translate them once in `_normalize_messages`:
  - An assistant message whose content contains one or more
    `{type: "tool_use", id, name, input}` blocks → an OpenAI-style
    message with `tool_calls: [{id, type: "function", function:
    {name, arguments: json.dumps(input)}}]` plus any plain text from
    text blocks.
  - A user message whose content contains `{type: "tool_result",
    tool_use_id, content}` blocks → a **tool-response assistant
    message** with `tool_responses: [{name: ?, response: …}]`. Gemma's
    template uses `tool_responses` on assistant messages, not a
    separate `role: tool`; we'll need to pair the `tool_use_id` with
    the prior assistant turn's call to recover the tool name.

## 4. Tool call parsing (hard path)

**Parser file**: `tools/gemma.py::GemmaToolCallParser`.

State machine fed one text delta at a time:

```
IDLE --(<|tool_call>call:)--> INSIDE_NAME
INSIDE_NAME --({)--> INSIDE_ARGS  (remembers name)
INSIDE_ARGS --(balanced {} + <|"|> escapes)--> COMPLETE
COMPLETE --(<tool_call|>)--> IDLE (emits ToolCall)
```

While in `IDLE` the parser also forwards any plain text it sees as
regular assistant content deltas.

The DSL value grammar (minimal):

- `{…}` = object, key:value comma-separated
- `[…]` = array
- `<|"|>…<|"|>` = string literal (custom escape around the value)
- bare tokens = number, `true`, `false`, `null`, or bare identifier

Conversion to real JSON:
- Replace `<|"|>` → `"`
- Keys are bare identifiers → wrap them in quotes (`arg1:` → `"arg1":`)
- Everything else follows JSON

There is a genuine risk that Gemma 4 emits malformed DSL (it's a
small model). Handle by: if a candidate call fails to parse, fall
back to forwarding the raw text as assistant content and logging a
warning. Never crash the stream.

**Streaming contract**: the parser yields events, not strings:

```python
class ToolParserEvent:
    kind: Literal["text", "tool_call"]
    text: str | None
    tool_call: ParsedToolCall | None  # {id, name, input: dict}
```

`provider.streaming()` consumes these and emits
`GenericStreamingChunk` values:
- `kind == "text"` → existing text delta chunk
- `kind == "tool_call"` → a `tool_use` chunk. Following Ollama, we
  emit the whole tool call as one `input_json_delta`:
  ```python
  GenericStreamingChunk(
      text="",
      tool_use=ChatCompletionToolCallChunk(
          id=generated_id,
          type="function",
          function={"name": name, "arguments": json.dumps(input)},
          index=n,
      ),
      is_finished=False,
      finish_reason="",
      usage=None,
      index=n,
  )
  ```
  LiteLLM's Anthropic-format translator is responsible for turning
  that into `content_block_start` (type `tool_use`) +
  `content_block_delta` (`input_json_delta`) + `content_block_stop`.
  We do **not** try to spec-compliance those events ourselves —
  that's LiteLLM's job, and breaking it is what our wildcard + proxy
  layer is there to insulate us from.

**Non-streaming path**: `completion()` feeds the parser with the full
generated string in one shot. The same event stream collapses into:
- zero-or-more text segments concatenated into
  `choices[0].message.content`
- zero-or-more tool calls collected into
  `choices[0].message.tool_calls` (OpenAI shape, LiteLLM converts to
  Anthropic `tool_use` blocks).
- `finish_reason`: `"tool_calls"` if any tool calls were emitted,
  else `"stop"`.

## 5. Message-history translation

New function `tools/schemas.py::anthropic_to_gemma_messages(messages)`:

Input: Claude Code's messages as LiteLLM hands them to us (OpenAI
shape already, LiteLLM does the initial Anthropic→OpenAI mapping).

Output: a list of dicts that Gemma 4's template understands —
specifically:

- `{role: "system", content: str}` — plain text, flattened from content
  blocks the way we already do today.
- `{role: "user", content: str}` — same.
- `{role: "assistant", content: str, tool_calls: [...]}` — both fields
  optional; content is any assistant text, tool_calls is the OpenAI
  shape with `function.arguments` **as a JSON string** (the template
  does `tool_call['function']['arguments']` and re-encodes).
- `{role: "assistant", tool_responses: [{name, response}]}` — this is
  Gemma-specific. We inject it whenever the previous user message
  contained `tool_result` blocks. The `name` comes from the
  corresponding `tool_use_id` in the prior assistant turn.

Edge case: Claude Code sends `tool_result.content` as either a string
or a list of text blocks. Flatten to string. If the content is
structured (images, etc.) for v1 we stringify with `json.dumps` and
log a warning — proper multimodal tool results are out of scope until
we wire images through mlx-vlm.

## 6. Handling model quirks

- **Stop tokens**: `<tool_call|>` is emitted by the template as the
  call terminator. We need to make sure `mlx_vlm.stream_generate`
  doesn't stop early on it (it won't — only EOS / `<|end|>` stop by
  default), and that our parser recognizes it exactly.
- **Interleaved text and tool calls**: the template allows
  `assistant` messages to have both text and tool_calls. The parser
  must forward text in `IDLE` state and switch into tool-call mode
  mid-stream without losing the text already emitted.
- **Multiple tool calls in one turn**: supported by the template. The
  parser must handle sequential `<|tool_call>…<tool_call|>` blocks in
  one turn.
- **Partial garbage**: if the model emits `<|tool_call>call:Write{`
  and then drifts, the parser should time out at the end of stream
  and fall back to treating the partial block as literal text so the
  user at least sees what happened.

## 7. Implementation order

1. **Schema translation (cheapest, unblocks everything else).**
   - `tools/schemas.py::anthropic_to_gemma_messages` + unit tests for
     each block-shape combination.
   - Wire `_render_prompt` to pass `tools=optional_params["tools"]`
     through to `apply_chat_template`, and to use the translated
     messages.
   - Smoke test: issue a non-streaming chat completion with a single
     tool (`Write`) defined and observe, via `MLXSERVER_DEBUG=1`,
     that the rendered prompt contains a `<|tool>declaration:Write…`
     block. Do not try to parse tool calls yet.
2. **Non-streaming parser.**
   - `tools/gemma.py::parse_gemma_output(text) -> (plain_text,
     tool_calls)`.
   - Unit test with hand-crafted Gemma-DSL strings (incl. multiple
     calls, nested objects, escaped strings, partial/garbage).
   - Wire `provider.completion()` to run the parser and emit
     `tool_calls` on `model_response.choices[0].message`.
3. **Streaming parser.**
   - `tools/gemma.py::GemmaToolCallParser` state machine fed one
     delta at a time. Yields `ToolParserEvent`.
   - Unit test with each delta-split at every character boundary
     across a golden input (ensures it's resumable).
   - Wire `provider.streaming()` to consume events and emit
     `GenericStreamingChunk` text / tool_use chunks. Do not invent
     Anthropic SSE event names — let LiteLLM's translator do it.
4. **Live Claude Code round-trip.**
   - Run `mlx-server --model mlx-community/gemma-4-e2b-it-4bit`.
   - Ask it to write `main.py` with `print("hello")`.
   - Observe: Gemma emits `<|tool_call>call:Write{…}<tool_call|>` →
     our parser → `tool_use` block → Claude Code executes Write →
     tool_result comes back → we format it as `tool_responses` in
     the next request → Gemma sees the result and continues.
5. **Fallbacks and polish.**
   - Warn and forward-as-text when parsing fails.
   - `MLXSERVER_DEBUG=1` should dump both the raw model output and
     the parsed events side-by-side so we can diagnose misbehavior.
   - Update README's "Known limitations" to remove the tool-use
     caveat.

## 8. Validation checklist

- [ ] `MLXSERVER_DEBUG=1` dump shows a `<|tool>declaration:Write{…}`
      block in the rendered prompt when the incoming request has
      tools.
- [ ] Unit test: parser returns the correct `(text, tool_calls)`
      tuple for golden inputs, including multiple calls, escaped
      strings, and nested objects.
- [ ] Unit test: streaming parser produces the same final result
      regardless of how deltas are split.
- [ ] Non-streaming `/v1/messages` with tools returns a response
      containing a `tool_use` content block visible to a curl client.
- [ ] Streaming `/v1/messages` emits Anthropic-spec
      `content_block_start`/`_delta`/`_stop` events for the tool
      call (this is LiteLLM's job; we confirm by inspection).
- [ ] Claude Code writes `main.py` end-to-end and the file appears
      on disk.
- [ ] Follow-up turn: Claude Code reads the file back (Read tool)
      and continues the conversation with the tool result in
      context. The second-turn prompt rendering must include a
      `<|tool_response>response:Write{…}<tool_response|>` block.
- [ ] Bad DSL output from Gemma does not crash the stream — it
      degrades to plain text and logs a warning.

## 9. Out of scope (v1.1+)

- Non-Gemma models. The parser and encoder are Gemma-specific.
- Multimodal tool results (images, audio). Stringify for now.
- Server tools (`web_search_20250305`). Not used by Claude Code's
  core loop.
- Streaming partial JSON tokens for `input_json_delta`. Ollama doesn't
  do it; we don't either. One call = one delta.
- Tool-call retries / auto-recovery. If Gemma emits malformed DSL,
  the turn fails and the user can retry.

## 10. Known risks

- **Gemma 4 E2B is small (effective 2B params).** Even with a clean
  DSL encoder and parser, the model may frequently emit malformed
  tool calls or hallucinate tool names. This is a model capability
  issue, not a plumbing issue. Measure pass rate on a few concrete
  Claude Code tasks after wiring; if it's <50%, document that
  Gemma 4 E2B is too small for agentic work and recommend stepping
  up to a larger variant (Gemma 4 E4B when available, or a
  different model family). Do not over-engineer the parser to
  compensate for model weakness.
- **Template changes upstream.** If Gemma 4's tokenizer chat
  template changes across mlx-vlm releases, our parser's expected
  markers could drift. Pin the marker strings as module-level
  constants and fail loud with a clear error if we see generated
  text that doesn't match any known format.
- **LiteLLM's `tool_use` streaming path.** We're relying on
  LiteLLM to turn `GenericStreamingChunk.tool_use` into proper
  Anthropic SSE `content_block_start`/`_delta`/`_stop` events. If
  that path is broken for custom providers, we fall back to
  emitting the tool call only in the non-streaming path and disable
  streaming while tools are in play. Decide after step 3 of the
  implementation order.
