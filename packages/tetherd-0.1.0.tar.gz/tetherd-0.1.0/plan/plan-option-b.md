# mlx-server — Plan (Option B: LiteLLM custom provider + mlx_lm SDK)

A pip-installable CLI, `mlx-server`, that boots a **LiteLLM proxy** in
Anthropic-compatible mode, backed by a **custom LiteLLM provider** which
calls the `mlx_lm` Python SDK directly (no inner HTTP hop, no
`mlx_lm.server`). Claude Code points `ANTHROPIC_BASE_URL` at this proxy
and uses local Gemma-3-4B (or any MLX model) as its backend.

## 1. Why this architecture

- **Claude Code only speaks the Anthropic Messages API.** An
  OpenAI-shaped endpoint cannot be used directly; a translator is
  required (see `plan/plan.md` §Research).
- **LiteLLM already implements that translator** — it exposes
  `/v1/messages` as a first-class entry point and maps it onto whichever
  backend provider handles the model. We get streaming events,
  tool-use block encoding, and `count_tokens` for free.
- **LiteLLM's Custom Provider API** lets us plug in a Python class that
  loads an MLX model once and serves completions via `mlx_lm.stream_generate`.
  Model stays resident in the LiteLLM process — **zero localhost HTTP
  hops between LiteLLM and the model**, which was the original concern
  with wrapping `mlx_lm.server`.
- Net result: one process, one port, Anthropic wire format on the
  outside, `mlx_lm` SDK on the inside.

## 2. Request flow

```
Claude Code
    │  POST /v1/messages   (Anthropic format, streaming SSE)
    ▼
LiteLLM proxy  ──►  MLXProvider (our CustomLLM subclass)
                         │
                         ▼
                    mlx_lm.stream_generate(model, tokenizer, prompt, ...)
                         │
                         ▼
                    yields token deltas
                         │
                         ▼
                    wrapped into LiteLLM ModelResponse chunks
                         │
                         ▼
                    LiteLLM converts → Anthropic SSE events
                         │
                         ▼
                    back to Claude Code
```

Everything above the `mlx_lm` call is LiteLLM code. Everything below
`stream_generate` is upstream mlx-lm. Our code is the ~100-line bridge in
the middle plus the CLI around it.

## 3. Packaging (`pyproject.toml`)

```toml
[project]
name = "mlx-server"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = [
  "mlx-lm>=0.21",
  "litellm[proxy]>=1.60",   # includes the proxy server + custom provider hooks
  "rich>=13",               # TUI picker
]

[project.scripts]
mlx-server = "mlxserver.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/mlxserver"]
```

Install:

```
pip install -e .           # dev
pip install mlx-server     # end user (once published)
```

`pip` pulls `mlx-lm` and `litellm` transitively and places the
`mlx-server` console script on `PATH`. `repo/mlx-lm` stays as a
read-only reference; it is never installed.

## 4. Project layout

```
mlx-server/
├── repo/mlx-lm/                 # upstream, read-only reference
├── plan/                        # this directory
│   ├── plan.md                  # Option-A plan (wrap mlx_lm.server)
│   └── plan-option-b.md         # THIS FILE
├── pyproject.toml
├── README.md
└── src/mlxserver/
    ├── __init__.py
    ├── __main__.py              # `python -m mlxserver`
    ├── cli.py                   # argparse entry point (mlxserver.cli:main)
    ├── config.py                # paths, defaults, model resolution
    ├── models.py                # discover models in ~/.mlxserver/models
    ├── picker.py                # rich-based TUI (arrows + enter)
    ├── provider.py              # MLXProvider(CustomLLM) — the bridge
    └── proxy.py                 # builds LiteLLM config + launches proxy
```

## 5. The custom provider (`provider.py`)

This is the only non-trivial piece of new code.

```python
from litellm import CustomLLM
from litellm.types.utils import GenericStreamingChunk, ModelResponse
import mlx_lm

class MLXProvider(CustomLLM):
    def __init__(self, model_path: str):
        self.model, self.tokenizer = mlx_lm.load(model_path)

    # non-streaming
    def completion(self, model, messages, **kwargs) -> ModelResponse:
        prompt = self.tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False,
        )
        text = mlx_lm.generate(
            self.model, self.tokenizer, prompt,
            max_tokens=kwargs.get("max_tokens", 1024),
            temp=kwargs.get("temperature", 0.7),
        )
        return ModelResponse(...)  # fill choices[0].message.content = text

    # streaming
    def streaming(self, model, messages, **kwargs):
        prompt = self.tokenizer.apply_chat_template(
            messages, add_generation_prompt=True, tokenize=False,
        )
        for chunk in mlx_lm.stream_generate(
            self.model, self.tokenizer, prompt,
            max_tokens=kwargs.get("max_tokens", 1024),
        ):
            yield GenericStreamingChunk(
                text=chunk.text,
                is_finished=False,
                finish_reason=None,
                usage=None,
                index=0,
                tool_use=None,
            )
        yield GenericStreamingChunk(
            text="", is_finished=True, finish_reason="stop",
            usage=None, index=0, tool_use=None,
        )

    async def acompletion(self, *a, **kw):  # reuse sync path in executor
        ...
    async def astreaming(self, *a, **kw):
        ...
```

Notes:

- **Model is loaded once** in `__init__` and reused across every
  request — that's the whole point of the SDK path.
- **Chat template** comes from the tokenizer the model ships with
  (Gemma 3's template is bundled); we do not hand-roll role prefixes.
- **Sampling params** (`temperature`, `top_p`, `max_tokens`,
  `repetition_penalty`) are forwarded from LiteLLM kwargs to
  `mlx_lm.generate` / `stream_generate`. Unknown kwargs are ignored.
- **Tool use** is v1.5 — start without it, verify Claude Code still
  functions against a tool-less model, then wire tool-call parsing in
  a follow-up using Gemma's function-calling tokens. Track as a known
  gap in README.
- **Stop sequences**: pass through to `stream_generate` via its
  `stop` / EOS-token mechanism; map back to LiteLLM `finish_reason`.

## 6. Proxy bootstrap (`proxy.py`)

LiteLLM's custom provider is registered by a `model_list` entry whose
`litellm_provider` points at our class. Two ways to launch:

- **(a) Programmatic**: `from litellm.proxy.proxy_server import
  app; uvicorn.run(app, ...)` after monkey-patching `litellm.custom_provider_map`
  with our instance.
- **(b) Config file**: write a temporary `litellm_config.yaml` pointing
  at `mlxserver.provider:MLXProvider` and exec `litellm --config
  <path> --port <port>`.

Pick **(a)** — it keeps everything in one process, avoids a temp-file
dance, and lets us bind the provider instance (which holds the loaded
model) directly into LiteLLM's registry. Subprocess approach (b) is the
fallback if LiteLLM's internal API changes and programmatic startup
becomes unstable.

Responsibilities of `proxy.py`:

- Instantiate `MLXProvider(model_path)` — this triggers model load
  (progress printed to stderr).
- Register it via `litellm.custom_provider_map`.
- Build a minimal `model_list` so LiteLLM routes `model="mlx/<name>"`
  (or just `model="default"`) to our provider.
- Call `uvicorn.run(litellm.proxy.proxy_server.app, host=..., port=...)`.
- Print the banner: `mlx-server → http://host:port/v1 (anthropic-compat, model=...)`.

## 7. Model discovery + TUI (`models.py`, `picker.py`)

Unchanged from the Option-A plan:

- Scan `$HOME/.mlxserver/models/` for immediate subdirs containing
  `config.json`.
- `rich`-based picker with ↑/↓ or j/k, Enter to select, q/Esc to
  cancel. Fallback to numbered prompt when stdout is not a TTY.
- Default model when the dir is empty:
  `mlx-community/gemma-3-4b-it-4bit` (downloaded via HF cache on first use).

## 8. CLI (`cli.py`)

```
mlx-server [--model PATH_OR_REPO] [--host 127.0.0.1] [--port 8080]
           [--models-dir DIR] [--list] [--yes] [--log-level LEVEL]
```

Resolution order for the model:

1. `--model` if provided (local path or HF repo id).
2. Else if local models exist → launch picker.
3. Else → `DEFAULT_HF_REPO`, prompt unless `--yes`.

Then: `proxy.run(model=resolved, host=..., port=...)`.

## 9. Claude Code wiring (documented in README)

```
export ANTHROPIC_BASE_URL=http://127.0.0.1:8080
export ANTHROPIC_API_KEY=dummy       # LiteLLM requires a value; any string works
claude
```

Claude Code will POST `/v1/messages` to the LiteLLM proxy, which
dispatches to `MLXProvider`, which runs `mlx_lm` locally. **This exact
flow must be tested end-to-end before the plan is considered shipped**
— do not trust the architecture diagram alone.

## 10. Implementation order

1. Scaffold `pyproject.toml` + `src/mlxserver/` + `pip install -e .`
   and confirm the `mlx-server` entry point resolves.
2. `config.py` + `models.py` + `--list` path; unit-test with a fake
   models dir.
3. `provider.py` — non-streaming `completion` first. Smoke test by
   calling it directly from a Python REPL (no proxy yet) to verify
   `mlx_lm.load` + `generate` work on the chosen Gemma build.
4. `proxy.py` — programmatic LiteLLM startup, register provider, hit
   `/v1/messages` with `curl` in non-streaming mode.
5. Add `streaming` + `astreaming` to the provider; verify SSE events
   reach `curl -N`.
6. `picker.py` TUI; manual test with 0, 1, and 3 local models.
7. Wire `cli.py` end-to-end.
8. **Claude Code smoke test**: real `claude` session, a multi-turn
   conversation, at least one tool call attempt (expected to degrade
   gracefully since tool use is deferred).
9. README with install + Claude Code wiring + known limitations.

## 11. Validation checklist

- [ ] `pip install -e .` produces a working `mlx-server` console
      script on `PATH`; importing `mlxserver.provider` triggers no
      LiteLLM errors.
- [ ] `mlx-server --list` on an empty dir prints a helpful message.
- [ ] `mlx-server --model mlx-community/gemma-3-4b-it-4bit --yes`
      loads the model once (verify via a single "loading…" log line),
      serves `/v1/messages`, and answers a `curl` request.
- [ ] Streaming: `curl -N` sees incremental Anthropic SSE events
      (`message_start`, `content_block_delta`, `message_stop`).
- [ ] Claude Code with `ANTHROPIC_BASE_URL` pointed at the proxy
      completes a real multi-turn chat.
- [ ] Ctrl-C shuts down cleanly; no orphan uvicorn or MLX processes.
- [ ] Second request after the first does **not** reload the model
      (confirms in-process SDK reuse — the whole reason for Option B).

## 12. Known risks / open questions

- **LiteLLM custom provider maturity.** The `CustomLLM` interface is
  public but less battle-tested than LiteLLM's built-in providers.
  If Anthropic-format streaming translation misbehaves for our
  chunks, we may need to tweak `GenericStreamingChunk` shapes or
  fall back to Option A (own FastAPI `/v1/messages` server).
- **Tool use.** Deferred to v1.1. Claude Code relies on tool use
  heavily; without it, usefulness is limited to plain chat and
  code explanation. Prioritize after v1 ships.
- **Gemma 3 chat template.** Confirm `tokenizer.apply_chat_template`
  on `mlx-community/gemma-3-4b-it-4bit` produces correct turns for
  system + user + assistant roles before trusting the provider.
- **LiteLLM version pin.** Custom-provider internals have shifted
  between LiteLLM releases; pin a known-good minor version and only
  bump deliberately.

## 13. Out of scope (v1)

- Tool use / function calling (v1.1).
- Multi-model hot-swap in one process.
- Auth / TLS (bind `127.0.0.1` only).
- Non-MLX backends.
- Windows/Linux (Apple Silicon macOS only).
