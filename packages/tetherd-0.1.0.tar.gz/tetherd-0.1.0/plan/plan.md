# mlx-server — Plan

A pip-installable CLI that runs an OpenAI-compatible HTTP server (suitable for
use as a Claude Code custom model endpoint) backed by `mlx-lm`, defaulting to
Gemma-3-4B-IT on Apple Silicon. Users either pass `--model <path>` or pick a
model from `$HOME/.mlxserver/models/` via a cursor-driven TUI.

## 1. Background

- `repo/mlx-lm` already ships `mlx_lm.server`, an OpenAI-compatible
  `/v1/chat/completions` + `/v1/completions` HTTP server (see
  `repo/mlx-lm/mlx_lm/SERVER.md`). We do **not** re-implement inference or
  HTTP — we wrap it.
- Claude Code can talk to any OpenAI-compatible endpoint via
  `ANTHROPIC_BASE_URL` / custom provider settings, so exposing the mlx-lm
  server at `http://localhost:<port>/v1` is sufficient.
- Target model: `mlx-community/gemma-3-4b-it-4bit` (MLX-quantized Gemma 3 4B
  Instruct). The CLI should not hard-code this — it should be the default
  when no `--model` and no local models are found.

## 2. Packaging (`pyproject.toml`)

This is the single source of truth for install, dependencies, and the
`mlx-server` entry point. No manual dep installs, no `pip install -e
./repo/mlx-lm` — everything comes through the project metadata.

```toml
[project]
name = "mlx-server"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = [
  "mlx-lm>=0.21",   # pin to a version known to expose mlx_lm.server.main
  "rich>=13",       # used by the TUI picker
]

[project.scripts]
mlx-server = "mlxserver.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/mlxserver"]
```

Install (dev):

```
pip install -e .
```

Install (end user, once published):

```
pip install mlx-server
```

Either way, `pip` pulls `mlx-lm` from PyPI and puts the `mlx-server`
console script on `PATH`. `repo/mlx-lm` stays checked out as a
**reference** for reading source only — it is not an install target. If a
local patched build is ever needed, point the `mlx-lm` dependency at it
via pip's `-e` override rather than editing this plan.

## 3. Project layout

```
mlx-server/
├── repo/mlx-lm/                 # upstream, read-only reference
├── plan/plan.md                 # this file
├── pyproject.toml               # see §2
├── README.md
└── src/mlxserver/
    ├── __init__.py
    ├── __main__.py              # `python -m mlxserver`
    ├── cli.py                   # argparse entry point (mlxserver.cli:main)
    ├── models.py                # discover models in ~/.mlxserver/models
    ├── picker.py                # TUI (arrow keys + enter)
    ├── server.py                # thin wrapper around mlx_lm.server
    └── config.py                # paths, defaults
```

## 4. Model discovery (`models.py`)

- Root dir: `$HOME/.mlxserver/models/` (create on first run).
- A "model" is any immediate subdirectory that contains a `config.json`
  (mlx-lm's on-disk format after `mlx_lm.convert` or an HF snapshot). Ignore
  everything else.
- Expose:
  - `models_root() -> Path`
  - `list_local_models() -> list[ModelEntry]` where `ModelEntry` has
    `name` (dir name), `path` (absolute), `size_bytes`, `quant` (parsed
    from `config.json` `quantization` field if present).
- Default model constant: `DEFAULT_HF_REPO = "mlx-community/gemma-3-4b-it-4bit"`.

## 5. TUI picker (`picker.py`)

- Implemented with `rich` + raw-mode stdin reads (no extra deps). Fallback
  to numbered `input()` prompt if stdout is not a TTY.
- Keys: ↑/↓ or j/k to move, Enter to select, q/Esc to cancel.
- Renders `name`, quant tag, and human-readable size per row; highlights
  the current row.
- Returns the selected `ModelEntry` or `None`.
- If `list_local_models()` is empty, print a message explaining the
  default model will be downloaded from HF and ask for confirmation
  (unless `--yes`).

## 6. CLI (`cli.py`)

Flags:

| flag | purpose |
|---|---|
| `--model PATH_OR_REPO` | explicit model; skips picker |
| `--host` (default `127.0.0.1`) | bind host |
| `--port` (default `8080`) | bind port |
| `--models-dir` | override `~/.mlxserver/models` |
| `--list` | list local models and exit |
| `--yes` | non-interactive; pick first local model or default |
| `--log-level` | forwarded to mlx-lm |

Resolution order for the model:

1. `--model` if provided.
2. Else if local models exist → launch picker.
3. Else → `DEFAULT_HF_REPO` (prompt unless `--yes`).

Then call `server.run(model, host, port, extra_args)`.

## 7. Server wrapper (`server.py`)

Two viable strategies, pick (a):

- **(a) In-process**: import `mlx_lm.server` and call its `main()` after
  injecting `sys.argv = ["mlx_lm.server", "--model", model, "--host", host,
  "--port", str(port), ...]`. Pros: single process, clean Ctrl-C, no
  subprocess plumbing. Cons: coupled to mlx-lm's argv interface — accept
  this and pin `mlx-lm` in `pyproject.toml` so an upstream rename breaks
  install resolution loudly instead of silently at runtime.
- **(b) Subprocess**: `subprocess.run([sys.executable, "-m",
  "mlx_lm.server", ...])`. Use only if (a) proves to leak state between
  restarts.

Wrapper responsibilities:

- Print a one-line banner: `mlx-server → http://host:port/v1  (model=...)`.
- Translate SIGINT to a clean shutdown.
- On startup, verify the model path exists OR looks like an HF repo id; if
  neither, error before handing off to mlx-lm.

## 8. Claude Code integration notes (documented in README)

- mlx-lm's server exposes `/v1/chat/completions`, which Claude Code's
  OpenAI-compatible provider path can target. Document the exact env vars
  / settings snippet once verified empirically — do NOT guess them in the
  plan. Verification step goes in §10.

## 9. Implementation order

1. Scaffold `pyproject.toml` + `src/mlxserver/`, then `pip install -e .`
   to confirm the entry point resolves and pulls in `mlx-lm`.
2. `config.py` + `models.py` + `--list` path; unit-test with a fake
   models dir.
3. `server.py` in-process wrapper; smoke test with `--model
   mlx-community/gemma-3-4b-it-4bit` and a `curl` chat completion.
4. `picker.py` TUI; manual test with 0, 1, and 3 local models.
5. Wire `cli.py` end-to-end; add `--yes`, `--list`, error messages.
6. README with install + Claude Code wiring instructions.

## 10. Validation checklist

- [ ] `pip install -e .` produces a working `mlx-server` console script
      on `PATH` with `mlx-lm` pulled in automatically.
- [ ] `mlx-server --list` on an empty dir prints a helpful message.
- [ ] `mlx-server` with ≥1 local model shows the TUI and launches the
      selected one.
- [ ] `mlx-server --model mlx-community/gemma-3-4b-it-4bit --yes` starts,
      downloads if needed, answers a `curl` chat completion.
- [ ] Point Claude Code at `http://127.0.0.1:8080/v1` and confirm a real
      turn round-trips. (Must be tested in-browser/CLI, not just assumed.)
- [ ] Ctrl-C shuts the server down cleanly with no orphan processes.

## 11. Out of scope (v1)

- Multi-model hot-swap in a single process.
- Auth / TLS (mlx-lm's server is localhost-only by default — keep it that
  way).
- Model downloading UI beyond what `huggingface_hub` already does.
- Windows/Linux support — Apple Silicon + macOS only.
