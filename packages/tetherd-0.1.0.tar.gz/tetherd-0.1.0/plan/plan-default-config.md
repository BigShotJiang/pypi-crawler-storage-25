# Config Directory + Layered Overrides

## Context

Today `~/.mlxserver/config.toml` is a single optional file. Two gaps:

1. **No default context cap**. `max_context = None` means "no limit",
   which is the wrong posture on a memory-bound local machine. We
   want a sensible 64k default baked into the Python code.
2. **Flat override model**. There's no organized way to keep one
   "baseline" config plus per-machine or per-project tweaks. The
   user would have to hand-maintain a single monolithic file.

Fix: move to a **`conf.d`-style directory** at
`~/.mlxserver/config/` with a guaranteed root file plus any number
of drop-in overlays, auto-merged in deterministic order.

## Layout

```
~/.mlxserver/
  config/
    config.toml         # always root, auto-created on first run
    10-m4pro.toml       # optional drop-in (memory caps, etc.)
    20-work.toml        # optional drop-in (project-specific)
    ...
```

- **`config.toml`** is the guaranteed first file. If it doesn't
  exist on startup, mlx-server writes a commented template with the
  factory defaults and prints a one-line notice. Never auto-
  overwritten after that.
- **Any other `*.toml`** in the directory is a drop-in overlay,
  merged on top in **alphabetical order**. The `NN-name.toml`
  numeric-prefix convention (mirroring systemd drop-ins and
  `/etc/*.d`) is the recommended way to control ordering but isn't
  enforced — any `.toml` filename works.
- **Non-`.toml` files, dotfiles, and subdirectories are ignored.**
  No recursion, no globbing surprises.

## Merge order (highest → lowest precedence)

```
CLI args
  > ~/.mlxserver/config/zz-last.toml                 (alphabetical tail)
    > …                                              (alphabetical middle)
      > ~/.mlxserver/config/10-m4pro.toml            (alphabetical head)
        > ~/.mlxserver/config/config.toml            (root, always first)
          > built-in dataclass defaults
```

There is **no `--config` flag**. For per-invocation tweaks, use the
dedicated CLI flag for the field you want to change (every
configurable option has one); for persistent tweaks, drop a new
`.toml` file into the directory. That's the whole story.

Each layer contributes only the fields it sets; unset keys fall
through. Unknown keys are silently ignored (same as today —
forward-compat over typo-friendliness).

## Files to modify

### `src/mlxserver/config.py` (core work)

1. **Default**: `DEFAULT_MAX_CONTEXT = 65536`.

2. **Constants**:
   ```python
   CONFIG_DIR = Path.home() / ".mlxserver" / "config"
   ROOT_CONFIG_NAME = "config.toml"
   ```

3. **Template constant** — TOML text, heavily commented, written on
   first run. Every field appears commented-out except
   `max_context`, which is the one default we actively care about:
   ```toml
   # mlx-server config — auto-generated on first run.
   # Edit freely; this file will not be overwritten. To add
   # per-machine or per-project overlays, drop more .toml files
   # into this directory (e.g. 10-m4pro.toml). Files are merged
   # alphabetically on top of this one.

   [server]
   # host = "127.0.0.1"
   # port = 8080

   [model]
   # Bare name (resolved against ~/.mlxserver/models/), absolute
   # path, or an HF repo id. Leave unset to get the TUI picker.
   # default = "gemma-4-e2b-it-4bit"

   # Hard MLX memory ceiling. mx.set_memory_limit raises on
   # overflow instead of swapping to disk. Examples: "18GB",
   # "20GiB", "500MB". Unset on machines with ample RAM.
   # memory_cap = "18GiB"

   # Max rendered-prompt size in tokens. When exceeded, oldest
   # conversation turns are dropped until the rendered prompt
   # fits. System messages are preserved.
   max_context = 65536

   [launch]
   # claude_path = "/usr/local/bin/claude"
   # log_level = "warning"
   ```

4. **`ensure_default_config(root_path: Path) -> bool`** — writes the
   template if the file is missing; returns True on creation (so
   cli.main can print a one-line "wrote default config …" notice).
   Creates the parent directory if necessary.

5. **`_read_toml_into(cfg: Config, path: Path) -> Config`** —
   private helper. Reads one TOML file and returns a new Config
   with any set fields overridden. Implemented once, reused for
   every layer.

6. **`discover_config_files(root_dir: Path) -> list[Path]`** —
   returns `[config.toml, *sorted(other .toml files)]`, all absolute
   paths. Filters out dotfiles and subdirectories. Exposed as a
   top-level helper so the CLI `--list` equivalent (future) can
   reuse it.

7. **`load_config() -> Config`** — the public entrypoint, no
   parameters:
   ```python
   def load_config() -> Config:
       ensure_default_config(CONFIG_DIR / ROOT_CONFIG_NAME)
       cfg = Config()  # dataclass defaults
       for p in discover_config_files(CONFIG_DIR):
           cfg = _read_toml_into(cfg, p)
       return cfg
   ```

### `src/mlxserver/cli.py` (thin)

1. **Remove** the existing `--config` flag. It was never shipped,
   no migration needed.

2. Every configurable field already has a CLI flag (`--model`,
   `--host`, `--port`, `--memory-cap`, `--max-context`,
   `--claude-path`, `--log-level`, `--models-dir`). Nothing new to
   add there.

3. `main()` calls `load_config()` (no args), then overlays CLI
   flags via `cfg.merge_cli(...)` as it does today.

4. Capture `ensure_default_config`'s creation flag (return it from
   `load_config` as `(Config, bool)`) and print a one-time
   `[mlx-server] wrote default config to <path>` before the
   `listening` banner on first run.

### `README.md`

Update "Config file" → "Config directory". Show:

- The layout with an example drop-in (`10-m4pro.toml`).
- The alphabetical merge rule.
- That `config.toml` is auto-generated and never overwritten.
- That every field is also available as a CLI flag for one-off
  overrides — point at `mlx-server --help`.

## Tests

New file `tests/test_config.py` — two small tests that pin the
contract so a future refactor can't silently regress it.

1. **First-run creation**: point `CONFIG_DIR` at a tmp path, call
   `load_config()`, assert the root file was written and the
   returned `Config.max_context == 65536`. Call again; assert
   mtime unchanged.

2. **Directory merge order**: write a root `config.toml` with
   `port = 9000` and `max_context = 30000`, plus two drop-ins:
   - `10-early.toml`: `port = 9001, memory_cap = "8GB"`
   - `20-late.toml`: `port = 9002`
   Load and assert `port == 9002` (alphabetical tail wins),
   `memory_cap == 8GB` (only set in early), `max_context == 30000`
   (only set in root).

## Validation

- [ ] Fresh run, no existing files: `~/.mlxserver/config/config.toml`
      is created, banner prints path, server starts with 64k
      context cap.
- [ ] Second run: no banner, file unchanged.
- [ ] Drop `10-local.toml` with `max_context = 20000` — next run
      uses 20000, not 65536.
- [ ] Add `20-override.toml` with `max_context = 10000` —
      alphabetical tail wins, result is 10000.
- [ ] `--max-context 100` on CLI — wins over every file in the
      directory.
- [ ] `pytest tests/` all green.

## Out of scope

- Recursive directory merge. Non-recursive is enough and easier to
  reason about.
- Anti-features: "remove key" markers, conditional include, TOML
  imports. If needed later, `--config` can cover per-invocation
  cases; more organized needs get their own plan.
- A `mlx-server config` CLI subcommand to print the resolved
  merged config. Cheap to add once we have a second use case for
  it (debug output would be the obvious driver), but not today.
- XDG-spec paths (`$XDG_CONFIG_HOME`). Users who care can symlink
  `~/.mlxserver/config` to wherever they want.

## Risks

- **Drop-in ordering confusion.** Users who don't know the
  alphabetical rule may be surprised that `production.toml` loses
  to `zzz-test.toml`. Mitigation: document the `NN-name.toml`
  convention in the README and in the generated template comment.
- **Dead drop-ins**. Easy to forget a half-done `10-experimental
  .toml` and wonder why settings don't stick later. Mitigation: on
  any merge where a drop-in set a value that was later overridden,
  skip — users discover this by editing files, which is fine.
