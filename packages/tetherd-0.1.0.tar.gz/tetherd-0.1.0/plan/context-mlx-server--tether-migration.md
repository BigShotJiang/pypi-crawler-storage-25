# Context Handoff: mlx-server → tether

Read this first if you're picking up this project in a fresh Claude
Code session after the directory rename. It's a condensed snapshot of
where the project is, what's done, what's pending, and how to get
back to a working state.

---

## TL;DR

- **Project is called `tether`.** It's a local Anthropic-compatible
  HTTP proxy that serves `mlx-vlm`-backed Gemma 4 (and later, other
  HF-compatible local models) to Claude Code via `ANTHROPIC_BASE_URL`.
- **On disk**, the working copy was at `~/project/mlx-server/` during
  development and may now be at `~/project/tether/` if the directory
  rename was executed. Either works — the code, git history, and
  Python package are all named `tether`; only the parent folder's
  name varies.
- **Two commits in git**: `eca590a` initial import, `9f6e903` rename.
- **Core features done**: proxy+LiteLLM+custom provider, unified
  launch (`ollama launch claude` style), Gemma 4 native tool-use
  (DSL + real-JSON body), prompt caching (~30× speedup on turn 2+),
  memory cap (`mx.set_memory_limit`), context cap (history
  truncation), conf.d-style `~/.tether/config/` with 64k default.
- **Open work**: investigating a "Invalid tool parameters" error
  that sometimes fires on multi-turn tool flows. A plan already
  exists at `plan/plan-invalid-tool-parameters.md` — start there.
  Phase 1 of that plan (capture a raw model output) is the next
  concrete action.

---

## What the project is, in one diagram

```
mlx-server       ➜  renamed to  ➜       tether
  (old)                                    (now)

Claude Code
   │  POST /v1/messages (Anthropic wire format, streaming SSE)
   ▼
LiteLLM proxy  (~/.tether/config/*.toml merged alphabetically)
   │      owns: routing, wildcard model-name → single backend,
   │            streaming event translation
   ▼
MLXProvider(CustomLLM)   ←  src/tether/provider.py
   │      owns: chat-template rendering, prompt-cache reuse,
   │            tool-call DSL parsing, memory-cap enforcement,
   │            max-context truncation
   ▼
mlx_vlm.load / stream_generate / generate   ←  Gemma 4 via mlx-vlm
```

All in one Python process. One `_MLX_LOCK` serializes every call
into mlx-vlm because MLX/Metal aborts on concurrent graph execution.
A single shared `PromptCacheState` rides on top, so 99% of tokens
are reused between turns in a Claude Code session.

---

## Module map — where to look for what

| Path | What's in it |
|---|---|
| `src/tether/cli.py` | argparse entrypoint, layered config merge, `--` passthrough to `claude`, `_resolve_model_name` (bare/path/repo) |
| `src/tether/config.py` | `Config` dataclass, TOML loader, `ensure_default_config`, `discover_config_files` (alphabetical conf.d), `_parse_memory_cap` ("18GiB" → bytes), `_DEFAULT_CONFIG_TEMPLATE` |
| `src/tether/launcher.py` | unified launch: uvicorn on daemon thread + `subprocess.Popen(claude, env=…)` with full env-var injection |
| `src/tether/proxy.py` | LiteLLM wiring: temp YAML config + `mlx_handler.py` shim, wildcard `model_name: "*"`, `_silence_litellm_noise` (banner + feedback box + CRITICAL log), memory/context caps plumbed via env vars |
| `src/tether/handler.py` | 5-line shim imported by LiteLLM's config loader; instantiates `MLXProvider` and eager-loads the model so startup failures surface on the readiness probe |
| `src/tether/provider.py` | `MLXProvider(CustomLLM)` — the whole ML/tool-use side: `_ensure_loaded` (memory cap + lazy load), `_render_prompt` (chat template + tools + context truncation + prompt-cache diag), `completion`/`streaming`/`acompletion`/`astreaming`, `_make_tool_use_chunks` (two-chunk tool streaming pattern so LiteLLM fans them into `content_block_start` + `input_json_delta` + `content_block_stop`) |
| `src/tether/tools/schemas.py` | `anthropic_to_gemma_messages` — folds LiteLLM's OpenAI-shape messages (with `role: tool` results) into Gemma 4's expected `tool_calls`/`tool_responses` structure; `openai_tools_for_template` normalizes the tools array |
| `src/tether/tools/gemma.py` | Gemma 4 tool-call parser — `parse_gemma_output` (non-streaming) and `GemmaToolCallParser` (resumable state machine fed one streaming delta at a time). Supports BOTH Gemma's native DSL (`<|tool_call>call:Name{key:<\|"\|>val<\|"\|>}<tool_call\|>`) and real JSON in the `{…}` body (model falls back to JSON on deeply nested schemas like `AskUserQuestion`) |
| `src/tether/picker.py` | rich-based TUI picker, `auto_refresh=False` + manual `live.update(..., refresh=True)` to avoid the "header scroll forever" bug |
| `src/tether/models.py` | `list_local_models` scans `~/.tether/models/*/config.json` |
| `tests/test_config.py` | 4 tests pinning first-run creation, idempotency, alphabetical merge order, unknown-key tolerance |
| `tests/test_gemma_parser.py` | 18 tests including streaming resumability at every delta split size and the real-JSON fallback path |

---

## Past plans (historical, in order)

1. `plan/plan.md` — original "wrap mlx_lm.server" (abandoned)
2. `plan/plan-option-b.md` — chosen: LiteLLM custom provider + mlx-lm SDK (later swapped to mlx-vlm when Gemma 4 turned out to need the VLM loader)
3. `plan/plan-unified-launch.md` — `ollama launch claude` pattern
4. `plan/plan-tool-use.md` — Gemma 4 native tool-call wiring (executed)
5. `plan/plan-default-config.md` — `~/.tether/config/` conf.d-style directory with 64k default (executed)
6. `plan/plan-invalid-tool-parameters.md` — **PAUSED.** Phase 1 (capture the raw failing output) has not been run yet; see "Open work" below.

Plan files are historical records. They reference the old
`src/mlxserver/*` paths — **do not rewrite them**; translate paths
to `src/tether/*` mentally when reading.

---

## Environment (what you need to get running)

On-disk layout after rename (or before, if you skipped the mv):

```
~/project/tether/                (or ~/project/mlx-server/)
├── .venv/                        # Python 3.12 venv; rebuild after any dir rename
├── src/tether/                   # Python package
├── tests/                        # 22 tests, all green on last run
├── plan/                         # this file + historical plans
├── pyproject.toml
├── README.md
└── repo/                         # git-ignored read-only reference checkouts
    ├── mlx-lm/                   # source, not installed
    └── ollama/                   # source, not installed
```

External state (outside the repo):

```
~/.tether/
├── config/
│   ├── config.toml               # auto-generated on first run, 64k default
│   └── *.toml                    # optional drop-ins, alphabetical merge
└── models/
    └── gemma-4-e2b-it-4bit/      # 4-bit MoE weights, user-placed
```

### If the project directory was renamed

Editable installs bake absolute paths into `.venv/lib/.../tether.egg-link`
and `bin/*` shebangs. Rebuild the venv:

```bash
cd ~/project/tether
rm -rf .venv .pytest_cache
python3.12 -m venv .venv
.venv/bin/pip install -e .
.venv/bin/python -m pytest tests/ -q       # should show 22 passed
```

### Run it

```bash
# Launch the proxy and open Claude Code in the same terminal:
.venv/bin/tether --model gemma-4-e2b-it-4bit

# Proxy only (no Claude Code child):
.venv/bin/tether --serve-only --model gemma-4-e2b-it-4bit --port 8765

# Debug logging (dumps messages, rendered prompt, raw output,
# prompt-cache hit ratios to stderr):
TETHER_DEBUG=1 .venv/bin/tether --model gemma-4-e2b-it-4bit 2> /tmp/tether.log
```

### Config precedence

```
CLI args
  > ~/.tether/config/zz-late.toml     (alphabetical tail)
    > …
      > ~/.tether/config/10-early.toml (alphabetical head)
        > ~/.tether/config/config.toml (auto-created root)
          > dataclass defaults (host=127.0.0.1, port=8080,
                                 max_context=65536)
```

---

## Known working model

`mlx-community/gemma-4-e2b-it-4bit` — Gemma 4 E2B (effective 2B
params), loaded via `mlx_vlm`. Handles the `v1/messages` flow,
produces real tool calls, 64k context window.

**Production target** (not yet tested): `gemma-4-26b-a4b-it-4bit`
(26B MoE, ~4B active). On a 24 GB M4 Pro this needs `memory_cap =
"18GiB"` and `max_context = 30000` to avoid swap. Earlier run
crashed under memory pressure — caps are the remedy.

---

## Open work (the reason this handoff exists)

### Primary: "Invalid tool parameters" on multi-turn flows

**Symptom** (from the user's last working session): Write a file
works. Update the same file a second time works. A third turn that
triggers a more complex tool (e.g. `AskUserQuestion`) sometimes
fails with Claude Code showing **"Invalid tool parameters"**.

**Not yet known**:
- Which layer is actually wrong (parser, model output, or the
  round-trip translator that folds prior-turn tool_result messages
  back into Gemma's `tool_responses` shape).
- Whether it's reproducible or intermittent.
- Whether it's specific to `AskUserQuestion` or generalizes to
  every complex-schema tool.

**Next concrete action**: Phase 1 of
`plan/plan-invalid-tool-parameters.md` — boot with
`TETHER_DEBUG=1`, reproduce the three-step flow, capture the raw
model output for the failing request, and paste it into the session.
The plan has three "buckets" (A: parser bug, B: model emits
schema-invalid call, C: round-trip translator drops prior-turn
history) and the raw output tells us which bucket to fix.

**Do not start coding** until Phase 1 produces concrete evidence.
The plan explicitly flags that any fix written without the capture
is guesswork.

### Secondary: validate the production model

Once tool use is stable on E2B, load `gemma-4-26b-a4b-it-4bit`
locally with the recommended caps and rerun the same three-step
flow. Measure: does the bigger model make the "Invalid tool
parameters" problem go away on its own? (Reasonable hypothesis;
small models often emit malformed calls under schema pressure.)

### Tertiary: usage-token counts

Every response currently reports `usage.input_tokens = 0, output_
tokens = 0`. Not blocking — Claude Code doesn't need them — but
it's a loose end called out in the README limitations.

---

## Things *not* to do

- **Don't rewrite plan files** to match the new name. They're
  history.
- **Don't revert the parser's JSON-body fallback**
  (`tools/gemma.py::_parse_call_body`) — it exists because the
  user observed Gemma 4 emitting real JSON inside `{…}` on one
  specific tool, and the fallback is strictly safer than DSL-only.
- **Don't remove `HF_HUB_DISABLE_PROGRESS_BARS` wait, that's
  already removed**. Current `proxy._prepare` only sets
  `TQDM_DISABLE=1`. The HF version was removed because local-path
  loading never touches HF anyway. If you see a user pasting
  `Fetching N files` / `Download complete`, they're passing an HF
  repo id instead of a bare name — point them at the bare-name
  resolution.
- **Don't delete the `_silence_litellm_noise` monkey-patches**
  (`generate_feedback_box`, `banner.show_banner`, logger level
  raise). They're ugly but required — LiteLLM prints a lot of
  unskippable noise otherwise. Escape hatch is `LITELLM_VERBOSE=1`.
- **Don't add a `--config` flag**. We removed it deliberately —
  overrides go through either the CLI flags (`--max-context`,
  `--memory-cap`, etc.) or a new `.toml` in `~/.tether/config/`.
  Two mechanisms, not three.

---

## Verification after handoff

Run this to confirm you're in a good state:

```bash
cd ~/project/tether          # or ~/project/mlx-server if unrenamed
.venv/bin/python -m pytest tests/ -q
# Expect: 22 passed

.venv/bin/tether --help | head -5
# Expect: usage: tether [...]

git log --oneline
# Expect:
#   9f6e903 Rename project: mlx-server → tether
#   eca590a Initial commit: mlx-server — local Anthropic-compatible proxy for Claude Code
```

If any of those fail, you're not in a good state — start by
rebuilding the venv per the "Environment" section.

---

## Picking up the conversation

Short version of where we were when the rename happened:

1. Everything built through "prompt caching + config directory +
   64k default + memory cap + context cap" — all merged.
2. Project renamed from `mlx-server` to `tether`, committed.
3. User asked how to rename the on-disk directory without losing
   the Claude Code session. This file was written so they could
   answer "move everything, then read the handoff in the fresh
   session."
4. The "Invalid tool parameters" investigation is the next real
   work item. It's been waiting since before the rename —
   `plan/plan-invalid-tool-parameters.md` has been written but
   Phase 1 (capture) has not been executed yet.

Start by asking the user whether they want to run Phase 1 of the
invalid-tool-parameters plan, or whether they want to do something
else first (e.g. load the 26B model and see if the bigger brain
fixes it for free).
