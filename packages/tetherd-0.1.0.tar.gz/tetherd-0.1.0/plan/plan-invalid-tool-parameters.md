# Fix: "Invalid tool parameters"

## Context

After prompt-caching and bare-name resolution landed, tool calls work
for simple single-turn prompts ("write hello world to main.py") but
Claude Code shows **"Invalid tool parameters"** on at least one
follow-up turn when running the same multi-step flow from before
(Write → Update main.py → another Update → picker).

That error comes from Claude Code's own schema validator, not from
our proxy or LiteLLM. It fires when the `input` field of a `tool_use`
content block fails to match the tool's declared `input_schema`. The
proxy is correctly delivering a `tool_use` block — otherwise Claude
Code would show a plain-text message or a different error. So the
tool call is reaching Claude Code; the *shape* of its arguments is
wrong.

There are three layers that can mangle that shape:

1. **The model** — Gemma 4 emits the call in either DSL or real JSON;
   the arguments it emits may not match the schema Claude Code sent.
2. **Our parser** — `_parse_call_body` could be type-coercing wrong
   (e.g. emitting a string where an int is expected, losing a
   required key, collapsing nested structure).
3. **Our round-trip translator** — `anthropic_to_gemma_messages`
   folds the last assistant turn's `tool_calls` + the user's
   `tool_result` back into Gemma's expected shape; a wrong mapping
   would make the model re-generate a malformed call based on stale
   context.

We cannot narrow this down without the raw model output for the
failing turn. The plan therefore starts with capture, then
diagnosis, then fix.

## Phase 1 — capture the failing call (no code change)

Reproduce the error with full debug logging and keep the log. This
is the only step where we learn what's actually wrong; everything
after this adapts to what we find.

```bash
rm -f /tmp/main.py
MLXSERVER_DEBUG=1 mlx-server --model gemma-4-e2b-it-4bit 2> /tmp/mlx-debug.log
```

In the Claude Code session, run the same three-step flow from the
user's report:

1. `Write python code to print "Hello World" to main.py`
2. `Update main.py to print 3 different interesting phrases.`
3. `okay should choose 1 phrase from list and print it. And Phrase 1,
   2, 3 isn't interesting. First come up with 3 interesting text from
   CS history like "Hello World"`

When Claude Code prints **Invalid tool parameters**, stop the server.

Then pull out, for the last request in `/tmp/mlx-debug.log`:

- The incoming `messages` dump (shows what LiteLLM handed us,
  including the prior assistant's `tool_calls` and the user's
  `tool_result`).
- The `tools` dump (to know the exact declared `input_schema` for the
  tool Gemma tried to call).
- The rendered prompt (to verify we sent tool declarations and prior
  turn context correctly).
- The **raw model output** — this is what `_parse_call_body` is
  parsing. We added a `[mlx-server DEBUG] raw output (N chars): …`
  line specifically for this; it's the ground truth.

Paste those four snippets into an issue or just look at them — they
will tell us which layer is broken in under a minute.

## Phase 2 — categorize the failure

Based on the raw output from Phase 1, exactly one of the following
is true. The fix differs per bucket; do not start coding until we
know which bucket we're in.

### Bucket A: model emits valid shape, parser mangles it

Symptoms:
- Raw output contains the correct keys and values.
- `_parse_call_body` returns a `ParsedToolCall` whose `arguments`
  dict has different keys, wrong types, or missing fields.

Likely culprits:
- `_parse_scalar` falls back to returning a bare identifier as a
  **string** when the schema wanted an int or bool
  (`count:5` → `5` is fine; `count:five` → `"five"` is a schema
  violation — but it was already wrong at the model layer).
- `_parse_string` consumes `<|"|>` delimiters but the model may
  have dropped one, producing a string that extends across the
  next key.
- JSON fallback parses successfully but `json.loads` returns a
  structure with extra wrapping keys (e.g. `{"parameters": {…}}`
  instead of the parameters directly).
- `_normalize_tool_calls` in `tools/schemas.py` re-serializes
  arguments to a JSON string and something downstream double-
  encodes it.

Fix path:
- Add a targeted unit test in `tests/test_gemma_parser.py` using
  the exact raw output as the golden input and the expected parsed
  arguments. Land the fix against that test. Keep the test — it
  guards the regression.

### Bucket B: model emits the wrong shape

Symptoms:
- Raw output has a key Claude Code's schema doesn't know, or
  omits a required field, or puts a value of the wrong type.
- Parser returns exactly what the model emitted.

Likely culprits:
- The tool has a deeply nested schema (AskUserQuestion,
  `Task.tools`, Agent's subagent config). Gemma generalizes badly
  from the `<|tool>declaration:…{…}<tool|>` format and fills in
  plausible-looking but schema-invalid content.
- Gemma 4 E2B is small; it hallucinates required fields or
  confuses similar tool names (e.g. `Edit` vs `Write`).
- The schema uses enum-valued strings and Gemma emits an out-of-
  enum value.

Fix path (one or more, in order of cheapness):

1. **Better declaration rendering**. Our current prompt is whatever
   `tokenizer.apply_chat_template(tools=…)` produces — a best-effort
   encoding built from each tool's JSON schema. For tools with
   required fields, verify those required fields actually appear in
   the declaration block the template emits. If they don't, we may
   need to inject a one-line reminder into the system prompt:
   "Always include all required fields when calling a tool."
   (Cheap, low-risk, easy to roll back.)
2. **Tool-call validation + one-shot repair**. After we parse a
   call, validate its `arguments` against the tool's
   `input_schema` using a lightweight JSON schema check
   (`jsonschema` package, already a transitive dep of LiteLLM). If
   it fails, either:
   - Drop the call and let Claude Code retry (current behavior
     except we currently don't validate — we deliver the bad call
     and Claude Code rejects it on its side).
   - Emit a **fallback text block** with the malformed JSON so the
     user can see what the model tried to do, rather than a
     cryptic "Invalid tool parameters" with no context.
3. **Skip-and-log degrade**. If a call fails validation, log
   `[mlx-server WARN] dropped invalid tool call: <tool> missing
   <fields>` and do not emit the `tool_use` block. The model
   typically continues with plain text or tries again — better
   than a hard error.
4. **Larger model**. If Gemma 4 E2B (effective 2B) is genuinely
   too small for schema-correct tool calls on complex tools, the
   real fix is to move to the production target
   (`gemma-4-26b-a4b-it-4bit`). Do this only after (1)–(3) prove
   insufficient — we should not hide model weakness behind parser
   hacks.

### Bucket C: round-trip translator corrupts history

Symptoms:
- First turn's tool call is fine.
- Second and later turns show the error.
- The rendered prompt on turn 2+ either (a) lacks the prior
  assistant tool_call block, (b) lacks the user tool_result
  block, or (c) has them wrapped in the wrong role / field.

This is an `anthropic_to_gemma_messages` bug in
`src/mlxserver/tools/schemas.py`. Specifically:

- Assistant turns with `tool_calls` must render as
  `<|turn>model\n<|tool_call>call:X{…}<tool_call|><turn|>`.
- User turns with `tool_result` must render as
  `<|turn>user\n<|tool_response>response:X{…}<tool_response|><turn|>`
  and mlx_vlm's chat template does this from the
  `message['tool_responses']` list we synthesize on an assistant
  role.

Check the rendered prompt for the failing turn:
- Is the prior `<|tool_call>` present?
- Is the prior `<|tool_response>` present?
- Does the `name` field on `tool_responses` match the original
  tool_call's `name`? (Our `_lookup_tool_name` scans previous
  messages for the `tool_call_id` — if LiteLLM renames or drops
  that id between turns, we pair tool results with "unknown" and
  the template emits a broken round-trip.)

Fix path:
- Add a schemas.py unit test that feeds a full three-turn
  conversation (user → assistant tool_call → user tool_result →
  user new question) and asserts the produced shape.
- Patch `anthropic_to_gemma_messages` until the test passes.

## Phase 3 — diagnostics plumbing (small, does double duty)

Regardless of which bucket we land in, these improvements pay for
themselves quickly and make future debugging 10× faster.

1. **Schema validation logging.** In `provider.completion` and
   `provider.streaming`, after calling `parse_gemma_output` /
   flushing the streaming parser, if any tool call's arguments
   fail a quick JSON-schema check against the declared tool, log:
   ```
   [mlx-server WARN] tool call "<Tool>" failed schema check: <reason>
     raw: <first 200 chars of model output for this call>
     args: <json of parsed args>
   ```
   This is always on (not gated on `MLXSERVER_DEBUG`), but one
   line per occurrence — not verbose.

2. **Round-trip dump helper.** `MLXSERVER_DEBUG=1` should also dump
   the output of `anthropic_to_gemma_messages` (the post-
   translation messages) right before rendering, so we can see
   exactly which history shape the model is being fed on each turn.
   Add it next to the existing rendered-prompt dump.

3. **Persist the last N failing requests.** When a call fails
   schema validation, write the (messages, tools, raw output,
   parsed args) tuple to
   `~/.mlxserver/debug/<timestamp>.json`. Makes "give me a
   repro" conversations trivial. Cap at the last 20.

Do these regardless of which bucket we fix — they're cheap and make
the codebase more self-diagnosing.

## Phase 4 — validation

- [ ] Rerun the exact three-step flow from Phase 1 with the fix in
      place. Each step must complete without Claude Code showing
      "Invalid tool parameters".
- [ ] `pytest tests/` still green. Any new tests added in Phase 2
      must be in the suite.
- [ ] If Bucket A fix was needed: the added parser unit test
      passes and would have failed on the previous commit.
- [ ] If Bucket B fix was needed: the schema-validation warning
      stops firing for the flow in question.
- [ ] If Bucket C fix was needed: the rendered prompt on turn 3
      contains the prior `<|tool_call>` and `<|tool_response>`
      blocks in the expected order.
- [ ] `MLXSERVER_DEBUG=1` still produces cache-hit, rendered
      prompt, raw output, and (new) post-translation-message
      dump lines.

## Out of scope (noted, deferred)

- Automatic retry when a tool call fails validation. Currently
  Claude Code handles retries on its side — don't duplicate.
- Model-agnostic tool parsing. The parser is Gemma-specific; that's
  fine for v1.
- Multi-session prompt caches. Still single-session.
- Moving off Gemma 4 E2B. The production target is
  `gemma-4-26b-a4b-it-4bit` and we should retest on it before
  concluding any fix isn't sufficient — a larger model may
  eliminate entire classes of schema errors without parser changes.

## Risks

- **Hallucinated causes**. Without the Phase 1 capture, any fix we
  write is guesswork. Do not skip Phase 1.
- **Over-fitting to one failing flow**. If the captured failure is
  specific to `AskUserQuestion` with its deep nesting, "fix" it
  against that alone and it will regress on the next complex tool.
  Add a schema validator (Phase 3, item 1) so we catch the whole
  class, not one instance.
- **Obscuring a model-capability issue**. If Gemma 4 E2B simply
  can't produce schema-correct calls for complex tools, the right
  fix is a bigger model — adding parser hacks only delays the
  reckoning. Phase 2 Bucket B explicitly flags this path.
