from pathlib import Path

from tether.config import (
    ROOT_CONFIG_NAME,
    Config,
    discover_config_files,
    ensure_default_config,
    load_config,
)


def test_first_run_creates_root_with_64k_default(tmp_path: Path):
    root = tmp_path / ROOT_CONFIG_NAME
    assert not root.exists()

    created = ensure_default_config(root)
    assert created is True
    assert root.is_file()
    assert "max_context = 65536" in root.read_text()

    # Idempotent: second call leaves the file alone.
    first_mtime = root.stat().st_mtime_ns
    created_again = ensure_default_config(root)
    assert created_again is False
    assert root.stat().st_mtime_ns == first_mtime

    cfg, first_run = load_config(config_dir=tmp_path)
    assert first_run is False  # ensure_default_config was already called
    assert cfg.max_context == 65536


def test_load_config_reports_first_run_when_root_missing(tmp_path: Path):
    cfg, first_run = load_config(config_dir=tmp_path)
    assert first_run is True
    assert (tmp_path / ROOT_CONFIG_NAME).is_file()
    assert cfg.max_context == 65536


def test_directory_merge_alphabetical(tmp_path: Path):
    (tmp_path / ROOT_CONFIG_NAME).write_text(
        '[server]\nport = 9000\n\n[model]\nmax_context = 30000\n'
    )
    (tmp_path / "10-early.toml").write_text(
        '[server]\nport = 9001\n\n[model]\nmemory_cap = "8GB"\n'
    )
    (tmp_path / "20-late.toml").write_text(
        '[server]\nport = 9002\n'
    )
    # Should be ignored:
    (tmp_path / ".hidden.toml").write_text('[server]\nport = 7777\n')
    (tmp_path / "notes.txt").write_text("ignored")

    files = [p.name for p in discover_config_files(tmp_path)]
    assert files == [ROOT_CONFIG_NAME, "10-early.toml", "20-late.toml"]

    cfg, _ = load_config(config_dir=tmp_path)
    # Alphabetical tail wins for a field set in multiple layers.
    assert cfg.port == 9002
    # Memory cap set only in the early drop-in survives.
    assert cfg.memory_cap_bytes == 8_000_000_000  # 8 GB (SI)
    # max_context is only in the root; nothing overrode it.
    assert cfg.max_context == 30000


def test_unknown_keys_are_silently_ignored(tmp_path: Path):
    (tmp_path / ROOT_CONFIG_NAME).write_text(
        '[model]\nmax_context = 12345\nfuture_field = "whatever"\n\n[unknown]\nx = 1\n'
    )
    cfg, _ = load_config(config_dir=tmp_path)
    assert cfg.max_context == 12345
