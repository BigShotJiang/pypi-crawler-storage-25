import pytest

from tether.tools.gemma import (
    GemmaToolCallParser,
    parse_gemma_output,
)

GOLDEN = (
    '<|tool_call>call:Write{'
    'content:<|"|>print("hello world")<|"|>,'
    'file_path:<|"|>/tmp/main.py<|"|>'
    '}<tool_call|>'
)


def test_non_streaming_golden():
    text, calls = parse_gemma_output(GOLDEN)
    assert text == ""
    assert len(calls) == 1
    c = calls[0]
    assert c.name == "Write"
    assert c.arguments == {
        "content": 'print("hello world")',
        "file_path": "/tmp/main.py",
    }
    assert c.id.startswith("toolu_")


def test_non_streaming_text_before_and_after():
    s = "Sure, I'll do that.\n" + GOLDEN + "\nDone."
    text, calls = parse_gemma_output(s)
    assert text == "Sure, I'll do that.\n\nDone."
    assert len(calls) == 1


def test_non_streaming_multiple_calls():
    call2 = (
        '<|tool_call>call:Bash{command:<|"|>ls /tmp<|"|>}<tool_call|>'
    )
    text, calls = parse_gemma_output(GOLDEN + call2)
    assert text == ""
    assert [c.name for c in calls] == ["Write", "Bash"]
    assert calls[1].arguments == {"command": "ls /tmp"}


def test_non_streaming_nested_object_and_array():
    s = (
        '<|tool_call>call:Complex{'
        'outer:{inner:<|"|>v<|"|>,n:42,b:true,nil:null},'
        'list:[1,2,<|"|>three<|"|>]'
        '}<tool_call|>'
    )
    _, calls = parse_gemma_output(s)
    assert len(calls) == 1
    args = calls[0].arguments
    assert args["outer"] == {"inner": "v", "n": 42, "b": True, "nil": None}
    assert args["list"] == [1, 2, "three"]


def test_non_streaming_malformed_falls_back_to_text():
    bad = "<|tool_call>call:Write{oops<tool_call|>"
    text, calls = parse_gemma_output(bad)
    assert calls == []
    assert text == bad


def test_non_streaming_real_json_body():
    # Observed in the wild: on deeply-nested schemas (AskUserQuestion)
    # Gemma 4 emits real JSON inside the braces instead of its own DSL.
    s = (
        '<|tool_call>call:AskUserQuestion{\n'
        '    "questions": [\n'
        '      {\n'
        '        "question": "Which phrase would you like to print?",\n'
        '        "header": "Phrase Selection",\n'
        '        "options": [\n'
        '          {"label": "Phrase 1", "description": "first"},\n'
        '          {"label": "Phrase 2", "description": "second"}\n'
        '        ],\n'
        '        "multiSelect": false\n'
        '      }\n'
        '    ]\n'
        '  }<tool_call|>'
    )
    text, calls = parse_gemma_output(s)
    assert text == ""
    assert len(calls) == 1
    c = calls[0]
    assert c.name == "AskUserQuestion"
    assert len(c.arguments["questions"]) == 1
    q = c.arguments["questions"][0]
    assert q["header"] == "Phrase Selection"
    assert q["multiSelect"] is False
    assert len(q["options"]) == 2
    assert q["options"][0]["label"] == "Phrase 1"


def test_streaming_real_json_body_split():
    # Same shape, but fed in small chunks, to confirm the streaming
    # parser also reaches the JSON-fallback path.
    golden = (
        '<|tool_call>call:AskUserQuestion{"questions":[{"q":"x","n":1}]}<tool_call|>'
    )
    p = GemmaToolCallParser()
    events = []
    for i in range(0, len(golden), 5):
        events.extend(p.feed(golden[i : i + 5]))
    events.extend(p.flush())
    calls = [e.tool_call for e in events if e.kind == "tool_call"]
    assert len(calls) == 1
    assert calls[0].name == "AskUserQuestion"
    assert calls[0].arguments == {"questions": [{"q": "x", "n": 1}]}


def test_streaming_full_golden_one_chunk():
    p = GemmaToolCallParser()
    events = p.feed(GOLDEN) + p.flush()
    kinds = [e.kind for e in events]
    assert kinds == ["tool_call"]
    assert events[0].tool_call.name == "Write"


@pytest.mark.parametrize("split_size", [1, 2, 3, 5, 7, 11, 13, 29])
def test_streaming_resumable_at_every_split(split_size):
    text = "ok here goes: " + GOLDEN + " done"
    p = GemmaToolCallParser()
    events = []
    for i in range(0, len(text), split_size):
        events.extend(p.feed(text[i : i + split_size]))
    events.extend(p.flush())
    text_out = "".join(e.text for e in events if e.kind == "text")
    calls = [e.tool_call for e in events if e.kind == "tool_call"]
    assert text_out == "ok here goes:  done"
    assert len(calls) == 1
    assert calls[0].name == "Write"
    assert calls[0].arguments["file_path"] == "/tmp/main.py"


def test_streaming_split_inside_open_marker():
    # Split in the middle of `<|tool_call>` — the parser must not emit
    # the partial marker as text.
    p = GemmaToolCallParser()
    a = "<|tool_ca"
    b = "ll>call:X{k:<|\"|>v<|\"|>}<tool_call|>"
    events = p.feed(a) + p.feed(b) + p.flush()
    text_out = "".join(e.text for e in events if e.kind == "text")
    calls = [e.tool_call for e in events if e.kind == "tool_call"]
    assert text_out == ""
    assert len(calls) == 1
    assert calls[0].name == "X"


def test_streaming_unterminated_call_flushed_as_text():
    p = GemmaToolCallParser()
    events = p.feed("<|tool_call>call:Half{k:") + p.flush()
    assert all(e.kind == "text" for e in events)
    assert "".join(e.text for e in events).startswith("<|tool_call>call:Half")
