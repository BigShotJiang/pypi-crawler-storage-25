from __future__ import annotations

import argparse
import sys
from pathlib import Path

from tether.config import (
    Config,
    _parse_memory_cap,
    ensure_models_root,
    load_config,
    models_root,
)
from tether.models import ModelEntry, list_local_models


def _split_passthrough(argv: list[str] | None) -> tuple[list[str], list[str]]:
    raw = list(sys.argv[1:] if argv is None else argv)
    if "--" in raw:
        idx = raw.index("--")
        return raw[:idx], raw[idx + 1 :]
    return raw, []


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tether",
        description=(
            "Local Anthropic-compatible LLM server for Claude Code, backed "
            "by mlx-vlm. By default, launches the proxy and opens Claude "
            "Code in the same terminal — like `ollama launch claude`. "
            "Defaults come from ~/.tether/config.toml when present; "
            "CLI flags override."
        ),
        epilog=(
            "Anything after `--` is forwarded to the claude child process "
            "(e.g. `tether --model X -- --resume`)."
        ),
    )
    p.add_argument("--model", help="Model path, bare name under ~/.tether/models/, or HF repo id.")
    p.add_argument("--host", help=f"Bind host (default from config, else 127.0.0.1)")
    p.add_argument("--port", type=int, help="Bind port (default from config, else 8080)")
    p.add_argument("--models-dir", help="Override ~/.tether/models")
    p.add_argument("--list", action="store_true", help="List local models and exit.")
    p.add_argument(
        "--serve-only",
        action="store_true",
        help="Run only the proxy (do not launch claude). Alias: --no-claude.",
    )
    p.add_argument("--no-claude", dest="serve_only", action="store_true")
    p.add_argument(
        "--claude-path",
        help="Path to the claude binary (default: first `claude` on PATH).",
    )
    p.add_argument(
        "--memory-cap",
        help="MLX memory ceiling, e.g. '18GB', '20GiB'. Hard-fails instead of swapping.",
    )
    p.add_argument(
        "--max-context",
        type=int,
        help="Truncate conversation history so the rendered prompt stays under N tokens.",
    )
    p.add_argument("--log-level", help="Uvicorn log level (default from config, else warning).")
    return p


def _print_list(entries: list[ModelEntry], root) -> None:
    if not entries:
        print(f"No models found in {root}.")
        print(f"Place MLX models there, or run with --model <path_or_repo>.")
        return
    print(f"Models in {root}:")
    for e in entries:
        q = f"[{e.quant}]" if e.quant else ""
        print(f"  {e.name:<40} {q:<10} {e.human_size}")


def _resolve_model_name(name: str, root) -> str:
    """Turn the --model argument into something mlx_vlm.load will accept.

    Resolution rules, in order:
      1. Existing filesystem path (absolute, ~-prefixed, or relative).
      2. Bare name with no slashes → try ``<models_dir>/<name>``; use it
         if the directory exists.
      3. Contains a slash → treat as an HF repo id and pass through.
      4. Otherwise → pass through so mlx_vlm.load surfaces the error.
    """
    raw = name.strip()
    expanded = Path(raw).expanduser()

    if expanded.exists():
        return str(expanded.resolve())

    if "/" not in raw:
        candidate = Path(root) / raw
        if candidate.exists():
            return str(candidate.resolve())

    return raw


def _apply_cli_to_config(cfg: Config, args) -> Config:
    memory_cap: int | None = None
    if args.memory_cap is not None:
        memory_cap = _parse_memory_cap(args.memory_cap)
    return cfg.merge_cli(
        host=args.host,
        port=args.port,
        model=args.model,
        models_dir=args.models_dir,
        claude_path=args.claude_path,
        log_level=args.log_level,
        memory_cap_bytes=memory_cap,
        max_context=args.max_context,
    )


def _resolve_model(cfg: Config) -> str | None:
    root = ensure_models_root(models_root(cfg.models_dir))

    if cfg.model:
        return _resolve_model_name(cfg.model, root)
    entries = list_local_models(root)

    if not entries:
        print(f"No local models in {root}.", file=sys.stderr)
        print(
            f"Download an MLX model into {root} (e.g. via "
            f"`huggingface-cli download <repo> --local-dir "
            f"{root}/<name>`) and retry, or pass --model <path>.",
            file=sys.stderr,
        )
        return None

    from tether.picker import pick_model

    choice = pick_model(entries)
    return str(choice.path) if choice else None


def main(argv: list[str] | None = None) -> int:
    parser_argv, claude_extra = _split_passthrough(argv)
    args = _build_parser().parse_args(parser_argv)

    cfg, first_run = load_config()
    if first_run:
        from tether.config import CONFIG_DIR, ROOT_CONFIG_NAME

        print(
            f"[tether] wrote default config to {CONFIG_DIR / ROOT_CONFIG_NAME}",
            flush=True,
        )
    cfg = _apply_cli_to_config(cfg, args)

    root = ensure_models_root(models_root(cfg.models_dir))

    if args.list:
        _print_list(list_local_models(root), root)
        return 0

    model = _resolve_model(cfg)
    if not model:
        print("No model selected.", file=sys.stderr)
        return 1

    if args.serve_only:
        from tether.proxy import run

        try:
            run(
                model,
                cfg.host,
                cfg.port,
                log_level=cfg.log_level,
                memory_cap_bytes=cfg.memory_cap_bytes,
                max_context=cfg.max_context,
            )
        except KeyboardInterrupt:
            print("\n[tether] shutting down", flush=True)
        return 0

    from tether.launcher import launch_claude

    return launch_claude(
        model_path=model,
        host=cfg.host,
        port=cfg.port,
        claude_path=cfg.claude_path,
        extra_args=claude_extra,
        log_level=cfg.log_level,
        memory_cap_bytes=cfg.memory_cap_bytes,
        max_context=cfg.max_context,
    )


if __name__ == "__main__":
    raise SystemExit(main())
