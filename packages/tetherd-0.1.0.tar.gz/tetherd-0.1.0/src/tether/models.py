from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ModelEntry:
    name: str
    path: Path
    size_bytes: int
    quant: str | None

    @property
    def human_size(self) -> str:
        n = float(self.size_bytes)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if n < 1024 or unit == "TB":
                return f"{n:.1f}{unit}" if unit != "B" else f"{int(n)}B"
            n /= 1024
        return f"{n:.1f}TB"


def _dir_size(path: Path) -> int:
    total = 0
    for p in path.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
            except OSError:
                pass
    return total


def _quant_tag(config_path: Path) -> str | None:
    try:
        data = json.loads(config_path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    q = data.get("quantization")
    if isinstance(q, dict):
        bits = q.get("bits")
        group = q.get("group_size")
        if bits is not None:
            return f"{bits}bit" + (f"-g{group}" if group else "")
    return None


def list_local_models(root: Path) -> list[ModelEntry]:
    if not root.exists():
        return []
    entries: list[ModelEntry] = []
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        config = child / "config.json"
        if not config.is_file():
            continue
        entries.append(
            ModelEntry(
                name=child.name,
                path=child.resolve(),
                size_bytes=_dir_size(child),
                quant=_quant_tag(config),
            )
        )
    return entries
