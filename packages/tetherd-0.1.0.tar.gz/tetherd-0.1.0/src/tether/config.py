from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # Python <3.11 fallback (we require 3.12 but be defensive)
    import tomli as tomllib  # type: ignore[no-redef]

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8080

# 64k-token context cap by default. Truncates the oldest conversation
# turns when a request would render longer than this, so the KV cache
# never blows up on a memory-bound machine. Set to 0 in a drop-in to
# disable.
DEFAULT_MEMORY_CAP: int | None = None
DEFAULT_MAX_CONTEXT: int | None = 65536

CONFIG_DIR = Path.home() / ".tether" / "config"
ROOT_CONFIG_NAME = "config.toml"

# Written to ~/.tether/config/config.toml on first run. Never
# overwritten after that. Keep it heavily commented so the file
# doubles as documentation the user can read without leaving their
# editor.
_DEFAULT_CONFIG_TEMPLATE = """\
# tether config — auto-generated on first run. Edit freely;
# this file will not be overwritten. For per-machine or per-project
# tweaks, drop additional .toml files into this same directory
# (e.g. 10-m4pro.toml). They are merged alphabetically on top of
# this file. Every option is also available as a CLI flag for
# one-off overrides — run `tether --help` to see them.

[server]
# host = "127.0.0.1"
# port = 8080

[model]
# Bare name (resolved against ~/.tether/models/), absolute path,
# or an HF repo id. Leave unset to get the TUI picker on startup.
# default = "gemma-4-e2b-it-4bit"

# Hard MLX memory ceiling. mx.set_memory_limit raises on overflow
# instead of swapping to disk. Examples: "18GB", "20GiB", "500MB".
# Leave unset on machines with ample RAM (32GB+).
# memory_cap = "18GiB"

# Maximum rendered-prompt size in tokens. When a request would
# exceed this, the oldest conversation turns are dropped until the
# rendered prompt fits. System messages are always preserved so
# the prompt cache stays hot. Set to 0 to disable.
max_context = 65536

[launch]
# claude_path = "/usr/local/bin/claude"
# log_level = "warning"
"""


@dataclass
class Config:
    """All tunables. Each field may come from a config file or a CLI arg.

    Precedence (highest → lowest):
      CLI arg > drop-in (alphabetical tail) > drop-in (…) > config.toml
        > built-in dataclass default
    """

    host: str = DEFAULT_HOST
    port: int = DEFAULT_PORT
    model: str | None = None
    models_dir: str | None = None
    memory_cap_bytes: int | None = DEFAULT_MEMORY_CAP
    max_context: int | None = DEFAULT_MAX_CONTEXT
    claude_path: str | None = None
    log_level: str = "warning"

    def merge_cli(self, **overrides: Any) -> "Config":
        """Return a copy with any non-None override applied."""
        out = Config(**self.__dict__)
        for k, v in overrides.items():
            if v is None:
                continue
            setattr(out, k, v)
        return out


def _parse_memory_cap(raw: Any) -> int | None:
    """Accept '18GB', '18G', '18.5 GiB', '500MB', '1000000000', or int bytes."""
    if raw is None or raw == "":
        return None
    if isinstance(raw, int):
        return raw if raw > 0 else None
    if not isinstance(raw, str):
        raise ValueError(f"memory_cap must be a string or int, got {type(raw).__name__}")
    m = re.fullmatch(
        r"\s*([0-9]+(?:\.[0-9]+)?)\s*([KMGT]i?B|B)?\s*",
        raw,
        flags=re.IGNORECASE,
    )
    if not m:
        raise ValueError(f"could not parse memory_cap {raw!r}")
    value = float(m.group(1))
    unit = (m.group(2) or "B").upper()
    factors = {
        "B": 1,
        "KB": 1000,
        "KIB": 1024,
        "MB": 1000**2,
        "MIB": 1024**2,
        "GB": 1000**3,
        "GIB": 1024**3,
        "TB": 1000**4,
        "TIB": 1024**4,
    }
    return int(value * factors[unit])


def ensure_default_config(path: Path) -> bool:
    """Write the template to ``path`` if it doesn't exist yet.

    Returns True when a file was created (so the CLI can print a
    one-time notice), False when the file already existed.
    """
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_DEFAULT_CONFIG_TEMPLATE)
    return True


def discover_config_files(root_dir: Path) -> list[Path]:
    """Return the config.toml root plus any sibling .toml drop-ins.

    Ordering: ``[config.toml, *sorted(rest by filename)]``. Files
    starting with ``.``, non-``.toml`` files, and subdirectories
    are ignored. If the directory does not exist, returns an empty
    list (caller should have called :func:`ensure_default_config`
    first).
    """
    if not root_dir.is_dir():
        return []
    root = root_dir / ROOT_CONFIG_NAME
    others: list[Path] = []
    for p in root_dir.iterdir():
        if not p.is_file():
            continue
        if p.name == ROOT_CONFIG_NAME:
            continue
        if p.name.startswith("."):
            continue
        if p.suffix != ".toml":
            continue
        others.append(p)
    others.sort(key=lambda p: p.name)
    result: list[Path] = []
    if root.is_file():
        result.append(root)
    result.extend(others)
    return result


def _read_toml_into(cfg: Config, path: Path) -> Config:
    """Apply one TOML file as an overlay on top of ``cfg``.

    Only fields that appear in the file are updated; everything else
    inherits from ``cfg``. Unknown keys are silently ignored.
    """
    with path.open("rb") as f:
        data = tomllib.load(f)

    server = data.get("server") or {}
    model = data.get("model") or {}
    launch = data.get("launch") or {}

    new = Config(**cfg.__dict__)

    if "host" in server:
        new.host = str(server["host"])
    if "port" in server:
        new.port = int(server["port"])

    if "default" in model:
        new.model = model["default"]
    if "models_dir" in model:
        new.models_dir = model["models_dir"]
    if "memory_cap" in model:
        new.memory_cap_bytes = _parse_memory_cap(model["memory_cap"])
    if "max_context" in model:
        mx_ctx = model["max_context"]
        new.max_context = int(mx_ctx) if mx_ctx else None

    if "claude_path" in launch:
        new.claude_path = launch["claude_path"]
    if "log_level" in launch:
        new.log_level = str(launch["log_level"])

    return new


def load_config(config_dir: Path | None = None) -> tuple[Config, bool]:
    """Assemble the merged config from the conf.d directory.

    Order of application (lowest to highest precedence):
      1. Dataclass defaults (``Config()``).
      2. ``<config_dir>/config.toml`` (the root; auto-created).
      3. Every other ``*.toml`` file in ``<config_dir>``, sorted by
         filename.

    Returns ``(config, first_run)`` where ``first_run`` is True when
    this call created the root config file.

    ``config_dir`` is intended for tests; production call sites pass
    nothing and get ``CONFIG_DIR``.
    """
    root_dir = config_dir if config_dir is not None else CONFIG_DIR
    created = ensure_default_config(root_dir / ROOT_CONFIG_NAME)

    cfg = Config()
    for p in discover_config_files(root_dir):
        cfg = _read_toml_into(cfg, p)
    return cfg, created


def models_root(override: str | None = None) -> Path:
    if override:
        return Path(override).expanduser().resolve()
    env = os.environ.get("TETHER_MODELS_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return Path.home() / ".tether" / "models"


def ensure_models_root(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path
