from __future__ import annotations

import os
import tempfile
from pathlib import Path

import yaml

MODEL_ALIAS = "mlx-local"


_HANDLER_SHIM = '''\
import os
from tether.provider import MLXProvider

_path = os.environ["TETHER_MODEL_PATH"]
handler = MLXProvider(_path)
# Eager-load the model at import time so any failure surfaces during
# proxy startup (readiness probe) rather than on the first request.
handler._ensure_loaded()
'''


def _write_litellm_config(tmpdir: Path) -> Path:
    # LiteLLM's get_instance_fn resolves custom_handler relative to the
    # config file's directory, so the shim module must live next to it.
    (tmpdir / "mlx_handler.py").write_text(_HANDLER_SHIM)

    # Claude Code sends several distinct model names per session (main
    # model, haiku for background tasks, subagent model, etc.). Our proxy
    # has exactly one real backend, so a wildcard route catches any name
    # and dispatches it to the single MLX handler. The explicit alias
    # entry is kept so /v1/models shows a sensible name.
    config = {
        "model_list": [
            {
                "model_name": MODEL_ALIAS,
                "litellm_params": {"model": f"mlx/{MODEL_ALIAS}"},
            },
            {
                "model_name": "*",
                "litellm_params": {"model": f"mlx/{MODEL_ALIAS}"},
            },
        ],
        "litellm_settings": {
            "custom_provider_map": [
                {
                    "provider": "mlx",
                    "custom_handler": "mlx_handler.handler",
                }
            ],
            "drop_params": True,
        },
        "general_settings": {
            "disable_spend_logs": True,
            "allow_requests_on_db_unavailable": True,
        },
    }
    path = tmpdir / "litellm_config.yaml"
    path.write_text(yaml.safe_dump(config, sort_keys=False))
    return path


def _silence_litellm_noise() -> None:
    """Suppress LiteLLM's startup ASCII banner, feedback box, and the
    CRITICAL master-key warning. None of it is actionable for a local
    single-user proxy and it clutters the otherwise-clean tether
    output. Users who want the chatter can set LITELLM_VERBOSE=1."""
    import logging

    import litellm
    from litellm.proxy import proxy_server

    if os.environ.get("LITELLM_VERBOSE") == "1":
        return

    # (1) ASCII banner + feedback box. Monkey-patch the functions that
    #     print them to no-ops. `generate_feedback_box` handles the
    #     "Thank you for using LiteLLM" box; `show_banner` prints the
    #     multi-line ASCII art.
    if hasattr(proxy_server, "generate_feedback_box"):
        proxy_server.generate_feedback_box = lambda *a, **kw: None
    try:
        from litellm.proxy.common_utils import banner as _banner_mod

        _banner_mod.show_banner = lambda *a, **kw: None
    except Exception:
        pass

    # (2) "LITELLM_MASTER_KEY is not set" and every other log line
    #     LiteLLM emits through its own loggers. Raise each to a level
    #     above CRITICAL so nothing gets through.
    _SILENCED = logging.CRITICAL + 10
    for name in ("LiteLLM", "LiteLLM Proxy", "LiteLLM Router"):
        logging.getLogger(name).setLevel(_SILENCED)
    # Also mute the module-level logger if LiteLLM switches to it.
    logging.getLogger("litellm").setLevel(_SILENCED)


def _prepare(
    model_path: str,
    memory_cap_bytes: int | None = None,
    max_context: int | None = None,
) -> None:
    os.environ["TETHER_MODEL_PATH"] = model_path
    os.environ.pop("LITELLM_MODE", None)
    os.environ.pop("DATABASE_URL", None)
    # mlx_vlm.generate hardcodes a tqdm "Prefill" progress bar that
    # fires on every long prompt (tool-use schemas push prompts into
    # the 20k-60k token range). Silence all tqdm output unless the
    # user explicitly opted in.
    os.environ.setdefault("TQDM_DISABLE", "1")
    _silence_litellm_noise()

    # Caps are passed to the handler shim through env vars so it can
    # apply them before the first request lands. The shim runs in the
    # uvicorn worker's import path, not in this process, so we cannot
    # hand it Python objects directly.
    if memory_cap_bytes:
        os.environ["TETHER_MEMORY_CAP"] = str(int(memory_cap_bytes))
    else:
        os.environ.pop("TETHER_MEMORY_CAP", None)
    if max_context:
        os.environ["TETHER_MAX_CONTEXT"] = str(int(max_context))
    else:
        os.environ.pop("TETHER_MAX_CONTEXT", None)

    tmpdir = Path(tempfile.mkdtemp(prefix="tether-"))
    config_path = _write_litellm_config(tmpdir)

    from litellm.proxy.proxy_server import save_worker_config

    save_worker_config(
        config=str(config_path),
        model=None,
        debug=False,
        telemetry=False,
    )


def build_server(
    model_path: str,
    host: str,
    port: int,
    log_level: str = "warning",
    memory_cap_bytes: int | None = None,
    max_context: int | None = None,
):
    """Return a configured (but not-yet-running) uvicorn.Server.

    Used by the unified launcher to run LiteLLM on a background thread
    while the main thread owns the terminal for the Claude Code child.
    """
    import uvicorn
    from litellm.proxy.proxy_server import app

    _prepare(model_path, memory_cap_bytes=memory_cap_bytes, max_context=max_context)

    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level=log_level,
        access_log=False,
    )
    return uvicorn.Server(config)


def run(
    model_path: str,
    host: str,
    port: int,
    log_level: str = "info",
    memory_cap_bytes: int | None = None,
    max_context: int | None = None,
) -> None:
    """Bare proxy mode (--serve-only). Blocks in the foreground."""
    import uvicorn
    from litellm.proxy.proxy_server import app

    _prepare(model_path, memory_cap_bytes=memory_cap_bytes, max_context=max_context)

    print(
        f"[tether] listening on http://{host}:{port}  "
        f"(anthropic-compat via LiteLLM, model={model_path})",
        flush=True,
    )
    if memory_cap_bytes:
        gb = memory_cap_bytes / 1024**3
        print(f"[tether] memory cap: {gb:.1f} GiB (hard limit)", flush=True)
    if max_context:
        print(f"[tether] max context: {max_context} tokens", flush=True)
    print(
        f"[tether] point Claude Code at ANTHROPIC_BASE_URL=http://{host}:{port}",
        flush=True,
    )
    uvicorn.run(app, host=host, port=port, log_level=log_level)
