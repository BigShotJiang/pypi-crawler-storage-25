from __future__ import annotations

import sys
from typing import Sequence

from rich.console import Console
from rich.live import Live
from rich.table import Table
from rich.text import Text

from tether.models import ModelEntry

console = Console()


def _render(entries: Sequence[ModelEntry], cursor: int) -> Table:
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column(" ", width=2)
    table.add_column("Model")
    table.add_column("Quant")
    table.add_column("Size", justify="right")
    for i, e in enumerate(entries):
        marker = "›" if i == cursor else " "
        row = [marker, e.name, e.quant or "-", e.human_size]
        if i == cursor:
            table.add_row(*[Text(c, style="reverse") for c in row])
        else:
            table.add_row(*row)
    return table


def _read_key() -> str:
    import termios
    import tty

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == "\x1b":
            ch2 = sys.stdin.read(2)
            return ch + ch2
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def pick_model(entries: Sequence[ModelEntry]) -> ModelEntry | None:
    if not entries:
        return None
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        console.print("Select a model:")
        for i, e in enumerate(entries, 1):
            console.print(f"  {i}. {e.name}  [{e.quant or '-'}]  {e.human_size}")
        raw = input("Enter number (blank to cancel): ").strip()
        if not raw:
            return None
        try:
            idx = int(raw) - 1
            return entries[idx] if 0 <= idx < len(entries) else None
        except ValueError:
            return None

    cursor = 0
    console.print("[dim]↑/↓ or j/k to move · Enter to select · q/Esc to cancel[/dim]")
    # auto_refresh=False: we drive the update manually after each key
    # press. With auto_refresh=True (the old default) rich redraws 30
    # times a second, and in any environment that lacks proper cursor
    # control it reprints the whole table each tick — the "Model
    # Quant Size" header ends up scrolling forever.
    with Live(
        _render(entries, cursor),
        console=console,
        auto_refresh=False,
        transient=True,
    ) as live:
        while True:
            key = _read_key()
            if key in ("\x1b[A", "k"):
                cursor = (cursor - 1) % len(entries)
            elif key in ("\x1b[B", "j"):
                cursor = (cursor + 1) % len(entries)
            elif key in ("\r", "\n"):
                return entries[cursor]
            elif key in ("q", "\x1b", "\x03"):
                return None
            live.update(_render(entries, cursor), refresh=True)
