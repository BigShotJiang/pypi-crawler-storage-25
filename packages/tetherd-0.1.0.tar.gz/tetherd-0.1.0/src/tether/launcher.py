from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

from tether.proxy import MODEL_ALIAS, build_server

READINESS_TIMEOUT_S = 120.0
READINESS_INTERVAL_S = 0.2


def _probe_ready(host: str, port: int, timeout: float) -> bool:
    url = f"http://{host}:{port}/health/readiness"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=1) as resp:
                if resp.status == 200:
                    return True
        except (urllib.error.URLError, ConnectionError, OSError):
            pass
        time.sleep(READINESS_INTERVAL_S)
    return False


def _child_env(host: str, port: int) -> dict[str, str]:
    env = dict(os.environ)
    env.update(
        {
            "ANTHROPIC_BASE_URL": f"http://{host}:{port}",
            "ANTHROPIC_API_KEY": MODEL_ALIAS,
            "ANTHROPIC_AUTH_TOKEN": MODEL_ALIAS,
            "ANTHROPIC_DEFAULT_OPUS_MODEL": MODEL_ALIAS,
            "ANTHROPIC_DEFAULT_SONNET_MODEL": MODEL_ALIAS,
            "ANTHROPIC_DEFAULT_HAIKU_MODEL": MODEL_ALIAS,
            "CLAUDE_CODE_SUBAGENT_MODEL": MODEL_ALIAS,
            "CLAUDE_CODE_ATTRIBUTION_HEADER": "0",
        }
    )
    return env


def launch_claude(
    model_path: str,
    host: str,
    port: int,
    claude_path: str | None,
    extra_args: list[str],
    log_level: str = "warning",
    memory_cap_bytes: int | None = None,
    max_context: int | None = None,
) -> int:
    resolved_claude = claude_path or shutil.which("claude")
    if not resolved_claude:
        print(
            "[tether] `claude` not found on PATH. Install Claude Code "
            "(https://claude.com/claude-code) or pass --claude-path, or run "
            "with --serve-only to start just the proxy.",
            file=sys.stderr,
        )
        return 127

    server = build_server(
        model_path,
        host,
        port,
        log_level=log_level,
        memory_cap_bytes=memory_cap_bytes,
        max_context=max_context,
    )

    thread_error: dict[str, BaseException] = {}

    def _run_server():
        try:
            server.run()
        except BaseException as exc:  # noqa: BLE001
            thread_error["err"] = exc

    thread = threading.Thread(target=_run_server, name="mlx-proxy", daemon=True)
    print(
        f"[tether] loading model and starting proxy on "
        f"http://{host}:{port} ...",
        flush=True,
    )
    thread.start()

    if not _probe_ready(host, port, READINESS_TIMEOUT_S):
        server.should_exit = True
        thread.join(timeout=5)
        if "err" in thread_error:
            print(
                f"[tether] proxy failed to start: {thread_error['err']!r}",
                file=sys.stderr,
            )
        else:
            print(
                "[tether] proxy did not become ready within "
                f"{READINESS_TIMEOUT_S:.0f}s",
                file=sys.stderr,
            )
        return 1

    print(
        f"[tether] proxy ready; launching claude ({resolved_claude})",
        flush=True,
    )

    env = _child_env(host, port)
    try:
        proc = subprocess.Popen(
            [resolved_claude, *extra_args],
            env=env,
            stdin=None,
            stdout=None,
            stderr=None,
        )
    except FileNotFoundError:
        print(
            f"[tether] could not execute {resolved_claude}",
            file=sys.stderr,
        )
        server.should_exit = True
        thread.join(timeout=5)
        return 127

    exit_code = 0
    try:
        exit_code = proc.wait()
    except KeyboardInterrupt:
        try:
            proc.send_signal(signal.SIGINT)
            exit_code = proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            exit_code = proc.wait()
    finally:
        server.should_exit = True
        thread.join(timeout=5)

    return exit_code
