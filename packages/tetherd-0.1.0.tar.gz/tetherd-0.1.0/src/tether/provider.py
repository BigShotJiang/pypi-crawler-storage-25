from __future__ import annotations

import json
import os
import sys
import threading
import time
from typing import Any, AsyncIterator, Iterator

from litellm import CustomLLM
from litellm.types.utils import (
    ChatCompletionMessageToolCall,
    Function,
    GenericStreamingChunk,
    ModelResponse,
)
from mlx_vlm import PromptCacheState

from tether.tools import (
    GemmaToolCallParser,
    anthropic_to_gemma_messages,
    openai_tools_for_template,
    parse_gemma_output,
)

# MLX / Metal is not safe for concurrent graph execution on the same
# model — two overlapping generations can trigger
# "Completed handler provided after commit call" aborts in the Metal
# command queue. Serialize all generation through this lock. One-user
# local server, so the extra latency is a non-issue.
_MLX_LOCK = threading.Lock()

# Single shared KV-cache for the loaded model. Claude Code runs one
# session at a time; reusing its stable system + tool prefix across
# turns is the whole point. mlx_vlm auto-trims the cache to the
# matched prefix on every call, so we don't need per-session state.
_PROMPT_CACHE = PromptCacheState()

_DEBUG = os.environ.get("TETHER_DEBUG") == "1"


def _log_cache_hit(processor, prompt: str) -> None:
    """Only called under TETHER_DEBUG=1. Tokenizes the prompt once
    for diagnostics; mlx_vlm's hot path does its own tokenization so
    this is debug-only overhead."""
    if _PROMPT_CACHE.token_ids is None:
        print("[tether DEBUG] prompt cache: empty (cold start)", file=sys.stderr, flush=True)
        return
    try:
        tok = getattr(processor, "tokenizer", processor)
        ids = tok(prompt, add_special_tokens=False)["input_ids"]
        if isinstance(ids[0], list):
            ids = ids[0]
        total = len(ids)
        prefix = _PROMPT_CACHE.find_prefix_length(list(ids))
        print(
            f"[tether DEBUG] prompt cache hit: {prefix}/{total} tokens"
            f" ({prefix * 100 // max(total, 1)}% reuse)",
            file=sys.stderr,
            flush=True,
        )
    except Exception as exc:
        print(f"[tether DEBUG] prompt cache probe failed: {exc}", file=sys.stderr, flush=True)


def _debug_dump_request(tag: str, messages: list, optional_params: dict) -> None:
    if not _DEBUG:
        return
    payload = {
        "tag": tag,
        "messages": messages,
        "tools": (optional_params or {}).get("tools"),
        "tool_choice": (optional_params or {}).get("tool_choice"),
        "max_tokens": (optional_params or {}).get("max_tokens"),
        "temperature": (optional_params or {}).get("temperature"),
    }
    try:
        line = json.dumps(payload, default=str)
    except Exception as exc:
        line = f"<unserializable: {exc}>"
    print(f"[tether DEBUG] {line}", file=sys.stderr, flush=True)


def _count_tokens(tok, text: str) -> int:
    try:
        ids = tok(text, add_special_tokens=False)["input_ids"]
    except Exception:
        return len(text) // 4  # rough char-to-token fallback
    if ids and isinstance(ids[0], list):
        ids = ids[0]
    return len(ids)


def _render_prompt(
    processor,
    config,
    messages: list[dict],
    tools: list[dict] | None,
) -> str:
    # Use the inner HF tokenizer's apply_chat_template directly. Going
    # through mlx_vlm.apply_chat_template re-wraps our flat string
    # content into a multimodal {"type":"text","text":...} list, and
    # Gemma 4's Jinja chat template has no case for that shape, so it
    # falls back to `{{ content }}` and emits a Python repr of the list.
    cleaned = anthropic_to_gemma_messages(messages)
    tok = getattr(processor, "tokenizer", processor)

    def _render(msgs: list[dict]) -> str:
        kwargs: dict[str, Any] = {
            "add_generation_prompt": True,
            "tokenize": False,
        }
        if tools:
            kwargs["tools"] = tools
        if not hasattr(tok, "apply_chat_template"):
            parts = [
                f"<{m.get('role','user')}>\n{m.get('content','')}\n</{m.get('role','user')}>"
                for m in msgs
            ]
            parts.append("<assistant>\n")
            return "\n".join(parts)
        return tok.apply_chat_template(msgs, **kwargs)

    rendered = _render(cleaned)

    max_ctx_env = os.environ.get("TETHER_MAX_CONTEXT")
    if not max_ctx_env:
        return rendered
    try:
        max_ctx = int(max_ctx_env)
    except ValueError:
        return rendered
    if max_ctx <= 0:
        return rendered

    token_count = _count_tokens(tok, rendered)
    if token_count <= max_ctx:
        return rendered

    # Truncate from the oldest non-system message until we fit. System
    # messages (and any leading non-user/assistant turn LiteLLM might
    # forward) stay — they carry the stable tool context the prompt
    # cache is built around.
    head: list[dict] = []
    tail: list[dict] = []
    for m in cleaned:
        if not head and m.get("role") in ("system",):
            head.append(m)
        else:
            tail.append(m)

    original_dropped = 0
    while tail and token_count > max_ctx:
        tail.pop(0)
        original_dropped += 1
        rendered = _render(head + tail)
        token_count = _count_tokens(tok, rendered)

    if original_dropped:
        print(
            f"[tether] context cap {max_ctx} reached; dropped "
            f"{original_dropped} oldest message(s); now {token_count} tokens",
            file=sys.stderr,
            flush=True,
        )
    return rendered


def _max_tokens(optional_params: dict[str, Any] | None) -> int:
    if not optional_params:
        return 1024
    v = optional_params.get("max_tokens") or optional_params.get(
        "max_completion_tokens"
    )
    return int(v) if v else 1024


def _make_tool_use_chunks(tool_call, index: int) -> list[GenericStreamingChunk]:
    """Emit a tool call as two streaming chunks.

    LiteLLM's OpenAI→Anthropic streaming adapter distinguishes:
      - A chunk with tool_calls[0].function.name → content_block_start
        (type: tool_use, id, name, input: {})
      - A chunk with tool_calls[0].function.arguments (and empty name) →
        content_block_delta (type: input_json_delta, partial_json: …)
    We emit one of each, in order. Following Ollama, we send the whole
    JSON as a single partial_json delta rather than streaming it.
    """
    args_json = json.dumps(tool_call.arguments)
    start = GenericStreamingChunk(
        text="",
        is_finished=False,
        finish_reason="",
        usage=None,
        index=index,
        tool_use={
            "id": tool_call.id,
            "type": "function",
            "function": {"name": tool_call.name, "arguments": ""},
            "index": index,
        },
    )
    delta = GenericStreamingChunk(
        text="",
        is_finished=False,
        finish_reason="",
        usage=None,
        index=index,
        tool_use={
            "id": tool_call.id,
            "type": "function",
            "function": {"name": "", "arguments": args_json},
            "index": index,
        },
    )
    return [start, delta]


def _sampling_kwargs(optional_params: dict[str, Any] | None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    if not optional_params:
        return out
    for src, dst in (
        ("temperature", "temperature"),
        ("top_p", "top_p"),
        ("repetition_penalty", "repetition_penalty"),
    ):
        if optional_params.get(src) is not None:
            out[dst] = optional_params[src]
    return out


class MLXProvider(CustomLLM):
    def __init__(self, model_path: str):
        super().__init__()
        self.model_path = model_path
        self._model = None
        self._processor = None

    def _ensure_loaded(self):
        if self._model is None:
            with _MLX_LOCK:
                if self._model is None:
                    import mlx.core as mx
                    import mlx_vlm

                    # Apply memory cap BEFORE loading weights so the cap
                    # gets enforced on the load itself, not only on
                    # subsequent allocations. Users who misconfigure
                    # (e.g. cap below weight size) see a clean error at
                    # startup instead of a hang mid-conversation.
                    cap = os.environ.get("TETHER_MEMORY_CAP")
                    if cap:
                        cap_bytes = int(cap)
                        prev = mx.set_memory_limit(cap_bytes)
                        gb = cap_bytes / 1024**3
                        print(
                            f"[tether] memory cap: {gb:.1f} GiB "
                            f"(was {prev / 1024**3:.1f} GiB)",
                            flush=True,
                        )

                    print(
                        f"[tether] loading model: {self.model_path}",
                        flush=True,
                    )
                    self._model, self._processor = mlx_vlm.load(self.model_path)
                    # Fresh cache per loaded model. No-op on cold start;
                    # matters only if we ever hot-swap models in v1.1.
                    global _PROMPT_CACHE
                    _PROMPT_CACHE = PromptCacheState()
                    print("[tether] model ready", flush=True)

    def _config(self):
        return getattr(self._model, "config", None)

    def completion(
        self,
        model: str,
        messages: list,
        api_base: str,
        custom_prompt_dict: dict,
        model_response: ModelResponse,
        print_verbose,
        encoding,
        api_key,
        logging_obj,
        optional_params: dict,
        acompletion=None,
        litellm_params=None,
        logger_fn=None,
        headers=None,
        timeout=None,
        client=None,
    ) -> ModelResponse:
        import mlx_vlm

        self._ensure_loaded()
        _debug_dump_request("completion", messages, optional_params)
        tools = openai_tools_for_template((optional_params or {}).get("tools"))
        prompt = _render_prompt(self._processor, self._config(), messages, tools)
        if _DEBUG:
            print(
                f"[tether DEBUG] rendered prompt ({len(prompt)} chars):\n{prompt}",
                file=sys.stderr,
                flush=True,
            )
            _log_cache_hit(self._processor, prompt)
        with _MLX_LOCK:
            result = mlx_vlm.generate(
                self._model,
                self._processor,
                prompt=prompt,
                max_tokens=_max_tokens(optional_params),
                verbose=False,
                prompt_cache_state=_PROMPT_CACHE,
                **_sampling_kwargs(optional_params),
            )
        raw = getattr(result, "text", None)
        if raw is None:
            raw = str(result)
        if _DEBUG:
            print(
                f"[tether DEBUG] raw output ({len(raw)} chars):\n{raw}",
                file=sys.stderr,
                flush=True,
            )
        text, tool_calls = parse_gemma_output(raw)
        model_response.created = int(time.time())
        model_response.model = model or self.model_path
        msg = model_response.choices[0].message  # type: ignore[attr-defined]
        msg.content = text or None
        if tool_calls:
            msg.tool_calls = [
                ChatCompletionMessageToolCall(
                    id=tc.id,
                    type="function",
                    function=Function(
                        name=tc.name,
                        arguments=json.dumps(tc.arguments),
                    ),
                )
                for tc in tool_calls
            ]
            model_response.choices[0].finish_reason = "tool_calls"  # type: ignore[attr-defined]
        else:
            model_response.choices[0].finish_reason = "stop"  # type: ignore[attr-defined]
        return model_response

    def streaming(
        self,
        model: str,
        messages: list,
        api_base: str,
        custom_prompt_dict: dict,
        model_response: ModelResponse,
        print_verbose,
        encoding,
        api_key,
        logging_obj,
        optional_params: dict,
        acompletion=None,
        litellm_params=None,
        logger_fn=None,
        headers=None,
        timeout=None,
        client=None,
    ) -> Iterator[GenericStreamingChunk]:
        import mlx_vlm

        self._ensure_loaded()
        _debug_dump_request("streaming", messages, optional_params)
        tools = openai_tools_for_template((optional_params or {}).get("tools"))
        prompt = _render_prompt(self._processor, self._config(), messages, tools)
        if _DEBUG:
            print(
                f"[tether DEBUG] rendered prompt ({len(prompt)} chars):\n{prompt}",
                file=sys.stderr,
                flush=True,
            )
            _log_cache_hit(self._processor, prompt)
        parser = GemmaToolCallParser()
        tool_index = 0
        saw_tool_call = False
        # Hold the lock for the entire stream so no other generation
        # interleaves Metal command-buffer ops on this model.
        with _MLX_LOCK:
            for chunk in mlx_vlm.stream_generate(
                self._model,
                self._processor,
                prompt=prompt,
                max_tokens=_max_tokens(optional_params),
                prompt_cache_state=_PROMPT_CACHE,
                **_sampling_kwargs(optional_params),
            ):
                piece = getattr(chunk, "text", None)
                if piece is None:
                    piece = str(chunk)
                if not piece:
                    continue
                for ev in parser.feed(piece):
                    if ev.kind == "text" and ev.text:
                        yield GenericStreamingChunk(
                            text=ev.text,
                            is_finished=False,
                            finish_reason="",
                            usage=None,
                            index=0,
                            tool_use=None,
                        )
                    elif ev.kind == "tool_call" and ev.tool_call is not None:
                        saw_tool_call = True
                        for out in _make_tool_use_chunks(ev.tool_call, tool_index):
                            yield out
                        tool_index += 1
        for ev in parser.flush():
            if ev.kind == "text" and ev.text:
                yield GenericStreamingChunk(
                    text=ev.text,
                    is_finished=False,
                    finish_reason="",
                    usage=None,
                    index=0,
                    tool_use=None,
                )
            elif ev.kind == "tool_call" and ev.tool_call is not None:
                saw_tool_call = True
                for out in _make_tool_use_chunks(ev.tool_call, tool_index):
                    yield out
                tool_index += 1
        yield GenericStreamingChunk(
            text="",
            is_finished=True,
            finish_reason="tool_calls" if saw_tool_call else "stop",
            usage=None,
            index=0,
            tool_use=None,
        )

    async def acompletion(self, *args, **kwargs) -> ModelResponse:
        import anyio

        return await anyio.to_thread.run_sync(
            lambda: self.completion(*args, **kwargs)
        )

    async def astreaming(self, *args, **kwargs) -> AsyncIterator[GenericStreamingChunk]:
        import anyio

        send, receive = anyio.create_memory_object_stream(max_buffer_size=64)

        async def _produce():
            def _run():
                try:
                    for c in self.streaming(*args, **kwargs):
                        from anyio.from_thread import run as _r
                        _r(send.send, c)
                finally:
                    from anyio.from_thread import run as _r
                    _r(send.aclose)

            await anyio.to_thread.run_sync(_run)

        async with anyio.create_task_group() as tg:
            tg.start_soon(_produce)
            async with receive:
                async for item in receive:
                    yield item
