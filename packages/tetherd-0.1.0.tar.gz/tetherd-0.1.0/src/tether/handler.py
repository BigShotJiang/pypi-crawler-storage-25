from __future__ import annotations

import os

from tether.provider import MLXProvider

_MODEL_PATH = os.environ.get("TETHER_MODEL_PATH")
if not _MODEL_PATH:
    raise RuntimeError(
        "TETHER_MODEL_PATH must be set before importing tether.handler"
    )

handler = MLXProvider(_MODEL_PATH)
