"""Translate LiteLLM/Anthropic-shaped messages into the structure Gemma 4's
chat template consumes.

Gemma 4's Jinja chat template accepts:
  - role="system"/"user"/"assistant" with string content
  - role="assistant" with a `tool_calls` field shaped like OpenAI
    ({id, type: "function", function: {name, arguments: <json-string>}})
  - role="assistant" with a `tool_responses` field — Gemma-specific, a
    list of {name, response} pairs that map back to earlier tool calls

LiteLLM hands us messages in OpenAI shape (it has already translated
Anthropic /v1/messages wire format). The things we still have to fix:
  - Flatten list-of-text-blocks content into a single string.
  - Fold role="tool" messages (OpenAI-style tool results) into
    assistant-with-tool_responses messages matching the previous
    assistant's tool_calls by tool_call_id, because Gemma's template
    does not have a "tool" role.
  - Normalize assistant tool_calls whose arguments came in as a dict
    instead of a JSON string.
"""

from __future__ import annotations

import json
from typing import Any


def _flatten_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                t = item.get("type")
                if t in (None, "text"):
                    parts.append(item.get("text", ""))
                elif t == "tool_result":
                    # Anthropic tool_result block sneaking through; caller
                    # handles those separately, but if we see one here
                    # just stringify the inner content.
                    parts.append(_flatten_content(item.get("content")))
        return "".join(parts)
    return str(content)


def _normalize_tool_calls(raw: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if not raw:
        return out
    for tc in raw:
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function") or {}
        name = fn.get("name") or tc.get("name") or ""
        args = fn.get("arguments")
        if args is None:
            args = tc.get("arguments")
        # Gemma's template calls `tool_call['function']['arguments']` and
        # expects it to be a JSON string that it can re-parse. Normalize
        # dict → JSON string.
        if isinstance(args, (dict, list)):
            args_str = json.dumps(args)
        elif isinstance(args, str):
            args_str = args
        else:
            args_str = "{}"
        out.append(
            {
                "id": tc.get("id") or f"call_{len(out)}",
                "type": "function",
                "function": {"name": name, "arguments": args_str},
            }
        )
    return out


def _lookup_tool_name(prior: list[dict[str, Any]], tool_call_id: str) -> str:
    for msg in reversed(prior):
        for tc in msg.get("tool_calls") or []:
            if tc.get("id") == tool_call_id:
                return (tc.get("function") or {}).get("name") or "unknown"
    return "unknown"


def anthropic_to_gemma_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Produce a message list that Gemma 4's chat template accepts.

    Input: OpenAI-shaped messages (what LiteLLM passes to our custom
    provider). Content blocks may be strings or list-of-text/tool_result
    items. Assistant messages may carry `tool_calls`. Tool result turns
    arrive as `role: "tool"` with a `tool_call_id`.

    Output: The same messages with content flattened to strings, any
    consecutive `role: "tool"` messages folded into the immediately
    preceding assistant turn as `tool_responses` entries.
    """
    out: list[dict[str, Any]] = []
    for msg in messages:
        role = msg.get("role", "user")

        if role == "tool":
            # Gemma has no "tool" role. Attach as tool_responses on the
            # preceding assistant turn (creating one if necessary so the
            # template sees the pairing).
            name = msg.get("name") or _lookup_tool_name(
                out, msg.get("tool_call_id", "")
            )
            response_text = _flatten_content(msg.get("content"))
            response_obj: Any
            # Gemma renders `response` as a mapping via tojson if it's a
            # dict, otherwise as a literal. Prefer to parse JSON strings
            # back into dicts so the template's mapping branch kicks in.
            try:
                response_obj = json.loads(response_text)
                if not isinstance(response_obj, dict):
                    response_obj = {"result": response_obj}
            except (ValueError, TypeError):
                response_obj = {"result": response_text}

            entry = {"name": name, "response": response_obj}

            if (
                out
                and out[-1].get("role") == "assistant"
                and out[-1].get("_gemma_response_carrier")
            ):
                out[-1].setdefault("tool_responses", []).append(entry)
            else:
                out.append(
                    {
                        "role": "assistant",
                        "tool_responses": [entry],
                        "_gemma_response_carrier": True,
                    }
                )
            continue

        flat: dict[str, Any] = {"role": role}
        content = _flatten_content(msg.get("content"))
        if content:
            flat["content"] = content

        if role == "assistant":
            tool_calls = _normalize_tool_calls(msg.get("tool_calls"))
            if tool_calls:
                flat["tool_calls"] = tool_calls

        # Drop empty assistant messages that carry neither text nor
        # tool_calls — those are usually placeholder entries LiteLLM
        # leaves behind.
        if (
            role == "assistant"
            and "content" not in flat
            and "tool_calls" not in flat
        ):
            continue

        out.append(flat)

    # Clean up the private carrier flag before handing to the template.
    for m in out:
        m.pop("_gemma_response_carrier", None)

    return out


def openai_tools_for_template(
    tools: list[dict[str, Any]] | None,
) -> list[dict[str, Any]] | None:
    """Normalize the `tools` array LiteLLM passes in optional_params.

    Gemma 4's template expects each entry shaped like OpenAI's function
    tools: {type: "function", function: {name, description, parameters}}.
    LiteLLM already hands us this shape, but we defensively filter out
    anything that isn't a function-type entry.
    """
    if not tools:
        return None
    clean: list[dict[str, Any]] = []
    for t in tools:
        if not isinstance(t, dict):
            continue
        if t.get("type") and t["type"] != "function":
            continue
        fn = t.get("function")
        if not isinstance(fn, dict) or not fn.get("name"):
            continue
        clean.append({"type": "function", "function": fn})
    return clean or None
