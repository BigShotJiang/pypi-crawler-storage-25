"""Gemma 4 tool-call DSL parser.

Gemma 4's Jinja chat template emits tool calls as a pseudo-JSON DSL:

    <|tool_call>call:Write{content:<|"|>print("hi")<|"|>,file_path:<|"|>/tmp/x.py<|"|>}<tool_call|>

Rules (empirically confirmed against mlx-community/gemma-4-e2b-it-4bit):

  - Open marker is the literal six-character token `<|tool_call>` followed
    by `call:` and then a bare function-name identifier up to `{`.
  - Close marker is the literal six-character token `<tool_call|>`.
  - String values are wrapped in `<|"|>...<|"|>`. Bare `"` chars inside
    the string are NOT escaped — parsing must match the full `<|"|>`
    terminator token and never react to a plain `"`.
  - Object keys are bare identifiers (no quotes).
  - Value types: string (`<|"|>...<|"|>`), number, `true`, `false`,
    `null`, object `{...}`, array `[...]`.
  - Multiple tool calls in one turn are allowed, back-to-back.

This module exposes:

  * `parse_gemma_output(text) -> (plain_text, tool_calls)` for the
    non-streaming path, where the full model output is available at
    once.
  * `GemmaToolCallParser` for the streaming path, fed one delta at a
    time, yielding `ToolParserEvent(kind="text"|"tool_call", …)`.

Both paths share the same low-level DSL value parser in `_parse_value`.
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass, field
from typing import Any, Iterator, Literal

TOOL_OPEN = "<|tool_call>"
TOOL_CLOSE = "<tool_call|>"
STR_DELIM = '<|"|>'
CALL_PREFIX = "call:"


@dataclass
class ParsedToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ToolParserEvent:
    kind: Literal["text", "tool_call"]
    text: str = ""
    tool_call: ParsedToolCall | None = None


# ------------- low-level DSL value parser -----------------------------

_IDENT_RE = re.compile(r"[A-Za-z_][A-Za-z_0-9\-]*")
_NUM_RE = re.compile(r"-?\d+(\.\d+)?([eE][+-]?\d+)?")


class _Cursor:
    __slots__ = ("s", "i")

    def __init__(self, s: str, i: int = 0):
        self.s = s
        self.i = i

    def peek(self, n: int = 1) -> str:
        return self.s[self.i : self.i + n]

    def at(self, token: str) -> bool:
        return self.s.startswith(token, self.i)

    def consume(self, token: str) -> bool:
        if self.at(token):
            self.i += len(token)
            return True
        return False

    def skip_ws(self) -> None:
        while self.i < len(self.s) and self.s[self.i] in " \t\r\n":
            self.i += 1


class GemmaDSLError(ValueError):
    pass


def _parse_value(c: _Cursor) -> Any:
    c.skip_ws()
    if c.i >= len(c.s):
        raise GemmaDSLError("unexpected end of DSL value")

    if c.at(STR_DELIM):
        return _parse_string(c)
    if c.peek() == "{":
        return _parse_object(c)
    if c.peek() == "[":
        return _parse_array(c)
    return _parse_scalar(c)


def _parse_string(c: _Cursor) -> str:
    if not c.consume(STR_DELIM):
        raise GemmaDSLError(f"expected {STR_DELIM!r} at {c.i}")
    end = c.s.find(STR_DELIM, c.i)
    if end == -1:
        raise GemmaDSLError("unterminated string")
    value = c.s[c.i : end]
    c.i = end + len(STR_DELIM)
    return value


def _parse_object(c: _Cursor) -> dict[str, Any]:
    if not c.consume("{"):
        raise GemmaDSLError(f"expected '{{' at {c.i}")
    out: dict[str, Any] = {}
    c.skip_ws()
    if c.consume("}"):
        return out
    while True:
        c.skip_ws()
        key = _parse_key(c)
        c.skip_ws()
        if not c.consume(":"):
            raise GemmaDSLError(f"expected ':' after key {key!r} at {c.i}")
        value = _parse_value(c)
        out[key] = value
        c.skip_ws()
        if c.consume(","):
            continue
        if c.consume("}"):
            return out
        raise GemmaDSLError(f"expected ',' or '}}' at {c.i}")


def _parse_array(c: _Cursor) -> list[Any]:
    if not c.consume("["):
        raise GemmaDSLError(f"expected '[' at {c.i}")
    out: list[Any] = []
    c.skip_ws()
    if c.consume("]"):
        return out
    while True:
        out.append(_parse_value(c))
        c.skip_ws()
        if c.consume(","):
            continue
        if c.consume("]"):
            return out
        raise GemmaDSLError(f"expected ',' or ']' at {c.i}")


def _parse_key(c: _Cursor) -> str:
    # Keys are bare identifiers. Some models may also emit quoted keys;
    # accept both defensively.
    if c.at(STR_DELIM):
        return _parse_string(c)
    m = _IDENT_RE.match(c.s, c.i)
    if not m:
        raise GemmaDSLError(f"expected identifier at {c.i}")
    c.i = m.end()
    return m.group(0)


def _parse_scalar(c: _Cursor) -> Any:
    if c.consume("true"):
        return True
    if c.consume("false"):
        return False
    if c.consume("null"):
        return None
    m = _NUM_RE.match(c.s, c.i)
    if m:
        c.i = m.end()
        raw = m.group(0)
        return float(raw) if "." in raw or "e" in raw or "E" in raw else int(raw)
    # Fallback: bare identifier (enum-like) — return as string.
    m = _IDENT_RE.match(c.s, c.i)
    if m:
        c.i = m.end()
        return m.group(0)
    raise GemmaDSLError(f"unrecognized scalar at {c.i}")


def _parse_call_body(body: str) -> ParsedToolCall:
    """Parse the interior of one <|tool_call>call:…<tool_call|> block.

    `body` starts with the function name (after CALL_PREFIX) and ends
    just before TOOL_CLOSE. Two formats seen in the wild:

      * Gemma DSL: `Write{content:<|"|>hi<|"|>,file_path:<|"|>/x<|"|>}`
      * Real JSON: `AskUserQuestion{"questions": [{"question": "..."}]}`

    The model picks JSON when its arguments have deeply nested schemas
    (e.g. AskUserQuestion) — it evidently falls back to the more
    familiar format from pretraining. We support both: try json.loads
    on the {...} portion first, and fall back to the DSL parser.
    """
    c = _Cursor(body)
    c.skip_ws()
    m = _IDENT_RE.match(body, c.i)
    if not m:
        raise GemmaDSLError("missing tool name")
    name = m.group(0)
    c.i = m.end()
    c.skip_ws()
    if not c.at("{"):
        raise GemmaDSLError(f"expected '{{' after tool name, got {body[c.i:c.i+10]!r}")
    rest = body[c.i:].strip()

    # Format A: real JSON. Fast path for models that abandon the DSL.
    try:
        args = json.loads(rest)
        if isinstance(args, dict):
            return ParsedToolCall(
                id=f"toolu_{uuid.uuid4().hex[:16]}",
                name=name,
                arguments=args,
            )
    except (json.JSONDecodeError, ValueError):
        pass

    # Format B: Gemma's pseudo-JSON DSL. This is what
    # `apply_chat_template(tools=…)` advertises, so it's still the
    # common case for simple tool schemas.
    args = _parse_object(c)
    return ParsedToolCall(
        id=f"toolu_{uuid.uuid4().hex[:16]}",
        name=name,
        arguments=args,
    )


# ------------- non-streaming parse ------------------------------------


def parse_gemma_output(text: str) -> tuple[str, list[ParsedToolCall]]:
    """Split model output into plain text and parsed tool calls.

    On malformed DSL, the offending `<|tool_call>…<tool_call|>` block
    is left inline in the returned text (so the user still sees
    something) and the block is not emitted as a tool call.
    """
    plain: list[str] = []
    calls: list[ParsedToolCall] = []
    i = 0
    n = len(text)
    while i < n:
        start = text.find(TOOL_OPEN, i)
        if start == -1:
            plain.append(text[i:])
            break
        if start > i:
            plain.append(text[i:start])
        end = text.find(TOOL_CLOSE, start + len(TOOL_OPEN))
        if end == -1:
            # Unterminated; the rest is unparseable, leave as plain text.
            plain.append(text[start:])
            break
        inner = text[start + len(TOOL_OPEN) : end]
        if not inner.startswith(CALL_PREFIX):
            plain.append(text[start : end + len(TOOL_CLOSE)])
            i = end + len(TOOL_CLOSE)
            continue
        body = inner[len(CALL_PREFIX) :]
        try:
            calls.append(_parse_call_body(body))
        except GemmaDSLError:
            plain.append(text[start : end + len(TOOL_CLOSE)])
        i = end + len(TOOL_CLOSE)
    return "".join(plain), calls


# ------------- streaming parser ---------------------------------------


@dataclass
class GemmaToolCallParser:
    """Stateful parser fed one text delta at a time.

    Call `.feed(delta) -> list[ToolParserEvent]` for each chunk from
    `mlx_vlm.stream_generate`, then `.flush() -> list[ToolParserEvent]`
    at end-of-stream to drain any buffered plain text.

    The parser operates in two states:
      * IDLE: scanning for TOOL_OPEN. Any text that cannot possibly be
        the start of TOOL_OPEN is emitted immediately as a text event.
        Text that might be the prefix of TOOL_OPEN is buffered.
      * INSIDE: buffering the interior of a tool call until TOOL_CLOSE
        arrives, then parsing and emitting a tool_call event.
    """

    _buf: str = ""
    _state: Literal["idle", "inside"] = "idle"

    def feed(self, delta: str) -> list[ToolParserEvent]:
        events: list[ToolParserEvent] = []
        self._buf += delta

        while True:
            if self._state == "idle":
                start = self._buf.find(TOOL_OPEN)
                if start >= 0:
                    # Flush any text before the open marker.
                    if start > 0:
                        events.append(
                            ToolParserEvent(kind="text", text=self._buf[:start])
                        )
                    # Transition into INSIDE; drop the open marker itself.
                    self._buf = self._buf[start + len(TOOL_OPEN) :]
                    self._state = "inside"
                    continue
                # No open marker. We can safely emit everything except
                # the last (len(TOOL_OPEN) - 1) chars, which might be a
                # partial marker.
                emit_until = max(0, len(self._buf) - (len(TOOL_OPEN) - 1))
                # Tighten emit_until: find the earliest potential
                # prefix of TOOL_OPEN in the tail so we don't emit its
                # leading bytes.
                tail_start = emit_until
                for k in range(emit_until, len(self._buf)):
                    if TOOL_OPEN.startswith(self._buf[k:]):
                        tail_start = k
                        break
                else:
                    tail_start = len(self._buf)
                if tail_start > 0:
                    events.append(
                        ToolParserEvent(kind="text", text=self._buf[:tail_start])
                    )
                    self._buf = self._buf[tail_start:]
                return events

            # INSIDE
            end = self._buf.find(TOOL_CLOSE)
            if end == -1:
                # Need more data.
                return events
            inner = self._buf[:end]
            self._buf = self._buf[end + len(TOOL_CLOSE) :]
            self._state = "idle"
            if inner.startswith(CALL_PREFIX):
                try:
                    call = _parse_call_body(inner[len(CALL_PREFIX) :])
                    events.append(ToolParserEvent(kind="tool_call", tool_call=call))
                except GemmaDSLError:
                    # Malformed. Surface as plain text so the user at
                    # least sees what the model tried to say.
                    events.append(
                        ToolParserEvent(
                            kind="text",
                            text=TOOL_OPEN + inner + TOOL_CLOSE,
                        )
                    )
            else:
                events.append(
                    ToolParserEvent(
                        kind="text",
                        text=TOOL_OPEN + inner + TOOL_CLOSE,
                    )
                )

    def flush(self) -> list[ToolParserEvent]:
        events: list[ToolParserEvent] = []
        if self._buf:
            if self._state == "inside":
                # Unterminated tool call at end of stream: treat as text.
                events.append(
                    ToolParserEvent(kind="text", text=TOOL_OPEN + self._buf)
                )
            else:
                events.append(ToolParserEvent(kind="text", text=self._buf))
            self._buf = ""
        return events
