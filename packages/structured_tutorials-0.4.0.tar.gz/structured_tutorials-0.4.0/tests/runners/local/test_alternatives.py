# Copyright (c) 2025 Mathias Ertl
# Licensed under the MIT License. See LICENSE file for details.

"""Test alternatives."""

import os
from pathlib import Path
from unittest import mock

import pytest
from pytest_subprocess import FakeProcess

from structured_tutorials.errors import InvalidAlternativesSelectedError
from structured_tutorials.models import TutorialModel
from structured_tutorials.runners.local import LocalTutorialRunner


@pytest.mark.tutorial("alternatives")
def test_alternatives(fp: FakeProcess, tutorial: TutorialModel) -> None:
    """Run a tutorial with alternatives."""
    fp.register("ls foo")
    runner = LocalTutorialRunner(tutorial, alternatives=("foo",))
    runner.run()

    fp.register("ls bar")
    runner = LocalTutorialRunner(tutorial, alternatives=("bar",))
    runner.run()


@pytest.mark.tutorial("alternatives-files")
def test_alternatives_with_file_part(tmp_path: Path, tutorial: TutorialModel) -> None:
    """Run a tutorial with alternatives containing files."""
    runner = LocalTutorialRunner(tutorial, alternatives=("foo",))
    runner.context["tmp_path"] = tmp_path
    runner.run()
    assert (tmp_path / "foo.txt").exists()

    runner = LocalTutorialRunner(tutorial, alternatives=("bar",))
    runner.context["tmp_path"] = tmp_path
    runner.run()
    assert (tmp_path / "bar.txt").exists()


@pytest.mark.tutorial("alternatives")
def test_alternatives_with_no_selected_part(tutorial: TutorialModel) -> None:
    """Run with an alternative that does not exist."""
    runner = LocalTutorialRunner(tutorial, alternatives=("bla",))
    with pytest.raises(InvalidAlternativesSelectedError):
        runner.validate_alternatives()
    # Running the tutorial itself does not check if an alternative is selected.
    runner.run()


@pytest.mark.tutorial("alternatives-chdir")
@pytest.mark.parametrize("alternative", ("foo", "bar"))
def test_alternatives_with_chdir(fp: FakeProcess, tutorial: TutorialModel, alternative: str) -> None:
    """Run with an alternative that calls chdir."""
    fp.register(f"ls {alternative}")
    fp.register("ls")
    runner = LocalTutorialRunner(tutorial, alternatives=(alternative,))
    with mock.patch("os.chdir", autospec=True) as mock_chdir:
        runner.run()
    mock_chdir.assert_called_once_with(f"/{alternative}")


@pytest.mark.doc_tutorial("alternatives-chdir-at-top-level")
@pytest.mark.parametrize("alternative", ("foo", "bar"))
def test_alternatives_with_toplevel_chdir(
    fp: FakeProcess, doc_tutorial: TutorialModel, alternative: str
) -> None:
    """Run with an alternative that calls chdir."""
    fp.register(f"cd /{alternative}")
    fp.register(f"echo {alternative}")
    fp.register("ls")
    runner = LocalTutorialRunner(doc_tutorial, alternatives=(alternative,))
    with mock.patch("os.chdir", autospec=True) as mock_chdir:
        runner.run()
    mock_chdir.assert_has_calls([mock.call(f"/{alternative}"), mock.call("/alt")])


@pytest.mark.tutorial("alternatives-chdir-false")
@pytest.mark.parametrize("alternative", ("foo", "bar"))
def test_alternatives_with_chdir_false(fp: FakeProcess, tutorial: TutorialModel, alternative: str) -> None:
    """Run with an alternative that calls chdir."""
    orig_cwd = os.getcwd()
    fp.register(f"ls {alternative}")
    fp.register("ls")
    runner = LocalTutorialRunner(tutorial, alternatives=(alternative,))
    with mock.patch("os.chdir", autospec=True) as mock_chdir:
        runner.run()
    # Switch back twice for part and alternative
    mock_chdir.assert_has_calls([mock.call(orig_cwd), mock.call(orig_cwd)])
