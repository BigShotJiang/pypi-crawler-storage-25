import argparse
import asyncio
import html
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import webbrowser
from datetime import datetime, timezone
from pathlib import Path

from agentiva.api.server import run_server
from agentiva.interceptor.core import Agentiva
from agentiva.interceptor.mcp_proxy import run_proxy


def _resolve_default_policy_path() -> str:
    """Resolve default policy: in-package (wheel/sdist), repo root, cwd, then data_files install."""
    cli_dir = Path(__file__).resolve().parent
    fallback = cli_dir / "policies" / "default.yaml"
    candidates = (
        fallback,
        cli_dir.parent / "policies" / "default.yaml",
        Path.cwd() / "policies" / "default.yaml",
    )
    for p in candidates:
        if p.is_file():
            return str(p)
    for prefix in (Path(sys.prefix), Path(getattr(sys, "base_prefix", sys.prefix))):
        installed = prefix / "policies" / "default.yaml"
        if installed.is_file():
            return str(installed)
    return str(fallback)


def _resolve_policy_template_path(template_arg: str) -> Path:
    """For init-policy: honor explicit paths; else cwd; else bundled default (no cwd file required)."""
    raw = Path(template_arg).expanduser()
    if raw.is_absolute():
        p = raw.resolve()
        if not p.is_file():
            raise SystemExit(f"Template policy not found: {p}")
        return p
    cwd_candidate = (Path.cwd() / raw).resolve()
    if cwd_candidate.is_file():
        return cwd_candidate
    bundled = Path(_resolve_default_policy_path())
    if bundled.is_file():
        return bundled
    raise SystemExit(f"Template policy not found: {cwd_candidate}")


def _mirror_scan_results_to_user_cache(scan_json_path: str) -> None:
    """Copy last scan JSON to ~/.agentiva/ so `agentiva dashboard` works from any cwd."""
    try:
        dest_dir = os.path.expanduser("~/.agentiva")
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "last_scan.json")
        shutil.copy2(scan_json_path, dest)
    except OSError:
        pass


def _ensure_gitignore_agentiva_dir() -> None:
    """Append `.agentiva/` to the repo root `.gitignore` if missing."""
    gi = Path.cwd() / ".gitignore"
    line = ".agentiva/"
    if gi.is_file():
        try:
            text = gi.read_text(encoding="utf-8")
        except OSError:
            return
        if line in text.splitlines() or any(l.strip() == line for l in text.splitlines()):
            return
        try:
            with gi.open("a", encoding="utf-8") as f:
                if text and not text.endswith("\n"):
                    f.write("\n")
                f.write(f"{line}\n")
        except OSError:
            return
    else:
        try:
            gi.write_text(f"{line}\n", encoding="utf-8")
        except OSError:
            return
    print("  📝 Added .agentiva/ to .gitignore")


def find_available_port(listen_host: str = "0.0.0.0", start: int = 8000, end: int = 8100) -> int | None:
    """Return first free TCP port in [start, end). Uses same bind address family as uvicorn will."""
    probe_host = "0.0.0.0" if listen_host in ("0.0.0.0", "::", "::0") else listen_host
    for port in range(start, end):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.bind((probe_host, port))
                return port
        except OSError:
            continue
    return None


def _cmd_scan(args: argparse.Namespace) -> None:
    """Walk a directory tree, heuristically flag secrets, risky shell, bad deps, PII hints."""
    directory = args.directory
    abs_dir = os.path.abspath(directory)
    if not os.path.isdir(abs_dir):
        raise SystemExit(f"Not a directory: {abs_dir}")

    project_name = os.path.basename(abs_dir)
    scan_agent_id = f"scan-{project_name}"

    print(f"\n  Agentiva scanning: {abs_dir}\n")

    policy_path = _resolve_default_policy_path()
    shield = Agentiva(mode="shadow", policy_path=policy_path)
    issues_found = 0
    files_scanned = 0
    gitignore_warned = False
    scan_issues: list[dict] = []

    credential_patterns = [
        "password",
        "secret_key",
        "api_key",
        "access_key",
        "private_key",
        "database_url",
        "db_password",
        "stripe_secret",
        "openai_api_key",
        "aws_secret",
        "begin rsa private key",
        "begin private key",
        "sk-proj-",
        "sk_live_",
        "akia",
    ]

    shell_substrings = [
        "rm -rf",
        "git push --force",
        "git push -f",
        "drop table",
        "delete from",
        "chmod 777",
        "kill -9",
        "pkill",
        "shutdown",
        "dd if=",
        "mkfs",
        "> /dev/sd",
    ]
    shell_regexes = [
        re.compile(r"curl\s+[^\n]*\|\s*bash", re.IGNORECASE),
        re.compile(r"wget\s+[^\n]*\|\s*sh", re.IGNORECASE),
    ]

    skip_dir_names = {
        ".git",
        "node_modules",
        "__pycache__",
        "venv",
        ".next",
        ".venv",
        "env",
        ".env",
        "dist",
        "build",
        ".tox",
        "coverage",
        ".pytest_cache",
        ".mypy_cache",
    }

    skip_suffixes = (
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".webp",
        ".ico",
        ".woff",
        ".woff2",
        ".ttf",
        ".eot",
        ".pyc",
        ".pyo",
        ".so",
        ".dylib",
        ".dll",
        ".exe",
        ".zip",
        ".tar",
        ".gz",
        ".pdf",
        ".mp4",
        ".mp3",
        ".wasm",
    )

    dep_files = {"requirements.txt", "package.json", "pipfile", "pyproject.toml"}

    for root, dirs, files in os.walk(abs_dir):
        dirs[:] = [d for d in dirs if d not in skip_dir_names]

        for filename in files:
            filepath = os.path.join(root, filename)
            rel_path = os.path.relpath(filepath, abs_dir)
            lower_name = filename.lower()

            try:
                if lower_name.endswith(skip_suffixes):
                    continue
                if os.path.getsize(filepath) > 500_000:
                    continue

                with open(filepath, encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                if not content.strip():
                    continue

                files_scanned += 1
                content_lower = content.lower()

                found_creds = [p for p in credential_patterns if p in content_lower]
                if found_creds:
                    action = shield.intercept_sync(
                        "read_file",
                        {
                            "path": rel_path,
                            "credentials_found": found_creds,
                            "content_preview": content[:200],
                        },
                        agent_id=scan_agent_id,
                    )
                    if action.decision in ("block", "shadow"):
                        issues_found += 1
                        icon = "[BLOCK]" if action.decision == "block" else "[WARN]"
                        print(f"  {icon} {rel_path}")
                        print(f"     Hardcoded credentials: {', '.join(found_creds)}")
                        print(f"     Risk: {action.risk_score:.2f}\n")
                        scan_issues.append(
                            {
                                "file": rel_path,
                                "decision": action.decision,
                                "risk": float(action.risk_score),
                                "tool_name": action.tool_name,
                                "description": f"Hardcoded credentials: {', '.join(found_creds)}",
                            }
                        )

                if lower_name.endswith((".sh", ".bash", ".zsh")):
                    found_dangerous = [d for d in shell_substrings if d in content_lower]
                    for rx in shell_regexes:
                        if rx.search(content):
                            found_dangerous.append(rx.pattern)
                    if found_dangerous:
                        action = shield.intercept_sync(
                            "run_shell_command",
                            {"command": content[:8000], "file": rel_path},
                            agent_id=scan_agent_id,
                        )
                        if action.decision in ("block", "shadow"):
                            issues_found += 1
                            icon = "[BLOCK]" if action.decision == "block" else "[WARN]"
                            print(f"  {icon} {rel_path}")
                            print(f"     Dangerous commands: {', '.join(found_dangerous[:12])}")
                            print(f"     Risk: {action.risk_score:.2f}\n")
                            scan_issues.append(
                                {
                                    "file": rel_path,
                                    "decision": action.decision,
                                    "risk": float(action.risk_score),
                                    "tool_name": action.tool_name,
                                    "description": f"Dangerous commands: {', '.join(found_dangerous[:12])}",
                                }
                            )

                if lower_name in dep_files:
                    known_compromised = [
                        "litellm==1.82.8",
                        "litellm==1.82.7",
                        "event-stream",
                        "ua-parser-js",
                        "colors@1.4.1",
                        "faker@6.6.6",
                    ]
                    found_bad = [d for d in known_compromised if d in content]
                    if found_bad:
                        action = shield.intercept_sync(
                            "install_package",
                            {"packages": found_bad, "file": rel_path},
                            agent_id=scan_agent_id,
                        )
                        issues_found += 1
                        print(f"  [BLOCK] {rel_path}")
                        print(f"     Compromised packages: {', '.join(found_bad)}")
                        print(f"     Risk: {action.risk_score:.2f}\n")
                        scan_issues.append(
                            {
                                "file": rel_path,
                                "decision": action.decision,
                                "risk": float(action.risk_score),
                                "tool_name": action.tool_name,
                                "description": f"Compromised packages: {', '.join(found_bad)}",
                            }
                        )

                if lower_name.endswith((".py", ".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs")):
                    if "export" in content_lower and (
                        "ssn" in content_lower or "credit_card" in content_lower
                    ):
                        action = shield.intercept_sync(
                            "read_customer_data",
                            {
                                "customer_id": "*",
                                "fields": "ssn,credit_card",
                                "file": rel_path,
                            },
                            agent_id=scan_agent_id,
                        )
                        if action.decision in ("block", "shadow"):
                            issues_found += 1
                            icon = "[BLOCK]" if action.decision == "block" else "[WARN]"
                            print(f"  {icon} {rel_path}")
                            print("     Endpoint exposes PII (SSN/credit card)")
                            print(f"     Risk: {action.risk_score:.2f}\n")
                            scan_issues.append(
                                {
                                    "file": rel_path,
                                    "decision": action.decision,
                                    "risk": float(action.risk_score),
                                    "tool_name": action.tool_name,
                                    "description": "Endpoint exposes PII (SSN/credit card)",
                                }
                            )

                if lower_name == ".gitignore":
                    if ".env" not in content and not gitignore_warned:
                        gitignore_warned = True
                        issues_found += 1
                        print("  [WARN] .gitignore missing .env")
                        print("     Credentials could be committed to git\n")
                        scan_issues.append(
                            {
                                "file": rel_path,
                                "decision": "shadow",
                                "risk": 0.45,
                                "tool_name": "read_file",
                                "description": ".gitignore missing .env — credentials could be committed to git",
                            }
                        )

            except OSError:
                continue

    agentiva_dir = os.path.join(abs_dir, ".agentiva")
    os.makedirs(agentiva_dir, exist_ok=True)
    scan_payload = {
        "project": project_name,
        "scan_root": abs_dir,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "agent_id": scan_agent_id,
        "files_scanned": files_scanned,
        "issues_found": issues_found,
        "issues": scan_issues,
    }
    last_scan_path = os.path.join(agentiva_dir, "last_scan.json")
    with open(last_scan_path, "w", encoding="utf-8") as sf:
        json.dump(scan_payload, sf, indent=2)
    _mirror_scan_results_to_user_cache(last_scan_path)

    sep = "=" * 50
    print(f"  {sep}")
    print("  Scan complete")
    print(f"  Files scanned: {files_scanned}")
    print(f"  Issues found: {issues_found}")
    blocked_count = sum(1 for i in scan_issues if i.get("decision") == "block")
    if blocked_count > 0:
        print(f"\n  🛑 {blocked_count} blocking issue(s) found.")
        print("  Fix these before deploying.")
    if issues_found > 0:
        if blocked_count == 0:
            print("\n  Fix these issues before deploying.")
        print("  View full report: agentiva dashboard")
        print("  Ask the co-pilot: 'what should I fix?' (when using the full UI)")
    else:
        print("\n  ✅ No security issues found. Safe to deploy (verify manually).")
        print("  View full report: agentiva dashboard")
    print(f"  {sep}\n")

    # Pre-push gate: non-zero if policy blocks OR any finding (incl. shadow / heuristic [BLOCK] rows).
    must_block_push = blocked_count > 0 or issues_found > 0
    raise SystemExit(1 if must_block_push else 0)


def _cmd_dashboard(args: argparse.Namespace) -> None:
    """Build a static HTML report from the last scan and open it in the browser."""
    root = os.path.abspath(args.directory)
    candidates = [
        os.path.join(root, ".agentiva", "last_scan.json"),
        os.path.expanduser("~/.agentiva/last_scan.json"),
    ]
    results_path = next((p for p in candidates if os.path.isfile(p)), None)
    if not results_path:
        print("  No scan results found. Run 'agentiva scan .' first.")
        raise SystemExit(0)

    with open(results_path, encoding="utf-8") as f:
        results = json.load(f)

    agentiva_out = os.path.join(os.getcwd(), ".agentiva")
    os.makedirs(agentiva_out, exist_ok=True)
    html_path = os.path.join(agentiva_out, "report.html")

    project = html.escape(str(results.get("project", "unknown")))
    timestamp = html.escape(str(results.get("timestamp", "unknown")))
    files_scanned = int(results.get("files_scanned", 0))
    issues_found = int(results.get("issues_found", 0))
    issues = results.get("issues") or []
    blocked_n = sum(1 for i in issues if i.get("decision") == "block")
    warn_n = sum(1 for i in issues if i.get("decision") != "block")

    parts: list[str] = [
        "<!DOCTYPE html>",
        "<html>",
        "<head>",
        "<meta charset=\"utf-8\">",
        "<title>Agentiva Scan Report</title>",
        "<style>",
        "  body { font-family: -apple-system, sans-serif; background: #0a0e1a; color: #e2e8f0; padding: 40px; }",
        "  h1 { color: #10b981; }",
        "  .issue { background: #111827; border-radius: 12px; padding: 20px; margin: 16px 0; border-left: 4px solid #ef4444; }",
        "  .issue.warn { border-left-color: #f59e0b; }",
        "  .issue.safe { border-left-color: #10b981; }",
        "  .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 700; }",
        "  .badge.block { background: #7f1d1d; color: #fca5a5; }",
        "  .badge.shadow { background: #78350f; color: #fde68a; }",
        "  .risk { float: right; font-size: 14px; color: #94a3b8; }",
        "  .file { font-family: monospace; color: #60a5fa; }",
        "  .summary { background: #111827; border-radius: 12px; padding: 24px; margin-bottom: 24px; }",
        "  .footer { margin-top: 40px; color: #64748b; font-size: 14px; }",
        "</style>",
        "</head>",
        "<body>",
        "<h1>Agentiva Scan Report</h1>",
        f"<p>Project: {project} — Scanned: {timestamp}</p>",
        "<div class=\"summary\">",
        f"  <strong>Files scanned:</strong> {files_scanned} &nbsp;",
        f"  <strong>Issues found:</strong> {issues_found} &nbsp;",
        f"  <strong>Blocked:</strong> {blocked_n} &nbsp;",
        f"  <strong>Warnings:</strong> {warn_n}",
        "</div>",
    ]

    for issue in issues:
        decision = issue.get("decision", "shadow")
        css_class = "issue" if decision == "block" else "issue warn"
        badge_class = "badge block" if decision == "block" else "badge shadow"
        badge_text = "BLOCK" if decision == "block" else "WARN"
        risk = float(issue.get("risk", 0.0))
        rel = html.escape(str(issue.get("file", "unknown")))
        desc = html.escape(str(issue.get("description", "")))
        parts.append(f'<div class="{css_class}">')
        parts.append(f'  <span class="{badge_class}">{badge_text}</span>')
        parts.append(f'  <span class="risk">Risk: {risk:.2f}</span>')
        parts.append("  <br><br>")
        parts.append(f'  <span class="file">{rel}</span>')
        parts.append("  <br>")
        parts.append(f"  {desc}")
        parts.append("</div>")

    if issues_found == 0:
        parts.append('<div class="issue safe">✅ No security issues found. Safe to deploy.</div>')

    parts.extend(
        [
            '<div class="footer">',
            '  <p>Generated by Agentiva · pip install agentiva · <a href="https://github.com/RishavAr/agentiva" style="color:#60a5fa">GitHub</a></p>',
            "</div>",
            "</body>",
            "</html>",
        ]
    )
    html_doc = "\n".join(parts)

    with open(html_path, "w", encoding="utf-8") as hf:
        hf.write(html_doc)

    webbrowser.open(Path(html_path).resolve().as_uri())
    print("  📊 Report opened in browser")
    print(f"  📁 Saved to {html_path}")


def _cmd_serve(args: argparse.Namespace) -> None:
    os.environ["AGENTIVA_MODE"] = args.mode
    start_port = args.port
    end_port = start_port + 100
    chosen = find_available_port(args.host, start_port, end_port)
    if chosen is None:
        raise SystemExit(
            f"No free port between {start_port} and {end_port - 1} for host {args.host!r}. "
            f"Stop the process using port {start_port} (e.g. kill $(lsof -ti :{start_port})) or pass --port."
        )
    if chosen != start_port:
        print(f"Port {start_port} is busy; using port {chosen}.", file=sys.stderr)
        print(
            f"Tip: point the dashboard at this API — set AGENTIVA_API_URL=http://127.0.0.1:{chosen} "
            f"in dashboard/.env.local",
            file=sys.stderr,
        )
    display_host = "127.0.0.1" if args.host in ("0.0.0.0", "::", "::0") else args.host
    print(f"Agentiva API: http://{display_host}:{chosen}")
    run_server(host=args.host, port=chosen)


def _cmd_demo(_: argparse.Namespace) -> None:
    from examples.live_demo import run_demo

    asyncio.run(run_demo())


def _cmd_test(args: argparse.Namespace) -> None:
    cmd = [sys.executable, "-m", "pytest"]
    if args.verbose:
        cmd.append("-v")
    if args.path:
        cmd.append(args.path)
    else:
        cmd.append("tests")
    result = subprocess.run(cmd, check=False)
    raise SystemExit(result.returncode)


def _cmd_init_policy(args: argparse.Namespace) -> None:
    source = _resolve_policy_template_path(args.template_policy)
    destination = Path.cwd() / args.output
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    print(f"Created policy file at {destination}")


def _cmd_init(args: argparse.Namespace) -> None:
    """Install git pre-push hook that runs `agentiva scan .` before each push."""
    git_dir = os.path.join(os.getcwd(), ".git")
    if not os.path.isdir(git_dir):
        print("  ⚠️  No git repository found. Run 'git init' first.")
        raise SystemExit(1)

    hooks_dir = os.path.join(git_dir, "hooks")
    os.makedirs(hooks_dir, exist_ok=True)

    hook_path = os.path.join(hooks_dir, "pre-push")

    hook_content = """#!/usr/bin/env bash
# Agentiva Security Gate — auto-scans before git push
set +e

echo ""
echo "🛡️  Agentiva scanning before push..."
echo ""

if command -v agentiva >/dev/null 2>&1; then
  agentiva scan .
else
  python -m agentiva.cli scan .
fi
EXIT_CODE=$?

if [ "$EXIT_CODE" -ne 0 ]; then
    echo ""
    echo "❌ Push BLOCKED — agentiva scan failed or found issues (exit $EXIT_CODE)"
    echo "   Fix the issues above, then push again."
    echo "   View full report: agentiva dashboard"
    echo ""
    exit 1
fi

echo ""
echo "✅ Agentiva: scan finished with no blocking issues. Pushing..."
echo ""
exit 0
"""

    with open(hook_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(hook_content)
    os.chmod(hook_path, 0o755)

    _ensure_gitignore_agentiva_dir()

    try:
        bundled = Path(_resolve_default_policy_path())
        if bundled.is_file():
            dest = Path.cwd() / "policies" / "default.yaml"
            dest.parent.mkdir(parents=True, exist_ok=True)
            if not dest.exists():
                shutil.copyfile(bundled, dest)
                print("  📄 Copied bundled default policy to policies/default.yaml")
    except OSError:
        pass

    print("  ✅ Agentiva initialized")
    print("  📋 Git pre-push hook installed")
    print("  🛡️  Every 'git push' will scan for security issues first")
    print("  📊 View scan report: agentiva dashboard  ·  API + web UI: agentiva serve")


def _cmd_mcp_proxy(args: argparse.Namespace) -> None:
    run_proxy(upstream=args.upstream, port=args.port)


def main() -> None:
    parser = argparse.ArgumentParser(prog="agentiva")
    sub = parser.add_subparsers(dest="command", required=True)

    serve = sub.add_parser("serve", help="Start API server")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=8000)
    serve.add_argument("--mode", default="shadow", choices=["shadow", "live", "approval"])
    serve.set_defaults(func=_cmd_serve)

    demo = sub.add_parser("demo", help="Run the live demo scenarios")
    demo.set_defaults(func=_cmd_demo)

    test_cmd = sub.add_parser("test", help="Run test suite")
    test_cmd.add_argument("--path", default="tests")
    test_cmd.add_argument("--verbose", action="store_true")
    test_cmd.set_defaults(func=_cmd_test)

    init_cmd = sub.add_parser(
        "init",
        help="Initialize Agentiva in the current project (installs git pre-push scan hook)",
    )
    init_cmd.set_defaults(func=_cmd_init)

    init_policy_cmd = sub.add_parser(
        "init-policy",
        help="Copy default policy YAML into the current directory",
    )
    init_policy_cmd.add_argument("--output", default="policies/default.yaml")
    init_policy_cmd.add_argument("--template-policy", default="policies/default.yaml")
    init_policy_cmd.set_defaults(func=_cmd_init_policy)

    mcp_proxy_cmd = sub.add_parser("mcp-proxy", help="Run MCP proxy with interception")
    mcp_proxy_cmd.add_argument("--upstream", default="localhost:3001")
    mcp_proxy_cmd.add_argument("--port", type=int, default=3002)
    mcp_proxy_cmd.set_defaults(func=_cmd_mcp_proxy)

    scan_cmd = sub.add_parser("scan", help="Scan a project for security issues (automatic heuristics)")
    scan_cmd.add_argument("directory", nargs="?", default=".", help="Root directory to scan (default: .)")
    scan_cmd.set_defaults(func=_cmd_scan)

    dash_cmd = sub.add_parser(
        "dashboard",
        help="Open last scan results as a local HTML report (no server)",
    )
    dash_cmd.add_argument(
        "directory",
        nargs="?",
        default=".",
        help="Project root that contains .agentiva/last_scan.json (default: .)",
    )
    dash_cmd.set_defaults(func=_cmd_dashboard)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
