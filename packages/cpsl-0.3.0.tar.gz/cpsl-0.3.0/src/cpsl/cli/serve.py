import os
import signal
import time
from hashlib import sha256
from queue import Empty, Queue
from threading import Event

import click
import grpc
import requests

from .. import terminal
from ..channel import ServiceClient, pass_service_client
from ..typestubs import generate_type_stubs
from ..clients.capsule import (
    ListAppsRequest,
    ListAppsResponse,
    ServeAttachRequest,
    ServeStreamMessage,
    ServeSyncRequest,
    StartServeRequest,
    StartServeResponse,
)
from ..config import get_config_context
from ..utils import (
    resolve_entry_point,
    collect_source_archive,
    build_image_spec,
    build_channel_specs,
    build_integration_specs,
    build_schedule_specs,
    normalize_image,
)

SYNC_INTERVAL = 0.1
HEARTBEAT_INTERVAL = 5.0
GATEWAY_READY_TIMEOUT = 5.0
START_SERVE_TIMEOUT = 180.0

_WATCHED_EXTENSIONS = (".py", ".tsx", ".ts", ".jsx", ".js")
_IGNORED_WATCH_DIRS = {".git", ".venv", "__pycache__", "node_modules"}


def _channel_api():
    """Return (base_url, headers) for the channel HTTP API, or None if not logged in."""
    ctx = get_config_context()
    if not ctx or not ctx.is_valid():
        return None
    port = ctx.http_port
    scheme = "https" if port == 443 else "http"
    host = ctx.gateway_host if port in (443, 80) else f"{ctx.gateway_host}:{port}"
    base = f"{scheme}://{host}/api/v1/channels"
    headers = {"Authorization": f"Bearer {ctx.token}"}
    return base, headers


def _list_channels(base: str, headers: dict, timeout: int = 10) -> dict[str, dict]:
    r = requests.get(base, headers=headers, timeout=timeout)
    if r.status_code != 200:
        return {}
    return {c["name"]: c for c in r.json().get("channels", [])}


def _bind_channels(app_name: str, names: tuple[str, ...], force: bool):
    api = _channel_api()
    if not api:
        terminal.warn("Skipping channel bind — not logged in.")
        return
    base, headers = api
    channels = _list_channels(base, headers)

    for name in names:
        terminal.header(f"Binding channel {name}")
        ch = channels.get(name)
        if not ch:
            terminal.status_fail("Channel not found")
            continue

        if force and ch.get("bound_to"):
            requests.post(f"{base}/{ch['id']}/unbind", headers=headers, timeout=10)

        r = requests.post(
            f"{base}/{ch['id']}/bind",
            json={"app_name": app_name},
            headers=headers,
            timeout=10,
        )
        if r.status_code == 409:
            terminal.status_fail("Already bound — use --force-channel to rebind")
        elif r.status_code == 200:
            terminal.status_ok(f"Bound to {app_name}")
        else:
            terminal.status_fail(f"Bind failed: {r.text}")


def _unbind_channels(names: tuple[str, ...]):
    api = _channel_api()
    if not api:
        return
    base, headers = api
    try:
        channels = _list_channels(base, headers, timeout=5)
        for name in names:
            ch = channels.get(name)
            if ch and ch.get("bound_to"):
                requests.post(f"{base}/{ch['id']}/unbind", headers=headers, timeout=5)
                terminal.detail(f"  Unbound channel '{name}'")
    except Exception:
        pass


@click.command("serve")
@click.argument("entry_point")
@click.option(
    "--channel",
    "channel_names",
    multiple=True,
    help="Bind channel(s) to this serve (repeatable). Use --force-channel to rebind already-bound channels.",
)
@click.option(
    "--force-channel", is_flag=True, help="Unbind channels from their current app before rebinding."
)
@pass_service_client
def serve(
    client: ServiceClient, entry_point: str, channel_names: tuple[str, ...], force_channel: bool
):
    """Serve an app with hot-reload.

    ENTRY_POINT is <module>:<ClassName>, e.g. app:DietCoach
    """
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer

    shutdown = Event()

    def _handle_signal(signum, frame):
        shutdown.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, _handle_signal)

    class _SyncHandler(FileSystemEventHandler):
        def __init__(self, queue: Queue, root: str):
            super().__init__()
            self.queue = queue
            self.root = os.path.abspath(root)
            self._known_hashes: dict[str, str] = {}

        def _is_watched(self, path: str) -> bool:
            return any(path.endswith(ext) for ext in _WATCHED_EXTENSIONS)

        def _normalize(self, path: str) -> str:
            return os.path.abspath(path)

        def _is_ignored(self, path: str) -> bool:
            normalized = self._normalize(path)
            try:
                rel = os.path.relpath(normalized, self.root)
            except ValueError:
                return False
            return any(part in _IGNORED_WATCH_DIRS for part in rel.split(os.sep))

        @staticmethod
        def _digest(data: bytes) -> str:
            return sha256(data).hexdigest()

        def seed(self) -> None:
            for dirpath, dirnames, filenames in os.walk(self.root):
                dirnames[:] = [name for name in dirnames if name not in _IGNORED_WATCH_DIRS]
                for filename in filenames:
                    path = os.path.join(dirpath, filename)
                    if not self._is_watched(path):
                        continue
                    try:
                        with open(path, "rb") as f:
                            self._known_hashes[self._normalize(path)] = self._digest(f.read())
                    except OSError:
                        continue

        def _enqueue_if_changed(self, path: str) -> None:
            normalized = self._normalize(path)
            try:
                with open(normalized, "rb") as f:
                    data = f.read()
            except OSError:
                return

            # Watchdog can emit duplicate modify events even when file contents
            # are unchanged; only sync when the bytes actually differ.
            digest = self._digest(data)
            if self._known_hashes.get(normalized) == digest:
                return

            self._known_hashes[normalized] = digest
            self.queue.put((normalized, data, False))

        def on_created(self, event):
            if event.is_directory or self._is_ignored(event.src_path) or not self._is_watched(event.src_path):
                return
            self._enqueue_if_changed(event.src_path)

        def on_modified(self, event):
            self.on_created(event)

        def on_deleted(self, event):
            if event.is_directory or self._is_ignored(event.src_path) or not self._is_watched(event.src_path):
                return
            normalized = self._normalize(event.src_path)
            if self._known_hashes.pop(normalized, None) is None:
                return
            self.queue.put((normalized, b"", True))

    config = resolve_entry_point(entry_point)

    image = normalize_image(config["image"])
    channels = config.get("channels", [])
    secrets = config.get("secrets", [])
    keep_warm = config.get("keep_warm_seconds", 0)
    filesystems = config.get("filesystems", {})
    integrations = config.get("integrations", [])
    schedules = config.get("schedules", [])

    pages = config.get("pages", [])
    data_sources = config.get("data_sources", [])

    generate_type_stubs(pages)

    terminal.header("Serving", f"[bold]{config['app_name']}[/bold]")
    terminal.detail(f"  entry:     {config['module']}:{config['class_name']}")

    if pages:
        terminal.detail(f"  pages:     {', '.join(p['name'] for p in pages)}")
    if data_sources:
        terminal.detail(f"  data:      {', '.join(data_sources)}")
    if secrets:
        terminal.detail(f"  secrets:   {', '.join(secrets)}")
    if keep_warm > 0:
        terminal.detail(f"  keep_warm: {keep_warm}s")
    if image.get("python_packages"):
        terminal.detail(f"  pip:       {', '.join(image['python_packages'])}")
    if image.get("apt_packages"):
        terminal.detail(f"  apt:       {', '.join(image['apt_packages'])}")
    if image.get("commands"):
        terminal.detail(f"  commands:  {len(image['commands'])}")

    terminal.header("Syncing files")
    archive = collect_source_archive()

    req = StartServeRequest(
        app_name=config["app_name"],
        image=build_image_spec(image),
        channels=build_channel_specs(channels),
        entry_point=f"{config['module']}:{config['class_name']}",
        source_archive=archive,
        keep_warm_seconds=keep_warm,
        secrets=secrets,
        filesystems=filesystems,
        integrations=build_integration_specs(integrations),
        schedules=build_schedule_specs(schedules),
    )

    with terminal.progress("Starting machine...") as spinner:
        t0 = time.monotonic()
        list_apps = client.channel.unary_unary(
            "/capsule.CapsuleService/ListApps",
            ListAppsRequest.SerializeToString,
            ListAppsResponse.FromString,
        )
        try:
            list_apps(ListAppsRequest(), timeout=GATEWAY_READY_TIMEOUT)
        except grpc.RpcError as err:
            if err.code() in (grpc.StatusCode.DEADLINE_EXCEEDED, grpc.StatusCode.UNAVAILABLE):
                terminal.error(
                    "Gateway gRPC tunnel is not responding. "
                    "If you're using local dev, restart `make start`."
                )
                raise SystemExit(1)
            raise

        start_serve = client.channel.unary_stream(
            "/capsule.CapsuleService/StartServe",
            StartServeRequest.SerializeToString,
            StartServeResponse.FromString,
        )
        res = None
        try:
            for msg in start_serve(req, timeout=START_SERVE_TIMEOUT):
                if msg.ok or msg.err_msg:
                    res = msg
                    break
                if msg.status:
                    spinner.update(msg.status)
        except grpc.RpcError as err:
            if err.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                terminal.error(
                    "Timed out waiting for StartServe. "
                    "If you're using local dev, restart `make start`."
                )
                raise SystemExit(1)
            raise

        if res is None:
            terminal.error("Serve stream ended without a result.")
            raise SystemExit(1)

        elapsed = time.monotonic() - t0

    if not res.ok:
        terminal.error(f"Serve failed: {res.err_msg}")
        raise SystemExit(1)

    app_id = res.app_id
    instance_ref = res.instance_ref

    terminal.success(f"Ready in {elapsed:.1f}s")
    terminal.header(f"Serving {config['app_name']}")

    terminal.url(res.url or f"https://{res.hostname}.capsule.new")

    spec_channel_names = tuple(
        ch["name"] for ch in channels if ch.get("type") == "_resource" and ch.get("name")
    )
    all_channel_names = tuple(dict.fromkeys(spec_channel_names + channel_names))

    if all_channel_names:
        _bind_channels(config["app_name"], all_channel_names, force_channel)

    sync_dir = os.getcwd()
    sync_queue: Queue = Queue()
    handler = _SyncHandler(sync_queue, sync_dir)
    handler.seed()
    observer = Observer()
    observer.schedule(handler, sync_dir, recursive=True)
    observer.start()

    def _stop_remote_serve():
        def _stop_generator():
            yield ServeStreamMessage(
                attach=ServeAttachRequest(app_id=app_id, instance_ref=instance_ref)
            )
            yield ServeStreamMessage(sync=ServeSyncRequest(path="", data=b"", is_delete=True))

        try:
            stream = client.capsule.serve_stream(_stop_generator())
            for _ in stream:
                break
        except grpc.RpcError:
            pass

    def _stream_generator():
        yield ServeStreamMessage(
            attach=ServeAttachRequest(app_id=app_id, instance_ref=instance_ref)
        )
        last_heartbeat = time.monotonic()
        while True:
            if shutdown.is_set():
                return
            try:
                path, data, is_delete = sync_queue.get_nowait()
                rel = os.path.relpath(path, start=sync_dir)
                terminal.header("Reloading", rel)
                yield ServeStreamMessage(
                    sync=ServeSyncRequest(
                        path=rel,
                        data=data,
                        is_delete=is_delete,
                    )
                )
                sync_queue.task_done()
                last_heartbeat = time.monotonic()
            except Empty:
                now = time.monotonic()
                if now - last_heartbeat >= HEARTBEAT_INTERVAL:
                    yield ServeStreamMessage(
                        sync=ServeSyncRequest(path="", data=b"", is_delete=False)
                    )
                    last_heartbeat = now
                else:
                    time.sleep(SYNC_INTERVAL)

    terminal.header("Watching for changes...")
    try:
        while not shutdown.is_set():
            try:
                stream = client.capsule.serve_stream(_stream_generator())
                remote_done = False
                for resp in stream:
                    if shutdown.is_set():
                        break
                    if resp.output:
                        terminal.detail(resp.output, dim=False, end="")
                    if resp.done:
                        remote_done = True
                        break
                if shutdown.is_set():
                    break
                if remote_done:
                    terminal.warn("Serve stream closed by server.")
                    break
                terminal.warn("Serve stream disconnected. Reconnecting...")
            except grpc.RpcError as err:
                if shutdown.is_set():
                    break
                code = err.code()
                if code == grpc.StatusCode.CANCELLED:
                    terminal.warn("Serve stream cancelled. Reconnecting...")
                else:
                    terminal.warn(f"Serve stream lost ({code.name.lower()}). Reconnecting...")
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown.set()
    finally:
        observer.stop()
        observer.join(timeout=1)

    if shutdown.is_set():
        terminal.header("Stopping serve")
    else:
        terminal.warn("Serve stream ended; leaving remote serve running.")

    if shutdown.is_set() and all_channel_names:
        _unbind_channels(all_channel_names)

    if shutdown.is_set():
        _stop_remote_serve()
    client.close()
