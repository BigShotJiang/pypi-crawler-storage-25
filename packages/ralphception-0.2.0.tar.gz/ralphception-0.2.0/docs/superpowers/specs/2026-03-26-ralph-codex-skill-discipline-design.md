# Ralph Codex Skill Discipline Design

**Problem**

Ralphception now routes startup intake and stage execution through real Codex turns, but the packaged Ralphception skills are still too thin. They name the stages, but they do not yet carry enough of the `~/.codex/superpowers` discipline to reliably shape the LLM's behavior. That leaves too much behavior implicit in stage prompts and too little in the reusable skill layer.

**Goal**

Make Ralphception's packaged Codex skills the primary behavioral driver for startup intake, PRD writing, plan writing, execution, and audit. The stage prompts should stay compact and artifact-focused, while the packaged skills carry the repo-local Ralph loop discipline.

**Non-Goals**

- Replacing the existing stage names or artifact contracts
- Changing `exec` to become Socratic
- Reworking the Codex TUI again in this slice
- Adding a new generalized skill system beyond the packaged Ralphception bundle

**Design**

Ralphception will keep five packaged Codex skills:

1. `ralph-startup-intake`
2. `ralph-spec-writing`
3. `ralph-plan-writing`
4. `ralph-execute-task`
5. `ralph-audit-review`

Each skill will be expanded so it encodes the stage discipline that currently lives only partially in prompts or in the human's expectations:

- Startup intake mirrors the Socratic cadence from `brainstorming`: one question at a time, repo-wide access by default, no permission-seeking, no artifact writing, and a crisp stop condition for when to synthesize the intake summary.
- Spec writing mirrors the superpowers design/spec mindset: state the goal, scope, non-goals, architecture, risks, constraints, and acceptance criteria in a repo-local PRD without spilling into implementation churn.
- Plan writing mirrors `writing-plans`: explicit file map, bite-sized tasks, TDD-first steps, exact verification commands, and the extra Ralphception JSON contract outputs that drive loop planning.
- Execution mirrors `test-driven-development` plus repo-local loop execution discipline: write or identify the failing verification first when behavior changes, make the minimal change, verify before claiming completion, and keep progress concrete.
- Audit mirrors `verification-before-completion` and code-review discipline: findings first, merged diff plus touched-path evidence, verification evidence, and a short-circuit to empty findings when the repo-local evidence is clean.

**Architecture**

The change stays mostly in packaged markdown resources plus small prompt-contract reinforcement:

- `src/ralphception/codex_skills/*/SKILL.md` becomes the main source of stage behavior.
- `src/ralphception/runtime/startup_llm.py` may gain stronger startup wording if the tests show missing guidance.
- `src/ralphception/headless.py` keeps stage prompts artifact-local and skill-invoking rather than duplicating the full process instructions.
- Tests pin the packaged skill content so later regressions cannot silently hollow the skill layer back out.

**Testing**

- Add failing unit tests that assert the packaged skill files contain the required stage discipline phrases.
- Keep the existing stage-prompt contract tests green.
- Run the focused packaged-skill and startup/stage contract tests.
- Run the full project suite plus `ty`.

**Risks**

- Overly verbose skills could cause the model to drift into meta narration.
- Copying superpowers language too literally could leak user-facing workflow instructions that do not fit Ralphception's repo-local runtime.

**Mitigations**

- Keep the skills specific to the stage and repo-local task.
- Assert for the key behavioral rules, not for giant verbatim copies.
- Leave artifact paths and output contracts in stage prompts where determinism matters.
