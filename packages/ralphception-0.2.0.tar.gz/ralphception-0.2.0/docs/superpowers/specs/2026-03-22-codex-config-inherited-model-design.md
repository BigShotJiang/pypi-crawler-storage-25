# Codex Config Inherited Model Design

## Goal

Make Ralphception inherit model selection from Codex itself instead of owning a parallel model-selection flow.

## Product Decision

Ralphception should not let users choose the model inside the Ralphception TUI. The effective model, reasoning effort, and service tier should come from Codex configuration, because Ralphception sits on top of Codex rather than replacing its model-selection behavior.

## Required Behavior

- The header and footer report the currently effective Codex model settings.
- Ralphception no longer persists model, reasoning, or latency/service-tier choices in `.ralphception/config.toml`.
- Ralphception no longer opens model or reasoning picker views.
- Entering `/model` in the composer produces guidance explaining:
  - model settings are inherited from Codex
  - they can be changed in Codex config or the Codex app
  - Ralphception must be restarted after changing them

## Runtime Contract

Ralphception currently launches Codex under an isolated `CODEX_HOME` and writes a temporary `config.toml`, then passes `model` and `effort` explicitly in app-server requests. That prevents true inheritance from Codex.

To fix this, Ralphception must:

- copy the user Codex config into the isolated Codex home instead of replacing it with a Ralphception-owned config
- keep the existing repo-local safety overrides for plugins/skills through request config overrides
- stop sending `model` and `effort` overrides in `thread/start`, `thread/resume`, `thread/fork`, and `turn/start`

## UI Contract

- The session header continues to use Codex-style structure, but the displayed model metadata comes from Codex config state.
- `/model` remains discoverable because Codex teaches it in the header, but in Ralphception it is informational, not interactive.
- Any existing model picker or reasoning picker UI is dead code after this change and should be removed from the active product path.

## Config Boundaries

- `.ralphception/config.toml` remains for Ralphception-specific behavior.
- Codex model selection lives in `CODEX_HOME/config.toml` or the Codex app.
- Ralphception may continue to use its own config for Ralphception-only defaults such as execution and verification behavior.

## Acceptance Criteria

- A user changing `~/.codex/config.toml` and restarting Ralphception sees the new model metadata in the shell.
- The Codex app-server transport no longer forces a Ralphception-owned model or reasoning effort.
- `/model` opens guidance instead of a picker.
- The old model/reasoning picker flow is removed from the live TUI path.
