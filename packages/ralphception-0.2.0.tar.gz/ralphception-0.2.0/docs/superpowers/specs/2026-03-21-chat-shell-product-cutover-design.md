# Chat Shell Product Cutover Design

## Objective

Promote the new Codex-shaped chat shell from an experimental fixture prototype into the primary Ralphception product surface. The default `ralphception` entrypoint should launch the chat shell, while `ralphception exec` with alias `ralphception e` should become the non-interactive execution path. The old startup/review/dashboard TUI split and the public `terminal` / `headless` / `chat-shell` commands should stop defining the product.

## Why This Cutover Exists

Ralphception currently exposes multiple competing interfaces:

- the legacy Textual startup, review, and dashboard flow
- the terminal frontend
- the headless frontend
- the new fixture-driven chat shell prototype

That split makes the product harder to understand than the runtime itself. Codex has the right interaction model for this class of tool: one interactive shell as the default experience and one explicit non-interactive `exec` path. Ralphception should do the same.

## Product Contract

After this cutover, the supported product contract is:

- `ralphception`
  Launch the interactive chat shell.
- `ralphception exec ...`
  Run the non-interactive mission path.
- `ralphception e ...`
  Alias for `exec`.
- `ralphception resume ...`
  Resume recovery state explicitly.

The following stop being public product commands:

- `ralphception terminal`
- `ralphception headless`
- `ralphception chat-shell`

Internal code may temporarily reuse pieces of the old implementations while the cutover lands, but those paths are no longer the user-facing product.

## Architecture

### 1. Keep the durable runtime core

The storage, workflow, approvals, recovery, worktree, merge, and execution runtime already work. Those layers should be reused. This cutover is not a rewrite of the durable engine.

The stable core to preserve:

- `RuntimeSupervisor`
- durable mission state in `.ralphception/`
- workflow and recovery services
- non-interactive mission execution loop
- worktree orchestration and merge flow

### 2. Replace the default interactive surface

The default product UI becomes `ChatShellApp`. It should no longer be a fixture-only prototype. It must render real runtime state and accept real user actions for the product-critical flows:

- workspace bootstrap
- mission conflict resolution
- review approval / rejection / pause
- mission status visibility
- thread and subagent visibility

The shell remains transcript-first, with status context and a bottom interaction surface. That interaction surface can still be minimal in this cutover, but it must operate on real runtime state rather than static fixtures.

### 3. Add a runtime-to-shell adapter

The existing supervisor exposes step-oriented state rather than the fully event-driven chat protocol envisioned in the long-term rewrite. For this cutover, Ralphception should add a thin adapter that converts current supervisor/runtime states into shell state:

- startup prompts become shell overlays and input forms
- review prompts become review overlays and transcript entries
- conflict prompts become shell overlays
- mission/dashboard state becomes transcript summaries, thread list state, and status indicators
- child runs become shell threads / subagents

This adapter is the bridge between the proven runtime core and the new shell. It is explicitly a cutover adapter, not the end-state event protocol.

### 4. Promote non-interactive execution

The current terminal frontend already embodies the right non-interactive mission semantics: it boots, prompts, executes, verifies, reopens on audit findings, and completes. That behavior should be promoted as the official `exec` command.

The change is product framing and CLI shape:

- `exec` is the public name
- `e` is a public alias
- output remains line-oriented and suitable for terminal use
- `terminal` and `headless` stop being public commands

Where practical, naming and help text should mirror the Codex mental model.

## Runtime Flow Mapping

### Interactive shell

`ralphception` should:

1. bootstrap the workspace if needed
2. resolve current supervisor state
3. adapt that state into `ShellState`
4. render the chat shell
5. let shell actions call back into the runtime for bootstrap, review, or conflict decisions
6. refresh shell state after each runtime mutation

This first product cutover does not need the full future streaming protocol. It does need a real, usable shell over the current runtime.

### Non-interactive exec

`ralphception exec` should:

1. resolve the repo root
2. run the existing non-interactive mission loop
3. print stable line-oriented output
4. exit with the corresponding result

This path should preserve current working behavior while changing the public command surface to match the new product model.

## Codebase Consequences

### Public code paths to change

- `src/ralphception/cli.py`
  Redefine public commands around shell + exec + resume.
- `src/ralphception/app.py`
  Make `run_app()` launch the real chat shell and expose a production `run_exec(...)` entrypoint.
- `src/ralphception/chat_shell/`
  Extend the shell from fixture-only prototype into the real product UI.

### Public code paths to demote or remove

- legacy startup/review/dashboard default launch path in `run_app()`
- public `terminal`, `headless`, and `chat-shell` commands
- README sections that describe the old split as the product

### Code that may remain temporarily

Some legacy UI files may remain in-repo during the cutover if they are no longer wired into public entrypoints. The success criterion is the new product path, not immediate full-file deletion. Dead code cleanup can happen during the same cutover if it is low-risk, but the public contract change is mandatory.

## Testing Strategy

The cutover must be driven by tests that prove the public contract:

- CLI tests proving:
  - no-subcommand launch uses the chat shell
  - `exec` and `e` both run the non-interactive path
  - removed public commands are no longer advertised
- shell integration tests proving:
  - startup state renders in the shell
  - review state renders in the shell
  - real runtime-backed state, not only fixture state, can be displayed
- end-to-end tests proving:
  - interactive launch still works on an empty workspace
  - non-interactive execution still works through `exec`

Existing terminal execution tests should be updated to assert the new `exec` naming where they exercise public behavior.

## Risks

### Risk: shell cutover is only cosmetic

If the shell remains fixture-driven, the product still does not work. The cutover must bind the shell to the real runtime.

### Risk: partial compatibility leaves a confused CLI

Keeping `terminal`, `headless`, and `chat-shell` as public commands would preserve the product split this cutover is meant to remove.

### Risk: deleting too much runtime code at once

The supervisor and execution loop are already working. The cutover should replace the public shell and command wiring, not destabilize durable runtime behavior unnecessarily.

## Acceptance Criteria

This cutover is complete when all of the following are true:

- `uv run ralphception` launches the real chat shell against actual runtime state
- `uv run ralphception exec ...` runs the non-interactive mission path
- `uv run ralphception e ...` works as an alias for `exec`
- `terminal`, `headless`, and `chat-shell` are no longer public product commands
- the README describes the new product contract, not the old split UI model
- the full test suite passes after the cutover
