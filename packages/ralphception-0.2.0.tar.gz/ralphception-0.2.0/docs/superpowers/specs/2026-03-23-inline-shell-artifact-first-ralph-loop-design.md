# Inline Shell And Artifact-First Ralph Loop Orchestrator Design

## Summary

Ralphception should stop behaving like a boxed full-screen Textual app that happens to look a bit like Codex. It should become a Codex-style inline terminal product whose primary transcript lives in normal terminal scrollback, while the active shell surface owns only the current conversational context, composer, and blocking state.

Ralphception is also not a general-purpose coding shell. It is a dedicated Ralph-loop orchestration product. Every meaningful task should begin with Socratic intake, produce durable planning artifacts, and then execute one or more Ralph loops against those artifacts until the work is complete or explicitly blocked.

This is a product reset in two dimensions:

- shell contract reset:
  - from boxed full-screen transcript widgets
  - to inline scrollback-first terminal UX
- orchestration contract reset:
  - from a generic staged supervisor
  - to an artifact-first Ralph-loop planner and executor

The implementation should be phased, but the design target is one coherent product.

## Product Identity

Ralphception should feel like Codex in how it inhabits the terminal:

- continuous conversational session
- inline transcript flowing through terminal scrollback
- clear active status, blocking state, and composer
- durable settled messages for what the system did or needs next

Ralphception should differ from Codex in what it is for:

- breadth-first exploration
- durable PRD, plan, and todo creation
- Ralph-loop preparation and execution
- nested orchestration:
  - plans of plans
  - loops of loops
  - parallel loop families when justified

The user should experience Ralphception as:

“Codex-like terminal UX, but specialized for long-running Ralph-loop orchestration.”

## Problem Statement

The current product has two fundamental mismatches.

### Wrong shell model

The shipped TUI still owns the whole terminal as a boxed interface:

- transcript is constrained inside `#transcript-view`
- the bottom pane is hard-capped
- history is re-rendered inside a widget rather than emitted durably to scrollback

That creates the exact failures the user observed:

- logs appear and disappear
- only a small portion of the visible history remains on screen
- scroll behavior is widget-local instead of terminal-native
- the app can look idle while work is still unresolved

This is the wrong primitive compared to Codex inline mode, which preserves normal terminal scrollback and treats the active UI as a viewport rather than as the entire terminal history.

### Wrong orchestration model

The runtime is still closer to a staged supervisor than to a first-class Ralph-loop orchestrator. Although recent work moved blocker handling toward conversational prompts, the live product still centers the pipeline around generic runtime stages such as:

- startup
- spec
- plan
- execute
- merge
- audit

That is not the right product contract. Ralphception should not merely “have” PRDs, plans, and loops. It should be explicitly built around producing them and executing from them.

The missing contract today is:

- Socratic intake first
- always write durable artifacts
- treat those artifacts as the execution control plane
- run Ralph loops against an explicit plan graph
- continuously narrate what is happening and what settled

## Product Goals

### Codex-style inline terminal UX

`uv run ralphception` should default to a Codex-like inline shell, not a full-screen boxed dashboard. Transcript history should live in normal terminal scrollback.

### Socratic intake for every real task

Ralphception should always begin by shaping the request through clarifying back-and-forth until it has enough structure to write durable planning artifacts.

### Artifact-first execution

Before real execution, Ralphception should always produce explicit durable artifacts:

- intake summary
- PRD or spec
- research or loop plan
- execution plan
- todos or checklists

### Ralph-loop-native orchestration

Execution should be driven by Ralph loops operating against explicit plans, not by an opaque while-loop or an ad hoc stage machine.

### Long-running continuity

Ralphception should be able to work for hours or days. When reopened, it should restore the active task, current artifacts, current plan node, current loop state, and current blocker or waiting state.

### No silent stalls

The user must always be able to tell one of:

- what Ralphception is doing
- what it is waiting on
- what it completed
- why it is blocked

## Non-Goals

- turning Ralphception into a general-purpose “just do it” coding shell
- preserving the current boxed transcript widget model
- hiding planning artifacts in model state instead of writing them durably
- making every interaction freeform if the system can express it more clearly through explicit artifacts and settled transcript messages

## Product Contract

### Task class

Ralphception should assume that every meaningful task requires breadth-first preparation for Ralph loops. It should not optimize for trivial one-shot “just do x” requests.

### Message classification

The shell and runtime need an explicit classifier for each incoming user message. Every message in an active session must be treated as exactly one of:

- `blocker_reply`
- `in_task_follow_up`
- `task_revision`
- `new_task_request`

The classifier should prefer continuity over accidental branching:

- if a prompt or blocker is pending, the next user message is first treated as a potential `blocker_reply`
- if no blocker is pending and there is an active task, the default assumption is `in_task_follow_up`
- the runtime should only treat a message as `new_task_request` when the assistant or runtime classifier has high confidence that the user is abandoning or superseding the current task
- if intent is ambiguous, Ralphception should ask a clarifying question rather than silently starting a parallel orchestration branch

This classifier is the boundary that lets Ralphception keep a continuous Codex-like conversation while still enforcing artifact-first orchestration.

### Default lifecycle

For each new task, the default lifecycle is:

1. Socratic intake
2. durable artifact formation
3. loop planning
4. loop execution
5. consolidation back into artifacts
6. repeat until complete or blocked

### Durable artifacts are mandatory

Before the first real Ralph loop begins, Ralphception should always materialize explicit artifacts. At minimum:

- `intake-summary`
- `prd` or `spec`
- `loop-plan`
- `execution-plan`
- `todos`

These artifacts are not optional reporting output. They are the control plane for subsequent execution.

### Explicit settled outcomes

Every significant step in the lifecycle should settle into a durable transcript statement, such as:

- wrote intake summary
- wrote PRD
- wrote loop plan
- launched 3 Ralph loops
- consolidated findings into the execution plan
- blocked waiting for clarification
- completed the requested work

The product must never simply go quiet at the end of a cycle.

## Top-Level Architecture

Ralphception should be decomposed into five primary subsystems.

### 1. Inline terminal shell

Responsibilities:

- preserve transcript history in normal terminal scrollback
- render the active shell surface:
  - session context
  - live status
  - composer
  - current blocker or waiting indicator
- keep the user inside one continuous conversation

This subsystem should stop trying to own the entire screen as a boxed application.

### 2. Socratic intake engine

Responsibilities:

- ask clarifying questions one at a time
- converge on task purpose, scope, constraints, and success criteria
- stop only when there is enough structure to write durable artifacts

This is the standard entry path for every real task.

### 3. Durable artifact pipeline

Responsibilities:

- write and update intake summaries
- write and update PRDs or specs
- write and update loop plans
- write and update execution plans
- write and update todos or checklists

Artifacts should live durably under `.ralphception` and be treated as authoritative execution inputs.

Each artifact set needs a stable identity model:

- `task_id`: the durable identity for the user-visible task
- `session_id`: the active conversational session carrying that task
- `plan_id`: the current authoritative plan graph for the task
- `loop_graph_id`: the current authoritative loop graph for the task
- `artifact_revision`: a monotonic revision for each authoritative artifact

Nested or parallel work should never create ambiguity about ownership:

- subplans belong to a parent `task_id`
- each subplan has its own `plan_node_id`
- loops attach to a specific `plan_node_id`
- loop outputs must declare which artifact and revision they propose to update

Only one artifact revision per artifact type is authoritative at a time. Superseded artifacts remain durable history, but execution always targets the current authoritative revision.

### 4. Ralph-loop planner and executor

Responsibilities:

- translate artifacts into executable loops
- manage loop objectives, stop conditions, and output contracts
- run one or many loops
- support nested orchestration:
  - plan from intake
  - subplan from plan node
  - loop family from subplan
  - loop spawning additional scoped loop work
- consolidate outputs back into durable artifacts and transcript

### 5. Long-running continuity layer

Responsibilities:

- persist current task identity
- persist authoritative artifacts
- persist current plan node and loop graph state
- persist current blocker or waiting state
- reopen directly into the active orchestration context after interruption

This layer should not own the same data as the artifact pipeline. The persistence split must be explicit:

- **artifact pipeline persistence**
  - user-facing durable work products
  - intake summary
  - PRD or spec
  - plan
  - loop plan
  - todos
- **continuity and control persistence**
  - current task/session identity
  - active plan node
  - active loop state
  - blocker state
  - failure state
  - queued next actions
  - artifact revision pointers

Artifacts are the durable work products. Continuity state is the internal runtime metadata that points at the current authoritative artifacts and current execution position.

## Execution Lifecycle

### Intake

The user begins with an initial goal. Ralphception conducts Socratic back-and-forth until it can define the work properly.

Outputs:

- explicit intake summary
- clarified scope
- success criteria
- relevant constraints

### Artifact formation

Ralphception writes the first durable artifacts:

- PRD or spec
- initial execution plan
- todo or checklist set
- initial Ralph-loop plan

This is the minimum bar before real loop execution.

### Loop planning

Ralphception determines how to operationalize the work:

- one primary loop
- subloops for separate research fronts
- parallel loop families
- plans of plans for large tasks

The resulting loop graph must be explicit and durable.

### Loop execution

Loops execute against explicit plan nodes. The transcript should make clear:

- which loop is active
- what it is exploring
- what evidence or outputs it is collecting
- whether more loops are being queued
- whether user input is needed

### Consolidation

Loop results update the durable artifacts:

- PRD or spec refinements
- plan adjustments
- todo changes
- new subplans
- newly queued loops

Execution is iterative, not one-pass.

### Completion or blocker

At the end of every cycle, Ralphception must state one of:

- completed result
- current findings and next step
- blocked on a specific user answer
- blocked on a specific system or runtime issue

## Shell And UX Contract

### Scrollback-first transcript

The primary transcript should live in normal terminal scrollback, not inside a boxed viewport. The terminal’s own scrollback is the main history surface.

The active shell should only own:

- session header or context line
- current live status region
- composer
- blocker or waiting indicators

The transcript contract must explicitly distinguish between scrollback history and live status chrome.

- **scrollback transcript**
  - user messages
  - assistant reasoning summaries that materially advance understanding
  - durable loop start and loop completion messages
  - command or tool results that matter for understanding the work
  - artifact-write and artifact-update messages
  - blocker explanations
  - settled outcome summaries
- **live status region**
  - current active loop or plan node
  - ephemeral progress counters
  - short-lived “currently waiting on ...” signals
  - active worker labels

Ephemeral progress should stay in the live region unless one of these becomes true:

- it changes the user’s understanding of what Ralphception decided
- it creates a blocker
- it updates or supersedes an authoritative artifact
- it completes or fails a meaningful unit of work

At that point it must be promoted into durable transcript scrollback.

### Continuous live narration

Ralphception must keep narrating what it is doing as intake, planning, and loops run. The user should always be able to tell:

- what stage is active
- what loop or plan node is active
- what it is waiting on
- whether it needs user input
- whether it settled the last chunk of work

The shell should not emit every heartbeat into scrollback. Instead:

- the live region carries fast-changing in-progress state
- scrollback receives stable, meaningful milestones
- a long-running loop must still emit periodic durable progress summaries if it runs long enough that silence would be confusing

### Clear settled outcomes

Major transitions should produce durable transcript entries rather than transient inline status only.

### Conversation remains primary

The composer remains the primary interface. The user should feel they are in a continuous Codex-like conversation, but the content is orchestration rather than general-purpose chat.

### Artifacts are always surfaced

When Ralphception writes or updates durable artifacts, it should say so explicitly and identify the authoritative artifact set for the current task.

## Orchestration Model

There is no evidence that `~/code/codex` itself defines a “Ralph loop” feature. Ralphception therefore needs to define the term clearly in product terms.

For Ralphception, a Ralph loop should mean:

- an execution unit derived from durable planning artifacts
- with a stated objective
- a defined exploration strategy
- explicit stop conditions
- an output contract
- and a consolidation target

The orchestration model is:

### Phase 1: Socratic shaping

Clarify the task until it is well formed enough to plan.

### Phase 2: Durable control artifacts

Write intake summary, PRD, loop plan, execution plan, and todos.

### Phase 3: Plan graph

Build a durable plan graph:

- root plan
- optional subplans
- dependency edges
- completion criteria

### Phase 4: Loop graph

Attach loop definitions to plan nodes:

- primary loop
- subloops
- parallel loop families
- recursive “loops of loops” where justified

### Phase 5: Consolidation and replanning

Feed loop results back into artifacts, then spawn new loops or close plan nodes accordingly.

This makes Ralphception a plan-driven loop orchestrator rather than a generic agent runner.

### Parallel and recursive loop control rules

Parallel and recursive loop orchestration is first-class, but it needs explicit control rules.

Each loop must declare:

- `loop_id`
- `task_id`
- `plan_node_id`
- `parent_loop_id` or `null`
- objective
- stop conditions
- output contract
- target artifact revisions
- merge strategy

Parallel loop families may run concurrently only when:

- their target artifacts do not overlap, or
- they write proposals into separate loop outputs that are later consolidated by a parent node

The default merge policy should be proposal-first, not direct overwrite:

- child or parallel loops write findings and proposed artifact changes
- the parent consolidation step decides what becomes authoritative

Failure propagation rules should also be explicit:

- a child loop failure blocks only its plan node by default
- a parent plan node may choose to retry, replace, or abandon that child branch
- parent task completion is impossible while required child nodes remain blocked

Recursive expansion should be gated:

- Ralphception may spawn subplans or loop families when the current plan explicitly calls for decomposition, or when new evidence shows the current node is too broad
- spawning a new subplan should create a durable record explaining why the decomposition happened

## Prompting And Blockers

The recent LLM-native prompt work remains directionally correct and should stay aligned with this product reset.

Prompt requests should still be:

- conversational
- durable
- explicit about what the system needs

But they must sit inside the larger artifact-first orchestration model.

Examples:

- intake clarification
- approval to revise a plan
- confirmation to fork a subplan
- resolution of a failed loop
- confirmation of a destructive recovery path

The transcript should explain the blocker, and the shell should visibly show that the system is waiting on the user.

## Error Handling And Completion

### Never silent

If any work remains unresolved, Ralphception must not appear idle. It must show one of:

- active work underway
- waiting on background work
- waiting on user clarification
- blocked on approval or review
- blocked on system or runtime failure

### Every pause is explained

If execution pauses, the transcript must say:

- what plan node or loop paused
- why it paused
- what is needed to continue

### Every loop settles visibly

When a loop completes, the transcript must summarize:

- what it did
- what artifacts it updated
- what the next step is
- whether more loops are queued

### Failures become durable state

A failed loop should:

- write failure state into durable runtime artifacts
- explain the failure in transcript
- either retry automatically, ask the user, or mark the plan node blocked

### Resume reopens active context

On restart, Ralphception should reopen directly into the current task, current artifacts, current plan node, and current blocker or waiting state.

## Implementation Phasing

This should be implemented in two major phases.

### Phase 1: Inline shell and transcript reset

Goals:

- remove the boxed transcript viewport model
- move to scrollback-first inline UX
- keep live narration visible
- make settled outcomes explicit
- eliminate silent idle-looking states

This is the first phase because the current shell model is fundamentally wrong even before deeper loop orchestration changes.

Phase 1 still needs a minimum runtime-to-shell contract. It cannot wait for the full orchestrator rewrite.

The minimum transitional event/state interface for Phase 1 should include:

- current task label
- current plan node label
- current loop label if one exists
- current blocker state
- current waiting state
- durable milestone messages
- artifact-write notifications
- completion and failure notifications

Phase 1 is not complete unless the shell can render those signals from the existing runtime without regressing into vague or silent status.

### Phase 2: Artifact-first Ralph-loop orchestrator

Goals:

- make Socratic intake the true default entry path
- always write durable artifacts before execution
- introduce explicit plan graph and loop graph state
- execute loops from those artifacts
- support nested and parallel loop structures

This is the second phase because it changes the product core and should be built on the correct shell contract.

Phase 2 replaces the transitional contract with the true task, plan, artifact, and loop graph runtime model.

## Acceptance Criteria

Ralphception should not be considered done until all of the following are true.

### Shell acceptance

- `uv run ralphception` uses an inline scrollback-first shell
- transcript history is not trapped inside a tiny boxed viewport
- the active shell region only owns live context, not all history
- the user can rely on normal terminal scrollback to inspect earlier work

### Artifact acceptance

- every real task starts with Socratic intake
- every real task writes durable intake, PRD or spec, plan, loop plan, and todos before real execution
- those artifacts are updated as work progresses

### Orchestration acceptance

- Ralphception executes explicit Ralph loops derived from durable plans
- loops can be parallelized
- larger efforts can create plans of plans and loops of loops
- loop results consolidate back into authoritative artifacts
- incoming user messages are correctly classified as blocker replies, in-task follow-ups, task revisions, or new task requests
- ambiguous user messages trigger clarification instead of silently creating the wrong orchestration branch
- parallel loop outputs follow proposal-first consolidation rather than direct conflicting overwrite
- authoritative artifact revisions advance only through explicit consolidation steps
- child loop failures propagate to the correct plan node without silently invalidating unrelated branches

### UX acceptance

- the shell continuously narrates what it is doing
- it never silently stalls
- every pause is explained
- every completion or partial completion settles visibly in transcript
- the user always knows whether the system is working, waiting, blocked, or complete

### Long-running acceptance

- reopening Ralphception restores the current orchestration context
- the user can continue multi-hour or multi-day work without losing task continuity

## Testing Strategy

The implementation plan should include verification for both phases.

### Shell verification

- transcript durability under long-running output
- normal terminal scrollback preserved
- active shell region remains stable while history accumulates
- waiting and blocker states stay visible
- settled outcome messages always appear

### Orchestration verification

- Socratic intake writes durable intake artifacts
- PRD, plan, loop plan, and todos are always created before loop execution
- loop planner produces explicit loop definitions
- loop executor runs multiple loops and consolidates outputs
- nested plan and loop structures persist correctly
- resumed sessions reopen into the current task and loop context
- message classification tests cover:
  - blocker reply versus new task
  - in-task follow-up versus task revision
  - ambiguous message requiring clarification
- parallel loop verification covers:
  - proposal-first merge behavior
  - authoritative artifact revision updates
  - failure propagation for child loops
  - overlap rejection or staged consolidation for conflicting outputs

### End-to-end verification

At least one real end-to-end scenario should prove:

1. initial broad request
2. Socratic intake
3. durable artifact creation
4. loop planning
5. one or more Ralph loops running
6. consolidation
7. explicit completion or blocker state

That scenario is the real bar for “Ralphception drives a Ralph loop correctly.”
