# Shared Runtime Frontends Design

Date: 2026-03-20
Status: Draft for review

## Summary

`ralphception` should stop treating the Textual UI and the current `headless` supervisor as separate runtimes. There should be one long-running runtime supervisor that owns startup, recovery, review gates, planning, execution fan-out, merge, audit, and reopen loops. The user-facing entrypoints should instead be two frontends over that single runtime:

- a full Textual TUI frontend
- a traditional terminal frontend that streams logs and blocks for input only when human interaction is required

This is a greenfield correction, not an incremental compatibility exercise. Breaking CLI and internal API changes are allowed if they reduce the chance that the TUI and terminal paths drift again.

## Problem Statement

The current codebase has two different control flows:

- `uv run ralphception` resolves startup, review, or dashboard mode through the Textual launch path in `src/ralphception/app.py`
- `uv run ralphception headless` runs a separate mission supervisor in `src/ralphception/headless.py`

Those paths overlap conceptually but not structurally. As a result:

- recovery, startup, review, and dashboard semantics are not actually shared
- behavior can diverge across frontends
- bugs that appear in the TUI are not necessarily reproducible through the headless path
- the product shape described for Ralphception, one outer loop that owns nested inner loops until completion, is split across two implementations instead of embodied once

This split is already causing confusion. The TUI appears to "resume something" because it rebuilds a dashboard state from durable files, while the headless path uses a different orchestration model. That is the wrong abstraction boundary.

## Goals

- Create one long-running runtime supervisor that is the only orchestrator for a root mission.
- Make the TUI and traditional terminal modes functionally identical at the runtime level.
- Ensure both frontends can start from bootstrap, continue through review and recovery, and remain attached until terminal completion.
- Preserve the current durable repo-local and XDG-backed state model.
- Keep the traditional terminal frontend log-oriented and prompt-oriented rather than REPL-oriented.
- Make runtime bugs reproducible without requiring Textual.

## Non-Goals

- Preserving the current `headless` implementation as a first-class architecture.
- Building a daemon/client architecture in this slice.
- Designing a third fully non-interactive automation mode in the same refactor.
- Freezing the exact existing CLI names if cleaner naming is needed.

## Product Model

Ralphception is a single long-running mission process:

1. intake and startup
2. spec generation and review
3. planning and execution-bundle review
4. execution fan-out into child loops
5. verification and merge
6. audit and reopen
7. terminal completion or failure

The process should remain attached until one of these happens:

- the mission completes successfully
- the mission reaches terminal failure
- the user interrupts it explicitly

The process should not print a snapshot and exit as the default runtime behavior.

## Architecture

### 1. Runtime Supervisor

Introduce a `RuntimeSupervisor` service as the only top-level orchestrator.

Responsibilities:

- resolve workspace bootstrap state
- reconstruct durable runtime state
- run recovery and lease handling
- drive the mission loop through startup, review, execute, merge, and audit stages
- request human input through a frontend interface when required
- emit structured runtime updates to the active frontend
- exit only on terminal completion, terminal failure, or explicit interrupt

This supervisor replaces the current split between `resolve_runtime_view(...)`, dashboard auto-advancement, and `run_headless_mission(...)`.

### 2. Frontend Interface

Introduce a small frontend contract that the supervisor depends on instead of calling Textual or printing directly.

Required capabilities:

- emit lifecycle and event messages
- render current status summaries
- prompt for bootstrap inputs
- prompt for review decisions
- prompt for recovery decisions
- announce completion or failure

The frontend should not decide runtime behavior. It should only render state and return user input.

### 3. Two Concrete Frontends

#### Textual Frontend

The TUI remains the modern interactive surface:

- stage tree
- detail panes
- event feed
- structured review UI
- command shortcuts when they remain useful

It should become a presentation layer over supervisor state rather than a place that owns parallel runtime decisions.

#### Terminal Frontend

The traditional terminal frontend should:

- stream textual progress continuously
- print stage transitions and notable child-loop events
- display human-readable review and recovery summaries
- block on focused prompts when user input is required
- remain attached until terminal completion

It should feel like a classic long-running terminal tool, not a REPL.

## Interaction Model

### Bootstrap

If the workspace is not bootstrapped:

- TUI renders the startup screen
- terminal mode prompts for seed prompt and optional source repo paths inline

Both paths produce the same durable startup artifacts.

### Review Gates

If the runtime needs approval or recovery input:

- TUI renders a dedicated review surface
- terminal mode prints the relevant artifact summary or diff summary and blocks on a targeted prompt

Examples:

- approve or reject a spec review
- approve or reject an execution bundle
- choose retry, restart, or replace for a blocked or lost run

These should call the same underlying runtime actions.

### Autonomous Running

When no human input is required:

- both frontends remain attached to the same supervisor
- both continue until the mission reaches a terminal state

The terminal frontend does not become a separate "batch" runtime. It is simply a different surface over the same mission.

## State Model

The existing durable state remains authoritative:

- repo-local `.ralphception/`
- XDG-backed lease state
- run records, approvals, bundles, findings, merge records, checkpoints, and verification results

The supervisor must own all writes to these files. Frontends may read supervisor-provided state but should not independently derive runtime transitions by poking durable files.

## Migration From Current Code

### 1. Retire `headless` as an architectural concept

The current `src/ralphception/headless.py` should not remain the separate orchestrator. Its useful pieces should be absorbed into the shared runtime where appropriate:

- durable loop progression
- artifact prompt contracts
- fake-session-driven mission execution
- terminal-friendly summaries

### 2. Move launch logic into the supervisor

The current launch branching in `src/ralphception/app.py` should become frontend selection plus supervisor startup, not separate runtime resolution.

That means:

- startup/review/dashboard should become runtime states visible to the supervisor and frontend
- TUI should not own the runtime loop by itself
- terminal mode should not own a parallel mission loop by itself

### 3. Rename CLI surfaces

Recommended CLI shape:

- `ralphception`
  Launch the TUI frontend
- `ralphception terminal`
  Launch the traditional terminal frontend
- `ralphception resume`
  Either remain as a narrow repair tool or become a thin wrapper into supervisor resume mode

The current `headless` command should either:

- be renamed to `terminal`, or
- be reserved for a later truly non-interactive automation mode

### 4. Keep fake-session support at the supervisor layer

The deterministic fake Codex backend is still valuable. It should attach to the shared supervisor so:

- TUI and terminal frontends can both be tested against the same fake runtime
- runtime bugs can be reproduced without Textual

## Error Handling

- If recovery detects corrupted event logs or invalid checkpoints, the supervisor should surface a recovery-blocked state through both frontends.
- If a frontend disconnects or crashes, durable mission state must remain resumable.
- If the terminal frontend is interrupted, rerunning it should reattach to the same durable supervisor state model and continue from the correct next input or autonomous step.
- If a child run fails or loses session state, both frontends should present the same recovery choices and the same recommended action.

## Testing Strategy

The refactor should shift testing emphasis from frontend-specific orchestration to shared runtime behavior.

Required coverage:

- supervisor bootstrap flow with both frontends
- supervisor review flow with both frontends
- supervisor autonomous mission completion with fake backend
- resume and repair behavior through the shared supervisor
- parity tests proving that TUI and terminal frontends observe the same runtime transitions on the same workspace state
- terminal frontend prompt tests for bootstrap and review decisions
- Textual frontend tests proving that rendering no longer owns runtime state transitions

Regression priority:

- the current dashboard refresh-loop bug should remain covered
- the current self-host authoritative-root-shift bug should remain covered
- terminal mode should be able to reproduce TUI-visible runtime bugs because they now share the same supervisor

## Implementation Direction

Recommended sequencing:

1. Create the shared supervisor and frontend protocol.
2. Move the terminal-oriented mission loop onto the supervisor first, because it is easier to observe in tests.
3. Rebuild the Textual entrypoint as a frontend over that supervisor.
4. Remove duplicated orchestration once parity tests pass.

This sequencing intentionally prefers runtime truth first and UI second.

## Open Naming Decision

The design assumes "terminal frontend" is the primary name for the traditional interface. If the CLI should preserve `headless` temporarily as an alias for transition, that can be handled during implementation, but the architecture should no longer be described as a separate headless runtime.
