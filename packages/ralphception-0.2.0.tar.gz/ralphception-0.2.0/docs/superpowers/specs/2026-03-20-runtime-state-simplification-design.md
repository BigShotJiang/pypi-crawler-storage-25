# Runtime State Simplification Design

Date: 2026-03-20
Status: Approved for implementation

## Summary

Ralphception currently treats repo-local `.ralphception` files as both product runtime state and checked-in project content. That is the wrong boundary. The runtime should own ephemeral mission state and clean it up freely, while checked-in project fixtures and docs should live somewhere else. At the same time, `ralphception terminal` should fail immediately if no real session backend is available instead of degrading to a dashboard-style no-op.

## Problems

### 1. Runtime State Is Tracked In Git

This repo tracks files like:

- `.ralphception/events/run-root.jsonl`
- `.ralphception/runs/run-root/startup.json`

That makes cleanup incorrect by construction:

- the runtime deletes `.ralphception`
- git restores tracked files from `HEAD`
- old missions reappear
- prompt override and completion cleanup become unreliable

### 2. Terminal Mode Pretends To Run Without A Backend

When no session backend exists, the mission loop returns `dashboard` mode instead of failing. For a user who invoked terminal mode to do real work, that looks like progress even though no turns can execute.

## Goals

- Make repo-local `.ralphception` mission state ephemeral and untracked.
- Preserve only intentional checked-in project docs by moving them out of `.ralphception`.
- Make `ralphception terminal` fail fast with a clear error when no live backend is configured.
- Keep the fake backend path working for tests and local verification.

## Non-Goals

- Introducing a new archival store for completed missions.
- Preserving compatibility for repos that intentionally committed runtime state.
- Building a separate readonly dashboard fallback for terminal mode.

## Design

### Runtime State Boundary

`.ralphception/` becomes runtime-owned and disposable:

- runs
- events
- plans/specs generated for missions
- approvals
- findings
- merge and verification artifacts
- config

If the project wants checked-in bootstrap/reference content, it should live under `docs/` or another intentional project directory, not inside `.ralphception/`.

### Git Policy

- add `.ralphception/` to `.gitignore`
- remove tracked runtime files from the index
- keep `.worktrees/` ignored as it already is

### Terminal Backend Availability

If `ralphception terminal` or `ralphception headless` is launched without:

- a live session backend, or
- `--fake-session-manager`

the command should exit non-zero with a direct error like:

`No Codex session backend is available for terminal execution. Install/configure the backend or use --fake-session-manager for deterministic local verification.`

This should happen before runtime output implies a real mission is running.

### TUI Implication

The TUI can still render startup/review/dashboard state, but when it tries to drive the mission loop without a backend it should surface the same underlying runtime error rather than silently acting productive.

## Testing

- unit/integration coverage for terminal fail-fast behavior without backend
- integration coverage for completed mission cleanup with untracked `.ralphception`
- real CLI check that this repo no longer resurrects old mission state from git
