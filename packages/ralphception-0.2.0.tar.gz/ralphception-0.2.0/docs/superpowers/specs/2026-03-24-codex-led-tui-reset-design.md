# Codex-Led TUI Reset Design

## Goal

Restore `ralphception` to a human-facing TUI that is led directly by `~/code/codex/codex-rs/tui` rather than by Ralphception-specific shell inventions, while keeping `ralphception exec` as the separate non-interactive path.

## Product Contract

- `ralphception` is the human mode.
- `ralphception` should launch into the same shell model as Codex TUI, not a custom startup screen or boxed dashboard replacement.
- The first visible state is the Codex idle shell waiting for user input in the composer.
- Ralphception-specific orchestration appears inside the Codex transcript and bottom pane model.
- `ralphception exec` remains the scriptable non-interactive path analogous to `codex exec`.
- `exec` skips the Socratic back-and-forth, but still writes the same durable artifacts and runs the same loop pipeline.

## Non-Goals

- Do not keep the current inline shell as the primary human UI.
- Do not invent alternate Ralphception-only interaction modes that Codex TUI does not have.
- Do not preserve the old startup forms, mission-first chrome, or dashboard-style layouts.

## Shell Requirements

The human shell should follow Codex TUI behavior from `~/code/codex/codex-rs/tui`:

- alternate-screen TUI by default
- Codex-style session header, transcript surface, bottom pane, footer, slash-command model, overlays, and transcript/history behavior
- the same waiting/working/blocker grammar as Codex
- no separate Ralphception bootstrap screen

Ralphception-specific text should only adapt the content of the transcript, labels, and overlays, not the shell structure.

## Startup And Intake

- Launch to the normal Codex idle shell.
- The first user prompt always starts a Socratic intake loop inside the normal transcript.
- Intake happens as ordinary assistant and user messages.
- Ralphception writes durable artifacts only after intake is sufficient:
  - intake summary
  - PRD
  - execution plan
  - loop plan
  - todos
- Artifact creation is narrated in the transcript like Codex tool/progress activity.

## Mode Split

### Human Mode

- `ralphception`
- live Codex-led TUI
- conversational intake
- artifact-first orchestration
- long-running Ralph-loop execution in the live shell

### Exec Mode

- `ralphception exec`
- non-interactive and scriptable
- no Socratic intake loop
- still writes durable artifacts from the provided prompt
- still runs the same orchestration pipeline

## Architecture Reset

### Default Entry Path

`src/ralphception/app.py` should stop routing `run_app()` through `runtime.inline_shell`. The default interactive path should construct and run the TUI app from `src/ralphception/tui/`.

### TUI Ownership

The TUI path should be the only shipped human UI. `src/ralphception/runtime/inline_shell.py` becomes either:

- an implementation detail that exists only for Codex-equivalent non-alt-screen support, if needed, or
- dead code to remove if the shipped path no longer uses it.

### Shared Runtime

The runtime beneath both modes remains shared:

- prompt resolution
- artifact pipeline
- loop planning
- loop execution
- resume and recovery

Only the human frontend changes.

## Acceptance Criteria

- `uv run ralphception` launches the Codex-led TUI instead of the inline event logger.
- the first screen is the normal Codex idle shell waiting for input
- the first prompt enters Socratic intake in the TUI transcript
- no Ralphception-specific startup form or dashboard appears
- transcript, overlays, and bottom pane behave like Codex TUI
- `uv run ralphception exec "..."` remains non-interactive and artifact-first
- the repo no longer ships two competing human UIs
