# TUI Core Shimmer Parity Design

## Goal

Make Ralphception's busy-status shimmer match Codex by porting the behavior into low-level `tui_core` primitives instead of keeping a near-match approximation inside the Codex-port layer.

The visible parity targets are:

- the busy header text uses the same shimmer timing and intensity band as Codex
- the leading busy glyph follows Codex's separate spinner path instead of reusing the shimmer algorithm
- shimmer colors come from the terminal's default palette and color capability, not from Ralphception's surfaced message background heuristic
- the low-level primitives live in `tui_core`, while `codex_tui` remains the higher-level Codex-port composition layer

## Current Problem

`src/ralphception/codex_tui/status.py` currently owns both the low-level animation behavior and the higher-level status-line composition. That implementation is close but not a literal port:

- it shimmers the leading `•`, while Codex uses a separate spinner primitive for that glyph
- it uses a narrower cosine band than Codex
- it derives colors from the surfaced background/lightness heuristic instead of queried terminal default foreground/background colors
- its truecolor and fallback styling rules do not match Codex exactly

These differences are small in code but visible in tmux, especially when switching between dark and light terminals.

## Codex Reference Behavior

The relevant Codex reference implementation is split across three seams:

- `codex-rs/tui_app_server/src/shimmer.rs`
- `codex-rs/tui_app_server/src/terminal_palette.rs`
- `codex-rs/tui_app_server/src/status_indicator_widget.rs`

Important behaviors to preserve:

- shimmer timing is synchronized to process start
- `padding = 10`
- `sweep_seconds = 2.0`
- `band_half_width = 5.0`
- truecolor mode blends from terminal default background toward terminal default foreground and applies bold styling
- non-truecolor mode falls back to dim / normal / bold buckets
- the leading glyph comes from `spinner(...)`, not `shimmer_spans(...)`

## Layering

### `tui_core`

`tui_core` should own the low-level reusable behavior:

- terminal palette querying and caching
- terminal color-level detection
- shimmer span generation
- spinner glyph generation for busy status rows

This layer should know nothing about blocker prompts, Ralphception runtime state, or transcript semantics.

### `codex_tui`

`codex_tui` should compose those low-level primitives into the Codex-style busy row:

- leading spinner glyph
- shimmered header text
- elapsed/interrupt segment
- optional inline context

That keeps Codex-parity UI behavior in the abstraction layer above the low-level terminal primitives.

## Proposed Implementation

### 1. Add terminal palette primitives to `tui_core`

Introduce a low-level module that can answer:

- current terminal default foreground color
- current terminal default background color
- current stdout color capability (`truecolor`, `256`, `16`, `unknown`)

The palette query should use the same terminal-query path already used for default background setup where possible, extended to capture both foreground and background. The result should be cached and resettable for tests.

### 2. Port Codex shimmer into `tui_core`

Create a low-level shimmer helper that accepts:

- text
- optional timestamp override for tests
- palette/capability context

It should reproduce the Codex algorithm directly:

- process-synchronized elapsed time
- same sweep constants
- same cosine band width
- same truecolor vs fallback styling decisions

### 3. Port the busy glyph separately

Add a low-level spinner helper for the status glyph instead of reusing shimmer for the bullet. The goal is not a generic animation library; the goal is parity with the Codex busy-row leading symbol.

### 4. Thin the Codex-port adapter

Update `src/ralphception/codex_tui/status.py` so it delegates shimmer/spinner generation to `tui_core` and only performs line composition.

## Testing Strategy

### Low-level unit tests

Add tests that prove:

- shimmer keeps the same visible text while changing style
- shimmer uses the Codex band width and style thresholds
- shimmer behavior differs correctly between truecolor and fallback color levels
- spinner glyph behavior is not implemented by the shimmer helper

### Integration tests

Keep and extend the current Codex-port tests so the rendered busy row still reads:

- `• Working (...)`

while sourcing its animation/style behavior from the new core primitives.

### tmux verification

Manually verify in tmux against `~/code/codex` in both dark and light terminal themes:

- busy row shimmer feels synchronized and comparable
- leading glyph behavior matches Codex more closely than the existing shimmer-reused bullet
- no regressions to footer spacing, cursor placement, or resize handling

## Success Criteria

This slice is successful when:

- the low-level shimmer logic lives in `tui_core`
- the leading glyph is no longer produced by the shimmer helper
- dark/light terminals both use terminal-palette-aware shimmer colors
- unit and tmux checks show the busy row is materially indistinguishable from Codex for this behavior
