# LLM-Native Conversational Runtime Design

## Summary

Ralphception should feel like Codex, but with Ralph loop orchestration, parallelization, and runtime rails layered underneath. The shell can still use compact blockers or quick actions as accelerators later, but the primary interaction contract should be fully conversational: when the runtime needs a constrained decision, the assistant explains the situation in transcript, the user replies in natural language, and the LLM resolves that reply into one of the runtime's allowed actions.

This is a hard architecture cutover. Ralphception should stop using synchronous frontend callbacks such as `prompt_startup`, `prompt_review`, and `prompt_conflict` as the main decision path. Those callbacks force the runtime to think in terms of workflow-controller screens instead of a continuous Codex-style conversation.

The replacement is a prompt-state protocol:

- the runtime creates a `PendingPrompt`
- transcript receives a committed assistant/system message that explains the blocker
- the shell enters a clear `waiting_on_prompt` state but keeps the normal composer active
- the user replies conversationally
- the LLM resolves that reply into one allowed action, or asks for clarification
- the runtime records the resolution and continues the blocked workflow

That gives Ralphception one interaction grammar for everything: normal turns, blockers, resume/fresh decisions, review approvals, recovery, Ralph loop steering, and subagent coordination.

## Product Goals

### Codex-style continuity

The user should stay inside one continuous conversation. Ralphception should not switch to a separate “decision mode” or “review mode” just because the runtime needs a constrained choice.

### LLM-native orchestration

Ralphception is an orchestrator. The runtime should provide rails and allowed actions, but the assistant should remain the conversational surface. The model interprets the user’s reply and advances the orchestration.

### Clear but lightweight blocking

It is acceptable for Ralphception to have non-conversational blockers internally, but the user-facing experience should remain conversational. The transcript must clearly explain what is needed, and the shell must make it obvious that the runtime is waiting on the user.

### Ralph loop identity

Ralph loops, web research, and parallel orchestration should feel like native Codex-style assistant behavior rather than a separate dashboard workflow. The assistant explains what it is doing, the loop emits durable transcript activity, and the user can steer it by replying conversationally.

## Problem Statement

Ralphception’s current TUI has become much more Codex-like, but the runtime beneath it still uses a callback-style frontend contract:

- `prompt_startup(...) -> StartupDecision`
- `prompt_review(...) -> ReviewDecision`
- `prompt_conflict(...) -> MissionConflictDecision`

That callback shape leaks into the product surface. Even when the TUI looks like Codex, the runtime still thinks in terms of “ask the frontend for a structured decision,” which makes blocker handling feel less native than Codex.

The repository already contains the outline of the right direction in `src/ralphception/protocol/events.py`, with event types such as:

- `PromptRequestedEvent`
- `PromptResolvedEvent`
- transcript delta/committed events
- subagent and session-thread events

But the live runtime path does not use that protocol as the actual decision contract. The runtime still depends on synchronous prompt callbacks. As a result:

- blocker handling feels separate from the main conversation
- the model is not the primary interpreter of user replies
- the shell can render input-needed/review surfaces, but they are not yet the true runtime control path

## Product Contract

### One interaction model

The normal composer is the primary way the user interacts with Ralphception:

- ordinary instructions
- blocker resolution
- follow-up clarifications
- continuing paused loops
- steering subagents or Ralph loops

There should not be a separate mental model for “chat mode” versus “decision mode.”

### Conversational blockers

When the runtime needs a constrained decision, the assistant or system should write a committed transcript entry that explains:

- what happened
- what Ralphception is waiting on
- what kinds of responses are valid

The shell should also visibly show that it is waiting on the user, but the user’s response should go through the normal composer.

### Constrained LLM resolution

The LLM should interpret user replies into one of the runtime-provided allowed actions. It should not invent arbitrary control flow.

This means the runtime remains safe and structured, while the surface remains LLM-native.

### No silent stalls

The shell must never look idle when a prompt is pending. Transcript and shell chrome should make the blocked state explicit.

## Core Architecture

### Pending prompt state

The runtime should own prompt state per session thread, not one global prompt for the entire session. Ralphception needs to support parallel subagents and blocked child threads without collapsing them into one session-wide decision object.

Every interactive workspace session should always have a root thread identity, even before bootstrap creates the durable root run. Launch-time prompts and the first user message attach to that root thread.

Each thread may have at most one active pending prompt:

- `thread_id`
- `owner_run_id` or `null` for pre-bootstrap root-thread prompts
- `prompt_id`
- `prompt_kind`
- `title`
- `question`
- `allowed_actions`
- `context`
- `status`
- `blocked_continuation`

Multiple threads may have pending prompts at the same time. The shell should surface the prompt for the active thread while still preserving blocked state for the other threads in durable session state.

This thread-scoped prompt state should be durable and persist in `.ralphception` alongside existing runtime/session state.

### Prompt resolution

The runtime should also own a durable prompt-resolution record:

- `thread_id`
- `owner_run_id` or `null` for pre-bootstrap root-thread prompts
- `prompt_id`
- `action`
- `raw_user_reply`
- `confidence`
- optional clarification data

Resolution is a runtime fact, not a TUI-only behavior.

### Transcript-first rendering

When a prompt becomes pending:

- transcript receives a committed explanation cell
- shell enters `waiting_on_prompt`
- composer remains active

When the prompt resolves:

- transcript receives a committed resolution cell
- blocked workflow resumes
- assistant continues the loop naturally

Child-thread prompts resolve in the child thread that owns them. They do not implicitly escalate to the parent thread or rebind when the user switches threads. If the parent thread needs awareness, the runtime should emit a transcript/status summary there, but the actual prompt remains owned by the original thread.

Switching the active thread changes which prompt, if any, the composer targets for conversational resolution.

Prompt transcript authorship should be explicit:

- initial blocker explanations are runtime-authored system messages derived from durable prompt state
- settled action acknowledgements are runtime-authored system messages derived from durable prompt resolutions
- clarifying follow-ups for ambiguous user replies are model-authored assistant messages emitted by the prompt-resolution layer and persisted as normal transcript turns

### Replacement runtime/shell protocol

The hard cutover should replace the callback API with one explicit protocol:

- shell to runtime:
  - `SendUserMessageAction(thread_id, text)` for every user turn, including blocker replies
  - `SwitchThreadAction(thread_id)` for navigation
  - `UpdateBootstrapSourcesAction(thread_id, repo_paths)` for pre-bootstrap root-thread source repository updates
- runtime to shell:
  - `SessionHydratedEvent(root_thread_id, active_thread_id, threads, transcript_snapshot, pending_prompts, deferred_inputs, status_context, launch_classification)`
  - transcript delta/committed events for assistant, system, and command output
  - `PromptRequestedEvent(thread_id, owner_run_id | null, prompt_id, prompt_kind, title, question, allowed_actions, context_summary)`
  - `PromptResolvedEvent(thread_id, owner_run_id | null, prompt_id, action, raw_user_reply)`
  - status/thread update events

The primary conversational path should not require `ResolvePromptAction`, `ReviewDecisionAction`, or other shell-owned structured decision actions. The runtime should interpret the next user turn itself when a prompt is pending.

The reserved root thread is the owner for:

- launch-time `resume_session`
- launch-time `broken_resume_recovery`
- the first ordinary user message in a fresh workspace

Before bootstrap, the root thread exists without a bound durable run. The first ordinary root-thread message creates the startup record, intake artifact, root run, and durable run binding for that same thread before the first orchestration turn begins.

For a fresh workspace, the shell learns that reserved root thread identity from `SessionHydratedEvent` before the user sends the first message. That is the `thread_id` used by the first `SendUserMessageAction`.

### Session hydration contract

On shell attach or reopen, the runtime must hydrate the shell from durable state before live events begin. Live events alone are not enough.

The hydration payload should include:

- root thread identity and active thread identity
- thread list and thread summaries
- committed transcript history for visible threads
- current active transcript tail, if any
- pre-bootstrap source repository context for the root thread, if bootstrap is not yet complete
- pending prompt state for each blocked thread
- deferred input queue for each thread
- footer/status context needed to render `waiting_on_prompt`, running, or idle state

After hydration completes, the runtime may resume streaming live transcript, prompt, and status events.

The shell must not accept ordinary user input until hydration completes, because hydration is what defines the active thread, the visible transcript backlog, and any pending prompt ownership.

### Persistence and resume semantics

Prompt state and blocked-workflow continuation need a stable ordering:

1. persist the pending prompt together with the blocked continuation reference for its owner thread
2. emit the committed transcript explanation and `PromptRequestedEvent`
3. if the user sends a new same-thread instruction instead of a resolvable answer, persist it on that thread's deferred-input queue and emit an assistant/system explanation that the blocker must resolve first
4. when the user replies with a resolvable answer, persist the raw reply and the resolved action
5. emit `PromptResolvedEvent`
6. resume the exact blocked continuation for that owner thread/run
7. once that continuation reaches its next stable yield point, dequeue and execute deferred same-thread input in FIFO order

The runtime must never resume a blocked workflow from shell memory alone. Prompt state and continuation ownership have to survive app restart and session resume.

### No synchronous prompt callbacks

The runtime/frontend contract should no longer depend on frontend methods that synchronously return decisions. The runtime should create prompt state and consume prompt resolutions instead.

## Prompt Types

The first hard-cutover version should support these prompt kinds:

### `resume_session`

Allowed actions:

- `resume`
- `start_fresh`

This prompt is only used when launch classification finds a resumable workspace session.

### `broken_resume_recovery`

Allowed actions:

- `start_fresh`
- `abort`

### `review_decision`

Allowed actions are prompt-instance specific.

For ordinary artifact approvals in the first cutover version, the supported action set is:

- `approve`

The previous `pause` behavior is intentionally removed as an explicit action. Leaving the prompt unresolved is the replacement for pausing.

### `workspace_conflict`

Allowed actions:

- `resume`
- `override`
- `abort`

### `recovery_decision`

Allowed actions:

- `resume`
- `retry`
- `restart`
- `replace`

The system should not turn ordinary conversation into a prompt. Prompts are only for constrained orchestration decisions.

Fresh startup is not a constrained prompt kind. A clean workspace should simply open the normal shell and wait for the first ordinary user instruction through the composer.

That first ordinary root-thread message becomes the durable bootstrap input. The runtime should create the startup record, intake artifact, and root run from that message, then bind the pre-bootstrap root thread to the new durable root run before the first orchestration turn begins.

Any pre-bootstrap metadata beyond the freeform root instruction is intentionally narrow in the first cutover. Optional source repositories remain an explicit shell/runtime affordance and are attached to bootstrap context before the first orchestration turn; they are not a separate constrained prompt type.

In the first cutover version, that source-repository affordance is `UpdateBootstrapSourcesAction` on the pre-bootstrap root thread, typically surfaced from a slash command such as `/source`. The runtime persists the updated source repository list immediately, exposes it again through hydration, and incorporates it into bootstrap context before the first orchestration turn begins.

## Action Semantics

Destructive prompt actions need durable, implementation-level meaning:

### `resume`

- preserve the existing session, thread graph, transcript history, pending prompt history, and run bindings
- continue the blocked continuation for the owner thread

### `start_fresh`

- clear the existing interactive-session marker and any pending prompt or deferred-input state attached to the superseded session
- clear bootstrap/startup state and transcript history for that superseded interactive session
- create a new fresh root-thread session context

### `override`

- supersede the currently active root session in the workspace
- preserve prior durable records only as historical artifacts, not as the live interactive session
- clear any pending prompts and deferred input owned by the superseded live session before starting the replacement session

### `restart`

- restart the owner workflow from its defined restart point inside the same interactive session
- preserve prior transcript history as settled historical context
- clear any pending prompt and deferred-input queue bound to the pre-restart blocked continuation

### `replace`

- create a replacement run for the blocked or failed owner workflow inside the same interactive session
- preserve transcript history and thread identity, but rebind future execution to the replacement run
- clear prompts and deferred input owned by the replaced blocked continuation

### `abort`

- leave the blocked workflow unresolved and do not start a replacement continuation
- persist the final aborted state and settled transcript message
- keep durable history available for later inspection, but do not treat the aborted continuation as resumable

## LLM Resolution Rules

### Strict actions, flexible language

The resolver should only return:

- one allowed action
- a clarification request

It should not invent a new action.

### Conversational input

The user should be able to type natural replies such as:

- “resume it”
- “start over”
- “approve that”
- “retry the step”

The model maps these into the allowed action set.

### Clarify instead of guessing

If the user reply is ambiguous, the model should ask a narrowing question instead of making a risky assumption.

### Higher bar for destructive actions

The resolver should require clearer intent for destructive actions such as:

- `start_fresh`
- `override`
- `restart`
- `abort`

than for low-risk actions like:

- `resume`
- `approve`
- `retry`

### Preserve raw reply

The runtime should store the raw user reply together with the chosen action. This improves observability and makes debugging resolution quality possible.

## Shell Behavior

### Pending prompt stays in transcript

The assistant/system message explaining the blocker is the primary visible artifact. Any compact blocker UI should be secondary, not primary.

### Composer stays active

The user replies through the normal composer. There is no special review input field or resume picker as the main control path.

When a thread has a pending prompt, the next composer submission is interpreted against that thread's allowed action set before it is considered a normal orchestration instruction.

If the reply clearly maps to one allowed action, the runtime resolves the prompt and continues.

If the reply is ambiguous, the assistant asks a clarifying follow-up and the prompt remains pending.

If the reply is unrelated to the pending prompt, the runtime should distinguish between three cases:

- shell/navigation intent such as thread switching: allowed immediately and does not resolve the prompt
- a new instruction for the same blocked thread: record it as deferred input for that thread, explain that the blocker must be resolved first, and keep the prompt pending
- unclear mixed input: ask a clarifying follow-up and keep the prompt pending

### Visible waiting state

Footer/status chrome should show that Ralphception is waiting on the user. The shell should not present as idle while a prompt is pending.

### Settled continuation

After the prompt resolves, transcript receives a short settled message, for example:

- “Resuming the previous session.”
- “Approved spec review.”
- “Starting fresh and clearing interrupted state.”

Then the runtime resumes the loop and the assistant continues naturally.

## Ralph Loop Integration

Ralph loops are part of ordinary orchestration, not a separate mode.

- the assistant decides when to start or steer Ralph loop work
- loop progress appears in transcript as durable activity
- if loop orchestration needs a constrained user choice, it creates a pending prompt
- the user answers in chat
- the runtime resolves the prompt and continues the loop

This makes Ralphception “Codex, but orchestrating Ralph loops.”

## Hard Cutover Plan

### Delete the old callback contract

Remove the synchronous decision methods from the runtime frontend contract:

- `prompt_startup`
- `prompt_review`
- `prompt_conflict`

### Introduce prompt-state ownership

Add durable thread-scoped prompt state, resolution state, and blocked-continuation ownership to the runtime/session model.

### Route user replies through prompt resolution

When the active thread has a pending prompt, the next composer submission is first evaluated as a reply to that thread's prompt. If there is no prompt pending for the active thread, the submission goes through the normal orchestration loop.

This first-pass resolution happens inside the runtime, not in the shell.

### Migrate blocker types

Convert these flows:

- launch resume gate
- broken resume recovery
- review approvals
- workspace conflict
- recovery decisions

to use the new prompt-state pipeline.

### Remove old UI-first blockers

Delete the current UI paths that assume the frontend is the primary source of decisions. Optional quick actions can come back later as accelerators, but not as the core contract.

## Acceptance Criteria

Ralphception is only done when all of the following are true:

- the normal composer is the primary interaction surface for both ordinary instructions and blocker resolution
- runtime blockers appear first as transcript explanations, not as special app modes
- the shell clearly shows when Ralphception is waiting on a user decision
- the LLM resolves user replies into one of the runtime-provided allowed actions
- ambiguous replies trigger conversational clarification instead of dead-end UI state
- multiple blocked threads may exist, but the active composer only resolves the active thread's prompt
- a clean workspace creates bootstrap state from the first ordinary root-thread message instead of a dedicated startup callback
- reopening the app hydrates pending prompts, deferred input, thread state, and waiting status from durable state before live events resume
- Ralph loops and subagents continue through the same conversation model
- the old callback-based runtime/frontend prompt contract is gone

## Non-Goals

This cutover does not require:

- removing every compact overlay or quick action from the shell forever
- turning every user instruction into a constrained prompt
- changing the product identity away from Ralph loop orchestration

The point is not “no structure.” The point is “structured orchestration through a Codex-native conversational surface.”
