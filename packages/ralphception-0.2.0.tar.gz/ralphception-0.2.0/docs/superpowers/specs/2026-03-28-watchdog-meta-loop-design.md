# Watchdog Meta-Loop Design

## Summary

Ralphception should not become "Codex, but with more turns." It should become a loop-of-loops orchestrator:

- Codex-like conversational threads and turns remain the local reasoning substrate
- Ralph loops remain the durable execution substrate
- a new watchdog meta-loop sits above both and keeps incomplete work moving when the root agent or user goes idle

The user's referenced "watchdog agents" idea is directionally better than Ralphception's current continuation model, but only if it is layered on top of the existing artifact-first Ralph loop engine instead of replacing it.

The right product identity is:

**Codex-style terminal interaction plus durable Ralph-loop execution plus a watchdog meta-loop that keeps incomplete work progressing, unsticks repetitive threads, and re-enters the loop without losing context.**

## What Ralphception Is Today

Ralphception already has the beginnings of the right execution substrate:

- startup intake produces a durable intake artifact
- headless execution uses durable stages:
  - `intake`
  - `spec`
  - `plan`
  - `execute`
  - `merge`
  - `audit`
- plan output becomes a `LoopGraph`
- `execute` launches child runs against explicit `LoopDefinition` contracts
- `audit` can reopen execution with a replacement child run
- conversational blockers already persist as:
  - `PendingPrompt`
  - `PromptResolution`
  - `DeferredInput`
  - `BlockedContinuationRef`

This matters because Ralphception is already more than a Codex wrapper. It already has durable plans, loops, merge safety, and reopen behavior.

## Where The Current System Is Weak

The current weakness is not lack of loops. It is lack of a durable meta-loop.

Today, continuation is still too dependent on the currently active agent turn:

- when a turn stops with "here are next steps", the system has no first-class runtime primitive for "keep going"
- unfinished work is mostly represented indirectly through:
  - transcript text
  - current stage
  - incomplete loop assignments
  - reopened audit state
- there is no impartial third-party continuation agent that can re-evaluate progress from outside the current rollout
- there is no first-class unsticking path beyond ordinary continuation or manual intervention
- compaction is not yet a runtime primitive Ralphception can deliberately use to recover from repetitive or bloated context

That is exactly where the watchdog idea is stronger than what we have now.

## How Ralphception Should Differ From Codex

Codex is fundamentally a thread-and-turn engine with good local capabilities:

- threads
- forks
- subagents
- rollback
- compaction
- approvals

Ralphception should use those ideas, but its higher-level product contract is different:

- durable artifacts are the control plane
- execution is broken into explicit Ralph loops
- progress should continue across many turns, runs, and subloops
- the system should decide when to keep going, reopen, compact, or ask for help

So the goal is not "port watchdogs from Codex."
The goal is:

**add a meta-loop that supervises artifact-first Ralph-loop execution the way Codex supervises individual threads and turns.**

## Evaluation Of The Watchdog Idea

### Better than the current continuation model

Yes, for three reasons:

1. It separates "doing the work" from "judging what should happen next."
2. It creates a durable way to keep progressing after the current agent naturally stops.
3. It makes compaction and unsticking explicit recovery tools rather than accidental side effects.

### Not better as a replacement for Ralph loops

No, if interpreted as "just keep spawning more Codex turns."

If Ralphception replaced its artifact-first stage and loop system with a generic watchdog that only keeps telling the root agent what to do next, we would lose the main thing that makes Ralphception special:

- durable plans
- durable artifacts
- explicit loop ownership
- merge-readiness contracts
- audit reopen behavior

The watchdog idea is best as a **meta-loop**, not as the primary execution model.

## Recommended Architecture

Ralphception should have three orchestration layers.

### 1. Conversational thread layer

This is the Codex-shaped surface:

- root thread
- child threads
- transcript
- pending prompts
- deferred inputs
- compaction hooks

This layer is how the user experiences the system.

### 2. Artifact-first Ralph loop layer

This remains the core execution substrate:

- intake
- PRD/spec
- plan
- loop graph
- child runs
- merge
- audit

This layer is how actual work gets executed safely and durably.

### 3. Watchdog meta-loop layer

This is the new piece.

It should supervise the active task at a higher level:

- detect when work is incomplete but the active thread is idle
- detect when the current rollout has become repetitive or unproductive
- trigger a continuation decision
- decide whether to:
  - continue the root thread
  - launch or reopen a Ralph loop
  - revise the plan
  - ask the user a focused question
  - compact the thread and continue
  - conclude that the task is actually complete

This layer is what turns Ralphception into a true loop-of-loops system.

## New Core Primitives

### Task frontier

Ralphception needs a durable representation of unfinished work that is more explicit than transcript text.

Add a runtime-owned `TaskFrontier` concept:

- `task_id`
- `goal`
- `completion_state`
- `frontier_items`
- `active_loop_ids`
- `blocked_reason`
- `last_progress_at`
- `last_watchdog_run_at`
- `stuck_counter`

Each `frontier_item` should represent a concrete outstanding obligation, for example:

- write missing artifact
- resolve blocker
- execute plan node
- merge loop result
- address audit finding
- verify touched paths

The watchdog should reason over this frontier instead of inferring everything from transcript text.

### Watchdog definition

A watchdog should be durable before it is active.

Add a `WatchdogDefinition`:

- `watchdog_id`
- `task_id`
- `scope`
- `goal_summary`
- `artifact_refs`
- `activation_policy`
- `cooldown_seconds`
- `prompt_template`

This is the "virtual subagent" form. It is not a live thread yet.

### Watchdog activation

When activation conditions are met, Ralphception materializes a real watchdog turn or child thread.

Add a `WatchdogActivation` / `WatchdogRun` record:

- `watchdog_id`
- `task_id`
- `trigger_reason`
- `source_thread_id`
- `input_snapshot`
- `result`
- `created_child_thread_id`
- `created_at`

### Compaction checkpoint

Compaction should become a first-class runtime action.

Add a `CompactionCheckpoint`:

- `task_id`
- `thread_id`
- `reason`
- `summary_artifact`
- `pre_compact_turn_id`
- `post_compact_turn_id`
- `created_at`

This allows Ralphception to deliberately compact and then continue, instead of treating compaction as a hidden implementation detail.

### Stuck signal

Ralphception needs an explicit stuck heuristic, not just a vibe.

Add a `StuckSignal` computed from:

- repeated similar assistant summaries
- multiple watchdog activations with no artifact delta
- repeated reopen/revise cycles
- elapsed idle time with unfinished frontier items
- repeated "next steps" without follow-through

This signal does not decide the next action directly, but it is one of the watchdog triggers.

## Watchdog Trigger Policy

The initial watchdog should activate only when all of these are true:

- task is not complete
- no pending prompt is blocking on the user
- no run is actively executing
- no approval is waiting
- frontier is non-empty
- watchdog cooldown has elapsed
- one of:
  - idle timeout elapsed
  - explicit "next steps" outcome was emitted
  - stuck signal crossed threshold

That gives Ralphception the "continue and untick itself" behavior the user wants without making the system feel chaotic.

## Watchdog Action Contract

A watchdog should not freeform its own control flow. It should resolve to one constrained action:

- `continue_root_turn`
- `launch_child_loop`
- `reopen_existing_loop`
- `revise_plan`
- `ask_user`
- `compact_root_thread`
- `mark_complete`

Each action may carry structured payload:

- target `plan_node_id`
- loop objective
- compact reason
- user-facing question
- plan revision summary

This is the same principle Ralphception already uses for prompt resolution: LLM-native surface, runtime-owned rails.

## Compaction Strategy

The chat message's "watchdog can run /compact on the parent thread" idea is good, but Ralphception should generalize it.

Compaction should happen in three cases:

### 1. Token pressure

Equivalent to Codex auto-compaction. This is technical hygiene.

### 2. Repetition recovery

If the root thread is spinning, repeating summaries, or producing similar next-step suggestions, the watchdog may compact and retry once.

### 3. Phase transition cleanup

After major settled milestones, Ralphception may compact to keep the active thread focused on the current frontier while preserving durable artifacts and compaction checkpoints.

The key rule:

**Compaction must never become the source of truth. Durable artifacts and frontier state remain the control plane.**

## Recommended First Implementation Slice

Do not attempt multi-watchdog orchestration first.

The first slice should add one root-task watchdog over the existing artifact-first runtime.

### Slice 1 goals

- preserve the current headless/stage/loop architecture
- add a durable frontier ledger
- add one root watchdog definition per active task
- trigger the watchdog when the task is incomplete and idle
- let the watchdog choose only from constrained next actions
- support one recovery action:
  - `compact_root_thread`

This is enough to prove the loop-of-loops concept without destabilizing the rest of the system.

## Why This Is Better Than What We Do Now

### Current model

- good durable execution substrate
- weak self-continuation
- weak unsticking
- too much progress logic hidden in transcript language

### Proposed model

- keep durable execution substrate
- add durable continuation substrate
- make "keep going" a runtime feature
- make compaction an explicit recovery primitive
- create an impartial re-evaluator that is not trapped inside the previous rollout's local reasoning

That is the right upgrade. It is more capable than the current system and more faithful to Ralphception's identity than simply making it behave more like plain Codex.

## Risks

### Too much autonomy

If watchdog activation is too eager, Ralphception could feel like it is taking control away from the user.

### Redundant orchestration

If the watchdog duplicates what the stage machine already knows, the new layer will add complexity without power.

### Compaction abuse

If compaction is treated as a generic fix-all, the system could hide real planning problems instead of solving them.

## Mitigations

- keep the first watchdog root-only
- constrain watchdog outputs to explicit actions
- make frontier state runtime-owned and inspectable
- only compact for explicit reasons
- tie watchdog activation to durable idle/blocking state, not to every pause

## Success Criteria

This upgrade is successful when:

- Ralphception can keep making progress after a root turn naturally stops
- the decision to continue is driven by durable frontier state, not transcript guesswork
- repetitive or stuck threads can be recovered via watchdog-triggered compaction
- reopened or newly launched Ralph loops still flow through the existing artifact-first execution engine
- the user experiences the system as one continuous conversational loop that can continue intelligently without losing the plot
