# Codex Transcript Repair Design

## Summary

Ralphception's current TUI still behaves like a snapshot-driven status dashboard instead of a Codex-style interactive transcript. Runtime activity is reduced to coarse `FrontendEvent(message=...)` summaries, then reapplied as whole-shell `RenderState` replacements. That design drops command output, hides waiting states, makes assistant output feel absent, and occasionally clobbers the local composer draft during runtime ticks.

The fix is structural: Ralphception should port Codex's transcript architecture more faithfully. The runtime path should preserve typed item-level events, the runtime adapter should reduce those events into persistent transcript state, and the chat widget should render committed history cells plus a real in-flight active cell. Waiting, approval, and request-user-input states should be explicit interaction objects instead of side effects of footer text or announcement rows.

## Problem Statement

The current failure mode has four visible symptoms:

- command/log output appears briefly, then disappears or is replaced by later updates
- the user does not reliably see assistant/model output as a continuous conversation
- blocking states such as review or input-needed are easy to miss or can appear as silent idle
- local draft text can be cleared or reset by incoming runtime updates

The architectural cause is that Ralphception currently collapses rich runtime/Codex activity into stringy summary events and then reconstructs shell state from those summaries. Codex does not do that. In `codex-rs/tui_app_server/src/chatwidget.rs` and `codex-rs/tui_app_server/src/history_cell.rs`, Codex keeps:

- a persistent committed history list
- a mutable in-flight active cell
- explicit unified-exec waiting/process state
- explicit approval/input request state
- transcript overlay rendering built from committed history plus a cached live tail

Ralphception needs the same ownership model.

## Product Contract

### Transcript is the source of truth

The shell should feel like Codex:

- assistant text streams live into the transcript
- command activity accumulates durably
- waiting is visible and named
- approvals and user-input requests are both visible in history and actionable in the bottom pane
- the shell only looks idle when it is genuinely ready for the next instruction

### No silent blocking

If Ralphception is blocked on review, request-user-input, a broken resume, a conflict, or a background-terminal wait, the user must be able to tell that directly from the shell without inferring from silence.

### No draft loss

The local composer draft belongs to the user. Runtime updates must never clear it unless the user explicitly submitted, queued, restored, or completed a slash-command action that intentionally rewrites the draft.

## Codex Reference Points

The repair should be guided directly by these Codex implementation areas:

- `~/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui_app_server/src/history_cell.rs`
- `~/code/codex/codex-rs/tui_app_server/src/app.rs`
- Codex chatwidget and history-cell snapshots that cover:
  - streamed assistant deltas and final message commit
  - unified exec wait status
  - unified exec interaction and process summaries
  - approval request and approval decision rendering
  - transcript overlay live-tail behavior

Ralphception should adapt its domain semantics into that structure instead of inventing a parallel event grammar.

## Architecture

### Typed runtime event pipeline

The current `FrontendEvent(message=...)` contract is too lossy. Ralphception should replace it with typed runtime events that preserve the interaction shape needed by the transcript.

Minimum event families:

- `assistant_delta`
- `assistant_final`
- `command_begin`
- `command_output_delta`
- `command_end`
- `background_wait_begin`
- `background_wait_update`
- `background_wait_end`
- `review_requested`
- `review_resolved`
- `request_user_input_requested`
- `request_user_input_resolved`
- `runtime_status_updated`
- `turn_started`
- `turn_completed`
- `turn_failed`
- `error`

These events should carry structured payloads, not English summary strings.

### Persistent transcript store

The runtime adapter should own a persistent transcript store with these state concepts:

- `history_cells`: append-only committed transcript/history cells
- `active_cell`: one mutable in-flight cell or cell group
- `active_cell_revision`: bumped whenever the active cell's rendered transcript meaning changes
- `blocking_surface`: approval/request-user-input/conflict/broken-resume state
- `task_state`: idle, running, waiting, blocked, failed
- `status_context`: model, directory, token usage, quota, active thread label
- `local_draft`: current composer text
- `queued_messages`: pending follow-up messages

The transcript store is where runtime events become durable shell semantics. `RenderState` should become a projection of this persistent interaction state, not the thing that owns it.

### Chat widget ownership

The chat widget should adopt the same ownership split Codex uses:

- committed history cells are durable and append-only
- one active cell mutates in place while streaming
- transcript overlay renders committed history plus a cached live tail derived from the active cell
- unified exec wait/process state is explicit and stays visible until ended

Ralphception-specific review and recovery events should be implemented as additional history-cell types, not as ad hoc system strings.

### Bottom pane ownership

The bottom pane should only derive from current interaction state:

- running
- waiting
- blocked
- queued input
- local draft

It should not infer shell truth from announcement rows or last-seen summary strings.

### App ownership

`src/ralphception/tui/app.py` should stop owning transcript semantics. Its responsibilities should be limited to:

- focus management
- view/overlay coordination
- runtime polling/bridging
- shell-level shortcuts
- mounting and syncing transcript overlay

The app should not synthesize transcript cells from user input and runtime summaries when that same state already belongs in the transcript store.

## Event Reduction Rules

### Assistant output

- deltas update a single active assistant cell
- final assistant output commits that cell into history
- duplicate final-after-delta payloads should not render duplicate transcript content

### Command output

- command begin creates or updates an active exec cell/group
- output deltas append to the active exec cell/group
- command end commits a stable command history cell with output and exit status
- command completion must never erase already-rendered output

### Background waiting

- empty terminal polling or equivalent "waiting" activity should surface as explicit wait state
- wait state should remain visible until it is resolved by output, completion, interruption, or failure
- if there is no assistant output yet, waiting state still counts as active shell activity

### Review and input requests

- review/input-needed should create a committed transcript/history entry explaining what is needed
- they should also activate the blocking bottom-pane surface
- resolving them should also create a committed transcript/history entry

### Errors and interruptions

- interrupted or failed turns should leave a durable transcript record
- they should clear or finalize active wait/exec state deterministically
- the shell should not silently fall back to idle if the runtime is actually blocked or failed

## UX Behavior Changes

### Assistant output becomes first-class

The user should see Ralphception talk back like Codex does. Streamed assistant output should be visible as live transcript content and settle into committed history when complete.

### Durable log behavior

Command output must stop disappearing. Once a command has emitted visible content, the shell should either keep it in the active exec cell or commit it into history; it should never vanish because a later status update overwrote the active cell.

### Explicit waiting

If the agent is waiting on background terminal activity or another explicit dependency, the shell should say so and keep showing that state until it ends.

### Explicit blocking

If the user must review or answer something, the shell should both show the transcript/history explanation and open the corresponding blocking surface. The user should never have to guess that approval is pending.

### Draft preservation

Incoming runtime updates must preserve the local composer draft. The only actions allowed to intentionally rewrite the draft are:

- submit
- queue
- restore queued message
- explicit slash-command completion

## File-Level Impact

The repair should concentrate work in these Ralphception files:

- `src/ralphception/runtime/frontends.py`
- `src/ralphception/headless.py`
- `src/ralphception/tui/runtime_adapter.py`
- `src/ralphception/tui/render_state.py`
- `src/ralphception/tui/chatwidget/transcript_cells.py`
- `src/ralphception/tui/chatwidget/transcript_view.py`
- `src/ralphception/tui/chatwidget/chat_widget.py`
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- `src/ralphception/tui/app.py`

It should also expand focused tests in:

- `tests/integration/test_tui_runtime_app.py`
- `tests/integration/test_tui_transcript.py`
- `tests/unit/test_tui_runtime_adapter.py`

Additional golden or snapshot-like tests should be added where useful to prove Codex-style transcript persistence and wait-state rendering.

## Testing Strategy

The repair is not done until the tests cover the live failure cases.

Required focused tests:

- assistant deltas followed by final assistant message preserve one coherent final transcript cell
- interleaved assistant and command events do not drop earlier output
- background wait state remains visible until explicitly ended
- review-required produces both transcript history and blocking surface
- request-user-input produces both transcript history and blocking surface
- local draft survives repeated runtime updates while a task is running
- transcript view follows tail when at bottom but does not yank the user when scrolled up
- transcript overlay includes a live tail derived from the active cell
- integration test reproducing a multi-command live turn where the shell ends in one of:
  - visible assistant output
  - visible waiting state
  - visible blocking review/input state

Manual verification should include a live tmux smoke against `uv run ralphception` with:

- a turn that runs several commands
- a turn that waits on background terminal polling
- a turn that hits review approval
- a turn where the user types during runtime activity

## Acceptance Criteria

- command/log output no longer disappears during multi-step turns
- assistant/model output is visible as a real transcript conversation
- the shell explicitly shows when it is waiting or blocked
- review/input-needed states are visible and actionable
- local draft text survives runtime updates unless an explicit user action changes it
- transcript overlay and main transcript stay consistent with the same live tail
- the shell only appears idle when the runtime is genuinely ready for more input
- the implementation structure is closer to Codex's `chatwidget` / `history_cell` model than to the current summary-string reducer
