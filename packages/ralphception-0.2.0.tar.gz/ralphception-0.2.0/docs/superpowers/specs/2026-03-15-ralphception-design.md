# Ralphception Design

Date: 2026-03-15
Status: Approved for planning

## Summary

`ralphception` is a Python `uv`/`uvx` project that runs inside a target repository and orchestrates nested Codex-driven loops: Socratic brainstorming, specification, planning, autonomous execution, merge coordination, and post-run auditing. It is optimized for cross-repo software porting, but the seed prompt can describe any task. The first user experience is a guided interactive TUI launched with `uvx ralphception`.

The runtime is tightly integrated with `codex app-server` through the Python SDK. Durable orchestration state lives in Python. Creative and task-specific behavior lives in bundled internal `ralphception` skills and prompts, with repo-local extensions under `.ralphception/skills/`.

## Goals

- Provide a Codex-native orchestration engine for "Ralph loops of Ralph loops".
- Support recursive child runs and parallel agents as first-class concepts.
- Run from the target repository while optionally reading one or more source repositories elsewhere on disk.
- Enforce a human gate through Socratic brainstorming, spec generation, and plan approval.
- Switch to autonomous execution after plan approval.
- Persist project memory under a tracked `.ralphception/` directory inside the target repo.
- Provide a mouse-enabled, fully interactive TUI with a machine-readable event log.
- Resume long-running workflows after crashes by reconnecting to Codex sessions and replaying durable state.
- Support mixed execution isolation: main working tree for read-heavy phases, git worktrees for edit-heavy child runs.
- Continue iterating through audit loops until no open `P0`, `P1`, or `P2` issues remain.

## Non-Goals

- Backend abstraction for non-Codex orchestration providers in v1.
- A web UI in v1.
- A fixed porting-only workflow.
- Full plugin packaging for bundled skills in v1. User customization is repo-local.

## Product Shape

`ralphception` is a generic orchestration engine with workflow structures inspired by porting:

- fan out to study source material and create cited specs
- distill work into plans and prioritized TODOs
- execute the most important work in recursive loops
- re-audit the result and reopen work until no high-priority gaps remain

The engine detects whether a run looks like porting, greenfield, brownfield, or mixed work and adjusts prompt affordances accordingly. Porting gets extra prompts for cross-repo citations and source-tracing, but the workflow engine itself remains generic.

## Architecture

The system deliberately splits durable orchestration from creative reasoning.

```mermaid
flowchart TD
    A["uvx ralphception"] --> B["Interactive TUI"]
    B --> C["Workflow Engine"]
    C --> D["Codex Session Manager<br/>app-server + Python SDK"]
    C --> E["Skill/Prompt Layer<br/>bundled skills + repo overlays"]
    C --> F["Artifact Store<br/>.ralphception/"]
    C --> G["Worktree Coordinator"]
    G --> H["Merge Coordinator"]
    C --> I["Event Log + Resume Index<br/>XDG state dir"]
    D --> J["Top-level Codex session"]
    D --> K["Child sessions / parallel agents"]
```

### Runtime Components

- `Interactive TUI`
  The default operator experience. It captures the seed prompt, shows workflow state, accepts approvals, and exposes slash commands such as `/model` and `/resume`.

- `Workflow Engine`
  Owns the recursive run graph, stage transitions, fan-out and fan-in, checkpoints, retries, completion rules, and autonomy boundaries.

- `Codex Session Manager`
  Wraps `codex app-server` through the Python SDK. It starts sessions, resumes sessions, streams events, configures model and reasoning settings, and runs Codex in full-access yolo mode.

- `Skill/Prompt Layer`
  Ships inside the Python package. It provides internal skills for brainstorming, specification, planning, implementation, auditing, merge handling, and run summarization. Repo-local `.ralphception/skills/` files can add or override behavior.

- `Artifact Store`
  Stores tracked project memory under `.ralphception/`.

- `Worktree Coordinator`
  Allocates git worktrees for edit-heavy child runs and tracks their lifecycle.

- `Merge Coordinator`
  Validates completed worktrees, resolves conflicts, squash-merges accepted work, and records merge outcomes.

- `Event Log + Resume Index`
  Persists structured events inside the repo and keeps crash-recovery pointers inside the XDG state directory.

### Worktree Coordinator Contract

Required operations:

- `create_child_worktree`
  Input: `run_id`, `base_ref`, `target_branch`, `goal`
  Output: `worktree_path`, `branch_name`

- `create_integration_worktree`
  Input: `run_id`, `target_branch`
  Output: `worktree_path`, `base_ref`

- `map_run_to_worktree`
  Input: `run_id`
  Output: `worktree_path`, `branch_name`, `authoritative`

- `cleanup_worktree`
  Input: `run_id`, `worktree_path`, `retain`
  Output: `cleanup_state`

- `switch_authoritative_root`
  Input: `run_id`, `new_root`
  Output: `authoritative_root`

Failure modes:

- `worktree_create_failed`
- `integration_root_unavailable`
- `cleanup_failed`

## Workflow Model

The core data model is `Run -> Stage -> Task`, where runs can recursively spawn child runs.

```text
Outer Run
|- Intake + Context Scan
|- Socratic Brainstorming Loop
|- Spec Generation
|- Plan Generation
|- Execution Loop
|  |- Child Run: implement area A
|  `- Child Run: implement area B
|- Merge Stage
|  |- Merge Task: integrate area A
|  |- Merge Task: integrate area B
|  `- Child Run: resolve merge conflict
`- Audit Loop
   |- gap discovery
   |- spec/plan updates
   `- re-enter execution until no P0/P1/P2 remain
```

### Definitions

- `Run`
  The durable orchestration unit. It has a goal, status, parent pointer, child pointers, config snapshot, Codex session reference, artifacts, and timestamps.

- `Stage`
  A named phase inside a run, such as `brainstorm`, `spec`, `plan`, `execute`, `merge`, or `audit`.

- `Task`
  The smallest schedulable unit. A task may correspond to a Codex turn, a child run, a parallel agent request, a merge action, or a verification command.

- `ChildAssignment`
  A durable assignment record for delegated work. Required fields: `assignment_id`, `goal`, `acceptance_criteria_refs`, `dependency_refs`, `bundle_version`.

- `Child run`
  A durable recursive `Run` with its own stages, tasks, event log, and artifacts.

- `Child session`
  The Codex session backing a run. `ChildSessionRef` is runtime transport metadata, not a separate orchestration model.

- `Parallel agent`
  A delegated worker represented by `AgentRef`, usually attached to one task for narrower parallel work. Agents are not full runs unless the engine explicitly promotes that work into a child run.

- `Agent output`
  Parallel agents may produce findings, summaries, or task-scoped output refs. Those outputs become canonical only when the owning parent task promotes them into task results, shared artifacts, or a new child run.

### Durable Runtime Contracts

The following contracts must be explicit in implementation because they are the interfaces between orchestration, persistence, resume, and the TUI.

Unless otherwise stated, every `*_refs` field in this spec contains `ArtifactRef` entries.

- `Run`
  Required fields: `run_id`, `parent_run_id`, `supersedes_run_id`, `goal`, `status`, `stage_ids`, `config_snapshot`, `codex_session_ref`, `artifact_refs`, `created_at`, `updated_at`.

- `Stage`
  Required fields: `stage_id`, `run_id`, `stage_kind`, `status`, `task_ids`, `started_at`, `completed_at`.

- `Task`
  Required fields: `task_id`, `run_id`, `stage_id`, `task_kind`, `status`, `owner`, `input_refs`, `output_refs`, `started_at`, `completed_at`.

- `ChildSessionRef`
  Required fields: `run_id`, `codex_thread_id`, `codex_session_id`, `workspace_path`, `resumable`, `last_seen_at`.

- `AgentRef`
  Required fields: `agent_id`, `parent_run_id`, `parent_task_id`, `codex_session_ref`, `goal`, `status`, `created_at`, `updated_at`.

- `Event`
  Required fields: `event_id`, `schema_version`, `run_id`, `stage_id`, `task_id`, `event_type`, `sequence`, `occurred_at`, `source`, `payload`.

- `WorktreeHandoff`
  Required fields: `child_run_id`, `worktree_path`, `branch_name`, `base_branch`, `head_commit`, `goal`, `artifact_refs`, `verification_artifact_refs`, `consumed_bundle_version`, `touched_paths`, `verification_summary`, `merge_readiness`, `cleanup_state`.
  Produced by an edit-heavy child run and consumed by the parent run's merge stage.

- `ArtifactRef`
  Required fields: `artifact_kind`, `artifact_path`, `artifact_version`, `content_hash`.

- `TodoArtifact`
  Required fields: `todo_id`, `title`, `priority`, `status`, `bundle_version`, `artifact_refs`.

- `ExecutionBundle`
  Required fields: `bundle_id`, `run_id`, `bundle_version`, `state`, `artifact_refs`, `base_bundle_id`, `scope_hash`, `created_at`, `assigned_run_ids`.

- `ApprovalRecord`
  Required fields: `approval_id`, `run_id`, `approval_kind`, `artifact_bundle_refs`, `bundle_version`, `scope_hash`, `approved_at`, `approver`, `waived_finding_ids`, `rationale`.

- `Checkpoint`
  Required fields: `checkpoint_id`, `run_id`, `checkpoint_kind`, `event_offsets`, `bundle_version`, `authoritative_root`, `active_worktrees`, `created_at`.

- `AuditFinding`
  Required fields: `finding_id`, `run_id`, `severity`, `kind`, `title`, `evidence_refs`, `status`, `created_at`, `resolved_at`.

- `VerificationSpec`
  Required fields: `verification_id`, `run_id`, `task_id`, `requested_by`, `scope`, `required`, `commands`, `success_criteria`, `created_at`.

- `VerificationResult`
  Required fields: `verification_id`, `run_id`, `task_id`, `status`, `command_results`, `started_at`, `completed_at`.

`VerificationResult.command_results` entries must include:

- `command`
- `cwd`
- `exit_code`
- `status`
- `duration_ms`
- `stdout_ref`
- `stderr_ref`

### Nullability And Lifecycle Presence

- `Run.parent_run_id`
  Nullable only for the outermost run.

- `Run.supersedes_run_id`
  Nullable unless this run replaces a failed or stale subtree.

- `Run.codex_session_ref`
  Nullable only before session startup or after unrecoverable startup failure.

- `Stage.started_at`, `Task.started_at`, and `VerificationResult.started_at`
  Nullable until execution begins.

- `Stage.completed_at`, `Task.completed_at`, `VerificationResult.completed_at`, and `AuditFinding.resolved_at`
  Nullable until the relevant object reaches a terminal or resolved state.

- `ApprovalRecord.waived_finding_ids` and `ApprovalRecord.rationale`
  Required for `finding_waiver`, otherwise null.

### Canonical Status Enums

These enums must be shared across workflow logic, persistence, replay, and the TUI.

- `Run.status` and `Stage.status`
  `pending -> running -> completed`
  `pending|running -> awaiting_approval`
  `running -> blocked|session_lost|recovery_blocked|failed|aborted`
  `awaiting_approval -> running|aborted`
  `session_lost -> running|failed|recovery_blocked`
  `blocked -> running|failed|aborted`

- `Task.status`
  `queued -> running -> succeeded`
  `queued|running -> blocked|session_lost|failed|aborted`
  `blocked|session_lost -> queued|failed|aborted`

- `AgentRef.status`
  `queued -> running -> completed`
  `queued|running -> blocked|failed|aborted`
  `blocked -> running|failed|aborted`

- `WorktreeHandoff.merge_readiness`
  `ready | needs_revision | blocked`

- `WorktreeHandoff.cleanup_state`
  `pending | retained | cleaned`

- `AuditFinding.status`
  `open | accepted | resolved | wontfix`

- `VerificationResult.status`
  `pending | running | passed | failed | errored`

- `ApprovalRecord.approval_kind`
  `spec_review | execution_bundle | finding_waiver`

- `ExecutionBundle.state`
  `draft | approved | derived_in_scope | awaiting_approval | superseded`

- `Stage.stage_kind`
  `intake | brainstorm | spec | plan | execute | merge | audit`

- `Task.task_kind`
  `turn | child_run | agent | merge | verification | artifact_promotion`

- `Task.owner`
  `workflow_engine | codex_session_manager | merge_stage | audit_stage | ui`

- `VerificationSpec.scope`
  `task | child_run | run | merge | audit`

- `TodoArtifact.status`
  `open | in_progress | done | dropped`

- `TodoArtifact.priority`
  `P0 | P1 | P2 | P3`

### Phase Semantics

1. `Intake`
   Read the seed prompt, repo state, optional source repo paths, and current `.ralphception` artifacts.

2. `Socratic brainstorming`
   Run a guided question loop before implementation. The purpose is to clarify goals, scope, success criteria, and initial workflow framing.

3. `Spec generation`
   Produce or update specs. In porting scenarios this includes citations back to source repositories.

4. `Spec approval`
   The user reviews the generated spec bundle. Planning may begin only after a `spec_review` approval has been recorded.

5. `Plan generation`
   Produce or update executable plans and TODOs from approved specs.

6. `Autonomous execution`
   After human approval of the plan, spawn child runs and agents as needed until the current plan is complete.

7. `Merge`
   Merge accepted child-run output back into the parent working tree. Merge is always represented as a `merge` stage inside the parent run. Conflict-resolution work may be delegated to child runs, but merge coordination itself is not a separate top-level model.

8. `Audit`
   Try to disprove completeness by looking for missing features, missing tests, spec drift, regressions, integration gaps, and unfinished items. Reopen work when needed.

### Completion Rule

The outermost run is complete only when:

- all work required by the newest consumable execution bundle is done
- the audit loop finds no open `P0`, `P1`, or `P2` items
- required verification passes
- merge coordination has integrated all accepted child runs

## Autonomy Boundary

The system has two modes separated by a clear human gate:

- `Human-gated mode`
  Intake, brainstorming, spec generation, and planning remain interactive. The user reviews generated artifacts and explicitly approves execution.

- `Autonomous mode`
  After approval, the engine executes, merges, audits, revises artifacts, and loops until the completion rule is satisfied.

This provides both requested behaviors: spec-first control upfront and fully autonomous operation afterward.

### Pre-Approval Write Boundary

Before execution approval, the run may write only orchestration artifacts under `.ralphception/`.

- allowed writes before approval:
  `.ralphception/config.toml`, `.ralphception/specs/`, `.ralphception/plans/`, `.ralphception/todos/`, `.ralphception/approvals/`, `.ralphception/runs/`, `.ralphception/events/`, `.ralphception/skills/`, `.ralphception/verification/`, and `.ralphception/findings/`
- forbidden writes before approval:
  target source files, tests, build scripts, and any non-`.ralphception/` project files
- violation handling:
  if pre-approval stages produce out-of-bounds writes, the run must transition to `blocked`, record a diagnostic artifact, and require operator intervention before continuing

Detection contract:

- the engine must snapshot relevant filesystem paths before each pre-approval task and diff them after the task completes
- any changed path outside the allowed-write roots counts as a violation
- violations are attributed to the currently executing run, task, or agent and emitted as blocking events
- the monitored surface is the target repo root and any declared source repo roots
- ignored paths may include `.git/`, local virtualenv caches, and XDG state files owned by the orchestrator
- writes outside the monitored roots are violations unless they are under the orchestrator's own XDG state directory

### Re-Approval Rules

After execution approval, the engine may continue without asking again only for changes that stay within the already approved objective.

| Change Type | Re-approval Required? | Reason |
|-------------|------------------------|--------|
| Split or reorder TODOs, add execution notes, refine task decomposition | No | Execution detail only |
| Update specs or plans to reflect implementation details that do not change user-visible requirements or acceptance criteria | No | Clarifying the approved scope |
| Reopen work because audit found missing tests, missing integration, or defects required to satisfy the approved scope | No | This is part of finishing the approved job |
| Add a new user-visible feature not implied by the approved spec/plan | Yes | Scope expansion |
| Remove an approved requirement or weaken acceptance criteria | Yes | Scope reduction without consent |
| Major strategy change that affects external behavior, repo boundaries, or source-repo assumptions | Yes | Material plan change |

If a re-approval case is detected during autonomous mode, the run must transition to `awaiting_approval` instead of continuing silently.

## Porting, Greenfield, And Brownfield Affordances

The seed prompt may describe any task. The runtime classifies the work to choose prompt affordances:

- `Porting`
  Source repositories live outside the target repo and are referenced by filesystem path. Specs must carry citations to source files and tests when useful.

- `Greenfield`
  The target repo has little or no implementation and the prompts should emphasize problem framing and architecture discovery.

- `Brownfield`
  The target repo already has code that must be studied and incrementally modified.

- `Mixed`
  The run may include both ported and newly designed parts.

This classification affects prompts, not the engine's control flow.

Source-repo policy:

- source repos are read-only inputs by default, even though Codex sessions have full filesystem access
- prompts, verification, and runtime checks must treat writes to source repos as out-of-bounds
- if a run writes to a source repo path, the run must transition to `blocked`, record the violation, and require operator intervention

## Skills And Prompt Layer

Bundled `ralphception` skills are internal package assets, not copied into the target repo. This keeps shipped behavior versioned with the installed tool.

### Internal Skills

The package should include internal prompts and skills for:

- Socratic brainstorming
- spec writing
- plan writing
- implementation tasking
- parallel research and execution fan-out
- merge coordination
- audit and gap detection
- final run summarization

### Skill Invocation Contract

To keep skill execution testable, the engine must treat skills as inputs and outputs with a fixed envelope.

Skill invocation input must include:

- run id and stage id
- goal and current task description
- target repo path
- source repo paths, if any
- relevant artifact references
- effective config snapshot
- expected output mode

Skill response must include:

- machine-readable status: `success | blocked | needs_approval`
- referenced artifacts to create or update
- artifact payloads or edit instructions for each referenced artifact
- suggested next tasks or child runs
- findings with severity when applicable
- markdown body for human-readable reasoning or content

Artifact apply contract:

- each returned artifact update must include an `ArtifactRef`
- allowed `apply_mode` values are `replace`, `append`, or `structured_patch`
- the payload must be either full replacement content or a structured edit operation the engine can validate and apply deterministically
- partial results are allowed only when `status = blocked` and the response explicitly marks which artifact updates are safe to persist

Structured patch schema:

- `{ op, start_line, end_line, content }`
- allowed `op` values: `replace_range | insert_after`

Allowed `expected output mode` values:

- `conversation`
- `artifact`
- `task_list`
- `findings`
- `summary`

Canonical artifact roots are limited to:

- `.ralphception/specs/`
- `.ralphception/plans/`
- `.ralphception/todos/`
- `.ralphception/runs/`
- `.ralphception/verification/`
- `.ralphception/findings/`
- `.ralphception/merge/`
- `.ralphception/approvals/`

If a repo-local override is unreadable, invalid, or does not return the expected envelope, the engine must:

1. emit a warning event
2. fall back to the bundled internal skill
3. record the fallback in the run summary

Normative response shape:

- `artifact_updates`
  Array of `{ artifact_ref, apply_mode, content, safe_to_persist }`

- `suggested_next`
  Array of `{ kind, title, goal, priority }` where `kind` is `task | child_run | agent`

- `findings`
  Array of `{ severity, kind, title, evidence_refs }`

### Skill Discovery Contract

Skills are resolved by stable skill ids owned by the engine.

- bundled internal skills ship with ids such as `brainstorm.default`, `spec.write`, `plan.write`, `execute.task`, `merge.coordinator`, and `audit.review`
- repo-local overrides live at `.ralphception/skills/<skill-id>.md`
- a repo-local skill overrides a bundled skill only when its filename or frontmatter id exactly matches the engine-requested skill id
- unknown or duplicate ids are validation errors and must not be loaded silently

### Repo-Local Skills

On the first run, `ralphception` creates `.ralphception/skills/` if it does not exist. Users may add repo-specific skills there. Resolution order should be:

1. repo-local overlay skill
2. bundled internal skill

This allows local extension without freezing the project onto an old bundled prompt set.

## Persistence Model

There are two durability layers: tracked repo artifacts and local-machine runtime state.

```mermaid
flowchart LR
    A["Target Repo"] --> B[".ralphception/"]
    B --> C["config.toml"]
    B --> D["specs/"]
    B --> E["plans/"]
    B --> F["todos/"]
    B --> G["approvals/"]
    B --> H["runs/"]
    B --> I["events/"]
    B --> J["verification/"]
    B --> K["findings/"]
    B --> L["merge/"]
    B --> M["skills/"]

    N["XDG State Dir"] --> O["workspace-hash/"]
    O --> P["session-index.json"]
    O --> Q["active-run.json"]
    O --> R["child-session-map.json"]
```

### `.ralphception/` Layout

```text
.ralphception/
|- config.toml
|- specs/
|- plans/
|- todos/
|- approvals/
|- runs/
|- events/
|- verification/
|- findings/
|- merge/
`- skills/
```

- `config.toml`
  User-editable runtime defaults, including model selection and reasoning profile.

- `specs/`
  Generated and revised specifications.

- `plans/`
  Approved plans and later updated plans.

- `todos/`
  Prioritized execution backlogs.

- `approvals/`
  Approval records that bind a user approval to a specific artifact version and scope hash.

- `runs/`
  Human-readable run summaries and snapshots.

- `events/`
  Structured event logs, ideally line-delimited JSON for replay.

- `verification/`
  Durable `VerificationSpec` and `VerificationResult` records owned by the parent run coordinator.

- `findings/`
  Durable `AuditFinding` records owned by the parent run coordinator.

- `merge/`
  Merge coordination notes and conflict records owned by the parent run coordinator.

- `skills/`
  Repo-local skill overlays.

### XDG Runtime State

The runtime should resolve the canonical git top-level path of the target repo, hash that repository root, and store a workspace-specific directory under the XDG state location. That directory should contain enough metadata to reconnect the TUI to the outer run and its child sessions after a crash.

Required capabilities:

- recover the outermost run
- enumerate child sessions
- reconnect to live Codex sessions when possible
- rebuild the workflow tree by replaying durable events

`ralphception resume` and `/resume` should both consult this index.

V1 concurrency model:

- one workspace may have at most one active outermost run at a time
- a workspace may have many completed, failed, or archived historical runs
- `/resume` may target the single active outer run or any resumable historical run in read or repair mode

Resume modes:

- `read`
  Attach the TUI for inspection without taking the workspace lease or mutating durable state.

- `repair`
  Take the workspace lease, reconcile durable state, and allow recovery actions such as retry, restart, replace, or approval.

Lease model:

- the active outer run holds a workspace lease in the XDG state directory
- the lease records workspace path hash, owning process id, run id, authoritative repository root, and a heartbeat timestamp
- startup and `/resume` must refuse to create a second active writer while a healthy lease exists
- stale leases may be stolen only after heartbeat expiry and durable-state reconciliation

### Approval Versioning

Human approval must be tied to concrete artifact versions.

- each spec and plan revision gets an `artifact_version`, defined as a monotonic revision number plus a content hash
- execution approval writes one bundle-level `ApprovalRecord` under `.ralphception/approvals/` for the selected `ExecutionBundle`
- `scope_hash` is calculated from the normalized approved bundle of spec, plan, and TODO artifacts that execution is allowed to satisfy
- `bundle_version` is the monotonic revision of the approved artifact bundle for that run
- re-approval checks compare the current bundle version and scope hash against the last approved record
- if an artifact changed in a way that requires re-approval, the run must stop in `awaiting_approval`
- on approval, the engine snapshots the approved artifact bundle under `.ralphception/approvals/<approval-id>/`

Child runs must receive an assigned execution-bundle snapshot as their authoritative planning input, even when the parent working tree has additional uncommitted changes.

Scope-hash normalization rules:

- include only the normalized contents of the bundle's artifact refs, in stable path order
- ignore timestamps, transient metadata, whitespace-only formatting differences, and event-log files
- ignore TODO ordering changes and execution-only notes that do not alter requirements or acceptance criteria
- changing any user-visible requirement, acceptance criterion, repo boundary, or source-repo input changes the `scope_hash`

### Bundle State Machine

Execution bundles move through these states:

- `draft`
  Newly generated but not yet eligible for autonomous execution.

- `approved`
  Explicitly human-approved for execution.

- `derived_in_scope`
  Autonomously derived from an already approved bundle without changing the approved scope.

- `awaiting_approval`
  Blocked until human approval because the changes are out of scope or a waiver is required.

Scheduling rule:

- new child runs may consume only `approved` or `derived_in_scope` bundles
- a `derived_in_scope` bundle must record which prior `approved` bundle it descends from
- a bundle in `awaiting_approval` state may not be scheduled onto new child runs
- a bundle becomes `superseded` when a newer consumable bundle replaces it for future scheduling

Storage rule:

- bundle records live under `.ralphception/runs/<run-id>/bundles/`
- bundle creation, state changes, and assignment must emit canonical bundle events

Approval kinds:

- `spec_review`
  Approves the current spec bundle so plan generation may begin.

- `execution_bundle`
  Approves a bundle for autonomous execution.

- `finding_waiver`
  Approves waiving one or more blocking audit findings by id, with the waiver recorded as a durable approval artifact.

Kind-specific approval rules:

- `spec_review`
  `artifact_bundle_refs` must contain the reviewed spec artifacts; `bundle_version` and `scope_hash` refer to that spec bundle.

- `execution_bundle`
  `artifact_bundle_refs`, `bundle_version`, and `scope_hash` refer to the full execution bundle of specs, plans, and TODOs.

- `finding_waiver`
  `waived_finding_ids` and `rationale` are required; `artifact_bundle_refs`, `bundle_version`, and `scope_hash` may be null.

### Execution Bundle Propagation

Autonomous in-scope revisions create new immutable execution bundles for future work without mutating the bundle already assigned to running children.

- every in-scope post-approval update to specs, plans, or TODOs creates a new `bundle_version`
- every such bundle enters the `derived_in_scope` state until a later change forces `awaiting_approval`
- newly scheduled child runs receive the newest approved or in-scope execution bundle available at scheduling time
- already running child runs continue on the bundle they started with unless the parent explicitly aborts and reschedules them
- parent fan-in, merge, and audit logic must record which `bundle_version` each child consumed

### Degraded Recovery Behavior

Resume must define failure paths, not only the happy path.

### Durable Checkpoints

The engine must write a `Checkpoint` at least:

- after each stage completes
- before merge starts
- after merge completes
- before lease-root switching

Checkpoint contents capture the minimum recovery state beyond the event log:

- current authoritative root
- latest consumable bundle version
- active worktrees
- persisted event offsets

- missing or expired live Codex session
  Mark the affected run or task as `session_lost`, preserve its prior artifacts, and offer restart from the last durable checkpoint using a fresh Codex session.

- stale XDG session map
  Reconcile against `.ralphception/events/` and `.ralphception/runs/`, then rewrite the XDG index from the durable repo state.

- missing XDG state but intact repo artifacts
  Rebuild the in-memory run tree from repo events and snapshots, then recreate the XDG index.

- corrupt or partial event log for a run
  Mark the run `recovery_blocked`, preserve all files, and stop automatic continuation for that run until the operator chooses a recovery action.

- child run unrecoverable but parent run recoverable
  Mark only that child subtree failed or blocked, keep siblings runnable, and let the parent decide whether to retry, replace, or abort that subtree.

## Configuration And Model Control

The first run writes `.ralphception/config.toml`. It should be safe to edit by hand and also writable through TUI commands.

Example shape:

```toml
[codex]
model = "gpt-5.4"
reasoning = "high"
latency_profile = "fast"
sandbox = "danger-full-access"
approval_policy = "never"

[execution]
use_worktrees_for_edit_runs = true
max_parallel_children = 4
audit_reopen_priorities = ["P0", "P1", "P2"]

[verification]
command_timeout_seconds = 1800

[ui]
show_event_timestamps = true
mouse = true
```

Behavior:

- default to the strongest desired Codex profile, such as `gpt-5.4` with high reasoning and fast latency, if available
- gracefully fall back to the best supported profile when unavailable
- snapshot effective config into each run so historical runs stay interpretable
- support `/model` to change the active model and persist the change back to `config.toml`
- write config updates atomically via temp-file plus rename
- if config parsing fails on startup or resume, preserve the broken file, surface a diagnostic, and block the run until the operator repairs the config or accepts a generated safe default

## Codex Integration

`ralphception` is intentionally Codex-specific in v1.

### Required Integration Surface

- `codex app-server`
  The primary backend for sessions, turns, and event streaming.

- Python SDK
  The preferred integration layer for launching and controlling the app server.

- child sessions and parallel agent support
  Used to express nested loops and task fan-out.

### Codex Session Manager Contract

The `Codex Session Manager` is the single boundary between raw Codex SDK interactions and engine-level orchestration.

Required operations:

- `start_session`
  Start a new Codex app-server backed session for a run or child run.

- `resume_session`
  Reattach to a resumable Codex session using stored session references.

- `run_turn`
  Submit the next prompt or task input for a session.

- `spawn_agent`
  Request a parallel agent through the supported Codex surface. Child runs are created by the workflow engine, then backed by `start_session`.

- `stream_raw_events`
  Read raw Codex events from the SDK transport.

- `normalize_event`
  Map raw Codex events into canonical engine events before persistence.

- `abort_session`
  Stop a session cleanly when a run or task is aborted.

Normalized failure modes:

- `startup_failed`
- `session_expired`
- `transport_error`
- `protocol_error`
- `model_unavailable`

The workflow engine should not consume raw SDK events directly. It consumes only normalized engine events emitted by this component.

Lifecycle expectations:

- one run may own zero or one active primary Codex session at a time
- one task may own zero or more `AgentRef` children
- a task may create a child run, but that child remains a distinct durable run rather than merely an agent
- agents may emit task-scoped outputs and findings, but they do not own shared artifact roots or canonical event logs

### Execution Mode

All Codex runs should be launched in full-access yolo mode:

- no sandbox restrictions
- no approval prompts
- direct filesystem access in the target repo and referenced source repos

This assumption must be explicit in the configuration and visible in the UI.

## Preflight Checks

Before a run begins, the engine must validate prerequisites and decide whether it can proceed.

- target repo is a git repository
  Required. If false, startup fails before orchestration begins.

- target branch is resolvable
  Required for edit-heavy execution. Detached HEAD blocks worktree-backed execution until the operator chooses or creates a branch.

- dirty working tree
  Allowed, but the run must record that state and branch worktrees from the current HEAD without auto-cleaning user changes.

- `git worktree` support is available
  Required for edit-heavy child runs. If unavailable, read-only phases may proceed but execution that needs worktrees must block.

- source repo paths are readable
  Required only when those paths are part of the seed prompt or configuration.

- Codex app-server startup succeeds
  Required. If startup fails, the run remains blocked with a diagnostic artifact and no child runs are scheduled.

## Execution Isolation

The engine uses a mixed strategy.

```text
main tree
|- intake
|- brainstorming
|- spec generation
|- planning
|- audit research
`- orchestration control

worktrees
|- child run: implement parser
|- child run: port module X
|- child run: add missing tests
`- child run: fix audit findings
```

Rules:

- read-only and artifact-heavy phases may stay in the main tree
- edit-heavy child runs should receive dedicated git worktrees
- each worktree belongs to one child run with one explicit goal
- worktree branches should use a `codex/` prefix
- completed worktree output goes to the parent run's merge stage, not directly to main

### Artifact Ownership And Single-Writer Rule

Canonical tracked state under the target repo's `.ralphception/` is owned by the parent run coordinator, regardless of whether it is currently attached to the operator checkout or the clean integration worktree.

- child worktrees may read shared `.ralphception/` artifacts
- child worktrees may write provisional child-scoped outputs under their own `.ralphception/runs/<child-run-id>/` paths on their branch
- child worktrees must not be treated as authoritative writers for shared specs, plans, TODOs, approvals, or event streams
- the parent run promotes accepted child outputs into canonical shared artifacts during fan-in or merge

Files under `.ralphception/runs/<child-run-id>/` written by a child branch are provisional until the parent coordinator promotes them.

Forbidden child-branch edits under `.ralphception/` are:

- `.ralphception/specs/`
- `.ralphception/plans/`
- `.ralphception/todos/`
- `.ralphception/approvals/`
- `.ralphception/events/`
- `.ralphception/verification/`
- `.ralphception/findings/`
- `.ralphception/merge/`

If a child branch modifies these shared paths directly, merge coordination must reject the handoff or strip those changes during promotion instead of accepting them blindly.

### Child Event And Artifact Promotion

Child-run activity becomes durable in the parent workspace through promotion, not by direct shared writes.

- live child session events are streamed to the parent coordinator
- the canonical event store uses one append-only JSONL file per run under `.ralphception/events/<run-id>.jsonl`
- the parent coordinator appends child events into the child run's canonical log file, not into the parent run's sequence
- parent-run fan-in and merge actions emit their own parent events that reference child run ids and promoted artifact ids
- child artifacts become canonical only when a parent fan-in or merge task promotes them into shared artifact roots
- replay must be possible from the parent-owned canonical event log even if a child worktree has been cleaned up

Canonical event writing rules:

- the coordinator that owns a run's canonical event log is the sole allocator of `sequence` numbers for that run
- source systems may emit stable `event_id` values before persistence, but only the canonical event writer assigns the final per-run `sequence`
- on resume or retry, already-persisted `event_id` values for that run must be deduplicated instead of appended again
- replay ordering is determined by persisted `sequence`; duplicates with the same `event_id` are ignored

This avoids concurrent child runs silently overwriting each other's durable state.

### Worktree Handoff And Cleanup

Edit-heavy child runs hand back a `WorktreeHandoff` record to merge coordination. The minimum handoff content is:

- child run identity
- worktree path
- branch name and base branch
- immutable head commit
- implementation goal
- changed artifact references
- verification artifact references
- consumed bundle version
- touched source paths
- verification summary
- merge readiness status
- cleanup state

Cleanup rules:

- successful squash merge
  Remove the worktree and delete the child branch by default, unless config requests retention.

- failed verification or merge rejection
  Keep the worktree for inspection and emit a retained-worktree event.

- child abort or crash
  Preserve the worktree until merge coordination or the operator explicitly discards or retries it.

## Merge Coordinator

Merge coordination is a first-class subsystem, represented canonically as the `merge` stage of a parent run.

### Merge Coordinator Contract

Required operations:

- `validate_handoff`
  Input: `WorktreeHandoff`, latest consumable bundle
  Output: `ready | stale | blocked`

- `promote_artifacts`
  Input: accepted handoff artifact refs
  Output: canonical promoted artifact refs

- `resolve_conflict`
  Input: merge conflict state
  Output: conflict-resolution child run or resolved integration state

- `finalize_merge`
  Input: accepted handoff, promoted artifacts, integration result
  Output: updated target branch ref and merge summary

Responsibilities:

- inspect completed child runs
- validate that the requested goal is met
- run merge-time verification
- squash-merge the handoff's `head_commit` into the parent run's target branch
- resolve conflicts directly or by dispatching focused conflict-resolution child runs
- record decisions and outcomes in `.ralphception/merge/`

The merge stage may contain multiple merge tasks and may spawn child runs for conflict resolution, but the workflow model should still render it as one parent-run stage with explicit tasks beneath it.

### Stale Bundle Policy

At merge or fan-in time, each child run must be evaluated against the newest consumable execution bundle.

- if the child's assigned `bundle_version` is still the newest consumable bundle, normal merge rules apply
- if a newer consumable bundle exists but does not change the child's goal, acceptance criteria, or touched artifact set, the child may merge after revalidation against the newest required verification
- if a newer consumable bundle materially changes the child's goal, acceptance criteria, or dependent artifacts, the child handoff becomes stale and must be replaced or rescheduled instead of merged directly

### Merge Safety Policy

- if the parent workspace is dirty at merge time, the coordinator must first create a durable orchestration checkpoint for `.ralphception/` artifacts
- merge execution should happen in a clean integration worktree rooted at the parent run's target branch
- only after merge verification passes should the accepted result be reflected back into the target branch
- if a clean integration base cannot be established, the merge stage must block instead of merging into an ambiguous state
- merge-time validation must reject or strip forbidden shared `.ralphception/` edits from child branches before integration
- when the operator's main workspace is dirty, the accepted merge updates the target branch and integration worktree only; it must not overwrite the dirty checkout in place
- subsequent edit-heavy child runs must branch from the updated target branch, not from the stale dirty checkout
- while the operator checkout remains dirty, the clean integration worktree becomes the authoritative repository view for later audit, read-heavy phases, and artifact promotion
- the parent run coordinator remains the single canonical writer while attached to that authoritative repository view
- the workspace lease must update its `authoritative_repository_root` whenever control shifts from the operator checkout to the clean integration worktree

Partial-merge recovery rules:

- if a crash happens before the integration worktree is updated, resume retries merge from the last handoff
- if a crash happens after the integration worktree is updated but before the target branch ref moves, resume must verify the worktree state and either complete or roll back the pending merge
- if a crash happens after the target branch ref moves but before lease-root metadata is updated, resume must reconcile the branch ref, integration worktree, and workspace lease before scheduling more work

## TUI

The default experience is a fully interactive terminal UI with mouse support.

```mermaid
flowchart TD
    A["Header: repo | run | model | mode"] --> B["Workflow Tree Pane"]
    A --> C["Detail Pane"]
    A --> D["Event Feed Pane"]
    A --> E["Command/Input Pane"]

    B --> B1["outer run"]
    B --> B2["child runs"]
    B --> B3["parallel agents"]

    C --> C1["selected node status"]
    C --> C2["artifacts"]
    C --> C3["session info"]
    C --> C4["worktree / branch info"]

    D --> D1["event stream"]
    D --> D2["warnings / blockers"]
    D --> D3["merge + audit updates"]

    E --> E1["seed prompt / approvals"]
    E --> E2["slash commands"]
```

### Primary TUI Views

- workflow tree pane
- selected node detail pane
- recent event feed
- input and slash-command area

### Required Commands

- `/model`
- `/resume`
- `/status`
- `/artifacts`
- `/approve`
- `/retry`
- `/restart`
- `/replace`
- `/abort`
- `/help`

### TUI Requirements

- render nested runs and parallel agents clearly
- support keyboard-first use and mouse interaction
- rebuild state from event logs during resume
- make artifact paths and worktree paths easy to inspect

### Interaction Semantics

- `/approve`
  Approves the currently selected pending spec review, execution bundle, or finding-waiver request, writes one `ApprovalRecord`, and transitions the run from `awaiting_approval` to the next runnable state when the blocking approval has been satisfied.

- `/resume`
  Reattaches to the selected resumable run or the top-level active run for the current workspace.

- `/retry`
  Requeues the selected blocked task, verification, or agent from its last durable checkpoint.

- `/restart`
  Starts a fresh Codex session for the selected run from its last durable checkpoint.

- `/replace`
  Creates a replacement child run for a failed or unrecoverable subtree while preserving the old subtree for auditability.

- `/status`
  Shows current stage, blockers, open audit findings, active verifications, and merge queue state.

- `/artifacts`
  Lists artifacts for the selected run, opens the selected artifact in the detail pane, and supports review or diff of pending approval bundles.

- `/help`
  Shows slash-command semantics, keybindings, and status legend information for the current screen.

- `/abort`
  Aborts the selected run or subtree and leaves artifacts and retained worktrees intact for inspection.

- blocked or errored nodes
  The TUI must surface the reason, related artifacts, and available next actions such as retry, approve, resume, or abort.

- selected-node actions
  The detail pane must expose actions relevant to the selected run, task, or agent, not only passive status text.

### Operator Flow

1. first run startup
   Capture the seed prompt, optional source repo paths, write `.ralphception/config.toml`, and create the initial outer run.

2. brainstorming and spec review
   Generate spec artifacts, show them in the artifact pane, and let the operator inspect or diff the current spec bundle before issuing `/approve` for `spec_review`.

3. plan review
   Generate plan and TODO artifacts, show the pending execution bundle, and let the operator inspect or diff the bundle before issuing `/approve` for `execution_bundle`.

4. autonomous execution and monitoring
   Render nested runs, agents, verification, merge, and audit activity live from the event stream.

5. blocked-state recovery
   When blocked, surface the exact blocking reason plus the valid next actions such as approve, retry, restart, replace, or abort.

## Eventing And Replay

The event log is a core product feature, not a debug afterthought.

Requirements:

- every significant transition should emit a structured event
- events should be durable enough to replay the run tree
- the TUI should render from the same event stream model used for persistence
- event logs should be suitable for future external viewers or automation

### Event Envelope

Each event record must include:

- `event_id`
  Stable unique identifier for deduplication.

- `schema_version`
  Allows forward migration and replay compatibility.

- `run_id`
  The owning run.

- `stage_id`
  Nullable only for run-level events.

- `task_id`
  Nullable only when no specific task exists.

- `event_type`
  Stable machine-readable type such as `run.started` or `merge.completed`.

- `sequence`
  Monotonic integer within a run. Replay order is by `sequence`, not by filesystem order.

- `occurred_at`
  RFC 3339 timestamp for display and cross-run correlation.

- `source`
  Emitter identity such as `workflow-engine`, `codex-session-manager`, `merge-stage`, or `ui`.

- `payload`
  Event-specific data.

Minimum required event types:

- `run.created`
- `run.started`
- `run.status_changed`
- `run.replaced`
- `bundle.created`
- `bundle.state_changed`
- `bundle.assigned`
- `stage.started`
- `stage.completed`
- `task.queued`
- `task.started`
- `task.completed`
- `task.blocked`
- `task.failed`
- `task.aborted`
- `task.session_lost`
- `agent.spawned`
- `artifact.promoted`
- `verification.completed`
- `merge.completed`
- `stage.blocked`
- `stage.failed`
- `stage.aborted`
- `audit.finding_created`
- `audit.finding_status_changed`

Minimum payload expectations:

- run events must identify run goal and parent linkage when applicable
- stage events must identify `stage_kind`
- task events must identify `task_kind` and owning run or stage
- agent events must identify `agent_id` and parent task
- artifact events must identify artifact path, kind, and producing run
- verification events must identify `verification_id` and result status
- audit events must identify `finding_id`, severity, and kind

### Replay Semantics

- event logs are append-only
- per-run sequence numbers must be monotonic
- snapshots in `.ralphception/runs/` are derived state, not the source of truth
- replay must be able to reconstruct the workflow tree, last known statuses, and artifact references without consulting volatile in-memory state
- if a run has both a snapshot and an event log, the event log wins when they disagree

## Verification Contract

Verification is an engine-owned subsystem used by execution, merge, audit, and final completion.

Command sources:

- default verification commands from project config
- plan-defined verification commands for a run or stage
- merge-stage requested verification for integration safety
- audit-stage requested verification when proving or disproving completion

Precedence when multiple sources apply:

1. merge-stage required verification
2. audit-stage required verification
3. plan-defined verification
4. config-defined default verification

Higher-precedence verification may add to lower-precedence commands. It must not silently remove required lower-precedence checks unless the active bundle explicitly says so.

Execution rules:

- verification runs as explicit tasks tied to a `VerificationSpec`
- verification tasks use `task_kind = verification`
- the workflow engine allocates the verification task id first, then writes the `VerificationSpec` referencing that `task_id`
- a verification task's `input_refs` must contain exactly one `VerificationSpec`
- a verification task's `output_refs` must contain exactly one `VerificationResult`
- results are persisted as `VerificationResult` records and mirrored into the event stream
- merge cannot complete with a failed or errored required verification
- final completion cannot occur while any required verification for the outer run is failing
- `VerificationSpec.requested_by` must identify the run, stage, or task that required the verification
- conflicting command sources are normalized into one concrete `VerificationSpec` before execution begins

Execution context rules:

- `scope = child_run` or `task` executes in the child run's assigned worktree
- `scope = merge` executes in the clean integration worktree
- `scope = run` or `audit` executes in the current authoritative repository root for the outer run
- verification inherits the project environment from the authoritative runtime configuration
- required verifications must honor configured timeouts and emit timeout results as `errored`

Suggested event categories:

- run lifecycle
- stage transition
- task scheduling
- Codex session lifecycle
- child session mapping
- artifact creation or update
- worktree lifecycle
- merge activity
- verification results
- audit findings
- completion summaries

## Audit Finding Contract

Audit findings are durable records, not ad hoc prose.

Severity meanings:

- `P0`
  A correctness, safety, or blocking failure that prevents acceptable completion.

- `P1`
  A major user-visible gap or regression that must be fixed before completion.

- `P2`
  An important missing capability, missing test coverage, or quality gap that still blocks completion.

- `P3`
  A lower-priority improvement that may remain open without blocking completion.

Finding kinds should include at least:

- `bug`
- `test_gap`
- `feature_gap`
- `spec_drift`
- `integration_risk`

Completion is blocked by any open `P0`, `P1`, or `P2` finding.

Waiver rules:

- only a human approval action may mark an open `P0`, `P1`, or `P2` finding as `accepted` or `wontfix`
- autonomous mode may mark findings `resolved` only when supported by verification or merged changes
- if a blocking finding requires waiver, the run must transition to `awaiting_approval`
- the durable waiver-request surface is the `AuditFinding` itself in `open` status plus the run's `awaiting_approval` state; the approving action writes a `finding_waiver` `ApprovalRecord` that references the waived finding id and rationale

## Verification And Audit Loop

The system is not done when execution says it is done. It is done when the audit loop cannot find any remaining important work.

### Audit Responsibilities

- identify missing implementation
- identify missing tests
- detect feature drift against specs and plans
- detect integration regressions
- reopen specs, plans, or TODOs when necessary

### Re-entry Rule

If audit finds any unresolved `P0`, `P1`, or `P2` issue, feature gap, or verification failure, the outer run must reopen execution and continue looping.

## Appendix: Packaging, Tooling, And Release

The project should be packaged and operated so it installs and launches cleanly with `uvx ralphception`.

This appendix is non-normative delivery infrastructure for follow-on work. It is explicitly outside the first core-runtime implementation plan.

### Packaging

- `pyproject.toml` with a console entry point for `ralphception`
- `uv`-native build and dependency management
- development dependencies for tests, linting, and type checking

### Task Runner

Use `mise` and `.mise.toml` as the canonical developer interface for:

- install
- run
- test
- lint
- format
- typecheck
- precommit

### Type Checking

Wire `ty` into the project and expose a `mise run typecheck` task.

### Pre-Commit

Use `.pre-commit-config.yaml` with repo-owned local hooks:

- formatting
- linting
- type checking
- tests

### GitHub Release Workflow

The repo should include a release workflow similar to `cmtr`'s publish workflow, using trusted publishing for PyPI.

Requirements:

- GitHub Actions workflow under `.github/workflows/`
- build distributions with `uv build`
- publish via `pypa/gh-action-pypi-publish`
- use OIDC trusted publishing with `id-token: write`
- configure a PyPI environment in GitHub Actions
- support release-driven publishing and manual workflow dispatch


## Testing Strategy

Testing should focus on orchestration correctness, not only prompt quality.

### Unit Tests

- config loading and persistence
- skill resolution
- run graph transitions
- event serialization
- artifact pathing
- XDG resume index behavior

### Integration Tests

- Codex session manager wrapper
- child run creation
- worktree allocation and cleanup
- merge coordinator decisions
- resume reconstruction

### End-to-End Tests

Use small fixture repositories for:

- generic seed prompt flow
- cross-repo porting flow
- audit loop reopening work
- crash and resume

### Golden Artifact Tests

Verify generated specs, plans, TODOs, and event log structure.

## Contract Examples

These examples are illustrative and non-normative, but they make the intended schemas concrete enough for planning.

For readability, some example arrays show artifact paths directly; the canonical durable form is still `ArtifactRef`.

### Example Approval Record

```json
{
  "approval_id": "approval-123",
  "run_id": "run-root",
  "approval_kind": "execution_bundle",
  "artifact_bundle_refs": [
    ".ralphception/specs/porting-spec.md",
    ".ralphception/plans/initial-plan.md",
    ".ralphception/todos/root.json"
  ],
  "bundle_version": 3,
  "scope_hash": "sha256:abc123",
  "approved_at": "2026-03-15T20:00:00Z",
  "approver": "user",
  "waived_finding_ids": null,
  "rationale": null
}
```

### Example Execution Bundle

```json
{
  "bundle_id": "bundle-3",
  "run_id": "run-root",
  "bundle_version": 3,
  "state": "derived_in_scope",
  "artifact_refs": [
    ".ralphception/specs/porting-spec.md",
    ".ralphception/plans/revised-plan.md",
    ".ralphception/todos/root.json"
  ],
  "base_bundle_id": "bundle-2",
  "scope_hash": "sha256:abc123",
  "created_at": "2026-03-15T20:10:00Z",
  "assigned_run_ids": ["run-child-a", "run-child-b"]
}
```

### Example Verification Spec

```json
{
  "verification_id": "verify-42",
  "run_id": "run-child-a",
  "task_id": "task-verify-42",
  "requested_by": "merge:task-7",
  "scope": "child_run",
  "required": true,
  "commands": [
    "mise run typecheck",
    "mise run test"
  ],
  "success_criteria": "all commands exit 0",
  "created_at": "2026-03-15T20:05:00Z"
}
```

### Example Skill Response

```json
{
  "status": "success",
  "artifact_updates": [
    {
      "artifact_ref": {
        "artifact_kind": "plan",
        "artifact_path": ".ralphception/plans/revised-plan.md",
        "artifact_version": 4,
        "content_hash": "sha256:plan4"
      },
      "apply_mode": "replace",
      "content": "# Revised Plan\n...",
      "safe_to_persist": true
    }
  ],
  "suggested_next": [
    {
      "kind": "child_run",
      "title": "Implement parser port",
      "goal": "Port the parser module to Python",
      "priority": "P1"
    }
  ],
  "findings": [],
  "markdown_body": "Plan updated to reflect audit findings."
}
```

### Example Event Payloads

```json
{
  "event_type": "task.started",
  "payload": {
    "task_kind": "child_run",
    "parent_task_id": "task-3",
    "child_run_id": "run-child-a"
  }
}
```

### Example Worktree Handoff

```json
{
  "child_run_id": "run-child-a",
  "worktree_path": "/tmp/ralphception/run-child-a",
  "branch_name": "codex/ralphception/run-child-a",
  "base_branch": "main",
  "head_commit": "abc1234",
  "goal": "Port parser module",
  "artifact_refs": [".ralphception/runs/run-child-a/summary.md"],
  "verification_artifact_refs": [".ralphception/runs/run-child-a/verify.json"],
  "consumed_bundle_version": 3,
  "touched_paths": ["src/parser.py", "tests/test_parser.py"],
  "verification_summary": "typecheck and tests passed",
  "merge_readiness": "ready",
  "cleanup_state": "pending"
}
```

```json
{
  "event_type": "artifact.promoted",
  "payload": {
    "artifact_kind": "plan",
    "artifact_path": ".ralphception/plans/revised-plan.md",
    "producing_run_id": "run-root"
  }
}
```

## Repository Structure

The implementation should stay modular enough that each unit is understandable without reading its internals. A likely initial package shape is:

```text
src/ralphception/
|- cli.py
|- app.py
|- config.py
|- models/
|- workflow/
|- codex/
|- skills/
|- ui/
|- storage/
|- git/
`- testing/
```

This is a guide for planning, not a locked file map.

## Risks And Constraints

- Codex model availability may differ across environments. The runtime needs graceful fallback behavior.
- Long-running nested sessions require careful checkpointing to avoid confusing partial recovery.
- Merge coordination can become a bottleneck if too many child runs finish simultaneously.
- Cross-repo citation quality will strongly affect porting effectiveness.

## Success Criteria For Core Runtime V1

Core runtime v1 is successful when it can:

- start from `uvx ralphception` in a target repo
- write `.ralphception/config.toml` and initialize repo-local artifacts
- gather a seed prompt and optional source repo paths
- run a Socratic loop before implementation
- generate specs and plans under `.ralphception/`
- wait for explicit approval before execution
- execute child runs autonomously after approval
- use worktrees for edit-heavy child runs
- squash-merge completed work through a merge coordinator
- run audit loops until no open `P0`, `P1`, or `P2` items remain
- recover after crashes through resume support

## Delivery Follow-On

After the core runtime v1 lands, the delivery appendix should add:

- trusted-publisher PyPI release workflow
- final `uvx` packaging polish
- pre-commit and developer-task automation

These follow-on items are explicitly out of scope for the first core-runtime implementation plan.
