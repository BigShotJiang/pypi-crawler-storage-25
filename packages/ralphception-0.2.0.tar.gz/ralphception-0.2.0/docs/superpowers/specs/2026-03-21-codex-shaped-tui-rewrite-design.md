# Codex-Shaped Ralphception TUI Rewrite Design

## Goal

Rebuild Ralphception as a chat-first terminal product that feels as close to Codex as Ralphception's product semantics allow.

This is a greenfield, breaking-change rewrite of both:

- the TUI shell
- the current screen-oriented runtime/frontend contract

The target is not "a better dashboard". The target is a Codex-like shell and interaction model backed by a Ralphception-specific mission runtime.

## Product Direction

The new product should behave like Codex by default:

- one transcript-first shell
- one bottom composer and footer/status model
- overlays instead of separate screens
- lightweight thread and subagent navigation
- transcript-native presentation of command output, approvals, review state, recovery, and subagent activity

Ralphception keeps its own identity through domain semantics, not through a separate UI model. Missions, stages, bundles, merge, recovery, and audit stay first-class concepts, but they are rendered through the same shell grammar Codex uses: transcript cells, overlays, status surfaces, and thread navigation.

## Current State

Today Ralphception is structurally split across multiple user surfaces:

- startup prompt
- review prompt
- dashboard
- terminal execution flow

That split is reflected in the current runtime contract, which still thinks in terms of `RuntimeStep` and screen-like frontend states rather than a continuous chat/session experience.

The codebase already contains several durable/domain pieces worth preserving:

- runtime models for runs, stages, tasks, bundles, approvals, and session refs
- append-only event storage
- approval persistence and snapshots
- worktree coordination
- merge and recovery machinery
- Codex session-manager integration

The design problem is therefore not "how to add a nicer shell on top of the current dashboard". The design problem is "how to replace the old screen-oriented product shape with a Codex-shaped system while preserving useful durable/domain machinery".

## Design Principles

### 1. Codex UX is the default

Use Codex's TUI as the primary model for:

- shell layout
- interaction model
- transcript behavior
- bottom-pane behavior
- overlay behavior
- subagent navigation

Departures should be rare and justified only when Ralphception's domain cannot be expressed cleanly otherwise.

### 2. No separate screens

The new system should not preserve distinct startup, review, dashboard, or recovery screens. Every current user-facing flow should be expressed through:

- transcript cells
- bottom-pane overlays
- status/header/footer surfaces
- mission/thread pickers or pagers

### 3. Runtime state stays canonical

The shell must not become a second source of workflow truth. Canonical state belongs to the runtime and durable stores. Shell state is a projection of runtime state plus live session signals.

### 4. Mission domain and session orchestration stay separate

Ralphception-specific mission policy should not get tangled with Codex session transport, worktree handling, or command streaming. Those concerns need explicit boundaries.

### 5. Cut over aggressively

Once the new system can cover the full user journey, the old UI and old frontend contract should be deleted rather than supported in parallel.

## Selected Architecture

The recommended architecture is a Codex-shaped shell over a new unified runtime protocol, backed by a split runtime core:

- `ChatShellApp`
- shell state and presentation primitives
- unified runtime protocol
- `MissionRuntime`
- `SessionOrchestrator`
- durable stores and execution providers

### Top-Level Layers

#### 1. ChatShellApp

`ChatShellApp` is the composition root for the new terminal UI.

Responsibilities:

- terminal lifecycle
- layout
- focus routing
- redraw scheduling
- global keyboard handling
- shell startup and cutover into the active mission/session

This layer should feel recognizably like Codex, not like a dashboard application.

#### 2. Shell State Model

The shell state model owns all presentation-facing state:

- committed transcript cells
- active streaming cell
- active thread
- subagent/thread list
- overlay stack
- status/header/footer state
- queued input and draft state
- pending approvals and request-user-input prompts

This state is rebuildable from the unified protocol stream plus current runtime snapshots.

#### 3. Unified Runtime Protocol

The old `RuntimeFrontend` / `RuntimeStep` contract should be removed. Replace it with one bidirectional action/event protocol.

Shell to runtime examples:

- `send_user_message`
- `approve_review`
- `reject_review`
- `submit_request_user_input`
- `spawn_subagent`
- `send_input_to_subagent`
- `switch_active_thread`
- `resume_mission`
- `resolve_conflict`
- `apply_recovery_action`
- `interrupt`
- `abort`
- `close_thread`

Runtime to shell examples:

- `transcript_delta`
- `transcript_commit`
- `command_started`
- `command_output`
- `command_finished`
- `subagent_spawned`
- `subagent_waiting`
- `subagent_completed`
- `subagent_failed`
- `subagent_closed`
- `review_requested`
- `review_resolved`
- `request_user_input_requested`
- `request_user_input_resolved`
- `status_updated`
- `session_list_updated`
- `active_thread_changed`
- `recovery_required`
- `recovery_result`

Ralphception-specific domain events like merge, audit, and execution-bundle review should live inside this same protocol vocabulary instead of owning bespoke frontend modes.

#### 4. MissionRuntime

`MissionRuntime` owns Ralphception's domain logic:

- mission identity and lifecycle
- runs, stages, tasks, bundles, approvals
- merge policy
- recovery policy
- verification and audit policy
- mission-specific status derivation

This is where Ralphception remains Ralphception.

#### 5. SessionOrchestrator

`SessionOrchestrator` owns live execution mechanics:

- Codex session lifecycle
- child-run/subagent session lifecycle
- worktree management
- command streaming
- session resume and recovery glue
- agent lifecycle signaling

It should be possible to understand `SessionOrchestrator` without understanding merge/audit policy, and vice versa.

#### 6. Durable Stores and Providers

These are the main reuse candidates from the current codebase:

- durable runtime models
- event store
- approval persistence
- artifact and bundle persistence
- session refs
- worktree coordinator
- merge coordinator where still appropriate
- Codex session manager integration

## Shell Model

### Single Shell Anatomy

The new shell should have one main layout:

- session header
- transcript viewport
- inline status surface
- bottom composer
- footer hints/status

There should be no persistent workflow tree.

### Transcript-First Rendering

The transcript is the primary user-facing history and control surface. It should include:

- user messages
- assistant commentary and final output
- command execution cells
- subagent lifecycle cells
- review and approval cells
- recovery and merge result cells
- audit result cells

Long-running or streaming items should use an active mutable cell that later commits into transcript history, matching Codex's interaction model.

### Overlays Replace Screens

The shell should use bottom-pane or pager overlays for:

- startup seed prompt
- request-user-input flows
- approvals and review actions
- conflict resolution
- recovery actions
- mission picker
- agent picker
- transcript pager or detail pager

Overlays are the only secondary surfaces. They should not become a substitute for the old screen split.

### Status Surfaces

Header/footer/status surfaces should carry:

- active mission and thread
- current stage
- active work or running tasks
- approval counts
- queued input state
- merge/audit/recovery summaries

Stages remain context, not a primary navigation axis.

## Session and Navigation Model

### Mission Thread = Root Run

The root run should be rendered as the primary mission thread. It owns:

- canonical mission transcript
- current stage context
- approval and review state
- merge and audit state
- user input

### Child Runs = Subagent Threads

Each child run should be treated as a first-class subagent thread. That means:

- child runs appear in agent/thread navigation
- child runs produce Codex-like subagent lifecycle cells
- replacement runs appear as new subagent threads that supersede older ones
- closed or replaced threads remain visible in history, dimmed or marked closed

### What Users Navigate Between

Primary navigation objects:

- missions
- subagent threads

Not primary navigation objects:

- stages
- bundles
- approvals
- recovery targets

Those should remain inside the active thread as transcript items or overlays.

## Rendering Grammar

Every major runtime condition should map into the same UI grammar:

- transcript cell
- overlay
- status update
- picker/pager entry

Examples:

- approvals -> review cell + approval overlay
- startup/conflict/recovery -> system cell + action overlay
- child-run lifecycle -> subagent transcript cells + agent picker updates
- merge and audit -> result cells + optional detail pager
- command output -> exec cell + pager for long output

The runtime should never ask for a screen. It should emit domain intents and state deltas, and the shell should render them.

## Reuse vs Replacement

### Reuse Likely

- `models/runtime.py`
- `models/session.py`
- `models/events.py`
- `storage/events.py`
- `workflow/approvals.py`
- worktree coordination
- merge machinery where the contract still fits
- session manager integration

### Replace Aggressively

- `runtime/frontends.py`
- `RuntimeStep`
- screen-oriented runtime resolution
- startup/review/dashboard screens
- dashboard tree/detail/event-feed architecture
- compatibility code whose only purpose is preserving the old UI split

## Recommended Greenfield Components

### Shell Components

- `ChatShellApp`
- `TranscriptStore`
- `TranscriptView`
- `Composer`
- `BottomPaneStack`
- `SessionNavigator`
- `StatusController`
- `OverlayRouter`
- `ProtocolClient`
- `EventProjector`

### Runtime Components

- `MissionRuntime`
- `SessionOrchestrator`
- durable stores/providers reused from the current system

### Boundary Rule

The shell should speak only through the unified protocol. Widgets and views should never reach directly into mission state stores, session managers, or merge/recovery services.

## Migration Strategy

This should be treated as a full rewrite program, but the implementation plan should still start with the foundation that de-risks everything else.

### Phase 1: Define the new spine

Build:

- unified protocol
- shell view models
- transcript cell models
- overlay models
- session navigation model
- status model

This phase defines the product shape.

### Phase 2: Build the shell against fixtures

Build the Codex-like shell against fake or fixture-based runtime streams so:

- layout
- keyboard behavior
- transcript behavior
- overlay behavior
- navigation behavior

can be stabilized before deeper runtime cutover.

### Phase 3: Rebuild runtime entrypoints behind the protocol

Replace screen-oriented runtime entrypoints with protocol-driven orchestration. Reuse durable/domain machinery where it still fits, but do not preserve the old screen contract.

### Phase 4: Cut over all user flows

Move all flows into the new shell:

- bootstrap
- planning
- execution
- approvals
- subagents
- merge
- recovery
- audit
- resume

### Phase 5: Delete old architecture

Once the new shell covers the end-to-end journey, remove:

- startup screen
- review screen
- dashboard screen
- `RuntimeFrontend`
- `RuntimeStep`
- any compatibility layer retained only for old architecture preservation

## Testing Strategy

### 1. Protocol contract tests

Validate action/event schemas and shell-runtime compatibility.

### 2. Shell behavior tests

Use render snapshots and key-routing tests to preserve:

- Codex-like layout
- transcript behavior
- overlay behavior
- navigation ergonomics

### 3. Runtime integration tests

Validate:

- approvals
- merge
- recovery
- audit
- session lifecycle
- subagent lifecycle

under the new protocol.

### 4. Golden mission scenarios

Use end-to-end scenarios that cover:

- bootstrap
- planning
- execution
- subagent activity
- approvals
- merge
- recovery
- audit

The system should be tested as a product, not just as disconnected components.

## Risks

- preserving too much of the old runtime contract and compromising the new shell
- under-specifying approvals, recovery, or merge/audit coverage in the unified protocol
- matching Codex's visual layout without matching its interaction feel
- allowing the old and new architectures to coexist too long

## Mitigations

- define protocol and shell model first
- keep mission domain separate from session/worktree orchestration
- treat transcript/overlay/status/thread navigation as the only presentation primitives
- set a hard deletion milestone once parity exists

## First Planning Scope

The next implementation plan should not try to execute the entire rewrite at once.

The first implementation plan should focus on:

1. defining the unified runtime protocol
2. defining shell view models and transcript cell types
3. building the first `ChatShellApp` skeleton
4. implementing transcript, bottom pane, status surfaces, and overlay routing
5. supporting fixture-based mission and subagent streams so Codex-like behavior can be validated early

That gives the rewrite a stable product spine before the deeper mission/runtime cutover work begins.

## Definition of Done

This rewrite is successful when:

- Ralphception has a single Codex-like chat-first shell
- startup/review/dashboard splits are gone
- missions and child runs render as mission threads and subagent threads
- approvals, recovery, merge, and audit live inside the new shell grammar
- the runtime speaks a unified event/action contract instead of screen steps
- the system feels like Codex with Ralphception's domain semantics, not like Ralphception wearing a Codex skin
