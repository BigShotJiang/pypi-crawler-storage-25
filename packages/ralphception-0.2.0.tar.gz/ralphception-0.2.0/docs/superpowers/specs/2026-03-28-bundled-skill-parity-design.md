# Bundled Skill Parity Design

## Summary

Ralphception's packaged Codex skills are the behavior layer for startup intake, PRD writing, plan writing, execution, and audit. They should not be thin reminders. They should carry enough of the `~/.codex/superpowers` structure and discipline that the stage prompts can stay compact and artifact-focused.

The main parity target is not verbatim copying. The target is behavioral parity:

- startup intake should feel like a compressed, repo-local `brainstorming` pass
- plan writing should feel like `writing-plans`, but produce Ralphception's durable loop artifacts
- execution and audit should feel like trimmed versions of `test-driven-development`, `verification-before-completion`, and review discipline
- execute and audit should explicitly carry the iron-law and severity/reopen rules instead of assuming runtime prompts will fill them in

## Problem

The current bundled skills are useful but still too thin:

- they describe the stage in a paragraph or two
- they do not include the reference skill structure that helps the model decide what to do next
- they do not explicitly teach self-review, no-placeholder discipline, or completion bars
- the planning skill does not explain why Ralphception needs both markdown and structured outputs
- the planning skill does not yet teach zero-context execution, exact task structure, or loop-safe checkpointing strongly enough

That means too much of the planning behavior still lives in developer expectations rather than in the packaged skill documents.

## Goals

- Make the bundled startup/spec/plan skills much closer to the reference superpowers skills in structure and rigor.
- Keep the differences explicit where Ralphception needs durable artifacts instead of human handoff.
- Pin the new discipline in tests so the bundle cannot regress back to thin prompts.

## Non-Goals

- Replacing Ralphception's stage prompts or artifact contracts
- Making the bundled skills exact copies of the personal superpowers skills
- Reworking runtime behavior beyond the skill content and tests required to keep it stable

## External Validation

Two external points reinforce this direction:

- Anthropic's Claude Code documentation treats plan mode as a distinct planning pass before execution, which supports keeping startup/spec/plan as explicit stages instead of blurring them together.
- OpenAI's prompt-optimization guidance recommends clear operating steps, narrow desired output properties, and manual review before production use, which supports richer static skill instructions plus stronger tests.

For Ralphception specifically, local code is the authoritative source for the planning outputs. The plan stage in `src/ralphception/headless.py` already requires:

- markdown plan output
- JSON contract with `execution_goal`
- `verification_commands`
- `todos`
- `commit_intents`
- `execution_policy`

So the bundled planning skill should teach that output contract directly.

## Design

### Startup intake

Rewrite `ralph-startup-intake` to mirror the reference `brainstorming` shape:

- overview
- anti-pattern for "too simple" tasks
- when to use / when not to use
- working assumptions
- checklist
- explicit intake flow
- question strategy
- completion bar
- common mistakes

It should still stay compressed and repo-local, but it should teach:

- inspect context first
- ask the smallest useful question
- decompose if the task is really multiple subsystems
- stop as soon as the PRD can be written safely

### Spec writing

Rewrite `ralph-spec-writing` to mirror the reference design/spec discipline:

- required structure
- explicit inputs
- writing guidance
- design for isolation and clarity
- Ralphception-specific role in later stages
- self-review
- common mistakes

This keeps the PRD concrete without turning it into an implementation plan.

### Plan writing

Rewrite `ralph-plan-writing` to mirror `writing-plans` much more directly:

- scope check
- file map
- bite-sized task granularity
- standard plan header
- task structure template
- zero-context worker assumptions
- loop-safe slice design
- task discipline
- no placeholders
- self-review

Then add a Ralphception-specific section for the structured outputs:

- markdown plan
- JSON contract
- todos
- commit intents
- execution policy

### Execute and audit

Keep them shorter than the reference skills, but strengthen them so they still carry:

- when-to-use guidance
- core discipline
- iron-law execution and verification gates
- review severity and reopen-vs-complete rules
- verification or evidence ladder
- common mistakes

## Testing

Expand `tests/unit/test_codex_skill_materialize.py` so the installed bundle is pinned for:

- startup intake structure and completion bar
- spec required structure and self-review
- planning header, bite-sized tasks, no placeholders, and Ralphception outputs
- execution common mistakes
- audit no-findings short-circuit

## Risks

- Skills may become too long and drift into meta narration.
- Copying the reference structure too literally could add steps that do not fit a fully automated stage.

## Mitigations

- Keep the sections, not the fluff.
- Adapt the human handoff parts into Ralphception artifact contracts.
- Use tests to pin the important behavior instead of huge verbatim blocks.
