# Cursor Row Parity Design

**Problem**

The Codex-style Ralphception TUI computes the terminal cursor row incorrectly when header, notice, or active-cell content exists above the bottom pane. The current Python `ChatWidget.cursor_pos()` treats the bottom pane as if it begins at viewport row 0, so the terminal cursor can land above the visible composer even though the input box is rendered at the bottom.

**Goal**

Make terminal cursor placement follow the actual live render tree so the terminal cursor lands on the composer row, not on the top of the viewport.

**Design**

- Treat `ChatWidget` as a stacked render tree with explicit sections:
  - header
  - notice band
  - active cell
  - bottom pane
- During rendering, compute both:
  - the full rendered line list
  - the starting row index of the bottom pane inside that list
- Use that bottom-pane start offset when computing cursor position.

**Why This Fix**

This addresses the real structural mismatch that the screenshot exposed without inventing more shell-specific hacks. The bug is not just styling. It is that cursor placement was being calculated from the wrong origin.

**Non-Goals**

- Full ratatui buffer parity in this slice
- Rewriting the entire Python Codex TUI renderer
- Changing scrollback insertion or trust/startup flow behavior

**Verification**

- Unit test for a widget with header + notice + bottom pane asserts cursor row matches the composer row
- Existing Codex TUI adapter/tmux tests remain green
