# Launch Resume Gate Design

## Summary

Ralphception should stop treating resume as a separate picker-driven workflow and instead behave like Codex: when the user reopens the app after an interruption, the shell should detect the unfinished session, ask whether to resume it, and then either restore that session in place or start fresh.

The workspace only needs to support a single resumable root session at a time under `.ralphception`. That constraint should simplify the UX and the persistence model: there is no session history browser, no `/resume` command, and no “mission” framing in the default shell chrome.

## Product Contract

### Fresh launch

If the workspace has no resumable session, `uv run ralphception` opens the normal shell with the composer focused.

### Interrupted launch

If the workspace has one resumable session, `uv run ralphception` opens the normal shell frame with a compact blocking prompt:

- `Resume last session`
- `Start fresh`

This is a launch-time decision, not a picker flow.

### Resume

If the user chooses resume:

- Ralphception restores the last shell session instead of synthesizing a new one.
- The active Codex thread/session is resumed directly when possible.
- The last active thread/subagent context is restored when possible.
- Pending blocking state such as approvals, recovery prompts, or required user input reappears in place.
- The user should be able to reopen the app and simply tell it to continue.

### Start fresh

If the user chooses start fresh:

- Ralphception clears the resumable-session marker for the workspace.
- The shell opens as a fresh session.
- Any first-run startup capture still happens if the workspace truly has no seed prompt yet.
- The user is not shown resume affordances again unless a later interruption creates a new resumable session.

### Hydration failure

If Ralphception detects resumable state but cannot restore the stored Codex thread/session, the shell should offer a direct fallback choice instead of silently starting over:

- `Start fresh`
- `Cancel`

The app must never pretend a resume worked when it actually fell back.

## UX Changes

### Remove resume as a normal interactive mode

The following surfaces should be removed from the interactive product path:

- `/resume`
- the resume picker
- launch copy that suggests resuming via a separate command

The public `ralphception resume` CLI command should also be removed or repurposed out of the normal end-user product surface. Reopening `ralphception` and answering the launch-time prompt is the only supported interactive resume path.

Internal workflow semantics such as review actions named `resume` may remain if they still mean “continue this blocked workflow” rather than “reopen a previous session.” Low-level recovery code may remain internally if it is still needed to repair state, but it should no longer define the normal shell UX.

### Remove mission-first chrome

The default shell should no longer present a `mission` label in the header card. Ralphception-specific context can still appear when useful, but the opening shell should feel like a Codex-style session shell rather than a mission dashboard.

### Launch prompt style

The resume prompt should use the same Codex-style shell and bottom-pane/overlay grammar as the rest of the TUI. It should not be implemented as a separate screen or picker.

## Persistence Model

Ralphception only needs to track one resumable interactive session per workspace.

The source of truth should be a single workspace-level marker file:

- `.ralphception/interactive-session.json`

That marker should be written and cleared deterministically by the interactive shell path. It should identify:

- the root run id
- the last active run id for the currently selected thread context
- whether the session is resumable
- whether a blocking shell surface was active
- the blocking surface kind, when one exists
- the last updated timestamp

This state should be updated so that:

- incomplete interactive sessions are resumable
- cleanly completed or explicitly discarded sessions are not
- the “start fresh” action clears the resumable marker deterministically

The Codex thread/session ids do not need to be duplicated into this marker because they already live in the persisted per-run `run.json` files through `codex_session_ref`. The marker only needs to point the launcher at the correct root run and active run/thread selection.

### Existing workspaces

This feature must work for preexisting Ralphception workspaces that already contain durable runtime state but no `interactive-session.json`.

For those workspaces, launch detection should:

- first look for `.ralphception/interactive-session.json`
- if it is missing, inspect the existing root-run durable state under `.ralphception/runs/run-root/`
- if the existing run state clearly represents an unfinished interactive session with a resumable `codex_session_ref`, synthesize the launch decision from that legacy state
- if the existing root run is unfinished but has no resumable `codex_session_ref`, or the stored Codex session is missing/invalid, classify the launch as broken-resume rather than fresh
- if the legacy root run exists but bootstrap/session state is incomplete or contradictory across `startup.json`, `run.json`, and `headless-state.json`, classify the launch as broken-resume rather than fresh
- if the existing root run is terminal/completed, classify the launch as fresh
- write the new marker only after the shell successfully enters the resumed or fresh interactive path

This keeps older workspaces resumable without requiring a one-time migration command.

`startup.json` remains the bootstrap record for whether the workspace already has a first prompt and source repositories. It stays independent from `interactive-session.json`.

`headless-state.json` remains backend/runtime state and legacy recovery input. It may be consulted only when `interactive-session.json` is absent during the legacy fallback path, but once the new marker exists it is no longer the primary source of truth for the interactive resume UX.

Legacy launch classification precedence must be deterministic:

1. If `interactive-session.json` exists, use it.
2. Otherwise, if neither `startup.json` nor `.ralphception/runs/run-root/run.json` exists, classify as fresh.
3. Otherwise, if the root run is terminal/completed, classify as fresh.
4. Otherwise, if the root run is unfinished and the chosen active run has a valid resumable `codex_session_ref`, classify as resumable.
5. Otherwise, classify as broken-resume.

“Chosen active run” in the legacy fallback path means:

- the run referenced by the new marker, if present
- otherwise the root run

There is no additional heuristic search across child runs in the legacy path.

## Architecture

### Launch-time detection

The app bootstrap layer should resolve one of three states before normal startup:

- no resumable session
- resumable session available
- resumable session metadata exists but is broken

That resolution should happen before the current startup/review/dashboard shell branching. Broken metadata means the marker exists but the referenced root run, active run, or Codex session ref cannot be resolved into a resumable shell state.

The launcher must gain an explicit broken-resume branch. It is not acceptable for this state to fall through into the existing startup, review, or dashboard branches, and it must not silently repair state before the user chooses an action.

### Shell integration

The runtime adapter should expose a launch overlay for “resume last session or start fresh” instead of surfacing a resume picker. This overlay belongs in the same bottom-pane/overlay system already used for approvals and startup prompts.

### Session restoration

When resuming, Ralphception should rehydrate the shell from the stored session state and then attach to the persisted Codex thread/session through the existing session manager and recovery plumbing. The important behavioral rule is that the shell reopens the previous session; it does not construct a new mission summary that merely points at old artifacts.

The minimum durable UI context required for this is:

- the root run id from the workspace marker
- the active run id from the workspace marker
- the persisted `codex_session_ref` for that active run from `run.json`
- the persisted blocking-surface kind from the workspace marker, if present

The resume path only needs to restore the last active thread context, not an arbitrary history of past thread selections. If `active_run_id` is missing, the launcher falls back to the root run id. If `active_run_id` is present but the referenced run cannot be resumed, launch classification becomes broken-resume instead of falling back silently.

### Hydration failure handling

If the launch resolver finds a marker but cannot restore the referenced state, it should return a dedicated broken-resume launch state rather than collapsing that case into “no resumable session.” The shell should then present a compact blocking prompt with:

- `Start fresh`
- `Cancel`

`Start fresh` clears `.ralphception/interactive-session.json` and continues with normal startup. `Cancel` leaves the marker in place and exits or leaves the shell unopened.

Launch detection for broken metadata should be non-destructive. It must not rewrite or partially repair the marker before the user chooses an action. The only automatic mutation allowed in this path is diagnostic logging; the marker itself should remain untouched until the user explicitly chooses `Start fresh`.

## Acceptance Criteria

- Reopening the app after interruption prompts exactly once to resume or start fresh.
- Choosing resume restores the last shell session in place.
- Choosing start fresh clears the resumable marker and opens a clean shell.
- `/resume` is gone.
- The resume picker is gone.
- `ralphception resume` is gone as a normal public entrypoint.
- No TUI slash-command menu, help text, footer hint, or terminal-facing user help still advertises `/resume` or a separate manual resume path.
- No user-facing CLI or terminal path still advertises or accepts a separate `resume` / `--resume` flow for reopening the last session.
- The default header no longer shows a `mission` label.
- If session hydration fails, the user gets an explicit fallback choice instead of a silent reset.
- A workspace created before `interactive-session.json` exists can still resume from its older durable run/session state on first launch after the upgrade.
- `startup.json` still controls first-run bootstrap independently from the interactive session marker.
- `src/ralphception/cli.py` no longer exposes `ralphception resume` as a public end-user command, and the CLI test coverage reflects that removal.
- `src/ralphception/app.py` resolves launch state through explicit branches for fresh, resumable, and broken-resume startup instead of collapsing broken resume into startup, review, or dashboard.
- Legacy workspaces with missing, stale, or contradictory session/bootstrap state resolve to broken-resume, not fresh, and do not self-repair before user choice.
- `src/ralphception/tui/bottom_pane/slash_commands.py`, `src/ralphception/tui/resume_picker.py`, resume-oriented branches in `src/ralphception/tui/app.py` and `src/ralphception/tui/runtime_adapter.py`, and terminal-facing resume copy are all removed or repurposed so no manual resume affordance remains in the interactive product.
