# Codex Bottom Pane Parity Design

## Goal

Close the remaining quality gap between Ralphception's Python Codex TUI port and the real Codex bottom pane by replacing string-assembled busy/footer rows with structured rendering that matches Codex's spacing, state transitions, and visual rhythm.

## Problems

The current `src/ralphception/codex_tui` bottom pane still behaves like a handcrafted text export:

- busy state is a single static string instead of a dedicated status-indicator renderable
- spacing around the busy row, composer, and footer is inconsistent
- footer behavior does not match Codex's "shortcuts", "queue message", and passive status-line rules
- startup intake still biases the model toward scope clarification even though Ralphception should assume the whole repo and referenced outside folders are in scope

These issues create the "cheap knockoff" feel the user called out, even though the major control-flow bugs are already fixed.

## Design

### 1. Port the structured bottom-pane model into `codex_tui`

Introduce a lightweight structured state/render layer in `src/ralphception/codex_tui` that mirrors the already-existing widget-oriented implementation under `src/ralphception/tui/bottom_pane`:

- structured status indicator state
- structured footer state
- deterministic spacing rules between:
  - status indicator
  - pending/active views
  - composer surface
  - footer row

The goal is not a full Textual port. The goal is to reuse the same layout decisions in the ANSI/string renderer used by `codex_tui`.

### 2. Replace `waiting_line: str` with a structured status indicator

The current `BottomPane.waiting_line` field should become a dedicated status-indicator state object with:

- `header`
- `details`
- `inline_message`
- `show_interrupt_hint`
- `elapsed_seconds`
- `animations_enabled`

Rendering rules:

- first line uses Codex-style `"Working (Xs • esc to interrupt)"` formatting
- optional inline message appears after ` · `
- optional details render on following lines with `  └ ` prefix and continuation indentation
- when busy, insert a blank spacer row before the composer surface

### 3. Port footer mode/layout rules

Codex uses the footer for different purposes depending on whether the composer is empty, has a draft, or the task is running. `codex_tui` should follow the same rules:

- idle empty composer: `? for shortcuts` on the left, context right summary on the right
- draft while idle: passive status line if enabled, otherwise shortcuts/context behavior
- draft while running: `tab to queue message` on the left, contextual summary on the right
- active reply-blocker footer: keep the reply submit hint
- passive status row should only appear when the mode allows ambient context

This should eliminate the current footer layout drift and give the shell better "breathing room".

### 4. Add shimmer-capable status text

The ANSI renderer should support a Codex-style shimmer treatment for the busy header text:

- time-based sweep derived from process start or render time
- RGB shimmer when truecolor is available
- readable dim/bold fallback when it is not

This is only for the busy header text, not the whole row.

### 5. Assume full-repo scope in startup intake

Ralphception should treat the whole repository and referenced outside folders as in scope by default. The startup intake skill/prompt should no longer ask "which files are in scope?" unless the user explicitly narrows the task or the model identifies a materially different ambiguity.

That change belongs in the startup skill/prompt contract, not in ad hoc UI logic.

## Files

Expected touch set:

- `src/ralphception/codex_tui/bottom_pane.py`
- `src/ralphception/codex_tui/chatwidget.py`
- `src/ralphception/codex_tui/status.py`
- `src/ralphception/codex_tui/styled_text.py`
- `src/ralphception/codex_tui/ralph_adapter.py`
- `src/ralphception/runtime/startup_llm.py`
- `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- `tests/unit/codex_tui/test_chatwidget.py`
- `tests/unit/codex_tui/test_ralph_adapter.py`
- `tests/unit/codex_tui/test_status.py`
- `tests/integration/test_codex_tui_tmux.py`

## Success Criteria

- busy state shows immediately after submitting the first prompt or a blocker reply
- busy state has a dedicated status row with consistent spacing above the composer
- footer mode changes match Codex more closely in idle, running, and queued-message states
- shimmer/styling makes the busy row feel alive instead of static
- startup intake no longer asks for repo/file scope by default
- tmux comparison against `~/code/codex` shows materially improved spacing and behavior
