# Codex App-Server TUI Python Port Design

**Goal:** Replace Ralphception's broken human terminal frontend with a Python port of the `~/code/codex/codex-rs/tui_app_server` terminal architecture, adapted to Ralphception runtime events and workflows.

**Non-goals:**
- Rewriting `ralphception exec`
- Changing Ralphception's orchestration semantics beyond what is required to fit the Codex TUI contract
- Preserving the current Textual or ANSI string-logger frontends as shipped human paths

## Reference Architecture

The reference implementation is the old Codex TUI app-server path, not `tuiv2`:

- `~/code/codex/codex-rs/tui_app_server/src/tui.rs`
- `~/code/codex/codex-rs/tui_app_server/src/custom_terminal.rs`
- `~/code/codex/codex-rs/tui_app_server/src/insert_history.rs`
- `~/code/codex/codex-rs/tui_app_server/src/app.rs`
- `~/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui/src/history_cell.rs`
- `~/code/codex/codex-rs/tui/src/markdown_render.rs`

The decisive behavior is:

1. The terminal owns a bottom-anchored live viewport.
2. Committed transcript history is inserted into normal terminal scrollback above that viewport.
3. The live viewport height is recomputed from the current chat widget render tree each frame.
4. Transcript state is split into committed history cells plus one mutable active cell.
5. Alternate-screen overlays are optional overlays on top of the inline viewport, not the main shell mode.

## Problems In Ralphception

The current Ralphception human path diverges in two incompatible ways:

1. `src/ralphception/runtime/codex_terminal.py` implements an ANSI line logger with a fake viewport instead of the Codex terminal pipeline.
2. `src/ralphception/tui/app.py` still models a full-screen Textual shell with a bounded transcript region, which is the opposite of the Codex scrollback-first design.

The result is the behavior the user reported:

- the shell controls the whole viewport instead of inserting committed history into scrollback
- tmux rendering is fragile and often blank or corrupted
- transcript/history is modeled as strings rather than committed render cells
- the live viewport does not track Codex's active-cell and bottom-pane semantics

## Target Architecture For Ralphception

Ralphception should adopt the same terminal layering as Codex and only adapt the event source and domain-specific transcript cells.

### 1. Terminal Core

New package:

- `src/ralphception/codex_tui/custom_terminal.py`
- `src/ralphception/codex_tui/insert_history.py`
- `src/ralphception/codex_tui/tui.py`

Responsibilities:

- raw terminal mode
- cursor tracking
- viewport area tracking
- resize handling
- queued history insertion above the live viewport
- alternate-screen entry and exit for overlays only

This package replaces the shipped use of `runtime/codex_terminal.py` for the human path.

### 2. Transcript Rendering Model

New package files:

- `src/ralphception/codex_tui/history_cell.py`
- `src/ralphception/codex_tui/markdown_render.py`
- `src/ralphception/codex_tui/chatwidget.py`

Responsibilities:

- define committed transcript units as cells
- maintain one mutable active cell
- produce width-aware display lines
- compute live viewport height
- expose transcript overlay live-tail state

Ralphception-specific runtime events will map into these cell types, but the render contract should mirror Codex.

### 3. Bottom Pane And Shell

New files:

- `src/ralphception/codex_tui/bottom_pane.py`
- `src/ralphception/codex_tui/status.py`
- `src/ralphception/codex_tui/app.py`

Responsibilities:

- composer
- footer/status line
- waiting/blocker state
- overlay routing
- top-level app event loop
- committed-history insertion orchestration

The shell should launch into the same idle state as Codex, then Ralphception-specific Socratic intake begins as normal assistant/user transcript content.

### 4. Ralphception Adapter Layer

New file:

- `src/ralphception/codex_tui/ralph_adapter.py`

Responsibilities:

- translate `ralphception.runtime.frontends.FrontendEvent` into Codex-style app events and history cells
- preserve Ralphception-specific events such as artifact writes, loop launch/completion, review prompts, and startup prompts
- keep `ralphception exec` on the existing non-interactive path

This layer is where Ralphception diverges functionally while staying Codex-native mechanically.

## File Map

### New shipped human-path files

- `src/ralphception/codex_tui/__init__.py`
- `src/ralphception/codex_tui/custom_terminal.py`
- `src/ralphception/codex_tui/insert_history.py`
- `src/ralphception/codex_tui/tui.py`
- `src/ralphception/codex_tui/app.py`
- `src/ralphception/codex_tui/chatwidget.py`
- `src/ralphception/codex_tui/history_cell.py`
- `src/ralphception/codex_tui/markdown_render.py`
- `src/ralphception/codex_tui/bottom_pane.py`
- `src/ralphception/codex_tui/status.py`
- `src/ralphception/codex_tui/ralph_adapter.py`

### Existing files to modify

- `src/ralphception/app.py`
- `src/ralphception/runtime/terminal.py`
- `src/ralphception/runtime/frontends.py`
- `src/ralphception/runtime/supervisor.py`
- `src/ralphception/headless.py`

### Existing files to remove from the shipped human path

- `src/ralphception/runtime/codex_terminal.py`
- `src/ralphception/runtime/inline_shell.py`
- `src/ralphception/tui/app.py`
- `src/ralphception/tui/runtime_adapter.py`
- `src/ralphception/tui/chatwidget/*`
- `src/ralphception/tui/bottom_pane/*`

Some of those can remain temporarily during the port, but they should not remain on the final human-path hot path.

## Verification Contract

The port is only done when these are all true:

1. `uv run ralphception` in tmux uses the new Codex-style human TUI.
2. Committed transcript lines scroll into terminal history above the live viewport.
3. The bottom composer/status region stays anchored while history moves upward.
4. First prompt always begins Socratic intake in-chat.
5. Assistant output, command output, blocker prompts, artifact writes, loop launches, and settled completions all become durable committed history.
6. `ralphception exec` remains scriptable and non-interactive.
7. The current ANSI logger and Textual shell are no longer the shipped human path.

## Risks

1. Python terminal behavior in tmux may differ subtly from Rust/crossterm.
   Mitigation: port the terminal control flow directly, test in fresh tmux sessions after each slice.

2. Ralphception runtime events are lower-level and noisier than Codex app-server notifications.
   Mitigation: keep a dedicated adapter layer instead of letting terminal code know about Ralphception internals.

3. Legacy frontends may keep influencing the entrypoint or tests.
   Mitigation: rewire `run_app()` early and keep explicit regression tests for the active human path.
