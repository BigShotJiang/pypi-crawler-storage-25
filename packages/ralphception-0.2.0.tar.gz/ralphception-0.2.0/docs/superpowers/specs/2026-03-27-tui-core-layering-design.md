# TUI Core Layering Design

## Goal

Make Ralphception's Codex-style terminal UI feel like a real port instead of a screenshot-matched imitation by separating low-level terminal/layout primitives from higher-level Codex transcript and runtime behavior.

The first implementation slice should fix the most visible parity problems:

- bottom-pane spacing still drifts from Codex
- the composer cursor is not visually centered in the surfaced input row
- busy/loading states do not have the same breathing room or animation quality
- layout fixes are hard because low-level ANSI math and high-level transcript policy are mixed together

## Current Problem

`src/ralphception/codex_tui` currently owns too many responsibilities at once:

- ANSI terminal backend and cursor math
- styled text width/truncation rules
- bottom-pane layout rules
- transcript/history cell rendering
- Ralphception-specific runtime state mapping

That makes parity work fragile. A spacing fix in `chatwidget.py` or `bottom_pane.py` often compensates for a lower-level cursor/layout problem instead of fixing the real seam.

Codex does not organize the code that way. Its lower-level terminal/layout machinery is separate from the higher-level chat widget and runtime-specific state machine. That separation is what makes its spacing and cursor behavior feel stable.

## Layering

### 1. `tui_core`

This is the low-level, reusable render substrate. It should contain only terminal and layout primitives.

Responsibilities:

- terminal backend abstraction
- viewport anchoring and repaint logic
- cursor placement math
- ANSI/styled-span rendering helpers
- visible-width measurement, truncation, padding, wrapping
- low-level renderables for:
  - composer surface
  - footer layout
  - status indicator
  - shimmer animation

Non-responsibilities:

- transcript/history semantics
- startup shells or trust screens
- Ralphception runtime events
- Codex-specific state machines beyond pure layout/render rules

### 2. Codex-port UI layer

Keep `src/ralphception/codex_tui` as the higher-level Codex-port layer for now, but narrow it so it composes `tui_core` primitives instead of re-implementing them ad hoc.

Responsibilities:

- transcript/history cells
- startup shell, trust shell, loading shell
- active-cell and committed-history composition
- bottom-pane state selection using low-level core primitives
- Codex-parity rendering rules for chat surfaces

This layer should decide what kind of UI surface to show, but not how low-level cursor math or footer width negotiation works.

### 3. Ralphception runtime adapter

This remains the outermost layer:

- translate Ralphception runtime/front-end events into Codex-port UI state
- decide when to show blocker prompts, failures, loop launches, approvals, and busy states
- remain ignorant of ANSI/cursor/layout details

`ralph_adapter.py` should become a mapping layer, not a place where layout hacks accumulate.

## First Slice

Do not rewrite the entire TUI in one pass. The first slice should extract and port only the seams causing the current visible drift.

### Slice Scope

1. Extract low-level bottom-pane primitives into `src/ralphception/tui_core/`
2. Port the current bottom-pane to use those primitives
3. Keep the public behavior in `codex_tui` intact except for the intended parity improvements
4. Prove the improvements in tmux against `~/code/codex`

### Slice Contents

#### `tui_core.terminal`

Move or mirror the low-level terminal objects currently living in:

- `src/ralphception/codex_tui/custom_terminal.py`
- `src/ralphception/codex_tui/tui.py`

The extracted core should own:

- viewport rectangle
- frame rendering
- cursor position tracking
- history insertion math
- top-anchor vs inline-anchor behavior

`codex_tui` can keep compatibility wrappers during the migration, but the implementation should move down into `tui_core`.

#### `tui_core.text`

Move the styled-span and visible-width helpers behind a stable core interface:

- ANSI-safe width measurement
- truncation with ellipsis
- padding to terminal width
- wrapped line composition

This is the substrate used by both the bottom pane and transcript rendering.

#### `tui_core.bottom_pane`

Introduce low-level primitives for:

- `StatusIndicatorState`
- `FooterLayoutState`
- `ComposerSurfaceState`
- `BottomPaneLayout`

These are render/layout primitives, not runtime objects.

The important change is that the low-level bottom pane owns:

- row ordering
- spacer rows
- footer width negotiation
- cursor placement relative to the composer surface

That is the seam currently causing the cursor and spacing drift.

#### `codex_tui` usage

`src/ralphception/codex_tui/chatwidget.py` and `bottom_pane.py` should become composition code over `tui_core`, not the place where row math is recomputed independently.

## Why This Fixes The User-Visible Problems

### Spacing parity

Right now spacing is "incidentally correct" when a few string-assembled rows line up. Moving row ordering and footer negotiation into `tui_core.bottom_pane` makes that spacing deterministic and testable.

### Cursor centering

The cursor-background mismatch is a low-level composer/cursor problem, not a transcript problem. Putting composer surface dimensions and cursor coordinates in the same low-level primitive removes the drift between what is painted and where the cursor is placed.

### Shimmer quality

The status line shimmer belongs in a low-level render primitive, not in the higher-level adapter. That lets us match Codex's behavior more closely and reuse the same animation logic anywhere a shimmered status row is needed.

### Easier future parity work

Once the low-level substrate is separate, future transcript/history-cell parity work can compare Ralphception's higher-level Codex-port UI directly against `~/code/codex` without re-litigating ANSI math and cursor placement every time.

## File Strategy

### New low-level package

Create:

- `src/ralphception/tui_core/__init__.py`
- `src/ralphception/tui_core/terminal.py`
- `src/ralphception/tui_core/text.py`
- `src/ralphception/tui_core/status_indicator.py`
- `src/ralphception/tui_core/footer.py`
- `src/ralphception/tui_core/composer.py`
- `src/ralphception/tui_core/bottom_pane.py`

These names are descriptive and map cleanly to the Codex concepts we are porting.

### Existing higher-level package

Modify:

- `src/ralphception/codex_tui/custom_terminal.py`
- `src/ralphception/codex_tui/tui.py`
- `src/ralphception/codex_tui/status.py`
- `src/ralphception/codex_tui/bottom_pane.py`
- `src/ralphception/codex_tui/chatwidget.py`
- `src/ralphception/codex_tui/ralph_adapter.py`

Initially these modules can delegate to `tui_core` while keeping import compatibility. A later cleanup pass can reduce or rename them further if needed.

## Testing Strategy

### Unit tests

Add low-level tests for:

- visible-width-safe footer layout
- composer surface row rendering
- cursor placement relative to the surfaced composer row
- status indicator shimmer and truncation behavior

### Higher-level Codex TUI tests

Keep and extend current tests for:

- startup shell layout
- busy state spacing
- blocker reply layout
- passive footer vs shortcuts footer mode

### tmux verification

Always compare the first slice against `~/code/codex` in tmux for:

- startup shell placement
- busy/loading row spacing
- composer surface placement
- cursor placement inside the input row

## Success Criteria

- the input cursor sits inside the visual composer surface instead of drifting against the background row
- busy/loading states have the same vertical rhythm as Codex: status row, spacer, composer, footer
- footer width negotiation behaves consistently at narrow widths
- `codex_tui` becomes thinner because low-level math lives in `tui_core`
- future transcript/history-cell parity work can happen above the low-level core without reintroducing cursor/layout bugs
