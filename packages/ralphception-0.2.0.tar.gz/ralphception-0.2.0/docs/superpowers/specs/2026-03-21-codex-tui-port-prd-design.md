# Codex TUI Port PRD For Ralphception

## Goal

Rebuild Ralphception's terminal user interface by porting the design and interaction model of the Codex app from `~/code/codex` into Ralphception's Python/Textual stack.

This is not a "Codex-inspired redesign." It is a Codex-first product rewrite. Ralphception should use the Codex app's shell grammar, layout, interaction semantics, and component structure as directly as practical, then adapt Ralphception-specific mission semantics into that shell.

## Problem Statement

Ralphception's current shell does not meet the product target.

The current UI still behaves like a lightly skinned mission dashboard:

- plain text status line at the top
- plain transcript rendering
- stub bottom composer
- no Codex-style session header card
- no Codex-style footer model
- no Codex-style overlay and picker system

This is a structural mismatch, not a polish issue. The current shell architecture is too shallow and too custom to ever converge on the Codex app by incremental tuning.

## Product Contract

Ralphception should ship as a Codex app style terminal product.

The Codex app is the design standard for:

- shell layout
- visual hierarchy
- transcript rendering model
- bottom composer behavior
- footer and status behavior
- overlays and pickers
- slash-command behavior
- thread and subagent navigation
- idle, running, warning, error, and completion presentation

Ralphception-specific semantics should be adapted into that shell rather than expressed through different UI primitives.

If Ralphception currently has a UI primitive and Codex already has an equivalent, the Codex pattern wins.

## Source Of Truth

The primary design and implementation references are the Codex source tree and its snapshot corpus.

Key source modules:

- `~/code/codex/codex-rs/tui/src/app.rs`
- `~/code/codex/codex-rs/tui/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui/src/chatwidget/session_header.rs`
- `~/code/codex/codex-rs/tui/src/bottom_pane/chat_composer.rs`
- `~/code/codex/codex-rs/tui/src/bottom_pane/footer.rs`
- `~/code/codex/codex-rs/tui/src/bottom_pane/approval_overlay.rs`
- `~/code/codex/codex-rs/tui/src/bottom_pane/request_user_input/*`
- `~/code/codex/codex-rs/tui/src/bottom_pane/slash_commands.rs`
- `~/code/codex/codex-rs/tui/src/multi_agents.rs`
- `~/code/codex/codex-rs/tui/src/resume_picker.rs`

Where the app-server path is the more current implementation, use:

- `~/code/codex/codex-rs/tui_app_server/src/app.rs`
- `~/code/codex/codex-rs/tui_app_server/src/app/app_server_adapter.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/*`

Visual acceptance should be anchored to the Codex snapshot files under:

- `~/code/codex/codex-rs/tui/src/**/snapshots`
- `~/code/codex/codex-rs/tui_app_server/src/**/snapshots`

## Scope

This PRD covers the full user-visible lifecycle of the Ralphception terminal product:

- launch and empty state
- intake and seed prompt behavior
- active mission execution
- command streaming
- approvals and reviews
- request-user-input flows
- subagent and thread navigation
- recovery and error states
- completion
- resume and history
- shell-wide keyboard behavior
- shell-wide slash-command behavior

This PRD also covers the architectural rewrite required to support that UX.

## Non-Goals

This rewrite does not preserve legacy Ralphception UI surfaces for compatibility.

Out of scope:

- keeping the old startup screen
- keeping the old review screen
- keeping the old dashboard
- keeping the old shell widgets as long-term compatibility wrappers
- creating a separate Ralphception visual identity for the terminal shell
- preserving obsolete runtime frontend abstractions if they encode the old product shape

## Design Principles

### 1. Codex-first parity

Ralphception should look and behave like the Codex app as directly as possible.

Deviations are allowed only when Ralphception's product semantics cannot be represented cleanly otherwise.

### 2. Product semantics adapt into the shell

Missions, stages, reviews, recovery, bundles, audits, and child runs remain Ralphception concepts, but they must be rendered through Codex-style transcript cells, overlays, pickers, footer state, and thread navigation.

### 3. No parallel UI language

Ralphception should not invent its own dashboard grammar alongside Codex's shell grammar.

### 4. Port structure, not just pixels

This should be implemented as a Python/Textual port of Codex's TUI decomposition where practical, not as a visually similar custom shell.

### 5. Delete legacy surfaces aggressively

When the new shell covers a flow, the old UI for that flow should be removed rather than preserved.

## UX Parity Standard

The following areas should match Codex as closely as practical:

- shell frame
- session header card
- transcript layout and streaming behavior
- composer block
- footer and status line
- warning and tip rows
- overlays and pagers
- slash-command invocation and picker behavior
- thread and subagent navigation
- resume picker
- keyboard and focus defaults

The following areas may differ only in content semantics:

- product naming
- mission vocabulary
- review wording
- recovery wording
- Ralphception-specific command names

## Visual System

### Shell Frame

The screen should use the same high-level Codex layout:

- product label line
- framed session header card
- optional announcement rows
- dominant transcript viewport
- anchored composer block
- compact footer line

Raw dashboard status text is not an acceptable top-level shell primitive.

### Session Header Card

The header card should follow Codex's structure:

- product and version line
- model and mode line
- directory line
- optional compact contextual hint

Ralphception mission context may appear only if it fits cleanly into this card structure.

### Transcript

The transcript should be the primary user-facing history and control surface. It should render Codex-style conversation and tool activity, not log lines.

### Composer

The composer must be a real Codex-style input surface with placeholder text, editing behavior, slash-command entry, and submit semantics matching Codex defaults.

### Footer

The footer should be compact and Codex-like, carrying shell status, hints, and mode information without turning into a bottom dashboard.

### Overlays

Approvals, request-user-input prompts, pickers, and blocking actions should use Codex-style overlays or pager-like secondary surfaces rather than screen transitions.

## Global Interaction Model

### Focus

Default focus should land in the composer unless a blocking overlay is active.

### Composer-first interaction

User input, slash commands, and most shell actions should originate from the composer, following the Codex model.

### Transcript-native execution

Execution, streaming output, approvals, subagent events, and completion should appear inside the transcript or transcript-adjacent surfaces rather than separate modes.

### Overlay behavior

Blocking or secondary interactions should open Codex-style overlays and return the user to the same shell context when resolved.

### Keyboard model

Keyboard behavior should follow Codex unless Ralphception has no meaningful equivalent.

### Thread and subagent navigation

Ralphception child runs should use the Codex multi-agent and thread model directly.

## Full Lifecycle Requirements

### Launch and empty state

`uv run ralphception` should open into a Codex-style idle shell with header card, optional announcements, transcript area, focused composer, and footer.

### Intake and seed prompt

Mission startup should happen through the shell, using the composer or a Codex-style overlay. There should be no dedicated startup screen.

### Active execution

Active mission execution should feel like Codex in use: transcript-first, streaming cells, inline command activity, compact footer updates, and a persistent shell context.

### Command streaming

Commands should start, stream, and complete inside the transcript using Codex-like execution cells. There should be no dedicated terminal panel.

### Reviews and approvals

Review requests should appear as transcript-native events plus Codex-style approval overlays. There should be no dedicated review screen.

### Request-user-input flows

Structured input requests should use Codex-style interactive overlays or bottom-pane interactions and resolve back into transcript history.

### Subagents and child runs

Child runs should appear as Codex-style agents and threads with transcript lifecycle rows and switchable thread navigation.

### Recovery and errors

Recovery should use transcript-native error presentation plus overlays for blocking choices. There should be no separate recovery mode screen.

### Completion

Completion should resolve into transcript history and footer/header updates while leaving the shell ready for the next prompt.

### Resume and history

Resume and history selection should use a Codex-style picker model and restore into the same shell.

## Ralphception Domain Mapping

Ralphception-specific domain concepts should map into Codex UI primitives as follows:

- `mission` -> active shell session context
- `stage` -> transcript/header/footer metadata, not a screen
- `review request` -> transcript event plus approval overlay
- `request_user_input` -> interactive overlay flow
- `child run` -> Codex subagent or thread
- `recovery action` -> blocking overlay plus transcript resolution event
- `merge result` -> transcript-native result cell
- `audit result` -> transcript-native status or result cell
- `completion` -> transcript-native completion cell plus footer/header state update
- `resume` -> Codex-style picker flow

No Ralphception domain concept should force the reintroduction of startup, review, dashboard, or terminal screens.

## Port-First Architecture

### Composition root

Port the structure of Codex's `app.rs` into a new Ralphception shell composition root that owns layout, focus routing, redraw scheduling, runtime binding, and global keyboard handling.

### Transcript and session header layer

Port the structure of `chatwidget.rs` and `session_header.rs` into Python/Textual and make this the primary rendering surface for conversation, commands, status rows, and mission events.

### Bottom pane layer

Port the structure and behavior of:

- `chat_composer.rs`
- `footer.rs`
- `approval_overlay.rs`
- `request_user_input/*`
- `slash_commands.rs`
- relevant picker and popup modules

### Multi-agent navigation layer

Port the structure of `multi_agents.rs` and related navigation logic for Ralphception child runs and active thread switching.

### Resume/history layer

Port the structure and interaction pattern of `resume_picker.rs`.

### Runtime adapter layer

Build a Ralphception runtime adapter analogous to Codex's app-server adapter path. This layer should translate Ralphception runtime events and actions into the ported shell primitives.

### Reuse boundary

The following Ralphception systems can be reused if they fit the new shell:

- durable mission and runtime models
- event persistence
- approval persistence
- worktree coordination
- subagent orchestration
- merge and recovery machinery
- CLI launch plumbing

The following should be replaced:

- current placeholder shell composition
- current plain transcript widget
- current plain status widget
- current stub bottom pane
- legacy runtime frontend abstractions that encode old screen-oriented product modes

## Proposed Ralphception Module Shape

The Python implementation should mirror Codex's decomposition as directly as practical. A likely target shape is:

- `src/ralphception/tui/app.py`
- `src/ralphception/tui/chatwidget.py`
- `src/ralphception/tui/chatwidget/session_header.py`
- `src/ralphception/tui/chatwidget/transcript_cells.py`
- `src/ralphception/tui/bottom_pane/chat_composer.py`
- `src/ralphception/tui/bottom_pane/footer.py`
- `src/ralphception/tui/bottom_pane/approval_overlay.py`
- `src/ralphception/tui/bottom_pane/request_user_input/*`
- `src/ralphception/tui/bottom_pane/slash_commands.py`
- `src/ralphception/tui/multi_agents.py`
- `src/ralphception/tui/resume_picker.py`
- `src/ralphception/tui/runtime_adapter.py`

The current `src/ralphception/chat_shell/*` structure should be treated as transitional and replaceable.

## Execution Strategy

Implementation should proceed in strict parity loops against Codex.

For each execution chunk:

1. identify the Codex source modules and snapshots that define the target
2. write failing parity-oriented tests first
3. port the relevant Codex component structure into Python/Textual
4. adapt Ralphception semantics only where needed
5. run focused verification
6. compare the result against Codex reference behavior
7. fix mismatches immediately
8. delete superseded Ralphception shell code
9. commit
10. move to the next chunk

The master execution plan should be chunked in this order:

1. shell frame and layout skeleton
2. session header card
3. transcript rendering system
4. bottom composer
5. footer and status line
6. approval and request-user-input overlays
7. thread and subagent navigation
8. resume and history picker
9. runtime adapter
10. Ralphception-specific domain cells and overlays
11. CLI cutover cleanup
12. final parity and deletion pass

## Acceptance Criteria

### Visual parity

- `uv run ralphception` is immediately recognizable as the Codex app in structure
- header card, transcript, composer, footer, and overlays follow Codex's visible grammar
- raw dashboard-like text surfaces are gone

### Interaction parity

- default focus lands in the composer
- transcript behavior matches Codex's active and committed cell model
- slash commands, overlays, pickers, and footer semantics match Codex defaults
- child-run navigation follows the Codex multi-agent model

### Ralphception domain fit

- missions, stages, reviews, request-user-input flows, recovery, completion, and resume all fit inside the Codex shell without separate screens

### Architectural completion

- the Python implementation clearly mirrors the relevant Codex TUI decomposition
- legacy shell primitives and old screen-oriented frontend assumptions are removed

### Verification

- render and snapshot-style tests cover shell frame, header, transcript, composer, footer, overlays, and thread navigation
- integration tests cover the full Ralphception lifecycle inside the shell
- manual side-by-side comparison against `~/code/codex` shows the same UX grammar, with only Ralphception-specific content differences

## Real Done Bar

This rewrite is done only when a user can place Ralphception beside Codex and honestly say:

- "this is the Codex app design"
- "the differences are Ralphception's product semantics, not a different shell"

If that is not true, the rewrite is not complete.
