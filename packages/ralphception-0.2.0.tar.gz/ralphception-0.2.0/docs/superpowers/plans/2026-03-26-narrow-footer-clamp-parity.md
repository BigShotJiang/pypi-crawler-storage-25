# 2026-03-26 Narrow Footer Clamp Parity

## Goal

Fix the narrow-pane blocker footer so the instructional hint is not clipped into
the right-side context label.

## Reference

Codex's `bottom_pane/footer.rs` explicitly drops right-side context when the
left-side instructional hint cannot fit. That is better than truncating the
reply hint.

## Plan

1. Add a failing test for a 40-column blocker footer that proves the reply hint
   stays readable instead of being clipped into `100% context left`.
2. Change the footer renderer to prefer the full instructional hint over the
   right-side context when both cannot fit together.
3. Re-run focused footer tests and a fresh 40-column tmux capture.
4. Re-run the full suite and typecheck.
5. Merge to `main`, push, and clean up the feature worktree.
