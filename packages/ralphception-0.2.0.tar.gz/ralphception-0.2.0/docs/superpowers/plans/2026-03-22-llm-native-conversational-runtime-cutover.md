# LLM-Native Conversational Runtime Cutover Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Ralphception's callback-driven blocker/runtime contract with a fully conversational, Codex-native runtime that can drive a Ralph loop end to end through transcript messages, natural-language blocker resolution, session hydration, and durable thread-scoped prompt state.

**Architecture:** Keep the Codex-style TUI shell, but move the real control plane into a new runtime prompt pipeline. The runtime owns durable thread-scoped pending prompts, deferred inputs, hydration snapshots, and LLM-based prompt resolution; the shell becomes a projection of that durable state plus ordinary conversation. The cutover is hard: remove synchronous `prompt_startup` / `prompt_review` / `prompt_conflict` decision callbacks and route startup, resume, review, recovery, and workspace-conflict decisions through one conversational protocol.

**Tech Stack:** Python 3.13, Pydantic models, existing Codex session manager/runtime integration, Textual TUI, pytest, ty, tmux smoke checks

---

## Scope Decision

This should stay as one plan. The protocol, runtime persistence, prompt resolution, TUI projection, and Ralph-loop continuity are tightly coupled. Splitting them into separate plans would create mixed-mode intermediate states that preserve the callback contract the spec explicitly removes.

## File Structure / Responsibility Map

**Create:**
- `src/ralphception/runtime/prompt_state.py`
  Thread-scoped durable prompt models: `PendingPrompt`, `PromptResolution`, `DeferredInput`, `BlockedContinuationRef`, and hydration snapshot helpers.
- `src/ralphception/runtime/prompt_resolution.py`
  Constrained LLM-native resolver for pending prompts; maps natural-language replies into allowed actions or clarification requests.
- `tests/unit/test_prompt_state.py`
  Unit tests for prompt persistence, nullable pre-bootstrap ownership, deferred input ordering, and hydration snapshot shape.
- `tests/unit/test_prompt_resolution.py`
  Unit tests for constrained action resolution, ambiguity, destructive-action strictness, and clarification behavior.
- `tests/integration/test_conversational_runtime.py`
  Integration coverage for startup, resume, review, recovery, and Ralph-loop blocker resolution through one conversational path.

**Modify:**
- `src/ralphception/protocol/actions.py`
  Remove shell-owned structured blocker actions; add `UpdateBootstrapSourcesAction`.
- `src/ralphception/protocol/events.py`
  Add `SessionHydratedEvent`; make prompt ownership nullable for pre-bootstrap root-thread prompts.
- `src/ralphception/protocol/__init__.py`
  Export only the conversational protocol surface.
- `src/ralphception/runtime/frontends.py`
  Remove synchronous decision callbacks; keep emit/status contract only if still needed for transitional runtime plumbing.
- `src/ralphception/runtime/interactive_session.py`
  Persist active-thread identity, prompt state, deferred inputs, hydration data, and resumable launch state.
- `src/ralphception/runtime/bootstrap.py`
  Bind pre-bootstrap root-thread state to the first ordinary root-thread message and persisted source-repo context.
- `src/ralphception/runtime/reviews.py`
  Expose prompt-instance-specific allowed actions and explicit destructive-action semantics (`replace`, `restart`, `resume`, `approve`).
- `src/ralphception/runtime/supervisor.py`
  Replace direct prompt callbacks with pending-prompt creation, prompt-resolution application, and blocked-continuation resume.
- `src/ralphception/headless.py`
  Emit hydration/prompt events instead of calling frontend decision methods.
- `src/ralphception/runtime/terminal.py`
  Project the new conversational runtime in non-TUI mode without reviving callback decisions.
- `src/ralphception/actor_runtime/orchestrator.py`
  Route startup/bootstrap and blocked decisions through the new conversational runtime path.
- `src/ralphception/tui/runtime_adapter.py`
  Consume `SessionHydratedEvent`, `PromptRequestedEvent`, `PromptResolvedEvent`, and ordinary transcript events; remove queue-based callback responses.
- `src/ralphception/tui/app.py`
  Keep the composer always active, route all user turns through `SendUserMessageAction`, and preserve active-thread prompt targeting.
- `src/ralphception/tui/render_state.py`
  Add waiting-on-prompt, deferred-input, and hydrated-thread/session fields needed by the shell.
- `src/ralphception/tui/chatwidget/transcript_store.py`
  Persist runtime-authored blocker/system messages and assistant-authored clarification turns in one durable transcript model.
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
  Show waiting-on-user status and optional `/source` bootstrap affordance without reintroducing callback-style blockers.
- `src/ralphception/tui/bottom_pane/slash_commands.py`
  Keep `/source`; remove `/resume` and any slash surface that revives structured blocker actions.
- `tests/unit/test_protocol_models.py`
  Cover nullable prompt ownership, hydration events, and bootstrap source transport.
- `tests/unit/test_interactive_session.py`
  Cover persisted prompt/deferred-input/hydration state.
- `tests/unit/test_headless_contracts.py`
  Cover the post-cutover runtime/frontend contract shape.
- `tests/unit/test_runtime_supervisor.py`
  Cover prompt creation, resolution, and blocked continuation resumption.
- `tests/unit/test_tui_runtime_adapter.py`
  Cover TUI consumption of hydration and conversational prompt events.
- `tests/integration/test_headless_supervisor.py`
  Cover conversational review/recovery/resume flows with the real runtime.
- `tests/integration/test_terminal_frontend.py`
  Cover non-TUI conversational behavior and ensure no structured callback prompts remain.
- `tests/integration/test_startup_flow.py`
  Cover first-message bootstrap and `/source` transport before the first orchestration turn.
- `tests/integration/test_tui_runtime_app.py`
  Cover hydrated launch, pending prompts in transcript, natural-language prompt resolution, and uninterrupted draft behavior.
- `tests/integration/test_tui_transcript.py`
  Cover runtime-authored blocker cells, assistant clarifications, and settled continuation cells.
- `tests/integration/test_actor_runtime_resume.py`
  Cover interrupted-session hydration and conversational resume.
- `tests/integration/test_actor_runtime_parallel.py`
  Cover thread-local prompts and parent/subagent continuity under parallel work.
- `tests/e2e/test_core_runtime.py`
  Cover real conversational startup, Ralph-loop orchestration, blocker resolution, and reopen/resume.
- `README.md`
  Update user-facing runtime contract if CLI/help text still describes explicit review/resume modes.

**Delete or collapse after cutover is green:**
- `ReviewDecisionAction`, `ResolvePromptAction`, and `ApplyRecoveryAction` from `src/ralphception/protocol/actions.py`
- callback decision methods from `src/ralphception/runtime/frontends.py`
- queue-based decision plumbing in `src/ralphception/tui/runtime_adapter.py`
- any tests asserting `prompt_startup`, `prompt_review`, or `prompt_conflict` behavior directly

## Relevant Reference Points

- Spec: [2026-03-22-llm-native-conversational-runtime-design.md](/Users/shayne/code/ralphception/docs/superpowers/specs/2026-03-22-llm-native-conversational-runtime-design.md)
- Existing callback contract: [frontends.py](/Users/shayne/code/ralphception/src/ralphception/runtime/frontends.py)
- Existing headless blocking behavior: [headless.py](/Users/shayne/code/ralphception/src/ralphception/headless.py)
- Existing supervisor review/conflict control: [supervisor.py](/Users/shayne/code/ralphception/src/ralphception/runtime/supervisor.py)
- Existing protocol seam: [actions.py](/Users/shayne/code/ralphception/src/ralphception/protocol/actions.py), [events.py](/Users/shayne/code/ralphception/src/ralphception/protocol/events.py)
- Existing TUI reducer surface: [runtime_adapter.py](/Users/shayne/code/ralphception/src/ralphception/tui/runtime_adapter.py)

### Task 1: Lock The Conversational Protocol Surface

**Files:**
- Modify: `src/ralphception/protocol/actions.py`
- Modify: `src/ralphception/protocol/events.py`
- Modify: `src/ralphception/protocol/__init__.py`
- Modify: `tests/unit/test_protocol_models.py`
- Modify: `tests/unit/test_headless_contracts.py`

- [ ] **Step 1: Write the failing protocol tests**

```python
def test_prompt_events_allow_null_owner_run_id_for_prebootstrap_root_thread() -> None:
    event = PromptRequestedEvent(
        kind="prompt_requested",
        thread_id="thread-root",
        owner_run_id=None,
        prompt_id="prompt-resume",
        prompt_kind="resume_session",
        title="Resume session",
        question="Resume or start fresh?",
        allowed_actions=["resume", "start_fresh"],
        context_summary="workspace has resumable state",
    )
    assert event.owner_run_id is None


def test_session_hydrated_event_carries_pending_prompts_and_bootstrap_sources() -> None:
    event = SessionHydratedEvent(
        kind="session_hydrated",
        root_thread_id="thread-root",
        active_thread_id="thread-root",
        threads=[],
        transcript_snapshot=[],
        pending_prompts=[],
        deferred_inputs=[],
        status_context={"busy": False},
        launch_classification="fresh",
        bootstrap_source_repos=["/tmp/source-repo"],
    )
    assert event.bootstrap_source_repos == ["/tmp/source-repo"]
```

- [ ] **Step 2: Run the focused protocol tests and verify failure**

Run: `uv run pytest tests/unit/test_protocol_models.py tests/unit/test_headless_contracts.py -q`

Expected: FAIL with missing `SessionHydratedEvent`, missing `UpdateBootstrapSourcesAction`, or non-nullable prompt ownership assumptions.

- [ ] **Step 3: Implement the minimal protocol changes**

```python
class UpdateBootstrapSourcesAction(_ProtocolModel):
    kind: Literal["update_bootstrap_sources"]
    thread_id: str
    repo_paths: list[str]


class SessionHydratedEvent(_ProtocolModel):
    kind: Literal["session_hydrated"]
    root_thread_id: str
    active_thread_id: str
    threads: list[ThreadSummary]
    transcript_snapshot: list[TranscriptCommittedEvent]
    active_transcript_tail: ActiveCell | None = None
    pending_prompts: list[PromptRequestedEvent]
    deferred_inputs: list[DeferredInputSnapshot]
    status_context: dict[str, object]
    launch_classification: Literal["fresh", "resumable", "broken_resume"]
    bootstrap_source_repos: list[str] = []
```

- [ ] **Step 4: Remove obsolete shell-owned decision actions from the protocol exports**

Run the edit in `src/ralphception/protocol/actions.py` and `src/ralphception/protocol/__init__.py`, then grep for old exports:

Run: `rg -n "ReviewDecisionAction|ResolvePromptAction|ApplyRecoveryAction" src/ralphception/protocol`

Expected: no live protocol exports remain after the cutover branch of this task.

- [ ] **Step 5: Re-run the focused protocol tests**

Run: `uv run pytest tests/unit/test_protocol_models.py tests/unit/test_headless_contracts.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/protocol/actions.py src/ralphception/protocol/events.py src/ralphception/protocol/__init__.py tests/unit/test_protocol_models.py tests/unit/test_headless_contracts.py
git commit -m "refactor: define conversational protocol surface"
```

### Task 2: Add Durable Prompt State, Deferred Input, And Hydration Snapshots

**Files:**
- Create: `src/ralphception/runtime/prompt_state.py`
- Modify: `src/ralphception/runtime/interactive_session.py`
- Modify: `src/ralphception/runtime/bootstrap.py`
- Create: `tests/unit/test_prompt_state.py`
- Modify: `tests/unit/test_interactive_session.py`
- Modify: `tests/unit/test_storage_bootstrap.py`

- [ ] **Step 1: Write failing storage tests**

```python
def test_interactive_session_marker_persists_thread_prompt_and_deferred_input(tmp_path: Path) -> None:
    state = InteractiveSessionState(
        root_thread_id="thread-root",
        active_thread_id="thread-worker-1",
        pending_prompts=[
            PendingPrompt(
                thread_id="thread-worker-1",
                owner_run_id="run-child-1",
                prompt_id="prompt-review-1",
                prompt_kind="review_decision",
                allowed_actions=("approve",),
            )
        ],
        deferred_inputs=[
            DeferredInput(thread_id="thread-worker-1", text="continue after approval")
        ],
    )
    write_interactive_session_state(tmp_path, state)
    reloaded = load_interactive_session_state(tmp_path)
    assert reloaded == state
```

- [ ] **Step 2: Run the new storage tests and verify failure**

Run: `uv run pytest tests/unit/test_prompt_state.py tests/unit/test_interactive_session.py tests/unit/test_storage_bootstrap.py -q`

Expected: FAIL because `PendingPrompt`, `DeferredInput`, and hydration persistence do not exist yet.

- [ ] **Step 3: Implement durable prompt-state models**

```python
class PendingPrompt(DurableModel):
    thread_id: str
    owner_run_id: str | None
    prompt_id: str
    prompt_kind: str
    title: str
    question: str
    allowed_actions: tuple[str, ...]
    context: dict[str, object]
    status: Literal["pending", "resolved", "cancelled"] = "pending"
    blocked_continuation: BlockedContinuationRef


class DeferredInput(DurableModel):
    thread_id: str
    text: str
    created_at: datetime


class PromptResolution(DurableModel):
    thread_id: str
    owner_run_id: str | None
    prompt_id: str
    action: str
    raw_user_reply: str
    confidence: float
    clarifying_question: str | None = None
```

- [ ] **Step 4: Persist hydration state and prompt resolutions in the interactive-session marker**

Add `root_thread_id`, `active_thread_id`, `pending_prompts`, `prompt_resolutions`, `deferred_inputs`, and `bootstrap_source_repos` to the durable workspace marker and tests.

- [ ] **Step 5: Bind first-message bootstrap to the reserved root thread**

Implement the minimal `bootstrap.py` changes so the first ordinary root-thread message creates the startup record and binds the reserved root thread to the new root run without inventing a second thread identifier.

- [ ] **Step 6: Re-run the storage tests**

Run: `uv run pytest tests/unit/test_prompt_state.py tests/unit/test_interactive_session.py tests/unit/test_storage_bootstrap.py -q`

Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/ralphception/runtime/prompt_state.py src/ralphception/runtime/interactive_session.py src/ralphception/runtime/bootstrap.py tests/unit/test_prompt_state.py tests/unit/test_interactive_session.py tests/unit/test_storage_bootstrap.py
git commit -m "feat: persist conversational prompt state"
```

### Task 3: Build The Constrained LLM Prompt Resolver

**Files:**
- Create: `src/ralphception/runtime/prompt_resolution.py`
- Modify: `src/ralphception/runtime/reviews.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Create: `tests/unit/test_prompt_resolution.py`
- Modify: `tests/unit/test_runtime_supervisor.py`

- [ ] **Step 1: Write the failing resolver tests**

```python
def test_prompt_resolver_maps_natural_language_reply_to_allowed_action() -> None:
    prompt = PendingPrompt(
        thread_id="thread-root",
        owner_run_id=None,
        prompt_id="prompt-resume",
        prompt_kind="resume_session",
        title="Resume",
        question="Resume or start fresh?",
        allowed_actions=("resume", "start_fresh"),
        blocked_continuation=BlockedContinuationRef(kind="launch_gate"),
    )
    result = resolve_prompt_reply(prompt, user_text="continue where we left off")
    assert result.action == "resume"


def test_prompt_resolver_returns_clarification_for_ambiguous_reply() -> None:
    prompt = build_recovery_prompt(actions=("retry", "replace"))
    result = resolve_prompt_reply(prompt, user_text="do it")
    assert result.kind == "clarify"
```

- [ ] **Step 2: Run the resolver tests and verify failure**

Run: `uv run pytest tests/unit/test_prompt_resolution.py tests/unit/test_runtime_supervisor.py -q`

Expected: FAIL with missing resolver or unresolved action semantics.

- [ ] **Step 3: Implement the constrained resolver**

```python
class PromptResolutionResult(DurableModel):
    kind: Literal["resolved", "clarify"]
    action: str | None = None
    clarifying_question: str | None = None
    confidence: float


def resolve_prompt_reply(prompt: PendingPrompt, user_text: str, *, session_manager: CodexSessionManager | None) -> PromptResolutionResult:
    # Ask Codex to choose from prompt.allowed_actions only.
    ...
```

- [ ] **Step 4: Encode destructive-action strictness and prompt-instance-specific review actions**

Ensure the resolver and `runtime/reviews.py` agree on the actual supported action sets:
- `approve` only for ordinary review prompts in v1
- `replace` for blocked/failed recovery
- `abort` only where the prompt kind explicitly allows it

- [ ] **Step 5: Persist prompt resolutions before any blocked continuation resumes**

Add a focused runtime-supervisor test:

```python
def test_prompt_resolution_is_persisted_before_continuation_resumes(repo_root: Path) -> None:
    supervisor = RuntimeSupervisor(repo_root=repo_root)
    supervisor.resolve_pending_prompt(thread_id="thread-root", user_text="resume it")
    state = load_interactive_session_state(repo_root)
    assert state.prompt_resolutions[-1].raw_user_reply == "resume it"
    assert state.prompt_resolutions[-1].action == "resume"
```

- [ ] **Step 6: Re-run the resolver tests**

Run: `uv run pytest tests/unit/test_prompt_resolution.py tests/unit/test_runtime_supervisor.py -q`

Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/ralphception/runtime/prompt_resolution.py src/ralphception/runtime/reviews.py src/ralphception/runtime/supervisor.py tests/unit/test_prompt_resolution.py tests/unit/test_runtime_supervisor.py
git commit -m "feat: add llm-native prompt resolver"
```

### Task 4: Remove Callback Decisions From Headless, Supervisor, Terminal, And Orchestrator

**Files:**
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `tests/integration/test_headless_supervisor.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/integration/test_actor_runtime_resume.py`
- Modify: `tests/unit/test_headless_contracts.py`

- [ ] **Step 1: Write failing integration tests for conversational blocker flow**

```python
def test_headless_runtime_blocks_on_pending_prompt_without_frontend_callback(repo_root: Path) -> None:
    runtime = HeadlessMission(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt=None,
        source_repos=(),
        approve_all=False,
        approver="tui",
        session_manager_factory=build_fake_headless_session_manager,
    )
    result = runtime.run(frontend=CollectingFrontend())
    assert result.mode == "running"
    assert any(event.kind == "prompt_requested" for event in frontend.events)
```

- [ ] **Step 2: Run the focused runtime tests and verify failure**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_terminal_frontend.py tests/integration/test_actor_runtime_resume.py tests/unit/test_headless_contracts.py -q`

Expected: FAIL because the runtime still calls `prompt_startup`, `prompt_review`, or `prompt_conflict`.

- [ ] **Step 3: Remove the synchronous frontend methods from `RuntimeFrontend`**

Delete:

```python
def prompt_startup(self, prompt: StartupPrompt) -> StartupDecision: ...
def prompt_review(self, prompt: ReviewPrompt) -> ReviewDecision: ...
def prompt_conflict(self, prompt: MissionConflictPrompt) -> MissionConflictDecision: ...
```

Replace them with prompt-state emission and a runtime-owned “blocked until prompt resolution” path.

- [ ] **Step 4: Convert startup, review, recovery, and conflict paths to `PendingPrompt`**

Implement the cutover in `headless.py`, `supervisor.py`, `terminal.py`, and `actor_runtime/orchestrator.py`:
- startup: first ordinary root-thread message bootstraps the run
- resume gate / broken resume: launch-time root-thread prompt
- review: review prompt plus runtime-authored transcript cell
- recovery/conflict: prompt instances with explicit allowed actions

- [ ] **Step 5: Lock the destructive-action semantics with integration tests**

Add targeted cases covering the spec semantics:
- `start_fresh` clears the superseded interactive-session marker, pending prompts, deferred inputs, bootstrap state, and superseded-session transcript history before creating a new fresh root-thread session context
- `override` supersedes the live session, clears pending prompts and deferred inputs owned by the superseded live session, leaves old durable artifacts only as historical records, and starts the replacement session afterward
- `restart` keeps transcript history but clears prompt/deferred-input state for the blocked continuation
- `replace` rebinds execution to a replacement run inside the same session and clears prompts/deferred input owned by the replaced blocked continuation
- `abort` persists a final aborted state and makes the continuation non-resumable

- [ ] **Step 6: Re-run the focused runtime tests**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_terminal_frontend.py tests/integration/test_actor_runtime_resume.py tests/unit/test_headless_contracts.py -q`

Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/ralphception/runtime/frontends.py src/ralphception/headless.py src/ralphception/runtime/supervisor.py src/ralphception/runtime/terminal.py src/ralphception/actor_runtime/orchestrator.py tests/integration/test_headless_supervisor.py tests/integration/test_terminal_frontend.py tests/integration/test_actor_runtime_resume.py tests/unit/test_headless_contracts.py
git commit -m "refactor: remove callback blocker decisions"
```

### Task 5: Hydrate And Render The Conversational Runtime In The TUI

**Files:**
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_store.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/bottom_pane/slash_commands.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/integration/test_tui_transcript.py`
- Modify: `tests/integration/test_tui_bottom_pane.py`

- [ ] **Step 1: Write failing TUI tests for hydrated launch and conversational prompts**

```python
def test_tui_hydrates_pending_prompt_before_first_user_turn(repo_root: Path) -> None:
    app = RalphceptionTuiApp.from_runtime(repo_root)
    rendered = app.export_text()
    assert "waiting on your reply" in rendered
    assert "resume the previous session" in rendered
    assert "Resume last session" not in rendered


def test_tui_sends_same_composer_turn_as_prompt_reply_when_thread_is_blocked(repo_root: Path) -> None:
    app = RalphceptionTuiApp.from_runtime(repo_root)
    app.runtime_adapter.submit_message(text="resume it")
    assert "Resuming the previous session." in app.export_text()
```

- [ ] **Step 2: Run the TUI tests and verify failure**

Run: `uv run pytest tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py -q`

Expected: FAIL because the adapter still uses queue-based callback responses and overlay-first launch/review logic.

- [ ] **Step 3: Implement hydration-first shell state**

On runtime attach:
- consume `SessionHydratedEvent`
- populate active thread, transcript backlog, pending prompts, bootstrap source repos, and waiting status
- block ordinary input until hydration is complete

- [ ] **Step 4: Remove callback response queues and overlay-first blocker handling**

Delete the `Queue[ReviewDecision]` / `Queue[MissionConflictDecision]` / startup-response plumbing from `runtime_adapter.py` and route all user turns through `SendUserMessageAction(thread_id, text)`.

- [ ] **Step 5: Preserve conversational transcript authorship**

Ensure:
- blocker explanations and settled action acknowledgements are runtime-authored system messages
- clarifying follow-ups are assistant messages from the resolver
- deferred same-thread input is acknowledged without being lost

- [ ] **Step 6: Keep `/source` as the only pre-bootstrap structured affordance**

Implement `/source` through `UpdateBootstrapSourcesAction(thread_id, repo_paths)` and show hydrated source-repo context in the shell without inventing a startup form.

- [ ] **Step 7: Re-run the TUI tests**

Run: `uv run pytest tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py -q`

Expected: PASS

- [ ] **Step 8: Commit**

```bash
git add src/ralphception/tui/runtime_adapter.py src/ralphception/tui/app.py src/ralphception/tui/render_state.py src/ralphception/tui/chatwidget/transcript_store.py src/ralphception/tui/chatwidget/transcript_view.py src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/bottom_pane/slash_commands.py tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py
git commit -m "feat: hydrate conversational runtime in tui"
```

### Task 6: Keep Ralph Loops And Subagents Continuous Through Conversation

**Files:**
- Modify: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `tests/integration/test_actor_runtime_parallel.py`
- Modify: `tests/integration/test_actor_runtime_resume.py`
- Create: `tests/integration/test_conversational_runtime.py`
- Modify: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Write failing Ralph-loop continuity tests**

```python
def test_parallel_child_prompt_stays_owned_by_child_thread(repo_root: Path) -> None:
    runtime = build_parallel_runtime(repo_root)
    runtime.start_parallel_children()
    runtime.inject_pending_prompt(thread_id="thread-worker-1", kind="recovery_decision")
    shell = runtime.attach_shell()
    shell.switch_thread("thread-worker-1")
    shell.submit("replace it")
    assert runtime.owner_thread_last_resolution("thread-worker-1") == "replace"


def test_parent_thread_receives_summary_without_stealing_child_prompt(repo_root: Path) -> None:
    runtime = build_parallel_runtime(repo_root)
    runtime.start_parallel_children()
    runtime.inject_pending_prompt(thread_id="thread-worker-1", kind="recovery_decision")
    parent_transcript = runtime.parent_thread_snapshot()
    assert "Worker 1 is waiting for a recovery decision" in parent_transcript
    assert runtime.pending_prompt_thread_id() == "thread-worker-1"
```

- [ ] **Step 2: Run the Ralph-loop tests and verify failure**

Run: `uv run pytest tests/integration/test_actor_runtime_parallel.py tests/integration/test_actor_runtime_resume.py tests/integration/test_conversational_runtime.py tests/integration/test_tui_runtime_app.py -q`

Expected: FAIL because prompt ownership, parent summaries, or deferred execution are not yet thread-local end to end.

- [ ] **Step 3: Implement thread-local prompt ownership and parent summaries**

Ensure:
- child-thread prompts resolve only in their own thread
- parent thread may receive summary/status updates, but never owns the child prompt implicitly
- resumed/deferred input executes in FIFO order after the blocked continuation yields

- [ ] **Step 4: Add a navigation-intent test while a prompt is pending**

```python
def test_switching_threads_does_not_resolve_or_hijack_pending_prompt(repo_root: Path) -> None:
    shell = launch_hydrated_shell(repo_root)
    shell.switch_thread("thread-worker-2")
    assert shell.active_thread_id == "thread-worker-2"
    assert shell.runtime.pending_prompt("thread-worker-1").status == "pending"
```

- [ ] **Step 5: Re-run the Ralph-loop tests**

Run: `uv run pytest tests/integration/test_actor_runtime_parallel.py tests/integration/test_actor_runtime_resume.py tests/integration/test_conversational_runtime.py tests/integration/test_tui_runtime_app.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/actor_runtime/orchestrator.py src/ralphception/runtime/supervisor.py src/ralphception/headless.py src/ralphception/tui/runtime_adapter.py tests/integration/test_actor_runtime_parallel.py tests/integration/test_actor_runtime_resume.py tests/integration/test_conversational_runtime.py tests/integration/test_tui_runtime_app.py
git commit -m "feat: keep ralph loops conversational across threads"
```

### Task 7: Remove The Old Contract Completely And Update Docs

**Files:**
- Modify: `src/ralphception/runtime/__init__.py`
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/protocol/__init__.py`
- Modify: `README.md`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Write a failure test that greps for the dead callback contract**

```python
def test_runtime_frontend_no_longer_exposes_prompt_callbacks() -> None:
    source = Path("src/ralphception/runtime/frontends.py").read_text()
    assert "prompt_startup" not in source
    assert "prompt_review" not in source
    assert "prompt_conflict" not in source
```

- [ ] **Step 2: Run the cleanup tests and verify failure**

Run: `uv run pytest tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py -q`

Expected: FAIL because docs/help/tests still mention callback-style or explicit review/resume modes.

- [ ] **Step 3: Remove dead contract remnants and update docs**

Clean up:
- stale imports/exports
- stale CLI/help text
- stale README sections describing resume/review as separate UI modes

- [ ] **Step 4: Re-run the cleanup tests**

Run: `uv run pytest tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/__init__.py src/ralphception/runtime/frontends.py src/ralphception/runtime/terminal.py src/ralphception/protocol/__init__.py README.md tests/integration/test_terminal_frontend.py tests/unit/test_cli_bootstrap.py
git commit -m "refactor: remove legacy blocker contract remnants"
```

### Task 8: Prove The End-To-End Ralph Loop Works

**Files:**
- Modify: `tests/e2e/test_core_runtime.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Add the failing end-to-end scenario**

```python
def test_e2e_conversational_ralph_loop_resume_review_and_continue(repo_root: Path) -> None:
    shell = launch_tui(repo_root)
    shell.submit("Investigate the bug and search broadly with Ralph.")
    shell.expect_text("Ralphception is investigating")
    shell.expect_text("waiting on your reply")
    shell.submit("approve it")
    shell.expect_text("Approved")
    shell.expect_text("Ralphception is continuing")
```

- [ ] **Step 2: Run the E2E slice and verify failure**

Run: `uv run pytest tests/e2e/test_core_runtime.py tests/integration/test_startup_flow.py tests/integration/test_tui_runtime_app.py -q`

Expected: FAIL because the full conversational loop is not yet proven from startup through blocker resolution and continuation.

- [ ] **Step 3: Make the minimal implementation fixes needed to pass the full loop**

Do not add new architecture here. Only close whatever gaps remain from Tasks 1-7 so the full conversational path works:
- fresh workspace first message
- Ralph-loop progress in transcript
- natural-language blocker resolution
- resumed continuation
- durable reopen/hydrate path

- [ ] **Step 4: Run the end-to-end slice**

Run: `uv run pytest tests/e2e/test_core_runtime.py tests/integration/test_startup_flow.py tests/integration/test_tui_runtime_app.py -q`

Expected: PASS

- [ ] **Step 5: Run the full project verification**

Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

Run: `uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 6: Run manual tmux smoke checks against the real TUI**

Run:

```bash
tmux new-session -d -s ralph_loop_smoke 'cd /path/to/fixture && uv run ralphception'
```

Verify manually:
- fresh workspace opens hydrated shell, not a startup form
- first message starts the run and transcript shows Ralph-loop progress
- blocked review/recovery is explained in transcript and footer says Ralphception is waiting on the user
- replying in natural language (for example `approve it`, `replace it`, `resume it`) continues the loop
- reopening the app hydrates the interrupted session and keeps the conversation intact

- [ ] **Step 7: Commit**

```bash
git add tests/e2e/test_core_runtime.py tests/integration/test_startup_flow.py tests/integration/test_tui_runtime_app.py
git commit -m "test: prove conversational ralph loop end to end"
```

## Final Acceptance Checklist

- [ ] No synchronous blocker callbacks remain in the runtime/frontend contract.
- [ ] A fresh workspace bootstraps from the first ordinary root-thread message.
- [ ] `/source` updates bootstrap source repositories through the explicit pre-bootstrap action.
- [ ] Reopening the app hydrates thread state, transcript backlog, pending prompts, and waiting status before accepting input.
- [ ] Runtime blockers are explained in transcript first and resolved through the normal composer.
- [ ] Ambiguous blocker replies trigger assistant clarifications instead of dead-end UI states.
- [ ] Thread-local blocked prompts stay owned by the correct Ralph-loop/subagent thread.
- [ ] Deferred same-thread input survives the blocker and runs after the blocked continuation yields.
- [ ] A real Ralph-loop path works from startup through blocker resolution and resume in the shipped TUI.
