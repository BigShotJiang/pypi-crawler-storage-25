# Launch Resume Gate Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace manual resume UX with a launch-time “resume last session or start fresh” gate that restores the last interactive session in place, removes public/manual resume affordances, and keeps first-run bootstrap independent.

**Architecture:** Add a single workspace-level interactive-session marker and a deterministic launch-state resolver. Use that resolver before the current startup/review/dashboard branching, expose the choice through the Codex-style shell overlay system, and delete `/resume`, the resume picker, and public CLI/manual resume paths.

**Tech Stack:** Python 3.12+, Textual, Typer, pytest, existing RuntimeSupervisor/RecoveryService/CodexSessionManager, Ralphception TUI render state

---

## Chunk 1: Freeze Launch-Resume Behavior With Tests

### Task 1: Add failing tests for launch-time resume classification and public surface removal

**Files:**
- Create: `tests/unit/test_interactive_session.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/integration/test_tui_bottom_pane.py`
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/integration/test_recovery.py`

- [ ] **Step 1: Write a failing unit test for launch-state classification**

Add a test matrix for:
- fresh workspace
- resumable marker present
- broken marker present
- legacy root run with resumable `codex_session_ref`
- legacy root run with missing/stale `codex_session_ref`
- conflicting legacy files resolving to broken-resume
- broken-resume classification leaves `interactive-session.json` untouched until `Start fresh`

- [ ] **Step 2: Run the new unit test to verify it fails**

Run:

```bash
uv run pytest tests/unit/test_interactive_session.py -q
```

- [ ] **Step 3: Write failing TUI tests for the new launch prompt**

Add integration coverage proving:
- launch prompt offers `Resume last session` and `Start fresh`
- choosing resume does not open a picker
- choosing fresh clears the resumable marker
- the default header does not show `mission:`

- [ ] **Step 4: Write failing surface-removal tests**

Add tests proving:
- `/resume` is absent from slash-command/help surfaces
- the CLI no longer exposes `resume`
- terminal/help text no longer suggests `--resume`

- [ ] **Step 5: Run the focused red suite**

Run:

```bash
uv run pytest tests/unit/test_interactive_session.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_bottom_pane.py tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py -q
```

## Chunk 2: Add Interactive Session Persistence And Launch Classification

### Task 2: Implement the workspace-level interactive-session marker and deterministic resolver

**Files:**
- Create: `src/ralphception/runtime/interactive_session.py`
- Modify: `src/ralphception/app.py`
- Test: `tests/unit/test_interactive_session.py`

- [ ] **Step 1: Create the marker model and path helpers**

Implement a focused module for:
- `.ralphception/interactive-session.json`
- typed marker model
- load/save/clear helpers

- [ ] **Step 2: Implement launch-state classification**

Implement deterministic resolution for:
- fresh
- resumable
- broken-resume
- legacy fallback from `startup.json`, `run.json`, and `headless-state.json`

- [ ] **Step 3: Update the app bootstrap layer to use the new resolver**

Rework `resolve_runtime_view()` so it can return explicit fresh/resumable/broken-resume launch modes instead of only startup/review/dashboard.

- [ ] **Step 4: Run focused tests to verify green**

Run:

```bash
uv run pytest tests/unit/test_interactive_session.py tests/unit/test_cli_bootstrap.py -q
```

- [ ] **Step 5: Commit the persistence/resolver slice**

```bash
git add src/ralphception/runtime/interactive_session.py src/ralphception/app.py tests/unit/test_interactive_session.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: add launch-time interactive session resolver"
```

## Chunk 3: Rework The TUI Launch Path Around Resume-Or-Fresh

### Task 3: Replace resume picker UX with a launch overlay and restore-in-place behavior

**Files:**
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/chatwidget/session_header.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/integration/test_tui_shell_frame.py`

- [ ] **Step 1: Add a dedicated launch overlay state for resumable and broken-resume startup**

Model:
- resumable prompt: `Resume last session` / `Start fresh`
- broken-resume prompt: `Start fresh` / `Cancel`

- [ ] **Step 2: Wire launch actions through the runtime adapter**

Implement:
- resume last session
- clear marker and start fresh
- broken-resume cancel behavior

- [ ] **Step 3: Remove mission-first shell chrome**

Stop surfacing `mission:` in the default session header/state.

- [ ] **Step 4: Restore the last active thread context deterministically**

Use:
- `active_run_id` from the marker
- root run fallback when missing
- broken-resume classification when the referenced run cannot be resumed

- [ ] **Step 5: Run the focused TUI suite**

Run:

```bash
uv run pytest tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py tests/unit/test_tui_runtime_adapter.py -q
```

- [ ] **Step 6: Commit the TUI launch cutover**

```bash
git add src/ralphception/tui/runtime_adapter.py src/ralphception/tui/app.py src/ralphception/tui/render_state.py src/ralphception/tui/chatwidget/session_header.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py tests/unit/test_tui_runtime_adapter.py
git commit -m "feat: add launch-time resume gate to the shell"
```

## Chunk 4: Persist Interactive Session State During Live Use

### Task 4: Keep the marker in sync with the live shell and active thread

**Files:**
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/codex/session_manager.py`
- Modify: `tests/integration/test_tui_multi_agents.py`
- Modify: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Write marker updates on interactive state transitions**

Persist:
- root run id
- active run id
- blocking overlay kind
- resumable flag

- [ ] **Step 2: Clear the marker on clean completion and explicit fresh start**

Make completion/non-resumable states deterministic.

- [ ] **Step 3: Update active thread persistence on agent switches**

When the user changes thread/subagent context, keep `active_run_id` current.

- [ ] **Step 4: Run focused persistence tests**

Run:

```bash
uv run pytest tests/integration/test_tui_multi_agents.py tests/integration/test_tui_runtime_app.py tests/integration/test_session_manager.py -q
```

- [ ] **Step 5: Commit marker-sync behavior**

```bash
git add src/ralphception/tui/runtime_adapter.py src/ralphception/codex/session_manager.py tests/integration/test_tui_multi_agents.py tests/integration/test_tui_runtime_app.py tests/integration/test_session_manager.py
git commit -m "feat: persist live interactive session state"
```

## Chunk 5: Delete Manual Resume Surfaces

### Task 5: Remove resume picker, slash-command, and public CLI/manual resume affordances

**Files:**
- Delete: `src/ralphception/tui/resume_picker.py`
- Modify: `src/ralphception/tui/bottom_pane/slash_commands.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `tests/integration/test_tui_bottom_pane.py`
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/integration/test_tui_resume_picker.py` or delete it if fully obsolete

- [ ] **Step 1: Remove `/resume` from slash-command matching and help text**

- [ ] **Step 2: Delete the resume picker widget/renderer and its app/runtime hooks**

- [ ] **Step 3: Remove the public `ralphception resume` command**

- [ ] **Step 4: Remove user-facing `resume` / `--resume` copy from terminal/help paths**

- [ ] **Step 4a: Remove stale resume guidance from shared frontend text**

- [ ] **Step 5: Run focused surface-removal tests**

Run:

```bash
uv run pytest tests/integration/test_tui_bottom_pane.py tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py -q
```

- [ ] **Step 6: Commit the surface deletion**

```bash
git add src/ralphception/tui/bottom_pane/slash_commands.py src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/app.py src/ralphception/cli.py src/ralphception/app.py src/ralphception/runtime/terminal.py src/ralphception/runtime/frontends.py tests/integration/test_tui_bottom_pane.py tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py tests/integration/test_recovery.py
git add -u src/ralphception/tui
git commit -m "refactor: remove manual resume surfaces"
```

## Chunk 6: End-To-End Verification And Integration

### Task 6: Verify real launch behavior and land the cutover

**Files:**
- Modify only files from prior chunks if needed

- [ ] **Step 1: Run the full suite**

```bash
uv run pytest tests/unit tests/integration tests/e2e -q
```

- [ ] **Step 2: Run type checks**

```bash
uv run ty check src tests
```

- [ ] **Step 3: Run diff hygiene**

```bash
git diff --check
```

- [ ] **Step 4: Smoke test the real shell**

Run `uv run ralphception` against:
- a fresh workspace
- a workspace with a resumable interrupted session
- a workspace with intentionally broken legacy resume state

Verify:
- fresh workspace launches cleanly
- interrupted workspace prompts once and resumes in place
- start fresh clears the marker
- broken resume offers `Start fresh` / `Cancel`
- no manual resume affordance remains

- [ ] **Step 5: Merge and clean up after verification**

Use superpowers:finishing-a-development-branch after all checks pass.
