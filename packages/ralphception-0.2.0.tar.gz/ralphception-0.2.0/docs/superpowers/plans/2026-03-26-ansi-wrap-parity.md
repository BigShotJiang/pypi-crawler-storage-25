# ANSI Wrap Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Wrap ANSI-styled committed history by visible width instead of raw escape-sequence length so Codex-style header and transcript surfaces stay intact in tmux.

**Architecture:** Keep the existing insert-history pipeline, but make line wrapping ANSI-aware. Plain-text lines should continue through the simple text wrapper, while lines containing SGR styling should be wrapped by visible columns with active styles carried across wrapped segments.

**Tech Stack:** Python, ANSI terminal renderer, Codex TUI port, pytest unit/integration tests

---

### Task 1: Lock the visible-width wrapping bug in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_insert_history.py`

- [ ] **Step 1: Add a failing ANSI wrapping regression**

Add a test that inserts a styled line containing ANSI SGR escapes through `insert_history_lines()` and asserts it consumes one visible history row when it should fit within the available width.

- [ ] **Step 2: Run the targeted regression to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_insert_history.py::test_insert_history_lines_does_not_wrap_ansi_styled_text_by_escape_length -q`

Expected: failure showing the styled line wrapped into extra history rows because escape bytes were counted as visible width.

### Task 2: Make history insertion wrap ANSI lines by visible columns

**Files:**
- Modify: `src/ralphception/codex_tui/insert_history.py`

- [ ] **Step 1: Keep the plain-text wrapping path unchanged**

Continue using the simple text wrapper for lines that do not contain ANSI escape sequences.

- [ ] **Step 2: Add an ANSI-aware wrapping helper**

Implement a helper that:
- treats SGR sequences as zero-width
- wraps only by visible characters
- carries active styles across wrapped segments
- resets style safely at segment boundaries when needed

- [ ] **Step 3: Route ANSI lines through the new helper**

Update the history insertion wrapping path so styled Codex surfaces and transcript cells use visible-width wrapping before insertion into scrollback.

### Task 3: Verify tmux parity on the first-prompt path

**Files:**
- No code changes required

- [ ] **Step 1: Run focused TUI tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_insert_history.py tests/unit/codex_tui/test_tui.py tests/integration/test_codex_tui_tmux.py -q`

Expected: pass

- [ ] **Step 2: Re-run the real tmux first-prompt flow**

Verify in a fresh tmux session that:
- the startup header/model line stays intact after the first prompt
- no large blank slab is reintroduced
- the first Socratic follow-up still renders cleanly

### Task 4: Full verification and merge

**Files:**
- No code changes required

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: all tests pass

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 3: Run diff check**

Run: `git diff --check`

Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/insert_history.py tests/unit/codex_tui/test_insert_history.py docs/superpowers/plans/2026-03-26-ansi-wrap-parity.md
git commit -m "fix: wrap ansi history by visible width"
```
