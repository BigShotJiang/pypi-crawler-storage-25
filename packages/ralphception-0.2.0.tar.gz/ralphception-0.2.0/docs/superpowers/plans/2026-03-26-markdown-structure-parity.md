# Markdown Structure Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Bring Ralphception’s assistant transcript renderer closer to Codex by supporting local-file link display, ordered lists, blockquotes, and fenced code blocks.

**Architecture:** Extend the current styled-span markdown renderer instead of replacing it. Add the missing structural cases one at a time, keeping the render path line-oriented and ANSI-backed, while copying Codex’s most user-visible transcript semantics: local path links display the target, ordered list markers are styled distinctly, blockquotes are visually marked, and fenced code blocks preserve indentation and styling.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the remaining markdown-structure gaps in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Write failing tests for structural markdown cases**

Add tests that assert:
- local file links display the path target rather than the markdown label
- ordered lists render numbered markers
- blockquotes render with a visible quote marker/styling
- fenced code blocks render as literal indented lines without markdown stripping

- [ ] **Step 2: Run the markdown-render tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL because the current renderer only handles headings, bullets, and basic inline markup.

- [ ] **Step 3: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_markdown_render.py
git commit -m "test: pin codex markdown structure parity"
```

### Task 2: Implement the missing structural markdown rendering

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Modify: `src/ralphception/codex_tui/styled_text.py`
- Test: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Re-run the failing markdown tests before coding**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL

- [ ] **Step 2: Implement the minimal structural renderer changes**

Add support for:
- local file links showing the destination text
- ordered list markers with distinct styling
- blockquote markers and quote styling
- fenced code blocks as preserved literal/code-styled lines

- [ ] **Step 3: Run the markdown-render tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: PASS

- [ ] **Step 4: Commit the renderer implementation**

```bash
git add src/ralphception/codex_tui/markdown_render.py src/ralphception/codex_tui/styled_text.py tests/unit/codex_tui/test_markdown_render.py
git commit -m "feat: add codex markdown structure rendering"
```

### Task 3: Verify transcript behavior and merge

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add transcript-level regression coverage**

Add tests that prove assistant-history cells preserve the new structure rendering in the transcript path.

- [ ] **Step 2: Run focused regression coverage**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

- [ ] **Step 3: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Compare against Codex in tmux**

Probe `codex` and `uv run ralphception` in fresh tmux windows and confirm that structured assistant transcript output is visibly closer for file references, quoted text, list markers, and code-block-like output.

- [ ] **Step 5: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/markdown-structure-parity
git push origin main
git worktree remove .worktrees/feat-markdown-structure-parity
git branch -d feat/markdown-structure-parity
```
