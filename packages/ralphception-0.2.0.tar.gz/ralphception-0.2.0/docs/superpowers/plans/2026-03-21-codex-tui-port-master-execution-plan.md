# Codex TUI App-Server Port Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Ralphception's fake Codex imitation with a Python/Textual port of the actual `~/code/codex/codex-rs/tui_app_server` shell structure, wired to Ralphception runtime state and stripped of hardcoded visual stand-ins.

**Architecture:** Rebuild `src/ralphception/tui/` around Codex's real ownership model: app root owns a stateful chat widget; chat widget owns transcript state plus a stateful bottom pane; the bottom pane owns the composer and overlay/view stack. Ralphception runtime state will be projected into this shell through a richer adapter layer instead of preformatted transcript strings or hardcoded footer/header labels.

**Tech Stack:** Python 3.13, Textual, pytest, existing Ralphception runtime/supervisor/bootstrap models, Codex `tui_app_server` Rust sources under `~/code/codex`

---

## Scope Check

This plan is intentionally narrower than a full product rewrite in one pass. It covers the full terminal product surface, but in ordered slices that always land on working software:

1. remove hardcoded shell metadata and fake transcript summaries
2. replace string-template shell primitives with stateful Codex-shaped components
3. port the bottom-pane/controller model from Codex's app-server TUI
4. port transcript and active-cell state so execution flows through the shell instead of ad hoc strings
5. port thread/subagent and resume picker behavior
6. finish runtime projection, delete obsolete internals, and re-verify the product end-to-end

Out of scope:

- preserving the current fake shell internals
- preserving visual or behavioral deviations just because they already exist
- implementing unrelated runtime features

## Execution Notes

- Follow `@superpowers:test-driven-development` for every behavior change. No production code without a failing test.
- Treat `~/code/codex/codex-rs/tui_app_server` as the primary source of truth. Only use `codex-rs/tui` when the app-server path reuses or omits a primitive.
- Prefer replacing existing `src/ralphception/tui/*.py` files over layering wrappers around them.
- Delete superseded code in the same chunk that replaces it.
- After every chunk, run the named verification commands before proceeding.

## Codex Reference Map

Primary source modules:

- `~/code/codex/codex-rs/tui_app_server/src/app.rs`
- `~/code/codex/codex-rs/tui_app_server/src/app/app_server_adapter.rs`
- `~/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui_app_server/src/chatwidget/session_header.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/mod.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/bottom_pane_view.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/chat_composer.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/footer.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/approval_overlay.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/request_user_input.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/slash_commands.rs`
- `~/code/codex/codex-rs/tui_app_server/src/multi_agents.rs`
- `~/code/codex/codex-rs/tui_app_server/src/resume_picker.rs`

Secondary references when app-server delegates to older shared implementations:

- `~/code/codex/codex-rs/tui/src/markdown_render.rs`
- `~/code/codex/codex-rs/tui/src/**/snapshots`
- `~/code/codex/codex-rs/tui_app_server/src/**/snapshots`

## Current Ralphception Files To Replace

These files currently encode the shortcut implementation and must be treated as replaceable, not foundational:

- `src/ralphception/tui/app.py`
- `src/ralphception/tui/render_state.py`
- `src/ralphception/tui/runtime_adapter.py`
- `src/ralphception/tui/chatwidget/session_header.py`
- `src/ralphception/tui/chatwidget/transcript_cells.py`
- `src/ralphception/tui/chatwidget/transcript_view.py`
- `src/ralphception/tui/bottom_pane/chat_composer.py`
- `src/ralphception/tui/bottom_pane/footer.py`
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`

## Chunk 1: Eliminate Hardcoded Shell Metadata And Fake Root State

### Task 1: Replace `RenderState.idle_preview()` with real session/app-shell state

**Codex references:**

- `codex-rs/tui_app_server/src/app.rs`
- `codex-rs/tui_app_server/src/chatwidget.rs`
- `codex-rs/tui_app_server/src/chatwidget/session_header.rs`

**Files:**

- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `tests/integration/test_tui_shell_frame.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Write failing tests that prohibit the existing hardcoded stand-ins**

Add assertions that the idle preview does **not** rewrite reasoning values, does **not** inject `100% left`, and does **not** hardcode the Codex placeholder text. Add a runtime-backed shell test that proves the header/footer fields come from explicit shell state rather than from `RenderState.idle_preview()` defaults.

- [ ] **Step 2: Run the focused tests to verify they fail for the current implementation**

Run: `uv run pytest tests/integration/test_tui_shell_frame.py tests/unit/test_tui_runtime_adapter.py -q`
Expected: FAIL on the hardcoded `xhigh`, `100% left`, and placeholder assumptions.

- [ ] **Step 3: Replace `RenderState` with explicit shell-state dataclasses**

Create or update state models so the app root receives:

- shell label
- header state
- announcement rows
- transcript state
- bottom-pane state
- overlay/view-stack state

`idle_preview()` may still exist for test fixtures, but it must build state explicitly and must not copy Codex marketing strings or quota strings into Ralphception by default.

- [ ] **Step 4: Update the root app to consume the explicit shell-state objects**

`RalphceptionTuiApp` should stop assembling text fragments from `render_state` and instead delegate to stateful child components.

- [ ] **Step 5: Re-run the focused tests and commit**

Run: `uv run pytest tests/integration/test_tui_shell_frame.py tests/unit/test_tui_runtime_adapter.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/render_state.py src/ralphception/tui/app.py tests/integration/test_tui_shell_frame.py tests/unit/test_tui_runtime_adapter.py
git commit -m "refactor: remove hardcoded TUI shell metadata"
```

## Chunk 2: Port The ChatWidget Ownership Model

### Task 2: Replace string-rendered shell regions with a stateful `ChatWidget`

**Codex references:**

- `codex-rs/tui_app_server/src/chatwidget.rs`
- `codex-rs/tui_app_server/src/chatwidget/session_header.rs`

**Files:**

- Create: `src/ralphception/tui/chatwidget/chat_widget.py`
- Modify: `src/ralphception/tui/chatwidget/__init__.py`
- Modify: `src/ralphception/tui/chatwidget/session_header.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `tests/integration/test_tui_session_header.py`
- Modify: `tests/integration/test_tui_transcript.py`

- [ ] **Step 1: Write failing integration tests for a real chat-widget structure**

Add tests that the root app mounts a single chat widget responsible for:

- session header
- announcement rows
- transcript viewport
- bottom pane

The tests should stop calling pure string renderers directly for the main shell path.

- [ ] **Step 2: Run the header/transcript tests to verify the current string-renderer approach fails**

Run: `uv run pytest tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py -q`
Expected: FAIL because the shell still depends on pure text render helpers rather than a widget-owned structure.

- [ ] **Step 3: Implement `ChatWidget` and a mutable `SessionHeader` component**

Port the ownership model, not the Rust syntax:

- `ChatWidget` owns header, transcript, bottom pane, and local UI state
- `SessionHeader` becomes a mutable component with explicit setters
- transcript view becomes a widget/controller over transcript cell state, not just `"\n".join(...)`

- [ ] **Step 4: Route the app root through `ChatWidget`**

`RalphceptionTuiApp` should become a thin composition root around the chat widget, mirroring Codex's `app.rs` more closely.

- [ ] **Step 5: Re-run tests and commit**

Run: `uv run pytest tests/integration/test_tui_shell_frame.py tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/app.py src/ralphception/tui/chatwidget tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py
git commit -m "refactor: port Codex chat widget ownership model"
```

## Chunk 3: Port The Bottom Pane Controller And Composer

### Task 3: Replace the placeholder composer with a real bottom-pane owner

**Codex references:**

- `codex-rs/tui_app_server/src/bottom_pane/mod.rs`
- `codex-rs/tui_app_server/src/bottom_pane/bottom_pane_view.rs`
- `codex-rs/tui_app_server/src/bottom_pane/chat_composer.rs`
- `codex-rs/tui_app_server/src/bottom_pane/footer.rs`

**Files:**

- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/bottom_pane/chat_composer.py`
- Modify: `src/ralphception/tui/bottom_pane/footer.py`
- Create: `src/ralphception/tui/bottom_pane/bottom_pane.py`
- Modify: `src/ralphception/tui/chatwidget/chat_widget.py`
- Modify: `tests/integration/test_tui_bottom_pane.py`

- [ ] **Step 1: Write failing tests for bottom-pane ownership and real composer state**

Add tests that assert:

- the composer is an editable widget, not a placeholder renderer
- the bottom pane owns a view stack for overlays/popups
- the footer is derived from structured state, not a single hardcoded status string

- [ ] **Step 2: Run the bottom-pane tests and verify they fail**

Run: `uv run pytest tests/integration/test_tui_bottom_pane.py -q`
Expected: FAIL because the current bottom pane still renders pure strings and a stub-like composer model.

- [ ] **Step 3: Implement `BottomPane` and `BottomPaneView` ownership**

Port these behaviors:

- persistent composer state even when an overlay replaces the visible pane
- local routing of input to the active view or composer
- explicit footer state separate from higher-level decisions

- [ ] **Step 4: Implement a real composer widget with placeholder, draft buffer, and focus**

Do not port every Codex composer feature immediately. Minimum required for this chunk:

- editable buffer
- placeholder
- submit callback
- slash-command detection hook
- focus management

- [ ] **Step 5: Port the footer as a structured renderer over state**

Footer data should come from state fields like mode, task-running status, context info, agent label, and hints. No single preformatted status line string.

- [ ] **Step 6: Re-run tests and commit**

Run: `uv run pytest tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_shell_frame.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/bottom_pane src/ralphception/tui/chatwidget/chat_widget.py tests/integration/test_tui_bottom_pane.py
git commit -m "refactor: port Codex bottom pane and composer ownership"
```

## Chunk 4: Port Overlay Stack For Reviews And Request-User-Input

### Task 4: Replace ad hoc overlay summaries with view-stack overlays

**Codex references:**

- `codex-rs/tui_app_server/src/bottom_pane/approval_overlay.rs`
- `codex-rs/tui_app_server/src/bottom_pane/request_user_input.rs`
- `codex-rs/tui_app_server/src/bottom_pane/list_selection_view.rs`

**Files:**

- Modify: `src/ralphception/tui/bottom_pane/approval_overlay.py`
- Modify: `src/ralphception/tui/bottom_pane/request_user_input.py`
- Modify: `src/ralphception/tui/bottom_pane/list_selection.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `tests/integration/test_tui_overlays.py`
- Modify: `tests/integration/test_startup_flow.py`

- [ ] **Step 1: Write failing overlay tests for review and startup/input flows**

Cover:

- startup bootstrap shown as a bottom-pane view
- review approval shown as a bottom-pane view
- view dismissal/submit returns the pane to the composer

- [ ] **Step 2: Run the overlay tests to verify the current implementation fails**

Run: `uv run pytest tests/integration/test_tui_overlays.py tests/integration/test_startup_flow.py -q`
Expected: FAIL because overlays are still flattened into summary text or button rows.

- [ ] **Step 3: Implement approval and request-user-input overlay views**

Port the view-stack concept, not just strings:

- explicit overlay models
- active-view selection in bottom pane
- callback/results back into the runtime adapter

- [ ] **Step 4: Re-run tests and commit**

Run: `uv run pytest tests/integration/test_tui_overlays.py tests/integration/test_startup_flow.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/bottom_pane src/ralphception/tui/runtime_adapter.py tests/integration/test_tui_overlays.py tests/integration/test_startup_flow.py
git commit -m "feat: port review and request-input overlays"
```

## Chunk 5: Port Transcript Cells And Runtime Projection

### Task 5: Replace canned transcript rows with transcript cell state and active-cell updates

**Codex references:**

- `codex-rs/tui_app_server/src/chatwidget.rs`
- `codex-rs/tui/src/markdown_render.rs`

**Files:**

- Modify: `src/ralphception/tui/chatwidget/transcript_cells.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/chatwidget/markdown_render.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `tests/integration/test_tui_transcript.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Write failing tests for committed cells plus active streaming cell behavior**

Add tests proving the adapter can emit:

- committed assistant/system/user cells
- an active in-flight cell
- command/tool style cells
- review/recovery/completion cells

- [ ] **Step 2: Run transcript and adapter tests to verify the current canned strings fail**

Run: `uv run pytest tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py -q`
Expected: FAIL because the adapter still returns preformatted transcript strings.

- [ ] **Step 3: Implement transcript cell models and a richer runtime projection**

Replace:

- `"Seed prompt required."`
- `"Mission ready for ..."`
- review summary line dumps

with explicit transcript cells and overlay intents derived from runtime steps and review prompts.

- [ ] **Step 4: Re-run tests and commit**

Run: `uv run pytest tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/chatwidget src/ralphception/tui/runtime_adapter.py tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py
git commit -m "refactor: project runtime state into Codex-style transcript cells"
```

## Chunk 6: Port Thread/Subagent And Resume Navigation

### Task 6: Move child runs and resume flows into Codex-style pickers

**Codex references:**

- `codex-rs/tui_app_server/src/multi_agents.rs`
- `codex-rs/tui_app_server/src/resume_picker.rs`

**Files:**

- Modify: `src/ralphception/tui/multi_agents.py`
- Modify: `src/ralphception/tui/resume_picker.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `tests/integration/test_tui_multi_agents.py`
- Modify: `tests/integration/test_tui_resume_picker.py`

- [ ] **Step 1: Write failing tests for thread labels, picker entries, and navigation shortcuts**

Cover:

- primary thread label
- child run/subagent label formatting
- picker entries
- next/previous navigation behavior

- [ ] **Step 2: Run the tests to verify the current implementation fails**

Run: `uv run pytest tests/integration/test_tui_multi_agents.py tests/integration/test_tui_resume_picker.py -q`
Expected: FAIL because the current implementation still uses simplified formatting and lacks Codex-style ownership.

- [ ] **Step 3: Implement Codex-style multi-agent and resume picker primitives**

Map Ralphception child runs and resumable missions into:

- picker item models
- formatting helpers
- view-stack integration
- runtime actions to switch active context

- [ ] **Step 4: Re-run tests and commit**

Run: `uv run pytest tests/integration/test_tui_multi_agents.py tests/integration/test_tui_resume_picker.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/tui/multi_agents.py src/ralphception/tui/resume_picker.py src/ralphception/tui/runtime_adapter.py tests/integration/test_tui_multi_agents.py tests/integration/test_tui_resume_picker.py
git commit -m "feat: port Codex thread and resume navigation"
```

## Chunk 7: Delete Obsolete Internals And Re-verify Product Entry

### Task 7: Remove dead stand-ins and tighten the public product path

**Codex references:**

- `codex-rs/tui_app_server/src/app.rs`

**Files:**

- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/app.py`
- Modify: `README.md`
- Modify/Delete as needed: obsolete helper functions under `src/ralphception/tui/`
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write failing tests that prove the live entrypoint uses the new shell structure**

The tests should prove:

- `ralphception` launches the rebuilt TUI
- runtime-backed startup/review flows use chat widget + bottom pane, not legacy stand-ins

- [ ] **Step 2: Run the CLI/runtime integration tests and verify they fail where dead helpers remain**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py tests/integration/test_tui_runtime_app.py tests/e2e/test_core_runtime.py -q`
Expected: FAIL until obsolete helper paths are removed or updated.

- [ ] **Step 3: Remove dead render helpers and finalize public entry wiring**

Delete or inline anything that only existed for the fake shell version.

- [ ] **Step 4: Re-run focused tests and commit**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py tests/integration/test_tui_runtime_app.py tests/e2e/test_core_runtime.py -q`
Expected: PASS

Commit:

```bash
git add src/ralphception/cli.py src/ralphception/app.py src/ralphception/tui README.md tests/unit/test_cli_bootstrap.py tests/integration/test_tui_runtime_app.py tests/e2e/test_core_runtime.py
git commit -m "refactor: cut over to real Codex-port TUI internals"
```

## Final Verification

- [ ] Run: `uv run pytest tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_shell_frame.py tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_overlays.py tests/integration/test_tui_multi_agents.py tests/integration/test_tui_resume_picker.py tests/integration/test_tui_runtime_app.py -q`
- [ ] Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
- [ ] Run: `uv run ty check src tests`
- [ ] Run: `git diff --check`
- [ ] Run a manual shell smoke test: `uv run ralphception`
- [ ] Compare the live shell against `~/code/codex` for header, composer, footer, overlay, and thread-nav behavior

## Definition Of Done

- no hardcoded model/footer/composer copy remains in `src/ralphception/tui/`
- the app root, chat widget, bottom pane, and transcript ownership model visibly follow Codex's `tui_app_server` structure
- runtime-backed startup, review, and ready states flow through transcript cells and bottom-pane views rather than ad hoc summary strings
- the public `ralphception` entrypoint uses the rebuilt shell
- focused tests, full test suite, type checks, and `git diff --check` all pass

Plan complete and saved to `docs/superpowers/plans/2026-03-21-codex-tui-port-master-execution-plan.md`. Ready to execute.
