# Terminal Live Logging Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make terminal mode stream readable high-level mission progress from the shared runtime while a real or fake backend executes.

**Architecture:** Keep the terminal frontend as a simple sink for `FrontendEvent.message` lines and add structured event emission inside the shared mission supervisor. Log at real state-transition points only, so output reflects authoritative progress without inventing a second control loop.

**Tech Stack:** Python 3.12, Typer, Textual-compatible runtime frontends, pytest.

---

## Chunk 1: Terminal Logging Contract

### Task 1: Lock down the user-visible terminal log behavior

**Files:**
- Modify: `tests/integration/test_terminal_frontend.py`
- Test: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Write the failing test**

Add one integration test that runs a fake-backed terminal mission and asserts the log text contains readable progress such as:
- stage announcements
- turn start/completion
- child run creation
- verification or merge milestones

- [ ] **Step 2: Run the targeted test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py -q`
Expected: FAIL because the current terminal output only shows coarse runtime status.

- [ ] **Step 3: Implement the minimal supervisor event emission**

Add shared-runtime event helpers and call them from the real mission flow.

- [ ] **Step 4: Re-run the targeted test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/integration/test_terminal_frontend.py src/ralphception/headless.py
git commit -m "feat: emit terminal mission progress events"
```

## Chunk 2: Shared Runtime Progress Coverage

### Task 2: Cover the important mission milestones

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/terminal.py` (only if needed)
- Test: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Add the next failing assertions**

Expand coverage to include:
- approval events
- audit reopen events
- mission completion event

- [ ] **Step 2: Run the targeted test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py -q`
Expected: FAIL until the remaining milestones are emitted.

- [ ] **Step 3: Implement the remaining progress events**

Add concise event messages at:
- spec/bundle approval
- execute-stage child run creation
- verification result
- merge result
- audit reopen or completion

- [ ] **Step 4: Re-run the targeted test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/headless.py src/ralphception/runtime/terminal.py tests/integration/test_terminal_frontend.py
git commit -m "feat: log terminal mission milestones"
```

## Chunk 3: Docs And Full Verification

### Task 3: Document and verify the new terminal behavior

**Files:**
- Modify: `README.md`
- Test: `tests/unit`
- Test: `tests/integration`
- Test: `tests/e2e`

- [ ] **Step 1: Update docs**

Document that terminal mode now streams high-level mission progress from the shared runtime.

- [ ] **Step 2: Run the full suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 4: Run a real terminal smoke test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ralphception terminal --repo-root <temp-repo> --seed-prompt 'find any bugs' --approve-all`
Expected: the command prints high-level progress lines before or while the mission is running, instead of staying silent after startup.

- [ ] **Step 5: Commit**

```bash
git add README.md
git commit -m "docs: describe terminal live logging"
```
