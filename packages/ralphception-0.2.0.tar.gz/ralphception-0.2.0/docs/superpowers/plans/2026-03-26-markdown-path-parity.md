# Markdown Path Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception’s local markdown file-link rendering match Codex more closely by shortening absolute paths against the current workspace and preserving relative local targets cleanly.

**Architecture:** Extend the current markdown renderer’s local-link path display helper rather than changing the whole render pipeline. Keep the current local-link detection and styled rendering, but add cwd-aware display shortening for absolute local paths, preserving non-local URLs and already-relative paths as-is.

**Tech Stack:** Python 3.13, pathlib, ANSI escape sequences, pytest

---

### Task 1: Pin the path-shortening gap in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Write failing tests for cwd-relative local link display**

Add tests that assert:
- an absolute local path under the cwd is shortened to a relative path
- an absolute path outside the cwd stays absolute
- an already-relative local path stays relative

- [ ] **Step 2: Run the markdown-render tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL because the current renderer prints the raw destination string.

- [ ] **Step 3: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_markdown_render.py
git commit -m "test: pin codex markdown path parity"
```

### Task 2: Implement cwd-aware local path display

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Test: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Re-run the failing markdown tests before coding**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL

- [ ] **Step 2: Implement the minimal cwd-aware path logic**

Add a helper that:
- normalizes local link paths
- shortens absolute paths only when they are strictly under the current cwd
- leaves outside-of-cwd absolute paths unchanged
- preserves relative local paths unchanged

- [ ] **Step 3: Run the markdown-render tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: PASS

- [ ] **Step 4: Commit the implementation**

```bash
git add src/ralphception/codex_tui/markdown_render.py tests/unit/codex_tui/test_markdown_render.py
git commit -m "feat: shorten codex tui local markdown paths"
```

### Task 3: Verify and merge

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Add transcript-level regression coverage**

Add an assistant-history test that proves an absolute local file link under the repo root renders as a relative path in transcript history.

- [ ] **Step 2: Run focused regression coverage**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: PASS

- [ ] **Step 3: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/markdown-path-parity
git push origin main
git worktree remove .worktrees/feat-markdown-path-parity
git branch -d feat/markdown-path-parity
```
