# Codex Bottom Pane Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port Codex-style bottom-pane status/footer behavior into `codex_tui` so busy states, spacing, shimmer, and startup intake scope assumptions feel like the real Codex shell.

**Architecture:** Replace the current string-only `waiting_line` flow with structured bottom-pane state modeled on the richer `src/ralphception/tui/bottom_pane` implementation already in this repo. Keep the ANSI renderer, but reuse the same footer and status-indicator rules so the layout logic is shared conceptually instead of hand-tuned per screenshot.

**Tech Stack:** Python 3.13, ANSI terminal rendering, pytest, tmux, existing `codex_tui` renderer and adapter.

---

### Task 1: Lock the bottom-pane parity targets in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`
- Modify: `tests/unit/codex_tui/test_status.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a failing unit test for busy-state spacer/layout**

Add assertions that a busy bottom pane renders:
- dedicated busy/status row
- blank spacer row
- composer row
- footer row

- [ ] **Step 2: Run the targeted unit test to verify it fails**

Run: `uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_status.py -q`
Expected: FAIL because `BottomPane` still uses `waiting_line` and static footer assembly.

- [ ] **Step 3: Add a failing unit test for running-draft footer behavior**

Assert that when a task is running and the composer has a draft, the footer uses `tab to queue message` instead of the passive status-line row.

- [ ] **Step 4: Add a failing startup-intake test for full-repo default scope**

Assert the startup prompt/skill contract no longer pushes the model toward file-scope clarification as the default follow-up.

- [ ] **Step 5: Add a failing tmux/integration expectation**

Update the tmux parity test to require:
- immediate busy line after prompt submit
- spacer between busy line and composer
- no stacked reply/input surface after blocker answer

- [ ] **Step 6: Run the targeted tests again**

Run: `uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/unit/codex_tui/test_status.py tests/integration/test_codex_tui_tmux.py -q`
Expected: FAIL on the new assertions.

### Task 2: Port structured status-indicator rendering into `codex_tui`

**Files:**
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/styled_text.py`

- [ ] **Step 1: Introduce structured busy-state data in `bottom_pane.py`**

Replace `waiting_line: str | None` with a status-indicator state object carrying:
- `header`
- `details`
- `inline_message`
- `elapsed_seconds`
- `show_interrupt_hint`
- `animations_enabled`

- [ ] **Step 2: Port Codex-style status-indicator formatting into `status.py`**

Implement:
- compact elapsed formatter
- structured busy-row renderer
- detail-line wrapping with `  └ ` prefix
- animation/shimmer helpers for the busy header

- [ ] **Step 3: Update `chatwidget.py` to render busy rows and spacer layout correctly**

Ensure the bottom pane produces:
- busy row
- optional details block
- blank spacer
- composer surface
- footer row

- [ ] **Step 4: Run the targeted tests**

Run: `uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_status.py -q`
Expected: PASS

### Task 3: Port footer mode behavior and wire the adapter

**Files:**
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Implement Codex-like footer mode selection**

Add the footer rules:
- idle empty composer => shortcuts/context
- running with draft => queue-message footer
- passive status row only when ambient context is allowed
- reply blocker preserves reply footer

- [ ] **Step 2: Update `ralph_adapter.py` to populate structured busy/footer state**

Map startup intake, blocker waits, live running states, and child-loop states onto the new structured status/footer model.

- [ ] **Step 3: Run adapter/unit tests**

Run: `uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: PASS

### Task 4: Remove startup scope-clarification bias

**Files:**
- Modify: `src/ralphception/runtime/startup_llm.py`
- Modify: `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Change the startup intake prompt contract**

Document and enforce:
- whole repo is in scope by default
- referenced outside folders are in scope by default
- ask about constraints/success criteria only when needed

- [ ] **Step 2: Run the startup-related tests**

Run: `uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`
Expected: PASS

### Task 5: Verify against real tmux behavior and ship

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py` (if final expectation tweaks are needed)

- [ ] **Step 1: Run the focused tmux smoke on the feature worktree**

Use the repo helper or tmux commands to verify:
- startup shell
- first prompt submit
- immediate busy/loading state
- Socratic follow-up
- blocker reply submit
- no stacked composer/reply surfaces
- footer mode looks closer to `~/code/codex`

- [ ] **Step 2: Run the full verification suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type checks and diff hygiene**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Merge and push**

Run:
```bash
git checkout main
git pull --ff-only
git merge --ff-only feat/codex-bottom-pane-parity
git push origin main
```

- [ ] **Step 5: Clean up**

Run:
```bash
git worktree remove .worktrees/feat-codex-bottom-pane-parity
git branch -d feat/codex-bottom-pane-parity
```
