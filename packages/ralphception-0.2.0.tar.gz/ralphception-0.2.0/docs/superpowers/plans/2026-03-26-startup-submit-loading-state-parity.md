# Startup Submit Loading State Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Show a Codex-style transient waiting/loading state immediately after the user submits the first prompt or a blocker reply, so the live TUI does not appear idle or stack the sent reply on top of the still-active input surface.

**Architecture:** Keep the fix in the Codex TUI submit loop, not in the runtime heuristics. The frontend should switch into a temporary waiting state before synchronous startup/prompt resolution, then let normal runtime events replace that state when the actual model-authored question or loop activity arrives.

**Tech Stack:** Python, pytest, tmux, Ralphception Codex TUI

---

### Task 1: Lock the missing loading transition with tests

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/unit/codex_tui/test_chatwidget.py`

- [ ] **Step 1: Write a failing integration test for first-prompt submit**

Add a scripted-shell test that submits the first prompt through `run_codex_tui_shell()` with a delayed `resolve_startup_input()` stub and asserts the rendered output shows a waiting/working state before the clarifying question arrives.

- [ ] **Step 2: Run the targeted test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`
Expected: FAIL because the shell stays visually idle until `resolve_startup_input()` returns.

- [ ] **Step 3: Write a failing test for blocker-reply submit**

Add a scripted-shell test that submits a blocker reply through the same interactive loop with a delayed `resolve_pending_prompt()` stub and asserts the reply composer is cleared and replaced by a waiting state before resolution returns.

- [ ] **Step 4: Run the targeted tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: FAIL because the sent reply remains stacked against the active reply input surface.

### Task 2: Implement the transient waiting/loading state

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py` (only if the existing bottom-pane API cannot express the transient waiting state cleanly)

- [ ] **Step 1: Add a frontend/helper entrypoint for startup submit waiting**

Implement a small helper that flushes the startup shell if needed, clears the reply composer state, and switches the live viewport into a waiting/working state before `resolve_startup_input()` is called.

- [ ] **Step 2: Add a frontend/helper entrypoint for blocker reply waiting**

Implement a similar helper for prompt replies so a submitted blocker answer clears the reply composer/footer immediately and yields breathing room before the next model-authored message arrives.

- [ ] **Step 3: Use the new helpers in the interactive submit loop**

Wire the first-prompt path and the `resolve_pending_prompt()` path in `run_codex_tui_shell()` through those helpers before the synchronous runtime resolution calls.

- [ ] **Step 4: Keep the waiting state compatible with later runtime events**

Make sure normal `BlockerPromptEvent`, `CurrentBlockerStateEvent`, `CurrentWaitingStateEvent`, and loop-launch events replace the transient loading state cleanly without leaving stale footer/input state behind.

### Task 3: Verify on real tmux and land cleanly

**Files:**
- Verify only

- [ ] **Step 1: Run targeted tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: PASS

- [ ] **Step 2: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type checks and diff hygiene**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Run tmux smoke on the feature worktree**

Drive:
1. `uv run ralphception`
2. Submit `hello`
3. Confirm a transient working/loading state appears before the Socratic question
4. Submit a blocker reply
5. Confirm the reply composer clears immediately and the shell shows waiting/working instead of stacking the sent reply against the active input box

- [ ] **Step 5: Commit, cherry-pick/merge to main, rerun verification on main, push, and clean up**
