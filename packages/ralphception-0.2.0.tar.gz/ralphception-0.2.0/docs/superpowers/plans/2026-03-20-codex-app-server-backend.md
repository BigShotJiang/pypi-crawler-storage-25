# Codex App-Server Backend Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `uv run ralphception terminal --seed-prompt ...` use a real Codex backend by speaking to the installed `codex app-server`, instead of depending on the missing `codex_app_server` Python module.

**Architecture:** Replace the current optional Python-SDK adapter with a stdio JSON-RPC client that launches `codex app-server --listen stdio://` as a subprocess and maps the existing thread/turn APIs onto that transport. Keep `CodexSessionManager` and the supervisor/runtime flow intact so the change is localized to backend discovery and the Codex client boundary.

**Tech Stack:** Python 3.12, Typer, Textual, subprocess, JSON-RPC over stdio, pytest.

---

## Chunk 1: Backend Contract And Detection

### Task 1: Lock down the required runtime behavior with tests

**Files:**
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Test: `tests/unit/test_cli_bootstrap.py`
- Test: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Write the failing tests**

Add coverage that asserts:
- a present `codex` binary is considered a real backend even when `codex_app_server.client` is absent
- terminal/headless no longer emit the old Python-module-specific failure when the CLI backend is available
- a missing `codex` binary still fails with a concrete backend-unavailable error

- [ ] **Step 2: Run the targeted tests to verify they fail**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py -q`
Expected: FAIL because backend discovery still only checks for `codex_app_server.client`

- [ ] **Step 3: Implement the minimal detection changes**

Update backend discovery to prefer the installed `codex` CLI, not the missing Python package.

- [ ] **Step 4: Re-run the targeted tests**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add tests/unit/test_cli_bootstrap.py tests/integration/test_terminal_frontend.py src/ralphception/app.py src/ralphception/runtime/supervisor.py
git commit -m "test: lock backend discovery to codex cli"
```

## Chunk 2: Stdio App-Server Client

### Task 2: Add a real Codex app-server transport client

**Files:**
- Modify: `src/ralphception/codex/client.py`
- Test: `tests/unit/test_codex_client.py`

- [ ] **Step 1: Write the failing client tests**

Add tests for:
- launching `codex app-server --listen stdio://`
- sending `initialize`, `model/list`, `thread/start`, `thread/resume`, `thread/fork`, `turn/start`, and `turn/interrupt` JSON-RPC requests
- reading notifications and mapping them into `RawCodexEvent`
- translating transport/protocol failures into the existing Ralphception client exceptions

- [ ] **Step 2: Run the new client tests to verify they fail**

Run: `uv run pytest tests/unit/test_codex_client.py -q`
Expected: FAIL because there is no stdio transport implementation yet

- [ ] **Step 3: Implement the stdio JSON-RPC client**

Build a subprocess-backed client in `src/ralphception/codex/client.py` that:
- launches `codex app-server`
- performs `initialize`
- maintains request ids and response correlation
- exposes the existing client protocol methods without changing `CodexSessionManager`

- [ ] **Step 4: Re-run the client tests**

Run: `uv run pytest tests/unit/test_codex_client.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/codex/client.py tests/unit/test_codex_client.py
git commit -m "feat: add codex app-server stdio client"
```

## Chunk 3: Runtime Wiring And Messaging

### Task 3: Wire the real backend through the shared runtime

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/codex/session_manager.py`
- Modify: `README.md`
- Test: `tests/integration/test_startup_flow.py`
- Test: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Write the failing runtime/documentation tests**

Add coverage that:
- `run_terminal` and `run_headless` proceed when `codex` is installed
- backend errors mention missing `codex` executable or missing Codex auth, not missing Python imports
- docs describe `codex` as the required real backend

- [ ] **Step 2: Run the targeted tests to verify they fail**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL until runtime wiring and messages are updated

- [ ] **Step 3: Implement the runtime wiring**

Update the shared runtime to:
- instantiate the new client-backed `CodexSessionManager`
- surface actionable startup failures
- keep `--fake-session-manager` strictly as a deterministic test path

- [ ] **Step 4: Re-run the targeted tests**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/unit/test_cli_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/app.py src/ralphception/runtime/supervisor.py src/ralphception/codex/session_manager.py README.md tests/integration/test_startup_flow.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: wire runtime to codex app-server backend"
```

## Chunk 4: End-To-End Verification

### Task 4: Verify the real backend path end to end

**Files:**
- Modify: `tests/e2e/` as needed
- Test: `tests/unit`
- Test: `tests/integration`
- Test: `tests/e2e`

- [ ] **Step 1: Add any missing e2e coverage**

If current coverage still only proves the fake backend path, add one focused e2e around real-backend detection and startup handoff.

- [ ] **Step 2: Run the full verification suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 4: Run a real CLI smoke test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ralphception terminal --seed-prompt 'find any bugs'`
Expected: the runtime reaches actual execution startup against the installed `codex` backend, or fails with a real auth/runtime error from Codex rather than a missing-backend import error

- [ ] **Step 5: Commit**

```bash
git add tests/e2e README.md
git commit -m "test: verify codex app-server backend end to end"
```
