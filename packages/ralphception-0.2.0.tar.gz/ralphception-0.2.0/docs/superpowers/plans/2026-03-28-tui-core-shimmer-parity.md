# TUI Core Shimmer Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the Codex shimmer, spinner, and terminal-palette behavior into low-level `tui_core` primitives, then make the Codex-port status indicator compose those primitives for real parity in tmux.

**Architecture:** Add low-level palette, shimmer, and spinner helpers under `src/ralphception/tui_core/`, then make `src/ralphception/codex_tui/status.py` delegate to them instead of implementing its own near-match algorithm. Preserve the existing visible busy-row contract while making the animation and styling logic match Codex.

**Tech Stack:** Python 3.12/3.13, ANSI terminal rendering, pytest, tmux, `uv`, `ty`.

---

### Task 1: Lock the current parity gap in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_status.py`
- Create: `tests/unit/tui_core/test_shimmer.py`

- [ ] **Step 1: Add a failing low-level shimmer parity test**

Write tests that pin:
- the Codex shimmer band width (`5.0`)
- bold-always truecolor styling
- dim/normal/bold fallback thresholds

- [ ] **Step 2: Add a failing separation test for spinner versus shimmer**

Write a test proving the busy glyph path is separate from the shimmered header path.

- [ ] **Step 3: Run the focused tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_status.py tests/unit/tui_core/test_shimmer.py -q`
Expected: FAIL on the new parity assertions.

### Task 2: Add low-level palette primitives to `tui_core`

**Files:**
- Create: `src/ralphception/tui_core/palette.py`
- Modify: `src/ralphception/tui_core/tui.py`
- Modify: `src/ralphception/tui_core/terminal.py`

- [ ] **Step 1: Add terminal default fg/bg and color-level helpers**

Implement cached helpers for:
- default foreground color
- default background color
- stdout color level

- [ ] **Step 2: Wire the TUI init path to seed/update the palette state**

Keep the existing surface background setup working while exposing palette data for shimmer.

- [ ] **Step 3: Run the focused low-level tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/tui_core/test_shimmer.py -q`
Expected: still FAIL only where shimmer/spinner logic is not yet ported.

### Task 3: Port Codex shimmer and spinner into `tui_core`

**Files:**
- Create: `src/ralphception/tui_core/shimmer.py`
- Modify: `src/ralphception/tui_core/text.py`
- Modify: `src/ralphception/codex_tui/status.py`

- [ ] **Step 1: Implement the low-level shimmer helper**

Port the Codex algorithm directly:
- process-synchronized timing
- `padding = 10`
- `sweep_seconds = 2.0`
- `band_half_width = 5.0`
- truecolor and fallback style behavior

- [ ] **Step 2: Implement the low-level busy glyph helper**

Add a dedicated spinner helper and stop using shimmer for the `•`.

- [ ] **Step 3: Adapt the Codex-port status builder**

Make `src/ralphception/codex_tui/status.py` compose:
- low-level spinner glyph
- shimmered header text
- existing elapsed/interrupt/inline-message segments

- [ ] **Step 4: Run the focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_status.py tests/unit/tui_core/test_shimmer.py -q`
Expected: PASS

### Task 4: Verify against tmux and full suite

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py` if expectation updates are needed

- [ ] **Step 1: Compare the busy row against `~/code/codex` in tmux**

Check both dark and light terminal themes and confirm:
- comparable shimmer band
- separate leading glyph behavior
- no regressions to spacing/cursor behavior

- [ ] **Step 2: Run the full verification suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type and hygiene checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Merge and push**

Run:
```bash
git checkout main
git pull --ff-only
git merge --ff-only feat/tui-core-shimmer-parity
git push origin main
```

- [ ] **Step 5: Clean up**

Run:
```bash
git worktree remove .worktrees/feat-tui-core-shimmer-parity
git branch -d feat/tui-core-shimmer-parity
```
