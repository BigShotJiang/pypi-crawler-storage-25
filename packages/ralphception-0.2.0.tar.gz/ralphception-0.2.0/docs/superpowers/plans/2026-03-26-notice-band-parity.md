# Notice Band Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Render Ralphception startup notices as a Codex-style indented notice band instead of a flat left-edge paragraph.

**Architecture:** Introduce a shared notice-line renderer that wraps markdown/plain text at a reduced content width and reapplies a two-space notice indent to every rendered line. Use that renderer in both the live startup shell and the committed startup shell history cell so launch-time and post-flush views stay aligned.

**Tech Stack:** Python, Codex TUI port, ANSI terminal renderer, pytest unit/tmux integration tests

---

### Task 1: Lock the startup notice-band mismatch in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Add a live-shell notice regression**

Assert that startup notice lines render with a two-space indent in the live `ChatWidget`.

- [ ] **Step 2: Add a committed-history notice regression**

Assert that `StartupShellHistoryCell` uses the same indented notice rendering after the startup shell is flushed into history.

- [ ] **Step 3: Run targeted tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: failures showing notice lines still render flush-left.

### Task 2: Share notice rendering between live and committed startup shells

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/history_cell.py`

- [ ] **Step 1: Add a shared notice-line renderer**

Wrap notice content at the available width minus the notice indent, then prefix each visible line with two spaces.

- [ ] **Step 2: Apply it to the live startup shell**

Update `ChatWidget.render_lines()` so `notice_lines` render through the new helper.

- [ ] **Step 3: Apply it to committed startup history**

Update `StartupShellHistoryCell.display_lines()` so flushed startup notices use the same helper.

### Task 3: Verify tmux startup parity

**Files:**
- No code changes required

- [ ] **Step 1: Run focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: pass

- [ ] **Step 2: Re-run a fresh tmux startup comparison**

Verify that the Ralphception startup tip now sits in an indented notice band more like Codex’s tip/warning stack.

### Task 4: Full verification and merge

**Files:**
- No code changes required

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: all tests pass

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 3: Run diff check**

Run: `git diff --check`

Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/markdown_render.py src/ralphception/codex_tui/chatwidget.py src/ralphception/codex_tui/history_cell.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_history_cell.py docs/superpowers/plans/2026-03-26-notice-band-parity.md
git commit -m "fix: render startup notices as a notice band"
```
