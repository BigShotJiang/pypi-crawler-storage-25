# Markdown Link Destination Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Match Codex’s transcript behavior for non-local markdown links by appending the destination in parentheses instead of showing only the label.

**Architecture:** Keep the current markdown renderer and link tokenization, but treat local and non-local links differently the same way Codex does. Local paths remain code-like path text; non-local links render the label plus a styled ` (destination)` suffix.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the non-local link gap in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Write failing tests for non-local link destination rendering**

Add tests that assert:
- a web/app link renders the label plus ` (destination)`
- the destination itself is styled as a link
- local file links do not pick up that suffix

- [ ] **Step 2: Run the markdown-render tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL because the current renderer only shows the label for non-local links.

- [ ] **Step 3: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_markdown_render.py
git commit -m "test: pin codex link destination parity"
```

### Task 2: Implement non-local link destination rendering

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Test: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Re-run the failing markdown tests before coding**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL

- [ ] **Step 2: Implement the minimal link rendering change**

Update the renderer so that:
- local file links keep the current code-like target rendering
- non-local links render `label (destination)` with the destination styled as a link

- [ ] **Step 3: Run the markdown-render tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: PASS

- [ ] **Step 4: Commit the implementation**

```bash
git add src/ralphception/codex_tui/markdown_render.py tests/unit/codex_tui/test_markdown_render.py
git commit -m "feat: show codex tui link destinations"
```

### Task 3: Verify and merge

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Add transcript-level regression coverage**

Add an assistant-history test that proves non-local links render with the destination suffix through the transcript path.

- [ ] **Step 2: Run focused regression coverage**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: PASS

- [ ] **Step 3: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/markdown-link-destination-parity
git push origin main
git worktree remove .worktrees/feat-markdown-link-destination-parity
git branch -d feat/markdown-link-destination-parity
```
