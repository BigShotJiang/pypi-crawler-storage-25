# Composer Surface Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception's committed user rows and live composer surface look materially closer to Codex in tmux by adding styled surface backgrounds and preserving readable footer/composer contrast.

**Architecture:** Extend the Python styled-text layer to support background colors, then apply that surface styling in the two places Codex uses it most visibly: committed user history cells and the bottom-pane composer block. Keep the terminal insertion/rendering model unchanged so this slice is visual only and does not reopen the startup-scrollback bug.

**Tech Stack:** Python, ANSI SGR styling, pytest

---

### Task 1: Add Background-Style Support To Styled Text

**Files:**
- Modify: `src/ralphception/codex_tui/styled_text.py`
- Test: `tests/unit/codex_tui/test_styled_text.py`

- [ ] **Step 1: Write the failing tests**

Add tests covering:
- background-color SGR emission
- padded lines preserving the requested background style across the full width

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q`
Expected: FAIL because background styling is not supported yet

- [ ] **Step 3: Write minimal implementation**

Implement `bg` support in `Style`, ANSI background mappings, and any padding helpers needed so full-width surfaces can stay styled.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/codex_tui/styled_text.py tests/unit/codex_tui/test_styled_text.py
git commit -m "feat: add codex tui surface background styling"
```

### Task 2: Style Committed User Rows Like Codex

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Write the failing test**

Add a test that asserts `UserHistoryCell.display_lines()` includes the surface background style on its blank spacer row and wrapped message rows.

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py -q`
Expected: FAIL because user rows are still flat/dim-only text

- [ ] **Step 3: Write minimal implementation**

Port a simplified version of Codex's `user_message_style` concept into the Python history-cell rendering path.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/codex_tui/history_cell.py tests/unit/codex_tui/test_history_cell.py
git commit -m "feat: style committed user rows in codex tui"
```

### Task 3: Style The Live Composer Surface

**Files:**
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Test: `tests/unit/codex_tui/test_chatwidget.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Write the failing tests**

Add tests asserting:
- the live composer line uses the surface background when idle
- the spacer row under the composer stays on the same surface
- tmux startup capture still shows the placeholder plus footer, but now with ANSI background styling present

- [ ] **Step 2: Run test to verify it fails**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/integration/test_codex_tui_tmux.py -q`
Expected: FAIL because the composer currently renders as flat text without a surface background

- [ ] **Step 3: Write minimal implementation**

Apply the same surface style to the live composer row and spacer row, while preserving existing footer/waiting-line behavior.

- [ ] **Step 4: Run test to verify it passes**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/integration/test_codex_tui_tmux.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/codex_tui/bottom_pane.py src/ralphception/codex_tui/status.py tests/unit/codex_tui/test_chatwidget.py tests/integration/test_codex_tui_tmux.py
git commit -m "feat: style live composer surface in codex tui"
```

### Task 4: Verify End-To-End Tmux Parity For This Slice

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-composer-surface-parity.md`

- [ ] **Step 1: Run the focused suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui tests/integration/test_codex_tui_tmux.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py -q`
Expected: PASS

- [ ] **Step 2: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run typecheck and whitespace verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Run tmux comparison against Codex**

Use fresh tmux sessions to compare:
- `codex`
- `uv run ralphception`

Verify that:
- startup shell still renders correctly
- first prompt still avoids the blank slab regression
- committed user rows and the live composer surface now look materially closer to Codex

- [ ] **Step 5: Commit**

```bash
git add docs/superpowers/plans/2026-03-26-composer-surface-parity.md
git commit -m "docs: record composer surface parity verification"
```
