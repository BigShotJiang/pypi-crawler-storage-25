# Real Cursor Anchor Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the Codex-led Ralphception human TUI anchor its startup viewport like `~/code/codex` in tmux so the first shell frame starts near the top of the visible area instead of rendering a giant blank region with a sticky header.

**Architecture:** Port Codex's startup cursor-anchor behavior more faithfully by making the Python ANSI backend try a real cursor-position query first and fall back safely to origin when the terminal does not answer. Pin the visible startup behavior with focused unit and tmux integration tests before changing the terminal implementation so the fix targets the real root cause instead of post-hoc layout symptoms.

**Tech Stack:** Python 3.12, pytest, tmux, ANSI terminal control sequences, Ralphception Codex TUI port

---

### Task 1: Pin the Broken Startup Anchor

**Files:**
- Modify: `tests/unit/codex_tui/test_tui.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a unit test for startup cursor anchoring**

Add a test that constructs `Tui(terminal=CustomTerminal.with_options(_FakeBackend(cursor_position=Position(x=0, y=0))))` and verifies the first draw keeps the viewport at the top instead of inventing a bottom-row anchor.

- [ ] **Step 2: Add an integration assertion for the first interactive screen**

Extend the tmux-facing startup test so it asserts the initial idle shell is rendered near the top of the screen buffer rather than after a tall blank gap.

- [ ] **Step 3: Run the focused tests and verify RED**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_tui.py tests/integration/test_codex_tui_tmux.py -q
```

Expected: FAIL on the new startup-anchor assertions.

### Task 2: Implement Real Cursor Discovery

**Files:**
- Modify: `src/ralphception/codex_tui/tui.py`
- Modify: `src/ralphception/codex_tui/custom_terminal.py`

- [ ] **Step 1: Implement a real ANSI cursor-position query in `AnsiBackend.get_cursor_position()`**

Use the terminal CPR sequence (`ESC[6n`) to query the current cursor position from the active terminal, parse the response, and convert it into a zero-based `Position`.

- [ ] **Step 2: Add safe fallback behavior**

If CPR fails, times out, or the terminal is not usable, fall back to `Position(x=0, y=0)` so startup stays usable in PTYs that do not answer the query, matching Codex's safe-default behavior.

- [ ] **Step 3: Preserve resize/draw assumptions**

Keep the rest of `Tui.draw()` and `CustomTerminal.with_options()` compatible with the new cursor source so existing scrollback and viewport tests still pass.

- [ ] **Step 4: Run the focused tests and verify GREEN**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_tui.py tests/integration/test_codex_tui_tmux.py -q
```

Expected: PASS.

### Task 3: Verify Live tmux Parity Against Codex

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Launch fresh tmux compare sessions**

Run `codex` and `uv run ralphception` in separate fresh tmux sessions rooted in fresh repos and capture the startup shell plus the first prompt / first Socratic turn.

- [ ] **Step 2: Confirm the user-visible parity target**

Verify Ralphception now matches Codex materially better on:
- startup shell anchored near the top
- no giant blank region above the header
- no sticky header artifact after first prompt
- committed first prompt and follow-up render cleanly without screen corruption

- [ ] **Step 3: Save any additional regression assertions if the live check exposes a second deterministic bug**

Only add a second regression if the live tmux check reveals a repeatable, code-local issue directly adjacent to the cursor-anchor fix.

### Task 4: Full Verification, Merge, and Cleanup

**Files:**
- No additional product files required unless the live parity check identifies one nearby deterministic defect.

- [ ] **Step 1: Run the full automated verification suite**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
git diff --check
```

Expected: all pass cleanly.

- [ ] **Step 2: Merge the worktree branch to `main` and push**

Use non-interactive git commands only after verification passes.

- [ ] **Step 3: Remove the feature worktree and branch**

Leave the repository with a single clean `main` worktree synced to `origin/main`.
