# Cursor Row Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix the Codex-style Ralphception TUI so the terminal cursor tracks the actual composer row when header and notice content exist above the bottom pane.

**Architecture:** `ChatWidget` will expose a small internal layout helper that returns both the full rendered line list and the row offset where the bottom pane begins. Cursor placement will use that offset instead of assuming the bottom pane starts at the top of the viewport.

**Tech Stack:** Python 3.12, pytest

---

### Task 1: Pin The Cursor Bug In Tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`

- [ ] **Step 1: Add a failing regression test**

Assert that a widget with header, notice lines, and a bottom pane returns a cursor row aligned to the composer line rather than viewport row 0.

- [ ] **Step 2: Run the focused test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py -q`

Expected: FAIL before the fix.

### Task 2: Fix The Layout Origin

**Files:**
- Modify: `src/ralphception/codex_tui/chatwidget.py`

- [ ] **Step 1: Add a layout helper**

Return both:
- the rendered lines
- the bottom-pane starting row index

- [ ] **Step 2: Update cursor placement**

Compute cursor row from `area.y + vertical_offset + bottom_pane_start`.

- [ ] **Step 3: Re-run focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

### Task 3: Verify And Land

**Files:**
- Modify: `docs/superpowers/specs/2026-03-26-cursor-row-parity-design.md`
- Modify: `docs/superpowers/plans/2026-03-26-cursor-row-parity.md`

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

- [ ] **Step 2: Run static verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

- [ ] **Step 3: Run diff hygiene**

Run: `git diff --check`

- [ ] **Step 4: Merge and push**

Run:
- `git commit -m "fix: align codex tui cursor with bottom pane"`
- `git checkout main`
- `git merge --ff-only feat/cursor-viewport-parity`
- `git push origin main`
