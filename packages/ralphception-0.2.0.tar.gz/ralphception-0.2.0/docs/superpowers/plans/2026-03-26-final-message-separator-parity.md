# Final Message Separator Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the Codex-style divider Ralphception should render before a final assistant summary after a turn that did concrete work.

**Architecture:** Port a small `FinalMessageSeparator` history cell into the Python Codex TUI and teach `RalphAdapter` to insert it only when command/tool work occurred since the last user turn. Keep purely conversational turns unchanged.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the missing separator in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add a failing history-cell test for the divider line**

Add coverage that a `FinalMessageSeparator` renders a full-width dim divider row.

- [ ] **Step 2: Add a failing adapter test for work-then-summary behavior**

Add coverage that:
- a user message
- followed by a command turn
- followed by a final assistant summary

produces committed history in this order:
- user message
- command history
- final separator
- assistant summary

- [ ] **Step 3: Run focused tests to verify failure**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: FAIL because the Python port does not yet emit a separator cell.

### Task 2: Implement the separator port

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`
- Test: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Re-run the focused tests before coding**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: FAIL

- [ ] **Step 2: Implement the minimal separator behavior**

Update the port so that:
- `FinalMessageSeparator` renders a dim `─` rule across the viewport width
- `RalphAdapter` tracks whether concrete work happened in the current turn
- `AssistantFinalEvent` inserts the separator before the committed assistant cell when appropriate
- user turns reset that separator state

- [ ] **Step 3: Run the focused tests to verify they pass**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: PASS

### Task 3: Verify, merge, and clean up

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-final-message-separator-parity.md`

- [ ] **Step 1: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- diff-check is clean

- [ ] **Step 2: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/final-message-separator-parity
git push origin main
git worktree remove .worktrees/feat-final-message-separator-parity
git branch -d feat/final-message-separator-parity
```
