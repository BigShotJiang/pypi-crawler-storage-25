# Loading Shell History Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve the post-trust `model: loading` shell in terminal scrollback so Ralphception matches Codex’s trust-to-loading-to-idle handoff in tmux.

**Architecture:** Reuse the existing startup-shell history cell path instead of introducing another viewport trick. The loading shell should be emitted through `tui.insert_history_lines(...)` with transcript height zero, then the final idle shell can redraw live underneath it.

**Tech Stack:** Python 3.13, pytest, tmux capture probes, Ralphception Codex TUI port

---

### Task 1: Lock The Loading-Shell History Contract In Tests

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add a failing test that the trust handoff inserts loading shell lines through the history path**

```python
def test_render_idle_shell_inserts_loading_shell_into_history(monkeypatch, tmp_path):
    frontend = ScriptedCodexTuiFrontend(...)
    inserted = []
    monkeypatch.setattr(frontend.tui, "insert_history_lines", inserted.extend)

    frontend.render_idle_shell(include_loading_transition=True)

    assert any("model:     loading   /model to change" in strip_ansi(line) for line in inserted)
```

- [ ] **Step 2: Add a failing trust-flow assertion that the loading shell is preserved before the final shell**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -k loading_shell -q`

Expected: FAIL because the current implementation only repaints the loading shell live.

### Task 2: Emit The Loading Shell Through Committed History

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/history_cell.py` if a helper export is needed

- [ ] **Step 1: Build the loading shell as a zero-transcript history cell**

```python
loading_cell = StartupShellHistoryCell(
    version=self.adapter._cli_version,
    directory_label=self.adapter._directory_label,
    model_label="loading",
)
```

- [ ] **Step 2: Insert its display lines into terminal history before the final redraw**

```python
width = max(1, tui.terminal.size().width)
tui.insert_history_lines(loading_cell.display_lines(width))
self._redraw()
```

- [ ] **Step 3: Keep the live final shell unchanged**

```python
def render_idle_shell(self, *, include_loading_transition: bool = False) -> None:
    if include_loading_transition:
        self._render_loading_shell_history()
    self._redraw()
```

- [ ] **Step 4: Run the focused loading-shell tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -k loading_shell -q`

Expected: PASS

### Task 3: Verify The Real Tmux Trust Handoff

**Files:**
- No additional code changes expected

- [ ] **Step 1: Re-run a fresh tmux probe on the worktree build**

Run:

```bash
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py create --name ralph-loading-verify --cwd <tmp-repo>
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py step --target ralph-loading-verify:0.0 --text "uv run --project /Users/shayne/code/ralphception/.worktrees/feat-loading-shell-parity ralphception" --enter --sleep-ms 3200 --lines 320
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py step --target ralph-loading-verify:0.0 --text "1" --enter --sleep-ms 1500 --lines 320
```

Expected: capture shows trust prompt, then a `model:     loading   /model to change` shell in scrollback, then the final startup shell below it.

- [ ] **Step 2: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 3: Run typecheck and diff hygiene**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/app.py \
        tests/integration/test_codex_tui_tmux.py \
        docs/superpowers/plans/2026-03-26-loading-shell-history-parity.md
git commit -m "fix: preserve loading shell in history"
```
