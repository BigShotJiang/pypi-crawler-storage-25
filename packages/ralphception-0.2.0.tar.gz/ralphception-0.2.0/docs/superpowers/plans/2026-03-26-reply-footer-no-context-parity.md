# 2026-03-26 Reply Footer No-Context Parity

## Goal

Make the blocker/reply footer behave more like Codex request-user-input mode by
letting the answer tips own the footer row instead of sharing it with the
passive `100% context left` status.

## Reference

Codex `bottom_pane/request_user_input/*` renders wrapped footer tips for the
answer flow and does not keep a right-side context label in that mode.

## Plan

1. Add a failing test that proves reply/footer state does not render
   `100% context left`.
2. Update the Ralphception blocker-footer path to suppress the passive context
   label while awaiting an answer.
3. Re-run focused footer/adapter tests and a tmux capture for the first prompt.
4. Re-run the full suite and typecheck.
5. Merge to `main`, push, and remove the feature worktree.
