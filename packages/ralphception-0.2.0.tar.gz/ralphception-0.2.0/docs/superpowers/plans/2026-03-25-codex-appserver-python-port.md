# Codex App-Server TUI Python Port Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Ralphception's current broken human terminal frontend with a Python port of the Codex `tui_app_server` terminal architecture while keeping `ralphception exec` as the non-interactive path.

**Architecture:** Port the Codex TUI layers in order: custom terminal, scrollback insertion, history cells, chat widget render tree, app loop, then a Ralphception adapter that maps runtime frontend events into Codex-style transcript and bottom-pane state. The shipped human path should route through the new package only after the core terminal and transcript semantics match Codex in tmux.

**Tech Stack:** Python 3.12, ANSI terminal control, tmux-based integration verification, existing Ralphception runtime/frontend event contracts, targeted pytest integration tests.

---

## File Structure

### New files

- `src/ralphception/codex_tui/__init__.py`
  Human TUI package exports.
- `src/ralphception/codex_tui/custom_terminal.py`
  Python port of Codex custom terminal state and buffer/viewport management.
- `src/ralphception/codex_tui/insert_history.py`
  Python port of Codex scroll-region history insertion above the viewport.
- `src/ralphception/codex_tui/tui.py`
  Terminal initialization, draw loop, alt-screen transitions, and pending history queue.
- `src/ralphception/codex_tui/history_cell.py`
  Transcript cell base contract and Ralphception-specific committed cell types.
- `src/ralphception/codex_tui/markdown_render.py`
  Markdown-to-display-lines renderer for committed assistant content.
- `src/ralphception/codex_tui/bottom_pane.py`
  Composer, footer, waiting line, blocker hints, and cursor logic.
- `src/ralphception/codex_tui/chatwidget.py`
  Active cell, committed cells, bottom-pane composition, desired height, cursor position.
- `src/ralphception/codex_tui/status.py`
  Model/path/token status helpers used by the bottom pane and session header.
- `src/ralphception/codex_tui/ralph_adapter.py`
  Maps `FrontendEvent` values into committed cells, active cell updates, and bottom-pane state.
- `src/ralphception/codex_tui/app.py`
  Top-level app loop that connects terminal events, adapter events, redraws, and overlays.
- `tests/unit/codex_tui/test_custom_terminal.py`
- `tests/unit/codex_tui/test_insert_history.py`
- `tests/unit/codex_tui/test_history_cell.py`
- `tests/unit/codex_tui/test_ralph_adapter.py`
- `tests/integration/test_codex_tui_app.py`
- `tests/integration/test_codex_tui_tmux.py`

### Files to modify

- `src/ralphception/app.py`
  Rewire `run_app()` to use the new Codex-led human TUI path.
- `src/ralphception/runtime/terminal.py`
  Make this a thin wrapper around the new human TUI runtime path only if still needed.
- `src/ralphception/runtime/frontends.py`
  Tighten event shapes where the adapter needs stable fields for committed transcript cells.
- `src/ralphception/headless.py`
  Remove or normalize noisy events that should become clean transcript cells in the new adapter.
- `src/ralphception/runtime/supervisor.py`
  Ensure startup/review/resume prompt events fit the new committed-cell plus live-blocker contract.

### Files to demote or remove from the shipped human path

- `src/ralphception/runtime/codex_terminal.py`
- `src/ralphception/runtime/inline_shell.py`
- `src/ralphception/tui/app.py`
- `src/ralphception/tui/runtime_adapter.py`
- `src/ralphception/tui/chatwidget/*`
- `src/ralphception/tui/bottom_pane/*`

## Task 1: Port The Terminal Core

**Files:**
- Create: `src/ralphception/codex_tui/__init__.py`
- Create: `src/ralphception/codex_tui/custom_terminal.py`
- Create: `src/ralphception/codex_tui/insert_history.py`
- Create: `src/ralphception/codex_tui/tui.py`
- Test: `tests/unit/codex_tui/test_custom_terminal.py`
- Test: `tests/unit/codex_tui/test_insert_history.py`

- [ ] **Step 1: Write the failing terminal-core tests**

Add tests for:
- viewport initialization from cursor row
- viewport resize/update behavior
- pending-history insertion above the viewport
- cursor restoration after history insertion
- visible-history-row accounting

- [ ] **Step 2: Run the new terminal-core tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py -q`
Expected: FAIL with missing module/import errors

- [ ] **Step 3: Port `custom_terminal` from Codex**

Implement:
- terminal state object with `viewport_area`
- cursor tracking
- resize/autoresize hooks
- viewport setters
- history row accounting

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/custom_terminal.rs`

- [ ] **Step 4: Port `insert_history` from Codex**

Implement:
- scroll region control
- wrapped line insertion above the viewport
- lower-region adjustment when viewport is not at the bottom
- cursor restoration after insertion

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/insert_history.rs`

- [ ] **Step 5: Port `tui.py` draw orchestration**

Implement:
- terminal init
- raw mode setup/restore
- pending-history queue
- `draw(height, draw_fn)` behavior
- viewport resizing before draw

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/tui.rs`

- [ ] **Step 6: Re-run the terminal-core tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py -q`
Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add src/ralphception/codex_tui/__init__.py src/ralphception/codex_tui/custom_terminal.py src/ralphception/codex_tui/insert_history.py src/ralphception/codex_tui/tui.py tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py
git commit -m "feat: port codex terminal core"
```

## Task 2: Port Transcript Cells And Markdown Rendering

**Files:**
- Create: `src/ralphception/codex_tui/history_cell.py`
- Create: `src/ralphception/codex_tui/markdown_render.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Write the failing history-cell tests**

Cover:
- assistant markdown renders into wrapped logical lines
- command cells expose transcript lines and desired height
- waiting/blocker/system/user cells render stable line output
- transcript height counts wrapped rows correctly

- [ ] **Step 2: Run the new history-cell tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py -q`
Expected: FAIL with missing module/import errors

- [ ] **Step 3: Port the `HistoryCell` contract and basic cell types**

Reference:
- `/Users/shayne/code/codex/codex-rs/tui/src/history_cell.rs`

Implement:
- cell protocol/base class
- `display_lines(width)`
- `transcript_lines(width)`
- `desired_height(width)`
- `desired_transcript_height(width)`

- [ ] **Step 4: Port markdown rendering**

Reference:
- `/Users/shayne/code/codex/codex-rs/tui/src/markdown_render.rs`

Implement width-aware markdown formatting for assistant/system cells.

- [ ] **Step 5: Re-run the history-cell tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/codex_tui/history_cell.py src/ralphception/codex_tui/markdown_render.py tests/unit/codex_tui/test_history_cell.py
git commit -m "feat: port codex transcript cells"
```

## Task 3: Port ChatWidget And Bottom Pane

**Files:**
- Create: `src/ralphception/codex_tui/bottom_pane.py`
- Create: `src/ralphception/codex_tui/status.py`
- Create: `src/ralphception/codex_tui/chatwidget.py`
- Test: `tests/integration/test_codex_tui_app.py`

- [ ] **Step 1: Write the failing chat-widget integration tests**

Cover:
- committed cells stay out of the live viewport once inserted
- active cell remains live in the viewport
- bottom pane anchors composer at the bottom
- desired viewport height changes with active content and bottom pane
- cursor position follows the composer

- [ ] **Step 2: Run the new integration tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_app.py -q`
Expected: FAIL with missing module/import errors

- [ ] **Step 3: Port bottom-pane primitives from Codex**

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/bottom_pane/*`

Implement only the shipped human-shell subset:
- composer
- footer/status line
- waiting indicator
- blocker prompt surface
- shortcut/help hints needed for parity

- [ ] **Step 4: Port `ChatWidget` render-tree behavior**

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`

Implement:
- committed cells collection
- mutable active cell
- bottom-pane composition
- `desired_height(width)`
- `cursor_pos(area)`
- transcript overlay cache hooks if needed for `Ctrl+T`

- [ ] **Step 5: Re-run the chat-widget integration tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_app.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/codex_tui/bottom_pane.py src/ralphception/codex_tui/status.py src/ralphception/codex_tui/chatwidget.py tests/integration/test_codex_tui_app.py
git commit -m "feat: port codex chat widget"
```

## Task 4: Build The Ralphception Event Adapter

**Files:**
- Create: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Test: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Write the failing adapter tests**

Cover mapping for:
- startup prompt / Socratic intake prompt
- assistant deltas and finals
- command begin/output/end
- artifact writes
- loop launch/completion
- waiting states
- review/blocker prompts
- settled completion lines

- [ ] **Step 2: Run the adapter tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py -q`
Expected: FAIL with missing module/import errors

- [ ] **Step 3: Implement the adapter**

Translate `FrontendEvent` values into:
- committed history cells
- active-cell updates
- bottom-pane waiting/blocker state
- durable milestone rows

- [ ] **Step 4: Tighten event producers only where required**

Modify runtime event emitters only if the adapter cannot distinguish:
- noisy reasoning vs transcript-worthy output
- blocker prompts vs normal system notices
- artifact writes vs controller telemetry

- [ ] **Step 5: Re-run the adapter tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/codex_tui/ralph_adapter.py src/ralphception/runtime/frontends.py src/ralphception/headless.py src/ralphception/runtime/supervisor.py tests/unit/codex_tui/test_ralph_adapter.py
git commit -m "feat: adapt ralphception events to codex tui"
```

## Task 5: Rewire The Shipped Human Path

**Files:**
- Create: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Write the failing human-path integration tests**

Cover:
- `uv run ralphception` launches the new Codex-led human TUI path
- `ralphception exec` still uses the non-interactive path
- first prompt begins Socratic intake
- default launch does not silently revive stale state

- [ ] **Step 2: Run the human-path integration tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`
Expected: FAIL with missing module/import errors or wrong frontend assertions

- [ ] **Step 3: Implement the top-level app loop**

Reference:
- `/Users/shayne/code/codex/codex-rs/tui_app_server/src/app.rs`

Wire:
- terminal events
- adapter events
- committed history insertion
- redraw scheduling
- overlay switching as needed

- [ ] **Step 4: Rewire `run_app()`**

Make the default human path use the new Codex TUI only.
Keep `exec` on the separate non-interactive path.

- [ ] **Step 5: Re-run the human-path integration tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/codex_tui/app.py src/ralphception/app.py src/ralphception/runtime/terminal.py tests/integration/test_codex_tui_tmux.py
git commit -m "feat: ship codex-led human tui"
```

## Task 6: End-To-End tmux Parity Verification

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Extend end-to-end tests for real parity**

Add scripted checks for:
- committed history scrolling above the viewport
- anchored composer during loop execution
- artifact write milestones in scrollback
- loop launch/completion lines
- review/blocker prompt visibility
- completion settling explicitly

- [ ] **Step 2: Run the targeted parity tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_terminal_frontend.py -q`
Expected: PASS

- [ ] **Step 3: Run a real tmux smoke against Codex and Ralphception**

Run both in fresh tmux panes and compare:

```bash
tmux new-session -d -s codex_ref 'cd /tmp && codex'
tmux new-session -d -s ralph_ref 'cd /Users/shayne/code/ralphception/.worktrees/feat-codex-appserver-python-port && uv run ralphception'
```

Verify manually:
- anchored live viewport
- scrollback insertion
- first prompt path
- loop progress durability

- [ ] **Step 4: Commit**

```bash
git add tests/integration/test_codex_tui_tmux.py tests/integration/test_terminal_frontend.py
git commit -m "test: lock tmux codex parity"
```

## Task 7: Remove Legacy Human Frontends From The Hot Path

**Files:**
- Modify: `src/ralphception/runtime/codex_terminal.py`
- Modify: `src/ralphception/runtime/inline_shell.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_store.py`
- Test: `tests/unit tests/integration tests/e2e`

- [ ] **Step 1: Remove legacy frontend selection from the shipped path**

Keep imports/buildability only where needed for tests or transition shims.

- [ ] **Step 2: Delete or demote dead-path code**

Remove the legacy human UI code from the hot path once the new app is verified.

- [ ] **Step 3: Run the full suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 4: Run typecheck**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 5: Run diff hygiene**

Run: `git diff --check`
Expected: no output

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/codex_terminal.py src/ralphception/runtime/inline_shell.py src/ralphception/tui/app.py src/ralphception/tui/runtime_adapter.py src/ralphception/tui/chatwidget/transcript_store.py
git commit -m "refactor: retire legacy human frontends"
```

## Final Verification And Integration

- [ ] **Step 1: Run the full suite again**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 2: Run typecheck again**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 3: Re-run the real tmux smoke**

Verify the final branch against `codex` in fresh tmux sessions.

- [ ] **Step 4: Complete the branch with `superpowers:finishing-a-development-branch`**

Use the finishing workflow to merge, push, and clean up.
