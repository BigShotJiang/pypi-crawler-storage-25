# Startup History Shell Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception’s Codex TUI startup shell behave like Codex by treating the session header and startup notices as committed history from launch, instead of keeping them in the live viewport until the first prompt.

**Architecture:** Move startup shell chrome into a dedicated startup-history emission path. On initial launch, queue the startup header/notice cell into committed history, clear it from the live `ChatWidget`, and redraw only the active bottom pane. Keep the existing first-cell fallback so startup chrome still flushes correctly if a nonstandard path bypasses the initial emission.

**Tech Stack:** Python 3.12, ANSI escape sequences, tmux, pytest, Ralphception Codex TUI port

---

### Task 1: Pin the Startup-History Gap

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add a failing startup-shell regression**

Assert that after the frontend draws the initial shell:
- startup header/tip are already absent from the live `ChatWidget`
- they were still written to the terminal output

- [ ] **Step 2: Run focused tests and verify RED**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/unit/codex_tui/test_ralph_adapter.py -q
```

Expected: FAIL because the current startup shell is still rendered live before first prompt.

### Task 2: Emit Startup Shell as History at Launch

**Files:**
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/app.py`

- [ ] **Step 1: Add explicit startup-shell emission**

Create an adapter method that queues the startup history cell and clears header/notice state from the live widget.

- [ ] **Step 2: Call it from the initial interactive shell path**

When the frontend draws the initial idle shell, emit startup history first and then redraw the live bottom pane.

- [ ] **Step 3: Preserve first-cell fallback**

Keep the existing startup flush fallback so alternate code paths still transition safely without duplicate startup cells.

### Task 3: Live tmux Verification, Full Suite, Merge

- [ ] **Step 1: Re-run fresh tmux shell-launched captures**

Verify that `uv run ralphception` now behaves more like Codex:
- command line at top
- startup header/tip directly below it
- live bottom pane only, not a second live header block

- [ ] **Step 2: Run full verification**

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
git diff --check
```

- [ ] **Step 3: Merge to `main`, push, and continue**

Fast-forward `main`, push `origin/main`, and keep iterating on the next parity gap from the merged tree.
