# Styled Startup Shell Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the Codex startup-shell styling model into Ralphception’s Python TUI so the header, tip, composer prompt, and footer render with real ANSI styling and ANSI-aware width handling instead of flat plain strings.

**Architecture:** Add a small styled-line abstraction for the Python Codex TUI port, teach the terminal writer and history insertion code to trim/stabilize ANSI-styled lines by visible width, then migrate the startup-shell surfaces that the user sees first: session header, startup notice, composer line, and footer/status line. Keep scope intentionally narrow to startup-shell parity first; transcript-wide rich styling can layer on the same primitive later.

**Tech Stack:** Python 3.12, ANSI escape sequences, tmux, pytest, Ralphception Codex TUI port

---

### Task 1: Pin the Styling Gap

**Files:**
- Create: `tests/unit/codex_tui/test_styled_text.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add failing unit tests for ANSI-aware visible-width trimming**

Write tests for a new styled-line helper that prove:
- visible width ignores ANSI escape sequences
- trimming to width preserves escape codes and resets correctly
- cursor-position math uses visible width, not raw string length

- [ ] **Step 2: Add a failing startup-shell integration assertion**

Extend the scripted/startup-shell integration test to assert the rendered output contains ANSI styling for at least:
- the header title emphasis
- the `/model` hint coloring
- the starter prompt / placeholder row styling

- [ ] **Step 3: Run the focused tests and verify RED**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py tests/integration/test_codex_tui_tmux.py -q
```

Expected: FAIL because the current shell is still plain-string based.

### Task 2: Introduce Styled Lines

**Files:**
- Create: `src/ralphception/codex_tui/styled_text.py`
- Modify: `src/ralphception/codex_tui/custom_terminal.py`
- Modify: `src/ralphception/codex_tui/insert_history.py`

- [ ] **Step 1: Add a styled text primitive**

Create a focused module with:
- a small span type (`text` + style)
- a styled line type
- ANSI encoding helpers
- visible-width calculation
- ANSI-aware width trimming

- [ ] **Step 2: Teach the terminal renderer to accept styled lines**

Update the frame/terminal write path so viewport rendering can emit either plain strings or styled lines without corrupting layout width.

- [ ] **Step 3: Teach committed-history insertion to use the same ANSI-aware trimming**

Update history insertion so styled lines inserted above the viewport keep their visible width and do not leak truncated escape sequences.

- [ ] **Step 4: Run focused tests to verify GREEN for the primitive**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q
```

Expected: PASS.

### Task 3: Port Styled Startup-Shell Surfaces

**Files:**
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/history_cell.py`

- [ ] **Step 1: Port the session header card styling**

Migrate the header card rows so they can express Codex-like emphasis:
- dim `>_`
- bold app title
- dim version
- colored `/model`
- magenta `fast`

- [ ] **Step 2: Port the startup composer / placeholder styling**

Migrate the startup prompt row so the `›` prompt marker and placeholder text can be styled distinctly, instead of one flat monochrome string.

- [ ] **Step 3: Port the footer/status styling**

Migrate the compact footer/status row so model/context/path segments can be styled with Codex-like emphasis without breaking width alignment.

- [ ] **Step 4: Keep waiting/reply shells visually consistent**

Update the reply/waiting variants so the first-turn Socratic reply shell uses the same styled primitives and does not regress to plain text.

- [ ] **Step 5: Run focused startup-shell tests**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_codex_tui_app.py -q
```

Expected: PASS.

### Task 4: Live tmux Verification Against Codex

**Files:**
- No additional product files required unless the live tmux check exposes one adjacent deterministic defect.

- [ ] **Step 1: Launch fresh tmux compare sessions**

Run fresh `codex` and `uv run --project <worktree> ralphception` sessions in comparable repos and capture:
- startup idle shell
- first prompt
- first Socratic reply shell

- [ ] **Step 2: Verify the parity target**

Confirm the Ralphception shell is materially closer to Codex on:
- top-anchored startup shell
- visibly styled header/composer/footer
- no monochrome flat prompt line
- no layout corruption after the first prompt

- [ ] **Step 3: Only fix one adjacent deterministic issue if needed**

If live tmux exposes one nearby rendering defect directly caused by the styled-line port, fix it in this slice. Do not expand into transcript-wide rich styling yet.

### Task 5: Full Verification, Merge, and Cleanup

**Files:**
- No additional product files required unless Task 4 uncovers one adjacent deterministic defect.

- [ ] **Step 1: Run the full verification suite**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
git diff --check
```

Expected: all pass cleanly.

- [ ] **Step 2: Merge the verified branch onto `main` and push**

Use non-interactive git commands only after verification passes.

- [ ] **Step 3: Remove the feature worktree and branch**

Leave the repository with one clean `main` worktree synced to `origin/main`.
