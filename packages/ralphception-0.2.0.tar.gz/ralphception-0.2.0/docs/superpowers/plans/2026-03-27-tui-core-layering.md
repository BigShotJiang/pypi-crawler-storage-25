# TUI Core Layering Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extract a low-level `tui_core` layer for terminal/layout primitives, then port the Codex-style bottom pane onto it so spacing, cursor placement, and busy-state rendering match Codex more closely.

**Architecture:** Create a new `src/ralphception/tui_core/` package that owns terminal, text, status-indicator, composer, footer, and bottom-pane primitives. Keep `src/ralphception/codex_tui/` as the higher-level Codex-port UI layer, but make it compose the new core instead of recomputing layout/cursor behavior itself.

**Tech Stack:** Python 3.12/3.13, ANSI terminal rendering, pytest, tmux, existing Codex-port UI tests, `uv`, `ty`.

---

### Task 1: Lock the low-level parity seam in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_status.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a failing test for bottom-pane row order**

Assert the busy bottom pane renders:
- status row
- spacer row
- composer surface row
- footer row

- [ ] **Step 2: Add a failing test for cursor placement inside the composer surface**

Assert the cursor column/row lands inside the surfaced input row, not just at the text prefix position.

- [ ] **Step 3: Add a failing tmux-oriented layout expectation**

Update the Codex TUI integration expectations so narrow-width/busy layouts preserve breathing room and do not stack the live composer against history.

- [ ] **Step 4: Run the focused tests and verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_status.py tests/integration/test_codex_tui_tmux.py -q`
Expected: FAIL on the new spacing/cursor assertions.

### Task 2: Extract the low-level `tui_core` package

**Files:**
- Create: `src/ralphception/tui_core/__init__.py`
- Create: `src/ralphception/tui_core/terminal.py`
- Create: `src/ralphception/tui_core/text.py`
- Create: `src/ralphception/tui_core/status_indicator.py`
- Create: `src/ralphception/tui_core/footer.py`
- Create: `src/ralphception/tui_core/composer.py`
- Create: `src/ralphception/tui_core/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/custom_terminal.py`
- Modify: `src/ralphception/codex_tui/tui.py`

- [ ] **Step 1: Write the failing import/behavior test for the extracted terminal core**

Add or update a test proving `codex_tui` terminal behavior still uses the same top-anchor/viewport semantics after extraction.

- [ ] **Step 2: Run that test to verify it fails before the extraction**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_tui.py -q`
Expected: FAIL once the new test references the not-yet-extracted core seam.

- [ ] **Step 3: Extract terminal/text primitives into `tui_core`**

Move or delegate:
- viewport and frame logic
- cursor tracking
- ANSI-safe width/truncation helpers

Keep `codex_tui` compatibility wrappers thin.

- [ ] **Step 4: Re-run the focused terminal/text tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_tui.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: PASS

### Task 3: Port bottom-pane primitives onto `tui_core`

**Files:**
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`

- [ ] **Step 1: Introduce low-level composer/footer/status primitives**

Make `codex_tui` use `tui_core` objects for:
- status indicator
- footer layout
- composer surface
- bottom-pane cursor placement

- [ ] **Step 2: Implement Codex-style spacing and cursor alignment**

Ensure the live bottom pane uses:
- busy row
- spacer
- surfaced composer row with cursor inside the same visual surface
- footer row

- [ ] **Step 3: Re-run focused Codex TUI tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_status.py tests/integration/test_codex_tui_tmux.py -q`
Expected: PASS

### Task 4: Verify against tmux and full suite

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py` if final expectation adjustments are required

- [ ] **Step 1: Run a tmux comparison against `~/code/codex`**

Verify:
- startup shell placement
- busy/loading row spacing
- composer cursor alignment inside the surfaced input row
- narrow-width footer behavior

- [ ] **Step 2: Run the full verification suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

- [ ] **Step 3: Run type checks and diff hygiene**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Merge and push**

Run:
```bash
git checkout main
git pull --ff-only
git merge --ff-only feat/tui-core-layering
git push origin main
```

- [ ] **Step 5: Clean up**

Run:
```bash
git worktree remove .worktrees/feat/tui-core-layering
git branch -d feat/tui-core-layering
```
