# Chat Shell Product Cutover Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the chat shell the default Ralphception product UI, promote `exec` / `e` as the non-interactive entrypoint, and remove the old public multi-surface CLI split.

**Architecture:** Keep the durable runtime and non-interactive mission engine, but add a runtime-backed chat-shell controller that adapts current supervisor states into shell state. Replace the default `run_app()` launch path with the chat shell, promote the current terminal runner behind `run_exec(...)`, and collapse the public CLI onto `ralphception`, `ralphception exec` / `ralphception e`, and `ralphception resume`.

**Tech Stack:** Python 3.12+, `textual`, `typer`, existing `RuntimeSupervisor`, `StartupBootstrapController`, `ArtifactReviewController`, pytest

---

## Scope Check

This plan completes the product cutover described in the approved spec:

1. bind the chat shell to real runtime state
2. make the shell usable for bootstrap and review actions
3. promote `exec` / `e` as the public non-interactive path
4. remove `terminal`, `headless`, and `chat-shell` from the public CLI
5. rewrite README and tests around the new product contract

Do not redesign the durable runtime protocol in this plan. Use an adapter over the existing supervisor and controllers.

## Execution Notes

- Follow @superpowers:test-driven-development for every behavior change.
- Use @superpowers:verification-before-completion before each commit and at final handoff.
- Do not preserve public CLI compatibility for `terminal`, `headless`, or `chat-shell`.
- Keep `run_terminal(...)` as an internal implementation detail if it remains useful; the user-facing contract is what matters.

## File Map

- Create: `src/ralphception/chat_shell/runtime.py`
  Runtime-backed controller that maps supervisor state into `ShellState` and applies startup/review actions.
- Modify: `src/ralphception/chat_shell/state.py`
  Add runtime-backed overlay and summary models needed for startup and review flows.
- Modify: `src/ralphception/chat_shell/app.py`
  Add production `from_runtime(...)`, event refresh, and real user action handlers.
- Modify: `src/ralphception/chat_shell/widgets/bottom_pane.py`
  Replace the stub with startup and review controls driven by shell state.
- Modify: `src/ralphception/chat_shell/widgets/status_surface.py`
  Render real mission/thread/review status from runtime-backed state.
- Modify: `src/ralphception/chat_shell/widgets/transcript_view.py`
  Support runtime-generated transcript summaries for startup, review, and dashboard states.
- Modify: `src/ralphception/app.py`
  Make `run_app()` launch the runtime-backed chat shell and add `run_exec(...)`.
- Modify: `src/ralphception/cli.py`
  Collapse the public CLI to default shell launch, `exec` / `e`, and `resume`.
- Modify: `README.md`
  Rewrite product docs around the new contract.
- Modify: `tests/unit/test_cli_bootstrap.py`
  Assert the new command surface and removed commands.
- Create: `tests/unit/test_chat_shell_runtime.py`
  Unit tests for runtime-to-shell state projection and actions.
- Modify: `tests/integration/test_chat_shell_app.py`
  Replace fixture-only coverage with runtime-backed startup/review shell tests.
- Modify: `tests/e2e/test_core_runtime.py`
  Update public-entrypoint assertions from legacy TUI/terminal naming to shell/exec naming.

## Chunk 1: Runtime-Backed Shell State

### Task 1: Add a runtime-backed chat shell controller

**Files:**
- Create: `src/ralphception/chat_shell/runtime.py`
- Modify: `src/ralphception/chat_shell/state.py`
- Test: `tests/unit/test_chat_shell_runtime.py`

- [ ] **Step 1: Write the failing runtime-shell unit tests**

```python
from pathlib import Path

from ralphception.chat_shell.runtime import RuntimeShellController
from ralphception.ui.screens.startup import StartupBootstrapController


def test_runtime_shell_controller_maps_startup_prompt_to_startup_overlay(tmp_path: Path) -> None:
    controller = RuntimeShellController(repo_root=tmp_path)

    state = controller.load_state()

    assert state.overlay is not None
    assert state.overlay.kind == "startup"
    assert "Seed prompt required" in state.transcript[0].text


def test_runtime_shell_controller_bootstraps_workspace_from_startup_submission(tmp_path: Path) -> None:
    controller = RuntimeShellController(repo_root=tmp_path)

    state = controller.submit_startup(
        seed_prompt="find any bugs",
        source_repos_text="/tmp/source-a\n/tmp/source-b",
    )

    record = StartupBootstrapController(tmp_path).needs_bootstrap()
    assert record is False
    assert state.status.phase in {"review_prompt", "dashboard"}
```

- [ ] **Step 2: Run the runtime-shell tests to verify they fail**

Run: `uv run pytest tests/unit/test_chat_shell_runtime.py -q`
Expected: FAIL because `RuntimeShellController` and `startup` overlay support do not exist.

- [ ] **Step 3: Write the minimal runtime-shell implementation**

Implement in `state.py`:

- `StartupOverlay`
- `ReviewActionState` if needed for button rendering
- optional summary fields to represent dashboard state cleanly

Implement in `runtime.py`:

- `RuntimeShellController`
- `load_state()`
- `submit_startup(...)`
- `apply_review_action(...)`
- helper mapping from `RuntimeSupervisor.step()` and `ArtifactReviewController` into `ShellState`
- preserve `_advance_workspace_engine(...)` behavior before rendering dashboard state

Keep this adapter simple and deterministic. It is a bridge over the current runtime, not the long-term protocol rewrite.

- [ ] **Step 4: Run the runtime-shell tests to verify they pass**

Run: `uv run pytest tests/unit/test_chat_shell_runtime.py -q`
Expected: PASS

- [ ] **Step 5: Commit the runtime-shell controller**

```bash
git add src/ralphception/chat_shell/runtime.py src/ralphception/chat_shell/state.py tests/unit/test_chat_shell_runtime.py
git commit -m "feat: add runtime-backed chat shell controller"
```

## Chunk 2: Real Shell Interactions

### Task 2: Make the chat shell usable for startup and review

**Files:**
- Modify: `src/ralphception/chat_shell/app.py`
- Modify: `src/ralphception/chat_shell/widgets/bottom_pane.py`
- Modify: `src/ralphception/chat_shell/widgets/status_surface.py`
- Modify: `src/ralphception/chat_shell/widgets/transcript_view.py`
- Modify: `tests/integration/test_chat_shell_app.py`

- [ ] **Step 1: Write the failing runtime-backed shell integration tests**

```python
import asyncio
from pathlib import Path

from ralphception.chat_shell.app import ChatShellApp
from ralphception.chat_shell.widgets.bottom_pane import BottomPaneWidget
from ralphception.chat_shell.widgets.transcript_view import TranscriptView


def test_chat_shell_renders_real_startup_state(tmp_path: Path) -> None:
    app = ChatShellApp.from_runtime(tmp_path)

    async def exercise() -> tuple[str | None, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            bottom = app.query_one("#bottom-pane", BottomPaneWidget)
            transcript = app.query_one("#transcript-view", TranscriptView)
            return bottom.active_overlay_kind, transcript.rendered_text()

    overlay_kind, rendered = asyncio.run(exercise())
    assert overlay_kind == "startup"
    assert "Seed prompt required" in rendered


def test_chat_shell_submits_startup_form_and_leaves_startup_overlay(tmp_path: Path) -> None:
    app = ChatShellApp.from_runtime(tmp_path)

    async def exercise() -> str | None:
        async with app.run_test() as pilot:
            app.query_one("#startup-seed-prompt").load_text("find any bugs")
            app.query_one("#startup-source-repos").load_text("/tmp/source")
            await pilot.click("#startup-submit")
            await pilot.pause()
            bottom = app.query_one("#bottom-pane", BottomPaneWidget)
            return bottom.active_overlay_kind

    assert asyncio.run(exercise()) != "startup"
```

- [ ] **Step 2: Run the shell integration tests to verify they fail**

Run: `uv run pytest tests/integration/test_chat_shell_app.py -q`
Expected: FAIL because the chat shell is still fixture-only and the bottom pane is not interactive.

- [ ] **Step 3: Write the minimal real shell implementation**

Implement in `app.py`:

- `ChatShellApp.from_runtime(repo_root: Path, ...)`
- app-level refresh method driven by `RuntimeShellController`
- button handlers for startup and review actions

Implement in `bottom_pane.py`:

- startup form fields and submit button
- review action buttons derived from overlay state
- stable query ids used by tests

Implement in `transcript_view.py` and `status_surface.py`:

- rendering of runtime-backed transcript/system summary
- status text reflecting current supervisor phase and pending review count

- [ ] **Step 4: Run the shell integration tests to verify they pass**

Run: `uv run pytest tests/integration/test_chat_shell_app.py -q`
Expected: PASS

- [ ] **Step 5: Commit the production chat shell UI**

```bash
git add src/ralphception/chat_shell/app.py src/ralphception/chat_shell/widgets tests/integration/test_chat_shell_app.py
git commit -m "feat: make chat shell handle startup and review flows"
```

## Chunk 3: Public CLI Cutover

### Task 3: Make the shell the default product and promote `exec` / `e`

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Write the failing CLI tests for the new public contract**

```python
from unittest.mock import patch

import ralphception.app as runtime_app
from typer.testing import CliRunner

from ralphception.cli import app


def test_cli_without_subcommand_runs_chat_shell() -> None:
    with patch.object(runtime_app, "run_app") as run_app:
        result = CliRunner().invoke(app, [])

    assert result.exit_code == 0
    run_app.assert_called_once_with()


def test_cli_help_exposes_exec_but_not_terminal_or_headless() -> None:
    result = CliRunner().invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "exec" in result.stdout
    assert "terminal" not in result.stdout
    assert "headless" not in result.stdout
    assert "chat-shell" not in result.stdout


def test_cli_exec_alias_invokes_run_exec() -> None:
    with patch.object(runtime_app, "run_exec") as run_exec:
        result = CliRunner().invoke(app, ["e", "find any bugs", "--source-repo", "/tmp/source"])

    assert result.exit_code == 0
    run_exec.assert_called_once_with(
        repo_root=None,
        seed_prompt="find any bugs",
        source_repos=("/tmp/source",),
        resume=False,
        approve_all=False,
        approver="exec",
        use_fake_session_manager=False,
    )
```

- [ ] **Step 2: Run the CLI tests to verify they fail**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL because the old command surface is still public and `run_exec(...)` does not exist.

- [ ] **Step 3: Write the minimal CLI/app cutover implementation**

Implement in `app.py`:

- `run_app()` launches `ChatShellApp.from_runtime(Path.cwd(), ...)`
- `run_exec(...)` wraps the existing terminal execution path

Implement in `cli.py`:

- remove public `terminal`, `headless`, and `chat-shell` commands
- add `exec` command with visible alias `e`
- use positional prompt for `exec`
- keep `resume`

The internal `run_terminal(...)` helper may remain if tests or internal callers still use it.

- [ ] **Step 4: Run the CLI tests to verify they pass**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit the public cutover**

```bash
git add src/ralphception/app.py src/ralphception/cli.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: cut over CLI to shell and exec"
```

## Chunk 4: Product Docs and End-to-End Proof

### Task 4: Rewrite docs and end-to-end assertions for the new product

**Files:**
- Modify: `README.md`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write the failing doc/e2e assertions**

```python
def test_readme_references_exec_instead_of_terminal():
    readme = Path("README.md").read_text(encoding="utf-8")
    assert "uv run ralphception exec" in readme
    assert "uv run ralphception terminal" not in readme
```

Add/adjust an end-to-end assertion so the public contract is reflected in tests instead of the legacy naming.

- [ ] **Step 2: Run the targeted tests to verify they fail**

Run: `uv run pytest tests/e2e/test_core_runtime.py -q`
Expected: FAIL until README/test expectations are updated for the new contract.

- [ ] **Step 3: Update docs and end-to-end expectations**

Rewrite README sections so they describe:

- default interactive shell
- `exec` / `e` non-interactive execution
- `resume` as the explicit recovery command

Update end-to-end tests that name the old `terminal` product surface so they instead describe the non-interactive `exec` path while preserving the underlying runtime behavior.

- [ ] **Step 4: Run the targeted end-to-end tests to verify they pass**

Run: `uv run pytest tests/e2e/test_core_runtime.py -q`
Expected: PASS

- [ ] **Step 5: Run final cutover verification**

Run: `uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: PASS

Run: `uv run ty check src tests`
Expected: PASS

Run: `git diff --check`
Expected: no output

- [ ] **Step 6: Commit the docs and final cutover assertions**

```bash
git add README.md tests/e2e/test_core_runtime.py
git commit -m "docs: finalize chat shell product cutover"
```

## Plan Completion Criteria

This plan is complete when:

- the default `ralphception` entrypoint launches the runtime-backed chat shell
- startup and review flows are usable from the shell
- `ralphception exec` and `ralphception e` run the non-interactive mission path
- `terminal`, `headless`, and `chat-shell` are no longer public commands
- README and tests describe the new shell/exec product model
- the full test suite and type checks pass
