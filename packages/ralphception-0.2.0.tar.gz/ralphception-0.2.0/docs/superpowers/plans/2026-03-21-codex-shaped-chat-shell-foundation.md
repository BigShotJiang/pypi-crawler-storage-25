# Codex-Shaped Chat Shell Foundation Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first working slice of the greenfield rewrite: a new Codex-shaped protocol and fixture-driven chat shell that runs as an experimental `chat-shell` entrypoint.

**Architecture:** Introduce a new `ralphception.protocol` package for the unified runtime action/event contract and a new `ralphception.chat_shell` package for transcript state, event projection, and Textual rendering. Keep the current dashboard/startup/review architecture in place for now, but do not extend it; the new shell should launch independently from fixture scenarios so the team can validate Codex-like behavior before rebinding the real runtime.

**Tech Stack:** Python 3.12+, `pydantic`, `textual`, `typer`, existing `src/ralphception/testing/fakes.py`, `pytest`

---

## Scope Check

The approved spec is a full-program rewrite. This plan intentionally covers only the first implementation slice from the spec's "First Planning Scope":

1. define the unified runtime protocol
2. define shell view models and transcript cell types
3. build the first `ChatShellApp` skeleton
4. implement transcript, bottom pane, status surfaces, and overlay routing
5. support fixture-based mission and subagent streams

Do not pull real mission orchestration, approvals persistence, or worktree-backed subagent execution into this plan. Those belong in later plans once the shell spine exists.

## Execution Notes

- Follow @superpowers:test-driven-development for each task.
- Use @superpowers:verification-before-completion before every commit and again at the end of the plan.
- Do not modify `src/ralphception/ui/` unless a later plan explicitly calls for removal or migration.
- Keep the new shell in `src/ralphception/chat_shell/` and the new contract in `src/ralphception/protocol/` so the greenfield path stays obvious.

## File Map

- Create: `src/ralphception/protocol/__init__.py`
  Public exports for the new protocol package.
- Create: `src/ralphception/protocol/actions.py`
  Pydantic models for shell-to-runtime actions such as send message, switch thread, approve review, and apply recovery action.
- Create: `src/ralphception/protocol/events.py`
  Pydantic models for runtime-to-shell events such as transcript deltas, review requests, subagent lifecycle updates, and status changes.
- Create: `src/ralphception/chat_shell/__init__.py`
  Public exports for the experimental shell package.
- Create: `src/ralphception/chat_shell/state.py`
  Shell-facing view models: transcript cells, overlays, footer/header state, session navigation state, and the aggregate shell state container.
- Create: `src/ralphception/chat_shell/projector.py`
  Event projector that consumes protocol events and mutates shell state deterministically.
- Create: `src/ralphception/chat_shell/fixtures.py`
  Fixture protocol streams and a tiny in-memory protocol client for development and integration tests.
- Create: `src/ralphception/chat_shell/app.py`
  `ChatShellApp` composition root and fixture bootstrapping entrypoint.
- Create: `src/ralphception/chat_shell/widgets/__init__.py`
  Widget package exports.
- Create: `src/ralphception/chat_shell/widgets/transcript_view.py`
  Transcript viewport widget rendering committed and active cells.
- Create: `src/ralphception/chat_shell/widgets/bottom_pane.py`
  Bottom composer stub, footer hints, and overlay presentation shell for the first slice.
- Create: `src/ralphception/chat_shell/widgets/status_surface.py`
  Header/footer/status widgets for active mission, thread, and busy/review state.
- Create: `tests/unit/test_protocol_models.py`
  Unit tests for protocol action/event validation and discriminated unions.
- Create: `tests/unit/test_chat_shell_projector.py`
  Unit tests for event projection into transcript cells, overlays, and status state.
- Create: `tests/integration/test_chat_shell_app.py`
  Textual integration coverage for fixture-driven shell rendering and overlay transitions.
- Modify: `src/ralphception/app.py`
  Add a `run_chat_shell(...)` helper that launches the new shell from a fixture scenario without touching the existing default app flow.
- Modify: `src/ralphception/cli.py`
  Add an experimental `chat-shell` command with a `--fixture` option.
- Modify: `tests/unit/test_cli_bootstrap.py`
  Cover the new `chat-shell` command wiring.
- Modify: `README.md`
  Document the experimental `chat-shell --fixture ...` command so other contributors can run the new shell foundation.

## Chunk 1: Protocol Spine

### Task 1: Define the unified action/event contract

**Files:**
- Create: `src/ralphception/protocol/__init__.py`
- Create: `src/ralphception/protocol/actions.py`
- Create: `src/ralphception/protocol/events.py`
- Test: `tests/unit/test_protocol_models.py`

- [ ] **Step 1: Write the failing protocol model tests**

```python
import pytest
from pydantic import ValidationError

from ralphception.protocol.actions import ShellAction
from ralphception.protocol.events import RuntimeEvent


def test_review_requested_event_validates_required_fields() -> None:
    event = RuntimeEvent.model_validate(
        {
            "kind": "review_requested",
            "thread_id": "run-root",
            "review_kind": "execution_bundle",
            "title": "Execution bundle v2",
            "summary": "Execution bundle v2 is waiting for approval.",
            "actions": ["approve", "reject"],
        }
    )

    assert event.kind == "review_requested"
    assert event.review_kind == "execution_bundle"


def test_send_user_message_action_rejects_blank_message() -> None:
    with pytest.raises(ValidationError):
        ShellAction.model_validate(
            {
                "kind": "send_user_message",
                "thread_id": "run-root",
                "text": "   ",
            }
        )
```

- [ ] **Step 2: Run the protocol tests to verify they fail**

Run: `uv run pytest tests/unit/test_protocol_models.py -q`
Expected: FAIL because `ralphception.protocol` does not exist yet.

- [ ] **Step 3: Write the minimal protocol implementation**

Implement:

- discriminated-union `ShellAction` models in `actions.py`
- discriminated-union `RuntimeEvent` models in `events.py`
- small, explicit event payload shapes for:
  - transcript commit/delta
  - status update
  - review requested/resolved
  - request-user-input requested/resolved
  - subagent spawned/waiting/completed/failed/closed
  - session list update / active thread changed

Keep the first slice intentionally narrow. Do not model every future event now.

- [ ] **Step 4: Run the protocol tests to verify they pass**

Run: `uv run pytest tests/unit/test_protocol_models.py -q`
Expected: PASS

- [ ] **Step 5: Commit the protocol spine**

```bash
git add src/ralphception/protocol tests/unit/test_protocol_models.py
git commit -m "feat: add chat shell protocol models"
```

## Chunk 2: Shell State and Projection

### Task 2: Build shell view models and the event projector

**Files:**
- Create: `src/ralphception/chat_shell/__init__.py`
- Create: `src/ralphception/chat_shell/state.py`
- Create: `src/ralphception/chat_shell/projector.py`
- Create: `src/ralphception/chat_shell/fixtures.py`
- Test: `tests/unit/test_chat_shell_projector.py`

- [ ] **Step 1: Write the failing shell state/projector tests**

```python
from ralphception.chat_shell.projector import EventProjector
from ralphception.chat_shell.state import ShellState
from ralphception.protocol.events import RuntimeEvent


def test_projector_appends_subagent_cell_and_marks_thread_waiting() -> None:
    state = ShellState.empty()
    projector = EventProjector(state)

    projector.apply(
        RuntimeEvent.model_validate(
            {
                "kind": "subagent_spawned",
                "thread_id": "run-root",
                "agent_thread_id": "run-child-1",
                "nickname": "Worker 1",
                "role": "worker",
                "summary": "Spawned Worker 1 [worker]",
            }
        )
    )

    assert state.transcript[-1].kind == "subagent_event"
    assert state.session_nav.threads["run-child-1"].status == "running"


def test_projector_opens_review_overlay_from_review_requested_event() -> None:
    state = ShellState.empty()
    projector = EventProjector(state)

    projector.apply(
        RuntimeEvent.model_validate(
            {
                "kind": "review_requested",
                "thread_id": "run-root",
                "review_kind": "execution_bundle",
                "title": "Execution bundle v2",
                "summary": "Execution bundle v2 is waiting for approval.",
                "actions": ["approve", "reject"],
            }
        )
    )

    assert state.overlay is not None
    assert state.overlay.kind == "review"
    assert state.status.pending_reviews == 1
```

- [ ] **Step 2: Run the projector tests to verify they fail**

Run: `uv run pytest tests/unit/test_chat_shell_projector.py -q`
Expected: FAIL because shell state and projector modules do not exist.

- [ ] **Step 3: Write the minimal shell state and projector implementation**

Implement in `state.py`:

- transcript cell models
- overlay models
- status/header/footer models
- thread/session navigation models
- `ShellState.empty()`

Implement in `projector.py`:

- `EventProjector.apply(...)`
- event-to-state projection for the protocol events created in Chunk 1

Implement in `fixtures.py`:

- 2-3 named fixture scenarios such as:
  - `hello`
  - `review_gate`
  - `subagent_review`
- a tiny in-memory fixture client that replays `RuntimeEvent` objects in order

- [ ] **Step 4: Run the projector tests to verify they pass**

Run: `uv run pytest tests/unit/test_chat_shell_projector.py -q`
Expected: PASS

- [ ] **Step 5: Commit shell state and projector**

```bash
git add src/ralphception/chat_shell tests/unit/test_chat_shell_projector.py
git commit -m "feat: add chat shell state projection"
```

## Chunk 3: Textual Shell Prototype

### Task 3: Render the fixture-driven chat shell

**Files:**
- Create: `src/ralphception/chat_shell/app.py`
- Create: `src/ralphception/chat_shell/widgets/__init__.py`
- Create: `src/ralphception/chat_shell/widgets/transcript_view.py`
- Create: `src/ralphception/chat_shell/widgets/bottom_pane.py`
- Create: `src/ralphception/chat_shell/widgets/status_surface.py`
- Test: `tests/integration/test_chat_shell_app.py`

- [ ] **Step 1: Write the failing Textual integration tests**

```python
import asyncio

from ralphception.chat_shell.app import ChatShellApp
from ralphception.chat_shell.widgets.bottom_pane import BottomPaneWidget
from ralphception.chat_shell.widgets.transcript_view import TranscriptView

def test_chat_shell_renders_fixture_transcript() -> None:
    app = ChatShellApp.from_fixture("subagent_review")

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            transcript = app.query_one("#transcript-view", TranscriptView)
            return transcript.rendered_text()

    rendered = asyncio.run(exercise())
    assert "Spawned Worker 1 [worker]" in rendered
    assert "Execution bundle v2 is waiting for approval." in rendered


def test_chat_shell_shows_review_overlay_for_fixture_scenario() -> None:
    app = ChatShellApp.from_fixture("review_gate")

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            overlay = app.query_one("#bottom-pane", BottomPaneWidget)
            return overlay.active_overlay_kind

    assert asyncio.run(exercise()) == "review"
```

- [ ] **Step 2: Run the shell integration tests to verify they fail**

Run: `uv run pytest tests/integration/test_chat_shell_app.py -q`
Expected: FAIL because `ChatShellApp` and its widgets do not exist.

- [ ] **Step 3: Write the minimal shell implementation**

Implement:

- `ChatShellApp.from_fixture(name: str)` in `app.py`
- a transcript widget that renders committed transcript lines from `ShellState`
- a bottom-pane widget that renders:
  - composer stub
  - footer hints
  - active overlay summary
- a status widget for mission/thread/busy context
- small widget test helpers such as `rendered_text()` / `active_overlay_kind` if needed to keep Textual tests simple and deterministic

Keep the first slice intentionally minimal:

- no real runtime connection
- no editable composer yet
- no slash command execution yet
- just enough layout and state binding to validate the Codex-like shell shape

- [ ] **Step 4: Run the shell integration tests to verify they pass**

Run: `uv run pytest tests/integration/test_chat_shell_app.py -q`
Expected: PASS

- [ ] **Step 5: Commit the shell prototype**

```bash
git add src/ralphception/chat_shell/app.py src/ralphception/chat_shell/widgets tests/integration/test_chat_shell_app.py
git commit -m "feat: add fixture-driven chat shell prototype"
```

## Chunk 4: Experimental Entry Point

### Task 4: Add an experimental `chat-shell` CLI command

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `tests/unit/test_cli_bootstrap.py`
- Modify: `README.md`

- [ ] **Step 1: Write the failing CLI tests**

```python
from unittest.mock import patch

import ralphception.app as runtime_app
from typer.testing import CliRunner

from ralphception.cli import app

def test_cli_help_exposes_chat_shell_command() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "chat-shell" in result.stdout


def test_cli_chat_shell_passes_fixture_name_to_runtime_app() -> None:
    with patch.object(runtime_app, "run_chat_shell") as run_chat_shell:
        result = CliRunner().invoke(app, ["chat-shell", "--fixture", "subagent_review"])

    assert result.exit_code == 0
    run_chat_shell.assert_called_once_with(fixture_name="subagent_review")
```

- [ ] **Step 2: Run the CLI tests to verify they fail**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL because the `chat-shell` command and `run_chat_shell(...)` helper do not exist.

- [ ] **Step 3: Write the minimal entrypoint implementation**

Implement:

- `run_chat_shell(*, fixture_name: str = "hello")` in `src/ralphception/app.py`
- a new `chat-shell` command in `src/ralphception/cli.py`
- a short README section showing:

```bash
uv run ralphception chat-shell --fixture subagent_review
```

Do not replace the default `run_app()` entrypoint yet. This slice is experimental by design.

- [ ] **Step 4: Run the targeted tests to verify they pass**

Run: `uv run pytest tests/unit/test_cli_bootstrap.py tests/integration/test_chat_shell_app.py -q`
Expected: PASS

- [ ] **Step 5: Run final first-slice verification**

Run: `uv run pytest tests/unit/test_protocol_models.py tests/unit/test_chat_shell_projector.py tests/unit/test_cli_bootstrap.py tests/integration/test_chat_shell_app.py -q`
Expected: PASS

Run: `uv run ty check src tests`
Expected: PASS

Run: `git diff --check`
Expected: no output

- [ ] **Step 6: Commit the experimental entrypoint**

```bash
git add src/ralphception/app.py src/ralphception/cli.py tests/unit/test_cli_bootstrap.py README.md
git commit -m "feat: add experimental chat shell entrypoint"
```

## Plan Completion Criteria

This plan is complete when:

- the new protocol package exists and is validated by unit tests
- the shell state and event projector exist and are validated by unit tests
- a fixture-driven `ChatShellApp` renders transcript, status, and overlay state in Textual
- contributors can launch the prototype through `uv run ralphception chat-shell --fixture <name>`
- all targeted tests and type checks pass

## Explicitly Out of Scope

- binding the shell to the real runtime
- replacing the current default TUI
- real composer editing semantics
- real slash command execution
- real approvals persistence through the new shell
- real subagent spawning through the new protocol

Those belong in the next plan once this foundation is in place and visually validated.
