# Assistant Bullet Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Render committed assistant messages as Codex-style bulleted history cells instead of plain unprefixed markdown lines.

**Architecture:** Keep the existing markdown renderer, but wrap committed assistant-history output with Codex-like history prefixes: the first visible line gets `• ` and subsequent visible lines get `  `. Preserve blank lines without bullets so markdown spacing still reads correctly.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the unbulleted assistant-history gap

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add failing assistant-history assertions**

Update tests so that committed assistant history expects:
- `• ` on the first visible assistant line
- `  ` on subsequent visible lines
- blank lines stay blank

- [ ] **Step 2: Run focused tests to verify failure**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_ralph_adapter.py -q`

Expected: FAIL because committed assistant cells are still emitted as raw markdown lines.

### Task 2: Implement the assistant-history wrapper

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`
- Test: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Re-run the focused tests before coding**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_ralph_adapter.py -q`

Expected: FAIL

- [ ] **Step 2: Implement the minimal bullet-prefix wrapping**

Update `AssistantHistoryCell` so that:
- the first non-empty line gets `• `
- subsequent non-empty lines get `  `
- blank lines remain blank
- height measurement follows the wrapped output

- [ ] **Step 3: Run the focused tests to verify they pass**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_ralph_adapter.py -q`

Expected: PASS

### Task 3: Verify, merge, and clean up

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-assistant-bullet-parity.md`

- [ ] **Step 1: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- diff-check is clean

- [ ] **Step 2: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/assistant-bullet-parity
git push origin main
git worktree remove .worktrees/feat-assistant-bullet-parity
git branch -d feat/assistant-bullet-parity
```
