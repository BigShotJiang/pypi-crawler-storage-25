# Codex Transcript Repair Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Ralphception's lossy summary-string TUI reducer with a Codex-style event-driven transcript and blocking-state model so logs do not disappear, assistant output is visible, waiting/review states are explicit, and local draft text survives runtime activity.

**Architecture:** Port the Codex `chatwidget` / `history_cell` ownership model instead of patching the current snapshot reducer. The runtime path will emit typed events, a new transcript store will own committed history plus a mutable active cell, and the runtime adapter will project that persistent interaction state into the existing shell frame. Bottom-pane state will derive from explicit running/waiting/blocked state instead of summary messages.

**Tech Stack:** Python 3.13, Textual, pytest, Ralphception runtime/supervisor/headless stack, Codex `tui_app_server` reference code under `~/code/codex`

---

## Scope And File Map

This plan covers one subsystem: the live interactive transcript/runtime path for the Ralphception TUI.

### Files to create

- `src/ralphception/tui/chatwidget/transcript_store.py`
  Persistent transcript reducer that owns committed history cells, active cell/group, active-cell revision, waiting state, and blocking transcript insertions.
- `tests/unit/test_tui_transcript_store.py`
  Red/green tests for interleaved deltas, command accumulation, wait streaks, approval/request history, and active-cell finalization.

### Files to modify

- `src/ralphception/runtime/frontends.py`
  Replace `FrontendEvent(message=...)` with typed event dataclasses and stable payload shapes.
- `src/ralphception/headless.py`
  Preserve typed event semantics from Codex/runtime notifications instead of collapsing them into summary prose.
- `src/ralphception/tui/runtime_adapter.py`
  Use the transcript store, derive explicit task/blocking state, and stop reconstructing transcript meaning from English strings.
- `src/ralphception/tui/render_state.py`
  Expand render-state structure so it can project persistent transcript/task/blocking state without owning it.
- `src/ralphception/tui/chatwidget/transcript_cells.py`
  Add Codex-like durable cell types for assistant output, command output, waiting, review/request, and error cases.
- `src/ralphception/tui/chatwidget/transcript_view.py`
  Use active-cell revision driven rendering and stable tail-follow behavior.
- `src/ralphception/tui/chatwidget/chat_widget.py`
  Render the richer transcript state instead of a string-joined approximation.
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
  Derive visible waiting/blocking/composer state from explicit shell state and preserve drafts while busy.
- `src/ralphception/tui/app.py`
  Stop manually synthesizing transcript history on submit; route input and runtime updates through the transcript store projection.

### Tests to modify

- `tests/unit/test_tui_runtime_adapter.py`
- `tests/integration/test_tui_transcript.py`
- `tests/integration/test_tui_runtime_app.py`

### Codex references for every task

- `~/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui_app_server/src/history_cell.rs`
- `~/code/codex/codex-rs/tui_app_server/src/app.rs`

---

## Task 1: Freeze The Real Transcript Failures With Red Tests

**Files:**
- Create: `tests/unit/test_tui_transcript_store.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`
- Modify: `tests/integration/test_tui_transcript.py`
- Modify: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Add a red unit test for assistant deltas committing cleanly**

  Add a test like:

  ```python
  def test_transcript_store_commits_final_assistant_after_deltas() -> None:
      store = TranscriptStore()
      store.apply(AssistantDeltaEvent(item_id="a1", text="hello"))
      store.apply(AssistantDeltaEvent(item_id="a1", text=" world"))
      store.apply(AssistantFinalEvent(item_id="a1", text="hello world"))
      assert store.active_cell is None
      assert [type(cell).__name__ for cell in store.history_cells] == ["AssistantHistoryCell"]
      assert "hello world" in store.history_cells[0].render_lines(width=80)
  ```

- [ ] **Step 2: Add a red unit test for interleaved command output**

  Add a test that applies:
  - `CommandBeginEvent`
  - two `CommandOutputDeltaEvent`s
  - `CommandEndEvent`

  Then assert the committed command cell still contains both output lines.

- [ ] **Step 3: Add a red unit test for explicit background waiting**

  Add a test that applies `BackgroundWaitBeginEvent(process_id="p1", command="tail -f log")`, verifies the store reports waiting, then applies `BackgroundWaitEndEvent` and verifies waiting is cleared.

- [ ] **Step 4: Add a red runtime-adapter test for dual-surfaced review state**

  Add a test that emits a typed `ReviewRequestedEvent` and asserts both:
  - the blocking bottom-pane overlay is active
  - a committed transcript/history entry exists explaining the review request

- [ ] **Step 5: Add a red live-app test for draft preservation during runtime updates**

  Add an integration test that:
  - starts a live task
  - types a partial draft while updates stream in
  - waits for several `_drain_runtime_updates()` cycles
  - asserts the composer still contains the same draft text

- [ ] **Step 6: Add a red integration test for “not idle while unresolved”**

  Add a TUI integration test that drives a run into one of:
  - assistant streaming
  - background wait
  - review requested

  Then assert the shell does not render as idle and exposes a visible active or blocked state.

- [ ] **Step 7: Run the focused red suite**

  Run:

  ```bash
  uv run pytest tests/unit/test_tui_transcript_store.py tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_transcript.py tests/integration/test_tui_runtime_app.py -q
  ```

  Expected: failures on every missing behavior above.

- [ ] **Step 8: Commit the red tests**

  ```bash
  git add tests/unit/test_tui_transcript_store.py tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_transcript.py tests/integration/test_tui_runtime_app.py
  git commit -m "test: capture codex transcript repair regressions"
  ```

---

## Task 2: Replace Summary Strings With Typed Runtime Events

**Files:**
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/headless.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Define typed frontend event dataclasses**

  Replace the current open-ended event shape with explicit dataclasses, for example:

  ```python
  @dataclass(frozen=True, slots=True)
  class AssistantDeltaEvent:
      item_id: str
      text: str

  @dataclass(frozen=True, slots=True)
  class CommandBeginEvent:
      item_id: str
      command: str

  RuntimeFrontendEvent: TypeAlias = (
      AssistantDeltaEvent
      | AssistantFinalEvent
      | CommandBeginEvent
      | CommandOutputDeltaEvent
      | CommandEndEvent
      | BackgroundWaitBeginEvent
      | BackgroundWaitUpdateEvent
      | BackgroundWaitEndEvent
      | ReviewRequestedEvent
      | ReviewResolvedEvent
      | RequestUserInputRequestedEvent
      | RequestUserInputResolvedEvent
      | RuntimeStatusUpdatedEvent
      | TurnStartedEvent
      | TurnCompletedEvent
      | TurnFailedEvent
      | ErrorEvent
  )
  ```

- [ ] **Step 2: Port `_format_turn_progress_event` to preserve event shape**

  Rewrite `src/ralphception/headless.py::_format_turn_progress_event()` so it returns typed events instead of `FrontendEvent(message=...)`.

  Specific mappings:
  - `item/agentMessage/delta` -> `AssistantDeltaEvent`
  - `item/completed(agentMessage)` -> `AssistantFinalEvent`
  - `item/started(commandExecution)` -> `CommandBeginEvent`
  - `item/commandExecution/outputDelta` -> `CommandOutputDeltaEvent`
  - `item/completed(commandExecution)` -> `CommandEndEvent`
  - terminal polling/wait cases -> `BackgroundWait*Event`
  - `thread/tokenUsage/updated` -> `RuntimeStatusUpdatedEvent`

- [ ] **Step 3: Preserve review/request events as typed runtime events**

  When Ralphception enters review or request-user-input, emit typed events that can later create both transcript history and blocking state.

- [ ] **Step 4: Remove string-prefix parsing from adapter tests**

  Update the adapter tests so they no longer depend on messages like `"Command started: ..."`.

- [ ] **Step 5: Run the event-shape test slice**

  Run:

  ```bash
  uv run pytest tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for typed event construction and no remaining string-prefix assumptions.

- [ ] **Step 6: Commit the typed-event contract**

  ```bash
  git add src/ralphception/runtime/frontends.py src/ralphception/headless.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "refactor: preserve typed runtime transcript events"
  ```

---

## Task 3: Build A Codex-Style Transcript Store

**Files:**
- Create: `src/ralphception/tui/chatwidget/transcript_store.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_cells.py`
- Modify: `tests/unit/test_tui_transcript_store.py`

- [ ] **Step 1: Implement the transcript store skeleton**

  Add a reducer object with state like:

  ```python
  @dataclass
  class TranscriptStore:
      history_cells: list[TranscriptCell] = field(default_factory=list)
      active_cell: ActiveTranscriptCell | None = None
      active_cell_revision: int = 0
      waiting_state: WaitingState | None = None

      def apply(self, event: RuntimeFrontendEvent) -> None:
          ...
  ```

- [ ] **Step 2: Port assistant active-cell behavior**

  Implement reducer rules so deltas mutate one active assistant cell and finals commit one assistant history cell with no duplicates.

- [ ] **Step 3: Port command active-group behavior**

  Implement reducer rules so command begin/output/end build one active command group and commit one command history cell with accumulated output.

- [ ] **Step 4: Add wait-state cells and state objects**

  Add explicit waiting models/cells so background-terminal waiting is durable and renderable until ended.

- [ ] **Step 5: Add review/request/system/error cells**

  Extend `transcript_cells.py` with committed history-cell types for:
  - review requested
  - review resolved
  - request-user-input requested
  - request-user-input resolved
  - failures/interruption

- [ ] **Step 6: Run the transcript-store unit suite**

  Run:

  ```bash
  uv run pytest tests/unit/test_tui_transcript_store.py -q
  ```

  Expected: PASS for interleaving, wait-state, and finalization behavior.

- [ ] **Step 7: Commit the transcript store**

  ```bash
  git add src/ralphception/tui/chatwidget/transcript_store.py src/ralphception/tui/chatwidget/transcript_cells.py tests/unit/test_tui_transcript_store.py
  git commit -m "feat: add codex-style transcript store"
  ```

---

## Task 4: Rewire The Runtime Adapter Around Persistent Transcript State

**Files:**
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Make the adapter own one persistent transcript store**

  Replace the current ad hoc transcript mutations with a long-lived `TranscriptStore` instance on the adapter.

- [ ] **Step 2: Derive blocking surfaces and task state explicitly**

  Add explicit adapter state for:
  - running
  - waiting
  - blocked
  - failed
  - idle

  Derive bottom-pane status indicator and overlay state from that model instead of from string messages.

- [ ] **Step 3: Stop appending transcript cells directly in fallback string branches**

  Delete the message-prefix parsing branch in `_apply_frontend_event()` and replace it with typed event reduction through the transcript store.

- [ ] **Step 4: Project review/input-needed as both history and overlay**

  Ensure typed review/request events:
  - append a committed history cell
  - activate the blocking surface

  Then ensure resolution events append a committed resolution cell and clear the blocking surface.

- [ ] **Step 5: Preserve local draft during adapter updates**

  Make sure adapter render-state projection never sets composer value unless:
  - startup submission intentionally clears it
  - explicit submit/queue/edit-last-queued intentionally changes it

- [ ] **Step 6: Run adapter-focused tests**

  Run:

  ```bash
  uv run pytest tests/unit/test_tui_runtime_adapter.py tests/unit/test_tui_transcript_store.py -q
  ```

  Expected: PASS for event reduction, task-state transitions, review dual-surfacing, and draft preservation.

- [ ] **Step 7: Commit the adapter rewrite**

  ```bash
  git add src/ralphception/tui/runtime_adapter.py src/ralphception/tui/render_state.py tests/unit/test_tui_runtime_adapter.py tests/unit/test_tui_transcript_store.py
  git commit -m "refactor: drive tui from persistent transcript state"
  ```

---

## Task 5: Make The Chat Widget And Transcript View Behave Like Codex

**Files:**
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/chatwidget/chat_widget.py`
- Modify: `src/ralphception/tui/app.py`
- Modify: `tests/integration/test_tui_transcript.py`

- [ ] **Step 1: Render committed history plus active tail from store-backed state**

  Rework the transcript view so it renders durable committed history plus a live active tail driven by `active_cell_revision`.

- [ ] **Step 2: Preserve tail-follow semantics**

  Keep Codex-like behavior:
  - if user is at tail, follow new output
  - if user scrolled up, do not yank them back

- [ ] **Step 3: Stop `app.py` from synthesizing transcript history on submit**

  On submit, route the user message through the adapter/store path so the transcript source of truth stays singular.

- [ ] **Step 4: Keep transcript overlay synchronized from the same source**

  Ensure `Ctrl+T` shows:
  - committed history cells
  - current active tail
  - stable updates while the active cell changes

- [ ] **Step 5: Run transcript integration tests**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_transcript.py tests/unit/test_tui_transcript_store.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for accumulation, commit, overlay live tail, and tail-follow behavior.

- [ ] **Step 6: Commit the chat widget rewrite**

  ```bash
  git add src/ralphception/tui/chatwidget/transcript_view.py src/ralphception/tui/chatwidget/chat_widget.py src/ralphception/tui/app.py tests/integration/test_tui_transcript.py
  git commit -m "fix: render stable codex-style transcript history"
  ```

---

## Task 6: Make Waiting And Blocking States Obvious In The Live Shell

**Files:**
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Surface waiting as explicit shell state**

  Add a visible waiting presentation for background-terminal polling and similar unresolved activity. This must survive until an explicit end event.

- [ ] **Step 2: Keep blocking overlays tied to committed transcript state**

  Ensure review/request-needed states produce both:
  - a committed transcript explanation
  - the active blocking bottom-pane overlay

- [ ] **Step 3: Prevent false idle transitions**

  The shell should only show idle footer/status when:
  - no active cell
  - no waiting state
  - no blocking state
  - no unresolved failure state

- [ ] **Step 4: Add a live multi-command unresolved integration test**

  Add a test that simulates several commands plus a pause/wait/review transition and asserts the shell ends in a visible non-idle state instead of silent readiness.

- [ ] **Step 5: Run the live app slice**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_runtime_app.py tests/integration/test_tui_transcript.py -q
  ```

  Expected: PASS for waiting, review, and non-idle behavior.

- [ ] **Step 6: Commit the shell-state fix**

  ```bash
  git add src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/render_state.py src/ralphception/tui/runtime_adapter.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_transcript.py
  git commit -m "fix: surface waiting and blocking transcript states"
  ```

---

## Task 7: Full Verification And Live Terminal Smoke

**Files:**
- Modify as needed from prior tasks only

- [ ] **Step 1: Run the focused TUI verification set**

  Run:

  ```bash
  uv run pytest tests/unit/test_tui_transcript_store.py tests/unit/test_tui_runtime_adapter.py tests/integration/test_tui_transcript.py tests/integration/test_tui_runtime_app.py -q
  ```

  Expected: PASS

- [ ] **Step 2: Run full automated verification**

  Run:

  ```bash
  uv run pytest tests/unit tests/integration tests/e2e -q
  uv run ty check src tests
  git diff --check
  ```

  Expected:
  - full test suite passes
  - type check passes
  - diff check is clean

- [ ] **Step 3: Run live tmux smoke for the exact reported failures**

  Manually verify in a real terminal session:

  - start a run that executes several commands
  - confirm command output remains visible instead of disappearing
  - confirm assistant/model text appears in transcript
  - confirm waiting-on-background-terminal is explicit when applicable
  - confirm review/input-needed state is obvious and actionable
  - type in the composer while the task runs and confirm the draft survives

- [ ] **Step 4: Capture any final fixes discovered in tmux smoke**

  If tmux reveals a mismatch not covered by tests, add the missing test first, then implement the fix, and rerun the relevant verification.

- [ ] **Step 5: Commit the final stabilization pass**

  ```bash
  git add src tests
  git commit -m "fix: complete codex transcript repair"
  ```

---

## Completion Gate

Do not call this work done until all of the following are true in a real terminal:

- the transcript grows monotonically during a multi-command run
- assistant output reads like a real conversation, not a sparse work log
- the user can always tell whether Ralphception is running, waiting, blocked, failed, or ready
- review/input-needed states are visible in both history and active interaction surfaces
- the local draft survives runtime activity until the user intentionally changes it
- the live shell feels like Codex’s `chatwidget` / `history_cell` model adapted to Ralphception, not a dashboard patched to resemble it
