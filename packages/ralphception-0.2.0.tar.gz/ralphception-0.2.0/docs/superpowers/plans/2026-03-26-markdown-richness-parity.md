# Markdown Richness Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the next layer of Codex transcript richness by styling assistant markdown for headings, emphasis, inline code, and links instead of flattening everything to plain text.

**Architecture:** Keep Ralphception’s line-oriented Python renderer, but replace the current strip-markup normalization with a small styled-span pipeline. Tokenize inline markdown into `StyledSpan`s, wrap those spans to visible width, and emit ANSI-styled transcript lines so assistant output reads more like Codex without rewriting the entire render stack.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the markdown richness gap in tests

**Files:**
- Create: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Write failing tests for rich markdown styling**

Add tests that assert:
- inline code renders cyan
- markdown links render cyan and underlined
- emphasis renders italic
- strong text renders bold
- h1 headings render bold and underlined

- [ ] **Step 2: Run the markdown-render tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL because the current renderer strips markup and emits plain text.

- [ ] **Step 3: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_markdown_render.py
git commit -m "test: pin codex markdown richness parity"
```

### Task 2: Implement styled inline markdown rendering

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Modify: `src/ralphception/codex_tui/styled_text.py`
- Test: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Run the failing tests again before coding**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL

- [ ] **Step 2: Implement the minimal styled-span renderer**

Add:
- inline tokenization for links, code, emphasis, and strong text
- heading-level styles
- visible-width-aware wrapping for styled spans
- ANSI output that preserves styling across wrapped lines

- [ ] **Step 3: Run the markdown-render tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: PASS

- [ ] **Step 4: Commit the renderer implementation**

```bash
git add src/ralphception/codex_tui/markdown_render.py src/ralphception/codex_tui/styled_text.py tests/unit/codex_tui/test_markdown_render.py
git commit -m "feat: enrich codex tui markdown styling"
```

### Task 3: Verify transcript parity on the live shell

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add regression coverage for assistant-history rich rendering**

Assert assistant cells and tmux startup/first-turn paths preserve the visible text while also emitting ANSI styling for markdown-rich lines.

- [ ] **Step 2: Run the focused assistant/tmux tests**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

- [ ] **Step 3: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Compare against Codex in tmux**

Run side-by-side tmux probes for:
- `codex`
- `uv run ralphception`

Check that assistant markdown now reads closer to Codex for:
- inline code
- linked phrases
- emphasized notes
- heading lines

- [ ] **Step 5: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/markdown-richness-parity
git push origin main
git worktree remove .worktrees/feat-markdown-richness-parity
git branch -d feat/markdown-richness-parity
```
