# Codex Config Inherited Model Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception inherit model settings from Codex config, remove the in-app model picker flow, and turn `/model` into guidance.

**Architecture:** The Codex transport becomes the source of truth by copying the user Codex config into Ralphception's isolated Codex home and by omitting explicit model/reasoning overrides from app-server requests. The TUI resolves display metadata from Codex config and replaces the picker flow with an informational `/model` command.

**Tech Stack:** Python 3.12+, Textual, pytest, tomllib, Codex app-server transport, Ralphception TUI runtime adapter

---

## Chunk 1: Freeze Current Behavior With Tests

### Task 1: Add failing tests for inherited Codex model behavior

**Files:**
- Modify: `tests/unit/test_codex_client.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/integration/test_tui_session_header.py`

- [ ] **Step 1: Write a failing transport test**

Add a test proving the isolated Codex home copies the source `config.toml` instead of writing a Ralphception-owned model config.

- [ ] **Step 2: Write a failing request-payload test**

Add a test proving `thread/start` and `turn/start` no longer send `model` or `effort` overrides.

- [ ] **Step 3: Write a failing `/model` TUI test**

Add an integration test proving `/model` opens guidance text instead of a model picker.

- [ ] **Step 4: Run focused tests and verify failure**

Run:

```bash
uv run pytest tests/unit/test_codex_client.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_session_header.py -q
```

## Chunk 2: Inherit Codex Config In The Transport

### Task 2: Stop forcing model selection in the Codex client

**Files:**
- Modify: `src/ralphception/codex/client.py`
- Test: `tests/unit/test_codex_client.py`

- [ ] **Step 1: Copy source Codex config into the isolated Codex home**
- [ ] **Step 2: Keep fallback config generation only when the source config is missing**
- [ ] **Step 3: Remove `model` and `effort` overrides from app-server request payloads**
- [ ] **Step 4: Run focused client tests**

```bash
uv run pytest tests/unit/test_codex_client.py -q
```

## Chunk 3: Resolve Display Metadata From Codex Config

### Task 3: Teach the TUI to display inherited Codex settings

**Files:**
- Create: `src/ralphception/codex/config.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Test: `tests/integration/test_tui_session_header.py`

- [ ] **Step 1: Add a small Codex config resolver for model, reasoning effort, and service tier**
- [ ] **Step 2: Use that resolver for header/footer display state**
- [ ] **Step 3: Keep Ralphception-specific config for non-model concerns**
- [ ] **Step 4: Run focused header/runtime tests**

```bash
uv run pytest tests/integration/test_tui_session_header.py tests/unit/test_tui_runtime_adapter.py -q
```

## Chunk 4: Remove Picker UX And Replace `/model`

### Task 4: Turn `/model` into guidance

**Files:**
- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/chatwidget/session_header.py`
- Test: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Remove the live model/reasoning picker route from `/model`**
- [ ] **Step 2: Replace `/model` with an informational announcement or overlay**
- [ ] **Step 3: Update header copy from `/model to change` to inherited-model guidance**
- [ ] **Step 4: Ensure no model picker view remains reachable in the live app**
- [ ] **Step 5: Run focused TUI tests**

```bash
uv run pytest tests/integration/test_tui_runtime_app.py tests/integration/test_tui_session_header.py -q
```

## Chunk 5: Final Verification

### Task 5: Verify end to end and land the slice

**Files:**
- Modify as needed from earlier chunks only

- [ ] **Step 1: Run the full suite**

```bash
uv run pytest tests/unit tests/integration tests/e2e -q
```

- [ ] **Step 2: Run type checks**

```bash
uv run ty check src tests
```

- [ ] **Step 3: Run diff hygiene**

```bash
git diff --check
```

- [ ] **Step 4: Smoke test the real shell**

Run `uv run ralphception` and verify:
- header/footer reflect Codex config values
- `/model` shows guidance
- no picker opens

- [ ] **Step 5: Commit**

```bash
git add <changed files>
git commit -m "fix: inherit model settings from codex config"
```
