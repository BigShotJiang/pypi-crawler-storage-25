# Busy Composer Placeholder Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Keep a Codex-style starter placeholder visible in the composer while Ralphception is working instead of blanking the prompt line.

**Architecture:** Reuse the already-selected idle starter placeholder for busy states. Update the adapter tests and tmux-facing expectations so active loop/execution states keep the starter prompt visible while the separate working-status line carries the actual in-progress state.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the busy-placeholder gap in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add failing assertions for working-state placeholder retention**

Update the busy-shell test so that when a loop launches:
- the waiting line still shows `• Working (...)`
- the composer placeholder stays on the idle starter text instead of becoming empty

- [ ] **Step 2: Run focused tests to verify failure**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL because the adapter currently swaps in an empty working placeholder.

### Task 2: Implement the busy-placeholder port

**Files:**
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Test: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Re-run the focused tests before coding**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL

- [ ] **Step 2: Implement the minimal placeholder change**

Update busy-shell rendering so the composer keeps the selected idle starter placeholder during working states instead of switching to an empty placeholder.

- [ ] **Step 3: Run the focused tests to verify they pass**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

### Task 3: Verify, merge, and clean up

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-busy-composer-placeholder-parity.md`

- [ ] **Step 1: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- diff-check is clean

- [ ] **Step 2: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/busy-composer-placeholder-parity
git push origin main
git worktree remove .worktrees/feat-busy-composer-placeholder-parity
git branch -d feat/busy-composer-placeholder-parity
```
