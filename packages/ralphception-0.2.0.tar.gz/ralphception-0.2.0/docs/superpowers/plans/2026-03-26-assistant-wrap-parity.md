# 2026-03-26 Assistant Wrap Parity

## Goal

Port Codex assistant-message wrapping more faithfully by applying the `• ` / `  `
indents during wrapping instead of after markdown lines are already width-limited.
The current Python port can emit visible assistant lines that are wider than the
viewport, which produces wrap jitter in tmux.

## Constraints

- Keep the existing committed assistant bullet shape.
- Preserve current markdown styling and transcript semantics.
- Make the narrow-width behavior match the Codex `AgentMessageCell` contract:
  wrapping must account for the indent width.

## Plan

1. Add focused tests that prove assistant history lines do not exceed the target
   width once bullets/continuation indents are present.
2. Update `AssistantHistoryCell` to render markdown against the inner width and
   then prefix wrapped lines without overflowing the viewport.
3. Rerun focused unit tests, then the full suite and typecheck.
4. Verify the first-turn assistant blocker in tmux at a narrow pane width.
5. Merge to `main`, push, and remove the feature worktree.
