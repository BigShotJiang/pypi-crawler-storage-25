# Markdown Fidelity Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Align Ralphception’s markdown transcript details more exactly with Codex by fixing heading markers, blockquote markers, and local-file link styling semantics.

**Architecture:** Keep the current markdown renderer but correct the remaining semantic mismatches against the Codex source. The renderer should emit Codex-shaped heading lines, use `> ` for blockquotes, and render local file links as code-like path text instead of normal underlined links.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the exact fidelity gaps in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Write failing tests for Codex-exact markdown details**

Add tests that assert:
- H1 renders with a `# ` prefix, not just bare heading text
- blockquotes render with a `> ` prefix, not `│ `
- local file links are code-styled path text rather than underlined web-link text

- [ ] **Step 2: Run the markdown-render tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL because the current renderer still diverges from the Codex source on these exact details.

- [ ] **Step 3: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_markdown_render.py
git commit -m "test: pin codex markdown fidelity parity"
```

### Task 2: Implement the renderer corrections

**Files:**
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Test: `tests/unit/codex_tui/test_markdown_render.py`

- [ ] **Step 1: Re-run the failing markdown tests before coding**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: FAIL

- [ ] **Step 2: Implement the minimal fidelity corrections**

Update the renderer so that:
- heading lines keep their Codex-style marker prefix
- blockquotes use `> ` with blockquote styling
- local file links use code styling and suppress web-link underline semantics

- [ ] **Step 3: Run the markdown-render tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py -q`
Expected: PASS

- [ ] **Step 4: Commit the renderer implementation**

```bash
git add src/ralphception/codex_tui/markdown_render.py tests/unit/codex_tui/test_markdown_render.py
git commit -m "feat: align codex tui markdown fidelity"
```

### Task 3: Verify transcript behavior and merge

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`

- [ ] **Step 1: Add transcript-level regression coverage**

Pin the same fidelity details through `AssistantHistoryCell`.

- [ ] **Step 2: Run focused regression coverage**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_markdown_render.py tests/unit/codex_tui/test_history_cell.py -q`

Expected: PASS

- [ ] **Step 3: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/markdown-fidelity-parity
git push origin main
git worktree remove .worktrees/feat-markdown-fidelity-parity
git branch -d feat/markdown-fidelity-parity
```
