# Busy Footer Status Line Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception's live busy shell keep the Codex-style model/context/path status line under the composer instead of dropping to a shortcuts-only footer after the first Socratic answer.

**Architecture:** Keep the existing bottom-pane renderer, but split reply-mode footer behavior from busy-mode footer behavior. Reply mode should continue to own the footer with answer guidance only, while busy mode should restore the passive status-line row even when a waiting line is visible.

**Tech Stack:** Python 3.13, pytest, tmux capture tests, Ralphception Codex TUI port

---

### Task 1: Lock The Busy Footer Contract In Tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Write the failing unit expectation for busy bottom-pane rendering**

```python
def test_working_state_keeps_passive_status_line_under_composer() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Implement {feature}"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
                status_line="gpt-5.4 xhigh fast · 100% left · ~/code/ralphception",
            ),
            waiting_line="• Working (0s • esc to interrupt) · run-child-1",
        )
    )

    lines = widget.render_lines(100)

    assert lines[0] == "• Working (0s • esc to interrupt) · run-child-1"
    assert strip_ansi(lines[1]).rstrip() == "› Implement {feature}"
    assert strip_ansi(lines[3]) == "  gpt-5.4 xhigh fast · 100% left · ~/code/ralphception"
```

- [ ] **Step 2: Write the failing adapter expectation for post-answer busy state**

```python
def test_adapter_busy_state_restores_passive_status_line_after_reply() -> None:
    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    adapter.commit_user_message("find typos")
    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-1",
            title="Scope",
            question="Which files are in scope?",
        )
    )
    adapter.commit_user_message("README only")
    adapter.apply_event(CurrentLoopLabelEvent(label="run-child-1"))

    lines = [strip_ansi(line) for line in adapter.chatwidget.render_lines(100)]

    assert any("• Working (0s • esc to interrupt) · run-child-1" in line for line in lines)
    assert any(line == "  gpt-5.4 xhigh fast · 100% left · /tmp/work" for line in lines)
```

- [ ] **Step 3: Write the failing tmux integration assertion**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -k busy -q`

Expected: FAIL because the live busy shell still shows `? for shortcuts` instead of the passive status line.

### Task 2: Restore Codex-Style Passive Status During Busy States

**Files:**
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/status.py`

- [ ] **Step 1: Keep reply-mode behavior isolated**

```python
self.chatwidget.bottom_pane.footer = FooterState(
    left_hint=REPLY_FOOTER_HINT,
    right_status="",
    model_label=self.chatwidget.bottom_pane.footer.model_label,
    status_line=None,
)
```

- [ ] **Step 2: Restore the passive status line when busy work resumes**

```python
self.chatwidget.bottom_pane.footer = FooterState(
    left_hint="? for shortcuts",
    right_status=self.chatwidget.bottom_pane.footer.right_status,
    model_label=self.chatwidget.bottom_pane.footer.model_label,
    status_line=self._idle_footer_status_line,
)
```

- [ ] **Step 3: Keep bottom-pane rendering preferring `status_line` even with a waiting line**

```python
if self.footer.status_line:
    lines.append(render_passive_status_line(self.footer.status_line, width=width))
    return lines
```

- [ ] **Step 4: Run the focused test set**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

### Task 3: Verify Live Tmux Parity And Finish The Slice

**Files:**
- No additional code changes expected

- [ ] **Step 1: Re-run fresh tmux captures**

Run:

```bash
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py create --name ralph-busy-verify --cwd /Users/shayne/code/ralphception/.worktrees/feat-busy-footer-status-parity
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py step --target ralph-busy-verify:0.0 --text "uv run ralphception" --enter --sleep-ms 3000 --lines 240
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py step --target ralph-busy-verify:0.0 --text "find and fix all the typos" --enter --sleep-ms 3500 --lines 240
python /Users/shayne/code/skills/skills/terminal-controller/scripts/tmux_control.py step --target ralph-busy-verify:0.0 --text "README only" --enter --sleep-ms 4000 --lines 240
```

Expected: Busy shell shows the working line plus the passive model/context/path status row under the composer.

- [ ] **Step 2: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 3: Run typecheck and diff hygiene**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/{ralph_adapter.py,bottom_pane.py,status.py} \
        tests/unit/codex_tui/{test_chatwidget.py,test_ralph_adapter.py} \
        tests/integration/test_codex_tui_tmux.py \
        docs/superpowers/plans/2026-03-26-busy-footer-status-line-parity.md
git commit -m "fix: restore busy footer status parity"
```
