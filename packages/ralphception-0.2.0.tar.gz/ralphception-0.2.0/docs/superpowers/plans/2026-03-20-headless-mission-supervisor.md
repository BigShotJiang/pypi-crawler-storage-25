# Headless Mission Supervisor Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn `uv run ralphception headless` into a real long-running supervisor that can accept a seed prompt, drive spec/plan/execute/merge/audit stages, reopen execution on blocking audit findings, and exit only when the mission reaches a terminal state.

**Architecture:** Add a dedicated headless supervisor service instead of growing more orchestration into `app.py`. The supervisor will use repo files as the contract between Codex turns and the runtime: each stage prompt writes deterministic artifacts into `.ralphception/`, the supervisor validates those artifacts, persists durable run state, and advances the workflow. Fake-session support will be upgraded so tests can simulate those file writes and stage transitions without a live Codex backend.

**Tech Stack:** Python 3.12+, `typer`, existing `CodexSessionManager`, existing worktree / merge / verification / audit services, `pytest`, `git worktree`

---

## File Map

- Create: `src/ralphception/headless.py`
  Long-running headless supervisor, prompt builders, durable stage-state persistence, and mission loop.
- Create: `tests/integration/test_headless_supervisor.py`
  Integration coverage for seed-prompt mission flow, approval policy, merge, audit reopen, and terminal completion.
- Modify: `src/ralphception/app.py`
  Replace the current short-lived helper with a thin wrapper around the new supervisor service.
- Modify: `src/ralphception/cli.py`
  Keep the CLI thin and point `headless` at the supervisor wrapper.
- Modify: `src/ralphception/testing/fakes.py`
  Add deterministic scripted-turn behavior that can write stage artifacts into the workspace during tests.
- Modify: `README.md`
  Document that `headless` is now a mission supervisor rather than a bootstrap/review helper.

## Chunk 1: Durable Headless Mission State

### Task 1: Add a persistent headless stage-state record

**Files:**
- Create: `src/ralphception/headless.py`
- Test: `tests/integration/test_headless_supervisor.py`

- [ ] **Step 1: Write the failing integration test**

```python
def test_headless_run_persists_stage_state_for_resume(tmp_path: Path) -> None:
    result = run_headless(
        repo_root=tmp_path,
        seed_prompt="Port parser",
        use_fake_session_manager=True,
    )

    stage_state_path = tmp_path / ".ralphception" / "runs" / "run-root" / "headless-state.json"
    assert stage_state_path.exists()
    assert result.mode == "completed"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_headless_supervisor.py::test_headless_run_persists_stage_state_for_resume -q`
Expected: FAIL because the supervisor and durable state file do not exist.

- [ ] **Step 3: Write minimal implementation**

Implement a headless-state model that records:
- current stage
- attempt counters
- current child run id
- last approved bundle version
- terminal outcome

Persist it to `.ralphception/runs/run-root/headless-state.json`.

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/integration/test_headless_supervisor.py::test_headless_run_persists_stage_state_for_resume -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/headless.py tests/integration/test_headless_supervisor.py
git commit -m "feat: add durable headless mission state"
```

## Chunk 2: Stage Prompt Contracts And Fake Session Support

### Task 2: Define deterministic artifact contracts for spec, plan, execute, and audit turns

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/testing/fakes.py`
- Test: `tests/integration/test_headless_supervisor.py`

- [ ] **Step 1: Write the failing integration tests**

```python
def test_headless_run_generates_spec_and_plan_artifacts(tmp_path: Path) -> None:
    result = run_headless(
        repo_root=tmp_path,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert (tmp_path / ".ralphception" / "specs" / "mission-spec.md").exists()
    assert (tmp_path / ".ralphception" / "plans" / "mission-plan.md").exists()
    assert result.completed_stages[:2] == ("spec", "plan")
```

```python
def test_headless_run_builds_child_handoff_and_audit_artifacts(tmp_path: Path) -> None:
    result = run_headless(
        repo_root=tmp_path,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert (tmp_path / ".ralphception" / "runs" / "run-child-1" / "handoff.json").exists()
    assert (tmp_path / ".ralphception" / "runs" / "run-root" / "audit-findings.json").exists()
    assert result.completed_stages[-2:] == ("merge", "audit")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/integration/test_headless_supervisor.py -q`
Expected: FAIL because no stage prompts or fake turn writers exist.

- [ ] **Step 3: Write minimal implementation**

Implement prompt builders that require these files:
- spec: `.ralphception/specs/mission-spec.md`
- plan: `.ralphception/plans/mission-plan.md`
- execute child: `.ralphception/runs/<child-run-id>/handoff.json`
- audit: `.ralphception/runs/run-root/audit-findings.json`

Upgrade the fake session manager so test turns can create those files deterministically from the prompt contract.

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/integration/test_headless_supervisor.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/headless.py src/ralphception/testing/fakes.py tests/integration/test_headless_supervisor.py
git commit -m "feat: add headless stage prompt contracts"
```

## Chunk 3: Mission Supervisor Loop

### Task 3: Drive spec -> plan -> execute -> merge -> audit until terminal completion

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Test: `tests/integration/test_headless_supervisor.py`
- Test: `tests/unit/test_cli_bootstrap.py`

- [ ] **Step 1: Write the failing integration and CLI tests**

```python
def test_headless_run_completes_full_mission_with_fake_backend(tmp_path: Path) -> None:
    result = run_headless(
        repo_root=tmp_path,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert result.root_run_status == "completed"
    assert result.completed_stages == ("intake", "spec", "plan", "execute", "merge", "audit")
```

```python
def test_cli_headless_reports_terminal_completion() -> None:
    result = CliRunner().invoke(
        app,
        ["headless", "--seed-prompt", "Port parser", "--approve-all", "--fake-session-manager"],
    )

    assert result.exit_code == 0
    assert "Headless mode: completed" in result.stdout
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/unit/test_cli_bootstrap.py -q`
Expected: FAIL because the supervisor still returns early.

- [ ] **Step 3: Write minimal implementation**

Implement a loop that:
- bootstraps if needed
- runs root spec turn and validates spec artifact
- creates or refreshes a pending execution bundle from the plan artifact
- auto-approves reviews when configured
- creates child worktree(s), runs execute turn(s), and validates `handoff.json`
- runs verification commands from the plan contract
- merges via `MergeCoordinator`
- audits findings, reopens execution for blocking `P0`/`P1`/`P2` findings, and repeats
- persists terminal run state and returns a terminal `HeadlessRunResult`

- [ ] **Step 4: Run tests to verify they pass**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/unit/test_cli_bootstrap.py -q`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/headless.py src/ralphception/app.py src/ralphception/cli.py tests/integration/test_headless_supervisor.py tests/unit/test_cli_bootstrap.py
git commit -m "feat: add headless mission supervisor"
```

## Chunk 4: Reopen Loop And Documentation

### Task 4: Reopen execution on blocking audit findings and document the new behavior

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `README.md`
- Test: `tests/integration/test_headless_supervisor.py`

- [ ] **Step 1: Write the failing integration test**

```python
def test_headless_run_reopens_execution_when_audit_finds_p1_gap(tmp_path: Path) -> None:
    result = run_headless(
        repo_root=tmp_path,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert "run-child-1-replacement-1" in result.child_run_ids
    assert result.audit_reopened is True
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/integration/test_headless_supervisor.py::test_headless_run_reopens_execution_when_audit_finds_p1_gap -q`
Expected: FAIL because the supervisor does not yet reopen execution on blocking findings.

- [ ] **Step 3: Write minimal implementation**

Use `AuditService` to persist and evaluate findings, reopen execution when blocking severities remain open, and continue the loop with a replacement child run.

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/integration/test_headless_supervisor.py::test_headless_run_reopens_execution_when_audit_finds_p1_gap -q`
Expected: PASS

- [ ] **Step 5: Update docs and verify**

Document:
- `headless` is a long-running mission supervisor
- what files each stage writes
- how to tail `.ralphception/events/run-root.jsonl`

Run:
- `uv run pytest tests/integration/test_headless_supervisor.py -q`
- `uv run pytest tests/unit tests/integration tests/e2e -q`
- `uv run ty check src tests`

Expected:
- All targeted tests pass
- Full suite passes
- Typecheck passes

