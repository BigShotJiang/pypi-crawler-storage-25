# Watchdog Meta-Loop Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a durable watchdog meta-loop above Ralphception's existing artifact-first Ralph loop engine so incomplete tasks can continue, unstick, compact, and re-enter execution without relying on a human to manually re-prompt the root thread.

**Architecture:** Keep the current conversational runtime and artifact-first stage machine. Add a new runtime-owned frontier ledger plus a root watchdog that can activate when the task is incomplete and idle. The watchdog resolves to constrained actions such as continuing the root thread, launching or reopening a Ralph loop, revising the plan, asking the user, compacting the root thread, or marking the task complete.

**Tech Stack:** Python 3.12/3.13, existing interactive session and prompt-state persistence, headless mission supervisor, Codex session manager, pytest, tmux, `uv`, `ty`.

---

### Task 1: Lock the current continuation gap in tests

**Files:**
- Modify: `tests/integration/test_headless_supervisor.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a failing runtime test for incomplete-but-idle work**

Create a scenario where a task has:
- approved artifacts
- an incomplete frontier
- no pending prompt
- no active run

Assert the runtime currently does nothing, so the test documents the missing continuation behavior.

- [ ] **Step 2: Add a failing test for transcript-only next steps**

Create a scenario where the active turn settles with "next steps" but does not create durable continuation state. Assert the runtime cannot automatically resume meaningful work.

- [ ] **Step 3: Add a failing tmux-oriented expectation**

Pin that the user-visible runtime should re-enter a working state when incomplete work is idle, rather than looking done.

- [ ] **Step 4: Run the focused tests and verify they fail**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL on the new watchdog/continuation assertions.

### Task 2: Add durable frontier state

**Files:**
- Create: `src/ralphception/runtime/frontier.py`
- Modify: `src/ralphception/runtime/interactive_session.py`
- Modify: `src/ralphception/runtime/prompt_state.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/models/runtime.py` if shared models are needed

- [ ] **Step 1: Add frontier models**

Add durable models for:
- `TaskFrontier`
- `FrontierItem`
- `StuckSignal`

The frontier must explicitly represent unfinished obligations instead of relying on transcript text.

- [ ] **Step 2: Persist frontier state alongside the interactive session/runtime**

Ensure the root task can record:
- completion state
- current active loop ids
- outstanding frontier items
- last progress time
- stuck counter

- [ ] **Step 3: Populate frontier state from existing runtime transitions**

Hook frontier updates into:
- startup/spec/plan completion
- loop launch/completion
- merge completion
- audit reopen
- blocker creation and resolution

- [ ] **Step 4: Re-run the focused frontier tests**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py -q`

Expected: PASS for frontier persistence and transition assertions.

### Task 3: Introduce a root watchdog definition and activation policy

**Files:**
- Create: `src/ralphception/runtime/watchdog.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/frontends.py` if new events are needed

- [ ] **Step 1: Add durable watchdog models**

Add:
- `WatchdogDefinition`
- `WatchdogActivation`
- `WatchdogAction`

The initial scope is one root-task watchdog per active task.

- [ ] **Step 2: Implement activation conditions**

Trigger the watchdog only when:
- the task is incomplete
- no pending prompt blocks on the user
- no run is active
- no approval is waiting
- frontier is non-empty
- cooldown elapsed
- idle or stuck threshold exceeded

- [ ] **Step 3: Emit runtime/frontend events for watchdog activation**

Add explicit events so transcript/TUI can show:
- watchdog armed
- watchdog activated
- watchdog chose next action

- [ ] **Step 4: Re-run focused watchdog activation tests**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_headless_supervisor.py -q`

Expected: PASS for root watchdog activation behavior.

### Task 4: Implement constrained watchdog actions

**Files:**
- Modify: `src/ralphception/runtime/watchdog.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/codex/session_manager.py` or related Codex glue if needed

- [ ] **Step 1: Add a failing test for watchdog decision resolution**

Assert the watchdog may resolve only to:
- `continue_root_turn`
- `launch_child_loop`
- `reopen_existing_loop`
- `revise_plan`
- `ask_user`
- `compact_root_thread`
- `mark_complete`

- [ ] **Step 2: Implement the root watchdog turn contract**

Materialize a real watchdog turn with:
- high-level task goal
- frontier snapshot
- relevant artifact refs
- recent transcript summary
- constrained action schema

- [ ] **Step 3: Wire each action back into the existing runtime**

Map watchdog outputs to existing rails:
- root continuation turn
- child loop launch/reopen
- plan revision path
- user blocker prompt
- completion path

- [ ] **Step 4: Re-run focused runtime tests**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py -q`

Expected: PASS for constrained watchdog action handling.

### Task 5: Add compaction as an explicit recovery primitive

**Files:**
- Create: `src/ralphception/runtime/compaction.py`
- Modify: `src/ralphception/runtime/watchdog.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/codex/session_manager.py`
- Modify: tests covering resume/thread behavior

- [ ] **Step 1: Add failing tests for compaction-triggered unsticking**

Create a repeated-summary or repeated-next-step scenario and assert the watchdog chooses `compact_root_thread` instead of blindly continuing.

- [ ] **Step 2: Implement a runtime compaction checkpoint**

Persist:
- compaction reason
- thread id
- summary artifact or summary text
- pre/post compact references

- [ ] **Step 3: Execute compaction through the Codex session substrate**

Use the session manager as the compaction boundary so the behavior mirrors Codex more closely and stays out of ad hoc transcript hacks.

- [ ] **Step 4: Re-run focused compaction tests**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS for explicit compaction recovery behavior.

### Task 6: Surface the watchdog loop in the TUI and transcript

**Files:**
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Modify: `tests/unit/codex_tui/*`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add transcript and status events for watchdog activity**

The user should be able to see:
- why the watchdog activated
- what it decided
- whether compaction or a new loop was launched

- [ ] **Step 2: Keep the surface Codex-like**

Render watchdog activity as settled transcript/status, not as a separate dashboard mode.

- [ ] **Step 3: Re-run the focused TUI/tmux tests**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

### Task 7: Verify the full upgrade and cleanly land it

**Files:**
- Update any touched test expectations or docs as required

- [ ] **Step 1: Run tmux verification**

Verify:
- normal startup intake
- task remains conversational
- incomplete idle work re-enters a working state automatically
- stuck/repetitive state triggers compaction recovery
- reopened loops still follow the existing artifact-first execution path

- [ ] **Step 2: Run the full verification suite**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 3: Run type checks and diff hygiene**

Run:
`PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

Run:
`git diff --check`

Expected: no output

- [ ] **Step 4: Merge and push**

Run:
```bash
git checkout main
git pull --ff-only
git merge --ff-only <feature-branch>
git push origin main
```

- [ ] **Step 5: Clean up**

Remove the feature worktree and branch after merge.

## Recommended Execution Order

Ship this in phases:

1. frontier ledger
2. root watchdog activation
3. constrained watchdog actions
4. compaction recovery
5. TUI/transcript surfacing

Do not start with parallel multi-watchdog orchestration. First prove one root watchdog can reliably keep a single artifact-first task moving.
