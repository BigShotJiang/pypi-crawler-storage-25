# Blocker Shell Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the first-turn blocker/reply shell behave more like Codex by removing the extra waiting row and fixing footer width math so the right-side context label stays intact.

**Architecture:** Keep the existing blocker state model, but stop projecting blocker state into a dedicated waiting row. The bottom pane should enter reply mode through its composer placeholder and footer alone. Also tighten footer layout so the two-space prefix is included in width accounting before rendering the right-aligned context label.

**Tech Stack:** Python, Codex TUI port, ANSI terminal renderer, pytest unit/tmux integration tests

---

### Task 1: Lock the blocker-shell regressions in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`

- [ ] **Step 1: Add a footer-width regression**

Assert that the reply footer keeps the full `100% context left` label while staying within the requested width.

- [ ] **Step 2: Add a blocker-shell regression**

Assert that blocker prompts switch the composer into reply mode without setting a separate `Waiting for your response` waiting line.

- [ ] **Step 3: Run targeted tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py -q`

Expected: failures on footer width and blocker waiting-line assertions.

### Task 2: Fix footer width accounting and blocker reply mode

**Files:**
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`

- [ ] **Step 1: Fix footer width math**

Include the left indentation prefix in width calculations and trim the left hint when necessary so the footer never overruns the viewport.

- [ ] **Step 2: Keep blocker state out of the waiting-line row**

Preserve blocker state internally, but render reply mode through the composer/footer only instead of adding a standalone waiting row above the composer.

### Task 3: Verify the live tmux blocker path

**Files:**
- No code changes required

- [ ] **Step 1: Re-run targeted tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: pass

- [ ] **Step 2: Re-run the real tmux first-turn blocker flow**

Verify:
- no `Waiting for your response` row appears above the reply composer
- the footer shows the full `100% context left`
- the reply shell stays aligned after the first prompt

### Task 4: Full verification and merge

**Files:**
- No code changes required

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: all tests pass

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 3: Run diff check**

Run: `git diff --check`

Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/status.py src/ralphception/codex_tui/ralph_adapter.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py docs/superpowers/plans/2026-03-26-blocker-shell-parity.md
git commit -m "fix: tighten blocker shell parity"
```
