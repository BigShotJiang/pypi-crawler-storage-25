# Post-Trust Input Drain And Notice Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve the Codex-style startup notice band after trust acceptance by draining any buffered trust-prompt keystrokes before the first real user-input cycle begins.

**Architecture:** Fix the real root cause in the terminal input path, not the render tree. Keep the existing trust prompt and post-trust viewport reset, but add a focused pending-input drain between trust acceptance and idle-shell handoff so the first prompt loop starts clean. Verify the drain is invoked in tests, then confirm the startup notice band survives in fresh tmux comparisons against `codex`.

**Tech Stack:** Python, pytest, tmux, ANSI terminal I/O, Ralphception Codex TUI

---

### Task 1: Pin The Buffered-Input Handoff Bug

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a failing trust-handoff test**

Write a focused test proving that trust acceptance triggers a pending-input drain before the idle shell is rendered. Use a small frontend test double that:
- returns `"trust"` from `prompt_trust_decision(...)`
- records whether `drain_pending_input()` was called

- [ ] **Step 2: Run the focused trust-handoff tests to verify failure**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_maybe_run_trust_onboarding_drains_pending_input_before_idle_shell -q
```

Expected: FAIL because the trust onboarding path does not yet drain pending input.


### Task 2: Implement The Minimal Input Drain

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a dedicated `drain_pending_input()` frontend hook**

Implement a method on `CodexTuiFrontend` that:
- no-ops for scripted/input-callback frontends
- drains immediately available bytes from the real stdin fd for terminal-backed frontends

Reuse the existing nonblocking-termios approach already used for escape-sequence draining rather than inventing a second terminal-drain mechanism.

- [ ] **Step 2: Call the drain during trust acceptance**

In `maybe_run_trust_onboarding(...)`, call `frontend.drain_pending_input()` after the trust decision is accepted and before the viewport reset / idle-shell render.

- [ ] **Step 3: Keep the fix narrowly scoped**

Do not rewrite the trust prompt or idle-shell renderer. The intent is only to clear leaked trust-input bytes so the first prompt cycle starts empty.


### Task 3: Verify The Targeted Behavior

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py` (only if more assertions are needed)

- [ ] **Step 1: Re-run the new focused test**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_maybe_run_trust_onboarding_drains_pending_input_before_idle_shell -q
```

Expected: PASS.

- [ ] **Step 2: Run the trust/startup subset**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_codex_tui_app.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/unit/test_project_trust.py -q
```

Expected: PASS.


### Task 4: Reproduce And Compare In Fresh tmux Sessions

**Files:**
- No code changes required unless tmux evidence shows the drain is insufficient

- [ ] **Step 1: Launch fresh tmux reference sessions**

Create new tmux sessions in fresh repos for:

```bash
codex
uv run ralphception
```

- [ ] **Step 2: Accept trust and capture the post-trust shell**

Expected Ralphception behavior after trust acceptance:
- no leaked `1` in the starter prompt
- startup notice band remains visible in the live viewport
- no immediate Socratic follow-up caused by the trust key being misread as the first prompt

- [ ] **Step 3: Compare against Codex**

Confirm that the post-trust handoff remains Codex-like:
- trust prompt in scrollback
- live header starts cleanly
- idle starter shell appears before any real user prompt is consumed


### Task 5: Final Verification And Integration

**Files:**
- No additional code changes expected

- [ ] **Step 1: Run the full test suite**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
```

Expected: PASS.

- [ ] **Step 2: Run type checks**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
```

Expected: `All checks passed!`

- [ ] **Step 3: Run tree hygiene checks**

Run:

```bash
git diff --check
git status --short --branch
```

Expected: clean diff-check output and only intended changes before commit.

- [ ] **Step 4: Commit and merge**

Run:

```bash
git add src/ralphception/codex_tui/app.py tests/integration/test_codex_tui_tmux.py docs/superpowers/plans/2026-03-26-post-trust-input-drain-and-notice-parity.md
git commit -m "fix: drain trust input before startup shell"
```

- [ ] **Step 5: Fast-forward `main`, rerun merged verification, push, and clean up**

Fast-forward `main`, rerun the merged verification on `main`, push `origin/main`, then remove the worktree, feature branch, and temporary tmux comparison sessions.
