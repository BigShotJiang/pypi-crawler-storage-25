# Codex TUI Notice Stack Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the missing startup notice band from the Codex tmux shell into Ralphception's human TUI so the area above the prompt/header no longer sits artificially empty.

**Architecture:** Keep the existing Python Codex-style terminal core and add a small, explicit notice-stack layer to the live viewport render tree. The notice stack should be generic and reusable, but the first shipped content should be a Ralphception-appropriate startup tip instead of copied Codex product/quota notices.

**Tech Stack:** Python 3.12, pytest, tmux, custom ANSI terminal rendering, Ralphception Codex TUI port

---

### Task 1: Add Failing Notice-Stack Rendering Tests

**Files:**
- Modify: `tests/unit/codex_tui/test_chatwidget.py`
- Modify: `tests/unit/codex_tui/test_ralph_adapter.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Write the failing chatwidget and adapter tests**

Add tests that assert:
- the live viewport can render one or more notice rows between the header card and the prompt area
- idle startup state can surface a Ralphception-specific notice line without disturbing the starter prompt, spacer row, or footer layout
- multiline notices wrap cleanly within the viewport width

- [ ] **Step 2: Run the focused tests to verify failure**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL because the current live viewport has no notice-stack concept and leaves the startup band empty.

- [ ] **Step 3: Commit the red phase if useful context needs preserving**

```bash
git add tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py
git commit -m "test: cover codex tui notice stack parity"
```

### Task 2: Implement A Generic Notice Stack And Ship A Startup Tip

**Files:**
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`

- [ ] **Step 1: Add notice-stack support to the render tree**

Teach `ChatWidget` to accept `notice_lines` and render them between the header block and the active-cell/prompt region, with wrapping that matches the viewport width.

- [ ] **Step 2: Add Ralphception notice-copy helpers**

In `status.py`, define the shipped startup notice text and any tiny formatting helpers needed so the notice content is explicit and reusable instead of being buried in the adapter.

- [ ] **Step 3: Project the notice into the idle human shell**

Update `RalphAdapter` so the idle startup shell includes the startup tip notice, while active blocker/reply/busy states can clear or replace the notice area later without disturbing the bottom-pane state.

- [ ] **Step 4: Run the focused tests to verify green**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

- [ ] **Step 5: Commit the implementation slice**

```bash
git add src/ralphception/codex_tui/chatwidget.py src/ralphception/codex_tui/status.py src/ralphception/codex_tui/ralph_adapter.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py
git commit -m "feat: add codex tui notice stack"
```

### Task 3: Verify In Fresh tmux Sessions Against `codex`

**Files:**
- No code changes required unless tmux verification exposes another concrete parity gap

- [ ] **Step 1: Port fresh-repo trust onboarding if the tmux reference shows it**

If fresh tmux comparison shows `codex` opening with the directory-trust prompt instead of the idle shell, add a matching Ralphception startup gate for undecided repositories before the normal idle shell appears. Persist the trust decision so later launches in the same repo skip the prompt.

- [ ] **Step 2: Add trust-onboarding tests first**

Cover:
- fresh untrusted repo shows the trust prompt
- accepting trust persists the decision and opens the normal idle shell
- declining trust quits cleanly

- [ ] **Step 3: Run focused trust tests to verify red then green**

Run the focused Codex TUI startup tests before and after the implementation so the trust gate is proven by TDD rather than hand-checked only in tmux.

- [ ] **Step 1: Capture fresh idle startup in tmux**
- [ ] **Step 4: Capture fresh startup in tmux**

Launch fresh tmux sessions for:
- `codex`
- `uv run ralphception`

Capture both idle shells and confirm the notice band is no longer visually empty in Ralphception.

- [ ] **Step 5: Verify first-turn behavior**

Submit the first prompt in Ralphception and confirm:
- the notice band remains compatible with the first committed user turn
- the Socratic follow-up still appears correctly
- committed history still scrolls above the live viewport

- [ ] **Step 6: Run full merged verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite PASS
- typecheck PASS
- diff check clean

- [ ] **Step 7: Merge to `main`, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/codex-tui-notice-stack
git push origin main
git branch -d feat/codex-tui-notice-stack
git worktree remove /private/tmp/ralphception-notice-stack.rjYcoO
```
