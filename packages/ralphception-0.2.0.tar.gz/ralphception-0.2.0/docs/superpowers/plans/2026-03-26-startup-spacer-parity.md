# Startup Spacer Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve a clean blank spacer between the flushed startup notice band and the first committed user prompt so the first-turn scrollback layout matches Codex more closely.

**Architecture:** Adjust the committed startup shell history cell only. The live shell already owns its own spacer. The fix should append a trailing blank line after committed notice-band rendering so the first real transcript cell does not butt directly against the startup shell content.

**Tech Stack:** Python, Codex TUI port, ANSI terminal renderer, pytest unit/tmux integration tests

---

### Task 1: Lock the committed startup-shell spacer regression

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a unit regression for `StartupShellHistoryCell`**

Assert that a startup shell with notice lines ends with a blank spacer line after the notice band.

- [ ] **Step 2: Add an integration regression for first-prompt flush**

Assert that the flushed startup shell committed by the first prompt is a `StartupShellHistoryCell` whose rendered lines end with a blank spacer.

- [ ] **Step 3: Run targeted tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: failures showing the committed startup shell ends directly on the final notice line.

### Task 2: Add the spacer to committed startup history

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`

- [ ] **Step 1: Keep live-shell rendering unchanged**

Do not touch the live startup shell path in `ChatWidget`; only adjust the committed startup shell history cell.

- [ ] **Step 2: Append the trailing blank spacer**

Update `StartupShellHistoryCell.display_lines()` so it adds a blank line after rendered notice lines.

### Task 3: Verify first-turn tmux parity

**Files:**
- No code changes required

- [ ] **Step 1: Re-run targeted tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: pass

- [ ] **Step 2: Re-run the real tmux first-prompt path**

Verify the committed startup shell leaves a visible spacer between the notice band and the first user prompt.

### Task 4: Full verification and merge

**Files:**
- No code changes required

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: all tests pass

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 3: Run diff check**

Run: `git diff --check`

Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/history_cell.py tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py docs/superpowers/plans/2026-03-26-startup-spacer-parity.md
git commit -m "fix: preserve startup shell spacer"
```
