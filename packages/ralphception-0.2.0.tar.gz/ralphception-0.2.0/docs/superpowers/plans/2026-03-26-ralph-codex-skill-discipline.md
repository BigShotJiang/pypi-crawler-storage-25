# Ralph Codex Skill Discipline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Strengthen Ralphception's packaged Codex skills so the startup, spec, plan, execute, and audit stages are driven by repo-local Ralph loop skills instead of thin placeholder guidance.

**Architecture:** The packaged `SKILL.md` files become the primary stage-behavior layer. Small prompt-contract changes are allowed only where needed to reinforce startup or stage boundaries, while deterministic artifact contracts stay in `startup_llm.py` and `headless.py`. Tests pin the key behavioral rules inside the packaged skills so later edits cannot hollow them out.

**Tech Stack:** Python 3.12, packaged markdown resources, pytest, ty

---

## File Map

**Create**
- `docs/superpowers/specs/2026-03-26-ralph-codex-skill-discipline-design.md`
- `docs/superpowers/plans/2026-03-26-ralph-codex-skill-discipline.md`

**Modify**
- `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- `src/ralphception/codex_skills/ralph-spec-writing/SKILL.md`
- `src/ralphception/codex_skills/ralph-plan-writing/SKILL.md`
- `src/ralphception/codex_skills/ralph-execute-task/SKILL.md`
- `src/ralphception/codex_skills/ralph-audit-review/SKILL.md`
- `src/ralphception/runtime/startup_llm.py`
- `tests/unit/test_codex_skill_materialize.py`
- `tests/unit/test_startup_llm.py`
- `tests/unit/test_headless_contracts.py`

### Task 1: Pin The Missing Skill Discipline In Tests

**Files:**
- Modify: `tests/unit/test_codex_skill_materialize.py`
- Modify: `tests/unit/test_startup_llm.py`

- [ ] **Step 1: Write failing packaged-skill assertions**

Add tests that assert the installed skill bundle includes:
- startup guidance for one-question-at-a-time Socratic intake, no permission-seeking, repo-wide default access, and intake-summary stop conditions
- spec guidance for goal, scope, non-goals, architecture, risks, and acceptance criteria
- plan guidance for file maps, bite-sized tasks, TDD-first verification, and exact commands
- execute guidance for red-green verification, minimal changes, and evidence-before-completion
- audit guidance for findings-first review with merged diff, touched-path, and verification evidence

- [ ] **Step 2: Run the focused tests to verify RED**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_skill_materialize.py tests/unit/test_startup_llm.py -q`

Expected: FAIL because the current packaged skills are too thin.

### Task 2: Rewrite The Packaged Ralphception Skills

**Files:**
- Modify: `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-spec-writing/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-plan-writing/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-execute-task/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-audit-review/SKILL.md`

- [ ] **Step 1: Expand startup intake**

Add repo-local startup guidance that mirrors superpowers brainstorming:
- assume whole-repo access
- one question per turn
- ask the minimum necessary questions
- avoid permission requests
- stop once the intake summary is sufficient

- [ ] **Step 2: Expand spec and plan writing**

Add PRD structure and plan-writing structure:
- spec sections
- plan file-map discipline
- bite-sized tasks
- TDD-first verification commands
- Ralphception JSON artifact expectations

- [ ] **Step 3: Expand execute and audit**

Add execution/audit discipline:
- execution must verify behavior before claiming done
- audit must lead with findings, prefer repo-local evidence, and emit empty findings cleanly when no issue exists

- [ ] **Step 4: Run the focused tests to verify GREEN**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_skill_materialize.py tests/unit/test_startup_llm.py -q`

Expected: PASS

### Task 3: Tighten Prompt Contracts Only Where Needed

**Files:**
- Modify: `src/ralphception/runtime/startup_llm.py`
- Modify: `tests/unit/test_headless_contracts.py`

- [ ] **Step 1: Add failing assertions if prompt reinforcement is missing**

Pin any missing startup/stage prompt wording needed to keep the skill-driven path deterministic, especially the no-permission and first-turn follow-up rules.

- [ ] **Step 2: Implement the minimal prompt reinforcement**

Adjust `startup_llm.py` only if the skill tests show the live startup contract still leaves room for heuristic drift.

- [ ] **Step 3: Run the prompt-contract slice**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_headless_contracts.py tests/unit/test_startup_llm.py -q`

Expected: PASS

### Task 4: Verify, Merge, And Clean Up

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-ralph-codex-skill-discipline.md`

- [ ] **Step 1: Run the targeted verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_skill_materialize.py tests/unit/test_startup_llm.py tests/unit/test_headless_contracts.py -q`

Expected: PASS

- [ ] **Step 2: Run the full suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 3: Run static verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 4: Run diff hygiene**

Run: `git diff --check`

Expected: no output

- [ ] **Step 5: Merge, push, and clean up**

Run:
- `git add ...`
- `git commit -m "feat: strengthen ralph codex skill discipline"`
- `git checkout main`
- `git merge --ff-only feat/skill-discipline`
- `git push origin main`
- `git worktree remove .worktrees/feat-skill-discipline`
- `git branch -d feat/skill-discipline`

Expected: merged `main`, pushed, and only the root worktree remains.
