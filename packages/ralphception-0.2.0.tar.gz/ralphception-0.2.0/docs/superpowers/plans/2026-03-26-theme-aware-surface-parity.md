# Theme-Aware Surface Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port Codex-style theme-aware user/composer surface rendering so Ralphception adapts cleanly to light and dark terminal backgrounds in tmux.

**Architecture:** Extend the Python Codex TUI style layer to support RGB ANSI colors and blended surface backgrounds derived from the detected terminal background. Thread that surface style through committed user transcript cells and the live bottom composer so both startup and first-turn conversation match Codex more closely in light and dark themes.

**Tech Stack:** Python 3.13, tmux, ANSI escape sequences, pytest

---

### Task 1: Document the Codex parity target in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_styled_text.py`
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/unit/codex_tui/test_chatwidget.py`

- [ ] **Step 1: Write failing styled-text tests for RGB ANSI output**

Add tests that assert `Style(bg=(244, 244, 244)).sgr_prefix()` emits a truecolor `48;2;244;244;244` background sequence and that the same works for `fg=(10, 20, 30)`.

- [ ] **Step 2: Run the new styled-text tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q`
Expected: FAIL because `Style` only accepts named colors today.

- [ ] **Step 3: Write failing theme-aware surface tests**

Add tests that pin Codex-like behavior:
- light terminal backgrounds produce a subtly darkened user/composer surface
- dark terminal backgrounds produce a subtly lightened user/composer surface
- user transcript rows and the composer prompt surface use that derived background instead of hard-coded `bright_black`

- [ ] **Step 4: Run the new history/chatwidget tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: FAIL because user surfaces are still hard-coded to `bright_black`.

- [ ] **Step 5: Commit the failing-test checkpoint**

```bash
git add tests/unit/codex_tui/test_styled_text.py tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_chatwidget.py
git commit -m "test: pin codex theme-aware surface parity"
```

### Task 2: Implement RGB-capable styles and blended surface helpers

**Files:**
- Modify: `src/ralphception/codex_tui/styled_text.py`
- Create: `src/ralphception/codex_tui/theme.py`
- Test: `tests/unit/codex_tui/test_styled_text.py`

- [ ] **Step 1: Add minimal failing helper tests for Codex-like blending math**

In `tests/unit/codex_tui/test_styled_text.py` or a new `tests/unit/codex_tui/test_theme.py`, assert that:
- light backgrounds blend toward black at 4%
- dark backgrounds blend toward white at 12%
- missing terminal background falls back to no themed surface override

- [ ] **Step 2: Run the helper tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q`
Expected: FAIL because no theme helper exists yet.

- [ ] **Step 3: Implement minimal RGB and theme helpers**

Implement:
- RGB foreground/background support in `Style`
- ANSI emission for truecolor RGB styles
- a `theme.py` helper that ports the Codex blend logic for user/composer surfaces

- [ ] **Step 4: Run the styled-text/theme tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_styled_text.py -q`
Expected: PASS

- [ ] **Step 5: Commit the style-layer implementation**

```bash
git add src/ralphception/codex_tui/styled_text.py src/ralphception/codex_tui/theme.py tests/unit/codex_tui/test_styled_text.py
git commit -m "feat: add codex-style themed surfaces"
```

### Task 3: Apply themed surfaces to transcript and composer rendering

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/app.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`
- Test: `tests/unit/codex_tui/test_chatwidget.py`

- [ ] **Step 1: Thread a terminal background / surface style through the render path**

Add the smallest possible plumbing so history cells and the bottom pane can render with a computed surface background, while preserving current behavior when no palette is available.

- [ ] **Step 2: Run the targeted unit tests to confirm any remaining failures**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: FAIL until all user/composer surfaces stop using the hard-coded fallback.

- [ ] **Step 3: Implement the minimal rendering changes**

Update:
- user transcript surfaces
- multiline continuation rows
- composer prompt background
- composer spacer row padding

to use the derived themed surface when available.

- [ ] **Step 4: Run the targeted unit tests to verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_chatwidget.py -q`
Expected: PASS

- [ ] **Step 5: Commit the render-path integration**

```bash
git add src/ralphception/codex_tui/history_cell.py src/ralphception/codex_tui/bottom_pane.py src/ralphception/codex_tui/chatwidget.py src/ralphception/codex_tui/app.py tests/unit/codex_tui/test_history_cell.py tests/unit/codex_tui/test_chatwidget.py
git commit -m "feat: theme codex tui transcript surfaces"
```

### Task 4: Verify in tmux against Codex and finish the branch

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add or tighten the tmux integration assertions**

Extend the tmux capture test so it asserts the startup shell and first user prompt remain legible in light-theme conditions and that the viewport still stays anchored correctly after the first prompt.

- [ ] **Step 2: Run the tmux-focused integration test**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`
Expected: PASS

- [ ] **Step 3: Run the full verification suite**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- no diff-check issues

- [ ] **Step 4: Verify manually in fresh tmux sessions against Codex**

Run side-by-side manual checks:
- `codex`
- `uv run ralphception`

Confirm:
- startup shell shape remains aligned
- user/composer surfaces look correct in the active light terminal theme
- first prompt and first Socratic follow-up no longer feel visually jarring versus Codex

- [ ] **Step 5: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/theme-aware-surfaces
git push origin main
git worktree remove .worktrees/feat-theme-aware-surfaces
git branch -d feat/theme-aware-surfaces
```
