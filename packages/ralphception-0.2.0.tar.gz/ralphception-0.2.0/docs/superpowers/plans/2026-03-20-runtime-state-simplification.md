# Runtime State Simplification Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `.ralphception` disposable runtime state and make terminal execution fail fast when no live backend is configured.

**Architecture:** Move checked-in bootstrap/reference content out of `.ralphception`, ignore `.ralphception/` in git, and treat the entire directory as runtime-owned state. Add an explicit runtime error for missing terminal backend availability so the CLI exits cleanly instead of degrading to dashboard mode.

**Tech Stack:** Python 3.12+, `typer`, shared runtime supervisor, git ignore/index changes, `pytest`

---

## File Map

- Modify: `.gitignore`
  Ignore `.ralphception/` directly.
- Modify: `src/ralphception/runtime/supervisor.py`
  Add explicit terminal backend availability checks.
- Modify: `src/ralphception/headless.py`
  Stop returning dashboard mode for no-backend terminal runs.
- Modify: `src/ralphception/cli.py`
  Render clean backend-unavailable errors.
- Modify: `README.md`
  Clarify `.ralphception` is ephemeral runtime state and document backend requirements.
- Modify: `tests/integration/test_terminal_frontend.py`
  Add fail-fast no-backend coverage.
- Modify: `tests/unit/test_cli_bootstrap.py`
  Add CLI error rendering coverage.

## Task 1: Lock fail-fast behavior with tests

- [ ] Add a terminal integration test that running with a seed prompt and no backend raises a clean backend-unavailable error.
- [ ] Add a CLI test that the terminal command exits non-zero and prints the backend error.
- [ ] Run the targeted tests and confirm they fail before implementation.

## Task 2: Implement backend fail-fast behavior

- [ ] Add a dedicated runtime error for missing terminal backend availability.
- [ ] Raise it before runtime output implies active mission execution.
- [ ] Keep `--fake-session-manager` and real backend execution paths unchanged.
- [ ] Re-run the targeted tests and confirm they pass.

## Task 3: Make `.ralphception` untracked runtime state

- [ ] Add `.ralphception/` to `.gitignore`.
- [ ] Remove currently tracked runtime files from the git index.
- [ ] Update any docs/tests that assumed checked-in runtime files.

## Task 4: Verify the simplified model end to end

- [ ] Run `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- [ ] Run `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- [ ] Run `uv run ralphception terminal --seed-prompt 'find any bugs'` on this repo and confirm it fails fast with the backend error instead of reviving saved mission state or falling into dashboard mode.
