# 2026-03-26 Narrow Pane Header Clamp Parity

## Goal

Fix the live Codex-style startup shell in narrow tmux panes so the session
header card does not wrap across terminal lines.

## Repro

In a 40-column tmux pane, the current Ralphception startup card overflows:

- the top and bottom borders wrap onto a second terminal line
- the title/model/directory rows wrap inside the box

Codex clamps the header card to the available width instead of allowing the box
to overflow.

## Plan

1. Add failing tests for narrow-width header rendering:
   - `render_session_header_card(..., max_width=40)` must keep every line within 40 columns
   - the live `ChatWidget` header rendered through `RalphTuiAdapter` must also stay within the viewport
2. Change the live header path so it renders against the current viewport width instead of a static pre-rendered 44-column card.
3. Clamp styled header rows before boxing so the frame itself never exceeds the target width.
4. Re-run focused unit tests, then a narrow tmux smoke, then the full suite and typecheck.
5. Merge to `main`, push, and remove the feature worktree.
