# Codex Scrollback Stability Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Preserve committed transcript/history lines in tmux when the Codex-style live viewport shrinks, moves, or redraws during Ralphception loop execution.

**Architecture:** Keep the current Codex-led Python terminal port, but tighten the viewport clearing and history insertion semantics so rows that have been promoted into terminal scrollback are never cleared by later live-frame redraws. Lock the fix with low-level terminal tests and a higher-level TUI regression that simulates the disappearing `Launched ...` rows.

**Tech Stack:** Python 3.12, ANSI terminal control, tmux-based verification, pytest.

---

### Task 1: Reproduce The Scrollback Wipe At The Terminal Layer

**Files:**
- Modify: `tests/unit/codex_tui/test_custom_terminal.py`
- Modify: `tests/unit/codex_tui/test_insert_history.py`

- [ ] **Step 1: Add a failing viewport-clear regression**

Cover the case where:
- a previous live frame occupied taller bottom rows
- committed history gets inserted above the new shorter viewport
- a later redraw must not clear rows above the new viewport top

- [ ] **Step 2: Add a failing history-persistence regression**

Cover the case where:
- committed lines are inserted
- the live viewport redraws with a shorter height and updated status
- the terminal write stream does not issue clears over the promoted history rows

- [ ] **Step 3: Run the targeted terminal tests and verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py -q`
Expected: FAIL on the new scrollback persistence assertions

### Task 2: Fix Viewport Clearing So Scrollback Stays Durable

**Files:**
- Modify: `src/ralphception/codex_tui/custom_terminal.py`
- Modify: `src/ralphception/codex_tui/tui.py`
- Modify: `src/ralphception/codex_tui/insert_history.py`

- [ ] **Step 1: Narrow frame clearing to true live-viewport rows**

Only clear:
- the current live frame area
- any stale rows below the new frame when the old frame was taller

Do not clear rows above the new viewport top just because the previous frame was taller or higher.

- [ ] **Step 2: Re-check history insertion ordering**

Confirm pending history insertion happens before the live frame draw and does not get invalidated by a follow-up clear.

- [ ] **Step 3: Run the targeted terminal tests and verify they pass**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py -q`
Expected: PASS

### Task 3: Lock The Real Ralphception Regression

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `src/ralphception/codex_tui/app.py` if needed
- Modify: `src/ralphception/codex_tui/ralph_adapter.py` only if event draining order also contributes

- [ ] **Step 1: Add a higher-level regression for durable loop milestones**

Simulate:
- startup question
- user scope reply
- committed milestone lines (`Wrote ...`, `Launched ...`)
- a later status-only redraw

Assert the committed launch lines remain in committed output / scrollback state instead of disappearing.

- [ ] **Step 2: Run the focused Codex-TUI suite and verify the new regression fails first if needed**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py tests/integration/test_codex_tui_tmux.py tests/integration/test_terminal_frontend.py -q`

- [ ] **Step 3: Make the minimum integration fix**

Only patch adapter/app ordering if the low-level terminal fix alone does not resolve the higher-level disappearance.

- [ ] **Step 4: Re-run the focused Codex-TUI suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py tests/integration/test_codex_tui_tmux.py tests/integration/test_terminal_frontend.py -q`
Expected: PASS

### Task 4: Verify Against Real tmux And Codex

**Files:**
- No code changes expected

- [ ] **Step 1: Re-run live tmux comparison against `codex`**

Use fresh tmux sessions in a throwaway repo and compare:
- startup shell shape
- first prompt behavior
- Socratic follow-up
- committed milestone lines while the loop keeps running
- later status updates do not erase prior committed rows

- [ ] **Step 2: Run repo-wide verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

- [ ] **Step 3: Commit**

```bash
git add src/ralphception/codex_tui/custom_terminal.py src/ralphception/codex_tui/tui.py src/ralphception/codex_tui/insert_history.py src/ralphception/codex_tui/app.py src/ralphception/codex_tui/ralph_adapter.py tests/unit/codex_tui/test_custom_terminal.py tests/unit/codex_tui/test_insert_history.py tests/integration/test_codex_tui_tmux.py tests/integration/test_terminal_frontend.py docs/superpowers/plans/2026-03-26-codex-scrollback-stability.md
git commit -m "fix: preserve codex scrollback history"
```
