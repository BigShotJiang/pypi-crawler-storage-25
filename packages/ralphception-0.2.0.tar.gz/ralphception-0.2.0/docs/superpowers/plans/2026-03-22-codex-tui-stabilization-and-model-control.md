# Codex TUI Stabilization And Model Control Plan

> **For agentic workers:** REQUIRED: Use superpowers:test-driven-development for each chunk. Steps use checkbox (`- [ ]`) syntax for tracking. Execute this plan in small loops, committing after every chunk.

**Goal:** Fix the current Ralphception TUI so it behaves like the Codex terminal app instead of merely resembling a screenshot: the composer must stay usable while runs are active, command/log streaming must accumulate and scroll instead of appearing/disappearing, the header must be driven by real Ralphception runtime/config state, and `/model` must work like Codex while remaining native to Ralphception’s product semantics.

**Architecture:** Keep the public product contract (`ralphception` launches the TUI), but tighten the implementation around Codex’s actual app-server shell structure. The bottom pane owns a stable local composer buffer and popup/view stack. The transcript owns stable committed history plus a live active cell that receives deltas without replacing prior output. The session header is populated from real Ralphception config/runtime state, not preview defaults. Model selection is surfaced through a Codex-style command and picker flow that persists back to Ralphception config.

**Tech Stack:** Python 3.13, Textual, pytest, Ralphception runtime/supervisor/bootstrap models, Ralphception config persistence, Codex `tui_app_server` Rust sources under `~/code/codex`

---

## Problem Statement

The current shell has four concrete failures that block it from being a usable Codex-style TUI:

1. the empty composer is oversized and feels like a dead dashboard slab instead of Codex’s compact idle input
2. live command/log output does not accumulate and scroll reliably; cells appear and disappear during ticks
3. runtime ticks clear or overwrite the user’s in-progress draft while work is running
4. the top header still reads like a copied Codex card instead of a dynamic Ralphception session header with a real `/model` flow

This plan is specifically about correcting those failures with Codex-derived implementation behavior. It is not a cosmetic restyle.

## Non-Negotiable Acceptance Criteria

- `uv run ralphception` opens with a compact idle composer that does not dominate the screen when empty
- typing into the composer while the runtime is busy never loses the local draft unless the user explicitly submits, queues, or accepts an external edit
- command/log output grows monotonically in the transcript and remains visible after commit; it does not flicker out during adapter updates
- the transcript viewport follows live output when the user is at the bottom and preserves manual scroll position when they are not
- the header shows the actual current Ralphception model, reasoning, latency profile, and working directory
- `/model` opens a real picker flow, updates the active shell state, and persists to Ralphception config
- no remaining header/footer strings are copied from Codex marketing/status copy unless they are intentionally driven by equivalent Ralphception state

## Current Failure Map

**Observed Ralphception files and responsibilities**

- `src/ralphception/tui/app.py`
  Current shell root, CSS, slash-command dispatch, and top-level event wiring. The current `TextArea` and `#bottom-pane` sizing rules are part of the empty-composer problem.
- `src/ralphception/tui/runtime_adapter.py`
  Live runtime projection, queue/draft handling, transcript mutation, and footer/header refreshes. This is the likely source of draft loss and disappearing active output.
- `src/ralphception/tui/render_state.py`
  Shared shell dataclasses plus `RenderState.idle_preview()`. This still seeds header/footer/composer defaults that can leak into the live shell.
- `src/ralphception/tui/bottom_pane/chat_composer.py`
  The current `TextArea`-backed composer. Needs a Codex-style compact idle state, growth rules, and a hard boundary between local draft state and adapter-driven state.
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
  Bottom-pane state owner and the current draft-preservation logic. This is the first place to harden against tick-driven draft clearing.
- `src/ralphception/tui/chatwidget/transcript_view.py`
  Current transcript widget; still too stateless to guarantee stable scrolling and active-cell persistence.
- `src/ralphception/tui/chatwidget/transcript_cells.py`
  Current cell grammar; must become the stable owner of accumulating live command/log output.
- `src/ralphception/tui/chatwidget/session_header.py`
  Current header widget; structure is Codex-like, but the data source still needs to become fully Ralphception-driven.
- `src/ralphception/config.py`
  Existing persisted Codex config model for Ralphception (`model`, `reasoning`, `latency_profile`, etc.). `/model` must use this instead of inventing a new state store.
- `src/ralphception/headless.py`
  Source of runtime progress events. May need minimal event-shape tightening if the adapter cannot distinguish stable log accumulation from status churn.

**Important execution note**

The working tree already contains uncommitted changes in `src/ralphception/headless.py` and `src/ralphception/tui/runtime_adapter.py`. Do not overwrite or revert those blindly while executing this plan. Reconcile them intentionally at the start of the implementation loop.

## Codex Reference Map

Treat these Codex modules as the primary implementation references for this stabilization pass:

- `~/code/codex/codex-rs/tui_app_server/src/app.rs`
- `~/code/codex/codex-rs/tui_app_server/src/chatwidget.rs`
- `~/code/codex/codex-rs/tui_app_server/src/chatwidget/session_header.rs`
- `~/code/codex/codex-rs/tui_app_server/src/status/card.rs`
- `~/code/codex/codex-rs/tui_app_server/src/status/helpers.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/bottom_pane_view.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/chat_composer.rs`
- `~/code/codex/codex-rs/tui_app_server/src/bottom_pane/footer.rs`
- `~/code/codex/codex-rs/tui_app_server/src/slash_command.rs`
- `~/code/codex/codex-rs/tui_app_server/src/history_cell.rs`

Specific Codex behaviors to port for this plan:

- dynamic session header model binding via `chatwidget.rs` and `chatwidget/session_header.rs`
- `/model` dispatch and model/reasoning popup flow via `chatwidget.rs`
- compact status/header composition via `status/card.rs` and `status/helpers.rs`
- bottom-pane composer sizing, draft ownership, and popup routing via `bottom_pane/chat_composer.rs` and `bottom_pane/bottom_pane_view.rs`
- stable streaming/active-cell transcript behavior via `chatwidget.rs` and `history_cell.rs`

## Execution Rules

- Follow strict red-green-refactor for each task. No production edits before a failing test captures the current bug.
- Prefer replacing unstable state transitions over layering more “preserve this if maybe unchanged” patches on top.
- Do not hardcode Codex-specific quota strings, marketing text, or placeholder copy just to match the screenshot.
- Do not let adapter ticks call `load_text()` or otherwise reset the composer unless the runtime is intentionally applying an external edit.
- Keep the shell visibly usable after every chunk; do not leave the app in a half-ported broken state between chunks.
- After every chunk, run the listed verification commands before committing.

## File Structure Before Task Execution

Use this file map while implementing the plan:

- `src/ralphception/tui/app.py`
  Root shell composition, CSS sizing, slash-command routing, shell-level bindings.
- `src/ralphception/tui/render_state.py`
  Stable shell state, header/footer/composer/transcript dataclasses, preview defaults.
- `src/ralphception/tui/runtime_adapter.py`
  Runtime event reduction, draft queueing, active thread state, header/footer status projection.
- `src/ralphception/tui/chatwidget/session_header.py`
  Header widget and header rendering helpers.
- `src/ralphception/tui/chatwidget/transcript_view.py`
  Transcript widget, scrolling policy, active-vs-committed rendering.
- `src/ralphception/tui/chatwidget/transcript_cells.py`
  Command/log/assistant/system/user cells and delta accumulation.
- `src/ralphception/tui/bottom_pane/chat_composer.py`
  Input widget behavior, idle height, popup routing, local draft preservation.
- `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
  Bottom-pane ownership, popups, queued message previews, active view stack.
- `src/ralphception/tui/bottom_pane/footer.py`
  Footer/status composition.
- `src/ralphception/config.py`
  Config persistence for model/reasoning/latency settings.
- `tests/integration/test_tui_bottom_pane.py`
  Bottom-pane layout, composer, popup, and queue behavior.
- `tests/integration/test_tui_runtime_app.py`
  Live TUI integration over the runtime adapter.
- `tests/integration/test_tui_session_header.py`
  Header rendering and live updates.
- `tests/integration/test_tui_transcript.py`
  Transcript rendering, active cell accumulation, command/history persistence.
- `tests/unit/test_tui_runtime_adapter.py`
  Runtime reduction correctness and draft/header/footer state transitions.

---

## Chunk 1: Freeze The Regressions With Failing Tests

### Task 1: Capture the current failures directly in tests

**Files:**

- Modify: `tests/integration/test_tui_bottom_pane.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/integration/test_tui_session_header.py`
- Modify: `tests/integration/test_tui_transcript.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Add a failing bottom-pane sizing test**

  Add an integration test that mounts the idle shell and asserts the composer occupies a compact idle height. The assertion should be in visible layout terms, not implementation internals.

- [ ] **Step 2: Add a failing draft-preservation test**

  Add a runtime-backed app test that starts a live run, types a partial draft without submitting it, triggers runtime updates, and asserts the draft and cursor position remain intact.

- [ ] **Step 3: Add a failing transcript accumulation/scroll test**

  Add tests that feed multiple command-output deltas through the adapter and assert:

  - active output accumulates instead of replacing prior lines
  - committed output remains visible after command completion
  - the transcript widget exposes enough state to keep following the tail

- [ ] **Step 4: Add a failing dynamic-header and `/model` test**

  Add tests that assert:

  - header fields come from live Ralphception config/runtime state
  - `/model` exists as a slash command entry
  - submitting `/model` opens a model-selection flow instead of becoming a dead command

- [ ] **Step 5: Run the focused test set and verify failure**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: FAIL on all four complaint areas.

- [ ] **Step 6: Commit the red tests**

  ```bash
  git add tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "test: capture codex tui stabilization regressions"
  ```

## Chunk 2: Make The Composer Compact And Stop Draft Loss

### Task 2: Port Codex-style idle composer sizing and local draft ownership

**Codex references:**

- `codex-rs/tui_app_server/src/bottom_pane/chat_composer.rs`
- `codex-rs/tui_app_server/src/bottom_pane/bottom_pane_view.rs`

**Files:**

- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/bottom_pane/chat_composer.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/render_state.py`

- [ ] **Step 1: Shrink the idle composer to Codex-like compact height**

  Replace the current oversized `TextArea` presentation so an empty composer sits at a compact single-line or minimal multiline height and only grows when content warrants it.

- [ ] **Step 2: Split local draft state from adapter refresh state**

  Make the bottom pane the authoritative owner of the in-progress local draft while a run is active. Runtime ticks may update status, transcript, and footer, but must not overwrite the local composer buffer unless the runtime is intentionally applying an external edit.

- [ ] **Step 3: Preserve cursor position and draft across recomposition**

  Ensure `set_state()`/recompose paths do not call `load_text()` when the incoming state is semantically unchanged relative to the local draft.

- [ ] **Step 4: Keep queue/submit paths explicit**

  Clear the composer only on explicit submit/queue/edit-last-queued flows. Do not clear it on unrelated runtime updates, polling intervals, or status changes.

- [ ] **Step 5: Re-run the focused tests**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for composer sizing and draft-preservation cases.

- [ ] **Step 6: Commit the chunk**

  ```bash
  git add src/ralphception/tui/app.py src/ralphception/tui/bottom_pane/chat_composer.py src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/runtime_adapter.py src/ralphception/tui/render_state.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "fix: preserve composer draft and compact idle input"
  ```

## Chunk 3: Make Command Output Stable, Accumulative, And Scrollable

### Task 3: Port Codex-style active command/log cell behavior

**Codex references:**

- `codex-rs/tui_app_server/src/chatwidget.rs`
- `codex-rs/tui_app_server/src/history_cell.rs`

**Files:**

- Modify: `src/ralphception/tui/chatwidget/transcript_cells.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/chatwidget/chat_widget.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/headless.py`

- [ ] **Step 1: Normalize runtime deltas into stable active-cell events**

  Stop treating progress text as replaceable shell summaries. Ensure command start, output deltas, and completion can be reduced into one active command cell that appends lines over time.

- [ ] **Step 2: Preserve committed command history after completion**

  When an active command completes, commit the accumulated output into transcript history instead of re-rendering a new summary cell and dropping prior details.

- [ ] **Step 3: Add explicit tail-follow behavior to the transcript widget**

  Port Codex-style transcript ownership so the widget follows the tail during live output but preserves the user’s manual scroll position if they have scrolled away.

- [ ] **Step 4: Prevent disappearing rows during runtime churn**

  Ensure active output lines are only appended or committed, never lost because a later unrelated runtime update rebuilds the transcript from coarser state.

- [ ] **Step 5: Re-run transcript and runtime tests**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_transcript.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for output accumulation, commit persistence, and scroll-follow behavior.

- [ ] **Step 6: Commit the chunk**

  ```bash
  git add src/ralphception/tui/chatwidget/transcript_cells.py src/ralphception/tui/chatwidget/transcript_view.py src/ralphception/tui/chatwidget/chat_widget.py src/ralphception/tui/runtime_adapter.py src/ralphception/headless.py tests/integration/test_tui_transcript.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "fix: stabilize transcript streaming and scrolling"
  ```

## Chunk 4: Replace The Header With Real Ralphception Session State

### Task 4: Make the session header dynamic, relevant, and config-driven

**Codex references:**

- `codex-rs/tui_app_server/src/chatwidget/session_header.rs`
- `codex-rs/tui_app_server/src/status/card.rs`
- `codex-rs/tui_app_server/src/status/helpers.rs`

**Files:**

- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/chatwidget/session_header.py`
- Modify: `src/ralphception/config.py`
- Modify: `tests/integration/test_tui_session_header.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Remove preview-only header leakage from live state**

  Ensure the live header state is always derived from actual Ralphception config/runtime values, not from `RenderState.idle_preview()` defaults once the real app is running.

- [ ] **Step 2: Map Ralphception config fields directly into the header**

  Show the real:

  - model
  - reasoning effort
  - latency profile
  - workdir

  Keep optional mission/session labeling only if it represents real runtime context.

- [ ] **Step 3: Tighten the header copy to Ralphception**

  Preserve Codex’s layout grammar, but ensure labels and values are meaningful for Ralphception. Do not keep any copied screenshot text that is not backed by real state.

- [ ] **Step 4: Re-run header/runtime tests**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_session_header.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for live config/header update behavior.

- [ ] **Step 5: Commit the chunk**

  ```bash
  git add src/ralphception/tui/render_state.py src/ralphception/tui/runtime_adapter.py src/ralphception/tui/chatwidget/session_header.py src/ralphception/config.py tests/integration/test_tui_session_header.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "fix: drive session header from live ralphception state"
  ```

## Chunk 5: Implement `/model` Like Codex, Persisted For Ralphception

### Task 5: Add a real model picker flow and config persistence

**Codex references:**

- `codex-rs/tui_app_server/src/chatwidget.rs`
- `codex-rs/tui_app_server/src/slash_command.rs`

**Files:**

- Modify: `src/ralphception/tui/app.py`
- Modify: `src/ralphception/tui/bottom_pane/slash_commands.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/config.py`
- Create: `src/ralphception/tui/bottom_pane/model_picker.py`
- Modify: `tests/integration/test_tui_bottom_pane.py`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify: `tests/unit/test_tui_runtime_adapter.py`

- [ ] **Step 1: Add `/model` to the real slash-command catalog**

  `/model` must be discoverable in the popup with Codex-like matching and a Ralphception-appropriate description.

- [ ] **Step 2: Implement a bottom-pane model picker flow**

  Port the interaction model from Codex:

  - slash command opens a picker
  - picker shows model choices and, if needed, reasoning-effort choices
  - enter confirms, escape dismisses

  The UI shape can be Python/Textual-native, but the interaction semantics should match Codex.

- [ ] **Step 3: Update active shell state immediately on selection**

  Once the user selects a new model/reasoning pairing, update:

  - header
  - footer
  - any runtime session config state that should change for future turns

- [ ] **Step 4: Persist selection to Ralphception config**

  Use `write_config_atomically()` so the new model/reasoning values are saved back to Ralphception config and survive restart.

- [ ] **Step 5: Re-run focused model-flow tests**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS for `/model` popup, selection, dismissal, and persistence behavior.

- [ ] **Step 6: Commit the chunk**

  ```bash
  git add src/ralphception/tui/app.py src/ralphception/tui/bottom_pane/slash_commands.py src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/bottom_pane/model_picker.py src/ralphception/tui/runtime_adapter.py src/ralphception/config.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/unit/test_tui_runtime_adapter.py
  git commit -m "feat: add codex-style model picker for ralphception"
  ```

## Chunk 6: Final Parity Pass On The Four Reported UX Failures

### Task 6: Verify the app feels like Codex while staying native to Ralphception

**Files:**

- Modify as needed: `src/ralphception/tui/**/*.py`
- Modify as needed: `tests/integration/*.py`
- Modify as needed: `tests/unit/*.py`

- [ ] **Step 1: Run the focused TUI suite**

  Run:

  ```bash
  uv run pytest tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_session_header.py tests/integration/test_tui_transcript.py tests/unit/test_tui_runtime_adapter.py -q
  ```

  Expected: PASS

- [ ] **Step 2: Run the full automated verification suite**

  Run:

  ```bash
  uv run pytest tests/unit tests/integration tests/e2e -q
  uv run ty check src tests
  git diff --check
  ```

  Expected:

  - all tests pass
  - type checks pass
  - diff is free of whitespace/conflict issues

- [ ] **Step 3: Perform a manual side-by-side UX check against Codex**

  Compare `uv run ralphception` with `codex` and verify:

  - compact idle composer
  - stable live transcript growth
  - no draft clearing during active runtime ticks
  - header shows real Ralphception model/config
  - `/model` works end-to-end

- [ ] **Step 4: Commit the final cleanup**

  ```bash
  git add src tests
  git commit -m "fix: align ralphception tui with codex runtime behavior"
  ```

---

## Definition Of Done

This plan is complete only when all of the following are true:

- the input box no longer looks oversized when empty
- the user can keep typing into the composer while the runtime is working without losing the draft
- commands/log output visibly streams, accumulates, and remains in history without flicker
- the top card is clearly driven by live Ralphception model/runtime/config state
- `/model` exists, opens a picker, updates the shell, and persists configuration
- the result feels like Codex’s TUI behavior adapted to Ralphception, not a screenshot clone or a dashboard with Codex paint

