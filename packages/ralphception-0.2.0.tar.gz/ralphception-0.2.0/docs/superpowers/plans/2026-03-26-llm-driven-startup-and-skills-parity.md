# LLM-Driven Startup And Skills Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace heuristic startup intake with a Codex-driven Socratic intake flow, enable real Ralphception Codex skills in isolated thread sessions, and wire the Ralph loop stages to those skills before merging the work to `main`.

**Architecture:** Ralphception will keep deterministic persistence, artifact writing, and routing, but the first-turn intake question generation and stage guidance will move into Codex-backed thread turns. A new packaged Codex-skill bundle will be materialized into the isolated `CODEX_HOME`, the startup prompt resolver will ask Codex for a structured intake decision, and the stage prompts will explicitly invoke Ralphception’s own Codex skills that mirror the `~/.codex/superpowers` brainstorming/spec/plan/execute/audit flow in repo-local form.

**Tech Stack:** Python 3.12, Pydantic models, Codex app-server JSON-RPC, packaged markdown resources, pytest, ty

---

## File Map

**New files**
- Create: `src/ralphception/codex_skills/__init__.py`
- Create: `src/ralphception/codex_skills/materialize.py`
- Create: `src/ralphception/codex_skills/startup-intake/SKILL.md`
- Create: `src/ralphception/codex_skills/spec-write/SKILL.md`
- Create: `src/ralphception/codex_skills/plan-write/SKILL.md`
- Create: `src/ralphception/codex_skills/execute-task/SKILL.md`
- Create: `src/ralphception/codex_skills/audit-review/SKILL.md`
- Create: `src/ralphception/runtime/startup_llm.py`
- Create: `tests/unit/test_startup_llm.py`
- Create: `tests/unit/test_codex_skill_materialize.py`

**Modified files**
- Modify: `src/ralphception/codex/config.py`
- Modify: `src/ralphception/codex/client.py`
- Modify: `src/ralphception/codex/session_manager.py`
- Modify: `src/ralphception/runtime/prompt_resolution.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/bootstrap.py`
- Modify: `src/ralphception/headless.py`
- Modify: `tests/unit/test_codex_client.py`
- Modify: `tests/unit/test_prompt_resolution.py`
- Modify: `tests/unit/test_runtime_supervisor.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `src/ralphception/testing/fakes.py`

### Task 1: Add The Failing Startup-Resolver Tests

**Files:**
- Modify: `tests/unit/test_prompt_resolution.py`
- Modify: `tests/unit/test_runtime_supervisor.py`
- Create: `tests/unit/test_startup_llm.py`

- [ ] **Step 1: Write failing unit tests for Codex-backed startup prompt resolution**

Add tests that assert:
- `resolve_prompt_reply(..., session_manager=manager)` uses the direct resolver for `startup_prompt`
- a startup resolver can return a structured `clarify` result with a model-authored question
- a startup resolver can return a structured `resolved/bootstrap` result with a synthesized intake summary
- heuristic typo-scope assertions are removed from the normal-path tests and retained only for explicit fallback tests

- [ ] **Step 2: Run the startup-resolution test slice to verify RED**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_prompt_resolution.py tests/unit/test_runtime_supervisor.py tests/unit/test_startup_llm.py -q`

Expected: FAIL because there is no Codex-backed startup resolver, no startup summary handoff, and the current tests still encode heuristic questions.

- [ ] **Step 3: Implement minimal startup-LLM contracts**

Create `src/ralphception/runtime/startup_llm.py` with:
- a small request builder that turns prior intake answers plus the latest user reply into a Codex turn prompt
- a JSON parser for `clarify` vs `resolved`
- a fallback helper that preserves the current heuristic path only when no Codex backend is available or structured output is missing

- [ ] **Step 4: Add the Codex session-manager startup resolver**

Modify `src/ralphception/codex/session_manager.py` and `src/ralphception/runtime/prompt_resolution.py` so:
- `CodexSessionManager.resolve_prompt_reply()` handles `startup_prompt`
- it starts or reuses the `run-root` session, runs one Codex turn, collects the final assistant text, and parses the startup contract
- `resolve_prompt_reply()` accepts `None` from direct resolvers and falls back locally only then

- [ ] **Step 5: Verify the startup-resolution slice turns GREEN**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_prompt_resolution.py tests/unit/test_runtime_supervisor.py tests/unit/test_startup_llm.py -q`

Expected: PASS with the normal startup path now driven by the Codex-backed resolver.

### Task 2: Materialize Ralphception Codex Skills Into The Isolated Home

**Files:**
- Create: `src/ralphception/codex_skills/__init__.py`
- Create: `src/ralphception/codex_skills/materialize.py`
- Create: `src/ralphception/codex_skills/startup-intake/SKILL.md`
- Create: `src/ralphception/codex_skills/spec-write/SKILL.md`
- Create: `src/ralphception/codex_skills/plan-write/SKILL.md`
- Create: `src/ralphception/codex_skills/execute-task/SKILL.md`
- Create: `src/ralphception/codex_skills/audit-review/SKILL.md`
- Modify: `src/ralphception/codex/config.py`
- Modify: `src/ralphception/codex/client.py`
- Create: `tests/unit/test_codex_skill_materialize.py`
- Modify: `tests/unit/test_codex_client.py`

- [ ] **Step 1: Write failing tests for isolated Codex-skill installation**

Add tests that assert:
- the isolated `CODEX_HOME` receives Ralphception’s packaged skills
- thread config no longer disables bundled skills
- the generated isolated config no longer hard-disables `[skills.bundled]`

- [ ] **Step 2: Run the Codex client/materializer tests to verify RED**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_client.py tests/unit/test_codex_skill_materialize.py -q`

Expected: FAIL because the isolated home only copies auth/config and thread config still disables skills.

- [ ] **Step 3: Implement skill materialization**

Create `src/ralphception/codex_skills/materialize.py` that:
- writes packaged `SKILL.md` resources into `$CODEX_HOME/skills/<skill-name>/SKILL.md`
- optionally preserves user-installed non-system skills when present
- remains deterministic for tests by only writing the packaged Ralphception skill set

- [ ] **Step 4: Enable skills in Codex client startup**

Modify `src/ralphception/codex/client.py` and `src/ralphception/codex/config.py` so:
- isolated homes install Ralphception’s packaged skills during transport startup
- `_THREAD_CONFIG_OVERRIDES` enables bundled skills
- the fallback isolated config keeps bundled skills enabled

- [ ] **Step 5: Verify the Codex client/materializer tests turn GREEN**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_client.py tests/unit/test_codex_skill_materialize.py -q`

Expected: PASS with isolated Codex homes now containing the Ralphception skill bundle and thread sessions enabling skills.

### Task 3: Rewire Stage Prompts To Call Ralphception’s Codex Skills

**Files:**
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/bootstrap.py`
- Modify: `src/ralphception/testing/fakes.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Write failing integration assertions for skill-driven stage prompts**

Update tests so the stage prompts assert:
- startup uses a Codex-backed Socratic question instead of the old hard-coded typo-scope question
- spec/plan/execute/audit prompts explicitly mention the Ralphception Codex skill name rather than inlining the old markdown body as the primary driver

- [ ] **Step 2: Run the startup/frontend integration slice to verify RED**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_startup_flow.py tests/integration/test_terminal_frontend.py -q`

Expected: FAIL because the current startup path is heuristic and `_render_prompt()` still inlines bundled stage markdown.

- [ ] **Step 3: Implement Codex-skill stage prompts**

Modify `src/ralphception/headless.py` and `src/ralphception/runtime/bootstrap.py` so:
- startup, spec, plan, execute, and audit prompts explicitly invoke the new Ralphception Codex skill names
- the user-facing stages follow the superpowers-inspired order and “one Socratic question at a time” intake rule
- repo-wide access is treated as the default assumption in the startup skill

- [ ] **Step 4: Update the fake Codex backend to emulate startup-skill decisions**

Modify `src/ralphception/testing/fakes.py` so tests can:
- return structured startup decisions from the fake startup turn
- keep the existing fake headless contract behavior for spec/plan/execute/audit

- [ ] **Step 5: Verify the startup/frontend integration slice turns GREEN**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_startup_flow.py tests/integration/test_terminal_frontend.py -q`

Expected: PASS with the normal startup flow now driven by Codex and the stage prompts invoking Ralphception skills.

### Task 4: Verify End-To-End Behavior And Finish The Branch

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `docs/superpowers/plans/2026-03-26-llm-driven-startup-and-skills-parity.md`

- [ ] **Step 1: Add the final regression coverage**

Pin the visible behavior in:
- `tests/integration/test_codex_tui_tmux.py`

Assertions:
- the first prompt no longer yields the old instantaneous heuristic typo-scope question
- the startup clarifying question comes through the Codex-backed path
- the busy/live shell still behaves correctly after the first Socratic answer

- [ ] **Step 2: Run the focused parity regression slice**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

- [ ] **Step 3: Run full project verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 4: Run static verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 5: Run diff hygiene**

Run: `git diff --check`

Expected: no output

- [ ] **Step 6: Merge and push**

Run:
- `git status --short --branch`
- `git add ...`
- `git commit -m "feat: drive startup and stage flow through codex skills"`
- `git checkout main`
- `git merge --ff-only feat/llm-driven-startup-skills`
- `git push origin main`

Expected: feature branch fast-forwarded into `main` and pushed.

- [ ] **Step 7: Clean up**

Run:
- `git worktree remove .worktrees/feat-llm-driven-startup-skills`
- `git branch -d feat/llm-driven-startup-skills`
- `git worktree list --porcelain`

Expected: only the root worktree remains.
