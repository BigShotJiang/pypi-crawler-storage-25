# Transcript Style Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make Ralphception’s committed transcript cells look more like Codex by styling user turns, system bullets, waiting rows, and command rows instead of rendering them as flat plain strings.

**Architecture:** Reuse the existing ANSI/styled-line primitives already added for the startup shell. Extend history cells to emit styled prefixes and row content while preserving the same visible text and wrapping behavior. Keep scope focused on transcript cell styling; do not attempt a full rich markdown port in this slice.

**Tech Stack:** Python 3.12, ANSI escape sequences, tmux, pytest, Ralphception Codex TUI port

---

### Task 1: Pin the Transcript Style Gap

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add failing unit tests for styled history rows**

Assert that:
- `UserHistoryCell.display_lines()` emits ANSI styling while preserving the same visible text
- `SystemHistoryCell`, `WaitingHistoryCell`, and `CommandHistoryCell` emit styled bullet/prefix rows

- [ ] **Step 2: Add a failing tmux-level regression**

Extend the live shell capture test to assert the first committed user line and first blocker/system line contain ANSI styling, not just plain text.

- [ ] **Step 3: Run focused tests and verify RED**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q
```

Expected: FAIL because transcript cells are still largely plain strings.

### Task 2: Style Transcript Cells

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Modify: `src/ralphception/codex_tui/markdown_render.py`
- Modify: `src/ralphception/codex_tui/styled_text.py` only if a small helper is needed

- [ ] **Step 1: Port styled user-turn rendering**

Make committed user turns use a styled Codex-like prompt prefix and keep wrapped continuation rows visually clean.

- [ ] **Step 2: Port styled system/waiting/command prefixes**

Style bullet prefixes and command tree markers so committed system activity no longer looks like raw logger output.

- [ ] **Step 3: Keep visible text stable**

Ensure styling changes do not regress wrapping, transcript contents, or width trimming.

### Task 3: Verify Live tmux Output, Run Full Suite, Merge

- [ ] **Step 1: Re-run fresh tmux comparison**

Check that the first committed user turn and follow-up system/question rows now look closer to Codex in the real shell-launched path.

- [ ] **Step 2: Run full verification**

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
git diff --check
```

- [ ] **Step 3: Merge, push, and continue**

Fast-forward `main`, push `origin/main`, remove the feature worktree, and proceed to the next visible parity gap from the merged tree.
