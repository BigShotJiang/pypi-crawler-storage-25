# Post-Trust Handoff Viewport Reset Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the human `ralphception` TUI hand off cleanly from the trust prompt to the idle Codex-style shell by resetting the viewport to the top of the terminal instead of re-anchoring from the backend cursor.

**Architecture:** Keep the fix narrow. Preserve the existing Codex-style trust onboarding flow, but replace the post-trust viewport rebuild with an explicit top-anchored terminal reset that mirrors the intended Codex handoff semantics. Verify with a failing test first, then with fresh tmux comparisons against `codex`.

**Tech Stack:** Python, pytest, tmux, ANSI terminal control, Ralphception Codex TUI

---

### Task 1: Pin The Post-Trust Viewport Regression

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Test: `tests/integration/test_codex_tui_tmux.py::test_run_codex_tui_shell_shows_trust_prompt_and_persists_decision_for_fresh_repo`

- [ ] **Step 1: Keep the failing regression assertion in place**

The test must continue asserting that the viewport resets to the top after trust acceptance:

```python
assert frontend.tui.terminal.viewport_area.y == 0
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_run_codex_tui_shell_shows_trust_prompt_and_persists_decision_for_fresh_repo -q
```

Expected: FAIL with the viewport `y` remaining at a lower row (for example `13`) instead of `0`.


### Task 2: Implement A Top-Anchored Terminal Reset

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/custom_terminal.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a dedicated top-anchored terminal constructor if needed**

If `CustomTerminal.with_options()` remains cursor-anchored for normal startup, add a separate helper that constructs a terminal with:

```python
viewport_area=Rect(x=0, y=0, width=0, height=0)
last_known_cursor_pos=Position(x=0, y=0)
visible_history_rows=0
```

Keep the existing cursor-anchored constructor for the normal initial attach path.

- [ ] **Step 2: Update the post-trust reset path to use the top-anchored terminal**

In `CodexTuiFrontend.reset_viewport()`, replace the `CustomTerminal.with_options(...)` rebuild with the explicit top-anchored terminal rebuild after clearing the screen and homing the cursor.

- [ ] **Step 3: Keep the change minimal**

Do not change trust-prompt logic, idle-shell rendering, or notice-stack behavior unless the test evidence shows they are directly required for the handoff fix.


### Task 3: Verify The Handoff Behavior Locally

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py` (only if more assertions are required)
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Re-run the focused regression test**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_run_codex_tui_shell_shows_trust_prompt_and_persists_decision_for_fresh_repo -q
```

Expected: PASS.

- [ ] **Step 2: Run the trust/startup TUI subset**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_codex_tui_app.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/unit/test_project_trust.py -q
```

Expected: PASS.


### Task 4: Compare Against Codex In Fresh tmux Sessions

**Files:**
- No code changes required unless tmux evidence reveals a direct mismatch

- [ ] **Step 1: Launch fresh tmux reference sessions**

Use fresh tmux sessions in a fresh git repo to compare:

```bash
codex
uv run ralphception
```

- [ ] **Step 2: Verify the post-trust handoff**

For both apps in tmux:
- accept trust in a fresh repo
- capture the pane immediately after trust acceptance

Expected Ralphception behavior:
- trust prompt remains in scrollback
- no stray lone `›` line above the header
- the idle shell starts from the top of the live viewport like Codex

- [ ] **Step 3: If tmux still disagrees, stop and inspect terminal state again**

Do not patch blindly. Re-capture pane output and inspect the viewport/cursor state before changing more code.


### Task 5: Final Verification And Integration

**Files:**
- No additional code changes expected

- [ ] **Step 1: Run the full test suite**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
```

Expected: PASS.

- [ ] **Step 2: Run type checks**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
```

Expected: `All checks passed!`

- [ ] **Step 3: Run tree hygiene checks**

Run:

```bash
git diff --check
git status --short --branch
```

Expected: no diff-check issues; branch clean except the intentional plan/code changes before commit.

- [ ] **Step 4: Commit and merge**

Run:

```bash
git add src/ralphception/codex_tui/app.py src/ralphception/codex_tui/custom_terminal.py tests/integration/test_codex_tui_tmux.py docs/superpowers/plans/2026-03-26-post-trust-handoff-viewport-reset.md
git commit -m "fix: reset viewport after trust acceptance"
```

- [ ] **Step 5: Fast-forward `main`, rerun merged verification, push, and clean up**

Run the merged verification on `main`, push `origin/main`, then remove the feature branch/worktree and any temporary tmux compare sessions.
