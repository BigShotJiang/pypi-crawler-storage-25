# Codex-Led TUI Reset Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restore `ralphception` to a Codex-led human TUI while keeping `ralphception exec` as the non-interactive scriptable path.

**Architecture:** The default interactive entrypoint moves back onto `src/ralphception/tui/`, with Codex-style shell ownership restored and the current inline human shell removed from the shipped path. The shared runtime stays artifact-first and loop-driven underneath both interfaces.

**Tech Stack:** Python, Textual, Typer, existing Ralphception runtime and TUI modules, `~/code/codex/codex-rs/tui` as the UI reference.

---

### Task 1: Repoint the shipped interactive entrypoint to the TUI

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Test: `tests/integration/test_inline_shell.py`
- Test: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Write failing tests for the shipped entrypoint**

Add or update tests so `run_app()` and the CLI default path assert that the interactive frontend is the TUI path, not `InlineShellFrontend`.

- [ ] **Step 2: Run the focused tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_inline_shell.py tests/integration/test_tui_runtime_app.py -k 'run_app or default' -q`

- [ ] **Step 3: Implement the minimal entrypoint cutover**

Change `src/ralphception/app.py` so `run_app()` launches the TUI app, and keep `run_terminal()` / `run_exec()` as the non-interactive shared-runtime paths.

- [ ] **Step 4: Re-run the focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_inline_shell.py tests/integration/test_tui_runtime_app.py -k 'run_app or default' -q`

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/app.py src/ralphception/cli.py tests/integration/test_inline_shell.py tests/integration/test_tui_runtime_app.py
git commit -m "feat: launch codex-led tui by default"
```

### Task 2: Remove Ralphception-specific startup shell behavior from the human path

**Files:**
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Modify: `src/ralphception/tui/render_state.py`
- Modify: `src/ralphception/tui/app.py`
- Test: `tests/integration/test_tui_runtime_app.py`
- Test: `tests/integration/test_tui_shell_frame.py`

- [ ] **Step 1: Write failing tests for idle-shell startup**

Add or update tests so the default TUI startup path asserts:
- no custom bootstrap form
- composer-focused Codex idle shell
- startup intake only begins after the first prompt

- [ ] **Step 2: Run the focused tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py -k 'startup or idle' -q`

- [ ] **Step 3: Implement the startup reset**

Update the TUI state/adapter so launch opens in the Codex idle shell and Socratic intake begins only after the user submits the first prompt.

- [ ] **Step 4: Re-run the focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py -k 'startup or idle' -q`

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/tui/runtime_adapter.py src/ralphception/tui/render_state.py src/ralphception/tui/app.py tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py
git commit -m "refactor: restore codex idle shell startup"
```

### Task 3: Reconcile transcript and bottom-pane behavior with the shipped TUI path

**Files:**
- Modify: `src/ralphception/tui/chatwidget/transcript_store.py`
- Modify: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify: `src/ralphception/tui/bottom_pane/bottom_pane_view.py`
- Modify: `src/ralphception/tui/runtime_adapter.py`
- Test: `tests/integration/test_tui_transcript.py`
- Test: `tests/integration/test_tui_bottom_pane.py`
- Test: `tests/integration/test_tui_runtime_app.py`

- [ ] **Step 1: Write failing tests for live TUI transcript behavior**

Add or update tests so the shipped TUI path proves:
- assistant output is visible
- command rows remain durable
- waiting/blocker states stay visible
- the shell does not degrade into the old inline event log

- [ ] **Step 2: Run the focused tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py -q`

- [ ] **Step 3: Implement the minimal TUI parity fixes**

Repair the TUI adapter/render path so the shipped interactive flow uses the existing Codex-style transcript and bottom-pane surfaces correctly.

- [ ] **Step 4: Re-run the focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py -q`

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/tui/chatwidget/transcript_store.py src/ralphception/tui/chatwidget/transcript_view.py src/ralphception/tui/bottom_pane/bottom_pane_view.py src/ralphception/tui/runtime_adapter.py tests/integration/test_tui_transcript.py tests/integration/test_tui_bottom_pane.py tests/integration/test_tui_runtime_app.py
git commit -m "fix: restore codex-style transcript and bottom pane"
```

### Task 4: Keep exec as the separate non-interactive path

**Files:**
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/runtime/inline_shell.py`
- Test: `tests/integration/test_terminal_frontend.py`
- Test: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write failing tests for exec path preservation**

Add or update tests so `ralphception exec` still runs headlessly, skips Socratic intake, and writes durable artifacts.

- [ ] **Step 2: Run the focused tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py tests/e2e/test_core_runtime.py -k 'exec' -q`

- [ ] **Step 3: Implement the separation cleanly**

Leave `exec` and the scriptable terminal path intact while removing the inline shell from the default human launch path.

- [ ] **Step 4: Re-run the focused tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_terminal_frontend.py tests/e2e/test_core_runtime.py -k 'exec' -q`

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/terminal.py src/ralphception/runtime/inline_shell.py tests/integration/test_terminal_frontend.py tests/e2e/test_core_runtime.py
git commit -m "refactor: keep exec as the scriptable path"
```

### Task 5: Final verification and merge

**Files:**
- Modify: `docs/superpowers/specs/2026-03-24-codex-led-tui-reset-design.md`
- Modify: `docs/superpowers/plans/2026-03-24-codex-led-tui-reset.md`

- [ ] **Step 1: Run the full test suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

- [ ] **Step 3: Check diff hygiene**

Run: `git diff --check`

- [ ] **Step 4: Smoke the shipped TUI manually**

Run: `uv run ralphception`
Expected: launches the Codex-led TUI idle shell, not the inline event logger.

- [ ] **Step 5: Merge and push**

```bash
git checkout main
git merge --ff-only feat/codex-tui-reset
git push origin main
git worktree remove .worktrees/codex-tui-reset
git branch -d feat/codex-tui-reset
```
