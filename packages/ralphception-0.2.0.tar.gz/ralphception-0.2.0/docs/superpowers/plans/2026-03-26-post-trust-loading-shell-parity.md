# Post-Trust Loading Shell Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add the missing Codex-style loading-shell transition after trust acceptance so Ralphception briefly renders a `model: loading` startup shell before settling into the final idle shell and notice band.

**Architecture:** Keep the startup shell state machine small. Add a transient loading-shell render path around the existing idle shell instead of rewriting adapter state. Verify the transition in the recording backend first, then confirm it appears in fresh tmux comparisons against `codex`.

**Tech Stack:** Python, pytest, tmux, ANSI terminal I/O, Ralphception Codex TUI

---

### Task 1: Pin The Missing Loading Transition

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a failing post-trust loading-shell test**

Write a focused test that accepts trust and asserts the recorded shell output contains both:
- `model:     loading   /model to change`
- the final resolved model line

The same test should keep checking for the startup notice text.

- [ ] **Step 2: Run the focused test to verify failure**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_maybe_run_trust_onboarding_renders_loading_shell_before_final_idle_shell -q
```

Expected: FAIL because the loading header is not currently rendered.


### Task 2: Implement The Transient Loading Shell

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py` (only if a tiny header-state hook is required)
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add a loading-shell render path**

Implement a small render path that writes a loading version of the header shell before the normal idle-shell render.

- [ ] **Step 2: Keep notice behavior correct**

The final idle shell should still show the Ralphception startup notice band after the loading frame.

- [ ] **Step 3: Keep the transition focused**

Do not add broader startup state machinery unless the tests require it.


### Task 3: Verify In Tests And tmux

**Files:**
- No additional files expected

- [ ] **Step 1: Re-run the focused loading-shell test**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py::test_maybe_run_trust_onboarding_renders_loading_shell_before_final_idle_shell -q
```

Expected: PASS.

- [ ] **Step 2: Re-run the trust/startup subset**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_codex_tui_app.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/unit/test_project_trust.py -q
```

Expected: PASS.

- [ ] **Step 3: Compare against Codex in fresh tmux sessions**

Accept trust in both apps and verify Ralphception now shows:
- the loading header frame
- then the final idle shell with the notice band


### Task 4: Final Verification And Integration

**Files:**
- No additional files expected

- [ ] **Step 1: Run the full test suite**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
```

- [ ] **Step 2: Run type checks**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
```

- [ ] **Step 3: Run hygiene checks**

Run:

```bash
git diff --check
git status --short --branch
```

- [ ] **Step 4: Commit, merge, push, and clean up**

Commit the slice, fast-forward `main`, rerun merged verification, push `origin/main`, and remove the worktree plus temporary tmux sessions.
