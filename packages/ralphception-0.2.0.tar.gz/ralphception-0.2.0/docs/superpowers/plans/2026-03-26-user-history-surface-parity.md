# User History Surface Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make committed user-message history cells render like Codex by using full-width surfaced rows with spacer lines above and below the prompt content.

**Architecture:** Keep the existing Python `UserHistoryCell`, but change it from “style only the visible text” to “render a surfaced block” the way Codex’s `UserHistoryCell` does. The surfaced block should include a leading blank row, the wrapped prompt rows with `› ` / `  ` prefixes, and a trailing blank row, all padded to the viewport width so the background extends across the row.

**Tech Stack:** Python 3.13, ANSI escape sequences, pytest

---

### Task 1: Pin the user-history surface gap in tests

**Files:**
- Modify: `tests/unit/codex_tui/test_history_cell.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Add failing unit coverage for surfaced user history rows**

Add tests that assert:
- `UserHistoryCell.display_lines(width)` includes a leading blank surfaced row
- wrapped prompt rows keep the `› ` / `  ` prefixes
- every surfaced row is padded to the full requested width
- the cell ends with a trailing blank surfaced row

- [ ] **Step 2: Add failing tmux-facing coverage for first-turn history presentation**

Extend the Codex TUI integration expectations so the first committed user prompt renders with the surfaced history block shape, not just a thin styled text row.

- [ ] **Step 3: Run the focused history tests to verify failure**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL because the current `UserHistoryCell` omits spacer rows and does not pad the surfaced background to the viewport width.

### Task 2: Implement surfaced user-history rows

**Files:**
- Modify: `src/ralphception/codex_tui/history_cell.py`
- Test: `tests/unit/codex_tui/test_history_cell.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Re-run the focused tests before coding**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: FAIL

- [ ] **Step 2: Implement the minimal `UserHistoryCell` surface-block change**

Update the cell so that:
- it emits a leading blank surfaced line
- wrapped prompt lines are padded to the requested width with the user-surface background
- it emits a trailing blank surfaced line
- height measurement follows the new surfaced output

- [ ] **Step 3: Run the focused tests to verify they pass**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_history_cell.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

### Task 3: Verify, compare in tmux, and merge

**Files:**
- Modify: `docs/superpowers/plans/2026-03-26-user-history-surface-parity.md`

- [ ] **Step 1: Re-run the live tmux compare against Codex**

Use tmux to capture fresh startup + first-prompt flows for both:
- `codex`
- `uv run ralphception`

Expected: Ralphception’s first committed user prompt now reads as a surfaced block with spacer rows like Codex.

- [ ] **Step 2: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite passes
- typecheck passes
- diff-check is clean

- [ ] **Step 3: Merge, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/user-history-surface-parity
git push origin main
git worktree remove .worktrees/feat-user-history-surface-parity
git branch -d feat/user-history-surface-parity
```
