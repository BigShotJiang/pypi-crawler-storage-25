# Bundled Skill Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Bring Ralphception's bundled Codex skills closer to the reference superpowers brainstorming/planning discipline while preserving Ralph-loop-specific output contracts.

**Architecture:** The packaged `SKILL.md` files remain the main stage-behavior layer. Tests pin the desired bundled-skill structure, and the rewrite adapts the reference superpowers sections into repo-local Ralphception stage contracts instead of copying them mechanically.

**Tech Stack:** Packaged markdown resources, pytest, ty

---

## File Map

**Create**
- `docs/superpowers/specs/2026-03-28-bundled-skill-parity-design.md`
- `docs/superpowers/plans/2026-03-28-bundled-skill-parity.md`

**Modify**
- `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- `src/ralphception/codex_skills/ralph-spec-writing/SKILL.md`
- `src/ralphception/codex_skills/ralph-plan-writing/SKILL.md`
- `src/ralphception/codex_skills/ralph-execute-task/SKILL.md`
- `src/ralphception/codex_skills/ralph-audit-review/SKILL.md`
- `tests/unit/test_codex_skill_materialize.py`

### Task 1: Pin The Missing Skill Depth In Tests

**Files:**
- Modify: `tests/unit/test_codex_skill_materialize.py`

- [ ] **Step 1: Add failing bundled-skill assertions**

Pin the missing structure and Ralph-loop output guidance:
- startup `When To Use`, repo-context inspection, decomposition rule, anti-pattern guidance, completion bar
- spec required structure and self-review
- plan header, zero-context assumptions, task structure, loop-safe checkpoints, no placeholders, self-review, and Ralphception JSON outputs
- execute common mistakes and verification discipline
- execute iron-law and verification gate
- audit severity ladder, reopen-vs-complete rules, and no-findings short-circuit

- [ ] **Step 2: Run the focused test to verify RED**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_skill_materialize.py -q`

Expected: FAIL because the bundled skills are currently too thin.

### Task 2: Rewrite The Bundled Skills

**Files:**
- Modify: `src/ralphception/codex_skills/ralph-startup-intake/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-spec-writing/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-plan-writing/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-execute-task/SKILL.md`
- Modify: `src/ralphception/codex_skills/ralph-audit-review/SKILL.md`

- [ ] **Step 1: Expand startup intake toward brainstorming parity**

Add:
- explicit when-to-use guidance
- repo-context inspection before questions
- decomposition rule for multi-subsystem tasks
- anti-pattern guidance for "simple" tasks
- checklist
- question strategy and completion bar

- [ ] **Step 2: Expand spec writing toward design-doc parity**

Add:
- required structure
- explicit inputs
- repo-local PRD guidance
- isolation/decomposition guidance for clean future loop slices
- self-review checklist
- common mistakes

- [ ] **Step 3: Expand plan writing toward writing-plans parity**

Add:
- scope check
- file map
- bite-sized task granularity
- plan header
- zero-context worker framing
- exact task structure template
- loop-safe checkpoint guidance for Ralph loops
- no placeholders
- self-review
- Ralphception output contract for markdown plus JSON/todos/commit intents/execution policy

- [ ] **Step 4: Expand execute and audit enough to match the rest of the bundle**

Add:
- when-to-use guidance
- verification/evidence discipline
- execute iron-law and completion gate
- audit severity ladder and reopen-vs-complete criteria
- common mistakes
- audit empty-findings short-circuit

- [ ] **Step 5: Run the focused test to verify GREEN**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/test_codex_skill_materialize.py -q`

Expected: PASS

### Task 3: Verify The Full Slice

**Files:**
- Modify: `docs/superpowers/specs/2026-03-28-bundled-skill-parity-design.md`
- Modify: `docs/superpowers/plans/2026-03-28-bundled-skill-parity.md`

- [ ] **Step 1: Run the full suite**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`

Expected: PASS

- [ ] **Step 2: Run static verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`

Expected: `All checks passed!`

- [ ] **Step 3: Run diff hygiene**

Run: `git diff --check`

Expected: no output

- [ ] **Step 4: Merge, push, and clean up**

Run:
- `git add ...`
- `git commit -m "feat: strengthen bundled ralph skills"`
- `git checkout main`
- `git merge --ff-only feat/bundled-skill-parity`
- `git push origin main`
- `git worktree remove .worktrees/feat-bundled-skill-parity`
- `git branch -d feat/bundled-skill-parity`

Expected: merged `main`, pushed, and only the root worktree remains.
