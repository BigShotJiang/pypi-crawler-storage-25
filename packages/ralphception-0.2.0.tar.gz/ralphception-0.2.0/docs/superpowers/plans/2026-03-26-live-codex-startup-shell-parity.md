# Live Codex Startup Shell Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make the human `ralphception` startup shell match the live tmux behavior of `codex` more closely by removing the wrong trust onboarding experiment, restoring the correct idle-shell baseline, and porting the missing footer/composer startup chrome.

**Architecture:** Keep the new Python Codex-style terminal stack (`custom_terminal`, `insert_history`, `tui`, `chatwidget`) and tighten only the startup-shell layer. The live tmux comparison against authenticated `codex` shows the next real parity gap is bottom-pane startup chrome, not a pre-shell trust prompt, so this slice removes the experimental trust gate and ports the observed footer/composer behavior instead.

**Tech Stack:** Python 3.12, pytest, tmux, custom ANSI terminal rendering, Codex config helpers

---

### Task 1: Remove The Incorrect Trust-Onboarding Experiment

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Delete: `tests/unit/test_codex_config.py`
- Optional cleanup if unused after revert: `src/ralphception/codex/config.py`

- [ ] **Step 1: Remove the trust prompt path from the human shell**

Delete the `load_project_trust_level` / `set_project_trust_level` startup gating from `run_codex_tui_shell()` and remove the trust-prompt helper methods from `CodexTuiFrontend` and `ScriptedCodexTuiFrontend` in `src/ralphception/codex_tui/app.py`.

- [ ] **Step 2: Remove trust-specific tests**

Delete the trust-prompt tests from `tests/integration/test_codex_tui_tmux.py` and remove `tests/unit/test_codex_config.py` if the new config helpers are no longer used by shipped code.

- [ ] **Step 3: Run the focused shell tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS, with the existing first-prompt and keep-alive shell tests green and no trust-prompt expectations remaining.

- [ ] **Step 4: Commit the baseline correction**

```bash
git add src/ralphception/codex_tui/app.py tests/integration/test_codex_tui_tmux.py tests/unit/test_codex_config.py src/ralphception/codex/config.py
git commit -m "fix: remove incorrect trust onboarding slice"
```

### Task 2: Port Live Codex Startup Footer And Composer Chrome

**Files:**
- Modify: `src/ralphception/codex_tui/bottom_pane.py`
- Modify: `src/ralphception/codex_tui/chatwidget.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`
- Modify: `src/ralphception/codex_tui/status.py`
- Test: `tests/unit/codex_tui/test_chatwidget.py`
- Test: `tests/unit/codex_tui/test_ralph_adapter.py`
- Test: `tests/integration/test_codex_tui_tmux.py`

- [ ] **Step 1: Write the failing startup-shell chrome tests**

Add tests that assert the idle human shell renders:
- a prompt placeholder instead of a bare `›`
- the `? for shortcuts` hint row
- the right-side `100% context left` footer text when idle

Use the existing recording/fake terminal helpers in the Codex TUI tests.

- [ ] **Step 2: Run the focused unit tests to verify failure**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py -q`

Expected: FAIL because the current startup shell renders a bare composer and a simplified footer line.

- [ ] **Step 3: Implement the minimal startup chrome port**

Update the Python Codex TUI port so the idle startup shell behaves like the live reference app:
- render a starter placeholder in the composer when the draft is empty
- keep the `? for shortcuts` footer hint visible while idle
- show `100% context left` on the right side of the footer when idle
- preserve the existing Ralphception-specific header card and runtime status behavior

- [ ] **Step 4: Run the focused unit and integration tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py -q`

Expected: PASS

- [ ] **Step 5: Commit the startup chrome parity work**

```bash
git add src/ralphception/codex_tui/bottom_pane.py src/ralphception/codex_tui/chatwidget.py src/ralphception/codex_tui/ralph_adapter.py src/ralphception/codex_tui/status.py tests/unit/codex_tui/test_chatwidget.py tests/unit/codex_tui/test_ralph_adapter.py tests/integration/test_codex_tui_tmux.py
git commit -m "feat: port codex startup footer chrome"
```

### Task 3: Verify In Fresh tmux Sessions Against `codex`

**Files:**
- No code changes required unless verification exposes another concrete parity bug

- [ ] **Step 1: Launch fresh compare sessions**

Use the tmux controller helper to launch:
- authenticated `codex` in a fresh git repo
- the branch build of `uv run ralphception` in the same repo shape

- [ ] **Step 2: Capture the idle shell in both sessions**

Verify:
- both open directly to the idle shell (no stale resume state)
- Ralphception now shows the placeholder + shortcuts + context footer row
- the bottom viewport stays anchored while startup history remains in scrollback

- [ ] **Step 3: Submit a first prompt in Ralphception**

Verify in tmux that:
- the first prompt becomes the first real user turn
- Socratic intake begins in transcript
- committed lines go into scrollback above the live viewport

- [ ] **Step 4: Run full verification**

Run:
- `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
- `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
- `git diff --check`

Expected:
- full suite PASS
- typecheck PASS
- diff check clean

- [ ] **Step 5: Merge to `main`, push, and clean up**

```bash
git checkout main
git merge --ff-only feat/trust-onboarding
git push origin main
git branch -d feat/trust-onboarding
git worktree remove /Users/shayne/code/ralphception/.worktrees/feat-trust-onboarding
```
