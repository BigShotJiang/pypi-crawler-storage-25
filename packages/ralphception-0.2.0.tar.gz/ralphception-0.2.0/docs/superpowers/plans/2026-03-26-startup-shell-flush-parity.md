# Startup Shell Flush Parity Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Keep the startup shell live on initial launch and flush it into history only when the first real interaction begins, so tmux startup layout matches Codex more closely.

**Architecture:** Move startup-shell ownership out of the eager launch path and into the first interaction boundary. The adapter should preserve startup shell state live at launch, then commit a `StartupShellHistoryCell` immediately before the first user message or first runtime event that begins the conversation.

**Tech Stack:** Python, ANSI terminal renderer, Codex TUI port, pytest integration/unit tests

---

### Task 1: Lock the intended startup/live-shell contract in tests

**Files:**
- Modify: `tests/integration/test_codex_tui_tmux.py`
- Modify: `tests/integration/test_inline_shell.py`
- Modify: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Write failing assertions for startup shell remaining live at launch**

Add or update tests to assert:
- initial launch keeps header/tip in the live viewport
- startup shell is not yet emitted into committed transcript/history before first interaction
- first user prompt flushes startup shell before the user message is committed

- [ ] **Step 2: Run targeted tests to verify they fail**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py -q`

Expected: failures around startup shell placement / flush timing

### Task 2: Move startup shell flush from launch-time to first interaction

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/ralph_adapter.py`

- [ ] **Step 1: Introduce an explicit live-startup state**

Keep startup header/notice lines live in `ChatWidget` at launch instead of eagerly converting them into a `StartupShellHistoryCell`.

- [ ] **Step 2: Flush startup shell at first interaction boundary**

Ensure the first user message path and any equivalent first-turn runtime kickoff path flush the startup shell into history immediately before committing the user message or other first transcript cell.

- [ ] **Step 3: Preserve trust/loading handoff behavior**

Make sure the trust acceptance/loading shell path still lands in the normal startup shell and does not regress to duplicate header/tip state or stray prompt lines.

### Task 3: Verify terminal history/layout behavior

**Files:**
- Modify: `src/ralphception/codex_tui/app.py`
- Modify: `src/ralphception/codex_tui/insert_history.py` (only if needed)

- [ ] **Step 1: Keep terminal history insertion unchanged unless tests prove it is the cause**

Do not rewrite low-level insertion logic unless launch/interaction tests still fail after moving the startup flush boundary.

- [ ] **Step 2: Re-run targeted tests**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/integration/test_codex_tui_tmux.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py -q`

Expected: pass

### Task 4: tmux verification against Codex

**Files:**
- No code changes required

- [ ] **Step 1: Launch fresh tmux sessions for Codex and Ralphception**

Verify:
- startup shell begins at the right location in the pane
- first prompt sequence shows startup shell above the user prompt instead of leaving a blank slab
- reply/waiting shell remains anchored at the bottom

- [ ] **Step 2: Only keep changes that materially improve parity**

If tmux comparison still shows the same large blank gap, stop and revisit root cause instead of layering more layout tweaks.

### Task 5: Full verification and merge

**Files:**
- No code changes required

- [ ] **Step 1: Run full verification**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q`
Expected: all tests pass

- [ ] **Step 2: Run type checks**

Run: `PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests`
Expected: `All checks passed!`

- [ ] **Step 3: Run diff check**

Run: `git diff --check`
Expected: no output

- [ ] **Step 4: Commit**

```bash
git add src/ralphception/codex_tui/app.py src/ralphception/codex_tui/ralph_adapter.py tests/integration/test_codex_tui_tmux.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py docs/superpowers/plans/2026-03-26-startup-shell-flush-parity.md
git commit -m "fix: flush startup shell on first interaction"
```
