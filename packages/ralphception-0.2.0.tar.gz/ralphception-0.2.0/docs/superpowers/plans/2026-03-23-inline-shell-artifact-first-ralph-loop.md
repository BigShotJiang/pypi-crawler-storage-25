# Inline Shell And Artifact-First Ralph Loop Orchestrator Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace Ralphception’s boxed full-screen TUI and stage-first runtime with a Codex-style inline shell that writes to terminal scrollback, always produces durable intake/PRD/plan/todo artifacts before execution, and drives long-running Ralph loops from an explicit plan and loop graph.

**Architecture:** Execute this as a two-phase cutover in one coherent branch. Phase 1 makes `uv run ralphception` use an inline, scrollback-first interactive shell with durable transcript milestones, explicit waiting/blocker states, and no boxed transcript viewport. Phase 2 makes the runtime artifact-first: Socratic intake writes authoritative artifacts, a task/plan/loop graph becomes the execution control plane, and Ralph loops run, consolidate, and resume from that durable state.

**Tech Stack:** Python 3.13, Typer, existing runtime/supervisor/headless stack, Codex session manager, pytest, ty, tmux smoke tests, durable `.ralphception` storage

---

## Scope Decision

Keep this as one phased plan. The inline shell reset and the artifact-first loop runtime are not independent projects: the shell needs the new runtime signals, and the runtime needs the new shell contract to expose loop progress, settled milestones, and blockers correctly. The phases should be implemented in order, but the branch should preserve one coherent product contract throughout.

## File Structure / Responsibility Map

### Create

- `src/ralphception/runtime/task_classifier.py`
  Classify each incoming user message as `blocker_reply`, `in_task_follow_up`, `task_revision`, or `new_task_request`.
- `src/ralphception/runtime/task_state.py`
  Durable identities and runtime metadata for `task_id`, `session_id`, `plan_id`, `loop_graph_id`, `plan_node_id`, authoritative artifact revisions, and current active node/loop pointers.
- `src/ralphception/runtime/artifact_pipeline.py`
  Write and update intake summaries, PRDs/specs, loop plans, execution plans, todos, and authoritative revision pointers.
- `src/ralphception/runtime/loop_planner.py`
  Create explicit loop definitions from the current plan graph, including objectives, stop conditions, output contracts, and merge strategy.
- `src/ralphception/runtime/loop_graph.py`
  Durable loop graph models and merge/failure propagation helpers for nested and parallel loop families.
- `src/ralphception/runtime/inline_shell.py`
  Scrollback-first interactive shell that owns only live status, prompt/composer interaction, and blocker rendering.
- `tests/unit/test_task_classifier.py`
  Unit tests for message classification and clarification triggers.
- `tests/unit/test_task_state.py`
  Unit tests for task identity, authoritative revision pointers, and continuity metadata.
- `tests/unit/test_artifact_pipeline.py`
  Unit tests for artifact writes, revision supersession, and authoritative artifact selection.
- `tests/unit/test_loop_planner.py`
  Unit tests for loop definitions, proposal-first merge strategy, and overlapping-output constraints.
- `tests/unit/test_loop_graph.py`
  Unit tests for child-loop failure propagation and parent consolidation rules.
- `tests/integration/test_inline_shell.py`
  Integration coverage for scrollback-first shell behavior, settled milestone emission, blocker visibility, and no silent idle state.
- `tests/integration/test_artifact_first_runtime.py`
  Integration coverage for intake -> artifact creation -> loop planning -> loop execution -> consolidation.

### Modify

- `src/ralphception/app.py`
  Make the inline shell the default interactive entry point and stop launching the boxed Textual app as the primary UX.
- `src/ralphception/cli.py`
  Keep `ralphception` as the default interactive command, but ensure it resolves to the inline shell contract.
- `src/ralphception/runtime/supervisor.py`
  Replace the stage-first “startup/spec/plan/execute/merge/audit” flow with task classification, artifact-first orchestration, loop planning, and loop execution.
- `src/ralphception/headless.py`
  Emit durable settled milestones and loop progress events that the inline shell can write into scrollback.
- `src/ralphception/runtime/frontends.py`
  Narrow the frontend contract to inline-shell/headless events that support scrollback milestones, live status, blockers, and loop progress.
- `src/ralphception/runtime/prompt_state.py`
  Keep conversational blockers, but align them with task/plan/loop ownership instead of generic stage ownership.
- `src/ralphception/runtime/prompt_resolution.py`
  Resolve blocker replies inside the new task classifier and plan-node ownership model.
- `src/ralphception/runtime/bootstrap.py`
  Stop treating startup as an isolated mode; route first-task intake through the artifact pipeline.
- `src/ralphception/actor_runtime/intake_actor.py`
  Convert from generic bootstrap logic into Socratic intake artifact generation.
- `src/ralphception/actor_runtime/orchestrator.py`
  Use task state, plan graph, loop graph, and consolidation rules as the real orchestration contract.
- `src/ralphception/actor_runtime/planner_actor.py`
  Generate or revise execution plans from the current intake/PRD state.
- `src/ralphception/actor_runtime/scheduler_actor.py`
  Queue loop families from explicit loop definitions rather than from implicit stages.
- `src/ralphception/actor_runtime/worker_actor.py`
  Execute loop work and publish proposal outputs for consolidation.
- `src/ralphception/testing/fakes.py`
  Make fake sessions emit artifact writes, loop launches, loop summaries, blockers, and final settled outcomes through the inline shell contract.
- `src/ralphception/storage/artifacts.py`
  Add authoritative revision helpers and artifact supersession rules.
- `src/ralphception/storage/bootstrap.py`
  Persist initial task/session/task-state bootstrap files for fresh workspaces.
- `src/ralphception/storage/events.py`
  Keep durable event history for milestone replay on resume.
- `src/ralphception/runtime/interactive_session.py`
  Persist current task, active plan node, active loop set, current blocker, and last settled milestone for resume.
- `src/ralphception/runtime/terminal.py`
  Either delegate to or collapse into the new inline shell so there is one scrollback-first interactive path.
- `tests/integration/test_startup_flow.py`
  Replace stage-first startup expectations with Socratic intake and mandatory artifact formation.
- `tests/integration/test_terminal_frontend.py`
  Replace “simple log-and-prompt” assertions with inline shell milestone and blocker behavior.
- `tests/integration/test_headless_supervisor.py`
  Assert durable milestones, artifact writes, loop launches, and explicit completion/blocker outcomes.
- `tests/integration/test_tui_runtime_app.py`
  Shrink to boxed-shell regression coverage only if the Textual path survives as a non-default compatibility path; otherwise replace with inline shell tests.
- `tests/e2e/test_core_runtime.py`
  Cover the full product flow from first prompt through intake, artifacts, loops, consolidation, and explicit completion/blocker state.
- `README.md`
  Rewrite product usage around the inline shell and artifact-first Ralph-loop orchestration.

### Delete Or Demote After Phase 1 Is Green

- The default interactive path through `src/ralphception/tui/app.py`
- Boxed transcript assumptions in `src/ralphception/tui/chatwidget/transcript_view.py`
- Boxed bottom-pane layout assumptions in `src/ralphception/tui/bottom_pane/*`
- The Codex-port snapshot/golden tests that only validate the boxed shell frame instead of the actual inline UX

If the Textual shell is kept temporarily, it must be hidden behind a non-default dev flag and no longer define the shipped UX.

## Relevant References

- Spec: [2026-03-23-inline-shell-artifact-first-ralph-loop-design.md](/Users/shayne/code/ralphception/docs/superpowers/specs/2026-03-23-inline-shell-artifact-first-ralph-loop-design.md)
- Current default app entry: [app.py](/Users/shayne/code/ralphception/src/ralphception/app.py)
- Current terminal frontend: [terminal.py](/Users/shayne/code/ralphception/src/ralphception/runtime/terminal.py)
- Current boxed TUI shell: [tui/app.py](/Users/shayne/code/ralphception/src/ralphception/tui/app.py)
- Current supervisor/orchestrator path: [supervisor.py](/Users/shayne/code/ralphception/src/ralphception/runtime/supervisor.py), [orchestrator.py](/Users/shayne/code/ralphception/src/ralphception/actor_runtime/orchestrator.py)
- Current conversational blocker work: [prompt_state.py](/Users/shayne/code/ralphception/src/ralphception/runtime/prompt_state.py), [prompt_resolution.py](/Users/shayne/code/ralphception/src/ralphception/runtime/prompt_resolution.py)
- Codex inline shell reference: `~/code/codex/codex-rs/tui/src/cli.rs`, `~/code/codex/codex-rs/tui/src/tui.rs`, `~/code/codex/codex-rs/tui/src/app.rs`

## Phase 1: Inline Shell And Scrollback Reset

### Task 1: Freeze The Current Interactive UX Failures With Red Tests

**Files:**
- Create: `tests/integration/test_inline_shell.py`
- Modify: `tests/integration/test_terminal_frontend.py`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write a failing integration test proving the default app path is not boxed**

```python
def test_default_interactive_shell_uses_scrollback_contract(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    launch = resolve_runtime_view(repo_root, session_manager_factory=fake_factory)
    assert launch.frontend_kind == "inline"
```

- [ ] **Step 2: Write a failing test for durable milestone output**

```python
def test_inline_shell_emits_settled_milestones_for_long_running_work(tmp_path: Path) -> None:
    frontend = ScriptedInlineShell(inputs=["look for typos"])
    result = run_terminal(repo_root=make_git_repo(tmp_path), frontend=frontend, use_fake_session_manager=True)
    text = frontend.output_text()
    assert "Wrote intake summary" in text
    assert "Wrote PRD" in text
    assert "Launched" in text
    assert result.mode == "completed"
```

- [ ] **Step 3: Write a failing test for explicit non-idle waiting state**

Run: `uv run pytest tests/integration/test_inline_shell.py -k waiting -q`

Expected: FAIL because the current terminal/frontend path does not preserve explicit waiting/blocker narration.

- [ ] **Step 4: Write a failing e2e test for “no silent stop”**

Add an e2e assertion that after a loop run the output always contains one of:
- `Completed`
- `Blocked`
- `Waiting on`
- `Next step`

- [ ] **Step 5: Run the focused red suite**

Run: `uv run pytest tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py tests/e2e/test_core_runtime.py -q`

Expected: FAIL on missing inline shell contract and missing settled milestones.

- [ ] **Step 6: Commit**

```bash
git add tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py tests/e2e/test_core_runtime.py
git commit -m "test: capture inline shell product reset regressions"
```

### Task 2: Introduce Durable Task Identity And Message Classification

**Files:**
- Create: `src/ralphception/runtime/task_classifier.py`
- Create: `src/ralphception/runtime/task_state.py`
- Create: `tests/unit/test_task_classifier.py`
- Create: `tests/unit/test_task_state.py`
- Modify: `src/ralphception/runtime/interactive_session.py`

- [ ] **Step 1: Write the failing classifier tests**

```python
def test_classifier_prefers_blocker_reply_when_prompt_is_pending() -> None:
    result = classify_user_message(
        text="resume it",
        prompt_pending=True,
        active_task_summary="fix typos in docs",
    )
    assert result.kind == "blocker_reply"


def test_classifier_requests_clarification_for_ambiguous_new_task_boundary() -> None:
    result = classify_user_message(
        text="do that other thing too",
        prompt_pending=False,
        active_task_summary="fix typos in docs",
    )
    assert result.kind == "needs_clarification"


def test_classifier_detects_task_revision() -> None:
    result = classify_user_message(
        text="change the scope to README typos only",
        prompt_pending=False,
        active_task_summary="fix typos in docs and comments",
    )
    assert result.kind == "task_revision"


def test_classifier_detects_new_task_request() -> None:
    result = classify_user_message(
        text="stop this and audit our CI pipeline instead",
        prompt_pending=False,
        active_task_summary="fix typos in docs and comments",
    )
    assert result.kind == "new_task_request"
```

- [ ] **Step 2: Write the failing task-state tests**

```python
def test_task_state_tracks_authoritative_artifact_revisions() -> None:
    state = TaskState.new(task_id="task-1")
    state = state.with_artifact_revision("prd", "rev-2")
    assert state.authoritative_artifacts["prd"] == "rev-2"
```

- [ ] **Step 3: Run the focused red tests**

Run: `uv run pytest tests/unit/test_task_classifier.py tests/unit/test_task_state.py -q`

Expected: FAIL with missing classifier/task-state models.

- [ ] **Step 4: Implement minimal models and persistence hooks**

```python
class MessageKind(StrEnum):
    BLOCKER_REPLY = "blocker_reply"
    IN_TASK_FOLLOW_UP = "in_task_follow_up"
    TASK_REVISION = "task_revision"
    NEW_TASK_REQUEST = "new_task_request"
    NEEDS_CLARIFICATION = "needs_clarification"
```

- [ ] **Step 5: Persist the active `task_id`, `plan_id`, `loop_graph_id`, and active plan node in interactive session state**
- [ ] **Step 5: Persist the active `task_id`, `session_id`, `plan_id`, `loop_graph_id`, and active plan node in interactive session state**

Run: `uv run pytest tests/unit/test_task_classifier.py tests/unit/test_task_state.py tests/unit/test_interactive_session.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/task_classifier.py src/ralphception/runtime/task_state.py src/ralphception/runtime/interactive_session.py tests/unit/test_task_classifier.py tests/unit/test_task_state.py
git commit -m "feat: add task identity and message classification"
```

### Task 3: Define The Transitional Inline Runtime Contract

**Files:**
- Modify: `src/ralphception/runtime/frontends.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `src/ralphception/testing/fakes.py`
- Modify: `tests/unit/test_headless_contracts.py`
- Modify: `tests/integration/test_inline_shell.py`

- [ ] **Step 1: Write failing tests for milestone-vs-live-status separation**

```python
def test_progress_heartbeat_stays_in_live_status_but_loop_completion_becomes_milestone() -> None:
    frontend = RecordingInlineShell()
    frontend.emit_live_status("Loop run-child-1 inspecting docs")
    frontend.emit_milestone("Loop run-child-1 completed: 4 typo candidates found")
    assert "completed" in frontend.output_text()
    assert frontend.live_status == "Loop run-child-1 inspecting docs"
```

- [ ] **Step 2: Add failing tests for minimum Phase 1 runtime labels**

Add assertions that the transitional contract can surface:
- current task label
- current plan node label
- current loop label
- current blocker state
- current waiting state

- [ ] **Step 3: Run the focused contract tests**

Run: `uv run pytest tests/unit/test_headless_contracts.py tests/integration/test_inline_shell.py -q`

Expected: FAIL because the current runtime does not expose the minimum Phase 1 signal set.

- [ ] **Step 4: Add explicit frontend event kinds for**
- live status
- milestone transcript line
- blocker prompt
- artifact write
- loop launch
- loop completion
- failure summary
- current task label
- current plan node label
- current loop label

- [ ] **Step 5: Update headless, terminal, and fake backends to emit those event kinds**

Run: `uv run pytest tests/unit/test_headless_contracts.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/frontends.py src/ralphception/headless.py src/ralphception/runtime/terminal.py src/ralphception/testing/fakes.py tests/unit/test_headless_contracts.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py
git commit -m "refactor: define transitional inline shell runtime contract"
```

### Task 4: Make The Inline Shell The Primary Interactive Surface

**Files:**
- Create: `src/ralphception/runtime/inline_shell.py`
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `tests/integration/test_inline_shell.py`
- Modify: `tests/integration/test_terminal_frontend.py`

- [ ] **Step 1: Write a failing inline-shell test for scrollback-first output**

```python
def test_inline_shell_writes_history_to_output_stream_not_boxed_widget(tmp_path: Path) -> None:
    shell = ScriptedInlineShell(inputs=["look for typos"])
    shell.write_milestone("Wrote intake summary")
    shell.write_milestone("Wrote PRD")
    assert shell.output_text().splitlines()[-2:] == [
        "Wrote intake summary",
        "Wrote PRD",
    ]
```

- [ ] **Step 2: Write a failing test proving `run_app()` resolves to the inline shell**

Run: `uv run pytest tests/integration/test_inline_shell.py -k default_interactive_shell -q`

Expected: FAIL because `run_app()` still launches `RalphceptionTuiApp`.

- [ ] **Step 3: Implement `InlineShellFrontend` as the primary interactive surface**

```python
@dataclass(slots=True)
class InlineShellFrontend:
    input_func: Callable[[str], str] = input
    write_func: Callable[[str], None] = print

    def emit_milestone(self, text: str) -> None:
        self.write_func(text)
```

- [ ] **Step 4: Route `run_app()` and the default CLI callback through the inline shell**

Run: `uv run pytest tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py -q`

Expected: PASS

- [ ] **Step 5: Demote the Textual app from the default product path**

Use grep to verify:

Run: `rg -n "RalphceptionTuiApp.from_runtime|launch.tui_app.run|run_app\\(" src/ralphception`

Expected: default interactive path points to the inline shell, not the boxed TUI.

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/inline_shell.py src/ralphception/app.py src/ralphception/cli.py src/ralphception/runtime/terminal.py tests/integration/test_inline_shell.py tests/integration/test_terminal_frontend.py
git commit -m "feat: make inline shell the default interactive frontend"
```

## Phase 2: Artifact-First Ralph Loop Orchestrator

### Task 5: Build The Durable Artifact Pipeline

**Files:**
- Create: `src/ralphception/runtime/artifact_pipeline.py`
- Modify: `src/ralphception/storage/artifacts.py`
- Modify: `src/ralphception/storage/bootstrap.py`
- Create: `tests/unit/test_artifact_pipeline.py`
- Modify: `tests/unit/test_storage_artifacts.py`
- Modify: `tests/unit/test_storage_bootstrap.py`

- [ ] **Step 1: Write failing artifact-pipeline tests**

```python
def test_first_task_writes_required_artifacts_before_loop_execution(tmp_path: Path) -> None:
    pipeline = ArtifactPipeline.for_workspace(tmp_path)
    result = pipeline.initialize_from_intake(
        task_id="task-1",
        intake_summary="Fix typos in docs",
    )
    assert result.paths["intake-summary"].exists()
    assert result.paths["prd"].exists()
    assert result.paths["execution-plan"].exists()
    assert result.paths["loop-plan"].exists()
    assert result.paths["todos"].exists()
```

- [ ] **Step 2: Add a failing revision-supersession test**

```python
def test_new_prd_revision_becomes_authoritative_without_deleting_history(tmp_path: Path) -> None:
    pipeline = ArtifactPipeline.for_workspace(tmp_path)
    rev1 = pipeline.write_artifact("prd", "v1")
    rev2 = pipeline.write_artifact("prd", "v2")
    assert pipeline.authoritative_revision("prd") == rev2.revision_id
    assert rev1.path.exists()
```

- [ ] **Step 3: Run the red artifact tests**

Run: `uv run pytest tests/unit/test_artifact_pipeline.py tests/unit/test_storage_artifacts.py tests/unit/test_storage_bootstrap.py -q`

Expected: FAIL with missing pipeline/revision behavior.

- [ ] **Step 4: Implement the minimal artifact pipeline**

```python
class ArtifactPipeline:
    REQUIRED_BOOTSTRAP_ARTIFACTS = (
        "intake-summary",
        "prd",
        "execution-plan",
        "loop-plan",
        "todos",
    )
```

- [ ] **Step 5: Re-run the artifact tests**

Run: `uv run pytest tests/unit/test_artifact_pipeline.py tests/unit/test_storage_artifacts.py tests/unit/test_storage_bootstrap.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/artifact_pipeline.py src/ralphception/storage/artifacts.py src/ralphception/storage/bootstrap.py tests/unit/test_artifact_pipeline.py tests/unit/test_storage_artifacts.py tests/unit/test_storage_bootstrap.py
git commit -m "feat: add artifact-first runtime pipeline"
```

### Task 6: Turn Startup Into Socratic Intake That Writes Artifacts

**Files:**
- Modify: `src/ralphception/runtime/bootstrap.py`
- Modify: `src/ralphception/actor_runtime/intake_actor.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/prompt_state.py`
- Modify: `src/ralphception/runtime/prompt_resolution.py`
- Modify: `tests/integration/test_startup_flow.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`

- [ ] **Step 1: Write the failing startup-flow test**

```python
def test_first_prompt_enters_socratic_intake_and_writes_artifacts(tmp_path: Path) -> None:
    frontend = ScriptedInlineShell(inputs=["fix typos", "focus on docs and comments"])
    result = run_terminal(repo_root=make_git_repo(tmp_path), frontend=frontend, use_fake_session_manager=True)
    text = frontend.output_text()
    assert "I need a little more context" in text
    assert "Wrote intake summary" in text
    assert "Wrote PRD" in text
    assert result.mode == "completed"
```

- [ ] **Step 2: Run the focused startup tests**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/integration/test_artifact_first_runtime.py -q`

Expected: FAIL because startup still shortcuts into generic execute mode.

- [ ] **Step 3: Implement intake prompts through the existing conversational blocker pipeline**

Use the classifier and prompt resolver so the first task continues until the intake engine says there is enough context to write artifacts.

- [ ] **Step 4: Route successful intake completion through `ArtifactPipeline.initialize_from_intake()`**

Run: `uv run pytest tests/integration/test_startup_flow.py tests/integration/test_artifact_first_runtime.py tests/unit/test_prompt_state.py tests/unit/test_prompt_resolution.py -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/bootstrap.py src/ralphception/actor_runtime/intake_actor.py src/ralphception/runtime/supervisor.py src/ralphception/runtime/prompt_state.py src/ralphception/runtime/prompt_resolution.py tests/integration/test_startup_flow.py tests/integration/test_artifact_first_runtime.py
git commit -m "feat: make socratic intake write durable artifacts"
```

### Task 7: Route Active-Session Messages Through The Classifier

**Files:**
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/task_classifier.py`
- Modify: `src/ralphception/runtime/prompt_resolution.py`
- Modify: `src/ralphception/runtime/interactive_session.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write failing active-session classification tests**

```python
def test_post_intake_message_can_extend_current_task_without_opening_new_task(tmp_path: Path) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "also check comments"])
    assert result.classifications[-1] == "in_task_follow_up"


def test_ambiguous_post_intake_message_requests_clarification(tmp_path: Path) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "do the other thing too"])
    assert "Need clarification" in result.log_text


def test_post_intake_message_can_revise_current_task_without_starting_new_task(tmp_path: Path) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "change scope to README only"])
    assert result.classifications[-1] == "task_revision"


def test_post_intake_message_can_start_new_task_when_intent_is_explicit(tmp_path: Path) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "stop this and audit CI instead"])
    assert result.classifications[-1] == "new_task_request"
```

- [ ] **Step 2: Run the focused active-session tests**

Run: `uv run pytest tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py -k "classification or follow_up or revision or ambiguity or new_task" -q`

Expected: FAIL because only startup intake currently routes through the new classifier logic.

- [ ] **Step 3: Route every active-session user message through the classifier**

Implement:
- blocker replies
- in-task follow-ups
- task revisions
- new task requests
- clarification on ambiguity

- [ ] **Step 4: Persist classification decisions in interactive session state for resume/debugging**

Run: `uv run pytest tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py -k "classification or follow_up or revision or ambiguity or new_task" -q`

Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add src/ralphception/runtime/supervisor.py src/ralphception/runtime/task_classifier.py src/ralphception/runtime/prompt_resolution.py src/ralphception/runtime/interactive_session.py tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py
git commit -m "feat: classify active session messages"
```

### Task 8: Add Plan Graph And Loop Graph Models

**Files:**
- Create: `src/ralphception/runtime/loop_graph.py`
- Create: `src/ralphception/runtime/loop_planner.py`
- Modify: `src/ralphception/runtime/task_state.py`
- Create: `tests/unit/test_loop_graph.py`
- Create: `tests/unit/test_loop_planner.py`

- [ ] **Step 1: Write the failing loop-planner test**

```python
def test_loop_planner_emits_explicit_loop_definitions_from_plan_nodes() -> None:
    plan = build_plan_graph(["docs", "comments"])
    loops = LoopPlanner().plan_loops(plan)
    assert {loop.plan_node_id for loop in loops} == {"docs", "comments"}
```

- [ ] **Step 2: Write the failing parallel-safety test**

```python
def test_parallel_loops_with_overlapping_target_artifacts_require_proposal_merge() -> None:
    loops = [
        LoopDefinition(loop_id="a", plan_node_id="docs", target_artifacts=("prd",)),
        LoopDefinition(loop_id="b", plan_node_id="comments", target_artifacts=("prd",)),
    ]
    graph = LoopGraph.from_definitions(loops)
    assert graph.requires_proposal_merge("prd") is True
```

- [ ] **Step 3: Run the red loop-model tests**

Run: `uv run pytest tests/unit/test_loop_planner.py tests/unit/test_loop_graph.py tests/unit/test_task_state.py -q`

Expected: FAIL with missing loop graph / merge policy behavior.

- [ ] **Step 4: Implement the loop graph and proposal-first merge rules**

```python
@dataclass(frozen=True, slots=True)
class LoopDefinition:
    loop_id: str
    task_id: str
    plan_node_id: str
    parent_loop_id: str | None
    objective: str
    stop_conditions: tuple[str, ...]
    output_contract: tuple[str, ...]
    target_artifacts: tuple[str, ...]
    merge_strategy: Literal["proposal_first", "direct_update"]
```

- [ ] **Step 5: Re-run the loop-model tests**

Run: `uv run pytest tests/unit/test_loop_planner.py tests/unit/test_loop_graph.py tests/unit/test_task_state.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/loop_graph.py src/ralphception/runtime/loop_planner.py src/ralphception/runtime/task_state.py tests/unit/test_loop_graph.py tests/unit/test_loop_planner.py tests/unit/test_task_state.py
git commit -m "feat: define plan and loop graph runtime models"
```

### Task 9: Add Nested Subplans And Recursive Loop Expansion

**Files:**
- Modify: `src/ralphception/runtime/loop_graph.py`
- Modify: `src/ralphception/runtime/loop_planner.py`
- Modify: `src/ralphception/runtime/task_state.py`
- Modify: `src/ralphception/actor_runtime/planner_actor.py`
- Modify: `tests/unit/test_loop_graph.py`
- Modify: `tests/unit/test_loop_planner.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`

- [ ] **Step 1: Write the failing nested-subplan test**

```python
def test_broad_plan_node_can_spawn_durable_subplan_and_child_loops() -> None:
    result = expand_plan_node_into_subplan("docs-quality")
    assert result.subplan.plan_node_id == "docs-quality"
    assert len(result.child_loops) >= 2
```

- [ ] **Step 2: Write the failing recursive-loop persistence test**

```python
def test_loop_graph_persists_parent_child_relationships_for_recursive_expansion() -> None:
    graph = LoopGraph.from_nested_definitions(build_recursive_loop_definitions())
    assert graph.children_for("loop-root")
```

- [ ] **Step 3: Run the nested-loop test slice**

Run: `uv run pytest tests/unit/test_loop_graph.py tests/unit/test_loop_planner.py tests/integration/test_artifact_first_runtime.py -k "subplan or recursive" -q`

Expected: FAIL with missing subplan/recursive orchestration behavior.

- [ ] **Step 4: Implement durable subplan creation and recursive loop expansion rules**

- [ ] **Step 5: Re-run the nested-loop test slice**

Run: `uv run pytest tests/unit/test_loop_graph.py tests/unit/test_loop_planner.py tests/integration/test_artifact_first_runtime.py -k "subplan or recursive" -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/loop_graph.py src/ralphception/runtime/loop_planner.py src/ralphception/runtime/task_state.py src/ralphception/actor_runtime/planner_actor.py tests/unit/test_loop_graph.py tests/unit/test_loop_planner.py tests/integration/test_artifact_first_runtime.py
git commit -m "feat: add nested subplans and recursive loops"
```

### Task 10: Execute Ralph Loops From Explicit Plans

**Files:**
- Modify: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `src/ralphception/actor_runtime/planner_actor.py`
- Modify: `src/ralphception/actor_runtime/scheduler_actor.py`
- Modify: `src/ralphception/actor_runtime/worker_actor.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/headless.py`
- Modify: `src/ralphception/testing/fakes.py`
- Modify: `tests/integration/test_headless_supervisor.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write the failing loop-execution integration test**

```python
def test_runtime_executes_planned_loops_and_consolidates_results(tmp_path: Path) -> None:
    frontend = ScriptedInlineShell(inputs=["fix typos", "docs only"])
    result = run_terminal(repo_root=make_git_repo(tmp_path), frontend=frontend, use_fake_session_manager=True)
    text = frontend.output_text()
    assert "Launched 1 Ralph loop" in text
    assert "Loop completed" in text
    assert result.mode == "completed"
```

- [ ] **Step 2: Run the red integration slice**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py -q`

Expected: FAIL because the runtime still executes generic stage work rather than loop-graph work.

- [ ] **Step 4: Implement loop execution from explicit `LoopDefinition`**

The worker path should:
- run loops from explicit `LoopDefinition`
- emit live progress plus durable settled milestones
- write proposal outputs without making them authoritative yet

- [ ] **Step 5: Re-run the integration slice**

Run: `uv run pytest tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py -q`

Expected: PASS for loop execution and proposal outputs, with consolidation and failure propagation still handled separately.

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/actor_runtime/orchestrator.py src/ralphception/actor_runtime/planner_actor.py src/ralphception/actor_runtime/scheduler_actor.py src/ralphception/actor_runtime/worker_actor.py src/ralphception/runtime/supervisor.py src/ralphception/headless.py src/ralphception/testing/fakes.py tests/integration/test_headless_supervisor.py tests/integration/test_artifact_first_runtime.py tests/e2e/test_core_runtime.py
git commit -m "feat: execute ralph loops from durable plans"
```

### Task 11: Consolidate Proposal Outputs Into Authoritative Artifacts

**Files:**
- Modify: `src/ralphception/runtime/artifact_pipeline.py`
- Modify: `src/ralphception/runtime/loop_graph.py`
- Modify: `src/ralphception/actor_runtime/orchestrator.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `tests/unit/test_artifact_pipeline.py`
- Modify: `tests/integration/test_artifact_first_runtime.py`

- [ ] **Step 1: Write the failing consolidation test**

```python
def test_parallel_loop_proposals_require_explicit_consolidation_before_revision_advances(tmp_path: Path) -> None:
    result = run_parallel_loop_proposals(tmp_path)
    assert result.authoritative_prd_revision_before == result.authoritative_prd_revision_during
    assert result.authoritative_prd_revision_after != result.authoritative_prd_revision_before
```

- [ ] **Step 2: Add the failing child-loop failure-propagation test**

Assert that a child loop failure marks only the owning plan node blocked and emits a durable blocker summary.

- [ ] **Step 3: Run the red consolidation slice**

Run: `uv run pytest tests/unit/test_artifact_pipeline.py tests/integration/test_artifact_first_runtime.py -k "consolidation or failure_propagation" -q`

Expected: FAIL because authoritative revisions still change too loosely or failure propagation is incomplete.

- [ ] **Step 4: Implement proposal-first consolidation and failure propagation**

- [ ] **Step 5: Re-run the consolidation slice**

Run: `uv run pytest tests/unit/test_artifact_pipeline.py tests/integration/test_artifact_first_runtime.py -k "consolidation or failure_propagation" -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/artifact_pipeline.py src/ralphception/runtime/loop_graph.py src/ralphception/actor_runtime/orchestrator.py src/ralphception/runtime/supervisor.py tests/unit/test_artifact_pipeline.py tests/integration/test_artifact_first_runtime.py
git commit -m "feat: consolidate loop proposals into authoritative artifacts"
```

### Task 12: Wire Long-Running Continuity, Resume, And Explicit Final Outcomes

**Files:**
- Modify: `src/ralphception/runtime/interactive_session.py`
- Modify: `src/ralphception/storage/events.py`
- Modify: `src/ralphception/runtime/supervisor.py`
- Modify: `src/ralphception/runtime/inline_shell.py`
- Modify: `src/ralphception/runtime/terminal.py`
- Modify: `tests/integration/test_inline_shell.py`
- Modify: `tests/integration/test_actor_runtime_resume.py`
- Modify: `tests/e2e/test_core_runtime.py`

- [ ] **Step 1: Write the failing resume test**

```python
def test_reopen_restores_current_task_plan_node_and_blocker(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    first = run_terminal(repo_root=repo_root, frontend=ScriptedInlineShell(inputs=["fix typos"]), use_fake_session_manager=True)
    resumed = run_terminal(repo_root=repo_root, frontend=ScriptedInlineShell(inputs=["continue"]), use_fake_session_manager=True, resume=True)
    assert "Resumed task" in resumed.log_text
    assert "Authoritative artifacts" in resumed.log_text
    assert "Current plan node" in resumed.log_text
    assert "Active loop" in resumed.log_text
    assert "Waiting on" in resumed.log_text or "Blocked" in resumed.log_text
```

- [ ] **Step 2: Add a failing final-outcome test**

Assert that a completed run ends with an explicit settled summary and that a blocked run ends with an explicit blocker summary.

- [ ] **Step 3: Run the red resume/finality suite**

Run: `uv run pytest tests/integration/test_inline_shell.py tests/integration/test_actor_runtime_resume.py tests/e2e/test_core_runtime.py -q`

Expected: FAIL on missing task/plan/loop restoration and incomplete settled summaries.

- [ ] **Step 4: Persist and replay current task, `session_id`, current plan node, active loop set, current waiting state, failure state, queued next actions, current blocker, and last settled milestone**

Use `src/ralphception/storage/events.py` to keep replayable milestone history separate from authoritative artifacts and continuity pointers.

- [ ] **Step 5: Re-run the resume/finality suite**

Run: `uv run pytest tests/integration/test_inline_shell.py tests/integration/test_actor_runtime_resume.py tests/e2e/test_core_runtime.py -q`

Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/runtime/interactive_session.py src/ralphception/storage/events.py src/ralphception/runtime/supervisor.py src/ralphception/runtime/inline_shell.py src/ralphception/runtime/terminal.py tests/integration/test_inline_shell.py tests/integration/test_actor_runtime_resume.py tests/e2e/test_core_runtime.py
git commit -m "feat: persist and resume artifact-first loop sessions"
```

### Task 13: Remove The Boxed Product Path And Finish The Docs

**Files:**
- Modify: `src/ralphception/app.py`
- Modify: `src/ralphception/cli.py`
- Modify: `README.md`
- Modify/Delete: `src/ralphception/tui/app.py`
- Modify/Delete: `src/ralphception/tui/chatwidget/transcript_view.py`
- Modify/Delete: `src/ralphception/tui/bottom_pane/*`
- Modify: `tests/integration/test_tui_runtime_app.py`
- Modify/Delete: `tests/integration/test_tui_shell_frame.py`
- Modify/Delete: `tests/golden/codex_port/*`

- [ ] **Step 1: Write failing cleanup assertions**

Add tests or grep assertions proving the default product path no longer depends on the boxed TUI.

- [ ] **Step 2: Update README usage examples**

Document:
- Socratic intake
- mandatory durable artifacts
- inline shell behavior
- explicit Ralph-loop execution and continuation

- [ ] **Step 3: Remove or hide boxed-shell-only UX from the shipped path**

Run:

```bash
rg -n "transcript-view|RalphceptionTuiApp|codex_port" src tests README.md
```

Expected: only compatibility or non-default references remain.

- [ ] **Step 4: Run the final project verification**

Run:

```bash
PYTHONDONTWRITEBYTECODE=1 uv run pytest tests/unit tests/integration tests/e2e -q
PYTHONDONTWRITEBYTECODE=1 uv run ty check src tests
git diff --check
```

Expected:
- all tests pass
- `All checks passed!`
- no diff-check output

- [ ] **Step 5: Run the final tmux smoke**

Verify on the real shipped path:

1. `uv run ralphception`
2. enter a broad task
3. observe Socratic intake
4. observe durable artifact creation messages
5. observe one or more Ralph loops
6. observe explicit completion or blocker summary

- [ ] **Step 6: Commit**

```bash
git add src/ralphception/app.py src/ralphception/cli.py README.md src/ralphception/tui tests/integration/test_tui_runtime_app.py tests/integration/test_tui_shell_frame.py tests/golden/codex_port
git commit -m "refactor: ship inline artifact-first ralph loop runtime"
```

## Final Verification Checklist

- [ ] Default `uv run ralphception` uses the inline shell, not the boxed Textual product path.
- [ ] Every real task begins with Socratic intake.
- [ ] Intake writes durable artifacts before loop execution.
- [ ] User message classification is tested for blocker replies, in-task follow-ups, task revisions, and new task requests.
- [ ] Loop planning is explicit and durable.
- [ ] Parallel loop safety is tested for proposal-first merge behavior and failure propagation.
- [ ] The shell never silently stalls; it always shows live work, waiting, blocker, or settled completion.
- [ ] Reopen/resume restores the active task, plan node, loop state, and blocker/finality context.
- [ ] Full pytest suite, type checks, `git diff --check`, and tmux smoke pass on the shipped path.
