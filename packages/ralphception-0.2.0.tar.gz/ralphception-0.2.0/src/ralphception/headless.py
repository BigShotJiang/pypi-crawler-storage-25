"""Long-running headless mission supervisor."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import shutil
from collections.abc import Mapping, Sequence
from pathlib import Path
import subprocess
import time
from typing import Any, Literal, cast
import uuid

from pydantic import BaseModel, Field, field_validator, model_validator

from ralphception.audit.service import AuditService
from ralphception.actor_runtime.planner_actor import PlannerActor
from ralphception.actor_runtime.scheduler_actor import SchedulerActor
from ralphception.actor_runtime.worker_actor import WorkerAssignment
from ralphception.config import RalphceptionConfig, load_or_create_config as load_repo_config
from ralphception.git.commit_style import (
    build_commit_style_prompt_hint,
    normalize_commit_message_for_repo,
)
from ralphception.git.merge import MergeCoordinator
from ralphception.git.identity import resolve_git_commit_identity
from ralphception.git.worktrees import (
    WorktreeAssignment,
    WorktreeCoordinator,
    WorktreeCreateFailed,
    read_worktree_assignment,
)
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.commit_intents import CommitIntent
from ralphception.models.events import Event
from ralphception.models.mission import ExecutionPolicy
from ralphception.models.runtime import ChildAssignment, ExecutionBundle, Run
from ralphception.models.todos import TodoNode
from ralphception.models.verification import AuditFinding, VerificationScope
from ralphception.models.worktree import WorktreeHandoff
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.artifacts import (
    artifact_revision_path,
    read_authoritative_revision,
    workflow_artifact_kind_for,
)
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic, write_markdown_atomic
from ralphception.storage.lease import acquire_workspace_lease, clear_workspace_lease
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    ArtifactWriteEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FailureSummaryEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    MilestoneTranscriptLineEvent,
    PlanUpdatedEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    RuntimeStatusUpdatedEvent,
)
from ralphception.runtime.continuation import detect_continuation_hint
from ralphception.runtime.artifact_pipeline import ArtifactPipeline
from ralphception.runtime.loop_planner import LoopDefinition
from ralphception.runtime.loop_graph import LoopGraph
from ralphception.runtime.bootstrap import (
    StartupBootstrapController,
    StartupRecord,
    intake_artifact_path,
    load_startup_record,
    primary_intake_goal,
)
from ralphception.runtime.supervisor import (
    _emit_pending_prompt,
    _persist_pending_prompt,
    _review_pending_prompt,
    _startup_pending_prompt,
)
from ralphception.skills.prompting import (
    BUNDLED_SKILL_DISCLOSURE_RULE,
    load_bundled_skill_guidance,
)
from ralphception.skills.registry import StableSkillId
from ralphception.verification.service import VerificationService
from ralphception.workflow.approvals import (
    create_execution_bundle_approval,
    create_spec_review,
    persist_approval,
    read_approval,
)
from ralphception.workflow.bundles import (
    compute_scope_hash_for_artifacts,
    create_bundle,
    read_bundle,
    transition_bundle_state,
)

StageName = Literal["intake", "spec", "plan", "execute", "merge", "audit", "completed", "failed"]
ReviewTargetKind = Literal["spec_review", "execution_bundle", "recovery"]

_ROOT_RUN_ID = "run-root"
_STAGE_SEQUENCE: tuple[str, ...] = ("intake", "spec", "plan", "execute", "merge", "audit")
_CONTRACT_BEGIN = "HEADLESS_CONTRACT_START"
_CONTRACT_END = "HEADLESS_CONTRACT_END"
_DEFAULT_SPEC_FILENAME = "prd.md"
_DEFAULT_PLAN_MARKDOWN_FILENAME = "execution-plan.md"
_DEFAULT_PLAN_CONTRACT_FILENAME = "execution-plan.json"
_LEGACY_PLAN_CONTRACT_FILENAME = "mission-plan.json"
_PLACEHOLDER_TOKEN_RE = re.compile(r"<[A-Za-z][^>\n]*>")


class HeadlessState(BaseModel):
    current_stage: StageName = "intake"
    completed_stages: list[str] = Field(default_factory=list)
    stage_attempts: dict[str, int] = Field(default_factory=dict)
    current_child_run_id: str | None = None
    child_run_ids: list[str] = Field(default_factory=list)
    last_approved_bundle_version: int | None = None
    execution_goal: str | None = None
    pending_child_goal: str | None = None
    loop_graph_id: str | None = None
    active_loop_ids: list[str] = Field(default_factory=list)
    completed_loop_ids: list[str] = Field(default_factory=list)
    terminal_outcome: Literal["completed", "failed"] | None = None
    audit_reopened: bool = False


class PlanContract(BaseModel):
    execution_goal: str
    verification_commands: list[str] = Field(default_factory=list)
    todos: list[TodoNode] = Field(default_factory=list)
    commit_intents: list[CommitIntent] = Field(default_factory=list)
    execution_policy: ExecutionPolicy = Field(default_factory=ExecutionPolicy)

    @field_validator("execution_goal")
    @classmethod
    def _validate_goal(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("execution_goal must not be blank")
        return value

    @field_validator("verification_commands")
    @classmethod
    def _normalize_verification_commands(cls, value: list[str]) -> list[str]:
        normalized: list[str] = []
        for command in value:
            stripped = command.strip()
            if not stripped:
                continue
            if _PLACEHOLDER_TOKEN_RE.search(stripped):
                continue
            normalized.append(stripped)
        return normalized


class ExecuteArtifactContract(BaseModel):
    path: str
    kind: str = "code"

    @field_validator("path", "kind")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("execute artifact fields must not be blank")
        return value


class ExecuteContract(BaseModel):
    summary: str
    artifacts: list[ExecuteArtifactContract]
    touched_paths: list[str]
    merge_readiness: Literal["ready", "needs_revision", "blocked"] = "ready"

    @field_validator("summary", mode="before")
    @classmethod
    def _normalize_summary(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value
        if not isinstance(value, list):
            return value
        normalized = [str(item).strip() for item in value if isinstance(item, str) and str(item).strip()]
        return " ".join(normalized)

    @field_validator("artifacts", mode="before")
    @classmethod
    def _normalize_artifacts(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        normalized: list[Any] = []
        for artifact in value:
            if isinstance(artifact, str):
                if _is_child_handoff_metadata_artifact(artifact):
                    continue
                kind = "metadata" if artifact.startswith(".ralphception/") else "code"
                normalized.append({"path": artifact, "kind": kind})
            else:
                if isinstance(artifact, Mapping) and _is_child_handoff_metadata_artifact(str(artifact.get("path", ""))):
                    continue
                normalized.append(artifact)
        return normalized

    @field_validator("touched_paths", mode="before")
    @classmethod
    def _normalize_touched_paths(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value
        return [
            path
            for path in value
            if isinstance(path, str) and not _is_child_handoff_metadata_artifact(path)
        ]

    @field_validator("merge_readiness", mode="before")
    @classmethod
    def _normalize_merge_readiness(cls, value: Any) -> Any:
        if isinstance(value, str):
            return value
        if not isinstance(value, Mapping):
            return value
        status = value.get("status")
        if isinstance(status, str):
            return status
        if value.get("blocked") is True:
            return "blocked"
        ready = value.get("ready")
        if isinstance(ready, bool):
            return "ready" if ready else "needs_revision"
        return value

    @model_validator(mode="after")
    def _validate_merge_ready_change_scope(self) -> "ExecuteContract":
        if self.merge_readiness == "ready" and not self.touched_paths:
            raise ValueError("merge-ready execute handoffs must report at least one touched path")
        return self


class AuditFindingContract(BaseModel):
    finding_id: str
    severity: Literal["P0", "P1", "P2", "P3"]
    kind: Literal["bug", "test_gap", "feature_gap", "spec_drift", "integration_risk"]
    title: str
    status: Literal["open", "accepted", "resolved", "wontfix"] = "open"
    evidence_paths: list[str] = Field(default_factory=list)


class AuditContract(BaseModel):
    findings: list[AuditFindingContract] = Field(default_factory=list)


class HeadlessRunResult(BaseModel):
    mode: Literal["startup", "review", "dashboard", "completed", "failed"]
    actions: tuple[str, ...]
    review_target_kind: ReviewTargetKind | None = None
    root_run_id: str | None = None
    root_run_status: str | None = None
    authoritative_repo_root: str | None = None
    child_run_ids: tuple[str, ...] = ()
    completed_stages: tuple[str, ...] = ()
    current_stage: StageName | None = None
    audit_reopened: bool = False
    engine: object | None = None
    watchdog_trigger_reason: str | None = None


def run_headless_mission(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    approve_all: bool = False,
    approver: str = "headless",
    session_manager_factory=None,
) -> HeadlessRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    supervisor = HeadlessMissionSupervisor(
        repo_root=resolved_repo_root,
        primary_repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=session_manager_factory,
    )
    return supervisor.run()


class HeadlessMissionSupervisor:
    def __init__(
        self,
        *,
        repo_root: Path,
        primary_repo_root: Path,
        seed_prompt: str | None,
        source_repos: tuple[str, ...],
        approve_all: bool,
        approver: str,
        session_manager_factory,
        announce_resume: bool = True,
    ) -> None:
        self.primary_repo_root = bootstrap_workspace(primary_repo_root)
        self.repo_root = bootstrap_workspace(repo_root)
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self.announce_resume = announce_resume
        _ensure_runtime_paths_excluded(self.repo_root)
        self.target_branch: str | None = None
        self.config = _load_or_create_config(self.repo_root)
        self.session_manager = None if session_manager_factory is None else session_manager_factory(
            self.repo_root,
            self.config,
        )
        self.event_store = EventStore(self.repo_root)
        self.actions: list[str] = []
        self._frontend = None
        self._last_announced_stage: StageName | None = None
        self._agent_message_chunks: dict[str, list[str]] = {}
        self.startup_record = load_startup_record(self.repo_root)
        self.root_run = self._ensure_root_run() if self.startup_record is not None else None
        self.state = self._load_state() if self.root_run is not None else HeadlessState()
        if self.root_run is not None:
            self._hydrate_state_from_workspace()

    def run(self, *, frontend=None) -> HeadlessRunResult:
        self._frontend = frontend
        self._pending_watchdog_trigger_reason: str | None = None
        if self.startup_record is None:
            if self.seed_prompt is None or not self.seed_prompt.strip():
                prompt = _startup_pending_prompt(self.repo_root, source_repos=self.source_repos)
                _persist_pending_prompt(
                    self.repo_root,
                    prompt,
                    root_thread_id=prompt.thread_id,
                    active_thread_id=prompt.thread_id,
                    bootstrap_source_repos=self.source_repos,
                )
                _emit_pending_prompt(frontend, prompt)
                return self._result(mode="startup")
            self.startup_record = self._ensure_startup_record()
            self.root_run = self._ensure_root_run()
            self.state = self._load_state()
            self._hydrate_state_from_workspace()
            if frontend is not None:
                frontend.emit_event(
                    FrontendEvent(
                        message=f"Bootstrapped {self.startup_record.outer_run_id}",
                        kind="runtime.bootstrapped",
                        run_id=self.startup_record.outer_run_id,
                    )
                )
        elif frontend is not None and self.root_run is not None and self.announce_resume:
            frontend.emit_event(
                FrontendEvent(
                    message=f"Resumed {self.root_run.run_id}",
                    kind="runtime.resumed",
                    run_id=self.root_run.run_id,
                )
            )

        if self.root_run is None:
            raise RuntimeError("root run is required after bootstrap")
        self._emit_current_task_label(self.root_run.goal)

        if self.state.terminal_outcome == "completed":
            self.root_run = self._update_run(self.root_run, status="completed")
            self._cleanup_completed_runtime_state()
            return self._result(mode="completed")
        if self.state.terminal_outcome == "failed":
            self.root_run = self._update_run(self.root_run, status="failed")
            return self._result(mode="failed")

        self._persist_state()
        if self.session_manager is None:
            return self._result(mode="dashboard")

        self._ensure_run_session(self.root_run, workspace_path=self.repo_root)
        self._prime_direct_execution_startup()

        try:
            while self.state.terminal_outcome is None:
                if self.state.current_stage == "intake":
                    self._mark_stage_complete("intake", next_stage="spec")
                    continue
                if self.state.current_stage == "spec":
                    self._announce_stage("spec")
                    review_result = self._run_spec_stage(frontend=frontend)
                    if review_result is not None:
                        return review_result
                    continue
                if self.state.current_stage == "plan":
                    self._announce_stage("plan")
                    review_result = self._run_plan_stage(frontend=frontend)
                    if review_result is not None:
                        return review_result
                    continue
                if self.state.current_stage == "execute":
                    self._announce_stage("execute")
                    if not self._run_execute_stage():
                        return self._result(mode="failed")
                    continue
                if self.state.current_stage == "merge":
                    self._announce_stage("merge")
                    if not self._run_merge_stage():
                        return self._result(mode="failed")
                    continue
                if self.state.current_stage == "audit":
                    self._announce_stage("audit")
                    self._run_audit_stage()
                    continue
                if self.state.current_stage == "completed":
                    self._emit_frontend_event(f"Session completed: {self.root_run.run_id}")
                    self.state.terminal_outcome = "completed"
                    self.root_run = self._update_run(self.root_run, status="completed")
                    self._persist_state()
                    self._cleanup_completed_runtime_state()
                    return self._result(mode="completed")
                raise RuntimeError(f"unsupported headless stage: {self.state.current_stage}")
        except Exception:
            self.state.current_stage = "failed"
            self.state.terminal_outcome = "failed"
            self.root_run = self._update_run(self.root_run, status="failed")
            self._persist_state()
            raise

        if self.state.terminal_outcome == "completed":
            self._cleanup_completed_runtime_state()
            return self._result(mode="completed")
        if self.state.terminal_outcome == "failed":
            return self._result(mode="failed")
        return self._result(mode="completed")

    def _run_spec_stage(self, *, frontend=None) -> HeadlessRunResult | None:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        spec_path = _preferred_spec_path(self.repo_root)
        if not spec_path.exists():
            self._run_turn(
                run_id=root_run.run_id,
                goal=root_run.goal,
                workspace_path=self.repo_root,
                stage_kind="spec",
                prompt=self._build_spec_prompt(spec_path),
            )
        spec_ref = _artifact_ref_for_file(self.repo_root, spec_path.relative_to(self.repo_root), "spec")
        if not self._has_spec_review_approval():
            if not self.approve_all:
                pending_prompt = _review_pending_prompt(
                    review_kind="spec_review",
                    run_id=root_run.run_id,
                    summary_text=f"Spec review pending for {spec_ref.artifact_path}",
                    recommended_actions=("approve",),
                )
                _persist_pending_prompt(
                    self.repo_root,
                    pending_prompt,
                    root_thread_id="run-root",
                    active_thread_id=pending_prompt.thread_id,
                )
                _emit_pending_prompt(frontend, pending_prompt)
                self._persist_state()
                return self._result(mode="review", review_target_kind="spec_review")
            approval = create_spec_review(
                approval_id="approval-spec-1",
                run_id=root_run.run_id,
                approver=self.approver,
                spec_artifacts=[spec_ref],
                bundle_version=1,
                scope_hash=compute_scope_hash_for_artifacts(self.repo_root, [spec_ref]),
            )
            persist_approval(self.repo_root, approval)
            self.actions.append("approved:spec_review")
            self._emit_frontend_event("Approved: spec_review")
        self.root_run = self._update_run(
            root_run,
            artifact_refs=[startup_record.intake_artifact, spec_ref],
        )
        self._mark_stage_complete("spec", next_stage="plan")
        return None

    def _run_plan_stage(self, *, frontend=None) -> HeadlessRunResult | None:
        from ralphception.actor_runtime.planner_actor import PlannerActor

        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        plan_path = _preferred_plan_markdown_path(self.repo_root)
        plan_contract_path = _preferred_plan_contract_path(self.repo_root)
        if not plan_path.exists():
            self._run_turn(
                run_id=root_run.run_id,
                goal=root_run.goal,
                workspace_path=self.repo_root,
                stage_kind="plan",
                prompt=self._build_plan_prompt(plan_path, plan_contract_path),
            )
        plan_ref = _artifact_ref_for_file(self.repo_root, plan_path.relative_to(self.repo_root), "plan")
        bundle = self._ensure_execution_bundle(plan_ref)
        if bundle.state != "approved":
            if not self.approve_all:
                pending_prompt = _review_pending_prompt(
                    review_kind="execution_bundle",
                    run_id=bundle.run_id,
                    summary_text=f"Execution bundle {bundle.bundle_id} is waiting for approval.",
                    recommended_actions=("approve",),
                )
                _persist_pending_prompt(
                    self.repo_root,
                    pending_prompt,
                    root_thread_id="run-root",
                    active_thread_id=pending_prompt.thread_id,
                )
                _emit_pending_prompt(frontend, pending_prompt)
                self._persist_state()
                return self._result(mode="review", review_target_kind="execution_bundle")
            bundle = transition_bundle_state(
                self.repo_root,
                bundle=bundle,
                next_state="approved",
                stage_id="stage-plan",
            )
            if not self._has_execution_bundle_approval(bundle.bundle_version):
                approval = create_execution_bundle_approval(
                    approval_id=f"approval-exec-{bundle.bundle_version}",
                    approver=self.approver,
                    bundle=bundle,
                )
                persist_approval(self.repo_root, approval)
            self.actions.append("approved:execution_bundle")
            self._emit_frontend_event("Approved: execution_bundle")

        plan_contract = _load_plan_contract(plan_contract_path, default_goal=self._default_execution_goal(bundle))
        PlannerActor(repo_root=self.repo_root).plan(approved_spec_path=_preferred_spec_path(self.repo_root))
        self.state.execution_goal = plan_contract.execution_goal
        self.state.last_approved_bundle_version = bundle.bundle_version
        intake_ref = _artifact_ref_for_file(
            self.repo_root,
            Path(startup_record.intake_artifact.artifact_path),
            "intake",
        )
        self.root_run = self._update_run(root_run, artifact_refs=[intake_ref, plan_ref])
        self._mark_stage_complete("plan", next_stage="execute")
        return None

    def _run_execute_stage(self) -> bool:
        bundle = self._latest_bundle()
        if bundle is None or bundle.state != "approved":
            raise RuntimeError("execute stage requires an approved execution bundle")
        plan_contract = _load_plan_contract(
            _preferred_plan_contract_path(self.repo_root),
            default_goal=self._default_execution_goal(bundle),
        )
        loop_graph, loop_assignments = self._plan_loop_assignments(plan_contract)
        if not loop_assignments:
            raise RuntimeError("execute stage requires at least one planned Ralph loop")
        replacement_goal = self.state.pending_child_goal
        pending_assignments = [
            assignment
            for assignment in loop_assignments
            if assignment.loop_id not in self.state.completed_loop_ids
        ]
        if replacement_goal is not None:
            selected_assignment = self._select_reopened_loop_assignment(loop_assignments)
        else:
            if not pending_assignments:
                raise RuntimeError("execute stage has no remaining planned Ralph loops")
            selected_assignment = pending_assignments[0]
        selected_loop_id = selected_assignment.loop_id or "loop-root"
        selected_loop = loop_graph.loop(selected_loop_id)
        if selected_loop_id not in self.state.active_loop_ids and selected_loop_id not in self.state.completed_loop_ids:
            loop_count = len(pending_assignments) or 1
            launch_message = (
                f"Launched {loop_count} Ralph loop"
                if loop_count == 1
                else f"Launched {loop_count} Ralph loops"
            )
            root_run = self._require_root_run()
            self._emit_frontend_event(
                launch_message,
                kind="loop.launched",
                run_id=root_run.run_id,
                stage_kind="execute",
                payload={
                    "loop_graph_id": loop_graph.loop_graph_id,
                    "loop_id": selected_loop_id,
                    "plan_node_id": selected_assignment.plan_node_id,
                    "loop_count": loop_count,
                },
            )
            self._append_headless_event(
                run_id=root_run.run_id,
                stage_id="stage-execute",
                event_type="stage.custom_loop_launched",
                payload={
                    "stage_kind": "execute",
                    "loop_graph_id": loop_graph.loop_graph_id,
                    "loop_id": selected_loop_id,
                    "plan_node_id": selected_assignment.plan_node_id,
                    "loop_count": loop_count,
                },
            )
            self.actions.append(f"loop_launched:{selected_loop_id}")
            self.state.active_loop_ids.append(selected_loop_id)
            self._persist_state()
        try:
            child_run = self._ensure_child_run(bundle, plan_contract, loop_assignment=selected_assignment)
        except WorktreeCreateFailed:
            failed_run = self._current_child_run()
            if failed_run is None:
                raise
            self._emit_frontend_event(f"Worktree setup failed: {failed_run.run_id} execute")
            self._fail_child_run(
                failed_run,
                stage_id="stage-execute",
                reason="worktree_create_failed",
                before_orchestration=True,
            )
            return False
        assignment = read_worktree_assignment(self.repo_root, child_run.run_id)
        self._run_turn(
            run_id=child_run.run_id,
            goal=child_run.goal,
            workspace_path=assignment.worktree_path,
            stage_kind="execute",
            prompt=self._build_execute_prompt(
                run_id=child_run.run_id,
                goal=child_run.goal,
                handoff_path=assignment.worktree_path / ".ralphception" / "runs" / child_run.run_id / "handoff.json",
                loop_definition=selected_loop,
            ),
        )

        local_handoff_path = assignment.worktree_path / ".ralphception" / "runs" / child_run.run_id / "handoff.json"
        contract = ExecuteContract.model_validate_json(local_handoff_path.read_text(encoding="utf-8"))
        self._commit_child_changes(
            worktree_path=assignment.worktree_path,
            run_id=child_run.run_id,
            touched_paths=contract.touched_paths,
        )
        verification_refs, verification_summary, passed = self._run_verification(
            run_id=child_run.run_id,
            stage_id="stage-execute",
            scope="child_run",
            cwd=assignment.worktree_path,
            commands=plan_contract.verification_commands or _default_verification_commands(self.repo_root),
        )
        if not passed:
            failure = ArtifactPipeline(self.repo_root).record_loop_failure(
                loop_graph=loop_graph,
                loop_id=selected_loop_id,
                reason="verification_failed",
            )
            self._emit_frontend_event(
                f"Blocked plan node(s): {', '.join(failure.blocked_plan_node_ids)}",
                kind="loop.failed",
                run_id=child_run.run_id,
                stage_kind="execute",
                payload={"loop_id": selected_loop_id, "blocked_plan_node_ids": failure.blocked_plan_node_ids},
            )
            self._fail_child_run(
                child_run,
                stage_id="stage-execute",
                reason="verification_failed",
                artifact_refs=verification_refs,
            )
            return False

        artifact_refs = [
            _artifact_ref_for_file(self.repo_root, Path(artifact.path), artifact.kind, root=assignment.worktree_path)
            for artifact in contract.artifacts
        ]
        normalized_handoff = WorktreeHandoff(
            child_run_id=child_run.run_id,
            worktree_path=str(assignment.worktree_path),
            branch_name=assignment.branch_name or assignment.target_branch,
            base_branch=assignment.base_ref,
            head_commit=_git_output(assignment.worktree_path, "rev-parse", "HEAD"),
            goal=child_run.goal,
            artifact_refs=artifact_refs,
            verification_artifact_refs=[],
            consumed_bundle_version=bundle.bundle_version,
            touched_paths=contract.touched_paths,
            verification_summary=verification_summary,
            merge_readiness=contract.merge_readiness,
            cleanup_state="pending",
        )
        root_handoff_path = self.repo_root / ".ralphception" / "runs" / child_run.run_id / "handoff.json"
        write_json_atomic(root_handoff_path, normalized_handoff.model_dump(mode="json"))
        child_run = self._update_run(
            child_run,
            status="completed",
            artifact_refs=[*artifact_refs, *verification_refs],
        )
        self._persist_run(child_run)
        proposals = ArtifactPipeline(self.repo_root).stage_loop_completion(
            loop_graph=loop_graph,
            loop_id=selected_loop_id,
        )
        if proposals:
            authoritative_kinds = [
                proposal.artifact_kind
                for proposal in proposals
                if ArtifactPipeline(self.repo_root).authoritative_revision(proposal.artifact_kind) == proposal.revision_id
            ]
            if authoritative_kinds:
                authoritative_paths = _summarize_authoritative_update_paths(
                    contract.touched_paths,
                    fallback_paths=[artifact.path for artifact in contract.artifacts],
                )
                self._emit_frontend_event(
                    f"Updated authoritative artifacts: {', '.join(authoritative_paths)}",
                    kind="artifact.authoritative.updated",
                    run_id=child_run.run_id,
                    stage_kind="execute",
                    payload={
                        "artifact_kinds": authoritative_kinds,
                        "artifact_paths": authoritative_paths,
                    },
                )
            else:
                self._emit_frontend_event(
                    f"Staged loop proposals for consolidation: {', '.join(proposal.artifact_kind for proposal in proposals)}",
                    kind="artifact.proposals.staged",
                    run_id=child_run.run_id,
                    stage_kind="execute",
                    payload={"artifact_kinds": [proposal.artifact_kind for proposal in proposals]},
                )
        if selected_loop_id in self.state.active_loop_ids:
            self.state.active_loop_ids.remove(selected_loop_id)
        if selected_loop_id not in self.state.completed_loop_ids:
            self.state.completed_loop_ids.append(selected_loop_id)
        self.actions.append(f"loop_completed:{selected_loop_id}")
        self._append_headless_event(
            run_id=self._require_root_run().run_id,
            stage_id="stage-execute",
            event_type="stage.custom_loop_completed",
            payload={
                "stage_kind": "execute",
                "loop_id": selected_loop_id,
                "plan_node_id": selected_assignment.plan_node_id,
            },
        )
        self._emit_loop_completion(
            loop_label=child_run.run_id,
            message=f"Loop completed: {child_run.run_id} {contract.summary}",
        )
        self._mark_stage_complete("execute", next_stage="merge")
        return True

    def _run_merge_stage(self) -> bool:
        root_run = self._require_root_run()
        child_run_id = self.state.current_child_run_id
        if child_run_id is None:
            raise RuntimeError("merge stage requires an active child run")
        child_run = self._current_child_run()
        if child_run is None:
            raise RuntimeError("merge stage requires the current child run record")
        acquire_workspace_lease(
            self.repo_root,
            run_id=root_run.run_id,
            process_id=os.getpid(),
            authoritative_repository_root=self.repo_root,
        )
        bundle = self._latest_bundle()
        if bundle is None:
            raise RuntimeError("merge stage requires a bundle")
        handoff_path = self.repo_root / ".ralphception" / "runs" / child_run_id / "handoff.json"
        handoff = WorktreeHandoff.model_validate_json(handoff_path.read_text(encoding="utf-8"))
        plan_contract = _load_plan_contract(
            _preferred_plan_contract_path(self.repo_root),
            default_goal=self._default_execution_goal(bundle),
        )
        coordinator = MergeCoordinator(
            repo_root=self.repo_root,
            run_id=root_run.run_id,
            stage_id="stage-merge",
            target_branch=self._resolve_target_branch(),
        )
        outcome = coordinator.finalize_merge(
            handoff=handoff,
            latest_bundle=bundle,
            latest_goal=handoff.goal,
            dependency_refs=[],
            newest_required_verification_passed=True,
            run_merge_verification=lambda integration_path: self._run_merge_verification(
                run_id=child_run_id,
                cwd=integration_path,
                commands=plan_contract.verification_commands or _default_verification_commands(self.repo_root),
            ),
        )
        if outcome.status != "merged":
            self._fail_child_run(
                child_run,
                stage_id="stage-merge",
                reason="; ".join(outcome.reasons),
            )
            return False
        if outcome.recovery is not None and outcome.recovery.lease_updated:
            self._rebind_repo_root(outcome.integration_worktree_path)
        try:
            WorktreeCoordinator(repo_root=self.repo_root).cleanup_worktree(
                run_id=root_run.run_id,
                worktree_path=outcome.integration_worktree_path,
                retain=False,
            )
        except Exception:
            pass
        self.actions.append(f"merged:{child_run_id}")
        self._emit_frontend_event(f"Merged: {child_run_id}")
        _, loop_assignments = self._plan_loop_assignments(plan_contract)
        remaining_assignments = [
            assignment
            for assignment in loop_assignments
            if assignment.loop_id not in self.state.completed_loop_ids
        ]
        if remaining_assignments:
            next_run_id = _next_child_run_id(self.state.child_run_ids)
            self.state.current_child_run_id = next_run_id
            if next_run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(next_run_id)
            self.state.current_stage = "execute"
            self._persist_state()
            return True
        self._mark_stage_complete("merge", next_stage="audit")
        return True

    def _run_audit_stage(self) -> None:
        root_run = self._require_root_run()
        audit_path = self.repo_root / ".ralphception" / "runs" / root_run.run_id / "audit-findings.json"
        self._run_turn(
            run_id=root_run.run_id,
            goal=root_run.goal,
            workspace_path=self.repo_root,
            stage_kind="audit",
            prompt=self._build_audit_prompt(audit_path),
        )
        contract = AuditContract.model_validate_json(audit_path.read_text(encoding="utf-8"))
        findings = self._persist_audit_contract(contract)
        if AuditService(self.repo_root).blocks_completion(findings):
            titles = ", ".join(finding.title for finding in findings if finding.status == "open")
            replacement_run_id = _next_replacement_run_id(self.state.current_child_run_id or "run-child-1")
            self.state.audit_reopened = True
            self.state.current_child_run_id = replacement_run_id
            if replacement_run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(replacement_run_id)
            self.state.pending_child_goal = f"Resolve blocking audit findings: {titles}."
            self.state.current_stage = "execute"
            self._append_headless_event(
                run_id=root_run.run_id,
                stage_id="stage-audit",
                event_type="stage.custom_headless_audit_reopened",
                payload={
                    "stage_kind": "audit",
                    "replacement_run_id": replacement_run_id,
                    "findings": [finding.finding_id for finding in findings if finding.status == "open"],
                },
            )
            self.actions.append("reopened:audit")
            self._emit_frontend_event(f"Audit reopened execution with {replacement_run_id}")
            self._persist_state()
            return

        self._emit_milestone_transcript_line("Audit passed: no blocking findings")
        self._mark_stage_complete("audit", next_stage="completed")
        self.state.terminal_outcome = "completed"
        self.state.current_stage = "completed"
        self.root_run = self._update_run(root_run, status="completed")
        self._emit_milestone_transcript_line(f"Session completed: {root_run.run_id}")
        self._persist_state()

    def _prime_direct_execution_startup(self) -> None:
        """Synthesize the minimal approved artifacts needed to enter execute directly."""
        if self.startup_record is None or self.root_run is None:
            return
        if self.state.current_stage not in {"intake", "spec", "plan"}:
            return

        execution_goal = primary_intake_goal(self.startup_record.seed_prompt)
        self._emit_artifact_write(
            artifact_kind="intake",
            artifact_path=self.repo_root / self.startup_record.intake_artifact.artifact_path,
            message="Wrote intake summary",
        )
        spec_path = _preferred_spec_path(self.repo_root)
        if not spec_path.exists():
            write_markdown_atomic(
                spec_path,
                _default_spec_markdown(
                    seed_prompt=execution_goal,
                    source_repos=tuple(self.startup_record.source_repos),
                ),
            )
            self._emit_artifact_write(
                artifact_kind="spec",
                artifact_path=spec_path,
                message="Wrote PRD",
            )
        spec_ref = _artifact_ref_for_file(self.repo_root, spec_path.relative_to(self.repo_root), "spec")
        if not self._has_spec_review_approval():
            persist_approval(
                self.repo_root,
                create_spec_review(
                    approval_id="approval-spec-1",
                    run_id=self.root_run.run_id,
                    approver=self.approver,
                    spec_artifacts=[spec_ref],
                    bundle_version=1,
                    scope_hash=compute_scope_hash_for_artifacts(self.repo_root, [spec_ref]),
                ),
            )
            self.actions.append("approved:spec_review")

        plan_path = _preferred_plan_markdown_path(self.repo_root)
        plan_contract_path = _preferred_plan_contract_path(self.repo_root)
        verification_commands = _default_verification_commands(self.repo_root)
        if not plan_path.exists():
            write_markdown_atomic(
                plan_path,
                _default_plan_markdown(
                    execution_goal=execution_goal,
                    verification_commands=verification_commands,
                ),
            )
        if not plan_contract_path.exists():
            write_json_atomic(
                plan_contract_path,
                {
                    "execution_goal": execution_goal,
                    "verification_commands": verification_commands,
                    "todos": [todo.model_dump(mode="json") for todo in _default_todos(execution_goal)],
                    "commit_intents": [
                        intent.model_dump(mode="json")
                        for intent in _default_commit_intents(self.repo_root, execution_goal)
                    ],
                    "execution_policy": ExecutionPolicy().model_dump(mode="json"),
                },
            )
        bootstrap_artifact_refs = self._emit_bootstrap_pipeline_artifact_writes()
        plan_ref = _artifact_ref_for_file(self.repo_root, plan_path.relative_to(self.repo_root), "plan")
        bundle = self._ensure_execution_bundle(plan_ref)
        if bundle.state != "approved":
            bundle = transition_bundle_state(
                self.repo_root,
                bundle=bundle,
                next_state="approved",
                stage_id="stage-plan",
            )
        if not self._has_execution_bundle_approval(bundle.bundle_version):
            persist_approval(
                self.repo_root,
                create_execution_bundle_approval(
                    approval_id=f"approval-exec-{bundle.bundle_version}",
                    approver=self.approver,
                    bundle=bundle,
                ),
            )
            self.actions.append("approved:execution_bundle")

        self.state.execution_goal = execution_goal
        self.state.last_approved_bundle_version = bundle.bundle_version
        self.root_run = self._update_run(
            self.root_run,
            artifact_refs=[
                self.startup_record.intake_artifact,
                spec_ref,
                plan_ref,
                *bootstrap_artifact_refs,
            ],
        )
        self._ensure_completed_stage("intake")
        self._ensure_completed_stage("spec")
        self._ensure_completed_stage("plan")
        self.state.current_stage = "execute"
        self._persist_state()

    def _ensure_startup_record(self) -> StartupRecord:
        controller = StartupBootstrapController(self.repo_root)
        if not controller.needs_bootstrap():
            record = load_startup_record(self.repo_root)
            if record is None:
                raise RuntimeError("workspace bootstrap state is missing")
            return record
        if self.seed_prompt is None or not self.seed_prompt.strip():
            raise RuntimeError("seed_prompt is required when workspace needs bootstrap")
        record = controller.start_first_run(
            seed_prompt=self.seed_prompt,
            source_repos=self.source_repos,
        )
        self.actions.append(f"bootstrapped:{record.outer_run_id}")
        self._emit_artifact_write(
            artifact_kind="intake",
            artifact_path=self.repo_root / record.intake_artifact.artifact_path,
            message="Wrote intake summary",
        )
        return record

    def _ensure_root_run(self) -> Run:
        if self.startup_record is None:
            raise RuntimeError("workspace bootstrap state is missing")
        run_path = self.repo_root / ".ralphception" / "runs" / _ROOT_RUN_ID / "run.json"
        if run_path.exists():
            return Run.model_validate_json(run_path.read_text(encoding="utf-8"))
        run = Run(
            run_id=_ROOT_RUN_ID,
            parent_run_id=None,
            supersedes_run_id=None,
            goal=self.startup_record.seed_prompt,
            status="pending",
            stage_ids=[f"stage-{stage}" for stage in _STAGE_SEQUENCE],
            config_snapshot={
                "codex": {"model": self.config.codex.model},
                "source_repos": self.startup_record.source_repos,
            },
            codex_session_ref=None,
            artifact_refs=[self.startup_record.intake_artifact],
            created_at=self.startup_record.created_at,
            updated_at=self.startup_record.created_at,
        )
        self._persist_run(run)
        return run

    def _load_state(self) -> HeadlessState:
        if self.root_run is None:
            return HeadlessState()
        path = self.repo_root / ".ralphception" / "runs" / self.root_run.run_id / "headless-state.json"
        if not path.exists():
            return HeadlessState()
        return HeadlessState.model_validate_json(path.read_text(encoding="utf-8"))

    def _hydrate_state_from_workspace(self) -> None:
        root_run = self._require_root_run()
        if "intake" not in self.state.completed_stages and load_startup_record(self.repo_root) is not None:
            self.state.completed_stages.append("intake")
            self.state.current_stage = "spec"
        spec_path = _preferred_spec_path(self.repo_root)
        if spec_path.exists() and self._has_spec_review_approval():
            self._ensure_completed_stage("spec")
            if self.state.current_stage == "spec":
                self.state.current_stage = "plan"
        bundle = self._latest_bundle()
        plan_path = _preferred_plan_markdown_path(self.repo_root)
        if plan_path.exists() and bundle is not None and bundle.state == "approved":
            self._ensure_completed_stage("plan")
            self.state.last_approved_bundle_version = bundle.bundle_version
            if self.state.current_stage == "plan":
                self.state.current_stage = "execute"
        for path in sorted((self.repo_root / ".ralphception" / "runs").glob("*/run.json")):
            if path.parent.name == root_run.run_id:
                continue
            run = Run.model_validate_json(path.read_text(encoding="utf-8"))
            if run.run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(run.run_id)

    def _ensure_execution_bundle(self, plan_ref: ArtifactRef) -> ExecutionBundle:
        root_run = self._require_root_run()
        existing = self._latest_bundle()
        if existing is not None:
            return existing
        spec_ref = _artifact_ref_for_file(
            self.repo_root,
            _preferred_spec_path(self.repo_root).relative_to(self.repo_root),
            "spec",
        )
        return create_bundle(
            self.repo_root,
            bundle_id="bundle-2",
            run_id=root_run.run_id,
            bundle_version=2,
            state="awaiting_approval",
            artifact_refs=[spec_ref, plan_ref],
            stage_id="stage-plan",
        )

    def _ensure_child_run(
        self,
        bundle: ExecutionBundle,
        plan_contract: PlanContract,
        *,
        loop_assignment: WorkerAssignment | None = None,
    ) -> Run:
        root_run = self._require_root_run()
        if self.state.current_child_run_id is None:
            next_run_id = "run-child-1" if not self.state.child_run_ids else self.state.child_run_ids[-1]
            if next_run_id in self.state.child_run_ids:
                next_run_id = _next_replacement_run_id(next_run_id)
            self.state.current_child_run_id = next_run_id
            if next_run_id not in self.state.child_run_ids:
                self.state.child_run_ids.append(next_run_id)

        run_id = self.state.current_child_run_id
        run_path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if run_path.exists():
            existing = Run.model_validate_json(run_path.read_text(encoding="utf-8"))
            assignment_path = self.repo_root / ".ralphception" / "runs" / run_id / "worktree.json"
            if assignment_path.exists():
                return existing
            return self._materialize_child_run(
                child_run=existing,
                bundle=bundle,
                plan_contract=plan_contract,
                goal=existing.goal,
                root_run=root_run,
                announce_created=False,
            )

        goal = (
            self.state.pending_child_goal
            or (loop_assignment.goal if loop_assignment is not None else None)
            or self.state.execution_goal
            or plan_contract.execution_goal
        )
        child_run = Run(
            run_id=run_id,
            parent_run_id=root_run.run_id,
            supersedes_run_id=_superseded_run_id(run_id),
            goal=goal,
            status="pending",
            stage_ids=["stage-execute"],
            config_snapshot=root_run.config_snapshot,
            codex_session_ref=None,
            artifact_refs=list(bundle.artifact_refs),
            created_at=_utc_now(),
            updated_at=_utc_now(),
        )
        self._persist_run(child_run)
        return self._materialize_child_run(
            child_run=child_run,
            bundle=bundle,
            plan_contract=plan_contract,
            goal=goal,
            root_run=root_run,
            announce_created=True,
        )

    def _materialize_child_run(
        self,
        *,
        child_run: Run,
        bundle: ExecutionBundle,
        plan_contract: PlanContract,
        goal: str,
        root_run: Run,
        announce_created: bool,
    ) -> Run:
        worktrees = WorktreeCoordinator(repo_root=self.repo_root)
        created = worktrees.create_child_worktree(
            run_id=child_run.run_id,
            base_ref=self._resolve_target_branch(),
            target_branch=child_run.run_id,
            goal=goal,
        )
        session_ref = self._start_run_session(
            run_id=child_run.run_id,
            goal=goal,
            parent_run_id=root_run.run_id,
            workspace_path=created.worktree_path,
        )
        child_run = self._update_run(
            child_run,
            status="running",
            codex_session_ref=session_ref,
            artifact_refs=list(child_run.artifact_refs or bundle.artifact_refs),
        )
        final_commit_message = _resolve_child_final_commit_message(
            repo_root=self.repo_root,
            goal=goal,
            plan_contract=plan_contract,
        )
        assignment = ChildAssignment(
            assignment_id=f"assignment-{child_run.run_id}",
            goal=goal,
            acceptance_criteria_refs=[],
            dependency_refs=list(child_run.artifact_refs or bundle.artifact_refs),
            bundle_version=bundle.bundle_version,
            final_commit_message=final_commit_message,
        )
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / child_run.run_id / "assignment.json",
            assignment.model_dump(mode="json"),
        )
        self.state.pending_child_goal = None
        if announce_created:
            self._emit_frontend_event(f"Child run created: {child_run.run_id}")
            self._emit_loop_launch(loop_label=child_run.run_id, message=f"Launched {child_run.run_id}")
        self._persist_state()
        return child_run

    def _persist_audit_contract(self, contract: AuditContract) -> list[AuditFinding]:
        root_run = self._require_root_run()
        service = AuditService(self.repo_root)
        findings_dir = self.repo_root / ".ralphception" / "findings"
        existing: dict[str, AuditFinding] = {}
        for path in sorted(findings_dir.glob("*.json")):
            finding = AuditFinding.model_validate_json(path.read_text(encoding="utf-8"))
            existing[finding.finding_id] = finding

        resolved: list[AuditFinding] = []
        current_ids: set[str] = set()
        for finding_contract in contract.findings:
            current_ids.add(finding_contract.finding_id)
            previous = existing.get(finding_contract.finding_id)
            evidence_refs = [
                _artifact_ref_for_file(self.repo_root, Path(path), "audit_evidence")
                for path in finding_contract.evidence_paths
                if (self.repo_root / path).exists()
            ]
            finding = AuditFinding(
                finding_id=finding_contract.finding_id,
                run_id=root_run.run_id,
                severity=finding_contract.severity,
                kind=finding_contract.kind,
                title=finding_contract.title,
                evidence_refs=evidence_refs,
                status=finding_contract.status,
                created_at=previous.created_at if previous is not None else _utc_now(),
                resolved_at=None if finding_contract.status == "open" else _utc_now(),
            )
            resolved.append(service.persist_finding(finding, stage_id="stage-audit"))

        for finding_id, finding in existing.items():
            if finding.status != "open" or finding_id in current_ids:
                if finding_id not in current_ids:
                    resolved.append(finding)
                continue
            resolved.append(
                service.transition_finding_status(
                    finding,
                    new_status="resolved",
                    actor="autonomous",
                    stage_id="stage-audit",
                    supported_by_merge=True,
                ),
            )
        return resolved

    def _run_verification(
        self,
        *,
        run_id: str,
        stage_id: str,
        scope: VerificationScope,
        cwd: Path,
        commands: list[str],
    ) -> tuple[list[ArtifactRef], str, bool]:
        service = VerificationService(self.repo_root)
        verification_id = f"{run_id}-{scope}-{self.state.stage_attempts.get(stage_id.replace('stage-', ''), 1)}"
        bundle = service.create_task_bundle(
            verification_id=verification_id,
            run_id=run_id,
            stage_id=stage_id,
            task_id=f"task-{verification_id}",
            requested_by="headless",
            scope=scope,
            active_bundle_exact_commands=commands,
        )
        started_at = _utc_now()
        command_results = [_run_verification_command(service, verification_id, index, command, cwd, self.config) for index, command in enumerate(bundle.spec.commands, start=1)]
        completed_at = _utc_now()
        persisted = service.persist_result(
            stage_id=stage_id,
            spec=bundle.spec,
            command_results=command_results,
            started_at=started_at,
            completed_at=completed_at,
        )
        stage_kind = stage_id.removeprefix("stage-")
        self._emit_frontend_event(
            f"Verification {persisted.result.status}: {run_id} {stage_kind}",
            kind="verification.completed",
            run_id=run_id,
            stage_kind=stage_kind,
            payload={"status": persisted.result.status},
        )
        return [persisted.result_ref], persisted.result.status, persisted.result.status == "passed"

    def _run_merge_verification(self, *, run_id: str, cwd: Path, commands: list[str]) -> bool:
        _, _, passed = self._run_verification(
            run_id=f"{run_id}-merge",
            stage_id="stage-merge",
            scope="merge",
            cwd=cwd,
            commands=commands,
        )
        return passed

    def _run_turn(
        self,
        *,
        run_id: str,
        goal: str,
        workspace_path: Path,
        stage_kind: Literal["spec", "plan", "execute", "audit"],
        prompt: str,
    ) -> None:
        self.state.stage_attempts[stage_kind] = self.state.stage_attempts.get(stage_kind, 0) + 1
        self.state.current_stage = stage_kind
        self._persist_state()
        task_id = f"task-{stage_kind}-{self.state.stage_attempts[stage_kind]}"
        self._emit_frontend_event(
            f"Turn started: {run_id} {stage_kind} attempt {self.state.stage_attempts[stage_kind]}",
            kind="turn.started",
            run_id=run_id,
            stage_kind=stage_kind,
            payload={"attempt": self.state.stage_attempts[stage_kind]},
        )
        self._append_headless_event(
            run_id=run_id,
            stage_id=f"stage-{stage_kind}",
            event_type="stage.started",
            payload={"stage_kind": stage_kind, "attempt": self.state.stage_attempts[stage_kind]},
        )
        self._ensure_run_session(self._load_run(run_id), workspace_path=workspace_path)
        run_turn = getattr(self.session_manager, "run_turn", None)
        iter_raw_events = getattr(self.session_manager, "iter_raw_events", None)
        stream_raw_events = getattr(self.session_manager, "stream_raw_events", None)
        normalize_event = getattr(self.session_manager, "normalize_event", None)
        if not callable(run_turn) or not callable(normalize_event):
            raise RuntimeError("session manager does not support headless turn execution")
        run_turn(run_id=run_id, input_text=prompt)
        if callable(iter_raw_events):
            raw_events = iter_raw_events(run_id=run_id, until_methods={"turn/completed", "error"})
        elif callable(stream_raw_events):
            raw_events = stream_raw_events(run_id=run_id, until_methods={"turn/completed", "error"})
        else:
            raise RuntimeError("session manager does not support raw event streaming")
        for raw_event in raw_events:
            progress_event = _format_turn_progress_event(raw_event, self._agent_message_chunks)
            if isinstance(progress_event, AssistantFinalEvent):
                continuation_hint = detect_continuation_hint(progress_event.text)
                if continuation_hint == "next_steps":
                    self._pending_watchdog_trigger_reason = continuation_hint
                    self._append_headless_event(
                        run_id=run_id,
                        stage_id=f"stage-{stage_kind}",
                        event_type="stage.custom_next_steps_emitted",
                        payload={
                            "stage_kind": stage_kind,
                            "hint": continuation_hint,
                            "text": progress_event.text,
                        },
                    )
            if progress_event is not None and self._frontend is not None:
                self._frontend.emit_event(progress_event)
            normalized = normalize_event(
                raw_event,
                run_id=run_id,
                stage_id=f"stage-{stage_kind}",
                task_id=task_id,
            )
            if normalized is not None:
                self._persist_event(normalized)
            if raw_event.method == "error":
                raise RuntimeError(f"session error while running {stage_kind}")
        self._agent_message_chunks.clear()
        self._append_headless_event(
            run_id=run_id,
            stage_id=f"stage-{stage_kind}",
            event_type="stage.completed",
            payload={"stage_kind": stage_kind, "attempt": self.state.stage_attempts[stage_kind]},
        )
        self._emit_frontend_event(
            f"Turn completed: {run_id} {stage_kind}",
            kind="turn.completed",
            run_id=run_id,
            stage_kind=stage_kind,
        )

    def _ensure_run_session(self, run: Run, *, workspace_path: Path) -> None:
        root_run = self._require_root_run()
        get_session_ref = getattr(self.session_manager, "get_session_ref", None)
        if run.codex_session_ref is not None and callable(get_session_ref):
            session_ref = get_session_ref(run.run_id)
            if session_ref is not None and Path(session_ref.workspace_path).resolve(strict=False) == workspace_path.resolve(
                strict=False,
            ):
                return
        session_ref = self._start_run_session(
            run_id=run.run_id,
            goal=run.goal,
            parent_run_id=run.parent_run_id,
            workspace_path=workspace_path,
        )
        updated = self._update_run(run, status="running", codex_session_ref=session_ref)
        if updated.run_id == root_run.run_id:
            self.root_run = updated
        self._persist_run(updated)

    def _rebind_repo_root(self, new_root: Path) -> None:
        root_run = self._require_root_run()
        resolved_root = bootstrap_workspace(new_root)
        if resolved_root == self.repo_root:
            return
        self.repo_root = resolved_root
        _ensure_runtime_paths_excluded(self.repo_root)
        self.config = _load_or_create_config(self.repo_root)
        self.event_store = EventStore(self.repo_root)
        self.startup_record = load_startup_record(self.repo_root) or self.startup_record
        self.root_run = self._load_run(root_run.run_id)
        workspace_path = str(self.repo_root)
        if self.session_manager is not None and hasattr(self.session_manager, "workspace_path"):
            self.session_manager.workspace_path = workspace_path

    def _cleanup_completed_runtime_state(self) -> None:
        cleanup_mission_workspace(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            root_run_id=self.root_run.run_id if self.root_run is not None else _ROOT_RUN_ID,
        )
        self.repo_root = self.primary_repo_root
        self.startup_record = None

    def _resolve_target_branch(self) -> str:
        if self.target_branch is None:
            self.target_branch, initialized_baseline = _ensure_worktree_base_commit(self.repo_root)
            if initialized_baseline:
                self._emit_milestone_transcript_line("Initialized baseline commit for empty repository")
        return self.target_branch

    def _start_run_session(
        self,
        *,
        run_id: str,
        goal: str,
        parent_run_id: str | None,
        workspace_path: Path,
    ):
        if self.session_manager is None:
            raise RuntimeError("headless execution requires a session manager")
        start_session = getattr(self.session_manager, "start_session", None)
        get_session_ref = getattr(self.session_manager, "get_session_ref", None)
        if not callable(start_session) or not callable(get_session_ref):
            raise RuntimeError("session manager does not support session startup")
        event = start_session(
            run_id=run_id,
            goal=goal,
            parent_run_id=parent_run_id,
            workspace_path=str(workspace_path),
        )
        if isinstance(event, Event):
            self._persist_event(event)
        session_ref = get_session_ref(run_id)
        if session_ref is None:
            raise RuntimeError(f"session manager did not return a session ref for {run_id}")
        return session_ref

    def _persist_event(self, event: Event) -> None:
        self.event_store.append(
            event_id=event.event_id,
            run_id=event.run_id,
            stage_id=event.stage_id,
            task_id=event.task_id,
            event_type=event.event_type,
            source=event.source,
            payload=event.payload,
            occurred_at=event.occurred_at,
        )

    def _append_headless_event(
        self,
        *,
        run_id: str,
        stage_id: str,
        event_type: str,
        payload: dict[str, object],
    ) -> None:
        self.event_store.append(
            event_id=f"{event_type}-{uuid.uuid4().hex}",
            run_id=run_id,
            stage_id=stage_id,
            task_id=None,
            event_type=event_type,
            source="headless.supervisor",
            payload=payload,
        )

    def _emit_frontend_event(
        self,
        message: str,
        *,
        kind: str | None = None,
        run_id: str | None = None,
        stage_kind: str | None = None,
        payload: dict[str, object] | None = None,
    ) -> None:
        if self._frontend is None:
            return
        self._frontend.emit_event(
            FrontendEvent(
                message=message,
                kind=kind,
                run_id=run_id,
                stage_kind=stage_kind,
                payload=payload,
            )
        )

    def _emit_frontend_contract_event(self, event: FrontendEvent) -> None:
        if self._frontend is None:
            return
        self._frontend.emit_event(event)

    def _emit_current_task_label(self, label: str | None) -> None:
        if label is None or not label.strip():
            return
        self._emit_frontend_contract_event(CurrentTaskLabelEvent(label=label))

    def _emit_current_plan_node_label(self, label: str | None) -> None:
        if label is None or not label.strip():
            return
        self._emit_frontend_contract_event(CurrentPlanNodeLabelEvent(label=label))

    def _emit_current_loop_label(self, label: str | None) -> None:
        if label is None or not label.strip():
            return
        self._emit_frontend_contract_event(CurrentLoopLabelEvent(label=label))

    def _emit_artifact_write(self, *, artifact_kind: str, artifact_path: Path, message: str) -> None:
        self._emit_frontend_contract_event(
            ArtifactWriteEvent(
                artifact_kind=artifact_kind,
                artifact_path=str(artifact_path.relative_to(self.repo_root)),
                message=message,
            )
        )

    def _emit_bootstrap_pipeline_artifact_writes(self) -> list[ArtifactRef]:
        emitted_refs: list[ArtifactRef] = []
        bootstrap_messages = (
            ("execution-plan", "Wrote execution plan"),
            ("loop-plan", "Wrote loop plan"),
            ("todos", "Wrote todos"),
        )
        for artifact_kind, message in bootstrap_messages:
            revision_id = read_authoritative_revision(self.repo_root, artifact_kind)
            if revision_id is None:
                continue
            artifact_path = artifact_revision_path(self.repo_root, artifact_kind, revision_id)
            if not artifact_path.exists():
                continue
            self._emit_artifact_write(
                artifact_kind=artifact_kind,
                artifact_path=artifact_path,
                message=message,
            )
            emitted_refs.append(
                _artifact_ref_for_file(
                    self.repo_root,
                    artifact_path.relative_to(self.repo_root),
                    workflow_artifact_kind_for(artifact_kind),
                )
            )
        return emitted_refs

    def _emit_loop_launch(self, *, loop_label: str, message: str) -> None:
        self._emit_current_loop_label(loop_label)
        self._emit_frontend_contract_event(LoopLaunchEvent(loop_label=loop_label, message=message))

    def _emit_loop_completion(self, *, loop_label: str, message: str) -> None:
        self._emit_current_loop_label(loop_label)
        self._emit_frontend_contract_event(LoopCompletionEvent(loop_label=loop_label, message=message))

    def _emit_milestone_transcript_line(self, message: str) -> None:
        self._emit_frontend_contract_event(MilestoneTranscriptLineEvent(message=message))

    def _announce_stage(self, stage: StageName) -> None:
        if self._last_announced_stage == stage:
            return
        self._last_announced_stage = stage
        self._emit_current_plan_node_label(stage)
        self._emit_frontend_event(
            f"Stage: {stage}",
            kind="stage.started",
            run_id=self.root_run.run_id if self.root_run is not None else None,
            stage_kind=stage,
        )

    def _mark_stage_complete(self, stage: Literal["intake", "spec", "plan", "execute", "merge", "audit"], *, next_stage: StageName) -> None:
        self._ensure_completed_stage(stage)
        self.state.current_stage = next_stage
        self._persist_state()

    def _ensure_completed_stage(self, stage: str) -> None:
        if stage not in self.state.completed_stages:
            self.state.completed_stages.append(stage)

    def _persist_run(self, run: Run) -> None:
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / run.run_id / "run.json",
            run.model_dump(mode="json"),
        )

    def _load_run(self, run_id: str) -> Run:
        path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        return Run.model_validate_json(path.read_text(encoding="utf-8"))

    def _update_run(
        self,
        run: Run,
        *,
        status: str | None = None,
        codex_session_ref=None,
        artifact_refs: list[ArtifactRef] | None = None,
    ) -> Run:
        data = run.model_dump(mode="python")
        data["status"] = run.status if status is None else status
        if codex_session_ref is not None:
            data["codex_session_ref"] = codex_session_ref
        data["artifact_refs"] = list(run.artifact_refs if artifact_refs is None else artifact_refs)
        data["updated_at"] = _utc_now()
        updated = Run(**data)
        self._persist_run(updated)
        return updated

    def _fail_child_run(
        self,
        run: Run,
        *,
        stage_id: str,
        reason: str,
        artifact_refs: list[ArtifactRef] | None = None,
        before_orchestration: bool = False,
    ) -> None:
        self._append_headless_event(
            run_id=run.run_id,
            stage_id=stage_id,
            event_type="stage.failed",
            payload={
                "stage_kind": stage_id.removeprefix("stage-"),
                "reason": reason,
            },
        )
        if before_orchestration:
            data = run.model_dump(mode="python")
            data["status"] = "failed"
            data["stage_ids"] = []
            data["artifact_refs"] = [*run.artifact_refs, *(artifact_refs or [])]
            data["updated_at"] = _utc_now()
            updated_child = Run(**data)
            self._persist_run(updated_child)
        else:
            updated_child = self._update_run(
                run,
                status="failed",
                artifact_refs=[*run.artifact_refs, *(artifact_refs or [])],
            )
        if reason == "verification_failed":
            summary = f"Verification failed: {updated_child.run_id} {stage_id.removeprefix('stage-')}"
        else:
            summary = f"Run failed: {updated_child.run_id} {reason}"
        self._emit_frontend_contract_event(FailureSummaryEvent(summary=summary))
        self.state.current_stage = "execute"
        self.state.terminal_outcome = None
        if updated_child.run_id not in self.state.child_run_ids:
            self.state.child_run_ids.append(updated_child.run_id)
        self._persist_state()

    def _current_child_run(self) -> Run | None:
        run_id = self.state.current_child_run_id
        if run_id is None:
            return None
        path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if not path.exists():
            return None
        return Run.model_validate_json(path.read_text(encoding="utf-8"))

    def _persist_state(self) -> None:
        root_run = self._require_root_run()
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / root_run.run_id / "headless-state.json",
            self.state.model_dump(mode="json"),
        )

    def _has_spec_review_approval(self) -> bool:
        root_run = self._require_root_run()
        approvals_dir = self.repo_root / ".ralphception" / "approvals"
        for path in approvals_dir.glob("*.json"):
            approval = read_approval(self.repo_root, approval_id=path.stem)
            if approval.run_id == root_run.run_id and approval.approval_kind == "spec_review":
                return True
        return False

    def _has_execution_bundle_approval(self, bundle_version: int) -> bool:
        root_run = self._require_root_run()
        approvals_dir = self.repo_root / ".ralphception" / "approvals"
        for path in approvals_dir.glob("*.json"):
            approval = read_approval(self.repo_root, approval_id=path.stem)
            if (
                approval.run_id == root_run.run_id
                and approval.approval_kind == "execution_bundle"
                and approval.bundle_version == bundle_version
            ):
                return True
        return False

    def _latest_bundle(self) -> ExecutionBundle | None:
        root_run = self._require_root_run()
        bundle_dir = self.repo_root / ".ralphception" / "runs" / root_run.run_id / "bundles"
        candidates: list[ExecutionBundle] = []
        for path in sorted(bundle_dir.glob("*.json")):
            candidates.append(read_bundle(self.repo_root, run_id=root_run.run_id, bundle_id=path.stem))
        if not candidates:
            return None
        return max(candidates, key=lambda bundle: bundle.bundle_version)

    def _build_spec_prompt(self, spec_path: Path) -> str:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        contract = {
            "stage": "spec",
            "run_id": root_run.run_id,
            "output_path": str(spec_path.relative_to(self.repo_root)),
            "seed_prompt": startup_record.seed_prompt,
        }
        return _render_prompt(
            repo_root=self.repo_root,
            contract=contract,
            skill_id="spec.write",
            body=(
                f"Use the intake artifact at `{startup_record.intake_artifact.artifact_path}`.\n"
                f"Write a repo-local PRD to `{spec_path.relative_to(self.repo_root)}`.\n"
                "Capture scope, architecture, risks, and acceptance criteria."
            ),
        )

    def _build_plan_prompt(self, plan_path: Path, plan_contract_path: Path) -> str:
        root_run = self._require_root_run()
        startup_record = self._require_startup_record()
        contract = {
            "stage": "plan",
            "run_id": root_run.run_id,
            "plan_path": str(plan_path.relative_to(self.repo_root)),
            "plan_contract_path": str(plan_contract_path.relative_to(self.repo_root)),
            "seed_prompt": startup_record.seed_prompt,
        }
        return _render_prompt(
            repo_root=self.repo_root,
            contract=contract,
            skill_id="plan.write",
            body=(
                f"Read `{_preferred_spec_path(self.repo_root).relative_to(self.repo_root)}`.\n"
                f"Write human-readable plan markdown to `{plan_path.relative_to(self.repo_root)}`.\n"
                f"Also write JSON to `{plan_contract_path.relative_to(self.repo_root)}` with keys "
                "`execution_goal`, `verification_commands`, `todos`, `commit_intents`, "
                "and `execution_policy`.\n"
                f"{build_commit_style_prompt_hint(self.repo_root)}"
            ),
        )

    def _build_execute_prompt(
        self,
        *,
        run_id: str,
        goal: str,
        handoff_path: Path,
        loop_definition: LoopDefinition,
    ) -> str:
        relative_handoff = Path(".ralphception") / "runs" / run_id / "handoff.json"
        contract = {
            "stage": "execute",
            "run_id": run_id,
            "handoff_path": str(relative_handoff),
            "goal": goal,
            "loop_id": loop_definition.loop_id,
            "plan_node_id": loop_definition.plan_node_id,
            "objective": loop_definition.objective,
            "stop_conditions": list(loop_definition.stop_conditions),
            "output_contract": list(loop_definition.output_contract),
            "target_artifacts": list(loop_definition.target_artifacts),
            "merge_strategy": loop_definition.merge_strategy,
        }
        stop_conditions = "\n".join(f"- {item}" for item in loop_definition.stop_conditions) or "- none"
        output_contract = "\n".join(f"- {item}" for item in loop_definition.output_contract) or "- none"
        target_artifacts = ", ".join(loop_definition.target_artifacts) or "none"
        return _render_prompt(
            repo_root=self.repo_root,
            contract=contract,
            skill_id="execute.task",
            body=(
                f"Execute the Ralph loop goal: {goal}\n"
                f"This loop is `{loop_definition.loop_id}` for plan node `{loop_definition.plan_node_id}`.\n"
                f"Objective: {loop_definition.objective}\n"
                "Stop conditions:\n"
                f"{stop_conditions}\n"
                "Output contract:\n"
                f"{output_contract}\n"
                f"Target artifacts: {target_artifacts}\n"
                f"Merge strategy: {loop_definition.merge_strategy}\n"
                "Stay inside the current repository root and the target artifacts for this loop.\n"
                "Start from the target artifacts and nearby repo-local evidence instead of broad repo discovery.\n"
                "Do the loop work directly in this worktree and report only task-relevant progress.\n"
                "Keep progress updates concrete: inspected files, edits, verification, findings, and blockers.\n"
                "If the requested target already looks correct, say so clearly and finish the loop without unnecessary churn.\n"
                "Do not inspect `.ralphception/` except for the provided handoff path.\n"
                "Do not narrate meta-planning about tools, agents, or internal capabilities.\n"
                "Do not discuss internal tool names, planning APIs, or tool-selection strategy.\n"
                "Do not write first-person internal deliberation like `I need to`, `I think`, `I'll`, or `Let's`.\n"
                "Modify the worktree to implement the goal and narrate progress as you work.\n"
                f"Write JSON handoff metadata to `{relative_handoff}` with keys "
                "`summary`, `artifacts`, `touched_paths`, and `merge_readiness`."
            ),
        )

    def _select_reopened_loop_assignment(self, loop_assignments: list[WorkerAssignment]) -> WorkerAssignment:
        current_run_id = self.state.current_child_run_id
        if current_run_id is not None:
            superseded_run_id = _superseded_run_id(current_run_id)
            if superseded_run_id is not None:
                for assignment in loop_assignments:
                    if assignment.run_id == superseded_run_id:
                        return assignment
        return loop_assignments[0]

    def _plan_loop_assignments(self, plan_contract: PlanContract) -> tuple[LoopGraph, list[WorkerAssignment]]:
        root_run = self._require_root_run()
        planner = PlannerActor(repo_root=self.repo_root)
        loop_graph = planner.build_loop_graph(
            task_id=root_run.run_id,
            execution_goal=plan_contract.execution_goal,
            todos=plan_contract.todos,
            execution_policy=plan_contract.execution_policy,
        )
        self.state.loop_graph_id = loop_graph.loop_graph_id
        scheduler = SchedulerActor.from_execution_policy(plan_contract.execution_policy)
        loop_assignments = scheduler.plan_loop_assignments(
            loops=list(loop_graph.loops),
            todos=plan_contract.todos,
            active_workers=[],
        )
        return loop_graph, loop_assignments

    def _build_audit_prompt(self, audit_path: Path) -> str:
        root_run = self._require_root_run()
        audit_context = self._latest_audit_context()
        contract = {
            "stage": "audit",
            "run_id": root_run.run_id,
            "audit_path": str(audit_path.relative_to(self.repo_root)),
            **audit_context,
        }
        raw_primary_targets = audit_context.get("touched_paths") or audit_context.get("artifact_paths") or []
        primary_targets = (
            [target for target in raw_primary_targets if isinstance(target, str) and target.strip()]
            if isinstance(raw_primary_targets, list)
            else []
        )
        primary_targets_text = ", ".join(primary_targets) if primary_targets else "none"
        verification_summary = audit_context.get("verification_summary")
        verification_summary_text = (
            verification_summary if isinstance(verification_summary, str) and verification_summary.strip() else "unknown"
        )
        return _render_prompt(
            repo_root=self.repo_root,
            contract=contract,
            skill_id="audit.review",
            body=(
                "Review the latest merged state and write audit findings JSON.\n"
                "Only inspect the current repository root and `.ralphception/` inside it.\n"
                "Do not read `..`, sibling repos, other worktrees, or unrelated clones.\n"
                "Prefer repo-local evidence from the latest merged diff, `git status --short`, "
                "the files changed by the merged child run, and `.ralphception/runs/` plus "
                "`.ralphception/verification/` in this repository.\n"
                "Treat the provided merged-run context as authoritative unless repo-local evidence "
                "contradicts it.\n"
                "Do not run broad discovery commands when the provided context already answers the "
                "audit question.\n"
                "For a small, single-file change with passed verification, prefer writing "
                "`{ \"findings\": [] }` immediately unless specific repo-local evidence shows a "
                "blocking issue.\n"
                "Do not enumerate `.ralphception` with shell loops or broad globbing commands.\n"
                "Do not narrate meta-planning about tools, agents, or internal capabilities.\n"
                "Do not discuss internal tool names, planning APIs, or tool-selection strategy.\n"
                f"Primary audit target files: {primary_targets_text}\n"
                f"Latest verification summary: {verification_summary_text}\n"
                "Keep the audit compact and focused on regressions, requirement gaps, and "
                "operational risks caused by the latest merged work.\n"
                "If there are no blocking findings, write `{ \"findings\": [] }` and stop.\n"
                f"Write findings to `{audit_path.relative_to(self.repo_root)}` using "
                "the shape `{ \"findings\": [...] }` with evidence paths relative to the "
                "current repository root."
            ),
        )

    def _latest_audit_context(self) -> dict[str, object]:
        child_run_id = self.state.current_child_run_id
        if child_run_id is None:
            return {}
        handoff_path = self.repo_root / ".ralphception" / "runs" / child_run_id / "handoff.json"
        if not handoff_path.exists():
            return {"child_run_id": child_run_id}
        handoff = WorktreeHandoff.model_validate_json(handoff_path.read_text(encoding="utf-8"))
        return {
            "child_run_id": handoff.child_run_id,
            "goal": handoff.goal,
            "touched_paths": list(handoff.touched_paths),
            "artifact_paths": [artifact.artifact_path for artifact in handoff.artifact_refs],
            "verification_summary": handoff.verification_summary,
            "merge_readiness": handoff.merge_readiness,
            "head_commit": handoff.head_commit,
        }

    def _default_execution_goal(self, bundle: ExecutionBundle) -> str:
        startup_record = self._require_startup_record()
        return f"Execute approved bundle v{bundle.bundle_version} for {startup_record.seed_prompt}."

    def _result(
        self,
        *,
        mode: Literal["startup", "review", "dashboard", "completed", "failed"],
        review_target_kind: ReviewTargetKind | None = None,
    ) -> HeadlessRunResult:
        watchdog_trigger_reason = self._pending_watchdog_trigger_reason if mode == "dashboard" else None
        self._pending_watchdog_trigger_reason = None
        return HeadlessRunResult(
            mode=mode,
            actions=tuple(self.actions),
            review_target_kind=review_target_kind,
            root_run_id=self.root_run.run_id if self.root_run is not None else None,
            root_run_status=self.root_run.status if self.root_run is not None else None,
            authoritative_repo_root=str(self.repo_root),
            child_run_ids=tuple(self.state.child_run_ids),
            completed_stages=tuple(stage for stage in _STAGE_SEQUENCE if stage in self.state.completed_stages),
            current_stage=self.state.current_stage,
            audit_reopened=self.state.audit_reopened,
            watchdog_trigger_reason=watchdog_trigger_reason,
        )

    def _commit_child_changes(self, *, worktree_path: Path, run_id: str, touched_paths: list[str]) -> None:
        if touched_paths:
            _run_git(worktree_path, "add", "--", *touched_paths)
        else:
            _run_git(worktree_path, "add", "--all", "--", ".")
        status = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            cwd=worktree_path,
            check=False,
            capture_output=True,
            text=True,
        )
        if status.returncode == 0:
            if touched_paths:
                raise RuntimeError(f"execute stage produced no staged changes for {run_id}")
            return
        author_name, author_email = resolve_git_commit_identity(worktree_path)
        _run_git(
            worktree_path,
            "-c",
            f"user.name={author_name}",
            "-c",
            f"user.email={author_email}",
            "commit",
            "-m",
            f"headless: {run_id}",
        )

    def _require_root_run(self) -> Run:
        if self.root_run is None:
            raise RuntimeError("root run is not initialized")
        return self.root_run

    def _require_startup_record(self) -> StartupRecord:
        if self.startup_record is None:
            raise RuntimeError("startup record is not initialized")
        return self.startup_record


def _default_spec_markdown(*, seed_prompt: str, source_repos: tuple[str, ...]) -> str:
    source_lines = "\n".join(f"- {repo_path}" for repo_path in source_repos) or "- none"
    return (
        "# PRD\n\n"
        f"- Goal: {seed_prompt}\n"
        "- Mode: Start execution directly from the first conversational prompt.\n"
        "- Acceptance: complete the requested work, verify it, and leave a merge-ready handoff.\n\n"
        "## Source Repositories\n\n"
        f"{source_lines}\n"
    )


def _default_plan_markdown(*, execution_goal: str, verification_commands: Sequence[str]) -> str:
    verification_lines = "\n".join(f"- `{command}`" for command in verification_commands) or "- none"
    return (
        "# Execution Plan\n\n"
        f"1. Execute the requested goal directly: {execution_goal}\n"
        "2. Run verification for the changed workspace.\n"
        "3. Merge the result and audit the final state.\n\n"
        "## Verification Commands\n\n"
        f"{verification_lines}\n"
    )


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    return load_repo_config(repo_root)


def _load_plan_contract(path: Path, *, default_goal: str) -> PlanContract:
    if not path.exists():
        return PlanContract(
            execution_goal=default_goal,
            verification_commands=_default_verification_commands(path.parent.parent.parent),
            todos=_default_todos(default_goal),
            commit_intents=_default_commit_intents(path.parent.parent.parent, default_goal),
        )
    raw = json.loads(path.read_text(encoding="utf-8"))
    normalized = _normalize_plan_contract_payload(
        raw,
        default_goal=default_goal,
        repo_root=path.parent.parent.parent,
    )
    return PlanContract.model_validate(normalized)


def _normalize_plan_contract_payload(
    raw: Any,
    *,
    default_goal: str,
    repo_root: Path,
) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raw = {}
    execution_goal = str(raw.get("execution_goal") or default_goal).strip() or default_goal
    todo_specs = _normalize_todo_specs(raw.get("todos"))
    commit_intents = _normalize_commit_intents(
        raw.get("commit_intents"),
        todo_ids=[spec["todo_id"] for spec in todo_specs],
        execution_goal=execution_goal,
        repo_root=repo_root,
    )
    if not commit_intents:
        commit_intents = [
            intent.model_dump(mode="json")
            for intent in _default_commit_intents(repo_root, execution_goal)
        ]

    commit_todo_ids = {
        todo_id
        for intent in commit_intents
        for todo_id in intent["todo_ids"]
    }
    todo_ids = [spec["todo_id"] for spec in todo_specs]
    if todo_ids and not commit_todo_ids:
        commit_intents[0]["todo_ids"] = list(todo_ids)
    else:
        missing_todo_ids = [todo_id for todo_id in todo_ids if todo_id not in commit_todo_ids]
        if missing_todo_ids:
            commit_intents[0]["todo_ids"] = [*commit_intents[0]["todo_ids"], *missing_todo_ids]

    todos = _normalize_todos(
        todo_specs,
        commit_intents=commit_intents,
        execution_goal=execution_goal,
    )
    if not todos:
        todos = [todo.model_dump(mode="json") for todo in _default_todos(execution_goal)]

    verification_commands = _normalize_verification_command_entries(raw.get("verification_commands"))
    if not verification_commands:
        verification_commands = _default_verification_commands(repo_root)

    return {
        "execution_goal": execution_goal,
        "verification_commands": verification_commands,
        "todos": todos,
        "commit_intents": commit_intents,
        "execution_policy": _normalize_execution_policy(raw.get("execution_policy")),
    }


def _normalize_verification_command_entries(raw_commands: Any) -> list[str]:
    if not isinstance(raw_commands, list):
        return []
    normalized: list[str] = []
    for entry in raw_commands:
        if isinstance(entry, str):
            normalized.append(entry)
            continue
        if isinstance(entry, Mapping):
            command = entry.get("command")
            if isinstance(command, str):
                normalized.append(command)
    return normalized


def _normalize_todo_specs(raw_todos: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_todos, list):
        return []
    specs: list[dict[str, Any]] = []
    previous_todo_id: str | None = None
    for index, entry in enumerate(raw_todos, start=1):
        if isinstance(entry, str):
            todo_id = f"todo-{index}"
            title = entry
            dependency_ids: list[str] | None = [previous_todo_id] if previous_todo_id is not None else []
            scope_hints: list[str] = []
            explicit_commit_intent_id = None
            explicit_status = None
        elif isinstance(entry, Mapping):
            entry_map = cast(Mapping[str, Any], entry)
            todo_id = str(entry_map.get("todo_id") or entry_map.get("id") or f"todo-{index}").strip() or f"todo-{index}"
            title = str(entry_map.get("title") or entry_map.get("summary") or todo_id).strip() or todo_id
            explicit_dependencies = _normalize_string_list(entry_map.get("dependency_ids"))
            dependency_ids = explicit_dependencies if explicit_dependencies is not None else (
                [previous_todo_id] if previous_todo_id is not None else []
            )
            scope_hints = (
                _normalize_string_list(entry_map.get("scope_hints"))
                or _normalize_string_list(entry_map.get("files"))
                or _normalize_string_list(entry_map.get("paths"))
                or []
            )
            explicit_commit_intent_id = _normalize_optional_string(entry_map.get("commit_intent_id"))
            explicit_status = _normalize_optional_string(entry_map.get("status"))
        else:
            continue
        status = explicit_status or ("blocked" if dependency_ids else "ready")
        specs.append(
            {
                "todo_id": todo_id,
                "title": title,
                "dependency_ids": dependency_ids,
                "status": status,
                "scope_hints": scope_hints,
                "explicit_commit_intent_id": explicit_commit_intent_id,
            }
        )
        previous_todo_id = todo_id
    return specs


def _normalize_commit_intents(
    raw_commit_intents: Any,
    *,
    todo_ids: list[str],
    execution_goal: str,
    repo_root: Path,
) -> list[dict[str, Any]]:
    if not isinstance(raw_commit_intents, list):
        return []
    normalized: list[dict[str, Any]] = []
    for index, entry in enumerate(raw_commit_intents, start=1):
        if isinstance(entry, Mapping):
            entry_map = cast(Mapping[str, Any], entry)
            intent_id = str(entry_map.get("intent_id") or f"intent-{index}").strip() or f"intent-{index}"
            message = _normalize_optional_string(entry_map.get("message"))
            if message is None:
                scope = _normalize_optional_string(entry_map.get("scope")) or "chore"
                summary = _normalize_optional_string(entry_map.get("summary")) or execution_goal
                message = _format_commit_message(scope, summary)
            message = normalize_commit_message_for_repo(repo_root, message)
            assigned_todo_ids = _normalize_string_list(entry_map.get("todo_ids"))
            if not assigned_todo_ids:
                if len(raw_commit_intents) == len(todo_ids) and index - 1 < len(todo_ids):
                    assigned_todo_ids = [todo_ids[index - 1]]
                elif index == 1:
                    assigned_todo_ids = list(todo_ids)
                else:
                    assigned_todo_ids = []
            if not assigned_todo_ids:
                continue
            ordering_after = _normalize_string_list(entry_map.get("ordering_after"))
            if ordering_after is None:
                ordering_after = [normalized[-1]["intent_id"]] if normalized else []
            normalized.append(
                {
                    "intent_id": intent_id,
                    "message": message,
                    "todo_ids": assigned_todo_ids,
                    "ordering_after": ordering_after,
                }
            )
    return normalized


def _normalize_todos(
    todo_specs: list[dict[str, Any]],
    *,
    commit_intents: list[dict[str, Any]],
    execution_goal: str,
) -> list[dict[str, Any]]:
    if not todo_specs:
        return []
    todo_to_commit_intent: dict[str, str] = {}
    for intent in commit_intents:
        intent_id = intent["intent_id"]
        for todo_id in intent["todo_ids"]:
            todo_to_commit_intent.setdefault(todo_id, intent_id)
    default_commit_intent_id = commit_intents[0]["intent_id"] if commit_intents else "intent-1"
    normalized: list[dict[str, Any]] = []
    for spec in todo_specs:
        normalized.append(
            {
                "todo_id": spec["todo_id"],
                "title": spec["title"] or execution_goal,
                "dependency_ids": spec["dependency_ids"],
                "status": spec["status"],
                "commit_intent_id": (
                    spec["explicit_commit_intent_id"]
                    or todo_to_commit_intent.get(spec["todo_id"])
                    or default_commit_intent_id
                ),
                "scope_hints": spec["scope_hints"],
            }
        )
    return normalized


def _normalize_execution_policy(raw_execution_policy: Any) -> dict[str, Any]:
    if not isinstance(raw_execution_policy, Mapping):
        return ExecutionPolicy().model_dump(mode="json")
    normalized: dict[str, Any] = {}
    if isinstance(raw_execution_policy.get("max_parallel_children"), int):
        normalized["max_parallel_children"] = raw_execution_policy["max_parallel_children"]
    if isinstance(raw_execution_policy.get("batch_by_scope"), bool):
        normalized["batch_by_scope"] = raw_execution_policy["batch_by_scope"]
    if isinstance(raw_execution_policy.get("allow_commit_split"), bool):
        normalized["allow_commit_split"] = raw_execution_policy["allow_commit_split"]
    return ExecutionPolicy(**normalized).model_dump(mode="json")


def _normalize_string_list(value: Any) -> list[str] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        return []
    normalized = [str(item).strip() for item in value if isinstance(item, str) and str(item).strip()]
    return normalized


def _normalize_optional_string(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    stripped = value.strip()
    return stripped or None


def _format_commit_message(scope: str, summary: str) -> str:
    normalized_scope = scope.strip() or "chore"
    normalized_summary = summary.strip() or "update runtime artifacts"
    return f"{normalized_scope}: {normalized_summary}"


def _default_todos(execution_goal: str) -> list[TodoNode]:
    return [
        TodoNode(
            todo_id="todo-1",
            title=execution_goal,
            dependency_ids=[],
            status="ready",
            commit_intent_id="intent-1",
            scope_hints=_default_scope_hints(execution_goal),
        )
    ]


def _default_commit_intents(repo_root: Path, execution_goal: str) -> list[CommitIntent]:
    return [
        CommitIntent(
            intent_id="intent-1",
            message=normalize_commit_message_for_repo(
                repo_root,
                f"feat: {execution_goal.rstrip('.')}",
                fallback_type="feat",
            ),
            todo_ids=["todo-1"],
            ordering_after=[],
        )
    ]


def _default_scope_hints(execution_goal: str) -> list[str]:
    normalized_goal = execution_goal.lower()
    if any(token in normalized_goal for token in ("typo", "spelling", "readme", "docs", "documentation")):
        return ["README.md"]
    return ["src/"]


def _resolve_child_final_commit_message(
    *,
    repo_root: Path,
    goal: str,
    plan_contract: PlanContract | None,
) -> str:
    if plan_contract is not None and plan_contract.commit_intents:
        return normalize_commit_message_for_repo(repo_root, plan_contract.commit_intents[0].message)
    return normalize_commit_message_for_repo(repo_root, f"chore: {goal.rstrip('.')}")


def _summarize_authoritative_update_paths(
    touched_paths: Sequence[str],
    *,
    fallback_paths: Sequence[str],
) -> list[str]:
    visible_paths = [
        path
        for path in touched_paths
        if path.strip() and not path.startswith(".ralphception/")
    ]
    if not visible_paths:
        visible_paths = [
            path
            for path in fallback_paths
            if path.strip() and not path.startswith(".ralphception/")
        ]
    if not visible_paths:
        return ["repo-local changes"]
    unique_paths = list(dict.fromkeys(visible_paths))
    if len(unique_paths) <= 3:
        return unique_paths
    remaining = len(unique_paths) - 3
    return [*unique_paths[:3], f"+{remaining} more"]


def _artifact_ref_for_file(
    repo_root: Path,
    relative_path: Path,
    artifact_kind: str,
    *,
    root: Path | None = None,
) -> ArtifactRef:
    base_root = root or repo_root
    content = (base_root / relative_path).read_bytes()
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=str(relative_path),
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content).hexdigest()}",
    )


def _preferred_artifact_path(directory: Path, *, preferred_name: str) -> Path:
    preferred = directory / preferred_name
    if preferred.exists():
        return preferred
    for path in sorted(directory.glob("*.md")):
        return path
    return preferred


def _preferred_spec_path(repo_root: Path) -> Path:
    return _preferred_artifact_path(
        repo_root / ".ralphception" / "specs",
        preferred_name=_DEFAULT_SPEC_FILENAME,
    )


def _preferred_plan_markdown_path(repo_root: Path) -> Path:
    return _preferred_artifact_path(
        repo_root / ".ralphception" / "plans",
        preferred_name=_DEFAULT_PLAN_MARKDOWN_FILENAME,
    )


def _preferred_plan_contract_path(repo_root: Path) -> Path:
    plans_dir = repo_root / ".ralphception" / "plans"
    preferred = plans_dir / _DEFAULT_PLAN_CONTRACT_FILENAME
    if preferred.exists():
        return preferred
    legacy = plans_dir / _LEGACY_PLAN_CONTRACT_FILENAME
    if legacy.exists():
        return legacy
    return preferred


def _render_prompt(
    *,
    repo_root: Path,
    contract: Mapping[str, object],
    skill_id: StableSkillId,
    body: str,
) -> str:
    bundled_guidance = load_bundled_skill_guidance(repo_root=repo_root, skill_id=skill_id)
    return (
        f"{_CONTRACT_BEGIN}\n"
        f"{json.dumps(contract, indent=2, sort_keys=True)}\n"
        f"{_CONTRACT_END}\n\n"
        f"{bundled_guidance}\n\n"
        f"{BUNDLED_SKILL_DISCLOSURE_RULE}\n\n"
        f"{body}\n"
    )


def _run_verification_command(
    service: VerificationService,
    verification_id: str,
    index: int,
    command: str,
    cwd: Path,
    config: RalphceptionConfig,
):
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            shell=True,
            check=False,
            capture_output=True,
            text=True,
            timeout=config.verification.command_timeout_seconds,
        )
        return service.shape_command_result(
            verification_id=verification_id,
            command_index=index,
            command=command,
            cwd=cwd,
            exit_code=completed.returncode,
            duration_ms=int((time.perf_counter() - started) * 1000),
            stdout=completed.stdout,
            stderr=completed.stderr,
        )
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return service.shape_command_result(
            verification_id=verification_id,
            command_index=index,
            command=command,
            cwd=cwd,
            exit_code=None,
            duration_ms=int((time.perf_counter() - started) * 1000),
            stdout=stdout,
            stderr=stderr,
            timed_out=True,
        )


def _default_verification_commands(repo_root: Path) -> list[str]:
    del repo_root
    return ['python -c "print(\'headless verification\')"']


def _current_branch(repo_root: Path) -> str:
    branch_name = _git_output_optional(repo_root, "branch", "--show-current")
    if branch_name:
        return branch_name
    return _git_output(repo_root, "rev-parse", "--abbrev-ref", "HEAD")


def _ensure_worktree_base_commit(repo_root: Path) -> tuple[str, bool]:
    branch_name = _current_branch(repo_root)
    if _has_head_commit(repo_root):
        return branch_name, False

    _ensure_runtime_paths_excluded(repo_root)
    author_name, author_email = resolve_git_commit_identity(repo_root)
    _run_git(repo_root, "add", "--all", "--", ".")
    _run_git(
        repo_root,
        "-c",
        f"user.name={author_name}",
        "-c",
        f"user.email={author_email}",
        "commit",
        "--allow-empty",
        "-m",
        "chore: initialize Ralphception baseline",
    )
    return _current_branch(repo_root), True


def _has_head_commit(repo_root: Path) -> bool:
    completed = subprocess.run(
        ["git", "rev-parse", "--verify", "HEAD"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    return completed.returncode == 0


def cleanup_mission_workspace(
    *,
    repo_root: Path,
    primary_repo_root: Path,
    root_run_id: str = _ROOT_RUN_ID,
    preserve_durable_artifacts: bool = True,
) -> Path:
    current_root = bootstrap_workspace(repo_root)
    canonical_primary_root = bootstrap_workspace(primary_repo_root)
    worktrees = WorktreeCoordinator(repo_root=canonical_primary_root)
    root_assignment = _load_worktree_assignment(canonical_primary_root, root_run_id)
    if current_root != canonical_primary_root and root_assignment is not None and root_assignment.kind == "integration":
        try:
            worktrees.switch_authoritative_root(run_id=root_run_id, new_root=canonical_primary_root)
        except RuntimeError:
            pass

    assignments = _runtime_worktree_assignments(canonical_primary_root)
    for assignment in assignments:
        if assignment.run_id == root_run_id or assignment.cleanup_state == "cleaned":
            continue
        worktrees.cleanup_worktree(run_id=assignment.run_id, worktree_path=assignment.worktree_path, retain=False)
    if root_assignment is not None and root_assignment.cleanup_state != "cleaned":
        worktrees.cleanup_worktree(run_id=root_run_id, worktree_path=root_assignment.worktree_path, retain=False)

    tracked_runtime_paths = _tracked_runtime_paths(canonical_primary_root)
    clear_workspace_lease(canonical_primary_root)
    runtime_root = canonical_primary_root / ".ralphception"
    if preserve_durable_artifacts:
        _prune_runtime_root_for_completed_task(runtime_root)
    else:
        _clear_runtime_root(runtime_root)
    worktrees_root = canonical_primary_root / ".worktrees"
    if worktrees_root.exists() and not any(worktrees_root.iterdir()):
        worktrees_root.rmdir()
    if tracked_runtime_paths:
        _run_git(
            canonical_primary_root,
            "restore",
            "--source=HEAD",
            "--staged",
            "--worktree",
            "--",
            *tracked_runtime_paths,
        )
    if not preserve_durable_artifacts:
        bootstrap_workspace(canonical_primary_root)
    return canonical_primary_root


_PERSISTED_RUNTIME_ROOT_CHILDREN: tuple[str, ...] = (
    "artifact-pipeline",
    "artifacts",
    "events",
    "plans",
    "runtime",
    "specs",
    "todos",
)


def prune_runtime_root_for_completed_task(repo_root: Path) -> None:
    """Remove volatile runtime state while preserving durable task artifacts."""
    _prune_runtime_root_for_completed_task(bootstrap_workspace(repo_root) / ".ralphception")


def clear_runtime_root_for_new_task(repo_root: Path) -> None:
    """Remove all repo-local Ralphception task state before starting a fresh task."""
    _clear_runtime_root(bootstrap_workspace(repo_root) / ".ralphception")


def _prune_runtime_root_for_completed_task(runtime_root: Path) -> None:
    if not runtime_root.exists():
        return
    for child in runtime_root.iterdir():
        if child.name in _PERSISTED_RUNTIME_ROOT_CHILDREN:
            continue
        _remove_runtime_child(child)


def _clear_runtime_root(runtime_root: Path) -> None:
    if not runtime_root.exists():
        return
    for child in runtime_root.iterdir():
        _remove_runtime_child(child)


def _remove_runtime_child(child: Path) -> None:
    if child.is_dir() and not child.is_symlink():
        shutil.rmtree(child)
        return
    child.unlink()


def _runtime_worktree_assignments(repo_root: Path) -> list[WorktreeAssignment]:
    assignments: list[WorktreeAssignment] = []
    runs_dir = repo_root / ".ralphception" / "runs"
    if not runs_dir.exists():
        return assignments
    for worktree_path in sorted(runs_dir.glob("*/worktree.json")):
        assignment = _load_worktree_assignment(repo_root, worktree_path.parent.name)
        if assignment is not None:
            assignments.append(assignment)
    return assignments


def _load_worktree_assignment(repo_root: Path, run_id: str) -> WorktreeAssignment | None:
    try:
        return read_worktree_assignment(repo_root, run_id)
    except (FileNotFoundError, ValueError, OSError):
        return None


def _tracked_runtime_paths(repo_root: Path) -> list[str]:
    completed = subprocess.run(
        ["git", "ls-files", "-z", "--", ".ralphception", ".worktrees"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return [path for path in completed.stdout.split("\0") if path]


def _ensure_runtime_paths_excluded(repo_root: Path) -> None:
    try:
        exclude_path = Path(_git_output(repo_root, "rev-parse", "--git-path", "info/exclude"))
    except subprocess.CalledProcessError:
        return
    if not exclude_path.is_absolute():
        exclude_path = repo_root / exclude_path
    exclude_path.parent.mkdir(parents=True, exist_ok=True)
    existing = exclude_path.read_text(encoding="utf-8") if exclude_path.exists() else ""
    additions = []
    for pattern in (".ralphception/", ".worktrees/"):
        if pattern not in existing.splitlines():
            additions.append(pattern)
    if additions:
        prefix = "" if existing.endswith("\n") or not existing else "\n"
        exclude_path.write_text(existing + prefix + "\n".join(additions) + "\n", encoding="utf-8")


def _format_turn_progress_event(raw_event, agent_message_chunks: dict[str, list[str]]) -> FrontendEvent | None:
    method = raw_event.method
    payload = raw_event.payload if isinstance(raw_event.payload, Mapping) else {}
    if method == "codex/event/task_started":
        message = _normalized_message_text(_as_text(payload.get("msg")))
        if message:
            return FrontendEvent(message=message, kind="codex.progress")
        return None
    if method.startswith("codex/event/"):
        return None

    if method == "thread/tokenUsage/updated":
        token_usage = payload.get("token_usage")
        if not isinstance(token_usage, Mapping):
            token_usage = payload.get("tokenUsage")
        if not isinstance(token_usage, Mapping):
            return None
        status_line_value = _status_line_value_from_token_usage(token_usage)
        quota_label = _quota_label_from_token_usage(token_usage)
        if status_line_value is None and quota_label is None:
            return None
        details = " · ".join(part for part in (status_line_value, quota_label) if part)
        return LiveStatusEvent(
            text=f"Runtime status updated: {details}" if details else "Runtime status updated",
            status_line_value=status_line_value,
            quota_label=quota_label,
        )

    if method == "turn/plan/updated":
        active_step, steps = _plan_update_steps(payload)
        if active_step is None:
            return None
        return PlanUpdatedEvent(active_step=active_step, steps=steps)

    if method == "item/agentMessage/delta":
        item_id = _as_text(payload.get("item_id"))
        delta = _as_text(payload.get("delta"))
        if item_id is not None and delta:
            chunks = agent_message_chunks.setdefault(item_id, [])
            chunks.append(delta)
            return AssistantDeltaEvent(item_id=item_id, text="".join(chunks))
        return None

    if method == "item/reasoning/summaryPartAdded":
        item_id = _as_text(payload.get("item_id"))
        summary_index = payload.get("summary_index")
        if not isinstance(summary_index, int):
            summary_index = payload.get("summaryIndex")
        if item_id is not None and isinstance(summary_index, int) and summary_index > 0:
            return ReasoningSectionBreakEvent(item_id=item_id, summary_index=summary_index)
        return None

    if method == "item/reasoning/summaryTextDelta":
        item_id = _as_text(payload.get("item_id"))
        delta = _as_text(payload.get("delta"))
        summary_index = payload.get("summary_index")
        if not isinstance(summary_index, int):
            summary_index = payload.get("summaryIndex")
        if item_id is not None and delta:
            return ReasoningSummaryDeltaEvent(
                item_id=item_id,
                text=delta,
                summary_index=summary_index if isinstance(summary_index, int) else None,
            )
        return None

    if method == "item/started":
        item = payload.get("item")
        if not isinstance(item, Mapping):
            return None
        if _as_text(item.get("type")) == "commandExecution":
            command = _compact_single_line(_as_text(item.get("command")))
            item_id = _as_text(item.get("id"))
            if command:
                return CommandBeginEvent(command=command, item_id=item_id)
        return None

    if method == "item/commandExecution/outputDelta":
        item_id = _as_text(payload.get("item_id"))
        delta = _as_text(payload.get("delta"))
        if item_id is not None and delta:
            return CommandOutputDeltaEvent(item_id=item_id, text=delta)
        return None

    if method == "subagent_waiting":
        thread_id = _as_text(payload.get("thread_id")) or _as_text(payload.get("threadId"))
        summary = _as_text(payload.get("summary"))
        if summary:
            process_id = _as_text(payload.get("agent_thread_id")) or _as_text(payload.get("agentThreadId")) or thread_id or "background"
            command = summary.removeprefix("Waiting on ").strip() or summary
            return CurrentWaitingStateEvent(
                label=summary,
                process_id=process_id,
                command=command,
            )
        return None

    if method != "item/completed":
        return None

    item = payload.get("item")
    if not isinstance(item, Mapping):
        return None
    item_type = _as_text(item.get("type"))
    item_id = _as_text(item.get("id"))
    if item_type == "agentMessage":
        text = _normalized_message_text(_as_text(item.get("text")))
        if not text and item_id is not None:
            text = _normalized_message_text("".join(agent_message_chunks.pop(item_id, [])))
        elif item_id is not None:
            agent_message_chunks.pop(item_id, None)
        if text:
            return AssistantFinalEvent(text=text, item_id=item_id)
        return None
    if item_type == "reasoning":
        return ReasoningFinalEvent(
            item_id=item_id,
            text=_completed_reasoning_summary_text(item),
        )
    if item_type == "commandExecution":
        command = _compact_single_line(_as_text(item.get("command")))
        item_id = _as_text(item.get("id"))
        if not command:
            return None
        exit_code = item.get("exit_code")
        if not isinstance(exit_code, int):
            exit_code = item.get("exitCode")
        if isinstance(exit_code, int):
            return CommandEndEvent(
                command=command,
                item_id=item_id,
                exit_code=exit_code,
                status="completed",
            )
        status = _as_text(item.get("status"))
        if status == "completed":
            return CommandEndEvent(command=command, item_id=item_id, status=status)
        if status:
            return CommandEndEvent(command=command, item_id=item_id, status=status)
    return None


def _as_text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _completed_reasoning_summary_text(item: Mapping[str, object]) -> str | None:
    summary = item.get("summary")
    if not isinstance(summary, Sequence):
        return None
    parts: list[str] = []
    for entry in summary:
        if not isinstance(entry, Mapping):
            continue
        entry_map = cast(Mapping[str, object], entry)
        text = _as_text(entry_map.get("text"))
        if text:
            parts.append(text)
    if not parts:
        return None
    return "\n\n".join(parts)


def _plan_update_steps(payload: Mapping[str, object]) -> tuple[str | None, tuple[str, ...]]:
    raw_plan = payload.get("plan")
    if not isinstance(raw_plan, list):
        return None, ()

    steps: list[str] = []
    active_step: str | None = None
    for entry in raw_plan:
        if not isinstance(entry, Mapping):
            continue
        entry_map = cast(Mapping[str, object], entry)
        step_text = _as_text(entry_map.get("step"))
        if not step_text:
            continue
        steps.append(step_text)
        status = _as_text(entry_map.get("status"))
        normalized_status = None if status is None else status.replace("_", "").lower()
        if active_step is None and normalized_status == "inprogress":
            active_step = step_text

    if active_step is None and steps:
        active_step = steps[0]
    return active_step, tuple(steps)


def _compact_single_line(value: str | None) -> str | None:
    if value is None:
        return None
    compacted = " ".join(value.split())
    if not compacted:
        return None
    return _normalize_display_command(compacted)


def _normalized_message_text(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.replace("\r\n", "\n").strip()
    if not normalized:
        return None
    return normalized


def _normalize_display_command(command: str) -> str:
    try:
        parts = shlex.split(command)
    except ValueError:
        return command

    if len(parts) >= 3:
        shell_name = Path(parts[0]).name
        if shell_name in {"sh", "bash", "zsh", "fish"} and parts[1] in {"-c", "-lc", "-ic"}:
            inner_command = " ".join(parts[2:]).strip()
            if inner_command:
                return inner_command
    return command


def _status_line_value_from_token_usage(token_usage: Mapping[str, object]) -> str | None:
    model_context_window = token_usage.get("model_context_window")
    if not isinstance(model_context_window, int):
        model_context_window = token_usage.get("modelContextWindow")
    if not isinstance(model_context_window, int):
        return None
    return f"{_format_tokens_compact(model_context_window)} window"


def _quota_label_from_token_usage(token_usage: Mapping[str, object]) -> str | None:
    total = token_usage.get("total")
    if not isinstance(total, Mapping):
        total_tokens = token_usage.get("total_tokens")
        if not isinstance(total_tokens, int):
            total_tokens = token_usage.get("totalTokens")
        if not isinstance(total_tokens, int):
            return None
        return f"{_format_tokens_compact(total_tokens)} total"
    total_payload = cast(dict[str, object], total)
    total_tokens = total_payload.get("total_tokens")
    if not isinstance(total_tokens, int):
        total_tokens = total_payload.get("totalTokens")
    if not isinstance(total_tokens, int):
        return None
    return f"{_format_tokens_compact(total_tokens)} total"


def _format_tokens_compact(value: int) -> str:
    bounded = max(0, value)
    if bounded < 1_000:
        return str(bounded)

    bounded_f64 = float(bounded)
    if bounded >= 1_000_000_000_000:
        scaled, suffix = bounded_f64 / 1_000_000_000_000.0, "T"
    elif bounded >= 1_000_000_000:
        scaled, suffix = bounded_f64 / 1_000_000_000.0, "B"
    elif bounded >= 1_000_000:
        scaled, suffix = bounded_f64 / 1_000_000.0, "M"
    else:
        scaled, suffix = bounded_f64 / 1_000.0, "K"

    decimals = 2 if scaled < 10.0 else 1 if scaled < 100.0 else 0
    formatted = f"{scaled:.{decimals}f}"
    if "." in formatted:
        formatted = formatted.rstrip("0").rstrip(".")
    return f"{formatted}{suffix}"


def _is_child_handoff_metadata_artifact(path: str) -> bool:
    normalized = path.strip().replace("\\", "/")
    return normalized.startswith(".ralphception/runs/") and normalized.endswith("/handoff.json")


def _run_git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def _git_output(repo_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _git_output_optional(repo_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return ""
    return completed.stdout.strip()


def _utc_now():
    from datetime import datetime, timezone

    return datetime.now(timezone.utc)


def _superseded_run_id(run_id: str) -> str | None:
    marker = "-replacement-"
    if marker not in run_id:
        return None
    return run_id.split(marker, 1)[0]


def _next_replacement_run_id(run_id: str) -> str:
    marker = "-replacement-"
    if marker not in run_id:
        return f"{run_id}{marker}1"
    base, raw_index = run_id.rsplit(marker, 1)
    return f"{base}{marker}{int(raw_index) + 1}"


def _next_child_run_id(run_ids: Sequence[str]) -> str:
    highest_index = 0
    for run_id in run_ids:
        base_run_id = _superseded_run_id(run_id) or run_id
        if not base_run_id.startswith("run-child-"):
            continue
        try:
            highest_index = max(highest_index, int(base_run_id.removeprefix("run-child-")))
        except ValueError:
            continue
    return f"run-child-{highest_index + 1}"
