"""Actor-runtime orchestrator for conversational Ralph-loop startup."""

from __future__ import annotations

from pathlib import Path

from ralphception.actor_runtime.intake_actor import IntakeActor
from ralphception.headless import HeadlessMissionSupervisor, HeadlessRunResult
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.frontends import FrontendEvent, RuntimeFrontend
from ralphception.runtime.supervisor import _emit_pending_prompt, _persist_pending_prompt, _startup_pending_prompt


class ActorOrchestrator:
    """Shared orchestrator fronting the downstream headless executor."""

    def __init__(
        self,
        *,
        repo_root: Path,
        primary_repo_root: Path,
        seed_prompt: str | None,
        source_repos: tuple[str, ...],
        approve_all: bool,
        approver: str,
        session_manager_factory,
    ) -> None:
        self.repo_root = repo_root
        self.primary_repo_root = primary_repo_root
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self.session_manager_factory = session_manager_factory
        self.intake_actor = IntakeActor(repo_root)
        self.actions: list[str] = []

    def run_until_blocked(self, *, frontend: RuntimeFrontend | None = None) -> HeadlessRunResult:
        session = self.intake_actor.load_session()
        if session is None:
            startup_record = load_startup_record(self.repo_root)
            if startup_record is None:
                seeded_answers: tuple[str, ...] = ()
                if self.seed_prompt is not None and self.seed_prompt.strip():
                    seeded_answers = (self.seed_prompt.strip(),)
                prompt = _startup_pending_prompt(
                    self.repo_root,
                    source_repos=self.source_repos,
                    initial_answers=seeded_answers,
                )
                _persist_pending_prompt(
                    self.repo_root,
                    prompt,
                    root_thread_id=prompt.thread_id,
                    active_thread_id=prompt.thread_id,
                    bootstrap_source_repos=self.source_repos,
                )
                if seeded_answers:
                    self.seed_prompt = None
                _emit_pending_prompt(frontend, prompt)
                return HeadlessRunResult(
                    mode="startup",
                    actions=(),
                    authoritative_repo_root=str(self.repo_root),
                )
            if self.seed_prompt is None or not self.seed_prompt.strip():
                self.seed_prompt = startup_record.seed_prompt
                self.source_repos = tuple(startup_record.source_repos)
            session = self.intake_actor.load_session()
            if session is None:
                raise RuntimeError("startup intake must complete before actor execution begins")

        announce_resume = session.phase not in {"intake", "spec_review"}

        downstream = self._build_downstream_supervisor(
            approve_all=self.approve_all,
            announce_resume=announce_resume,
        )
        return self._with_accumulated_actions(downstream.run(frontend=frontend))

    def _build_downstream_supervisor(
        self,
        *,
        approve_all: bool,
        announce_resume: bool = True,
    ) -> HeadlessMissionSupervisor:
        return HeadlessMissionSupervisor(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            seed_prompt=None,
            source_repos=self.source_repos,
            approve_all=approve_all,
            approver=self.approver,
            session_manager_factory=self.session_manager_factory,
            announce_resume=announce_resume,
        )

    def _emit(self, frontend: RuntimeFrontend | None, message: str) -> None:
        if frontend is None:
            return
        frontend.emit_event(FrontendEvent(message=message))

    def _with_accumulated_actions(self, result: HeadlessRunResult) -> HeadlessRunResult:
        if not self.actions:
            return result
        return result.model_copy(update={"actions": (*self.actions, *result.actions)})
