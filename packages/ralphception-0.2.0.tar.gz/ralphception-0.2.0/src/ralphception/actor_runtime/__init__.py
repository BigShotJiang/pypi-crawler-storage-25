"""Actor-runtime entrypoints."""

from __future__ import annotations

from typing import Any

__all__ = [
    "ActorOrchestrator",
    "IntakeActor",
    "MergeAgent",
    "MergeDecision",
    "PlannerActor",
    "SchedulerActor",
    "WorkerCandidate",
    "WorkerActor",
    "WorkerAssignment",
]


def __getattr__(name: str) -> Any:
    if name == "ActorOrchestrator":
        from .orchestrator import ActorOrchestrator

        return ActorOrchestrator
    if name == "IntakeActor":
        from .intake_actor import IntakeActor

        return IntakeActor
    if name in {"MergeAgent", "MergeDecision", "WorkerCandidate"}:
        from .merge_actor import MergeAgent, MergeDecision, WorkerCandidate

        return {
            "MergeAgent": MergeAgent,
            "MergeDecision": MergeDecision,
            "WorkerCandidate": WorkerCandidate,
        }[name]
    if name == "PlannerActor":
        from .planner_actor import PlannerActor

        return PlannerActor
    if name == "SchedulerActor":
        from .scheduler_actor import SchedulerActor

        return SchedulerActor
    if name in {"WorkerActor", "WorkerAssignment"}:
        from .worker_actor import WorkerActor, WorkerAssignment

        return {"WorkerActor": WorkerActor, "WorkerAssignment": WorkerAssignment}[name]
    raise AttributeError(name)
