"""Worker assignment and worktree startup helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator

from ralphception.git.worktrees import WorktreeCoordinator
from ralphception.models.artifacts import DurableModel


class WorkerAssignment(DurableModel):
    worker_id: str
    run_id: str
    goal: str
    todo_ids: list[str] = Field(min_length=1)
    claimed_commit_intent_ids: list[str] = Field(min_length=1)
    loop_id: str | None = None
    plan_node_id: str | None = None
    worktree_path: str | None = None
    status: Literal["planned", "running", "completed", "failed"] = "planned"

    @field_validator("worker_id", "run_id", "goal")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("worker assignment fields must not be blank")
        return value

    @field_validator("todo_ids", "claimed_commit_intent_ids")
    @classmethod
    def _validate_non_blank_items(cls, value: list[str]) -> list[str]:
        if any(not item.strip() for item in value):
            raise ValueError("worker assignment list fields must not contain blank values")
        return value


class WorkerActor:
    """Starts worker assignments in git worktrees."""

    def __init__(self, *, repo_root: Path, base_ref: str, target_branch: str) -> None:
        self.repo_root = repo_root
        self.base_ref = base_ref
        self.target_branch = target_branch
        self.worktrees = WorktreeCoordinator(repo_root=repo_root)

    def start(self, assignment: WorkerAssignment) -> WorkerAssignment:
        created = self.worktrees.create_child_worktree(
            run_id=assignment.run_id,
            base_ref=self.base_ref,
            target_branch=f"{self.target_branch}-{assignment.run_id}",
            goal=assignment.goal,
        )
        return assignment.model_copy(
            update={
                "worktree_path": str(created.worktree_path),
                "status": "running",
            }
        )

    def start_loop(self, assignment: WorkerAssignment) -> WorkerAssignment:
        return self.start(assignment)
