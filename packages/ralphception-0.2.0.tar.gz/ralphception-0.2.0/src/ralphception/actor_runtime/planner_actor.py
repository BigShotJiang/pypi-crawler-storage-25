"""Planner actor for durable plan outputs."""

from __future__ import annotations

from pathlib import Path

from ralphception.models.mission import ExecutionPolicy, PlannerOutput
from ralphception.models.todos import TodoNode
from ralphception.runtime.loop_graph import LoopGraph
from ralphception.runtime.loop_planner import LoopPlanner, PlanGraph, PlanNode, SubplanExpansion
from ralphception.storage.mission_store import MissionStore


class PlannerActor:
    """Persist todo and commit-intent outputs derived from the approved plan contract."""

    def __init__(self, *, repo_root: Path, store: MissionStore | None = None) -> None:
        self.repo_root = repo_root
        self.store = store or MissionStore(repo_root)

    def plan(self, *, approved_spec_path: Path) -> PlannerOutput:
        from ralphception.headless import _load_plan_contract

        if not approved_spec_path.exists():
            fallback_spec_path = _preferred_artifact_path(
                approved_spec_path.parent,
                preferred_name=approved_spec_path.name,
            )
            if not fallback_spec_path.exists():
                raise FileNotFoundError(f"approved spec is missing: {approved_spec_path}")
            approved_spec_path = fallback_spec_path

        plans_dir = self.repo_root / ".ralphception" / "plans"
        plan_markdown_path = _preferred_artifact_path(plans_dir, preferred_name="execution-plan.md")
        plan_json_path = _preferred_plan_json_path(plans_dir)
        contract = _load_plan_contract(
            plan_json_path,
            default_goal=f"Implement {approved_spec_path.stem}.",
        )

        self.store.write_todos(contract.todos)
        self.store.write_commit_intents(contract.commit_intents)
        output = PlannerOutput(
            plan_markdown_path=str(plan_markdown_path.relative_to(self.repo_root)),
            plan_json_path=str(plan_json_path.relative_to(self.repo_root)),
            todo_ids=[todo.todo_id for todo in contract.todos],
            commit_intent_ids=[intent.intent_id for intent in contract.commit_intents],
            execution_policy=contract.execution_policy,
        )
        self.store.write_planner_output(output)
        return output

    def expand_plan_node_into_subplan(self, plan_node_id: str) -> SubplanExpansion:
        plan = PlanGraph(
            task_id="task-root",
            plan_id="plan-root",
            nodes=(
                PlanNode(
                    plan_node_id=plan_node_id,
                    title=plan_node_id.replace("-", " ").title(),
                    objective=f"Expand {plan_node_id} into explicit Ralph loops.",
                    target_artifacts=("prd", "todo"),
                    stop_conditions=(f"{plan_node_id} expansion is complete",),
                    output_contract=(f"publish {plan_node_id} subplan proposals",),
                ),
            ),
            root_plan_node_id=plan_node_id,
        )
        return LoopPlanner().expand_plan_node_into_subplan(plan, plan_node_id)

    def build_plan_graph(
        self,
        *,
        task_id: str,
        execution_goal: str,
        todos: list[TodoNode],
        execution_policy: ExecutionPolicy | None = None,
    ) -> PlanGraph:
        del execution_policy
        if todos:
            nodes = tuple(
                PlanNode(
                    plan_node_id=todo.todo_id,
                    title=todo.title,
                    objective=todo.title,
                    target_artifacts=_target_artifacts_for_todo(todo),
                    stop_conditions=(f"{todo.title} is settled",),
                    output_contract=(f"publish {todo.todo_id} Ralph-loop findings",),
                )
                for todo in todos
            )
            root_plan_node_id = todos[0].todo_id
        else:
            nodes = (
                PlanNode(
                    plan_node_id="todo-root",
                    title=execution_goal,
                    objective=execution_goal,
                    target_artifacts=("code",),
                    stop_conditions=(f"{execution_goal} is complete",),
                    output_contract=("publish root Ralph-loop findings",),
                ),
            )
            root_plan_node_id = "todo-root"

        return PlanGraph(
            task_id=task_id,
            plan_id=f"plan-{task_id}",
            nodes=nodes,
            root_plan_node_id=root_plan_node_id,
        )

    def build_loop_graph(
        self,
        *,
        task_id: str,
        execution_goal: str,
        todos: list[TodoNode],
        execution_policy: ExecutionPolicy | None = None,
    ) -> LoopGraph:
        plan = self.build_plan_graph(
            task_id=task_id,
            execution_goal=execution_goal,
            todos=todos,
            execution_policy=execution_policy,
        )
        loops = LoopPlanner().plan_loops(plan)
        return LoopGraph.from_definitions(loops, loop_graph_id=f"loop-graph-{task_id}")

    def build_loop_graph_from_plan_contract(self, *, approved_spec_path: Path) -> LoopGraph:
        from ralphception.headless import _load_plan_contract

        if not approved_spec_path.exists():
            fallback_spec_path = _preferred_artifact_path(
                approved_spec_path.parent,
                preferred_name=approved_spec_path.name,
            )
            if not fallback_spec_path.exists():
                raise FileNotFoundError(f"approved spec is missing: {approved_spec_path}")
            approved_spec_path = fallback_spec_path

        plans_dir = self.repo_root / ".ralphception" / "plans"
        plan_json_path = _preferred_plan_json_path(plans_dir)
        contract = _load_plan_contract(
            plan_json_path,
            default_goal=f"Implement {approved_spec_path.stem}.",
        )
        return self.build_loop_graph(
            task_id=plan_json_path.stem,
            execution_goal=contract.execution_goal,
            todos=contract.todos,
            execution_policy=contract.execution_policy,
        )

def _target_artifacts_for_todo(todo: TodoNode) -> tuple[str, ...]:
    if todo.scope_hints:
        return tuple(todo.scope_hints)
    joined_scope = " ".join(todo.scope_hints).lower()
    if "docs/" in joined_scope or ".md" in joined_scope:
        return ("prd", "todo")
    if "tests/" in joined_scope:
        return ("todo", "test")
    return ("code",)


def _preferred_artifact_path(directory: Path, *, preferred_name: str) -> Path:
    preferred = directory / preferred_name
    if preferred.exists():
        return preferred
    for path in sorted(directory.glob("*.md")):
        return path
    return preferred


def _preferred_plan_json_path(plans_dir: Path) -> Path:
    preferred = plans_dir / "execution-plan.json"
    if preferred.exists():
        return preferred
    legacy = plans_dir / "mission-plan.json"
    if legacy.exists():
        return legacy
    return preferred
