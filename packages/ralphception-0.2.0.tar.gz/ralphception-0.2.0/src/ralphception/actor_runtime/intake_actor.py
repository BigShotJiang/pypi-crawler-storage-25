"""Mission-start intake helpers for the actor runtime."""

from __future__ import annotations

from pathlib import Path

from ralphception.models.mission import MissionPhase, MissionSession
from ralphception.runtime.bootstrap import (
    StartupBootstrapController,
    bootstrap_from_intake,
    compose_intake_summary,
    load_startup_record,
)
from ralphception.storage.mission_store import MissionStore
from ralphception.workflow.approvals import read_approval

_SPEC_ARTIFACT_PATH = Path(".ralphception/specs/prd.md")
_LEGACY_SPEC_ARTIFACT_PATH = Path(".ralphception/specs/mission-spec.md")


class IntakeActor:
    """Owns the initial mission brief capture and spec-approval phase state."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = repo_root
        self._store = MissionStore(repo_root)
        self._startup = StartupBootstrapController(repo_root)

    def load_session(self) -> MissionSession | None:
        session = self._store.read_session()
        if session is None:
            startup_record = load_startup_record(self.repo_root)
            if startup_record is None:
                return None
            session = MissionSession(
                mission_id=startup_record.outer_run_id,
                repo_root=str(self.repo_root),
                phase=self._phase_from_workspace(),
                approved_spec_version=1 if self._has_spec_approval() else None,
            )
            self._store.write_session(session)
            return session

        desired_phase = self._phase_from_workspace()
        approved_spec_version = 1 if self._has_spec_approval() else None
        if session.phase == desired_phase and session.approved_spec_version == approved_spec_version:
            return session
        updated = session.model_copy(
            update={
                "phase": desired_phase,
                "approved_spec_version": approved_spec_version,
            }
        )
        self._store.write_session(updated)
        return updated

    def apply_answer(self, *, seed_prompt: str, source_repos: tuple[str, ...]) -> MissionSession:
        intake_summary = compose_intake_summary(seed_prompt)
        record = bootstrap_from_intake(
            self.repo_root,
            task_id="task-root",
            intake_summary=intake_summary,
            source_repos=source_repos,
        )
        session = MissionSession(
            mission_id=record.outer_run_id,
            repo_root=str(self.repo_root),
            phase="intake",
            approved_spec_version=None,
        )
        self._store.write_session(session)
        return session

    def mark_ready_for_spec_review(self) -> MissionSession:
        session = self._require_session()
        updated = session.model_copy(
            update={
                "phase": "spec_review",
                "approved_spec_version": None,
            }
        )
        self._store.write_session(updated)
        return updated

    def approve_spec(self, *, artifact_version: int = 1) -> MissionSession:
        session = self._require_session()
        updated = session.model_copy(
            update={
                "phase": "planning",
                "approved_spec_version": artifact_version,
            }
        )
        self._store.write_session(updated)
        return updated

    def _require_session(self) -> MissionSession:
        session = self.load_session()
        if session is None:
            raise RuntimeError("mission session is not initialized")
        return session

    def _phase_from_workspace(self) -> MissionPhase:
        if self._has_spec_approval():
            return "planning"
        if (self.repo_root / _SPEC_ARTIFACT_PATH).exists() or (
            self.repo_root / _LEGACY_SPEC_ARTIFACT_PATH
        ).exists():
            return "spec_review"
        return "intake"

    def _has_spec_approval(self) -> bool:
        approval_path = self.repo_root / ".ralphception" / "approvals" / "approval-spec-1.json"
        if not approval_path.exists():
            return False
        return read_approval(self.repo_root, approval_id="approval-spec-1") is not None
