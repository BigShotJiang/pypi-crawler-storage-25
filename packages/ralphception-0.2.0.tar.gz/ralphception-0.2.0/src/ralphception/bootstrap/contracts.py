"""Bootstrap ledger durable model contracts."""

from __future__ import annotations

import hashlib
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator

from ralphception.models.artifacts import DurableModel
from ralphception.models.runtime import ApprovalKind
from ralphception.models.verification import AuditFindingStatus, FindingKind, FindingSeverity

BootstrapKind = Literal[
    "implementation_gap",
    "verification_gap",
    "ux_gap",
    "doc_gap",
    "scope_gap",
]

BOOTSTRAP_SCHEMA_VERSION = 1
DEFAULT_AUTHORITATIVE_SPEC_PATHS = [
    "docs/superpowers/specs/2026-03-15-ralphception-design.md",
    "docs/superpowers/specs/2026-03-17-ralphception-bootstrap-loop-design.md",
]
DEFAULT_AUTHORITATIVE_PLAN_PATH = "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
DEFAULT_AUTHORITATIVE_README_PATHS = ["README.md"]
DEFAULT_AUTHORITATIVE_CODE_GLOBS = ["src/ralphception/**"]
DEFAULT_AUTHORITATIVE_TEST_GLOBS = ["tests/unit/**", "tests/integration/**", "tests/e2e/**"]

_CHECKBOX_MARKER_PATTERN = re.compile(r"^- \[(?: |x|X)\]\s*")
_STEP_PREFIX_PATTERN = re.compile(r"^Step\s+\d+:\s*", re.IGNORECASE)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _validate_non_blank(value: str, *, field_name: str) -> str:
    if not value.strip():
        raise ValueError(f"{field_name} must not be blank")
    return value


def _validate_non_blank_list(values: list[str], *, field_name: str) -> list[str]:
    if any(not value.strip() for value in values):
        raise ValueError(f"{field_name} must not contain blank values")
    return values


def slugify_heading(heading: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", heading.lower())
    return normalized.strip("-")


def make_plan_item_ref(*, plan_path: Path, heading: str, checkbox_text: str) -> str:
    section_slug = slugify_heading(heading)
    normalized_text = _CHECKBOX_MARKER_PATTERN.sub("", checkbox_text, count=1)
    normalized_text = normalized_text.replace("**", "")
    normalized_text = _STEP_PREFIX_PATTERN.sub("", normalized_text, count=1)
    normalized_text = " ".join(normalized_text.split()).strip()
    digest = hashlib.sha1(normalized_text.encode("utf-8")).hexdigest()
    return f"{plan_path.as_posix()}#{section_slug}/{digest}"


class BootstrapInputs(DurableModel):
    schema_version: Literal[1] = BOOTSTRAP_SCHEMA_VERSION
    updated_at: datetime
    authoritative_spec_paths: list[str] = Field(min_length=1)
    authoritative_plan_path: str
    authoritative_readme_paths: list[str] = Field(min_length=1)
    authoritative_code_globs: list[str] = Field(min_length=1)
    authoritative_test_globs: list[str] = Field(min_length=1)
    latest_iteration_summary_path: str | None = None
    notes: list[str] = Field(default_factory=list)

    @field_validator(
        "authoritative_spec_paths",
        "authoritative_readme_paths",
        "authoritative_code_globs",
        "authoritative_test_globs",
        "notes",
    )
    @classmethod
    def validate_non_blank_lists(cls, values: list[str], info) -> list[str]:
        return _validate_non_blank_list(values, field_name=info.field_name)

    @field_validator("authoritative_plan_path")
    @classmethod
    def validate_authoritative_plan_path(cls, value: str) -> str:
        return _validate_non_blank(value, field_name="authoritative_plan_path")

    @field_validator("latest_iteration_summary_path")
    @classmethod
    def validate_latest_iteration_summary_path(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return _validate_non_blank(value, field_name="latest_iteration_summary_path")

    @classmethod
    def default(cls) -> "BootstrapInputs":
        return cls(
            updated_at=_utc_now(),
            authoritative_spec_paths=list(DEFAULT_AUTHORITATIVE_SPEC_PATHS),
            authoritative_plan_path=DEFAULT_AUTHORITATIVE_PLAN_PATH,
            authoritative_readme_paths=list(DEFAULT_AUTHORITATIVE_README_PATHS),
            authoritative_code_globs=list(DEFAULT_AUTHORITATIVE_CODE_GLOBS),
            authoritative_test_globs=list(DEFAULT_AUTHORITATIVE_TEST_GLOBS),
            latest_iteration_summary_path=None,
            notes=[],
        )


class BootstrapFinding(DurableModel):
    gap_id: str
    title: str
    severity: FindingSeverity
    bootstrap_kind: BootstrapKind
    audit_kind: FindingKind
    status: AuditFindingStatus
    rationale: str | None
    evidence_paths: list[str] = Field(default_factory=list)
    plan_item_refs: list[str] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=_utc_now)

    @field_validator("gap_id", "title")
    @classmethod
    def validate_non_blank_strings(cls, value: str, info) -> str:
        return _validate_non_blank(value, field_name=info.field_name)

    @field_validator("rationale")
    @classmethod
    def validate_optional_rationale(cls, value: str | None) -> str | None:
        if value is None:
            return value
        return _validate_non_blank(value, field_name="rationale")

    @field_validator("evidence_paths", "plan_item_refs")
    @classmethod
    def validate_reference_lists(cls, values: list[str], info) -> list[str]:
        return _validate_non_blank_list(values, field_name=info.field_name)

    @model_validator(mode="after")
    def validate_status_specific_fields(self) -> "BootstrapFinding":
        if not self.plan_item_refs and self.rationale is None:
            raise ValueError("findings without plan_item_refs require rationale")
        if self.status in {"accepted", "wontfix"} and self.rationale is None:
            raise ValueError("accepted and wontfix findings require rationale")
        return self


class BootstrapGapLedger(DurableModel):
    schema_version: Literal[1] = BOOTSTRAP_SCHEMA_VERSION
    updated_at: datetime
    authoritative_plan_path: str
    findings: list[BootstrapFinding] = Field(default_factory=list)

    @field_validator("authoritative_plan_path")
    @classmethod
    def validate_authoritative_plan_path(cls, value: str) -> str:
        return _validate_non_blank(value, field_name="authoritative_plan_path")

    @model_validator(mode="after")
    def validate_unique_finding_ids(self) -> "BootstrapGapLedger":
        if len({finding.gap_id for finding in self.findings}) != len(self.findings):
            raise ValueError("findings must have unique gap_id values")
        return self


class BootstrapApprovalRequest(DurableModel):
    approval_kind: ApprovalKind
    run_id: str
    artifact_paths: list[str]
    bundle_id: str | None
    bundle_version: int | None = Field(default=None, ge=1)
    scope_hash: str | None
    waived_finding_ids: list[str] | None
    rationale: str | None
    requested_at: datetime

    @field_validator("run_id")
    @classmethod
    def validate_run_id(cls, value: str) -> str:
        return _validate_non_blank(value, field_name="run_id")

    @field_validator("bundle_id", "scope_hash", "rationale")
    @classmethod
    def validate_optional_strings(cls, value: str | None, info) -> str | None:
        if value is None:
            return value
        return _validate_non_blank(value, field_name=info.field_name)

    @field_validator("artifact_paths")
    @classmethod
    def validate_artifact_paths(cls, values: list[str]) -> list[str]:
        return _validate_non_blank_list(values, field_name="artifact_paths")

    @field_validator("waived_finding_ids")
    @classmethod
    def validate_waived_finding_ids(cls, values: list[str] | None) -> list[str] | None:
        if values is None:
            return values
        return _validate_non_blank_list(values, field_name="waived_finding_ids")

    @model_validator(mode="after")
    def validate_approval_contract(self) -> "BootstrapApprovalRequest":
        if self.approval_kind == "finding_waiver":
            if not self.waived_finding_ids:
                raise ValueError("finding_waiver requests require waived_finding_ids")
            if self.rationale is None:
                raise ValueError("finding_waiver requests require rationale")
            has_bundle_context = (
                self.bundle_id is not None
                or self.bundle_version is not None
                or self.scope_hash is not None
            )
            if has_bundle_context and (
                self.bundle_id is None or self.bundle_version is None or self.scope_hash is None
            ):
                raise ValueError(
                    "finding_waiver bundle context must include bundle_id, bundle_version, and scope_hash together",
                )
            return self

        if not self.artifact_paths:
            raise ValueError("non-waiver requests require artifact_paths")
        if self.bundle_id is None or self.bundle_version is None or self.scope_hash is None:
            raise ValueError("non-waiver requests require bundle_id, bundle_version, and scope_hash")
        if self.waived_finding_ids is not None or self.rationale is not None:
            raise ValueError("waiver fields must be null unless approval_kind is finding_waiver")
        return self


__all__ = [
    "BOOTSTRAP_SCHEMA_VERSION",
    "BootstrapApprovalRequest",
    "BootstrapFinding",
    "BootstrapGapLedger",
    "BootstrapInputs",
    "BootstrapKind",
    "DEFAULT_AUTHORITATIVE_CODE_GLOBS",
    "DEFAULT_AUTHORITATIVE_PLAN_PATH",
    "DEFAULT_AUTHORITATIVE_README_PATHS",
    "DEFAULT_AUTHORITATIVE_SPEC_PATHS",
    "DEFAULT_AUTHORITATIVE_TEST_GLOBS",
    "make_plan_item_ref",
    "slugify_heading",
]
