"""Bootstrap ledger storage, seeding, and findings sync helpers."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from ralphception.audit.service import AuditService
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.verification import AuditFinding
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import (
    ensure_directory_tree_durable,
    write_json_atomic,
    write_markdown_atomic,
)

from .contracts import BootstrapApprovalRequest, BootstrapFinding, BootstrapGapLedger, BootstrapInputs

_BOOTSTRAP_RUN_ID = "run-root"
_REQUIRED_VERIFICATION_COMMANDS = [
    "uv run pytest tests/unit tests/integration tests/e2e -q",
    "uv run ty check src tests",
]
_FINDING_SEVERITY_ORDER = ("P0", "P1", "P2", "P3")


@dataclass(slots=True)
class BootstrapState:
    repo_root: Path
    boot_dir: Path
    inputs: BootstrapInputs
    gaps: BootstrapGapLedger
    gaps_markdown: str
    finish_criteria_markdown: str
    required_verification_commands: list[str]
    approval_request: BootstrapApprovalRequest | None = None
    approval_request_path: str = field(
        default=".ralphception/bootstrapping/approval-request.json",
    )


def ensure_bootstrap_dirs(repo_root: Path) -> Path:
    """Ensure helper-only bootstrap storage exists without changing runtime defaults."""
    repo_root = bootstrap_workspace(repo_root)
    boot_dir = repo_root / ".ralphception" / "bootstrapping"
    ensure_directory_tree_durable(boot_dir / "iterations")
    return boot_dir


def seed_bootstrap_state(repo_root: Path) -> BootstrapState:
    """Seed the bootstrap ledger on first run and return the current state."""
    repo_root = repo_root.resolve(strict=False)
    boot_dir = ensure_bootstrap_dirs(repo_root)
    inputs_path = boot_dir / "inputs.json"
    gaps_path = boot_dir / "gaps.json"
    gaps_markdown_path = boot_dir / "gaps.md"
    finish_criteria_path = boot_dir / "finish-criteria.md"

    if all(
        path.exists()
        for path in (
            inputs_path,
            gaps_path,
            gaps_markdown_path,
            finish_criteria_path,
        )
    ):
        return _load_bootstrap_state(repo_root, boot_dir)

    seeded_at = _utc_now()
    inputs = BootstrapInputs.default().model_copy(update={"updated_at": seeded_at})
    gaps = BootstrapGapLedger(
        updated_at=seeded_at,
        authoritative_plan_path=inputs.authoritative_plan_path,
        findings=_seed_findings(updated_at=seeded_at),
    )
    gaps_markdown = _render_gaps_markdown(gaps)
    finish_criteria_markdown = _render_finish_criteria(inputs)

    write_json_atomic(inputs_path, inputs.model_dump(mode="json"))
    write_json_atomic(gaps_path, gaps.model_dump(mode="json"))
    write_markdown_atomic(gaps_markdown_path, gaps_markdown)
    write_markdown_atomic(finish_criteria_path, finish_criteria_markdown)

    return _load_bootstrap_state(repo_root, boot_dir)


def sync_gap_ledger_to_findings(repo_root: Path, ledger: BootstrapGapLedger, *, stage_id: str) -> None:
    """Mirror the bootstrap working ledger into the canonical audit findings store."""
    audit = AuditService(repo_root)
    for finding in ledger.findings:
        audit.persist_finding(
            _to_audit_finding(finding, repo_root=repo_root),
            stage_id=stage_id,
            source="bootstrap.storage",
        )


def _load_bootstrap_state(repo_root: Path, boot_dir: Path) -> BootstrapState:
    inputs = BootstrapInputs.model_validate(
        json.loads((boot_dir / "inputs.json").read_text(encoding="utf-8")),
    )
    gaps = BootstrapGapLedger.model_validate(
        json.loads((boot_dir / "gaps.json").read_text(encoding="utf-8")),
    )
    gaps_markdown = (boot_dir / "gaps.md").read_text(encoding="utf-8")
    finish_criteria_markdown = (boot_dir / "finish-criteria.md").read_text(encoding="utf-8")

    return BootstrapState(
        repo_root=repo_root,
        boot_dir=boot_dir,
        inputs=inputs,
        gaps=gaps,
        gaps_markdown=gaps_markdown,
        finish_criteria_markdown=finish_criteria_markdown,
        required_verification_commands=_parse_required_verification_commands(
            finish_criteria_markdown,
        ),
    )


def _seed_findings(*, updated_at: datetime) -> list[BootstrapFinding]:
    return [
        BootstrapFinding(
            gap_id="bootstrap-cli-resume",
            title="CLI resume gap",
            severity="P1",
            bootstrap_kind="ux_gap",
            audit_kind="feature_gap",
            status="open",
            rationale=None,
            evidence_paths=["src/ralphception/cli.py"],
            plan_item_refs=[
                "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
                "#task-1-create-the-python-project-scaffold/"
                "007b80da0ec5a5f6d0faf362d046c17b19189f1f",
            ],
            updated_at=updated_at,
        ),
        BootstrapFinding(
            gap_id="bootstrap-startup-screen",
            title="Startup UX gap",
            severity="P1",
            bootstrap_kind="ux_gap",
            audit_kind="feature_gap",
            status="open",
            rationale=None,
            evidence_paths=["src/ralphception/runtime/bootstrap.py"],
            plan_item_refs=[
                "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
                "#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/"
                "59a3096afd6833963d77087065353060024bb6e7",
            ],
            updated_at=updated_at,
        ),
        BootstrapFinding(
            gap_id="bootstrap-review-screen",
            title="Review UX gap",
            severity="P1",
            bootstrap_kind="ux_gap",
            audit_kind="feature_gap",
            status="open",
            rationale=None,
            evidence_paths=["src/ralphception/runtime/reviews.py"],
            plan_item_refs=[
                "docs/superpowers/plans/2026-03-15-ralphception-core-runtime.md"
                "#task-14-implement-startup-flow-first-run-bootstrap-and-artifact-review-screens/"
                "59a3096afd6833963d77087065353060024bb6e7",
            ],
            updated_at=updated_at,
        ),
        BootstrapFinding(
            gap_id="bootstrap-storage-artifacts-module",
            title="Storage-plan gap",
            severity="P2",
            bootstrap_kind="implementation_gap",
            audit_kind="feature_gap",
            status="open",
            rationale=(
                "The runtime plan names src/ralphception/storage/artifacts.py, but the approved "
                "seed finding has no matching checkbox-backed plan item reference."
            ),
            evidence_paths=["src/ralphception/storage/artifacts.py"],
            plan_item_refs=[],
            updated_at=updated_at,
        ),
    ]


def _render_gaps_markdown(ledger: BootstrapGapLedger) -> str:
    lines = ["# Bootstrap Gap Ledger", ""]
    for severity in _FINDING_SEVERITY_ORDER:
        findings = [finding for finding in ledger.findings if finding.severity == severity]
        if not findings:
            continue
        lines.append(f"## {severity}")
        lines.append("")
        for finding in findings:
            lines.append(f"- `{finding.gap_id}`: {finding.title}")
            lines.append(f"  Status: {finding.status}")
            lines.append(f"  Bootstrap kind: {finding.bootstrap_kind}")
            lines.append(f"  Audit kind: {finding.audit_kind}")
            if finding.plan_item_refs:
                lines.append(f"  Plan refs: {', '.join(finding.plan_item_refs)}")
            if finding.rationale is not None:
                lines.append(f"  Rationale: {finding.rationale}")
            if finding.evidence_paths:
                lines.append(f"  Evidence: {', '.join(finding.evidence_paths)}")
            lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _render_finish_criteria(inputs: BootstrapInputs) -> str:
    lines = [
        "# Bootstrap Finish Criteria",
        "",
        "## Authoritative Specs",
        "",
    ]
    lines.extend(f"- {path}" for path in inputs.authoritative_spec_paths)
    lines.extend(
        [
            "",
            "## Authoritative Plan",
            "",
            f"- {inputs.authoritative_plan_path}",
            "",
            "## Accepted Items",
            "",
            "- None.",
            "",
            "## Wontfix Items",
            "",
            "- None.",
            "",
            "## Required Verification Commands",
            "",
        ],
    )
    lines.extend(f"- {command}" for command in _REQUIRED_VERIFICATION_COMMANDS)
    lines.extend(
        [
            "",
            "## Stop Rule",
            "",
            "Stop when there are no open P0, P1, or P2 gaps, no unchecked in-scope plan items,",
            "every accepted or wontfix item is recorded with rationale, verification passes, and",
            "the README and authoritative planning docs do not overstate the implementation.",
            "",
        ],
    )
    return "\n".join(lines)


def _parse_required_verification_commands(finish_criteria_markdown: str) -> list[str]:
    commands: list[str] = []
    in_section = False

    for line in finish_criteria_markdown.splitlines():
        if line == "## Required Verification Commands":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if in_section and line.startswith("- "):
            commands.append(line[2:].strip())

    return commands


def _to_audit_finding(finding: BootstrapFinding, *, repo_root: Path) -> AuditFinding:
    resolved_at = None if finding.status == "open" else finding.updated_at
    return AuditFinding(
        finding_id=finding.gap_id,
        run_id=_BOOTSTRAP_RUN_ID,
        severity=finding.severity,
        kind=finding.audit_kind,
        title=finding.title,
        evidence_refs=[
            ArtifactRef(
                artifact_kind="bootstrap_evidence",
                artifact_path=path,
                artifact_version=1,
                content_hash=_content_hash_for_path(repo_root, path),
            )
            for path in finding.evidence_paths
        ],
        status=finding.status,
        created_at=finding.updated_at,
        resolved_at=resolved_at,
    )


def _content_hash_for_path(repo_root: Path, path: str) -> str:
    evidence_path = Path(path)
    if not evidence_path.is_absolute():
        evidence_path = repo_root / evidence_path

    if evidence_path.is_file():
        digest = hashlib.sha256(evidence_path.read_bytes()).hexdigest()
        return f"sha256:{digest}"

    digest = hashlib.sha256(f"missing:{Path(path).as_posix()}".encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


__all__ = [
    "BootstrapState",
    "ensure_bootstrap_dirs",
    "seed_bootstrap_state",
    "sync_gap_ledger_to_findings",
]
