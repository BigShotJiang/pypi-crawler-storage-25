"""One-iteration bootstrap runner preparation helpers."""

from __future__ import annotations

import argparse
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from ralphception.config import CodexConfig, RalphceptionConfig, load_or_create_config as load_repo_config
from ralphception.storage.files import write_json_atomic, write_text_atomic

from .contracts import BootstrapFinding, BootstrapInputs, make_plan_item_ref
from .prompting import render_iteration_prompt
from .script import install_local_bootstrap_script
from .storage import seed_bootstrap_state, sync_gap_ledger_to_findings

_BOOTSTRAP_STAGE_ID = "stage-bootstrap"
_EXIT_DONE = 0
_EXIT_CONTINUE = 10
_EXIT_AWAITING_REVIEW = 11
_BLOCKING_SEVERITIES = frozenset({"P0", "P1", "P2"})
_CHECKBOX_PATTERN = re.compile(r"^- \[(?P<mark>[ xX])\]\s*(?P<text>.*)$")
_HEADING_PATTERN = re.compile(r"^(?P<level>#{1,6})\s+(?P<text>.+)$")
_DEFAULT_EXCLUDED_PLAN_HEADINGS = frozenset({"Follow-On Delivery Backlog"})


@dataclass(slots=True)
class PreparedBootstrapIteration:
    repo_root: Path
    boot_dir: Path
    inputs: BootstrapInputs
    should_run_codex: bool
    reason: str
    command: list[str]

    def record_iteration_summary(
        self,
        changes_summary: str,
        *,
        verification_lines: list[str],
    ) -> Path:
        if not self.should_run_codex:
            raise RuntimeError("cannot record an iteration summary when Codex is not ready to run")

        summary_path = _next_iteration_summary_path(self.boot_dir)
        previous_summary_path = self.inputs.latest_iteration_summary_path
        relative_summary_path = summary_path.relative_to(self.repo_root).as_posix()
        timestamp = _utc_now()
        summary_markdown = _render_iteration_summary(
            timestamp=timestamp,
            inputs=self.inputs,
            changes_summary=changes_summary,
            verification_lines=verification_lines,
            previous_summary_path=previous_summary_path,
            current_summary_path=relative_summary_path,
        )
        write_text_atomic(summary_path, summary_markdown)

        updated_inputs = self.inputs.model_copy(
            update={
                "latest_iteration_summary_path": relative_summary_path,
                "updated_at": timestamp,
            },
        )
        write_json_atomic(self.boot_dir / "inputs.json", updated_inputs.model_dump(mode="json"))
        self.inputs = updated_inputs
        _sync_bootstrap_findings(self.repo_root)
        return summary_path


def prepare_bootstrap_iteration(repo_root: Path) -> PreparedBootstrapIteration:
    """Prepare one bootstrap loop iteration without executing Codex."""
    repo_root = repo_root.resolve(strict=False)
    state = seed_bootstrap_state(repo_root)
    sync_gap_ledger_to_findings(repo_root, state.gaps, stage_id=_BOOTSTRAP_STAGE_ID)
    config = _load_or_create_config(repo_root)
    prompt = render_iteration_prompt(repo_root, state)
    write_text_atomic(state.boot_dir / "prompt.txt", prompt)

    approval_request_path = repo_root / state.approval_request_path
    if approval_request_path.is_file():
        return PreparedBootstrapIteration(
            repo_root=repo_root,
            boot_dir=state.boot_dir,
            inputs=state.inputs,
            should_run_codex=False,
            reason="awaiting_review",
            command=[],
        )

    if _bootstrap_done(repo_root, state.inputs):
        return PreparedBootstrapIteration(
            repo_root=repo_root,
            boot_dir=state.boot_dir,
            inputs=state.inputs,
            should_run_codex=False,
            reason="done",
            command=[],
        )

    return PreparedBootstrapIteration(
        repo_root=repo_root,
        boot_dir=state.boot_dir,
        inputs=state.inputs,
        should_run_codex=True,
        reason="ready",
        command=build_codex_exec_command(repo_root, codex_config=config.codex),
    )


def build_codex_exec_command(repo_root: Path, *, codex_config: CodexConfig) -> list[str]:
    """Build the deterministic `codex exec` command for one bootstrap iteration."""
    repo_root = repo_root.resolve(strict=False)
    return [
        "codex",
        "exec",
        "--cd",
        str(repo_root),
        "--dangerously-bypass-approvals-and-sandbox",
        "--model",
        codex_config.model,
        "-c",
        f'model_reasoning_effort="{codex_config.reasoning}"',
        "-c",
        'model_verbosity="low"',
        "-",
    ]


def install_or_run(
    repo_root: Path,
    *,
    run_command: Callable[..., subprocess.CompletedProcess[str] | object] = subprocess.run,
) -> int:
    """Install the helper script, prepare the prompt, and launch Codex when ready."""
    repo_root = repo_root.resolve(strict=False)
    install_local_bootstrap_script(repo_root)
    prepared = prepare_bootstrap_iteration(repo_root)
    if not prepared.should_run_codex:
        print(f"Bootstrap iteration is {prepared.reason}; resolve review and rerun ralph.sh.")
        return 0

    prompt = (prepared.boot_dir / "prompt.txt").read_text(encoding="utf-8")
    completed = run_command(
        prepared.command,
        cwd=prepared.repo_root,
        input=prompt,
        text=True,
        check=False,
    )
    return int(getattr(completed, "returncode", 0))


def run_loop_once(
    repo_root: Path,
    *,
    run_command: Callable[..., subprocess.CompletedProcess[str] | object] = subprocess.run,
) -> int:
    """Run a single bootstrap iteration and return a loop-control exit code."""
    prepared = prepare_bootstrap_iteration(repo_root)
    if prepared.reason == "awaiting_review":
        print("Bootstrap iteration is awaiting review.")
        return _EXIT_AWAITING_REVIEW
    if prepared.reason == "done":
        print("Bootstrap loop is done.")
        return _EXIT_DONE

    prompt = (prepared.boot_dir / "prompt.txt").read_text(encoding="utf-8")
    completed = run_command(
        prepared.command,
        cwd=prepared.repo_root,
        input=prompt,
        text=True,
        check=False,
    )
    return_code = int(getattr(completed, "returncode", 0))
    if return_code != 0:
        return return_code

    refreshed = prepare_bootstrap_iteration(repo_root)
    if refreshed.reason == "awaiting_review":
        print("Bootstrap iteration is awaiting review.")
        return _EXIT_AWAITING_REVIEW
    if refreshed.reason == "done":
        print("Bootstrap loop is done.")
        return _EXIT_DONE

    return _EXIT_CONTINUE


def main(argv: list[str] | None = None) -> int:
    """CLI entry point for the local bootstrap helper."""
    parser = argparse.ArgumentParser(description="Prepare and run one Ralphception bootstrap iteration.")
    parser.add_argument(
        "--install-or-run",
        action="store_true",
        help="Install the local helper, prepare one iteration, and run Codex when ready.",
    )
    parser.add_argument(
        "--loop-once",
        action="store_true",
        help="Run one bootstrap iteration and return a loop-control exit code.",
    )
    parser.add_argument(
        "--repo-root",
        default=".",
        help="Repository root to operate in. Defaults to the current working directory.",
    )
    options, _extras = parser.parse_known_args(argv)

    if options.loop_once:
        return run_loop_once(Path(options.repo_root))
    if options.install_or_run:
        return install_or_run(Path(options.repo_root))

    if not options.install_or_run:
        parser.print_help()
        return 2

    return install_or_run(Path(options.repo_root))


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    return load_repo_config(repo_root)


def _next_iteration_summary_path(boot_dir: Path) -> Path:
    timestamp = _utc_now().strftime("%Y-%m-%dT%H-%M-%SZ")
    candidate = boot_dir / "iterations" / f"{timestamp}.md"
    suffix = 1
    while candidate.exists():
        candidate = boot_dir / "iterations" / f"{timestamp}-{suffix}.md"
        suffix += 1
    return candidate


def _render_iteration_summary(
    *,
    timestamp: datetime,
    inputs: BootstrapInputs,
    changes_summary: str,
    verification_lines: list[str],
    previous_summary_path: str | None,
    current_summary_path: str,
) -> str:
    lines = [
        "# Bootstrap Iteration Summary",
        "",
        f"- Iteration timestamp: {timestamp.isoformat().replace('+00:00', 'Z')}",
        "",
        "## Authoritative Inputs",
        "",
        f"- Plan: {inputs.authoritative_plan_path}",
    ]
    lines.extend(f"- Spec: {path}" for path in inputs.authoritative_spec_paths)
    lines.extend(f"- README: {path}" for path in inputs.authoritative_readme_paths)
    lines.extend(
        [
            "",
            "## Changes Made",
            "",
            changes_summary,
            "",
            "## Verification",
            "",
        ],
    )
    if verification_lines:
        lines.extend(f"- {line}" for line in verification_lines)
    else:
        lines.append("- Not recorded.")
    lines.extend(
        [
            "",
            "## Gap Changes",
            "",
            "- None recorded by the runner.",
            "",
            "## Latest Summary Pointer",
            "",
            f"- Previous: {previous_summary_path or '(none)'}",
            f"- Current: {current_summary_path}",
            "",
            "## Next Recommended Slice",
            "",
            "- Continue from the current bootstrap gap ledger.",
            "",
        ],
    )
    return "\n".join(lines)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _sync_bootstrap_findings(repo_root: Path) -> None:
    state = seed_bootstrap_state(repo_root)
    sync_gap_ledger_to_findings(repo_root, state.gaps, stage_id=_BOOTSTRAP_STAGE_ID)


def _bootstrap_done(repo_root: Path, inputs: BootstrapInputs) -> bool:
    state = seed_bootstrap_state(repo_root)
    return not _has_blocking_findings(state.gaps.findings) and not _has_open_plan_items(
        repo_root,
        inputs,
        state.gaps.findings,
    )


def _has_blocking_findings(findings: list[BootstrapFinding]) -> bool:
    return any(
        finding.status == "open"
        and finding.severity in _BLOCKING_SEVERITIES
        for finding in findings
    )


def _has_open_plan_items(
    repo_root: Path,
    inputs: BootstrapInputs,
    findings: list[BootstrapFinding],
) -> bool:
    plan_path = repo_root / inputs.authoritative_plan_path
    try:
        plan_lines = plan_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return True

    excluded_headings = _excluded_plan_headings(inputs.notes)
    exempt_refs = {
        plan_item_ref
        for finding in findings
        if finding.status in {"accepted", "wontfix"}
        for plan_item_ref in finding.plan_item_refs
    }
    current_heading_line = "# Root"
    excluded_heading_level: int | None = None

    for raw_line in plan_lines:
        heading_match = _HEADING_PATTERN.match(raw_line.strip())
        if heading_match is not None:
            heading_level = len(heading_match.group("level"))
            if excluded_heading_level is not None and heading_level <= excluded_heading_level:
                excluded_heading_level = None
            current_heading_line = raw_line.strip()
            if heading_match.group("text").strip() in excluded_headings:
                excluded_heading_level = heading_level
            continue

        checkbox_match = _CHECKBOX_PATTERN.match(raw_line.strip())
        if checkbox_match is None or excluded_heading_level is not None:
            continue
        if checkbox_match.group("mark").lower() == "x":
            continue

        plan_item_ref = make_plan_item_ref(
            plan_path=Path(inputs.authoritative_plan_path),
            heading=current_heading_line,
            checkbox_text=raw_line.strip(),
        )
        if plan_item_ref in exempt_refs:
            continue
        return True

    return False


def _excluded_plan_headings(notes: list[str]) -> set[str]:
    headings = set(_DEFAULT_EXCLUDED_PLAN_HEADINGS)
    for note in notes:
        for prefix in ("exclude_heading:", "exclude_heading="):
            if note.startswith(prefix):
                heading = note[len(prefix) :].strip()
                if heading:
                    headings.add(heading)
    return headings


__all__ = [
    "PreparedBootstrapIteration",
    "build_codex_exec_command",
    "install_or_run",
    "main",
    "prepare_bootstrap_iteration",
    "run_loop_once",
]


if __name__ == "__main__":
    raise SystemExit(main())
