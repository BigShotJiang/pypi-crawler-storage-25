"""Bootstrap loop prompt rendering helpers."""

from __future__ import annotations

from importlib import resources
from pathlib import Path

from .storage import BootstrapState

_PROMPT_RESOURCE_NAME = "bootstrap.loop.md"


def render_iteration_prompt(repo_root: Path, state: BootstrapState) -> str:
    """Render the bootstrap loop prompt from durable state and package resources."""
    repo_root = repo_root.resolve(strict=False)
    template = resources.files("ralphception.bundled_skills").joinpath(_PROMPT_RESOURCE_NAME).read_text(
        encoding="utf-8",
    )
    latest_summary_path = state.inputs.latest_iteration_summary_path or "(none yet)"
    approval_request_path, approval_request_text, approval_request_instruction = (
        _resolve_approval_request_state(repo_root, state)
    )

    return template.format(
        repo_root=repo_root.as_posix(),
        spec_paths=_render_bullets(state.inputs.authoritative_spec_paths),
        spec_inputs=_render_file_sections(repo_root, state.inputs.authoritative_spec_paths),
        plan_path=state.inputs.authoritative_plan_path,
        plan_input=_render_file_sections(repo_root, [state.inputs.authoritative_plan_path]),
        readme_paths=_render_bullets(state.inputs.authoritative_readme_paths),
        readme_inputs=_render_file_sections(repo_root, state.inputs.authoritative_readme_paths),
        code_globs=_render_bullets(state.inputs.authoritative_code_globs),
        test_globs=_render_bullets(state.inputs.authoritative_test_globs),
        latest_summary_path=latest_summary_path,
        latest_summary_text=_read_repo_text(repo_root, latest_summary_path)
        if state.inputs.latest_iteration_summary_path
        else "(none yet)",
        gaps_json_path=".ralphception/bootstrapping/gaps.json",
        gaps_json_text=state.gaps.model_dump_json(indent=2),
        gaps_md_path=".ralphception/bootstrapping/gaps.md",
        gaps_md_text=_normalize_block_text(state.gaps_markdown),
        finish_criteria_path=".ralphception/bootstrapping/finish-criteria.md",
        finish_criteria_text=_normalize_block_text(state.finish_criteria_markdown),
        verification_commands=_render_bullets(state.required_verification_commands),
        approval_request_path=approval_request_path,
        approval_request_text=approval_request_text,
        approval_request_instruction=approval_request_instruction,
    )


def _render_bullets(values: list[str]) -> str:
    return "\n".join(f"- {value}" for value in values)


def _render_file_sections(repo_root: Path, relative_paths: list[str]) -> str:
    sections: list[str] = []
    for relative_path in relative_paths:
        sections.extend(
            [
                f"#### `{relative_path}`",
                "",
                "````markdown",
                _read_repo_text(repo_root, relative_path),
                "````",
                "",
            ],
        )
    return "\n".join(sections).rstrip()


def _resolve_approval_request_state(repo_root: Path, state: BootstrapState) -> tuple[str, str, str]:
    if state.approval_request is not None:
        return (
            state.approval_request_path,
            state.approval_request.model_dump_json(indent=2),
            "Pending approval request detected. Stop for human review before making changes.",
        )

    approval_request_path = repo_root / state.approval_request_path
    if approval_request_path.is_file():
        return (
            state.approval_request_path,
            _read_repo_text(repo_root, state.approval_request_path),
            "Pending approval request detected. Stop for human review before making changes.",
        )

    return "(none)", "(none)", "No pending approval request."


def _read_repo_text(repo_root: Path, relative_path: str) -> str:
    candidate = Path(relative_path)
    if not candidate.is_absolute():
        candidate = repo_root / candidate

    try:
        contents = candidate.read_text(encoding="utf-8")
    except FileNotFoundError:
        return f"(missing: {relative_path})"
    except OSError as error:
        return f"(unreadable: {relative_path}: {error})"

    return _normalize_block_text(contents)


def _normalize_block_text(contents: str) -> str:
    normalized = contents.rstrip()
    return normalized if normalized else "(empty file)"


__all__ = ["render_iteration_prompt"]
