"""Markdown-to-ANSI line rendering for the Codex TUI port."""

from __future__ import annotations

from pathlib import Path
import re
import textwrap

from .styled_text import Style, StyledLine, StyledSpan, join_spans, render_styled_line, visible_width


_HEADING_RE = re.compile(r"^\s{0,3}(#{1,6})\s+")
_BULLET_RE = re.compile(r"^\s*[-*+]\s+")
_ORDERED_RE = re.compile(r"^\s*(\d+)\.\s+")
_BLOCKQUOTE_RE = re.compile(r"^\s*>\s?")
_FENCE_RE = re.compile(r"^\s*```")
_INLINE_TOKEN_RE = re.compile(
    r"\[(?P<link_label>[^\]]+)\]\((?P<link_dest>[^)]+)\)"
    r"|`(?P<code>[^`]+)`"
    r"|\*\*(?P<strong>.+?)\*\*"
    r"|\*(?P<em>[^*]+)\*"
)


def render_markdown_lines(text: str, *, width: int) -> list[str]:
    rendered: list[str] = []
    in_fenced_code = False
    for raw_line in text.splitlines():
        source = raw_line.rstrip()
        if _FENCE_RE.match(source):
            in_fenced_code = not in_fenced_code
            continue
        if in_fenced_code:
            rendered.extend(_render_code_block_line(source, width=width))
            continue
        if not source:
            rendered.append("")
            continue
        heading_match = _HEADING_RE.match(source)
        if heading_match is not None:
            level = len(heading_match.group(1))
            body = source[heading_match.end() :]
            rendered.extend(
                _render_inline_wrapped(
                    body,
                    width=width,
                    base_style=_heading_style(level),
                    initial_prefix=(StyledSpan(f"{'#' * level} ", _heading_style(level)),),
                    subsequent_prefix=(StyledSpan(" " * (level + 1), _heading_style(level)),),
                )
            )
            continue
        if _BULLET_RE.match(source):
            body = _BULLET_RE.sub("", source)
            rendered.extend(
                _render_inline_wrapped(
                    body,
                    width=width,
                    initial_prefix=(StyledSpan("• "),),
                    subsequent_prefix=(StyledSpan("  "),),
                )
            )
            continue
        ordered_match = _ORDERED_RE.match(source)
        if ordered_match is not None:
            body = source[ordered_match.end() :]
            marker = ordered_match.group(1) + ". "
            rendered.extend(
                _render_inline_wrapped(
                    body,
                    width=width,
                    initial_prefix=(StyledSpan(marker, Style(fg="light_blue")),),
                    subsequent_prefix=(StyledSpan(" " * len(marker)),),
                )
            )
            continue
        if _BLOCKQUOTE_RE.match(source):
            body = _BLOCKQUOTE_RE.sub("", source)
            rendered.extend(
                _render_inline_wrapped(
                    body,
                    width=width,
                    base_style=Style(fg="green"),
                    initial_prefix=(StyledSpan("> ", Style(fg="green")),),
                    subsequent_prefix=(StyledSpan("> ", Style(fg="green")),),
                )
            )
            continue
        rendered.extend(_render_inline_wrapped(source, width=width))
    return rendered


def render_notice_lines(text: str, *, width: int) -> list[str]:
    indent = "  "
    rendered: list[str] = []
    for line in render_markdown_lines(text, width=max(1, width - len(indent))):
        if line:
            rendered.append(f"{indent}{line}")
        else:
            rendered.append("")
    return rendered


def _render_inline_wrapped(
    text: str,
    *,
    width: int,
    base_style: Style | None = None,
    initial_prefix: tuple[StyledSpan, ...] = (),
    subsequent_prefix: tuple[StyledSpan, ...] = (),
) -> list[str]:
    spans = _tokenize_inline_markup(text, base_style=base_style or Style())
    return _wrap_styled_spans(
        spans,
        width=width,
        initial_prefix=initial_prefix,
        subsequent_prefix=subsequent_prefix,
    )


def _tokenize_inline_markup(text: str, *, base_style: Style) -> list[StyledSpan]:
    spans: list[StyledSpan] = []
    cursor = 0
    for match in _INLINE_TOKEN_RE.finditer(text):
        start, end = match.span()
        if start > cursor:
            spans.append(StyledSpan(text[cursor:start], base_style))
        if match.group("link_label") is not None:
            link_dest = match.group("link_dest")
            if _is_local_path_like_link(link_dest):
                spans.append(
                    StyledSpan(
                        _display_link_target(link_dest),
                        _merge_styles(base_style, Style(fg="cyan")),
                    )
                )
            else:
                spans.append(
                    StyledSpan(
                        match.group("link_label"),
                        _merge_styles(base_style, Style(fg="cyan", underline=True)),
                    )
                )
                spans.append(StyledSpan(" (", base_style))
                spans.append(
                    StyledSpan(
                        link_dest,
                        _merge_styles(base_style, Style(fg="cyan", underline=True)),
                    )
                )
                spans.append(StyledSpan(")", base_style))
        elif match.group("code") is not None:
            spans.append(
                StyledSpan(
                    match.group("code"),
                    _merge_styles(base_style, Style(fg="cyan")),
                )
            )
        elif match.group("strong") is not None:
            spans.append(
                StyledSpan(
                    match.group("strong"),
                    _merge_styles(base_style, Style(bold=True)),
                )
            )
        elif match.group("em") is not None:
            spans.append(
                StyledSpan(
                    match.group("em"),
                    _merge_styles(base_style, Style(italic=True)),
                )
            )
        cursor = end
    if cursor < len(text):
        spans.append(StyledSpan(text[cursor:], base_style))
    return _coalesce_spans(spans) if spans else [StyledSpan("", base_style)]


def _wrap_styled_spans(
    spans: list[StyledSpan],
    *,
    width: int,
    initial_prefix: tuple[StyledSpan, ...] = (),
    subsequent_prefix: tuple[StyledSpan, ...] = (),
) -> list[str]:
    prefix_width = visible_width(StyledLine(initial_prefix)) if initial_prefix else 0
    content_width = max(1, width - prefix_width)
    plain_text = "".join(span.text for span in spans)
    wrapped_parts = textwrap.wrap(
        plain_text,
        width=content_width,
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    char_buffer = [(char, span.style) for span in spans for char in span.text]
    cursor = 0
    rendered: list[str] = []
    for index, part in enumerate(wrapped_parts):
        if part and not part[0].isspace():
            while cursor < len(char_buffer) and char_buffer[cursor][0].isspace():
                cursor += 1
        line_chars: list[tuple[str, Style]] = []
        for expected in part:
            while cursor < len(char_buffer) and char_buffer[cursor][0] != expected:
                if char_buffer[cursor][0].isspace():
                    cursor += 1
                    continue
                break
            if cursor >= len(char_buffer):
                break
            line_chars.append(char_buffer[cursor])
            cursor += 1
        prefix = initial_prefix if index == 0 else subsequent_prefix
        content_spans = _coalesce_char_spans(line_chars)
        rendered.append(render_styled_line(join_spans((*prefix, *content_spans))))
    return rendered


def _coalesce_char_spans(chars: list[tuple[str, Style]]) -> tuple[StyledSpan, ...]:
    if not chars:
        return (StyledSpan("", Style()),)
    spans: list[StyledSpan] = []
    buffer = [chars[0][0]]
    active_style = chars[0][1]
    for char, style in chars[1:]:
        if style == active_style:
            buffer.append(char)
            continue
        spans.append(StyledSpan("".join(buffer), active_style))
        buffer = [char]
        active_style = style
    spans.append(StyledSpan("".join(buffer), active_style))
    return tuple(spans)


def _coalesce_spans(spans: list[StyledSpan]) -> list[StyledSpan]:
    if not spans:
        return []
    merged: list[StyledSpan] = [spans[0]]
    for span in spans[1:]:
        previous = merged[-1]
        if previous.style == span.style:
            merged[-1] = StyledSpan(previous.text + span.text, previous.style)
            continue
        merged.append(span)
    return merged


def _heading_style(level: int) -> Style:
    if level == 1:
        return Style(bold=True, underline=True)
    if level == 2:
        return Style(bold=True)
    if level == 3:
        return Style(bold=True, italic=True)
    return Style(italic=True)


def _render_code_block_line(text: str, *, width: int) -> list[str]:
    return _render_inline_wrapped(
        text,
        width=width,
        base_style=Style(fg="cyan"),
        initial_prefix=(StyledSpan("  ", Style(fg="cyan")),),
        subsequent_prefix=(StyledSpan("  ", Style(fg="cyan")),),
    )


def _is_local_path_like_link(destination: str) -> bool:
    if "://" in destination:
        return False
    return (
        destination.startswith(("/", "./", "../", "~"))
        or "/" in destination
        or destination.endswith(".py")
        or destination.endswith(".md")
        or destination.endswith(".json")
    )


def _display_link_target(destination: str) -> str:
    if destination.startswith("/"):
        cwd = _safe_cwd()
        if cwd is not None:
            try:
                relative = Path(destination).resolve(strict=False).relative_to(
                    cwd.resolve(strict=False)
                )
            except ValueError:
                return destination
            return relative.as_posix()
    return destination


def _safe_cwd() -> Path | None:
    try:
        return Path.cwd()
    except OSError:
        return None


def _merge_styles(base: Style, override: Style) -> Style:
    return Style(
        bold=base.bold or override.bold,
        dim=base.dim or override.dim,
        italic=base.italic or override.italic,
        underline=base.underline or override.underline,
        fg=override.fg if override.fg is not None else base.fg,
        bg=override.bg if override.bg is not None else base.bg,
    )
