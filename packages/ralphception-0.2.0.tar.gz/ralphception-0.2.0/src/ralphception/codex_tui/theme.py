"""Compatibility wrapper over low-level TUI theme helpers."""

from ralphception.tui_core.theme import RgbColor, blend, is_light, user_surface_rgb

__all__ = ["RgbColor", "blend", "is_light", "user_surface_rgb"]
