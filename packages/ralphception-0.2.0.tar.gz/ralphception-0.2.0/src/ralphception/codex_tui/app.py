"""Top-level Codex-led human TUI loop for Ralphception."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
import os
from pathlib import Path
import select
import sys
from threading import Event, Lock, Thread, current_thread
import textwrap
from typing import cast

try:
    import termios
except ImportError:  # pragma: no cover - unix only in practice
    termios = None  # type: ignore[assignment]

from ralphception.runtime.frontends import CurrentBlockerStateEvent, FrontendEvent, RuntimeFrontend, RuntimeStep
from ralphception.runtime.inline_shell import (
    InlineShellRunResult,
    _resolve_inline_shell_session_manager_factory,
)
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.project_trust import load_project_trust, save_project_trust
from ralphception.runtime.supervisor import (
    RuntimeLaunchAbortedError,
    RuntimeSupervisor,
)

from .ralph_adapter import RalphAdapter
from .custom_terminal import CustomTerminal, Position, Size
from .history_cell import rendered_block_is_internal_skill_meta
from .tui import Tui


@dataclass
class _RecordingBackend:
    screen_size: Size = Size(width=80, height=24)
    cursor_position: Position = Position(x=0, y=0)
    writes: list[str] = field(default_factory=list)

    def size(self) -> Size:
        return self.screen_size

    def get_cursor_position(self) -> Position:
        return self.cursor_position

    def write(self, data: str) -> None:
        self.writes.append(data)

    def flush(self) -> None:
        return

    def enter_raw_mode(self) -> None:
        return

    def leave_raw_mode(self) -> None:
        return


def _wrap_indented(text: str, *, width: int, indent: str) -> list[str]:
    indent_width = len(indent)
    wrapped = textwrap.wrap(
        text,
        width=max(1, width - indent_width),
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    return [f"{indent}{line}".rstrip() for line in wrapped]


@dataclass(frozen=True, slots=True)
class _TrustPromptScreen:
    cwd: Path
    highlighted_choice: int = 0

    def render_lines(self, width: int) -> list[str]:
        lines = [
            f"> You are in {self.cwd}",
            "",
            *_wrap_indented(
                "Do you trust the contents of this directory? Working with untrusted contents comes with higher risk of prompt injection.",
                width=width,
                indent="  ",
            ),
            "",
            "› 1. Yes, continue" if self.highlighted_choice == 0 else "  1. Yes, continue",
            "› 2. No, quit" if self.highlighted_choice == 1 else "  2. No, quit",
            "",
            "  Press enter to continue",
        ]
        return lines

    def desired_height(self, width: int) -> int:
        return len(self.render_lines(width))

    def cursor_pos(self, area) -> tuple[int, int]:
        rendered = self.render_lines(area.width)
        option_prefix = "› 1." if self.highlighted_choice == 0 else "› 2."
        option_index = next(
            (
                index
                for index, line in enumerate(rendered)
                if line.startswith(option_prefix)
            ),
            0,
        )
        return (0, area.y + option_index)

    def render(self, frame) -> None:
        rendered = self.render_lines(frame.area.width)
        frame.lines = rendered
        frame.set_cursor_position(self.cursor_pos(frame.area))


def build_recording_tui() -> Tui:
    return Tui(terminal=CustomTerminal.with_home_viewport(_RecordingBackend()))


@dataclass(slots=True)
class CodexTuiFrontend(RuntimeFrontend):
    """Runtime frontend backed by the new Codex-style terminal core."""

    repo_root: Path
    input_callback: Callable[[], str] | None = None
    tui: Tui | None = None
    draw_initial_shell: bool = True
    enable_trust_onboarding: bool = True
    default_session_manager_factory: object | None = None
    adapter: RalphAdapter = field(init=False)
    events: list[FrontendEvent] = field(default_factory=list)
    _output_lines: list[str] = field(default_factory=list)
    _draw_lock: Lock = field(default_factory=Lock, init=False)
    _animation_stop: Event = field(default_factory=Event, init=False)
    _animation_thread: Thread | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        use_recording_tui = self.input_callback is not None or not _stdio_supports_interactive_tui()
        self.tui = self.tui or (build_recording_tui() if use_recording_tui else Tui.init())
        self.adapter = RalphAdapter(
            repo_root=self.repo_root,
            animations_enabled=self.input_callback is None,
        )
        if self.draw_initial_shell:
            self.render_idle_shell()

    def emit_event(self, event: FrontendEvent) -> None:
        self.events.append(event)
        self.adapter.apply_event(event)
        self._flush_and_redraw()

    def emit_status(self, step: RuntimeStep) -> None:
        self.adapter.emit_status(step)
        self._flush_and_redraw()

    def finish(self, step: RuntimeStep) -> None:
        self.adapter.finish(step)
        self._flush_and_redraw()

    def read_user_input(self) -> str:
        if self.input_callback is not None:
            text = self.input_callback()
            self.adapter.commit_user_message(text)
            self._flush_and_redraw()
            return text

        backend = self._require_tui().terminal.backend
        fd = getattr(backend, "_stdin_fd", 0)
        buffer = ""
        while True:
            self.adapter.set_composer_value(buffer)
            self._redraw()
            ready, _, _ = select.select([fd], [], [], 0.08)
            if not ready:
                self._redraw_if_terminal_resized()
                continue
            raw = os.read(fd, 1)
            if not raw:
                break
            if raw in {b"\r", b"\n"}:
                break
            if raw == b"\x03":
                raise KeyboardInterrupt
            if raw in {b"\x08", b"\x7f"}:
                buffer = buffer[:-1]
                continue
            if raw == b"\x1b":
                self._drain_escape_sequence(fd)
                continue
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                continue
            if text.isprintable():
                buffer += text
        self.adapter.commit_user_message(buffer)
        self._flush_and_redraw()
        return buffer

    def output_text(self) -> str:
        return "\n".join(self._output_lines)

    def close(self) -> None:
        self._stop_animation_loop()
        if self.tui is not None:
            self.tui.close()

    def prompt_trust_decision(self, *, cwd: Path) -> str:
        highlighted_choice = 0
        if self.input_callback is not None:
            while True:
                self._render_trust_prompt(cwd=cwd, highlighted_choice=highlighted_choice)
                response = self.input_callback().strip().lower()
                if response in {"", "1", "y", "yes"}:
                    return "trust" if response != "" else ("trust" if highlighted_choice == 0 else "quit")
                if response in {"2", "n", "no", "quit"}:
                    return "quit"
                if response in {"j", "down"}:
                    highlighted_choice = 1
                    continue
                if response in {"k", "up"}:
                    highlighted_choice = 0
                    continue
            return "quit"

        backend = self._require_tui().terminal.backend
        fd = getattr(backend, "_stdin_fd", 0)
        while True:
            self._render_trust_prompt(cwd=cwd, highlighted_choice=highlighted_choice)
            key = self._read_key(fd)
            if key == "":
                self._redraw_if_terminal_resized(
                    redraw_fn=lambda: self._render_trust_prompt(
                        cwd=cwd,
                        highlighted_choice=highlighted_choice,
                    )
                )
                continue
            if key == "ctrl-c":
                raise KeyboardInterrupt
            if key in {"1", "y"}:
                return "trust"
            if key in {"2", "n"}:
                return "quit"
            if key == "enter":
                return "trust" if highlighted_choice == 0 else "quit"
            if key in {"j", "down"}:
                highlighted_choice = 1
                continue
            if key in {"k", "up"}:
                highlighted_choice = 0

    def render_idle_shell(self, *, include_loading_transition: bool = False) -> None:
        if include_loading_transition:
            self._render_loading_shell()
            self.adapter.emit_startup_shell_history()
            self._flush_and_redraw()
            return
        self._redraw()

    def show_submit_waiting(self, *, summary: str) -> None:
        self.adapter.begin_submit_waiting(summary)
        self._redraw()

    def drain_pending_input(self) -> None:
        if self.input_callback is not None:
            return
        backend = self._require_tui().terminal.backend
        fd = getattr(backend, "_stdin_fd", None)
        if fd is None:
            return
        self._drain_available_input(fd)

    def reset_viewport(self) -> None:
        self._stop_animation_loop()
        tui = self._require_tui()
        tui.terminal.backend.write("\x1b[2J\x1b[H")
        tui.terminal.backend.flush()
        self.tui = Tui(terminal=CustomTerminal.with_home_viewport(tui.terminal.backend))

    @property
    def live_status(self) -> str | None:
        return self.adapter._live_status

    @property
    def current_task_label(self) -> str | None:
        return self.adapter._current_task

    @property
    def current_plan_node_label(self) -> str | None:
        return self.adapter._current_plan_node

    @property
    def current_loop_label(self) -> str | None:
        return self.adapter._current_loop

    @property
    def current_blocker_state(self) -> str | None:
        return self.adapter._current_blocker

    @property
    def current_waiting_state(self) -> str | None:
        return self.adapter._current_waiting

    def _flush_and_redraw(self) -> None:
        with self._draw_lock:
            tui = self._require_tui()
            width = max(1, tui.terminal.size().width)
            pending_cells = self.adapter.drain_pending_history_cells()
            if pending_cells:
                display_lines: list[str] = []
                logical_lines: list[str] = []
                for cell in pending_cells:
                    cell_display_lines = cell.display_lines(width)
                    cell_logical_lines = cell.transcript_lines(10_000)
                    if rendered_block_is_internal_skill_meta(cell_display_lines) or rendered_block_is_internal_skill_meta(
                        cell_logical_lines
                    ):
                        continue
                    display_lines.extend(cell_display_lines)
                    logical_lines.extend(cell_logical_lines)
                self._output_lines.extend(logical_lines)
                tui.insert_history_lines(display_lines)
            self._draw_current_frame()
        self._sync_animation_loop()

    def _redraw(self) -> None:
        with self._draw_lock:
            self._draw_current_frame()
        self._sync_animation_loop()

    def _render_loading_shell(self) -> None:
        with self._draw_lock:
            tui = self._require_tui()
            width = max(1, tui.terminal.size().width)
            tui.insert_history_lines(self.adapter.build_loading_shell_history_cell().display_lines(width))

    def _require_tui(self) -> Tui:
        if self.tui is None:
            raise RuntimeError("CodexTuiFrontend requires an initialized TUI")
        return self.tui

    def _redraw_if_terminal_resized(self, redraw_fn: Callable[[], None] | None = None) -> bool:
        tui = self._require_tui()
        if tui.terminal.size() == tui.terminal.last_known_screen_size:
            return False
        (redraw_fn or self._redraw)()
        return True

    def _drain_escape_sequence(self, fd: int) -> None:
        self._drain_available_input(fd)

    def _drain_available_input(self, fd: int) -> None:
        if termios is None:
            return
        original = termios.tcgetattr(fd)
        try:
            attrs = termios.tcgetattr(fd)
            attrs[3] &= ~termios.ICANON
            attrs[3] &= ~termios.ECHO
            attrs[6][termios.VMIN] = 0
            attrs[6][termios.VTIME] = 0
            termios.tcsetattr(fd, termios.TCSANOW, attrs)
            while os.read(fd, 1):
                continue
        except OSError:
            return
        finally:
            termios.tcsetattr(fd, termios.TCSANOW, original)

    def _render_trust_prompt(self, *, cwd: Path, highlighted_choice: int) -> None:
        with self._draw_lock:
            tui = self._require_tui()
            width = max(1, tui.terminal.size().width)
            prompt = _TrustPromptScreen(cwd=cwd, highlighted_choice=highlighted_choice)
            tui.clear_pending_history_lines()
            tui.draw(prompt.desired_height(width), prompt.render)

    def _read_key(self, fd: int) -> str:
        ready, _, _ = select.select([fd], [], [], 0.08)
        if not ready:
            return ""
        raw = os.read(fd, 1)
        if not raw:
            return ""
        if raw in {b"\r", b"\n"}:
            return "enter"
        if raw == b"\x03":
            return "ctrl-c"
        if raw == b"\x1b":
            try:
                next_one = os.read(fd, 1)
                next_two = os.read(fd, 1) if next_one == b"[" else b""
            except OSError:
                return "escape"
            if next_one == b"[" and next_two == b"A":
                return "up"
            if next_one == b"[" and next_two == b"B":
                return "down"
            return "escape"
        try:
            return raw.decode("utf-8").lower()
        except UnicodeDecodeError:
            return ""

    def _draw_current_frame(self) -> None:
        tui = self._require_tui()
        width = max(1, tui.terminal.size().width)
        height = self.adapter.chatwidget.desired_height(width)
        tui.draw(height, self.adapter.chatwidget.render)

    def _animation_loop(self) -> None:
        while not self._animation_stop.wait(0.08):
            indicator = self.adapter.chatwidget.bottom_pane.status_indicator
            if indicator is None or not indicator.animations_enabled:
                return
            try:
                with self._draw_lock:
                    self._draw_current_frame()
            except Exception:
                return

    def _sync_animation_loop(self) -> None:
        indicator = self.adapter.chatwidget.bottom_pane.status_indicator
        should_run = (
            self.input_callback is None
            and indicator is not None
            and indicator.animations_enabled
        )
        if should_run:
            if self._animation_thread is not None and self._animation_thread.is_alive():
                return
            self._animation_stop.clear()
            self._animation_thread = Thread(
                target=self._animation_loop,
                name="ralphception-codex-tui-animation",
                daemon=True,
            )
            self._animation_thread.start()
            return
        self._stop_animation_loop()

    def _stop_animation_loop(self) -> None:
        self._animation_stop.set()
        thread = self._animation_thread
        if thread is not None and thread.is_alive() and thread is not current_thread():
            thread.join(timeout=0.2)
        self._animation_thread = None


def _stdio_supports_interactive_tui() -> bool:
    stdout_isatty = getattr(sys.stdout, "isatty", lambda: False)()
    stdin_isatty = getattr(sys.stdin, "isatty", lambda: False)()
    if not stdout_isatty or not stdin_isatty:
        return False
    try:
        getattr(sys.stdin, "fileno", lambda: 0)()
        getattr(sys.stdout, "fileno", lambda: 1)()
    except OSError:
        return False
    return True


class ScriptedCodexTuiFrontend(CodexTuiFrontend):
    def __init__(
        self,
        *,
        repo_root: Path,
        inputs: Sequence[str] = (),
        tui: Tui | None = None,
        draw_initial_shell: bool = True,
        enable_trust_onboarding: bool = False,
    ) -> None:
        self.scripted_inputs = list(inputs)
        CodexTuiFrontend.__init__(
            self,
            repo_root=repo_root,
            input_callback=self._consume_input,
            tui=tui,
            draw_initial_shell=draw_initial_shell,
            enable_trust_onboarding=enable_trust_onboarding,
        )

    def _consume_input(self) -> str:
        if not self.scripted_inputs:
            raise RuntimeError("no scripted input available")
        return self.scripted_inputs.pop(0)


def _read_nonempty_input(frontend: CodexTuiFrontend) -> str | None:
    while True:
        try:
            text = frontend.read_user_input().strip()
        except RuntimeError as exc:
            if str(exc) == "no scripted input available":
                return None
            raise
        if text:
            return text


def _submit_waiting_summary(*, prompt_kind: str | None = None, startup: bool = False) -> str:
    if startup or prompt_kind == "startup_prompt":
        return "Preparing startup intake"
    return "Processing your response"


def maybe_run_trust_onboarding(*, repo_root: Path, frontend: CodexTuiFrontend) -> bool:
    if load_project_trust(repo_root) is not None:
        return True
    decision = frontend.prompt_trust_decision(cwd=repo_root)
    if decision == "trust":
        save_project_trust(repo_root, "trusted")
        frontend.drain_pending_input()
        frontend.reset_viewport()
        frontend.render_idle_shell(include_loading_transition=True)
        return True
    return False


def run_codex_tui_shell(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "terminal",
    use_fake_session_manager: bool = False,
    session_manager_factory=None,
    frontend: CodexTuiFrontend | None = None,
    keep_alive: bool | None = None,
) -> InlineShellRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    trust_undecided = load_project_trust(resolved_repo_root) is None
    resolved_session_manager_factory = _resolve_inline_shell_session_manager_factory(
        session_manager_factory=session_manager_factory,
        use_fake_session_manager=use_fake_session_manager,
    )
    resolved_frontend = frontend or CodexTuiFrontend(
        repo_root=resolved_repo_root,
        draw_initial_shell=not (seed_prompt is None and not resume and trust_undecided),
    )
    keep_alive = resolved_frontend.input_callback is None if keep_alive is None else keep_alive
    last_result = InlineShellRunResult(
        mode="running",
        root_run_id=None,
        authoritative_repo_root=str(resolved_repo_root),
        log_text=resolved_frontend.output_text(),
    )
    try:
        if (
            seed_prompt is None
            and not resume
            and resolved_frontend.enable_trust_onboarding
            and not maybe_run_trust_onboarding(
                repo_root=resolved_repo_root,
                frontend=resolved_frontend,
            )
        ):
            return last_result
        while True:
            supervisor = RuntimeSupervisor(
                repo_root=resolved_repo_root,
                seed_prompt=seed_prompt,
                source_repos=source_repos,
                approve_all=approve_all,
                approver=approver,
                session_manager_factory=resolved_session_manager_factory
                or resolved_frontend.default_session_manager_factory,
            )
            if resume:
                supervisor.request_resume_launch()
            else:
                first_prompt = seed_prompt.strip() if seed_prompt is not None else _read_nonempty_input(resolved_frontend)
                if first_prompt is None:
                    return last_result
                supervisor.request_start_fresh_launch(source_repos=source_repos)
                resolved_frontend.show_submit_waiting(summary=_submit_waiting_summary(startup=True))
                supervisor.resolve_startup_input(user_text=first_prompt, source_repos=source_repos)

            while True:
                result = supervisor.run(frontend=cast(RuntimeFrontend, resolved_frontend))
                if result.mode in {"completed", "failed"}:
                    break
                prompt = supervisor.current_pending_prompt()
                if prompt is None:
                    watchdog_result = supervisor.activate_root_watchdog(
                        frontend=cast(RuntimeFrontend, resolved_frontend),
                        trigger_reason=result.watchdog_trigger_reason or "idle",
                    )
                    if watchdog_result is None:
                        break
                    result = watchdog_result
                    if result.mode in {"completed", "failed"}:
                        break
                    prompt = supervisor.current_pending_prompt()
                    if prompt is None:
                        break
                reply = _read_nonempty_input(resolved_frontend)
                if reply is None:
                    return last_result
                if prompt.prompt_kind == "launch_conflict" and reply.lower() in {"start", "new"}:
                    reply = "override"
                resolved_frontend.show_submit_waiting(
                    summary=_submit_waiting_summary(prompt_kind=prompt.prompt_kind)
                )
                resolution = supervisor.resolve_pending_prompt(thread_id=prompt.thread_id, user_text=reply)
                if resolution.kind != "resolved":
                    continue
                if resolution.action == "pause":
                    startup_record = load_startup_record(resolved_repo_root)
                    return InlineShellRunResult(
                        mode="running",
                        root_run_id=None if startup_record is None else startup_record.outer_run_id,
                        authoritative_repo_root=str(resolved_repo_root),
                        log_text=resolved_frontend.output_text(),
                    )
                resolved_frontend.emit_event(CurrentBlockerStateEvent.clear())
                if resolution.action == "abort" and prompt.prompt_kind in {"resume_session", "launch_conflict"}:
                    raise RuntimeLaunchAbortedError("Launch aborted.")

            resolved_frontend.finish(RuntimeStep(kind=result.mode))
            last_result = InlineShellRunResult(
                mode="completed" if result.mode == "completed" else ("failed" if result.mode == "failed" else "running"),
                root_run_id=result.root_run_id,
                authoritative_repo_root=result.authoritative_repo_root,
                log_text=resolved_frontend.output_text(),
            )
            if not keep_alive or seed_prompt is not None:
                return last_result
            resume = False
            seed_prompt = None
    finally:
        resolved_frontend.close()


__all__ = [
    "CodexTuiFrontend",
    "ScriptedCodexTuiFrontend",
    "maybe_run_trust_onboarding",
    "run_codex_tui_shell",
]
