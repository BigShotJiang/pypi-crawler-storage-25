"""Insert committed history above the live viewport."""

from __future__ import annotations

from collections.abc import Sequence
import re
import textwrap

from .custom_terminal import CustomTerminal, Rect
from .styled_text import trim_ansi_text

_SGR_RE = re.compile(r"\x1b\[[0-9;]*m")


def insert_history_lines(terminal: CustomTerminal, lines: Sequence[str]) -> None:
    if not lines:
        return

    screen_size = terminal.size()
    area = terminal.viewport_area
    wrap_width = max(1, area.width or screen_size.width)
    wrapped = _wrap_lines(lines, width=wrap_width)
    wrapped_rows = len(wrapped)

    if area.top <= 1:
        history_origin = area.top
        max_history_rows = max(0, screen_size.height - area.height - history_origin)
        visible_history = wrapped[:max_history_rows]
        for index, line in enumerate(visible_history):
            terminal.backend.write(_move_to(0, history_origin + index))
            terminal.backend.write("\x1b[2K")
            terminal.backend.write(_trim_to_width(line, wrap_width))
        terminal.backend.write(_move_to(terminal.last_known_cursor_pos.x, terminal.last_known_cursor_pos.y))
        area = Rect(
            x=area.x,
            y=history_origin + len(visible_history),
            width=area.width,
            height=area.height,
        )
        if area != terminal.viewport_area:
            terminal.set_viewport_area(area)
        if visible_history:
            terminal.note_history_rows_inserted(len(visible_history))
        return

    if area.bottom < screen_size.height:
        overflow_rows = max(0, wrapped_rows - area.top)
        scroll_amount = min(overflow_rows, screen_size.height - area.bottom)
        if scroll_amount > 0:
            top_1based = area.top + 1
            terminal.backend.write(f"\x1b[{top_1based};{screen_size.height}r")
            terminal.backend.write(_move_to(0, area.top))
            for _ in range(scroll_amount):
                terminal.backend.write("\x1bM")
            terminal.backend.write("\x1b[r")
            area = Rect(x=area.x, y=area.y + scroll_amount, width=area.width, height=area.height)

    if area.top > 0:
        terminal.backend.write(f"\x1b[1;{area.top}r")
        cursor_top = max(0, area.top - 1)
        terminal.backend.write(_move_to(0, cursor_top))
        for line in wrapped:
            terminal.backend.write("\r\n")
            terminal.backend.write("\x1b[2K")
            terminal.backend.write(_trim_to_width(line, wrap_width))
        terminal.backend.write("\x1b[r")
    terminal.backend.write(_move_to(terminal.last_known_cursor_pos.x, terminal.last_known_cursor_pos.y))

    if area != terminal.viewport_area:
        terminal.set_viewport_area(area)
    terminal.note_history_rows_inserted(wrapped_rows)


def _wrap_lines(lines: Sequence[str], *, width: int) -> list[str]:
    wrapped: list[str] = []
    for line in lines:
        if line == "":
            wrapped.append("")
            continue
        if _SGR_RE.search(line):
            wrapped.extend(_wrap_ansi_line(line, width=width))
            continue
        chunks = textwrap.wrap(
            line,
            width=width,
            replace_whitespace=False,
            drop_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
        )
        wrapped.extend(chunks or [""])
    return wrapped


def _wrap_ansi_line(line: str, *, width: int) -> list[str]:
    if width <= 0:
        return [""]
    chunks: list[str] = []
    current: list[str] = []
    active_sgr: list[str] = []
    visible_width = 0
    index = 0
    while index < len(line):
        match = _SGR_RE.match(line, index)
        if match is not None:
            seq = match.group(0)
            current.append(seq)
            if seq == "\x1b[0m":
                active_sgr.clear()
            else:
                active_sgr.append(seq)
            index = match.end()
            continue
        if visible_width == width:
            if active_sgr and (not current or current[-1] != "\x1b[0m"):
                current.append("\x1b[0m")
            chunks.append("".join(current))
            current = list(active_sgr)
            visible_width = 0
        current.append(line[index])
        visible_width += 1
        index += 1
    if current:
        if active_sgr and current[-1] != "\x1b[0m":
            current.append("\x1b[0m")
        chunks.append("".join(current))
    return chunks or [""]


def _move_to(x: int, y: int) -> str:
    return f"\x1b[{y + 1};{x + 1}H"


def _trim_to_width(line: str, width: int) -> str:
    return trim_ansi_text(line, width)
