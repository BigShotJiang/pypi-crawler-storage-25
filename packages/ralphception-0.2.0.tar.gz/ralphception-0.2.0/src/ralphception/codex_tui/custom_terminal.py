"""Compatibility wrapper over low-level custom terminal primitives."""

from ralphception.tui_core.terminal import BufferFrame, CustomTerminal, Position, Rect, Size

__all__ = ["BufferFrame", "CustomTerminal", "Position", "Rect", "Size"]
