"""Transcript/history cells for the Codex TUI Python port."""

from __future__ import annotations

from dataclasses import dataclass
import math
import textwrap
from typing import Protocol

from .markdown_render import render_markdown_lines, render_notice_lines
from .status import render_session_header_card
from .styled_text import (
    Style,
    StyledSpan,
    join_spans,
    pad_styled_line,
    plain_line,
    render_styled_line,
    trim_styled_line_with_ellipsis,
    user_surface_style,
    visible_width,
)

_COMMAND_OUTPUT_HEAD_LINES = 2
_COMMAND_OUTPUT_TAIL_LINES = 2
_COMMAND_CONTINUATION_MAX_LINES = 2


class HistoryCell(Protocol):
    def display_lines(self, width: int) -> list[str]: ...

    def transcript_lines(self, width: int) -> list[str]: ...

    def desired_height(self, width: int) -> int: ...

    def desired_transcript_height(self, width: int) -> int: ...


def is_internal_skill_meta(text: str) -> bool:
    collapsed = " ".join(text.split())
    normalized = collapsed.lstrip("•*- ").strip()
    for prefix in ("agent delta:", "agent:"):
        if normalized.lower().startswith(prefix):
            normalized = normalized[len(prefix) :].lstrip("•*- ").strip()
            break
    lowered = normalized.lower()
    if lowered.startswith("using ralph-"):
        return True
    if "loaded the execution instructions" in lowered:
        return True
    if "task-specific execution instructions" in lowered:
        return True
    return False


def is_internal_skill_command(command: str, output: tuple[str, ...] = ()) -> bool:
    lowered = " ".join(command.split()).lower()
    if "using skill:" in lowered and "ralph-" in lowered:
        return True
    if "printf '\\n--- skill ---\\n'" in lowered and "/skill.md" in lowered:
        return True
    if "cat " in lowered and "/skill.md" in lowered and "/skills/" in lowered:
        return True
    if "/ralphception-codex-" in lowered and (lowered.startswith("sed -n ") or lowered.startswith("cat ")):
        return True
    if "/private/var/folders/" in lowered and ("sed -n " in lowered or " cat " in lowered or lowered.startswith("cat ")):
        return True
    if output:
        combined_output = " ".join(line.strip() for line in output if line.strip())
        combined_output_lowered = " ".join(combined_output.split()).lower()
        if "using skill:" in combined_output_lowered and "ralph-" in combined_output_lowered:
            return True
    return False


def rendered_block_is_internal_skill_meta(lines: list[str]) -> bool:
    from .styled_text import strip_ansi

    combined = " ".join(strip_ansi(line).strip() for line in lines if strip_ansi(line).strip())
    return is_internal_skill_meta(combined)


def _wrap_prefixed(text: str, *, width: int, initial_prefix: str, subsequent_prefix: str) -> list[str]:
    content_width = max(1, width - len(initial_prefix))
    parts = textwrap.wrap(
        text,
        width=content_width,
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    wrapped: list[str] = []
    for index, part in enumerate(parts):
        prefix = initial_prefix if index == 0 else subsequent_prefix
        wrapped.append(f"{prefix}{part}".rstrip())
    return wrapped


def _style_wrapped_prefixes(
    lines: list[str],
    *,
    initial_prefix: str,
    initial_style: Style,
    subsequent_prefix: str | None = None,
    subsequent_style: Style | None = None,
) -> list[str]:
    styled: list[str] = []
    for index, line in enumerate(lines):
        if index == 0 and line.startswith(initial_prefix):
            styled.append(
                render_styled_line(
                    join_spans(
                        (
                            StyledSpan(initial_prefix, initial_style),
                            StyledSpan(line[len(initial_prefix) :]),
                        )
                    )
                )
            )
            continue
        if subsequent_prefix is not None and line.startswith(subsequent_prefix):
            styled.append(
                render_styled_line(
                    join_spans(
                        (
                            StyledSpan(subsequent_prefix, subsequent_style or Style()),
                            StyledSpan(line[len(subsequent_prefix) :]),
                        )
                    )
                )
            )
            continue
        styled.append(line)
    return styled


def _render_user_surface_line(*, prefix: str, text: str, dim_prefix: bool, width: int) -> str:
    surface = user_surface_style()
    return render_styled_line(
        pad_styled_line(
            join_spans(
                (
                    StyledSpan(prefix, Style(dim=dim_prefix, bg=surface.bg)),
                    StyledSpan(text, surface),
                )
            ),
            width,
            pad_style=surface,
        )
    )


def _render_user_surface_blank(*, width: int) -> str:
    surface = user_surface_style()
    return render_styled_line(pad_styled_line(plain_line(""), width, pad_style=surface))


def _measure(lines: list[str], *, width: int) -> int:
    if not lines:
        return 0
    safe_width = max(1, width)
    rows = 0
    for line in lines:
        rows += max(1, math.ceil(max(1, visible_width(line)) / safe_width))
    return rows


def _normalize_command_lines(command: str) -> list[str]:
    logical_lines = [" ".join(line.split()) for line in command.splitlines() if line.strip()]
    if logical_lines:
        return logical_lines
    return [" ".join(command.split())]


def _wrap_command_header_lines(
    *,
    command: str,
    width: int,
    initial_prefix: str,
    subsequent_prefix: str,
    max_continuation_lines: int,
) -> list[str]:
    logical_lines = _normalize_command_lines(command)
    if not logical_lines:
        return [initial_prefix.rstrip()]

    first_width = max(1, width - len(initial_prefix))
    continuation_width = max(1, width - len(subsequent_prefix))

    first_parts = textwrap.wrap(
        logical_lines[0],
        width=first_width,
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=True,
        break_on_hyphens=False,
    ) or [""]
    header_line = f"{initial_prefix}{first_parts[0]}".rstrip()

    continuation_parts: list[str] = list(first_parts[1:])
    for line in logical_lines[1:]:
        continuation_parts.extend(
            textwrap.wrap(
                line,
                width=continuation_width,
                replace_whitespace=False,
                drop_whitespace=True,
                break_long_words=True,
                break_on_hyphens=False,
            )
            or [""]
        )

    if len(continuation_parts) > max_continuation_lines:
        omitted = len(continuation_parts) - max_continuation_lines
        continuation_parts = [
            *continuation_parts[:max_continuation_lines],
            f"… +{omitted} lines",
        ]

    return [header_line, *[f"{subsequent_prefix}{part}".rstrip() for part in continuation_parts]]


def _command_header_style(*, active: bool) -> Style:
    return Style(dim=not active, bold=active)


def _render_command_prefixed_lines(
    *,
    text: str,
    width: int,
    initial_prefix: str,
    subsequent_prefix: str,
    content_style: Style,
    prefix_style: Style | None = None,
    force_single_line: bool = False,
) -> list[str]:
    prefix_style = prefix_style or content_style
    if force_single_line:
        wrapped = [f"{initial_prefix}{text}".rstrip()]
    else:
        wrapped = _wrap_prefixed(
            text,
            width=width,
            initial_prefix=initial_prefix,
            subsequent_prefix=subsequent_prefix,
        )
    rendered: list[str] = []
    for index, line in enumerate(wrapped):
        prefix = initial_prefix if index == 0 else subsequent_prefix
        content = line[len(prefix) :]
        rendered.append(
            render_styled_line(
                trim_styled_line_with_ellipsis(
                    join_spans(
                        (
                            StyledSpan(prefix, prefix_style),
                            StyledSpan(content, content_style),
                        )
                    ),
                    width,
                    ellipsis_style=content_style,
                )
            )
        )
    return rendered


def _truncate_command_output(output: tuple[str, ...]) -> tuple[str, ...]:
    visible = tuple(line for line in output)
    limit = _COMMAND_OUTPUT_HEAD_LINES + _COMMAND_OUTPUT_TAIL_LINES
    if len(visible) <= limit:
        return visible
    omitted = len(visible) - limit
    return (
        *visible[:_COMMAND_OUTPUT_HEAD_LINES],
        f"… +{omitted} lines",
        *visible[-_COMMAND_OUTPUT_TAIL_LINES:],
    )


def render_command_display_lines(
    *,
    command: str,
    width: int,
    output: tuple[str, ...] = (),
    status: str | None = None,
    active: bool = False,
) -> list[str]:
    if is_internal_skill_command(command, output):
        return []
    lines = _style_wrapped_prefixes(
        _wrap_command_header_lines(
            command=command,
            width=width,
            initial_prefix=f"• {'Running' if active else 'Ran'} ",
            subsequent_prefix="  │ ",
            max_continuation_lines=_COMMAND_CONTINUATION_MAX_LINES,
        ),
        initial_prefix=f"• {'Running' if active else 'Ran'} ",
        initial_style=_command_header_style(active=active),
        subsequent_prefix="  │ ",
        subsequent_style=Style(dim=True),
    )
    output_style = Style(dim=True)
    truncated_output = _truncate_command_output(output)
    if truncated_output:
        for index, line in enumerate(truncated_output):
            lines.extend(
                _render_command_prefixed_lines(
                    text=line,
                    width=width,
                    initial_prefix="  └ " if index == 0 else "    ",
                    subsequent_prefix="    ",
                    content_style=output_style,
                    prefix_style=Style(dim=True),
                )
            )
    normalized_status = (status or "").strip().lower()
    if status and normalized_status not in {"", "completed", "exit 0"}:
        lines.extend(
            _render_command_prefixed_lines(
                text=status,
                width=width,
                initial_prefix="  └ ",
                subsequent_prefix="    ",
                content_style=output_style,
                prefix_style=Style(dim=True),
            )
        )
    return lines


@dataclass(frozen=True, slots=True)
class UserHistoryCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        wrapped = _wrap_prefixed(self.text, width=width, initial_prefix="› ", subsequent_prefix="  ")
        styled: list[str] = [_render_user_surface_blank(width=width)]
        for index, line in enumerate(wrapped):
            if index == 0:
                styled.append(
                    _render_user_surface_line(
                        prefix="› ",
                        text=line[len("› ") :],
                        dim_prefix=True,
                        width=width,
                    )
                )
                continue
            styled.append(
                _render_user_surface_line(
                    prefix="  ",
                    text=line[len("  ") :],
                    dim_prefix=False,
                    width=width,
                )
            )
        styled.append(_render_user_surface_blank(width=width))
        return styled

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class AssistantHistoryCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        if is_internal_skill_meta(self.text):
            return []
        content_width = max(1, width - 2)
        lines = render_markdown_lines(self.text, width=content_width)
        rendered: list[str] = []
        first_visible = True
        for line in lines:
            if not line:
                rendered.append("")
                continue
            if first_visible:
                rendered.append(
                    render_styled_line(
                        join_spans(
                            (
                                StyledSpan("• ", Style(dim=True)),
                                StyledSpan(line),
                            )
                        )
                    )
                )
                first_visible = False
                continue
            rendered.append(
                render_styled_line(
                    join_spans(
                        (
                            StyledSpan("  "),
                            StyledSpan(line),
                        )
                    )
                )
            )
        return rendered

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class SystemHistoryCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        return _style_wrapped_prefixes(
            _wrap_prefixed(self.text, width=width, initial_prefix="• ", subsequent_prefix="  "),
            initial_prefix="• ",
            initial_style=Style(dim=True),
        )

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class TranscriptOnlyHistoryCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        del width
        return []

    def transcript_lines(self, width: int) -> list[str]:
        return SystemHistoryCell(self.text).transcript_lines(width)

    def desired_height(self, width: int) -> int:
        del width
        return 0

    def desired_transcript_height(self, width: int) -> int:
        return SystemHistoryCell(self.text).desired_transcript_height(width)


@dataclass(frozen=True, slots=True)
class WaitingHistoryCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        return _style_wrapped_prefixes(
            _wrap_prefixed(self.text, width=width, initial_prefix="• ", subsequent_prefix="  "),
            initial_prefix="• ",
            initial_style=Style(dim=True),
        )

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class CommandHistoryCell:
    command: str
    output: tuple[str, ...] = ()
    status: str | None = None

    def display_lines(self, width: int) -> list[str]:
        return render_command_display_lines(
            command=self.command,
            width=width,
            output=self.output,
            status=self.status,
            active=False,
        )

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class FinalMessageSeparator:
    def display_lines(self, width: int) -> list[str]:
        safe_width = max(1, width)
        return [
            render_styled_line(
                join_spans((StyledSpan("─" * safe_width, Style(dim=True)),))
            )
        ]

    def transcript_lines(self, width: int) -> list[str]:
        return self.display_lines(width)

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return self.desired_height(width)


@dataclass(frozen=True, slots=True)
class StartupShellHistoryCell:
    version: str
    directory_label: str
    model_label: str
    notice_lines: tuple[str, ...] = ()
    title: str = "Ralphception"
    model_hint: str = "/model to change"

    def display_lines(self, width: int) -> list[str]:
        lines: list[str] = [
            "",
            *render_session_header_card(
                version=self.version,
                directory_label=self.directory_label,
                model_label=self.model_label,
                title=self.title,
                model_hint=self.model_hint,
                max_width=max(1, width),
            ),
        ]
        if self.notice_lines:
            lines.append("")
            for notice in self.notice_lines:
                lines.extend(render_notice_lines(notice, width=width))
            lines.append("")
        return lines

    def transcript_lines(self, width: int) -> list[str]:
        del width
        return []

    def desired_height(self, width: int) -> int:
        return _measure(self.display_lines(width), width=width)

    def desired_transcript_height(self, width: int) -> int:
        return 0
