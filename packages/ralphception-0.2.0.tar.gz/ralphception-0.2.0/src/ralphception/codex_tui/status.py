"""Status helpers for the Codex TUI Python port."""

from __future__ import annotations

import textwrap

from ralphception.tui.path_labels import center_truncate, normalize_directory_label
from ralphception.tui_core.shimmer import shimmer_spans as core_shimmer_spans
from ralphception.tui_core.shimmer import spinner_span

from .styled_text import (
    Style,
    StyledSpan,
    join_spans,
    pad_styled_line,
    plain_line,
    render_styled_line,
    trim_styled_line_with_ellipsis,
    visible_width,
)

DEFAULT_MODEL_LABEL = "gpt-5.4 xhigh fast"
DEFAULT_HEADER_MODEL_LABEL = "gpt-5.4 xhigh   fast"
DEFAULT_CONTEXT_STATUS = "100% context left"
DEFAULT_STATUS_LINE_CONTEXT = "100% left"
DEFAULT_STARTER_PLACEHOLDER = "Ask Ralphception to do anything"
STARTUP_NOTICE_LINES: tuple[str, ...] = (
    "Tip: Ralphception starts with Socratic intake, then writes the PRD, execution plan, loop plan, and todos.",
)
ANSWER_PLACEHOLDER = "Type your answer (optional)"
REPLY_FOOTER_HINT = "enter to submit answer | esc to interrupt"
WORKING_FOOTER_HINT = ""
STARTER_PLACEHOLDERS: tuple[str, ...] = (
    "Explain this codebase",
    "Summarize recent commits",
    "Implement {feature}",
    "Find and fix a bug in @filename",
    "Write tests for @filename",
    "Improve documentation in @filename",
    "Run /review on my current changes",
    "Use /skills to list available skills",
)
_FOOTER_INDENT = 2
_FOOTER_RIGHT_PADDING = 2
_FOOTER_CONTEXT_GAP = 1


def pick_starter_placeholder() -> str:
    return DEFAULT_STARTER_PLACEHOLDER


def build_status_line(
    *,
    model_label: str,
    directory_label: str,
    context_label: str = DEFAULT_STATUS_LINE_CONTEXT,
) -> str:
    return " · ".join(
        part
        for part in (
            model_label.strip(),
            context_label.strip(),
            normalize_directory_label(directory_label),
        )
        if part
    )


def build_header_model_label(
    *,
    model: str,
    reasoning_effort: str | None = None,
    service_tier: str | None = None,
) -> str:
    core = " ".join(part for part in (model, reasoning_effort) if part)
    if service_tier:
        return f"{core}   {service_tier}".strip()
    return core.strip()


def fmt_elapsed_compact(elapsed_seconds: int) -> str:
    if elapsed_seconds < 60:
        return f"{elapsed_seconds}s"
    minutes, seconds = divmod(elapsed_seconds, 60)
    if minutes < 60:
        return f"{minutes}m {seconds:02d}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes:02d}m {seconds:02d}s"


def _spinner_spans(*, animations_enabled: bool, now: float | None = None) -> tuple[StyledSpan, ...]:
    return (spinner_span(animations_enabled=animations_enabled, now=now),)


def _shimmer_spans(text: str, *, animations_enabled: bool, now: float | None = None) -> tuple[StyledSpan, ...]:
    if not text:
        return ()
    if not animations_enabled:
        return (StyledSpan(text),)
    return core_shimmer_spans(text, now=now)


def build_working_status_lines(
    *,
    header: str,
    elapsed_seconds: int,
    inline_message: str | None,
    details: str | None = None,
    width: int,
    show_interrupt_hint: bool = True,
    animations_enabled: bool = True,
    now: float | None = None,
) -> list[str]:
    elapsed_label = fmt_elapsed_compact(max(0, elapsed_seconds))
    line_spans: list[StyledSpan] = [
        *_spinner_spans(animations_enabled=animations_enabled, now=now),
        StyledSpan(" ", Style()),
        *_shimmer_spans(header.strip() or "Working", animations_enabled=animations_enabled, now=now),
        StyledSpan(" "),
    ]
    if show_interrupt_hint:
        line_spans.append(StyledSpan(f"({elapsed_label} • ", Style(dim=True)))
        line_spans.append(StyledSpan("esc", Style(dim=True, underline=True)))
        line_spans.append(StyledSpan(" to interrupt)", Style(dim=True)))
    else:
        line_spans.append(StyledSpan(f"({elapsed_label})", Style(dim=True)))
    if inline_message:
        line_spans.append(StyledSpan(" · ", Style(dim=True)))
        line_spans.append(StyledSpan(inline_message.strip(), Style(dim=True)))
    first_line = trim_styled_line_with_ellipsis(join_spans(line_spans), width)
    rendered = [render_styled_line(first_line)]

    details_text = (details or "").strip()
    if not details_text:
        return rendered
    prefix = "  └ "
    continuation = "    "
    content_width = max(1, width - len(prefix))
    wrapped = textwrap.wrap(
        details_text,
        width=content_width,
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=True,
        break_on_hyphens=False,
    ) or [""]
    for index, part in enumerate(wrapped[:3]):
        leader = prefix if index == 0 else continuation
        detail_line = join_spans(
            (
                StyledSpan(leader, Style(dim=True)),
                StyledSpan(part, Style(dim=True)),
            )
        )
        rendered.append(render_styled_line(trim_styled_line_with_ellipsis(detail_line, width)))
    return rendered


def build_working_status_line(*, elapsed_seconds: int, inline_message: str | None) -> str:
    base = f"• Working ({fmt_elapsed_compact(elapsed_seconds)} • esc to interrupt)"
    if inline_message:
        return f"{base} · {inline_message}"
    return base


def build_footer_status(
    *,
    width: int,
    left_hint: str,
    right_status: str = DEFAULT_CONTEXT_STATUS,
) -> str:
    left = f"  {left_hint}".rstrip() if left_hint else ""
    if not left:
        return right_status.rjust(width)
    prefix_width = 2
    available = max(0, width - prefix_width - len(right_status))
    trimmed_left = left_hint.strip()
    if available <= 0:
        return f"{' ' * prefix_width}{right_status[-max(0, width - prefix_width):]}".rstrip()
    if len(trimmed_left) + 1 > available:
        trimmed_left = trimmed_left[: max(0, available - 1)].rstrip()
    spacing = max(1, available - len(trimmed_left))
    return f"{' ' * prefix_width}{trimmed_left}{' ' * spacing}{right_status}".rstrip()


def render_footer_status_lines(
    *,
    width: int,
    left_hint: str,
    right_status: str = DEFAULT_CONTEXT_STATUS,
) -> list[str]:
    left = left_hint.strip()
    right = "" if left == REPLY_FOOTER_HINT else right_status.strip()
    if not left:
        return [render_styled_line(
            pad_styled_line(join_spans((StyledSpan(right, Style(dim=True)),)), width)
        )]
    if left == "tab to queue message":
        if _can_show_left_with_context(width=width, left_width=len(left), right_width=len(right)):
            return [_render_single_line_footer(width=width, left_text=left, right_text=right)]
        short_hint = "tab to queue"
        if _can_show_left_with_context(width=width, left_width=len(short_hint), right_width=len(right)):
            return [_render_single_line_footer(width=width, left_text=short_hint, right_text=right)]
        if _left_fits(width=width, left_width=len(left)):
            return [_render_single_line_footer(width=width, left_text=left, right_text="")]
        if _left_fits(width=width, left_width=len(short_hint)):
            return [_render_single_line_footer(width=width, left_text=short_hint, right_text="")]
        return [_render_single_line_footer(width=width, left_text="", right_text=right)]
    prefix_width = 2
    available = max(0, width - prefix_width - len(right))
    if available <= 0:
        wrapped = textwrap.wrap(
            left,
            width=max(1, width - prefix_width),
            replace_whitespace=False,
            drop_whitespace=True,
            break_long_words=False,
            break_on_hyphens=False,
        ) or [""]
        return [
            render_styled_line(
                pad_styled_line(
                    join_spans(
                        (
                            StyledSpan(" " * prefix_width, Style()),
                            StyledSpan(part, Style(dim=True)),
                        )
                    ),
                    width,
                )
            )
            for part in wrapped
        ]
    if len(left) + 1 > available:
        wrapped = textwrap.wrap(
            left,
            width=max(1, width - prefix_width),
            replace_whitespace=False,
            drop_whitespace=True,
            break_long_words=False,
            break_on_hyphens=False,
        ) or [""]
        return [
            render_styled_line(
                pad_styled_line(
                    join_spans(
                        (
                            StyledSpan("  ", Style()),
                            StyledSpan(part, Style(dim=True)),
                        )
                    ),
                    width,
                )
            )
            for part in wrapped
        ]
    spacing = max(1, available - len(left))
    line = join_spans(
        (
            StyledSpan("  ", Style()),
            StyledSpan(left, Style(dim=True)),
            StyledSpan(" " * spacing, Style()),
            StyledSpan(right, Style(dim=True)),
        )
    )
    return [render_styled_line(pad_styled_line(line, width))]


def _right_aligned_x(*, width: int, right_width: int) -> int | None:
    max_width = max(0, width - _FOOTER_RIGHT_PADDING)
    if right_width <= 0 or max_width <= 0:
        return None
    if right_width >= max_width:
        return _FOOTER_RIGHT_PADDING
    return width - _FOOTER_RIGHT_PADDING - right_width


def _left_fits(*, width: int, left_width: int) -> bool:
    return left_width <= max(0, width - _FOOTER_INDENT - _FOOTER_RIGHT_PADDING)


def _can_show_left_with_context(*, width: int, left_width: int, right_width: int) -> bool:
    context_x = _right_aligned_x(width=width, right_width=right_width)
    if context_x is None or left_width <= 0:
        return True
    left_extent = _FOOTER_INDENT + left_width + _FOOTER_CONTEXT_GAP
    return left_extent <= context_x


def _render_single_line_footer(*, width: int, left_text: str, right_text: str) -> str:
    spans: list[StyledSpan] = [StyledSpan(" " * _FOOTER_INDENT, Style())]
    if left_text:
        spans.append(StyledSpan(left_text, Style(dim=True)))
    if right_text:
        right_x = _right_aligned_x(width=width, right_width=len(right_text))
        if right_x is not None:
            current_width = _FOOTER_INDENT + len(left_text)
            gap = max(1, right_x - current_width)
            spans.append(StyledSpan(" " * gap, Style()))
            spans.append(StyledSpan(right_text, Style(dim=True)))
    return render_styled_line(pad_styled_line(join_spans(spans), width))


def render_footer_lines(
    *,
    width: int,
    left_hint: str,
    right_status: str,
    composer_has_draft: bool,
    is_task_running: bool,
    status_line: str | None = None,
) -> list[str]:
    if left_hint == REPLY_FOOTER_HINT:
        return render_footer_status_lines(width=width, left_hint=left_hint, right_status="")
    if status_line and not is_task_running:
        return [render_passive_status_line(status_line, width=width)]
    if composer_has_draft and is_task_running:
        return render_footer_status_lines(
            width=width,
            left_hint="tab to queue message",
            right_status=right_status,
        )
    hint = "" if composer_has_draft and left_hint == "? for shortcuts" else left_hint
    return render_footer_status_lines(width=width, left_hint=hint, right_status=right_status)


def render_passive_status_line(status_line: str, *, width: int | None = None) -> str:
    parts = status_line.split(" · ")
    if len(parts) != 3:
        line = join_spans((StyledSpan(f"  {status_line}", Style(dim=True)),))
        if width is not None and visible_width(line) > width:
            line = trim_styled_line_with_ellipsis(line, width)
        return render_styled_line(line)
    model, context, directory = parts
    model_spans: list[StyledSpan] = [StyledSpan("  ")]
    if model.endswith(" fast"):
        model_spans.append(StyledSpan(model[:-5], Style(dim=True)))
        model_spans.append(StyledSpan(" ", Style(dim=True)))
        model_spans.append(StyledSpan("fast", Style(fg="magenta")))
    else:
        model_spans.append(StyledSpan(model, Style(dim=True)))
    model_spans.append(StyledSpan(" · ", Style(dim=True)))
    model_spans.append(StyledSpan(context, Style(dim=True)))
    model_spans.append(StyledSpan(" · ", Style(dim=True)))
    model_spans.append(StyledSpan(directory, Style(dim=True)))
    line = join_spans(model_spans)
    if width is not None and visible_width(line) > width:
        line = trim_styled_line_with_ellipsis(line, width)
    return render_styled_line(line)


def render_session_header_card(
    *,
    version: str,
    directory_label: str,
    model_label: str = DEFAULT_MODEL_LABEL,
    title: str = "Ralphception",
    model_hint: str = "/model to change",
    max_width: int | None = None,
) -> list[str]:
    inner_limit = None
    if max_width is not None:
        inner_limit = max(1, max_width - 4)
    directory = directory_label
    if inner_limit is not None:
        directory = center_truncate(directory_label, inner_limit)
    title_line = join_spans(
        (
            StyledSpan(">_ ", Style(dim=True)),
            StyledSpan(title, Style(bold=True)),
            StyledSpan(" ", Style(dim=True)),
            StyledSpan(f"(v{version})", Style(dim=True)),
        )
    )
    model_spans: list[StyledSpan] = [StyledSpan("model:     ", Style(dim=True))]
    if "   fast" in model_label:
        base, _, _ = model_label.partition("   fast")
        model_spans.append(StyledSpan(base, Style()))
        model_spans.append(StyledSpan("   ", Style()))
        model_spans.append(StyledSpan("fast", Style(fg="magenta")))
    else:
        model_spans.append(StyledSpan(model_label, Style()))
    if model_hint.startswith("/model"):
        model_spans.append(StyledSpan("   ", Style(dim=True)))
        model_spans.append(StyledSpan("/model", Style(fg="cyan")))
        model_spans.append(StyledSpan(model_hint[len("/model") :], Style(dim=True)))
    else:
        model_spans.append(StyledSpan("   ", Style(dim=True)))
        model_spans.append(StyledSpan(model_hint, Style(dim=True)))
    model_line = join_spans(tuple(model_spans))
    directory_line = join_spans(
        (
            StyledSpan("directory: ", Style(dim=True)),
            StyledSpan(directory, Style()),
        )
    )
    content = [
        title_line,
        plain_line(""),
        model_line,
        directory_line,
    ]
    if inner_limit is not None:
        content = [trim_styled_line_with_ellipsis(line, inner_limit) for line in content]
    inner_width = max(visible_width(line) for line in content)
    padded_width = inner_width + 2
    top = f"╭{'─' * padded_width}╮"
    body = [
        f"│ {render_styled_line(pad_styled_line(line, inner_width))} │"
        for line in content
    ]
    bottom = f"╰{'─' * padded_width}╯"
    return [top, *body, bottom]
