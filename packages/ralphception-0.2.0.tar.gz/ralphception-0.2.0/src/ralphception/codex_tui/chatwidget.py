"""Live viewport render tree for the Codex TUI Python port."""

from __future__ import annotations

from dataclasses import dataclass, field
import textwrap
from collections.abc import Callable
from typing import Protocol

from .bottom_pane import BottomPane, ComposerState, FooterState
from .custom_terminal import BufferFrame
from .history_cell import (
    HistoryCell,
    WaitingHistoryCell,
    is_internal_skill_command,
    is_internal_skill_meta,
    render_command_display_lines,
    rendered_block_is_internal_skill_meta,
)
from .markdown_render import render_markdown_lines, render_notice_lines


class ActiveCellRenderable(Protocol):
    def display_lines(self, width: int) -> list[str]: ...


def _wrap_prefixed(text: str, *, width: int, initial_prefix: str, subsequent_prefix: str) -> list[str]:
    content_width = max(1, width - len(initial_prefix))
    parts = textwrap.wrap(
        text,
        width=content_width,
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    lines: list[str] = []
    for index, part in enumerate(parts):
        prefix = initial_prefix if index == 0 else subsequent_prefix
        lines.append(f"{prefix}{part}".rstrip())
    return lines


@dataclass(frozen=True, slots=True)
class ActiveAssistantCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        if is_internal_skill_meta(self.text):
            return []
        return render_markdown_lines(self.text, width=width)


@dataclass(frozen=True, slots=True)
class ActiveCommandCell:
    command: str
    output: tuple[str, ...] = ()

    def display_lines(self, width: int) -> list[str]:
        return render_command_display_lines(
            command=self.command,
            width=width,
            output=self.output,
            active=True,
        )


@dataclass(frozen=True, slots=True)
class ActiveWaitingCell:
    text: str

    def display_lines(self, width: int) -> list[str]:
        return WaitingHistoryCell(self.text).display_lines(width)


@dataclass(slots=True)
class ChatWidget:
    committed_cells: list[HistoryCell] = field(default_factory=list)
    active_cell: ActiveCellRenderable | None = None
    header_lines: tuple[str, ...] = ()
    header_builder: Callable[[int], list[str]] | None = None
    notice_lines: tuple[str, ...] = ()
    bottom_pane: BottomPane = field(
        default_factory=lambda: BottomPane(
            composer=ComposerState(),
            footer=FooterState(left_hint="? for shortcuts", right_status="~"),
        )
    )

    def _render_layout(self, width: int) -> tuple[list[str], int]:
        lines: list[str] = (
            list(self.header_builder(width)) if self.header_builder is not None else list(self.header_lines)
        )
        if lines:
            lines.append("")
        if self.notice_lines:
            for notice in self.notice_lines:
                lines.extend(render_notice_lines(notice, width=width))
            lines.append("")
        if self.active_cell is not None:
            active_lines = self.active_cell.display_lines(width)
            if rendered_block_is_internal_skill_meta(active_lines):
                active_lines = []
            if active_lines:
                if lines or self.committed_cells:
                    if not lines or lines[-1] != "":
                        lines.append("")
                lines.extend(active_lines)
                lines.append("")
        if self.committed_cells and (not lines or lines[-1] != ""):
            lines.append("")
        bottom_pane_start = len(lines)
        lines.extend(self.bottom_pane.render_lines(width))
        return lines, bottom_pane_start

    def render_lines(self, width: int) -> list[str]:
        lines, _ = self._render_layout(width)
        return lines

    def desired_height(self, width: int) -> int:
        return len(self.render_lines(width))

    def cursor_pos(self, area) -> tuple[int, int]:
        rendered, bottom_pane_start = self._render_layout(area.width)
        return self.bottom_pane.cursor_pos(
            area_y=area.y + bottom_pane_start,
            rendered_lines=rendered[bottom_pane_start:],
        )

    def render(self, frame: BufferFrame) -> None:
        rendered = self.render_lines(frame.area.width)
        frame.lines = rendered
        frame.set_cursor_position(self.cursor_pos(frame.area))
