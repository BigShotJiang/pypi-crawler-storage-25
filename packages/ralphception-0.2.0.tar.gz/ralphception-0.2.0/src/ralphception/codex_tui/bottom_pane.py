"""Bottom-pane primitives for the Codex TUI Python port."""

from __future__ import annotations

from dataclasses import dataclass
from time import monotonic

from ralphception.tui_core.composer import composer_cursor_pos, render_composer_surface

from .request_input_overlay import (
    RequestInputOverlayState,
    render_request_input_overlay,
    request_input_overlay_cursor_pos,
)
from .status import (
    DEFAULT_CONTEXT_STATUS,
    DEFAULT_STARTER_PLACEHOLDER,
    build_working_status_lines,
    render_footer_lines,
)
from .styled_text import strip_ansi


@dataclass(frozen=True, slots=True)
class ComposerState:
    value: str = ""
    placeholder: str = DEFAULT_STARTER_PLACEHOLDER
    content_inset: int = 0


@dataclass(frozen=True, slots=True)
class FooterState:
    left_hint: str
    right_status: str = DEFAULT_CONTEXT_STATUS
    model_label: str = "gpt-5.4 xhigh fast"
    status_line: str | None = None
    is_task_running: bool = False


@dataclass(frozen=True, slots=True)
class StatusIndicatorState:
    header: str = "Working"
    details: str | None = None
    inline_message: str | None = None
    show_interrupt_hint: bool = True
    elapsed_seconds: int | None = None
    started_at: float | None = None
    animations_enabled: bool = False

    def resolved_elapsed_seconds(self) -> int:
        if self.elapsed_seconds is not None:
            return max(0, self.elapsed_seconds)
        if self.started_at is None:
            return 0
        return max(0, int(monotonic() - self.started_at))


@dataclass(slots=True)
class BottomPane:
    composer: ComposerState
    footer: FooterState
    status_indicator: StatusIndicatorState | None = None
    request_input_overlay: RequestInputOverlayState | None = None

    @property
    def waiting_line(self) -> str | None:
        if self.status_indicator is None:
            return None
        lines = build_working_status_lines(
            header=self.status_indicator.header,
            elapsed_seconds=self.status_indicator.resolved_elapsed_seconds(),
            inline_message=self.status_indicator.inline_message,
            details=None,
            width=10_000,
            show_interrupt_hint=self.status_indicator.show_interrupt_hint,
            animations_enabled=False,
        )
        return strip_ansi(lines[0]) if lines else None

    def render_lines(self, width: int) -> list[str]:
        if self.request_input_overlay is not None:
            return render_request_input_overlay(
                state=self.request_input_overlay,
                value=self.composer.value,
                width=width,
            )
        lines: list[str] = []
        if self.status_indicator is not None:
            lines.extend(
                build_working_status_lines(
                    header=self.status_indicator.header,
                    elapsed_seconds=self.status_indicator.resolved_elapsed_seconds(),
                    inline_message=self.status_indicator.inline_message,
                    details=self.status_indicator.details,
                    width=width,
                    show_interrupt_hint=self.status_indicator.show_interrupt_hint,
                    animations_enabled=self.status_indicator.animations_enabled,
                )
            )
            lines.append("")
        lines.extend(
            render_composer_surface(
                value=self.composer.value,
                placeholder=self.composer.placeholder,
                width=width,
                content_inset=self.composer.content_inset,
            )
        )
        lines.extend(
            render_footer_lines(
                width=width,
                left_hint=self.footer.left_hint,
                right_status=self.footer.right_status,
                composer_has_draft=bool(self.composer.value.strip()),
                is_task_running=self.footer.is_task_running,
                status_line=self.footer.status_line,
            )
        )
        return lines

    def desired_height(self, width: int) -> int:
        return len(self.render_lines(width))

    def cursor_pos(self, *, area_y: int, rendered_lines: list[str]) -> tuple[int, int]:
        if self.request_input_overlay is not None:
            width = max(1, max((len(strip_ansi(line)) for line in rendered_lines), default=1))
            return request_input_overlay_cursor_pos(
                area_y=area_y,
                state=self.request_input_overlay,
                value=self.composer.value,
                width=width,
            )
        status_height = 0
        if self.status_indicator is not None:
            status_height = len(
                build_working_status_lines(
                    header=self.status_indicator.header,
                    elapsed_seconds=self.status_indicator.resolved_elapsed_seconds(),
                    inline_message=self.status_indicator.inline_message,
                    details=self.status_indicator.details,
                    width=10_000,
                    show_interrupt_hint=self.status_indicator.show_interrupt_hint,
                    animations_enabled=False,
                )
            ) + 1
        return composer_cursor_pos(
            area_y=area_y + status_height,
            value=self.composer.value,
            content_inset=self.composer.content_inset,
        )
