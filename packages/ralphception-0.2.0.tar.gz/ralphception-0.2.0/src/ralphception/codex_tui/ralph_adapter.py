"""Translate Ralphception runtime events into Codex-style chat widget state."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from time import monotonic

from ralphception.codex.config import load_codex_runtime_settings
from ralphception.runtime.frontends import (
    ArtifactWriteEvent,
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BackgroundWaitBeginEvent,
    BackgroundWaitEndEvent,
    BackgroundWaitUpdateEvent,
    BlockerPromptEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    CurrentBlockerStateEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FailureSummaryEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    MilestoneTranscriptLineEvent,
    PlanUpdatedEvent,
    RequestUserInputRequestedEvent,
    RequestUserInputResolvedEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    ReviewRequestedEvent,
    ReviewResolvedEvent,
    RuntimeStatusUpdatedEvent,
    RuntimeStep,
)
from ralphception.tui.path_labels import normalize_directory_label
from ralphception.version import resolve_cli_version

from .bottom_pane import BottomPane, ComposerState, FooterState, StatusIndicatorState
from .chatwidget import ActiveAssistantCell, ActiveCommandCell, ActiveWaitingCell, ChatWidget
from .history_cell import (
    AssistantHistoryCell,
    CommandHistoryCell,
    FinalMessageSeparator,
    HistoryCell,
    StartupShellHistoryCell,
    SystemHistoryCell,
    TranscriptOnlyHistoryCell,
    UserHistoryCell,
    is_internal_skill_command,
)
from .request_input_overlay import RequestInputOverlayState
from .status import (
    ANSWER_PLACEHOLDER,
    DEFAULT_CONTEXT_STATUS,
    DEFAULT_HEADER_MODEL_LABEL,
    DEFAULT_MODEL_LABEL,
    REPLY_FOOTER_HINT,
    STARTUP_NOTICE_LINES,
    build_header_model_label,
    build_status_line,
    pick_starter_placeholder,
    render_session_header_card,
)

_WAITING_FOR_REPLY = "Waiting for your response"


def _humanize_stage_message(stage_kind: str | None) -> str:
    if stage_kind == "spec":
        return "Writing the PRD"
    if stage_kind == "plan":
        return "Preparing the execution plan"
    if stage_kind == "execute":
        return "Executing the loop plan"
    if stage_kind == "merge":
        return "Consolidating loop results"
    if stage_kind == "audit":
        return "Auditing the merged result"
    return "Working"


@dataclass(slots=True)
class RalphAdapter:
    """Owns committed history, one live active cell, and bottom-pane status."""

    repo_root: Path
    animations_enabled: bool = False
    chatwidget: ChatWidget = field(init=False)
    _pending_history_cells: list[HistoryCell] = field(default_factory=list)
    _seen_prompt_questions: dict[str, str] = field(default_factory=dict)
    _last_prompt_text: str | None = None
    _assistant_item_id: str | None = None
    _command_item_id: str | None = None
    _command_output: tuple[str, ...] = ()
    _command_suppressed: bool = False
    _current_blocker: str | None = None
    _current_waiting: str | None = None
    _current_loop: str | None = None
    _current_plan_node: str | None = None
    _current_task: str | None = None
    _live_status: str | None = None
    _idle_placeholder: str = field(init=False)
    _idle_footer_status_line: str = field(init=False)
    _busy_started_at: float | None = None
    _startup_shell_flushed: bool = field(default=False, init=False)
    _had_work_activity: bool = field(default=False, init=False)
    _header_model_label: str = field(init=False)
    _directory_label: str = field(init=False)
    _cli_version: str = field(init=False)
    _transient_submit_waiting: bool = field(default=False, init=False)

    def __post_init__(self) -> None:
        try:
            settings = load_codex_runtime_settings()
            footer_model_label = " ".join(
                part for part in (settings.model, settings.reasoning_effort, settings.service_tier) if part
            )
            header_model_label = build_header_model_label(
                model=settings.model,
                reasoning_effort=settings.reasoning_effort,
                service_tier=settings.service_tier,
            )
        except Exception:
            footer_model_label = DEFAULT_MODEL_LABEL
            header_model_label = DEFAULT_HEADER_MODEL_LABEL
        directory_label = normalize_directory_label(str(self.repo_root))
        cli_version = resolve_cli_version(self.repo_root)
        self._idle_placeholder = pick_starter_placeholder()
        self._idle_footer_status_line = build_status_line(
            model_label=footer_model_label,
            directory_label=str(self.repo_root),
        )
        self._header_model_label = header_model_label
        self._directory_label = directory_label
        self._cli_version = cli_version
        self.chatwidget = ChatWidget(
            header_builder=lambda width: [
                "",
                *render_session_header_card(
                    version=cli_version,
                    directory_label=directory_label,
                    model_label=header_model_label,
                    max_width=max(1, width),
                ),
            ],
            notice_lines=STARTUP_NOTICE_LINES,
            bottom_pane=BottomPane(
                composer=ComposerState(value="", placeholder=self._idle_placeholder),
                footer=FooterState(
                    left_hint="? for shortcuts",
                    right_status=DEFAULT_CONTEXT_STATUS,
                    model_label=footer_model_label,
                    status_line=None,
                    is_task_running=False,
                ),
            )
        )

    def set_composer_value(self, value: str) -> None:
        self.chatwidget.bottom_pane.composer = ComposerState(
            value=value,
            placeholder=self.chatwidget.bottom_pane.composer.placeholder,
            content_inset=self.chatwidget.bottom_pane.composer.content_inset,
        )

    def emit_startup_shell_history(self) -> None:
        self._flush_startup_shell()

    def build_loading_chatwidget(self) -> ChatWidget:
        directory_label = normalize_directory_label(str(self.repo_root))
        return ChatWidget(
            header_builder=lambda width: [
                "",
                *render_session_header_card(
                    version=resolve_cli_version(self.repo_root),
                    directory_label=directory_label,
                    model_label="loading",
                    max_width=max(1, width),
                ),
            ],
            notice_lines=(),
            bottom_pane=self.chatwidget.bottom_pane,
        )

    def build_loading_shell_history_cell(self) -> StartupShellHistoryCell:
        return StartupShellHistoryCell(
            version=self._cli_version,
            directory_label=self._directory_label,
            model_label="loading",
        )

    def commit_user_message(self, text: str) -> None:
        self._flush_startup_shell()
        self._had_work_activity = False
        self._commit(UserHistoryCell(text))
        self.set_composer_value("")

    def begin_submit_waiting(self, summary: str) -> None:
        self._current_blocker = None
        self._current_waiting = summary
        self._transient_submit_waiting = True
        self.chatwidget.active_cell = None
        self.set_composer_value("")
        self._refresh_waiting_line()

    def apply_event(self, event: FrontendEvent) -> None:
        if self._transient_submit_waiting:
            self._current_waiting = None
            self._transient_submit_waiting = False
        if isinstance(event, AssistantDeltaEvent):
            sanitized_text = _sanitize_assistant_message(event.text)
            if sanitized_text is None:
                if event.item_id == self._assistant_item_id:
                    self.chatwidget.active_cell = None
                    self._assistant_item_id = None
                return
            self._assistant_item_id = event.item_id
            self.chatwidget.active_cell = ActiveAssistantCell(sanitized_text)
            return
        if isinstance(event, AssistantFinalEvent):
            sanitized_text = _sanitize_assistant_message(event.text)
            if sanitized_text is None:
                if event.item_id is None or event.item_id == self._assistant_item_id:
                    self.chatwidget.active_cell = None
                    self._assistant_item_id = None
                return
            if self._had_work_activity and sanitized_text.strip():
                self._commit(FinalMessageSeparator())
                self._had_work_activity = False
            self._commit(AssistantHistoryCell(sanitized_text))
            if event.item_id is None or event.item_id == self._assistant_item_id:
                self.chatwidget.active_cell = None
                self._assistant_item_id = None
            return
        if isinstance(event, (ReasoningSummaryDeltaEvent, ReasoningSectionBreakEvent, ReasoningFinalEvent)):
            return
        if isinstance(event, CommandBeginEvent):
            self._command_item_id = event.item_id
            self._command_output = ()
            self._command_suppressed = is_internal_skill_command(event.command)
            if self._command_suppressed:
                self.chatwidget.active_cell = None
                return
            self.chatwidget.active_cell = ActiveCommandCell(event.command, ())
            return
        if isinstance(event, CommandOutputDeltaEvent):
            if self._command_item_id is not None and event.item_id != self._command_item_id:
                return
            if self._command_suppressed:
                return
            self._command_output = (*self._command_output, *self._split_output(event.text))
            if isinstance(self.chatwidget.active_cell, ActiveCommandCell):
                self.chatwidget.active_cell = ActiveCommandCell(
                    self.chatwidget.active_cell.command,
                    self._command_output,
                )
            return
        if isinstance(event, CommandEndEvent):
            if self._command_suppressed:
                self.chatwidget.active_cell = None
                self._command_item_id = None
                self._command_output = ()
                self._command_suppressed = False
                return
            output = self._command_output
            self._had_work_activity = True
            self._commit(CommandHistoryCell(command=event.command, output=output, status=self._command_status(event)))
            self.chatwidget.active_cell = None
            self._command_item_id = None
            self._command_output = ()
            self._command_suppressed = False
            return
        if isinstance(event, BackgroundWaitBeginEvent):
            self._current_waiting = event.summary
            self.chatwidget.active_cell = ActiveWaitingCell(event.summary)
            self._refresh_waiting_line()
            return
        if isinstance(event, BackgroundWaitUpdateEvent):
            self._current_waiting = event.summary
            self.chatwidget.active_cell = ActiveWaitingCell(event.summary)
            self._refresh_waiting_line()
            return
        if isinstance(event, BackgroundWaitEndEvent):
            self._current_waiting = None
            if isinstance(self.chatwidget.active_cell, ActiveWaitingCell):
                self.chatwidget.active_cell = None
            self._refresh_waiting_line()
            return
        if isinstance(event, CurrentWaitingStateEvent):
            self._current_waiting = None if event.cleared else event.label
            if self._current_waiting and not isinstance(self.chatwidget.active_cell, ActiveCommandCell):
                self.chatwidget.active_cell = ActiveWaitingCell(self._current_waiting)
            elif self._current_waiting is None and isinstance(self.chatwidget.active_cell, ActiveWaitingCell):
                self.chatwidget.active_cell = None
            self._refresh_waiting_line()
            return
        if isinstance(event, CurrentBlockerStateEvent):
            self._current_blocker = None if event.cleared else _WAITING_FOR_REPLY
            if event.cleared:
                self._restore_idle_composer()
            else:
                self.chatwidget.bottom_pane.composer = ComposerState(
                    value=self.chatwidget.bottom_pane.composer.value,
                    placeholder=ANSWER_PLACEHOLDER,
                    content_inset=2,
                )
                if self.chatwidget.bottom_pane.request_input_overlay is None:
                    self.chatwidget.bottom_pane.request_input_overlay = RequestInputOverlayState(question="")
                self.chatwidget.bottom_pane.footer = FooterState(
                    left_hint=REPLY_FOOTER_HINT,
                    right_status="",
                    model_label=self.chatwidget.bottom_pane.footer.model_label,
                    is_task_running=False,
                )
            self._refresh_waiting_line()
            return
        if isinstance(event, CurrentLoopLabelEvent):
            self._current_loop = None if event.cleared else event.label
            self._refresh_waiting_line()
            return
        if isinstance(event, CurrentPlanNodeLabelEvent):
            self._current_plan_node = None if event.cleared else event.label
            self._refresh_waiting_line()
            return
        if isinstance(event, CurrentTaskLabelEvent):
            self._current_task = None if event.cleared else event.label
            self._refresh_waiting_line()
            return
        if isinstance(event, LiveStatusEvent):
            self._live_status = event.text
            self._refresh_waiting_line()
            return
        if isinstance(event, RuntimeStatusUpdatedEvent):
            self._live_status = event.message
            self._refresh_waiting_line()
            return
        if isinstance(event, PlanUpdatedEvent):
            self._current_plan_node = event.active_step
            self._commit_system_message(event.active_step)
            self._refresh_waiting_line()
            return
        if isinstance(event, BlockerPromptEvent):
            self._commit_prompt(event.prompt_id, event.question)
            return
        if isinstance(event, RequestUserInputRequestedEvent):
            self._commit_prompt(event.prompt_id, event.question)
            return
        if isinstance(event, RequestUserInputResolvedEvent):
            self._current_blocker = None
            self._last_prompt_text = None
            self._restore_idle_composer()
            self._refresh_waiting_line()
            return
        if isinstance(event, ReviewRequestedEvent):
            self._commit_prompt(f"review:{event.run_id}:{event.review_kind}", event.summary_text)
            return
        if isinstance(event, ReviewResolvedEvent):
            self._current_blocker = None
            self._last_prompt_text = None
            self._restore_idle_composer()
            self._commit_system_message(f"Review resolved: {event.review_kind} -> {event.resolution}")
            self._refresh_waiting_line()
            return
        if isinstance(event, (ArtifactWriteEvent, LoopLaunchEvent, LoopCompletionEvent, MilestoneTranscriptLineEvent)):
            self._commit_system_message(event.message)
            if isinstance(event, (LoopLaunchEvent, LoopCompletionEvent)):
                self._current_loop = event.loop_label
                self._refresh_waiting_line()
            return
        if isinstance(event, FailureSummaryEvent):
            self._commit_system_message(event.summary)
            return
        if event.kind == "stage.started":
            self._commit_system_message(_humanize_stage_message(event.stage_kind))
            return
        if event.kind in {"turn.started", "turn.completed"}:
            return
        if event.message.startswith("Child run created: "):
            return
        if event.message:
            self._commit_system_message(event.message)

    def emit_status(self, step: RuntimeStep) -> None:
        self._live_status = f"Runtime: {step.kind}"
        self._refresh_waiting_line()

    def finish(self, step: RuntimeStep) -> None:
        self._live_status = None
        self._current_waiting = None
        self._current_blocker = None
        self._current_loop = None
        self._current_plan_node = None
        self._current_task = None
        self.chatwidget.active_cell = None
        self._restore_idle_composer()
        self._refresh_waiting_line()
        self._commit(SystemHistoryCell(f"Runtime: {step.kind}"))

    def drain_pending_history_cells(self) -> list[HistoryCell]:
        cells = list(self._pending_history_cells)
        self._pending_history_cells.clear()
        return cells

    def drain_pending_history_lines(self, *, width: int) -> list[str]:
        lines: list[str] = []
        for cell in self.drain_pending_history_cells():
            lines.extend(cell.transcript_lines(width))
        return lines

    def _commit_prompt(self, prompt_id: str, question: str) -> None:
        previous_question = self._seen_prompt_questions.get(prompt_id)
        if question != self._last_prompt_text and question != previous_question:
            self._seen_prompt_questions[prompt_id] = question
            self._last_prompt_text = question
            self._pending_history_cells.append(TranscriptOnlyHistoryCell(question))
        self._current_blocker = _WAITING_FOR_REPLY
        self.chatwidget.bottom_pane.composer = ComposerState(
            value=self.chatwidget.bottom_pane.composer.value,
            placeholder=ANSWER_PLACEHOLDER,
            content_inset=2,
        )
        self.chatwidget.bottom_pane.request_input_overlay = RequestInputOverlayState(question=question)
        self.chatwidget.bottom_pane.footer = FooterState(
            left_hint=REPLY_FOOTER_HINT,
            right_status="",
            model_label=self.chatwidget.bottom_pane.footer.model_label,
            status_line=None,
            is_task_running=False,
        )
        self._refresh_waiting_line()

    def _commit(self, cell: HistoryCell) -> None:
        self._flush_startup_shell()
        self.chatwidget.committed_cells.append(cell)
        self._pending_history_cells.append(cell)

    def _commit_system_message(self, message: str) -> None:
        sanitized = _sanitize_system_message(message)
        if sanitized is None:
            return
        self._commit(SystemHistoryCell(sanitized))

    def _flush_startup_shell(self) -> None:
        if self._startup_shell_flushed:
            return
        if self.chatwidget.header_builder is None and not self.chatwidget.header_lines and not self.chatwidget.notice_lines:
            self._startup_shell_flushed = True
            return
        startup_cell = StartupShellHistoryCell(
            version=self._cli_version,
            directory_label=self._directory_label,
            model_label=self._header_model_label,
            notice_lines=self.chatwidget.notice_lines,
        )
        self.chatwidget.committed_cells.append(startup_cell)
        self._pending_history_cells.append(startup_cell)
        self.chatwidget.header_builder = None
        self.chatwidget.header_lines = ()
        self.chatwidget.notice_lines = ()
        self._startup_shell_flushed = True

    def _refresh_waiting_line(self) -> None:
        if self._current_blocker:
            self.chatwidget.bottom_pane.status_indicator = None
            return

        inline_message = (
            self._current_waiting
            or self._current_loop
            or self._current_plan_node
            or self._current_task
            or self._live_status
        )
        if inline_message:
            self.chatwidget.bottom_pane.request_input_overlay = None
            if self._busy_started_at is None:
                self._busy_started_at = monotonic()
            self.chatwidget.bottom_pane.status_indicator = StatusIndicatorState(
                header="Working",
                inline_message=inline_message,
                started_at=self._busy_started_at,
                animations_enabled=self.animations_enabled,
            )
            self.chatwidget.bottom_pane.composer = ComposerState(
                value=self.chatwidget.bottom_pane.composer.value,
                placeholder=self._idle_placeholder,
                content_inset=0,
            )
            self.chatwidget.bottom_pane.footer = FooterState(
                left_hint="? for shortcuts",
                right_status=self.chatwidget.bottom_pane.footer.right_status,
                model_label=self.chatwidget.bottom_pane.footer.model_label,
                status_line=self._idle_footer_status_line,
                is_task_running=True,
            )
            return
        self.chatwidget.bottom_pane.status_indicator = None
        self._busy_started_at = None
        self._restore_idle_composer()

    def _restore_idle_composer(self) -> None:
        self.chatwidget.bottom_pane.composer = ComposerState(
            value=self.chatwidget.bottom_pane.composer.value,
            placeholder=self._idle_placeholder,
            content_inset=0,
        )
        self.chatwidget.bottom_pane.request_input_overlay = None
        self.chatwidget.bottom_pane.footer = FooterState(
            left_hint="? for shortcuts",
            right_status=DEFAULT_CONTEXT_STATUS,
            model_label=self.chatwidget.bottom_pane.footer.model_label,
            status_line=self._idle_footer_status_line,
            is_task_running=False,
        )

    @staticmethod
    def _split_output(text: str) -> tuple[str, ...]:
        segments = text.splitlines()
        if text.endswith("\n"):
            segments.append("")
        return tuple(segments)

    @staticmethod
    def _command_status(event: CommandEndEvent) -> str | None:
        if event.exit_code is not None:
            return f"exit {event.exit_code}"
        return event.status


def _sanitize_system_message(message: str) -> str | None:
    lowered = _normalized_skill_meta_prefix(message)
    if lowered.startswith("using the ") and " skill " in lowered:
        return None
    if lowered.startswith("using ralph-"):
        return None
    return message


def _sanitize_assistant_message(message: str) -> str | None:
    if _normalized_skill_meta_prefix(message).startswith("using ralph-"):
        return None
    return message


def _normalized_skill_meta_prefix(message: str) -> str:
    collapsed = " ".join(message.split())
    normalized = collapsed.lstrip("•*- ").strip()
    for prefix in ("agent delta:", "agent:"):
        if normalized.lower().startswith(prefix):
            normalized = normalized[len(prefix) :].lstrip("•*- ").strip()
            break
    return normalized.lower()
