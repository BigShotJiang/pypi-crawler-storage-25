"""Compatibility wrapper over low-level styled text helpers."""

from ralphception.tui_core.text import (
    Style,
    StyledLine,
    StyledSpan,
    _surface_terminal_background,
    join_spans,
    pad_styled_line,
    plain_line,
    render_styled_line,
    reset_surface_theme,
    set_surface_terminal_background,
    strip_ansi,
    trim_ansi_text,
    trim_styled_line,
    trim_styled_line_with_ellipsis,
    user_surface_style,
    visible_width,
)

__all__ = [
    "Style",
    "StyledLine",
    "StyledSpan",
    "_surface_terminal_background",
    "join_spans",
    "pad_styled_line",
    "plain_line",
    "render_styled_line",
    "reset_surface_theme",
    "set_surface_terminal_background",
    "strip_ansi",
    "trim_ansi_text",
    "trim_styled_line",
    "trim_styled_line_with_ellipsis",
    "user_surface_style",
    "visible_width",
]
