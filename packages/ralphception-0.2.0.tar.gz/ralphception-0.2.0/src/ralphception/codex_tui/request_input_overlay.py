"""Codex-style request-user-input overlay primitives."""

from __future__ import annotations

from dataclasses import dataclass
import textwrap

from ralphception.tui_core.composer import composer_cursor_pos, render_composer_surface

from .styled_text import Style, StyledSpan, join_spans, render_styled_line
from .status import ANSWER_PLACEHOLDER, REPLY_FOOTER_HINT, render_footer_lines

_OVERLAY_PROGRESS_LABEL = "Question 1/1 (1 unanswered)"
_OVERLAY_INSET = 2
_OVERLAY_FOOTER_SPACERS = 2


@dataclass(frozen=True, slots=True)
class RequestInputOverlayState:
    question: str
    progress_label: str = _OVERLAY_PROGRESS_LABEL
    placeholder: str = ANSWER_PLACEHOLDER
    footer_hint: str = REPLY_FOOTER_HINT
    content_inset: int = _OVERLAY_INSET


def _wrap_overlay_text(text: str, *, width: int, style: Style | None = None) -> list[str]:
    prefix = "  "
    wrapped = textwrap.wrap(
        text,
        width=max(1, width - len(prefix)),
        replace_whitespace=False,
        drop_whitespace=True,
        break_long_words=False,
        break_on_hyphens=False,
    ) or [""]
    rendered: list[str] = []
    for line in wrapped:
        styled = join_spans(
            (
                StyledSpan(prefix, style or Style()),
                StyledSpan(line.rstrip(), style or Style()),
            )
        )
        rendered.append(render_styled_line(styled).rstrip())
    return rendered


def _overlay_header_lines(state: RequestInputOverlayState, *, width: int) -> list[str]:
    return [
        *_wrap_overlay_text(state.progress_label, width=width, style=Style(dim=True)),
        *_wrap_overlay_text(
            state.question,
            width=width,
            style=Style(fg="cyan"),
        ),
        "",
    ]


def render_request_input_overlay(
    *,
    state: RequestInputOverlayState,
    value: str,
    width: int,
) -> list[str]:
    lines = _overlay_header_lines(state, width=width)
    lines.extend(
        render_composer_surface(
            value=value,
            placeholder=state.placeholder,
            width=width,
            content_inset=max(_OVERLAY_INSET, state.content_inset),
        )
    )
    lines.extend([""] * _OVERLAY_FOOTER_SPACERS)
    lines.extend(
        render_footer_lines(
            width=width,
            left_hint=state.footer_hint,
            right_status="",
            composer_has_draft=bool(value.strip()),
            is_task_running=False,
            status_line=None,
        )
    )
    return lines


def request_input_overlay_cursor_pos(
    *,
    area_y: int,
    state: RequestInputOverlayState,
    value: str,
    width: int,
) -> tuple[int, int]:
    header_height = len(_overlay_header_lines(state, width=width))
    return composer_cursor_pos(
        area_y=area_y + header_height,
        value=value,
        content_inset=max(_OVERLAY_INSET, state.content_inset),
    )
