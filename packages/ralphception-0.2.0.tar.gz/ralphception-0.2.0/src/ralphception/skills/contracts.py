"""Pydantic contracts for skill invocation and responses."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from ralphception.models.artifacts import ArtifactRef

SkillStatus = Literal["success", "blocked", "needs_approval"]
ExpectedOutputMode = Literal["conversation", "artifact", "task_list", "findings", "summary"]
ArtifactApplyMode = Literal["replace", "append", "structured_patch"]
StructuredPatchOp = Literal["replace_range", "insert_after"]
FindingSeverity = Literal["info", "warning", "error"]


class SkillContractModel(BaseModel):
    """Shared base model configuration for skill contracts."""

    model_config = ConfigDict(extra="forbid")


class SkillInvocation(SkillContractModel):
    run_id: str
    stage_id: str
    goal: str
    current_task_description: str
    target_repo_path: Path
    source_repo_paths: list[Path] = Field(min_length=1)
    relevant_artifact_refs: list[ArtifactRef]
    effective_config_snapshot: dict[str, Any] = Field(min_length=1)
    expected_output_mode: ExpectedOutputMode

    @field_validator("run_id", "stage_id", "goal", "current_task_description")
    @classmethod
    def _require_non_empty_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be empty")
        return value

    @field_validator("target_repo_path")
    @classmethod
    def _require_absolute_target_repo_path(cls, value: Path) -> Path:
        if not value.is_absolute():
            raise ValueError("target_repo_path must be absolute")
        return value

    @field_validator("source_repo_paths")
    @classmethod
    def _require_absolute_source_repo_paths(cls, value: list[Path]) -> list[Path]:
        if any(not path.is_absolute() for path in value):
            raise ValueError("source_repo_paths must contain absolute paths")
        return value


class StructuredPatchOperation(SkillContractModel):
    op: StructuredPatchOp
    start_line: int = Field(ge=1)
    end_line: int = Field(ge=1)
    content: str

    @model_validator(mode="after")
    def _validate_line_ranges(self) -> StructuredPatchOperation:
        if self.op == "replace_range" and self.end_line < self.start_line:
            raise ValueError("replace_range operations require end_line >= start_line")

        if self.op == "insert_after" and self.end_line != self.start_line:
            raise ValueError("insert_after operations require end_line == start_line")

        return self


class SkillArtifactUpdate(SkillContractModel):
    artifact_kind: str
    artifact_path: str
    apply_mode: ArtifactApplyMode
    content: str | None = None
    structured_patch: list[StructuredPatchOperation] | None = None

    @field_validator("artifact_kind", "artifact_path")
    @classmethod
    def _require_target_metadata(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be empty")
        return value

    @model_validator(mode="after")
    def _validate_mode_payload(self) -> SkillArtifactUpdate:
        if self.apply_mode in {"replace", "append"}:
            if self.content is None:
                raise ValueError("replace and append updates require content")
            if self.structured_patch is not None:
                raise ValueError("replace and append updates do not accept structured_patch")
            return self

        if not self.structured_patch:
            raise ValueError("structured_patch updates require structured_patch operations")
        if self.content is not None:
            raise ValueError("structured_patch updates do not accept content")
        return self


class SkillSuggestedNext(SkillContractModel):
    title: str
    instruction: str

    @field_validator("title", "instruction")
    @classmethod
    def _require_non_empty_instruction_fields(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be empty")
        return value


class SkillFinding(SkillContractModel):
    severity: FindingSeverity
    title: str
    detail: str
    artifact_ref: ArtifactRef | None = None

    @field_validator("title", "detail")
    @classmethod
    def _require_non_empty_finding_fields(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be empty")
        return value


class SkillResult(SkillContractModel):
    status: SkillStatus
    artifact_updates: list[SkillArtifactUpdate]
    suggested_next: list[SkillSuggestedNext]
    findings: list[SkillFinding]
    markdown_body: str

    @field_validator("markdown_body")
    @classmethod
    def _require_non_empty_markdown_body(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("markdown_body must not be empty")
        return value
