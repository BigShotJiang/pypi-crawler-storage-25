"""Helpers for embedding canonical bundled skill guidance into runtime prompts."""

from __future__ import annotations

from pathlib import Path

from .registry import SkillRegistry, StableSkillId

BUNDLED_SKILL_DISCLOSURE_RULE = (
    "Do not announce bundled skill guidance in the transcript, command output, or final answer."
)


def load_bundled_skill_guidance(*, repo_root: Path, skill_id: StableSkillId) -> str:
    """Return the canonical bundled skill body for a repo-rooted runtime prompt."""
    return SkillRegistry(repo_root).load(skill_id).markdown_body.strip()

