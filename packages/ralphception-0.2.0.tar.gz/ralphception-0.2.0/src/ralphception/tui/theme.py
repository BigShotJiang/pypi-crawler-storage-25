"""Theme constants for the Codex-style Ralphception TUI."""

HEADER_BORDER = "-" * 62
