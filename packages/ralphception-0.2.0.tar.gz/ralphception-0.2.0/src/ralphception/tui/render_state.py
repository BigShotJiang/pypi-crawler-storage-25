"""Structured shell-state models for the Codex-style Ralphception TUI."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TypeAlias

from ralphception.codex.config import CodexRuntimeSettings, load_codex_runtime_settings
from ralphception.config import RalphceptionConfig, load_or_create_config as load_repo_config
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, TranscriptCell
from ralphception.version import resolve_cli_version


@dataclass(frozen=True, slots=True)
class HeaderCardState:
    """Top-of-shell session header card state."""

    product_name: str
    version: str
    model_name: str
    reasoning_effort: str
    latency_label: str
    directory_label: str
    mission_label: str | None = None


@dataclass(frozen=True, slots=True)
class OverlayState:
    """Blocking bottom-pane overlay state."""

    kind: str
    title: str
    summary: str
    actions: tuple[str, ...] = ()
    options: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class RequestUserInputViewState:
    """Request-user-input view shown in the bottom pane."""

    title: str
    question: str
    options: tuple[str, ...]
    kind: str = field(default="request_user_input", init=False)


@dataclass(frozen=True, slots=True)
class AgentPickerViewState:
    """Active thread/agent picker view."""

    title: str
    active_thread_id: str | None
    rows: tuple[tuple[str, str], ...]
    kind: str = field(default="agent_picker", init=False)


@dataclass(frozen=True, slots=True)
class SlashCommandMatchState:
    """Single slash-command popup row."""

    command: str
    description: str
    match_indices: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class SlashCommandPopupState:
    """Slash-command popup state rendered alongside the composer."""

    query: str
    matches: tuple[SlashCommandMatchState, ...]
    selected_index: int | None = None


BottomPaneViewState: TypeAlias = (
    OverlayState
    | RequestUserInputViewState
    | AgentPickerViewState
)


@dataclass(frozen=True, slots=True)
class ComposerState:
    """Composer/input state for the bottom pane."""

    placeholder: str
    value: str = ""
    input_enabled: bool = True


@dataclass(frozen=True, slots=True)
class FooterState:
    """Structured footer state mirroring Codex's footer inputs."""

    left_hint: str
    model_name: str
    reasoning_effort: str
    latency_label: str
    directory_label: str
    is_task_running: bool = False
    status_line_enabled: bool = False
    status_line_value: str | None = None
    quota_label: str | None = None
    active_thread_label: str | None = None


@dataclass(frozen=True, slots=True)
class StatusIndicatorState:
    """Running-task strip shown above the composer while the agent is busy."""

    header: str = "Working"
    details: str | None = None
    inline_message: str | None = None
    show_interrupt_hint: bool = True
    details_max_lines: int = 3


@dataclass(frozen=True, slots=True)
class TranscriptState:
    """Committed and active transcript state for the chat widget."""

    committed: tuple[TranscriptCell, ...] = ()
    active: ActiveCell | None = None


@dataclass(frozen=True, slots=True)
class BottomPaneState:
    """Bottom pane state: composer, footer, and active views/popups."""

    composer: ComposerState
    footer: FooterState
    startup_prompt_active: bool = False
    startup_source_repos: tuple[str, ...] = ()
    status_indicator: StatusIndicatorState | None = None
    pending_thread_approvals: tuple[str, ...] = ()
    shortcut_overlay_visible: bool = False
    view_stack: tuple[BottomPaneViewState, ...] = ()
    popup: SlashCommandPopupState | None = None
    queued_messages: tuple[str, ...] = ()

    @property
    def active_view(self) -> BottomPaneViewState | None:
        return self.view_stack[-1] if self.view_stack else None


@dataclass(frozen=True, slots=True)
class RenderState:
    """Top-level render state for the shell frame."""

    shell_label: str
    header_card: HeaderCardState
    announcement_rows: tuple[str, ...]
    transcript: TranscriptState
    bottom_pane: BottomPaneState

    @property
    def transcript_rows(self) -> tuple[str, ...]:
        """Compatibility shim for older tests and export paths."""
        return tuple(cell.render_lines() for cell in self.transcript.committed)

    @property
    def active_overlay_kind(self) -> str | None:
        """Backwards-compatible access to the active blocking view kind."""
        active_view = self.bottom_pane.active_view
        return None if active_view is None else active_view.kind

    @property
    def overlay(self) -> OverlayState | None:
        """Compat shim for callers that only understand overlay views."""
        active_view = self.bottom_pane.active_view
        return active_view if isinstance(active_view, OverlayState) else None

    @property
    def composer_placeholder(self) -> str:
        """Compat shim for older callers during the port."""
        return self.bottom_pane.composer.placeholder

    @property
    def footer_status(self) -> str:
        """Compat shim for older callers during the port."""
        parts = [
            self.bottom_pane.footer.model_name,
            self.bottom_pane.footer.reasoning_effort,
            self.bottom_pane.footer.latency_label,
        ]
        context = " ".join(part for part in parts if part)
        metadata = [context, self.bottom_pane.footer.directory_label]
        if self.bottom_pane.footer.active_thread_label:
            metadata.append(self.bottom_pane.footer.active_thread_label)
        if self.bottom_pane.footer.quota_label:
            metadata.append(self.bottom_pane.footer.quota_label)
        return " · ".join(part for part in metadata if part)

    @classmethod
    def idle_preview(
        cls,
        repo_root: Path,
        *,
        config: RalphceptionConfig | None = None,
        codex_settings: CodexRuntimeSettings | None = None,
    ) -> "RenderState":
        _ = config or _load_or_create_config(repo_root)
        resolved_codex_settings = codex_settings or load_codex_runtime_settings()
        directory_label = str(repo_root)
        return cls(
            shell_label="ralphception",
            header_card=HeaderCardState(
                product_name="Ralphception",
                version=resolve_cli_version(repo_root),
                model_name=resolved_codex_settings.model,
                reasoning_effort=resolved_codex_settings.reasoning_effort,
                latency_label=resolved_codex_settings.service_tier,
                directory_label=directory_label,
                mission_label=None,
            ),
            announcement_rows=(),
            transcript=TranscriptState(),
            bottom_pane=BottomPaneState(
                composer=ComposerState(
                    placeholder="Describe the task or ask a question",
                ),
                footer=FooterState(
                    left_hint="? for shortcuts",
                    model_name=resolved_codex_settings.model,
                    reasoning_effort=resolved_codex_settings.reasoning_effort,
                    latency_label=resolved_codex_settings.service_tier,
                    directory_label=directory_label,
                    status_line_enabled=True,
                ),
                view_stack=(),
                popup=None,
            ),
        )


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    return load_repo_config(repo_root)
