"""Request-user-input overlay rendering and widget."""

from __future__ import annotations

from dataclasses import dataclass

from textual.widgets import Static

from ralphception.tui.render_state import RequestUserInputViewState


@dataclass(frozen=True, slots=True)
class RequestUserInputState:
    """Backwards-compatible render-helper state."""

    prompt: str
    options: tuple[str, ...]


class RequestUserInputView(Static):
    """Static widget for request-user-input content in the bottom pane."""

    def __init__(self, state: RequestUserInputViewState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state

    def set_state(self, state: RequestUserInputViewState) -> None:
        self._state = state
        self.update(render_request_user_input(state, width=self._content_width()))

    def on_mount(self) -> None:
        self.update(render_request_user_input(self._state, width=self._content_width()))

    def on_resize(self) -> None:
        self.update(render_request_user_input(self._state, width=self._content_width()))

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def render_request_user_input(
    state: RequestUserInputState | RequestUserInputViewState,
    *,
    width: int,
) -> str:
    """Render a request-user-input overlay."""
    del width
    if isinstance(state, RequestUserInputState):
        rows = [state.prompt]
        rows.extend([f"- {option}" for option in state.options])
        return "\n".join(rows)

    rows = [state.title, state.question]
    rows.extend(f"- {option}" for option in state.options)
    return "\n".join(rows)
