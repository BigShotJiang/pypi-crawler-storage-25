"""Bottom-pane primitives for the Codex-style Ralphception shell."""

from ralphception.tui.bottom_pane.bottom_pane_view import BottomPaneWidget, render_bottom_pane
from ralphception.tui.bottom_pane.chat_composer import ChatComposer, render_chat_composer
from ralphception.tui.bottom_pane.footer import render_footer

__all__ = [
    "BottomPaneWidget",
    "ChatComposer",
    "render_bottom_pane",
    "render_chat_composer",
    "render_footer",
]
