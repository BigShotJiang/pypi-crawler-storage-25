"""Approval overlay renderer for the Codex-style Ralphception shell."""

from __future__ import annotations

from dataclasses import dataclass

from textual.widgets import Static


@dataclass(frozen=True, slots=True)
class ApprovalOverlayState:
    """Blocking approval overlay state."""

    title: str
    summary: str
    actions: tuple[str, ...]


class ApprovalOverlayView(Static):
    """Static widget wrapper for approval-overlay content."""

    def __init__(self, state: ApprovalOverlayState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state

    def set_state(self, state: ApprovalOverlayState) -> None:
        self._state = state
        self.update(_render_approval_overlay_body(state, width=self._content_width()))

    def on_mount(self) -> None:
        self.update(_render_approval_overlay_body(self._state, width=self._content_width()))

    def on_resize(self) -> None:
        self.update(_render_approval_overlay_body(self._state, width=self._content_width()))

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def render_approval_overlay(state: ApprovalOverlayState, *, width: int) -> str:
    """Render an approval overlay as shell text."""
    del width
    action_row = " | ".join(action.title() for action in state.actions)
    lines = [state.title, state.summary]
    if action_row:
        lines.append(action_row)
    return "\n".join(lines) + "\n"


def _render_approval_overlay_body(state: ApprovalOverlayState, *, width: int) -> str:
    del width
    action_row = " | ".join(action.title() for action in state.actions)
    lines = [state.title, state.summary]
    if action_row and len(state.actions) == 1:
        # Single-action review prompts already render a real button below the body.
        # Keeping the body focused on title + summary avoids duplicated action copy.
        action_row = ""
    if action_row:
        lines.append(action_row)
    return "\n".join(line for line in lines if line) + "\n"
