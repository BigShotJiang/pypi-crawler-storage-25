"""Codex-style inline notices for inactive threads waiting on approval."""

from __future__ import annotations

from textwrap import wrap

from textual.widgets import Static


def render_pending_thread_approvals(*, threads: tuple[str, ...], width: int) -> str:
    """Render inactive-thread approval notices like Codex."""
    if not threads or width < 4:
        return ""

    lines: list[str] = []
    content_width = max(1, width - 4)
    for thread in threads[:3]:
        chunks = wrap(
            f"Approval needed in {thread}",
            width=content_width,
            break_long_words=True,
            break_on_hyphens=False,
        ) or [f"Approval needed in {thread}"]
        for index, chunk in enumerate(chunks):
            prefix = "  ! " if index == 0 else "    "
            lines.append(f"{prefix}{chunk}")

    if len(threads) > 3:
        lines.append("    ...")

    lines.append("    /agent to switch threads")
    return "\n".join(lines)


class PendingThreadApprovals(Static):
    """Stateful Textual wrapper for pending-thread approval notices."""

    def __init__(self, *, threads: tuple[str, ...], id: str | None = None) -> None:
        super().__init__("", id=id)
        self._threads = threads

    def on_mount(self) -> None:
        self.update(self._render_text())

    def set_threads(self, threads: tuple[str, ...]) -> None:
        if self._threads == threads:
            return
        self._threads = threads
        self.update(self._render_text())

    def _render_text(self) -> str:
        width = self.size.width if self.size.width > 0 else 80
        return render_pending_thread_approvals(threads=self._threads, width=width)
