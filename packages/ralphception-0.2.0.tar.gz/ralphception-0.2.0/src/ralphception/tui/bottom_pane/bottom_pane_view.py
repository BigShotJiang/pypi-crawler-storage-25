"""Bottom-pane composition for the Codex-style Ralphception shell."""

from __future__ import annotations

from dataclasses import replace

from textual import events
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widgets import Button, Static, TextArea

from ralphception.tui.bottom_pane.approval_overlay import ApprovalOverlayState, ApprovalOverlayView, render_approval_overlay
from ralphception.tui.bottom_pane.chat_composer import ChatComposer, render_chat_composer
from ralphception.tui.bottom_pane.footer import render_footer
from ralphception.tui.bottom_pane.pending_input_preview import (
    PendingInputPreview,
    queued_message_edit_binding_key,
    render_pending_input_preview,
)
from ralphception.tui.bottom_pane.pending_thread_approvals import PendingThreadApprovals, render_pending_thread_approvals
from ralphception.tui.bottom_pane.request_user_input import RequestUserInputView, render_request_user_input
from ralphception.tui.bottom_pane.shortcut_overlay import ShortcutOverlay, render_shortcut_overlay
from ralphception.tui.bottom_pane.slash_commands import (
    SlashCommandPopup,
    match_slash_commands,
    move_slash_command_selection,
    render_slash_command_popup,
    selected_slash_command_match,
)
from ralphception.tui.bottom_pane.status_indicator import StatusIndicator, render_status_indicator
from ralphception.tui.multi_agents import AgentPickerView, render_agent_picker_from_state
from ralphception.tui.render_state import (
    AgentPickerViewState,
    BottomPaneState,
    BottomPaneViewState,
    OverlayState,
    RequestUserInputViewState,
    StatusIndicatorState,
)


def render_bottom_pane(*, state: BottomPaneState, width: int) -> str:
    """Render composer/footer and active views as shell text."""
    primary = _render_primary_surface(state=state, width=width)
    footer = render_footer(
        state.footer,
        width=width,
        composer_has_draft=bool(state.composer.value.strip()),
        view_active=state.active_view is not None,
        popup_active=state.popup is not None,
        shortcut_overlay_active=state.shortcut_overlay_visible,
    )
    if footer:
        return f"{primary}\n{footer}"
    return primary


def _render_primary_surface(*, state: BottomPaneState, width: int) -> str:
    active_view = state.active_view
    if active_view is not None:
        return _render_view_text(active_view, width=width)

    indicator_state = _effective_status_indicator_state(state)
    has_status_or_footer = indicator_state is not None
    has_pending_thread_approvals = bool(state.pending_thread_approvals)
    has_pending_input = bool(state.queued_messages)
    has_inline_previews = has_pending_thread_approvals or has_pending_input
    lines: list[str] = []
    if indicator_state is not None:
        lines.append(
            render_status_indicator(
                indicator_state,
                width=width,
            )
        )
    if has_inline_previews and has_status_or_footer:
        lines.append("")
    if state.pending_thread_approvals:
        lines.append(
            render_pending_thread_approvals(
                threads=state.pending_thread_approvals,
                width=width,
            )
        )
    if has_pending_thread_approvals and has_pending_input:
        lines.append("")
    if state.queued_messages:
        lines.append(
            render_pending_input_preview(
                queued_messages=state.queued_messages,
                width=width,
            )
        )
    if not has_inline_previews and has_status_or_footer:
        lines.append("")
    lines.append(render_chat_composer(state.composer, width=width))
    if state.shortcut_overlay_visible:
        lines.append(render_shortcut_overlay(width=width))
    if state.popup is not None:
        lines.append(render_slash_command_popup(state.popup, width=width))
    return "\n".join(lines)


def _render_view_text(view: BottomPaneViewState, *, width: int) -> str:
    if isinstance(view, OverlayState):
        if view.kind == "approval":
            return render_approval_overlay(
                ApprovalOverlayState(
                    title=view.title,
                    summary=view.summary,
                    actions=view.actions,
                ),
                width=width,
            ).rstrip("\n")
        lines = [view.title, view.summary]
        if view.actions:
            lines.extend(_overlay_action_label(action) for action in view.actions)
        return "\n".join(lines)
    if isinstance(view, RequestUserInputViewState):
        return render_request_user_input(view, width=width)
    if isinstance(view, AgentPickerViewState):
        return render_agent_picker_from_state(view, width=width)
    raise TypeError(f"unsupported bottom-pane view: {type(view)!r}")


class BottomPaneWidget(Vertical):
    """Interactive bottom pane that mirrors Codex's composer and view stack."""

    class SlashCommandSubmitted(Message):
        """Posted when the composer submits a slash command."""

        def __init__(self, command: str) -> None:
            self.command = command
            super().__init__()

    class ComposerSubmitted(Message):
        """Posted when the composer submits a normal message."""

        def __init__(self, text: str) -> None:
            self.text = text
            super().__init__()

    class ComposerQueued(Message):
        """Posted when the composer queues a follow-up while a task is running."""

        def __init__(self, text: str) -> None:
            self.text = text
            super().__init__()

    class ComposerDraftChanged(Message):
        """Posted when the visible local composer draft changes."""

        def __init__(self, text: str) -> None:
            self.text = text
            super().__init__()

    class DismissRequested(Message):
        """Posted when the active picker/view should be dismissed."""

    class InterruptRequested(Message):
        """Posted when Esc should interrupt the active running task."""

    class EditLastQueuedRequested(Message):
        """Posted when the newest queued message should be restored to the composer."""

    def __init__(self, state: BottomPaneState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state
        self._composer_value = state.composer.value
        self._popup_state = state.popup or match_slash_commands(state.composer.value)

    @property
    def active_overlay_kind(self) -> str | None:
        active_view = self._state.active_view
        return None if active_view is None else active_view.kind

    def set_state(self, state: BottomPaneState) -> None:
        previous_state = self._state
        if self.query("#composer-input"):
            current_text = self.query_one("#composer-input", ChatComposer).text
            # Preserve a live draft across recomposition only when the incoming state has
            # not intentionally changed the composer value.
            preserve_local_draft = (
                current_text != previous_state.composer.value
                and state.composer.value == previous_state.composer.value
                and not (state.composer.value == "" and not current_text.strip())
            )
            self._composer_value = current_text if preserve_local_draft else state.composer.value
        else:
            if state.composer.value or not self._composer_value:
                self._composer_value = state.composer.value
        if self._composer_value != state.composer.value:
            state = replace(
                state,
                composer=replace(state.composer, value=self._composer_value),
            )
        next_popup = state.popup or match_slash_commands(
            self._composer_value,
            selected_index=None if self._popup_state is None else self._popup_state.selected_index,
        )
        preserve_shortcut_overlay = (
            self._state.shortcut_overlay_visible
            and not state.shortcut_overlay_visible
            and state.active_view is None
            and next_popup is None
            and not self._composer_value.strip()
        )
        if preserve_shortcut_overlay:
            state = replace(state, shortcut_overlay_visible=True)
        needs_recompose = (
            previous_state.active_view != state.active_view
            or _effective_status_indicator_state(previous_state) != _effective_status_indicator_state(state)
            or previous_state.pending_thread_approvals != state.pending_thread_approvals
            or previous_state.shortcut_overlay_visible != state.shortcut_overlay_visible
            or previous_state.queued_messages != state.queued_messages
            or self._popup_state != next_popup
        )
        self._state = state
        self._popup_state = next_popup
        if needs_recompose:
            self.refresh(recompose=True)
            return
        if self.query("#composer-input"):
            composer = self.query_one("#composer-input", ChatComposer)
            composer.set_state(replace(self._state.composer, value=self._composer_value))
            composer.set_popup_active((self._state.popup or self._popup_state) is not None)
        if self.query("#footer-status"):
            footer_widget = self.query_one("#footer-status", Static)
            self.query_one("#footer-status", Static).update(
                render_footer(
                    self._state.footer,
                    width=footer_widget.size.width if footer_widget.size.width > 0 else self._content_width(),
                    composer_has_draft=bool(self._composer_value.strip()),
                    view_active=self._state.active_view is not None,
                    popup_active=self._state.popup is not None or self._popup_state is not None,
                    shortcut_overlay_active=self._state.shortcut_overlay_visible,
                )
            )
        indicator_state = _effective_status_indicator_state(self._state)
        if self.query("#status-indicator") and indicator_state is not None:
            self.query_one("#status-indicator", StatusIndicator).set_state(indicator_state)
        if self.query("#pending-thread-approvals"):
            self.query_one("#pending-thread-approvals", PendingThreadApprovals).set_threads(
                self._state.pending_thread_approvals
            )

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        if event.text_area.id == "composer-input":
            self._composer_value = event.text_area.text
            self._state = replace(
                self._state,
                composer=replace(self._state.composer, value=self._composer_value),
            )
            if self._state.shortcut_overlay_visible and event.text_area.text.strip():
                self._state = replace(self._state, shortcut_overlay_visible=False)
            self.post_message(self.ComposerDraftChanged(self._composer_value))
            if self._state.active_view is None and self._state.popup is None:
                next_popup = match_slash_commands(
                    event.text_area.text,
                    selected_index=None if self._popup_state is None else self._popup_state.selected_index,
                )
                if next_popup != self._popup_state:
                    self._popup_state = next_popup
                    self.refresh(recompose=True)
                    self.call_after_refresh(self._focus_composer)
                    return
                if self.query("#composer-input"):
                    self.query_one("#composer-input", ChatComposer).set_popup_active(next_popup is not None)

    def on_chat_composer_slash_popup_move_requested(
        self,
        event: ChatComposer.SlashPopupMoveRequested,
    ) -> None:
        popup_state = self._state.popup or self._popup_state
        if popup_state is None:
            return
        self._popup_state = move_slash_command_selection(popup_state, direction=event.direction)
        self.refresh(recompose=True)
        self.call_after_refresh(self._focus_composer)

    def on_chat_composer_slash_popup_complete_requested(
        self,
        event: ChatComposer.SlashPopupCompleteRequested,
    ) -> None:
        del event
        popup_state = self._state.popup or self._popup_state
        if popup_state is None:
            return
        selected_match = selected_slash_command_match(popup_state)
        if selected_match is None:
            return
        self._composer_value = f"/{selected_match.command} "
        self._popup_state = match_slash_commands(
            self._composer_value,
            selected_index=popup_state.selected_index,
        )
        self.refresh(recompose=True)
        self.call_after_refresh(self._focus_composer)

    def on_chat_composer_shortcut_overlay_toggle_requested(
        self,
        event: ChatComposer.ShortcutOverlayToggleRequested,
    ) -> None:
        del event
        if self._state.active_view is not None or (self._state.popup or self._popup_state) is not None:
            return
        self._state = replace(
            self._state,
            shortcut_overlay_visible=not self._state.shortcut_overlay_visible,
        )
        self.refresh(recompose=True)
        self.call_after_refresh(self._focus_composer)

    def on_chat_composer_slash_popup_submit_requested(
        self,
        event: ChatComposer.SlashPopupSubmitRequested,
    ) -> None:
        del event
        popup_state = self._state.popup or self._popup_state
        if popup_state is None:
            return
        selected_match = selected_slash_command_match(popup_state)
        if selected_match is None:
            return
        self._composer_value = ""
        self._popup_state = None
        self.refresh(recompose=True)
        self.call_after_refresh(self._focus_composer)
        self.post_message(self.SlashCommandSubmitted(f"/{selected_match.command}"))

    def on_chat_composer_submitted(self, event: ChatComposer.Submitted) -> None:
        if self._state.active_view is not None:
            return
        value = event.text.strip()
        if not value:
            return
        if value.startswith("/"):
            self._composer_value = ""
            self._state = replace(
                self._state,
                composer=replace(self._state.composer, value=""),
                shortcut_overlay_visible=False,
                popup=None,
            )
            self.refresh(recompose=True)
            self.call_after_refresh(self._focus_composer)
            self.post_message(self.SlashCommandSubmitted(value.lower()))
            return
        if event.queue_requested and self._state.footer.is_task_running:
            updated_messages = (*self._state.queued_messages, value)
            self._composer_value = ""
            self._state = replace(
                self._state,
                composer=replace(self._state.composer, value=""),
                queued_messages=updated_messages,
                shortcut_overlay_visible=False,
            )
            self.refresh(recompose=True)
            self.call_after_refresh(self._focus_composer)
            self.post_message(self.ComposerQueued(value))
            return
        self._composer_value = ""
        self._state = replace(
            self._state,
            composer=replace(self._state.composer, value=""),
            shortcut_overlay_visible=False,
            popup=None,
        )
        self.refresh(recompose=True)
        self.call_after_refresh(self._focus_composer)
        self.post_message(self.ComposerSubmitted(value))

    def on_key(self, event) -> None:
        if (
            event.key == queued_message_edit_binding_key()
            and self._state.active_view is None
            and self._state.queued_messages
        ):
            self.post_message(self.EditLastQueuedRequested())
            event.stop()
            return
        if event.key != "escape":
            return
        active_view = self._state.active_view
        if self._state.shortcut_overlay_visible:
            self._state = replace(self._state, shortcut_overlay_visible=False)
            self.refresh(recompose=True)
            self.call_after_refresh(self._focus_composer)
            event.stop()
            return
        if active_view is None and (self._state.popup is not None or self._popup_state is not None):
            self._popup_state = None
            self.refresh(recompose=True)
            self.call_after_refresh(self._focus_composer)
            event.stop()
            return
        if isinstance(active_view, AgentPickerViewState):
            self.post_message(self.DismissRequested())
            event.stop()
            return
        composer_text = self._composer_value.lstrip()
        is_agent_command = composer_text.splitlines()[0].startswith("/agent") if composer_text else False
        popup_active = self._state.popup is not None or self._popup_state is not None
        if self._state.footer.is_task_running and not is_agent_command and not popup_active:
            self.post_message(self.InterruptRequested())
            event.stop()

    def on_resize(self) -> None:
        self.refresh(recompose=True)

    def _focus_composer(self) -> None:
        if self.query("#composer-input"):
            self.app.set_focus(self.query_one("#composer-input", ChatComposer))

    def compose(self) -> ComposeResult:
        width = self._content_width()
        active_view = self._state.active_view
        if isinstance(active_view, OverlayState) and active_view.kind == "approval":
            yield ApprovalOverlayView(
                ApprovalOverlayState(
                    title=active_view.title,
                    summary=active_view.summary,
                    actions=active_view.actions,
                ),
                id="approval-overlay-view",
            )
            for action in active_view.actions:
                yield OverlayActionButton(action.replace("_", " ").title(), id=f"review-action-{action}")
        elif isinstance(active_view, OverlayState) and active_view.kind in {"launch_resume", "broken_resume"}:
            yield Static(active_view.title, id="launch-title")
            yield Static(active_view.summary, id="launch-summary")
            for action in active_view.actions:
                yield OverlayActionButton(
                    _overlay_action_label(action),
                    id=f"launch-action-{action.replace('_', '-')}",
                )
        elif isinstance(active_view, OverlayState):
            yield Static(active_view.title, id="review-title")
            yield Static(active_view.summary, id="review-summary")
            for action in active_view.actions:
                yield OverlayActionButton(action.replace("_", " ").title(), id=f"conflict-action-{action}")
        elif isinstance(active_view, RequestUserInputViewState):
            yield RequestUserInputView(active_view, id="request-user-input-view")
        elif isinstance(active_view, AgentPickerViewState):
            yield AgentPickerView(active_view, id="agent-picker-view")
        else:
            indicator_state = _effective_status_indicator_state(self._state)
            has_status_or_footer = indicator_state is not None
            has_pending_thread_approvals = bool(self._state.pending_thread_approvals)
            has_pending_input = bool(self._state.queued_messages)
            has_inline_previews = has_pending_thread_approvals or has_pending_input
            if indicator_state is not None:
                yield StatusIndicator(indicator_state, id="status-indicator")
            if has_inline_previews and has_status_or_footer:
                yield Static("", classes="bottom-pane-spacer")
            if self._state.pending_thread_approvals:
                yield PendingThreadApprovals(
                    threads=self._state.pending_thread_approvals,
                    id="pending-thread-approvals",
                )
            if has_pending_thread_approvals and has_pending_input:
                yield Static("", classes="bottom-pane-spacer")
            if self._state.queued_messages:
                yield PendingInputPreview(
                    queued_messages=self._state.queued_messages,
                    id="pending-input-preview",
                )
            if not has_inline_previews and has_status_or_footer:
                yield Static("", classes="bottom-pane-spacer")
            yield ChatComposer(
                replace(self._state.composer, value=self._composer_value),
                popup_active=(self._state.popup or self._popup_state) is not None,
                id="composer-input",
            )
            if self._state.shortcut_overlay_visible:
                yield ShortcutOverlay(
                    render_shortcut_overlay(width=width),
                    id="shortcut-overlay",
                )
            popup_state = self._state.popup or self._popup_state
            if popup_state is not None:
                yield SlashCommandPopup(popup_state, id="slash-command-popup")

        yield Static(
            render_footer(
                self._state.footer,
                width=width,
                composer_has_draft=bool(self._composer_value.strip()),
                view_active=self._state.active_view is not None,
                popup_active=(self._state.popup or self._popup_state) is not None,
                shortcut_overlay_active=self._state.shortcut_overlay_visible,
            ),
            id="footer-status",
        )

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def _effective_status_indicator_state(state: BottomPaneState) -> StatusIndicatorState | None:
    if state.status_indicator is not None:
        return state.status_indicator
    if state.footer.is_task_running and state.active_view is None:
        return StatusIndicatorState()
    return None


def _overlay_action_label(action: str) -> str:
    return action.replace("_", " ").capitalize()


class OverlayActionButton(Button):
    """Keyboard-first overlay button for launch/review/conflict actions."""

    BINDINGS = []
