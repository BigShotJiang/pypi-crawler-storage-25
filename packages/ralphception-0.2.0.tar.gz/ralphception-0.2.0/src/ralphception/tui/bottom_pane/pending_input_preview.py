"""Queued follow-up preview for the Codex-style bottom pane."""

from __future__ import annotations

from collections.abc import Iterable
import os
import textwrap

from textual.widgets import Static

_PREVIEW_LINE_LIMIT = 3
_SECTION_PREFIX = "• "
_ITEM_PREFIX = "  ↳ "
_ITEM_CONTINUATION_PREFIX = "    "
_ELLIPSIS_LINE = "    …"


def queued_message_edit_binding_key() -> str:
    """Return the key string used to edit the newest queued message."""
    terminal_program = (os.environ.get("TERM_PROGRAM") or "").lower()
    if terminal_program in {"apple_terminal", "vscode"} or "warp" in terminal_program:
        return "shift+left"
    return "alt+up"


def queued_message_edit_binding_label() -> str:
    """Return the rendered hint label for the queued-message edit binding."""
    return queued_message_edit_binding_key()


def render_pending_input_preview(
    *,
    queued_messages: tuple[str, ...],
    width: int,
) -> str:
    """Render queued follow-up messages above the composer."""
    if not queued_messages or width < 4:
        return ""

    lines = [_SECTION_PREFIX + "Queued follow-up messages"]
    for message in queued_messages:
        lines.extend(_truncated_preview_lines(message, width=width))
    lines.append(f"    {queued_message_edit_binding_label()} edit last queued message")
    return "\n".join(lines)


def _truncated_preview_lines(message: str, *, width: int) -> list[str]:
    wrapped = _wrap_preview_lines(message, width=width)
    lines = wrapped[:_PREVIEW_LINE_LIMIT]
    if len(wrapped) > _PREVIEW_LINE_LIMIT:
        lines.append(_ELLIPSIS_LINE)
    return lines


def _wrap_preview_lines(message: str, *, width: int) -> list[str]:
    wrapped_lines: list[str] = []
    source_lines: Iterable[str] = message.splitlines() or [message]
    content_width = max(1, width - len(_ITEM_PREFIX))
    continuation_width = max(1, width - len(_ITEM_CONTINUATION_PREFIX))

    for raw_line in source_lines:
        line = raw_line or ""
        initial_parts = textwrap.wrap(
            line,
            width=content_width,
            break_long_words=True,
            break_on_hyphens=False,
        ) or [""]
        for index, part in enumerate(initial_parts):
            if index == 0:
                wrapped_lines.append(f"{_ITEM_PREFIX}{part}")
                continue
            continuation_parts = textwrap.wrap(
                part,
                width=continuation_width,
                break_long_words=True,
                break_on_hyphens=False,
            ) or [""]
            for continuation in continuation_parts:
                wrapped_lines.append(f"{_ITEM_CONTINUATION_PREFIX}{continuation}")
    return wrapped_lines


class PendingInputPreview(Static):
    """Static queued-message preview surface."""

    def __init__(
        self,
        *,
        queued_messages: tuple[str, ...],
        id: str | None = None,
    ) -> None:
        super().__init__("", id=id)
        self._queued_messages = queued_messages

    def on_mount(self) -> None:
        self.update(self._render_text())

    def on_resize(self) -> None:
        self.update(self._render_text())

    def _render_text(self) -> str:
        width = self.size.width if self.size.width > 0 else 80
        return render_pending_input_preview(queued_messages=self._queued_messages, width=width)
