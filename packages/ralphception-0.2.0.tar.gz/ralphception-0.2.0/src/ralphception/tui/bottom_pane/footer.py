"""Footer rendering helpers for the Codex-style Ralphception shell."""

from __future__ import annotations

from ralphception.tui.path_labels import normalize_directory_label
from ralphception.tui.render_state import FooterState


def render_footer(
    state: FooterState,
    *,
    width: int,
    composer_has_draft: bool = False,
    view_active: bool = False,
    popup_active: bool = False,
    shortcut_overlay_active: bool = False,
) -> str:
    """Render the footer from structured state and bottom-pane context."""
    available_width = max(1, width - 1)
    if shortcut_overlay_active:
        return ""
    passive = _passive_footer_status_line(
        state,
        composer_has_draft=composer_has_draft,
        view_active=view_active,
        popup_active=popup_active,
    )
    if passive is not None:
        return _truncate(passive, available_width)

    left, right = _instructional_footer_parts(
        state,
        composer_has_draft=composer_has_draft,
        view_active=view_active,
    )
    if right:
        max_right_width = max(1, available_width - len(left) - 1)
        if max_right_width <= 0:
            return _truncate(left, available_width)
        right = _truncate(right, max_right_width)
        gap = max(1, available_width - len(left) - len(right))
        return f"{left}{' ' * gap}{right}"
    return _truncate(left, available_width)


def _instructional_footer_parts(
    state: FooterState,
    *,
    composer_has_draft: bool,
    view_active: bool,
) -> tuple[str, str]:
    if view_active:
        return state.left_hint, ""

    if composer_has_draft and state.is_task_running:
        return "tab to queue message", _contextual_right_summary(state)

    if state.left_hint:
        return state.left_hint, _contextual_right_summary(state)

    return "", _contextual_right_summary(state)


def _passive_footer_status_line(
    state: FooterState,
    *,
    composer_has_draft: bool,
    view_active: bool,
    popup_active: bool,
) -> str | None:
    if view_active or popup_active:
        return None
    if composer_has_draft and state.is_task_running:
        return None
    if state.is_task_running and state.left_hint not in {"", "? for shortcuts"}:
        return None

    base_line = _status_line_value(state)
    if state.active_thread_label:
        if base_line:
            return f"{base_line} · {state.active_thread_label}"
        return state.active_thread_label
    return base_line


def _status_line_value(state: FooterState) -> str | None:
    if not state.status_line_enabled:
        return None
    if state.status_line_value:
        return state.status_line_value

    model_bits = " ".join(
        bit for bit in (state.model_name, state.reasoning_effort, state.latency_label) if bit
    ).strip()
    line_parts = [model_bits]
    if state.quota_label:
        line_parts.append(state.quota_label)
    if state.directory_label:
        line_parts.append(normalize_directory_label(state.directory_label))
    value = " · ".join(part for part in line_parts if part)
    return value or None


def _contextual_right_summary(state: FooterState) -> str:
    if state.status_line_value and state.quota_label:
        return f"{state.status_line_value} · {state.quota_label}"
    if state.status_line_value:
        return state.status_line_value
    if state.quota_label:
        return state.quota_label

    passive = _status_line_value(state)
    if passive:
        return passive

    parts = [
        " ".join(
            bit for bit in (state.model_name, state.reasoning_effort, state.latency_label) if bit
        ).strip(),
        normalize_directory_label(state.directory_label),
    ]
    return " · ".join(part for part in parts if part)


def _truncate(text: str, width: int) -> str:
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width == 1:
        return text[:1]
    return f"{text[: width - 1]}…"
