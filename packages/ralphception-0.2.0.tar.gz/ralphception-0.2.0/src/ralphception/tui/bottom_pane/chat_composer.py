"""Chat composer rendering and widget helpers for the Codex-style shell."""

from __future__ import annotations

from rich.text import Text
from textual import events
from textual.message import Message
from textual.widgets import TextArea

from ralphception.tui.render_state import ComposerState

ChatComposerState = ComposerState


class ChatComposer(TextArea):
    """TextArea-backed composer closer to Codex's multiline input model."""

    MIN_HEIGHT = 3
    MAX_HEIGHT = 8

    class Submitted(Message):
        """Posted when the composer wants to submit or queue a message."""

        def __init__(self, text: str, *, queue_requested: bool = False) -> None:
            self.text = text
            self.queue_requested = queue_requested
            super().__init__()

    class SlashPopupMoveRequested(Message):
        """Posted when the slash-command popup selection should move."""

        def __init__(self, direction: str) -> None:
            self.direction = direction
            super().__init__()

    class SlashPopupCompleteRequested(Message):
        """Posted when the selected slash-command should complete into the draft."""

    class SlashPopupSubmitRequested(Message):
        """Posted when the selected slash-command should be submitted."""

    class ShortcutOverlayToggleRequested(Message):
        """Posted when `?` should toggle the shortcut overlay instead of inserting text."""

    def __init__(
        self,
        state: ComposerState,
        *,
        popup_active: bool = False,
        id: str | None = None,
    ) -> None:
        super().__init__(self._normalize_blank_draft(state.value), id=id)
        self._placeholder = state.placeholder
        self.disabled = not state.input_enabled
        self._popup_active = popup_active
        self._autosize()
        self._move_cursor_to_end()

    @property
    def placeholder(self) -> str:
        return self._placeholder

    @property
    def value(self) -> str:
        return self.text

    @value.setter
    def value(self, value: str) -> None:
        value = self._normalize_blank_draft(value)
        if value != self.text:
            self.load_text(value)
            self._move_cursor_to_end()
        self._autosize()

    def set_state(self, state: ComposerState) -> None:
        self._placeholder = state.placeholder
        normalized_value = self._normalize_blank_draft(state.value)
        if normalized_value != self.text:
            self.load_text(normalized_value)
            self._move_cursor_to_end()
        self.disabled = not state.input_enabled
        self._autosize()

    def set_popup_active(self, popup_active: bool) -> None:
        self._popup_active = popup_active

    def on_mount(self) -> None:
        self._normalize_blank_draft_in_place()
        self._autosize()
        if not self.disabled:
            self.call_after_refresh(lambda: self.app.set_focus(self))

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        del event
        self._normalize_blank_draft_in_place()
        self._autosize()

    def _move_cursor_to_end(self) -> None:
        lines = self.text.splitlines() or [self.text]
        last_line = lines[-1] if lines else ""
        row = max(0, len(lines) - 1)
        self.cursor_location = (row, len(last_line))

    @staticmethod
    def _normalize_blank_draft(value: str) -> str:
        return "" if value and not value.strip() else value

    def _normalize_blank_draft_in_place(self) -> None:
        normalized = self._normalize_blank_draft(self.text)
        if normalized == self.text:
            return
        self.load_text(normalized)
        self._move_cursor_to_end()

    def get_line(self, line_index: int) -> Text:
        if not self.text.strip() and line_index == 0:
            return Text(self._placeholder, style="dim", end="")
        return super().get_line(line_index)

    def _autosize(self) -> None:
        line_count = max(1, len(self.text.splitlines()) or 1)
        height = min(self.MAX_HEIGHT, max(self.MIN_HEIGHT, line_count + 2))
        self.styles.height = height

    async def _on_key(self, event: events.Key) -> None:
        if (
            (event.character == "?" or event.key == "question_mark")
            and not self.text.strip()
            and not self._popup_active
        ):
            self.post_message(self.ShortcutOverlayToggleRequested())
            event.prevent_default()
            event.stop()
            return
        if self._popup_active:
            if event.key in {"up", "ctrl+p"}:
                self.post_message(self.SlashPopupMoveRequested("up"))
                event.stop()
                return
            if event.key in {"down", "ctrl+n"}:
                self.post_message(self.SlashPopupMoveRequested("down"))
                event.stop()
                return
            if event.key == "tab":
                self.post_message(self.SlashPopupCompleteRequested())
                event.stop()
                return
            if event.key == "enter":
                self.post_message(self.SlashPopupSubmitRequested())
                event.stop()
                return
        if event.key == "enter":
            value = self.text.strip()
            if value:
                self.load_text("")
                self._autosize()
                self._move_cursor_to_end()
                self.post_message(self.Submitted(value))
                event.stop()
            return
        if event.key == "tab":
            value = self.text.strip()
            if value:
                self.load_text("")
                self._autosize()
                self._move_cursor_to_end()
                self.post_message(self.Submitted(value, queue_requested=True))
                event.stop()
            return
        await super()._on_key(event)


def render_chat_composer(state: ComposerState, *, width: int) -> str:
    """Render the composer with a Codex-style prompt prefix."""
    del width
    value = state.value.strip() or state.placeholder
    return f"\u203a {value}"
