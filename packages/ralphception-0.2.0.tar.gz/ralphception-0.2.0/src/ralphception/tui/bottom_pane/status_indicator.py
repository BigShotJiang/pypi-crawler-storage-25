"""Codex-style running status strip rendered above the composer."""

from __future__ import annotations

from textwrap import wrap
from time import monotonic

from textual.widgets import Static

from ralphception.tui.render_state import StatusIndicatorState

_DETAILS_PREFIX = "  └ "
_DETAILS_CONTINUATION = "    "


def fmt_elapsed_compact(elapsed_seconds: int) -> str:
    """Port Codex's compact elapsed formatter."""
    if elapsed_seconds < 60:
        return f"{elapsed_seconds}s"
    if elapsed_seconds < 3600:
        minutes = elapsed_seconds // 60
        seconds = elapsed_seconds % 60
        return f"{minutes}m {seconds:02}s"
    hours = elapsed_seconds // 3600
    minutes = (elapsed_seconds % 3600) // 60
    seconds = elapsed_seconds % 60
    return f"{hours}h {minutes:02}m {seconds:02}s"


def render_status_indicator(
    state: StatusIndicatorState,
    *,
    width: int,
    elapsed_seconds: int = 0,
) -> str:
    """Render a Codex-style running status strip."""
    header = state.header.strip() or "Working"
    elapsed = fmt_elapsed_compact(max(0, elapsed_seconds))
    if state.show_interrupt_hint:
        line = f"{header} ({elapsed} • esc to interrupt)"
    else:
        line = f"{header} ({elapsed})"
    if state.inline_message:
        line = f"{line} · {state.inline_message.strip()}"

    lines = [_truncate(line, width)]
    lines.extend(_wrap_details(state=state, width=width))
    return "\n".join(lines)


def _wrap_details(*, state: StatusIndicatorState, width: int) -> list[str]:
    details = (state.details or "").strip()
    if not details or width <= 0:
        return []

    content_width = max(1, width - len(_DETAILS_PREFIX))
    wrapped = wrap(
        details,
        width=content_width,
        break_long_words=True,
        break_on_hyphens=False,
    )
    if not wrapped:
        return []

    lines: list[str] = []
    for index, chunk in enumerate(wrapped[: state.details_max_lines]):
        prefix = _DETAILS_PREFIX if index == 0 else _DETAILS_CONTINUATION
        if index == state.details_max_lines - 1 and len(wrapped) > state.details_max_lines:
            chunk = _truncate(chunk, content_width)
            if not chunk.endswith("…"):
                chunk = _truncate(f"{chunk}…", content_width)
        lines.append(f"{prefix}{chunk}")
    return lines


def _truncate(text: str, width: int) -> str:
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width == 1:
        return text[:1]
    return f"{text[: width - 1]}…"


class StatusIndicator(Static):
    """Stateful status strip with a local elapsed timer like Codex's widget."""

    def __init__(self, state: StatusIndicatorState, *, id: str | None = None) -> None:
        self._state = state
        self._started_at = monotonic()
        super().__init__("", id=id)

    def on_mount(self) -> None:
        self.update(self._render_text())
        self.set_interval(1.0, self._tick)

    def set_state(self, state: StatusIndicatorState) -> None:
        if self._state != state:
            self._state = state
            self.update(self._render_text())

    def _tick(self) -> None:
        self.update(self._render_text())

    def _render_text(self) -> str:
        width = self.size.width if self.size.width > 0 else 80
        elapsed = int(monotonic() - self._started_at)
        return render_status_indicator(
            self._state,
            width=width,
            elapsed_seconds=elapsed,
        )
