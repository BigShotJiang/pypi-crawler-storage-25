"""Slash-command popup rendering for the Codex-style Ralphception shell."""

from __future__ import annotations

from dataclasses import dataclass
import textwrap
from textual.widgets import Static

from ralphception.tui.render_state import SlashCommandMatchState, SlashCommandPopupState

SlashCommandState = SlashCommandPopupState
SlashCommandMatch = SlashCommandMatchState


@dataclass(frozen=True, slots=True)
class _CommandSpec:
    command: str
    description: str


_SUPPORTED_COMMANDS = (
    _CommandSpec("agent", "switch between active threads"),
    _CommandSpec("model", "show where Ralphception inherits the Codex model"),
    _CommandSpec("resume", "resume the last interrupted Ralphception session"),
    _CommandSpec("source", "add an optional source repository before startup"),
    _CommandSpec("help", "show shell shortcuts and command help"),
)


class SlashCommandPopup(Static):
    """Codex-style slash-command popup shown beneath the composer."""

    def __init__(self, state: SlashCommandPopupState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state

    def set_state(self, state: SlashCommandPopupState) -> None:
        self._state = state
        self.update(render_slash_command_popup(state, width=self._content_width()))

    def on_mount(self) -> None:
        self.update(render_slash_command_popup(self._state, width=self._content_width()))

    def on_resize(self) -> None:
        self.update(render_slash_command_popup(self._state, width=self._content_width()))

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def render_slash_command_popup(state: SlashCommandPopupState, *, width: int) -> str:
    """Render slash-command matches with Codex-style command + description rows."""
    if not state.matches:
        return ""
    command_width = min(
        max(len(match.command) for match in state.matches) + 5,  # selection + slash + padding
        max(10, width // 3),
    )
    lines: list[str] = []
    for index, match in enumerate(state.matches):
        prefix = "\u203a " if index == state.selected_index else "  "
        command = f"/{match.command}"
        padded_command = f"{prefix}{command}".ljust(command_width)
        description_width = max(1, width - len(padded_command) - 1)
        wrapped_description = textwrap.wrap(
            match.description,
            width=description_width,
            break_long_words=False,
            break_on_hyphens=False,
        ) or [""]
        lines.append(f"{padded_command} {wrapped_description[0]}".rstrip())
        for continuation in wrapped_description[1:]:
            lines.append(f"{' ' * len(padded_command)} {continuation}".rstrip())
    return "\n".join(lines)


def match_slash_commands(
    query: str,
    *,
    selected_index: int | None = None,
) -> SlashCommandPopupState | None:
    """Return popup matches for the current slash-command query."""
    first_line = query.splitlines()[0] if query else ""
    if not first_line.startswith("/"):
        return None

    after_slash = first_line[1:]
    if not after_slash:
        return SlashCommandPopupState(
            query=query,
            matches=tuple(
                SlashCommandMatch(command=spec.command, description=spec.description)
                for spec in _SUPPORTED_COMMANDS
            ),
            selected_index=0 if _SUPPORTED_COMMANDS else None,
        )

    if after_slash[:1].isspace():
        return None

    token = after_slash.lstrip().split()[0]
    if not token:
        return None
    if after_slash.strip() != token:
        return None

    normalized = token.lower()
    exact: list[SlashCommandMatch] = []
    prefix: list[SlashCommandMatch] = []
    fuzzy: list[SlashCommandMatch] = []

    for spec in _SUPPORTED_COMMANDS:
        command = spec.command
        command_lower = command.lower()
        if command_lower == normalized:
            exact.append(
                SlashCommandMatch(
                    command=command,
                    description=spec.description,
                    match_indices=tuple(range(len(command))),
                )
            )
            continue
        if command_lower.startswith(normalized):
            prefix.append(
                SlashCommandMatch(
                    command=command,
                    description=spec.description,
                    match_indices=tuple(range(len(normalized))),
                )
            )
            continue
        fuzzy_indices = _fuzzy_match_indices(command_lower, normalized)
        if fuzzy_indices is not None:
            fuzzy.append(
                SlashCommandMatch(
                    command=command,
                    description=spec.description,
                    match_indices=fuzzy_indices,
                )
            )

    matches = tuple([*exact, *prefix, *fuzzy])
    if not matches:
        return None
    clamped_index = _clamp_selected_index(selected_index, len(matches))
    return SlashCommandPopupState(
        query=query,
        matches=matches,
        selected_index=clamped_index,
    )


def move_slash_command_selection(
    state: SlashCommandPopupState,
    *,
    direction: str,
) -> SlashCommandPopupState:
    """Move the popup selection with Codex-style wraparound semantics."""
    if not state.matches:
        return state
    selected_index = _clamp_selected_index(state.selected_index, len(state.matches))
    if selected_index is None:
        selected_index = 0
    if direction == "up":
        next_index = selected_index - 1 if selected_index > 0 else len(state.matches) - 1
    elif direction == "down":
        next_index = selected_index + 1 if selected_index + 1 < len(state.matches) else 0
    else:
        raise ValueError(f"unsupported slash-command direction: {direction}")
    return SlashCommandPopupState(
        query=state.query,
        matches=state.matches,
        selected_index=next_index,
    )


def selected_slash_command_match(state: SlashCommandPopupState) -> SlashCommandMatchState | None:
    """Return the currently selected popup match, if any."""
    if not state.matches:
        return None
    selected_index = _clamp_selected_index(state.selected_index, len(state.matches))
    if selected_index is None:
        return None
    return state.matches[selected_index]


def _fuzzy_match_indices(command: str, query: str) -> tuple[int, ...] | None:
    indices: list[int] = []
    command_index = 0
    for query_char in query:
        found = False
        while command_index < len(command):
            if command[command_index] == query_char:
                indices.append(command_index)
                command_index += 1
                found = True
                break
            command_index += 1
        if not found:
            return None
    return tuple(indices)


def _clamp_selected_index(selected_index: int | None, match_count: int) -> int | None:
    if match_count <= 0:
        return None
    if selected_index is None:
        return 0
    return min(max(selected_index, 0), match_count - 1)
