"""Codex-style list-selection popup primitives."""

from __future__ import annotations

from dataclasses import dataclass
from textual import events
from textual.message import Message
from textual.widgets import Static


@dataclass(frozen=True, slots=True)
class ListSelectionRowState:
    """Single selectable row in a list-selection popup."""

    row_id: str
    label: str
    description: str | None = None
    is_current: bool = False


@dataclass(frozen=True, slots=True)
class ListSelectionState:
    """Generic list-selection popup state with local selection."""

    title: str
    rows: tuple[ListSelectionRowState, ...]
    subtitle: str | None = None
    selected_index: int = 0


class ListSelectionView(Static):
    """Interactive selection list with Codex-style keyboard traversal."""

    can_focus = True
    BINDINGS = [
        ("up", "cursor_up", "Previous"),
        ("down", "cursor_down", "Next"),
        ("enter", "select_current", "Select"),
        ("escape", "dismiss", "Close"),
    ]

    class RowSelected(Message):
        """Posted when the highlighted row is selected."""

        def __init__(self, row_id: str, label: str) -> None:
            self.row_id = row_id
            self.label = label
            super().__init__()

    class DismissRequested(Message):
        """Posted when the selection view should be dismissed."""

    def __init__(self, state: ListSelectionState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state
        self._selected_index = _normalize_selected_index(state.selected_index, len(state.rows))

    @property
    def current_row(self) -> ListSelectionRowState | None:
        if not self._state.rows:
            return None
        return self._state.rows[self._selected_index]

    def set_state(self, state: ListSelectionState) -> None:
        self._state = state
        self._selected_index = _normalize_selected_index(state.selected_index, len(state.rows))
        self.update(self._render_body())

    def on_mount(self) -> None:
        self.update(self._render_body())
        self.call_after_refresh(self._focus_self)

    def action_cursor_up(self) -> None:
        if not self._state.rows:
            return
        self._selected_index = (self._selected_index - 1) % len(self._state.rows)
        self.update(self._render_body())

    def action_cursor_down(self) -> None:
        if not self._state.rows:
            return
        self._selected_index = (self._selected_index + 1) % len(self._state.rows)
        self.update(self._render_body())

    def action_select_current(self) -> None:
        row = self.current_row
        if row is None:
            return
        self.post_message(self.RowSelected(row.row_id, row.label))

    def action_dismiss(self) -> None:
        self.post_message(self.DismissRequested())

    def on_key(self, event: events.Key) -> None:
        if event.key == "escape":
            self.post_message(self.DismissRequested())
            event.stop()

    def _render_state(self) -> ListSelectionState:
        return ListSelectionState(
            title=self._state.title,
            subtitle=self._state.subtitle,
            rows=self._state.rows,
            selected_index=self._selected_index,
        )

    def _render_body(self) -> str:
        width = self.size.width if self.size.width > 0 else 80
        return render_list_selection(self._render_state(), width=width)

    def _focus_self(self) -> None:
        self.app.set_focus(self)


def render_list_selection(state: ListSelectionState, *, width: int) -> str:
    """Render a list-selection popup."""
    del width
    lines = [state.title]
    if state.subtitle:
        lines.append(state.subtitle)
    for index, row in enumerate(state.rows):
        selection_marker = "›" if index == state.selected_index else " "
        current_marker = "• " if row.is_current else "  "
        lines.append(f"{selection_marker} {current_marker}{row.label}")
        if row.description:
            lines.append(f"    {row.description}")
    return "\n".join(lines)


def _normalize_selected_index(selected_index: int, row_count: int) -> int:
    if row_count <= 0:
        return 0
    if selected_index < 0:
        return 0
    if selected_index >= row_count:
        return row_count - 1
    return selected_index
