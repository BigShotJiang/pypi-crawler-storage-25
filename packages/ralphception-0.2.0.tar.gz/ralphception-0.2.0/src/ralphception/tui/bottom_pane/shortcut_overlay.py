"""Shortcut overlay for the Codex-style Ralphception footer mode."""

from __future__ import annotations

from textual.widgets import Static


_SHORTCUT_COLUMNS: tuple[tuple[str, str], ...] = (
    ("/ for commands", "tab to queue message"),
    ("alt+left/right switch threads", "esc to interrupt or dismiss"),
    ("ctrl + c to exit", ""),
)

_TRANSCRIPT_HINT = "ctrl + t to view transcript"


class ShortcutOverlay(Static):
    """Multiline shortcut overlay shown when `?` is pressed on an empty draft."""

    def __init__(self, text: str = "", *, id: str | None = None) -> None:
        super().__init__(text, id=id)

    def on_mount(self) -> None:
        self.update(render_shortcut_overlay(width=self._content_width()))

    def on_resize(self) -> None:
        self.update(render_shortcut_overlay(width=self._content_width()))

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def render_shortcut_overlay(*, width: int) -> str:
    """Render a compact Codex-style two-column shortcut overlay."""
    column_gap = 4
    inner_width = max(24, width - 2)
    left_width = max(12, (inner_width - column_gap) // 2)
    right_width = max(8, inner_width - left_width - column_gap)

    lines: list[str] = []
    for left, right in _SHORTCUT_COLUMNS:
        left_text = f"  {left}".ljust(left_width)
        if right:
            lines.append(f"{left_text}{' ' * column_gap}{right[:right_width]}".rstrip())
        else:
            lines.append(left_text.rstrip())
    lines.append("")
    lines.append(f"  {_TRANSCRIPT_HINT}")
    return "\n".join(lines)
