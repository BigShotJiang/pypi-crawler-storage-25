"""Shared path-label helpers for Codex-style shell surfaces."""

from __future__ import annotations

from pathlib import Path


def normalize_directory_label(directory_label: str) -> str:
    """Render home-relative paths the same way Codex does."""
    if directory_label == "~" or directory_label.startswith("~/"):
        return directory_label

    home = str(Path.home())
    if directory_label == home:
        return "~"
    home_prefix = f"{home}/"
    if directory_label.startswith(home_prefix):
        return f"~/{directory_label.removeprefix(home_prefix)}"
    return directory_label


def center_truncate(value: str, max_width: int) -> str:
    """Center-truncate a label when it must fit into a compact shell row."""
    if max_width <= 0:
        return ""
    if len(value) <= max_width:
        return value
    if max_width == 1:
        return "…"
    keep = max_width - 1
    left = keep // 2
    right = keep - left
    return f"{value[:left]}…{value[-right:]}"
