"""Persistent transcript reducer for the Codex-style Ralphception shell."""

from __future__ import annotations

from dataclasses import dataclass, field
import re

from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BackgroundWaitBeginEvent,
    BackgroundWaitEndEvent,
    BackgroundWaitUpdateEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    ErrorEvent,
    FrontendEvent,
    PlanUpdatedEvent,
    RequestUserInputRequestedEvent,
    RequestUserInputResolvedEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    ReviewRequestedEvent,
    ReviewResolvedEvent,
)
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, AssistantCell, CommandCell, SystemCell, TranscriptCell, UserCell


@dataclass(frozen=True, slots=True)
class WaitingState:
    """Explicit background wait state that survives turn completion."""

    process_id: str
    command: str
    summary: str


@dataclass(slots=True)
class TranscriptStore:
    """Committed history plus one mutable active cell, mirroring Codex's transcript ownership."""

    history_cells: list[TranscriptCell] = field(default_factory=list)
    active_cell: ActiveCell | None = None
    active_cell_revision: int = 0
    waiting_state: WaitingState | None = None
    reasoning_item_id: str | None = None
    reasoning_buffer: str = ""
    full_reasoning_buffer: str = ""
    last_plan_step: str | None = None
    _assistant_history_indices: dict[str, int] = field(default_factory=dict)
    _buffered_assistant_deltas: dict[str, str] = field(default_factory=dict)
    _buffered_assistant_order: list[str] = field(default_factory=list)

    @property
    def reasoning_header(self) -> str | None:
        return _extract_first_bold(self.reasoning_buffer)

    def apply(self, event: FrontendEvent) -> None:
        if isinstance(event, AssistantDeltaEvent):
            self._apply_assistant_delta(event)
            return
        if isinstance(event, AssistantFinalEvent):
            self._apply_assistant_final(event)
            return
        if isinstance(event, CommandBeginEvent):
            self._apply_command_begin(event)
            return
        if isinstance(event, CommandOutputDeltaEvent):
            self._apply_command_output_delta(event)
            return
        if isinstance(event, CommandEndEvent):
            self._apply_command_end(event)
            return
        if isinstance(event, ReasoningSummaryDeltaEvent):
            self._apply_reasoning_delta(event)
            return
        if isinstance(event, ReasoningSectionBreakEvent):
            self._apply_reasoning_section_break(event)
            return
        if isinstance(event, ReasoningFinalEvent):
            self._apply_reasoning_final(event)
            return
        if isinstance(event, BackgroundWaitBeginEvent):
            self._apply_wait_begin(event)
            return
        if isinstance(event, BackgroundWaitUpdateEvent):
            self._apply_wait_update(event)
            return
        if isinstance(event, BackgroundWaitEndEvent):
            self._apply_wait_end(event)
            return
        if isinstance(event, PlanUpdatedEvent):
            self._apply_plan_update(event)
            return
        if isinstance(event, ReviewRequestedEvent):
            self._commit(SystemCell(event.summary_text))
            return
        if isinstance(event, ReviewResolvedEvent):
            self._commit(SystemCell(_format_review_resolution(event.review_kind, event.resolution)))
            return
        if isinstance(event, RequestUserInputRequestedEvent):
            self._commit(SystemCell(event.question))
            return
        if isinstance(event, RequestUserInputResolvedEvent):
            self._commit(SystemCell(f"Input received: {event.prompt_id}"))
            return
        if isinstance(event, ErrorEvent):
            self._commit(SystemCell(event.message))

    def synchronize(self, *, committed: tuple[TranscriptCell, ...], active: ActiveCell | None) -> None:
        """Keep the reducer aligned with externally committed user cells and current active state."""

        self.history_cells = list(committed)
        self.active_cell = active
        self._assistant_history_indices.clear()
        self._bump_revision()

    def commit_user_message(self, text: str) -> None:
        self._commit(UserCell(text))

    def commit_system_message(self, text: str) -> None:
        self._commit(SystemCell(text))

    def commit_cell(self, cell: TranscriptCell) -> None:
        self._commit(cell)

    def clear_live_state(self) -> None:
        self.active_cell = None
        self.waiting_state = None
        self.reasoning_item_id = None
        self.reasoning_buffer = ""
        self.full_reasoning_buffer = ""
        self.last_plan_step = None
        self._buffered_assistant_deltas.clear()
        self._buffered_assistant_order.clear()
        self._bump_revision()

    def begin_turn_wait(self, *, summary: str = "Waiting for Ralphception to respond.") -> None:
        if self.active_cell is None:
            self.active_cell = ActiveCell(prefix="thinking", text=summary, item_id="turn-wait")
            self._bump_revision()

    def clear_turn_wait(self) -> None:
        if self.waiting_state is None and self.active_cell is not None and self.active_cell.item_id == "turn-wait":
            self.active_cell = None
            self._bump_revision()

    def _apply_assistant_delta(self, event: AssistantDeltaEvent) -> None:
        if self.active_cell is not None and self.active_cell.prefix == "$":
            self._buffer_assistant_delta(event.item_id, event.text)
            self._bump_revision()
            return
        if (
            self.active_cell is not None
            and self.active_cell.prefix == "assistant"
            and self.active_cell.item_id == event.item_id
        ):
            next_text = event.text if event.text.startswith(self.active_cell.text) else self.active_cell.text + event.text
            self.active_cell = ActiveCell(prefix="assistant", text=next_text, item_id=event.item_id)
            self._bump_revision()
            return
        if self.active_cell is not None and self.active_cell.prefix == "assistant" and self.active_cell.text:
            self._commit_assistant(self.active_cell.text, self.active_cell.item_id)
        self.active_cell = ActiveCell(prefix="assistant", text=event.text, item_id=event.item_id)
        self._bump_revision()

    def _apply_assistant_final(self, event: AssistantFinalEvent) -> None:
        assistant_item_id = event.item_id
        if assistant_item_id is None and self.active_cell is not None and self.active_cell.prefix == "assistant":
            assistant_item_id = self.active_cell.item_id
        self._commit_assistant(event.text, assistant_item_id)
        if event.item_id is not None:
            self._forget_buffered_assistant(event.item_id)
        if (
            self.active_cell is not None
            and self.active_cell.prefix == "assistant"
            and (event.item_id is None or self.active_cell.item_id == event.item_id)
        ):
            self.active_cell = None
            self._bump_revision()

    def _apply_command_begin(self, event: CommandBeginEvent) -> None:
        if self.active_cell is not None and self.active_cell.prefix == "assistant" and self.active_cell.text:
            self._commit_assistant(self.active_cell.text, self.active_cell.item_id)
            self.active_cell = None
        self.active_cell = ActiveCell(prefix="$", text=event.command, item_id=event.item_id)
        self._bump_revision()

    def _apply_command_output_delta(self, event: CommandOutputDeltaEvent) -> None:
        if (
            self.active_cell is None
            or self.active_cell.prefix != "$"
            or (self.active_cell.item_id is not None and self.active_cell.item_id != event.item_id)
        ):
            return
        delta_lines = tuple(event.text.splitlines())
        if not delta_lines:
            return
        self.active_cell = ActiveCell(
            prefix="$",
            text=self.active_cell.text,
            item_id=self.active_cell.item_id,
            output=(*self.active_cell.output, *delta_lines),
        )
        self._bump_revision()

    def _apply_command_end(self, event: CommandEndEvent) -> None:
        output: tuple[str, ...] = ()
        if (
            self.active_cell is not None
            and self.active_cell.prefix == "$"
            and (event.item_id is None or self.active_cell.item_id == event.item_id)
        ):
            output = self.active_cell.output
        status = f"exit {event.exit_code}" if event.exit_code is not None else event.status
        if status is None:
            status = "completed"
        self._commit(CommandCell(command=event.command, output=output, status=status))
        if self.active_cell is not None and self.active_cell.prefix == "$":
            self.active_cell = None
        self._promote_buffered_assistant()
        self._bump_revision()

    def _apply_reasoning_delta(self, event: ReasoningSummaryDeltaEvent) -> None:
        if self.reasoning_item_id is not None and event.item_id != self.reasoning_item_id:
            self._finalize_reasoning()
        self._prepare_for_reasoning_status_update()
        self.reasoning_item_id = event.item_id
        self.reasoning_buffer += event.text
        self._bump_revision()

    def _apply_reasoning_section_break(self, event: ReasoningSectionBreakEvent) -> None:
        if self.reasoning_item_id is not None and event.item_id != self.reasoning_item_id:
            self._finalize_reasoning()
        self._prepare_for_reasoning_status_update()
        self.reasoning_item_id = event.item_id
        self._advance_reasoning_section()
        self._bump_revision()

    def _apply_reasoning_final(self, event: ReasoningFinalEvent) -> None:
        if event.text:
            if self.reasoning_item_id is not None and event.item_id != self.reasoning_item_id:
                self._finalize_reasoning()
            self.reasoning_item_id = event.item_id
            self.reasoning_buffer = event.text
        if event.item_id is not None and self.reasoning_item_id is not None and event.item_id != self.reasoning_item_id:
            self._finalize_reasoning()
            return
        self._finalize_reasoning()

    def _apply_wait_begin(self, event: BackgroundWaitBeginEvent) -> None:
        self.waiting_state = WaitingState(
            process_id=event.process_id,
            command=event.command,
            summary=event.summary,
        )
        self.active_cell = ActiveCell(prefix="thinking", text=event.summary, item_id=event.process_id)
        self._bump_revision()

    def _apply_wait_update(self, event: BackgroundWaitUpdateEvent) -> None:
        if self.waiting_state is None or self.waiting_state.process_id != event.process_id:
            return
        self.waiting_state = WaitingState(
            process_id=self.waiting_state.process_id,
            command=self.waiting_state.command,
            summary=event.summary,
        )
        self.active_cell = ActiveCell(prefix="thinking", text=event.summary, item_id=event.process_id)
        self._bump_revision()

    def _apply_wait_end(self, event: BackgroundWaitEndEvent) -> None:
        if self.waiting_state is None or self.waiting_state.process_id != event.process_id:
            return
        self.waiting_state = None
        if self.active_cell is not None and self.active_cell.item_id == event.process_id:
            self.active_cell = None
        self._bump_revision()

    def _apply_plan_update(self, event: PlanUpdatedEvent) -> None:
        if event.active_step == self.last_plan_step:
            return
        self.last_plan_step = event.active_step
        self._commit(SystemCell(event.active_step))

    def _commit(self, cell: TranscriptCell) -> None:
        self.history_cells.append(cell)
        self._bump_revision()

    def _commit_assistant(self, text: str, item_id: str | None) -> None:
        if item_id is not None:
            history_index = self._assistant_history_indices.get(item_id)
            if history_index is not None:
                self.history_cells[history_index] = AssistantCell(text)
                self._bump_revision()
                return
        self.history_cells.append(AssistantCell(text))
        if item_id is not None:
            self._assistant_history_indices[item_id] = len(self.history_cells) - 1
        self._bump_revision()

    def _buffer_assistant_delta(self, item_id: str, text: str) -> None:
        current = self._buffered_assistant_deltas.get(item_id)
        next_text = text if current is None or text.startswith(current) else current + text
        self._buffered_assistant_deltas[item_id] = next_text
        if item_id not in self._buffered_assistant_order:
            self._buffered_assistant_order.append(item_id)

    def _forget_buffered_assistant(self, item_id: str) -> None:
        self._buffered_assistant_deltas.pop(item_id, None)
        self._buffered_assistant_order = [
            candidate for candidate in self._buffered_assistant_order if candidate != item_id
        ]

    def _promote_buffered_assistant(self) -> None:
        while self._buffered_assistant_order:
            item_id = self._buffered_assistant_order.pop(0)
            text = self._buffered_assistant_deltas.pop(item_id, None)
            if text:
                self.active_cell = ActiveCell(prefix="assistant", text=text, item_id=item_id)
                return

    def _advance_reasoning_section(self) -> None:
        current = self.reasoning_buffer.strip()
        if not current:
            self.reasoning_buffer = ""
            return
        prefix = f"{self.full_reasoning_buffer}\n\n" if self.full_reasoning_buffer else ""
        self.full_reasoning_buffer = f"{prefix}{current}"
        self.reasoning_buffer = ""

    def _finalize_reasoning(self) -> None:
        self._advance_reasoning_section()
        summary = _reasoning_summary_text(self.full_reasoning_buffer)
        if self.active_cell is not None and self.active_cell.prefix == "thinking":
            self.active_cell = None
        self.reasoning_item_id = None
        self.reasoning_buffer = ""
        self.full_reasoning_buffer = ""
        if summary:
            self._commit(SystemCell(summary))
        else:
            self._bump_revision()

    def _prepare_for_reasoning_status_update(self) -> None:
        if self.active_cell is None:
            return
        if self.active_cell.prefix == "$":
            return
        if self.active_cell.prefix == "assistant" and self.active_cell.text:
            self._commit_assistant(self.active_cell.text, self.active_cell.item_id)
        self.active_cell = None

    def _bump_revision(self) -> None:
        self.active_cell_revision += 1


def _extract_first_bold(text: str) -> str | None:
    start = text.find("**")
    if start < 0:
        return None
    remainder = text[start + 2 :]
    end = remainder.find("**")
    if end < 0:
        return None
    header = remainder[:end].strip()
    return header or None


def _format_review_resolution(review_kind: str, resolution: str) -> str:
    if resolution == "approve":
        return f"Approved: {review_kind}"
    action_label = resolution.replace("_", " ").capitalize()
    return f"{action_label}: {review_kind}"


def _reasoning_summary_text(text: str) -> str:
    full_reasoning_buffer = text.strip()
    if not full_reasoning_buffer:
        return ""
    header: str | None = None
    body = full_reasoning_buffer
    open_index = full_reasoning_buffer.find("**")
    if open_index >= 0:
        after_open = full_reasoning_buffer[open_index + 2 :]
        close_index = after_open.find("**")
        if close_index >= 0:
            header = after_open[:close_index].strip()
            after_close_index = open_index + 2 + close_index + 2
            if after_close_index < len(full_reasoning_buffer):
                body = full_reasoning_buffer[after_close_index:]
            else:
                body = ""
    sanitized_body = _sanitize_reasoning_summary_text(body)
    header_summary = _sanitize_reasoning_header(header)
    if _contains_tool_selection_meta(full_reasoning_buffer):
        return header_summary
    if sanitized_body:
        return sanitized_body
    return header_summary


_LEADING_INTERNAL_REASONING_PATTERNS = (
    re.compile(r"^\s*i need to act as (?:an? )?coding agent and\s+", re.IGNORECASE),
    re.compile(r"^\s*i need to act as ralphception'?s embedded coding agent and\s+", re.IGNORECASE),
    re.compile(r"^\s*i should use the commentary tools and explorer to\s+", re.IGNORECASE),
    re.compile(r"^\s*i should use the commentary tools to\s+", re.IGNORECASE),
    re.compile(r"^\s*i should use the explorer to\s+", re.IGNORECASE),
    re.compile(r"^\s*i can use the explorer to\s+", re.IGNORECASE),
    re.compile(r"^\s*i(?:'ll| will) use the explorer to\s+", re.IGNORECASE),
    re.compile(r"^\s*i need to follow the stage contract and\s+", re.IGNORECASE),
)
_LEADING_FIRST_PERSON_REASONING_PATTERNS = (
    re.compile(r"^\s*i see that\s+", re.IGNORECASE),
    re.compile(r"^\s*i need to\s+", re.IGNORECASE),
    re.compile(r"^\s*i think (?:the best option is to\s+)?", re.IGNORECASE),
    re.compile(r"^\s*i(?:'m| am) considering\s+", re.IGNORECASE),
    re.compile(r"^\s*i can\s+", re.IGNORECASE),
    re.compile(r"^\s*i should\s+", re.IGNORECASE),
    re.compile(r"^\s*i(?:'ll| will)\s+", re.IGNORECASE),
    re.compile(r"^\s*my goal is to\s+", re.IGNORECASE),
    re.compile(r"^\s*let's\s+", re.IGNORECASE),
)
_INTERNAL_REASONING_TOKENS = (
    "coding agent",
    "commentary",
    "explorer",
    "tool-selection",
    "skill system",
    "stage contract",
    "desktop workflow",
    "desktop-specific",
    "autonomous runtime",
    "outer chat history",
    "internal capabilities",
)
_PURE_META_REASONING_PATTERNS = (
    re.compile(r"\bfocus on mentioning\b", re.IGNORECASE),
    re.compile(r"\bkeep this concise\b", re.IGNORECASE),
    re.compile(r"\bconcise and efficient\b", re.IGNORECASE),
    re.compile(r"\btake a look\b", re.IGNORECASE),
    re.compile(r"\bthe \.ralphception path\b", re.IGNORECASE),
    re.compile(r"\bnarrat(?:e|ing) (?:my )?progress\b", re.IGNORECASE),
    re.compile(r"\bprovided path\b", re.IGNORECASE),
    re.compile(r"\bclear summary\b", re.IGNORECASE),
    re.compile(r"\bconcrete progress updates\b", re.IGNORECASE),
)
_CONCRETE_REASONING_HINTS = (
    "inspect",
    "review",
    "read",
    "update",
    "edit",
    "fix",
    "verify",
    "search",
    "check",
    "compare",
    "run ",
    "readme",
    ".md",
    ".py",
    ".rs",
    ".ts",
    ".js",
    "repo",
    "file",
    "diff",
    "artifact",
    "handoff",
    "todo",
    "plan",
)
_CONCRETE_TARGET_HINTS = (
    "readme",
    ".md",
    ".py",
    ".rs",
    ".ts",
    ".js",
    "repo",
    "diff",
    "artifact",
    "handoff",
    "todo",
    "plan",
)
_CONCRETE_HEADER_HINTS = (
    "inspect",
    "review",
    "read",
    "update",
    "edit",
    "fix",
    "verify",
    "search",
    "check",
    "compare",
    "readme",
    "file",
    "diff",
    "artifact",
    "handoff",
)
_GENERIC_REASONING_HEADER_PREFIXES = (
    "planning ",
    "next ",
    "thinking ",
    "considering ",
    "working ",
)
_TOOL_SELECTION_META_PATTERNS = (
    re.compile(r"\bexec_command\b", re.IGNORECASE),
    re.compile(r"\bcommentary tools?\b", re.IGNORECASE),
    re.compile(r"\bexplorer\b", re.IGNORECASE),
    re.compile(r"\bi(?:'m| am) wondering if i should\b", re.IGNORECASE),
    re.compile(r"\bmaybe i should\b", re.IGNORECASE),
    re.compile(r"\bi could use\b", re.IGNORECASE),
    re.compile(r"\bi(?:'ll| will) use\b", re.IGNORECASE),
    re.compile(r"\bwait for the final response\b", re.IGNORECASE),
    re.compile(r"\bnarrate progress\b", re.IGNORECASE),
    re.compile(r"\bwait for some input from an agent\b", re.IGNORECASE),
    re.compile(r"\boverthinking this\b", re.IGNORECASE),
    re.compile(r"\bnot strictly necessary\b", re.IGNORECASE),
)
_HANDOFF_SCHEMA_META_PATTERNS = (
    re.compile(r"\bwrite a file called handoff\.json\b", re.IGNORECASE),
    re.compile(r"\bthe user did(?:n't| not) specify types\b", re.IGNORECASE),
    re.compile(r"\bmerge_readiness could be\b", re.IGNORECASE),
    re.compile(r"\bpossibly with a \"?true\"? value\b", re.IGNORECASE),
)


def _sanitize_reasoning_summary_text(text: str) -> str:
    normalized = " ".join(text.strip().split())
    if not normalized:
        return ""
    if _is_task_restatement_meta(normalized) or _is_handoff_schema_meta(normalized):
        return ""

    kept_sentences: list[str] = []
    for raw_sentence in re.split(r"(?:(?<=[.!?])|(?<=[.!?][\"']))\s+", normalized):
        sentence = raw_sentence.strip()
        if not sentence:
            continue
        if ".ralphception" in sentence.lower():
            continue
        lowered_original = sentence.lower()
        had_internal_meta = any(token in lowered_original for token in _INTERNAL_REASONING_TOKENS)
        had_first_person_meta = False
        cleaned = sentence
        for pattern in _LEADING_INTERNAL_REASONING_PATTERNS:
            cleaned = pattern.sub("", cleaned)
        for pattern in _LEADING_FIRST_PERSON_REASONING_PATTERNS:
            next_cleaned = pattern.sub("", cleaned)
            if next_cleaned != cleaned:
                had_first_person_meta = True
                cleaned = next_cleaned
        cleaned = cleaned.strip()
        if cleaned:
            cleaned = cleaned[0].upper() + cleaned[1:]
        lowered_cleaned = cleaned.lower()
        if had_internal_meta:
            if any(token in lowered_cleaned for token in _INTERNAL_REASONING_TOKENS):
                continue
            if not any(hint in lowered_cleaned for hint in _CONCRETE_REASONING_HINTS):
                continue
        if had_first_person_meta:
            if any(pattern.search(cleaned) for pattern in _PURE_META_REASONING_PATTERNS):
                continue
            if not any(hint in lowered_cleaned for hint in _CONCRETE_TARGET_HINTS):
                continue
        if cleaned:
            kept_sentences.append(cleaned)

    return " ".join(kept_sentences)


def _sanitize_reasoning_header(header: str | None) -> str:
    if header is None:
        return ""
    normalized = " ".join(header.strip().split())
    if not normalized:
        return ""
    lowered = normalized.lower()
    if lowered.startswith(_GENERIC_REASONING_HEADER_PREFIXES):
        return ""
    if not any(hint in lowered for hint in _CONCRETE_HEADER_HINTS):
        return ""
    return normalized if normalized.endswith((".", "!", "?")) else f"{normalized}."


def _contains_tool_selection_meta(text: str) -> bool:
    return any(pattern.search(text) for pattern in _TOOL_SELECTION_META_PATTERNS)


def _is_task_restatement_meta(text: str) -> bool:
    lowered = text.lower()
    return (
        "write a handoff json" in lowered or "write a handoff.json" in lowered
    ) and any(
        pattern.search(text)
        for pattern in (
            re.compile(r"\bprovided path\b", re.IGNORECASE),
            re.compile(r"\bnarrat(?:e|ing) (?:my )?progress\b", re.IGNORECASE),
            re.compile(r"\bclear summary\b", re.IGNORECASE),
            re.compile(r"\bconcrete progress updates\b", re.IGNORECASE),
        )
    )


def _is_handoff_schema_meta(text: str) -> bool:
    return any(pattern.search(text) for pattern in _HANDOFF_SCHEMA_META_PATTERNS)


__all__ = [
    "AssistantDeltaEvent",
    "AssistantFinalEvent",
    "BackgroundWaitBeginEvent",
    "BackgroundWaitEndEvent",
    "BackgroundWaitUpdateEvent",
    "CommandBeginEvent",
    "CommandEndEvent",
    "CommandOutputDeltaEvent",
    "ReasoningFinalEvent",
    "ReasoningSectionBreakEvent",
    "ReasoningSummaryDeltaEvent",
    "TranscriptStore",
    "WaitingState",
]
