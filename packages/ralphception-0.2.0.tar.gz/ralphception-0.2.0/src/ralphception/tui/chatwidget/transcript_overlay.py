"""Transcript overlay widget for the Codex-style Ralphception shell."""

from __future__ import annotations

from collections.abc import Sequence

from textual.widgets import Static

from ralphception.tui.chatwidget.transcript_cells import ActiveCell, TranscriptCell
from ralphception.tui.chatwidget.transcript_view import render_transcript


class TranscriptOverlay(Static, can_focus=True):
    """Overlay that renders committed transcript cells plus the live active tail."""

    def __init__(
        self,
        *,
        committed: Sequence[TranscriptCell],
        active: ActiveCell | None,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self._committed = tuple(committed)
        self._active = active
        self._follow_tail = True

    def set_state(
        self,
        *,
        committed: Sequence[TranscriptCell],
        active: ActiveCell | None,
    ) -> None:
        was_at_tail = self.is_at_tail()
        self._committed = tuple(committed)
        self._active = active
        self.update(self._render_overlay())
        self._follow_tail = was_at_tail
        if was_at_tail:
            self.call_after_refresh(self._scroll_to_tail)

    def on_mount(self) -> None:
        self.update(self._render_overlay())
        self.call_after_refresh(self._scroll_to_tail)

    def is_at_tail(self) -> bool:
        return self.scroll_offset.y >= self.max_scroll_y

    def _scroll_to_tail(self) -> None:
        self.scroll_to(y=self.max_scroll_y, animate=False, force=True)

    def _render_overlay(self) -> str:
        width = max(48, self.size.width - 4) if self.size.width > 0 else 80
        transcript = render_transcript(
            committed=self._committed,
            active=self._active,
            width=width,
        ).strip()
        if not transcript:
            transcript = "No transcript yet."
        return f"T R A N S C R I P T\n\n{transcript}"
