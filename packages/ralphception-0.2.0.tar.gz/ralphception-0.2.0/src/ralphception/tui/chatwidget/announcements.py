"""Announcement row rendering for the Codex-style shell."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AnnouncementRow:
    """Single informational or warning row below the session header."""

    text: str


def render_announcements(rows: tuple[AnnouncementRow, ...]) -> str:
    """Render announcement rows as newline-delimited shell text."""
    if not rows:
        return ""
    return "\n".join(row.text for row in rows) + "\n"
