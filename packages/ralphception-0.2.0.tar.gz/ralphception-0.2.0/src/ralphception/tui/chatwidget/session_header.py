"""Session header card component for the Codex-style shell."""

from __future__ import annotations

from textual.widgets import Static

from ralphception.tui.path_labels import center_truncate, normalize_directory_label
from ralphception.tui.render_state import HeaderCardState

SessionHeaderState = HeaderCardState


class SessionHeader(Static):
    """Mutable header-card widget similar to Codex's session header owner."""

    def __init__(self, state: HeaderCardState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state

    def set_state(self, state: HeaderCardState) -> None:
        if self._state == state:
            return
        self._state = state
        self.update(_render_session_header_body(state, width=self._content_width()))

    def on_mount(self) -> None:
        self.update(_render_session_header_body(self._state, width=self._content_width()))

    def on_resize(self) -> None:
        self.update(_render_session_header_body(self._state, width=self._content_width()))

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 72


def render_session_header(state: HeaderCardState, *, width: int) -> str:
    """Render the session header card using the Codex card structure."""
    border = "-" * width
    body_lines = _session_header_lines(state, width=width)
    lines = [border, *body_lines, border]
    return "\n".join(lines) + "\n"


def _render_session_header_body(state: HeaderCardState, *, width: int) -> str:
    return "\n".join(_session_header_lines(state, width=width))


def _session_header_lines(state: HeaderCardState, *, width: int) -> list[str]:
    model_label = f"{state.model_name} {state.reasoning_effort}".strip()
    if state.latency_label:
        model_label = f"{model_label}   {state.latency_label}".strip()
    model_label = f"{model_label}   /model for config help".strip()
    directory_label = _format_directory_label(
        state.directory_label,
        max_width=max(0, width - len("directory: ") - 10),
    )
    lines: list[str] = [
        f">_ {state.product_name} (v{state.version})",
        "",
        f"model:     {model_label}",
        f"directory: {directory_label}",
    ]
    if state.mission_label:
        lines.append(f"mission:   {state.mission_label}")
    return lines


def _format_directory_label(directory_label: str, *, max_width: int) -> str:
    normalized = normalize_directory_label(directory_label)
    if max_width <= 0 or len(normalized) <= max_width:
        return normalized

    separator = "/"
    parts = normalized.split(separator)
    if len(parts) < 4:
        return center_truncate(normalized, max_width)

    leading = parts[:3]
    trailing = parts[-2:]
    candidate = separator.join([*leading, "…", *trailing])
    if len(candidate) <= max_width:
        return candidate

    while len(leading) > 1:
        leading = leading[:-1]
        candidate = separator.join([*leading, "…", *trailing])
        if len(candidate) <= max_width:
            return candidate

    while len(trailing) > 1:
        trailing = trailing[1:]
        candidate = separator.join([*leading, "…", *trailing])
        if len(candidate) <= max_width:
            return candidate

    return center_truncate(normalized, max_width)
