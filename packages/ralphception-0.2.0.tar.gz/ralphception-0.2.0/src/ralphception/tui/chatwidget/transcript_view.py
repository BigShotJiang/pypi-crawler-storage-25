"""Transcript renderer and widget for the Codex-style Ralphception shell."""

from __future__ import annotations

from collections.abc import Sequence

from textual.widgets import Static

from ralphception.tui.chatwidget.markdown_render import render_markdown
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, TranscriptCell


class TranscriptView(Static):
    """Stateful transcript widget mirroring Codex's transcript ownership."""

    def __init__(
        self,
        *,
        committed: Sequence[TranscriptCell],
        active: ActiveCell | None,
        id: str | None = None,
    ) -> None:
        super().__init__(id=id)
        self._committed = tuple(committed)
        self._active = active
        self._follow_tail = True

    def set_state(
        self,
        *,
        committed: Sequence[TranscriptCell],
        active: ActiveCell | None,
    ) -> None:
        was_at_tail = self.is_at_tail()
        self._committed = tuple(committed)
        self._active = active
        self.update(
            render_transcript(
                committed=self._committed,
                active=self._active,
                width=self._content_width(),
            )
        )
        self._follow_tail = was_at_tail
        if was_at_tail:
            self.call_after_refresh(self._scroll_to_tail)

    def on_mount(self) -> None:
        self.update(
            render_transcript(
                committed=self._committed,
                active=self._active,
                width=self._content_width(),
            )
        )
        self.call_after_refresh(self._scroll_to_tail)

    def on_resize(self) -> None:
        self.update(
            render_transcript(
                committed=self._committed,
                active=self._active,
                width=self._content_width(),
            )
        )
        if self._follow_tail:
            self.call_after_refresh(self._scroll_to_tail)

    def is_at_tail(self) -> bool:
        return self.scroll_offset.y >= self.max_scroll_y

    def _scroll_to_tail(self) -> None:
        self.scroll_to(y=self.max_scroll_y, animate=False, force=True)

    def _content_width(self) -> int:
        return self.size.width if self.size.width > 0 else 80


def render_transcript(
    *,
    committed: Sequence[TranscriptCell],
    active: ActiveCell | None,
    width: int,
) -> str:
    """Render committed and active transcript cells as shell text."""
    lines = [_render_cell(cell, width=width) for cell in committed]
    if active is not None:
        lines.append(active.render_lines(width=width))
    return "\n\n".join(line for line in lines if line)


def _render_cell(cell: TranscriptCell, *, width: int) -> str:
    rendered = cell.render_lines(width=width)
    return "\n".join(render_markdown(line) for line in rendered.splitlines())
