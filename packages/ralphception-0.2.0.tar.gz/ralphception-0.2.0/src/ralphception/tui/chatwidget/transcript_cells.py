"""Transcript cell models for the Codex-style Ralphception shell."""

from __future__ import annotations

from dataclasses import dataclass
import textwrap
from typing import TypeAlias


def _wrap_prefixed(
    text: str,
    *,
    width: int,
    initial_prefix: str,
    subsequent_prefix: str,
) -> str:
    if width <= 0:
        return ""
    wrapped_lines: list[str] = []
    source_lines = text.splitlines() or [text]
    content_width = max(1, width - len(initial_prefix) - 1)
    for raw_line in source_lines:
        line = raw_line or ""
        parts = textwrap.wrap(line, width=content_width) or [""]
        for index, part in enumerate(parts):
            prefix = initial_prefix if index == 0 else subsequent_prefix
            wrapped_lines.append(f"{prefix}{part}")
    return "\n".join(wrapped_lines)


def _render_command_details(lines: tuple[str, ...]) -> tuple[str, ...]:
    if not lines:
        return ()
    rendered: list[str] = []
    for index, line in enumerate(lines):
        prefix = "  \u2514 " if index == 0 else "    "
        rendered.append(f"{prefix}{line}")
    return tuple(rendered)


@dataclass(frozen=True, slots=True)
class UserCell:
    """Committed user transcript cell."""

    text: str

    def render_lines(self, *, width: int = 80) -> str:
        return _wrap_prefixed(
            self.text,
            width=width,
            initial_prefix="› ",
            subsequent_prefix="  ",
        )


@dataclass(frozen=True, slots=True)
class AssistantCell:
    """Committed assistant transcript cell."""

    text: str

    def render_lines(self, *, width: int = 80) -> str:
        del width
        return self.text


@dataclass(frozen=True, slots=True)
class SystemCell:
    """Committed system/status transcript cell."""

    text: str

    def render_lines(self, *, width: int = 80) -> str:
        return _wrap_prefixed(
            self.text,
            width=width,
            initial_prefix="• ",
            subsequent_prefix="  ",
        )


@dataclass(frozen=True, slots=True)
class CommandCell:
    """Committed command transcript cell."""

    command: str
    output: tuple[str, ...] = ()
    status: str | None = None

    def render_lines(self, *, width: int = 80) -> str:
        del width
        lines = [f"\u2022 Ran {self.command}"]
        detail_lines = list(_render_command_details(self.output))
        if _should_render_command_status(self.status):
            detail_lines.extend(_render_command_details((self.status or "",)))
        lines.extend(detail_lines)
        return "\n".join(lines)


TranscriptCell: TypeAlias = UserCell | AssistantCell | SystemCell | CommandCell


@dataclass(frozen=True, slots=True)
class ActiveCell:
    """Active streaming transcript cell."""

    prefix: str
    text: str
    item_id: str | None = None
    output: tuple[str, ...] = ()

    def render_lines(self, *, width: int = 80) -> str:
        if self.prefix == "$":
            lines = [f"\u2022 Running {self.text}"]
            lines.extend(_render_command_details(self.output))
            return "\n".join(lines)
        if self.prefix in {"thinking", "assistant"}:
            return _wrap_prefixed(
                self.text,
                width=width,
                initial_prefix="• ",
                subsequent_prefix="  ",
            )
        return f"{self.prefix}: {self.text}"


StreamingCell = ActiveCell


def _should_render_command_status(status: str | None) -> bool:
    if status is None:
        return False
    normalized = status.strip().lower()
    return normalized not in {"", "completed", "exit 0"}
