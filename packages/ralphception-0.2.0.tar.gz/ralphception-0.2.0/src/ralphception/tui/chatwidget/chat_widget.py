"""Main chat surface for the Ralphception TUI."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Static

from ralphception.tui.bottom_pane.bottom_pane_view import BottomPaneWidget
from ralphception.tui.chatwidget.session_header import SessionHeader
from ralphception.tui.chatwidget.transcript_view import TranscriptView
from ralphception.tui.render_state import RenderState


class ChatWidget(Vertical):
    """Owns the header, transcript, and bottom pane like Codex's chat widget."""

    def __init__(self, state: RenderState, *, id: str | None = None) -> None:
        super().__init__(id=id)
        self._state = state

    def compose(self) -> ComposeResult:
        yield SessionHeader(self._state.header_card, id="session-header")
        yield Static("\n".join(self._state.announcement_rows), id="announcement-rows")
        yield TranscriptView(
            committed=self._state.transcript.committed,
            active=self._state.transcript.active,
            id="transcript-view",
        )
        yield BottomPaneWidget(self._state.bottom_pane, id="bottom-pane")

    def set_state(self, state: RenderState) -> None:
        self._state = state
        self.query_one("#session-header", SessionHeader).set_state(state.header_card)
        self.query_one("#announcement-rows", Static).update("\n".join(state.announcement_rows))
        transcript_view = self.query_one("#transcript-view", TranscriptView)
        transcript_view.set_state(
            committed=state.transcript.committed,
            active=state.transcript.active,
        )
        self.query_one("#bottom-pane", BottomPaneWidget).set_state(state.bottom_pane)
        self._apply_overlay_layout()

    def on_mount(self) -> None:
        self._apply_overlay_layout()

    def _apply_overlay_layout(self) -> None:
        announcement_rows = self.query_one("#announcement-rows", Static)
        view_active = self._state.bottom_pane.active_view is not None
        announcement_rows.display = not view_active
