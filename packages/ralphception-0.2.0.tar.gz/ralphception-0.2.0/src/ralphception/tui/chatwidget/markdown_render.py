"""Minimal markdown rendering for transcript content."""

from __future__ import annotations


def render_markdown(text: str) -> str:
    """Render transcript markdown as plain shell text for now."""
    return text
