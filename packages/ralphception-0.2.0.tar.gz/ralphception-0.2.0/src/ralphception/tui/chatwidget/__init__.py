"""Chat-widget package for the Codex-style Ralphception TUI."""

__all__ = []
