"""Codex-style multi-agent picker ordering and active-label state."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ralphception.tui.multi_agents import format_agent_picker_item_name


@dataclass(frozen=True, slots=True)
class AgentPickerThreadEntry:
    """Cached picker metadata for a thread."""

    nickname: str | None
    role: str | None
    is_closed: bool


class AgentNavigationDirection(str, Enum):
    """Direction through stable agent spawn order."""

    PREVIOUS = "previous"
    NEXT = "next"


class AgentNavigationState:
    """Small state container for stable agent/thread traversal and labeling."""

    def __init__(self) -> None:
        self._threads: dict[str, AgentPickerThreadEntry] = {}
        self._order: list[str] = []

    def get(self, thread_id: str) -> AgentPickerThreadEntry | None:
        return self._threads.get(thread_id)

    def is_empty(self) -> bool:
        return not self._threads

    def upsert(
        self,
        thread_id: str,
        *,
        nickname: str | None,
        role: str | None,
        is_closed: bool,
    ) -> None:
        if thread_id not in self._threads:
            self._order.append(thread_id)
        self._threads[thread_id] = AgentPickerThreadEntry(
            nickname=nickname,
            role=role,
            is_closed=is_closed,
        )

    def mark_closed(self, thread_id: str) -> None:
        entry = self._threads.get(thread_id)
        if entry is None:
            self.upsert(thread_id, nickname=None, role=None, is_closed=True)
            return
        self._threads[thread_id] = AgentPickerThreadEntry(
            nickname=entry.nickname,
            role=entry.role,
            is_closed=True,
        )

    def clear(self) -> None:
        self._threads.clear()
        self._order.clear()

    def has_non_primary_thread(self, primary_thread_id: str | None) -> bool:
        return any(thread_id != primary_thread_id for thread_id in self._threads)

    def ordered_threads(self) -> list[tuple[str, AgentPickerThreadEntry]]:
        return [
            (thread_id, entry)
            for thread_id in self._order
            if (entry := self._threads.get(thread_id)) is not None
        ]

    def ordered_thread_ids(self) -> list[str]:
        return [thread_id for thread_id, _entry in self.ordered_threads()]

    def adjacent_thread_id(
        self,
        current_displayed_thread_id: str | None,
        direction: AgentNavigationDirection,
    ) -> str | None:
        ordered_threads = self.ordered_thread_ids()
        if len(ordered_threads) < 2 or current_displayed_thread_id is None:
            return None
        try:
            current_index = ordered_threads.index(current_displayed_thread_id)
        except ValueError:
            return None
        if direction is AgentNavigationDirection.NEXT:
            return ordered_threads[(current_index + 1) % len(ordered_threads)]
        return ordered_threads[current_index - 1 if current_index > 0 else len(ordered_threads) - 1]

    def active_agent_label(
        self,
        current_displayed_thread_id: str | None,
        *,
        primary_thread_id: str | None,
    ) -> str | None:
        if len(self._threads) <= 1 or current_displayed_thread_id is None:
            return None
        entry = self._threads.get(current_displayed_thread_id)
        return format_agent_picker_item_name(
            None if entry is None else entry.nickname,
            None if entry is None else entry.role,
            is_primary=current_displayed_thread_id == primary_thread_id,
        )
