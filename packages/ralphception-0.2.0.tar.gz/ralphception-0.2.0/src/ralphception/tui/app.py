"""Root Textual app for the Codex-style Ralphception TUI."""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Literal

from textual import events
from textual.app import App, ComposeResult
from textual.app import SuspendNotSupported
from textual.binding import Binding
from textual.containers import Vertical
from textual.widgets import Button, Static, TextArea

from ralphception.tui.bottom_pane.chat_composer import ChatComposer
from ralphception.tui.bottom_pane.bottom_pane_view import render_bottom_pane
from ralphception.tui.bottom_pane.bottom_pane_view import BottomPaneWidget
from ralphception.tui.chatwidget.chat_widget import ChatWidget
from ralphception.tui.chatwidget.transcript_overlay import TranscriptOverlay
from ralphception.tui.chatwidget.transcript_view import TranscriptView
from ralphception.tui.chatwidget.transcript_view import render_transcript
from ralphception.tui.chatwidget.session_header import render_session_header
from ralphception.tui.multi_agents import AgentPickerView
from ralphception.tui.render_state import RenderState
from ralphception.tui.runtime_adapter import RuntimeAdapter


class RalphceptionTuiApp(App[None]):
    """Root shell composition that mirrors Codex's app/chat-widget split."""

    BINDINGS = [
        Binding("escape", "close_active_view", "Close picker"),
        Binding("ctrl+t", "toggle_transcript_overlay", "View transcript"),
        Binding("alt+left", "previous_agent", "Previous agent"),
        Binding("alt+right", "next_agent", "Next agent"),
        Binding("enter", "activate_overlay_action", "", show=False, priority=True),
        Binding("space", "activate_overlay_action", "", show=False, priority=True),
        Binding("tab", "focus_next_overlay_action", "", show=False, priority=True),
        Binding("shift+tab", "focus_previous_overlay_action", "", show=False, priority=True),
        Binding("down", "focus_next_overlay_action", "", show=False, priority=True),
        Binding("up", "focus_previous_overlay_action", "", show=False, priority=True),
    ]

    CSS = """
    Screen {
        background: #232530;
        color: #e8e8ec;
    }

    #shell-root {
        padding: 1 2;
        width: 100%;
    }

    #shell-label {
        color: #8bd5ca;
        margin: 0 0 1 1;
        text-style: bold;
    }

    #chat-widget {
        width: 100%;
    }

    #session-header {
        border: round #7a8194;
        background: #2c2f3a;
        color: #f5f5f7;
        padding: 0 1;
        margin-bottom: 1;
    }

    #announcement-rows {
        color: #e8dd7a;
        margin: 0 0 1 1;
    }

    #transcript-view {
        min-height: 6;
        background: #2c2f3a;
        color: #f5f5f7;
        padding: 1 1;
        margin-bottom: 1;
        overflow-x: hidden;
    }

    #bottom-pane {
        height: auto;
        max-height: 10;
    }

    #transcript-overlay {
        layer: overlay;
        overlay: screen;
        width: 1fr;
        height: 1fr;
        margin: 2 4;
        border: round #7a8194;
        background: #1d1f28;
        color: #f5f5f7;
        padding: 1 2;
        overflow-y: auto;
        overflow-x: hidden;
    }

    #status-indicator {
        color: #cfd3dc;
        margin: 0 0 1 1;
    }

    #composer-input,
    #startup-seed-prompt,
    #startup-source-repos {
        background: #4f5362;
        color: #f5f5f7;
        border: round #4f5362;
    }

    #composer-input {
        min-height: 3;
        max-height: 8;
    }

    #startup-seed-prompt,
    #startup-source-repos {
        height: 3;
    }

    #footer-status {
        color: #a5abba;
        margin: 1 0 0 1;
    }

    #review-title,
    #startup-title {
        color: #f5f5f7;
        text-style: bold;
        margin-bottom: 1;
    }

    #review-summary,
    #startup-summary,
    .startup-label {
        color: #cfd3dc;
    }
    """

    def __init__(
        self,
        render_state: RenderState,
        *,
        runtime_adapter: RuntimeAdapter | None = None,
    ) -> None:
        super().__init__()
        self.render_state = render_state
        self.runtime_adapter = runtime_adapter
        self._transcript_overlay_open = False
        self._overlay_action_index = 0
        self._inline_history_cell_count = 0

    @classmethod
    def for_idle_preview(cls, repo_root: Path) -> "RalphceptionTuiApp":
        return cls(render_state=RenderState.idle_preview(repo_root))

    @classmethod
    def from_runtime(
        cls,
        repo_root: Path,
        *,
        session_manager_factory=None,
    ) -> "RalphceptionTuiApp":
        adapter = RuntimeAdapter(
            repo_root=repo_root,
            session_manager_factory=session_manager_factory,
        )
        return cls(
            render_state=adapter.load_render_state(),
            runtime_adapter=adapter,
        )

    def compose(self) -> ComposeResult:
        with Vertical(id="shell-root"):
            yield Static(self.render_state.shell_label, id="shell-label")
            yield ChatWidget(self.render_state, id="chat-widget")

    def on_mount(self) -> None:
        if self.runtime_adapter is not None and self.runtime_adapter.can_run_live():
            self.set_interval(0.05, self._drain_runtime_updates)
        if self.is_inline:
            self.call_after_refresh(self._sync_inline_history_after_refresh)
        if self.render_state.active_overlay_kind is not None:
            self.call_after_refresh(self._focus_active_view)
        else:
            self.call_after_refresh(self._focus_primary_input)

    async def on_event(self, event: events.Event) -> None:
        if isinstance(event, events.Key) and self._handle_overlay_action_key(event):
            event.stop()
            return
        await super().on_event(event)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if self.runtime_adapter is None or event.button.id is None:
            return

        if event.button.id.startswith("review-action-"):
            action = event.button.id.removeprefix("review-action-")
            self.runtime_adapter.apply_review_action(action)
            if not self.runtime_adapter.can_run_live():
                self._drain_runtime_updates()
            return

        if event.button.id.startswith("conflict-action-"):
            action = event.button.id.removeprefix("conflict-action-")
            self.runtime_adapter.apply_conflict_action(action)
            if not self.runtime_adapter.can_run_live():
                self._drain_runtime_updates()
            return

        if event.button.id.startswith("launch-action-"):
            action = event.button.id.removeprefix("launch-action-").replace("-", "_")
            self.runtime_adapter.apply_launch_action(action)
            self._drain_runtime_updates()

    def on_bottom_pane_widget_slash_command_submitted(
        self,
        message: BottomPaneWidget.SlashCommandSubmitted,
    ) -> None:
        if self.runtime_adapter is None:
            return
        command = message.command.strip()
        command_name, _, command_arg = command.partition(" ")
        normalized_name = command_name.lower()
        if normalized_name == "/agent":
            self._open_runtime_view(self.runtime_adapter.agent_picker_view())
            return
        if normalized_name == "/model":
            self._set_render_state(
                replace(
                    self.render_state,
                    announcement_rows=self.runtime_adapter.model_help_lines(),
                    bottom_pane=replace(
                        self.render_state.bottom_pane,
                        composer=replace(self.render_state.bottom_pane.composer, value=""),
                        popup=None,
                    ),
                )
            )
            return
        if normalized_name == "/resume":
            if self.runtime_adapter.resume_last_session():
                self._drain_runtime_updates()
            else:
                self._set_render_state(
                    replace(
                        self.render_state,
                        announcement_rows=("No resumable Ralphception session was found.",),
                        bottom_pane=replace(
                            self.render_state.bottom_pane,
                            composer=replace(self.render_state.bottom_pane.composer, value=""),
                            popup=None,
                        ),
                    )
                )
            return
        if normalized_name == "/source":
            if self.runtime_adapter is not None and self.runtime_adapter.startup_prompt_pending() and command_arg.strip():
                self.runtime_adapter.add_startup_source_repo(command_arg)
                self._set_render_state(self.runtime_adapter.current_render_state())
            return
        if normalized_name == "/help":
            self._set_render_state(
                replace(
                    self.render_state,
                    announcement_rows=(
                        "Enter submit · Tab queue message · Esc interrupt or dismiss",
                        "/agent switch threads · /resume continue interrupted work · /model inherited Codex config",
                    ),
                    bottom_pane=replace(
                        self.render_state.bottom_pane,
                        composer=replace(self.render_state.bottom_pane.composer, value=""),
                        popup=None,
                    ),
                )
            )

    def on_bottom_pane_widget_composer_submitted(
        self,
        message: BottomPaneWidget.ComposerSubmitted,
    ) -> None:
        if self.runtime_adapter is None:
            return
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    composer=replace(self.render_state.bottom_pane.composer, value=""),
                    popup=None,
                    shortcut_overlay_visible=False,
                ),
            )
        )
        self.runtime_adapter.submit_message(text=message.text, render_immediately=True)
        self._drain_runtime_updates()

    def on_bottom_pane_widget_composer_queued(
        self,
        message: BottomPaneWidget.ComposerQueued,
    ) -> None:
        if self.runtime_adapter is None:
            return
        next_state = replace(
            self.render_state,
            bottom_pane=replace(
                self.render_state.bottom_pane,
                composer=replace(self.render_state.bottom_pane.composer, value=""),
                queued_messages=(*self.render_state.bottom_pane.queued_messages, message.text),
                popup=None,
            ),
        )
        self._set_render_state(next_state)
        self.runtime_adapter.queue_message(text=message.text, render_immediately=False)

    def on_bottom_pane_widget_composer_draft_changed(
        self,
        message: BottomPaneWidget.ComposerDraftChanged,
    ) -> None:
        if self.render_state.bottom_pane.composer.value == message.text:
            return
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    composer=replace(
                        self.render_state.bottom_pane.composer,
                        value=message.text,
                    ),
                ),
            )
        )

    def on_bottom_pane_widget_dismiss_requested(
        self,
        message: BottomPaneWidget.DismissRequested,
    ) -> None:
        del message
        self._pop_active_view()

    def on_bottom_pane_widget_interrupt_requested(
        self,
        message: BottomPaneWidget.InterruptRequested,
    ) -> None:
        del message
        if self.runtime_adapter is None:
            return
        if self.runtime_adapter.interrupt_active_turn():
            self._drain_runtime_updates()

    def on_bottom_pane_widget_edit_last_queued_requested(
        self,
        message: BottomPaneWidget.EditLastQueuedRequested,
    ) -> None:
        del message
        queued_messages = self.render_state.bottom_pane.queued_messages
        if not queued_messages:
            return
        restored_message = queued_messages[-1]
        if self.runtime_adapter is not None:
            restored_message = self.runtime_adapter.pop_last_queued_message() or restored_message
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    composer=replace(
                        self.render_state.bottom_pane.composer,
                        value=restored_message,
                    ),
                    queued_messages=queued_messages[:-1],
                    popup=None,
                ),
            )
        )

    def on_agent_picker_view_dismiss_requested(
        self,
        message: AgentPickerView.DismissRequested,
    ) -> None:
        del message
        self._pop_active_view()

    def on_agent_picker_view_thread_selected(
        self,
        message: AgentPickerView.ThreadSelected,
    ) -> None:
        self._pop_active_view()
        if self.runtime_adapter is not None:
            self.runtime_adapter.select_agent_thread(
                thread_id=message.thread_id,
                label=message.label,
            )
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    footer=replace(
                        self.render_state.bottom_pane.footer,
                        active_thread_label=message.label,
                    ),
                ),
            )
        )

    def on_key(self, event: events.Key) -> None:
        if event.key != "escape":
            return
        if self._transcript_overlay_open:
            self._close_transcript_overlay()
            event.stop()
            return
        active_kind = self.render_state.active_overlay_kind
        if active_kind == "agent_picker":
            self._pop_active_view()
            event.stop()

    def action_close_active_view(self) -> None:
        if self._transcript_overlay_open:
            self._close_transcript_overlay()
            return
        if self.render_state.active_overlay_kind == "agent_picker":
            self._pop_active_view()

    def action_toggle_transcript_overlay(self) -> None:
        if self._transcript_overlay_open:
            self._close_transcript_overlay()
            return
        self._open_transcript_overlay()

    def action_previous_agent(self) -> None:
        self._cycle_agent_thread(direction="previous")

    def action_next_agent(self) -> None:
        self._cycle_agent_thread(direction="next")

    def action_activate_overlay_action(self) -> None:
        buttons = self._overlay_action_buttons()
        if not buttons:
            return
        selected = buttons[self._overlay_action_index % len(buttons)]
        selected.press()

    def action_focus_next_overlay_action(self) -> None:
        buttons = self._overlay_action_buttons()
        if not buttons:
            return
        next_button = self._adjacent_overlay_button(buttons, direction=1)
        self._overlay_action_index = buttons.index(next_button)
        next_button.focus()

    def action_focus_previous_overlay_action(self) -> None:
        buttons = self._overlay_action_buttons()
        if not buttons:
            return
        previous_button = self._adjacent_overlay_button(buttons, direction=-1)
        self._overlay_action_index = buttons.index(previous_button)
        previous_button.focus()

    def export_text(self) -> str:
        lines = [
            self.render_state.shell_label,
            render_session_header(self.render_state.header_card, width=72).rstrip("\n"),
            "",
        ]
        lines.extend(self.render_state.announcement_rows)
        if self.render_state.announcement_rows:
            lines.append("")
        transcript = render_transcript(
            committed=self.render_state.transcript.committed,
            active=self.render_state.transcript.active,
            width=80,
        )
        if transcript:
            lines.append(transcript)
            lines.append("")
        if self._transcript_overlay_open:
            lines.append(self._render_transcript_overlay_text())
            lines.append("")
        lines.append(render_bottom_pane(state=self.render_state.bottom_pane, width=80))
        return "\n".join(lines) + "\n"

    def _set_render_state(self, render_state: RenderState) -> None:
        self.render_state = render_state
        if self.render_state.active_overlay_kind not in {"approval", "conflict", "launch_resume", "broken_resume"}:
            self._overlay_action_index = 0
        if self.runtime_adapter is not None:
            self.runtime_adapter.replace_render_state(render_state)
        if not self.is_mounted:
            return
        display_state = self._display_render_state(render_state)
        if not self.query("#shell-label") or not self.query("#chat-widget"):
            return
        self.query_one("#shell-label", Static).update(display_state.shell_label)
        self.query_one("#chat-widget", ChatWidget).set_state(display_state)
        if self.is_inline:
            self.call_after_refresh(self._sync_inline_history_after_refresh)
        self._sync_transcript_overlay()
        if self.render_state.active_overlay_kind is not None:
            self.call_after_refresh(self._focus_active_view)
        elif self._transcript_overlay_open:
            self.call_after_refresh(self._focus_transcript_overlay)
        else:
            self.call_after_refresh(self._focus_primary_input)

    def _display_render_state(self, render_state: RenderState) -> RenderState:
        if not self.is_inline:
            return render_state
        committed = render_state.transcript.committed
        flushed_count = min(self._inline_history_cell_count, len(committed))
        if flushed_count <= 0:
            return render_state
        return replace(
            render_state,
            transcript=replace(
                render_state.transcript,
                committed=committed[flushed_count:],
            ),
        )

    def _flush_inline_history(self, render_state: RenderState) -> None:
        if not self.is_inline:
            self._inline_history_cell_count = 0
            return
        committed = render_state.transcript.committed
        if len(committed) < self._inline_history_cell_count:
            self._inline_history_cell_count = 0
        new_cells = committed[self._inline_history_cell_count :]
        if not new_cells:
            return
        history_text = render_transcript(
            committed=new_cells,
            active=None,
            width=self._inline_history_width(),
        ).strip()
        self._inline_history_cell_count = len(committed)
        if not history_text:
            return
        if self._inline_history_cell_count > len(new_cells):
            history_text = f"\n{history_text}"
        try:
            with self.suspend():
                print(history_text, flush=True)
        except SuspendNotSupported:
            print(history_text, flush=True)

    def _inline_history_width(self) -> int:
        if self.is_mounted and self.query("#transcript-view"):
            width = self.query_one("#transcript-view", TranscriptView).size.width
            if width > 0:
                return width
        return 80

    def _sync_inline_history_after_refresh(self) -> None:
        if not self.is_inline or not self.is_mounted or not self.query("#chat-widget"):
            return
        self._flush_inline_history(self.render_state)
        self.query_one("#chat-widget", ChatWidget).set_state(
            self._display_render_state(self.render_state)
        )

    def _focus_primary_input(self) -> None:
        if self._transcript_overlay_open:
            return
        if self.render_state.bottom_pane.startup_prompt_active and self.query("#composer-input"):
            self.set_focus(self.query_one("#composer-input", ChatComposer))
            return
        if self.render_state.active_overlay_kind is None and self.query("#composer-input"):
            self.set_focus(self.query_one("#composer-input"))

    def _open_runtime_view(self, view_state: object | None) -> None:
        if view_state is None:
            return
        if self.query("#composer-input"):
            self.query_one("#composer-input", TextArea).load_text("")
        self.set_focus(None)
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    composer=replace(self.render_state.bottom_pane.composer, value=""),
                    view_stack=(*self.render_state.bottom_pane.view_stack, view_state),
                    popup=None,
                ),
            )
        )

    def _push_active_view(self, view_state: object) -> None:
        self.set_focus(None)
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    view_stack=(*self.render_state.bottom_pane.view_stack, view_state),
                    popup=None,
                ),
            )
        )

    def _pop_active_view(self) -> None:
        if not self.render_state.bottom_pane.view_stack:
            return
        self.set_focus(None)
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    view_stack=self.render_state.bottom_pane.view_stack[:-1],
                    popup=None,
                ),
            )
        )
        self.set_timer(0, self._focus_primary_input)

    def _focus_active_view(self) -> None:
        active_kind = self.render_state.active_overlay_kind
        if active_kind in {"approval", "conflict", "launch_resume", "broken_resume"}:
            buttons = self._overlay_action_buttons()
            if buttons:
                self._overlay_action_index = min(self._overlay_action_index, len(buttons) - 1)
                self.screen.set_focus(buttons[0])
                return
        if active_kind == "agent_picker" and self.query("#agent-picker-view"):
            self.screen.set_focus(self.query_one("#agent-picker-view", AgentPickerView))
            return

    def _focus_transcript_overlay(self) -> None:
        if self.query("#transcript-overlay"):
            self.set_focus(self.query_one("#transcript-overlay", TranscriptOverlay))

    def _drain_runtime_updates(self) -> None:
        if self.runtime_adapter is None:
            return
        drain_all = getattr(self.runtime_adapter, "drain_render_state", None)
        if callable(drain_all):
            state = drain_all()
        else:
            drain_next = getattr(self.runtime_adapter, "drain_next_render_state", None)
            state = drain_next() if callable(drain_next) else None
        if state is not None:
            state = self._merge_local_draft_into_runtime_state(state)
            self._set_render_state(state)

    def _cycle_agent_thread(self, *, direction: Literal["previous", "next"]) -> None:
        if self.runtime_adapter is None or self.render_state.active_overlay_kind is not None:
            return
        active_thread_label = self.runtime_adapter.cycle_agent_thread(direction=direction)
        if active_thread_label is None:
            return
        self._set_render_state(
            replace(
                self.render_state,
                bottom_pane=replace(
                    self.render_state.bottom_pane,
                    footer=replace(
                        self.render_state.bottom_pane.footer,
                        active_thread_label=active_thread_label,
                    ),
                ),
            )
        )

    def _open_transcript_overlay(self) -> None:
        if self._transcript_overlay_open or self.render_state.active_overlay_kind is not None:
            return
        overlay = TranscriptOverlay(
            committed=self.render_state.transcript.committed,
            active=self.render_state.transcript.active,
            id="transcript-overlay",
        )
        self.mount(overlay)
        self._transcript_overlay_open = True
        self.set_timer(0, self._focus_transcript_overlay)

    def _close_transcript_overlay(self) -> None:
        if not self._transcript_overlay_open:
            return
        if self.query("#transcript-overlay"):
            self.query_one("#transcript-overlay", TranscriptOverlay).remove()
        self._transcript_overlay_open = False
        self.set_timer(0, self._focus_primary_input)

    def _sync_transcript_overlay(self) -> None:
        if not self._transcript_overlay_open or not self.query("#transcript-overlay"):
            return
        self.query_one("#transcript-overlay", TranscriptOverlay).set_state(
            committed=self.render_state.transcript.committed,
            active=self.render_state.transcript.active,
        )

    def _render_transcript_overlay_text(self) -> str:
        transcript = render_transcript(
            committed=self.render_state.transcript.committed,
            active=self.render_state.transcript.active,
            width=80,
        ).strip()
        if not transcript:
            transcript = "No transcript yet."
        return f"T R A N S C R I P T\n\n{transcript}"

    def _merge_local_draft_into_runtime_state(self, state: RenderState) -> RenderState:
        if not self.query("#composer-input"):
            return state
        composer = self.query_one("#composer-input", ChatComposer)
        live_text = composer.text
        if live_text == state.bottom_pane.composer.value:
            return state
        if not live_text and not state.bottom_pane.footer.is_task_running:
            return state
        return replace(
            state,
            bottom_pane=replace(
                state.bottom_pane,
                composer=replace(state.bottom_pane.composer, value=live_text),
            ),
        )

    def _handle_overlay_action_key(self, event: events.Key) -> bool:
        active_kind = self.render_state.active_overlay_kind
        if active_kind not in {"approval", "conflict", "launch_resume", "broken_resume"}:
            return False

        buttons = self._overlay_action_buttons()
        if not buttons:
            return False

        if event.key in {"tab", "down"}:
            next_button = self._adjacent_overlay_button(buttons, direction=1)
            self._overlay_action_index = buttons.index(next_button)
            next_button.focus()
            return True
        if event.key in {"shift+tab", "up"}:
            previous_button = self._adjacent_overlay_button(buttons, direction=-1)
            self._overlay_action_index = buttons.index(previous_button)
            previous_button.focus()
            return True
        if event.key in {"enter", "space"}:
            focused = self.focused
            if isinstance(focused, Button) and focused in buttons:
                focused.press()
                return True
            buttons[0].press()
            return True
        return False

    def _overlay_action_buttons(self) -> list[Button]:
        buttons: list[Button] = []
        for button in self.query(Button):
            if button.id and (
                button.id.startswith("review-action-")
                or button.id.startswith("conflict-action-")
                or button.id.startswith("launch-action-")
            ):
                buttons.append(button)
        return buttons

    def _focus_adjacent_overlay_button(self, buttons: list[Button], *, direction: int) -> None:
        self.screen.set_focus(self._adjacent_overlay_button(buttons, direction=direction))

    def _adjacent_overlay_button(self, buttons: list[Button], *, direction: int) -> Button:
        focused = self.focused
        focused_id = focused.id if isinstance(focused, Button) else None
        button_ids = [button.id for button in buttons]
        if focused_id is None or focused_id not in button_ids:
            return buttons[0]
        index = button_ids.index(focused_id)
        return buttons[(index + direction) % len(buttons)]

    def check_action(self, action: str, parameters: tuple[object, ...]) -> bool | None:
        del parameters
        if action in {
            "activate_overlay_action",
            "focus_next_overlay_action",
            "focus_previous_overlay_action",
        }:
            return self.render_state.active_overlay_kind in {
                "approval",
                "conflict",
                "launch_resume",
                "broken_resume",
            }
        return super().check_action(action, ())
