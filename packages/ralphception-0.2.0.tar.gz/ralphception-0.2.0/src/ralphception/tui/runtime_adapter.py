"""Map Ralphception runtime state into a live Codex-style TUI shell."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable
from dataclasses import replace
from datetime import datetime, timezone
import json
from pathlib import Path
import queue
import re
import threading
from time import monotonic
from typing import TYPE_CHECKING, Literal, cast

from ralphception.codex.client import codex_cli_available
from ralphception.codex.config import CodexRuntimeSettings, load_codex_runtime_settings
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import RalphceptionConfig, load_or_create_config as load_repo_config
from ralphception.headless import _format_turn_progress_event
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.interactive_session import (
    InteractiveLaunchState,
    clear_interactive_session_marker,
    load_interactive_session_state,
    resolve_interactive_launch_state,
)
from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    ArtifactWriteEvent,
    BackgroundWaitBeginEvent,
    BackgroundWaitEndEvent,
    BackgroundWaitUpdateEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FailureSummaryEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    MilestoneTranscriptLineEvent,
    PlanUpdatedEvent,
    RequestUserInputRequestedEvent,
    RequestUserInputResolvedEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    ReviewRequestedEvent,
    ReviewResolvedEvent,
    ReviewDecision,
    RuntimeFrontend,
    RuntimeStatusUpdatedEvent,
    RuntimeStep,
    ReviewKind,
)
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.runtime.supervisor import (
    _persist_pending_prompt,
    _resume_launch_prompt,
    _startup_pending_prompt,
)
from ralphception.tui.multi_agents import format_agent_picker_item_name
from ralphception.tui.agent_navigation import AgentNavigationDirection, AgentNavigationState
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, AssistantCell, CommandCell, SystemCell, UserCell
from ralphception.tui.chatwidget.transcript_store import TranscriptStore
from ralphception.tui.render_state import (
    AgentPickerViewState,
    BottomPaneState,
    ComposerState,
    FooterState,
    OverlayState,
    RequestUserInputViewState,
    RenderState,
    StatusIndicatorState,
    TranscriptState,
)

if TYPE_CHECKING:
    from ralphception.headless import HeadlessRunResult


_COMMAND_COMPLETED_RE = re.compile(r"^Command completed(?: \(exit (?P<code>\d+)\))?: (?P<command>.+)$")
_QUEUED_FOLLOW_UP_WINDOW_SECONDS = 2.0
_QUEUED_MESSAGE_PREVIEW_SECONDS = 0.2
_MIN_RUNNING_STATUS_SECONDS = 0.25


class RuntimeAdapter(RuntimeFrontend):
    """Runtime-to-shell adapter for both snapshot previews and live TUI updates."""

    def __init__(
        self,
        *,
        repo_root: Path,
        approver: str = "tui",
        session_manager_factory=None,
    ) -> None:
        self.repo_root = repo_root
        self.approver = approver
        self._config = _load_or_create_config(repo_root)
        self._codex_settings = load_codex_runtime_settings()
        self._session_manager_factory = session_manager_factory
        self._launch_state = resolve_interactive_launch_state(repo_root)
        self._render_state = RenderState.idle_preview(
            repo_root,
            config=self._config,
            codex_settings=self._codex_settings,
        )
        self._updates: queue.Queue[Callable[[RenderState], RenderState]] = queue.Queue()
        self._worker: threading.Thread | None = None
        self._turn_worker: threading.Thread | None = None
        self._running = False
        self._queued_messages: deque[tuple[str, float]] = deque()
        self._queue_lock = threading.Lock()
        self._agent_message_chunks: dict[str, list[str]] = {}
        self._transcript_store = TranscriptStore()
        self._startup_source_repos: tuple[str, ...] = ()
        self._active_run_id: str | None = None
        self._active_thread_label: str | None = None
        self._agent_navigation = AgentNavigationState()
        self._shared_session_manager: object | None = None
        self._shared_session_manager_initialized = False
        self._launch_resume_requested = False

    def load_render_state(self) -> RenderState:
        """Return a point-in-time render-state snapshot for tests and previews."""
        base_state = RenderState.idle_preview(
            self.repo_root,
            config=self._config,
            codex_settings=self._codex_settings,
        )
        prompt_state = load_interactive_session_state(self.repo_root)
        if prompt_state.pending_prompts:
            state = _apply_pending_prompt_shell_state(
                base_state,
                prompt=prompt_state.pending_prompts[0],
                source_repos=tuple(prompt_state.bootstrap_source_repos),
            )
            self._render_state = state
            return state
        if self._launch_state.kind in {"resumable", "broken_resume"}:
            self._render_state = base_state
            return base_state
        supervisor = self._build_supervisor()
        step = supervisor.step()
        prompt = step.pending_prompt
        if prompt is not None and prompt.prompt_kind == "startup_prompt":
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
                bootstrap_source_repos=self._startup_source_repos,
            )
            state = _apply_pending_prompt_shell_state(
                base_state,
                prompt=prompt,
                source_repos=self._startup_source_repos,
            )
            self._render_state = state
            return state
        if prompt is not None and prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"}:
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id="run-root",
                active_thread_id=prompt.thread_id,
            )
            state = _apply_pending_prompt_shell_state(base_state, prompt=prompt, source_repos=())
            self._render_state = state
            return state
        if prompt is not None and prompt.prompt_kind == "launch_conflict":
            state = replace(
                base_state,
                announcement_rows=("This workspace already has an unfinished Ralphception session.",),
                bottom_pane=replace(
                    base_state.bottom_pane,
                    footer=_footer_with_left_hint(base_state.bottom_pane.footer, "Esc close"),
                    view_stack=(
                        OverlayState(
                            kind="conflict",
                            title="Resume or replace the current session",
                            summary=prompt.question,
                            actions=("resume", "override", "abort"),
                        ),
                    ),
                ),
            )
            self._render_state = state
            return state
        state = self._state_from_step(step)
        self._render_state = state
        return state

    def has_pending_prompt(self) -> bool:
        if load_interactive_session_state(self.repo_root).pending_prompts:
            return True
        step = self._build_supervisor().step()
        return step.pending_prompt is not None

    def current_render_state(self) -> RenderState:
        return self._render_state

    def add_startup_source_repo(self, repo_path: str) -> None:
        normalized = tuple(_parse_source_repos(repo_path))
        if not normalized:
            return
        next_repos = tuple(dict.fromkeys((*self._startup_source_repos, *normalized)))
        self._startup_source_repos = next_repos
        if len(normalized) == 1:
            self._transcript_store.commit_system_message(f"Added source repo: {normalized[0]}")
        else:
            self._transcript_store.commit_system_message(f"Added source repos: {', '.join(normalized)}")
        prompt = _startup_pending_prompt(self.repo_root, source_repos=next_repos)
        _persist_pending_prompt(
            self.repo_root,
            prompt,
            root_thread_id=prompt.thread_id,
            active_thread_id=prompt.thread_id,
            bootstrap_source_repos=next_repos,
        )
        self._render_state = replace(
            _apply_startup_shell_state(self._render_state, source_repos=next_repos),
            transcript=_project_transcript_state(self._transcript_store),
        )

    def resume_last_session(self) -> bool:
        if self._launch_state.kind != "resumable":
            return False
        self._transcript_store.commit_system_message("Resuming the previous session.")
        self._active_run_id = self._launch_state.active_run_id or self._launch_state.root_run_id
        self._launch_state = InteractiveLaunchState(kind="fresh")
        self._launch_resume_requested = True
        self._enqueue(lambda _state: self._state_from_step(self._build_supervisor().step()))
        return True

    def startup_prompt_pending(self) -> bool:
        prompt_state = load_interactive_session_state(self.repo_root)
        return any(prompt.prompt_kind == "startup_prompt" for prompt in prompt_state.pending_prompts)

    def replace_render_state(self, render_state: RenderState) -> None:
        self._render_state = render_state
        self._transcript_store.synchronize(
            committed=render_state.transcript.committed,
            active=render_state.transcript.active,
        )

    def apply_launch_action(self, action: str) -> None:
        if self._launch_state.kind not in {"resumable", "broken_resume"}:
            return
        if action == "resume" and self._launch_state.kind == "resumable":
            self._active_run_id = self._launch_state.active_run_id or self._launch_state.root_run_id
            self._launch_state = InteractiveLaunchState(kind="fresh")
            self._launch_resume_requested = True
            self._enqueue(lambda _state: self._state_from_step(self._build_supervisor().step()))
            return
        if action == "start_fresh":
            _clear_runtime_workspace(self.repo_root)
            clear_interactive_session_marker(self.repo_root)
            self._active_run_id = None
            self._active_thread_label = None
            self._agent_navigation = AgentNavigationState()
            self._shared_session_manager = None
            self._shared_session_manager_initialized = False
            self._transcript_store = TranscriptStore()
            self._launch_state = resolve_interactive_launch_state(self.repo_root)
            self._enqueue(lambda _state: self.load_render_state())
            return
        if action == "cancel":
            self._enqueue(
                lambda state: replace(
                    state,
                    announcement_rows=("Launch cancelled.",),
                )
            )

    def start(self) -> None:
        if self._worker is not None and self._worker.is_alive():
            return
        self._worker = threading.Thread(
            target=self._run_supervisor_forever,
            name="ralphception-tui-runtime",
            daemon=True,
        )
        self._worker.start()

    def can_run_live(self) -> bool:
        return self._session_manager_factory is not None or codex_cli_available()

    def submit_message(self, *, text: str, render_immediately: bool = True) -> None:
        if (
            text.strip()
            and not self._launch_resume_requested
            and self._launch_state.kind in {"resumable", "broken_resume"}
        ):
            self._reset_for_fresh_launch()
        prompt_state = load_interactive_session_state(self.repo_root)
        if prompt_state.pending_prompts:
            self._resolve_prompt_from_composer(
                prompt=prompt_state.pending_prompts[0],
                user_text=text,
                render_immediately=render_immediately,
                source_repos=tuple(prompt_state.bootstrap_source_repos),
            )
            return
        if self._turn_worker is not None and self._turn_worker.is_alive():
            self.queue_message(text=text, render_immediately=render_immediately)
            return
        startup_source_repos = tuple(
            dict.fromkeys((*prompt_state.bootstrap_source_repos, *self._startup_source_repos))
        )
        if StartupBootstrapController(self.repo_root).needs_bootstrap():
            prompt = _startup_pending_prompt(
                self.repo_root,
                source_repos=startup_source_repos,
            )
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
                bootstrap_source_repos=startup_source_repos,
            )
            self._resolve_prompt_from_composer(
                prompt=prompt,
                user_text=text,
                render_immediately=render_immediately,
                source_repos=startup_source_repos,
            )
            return
        if render_immediately:
            self._transcript_store.commit_user_message(text)
            self._enqueue(
                lambda state, text=text: replace(
                    state,
                    announcement_rows=(),
                    transcript=_project_transcript_state(self._transcript_store),
                    bottom_pane=replace(
                        state.bottom_pane,
                        composer=replace(state.bottom_pane.composer, value=""),
                        status_indicator=StatusIndicatorState(header="Working"),
                        footer=_footer_with_left_hint(
                            state.bottom_pane.footer,
                            "Ctrl+C interrupt",
                            is_task_running=True,
                        ),
                        popup=None,
                    ),
                )
            )
        self._turn_worker = threading.Thread(
            target=self._run_live_turn,
            kwargs={"initial_input": text},
            name="ralphception-tui-turn",
            daemon=True,
        )
        self._turn_worker.start()

    def _resolve_prompt_from_composer(
        self,
        *,
        prompt: PendingPrompt,
        user_text: str,
        render_immediately: bool,
        source_repos: tuple[str, ...],
    ) -> None:
        supervisor = self._build_supervisor()
        result = supervisor.resolve_pending_prompt(
            thread_id=prompt.thread_id,
            user_text=user_text,
        )
        if render_immediately:
            self._transcript_store.commit_user_message(user_text)

        resumed_thread_label: str | None = None

        if result.kind != "resolved" or result.action is None:
            clarification = result.clarifying_question or prompt.question
            self._transcript_store.apply(AssistantFinalEvent(text=clarification))
            self._enqueue(
                lambda state, clarification=clarification, prompt=prompt, source_repos=source_repos: _project_transcript_store_runtime_state(
                    _apply_pending_prompt_shell_state(
                        replace(
                            state,
                            announcement_rows=(),
                            transcript=_project_transcript_state(self._transcript_store),
                            bottom_pane=replace(
                                state.bottom_pane,
                                composer=replace(state.bottom_pane.composer, value=""),
                            ),
                        ),
                        prompt=prompt,
                        source_repos=source_repos,
                        include_transcript_message=False,
                    ),
                    self._transcript_store,
                    idle_hint="? for shortcuts",
                )
            )
            return

        if prompt.prompt_kind == "startup_prompt":
            self._startup_source_repos = ()
            self._launch_state = InteractiveLaunchState(kind="fresh")
        elif prompt.prompt_kind == "resume_session" and result.action == "resume":
            launch_state = self._launch_state
            resumed_run_id = (
                prompt.blocked_continuation.run_id
                if prompt.blocked_continuation is not None
                else launch_state.active_run_id or launch_state.root_run_id
            )
            self._launch_state = InteractiveLaunchState(kind="fresh")
            self._launch_resume_requested = True
            self._active_run_id = resumed_run_id
            dashboard_state = self._state_from_step(supervisor.step())
            resumed_thread_label = dashboard_state.bottom_pane.footer.active_thread_label
            self._active_thread_label = resumed_thread_label
        elif prompt.prompt_kind == "resume_session" and result.action == "start_fresh":
            self._launch_state = resolve_interactive_launch_state(self.repo_root)
            self._active_run_id = None
            self._active_thread_label = None
        if prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"}:
            self._enqueue(
                lambda state, review_kind=_review_kind_from_prompt_kind(prompt.prompt_kind), resolution=result.action: _apply_frontend_event(
                    state,
                    ReviewResolvedEvent(review_kind=review_kind, resolution=resolution),
                    self._transcript_store,
                )
            )
        else:
            resolved_message = _resolved_prompt_message(prompt.prompt_kind, result.action)
            if resolved_message:
                self._transcript_store.commit_system_message(resolved_message)
                self._enqueue(
                    lambda state: _project_transcript_store_runtime_state(
                        replace(
                            state,
                            transcript=_project_transcript_state(self._transcript_store),
                        ),
                        self._transcript_store,
                        idle_hint=(
                            "Reply in chat · Ctrl+C quit"
                            if state.bottom_pane.startup_prompt_active
                            else "? for shortcuts"
                        ),
                    )
                )

        should_resume_runtime = (
            prompt.prompt_kind == "startup_prompt"
            or (prompt.prompt_kind == "resume_session" and result.action == "resume")
            or (prompt.prompt_kind == "launch_conflict" and result.action == "override")
            or (prompt.prompt_kind in {"spec_review", "execution_bundle"} and result.action == "approve")
            or (prompt.prompt_kind == "recovery_review" and result.action in {"resume", "retry", "restart", "replace"})
        )
        if should_resume_runtime:
            self._enqueue(
                lambda state, resumed_thread_label=resumed_thread_label: replace(
                    state,
                    transcript=_project_transcript_state(self._transcript_store),
                    bottom_pane=replace(
                        state.bottom_pane,
                        composer=replace(
                            state.bottom_pane.composer,
                            placeholder="Send the next instruction to Ralphception",
                            value="",
                            input_enabled=True,
                        ),
                        startup_prompt_active=False,
                        status_indicator=StatusIndicatorState(header="Working"),
                        footer=_footer_with_left_hint(
                            replace(
                                state.bottom_pane.footer,
                                active_thread_label=(
                                    resumed_thread_label
                                    if resumed_thread_label is not None
                                    else state.bottom_pane.footer.active_thread_label
                                ),
                            ),
                            "Ctrl+C interrupt",
                            is_task_running=True,
                        ),
                        view_stack=(),
                        popup=None,
                    ),
                )
            )
            self.start()
            return

        if result.action == "start_fresh":
            self._startup_source_repos = ()
        self._launch_state = resolve_interactive_launch_state(self.repo_root)
        self._enqueue(lambda _state: self.load_render_state())

    def queue_message(self, *, text: str, render_immediately: bool = True) -> None:
        with self._queue_lock:
            self._queued_messages.append((text, monotonic()))
        if render_immediately:
            self._enqueue(
                lambda state, text=text: replace(
                    state,
                    bottom_pane=replace(
                        state.bottom_pane,
                        queued_messages=(*state.bottom_pane.queued_messages, text),
                    ),
                )
            )

    def pop_last_queued_message(self) -> str | None:
        with self._queue_lock:
            if not self._queued_messages:
                return None
            message, _queued_at = self._queued_messages.pop()
        return message

    def drain_render_state(self) -> RenderState | None:
        changed = False
        while True:
            try:
                updater = self._updates.get_nowait()
            except queue.Empty:
                break
            self._render_state = updater(self._render_state)
            changed = True
        return self._render_state if changed else None

    def drain_next_render_state(self) -> RenderState | None:
        try:
            updater = self._updates.get_nowait()
        except queue.Empty:
            return None
        self._render_state = updater(self._render_state)
        return self._render_state

    def apply_review_action(self, action: str) -> None:
        prompt_state = load_interactive_session_state(self.repo_root)
        if prompt_state.pending_prompts:
            self._resolve_prompt_from_composer(
                prompt=prompt_state.pending_prompts[0],
                user_text=action,
                render_immediately=False,
                source_repos=tuple(prompt_state.bootstrap_source_repos),
            )
            return
        self._build_supervisor().apply_review_decision(
            ReviewDecision(
                action=cast(
                    Literal["approve", "resume", "retry", "restart", "replace", "abort", "pause"],
                    action,
                ),
                approver=self.approver,
            )
        )

    def apply_conflict_action(self, action: str) -> None:
        prompt_state = load_interactive_session_state(self.repo_root)
        if not prompt_state.pending_prompts:
            return
        self._resolve_prompt_from_composer(
            prompt=prompt_state.pending_prompts[0],
            user_text=action,
            render_immediately=False,
            source_repos=tuple(prompt_state.bootstrap_source_repos),
        )

    def agent_picker_view(self) -> AgentPickerViewState | None:
        engine = self._current_engine()
        if engine is None:
            return None

        self._sync_agent_navigation(engine)
        if not self._agent_navigation.has_non_primary_thread(engine.root_run.run_id):
            return None

        return AgentPickerViewState(
            title="Agents",
            active_thread_id=_resolve_active_run(engine, self._active_run_id).run_id,
            rows=tuple(
                (
                    thread_id,
                    _agent_picker_label(
                        thread_id=thread_id,
                        entry=entry.nickname if entry is not None else None,
                        role=None if entry is None else entry.role,
                        primary_thread_id=engine.root_run.run_id,
                    ),
                )
                for thread_id, entry in self._agent_navigation.ordered_threads()
            ),
        )

    def select_agent_thread(self, *, thread_id: str, label: str) -> None:
        self._active_run_id = thread_id
        self._active_thread_label = label

    def cycle_agent_thread(self, *, direction: Literal["previous", "next"]) -> str | None:
        engine = self._current_engine()
        if engine is None:
            return None

        self._sync_agent_navigation(engine)
        current_run = _resolve_active_run(engine, self._active_run_id)
        thread_id = self._agent_navigation.adjacent_thread_id(
            current_run.run_id,
            AgentNavigationDirection.PREVIOUS
            if direction == "previous"
            else AgentNavigationDirection.NEXT,
        )
        if thread_id is None:
            return None
        entry = self._agent_navigation.get(thread_id)
        label = _agent_picker_label(
            thread_id=thread_id,
            entry=None if entry is None else entry.nickname,
            role=None if entry is None else entry.role,
            primary_thread_id=engine.root_run.run_id,
        )
        self.select_agent_thread(thread_id=thread_id, label=label)
        return label

    def interrupt_active_turn(self) -> bool:
        engine = self._current_engine()
        if engine is None or engine.session_manager is None:
            return False

        abort_session = getattr(engine.session_manager, "abort_session", None)
        if not callable(abort_session):
            return False

        current_run = _resolve_active_run(engine, self._active_run_id)
        restored_messages = self._render_state.bottom_pane.queued_messages or self._drain_queued_message_texts()
        abort_session(run_id=current_run.run_id)
        self._transcript_store.clear_live_state()
        self._enqueue(
            lambda state, restored_messages=restored_messages: replace(
                state,
                transcript=_project_transcript_state(self._transcript_store),
                bottom_pane=replace(
                    state.bottom_pane,
                    composer=replace(
                        state.bottom_pane.composer,
                        value=_restore_queued_messages_into_composer(
                            existing_draft=state.bottom_pane.composer.value,
                            queued_messages=restored_messages,
                        ),
                    ),
                    queued_messages=(),
                    status_indicator=None,
                    popup=None,
                    footer=_footer_with_left_hint(
                        state.bottom_pane.footer,
                        "? for shortcuts",
                        is_task_running=False,
                    ),
                ),
            )
        )
        return True

    def model_help_lines(self) -> tuple[str, ...]:
        settings = self._codex_settings
        details = " ".join(
            part
            for part in (settings.model, settings.reasoning_effort, settings.service_tier)
            if part
        )
        return (
            "Model settings are inherited from Codex config.",
            f"Current: {details}".strip(),
            f"Change {settings.config_path} or update it in the Codex app, then restart Ralphception.",
        )

    def emit_event(self, event: FrontendEvent) -> None:
        if event.message.startswith("Child run created: "):
            child_run_id = event.message.removeprefix("Child run created: ").strip()
            if child_run_id:
                self._activate_run_by_id(child_run_id)
                label = self._active_thread_label
                if label is not None:
                    wait_message = f"Waiting for {label.split(' [', 1)[0]} to start the Ralph loop."
                    self._enqueue(
                        lambda state, label=label, wait_message=wait_message: replace(
                            state,
                            bottom_pane=replace(
                                state.bottom_pane,
                                status_indicator=_status_indicator(
                                    state.bottom_pane.status_indicator,
                                    header="Working",
                                    inline_message=wait_message,
                                ),
                                footer=replace(state.bottom_pane.footer, active_thread_label=label),
                            ),
                        )
                    )
            return
        self._enqueue(lambda state, event=event: _apply_frontend_event(state, event, self._transcript_store))

    def emit_status(self, step: RuntimeStep) -> None:
        self._enqueue(lambda state: _apply_runtime_step(state, step))

    def finish(self, step: RuntimeStep) -> None:
        self._enqueue(lambda state: _apply_runtime_step(state, step))

    def _build_supervisor(self) -> RuntimeSupervisor:
        supervisor = RuntimeSupervisor(
            repo_root=self.repo_root,
            approver=self.approver,
            session_manager_factory=self._shared_session_manager_factory,
        )
        if self._launch_resume_requested:
            supervisor._launch_resume_requested = True
        return supervisor

    def _current_engine(self):
        supervisor = self._build_supervisor()
        step = supervisor.step()
        return step.engine

    def _sync_agent_navigation(self, engine) -> None:
        self._agent_navigation.upsert(
            engine.root_run.run_id,
            nickname=None,
            role=None,
            is_closed=engine.root_run.status in {"completed", "failed"},
        )
        child_runs = [run for run in engine.runs() if run.run_id != engine.root_run.run_id]
        for index, child_run in enumerate(child_runs, start=1):
            self._agent_navigation.upsert(
                child_run.run_id,
                nickname=_child_run_nickname(child_run.run_id, index=index),
                role="worker",
                is_closed=child_run.status in {"completed", "failed"},
            )

    def _sync_active_run(self, engine):
        active_run = _resolve_active_run(
            engine,
            _preferred_active_run_id(
                repo_root=self.repo_root,
                engine=engine,
                explicit_active_run_id=self._active_run_id,
            ),
        )
        self._active_run_id = active_run.run_id
        self._active_thread_label = self._agent_navigation.active_agent_label(
            active_run.run_id,
            primary_thread_id=engine.root_run.run_id,
        )
        return active_run

    def _activate_run_by_id(self, run_id: str) -> None:
        self._active_run_id = run_id
        try:
            engine = self._current_engine()
        except Exception:
            engine = None
        if engine is None:
            match = re.search(r"(\\d+)$", run_id)
            worker_index = int(match.group(1)) if match is not None else 1
            self._active_thread_label = _agent_picker_label(
                thread_id=run_id,
                entry=_child_run_nickname(run_id, index=worker_index),
                role="worker",
                primary_thread_id="run-root",
            )
            return
        self._sync_agent_navigation(engine)
        self._active_thread_label = self._agent_navigation.active_agent_label(
            run_id,
            primary_thread_id=engine.root_run.run_id,
        )

    def _shared_session_manager_factory(self, repo_root: Path, config) -> object | None:
        self._config = config
        if self._shared_session_manager_initialized:
            return self._shared_session_manager

        if self._session_manager_factory is not None:
            manager = self._session_manager_factory(repo_root, config)
        elif codex_cli_available():
            manager = CodexSessionManager(workspace_path=str(repo_root), config=config)
        else:
            manager = None

        self._shared_session_manager = manager
        self._shared_session_manager_initialized = True
        return manager

    def _state_from_step(self, step: RuntimeStep) -> RenderState:
        state = RenderState.idle_preview(
            self.repo_root,
            config=self._config,
            codex_settings=self._codex_settings,
        )
        prompt = step.pending_prompt
        if prompt is not None and prompt.prompt_kind == "startup_prompt":
            return _apply_pending_prompt_shell_state(
                state,
                prompt=prompt,
                source_repos=self._startup_source_repos,
            )
        if prompt is not None and prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"}:
            return _apply_pending_prompt_shell_state(
                state,
                prompt=prompt,
                source_repos=(),
            )
        if prompt is not None and prompt.prompt_kind == "launch_conflict":
            return replace(
                state,
                announcement_rows=("This workspace already has an unfinished Ralphception session.",),
                bottom_pane=replace(
                    state.bottom_pane,
                    footer=_footer_with_left_hint(state.bottom_pane.footer, "Esc close"),
                    view_stack=(
                        OverlayState(
                            kind="conflict",
                            title="Resume or replace the current session",
                            summary=prompt.question,
                            actions=("resume", "override", "abort"),
                        ),
                    ),
                ),
            )
        if step.kind == "dashboard" and step.engine is not None:
            self._sync_agent_navigation(step.engine)
            active_run = self._sync_active_run(step.engine)
            return replace(
                state,
                header_card=replace(
                    state.header_card,
                    mission_label=None,
                ),
                announcement_rows=(),
                bottom_pane=replace(
                    state.bottom_pane,
                    composer=ComposerState(
                        placeholder="Send the next instruction to Ralphception",
                    ),
                    startup_prompt_active=False,
                    startup_source_repos=(),
                    status_indicator=None,
                    pending_thread_approvals=_pending_thread_approval_labels(
                        engine=step.engine,
                        active_run_id=active_run.run_id,
                        agent_navigation=self._agent_navigation,
                    ),
                    footer=FooterState(
                        left_hint="? for shortcuts",
                        model_name=state.bottom_pane.footer.model_name,
                        reasoning_effort=state.bottom_pane.footer.reasoning_effort,
                        latency_label=state.bottom_pane.footer.latency_label,
                        directory_label=state.bottom_pane.footer.directory_label,
                        status_line_enabled=True,
                        status_line_value=state.bottom_pane.footer.status_line_value,
                        quota_label=state.bottom_pane.footer.quota_label,
                        active_thread_label=self._agent_navigation.active_agent_label(
                            active_run.run_id,
                            primary_thread_id=step.engine.root_run.run_id,
                        ),
                    ),
                    view_stack=(),
                    popup=None,
                ),
                transcript=_project_transcript_state(self._transcript_store),
            )
        return state

    def _reset_for_fresh_launch(self) -> None:
        self._build_supervisor().request_start_fresh_launch()
        self._active_run_id = None
        self._active_thread_label = None
        self._agent_navigation = AgentNavigationState()
        self._shared_session_manager = None
        self._shared_session_manager_initialized = False
        self._transcript_store = TranscriptStore()
        self._launch_state = InteractiveLaunchState(kind="fresh")

    def _run_supervisor_forever(self) -> None:
        self._running = True
        try:
            supervisor = self._build_supervisor()
            self._launch_resume_requested = False
            result = supervisor.run(frontend=self)
        except Exception as exc:
            error_message = str(exc)
            self._enqueue(lambda state, error_message=error_message: _apply_runtime_failure(state, error_message))
        else:
            if result.mode == "dashboard":
                self._enqueue(lambda _state: self.load_render_state())
            elif result.mode in {"startup", "review"}:
                step = self._build_supervisor().step()
                prompt_state = load_interactive_session_state(self.repo_root)
                prompt = step.pending_prompt
                if prompt is None and prompt_state.pending_prompts:
                    prompt = prompt_state.pending_prompts[0]
                if prompt is not None:
                    source_repos = tuple(prompt_state.bootstrap_source_repos) if prompt.prompt_kind == "startup_prompt" else ()
                    self._enqueue(
                        lambda state, prompt=prompt, source_repos=source_repos: _project_transcript_store_runtime_state(
                            _apply_pending_prompt_shell_state(
                                replace(
                                    state,
                                    transcript=_project_transcript_state(self._transcript_store),
                                ),
                                prompt=prompt,
                                source_repos=source_repos,
                                include_transcript_message=False,
                            ),
                            self._transcript_store,
                            idle_hint="Reply in chat · Ctrl+C quit",
                        )
                    )
                else:
                    self._enqueue(lambda _state: self.load_render_state())
            else:
                self._enqueue(lambda state, result=result: _apply_run_result(state, result))
        finally:
            self._running = False

    def _enqueue(self, updater: Callable[[RenderState], RenderState]) -> None:
        self._updates.put(updater)

    def _run_live_turn(self, *, initial_input: str) -> None:
        current_input = initial_input
        turn_started_at = monotonic()
        try:
            while True:
                self._run_single_turn(current_input)
                next_input = self._wait_for_next_queued_message(
                    timeout=_QUEUED_FOLLOW_UP_WINDOW_SECONDS
                )
                if next_input is None:
                    break
                self._transcript_store.commit_user_message(next_input)
                self._enqueue(
                    lambda state, next_input=next_input: replace(
                        state,
                        transcript=_project_transcript_state(self._transcript_store),
                        bottom_pane=replace(
                            state.bottom_pane,
                            composer=replace(state.bottom_pane.composer, value=""),
                            queued_messages=_drop_first_queued_message(state.bottom_pane.queued_messages),
                            status_indicator=_status_indicator(
                                state.bottom_pane.status_indicator,
                                header="Working",
                            ),
                            footer=_footer_with_left_hint(
                                state.bottom_pane.footer,
                                "Ctrl+C interrupt",
                                is_task_running=True,
                            ),
                        ),
                    )
                )
                current_input = next_input
        except Exception as exc:  # pragma: no cover - defensive runtime guard
            error_message = str(exc)
            self._enqueue(lambda state, error_message=error_message: _apply_runtime_failure(state, error_message))
        finally:
            remaining_status_window = _MIN_RUNNING_STATUS_SECONDS - (monotonic() - turn_started_at)
            if remaining_status_window > 0:
                threading.Event().wait(remaining_status_window)
            self._transcript_store.clear_turn_wait()
            self._enqueue(
                lambda state: _project_transcript_store_runtime_state(
                    replace(
                        state,
                        transcript=_project_transcript_state(self._transcript_store),
                    ),
                    self._transcript_store,
                    idle_hint="? for shortcuts",
                    preserve_running_footer=False,
                )
            )
            self._turn_worker = None

    def _run_single_turn(self, input_text: str) -> None:
        engine = self._current_engine()
        if engine is None or engine.session_manager is None:
            raise RuntimeError("No live execution backend is available for interactive turns.")

        session_manager = engine.session_manager
        target_run = _resolve_active_run(engine, self._active_run_id)
        _ensure_run_session(engine, target_run, repo_root=self.repo_root)

        run_turn = getattr(session_manager, "run_turn", None)
        iter_raw_events = getattr(session_manager, "iter_raw_events", None)
        stream_raw_events = getattr(session_manager, "stream_raw_events", None)
        if not callable(run_turn):
            raise RuntimeError("session manager does not support live turn execution")

        run_turn(run_id=target_run.run_id, input_text=input_text)
        if callable(iter_raw_events):
            raw_events = iter_raw_events(run_id=target_run.run_id, until_methods={"turn/completed", "error"})
        elif callable(stream_raw_events):
            raw_events = stream_raw_events(run_id=target_run.run_id, until_methods={"turn/completed", "error"})
        else:
            raise RuntimeError("session manager does not support raw event streaming")

        self.emit_event(
            FrontendEvent(
                message=f"Turn started: {target_run.run_id} interactive",
                kind="turn.started",
                run_id=target_run.run_id,
            )
        )
        for raw_event in raw_events:
            progress_event = _format_turn_progress_event(raw_event, self._agent_message_chunks)
            if progress_event is not None:
                self.emit_event(progress_event)
            if raw_event.method == "error":
                raise RuntimeError("session error while running interactive turn")
        self._agent_message_chunks.clear()

    def _consume_next_queued_message(self) -> str | None:
        with self._queue_lock:
            if not self._queued_messages:
                return None
            next_message, queued_at = self._queued_messages[0]
            if monotonic() - queued_at < _QUEUED_MESSAGE_PREVIEW_SECONDS:
                return None
            self._queued_messages.popleft()
            return next_message

    def _wait_for_next_queued_message(self, *, timeout: float) -> str | None:
        deadline = datetime.now(timezone.utc).timestamp() + timeout
        while datetime.now(timezone.utc).timestamp() < deadline:
            next_message = self._consume_next_queued_message()
            if next_message is not None:
                return next_message
            threading.Event().wait(0.01)
        return self._consume_next_queued_message()

    def _drain_queued_message_texts(self) -> tuple[str, ...]:
        with self._queue_lock:
            queued_messages = tuple(message for message, _queued_at in self._queued_messages)
            self._queued_messages.clear()
        return queued_messages

def _apply_frontend_event(state: RenderState, event: FrontendEvent, store: TranscriptStore) -> RenderState:
    if isinstance(event, LiveStatusEvent):
        next_footer = replace(
            state.bottom_pane.footer,
            status_line_enabled=True,
            status_line_value=event.status_line_value,
            quota_label=event.quota_label,
        )
        return replace(
            state,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header="Working",
                ),
                footer=next_footer,
            ),
        )

    if isinstance(event, RuntimeStatusUpdatedEvent):
        next_footer = replace(
            state.bottom_pane.footer,
            status_line_enabled=True,
            status_line_value=event.status_line_value,
            quota_label=event.quota_label,
        )
        return replace(
            state,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header="Working",
                ),
                footer=next_footer,
            ),
        )

    if isinstance(event, CurrentWaitingStateEvent):
        process_id = event.process_id or "background"
        if event.cleared or event.label is None:
            store.apply(BackgroundWaitEndEvent(process_id=process_id))
        elif store.waiting_state is None or store.waiting_state.process_id != process_id:
            store.apply(
                BackgroundWaitBeginEvent(
                    process_id=process_id,
                    command=event.command or event.label,
                    summary=event.label,
                )
            )
        else:
            store.apply(
                BackgroundWaitUpdateEvent(
                    process_id=process_id,
                    summary=event.label,
                )
            )
        return _project_transcript_store_runtime_state(
            replace(
                state,
                transcript=_project_transcript_state(store),
            ),
            store,
            idle_hint="? for shortcuts" if not state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if isinstance(event, CurrentTaskLabelEvent):
        return replace(state, announcement_rows=())

    if isinstance(event, CurrentPlanNodeLabelEvent):
        return replace(state, announcement_rows=())

    if isinstance(event, CurrentLoopLabelEvent):
        return replace(state, announcement_rows=())

    if isinstance(
        event,
        (
            ArtifactWriteEvent,
            LoopLaunchEvent,
            LoopCompletionEvent,
            MilestoneTranscriptLineEvent,
            FailureSummaryEvent,
        ),
    ):
        store.commit_system_message(event.message)
        return _project_transcript_store_runtime_state(
            replace(
                state,
                announcement_rows=(),
                transcript=_project_transcript_state(store),
            ),
            store,
            idle_hint="? for shortcuts" if not state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if isinstance(
        event,
        (
            AssistantDeltaEvent,
            AssistantFinalEvent,
            CommandBeginEvent,
            CommandOutputDeltaEvent,
            CommandEndEvent,
            ReasoningSummaryDeltaEvent,
            ReasoningSectionBreakEvent,
            ReasoningFinalEvent,
            BackgroundWaitBeginEvent,
            BackgroundWaitUpdateEvent,
            BackgroundWaitEndEvent,
            PlanUpdatedEvent,
            ReviewRequestedEvent,
            ReviewResolvedEvent,
            RequestUserInputRequestedEvent,
            RequestUserInputResolvedEvent,
        ),
    ):
        store.apply(event)
        next_state = replace(
            state,
            announcement_rows=(),
            transcript=_project_transcript_state(store),
        )
        if isinstance(event, ReviewRequestedEvent):
            next_state = replace(
                next_state,
                bottom_pane=replace(
                    next_state.bottom_pane,
                    composer=replace(
                        next_state.bottom_pane.composer,
                        placeholder="Reply to continue",
                        input_enabled=True,
                    ),
                    footer=_footer_with_left_hint(
                        next_state.bottom_pane.footer,
                        "Reply in chat · Ctrl+C quit",
                    ),
                    status_indicator=StatusIndicatorState(
                        header="Waiting for your reply",
                        details=_review_title_from_kind(event.review_kind),
                        show_interrupt_hint=False,
                    ),
                    view_stack=(),
                    popup=None,
                ),
            )
        elif isinstance(event, ReviewResolvedEvent):
            next_state = replace(
                next_state,
                bottom_pane=replace(
                    next_state.bottom_pane,
                    composer=replace(
                        next_state.bottom_pane.composer,
                        placeholder="Send the next instruction to Ralphception",
                        input_enabled=True,
                    ),
                    status_indicator=None,
                    view_stack=(),
                    popup=None,
                ),
            )
        elif isinstance(event, RequestUserInputRequestedEvent):
            is_startup_prompt = event.prompt_id == "prompt-run-root-startup"
            next_state = replace(
                next_state,
                bottom_pane=replace(
                    next_state.bottom_pane,
                    startup_prompt_active=False if is_startup_prompt else event.prompt_id == "prompt-run-root-startup",
                    composer=replace(
                        next_state.bottom_pane.composer,
                        placeholder=(
                            "Describe the task or ask a question"
                            if is_startup_prompt
                            else "Reply to continue"
                        ),
                        input_enabled=True,
                    ),
                    footer=_footer_with_left_hint(
                        next_state.bottom_pane.footer,
                        "? for shortcuts"
                        if is_startup_prompt
                        else "Reply in chat · Ctrl+C quit",
                    ),
                    status_indicator=None
                    if is_startup_prompt
                    else StatusIndicatorState(
                        header="Waiting for your reply",
                        details=event.title,
                        show_interrupt_hint=False,
                    ),
                    view_stack=(),
                    popup=None,
                ),
            )
        elif isinstance(event, RequestUserInputResolvedEvent):
            next_state = replace(
                next_state,
                bottom_pane=replace(
                    next_state.bottom_pane,
                    startup_prompt_active=False,
                    composer=replace(
                        next_state.bottom_pane.composer,
                        placeholder="Send the next instruction to Ralphception",
                        input_enabled=True,
                    ),
                    status_indicator=None,
                    view_stack=(),
                    popup=None,
                ),
            )
        elif isinstance(event, PlanUpdatedEvent):
            next_state = replace(
                next_state,
                bottom_pane=replace(
                    next_state.bottom_pane,
                    status_indicator=_status_indicator(
                        next_state.bottom_pane.status_indicator,
                        header=event.active_step,
                    ),
                    footer=_footer_with_left_hint(
                        next_state.bottom_pane.footer,
                        "Ctrl+C interrupt",
                        is_task_running=True,
                    ),
                ),
            )
        return _project_transcript_store_runtime_state(
            next_state,
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )
    if event.kind == "turn.started":
        store.begin_turn_wait()
        return replace(
            state,
            transcript=_project_transcript_state(store),
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header="Working",
                    details="Waiting for Ralphception to respond.",
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
    if event.kind == "stage.started" and event.stage_kind is not None:
        return replace(
            state,
            announcement_rows=(),
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header="Working",
                    inline_message=event.stage_kind,
                ),
                footer=replace(
                    _footer_with_left_hint(
                        state.bottom_pane.footer,
                        "Ctrl+C interrupt",
                        is_task_running=True,
                    ),
                ),
            ),
        )
    if event.kind == "turn.completed":
        store.clear_turn_wait()
        return _project_transcript_store_runtime_state(
            replace(
                state,
                announcement_rows=(),
                transcript=_project_transcript_state(store),
            ),
            store,
            idle_hint="? for shortcuts" if not state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
            preserve_running_footer=store.waiting_state is not None,
        )

    message = event.message
    next_state = replace(state, announcement_rows=())

    if message.startswith("Command started: "):
        command = message.removeprefix("Command started: ")
        return replace(
            next_state,
            transcript=replace(next_state.transcript, active=ActiveCell(prefix="$", text=command)),
            bottom_pane=replace(
                next_state.bottom_pane,
                status_indicator=_status_indicator(
                    next_state.bottom_pane.status_indicator,
                    header="Working",
                    details=command,
                ),
                footer=_footer_with_left_hint(
                    next_state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )

    command_match = _COMMAND_COMPLETED_RE.match(message)
    if command_match is not None:
        command = command_match.group("command")
        exit_code = command_match.group("code")
        store.commit_cell(
            CommandCell(
                command=command,
                status=f"exit {exit_code}" if exit_code is not None else "completed",
            )
        )
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
            ),
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if message.startswith("Agent: "):
        store.commit_cell(AssistantCell(message.removeprefix("Agent: ")))
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
                bottom_pane=replace(
                    next_state.bottom_pane,
                    status_indicator=_status_indicator(
                        next_state.bottom_pane.status_indicator,
                        header="Working",
                    ),
                    footer=_footer_with_left_hint(
                        next_state.bottom_pane.footer,
                        "Ctrl+C interrupt",
                        is_task_running=True,
                    ),
                ),
            ),
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if message.startswith("Bootstrapped "):
        return next_state

    if message.startswith("Resumed "):
        store.commit_system_message("Resumed the previous Ralphception session.")
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
                bottom_pane=replace(
                    next_state.bottom_pane,
                    status_indicator=_status_indicator(
                        next_state.bottom_pane.status_indicator,
                        header="Working",
                    ),
                    footer=_footer_with_left_hint(
                        next_state.bottom_pane.footer,
                        "Ctrl+C interrupt",
                        is_task_running=True,
                    ),
                ),
            ),
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if message.startswith("Stage: "):
        stage_label = message.removeprefix("Stage: ")
        friendly_stage_message = _friendly_stage_message(stage_label)
        if friendly_stage_message is not None:
            store.commit_system_message(friendly_stage_message)
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
                bottom_pane=replace(
                    next_state.bottom_pane,
                    status_indicator=_status_indicator(
                        next_state.bottom_pane.status_indicator,
                        header="Working",
                        inline_message=stage_label,
                    ),
                    footer=replace(
                        _footer_with_left_hint(next_state.bottom_pane.footer, "Ctrl+C interrupt"),
                    ),
                ),
            ),
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    if message.startswith("Session completed: "):
        store.commit_system_message(message)
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
                bottom_pane=replace(
                    next_state.bottom_pane,
                    status_indicator=None,
                    footer=replace(
                        _footer_with_left_hint(next_state.bottom_pane.footer, "? for shortcuts"),
                        active_thread_label=None,
                    ),
                ),
            ),
            store,
            idle_hint="? for shortcuts",
        )

    if message.startswith("Turn started: "):
        return replace(
            next_state,
            bottom_pane=replace(
                next_state.bottom_pane,
                status_indicator=_status_indicator(
                    next_state.bottom_pane.status_indicator,
                    header="Working",
                ),
                footer=_footer_with_left_hint(
                    next_state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )

    if message.startswith("Turn completed: "):
        store.clear_turn_wait()
        return replace(next_state, transcript=_project_transcript_state(store))

    if message == "Socratic intake":
        store.commit_system_message("Preparing the initial spec and plan for this workspace.")
        return _project_transcript_store_runtime_state(
            replace(
                next_state,
                transcript=_project_transcript_state(store),
            ),
            store,
            idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
        )

    store.commit_system_message(message)
    return _project_transcript_store_runtime_state(
        replace(
            next_state,
            transcript=_project_transcript_state(store),
        ),
        store,
        idle_hint="? for shortcuts" if not next_state.bottom_pane.startup_prompt_active else "Reply in chat · Ctrl+C quit",
    )


def _apply_runtime_step(state: RenderState, step: RuntimeStep) -> RenderState:
    if step.kind == "completed":
        return replace(
            state,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=None,
                footer=_footer_with_left_hint(state.bottom_pane.footer, "? for shortcuts", is_task_running=False),
            ),
        )
    if step.kind == "failed":
        return replace(
            state,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=None,
                footer=_footer_with_left_hint(state.bottom_pane.footer, "? for shortcuts", is_task_running=False),
            ),
        )
    return state


def _apply_run_result(state: RenderState, result: HeadlessRunResult) -> RenderState:
    message = f"Runtime {result.mode}: {result.root_run_id or 'session'}"
    return replace(
        state,
        transcript=_append_committed_cell(
            replace(state.transcript, active=None),
            SystemCell(message),
        ),
        bottom_pane=replace(
            state.bottom_pane,
            status_indicator=None,
            footer=_footer_with_left_hint(state.bottom_pane.footer, "? for shortcuts", is_task_running=False),
        ),
    )


def _apply_runtime_failure(state: RenderState, error_message: str) -> RenderState:
    return replace(
        state,
        announcement_rows=(f"Runtime failed: {error_message}",),
        transcript=_append_committed_cell(
            replace(state.transcript, active=None),
            SystemCell(f"Runtime failed: {error_message}"),
        ),
        bottom_pane=replace(
            state.bottom_pane,
            status_indicator=None,
            footer=_footer_with_left_hint(state.bottom_pane.footer, "? for shortcuts", is_task_running=False),
        ),
    )


def _append_committed_cell(transcript: TranscriptState, cell) -> TranscriptState:
    return replace(
        transcript,
        committed=(*transcript.committed, cell),
    )


def _friendly_stage_message(stage_label: str) -> str | None:
    normalized = stage_label.strip().lower()
    messages = {
        "intake": "Collecting the initial task context.",
        "spec": "Drafting the initial spec for this workspace.",
        "plan": "Turning the approved spec into an execution plan.",
        "execute": "Starting the Ralph loop and execution phase.",
        "merge": "Preparing the merge-ready result.",
        "audit": "Running the final audit checks.",
    }
    return messages.get(normalized)


def _apply_startup_shell_state(
    state: RenderState,
    *,
    source_repos: tuple[str, ...],
) -> RenderState:
    return _apply_pending_prompt_shell_state(
        state,
        prompt=PendingPrompt(
            thread_id="run-root",
            owner_run_id="run-root",
            prompt_id="prompt-run-root-startup-preview",
            prompt_kind="startup_prompt",
            title="Start first task",
            question="Describe what you want Ralphception to work on in this workspace.",
            allowed_actions=("bootstrap",),
            context={},
            blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
        ),
        source_repos=source_repos,
    )


def _apply_launch_resume_shell_state(
    state: RenderState,
    *,
    launch_state: InteractiveLaunchState,
) -> RenderState:
    if launch_state.kind == "resumable":
        prompt = _resume_launch_prompt(
            repo_root=Path(state.header_card.directory_label),
            active_run_id=launch_state.active_run_id or launch_state.root_run_id or "run-root",
            existing_seed_prompt="",
        )
    else:
        prompt = _broken_resume_pending_prompt(
            active_run_id=launch_state.active_run_id or launch_state.root_run_id or "run-root",
        )
    return _apply_pending_prompt_shell_state(state, prompt=prompt, source_repos=())


def _apply_pending_prompt_shell_state(
    state: RenderState,
    *,
    prompt,
    source_repos: tuple[str, ...],
    include_transcript_message: bool = True,
) -> RenderState:
    is_startup_prompt = prompt.prompt_kind == "startup_prompt"
    next_transcript = state.transcript
    if include_transcript_message and not is_startup_prompt:
        next_transcript = _append_committed_cell(
            replace(state.transcript, active=None),
            SystemCell(prompt.question),
        )
    if is_startup_prompt:
        return replace(
            state,
            announcement_rows=(),
            transcript=next_transcript,
            bottom_pane=replace(
                state.bottom_pane,
                startup_prompt_active=False,
                startup_source_repos=source_repos,
                composer=replace(
                    state.bottom_pane.composer,
                    placeholder="Describe the task or ask a question",
                    value="",
                    input_enabled=True,
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "? for shortcuts",
                    is_task_running=False,
                ),
                status_indicator=None,
                view_stack=(),
                popup=None,
            ),
        )
    return replace(
        state,
        announcement_rows=(),
        transcript=next_transcript,
        bottom_pane=replace(
            state.bottom_pane,
            startup_prompt_active=is_startup_prompt,
            startup_source_repos=source_repos if is_startup_prompt else (),
            composer=replace(
                state.bottom_pane.composer,
                placeholder=(
                    "Describe what you want Ralphception to work on in this workspace"
                    if is_startup_prompt
                    else "Reply to continue"
                ),
                value="",
                input_enabled=True,
            ),
            footer=_footer_with_left_hint(
                state.bottom_pane.footer,
                "Enter submit · /source add repo · Ctrl+C quit"
                if is_startup_prompt
                else "Reply in chat · Ctrl+C quit",
                is_task_running=False,
            ),
            status_indicator=StatusIndicatorState(
                header="Waiting for your reply",
                details=prompt.title,
                show_interrupt_hint=False,
            ),
            view_stack=(),
            popup=None,
        ),
    )


def _broken_resume_pending_prompt(*, active_run_id: str) -> PendingPrompt:
    return PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-broken-resume",
        prompt_kind="resume_session",
        title="Resume failed",
        question=(
            "Ralphception found unfinished state, but it cannot restore the last session cleanly. "
            "Reply with start fresh to clear it and begin again."
        ),
        allowed_actions=("start_fresh",),
        context={},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id=active_run_id),
    )


def _startup_announcement_rows(source_repos: tuple[str, ...]) -> tuple[str, ...]:
    source_summary = ", ".join(source_repos) if source_repos else "none"
    return (
        "This workspace needs an initial task before Ralphception can start.",
        "Optional: /source <path> to add source repositories.",
        f"Sources: {source_summary}",
    )


def _resolved_prompt_message(prompt_kind: str, action: str) -> str | None:
    if prompt_kind == "startup_prompt" and action == "bootstrap":
        return None
    if prompt_kind == "resume_session" and action == "resume":
        return "Resuming the previous session."
    if prompt_kind == "resume_session" and action == "start_fresh":
        return "Starting fresh and clearing the interrupted session state."
    if prompt_kind == "launch_conflict" and action == "override":
        return "Starting a fresh session in this workspace."
    if prompt_kind == "launch_conflict" and action == "abort":
        return "Launch aborted."
    if prompt_kind == "recovery_review":
        return f"{action.capitalize()}: recovery_review"
    return None


def _footer_with_left_hint(
    footer: FooterState,
    left_hint: str,
    *,
    is_task_running: bool | None = None,
) -> FooterState:
    if is_task_running is None:
        return replace(footer, left_hint=left_hint)
    return replace(footer, left_hint=left_hint, is_task_running=is_task_running)


def _status_indicator(
    current: StatusIndicatorState | None,
    *,
    header: str,
    details: str | None = None,
    inline_message: str | None = None,
    show_interrupt_hint: bool = True,
) -> StatusIndicatorState:
    if current is None:
        return StatusIndicatorState(
            header=header,
            details=details,
            inline_message=inline_message,
            show_interrupt_hint=show_interrupt_hint,
        )
    return replace(
        current,
        header=header,
        details=details,
        inline_message=inline_message,
        show_interrupt_hint=show_interrupt_hint,
    )


def _pending_thread_approval_labels(*, engine, active_run_id: str, agent_navigation: AgentNavigationState) -> tuple[str, ...]:
    labels: list[str] = []
    for run in engine.runs():
        if run.run_id == active_run_id or run.status != "awaiting_approval":
            continue
        entry = agent_navigation.get(run.run_id)
        labels.append(
            _agent_picker_label(
                thread_id=run.run_id,
                entry=None if entry is None else entry.nickname,
                role=None if entry is None else entry.role,
                primary_thread_id=engine.root_run.run_id,
            )
        )
    return tuple(labels)


def _drop_first_queued_message(messages: tuple[str, ...]) -> tuple[str, ...]:
    if not messages:
        return ()
    return messages[1:]


def _project_transcript_state(store: TranscriptStore) -> TranscriptState:
    return TranscriptState(
        committed=tuple(store.history_cells),
        active=store.active_cell,
    )


def _project_transcript_store_runtime_state(
    state: RenderState,
    store: TranscriptStore,
    *,
    idle_hint: str,
    preserve_running_footer: bool = True,
) -> RenderState:
    transcript = _project_transcript_state(store)
    waiting_state = store.waiting_state
    if waiting_state is not None:
        return replace(
            state,
            transcript=transcript,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=StatusIndicatorState(
                    header="Working",
                    details=waiting_state.command,
                    inline_message=waiting_state.summary,
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
    if store.active_cell is not None:
        active = store.active_cell
        if active.prefix == "$":
            header = "Working"
            details = active.text
            inline_message = None
        elif active.prefix == "thinking":
            header = store.reasoning_header or "Working"
            details = None
            inline_message = active.text
        else:
            header = "Working"
            details = None
            inline_message = active.text
        return replace(
            state,
            transcript=transcript,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header=header,
                    details=details,
                    inline_message=inline_message,
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
    if store.reasoning_header is not None:
        return replace(
            state,
            transcript=transcript,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    state.bottom_pane.status_indicator,
                    header=store.reasoning_header,
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
    if preserve_running_footer and state.bottom_pane.footer.is_task_running:
        current_indicator = state.bottom_pane.status_indicator
        return replace(
            state,
            transcript=transcript,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=_status_indicator(
                    current_indicator,
                    header="Working",
                    details=None if current_indicator is None else current_indicator.details,
                    inline_message=None if current_indicator is None else current_indicator.inline_message,
                ),
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    "Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
    current_indicator = state.bottom_pane.status_indicator
    if current_indicator is not None and not current_indicator.show_interrupt_hint:
        return replace(
            state,
            transcript=transcript,
            bottom_pane=replace(
                state.bottom_pane,
                status_indicator=current_indicator,
                footer=_footer_with_left_hint(
                    state.bottom_pane.footer,
                    idle_hint,
                    is_task_running=False,
                ),
            ),
        )
    return replace(
        state,
        transcript=transcript,
        bottom_pane=replace(
            state.bottom_pane,
            status_indicator=None,
            footer=_footer_with_left_hint(
                state.bottom_pane.footer,
                idle_hint,
                is_task_running=False,
            ),
        ),
    )


def _restore_queued_messages_into_composer(
    *,
    existing_draft: str,
    queued_messages: tuple[str, ...],
) -> str:
    queued_text = "\n".join(message for message in queued_messages if message)
    if not queued_text:
        return existing_draft
    if not existing_draft:
        return queued_text
    return f"{queued_text}\n{existing_draft}"


def _ensure_run_session(engine, run, *, repo_root: Path) -> None:
    session_manager = engine.session_manager
    if session_manager is None:
        raise RuntimeError("session manager is required to start the selected run")

    start_session = getattr(session_manager, "start_session", None)
    get_session_ref = getattr(session_manager, "get_session_ref", None)
    if not callable(start_session) or not callable(get_session_ref):
        raise RuntimeError("session manager does not support session startup")

    workspace_path = repo_root
    if run.codex_session_ref is not None:
        workspace_path = Path(run.codex_session_ref.workspace_path)

    session_ref = get_session_ref(run.run_id)
    if session_ref is not None and Path(session_ref.workspace_path).resolve(strict=False) == workspace_path.resolve(
        strict=False,
    ):
        if run.codex_session_ref != session_ref:
            updated_run = engine.update_run(
                run.run_id,
                status="running",
                codex_session_ref=session_ref,
                updated_at=datetime.now(timezone.utc),
            )
            if updated_run.run_id == engine.root_run.run_id:
                engine.root_run = updated_run
        return

    start_session(
        run_id=run.run_id,
        goal=run.goal,
        parent_run_id=run.parent_run_id,
        workspace_path=str(workspace_path),
    )
    session_ref = get_session_ref(run.run_id)
    if session_ref is None:
        raise RuntimeError("session manager did not return a session reference")
    updated_run = engine.update_run(
        run.run_id,
        status="running",
        codex_session_ref=session_ref,
        updated_at=datetime.now(timezone.utc),
    )
    if updated_run.run_id == engine.root_run.run_id:
        engine.root_run = updated_run


def _resolve_active_run(engine, active_run_id: str | None):
    if active_run_id is None:
        return engine.root_run
    try:
        return engine.run(active_run_id)
    except Exception:
        return engine.root_run


def _preferred_active_run_id(*, repo_root: Path, engine, explicit_active_run_id: str | None) -> str:
    if explicit_active_run_id is not None:
        try:
            engine.run(explicit_active_run_id)
            return explicit_active_run_id
        except Exception:
            pass

    prompt_state = load_interactive_session_state(repo_root)
    current_child_run_id = _workspace_current_child_run_id(repo_root, root_run_id=engine.root_run.run_id)
    active_thread_id = prompt_state.active_thread_id
    if active_thread_id:
        try:
            engine.run(active_thread_id)
        except Exception:
            active_thread_id = None
        else:
            if active_thread_id != engine.root_run.run_id or current_child_run_id is None:
                return active_thread_id

    if current_child_run_id is not None:
        try:
            engine.run(current_child_run_id)
        except Exception:
            pass
        else:
            return current_child_run_id

    return engine.root_run.run_id


def _workspace_current_child_run_id(repo_root: Path, *, root_run_id: str) -> str | None:
    path = repo_root / ".ralphception" / "runs" / root_run_id / "headless-state.json"
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    current_child_run_id = payload.get("current_child_run_id")
    if isinstance(current_child_run_id, str) and current_child_run_id.strip():
        return current_child_run_id
    return None


def _parse_source_repos(raw_text: str) -> list[str]:
    source_repos: list[str] = []
    for line in raw_text.replace(",", "\n").splitlines():
        candidate = line.strip()
        if candidate:
            source_repos.append(candidate)
    return source_repos

def _review_kind_from_prompt_kind(prompt_kind: str) -> ReviewKind:
    if prompt_kind == "recovery_review":
        return "recovery"
    if prompt_kind in {"spec_review", "execution_bundle"}:
        return cast(ReviewKind, prompt_kind)
    return "recovery"


def _review_title_from_kind(review_kind: str) -> str:
    if review_kind == "spec_review":
        return "Spec review"
    if review_kind == "execution_bundle":
        return "Execution bundle review"
    return "Recovery review"


def _child_run_nickname(run_id: str, *, index: int) -> str:
    match = re.search(r"(\d+)$", run_id)
    if match is not None:
        return f"Worker {match.group(1)}"
    return f"Worker {index}"


def _agent_picker_label(
    *,
    thread_id: str,
    entry: str | None,
    role: str | None,
    primary_thread_id: str,
) -> str:
    return format_agent_picker_item_name(
        entry,
        role,
        is_primary=thread_id == primary_thread_id,
    )


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    return load_repo_config(repo_root)


def _format_relative_time(raw_value: object) -> str:
    if not isinstance(raw_value, str):
        return "-"
    try:
        parsed = datetime.fromisoformat(raw_value.replace("Z", "+00:00"))
    except ValueError:
        return "-"
    now = datetime.now(timezone.utc)
    delta = now - parsed.astimezone(timezone.utc)
    total_seconds = int(delta.total_seconds())
    if total_seconds < 60:
        return "just now"
    total_minutes = total_seconds // 60
    if total_minutes < 60:
        suffix = "minute" if total_minutes == 1 else "minutes"
        return f"{total_minutes} {suffix} ago"
    total_hours = total_minutes // 60
    if total_hours < 24:
        suffix = "hour" if total_hours == 1 else "hours"
        return f"{total_hours} {suffix} ago"
    total_days = total_hours // 24
    suffix = "day" if total_days == 1 else "days"
    return f"{total_days} {suffix} ago"


def _clear_runtime_workspace(repo_root: Path) -> None:
    from ralphception.headless import cleanup_mission_workspace
    from ralphception.headless import prune_runtime_root_for_completed_task

    try:
        cleanup_mission_workspace(
            repo_root=repo_root,
            primary_repo_root=repo_root,
        )
    except RuntimeError:
        prune_runtime_root_for_completed_task(repo_root)
