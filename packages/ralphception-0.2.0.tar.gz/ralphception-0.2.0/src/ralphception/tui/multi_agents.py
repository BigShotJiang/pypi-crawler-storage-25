"""Multi-agent picker rendering for the Codex-style shell."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from textual.message import Message

from ralphception.tui.bottom_pane.list_selection import (
    ListSelectionRowState,
    ListSelectionState,
    ListSelectionView,
    render_list_selection,
)
from ralphception.tui.render_state import AgentPickerViewState


@dataclass(frozen=True, slots=True)
class AgentThreadState:
    """Single child-thread row in the agent picker."""

    thread_id: str
    nickname: str | None
    role: str | None
    closed: bool


class AgentPickerView(ListSelectionView):
    """Interactive `/agent` picker backed by the shared list-selection view."""

    class DismissRequested(Message):
        """Posted when the picker should be dismissed."""

    class ThreadSelected(Message):
        """Posted when the user chooses a thread."""

        def __init__(self, thread_id: str, label: str) -> None:
            self.thread_id = thread_id
            self.label = label
            super().__init__()

    def __init__(self, state: AgentPickerViewState, *, id: str | None = None) -> None:
        self._state = state
        super().__init__(_list_state_from_agent_picker(state), id=id)

    def action_dismiss(self) -> None:
        self.post_message(self.DismissRequested())

    def action_select_current(self) -> None:
        row = self.current_row
        if row is None:
            return
        self.post_message(self.ThreadSelected(row.row_id, row.label))


def render_agent_picker(
    rows: Iterable[AgentThreadState],
    *,
    active_thread_id: str | None,
    width: int,
) -> str:
    """Render agent picker rows with the active thread marker."""
    del width
    rendered_rows: list[str] = []
    for row in rows:
        label = _format_agent_label(row)
        prefix = "*" if row.thread_id == active_thread_id else " "
        suffix = " (closed)" if row.closed else ""
        rendered_rows.append(f"{prefix} {label}{suffix}")
    return "\n".join(rendered_rows) + ("\n" if rendered_rows else "")


def render_agent_picker_from_state(state: AgentPickerViewState, *, width: int) -> str:
    """Render a structured agent-picker view state."""
    return render_list_selection(_list_state_from_agent_picker(state), width=width)


def format_agent_picker_item_name(
    nickname: str | None,
    role: str | None,
    *,
    is_primary: bool,
) -> str:
    if is_primary:
        return "Main [default]"
    if nickname and role:
        return f"{nickname} [{role}]"
    if nickname:
        return nickname
    if role:
        return f"[{role}]"
    return "Agent"


def _format_agent_label(row: AgentThreadState) -> str:
    return format_agent_picker_item_name(
        row.nickname,
        row.role,
        is_primary=False,
    )


def _list_state_from_agent_picker(state: AgentPickerViewState) -> ListSelectionState:
    rows = tuple(
        ListSelectionRowState(
            row_id=thread_id,
            label=label,
            is_current=thread_id == state.active_thread_id,
        )
        for thread_id, label in state.rows
    )
    selected_index = 0
    for index, row in enumerate(rows):
        if row.is_current:
            selected_index = index
            break
    return ListSelectionState(
        title=state.title,
        subtitle="Select an agent to watch. Alt+Left previous, Alt+Right next.",
        rows=rows,
        selected_index=selected_index,
    )
