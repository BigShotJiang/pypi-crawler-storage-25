# Ralph Audit Review

## Overview

Audit the latest merged work in the style of a compact code review. Start from the merged diff and verification evidence, lead with findings, and stop quickly when the repo-local evidence is clean.

## When To Use

Use this stage when:
- merged work needs a final regression/risk pass
- Ralphception must decide whether to reopen execution or conclude completion
- verification results and merged-run context already exist

Do not use this stage to:
- re-implement the task
- do broad exploratory coding work
- pad the response when there are no real findings

## Findings Format

- List findings first, ordered by severity.
- Cite repo-local evidence for every finding.
- Keep findings compact and actionable.
- If there are no findings, write the empty findings payload plainly and stop.

## Severity Ladder

Use a simple review severity model:
- blocking: must reopen execution before completion
- important: real regression or requirement gap that should not be waved away
- minor: quality issue or low-risk follow-up that does not block completion

Do not inflate minor issues into blocking findings, and do not hide blocking evidence inside summary prose.

## Evidence Ladder

Prefer evidence in this order:
- latest merged diff
- touched paths
- verification output
- merged child-run artifacts
- narrow repo-local inspection of the affected paths

Do not escalate to broad repo discovery if the provided merged context already answers the audit question.

## Ralphception-Specific Discipline

- Treat the provided merged-run context as authoritative unless repo-local evidence contradicts it.
- Focus on regressions, requirement gaps, and operational risk caused by the latest merged work.
- Short-circuit to empty findings cleanly when the repo-local evidence is already sufficient.

## Reopen vs Complete

Reopen execution when:
- a blocking finding shows the latest merged work is incorrect or incomplete
- verification evidence contradicts the claimed outcome
- the merged diff clearly misses a required acceptance criterion

Conclude completion when:
- there are no findings
- only non-blocking follow-ups remain
- the repo-local evidence is already sufficient and consistent

## Common Mistakes

- Do not bury findings under summary prose.
- Do not make speculative findings without evidence.
- Do not ignore passed verification when there is no contradictory repo-local signal.
- Do not stay in audit mode when there are no findings to report.
