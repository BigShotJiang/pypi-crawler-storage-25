# Ralph Plan Writing

## Overview

Turn the PRD into a concrete execution plan using the reference `writing-plans` discipline, adapted for Ralphception's durable artifacts. Explicitly assume the later loop worker has zero context for the repo and will only succeed if the plan is explicit, well-scoped, and broken into small mergeable checkpoints. The result should be detailed enough that a later loop worker can execute without inventing structure, while the JSON contract is strict enough to drive loop planning and todo generation.

## When To Use

Use this stage when:
- the PRD/spec is already written
- the task is multi-step and needs explicit execution structure before code changes
- Ralphception needs plan markdown plus structured plan data for loop scheduling

Do not use this stage to:
- rewrite the PRD
- perform implementation work
- emit vague next steps without exact files, commands, and artifact outputs

## Scope Check

If the PRD still covers multiple independent subsystems, break the work into smaller slices instead of forcing one bloated plan. Each plan should produce a working, verifiable chunk of software on its own.

## File Map

Before defining tasks, map out which files will be created or modified and what each one is responsible for.

- Use exact file paths.
- Keep file responsibilities clear and repo-local.
- Prefer smaller, testable changes over broad cross-repo churn.
- If files are likely to grow together, say so explicitly in the plan instead of hand-waving.

## Bite-Sized Task Granularity

Each step should be one small action a worker can complete without guessing:
- write the failing test or verification
- run it to watch the expected failure
- write the minimal implementation
- run verification again
- commit or stage the next durable checkpoint

Frequent commits are a feature, not ceremony. Prefer plan shapes that create reviewable checkpoints after a small number of related steps.

## Plan Document Header

Every markdown plan should start with a clear header like:

```markdown
# [Feature Name] Implementation Plan

> **For agentic workers:** Execute this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** [One sentence]

**Architecture:** [2-3 sentences]

**Tech Stack:** [Key technologies/libraries]

---
```

## Task Discipline

- Break work into small, testable steps.
- Prefer TDD, DRY, and YAGNI.
- Use exact files, concrete verification commands, and explicit ordering.
- Write the failing test or verification first when behavior is changing.
- Include exact commands and expected outcomes when the worker needs them to judge success.

## Loop-Safe Slice Design

Ralph loops work best when the plan can progress through durable, mergeable slices:

- prefer slices that leave the repo in a working state after each commit intent
- keep todos completion-shaped so the frontier and watchdog logic can tell whether progress happened
- avoid umbrella tasks that mix unrelated files or multiple risky behaviors
- make parallelism explicit only when scopes are truly disjoint
- group commit intents around meaningful checkpoints, not arbitrary task counts

## Task Structure

Use a concrete task format, not generic prose. A typical plan section should look like:

````markdown
### Task N: [Component Name]

**Files:**
- Create: `exact/path/to/file.py`
- Modify: `exact/path/to/existing.py`
- Test: `tests/exact/path/to/test.py`

- [ ] **Step 1: Write the failing test**

```python
def test_specific_behavior():
    ...
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/path/test.py::test_name -v`
Expected: FAIL

- [ ] **Step 3: Write minimal implementation**

```python
...
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/path/test.py::test_name -v`
Expected: PASS

- [ ] **Step 5: Commit the checkpoint**
````

When code is changing, include the actual test shape and implementation sketch instead of vague descriptions.

## Ralphception Outputs

The markdown plan is not enough. The stage must also produce a JSON contract that is consistent with the markdown plan and includes:

- `execution_goal`
- `verification_commands`
- `todos`
- `commit_intents`
- `execution_policy`

The JSON should be derived from the plan rather than contradicting it.

### Todos

- Todos should be durable, dependency-aware units of work.
- Todo titles should be concrete and completion-shaped.
- Dependency chains should reflect real execution order.

### Commit Intents

- Commit intents should group related todos into meaningful checkpoints.
- Commit intent summaries should fit the repo's observed commit style rather than generic planner prose.

### Execution Policy

- The execution policy should help Ralphception decide loop ordering, concurrency, and verification pressure.
- Prefer simple, explicit policy over clever but underspecified scheduling.

## No Placeholders

Never write:
- TBD / TODO / "implement later"
- "write tests for the above" without the actual test shape
- "handle edge cases" without naming the edge cases
- "similar to previous task" without repeating the necessary detail
- steps that describe what to do without showing how
- references to types, functions, or files not defined anywhere in the plan

## Self-Review

Before finishing:
- Spec coverage: check that every major PRD requirement maps to plan tasks.
- Placeholder scan: check that there are no placeholder steps or missing verification commands.
- Type consistency: check that file paths, function names, and artifact names stay consistent across the plan.
- Check that the markdown plan and JSON contract agree.
- Check that todo coverage and commit-intent coverage are complete.

## Common Mistakes

- Do not emit a generic task list without a file map.
- Do not skip verification commands.
- Do not make the JSON contract shallower than the markdown plan.
- Do not forget that Ralphception needs plan markdown plus durable structured outputs, not just prose.
