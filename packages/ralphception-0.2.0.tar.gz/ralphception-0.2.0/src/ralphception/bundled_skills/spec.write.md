# Ralph Spec Writing

## Overview

Turn the approved intake into a repo-local PRD using the same discipline the reference `brainstorming` skill uses for design docs: clear scope, explicit architecture, concrete constraints, and no implementation churn disguised as planning.

## When To Use

Use this stage when:
- intake is complete enough to stop asking questions
- Ralphception needs a durable PRD/spec artifact to anchor plan writing
- the task needs scope, architecture, risks, and acceptance criteria written down before execution

Do not use this stage to:
- write the implementation plan
- enumerate todos or commit intents
- start coding or describing exact implementation steps

## Inputs

- The approved intake summary is authoritative.
- Relevant repo context should be inspected before writing so the PRD names real files, systems, and boundaries.
- The spec should stay tightly scoped to the current task, not every adjacent improvement idea.

## Required Structure

Every PRD must clearly cover:
- Goal
- In Scope
- Non-Goals
- Repo Context
- Architecture
- Risks And Constraints
- Acceptance Criteria

## Writing Guidance

- Turn the intake into a repo-local PRD that a later planning stage can implement without guessing the task intent.
- Name the files, systems, or code areas that matter when the intake or repo context already narrowed them.
- Separate scope decisions from implementation steps.
- Prefer explicit tradeoffs and boundaries over vague aspiration language.
- If a requirement could be interpreted more than one way, pick the interpretation best supported by the intake and make it explicit.

## Design for Isolation and Clarity

- Break the design into smaller units with one clear purpose and well-defined boundaries.
- Make it obvious which responsibilities belong together and which should stay separate.
- Prefer spec shapes that let later loop plans produce small, mergeable slices instead of one tangled execution blob.
- If the requested work is still too broad for one clean plan, say so explicitly in the PRD and define the first slice clearly instead of pretending the whole system is one task.

## Ralphception-Specific Discipline

- The PRD is the durable contract for later plan markdown, plan JSON, loop graph generation, and todo derivation.
- Write only what later stages need to plan and verify the work safely.
- Avoid speculative extra features, future nice-to-haves, or "while we are here" churn.

## Self-Review

Before finishing the PRD, check:
- Does each acceptance criterion map to a real piece of work or verification?
- Are non-goals explicit enough to prevent scope creep?
- Does the architecture section explain the approach without slipping into implementation steps?
- Are there any placeholders, contradictions, or ambiguous terms left unresolved?

## Common Mistakes

- Do not turn the PRD into an implementation checklist.
- Do not omit repo context when local files or systems clearly matter.
- Do not leave acceptance criteria vague.
- Do not write TODO/TBD placeholders.
