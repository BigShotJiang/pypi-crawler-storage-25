# Ralph Merge Coordinator

## Overview

Assess whether the latest Ralph loop result is actually safe to merge, in the spirit of `finishing-a-development-branch` plus `verification-before-completion`. The merge stage exists to protect the main branch from optimistic handoffs, missing verification, and vague “should be ready” claims.

## When To Use

Use this stage when:
- a child loop or execution slice has produced a handoff and claims merge readiness
- Ralphception needs to decide whether to integrate the work, reopen execution, or stop with a concrete blocker
- verification evidence, touched paths, and artifact updates already exist

Do not use this stage to:
- do fresh exploratory implementation
- silently paper over failed verification
- merge work that has not been checked against the handoff contract

## Core Principle

Evidence before merge. A handoff is not merge-ready because the child said so. It is merge-ready only when the repo-local evidence, verification outputs, and touched paths support that claim.

## Merge Readiness Checklist

Before merging, check:
- the handoff metadata is present and readable
- touched paths and artifact paths are plausible for the stated goal
- verification evidence is present, fresh, and relevant to the change
- the worktree state matches the claimed scope
- there are no unresolved blockers or explicit `needs_revision` / `blocked` signals

If any of those checks fail, do not merge. Surface the blocker concretely.

## Decision Ladder

Prefer decisions in this order:

1. **merge now** when the evidence is sufficient and the change is within scope
2. **reopen execution** when the work is close but clearly needs revision
3. **fail the child run** when the handoff is blocked, contradictory, or not credible

Do not invent a fourth “maybe merge anyway” state.

## Blocking Signals

Treat these as merge blockers:
- verification missing, stale, or unrelated to the change
- touched paths do not match the claimed loop scope
- handoff says `blocked` or `needs_revision`
- artifact updates required by the output contract are missing
- repo-local evidence contradicts the claimed outcome

## Ralphception-Specific Discipline

- Preserve the authoritative repo root as the merge surface.
- Treat the handoff JSON and current worktree evidence together as the merge contract.
- Prefer a clean reopen with a concrete reason over a risky merge.
- Keep merge outcomes explicit so the watchdog/frontier logic can reason about what happened next.

## Output Contract

A good merge result must leave a concrete handoff for the next stage:
- merged with clear integrated paths and head commit information, or
- reopened with an explicit recovery reason, or
- failed with explicit blocker reasons

Do not emit vague prose where a later stage needs a concrete decision.

## Common Mistakes

- Do not trust the child summary without checking verification.
- Do not merge because the diff is small.
- Do not hide blockers in narrative prose.
- Do not reopen execution without a concrete reason the next loop can act on.
