# Ralph Execute Task

## Overview

Execute one Ralph loop assignment with the discipline of `test-driven-development` plus `verification-before-completion`: stay scoped, make the smallest useful change, and prove the outcome with fresh repo-local evidence.

## When To Use

Use this stage when:
- a Ralph loop assignment is already defined
- the worker has an explicit objective, stop condition, output contract, and target artifacts
- implementation work needs to happen inside the current worktree

Do not use this stage to:
- widen the task beyond the assigned loop scope
- narrate generic planning instead of doing the work
- claim completion without verification

## Core Discipline

- Follow the red-green-refactor spirit of TDD.
- Write or identify the failing test or verification first when behavior is changing.
- Prefer the smallest change that satisfies the loop objective.
- Do not claim completion without fresh verification evidence.

## The Iron Law

`NO PRODUCTION CODE WITHOUT A FAILING TEST OR VERIFICATION FIRST`

If the requested work changes behavior, write or identify the verification first, run it, and make sure it demonstrates the missing behavior before changing production code. If you skipped that step, fix the verification flow before you continue.

## Progress Contract

- Stay inside the current repository root and the assigned task scope.
- Prefer direct evidence over broad discovery.
- Keep progress updates concrete: inspected files, edits, verification, blockers.
- If the requested target is already correct, say so clearly and finish without unnecessary churn.

## Verification Discipline

- Run the narrowest verification that proves the requested behavior.
- If you touch multiple risky areas, expand verification accordingly.
- When verification cannot be run, say exactly what blocked it and what remains uncertain.

## Verification Gate

`NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE`

Before claiming progress is complete:
- identify the command that proves the claim
- run it fresh
- read the full output and exit status
- report the real result, even if it failed

Do not rely on stale command output, assumptions, or "should pass now" language.

## Ralphception-Specific Output

- Update the worktree directly.
- Keep the handoff JSON accurate for `summary`, `artifacts`, `touched_paths`, and `merge_readiness`.
- Report only task-relevant progress, findings, and blockers.

## Common Mistakes

- Do not roam the repo when the target artifacts and nearby evidence already answer the question.
- Do not narrate internal tool strategy or agent meta-behavior.
- Do not overbuild beyond the loop objective.
- Do not skip the verification step because the change looks small.
- Do not trust previous command runs when reporting current status.
