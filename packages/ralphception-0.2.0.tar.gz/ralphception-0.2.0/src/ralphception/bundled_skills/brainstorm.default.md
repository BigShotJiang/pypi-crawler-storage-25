# Ralph Startup Intake

## Overview

Run Ralphception's startup intake in the spirit of the reference `brainstorming` skill, but compressed for a live repository task. The goal is to inspect enough repo context to ask the smallest useful question, get to a crisp intake summary quickly, and then stop.

## Anti-Pattern: "This Is Too Simple To Need Intake"

Every new Ralphception task still gets intake. Even when the requested work sounds tiny, the startup stage should inspect repo context, surface the smallest missing constraint, and produce a durable summary before PRD and planning begin. The intake can be short, but it should not be skipped.

## When To Use

Use this stage when:
- the user has just started a new Ralphception task
- Ralphception needs to clarify constraints, success criteria, or risk boundaries before writing artifacts
- the repo is the working surface and the next stage needs a durable intake summary

Do not use this stage to:
- write the PRD, execution plan, todos, or code
- ask for file-inspection permission or repo-local access confirmation
- have an open-ended brainstorming conversation when one concrete repo-task question will do

## Working Assumptions

- Assume full read/write access to the entire current repository by default.
- Assume referenced outside folders provided with the task are in scope by default.
- Do not ask the user for permission to inspect files in the repo.
- Prefer the minimum number of questions needed to make the task safe and clear.
- Keep the question short, concrete, and repo-task-shaped.

## Intake Flow

1. Inspect the repo context before asking a question.
2. Identify the smallest missing fact that would change the PRD or execution plan.
3. Ask exactly one Socratic follow-up question per turn.
4. After each user answer, re-evaluate whether intake is already sufficient.
5. Once intake is sufficient, stop asking questions and synthesize the intake summary.

## Checklist

1. Explore the current repo context.
2. Decide whether the task is one slice or needs decomposition first.
3. Ask exactly one high-leverage follow-up question if a real planning ambiguity remains.
4. Synthesize the intake summary and hand off to the PRD stage.

## Question Strategy

Prefer questions in this order:
- constraints that change implementation or safety
- success criteria that determine when the task is done
- risk boundaries or explicit no-go areas
- narrow scope limits the user already hinted at

If the task actually spans multiple independent subsystems, ask one decomposition-oriented question instead of pretending it is already one clean slice.

## Rules

- Ask exactly one Socratic follow-up question per turn.
- In human interactive mode, always ask one Socratic follow-up after the very first task message before declaring intake sufficient.
- Treat the whole repository and referenced outside folders as the default scope.
- Do not ask the user to confirm repo-wide file scope unless they already narrowed it or there is a concrete risk boundary.
- Focus on constraints, success criteria, risk boundaries, and explicit user-provided scope limits.
- Once there has already been at least one follow-up answer, do not ask another question if intake is already sufficient.
- Do not write artifacts, plans, todos, or code in this stage.
- Keep questions short, concrete, and task-shaped.

## Completion Bar

- If more context is required: ask exactly one follow-up question.
- If intake is sufficient: synthesize a concise intake summary Ralphception can bootstrap into the PRD, plan markdown, plan JSON contract, loop plan, and todos.
- The intake summary should capture the task goal, default scope, constraints, success criteria, and any explicit file or area boundaries.

## Common Mistakes

- Do not ask open-ended "tell me more" questions when a tighter repo-task question would do.
- Do not ask "which files are in scope?" when the task can be safely treated as repo-wide.
- Do not stay in intake once the next artifact-writing stages can proceed without guessing.
- Do not leak meta-workflow narration about skills, prompts, or internal orchestration.
