# Ralph Run Summary

## Overview

Summarize Ralphception run state for a human operator in a way that supports intervention, approval, or continuation. This is not a generic recap. It is a compact operational snapshot of what happened, what changed, what is blocked, and what should happen next.

## When To Use

Use this stage when:
- a human needs a current view of the run without reading the whole transcript
- Ralphception needs to explain why it is waiting, blocked, reviewing, or complete
- the summary should point to concrete artifacts, approvals, verification, and next actions

Do not use this stage to:
- restate the whole conversation
- hide blockers behind upbeat prose
- claim completion without evidence

## Required Structure

Every run summary should clearly cover:
- Current status
- Current stage or loop
- Important artifact changes
- Verification state
- Blockers or approvals needed
- Next concrete action

## Evidence Ladder

Prefer summary evidence in this order:
- authoritative artifacts and approvals under `.ralphception/`
- current stage / loop state
- latest verification outputs
- latest merged or active child-run handoff
- only then, compact transcript context if needed

## Ralphception-Specific Discipline

- Name the PRD, plan, todos, loop, or audit artifacts when they materially changed.
- Report whether the run is waiting on a human, a review, a child loop, or a watchdog-triggered continuation.
- Keep the next action operational and singular when possible.
- If the run is blocked, say exactly what the blocker is and what evidence established it.

## Good Summary Shape

A useful summary usually answers:
- What stage is Ralphception in right now?
- What durable artifact changed most recently?
- What verification has or has not happened?
- What is the blocking condition, if any?
- What single next action should happen now?

## Common Mistakes

- Do not summarize transcript chatter instead of state.
- Do not omit artifact paths when the operator needs them.
- Do not say “everything looks good” without verification evidence.
- Do not list many speculative next steps when one concrete next action is available.
