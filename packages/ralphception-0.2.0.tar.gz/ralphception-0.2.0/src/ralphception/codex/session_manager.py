"""Codex session lifecycle management and engine-event normalization."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import cast
from uuid import uuid4

from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig
from ralphception.models.events import Event
from ralphception.models.session import AgentRef, ChildSessionRef, SessionFailureKind
from ralphception.runtime.compaction import build_compaction_refresh_prompt
from ralphception.runtime.frontier import TaskFrontier
from ralphception.runtime.prompt_state import PendingPrompt, STARTUP_INTAKE_ANSWERS_KEY
from ralphception.runtime.startup_llm import (
    build_startup_resolution_prompt,
    normalize_startup_clarifying_question,
    parse_startup_resolution,
)
from ralphception.runtime.watchdog import (
    WatchdogAction,
    WatchdogDecision,
    WatchdogResolution,
    build_watchdog_decision_prompt,
    parse_watchdog_decision,
)

from .client import (
    CodexAppServerClient,
    CodexClientProtocol,
    CodexModelUnavailableError,
    CodexProtocolError,
    CodexSessionExpiredError,
    CodexStartupFailedError,
    CodexThreadSession,
    CodexTransportError,
    CodexTurnRef,
    RawCodexEvent,
    normalize_notification,
)


@dataclass(slots=True)
class _RunState:
    run_id: str
    goal: str
    parent_run_id: str | None
    workspace_path: str
    session_ref: ChildSessionRef | None = None
    active_turn_id: str | None = None


@dataclass(frozen=True, slots=True)
class CodexCompactionOutcome:
    previous_session_ref: ChildSessionRef
    compacted_session_ref: ChildSessionRef


class CodexSessionManager:
    """Owns Codex session startup, resumption, and event normalization."""

    def __init__(
        self,
        *,
        workspace_path: str,
        config: RalphceptionConfig = DEFAULT_CONFIG,
        client: CodexClientProtocol | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.workspace_path = workspace_path
        self.config = config
        self.client = client or CodexAppServerClient(cwd=workspace_path)
        self._clock = clock or _utc_now
        self._client_ready = False
        self._available_models: frozenset[str] | None = None
        self._run_states: dict[str, _RunState] = {}
        self._agents: dict[str, AgentRef] = {}
        self._buffered_raw_events: dict[str, deque[RawCodexEvent]] = {}
        self._agent_counter = 0
        self._last_primary_run_id: str | None = None

    def start(self) -> None:
        if self._client_ready:
            return
        self.client.start()
        self.client.initialize()
        self._client_ready = True

    def close(self) -> None:
        self.client.close()
        self._client_ready = False

    def start_session(
        self,
        *,
        run_id: str,
        goal: str | None = None,
        parent_run_id: str | None = None,
        workspace_path: str | None = None,
    ) -> Event:
        self.start()
        self._ensure_model_available()
        state = self._run_states.get(run_id)
        if state is None:
            state = _RunState(
                run_id=run_id,
                goal=goal or f"Run {run_id}",
                parent_run_id=parent_run_id,
                workspace_path=workspace_path or self.workspace_path,
            )
            self._run_states[run_id] = state
        else:
            if goal is not None:
                state.goal = goal
            if parent_run_id is not None:
                state.parent_run_id = parent_run_id
            if workspace_path is not None:
                state.workspace_path = workspace_path

        started_session = self.client.thread_start(
            cwd=state.workspace_path,
            config=self.config.codex,
        )
        state.session_ref = self._child_session_ref(run_id, started_session)
        state.active_turn_id = None
        self._last_primary_run_id = run_id
        return self._run_started_event(run_id, state)

    def resume_session(
        self,
        *,
        run_id: str,
        goal: str | None = None,
        parent_run_id: str | None = None,
    ) -> Event:
        self.start()
        state = self._require_state(run_id)
        session_ref = self._require_session_ref(run_id)
        if goal is not None:
            state.goal = goal
        if parent_run_id is not None:
            state.parent_run_id = parent_run_id
        resumed = self.client.thread_resume(
            session_ref.codex_thread_id,
            cwd=session_ref.workspace_path,
            config=self.config.codex,
        )
        state.session_ref = self._child_session_ref(run_id, resumed)
        state.active_turn_id = None
        self._last_primary_run_id = run_id
        return self._run_started_event(run_id, state)

    def run_turn(self, *, run_id: str, input_text: str) -> CodexTurnRef:
        self.start()
        self._ensure_model_available()
        session_ref = self._require_session_ref(run_id)
        turn_ref = self.client.turn_start(
            session_ref.codex_thread_id,
            input_text,
            cwd=session_ref.workspace_path,
            config=self.config.codex,
        )
        self._run_states[run_id].active_turn_id = turn_ref.turn_id
        return turn_ref

    def resolve_prompt_reply(self, *, prompt: PendingPrompt, user_text: str) -> dict[str, object] | None:
        if prompt.prompt_kind != "startup_prompt":
            return None
        run_id = prompt.owner_run_id or prompt.thread_id or "run-root"
        if self.get_session_ref(run_id) is None:
            self.start_session(
                run_id=run_id,
                goal="Ralphception startup intake",
                workspace_path=self.workspace_path,
            )
        prompt_text = build_startup_resolution_prompt(
            repo_root=Path(self.workspace_path),
            repo_root_label=self.workspace_path,
            prior_answers=tuple(_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY)),
            latest_user_text=user_text,
            source_repos=tuple(_context_str_list(prompt, "source_repos")),
        )
        self.run_turn(run_id=run_id, input_text=prompt_text)
        assistant_text = self._collect_assistant_text(run_id=run_id)
        decision = parse_startup_resolution(assistant_text)
        if decision is None:
            return None
        if decision.kind == "clarify":
            return {
                "kind": "clarify",
                "clarifying_question": normalize_startup_clarifying_question(
                    question=decision.question or "",
                    latest_user_text=user_text,
                    prior_answers=tuple(_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY)),
                ),
                "confidence": 0.75,
            }
        return {
            "kind": "resolved",
            "action": "bootstrap",
            "intake_summary": decision.intake_summary,
            "confidence": 0.9,
        }

    def resolve_watchdog_action(
        self,
        *,
        run_id: str,
        goal: str,
        frontier: TaskFrontier,
        trigger_reason: str,
        artifact_paths: tuple[str, ...] = (),
        recent_runtime_events: tuple[str, ...] = (),
        allowed_actions: tuple[WatchdogAction, ...],
    ) -> WatchdogResolution | None:
        if self.get_session_ref(run_id) is None:
            self.start_session(
                run_id=run_id,
                goal=goal,
                workspace_path=self.workspace_path,
            )
        parent_session_ref = self._require_session_ref(run_id)
        forked_session = self.client.thread_fork(
            parent_session_ref.codex_thread_id,
            cwd=parent_session_ref.workspace_path,
            config=self.config.codex,
        )
        watchdog_run_id = f"{run_id}:watchdog:{uuid4().hex}"
        self._run_states[watchdog_run_id] = _RunState(
            run_id=watchdog_run_id,
            goal=f"Watchdog for {goal}",
            parent_run_id=run_id,
            workspace_path=forked_session.workspace_path,
            session_ref=self._child_session_ref(watchdog_run_id, forked_session),
        )
        prompt_text = build_watchdog_decision_prompt(
            goal=goal,
            trigger_reason=trigger_reason,
            frontier=frontier,
            artifact_paths=artifact_paths,
            recent_runtime_events=recent_runtime_events,
            allowed_actions=allowed_actions,
        )
        self.run_turn(run_id=watchdog_run_id, input_text=prompt_text)
        assistant_text = self._collect_assistant_text(run_id=watchdog_run_id)
        decision = parse_watchdog_decision(assistant_text, allowed_actions=allowed_actions)
        if decision is None:
            return None
        return WatchdogResolution(
            decision=decision,
            source_thread_id=parent_session_ref.codex_thread_id,
            created_child_thread_id=forked_session.thread_id,
        )

    def compact_run_context(
        self,
        *,
        run_id: str,
        goal: str,
        reason: str,
        summary_text: str,
    ) -> CodexCompactionOutcome:
        self.start()
        self._ensure_model_available()
        previous_session_ref = self._require_session_ref(run_id)
        started_session = self.client.thread_start(
            cwd=previous_session_ref.workspace_path,
            config=self.config.codex,
        )
        compacted_session_ref = self._child_session_ref(run_id, started_session)
        state = self._require_state(run_id)
        state.session_ref = compacted_session_ref
        state.active_turn_id = None
        refresh_prompt = build_compaction_refresh_prompt(
            goal=goal,
            reason=reason,
            summary_text=summary_text,
        )
        self.run_turn(run_id=run_id, input_text=refresh_prompt)
        self._collect_assistant_text(run_id=run_id)
        return CodexCompactionOutcome(
            previous_session_ref=previous_session_ref,
            compacted_session_ref=compacted_session_ref,
        )

    def spawn_agent(
        self,
        *,
        task_id: str,
        goal: str,
        parent_run_id: str | None = None,
        workspace_path: str | None = None,
    ) -> AgentRef:
        self.start()
        self._ensure_model_available()
        resolved_parent_run_id = parent_run_id or self._last_primary_run_id
        if resolved_parent_run_id is None:
            raise CodexSessionExpiredError("Cannot spawn an agent without a parent run session")

        parent_session_ref = self._require_session_ref(resolved_parent_run_id)
        forked_session = self.client.thread_fork(
            parent_session_ref.codex_thread_id,
            cwd=workspace_path or parent_session_ref.workspace_path,
            config=self.config.codex,
        )
        now = self._clock()
        self._agent_counter += 1
        agent_id = f"agent-{self._agent_counter}"
        agent_session = ChildSessionRef(
            run_id=f"agent:{agent_id}",
            codex_thread_id=forked_session.thread_id,
            codex_session_id=forked_session.session_id,
            workspace_path=forked_session.workspace_path,
            resumable=True,
            last_seen_at=now,
        )
        agent_ref = AgentRef(
            agent_id=agent_id,
            parent_run_id=resolved_parent_run_id,
            parent_task_id=task_id,
            codex_session_ref=agent_session,
            goal=goal,
            status="queued",
            created_at=now,
            updated_at=now,
        )
        self._agents[agent_id] = agent_ref
        return agent_ref

    def stream_raw_events(
        self,
        *,
        run_id: str,
        until_methods: Iterable[str] | str,
    ) -> list[RawCodexEvent]:
        return list(self.iter_raw_events(run_id=run_id, until_methods=until_methods))

    def iter_raw_events(
        self,
        *,
        run_id: str,
        until_methods: Iterable[str] | str,
    ):
        session_ref = self._require_session_ref(run_id)
        target_methods = {until_methods} if isinstance(until_methods, str) else set(until_methods)

        while True:
            raw_event = self._next_raw_event(session_ref.codex_thread_id)
            self._apply_raw_event(run_id, raw_event)
            yield raw_event
            if raw_event.method in target_methods:
                return

    def normalize_event(
        self,
        raw_event: RawCodexEvent,
        *,
        run_id: str,
        stage_id: str | None = None,
        task_id: str | None = None,
    ) -> Event | None:
        state = self._run_states.get(run_id)
        goal = state.goal if state is not None else f"Run {run_id}"
        parent_run_id = state.parent_run_id if state is not None else None

        if raw_event.method == "thread/started":
            return self._build_event(
                run_id=run_id,
                stage_id=None,
                task_id=None,
                event_type="run.started",
                payload={"goal": goal, "parent_run_id": parent_run_id},
            )
        if raw_event.method == "turn/started":
            if stage_id is None or task_id is None:
                return None
            return self._build_event(
                run_id=run_id,
                stage_id=stage_id,
                task_id=task_id,
                event_type="task.started",
                payload={"task_kind": "turn"},
            )
        if raw_event.method == "turn/completed":
            if stage_id is None or task_id is None:
                return None
            return self._build_event(
                run_id=run_id,
                stage_id=stage_id,
                task_id=task_id,
                event_type="task.completed",
                payload={"task_kind": "turn"},
            )
        if raw_event.method == "error":
            if stage_id is None or task_id is None:
                return None
            return self._build_event(
                run_id=run_id,
                stage_id=stage_id,
                task_id=task_id,
                event_type="task.session_lost",
                payload={
                    "task_kind": "turn",
                    "failure_kind": self._failure_kind_from_payload(raw_event.payload),
                },
            )
        return None

    def abort_session(self, *, run_id: str) -> None:
        state = self._run_states.get(run_id)
        if state is None or state.session_ref is None or state.active_turn_id is None:
            return
        self.client.turn_interrupt(state.session_ref.codex_thread_id, state.active_turn_id)
        state.active_turn_id = None

    def get_session_ref(self, run_id: str) -> ChildSessionRef | None:
        state = self._run_states.get(run_id)
        return None if state is None else state.session_ref

    def active_turn_id(self, run_id: str) -> str | None:
        state = self._run_states.get(run_id)
        return None if state is None else state.active_turn_id

    def normalize_error(self, error: BaseException) -> str:
        if isinstance(error, (CodexStartupFailedError, FileNotFoundError, ImportError, OSError)):
            return SessionFailureKind.STARTUP_FAILED.value
        if isinstance(error, CodexSessionExpiredError):
            return SessionFailureKind.SESSION_EXPIRED.value
        if isinstance(error, CodexTransportError):
            return SessionFailureKind.TRANSPORT_ERROR.value
        if isinstance(error, CodexModelUnavailableError):
            return SessionFailureKind.MODEL_UNAVAILABLE.value
        if isinstance(error, CodexProtocolError):
            return SessionFailureKind.PROTOCOL_ERROR.value
        return SessionFailureKind.PROTOCOL_ERROR.value

    def _run_started_event(self, run_id: str, state: _RunState) -> Event:
        session_ref = self._require_session_ref(run_id)
        raw_event = normalize_notification(
            "thread/started",
            {
                "cwd": session_ref.workspace_path,
                "sessionId": session_ref.codex_session_id,
                "thread": {"id": session_ref.codex_thread_id},
            },
        )
        event = self.normalize_event(raw_event, run_id=run_id)
        if event is None:
            raise CodexProtocolError("thread/started could not be normalized")
        return event

    def _build_event(
        self,
        *,
        run_id: str,
        stage_id: str | None,
        task_id: str | None,
        event_type: str,
        payload: dict[str, object],
    ) -> Event:
        return Event(
            event_id=f"event-{uuid4().hex}",
            schema_version=1,
            run_id=run_id,
            stage_id=stage_id,
            task_id=task_id,
            event_type=event_type,
            sequence=0,
            occurred_at=self._clock(),
            source="codex_session_manager",
            payload=payload,
        )

    def _ensure_model_available(self) -> None:
        configured_model = self.config.codex.model
        if self._available_models is None:
            self._available_models = frozenset(self.client.model_list())
        if configured_model not in self._available_models:
            raise CodexModelUnavailableError(
                f"Configured model {configured_model!r} is not available from Codex",
            )

    def _require_state(self, run_id: str) -> _RunState:
        state = self._run_states.get(run_id)
        if state is None:
            raise CodexSessionExpiredError(f"No stored session state exists for run {run_id!r}")
        return state

    def _require_session_ref(self, run_id: str) -> ChildSessionRef:
        state = self._require_state(run_id)
        if state.session_ref is None:
            raise CodexSessionExpiredError(f"Run {run_id!r} has no resumable Codex session")
        return state.session_ref

    def _child_session_ref(self, run_id: str, started_session: CodexThreadSession) -> ChildSessionRef:
        return ChildSessionRef(
            run_id=run_id,
            codex_thread_id=started_session.thread_id,
            codex_session_id=started_session.session_id,
            workspace_path=started_session.workspace_path,
            resumable=True,
            last_seen_at=self._clock(),
        )

    def _apply_raw_event(self, run_id: str, raw_event: RawCodexEvent) -> None:
        state = self._run_states.get(run_id)
        if state is None or state.session_ref is None:
            return

        state.session_ref = state.session_ref.model_copy(update={"last_seen_at": self._clock()})
        if raw_event.method in {"turn/completed", "error"} and raw_event.turn_id == state.active_turn_id:
            state.active_turn_id = None

    def _next_raw_event(self, thread_id: str) -> RawCodexEvent:
        buffered_events = self._buffered_raw_events.get(thread_id)
        if buffered_events:
            raw_event = buffered_events.popleft()
            if not buffered_events:
                self._buffered_raw_events.pop(thread_id, None)
            return raw_event

        while True:
            raw_event = self.client.next_notification()
            if raw_event.thread_id not in {None, thread_id}:
                self._buffered_raw_events.setdefault(raw_event.thread_id, deque()).append(raw_event)
                continue
            return raw_event

    def _collect_assistant_text(self, *, run_id: str) -> str:
        session_ref = self._require_session_ref(run_id)
        message_chunks: dict[str, list[str]] = {}
        completed_messages: list[str] = []
        while True:
            raw_event = self._next_raw_event(session_ref.codex_thread_id)
            self._apply_raw_event(run_id, raw_event)
            if raw_event.method == "item/agentMessage/delta":
                item_id = _as_text(raw_event.payload.get("item_id"))
                delta = _as_text(raw_event.payload.get("delta"))
                if item_id is not None and delta:
                    message_chunks.setdefault(item_id, []).append(delta)
            elif raw_event.method == "item/completed":
                item = raw_event.payload.get("item")
                if isinstance(item, dict) and _as_text(item.get("type")) == "agentMessage":
                    item_id = _as_text(item.get("id"))
                    text = _as_text(item.get("text"))
                    if not text and item_id is not None:
                        text = "".join(message_chunks.pop(item_id, []))
                    elif item_id is not None:
                        message_chunks.pop(item_id, None)
                    if text:
                        completed_messages.append(text)
            if raw_event.method in {"turn/completed", "error"}:
                return "\n\n".join(part for part in completed_messages if part.strip()).strip()

    def _failure_kind_from_payload(self, payload: dict[str, object]) -> str:
        details: list[str] = []
        error_payload = payload.get("error")
        if isinstance(error_payload, dict):
            normalized_error_payload = cast(dict[str, object], error_payload)
            message = normalized_error_payload.get("message")
            if isinstance(message, str):
                details.append(message)
            codex_error_info = normalized_error_payload.get("codex_error_info")
            if isinstance(codex_error_info, str):
                details.append(codex_error_info)
        joined = " ".join(detail.lower() for detail in details)
        if "expired" in joined or "not found" in joined:
            return SessionFailureKind.SESSION_EXPIRED.value
        if "unavailable" in joined and "model" in joined:
            return SessionFailureKind.MODEL_UNAVAILABLE.value
        return SessionFailureKind.PROTOCOL_ERROR.value


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _context_str_list(prompt: PendingPrompt, key: str) -> list[str]:
    value = prompt.context.get(key)
    if not isinstance(value, list):
        return []
    return [entry for entry in value if isinstance(entry, str) and entry.strip()]


def _as_text(value: object) -> str | None:
    if isinstance(value, str):
        stripped = value.strip()
        return stripped or None
    return None
