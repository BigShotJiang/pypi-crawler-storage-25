"""Helpers for reading the user's Codex configuration."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

from ralphception.config import DEFAULT_CONFIG


@dataclass(frozen=True, slots=True)
class CodexRuntimeSettings:
    model: str
    reasoning_effort: str
    service_tier: str
    config_path: Path


def resolve_codex_home() -> Path:
    env_home = os.environ.get("CODEX_HOME")
    if env_home:
        return Path(env_home).expanduser()
    return Path.home() / ".codex"


def codex_config_path(*, codex_home: Path | None = None) -> Path:
    return (codex_home or resolve_codex_home()) / "config.toml"


def load_codex_runtime_settings(*, codex_home: Path | None = None) -> CodexRuntimeSettings:
    config_file = codex_config_path(codex_home=codex_home)
    model = DEFAULT_CONFIG.codex.model
    reasoning_effort = DEFAULT_CONFIG.codex.reasoning
    service_tier = DEFAULT_CONFIG.codex.latency_profile

    if config_file.exists():
        try:
            payload = tomllib.loads(config_file.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError):
            payload = {}
        if isinstance(payload.get("model"), str) and payload["model"]:
            model = payload["model"]
        if isinstance(payload.get("model_reasoning_effort"), str) and payload["model_reasoning_effort"]:
            reasoning_effort = payload["model_reasoning_effort"]
        if isinstance(payload.get("service_tier"), str) and payload["service_tier"]:
            service_tier = payload["service_tier"]

    return CodexRuntimeSettings(
        model=model,
        reasoning_effort=reasoning_effort,
        service_tier=service_tier,
        config_path=config_file,
    )
