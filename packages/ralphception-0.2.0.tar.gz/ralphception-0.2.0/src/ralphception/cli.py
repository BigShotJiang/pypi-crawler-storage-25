"""CLI entry point for Ralphception."""

from pathlib import Path
import sys
from typing import Annotated

import typer

import ralphception.app as runtime_app
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeLaunchAbortedError,
    RuntimePromptConflictError,
)
app = typer.Typer(help="Ralphception core runtime CLI.")


@app.callback(invoke_without_command=True)
def main(ctx: typer.Context) -> None:
    """Start the Ralphception inline shell."""

    if ctx.invoked_subcommand is None:
        runtime_app.run_app()


@app.command("e", hidden=True)
@app.command("exec")
def exec_command(
    prompt: Annotated[str | None, typer.Argument()] = None,
    repo_root: Annotated[Path | None, typer.Option("--repo-root")] = None,
    source_repos: Annotated[list[str] | None, typer.Option("--source-repo")] = None,
    approve_all: Annotated[bool, typer.Option("--approve-all/--no-approve-all")] = True,
    approver: Annotated[str, typer.Option("--approver")] = "exec",
    fake_session_manager: Annotated[bool, typer.Option("--fake-session-manager")] = False,
) -> None:
    """Run Ralphception non-interactively."""
    resolved_prompt = _resolve_exec_prompt(prompt)
    if resolved_prompt is None:
        typer.echo("Prompt is required unless provided via stdin.")
        raise typer.Exit(code=1)
    try:
        result = runtime_app.run_exec(
            repo_root=repo_root,
            prompt=resolved_prompt,
            source_repos=tuple(source_repos or ()),
            approve_all=approve_all,
            approver=approver,
            use_fake_session_manager=fake_session_manager,
        )
    except (RuntimeBackendUnavailableError, RuntimeLaunchAbortedError, RuntimePromptConflictError) as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1) from exc
    typer.echo(runtime_app._render_exec_result(result))
def _resolve_exec_prompt(prompt: str | None) -> str | None:
    if prompt not in {None, "-"}:
        normalized = prompt.strip()
        return normalized or None

    if prompt == "-" or not sys.stdin.isatty():
        stdin_text = sys.stdin.read().strip()
        return stdin_text or None
    return None
