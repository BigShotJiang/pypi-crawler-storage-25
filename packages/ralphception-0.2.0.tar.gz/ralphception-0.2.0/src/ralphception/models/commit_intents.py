"""Commit intent durable models for the actor runtime."""

from __future__ import annotations

from pydantic import Field, field_validator, model_validator

from .artifacts import DurableModel


class CommitIntent(DurableModel):
    intent_id: str
    message: str
    todo_ids: list[str] = Field(min_length=1)
    ordering_after: list[str]
    winning_candidate_id: str | None = None

    @field_validator("intent_id", "message")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("commit intent fields must not be blank")
        return value

    @field_validator("todo_ids", "ordering_after")
    @classmethod
    def _validate_string_lists(cls, values: list[str]) -> list[str]:
        for value in values:
            if not value.strip():
                raise ValueError("commit intent list fields must not contain blank values")
        return values

    @model_validator(mode="after")
    def _validate_uniqueness(self) -> "CommitIntent":
        if len(set(self.todo_ids)) != len(self.todo_ids):
            raise ValueError("todo_ids must be unique")
        if len(set(self.ordering_after)) != len(self.ordering_after):
            raise ValueError("ordering_after must be unique")
        return self
