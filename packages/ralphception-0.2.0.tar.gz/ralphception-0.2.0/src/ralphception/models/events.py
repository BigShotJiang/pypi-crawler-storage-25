"""Event envelope contracts and required event vocabulary."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import ConfigDict, Field, field_validator, model_validator

from .artifacts import DurableModel
from .runtime import StageKind, TaskKind
from .verification import FindingKind, FindingSeverity, VerificationStatus

REQUIRED_EVENT_TYPES: tuple[str, ...] = (
    "run.created",
    "run.started",
    "run.status_changed",
    "run.replaced",
    "bundle.created",
    "bundle.state_changed",
    "bundle.assigned",
    "stage.started",
    "stage.completed",
    "task.queued",
    "task.started",
    "task.completed",
    "task.blocked",
    "task.failed",
    "task.aborted",
    "task.session_lost",
    "agent.spawned",
    "artifact.promoted",
    "verification.completed",
    "merge.completed",
    "stage.blocked",
    "stage.failed",
    "stage.aborted",
    "audit.finding_created",
    "audit.finding_status_changed",
)

class EventPayloadHelper(DurableModel):
    """Typed payload helper base model for event categories."""

    model_config = ConfigDict(extra="allow")


class RunEventPayload(EventPayloadHelper):
    goal: str
    parent_run_id: str | None


class BundleEventPayload(EventPayloadHelper):
    bundle_id: str
    bundle_version: int = Field(ge=1)


class StageEventPayload(EventPayloadHelper):
    stage_kind: StageKind


class TaskEventPayload(EventPayloadHelper):
    task_kind: TaskKind


class AgentEventPayload(EventPayloadHelper):
    agent_id: str
    parent_task_id: str


class ArtifactEventPayload(EventPayloadHelper):
    artifact_path: str
    artifact_kind: str
    producing_run_id: str


class MergeEventPayload(EventPayloadHelper):
    child_run_id: str


class VerificationEventPayload(EventPayloadHelper):
    verification_id: str
    status: VerificationStatus


class AuditEventPayload(EventPayloadHelper):
    finding_id: str
    severity: FindingSeverity
    kind: FindingKind


_PAYLOAD_HELPER_BY_CATEGORY: dict[str, type[EventPayloadHelper]] = {
    "run": RunEventPayload,
    "bundle": BundleEventPayload,
    "stage": StageEventPayload,
    "task": TaskEventPayload,
    "agent": AgentEventPayload,
    "artifact": ArtifactEventPayload,
    "merge": MergeEventPayload,
    "verification": VerificationEventPayload,
    "audit": AuditEventPayload,
}

_CUSTOM_EVENT_PREFIX = "custom_"


class Event(DurableModel):
    event_id: str
    schema_version: int = Field(ge=1)
    run_id: str
    stage_id: str | None
    task_id: str | None
    event_type: str
    sequence: int = Field(ge=0)
    occurred_at: datetime
    source: str
    payload: dict[str, Any]

    @field_validator("event_type")
    @classmethod
    def validate_event_type(cls, value: str) -> str:
        if value.count(".") != 1:
            raise ValueError("event_type must contain exactly one dot")
        category, action = value.split(".", 1)
        if not category or not action:
            raise ValueError("event_type must have non-empty category and action")
        return value

    @model_validator(mode="after")
    def validate_scope_fields(self) -> "Event":
        category = self.event_type.split(".", 1)[0]
        _, action = self.event_type.split(".", 1)

        if action == _CUSTOM_EVENT_PREFIX:
            raise ValueError("custom_ event actions must include a suffix")

        if self.schema_version == 1:
            if self.event_type not in REQUIRED_EVENT_TYPES:
                if category not in _PAYLOAD_HELPER_BY_CATEGORY or not action.startswith(_CUSTOM_EVENT_PREFIX):
                    raise ValueError(
                        "schema_version 1 event_type must be required or use a custom_ extension action",
                    )

        if category == "run":
            if self.stage_id is not None or self.task_id is not None:
                raise ValueError("run events must not include stage_id or task_id")
        elif self.stage_id is None:
            raise ValueError("stage_id is required for non-run events")

        if category in _PAYLOAD_HELPER_BY_CATEGORY:
            if category == "stage" and self.task_id is not None:
                raise ValueError("stage events must not include task_id")
            if category in {"task", "verification"} and self.task_id is None:
                raise ValueError("task and verification events require task_id")
            if category == "agent" and self.task_id is None:
                raise ValueError("agent events require task_id")

            payload_helper = _PAYLOAD_HELPER_BY_CATEGORY[category]
            self.payload = payload_helper.model_validate(self.payload).model_dump()

            if category == "agent" and self.task_id != self.payload["parent_task_id"]:
                raise ValueError("agent event task_id must match payload.parent_task_id")

            if self.event_type.startswith("task.") or self.event_type.startswith("verification."):
                if self.stage_id is None:
                    raise ValueError("task and verification events require stage_id")
        return self
