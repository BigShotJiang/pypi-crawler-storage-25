"""Todo graph durable models for the actor runtime."""

from __future__ import annotations

from typing import Literal

from pydantic import field_validator, model_validator

from .artifacts import DurableModel

TodoNodeStatus = Literal["blocked", "ready", "assigned", "running", "completed", "failed", "dropped"]


class TodoNode(DurableModel):
    todo_id: str
    title: str
    dependency_ids: list[str]
    status: TodoNodeStatus
    commit_intent_id: str
    scope_hints: list[str]
    assigned_worker_id: str | None = None

    @field_validator("todo_id", "title", "commit_intent_id")
    @classmethod
    def _validate_non_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("todo fields must not be blank")
        return value

    @field_validator("dependency_ids", "scope_hints")
    @classmethod
    def _validate_string_lists(cls, values: list[str]) -> list[str]:
        for value in values:
            if not value.strip():
                raise ValueError("todo list fields must not contain blank values")
        return values

    @model_validator(mode="after")
    def _validate_dependencies(self) -> "TodoNode":
        if len(set(self.dependency_ids)) != len(self.dependency_ids):
            raise ValueError("dependency_ids must be unique")
        if self.todo_id in self.dependency_ids:
            raise ValueError("todo nodes must not depend on themselves")
        return self
