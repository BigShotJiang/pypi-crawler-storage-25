"""Artifact and TODO durable model contracts."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

TodoPriority = Literal["P0", "P1", "P2", "P3"]
TodoStatus = Literal["open", "in_progress", "done", "dropped"]


class DurableModel(BaseModel):
    """Shared base model configuration for durable records."""

    model_config = ConfigDict(extra="forbid")


class ArtifactRef(DurableModel):
    artifact_kind: str
    artifact_path: str
    artifact_version: int = Field(ge=1)
    content_hash: str


class TodoArtifact(DurableModel):
    todo_id: str
    title: str
    priority: TodoPriority
    status: TodoStatus
    bundle_version: int = Field(ge=1)
    artifact_refs: list[ArtifactRef]
