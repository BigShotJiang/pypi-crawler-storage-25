"""Session and delegated-agent durable model contracts."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal

from pydantic import model_validator

from .artifacts import DurableModel

AgentStatus = Literal["queued", "running", "completed", "blocked", "failed", "aborted"]


class SessionFailureKind(StrEnum):
    STARTUP_FAILED = "startup_failed"
    SESSION_EXPIRED = "session_expired"
    TRANSPORT_ERROR = "transport_error"
    PROTOCOL_ERROR = "protocol_error"
    MODEL_UNAVAILABLE = "model_unavailable"


class ChildSessionRef(DurableModel):
    run_id: str
    codex_thread_id: str
    codex_session_id: str
    workspace_path: str
    resumable: bool
    last_seen_at: datetime


class AgentRef(DurableModel):
    agent_id: str
    parent_run_id: str
    parent_task_id: str
    codex_session_ref: ChildSessionRef
    goal: str
    status: AgentStatus
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="after")
    def validate_timestamps(self) -> "AgentRef":
        if self.updated_at < self.created_at:
            raise ValueError("updated_at must be greater than or equal to created_at")
        return self
