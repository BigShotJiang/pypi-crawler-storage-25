"""Runtime version helpers for Ralphception."""

from __future__ import annotations

import importlib.metadata
from importlib import import_module
import re
from pathlib import Path

from ralphception.paths import _git_output


def _load_generated_version() -> str:
    try:
        module = import_module("ralphception._version")
    except ImportError:
        return "0.0.0"
    return str(getattr(module, "__version__", "0.0.0"))


GENERATED_VERSION = _load_generated_version()

_DESCRIBE_PATTERN = re.compile(
    r"^v(?P<tag>\d+(?:\.\d+)*?)-(?P<distance>\d+)-g(?P<commit>[0-9a-f]+)(?P<dirty>-dirty)?$",
)


def resolve_cli_version(repo_root: Path | None = None) -> str:
    """Return the best available runtime version for the current shell."""
    if repo_root is not None:
        checkout = checkout_version(repo_root)
        if checkout is not None:
            return checkout
    checkout = checkout_version(_ralphception_checkout_root())
    if checkout is not None:
        return checkout
    try:
        return importlib.metadata.version("ralphception")
    except importlib.metadata.PackageNotFoundError:
        return GENERATED_VERSION


def checkout_version(repo_root: Path) -> str | None:
    """Return the current checkout version derived from git, if available."""
    try:
        describe = _git_output(
            repo_root,
            "describe",
            "--dirty",
            "--tags",
            "--long",
            "--abbrev=9",
            "--match",
            "v*",
        )
    except RuntimeError:
        return None
    return _checkout_version_from_describe(describe)


def _checkout_version_from_describe(describe: str) -> str | None:
    match = _DESCRIBE_PATTERN.fullmatch(describe)
    if match is None:
        return None

    tag = match.group("tag")
    distance = int(match.group("distance"))
    commit = match.group("commit")
    dirty = match.group("dirty") is not None

    if distance == 0 and not dirty:
        return tag

    bumped_tag = _bump_release_tag(tag)
    local = f"g{commit}"
    if dirty:
        local = f"{local}.dirty"
    return f"{bumped_tag}.dev{distance}+{local}"


def _bump_release_tag(tag: str) -> str:
    parts = tag.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def _ralphception_checkout_root() -> Path:
    return Path(__file__).resolve().parents[2]
