"""Fake Codex client and session-manager builders for integration tests."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
import re

from ralphception.config import CodexConfig, DEFAULT_CONFIG, RalphceptionConfig
from ralphception.codex.client import (
    CodexClientProtocol,
    CodexModelPreset,
    CodexReasoningEffortPreset,
    CodexModelUnavailableError,
    CodexProtocolError,
    CodexSessionExpiredError,
    CodexStartupFailedError,
    CodexThreadSession,
    CodexTransportError,
    CodexTurnRef,
    RawCodexEvent,
    normalize_notification,
)
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.runtime.bootstrap import assess_intake_answers, compose_intake_summary
from ralphception.runtime.compaction import COMPACTION_REFRESH_BEGIN, COMPACTION_REFRESH_END
from ralphception.runtime.startup_llm import STARTUP_DECISION_BEGIN, STARTUP_DECISION_END
from ralphception.runtime.watchdog import WATCHDOG_DECISION_BEGIN, WATCHDOG_DECISION_END

FakeStartupFailure = CodexStartupFailedError
FakeExpiredSession = CodexSessionExpiredError
FakeTransportError = CodexTransportError
FakeProtocolError = CodexProtocolError
FakeModelUnavailableError = CodexModelUnavailableError
TurnHandler = Callable[[CodexThreadSession, str, int], None]

_CONTRACT_RE = re.compile(
    r"HEADLESS_CONTRACT_START\s*(?P<json>\{.*?\})\s*HEADLESS_CONTRACT_END",
    re.DOTALL,
)
_STARTUP_PRIOR_ANSWERS_RE = re.compile(
    r"Intake answers so far:\n(?P<answers>.*?)\n\nOptional source repositories:\n",
    re.DOTALL,
)
_STARTUP_LATEST_MESSAGE_RE = re.compile(
    r"Latest user message:\n- (?P<message>.*?)\n\nDecide whether to ask one more Socratic question",
    re.DOTALL,
)


@dataclass(frozen=True, slots=True)
class FakeNotification:
    method: str
    payload: dict[str, object]


@dataclass(slots=True)
class FakeCodexClient(CodexClientProtocol):
    available_models: tuple[str, ...] = ("gpt-5.4",)
    workspace_path: str = "/repo"
    started: bool = False
    initialized: bool = False
    closed: bool = False
    resumed_thread_ids: list[str] = field(default_factory=list)
    interruptions: list[tuple[str, str]] = field(default_factory=list)
    thread_counter: int = 0
    turn_counter: int = 0
    notifications: deque[FakeNotification] = field(default_factory=deque)
    turn_handler: TurnHandler | None = None
    _sessions_by_thread_id: dict[str, CodexThreadSession] = field(default_factory=dict)

    def start(self) -> None:
        self.started = True
        self.closed = False

    def initialize(self) -> None:
        if not self.started:
            raise FakeStartupFailure("client must be started before initialize")
        self.initialized = True

    def close(self) -> None:
        self.closed = True
        self.started = False
        self.initialized = False

    def thread_start(
        self,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        self.thread_counter += 1
        session = CodexThreadSession(
            thread_id=f"thread-{self.thread_counter}",
            session_id=f"session-{self.thread_counter}",
            workspace_path=cwd or self.workspace_path,
            model=config.model,
            approval_policy=config.approval_policy,
            sandbox=config.sandbox,
        )
        self._sessions_by_thread_id[session.thread_id] = session
        return session

    def thread_resume(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        session = self._sessions_by_thread_id.get(thread_id)
        if session is None:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        self.resumed_thread_ids.append(thread_id)
        if cwd is None or cwd == session.workspace_path:
            return session
        updated = CodexThreadSession(
            thread_id=session.thread_id,
            session_id=session.session_id,
            workspace_path=cwd,
            model=config.model,
            approval_policy=config.approval_policy,
            sandbox=config.sandbox,
        )
        self._sessions_by_thread_id[thread_id] = updated
        return updated

    def thread_fork(
        self,
        thread_id: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexThreadSession:
        if thread_id not in self._sessions_by_thread_id:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        return self.thread_start(cwd=cwd, config=config)

    def turn_start(
        self,
        thread_id: str,
        input_text: str,
        *,
        cwd: str | None,
        config: CodexConfig,
    ) -> CodexTurnRef:
        if thread_id not in self._sessions_by_thread_id:
            raise FakeExpiredSession(f"thread {thread_id!r} is no longer available")
        self.turn_counter += 1
        turn_id = f"turn-{self.turn_counter}"
        session = self._sessions_by_thread_id[thread_id]
        self.notifications.append(
            FakeNotification(
                method="turn/started",
                payload={
                    "threadId": thread_id,
                    "turn": {
                        "id": turn_id,
                        "status": "running",
                    },
                },
            ),
        )
        if self.turn_handler is not None:
            try:
                self.turn_handler(session, input_text, self.turn_counter)
            except Exception as exc:
                self.notifications.append(
                    FakeNotification(
                        method="error",
                        payload={
                            "threadId": thread_id,
                            "turn": {
                                "id": turn_id,
                                "status": "failed",
                            },
                            "error": {
                                "message": str(exc),
                            },
                        },
                    ),
                )
                return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)
        self.notifications.append(
            FakeNotification(
                method="turn/completed",
                payload={
                    "threadId": thread_id,
                    "turn": {
                        "id": turn_id,
                        "status": "completed",
                    },
                },
            ),
        )
        return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)

    def turn_interrupt(self, thread_id: str, turn_id: str) -> None:
        self.interruptions.append((thread_id, turn_id))

    def next_notification(self) -> RawCodexEvent:
        if not self.notifications:
            raise FakeTransportError("notification queue is empty")
        notification = self.notifications.popleft()
        return normalize_notification(notification.method, notification.payload)

    def stream_until_methods(self, methods: Iterable[str] | str) -> list[RawCodexEvent]:
        target_methods = {methods} if isinstance(methods, str) else set(methods)
        events: list[RawCodexEvent] = []
        while True:
            event = self.next_notification()
            events.append(event)
            if event.method in target_methods:
                return events

    def model_list(self) -> tuple[str, ...]:
        return self.available_models

    def model_catalog(self) -> tuple[CodexModelPreset, ...]:
        return tuple(
            CodexModelPreset(
                model=model_name,
                default_reasoning_effort="high",
                supported_reasoning_efforts=(
                    CodexReasoningEffortPreset(
                        effort="high",
                        description="Greater reasoning depth for complex work.",
                    ),
                ),
            )
            for model_name in self.available_models
        )


def build_fake_session_manager(
    *,
    available_models: tuple[str, ...] = ("gpt-5.4",),
    workspace_path: str = "/repo",
    config: RalphceptionConfig = DEFAULT_CONFIG,
    turn_handler: TurnHandler | None = None,
    watchdog_decisions: tuple[dict[str, object], ...] = (),
) -> CodexSessionManager:
    fake_client = FakeCodexClient(
        available_models=available_models,
        workspace_path=workspace_path,
        turn_handler=turn_handler,
    )
    if fake_client.turn_handler is None:
        writer = FakeStartupTurnWriter(client=fake_client, watchdog_decisions=deque(watchdog_decisions))
        fake_client.turn_handler = writer.handle_turn
    return CodexSessionManager(
        workspace_path=workspace_path,
        config=config,
        client=fake_client,
        clock=_fixed_utc_now,
    )


def build_fake_headless_session_manager(
    *,
    available_models: tuple[str, ...] = ("gpt-5.4",),
    workspace_path: str = "/repo",
    config: RalphceptionConfig = DEFAULT_CONFIG,
    watchdog_decisions: tuple[dict[str, object], ...] = (),
) -> CodexSessionManager:
    fake_client = FakeCodexClient(
        available_models=available_models,
        workspace_path=workspace_path,
    )
    writer = FakeHeadlessTurnWriter(client=fake_client, watchdog_decisions=deque(watchdog_decisions))
    fake_client.turn_handler = writer.handle_turn
    return CodexSessionManager(
        workspace_path=workspace_path,
        config=config,
        client=fake_client,
        clock=_fixed_utc_now,
    )


@dataclass(slots=True)
class FakeHeadlessTurnWriter:
    audit_turns: int = 0
    client: FakeCodexClient | None = None
    watchdog_decisions: deque[dict[str, object]] = field(default_factory=deque)

    def handle_turn(self, session: CodexThreadSession, input_text: str, turn_counter: int) -> None:
        startup_text = _build_fake_startup_resolution_text(input_text)
        if startup_text is not None:
            self._emit_agent_message(session, turn_counter, text=startup_text)
            return
        watchdog_text = self._build_fake_watchdog_resolution_text()
        if WATCHDOG_DECISION_BEGIN in input_text and WATCHDOG_DECISION_END in input_text and watchdog_text is not None:
            self._emit_agent_message(session, turn_counter, text=watchdog_text)
            return
        if COMPACTION_REFRESH_BEGIN in input_text and COMPACTION_REFRESH_END in input_text:
            self._emit_agent_message(session, turn_counter, text=f"{COMPACTION_REFRESH_BEGIN}\nready\n{COMPACTION_REFRESH_END}")
            return
        contract = _extract_contract(input_text)
        if contract is None:
            return
        stage = str(contract["stage"])
        workspace = Path(session.workspace_path)
        if stage == "spec":
            output_path = workspace / str(contract["output_path"])
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(
                "# PRD\n\n"
                "- Goal: Port parser.\n"
                "- Acceptance: produce a tracked implementation artifact and pass verification.\n",
                encoding="utf-8",
            )
            return
        if stage == "plan":
            plan_path = workspace / str(contract["plan_path"])
            plan_path.parent.mkdir(parents=True, exist_ok=True)
            plan_path.write_text(
                "# Execution Plan\n\n"
                "1. Implement the parser artifact.\n"
                "2. Run verification.\n"
                "3. Merge and audit.\n",
                encoding="utf-8",
            )
            contract_path = workspace / str(contract["plan_contract_path"])
            contract_path.parent.mkdir(parents=True, exist_ok=True)
            contract_path.write_text(
                json.dumps(
                    {
                        "execution_goal": "Implement the parser artifact.",
                        "verification_commands": ['python -c "print(\'headless verification\')"'],
                        "todos": [
                            {
                                "todo_id": "todo-1",
                                "title": "Implement parser artifact",
                                "dependency_ids": [],
                                "status": "ready",
                                "commit_intent_id": "intent-1",
                                "scope_hints": ["src/parser.py"],
                            }
                        ],
                        "commit_intents": [
                            {
                                "intent_id": "intent-1",
                                "message": "feat: Implement the parser artifact.",
                                "todo_ids": ["todo-1"],
                                "ordering_after": [],
                            }
                        ],
                        "execution_policy": {
                            "max_parallel_children": 1,
                            "batch_by_scope": True,
                            "allow_commit_split": True,
                        },
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            return
        if stage == "execute":
            loop_id = str(contract.get("loop_id", "loop-root"))
            raw_target_artifacts = contract.get("target_artifacts", [])
            target_artifacts = (
                tuple(str(item) for item in raw_target_artifacts)
                if isinstance(raw_target_artifacts, (list, tuple))
                else ()
            )
            self._emit_conversational_progress(
                session,
                turn_counter,
                assistant_text=f"Running Ralph loop {loop_id}. Inspecting the workspace.",
                command="git status --short",
                output_delta="?? .ralphception/\n",
            )
            if self.client is not None:
                self.client.notifications.append(
                    FakeNotification(
                        method="subagent_waiting",
                        payload={
                            "thread_id": session.thread_id,
                            "agent_thread_id": "run-child-1",
                            "summary": "Waiting on run-child-1 to finish verification",
                        },
                    )
                )
            run_id = str(contract["run_id"])
            handoff_path = workspace / str(contract["handoff_path"])
            handoff_path.parent.mkdir(parents=True, exist_ok=True)
            artifact_path = _resolve_fake_execute_artifact_path(
                workspace,
                target_artifacts[0] if target_artifacts else None,
                goal=str(contract.get("goal", "")),
            )
            work_product_path = workspace / artifact_path
            work_product_path.parent.mkdir(parents=True, exist_ok=True)
            touched_paths = [artifact_path]
            summary = f"Completed Ralph loop work for {artifact_path}."
            if "-replacement-" in run_id:
                tests_path = workspace / "tests" / "test_parser.py"
                tests_path.parent.mkdir(parents=True, exist_ok=True)
                tests_path.write_text(
                    f"def test_parser_placeholder_{run_id.replace('-', '_')}():\n    assert True\n",
                    encoding="utf-8",
                )
                work_product_path.write_text(f'VALUE = "{run_id}"\n', encoding="utf-8")
                touched_paths.append("tests/test_parser.py")
                summary = f"Resolved audit gap by adding parser coverage in {run_id}."
            else:
                if artifact_path.endswith(".md"):
                    work_product_path.write_text("# Notes\n\nFixed typo pass.\n", encoding="utf-8")
                else:
                    work_product_path.write_text("VALUE = 1\n", encoding="utf-8")
            handoff_path.write_text(
                json.dumps(
                    {
                        "summary": summary,
                        "artifacts": [{"path": artifact_path, "kind": "code"}],
                        "touched_paths": touched_paths,
                        "merge_readiness": "ready",
                    },
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
                encoding="utf-8",
            )
            return
        if stage == "audit":
            raw_touched_paths = contract.get("touched_paths", [])
            touched_paths = (
                [str(item) for item in raw_touched_paths if isinstance(item, str)]
                if isinstance(raw_touched_paths, (list, tuple))
                else []
            )
            primary_path = next(
                (path for path in touched_paths if not path.startswith(".ralphception/")),
                "src/parser.py",
            )
            diff_stat_line = f" {primary_path} | 1 +\n"
            self._emit_conversational_progress(
                session,
                turn_counter,
                assistant_text="Reviewing the latest Ralph-loop results.",
                command="git diff --stat",
                output_delta=diff_stat_line,
            )
            audit_path = workspace / str(contract["audit_path"])
            audit_path.parent.mkdir(parents=True, exist_ok=True)
            if self.audit_turns == 0 and not primary_path.endswith(".md"):
                payload = {
                    "findings": [
                        {
                            "finding_id": "audit-gap-1",
                            "severity": "P1",
                            "kind": "test_gap",
                            "title": "Parser change needs regression coverage.",
                            "status": "open",
                            "evidence_paths": [],
                        }
                    ]
                }
            else:
                payload = {"findings": []}
            self.audit_turns += 1
            audit_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def _emit_conversational_progress(
        self,
        session: CodexThreadSession,
        turn_counter: int,
        *,
        assistant_text: str,
        command: str,
        output_delta: str | None = None,
    ) -> None:
        if self.client is None:
            return
        message_id = f"message-{turn_counter}"
        command_id = f"command-{turn_counter}"
        notifications = [
            FakeNotification(
                method="thread/tokenUsage/updated",
                payload={
                    "threadId": session.thread_id,
                    "tokenUsage": {
                        "modelContextWindow": 128000,
                        "totalTokens": 1234,
                    },
                },
            ),
            FakeNotification(
                method="item/started",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {"type": "agentMessage", "id": message_id, "text": ""},
                },
            ),
            FakeNotification(
                method="item/agentMessage/delta",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "itemId": message_id,
                    "delta": assistant_text,
                },
            ),
            FakeNotification(
                method="item/completed",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {
                        "type": "agentMessage",
                        "id": message_id,
                        "text": assistant_text,
                    },
                },
            ),
            FakeNotification(
                method="item/started",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {
                        "type": "commandExecution",
                        "id": command_id,
                        "command": command,
                        "status": "inProgress",
                    },
                },
            ),
        ]
        if output_delta:
            notifications.append(
                FakeNotification(
                    method="item/commandExecution/outputDelta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": command_id,
                        "delta": output_delta,
                    },
                )
            )
        notifications.append(
            FakeNotification(
                method="item/completed",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {
                        "type": "commandExecution",
                        "id": command_id,
                        "command": command,
                        "status": "completed",
                        "exitCode": 0,
                    },
                },
            )
        )
        self.client.notifications.extend(notifications)

    def _emit_agent_message(self, session: CodexThreadSession, turn_counter: int, *, text: str) -> None:
        if self.client is None:
            return
        message_id = f"message-{turn_counter}"
        self.client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {"type": "agentMessage", "id": message_id, "text": ""},
                    },
                ),
                FakeNotification(
                    method="item/agentMessage/delta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": message_id,
                        "delta": text,
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "agentMessage",
                            "id": message_id,
                            "text": text,
                        },
                    },
                ),
            ]
        )

    def _build_fake_watchdog_resolution_text(self) -> str | None:
        payload = self.watchdog_decisions.popleft() if self.watchdog_decisions else {
            "action": "continue_root_turn",
            "rationale": "The task is incomplete and the next durable step is to continue the root turn.",
        }
        return (
            f"{WATCHDOG_DECISION_BEGIN}\n"
            f"{json.dumps(payload, sort_keys=True)}\n"
            f"{WATCHDOG_DECISION_END}"
        )


@dataclass(slots=True)
class FakeStartupTurnWriter:
    client: FakeCodexClient
    watchdog_decisions: deque[dict[str, object]] = field(default_factory=deque)
    headless_writer: FakeHeadlessTurnWriter = field(init=False)

    def __post_init__(self) -> None:
        self.headless_writer = FakeHeadlessTurnWriter(
            client=self.client,
            watchdog_decisions=self.watchdog_decisions,
        )

    def handle_turn(self, session: CodexThreadSession, input_text: str, turn_counter: int) -> None:
        startup_text = _build_fake_startup_resolution_text(input_text)
        if startup_text is None:
            self.headless_writer.handle_turn(session, input_text, turn_counter)
            return
        message_id = f"message-{turn_counter}"
        self.client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {"type": "agentMessage", "id": message_id, "text": ""},
                    },
                ),
                FakeNotification(
                    method="item/agentMessage/delta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": message_id,
                        "delta": startup_text,
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "agentMessage",
                            "id": message_id,
                            "text": startup_text,
                        },
                    },
                ),
            ]
        )


def _extract_contract(input_text: str) -> dict[str, object] | None:
    match = _CONTRACT_RE.search(input_text)
    if match is None:
        return None
    return json.loads(match.group("json"))


def _build_fake_startup_resolution_text(input_text: str) -> str | None:
    if STARTUP_DECISION_BEGIN not in input_text or STARTUP_DECISION_END not in input_text:
        return None
    latest_user_text = _extract_startup_latest_user_text(input_text)
    if latest_user_text is None:
        return None
    prior_answers = _extract_startup_prior_answers(input_text)
    assessment = assess_intake_answers(*prior_answers, latest_user_text)
    if assessment.is_sufficient:
        payload = {
            "kind": "resolved",
            "intake_summary": compose_intake_summary(*prior_answers, latest_user_text),
        }
    else:
        payload = {
            "kind": "clarify",
            "question": assessment.next_question,
        }
    return (
        f"{STARTUP_DECISION_BEGIN}\n"
        f"{json.dumps(payload, sort_keys=True)}\n"
        f"{STARTUP_DECISION_END}"
    )


def _extract_startup_prior_answers(input_text: str) -> tuple[str, ...]:
    match = _STARTUP_PRIOR_ANSWERS_RE.search(input_text)
    if match is None:
        return ()
    answers: list[str] = []
    for line in match.group("answers").splitlines():
        stripped = line.strip()
        if not stripped.startswith("- "):
            continue
        value = stripped[2:].strip()
        if value and value != "none yet":
            answers.append(value)
    return tuple(answers)


def _extract_startup_latest_user_text(input_text: str) -> str | None:
    match = _STARTUP_LATEST_MESSAGE_RE.search(input_text)
    if match is None:
        return None
    message = match.group("message").strip()
    return message or None


def _resolve_fake_execute_artifact_path(
    workspace: Path,
    raw_artifact_path: str | None,
    *,
    goal: str,
) -> str:
    readme_path = workspace / "README.md"
    normalized_goal = goal.lower()
    prefers_readme = any(
        token in normalized_goal
        for token in ("typo", "spelling", "readme", "docs", "documentation")
    )
    if raw_artifact_path is None:
        return "README.md" if prefers_readme and readme_path.exists() else "src/parser.py"
    normalized = raw_artifact_path.strip()
    if not normalized or normalized in {"code", "src", "src/"}:
        return "README.md" if prefers_readme and readme_path.exists() else "src/parser.py"
    if normalized in {"prd", "todo", "docs", "docs/"}:
        return "README.md" if readme_path.exists() else "docs/README.md"
    if normalized.endswith("/"):
        if prefers_readme and readme_path.exists():
            return "README.md"
        return f"{normalized.rstrip('/')}/README.md"
    return normalized


def _fixed_utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
