"""Runtime-to-shell events for the experimental chat shell."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, RootModel

from ralphception.models.artifacts import DurableModel


class _ProtocolModel(DurableModel):
    """Shared configuration for chat-shell protocol models."""


class TranscriptDeltaEvent(_ProtocolModel):
    kind: Literal["transcript_delta"]
    thread_id: str
    cell_id: str
    author: Literal["user", "assistant", "system"]
    delta: str


class TranscriptCommittedEvent(_ProtocolModel):
    kind: Literal["transcript_committed"]
    thread_id: str
    cell_id: str
    author: Literal["user", "assistant", "system"]
    text: str


class StatusUpdatedEvent(_ProtocolModel):
    kind: Literal["status_updated"]
    thread_id: str
    phase: str
    summary: str
    busy: bool = False


class ReviewRequestedEvent(_ProtocolModel):
    kind: Literal["review_requested"]
    thread_id: str
    review_kind: str
    title: str
    summary: str
    actions: list[Literal["approve", "reject", "defer"]] = Field(min_length=1)


class ReviewResolvedEvent(_ProtocolModel):
    kind: Literal["review_resolved"]
    thread_id: str
    review_kind: str
    resolution: Literal["approved", "rejected", "dismissed"]


class PromptOption(_ProtocolModel):
    choice_id: str
    label: str
    description: str


class PromptRequestedEvent(_ProtocolModel):
    kind: Literal["prompt_requested"]
    thread_id: str
    prompt_id: str
    title: str
    question: str
    options: list[PromptOption] = Field(min_length=1)


class PromptResolvedEvent(_ProtocolModel):
    kind: Literal["prompt_resolved"]
    thread_id: str
    prompt_id: str
    choice_id: str


class SubagentSpawnedEvent(_ProtocolModel):
    kind: Literal["subagent_spawned"]
    thread_id: str
    agent_thread_id: str
    nickname: str
    role: str
    summary: str


class SubagentWaitingEvent(_ProtocolModel):
    kind: Literal["subagent_waiting"]
    thread_id: str
    agent_thread_id: str
    summary: str


class SubagentCompletedEvent(_ProtocolModel):
    kind: Literal["subagent_completed"]
    thread_id: str
    agent_thread_id: str
    summary: str


class SubagentFailedEvent(_ProtocolModel):
    kind: Literal["subagent_failed"]
    thread_id: str
    agent_thread_id: str
    summary: str


class SubagentClosedEvent(_ProtocolModel):
    kind: Literal["subagent_closed"]
    thread_id: str
    agent_thread_id: str
    summary: str


class ThreadSummary(_ProtocolModel):
    thread_id: str
    title: str
    kind: Literal["root", "worker", "explorer", "review"]
    status: Literal["running", "waiting", "completed", "failed", "closed"]
    parent_thread_id: str | None = None


class SessionThreadsUpdatedEvent(_ProtocolModel):
    kind: Literal["session_threads_updated"]
    thread_id: str
    threads: list[ThreadSummary]


class ActiveThreadChangedEvent(_ProtocolModel):
    kind: Literal["active_thread_changed"]
    thread_id: str
    active_thread_id: str


RuntimeEventPayload = Annotated[
    TranscriptDeltaEvent
    | TranscriptCommittedEvent
    | StatusUpdatedEvent
    | ReviewRequestedEvent
    | ReviewResolvedEvent
    | PromptRequestedEvent
    | PromptResolvedEvent
    | SubagentSpawnedEvent
    | SubagentWaitingEvent
    | SubagentCompletedEvent
    | SubagentFailedEvent
    | SubagentClosedEvent
    | SessionThreadsUpdatedEvent
    | ActiveThreadChangedEvent,
    Field(discriminator="kind"),
]


class RuntimeEvent(RootModel[RuntimeEventPayload]):
    """Discriminated-union wrapper for runtime events."""

    def __getattr__(self, name: str) -> object:
        return getattr(self.root, name)
