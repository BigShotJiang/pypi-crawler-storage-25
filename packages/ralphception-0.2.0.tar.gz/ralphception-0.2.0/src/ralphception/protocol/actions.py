"""Shell-to-runtime actions for the experimental chat shell."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field, RootModel, field_validator

from ralphception.models.artifacts import DurableModel


class _ProtocolModel(DurableModel):
    """Shared configuration for chat-shell protocol models."""


class SendUserMessageAction(_ProtocolModel):
    kind: Literal["send_user_message"]
    thread_id: str
    text: str

    @field_validator("text")
    @classmethod
    def validate_text(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("text must not be blank")
        return value


class SwitchThreadAction(_ProtocolModel):
    kind: Literal["switch_thread"]
    thread_id: str


class ReviewDecisionAction(_ProtocolModel):
    kind: Literal["review_decision"]
    thread_id: str
    review_kind: str
    decision: Literal["approve", "reject", "defer"]


class ResolvePromptAction(_ProtocolModel):
    kind: Literal["resolve_prompt"]
    thread_id: str
    prompt_id: str
    choice_id: str
    freeform_text: str | None = None


class ApplyRecoveryAction(_ProtocolModel):
    kind: Literal["apply_recovery_action"]
    thread_id: str
    recovery_action: str


ShellActionPayload = Annotated[
    SendUserMessageAction
    | SwitchThreadAction
    | ReviewDecisionAction
    | ResolvePromptAction
    | ApplyRecoveryAction,
    Field(discriminator="kind"),
]


class ShellAction(RootModel[ShellActionPayload]):
    """Discriminated-union wrapper for shell actions."""

    def __getattr__(self, name: str) -> object:
        return getattr(self.root, name)
