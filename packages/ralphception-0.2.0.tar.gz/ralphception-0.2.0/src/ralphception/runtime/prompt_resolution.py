"""Constrained prompt-reply resolution helpers."""

from __future__ import annotations

import re
from typing import Literal

from pydantic import Field

from ralphception.codex.session_manager import CodexSessionManager
from ralphception.models.artifacts import DurableModel
from ralphception.runtime.bootstrap import assess_intake_answers
from ralphception.runtime.prompt_state import PendingPrompt, STARTUP_INTAKE_ANSWERS_KEY
from ralphception.runtime.startup_llm import normalize_startup_clarifying_question


class PromptResolutionResult(DurableModel):
    """Outcome of resolving a prompt reply."""

    kind: Literal["resolved", "clarify"]
    action: str | None = None
    clarifying_question: str | None = None
    intake_summary: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)


_APPROVE_PROMPT_KINDS = {"review_decision", "review_prompt", "spec_review", "execution_bundle"}
_ABORT_PROMPT_KINDS = {
    "abort",
    "abort_mission",
    "launch_conflict",
    "mission_conflict",
    "recovery_review",
    "startup_conflict",
    "startup_prompt",
}
_RECOVERY_PROMPT_KINDS = {"recovery_action", "recovery_decision", "recovery_review"}
_RESUME_PROMPT_KINDS = {"resume_session", "session_resume", "resume_prompt"}
_STARTUP_PROMPT_KINDS = {"startup_prompt"}

_ACTION_SYNONYMS: dict[str, tuple[str, ...]] = {
    "resume": ("continue where we left off", "continue", "resume", "pick up", "keep going", "resume it"),
    "start_fresh": ("start fresh", "start over", "fresh start", "new session", "reset"),
    "continue_current_task": (
        "continue current task",
        "keep working on this",
        "same task",
        "treat it as follow up",
        "follow up",
    ),
    "revise_current_task": (
        "revise current task",
        "scope revision",
        "change current scope",
        "treat it as a revision",
        "scope change",
    ),
    "start_new_task": ("start new task", "different task", "new task", "treat it as new"),
    "override": ("override", "start", "start new", "new session", "replace it"),
    "retry": ("retry", "try again", "again", "give it another try"),
    "restart": ("restart", "restart it", "start it again"),
    "replace": ("replace", "swap", "take another approach"),
    "pause": ("pause", "hold here", "wait here", "stop here", "leave it paused"),
    "approve": ("approve", "looks good", "ok", "okay", "yes", "confirm", "ship it"),
    "abort": ("abort", "cancel", "stop", "never mind", "quit"),
}


def resolve_prompt_reply(
    prompt: PendingPrompt,
    user_text: str,
    *,
    session_manager: CodexSessionManager | None,
) -> PromptResolutionResult:
    """Resolve a prompt reply using a constrained action set."""

    direct_resolver = getattr(session_manager, "resolve_prompt_reply", None) if session_manager is not None else None
    if callable(direct_resolver):
        resolved = direct_resolver(prompt=prompt, user_text=user_text)
        if resolved is None:
            return _resolve_locally(prompt=prompt, user_text=user_text)
        if isinstance(resolved, PromptResolutionResult):
            parsed = resolved
        else:
            parsed = PromptResolutionResult.model_validate(resolved)
        if _prompt_kind_allows_startup(prompt.prompt_kind):
            prior_answers = tuple(_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY))
            assessment = assess_intake_answers(*prior_answers, user_text)
            if parsed.kind == "resolved" and not assessment.is_sufficient:
                return PromptResolutionResult(
                    kind="clarify",
                    clarifying_question=normalize_startup_clarifying_question(
                        question=parsed.clarifying_question or assessment.next_question,
                        latest_user_text=user_text,
                        prior_answers=prior_answers,
                    ),
                    confidence=min(parsed.confidence, 0.4),
                )
            if parsed.kind == "clarify":
                return parsed.model_copy(
                    update={
                        "clarifying_question": normalize_startup_clarifying_question(
                            question=parsed.clarifying_question or prompt.question,
                            latest_user_text=user_text,
                            prior_answers=prior_answers,
                        )
                    }
                )
        return parsed

    return _resolve_locally(prompt=prompt, user_text=user_text)


def _resolve_locally(prompt: PendingPrompt, user_text: str) -> PromptResolutionResult:
    normalized_text = _normalize_text(user_text)
    if _prompt_kind_allows_startup(prompt.prompt_kind):
        return _resolve_startup_prompt(prompt, user_text)
    allowed_actions = tuple(_normalize_action_label(action) for action in prompt.allowed_actions)
    candidate_scores: dict[str, float] = {}

    for action in allowed_actions:
        score = _score_action(prompt=prompt, action=action, normalized_text=normalized_text)
        if score is not None:
            candidate_scores[action] = score

    if len(candidate_scores) == 1:
        action, confidence = next(iter(candidate_scores.items()))
        return PromptResolutionResult(kind="resolved", action=action, confidence=confidence)

    if len(candidate_scores) > 1:
        return _clarify(prompt, normalized_text)

    return _clarify(prompt, normalized_text)


def _resolve_startup_prompt(prompt: PendingPrompt, user_text: str) -> PromptResolutionResult:
    if not user_text.strip():
        return PromptResolutionResult(
            kind="clarify",
            clarifying_question=normalize_startup_clarifying_question(
                question=prompt.question,
                latest_user_text=user_text,
                prior_answers=tuple(_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY)),
            ),
            confidence=0.2,
        )
    assessment = assess_intake_answers(*_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY), user_text)
    if not assessment.is_sufficient:
        return PromptResolutionResult(
            kind="clarify",
            clarifying_question=normalize_startup_clarifying_question(
                question=assessment.next_question,
                latest_user_text=user_text,
                prior_answers=tuple(_context_str_list(prompt, STARTUP_INTAKE_ANSWERS_KEY)),
            ),
            confidence=0.2,
        )
    return PromptResolutionResult(kind="resolved", action="bootstrap", confidence=0.9)


def _score_action(prompt: PendingPrompt, action: str, *, normalized_text: str) -> float | None:
    if action == "approve" and not _prompt_kind_allows_approve(prompt.prompt_kind):
        return None
    if action == "abort" and not _prompt_kind_allows_abort(prompt.prompt_kind):
        return None
    if action in {"retry", "restart", "replace", "pause"} and not _prompt_kind_allows_recovery(prompt.prompt_kind):
        return None
    if action in {"resume", "start_fresh"} and not _prompt_kind_allows_resume(prompt.prompt_kind):
        return None

    for phrase in _ACTION_SYNONYMS.get(action, (action,)):
        if phrase in normalized_text:
            return 0.95 if len(phrase) >= 5 else 0.85

    tokens = set(re.findall(r"[a-z0-9]+", normalized_text))
    if action in tokens:
        return 0.8
    return None


def _clarify(prompt: PendingPrompt, normalized_text: str) -> PromptResolutionResult:
    actions = ", ".join(_humanize_action(action) for action in prompt.allowed_actions)
    question = prompt.question.strip() or prompt.title.strip() or "Which option should I use?"
    if actions:
        question = f"{question} I can choose from: {actions}. Which one do you want?"
    return PromptResolutionResult(kind="clarify", clarifying_question=question, confidence=0.2)


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _normalize_action_label(action: str) -> str:
    return action.strip().lstrip("/").replace("-", "_").replace(" ", "_").lower()


def _humanize_action(action: str) -> str:
    return _normalize_action_label(action).replace("_", " ")


def _prompt_kind_allows_approve(prompt_kind: str) -> bool:
    normalized = _normalize_action_label(prompt_kind)
    return normalized in _APPROVE_PROMPT_KINDS or normalized.endswith("_review") or "review" in normalized


def _prompt_kind_allows_abort(prompt_kind: str) -> bool:
    normalized = _normalize_action_label(prompt_kind)
    return normalized in _ABORT_PROMPT_KINDS or "conflict" in normalized or "abort" in normalized


def _prompt_kind_allows_recovery(prompt_kind: str) -> bool:
    normalized = _normalize_action_label(prompt_kind)
    return normalized in _RECOVERY_PROMPT_KINDS or "recovery" in normalized or "blocked" in normalized or "failed" in normalized


def _prompt_kind_allows_resume(prompt_kind: str) -> bool:
    normalized = _normalize_action_label(prompt_kind)
    return normalized in _RESUME_PROMPT_KINDS or "resume" in normalized or "session" in normalized


def _prompt_kind_allows_startup(prompt_kind: str) -> bool:
    normalized = _normalize_action_label(prompt_kind)
    return normalized in _STARTUP_PROMPT_KINDS


def _context_str_list(prompt: PendingPrompt, key: str) -> list[str]:
    value = prompt.context.get(key)
    if not isinstance(value, list):
        return []
    return [entry for entry in value if isinstance(entry, str) and entry.strip()]


__all__ = [
    "PromptResolutionResult",
    "resolve_prompt_reply",
]
