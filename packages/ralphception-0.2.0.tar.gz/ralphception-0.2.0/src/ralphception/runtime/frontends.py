"""Shared runtime frontend contracts and prompt models."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any
from typing import Literal, Protocol

from ralphception.runtime.prompt_state import PendingPrompt
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeMode

ReviewKind = Literal["spec_review", "execution_bundle", "recovery"]
RuntimeStepKind = Literal["startup_prompt", "review_prompt", "dashboard", "completed", "failed"]


@dataclass(frozen=True, slots=True)
class FrontendEvent:
    message: str
    level: Literal["info", "warning", "error"] = "info"
    run_id: str | None = None
    stage_kind: str | None = None
    kind: str | None = None
    payload: dict[str, Any] | None = None


class RuntimeStatusUpdatedEvent(FrontendEvent):
    status_line_value: str | None
    quota_label: str | None
    __slots__ = ("status_line_value", "quota_label")

    def __init__(
        self,
        *,
        status_line_value: str | None,
        quota_label: str | None,
        kind: str = "runtime.status",
        message: str | None = None,
    ) -> None:
        details = " · ".join(part for part in (status_line_value, quota_label) if part)
        super().__init__(
            message=message or (f"Runtime status updated: {details}" if details else "Runtime status updated"),
            kind=kind,
            payload={
                "status_line_value": status_line_value,
                "quota_label": quota_label,
            },
        )
        object.__setattr__(self, "status_line_value", status_line_value)
        object.__setattr__(self, "quota_label", quota_label)


class LiveStatusEvent(FrontendEvent):
    text: str
    status_line_value: str | None
    quota_label: str | None
    __slots__ = ("text", "status_line_value", "quota_label")

    def __init__(
        self,
        *,
        text: str,
        status_line_value: str | None = None,
        quota_label: str | None = None,
    ) -> None:
        super().__init__(
            message=text,
            kind="runtime.live_status",
            payload={
                "text": text,
                "status_line_value": status_line_value,
                "quota_label": quota_label,
            },
        )
        object.__setattr__(self, "text", text)
        object.__setattr__(self, "status_line_value", status_line_value)
        object.__setattr__(self, "quota_label", quota_label)


class AssistantDeltaEvent(FrontendEvent):
    item_id: str
    text: str
    __slots__ = ("item_id", "text")

    def __init__(self, *, item_id: str, text: str) -> None:
        super().__init__(
            message=f"Agent delta: {text}",
            kind="agent.message.delta",
            payload={"item_id": item_id, "text": text},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "text", text)


class AssistantFinalEvent(FrontendEvent):
    item_id: str | None
    text: str
    __slots__ = ("item_id", "text")

    def __init__(self, *, text: str, item_id: str | None = None) -> None:
        super().__init__(
            message=f"Agent: {text}",
            kind="agent.message",
            payload={"text": text, "item_id": item_id},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "text", text)


class ReasoningSummaryDeltaEvent(FrontendEvent):
    item_id: str
    text: str
    summary_index: int | None
    __slots__ = ("item_id", "text", "summary_index")

    def __init__(self, *, item_id: str, text: str, summary_index: int | None = None) -> None:
        super().__init__(
            message=f"Reasoning summary delta: {text}",
            kind="agent.reasoning.delta",
            payload={"item_id": item_id, "text": text, "summary_index": summary_index},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "text", text)
        object.__setattr__(self, "summary_index", summary_index)


class ReasoningSectionBreakEvent(FrontendEvent):
    item_id: str
    summary_index: int
    __slots__ = ("item_id", "summary_index")

    def __init__(self, *, item_id: str, summary_index: int) -> None:
        super().__init__(
            message=f"Reasoning section break: {item_id}#{summary_index}",
            kind="agent.reasoning.section_break",
            payload={"item_id": item_id, "summary_index": summary_index},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "summary_index", summary_index)


class ReasoningFinalEvent(FrontendEvent):
    item_id: str | None
    text: str | None
    __slots__ = ("item_id", "text")

    def __init__(self, *, item_id: str | None = None, text: str | None = None) -> None:
        super().__init__(
            message="Reasoning completed",
            kind="agent.reasoning.completed",
            payload={"item_id": item_id, "text": text},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "text", text)


class CommandBeginEvent(FrontendEvent):
    item_id: str | None
    command: str
    __slots__ = ("item_id", "command")

    def __init__(self, *, command: str, item_id: str | None = None) -> None:
        super().__init__(
            message=f"Command started: {command}",
            kind="command.started",
            payload={"command": command, "item_id": item_id},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "command", command)


class CommandOutputDeltaEvent(FrontendEvent):
    item_id: str
    text: str
    __slots__ = ("item_id", "text")

    def __init__(self, *, item_id: str, text: str) -> None:
        super().__init__(
            message=f"Command output: {text}",
            kind="command.output.delta",
            payload={"item_id": item_id, "text": text},
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "text", text)


class CommandEndEvent(FrontendEvent):
    item_id: str | None
    command: str
    exit_code: int | None
    status: str | None
    __slots__ = ("item_id", "command", "exit_code", "status")

    def __init__(
        self,
        *,
        command: str,
        item_id: str | None = None,
        exit_code: int | None = None,
        status: str | None = None,
    ) -> None:
        if exit_code is not None:
            message = f"Command completed (exit {exit_code}): {command}"
        elif status is not None and status != "completed":
            message = f"Command {status}: {command}"
        else:
            message = f"Command completed: {command}"
        payload: dict[str, Any] = {"command": command, "item_id": item_id}
        if exit_code is not None:
            payload["exit_code"] = exit_code
        if status is not None:
            payload["status"] = status
        super().__init__(
            message=message,
            kind="command.completed" if status in {None, "completed"} else "command.status",
            payload=payload,
        )
        object.__setattr__(self, "item_id", item_id)
        object.__setattr__(self, "command", command)
        object.__setattr__(self, "exit_code", exit_code)
        object.__setattr__(self, "status", status)


class BackgroundWaitBeginEvent(FrontendEvent):
    process_id: str
    command: str
    summary: str
    __slots__ = ("process_id", "command", "summary")

    def __init__(
        self,
        *,
        process_id: str,
        command: str,
        summary: str | None = None,
        kind: str = "background.wait.started",
    ) -> None:
        wait_summary = summary or f"Waiting on {command}"
        super().__init__(
            message=wait_summary,
            kind=kind,
            payload={"process_id": process_id, "command": command, "summary": wait_summary},
        )
        object.__setattr__(self, "process_id", process_id)
        object.__setattr__(self, "command", command)
        object.__setattr__(self, "summary", wait_summary)


class CurrentWaitingStateEvent(FrontendEvent):
    label: str | None
    cleared: bool
    process_id: str | None
    command: str | None
    __slots__ = ("label", "cleared", "process_id", "command")

    def __init__(
        self,
        *,
        label: str | None = None,
        process_id: str | None = "background",
        command: str | None = None,
        cleared: bool = False,
    ) -> None:
        normalized_label = None if label is None else label.strip() or None
        is_cleared = cleared or normalized_label is None
        super().__init__(
            message="Current waiting cleared" if is_cleared else f"Current waiting: {normalized_label}",
            kind="runtime.current_waiting_state",
            payload={
                "label": None if is_cleared else normalized_label,
                "cleared": is_cleared,
                "process_id": process_id,
                "command": command,
            },
        )
        object.__setattr__(self, "label", None if is_cleared else normalized_label)
        object.__setattr__(self, "cleared", is_cleared)
        object.__setattr__(self, "process_id", process_id)
        object.__setattr__(self, "command", command)

    @classmethod
    def clear(cls) -> "CurrentWaitingStateEvent":
        return cls(cleared=True)


class BackgroundWaitUpdateEvent(FrontendEvent):
    process_id: str
    summary: str
    __slots__ = ("process_id", "summary")

    def __init__(self, *, process_id: str, summary: str) -> None:
        super().__init__(
            message=summary,
            kind="background.wait.updated",
            payload={"process_id": process_id, "summary": summary},
        )
        object.__setattr__(self, "process_id", process_id)
        object.__setattr__(self, "summary", summary)


class BackgroundWaitEndEvent(FrontendEvent):
    process_id: str
    __slots__ = ("process_id",)

    def __init__(self, *, process_id: str) -> None:
        super().__init__(
            message=f"Background wait ended: {process_id}",
            kind="background.wait.ended",
            payload={"process_id": process_id},
        )
        object.__setattr__(self, "process_id", process_id)


class PlanUpdatedEvent(FrontendEvent):
    active_step: str
    steps: tuple[str, ...]
    __slots__ = ("active_step", "steps")

    def __init__(
        self,
        *,
        active_step: str,
        steps: tuple[str, ...],
        kind: str = "turn.plan.updated",
        message: str | None = None,
    ) -> None:
        super().__init__(
            message=message or f"Plan updated: {active_step}",
            kind=kind,
            payload={"active_step": active_step, "steps": steps},
        )
        object.__setattr__(self, "active_step", active_step)
        object.__setattr__(self, "steps", steps)


class CurrentPlanNodeLabelEvent(FrontendEvent):
    label: str | None
    cleared: bool
    __slots__ = ("label", "cleared")

    def __init__(self, *, label: str | None = None, cleared: bool = False) -> None:
        normalized_label = None if label is None else label.strip() or None
        is_cleared = cleared or normalized_label is None
        super().__init__(
            message="Current plan node cleared" if is_cleared else f"Current plan node: {normalized_label}",
            kind="runtime.current_plan_node_label",
            payload={"label": None if is_cleared else normalized_label, "cleared": is_cleared},
        )
        object.__setattr__(self, "label", None if is_cleared else normalized_label)
        object.__setattr__(self, "cleared", is_cleared)

    @classmethod
    def clear(cls) -> "CurrentPlanNodeLabelEvent":
        return cls(cleared=True)


class ReviewRequestedEvent(FrontendEvent):
    review_kind: ReviewKind
    run_id: str
    summary_text: str
    recommended_actions: tuple[str, ...]
    __slots__ = ("review_kind", "run_id", "summary_text", "recommended_actions")

    def __init__(
        self,
        *,
        review_kind: ReviewKind,
        run_id: str,
        summary_text: str,
        recommended_actions: tuple[str, ...],
    ) -> None:
        super().__init__(
            message=f"Review requested: {summary_text}",
            kind="review.requested",
            run_id=run_id,
            payload={
                "review_kind": review_kind,
                "run_id": run_id,
                "summary_text": summary_text,
                "recommended_actions": recommended_actions,
            },
        )
        object.__setattr__(self, "review_kind", review_kind)
        object.__setattr__(self, "run_id", run_id)
        object.__setattr__(self, "summary_text", summary_text)
        object.__setattr__(self, "recommended_actions", recommended_actions)


class ReviewResolvedEvent(FrontendEvent):
    review_kind: ReviewKind
    resolution: str
    __slots__ = ("review_kind", "resolution")

    def __init__(self, *, review_kind: ReviewKind, resolution: str) -> None:
        super().__init__(
            message=f"Review resolved: {review_kind} -> {resolution}",
            kind="review.resolved",
            payload={"review_kind": review_kind, "resolution": resolution},
        )
        object.__setattr__(self, "review_kind", review_kind)
        object.__setattr__(self, "resolution", resolution)


class RequestUserInputRequestedEvent(FrontendEvent):
    prompt_id: str
    title: str
    question: str
    options: tuple[str, ...]
    __slots__ = ("prompt_id", "title", "question", "options")

    def __init__(
        self,
        *,
        prompt_id: str,
        title: str,
        question: str,
        options: tuple[str, ...],
    ) -> None:
        super().__init__(
            message=f"Input requested: {title}",
            kind="request_user_input.requested",
            payload={
                "prompt_id": prompt_id,
                "title": title,
                "question": question,
                "options": options,
            },
        )
        object.__setattr__(self, "prompt_id", prompt_id)
        object.__setattr__(self, "title", title)
        object.__setattr__(self, "question", question)
        object.__setattr__(self, "options", options)


class RequestUserInputResolvedEvent(FrontendEvent):
    prompt_id: str
    choice: str
    __slots__ = ("prompt_id", "choice")

    def __init__(self, *, prompt_id: str, choice: str) -> None:
        super().__init__(
            message=f"Input resolved: {prompt_id}",
            kind="request_user_input.resolved",
            payload={"prompt_id": prompt_id, "choice": choice},
        )
        object.__setattr__(self, "prompt_id", prompt_id)
        object.__setattr__(self, "choice", choice)


class TurnStartedEvent(FrontendEvent):
    attempt: int | None
    __slots__ = ("attempt",)

    def __init__(self, *, attempt: int | None = None) -> None:
        payload = {"attempt": attempt} if attempt is not None else None
        message = "Turn started" if attempt is None else f"Turn started: attempt {attempt}"
        super().__init__(message=message, kind="turn.started", payload=payload)
        object.__setattr__(self, "attempt", attempt)


class TurnCompletedEvent(FrontendEvent):
    __slots__ = ()

    def __init__(self) -> None:
        super().__init__(message="Turn completed", kind="turn.completed")


class TurnFailedEvent(FrontendEvent):
    reason: str
    __slots__ = ("reason",)

    def __init__(self, *, reason: str) -> None:
        super().__init__(message=f"Turn failed: {reason}", kind="turn.failed", level="error")
        object.__setattr__(self, "reason", reason)


class ErrorEvent(FrontendEvent):
    __slots__ = ()

    def __init__(self, *, message: str) -> None:
        super().__init__(message=message, kind="error", level="error")


class MilestoneTranscriptEvent(FrontendEvent):
    __slots__ = ()

    def __init__(self, *, message: str, kind: str, payload: dict[str, Any] | None = None) -> None:
        super().__init__(message=message, kind=kind, payload=payload)


class MilestoneTranscriptLineEvent(MilestoneTranscriptEvent):
    __slots__ = ()

    def __init__(self, *, message: str) -> None:
        super().__init__(
            message=message,
            kind="runtime.milestone_transcript_line",
        )


class ArtifactWriteEvent(MilestoneTranscriptEvent):
    artifact_kind: str
    artifact_path: str
    __slots__ = ("artifact_kind", "artifact_path")

    def __init__(self, *, artifact_kind: str, artifact_path: str, message: str) -> None:
        super().__init__(
            message=message,
            kind="runtime.artifact_write",
            payload={"artifact_kind": artifact_kind, "artifact_path": artifact_path},
        )
        object.__setattr__(self, "artifact_kind", artifact_kind)
        object.__setattr__(self, "artifact_path", artifact_path)


class LoopLaunchEvent(MilestoneTranscriptEvent):
    loop_label: str
    __slots__ = ("loop_label",)

    def __init__(self, *, loop_label: str, message: str) -> None:
        super().__init__(
            message=message,
            kind="runtime.loop_launch",
            payload={"loop_label": loop_label},
        )
        object.__setattr__(self, "loop_label", loop_label)


class LoopCompletionEvent(MilestoneTranscriptEvent):
    loop_label: str
    __slots__ = ("loop_label",)

    def __init__(self, *, loop_label: str, message: str) -> None:
        super().__init__(
            message=message,
            kind="runtime.loop_completion",
            payload={"loop_label": loop_label},
        )
        object.__setattr__(self, "loop_label", loop_label)


class FailureSummaryEvent(MilestoneTranscriptEvent):
    summary: str
    __slots__ = ("summary",)

    def __init__(self, *, summary: str, message: str | None = None) -> None:
        super().__init__(
            message=message or summary,
            kind="runtime.failure_summary",
            payload={"summary": summary},
        )
        object.__setattr__(self, "summary", summary)


class CurrentTaskLabelEvent(FrontendEvent):
    label: str | None
    cleared: bool
    __slots__ = ("label", "cleared")

    def __init__(self, *, label: str | None = None, cleared: bool = False) -> None:
        normalized_label = None if label is None else label.strip() or None
        is_cleared = cleared or normalized_label is None
        super().__init__(
            message="Current task cleared" if is_cleared else f"Current task: {normalized_label}",
            kind="runtime.current_task_label",
            payload={"label": None if is_cleared else normalized_label, "cleared": is_cleared},
        )
        object.__setattr__(self, "label", None if is_cleared else normalized_label)
        object.__setattr__(self, "cleared", is_cleared)

    @classmethod
    def clear(cls) -> "CurrentTaskLabelEvent":
        return cls(cleared=True)


class CurrentLoopLabelEvent(FrontendEvent):
    label: str | None
    cleared: bool
    __slots__ = ("label", "cleared")

    def __init__(self, *, label: str | None = None, cleared: bool = False) -> None:
        normalized_label = None if label is None else label.strip() or None
        is_cleared = cleared or normalized_label is None
        super().__init__(
            message="Current loop cleared" if is_cleared else f"Current loop: {normalized_label}",
            kind="runtime.current_loop_label",
            payload={"label": None if is_cleared else normalized_label, "cleared": is_cleared},
        )
        object.__setattr__(self, "label", None if is_cleared else normalized_label)
        object.__setattr__(self, "cleared", is_cleared)

    @classmethod
    def clear(cls) -> "CurrentLoopLabelEvent":
        return cls(cleared=True)


class CurrentBlockerStateEvent(FrontendEvent):
    label: str | None
    cleared: bool
    __slots__ = ("label", "cleared")

    def __init__(self, *, label: str | None = None, cleared: bool = False) -> None:
        normalized_label = None if label is None else label.strip() or None
        is_cleared = cleared or normalized_label is None
        super().__init__(
            message="Current blocker cleared" if is_cleared else f"Current blocker: {normalized_label}",
            kind="runtime.current_blocker_state",
            payload={"label": None if is_cleared else normalized_label, "cleared": is_cleared},
        )
        object.__setattr__(self, "label", None if is_cleared else normalized_label)
        object.__setattr__(self, "cleared", is_cleared)

    @classmethod
    def clear(cls) -> "CurrentBlockerStateEvent":
        return cls(cleared=True)


class BlockerPromptEvent(FrontendEvent):
    prompt_id: str
    title: str
    question: str
    __slots__ = ("prompt_id", "title", "question")

    def __init__(self, *, prompt_id: str, title: str, question: str) -> None:
        super().__init__(
            message=question,
            kind="runtime.blocker_prompt",
            payload={"prompt_id": prompt_id, "title": title, "question": question},
        )
        object.__setattr__(self, "prompt_id", prompt_id)
        object.__setattr__(self, "title", title)
        object.__setattr__(self, "question", question)


@dataclass(frozen=True, slots=True)
class ReviewDecision:
    action: Literal["approve", "resume", "retry", "restart", "replace", "abort", "pause"]
    approver: str | None = None
    resume_mode: ResumeMode = "read"


@dataclass(frozen=True, slots=True)
class RuntimeStep:
    kind: RuntimeStepKind
    pending_prompt: PendingPrompt | None = None
    engine: WorkflowEngine | None = None


class RuntimeFrontend(Protocol):
    def emit_event(self, event: FrontendEvent) -> None: ...

    def emit_status(self, step: RuntimeStep) -> None: ...

    def finish(self, step: RuntimeStep) -> None: ...


def format_review_actions(actions: Sequence[str]) -> tuple[str, ...]:
    return tuple(actions)


__all__ = [
    "AssistantDeltaEvent",
    "AssistantFinalEvent",
    "ArtifactWriteEvent",
    "BackgroundWaitBeginEvent",
    "BackgroundWaitEndEvent",
    "BackgroundWaitUpdateEvent",
    "BlockerPromptEvent",
    "CommandBeginEvent",
    "CommandEndEvent",
    "CommandOutputDeltaEvent",
    "CurrentBlockerStateEvent",
    "CurrentLoopLabelEvent",
    "CurrentPlanNodeLabelEvent",
    "CurrentTaskLabelEvent",
    "CurrentWaitingStateEvent",
    "ErrorEvent",
    "FailureSummaryEvent",
    "FrontendEvent",
    "LiveStatusEvent",
    "LoopCompletionEvent",
    "LoopLaunchEvent",
    "MilestoneTranscriptEvent",
    "MilestoneTranscriptLineEvent",
    "PlanUpdatedEvent",
    "RequestUserInputRequestedEvent",
    "RequestUserInputResolvedEvent",
    "ReasoningFinalEvent",
    "ReasoningSectionBreakEvent",
    "ReasoningSummaryDeltaEvent",
    "ReviewDecision",
    "ReviewKind",
    "ReviewRequestedEvent",
    "ReviewResolvedEvent",
    "RuntimeFrontend",
    "RuntimeStatusUpdatedEvent",
    "RuntimeStep",
    "TurnCompletedEvent",
    "TurnFailedEvent",
    "TurnStartedEvent",
]
