"""Durable root-watchdog records and decision contracts for idle continuation."""

from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal

from pydantic import Field

from ralphception.models.artifacts import DurableModel
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.frontier import TaskFrontier
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic

WatchdogAction = Literal[
    "continue_root_turn",
    "launch_child_loop",
    "reopen_existing_loop",
    "revise_plan",
    "ask_user",
    "compact_root_thread",
    "mark_complete",
]

WATCHDOG_DECISION_BEGIN = "RALPHCEPTION_WATCHDOG_DECISION_START"
WATCHDOG_DECISION_END = "RALPHCEPTION_WATCHDOG_DECISION_END"

_WATCHDOG_FILENAME = "root-watchdog.json"
_ROOT_WATCHDOG_ID = "root-watchdog"
_WATCHDOG_ACTIVATION_DIRNAME = "watchdog-activations"
_WATCHDOG_PROMPT_TEMPLATE = "root_watchdog_decision_v1"
_DEFAULT_ALLOWED_ACTIONS: tuple[WatchdogAction, ...] = (
    "continue_root_turn",
    "launch_child_loop",
    "reopen_existing_loop",
    "revise_plan",
    "ask_user",
    "compact_root_thread",
    "mark_complete",
)
_WATCHDOG_DECISION_RE = re.compile(
    rf"{WATCHDOG_DECISION_BEGIN}\s*(?P<json>\{{.*?\}})\s*{WATCHDOG_DECISION_END}",
    re.DOTALL,
)


class WatchdogDefinition(DurableModel):
    class WatchdogActivationPolicy(DurableModel):
        idle_timeout_seconds: int = Field(default=0, ge=0)
        stuck_threshold: int = Field(default=2, ge=0)

    watchdog_id: str = _ROOT_WATCHDOG_ID
    root_run_id: str
    task_id: str | None = None
    goal: str
    artifact_refs: tuple[str, ...] = ()
    prompt_template: str = _WATCHDOG_PROMPT_TEMPLATE
    scope: str = "root_task"
    allowed_actions: tuple[WatchdogAction, ...] = _DEFAULT_ALLOWED_ACTIONS
    cooldown_seconds: int = Field(default=30, ge=0)
    activation_policy: WatchdogActivationPolicy = Field(default_factory=WatchdogActivationPolicy)
    active: bool = True
    last_trigger_reason: str | None = None
    last_activated_at: datetime | None = None
    updated_at: datetime


WatchdogActivationPolicy = WatchdogDefinition.WatchdogActivationPolicy


class WatchdogActivation(DurableModel):
    activation_id: str
    watchdog_id: str
    task_id: str
    root_run_id: str
    trigger_reason: str
    source_thread_id: str | None = None
    input_snapshot: "WatchdogInputSnapshot"
    result: "WatchdogDecision"
    created_child_thread_id: str | None = None
    created_at: datetime

    @property
    def action(self) -> WatchdogAction:
        return self.result.action

    @property
    def rationale(self) -> str | None:
        return self.result.rationale

    @property
    def activated_at(self) -> datetime:
        return self.created_at


class WatchdogInputSnapshot(DurableModel):
    goal: str
    trigger_reason: str
    frontier: TaskFrontier
    artifact_paths: tuple[str, ...] = ()
    recent_runtime_events: tuple[str, ...] = ()


class WatchdogDecision(DurableModel):
    action: WatchdogAction
    rationale: str
    question: str | None = None
    target_run_id: str | None = None
    plan_revision_summary: str | None = None
    compact_reason: str | None = None


class WatchdogResolution(DurableModel):
    decision: WatchdogDecision
    source_thread_id: str | None = None
    created_child_thread_id: str | None = None


def watchdog_path(repo_root: Path) -> Path:
    resolved_root = bootstrap_workspace(repo_root)
    return resolved_root / ".ralphception" / "runtime" / _WATCHDOG_FILENAME


def watchdog_activation_dir(repo_root: Path) -> Path:
    resolved_root = bootstrap_workspace(repo_root)
    return resolved_root / ".ralphception" / "runtime" / _WATCHDOG_ACTIVATION_DIRNAME


def load_root_watchdog(repo_root: Path) -> WatchdogDefinition | None:
    path = watchdog_path(repo_root)
    if not path.exists():
        return None
    return WatchdogDefinition.model_validate_json(path.read_text(encoding="utf-8"))


def clear_root_watchdog(repo_root: Path) -> None:
    path = watchdog_path(repo_root)
    if path.exists():
        path.unlink()


def write_root_watchdog(repo_root: Path, definition: WatchdogDefinition) -> WatchdogDefinition:
    write_json_atomic(watchdog_path(repo_root), definition.model_dump(mode="json"))
    return definition


def ensure_root_watchdog(repo_root: Path) -> WatchdogDefinition | None:
    startup_record = load_startup_record(repo_root)
    existing = load_root_watchdog(repo_root)
    if startup_record is None:
        return existing
    now = datetime.now(timezone.utc)
    definition = WatchdogDefinition(
        root_run_id=startup_record.outer_run_id,
        task_id=startup_record.outer_run_id,
        goal=startup_record.seed_prompt,
        cooldown_seconds=0,
        activation_policy=(
            WatchdogActivationPolicy()
            if existing is None
            else existing.activation_policy
        ),
        artifact_refs=() if existing is None else existing.artifact_refs,
        prompt_template=_WATCHDOG_PROMPT_TEMPLATE if existing is None else existing.prompt_template,
        scope="root_task" if existing is None else existing.scope,
        last_trigger_reason=None if existing is None else existing.last_trigger_reason,
        last_activated_at=None if existing is None else existing.last_activated_at,
        updated_at=now,
    )
    return write_root_watchdog(repo_root, definition)


def can_activate_root_watchdog(definition: WatchdogDefinition, *, now: datetime | None = None) -> bool:
    if not definition.active:
        return False
    resolved_now = datetime.now(timezone.utc) if now is None else now
    if definition.last_activated_at is None:
        return True
    cooldown = timedelta(seconds=definition.cooldown_seconds)
    return resolved_now - definition.last_activated_at >= cooldown


def can_activate_root_watchdog_for_frontier(
    definition: WatchdogDefinition,
    frontier: TaskFrontier,
    *,
    now: datetime | None = None,
) -> bool:
    if not can_activate_root_watchdog(definition, now=now):
        return False
    if not frontier_allows_watchdog_activation(frontier):
        return False
    resolved_now = datetime.now(timezone.utc) if now is None else now
    policy = definition.activation_policy
    if frontier.stuck_count >= policy.stuck_threshold > 0:
        return True
    if frontier.last_progress_at is None:
        return True
    if policy.idle_timeout_seconds <= 0:
        return True
    return resolved_now - frontier.last_progress_at >= timedelta(seconds=policy.idle_timeout_seconds)


def frontier_allows_watchdog_activation(frontier: TaskFrontier) -> bool:
    if not frontier.frontier_items:
        return False
    if frontier.status == "completed":
        return False
    if frontier.blocked_reason == "recovery_review":
        return True
    if any(item.kind in {"pending_prompt", "review_prompt"} for item in frontier.frontier_items):
        return False
    return True


def build_watchdog_decision_prompt(
    *,
    goal: str,
    trigger_reason: str,
    frontier: TaskFrontier,
    artifact_paths: tuple[str, ...],
    recent_runtime_events: tuple[str, ...],
    allowed_actions: tuple[WatchdogAction, ...] = _DEFAULT_ALLOWED_ACTIONS,
) -> str:
    frontier_lines = "\n".join(
        f"- kind={item.kind}; summary={item.summary}; run_id={item.run_id or 'none'}; stage={item.stage_kind or 'none'}"
        for item in frontier.frontier_items
    ) or "- none"
    artifact_lines = "\n".join(f"- {path}" for path in artifact_paths) or "- none"
    event_lines = "\n".join(f"- {line}" for line in recent_runtime_events) or "- none"
    stuck_lines = "\n".join(
        f"- {signal.reason}: {signal.count}"
        for signal in frontier.stuck_signals
    ) or "- none"
    allowed_actions_text = "\n".join(f"- {action}" for action in allowed_actions)
    return (
        "You are Ralphception's root watchdog. Treat the prior transcript as the work of another agent.\n"
        "You are an impartial continuation supervisor whose job is to pick the next constrained action that best advances the user's goal.\n"
        "Prefer durable progress over transcript churn. Use the frontier, artifacts, and recent runtime events as the source of truth.\n"
        "If the thread looks repetitive or stuck, prefer `compact_root_thread`.\n"
        "If durable work is already complete, choose `mark_complete`.\n"
        "If you need missing information from the user, choose `ask_user` and provide exactly one focused question.\n\n"
        f"Goal:\n- {goal}\n\n"
        f"Trigger reason:\n- {trigger_reason}\n\n"
        "Frontier:\n"
        f"- status: {frontier.status}\n"
        f"- current_stage: {frontier.current_stage or 'none'}\n"
        f"- active_loop_ids: {', '.join(frontier.active_loop_ids) or 'none'}\n"
        f"- stuck_count: {frontier.stuck_count}\n"
        "Frontier items:\n"
        f"{frontier_lines}\n\n"
        "Stuck signals:\n"
        f"{stuck_lines}\n\n"
        "Artifact paths:\n"
        f"{artifact_lines}\n\n"
        "Recent runtime events:\n"
        f"{event_lines}\n\n"
        "Allowed actions:\n"
        f"{allowed_actions_text}\n\n"
        "Respond with JSON only between the markers below.\n"
        "Required fields: `action`, `rationale`.\n"
        "Optional fields:\n"
        "- `question` when action=`ask_user`\n"
        "- `target_run_id` when action=`reopen_existing_loop`\n"
        "- `plan_revision_summary` when action=`revise_plan`\n"
        "- `compact_reason` when action=`compact_root_thread`\n\n"
        f"{WATCHDOG_DECISION_BEGIN}\n"
        '{"action":"continue_root_turn","rationale":"brief reason"}\n'
        f"{WATCHDOG_DECISION_END}"
    )


def parse_watchdog_decision(
    assistant_text: str,
    *,
    allowed_actions: tuple[WatchdogAction, ...] = _DEFAULT_ALLOWED_ACTIONS,
) -> WatchdogDecision | None:
    match = _WATCHDOG_DECISION_RE.search(assistant_text)
    if match is None:
        return None
    try:
        payload = json.loads(match.group("json"))
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    try:
        decision = WatchdogDecision.model_validate(payload)
    except Exception:
        return None
    if decision.action not in allowed_actions:
        return None
    if decision.action == "ask_user" and not (decision.question and decision.question.strip()):
        return None
    if decision.action == "compact_root_thread" and not (decision.compact_reason and decision.compact_reason.strip()):
        return None
    if decision.action == "revise_plan" and not (
        decision.plan_revision_summary and decision.plan_revision_summary.strip()
    ):
        return None
    return decision


def record_root_watchdog_activation(
    repo_root: Path,
    *,
    trigger_reason: str,
    input_snapshot: WatchdogInputSnapshot,
    result: WatchdogDecision,
    source_thread_id: str | None = None,
    created_child_thread_id: str | None = None,
) -> WatchdogActivation | None:
    definition = ensure_root_watchdog(repo_root)
    if definition is None:
        return None
    created_at = datetime.now(timezone.utc)
    updated = definition.model_copy(
        update={
            "last_trigger_reason": trigger_reason,
            "last_activated_at": created_at,
            "updated_at": created_at,
            "artifact_refs": input_snapshot.artifact_paths,
            "prompt_template": _WATCHDOG_PROMPT_TEMPLATE,
            "task_id": definition.task_id or definition.root_run_id,
        }
    )
    write_json_atomic(watchdog_path(repo_root), updated.model_dump(mode="json"))
    activation = WatchdogActivation(
        activation_id=f"watchdog-activation-{uuid.uuid4().hex}",
        watchdog_id=updated.watchdog_id,
        task_id=updated.task_id or updated.root_run_id,
        root_run_id=updated.root_run_id,
        trigger_reason=trigger_reason,
        source_thread_id=source_thread_id,
        input_snapshot=input_snapshot,
        result=result,
        created_child_thread_id=created_child_thread_id,
        created_at=created_at,
    )
    write_json_atomic(
        watchdog_activation_dir(repo_root) / f"{activation.activation_id}.json",
        activation.model_dump(mode="json"),
    )
    return activation


def list_root_watchdog_activations(repo_root: Path) -> tuple[WatchdogActivation, ...]:
    directory = watchdog_activation_dir(repo_root)
    if not directory.exists():
        return ()
    activations = [
        WatchdogActivation.model_validate_json(path.read_text(encoding="utf-8"))
        for path in sorted(directory.glob("*.json"))
    ]
    return tuple(sorted(activations, key=lambda activation: activation.created_at))


def latest_root_watchdog_activation(repo_root: Path) -> WatchdogActivation | None:
    activations = list_root_watchdog_activations(repo_root)
    if not activations:
        return None
    return activations[-1]


__all__ = [
    "WatchdogActivation",
    "WatchdogActivationPolicy",
    "WatchdogAction",
    "WatchdogDecision",
    "WatchdogDefinition",
    "WatchdogInputSnapshot",
    "WatchdogResolution",
    "WATCHDOG_DECISION_BEGIN",
    "WATCHDOG_DECISION_END",
    "build_watchdog_decision_prompt",
    "can_activate_root_watchdog",
    "can_activate_root_watchdog_for_frontier",
    "clear_root_watchdog",
    "ensure_root_watchdog",
    "frontier_allows_watchdog_activation",
    "latest_root_watchdog_activation",
    "list_root_watchdog_activations",
    "load_root_watchdog",
    "parse_watchdog_decision",
    "record_root_watchdog_activation",
    "watchdog_activation_dir",
    "write_root_watchdog",
    "watchdog_path",
]
