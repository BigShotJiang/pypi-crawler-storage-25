"""Workspace-local trust persistence for the human Codex-style shell."""

from __future__ import annotations

from pathlib import Path
from typing import cast
from typing import Literal

from ralphception.paths import APP_NAME, resolve_xdg_state_home, workspace_hash, workspace_state_dir

ProjectTrust = Literal["trusted", "untrusted"]
_TRUST_FILE_NAME = "project-trust.txt"


def project_trust_path(repo_root: Path, *, xdg_state_home: Path | None = None) -> Path:
    return _project_trust_state_dir(repo_root, xdg_state_home=xdg_state_home) / _TRUST_FILE_NAME


def load_project_trust(repo_root: Path, *, xdg_state_home: Path | None = None) -> ProjectTrust | None:
    trust_path = project_trust_path(repo_root, xdg_state_home=xdg_state_home)
    try:
        value = trust_path.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if value in {"trusted", "untrusted"}:
        return cast(ProjectTrust, value)
    return None


def save_project_trust(
    repo_root: Path,
    trust_level: ProjectTrust,
    *,
    xdg_state_home: Path | None = None,
) -> None:
    trust_path = project_trust_path(repo_root, xdg_state_home=xdg_state_home)
    trust_path.parent.mkdir(parents=True, exist_ok=True)
    trust_path.write_text(f"{trust_level}\n", encoding="utf-8")


def _project_trust_state_dir(repo_root: Path, *, xdg_state_home: Path | None = None) -> Path:
    try:
        return workspace_state_dir(repo_root, xdg_state_home=xdg_state_home)
    except RuntimeError:
        fallback_root = repo_root.resolve(strict=False)
        return resolve_xdg_state_home(xdg_state_home=xdg_state_home) / APP_NAME / workspace_hash(
            fallback_root,
        )
