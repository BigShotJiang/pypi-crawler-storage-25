"""Durable prompt state records persisted in the interactive-session file."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import Field, model_validator

from ralphception.models.artifacts import DurableModel

STARTUP_INTAKE_ANSWERS_KEY = "intake_answers"


class BlockedContinuationRef(DurableModel):
    """Reference to the blocked run/thread pair behind a prompt."""

    thread_id: str
    run_id: str


class PendingPrompt(DurableModel):
    """A prompt waiting on the user before a continuation can resume."""

    thread_id: str
    owner_run_id: str
    prompt_id: str
    prompt_kind: str
    title: str
    question: str
    allowed_actions: tuple[str, ...]
    context: dict[str, Any] = Field(default_factory=dict)
    blocked_continuation: BlockedContinuationRef | None = None


class PromptResolution(DurableModel):
    """A persisted resolution for a completed prompt."""

    thread_id: str
    owner_run_id: str
    prompt_id: str
    action: str
    raw_user_reply: str
    confidence: float


class DeferredInput(DurableModel):
    """A deferred user reply that still needs to be replayed later."""

    thread_id: str
    text: str
    created_at: datetime | None = None


class TaskMessageClassification(DurableModel):
    """A persisted active-session message classification."""

    thread_id: str | None = None
    raw_user_text: str | None = None
    text: str | None = None
    kind: str
    prompt_pending: bool = False
    active_task_summary: str | None = None
    confidence: float | None = None
    clarifying_question: str | None = None
    created_at: datetime | None = None

    @model_validator(mode="after")
    def _sync_text_fields(self) -> "TaskMessageClassification":
        if self.text is None and self.raw_user_text is not None:
            self.text = self.raw_user_text
        if self.raw_user_text is None and self.text is not None:
            self.raw_user_text = self.text
        return self


MessageClassification = TaskMessageClassification


class InteractiveSessionState(DurableModel):
    """Workspace-level prompt state persisted alongside the interactive marker."""

    root_thread_id: str = ""
    active_thread_id: str | None = None
    active_task_id: str | None = None
    active_task_summary: str | None = None
    session_id: str | None = None
    plan_id: str | None = None
    loop_graph_id: str | None = None
    active_plan_node_id: str | None = None
    pending_prompts: list[PendingPrompt] = Field(default_factory=list)
    prompt_resolutions: list[PromptResolution] = Field(default_factory=list)
    deferred_inputs: list[DeferredInput] = Field(default_factory=list)
    message_classifications: list[TaskMessageClassification] = Field(default_factory=list)
    task_message_classifications: list[TaskMessageClassification] = Field(default_factory=list)
    bootstrap_source_repos: list[str] = Field(default_factory=list)
    updated_at: datetime | None = None

    @model_validator(mode="after")
    def _sync_classification_lists(self) -> "InteractiveSessionState":
        if self.task_message_classifications and not self.message_classifications:
            self.message_classifications = list(self.task_message_classifications)
        elif self.message_classifications and not self.task_message_classifications:
            self.task_message_classifications = list(self.message_classifications)
        elif self.message_classifications != self.task_message_classifications:
            self.task_message_classifications = list(self.message_classifications)
        return self


__all__ = [
    "BlockedContinuationRef",
    "DeferredInput",
    "InteractiveSessionState",
    "MessageClassification",
    "TaskMessageClassification",
    "PendingPrompt",
    "PromptResolution",
    "STARTUP_INTAKE_ANSWERS_KEY",
]
