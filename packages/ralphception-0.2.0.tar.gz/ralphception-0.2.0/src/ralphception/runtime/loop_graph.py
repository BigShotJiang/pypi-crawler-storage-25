"""Durable loop graph models and merge safety helpers."""

from __future__ import annotations

from collections import defaultdict

from ralphception.models.artifacts import DurableModel
from ralphception.runtime.loop_planner import LoopDefinition, MergeStrategy


class LoopGraph(DurableModel):
    """Durable loop graph for a task."""

    loop_graph_id: str | None = None
    loops: tuple[LoopDefinition, ...]

    @classmethod
    def from_definitions(
        cls,
        definitions: list[LoopDefinition] | tuple[LoopDefinition, ...],
        *,
        loop_graph_id: str | None = None,
    ) -> "LoopGraph":
        return cls(loop_graph_id=loop_graph_id, loops=tuple(definitions))

    @classmethod
    def from_nested_definitions(
        cls,
        definitions: list[LoopDefinition] | tuple[LoopDefinition, ...],
        *,
        loop_graph_id: str | None = None,
    ) -> "LoopGraph":
        return cls.from_definitions(definitions, loop_graph_id=loop_graph_id)

    def requires_proposal_merge(self, artifact_kind: str) -> bool:
        matching_loops = [loop for loop in self.loops if artifact_kind in loop.target_artifacts]
        if len(matching_loops) > 1:
            return True
        return False

    def merge_strategy_for(self, artifact_kind: str) -> MergeStrategy:
        if self.requires_proposal_merge(artifact_kind):
            return "proposal_first"
        for loop in self.loops:
            if artifact_kind in loop.target_artifacts:
                return loop.merge_strategy
        return "direct_update"

    def loops_for_artifact(self, artifact_kind: str) -> tuple[LoopDefinition, ...]:
        return tuple(loop for loop in self.loops if artifact_kind in loop.target_artifacts)

    def child_loops_for(self, parent_loop_id: str | None) -> tuple[LoopDefinition, ...]:
        return tuple(loop for loop in self.loops if loop.parent_loop_id == parent_loop_id)

    def children_for(self, parent_loop_id: str | None) -> tuple[LoopDefinition, ...]:
        return self.child_loops_for(parent_loop_id)

    def loop(self, loop_id: str) -> LoopDefinition:
        for loop in self.loops:
            if loop.loop_id == loop_id:
                return loop
        raise KeyError(loop_id)

    def blocked_plan_node_ids_for_failure(self, loop_id: str) -> tuple[str, ...]:
        return (self.loop(loop_id).plan_node_id,)

    def target_artifact_owners(self) -> dict[str, tuple[str, ...]]:
        owners: dict[str, list[str]] = defaultdict(list)
        for loop in self.loops:
            for artifact_kind in loop.target_artifacts:
                owners[artifact_kind].append(loop.loop_id)
        return {artifact_kind: tuple(loop_ids) for artifact_kind, loop_ids in owners.items()}


__all__ = [
    "LoopDefinition",
    "LoopGraph",
]
