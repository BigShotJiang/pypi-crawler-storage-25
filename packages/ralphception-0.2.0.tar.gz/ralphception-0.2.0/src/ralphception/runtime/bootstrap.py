"""First-run bootstrap capture and intake helpers."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel

from ralphception.models.artifacts import ArtifactRef
from ralphception.runtime.artifact_pipeline import ArtifactPipeline
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic, write_markdown_atomic

_ROOT_RUN_ID = "run-root"
_INITIAL_STARTUP_QUESTION = "Describe what you want Ralphception to work on in this workspace."
_FIRST_FOLLOW_UP_STARTUP_QUESTION = (
    "What outcome or definition of done should I use for the first execution slice?"
)
_SECOND_FOLLOW_UP_STARTUP_QUESTION = (
    "Are there any hard constraints, no-go areas, or review expectations I should treat as boundaries?"
)
_MORE_CONTEXT_STARTUP_QUESTION = (
    "I still need more context before I can write the intake artifacts. "
    "What hard constraints, no-go areas, or review expectations should I use?"
)
_TYPO_SCOPE_STARTUP_QUESTION = (
    "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
)
_TYPO_CONSTRAINTS_STARTUP_QUESTION = (
    "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
)
_TYPO_SCOPE_MORE_CONTEXT_STARTUP_QUESTION = (
    "I still need more context for this typo pass. "
    "Are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
)
_LOW_INFORMATION_ANSWERS = {
    "continue",
    "do it",
    "fine",
    "go",
    "good",
    "ok",
    "okay",
    "please",
    "proceed",
    "sure",
    "works",
    "yes",
}
_INTAKE_STOPWORDS = {
    "a",
    "an",
    "and",
    "for",
    "in",
    "it",
    "of",
    "on",
    "the",
    "to",
    "with",
}
_TYPO_SCOPE_TOKENS = {
    "comment",
    "comments",
    "doc",
    "docs",
    "documentation",
    "markdown",
    "readme",
    "spelling",
    "typo",
    "typos",
}


@dataclass(frozen=True, slots=True)
class IntakeAssessment:
    """Assessment of whether startup intake has enough detail to bootstrap artifacts."""

    normalized_answers: tuple[str, ...]
    is_sufficient: bool
    next_question: str


class StartupRecord(BaseModel):
    """Persisted first-run bootstrap state."""

    outer_run_id: str
    root_thread_id: str = "thread-root"
    seed_prompt: str
    source_repos: list[str]
    intake_artifact: ArtifactRef
    created_at: datetime


def startup_record_path(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> Path:
    """Return the durable startup record path for the root run."""
    repo_root = bootstrap_workspace(repo_root)
    return repo_root / ".ralphception" / "runs" / run_id / "startup.json"


def intake_artifact_path(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> Path:
    """Return the durable intake artifact path for the root run."""
    repo_root = bootstrap_workspace(repo_root)
    return repo_root / ".ralphception" / "runs" / run_id / "intake.md"


def load_startup_record(repo_root: Path, *, run_id: str = _ROOT_RUN_ID) -> StartupRecord | None:
    """Load the persisted first-run bootstrap state if present."""
    path = startup_record_path(repo_root, run_id=run_id)
    if not path.exists():
        return None
    return StartupRecord.model_validate_json(path.read_text(encoding="utf-8"))


class StartupBootstrapController:
    """Capture first-run inputs into the durable workspace state."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = bootstrap_workspace(repo_root)

    def needs_bootstrap(self) -> bool:
        """Return whether the current workspace still needs first-run capture."""
        return load_startup_record(self.repo_root) is None

    def start_first_run(
        self,
        *,
        seed_prompt: str,
        source_repos: Sequence[Path | str],
    ) -> StartupRecord:
        """Persist the initial seed prompt and source repositories."""
        normalized_seed_prompt = seed_prompt.strip()
        if not normalized_seed_prompt:
            raise ValueError("seed_prompt must not be blank")

        normalized_source_repos = [
            str(Path(repo_path).expanduser())
            for repo_path in source_repos
        ]
        from ralphception.runtime.frontier import clear_task_frontier
        from ralphception.runtime.watchdog import clear_root_watchdog

        clear_task_frontier(self.repo_root)
        clear_root_watchdog(self.repo_root)
        created_at = datetime.now(timezone.utc)
        intake_markdown = _render_intake_markdown(
            seed_prompt=normalized_seed_prompt,
            source_repos=normalized_source_repos,
        )
        intake_path = intake_artifact_path(self.repo_root)
        write_markdown_atomic(intake_path, intake_markdown)
        record = StartupRecord(
            outer_run_id=_ROOT_RUN_ID,
            root_thread_id="thread-root",
            seed_prompt=normalized_seed_prompt,
            source_repos=normalized_source_repos,
            intake_artifact=_artifact_ref_for_text(
                artifact_kind="intake",
                artifact_path=str(intake_path.relative_to(self.repo_root)),
                artifact_version=1,
                content=intake_markdown,
            ),
            created_at=created_at,
        )
        write_json_atomic(startup_record_path(self.repo_root), record.model_dump(mode="json"))
        from ralphception.runtime.interactive_session import write_interactive_session_state
        from ralphception.runtime.prompt_state import InteractiveSessionState

        write_interactive_session_state(
            self.repo_root,
            InteractiveSessionState(
                root_thread_id=_ROOT_RUN_ID,
                active_thread_id=_ROOT_RUN_ID,
                pending_prompts=[],
                prompt_resolutions=[],
                deferred_inputs=[],
                bootstrap_source_repos=[],
            ),
        )
        EventStore(self.repo_root).append(
            event_id=f"run-created-{record.outer_run_id}",
            run_id=record.outer_run_id,
            event_type="run.created",
            source="ui.startup",
            payload={
                "goal": record.seed_prompt,
                "parent_run_id": None,
            },
            occurred_at=record.created_at,
        )
        return record

    def summary_text(self) -> str:
        """Return the current startup summary."""
        record = load_startup_record(self.repo_root)
        if record is None:
            return (
                "First-run bootstrap\n\n"
                "Seed prompt: pending\n"
                "Source repos: pending\n"
                "Next step: capture the root prompt and any source repositories."
            )
        source_lines = "\n".join(f"- {repo_path}" for repo_path in record.source_repos) or "- none"
        return (
            "First-run bootstrap complete\n\n"
            f"Run: {record.outer_run_id}\n"
            f"Seed prompt: {record.seed_prompt}\n"
            "Source repos:\n"
            f"{source_lines}"
        )


def _render_intake_markdown(*, seed_prompt: str, source_repos: Sequence[str]) -> str:
    source_lines = "\n".join(f"- {repo_path}" for repo_path in source_repos) or "- none"
    return (
        "# Intake\n\n"
        f"Seed prompt: {seed_prompt}\n\n"
        "Source repositories:\n"
        f"{source_lines}\n"
    )


def compose_intake_summary(*answers: str) -> str:
    """Combine one or more intake replies into a durable task summary."""
    normalized_answers = [answer.strip() for answer in answers if answer.strip()]
    if not normalized_answers:
        raise ValueError("at least one intake answer is required")
    primary_answer, *additional_answers = normalized_answers
    if not additional_answers:
        return primary_answer
    details = "\n".join(f"- {answer}" for answer in additional_answers)
    return (
        primary_answer
        + "\n\nAdditional context:\n"
        + details
    )


def primary_intake_goal(intake_summary: str) -> str:
    """Extract the concise leading task statement from an intake summary."""
    summary = intake_summary.strip()
    if not summary:
        raise ValueError("intake_summary must not be blank")
    return summary.split("\n\nAdditional context:\n", 1)[0].strip()


def assess_intake_answers(*answers: str) -> IntakeAssessment:
    """Return whether startup intake has enough structure to write durable artifacts."""
    normalized_answers = tuple(answer.strip() for answer in answers if answer.strip())
    if not normalized_answers:
        return IntakeAssessment(
            normalized_answers=(),
            is_sufficient=False,
            next_question=_INITIAL_STARTUP_QUESTION,
        )
    task_family = _classify_intake_task_family(*normalized_answers)
    if len(normalized_answers) == 1:
        return IntakeAssessment(
            normalized_answers=normalized_answers,
            is_sufficient=False,
            next_question=_follow_up_question_for_task_family(task_family, answer_count=len(normalized_answers)),
        )
    if len(normalized_answers) == 2:
        return IntakeAssessment(
            normalized_answers=normalized_answers,
            is_sufficient=False,
            next_question=_follow_up_question_for_task_family(task_family, answer_count=len(normalized_answers)),
        )
    latest_answer = normalized_answers[-1]
    meaningful_tokens = _meaningful_tokens(" ".join(normalized_answers))
    if _is_low_information_answer(latest_answer) or len(meaningful_tokens) < 6:
        return IntakeAssessment(
            normalized_answers=normalized_answers,
            is_sufficient=False,
            next_question=_more_context_question_for_task_family(task_family),
        )
    return IntakeAssessment(
        normalized_answers=normalized_answers,
        is_sufficient=True,
        next_question=_follow_up_question_for_task_family(
            task_family,
            answer_count=len(normalized_answers),
        ),
    )


def bootstrap_from_intake(
    repo_root: Path,
    *,
    task_id: str,
    intake_summary: str,
    source_repos: Sequence[Path | str],
) -> StartupRecord:
    """Write authoritative intake artifacts and persist the startup record."""
    ArtifactPipeline.for_workspace(repo_root).initialize_from_intake(
        task_id=task_id,
        intake_summary=intake_summary,
    )
    return StartupBootstrapController(repo_root).start_first_run(
        seed_prompt=intake_summary,
        source_repos=source_repos,
    )


def _artifact_ref_for_text(
    *,
    artifact_kind: str,
    artifact_path: str,
    artifact_version: int,
    content: str,
) -> ArtifactRef:
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=artifact_version,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def _is_low_information_answer(text: str) -> bool:
    normalized = " ".join(text.strip().lower().split())
    if not normalized:
        return True
    return normalized in _LOW_INFORMATION_ANSWERS


def _meaningful_tokens(text: str) -> set[str]:
    tokens = {token for token in re.findall(r"[a-z0-9]+", text.lower()) if token}
    return tokens - _INTAKE_STOPWORDS


def _classify_intake_task_family(*answers: str) -> str:
    meaningful_tokens = _meaningful_tokens(" ".join(answers))
    if meaningful_tokens & _TYPO_SCOPE_TOKENS:
        return "typo_scope"
    return "generic"


def _follow_up_question_for_task_family(task_family: str, *, answer_count: int) -> str:
    if task_family == "typo_scope":
        if answer_count <= 1:
            return _TYPO_SCOPE_STARTUP_QUESTION
        return _TYPO_CONSTRAINTS_STARTUP_QUESTION
    if answer_count <= 1:
        return _FIRST_FOLLOW_UP_STARTUP_QUESTION
    return _SECOND_FOLLOW_UP_STARTUP_QUESTION


def _more_context_question_for_task_family(task_family: str) -> str:
    if task_family == "typo_scope":
        return _TYPO_SCOPE_MORE_CONTEXT_STARTUP_QUESTION
    return _MORE_CONTEXT_STARTUP_QUESTION


def _parse_source_repos(raw_text: str) -> list[str]:
    normalized_paths: list[str] = []
    for line in raw_text.replace(",", "\n").splitlines():
        candidate = line.strip()
        if candidate:
            normalized_paths.append(candidate)
    return normalized_paths


__all__ = [
    "IntakeAssessment",
    "assess_intake_answers",
    "bootstrap_from_intake",
    "primary_intake_goal",
    "StartupBootstrapController",
    "StartupRecord",
    "compose_intake_summary",
    "intake_artifact_path",
    "load_startup_record",
    "startup_record_path",
]
