"""Codex-style human terminal frontend with committed scrollback and live viewport."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
import os
from pathlib import Path
import sys
import textwrap
from typing import Any, Literal, Protocol

try:
    import termios
    import tty
except ImportError:  # pragma: no cover - unix-only in practice here
    termios = None  # type: ignore[assignment]
    tty = None  # type: ignore[assignment]

from ralphception.codex.config import load_codex_runtime_settings
from ralphception.config import RalphceptionConfig
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.interactive_session import resolve_interactive_launch_state
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BlockerPromptEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    CurrentBlockerStateEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FailureSummaryEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    RequestUserInputRequestedEvent,
    RuntimeStep,
)
from ralphception.runtime.inline_shell import (
    InlineShellRunResult,
    _compact_command_for_scrollback,
    _humanize_stage_message,
    _resolve_inline_shell_session_manager_factory,
)
from ralphception.runtime.supervisor import RuntimeLaunchAbortedError, RuntimeSupervisor
from ralphception.tui.path_labels import center_truncate, normalize_directory_label
from ralphception.version import resolve_cli_version

_INITIAL_STARTUP_QUESTION = "Describe what you want Ralphception to work on in this workspace."
_VIEWPORT_MIN_HEIGHT = 9
_LIVE_PROMPT_PREFIX = "› "
_BLOCKER_STATUS = "Waiting for your response"


class TerminalSurface(Protocol):
    def render(self, lines: Sequence[str]) -> None: ...

    def commit(self, lines: Sequence[str]) -> None: ...

    def read_input(self, prompt_prefix: str) -> str: ...

    def close(self) -> None: ...


@dataclass(slots=True)
class RecordingTerminalSurface:
    """Deterministic surface for tests."""

    width: int = 72
    height: int = 18
    history_lines: list[str] = field(default_factory=list)
    view_lines: tuple[str, ...] = ()

    def render(self, lines: Sequence[str]) -> None:
        self.view_lines = tuple(lines)

    def commit(self, lines: Sequence[str]) -> None:
        self.history_lines.extend(lines)

    def read_input(self, prompt_prefix: str) -> str:
        raise RuntimeError(f"RecordingTerminalSurface cannot read input for prompt {prompt_prefix!r}")

    def close(self) -> None:
        return


@dataclass(slots=True)
class AnsiTerminalSurface:
    """Inline terminal viewport that keeps committed history in normal scrollback."""

    stdout: object = sys.stdout
    stdin: object = sys.stdin
    min_height: int = _VIEWPORT_MIN_HEIGHT
    _width: int = 80
    _height: int = 24
    _viewport_top: int = 1
    _rendered_lines: tuple[str, ...] = ()
    _stdin_fd: int | None = None
    _stdout_fd: int | None = None
    _original_termios: Any = None

    def __post_init__(self) -> None:
        self._stdout_fd = getattr(self.stdout, "fileno", lambda: 1)()
        self._stdin_fd = getattr(self.stdin, "fileno", lambda: 0)()
        self._update_terminal_size()
        self._enter_raw_mode()

    def render(self, lines: Sequence[str]) -> None:
        self._update_terminal_size()
        viewport_height = max(self.min_height, len(lines))
        viewport_height = min(viewport_height, self._height)
        self._viewport_top = max(1, self._height - viewport_height + 1)
        clear_height = max(len(self._rendered_lines), viewport_height)
        handle = self._stdout_handle()
        for index in range(clear_height):
            row = self._viewport_top + index
            if row > self._height:
                break
            handle.write(f"\x1b[{row};1H\x1b[2K")
        for index, line in enumerate(lines):
            row = self._viewport_top + index
            if row > self._height:
                break
            handle.write(f"\x1b[{row};1H{_trim_to_width(str(line), self._width)}")
        handle.flush()
        self._rendered_lines = tuple(lines)

    def commit(self, lines: Sequence[str]) -> None:
        if not lines:
            return
        self._update_terminal_size()
        handle = self._stdout_handle()
        history_bottom = max(1, self._viewport_top - 1)
        cursor_row = self._viewport_top + max(0, len(self._rendered_lines) - 1)
        if history_bottom < 1:
            return
        wrapped_lines = _wrap_history_lines(lines, width=self._width)
        handle.write(f"\x1b[1;{history_bottom}r")
        handle.write(f"\x1b[{history_bottom};1H")
        for line in wrapped_lines:
            handle.write("\r\n")
            handle.write("\x1b[2K")
            handle.write(_trim_to_width(line, self._width))
        handle.write("\x1b[r")
        if self._rendered_lines:
            handle.write(f"\x1b[{cursor_row};1H")
        handle.flush()

    def read_input(self, prompt_prefix: str) -> str:
        self._update_terminal_size()
        buffer = ""
        self._render_input_buffer(prompt_prefix, buffer)
        fd = self._stdin_handle()
        while True:
            raw = os.read(fd, 1)
            if not raw:
                return buffer
            if raw in {b"\r", b"\n"}:
                break
            if raw == b"\x03":
                raise KeyboardInterrupt
            if raw in {b"\x08", b"\x7f"}:
                buffer = buffer[:-1]
                self._render_input_buffer(prompt_prefix, buffer)
                continue
            if raw == b"\x1b":
                self._drain_escape_sequence(fd)
                continue
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                continue
            if not text.isprintable():
                continue
            buffer += text
            self._render_input_buffer(prompt_prefix, buffer)
        return buffer

    def close(self) -> None:
        handle = self._stdout_handle()
        handle.write("\x1b[r")
        handle.flush()
        self._restore_raw_mode()

    def _update_terminal_size(self) -> None:
        size = os.get_terminal_size(self._stdout_fd or 1)
        self._width = size.columns
        self._height = size.lines

    def _stdout_handle(self):
        return self.stdout

    def _stdin_handle(self):
        return self._stdin_fd or 0

    @property
    def width(self) -> int:
        return self._width

    def _render_input_buffer(self, prompt_prefix: str, buffer: str) -> None:
        prompt_row = self._viewport_top + len(self._rendered_lines) - 1
        available = max(0, self._width - len(prompt_prefix))
        display = buffer[-available:] if available else ""
        handle = self._stdout_handle()
        handle.write(f"\x1b[{prompt_row};1H\x1b[2K{prompt_prefix}{display}")
        handle.flush()

    def _enter_raw_mode(self) -> None:
        if termios is None or tty is None or self._stdin_fd is None:
            return
        self._original_termios = termios.tcgetattr(self._stdin_fd)
        tty.setraw(self._stdin_fd)

    def _restore_raw_mode(self) -> None:
        if termios is None or self._stdin_fd is None or self._original_termios is None:
            return
        termios.tcsetattr(self._stdin_fd, termios.TCSADRAIN, self._original_termios)
        self._original_termios = None

    def _drain_escape_sequence(self, fd: int) -> None:
        if termios is None:
            return
        original = termios.tcgetattr(fd)
        try:
            attrs = termios.tcgetattr(fd)
            attrs[3] &= ~termios.ICANON
            attrs[3] &= ~termios.ECHO
            attrs[6][termios.VMIN] = 0
            attrs[6][termios.VTIME] = 0
            termios.tcsetattr(fd, termios.TCSANOW, attrs)
            while os.read(fd, 1):
                continue
        except OSError:
            return
        finally:
            termios.tcsetattr(fd, termios.TCSANOW, original)


@dataclass(slots=True)
class CodexTerminalFrontend:
    """Human terminal frontend modeled after Codex's inline viewport behavior."""

    repo_root: Path
    input_callback: Callable[[str], str] | None = None
    surface: TerminalSurface | None = None
    default_session_manager_factory: object | None = None
    _output_lines: list[str] = field(default_factory=list)
    events: list[FrontendEvent] = field(default_factory=list)
    live_status: str | None = None
    current_task_label: str | None = None
    current_plan_node_label: str | None = None
    current_loop_label: str | None = None
    current_blocker_state: str | None = None
    current_waiting_state: str | None = None
    input_func: Callable[[str], str] = field(init=False)
    _assistant_deltas: dict[str, str] = field(default_factory=dict)
    _reasoning_deltas: dict[str, str] = field(default_factory=dict)
    _input_prompt_active: bool = False
    _input_prompt_label: str = _LIVE_PROMPT_PREFIX
    _startup_prompt_visible: bool = False

    def __post_init__(self) -> None:
        if self.surface is None:
            if getattr(sys.stdout, "isatty", lambda: False)():
                self.surface = AnsiTerminalSurface()
            else:
                self.surface = RecordingTerminalSurface()
        self.input_func = self._read_input
        self.render_view()

    def emit_event(self, event: FrontendEvent) -> None:
        self.events.append(event)
        if isinstance(event, LiveStatusEvent):
            self.live_status = event.text
            self.render_view()
            return
        if isinstance(event, CommandBeginEvent):
            self._commit_history(f"Command started: {_compact_command_for_scrollback(event.command)}")
            return
        if isinstance(event, CommandEndEvent):
            command = _compact_command_for_scrollback(event.command)
            if event.exit_code is not None:
                self._commit_history(f"Command completed (exit {event.exit_code}): {command}")
            elif event.status is not None and event.status != "completed":
                self._commit_history(f"Command {event.status}: {command}")
            else:
                self._commit_history(f"Command completed: {command}")
            return
        if isinstance(event, AssistantDeltaEvent):
            self._assistant_deltas[event.item_id] = event.text
            self.live_status = event.text
            self.render_view()
            return
        if isinstance(event, AssistantFinalEvent):
            if event.item_id is not None:
                self._assistant_deltas.pop(event.item_id, None)
            self.live_status = None
            self._commit_history(event.message)
            self.render_view()
            return
        if isinstance(event, ReasoningSummaryDeltaEvent):
            self._reasoning_deltas[event.item_id] = event.text
            if not self.live_status:
                self.live_status = event.text
            self.render_view()
            return
        if isinstance(event, ReasoningSectionBreakEvent):
            return
        if isinstance(event, ReasoningFinalEvent):
            if event.item_id is not None:
                self._reasoning_deltas.pop(event.item_id, None)
            if self.live_status == (event.text or self.live_status):
                self.live_status = None
            self.render_view()
            return
        if isinstance(event, CurrentTaskLabelEvent):
            self.current_task_label = None if event.cleared else event.label
            self.render_view()
            return
        if isinstance(event, CurrentPlanNodeLabelEvent):
            self.current_plan_node_label = None if event.cleared else event.label
            self.render_view()
            return
        if isinstance(event, CurrentLoopLabelEvent):
            self.current_loop_label = None if event.cleared else event.label
            self.render_view()
            return
        if isinstance(event, CurrentBlockerStateEvent):
            if event.cleared:
                self.current_blocker_state = None
            elif event.label is not None and _is_initial_startup_question(event.label):
                self.current_blocker_state = None
                self._startup_prompt_visible = True
            else:
                self.current_blocker_state = _BLOCKER_STATUS
            self.render_view()
            return
        if isinstance(event, CurrentWaitingStateEvent):
            self.current_waiting_state = None if event.cleared else event.label
            self.render_view()
            return
        if isinstance(event, RequestUserInputRequestedEvent):
            if self.input_callback is not None:
                self._output_lines.append(f"Input requested: {event.title}")
            self.render_view()
            return
        if isinstance(event, BlockerPromptEvent):
            if not _is_initial_startup_question(event.question):
                self._commit_history(event.question)
                self.current_blocker_state = _BLOCKER_STATUS
            else:
                self._startup_prompt_visible = True
                self.render_view()
            return
        if isinstance(event, CommandOutputDeltaEvent):
            self._commit_history(event.text)
            return
        if event.kind == "stage.started":
            self._commit_history(_humanize_stage_message(event.stage_kind))
            return
        if event.kind in {"turn.started", "turn.completed"}:
            return
        if event.message.startswith("Child run created: "):
            return
        if isinstance(event, (LoopLaunchEvent, LoopCompletionEvent)):
            self.current_loop_label = event.loop_label
        if isinstance(event, (LoopCompletionEvent, FailureSummaryEvent)):
            self.current_waiting_state = None
        self._commit_history(event.message)

    def emit_status(self, step: RuntimeStep) -> None:
        self.live_status = f"Runtime: {step.kind}"
        self.render_view()

    def finish(self, step: RuntimeStep) -> None:
        self.live_status = None
        self._commit_history(f"Runtime: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self._output_lines)

    def run(
        self,
        *,
        repo_root: Path | None = None,
        seed_prompt: str | None = None,
        source_repos: tuple[str, ...] = (),
        resume: bool = False,
        approve_all: bool = False,
        approver: str = "terminal",
        use_fake_session_manager: bool = False,
        session_manager_factory=None,
    ) -> InlineShellRunResult:
        return run_codex_terminal_shell(
            repo_root=self.repo_root if repo_root is None else repo_root,
            seed_prompt=seed_prompt,
            source_repos=source_repos,
            resume=resume,
            approve_all=approve_all,
            approver=approver,
            use_fake_session_manager=use_fake_session_manager,
            session_manager_factory=(
                self.default_session_manager_factory
                if session_manager_factory is None
                else session_manager_factory
            ),
            frontend=self,
        )

    def close(self) -> None:
        if self.surface is not None:
            self.surface.close()

    def render_view(self) -> None:
        if self.surface is None:
            return
        self.surface.render(self._view_lines())

    def _commit_history(self, line: str) -> None:
        self._output_lines.append(line)
        if self.surface is not None:
            self.surface.commit([line])

    def _read_input(self, prompt: str) -> str:
        if self.input_callback is not None:
            self._output_lines.append(prompt)
            return self.input_callback(prompt)
        self._input_prompt_active = True
        self._input_prompt_label = _LIVE_PROMPT_PREFIX
        self.render_view()
        assert self.surface is not None
        reply = self.surface.read_input(self._input_prompt_label)
        committed = f"{self._input_prompt_label}{reply}".rstrip()
        if committed:
            self._output_lines.append(committed)
            self.surface.commit([committed])
        self._input_prompt_active = False
        self.render_view()
        return reply

    def _view_lines(self) -> list[str]:
        header_lines = _render_header_card(
            repo_root=self.repo_root,
            width=getattr(self.surface, "width", 72),
        )
        lines = ["", *header_lines, ""]
        status_line = self._status_line()
        if status_line:
            lines.append(status_line)
        else:
            lines.append("")
        lines.append("")
        lines.append(self._input_prompt_label if self._input_prompt_active else self._footer_line())
        return lines

    def _status_line(self) -> str | None:
        return (
            self.current_blocker_state
            or self.current_waiting_state
            or self.live_status
            or self.current_loop_label
            or self.current_plan_node_label
            or self.current_task_label
        )

    def _footer_line(self) -> str:
        settings = load_codex_runtime_settings()
        directory = normalize_directory_label(str(self.repo_root))
        return f"  {settings.model} {settings.reasoning_effort} {settings.service_tier} · {directory}"


@dataclass(slots=True)
class ScriptedCodexTerminalFrontend(CodexTerminalFrontend):
    scripted_inputs: list[str] = field(default_factory=list)

    def __init__(self, *, repo_root: Path, inputs: Sequence[str] = (), surface: TerminalSurface | None = None) -> None:
        self.scripted_inputs = list(inputs)
        super().__init__(
            repo_root=repo_root,
            input_callback=self._consume_input,
            surface=surface or RecordingTerminalSurface(),
        )

    def _consume_input(self, prompt: str) -> str:
        if not self.scripted_inputs:
            raise RuntimeError(f"no scripted input available for prompt {prompt!r}")
        return self.scripted_inputs.pop(0)


def run_codex_terminal_shell(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "terminal",
    use_fake_session_manager: bool = False,
    session_manager_factory=None,
    frontend: CodexTerminalFrontend | None = None,
) -> InlineShellRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    resolved_session_manager_factory = _resolve_inline_shell_session_manager_factory(
        session_manager_factory=session_manager_factory,
        use_fake_session_manager=use_fake_session_manager,
    )
    resolved_frontend = frontend or CodexTerminalFrontend(repo_root=resolved_repo_root)
    supervisor = RuntimeSupervisor(
        repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=resolved_session_manager_factory,
    )
    if resume:
        supervisor.request_resume_launch()
    else:
        launch_state = resolve_interactive_launch_state(resolved_repo_root)
        if launch_state.kind in {"resumable", "broken_resume"}:
            while True:
                first_prompt = resolved_frontend.input_func("You: ").strip()
                if not first_prompt:
                    continue
                supervisor.request_start_fresh_launch(source_repos=source_repos)
                supervisor.resolve_startup_input(
                    user_text=first_prompt,
                    source_repos=source_repos,
                )
                break
    if not resume and seed_prompt is not None and seed_prompt.strip():
        launch_state = resolve_interactive_launch_state(resolved_repo_root)
        if launch_state.kind in {"resumable", "broken_resume"}:
            supervisor.request_start_fresh_launch(source_repos=source_repos)
            supervisor.resolve_startup_input(
                user_text=seed_prompt.strip(),
                source_repos=source_repos,
            )
    try:
        while True:
            result = supervisor.run(frontend=resolved_frontend)
            if result.mode in {"completed", "failed"}:
                break
            prompt = supervisor.current_pending_prompt()
            if prompt is None:
                break
            reply = resolved_frontend.input_func(
                "You: " if prompt.prompt_kind == "startup_prompt" else "Reply: "
            ).strip()
            if prompt.prompt_kind == "launch_conflict" and reply.lower() in {"start", "new"}:
                reply = "override"
            if prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"} and reply.lower() in {
                "pause",
                "/pause",
            }:
                startup_record = load_startup_record(supervisor.repo_root)
                resolved_frontend.emit_status(RuntimeStep(kind="review_prompt"))
                return InlineShellRunResult(
                    mode="running",
                    root_run_id=None if startup_record is None else startup_record.outer_run_id,
                    authoritative_repo_root=str(supervisor.repo_root),
                    log_text=resolved_frontend.output_text(),
                )
            resolution = supervisor.resolve_pending_prompt(thread_id=prompt.thread_id, user_text=reply)
            if resolution.kind != "resolved":
                continue
            resolved_frontend.emit_event(CurrentBlockerStateEvent.clear())
            if resolution.action == "abort" and prompt.prompt_kind in {"resume_session", "launch_conflict"}:
                raise RuntimeLaunchAbortedError("Launch aborted.")
        resolved_frontend.finish(RuntimeStep(kind=result.mode))
        return InlineShellRunResult(
            mode="completed" if result.mode == "completed" else ("failed" if result.mode == "failed" else "running"),
            root_run_id=result.root_run_id,
            authoritative_repo_root=result.authoritative_repo_root,
            log_text=resolved_frontend.output_text(),
        )
    finally:
        resolved_frontend.close()


def _is_initial_startup_question(question: str) -> bool:
    return question.strip() == _INITIAL_STARTUP_QUESTION


def _render_header_card(*, repo_root: Path, width: int) -> list[str]:
    settings = load_codex_runtime_settings()
    version = resolve_cli_version(repo_root)
    directory = _format_directory_label(str(repo_root), max_width=max(20, width - 18))
    model_line = f"model:     {settings.model} {settings.reasoning_effort}   {settings.service_tier}   /model for config help"
    directory_line = f"directory: {directory}"
    content = [
        f">_ Ralphception (v{version})",
        "",
        model_line,
        directory_line,
    ]
    inner_width = max(len(line) for line in content)
    padded_width = inner_width + 2
    top = f"╭{'─' * padded_width}╮"
    body = [f"│ {line.ljust(inner_width)} │" for line in content]
    bottom = f"╰{'─' * padded_width}╯"
    return [top, *body, bottom]


def _format_directory_label(directory_label: str, *, max_width: int) -> str:
    normalized = normalize_directory_label(directory_label)
    if max_width <= 0 or len(normalized) <= max_width:
        return normalized

    separator = "/"
    parts = normalized.split(separator)
    if len(parts) < 4:
        return center_truncate(normalized, max_width)

    leading = parts[:3]
    trailing = parts[-2:]
    candidate = separator.join([*leading, "…", *trailing])
    if len(candidate) <= max_width:
        return candidate
    return center_truncate(normalized, max_width)


def _wrap_history_lines(lines: Sequence[str], *, width: int) -> list[str]:
    wrapped: list[str] = []
    effective_width = max(1, width)
    for line in lines:
        segments = str(line).splitlines() or [""]
        if str(line).endswith("\n"):
            segments.append("")
        for segment in segments:
            chunks = textwrap.wrap(
                segment,
                width=effective_width,
                replace_whitespace=False,
                drop_whitespace=False,
            ) or [""]
            wrapped.extend(chunks)
    return wrapped


def _trim_to_width(value: str, width: int) -> str:
    if width <= 0:
        return ""
    return value[:width]


__all__ = [
    "AnsiTerminalSurface",
    "CodexTerminalFrontend",
    "RecordingTerminalSurface",
    "ScriptedCodexTerminalFrontend",
    "run_codex_terminal_shell",
]
