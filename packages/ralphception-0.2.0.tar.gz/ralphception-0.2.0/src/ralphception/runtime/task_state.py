"""Durable task identity and continuity metadata."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from ralphception.models.artifacts import DurableModel


class TaskState(DurableModel):
    """Runtime continuity state for a task."""

    task_id: str
    session_id: str | None = None
    plan_id: str | None = None
    loop_graph_id: str | None = None
    plan_node_id: str | None = None
    active_subplan_id: str | None = None
    active_loop_id: str | None = None
    active_loop_ids: tuple[str, ...] = ()
    authoritative_artifact_revisions: dict[str, str] = Field(default_factory=dict)
    queued_next_actions: tuple[str, ...] = ()
    current_blocker: str | None = None
    current_waiting_state: str | None = None
    updated_at: datetime | None = None

    @classmethod
    def new(cls, *, task_id: str, session_id: str | None = None) -> "TaskState":
        return cls(task_id=task_id, session_id=session_id)

    def with_artifact_revision(self, artifact_kind: str, revision: str) -> "TaskState":
        revisions = dict(self.authoritative_artifact_revisions)
        revisions[artifact_kind] = revision
        return self.model_copy(update={"authoritative_artifact_revisions": revisions})

    def with_plan_context(
        self,
        *,
        plan_id: str | None = None,
        loop_graph_id: str | None = None,
        plan_node_id: str | None = None,
        active_subplan_id: str | None = None,
        active_loop_id: str | None = None,
        active_loop_ids: tuple[str, ...] | None = None,
    ) -> "TaskState":
        updates: dict[str, object] = {}
        if plan_id is not None:
            updates["plan_id"] = plan_id
        if loop_graph_id is not None:
            updates["loop_graph_id"] = loop_graph_id
        if plan_node_id is not None:
            updates["plan_node_id"] = plan_node_id
        if active_subplan_id is not None:
            updates["active_subplan_id"] = active_subplan_id
        if active_loop_id is not None:
            updates["active_loop_id"] = active_loop_id
        if active_loop_ids is not None:
            updates["active_loop_ids"] = active_loop_ids
        return self.model_copy(update=updates)


__all__ = [
    "TaskState",
]
