"""Durable artifact bootstrap plus proposal/consolidation state for Ralph loops."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any

from pydantic import Field

from ralphception.models.artifacts import ArtifactRef, DurableModel, TodoArtifact
from ralphception.runtime.loop_graph import LoopGraph
from ralphception.storage.artifacts import (
    artifact_revision_path,
    next_revision_id,
    read_authoritative_revision,
    workflow_artifact_kind_for,
    write_authoritative_revision,
)
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic, write_markdown_atomic


@dataclass(frozen=True)
class ArtifactRevision:
    artifact_kind: str
    revision_id: str
    path: Path
    workflow_artifact_kind: str
    artifact_ref: ArtifactRef


@dataclass(frozen=True)
class ArtifactInitializationResult:
    task_id: str
    revisions: dict[str, ArtifactRevision]
    paths: dict[str, Path]


class ArtifactProposal(DurableModel):
    loop_id: str
    artifact_kind: str
    revision_id: str
    created_at: datetime | None = None


class ArtifactFailureRecord(DurableModel):
    loop_id: str
    reason: str
    blocked_plan_node_ids: tuple[str, ...]
    created_at: datetime | None = None


class ArtifactPipelineState(DurableModel):
    authoritative_revisions: dict[str, str] = Field(default_factory=dict)
    proposals: list[ArtifactProposal] = Field(default_factory=list)
    failures: list[ArtifactFailureRecord] = Field(default_factory=list)


class ArtifactConsolidationResult(DurableModel):
    artifact_kind: str
    authoritative_revision_before: str | None
    authoritative_revision_after: str | None
    proposal_revision_ids: tuple[str, ...]


class ArtifactPipeline:
    REQUIRED_BOOTSTRAP_ARTIFACTS = (
        "intake-summary",
        "prd",
        "execution-plan",
        "loop-plan",
        "todos",
    )

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = bootstrap_workspace(repo_root)

    @classmethod
    def for_workspace(cls, repo_root: Path) -> "ArtifactPipeline":
        return cls(repo_root)

    def initialize_from_intake(
        self,
        *,
        task_id: str,
        intake_summary: str,
    ) -> ArtifactInitializationResult:
        normalized_task_id = task_id.strip()
        normalized_summary = intake_summary.strip()
        if not normalized_task_id:
            raise ValueError("task_id must not be blank")
        if not normalized_summary:
            raise ValueError("intake_summary must not be blank")

        revisions = {
            "intake-summary": self.write_artifact(
                "intake-summary",
                self._render_intake_summary(task_id=normalized_task_id, intake_summary=normalized_summary),
            ),
            "prd": self.write_artifact(
                "prd",
                self._render_prd(task_id=normalized_task_id, intake_summary=normalized_summary),
            ),
            "execution-plan": self.write_artifact(
                "execution-plan",
                self._render_execution_plan(task_id=normalized_task_id, intake_summary=normalized_summary),
            ),
            "loop-plan": self.write_artifact(
                "loop-plan",
                self._render_loop_plan(task_id=normalized_task_id),
            ),
        }
        revisions["todos"] = self.write_artifact(
            "todos",
            self._render_todos(
                task_id=normalized_task_id,
                intake_summary=normalized_summary,
                revisions=revisions,
            ),
        )
        return ArtifactInitializationResult(
            task_id=normalized_task_id,
            revisions=revisions,
            paths={artifact_kind: revision.path for artifact_kind, revision in revisions.items()},
        )

    def write_artifact(self, artifact_kind: str, content: str | Any) -> ArtifactRevision:
        revision_id = next_revision_id(self.repo_root, artifact_kind)
        path = artifact_revision_path(self.repo_root, artifact_kind, revision_id)
        workflow_artifact_kind = workflow_artifact_kind_for(artifact_kind)
        if path.suffix == ".json":
            json_payload = _normalize_json_payload(content)
            write_json_atomic(path, json_payload)
            serialized_content = json.dumps(json_payload, indent=2, sort_keys=True) + "\n"
        else:
            if not isinstance(content, str):
                raise TypeError(f"{artifact_kind!r} content must be markdown text")
            write_markdown_atomic(path, content)
            serialized_content = content
        write_authoritative_revision(self.repo_root, artifact_kind, revision_id)
        artifact_ref = ArtifactRef(
            artifact_kind=workflow_artifact_kind,
            artifact_path=str(path.relative_to(self.repo_root)),
            artifact_version=_artifact_version_from_revision_id(revision_id),
            content_hash=f"sha256:{hashlib.sha256(serialized_content.encode('utf-8')).hexdigest()}",
        )
        return ArtifactRevision(
            artifact_kind=artifact_kind,
            revision_id=revision_id,
            path=path,
            workflow_artifact_kind=workflow_artifact_kind,
            artifact_ref=artifact_ref,
        )

    def authoritative_revision(self, artifact_kind: str) -> str | None:
        state_revision = self._load_state().authoritative_revisions.get(artifact_kind)
        if state_revision is not None:
            return state_revision
        return read_authoritative_revision(self.repo_root, artifact_kind)

    def stage_loop_completion(self, *, loop_graph: LoopGraph, loop_id: str) -> tuple[ArtifactProposal, ...]:
        state = self._load_state()
        loop = loop_graph.loop(loop_id)
        proposals: list[ArtifactProposal] = []
        now = datetime.now(timezone.utc)
        for artifact_kind in loop.target_artifacts:
            revision_id = f"{artifact_kind}:{loop_id}:{_next_revision_suffix(state, artifact_kind)}"
            proposal = ArtifactProposal(
                loop_id=loop_id,
                artifact_kind=artifact_kind,
                revision_id=revision_id,
                created_at=now,
            )
            state.proposals.append(proposal)
            proposals.append(proposal)
            if loop_graph.merge_strategy_for(artifact_kind) == "direct_update":
                state.authoritative_revisions[artifact_kind] = revision_id
        self._write_state(state)
        return tuple(proposals)

    def consolidate_artifact(
        self,
        artifact_kind: str,
        *,
        selected_loop_id: str | None = None,
    ) -> ArtifactConsolidationResult:
        state = self._load_state()
        proposals = [proposal for proposal in state.proposals if proposal.artifact_kind == artifact_kind]
        before = state.authoritative_revisions.get(artifact_kind) or read_authoritative_revision(
            self.repo_root,
            artifact_kind,
        )
        selected = _select_proposal(proposals, selected_loop_id=selected_loop_id)
        after = before if selected is None else selected.revision_id
        if selected is not None:
            state.authoritative_revisions[artifact_kind] = selected.revision_id
        self._write_state(state)
        return ArtifactConsolidationResult(
            artifact_kind=artifact_kind,
            authoritative_revision_before=before,
            authoritative_revision_after=after,
            proposal_revision_ids=tuple(proposal.revision_id for proposal in proposals),
        )

    def record_loop_failure(self, *, loop_graph: LoopGraph, loop_id: str, reason: str) -> ArtifactFailureRecord:
        state = self._load_state()
        record = ArtifactFailureRecord(
            loop_id=loop_id,
            reason=reason,
            blocked_plan_node_ids=loop_graph.blocked_plan_node_ids_for_failure(loop_id),
            created_at=datetime.now(timezone.utc),
        )
        state.failures.append(record)
        self._write_state(state)
        return record

    def _render_intake_summary(self, *, task_id: str, intake_summary: str) -> str:
        return (
            "# Intake Summary\n\n"
            f"Task ID: {task_id}\n\n"
            f"Summary: {intake_summary}\n"
        )

    def _render_prd(self, *, task_id: str, intake_summary: str) -> str:
        return (
            "# PRD\n\n"
            f"Task ID: {task_id}\n\n"
            "## Problem\n\n"
            f"{intake_summary}\n\n"
            "## Success Criteria\n\n"
            "- Produce the requested change set.\n"
        )

    def _render_execution_plan(self, *, task_id: str, intake_summary: str) -> str:
        return (
            "# Execution Plan\n\n"
            f"Task ID: {task_id}\n\n"
            "## Objective\n\n"
            f"{intake_summary}\n\n"
            "## Initial Steps\n\n"
            "1. Review the authoritative PRD.\n"
            "2. Execute the current loop plan.\n"
        )

    def _render_loop_plan(self, *, task_id: str) -> str:
        return (
            "# Loop Plan\n\n"
            f"Task ID: {task_id}\n\n"
            "## Loop Contract\n\n"
            "- Read authoritative artifacts.\n"
            "- Execute one bounded unit of work.\n"
            "- Consolidate outputs back into authoritative artifacts.\n"
        )

    def _render_todos(
        self,
        *,
        task_id: str,
        intake_summary: str,
        revisions: dict[str, ArtifactRevision],
    ) -> list[TodoArtifact]:
        return [
            TodoArtifact(
                todo_id=f"{task_id}-1",
                title=intake_summary,
                priority="P1",
                status="open",
                bundle_version=1,
                artifact_refs=[
                    revisions["intake-summary"].artifact_ref,
                    revisions["prd"].artifact_ref,
                    revisions["execution-plan"].artifact_ref,
                    revisions["loop-plan"].artifact_ref,
                ],
            ),
        ]

    def _load_state(self) -> ArtifactPipelineState:
        path = self._state_path()
        if not path.exists():
            return ArtifactPipelineState()
        return ArtifactPipelineState.model_validate_json(path.read_text(encoding="utf-8"))

    def _write_state(self, state: ArtifactPipelineState) -> None:
        artifacts_dir = self.repo_root / ".ralphception" / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        write_json_atomic(self._state_path(), state.model_dump(mode="json"))
        write_json_atomic(
            artifacts_dir / "failures.json",
            {"failures": [failure.model_dump(mode="json") for failure in state.failures]},
        )

    def _state_path(self) -> Path:
        return self.repo_root / ".ralphception" / "artifacts" / "state.json"


def _next_revision_suffix(state: ArtifactPipelineState, artifact_kind: str) -> int:
    count = sum(1 for proposal in state.proposals if proposal.artifact_kind == artifact_kind)
    return count + 1


def _select_proposal(
    proposals: list[ArtifactProposal],
    *,
    selected_loop_id: str | None,
) -> ArtifactProposal | None:
    if selected_loop_id is not None:
        for proposal in reversed(proposals):
            if proposal.loop_id == selected_loop_id:
                return proposal
    return proposals[-1] if proposals else None


def _normalize_json_payload(content: Any) -> Any:
    if isinstance(content, list):
        return [_normalize_json_payload(item) for item in content]
    if hasattr(content, "model_dump"):
        return content.model_dump(mode="json")
    return content


def _artifact_version_from_revision_id(revision_id: str) -> int:
    if not revision_id.startswith("rev-"):
        raise ValueError(f"unsupported revision id: {revision_id}")
    suffix = revision_id.removeprefix("rev-")
    if not suffix.isdigit():
        raise ValueError(f"unsupported revision id: {revision_id}")
    return int(suffix)


__all__ = [
    "ArtifactConsolidationResult",
    "ArtifactFailureRecord",
    "ArtifactInitializationResult",
    "ArtifactPipeline",
    "ArtifactPipelineState",
    "ArtifactProposal",
    "ArtifactRevision",
]
