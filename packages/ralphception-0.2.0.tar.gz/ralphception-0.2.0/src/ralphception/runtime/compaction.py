"""Durable compaction checkpoints for root-thread recovery."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.artifacts import DurableModel
from ralphception.runtime.frontier import TaskFrontier
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic

COMPACTION_REFRESH_BEGIN = "RALPHCEPTION_COMPACTION_REFRESH_START"
COMPACTION_REFRESH_END = "RALPHCEPTION_COMPACTION_REFRESH_END"


class CompactionCheckpoint(DurableModel):
    checkpoint_id: str
    root_run_id: str
    reason: str
    summary_text: str
    pre_compact_thread_id: str
    post_compact_thread_id: str
    created_at: datetime


def compaction_checkpoint_dir(repo_root: Path) -> Path:
    resolved_root = bootstrap_workspace(repo_root)
    return resolved_root / ".ralphception" / "runtime" / "compaction-checkpoints"


def persist_compaction_checkpoint(
    repo_root: Path,
    *,
    root_run_id: str,
    reason: str,
    summary_text: str,
    pre_compact_thread_id: str,
    post_compact_thread_id: str,
) -> CompactionCheckpoint:
    checkpoint = CompactionCheckpoint(
        checkpoint_id=f"compaction-{uuid.uuid4().hex}",
        root_run_id=root_run_id,
        reason=reason,
        summary_text=summary_text,
        pre_compact_thread_id=pre_compact_thread_id,
        post_compact_thread_id=post_compact_thread_id,
        created_at=datetime.now(timezone.utc),
    )
    directory = compaction_checkpoint_dir(repo_root)
    write_json_atomic(directory / f"{checkpoint.checkpoint_id}.json", checkpoint.model_dump(mode="json"))
    return checkpoint


def latest_compaction_checkpoint(repo_root: Path) -> CompactionCheckpoint | None:
    directory = compaction_checkpoint_dir(repo_root)
    if not directory.exists():
        return None
    candidates = [
        CompactionCheckpoint.model_validate_json(path.read_text(encoding="utf-8"))
        for path in sorted(directory.glob("*.json"))
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda checkpoint: checkpoint.created_at)


def build_compaction_summary(
    *,
    goal: str,
    frontier: TaskFrontier,
    recent_runtime_events: tuple[str, ...],
) -> str:
    frontier_lines = "\n".join(f"- {item.summary}" for item in frontier.frontier_items) or "- none"
    event_lines = "\n".join(f"- {line}" for line in recent_runtime_events) or "- none"
    return (
        f"Goal: {goal}\n"
        f"Current stage: {frontier.current_stage or 'none'}\n"
        f"Frontier status: {frontier.status}\n"
        f"Stuck count: {frontier.stuck_count}\n"
        "Outstanding work:\n"
        f"{frontier_lines}\n"
        "Recent runtime events:\n"
        f"{event_lines}"
    )


def build_compaction_refresh_prompt(*, goal: str, reason: str, summary_text: str) -> str:
    return (
        "You are resuming a Ralphception root thread after an intentional compaction.\n"
        "The prior verbose thread history has been replaced by the compact summary below.\n"
        "Do not ask a new question or start work from this message alone. Just absorb the summary and reply with one short readiness line.\n\n"
        f"Goal: {goal}\n"
        f"Compaction reason: {reason}\n\n"
        f"{summary_text}\n\n"
        f"{COMPACTION_REFRESH_BEGIN}\n"
        "ready\n"
        f"{COMPACTION_REFRESH_END}"
    )


__all__ = [
    "COMPACTION_REFRESH_BEGIN",
    "COMPACTION_REFRESH_END",
    "CompactionCheckpoint",
    "build_compaction_refresh_prompt",
    "build_compaction_summary",
    "compaction_checkpoint_dir",
    "latest_compaction_checkpoint",
    "persist_compaction_checkpoint",
]
