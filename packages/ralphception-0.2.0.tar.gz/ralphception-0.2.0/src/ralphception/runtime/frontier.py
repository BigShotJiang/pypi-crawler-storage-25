"""Durable frontier state for incomplete root-task progress."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import Field

from ralphception.models.artifacts import DurableModel
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, Stage
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.interactive_session import load_interactive_session_state
from ralphception.runtime.prompt_state import PendingPrompt
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.workflow.engine import WorkflowEngine

FrontierStatus = Literal["incomplete", "blocked", "completed"]
FrontierItemKind = Literal["continue_stage", "review_prompt", "pending_prompt", "failed_run", "mark_complete"]

_FRONTIER_FILENAME = "task-frontier.json"
_REVIEW_PROMPT_KINDS = {"spec_review", "execution_bundle", "recovery_review"}


class FrontierItem(DurableModel):
    kind: FrontierItemKind
    summary: str
    run_id: str | None = None
    stage_kind: str | None = None
    prompt_id: str | None = None


class StuckSignal(DurableModel):
    reason: str
    count: int = Field(default=1, ge=0)


class TaskFrontier(DurableModel):
    root_run_id: str
    status: FrontierStatus
    goal: str | None = None
    current_stage: str | None = None
    frontier_items: list[FrontierItem] = Field(default_factory=list)
    active_loop_ids: list[str] = Field(default_factory=list)
    blocked_reason: str | None = None
    stuck_signals: list[StuckSignal] = Field(default_factory=list)
    last_progress_at: datetime | None = None
    last_watchdog_run_at: datetime | None = None
    stuck_count: int = Field(default=0, ge=0)
    updated_at: datetime


def frontier_path(repo_root: Path) -> Path:
    resolved_root = bootstrap_workspace(repo_root)
    return resolved_root / ".ralphception" / "runtime" / _FRONTIER_FILENAME


def load_task_frontier(repo_root: Path) -> TaskFrontier | None:
    path = frontier_path(repo_root)
    if path.exists():
        return TaskFrontier.model_validate_json(path.read_text(encoding="utf-8"))
    return None


def clear_task_frontier(repo_root: Path) -> None:
    path = frontier_path(repo_root)
    if path.exists():
        path.unlink()


def persist_task_frontier(
    repo_root: Path,
    *,
    engine: WorkflowEngine | None = None,
    pending_prompt: PendingPrompt | None = None,
    review_prompt_kind: str | None = None,
) -> TaskFrontier | None:
    frontier = derive_task_frontier(
        repo_root,
        engine=engine,
        pending_prompt=pending_prompt,
        review_prompt_kind=review_prompt_kind,
    )
    if frontier is None:
        clear_task_frontier(repo_root)
        return None
    return write_task_frontier(repo_root, frontier)


def write_task_frontier(repo_root: Path, frontier: TaskFrontier) -> TaskFrontier:
    write_json_atomic(frontier_path(repo_root), frontier.model_dump(mode="json"))
    return frontier


def mark_task_frontier(
    repo_root: Path,
    *,
    status: FrontierStatus,
    root_run_id: str,
    current_stage: str | None,
    frontier_items: list[FrontierItem] | None = None,
    active_loop_ids: list[str] | None = None,
) -> TaskFrontier:
    now = datetime.now(timezone.utc)
    startup_record = load_startup_record(repo_root)
    frontier = TaskFrontier(
        root_run_id=root_run_id,
        status=status,
        goal=None if startup_record is None else startup_record.seed_prompt,
        current_stage=current_stage,
        frontier_items=[] if frontier_items is None else frontier_items,
        active_loop_ids=[] if active_loop_ids is None else active_loop_ids,
        last_progress_at=now,
        updated_at=now,
    )
    return write_task_frontier(repo_root, frontier)


def derive_task_frontier(
    repo_root: Path,
    *,
    engine: WorkflowEngine | None = None,
    pending_prompt: PendingPrompt | None = None,
    review_prompt_kind: str | None = None,
) -> TaskFrontier | None:
    resolved_root = bootstrap_workspace(repo_root)
    startup_record = load_startup_record(resolved_root)
    existing = load_task_frontier(resolved_root)
    if startup_record is None:
        return existing

    prompt_state = load_interactive_session_state(resolved_root)
    prompt = pending_prompt or (prompt_state.pending_prompts[0] if prompt_state.pending_prompts else None)
    root_run = _load_root_run(resolved_root, run_id=startup_record.outer_run_id)
    root_run_id = startup_record.outer_run_id
    now = datetime.now(timezone.utc)
    goal = startup_record.seed_prompt
    last_progress_at = (
        root_run.updated_at
        if root_run is not None
        else startup_record.created_at
    )
    from ralphception.runtime.watchdog import load_root_watchdog

    watchdog = load_root_watchdog(resolved_root)
    last_watchdog_run_at = None if watchdog is None else watchdog.last_activated_at
    terminal_outcome, current_stage = _load_headless_stage_state(resolved_root)
    stuck_signals = _derive_stuck_signals(
        resolved_root,
        root_run_id=root_run_id,
        terminal_outcome=terminal_outcome,
        current_stage=current_stage,
    )
    stuck_count = sum(signal.count for signal in stuck_signals)

    if prompt is not None:
        item_kind: FrontierItemKind = (
            "review_prompt" if prompt.prompt_kind in _REVIEW_PROMPT_KINDS else "pending_prompt"
        )
        return TaskFrontier(
            root_run_id=root_run_id,
            status="blocked",
            goal=goal,
            current_stage=_infer_current_stage(resolved_root, engine=engine, root_run=root_run),
            frontier_items=[
                FrontierItem(
                    kind=item_kind,
                    summary=prompt.question,
                    run_id=prompt.owner_run_id,
                    prompt_id=prompt.prompt_id,
                )
            ],
            active_loop_ids=_load_active_loop_ids(resolved_root),
            blocked_reason=prompt.prompt_kind,
            stuck_signals=stuck_signals,
            stuck_count=stuck_count,
            last_progress_at=last_progress_at,
            last_watchdog_run_at=last_watchdog_run_at,
            updated_at=now,
        )

    if review_prompt_kind is not None:
        return TaskFrontier(
            root_run_id=root_run_id,
            status="blocked",
            goal=goal,
            current_stage=_infer_current_stage(resolved_root, engine=engine, root_run=root_run),
            frontier_items=[
                FrontierItem(
                    kind="review_prompt",
                    summary=f"Await {review_prompt_kind} review",
                    run_id=root_run_id,
                )
            ],
            active_loop_ids=_load_active_loop_ids(resolved_root),
            blocked_reason=review_prompt_kind,
            stuck_signals=stuck_signals,
            stuck_count=stuck_count,
            last_progress_at=last_progress_at,
            last_watchdog_run_at=last_watchdog_run_at,
            updated_at=now,
        )

    if root_run is not None and root_run.status == "completed":
        return TaskFrontier(
            root_run_id=root_run_id,
            status="completed",
            goal=goal,
            current_stage="completed",
            frontier_items=[],
            active_loop_ids=[],
            last_progress_at=root_run.updated_at,
            last_watchdog_run_at=last_watchdog_run_at,
            updated_at=now,
        )
    active_loop_ids = _load_active_loop_ids(resolved_root)
    inferred_stage = _infer_current_stage(resolved_root, engine=engine, root_run=root_run)
    if terminal_outcome == "completed" or inferred_stage == "completed":
        return TaskFrontier(
            root_run_id=root_run_id,
            status="completed",
            goal=goal,
            current_stage="completed",
            frontier_items=[],
            active_loop_ids=[],
            last_progress_at=last_progress_at,
            last_watchdog_run_at=last_watchdog_run_at,
            updated_at=now,
        )
    if terminal_outcome == "failed" or current_stage == "failed" or (root_run is not None and root_run.status == "failed"):
        failed_stage = inferred_stage or current_stage
        failure_signals = stuck_signals or [StuckSignal(reason="runtime_failed", count=1)]
        return TaskFrontier(
            root_run_id=root_run_id,
            status="blocked",
            goal=goal,
            current_stage=failed_stage,
            frontier_items=[
                FrontierItem(
                    kind="failed_run",
                    summary=f"Investigate failed {failed_stage or 'runtime'} stage",
                    run_id=root_run_id,
                    stage_kind=failed_stage,
                )
            ],
            active_loop_ids=active_loop_ids,
            blocked_reason="failed",
            last_progress_at=last_progress_at,
            last_watchdog_run_at=last_watchdog_run_at,
            updated_at=now,
            stuck_count=max(stuck_count, 1),
            stuck_signals=failure_signals,
        )

    continue_stage = inferred_stage or "execute"
    return TaskFrontier(
        root_run_id=root_run_id,
        status="incomplete",
        goal=goal,
        current_stage=continue_stage,
        frontier_items=[
            FrontierItem(
                kind="continue_stage",
                summary=f"Continue {continue_stage} stage",
                run_id=root_run_id,
                stage_kind=continue_stage,
            )
        ],
        active_loop_ids=active_loop_ids,
        stuck_signals=stuck_signals,
        stuck_count=stuck_count,
        last_progress_at=last_progress_at,
        last_watchdog_run_at=last_watchdog_run_at,
        updated_at=now,
    )


def _derive_stuck_signals(
    repo_root: Path,
    *,
    root_run_id: str,
    terminal_outcome: str | None,
    current_stage: str | None,
) -> list[StuckSignal]:
    signals: list[StuckSignal] = []
    if terminal_outcome == "failed" or current_stage == "failed":
        signals.append(StuckSignal(reason="runtime_failed", count=1))

    try:
        events = EventStore(repo_root).read_run(root_run_id)
    except Exception:
        events = []
    recent_event_types = [event.event_type for event in events[-12:]]
    repeated_watchdog_decisions = recent_event_types.count("stage.custom_watchdog_decided")
    if repeated_watchdog_decisions >= 2:
        signals.append(
            StuckSignal(reason="repeated_watchdog_decisions", count=repeated_watchdog_decisions)
        )
    repeated_reopens = recent_event_types.count("stage.custom_headless_audit_reopened")
    if repeated_reopens >= 2:
        signals.append(StuckSignal(reason="repeated_audit_reopen", count=repeated_reopens))
    repeated_stage_failures = recent_event_types.count("stage.failed")
    if repeated_stage_failures >= 2:
        signals.append(StuckSignal(reason="repeated_stage_failures", count=repeated_stage_failures))
    repeated_next_steps = recent_event_types.count("stage.custom_next_steps_emitted")
    if repeated_next_steps >= 2:
        signals.append(StuckSignal(reason="repeated_next_steps", count=repeated_next_steps))

    from ralphception.runtime.compaction import latest_compaction_checkpoint
    from ralphception.runtime.watchdog import list_root_watchdog_activations

    repeated_no_artifact_delta = _count_repeated_watchdog_runs_without_artifact_delta(
        list_root_watchdog_activations(repo_root),
        root_run_id=root_run_id,
    )
    if repeated_no_artifact_delta >= 2:
        signals.append(
            StuckSignal(reason="watchdog_no_artifact_delta", count=repeated_no_artifact_delta)
        )

    latest_compaction = latest_compaction_checkpoint(repo_root)
    if latest_compaction is not None and latest_compaction.root_run_id == root_run_id:
        signals.append(StuckSignal(reason="watchdog_compaction", count=1))

    return signals


def _count_repeated_watchdog_runs_without_artifact_delta(
    activations,
    *,
    root_run_id: str,
) -> int:
    matching = [
        activation
        for activation in activations
        if activation.root_run_id == root_run_id
    ]
    if len(matching) < 2:
        return 0
    latest_paths = matching[-1].input_snapshot.artifact_paths
    count = 0
    for activation in reversed(matching):
        if activation.input_snapshot.artifact_paths != latest_paths:
            break
        count += 1
    return count


def _load_root_run(repo_root: Path, *, run_id: str) -> Run | None:
    path = repo_root / ".ralphception" / "runs" / run_id / "run.json"
    if not path.exists():
        return None
    return Run.model_validate_json(path.read_text(encoding="utf-8"))


def _load_headless_stage_state(repo_root: Path) -> tuple[str | None, str | None]:
    path = repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json"
    if not path.exists():
        return (None, None)
    payload = json.loads(path.read_text(encoding="utf-8"))
    terminal_outcome = payload.get("terminal_outcome")
    current_stage = payload.get("current_stage")
    return (
        terminal_outcome if isinstance(terminal_outcome, str) else None,
        current_stage if isinstance(current_stage, str) else None,
    )


def _load_active_loop_ids(repo_root: Path) -> list[str]:
    path = repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json"
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding="utf-8"))
    value = payload.get("active_loop_ids")
    if not isinstance(value, list):
        return []
    return [loop_id for loop_id in value if isinstance(loop_id, str)]


def _infer_current_stage(repo_root: Path, *, engine: WorkflowEngine | None, root_run: Run | None) -> str | None:
    if engine is not None:
        from_engine = _infer_current_stage_from_engine(engine)
        if from_engine is not None:
            return from_engine

    _, from_headless_state = _load_headless_stage_state(repo_root)
    if from_headless_state is not None:
        return from_headless_state

    if root_run is not None and root_run.status == "completed":
        return "completed"

    if _has_pending_review(repo_root):
        return "spec"
    if _has_approved_bundle(repo_root):
        return "execute"
    if _has_approved_spec(repo_root):
        return "plan"
    if _has_spec_artifact(repo_root):
        return "spec"
    return "intake"


def _infer_current_stage_from_engine(engine: WorkflowEngine) -> str | None:
    stages: list[Stage] = []
    for stage_kind in ("intake", "spec", "plan", "execute", "merge", "audit"):
        try:
            stages.append(engine.stage(stage_kind))
        except KeyError:
            continue
    for status in ("running", "awaiting_approval", "blocked", "recovery_blocked", "session_lost", "pending"):
        stage = next((candidate for candidate in stages if candidate.status == status), None)
        if stage is not None:
            return stage.stage_kind
    if stages and all(candidate.status == "completed" for candidate in stages):
        return "completed"
    return None


def _has_spec_artifact(repo_root: Path) -> bool:
    return any((repo_root / ".ralphception" / "specs").glob("**/*"))


def _has_approved_spec(repo_root: Path) -> bool:
    return any(
        approval.approval_kind == "spec_review"
        for approval in _load_approvals(repo_root)
    )


def _has_approved_bundle(repo_root: Path) -> bool:
    return any(bundle.state == "approved" for bundle in _load_bundles(repo_root))


def _has_pending_review(repo_root: Path) -> bool:
    if not _has_spec_artifact(repo_root):
        return False
    if not _has_approved_spec(repo_root):
        return True
    return any(bundle.state == "awaiting_approval" for bundle in _load_bundles(repo_root))


def _load_approvals(repo_root: Path) -> list[ApprovalRecord]:
    approval_dir = repo_root / ".ralphception" / "approvals"
    if not approval_dir.exists():
        return []
    return [
        ApprovalRecord.model_validate_json(path.read_text(encoding="utf-8"))
        for path in sorted(approval_dir.glob("*.json"))
    ]


def _load_bundles(repo_root: Path) -> list[ExecutionBundle]:
    bundle_dir = repo_root / ".ralphception" / "runs" / "run-root" / "bundles"
    if not bundle_dir.exists():
        return []
    return [
        ExecutionBundle.model_validate_json(path.read_text(encoding="utf-8"))
        for path in sorted(bundle_dir.glob("*.json"))
    ]


__all__ = [
    "FrontierItem",
    "StuckSignal",
    "TaskFrontier",
    "clear_task_frontier",
    "derive_task_frontier",
    "frontier_path",
    "load_task_frontier",
    "mark_task_frontier",
    "persist_task_frontier",
    "write_task_frontier",
]
