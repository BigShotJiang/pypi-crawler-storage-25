"""Shared runtime supervisor and frontend exports."""

from __future__ import annotations

from ralphception.runtime.frontends import (
    FrontendEvent,
    ReviewDecision,
    RuntimeFrontend,
    RuntimeStep,
)
from ralphception.runtime.prompt_state import PendingPrompt, PromptResolution

__all__ = [
    "FrontendEvent",
    "PendingPrompt",
    "PromptResolution",
    "ReviewDecision",
    "RuntimeFrontend",
    "RuntimeStep",
    "RuntimeSupervisor",
]


def __getattr__(name: str):
    if name == "RuntimeSupervisor":
        from ralphception.runtime.supervisor import RuntimeSupervisor

        return RuntimeSupervisor
    raise AttributeError(name)
