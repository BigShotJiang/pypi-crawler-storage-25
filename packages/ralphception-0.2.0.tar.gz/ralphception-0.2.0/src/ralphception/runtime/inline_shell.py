"""Primary inline-shell frontend over the shared runtime supervisor."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from ralphception.config import RalphceptionConfig
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BlockerPromptEvent,
    CommandBeginEvent,
    CommandEndEvent,
    FrontendEvent,
    CommandOutputDeltaEvent,
    CurrentBlockerStateEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FailureSummaryEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    ReasoningFinalEvent,
    ReasoningSectionBreakEvent,
    ReasoningSummaryDeltaEvent,
    RuntimeStep,
)
from ralphception.runtime.supervisor import RuntimeLaunchAbortedError, RuntimeSupervisor


@dataclass(frozen=True, slots=True)
class InlineShellRunResult:
    mode: Literal["running", "completed", "failed"]
    root_run_id: str | None = None
    authoritative_repo_root: str | None = None
    log_text: str = ""


@dataclass(slots=True)
class InlineShellFrontend:
    """Scrollback-first interactive shell surface."""

    input_func: Callable[[str], str] = input
    write_func: Callable[[str], None] = print
    default_repo_root: Path | None = None
    default_session_manager_factory: object | None = None
    _output_lines: list[str] = field(default_factory=list)
    events: list[FrontendEvent] = field(default_factory=list)
    live_status: str | None = None
    current_task_label: str | None = None
    current_plan_node_label: str | None = None
    current_loop_label: str | None = None
    current_blocker_state: str | None = None
    current_waiting_state: str | None = None
    _assistant_deltas: dict[str, str] = field(default_factory=dict)
    _reasoning_deltas: dict[str, str] = field(default_factory=dict)

    def emit_event(self, event: FrontendEvent) -> None:
        self.events.append(event)
        if isinstance(event, LiveStatusEvent):
            self.live_status = event.text
            return
        if isinstance(event, CommandBeginEvent):
            self._write(f"Command started: {_compact_command_for_scrollback(event.command)}")
            return
        if isinstance(event, CommandEndEvent):
            command = _compact_command_for_scrollback(event.command)
            if event.exit_code is not None:
                self._write(f"Command completed (exit {event.exit_code}): {command}")
            elif event.status is not None and event.status != "completed":
                self._write(f"Command {event.status}: {command}")
            else:
                self._write(f"Command completed: {command}")
            return
        if isinstance(event, AssistantDeltaEvent):
            self._assistant_deltas[event.item_id] = event.text
            return
        if isinstance(event, AssistantFinalEvent):
            if event.item_id is not None:
                self._assistant_deltas.pop(event.item_id, None)
            self._write(event.message)
            return
        if isinstance(event, ReasoningSummaryDeltaEvent):
            self._reasoning_deltas[event.item_id] = event.text
            return
        if isinstance(event, ReasoningSectionBreakEvent):
            return
        if isinstance(event, ReasoningFinalEvent):
            if event.item_id is not None:
                self._reasoning_deltas.pop(event.item_id, None)
            return
        if isinstance(event, CurrentTaskLabelEvent):
            self.current_task_label = None if event.cleared else event.label
            return
        if isinstance(event, CurrentPlanNodeLabelEvent):
            self.current_plan_node_label = None if event.cleared else event.label
            return
        if isinstance(event, CurrentLoopLabelEvent):
            self.current_loop_label = None if event.cleared else event.label
            return
        if isinstance(event, CurrentBlockerStateEvent):
            self.current_blocker_state = None if event.cleared else event.label
            return
        if isinstance(event, CurrentWaitingStateEvent):
            previous_waiting_state = self.current_waiting_state
            self.current_waiting_state = None if event.cleared else event.label
            if self.current_waiting_state and self.current_waiting_state != previous_waiting_state:
                self._write(self.current_waiting_state)
            return
        if event.kind == "stage.started":
            self._write(_humanize_stage_message(event.stage_kind))
            return
        if event.kind in {"turn.started", "turn.completed"}:
            return
        if event.message.startswith("Child run created: "):
            return
        if isinstance(event, BlockerPromptEvent):
            self.current_blocker_state = event.question
            self._write(event.message)
            return
        if isinstance(event, CommandOutputDeltaEvent):
            self._write(event.message)
            return
        if isinstance(event, (LoopLaunchEvent, LoopCompletionEvent)):
            self.current_loop_label = event.loop_label
        if isinstance(event, (LoopCompletionEvent, FailureSummaryEvent)):
            self.current_waiting_state = None
        self._write(event.message)

    def emit_status(self, step: RuntimeStep) -> None:
        self._write(f"Runtime: {step.kind}")

    def finish(self, step: RuntimeStep) -> None:
        self._write(f"Finished: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self._output_lines)

    def run(
        self,
        *,
        repo_root: Path | None = None,
        seed_prompt: str | None = None,
        source_repos: tuple[str, ...] = (),
        resume: bool = False,
        approve_all: bool = False,
        approver: str = "inline-shell",
        use_fake_session_manager: bool = False,
        session_manager_factory=None,
    ) -> InlineShellRunResult:
        return run_inline_shell(
            repo_root=self.default_repo_root if repo_root is None else repo_root,
            seed_prompt=seed_prompt,
            source_repos=source_repos,
            resume=resume,
            approve_all=approve_all,
            approver=approver,
            use_fake_session_manager=use_fake_session_manager,
            session_manager_factory=(
                self.default_session_manager_factory
                if session_manager_factory is None
                else session_manager_factory
            ),
            frontend=self,
        )

    def _write(self, text: str) -> None:
        self._output_lines.append(text)
        self.write_func(text)


_MAX_INLINE_COMMAND_LENGTH = 120


def _compact_command_for_scrollback(command: str, *, limit: int = _MAX_INLINE_COMMAND_LENGTH) -> str:
    if len(command) <= limit:
        return command
    return f"{command[: limit - 3].rstrip()}..."


@dataclass(slots=True)
class ScriptedInlineShellFrontend(InlineShellFrontend):
    """Deterministic inline shell for integration tests."""

    scripted_inputs: list[str] = field(default_factory=list)

    def __init__(self, *, inputs: Sequence[str] = ()) -> None:
        self.scripted_inputs = list(inputs)
        InlineShellFrontend.__init__(self, input_func=self._consume_input, write_func=lambda text: None)

    def _consume_input(self, prompt: str) -> str:
        self._output_lines.append(prompt)
        if not self.scripted_inputs:
            raise RuntimeError(f"no scripted input available for prompt {prompt!r}")
        return self.scripted_inputs.pop(0)


def run_inline_shell(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "inline-shell",
    use_fake_session_manager: bool = False,
    session_manager_factory=None,
    frontend: InlineShellFrontend | None = None,
) -> InlineShellRunResult:
    resolved_repo_root = Path.cwd() if repo_root is None else repo_root
    resolved_frontend = frontend or InlineShellFrontend()
    resolved_session_manager_factory = _resolve_inline_shell_session_manager_factory(
        session_manager_factory=session_manager_factory,
        use_fake_session_manager=use_fake_session_manager,
    )
    supervisor = RuntimeSupervisor(
        repo_root=resolved_repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        approve_all=approve_all,
        approver=approver,
        session_manager_factory=resolved_session_manager_factory,
    )
    if resume:
        supervisor.request_resume_launch()
    while True:
        result = supervisor.run(frontend=resolved_frontend)
        if result.mode in {"completed", "failed"}:
            break
        prompt = supervisor.current_pending_prompt()
        if prompt is None:
            break
        reply = resolved_frontend.input_func("You: " if prompt.prompt_kind == "startup_prompt" else "Reply: ").strip()
        if prompt.prompt_kind == "launch_conflict" and reply.lower() in {"start", "new"}:
            reply = "override"
        if prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"} and reply.lower() in {"pause", "/pause"}:
            startup_record = load_startup_record(supervisor.repo_root)
            resolved_frontend.emit_status(RuntimeStep(kind="review_prompt"))
            return InlineShellRunResult(
                mode="running",
                root_run_id=None if startup_record is None else startup_record.outer_run_id,
                authoritative_repo_root=str(supervisor.repo_root),
                log_text=resolved_frontend.output_text(),
            )
        resolution = supervisor.resolve_pending_prompt(thread_id=prompt.thread_id, user_text=reply)
        if resolution.kind != "resolved":
            continue
        resolved_frontend.emit_event(CurrentBlockerStateEvent.clear())
        if resolution.action == "abort" and prompt.prompt_kind in {"resume_session", "launch_conflict"}:
            raise RuntimeLaunchAbortedError("Launch aborted.")
    resolved_frontend.emit_status(RuntimeStep(kind=result.mode))
    return InlineShellRunResult(
        mode="completed" if result.mode == "completed" else ("failed" if result.mode == "failed" else "running"),
        root_run_id=result.root_run_id,
        authoritative_repo_root=result.authoritative_repo_root,
        log_text=resolved_frontend.output_text(),
    )


def _resolve_inline_shell_session_manager_factory(
    *,
    session_manager_factory,
    use_fake_session_manager: bool,
):
    if session_manager_factory is not None:
        return session_manager_factory
    if not use_fake_session_manager:
        return None

    from ralphception.testing.fakes import build_fake_headless_session_manager

    def _factory(repo_root: Path, config: RalphceptionConfig) -> object:
        return build_fake_headless_session_manager(workspace_path=str(repo_root), config=config)

    return _factory


def _humanize_stage_message(stage_kind: str | None) -> str:
    if stage_kind == "spec":
        return "Writing the PRD"
    if stage_kind == "plan":
        return "Preparing the execution plan"
    if stage_kind == "execute":
        return "Executing the loop plan"
    if stage_kind == "merge":
        return "Consolidating loop results"
    if stage_kind == "audit":
        return "Auditing the merged result"
    return "Working"


__all__ = [
    "InlineShellFrontend",
    "InlineShellRunResult",
    "ScriptedInlineShellFrontend",
    "run_inline_shell",
]
