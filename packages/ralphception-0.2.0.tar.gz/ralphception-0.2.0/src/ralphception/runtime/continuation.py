"""Low-level continuation hint detection for durable runtime signals."""

from __future__ import annotations

import re
from typing import Literal

ContinuationHint = Literal["next_steps"]

_NEXT_STEPS_RE = re.compile(r"\bnext steps?\b", re.IGNORECASE)


def detect_continuation_hint(text: str | None) -> ContinuationHint | None:
    if not text:
        return None
    if _NEXT_STEPS_RE.search(text):
        return "next_steps"
    return None


__all__ = ["ContinuationHint", "detect_continuation_hint"]
