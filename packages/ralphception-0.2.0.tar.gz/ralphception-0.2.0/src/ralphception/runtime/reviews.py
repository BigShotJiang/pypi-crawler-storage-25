"""Artifact review, approval, and recovery helpers."""

from __future__ import annotations

import difflib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Protocol, cast

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, StageKind
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.workflow.approvals import (
    approval_snapshot_dir,
    create_execution_bundle_approval,
    create_spec_review,
    persist_approval,
)
from ralphception.workflow.bundles import compute_scope_hash_for_artifacts, transition_bundle_state
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import ResumeResult

_PENDING_BUNDLE_STATES = frozenset({"draft", "awaiting_approval"})
_RECOVERY_RUN_STATUSES = frozenset({"blocked", "failed", "session_lost", "recovery_blocked"})


class RecoveryActionsProtocol(Protocol):
    """Recovery operations the review screen can trigger."""

    def resume(self, *, run_id: str, mode: Literal["read", "repair"]) -> ResumeResult: ...

    def retry_run(self, run_id: str) -> Run: ...

    def restart_run(self, run_id: str) -> Run: ...

    def replace_run(self, run_id: str) -> Run: ...


@dataclass(frozen=True, slots=True)
class ReviewTarget:
    """Current review target shown on the review screen."""

    kind: Literal["spec_review", "execution_bundle", "recovery"]
    run_id: str
    artifact_refs: tuple[ArtifactRef, ...] = ()
    bundle_id: str | None = None
    bundle_version: int | None = None


@dataclass(frozen=True, slots=True)
class ReviewDiffEntry:
    """A single artifact diff entry."""

    artifact_path: str
    diff_text: str


@dataclass(frozen=True, slots=True)
class ReviewDiffResult:
    """The rendered diff body for a review target."""

    title: str
    entries: tuple[ReviewDiffEntry, ...]
    rendered_text: str


class ArtifactReviewController:
    """Drive approval gating, artifact diffs, and recovery actions."""

    def __init__(
        self,
        *,
        repo_root: Path,
        engine: WorkflowEngine,
        recovery_service: RecoveryActionsProtocol | None = None,
    ) -> None:
        self.repo_root = bootstrap_workspace(repo_root)
        self.engine = engine
        self.recovery_service = recovery_service

    @property
    def can_enter_plan_generation(self) -> bool:
        """Return whether plan generation is unblocked."""
        return self.engine.can_enter_plan_stage()

    @property
    def can_enter_execution(self) -> bool:
        """Return whether execution is unblocked."""
        return self.engine.can_enter_execute_stage()

    def current_target(self) -> ReviewTarget | None:
        """Return the highest-priority review or recovery target."""
        pending_targets = self.pending_targets()
        return pending_targets[0] if pending_targets else None

    def pending_targets(self) -> tuple[ReviewTarget, ...]:
        """Return pending review and recovery targets in priority order."""
        targets: list[ReviewTarget] = []
        spec_artifacts = self._spec_artifacts()
        if spec_artifacts and not self.can_enter_plan_generation:
            targets.append(
                ReviewTarget(
                    kind="spec_review",
                    run_id=self.engine.root_run.run_id,
                    artifact_refs=tuple(spec_artifacts),
                )
            )

        pending_bundle = self._pending_bundle()
        if pending_bundle is not None:
            targets.append(
                ReviewTarget(
                    kind="execution_bundle",
                    run_id=pending_bundle.run_id,
                    artifact_refs=tuple(pending_bundle.artifact_refs),
                    bundle_id=pending_bundle.bundle_id,
                    bundle_version=pending_bundle.bundle_version,
                )
            )

        targets.extend(
            ReviewTarget(kind="recovery", run_id=blocked_run.run_id)
            for blocked_run in self._recovery_candidates()
        )
        return tuple(targets)

    def diff_current_target(self) -> ReviewDiffResult:
        """Render a unified diff for the selected review target."""
        target = self.current_target()
        return self.diff_target(target)

    def diff_target(self, target: ReviewTarget | None) -> ReviewDiffResult:
        """Render a unified diff for the provided review target."""
        if target is None:
            return ReviewDiffResult(title="No review target", entries=(), rendered_text="Nothing to review.")

        if target.kind == "recovery":
            actions = "\n".join(self.recovery_actions(target.run_id)) or "No recovery actions available."
            return ReviewDiffResult(
                title="Recovery actions",
                entries=(),
                rendered_text=f"Recovery actions for {target.run_id}\n\n{actions}",
            )

        baseline_approval = self._baseline_approval(target.kind, target.bundle_version)
        diff_entries = tuple(
            ReviewDiffEntry(
                artifact_path=artifact_ref.artifact_path,
                diff_text=self._artifact_diff_text(
                    artifact_ref=artifact_ref,
                    baseline_approval=baseline_approval,
                ),
            )
            for artifact_ref in target.artifact_refs
        )
        title = "Spec review diff" if target.kind == "spec_review" else "Execution bundle diff"
        rendered_entries = "\n\n".join(
            f"{entry.artifact_path}\n{entry.diff_text}" for entry in diff_entries
        )
        return ReviewDiffResult(
            title=title,
            entries=diff_entries,
            rendered_text=f"{title}\n\n{rendered_entries}".strip(),
        )

    def approve_current_target(self, *, approver: str) -> ApprovalRecord:
        """Persist approval for the current review target."""
        target = self.current_target()
        return self.approve_target(target, approver=approver)

    def approve_target(self, target: ReviewTarget | None, *, approver: str) -> ApprovalRecord:
        """Persist approval for the provided review target."""
        if target is None:
            raise RuntimeError("no review target is pending")
        if target.kind == "recovery":
            raise RuntimeError("recovery targets cannot be approved")

        if target.kind == "spec_review":
            approval = persist_approval(
                self.repo_root,
                create_spec_review(
                    approval_id=f"approval-spec-{self._next_approval_number('spec_review')}",
                    run_id=self.engine.root_run.run_id,
                    approver=approver,
                    spec_artifacts=list(target.artifact_refs),
                    bundle_version=self._next_approval_number("spec_review"),
                    scope_hash=compute_scope_hash_for_artifacts(self.repo_root, list(target.artifact_refs)),
                ),
            )
            self._approvals().append(approval)
            self.engine.can_enter_plan_stage()
            return approval

        bundle = self._bundle_for_target(target)
        if bundle is None:
            raise RuntimeError("no execution bundle is waiting for approval")
        approved_bundle = transition_bundle_state(
            self.repo_root,
            bundle=bundle,
            next_state="approved",
            stage_id=self._stage_id("execute"),
            source="ui.review",
        )
        self._bundles_by_id()[approved_bundle.bundle_id] = approved_bundle
        approval = persist_approval(
            self.repo_root,
            create_execution_bundle_approval(
                approval_id=f"approval-exec-{approved_bundle.bundle_version}",
                approver=approver,
                bundle=approved_bundle,
            ),
        )
        self._approvals().append(approval)
        self.engine.can_enter_execute_stage()
        return approval

    def recovery_actions(self, run_id: str) -> tuple[str, ...]:
        """Return the supported recovery actions for a run."""
        run = self.engine.run(run_id)
        if run.status in {"session_lost", "recovery_blocked"}:
            return ("/resume", "/restart")
        if run.status in {"blocked", "failed"}:
            return ("/retry", "/replace")
        return ()

    def apply_recovery_action(
        self,
        run_id: str,
        action: Literal["resume", "retry", "restart", "replace"],
    ) -> Run | ResumeResult:
        """Execute a supported recovery action for a blocked run."""
        if self.recovery_service is None:
            raise RuntimeError("recovery service is not configured")

        if action == "resume":
            return self.recovery_service.resume(run_id=run_id, mode="read")
        if action == "retry":
            return self.recovery_service.retry_run(run_id)
        if action == "restart":
            return self.recovery_service.restart_run(run_id)
        if action == "replace":
            return self.recovery_service.replace_run(run_id)
        raise ValueError(f"unsupported recovery action: {action}")

    def record_feedback(
        self,
        target: ReviewTarget | None,
        *,
        reviewer: str,
        feedback: str,
    ) -> Path:
        """Persist review feedback without approving the target."""
        if target is None:
            raise RuntimeError("no review target is pending")
        note = feedback.strip()
        if not note:
            raise RuntimeError("feedback is required")

        feedback_path = self._feedback_path(target)
        feedback_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [
            self._feedback_title(target),
            "",
            f"Reviewer: {reviewer}",
            f"Run: {target.run_id}",
        ]
        if target.bundle_id is not None:
            lines.append(f"Bundle: {target.bundle_id} (v{target.bundle_version})")
        lines.extend(("", note, ""))
        feedback_path.write_text("\n".join(lines), encoding="utf-8")
        return feedback_path

    def summary_text(self) -> str:
        """Return the review screen summary text."""
        target = self.current_target()
        if target is None:
            return "Review queue is clear."
        if target.kind == "spec_review":
            return self.diff_current_target().rendered_text
        if target.kind == "execution_bundle":
            return f"Execution bundle review\n\n{self.diff_current_target().rendered_text}"

        actions = "\n".join(self.recovery_actions(target.run_id)) or "No actions available."
        return f"Recovery review\n\nRun: {target.run_id}\nActions:\n{actions}"

    def _spec_artifacts(self) -> list[ArtifactRef]:
        return [
            artifact_ref
            for artifact_ref in self.engine.root_run.artifact_refs
            if artifact_ref.artifact_kind == "spec"
        ]

    def _pending_bundle(self) -> ExecutionBundle | None:
        pending = [
            bundle
            for bundle in self._bundles_by_id().values()
            if bundle.state in _PENDING_BUNDLE_STATES
        ]
        if not pending:
            return None
        return max(pending, key=lambda bundle: (bundle.bundle_version, bundle.bundle_id))

    def _baseline_approval(
        self,
        kind: Literal["spec_review", "execution_bundle"],
        pending_bundle_version: int | None,
    ) -> ApprovalRecord | None:
        approvals = [
            approval
            for approval in self._approvals()
            if approval.approval_kind == kind
        ]
        if kind == "execution_bundle" and pending_bundle_version is not None:
            approvals = [
                approval
                for approval in approvals
                if approval.bundle_version is not None and approval.bundle_version < pending_bundle_version
            ]
        if not approvals:
            return None
        return max(
            approvals,
            key=lambda approval: (
                approval.bundle_version or 0,
                approval.approved_at,
                approval.approval_id,
            ),
        )

    def _artifact_diff_text(
        self,
        *,
        artifact_ref: ArtifactRef,
        baseline_approval: ApprovalRecord | None,
    ) -> str:
        current_path = self.repo_root / artifact_ref.artifact_path
        baseline_path = self._snapshot_path(baseline_approval, artifact_ref.artifact_path)
        current_label, current_text, current_missing = self._diff_source(
            current_path,
            default_label=artifact_ref.artifact_path,
            missing_suffix="missing from workspace",
        )
        baseline_label, baseline_text, baseline_missing = self._diff_source(
            baseline_path,
            default_label=str(baseline_path.relative_to(self.repo_root)) if baseline_path is not None else "empty",
            missing_suffix="missing baseline snapshot",
        )
        diff_lines = difflib.unified_diff(
            baseline_text.splitlines(),
            current_text.splitlines(),
            fromfile=baseline_label,
            tofile=current_label,
            lineterm="",
        )
        rendered = "\n".join(diff_lines)
        if rendered:
            return rendered

        missing_notes: list[str] = []
        if baseline_missing:
            missing_notes.append("baseline snapshot missing")
        if current_missing:
            missing_notes.append("current artifact missing from workspace")
        if missing_notes:
            return f"(no textual diff; {'; '.join(missing_notes)})"
        return "(no content changes)"

    def _snapshot_path(self, approval: ApprovalRecord | None, artifact_path: str) -> Path | None:
        if approval is None:
            return None
        candidate = approval_snapshot_dir(self.repo_root, approval.approval_id) / artifact_path
        if not candidate.exists():
            return None
        return candidate

    def _recovery_candidates(self) -> tuple[Run, ...]:
        superseded_run_ids = {
            run.supersedes_run_id
            for run in self.engine.runs()
            if run.supersedes_run_id is not None
        }
        return tuple(
            sorted(
                (
                    run
                    for run in self.engine.runs()
                    if run.run_id != self.engine.root_run.run_id and run.status in _RECOVERY_RUN_STATUSES
                    and run.run_id not in superseded_run_ids
                ),
                key=lambda run: run.run_id,
            )
        )

    def _bundle_for_target(self, target: ReviewTarget) -> ExecutionBundle | None:
        if target.bundle_id is None:
            return None
        return self._bundles_by_id().get(target.bundle_id)

    def _next_approval_number(self, kind: Literal["spec_review", "execution_bundle"]) -> int:
        bundle_versions = [
            approval.bundle_version or 0
            for approval in self._approvals()
            if approval.approval_kind == kind
        ]
        return max(bundle_versions, default=0) + 1

    def _stage_id(self, stage_kind: StageKind) -> str:
        try:
            return self.engine.stage(stage_kind).stage_id
        except Exception:
            return f"stage-{stage_kind}"

    def _approvals(self) -> list[ApprovalRecord]:
        return cast(list[ApprovalRecord], getattr(self.engine, "_approvals"))

    def _bundles_by_id(self) -> dict[str, ExecutionBundle]:
        return cast(dict[str, ExecutionBundle], getattr(self.engine, "_bundles_by_id"))

    @staticmethod
    def _feedback_title(target: ReviewTarget) -> str:
        if target.kind == "spec_review":
            return "Spec review target"
        if target.kind == "execution_bundle":
            return "Execution bundle target"
        return "Recovery target"

    def _feedback_path(self, target: ReviewTarget) -> Path:
        target_id = target.bundle_id if target.kind == "execution_bundle" and target.bundle_id is not None else target.run_id
        return self.repo_root / ".ralphception" / "reviews" / f"{target.kind}-{target_id}.md"

    @staticmethod
    def _diff_source(
        path: Path | None,
        *,
        default_label: str,
        missing_suffix: str,
    ) -> tuple[str, str, bool]:
        if path is None:
            return default_label, "", False
        try:
            return default_label, ArtifactReviewController._read_text(path), False
        except FileNotFoundError:
            return f"{default_label} ({missing_suffix})", "", True

    @staticmethod
    def _read_text(path: Path) -> str:
        if path.suffix == ".json":
            return json.dumps(
                json.loads(path.read_text(encoding="utf-8")),
                indent=2,
                sort_keys=True,
            )
        return path.read_text(encoding="utf-8")


__all__ = [
    "ArtifactReviewController",
    "ReviewDiffResult",
    "ReviewTarget",
]
