"""Heuristic active-session message classification."""

from __future__ import annotations

import re
from enum import StrEnum

from ralphception.runtime.prompt_state import TaskMessageClassification

_AMBIGUOUS_MARKERS = (
    "other thing",
    "that other",
    "something else",
    "do that too",
    "do the other",
    "maybe",
    "whatever",
)
_REVISION_MARKERS = (
    "change scope",
    "scope to",
    "revise",
    "narrow",
    "broaden",
    "limit it",
    "just ",
    "only",
    "instead of",
    "make it",
)
_FOLLOW_UP_MARKERS = (
    "also",
    "also check",
    "add ",
    "and check",
    "while you're at it",
    "in addition",
    "check ",
)
_NEW_TASK_MARKERS = (
    "new task",
    "different task",
    "another task",
    "switch to",
    "start a new",
    "replace this",
    "stop this",
    "instead",
)


class MessageKind(StrEnum):
    blocker_reply = "blocker_reply"
    needs_clarification = "needs_clarification"
    task_revision = "task_revision"
    in_task_follow_up = "in_task_follow_up"
    new_task_request = "new_task_request"


def classify_user_message(
    *,
    text: str,
    prompt_pending: bool,
    active_task_summary: str | None = None,
) -> TaskMessageClassification:
    """Classify a user message for the active-session routing contract."""

    normalized_text = _normalize_text(text)
    active_summary = None if active_task_summary is None else _normalize_text(active_task_summary)

    if prompt_pending:
        return _make_classification(
            kind=MessageKind.blocker_reply,
            text=text,
            prompt_pending=True,
            active_task_summary=active_task_summary,
            confidence=0.96,
        )

    if _contains_any(normalized_text, _AMBIGUOUS_MARKERS):
        return _make_classification(
            kind=MessageKind.needs_clarification,
            text=text,
            prompt_pending=False,
            active_task_summary=active_task_summary,
            confidence=0.42,
            clarifying_question=_build_clarifying_question(active_task_summary=active_task_summary, text=text),
        )

    if _contains_any(normalized_text, _REVISION_MARKERS):
        return _make_classification(
            kind=MessageKind.task_revision,
            text=text,
            prompt_pending=False,
            active_task_summary=active_task_summary,
            confidence=0.91,
        )

    if _contains_any(normalized_text, _FOLLOW_UP_MARKERS):
        return _make_classification(
            kind=MessageKind.in_task_follow_up,
            text=text,
            prompt_pending=False,
            active_task_summary=active_task_summary,
            confidence=0.88,
        )

    if _contains_any(normalized_text, _NEW_TASK_MARKERS):
        return _make_classification(
            kind=MessageKind.new_task_request,
            text=text,
            prompt_pending=False,
            active_task_summary=active_task_summary,
            confidence=0.94,
        )

    if active_summary is not None:
        return _make_classification(
            kind=MessageKind.new_task_request,
            text=text,
            prompt_pending=False,
            active_task_summary=active_task_summary,
            confidence=0.71,
        )

    return _make_classification(
        kind=MessageKind.needs_clarification,
        text=text,
        prompt_pending=False,
        active_task_summary=active_task_summary,
        confidence=0.35,
        clarifying_question=_build_clarifying_question(active_task_summary=active_task_summary, text=text),
    )


def _make_classification(
    *,
    kind: MessageKind | str,
    text: str,
    prompt_pending: bool,
    active_task_summary: str | None,
    confidence: float,
    clarifying_question: str | None = None,
) -> TaskMessageClassification:
    return TaskMessageClassification(
        raw_user_text=text,
        kind=kind.value if isinstance(kind, MessageKind) else kind,
        prompt_pending=prompt_pending,
        active_task_summary=active_task_summary,
        confidence=confidence,
        clarifying_question=clarifying_question,
    )


def _contains_any(text: str, markers: tuple[str, ...]) -> bool:
    return any(marker in text for marker in markers)


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _build_clarifying_question(*, active_task_summary: str | None, text: str) -> str:
    if active_task_summary:
        return (
            f"Need clarification: should I revise the current task ({active_task_summary}) "
            f"or treat {text!r} as a new task?"
        )
    return f"Need clarification: what should I do with {text!r}?"


__all__ = [
    "MessageKind",
    "classify_user_message",
]
