"""Plan graph models and loop planning helpers."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from ralphception.models.artifacts import DurableModel

MergeStrategy = Literal["proposal_first", "direct_update"]


class PlanNode(DurableModel):
    """A durable node in the task plan graph."""

    plan_node_id: str
    title: str
    objective: str
    target_artifacts: tuple[str, ...] = ()
    stop_conditions: tuple[str, ...] = ()
    output_contract: tuple[str, ...] = ()
    parent_plan_node_id: str | None = None
    child_plan_node_ids: tuple[str, ...] = ()
    merge_strategy: MergeStrategy = "proposal_first"


class PlanGraph(DurableModel):
    """Durable plan graph for a task."""

    task_id: str
    plan_id: str
    nodes: tuple[PlanNode, ...]
    root_plan_node_id: str | None = None


class SubplanGraph(DurableModel):
    """A nested plan graph spawned from a parent plan node."""

    task_id: str
    plan_id: str
    plan_node_id: str
    nodes: tuple[PlanNode, ...]
    root_plan_node_id: str | None = None


class LoopDefinition(DurableModel):
    """Concrete loop execution contract derived from a plan node."""

    loop_id: str
    task_id: str
    plan_node_id: str
    parent_loop_id: str | None
    objective: str
    stop_conditions: tuple[str, ...]
    output_contract: tuple[str, ...]
    target_artifacts: tuple[str, ...]
    merge_strategy: MergeStrategy = Field(default="proposal_first")


class SubplanExpansion(DurableModel):
    """The durable result of expanding one broad plan node into a subplan."""

    parent_plan_node_id: str
    subplan: SubplanGraph
    child_loops: tuple[LoopDefinition, ...]


class LoopPlanner:
    """Translate plan nodes into explicit loop definitions."""

    def plan_loops(self, plan: PlanGraph) -> list[LoopDefinition]:
        overlapping_target_artifacts = _overlapping_target_artifacts(plan.nodes)
        loops: list[LoopDefinition] = []
        for node in plan.nodes:
            merge_strategy: MergeStrategy = "proposal_first"
            if not overlapping_target_artifacts.intersection(node.target_artifacts):
                merge_strategy = "direct_update"
            loops.append(
                LoopDefinition(
                    loop_id=f"loop-{node.plan_node_id}",
                    task_id=plan.task_id,
                    plan_node_id=node.plan_node_id,
                    parent_loop_id=None,
                    objective=node.objective,
                    stop_conditions=node.stop_conditions,
                    output_contract=node.output_contract,
                    target_artifacts=node.target_artifacts,
                    merge_strategy=merge_strategy,
                ),
            )
        return loops

    def expand_plan_node_into_subplan(self, plan: PlanGraph, plan_node_id: str) -> SubplanExpansion:
        parent_node = next(node for node in plan.nodes if node.plan_node_id == plan_node_id)
        child_nodes = (
            PlanNode(
                plan_node_id=f"{plan_node_id}-research",
                title=f"{parent_node.title} research",
                objective=f"Research breadth for {parent_node.objective}",
                target_artifacts=parent_node.target_artifacts,
                stop_conditions=(f"{parent_node.title} research is understood",),
                output_contract=(f"publish {plan_node_id} research proposal",),
                parent_plan_node_id=plan_node_id,
            ),
            PlanNode(
                plan_node_id=f"{plan_node_id}-verification",
                title=f"{parent_node.title} verification",
                objective=f"Verify breadth findings for {parent_node.objective}",
                target_artifacts=parent_node.target_artifacts,
                stop_conditions=(f"{parent_node.title} verification is complete",),
                output_contract=(f"publish {plan_node_id} verification proposal",),
                parent_plan_node_id=plan_node_id,
            ),
        )
        subplan = SubplanGraph(
            task_id=plan.task_id,
            plan_id=f"{plan.plan_id}:{plan_node_id}",
            plan_node_id=plan_node_id,
            nodes=child_nodes,
            root_plan_node_id=child_nodes[0].plan_node_id,
        )
        child_loops = tuple(
            loop.model_copy(update={"parent_loop_id": f"loop-{plan_node_id}"})
            for loop in self.plan_loops(
                PlanGraph(
                    task_id=subplan.task_id,
                    plan_id=subplan.plan_id,
                    nodes=subplan.nodes,
                    root_plan_node_id=subplan.root_plan_node_id,
                ),
            )
        )
        return SubplanExpansion(
            parent_plan_node_id=plan_node_id,
            subplan=subplan,
            child_loops=child_loops,
        )


def _overlapping_target_artifacts(nodes: tuple[PlanNode, ...]) -> set[str]:
    counts: dict[str, int] = {}
    for node in nodes:
        for artifact_kind in node.target_artifacts:
            counts[artifact_kind] = counts.get(artifact_kind, 0) + 1
    return {artifact_kind for artifact_kind, count in counts.items() if count > 1}


__all__ = [
    "LoopDefinition",
    "LoopPlanner",
    "MergeStrategy",
    "PlanGraph",
    "PlanNode",
    "SubplanExpansion",
    "SubplanGraph",
]
