"""Codex-style human terminal frontend entrypoints."""

from __future__ import annotations

from pathlib import Path

from ralphception.codex_tui.app import (
    CodexTuiFrontend,
    ScriptedCodexTuiFrontend,
    run_codex_tui_shell,
)
from ralphception.runtime.inline_shell import InlineShellRunResult

TerminalRunResult = InlineShellRunResult


class TerminalFrontend(CodexTuiFrontend):
    """Backwards-compatible terminal frontend wrapper."""

    def __init__(
        self,
        *,
        input_func=input,
        write_func=print,
        default_repo_root: Path | None = None,
        default_session_manager_factory=None,
        tui=None,
    ) -> None:
        del write_func
        super().__init__(
            repo_root=Path.cwd() if default_repo_root is None else default_repo_root,
            input_callback=lambda: input_func(""),
            tui=tui,
            default_session_manager_factory=default_session_manager_factory,
            enable_trust_onboarding=False,
        )


class ScriptedTerminalFrontend(ScriptedCodexTuiFrontend):
    """Deterministic terminal frontend wrapper for tests."""

    def __init__(self, *, inputs=(), repo_root: Path | None = None, tui=None) -> None:
        super().__init__(
            repo_root=Path.cwd() if repo_root is None else repo_root,
            inputs=inputs,
            tui=tui,
            enable_trust_onboarding=False,
        )


def run_terminal(
    *,
    repo_root: Path | None = None,
    seed_prompt: str | None = None,
    source_repos: tuple[str, ...] = (),
    resume: bool = False,
    approve_all: bool = False,
    approver: str = "terminal",
    use_fake_session_manager: bool = False,
    session_manager_factory=None,
    frontend: CodexTuiFrontend | None = None,
) -> TerminalRunResult:
    if frontend is not None:
        frontend.repo_root = Path.cwd() if repo_root is None else repo_root
        if session_manager_factory is not None:
            frontend.default_session_manager_factory = session_manager_factory
    return run_codex_tui_shell(
        repo_root=repo_root,
        seed_prompt=seed_prompt,
        source_repos=source_repos,
        resume=resume,
        approve_all=approve_all,
        approver=approver,
        use_fake_session_manager=use_fake_session_manager,
        session_manager_factory=session_manager_factory,
        frontend=frontend,
    )


__all__ = [
    "ScriptedTerminalFrontend",
    "TerminalFrontend",
    "TerminalRunResult",
    "run_terminal",
]
