"""Helpers for bundled-skill-driven startup intake resolution."""

from __future__ import annotations

import json
from pathlib import Path
import re
from typing import Literal

from pydantic import model_validator

from ralphception.models.artifacts import DurableModel
from ralphception.runtime.bootstrap import assess_intake_answers
from ralphception.skills.prompting import (
    BUNDLED_SKILL_DISCLOSURE_RULE,
    load_bundled_skill_guidance,
)

STARTUP_DECISION_BEGIN = "RALPH_STARTUP_DECISION_START"
STARTUP_DECISION_END = "RALPH_STARTUP_DECISION_END"
_DECISION_RE = re.compile(
    rf"{STARTUP_DECISION_BEGIN}\s*(\{{.*?\}})\s*{STARTUP_DECISION_END}",
    re.DOTALL,
)
_REDUNDANT_STARTUP_QUESTION_RE = re.compile(
    r"which\s+(?:files?(?:\s+or\s+areas?)?|directories?|areas?)\s+(should|do)\s+i\s+(treat\s+as\s+)?in\s+scope"
    r"|what\s+scope\s+should\s+i\s+use"
    r"|scope,\s*constraints?,\s*or\s*success\s*criteria"
    r"|default\s+repo-wide\s+scope",
    re.IGNORECASE,
)


class StartupTurnDecision(DurableModel):
    kind: Literal["clarify", "resolved"]
    question: str | None = None
    intake_summary: str | None = None

    @model_validator(mode="after")
    def _validate_shape(self) -> "StartupTurnDecision":
        if self.kind == "clarify":
            if not self.question or self.intake_summary is not None:
                raise ValueError("clarify decisions require question and forbid intake_summary")
        else:
            if not self.intake_summary or self.question is not None:
                raise ValueError("resolved decisions require intake_summary and forbid question")
        return self


def build_startup_resolution_prompt(
    *,
    repo_root: Path,
    repo_root_label: str,
    prior_answers: tuple[str, ...],
    latest_user_text: str,
    source_repos: tuple[str, ...],
) -> str:
    prior_answer_lines = "\n".join(f"- {answer}" for answer in prior_answers) or "- none yet"
    source_repo_lines = "\n".join(f"- {repo}" for repo in source_repos) or "- none"
    first_turn_rule = (
        "This is the first human startup turn after the user's initial task message.\n"
        "Ask exactly one Socratic follow-up question on this turn.\n"
        "Do not return `resolved` yet.\n\n"
        if not prior_answers
        else ""
    )
    bundled_guidance = load_bundled_skill_guidance(repo_root=repo_root, skill_id="brainstorm.default")
    return (
        f"{bundled_guidance}\n\n"
        f"{BUNDLED_SKILL_DISCLOSURE_RULE}\n\n"
        "You are handling Ralphception startup intake for the current repository task.\n"
        "This startup stage is a compressed brainstorming loop, not a single permission check.\n"
        "Assume full read/write access to the entire repository by default.\n"
        "Assume referenced outside folders supplied with the task are also in scope by default.\n"
        "Do not ask the user for permission to inspect files in the repository.\n"
        "Do not ask the user to confirm repo-wide scope unless they explicitly narrowed it or there is a concrete risk boundary.\n"
        "Do not resolve startup intake after a single weak follow-up like `no`, `none`, `whatever`, or another generic approval.\n"
        "Keep asking the next highest-leverage Socratic question until you have enough detail for a real PRD and execution plan.\n"
        "In human interactive mode, gather at least two distinct follow-up answers before resolving unless the initial task message already contains unusually specific scope, constraints, success criteria, and boundaries.\n"
        "If one answer only settles a single dimension, ask the next missing dimension instead of resolving.\n"
        "Vary the dimensions across questions when possible: scope surface, definition of done, cleanup aggressiveness, hard constraints, risk boundaries, or review expectations.\n"
        f"Repository root: {repo_root_label}\n\n"
        f"{first_turn_rule}"
        "Intake answers so far:\n"
        f"{prior_answer_lines}\n\n"
        "Optional source repositories:\n"
        f"{source_repo_lines}\n\n"
        "Latest user message:\n"
        f"- {latest_user_text.strip()}\n\n"
        "Decide whether to ask one more Socratic question or declare intake sufficient.\n"
        "Keep the question short, concrete, and repo-task-shaped.\n"
        "Return only one JSON object between the required markers.\n"
        f"{STARTUP_DECISION_BEGIN}\n"
        '{"kind":"clarify","question":"..."}\n'
        "or\n"
        '{"kind":"resolved","intake_summary":"..."}\n'
        f"{STARTUP_DECISION_END}\n"
    )


def parse_startup_resolution(text: str) -> StartupTurnDecision | None:
    match = _DECISION_RE.search(text)
    if match is None:
        return None
    try:
        payload = json.loads(match.group(1))
    except json.JSONDecodeError:
        return None
    try:
        return StartupTurnDecision.model_validate(payload)
    except Exception:
        return None


def normalize_startup_clarifying_question(
    *,
    question: str,
    latest_user_text: str,
    prior_answers: tuple[str, ...] = (),
) -> str:
    cleaned = " ".join(question.split()).strip()
    fallback_question = assess_intake_answers(*prior_answers, latest_user_text).next_question
    if not cleaned:
        return fallback_question
    if _REDUNDANT_STARTUP_QUESTION_RE.search(cleaned):
        return fallback_question
    return cleaned


__all__ = [
    "STARTUP_DECISION_BEGIN",
    "STARTUP_DECISION_END",
    "StartupTurnDecision",
    "build_startup_resolution_prompt",
    "normalize_startup_clarifying_question",
    "parse_startup_resolution",
]
