"""Shared runtime mode resolution and orchestration entrypoints."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, cast
import uuid

from pydantic import ValidationError

from ralphception.codex.client import codex_cli_available
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import RalphceptionConfig, load_or_create_config as load_repo_config
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle, Run, RunStageStatus, Stage
from ralphception.runtime.frontends import (
    BlockerPromptEvent,
    CurrentBlockerStateEvent,
    FrontendEvent,
    RequestUserInputRequestedEvent,
    ReviewDecision,
    ReviewRequestedEvent,
    ReviewKind,
    RuntimeStep,
)
from ralphception.runtime.interactive_session import (
    InteractiveSessionState,
    InteractiveSessionMarker,
    clear_interactive_session_marker,
    load_interactive_session_marker,
    load_interactive_session_state,
    resolve_interactive_launch_state,
    write_interactive_session_marker,
    write_interactive_session_state,
)
from ralphception.runtime.prompt_resolution import PromptResolutionResult, resolve_prompt_reply
from ralphception.runtime.prompt_state import (
    BlockedContinuationRef,
    DeferredInput,
    PendingPrompt,
    PromptResolution,
    STARTUP_INTAKE_ANSWERS_KEY,
    MessageClassification,
)
from ralphception.runtime.task_classifier import MessageKind, classify_user_message
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic
from ralphception.runtime.reviews import ArtifactReviewController
from ralphception.runtime.bootstrap import (
    StartupBootstrapController,
    assess_intake_answers,
    bootstrap_from_intake,
    compose_intake_summary,
    load_startup_record,
    primary_intake_goal,
)
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import RecoveryService, ResumeResult

_RUNTIME_STAGE_ORDER = (
    ("intake", "completed"),
    ("spec", "completed"),
    ("plan", "pending"),
    ("execute", "pending"),
    ("merge", "pending"),
    ("audit", "pending"),
)
_UNSET_SESSION_MANAGER = object()


class RuntimePromptConflictError(RuntimeError):
    """Raised when a requested seed prompt conflicts with an existing root mission."""

    def __init__(
        self,
        *,
        repo_root: Path,
        existing_seed_prompt: str,
        requested_seed_prompt: str,
        run_id: str = "run-root",
        run_status: str | None = None,
        current_stage: str | None = None,
    ) -> None:
        self.repo_root = repo_root
        self.existing_seed_prompt = existing_seed_prompt
        self.requested_seed_prompt = requested_seed_prompt
        self.run_id = run_id
        self.run_status = run_status
        self.current_stage = current_stage
        super().__init__(str(self))

    def __str__(self) -> str:
        details: list[str] = []
        if self.run_status is not None:
            details.append(f"status={self.run_status}")
        if self.current_stage is not None:
            details.append(f"stage={self.current_stage}")
        suffix = f" ({', '.join(details)})" if details else ""
        return (
            f"Workspace {self.repo_root} already has active root session {self.run_id}{suffix} with seed prompt "
            f"{self.existing_seed_prompt!r}; refusing to ignore requested seed prompt "
            f"{self.requested_seed_prompt!r}. Reopen Ralphception to resume the existing session or clear/reset "
            "the Ralphception workspace state before starting a new session."
        )


class RuntimeLaunchAbortedError(RuntimeError):
    """Raised when the user aborts launch during conflict resolution."""


class RuntimeResumeRequiredError(RuntimeError):
    """Raised when a workspace already has a mission and the user did not opt into resume."""

    def __init__(
        self,
        *,
        repo_root: Path,
        run_id: str,
        seed_prompt: str,
        run_status: str | None = None,
        current_stage: str | None = None,
    ) -> None:
        self.repo_root = repo_root
        self.run_id = run_id
        self.seed_prompt = seed_prompt
        self.run_status = run_status
        self.current_stage = current_stage
        super().__init__(str(self))

    def __str__(self) -> str:
        details: list[str] = []
        if self.run_status is not None:
            details.append(f"status={self.run_status}")
        if self.current_stage is not None:
            details.append(f"stage={self.current_stage}")
        suffix = f" ({', '.join(details)})" if details else ""
        return (
            f"Workspace {self.repo_root} already has session {self.run_id}{suffix} for seed prompt "
            f"{self.seed_prompt!r}. Reopen Ralphception to resume it, or clear/reset the Ralphception "
            "workspace state before starting a new session."
        )


class RuntimeResumeUnavailableError(RuntimeError):
    """Raised when resume was requested but there is no resumable mission in the workspace."""

    def __init__(self, *, repo_root: Path) -> None:
        self.repo_root = repo_root
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Workspace {self.repo_root} has no existing session to resume. "
            "Start a new session with --seed-prompt instead."
        )


class RuntimeBackendUnavailableError(RuntimeError):
    """Raised when terminal execution is requested without any usable backend."""

    def __init__(self) -> None:
        super().__init__(
            "No Codex session backend is available for terminal execution. "
            "Install/configure the backend or use --fake-session-manager for deterministic local verification.",
        )


@dataclass(frozen=True, slots=True)
class ExistingRootMission:
    run_id: str
    seed_prompt: str
    run_status: str | None
    current_stage: str | None
    terminal_outcome: str | None

    @property
    def is_completed(self) -> bool:
        return self.terminal_outcome == "completed" or self.run_status == "completed"

    @property
    def is_failed(self) -> bool:
        return self.terminal_outcome == "failed" or self.run_status == "failed"

    @property
    def is_terminal(self) -> bool:
        return self.is_completed or self.is_failed


class RuntimeSupervisor:
    """Resolve the current shared runtime state for a workspace."""

    def __init__(
        self,
        *,
        repo_root: Path,
        seed_prompt: str | None = None,
        source_repos: tuple[str, ...] = (),
        approve_all: bool = False,
        approver: str = "terminal",
        session_manager_factory=None,
    ) -> None:
        self.primary_repo_root = bootstrap_workspace(repo_root)
        self.repo_root = _resolve_authoritative_repo_root(self.primary_repo_root)
        self.seed_prompt = seed_prompt
        self.source_repos = source_repos
        self.approve_all = approve_all
        self.approver = approver
        self._session_manager_factory = session_manager_factory
        self.config = _load_or_create_config(self.repo_root)
        self._launch_resume_requested = False
        self._auto_approve_startup_reviews = False
        self._session_manager: object = _UNSET_SESSION_MANAGER

    def step(self) -> RuntimeStep:
        self._cleanup_terminal_residue(frontend=None)
        self._reconcile_failed_runtime_state()
        startup_controller = StartupBootstrapController(self.repo_root)
        prompt_state = _load_prompt_state(self.repo_root)
        while prompt_state.pending_prompts:
            prompt = prompt_state.pending_prompts[0]
            if prompt.prompt_kind == "startup_prompt":
                if startup_controller.needs_bootstrap():
                    return RuntimeStep(
                        kind="startup_prompt",
                        pending_prompt=prompt,
                    )
                prompt_state.pending_prompts.pop(0)
                write_interactive_session_state(self.repo_root, prompt_state)
                continue
            review_kind = _review_kind_for_prompt(prompt)
            if review_kind is not None:
                engine = self.build_engine()
                review_controller = self.build_review_controller(engine=engine)
                target = review_controller.current_target()
                if target is not None and target.run_id == prompt.owner_run_id and (
                    (review_kind == "recovery" and target.kind == "recovery") or target.kind == review_kind
                ):
                    return RuntimeStep(
                        kind="review_prompt",
                        pending_prompt=prompt,
                        engine=engine,
                    )
                prompt_state.pending_prompts.pop(0)
                write_interactive_session_state(self.repo_root, prompt_state)
                continue
            if prompt.prompt_kind == "launch_conflict":
                mission = self._load_existing_root_mission()
                if mission is not None and not mission.is_completed:
                    return RuntimeStep(
                        kind="startup_prompt",
                        pending_prompt=prompt,
                    )
                prompt_state.pending_prompts.pop(0)
                write_interactive_session_state(self.repo_root, prompt_state)
                continue
            return RuntimeStep(
                kind="startup_prompt",
                pending_prompt=prompt,
            )
        if startup_controller.needs_bootstrap():
            return RuntimeStep(
                kind="startup_prompt",
                pending_prompt=_startup_pending_prompt(self.repo_root, source_repos=self.source_repos),
            )

        engine = self.build_engine()
        review_controller = self.build_review_controller(engine=engine)
        target = review_controller.current_target()
        if target is not None:
            return RuntimeStep(
                kind="review_prompt",
                pending_prompt=_review_pending_prompt(
                    review_kind=target.kind,
                    run_id=target.run_id,
                    summary_text=review_controller.summary_text(),
                    recommended_actions=review_controller.recovery_actions(target.run_id)
                    if target.kind == "recovery"
                    else ("approve",),
                ),
                engine=engine,
            )

        return RuntimeStep(kind="dashboard", engine=engine)

    def build_engine(self) -> WorkflowEngine:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            raise RuntimeError("workspace bootstrap state is missing")

        spec_artifacts = _discover_artifacts(self.repo_root / ".ralphception" / "specs", artifact_kind="spec")
        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        if root_run_path.exists():
            root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
            if spec_artifacts and not any(ref.artifact_kind == "spec" for ref in root_run.artifact_refs):
                root_run = root_run.model_copy(update={"artifact_refs": [*root_run.artifact_refs, *spec_artifacts]})
        else:
            root_run = Run(
                run_id=startup_record.outer_run_id,
                parent_run_id=None,
                supersedes_run_id=None,
                goal=startup_record.seed_prompt,
                status="pending",
                stage_ids=[f"stage-{stage_kind}" for stage_kind, _ in _RUNTIME_STAGE_ORDER],
                config_snapshot={
                    "codex": {"model": self.config.codex.model},
                    "source_repos": startup_record.source_repos,
                },
                codex_session_ref=None,
                artifact_refs=spec_artifacts or [startup_record.intake_artifact],
                created_at=startup_record.created_at,
                updated_at=startup_record.created_at,
            )
        headless_state = _load_headless_state(self.repo_root, root_run.run_id)
        raw_completed_stages = headless_state.get("completed_stages", [])
        completed_stages = (
            set(cast(list[str], raw_completed_stages))
            if isinstance(raw_completed_stages, list)
            else set()
        )
        current_stage = headless_state.get("current_stage")
        stages = [
            Stage(
                stage_id=f"stage-{stage_kind}",
                run_id=root_run.run_id,
                stage_kind=stage_kind,
                status=resolved_status,
                task_ids=[],
                started_at=startup_record.created_at
                if resolved_status in {"completed", "running"}
                else None,
                completed_at=startup_record.created_at
                if resolved_status == "completed"
                else None,
            )
            for stage_kind, status in _RUNTIME_STAGE_ORDER
            for resolved_status in [
                _stage_status_for_kind(
                    stage_kind=stage_kind,
                    default_status=cast(RunStageStatus, status if stage_kind != "spec" or spec_artifacts else "pending"),
                    completed_stages=completed_stages,
                    current_stage=current_stage,
                )
            ]
        ]
        return WorkflowEngine(
            repo_root=self.repo_root,
            root_run=root_run,
            stages=stages,
            child_runs=_load_child_runs(self.repo_root, root_run.run_id),
            bundles=_load_bundles(self.repo_root, root_run.run_id),
            approvals=_load_approvals(self.repo_root),
            session_manager=self._get_session_manager(),
        )

    def build_recovery_service(self, *, engine: WorkflowEngine | None = None) -> RecoveryService:
        return RecoveryService(
            engine=self.build_engine() if engine is None else engine,
            process_id=os.getpid(),
        )

    def build_review_controller(self, *, engine: WorkflowEngine | None = None) -> ArtifactReviewController:
        resolved_engine = self.build_engine() if engine is None else engine
        return ArtifactReviewController(
            repo_root=self.repo_root,
            engine=resolved_engine,
            recovery_service=self.build_recovery_service(engine=resolved_engine),
        )

    def apply_review_decision(
        self,
        decision: ReviewDecision,
        *,
        engine: WorkflowEngine | None = None,
    ) -> None:
        controller = self.build_review_controller(engine=engine)
        target = controller.current_target()
        if target is None:
            raise RuntimeError("no review target is pending")
        if decision.action == "pause":
            return

        if target.kind == "recovery":
            if decision.action not in {"resume", "retry", "restart", "replace"}:
                raise RuntimeError(f"unsupported recovery action: {decision.action}")
            outcome = controller.apply_recovery_action(
                target.run_id,
                cast(Literal["resume", "retry", "restart", "replace"], decision.action),
            )
            if isinstance(outcome, Run):
                self._sync_headless_state_after_recovery(run=outcome)
            elif isinstance(outcome, ResumeResult):
                self._clear_headless_terminal_outcome(run_id=outcome.run_id)
            return

        if decision.action != "approve":
            raise RuntimeError(f"unsupported review action for {target.kind}: {decision.action}")
        controller.approve_target(target, approver=decision.approver or "terminal")

    def resolve_pending_prompt(
        self,
        *,
        thread_id: str,
        user_text: str,
    ) -> PromptResolutionResult:
        state = _load_prompt_state(self.repo_root)
        prompt = self._pending_prompt_for_thread(state, thread_id=thread_id)
        normalized_reply = user_text.strip().lower()
        if prompt.prompt_kind == "startup_prompt":
            prompt_for_resolution = prompt.model_copy(
                update={
                    "context": {
                        **prompt.context,
                        "source_repos": list(state.bootstrap_source_repos),
                    },
                }
            )
            result = resolve_prompt_reply(
                prompt_for_resolution,
                user_text,
                session_manager=cast(CodexSessionManager | None, self._get_session_manager()),
            )
            if result.kind != "resolved" or result.action is None:
                updated_prompt = prompt
                if result.kind == "clarify":
                    intake_answers = _as_context_str_list(prompt.context, STARTUP_INTAKE_ANSWERS_KEY)
                    normalized_reply = user_text.strip()
                    if normalized_reply:
                        intake_answers.append(normalized_reply)
                    updated_prompt = prompt.model_copy(
                        update={
                            "question": result.clarifying_question or prompt.question,
                            "context": {
                                **prompt.context,
                                STARTUP_INTAKE_ANSWERS_KEY: intake_answers,
                            },
                        }
                    )
                state.pending_prompts = [
                    updated_prompt if pending.prompt_id == prompt.prompt_id else pending
                    for pending in state.pending_prompts
                ]
                if not state.root_thread_id:
                    state.root_thread_id = prompt.thread_id
                state.active_thread_id = prompt.thread_id
                write_interactive_session_state(self.repo_root, state)
                return result
            intake_answers = [
                *_as_context_str_list(prompt.context, STARTUP_INTAKE_ANSWERS_KEY),
                user_text.strip(),
            ]
            state.prompt_resolutions.append(
                PromptResolution(
                    thread_id=prompt.thread_id,
                    owner_run_id=prompt.owner_run_id,
                    prompt_id=prompt.prompt_id,
                    action="bootstrap",
                    raw_user_reply=user_text,
                    confidence=result.confidence,
                )
            )
            state.pending_prompts = [pending for pending in state.pending_prompts if pending.prompt_id != prompt.prompt_id]
            if not state.root_thread_id:
                state.root_thread_id = prompt.thread_id
            state.active_thread_id = prompt.thread_id
            write_interactive_session_state(self.repo_root, state)
            if result.intake_summary is not None:
                self._bootstrap_from_intake_summary(
                    result.intake_summary,
                    source_repos=tuple(state.bootstrap_source_repos),
                    thread_id=prompt.thread_id,
                )
            else:
                self._bootstrap_from_intake_answers(
                    intake_answers,
                    source_repos=tuple(state.bootstrap_source_repos),
                    thread_id=prompt.thread_id,
                )
            return PromptResolutionResult(
                kind="resolved",
                action="bootstrap",
                intake_summary=result.intake_summary,
                confidence=result.confidence,
            )
        if prompt.prompt_kind == "watchdog_question":
            if not user_text.strip():
                return PromptResolutionResult(
                    kind="clarify",
                    clarifying_question=prompt.question,
                    confidence=0.2,
                )
            state.prompt_resolutions.append(
                PromptResolution(
                    thread_id=prompt.thread_id,
                    owner_run_id=prompt.owner_run_id,
                    prompt_id=prompt.prompt_id,
                    action="continue_root_turn",
                    raw_user_reply=user_text,
                    confidence=0.95,
                )
            )
            state.pending_prompts = [pending for pending in state.pending_prompts if pending.prompt_id != prompt.prompt_id]
            state.active_thread_id = prompt.thread_id
            state.updated_at = datetime.now(timezone.utc)
            write_interactive_session_state(self.repo_root, state)
            return PromptResolutionResult(
                kind="resolved",
                action="continue_root_turn",
                confidence=0.95,
            )
        if prompt.prompt_kind == "recovery_review" and normalized_reply in {"pause", "/pause"}:
            return PromptResolutionResult(kind="resolved", action="pause", confidence=0.95)
        if prompt.prompt_kind == "recovery_review" and normalized_reply in {"abort", "/abort", "cancel", "stop"}:
            result = PromptResolutionResult(kind="resolved", action="abort", confidence=0.95)
        else:
            result = resolve_prompt_reply(prompt, user_text, session_manager=None)
        if result.kind != "resolved" or result.action is None:
            return result

        state.prompt_resolutions.append(
            PromptResolution(
                thread_id=prompt.thread_id,
                owner_run_id=prompt.owner_run_id,
                prompt_id=prompt.prompt_id,
                action=result.action,
                raw_user_reply=user_text,
                confidence=result.confidence,
            )
        )
        state.pending_prompts = [pending for pending in state.pending_prompts if pending.prompt_id != prompt.prompt_id]
        if not state.root_thread_id:
            state.root_thread_id = prompt.blocked_continuation.thread_id if prompt.blocked_continuation is not None else prompt.thread_id
        state.active_thread_id = prompt.thread_id
        write_interactive_session_state(self.repo_root, state)
        self._resume_prompt_continuation(prompt, result)
        return result

    def _bootstrap_from_intake_answers(
        self,
        intake_answers: list[str] | tuple[str, ...],
        *,
        source_repos: tuple[str, ...],
        thread_id: str = "run-root",
    ) -> None:
        intake_summary = compose_intake_summary(*intake_answers)
        self._bootstrap_from_intake_summary(
            intake_summary,
            source_repos=source_repos,
            thread_id=thread_id,
        )

    def _bootstrap_from_intake_summary(
        self,
        intake_summary: str,
        *,
        source_repos: tuple[str, ...],
        thread_id: str = "run-root",
    ) -> None:
        self.seed_prompt = intake_summary
        self.source_repos = source_repos
        self._launch_resume_requested = True
        self._auto_approve_startup_reviews = True
        bootstrap_from_intake(
            self.repo_root,
            task_id="task-root",
            intake_summary=intake_summary,
            source_repos=source_repos,
        )
        state = _load_prompt_state(self.repo_root)
        if not state.root_thread_id:
            state.root_thread_id = thread_id
        state.active_thread_id = thread_id
        state.active_task_id = "task-root"
        state.active_task_summary = intake_summary
        state.session_id = "run-root"
        state.bootstrap_source_repos = list(source_repos)
        write_interactive_session_state(self.repo_root, state)
        self.seed_prompt = None
        self.source_repos = ()

    def run(self, *, frontend=None):
        self._cleanup_terminal_residue(frontend=frontend)
        launch_block = self._launch_blocker(frontend=frontend)
        if launch_block is not None:
            return launch_block
        step = self.step()
        prompt = step.pending_prompt
        if prompt is not None and prompt.prompt_kind == "startup_prompt":
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id="run-root",
                active_thread_id=prompt.thread_id,
                bootstrap_source_repos=tuple(self.source_repos),
            )
            _emit_pending_prompt(frontend, prompt)
            from ralphception.headless import HeadlessRunResult

            return HeadlessRunResult(
                mode="startup",
                actions=(),
                root_run_id=None,
                authoritative_repo_root=str(self.repo_root),
            )
        if load_startup_record(self.repo_root) is not None:
            prompt_state = _load_prompt_state(self.repo_root)
            prompt = step.pending_prompt
            if prompt is not None and prompt.prompt_kind in {"spec_review", "execution_bundle", "recovery_review"}:
                if prompt.prompt_kind in {"spec_review", "execution_bundle"} and (
                    self.approve_all or self._auto_approve_startup_reviews
                ):
                    self.apply_review_decision(
                        ReviewDecision(action="approve", approver=self.approver),
                        engine=step.engine,
                    )
                    if prompt.prompt_kind == "execution_bundle":
                        self._auto_approve_startup_reviews = False
                    step = RuntimeStep(kind="dashboard", engine=step.engine)
                else:
                    _persist_pending_prompt(
                        self.repo_root,
                        prompt,
                        root_thread_id="run-root",
                        active_thread_id=prompt.thread_id,
                    )
                    _emit_pending_prompt(frontend, prompt)
                    from ralphception.headless import HeadlessRunResult

                    return HeadlessRunResult(
                        mode="review",
                        actions=(),
                        review_target_kind=_review_kind_for_prompt(prompt),
                        root_run_id=None if step.engine is None else step.engine.root_run.run_id,
                        root_run_status=None if step.engine is None else step.engine.root_run.status,
                        authoritative_repo_root=str(self.repo_root),
                    )
        session_manager = self._require_execution_backend()
        from ralphception.actor_runtime.orchestrator import ActorOrchestrator

        mission = ActorOrchestrator(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            seed_prompt=self.seed_prompt,
            source_repos=self.source_repos,
            approve_all=self.approve_all,
            approver=self.approver,
            session_manager_factory=lambda repo_root, config: session_manager,
        )
        return mission.run_until_blocked(frontend=frontend)

    def ensure_new_launch_allowed(self, *, frontend=None) -> None:
        self._cleanup_terminal_residue(frontend=None)
        blocked = self._launch_blocker(frontend=frontend)
        if blocked is not None and frontend is None:
            mission = self._load_existing_root_mission()
            if mission is not None:
                raise RuntimeResumeRequiredError(
                    repo_root=self.repo_root,
                    run_id=mission.run_id,
                    seed_prompt=mission.seed_prompt,
                    run_status=mission.run_status,
                    current_stage=mission.current_stage,
                )
        if blocked is not None:
            raise RuntimeLaunchAbortedError("Launch aborted.")

    def ensure_resume_target_exists(self) -> ExistingRootMission:
        self._cleanup_terminal_residue(frontend=None)
        mission = self._load_existing_root_mission()
        if mission is None:
            raise RuntimeResumeUnavailableError(repo_root=self.repo_root)
        return mission

    def request_resume_launch(self) -> ExistingRootMission:
        mission = self.ensure_resume_target_exists()
        self._launch_resume_requested = True
        self._auto_approve_startup_reviews = False
        return mission

    def request_start_fresh_launch(
        self,
        *,
        seed_prompt: str | None = None,
        source_repos: tuple[str, ...] | None = None,
    ) -> None:
        from ralphception.headless import clear_runtime_root_for_new_task

        launch_state = resolve_interactive_launch_state(self.repo_root)
        if launch_state.kind in {"resumable", "broken_resume"}:
            self._cleanup_runtime_workspace(
                root_run_id=launch_state.root_run_id or "run-root",
                preserve_durable_artifacts=False,
            )
            self._reset_to_primary_repo_root()
            clear_interactive_session_marker(self.repo_root)
        else:
            startup_record = load_startup_record(self.repo_root)
            if startup_record is not None:
                self._cleanup_runtime_workspace(
                    root_run_id=startup_record.outer_run_id,
                    preserve_durable_artifacts=False,
                )
                self._reset_to_primary_repo_root()
                clear_interactive_session_marker(self.repo_root)
            else:
                clear_runtime_root_for_new_task(self.repo_root)
                self._reset_to_primary_repo_root()
                clear_interactive_session_marker(self.repo_root)
        self.seed_prompt = seed_prompt
        if source_repos is not None:
            self.source_repos = tuple(source_repos)
        self._launch_resume_requested = False
        self._auto_approve_startup_reviews = False

    def resolve_startup_input(
        self,
        *,
        user_text: str,
        source_repos: tuple[str, ...] = (),
    ) -> PromptResolutionResult:
        step = self.step()
        prompt = step.pending_prompt
        if prompt is None or prompt.prompt_kind != "startup_prompt":
            raise RuntimeError("startup prompt is not pending")
        _persist_pending_prompt(
            self.repo_root,
            prompt,
            root_thread_id=prompt.thread_id,
            active_thread_id=prompt.thread_id,
            bootstrap_source_repos=source_repos,
            clear_existing=True,
        )
        return self.resolve_pending_prompt(thread_id=prompt.thread_id, user_text=user_text)

    def current_pending_prompt(self) -> PendingPrompt | None:
        state = _load_prompt_state(self.repo_root)
        if state.pending_prompts:
            return state.pending_prompts[0]
        return self.step().pending_prompt

    def activate_root_watchdog(self, *, frontend=None, trigger_reason: str = "idle"):
        from ralphception.runtime.compaction import (
            build_compaction_summary,
            persist_compaction_checkpoint,
        )
        from ralphception.runtime.frontier import mark_task_frontier, persist_task_frontier
        from ralphception.runtime.watchdog import (
            WatchdogInputSnapshot,
            can_activate_root_watchdog_for_frontier,
            ensure_root_watchdog,
            record_root_watchdog_activation,
        )

        step = self.step()
        prompt = step.pending_prompt
        review_prompt_kind = prompt.prompt_kind if prompt is not None and prompt.prompt_kind in {
            "spec_review",
            "execution_bundle",
            "recovery_review",
        } else None
        frontier = persist_task_frontier(
            self.repo_root,
            engine=step.engine,
            pending_prompt=prompt,
            review_prompt_kind=review_prompt_kind,
        )
        if frontier is None:
            return None

        watchdog = ensure_root_watchdog(self.repo_root)
        if watchdog is None or not can_activate_root_watchdog_for_frontier(watchdog, frontier):
            return None

        watchdog_stage_kind = self._normalize_watchdog_stage_kind(frontier.current_stage)
        self._append_runtime_event(
            run_id=frontier.root_run_id,
            event_type="stage.custom_watchdog_armed",
            payload={
                "stage_kind": watchdog_stage_kind,
                "trigger_reason": trigger_reason,
                "current_stage": frontier.current_stage or "none",
                "status": frontier.status,
            },
            stage_kind=watchdog_stage_kind,
        )
        if frontend is not None:
            frontend.emit_event(
                FrontendEvent(
                    message=f"Watchdog armed: {trigger_reason}",
                    kind="runtime.watchdog.armed",
                    run_id=frontier.root_run_id,
                    payload={
                        "trigger_reason": trigger_reason,
                        "current_stage": frontier.current_stage,
                        "status": frontier.status,
                    },
                )
            )

        artifact_paths = self._watchdog_artifact_paths(frontier.root_run_id)
        recent_runtime_events = self._watchdog_recent_runtime_events(frontier.root_run_id)
        resolution = self._resolve_watchdog_decision(
            frontier=frontier,
            trigger_reason=trigger_reason,
            artifact_paths=artifact_paths,
            recent_runtime_events=recent_runtime_events,
        )
        if resolution is None:
            return None
        activation = record_root_watchdog_activation(
            self.repo_root,
            trigger_reason=trigger_reason,
            source_thread_id=resolution.source_thread_id,
            created_child_thread_id=resolution.created_child_thread_id,
            input_snapshot=WatchdogInputSnapshot(
                goal=watchdog.goal,
                trigger_reason=trigger_reason,
                frontier=frontier,
                artifact_paths=artifact_paths,
                recent_runtime_events=recent_runtime_events,
            ),
            result=resolution.decision,
        )
        if activation is None:
            return None
        self._append_runtime_event(
            run_id=frontier.root_run_id,
            event_type="stage.custom_watchdog_activated",
            payload={
                "stage_kind": watchdog_stage_kind,
                "trigger_reason": activation.trigger_reason,
                "action": activation.action,
                "rationale": activation.rationale,
                "activation_id": activation.activation_id,
                "source_thread_id": activation.source_thread_id,
                "created_child_thread_id": activation.created_child_thread_id,
                "activated_at": activation.activated_at.isoformat(),
            },
            stage_kind=watchdog_stage_kind,
        )
        if frontend is not None:
            frontend.emit_event(
                FrontendEvent(
                    message=f"Watchdog activated: {activation.action}",
                    kind="runtime.watchdog.activated",
                    run_id=activation.root_run_id,
                    payload={
                        "trigger_reason": activation.trigger_reason,
                        "activation_id": activation.activation_id,
                        "activated_at": activation.activated_at.isoformat(),
                        "action": activation.action,
                        "rationale": activation.rationale,
                        "source_thread_id": activation.source_thread_id,
                        "created_child_thread_id": activation.created_child_thread_id,
                    },
                )
            )
        self._append_runtime_event(
            run_id=frontier.root_run_id,
            event_type="stage.custom_watchdog_decided",
            payload={
                "stage_kind": watchdog_stage_kind,
                **resolution.decision.model_dump(mode="json"),
            },
            stage_kind=watchdog_stage_kind,
        )
        if frontend is not None:
            frontend.emit_event(
                FrontendEvent(
                    message=f"Watchdog decided: {resolution.decision.action}",
                    kind="runtime.watchdog.decided",
                    run_id=activation.root_run_id,
                    payload=resolution.decision.model_dump(mode="json"),
                )
            )

        decision = resolution.decision
        if decision.action == "compact_root_thread":
            compact_run_context = getattr(self._require_execution_backend(), "compact_run_context", None)
            if callable(compact_run_context):
                startup_record = load_startup_record(self.repo_root)
                goal = startup_record.seed_prompt if startup_record is not None else frontier.root_run_id
                summary_text = build_compaction_summary(
                    goal=goal,
                    frontier=frontier,
                    recent_runtime_events=recent_runtime_events,
                )
                compacted = compact_run_context(
                    run_id=frontier.root_run_id,
                    goal=goal,
                    reason=decision.compact_reason or decision.rationale,
                    summary_text=summary_text,
                )
                self._persist_run_session_ref(
                    run_id=frontier.root_run_id,
                    session_ref=compacted.compacted_session_ref,
                )
                checkpoint = persist_compaction_checkpoint(
                    self.repo_root,
                    root_run_id=frontier.root_run_id,
                    reason=decision.compact_reason or decision.rationale,
                    summary_text=summary_text,
                    pre_compact_thread_id=compacted.previous_session_ref.codex_thread_id,
                    post_compact_thread_id=compacted.compacted_session_ref.codex_thread_id,
                )
                self._append_runtime_event(
                    run_id=frontier.root_run_id,
                    event_type="stage.custom_watchdog_compacted",
                    payload={
                        "stage_kind": watchdog_stage_kind,
                        **checkpoint.model_dump(mode="json"),
                    },
                    stage_kind=watchdog_stage_kind,
                )
                if frontend is not None:
                    frontend.emit_event(
                        FrontendEvent(
                            message="Watchdog compacted root thread",
                            kind="runtime.watchdog.compacted",
                            run_id=frontier.root_run_id,
                            payload=checkpoint.model_dump(mode="json"),
                        )
                    )
            result = self.run(frontend=frontend)
        elif decision.action == "ask_user":
            result = self._prompt_watchdog_question(decision=decision, frontend=frontend, root_run_id=frontier.root_run_id)
        elif decision.action == "revise_plan":
            self._prepare_plan_revision(decision=decision, root_run_id=frontier.root_run_id)
            result = self.run(frontend=frontend)
        elif decision.action == "mark_complete":
            self._force_headless_completion(root_run_id=frontier.root_run_id)
            result = self._complete_runtime_for_watchdog(root_run_id=frontier.root_run_id, frontend=frontend)
        elif decision.action == "reopen_existing_loop":
            self._reopen_existing_loop(frontier=frontier, frontend=frontend)
            result = self.run(frontend=frontend)
        elif decision.action == "launch_child_loop":
            self._set_headless_stage_for_watchdog(root_run_id=frontier.root_run_id, current_stage="execute")
            result = self.run(frontend=frontend)
        else:
            result = self.run(frontend=frontend)
        if getattr(result, "mode", None) == "completed":
            mark_task_frontier(
                self.repo_root,
                status="completed",
                root_run_id=frontier.root_run_id,
                current_stage="completed",
            )
        else:
            persist_task_frontier(self.repo_root)
        return result

    def _resolve_watchdog_decision(
        self,
        *,
        frontier,
        trigger_reason: str,
        artifact_paths: tuple[str, ...],
        recent_runtime_events: tuple[str, ...],
    ):
        session_manager = self._get_session_manager()
        resolve_watchdog_action = getattr(session_manager, "resolve_watchdog_action", None)
        if not callable(resolve_watchdog_action):
            return None
        startup_record = load_startup_record(self.repo_root)
        goal = startup_record.seed_prompt if startup_record is not None else "Continue the active Ralphception task."
        return resolve_watchdog_action(
            run_id=frontier.root_run_id,
            goal=goal,
            frontier=frontier,
            trigger_reason=trigger_reason,
            artifact_paths=artifact_paths,
            recent_runtime_events=recent_runtime_events,
            allowed_actions=(
                "continue_root_turn",
                "launch_child_loop",
                "reopen_existing_loop",
                "revise_plan",
                "ask_user",
                "compact_root_thread",
                "mark_complete",
            ),
        )

    def _watchdog_artifact_paths(self, root_run_id: str) -> tuple[str, ...]:
        run_path = self.repo_root / ".ralphception" / "runs" / root_run_id / "run.json"
        if not run_path.exists():
            return ()
        run = Run.model_validate_json(run_path.read_text(encoding="utf-8"))
        return tuple(ref.artifact_path for ref in run.artifact_refs)

    def _watchdog_recent_runtime_events(self, root_run_id: str, *, limit: int = 8) -> tuple[str, ...]:
        try:
            events = EventStore(self.repo_root).read_run(root_run_id)
        except Exception:
            return ()
        rendered: list[str] = []
        for event in events[-limit:]:
            summary_parts: list[str] = []
            for key in ("stage_kind", "loop_id", "replacement_run_id", "status", "assigned_run_id"):
                value = event.payload.get(key)
                if isinstance(value, str) and value.strip():
                    summary_parts.append(f"{key}={value}")
            rendered.append(" ".join(part for part in (event.event_type, *summary_parts) if part).strip())
        return tuple(line for line in rendered if line)

    def _append_runtime_event(
        self,
        *,
        run_id: str,
        event_type: str,
        payload: dict[str, object],
        stage_kind: str | None = None,
    ) -> None:
        try:
            EventStore(self.repo_root).append(
                event_id=f"{event_type}-{uuid.uuid4().hex}",
                run_id=run_id,
                event_type=event_type,
                source="runtime.supervisor",
                payload=payload,
                stage_id=None if stage_kind is None else f"stage-{stage_kind}",
            )
        except Exception:
            return

    def _normalize_watchdog_stage_kind(self, stage_kind: str | None) -> str:
        if stage_kind in {"intake", "spec", "plan", "execute", "merge", "audit"}:
            return stage_kind
        return "execute"

    def _prompt_watchdog_question(self, *, decision, frontend, root_run_id: str):
        from ralphception.headless import HeadlessRunResult

        prompt = PendingPrompt(
            thread_id=root_run_id,
            owner_run_id=root_run_id,
            prompt_id=f"prompt-{root_run_id}-watchdog-question",
            prompt_kind="watchdog_question",
            title="Need one more thing",
            question=decision.question or "Need one more thing before continuing.",
            allowed_actions=("continue_root_turn",),
            context={
                "watchdog_action": decision.action,
                "watchdog_rationale": decision.rationale,
            },
            blocked_continuation=BlockedContinuationRef(thread_id=root_run_id, run_id=root_run_id),
        )
        _persist_pending_prompt(
            self.repo_root,
            prompt,
            root_thread_id=root_run_id,
            active_thread_id=root_run_id,
        )
        _emit_pending_prompt(frontend, prompt)
        return HeadlessRunResult(
            mode="startup",
            actions=(),
            root_run_id=root_run_id,
            authoritative_repo_root=str(self.repo_root),
        )

    def _prepare_plan_revision(self, *, decision, root_run_id: str) -> None:
        from ralphception.headless import _preferred_plan_contract_path, _preferred_plan_markdown_path

        headless_state = _load_headless_state(self.repo_root, root_run_id)
        raw_completed_stages = headless_state.get("completed_stages")
        completed_stages = [
            stage
            for stage in (raw_completed_stages if isinstance(raw_completed_stages, list) else [])
            if isinstance(stage, str) and stage in {"intake", "spec"}
        ]
        revised_state = {
            **headless_state,
            "current_stage": "plan",
            "completed_stages": completed_stages,
            "terminal_outcome": None,
            "current_child_run_id": None,
            "active_loop_ids": [],
            "completed_loop_ids": [],
            "pending_child_goal": decision.plan_revision_summary,
            "last_approved_bundle_version": None,
        }
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / root_run_id / "headless-state.json",
            revised_state,
        )
        for path in (
            _preferred_plan_markdown_path(self.repo_root),
            _preferred_plan_contract_path(self.repo_root),
        ):
            if path.exists():
                path.unlink()
        bundle_dir = self.repo_root / ".ralphception" / "runs" / root_run_id / "bundles"
        if bundle_dir.exists():
            for path in bundle_dir.glob("*.json"):
                path.unlink()
        approvals_dir = self.repo_root / ".ralphception" / "approvals"
        if approvals_dir.exists():
            for path in approvals_dir.glob("*.json"):
                try:
                    approval = ApprovalRecord.model_validate_json(path.read_text(encoding="utf-8"))
                except Exception:
                    continue
                if approval.run_id == root_run_id and approval.approval_kind == "execution_bundle":
                    path.unlink()

    def _force_headless_completion(self, *, root_run_id: str) -> None:
        headless_state = _load_headless_state(self.repo_root, root_run_id)
        revised_state = {
            **headless_state,
            "current_stage": "completed",
            "terminal_outcome": "completed",
        }
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / root_run_id / "headless-state.json",
            revised_state,
        )
        run_path = self.repo_root / ".ralphception" / "runs" / root_run_id / "run.json"
        if run_path.exists():
            run = Run.model_validate_json(run_path.read_text(encoding="utf-8"))
            write_json_atomic(
                run_path,
                run.model_copy(update={"status": "completed", "updated_at": datetime.now(timezone.utc)}).model_dump(mode="json"),
            )

    def _set_headless_stage_for_watchdog(self, *, root_run_id: str, current_stage: str) -> None:
        headless_state = _load_headless_state(self.repo_root, root_run_id)
        revised_state = {
            **headless_state,
            "current_stage": current_stage,
            "terminal_outcome": None,
        }
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / root_run_id / "headless-state.json",
            revised_state,
        )

    def _complete_runtime_for_watchdog(self, *, root_run_id: str, frontend):
        from ralphception.headless import HeadlessRunResult, cleanup_mission_workspace

        cleanup_mission_workspace(
            repo_root=self.repo_root,
            primary_repo_root=self.primary_repo_root,
            root_run_id=root_run_id,
        )
        self._reset_to_primary_repo_root()
        if frontend is not None:
            frontend.emit_event(FrontendEvent(message=f"Session completed: {root_run_id}"))
        return HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id=root_run_id,
            root_run_status="completed",
            authoritative_repo_root=str(self.repo_root),
        )

    def _reopen_existing_loop(self, *, frontier, frontend) -> None:
        controller = self.build_review_controller()
        target = controller.current_target()
        if target is not None and target.kind == "recovery":
            actions = controller.recovery_actions(target.run_id)
            preferred_action = next(
                (
                    action
                    for action in ("replace", "restart", "retry", "resume")
                    if f"/{action}" in actions
                ),
                None,
            )
            if preferred_action is not None:
                outcome = controller.apply_recovery_action(target.run_id, preferred_action)
                if isinstance(outcome, Run):
                    self._sync_headless_state_after_recovery(run=outcome)
                elif isinstance(outcome, ResumeResult):
                    self._clear_headless_terminal_outcome(run_id=outcome.run_id)
                return
        self._set_headless_stage_for_watchdog(root_run_id=frontier.root_run_id, current_stage="execute")

    def _persist_run_session_ref(self, *, run_id: str, session_ref) -> None:
        path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if not path.exists():
            return
        run = Run.model_validate_json(path.read_text(encoding="utf-8"))
        write_json_atomic(
            path,
            run.model_copy(update={"codex_session_ref": session_ref, "updated_at": datetime.now(timezone.utc)}).model_dump(mode="json"),
        )

    def _require_execution_backend(self) -> object:
        session_manager = self._get_session_manager()
        if session_manager is None:
            raise RuntimeBackendUnavailableError()
        return session_manager

    def _get_session_manager(self) -> object:
        if self._session_manager is _UNSET_SESSION_MANAGER:
            self._session_manager = _build_session_manager(
                self.repo_root,
                self.config,
                session_manager_factory=self._session_manager_factory,
            )
        return self._session_manager

    def _cleanup_terminal_residue(self, *, frontend) -> None:
        mission = self._load_existing_root_mission()
        if mission is None or not mission.is_completed:
            return
        self._cleanup_runtime_workspace(root_run_id=mission.run_id)
        self._reset_to_primary_repo_root()
        if frontend is not None:
            frontend.emit_event(FrontendEvent(message=f"Cleared completed runtime state for {mission.run_id}"))

    def _reconcile_failed_runtime_state(self) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return

        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        current_stage = state.get("current_stage")
        terminal_outcome = state.get("terminal_outcome")
        if current_stage != "failed" and terminal_outcome != "failed":
            return

        resume_stage = _infer_resume_stage(state)
        current_child_run_id = state.get("current_child_run_id")
        if resume_stage == "execute" and isinstance(current_child_run_id, str):
            child_run_path = self.repo_root / ".ralphception" / "runs" / current_child_run_id / "run.json"
            if child_run_path.exists():
                child_run = Run.model_validate_json(child_run_path.read_text(encoding="utf-8"))
                if child_run.status in {"pending", "running"}:
                    write_json_atomic(
                        child_run_path,
                        child_run.model_copy(update={"status": "failed"}).model_dump(mode="json"),
                    )

        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        if root_run_path.exists():
            root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
            if root_run.status == "failed":
                write_json_atomic(
                    root_run_path,
                    root_run.model_copy(update={"status": "running"}).model_dump(mode="json"),
                )

        state["current_stage"] = resume_stage
        state["terminal_outcome"] = None
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )

    def _reconcile_requested_seed_prompt(self, *, frontend) -> None:
        _ = frontend
        return None

    def _load_existing_root_mission(self) -> ExistingRootMission | None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return None
        root_run_path = self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "run.json"
        run_status: str | None = None
        if root_run_path.exists():
            run_status = Run.model_validate_json(root_run_path.read_text(encoding="utf-8")).status
        headless_state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        terminal_outcome = headless_state.get("terminal_outcome")
        current_stage = headless_state.get("current_stage")
        return ExistingRootMission(
            run_id=startup_record.outer_run_id,
            seed_prompt=startup_record.seed_prompt.strip(),
            run_status=run_status,
            current_stage=current_stage if isinstance(current_stage, str) else None,
            terminal_outcome=terminal_outcome if isinstance(terminal_outcome, str) else None,
        )

    def _reset_to_primary_repo_root(self) -> None:
        self.repo_root = self.primary_repo_root
        self.config = _load_or_create_config(self.repo_root)

    def _sync_headless_state_after_recovery(self, *, run: Run) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return
        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        if not state:
            return
        child_run_ids = state.get("child_run_ids")
        normalized_child_run_ids = (
            [run_id for run_id in child_run_ids if isinstance(run_id, str)]
            if isinstance(child_run_ids, list)
            else []
        )
        if run.run_id not in normalized_child_run_ids:
            normalized_child_run_ids.append(run.run_id)
        state["child_run_ids"] = normalized_child_run_ids
        state["current_child_run_id"] = run.run_id
        state["current_stage"] = "execute"
        state["terminal_outcome"] = None
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )

    def _pending_prompt_for_thread(self, state: InteractiveSessionState, *, thread_id: str) -> PendingPrompt:
        for prompt in state.pending_prompts:
            if prompt.thread_id == thread_id:
                return prompt
            blocked = prompt.blocked_continuation
            if blocked is not None and blocked.thread_id == thread_id:
                return prompt
        if len(state.pending_prompts) == 1:
            return state.pending_prompts[0]
        if state.pending_prompts:
            raise RuntimeError(f"no pending prompt matches thread_id={thread_id!r}")
        return PendingPrompt(
            thread_id=thread_id,
            owner_run_id=thread_id,
            prompt_id=f"prompt-{thread_id}-resume",
            prompt_kind="resume_session",
            title="Resume session",
            question="Continue where we left off?",
            allowed_actions=("resume", "start_fresh"),
            context={},
            blocked_continuation=BlockedContinuationRef(thread_id=thread_id, run_id=thread_id),
        )

    def _active_task_summary(
        self,
        state: InteractiveSessionState,
        mission: ExistingRootMission | None,
    ) -> str:
        if state.active_task_summary is not None and state.active_task_summary.strip():
            return state.active_task_summary.strip()
        if mission is not None and mission.seed_prompt.strip():
            return mission.seed_prompt.strip()
        startup_record = load_startup_record(self.repo_root)
        if startup_record is not None and startup_record.seed_prompt.strip():
            return startup_record.seed_prompt.strip()
        return ""

    def _record_message_classification(
        self,
        state: InteractiveSessionState,
        *,
        text: str,
        kind: MessageKind | str,
    ) -> None:
        resolved_kind = kind.value if isinstance(kind, MessageKind) else kind
        state.message_classifications.append(
            MessageClassification(
                text=text,
                kind=resolved_kind,
            )
        )
        write_interactive_session_state(self.repo_root, state)

    def _record_task_message_classification(
        self,
        *,
        state: InteractiveSessionState,
        user_text: str,
        prompt_pending: bool,
        active_task_summary: str | None,
        thread_id: str,
    ):
        classification = classify_user_message(
            text=user_text,
            prompt_pending=prompt_pending,
            active_task_summary=active_task_summary,
        ).model_copy(
            update={
                "thread_id": thread_id,
                "created_at": datetime.now(timezone.utc),
            }
        )
        if not state.root_thread_id:
            state.root_thread_id = thread_id
        state.active_thread_id = thread_id
        state.message_classifications.append(classification)
        state.updated_at = classification.created_at
        write_interactive_session_state(self.repo_root, state)
        return classification

    def route_active_session_message(
        self,
        *,
        user_text: str,
        frontend=None,
    ):
        state = _load_prompt_state(self.repo_root)
        mission = self._load_existing_root_mission()
        if mission is None:
            raise RuntimeError("no active session exists to classify")

        prompt = state.pending_prompts[0] if state.pending_prompts else None
        if prompt is not None and prompt.prompt_kind != "startup_prompt":
            classification = classify_user_message(
                text=user_text,
                prompt_pending=True,
                active_task_summary=self._active_task_summary(state, mission),
            )
            result = self.resolve_pending_prompt(thread_id=prompt.thread_id, user_text=user_text)
            if result.kind == "clarify" and frontend is not None:
                frontend.emit_event(FrontendEvent(message=result.clarifying_question or prompt.question))
            return classification

        thread_id = state.active_thread_id or state.root_thread_id or mission.run_id
        classification = self._record_task_message_classification(
            state=state,
            user_text=user_text,
            prompt_pending=False,
            active_task_summary=self._active_task_summary(state, mission),
            thread_id=thread_id,
        )
        if classification.kind in {MessageKind.in_task_follow_up, MessageKind.task_revision}:
            state = _load_prompt_state(self.repo_root)
            classification_thread_id = classification.thread_id or thread_id
            state.deferred_inputs.append(
                DeferredInput(
                    thread_id=classification_thread_id,
                    text=user_text,
                    created_at=datetime.now(timezone.utc),
                )
            )
            if not state.root_thread_id:
                state.root_thread_id = classification_thread_id
            state.active_thread_id = classification_thread_id
            state.updated_at = datetime.now(timezone.utc)
            write_interactive_session_state(self.repo_root, state)
            if frontend is not None:
                label = "in-task follow-up" if classification.kind == MessageKind.in_task_follow_up else "task revision"
                frontend.emit_event(FrontendEvent(message=f"Queued {label} for current task."))
            return classification

        if classification.kind == MessageKind.needs_clarification:
            prompt = _task_clarification_prompt(
                repo_root=self.repo_root,
                mission=mission,
                requested_seed_prompt=user_text,
                question=classification.clarifying_question or "Need clarification.",
                source_repos=tuple(state.bootstrap_source_repos),
            )
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
                bootstrap_source_repos=tuple(state.bootstrap_source_repos),
            )
            _emit_pending_prompt(frontend, prompt)
            return classification

        prompt = _launch_conflict_prompt(
            repo_root=self.repo_root,
            mission=mission,
            requested_seed_prompt=user_text,
            source_repos=tuple(state.bootstrap_source_repos),
        )
        _persist_pending_prompt(
            self.repo_root,
            prompt,
            root_thread_id=prompt.thread_id,
            active_thread_id=prompt.thread_id,
        )
        _emit_pending_prompt(frontend, prompt)
        return classification

    def _queue_deferred_input(
        self,
        state: InteractiveSessionState,
        *,
        thread_id: str,
        text: str,
        active_task_summary: str,
    ) -> None:
        state.active_thread_id = thread_id
        state.active_task_id = state.active_task_id or "task-root"
        state.session_id = state.session_id or "run-root"
        state.active_task_summary = active_task_summary
        state.deferred_inputs.append(DeferredInput(thread_id=thread_id, text=text))
        write_interactive_session_state(self.repo_root, state)

    def _resume_prompt_continuation(self, prompt: PendingPrompt, result: PromptResolutionResult) -> None:
        """Hook for continuation resumption after a prompt is durably resolved."""
        action = result.action
        if action is None:
            return

        if prompt.prompt_kind == "resume_session":
            if action == "resume":
                self._launch_resume_requested = True
                self.seed_prompt = _as_context_text(prompt.context, "existing_seed_prompt")
                return
            if action == "start_fresh":
                self._clear_runtime_for_fresh_launch(prompt)
                return

        if prompt.prompt_kind == "launch_conflict":
            if action == "override":
                self._override_live_mission(prompt)
                return
            if action == "abort":
                self._abort_blocked_continuation(prompt)
                return

        if prompt.prompt_kind == "task_clarification":
            state = _load_prompt_state(self.repo_root)
            original_message = _as_context_text(prompt.context, "requested_seed_prompt") or ""
            source_repos = tuple(_as_context_str_list(prompt.context, "source_repos"))
            summary = self._active_task_summary(state, self._load_existing_root_mission())
            if action == "continue_current_task":
                self._queue_deferred_input(
                    state,
                    thread_id=state.active_thread_id or prompt.thread_id,
                    text=original_message,
                    active_task_summary=summary,
                )
                self._launch_resume_requested = True
                return
            if action == "revise_current_task":
                self._queue_deferred_input(
                    state,
                    thread_id=state.active_thread_id or prompt.thread_id,
                    text=original_message,
                    active_task_summary=original_message or summary,
                )
                self._launch_resume_requested = True
                return
            if action == "start_new_task":
                mission = self._load_existing_root_mission()
                if mission is None:
                    return
                launch_prompt = _launch_conflict_prompt(
                    repo_root=self.repo_root,
                    mission=mission,
                    requested_seed_prompt=original_message,
                    source_repos=source_repos,
                )
                _persist_pending_prompt(
                    self.repo_root,
                    launch_prompt,
                    root_thread_id=state.root_thread_id or launch_prompt.thread_id,
                    active_thread_id=launch_prompt.thread_id,
                )
                return

        if prompt.prompt_kind in {"spec_review", "execution_bundle"} and action == "approve":
            self.apply_review_decision(ReviewDecision(action="approve", approver=self.approver))
            return

        if prompt.prompt_kind == "recovery_review":
            if action == "abort":
                self._abort_blocked_continuation(prompt)
                return
            self.apply_review_decision(
                ReviewDecision(
                    action=cast(Literal["resume", "retry", "restart", "replace"], action),
                    approver=self.approver,
                )
            )
            self._clear_owned_prompt_state(prompt)
            return

    def _clear_headless_terminal_outcome(self, *, run_id: str) -> None:
        startup_record = load_startup_record(self.repo_root)
        if startup_record is None:
            return
        state = _load_headless_state(self.repo_root, startup_record.outer_run_id)
        if not state:
            return
        state["current_stage"] = "execute"
        state["terminal_outcome"] = None
        state["current_child_run_id"] = run_id
        child_run_ids = state.get("child_run_ids")
        normalized_child_run_ids = (
            [child_run_id for child_run_id in child_run_ids if isinstance(child_run_id, str)]
            if isinstance(child_run_ids, list)
            else []
        )
        if run_id not in normalized_child_run_ids:
            normalized_child_run_ids.append(run_id)
        state["child_run_ids"] = normalized_child_run_ids
        write_json_atomic(
            self.repo_root / ".ralphception" / "runs" / startup_record.outer_run_id / "headless-state.json",
            state,
        )

    def _launch_blocker(self, *, frontend) -> object | None:
        startup_controller = StartupBootstrapController(self.repo_root)
        if startup_controller.needs_bootstrap():
            prompt_state = _load_prompt_state(self.repo_root)
            prompt = next(
                (
                    pending
                    for pending in prompt_state.pending_prompts
                    if pending.prompt_kind == "startup_prompt"
                ),
                None,
            )
            seeded_answers: tuple[str, ...] = ()
            if self.seed_prompt is not None and self.seed_prompt.strip():
                seeded_answers = (self.seed_prompt.strip(),)
            merged_source_repos = tuple(dict.fromkeys((*prompt_state.bootstrap_source_repos, *self.source_repos)))
            can_execute_inline_seed = (
                frontend is not None
                or self._session_manager_factory is not None
                or codex_cli_available()
            )
            if prompt is None and seeded_answers and can_execute_inline_seed:
                self._bootstrap_from_intake_answers(
                    list(seeded_answers),
                    source_repos=merged_source_repos,
                    thread_id="run-root",
                )
                return None
            if prompt is None:
                prompt = _startup_pending_prompt(
                    self.repo_root,
                    source_repos=merged_source_repos,
                    initial_answers=seeded_answers,
                )
            else:
                merged_answers = list(_as_context_str_list(prompt.context, STARTUP_INTAKE_ANSWERS_KEY))
                for answer in seeded_answers:
                    if answer not in merged_answers:
                        merged_answers.append(answer)
                if merged_answers or merged_source_repos != tuple(prompt_state.bootstrap_source_repos):
                    assessment = assess_intake_answers(*merged_answers)
                    prompt = prompt.model_copy(
                        update={
                            "question": assessment.next_question,
                            "context": {
                                **prompt.context,
                                STARTUP_INTAKE_ANSWERS_KEY: merged_answers,
                            }
                            if merged_answers
                            else dict(prompt.context),
                        }
                    )
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
                bootstrap_source_repos=merged_source_repos,
            )
            if seeded_answers:
                self.seed_prompt = None
            _emit_pending_prompt(frontend, prompt)
            from ralphception.headless import HeadlessRunResult

            return HeadlessRunResult(mode="startup", actions=(), authoritative_repo_root=str(self.repo_root))

        launch_state = resolve_interactive_launch_state(self.repo_root)
        prompt_state = _load_prompt_state(self.repo_root)
        if (
            self.seed_prompt is None or not self.seed_prompt.strip()
        ) and not self._launch_resume_requested and launch_state.kind in {"resumable", "broken_resume"}:
            mission = self._load_existing_root_mission()
            prompt = _resume_launch_prompt(
                repo_root=self.repo_root,
                active_run_id=launch_state.active_run_id or launch_state.root_run_id or "run-root",
                existing_seed_prompt=None if mission is None else mission.seed_prompt,
            )
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
            )
            _emit_pending_prompt(frontend, prompt)
            from ralphception.headless import HeadlessRunResult

            return HeadlessRunResult(mode="startup", actions=(), authoritative_repo_root=str(self.repo_root))

        mission = self._load_existing_root_mission()
        if mission is None:
            return None
        if mission.is_completed:
            self._cleanup_terminal_residue(frontend=frontend)
            return None
        if self._launch_resume_requested:
            self._launch_resume_requested = False
            return None
        requested_seed_prompt = None if self.seed_prompt is None else self.seed_prompt.strip()
        if requested_seed_prompt:
            classified = classify_user_message(
                text=requested_seed_prompt,
                prompt_pending=bool(prompt_state.pending_prompts),
                active_task_summary=self._active_task_summary(prompt_state, mission),
            )
            self._record_message_classification(
                prompt_state,
                text=requested_seed_prompt,
                kind=classified.kind,
            )
            if classified.kind == MessageKind.blocker_reply and prompt_state.pending_prompts:
                resolution = self.resolve_pending_prompt(
                    thread_id=prompt_state.pending_prompts[0].thread_id,
                    user_text=requested_seed_prompt,
                )
                follow_up_prompt = self.current_pending_prompt()
                if resolution.kind != "resolved" or follow_up_prompt is not None:
                    if follow_up_prompt is not None:
                        _emit_pending_prompt(frontend, follow_up_prompt)
                    from ralphception.headless import HeadlessRunResult

                    return HeadlessRunResult(
                        mode="startup",
                        actions=(),
                        authoritative_repo_root=str(self.repo_root),
                    )
                self.seed_prompt = None
                return None
            if classified.kind in {MessageKind.in_task_follow_up, MessageKind.task_revision}:
                updated_summary = (
                    requested_seed_prompt
                    if classified.kind == MessageKind.task_revision
                    else self._active_task_summary(prompt_state, mission)
                )
                self._queue_deferred_input(
                    prompt_state,
                    thread_id=prompt_state.active_thread_id or mission.run_id,
                    text=requested_seed_prompt,
                    active_task_summary=updated_summary,
                )
                self.seed_prompt = None
                self._launch_resume_requested = True
                return None
            if classified.kind == MessageKind.needs_clarification:
                prompt = _task_clarification_prompt(
                    repo_root=self.repo_root,
                    mission=mission,
                    requested_seed_prompt=requested_seed_prompt,
                )
                _persist_pending_prompt(
                    self.repo_root,
                    prompt,
                    root_thread_id=prompt_state.root_thread_id or prompt.thread_id,
                    active_thread_id=prompt.thread_id,
                )
                self.seed_prompt = None
                _emit_pending_prompt(frontend, prompt)
                from ralphception.headless import HeadlessRunResult

                return HeadlessRunResult(
                    mode="startup",
                    actions=(),
                    authoritative_repo_root=str(self.repo_root),
                )
            prompt = _launch_conflict_prompt(
                repo_root=self.repo_root,
                mission=mission,
                requested_seed_prompt=requested_seed_prompt,
                source_repos=self.source_repos,
            )
            _persist_pending_prompt(
                self.repo_root,
                prompt,
                root_thread_id=prompt.thread_id,
                active_thread_id=prompt.thread_id,
            )
            _emit_pending_prompt(frontend, prompt)
            from ralphception.headless import HeadlessRunResult

            return HeadlessRunResult(mode="startup", actions=(), authoritative_repo_root=str(self.repo_root))
        return None

    def _clear_runtime_for_fresh_launch(self, prompt: PendingPrompt) -> None:
        self._cleanup_runtime_workspace(
            root_run_id=(prompt.blocked_continuation.run_id if prompt.blocked_continuation is not None else "run-root"),
            preserve_durable_artifacts=False,
        )
        self._reset_to_primary_repo_root()
        startup_prompt = _startup_pending_prompt(self.repo_root)
        _persist_pending_prompt(
            self.repo_root,
            startup_prompt,
            root_thread_id=startup_prompt.thread_id,
            active_thread_id=startup_prompt.thread_id,
            clear_existing=True,
        )

    def _override_live_mission(self, prompt: PendingPrompt) -> None:
        self._cleanup_runtime_workspace(
            root_run_id=(prompt.blocked_continuation.run_id if prompt.blocked_continuation is not None else "run-root"),
            preserve_durable_artifacts=False,
        )
        self._reset_to_primary_repo_root()
        self.seed_prompt = _as_context_text(prompt.context, "requested_seed_prompt")
        source_repos = _as_context_str_list(prompt.context, "source_repos")
        self.source_repos = tuple(source_repos)
        self._launch_resume_requested = False
        if self.seed_prompt is not None and self.seed_prompt.strip():
            startup_prompt = _startup_pending_prompt(
                self.repo_root,
                source_repos=self.source_repos,
                initial_answers=(self.seed_prompt.strip(),),
            )
            _persist_pending_prompt(
                self.repo_root,
                startup_prompt,
                root_thread_id=startup_prompt.thread_id,
                active_thread_id=startup_prompt.thread_id,
                bootstrap_source_repos=self.source_repos,
                clear_existing=True,
            )
            self.seed_prompt = None
            return
        startup_prompt = _startup_pending_prompt(self.repo_root, source_repos=self.source_repos)
        _persist_pending_prompt(
            self.repo_root,
            startup_prompt,
            root_thread_id=startup_prompt.thread_id,
            active_thread_id=startup_prompt.thread_id,
            bootstrap_source_repos=self.source_repos,
            clear_existing=True,
        )

    def _clear_owned_prompt_state(self, prompt: PendingPrompt) -> None:
        state = _load_prompt_state(self.repo_root)
        owned_thread_ids = {prompt.thread_id}
        blocked = prompt.blocked_continuation
        owned_run_ids = {prompt.owner_run_id}
        if blocked is not None:
            owned_thread_ids.add(blocked.thread_id)
            owned_run_ids.add(blocked.run_id)
        state.pending_prompts = [
            pending
            for pending in state.pending_prompts
            if pending.owner_run_id not in owned_run_ids
            and pending.thread_id not in owned_thread_ids
            and (
                pending.blocked_continuation is None
                or (
                    pending.blocked_continuation.run_id not in owned_run_ids
                    and pending.blocked_continuation.thread_id not in owned_thread_ids
                )
            )
        ]
        state.deferred_inputs = [
            deferred
            for deferred in state.deferred_inputs
            if deferred.thread_id not in owned_thread_ids
        ]
        write_interactive_session_state(self.repo_root, state)

    def _abort_blocked_continuation(self, prompt: PendingPrompt) -> None:
        blocked = prompt.blocked_continuation
        run_id = prompt.owner_run_id if blocked is None else blocked.run_id
        run_path = self.repo_root / ".ralphception" / "runs" / run_id / "run.json"
        if run_path.exists():
            run = Run.model_validate_json(run_path.read_text(encoding="utf-8"))
            if run.codex_session_ref is not None:
                write_json_atomic(
                    run_path,
                    run.model_copy(update={"status": "aborted"}).model_dump(mode="json"),
                )
        marker = load_interactive_session_marker(self.repo_root)
        if marker is not None:
            write_interactive_session_marker(
                self.repo_root,
                marker.model_copy(update={"resumable": False, "blocking_surface_kind": "aborted"}),
            )
        self._clear_owned_prompt_state(prompt)

    def _cleanup_runtime_workspace(self, *, root_run_id: str, preserve_durable_artifacts: bool = True) -> None:
        from ralphception.headless import clear_runtime_root_for_new_task
        from ralphception.headless import cleanup_mission_workspace
        from ralphception.headless import prune_runtime_root_for_completed_task

        try:
            cleanup_mission_workspace(
                repo_root=self.repo_root,
                primary_repo_root=self.primary_repo_root,
                root_run_id=root_run_id,
                preserve_durable_artifacts=preserve_durable_artifacts,
            )
        except RuntimeError as exc:
            if "not a git repository" not in str(exc):
                raise
            if preserve_durable_artifacts:
                prune_runtime_root_for_completed_task(self.repo_root)
            else:
                clear_runtime_root_for_new_task(self.repo_root)


def _build_session_manager(
    repo_root: Path,
    config: RalphceptionConfig,
    *,
    session_manager_factory,
) -> object:
    factory = session_manager_factory or _default_session_manager_factory
    return factory(repo_root, config)


def _default_session_manager_factory(repo_root: Path, config: RalphceptionConfig) -> object:
    if not codex_cli_available():
        return None
    return CodexSessionManager(workspace_path=str(repo_root), config=config)


def _load_bundles(repo_root: Path, run_id: str) -> list[ExecutionBundle]:
    bundle_dir = repo_root / ".ralphception" / "runs" / run_id / "bundles"
    if not bundle_dir.exists():
        return []
    return [
        ExecutionBundle.model_validate(json.loads(path.read_text(encoding="utf-8")))
        for path in sorted(bundle_dir.glob("*.json"))
    ]


def _load_child_runs(repo_root: Path, root_run_id: str) -> list[Run]:
    runs_dir = repo_root / ".ralphception" / "runs"
    if not runs_dir.exists():
        return []

    child_runs: list[Run] = []
    for path in sorted(runs_dir.glob("*/run.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        try:
            run = Run.model_validate(payload)
        except ValidationError:
            repaired_payload = _repair_stale_failed_child_run_payload(payload)
            if repaired_payload is None:
                raise
            write_json_atomic(path, repaired_payload)
            run = Run.model_validate(repaired_payload)
        if run.run_id == root_run_id:
            continue
        child_runs.append(run)
    return child_runs


def _repair_stale_failed_child_run_payload(payload: object) -> dict[str, object] | None:
    if not isinstance(payload, dict):
        return None
    payload_map = cast(dict[str, object], payload)
    if payload_map.get("status") != "failed":
        return None
    if payload_map.get("codex_session_ref") is not None:
        return None
    stage_ids = payload_map.get("stage_ids")
    if not isinstance(stage_ids, list) or not stage_ids:
        return None
    repaired = dict(payload_map)
    repaired["stage_ids"] = []
    return repaired


def _load_approvals(repo_root: Path) -> list[ApprovalRecord]:
    approval_dir = repo_root / ".ralphception" / "approvals"
    if not approval_dir.exists():
        return []
    approvals: list[ApprovalRecord] = []
    for path in sorted(approval_dir.glob("*.json")):
        approvals.append(ApprovalRecord.model_validate(json.loads(path.read_text(encoding="utf-8"))))
    return approvals


def _discover_artifacts(directory: Path, *, artifact_kind: str) -> list[ArtifactRef]:
    if not directory.exists():
        return []
    artifact_refs: list[ArtifactRef] = []
    for index, path in enumerate(sorted(directory.glob("**/*")), start=1):
        if not path.is_file():
            continue
        content = path.read_text(encoding="utf-8")
        artifact_refs.append(
            ArtifactRef(
                artifact_kind=artifact_kind,
                artifact_path=str(path.relative_to(directory.parent.parent)),
                artifact_version=index,
                content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
            ),
        )
    return artifact_refs


def _load_or_create_config(repo_root: Path) -> RalphceptionConfig:
    return load_repo_config(repo_root)


def _resolve_authoritative_repo_root(repo_root: Path) -> Path:
    worktree_path = repo_root / ".ralphception" / "runs" / "run-root" / "worktree.json"
    if not worktree_path.exists():
        return repo_root
    payload = json.loads(worktree_path.read_text(encoding="utf-8"))
    candidate = payload.get("worktree_path")
    if payload.get("kind") != "integration" or not isinstance(candidate, str):
        return repo_root
    resolved = Path(candidate).resolve(strict=False)
    if not resolved.exists():
        return repo_root
    return bootstrap_workspace(resolved)


def _load_headless_state(repo_root: Path, run_id: str) -> dict[str, object]:
    path = repo_root / ".ralphception" / "runs" / run_id / "headless-state.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _load_prompt_state(repo_root: Path) -> InteractiveSessionState:
    return load_interactive_session_state(repo_root)


def _persist_pending_prompt(
    repo_root: Path,
    prompt: PendingPrompt | None,
    *,
    root_thread_id: str,
    active_thread_id: str,
    bootstrap_source_repos: tuple[str, ...] = (),
    clear_existing: bool = False,
) -> None:
    state = InteractiveSessionState() if clear_existing else _load_prompt_state(repo_root)
    if prompt is None:
        state.pending_prompts = []
    else:
        state.pending_prompts = [pending for pending in state.pending_prompts if pending.prompt_id != prompt.prompt_id]
        state.pending_prompts.append(prompt)
    state.root_thread_id = root_thread_id
    state.active_thread_id = active_thread_id
    state.bootstrap_source_repos = list(bootstrap_source_repos)
    write_interactive_session_state(repo_root, state)


def _emit_pending_prompt(frontend, prompt: PendingPrompt) -> None:
    if frontend is None:
        return
    frontend.emit_event(CurrentBlockerStateEvent(label=prompt.question))
    review_kind = _review_kind_for_prompt(prompt)
    if review_kind is not None:
        frontend.emit_event(
            ReviewRequestedEvent(
                review_kind=review_kind,
                run_id=prompt.thread_id,
                summary_text=prompt.question,
                recommended_actions=_review_requested_actions_for_prompt(prompt),
            )
        )
    else:
        frontend.emit_event(
            BlockerPromptEvent(
                prompt_id=prompt.prompt_id,
                title=prompt.title,
                question=prompt.question,
            )
        )
    frontend.emit_event(
        RequestUserInputRequestedEvent(
            prompt_id=prompt.prompt_id,
            title=prompt.title,
            question=prompt.question,
            options=tuple(f"/{action}" for action in prompt.allowed_actions if action != "bootstrap"),
        )
    )


def _startup_pending_prompt(
    repo_root: Path,
    *,
    source_repos: tuple[str, ...] = (),
    initial_answers: tuple[str, ...] = (),
) -> PendingPrompt:
    _ = repo_root
    _ = source_repos
    assessment = assess_intake_answers(*initial_answers)
    context: dict[str, object] = {}
    if assessment.normalized_answers:
        context[STARTUP_INTAKE_ANSWERS_KEY] = list(assessment.normalized_answers)
    return PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Start first task",
        question=assessment.next_question,
        allowed_actions=("bootstrap",),
        context=context,
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )


def _review_pending_prompt(
    *,
    review_kind: ReviewKind,
    run_id: str,
    summary_text: str,
    recommended_actions: tuple[str, ...],
) -> PendingPrompt:
    allowed_actions = tuple(action.lstrip("/").replace("-", "_") for action in recommended_actions)
    if review_kind == "recovery":
        for extra_action in ("pause", "abort"):
            if extra_action not in allowed_actions:
                allowed_actions = (*allowed_actions, extra_action)
    title = "Recovery review" if review_kind == "recovery" else "Review requested"
    return PendingPrompt(
        thread_id=run_id,
        owner_run_id=run_id,
        prompt_id=f"prompt-{run_id}-{review_kind}",
        prompt_kind="recovery_review" if review_kind == "recovery" else review_kind,
        title=title,
        question=summary_text,
        allowed_actions=allowed_actions,
        context={
            "review_kind": review_kind,
            "recommended_actions": list(recommended_actions),
        },
        blocked_continuation=BlockedContinuationRef(
            thread_id=run_id,
            run_id=run_id,
        ),
    )


def _review_kind_for_prompt(prompt: PendingPrompt) -> ReviewKind | None:
    if prompt.prompt_kind == "recovery_review":
        return cast(ReviewKind, "recovery")
    elif prompt.prompt_kind in {"spec_review", "execution_bundle"}:
        return cast(ReviewKind, prompt.prompt_kind)
    return None


def _review_requested_actions_for_prompt(prompt: PendingPrompt) -> tuple[str, ...]:
    value = prompt.context.get("recommended_actions")
    if isinstance(value, list):
        actions = tuple(entry for entry in value if isinstance(entry, str) and entry.strip())
        if actions and _review_kind_for_prompt(prompt) == "recovery":
            ordered = list(actions)
            for extra_action in ("/pause", "/abort"):
                if extra_action not in ordered:
                    ordered.append(extra_action)
            return tuple(ordered)
        if actions:
            return actions
    if _review_kind_for_prompt(prompt) == "recovery":
        actions = tuple(f"/{action.replace('_', '-')}" for action in prompt.allowed_actions if action != "abort")
        if actions:
            return actions
    return prompt.allowed_actions


def _resume_launch_prompt(
    *,
    repo_root: Path,
    active_run_id: str,
    existing_seed_prompt: str | None,
) -> PendingPrompt:
    _ = repo_root
    return PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-resume",
        prompt_kind="resume_session",
        title="Resume last session",
        question="Resume the last Ralphception session or start fresh?",
        allowed_actions=("resume", "start_fresh"),
        context={"existing_seed_prompt": existing_seed_prompt or ""},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id=active_run_id),
    )


def _launch_conflict_prompt(
    *,
    repo_root: Path,
    mission: ExistingRootMission,
    requested_seed_prompt: str,
    source_repos: tuple[str, ...],
) -> PendingPrompt:
    return PendingPrompt(
        thread_id="run-root",
        owner_run_id=mission.run_id,
        prompt_id=f"prompt-{mission.run_id}-conflict",
        prompt_kind="launch_conflict",
        title="Session conflict",
        question=_launch_conflict_message(
            repo_root=repo_root,
            mission=mission,
        ),
        allowed_actions=("override", "abort"),
        context={
            "requested_seed_prompt": requested_seed_prompt,
            "source_repos": list(source_repos),
        },
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id=mission.run_id),
    )


def _task_clarification_prompt(
    *,
    repo_root: Path,
    mission: ExistingRootMission,
    requested_seed_prompt: str,
    question: str | None = None,
    source_repos: tuple[str, ...] = (),
) -> PendingPrompt:
    _ = repo_root
    return PendingPrompt(
        thread_id="run-root",
        owner_run_id=mission.run_id,
        prompt_id=f"prompt-{mission.run_id}-task-clarification",
        prompt_kind="task_clarification",
        title="Task clarification",
        question=question
        or (
            "Need clarification before I change the active task. "
            "Should I treat this as a follow-up to the current task, a scope revision, "
            "or a new task?"
        ),
        allowed_actions=("continue_current_task", "revise_current_task", "start_new_task"),
        context={
            "requested_seed_prompt": requested_seed_prompt,
            "source_repos": list(source_repos),
        },
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id=mission.run_id),
    )


def _launch_conflict_message(
    *,
    repo_root: Path,
    mission: ExistingRootMission,
) -> str:
    details: list[str] = []
    if mission.run_status is not None:
        details.append(f"status={mission.run_status}")
    if mission.current_stage is not None:
        details.append(f"stage={mission.current_stage}")
    suffix = f" ({', '.join(details)})" if details else ""
    return (
        f"Workspace {repo_root} already has an unfinished Ralphception session {mission.run_id}{suffix} "
        f"for seed prompt {mission.seed_prompt!r}. Reopen Ralphception to resume it, or start fresh here. "
        "Starting a new session will clear the current Ralphception runtime state."
    )


def _as_context_text(context: dict[str, object], key: str) -> str | None:
    value = context.get(key)
    return value if isinstance(value, str) and value.strip() else None


def _as_context_str_list(context: dict[str, object], key: str) -> list[str]:
    value = context.get(key)
    if not isinstance(value, list):
        return []
    return [entry for entry in value if isinstance(entry, str) and entry.strip()]


def _infer_resume_stage(state: dict[str, object]) -> str:
    completed = state.get("completed_stages")
    completed_stages = (
        {stage_name for stage_name in completed if isinstance(stage_name, str)}
        if isinstance(completed, list)
        else set()
    )
    for stage_name in ("intake", "spec", "plan", "execute", "merge", "audit"):
        if stage_name not in completed_stages:
            return stage_name
    return "audit"


def _stage_status_for_kind(
    *,
    stage_kind: str,
    default_status: RunStageStatus,
    completed_stages: set[str],
    current_stage: object,
) -> RunStageStatus:
    if stage_kind in completed_stages:
        return "completed"
    if current_stage == stage_kind:
        return "running"
    return default_status


__all__ = ["RuntimeSupervisor"]
