"""Workspace-level interactive session marker and prompt-state persistence."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from ralphception.models.runtime import Run
from ralphception.runtime.bootstrap import load_startup_record
from ralphception.runtime.prompt_state import (
    BlockedContinuationRef,
    DeferredInput,
    InteractiveSessionState,
    PendingPrompt,
    PromptResolution,
    TaskMessageClassification,
)
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic

_ROOT_RUN_ID = "run-root"
_INTERACTIVE_SESSION_FILENAME = "interactive-session.json"
_PROMPT_STATE_FIELDS = {
    "root_thread_id",
    "active_thread_id",
    "active_task_id",
    "active_task_summary",
    "session_id",
    "plan_id",
    "loop_graph_id",
    "active_plan_node_id",
    "pending_prompts",
    "prompt_resolutions",
    "task_message_classifications",
    "deferred_inputs",
    "message_classifications",
    "bootstrap_source_repos",
    "updated_at",
}
_CLEAR_ON_NONE_STATE_FIELDS = {
    "active_task_id",
    "active_task_summary",
    "session_id",
    "plan_id",
    "loop_graph_id",
    "active_plan_node_id",
}


class InteractiveSessionMarker(BaseModel):
    """Single interactive session marker for the current workspace."""

    root_run_id: str
    active_run_id: str | None = None
    resumable: bool = True
    blocking_surface_kind: str | None = None
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class InteractiveLaunchState:
    """Resolved launch-time interactive session classification."""

    kind: str
    root_run_id: str | None = None
    active_run_id: str | None = None
    blocking_surface_kind: str | None = None


def interactive_session_path(repo_root: Path) -> Path:
    """Return the workspace-level interactive-session record path."""
    return bootstrap_workspace(repo_root) / ".ralphception" / _INTERACTIVE_SESSION_FILENAME


def load_interactive_session_marker(repo_root: Path) -> InteractiveSessionMarker | None:
    """Load the interactive-session marker if present and valid."""
    payload = _load_interactive_session_payload(repo_root)
    if payload is None or "root_run_id" not in payload:
        return None
    return InteractiveSessionMarker.model_validate(payload)


def write_interactive_session_marker(repo_root: Path, marker: InteractiveSessionMarker) -> Path:
    """Persist the interactive-session marker without dropping prompt state."""
    payload = _load_interactive_session_payload(repo_root) or {}
    payload.update(marker.model_dump(mode="json"))
    return write_json_atomic(interactive_session_path(repo_root), payload)


def clear_interactive_session_marker(repo_root: Path) -> None:
    """Remove the interactive-session marker if present."""
    path = interactive_session_path(repo_root)
    if path.exists():
        path.unlink()


def load_interactive_session_state(repo_root: Path) -> InteractiveSessionState:
    """Load the durable interactive-session prompt state."""
    payload = _load_interactive_session_payload(repo_root)
    if payload is None:
        return InteractiveSessionState()
    filtered = {key: value for key, value in payload.items() if key in _PROMPT_STATE_FIELDS}
    if "root_thread_id" not in filtered:
        return InteractiveSessionState()
    return InteractiveSessionState.model_validate(filtered)


def write_interactive_session_state(repo_root: Path, state: InteractiveSessionState) -> Path:
    """Persist the interactive-session prompt state without clobbering marker fields."""
    payload = _load_interactive_session_payload(repo_root) or {}
    state_payload = state.model_dump(mode="json", exclude_none=True)
    payload.update(state_payload)
    for field_name in _CLEAR_ON_NONE_STATE_FIELDS:
        if field_name not in state_payload:
            payload.pop(field_name, None)
    return write_json_atomic(interactive_session_path(repo_root), payload)


def resolve_interactive_launch_state(repo_root: Path) -> InteractiveLaunchState:
    """Classify the workspace into fresh, resumable, or broken-resume launch state."""
    resolved_repo_root = bootstrap_workspace(repo_root)
    marker = load_interactive_session_marker(resolved_repo_root)
    if marker is not None:
        return _classify_from_marker(resolved_repo_root, marker)
    return InteractiveLaunchState(kind="fresh")


def _classify_from_marker(repo_root: Path, marker: InteractiveSessionMarker) -> InteractiveLaunchState:
    root_run = _load_run(repo_root, marker.root_run_id)
    active_run_id = marker.active_run_id or marker.root_run_id
    active_run = _load_run(repo_root, active_run_id)
    if root_run is None or active_run is None:
        return InteractiveLaunchState(
            kind="broken_resume",
            root_run_id=marker.root_run_id,
            active_run_id=active_run_id,
            blocking_surface_kind=marker.blocking_surface_kind,
        )
    if not marker.resumable or not _run_is_resumable(active_run):
        return InteractiveLaunchState(
            kind="broken_resume",
            root_run_id=root_run.run_id,
            active_run_id=active_run.run_id,
            blocking_surface_kind=marker.blocking_surface_kind,
        )
    return InteractiveLaunchState(
        kind="resumable",
        root_run_id=root_run.run_id,
        active_run_id=active_run.run_id,
        blocking_surface_kind=marker.blocking_surface_kind,
    )


def _load_run(repo_root: Path, run_id: str) -> Run | None:
    run_path = bootstrap_workspace(repo_root) / ".ralphception" / "runs" / run_id / "run.json"
    if not run_path.exists():
        return None
    return Run.model_validate_json(run_path.read_text(encoding="utf-8"))


def _run_is_resumable(run: Run) -> bool:
    session_ref = run.codex_session_ref
    if session_ref is None:
        return False
    return session_ref.resumable


def _load_interactive_session_payload(repo_root: Path) -> dict[str, Any] | None:
    path = interactive_session_path(repo_root)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


__all__ = [
    "BlockedContinuationRef",
    "DeferredInput",
    "InteractiveLaunchState",
    "InteractiveSessionMarker",
    "InteractiveSessionState",
    "PendingPrompt",
    "PromptResolution",
    "TaskMessageClassification",
    "clear_interactive_session_marker",
    "interactive_session_path",
    "load_interactive_session_marker",
    "load_interactive_session_state",
    "resolve_interactive_launch_state",
    "write_interactive_session_marker",
    "write_interactive_session_state",
]
