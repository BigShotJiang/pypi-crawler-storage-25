"""Helpers for adapting generated commit subjects to repository style."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

_CONVENTIONAL_SUBJECT_RE = re.compile(r"^(?P<type>[a-z]+(?:\([^)]+\))?!?): (?P<summary>.+)$")
_VERBOSE_SECTION_RE = re.compile(
    r"(?i)\b(Goal|Scope|Constraints|Success criteria|Acceptance criteria|Mode):"
)


@dataclass(frozen=True, slots=True)
class CommitStyleProfile:
    conventional: bool
    recent_examples: tuple[str, ...]
    dominant_type: str = "chore"


def detect_commit_style(repo_root: Path, *, limit: int = 25) -> CommitStyleProfile:
    subjects = tuple(_recent_commit_subjects(repo_root, limit=limit))
    filtered = tuple(subject for subject in subjects if _subject_is_style_signal(subject))
    conventional = [match for subject in filtered if (match := _CONVENTIONAL_SUBJECT_RE.match(subject))]
    if conventional and len(conventional) * 2 >= max(1, len(filtered)):
        dominant_type = _dominant_commit_type(tuple(match.group("type") for match in conventional))
        examples = tuple(subject for subject in filtered if _CONVENTIONAL_SUBJECT_RE.match(subject))[:5]
        return CommitStyleProfile(conventional=True, recent_examples=examples, dominant_type=dominant_type)
    return CommitStyleProfile(conventional=False, recent_examples=filtered[:5])


def normalize_commit_message_for_repo(
    repo_root: Path,
    message: str,
    *,
    fallback_type: str = "chore",
) -> str:
    normalized = " ".join(message.strip().split())
    if not normalized:
        raise ValueError("commit message must not be blank")

    profile = detect_commit_style(repo_root)
    parsed = _CONVENTIONAL_SUBJECT_RE.match(normalized)
    commit_type = parsed.group("type") if parsed is not None else fallback_type
    summary = parsed.group("summary") if parsed is not None else normalized
    summary = _summarize_commit_subject(summary)

    if profile.conventional or parsed is not None:
        effective_type = commit_type.strip() or profile.dominant_type or fallback_type
        return f"{effective_type}: {summary}"
    return summary


def build_commit_style_prompt_hint(repo_root: Path) -> str:
    profile = detect_commit_style(repo_root)
    examples = "\n".join(f"- {subject}" for subject in profile.recent_examples)
    base = (
        "Match this repository's recent commit-subject style. "
        "Write concise one-line commit subjects only. "
        "Never include Goal/Scope/Constraints/Success criteria prose in a commit subject."
    )
    if not examples:
        return base
    return f"{base}\nRecent examples:\n{examples}"


def _recent_commit_subjects(repo_root: Path, *, limit: int) -> list[str]:
    completed = subprocess.run(
        ["git", "log", f"-n{limit}", "--format=%s"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return []
    return [line.strip() for line in completed.stdout.splitlines() if line.strip()]


def _subject_is_style_signal(subject: str) -> bool:
    lowered = subject.lower()
    if lowered.startswith("revert "):
        return False
    if _VERBOSE_SECTION_RE.search(subject):
        return False
    return len(subject) <= 100


def _dominant_commit_type(types: tuple[str, ...]) -> str:
    counts: dict[str, int] = {}
    for commit_type in types:
        counts[commit_type] = counts.get(commit_type, 0) + 1
    return max(counts, key=counts.__getitem__, default="chore")


def _summarize_commit_subject(subject: str) -> str:
    normalized = " ".join(subject.strip().split())
    if not normalized:
        return "update runtime artifacts"
    if _VERBOSE_SECTION_RE.search(normalized):
        goal_match = re.search(
            r"(?i)\bGoal:\s*(.+?)(?=(?:\bScope:|\bConstraints:|\bSuccess criteria:|\bAcceptance criteria:|\bMode:)|$)",
            normalized,
        )
        if goal_match is not None:
            normalized = goal_match.group(1).strip()
        else:
            normalized = _VERBOSE_SECTION_RE.split(normalized, maxsplit=1)[0].strip() or normalized
    for separator in (". ", "; ", " — ", " - "):
        if separator in normalized:
            normalized = normalized.split(separator, 1)[0].strip()
            break
    return normalized.rstrip(".")


__all__ = [
    "CommitStyleProfile",
    "build_commit_style_prompt_hint",
    "detect_commit_style",
    "normalize_commit_message_for_repo",
]
