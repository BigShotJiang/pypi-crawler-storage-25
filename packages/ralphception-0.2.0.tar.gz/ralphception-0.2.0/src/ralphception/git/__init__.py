"""Git helpers for runtime worktree orchestration."""

from .commit_style import (
    CommitStyleProfile,
    build_commit_style_prompt_hint,
    detect_commit_style,
    normalize_commit_message_for_repo,
)
from .identity import GitIdentityError, resolve_git_commit_identity
from .merge import (
    HandoffPathValidationResult,
    HandoffValidationResult,
    MergeCoordinator,
    MergeOutcome,
    PartialMergeRecoveryOutcome,
    reconcile_partial_merge,
    validate_handoff,
    validate_handoff_paths,
)
from .worktrees import (
    CleanupFailed,
    CheckoutRootInvalid,
    CreatedChildWorktree,
    CreatedIntegrationWorktree,
    IntegrationRootUnavailable,
    WorktreeMappingUnavailable,
    RunWorktreeMapping,
    WorktreeAssignment,
    WorktreeCoordinator,
    WorktreeCoordinatorError,
    WorktreeCreateFailed,
    read_worktree_assignment,
)

__all__ = [
    "CleanupFailed",
    "CommitStyleProfile",
    "CheckoutRootInvalid",
    "CreatedChildWorktree",
    "CreatedIntegrationWorktree",
    "GitIdentityError",
    "HandoffPathValidationResult",
    "HandoffValidationResult",
    "IntegrationRootUnavailable",
    "MergeCoordinator",
    "MergeOutcome",
    "PartialMergeRecoveryOutcome",
    "WorktreeMappingUnavailable",
    "RunWorktreeMapping",
    "WorktreeAssignment",
    "WorktreeCoordinator",
    "WorktreeCoordinatorError",
    "WorktreeCreateFailed",
    "build_commit_style_prompt_hint",
    "detect_commit_style",
    "normalize_commit_message_for_repo",
    "resolve_git_commit_identity",
    "reconcile_partial_merge",
    "read_worktree_assignment",
    "validate_handoff",
    "validate_handoff_paths",
]
