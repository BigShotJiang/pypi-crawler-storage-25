"""Git identity resolution helpers for runtime-created commits."""

from __future__ import annotations

import subprocess
from pathlib import Path

_FORBIDDEN_NAMES = {"Ralphception", "Ralphception Merge"}
_FORBIDDEN_EMAILS = {"ralphception@example.com", "merge@ralphception.local"}


class GitIdentityError(RuntimeError):
    """Raised when a usable user identity cannot be resolved from git."""


def resolve_git_commit_identity(repo_root: Path) -> tuple[str, str]:
    configured_name = _git_output(repo_root, "config", "--get", "user.name")
    configured_email = _git_output(repo_root, "config", "--get", "user.email")
    if _is_usable_identity(configured_name, configured_email):
        return configured_name, configured_email

    head_name = _git_output(repo_root, "show", "-s", "--format=%an", "HEAD")
    head_email = _git_output(repo_root, "show", "-s", "--format=%ae", "HEAD")
    if _is_usable_identity(head_name, head_email):
        return head_name, head_email

    raise GitIdentityError(
        "Git user identity is not configured. Set git user.name and user.email before running Ralphception.",
    )


def _is_usable_identity(name: str, email: str) -> bool:
    return bool(name and email) and name not in _FORBIDDEN_NAMES and email not in _FORBIDDEN_EMAILS


def _git_output(repo_root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        return ""
    return completed.stdout.strip()
