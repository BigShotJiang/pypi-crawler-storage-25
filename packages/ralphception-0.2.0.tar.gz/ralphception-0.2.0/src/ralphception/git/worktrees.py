"""Coordinator helpers for child and integration git worktrees."""

from __future__ import annotations

from collections.abc import Sequence
import json
import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Literal, cast

from ralphception.paths import resolve_repo_root, resolve_workspace_identity_root
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import write_json_atomic
from ralphception.storage.lease import read_workspace_lease, update_workspace_lease_authoritative_root
from ralphception.workflow._identifiers import validate_storage_identifier

WorktreeKind = Literal["child", "integration"]
CleanupState = Literal["pending", "retained", "cleaned"]


class WorktreeCoordinatorError(RuntimeError):
    """Base error for normalized worktree coordinator failures."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class WorktreeCreateFailed(WorktreeCoordinatorError):
    def __init__(self, message: str) -> None:
        super().__init__("worktree_create_failed", message)


class IntegrationRootUnavailable(WorktreeCoordinatorError):
    def __init__(self, message: str) -> None:
        super().__init__("integration_root_unavailable", message)


class CleanupFailed(WorktreeCoordinatorError):
    def __init__(self, message: str) -> None:
        super().__init__("cleanup_failed", message)


class WorktreeMappingUnavailable(WorktreeCoordinatorError):
    def __init__(self, message: str) -> None:
        super().__init__("worktree_mapping_unavailable", message)


class CheckoutRootInvalid(WorktreeCoordinatorError):
    def __init__(self, message: str) -> None:
        super().__init__("checkout_root_invalid", message)


@dataclass(frozen=True, slots=True)
class CreatedChildWorktree:
    worktree_path: Path
    branch_name: str


@dataclass(frozen=True, slots=True)
class CreatedIntegrationWorktree:
    worktree_path: Path
    base_ref: str


@dataclass(frozen=True, slots=True)
class RunWorktreeMapping:
    worktree_path: Path
    branch_name: str | None
    authoritative: bool


@dataclass(frozen=True, slots=True)
class WorktreeAssignment:
    run_id: str
    kind: WorktreeKind
    worktree_path: Path
    branch_name: str | None
    base_ref: str
    target_branch: str
    goal: str | None
    head_commit: str
    cleanup_state: CleanupState

    def to_json(self) -> dict[str, str | None]:
        return {
            "run_id": self.run_id,
            "kind": self.kind,
            "worktree_path": str(self.worktree_path),
            "branch_name": self.branch_name,
            "base_ref": self.base_ref,
            "target_branch": self.target_branch,
            "goal": self.goal,
            "head_commit": self.head_commit,
            "cleanup_state": self.cleanup_state,
        }

    @classmethod
    def from_json(cls, payload: dict[str, object]) -> "WorktreeAssignment":
        try:
            run_id = validate_storage_identifier(str(payload["run_id"]), field_name="run_id")
            kind = _require_kind(payload["kind"])
            worktree_path = Path(str(payload["worktree_path"]))
            branch_name = _optional_string(payload.get("branch_name"))
            base_ref = str(payload["base_ref"])
            target_branch = _optional_string(payload.get("target_branch")) or branch_name or base_ref
            goal = _optional_string(payload.get("goal"))
            head_commit = str(payload["head_commit"])
            cleanup_state = _require_cleanup_state(payload["cleanup_state"])
        except KeyError as exc:
            raise ValueError(f"missing worktree assignment field: {exc.args[0]}") from exc
        return cls(
            run_id=run_id,
            kind=kind,
            worktree_path=worktree_path,
            branch_name=branch_name,
            base_ref=base_ref,
            target_branch=target_branch,
            goal=goal,
            head_commit=head_commit,
            cleanup_state=cleanup_state,
        )


class WorktreeCoordinator:
    """Create, map, switch, and clean up Ralphception worktrees."""

    def __init__(self, *, repo_root: Path, xdg_state_home: Path | None = None) -> None:
        self.repo_root = _canonical_workspace_root(repo_root)
        self.checkout_root = _resolve_checkout_root(repo_root, canonical_root=self.repo_root)
        self.xdg_state_home = xdg_state_home
        self._worktrees_root = self.repo_root / ".worktrees"
        self._worktrees_root.mkdir(exist_ok=True)

    def create_child_worktree(
        self,
        *,
        run_id: str,
        base_ref: str,
        target_branch: str,
        goal: str,
    ) -> CreatedChildWorktree:
        branch_name = _normalize_child_branch(target_branch)
        worktree_path = self._worktrees_root / run_id
        worktree_created = False
        try:
            validate_storage_identifier(run_id, field_name="run_id")
            self._run_git("worktree", "add", "--no-checkout", "-b", branch_name, str(worktree_path), base_ref)
            worktree_created = True
            self._materialize_worktree_checkout(worktree_path)
            assignment = WorktreeAssignment(
                run_id=run_id,
                kind="child",
                worktree_path=worktree_path,
                branch_name=branch_name,
                base_ref=base_ref,
                target_branch=branch_name,
                goal=goal,
                head_commit=self._git_output(worktree_path, "rev-parse", "HEAD"),
                cleanup_state="pending",
            )
            self._write_assignment(assignment)
        except WorktreeCreateFailed:
            raise
        except (subprocess.CalledProcessError, ValueError, OSError) as exc:
            if worktree_created:
                self._rollback_created_worktree(worktree_path=worktree_path, branch_name=branch_name)
            raise WorktreeCreateFailed(
                f"failed to create child worktree for {run_id!r}: {self._format_error(exc)}",
            ) from exc
        return CreatedChildWorktree(worktree_path=worktree_path, branch_name=branch_name)

    def create_integration_worktree(
        self,
        *,
        run_id: str,
        target_branch: str,
    ) -> CreatedIntegrationWorktree:
        worktree_path = self._worktrees_root / f"{run_id}-integration"
        worktree_created = False
        try:
            validate_storage_identifier(run_id, field_name="run_id")
            if self._can_reuse_current_integration_worktree(run_id=run_id, worktree_path=worktree_path):
                return CreatedIntegrationWorktree(worktree_path=worktree_path, base_ref=target_branch)
            self._run_git("worktree", "add", "--detach", "--no-checkout", str(worktree_path), target_branch)
            worktree_created = True
            self._materialize_worktree_checkout(worktree_path)
            assignment = WorktreeAssignment(
                run_id=run_id,
                kind="integration",
                worktree_path=worktree_path,
                branch_name=None,
                base_ref=target_branch,
                target_branch=target_branch,
                goal=None,
                head_commit=self._git_output(worktree_path, "rev-parse", "HEAD"),
                cleanup_state="pending",
            )
            self._write_assignment(assignment)
        except (subprocess.CalledProcessError, ValueError, OSError) as exc:
            if worktree_created:
                self._rollback_created_worktree(worktree_path=worktree_path, branch_name=None)
            raise IntegrationRootUnavailable(
                f"failed to establish integration worktree for {run_id!r}: {self._format_error(exc)}",
            ) from exc
        return CreatedIntegrationWorktree(worktree_path=worktree_path, base_ref=target_branch)

    def create_child_worktrees(
        self,
        *,
        assignments: Sequence[tuple[str, str]],
        base_ref: str,
        target_branch: str,
    ) -> list[CreatedChildWorktree]:
        return [
            self.create_child_worktree(
                run_id=run_id,
                base_ref=base_ref,
                target_branch=target_branch,
                goal=goal,
            )
            for run_id, goal in assignments
        ]

    def _can_reuse_current_integration_worktree(self, *, run_id: str, worktree_path: Path) -> bool:
        if _normalized_path(self.checkout_root) != _normalized_path(worktree_path):
            return False
        try:
            assignment = read_worktree_assignment(self.repo_root, run_id)
        except (FileNotFoundError, ValueError, OSError):
            return False
        if assignment.kind != "integration":
            return False
        return _normalized_path(assignment.worktree_path) == _normalized_path(worktree_path)

    def map_run_to_worktree(self, run_id: str) -> RunWorktreeMapping:
        try:
            assignment = read_worktree_assignment(self.repo_root, run_id)
            lease = read_workspace_lease(self.checkout_root, xdg_state_home=self.xdg_state_home)
        except (FileNotFoundError, ValueError, OSError) as exc:
            raise WorktreeMappingUnavailable(
                f"failed to map worktree for {run_id!r}: {self._format_error(exc)}",
            ) from exc
        authoritative = lease is not None and (
            lease.authoritative_repository_root.resolve(strict=False)
            == assignment.worktree_path.resolve(strict=False)
        )
        return RunWorktreeMapping(
            worktree_path=assignment.worktree_path,
            branch_name=assignment.branch_name,
            authoritative=authoritative,
        )

    def switch_authoritative_root(self, *, run_id: str, new_root: Path) -> Path:
        validate_storage_identifier(run_id, field_name="run_id")
        candidate = self._validate_authoritative_root(run_id=run_id, new_root=new_root)
        try:
            lease = update_workspace_lease_authoritative_root(
                self.checkout_root,
                run_id=run_id,
                authoritative_repository_root=candidate,
                xdg_state_home=self.xdg_state_home,
            )
        except (FileNotFoundError, ValueError, OSError) as exc:
            raise IntegrationRootUnavailable(
                f"failed to switch authoritative root for {run_id!r}: {self._format_error(exc)}",
            ) from exc
        return lease.authoritative_repository_root

    def cleanup_worktree(
        self,
        *,
        run_id: str,
        worktree_path: Path,
        retain: bool = False,
    ) -> CleanupState:
        try:
            assignment = read_worktree_assignment(self.repo_root, run_id)
            if _normalized_path(assignment.worktree_path) != _normalized_path(worktree_path):
                raise CleanupFailed(
                    f"mapped worktree for {run_id!r} is {assignment.worktree_path}, not {worktree_path}",
                )
            if not self._is_managed_worktree_path(assignment.worktree_path):
                raise CleanupFailed(
                    f"refusing to clean unmanaged worktree path for {run_id!r}: {assignment.worktree_path}",
                )
            if retain:
                if not self._is_valid_worktree_root(assignment.worktree_path):
                    raise CleanupFailed(
                        f"cannot retain unavailable worktree for {run_id!r}: {assignment.worktree_path}",
                    )
                self._write_assignment(_with_cleanup_state(assignment, "retained"))
                return "retained"
            if self._is_authoritative_root(assignment.worktree_path):
                raise CleanupFailed(
                    f"cannot clean up authoritative worktree for {run_id!r} until authoritative root moves",
                )

            branch_name = self._branch_name_for_cleanup(assignment)
            self._remove_or_prune_worktree(assignment.worktree_path)
            if branch_name is not None and self._branch_exists(branch_name):
                self._delete_branch(branch_name)
            self._write_assignment(_with_cleanup_state(assignment, "cleaned"))
        except CleanupFailed:
            raise
        except (FileNotFoundError, subprocess.CalledProcessError, OSError, ValueError) as exc:
            raise CleanupFailed(
                f"failed to clean up worktree for {run_id!r}: {self._format_error(exc)}",
            ) from exc
        return "cleaned"

    def _write_assignment(self, assignment: WorktreeAssignment) -> WorktreeAssignment:
        validate_storage_identifier(assignment.run_id, field_name="run_id")
        write_json_atomic(_assignment_path(self.repo_root, assignment.run_id), assignment.to_json())
        return assignment

    def _is_valid_worktree_root(self, candidate: Path) -> bool:
        if not candidate.exists():
            return False
        if candidate.is_symlink():
            return False
        if not self._is_managed_worktree_path(candidate):
            return False
        if not self._shares_workspace_identity(candidate):
            return False
        try:
            return _normalized_path(
                _resolve_checkout_root(candidate, canonical_root=self.repo_root),
            ) == _normalized_path(candidate)
        except (WorktreeCoordinatorError, RuntimeError, OSError):
            return False

    def _is_managed_worktree_path(self, candidate: Path) -> bool:
        try:
            relative = _normalized_path(candidate).relative_to(
                _normalized_path(self._worktrees_root),
            )
        except ValueError:
            return False
        return len(relative.parts) == 1

    def _is_authoritative_root(self, candidate: Path) -> bool:
        lease = read_workspace_lease(self.checkout_root, xdg_state_home=self.xdg_state_home)
        if lease is None:
            return False
        return _normalized_path(lease.authoritative_repository_root) == _normalized_path(candidate)

    def _branch_exists(self, branch_name: str) -> bool:
        result = subprocess.run(
            ["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch_name}"],
            check=False,
            cwd=self.checkout_root,
            capture_output=True,
            text=True,
        )
        return result.returncode == 0

    def _materialize_worktree_checkout(self, worktree_path: Path) -> None:
        self._link_shared_git_crypt_state(worktree_path)
        self._run_git_in_cwd(worktree_path, "reset", "--hard", "HEAD")

    def _link_shared_git_crypt_state(self, worktree_path: Path) -> None:
        git_dir = self._resolve_git_path(worktree_path, "--git-dir")
        common_dir = self._resolve_git_path(worktree_path, "--git-common-dir")
        if _normalized_path(git_dir) == _normalized_path(common_dir):
            return
        shared_state = common_dir / "git-crypt"
        if not shared_state.exists():
            return
        worktree_state = git_dir / "git-crypt"
        if worktree_state.exists() or worktree_state.is_symlink():
            return
        os.symlink(shared_state, worktree_state, target_is_directory=True)

    def _resolve_git_path(self, cwd: Path, rev_parse_flag: str) -> Path:
        path = Path(self._git_output(cwd, "rev-parse", rev_parse_flag))
        if not path.is_absolute():
            path = cwd / path
        return path.resolve(strict=False)

    def _run_git(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            check=True,
            cwd=self.checkout_root,
            capture_output=True,
            text=True,
        )

    def _run_git_in_cwd(self, cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            check=True,
            cwd=cwd,
            capture_output=True,
            text=True,
        )

    def _git_output(self, cwd: Path, *args: str) -> str:
        result = self._run_git_in_cwd(cwd, *args)
        return result.stdout.strip()

    def _rollback_created_worktree(self, *, worktree_path: Path, branch_name: str | None) -> None:
        self._remove_or_prune_worktree(worktree_path, best_effort=True)
        if branch_name is not None:
            self._delete_branch(branch_name, best_effort=True)

    def _branch_name_for_cleanup(self, assignment: WorktreeAssignment) -> str | None:
        if assignment.kind != "child":
            return None
        if assignment.worktree_path.exists() and self._is_valid_worktree_root(assignment.worktree_path):
            branch_name = self._git_output(assignment.worktree_path, "rev-parse", "--abbrev-ref", "HEAD")
            if branch_name == "HEAD":
                raise CleanupFailed(
                    f"cannot determine child branch for {assignment.run_id!r}: detached HEAD",
                )
            return branch_name

        registered_branch = self._branch_name_from_worktree_list(assignment.worktree_path)
        if registered_branch is not None:
            return registered_branch
        fallback_branch = self._fallback_child_branch_name(assignment)
        if fallback_branch is not None:
            return fallback_branch
        raise CleanupFailed(
            f"cannot determine child branch for {assignment.run_id!r}: {assignment.worktree_path}",
        )

    def _fallback_child_branch_name(self, assignment: WorktreeAssignment) -> str | None:
        candidates = tuple(
            candidate
            for candidate in (assignment.branch_name, assignment.target_branch)
            if candidate
        )
        first_missing_candidate: str | None = None
        for candidate in candidates:
            normalized = _normalize_child_branch(candidate)
            if self._branch_exists(normalized):
                if self._git_output(self.checkout_root, "rev-parse", normalized) == assignment.head_commit:
                    return normalized
                continue
            if first_missing_candidate is None:
                first_missing_candidate = normalized
        return first_missing_candidate

    def _remove_or_prune_worktree(self, worktree_path: Path, *, best_effort: bool = False) -> None:
        if worktree_path.exists():
            result = self._run_git_checked(
                "worktree",
                "remove",
                "--force",
                str(worktree_path),
                best_effort=best_effort,
            )
            if not best_effort and result.returncode != 0:
                if not self._is_managed_worktree_path(worktree_path):
                    raise subprocess.CalledProcessError(
                        result.returncode,
                        result.args,
                        output=result.stdout,
                        stderr=result.stderr,
                    )
                if not (worktree_path / ".git").exists():
                    shutil.rmtree(worktree_path)
                else:
                    raise subprocess.CalledProcessError(
                        result.returncode,
                        result.args,
                        output=result.stdout,
                        stderr=result.stderr,
                    )
        prune_result = self._run_git_checked(
            "worktree",
            "prune",
            "--expire",
            "now",
            best_effort=best_effort,
        )
        if not best_effort and prune_result.returncode != 0:
            raise subprocess.CalledProcessError(
                prune_result.returncode,
                prune_result.args,
                output=prune_result.stdout,
                stderr=prune_result.stderr,
            )

    def _delete_branch(self, branch_name: str, *, best_effort: bool = False) -> None:
        result = self._run_git_checked("branch", "-D", branch_name, best_effort=best_effort)
        if result.returncode == 0 or best_effort:
            return
        stderr = (result.stderr or "").strip()
        if "used by worktree" in stderr:
            self._run_git_checked("worktree", "prune", "--expire", "now", best_effort=True)
            retry = self._run_git_checked("branch", "-D", branch_name, best_effort=best_effort)
            if retry.returncode == 0:
                return
            raise subprocess.CalledProcessError(
                retry.returncode,
                retry.args,
                output=retry.stdout,
                stderr=retry.stderr,
            )
        raise subprocess.CalledProcessError(
            result.returncode,
            result.args,
            output=result.stdout,
            stderr=result.stderr,
        )

    def _branch_name_from_worktree_list(self, worktree_path: Path) -> str | None:
        result = self._run_git_checked("worktree", "list", "--porcelain", best_effort=False)
        current_path: Path | None = None

        for line in result.stdout.splitlines():
            if line.startswith("worktree "):
                current_path = _normalized_path(Path(line.removeprefix("worktree ").strip()))
                continue
            if current_path == _normalized_path(worktree_path) and line.startswith("branch refs/heads/"):
                return line.removeprefix("branch refs/heads/").strip()
        return None

    def _validate_authoritative_root(self, *, run_id: str, new_root: Path) -> Path:
        candidate = _normalized_path(new_root)
        repo_root = _normalized_path(self.repo_root)
        if candidate == repo_root and candidate.exists() and candidate.is_dir():
            return candidate
        if not (candidate.exists() and candidate.is_dir()):
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            )
        if candidate.is_symlink():
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            )
        try:
            candidate_repo_root = _normalized_path(resolve_repo_root(candidate))
        except RuntimeError as exc:
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            ) from exc
        if candidate_repo_root != candidate:
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            )
        if not self._shares_workspace_identity(candidate):
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            )
        try:
            assignment = read_worktree_assignment(self.repo_root, run_id)
        except (FileNotFoundError, ValueError) as exc:
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            ) from exc
        expected_integration_path = _normalized_path(self._worktrees_root / f"{run_id}-integration")
        if Path(expected_integration_path).is_symlink():
            raise IntegrationRootUnavailable(
                f"invalid authoritative root: {new_root}",
            )
        if (
            assignment.kind == "integration"
            and _normalized_path(assignment.worktree_path) == expected_integration_path
            and candidate == expected_integration_path
        ):
            return candidate
        raise IntegrationRootUnavailable(
            f"invalid authoritative root: {new_root}",
        )

    def _format_error(self, exc: BaseException) -> str:
        if isinstance(exc, subprocess.CalledProcessError):
            stderr = (exc.stderr or "").strip()
            stdout = (exc.stdout or "").strip()
            return stderr or stdout or str(exc)
        return str(exc)

    def _shares_workspace_identity(self, candidate: Path) -> bool:
        try:
            return resolve_workspace_identity_root(candidate).resolve(strict=False) == self.repo_root.resolve(
                strict=False,
            )
        except RuntimeError:
            return False

    def _run_git_checked(self, *args: str, best_effort: bool) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", *args],
            check=False,
            cwd=self.checkout_root,
            capture_output=True,
            text=True,
        )


def read_worktree_assignment(repo_root: Path, run_id: str) -> WorktreeAssignment:
    validate_storage_identifier(run_id, field_name="run_id")
    repo_root = _canonical_workspace_root(repo_root)
    path = _assignment_path(repo_root, run_id)
    assignment = WorktreeAssignment.from_json(json.loads(path.read_text(encoding="utf-8")))
    expected_worktree_path = _expected_worktree_path(repo_root, run_id, kind=assignment.kind)
    if assignment.worktree_path.is_symlink():
        raise ValueError(f"invalid symlinked worktree_path for {run_id!r}: {assignment.worktree_path}")
    if _normalized_path(assignment.worktree_path) != _normalized_path(expected_worktree_path):
        raise ValueError(f"invalid worktree_path for {run_id!r}: {assignment.worktree_path}")
    return assignment


def _assignment_path(repo_root: Path, run_id: str) -> Path:
    return repo_root / ".ralphception" / "runs" / run_id / "worktree.json"


def _expected_worktree_path(repo_root: Path, run_id: str, *, kind: WorktreeKind) -> Path:
    worktrees_root = repo_root / ".worktrees"
    if kind == "integration":
        return worktrees_root / f"{run_id}-integration"
    return worktrees_root / run_id


def _canonical_workspace_root(start_path: Path) -> Path:
    return bootstrap_workspace(resolve_workspace_identity_root(start_path))


def _normalized_path(path: Path) -> Path:
    return Path(os.path.abspath(path))


def _resolve_checkout_root(start_path: Path, *, canonical_root: Path) -> Path:
    candidate = start_path.resolve(strict=False)
    checkout_root = resolve_repo_root(start_path).resolve(strict=False)
    worktrees_root = (canonical_root / ".worktrees").resolve(strict=False)

    try:
        candidate.relative_to(worktrees_root)
    except ValueError:
        return checkout_root

    try:
        checkout_root.relative_to(worktrees_root)
    except ValueError:
        raise CheckoutRootInvalid(f"invalid checkout root: {start_path}")
    try:
        candidate.relative_to(checkout_root)
    except ValueError:
        raise CheckoutRootInvalid(f"invalid checkout root: {start_path}")
    return checkout_root


def _with_cleanup_state(assignment: WorktreeAssignment, cleanup_state: CleanupState) -> WorktreeAssignment:
    return WorktreeAssignment(
        run_id=assignment.run_id,
        kind=assignment.kind,
        worktree_path=assignment.worktree_path,
        branch_name=assignment.branch_name,
        base_ref=assignment.base_ref,
        target_branch=assignment.target_branch,
        goal=assignment.goal,
        head_commit=assignment.head_commit,
        cleanup_state=cleanup_state,
    )


def _normalize_child_branch(target_branch: str) -> str:
    candidate = target_branch.strip()
    if not candidate:
        raise WorktreeCreateFailed("child target_branch must not be blank")
    if not candidate.startswith("codex/"):
        candidate = f"codex/{candidate}"
    if "\\" in candidate or "\x00" in candidate:
        raise WorktreeCreateFailed(f"invalid child target_branch: {target_branch!r}")
    parts = candidate.split("/")
    if parts[0] != "codex" or len(parts) < 2 or any(part in {"", ".", ".."} for part in parts):
        raise WorktreeCreateFailed(f"invalid child target_branch: {target_branch!r}")
    return candidate


def _optional_string(value: object | None) -> str | None:
    if value is None:
        return None
    return str(value)


def _require_kind(value: object) -> WorktreeKind:
    candidate = str(value)
    if candidate not in {"child", "integration"}:
        raise ValueError(f"invalid worktree kind: {candidate!r}")
    return cast(WorktreeKind, candidate)


def _require_cleanup_state(value: object) -> CleanupState:
    candidate = str(value)
    if candidate not in {"pending", "retained", "cleaned"}:
        raise ValueError(f"invalid cleanup state: {candidate!r}")
    return cast(CleanupState, candidate)
