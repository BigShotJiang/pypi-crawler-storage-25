"""Commit intent storage helpers for the actor runtime."""

from __future__ import annotations

import json
from pathlib import Path

from pydantic import TypeAdapter

from ralphception.models.commit_intents import CommitIntent
from ralphception.storage.files import write_json_atomic

_COMMIT_INTENT_LIST_ADAPTER = TypeAdapter(list[CommitIntent])


def commit_intents_path(repo_root: Path) -> Path:
    return repo_root / ".ralphception" / "commits" / "intents.json"


def write_commit_intents(repo_root: Path, intents: list[CommitIntent]) -> Path:
    return write_json_atomic(
        commit_intents_path(repo_root),
        [intent.model_dump(mode="json") for intent in intents],
    )


def read_commit_intents(repo_root: Path) -> list[CommitIntent]:
    path = commit_intents_path(repo_root)
    if not path.exists():
        return []
    return _COMMIT_INTENT_LIST_ADAPTER.validate_python(json.loads(path.read_text(encoding="utf-8")))


def update_commit_intent_winner(repo_root: Path, *, intent_id: str, candidate_id: str) -> CommitIntent:
    intents = read_commit_intents(repo_root)
    updated_intent: CommitIntent | None = None
    rewritten: list[CommitIntent] = []
    for intent in intents:
        if intent.intent_id == intent_id:
            updated_intent = intent.model_copy(update={"winning_candidate_id": candidate_id})
            rewritten.append(updated_intent)
            continue
        rewritten.append(intent)
    if updated_intent is None:
        raise ValueError(f"unknown commit intent: {intent_id}")
    write_commit_intents(repo_root, rewritten)
    return updated_intent
