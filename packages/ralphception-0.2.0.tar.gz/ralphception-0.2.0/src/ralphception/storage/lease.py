"""Minimal XDG workspace lease persistence for authoritative-root tracking."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ralphception.paths import resolve_workspace_identity_root, workspace_hash, workspace_state_dir
from ralphception.storage.files import write_json_atomic
from ralphception.workflow._identifiers import validate_storage_identifier


class WorkspaceLeaseConflictError(RuntimeError):
    """Raised when a healthy foreign lease prevents a second active writer."""


@dataclass(frozen=True, slots=True)
class WorkspaceLease:
    workspace_path_hash: str
    process_id: int
    run_id: str
    authoritative_repository_root: Path
    heartbeat_at: datetime

    def to_json(self) -> dict[str, int | str]:
        return {
            "workspace_path_hash": self.workspace_path_hash,
            "process_id": self.process_id,
            "run_id": self.run_id,
            "authoritative_repository_root": str(self.authoritative_repository_root),
            "heartbeat_at": self.heartbeat_at.isoformat(),
        }

    @classmethod
    def from_json(cls, payload: dict[str, object]) -> "WorkspaceLease":
        try:
            workspace_path_hash = str(payload["workspace_path_hash"])
            process_id = payload["process_id"]
            run_id = str(payload["run_id"])
            authoritative_repository_root = Path(str(payload["authoritative_repository_root"]))
            heartbeat_at = datetime.fromisoformat(str(payload["heartbeat_at"]))
        except KeyError as exc:
            raise ValueError(f"missing lease field: {exc.args[0]}") from exc
        if not isinstance(process_id, int):
            raise ValueError(f"invalid process_id: {process_id!r}")
        if not authoritative_repository_root.is_absolute():
            raise ValueError(
                f"invalid authoritative_repository_root: {authoritative_repository_root!s}",
            )
        if authoritative_repository_root.is_symlink():
            raise ValueError(
                f"invalid authoritative_repository_root: {authoritative_repository_root!s}",
            )
        return cls(
            workspace_path_hash=workspace_path_hash,
            process_id=process_id,
            run_id=run_id,
            authoritative_repository_root=authoritative_repository_root,
            heartbeat_at=heartbeat_at,
        )


def lease_path(start_path: Path, *, xdg_state_home: Path | None = None) -> Path:
    return workspace_state_dir(start_path, xdg_state_home=xdg_state_home) / "lease.json"


def write_workspace_lease(
    start_path: Path,
    *,
    run_id: str,
    process_id: int,
    authoritative_repository_root: Path,
    heartbeat_at: datetime | None = None,
    xdg_state_home: Path | None = None,
) -> WorkspaceLease:
    validate_storage_identifier(run_id, field_name="run_id")
    lease = WorkspaceLease(
        workspace_path_hash=workspace_hash(resolve_workspace_identity_root(start_path)),
        process_id=process_id,
        run_id=run_id,
        authoritative_repository_root=authoritative_repository_root.resolve(strict=False),
        heartbeat_at=heartbeat_at or datetime.now(timezone.utc),
    )
    write_json_atomic(lease_path(start_path, xdg_state_home=xdg_state_home), lease.to_json())
    return lease


def read_workspace_lease(
    start_path: Path,
    *,
    xdg_state_home: Path | None = None,
) -> WorkspaceLease | None:
    path = lease_path(start_path, xdg_state_home=xdg_state_home)
    if not path.exists():
        return None
    return WorkspaceLease.from_json(json.loads(path.read_text(encoding="utf-8")))


def clear_workspace_lease(
    start_path: Path,
    *,
    xdg_state_home: Path | None = None,
) -> None:
    path = lease_path(start_path, xdg_state_home=xdg_state_home)
    if not path.exists():
        return
    path.unlink()
    for candidate in (path.parent, path.parent.parent):
        try:
            candidate.rmdir()
        except OSError:
            pass


def update_workspace_lease_authoritative_root(
    start_path: Path,
    *,
    run_id: str,
    authoritative_repository_root: Path,
    xdg_state_home: Path | None = None,
    heartbeat_at: datetime | None = None,
) -> WorkspaceLease:
    lease = read_workspace_lease(start_path, xdg_state_home=xdg_state_home)
    if lease is None:
        raise FileNotFoundError("workspace lease does not exist")
    if lease.run_id != run_id:
        raise ValueError(f"workspace lease belongs to {lease.run_id!r}, not {run_id!r}")
    return write_workspace_lease(
        start_path,
        run_id=run_id,
        process_id=lease.process_id,
        authoritative_repository_root=authoritative_repository_root,
        heartbeat_at=heartbeat_at or datetime.now(timezone.utc),
        xdg_state_home=xdg_state_home,
    )


def lease_is_stale(
    lease: WorkspaceLease,
    *,
    now: datetime,
    timeout: timedelta,
) -> bool:
    return lease.heartbeat_at <= now - timeout


def acquire_workspace_lease(
    start_path: Path,
    *,
    run_id: str,
    process_id: int,
    authoritative_repository_root: Path,
    xdg_state_home: Path | None = None,
    heartbeat_at: datetime | None = None,
    timeout: timedelta = timedelta(minutes=5),
) -> WorkspaceLease:
    current_heartbeat = heartbeat_at or datetime.now(timezone.utc)
    lease = read_workspace_lease(start_path, xdg_state_home=xdg_state_home)
    same_owner = lease is not None and lease.run_id == run_id and lease.process_id == process_id
    if lease is not None and not same_owner and not lease_is_stale(lease, now=current_heartbeat, timeout=timeout):
        raise WorkspaceLeaseConflictError(
            f"healthy workspace lease belongs to {lease.run_id!r} (pid {lease.process_id})",
        )
    return write_workspace_lease(
        start_path,
        run_id=run_id,
        process_id=process_id,
        authoritative_repository_root=authoritative_repository_root,
        heartbeat_at=current_heartbeat,
        xdg_state_home=xdg_state_home,
    )


def heartbeat_workspace_lease(
    start_path: Path,
    *,
    run_id: str,
    xdg_state_home: Path | None = None,
    heartbeat_at: datetime | None = None,
) -> WorkspaceLease:
    lease = read_workspace_lease(start_path, xdg_state_home=xdg_state_home)
    if lease is None:
        raise FileNotFoundError("workspace lease does not exist")
    if lease.run_id != run_id:
        raise WorkspaceLeaseConflictError(
            f"workspace lease belongs to {lease.run_id!r}, not {run_id!r}",
        )
    return write_workspace_lease(
        start_path,
        run_id=run_id,
        process_id=lease.process_id,
        authoritative_repository_root=lease.authoritative_repository_root,
        heartbeat_at=heartbeat_at or datetime.now(timezone.utc),
        xdg_state_home=xdg_state_home,
    )


__all__ = [
    "WorkspaceLeaseConflictError",
    "WorkspaceLease",
    "acquire_workspace_lease",
    "clear_workspace_lease",
    "heartbeat_workspace_lease",
    "lease_path",
    "lease_is_stale",
    "read_workspace_lease",
    "update_workspace_lease_authoritative_root",
    "write_workspace_lease",
]
