"""Helpers for promoting child-scoped artifacts during merge integration."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Sequence

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.worktree import WorktreeHandoff
from ralphception.paths import project_dir

from .files import write_file_atomic, write_json_atomic

ARTIFACT_PIPELINE_DIRECTORY = "artifact-pipeline"
ARTIFACT_DIRECTORY_BY_KIND: dict[str, str] = {
    "intake-summary": "intake-summary",
    "prd": "prd",
    "execution-plan": "execution-plan",
    "loop-plan": "loop-plan",
    "todos": "todos",
}
ARTIFACT_FILE_SUFFIX_BY_KIND: dict[str, str] = {
    "intake-summary": ".md",
    "prd": ".md",
    "execution-plan": ".md",
    "loop-plan": ".md",
    "todos": ".json",
}
WORKFLOW_ARTIFACT_KIND_BY_KEY: dict[str, str] = {
    "intake-summary": "intake",
    "prd": "spec",
    "execution-plan": "plan",
    "loop-plan": "plan",
    "todos": "todo",
}
REQUIRED_ARTIFACT_DIRECTORIES: tuple[str, ...] = (
    ARTIFACT_PIPELINE_DIRECTORY,
    *tuple(
        f"{ARTIFACT_PIPELINE_DIRECTORY}/{directory}"
        for directory in dict.fromkeys(ARTIFACT_DIRECTORY_BY_KIND.values())
    ),
)


def promote_child_scoped_artifacts(
    destination_root: Path,
    handoff: WorktreeHandoff,
    stripped_paths: Sequence[str],
    load_artifact_bytes: Callable[[str], bytes],
) -> list[Path]:
    """Restore declared child-scoped .ralphception artifacts after stripping them."""
    written_paths: list[Path] = []
    declared_paths = {
        artifact_ref.artifact_path
        for artifact_ref in _iter_handoff_artifact_refs(handoff)
    }
    for relative_path in stripped_paths:
        if not _is_child_scoped_ralphception_path(relative_path, handoff.child_run_id):
            continue
        if relative_path not in declared_paths:
            continue
        destination_path = destination_root / relative_path
        write_file_atomic(destination_path, load_artifact_bytes(relative_path))
        written_paths.append(destination_path)
    return written_paths


def promoted_artifact_refs(
    handoff: WorktreeHandoff,
    stripped_paths: Sequence[str],
) -> list[ArtifactRef]:
    """Filter handoff refs down to the artifacts promoted into the merge result."""
    promoted: list[ArtifactRef] = []
    stripped_path_set = set(stripped_paths)
    for artifact_ref in _iter_handoff_artifact_refs(handoff):
        artifact_path = artifact_ref.artifact_path
        if artifact_path in stripped_path_set:
            if _is_child_scoped_ralphception_path(artifact_path, handoff.child_run_id):
                promoted.append(artifact_ref)
            continue
        if not _is_ralphception_path(artifact_path):
            promoted.append(artifact_ref)
    return promoted


def is_ralphception_path(path: str) -> bool:
    """Return whether a path lives under the repo-local Ralphception state root."""
    return path == ".ralphception" or path.startswith(".ralphception/")


def is_child_scoped_ralphception_path(path: str, child_run_id: str) -> bool:
    """Return whether a path is a child-run-scoped artifact path safe to promote."""
    return path.startswith(f".ralphception/runs/{child_run_id}/")


def artifact_directory(repo_root: Path, artifact_kind: str) -> Path:
    """Return the durable base directory for a runtime artifact kind."""
    return (
        project_dir(repo_root.resolve(strict=False))
        / ARTIFACT_PIPELINE_DIRECTORY
        / _artifact_directory_name(artifact_kind)
    )


def artifact_revision_path(repo_root: Path, artifact_kind: str, revision_id: str) -> Path:
    """Return the path for one durable artifact revision."""
    return artifact_directory(repo_root, artifact_kind) / "revisions" / (
        f"{revision_id}{_artifact_file_suffix(artifact_kind)}"
    )


def authoritative_revision_record_path(repo_root: Path, artifact_kind: str) -> Path:
    """Return the path for the authoritative revision pointer record."""
    return artifact_directory(repo_root, artifact_kind) / "authoritative.json"


def read_authoritative_revision(repo_root: Path, artifact_kind: str) -> str | None:
    """Load the authoritative revision identifier for an artifact kind, if present."""
    record_path = authoritative_revision_record_path(repo_root, artifact_kind)
    if not record_path.exists():
        return None
    payload = json.loads(record_path.read_text(encoding="utf-8"))
    revision_id = payload.get("revision_id")
    if not isinstance(revision_id, str) or not revision_id:
        raise ValueError(f"invalid authoritative revision record for {artifact_kind!r}")
    return revision_id


def write_authoritative_revision(repo_root: Path, artifact_kind: str, revision_id: str) -> Path:
    """Persist the authoritative revision identifier for an artifact kind."""
    return write_json_atomic(
        authoritative_revision_record_path(repo_root, artifact_kind),
        {
            "artifact_kind": artifact_kind,
            "revision_id": revision_id,
        },
    )


def next_revision_id(repo_root: Path, artifact_kind: str) -> str:
    """Return the next monotonic revision id for an artifact kind."""
    revisions_directory = artifact_revision_path(repo_root, artifact_kind, "rev-0000").parent
    max_revision = 0
    if revisions_directory.exists():
        for path in revisions_directory.iterdir():
            stem = path.stem
            if not stem.startswith("rev-"):
                continue
            suffix = stem.removeprefix("rev-")
            if suffix.isdigit():
                max_revision = max(max_revision, int(suffix))
    return f"rev-{max_revision + 1:04d}"


def workflow_artifact_kind_for(artifact_kind: str) -> str:
    """Return the workflow-compatible artifact kind for a logical bootstrap artifact key."""
    try:
        return WORKFLOW_ARTIFACT_KIND_BY_KEY[artifact_kind]
    except KeyError as exc:
        raise ValueError(f"unsupported artifact kind: {artifact_kind}") from exc


def _iter_handoff_artifact_refs(handoff: WorktreeHandoff) -> list[ArtifactRef]:
    return [*handoff.artifact_refs, *handoff.verification_artifact_refs]


def _is_ralphception_path(path: str) -> bool:
    return is_ralphception_path(path)


def _is_child_scoped_ralphception_path(path: str, child_run_id: str) -> bool:
    return is_child_scoped_ralphception_path(path, child_run_id)


def _artifact_directory_name(artifact_kind: str) -> str:
    try:
        return ARTIFACT_DIRECTORY_BY_KIND[artifact_kind]
    except KeyError as exc:
        raise ValueError(f"unsupported artifact kind: {artifact_kind}") from exc


def _artifact_file_suffix(artifact_kind: str) -> str:
    try:
        return ARTIFACT_FILE_SUFFIX_BY_KIND[artifact_kind]
    except KeyError as exc:
        raise ValueError(f"unsupported artifact kind: {artifact_kind}") from exc
