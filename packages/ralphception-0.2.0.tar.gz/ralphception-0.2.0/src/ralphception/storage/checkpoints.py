"""Durable checkpoint persistence for run recovery."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.runtime import Checkpoint

from .bootstrap import bootstrap_workspace
from .files import write_json_atomic


def checkpoint_path(repo_root: Path, run_id: str, checkpoint_id: str) -> Path:
    """Return the canonical JSON path for a run checkpoint."""
    repo_root = bootstrap_workspace(repo_root)
    return repo_root / ".ralphception" / "runs" / run_id / "checkpoints" / f"{checkpoint_id}.json"


def write_checkpoint(
    repo_root: Path,
    *,
    checkpoint_id: str,
    run_id: str,
    checkpoint_kind: str,
    event_offsets: dict[str, int],
    bundle_version: int,
    authoritative_root: str,
    active_worktrees: list[str],
    created_at: datetime | None = None,
) -> Checkpoint:
    """Persist a checkpoint record for a run and return the validated model."""
    checkpoint = Checkpoint(
        checkpoint_id=checkpoint_id,
        run_id=run_id,
        checkpoint_kind=checkpoint_kind,
        event_offsets=event_offsets,
        bundle_version=bundle_version,
        authoritative_root=authoritative_root,
        active_worktrees=active_worktrees,
        created_at=created_at or datetime.now(timezone.utc),
    )
    path = checkpoint_path(repo_root, run_id, checkpoint_id)
    write_json_atomic(path, checkpoint.model_dump(mode="json"))
    return checkpoint


def read_checkpoint(repo_root: Path, *, run_id: str, checkpoint_id: str) -> Checkpoint:
    """Load and validate a checkpoint record from its canonical JSON path."""
    path = checkpoint_path(repo_root, run_id, checkpoint_id)
    return Checkpoint.model_validate(json.loads(path.read_text(encoding="utf-8")))
