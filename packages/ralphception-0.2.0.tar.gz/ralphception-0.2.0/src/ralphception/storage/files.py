"""Atomic file write helpers for repo-local durable artifacts."""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path
from typing import Any


def write_file_atomic(path: Path, content: bytes) -> Path:
    """Atomically replace a file with the provided bytes."""
    ensure_directory_tree_durable(path.parent)
    temp_path = path.parent / f".{path.name}.{uuid.uuid4().hex}.tmp"

    try:
        with temp_path.open("wb") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        fsync_directory(path.parent)
    finally:
        if temp_path.exists():
            temp_path.unlink()

    return path


def write_text_atomic(path: Path, content: str, *, encoding: str = "utf-8") -> Path:
    """Atomically replace a text file."""
    return write_file_atomic(path, content.encode(encoding))


def write_markdown_atomic(path: Path, content: str) -> Path:
    """Atomically replace a Markdown file."""
    return write_text_atomic(path, content)


def write_json_atomic(path: Path, data: Any) -> Path:
    """Atomically replace a JSON file with canonical formatting."""
    return write_text_atomic(
        path,
        json.dumps(data, indent=2, sort_keys=True) + "\n",
    )


def fsync_directory(path: Path) -> None:
    """Flush directory metadata for a recently replaced child entry."""
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY

    directory_fd = os.open(path, flags)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def ensure_directory_tree_durable(path: Path) -> None:
    """Create any missing ancestors one at a time and durably persist each entry."""
    missing_directories: list[Path] = []
    current = path

    while not current.exists():
        missing_directories.append(current)
        if current.parent == current:
            break
        current = current.parent

    for directory in reversed(missing_directories):
        directory.mkdir(exist_ok=True)
        fsync_directory(directory.parent)
