"""Append-only per-run event storage."""

from __future__ import annotations

import json
import os
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ralphception.models.events import Event
from pydantic import ValidationError

from .bootstrap import bootstrap_workspace
from .files import ensure_directory_tree_durable, fsync_directory


class EventLogCorruptionError(RuntimeError):
    """Raised when a persisted event log cannot be replayed safely."""


def _event_fingerprint(event: Event) -> dict[str, Any]:
    fingerprint = event.model_dump(mode="json")
    fingerprint.pop("sequence")
    return fingerprint


class EventStore:
    """Persist and replay canonical per-run event logs."""

    def __init__(self, repo_root: Path) -> None:
        self.repo_root = bootstrap_workspace(repo_root)

    def append(
        self,
        *,
        event_id: str,
        run_id: str,
        event_type: str,
        source: str,
        payload: dict[str, Any],
        occurred_at: datetime | None = None,
        sequence: int | None = None,
        schema_version: int = 1,
        stage_id: str | None = None,
        task_id: str | None = None,
    ) -> Event:
        raw_events = self._load_raw_events(run_id)
        by_event_id: dict[str, Event] = {}
        for event in raw_events:
            by_event_id.setdefault(event.event_id, event)
        if event_id in by_event_id:
            existing_event = by_event_id[event_id]
            candidate_event = Event(
                event_id=event_id,
                schema_version=schema_version,
                run_id=run_id,
                stage_id=stage_id,
                task_id=task_id,
                event_type=event_type,
                sequence=existing_event.sequence if sequence is None else sequence,
                occurred_at=existing_event.occurred_at if occurred_at is None else occurred_at,
                source=source,
                payload=payload,
            )
            if _event_fingerprint(candidate_event) != _event_fingerprint(existing_event):
                raise EventLogCorruptionError(
                    f"Corrupt event log for run {run_id}: conflicting duplicate event_id {event_id}",
                )
            return existing_event

        expected_sequence = 1 if not raw_events else raw_events[-1].sequence + 1
        if sequence is None:
            final_sequence = expected_sequence
        elif sequence != expected_sequence:
            raise ValueError(
                f"sequence must be {expected_sequence} for run {run_id}, got {sequence}",
            )
        else:
            final_sequence = sequence

        event = Event(
            event_id=event_id,
            schema_version=schema_version,
            run_id=run_id,
            stage_id=stage_id,
            task_id=task_id,
            event_type=event_type,
            sequence=final_sequence,
            occurred_at=occurred_at or datetime.now(timezone.utc),
            source=source,
            payload=payload,
        )

        run_path = self.run_path(run_id)
        ensure_directory_tree_durable(run_path.parent)
        with run_path.open("ab") as handle:
            handle.write((json.dumps(event.model_dump(mode="json"), sort_keys=True) + "\n").encode("utf-8"))
            handle.flush()
            os.fsync(handle.fileno())
        fsync_directory(run_path.parent)

        return event

    def read_run(self, run_id: str) -> list[Event]:
        raw_events = self._load_raw_events(run_id)

        deduplicated_events: list[Event] = []
        seen_event_ids: set[str] = set()

        for event in raw_events:
            if event.event_id in seen_event_ids:
                continue
            seen_event_ids.add(event.event_id)
            deduplicated_events.append(event)

        return deduplicated_events

    def replay_run(self, run_id: str) -> Iterator[Event]:
        """Yield events for a run in canonical replay order."""
        yield from self.read_run(run_id)

    def run_path(self, run_id: str) -> Path:
        """Return the canonical JSONL path for a run's event log."""
        return self.repo_root / ".ralphception" / "events" / f"{run_id}.jsonl"

    def _load_raw_events(self, run_id: str) -> list[Event]:
        run_path = self.run_path(run_id)
        if not run_path.exists():
            return []

        raw_events: list[Event] = []

        with run_path.open(encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                raw_line = line.strip()
                if not raw_line:
                    continue
                try:
                    event = Event.model_validate(json.loads(raw_line))
                except json.JSONDecodeError as exc:
                    raise EventLogCorruptionError(
                        f"Corrupt event log for run {run_id} at line {line_number}: invalid JSON",
                    ) from exc
                except ValidationError as exc:
                    raise EventLogCorruptionError(
                        f"Corrupt event log for run {run_id} at line {line_number}: invalid event record",
                    ) from exc

                raw_events.append(event)

        previous_sequence: int | None = None
        for event in raw_events:
            if previous_sequence is not None:
                if event.sequence == previous_sequence:
                    raise EventLogCorruptionError(
                        f"Corrupt event log for run {run_id}: duplicate sequence {event.sequence}",
                    )
                if event.sequence < previous_sequence:
                    raise EventLogCorruptionError(
                        f"Corrupt event log for run {run_id}: non-monotonic sequence {event.sequence} after {previous_sequence}",
                    )
            previous_sequence = event.sequence

        expected_sequence = 1
        for event in raw_events:
            if event.sequence != expected_sequence:
                raise EventLogCorruptionError(
                    f"Corrupt event log for run {run_id}: expected sequence {expected_sequence}, got {event.sequence}",
                )
            expected_sequence += 1

        canonical_by_event_id: dict[str, dict[str, Any]] = {}
        for event in raw_events:
            fingerprint = _event_fingerprint(event)
            existing = canonical_by_event_id.get(event.event_id)
            if existing is None:
                canonical_by_event_id[event.event_id] = fingerprint
                continue
            if fingerprint != existing:
                raise EventLogCorruptionError(
                    f"Corrupt event log for run {run_id}: conflicting duplicate event_id {event.event_id}",
                )

        return raw_events
