"""Custom terminal state modeled after Codex's ratatui wrapper."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from .text import trim_ansi_text


class Backend(Protocol):
    def size(self) -> "Size": ...
    def get_cursor_position(self) -> "Position": ...
    def write(self, data: str) -> None: ...
    def flush(self) -> None: ...


@dataclass(frozen=True, slots=True)
class Size:
    width: int
    height: int


@dataclass(frozen=True, slots=True)
class Position:
    x: int
    y: int


@dataclass(frozen=True, slots=True)
class Rect:
    x: int
    y: int
    width: int
    height: int

    @property
    def top(self) -> int:
        return self.y

    @property
    def bottom(self) -> int:
        return self.y + self.height

    @property
    def left(self) -> int:
        return self.x


@dataclass(slots=True)
class Frame:
    """A simple line-oriented frame for the Python port."""

    area: Rect
    lines: list[str] = field(default_factory=list)
    cursor_position: tuple[int, int] | None = None

    def set_cursor_position(self, position: Position | tuple[int, int]) -> None:
        if isinstance(position, tuple):
            self.cursor_position = position
            return
        self.cursor_position = (position.x, position.y)


@dataclass(slots=True)
class CustomTerminal:
    backend: Backend
    viewport_area: Rect
    last_known_screen_size: Size
    last_known_cursor_pos: Position
    home_viewport: bool = False
    visible_history_rows: int = 0
    _last_frame_area: Rect | None = None
    _clear_from_previous_top_on_next_draw: bool = False

    @classmethod
    def with_options(cls, backend: Backend) -> "CustomTerminal":
        screen_size = backend.size()
        cursor_pos = backend.get_cursor_position()
        return cls(
            backend=backend,
            viewport_area=Rect(x=0, y=cursor_pos.y, width=0, height=0),
            last_known_screen_size=screen_size,
            last_known_cursor_pos=cursor_pos,
            home_viewport=False,
            visible_history_rows=0,
        )

    @classmethod
    def with_home_viewport(cls, backend: Backend) -> "CustomTerminal":
        screen_size = backend.size()
        home_pos = Position(x=0, y=0)
        return cls(
            backend=backend,
            viewport_area=Rect(x=0, y=0, width=0, height=0),
            last_known_screen_size=screen_size,
            last_known_cursor_pos=home_pos,
            home_viewport=True,
            visible_history_rows=0,
        )

    def size(self) -> Size:
        return self.backend.size()

    def resize(self, screen_size: Size) -> None:
        self.last_known_screen_size = screen_size

    def get_cursor_position(self) -> Position:
        return self.backend.get_cursor_position()

    def autoresize(self) -> None:
        screen_size = self.size()
        if screen_size != self.last_known_screen_size:
            self.resize(screen_size)

    def set_viewport_area(self, area: Rect) -> None:
        self.viewport_area = area
        self.visible_history_rows = min(self.visible_history_rows, area.top)

    def note_history_rows_inserted(self, inserted_rows: int) -> None:
        self.visible_history_rows = min(
            self.visible_history_rows + max(0, inserted_rows),
            self.viewport_area.top,
        )

    def update_viewport_height(self, height: int) -> None:
        if height < 0:
            raise ValueError("height must be non-negative")
        size = self.size()
        area = self.viewport_area
        next_height = min(height, size.height)
        next_width = size.width
        next_y = area.y
        if next_y + next_height > size.height:
            next_y = max(0, size.height - next_height)
        self.set_viewport_area(Rect(x=0, y=next_y, width=next_width, height=next_height))

    def clear(self) -> None:
        for row in range(self.viewport_area.top, self.viewport_area.bottom):
            self.backend.write(_move_to(0, row))
            self.backend.write("\x1b[2K")

    def clear_visible_screen(self) -> None:
        size = self.size()
        self.backend.write("\x1b[H\x1b[2J")
        self.last_known_cursor_pos = Position(x=0, y=0)
        self._last_frame_area = Rect(x=0, y=0, width=size.width, height=size.height)

    def request_resize_reflow(self) -> None:
        self._clear_from_previous_top_on_next_draw = True

    def draw(self, render_callback) -> None:
        frame = Frame(area=self.viewport_area, lines=[])
        render_callback(frame)
        self._render_frame(frame)

    def _render_frame(self, frame: Frame) -> None:
        previous_area = self._last_frame_area or frame.area
        clear_top = frame.area.top
        if self._clear_from_previous_top_on_next_draw:
            clear_top = min(previous_area.top, frame.area.top)
        clear_bottom = max(previous_area.bottom, frame.area.bottom)
        for row in range(clear_top, clear_bottom):
            if row >= self.last_known_screen_size.height:
                break
            self.backend.write(_move_to(0, row))
            self.backend.write("\x1b[2K")

        width = max(1, frame.area.width)
        for index, line in enumerate(frame.lines[: frame.area.height]):
            row = frame.area.top + index
            self.backend.write(_move_to(0, row))
            self.backend.write(_trim_to_width(line, width))

        if frame.cursor_position is not None:
            x, y = frame.cursor_position
            self.last_known_cursor_pos = Position(x=x, y=y)
            self.backend.write(_move_to(x, y))
        self._last_frame_area = frame.area
        self._clear_from_previous_top_on_next_draw = False


BufferFrame = Frame


def _move_to(x: int, y: int) -> str:
    return f"\x1b[{y + 1};{x + 1}H"


def _trim_to_width(line: str, width: int) -> str:
    return trim_ansi_text(line, width)
