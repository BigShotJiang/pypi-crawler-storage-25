"""Minimal styled text helpers for low-level terminal rendering."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Iterable

from .palette import IndexedColor, best_color, get_terminal_palette
from .theme import RgbColor, user_surface_rgb

_SGR_RE = re.compile(r"\x1b\[[0-9;]*m")

_FG_CODES: dict[str, str] = {
    "cyan": "36",
    "magenta": "35",
    "bright_black": "90",
    "yellow": "33",
    "green": "32",
    "light_blue": "94",
}

_BG_CODES: dict[str, str] = {
    "bright_black": "100",
}

_surface_terminal_background: RgbColor | None = None


def _sgr_code(color: str | RgbColor | IndexedColor, *, foreground: bool) -> str:
    if isinstance(color, tuple):
        prefix = "38" if foreground else "48"
        return f"{prefix};2;{color[0]};{color[1]};{color[2]}"
    if isinstance(color, IndexedColor):
        prefix = "38" if foreground else "48"
        return f"{prefix};5;{color.index}"
    codes = _FG_CODES if foreground else _BG_CODES
    return codes[color]


def set_surface_terminal_background(color: RgbColor | None) -> None:
    global _surface_terminal_background
    _surface_terminal_background = color


def reset_surface_theme() -> None:
    set_surface_terminal_background(None)


def user_surface_style() -> "Style":
    terminal_bg = _surface_terminal_background
    if terminal_bg is None:
        terminal_bg = get_terminal_palette().bg
    if terminal_bg is None:
        return Style()
    surface_bg = best_color(
        user_surface_rgb(terminal_bg),
        color_level=get_terminal_palette().color_level,
    )
    if surface_bg is None:
        return Style()
    return Style(bg=surface_bg)


@dataclass(frozen=True, slots=True)
class Style:
    bold: bool = False
    dim: bool = False
    italic: bool = False
    underline: bool = False
    fg: str | RgbColor | IndexedColor | None = None
    bg: str | RgbColor | IndexedColor | None = None

    def sgr_prefix(self) -> str:
        codes: list[str] = []
        if self.bold:
            codes.append("1")
        if self.dim:
            codes.append("2")
        if self.italic:
            codes.append("3")
        if self.underline:
            codes.append("4")
        if self.fg:
            codes.append(_sgr_code(self.fg, foreground=True))
        if self.bg:
            codes.append(_sgr_code(self.bg, foreground=False))
        if not codes:
            return ""
        return f"\x1b[{';'.join(codes)}m"


@dataclass(frozen=True, slots=True)
class StyledSpan:
    text: str
    style: Style = Style()


@dataclass(frozen=True, slots=True)
class StyledLine:
    spans: tuple[StyledSpan, ...]

    def __iter__(self):
        return iter(self.spans)


def plain_line(text: str) -> StyledLine:
    return StyledLine((StyledSpan(text),))


def render_styled_line(line: StyledLine) -> str:
    rendered: list[str] = []
    for span in line.spans:
        prefix = span.style.sgr_prefix()
        if prefix:
            rendered.append(prefix)
            rendered.append(span.text)
            rendered.append("\x1b[0m")
        else:
            rendered.append(span.text)
    return "".join(rendered)


def strip_ansi(text: str) -> str:
    return _SGR_RE.sub("", text)


def visible_width(value: str | StyledLine) -> int:
    if isinstance(value, StyledLine):
        return sum(len(span.text) for span in value.spans)
    return len(strip_ansi(value))


def trim_styled_line(line: StyledLine, width: int) -> StyledLine:
    if width <= 0:
        return plain_line("")
    remaining = width
    spans: list[StyledSpan] = []
    for span in line.spans:
        if remaining <= 0:
            break
        if len(span.text) <= remaining:
            spans.append(span)
            remaining -= len(span.text)
            continue
        spans.append(StyledSpan(span.text[:remaining], span.style))
        remaining = 0
    if not spans:
        return plain_line("")
    return StyledLine(tuple(spans))


def trim_styled_line_with_ellipsis(
    line: StyledLine,
    width: int,
    *,
    ellipsis_style: Style | None = None,
) -> StyledLine:
    if width <= 0:
        return plain_line("")
    if visible_width(line) <= width:
        return line
    if width == 1:
        return StyledLine((StyledSpan("…", ellipsis_style or Style(dim=True)),))
    trimmed = trim_styled_line(line, width - 1)
    return StyledLine((*trimmed.spans, StyledSpan("…", ellipsis_style or Style(dim=True))))


def pad_styled_line(line: StyledLine, width: int, *, pad_style: Style | None = None) -> StyledLine:
    padding = max(0, width - visible_width(line))
    if padding == 0:
        return line
    return StyledLine((*line.spans, StyledSpan(" " * padding, pad_style or Style())))


def trim_ansi_text(text: str, width: int) -> str:
    if width <= 0:
        return ""
    visible = 0
    index = 0
    active_style = False
    output: list[str] = []
    while index < len(text) and visible < width:
        match = _SGR_RE.match(text, index)
        if match is not None:
            seq = match.group(0)
            output.append(seq)
            active_style = seq != "\x1b[0m"
            index = match.end()
            continue
        output.append(text[index])
        visible += 1
        index += 1
    if active_style:
        output.append("\x1b[0m")
    return "".join(output)


def join_spans(spans: Iterable[StyledSpan]) -> StyledLine:
    return StyledLine(tuple(spans))
