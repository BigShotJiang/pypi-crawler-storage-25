"""Low-level composer surface primitives."""

from __future__ import annotations

from .text import (
    Style,
    StyledSpan,
    join_spans,
    pad_styled_line,
    plain_line,
    render_styled_line,
    user_surface_style,
)

PROMPT_PREFIX = "› "


def render_composer_surface(
    *,
    value: str,
    placeholder: str,
    width: int,
    prompt_prefix: str = PROMPT_PREFIX,
    content_inset: int = 0,
) -> list[str]:
    surface = user_surface_style()
    prompt_text = value or placeholder
    prompt_style = surface if value else Style(dim=True, bg=surface.bg)
    prefix_style = Style(dim=True, bg=surface.bg)
    inset = max(0, content_inset)
    blank_line = render_styled_line(pad_styled_line(plain_line(""), width, pad_style=surface))
    prompt_line = render_styled_line(
        pad_styled_line(
            join_spans(
                (
                    StyledSpan(" " * inset, Style(bg=surface.bg)),
                    StyledSpan(prompt_prefix, prefix_style),
                    StyledSpan(prompt_text, prompt_style),
                )
            ),
            width,
            pad_style=surface,
        )
    )
    return [blank_line, prompt_line, blank_line]


def composer_cursor_pos(
    *,
    area_y: int,
    value: str,
    prompt_prefix: str = PROMPT_PREFIX,
    content_inset: int = 0,
) -> tuple[int, int]:
    return (max(0, content_inset) + len(prompt_prefix) + len(value), area_y + 1)
