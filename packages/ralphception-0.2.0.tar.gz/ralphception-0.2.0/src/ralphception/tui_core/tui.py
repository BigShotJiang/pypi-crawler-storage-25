"""Codex-style terminal wrapper with pending committed-history insertion."""

from __future__ import annotations

from dataclasses import dataclass, field
from io import UnsupportedOperation
import os
import re
import select
import shutil
import sys
import time
from typing import Any, Protocol, TextIO

try:
    import termios
    import tty
except ImportError:  # pragma: no cover
    termios = None  # type: ignore[assignment]
    tty = None  # type: ignore[assignment]

from ralphception.codex_tui.insert_history import insert_history_lines

from .palette import detect_color_level, requery_terminal_palette, set_terminal_palette
from .terminal import CustomTerminal, Position, Rect, Size
from .text import reset_surface_theme, set_surface_terminal_background


class TerminalBackend(Protocol):
    def size(self) -> Size: ...
    def get_cursor_position(self) -> Position: ...
    def write(self, data: str) -> None: ...
    def flush(self) -> None: ...


@dataclass(slots=True)
class AnsiBackend:
    stdout: TextIO = sys.stdout
    stdin: TextIO = sys.stdin
    _stdout_fd: int | None = field(init=False)
    _stdin_fd: int | None = field(init=False)
    _saved_termios: Any = field(default=None, init=False)

    def __post_init__(self) -> None:
        self._stdout_fd = _safe_fileno(self.stdout)
        self._stdin_fd = _safe_fileno(self.stdin)

    def size(self) -> Size:
        if self._stdout_fd is None:
            terminal_size = shutil.get_terminal_size(fallback=(80, 24))
            return Size(width=terminal_size.columns, height=terminal_size.lines)
        try:
            terminal_size = os.get_terminal_size(self._stdout_fd)
        except OSError:
            terminal_size = shutil.get_terminal_size(fallback=(80, 24))
        return Size(width=terminal_size.columns, height=terminal_size.lines)

    def get_cursor_position(self) -> Position:
        position = self._query_cursor_position()
        if position is not None:
            return position
        return Position(x=0, y=0)

    def get_default_background(self) -> tuple[int, int, int] | None:
        report = self._query_default_background_report()
        if report is None:
            return _background_from_colorfgbg(os.environ.get("COLORFGBG"))
        return _parse_default_background_report(report)

    def get_default_foreground(self) -> tuple[int, int, int] | None:
        report = self._query_default_foreground_report()
        if report is None:
            return _foreground_from_colorfgbg(os.environ.get("COLORFGBG"))
        return _parse_default_foreground_report(report)

    def get_stdout_color_level(self):
        return detect_color_level(env=os.environ, is_tty=self._stdout_fd is not None and os.isatty(self._stdout_fd))

    def write(self, data: str) -> None:
        self.stdout.write(data)

    def flush(self) -> None:
        self.stdout.flush()

    def enter_raw_mode(self) -> None:
        if termios is None or tty is None or self._stdin_fd is None:
            return
        try:
            self._saved_termios = termios.tcgetattr(self._stdin_fd)
            tty.setraw(self._stdin_fd)
        except termios.error:
            self._saved_termios = None

    def leave_raw_mode(self) -> None:
        if termios is None or self._saved_termios is None or self._stdin_fd is None:
            return
        try:
            termios.tcsetattr(self._stdin_fd, termios.TCSADRAIN, self._saved_termios)
        except termios.error:
            pass
        self._saved_termios = None

    def _query_cursor_position(self) -> Position | None:
        if self._stdin_fd is None or self._stdout_fd is None:
            return None
        if not os.isatty(self._stdin_fd) or not os.isatty(self._stdout_fd):
            return None
        self.write("\x1b[6n")
        self.flush()
        report = self._read_cursor_report()
        if report is None:
            return None
        return _parse_cursor_report(report)

    def _query_default_background_report(self) -> bytes | None:
        if self._stdin_fd is None or self._stdout_fd is None:
            return None
        if not os.isatty(self._stdin_fd) or not os.isatty(self._stdout_fd):
            return None
        self.write("\x1b]11;?\x07")
        self.flush()
        return self._read_osc_response()

    def _query_default_foreground_report(self) -> bytes | None:
        if self._stdin_fd is None or self._stdout_fd is None:
            return None
        if not os.isatty(self._stdin_fd) or not os.isatty(self._stdout_fd):
            return None
        self.write("\x1b]10;?\x07")
        self.flush()
        return self._read_osc_response()

    def _read_cursor_report(self, timeout_seconds: float = 0.1) -> bytes | None:
        if self._stdin_fd is None:
            return None
        deadline = time.monotonic() + timeout_seconds
        chunks = bytearray()
        while time.monotonic() < deadline:
            remaining = max(0.0, deadline - time.monotonic())
            ready, _, _ = select.select([self._stdin_fd], [], [], remaining)
            if not ready:
                break
            try:
                chunk = os.read(self._stdin_fd, 64)
            except OSError:
                return None
            if not chunk:
                break
            chunks.extend(chunk)
            if b"R" in chunk:
                break
        if not chunks:
            return None
        return bytes(chunks)

    def _read_osc_response(self, timeout_seconds: float = 0.1) -> bytes | None:
        if self._stdin_fd is None:
            return None
        deadline = time.monotonic() + timeout_seconds
        chunks = bytearray()
        while time.monotonic() < deadline:
            remaining = max(0.0, deadline - time.monotonic())
            ready, _, _ = select.select([self._stdin_fd], [], [], remaining)
            if not ready:
                break
            try:
                chunk = os.read(self._stdin_fd, 64)
            except OSError:
                return None
            if not chunk:
                break
            chunks.extend(chunk)
            if b"\x07" in chunks or b"\x1b\\" in chunks:
                break
        if not chunks:
            return None
        return bytes(chunks)


@dataclass(slots=True)
class Tui:
    terminal: CustomTerminal
    pending_history_lines: list[str] = field(default_factory=list)

    @classmethod
    def init(cls) -> "Tui":
        backend = AnsiBackend()
        backend.enter_raw_mode()
        reset_surface_theme()
        tui = cls(terminal=CustomTerminal.with_options(backend))
        tui._refresh_terminal_palette(requery=False)
        return tui

    def close(self) -> None:
        backend = self.terminal.backend
        leave_raw_mode = getattr(backend, "leave_raw_mode", None)
        if callable(leave_raw_mode):
            leave_raw_mode()

    def insert_history_lines(self, lines: list[str]) -> None:
        self.pending_history_lines.extend(lines)

    def clear_pending_history_lines(self) -> None:
        self.pending_history_lines.clear()

    def draw(self, height: int, draw_fn) -> None:
        pending_area = self._pending_viewport_area()
        size_before_resize = self.terminal.size()
        screen_resized = size_before_resize != self.terminal.last_known_screen_size
        self.terminal.autoresize()
        self.terminal.backend.write("\x1b[?2026h")
        if screen_resized:
            self._refresh_terminal_palette(requery=True)
            self.terminal.request_resize_reflow()
        if pending_area is not None:
            self.terminal.set_viewport_area(pending_area)
        size = self.terminal.size()
        viewport_height = min(max(0, height), size.height)
        previous_area = self.terminal.viewport_area
        area = previous_area
        area = Rect(x=0, y=area.y, width=size.width, height=viewport_height)
        if (
            not self.terminal.home_viewport
            and previous_area.height == 0
            and viewport_height > 0
        ):
            area = Rect(
                x=0,
                y=max(0, size.height - viewport_height),
                width=size.width,
                height=viewport_height,
            )
        if previous_area.bottom == size.height and viewport_height < previous_area.height:
            area = Rect(
                x=0,
                y=max(0, size.height - viewport_height),
                width=size.width,
                height=viewport_height,
            )
        if area.bottom > size.height:
            _scroll_region_up(
                self.terminal.backend,
                region_top=0,
                region_bottom=area.top,
                scroll_by=area.bottom - size.height,
            )
            area = Rect(
                x=0,
                y=max(0, size.height - viewport_height),
                width=size.width,
                height=viewport_height,
            )
        if area != self.terminal.viewport_area:
            self.terminal.clear()
            self.terminal.set_viewport_area(area)

        if self.pending_history_lines:
            insert_history_lines(self.terminal, self.pending_history_lines)
            self.pending_history_lines.clear()

        self.terminal.draw(draw_fn)
        self.terminal.backend.write("\x1b[?2026l")
        self.terminal.backend.flush()

    def _refresh_terminal_palette(self, *, requery: bool) -> None:
        backend = self.terminal.backend
        fg_getter = getattr(backend, "get_default_foreground", None)
        bg_getter = getattr(backend, "get_default_background", None)
        level_getter = getattr(backend, "get_stdout_color_level", None)
        fg = fg_getter() if callable(fg_getter) else None
        bg = bg_getter() if callable(bg_getter) else None
        color_level = level_getter() if callable(level_getter) else None
        set_surface_terminal_background(bg)
        if requery:
            requery_terminal_palette(fg=fg, bg=bg, color_level=color_level)
            return
        set_terminal_palette(fg=fg, bg=bg, color_level=color_level)

    def _pending_viewport_area(self) -> Rect | None:
        terminal = self.terminal
        screen_size = terminal.size()
        if screen_size == terminal.last_known_screen_size:
            return None
        cursor_pos = terminal.get_cursor_position()
        last_known_cursor_pos = terminal.last_known_cursor_pos
        if cursor_pos.y == last_known_cursor_pos.y:
            return None
        offset_y = cursor_pos.y - last_known_cursor_pos.y
        area = terminal.viewport_area
        return Rect(
            x=area.x,
            y=max(0, area.y + offset_y),
            width=area.width,
            height=area.height,
        )


def _scroll_region_up(backend: TerminalBackend, *, region_top: int, region_bottom: int, scroll_by: int) -> None:
    if scroll_by <= 0 or region_bottom <= region_top:
        return
    top_1based = region_top + 1
    bottom_1based = region_bottom
    backend.write(f"\x1b[{top_1based};{bottom_1based}r")
    backend.write(_move_to(0, region_bottom - 1))
    backend.write("\x1bD" * scroll_by)
    backend.write("\x1b[r")


def _move_to(x: int, y: int) -> str:
    return f"\x1b[{y + 1};{x + 1}H"


_CURSOR_REPORT = re.compile(rb"\x1b\[(\d+);(\d+)R")
_DEFAULT_FOREGROUND_REPORT = re.compile(rb"\x1b\]10;rgb:([0-9a-fA-F]+)/([0-9a-fA-F]+)/([0-9a-fA-F]+)(?:\x07|\x1b\\)")
_DEFAULT_BACKGROUND_REPORT = re.compile(rb"\x1b\]11;rgb:([0-9a-fA-F]+)/([0-9a-fA-F]+)/([0-9a-fA-F]+)(?:\x07|\x1b\\)")


def _parse_cursor_report(report: bytes) -> Position | None:
    match = _CURSOR_REPORT.search(report)
    if match is None:
        return None
    row = int(match.group(1))
    column = int(match.group(2))
    return Position(x=max(0, column - 1), y=max(0, row - 1))


def _parse_default_background_report(report: bytes) -> tuple[int, int, int] | None:
    return _parse_default_color_report(_DEFAULT_BACKGROUND_REPORT, report)


def _parse_default_foreground_report(report: bytes) -> tuple[int, int, int] | None:
    return _parse_default_color_report(_DEFAULT_FOREGROUND_REPORT, report)


def _parse_default_color_report(pattern: re.Pattern[bytes], report: bytes) -> tuple[int, int, int] | None:
    match = pattern.search(report)
    if match is None:
        return None
    channels = []
    for group in match.groups():
        value = group.decode("ascii")
        if len(value) <= 2:
            channels.append(int(value, 16))
            continue
        channels.append(int(value[:2], 16))
    return tuple(channels)


_SYSTEM_COLORS: tuple[tuple[int, int, int], ...] = (
    (0, 0, 0),
    (205, 0, 0),
    (0, 205, 0),
    (205, 205, 0),
    (0, 0, 238),
    (205, 0, 205),
    (0, 205, 205),
    (229, 229, 229),
    (127, 127, 127),
    (255, 0, 0),
    (0, 255, 0),
    (255, 255, 0),
    (92, 92, 255),
    (255, 0, 255),
    (0, 255, 255),
    (255, 255, 255),
)


def _background_from_colorfgbg(value: str | None) -> tuple[int, int, int] | None:
    colors = _colors_from_colorfgbg(value)
    if colors is None:
        return None
    _, background = colors
    return background


def _foreground_from_colorfgbg(value: str | None) -> tuple[int, int, int] | None:
    colors = _colors_from_colorfgbg(value)
    if colors is None:
        return None
    foreground, _ = colors
    return foreground


def _colors_from_colorfgbg(value: str | None) -> tuple[tuple[int, int, int], tuple[int, int, int]] | None:
    if not value:
        return None
    try:
        foreground_index = int(value.split(";")[0])
        background_index = int(value.split(";")[-1])
    except (ValueError, IndexError):
        return None
    if not (0 <= foreground_index < len(_SYSTEM_COLORS)):
        return None
    if not (0 <= background_index < len(_SYSTEM_COLORS)):
        return None
    return _SYSTEM_COLORS[foreground_index], _SYSTEM_COLORS[background_index]


def _safe_fileno(handle: TextIO) -> int | None:
    try:
        return handle.fileno()
    except (AttributeError, OSError, UnsupportedOperation):
        return None
