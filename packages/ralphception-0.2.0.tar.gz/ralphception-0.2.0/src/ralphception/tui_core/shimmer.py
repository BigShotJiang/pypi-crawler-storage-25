"""Codex-style shimmer and busy-glyph primitives."""

from __future__ import annotations

import math
from time import monotonic

from .palette import ColorLevel, TerminalPalette, get_terminal_palette
from .text import Style, StyledSpan
from .theme import blend

_PROCESS_START = monotonic()


def _animation_elapsed(now: float | None = None) -> float:
    if now is not None:
        return max(0.0, now)
    return max(0.0, monotonic() - _PROCESS_START)


def shimmer_spans(
    text: str,
    *,
    now: float | None = None,
    palette: TerminalPalette | None = None,
) -> tuple[StyledSpan, ...]:
    chars = tuple(text)
    if not chars:
        return ()

    terminal_palette = palette or get_terminal_palette()
    timestamp = _animation_elapsed(now)
    padding = 10
    period = len(chars) + padding * 2
    sweep_seconds = 2.0
    pos = int((timestamp % sweep_seconds) / sweep_seconds * period)
    band_half_width = 5.0
    has_true_color = terminal_palette.color_level == ColorLevel.TRUECOLOR
    base_color = terminal_palette.fg or (128, 128, 128)
    highlight_color = terminal_palette.bg or (255, 255, 255)

    spans: list[StyledSpan] = []
    for index, char in enumerate(chars):
        distance = abs((index + padding) - pos)
        intensity = 0.0
        if distance <= band_half_width:
            x = math.pi * (distance / band_half_width)
            intensity = 0.5 * (1.0 + math.cos(x))
        if has_true_color:
            color = blend(highlight_color, base_color, max(0.0, min(1.0, intensity * 0.9)))
            spans.append(StyledSpan(char, Style(fg=color, bold=True)))
            continue
        if intensity < 0.2:
            style = Style(dim=True)
        elif intensity < 0.6:
            style = Style()
        else:
            style = Style(bold=True)
        spans.append(StyledSpan(char, style))
    return tuple(spans)


def spinner_span(
    *,
    animations_enabled: bool,
    now: float | None = None,
    palette: TerminalPalette | None = None,
) -> StyledSpan:
    if not animations_enabled:
        return StyledSpan("•", Style(dim=True))

    terminal_palette = palette or get_terminal_palette()
    if terminal_palette.color_level == ColorLevel.TRUECOLOR:
        return shimmer_spans("•", now=now, palette=terminal_palette)[0]

    blink_on = int((_animation_elapsed(now) * 1000) // 600) % 2 == 0
    if blink_on:
        return StyledSpan("•", Style())
    return StyledSpan("◦", Style(dim=True))
