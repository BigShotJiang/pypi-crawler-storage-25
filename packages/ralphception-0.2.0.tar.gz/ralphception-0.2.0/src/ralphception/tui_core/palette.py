"""Terminal palette and color-capability helpers for low-level TUI primitives."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
import os
from typing import Mapping

from .theme import RgbColor


class ColorLevel(StrEnum):
    TRUECOLOR = "truecolor"
    ANSI256 = "ansi256"
    ANSI16 = "ansi16"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class TerminalPalette:
    fg: RgbColor | None = None
    bg: RgbColor | None = None
    color_level: ColorLevel = ColorLevel.UNKNOWN


@dataclass(frozen=True, slots=True)
class IndexedColor:
    index: int


_terminal_palette = TerminalPalette()
_palette_version = 0


def get_terminal_palette() -> TerminalPalette:
    return _terminal_palette


def set_terminal_palette(
    *,
    fg: RgbColor | None = None,
    bg: RgbColor | None = None,
    color_level: ColorLevel | None = None,
) -> None:
    global _terminal_palette
    previous = _terminal_palette
    _terminal_palette = TerminalPalette(
        fg=fg,
        bg=bg,
        color_level=color_level or previous.color_level,
    )


def requery_terminal_palette(
    *,
    fg: RgbColor | None = None,
    bg: RgbColor | None = None,
    color_level: ColorLevel | None = None,
) -> TerminalPalette:
    global _palette_version
    set_terminal_palette(fg=fg, bg=bg, color_level=color_level)
    _palette_version += 1
    return _terminal_palette


def palette_version() -> int:
    return _palette_version


def reset_terminal_palette() -> None:
    global _terminal_palette, _palette_version
    _terminal_palette = TerminalPalette()
    _palette_version = 0


def detect_color_level(
    *,
    env: Mapping[str, str] | None = None,
    is_tty: bool = True,
) -> ColorLevel:
    variables = os.environ if env is None else env
    if not is_tty:
        return ColorLevel.UNKNOWN
    color_term = variables.get("COLORTERM", "").lower()
    if "truecolor" in color_term or "24bit" in color_term:
        return ColorLevel.TRUECOLOR
    term = variables.get("TERM", "").lower()
    if "256color" in term:
        return ColorLevel.ANSI256
    if term:
        return ColorLevel.ANSI16
    return ColorLevel.UNKNOWN


def best_color(target: RgbColor, *, color_level: ColorLevel) -> RgbColor | IndexedColor | None:
    if color_level == ColorLevel.TRUECOLOR:
        return target
    if color_level == ColorLevel.ANSI256:
        best = min(_xterm_fixed_colors(), key=lambda item: _perceptual_distance(item[1], target))
        return IndexedColor(best[0])
    return None


def _xterm_fixed_colors() -> list[tuple[int, RgbColor]]:
    colors: list[tuple[int, RgbColor]] = []
    cube_values = (0, 95, 135, 175, 215, 255)
    index = 16
    for r in cube_values:
        for g in cube_values:
            for b in cube_values:
                colors.append((index, (r, g, b)))
                index += 1
    for step in range(24):
        value = 8 + step * 10
        colors.append((232 + step, (value, value, value)))
    return colors


def _perceptual_distance(a: RgbColor, b: RgbColor) -> float:
    def srgb_to_linear(c: int) -> float:
        value = c / 255.0
        if value <= 0.04045:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    def rgb_to_xyz(rgb: RgbColor) -> tuple[float, float, float]:
        r, g, blue = (srgb_to_linear(channel) for channel in rgb)
        x = r * 0.4124 + g * 0.3576 + blue * 0.1805
        y = r * 0.2126 + g * 0.7152 + blue * 0.0722
        z = r * 0.0193 + g * 0.1192 + blue * 0.9505
        return x, y, z

    def xyz_to_lab(x: float, y: float, z: float) -> tuple[float, float, float]:
        xr = x / 0.95047
        yr = y / 1.00000
        zr = z / 1.08883

        def f(value: float) -> float:
            if value > 0.008856:
                return value ** (1.0 / 3.0)
            return 7.787 * value + 16.0 / 116.0

        fx = f(xr)
        fy = f(yr)
        fz = f(zr)
        return 116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz)

    l1, a1, b1 = xyz_to_lab(*rgb_to_xyz(a))
    l2, a2, b2 = xyz_to_lab(*rgb_to_xyz(b))
    return ((l1 - l2) ** 2 + (a1 - a2) ** 2 + (b1 - b2) ** 2) ** 0.5
