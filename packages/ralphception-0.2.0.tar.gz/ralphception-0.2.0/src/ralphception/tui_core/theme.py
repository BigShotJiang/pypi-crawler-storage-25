"""Theme helpers for low-level TUI surface rendering."""

from __future__ import annotations

from typing import TypeAlias

RgbColor: TypeAlias = tuple[int, int, int]


def is_light(bg: RgbColor) -> bool:
    r, g, b = bg
    return 0.299 * r + 0.587 * g + 0.114 * b > 128.0


def blend(fg: RgbColor, bg: RgbColor, alpha: float) -> RgbColor:
    return (
        int(fg[0] * alpha + bg[0] * (1.0 - alpha)),
        int(fg[1] * alpha + bg[1] * (1.0 - alpha)),
        int(fg[2] * alpha + bg[2] * (1.0 - alpha)),
    )


def user_surface_rgb(terminal_bg: RgbColor) -> RgbColor:
    top, alpha = (((0, 0, 0), 0.04) if is_light(terminal_bg) else ((255, 255, 255), 0.12))
    return blend(top, terminal_bg, alpha)
