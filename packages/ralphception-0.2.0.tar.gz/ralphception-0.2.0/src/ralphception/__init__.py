"""Ralphception package metadata."""

from importlib import import_module

__all__ = ["__version__"]


def _load_generated_version() -> str:
    try:
        module = import_module("ralphception._version")
    except ImportError:
        return "0.0.0"
    return str(getattr(module, "__version__", "0.0.0"))


__version__ = _load_generated_version()
