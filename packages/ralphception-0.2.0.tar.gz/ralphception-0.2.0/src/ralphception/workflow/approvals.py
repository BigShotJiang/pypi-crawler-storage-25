"""Approval record helpers and snapshot persistence."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel, Field, model_validator

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ApprovalRecord, ExecutionBundle
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.files import ensure_directory_tree_durable, write_file_atomic, write_json_atomic

from ._identifiers import validate_storage_identifier


class _SpecReviewRequest(BaseModel):
    approval_id: str
    run_id: str
    approver: str
    spec_artifacts: list[ArtifactRef]
    plan_artifacts: list[ArtifactRef] = Field(default_factory=list)
    bundle_version: int = Field(ge=1)
    scope_hash: str
    approved_at: datetime | None = None

    @model_validator(mode="after")
    def validate_spec_bundle_only(self) -> "_SpecReviewRequest":
        if not self.spec_artifacts:
            raise ValueError("spec_review requires at least one spec artifact")
        if self.plan_artifacts:
            raise ValueError("spec_review accepts reviewed spec artifacts only")
        if any(artifact.artifact_kind != "spec" for artifact in self.spec_artifacts):
            raise ValueError("spec_review artifacts must all be spec artifacts")
        return self


def approval_path(repo_root: Path, approval_id: str) -> Path:
    """Return the canonical approval record path."""
    repo_root = bootstrap_workspace(repo_root)
    validated_approval_id = validate_storage_identifier(approval_id, field_name="approval_id")
    return repo_root / ".ralphception" / "approvals" / f"{validated_approval_id}.json"


def approval_snapshot_dir(repo_root: Path, approval_id: str) -> Path:
    """Return the canonical approval snapshot directory."""
    repo_root = bootstrap_workspace(repo_root)
    validated_approval_id = validate_storage_identifier(approval_id, field_name="approval_id")
    return repo_root / ".ralphception" / "approvals" / validated_approval_id


def create_spec_review(
    *,
    approval_id: str,
    run_id: str,
    approver: str,
    spec_artifacts: list[ArtifactRef],
    plan_artifacts: list[ArtifactRef] | None = None,
    bundle_version: int,
    scope_hash: str,
    approved_at: datetime | None = None,
) -> ApprovalRecord:
    """Create a spec-review approval bound to spec artifacts only."""
    validate_storage_identifier(approval_id, field_name="approval_id")
    validate_storage_identifier(run_id, field_name="run_id")
    request = _SpecReviewRequest(
        approval_id=approval_id,
        run_id=run_id,
        approver=approver,
        spec_artifacts=spec_artifacts,
        plan_artifacts=[] if plan_artifacts is None else plan_artifacts,
        bundle_version=bundle_version,
        scope_hash=scope_hash,
        approved_at=approved_at,
    )
    return ApprovalRecord(
        approval_id=request.approval_id,
        run_id=request.run_id,
        approval_kind="spec_review",
        artifact_bundle_refs=request.spec_artifacts,
        bundle_version=request.bundle_version,
        scope_hash=request.scope_hash,
        approved_at=request.approved_at or datetime.now(timezone.utc),
        approver=request.approver,
        waived_finding_ids=None,
        rationale=None,
    )


def create_execution_bundle_approval(
    *,
    approval_id: str,
    approver: str,
    bundle: ExecutionBundle,
    approved_at: datetime | None = None,
) -> ApprovalRecord:
    """Create an execution-bundle approval for a concrete bundle version."""
    validate_storage_identifier(approval_id, field_name="approval_id")
    validate_storage_identifier(bundle.run_id, field_name="run_id")
    return ApprovalRecord(
        approval_id=approval_id,
        run_id=bundle.run_id,
        approval_kind="execution_bundle",
        artifact_bundle_refs=bundle.artifact_refs,
        bundle_version=bundle.bundle_version,
        scope_hash=bundle.scope_hash,
        approved_at=approved_at or datetime.now(timezone.utc),
        approver=approver,
        waived_finding_ids=None,
        rationale=None,
    )


def create_finding_waiver(
    *,
    approval_id: str,
    run_id: str,
    approver: str,
    waived_finding_ids: list[str],
    rationale: str,
    approved_at: datetime | None = None,
    artifact_bundle_refs: list[ArtifactRef] | None = None,
    bundle_version: int | None = None,
    scope_hash: str | None = None,
) -> ApprovalRecord:
    """Create a durable waiver approval, optionally scoped to a bundle context."""
    validate_storage_identifier(approval_id, field_name="approval_id")
    validate_storage_identifier(run_id, field_name="run_id")
    return ApprovalRecord(
        approval_id=approval_id,
        run_id=run_id,
        approval_kind="finding_waiver",
        artifact_bundle_refs=artifact_bundle_refs,
        bundle_version=bundle_version,
        scope_hash=scope_hash,
        approved_at=approved_at or datetime.now(timezone.utc),
        approver=approver,
        waived_finding_ids=waived_finding_ids,
        rationale=rationale,
    )


def persist_approval(
    repo_root: Path,
    approval: ApprovalRecord,
    *,
    snapshot_refs: list[ArtifactRef] | None = None,
) -> ApprovalRecord:
    """Persist an approval record and snapshot the approved artifacts."""
    repo_root = bootstrap_workspace(repo_root)
    validate_storage_identifier(approval.approval_id, field_name="approval_id")
    validate_storage_identifier(approval.run_id, field_name="run_id")
    snapshot_directory = approval_snapshot_dir(repo_root, approval.approval_id)
    ensure_directory_tree_durable(snapshot_directory)

    for artifact_ref in snapshot_refs if snapshot_refs is not None else (approval.artifact_bundle_refs or []):
        source = repo_root / artifact_ref.artifact_path
        target = snapshot_directory / artifact_ref.artifact_path
        write_file_atomic(target, source.read_bytes())

    write_json_atomic(approval_path(repo_root, approval.approval_id), approval.model_dump(mode="json"))
    return approval


def read_approval(repo_root: Path, *, approval_id: str) -> ApprovalRecord:
    """Load a persisted approval record."""
    path = approval_path(repo_root, approval_id)
    return ApprovalRecord.model_validate(json.loads(path.read_text(encoding="utf-8")))
