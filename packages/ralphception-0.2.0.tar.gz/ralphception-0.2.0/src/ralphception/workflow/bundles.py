"""Execution bundle helpers, persistence, and event emission."""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ExecutionBundle, ExecutionBundleState
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.events import EventStore
from ralphception.storage.files import write_json_atomic

from ._identifiers import validate_storage_identifier

_SKIP = object()
_CONSUMABLE_STATES = frozenset({"approved", "derived_in_scope"})
_TRANSIENT_METADATA_KEYS = frozenset(
    {
        "approved_at",
        "content_hash",
        "created_at",
        "event_id",
        "generated_at",
        "last_updated",
        "occurred_at",
        "sequence",
        "timestamp",
        "updated_at",
    },
)
_EXECUTION_ONLY_NOTE_KEYS = frozenset(
    {
        "agent_notes",
        "execution_notes",
        "implementation_notes",
        "progress_notes",
        "session_notes",
    },
)
_ALLOWED_STATE_TRANSITIONS: dict[ExecutionBundleState, frozenset[ExecutionBundleState]] = {
    "draft": frozenset({"approved", "awaiting_approval", "superseded"}),
    "approved": frozenset({"superseded"}),
    "derived_in_scope": frozenset({"superseded"}),
    "awaiting_approval": frozenset({"approved", "superseded"}),
    "superseded": frozenset(),
}
_EXECUTION_NOTES_HEADING_RE = re.compile(
    r"^(?P<level>#{1,6})\s*(execution|implementation|agent|session)\s+notes?\s*$",
    re.IGNORECASE,
)
_MARKDOWN_HEADING_RE = re.compile(r"^(?P<level>#{1,6})\s+")
_WHITESPACE_RE = re.compile(r"\s+")


@dataclass(frozen=True, slots=True)
class ScopeHashArtifact:
    """Artifact content included in a scope-hash computation."""

    artifact_path: str
    content: object


def compute_scope_hash(bundle_contents: object) -> str:
    """Return a deterministic scope hash for normalized bundle contents."""
    normalized = _normalize_scope_input(bundle_contents)
    encoded = json.dumps(normalized, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return f"sha256:{hashlib.sha256(encoded.encode('utf-8')).hexdigest()}"


def compute_scope_hash_for_artifacts(repo_root: Path, artifact_refs: list[ArtifactRef]) -> str:
    """Load artifact contents from disk and compute a normalized scope hash."""
    repo_root = bootstrap_workspace(repo_root)
    bundle_contents = [
        ScopeHashArtifact(
            artifact_path=artifact_ref.artifact_path,
            content=_load_artifact_content(repo_root, artifact_ref),
        )
        for artifact_ref in artifact_refs
    ]
    return compute_scope_hash(bundle_contents)


def bundle_path(repo_root: Path, run_id: str, bundle_id: str) -> Path:
    """Return the canonical bundle record path for a run-local bundle."""
    repo_root = bootstrap_workspace(repo_root)
    validated_run_id = validate_storage_identifier(run_id, field_name="run_id")
    validated_bundle_id = validate_storage_identifier(bundle_id, field_name="bundle_id")
    return repo_root / ".ralphception" / "runs" / validated_run_id / "bundles" / f"{validated_bundle_id}.json"


def persist_bundle(repo_root: Path, bundle: ExecutionBundle) -> ExecutionBundle:
    """Write a bundle record to its canonical run-local location."""
    write_json_atomic(
        bundle_path(repo_root, bundle.run_id, bundle.bundle_id),
        bundle.model_dump(mode="json"),
    )
    return bundle


def read_bundle(repo_root: Path, *, run_id: str, bundle_id: str) -> ExecutionBundle:
    """Load a bundle record from durable storage."""
    path = bundle_path(repo_root, run_id, bundle_id)
    return ExecutionBundle.model_validate(json.loads(path.read_text(encoding="utf-8")))


def create_bundle(
    repo_root: Path,
    *,
    bundle_id: str,
    run_id: str,
    bundle_version: int,
    state: ExecutionBundleState,
    artifact_refs: list[ArtifactRef],
    stage_id: str,
    created_at: datetime | None = None,
    base_bundle_id: str | None = None,
    source: str = "workflow.bundles",
) -> ExecutionBundle:
    """Create, persist, and emit the canonical created event for a bundle."""
    repo_root = bootstrap_workspace(repo_root)
    validated_run_id = validate_storage_identifier(run_id, field_name="run_id")
    validated_bundle_id = validate_storage_identifier(bundle_id, field_name="bundle_id")
    bundle = ExecutionBundle(
        bundle_id=validated_bundle_id,
        run_id=validated_run_id,
        bundle_version=bundle_version,
        state=state,
        artifact_refs=artifact_refs,
        base_bundle_id=base_bundle_id,
        scope_hash=compute_scope_hash_for_artifacts(repo_root, artifact_refs),
        created_at=created_at or datetime.now(timezone.utc),
        assigned_run_ids=[],
    )
    return _persist_bundle_and_emit_event(
        repo_root,
        bundle=bundle,
        previous_bundle=None,
        stage_id=stage_id,
        event_type="bundle.created",
        source=source,
        payload={
            "bundle_id": bundle.bundle_id,
            "bundle_version": bundle.bundle_version,
            "state": bundle.state,
        },
    )


def transition_bundle_state(
    repo_root: Path,
    *,
    bundle: ExecutionBundle,
    next_state: ExecutionBundleState,
    stage_id: str,
    source: str = "workflow.bundles",
) -> ExecutionBundle:
    """Transition a bundle to a new valid state and emit the state-change event."""
    validate_storage_identifier(bundle.run_id, field_name="run_id")
    validate_storage_identifier(bundle.bundle_id, field_name="bundle_id")
    if next_state == bundle.state:
        return bundle
    allowed_next_states = _ALLOWED_STATE_TRANSITIONS[bundle.state]
    if next_state not in allowed_next_states:
        raise ValueError(f"bundle {bundle.bundle_id} cannot transition {bundle.state} -> {next_state}")

    bundle_data = bundle.model_dump(mode="python")
    bundle_data["state"] = next_state
    updated = ExecutionBundle(**bundle_data)
    return _persist_bundle_and_emit_event(
        repo_root,
        bundle=updated,
        previous_bundle=bundle,
        stage_id=stage_id,
        event_type="bundle.state_changed",
        source=source,
        payload={
            "bundle_id": updated.bundle_id,
            "bundle_version": updated.bundle_version,
            "from_state": bundle.state,
            "to_state": next_state,
        },
    )


def is_bundle_consumable(bundle: ExecutionBundle) -> bool:
    """Return whether scheduling may assign the bundle to new child runs."""
    return bundle.state in _CONSUMABLE_STATES


def assign_bundle(
    repo_root: Path,
    *,
    bundle: ExecutionBundle,
    assigned_run_id: str,
    stage_id: str,
    source: str = "workflow.bundles",
) -> ExecutionBundle:
    """Record a child-run bundle assignment and emit the assignment event."""
    validate_storage_identifier(bundle.run_id, field_name="run_id")
    validate_storage_identifier(bundle.bundle_id, field_name="bundle_id")
    validate_storage_identifier(assigned_run_id, field_name="assigned_run_id")
    if not is_bundle_consumable(bundle):
        raise ValueError(f"bundle {bundle.bundle_id} is not consumable in state {bundle.state}")
    if assigned_run_id in bundle.assigned_run_ids:
        return bundle

    bundle_data = bundle.model_dump(mode="python")
    bundle_data["assigned_run_ids"] = [*bundle.assigned_run_ids, assigned_run_id]
    updated = ExecutionBundle(**bundle_data)
    return _persist_bundle_and_emit_event(
        repo_root,
        bundle=updated,
        previous_bundle=bundle,
        stage_id=stage_id,
        event_type="bundle.assigned",
        source=source,
        payload={
            "bundle_id": updated.bundle_id,
            "bundle_version": updated.bundle_version,
            "assigned_run_id": assigned_run_id,
        },
    )


def _append_bundle_event(
    repo_root: Path,
    *,
    run_id: str,
    stage_id: str,
    event_type: str,
    source: str,
    payload: dict[str, object],
) -> None:
    validated_run_id = validate_storage_identifier(run_id, field_name="run_id")
    EventStore(repo_root).append(
        event_id=f"{event_type}-{uuid.uuid4().hex}",
        run_id=validated_run_id,
        stage_id=stage_id,
        task_id=None,
        event_type=event_type,
        source=source,
        payload=payload,
    )


def _persist_bundle_and_emit_event(
    repo_root: Path,
    *,
    bundle: ExecutionBundle,
    previous_bundle: ExecutionBundle | None,
    stage_id: str,
    event_type: str,
    source: str,
    payload: dict[str, object],
) -> ExecutionBundle:
    persist_bundle(repo_root, bundle)
    try:
        _append_bundle_event(
            repo_root,
            run_id=bundle.run_id,
            stage_id=stage_id,
            event_type=event_type,
            source=source,
            payload=payload,
        )
    except Exception:
        try:
            if previous_bundle is None:
                _delete_bundle_record(repo_root, run_id=bundle.run_id, bundle_id=bundle.bundle_id)
            else:
                persist_bundle(repo_root, previous_bundle)
        except Exception:
            pass
        raise
    return bundle


def _delete_bundle_record(repo_root: Path, *, run_id: str, bundle_id: str) -> None:
    path = bundle_path(repo_root, run_id, bundle_id)
    if path.exists():
        path.unlink()


def _load_artifact_content(repo_root: Path, artifact_ref: ArtifactRef) -> object:
    artifact_path = repo_root / artifact_ref.artifact_path
    raw_text = artifact_path.read_text(encoding="utf-8")
    if artifact_path.suffix == ".json":
        try:
            return json.loads(raw_text)
        except json.JSONDecodeError:
            return raw_text
    return raw_text


def _normalize_scope_input(value: object, *, artifact_path: str | None = None) -> object:
    if isinstance(value, ScopeHashArtifact):
        if _should_ignore_artifact(value.artifact_path):
            return _SKIP
        normalized_content = _normalize_scope_input(value.content, artifact_path=value.artifact_path)
        if normalized_content is _SKIP:
            return _SKIP
        return {
            "artifact_path": value.artifact_path,
            "content": normalized_content,
        }

    if isinstance(value, dict):
        normalized_dict: dict[str, object] = {}
        for raw_key in sorted(value):
            key = str(raw_key)
            lowered_key = key.lower()
            if lowered_key in _TRANSIENT_METADATA_KEYS or lowered_key in _EXECUTION_ONLY_NOTE_KEYS:
                continue
            normalized_value = _normalize_scope_input(value[raw_key], artifact_path=artifact_path)
            if normalized_value is _SKIP:
                continue
            normalized_dict[key] = normalized_value
        return normalized_dict

    if isinstance(value, list):
        if value and all(isinstance(item, ScopeHashArtifact) for item in value):
            normalized_artifacts = [
                normalized_item
                for item in sorted(value, key=lambda artifact: artifact.artifact_path)
                if (normalized_item := _normalize_scope_input(item, artifact_path=artifact_path)) is not _SKIP
            ]
            return normalized_artifacts
        normalized_items = [
            normalized_item
            for item in value
            if (normalized_item := _normalize_scope_input(item, artifact_path=artifact_path)) is not _SKIP
        ]
        if _is_todo_list(value, artifact_path):
            return sorted(
                normalized_items,
                key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=True),
            )
        return normalized_items

    if isinstance(value, tuple):
        if value and all(isinstance(item, ScopeHashArtifact) for item in value):
            normalized_artifacts = [
                normalized_item
                for item in sorted(value, key=lambda artifact: artifact.artifact_path)
                if (normalized_item := _normalize_scope_input(item, artifact_path=artifact_path)) is not _SKIP
            ]
            return normalized_artifacts
        normalized_items = [
            normalized_item
            for item in value
            if (normalized_item := _normalize_scope_input(item, artifact_path=artifact_path)) is not _SKIP
        ]
        if _is_todo_list(list(value), artifact_path):
            return sorted(
                normalized_items,
                key=lambda item: json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=True),
            )
        return normalized_items

    if isinstance(value, str):
        return _normalize_text(value, artifact_path=artifact_path)

    if isinstance(value, bytes):
        return _normalize_text(value.decode("utf-8"), artifact_path=artifact_path)

    if isinstance(value, (int, float, bool)) or value is None:
        return value

    return _normalize_text(str(value), artifact_path=artifact_path)


def _should_ignore_artifact(artifact_path: str) -> bool:
    normalized_path = artifact_path.replace("\\", "/")
    return normalized_path.endswith(".jsonl") or "/events/" in normalized_path


def _is_todo_list(value: object, artifact_path: str | None) -> bool:
    if artifact_path is not None and "/todos/" in artifact_path.replace("\\", "/"):
        return True
    if not isinstance(value, list):
        return False
    return bool(value) and all(isinstance(item, dict) and "todo_id" in item for item in value)


def _normalize_text(value: str, *, artifact_path: str | None) -> str:
    text = value
    if artifact_path is not None and Path(artifact_path).suffix in {".md", ".txt"}:
        text = _strip_execution_only_sections(text)

    normalized_lines = []
    for line in text.splitlines():
        collapsed = _WHITESPACE_RE.sub(" ", line.strip())
        if collapsed:
            normalized_lines.append(collapsed)
    return "\n".join(normalized_lines)


def _strip_execution_only_sections(value: str) -> str:
    kept_lines: list[str] = []
    skip_level: int | None = None

    for line in value.splitlines():
        heading_match = _EXECUTION_NOTES_HEADING_RE.match(line.strip())
        if heading_match is not None:
            skip_level = len(heading_match.group("level"))
            continue

        if skip_level is not None:
            next_heading_match = _MARKDOWN_HEADING_RE.match(line.strip())
            if next_heading_match is None:
                continue
            if len(next_heading_match.group("level")) > skip_level:
                continue
            skip_level = None

        kept_lines.append(line)

    return "\n".join(kept_lines)
