from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest

from ralphception.codex_tui.app import _TrustPromptScreen
from ralphception.codex_tui.bottom_pane import BottomPane, ComposerState, FooterState
from ralphception.codex_tui.chatwidget import ActiveAssistantCell, ChatWidget
from ralphception.codex_tui.custom_terminal import BufferFrame, Rect
from ralphception.codex_tui.history_cell import SystemHistoryCell
from ralphception.codex_tui.styled_text import reset_surface_theme, set_surface_terminal_background, strip_ansi
from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette


@pytest.fixture(autouse=True)
def _default_surface_theme() -> Iterator[None]:
    set_surface_terminal_background((0, 0, 0))
    set_terminal_palette(fg=(255, 255, 255), bg=(0, 0, 0), color_level=ColorLevel.TRUECOLOR)
    try:
        yield
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_committed_cells_stay_out_of_live_viewport() -> None:
    widget = ChatWidget(
        committed_cells=[SystemHistoryCell("Wrote todos")],
        active_cell=ActiveAssistantCell("Inspecting README.md for obvious typos."),
        bottom_pane=BottomPane(
            composer=ComposerState(value=""),
            footer=FooterState(left_hint="? for shortcuts", right_status="~/code/ralphception"),
        ),
    )

    lines = widget.render_lines(width=40)

    assert all("Wrote todos" not in line for line in lines)
    assert any("Inspecting README.md" in line for line in lines)


def test_bottom_pane_keeps_composer_at_bottom() -> None:
    widget = ChatWidget(
        committed_cells=[],
        active_cell=ActiveAssistantCell("Working on the loop."),
        bottom_pane=BottomPane(
            composer=ComposerState(value="fix typos"),
            footer=FooterState(left_hint="? for shortcuts", right_status="~/code/ralphception"),
        ),
    )

    lines = widget.render_lines(width=40)

    assert strip_ansi(lines[-4]).strip() == ""
    assert strip_ansi(lines[-3]).rstrip() == "› fix typos"
    assert "\x1b[48;2;30;30;30m" in lines[-4]
    assert "\x1b[48;2;30;30;30m" in lines[-3]
    assert "\x1b[48;2;30;30;30m" in lines[-2]
    assert strip_ansi(lines[-2]).strip() == ""
    assert strip_ansi(lines[-1]).strip() == "~/code/ralphception"


def test_desired_height_tracks_active_content_and_bottom_pane() -> None:
    widget = ChatWidget(
        committed_cells=[],
        active_cell=ActiveAssistantCell("Waiting for background terminal output from run-child-1."),
        bottom_pane=BottomPane(
            composer=ComposerState(value=""),
            footer=FooterState(left_hint="? for shortcuts", right_status="~/code/ralphception"),
        ),
    )

    assert widget.desired_height(24) == 8


def test_cursor_position_follows_composer_text() -> None:
    widget = ChatWidget(
        committed_cells=[],
        active_cell=None,
        bottom_pane=BottomPane(
            composer=ComposerState(value="hello"),
            footer=FooterState(left_hint="? for shortcuts", right_status="~/code/ralphception"),
        ),
    )
    frame = BufferFrame(area=Rect(x=0, y=18, width=40, height=4))

    widget.render(frame)

    assert frame.cursor_position == (7, 19)


def test_trust_prompt_screen_top_anchors_in_taller_viewport() -> None:
    screen = _TrustPromptScreen(cwd=Path("/tmp/project"))
    frame = BufferFrame(area=Rect(x=0, y=0, width=60, height=16))

    screen.render(frame)

    stripped = [strip_ansi(line) for line in frame.lines]

    assert stripped[0] == "> You are in /tmp/project"
    assert stripped[1] == ""
    assert stripped[6].startswith("› 1. Yes, continue")
    assert frame.cursor_position == (0, 6)
