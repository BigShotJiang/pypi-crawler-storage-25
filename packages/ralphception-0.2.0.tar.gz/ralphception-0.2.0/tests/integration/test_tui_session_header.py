from __future__ import annotations

import asyncio
from pathlib import Path

from ralphception.config import DEFAULT_CONFIG
from ralphception.tui import render_state as render_state_module
from ralphception.tui.chatwidget.session_header import SessionHeader, SessionHeaderState, render_session_header
from ralphception.tui.render_state import RenderState


def test_session_header_uses_codex_card_structure() -> None:
    fixture_path = Path(__file__).resolve().parents[1] / "golden" / "codex_port" / "header_card.txt"
    state = SessionHeaderState(
        product_name="Ralphception",
        version="0.1.3",
        model_name="gpt-5.4",
        reasoning_effort="high",
        latency_label="fast",
        directory_label="~/code/ralphception",
    )

    rendered = render_session_header(state, width=72)
    assert rendered == fixture_path.read_text(encoding="utf-8")
    assert ">_ Ralphception" in rendered
    assert "model:" in rendered
    assert "directory:" in rendered
    assert "/model for config help" in rendered


def test_session_header_directory_center_truncates_like_codex() -> None:
    state = SessionHeaderState(
        product_name="Ralphception",
        version="0.1.3",
        model_name="gpt-5.4",
        reasoning_effort="high",
        latency_label="fast",
        directory_label="~/hello/the/fox/is/very/fast",
    )

    rendered = render_session_header(state, width=44)
    assert "~/hello/the/…/very/fast" in rendered


def test_session_header_widget_updates_when_state_changes() -> None:
    header = SessionHeader(
        SessionHeaderState(
            product_name="Ralphception",
            version="0.1.3",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )

    async def exercise() -> str:
        from textual.app import App

        class Harness(App[None]):
            def compose(self):
                yield header

        async with Harness().run_test() as pilot:
            await pilot.pause()
            header.set_state(
                SessionHeaderState(
                    product_name="Ralphception",
                    version="0.1.3",
                    model_name="gpt-5.5",
                    reasoning_effort="medium",
                    latency_label="balanced",
                    directory_label="~/code/ralphception",
                )
            )
            await pilot.pause()
            return str(header.renderable)

    rendered = asyncio.run(exercise())
    assert "gpt-5.5 medium" in rendered


def test_session_header_widget_uses_live_width_for_directory_rendering() -> None:
    directory_label = "~/code/ralphception/.worktrees/codex-startup-shell/very/long/path/that/should/fit"
    header = SessionHeader(
        SessionHeaderState(
            product_name="Ralphception",
            version="0.1.3",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label=directory_label,
        ),
    )

    async def exercise() -> str:
        from textual.app import App

        class Harness(App[None]):
            def compose(self):
                yield header

        async with Harness().run_test(size=(140, 24)) as pilot:
            await pilot.pause()
            return str(header.renderable)

    rendered = asyncio.run(exercise())
    assert directory_label in rendered


def test_idle_preview_header_uses_checkout_version_when_generated_module_is_stale(
    monkeypatch,
) -> None:
    repo_root = Path(__file__).resolve().parents[2]
    monkeypatch.setattr(
        render_state_module,
        "resolve_cli_version",
        lambda path: "0.1.3.dev40+gd3313a533",
    )

    state = RenderState.idle_preview(repo_root, config=DEFAULT_CONFIG)

    assert state.header_card.version == "0.1.3.dev40+gd3313a533"


def test_idle_preview_header_prefers_codex_runtime_settings(monkeypatch) -> None:
    repo_root = Path(__file__).resolve().parents[2]
    monkeypatch.setattr(
        render_state_module,
        "load_codex_runtime_settings",
        lambda: render_state_module.CodexRuntimeSettings(
            model="gpt-5.4",
            reasoning_effort="xhigh",
            service_tier="fast",
            config_path=Path("/Users/shayne/.codex/config.toml"),
        ),
        raising=False,
    )

    state = RenderState.idle_preview(repo_root, config=DEFAULT_CONFIG)

    assert state.header_card.model_name == "gpt-5.4"
    assert state.header_card.reasoning_effort == "xhigh"
    assert state.header_card.latency_label == "fast"
