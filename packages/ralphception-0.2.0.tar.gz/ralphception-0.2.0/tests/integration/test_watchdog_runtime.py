from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

from ralphception.app import resolve_runtime_view
from ralphception.config import RalphceptionConfig
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import Run
from ralphception.models.session import ChildSessionRef
from ralphception.runtime.compaction import latest_compaction_checkpoint, persist_compaction_checkpoint
from ralphception.runtime.frontier import FrontierItem, TaskFrontier, load_task_frontier
from ralphception.runtime.interactive_session import load_interactive_session_state
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.headless import HeadlessMissionSupervisor
from ralphception.storage.events import EventStore
from ralphception.runtime.watchdog import (
    WatchdogDecision,
    WatchdogInputSnapshot,
    latest_root_watchdog_activation,
    record_root_watchdog_activation,
)
from ralphception.workflow.bundles import create_bundle
from ralphception.runtime.watchdog import ensure_root_watchdog, write_root_watchdog


class _RecordingFrontend:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def emit_event(self, event) -> None:
        self.messages.append(event.message)

    def emit_status(self, step) -> None:
        self.messages.append(f"Runtime: {step.kind}")

    def finish(self, step) -> None:
        self.messages.append(f"Finished: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self.messages)


def test_runtime_view_persists_frontier_for_incomplete_dashboard_workspace(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    frontier = load_task_frontier(repo_root)

    assert launch.mode == "dashboard"
    assert frontier is not None
    assert frontier.status == "incomplete"
    assert frontier.current_stage == "execute"
    assert [item.kind for item in frontier.frontier_items] == ["continue_stage"]
    assert frontier.frontier_items[0].summary == "Continue execute stage"


def test_runtime_view_persists_watchdog_metadata_in_frontier(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    watchdog = ensure_root_watchdog(repo_root)
    assert watchdog is not None
    watchdog = watchdog.model_copy(
        update={
            "last_activated_at": datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc),
        }
    )
    write_root_watchdog(repo_root, watchdog)

    resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    frontier = load_task_frontier(repo_root)

    assert frontier is not None
    assert frontier.goal == "port parser"
    assert frontier.last_watchdog_run_at == datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc)
    assert frontier.blocked_reason is None


def test_root_watchdog_can_resume_incomplete_idle_dashboard_workspace(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    frontier = load_task_frontier(repo_root)
    event_types = [event.event_type for event in EventStore(repo_root).read_run("run-root")]
    activation = latest_root_watchdog_activation(repo_root)

    assert result is not None
    assert result.mode == "completed"
    assert "Watchdog armed: idle" in frontend.output_text()
    assert "Watchdog activated: continue_root_turn" in frontend.output_text()
    assert "stage.custom_watchdog_armed" in event_types
    assert activation is not None
    assert activation.source_thread_id == "thread-1"
    assert activation.created_child_thread_id == "thread-2"
    assert activation.input_snapshot.frontier.status == "incomplete"
    assert activation.input_snapshot.frontier.frontier_items
    assert activation.input_snapshot.recent_runtime_events
    assert activation.result.action == "continue_root_turn"
    assert frontier is not None
    assert frontier.status == "completed"


def test_root_watchdog_does_not_activate_while_review_prompt_is_pending(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=False,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    frontier = load_task_frontier(repo_root)

    assert launch.mode == "review"
    assert result is None
    assert "Watchdog activated" not in frontend.output_text()
    assert frontier is not None
    assert frontier.status == "blocked"
    assert [item.kind for item in frontier.frontier_items] == ["review_prompt"]


def test_root_watchdog_can_ask_user_instead_of_blindly_continuing(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "ask_user",
                "rationale": "Need one constraint before continuing.",
                "question": "What is the highest-priority constraint for this task?",
            }
        ),
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    prompt_state = load_interactive_session_state(repo_root)
    frontier = load_task_frontier(repo_root)
    event_types = [event.event_type for event in EventStore(repo_root).read_run("run-root")]

    assert result is not None
    assert result.mode == "startup"
    assert prompt_state.pending_prompts
    assert prompt_state.pending_prompts[0].question == "What is the highest-priority constraint for this task?"
    assert "Watchdog activated: ask_user" in frontend.output_text()
    assert "Watchdog decided: ask_user" in frontend.output_text()
    assert frontier is not None
    assert frontier.status == "blocked"
    assert [item.kind for item in frontier.frontier_items] == ["pending_prompt"]
    assert "stage.custom_watchdog_activated" in event_types
    assert "stage.custom_watchdog_decided" in event_types


def test_watchdog_question_reply_reenters_runtime_after_user_answer(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "ask_user",
                "rationale": "Need one more constraint before continuing.",
                "question": "What constraint matters most?",
            }
        ),
    )

    initial = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    prompt_state = load_interactive_session_state(repo_root)
    assert initial is not None
    assert initial.mode == "startup"
    assert prompt_state.pending_prompts

    resolution = supervisor.resolve_pending_prompt(
        thread_id=prompt_state.pending_prompts[0].thread_id,
        user_text="Focus on docs only.",
    )
    resumed = supervisor.run(frontend=frontend)
    prompt_state = load_interactive_session_state(repo_root)

    assert resolution.kind == "resolved"
    assert resolution.action == "continue_root_turn"
    assert resumed.mode == "completed"
    assert prompt_state.pending_prompts == []


def test_root_watchdog_can_revise_the_plan_and_regenerate_plan_artifacts(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()
    original_plan = (repo_root / ".ralphception" / "plans" / "runtime.md").read_text(encoding="utf-8")

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "revise_plan",
                "rationale": "The plan is too shallow to drive execution safely.",
                "plan_revision_summary": "Rewrite the plan with explicit implementation and verification steps.",
            }
        ),
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    plan_candidates = sorted((repo_root / ".ralphception" / "plans").glob("*.md"))
    assert plan_candidates
    rewritten_plan = plan_candidates[0].read_text(encoding="utf-8")
    frontier = load_task_frontier(repo_root)

    assert result is not None
    assert result.mode == "completed"
    assert rewritten_plan != original_plan
    assert rewritten_plan.startswith("# Execution Plan")
    assert "Watchdog decided: revise_plan" in frontend.output_text()
    assert frontier is not None
    assert frontier.status == "completed"


def test_root_watchdog_compacts_root_thread_and_records_checkpoint(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "compact_root_thread",
                "rationale": "The root thread is repetitive and not making durable progress.",
                "compact_reason": "Repeated next-step summaries with no artifact delta.",
            }
        ),
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    checkpoint = latest_compaction_checkpoint(repo_root)
    event_types = [event.event_type for event in EventStore(repo_root).read_run("run-root")]

    assert result is not None
    assert result.mode == "completed"
    assert checkpoint is not None
    assert checkpoint.reason == "Repeated next-step summaries with no artifact delta."
    assert checkpoint.pre_compact_thread_id != checkpoint.post_compact_thread_id
    assert checkpoint.summary_text
    assert "Watchdog decided: compact_root_thread" in frontend.output_text()
    assert "Watchdog compacted root thread" in frontend.output_text()
    assert "stage.custom_watchdog_compacted" in event_types


def test_runtime_view_derives_stuck_signals_from_watchdog_history(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    _append_runtime_event(repo_root, run_id="run-root", event_type="stage.custom_watchdog_decided", payload={"action": "continue_root_turn"})
    _append_runtime_event(repo_root, run_id="run-root", event_type="stage.custom_watchdog_decided", payload={"action": "revise_plan"})
    persist_compaction_checkpoint(
        repo_root,
        root_run_id="run-root",
        reason="Repeated next-step summaries with no artifact delta.",
        summary_text="Goal: port parser\nCurrent stage: execute",
        pre_compact_thread_id="thread-1",
        post_compact_thread_id="thread-2",
    )

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    frontier = load_task_frontier(repo_root)

    assert launch.mode == "dashboard"
    assert frontier is not None
    assert frontier.status == "incomplete"
    assert frontier.stuck_count == 3
    reasons = {signal.reason: signal.count for signal in frontier.stuck_signals}
    assert reasons["repeated_watchdog_decisions"] == 2
    assert reasons["watchdog_compaction"] == 1


def test_runtime_view_derives_stuck_signals_from_repeated_next_steps_hints(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    _append_runtime_event(
        repo_root,
        run_id="run-root",
        event_type="stage.custom_next_steps_emitted",
        payload={"stage_kind": "execute", "text": "Here are the next steps I can take."},
    )
    _append_runtime_event(
        repo_root,
        run_id="run-root",
        event_type="stage.custom_next_steps_emitted",
        payload={"stage_kind": "execute", "text": "Planning next steps."},
    )

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    frontier = load_task_frontier(repo_root)

    assert launch.mode == "dashboard"
    assert frontier is not None
    reasons = {signal.reason: signal.count for signal in frontier.stuck_signals}
    assert reasons["repeated_next_steps"] == 2


def test_runtime_view_derives_stuck_signals_from_watchdog_runs_without_artifact_delta(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontier_snapshot = TaskFrontier(
        root_run_id="run-root",
        status="incomplete",
        goal="port parser",
        current_stage="execute",
        frontier_items=[
            FrontierItem(
                kind="continue_stage",
                summary="Continue execute stage",
                run_id="run-root",
                stage_kind="execute",
            )
        ],
        updated_at=_utc_now(),
    )
    snapshot = WatchdogInputSnapshot(
        goal="port parser",
        trigger_reason="idle",
        frontier=frontier_snapshot,
        artifact_paths=(".ralphception/specs/runtime.md", ".ralphception/plans/runtime.md"),
        recent_runtime_events=("stage.custom_watchdog_armed stage_kind=execute",),
    )
    record_root_watchdog_activation(
        repo_root,
        trigger_reason="idle",
        source_thread_id="thread-1",
        created_child_thread_id="thread-2",
        input_snapshot=snapshot,
        result=WatchdogDecision(
            action="continue_root_turn",
            rationale="The task is still incomplete.",
        ),
    )
    record_root_watchdog_activation(
        repo_root,
        trigger_reason="next_steps",
        source_thread_id="thread-1",
        created_child_thread_id="thread-3",
        input_snapshot=snapshot.model_copy(update={"trigger_reason": "next_steps"}),
        result=WatchdogDecision(
            action="revise_plan",
            rationale="The thread is not making durable artifact progress.",
            plan_revision_summary="Tighten the next execution tranche.",
        ),
    )

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )
    frontier = load_task_frontier(repo_root)

    assert launch.mode == "dashboard"
    assert frontier is not None
    reasons = {signal.reason: signal.count for signal in frontier.stuck_signals}
    assert reasons["watchdog_no_artifact_delta"] == 2


def test_root_watchdog_can_mark_the_task_complete(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "mark_complete",
                "rationale": "All required artifacts and execution stages are already complete.",
            }
        ),
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")
    frontier = load_task_frontier(repo_root)

    assert result is not None
    assert result.mode == "completed"
    assert frontier is not None
    assert frontier.status == "completed"
    assert "Watchdog decided: mark_complete" in frontend.output_text()


def test_root_watchdog_can_force_a_new_child_loop_from_a_later_stage(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()
    _write_headless_state(
        repo_root,
        current_stage="merge",
        completed_stages=["intake", "spec", "plan", "execute"],
        terminal_outcome=None,
    )

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "launch_child_loop",
                "rationale": "Merge is premature; execution needs another child loop first.",
            }
        ),
    )

    result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")

    assert result is not None
    assert result.mode == "completed"
    assert "Watchdog decided: launch_child_loop" in frontend.output_text()
    assert "Launched 1 Ralph loop" in frontend.output_text()


def test_root_watchdog_can_reopen_a_failed_loop_through_recovery(tmp_path: Path) -> None:
    repo_root = _prepare_launch_runtime_workspace(tmp_path)
    frontend = _RecordingFrontend()
    _write_failed_child_run(repo_root, run_id="run-child-1")
    _write_headless_state(
        repo_root,
        current_stage="failed",
        completed_stages=["intake", "spec", "plan"],
        terminal_outcome="failed",
        current_child_run_id="run-child-1",
        child_run_ids=["run-child-1"],
    )

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        approve_all=True,
        session_manager_factory=_build_scripted_session_manager_for_repo(
            {
                "action": "reopen_existing_loop",
                "rationale": "The failed loop should be reopened on the normal recovery rail.",
                "target_run_id": "run-child-1",
            }
        ),
    )

    with patch.object(HeadlessMissionSupervisor, "_cleanup_completed_runtime_state", lambda self: None):
        result = supervisor.activate_root_watchdog(frontend=frontend, trigger_reason="idle")

    replacement_run_path = repo_root / ".ralphception" / "runs" / "run-child-1-replacement-1" / "run.json"
    replacement_run = Run.model_validate_json(replacement_run_path.read_text(encoding="utf-8"))

    assert result is not None
    assert result.mode == "completed"
    assert replacement_run.supersedes_run_id == "run-child-1"
    assert "Watchdog decided: reopen_existing_loop" in frontend.output_text()


def _prepare_launch_runtime_workspace(tmp_path: Path) -> Path:
    repo_root = tmp_path / "launch-runtime"
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Launch should start execution.\n",
    )
    _approve_current_review_target(repo_root)
    plan_ref = _write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Runtime Plan\n\n- Launch should start execution.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=_utc_now(),
    )
    _approve_current_review_target(repo_root)
    return repo_root


def _prepare_review_workspace(tmp_path: Path) -> Path:
    repo_root = tmp_path / "review-workspace"
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="review runtime",
        source_repos=[],
    )
    _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Review before planning.\n",
    )
    return repo_root


def _approve_current_review_target(repo_root: Path) -> None:
    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None
    launch.review_controller.approve_current_target(approver="user")


def _write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def _init_git_repo(repo_root: Path) -> None:
    repo_root.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init"], cwd=repo_root, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Ralphception Tests"], cwd=repo_root, check=True)
    subprocess.run(["git", "config", "user.email", "tests@example.com"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("# fixture\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo_root, check=True, capture_output=True)


def _write_headless_state(
    repo_root: Path,
    *,
    current_stage: str,
    completed_stages: list[str],
    terminal_outcome: str | None,
    current_child_run_id: str | None = None,
    child_run_ids: list[str] | None = None,
) -> None:
    path = repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json"
    if path.exists():
        payload = json.loads(path.read_text(encoding="utf-8"))
    else:
        payload = {
            "current_stage": "execute",
            "completed_stages": ["intake", "spec", "plan"],
            "stage_attempts": {},
            "current_child_run_id": None,
            "child_run_ids": [],
            "last_approved_bundle_version": 2,
            "execution_goal": "port parser",
            "pending_child_goal": None,
            "loop_graph_id": None,
            "active_loop_ids": [],
            "completed_loop_ids": [],
            "terminal_outcome": None,
            "audit_reopened": False,
        }
    payload["current_stage"] = current_stage
    payload["completed_stages"] = completed_stages
    payload["terminal_outcome"] = terminal_outcome
    payload["current_child_run_id"] = current_child_run_id
    payload["child_run_ids"] = [] if child_run_ids is None else child_run_ids
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_failed_child_run(repo_root: Path, *, run_id: str) -> None:
    now = _utc_now()
    run_dir = repo_root / ".ralphception" / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    run_dir.joinpath("run.json").write_text(
        Run(
            run_id=run_id,
            parent_run_id="run-root",
            supersedes_run_id=None,
            goal="Recover the failed loop.",
            status="failed",
            stage_ids=[],
            config_snapshot={"codex": {"model": "gpt-5.4"}},
            codex_session_ref=None,
            artifact_refs=[],
            created_at=now,
            updated_at=now,
        ).model_dump_json(indent=2),
        encoding="utf-8",
    )


def _build_fake_session_manager_for_repo(repo_root: Path, config: RalphceptionConfig) -> object:
    return build_fake_session_manager(
        workspace_path=str(repo_root),
        config=config,
    )


def _build_scripted_session_manager_for_repo(decision: dict[str, object]):
    def factory(repo_root: Path, config: RalphceptionConfig) -> object:
        return build_fake_session_manager(
            workspace_path=str(repo_root),
            config=config,
            watchdog_decisions=(decision,),
        )

    return factory


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _append_runtime_event(repo_root: Path, *, run_id: str, event_type: str, payload: dict[str, object]) -> None:
    EventStore(repo_root).append(
        event_id=f"{event_type}-{hashlib.sha256(json.dumps(payload, sort_keys=True).encode('utf-8')).hexdigest()[:12]}",
        run_id=run_id,
        event_type=event_type,
        source="tests.watchdog",
        stage_id="stage-execute",
        payload={"stage_kind": "execute", **payload},
    )
