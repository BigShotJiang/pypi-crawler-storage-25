from __future__ import annotations

import asyncio
from pathlib import Path
import re

from ralphception.codex.config import CodexRuntimeSettings
from ralphception.tui.app import RalphceptionTuiApp


def test_idle_shell_matches_codex_frame_shape(monkeypatch) -> None:
    fixture_path = Path(__file__).resolve().parents[1] / "golden" / "codex_port" / "idle_shell.txt"
    _stub_codex_runtime_settings(monkeypatch)
    app = RalphceptionTuiApp.for_idle_preview(repo_root=Path("/tmp/project"))

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            return app.export_text()

    rendered = asyncio.run(exercise())
    expected = fixture_path.read_text(encoding="utf-8")
    assert _normalize_version(rendered) == _normalize_version(expected)
    assert ">_ Ralphception" in rendered
    assert "Mission |" not in rendered
    assert "? for shortcuts" not in rendered


def test_idle_shell_does_not_invent_codex_marketing_metadata(monkeypatch) -> None:
    _stub_codex_runtime_settings(monkeypatch)
    app = RalphceptionTuiApp.for_idle_preview(repo_root=Path("/tmp/project"))

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            return app.export_text()

    rendered = asyncio.run(exercise())
    assert "100% left" not in rendered
    assert "Find and fix a bug in @filename" not in rendered
    assert "gpt-5.4 high   fast" in rendered


def test_app_defines_codex_like_shell_css() -> None:
    css = RalphceptionTuiApp.CSS
    transcript_view_block = css.split("#transcript-view {", 1)[1].split("}", 1)[0]
    shell_root_block = css.split("#shell-root {", 1)[1].split("}", 1)[0]

    assert "#shell-root" in css
    assert "#session-header" in css
    assert "#composer-input" in css
    assert "border: round" in css
    assert "#transcript-view" in css
    assert "height: 100%;" not in shell_root_block
    assert "height: 1fr;" not in transcript_view_block
    assert "overflow-y: auto;" not in transcript_view_block


def _normalize_version(text: str) -> str:
    return re.sub(r"\(v[^)]+\)", "(v<version>)", text)


def _stub_codex_runtime_settings(monkeypatch) -> None:
    monkeypatch.setattr(
        "ralphception.tui.render_state.load_codex_runtime_settings",
        lambda: CodexRuntimeSettings(
            model="gpt-5.4",
            reasoning_effort="high",
            service_tier="fast",
            config_path=Path("/Users/shayne/.codex/config.toml"),
        ),
    )
