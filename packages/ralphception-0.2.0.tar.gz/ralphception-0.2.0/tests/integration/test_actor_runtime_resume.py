from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

from ralphception.models.runtime import Run, RunStageStatus
from ralphception.models.session import ChildSessionRef
from ralphception.actor_runtime.planner_actor import PlannerActor
from ralphception.models.mission import ExecutionPolicy, MissionSession, PlannerOutput
from ralphception.runtime.bootstrap import StartupBootstrapController, load_startup_record
from ralphception.runtime.interactive_session import (
    InteractiveSessionMarker,
    load_interactive_session_marker,
    load_interactive_session_state,
    write_interactive_session_marker,
    write_interactive_session_state,
)
from ralphception.runtime.prompt_state import BlockedContinuationRef, DeferredInput, PendingPrompt
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.storage.mission_store import MissionStore
from ralphception.runtime.prompt_state import InteractiveSessionState


def test_planner_actor_writes_todo_graph_and_commit_intents(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    specs_dir = repo_root / ".ralphception" / "specs"
    plans_dir.mkdir(parents=True)
    specs_dir.mkdir(parents=True)
    approved_spec_path = specs_dir / "mission-spec.md"
    approved_spec_path.write_text("# Approved Spec\n", encoding="utf-8")
    (plans_dir / "mission-plan.md").write_text("# Mission Plan\n", encoding="utf-8")
    (plans_dir / "mission-plan.json").write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['uv run pytest tests/unit/test_runtime_supervisor.py -q'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    },
                    {
                        "todo_id": "todo-2",
                        "title": "Add parser regression test",
                        "dependency_ids": ["todo-1"],
                        "status": "blocked",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["tests/test_parser.py"],
                    },
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1", "todo-2"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 2,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    store = MissionStore(repo_root)
    store.write_session(
        MissionSession(
            mission_id="run-root",
            repo_root=str(repo_root),
            phase="planning",
            approved_spec_version=1,
        )
    )

    output = PlannerActor(repo_root=repo_root, store=store).plan(approved_spec_path=approved_spec_path)

    assert output == PlannerOutput(
        plan_markdown_path=".ralphception/plans/mission-plan.md",
        plan_json_path=".ralphception/plans/mission-plan.json",
        todo_ids=["todo-1", "todo-2"],
        commit_intent_ids=["intent-1"],
        execution_policy=ExecutionPolicy(
            max_parallel_children=2,
            batch_by_scope=True,
            allow_commit_split=True,
        ),
    )
    assert [todo.todo_id for todo in store.read_todos()] == ["todo-1", "todo-2"]
    assert [intent.intent_id for intent in store.read_commit_intents()] == ["intent-1"]
    assert store.read_planner_output() == output


def test_start_fresh_resolution_clears_blocked_runtime_state_and_reopens_startup(tmp_path: Path) -> None:
    repo_root = _prepare_launch_conflict_workspace(tmp_path / "start-fresh")
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState().model_copy(
            update={
                "pending_prompts": [
                    PendingPrompt(
                        thread_id="run-root",
                        owner_run_id="run-root",
                        prompt_id="prompt-launch-1",
                        prompt_kind="resume_session",
                        title="Resume session",
                        question="Resume or start fresh?",
                        allowed_actions=("resume", "start_fresh"),
                        context={},
                        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
                    )
                ],
                "deferred_inputs": [
                    DeferredInput(thread_id="run-root", text="resume the blocked turn"),
                ],
                "bootstrap_source_repos": ["/tmp/source-a"],
            }
        ),
    )

    result = RuntimeSupervisor(repo_root=repo_root).resolve_pending_prompt(
        thread_id="run-root",
        user_text="start fresh",
    )

    state = load_interactive_session_state(repo_root)

    assert result.kind == "resolved"
    assert result.action == "start_fresh"
    assert load_startup_record(repo_root) is None
    assert [prompt.prompt_kind for prompt in state.pending_prompts] == ["startup_prompt"]
    assert state.deferred_inputs == []
    assert load_interactive_session_marker(repo_root) is None


def test_override_resolution_bootstraps_replacement_and_clears_superseded_inputs(tmp_path: Path) -> None:
    repo_root = _prepare_launch_conflict_workspace(tmp_path / "override")
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState().model_copy(
            update={
                "pending_prompts": [
                    PendingPrompt(
                        thread_id="run-root",
                        owner_run_id="run-root",
                        prompt_id="prompt-conflict-1",
                        prompt_kind="launch_conflict",
                        title="Session conflict",
                        question="Replace the unfinished session in this workspace?",
                        allowed_actions=("override", "abort"),
                        context={
                            "requested_seed_prompt": "new mission",
                            "source_repos": ["/tmp/source-a"],
                        },
                        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
                    )
                ],
                "deferred_inputs": [
                    DeferredInput(thread_id="run-root", text="stale launch reply"),
                ],
            }
        ),
    )

    result = RuntimeSupervisor(repo_root=repo_root).resolve_pending_prompt(
        thread_id="run-root",
        user_text="override",
    )

    state = load_interactive_session_state(repo_root)
    startup_record = load_startup_record(repo_root)

    assert result.kind == "resolved"
    assert result.action == "override"
    assert startup_record is None
    assert [prompt.prompt_kind for prompt in state.pending_prompts] == ["startup_prompt"]
    assert state.pending_prompts[0].context["intake_answers"] == ["new mission"]
    assert state.pending_prompts[0].question
    assert state.deferred_inputs == []


def test_replace_resolution_clears_only_blocked_continuation_inputs(tmp_path: Path) -> None:
    repo_root = _prepare_recovery_workspace(tmp_path / "replace", child_status="blocked")
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState().model_copy(
            update={
                "pending_prompts": [
                    PendingPrompt(
                        thread_id="run-child-1",
                        owner_run_id="run-child-1",
                        prompt_id="prompt-recovery-1",
                        prompt_kind="recovery_review",
                        title="Recovery review",
                        question="Retry, replace, or abort?",
                        allowed_actions=("retry", "replace", "abort"),
                        context={},
                        blocked_continuation=BlockedContinuationRef(thread_id="run-child-1", run_id="run-child-1"),
                    ),
                    PendingPrompt(
                        thread_id="run-other",
                        owner_run_id="run-other",
                        prompt_id="prompt-other-1",
                        prompt_kind="review_prompt",
                        title="Other prompt",
                        question="Approve?",
                        allowed_actions=("approve",),
                        context={},
                    ),
                ],
                "deferred_inputs": [
                    DeferredInput(thread_id="run-child-1", text="stale blocked reply"),
                    DeferredInput(thread_id="run-other", text="keep me"),
                ],
            }
        ),
    )

    supervisor = RuntimeSupervisor(repo_root=repo_root)
    result = supervisor.resolve_pending_prompt(thread_id="run-child-1", user_text="replace")
    state = load_interactive_session_state(repo_root)

    assert result.kind == "resolved"
    assert result.action == "replace"
    assert [prompt.owner_run_id for prompt in state.pending_prompts] == ["run-other"]
    assert [item.thread_id for item in state.deferred_inputs] == ["run-other"]
    assert (repo_root / ".ralphception" / "runs" / "run-child-1-replacement-1" / "run.json").exists()


def test_abort_resolution_marks_blocked_run_non_resumable(tmp_path: Path) -> None:
    repo_root = _prepare_recovery_workspace(tmp_path / "abort", child_status="blocked")
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState().model_copy(
            update={
                "pending_prompts": [
                    PendingPrompt(
                        thread_id="run-child-1",
                        owner_run_id="run-child-1",
                        prompt_id="prompt-recovery-1",
                        prompt_kind="recovery_review",
                        title="Recovery review",
                        question="Retry, replace, or abort?",
                        allowed_actions=("retry", "replace", "abort"),
                        context={},
                        blocked_continuation=BlockedContinuationRef(thread_id="run-child-1", run_id="run-child-1"),
                    )
                ]
            }
        ),
    )

    result = RuntimeSupervisor(repo_root=repo_root).resolve_pending_prompt(
        thread_id="run-child-1",
        user_text="abort",
    )

    aborted_run = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )
    marker = load_interactive_session_marker(repo_root)

    assert result.kind == "resolved"
    assert result.action == "abort"
    assert aborted_run.status == "aborted"
    assert marker is not None
    assert marker.resumable is False


def _prepare_launch_conflict_workspace(repo_root: Path) -> Path:
    repo_root.mkdir(parents=True)
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="existing mission",
        source_repos=[],
    )
    now = datetime.now(timezone.utc)
    write_interactive_session_marker(
        repo_root,
        InteractiveSessionMarker(
            root_run_id="run-root",
            active_run_id="run-root",
            resumable=True,
            blocking_surface_kind="review",
            updated_at=now,
        ),
    )
    return repo_root


def _prepare_recovery_workspace(repo_root: Path, *, child_status: RunStageStatus) -> Path:
    repo_root.mkdir(parents=True)
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    now = datetime.now(timezone.utc)
    run_dir = repo_root / ".ralphception" / "runs" / "run-child-1"
    run_dir.mkdir(parents=True, exist_ok=True)
    run_dir.joinpath("run.json").write_text(
        Run(
            run_id="run-child-1",
            parent_run_id="run-root",
            supersedes_run_id=None,
            goal="Inspect the blocked runtime",
            status=child_status,
            stage_ids=[],
            config_snapshot={"codex": {"model": "gpt-5.4"}},
            codex_session_ref=ChildSessionRef(
                run_id="run-child-1",
                codex_thread_id="thread-child-1",
                codex_session_id="session-child-1",
                workspace_path=str(repo_root),
                resumable=True,
                last_seen_at=now,
            ),
            artifact_refs=[],
            created_at=now,
            updated_at=now,
        ).model_dump_json(indent=2),
        encoding="utf-8",
    )
    write_interactive_session_marker(
        repo_root,
        InteractiveSessionMarker(
            root_run_id="run-root",
            active_run_id="run-child-1",
            resumable=True,
            blocking_surface_kind="review",
            updated_at=now,
        ),
    )
    return repo_root


def _init_git_repo(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], cwd=repo_root, check=True, capture_output=True, text=True)
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
