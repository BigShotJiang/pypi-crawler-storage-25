from __future__ import annotations

import asyncio
from contextlib import contextmanager
from dataclasses import replace
from pathlib import Path

from ralphception.tui.chatwidget.transcript_cells import (
    ActiveCell,
    AssistantCell,
    CommandCell,
    StreamingCell,
    SystemCell,
    UserCell,
)
from ralphception.tui.chatwidget.transcript_overlay import TranscriptOverlay
from ralphception.tui.chatwidget.transcript_view import TranscriptView, render_transcript
from ralphception.tui.app import RalphceptionTuiApp
from ralphception.tui.bottom_pane.chat_composer import ChatComposer
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.testing.fakes import FakeCodexClient, FakeNotification
from ralphception.config import RalphceptionConfig
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.frontends import ReviewDecision
from ralphception.runtime.supervisor import RuntimeSupervisor


def test_transcript_renders_committed_and_streaming_cells() -> None:
    rendered = render_transcript(
        committed=[
            UserCell(text="Investigate the failing approval flow."),
            AssistantCell(text="I am checking the current runtime state."),
            CommandCell(
                command="git status --short --branch",
                output=("## feat/codex-appserver-port",),
                status="completed",
            ),
        ],
        active=StreamingCell(prefix="thinking", text="Working..."),
        width=80,
    )
    assert "Investigate the failing approval flow." in rendered
    assert "I am checking the current runtime state." in rendered
    assert "• Ran git status --short --branch" in rendered
    assert "└ ## feat/codex-appserver-port" in rendered
    assert "Working..." in rendered


def test_transcript_uses_codex_style_prefixes_for_user_and_system_cells() -> None:
    rendered = render_transcript(
        committed=[
            UserCell(text="Inspect the runtime adapter implementation."),
            SystemCell(text="Mission ready."),
        ],
        active=None,
        width=80,
    )

    assert "› Inspect the runtime adapter implementation." in rendered
    assert "• Mission ready." in rendered


def test_transcript_renders_active_command_output_deltas_inline() -> None:
    rendered = render_transcript(
        committed=[],
        active=ActiveCell(
            prefix="$",
            text="git status --short",
            item_id="command-1",
            output=("M src/ralphception/tui/runtime_adapter.py",),
        ),
        width=80,
    )

    assert "• Running git status --short" in rendered
    assert "└ M src/ralphception/tui/runtime_adapter.py" in rendered


def test_transcript_view_scrolls_to_tail_and_follows_appended_output() -> None:
    app = RalphceptionTuiApp.for_idle_preview(Path("/tmp"))

    async def exercise() -> tuple[int, int, int]:
        async with app.run_test() as pilot:
            await pilot.pause()
            initial_state = replace(
                app.render_state,
                transcript=replace(
                    app.render_state.transcript,
                    committed=tuple(SystemCell(f"line {index}") for index in range(120)),
                ),
            )
            app._set_render_state(initial_state)
            await pilot.pause()
            transcript = app.query_one("#transcript-view", TranscriptView)
            transcript.scroll_end(animate=False)
            await pilot.pause()
            after_scroll = transcript.scroll_offset.y
            appended_state = replace(
                app.render_state,
                transcript=replace(
                    app.render_state.transcript,
                    committed=tuple(SystemCell(f"line {index}") for index in range(140)),
                ),
            )
            app._set_render_state(appended_state)
            await pilot.pause()
            return after_scroll, transcript.scroll_offset.y, transcript.max_scroll_y

    after_scroll, after_append, max_scroll_y = asyncio.run(exercise())
    assert max_scroll_y > 0
    assert after_scroll == max_scroll_y
    assert after_append == max_scroll_y


def test_tui_app_ctrl_t_opens_transcript_overlay_with_committed_history() -> None:
    app = RalphceptionTuiApp.for_idle_preview(Path("/tmp"))

    async def exercise() -> tuple[int, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            next_state = replace(
                app.render_state,
                transcript=replace(
                    app.render_state.transcript,
                    committed=(
                        UserCell("Inspect the runtime adapter."),
                        AssistantCell("Checking the current shell state."),
                    ),
                ),
            )
            app._set_render_state(next_state)
            await pilot.pause()
            await pilot.press("ctrl+t")
            await pilot.pause()
            return (
                len(app.query("#transcript-overlay")),
                str(app.query_one("#transcript-overlay", TranscriptOverlay).renderable),
            )

    overlay_count, rendered = asyncio.run(exercise())
    assert overlay_count == 1
    assert "Inspect the runtime adapter." in rendered
    assert "Checking the current shell state." in rendered


def test_tui_app_transcript_overlay_includes_live_active_tail() -> None:
    app = RalphceptionTuiApp.for_idle_preview(Path("/tmp"))

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            next_state = replace(
                app.render_state,
                transcript=replace(
                    app.render_state.transcript,
                    committed=(SystemCell("Mission ready."),),
                    active=ActiveCell(
                        prefix="$",
                        text="git status --short",
                        item_id="command-1",
                        output=("M src/ralphception/tui/runtime_adapter.py",),
                    ),
                ),
            )
            app._set_render_state(next_state)
            await pilot.pause()
            await pilot.press("ctrl+t")
            await pilot.pause()
            return str(app.query_one("#transcript-overlay", TranscriptOverlay).renderable)

    rendered = asyncio.run(exercise())
    assert "Mission ready." in rendered
    assert "• Running git status --short" in rendered
    assert "└ M src/ralphception/tui/runtime_adapter.py" in rendered


def test_tui_app_escape_closes_transcript_overlay_and_restores_composer_focus() -> None:
    app = RalphceptionTuiApp.for_idle_preview(Path("/tmp"))

    async def exercise() -> tuple[int, int]:
        async with app.run_test() as pilot:
            await pilot.pause()
            await pilot.press("ctrl+t")
            await pilot.pause()
            await pilot.press("escape")
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            return len(app.query("#transcript-overlay")), int(app.focused is composer)

    overlay_count, composer_focused = asyncio.run(exercise())
    assert overlay_count == 0
    assert composer_focused == 1


def test_inline_tui_flushes_committed_history_to_scrollback(monkeypatch) -> None:
    printed: list[str] = []

    @contextmanager
    def fake_suspend(self):
        yield

    monkeypatch.setattr(RalphceptionTuiApp, "is_inline", property(lambda self: True))
    monkeypatch.setattr(RalphceptionTuiApp, "suspend", fake_suspend)
    monkeypatch.setattr("builtins.print", lambda *args, **kwargs: printed.append(" ".join(str(arg) for arg in args)))

    app = RalphceptionTuiApp.for_idle_preview(Path("/tmp"))

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            next_state = replace(
                app.render_state,
                transcript=replace(
                    app.render_state.transcript,
                    committed=(
                        UserCell("Inspect the workspace."),
                        AssistantCell("Reviewing README.md for typo-only fixes."),
                    ),
                ),
            )
            app._set_render_state(next_state)
            await pilot.pause()
            return str(app.query_one("#transcript-view", TranscriptView).renderable)

    rendered = asyncio.run(exercise())
    flushed = "\n".join(printed)
    assert "Inspect the workspace." in flushed
    assert "Reviewing README.md for typo-only fixes." in flushed
    assert "Inspect the workspace." not in rendered
    assert "Reviewing README.md for typo-only fixes." not in rendered

def test_tui_app_transcript_overlay_keeps_background_wait_visible_during_unresolved_run(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_background_wait_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            for _ in range(80):
                await pilot.pause()
                await asyncio.sleep(0.01)
            await pilot.press("ctrl+t")
            await pilot.pause()
            return str(app.query_one("#transcript-overlay", TranscriptOverlay).renderable)

    rendered = asyncio.run(exercise())
    assert "Waiting" in rendered
    assert "tail -f log" in rendered
def _prepare_dashboard_workspace(tmp_path: Path) -> Path:
    repo_root = tmp_path / "dashboard-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    spec_path = repo_root / ".ralphception" / "specs" / "runtime.md"
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text("# Runtime Spec\n\n- Review before planning.\n", encoding="utf-8")
    RuntimeSupervisor(repo_root=repo_root).apply_review_decision(ReviewDecision(action="approve", approver="tui"))
    return repo_root


def _background_wait_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        del input_text
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="subagent_waiting",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "agentThreadId": "worker-1",
                        "summary": "Waiting on tail -f log",
                    },
                ),
            ],
        )

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )
