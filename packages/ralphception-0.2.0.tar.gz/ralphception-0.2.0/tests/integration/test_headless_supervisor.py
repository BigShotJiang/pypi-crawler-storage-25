from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import patch

from pydantic import ValidationError
import pytest

from ralphception.headless import HeadlessMissionSupervisor
from ralphception.models.runtime import Run
from ralphception.runtime.interactive_session import (
    load_interactive_session_marker,
    load_interactive_session_state,
)
from ralphception.runtime.terminal import ScriptedTerminalFrontend, run_terminal
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.storage.artifacts import read_authoritative_revision
from ralphception.storage.lease import lease_path
from ralphception.testing.fakes import (
    FakeHeadlessTurnWriter,
    build_fake_headless_session_manager,
    build_fake_session_manager,
)

_STARTUP_CONTEXT_REPLY = "focus on docs and comments only"
_STARTUP_BOUNDARY_REPLY = (
    "completion means the first execution slice is verified, stays in scope, and is ready for review"
)
_BUG_HUNT_OUTCOME_REPLY = (
    "focus on one concrete bug with a failing test and a verified fix"
)
_BUG_HUNT_BOUNDARY_REPLY = (
    "do not refactor unrelated code, and stop once one real bug is fixed and verified"
)


def _seeded_follow_up_inputs(*answers: str) -> list[str]:
    if answers and "typo" in answers[0].lower():
        return [
            *answers,
            "docs and comments only",
            "spelling only, and completion means the docs/comments typo pass is clean",
        ]
    if answers and "bug" in answers[0].lower():
        return [*answers, _BUG_HUNT_OUTCOME_REPLY, _BUG_HUNT_BOUNDARY_REPLY]
    return [*answers, _STARTUP_CONTEXT_REPLY, _STARTUP_BOUNDARY_REPLY]


def test_terminal_run_completes_full_mission_and_preserves_durable_artifacts(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("Port parser"))

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert result.root_run_id == "run-root"
    assert result.authoritative_repo_root == str(repo_root)
    assert "Runtime: completed" in frontend.output_text()
    assert (repo_root / ".ralphception").exists()
    assert (repo_root / ".ralphception" / "specs" / "prd.md").exists()
    assert (repo_root / ".ralphception" / "plans" / "execution-plan.md").exists()
    assert (repo_root / ".ralphception" / "plans" / "execution-plan.json").exists()
    assert not (repo_root / ".ralphception" / "specs" / "mission-spec.md").exists()
    assert not (repo_root / ".ralphception" / "plans" / "mission-plan.md").exists()
    assert not (repo_root / ".ralphception" / "plans" / "mission-plan.json").exists()
    assert read_authoritative_revision(repo_root, "prd") is not None
    assert read_authoritative_revision(repo_root, "execution-plan") is not None
    assert read_authoritative_revision(repo_root, "loop-plan") is not None
    assert read_authoritative_revision(repo_root, "todos") is not None
    assert (repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json").exists() is False
    assert (repo_root / ".ralphception" / "runs" / "run-root" / "startup.json").exists() is False
    assert load_interactive_session_marker(repo_root) is None
    assert not lease_path(repo_root, xdg_state_home=tmp_path / "xdg-state").exists()
    assert git_status(repo_root) == ""
    assert git_author(repo_root) == "Test User <test@example.com>"
    assert git_subject(repo_root) == "feat: Port parser"
    worktrees_root = repo_root / ".worktrees"
    assert not worktrees_root.exists() or list(worktrees_root.iterdir()) == []


def test_terminal_run_preserves_non_runtime_worktrees_root_contents(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("Port parser"))
    external_worktree = repo_root / ".worktrees" / "feat-dev-shell"
    external_worktree.mkdir(parents=True)
    marker = external_worktree / "KEEP"
    marker.write_text("preserve me\n", encoding="utf-8")

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert external_worktree.exists()
    assert marker.read_text(encoding="utf-8") == "preserve me\n"


def test_terminal_run_from_nested_linked_worktree_under_worktrees_root_completes(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    nested_worktree = repo_root / ".worktrees" / "feat" / "dev-shell"
    nested_worktree.parent.mkdir(parents=True, exist_ok=True)
    run_git(
        repo_root,
        "worktree",
        "add",
        "-b",
        "codex/dev-shell",
        str(nested_worktree),
        "main",
    )
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(
        inputs=_seeded_follow_up_inputs("find and fix typos"),
        repo_root=nested_worktree,
    )

    result = run_terminal(
        repo_root=nested_worktree,
        seed_prompt="find and fix typos",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert result.authoritative_repo_root == str(nested_worktree)


def test_terminal_run_emits_explicit_loop_launch_and_completion_messages(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find and fix typos"))

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find and fix typos",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    text = frontend.output_text()

    assert result.mode == "completed"
    assert "Launched 1 Ralph loop" in text
    assert "Loop completed" in text


def test_terminal_run_surfaces_bootstrap_artifact_writes_before_loop_launch(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find and fix typos"))

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find and fix typos",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    text = frontend.output_text()

    assert result.mode == "completed"
    assert "Wrote intake summary" in text
    assert "Wrote PRD" in text
    assert "Wrote execution plan" in text
    assert "Wrote loop plan" in text
    assert "Wrote todos" in text


def test_terminal_run_executes_each_planned_loop_before_merge(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    _prepare_multi_loop_plan(repo_root)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    result = run_terminal(
        repo_root=repo_root,
        resume=True,
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    text = frontend.output_text()

    assert result.mode == "completed"
    assert text.count("Loop completed") >= 2
    assert "Merged: run-child-2" in text


def test_headless_supervisor_persists_durable_loop_events(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    _prepare_multi_loop_plan(repo_root)
    frontend = _PassiveFrontend()

    with patch.object(HeadlessMissionSupervisor, "_cleanup_completed_runtime_state", lambda self: None):
        result = HeadlessMissionSupervisor(
            repo_root=repo_root,
            primary_repo_root=repo_root,
            seed_prompt=None,
            source_repos=(),
            approve_all=True,
            approver="headless",
            session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
                workspace_path=str(resolved_repo_root),
                config=config,
            ),
        ).run(frontend=frontend)

    events_text = (repo_root / ".ralphception" / "events" / "run-root.jsonl").read_text(encoding="utf-8")

    assert result.mode == "completed"
    assert "stage.custom_loop_launched" in events_text
    assert "stage.custom_loop_completed" in events_text


def test_headless_supervisor_uses_audit_replacement_goal_for_reopened_execute(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))
    execute_contracts: list[dict[str, object]] = []

    class RecordingExecuteWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            contract = _extract_headless_contract(input_text)
            if contract is not None and contract.get("stage") == "execute":
                execute_contracts.append(contract)
            super().handle_turn(session, input_text, turn_counter)

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = RecordingExecuteWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert len(execute_contracts) >= 2
    assert execute_contracts[1]["goal"] != execute_contracts[0]["goal"]
    assert execute_contracts[1]["goal"] == "Resolve blocking audit findings: Parser change needs regression coverage.."


def test_headless_supervisor_includes_full_loop_contract_in_execute_prompt(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    _prepare_multi_loop_plan(repo_root)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend()
    execute_contracts: list[dict[str, object]] = []

    class RecordingExecuteWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            contract = _extract_headless_contract(input_text)
            if contract is not None and contract.get("stage") == "execute":
                execute_contracts.append(contract)
            super().handle_turn(session, input_text, turn_counter)

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = RecordingExecuteWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        resume=True,
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert execute_contracts
    first_contract = execute_contracts[0]
    assert first_contract["loop_id"] == "loop-todo-1"
    assert first_contract["plan_node_id"] == "todo-1"
    assert first_contract["objective"] == "Inspect markdown typos"
    assert first_contract["stop_conditions"] == ["Inspect markdown typos is settled"]
    assert first_contract["output_contract"] == ["publish todo-1 Ralph-loop findings"]
    assert first_contract["target_artifacts"] == ["docs/README.md"]
    assert first_contract["merge_strategy"] == "direct_update"


def test_terminal_run_starts_fresh_after_completed_mission_cleanup(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    first_frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("Port parser"))

    first = run_terminal(
        repo_root=repo_root,
        seed_prompt="Port parser",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=first_frontend,
    )
    second_frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))
    restarted = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=second_frontend,
    )

    assert first.mode == "completed"
    assert restarted.mode == "completed"
    assert "Resumed run-root" not in second_frontend.output_text()
    assert "Bootstrapped run-root" not in second_frontend.output_text()
    assert "Executing the loop plan" in second_frontend.output_text()


def test_terminal_run_completes_when_repo_tracks_runtime_event_log(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path, track_runtime_event_log=True)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        use_fake_session_manager=True,
        frontend=frontend,
    )

    assert result.mode == "completed"
    assert "Runtime: completed" in frontend.output_text()


def test_terminal_run_accepts_string_artifact_handoffs_from_execute_stage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    class StringArtifactWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["artifacts"] = ["src/parser.py", f".ralphception/runs/{run_id}/handoff.json"]
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = StringArtifactWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert "Session completed: run-root" in frontend.output_text()


def test_terminal_run_accepts_object_merge_readiness_from_execute_stage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    class ObjectMergeReadinessWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["merge_readiness"] = {
                "ready": True,
                "notes": "Only the requested files were added.",
            }
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = ObjectMergeReadinessWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert "Session completed: run-root" in frontend.output_text()


def test_terminal_run_accepts_list_summary_handoffs_from_execute_stage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    class ListSummaryWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["summary"] = [
                "Searched markdown files for obvious typos.",
                "Applied minimal fixes to README.md.",
            ]
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = ListSummaryWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "completed"
    assert "Session completed: run-root" in frontend.output_text()


def test_terminal_run_returns_failed_result_when_execute_handoff_is_not_merge_ready(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    class BlockedMergeReadinessWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["merge_readiness"] = "blocked"
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = BlockedMergeReadinessWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        approve_all=True,
        frontend=frontend,
        session_manager_factory=session_manager_factory,
    )

    assert result.mode == "failed"
    assert "Runtime: failed" in frontend.output_text()
    assert "handoff is not merge-ready: blocked" in frontend.output_text()
    assert "Traceback" not in frontend.output_text()

    child_run = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )
    assert child_run.status == "failed"


def test_terminal_run_rejects_merge_ready_execute_handoffs_without_touched_paths(
    tmp_path: Path,
    monkeypatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "xdg-state"))
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    class EmptyExecuteHandoffWriter(FakeHeadlessTurnWriter):
        def handle_turn(self, session, input_text: str, turn_counter: int) -> None:
            super().handle_turn(session, input_text, turn_counter)
            if '"stage": "execute"' not in input_text:
                return
            run_id = "run-child-1-replacement-1" if "-replacement-" in input_text else "run-child-1"
            handoff_path = Path(session.workspace_path) / ".ralphception" / "runs" / run_id / "handoff.json"
            payload = json.loads(handoff_path.read_text(encoding="utf-8"))
            payload["artifacts"] = []
            payload["touched_paths"] = []
            handoff_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def session_manager_factory(resolved_repo_root: Path, config):
        writer = EmptyExecuteHandoffWriter()
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    with pytest.raises(
        ValidationError,
        match="merge-ready execute handoffs must report at least one touched path",
    ):
        run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            approve_all=True,
            frontend=frontend,
            session_manager_factory=session_manager_factory,
        )


class _PassiveFrontend:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def emit_event(self, event) -> None:
        self.messages.append(event.message)

    def emit_status(self, step) -> None:
        self.messages.append(f"Runtime: {step.kind}")

    def finish(self, step) -> None:
        self.messages.append(f"Finished: {step.kind}")


def test_headless_supervisor_runs_direct_startup_without_frontend_callback_methods(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    frontend = _PassiveFrontend()

    result = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt=None,
        source_repos=(),
        approve_all=False,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    ).run(frontend=frontend)

    state = load_interactive_session_state(repo_root)

    assert result.mode == "completed"
    assert state.pending_prompts == []
    assert any("Stage: execute" in message for message in frontend.messages)
    assert all("spec review pending" not in message.lower() for message in frontend.messages)


def make_git_repo(tmp_path: Path, *, track_runtime_event_log: bool = False) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    if track_runtime_event_log:
        tracked_event_log = repo_root / ".ralphception" / "events" / "run-root.jsonl"
        tracked_event_log.parent.mkdir(parents=True, exist_ok=True)
        tracked_event_log.write_text("", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    if track_runtime_event_log:
        run_git(repo_root, "add", ".ralphception/events/run-root.jsonl")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "initial",
    )
    run_git(repo_root, "config", "user.name", "Test User")
    run_git(repo_root, "config", "user.email", "test@example.com")
    return repo_root


def _prepare_multi_loop_plan(repo_root: Path) -> None:
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    plans_dir = repo_root / ".ralphception" / "plans"
    specs_dir = repo_root / ".ralphception" / "specs"
    plans_dir.mkdir(parents=True, exist_ok=True)
    specs_dir.mkdir(parents=True, exist_ok=True)
    (specs_dir / "mission-spec.md").write_text("# Mission Spec\n", encoding="utf-8")
    (plans_dir / "mission-plan.md").write_text("# Mission Plan\n", encoding="utf-8")
    (plans_dir / "mission-plan.json").write_text(
        json.dumps(
            {
                "execution_goal": "Find and fix typos.",
                "verification_commands": ['python -c "print(\'verification\')"'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Inspect markdown typos",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["docs/README.md"],
                    },
                    {
                        "todo_id": "todo-2",
                        "title": "Inspect code comments",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-2",
                        "scope_hints": ["src/parser.py"],
                    },
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "docs: fix markdown typos",
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    },
                    {
                        "intent_id": "intent-2",
                        "message": "fix: correct code comment typos",
                        "todo_ids": ["todo-2"],
                        "ordering_after": [],
                    },
                ],
                "execution_policy": {
                    "max_parallel_children": 2,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )


def run_git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def git_status(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "status", "--short"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def git_author(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%an <%ae>"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def git_subject(repo_root: Path) -> str:
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%s"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _extract_headless_contract(input_text: str) -> dict[str, object] | None:
    begin = "HEADLESS_CONTRACT_START"
    end = "HEADLESS_CONTRACT_END"
    if begin not in input_text or end not in input_text:
        return None
    raw_contract = input_text.split(begin, 1)[1].split(end, 1)[0].strip()
    return json.loads(raw_contract)
