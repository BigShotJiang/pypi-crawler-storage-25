from __future__ import annotations

from pathlib import Path

from ralphception.tui.multi_agents import AgentThreadState, render_agent_picker


def test_agent_picker_formats_role_and_nickname_like_codex() -> None:
    fixture_path = Path(__file__).resolve().parents[1] / "golden" / "codex_port" / "subagent_picker.txt"
    rendered = render_agent_picker(
        [AgentThreadState(thread_id="run-child-1", nickname="Worker 1", role="worker", closed=False)],
        active_thread_id="run-child-1",
        width=80,
    )
    assert rendered == fixture_path.read_text(encoding="utf-8")
    assert "Worker 1 [worker]" in rendered
