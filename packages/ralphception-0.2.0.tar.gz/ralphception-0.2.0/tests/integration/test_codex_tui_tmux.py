from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import re
import subprocess
from types import SimpleNamespace

import pytest
import ralphception.headless as headless_module
from ralphception.app import run_app, run_exec
from ralphception.codex_tui.app import (
    ScriptedCodexTuiFrontend,
    maybe_run_trust_onboarding,
    run_codex_tui_shell,
)
from ralphception.codex_tui.history_cell import StartupShellHistoryCell
from ralphception.codex_tui.history_cell import AssistantHistoryCell
from ralphception.codex_tui.history_cell import CommandHistoryCell
from ralphception.codex_tui.history_cell import UserHistoryCell
from ralphception.codex_tui.custom_terminal import CustomTerminal, Position, Size
from ralphception.codex_tui.status import DEFAULT_STARTER_PLACEHOLDER
from ralphception.codex_tui.styled_text import strip_ansi
from ralphception.runtime.project_trust import load_project_trust, save_project_trust
from ralphception.codex_tui.tui import Tui
from ralphception.runtime.frontends import BlockerPromptEvent
from ralphception.runtime.frontends import FrontendEvent
from ralphception.runtime.interactive_session import InteractiveSessionMarker, write_interactive_session_marker
from ralphception.runtime.supervisor import RuntimeSupervisor


@dataclass
class _FakeBackend:
    screen_size: Size = Size(width=80, height=24)
    cursor_position: Position = Position(x=0, y=0)
    default_foreground: tuple[int, int, int] | None = (255, 255, 255)
    default_background: tuple[int, int, int] | None = (0, 0, 0)
    color_level: str = "truecolor"
    writes: list[str] = field(default_factory=list)

    def size(self) -> Size:
        return self.screen_size

    def get_cursor_position(self) -> Position:
        return self.cursor_position

    def write(self, data: str) -> None:
        self.writes.append(data)

    def flush(self) -> None:
        return

    def enter_raw_mode(self) -> None:
        return

    def leave_raw_mode(self) -> None:
        return

    def get_default_background(self) -> tuple[int, int, int] | None:
        return self.default_background

    def get_default_foreground(self) -> tuple[int, int, int] | None:
        return self.default_foreground

    def get_stdout_color_level(self) -> str:
        return self.color_level


class _DrainTrackingFrontend(ScriptedCodexTuiFrontend):
    def __init__(self, *, repo_root: Path) -> None:
        self.drained_input = 0
        super().__init__(
            repo_root=repo_root,
            inputs=(),
            tui=_fake_tui(),
            draw_initial_shell=False,
            enable_trust_onboarding=True,
        )

    def prompt_trust_decision(self, *, cwd: Path) -> str:
        del cwd
        return "trust"

    def drain_pending_input(self) -> None:
        self.drained_input += 1


def _make_git_repo(tmp_path: Path) -> Path:
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=tmp_path,
        check=True,
        capture_output=True,
    )
    (tmp_path / "README.md").write_text("This is the readme.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=tmp_path, check=True, capture_output=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=tmp_path, check=True, capture_output=True)
    return tmp_path


def _fake_tui() -> Tui:
    tui = Tui(terminal=CustomTerminal.with_home_viewport(_FakeBackend()))
    tui._refresh_terminal_palette(requery=False)
    return tui


def test_run_codex_tui_shell_begins_with_socratic_intake(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=[
            "look at and fix typos in the readme",
            "README only",
            "spelling only, and completion means the README typo pass is clean",
        ],
        tui=_fake_tui(),
    )

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = frontend.output_text()
    rendered = "".join(frontend.tui.terminal.backend.writes)  # type: ignore[union-attr]

    assert result.mode == "completed"
    assert "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?" in output
    assert "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?" in output
    assert "Wrote intake summary" in output
    assert re.search(r"\x1b\[[0-9;]*m", rendered)


def test_first_prompt_shows_working_state_before_startup_resolution_returns(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["hello"],
        tui=_fake_tui(),
    )
    observed: dict[str, list[str]] = {}

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        assert user_text == "hello"
        observed["live_lines"] = [strip_ansi(line) for line in frontend.adapter.chatwidget.render_lines(100)]

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self, frontend
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert observed["live_lines"][0] == ""
    assert observed["live_lines"][1].startswith("• Working (")
    assert observed["live_lines"][2] == ""
    assert observed["live_lines"][3].strip() == ""
    assert observed["live_lines"][4].startswith("› ")
    assert any("? for shortcuts" in line for line in observed["live_lines"])
    assert not any("gpt-5.4 xhigh fast · 100% left ·" in line for line in observed["live_lines"])


def test_blocker_reply_shows_working_state_before_resolution_returns(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["hello", "whole repo"],
        tui=_fake_tui(),
    )
    prompt = SimpleNamespace(prompt_kind="startup_prompt", thread_id="run-root")
    observed: dict[str, list[str]] = {}
    state = {"run_calls": 0, "resolved": False}

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        assert user_text == "hello"

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self
        state["run_calls"] += 1
        if state["run_calls"] == 1:
            assert frontend is not None
            frontend.emit_event(
                BlockerPromptEvent(
                    prompt_id="startup:scope",
                    title="Scope",
                    question="Which scope should I use?",
                )
            )
            return headless_module.HeadlessRunResult(
                mode="startup",
                actions=(),
                root_run_id="run-root",
                authoritative_repo_root=str(repo_root),
            )
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    def fake_current_pending_prompt(self: RuntimeSupervisor):
        del self
        return None if state["resolved"] else prompt

    def fake_resolve_pending_prompt(self: RuntimeSupervisor, *, thread_id: str, user_text: str):
        del self
        assert thread_id == "run-root"
        assert user_text == "whole repo"
        observed["live_lines"] = [strip_ansi(line) for line in frontend.adapter.chatwidget.render_lines(100)]
        state["resolved"] = True
        return SimpleNamespace(kind="resolved", action="resume")

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)
    monkeypatch.setattr(RuntimeSupervisor, "current_pending_prompt", fake_current_pending_prompt)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_pending_prompt", fake_resolve_pending_prompt)

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert observed["live_lines"][0] == ""
    assert observed["live_lines"][1].startswith("• Working (")
    assert observed["live_lines"][2] == ""
    assert observed["live_lines"][3].strip() == ""
    assert observed["live_lines"][4].startswith("› ")
    assert any("? for shortcuts" in line for line in observed["live_lines"])
    assert not any("Type your answer (optional)" in line for line in observed["live_lines"])


def test_blocker_prompt_renders_request_input_overlay(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["hello"],
        tui=_fake_tui(),
    )
    observed: dict[str, list[str]] = {}

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        assert user_text == "hello"

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self
        assert frontend is not None
        frontend.emit_event(
            BlockerPromptEvent(
                prompt_id="startup:scope",
                title="Scope",
                question="Which scope should I use?",
            )
        )
        observed["live_lines"] = [strip_ansi(line) for line in frontend.adapter.chatwidget.render_lines(100)]
        return headless_module.HeadlessRunResult(
            mode="startup",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "running"
    assert "  Question 1/1 (1 unanswered)" in observed["live_lines"]
    assert any("Which scope should I use?" in line for line in observed["live_lines"])
    assert any("Type your answer (optional)" in line for line in observed["live_lines"])
    assert any("enter to submit answer | esc to interrupt" in line for line in observed["live_lines"])
    composer_index = next(
        idx for idx, line in enumerate(observed["live_lines"]) if "Type your answer (optional)" in line
    )
    footer_index = next(
        idx
        for idx, line in enumerate(observed["live_lines"])
        if "enter to submit answer | esc to interrupt" in line
    )
    assert observed["live_lines"][composer_index + 1].strip() == ""
    assert observed["live_lines"][composer_index + 2].strip() == ""
    assert observed["live_lines"][composer_index + 3].strip() == ""
    assert footer_index == composer_index + 4


def test_first_prompt_flushes_startup_shell_out_of_live_viewport(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["find and fix all the typos"],
        tui=_fake_tui(),
    )

    first_prompt = frontend.read_user_input()
    live_lines = [strip_ansi(line) for line in frontend.adapter.chatwidget.render_lines(80)]
    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert first_prompt == "find and fix all the typos"
    assert ">_ Ralphception" not in "\n".join(live_lines)
    assert "/model to change" not in "\n".join(live_lines)
    assert "Tip: Ralphception starts with Socratic intake" not in "\n".join(live_lines)
    assert "Ralphception" in rendered
    assert "Tip: Ralphception starts with Socratic intake" in rendered
    startup_cell = frontend.adapter.chatwidget.committed_cells[0]
    assert isinstance(startup_cell, StartupShellHistoryCell)
    assert startup_cell.display_lines(80)[-1] == ""
    user_cell = frontend.adapter.chatwidget.committed_cells[1]
    assert isinstance(user_cell, UserHistoryCell)
    user_lines = [strip_ansi(line) for line in user_cell.display_lines(80)]
    assert user_lines[0] == " " * 80
    assert user_lines[1].startswith("› find and fix all the typos")
    assert len(user_lines[1]) == 80
    assert user_lines[-1] == " " * 80


def test_scripted_frontend_starts_with_codex_like_idle_shell(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    assert frontend.tui is not None
    backend = frontend.tui.terminal.backend
    assert isinstance(backend, _FakeBackend)
    rendered = "".join(backend.writes)
    plain_rendered = strip_ansi(rendered)
    live_lines = [strip_ansi(line) for line in frontend.adapter.chatwidget.render_lines(80)]

    assert f"› {DEFAULT_STARTER_PLACEHOLDER}" in plain_rendered
    assert "Tip: Ralphception starts with Socratic intake" in plain_rendered
    assert "? for shortcuts" in plain_rendered
    assert "100% context left" in plain_rendered
    assert "gpt-5.4 xhigh fast · 100% left · " not in plain_rendered
    assert "Ralphception" in plain_rendered
    assert "to change" in plain_rendered
    assert frontend.tui.terminal.viewport_area.y == 0
    assert "\x1b[48;2;30;30;30m" in rendered
    assert re.search(r"\x1b\[[0-9;]*m", rendered)
    assert any("Ralphception" in line for line in live_lines)
    assert any("Tip: Ralphception starts with Socratic intake" in line for line in live_lines)
    assert frontend.adapter.chatwidget.header_builder is not None
    assert frontend.adapter.chatwidget.notice_lines != ()
    assert frontend.output_text() == ""


def test_frontend_redraws_when_terminal_resizes_during_input_idle(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )
    redraws: list[str] = []
    backend = frontend.tui.terminal.backend  # type: ignore[union-attr]
    assert isinstance(backend, _FakeBackend)
    backend.screen_size = Size(width=120, height=40)

    original_redraw = frontend._redraw

    def recording_redraw() -> None:
        redraws.append("redraw")
        original_redraw()

    monkeypatch.setattr(frontend, "_redraw", recording_redraw)

    frontend._redraw_if_terminal_resized()

    assert redraws == ["redraw"]
    assert frontend.tui.terminal.last_known_screen_size == Size(width=120, height=40)  # type: ignore[union-attr]


def test_flush_and_redraw_drops_internal_skill_meta_lines_from_history(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        AssistantHistoryCell("• Using ralph-execute-task because this is a repo-local loop execution.")
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "Using ralph-execute-task" not in rendered


def test_flush_and_redraw_drops_wrapped_internal_skill_meta_blocks_from_history(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        AssistantHistoryCell(
            "• Using ralph-execute-task because this is a repo-local loop execution with implementation and verification/handoff output."
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "Using ralph-execute-task" not in rendered
    assert "verification/handoff output." not in rendered


def test_flush_and_redraw_drops_internal_skill_announcement_commands(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        CommandHistoryCell(
            command="printf 'Using skill: ralph-execute-task — repo-local execution and verification for the request.\\n'"
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "Using skill: ralph-execute-task" not in rendered
    assert "Ran printf" not in rendered


def test_idle_dashboard_activates_root_watchdog_before_returning_to_idle(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["hello"],
        tui=_fake_tui(),
    )
    state = {"run_calls": 0, "watchdog_calls": 0}

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        assert user_text == "hello"

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self, frontend
        state["run_calls"] += 1
        return headless_module.HeadlessRunResult(
            mode="dashboard",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    def fake_current_pending_prompt(self: RuntimeSupervisor):
        del self
        return None

    def fake_activate_root_watchdog(self: RuntimeSupervisor, *, frontend=None, trigger_reason: str = "idle"):
        del self
        assert frontend is not None
        assert trigger_reason == "idle"
        state["watchdog_calls"] += 1
        frontend.emit_event(FrontendEvent(message="Watchdog activated: continue_root_turn"))
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)
    monkeypatch.setattr(RuntimeSupervisor, "current_pending_prompt", fake_current_pending_prompt)
    monkeypatch.setattr(RuntimeSupervisor, "activate_root_watchdog", fake_activate_root_watchdog)

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert state["run_calls"] == 1
    assert state["watchdog_calls"] == 1


def test_dashboard_result_passes_next_steps_trigger_reason_to_root_watchdog(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["hello"],
        tui=_fake_tui(),
    )

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        assert user_text == "hello"

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self, frontend
        return headless_module.HeadlessRunResult(
            mode="dashboard",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
            watchdog_trigger_reason="next_steps",
        )

    def fake_current_pending_prompt(self: RuntimeSupervisor):
        del self
        return None

    def fake_activate_root_watchdog(self: RuntimeSupervisor, *, frontend=None, trigger_reason: str = "idle"):
        del self, frontend
        assert trigger_reason == "next_steps"
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)
    monkeypatch.setattr(RuntimeSupervisor, "current_pending_prompt", fake_current_pending_prompt)
    monkeypatch.setattr(RuntimeSupervisor, "activate_root_watchdog", fake_activate_root_watchdog)

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"


def test_flush_and_redraw_drops_internal_skill_bootstrap_file_reads(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        CommandHistoryCell(
            command=(
                "pwd && ls && printf '\\n--- SKILL ---\\n' && "
                "cat /private/var/folders/abc123/T/.tmp-skill-home/skills/ralph-execute-task/SKILL.md"
            )
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "SKILL" not in rendered
    assert "Ran pwd" not in rendered


def test_flush_and_redraw_drops_internal_execution_instruction_progress(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        AssistantHistoryCell(
            "• Progress: inspected the repository root and loaded the execution instructions. Next step is a focused pass on README.md."
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "execution instructions" not in rendered
    assert "focused pass on README.md" not in rendered


def test_flush_and_redraw_drops_task_specific_execution_instruction_progress(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        AssistantHistoryCell("• Inspecting the README and the task-specific execution instructions now.")
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "task-specific execution instructions" not in rendered


def test_flush_and_redraw_drops_internal_ralphception_handoff_file_reads(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        CommandHistoryCell(
            command="sed -n '1,220p' /private/var/folders/s0/qb7vdhwx4495l9p03x2dv5n40000gn/T/ralphception-codex-handoff-123.md"
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "ralphception-codex-handoff" not in rendered
    assert "Ran sed -n" not in rendered


def test_flush_and_redraw_drops_internal_temp_instruction_file_reads(tmp_path: Path) -> None:
    repo_root = _make_git_repo(tmp_path)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
    )

    frontend.adapter._pending_history_cells.append(
        CommandHistoryCell(
            command="pwd && echo '---' && sed -n '1,220p' /private/var/folders/abc123/T/tmp-instructions.md"
        )
    )
    frontend._flush_and_redraw()

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert "tmp-instructions.md" not in rendered
    assert "Ran sed -n" not in rendered


def test_run_codex_tui_shell_shows_trust_prompt_and_persists_decision_for_fresh_repo(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=[
            "1",
            "look at and fix typos in the readme",
            "README only",
            "spelling only, and completion means the README typo pass is clean",
        ],
        tui=_fake_tui(),
        draw_initial_shell=False,
        enable_trust_onboarding=True,
    )

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert load_project_trust(repo_root, xdg_state_home=state_home) == "trusted"
    rendered = "".join(frontend.tui.terminal.backend.writes)  # type: ignore[union-attr]
    assert "Do you trust the contents of this directory?" in rendered
    assert "Press enter to continue" in rendered
    assert "Tip: Ralphception starts with Socratic intake" in rendered


def test_maybe_run_trust_onboarding_flushes_startup_shell_into_history_after_trust(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["1"],
        tui=_fake_tui(),
        draw_initial_shell=False,
        enable_trust_onboarding=True,
    )

    trusted = maybe_run_trust_onboarding(repo_root=repo_root, frontend=frontend)

    assert trusted is True
    assert load_project_trust(repo_root, xdg_state_home=state_home) == "trusted"
    assert frontend.tui is not None
    rendered = "".join(frontend.tui.terminal.backend.writes)  # type: ignore[union-attr]
    assert "Do you trust the contents of this directory?" in rendered
    assert "Tip: Ralphception starts with Socratic intake" in rendered
    assert frontend.tui.terminal.viewport_area.y > 0
    assert frontend.tui.terminal.visible_history_rows > 0
    assert frontend.adapter.chatwidget.header_builder is None
    assert frontend.adapter.chatwidget.notice_lines == ()


def test_maybe_run_trust_onboarding_drains_pending_input_before_idle_shell(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = _DrainTrackingFrontend(repo_root=repo_root)

    trusted = maybe_run_trust_onboarding(repo_root=repo_root, frontend=frontend)

    assert trusted is True
    assert frontend.drained_input == 1


def test_maybe_run_trust_onboarding_renders_loading_shell_before_final_idle_shell(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["1"],
        tui=_fake_tui(),
        draw_initial_shell=False,
        enable_trust_onboarding=True,
    )

    trusted = maybe_run_trust_onboarding(repo_root=repo_root, frontend=frontend)

    assert trusted is True
    assert frontend.tui is not None
    backend = frontend.tui.terminal.backend
    assert isinstance(backend, _FakeBackend)
    rendered = "".join(backend.writes)
    plain_rendered = strip_ansi(rendered)
    assert "model:     loading   /model to change" in plain_rendered
    assert "Ralphception" in plain_rendered
    assert "Tip: Ralphception starts with Socratic intake" in plain_rendered


def test_render_idle_shell_inserts_loading_shell_into_history_before_final_shell(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        tui=_fake_tui(),
        draw_initial_shell=False,
        enable_trust_onboarding=True,
    )
    inserted: list[str] = []
    original_insert = Tui.insert_history_lines

    def capture_insert(self: Tui, lines: list[str]) -> None:
        inserted.extend(lines)
        original_insert(self, lines)

    monkeypatch.setattr(Tui, "insert_history_lines", capture_insert)

    frontend.render_idle_shell(include_loading_transition=True)

    plain_inserted = [strip_ansi(line) for line in inserted]

    assert any("model:     loading   /model to change" in line for line in plain_inserted)
    assert any("model:     gpt-5.4 xhigh   fast   /model to change" in line for line in plain_inserted)


def test_run_codex_tui_shell_can_quit_from_trust_prompt(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=["2"],
        tui=_fake_tui(),
        draw_initial_shell=False,
        enable_trust_onboarding=True,
    )

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "running"
    assert load_project_trust(repo_root, xdg_state_home=state_home) is None
    rendered = "".join(frontend.tui.terminal.backend.writes)  # type: ignore[union-attr]
    assert "Do you trust the contents of this directory?" in rendered
    assert "No, quit" in rendered


def test_run_codex_tui_shell_treats_first_prompt_as_fresh_launch_even_with_stale_state(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    write_interactive_session_marker(
        repo_root,
        InteractiveSessionMarker(
            root_run_id="run-root",
            active_run_id="run-root",
            resumable=True,
            updated_at=datetime.now(timezone.utc),
        ),
    )
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=[
            "find typos",
            "README only",
            "spelling only, and completion means the README typo pass is clean",
        ],
        tui=_fake_tui(),
    )

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = frontend.output_text()

    assert result.mode == "completed"
    assert "Resumed run-root" not in output
    assert "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?" in output
    assert "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?" in output


def test_run_codex_tui_shell_restores_passive_status_line_after_first_answer(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=[
            "find and fix all the typos",
            "README only",
            "spelling only, and completion means the README typo pass is clean",
        ],
        tui=_fake_tui(),
    )

    result = run_codex_tui_shell(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    rendered = strip_ansi("".join(frontend.tui.terminal.backend.writes))  # type: ignore[union-attr]

    assert result.mode == "completed"
    assert "• Working (" in rendered
    assert "run-child-1" in rendered
    assert "  gpt-5.4 xhigh fast · 100% left · " in rendered


def test_run_codex_tui_shell_can_start_another_task_after_completion(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    repo_root = _make_git_repo(tmp_path)
    state_home = tmp_path / "state"
    monkeypatch.setenv("XDG_STATE_HOME", str(state_home))
    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)
    frontend = ScriptedCodexTuiFrontend(
        repo_root=repo_root,
        inputs=[
            "first task",
            "second task",
        ],
        tui=_fake_tui(),
    )
    resolved_prompts: list[str] = []

    def fake_request_start_fresh_launch(self: RuntimeSupervisor, *, source_repos=()) -> None:
        del self, source_repos

    def fake_resolve_startup_input(
        self: RuntimeSupervisor,
        *,
        user_text: str,
        source_repos=(),
    ) -> None:
        del self, source_repos
        resolved_prompts.append(user_text)

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        del self, frontend
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_start_fresh_launch", fake_request_start_fresh_launch)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_startup_input", fake_resolve_startup_input)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)
    try:
        result = run_codex_tui_shell(
            repo_root=repo_root,
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
            keep_alive=True,
        )
    finally:
        monkeypatch.undo()

    output = frontend.output_text()

    assert result.mode == "completed"
    assert resolved_prompts == ["first task", "second task"]
    assert output.count("Runtime: completed") == 2


def test_run_app_uses_codex_tui_human_path(monkeypatch, tmp_path: Path) -> None:
    observed: dict[str, object] = {}

    def fake_run_codex_tui_shell(**kwargs: object):
        observed.update(kwargs)
        return None

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("ralphception.app.run_codex_tui_shell", fake_run_codex_tui_shell)

    run_app()

    assert observed["repo_root"] == tmp_path


def test_run_exec_remains_non_interactive(monkeypatch, tmp_path: Path) -> None:
    observed: dict[str, object] = {}

    def fake_run_headless_mission(**kwargs: object):
        observed.update(kwargs)
        return "headless-result"

    monkeypatch.setattr("ralphception.app.run_headless_mission", fake_run_headless_mission)

    result = run_exec(repo_root=tmp_path, prompt="find typos")

    assert result == "headless-result"
    assert observed["repo_root"] == tmp_path
    assert observed["seed_prompt"] == "find typos"
