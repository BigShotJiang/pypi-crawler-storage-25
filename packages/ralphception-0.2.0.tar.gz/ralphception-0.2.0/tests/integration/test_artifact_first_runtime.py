from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from ralphception.actor_runtime.planner_actor import PlannerActor
from ralphception.runtime.artifact_pipeline import ArtifactPipeline
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.interactive_session import load_interactive_session_state
from ralphception.runtime.loop_graph import LoopGraph
from ralphception.runtime.loop_planner import LoopDefinition, LoopPlanner, PlanGraph, PlanNode
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.storage.bootstrap import bootstrap_workspace


@dataclass(frozen=True, slots=True)
class ActiveTaskMessageFlow:
    classifications: list[str]
    log_text: str


class _RecordingFrontend:
    def __init__(self) -> None:
        self.lines: list[str] = []

    def emit_event(self, event) -> None:
        self.lines.append(event.message)

    def emit_status(self, step) -> None:
        self.lines.append(f"Runtime: {step.kind}")

    def finish(self, step) -> None:
        self.lines.append(f"Finished: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self.lines)


def test_post_intake_message_can_extend_current_task_without_opening_new_task(
    tmp_path: Path,
) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "also check comments"])

    assert result.classifications[-1] == "in_task_follow_up"
    assert "Session conflict" not in result.log_text


def test_ambiguous_post_intake_message_requests_clarification(tmp_path: Path) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "do the other thing too"])

    assert result.classifications[-1] == "needs_clarification"
    assert "Need clarification" in result.log_text


def test_post_intake_message_can_revise_current_task_without_starting_new_task(
    tmp_path: Path,
) -> None:
    result = drive_active_task_messages(tmp_path, ["fix typos", "docs only", "change scope to README only"])

    assert result.classifications[-1] == "task_revision"
    assert "Session conflict" not in result.log_text


def test_post_intake_message_can_start_new_task_when_intent_is_explicit(
    tmp_path: Path,
) -> None:
    repo_root = _prepare_active_session(tmp_path)
    frontend = _RecordingFrontend()

    outcome = RuntimeSupervisor(
        repo_root=repo_root,
        seed_prompt="stop this and audit CI instead",
    ).run(frontend=frontend)

    state = load_interactive_session_state(repo_root)

    assert outcome.mode == "startup"
    assert state.task_message_classifications[-1].kind == "new_task_request"
    assert "Session conflict" in frontend.output_text()


def test_broad_plan_node_can_spawn_durable_subplan_and_child_loops(tmp_path: Path) -> None:
    repo_root = _prepare_active_session(tmp_path)
    _ = repo_root
    plan = PlanGraph(
        task_id="task-1",
        plan_id="plan-1",
        nodes=(
            PlanNode(
                plan_node_id="docs-quality",
                title="Docs quality",
                objective="Inspect docs broadly before execution",
                target_artifacts=("prd", "todo"),
                stop_conditions=("docs quality scope is understood",),
                output_contract=("publish docs quality loop proposals",),
            ),
        ),
        root_plan_node_id="docs-quality",
    )

    expansion = LoopPlanner().expand_plan_node_into_subplan(plan, "docs-quality")
    graph = LoopGraph.from_nested_definitions(expansion.child_loops, loop_graph_id="loop-graph-1")

    assert expansion.subplan.plan_node_id == "docs-quality"
    assert len(expansion.child_loops) >= 2
    assert graph.children_for("loop-docs-quality")


def test_planner_actor_builds_an_explicit_loop_graph_from_the_plan_contract(
    tmp_path: Path,
) -> None:
    repo_root = _prepare_active_session(tmp_path)
    plans_dir = repo_root / ".ralphception" / "plans"
    specs_dir = repo_root / ".ralphception" / "specs"
    plans_dir.mkdir(parents=True, exist_ok=True)
    specs_dir.mkdir(parents=True, exist_ok=True)

    approved_spec_path = specs_dir / "mission-spec.md"
    approved_spec_path.write_text("# Approved Spec\n", encoding="utf-8")
    (plans_dir / "mission-plan.md").write_text("# Mission Plan\n", encoding="utf-8")
    (plans_dir / "mission-plan.json").write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['python -c "print(\'verification\')"'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    }
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 1,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    loop_graph = PlannerActor(repo_root=repo_root).build_loop_graph_from_plan_contract(
        approved_spec_path=approved_spec_path,
    )

    assert loop_graph.loop_graph_id == "loop-graph-mission-plan"
    assert [loop.plan_node_id for loop in loop_graph.loops] == ["todo-1"]
    assert loop_graph.loops[0].objective == "Implement parser artifact"
    assert loop_graph.loops[0].target_artifacts == ("src/parser.py",)


def test_child_loop_failure_marks_only_owning_plan_node_blocked(tmp_path: Path) -> None:
    repo_root = _prepare_active_session(tmp_path)
    pipeline = ArtifactPipeline(repo_root)
    graph = LoopGraph.from_nested_definitions(
        [
            LoopDefinition(
                loop_id="loop-root",
                task_id="task-1",
                plan_node_id="root",
                parent_loop_id=None,
                objective="Explore root",
                stop_conditions=("root settled",),
                output_contract=("root proposal",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
            LoopDefinition(
                loop_id="loop-child-a",
                task_id="task-1",
                plan_node_id="child-a",
                parent_loop_id="loop-root",
                objective="Explore child a",
                stop_conditions=("child a settled",),
                output_contract=("child a proposal",),
                target_artifacts=("todo",),
                merge_strategy="direct_update",
            ),
            LoopDefinition(
                loop_id="loop-child-b",
                task_id="task-1",
                plan_node_id="child-b",
                parent_loop_id="loop-root",
                objective="Explore child b",
                stop_conditions=("child b settled",),
                output_contract=("child b proposal",),
                target_artifacts=("todo",),
                merge_strategy="direct_update",
            ),
        ],
        loop_graph_id="loop-graph-1",
    )

    summary = pipeline.record_loop_failure(
        loop_graph=graph,
        loop_id="loop-child-a",
        reason="verification_failed",
    )
    payload = json.loads((repo_root / ".ralphception" / "artifacts" / "failures.json").read_text(encoding="utf-8"))

    assert summary.blocked_plan_node_ids == ("child-a",)
    assert summary.loop_id == "loop-child-a"
    assert payload["failures"][0]["blocked_plan_node_ids"] == ["child-a"]


def drive_active_task_messages(tmp_path: Path, messages: list[str]) -> ActiveTaskMessageFlow:
    repo_root = _prepare_active_session(tmp_path)
    frontend = _RecordingFrontend()
    supervisor = RuntimeSupervisor(repo_root=repo_root)
    classifications: list[str] = []

    for message in messages[1:]:
        result = supervisor.route_active_session_message(user_text=message, frontend=frontend)
        classifications.append(result.kind)

    return ActiveTaskMessageFlow(classifications=classifications, log_text=frontend.output_text())


def _prepare_active_session(tmp_path: Path) -> Path:
    repo_root = bootstrap_workspace(tmp_path / "repo")
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="fix typos",
        source_repos=[],
    )
    return repo_root
