import shutil
import subprocess
import json
from datetime import datetime, timezone
from pathlib import Path
import stat

import pytest
import ralphception.git.worktrees as worktrees_module

from ralphception.git.worktrees import (
    CleanupFailed,
    CheckoutRootInvalid,
    IntegrationRootUnavailable,
    WorktreeCoordinator,
    WorktreeMappingUnavailable,
    WorktreeCreateFailed,
    read_worktree_assignment,
)
from ralphception.storage.lease import read_workspace_lease, write_workspace_lease


def test_create_child_worktree_returns_branch_and_path(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    assert created.branch_name == "codex/run-child-1"
    assert created.worktree_path == repo_root / ".worktrees" / "run-child-1"
    assert created.worktree_path.exists()
    assert git_output(created.worktree_path, "rev-parse", "--abbrev-ref", "HEAD") == created.branch_name
    assert git_output(created.worktree_path, "rev-parse", "HEAD") == git_output(repo_root, "rev-parse", "HEAD")

    persisted = read_worktree_assignment(repo_root, "run-child-1")
    assert persisted.run_id == "run-child-1"
    assert persisted.kind == "child"
    assert persisted.base_ref == "main"
    assert persisted.branch_name == "codex/run-child-1"
    assert persisted.goal == "Implement parser"
    assert persisted.cleanup_state == "pending"
    assert persisted.worktree_path == created.worktree_path


def test_create_child_worktree_preserves_explicit_codex_branch_prefix(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="codex/custom-parser-branch",
        goal="Implement parser",
    )

    assert created.branch_name == "codex/custom-parser-branch"
    persisted = read_worktree_assignment(repo_root, "run-child-1")
    assert persisted.branch_name == "codex/custom-parser-branch"


def test_map_run_to_worktree_returns_persisted_mapping_and_authoritative_state(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    mapping = coordinator.map_run_to_worktree("run-child-1")

    assert mapping.worktree_path == created.worktree_path
    assert mapping.branch_name == "codex/run-child-1"
    assert mapping.authoritative is False


def test_create_integration_worktree_is_detached_and_persists_base_ref(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    created = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")

    assert created.worktree_path == repo_root / ".worktrees" / "run-root-integration"
    assert created.base_ref == "main"
    assert git_output(created.worktree_path, "rev-parse", "--abbrev-ref", "HEAD") == "HEAD"
    assert git_output(created.worktree_path, "rev-parse", "HEAD") == git_output(repo_root, "rev-parse", "main")

    persisted = read_worktree_assignment(repo_root, "run-root")
    assert persisted.kind == "integration"
    assert persisted.branch_name is None
    assert persisted.base_ref == "main"
    assert persisted.cleanup_state == "pending"


def test_create_child_worktree_reuses_shared_git_crypt_state_for_checkout(tmp_path: Path) -> None:
    repo_root = make_git_repo_with_gitdir_local_filter(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    worktree_git_dir = Path(git_output(created.worktree_path, "rev-parse", "--git-dir"))
    if not worktree_git_dir.is_absolute():
        worktree_git_dir = created.worktree_path / worktree_git_dir

    assert (created.worktree_path / "home-manager" / "lib" / "shellAliases.enc.nix").read_text(
        encoding="utf-8",
    ) == "secret\n"
    assert (worktree_git_dir / "git-crypt").is_symlink()


def test_create_integration_worktree_reuses_shared_git_crypt_state_for_checkout(tmp_path: Path) -> None:
    repo_root = make_git_repo_with_gitdir_local_filter(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    created = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")

    worktree_git_dir = Path(git_output(created.worktree_path, "rev-parse", "--git-dir"))
    if not worktree_git_dir.is_absolute():
        worktree_git_dir = created.worktree_path / worktree_git_dir

    assert (created.worktree_path / "home-manager" / "lib" / "shellAliases.enc.nix").read_text(
        encoding="utf-8",
    ) == "secret\n"
    assert (worktree_git_dir / "git-crypt").is_symlink()


def test_switch_authoritative_root_updates_lease_and_mapping(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")

    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )

    authoritative_root = coordinator.switch_authoritative_root(
        run_id="run-root",
        new_root=integration.worktree_path,
    )

    assert authoritative_root == integration.worktree_path

    persisted = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert persisted is not None
    assert persisted.authoritative_repository_root == integration.worktree_path
    assert persisted.process_id == 4242

    mapping = coordinator.map_run_to_worktree("run-root")
    assert mapping.worktree_path == integration.worktree_path
    assert mapping.branch_name is None
    assert mapping.authoritative is True


def test_cleanup_worktree_retains_when_requested(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
        retain=True,
    )

    assert cleanup_state == "retained"
    assert created.worktree_path.exists()
    assert branch_exists(repo_root, created.branch_name)

    persisted = read_worktree_assignment(repo_root, "run-child-1")
    assert persisted.cleanup_state == "retained"


def test_cleanup_worktree_removes_child_branch_by_default(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert not created.worktree_path.exists()
    assert not branch_exists(repo_root, created.branch_name)

    persisted = read_worktree_assignment(repo_root, "run-child-1")
    assert persisted.cleanup_state == "cleaned"


def test_cleanup_worktree_rejects_mismatched_path(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-child-1",
            worktree_path=repo_root / ".worktrees" / "some-other-run",
        )

    assert exc_info.value.code == "cleanup_failed"
    assert created.worktree_path.exists()


def test_cleanup_worktree_rejects_authoritative_worktree(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=integration.worktree_path,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-root",
            worktree_path=integration.worktree_path,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert integration.worktree_path.exists()
    assert worktree_registered(repo_root, integration.worktree_path)
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == integration.worktree_path
    assert read_worktree_assignment(repo_root, "run-root").cleanup_state == "pending"


def test_cleanup_worktree_allows_retaining_authoritative_worktree(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=integration.worktree_path,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-root",
        worktree_path=integration.worktree_path,
        retain=True,
    )

    assert cleanup_state == "retained"
    assert integration.worktree_path.exists()
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == integration.worktree_path
    assert read_worktree_assignment(repo_root, "run-root").cleanup_state == "retained"


def test_cleanup_worktree_rejects_retaining_unavailable_worktree(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    shutil.rmtree(created.worktree_path)

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-child-1",
            worktree_path=created.worktree_path,
            retain=True,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert read_worktree_assignment(repo_root, "run-child-1").cleanup_state == "pending"


def test_cleanup_worktree_rejects_retaining_reinitialized_repo_in_managed_slot(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    (integration.worktree_path / ".git").unlink()
    run_git(integration.worktree_path, "init", "-b", "main")

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-root",
            worktree_path=integration.worktree_path,
            retain=True,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert read_worktree_assignment(repo_root, "run-root").cleanup_state == "pending"


def test_create_child_worktree_rolls_back_git_state_when_persistence_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    worktree_path = repo_root / ".worktrees" / "run-child-1"

    def fail_write_json_atomic(*args: object, **kwargs: object) -> Path:
        raise OSError("disk full")

    monkeypatch.setattr(worktrees_module, "write_json_atomic", fail_write_json_atomic)

    with pytest.raises(WorktreeCreateFailed) as exc_info:
        coordinator.create_child_worktree(
            run_id="run-child-1",
            base_ref="main",
            target_branch="run-child-1",
            goal="Implement parser",
        )

    assert exc_info.value.code == "worktree_create_failed"
    assert not worktree_path.exists()
    assert not worktree_registered(repo_root, worktree_path)
    assert not branch_exists(repo_root, "codex/run-child-1")


def test_create_integration_worktree_rolls_back_git_state_when_persistence_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    worktree_path = repo_root / ".worktrees" / "run-root-integration"

    def fail_write_json_atomic(*args: object, **kwargs: object) -> Path:
        raise OSError("disk full")

    monkeypatch.setattr(worktrees_module, "write_json_atomic", fail_write_json_atomic)

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.create_integration_worktree(run_id="run-root", target_branch="main")

    assert exc_info.value.code == "integration_root_unavailable"
    assert not worktree_path.exists()
    assert not worktree_registered(repo_root, worktree_path)


def test_cleanup_worktree_succeeds_when_directory_already_missing(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    shutil.rmtree(created.worktree_path)

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert not created.worktree_path.exists()
    assert not worktree_registered(repo_root, created.worktree_path)
    assert not branch_exists(repo_root, created.branch_name)


def test_cleanup_worktree_succeeds_when_git_metadata_is_missing_but_directory_remains(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    (created.worktree_path / ".git").unlink()

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert not created.worktree_path.exists()
    assert not worktree_registered(repo_root, created.worktree_path)
    assert not branch_exists(repo_root, created.branch_name)


def test_switch_authoritative_root_rejects_invalid_root_cleanly(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=tmp_path / "outside-root",
        )

    assert exc_info.value.code == "integration_root_unavailable"
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == repo_root


def test_cleanup_worktree_raises_cleanup_failed_for_corrupt_assignment(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    assignment_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload.pop("cleanup_state")
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-child-1",
            worktree_path=created.worktree_path,
        )

    assert exc_info.value.code == "cleanup_failed"


def test_cleanup_worktree_rejects_tampered_external_worktree_path(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    external_path = tmp_path / "external-dir"
    external_path.mkdir()
    assignment_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["worktree_path"] = str(external_path)
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-child-1",
            worktree_path=external_path,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert external_path.exists()
    assert created.worktree_path.exists()


def test_external_symlink_alias_to_managed_slot_is_rejected_everywhere(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    alias_path = tmp_path / "integration-alias"
    alias_path.symlink_to(integration.worktree_path, target_is_directory=True)
    assignment_path = repo_root / ".ralphception" / "runs" / "run-root" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["worktree_path"] = str(alias_path)
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(WorktreeMappingUnavailable) as mapping_exc:
        coordinator.map_run_to_worktree("run-root")

    assert mapping_exc.value.code == "worktree_mapping_unavailable"

    with pytest.raises(CleanupFailed) as cleanup_exc:
        coordinator.cleanup_worktree(
            run_id="run-root",
            worktree_path=alias_path,
            retain=True,
        )

    assert cleanup_exc.value.code == "cleanup_failed"

    with pytest.raises(IntegrationRootUnavailable) as authority_exc:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=alias_path,
        )

    assert authority_exc.value.code == "integration_root_unavailable"
    assert alias_path.exists()
    assert integration.worktree_path.exists()


def test_switch_authoritative_root_rejects_untampered_external_alias_input(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    alias_path = tmp_path / "integration-alias-untampered"
    alias_path.symlink_to(integration.worktree_path, target_is_directory=True)

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=alias_path,
        )

    assert exc_info.value.code == "integration_root_unavailable"


def test_assignment_tampered_to_another_managed_slot_cannot_map_or_cleanup_other_run(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    run_a = coordinator.create_child_worktree(
        run_id="run-a",
        base_ref="main",
        target_branch="run-a",
        goal="Implement parser A",
    )
    run_b = coordinator.create_child_worktree(
        run_id="run-b",
        base_ref="main",
        target_branch="run-b",
        goal="Implement parser B",
    )
    assignment_path = repo_root / ".ralphception" / "runs" / "run-a" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["worktree_path"] = str(run_b.worktree_path)
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(WorktreeMappingUnavailable) as mapping_exc:
        coordinator.map_run_to_worktree("run-a")

    assert mapping_exc.value.code == "worktree_mapping_unavailable"

    with pytest.raises(CleanupFailed) as cleanup_exc:
        coordinator.cleanup_worktree(
            run_id="run-a",
            worktree_path=run_b.worktree_path,
        )

    assert cleanup_exc.value.code == "cleanup_failed"
    assert run_a.worktree_path.exists()
    assert run_b.worktree_path.exists()


def test_cleanup_worktree_rejects_tampered_run_id_path_traversal(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    assignment_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["run_id"] = "../../outside-dir"
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")
    outside_path = tmp_path / "outside-dir" / "worktree.json"

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-child-1",
            worktree_path=created.worktree_path,
            retain=True,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert not outside_path.exists()


def test_cleanup_worktree_ignores_tampered_branch_name_and_uses_actual_child_branch(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    release_branch = "release"
    run_git(repo_root, "branch", release_branch)
    assignment_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["branch_name"] = release_branch
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert branch_exists(repo_root, release_branch)
    assert not branch_exists(repo_root, created.branch_name)


def test_cleanup_worktree_uses_stored_branch_name_when_missing_slot_is_pruned(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    shutil.rmtree(created.worktree_path)
    run_git(repo_root, "worktree", "prune", "--expire", "now")

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert not branch_exists(repo_root, created.branch_name)


def test_cleanup_worktree_does_not_delete_tampered_branch_when_missing_slot_is_pruned(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    created = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    release_branch = "release"
    run_git(repo_root, "branch", release_branch)
    assignment_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["branch_name"] = release_branch
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    shutil.rmtree(created.worktree_path)
    run_git(repo_root, "worktree", "prune", "--expire", "now")

    cleanup_state = coordinator.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )

    assert cleanup_state == "cleaned"
    assert branch_exists(repo_root, release_branch)
    assert not branch_exists(repo_root, created.branch_name)


def test_switch_authoritative_root_raises_integration_root_unavailable_for_corrupt_lease(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    lease = read_workspace_lease(
        repo_root,
        xdg_state_home=xdg_state_home,
    )
    assert lease is not None
    lease_path = xdg_state_home / "ralphception" / lease.workspace_path_hash / "lease.json"
    payload = json.loads(lease_path.read_text(encoding="utf-8"))
    payload.pop("authoritative_repository_root")
    lease_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=integration.worktree_path,
        )

    assert exc_info.value.code == "integration_root_unavailable"


def test_cleanup_worktree_rejects_alias_valued_authoritative_root_in_lease(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    lease = read_workspace_lease(
        repo_root,
        xdg_state_home=xdg_state_home,
    )
    assert lease is not None
    alias_path = tmp_path / "integration-lease-alias"
    alias_path.symlink_to(integration.worktree_path, target_is_directory=True)
    lease_path = xdg_state_home / "ralphception" / lease.workspace_path_hash / "lease.json"
    payload = json.loads(lease_path.read_text(encoding="utf-8"))
    payload["authoritative_repository_root"] = str(alias_path)
    lease_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(CleanupFailed) as exc_info:
        coordinator.cleanup_worktree(
            run_id="run-root",
            worktree_path=integration.worktree_path,
        )

    assert exc_info.value.code == "cleanup_failed"
    assert integration.worktree_path.exists()


def test_map_run_to_worktree_raises_worktree_mapping_unavailable_for_corrupt_lease(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    lease = read_workspace_lease(
        repo_root,
        xdg_state_home=xdg_state_home,
    )
    assert lease is not None
    lease_path = xdg_state_home / "ralphception" / lease.workspace_path_hash / "lease.json"
    payload = json.loads(lease_path.read_text(encoding="utf-8"))
    payload.pop("authoritative_repository_root")
    lease_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(WorktreeMappingUnavailable) as exc_info:
        coordinator.map_run_to_worktree("run-child-1")

    assert exc_info.value.code == "worktree_mapping_unavailable"


def test_recreating_coordinator_from_authoritative_integration_root_uses_canonical_workspace_root(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    coordinator.switch_authoritative_root(
        run_id="run-root",
        new_root=integration.worktree_path,
    )

    resumed = WorktreeCoordinator(repo_root=integration.worktree_path, xdg_state_home=xdg_state_home)
    created = resumed.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )

    assert created.worktree_path == repo_root / ".worktrees" / "run-child-1"
    assert not (integration.worktree_path / ".worktrees").exists()
    assert (repo_root / ".ralphception" / "runs" / "run-child-1" / "worktree.json").exists()
    assert not (integration.worktree_path / ".ralphception" / "runs" / "run-child-1" / "worktree.json").exists()

    mapping = resumed.map_run_to_worktree("run-root")
    assert mapping.worktree_path == integration.worktree_path
    assert mapping.authoritative is True

    cleanup_state = resumed.cleanup_worktree(
        run_id="run-child-1",
        worktree_path=created.worktree_path,
    )
    assert cleanup_state == "cleaned"
    assert read_worktree_assignment(integration.worktree_path, "run-child-1").cleanup_state == "cleaned"


def test_recreating_coordinator_from_stale_integration_root_raises_error(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    (integration.worktree_path / ".git").unlink()

    with pytest.raises(CheckoutRootInvalid) as exc_info:
        WorktreeCoordinator(
            repo_root=integration.worktree_path,
            xdg_state_home=tmp_path / "xdg-state",
        )

    assert exc_info.value.code == "checkout_root_invalid"


def test_coordinator_accepts_nested_linked_worktree_paths_under_worktrees_root(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    nested_worktree = repo_root / ".worktrees" / "feat" / "dev-shell"
    nested_worktree.parent.mkdir(parents=True, exist_ok=True)
    run_git(
        repo_root,
        "worktree",
        "add",
        "-b",
        "codex/dev-shell",
        str(nested_worktree),
        "main",
    )

    coordinator = WorktreeCoordinator(
        repo_root=nested_worktree,
        xdg_state_home=tmp_path / "xdg-state",
    )

    assert coordinator.repo_root == repo_root
    assert coordinator.checkout_root == nested_worktree


def test_switch_authoritative_root_rejects_stale_integration_directory_without_git_metadata(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    (integration.worktree_path / ".git").unlink()

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=integration.worktree_path,
        )

    assert exc_info.value.code == "integration_root_unavailable"


def test_switch_authoritative_root_rejects_reinitialized_repo_in_managed_slot(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    (integration.worktree_path / ".git").unlink()
    run_git(integration.worktree_path, "init", "-b", "main")

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=integration.worktree_path,
        )

    assert exc_info.value.code == "integration_root_unavailable"


def test_managed_slot_symlink_to_other_linked_worktree_is_rejected(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    integration = coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    foreign_worktree = tmp_path / "foreign-linked-worktree"
    run_git(
        repo_root,
        "worktree",
        "add",
        "-b",
        "codex/foreign-linked-worktree",
        str(foreign_worktree),
        "main",
    )
    run_git(repo_root, "worktree", "remove", "--force", str(integration.worktree_path))
    integration.worktree_path.symlink_to(foreign_worktree, target_is_directory=True)

    with pytest.raises(CleanupFailed) as cleanup_exc:
        coordinator.cleanup_worktree(
            run_id="run-root",
            worktree_path=integration.worktree_path,
            retain=True,
        )

    assert cleanup_exc.value.code == "cleanup_failed"

    with pytest.raises(IntegrationRootUnavailable) as authority_exc:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=integration.worktree_path,
        )

    assert authority_exc.value.code == "integration_root_unavailable"


def test_switch_authoritative_root_rejects_tampered_assignment_to_external_repo(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    external_repo = tmp_path / "external-repo"
    external_repo.mkdir()
    run_git(external_repo, "init", "-b", "main")
    assignment_path = repo_root / ".ralphception" / "runs" / "run-root" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["worktree_path"] = str(external_repo)
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=external_repo,
        )

    assert exc_info.value.code == "integration_root_unavailable"


def test_switch_authoritative_root_rejects_tampered_assignment_to_unmanaged_linked_worktree(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    coordinator.create_integration_worktree(run_id="run-root", target_branch="main")
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )
    unmanaged_worktree = tmp_path / "unmanaged-linked-worktree"
    run_git(
        repo_root,
        "worktree",
        "add",
        "-b",
        "codex/unmanaged-linked-worktree",
        str(unmanaged_worktree),
        "main",
    )
    assignment_path = repo_root / ".ralphception" / "runs" / "run-root" / "worktree.json"
    payload = json.loads(assignment_path.read_text(encoding="utf-8"))
    payload["worktree_path"] = str(unmanaged_worktree)
    assignment_path.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=unmanaged_worktree,
        )

    assert exc_info.value.code == "integration_root_unavailable"


@pytest.mark.parametrize("invalid_root_kind", ["child", "other"])
def test_switch_authoritative_root_rejects_child_worktrees_and_wrong_in_tree_paths(
    tmp_path: Path,
    invalid_root_kind: str,
) -> None:
    repo_root = make_git_repo(tmp_path)
    xdg_state_home = tmp_path / "xdg-state"
    coordinator = WorktreeCoordinator(repo_root=repo_root, xdg_state_home=xdg_state_home)
    child = coordinator.create_child_worktree(
        run_id="run-child-1",
        base_ref="main",
        target_branch="run-child-1",
        goal="Implement parser",
    )
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=4242,
        authoritative_repository_root=repo_root,
        heartbeat_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        xdg_state_home=xdg_state_home,
    )

    if invalid_root_kind == "child":
        invalid_root = child.worktree_path
    else:
        invalid_root = repo_root / ".worktrees" / "wrong-path"
        invalid_root.mkdir(parents=True)

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.switch_authoritative_root(
            run_id="run-root",
            new_root=invalid_root,
        )

    assert exc_info.value.code == "integration_root_unavailable"
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)
    assert lease is not None
    assert lease.authoritative_repository_root == repo_root


def test_create_child_worktree_raises_worktree_create_failed_for_invalid_target_branch(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    with pytest.raises(WorktreeCreateFailed) as exc_info:
        coordinator.create_child_worktree(
            run_id="run-child-1",
            base_ref="main",
            target_branch="../bad-branch",
            goal="Implement parser",
        )

    assert exc_info.value.code == "worktree_create_failed"


def test_create_child_worktree_raises_worktree_create_failed_for_invalid_run_id(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    with pytest.raises(WorktreeCreateFailed) as exc_info:
        coordinator.create_child_worktree(
            run_id="../bad-run",
            base_ref="main",
            target_branch="run-child-1",
            goal="Implement parser",
        )

    assert exc_info.value.code == "worktree_create_failed"


def test_create_integration_worktree_raises_integration_root_unavailable_for_missing_branch(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.create_integration_worktree(run_id="run-root", target_branch="missing-branch")

    assert exc_info.value.code == "integration_root_unavailable"


def test_create_integration_worktree_raises_integration_root_unavailable_for_invalid_run_id(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = WorktreeCoordinator(
        repo_root=repo_root,
        xdg_state_home=tmp_path / "xdg-state",
    )

    with pytest.raises(IntegrationRootUnavailable) as exc_info:
        coordinator.create_integration_worktree(run_id="../bad-run", target_branch="main")

    assert exc_info.value.code == "integration_root_unavailable"


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "init",
    )
    return repo_root


def make_git_repo_with_gitdir_local_filter(tmp_path: Path) -> Path:
    repo_root = make_git_repo(tmp_path)
    helper = tmp_path / "fake-git-crypt-smudge.py"
    helper.write_text(
        "#!/usr/bin/env python3\n"
        "from __future__ import annotations\n"
        "import subprocess\n"
        "import sys\n"
        "from pathlib import Path\n"
        "\n"
        "git_dir = subprocess.run(\n"
        "    ['git', 'rev-parse', '--git-dir'],\n"
        "    check=True,\n"
        "    capture_output=True,\n"
        "    text=True,\n"
        ").stdout.strip()\n"
        "git_dir_path = Path(git_dir)\n"
        "if not git_dir_path.is_absolute():\n"
        "    git_dir_path = Path.cwd() / git_dir_path\n"
        "if not (git_dir_path / 'git-crypt' / 'keys' / 'unlocked').exists():\n"
        "    sys.stderr.write(\n"
        "        'git-crypt: Error: Unable to open key file - have you unlocked/initialized this repository yet?\\n'\n"
        "    )\n"
        "    raise SystemExit(1)\n"
        "sys.stdout.write(sys.stdin.read())\n",
        encoding="utf-8",
    )
    helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
    (repo_root / ".gitattributes").write_text("*.enc.nix filter=git-crypt\n", encoding="utf-8")
    secret_path = repo_root / "home-manager" / "lib" / "shellAliases.enc.nix"
    secret_path.parent.mkdir(parents=True, exist_ok=True)
    secret_path.write_text("secret\n", encoding="utf-8")
    (repo_root / ".git" / "git-crypt" / "keys").mkdir(parents=True, exist_ok=True)
    (repo_root / ".git" / "git-crypt" / "keys" / "unlocked").write_text("ok\n", encoding="utf-8")
    run_git(repo_root, "config", "filter.git-crypt.smudge", str(helper))
    run_git(repo_root, "config", "filter.git-crypt.clean", "cat")
    run_git(repo_root, "config", "filter.git-crypt.required", "true")
    run_git(repo_root, "add", ".gitattributes", "home-manager/lib/shellAliases.enc.nix")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "add encrypted fixture",
    )
    return repo_root


def git_output(cwd: Path, *args: str) -> str:
    return run_git(cwd, *args).stdout.strip()


def branch_exists(cwd: Path, branch_name: str | None) -> bool:
    if branch_name is None:
        return False
    result = subprocess.run(
        ["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch_name}"],
        check=False,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def worktree_registered(cwd: Path, worktree_path: Path) -> bool:
    output = git_output(cwd, "worktree", "list", "--porcelain")
    needle = f"worktree {worktree_path.resolve(strict=False)}"
    return needle in output


def run_git(cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        check=True,
        cwd=cwd,
        capture_output=True,
        text=True,
    )
