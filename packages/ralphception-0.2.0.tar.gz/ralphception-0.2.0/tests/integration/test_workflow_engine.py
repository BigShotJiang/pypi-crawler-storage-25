import json
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import ExecutionBundleState, Run, Stage
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.checkpoints import read_checkpoint
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.workflow.approvals import (
    create_execution_bundle_approval,
    create_spec_review,
    persist_approval,
)
from ralphception.workflow.bundles import create_bundle
from ralphception.workflow.engine import WorkflowEngine


def test_engine_blocks_plan_generation_until_spec_review_approval(tmp_path: Path) -> None:
    engine = build_engine_without_spec_review_approval(tmp_path)

    assert engine.can_enter_plan_stage() is False
    assert engine.stage("plan").status == "awaiting_approval"


def test_engine_blocks_plan_execution_until_execution_bundle_approval(tmp_path: Path) -> None:
    engine = build_engine_without_execution_approval(tmp_path)

    assert engine.can_enter_execute_stage() is False
    assert engine.stage("execute").status == "awaiting_approval"


def test_engine_records_replacement_lineage_on_replace(tmp_path: Path) -> None:
    engine = build_engine(tmp_path)

    replacement = engine.replace_run("run-child-a")
    replaced = engine.run("run-child-a")

    assert replacement.supersedes_run_id == "run-child-a"
    assert replacement.parent_run_id == replaced.parent_run_id
    assert replacement.config_snapshot == replaced.config_snapshot


def test_engine_uses_latest_consumable_bundle_for_new_children(tmp_path: Path) -> None:
    engine = build_engine_with_bundle_versions(tmp_path, [2, 3])

    child = engine.schedule_child_run(goal="implement parser")

    assert child.bundle_version == 3


def test_engine_preserves_running_plan_stage_when_gate_is_rechecked(tmp_path: Path) -> None:
    engine = build_engine(tmp_path)

    stage_before = engine.stage("plan")
    allowed = engine.can_enter_plan_stage()
    stage_after = engine.stage("plan")

    assert allowed is True
    assert stage_before.status == "running"
    assert stage_after.status == "running"
    assert stage_after.started_at == stage_before.started_at


def test_engine_treats_derived_in_scope_bundles_as_consumable(tmp_path: Path) -> None:
    engine = build_engine_with_bundle_versions(tmp_path, [2, 3], latest_bundle_state="derived_in_scope")

    child = engine.schedule_child_run(goal="implement parser")

    assert child.bundle_version == 3


def test_engine_skips_awaiting_approval_bundles_when_scheduling_children(tmp_path: Path) -> None:
    engine = build_engine_with_bundle_versions(tmp_path, [2, 3], latest_bundle_state="awaiting_approval")

    child = engine.schedule_child_run(goal="implement parser")

    assert child.bundle_version == 2


def test_engine_writes_checkpoint_after_scheduling_child_run(tmp_path: Path) -> None:
    engine = build_engine_with_bundle_versions(tmp_path, [2, 3])

    child = engine.schedule_child_run(goal="implement parser")

    assert engine.last_checkpoint is not None
    checkpoint = read_checkpoint(
        engine.repo_root,
        run_id=engine.root_run.run_id,
        checkpoint_id=engine.last_checkpoint.checkpoint_id,
    )
    assert checkpoint.checkpoint_kind == "child_scheduled"
    assert checkpoint.bundle_version == child.bundle_version


def test_engine_starts_child_session_when_scheduling_child_run(tmp_path: Path) -> None:
    engine = build_engine_with_bundle_versions(tmp_path, [2, 3])

    engine.schedule_child_run(goal="implement parser")
    child_run = engine.run("run-child-1")

    assert child_run.codex_session_ref is not None
    assert child_run.codex_session_ref.run_id == "run-child-1"


def build_engine_without_spec_review_approval(tmp_path: Path) -> WorkflowEngine:
    return build_engine(tmp_path, spec_review_approved=False)


def build_engine_without_execution_approval(tmp_path: Path) -> WorkflowEngine:
    return build_engine(tmp_path, execution_bundle_approved=False)


def build_engine_with_bundle_versions(
    tmp_path: Path,
    bundle_versions: list[int],
    *,
    latest_bundle_state: ExecutionBundleState = "approved",
) -> WorkflowEngine:
    return build_engine(
        tmp_path,
        bundle_versions=bundle_versions,
        latest_bundle_state=latest_bundle_state,
    )


def build_engine(
    tmp_path: Path,
    *,
    spec_review_approved: bool = True,
    execution_bundle_approved: bool = True,
    bundle_versions: list[int] | None = None,
    latest_bundle_state: ExecutionBundleState = "approved",
) -> WorkflowEngine:
    repo_root = bootstrap_workspace(tmp_path)
    spec_ref = write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Task 8 workflow engine coverage.\n",
    )
    plan_ref = write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Runtime Plan\n\n- Coordinate child runs through approved bundles.\n",
    )
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate root workflow")

    root_run = Run(
        run_id="run-root",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Coordinate root workflow",
        status="running",
        stage_ids=["stage-spec-1", "stage-plan-1", "stage-execute-1"],
        config_snapshot={"codex": {"model": "gpt-5.4"}, "execution": {"approval_required": True}},
        codex_session_ref=session_manager.get_session_ref("run-root"),
        artifact_refs=[spec_ref, plan_ref],
        created_at=utc_now(),
        updated_at=utc_now(),
    )
    child_run = Run(
        run_id="run-child-a",
        parent_run_id="run-root",
        supersedes_run_id=None,
        goal="Implement parser",
        status="failed",
        stage_ids=[],
        config_snapshot=root_run.config_snapshot,
        codex_session_ref=None,
        artifact_refs=[plan_ref],
        created_at=utc_now(),
        updated_at=utc_now(),
    )
    stages = [
        Stage(
            stage_id="stage-spec-1",
            run_id="run-root",
            stage_kind="spec",
            status="completed",
            task_ids=[],
            started_at=utc_now(),
            completed_at=utc_now(),
        ),
        Stage(
            stage_id="stage-plan-1",
            run_id="run-root",
            stage_kind="plan",
            status="running" if spec_review_approved else "pending",
            task_ids=[],
            started_at=utc_now() if spec_review_approved else None,
            completed_at=None,
        ),
        Stage(
            stage_id="stage-execute-1",
            run_id="run-root",
            stage_kind="execute",
            status="pending",
            task_ids=[],
            started_at=None,
            completed_at=None,
        ),
    ]

    approvals = []
    if spec_review_approved:
        approvals.append(
            persist_approval(
                repo_root,
                create_spec_review(
                    approval_id="approval-spec-1",
                    run_id="run-root",
                    approver="user",
                    spec_artifacts=[spec_ref],
                    bundle_version=1,
                    scope_hash="sha256:spec-scope",
                    approved_at=utc_now(),
                ),
            ),
        )

    versions = bundle_versions or [1]
    bundles = []
    for index, bundle_version in enumerate(versions, start=1):
        state: ExecutionBundleState = "approved"
        if index == len(versions):
            state = latest_bundle_state
        bundle = create_bundle(
            repo_root,
            bundle_id=f"bundle-{bundle_version}",
            run_id="run-root",
            bundle_version=bundle_version,
            state=state,
            artifact_refs=[spec_ref, plan_ref],
            stage_id="stage-plan-1",
            created_at=utc_now(),
            base_bundle_id=None if state != "derived_in_scope" else f"bundle-{bundle_version - 1}",
        )
        bundles.append(bundle)

    if execution_bundle_approved:
        approved_bundle = next(bundle for bundle in reversed(bundles) if bundle.state == "approved")
        approvals.append(
            persist_approval(
                repo_root,
                create_execution_bundle_approval(
                    approval_id=f"approval-exec-{approved_bundle.bundle_version}",
                    approver="user",
                    bundle=approved_bundle,
                    approved_at=utc_now(),
                ),
            ),
        )

    return WorkflowEngine(
        repo_root=repo_root,
        root_run=root_run,
        stages=stages,
        child_runs=[child_run],
        bundles=bundles,
        approvals=approvals,
        session_manager=session_manager,
        authoritative_root=str(repo_root),
    )


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: object,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(content, str):
        target.write_text(content, encoding="utf-8")
    else:
        target.write_text(json.dumps(content, indent=2) + "\n", encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{artifact_kind}:{target.name}",
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
