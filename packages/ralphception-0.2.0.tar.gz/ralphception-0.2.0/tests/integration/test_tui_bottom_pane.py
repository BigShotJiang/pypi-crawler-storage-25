from __future__ import annotations

import asyncio
from dataclasses import replace
from pathlib import Path
import os

from textual.app import App
from textual.widgets import Static
from textual.widgets import TextArea

from ralphception.tui.bottom_pane.chat_composer import ChatComposer
from ralphception.tui.bottom_pane.bottom_pane_view import BottomPaneWidget, render_bottom_pane
from ralphception.tui.bottom_pane.chat_composer import ChatComposerState, render_chat_composer
from ralphception.tui.bottom_pane.footer import FooterState, render_footer
from ralphception.tui.bottom_pane.pending_input_preview import render_pending_input_preview
from ralphception.tui.bottom_pane.pending_thread_approvals import render_pending_thread_approvals
from ralphception.tui.bottom_pane.slash_commands import (
    SlashCommandMatch,
    SlashCommandState,
    match_slash_commands,
    render_slash_command_popup,
)
from ralphception.tui.render_state import StatusIndicatorState
from ralphception.tui.render_state import (
    AgentPickerViewState,
    BottomPaneState,
    OverlayState,
    RequestUserInputViewState,
)


def test_composer_renders_codex_style_placeholder() -> None:
    fixture_path = Path(__file__).resolve().parents[1] / "golden" / "codex_port" / "composer_footer_idle.txt"
    composer = render_chat_composer(
        ChatComposerState(placeholder="Describe the task or ask a question"),
        width=80,
    )
    footer = render_footer(
        FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
        width=80,
    )
    rendered = f"{composer}\n{footer}\n"
    assert rendered == fixture_path.read_text(encoding="utf-8")
    assert "Describe the task or ask a question" in rendered
    assert "gpt-5.4 high fast" in rendered


def test_chat_composer_widget_renders_placeholder_when_empty() -> None:
    class Harness(App[None]):
        def compose(self):
            yield ChatComposer(
                ChatComposerState(placeholder="Describe the task or ask a question"),
                id="composer-input",
            )

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pilot.app.query_one("#composer-input", ChatComposer)
            return composer.render_line(0).text

    rendered = asyncio.run(exercise())
    assert "Describe the task or ask a question" in rendered


def test_footer_prefers_passive_status_line_when_idle() -> None:
    rendered = render_footer(
        FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            status_line_enabled=True,
        ),
        width=80,
    )

    assert rendered == "gpt-5.4 high fast · ~/code/ralphception"
    assert "? for shortcuts" not in rendered


def test_footer_normalizes_home_relative_directory_label_when_idle() -> None:
    rendered = render_footer(
        FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label=str(Path.home() / "code" / "ralphception"),
            status_line_enabled=True,
        ),
        width=120,
    )

    assert rendered == "gpt-5.4 high fast · ~/code/ralphception"


def test_footer_merges_passive_status_line_with_active_agent_label() -> None:
    rendered = render_footer(
        FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            status_line_enabled=True,
            status_line_value="Status line content",
            active_thread_label="Worker 1 [worker]",
        ),
        width=80,
    )

    assert rendered == "Status line content · Worker 1 [worker]"


def test_footer_truncates_context_to_stay_single_line() -> None:
    width = 80
    rendered = render_footer(
        FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="/private/tmp/ralph-startup-live.y2eiXW",
            is_task_running=True,
        ),
        width=width,
    )

    assert "\n" not in rendered
    assert len(rendered) < width


def test_bottom_pane_footer_uses_live_widget_width_for_running_layout() -> None:
    state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception/.worktrees/codex-startup-shell",
            is_task_running=True,
        ),
        status_indicator=StatusIndicatorState(header="Working", details="Plan turn"),
    )
    pane = BottomPaneWidget(state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test(size=(120, 24)) as pilot:
            await pilot.pause()
            footer = pane.query_one("#footer-status", Static)
            return footer.size.width, str(footer.renderable)

    footer_width, rendered = asyncio.run(exercise())
    expected = render_footer(
        state.footer,
        width=footer_width,
        composer_has_draft=False,
        view_active=False,
        popup_active=False,
        shortcut_overlay_active=False,
    )
    assert rendered == expected


def test_slash_command_popup_renders_matching_commands() -> None:
    rendered = render_slash_command_popup(
        SlashCommandState(
            query="so",
            matches=(
                SlashCommandMatch(command="source", description="add an optional source repository before startup"),
                SlashCommandMatch(command="restart", description="restart the active recovery flow"),
            ),
        ),
        width=40,
    )
    assert "/source" in rendered
    assert "add an optional source" in rendered
    assert "repository before startup" in rendered
    assert "/restart" in rendered


def test_slash_command_popup_includes_model_command() -> None:
    popup = match_slash_commands("/mo")

    assert popup is not None
    assert any(match.command == "model" for match in popup.matches)


def test_slash_command_popup_hides_once_command_arguments_begin() -> None:
    popup = match_slash_commands("/source /tmp/source-a")

    assert popup is None


def test_bottom_pane_preserves_draft_across_overlay_transitions() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.value = "inspect runtime adapter"
            pane.set_state(
                replace(
                    base_state,
                    view_stack=(
                        OverlayState(
                            kind="approval",
                            title="Execution bundle review",
                            summary="Approve or reject the proposed execution bundle.",
                            actions=("approve", "reject"),
                        ),
                    ),
                )
            )
            await pilot.pause()
            pane.set_state(base_state)
            await pilot.pause()
            return pane.query_one("#composer-input", ChatComposer).value

    assert asyncio.run(exercise()) == "inspect runtime adapter"


def test_bottom_pane_mounts_single_approval_overlay_surface_without_duplicate_review_statics() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
        view_stack=(
            OverlayState(
                kind="approval",
                title="Spec review",
                summary="Spec review pending for .ralphception/specs/mission-spec.md",
                actions=("approve",),
            ),
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, int, int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            overlay = pane.query_one("#approval-overlay-view", Static)
            return (
                len(pane.query("#review-title")),
                len(pane.query("#review-summary")),
                len(pane.query("#review-action-approve")),
                str(overlay.renderable),
            )

    review_titles, review_summaries, approve_buttons, overlay_text = asyncio.run(exercise())
    assert review_titles == 0
    assert review_summaries == 0
    assert approve_buttons == 1
    assert "Spec review" in overlay_text
    assert "mission-spec.md" in overlay_text


def test_bottom_pane_keeps_composer_visible_for_popup_views() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
        popup=SlashCommandState(
            query="so",
            matches=(
                SlashCommandMatch(command="source", description="add an optional source repository before startup"),
                SlashCommandMatch(command="restart", description="restart the active recovery flow"),
            ),
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            popup = pane.query_one("#slash-command-popup", Static)
            return len(pane.query("#composer-input")), str(popup.renderable)

    composer_count, popup_text = asyncio.run(exercise())
    assert composer_count == 1
    assert "/source" in popup_text
    assert "add an optional source repository before startup" in popup_text


def test_bottom_pane_shows_slash_popup_for_live_composer_input() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "s", "o")
            await pilot.pause()
            popup = pane.query_one("#slash-command-popup", Static)
            return str(popup.renderable)

    popup_text = asyncio.run(exercise())
    assert "/source" in popup_text
    assert "add an optional source repository before startup" in popup_text


def test_bottom_pane_arrow_keys_move_selected_slash_command() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[str, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/")
            await pilot.pause()
            initial = str(pane.query_one("#slash-command-popup", Static).renderable)
            await pilot.press("down")
            await pilot.pause()
            moved = str(pane.query_one("#slash-command-popup", Static).renderable)
            return initial, moved

    initial, moved = asyncio.run(exercise())
    assert "› /agent" in initial
    assert "› /model" in moved
    assert "› /agent" not in moved


def test_bottom_pane_tab_completes_selected_slash_command() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "down", "tab")
            await pilot.pause()
            return pane.query_one("#composer-input", ChatComposer).text

    assert asyncio.run(exercise()) == "/model "


def test_match_slash_commands_supports_fuzzy_matching_for_supported_commands() -> None:
    from ralphception.tui.bottom_pane.slash_commands import match_slash_commands

    popup = match_slash_commands("/src")

    assert popup is not None
    assert popup.matches[0].command == "source"


def test_match_slash_commands_returns_none_for_unknown_prefix() -> None:
    from ralphception.tui.bottom_pane.slash_commands import match_slash_commands

    assert match_slash_commands("/zzz") is None


def test_match_slash_commands_selects_first_match_by_default() -> None:
    from ralphception.tui.bottom_pane.slash_commands import match_slash_commands

    popup = match_slash_commands("/")

    assert popup is not None
    assert popup.selected_index == 0
    assert popup.matches[0].command == "agent"


def test_bottom_pane_escape_dismisses_slash_popup_and_keeps_draft() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "escape")
            await pilot.pause()
            return len(pane.query("#slash-command-popup")), pane.query_one("#composer-input", ChatComposer).text

    popup_count, composer_text = asyncio.run(exercise())
    assert popup_count == 0
    assert composer_text == "/"


def test_bottom_pane_question_mark_toggles_shortcut_overlay_when_composer_empty() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("?")
            await pilot.pause()
            overlay = pane.query_one("#shortcut-overlay", Static)
            composer_text = pane.query_one("#composer-input", ChatComposer).text
            return (
                len(pane.query("#shortcut-overlay")),
                str(overlay.renderable),
                composer_text,
            )

    overlay_count, overlay_text, composer_text = asyncio.run(exercise())
    assert overlay_count == 1
    assert "/ for commands" in overlay_text
    assert "ctrl + t to view transcript" in overlay_text
    assert composer_text == ""


def test_bottom_pane_question_mark_toggles_shortcut_overlay_off_on_second_press() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("?")
            await pilot.pause()
            await pilot.press("?")
            await pilot.pause()
            return len(pane.query("#shortcut-overlay")), pane.query_one("#composer-input", ChatComposer).text

    overlay_count, composer_text = asyncio.run(exercise())
    assert overlay_count == 0
    assert composer_text == ""


def test_bottom_pane_question_mark_types_normally_when_draft_exists() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("r", "e", "v", "i", "e", "w", "?")
            await pilot.pause()
            return len(pane.query("#shortcut-overlay")), pane.query_one("#composer-input", ChatComposer).text

    overlay_count, composer_text = asyncio.run(exercise())
    assert overlay_count == 0
    assert composer_text == "review?"


def test_pending_input_preview_uses_shift_left_hint_for_apple_terminal(monkeypatch) -> None:
    monkeypatch.setenv("TERM_PROGRAM", "Apple_Terminal")

    rendered = render_pending_input_preview(
        queued_messages=("Queued follow-up",),
        width=48,
    )

    assert "shift+left edit last queued message" in rendered


def test_pending_input_preview_uses_alt_up_hint_by_default(monkeypatch) -> None:
    monkeypatch.delenv("TERM_PROGRAM", raising=False)

    rendered = render_pending_input_preview(
        queued_messages=("Queued follow-up",),
        width=48,
    )

    assert "alt+up edit last queued message" in rendered


def test_bottom_pane_uses_topmost_view_from_stack() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
        view_stack=(
            OverlayState(
                kind="approval",
                title="Execution bundle review",
                summary="Approve or reject the proposed execution bundle.",
                actions=("approve", "reject"),
            ),
            RequestUserInputViewState(
                title="Choose recovery mode",
                question="How should Ralphception proceed?",
                options=("Read", "Repair"),
            ),
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            request_view = pane.query_one("#request-user-input-view", Static)
            return (
                len(pane.query("#composer-input")),
                len(pane.query("#review-title")),
                str(request_view.renderable),
            )

    composer_count, approval_titles, request_text = asyncio.run(exercise())
    assert composer_count == 0
    assert approval_titles == 0
    assert "Choose recovery mode" in request_text
    assert "Repair" in request_text


def test_bottom_pane_can_mount_agent_picker_view() -> None:
    base_footer = FooterState(
        left_hint="? for shortcuts",
        model_name="gpt-5.4",
        reasoning_effort="high",
        latency_label="fast",
        directory_label="~/code/ralphception",
    )

    class Harness(App[None]):
        def __init__(self, state: BottomPaneState) -> None:
            super().__init__()
            self._pane = BottomPaneWidget(state)

        def compose(self):
            yield self._pane

    async def render(state: BottomPaneState, widget_id: str) -> str:
        app = Harness(state)
        async with app.run_test() as pilot:
            await pilot.pause()
            return str(app.query_one(widget_id, Static).renderable)

    agent_text = asyncio.run(
        render(
            BottomPaneState(
                composer=ChatComposerState(placeholder="Describe the task or ask a question"),
                footer=base_footer,
                view_stack=(
                    AgentPickerViewState(
                        title="Agents",
                        active_thread_id="run-child-1",
                        rows=(
                            ("run-root", "Main [default]"),
                            ("run-child-1", "Worker 1 [worker]"),
                        ),
                    ),
                ),
            ),
            "#agent-picker-view",
        )
    )
    assert "Worker 1 [worker]" in agent_text


def test_bottom_pane_uses_text_area_backed_composer() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> bool:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input")
            return isinstance(composer, TextArea)

    assert asyncio.run(exercise()) is True


def test_bottom_pane_prefers_queue_hint_when_task_running_with_draft() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
            value="inspect runtime adapter",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
            status_line_enabled=True,
            quota_label="98% context left",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            return str(pane.query_one("#footer-status", Static).renderable)

    rendered = asyncio.run(exercise())
    assert "tab to queue message" in rendered
    assert "98% context left" in rendered
    assert "Ctrl+C interrupt" not in rendered


def test_bottom_pane_renders_status_indicator_above_composer_while_task_running() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            indicator = pane.query_one("#status-indicator", Static)
            composer = pane.query_one("#composer-input", ChatComposer)
            return (
                len(pane.query("#status-indicator")),
                len(pane.query("#composer-input")),
                "\n".join(str(indicator.renderable).splitlines()[:2]),
            )

    indicator_count, composer_count, rendered = asyncio.run(exercise())
    assert indicator_count == 1
    assert composer_count == 1
    assert "Working" in rendered
    assert "esc to interrupt" in rendered.lower()


def test_bottom_pane_escape_interrupts_running_task_when_no_popup_is_active() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        interrupt_requests = 0

        def compose(self):
            yield pane

        def on_bottom_pane_widget_interrupt_requested(self, message: BottomPaneWidget.InterruptRequested) -> None:
            del message
            self.interrupt_requests += 1

    async def exercise() -> int:
        app = Harness()
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("escape")
            await pilot.pause()
            return app.interrupt_requests

    assert asyncio.run(exercise()) == 1


def test_bottom_pane_escape_does_not_interrupt_running_task_while_agent_slash_popup_is_active() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
            value="/agent",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
        popup=SlashCommandState(
            query="agent",
            matches=(
                SlashCommandMatch(command="agent", description="switch between active threads"),
            ),
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        interrupt_requests = 0

        def compose(self):
            yield pane

        def on_bottom_pane_widget_interrupt_requested(self, message: BottomPaneWidget.InterruptRequested) -> None:
            del message
            self.interrupt_requests += 1

    async def exercise() -> int:
        app = Harness()
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("escape")
            await pilot.pause()
            return app.interrupt_requests

    assert asyncio.run(exercise()) == 0


def test_bottom_pane_shift_left_edits_most_recent_queued_message_for_apple_terminal(monkeypatch) -> None:
    monkeypatch.setenv("TERM_PROGRAM", "Apple_Terminal")
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
        queued_messages=("first queued", "second queued"),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        edit_requests = 0

        def compose(self):
            yield pane

        def on_bottom_pane_widget_edit_last_queued_requested(
            self,
            message: BottomPaneWidget.EditLastQueuedRequested,
        ) -> None:
            del message
            self.edit_requests += 1

    async def exercise() -> int:
        app = Harness()
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("shift+left")
            await pilot.pause()
            return app.edit_requests

    assert asyncio.run(exercise()) == 1


def test_bottom_pane_renders_status_indicator_details_like_codex() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
        status_indicator=StatusIndicatorState(
            header="Working",
            details="git status --short",
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> str:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            indicator = pane.query_one("#status-indicator", Static)
            return str(indicator.renderable)

    rendered = asyncio.run(exercise())
    assert "Working" in rendered
    assert "└ git status --short" in rendered


def test_pending_thread_approvals_renders_codex_style_agent_switch_hint() -> None:
    rendered = render_pending_thread_approvals(
        threads=("Worker 1 [worker]", "Worker 2 [worker]"),
        width=44,
    )

    assert "Approval needed in Worker 1 [worker]" in rendered
    assert "Approval needed in Worker 2 [worker]" in rendered
    assert "/agent to switch threads" in rendered


def test_bottom_pane_renders_pending_thread_approvals_above_composer() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="? for shortcuts",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
        ),
        pending_thread_approvals=("Worker 1 [worker]",),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            approvals = pane.query_one("#pending-thread-approvals", Static)
            return len(pane.query("#pending-thread-approvals")), str(approvals.renderable)

    count, rendered = asyncio.run(exercise())
    assert count == 1
    assert "Approval needed in Worker 1 [worker]" in rendered
    assert "/agent to switch threads" in rendered


def test_render_bottom_pane_inserts_spacer_between_status_and_inline_previews() -> None:
    rendered = render_bottom_pane(
        state=BottomPaneState(
            composer=ChatComposerState(
                placeholder="Describe the task or ask a question",
            ),
            footer=FooterState(
                left_hint="Ctrl+C interrupt",
                model_name="gpt-5.4",
                reasoning_effort="high",
                latency_label="fast",
                directory_label="~/code/ralphception",
                is_task_running=True,
            ),
            status_indicator=StatusIndicatorState(header="Working"),
            pending_thread_approvals=("Worker 1 [worker]",),
        ),
        width=80,
    )

    assert "Working (0s • esc to interrupt)\n\n  ! Approval needed in Worker 1 [worker]" in rendered


def test_render_bottom_pane_inserts_spacer_between_pending_approvals_and_queued_messages() -> None:
    rendered = render_bottom_pane(
        state=BottomPaneState(
            composer=ChatComposerState(
                placeholder="Describe the task or ask a question",
            ),
            footer=FooterState(
                left_hint="? for shortcuts",
                model_name="gpt-5.4",
                reasoning_effort="high",
                latency_label="fast",
                directory_label="~/code/ralphception",
            ),
            pending_thread_approvals=("Worker 1 [worker]",),
            queued_messages=("Follow up on the failing test",),
        ),
        width=80,
    )

    assert "/agent to switch threads\n\n• Queued follow-up messages" in rendered


def test_pending_input_preview_uses_codex_section_header() -> None:
    rendered = render_pending_input_preview(
        queued_messages=("review the runtime adapter",),
        width=40,
    )

    assert rendered == "\n".join(
        (
            "• Queued follow-up messages",
            "  ↳ review the runtime adapter",
            "    alt+up edit last queued message",
        )
    )


def test_pending_input_preview_wraps_and_truncates_long_messages() -> None:
    rendered = render_pending_input_preview(
        queued_messages=("This is a longer queued follow-up message that should wrap and truncate cleanly.",),
        width=28,
    )

    lines = rendered.splitlines()
    assert lines[0] == "• Queued follow-up messages"
    assert lines[1].startswith("  ↳ ")
    assert "…" in rendered
    assert lines[-1] == "    alt+up edit last queued message"


def test_bottom_pane_queues_preview_when_task_running_and_tab_pressed() -> None:
    base_state = BottomPaneState(
        composer=ChatComposerState(
            placeholder="Describe the task or ask a question",
        ),
        footer=FooterState(
            left_hint="Ctrl+C interrupt",
            model_name="gpt-5.4",
            reasoning_effort="high",
            latency_label="fast",
            directory_label="~/code/ralphception",
            is_task_running=True,
        ),
    )
    pane = BottomPaneWidget(base_state)

    class Harness(App[None]):
        def compose(self):
            yield pane

    async def exercise() -> tuple[int, str]:
        async with Harness().run_test() as pilot:
            await pilot.pause()
            composer = pane.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("r", "e", "v", "i", "e", "w", "tab")
            await pilot.pause()
            preview = pane.query_one("#pending-input-preview", Static)
            return len(pane.query("#pending-input-preview")), str(preview.renderable)

    preview_count, rendered = asyncio.run(exercise())
    assert preview_count == 1
    assert "Queued follow-up messages" in rendered
    assert "review" in rendered
