from __future__ import annotations

from pathlib import Path

from ralphception.tui.bottom_pane.approval_overlay import ApprovalOverlayState, render_approval_overlay
from ralphception.tui.bottom_pane.list_selection import (
    ListSelectionRowState,
    ListSelectionState,
    render_list_selection,
)
from ralphception.tui.bottom_pane.request_user_input import RequestUserInputState, render_request_user_input


def test_approval_overlay_renders_blocking_prompt() -> None:
    fixture_path = Path(__file__).resolve().parents[1] / "golden" / "codex_port" / "approval_overlay.txt"
    rendered = render_approval_overlay(
        ApprovalOverlayState(
            title="Execution bundle v2",
            summary="Approve or reject the proposed execution bundle.",
            actions=("approve", "reject"),
        ),
        width=80,
    )
    assert rendered == fixture_path.read_text(encoding="utf-8")
    assert "Execution bundle v2" in rendered
    assert "approve" in rendered.lower()


def test_request_user_input_and_list_selection_render_rows() -> None:
    form = render_request_user_input(
        RequestUserInputState(prompt="Which mode?", options=("Read", "Repair")),
        width=60,
    )
    picker = render_list_selection(
        ListSelectionState(
            title="Pick a thread",
            rows=(
                ListSelectionRowState(row_id="run-root", label="run-root"),
                ListSelectionRowState(row_id="run-child-1", label="run-child-1"),
            ),
        ),
        width=60,
    )
    assert "Which mode?" in form
    assert "Read" in form
    assert "Pick a thread" in picker
    assert "run-child-1" in picker
