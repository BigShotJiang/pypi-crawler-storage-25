from __future__ import annotations

import hashlib
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

from ralphception.app import resolve_runtime_view, run_headless
from ralphception.config import RalphceptionConfig
from ralphception.models.artifacts import ArtifactRef
from ralphception.runtime.bootstrap import StartupBootstrapController, load_startup_record
from ralphception.runtime.interactive_session import write_interactive_session_state
from ralphception.runtime.prompt_state import BlockedContinuationRef, InteractiveSessionState, PendingPrompt
from ralphception.runtime.terminal import ScriptedTerminalFrontend, run_terminal
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.workflow.bundles import create_bundle


def test_resolve_runtime_view_returns_startup_inline_shell_for_empty_workspace(tmp_path: Path) -> None:
    launch = resolve_runtime_view(tmp_path)

    assert launch.mode == "startup"
    assert launch.startup_controller is not None
    assert launch.interactive_frontend is not None
    assert launch.supervisor is not None
    prompt = launch.supervisor.current_pending_prompt()
    assert prompt is not None
    assert prompt.prompt_kind == "startup_prompt"


def test_startup_controller_transitions_launch_to_dashboard(tmp_path: Path) -> None:
    launch = resolve_runtime_view(tmp_path)
    assert launch.startup_controller is not None

    launch.startup_controller.start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    next_launch = resolve_runtime_view(tmp_path)
    assert next_launch.mode == "dashboard"
    assert next_launch.interactive_frontend is not None
    assert next_launch.engine is not None


def test_first_prompt_enters_socratic_intake_and_writes_artifacts(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path / "startup-intake")
    _init_git_repo(repo_root)
    frontend = ScriptedTerminalFrontend(
        inputs=[
            "fix typos",
            "focus on docs and comments",
            "spelling only, and completion means the docs/comments typo pass is clean",
        ]
    )

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = frontend.output_text()

    assert "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?" in output
    assert (
        "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
    ) in output
    assert "Wrote intake summary" in output
    assert "Wrote PRD" in output
    assert "Wrote execution plan" in output
    assert "Wrote loop plan" in output
    assert "Wrote todos" in output
    assert result.mode == "completed"


def test_resolve_runtime_view_returns_review_mode_for_pending_spec(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "review"
    assert launch.review_controller is not None
    assert launch.interactive_frontend is not None
    assert launch.review_controller.current_target() is not None


def test_resolve_runtime_view_treats_persisted_launch_conflict_as_startup_mode(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path / "conflict-workspace")
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="existing mission",
        source_repos=[],
    )
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState(
            root_thread_id="run-root",
            active_thread_id="run-root",
            pending_prompts=[
                PendingPrompt(
                    thread_id="run-root",
                    owner_run_id="run-root",
                    prompt_id="prompt-conflict-1",
                    prompt_kind="launch_conflict",
                    title="Session conflict",
                    question="Replace the unfinished session in this workspace?",
                    allowed_actions=("override", "abort"),
                    context={"requested_seed_prompt": "new mission"},
                    blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
                )
            ],
        ),
    )

    launch = resolve_runtime_view(repo_root)

    assert launch.mode == "startup"
    assert launch.interactive_frontend is not None
    assert launch.supervisor is not None
    prompt = launch.supervisor.current_pending_prompt()
    assert prompt is not None
    assert prompt.question == "Replace the unfinished session in this workspace?"


def test_review_controller_approve_current_target_unblocks_dashboard(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)

    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None
    launch.review_controller.approve_current_target(approver="user")

    next_launch = resolve_runtime_view(repo_root)
    assert next_launch.mode == "dashboard"
    assert next_launch.review_controller is None


def test_launch_path_starts_execution_for_approved_bundle(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path / "launch-runtime")
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Launch should start execution.\n",
    )
    _approve_current_review_target(repo_root)
    plan_ref = _write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Runtime Plan\n\n- Launch should start execution.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=_utc_now(),
    )
    _approve_current_review_target(repo_root)

    launch = resolve_runtime_view(
        repo_root,
        session_manager_factory=_build_fake_session_manager_for_repo,
    )

    assert launch.mode == "dashboard"
    assert launch.engine is not None
    assert launch.engine.stage("execute").status == "running"
    assert launch.engine.run("run-child-1").goal.startswith("Execute approved bundle v2")
    assert launch.interactive_frontend is not None
    assert (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").exists()


def test_run_headless_bootstraps_workspace_without_tui(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        result = run_headless(
            repo_root=tmp_path,
            seed_prompt="port parser",
            source_repos=(),
        )

    assert result.mode == "startup"
    assert load_startup_record(tmp_path) is None


def test_run_headless_auto_approves_review_targets_and_starts_execution(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    spec_ref = _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Headless mode approves reviews.\n",
    )
    plan_ref = _write_artifact(
        repo_root,
        artifact_kind="plan",
        artifact_path=".ralphception/plans/runtime.md",
        content="# Runtime Plan\n\n- Headless mode starts execution.\n",
    )
    create_bundle(
        repo_root,
        bundle_id="bundle-2",
        run_id="run-root",
        bundle_version=2,
        state="awaiting_approval",
        artifact_refs=[spec_ref, plan_ref],
        stage_id="stage-plan",
        created_at=_utc_now(),
    )

    result = run_headless(
        repo_root=repo_root,
        approve_all=True,
        approver="automation",
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert "approved:execution_bundle" in result.actions
    assert result.review_target_kind is None
    assert result.root_run_status == "completed"
    assert resolve_runtime_view(repo_root).mode == "startup"


def _prepare_review_workspace(tmp_path: Path) -> Path:
    repo_root = bootstrap_workspace(tmp_path / "review-workspace")
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Review before planning.\n",
    )
    return repo_root


def _approve_current_review_target(repo_root: Path) -> None:
    launch = resolve_runtime_view(repo_root)
    assert launch.review_controller is not None
    launch.review_controller.approve_current_target(approver="user")


def _write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )


def _init_git_repo(repo_root: Path) -> None:
    subprocess.run(["git", "init"], cwd=repo_root, check=True, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Ralphception Tests"], cwd=repo_root, check=True)
    subprocess.run(["git", "config", "user.email", "tests@example.com"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("# fixture\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=repo_root, check=True, capture_output=True)


def _build_fake_session_manager_for_repo(repo_root: Path, config: RalphceptionConfig) -> object:
    return build_fake_session_manager(
        workspace_path=str(repo_root),
        config=config,
    )


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)
