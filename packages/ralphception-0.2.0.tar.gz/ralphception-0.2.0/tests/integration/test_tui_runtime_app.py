from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
from typing import cast
from unittest.mock import patch

from ralphception.codex.config import CodexRuntimeSettings
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.config import DEFAULT_CONFIG, RalphceptionConfig, load_config, write_config_atomically
from ralphception.paths import config_path
from textual.widgets import Static, TextArea

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.runtime import Run, RunStageStatus
from ralphception.models.session import ChildSessionRef
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.interactive_session import load_interactive_session_marker, write_interactive_session_state
from ralphception.runtime.prompt_state import InteractiveSessionState
from ralphception.testing.fakes import (
    FakeCodexClient,
    build_fake_headless_session_manager,
    FakeHeadlessTurnWriter,
    FakeNotification,
    build_fake_session_manager,
)
from ralphception.tui.app import RalphceptionTuiApp
from ralphception.tui.bottom_pane.chat_composer import ChatComposer
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, AssistantCell, UserCell
from ralphception.tui.render_state import RenderState, StatusIndicatorState
from ralphception.tui.runtime_adapter import RuntimeAdapter

_GENERIC_STARTUP_FIRST_QUESTION = (
    "What outcome or definition of done should I use for the first execution slice?"
)
_GENERIC_STARTUP_SECOND_QUESTION = (
    "Are there any hard constraints, no-go areas, or review expectations I should treat as boundaries?"
)
_TYPO_SCOPE_QUESTION = (
    "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
)
_TYPO_CONSTRAINTS_QUESTION = (
    "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
)


def test_tui_app_renders_codex_idle_shell_for_empty_workspace(tmp_path: Path) -> None:
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(tmp_path)

        async def exercise() -> tuple[int, int, str, str]:
            async with app.run_test() as pilot:
                await pilot.pause()
                return (
                    len(app.query(TextArea)),
                    len(app.query("#startup-submit")),
                    str(app.query_one("#composer-input", ChatComposer).placeholder),
                    app.export_text(),
                )

        textareas, submit_buttons, placeholder, rendered = asyncio.run(exercise())
    assert textareas == 1
    assert submit_buttons == 0
    assert placeholder == "Describe the task or ask a question"
    assert "Describe the task or ask a question" in rendered
    assert "Describe what you want Ralphception to work on in this workspace" not in rendered
    assert "This workspace needs an initial task before Ralphception can start." not in rendered
    assert "Waiting for your reply" not in rendered
    assert "Socratic intake" not in rendered
    assert "Bootstrapped" not in rendered


def test_tui_app_keeps_startup_transcript_quiet_while_runtime_is_live(tmp_path: Path) -> None:
    app = RalphceptionTuiApp.from_runtime(
        tmp_path,
        session_manager_factory=_streaming_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            for _ in range(10):
                await pilot.pause()
                await asyncio.sleep(0.01)
            return app.export_text()

    rendered = asyncio.run(exercise())
    assert "Describe the task or ask a question" in rendered
    assert "Describe what you want Ralphception to work on in this workspace" not in rendered
    assert "Waiting for your reply" not in rendered
    assert "Socratic intake" not in rendered
    assert "Bootstrapped" not in rendered
    assert "Stage:" not in rendered
    assert "Turn started:" not in rendered


def test_tui_app_idle_composer_stays_compact_when_empty(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> int:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            return composer.size.height

    composer_height = asyncio.run(exercise())
    assert composer_height <= 3


def test_tui_app_submits_startup_and_removes_startup_controls(tmp_path: Path) -> None:
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(tmp_path)

        async def exercise() -> tuple[int, str]:
            async with app.run_test() as pilot:
                composer = app.query_one("#composer-input", ChatComposer)
                composer.focus()
                await pilot.pause()
                await pilot.press("f", "i", "n", "d", " ", "a", "n", "d", " ", "f", "i", "x", " ", "a", " ", "b", "u", "g", "enter")
                await pilot.pause()
                return len(app.query("#startup-submit")), app.export_text()

        remaining_submit_buttons, rendered = asyncio.run(exercise())
    assert remaining_submit_buttons == 0
    assert "find and fix a bug" in rendered


def test_tui_app_completes_socratic_startup_without_controller_spam(tmp_path: Path) -> None:
    repo_root = tmp_path / "startup-conversation"
    repo_root.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("# Readme\n\nThs is a typo.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=repo_root, check=True)

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press(*list("fix typos in the readme"), "enter")
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if _TYPO_SCOPE_QUESTION in rendered:
                    break
                await asyncio.sleep(0.01)
            await pilot.press(*list("README only"), "enter")
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if _TYPO_CONSTRAINTS_QUESTION in rendered:
                    break
                await asyncio.sleep(0.01)
            await pilot.press(
                *list("Spelling only, and completion means the README typo pass is clean."),
                "enter",
            )
            for _ in range(400):
                await pilot.pause()
                rendered = app.export_text()
                if "Session completed: run-root" in rendered:
                    return rendered
                await asyncio.sleep(0.01)
            raise AssertionError(app.export_text())

    rendered = asyncio.run(exercise())
    assert "Wrote intake summary" in rendered
    assert "Wrote PRD" in rendered
    assert "Loop completed: run-child-1" in rendered
    assert "Audit passed: no blocking findings" in rendered
    assert "Session completed: run-root" in rendered
    assert "Child run created:" not in rendered
    assert "Current task:" not in rendered
    assert "Current plan node:" not in rendered
    assert "Current loop:" not in rendered


def test_tui_app_clears_submitted_startup_prompt_before_socratic_follow_up(tmp_path: Path) -> None:
    repo_root = tmp_path / "startup-composer-reset"
    repo_root.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("# Readme\n\nThs is a typo.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=repo_root, check=True)

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press(*list("fix typos in the readme"), "enter")
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if _TYPO_SCOPE_QUESTION in rendered:
                    composer = app.query_one("#composer-input", ChatComposer)
                    return composer.text, rendered
                await asyncio.sleep(0.01)
            raise AssertionError(app.export_text())

    composer_text, rendered = asyncio.run(exercise())
    assert composer_text == ""
    assert "› fix typos in the readmeREADME only" not in rendered


def test_tui_app_recreates_missing_startup_prompt_before_first_submit(tmp_path: Path) -> None:
    repo_root = tmp_path / "startup-prompt-race"
    repo_root.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=repo_root, check=True)
    (repo_root / "README.md").write_text("# Readme\n\nThs is a typo.\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=repo_root, check=True)

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            write_interactive_session_state(repo_root, InteractiveSessionState())
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press(*list("fix typos in the readme"), "enter")
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if _TYPO_SCOPE_QUESTION in rendered:
                    return rendered
                await asyncio.sleep(0.01)
            raise AssertionError(app.export_text())

    rendered = asyncio.run(exercise())
    assert _TYPO_SCOPE_QUESTION in rendered
    assert "Wrote intake summary" not in rendered


def test_tui_app_adds_startup_source_repo_from_slash_command(tmp_path: Path) -> None:
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(tmp_path)

        async def exercise() -> tuple[str, str, str]:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input", ChatComposer)
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "s", "o", "u", "r", "c", "e", "space", "/", "t", "m", "p", "/", "s", "o", "u", "r", "c", "e", "enter")
                await pilot.pause()
                composer = app.query_one("#composer-input", ChatComposer)
                return app.export_text(), composer.text, composer.render_line(0).text

        rendered, composer_text, composer_line = asyncio.run(exercise())
    assert "Added source repo: /tmp/source" in rendered
    assert "/source /tmp/source" not in rendered
    assert composer_text == ""
    assert "Describe the task or ask a question" in composer_line


def test_tui_app_accepts_natural_language_review_reply_without_review_buttons(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> tuple[int, str]:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input", ChatComposer)
                composer.focus()
                await pilot.pause()
                await pilot.press("a", "p", "p", "r", "o", "v", "e", " ", "i", "t", "enter")
                for _ in range(40):
                    await pilot.pause()
                    rendered = app.export_text()
                    if "Approved: spec_review" in rendered:
                        return len(app.query("#review-action-approve")), rendered
                    await asyncio.sleep(0.01)
                return len(app.query("#review-action-approve")), app.export_text()

        remaining_approve_buttons, rendered = asyncio.run(exercise())
    assert remaining_approve_buttons == 0
    assert "Approved: spec_review" in rendered


def test_tui_app_focuses_composer_on_first_review_render(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> str | None:
            async with app.run_test() as pilot:
                await pilot.pause()
                return app.focused.id if app.focused is not None else None

        focused_id = asyncio.run(exercise())
    assert focused_id == "composer-input"


def test_tui_app_restores_idle_composer_placeholder_after_review_approval(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> tuple[str, str, str]:
            async with app.run_test(size=(120, 40)) as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input", ChatComposer)
                composer.focus()
                await pilot.pause()
                await pilot.press("a", "p", "p", "r", "o", "v", "e", "enter")
                for _ in range(40):
                    await pilot.pause()
                    await asyncio.sleep(0.01)
                    if app.query("#composer-input"):
                        composer = app.query_one("#composer-input", ChatComposer)
                        return composer.text, composer.render_line(0).text, app.export_text()
                raise AssertionError("composer never returned after review approval")

        composer_text, composer_line, rendered = asyncio.run(exercise())
    assert composer_text == ""
    assert "Send the next instruction to Ralphception" in composer_line
    assert "Send the next instruction to Ralphception" in rendered


def test_tui_app_opens_agent_picker_from_slash_command(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> str:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input")
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "a", "g", "e", "n", "t", "enter")
                await pilot.pause()
                return str(app.query_one("#agent-picker-view", Static).renderable)

        rendered = asyncio.run(exercise())
    assert "Select an agent to watch." in rendered
    assert "Main [default]" in rendered
    assert "Worker 1 [worker]" in rendered


def test_tui_app_enters_selected_slash_command_from_popup(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> str:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input")
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "down", "enter")
                await pilot.pause()
                return app.export_text()

        rendered = asyncio.run(exercise())
    assert "inherited from Codex config" in rendered


def test_tui_app_shows_pending_thread_approvals_for_inactive_agents(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="awaiting_approval")
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> str:
            async with app.run_test() as pilot:
                await pilot.pause()
                return str(app.query_one("#pending-thread-approvals", Static).renderable)

        rendered = asyncio.run(exercise())
    assert "Approval needed in Worker 1 [worker]" in rendered
    assert "/agent to switch threads" in rendered


def test_tui_app_keeps_transcript_visible_when_agent_picker_is_open(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> bool:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input")
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "a", "g", "e", "n", "t", "enter")
                await pilot.pause()
                transcript = app.query_one("#transcript-view", Static)
                return bool(transcript.display)

        transcript_visible = asyncio.run(exercise())
    assert transcript_visible is True


def test_tui_app_escape_closes_agent_picker_and_restores_composer(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> tuple[int, int]:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input")
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "a", "g", "e", "n", "t", "enter")
                await pilot.pause()
                await pilot.press("escape")
                await pilot.pause()
                return len(app.query("#agent-picker-view")), len(app.query("#composer-input"))

        picker_count, composer_count = asyncio.run(exercise())
    assert picker_count == 0
    assert composer_count == 1


def test_tui_app_selects_agent_picker_row_and_updates_active_thread(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> tuple[int, int, str | None]:
            async with app.run_test() as pilot:
                await pilot.pause()
                composer = app.query_one("#composer-input")
                composer.focus()
                await pilot.pause()
                await pilot.press("/", "a", "g", "e", "n", "t", "enter")
                await pilot.pause()
                await pilot.press("down", "enter")
                await pilot.pause()
                return (
                    len(app.query("#agent-picker-view")),
                    len(app.query("#composer-input")),
                    app.render_state.bottom_pane.footer.active_thread_label,
                )

        picker_count, composer_count, active_thread_label = asyncio.run(exercise())
    assert picker_count == 0
    assert composer_count == 1
    assert active_thread_label == "Worker 1 [worker]"


def test_tui_app_can_cycle_agent_threads_from_main_shell(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    with patch("ralphception.tui.runtime_adapter.codex_cli_available", return_value=False):
        app = RalphceptionTuiApp.from_runtime(repo_root)

        async def exercise() -> tuple[str | None, str | None]:
            async with app.run_test() as pilot:
                await pilot.pause()
                await pilot.press("alt+right")
                await pilot.pause()
                next_label = app.render_state.bottom_pane.footer.active_thread_label
                await pilot.press("alt+left")
                await pilot.pause()
                previous_label = app.render_state.bottom_pane.footer.active_thread_label
                return next_label, previous_label

        next_label, previous_label = asyncio.run(exercise())
    assert next_label == "Worker 1 [worker]"
    assert previous_label == "Main [default]"


def test_tui_app_submits_turns_to_selected_agent_thread(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_message_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "a", "g", "e", "n", "t", "enter")
            await pilot.pause()
            await pilot.press("down", "enter")
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "Inspecting the workspace." in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Inspecting the workspace." in rendered
    assert "Turn started: run-child-1 interactive" not in rendered


def test_tui_app_shows_running_status_indicator_during_live_turn(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_message_session_manager_factory,
    )

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            indicator_text = ""
            full_text = ""
            for _ in range(120):
                await pilot.pause()
                full_text = app.export_text()
                indicators = app.query("#status-indicator")
                if indicators:
                    indicator_text = str(app.query_one("#status-indicator", Static).renderable)
                    if "Working" in indicator_text:
                        break
                await asyncio.sleep(0.01)
            return indicator_text, full_text

    indicator_text, full_text = asyncio.run(exercise())
    assert "Working" in indicator_text
    assert "esc to interrupt" in indicator_text.lower()
    assert "Inspecting the workspace." in full_text


def test_tui_app_escape_interrupts_active_run_from_running_shell(tmp_path: Path) -> None:
    repo_root = tmp_path / "interrupt-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    assert isinstance(manager.client, FakeCodexClient)
    fake_client = cast(FakeCodexClient, manager.client)
    manager.start_session(run_id="run-root")
    manager.run_turn(run_id="run-root", input_text="interrupt me")

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    app.render_state = replace(
        app.render_state,
        bottom_pane=replace(
            app.render_state.bottom_pane,
            status_indicator=app.render_state.bottom_pane.status_indicator or StatusIndicatorState(header="Working"),
            footer=replace(
                app.render_state.bottom_pane.footer,
                is_task_running=True,
                left_hint="Ctrl+C interrupt",
            ),
        ),
    )

    async def exercise() -> list[tuple[str, str]]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("escape")
            await pilot.pause()
            return list(fake_client.interruptions)

    interruptions = asyncio.run(exercise())
    assert interruptions == [("thread-1", "turn-1")]


def test_tui_app_escape_restores_queued_messages_into_composer(tmp_path: Path) -> None:
    repo_root = tmp_path / "interrupt-queued-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-root")
    manager.run_turn(run_id="run-root", input_text="interrupt me")

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    app.render_state = replace(
        app.render_state,
        bottom_pane=replace(
            app.render_state.bottom_pane,
            queued_messages=("first queued", "second queued"),
            status_indicator=app.render_state.bottom_pane.status_indicator or StatusIndicatorState(header="Working"),
            footer=replace(
                app.render_state.bottom_pane.footer,
                is_task_running=True,
                left_hint="Ctrl+C interrupt",
            ),
        ),
    )
    runtime_adapter = cast(RuntimeAdapter, app.runtime_adapter)
    runtime_adapter.queue_message(text="first queued", render_immediately=False)
    runtime_adapter.queue_message(text="second queued", render_immediately=False)

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("escape")
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            return composer.text, app.export_text()

    composer_text, exported = asyncio.run(exercise())
    assert composer_text == "first queued\nsecond queued"
    assert "Queued follow-up messages" not in exported


def test_tui_app_alt_up_edits_most_recent_queued_message(tmp_path: Path) -> None:
    repo_root = tmp_path / "edit-queued-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-root")
    manager.run_turn(run_id="run-root", input_text="queue edits")

    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    app.render_state = replace(
        app.render_state,
        bottom_pane=replace(
            app.render_state.bottom_pane,
            queued_messages=("first queued", "second queued"),
            status_indicator=app.render_state.bottom_pane.status_indicator or StatusIndicatorState(header="Working"),
            footer=replace(
                app.render_state.bottom_pane.footer,
                is_task_running=True,
                left_hint="Ctrl+C interrupt",
            ),
        ),
    )
    runtime_adapter = cast(RuntimeAdapter, app.runtime_adapter)
    runtime_adapter.queue_message(text="first queued", render_immediately=False)
    runtime_adapter.queue_message(text="second queued", render_immediately=False)

    async def exercise() -> tuple[str, str | None]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("alt+up")
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            previews = app.query("#pending-input-preview")
            preview_text = None if not previews else str(app.query_one("#pending-input-preview", Static).renderable)
            return composer.text, preview_text

    composer_text, preview_text = asyncio.run(exercise())
    assert composer_text == "second queued"
    assert preview_text is not None
    assert "first queued" in preview_text
    assert "second queued" not in preview_text


def test_tui_app_help_slash_command_surfaces_shell_guidance(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_message_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "h", "e", "l", "p", "enter")
            await pilot.pause()
            return app.export_text()

    rendered = asyncio.run(exercise())
    assert "Enter submit" in rendered
    assert "/agent switch threads" in rendered
    assert "/resume continue interrupted work" in rendered


def test_tui_app_preserves_live_draft_in_shell_state_during_runtime_updates(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_output_delta_session_manager_factory,
    )

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            await pilot.pause()
            await pilot.press("d", "r", "a", "f", "t")
            for _ in range(60):
                await pilot.pause()
                await asyncio.sleep(0.01)
                if "git status --short" in app.export_text():
                    break
            composer = app.query_one("#composer-input", ChatComposer)
            return composer.text, app.render_state.bottom_pane.composer.value

    widget_text, state_text = asyncio.run(exercise())
    assert widget_text.rstrip("\n") == "draft"
    assert state_text.rstrip("\n") == "draft"

def test_tui_app_preserves_live_draft_while_stale_runtime_updates_stream(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    initial_state = RenderState.idle_preview(repo_root)
    app = RalphceptionTuiApp(
        initial_state,
        runtime_adapter=cast(RuntimeAdapter, _StaleSnapshotRuntimeAdapter(initial_state)),
    )

    async def exercise() -> tuple[str, str, bool]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            await pilot.pause()
            await pilot.press("d", "r", "a", "f", "t")
            for _ in range(80):
                await pilot.pause()
                await asyncio.sleep(0.01)
            composer = app.query_one("#composer-input", ChatComposer)
            return (
                composer.text,
                app.render_state.bottom_pane.composer.value,
                app.render_state.bottom_pane.footer.is_task_running,
            )

    widget_text, state_text, is_task_running = asyncio.run(exercise())
    assert widget_text.rstrip("\n") == "draft"
    assert state_text.rstrip("\n") == "draft"
    assert is_task_running is True


def test_tui_app_keeps_composer_blank_after_submit_while_stale_runtime_updates_arrive(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    initial_state = RenderState.idle_preview(repo_root)
    app = RalphceptionTuiApp(
        initial_state,
        runtime_adapter=cast(RuntimeAdapter, _StaleSnapshotRuntimeAdapter(initial_state)),
    )

    async def exercise() -> tuple[str, str, bool]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            for _ in range(80):
                await pilot.pause()
                await asyncio.sleep(0.01)
            composer = app.query_one("#composer-input", ChatComposer)
            return (
                composer.text,
                app.render_state.bottom_pane.composer.value,
                app.render_state.bottom_pane.footer.is_task_running,
            )

    widget_text, state_text, is_task_running = asyncio.run(exercise())
    assert widget_text == ""
    assert state_text == ""
    assert is_task_running is True


def test_tui_app_drains_the_latest_runtime_burst_in_one_tick(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    initial_state = RenderState.idle_preview(repo_root)
    app = RalphceptionTuiApp(
        initial_state,
        runtime_adapter=cast(RuntimeAdapter, _BurstSnapshotRuntimeAdapter(initial_state)),
    )

    async def exercise() -> tuple[str, str | None, bool]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            app._drain_runtime_updates()
            await pilot.pause()
            indicator = app.render_state.bottom_pane.status_indicator
            return (
                app.export_text(),
                None if indicator is None else indicator.header,
                app.render_state.bottom_pane.footer.is_task_running,
            )

    rendered, indicator_header, is_task_running = asyncio.run(exercise())
    assert "Final assistant message." in rendered
    assert "Intermediate runtime update." not in rendered
    assert indicator_header is None
    assert is_task_running is False


def test_tui_app_preserves_live_draft_when_runtime_finishes_to_idle(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    initial_state = RenderState.idle_preview(repo_root)
    app = RalphceptionTuiApp(
        initial_state,
        runtime_adapter=cast(RuntimeAdapter, _FinalIdleSnapshotRuntimeAdapter(initial_state)),
    )

    async def exercise() -> tuple[str, str, bool]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            await pilot.pause()
            await pilot.press("d", "r", "a", "f", "t")
            for _ in range(80):
                await pilot.pause()
                await asyncio.sleep(0.01)
            composer = app.query_one("#composer-input", ChatComposer)
            return (
                composer.text,
                app.render_state.bottom_pane.composer.value,
                app.render_state.bottom_pane.footer.is_task_running,
            )

    widget_text, state_text, is_task_running = asyncio.run(exercise())
    assert widget_text.rstrip("\n") == "draft"
    assert state_text.rstrip("\n") == "draft"
    assert is_task_running is False


def test_tui_app_remains_non_idle_while_background_wait_is_unresolved(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_background_wait_session_manager_factory,
    )

    async def exercise() -> tuple[bool, str, bool, bool]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            for _ in range(80):
                await pilot.pause()
                await asyncio.sleep(0.01)
            return (
                app.render_state.bottom_pane.footer.is_task_running,
                app.export_text(),
                app.render_state.bottom_pane.status_indicator is not None,
                app.render_state.transcript.active is not None,
            )

    is_task_running, rendered, has_status_indicator, has_active_transcript = asyncio.run(exercise())
    assert is_task_running is True
    assert "Ctrl+C interrupt" in rendered
    assert "Waiting" in rendered
    assert has_status_indicator or has_active_transcript


def test_tui_app_shows_active_command_in_status_indicator_details(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_output_delta_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                indicators = app.query("#status-indicator")
                if indicators:
                    rendered = str(app.query_one("#status-indicator", Static).renderable)
                    if "git status --short" in rendered:
                        break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Working" in rendered
    assert "git status --short" in rendered


def test_tui_app_surfaces_reasoning_header_and_commits_reasoning_summary(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_reasoning_summary_session_manager_factory,
    )

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            indicator_text = ""
            transcript_text = ""
            for _ in range(120):
                await pilot.pause()
                indicator = app.render_state.bottom_pane.status_indicator
                if indicator is not None:
                    indicator_text = indicator.header
                transcript_text = app.export_text()
                if "Inspect README.md for typos." in transcript_text:
                    break
                await asyncio.sleep(0.01)
            return indicator_text, transcript_text

    indicator_text, transcript_text = asyncio.run(exercise())
    assert indicator_text in {"Planning codebase inspection", "Working"}
    assert "Inspect README.md for typos." in transcript_text
    assert "coding agent" not in transcript_text
    assert "commentary tools" not in transcript_text


def test_tui_app_uses_codex_config_model_in_session_header(tmp_path: Path, monkeypatch) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    custom_config = replace(
        DEFAULT_CONFIG,
        codex=replace(
            DEFAULT_CONFIG.codex,
            model="gpt-5.3-codex",
            reasoning="medium",
            latency_profile="balanced",
        ),
    )
    write_config_atomically(config_path(repo_root), custom_config)
    monkeypatch.setattr(
        "ralphception.tui.runtime_adapter.load_codex_runtime_settings",
        lambda: CodexRuntimeSettings(
            model="gpt-5.4",
            reasoning_effort="xhigh",
            service_tier="fast",
            config_path=Path("/Users/shayne/.codex/config.toml"),
        ),
    )
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            return str(app.query_one("#session-header", Static).renderable)

    rendered = asyncio.run(exercise())
    assert "gpt-5.4 xhigh" in rendered
    assert "fast" in rendered
    assert "mission:" not in rendered


def test_tui_app_keeps_default_launch_idle_when_workspace_has_resumable_session(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    _write_interactive_session_marker(
        repo_root,
        root_run_id="run-root",
        active_run_id="run-child-1",
        blocking_surface_kind="review",
    )
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> tuple[str, int]:
        async with app.run_test() as pilot:
            await pilot.pause()
            return app.export_text(), len(app.query("#resume-picker-view"))

    rendered, resume_picker_count = asyncio.run(exercise())
    assert "Resume the last Ralphception session or start fresh?" not in rendered
    assert "Describe the task or ask a question" in rendered or "Send the next instruction to Ralphception" in rendered
    assert resume_picker_count == 0


def test_tui_app_focuses_composer_when_resumable_session_exists_on_launch(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    _write_interactive_session_marker(
        repo_root,
        root_run_id="run-root",
        active_run_id="run-child-1",
        blocking_surface_kind="review",
    )
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> str | None:
        async with app.run_test() as pilot:
            await pilot.pause()
            return app.focused.id if app.focused is not None else None

    focused_id = asyncio.run(exercise())
    assert focused_id == "composer-input"


def test_tui_app_first_prompt_starts_fresh_instead_of_resuming_last_session(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    _write_interactive_session_marker(
        repo_root,
        root_run_id="run-root",
        active_run_id="run-child-1",
        blocking_surface_kind="review",
    )
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )

    async def exercise() -> tuple[bool, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("f", "i", "x", " ", "t", "y", "p", "o", "s", "enter")
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if load_interactive_session_marker(repo_root) is None:
                    return True, rendered
                await asyncio.sleep(0.01)
            return load_interactive_session_marker(repo_root) is None, app.export_text()

    marker_cleared, rendered = asyncio.run(exercise())
    assert marker_cleared
    assert "Resume the last Ralphception session or start fresh?" not in rendered
    assert "Resuming the previous session." not in rendered
    assert "fix typos" in rendered


def test_tui_app_resume_command_restores_last_active_thread_without_picker(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path)
    _write_interactive_session_marker(
        repo_root,
        root_run_id="run-root",
        active_run_id="run-child-1",
        blocking_surface_kind="review",
    )
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> tuple[int, str | None, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "r", "e", "s", "u", "m", "e", "enter")
            for _ in range(40):
                await pilot.pause()
                if app.render_state.bottom_pane.footer.active_thread_label is not None:
                    break
                await asyncio.sleep(0.01)
            return (
                len(app.query("#resume-picker-view")),
                app.render_state.bottom_pane.footer.active_thread_label,
                app.export_text(),
            )

    resume_picker_count, active_thread_label, rendered = asyncio.run(exercise())
    assert resume_picker_count == 0
    assert active_thread_label == "Worker 1 [worker]"
    assert "Resuming the previous session." in rendered


def test_tui_app_resume_command_shows_help_when_no_resumable_session_exists(tmp_path: Path) -> None:
    app = RalphceptionTuiApp.from_runtime(tmp_path)

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "r", "e", "s", "u", "m", "e", "enter")
            await pilot.pause()
            return app.export_text()

    rendered = asyncio.run(exercise())
    assert "No resumable Ralphception session was found" in rendered


def test_tui_app_model_command_shows_inherited_codex_guidance(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(repo_root)

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("/", "m", "o", "d", "e", "l", "enter")
            await pilot.pause()
            return app.export_text()

    rendered = asyncio.run(exercise())
    assert "inherited from Codex config" in rendered
    assert "restart Ralphception" in rendered
    assert "model-picker-view" not in rendered


def test_tui_app_streams_live_progress_after_startup_submit(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_streaming_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("f", "i", "n", "d", " ", "a", "n", "d", " ", "f", "i", "x", " ", "a", " ", "b", "u", "g", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if (
                    "• Ran git status --short" in rendered
                    or "Starting the Ralph loop and execution phase." in rendered
                ):
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Starting the Ralph loop and execution phase." in rendered or "• Ran git status --short" in rendered
    assert "Describe what you want Ralphception to work on in this workspace" not in rendered
    assert "Preparing the initial spec and plan for this workspace." not in rendered
    assert "Socratic intake" not in rendered
    assert "Bootstrapped" not in rendered
    assert "Stage: spec" not in rendered
    assert "Stage: plan" not in rendered
    assert "Turn started:" not in rendered
    assert "Turn completed:" not in rendered


def test_tui_app_fake_headless_startup_path_emits_conversational_progress(tmp_path: Path) -> None:
    repo_root = tmp_path / "fresh-fake-headless-workspace"
    repo_root.mkdir()
    _init_git_repo(repo_root)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("f", "i", "n", "d", " ", "a", "n", "y", " ", "b", "u", "g", "s", "enter")
            for _ in range(40):
                await pilot.pause()
                if _GENERIC_STARTUP_FIRST_QUESTION in app.export_text():
                    break
                await asyncio.sleep(0.01)
            await pilot.press(
                "f",
                "o",
                "c",
                "u",
                "s",
                " ",
                "o",
                "n",
                " ",
                "d",
                "o",
                "c",
                "s",
                " ",
                "a",
                "n",
                "d",
                " ",
                "c",
                "o",
                "m",
                "m",
                "e",
                "n",
                "t",
                "s",
                "enter",
            )
            for _ in range(40):
                await pilot.pause()
                if _GENERIC_STARTUP_SECOND_QUESTION in app.export_text():
                    break
                await asyncio.sleep(0.01)
            await pilot.press(
                "c",
                "o",
                "m",
                "p",
                "l",
                "e",
                "t",
                "i",
                "o",
                "n",
                " ",
                "m",
                "e",
                "a",
                "n",
                "s",
                " ",
                "t",
                "h",
                "e",
                " ",
                "f",
                "i",
                "r",
                "s",
                "t",
                " ",
                "s",
                "l",
                "i",
                "c",
                "e",
                " ",
                "s",
                "t",
                "a",
                "y",
                "s",
                " ",
                "i",
                "n",
                " ",
                "s",
                "c",
                "o",
                "p",
                "e",
                ",",
                " ",
                "i",
                "s",
                " ",
                "v",
                "e",
                "r",
                "i",
                "f",
                "i",
                "e",
                "d",
                ",",
                " ",
                "a",
                "n",
                "d",
                " ",
                "i",
                "s",
                " ",
                "r",
                "e",
                "a",
                "d",
                "y",
                " ",
                "f",
                "o",
                "r",
                " ",
                "r",
                "e",
                "v",
                "i",
                "e",
                "w",
                "enter",
            )
            rendered = ""
            for _ in range(160):
                await pilot.pause()
                rendered = app.export_text()
                if "Inspecting the workspace." in rendered and "• Ran git status --short" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Inspecting the workspace." in rendered
    assert "• Ran git status --short" in rendered


def test_tui_app_surfaces_plan_update_before_command_output(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_plan_update_session_manager_factory,
    )

    async def exercise() -> tuple[str, str]:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            rendered = ""
            indicator_text = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                indicator = app.render_state.bottom_pane.status_indicator
                if indicator is not None:
                    indicator_text = indicator.header
                if "Inspect repository structure and identify likely failing area" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered, indicator_text

    rendered, indicator_text = asyncio.run(exercise())
    assert "Inspect repository structure and identify likely failing area" in rendered
    assert indicator_text in {
        "Inspect repository structure and identify likely failing area",
        "Working",
    }


def test_tui_app_renders_live_command_output_delta(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_output_delta_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "M src/ralphception/tui/runtime_adapter.py" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "• Running git status --short" in rendered or "• Ran git status --short" in rendered
    assert "└ M src/ralphception/tui/runtime_adapter.py" in rendered


def test_tui_app_runs_live_progress_after_review_approval(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_streaming_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input", ChatComposer)
            composer.focus()
            await pilot.pause()
            await pilot.press("a", "p", "p", "r", "o", "v", "e", " ", "i", "t", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "• Ran git status --short" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Approved: spec_review" in rendered
    assert "• Ran git status --short" in rendered
    assert "Stage: plan" not in rendered
    assert "Turn started:" not in rendered
    assert "Turn completed:" not in rendered


def test_tui_app_submits_live_message_from_composer(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_message_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("c", "h", "e", "c", "k", " ", "t", "h", "e", " ", "l", "a", "s", "t", " ", "f", "a", "i", "l", "u", "r", "e", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "check the last failure" in rendered and "Checking the last failure." in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "check the last failure" in rendered
    assert "Checking the last failure." in rendered


def test_tui_app_updates_footer_from_live_token_usage_notification(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_token_usage_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "950K window" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "950K window" in rendered


def test_tui_app_queues_follow_up_message_with_tab_while_task_running(tmp_path: Path) -> None:
    repo_root = _prepare_dashboard_workspace(tmp_path)
    app = RalphceptionTuiApp.from_runtime(
        repo_root,
        session_manager_factory=_message_session_manager_factory,
    )

    async def exercise() -> str:
        async with app.run_test() as pilot:
            await pilot.pause()
            composer = app.query_one("#composer-input")
            composer.focus()
            await pilot.pause()
            await pilot.press("i", "n", "s", "p", "e", "c", "t", "enter")
            await pilot.pause()
            await pilot.press("c", "h", "e", "c", "k", " ", "t", "h", "e", " ", "l", "a", "s", "t", " ", "f", "a", "i", "l", "u", "r", "e", "tab")
            rendered = ""
            for _ in range(120):
                await pilot.pause()
                rendered = app.export_text()
                if "Queued follow-up messages" in rendered:
                    break
                await asyncio.sleep(0.01)
            return rendered

    rendered = asyncio.run(exercise())
    assert "Queued follow-up messages" in rendered
    assert "check the last failure" in rendered


def _prepare_review_workspace(tmp_path: Path) -> Path:
    repo_root = tmp_path / "review-workspace"
    repo_root.mkdir()
    _init_git_repo(repo_root)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/mission-spec.md",
        content="# Runtime Spec\n\n- Review before planning.\n",
    )
    return repo_root


def _init_git_repo(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], cwd=repo_root, check=True, capture_output=True, text=True)
    (repo_root / "README.md").write_text("review workspace\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], cwd=repo_root, check=True, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=repo_root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=repo_root, check=True, capture_output=True, text=True)


def _prepare_dashboard_workspace(tmp_path: Path) -> Path:
    from ralphception.runtime.frontends import ReviewDecision
    from ralphception.runtime.supervisor import RuntimeSupervisor

    repo_root = _prepare_review_workspace(tmp_path)
    RuntimeSupervisor(repo_root=repo_root).apply_review_decision(
        ReviewDecision(action="approve", approver="tui")
    )
    return repo_root


class _StaleSnapshotRuntimeAdapter:
    def __init__(self, initial_state: RenderState) -> None:
        self._state = initial_state
        self._queued_updates: list[RenderState] = []

    def can_run_live(self) -> bool:
        return True

    def start(self) -> None:
        return None

    def replace_render_state(self, render_state: RenderState) -> None:
        self._state = render_state

    def submit_message(self, *, text: str, render_immediately: bool = True) -> None:
        del text, render_immediately
        baseline = self._state
        stale_update = replace(
            baseline,
            transcript=replace(
                baseline.transcript,
                active=ActiveCell(prefix="assistant", text="Still working", item_id="message-1"),
            ),
            bottom_pane=replace(
                baseline.bottom_pane,
                composer=replace(baseline.bottom_pane.composer, value="stale"),
                status_indicator=StatusIndicatorState(header="Working"),
                footer=replace(
                    baseline.bottom_pane.footer,
                    left_hint="Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
        self._queued_updates = [stale_update, stale_update]

    def drain_render_state(self) -> RenderState | None:
        if not self._queued_updates:
            return None
        self._state = self._queued_updates.pop(0)
        return self._state


class _FinalIdleSnapshotRuntimeAdapter(_StaleSnapshotRuntimeAdapter):
    def submit_message(self, *, text: str, render_immediately: bool = True) -> None:
        del text, render_immediately
        baseline = self._state
        running_update = replace(
            baseline,
            transcript=replace(
                baseline.transcript,
                active=ActiveCell(prefix="assistant", text="Still working", item_id="message-1"),
            ),
            bottom_pane=replace(
                baseline.bottom_pane,
                composer=replace(baseline.bottom_pane.composer, value=""),
                status_indicator=StatusIndicatorState(header="Working"),
                footer=replace(
                    baseline.bottom_pane.footer,
                    left_hint="Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
        idle_update = replace(
            baseline,
            transcript=replace(baseline.transcript, active=None),
            bottom_pane=replace(
                baseline.bottom_pane,
                composer=replace(baseline.bottom_pane.composer, value=""),
                status_indicator=None,
                footer=replace(
                    baseline.bottom_pane.footer,
                    left_hint="? for shortcuts",
                    is_task_running=False,
                ),
            ),
        )
        self._queued_updates = [running_update, idle_update]


class _BurstSnapshotRuntimeAdapter(_StaleSnapshotRuntimeAdapter):
    def submit_message(self, *, text: str, render_immediately: bool = True) -> None:
        del text, render_immediately
        baseline = self._state
        intermediate_update = replace(
            baseline,
            transcript=replace(
                baseline.transcript,
                active=ActiveCell(prefix="assistant", text="Intermediate runtime update.", item_id="message-1"),
            ),
            bottom_pane=replace(
                baseline.bottom_pane,
                status_indicator=StatusIndicatorState(header="Working"),
                footer=replace(
                    baseline.bottom_pane.footer,
                    left_hint="Ctrl+C interrupt",
                    is_task_running=True,
                ),
            ),
        )
        final_update = replace(
            baseline,
            transcript=replace(
                baseline.transcript,
                committed=(UserCell("inspect"), AssistantCell("Final assistant message.")),
                active=None,
            ),
            bottom_pane=replace(
                baseline.bottom_pane,
                status_indicator=None,
                footer=replace(
                    baseline.bottom_pane.footer,
                    left_hint="? for shortcuts",
                    is_task_running=False,
                ),
            ),
        )
        self._queued_updates = [intermediate_update, final_update]

    def drain_next_render_state(self) -> RenderState | None:
        if not self._queued_updates:
            return None
        self._state = self._queued_updates.pop(0)
        return self._state


def _streaming_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        command = "git status --short"
        message_id = f"message-{turn_counter}"
        command_id = f"command-{turn_counter}"
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {"type": "agentMessage", "id": message_id, "text": ""},
                    },
                ),
                FakeNotification(
                    method="item/agentMessage/delta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": message_id,
                        "delta": "Inspecting the workspace.",
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "agentMessage",
                            "id": message_id,
                            "text": "Inspecting the workspace.",
                        },
                    },
                ),
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "commandExecution",
                            "id": command_id,
                            "command": command,
                            "status": "inProgress",
                        },
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "commandExecution",
                            "id": command_id,
                            "command": command,
                            "status": "completed",
                            "exitCode": 0,
                        },
                    },
                ),
            ],
        )
        writer.handle_turn(session, input_text, turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )


def _plan_update_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="turn/plan/updated",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "explanation": None,
                        "plan": [
                            {
                                "step": "Inspect repository structure and identify likely failing area",
                                "status": "inProgress",
                            },
                            {
                                "step": "Implement a fix for the discovered bug",
                                "status": "pending",
                            },
                        ],
                    },
                )
            ],
        )
        writer.handle_turn(session, input_text, turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )


def _message_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        assistant_text = (
            "Checking the last failure."
            if "last failure" in input_text.lower()
            else "Inspecting the workspace."
        )
        message_id = f"message-{turn_counter}"
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {"type": "agentMessage", "id": message_id, "text": ""},
                    },
                ),
                FakeNotification(
                    method="item/agentMessage/delta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": message_id,
                        "delta": assistant_text,
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "agentMessage",
                            "id": message_id,
                            "text": assistant_text,
                        },
                    },
                ),
            ],
        )
        writer.handle_turn(session, input_text, turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )


def _output_delta_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        command_id = f"command-{turn_counter}"
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "commandExecution",
                            "id": command_id,
                            "command": "git status --short",
                            "status": "inProgress",
                        },
                    },
                ),
                FakeNotification(
                    method="item/commandExecution/outputDelta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": command_id,
                        "delta": "M src/ralphception/tui/runtime_adapter.py\n",
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "commandExecution",
                            "id": command_id,
                            "command": "git status --short",
                            "status": "completed",
                            "exitCode": 0,
                        },
                    },
                ),
            ],
        )
        writer.handle_turn(session, input_text, turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )


def _token_usage_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        message_id = f"message-{turn_counter}"
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="item/started",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {"type": "agentMessage", "id": message_id, "text": ""},
                    },
                ),
                FakeNotification(
                    method="item/agentMessage/delta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": message_id,
                        "delta": "Inspecting the workspace.",
                    },
                ),
                FakeNotification(
                    method="thread/tokenUsage/updated",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "tokenUsage": {
                            "last": {
                                "cachedInputTokens": 1,
                                "inputTokens": 2,
                                "outputTokens": 3,
                                "reasoningOutputTokens": 0,
                                "totalTokens": 6,
                            },
                            "total": {
                                "cachedInputTokens": 4,
                                "inputTokens": 10,
                                "outputTokens": 12,
                                "reasoningOutputTokens": 0,
                                "totalTokens": 26,
                            },
                            "modelContextWindow": 950000,
                        },
                    },
                ),
                FakeNotification(
                    method="item/completed",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "item": {
                            "type": "agentMessage",
                            "id": message_id,
                            "text": "Inspecting the workspace.",
                        },
                    },
                ),
            ],
        )
        writer.handle_turn(session, input_text, turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )


def _background_wait_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        del input_text
        fake_client.notifications.extend(
            [
                FakeNotification(
                    method="subagent_waiting",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "agentThreadId": "worker-1",
                        "summary": "Waiting on tail -f log",
                    },
                ),
            ],
        )

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )

def _reasoning_summary_session_manager_factory(
    resolved_repo_root: Path,
    config: RalphceptionConfig,
) -> CodexSessionManager:
    fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
    writer = FakeHeadlessTurnWriter()

    def turn_handler(session, input_text: str, turn_counter: int) -> None:
        del input_text
        reasoning_id = f"reasoning-{turn_counter}"
        notifications = [
            FakeNotification(
                method="item/started",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {
                        "type": "reasoning",
                        "id": reasoning_id,
                        "summary": [],
                        "content": [],
                    },
                },
            ),
            FakeNotification(
                method="item/reasoning/summaryPartAdded",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "itemId": reasoning_id,
                    "summaryIndex": 0,
                },
            ),
        ]
        for chunk in (
            "**Planning codebase inspection**\n\nI need to act as a coding agent and inspect",
            " README.md",
            " for typos.",
        ):
            notifications.append(
                FakeNotification(
                    method="item/reasoning/summaryTextDelta",
                    payload={
                        "threadId": session.thread_id,
                        "turnId": f"turn-{turn_counter}",
                        "itemId": reasoning_id,
                        "summaryIndex": 0,
                        "delta": chunk,
                    },
                )
            )
        notifications.append(
            FakeNotification(
                method="item/completed",
                payload={
                    "threadId": session.thread_id,
                    "turnId": f"turn-{turn_counter}",
                    "item": {
                        "type": "reasoning",
                        "id": reasoning_id,
                        "summary": [
                            {
                                "type": "summary_text",
                                "text": "**Planning codebase inspection**\n\nI need to act as a coding agent and inspect README.md for typos.",
                            }
                        ],
                        "content": [],
                    },
                },
            )
        )
        fake_client.notifications.extend(notifications)
        writer.handle_turn(session, "inspect", turn_counter)

    fake_client.turn_handler = turn_handler
    return CodexSessionManager(
        workspace_path=str(resolved_repo_root),
        config=config,
        client=fake_client,
    )
def _prepare_child_run_workspace(
    tmp_path: Path,
    *,
    child_status: RunStageStatus = "running",
) -> Path:
    repo_root = tmp_path / "child-run-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    now = datetime.now(timezone.utc)
    root_run = Run(
        run_id="run-root",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Find any bugs",
        status="running",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id="run-root",
            codex_thread_id="thread-root",
            codex_session_id="session-root",
            workspace_path=str(repo_root),
            resumable=True,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    root_run_path = repo_root / ".ralphception" / "runs" / "run-root"
    root_run_path.mkdir(parents=True, exist_ok=True)
    (root_run_path / "run.json").write_text(root_run.model_dump_json(indent=2), encoding="utf-8")
    (root_run_path / "headless-state.json").write_text(json.dumps({"current_stage": "execute"}), encoding="utf-8")
    child_run = Run(
        run_id="run-child-1",
        parent_run_id="run-root",
        supersedes_run_id=None,
        goal="Inspect the runtime adapter implementation",
        status=child_status,
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id="run-child-1",
            codex_thread_id="thread-child-1",
            codex_session_id="session-child-1",
            workspace_path=str(repo_root),
            resumable=True,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    child_run_path = repo_root / ".ralphception" / "runs" / "run-child-1"
    child_run_path.mkdir(parents=True, exist_ok=True)
    (child_run_path / "run.json").write_text(child_run.model_dump_json(indent=2), encoding="utf-8")
    (child_run_path / "headless-state.json").write_text(json.dumps({"current_stage": "execute"}), encoding="utf-8")
    return repo_root


def _write_interactive_session_marker(
    repo_root: Path,
    *,
    root_run_id: str,
    active_run_id: str | None,
    blocking_surface_kind: str | None,
) -> Path:
    marker_path = repo_root / ".ralphception" / "interactive-session.json"
    marker_path.write_text(
        json.dumps(
            {
                "root_run_id": root_run_id,
                "active_run_id": active_run_id,
                "resumable": True,
                "blocking_surface_kind": blocking_surface_kind,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return marker_path


def _write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )
