import subprocess
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Literal

import pytest

import ralphception.app as runtime_app
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.models.runtime import Run
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.checkpoints import write_checkpoint
from ralphception.storage.events import EventStore
from ralphception.storage.lease import WorkspaceLeaseConflictError, read_workspace_lease, write_workspace_lease
from ralphception.testing.fakes import build_fake_session_manager
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.workflow.engine import WorkflowEngine
from ralphception.workflow.recovery import RecoveryBlockedError, RecoveryService


def test_resume_read_mode_does_not_take_lease(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    result = service.resume(run_id="run-root", mode="read")

    assert result.mode == "read"
    assert result.lease_taken is False
    assert read_workspace_lease(repo_root, xdg_state_home=xdg_state_home) is None


def test_resume_app_repair_mode_resumes_current_workspace_root_run(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="Coordinate workflow",
        source_repos=[],
    )

    result = runtime_app.resume_app(repo_root=repo_root, mode="repair")
    lease = read_workspace_lease(repo_root)

    assert result.run_id == "run-root"
    assert result.mode == "repair"
    assert result.lease_taken is True
    assert lease is not None
    assert lease.run_id == "run-root"


def test_repair_resume_acquires_workspace_lease_and_heartbeat_refreshes_it(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    clock = sequential_clock(
        utc_now(),
        utc_now() + timedelta(minutes=1),
    )
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=clock,
    )

    result = service.resume(run_id="run-root", mode="repair")
    refreshed = service.heartbeat()

    assert result.lease_taken is True
    assert result.lease is not None
    assert refreshed.run_id == "run-root"
    assert refreshed.heartbeat_at > result.lease.heartbeat_at


def test_resume_repair_mode_refuses_healthy_foreign_lease(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-foreign",
        process_id=9999,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    with pytest.raises(WorkspaceLeaseConflictError, match="healthy workspace lease"):
        service.resume(run_id="run-root", mode="repair")


def test_resume_repair_mode_can_steal_stale_lease(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-foreign",
        process_id=9999,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now() - timedelta(minutes=10),
        xdg_state_home=xdg_state_home,
    )
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    result = service.resume(run_id="run-root", mode="repair")
    lease = read_workspace_lease(repo_root, xdg_state_home=xdg_state_home)

    assert result.lease_taken is True
    assert lease is not None
    assert lease.run_id == "run-root"


def test_resume_repair_mode_refuses_healthy_same_run_lease_owned_by_another_process(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    write_workspace_lease(
        repo_root,
        run_id="run-root",
        process_id=9999,
        authoritative_repository_root=repo_root,
        heartbeat_at=utc_now(),
        xdg_state_home=xdg_state_home,
    )
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    with pytest.raises(WorkspaceLeaseConflictError, match="healthy workspace lease"):
        service.resume(run_id="run-root", mode="repair")


def test_retry_run_reconciles_checkpoint_and_requeues_failed_run(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "xdg-state"
    append_run_started(repo_root, run_id="run-root", goal="Coordinate workflow", parent_run_id=None)
    append_run_started(repo_root, run_id="run-child-a", goal="Implement parser", parent_run_id="run-root")
    write_root_checkpoint(repo_root, event_offsets={"run-root": 1, "run-child-a": 1})
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    resumed = service.resume(run_id="run-child-a", mode="read")
    retried = service.retry_run("run-child-a")

    assert resumed.recommended_action == "retry"
    assert resumed.checkpoint_reconciled is True
    assert retried.run_id == "run-child-a"
    assert retried.status == "pending"


def test_restart_run_recovers_session_lost_run_from_checkpoint(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, session_manager = build_engine(repo_root, child_status="session_lost")
    xdg_state_home = tmp_path / "xdg-state"
    append_run_started(repo_root, run_id="run-root", goal="Coordinate workflow", parent_run_id=None)
    append_run_started(repo_root, run_id="run-child-a", goal="Implement parser", parent_run_id="run-root")
    write_root_checkpoint(repo_root, event_offsets={"run-root": 1, "run-child-a": 1})
    previous_session_ref = session_manager.get_session_ref("run-child-a")
    assert previous_session_ref is not None
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    resumed = service.resume(run_id="run-child-a", mode="read")
    restarted = service.restart_run("run-child-a")
    current_session_ref = session_manager.get_session_ref("run-child-a")

    assert resumed.recommended_action == "restart"
    assert resumed.checkpoint_reconciled is True
    assert restarted.run_id == "run-child-a"
    assert restarted.status == "running"
    assert current_session_ref is not None
    assert current_session_ref.codex_thread_id != previous_session_ref.codex_thread_id
    assert restarted.codex_session_ref == current_session_ref


def test_replace_run_creates_new_run_with_supersedes_link(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    service = build_recovery_service(
        engine,
        xdg_state_home=tmp_path / "xdg-state",
        clock=lambda: utc_now(),
    )

    replacement = service.replace_run("run-child-a")

    assert replacement.supersedes_run_id == "run-child-a"
    assert replacement.parent_run_id == "run-root"
    assert replacement.run_id == "run-child-a-replacement-1"


def test_resume_repair_mode_repairs_missing_xdg_state(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    xdg_state_home = tmp_path / "missing-xdg-state"
    service = build_recovery_service(
        engine,
        xdg_state_home=xdg_state_home,
        clock=lambda: utc_now(),
    )

    result = service.resume(run_id="run-root", mode="repair")

    assert result.xdg_state_repaired is True
    assert read_workspace_lease(repo_root, xdg_state_home=xdg_state_home) is not None


def test_resume_blocks_corrupt_event_logs(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    service = build_recovery_service(
        engine,
        xdg_state_home=tmp_path / "xdg-state",
        clock=lambda: utc_now(),
    )
    event_store = EventStore(repo_root)
    corrupt_log = event_store.run_path("run-child-a")
    corrupt_log.parent.mkdir(parents=True, exist_ok=True)
    corrupt_log.write_text("{not json}\n", encoding="utf-8")

    with pytest.raises(RecoveryBlockedError, match="Corrupt event log"):
        service.resume(run_id="run-child-a", mode="repair")


def test_resume_blocks_partial_event_logs_that_regress_checkpoint_offsets(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    service = build_recovery_service(
        engine,
        xdg_state_home=tmp_path / "xdg-state",
        clock=lambda: utc_now(),
    )
    append_run_started(repo_root, run_id="run-root", goal="Coordinate workflow", parent_run_id=None)
    append_run_started(repo_root, run_id="run-child-a", goal="Implement parser", parent_run_id="run-root")
    write_root_checkpoint(repo_root, event_offsets={"run-root": 1, "run-child-a": 2})

    with pytest.raises(RecoveryBlockedError, match="checkpoint offset"):
        service.resume(run_id="run-child-a", mode="repair")


def test_resume_uses_newest_checkpoint_after_double_digits(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    engine, _ = build_engine(repo_root)
    service = build_recovery_service(
        engine,
        xdg_state_home=tmp_path / "xdg-state",
        clock=lambda: utc_now(),
    )
    append_run_started(repo_root, run_id="run-root", goal="Coordinate workflow", parent_run_id=None)
    append_run_started(repo_root, run_id="run-child-a", goal="Implement parser", parent_run_id="run-root")
    for checkpoint_number in range(1, 12):
        write_root_checkpoint(
            repo_root,
            checkpoint_id=f"checkpoint-{checkpoint_number}",
            event_offsets={
                "run-root": 1,
                "run-child-a": 2 if checkpoint_number == 11 else 1,
            },
            created_at=utc_now() + timedelta(minutes=checkpoint_number),
        )

    with pytest.raises(RecoveryBlockedError, match="checkpoint offset"):
        service.resume(run_id="run-child-a", mode="read")


def build_recovery_service(
    engine: WorkflowEngine,
    *,
    xdg_state_home: Path,
    clock: Callable[[], datetime],
) -> RecoveryService:
    return RecoveryService(
        engine=engine,
        process_id=4242,
        xdg_state_home=xdg_state_home,
        clock=clock,
        lease_timeout=timedelta(minutes=5),
    )


def build_engine(
    repo_root: Path,
    *,
    child_status: Literal["failed", "session_lost"] = "failed",
) -> tuple[WorkflowEngine, CodexSessionManager]:
    repo_root = bootstrap_workspace(repo_root)
    session_manager = build_fake_session_manager(workspace_path=str(repo_root))
    session_manager.start_session(run_id="run-root", goal="Coordinate workflow", workspace_path=str(repo_root))
    root_run = Run(
        run_id="run-root",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Coordinate workflow",
        status="running",
        stage_ids=[],
        config_snapshot={},
        codex_session_ref=session_manager.get_session_ref("run-root"),
        artifact_refs=[],
        created_at=utc_now(),
        updated_at=utc_now(),
    )

    child_session_ref = None
    if child_status == "session_lost":
        session_manager.start_session(
            run_id="run-child-a",
            goal="Implement parser",
            parent_run_id="run-root",
            workspace_path=str(repo_root),
        )
        child_session_ref = session_manager.get_session_ref("run-child-a")

    child_run = Run(
        run_id="run-child-a",
        parent_run_id="run-root",
        supersedes_run_id=None,
        goal="Implement parser",
        status=child_status,
        stage_ids=[],
        config_snapshot={},
        codex_session_ref=child_session_ref,
        artifact_refs=[],
        created_at=utc_now(),
        updated_at=utc_now(),
    )
    return (
        WorkflowEngine(
            repo_root=repo_root,
            root_run=root_run,
            stages=[],
            child_runs=[child_run],
            session_manager=session_manager,
        ),
        session_manager,
    )


def append_run_started(
    repo_root: Path,
    *,
    run_id: str,
    goal: str,
    parent_run_id: str | None,
) -> None:
    EventStore(repo_root).append(
        event_id=f"{run_id}-started",
        run_id=run_id,
        event_type="run.started",
        source="test",
        payload={"goal": goal, "parent_run_id": parent_run_id},
    )


def write_root_checkpoint(
    repo_root: Path,
    *,
    event_offsets: dict[str, int],
    checkpoint_id: str = "checkpoint-1",
    created_at: datetime | None = None,
) -> None:
    write_checkpoint(
        repo_root,
        checkpoint_id=checkpoint_id,
        run_id="run-root",
        checkpoint_kind="recovery-test",
        event_offsets=event_offsets,
        bundle_version=1,
        authoritative_root=str(repo_root),
        active_worktrees=[],
        created_at=created_at or utc_now(),
    )


def sequential_clock(*values: datetime) -> Callable[[], datetime]:
    remaining = list(values)

    def _clock() -> datetime:
        if len(remaining) == 1:
            return remaining[0]
        return remaining.pop(0)

    return _clock


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "init",
    )
    return repo_root


def run_git(cwd: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", *args],
        check=True,
        cwd=cwd,
        capture_output=True,
        text=True,
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
