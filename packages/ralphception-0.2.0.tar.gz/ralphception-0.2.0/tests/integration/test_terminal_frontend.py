from __future__ import annotations
	
from datetime import datetime, timezone
import json
import queue
import subprocess
from pathlib import Path
import threading
import time
from typing import cast
from unittest.mock import patch

import pytest

import ralphception.headless as headless_module
from ralphception.codex.client import CodexTurnRef, normalize_notification
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.codex_tui.app import CodexTuiFrontend
from ralphception.config import RalphceptionConfig
from ralphception.git.worktrees import WorktreeCreateFailed
from ralphception.models.runtime import Run
from ralphception.models.session import ChildSessionRef
from ralphception.runtime.codex_terminal import (
    CodexTerminalFrontend,
    RecordingTerminalSurface,
    _wrap_history_lines,
)
from ralphception.runtime.frontends import BlockerPromptEvent, CurrentBlockerStateEvent
from ralphception.runtime.interactive_session import load_interactive_session_marker
from ralphception.runtime.frontends import FailureSummaryEvent
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeResumeUnavailableError,
    RuntimeSupervisor,
)
from ralphception.runtime.terminal import ScriptedTerminalFrontend, TerminalFrontend, TerminalRunResult, run_terminal
from ralphception.storage.artifacts import read_authoritative_revision
from ralphception.testing.fakes import (
    FakeCodexClient,
    FakeHeadlessTurnWriter,
    FakeNotification,
    build_fake_session_manager,
)
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.codex_tui.styled_text import strip_ansi

_STARTUP_CONTEXT_REPLY = "focus on docs and comments only"
_STARTUP_BOUNDARY_REPLY = (
    "completion means the first slice stays in scope, is verified, and is ready for review"
)
_GENERIC_STARTUP_FIRST_QUESTION = (
    "What outcome or definition of done should I use for the first execution slice?"
)
_GENERIC_STARTUP_SECOND_QUESTION = (
    "Are there any hard constraints, no-go areas, or review expectations I should treat as boundaries?"
)
_TYPO_SCOPE_QUESTION = (
    "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
)
_TYPO_CONSTRAINTS_QUESTION = (
    "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
)


class CallbacklessTerminalFrontend(TerminalFrontend):
    def __init__(self, *, inputs: list[str]) -> None:
        super().__init__(input_func=self.input_func, write_func=lambda _text: None)
        self._inputs = list(inputs)

    def emit_event(self, event) -> None:
        self._output_lines.append(event.message)

    def emit_status(self, step) -> None:
        self._output_lines.append(f"Runtime: {step.kind}")

    def finish(self, step) -> None:
        self._output_lines.append(f"Finished: {step.kind}")

    def output_text(self) -> str:
        return "\n".join(self._output_lines)

    def input_func(self, prompt: str) -> str:
        self._output_lines.append(prompt)
        if not self._inputs:
            raise RuntimeError(f"no scripted input available for prompt {prompt!r}")
        return self._inputs.pop(0)


def _seeded_follow_up_inputs(*answers: str) -> list[str]:
    if answers and "typo" in answers[0].lower():
        scope_reply = "README only" if "readme" in answers[0].lower() else "docs and comments only"
        constraints_reply = (
            "spelling only, and completion means the README typo pass is clean"
            if "readme" in answers[0].lower()
            else "spelling only, and completion means the docs/comments typo pass is clean"
        )
        return [*answers, scope_reply, constraints_reply]
    return [*answers, _STARTUP_CONTEXT_REPLY, _STARTUP_BOUNDARY_REPLY]


def test_terminal_frontend_prompts_for_startup_inputs(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("port parser"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert "Input requested: Start first task" not in output
    assert "You: " not in output
    assert "› port parser" in output
    assert _GENERIC_STARTUP_FIRST_QUESTION in output
    assert result.mode == "completed"


def test_terminal_frontend_emits_settled_milestones_for_long_running_work(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("look for typos"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert "Wrote intake summary" in output
    assert "Wrote PRD" in output
    assert "Wrote execution plan" in output
    assert "Wrote loop plan" in output
    assert "Wrote todos" in output
    assert "Launched" in output
    assert {event.kind for event in frontend.events if getattr(event, "kind", None)} >= {
        "runtime.artifact_write",
        "runtime.live_status",
        "runtime.loop_launch",
        "runtime.loop_completion",
        "runtime.milestone_transcript_line",
        "runtime.current_task_label",
        "runtime.current_plan_node_label",
        "runtime.current_loop_label",
    }
    assert result.mode == "completed"


def test_terminal_frontend_does_not_duplicate_startup_clarification_prompt(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("port parser"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    question = _GENERIC_STARTUP_FIRST_QUESTION

    assert result.mode == "completed"
    assert frontend.output_text().count(question) == 1


def test_terminal_frontend_uses_task_shaped_startup_follow_up_for_typo_scope(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("look at and fix typos in the readme"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    question = _TYPO_SCOPE_QUESTION

    assert result.mode == "completed"
    assert frontend.output_text().count(question) == 1


def test_terminal_frontend_emits_settled_agent_output_without_delta_spam(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("port parser"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert result.mode == "completed"
    assert "Agent delta:" not in output
    assert "Reasoning summary delta:" not in output
    assert "Inspecting the workspace." in output


def test_terminal_frontend_reports_real_touched_paths_in_loop_completion_and_artifact_updates(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    (repo_root / "README.md").write_text(
        "# Typo Doc\n\nThis repo has several typo examples.\n",
        encoding="utf-8",
    )
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("look at and fix typos"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert result.mode == "completed"
    assert "Updated authoritative artifacts: README.md" in output
    assert "Updated authoritative artifacts: src/" not in output
    assert "src/parser.py" not in output
    assert "Loop completed: run-child-1 Completed Ralph loop work for README.md." in output
    assert "Audit reopened execution" not in output


def test_run_terminal_uses_codex_terminal_frontend_by_default(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    observed: dict[str, str] = {}

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        observed["frontend_type"] = type(frontend).__name__
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(self.repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        use_fake_session_manager=True,
    )

    assert observed == {"frontend_type": CodexTuiFrontend.__name__}
    assert result.mode == "completed"


def test_recording_terminal_surface_keeps_committed_history_outside_live_view() -> None:
    surface = RecordingTerminalSurface(width=40, height=12)

    surface.render(
        [
            "╭ header ╮",
            "│ body   │",
            "╰────────╯",
            "",
            "› ",
        ]
    )
    surface.commit(["Wrote PRD", "Launched run-child-1"])

    assert surface.history_lines == [
        "Wrote PRD",
        "Launched run-child-1",
    ]
    assert surface.view_lines == (
        "╭ header ╮",
        "│ body   │",
        "╰────────╯",
        "",
        "› ",
    )


def test_codex_terminal_frontend_hides_initial_startup_question_from_history_and_view(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    surface = RecordingTerminalSurface(width=72, height=18)
    frontend = CodexTerminalFrontend(repo_root=repo_root, surface=surface)
    question = "Describe what you want Ralphception to work on in this workspace."

    frontend.emit_event(CurrentBlockerStateEvent(label=question))
    frontend.emit_event(
        BlockerPromptEvent(
            prompt_id="prompt-run-root-startup",
            title="Start first task",
            question=question,
        )
    )

    assert question not in frontend.output_text()
    assert all(question not in line for line in surface.view_lines)


def test_codex_terminal_frontend_commits_blocker_prompt_once_and_keeps_live_view_generic(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    surface = RecordingTerminalSurface(width=72, height=18)
    frontend = CodexTerminalFrontend(repo_root=repo_root, surface=surface)
    question = _TYPO_SCOPE_QUESTION

    frontend.emit_event(CurrentBlockerStateEvent(label=question))
    frontend.emit_event(
        BlockerPromptEvent(
            prompt_id="prompt-run-root-follow-up",
            title="Clarify scope",
            question=question,
        )
    )

    assert frontend.output_text().count(question) == 1
    assert all(question not in line for line in surface.view_lines)
    assert any("Waiting for your response" in line for line in surface.view_lines)


def test_wrap_history_lines_splits_embedded_newlines_before_terminal_insert() -> None:
    wrapped = _wrap_history_lines(
        ["Agent: fixed typo\n\nREADME.md updated\nmerge_readiness: ready"],
        width=80,
    )

    assert wrapped == [
        "Agent: fixed typo",
        "",
        "README.md updated",
        "merge_readiness: ready",
    ]


def test_terminal_frontend_bootstraps_without_prompt_callback_methods(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = CallbacklessTerminalFrontend(inputs=_seeded_follow_up_inputs("port parser"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert "Input requested: Start first task" in frontend.output_text()
    assert "Seed prompt" not in frontend.output_text()
    assert "what you want ralphception to work on" not in frontend.output_text().lower()
    assert _GENERIC_STARTUP_FIRST_QUESTION.lower() in frontend.output_text().lower()


def test_terminal_frontend_with_seed_prompt_fails_fast_without_backend(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)

    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        with pytest.raises(RuntimeBackendUnavailableError, match="No Codex session backend"):
            run_terminal(
                repo_root=repo_root,
                seed_prompt="find any bugs",
                frontend=ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs()),
            )


def test_terminal_frontend_first_prompt_starts_fresh_when_workspace_has_active_session(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="existing mission",
        source_repos=[],
    )
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert "--resume" not in frontend.output_text()
    assert "Input requested: Session conflict" not in frontend.output_text()
    assert "Reply: " not in frontend.output_text()
    assert "Resumed run-root" not in frontend.output_text()
    assert "Wrote intake summary" in frontend.output_text()
    assert result.mode == "completed"


def test_terminal_frontend_same_prompt_still_starts_fresh_by_default(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert "--resume" not in frontend.output_text()
    assert "Input requested: Session conflict" not in frontend.output_text()
    assert "Reply: " not in frontend.output_text()
    assert "Resumed run-root" not in frontend.output_text()
    assert "Wrote intake summary" in frontend.output_text()
    assert result.mode == "completed"


def test_terminal_frontend_first_prompt_overwrites_resumable_session_state(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    _prepare_resumable_runtime_workspace(repo_root)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("look at and fix typos in the readme"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert "Resumed run-root" not in frontend.output_text()
    assert "Input requested: Session conflict" not in frontend.output_text()
    assert "Reply: " not in frontend.output_text()
    assert frontend.output_text().count(_TYPO_SCOPE_QUESTION) == 1
    assert frontend.output_text().count(_TYPO_CONSTRAINTS_QUESTION) == 1
    assert "Wrote intake summary" in frontend.output_text()
    assert load_interactive_session_marker(repo_root) is None


def test_terminal_frontend_direct_start_does_not_leave_resumable_review_state(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    initial_frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    initial = run_terminal(
        repo_root=repo_root,
        frontend=initial_frontend,
        use_fake_session_manager=True,
    )

    assert initial.mode == "completed"
    assert "Executing the loop plan" in initial_frontend.output_text()
    assert "Reply: " not in initial_frontend.output_text()
    assert load_interactive_session_marker(repo_root) is None
    assert read_authoritative_revision(repo_root, "execution-plan") is not None

    with pytest.raises(RuntimeResumeUnavailableError, match="has no existing session to resume"):
        run_terminal(
            repo_root=repo_root,
            frontend=ScriptedTerminalFrontend(),
            approve_all=True,
            use_fake_session_manager=True,
            resume=True,
        )


def test_terminal_frontend_direct_start_skips_manual_startup_reviews_when_approvals_are_manual(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs("find any bugs"))

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        approve_all=False,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert result.mode == "completed"
    assert "Executing the loop plan" in output
    assert "Execution bundle" not in output
    assert "Reply: " not in output
    assert load_interactive_session_marker(repo_root) is None
    assert read_authoritative_revision(repo_root, "execution-plan") is not None
    assert not (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").exists()


def test_terminal_frontend_streams_high_level_mission_progress(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    output = strip_ansi(frontend.output_text())

    assert "Stage: spec" not in output
    assert "Stage: plan" not in output
    assert "Approved: spec_review" not in output
    assert "Approved: execution_bundle" not in output
    assert "Executing the loop plan" in output
    assert "Child run created: run-child-1" not in output
    assert "Verification passed: run-child-1 execute" in output
    assert "Merged: run-child-1" in output
    assert "Audit passed: no blocking findings" in output
    assert "Session completed: run-root" in output
    assert result.mode == "completed"


def test_terminal_frontend_streams_live_turn_progress_from_raw_backend_events(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        fake_client = FakeCodexClient(workspace_path=str(resolved_repo_root))
        writer = FakeHeadlessTurnWriter()

        def turn_handler(session, input_text: str, turn_counter: int) -> None:
            command = "git status --short"
            message_id = f"message-{turn_counter}"
            command_id = f"command-{turn_counter}"
            fake_client.notifications.extend(
                [
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {"type": "agentMessage", "id": message_id, "text": ""},
                        },
                    ),
                    FakeNotification(
                        method="item/agentMessage/delta",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "itemId": message_id,
                            "delta": "Inspecting the workspace.",
                        },
                    ),
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "agentMessage",
                                "id": message_id,
                                "text": "Inspecting the workspace.",
                            },
                        },
                    ),
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "inProgress",
                            },
                        },
                    ),
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "completed",
                                "exitCode": 0,
                            },
                        },
                    ),
                ],
            )
            writer.handle_turn(session, input_text, turn_counter)

        fake_client.turn_handler = turn_handler
        return CodexSessionManager(
            workspace_path=str(resolved_repo_root),
            config=config,
            client=fake_client,
        )

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
    )

    output = strip_ansi(frontend.output_text())

    assert "Inspecting the workspace." in output
    assert "• Ran git status --short" in output
    assert result.mode == "completed"


def test_terminal_frontend_emits_live_progress_before_turn_completion(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    observed: dict[str, object] = {}

    class BlockingFakeCodexClient(FakeCodexClient):
        def __init__(self, *, workspace_path: str) -> None:
            super().__init__(workspace_path=workspace_path)
            self._notification_queue: queue.Queue[FakeNotification] = queue.Queue()

        def turn_start(
            self,
            thread_id: str,
            input_text: str,
            *,
            cwd: str | None,
            config,
        ) -> CodexTurnRef:
            if thread_id not in self._sessions_by_thread_id:
                raise RuntimeError(f"missing thread {thread_id}")
            self.turn_counter += 1
            turn_id = f"turn-{self.turn_counter}"
            session = self._sessions_by_thread_id[thread_id]
            self._notification_queue.put(
                FakeNotification(
                    method="turn/started",
                    payload={"threadId": thread_id, "turn": {"id": turn_id, "status": "running"}},
                ),
            )
            if self.turn_handler is not None:
                self.turn_handler(session, input_text, self.turn_counter)
            return CodexTurnRef(thread_id=thread_id, turn_id=turn_id)

        def next_notification(self):
            notification = self._notification_queue.get(timeout=5)
            return normalize_notification(notification.method, notification.payload)

        def enqueue(self, notification: FakeNotification) -> None:
            self._notification_queue.put(notification)

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        fake_client = BlockingFakeCodexClient(workspace_path=str(resolved_repo_root))
        writer = FakeHeadlessTurnWriter()

        def turn_handler(session, input_text: str, turn_counter: int) -> None:
            command = "git status --short"
            message_id = f"message-{turn_counter}"
            command_id = f"command-{turn_counter}"
            writer.handle_turn(session, input_text, turn_counter)

            def publish() -> None:
                fake_client.enqueue(
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {"type": "agentMessage", "id": message_id, "text": ""},
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/agentMessage/delta",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "itemId": message_id,
                            "delta": "Inspecting the workspace.",
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "agentMessage",
                                "id": message_id,
                                "text": "Inspecting the workspace.",
                            },
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="item/started",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "inProgress",
                            },
                        },
                    ),
                )
                time.sleep(0.2)
                fake_client.enqueue(
                    FakeNotification(
                        method="item/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turnId": f"turn-{turn_counter}",
                            "item": {
                                "type": "commandExecution",
                                "id": command_id,
                                "command": command,
                                "status": "completed",
                                "exitCode": 0,
                            },
                        },
                    ),
                )
                fake_client.enqueue(
                    FakeNotification(
                        method="turn/completed",
                        payload={
                            "threadId": session.thread_id,
                            "turn": {"id": f"turn-{turn_counter}", "status": "completed"},
                        },
                    ),
                )

            threading.Thread(target=publish, daemon=True).start()

        fake_client.turn_handler = turn_handler
        return CodexSessionManager(
            workspace_path=str(resolved_repo_root),
            config=config,
            client=fake_client,
        )

    def run_terminal_in_thread() -> None:
        observed["result"] = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )

    worker = threading.Thread(target=run_terminal_in_thread, daemon=True)
    worker.start()

    output = ""
    live_progress_seen = False
    for _ in range(60):
        time.sleep(0.02)
        output = strip_ansi(frontend.output_text())
        if "Inspecting the workspace." in output and "• Ran git status --short" in output:
            live_progress_seen = worker.is_alive()
            break

    assert "Executing the loop plan" in output
    assert live_progress_seen
    assert "Inspecting the workspace." in output
    assert "• Ran git status --short" in output
    assert "Turn completed: run-root spec" not in output

    worker.join(timeout=5)
    assert worker.is_alive() is False
    assert cast(TerminalRunResult, observed["result"]).mode == "completed"


def test_terminal_frontend_returns_failed_result_when_child_verification_fails(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    original_run_verification_command = headless_module._run_verification_command

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        result = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )
    finally:
        monkeypatch.undo()

    assert result.mode == "failed"
    assert "Verification failed: run-child-1 execute" in frontend.output_text()
    assert "Runtime: failed" in frontend.output_text()
    assert any(isinstance(event, FailureSummaryEvent) for event in frontend.events)

    child_run = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )
    assert child_run.status == "failed"

    step = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    ).step()
    assert step.kind == "review_prompt"
    assert step.pending_prompt is not None
    assert step.pending_prompt.prompt_kind == "recovery_review"
    assert step.pending_prompt.owner_run_id == "run-child-1"


def test_terminal_frontend_prompts_before_starting_new_mission_when_workspace_has_failed_mission(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    original_run_verification_command = headless_module._run_verification_command

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    next_frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    restarted = run_terminal(
        repo_root=repo_root,
        seed_prompt="find any bugs",
        frontend=next_frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert restarted.mode == "completed"
    assert "Input requested: Session conflict" not in next_frontend.output_text()
    assert "Reply: " not in next_frontend.output_text()
    assert "Resumed run-root" not in next_frontend.output_text()
    assert "Wrote intake summary" in next_frontend.output_text()


def test_terminal_frontend_reports_child_worktree_setup_failure_as_failed_runtime(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    original_create_child_worktree = headless_module.WorktreeCoordinator.create_child_worktree

    def fail_create_child_worktree(self, *, run_id: str, base_ref: str, target_branch: str, goal: str):
        raise WorktreeCreateFailed(
            "failed to create child worktree for 'run-child-1': git-crypt smudge failed",
        )

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(
        headless_module.WorktreeCoordinator,
        "create_child_worktree",
        fail_create_child_worktree,
    )

    try:
        result = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            use_fake_session_manager=True,
        )
    finally:
        monkeypatch.setattr(
            headless_module.WorktreeCoordinator,
            "create_child_worktree",
            original_create_child_worktree,
        )
        monkeypatch.undo()

    assert result.mode == "failed"
    assert "Worktree setup failed: run-child-1 execute" in frontend.output_text()
    assert "Runtime: failed" in frontend.output_text()

    child_run = Run.model_validate_json(
        (repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json").read_text(encoding="utf-8")
    )
    assert child_run.status == "failed"

    step = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=lambda resolved_repo_root, config: build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    ).step()
    assert step.kind == "review_prompt"
    assert step.pending_prompt is not None
    assert step.pending_prompt.prompt_kind == "recovery_review"
    assert step.pending_prompt.owner_run_id == "run-child-1"


def test_terminal_frontend_bootstraps_empty_repo_before_first_loop(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path, with_commit=False)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())

    result = run_terminal(
        repo_root=repo_root,
        seed_prompt="find and fix typos",
        frontend=frontend,
        approve_all=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert "Launched 1 Ralph loop" in frontend.output_text()
    assert subprocess.run(
        ["git", "rev-parse", "--verify", "HEAD"],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    ).returncode == 0


def test_terminal_frontend_can_resume_failed_mission_through_recovery(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    original_run_verification_command = headless_module._run_verification_command
    writer = FakeHeadlessTurnWriter()

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    writer.audit_turns = 1
    resumed_frontend = ScriptedTerminalFrontend(inputs=["replace"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=resumed_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "completed"
    assert "Recovery review" in resumed_frontend.output_text()
    assert "Run: run-child-1" in resumed_frontend.output_text()
    assert "Session completed: run-root" in resumed_frontend.output_text()


def test_terminal_frontend_resume_can_pause_at_recovery_review_without_reporting_child_as_root(
    tmp_path: Path,
) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs())
    original_run_verification_command = headless_module._run_verification_command
    writer = FakeHeadlessTurnWriter()

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=frontend,
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    paused_frontend = ScriptedTerminalFrontend(inputs=["pause"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=paused_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "running"
    assert resumed.root_run_id == "run-root"
    assert "Recovery review" in paused_frontend.output_text()
    assert "Run: run-child-1" in paused_frontend.output_text()


def test_terminal_frontend_reconciles_legacy_failed_runtime_state_on_resume(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    writer = FakeHeadlessTurnWriter()
    original_run_verification_command = headless_module._run_verification_command

    def session_manager_factory(resolved_repo_root: Path, config: RalphceptionConfig) -> CodexSessionManager:
        return build_fake_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
            turn_handler=writer.handle_turn,
        )

    def failing_run_verification_command(service, verification_id, index, command, cwd, config):
        if verification_id.startswith("run-child-1-child_run"):
            return service.shape_command_result(
                verification_id=verification_id,
                command_index=index,
                command=command,
                cwd=cwd,
                exit_code=1,
                duration_ms=1,
                stdout="",
                stderr="forced verification failure",
            )
        return original_run_verification_command(service, verification_id, index, command, cwd, config)

    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(headless_module, "_run_verification_command", failing_run_verification_command)

    try:
        failed = run_terminal(
            repo_root=repo_root,
            seed_prompt="find any bugs",
            frontend=ScriptedTerminalFrontend(inputs=_seeded_follow_up_inputs()),
            approve_all=True,
            session_manager_factory=session_manager_factory,
        )
    finally:
        monkeypatch.undo()

    assert failed.mode == "failed"

    root_run_path = repo_root / ".ralphception" / "runs" / "run-root" / "run.json"
    child_run_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json"
    headless_state_path = repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json"

    root_run = Run.model_validate_json(root_run_path.read_text(encoding="utf-8"))
    child_run = Run.model_validate_json(child_run_path.read_text(encoding="utf-8"))
    headless_state = cast(dict[str, object], json.loads(headless_state_path.read_text(encoding="utf-8")))

    root_run_path.write_text(
        root_run.model_copy(update={"status": "failed"}).model_dump_json(indent=2),
        encoding="utf-8",
    )
    child_run_path.write_text(
        child_run.model_copy(update={"status": "running"}).model_dump_json(indent=2),
        encoding="utf-8",
    )
    headless_state["current_stage"] = "failed"
    headless_state["terminal_outcome"] = "failed"
    headless_state_path.write_text(json.dumps(headless_state, indent=2), encoding="utf-8")

    writer.audit_turns = 1
    resumed_frontend = ScriptedTerminalFrontend(inputs=["replace"])
    resumed = run_terminal(
        repo_root=repo_root,
        frontend=resumed_frontend,
        approve_all=True,
        session_manager_factory=session_manager_factory,
        resume=True,
    )

    assert resumed.mode == "completed"
    assert "Recovery review" in resumed_frontend.output_text()
    assert "Run: run-child-1" in resumed_frontend.output_text()
    assert "Session completed: run-root" in resumed_frontend.output_text()


def make_git_repo(tmp_path: Path, *, with_commit: bool = True) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    run_git(repo_root, "config", "user.name", "Test User")
    run_git(repo_root, "config", "user.email", "test@example.com")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    if with_commit:
        run_git(repo_root, "add", "README.md")
        run_git(
            repo_root,
            "-c",
            "commit.gpgsign=false",
            "commit",
            "-m",
            "initial",
        )
    return repo_root


def _prepare_resumable_runtime_workspace(repo_root: Path) -> None:
    now = datetime.now(timezone.utc)
    runtime_root = repo_root / ".ralphception" / "runs"
    root_run_path = runtime_root / "run-root"
    child_run_path = runtime_root / "run-child-1"
    root_run_path.mkdir(parents=True, exist_ok=True)
    child_run_path.mkdir(parents=True, exist_ok=True)

    root_run = Run(
        run_id="run-root",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Existing interrupted task",
        status="running",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id="run-root",
            codex_thread_id="thread-root",
            codex_session_id="session-root",
            workspace_path=str(repo_root),
            resumable=True,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    child_run = Run(
        run_id="run-child-1",
        parent_run_id="run-root",
        supersedes_run_id=None,
        goal="Investigate the repository for typos",
        status="running",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id="run-child-1",
            codex_thread_id="thread-child-1",
            codex_session_id="session-child-1",
            workspace_path=str(repo_root),
            resumable=True,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    (root_run_path / "run.json").write_text(root_run.model_dump_json(indent=2), encoding="utf-8")
    (child_run_path / "run.json").write_text(child_run.model_dump_json(indent=2), encoding="utf-8")
    (root_run_path / "headless-state.json").write_text(json.dumps({"current_stage": "execute"}), encoding="utf-8")
    (child_run_path / "headless-state.json").write_text(json.dumps({"current_stage": "execute"}), encoding="utf-8")
    (repo_root / ".ralphception" / "interactive-session.json").write_text(
        json.dumps(
            {
                "root_run_id": "run-root",
                "active_run_id": "run-child-1",
                "resumable": True,
                "blocking_surface_kind": "review",
                "updated_at": now.isoformat(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )


def run_git(repo_root: Path, *args: str) -> None:
    import subprocess

    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
