from __future__ import annotations

import subprocess
from collections.abc import Sequence
from pathlib import Path

import ralphception.headless as headless_module
import ralphception.runtime.inline_shell as inline_shell_module
from ralphception.app import resolve_runtime_view, run_app
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CurrentBlockerStateEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    FrontendEvent,
    LiveStatusEvent,
    LoopLaunchEvent,
    MilestoneTranscriptLineEvent,
    LoopCompletionEvent,
    ReasoningSectionBreakEvent,
    ReasoningFinalEvent,
    ReasoningSummaryDeltaEvent,
)
from ralphception.runtime.inline_shell import InlineShellFrontend
from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.runtime.terminal import TerminalFrontend, TerminalRunResult, run_terminal
from ralphception.codex_tui.styled_text import strip_ansi

_STARTUP_CONTEXT_REPLY = "focus on docs and comments only"
_STARTUP_BOUNDARY_REPLY = (
    "completion means the first execution slice is verified, stays in scope, and is ready for review"
)


def _seeded_follow_up_inputs(*answers: str) -> list[str]:
    if answers and "typo" in answers[0].lower():
        return [
            *answers,
            "docs and comments only",
            "spelling only, and completion means the docs/comments typo pass is clean",
        ]
    return [*answers, _STARTUP_CONTEXT_REPLY, _STARTUP_BOUNDARY_REPLY]


class ScriptedInlineShell(TerminalFrontend):
    def __init__(self, *, inputs: Sequence[str] = ()) -> None:
        self._inputs = list(inputs)
        super().__init__(input_func=self.input_func, write_func=lambda _text: None)

    def input_func(self, prompt: str) -> str:
        self._output_lines.append(prompt)
        if not self._inputs:
            raise RuntimeError(f"no scripted input available for prompt {prompt!r}")
        return self._inputs.pop(0)


def test_inline_shell_keeps_live_status_separate_from_durable_milestones() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(LiveStatusEvent(text="Loop run-child-1 inspecting docs"))
    frontend.emit_event(MilestoneTranscriptLineEvent(message="Loop run-child-1 completed: 4 typo candidates found"))

    assert frontend.live_status == "Loop run-child-1 inspecting docs"
    assert "Loop run-child-1 completed: 4 typo candidates found" in frontend.output_text()
    assert "Loop run-child-1 inspecting docs" not in frontend.output_text()


def test_inline_shell_writes_explicit_milestone_transcript_line_event() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(MilestoneTranscriptLineEvent(message="Next step: verify the plan output"))

    assert strip_ansi(frontend.output_text()) == "• Next step: verify the plan output"


def test_inline_shell_only_commits_settled_agent_messages_to_scrollback() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    frontend.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting the workspace."))
    frontend.emit_event(AssistantFinalEvent(item_id="message-1", text="Inspecting the workspace."))
    frontend.emit_event(ReasoningSectionBreakEvent(item_id="reasoning-1", summary_index=1))
    frontend.emit_event(ReasoningSummaryDeltaEvent(item_id="reasoning-1", text="Thinking", summary_index=0))
    frontend.emit_event(ReasoningFinalEvent(item_id="reasoning-1", text="Thinking through the task."))

    assert strip_ansi(frontend.output_text()).splitlines() == [
        "• Inspecting the workspace.",
    ]


def test_inline_shell_appends_scrollback_milestones_in_order() -> None:
    frontend = InlineShellFrontend(write_func=lambda _text: None)

    frontend.emit_event(MilestoneTranscriptLineEvent(message="Wrote intake summary"))
    frontend.emit_event(MilestoneTranscriptLineEvent(message="Wrote PRD"))
    frontend.emit_event(MilestoneTranscriptLineEvent(message="Launched run-child-1"))
    frontend.emit_event(LoopCompletionEvent(loop_label="run-child-1", message="Completed run-child-1"))

    assert frontend.output_text().splitlines() == [
        "Wrote intake summary",
        "Wrote PRD",
        "Launched run-child-1",
        "Completed run-child-1",
    ]


def test_inline_shell_tracks_minimum_phase1_runtime_labels() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(CurrentTaskLabelEvent(label="Fix the docs typos"))
    frontend.emit_event(CurrentPlanNodeLabelEvent(label="Execute the approved plan"))
    frontend.emit_event(CurrentLoopLabelEvent(label="run-child-1"))
    frontend.emit_event(CurrentBlockerStateEvent(label="Waiting for approval"))
    frontend.emit_event(CurrentWaitingStateEvent(label="Waiting on child run output"))

    assert frontend.current_task_label == "Fix the docs typos"
    assert frontend.current_plan_node_label == "Execute the approved plan"
    assert frontend.current_loop_label == "run-child-1"
    assert frontend.current_blocker_state == "Waiting for your response"
    assert frontend.current_waiting_state == "Waiting on child run output"
    assert frontend.output_text() == ""


def test_inline_shell_rewrites_stage_milestones_and_suppresses_turn_noise() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(FrontendEvent(message="Stage: execute", kind="stage.started", stage_kind="execute"))
    frontend.emit_event(FrontendEvent(message="Child run created: run-child-1"))
    frontend.emit_event(FrontendEvent(message="Turn started: run-child-1 execute attempt 1", kind="turn.started"))
    frontend.emit_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched run-child-1"))
    frontend.emit_event(FrontendEvent(message="Turn completed: run-child-1 execute", kind="turn.completed"))

    assert strip_ansi(frontend.output_text()).splitlines() == [
        "• Executing the loop plan",
        "• Launched run-child-1",
    ]


def test_inline_shell_can_clear_transitional_runtime_labels() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(CurrentLoopLabelEvent(label="run-child-1"))
    frontend.emit_event(CurrentBlockerStateEvent(label="Waiting for approval"))
    frontend.emit_event(CurrentWaitingStateEvent(label="Waiting on child run output"))
    frontend.emit_event(CurrentLoopLabelEvent.clear())
    frontend.emit_event(CurrentBlockerStateEvent.clear())
    frontend.emit_event(CurrentWaitingStateEvent.clear())

    assert frontend.current_loop_label is None
    assert frontend.current_blocker_state is None
    assert frontend.current_waiting_state is None
    assert frontend.output_text() == ""


def test_inline_shell_dedupes_repeated_waiting_state_messages() -> None:
    frontend = ScriptedInlineShell()

    frontend.emit_event(CurrentWaitingStateEvent(label="Waiting on child run output"))
    frontend.emit_event(CurrentWaitingStateEvent(label="Waiting on child run output"))
    frontend.emit_event(CurrentWaitingStateEvent.clear())
    frontend.emit_event(CurrentWaitingStateEvent(label="Waiting on verification"))

    assert frontend.output_text() == ""


def test_inline_shell_preserves_overlong_command_entries_when_width_allows() -> None:
    frontend = ScriptedInlineShell()
    long_command = (
        "mkdir -p .ralphception/runs/run-child-1 && cat > "
        ".ralphception/runs/run-child-1/handoff.json <<'JSON' { "
        "\"summary\": \"Fixed obvious typos in README.md\", "
        "\"touched_paths\": [\"README.md\", \".ralphception/runs/run-child-1/handoff.json\"] } JSON"
    )

    frontend.emit_event(CommandBeginEvent(command=long_command))
    frontend.emit_event(CommandEndEvent(command=long_command, exit_code=0))

    lines = strip_ansi(frontend.output_text()).splitlines()
    assert len(lines) == 1
    assert lines[0].startswith("• Ran mkdir -p .ralphception/runs/run-child-1")
    assert "..." not in lines[0]
    assert long_command in frontend.output_text()


def test_inline_shell_preserves_explicit_waiting_state(tmp_path: Path) -> None:
    frontend = ScriptedInlineShell(inputs=_seeded_follow_up_inputs("look for typos"))

    run_terminal(
        repo_root=make_git_repo(tmp_path),
        seed_prompt="look for typos",
        frontend=frontend,
        use_fake_session_manager=True,
        approve_all=True,
    )

    text = frontend.output_text()

    assert any(event.kind == "runtime.current_waiting_state" for event in frontend.events) or "Waiting on" in text or "Blocked" in text or "Next step" in text
    assert any(event.kind == "runtime.live_status" for event in frontend.events)


def test_resolve_runtime_view_exposes_single_inline_entrypoint_surface(tmp_path: Path) -> None:
    launch = resolve_runtime_view(make_git_repo(tmp_path))

    assert launch.interactive_frontend is not None
    assert not hasattr(launch, "frontend_kind")
    assert not hasattr(launch, "tui_app")


def test_run_app_uses_codex_tui_shell_by_default(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    called: dict[str, object] = {}

    def fake_run_codex_tui_shell(**kwargs: object) -> TerminalRunResult:
        called.update(kwargs)
        return TerminalRunResult(mode="completed")

    monkeypatch.chdir(repo_root)
    monkeypatch.delenv("TMUX", raising=False)
    monkeypatch.setattr("ralphception.app.run_codex_tui_shell", fake_run_codex_tui_shell)

    run_app()

    assert called == {
        "repo_root": repo_root,
    }


def test_run_app_uses_same_codex_tui_shell_inside_tmux(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    called: dict[str, object] = {}

    def fake_run_codex_tui_shell(**kwargs: object) -> TerminalRunResult:
        called.update(kwargs)
        return TerminalRunResult(mode="completed")

    monkeypatch.chdir(repo_root)
    monkeypatch.setenv("TMUX", "/tmp/tmux-1000/default,123,0")
    monkeypatch.setattr("ralphception.app.run_codex_tui_shell", fake_run_codex_tui_shell)

    run_app()

    assert called == {
        "repo_root": repo_root,
    }


def test_resolved_inline_frontend_run_preserves_bound_runtime_context(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    called: dict[str, object] = {}

    def fake_session_manager_factory(repo_root: Path, config) -> object:
        return object()

    def fake_run_inline_shell(**kwargs: object) -> TerminalRunResult:
        called.update(kwargs)
        return TerminalRunResult(mode="completed")

    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(inline_shell_module, "run_inline_shell", fake_run_inline_shell)

    launch = resolve_runtime_view(repo_root, session_manager_factory=fake_session_manager_factory)

    launch.interactive_frontend.run()

    assert called["repo_root"] == repo_root
    assert called["session_manager_factory"] is fake_session_manager_factory


def test_inline_shell_uses_public_supervisor_resume_and_prompt_apis(tmp_path: Path, monkeypatch) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = ScriptedInlineShell(inputs=["resume reply"])
    observed: list[str] = []
    run_count = {"count": 0}

    def fake_request_resume_launch(self: RuntimeSupervisor) -> None:
        observed.append("request_resume_launch")

    def fake_current_pending_prompt(self: RuntimeSupervisor):
        observed.append("current_pending_prompt")
        return type(
            "Prompt",
            (),
            {
                "prompt_kind": "startup_prompt",
                "thread_id": "run-root",
                "question": "Start first task",
            },
        )()

    def fake_resolve_pending_prompt(self: RuntimeSupervisor, *, thread_id: str, user_text: str):
        observed.append(f"resolve_pending_prompt:{thread_id}:{user_text}")
        return type("Resolution", (), {"kind": "resolved", "action": "bootstrap"})()

    def fake_run(self: RuntimeSupervisor, *, frontend=None):
        run_count["count"] += 1
        if run_count["count"] == 1:
            return headless_module.HeadlessRunResult(
                mode="startup",
                actions=(),
                authoritative_repo_root=str(self.repo_root),
            )
        return headless_module.HeadlessRunResult(
            mode="completed",
            actions=(),
            root_run_id="run-root",
            authoritative_repo_root=str(self.repo_root),
        )

    monkeypatch.setattr(RuntimeSupervisor, "request_resume_launch", fake_request_resume_launch)
    monkeypatch.setattr(RuntimeSupervisor, "current_pending_prompt", fake_current_pending_prompt)
    monkeypatch.setattr(RuntimeSupervisor, "resolve_pending_prompt", fake_resolve_pending_prompt)
    monkeypatch.setattr(RuntimeSupervisor, "run", fake_run)

    result = run_terminal(
        repo_root=repo_root,
        frontend=frontend,
        resume=True,
        use_fake_session_manager=True,
    )

    assert result.mode == "completed"
    assert observed == [
        "request_resume_launch",
        "current_pending_prompt",
        "resolve_pending_prompt:run-root:resume reply",
    ]


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    subprocess.run(
        ["git", "init", "-b", "main"],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(
        ["git", "add", "README.md"],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    return repo_root
