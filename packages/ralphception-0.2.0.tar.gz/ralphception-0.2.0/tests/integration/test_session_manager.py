import pytest

from ralphception.models.session import SessionFailureKind
from ralphception.runtime.prompt_state import PendingPrompt, STARTUP_INTAKE_ANSWERS_KEY
from ralphception.testing.fakes import (
    FakeCodexClient,
    FakeExpiredSession,
    build_fake_headless_session_manager,
    FakeModelUnavailableError,
    FakeProtocolError,
    FakeStartupFailure,
    FakeTransportError,
    build_fake_session_manager,
)


def test_manager_starts_client_lazily_and_shuts_it_down() -> None:
    manager = build_fake_session_manager()
    assert isinstance(manager.client, FakeCodexClient)

    assert manager.client.started is False
    assert manager.client.initialized is False

    manager.start_session(run_id="run-1")

    assert manager.client.started is True
    assert manager.client.initialized is True

    manager.close()

    assert manager.client.closed is True


def test_start_session_normalizes_run_started_event() -> None:
    manager = build_fake_session_manager()

    event = manager.start_session(run_id="run-1")
    session_ref = manager.get_session_ref("run-1")

    assert event.event_type == "run.started"
    assert event.run_id == "run-1"
    assert event.payload["goal"] == "Run run-1"
    assert event.payload["parent_run_id"] is None
    assert session_ref is not None
    assert session_ref.run_id == "run-1"
    assert session_ref.codex_thread_id == "thread-1"


def test_resume_session_reuses_stored_thread_and_normalizes_run_started_event() -> None:
    manager = build_fake_session_manager()
    assert isinstance(manager.client, FakeCodexClient)
    manager.start_session(run_id="run-1")

    event = manager.resume_session(run_id="run-1")

    assert event.event_type == "run.started"
    assert event.run_id == "run-1"
    assert manager.client.resumed_thread_ids == ["thread-1"]


def test_run_turn_streams_normalized_raw_events_and_abort_session_interrupts_active_turn() -> None:
    manager = build_fake_session_manager()
    assert isinstance(manager.client, FakeCodexClient)
    manager.start_session(run_id="run-1")

    turn_ref = manager.run_turn(run_id="run-1", input_text="inspect tests")

    assert turn_ref.turn_id == "turn-1"
    assert manager.active_turn_id("run-1") == "turn-1"

    raw_events = manager.stream_raw_events(run_id="run-1", until_methods="turn/completed")

    assert [(event.method, event.thread_id, event.turn_id) for event in raw_events] == [
        ("turn/started", "thread-1", "turn-1"),
        ("turn/completed", "thread-1", "turn-1"),
    ]

    manager.run_turn(run_id="run-1", input_text="abort this turn")
    manager.abort_session(run_id="run-1")

    assert manager.client.interruptions == [("thread-1", "turn-2")]
    assert manager.active_turn_id("run-1") is None


def test_stream_raw_events_preserves_other_run_notifications_until_their_owner_reads_them() -> None:
    manager = build_fake_session_manager()
    assert isinstance(manager.client, FakeCodexClient)
    manager.start_session(run_id="run-1")
    manager.start_session(run_id="run-2")

    manager.run_turn(run_id="run-2", input_text="inspect sibling run")
    manager.run_turn(run_id="run-1", input_text="inspect active run")

    run_1_events = manager.stream_raw_events(run_id="run-1", until_methods="turn/completed")
    run_2_events = manager.stream_raw_events(run_id="run-2", until_methods="turn/completed")

    assert [(event.method, event.thread_id, event.turn_id) for event in run_1_events] == [
        ("turn/started", "thread-1", "turn-2"),
        ("turn/completed", "thread-1", "turn-2"),
    ]
    assert [(event.method, event.thread_id, event.turn_id) for event in run_2_events] == [
        ("turn/started", "thread-2", "turn-1"),
        ("turn/completed", "thread-2", "turn-1"),
    ]


def test_normalize_event_maps_turn_lifecycle_methods_to_engine_events() -> None:
    manager = build_fake_session_manager()
    manager.start_session(run_id="run-1")
    manager.run_turn(run_id="run-1", input_text="inspect tests")
    raw_events = manager.stream_raw_events(run_id="run-1", until_methods="turn/completed")

    started = manager.normalize_event(
        raw_events[0],
        run_id="run-1",
        stage_id="stage-1",
        task_id="task-1",
    )
    completed = manager.normalize_event(
        raw_events[1],
        run_id="run-1",
        stage_id="stage-1",
        task_id="task-1",
    )

    assert started is not None
    assert completed is not None
    assert started.event_type == "task.started"
    assert started.payload["task_kind"] == "turn"
    assert completed.event_type == "task.completed"
    assert completed.payload["task_kind"] == "turn"


def test_spawn_agent_is_agent_only_and_child_runs_use_start_session() -> None:
    manager = build_fake_session_manager()
    manager.start_session(run_id="run-1")

    agent_ref = manager.spawn_agent(task_id="task-1", goal="inspect tests")
    child_started = manager.start_session(run_id="run-child-1")

    assert agent_ref.parent_task_id == "task-1"
    assert agent_ref.parent_run_id == "run-1"
    assert agent_ref.codex_session_ref.run_id.startswith("agent:")
    assert child_started.event_type == "run.started"
    assert child_started.run_id == "run-child-1"


def test_session_manager_maps_all_required_failures() -> None:
    manager = build_fake_session_manager()

    assert manager.normalize_error(FakeStartupFailure()) == SessionFailureKind.STARTUP_FAILED.value
    assert manager.normalize_error(FakeExpiredSession()) == SessionFailureKind.SESSION_EXPIRED.value
    assert manager.normalize_error(FakeTransportError()) == SessionFailureKind.TRANSPORT_ERROR.value
    assert manager.normalize_error(FakeProtocolError()) == SessionFailureKind.PROTOCOL_ERROR.value
    assert (
        manager.normalize_error(FakeModelUnavailableError())
        == SessionFailureKind.MODEL_UNAVAILABLE.value
    )


def test_start_session_raises_normalized_model_unavailable_error() -> None:
    manager = build_fake_session_manager(available_models=("gpt-5.5",))

    with pytest.raises(FakeModelUnavailableError):
        manager.start_session(run_id="run-1")


def test_fake_headless_session_manager_resolves_startup_prompt_with_structured_clarification() -> None:
    manager = build_fake_headless_session_manager()

    resolved = manager.resolve_prompt_reply(
        prompt=PendingPrompt(
            thread_id="run-root",
            owner_run_id="run-root",
            prompt_id="prompt-run-root-startup",
            prompt_kind="startup_prompt",
            title="Start first task",
            question="Describe what you want Ralphception to work on in this workspace.",
            allowed_actions=("bootstrap",),
            context={},
        ),
        user_text="fix typos",
    )

    assert resolved == {
        "kind": "clarify",
        "clarifying_question": "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?",
        "confidence": 0.75,
    }


def test_fake_headless_session_manager_resolves_startup_prompt_with_structured_summary() -> None:
    manager = build_fake_headless_session_manager()

    resolved = manager.resolve_prompt_reply(
        prompt=PendingPrompt(
            thread_id="run-root",
            owner_run_id="run-root",
            prompt_id="prompt-run-root-startup",
            prompt_kind="startup_prompt",
            title="Clarify constraints",
            question="For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?",
            allowed_actions=("bootstrap",),
            context={STARTUP_INTAKE_ANSWERS_KEY: ["fix typos", "README only"]},
        ),
        user_text="Spelling only, and completion means the README is typo-free.",
    )

    assert resolved == {
        "kind": "resolved",
        "action": "bootstrap",
        "intake_summary": "fix typos\n\nAdditional context:\n- README only\n- Spelling only, and completion means the README is typo-free.",
        "confidence": 0.9,
    }
