from __future__ import annotations

import subprocess
from pathlib import Path
from typing import cast

from ralphception.actor_runtime.scheduler_actor import SchedulerActor
from ralphception.actor_runtime.worker_actor import WorkerActor
from ralphception.models.todos import TodoNode


def test_worker_actor_starts_parallel_ready_batches_in_separate_worktrees(tmp_path: Path) -> None:
    repo_root = tmp_path / "parallel-repo"
    repo_root.mkdir()
    _init_git_repo_with_commit(repo_root)
    scheduler = SchedulerActor(max_parallel_children=2)

    assignments = scheduler.plan_assignments(
        todos=[
            TodoNode(
                todo_id="todo-1",
                title="Implement parser artifact",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-1",
                scope_hints=["src/parser.py"],
            ),
            TodoNode(
                todo_id="todo-2",
                title="Add parser regression test",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-2",
                scope_hints=["tests/test_parser.py"],
            ),
        ],
        active_workers=[],
    )
    actor = WorkerActor(repo_root=repo_root, base_ref="main", target_branch="main")

    started = [actor.start(assignment) for assignment in assignments]

    assert len(started) == 2
    assert len({assignment.worktree_path for assignment in started}) == 2
    assert all(assignment.worktree_path is not None for assignment in started)
    assert all(Path(cast(str, assignment.worktree_path)).exists() for assignment in started)
    assert sorted(path.name for path in (repo_root / ".worktrees").iterdir()) == [
        "run-worker-1",
        "run-worker-2",
    ]


def _init_git_repo_with_commit(repo_root: Path) -> None:
    subprocess.run(["git", "init", "-b", "main"], check=True, cwd=repo_root, capture_output=True, text=True)
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(["git", "add", "README.md"], check=True, cwd=repo_root, capture_output=True, text=True)
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
