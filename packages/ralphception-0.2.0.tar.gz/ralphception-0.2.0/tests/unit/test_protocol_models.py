import pytest
from pydantic import ValidationError

from ralphception.protocol.actions import ShellAction
from ralphception.protocol.events import RuntimeEvent


def test_review_requested_event_validates_required_fields() -> None:
    event = RuntimeEvent.model_validate(
        {
            "kind": "review_requested",
            "thread_id": "run-root",
            "review_kind": "execution_bundle",
            "title": "Execution bundle v2",
            "summary": "Execution bundle v2 is waiting for approval.",
            "actions": ["approve", "reject"],
        }
    )

    assert event.kind == "review_requested"
    assert event.review_kind == "execution_bundle"


def test_send_user_message_action_rejects_blank_message() -> None:
    with pytest.raises(ValidationError):
        ShellAction.model_validate(
            {
                "kind": "send_user_message",
                "thread_id": "run-root",
                "text": "   ",
            }
        )
