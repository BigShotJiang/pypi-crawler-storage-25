from __future__ import annotations

from pathlib import Path


def test_build_startup_resolution_prompt_includes_skill_and_repo_wide_assumption() -> None:
    from ralphception.runtime.startup_llm import build_startup_resolution_prompt

    prompt = build_startup_resolution_prompt(
        repo_root=Path("/tmp/work"),
        repo_root_label="~/code/ralphception",
        prior_answers=("fix typos",),
        latest_user_text="README only",
        source_repos=("/tmp/source-a",),
    )

    assert "# Ralph Startup Intake" in prompt
    assert "## Anti-Pattern: \"This Is Too Simple To Need Intake\"" in prompt
    assert "Assume full read/write access to the entire repository by default." in prompt
    assert "Assume referenced outside folders supplied with the task are also in scope by default." in prompt
    assert "Do not ask the user for permission to inspect files in the repository." in prompt
    assert "Do not ask the user to confirm repo-wide scope unless they explicitly narrowed it or there is a concrete risk boundary." in prompt
    assert "Do not announce bundled skill guidance in the transcript, command output, or final answer." in prompt
    assert "This startup stage is a compressed brainstorming loop, not a single permission check." in prompt
    assert "gather at least two distinct follow-up answers before resolving" in prompt
    assert "fix typos" in prompt
    assert "README only" in prompt
    assert "/tmp/source-a" in prompt


def test_build_startup_resolution_prompt_requires_a_follow_up_on_the_first_human_turn() -> None:
    from ralphception.runtime.startup_llm import build_startup_resolution_prompt

    prompt = build_startup_resolution_prompt(
        repo_root=Path("/tmp/work"),
        repo_root_label="~/code/ralphception",
        prior_answers=(),
        latest_user_text="fix typos",
        source_repos=(),
    )

    assert "This is the first human startup turn after the user's initial task message." in prompt
    assert "Ask exactly one Socratic follow-up question on this turn." in prompt
    assert "Keep the question short, concrete, and repo-task-shaped." in prompt
    assert "Do not return `resolved` yet." in prompt


def test_parse_startup_resolution_extracts_clarify_payload() -> None:
    from ralphception.runtime.startup_llm import parse_startup_resolution

    decision = parse_startup_resolution(
        """
        some preface
        RALPH_STARTUP_DECISION_START
        {"kind":"clarify","question":"Which files are in scope?"}
        RALPH_STARTUP_DECISION_END
        """
    )

    assert decision is not None
    assert decision.kind == "clarify"
    assert decision.question == "Which files are in scope?"
    assert decision.intake_summary is None


def test_parse_startup_resolution_extracts_resolved_payload() -> None:
    from ralphception.runtime.startup_llm import parse_startup_resolution

    decision = parse_startup_resolution(
        """
        RALPH_STARTUP_DECISION_START
        {"kind":"resolved","intake_summary":"Fix typos in README only."}
        RALPH_STARTUP_DECISION_END
        """
    )

    assert decision is not None
    assert decision.kind == "resolved"
    assert decision.question is None
    assert decision.intake_summary == "Fix typos in README only."


def test_normalize_startup_clarifying_question_rewrites_scope_question_for_typo_pass() -> None:
    from ralphception.runtime.startup_llm import normalize_startup_clarifying_question

    question = normalize_startup_clarifying_question(
        question=(
            "For this typo pass, which files or areas should I treat as in scope? "
            "For example: README only, docs and comments, or the whole repo."
        ),
        latest_user_text="fix all of the typos in the repo",
        prior_answers=(),
    )

    assert question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )
