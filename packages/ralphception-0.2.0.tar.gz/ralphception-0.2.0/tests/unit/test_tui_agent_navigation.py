from __future__ import annotations

from ralphception.tui.agent_navigation import AgentNavigationDirection, AgentNavigationState


def test_agent_navigation_preserves_first_seen_order_when_entries_update() -> None:
    state = AgentNavigationState()

    state.upsert("run-root", nickname=None, role=None, is_closed=False)
    state.upsert("run-child-1", nickname="Worker 1", role="worker", is_closed=False)
    state.upsert("run-child-2", nickname="Worker 2", role="worker", is_closed=False)
    state.upsert("run-child-1", nickname="Reviewer", role="reviewer", is_closed=False)

    assert state.ordered_thread_ids() == ["run-root", "run-child-1", "run-child-2"]


def test_agent_navigation_wraps_next_and_previous_in_spawn_order() -> None:
    state = AgentNavigationState()
    state.upsert("run-root", nickname=None, role=None, is_closed=False)
    state.upsert("run-child-1", nickname="Worker 1", role="worker", is_closed=False)
    state.upsert("run-child-2", nickname="Worker 2", role="worker", is_closed=False)

    assert state.adjacent_thread_id("run-root", AgentNavigationDirection.NEXT) == "run-child-1"
    assert state.adjacent_thread_id("run-child-2", AgentNavigationDirection.NEXT) == "run-root"
    assert state.adjacent_thread_id("run-root", AgentNavigationDirection.PREVIOUS) == "run-child-2"


def test_agent_navigation_formats_active_label_like_codex() -> None:
    state = AgentNavigationState()
    state.upsert("run-root", nickname=None, role=None, is_closed=False)
    assert state.active_agent_label("run-root", primary_thread_id="run-root") is None

    state.upsert("run-child-1", nickname="Worker 1", role="worker", is_closed=False)

    assert state.active_agent_label("run-root", primary_thread_id="run-root") == "Main [default]"
    assert state.active_agent_label("run-child-1", primary_thread_id="run-root") == "Worker 1 [worker]"
