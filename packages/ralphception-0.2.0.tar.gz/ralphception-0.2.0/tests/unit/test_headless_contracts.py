from __future__ import annotations

import json
from pathlib import Path
import subprocess

from pydantic import ValidationError
import pytest

from ralphception.headless import (
    ExecuteContract,
    HeadlessMissionSupervisor,
    _format_turn_progress_event,
    _load_plan_contract,
    _resolve_child_final_commit_message,
)
from ralphception.git.merge import MergeCoordinator
from ralphception.models.worktree import WorktreeHandoff
from ralphception.runtime.loop_planner import LoopDefinition
from ralphception.runtime.frontends import (
    BackgroundWaitBeginEvent,
    BlockerPromptEvent,
    CurrentBlockerStateEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    LiveStatusEvent,
    MilestoneTranscriptLineEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    PlanUpdatedEvent,
    ReviewRequestedEvent,
    RuntimeStatusUpdatedEvent,
)
from ralphception.runtime.interactive_session import load_interactive_session_state
from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt
from ralphception.runtime.supervisor import _emit_pending_prompt
from ralphception.testing.fakes import build_fake_headless_session_manager


class _PassiveFrontend:
    def __init__(self) -> None:
        self.events: list[object] = []
        self.messages: list[str] = []

    def emit_event(self, event) -> None:
        self.events.append(event)
        self.messages.append(event.message)

    def emit_status(self, step) -> None:
        self.messages.append(f"Runtime: {step.kind}")

    def finish(self, step) -> None:
        self.messages.append(f"Finished: {step.kind}")


def test_load_plan_contract_ignores_placeholder_verification_commands(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Find a bug",
                "verification_commands": [
                    "uv run pytest tests/unit/test_runtime_supervisor.py -q",
                    "uv run pytest <targeted test file or test node> -q",
                    "uv run pytest <updated targeted tests> -q",
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.execution_goal == "Find a bug"
    assert contract.verification_commands == [
        "uv run pytest tests/unit/test_runtime_supervisor.py -q",
    ]


def test_load_plan_contract_parses_todos_commit_intents_and_execution_policy(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['uv run pytest tests/unit/test_runtime_supervisor.py -q'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    }
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 3,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert [todo.todo_id for todo in contract.todos] == ["todo-1"]
    assert [intent.intent_id for intent in contract.commit_intents] == ["intent-1"]
    assert contract.execution_policy.max_parallel_children == 3


def test_load_plan_contract_normalizes_verbose_commit_intent_subject(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Fix typos across the repository.",
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": (
                            "feat: Goal: fix typos across the repository. Scope: the whole repo. "
                            "Constraints: keep the work focused on typo cleanup."
                        ),
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    }
                ],
                "todos": ["Fix typos across the repository."],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.commit_intents[0].message == "feat: fix typos across the repository"


def test_load_plan_contract_normalizes_richer_planner_schema(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Document the system architecture.",
                "verification_commands": [
                    {
                        "command": "nix fmt",
                        "purpose": "Keep formatting consistent.",
                    },
                    {
                        "command": "nix flake check --all-systems",
                        "purpose": "Verify the flake.",
                    },
                ],
                "todos": [
                    {
                        "id": "baseline-architecture-inventory",
                        "title": "Inventory the current architecture",
                        "files": ["flake.nix", "README.md"],
                        "commands": ["rg -n architecture ."],
                        "verification_gate": ["Confirm the host list matches the flake outputs."],
                    },
                    {
                        "id": "document-modules-and-package-wiring",
                        "title": "Document module and package wiring",
                        "files": ["docs/architecture.md"],
                        "commands": ["sed -n '1,200p' docs/architecture.md"],
                        "verification_gate": ["The documentation should reflect the package wiring."],
                    },
                ],
                "commit_intents": [
                    {
                        "scope": "docs",
                        "summary": "add an architecture overview",
                    },
                    {
                        "scope": "lib",
                        "summary": "annotate flake outputs and loader composition flow",
                    },
                ],
                "execution_policy": {
                    "mode": "documentation-first, behavior-preserving",
                    "allowed_changes": ["Markdown documentation", "Comments"],
                    "forbidden_changes": ["Behavior changes"],
                    "verification_strategy": "Run the targeted nix checks.",
                    "completion_definition": "All gates pass.",
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.execution_goal == "Document the system architecture."
    assert contract.verification_commands == [
        "nix fmt",
        "nix flake check --all-systems",
    ]
    assert [todo.todo_id for todo in contract.todos] == [
        "baseline-architecture-inventory",
        "document-modules-and-package-wiring",
    ]
    assert contract.todos[0].status == "ready"
    assert contract.todos[1].dependency_ids == ["baseline-architecture-inventory"]
    assert contract.todos[0].scope_hints == ["flake.nix", "README.md"]
    assert [intent.intent_id for intent in contract.commit_intents] == ["intent-1", "intent-2"]
    assert contract.commit_intents[0].message == "docs: add an architecture overview"
    assert contract.commit_intents[0].todo_ids == ["baseline-architecture-inventory"]
    assert contract.commit_intents[1].ordering_after == ["intent-1"]
    assert contract.commit_intents[1].todo_ids == ["document-modules-and-package-wiring"]
    assert contract.execution_policy == contract.execution_policy.__class__()


def test_execute_contract_rejects_merge_ready_handoffs_without_touched_paths() -> None:
    with pytest.raises(
        ValidationError,
        match="merge-ready execute handoffs must report at least one touched path",
    ):
        ExecuteContract.model_validate(
            {
                "summary": "No tracked edits were needed.",
                "artifacts": [],
                "touched_paths": [],
                "merge_readiness": "ready",
            }
        )


def test_format_turn_progress_event_uses_explicit_live_and_waiting_contract_kinds() -> None:
    live_status = _format_turn_progress_event(
        _RawEvent(
            "thread/tokenUsage/updated",
            {
                "tokenUsage": {
                    "totalTokens": 1234,
                    "inputTokens": 1000,
                    "outputTokens": 234,
                }
            },
        ),
        {},
    )
    waiting = _format_turn_progress_event(
        _RawEvent(
            "subagent_waiting",
            {
                "thread_id": "thread-1",
                "agent_thread_id": "run-child-1",
                "summary": "Waiting on run-child-1 to finish verification",
            },
        ),
        {},
    )

    assert isinstance(live_status, LiveStatusEvent)
    assert live_status.kind == "runtime.live_status"
    assert isinstance(waiting, CurrentWaitingStateEvent)
    assert waiting.kind == "runtime.current_waiting_state"


def test_milestone_transcript_line_event_uses_explicit_contract_kind() -> None:
    event = MilestoneTranscriptLineEvent(message="Next step: verify the plan output")

    assert event.kind == "runtime.milestone_transcript_line"
    assert event.message == "Next step: verify the plan output"


def test_inline_only_contract_events_do_not_inherit_legacy_tui_event_types() -> None:
    live_status = LiveStatusEvent(text="Loop run-child-1 inspecting docs")
    plan_label = CurrentPlanNodeLabelEvent(label="Execute the approved plan")
    waiting_label = CurrentWaitingStateEvent(label="Waiting on child run output")

    assert not isinstance(live_status, RuntimeStatusUpdatedEvent)
    assert not isinstance(plan_label, PlanUpdatedEvent)
    assert not isinstance(waiting_label, BackgroundWaitBeginEvent)


def test_headless_startup_blocker_persists_pending_prompt_without_frontend_callbacks(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    frontend = _PassiveFrontend()

    result = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt=None,
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=None,
    ).run(frontend=frontend)

    state = load_interactive_session_state(repo_root)

    assert result.mode == "startup"
    assert [prompt.prompt_kind for prompt in state.pending_prompts] == ["startup_prompt"]
    assert any("start first task" in message.lower() for message in frontend.messages)
    assert any(isinstance(event, BlockerPromptEvent) for event in frontend.events)
    assert any(isinstance(event, CurrentBlockerStateEvent) for event in frontend.events)


def test_emit_pending_prompt_preserves_review_requested_actions_for_recovery_prompt() -> None:
    frontend = _PassiveFrontend()
    prompt = PendingPrompt(
        thread_id="run-child-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-run-child-1-recovery",
        prompt_kind="recovery_review",
        title="Recovery review",
        question="Recovery review pending for run-child-1",
        allowed_actions=("retry", "replace", "abort"),
        context={
            "review_kind": "recovery",
            "recommended_actions": ["/retry", "/replace"],
        },
        blocked_continuation=BlockedContinuationRef(thread_id="run-child-1", run_id="run-child-1"),
    )

    _emit_pending_prompt(frontend, prompt)

    review_requested = next(event for event in frontend.events if isinstance(event, ReviewRequestedEvent))
    assert review_requested.recommended_actions == ("/retry", "/replace", "/pause", "/abort")


def test_headless_run_emits_transitional_inline_runtime_contract_events(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    frontend = _PassiveFrontend()

    result = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="look for typos",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    ).run(frontend=frontend)

    assert result.mode == "completed"
    assert any(isinstance(event, CurrentTaskLabelEvent) for event in frontend.events)
    assert any(isinstance(event, CurrentPlanNodeLabelEvent) for event in frontend.events)
    assert any(isinstance(event, LoopLaunchEvent) for event in frontend.events)
    assert any(isinstance(event, LoopCompletionEvent) for event in frontend.events)
    assert any(getattr(event, "kind", None) == "runtime.milestone_transcript_line" for event in frontend.events)


def test_build_audit_prompt_constrains_review_to_repo_local_evidence(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="look for typos",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    supervisor.startup_record = supervisor._ensure_startup_record()
    supervisor.root_run = supervisor._ensure_root_run()
    supervisor.state = supervisor._load_state()

    prompt = supervisor._build_audit_prompt(
        repo_root / ".ralphception" / "runs" / "run-root" / "audit-findings.json"
    )

    assert "Only inspect the current repository root and `.ralphception/` inside it." in prompt
    assert "Do not read `..`, sibling repos, other worktrees, or unrelated clones." in prompt
    assert "If there are no blocking findings, write `{ \"findings\": [] }`" in prompt
    assert "Do not narrate meta-planning about tools, agents, or internal capabilities." in prompt
    assert "Do not discuss internal tool names, planning APIs, or tool-selection strategy." in prompt


def test_build_audit_prompt_includes_latest_merged_run_context(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    run_dir = repo_root / ".ralphception" / "runs" / "run-child-1"
    run_dir.mkdir(parents=True)
    (run_dir / "handoff.json").write_text(
        json.dumps(
            {
                "artifact_refs": [
                    {
                        "artifact_kind": "code",
                        "artifact_path": "README.md",
                        "artifact_version": 1,
                        "content_hash": "sha256:test",
                    }
                ],
                "base_branch": "main",
                "branch_name": "codex/run-child-1",
                "child_run_id": "run-child-1",
                "cleanup_state": "pending",
                "consumed_bundle_version": 1,
                "goal": "look for typos",
                "head_commit": "abc123",
                "merge_readiness": "ready",
                "touched_paths": ["README.md"],
                "verification_artifact_refs": [],
                "verification_summary": "passed",
                "worktree_path": str(repo_root / ".worktrees" / "run-child-1"),
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="look for typos",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    supervisor.startup_record = supervisor._ensure_startup_record()
    supervisor.root_run = supervisor._ensure_root_run()
    supervisor.state = supervisor._load_state()
    supervisor.state.current_child_run_id = "run-child-1"

    prompt = supervisor._build_audit_prompt(
        repo_root / ".ralphception" / "runs" / "run-root" / "audit-findings.json"
    )

    assert '"child_run_id": "run-child-1"' in prompt
    assert '"touched_paths": [' in prompt
    assert '"README.md"' in prompt
    assert '"verification_summary": "passed"' in prompt
    assert "Primary audit target files: README.md" in prompt
    assert "Treat the provided merged-run context as authoritative unless repo-local evidence contradicts it." in prompt
    assert "Do not run broad discovery commands when the provided context already answers the audit question." in prompt


def test_build_audit_prompt_prefers_direct_no_findings_for_trivial_verified_changes(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    run_dir = repo_root / ".ralphception" / "runs" / "run-child-1"
    run_dir.mkdir(parents=True)
    (run_dir / "handoff.json").write_text(
        json.dumps(
            {
                "artifact_refs": [
                    {
                        "artifact_kind": "code",
                        "artifact_path": "README.md",
                        "artifact_version": 1,
                        "content_hash": "sha256:test",
                    }
                ],
                "base_branch": "main",
                "branch_name": "codex/run-child-1",
                "child_run_id": "run-child-1",
                "cleanup_state": "pending",
                "consumed_bundle_version": 1,
                "goal": "look for typos",
                "head_commit": "abc123",
                "merge_readiness": "ready",
                "touched_paths": ["README.md"],
                "verification_artifact_refs": [],
                "verification_summary": "passed",
                "worktree_path": str(repo_root / ".worktrees" / "run-child-1"),
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="look for typos",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    supervisor.startup_record = supervisor._ensure_startup_record()
    supervisor.root_run = supervisor._ensure_root_run()
    supervisor.state = supervisor._load_state()
    supervisor.state.current_child_run_id = "run-child-1"

    prompt = supervisor._build_audit_prompt(
        repo_root / ".ralphception" / "runs" / "run-root" / "audit-findings.json"
    )

    assert "For a small, single-file change with passed verification, prefer writing `{ \"findings\": [] }` immediately" in prompt
    assert "Do not enumerate `.ralphception` with shell loops or broad globbing commands." in prompt


def test_stage_prompts_embed_bundled_skill_guidance(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="fix typos in the readme",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    supervisor.startup_record = supervisor._ensure_startup_record()
    supervisor.root_run = supervisor._ensure_root_run()
    supervisor.state = supervisor._load_state()
    loop_definition = LoopDefinition(
        loop_id="loop-todo-1",
        task_id="run-root",
        plan_node_id="todo-1",
        parent_loop_id=None,
        objective="Inspect README.md for typo fixes",
        stop_conditions=("README.md typo pass is settled",),
        output_contract=("publish README.md typo findings",),
        target_artifacts=("README.md",),
        merge_strategy="direct_update",
    )

    spec_prompt = supervisor._build_spec_prompt(repo_root / ".ralphception" / "specs" / "prd.md")
    plan_prompt = supervisor._build_plan_prompt(
        repo_root / ".ralphception" / "plans" / "execution-plan.md",
        repo_root / ".ralphception" / "plans" / "execution-plan.json",
    )
    execute_prompt = supervisor._build_execute_prompt(
        run_id="run-child-1",
        goal="Fix typos in README.md",
        handoff_path=repo_root / ".ralphception" / "runs" / "run-child-1" / "handoff.json",
        loop_definition=loop_definition,
    )
    audit_prompt = supervisor._build_audit_prompt(
        repo_root / ".ralphception" / "runs" / "run-root" / "audit-findings.json"
    )

    assert "# Ralph Spec Writing" in spec_prompt
    assert "## Required Structure" in spec_prompt
    assert "# Ralph Plan Writing" in plan_prompt
    assert "## Loop-Safe Slice Design" in plan_prompt
    assert "# Ralph Execute Task" in execute_prompt
    assert "## The Iron Law" in execute_prompt
    assert "# Ralph Audit Review" in audit_prompt
    assert "## Reopen vs Complete" in audit_prompt
    assert "Use the `ralph-spec-writing` skill." not in spec_prompt
    assert "Use the `ralph-plan-writing` skill." not in plan_prompt
    assert "Use the `ralph-execute-task` skill." not in execute_prompt
    assert "Use the `ralph-audit-review` skill." not in audit_prompt
    assert "Do not announce bundled skill guidance in the transcript, command output, or final answer." in spec_prompt
    assert "Do not announce bundled skill guidance in the transcript, command output, or final answer." in plan_prompt
    assert "Do not announce bundled skill guidance in the transcript, command output, or final answer." in execute_prompt
    assert "Do not announce bundled skill guidance in the transcript, command output, or final answer." in audit_prompt


def test_build_execute_prompt_constrains_loop_worker_to_repo_local_scope(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="fix typos in the readme",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    loop_definition = LoopDefinition(
        loop_id="loop-todo-1",
        task_id="run-root",
        plan_node_id="todo-1",
        parent_loop_id=None,
        objective="Inspect README.md for typo fixes",
        stop_conditions=("README.md typo pass is settled",),
        output_contract=("publish README.md typo findings",),
        target_artifacts=("README.md",),
        merge_strategy="direct_update",
    )

    prompt = supervisor._build_execute_prompt(
        run_id="run-child-1",
        goal="Fix typos in README.md",
        handoff_path=repo_root / ".ralphception" / "runs" / "run-child-1" / "handoff.json",
        loop_definition=loop_definition,
    )

    assert "Stay inside the current repository root and the target artifacts for this loop." in prompt
    assert "Start from the target artifacts and nearby repo-local evidence instead of broad repo discovery." in prompt
    assert "Keep progress updates concrete: inspected files, edits, verification, findings, and blockers." in prompt
    assert "If the requested target already looks correct, say so clearly and finish the loop without unnecessary churn." in prompt


def test_build_execute_prompt_blocks_generic_codex_agent_meta_behavior(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    supervisor = HeadlessMissionSupervisor(
        repo_root=repo_root,
        primary_repo_root=repo_root,
        seed_prompt="fix typos in the readme",
        source_repos=(),
        approve_all=True,
        approver="headless",
        session_manager_factory=lambda resolved_repo_root, config: build_fake_headless_session_manager(
            workspace_path=str(resolved_repo_root),
            config=config,
        ),
    )
    loop_definition = LoopDefinition(
        loop_id="loop-todo-1",
        task_id="run-root",
        plan_node_id="todo-1",
        parent_loop_id=None,
        objective="Inspect README.md for typo fixes",
        stop_conditions=("README.md typo pass is settled",),
        output_contract=("publish README.md typo findings",),
        target_artifacts=("README.md",),
        merge_strategy="direct_update",
    )

    prompt = supervisor._build_execute_prompt(
        run_id="run-child-1",
        goal="Fix typos in README.md",
        handoff_path=repo_root / ".ralphception" / "runs" / "run-child-1" / "handoff.json",
        loop_definition=loop_definition,
    )

    assert "Do not narrate meta-planning about tools, agents, or internal capabilities." in prompt
    assert "Do not discuss internal tool names, planning APIs, or tool-selection strategy." in prompt
    assert "Do the loop work directly in this worktree and report only task-relevant progress." in prompt
    assert "Do not inspect `.ralphception/` except for the provided handoff path." in prompt
    assert "Do not write first-person internal deliberation like `I need to`, `I think`, `I'll`, or `Let's`." in prompt


def test_emit_pending_prompt_reconstructs_legacy_recovery_actions_when_context_is_missing() -> None:
    frontend = _PassiveFrontend()
    prompt = PendingPrompt(
        thread_id="run-child-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-run-child-1-recovery",
        prompt_kind="recovery_review",
        title="Recovery review",
        question="Recovery review pending for run-child-1",
        allowed_actions=("retry", "replace", "abort"),
        context={"review_kind": "recovery"},
        blocked_continuation=BlockedContinuationRef(thread_id="run-child-1", run_id="run-child-1"),
    )

    _emit_pending_prompt(frontend, prompt)

    review_requested = next(event for event in frontend.events if isinstance(event, ReviewRequestedEvent))
    assert review_requested.recommended_actions == ("/retry", "/replace")


class _RawEvent:
    def __init__(self, method: str, payload: dict[str, object]) -> None:
        self.method = method
        self.payload = payload


def make_git_repo(tmp_path: Path) -> Path:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    subprocess.run(
        ["git", "init", "-b", "main"],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    subprocess.run(
        ["git", "add", "README.md"],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    subprocess.run(
        [
            "git",
            "-c",
            "commit.gpgsign=false",
            "-c",
            "user.name=Test User",
            "-c",
            "user.email=test@example.com",
            "commit",
            "-m",
            "initial",
        ],
        check=True,
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    return repo_root


def test_resolve_child_final_commit_message_normalizes_to_repo_style(tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)

    resolved = _resolve_child_final_commit_message(
        repo_root=repo_root,
        goal="Fix typos across the repository.",
        plan_contract=None,
    )

    assert resolved == "chore: Fix typos across the repository"


def test_commit_child_changes_does_not_disable_signing(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    calls: list[tuple[Path, tuple[str, ...]]] = []

    monkeypatch.setattr(
        "ralphception.headless.resolve_git_commit_identity",
        lambda _: ("Test User", "test@example.com"),
    )
    monkeypatch.setattr(
        "ralphception.headless._run_git",
        lambda cwd, *args: calls.append((cwd, args)),
    )

    def fake_run(args: list[str], **kwargs) -> subprocess.CompletedProcess[str]:
        assert args == ["git", "diff", "--cached", "--quiet"]
        return subprocess.CompletedProcess(args=args, returncode=1, stdout="", stderr="")

    monkeypatch.setattr("ralphception.headless.subprocess.run", fake_run)

    supervisor = object.__new__(HeadlessMissionSupervisor)
    HeadlessMissionSupervisor._commit_child_changes(
        supervisor,
        worktree_path=repo_root,
        run_id="run-child-1",
        touched_paths=["README.md"],
    )

    commit_call = next(args for _cwd, args in calls if "commit" in args)
    assert "commit.gpgsign=false" not in commit_call


def test_commit_squash_merge_does_not_disable_signing(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    repo_root = make_git_repo(tmp_path)
    coordinator = MergeCoordinator(
        repo_root=repo_root,
        run_id="run-root",
        stage_id="merge",
        target_branch="main",
    )
    calls: list[tuple[Path, tuple[str, ...]]] = []

    monkeypatch.setattr(
        "ralphception.git.merge.resolve_git_commit_identity",
        lambda _: ("Test User", "test@example.com"),
    )
    monkeypatch.setattr(
        coordinator,
        "_run_git",
        lambda cwd, *args: calls.append((cwd, args)) or subprocess.CompletedProcess(args=["git"], returncode=0, stdout="", stderr=""),
    )

    coordinator._commit_squash_merge(
        repo_root,
        handoff=WorktreeHandoff(
            child_run_id="run-child-1",
            worktree_path=str(repo_root / ".worktrees" / "run-child-1"),
            branch_name="codex/run-child-1",
            base_branch="main",
            head_commit="a" * 40,
            goal="Fix typos across the repository.",
            artifact_refs=[],
            verification_artifact_refs=[],
            consumed_bundle_version=1,
            touched_paths=["README.md"],
            verification_summary="tests passed",
            merge_readiness="ready",
            cleanup_state="pending",
        ),
        final_commit_message="fix: concise subject",
    )

    commit_call = next(args for _cwd, args in calls if "commit" in args)
    assert "commit.gpgsign=false" not in commit_call
