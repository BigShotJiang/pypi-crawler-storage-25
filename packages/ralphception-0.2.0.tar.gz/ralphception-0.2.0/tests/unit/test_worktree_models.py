from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.worktree import WorktreeHandoff


def test_worktree_handoff_accepts_required_contract_fields() -> None:
    artifact_ref = ArtifactRef(
        artifact_kind="summary",
        artifact_path=".ralphception/runs/run-child-1/summary.md",
        artifact_version=1,
        content_hash="sha256:summary-1",
    )
    handoff = WorktreeHandoff(
        child_run_id="run-child-1",
        worktree_path="/repo/.worktrees/child-1",
        branch_name="codex/core-runtime",
        base_branch="main",
        head_commit="abc1234",
        goal="Implement the durable runtime models",
        artifact_refs=[artifact_ref],
        verification_artifact_refs=[artifact_ref],
        consumed_bundle_version=3,
        touched_paths=[
            "src/ralphception/models/runtime.py",
            "tests/unit/test_runtime_models.py",
        ],
        verification_summary="pytest and type checking passed",
        merge_readiness="ready",
        cleanup_state="pending",
    )

    assert handoff.merge_readiness == "ready"
    assert handoff.cleanup_state == "pending"


def test_worktree_handoff_rejects_unknown_state_values() -> None:
    artifact_ref = ArtifactRef(
        artifact_kind="summary",
        artifact_path=".ralphception/runs/run-child-1/summary.md",
        artifact_version=1,
        content_hash="sha256:summary-1",
    )

    with pytest.raises(ValidationError):
        WorktreeHandoff(
            child_run_id="run-child-1",
            worktree_path="/repo/.worktrees/child-1",
            branch_name="codex/core-runtime",
            base_branch="main",
            head_commit="abc1234",
            goal="Implement the durable runtime models",
            artifact_refs=[artifact_ref],
            verification_artifact_refs=[artifact_ref],
            consumed_bundle_version=3,
            touched_paths=["src/ralphception/models/runtime.py"],
            verification_summary="pytest and type checking passed",
            merge_readiness=cast(Any, "almost_ready"),
            cleanup_state="pending",
        )

    with pytest.raises(ValidationError):
        WorktreeHandoff(
            child_run_id="run-child-1",
            worktree_path="/repo/.worktrees/child-1",
            branch_name="codex/core-runtime",
            base_branch="main",
            head_commit="abc1234",
            goal="Implement the durable runtime models",
            artifact_refs=[artifact_ref],
            verification_artifact_refs=[artifact_ref],
            consumed_bundle_version=3,
            touched_paths=["src/ralphception/models/runtime.py"],
            verification_summary="pytest and type checking passed",
            merge_readiness="ready",
            cleanup_state=cast(Any, "archived"),
        )


def test_worktree_handoff_requires_positive_consumed_bundle_version() -> None:
    artifact_ref = ArtifactRef(
        artifact_kind="summary",
        artifact_path=".ralphception/runs/run-child-1/summary.md",
        artifact_version=1,
        content_hash="sha256:summary-1",
    )

    with pytest.raises(ValidationError):
        WorktreeHandoff(
            child_run_id="run-child-1",
            worktree_path="/repo/.worktrees/child-1",
            branch_name="codex/core-runtime",
            base_branch="main",
            head_commit="abc1234",
            goal="Implement the durable runtime models",
            artifact_refs=[artifact_ref],
            verification_artifact_refs=[artifact_ref],
            consumed_bundle_version=0,
            touched_paths=["src/ralphception/models/runtime.py"],
            verification_summary="pytest and type checking passed",
            merge_readiness="ready",
            cleanup_state="pending",
        )


@pytest.mark.parametrize("merge_readiness", ["needs_revision", "blocked"])
def test_worktree_handoff_rejects_cleaned_state_when_not_mergeable(merge_readiness: str) -> None:
    artifact_ref = ArtifactRef(
        artifact_kind="summary",
        artifact_path=".ralphception/runs/run-child-1/summary.md",
        artifact_version=1,
        content_hash="sha256:summary-1",
    )

    with pytest.raises(ValidationError):
        WorktreeHandoff(
            child_run_id="run-child-1",
            worktree_path="/repo/.worktrees/child-1",
            branch_name="codex/core-runtime",
            base_branch="main",
            head_commit="abc1234",
            goal="Implement the durable runtime models",
            artifact_refs=[artifact_ref],
            verification_artifact_refs=[artifact_ref],
            consumed_bundle_version=3,
            touched_paths=["src/ralphception/models/runtime.py"],
            verification_summary="pytest and type checking passed",
            merge_readiness=cast(Any, merge_readiness),
            cleanup_state="cleaned",
        )
