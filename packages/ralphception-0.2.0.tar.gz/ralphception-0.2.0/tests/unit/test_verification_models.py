from datetime import datetime, timezone
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception import models as exported_models
from ralphception.models.artifacts import ArtifactRef
from ralphception.models.artifacts import TodoPriority as SourceTodoPriority
from ralphception.models.runtime import StageKind as SourceStageKind
from ralphception.models.verification import (
    VerificationStatus as SourceVerificationStatus,
    AuditFinding,
    VerificationCommandResult,
    VerificationResult,
    VerificationSpec,
)
from ralphception.models.worktree import MergeReadiness as SourceMergeReadiness
from ralphception.models.session import SessionFailureKind as SourceSessionFailureKind


def test_verification_spec_accepts_required_contract_fields() -> None:
    spec = VerificationSpec(
        verification_id="verification-1",
        run_id="run-1",
        task_id="task-verify-1",
        requested_by="merge:task-1",
        scope="merge",
        required=True,
        commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
        success_criteria="all commands exit 0",
        created_at=utc_now(),
    )

    assert spec.scope == "merge"
    assert spec.required is True


def test_verification_spec_requires_non_empty_commands() -> None:
    with pytest.raises(ValidationError):
        VerificationSpec(
            verification_id="verification-1",
            run_id="run-1",
            task_id="task-verify-1",
            requested_by="merge:task-1",
            scope="merge",
            required=True,
            commands=[],
            success_criteria="all commands exit 0",
            created_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationSpec(
            verification_id="verification-2",
            run_id="run-1",
            task_id="task-verify-1",
            requested_by="merge:task-1",
            scope="merge",
            required=True,
            commands=["   "],
            success_criteria="all commands exit 0",
            created_at=utc_now(),
        )


def test_verification_result_rejects_incomplete_command_results_entries() -> None:
    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-1",
            run_id="run-1",
            task_id="task-verify-1",
            status="passed",
            command_results=cast(Any, [{"command": "pytest"}]),
            started_at=utc_now(),
            completed_at=utc_now(),
        )


@pytest.mark.parametrize(
    ("status", "exit_code"),
    [
        ("passed", 1),
        ("failed", 0),
        ("errored", 0),
    ],
)
def test_verification_command_result_rejects_inconsistent_exit_code(
    status: str,
    exit_code: int,
) -> None:
    with pytest.raises(ValidationError):
        VerificationCommandResult(
            command="uv run pytest tests/unit/test_runtime_models.py -v",
            cwd="/repo",
            exit_code=exit_code,
            status=cast(Any, status),
            duration_ms=1500,
            stdout_ref=make_artifact_ref(),
            stderr_ref=make_artifact_ref(),
        )


def test_verification_command_result_rejects_negative_duration() -> None:
    with pytest.raises(ValidationError):
        VerificationCommandResult(
            command="uv run pytest tests/unit/test_runtime_models.py -v",
            cwd="/repo",
            exit_code=0,
            status="passed",
            duration_ms=-1,
            stdout_ref=make_artifact_ref(),
            stderr_ref=make_artifact_ref(),
        )

    with pytest.raises(ValidationError):
        VerificationCommandResult(
            command="   ",
            cwd="/repo",
            exit_code=0,
            status="passed",
            duration_ms=1,
            stdout_ref=make_artifact_ref(),
            stderr_ref=make_artifact_ref(),
        )

    with pytest.raises(ValidationError):
        VerificationCommandResult(
            command="uv run pytest tests/unit/test_runtime_models.py -v",
            cwd="   ",
            exit_code=0,
            status="passed",
            duration_ms=1,
            stdout_ref=make_artifact_ref(),
            stderr_ref=make_artifact_ref(),
        )


@pytest.mark.parametrize("status", ["pending", "running"])
def test_verification_command_result_requires_inflight_shape(status: str) -> None:
    command_result = VerificationCommandResult(
        command="uv run pytest tests/unit/test_runtime_models.py -v",
        cwd="/repo",
        exit_code=None,
        status=cast(Any, status),
        duration_ms=None,
        stdout_ref=None,
        stderr_ref=None,
    )

    assert command_result.exit_code is None

    with pytest.raises(ValidationError):
        VerificationCommandResult(
            command="uv run pytest tests/unit/test_runtime_models.py -v",
            cwd="/repo",
            exit_code=0,
            status=cast(Any, status),
            duration_ms=1500,
            stdout_ref=make_artifact_ref(),
            stderr_ref=make_artifact_ref(),
        )


def test_verification_result_lifecycle_requires_timestamps() -> None:
    command_result = VerificationCommandResult(
        command="uv run pytest tests/unit/test_runtime_models.py -v",
        cwd="/repo",
        exit_code=0,
        status="passed",
        duration_ms=1500,
        stdout_ref=make_artifact_ref(),
        stderr_ref=make_artifact_ref(),
    )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-1",
            run_id="run-1",
            task_id="task-verify-1",
            status="running",
            command_results=[],
            started_at=None,
            completed_at=None,
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-1",
            run_id="run-1",
            task_id="task-verify-1",
            status="pending",
            command_results=[],
            started_at=utc_now(),
            completed_at=None,
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-1",
            run_id="run-1",
            task_id="task-verify-1",
            status="pending",
            command_results=[],
            started_at=None,
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-pending-with-results",
            run_id="run-1",
            task_id="task-verify-1",
            status="pending",
            command_results=[command_result],
            started_at=None,
            completed_at=None,
        )

    result = VerificationResult(
        verification_id="verification-1",
        run_id="run-1",
        task_id="task-verify-1",
        status="passed",
        command_results=[command_result],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert result.command_results[0].exit_code == 0

    pending_result = VerificationResult(
        verification_id="verification-2",
        run_id="run-1",
        task_id="task-verify-2",
        status="pending",
        command_results=[],
        started_at=None,
        completed_at=None,
    )

    assert pending_result.started_at is None
    assert pending_result.completed_at is None


def test_running_verification_result_accepts_inflight_command_results() -> None:
    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-pending-row",
            run_id="run-1",
            task_id="task-verify-1",
            status="pending",
            command_results=[make_command_result(status="running")],
            started_at=None,
            completed_at=None,
        )

    running_result = VerificationResult(
        verification_id="verification-running-partial-progress",
        run_id="run-1",
        task_id="task-verify-1",
        status="running",
        command_results=[
            make_command_result(status="passed", exit_code=0),
            make_command_result(status="running"),
        ],
        started_at=utc_now(),
        completed_at=None,
    )

    assert [result.status for result in running_result.command_results] == ["passed", "running"]


def test_running_verification_result_allows_completed_success_snapshot() -> None:
    result = VerificationResult(
        verification_id="verification-running-all-passed",
        run_id="run-1",
        task_id="task-verify-1",
        status="running",
        command_results=[make_command_result(status="passed", exit_code=0)],
        started_at=utc_now(),
        completed_at=None,
    )

    assert [command.status for command in result.command_results] == ["passed"]


@pytest.mark.parametrize("status", ["passed", "failed", "errored"])
def test_verification_result_rejects_completed_before_started(status: str) -> None:
    terminal_command = make_command_result(
        status="passed" if status == "passed" else cast(Any, status),
        exit_code=0 if status == "passed" else 1,
    )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id=f"verification-{status}-chronology",
            run_id="run-1",
            task_id="task-verify-1",
            status=cast(Any, status),
            command_results=[terminal_command],
            started_at=datetime(2026, 3, 15, 21, 0, tzinfo=timezone.utc),
            completed_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        )


def test_verification_result_requires_matching_terminal_command_evidence() -> None:
    passed_command = make_command_result(status="passed", exit_code=0)
    failed_command = make_command_result(status="failed", exit_code=1)
    errored_command = make_command_result(status="errored", exit_code=2)

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-empty-passed",
            run_id="run-1",
            task_id="task-verify-1",
            status="passed",
            command_results=[],
            started_at=utc_now(),
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-mixed-passed",
            run_id="run-1",
            task_id="task-verify-1",
            status="passed",
            command_results=[passed_command, failed_command],
            started_at=utc_now(),
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-no-failed",
            run_id="run-1",
            task_id="task-verify-1",
            status="failed",
            command_results=[passed_command],
            started_at=utc_now(),
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-no-errored",
            run_id="run-1",
            task_id="task-verify-1",
            status="errored",
            command_results=[failed_command],
            started_at=utc_now(),
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-failed-with-errored",
            run_id="run-1",
            task_id="task-verify-1",
            status="failed",
            command_results=[failed_command, errored_command],
            started_at=utc_now(),
            completed_at=utc_now(),
        )

    failed_result = VerificationResult(
        verification_id="verification-failed",
        run_id="run-1",
        task_id="task-verify-1",
        status="failed",
        command_results=[passed_command, failed_command],
        started_at=utc_now(),
        completed_at=utc_now(),
    )
    errored_result = VerificationResult(
        verification_id="verification-errored",
        run_id="run-1",
        task_id="task-verify-1",
        status="errored",
        command_results=[failed_command, errored_command],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert failed_result.status == "failed"
    assert errored_result.status == "errored"


def test_running_verification_result_rejects_terminal_failure_command_states() -> None:
    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-running-errored-after-pass",
            run_id="run-1",
            task_id="task-verify-1",
            status="running",
            command_results=[
                make_command_result(status="passed", exit_code=0),
                make_command_result(status="errored", exit_code=2),
            ],
            started_at=utc_now(),
            completed_at=None,
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-running-failed",
            run_id="run-1",
            task_id="task-verify-1",
            status="running",
            command_results=[make_command_result(status="failed", exit_code=1)],
            started_at=utc_now(),
            completed_at=None,
        )

    with pytest.raises(ValidationError):
        VerificationResult(
            verification_id="verification-running-errored",
            run_id="run-1",
            task_id="task-verify-1",
            status="running",
            command_results=[make_command_result(status="errored", exit_code=2)],
            started_at=utc_now(),
            completed_at=None,
        )


def test_audit_finding_resolved_status_requires_resolved_at() -> None:
    evidence_ref = make_artifact_ref()

    with pytest.raises(ValidationError):
        AuditFinding(
            finding_id="finding-1",
            run_id="run-1",
            severity="P1",
            kind="test_gap",
            title="Missing verification coverage",
            evidence_refs=[evidence_ref],
            status="resolved",
            created_at=utc_now(),
            resolved_at=None,
        )

    finding = AuditFinding(
        finding_id="finding-2",
        run_id="run-1",
        severity="P2",
        kind="test_gap",
        title="Missing worktree test coverage",
        evidence_refs=[evidence_ref],
        status="open",
        created_at=utc_now(),
        resolved_at=None,
    )

    assert finding.status == "open"


def test_audit_finding_rejects_resolved_before_created() -> None:
    with pytest.raises(ValidationError):
        AuditFinding(
            finding_id="finding-4",
            run_id="run-1",
            severity="P1",
            kind="bug",
            title="Resolution predates finding creation",
            evidence_refs=[make_artifact_ref()],
            status="resolved",
            created_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
            resolved_at=datetime(2026, 3, 15, 19, 0, tzinfo=timezone.utc),
        )


def test_audit_finding_rejects_unknown_kind() -> None:
    with pytest.raises(ValidationError):
        AuditFinding(
            finding_id="finding-3",
            run_id="run-1",
            severity="P2",
            kind=cast(Any, "missing_test"),
            title="Unknown finding kind",
            evidence_refs=[make_artifact_ref()],
            status="open",
            created_at=utc_now(),
            resolved_at=None,
        )


def test_models_aggregator_reexports_shared_vocabularies() -> None:
    expected_exports = {
        "StageKind",
        "TaskKind",
        "TaskStatus",
        "RunStageStatus",
        "TaskOwner",
        "ExecutionBundleState",
        "ApprovalKind",
        "AgentStatus",
        "SessionFailureKind",
        "MergeReadiness",
        "CleanupState",
        "VerificationScope",
        "VerificationStatus",
        "VerificationCommandStatus",
        "AuditFindingStatus",
        "FindingSeverity",
        "FindingKind",
        "TodoPriority",
        "TodoStatus",
    }

    assert expected_exports.issubset(set(exported_models.__all__))
    assert exported_models.StageKind == SourceStageKind
    assert exported_models.VerificationStatus == SourceVerificationStatus
    assert exported_models.TodoPriority == SourceTodoPriority
    assert exported_models.MergeReadiness == SourceMergeReadiness
    assert exported_models.SessionFailureKind is SourceSessionFailureKind


def make_artifact_ref() -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="verification_log",
        artifact_path=".ralphception/verification/verification-1.json",
        artifact_version=1,
        content_hash="sha256:verification-1",
    )


def make_command_result(
    *,
    status: str,
    exit_code: int | None = None,
) -> VerificationCommandResult:
    is_terminal = status in {"passed", "failed", "errored"}
    return VerificationCommandResult(
        command="uv run pytest tests/unit/test_runtime_models.py -v",
        cwd="/repo",
        exit_code=exit_code,
        status=cast(Any, status),
        duration_ms=1500 if is_terminal else None,
        stdout_ref=make_artifact_ref() if is_terminal else None,
        stderr_ref=make_artifact_ref() if is_terminal else None,
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
