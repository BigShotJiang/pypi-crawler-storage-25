from __future__ import annotations

import hashlib
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from ralphception.config import DEFAULT_CONFIG
from ralphception.codex.session_manager import CodexSessionManager
from ralphception.models.artifacts import ArtifactRef
from ralphception.runtime.interactive_session import write_interactive_session_state
from ralphception.runtime.interactive_session import interactive_session_path
from ralphception.runtime.prompt_state import BlockedContinuationRef, InteractiveSessionState, PendingPrompt
from ralphception.runtime.supervisor import RuntimeSupervisor, _default_session_manager_factory
from ralphception.runtime.supervisor import _load_prompt_state
from ralphception.runtime.interactive_session import load_interactive_session_state
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.runtime.bootstrap import StartupBootstrapController, load_startup_record


@pytest.fixture
def repo_root(tmp_path: Path) -> Path:
    return bootstrap_workspace(tmp_path)


def test_supervisor_routes_unbootstrapped_workspace_to_startup_request(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "startup_prompt"
    assert outcome.pending_prompt is not None
    assert outcome.pending_prompt.prompt_kind == "startup_prompt"
    assert outcome.pending_prompt.thread_id == "run-root"


def test_supervisor_routes_pending_spec_to_review_request(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )
    write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content="# Runtime Spec\n\n- Review before planning.\n",
    )

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "review_prompt"
    assert outcome.pending_prompt is not None
    assert outcome.pending_prompt.prompt_kind == "spec_review"
    assert outcome.pending_prompt.owner_run_id == "run-root"


def test_supervisor_routes_bootstrapped_workspace_to_dashboard_state(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="port parser",
        source_repos=[],
    )

    supervisor = RuntimeSupervisor(repo_root=repo_root)

    outcome = supervisor.step()

    assert outcome.kind == "dashboard"
    assert outcome.engine is not None


def test_supervisor_repairs_failed_child_run_without_session_ref_from_stale_crash(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find and fix typos",
        source_repos=[],
    )
    child_run_path = repo_root / ".ralphception" / "runs" / "run-child-1" / "run.json"
    child_run_path.parent.mkdir(parents=True, exist_ok=True)
    child_run_path.write_text(
        json.dumps(
            {
                "run_id": "run-child-1",
                "parent_run_id": "run-root",
                "supersedes_run_id": None,
                "goal": "find and fix typos",
                "status": "failed",
                "stage_ids": ["stage-execute"],
                "config_snapshot": {"codex": {"model": "gpt-5.4"}},
                "codex_session_ref": None,
                "artifact_refs": [],
                "created_at": "2026-03-24T00:00:00Z",
                "updated_at": "2026-03-24T00:00:01Z",
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    outcome = RuntimeSupervisor(repo_root=repo_root).step()

    assert outcome.kind == "review_prompt"
    assert outcome.pending_prompt is not None
    assert outcome.pending_prompt.prompt_kind == "recovery_review"
    repaired_payload = json.loads(child_run_path.read_text(encoding="utf-8"))
    assert repaired_payload["stage_ids"] == []


def test_supervisor_surfaces_persisted_launch_conflict_as_pending_prompt(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="existing mission",
        source_repos=[],
    )
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState(
            root_thread_id="run-root",
            active_thread_id="run-root",
            pending_prompts=[
                PendingPrompt(
                    thread_id="run-root",
                    owner_run_id="run-root",
                    prompt_id="prompt-conflict-1",
                    prompt_kind="launch_conflict",
                    title="Session conflict",
                    question="Replace the unfinished session in this workspace?",
                    allowed_actions=("override", "abort"),
                    context={"requested_seed_prompt": "new mission"},
                    blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
                )
            ],
        ),
    )

    outcome = RuntimeSupervisor(repo_root=repo_root).step()

    assert outcome.kind == "startup_prompt"
    assert outcome.pending_prompt is not None
    assert outcome.pending_prompt.prompt_kind == "launch_conflict"


def test_default_session_manager_factory_uses_codex_cli_backend_when_available(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=True):
        manager = _default_session_manager_factory(tmp_path, DEFAULT_CONFIG)

    assert isinstance(manager, CodexSessionManager)


def test_default_session_manager_factory_returns_none_without_codex_cli(tmp_path: Path) -> None:
    with patch("ralphception.runtime.supervisor.codex_cli_available", return_value=False):
        manager = _default_session_manager_factory(tmp_path, DEFAULT_CONFIG)

    assert manager is None


def test_resolve_startup_input_uses_model_authored_clarifying_question(repo_root: Path) -> None:
    class FakeStartupSessionManager:
        def resolve_prompt_reply(self, *, prompt, user_text: str):
            return {
                "kind": "clarify",
                "clarifying_question": "Which files should I treat as in scope for this cleanup?",
                "confidence": 0.8,
            }

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: FakeStartupSessionManager(),
    )

    result = supervisor.resolve_startup_input(user_text="fix typos")
    prompt = supervisor.current_pending_prompt()

    assert result.kind == "clarify"
    assert result.clarifying_question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )
    assert prompt is not None
    assert prompt.question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )


def test_resolve_startup_input_bootstraps_from_model_authored_summary(repo_root: Path) -> None:
    class FakeStartupSessionManager:
        def resolve_prompt_reply(self, *, prompt, user_text: str):
            return {
                "kind": "resolved",
                "action": "bootstrap",
                "intake_summary": (
                    "Fix typos in README.md.\n\n"
                    "Additional context:\n"
                    "- Limit edits to README.md.\n"
                    "- Prefer spelling and wording fixes only."
                ),
                "confidence": 0.9,
            }

    supervisor = RuntimeSupervisor(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: FakeStartupSessionManager(),
    )

    result = supervisor.resolve_startup_input(user_text="fix typos in README.md")
    startup_record = load_startup_record(repo_root)

    assert result.kind == "clarify"
    assert result.clarifying_question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )
    assert startup_record is None


def test_prompt_resolution_is_persisted_before_continuation_resumes(repo_root: Path) -> None:
    supervisor = RuntimeSupervisor(repo_root=repo_root)

    supervisor.resolve_pending_prompt(thread_id="thread-root", user_text="resume it")
    state = load_interactive_session_state(repo_root)

    assert state.prompt_resolutions[-1].raw_user_reply == "resume it"
    assert state.prompt_resolutions[-1].action == "resume"


def test_supervisor_prompt_loader_preserves_task_session_and_plan_fields(tmp_path: Path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    payload = {
        "root_thread_id": "thread-root",
        "active_thread_id": "thread-active",
        "active_task_id": "task-1",
        "session_id": "session-1",
        "plan_id": "plan-1",
        "loop_graph_id": "loop-1",
        "active_plan_node_id": "plan-node-1",
        "pending_prompts": [],
        "prompt_resolutions": [],
        "deferred_inputs": [],
        "bootstrap_source_repos": ["/tmp/source-a"],
    }
    interactive_session_path(repo_root).write_text(json.dumps(payload), encoding="utf-8")

    state = _load_prompt_state(repo_root)

    assert state.root_thread_id == "thread-root"
    assert state.active_thread_id == "thread-active"
    assert state.active_task_id == "task-1"
    assert state.session_id == "session-1"
    assert state.plan_id == "plan-1"
    assert state.loop_graph_id == "loop-1"
    assert state.active_plan_node_id == "plan-node-1"


def write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    artifact_version: int,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=artifact_version,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )
