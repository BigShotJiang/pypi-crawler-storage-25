from pathlib import Path
from unittest.mock import patch

import ralphception.app as runtime_app
from typer.testing import CliRunner

from ralphception.cli import app
from ralphception.runtime.supervisor import (
    RuntimeBackendUnavailableError,
    RuntimeLaunchAbortedError,
    RuntimePromptConflictError,
)
def test_cli_help_exposes_shell_and_exec_only() -> None:
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "exec" in result.stdout
    assert "resume" not in result.stdout
    assert "terminal" not in result.stdout
    assert "headless" not in result.stdout
    assert "chat-shell" not in result.stdout


def test_cli_without_subcommand_runs_chat_shell() -> None:
    with patch.object(runtime_app, "run_app") as run_app:
        result = CliRunner().invoke(app, [])

    assert result.exit_code == 0
    run_app.assert_called_once_with()


def test_cli_exec_runs_noninteractive_runtime() -> None:
    fake_result = object()
    with patch.object(runtime_app, "run_exec", return_value=fake_result) as run_exec, patch.object(
        runtime_app,
        "_render_exec_result",
        return_value="Exec mode: completed",
    ) as render_exec:
        result = CliRunner().invoke(
            app,
            [
                "exec",
                "find any bugs",
                "--source-repo",
                "/tmp/source",
                "--fake-session-manager",
            ],
        )

    assert result.exit_code == 0
    run_exec.assert_called_once_with(
        repo_root=None,
        prompt="find any bugs",
        source_repos=("/tmp/source",),
        approve_all=True,
        approver="exec",
        use_fake_session_manager=True,
    )
    render_exec.assert_called_once_with(fake_result)
    assert "Exec mode: completed" in result.stdout


def test_cli_e_alias_runs_noninteractive_runtime() -> None:
    fake_result = object()
    with patch.object(runtime_app, "run_exec", return_value=fake_result) as run_exec, patch.object(
        runtime_app,
        "_render_exec_result",
        return_value="Exec mode: completed",
    ):
        result = CliRunner().invoke(app, ["e", "find any bugs"])

    assert result.exit_code == 0
    run_exec.assert_called_once_with(
        repo_root=None,
        prompt="find any bugs",
        source_repos=(),
        approve_all=True,
        approver="exec",
        use_fake_session_manager=False,
    )


def test_cli_resume_command_is_not_public() -> None:
    result = CliRunner().invoke(app, ["resume"])

    assert result.exit_code == 2
    assert "No such command 'resume'" in result.output


def test_cli_exec_reports_backend_unavailable_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_exec",
        side_effect=RuntimeBackendUnavailableError(),
    ):
        result = CliRunner().invoke(app, ["exec", "find any bugs"])

    assert result.exit_code == 1
    assert "No Codex session backend" in result.stdout


def test_cli_exec_reports_seed_prompt_conflict_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_exec",
        side_effect=RuntimePromptConflictError(
            repo_root=Path("/tmp/repo"),
            existing_seed_prompt="existing mission",
            requested_seed_prompt="find any bugs",
        ),
    ):
        result = CliRunner().invoke(app, ["exec", "find any bugs"])

    assert result.exit_code == 1
    assert "existing mission" in result.stdout


def test_cli_exec_reports_launch_abort_cleanly() -> None:
    with patch.object(
        runtime_app,
        "run_exec",
        side_effect=RuntimeLaunchAbortedError("Launch aborted."),
    ):
        result = CliRunner().invoke(app, ["exec", "find any bugs"])

    assert result.exit_code == 1
    assert "Launch aborted." in result.stdout
