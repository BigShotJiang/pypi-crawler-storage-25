from __future__ import annotations

from ralphception.runtime.loop_planner import LoopPlanner, PlanGraph, PlanNode


def build_plan_graph(node_ids: list[str]) -> PlanGraph:
    return PlanGraph(
        task_id="task-1",
        plan_id="plan-1",
        nodes=tuple(
            PlanNode(
                plan_node_id=node_id,
                title=f"{node_id.title()} work",
                objective=f"Complete {node_id}",
                target_artifacts=(f"{node_id}-artifact",),
                stop_conditions=(f"{node_id} is complete",),
                output_contract=(f"publish {node_id} updates",),
            )
            for node_id in node_ids
        ),
    )


def test_loop_planner_emits_explicit_loop_definitions_from_plan_nodes() -> None:
    plan = build_plan_graph(["docs", "comments"])

    loops = LoopPlanner().plan_loops(plan)

    assert {loop.plan_node_id for loop in loops} == {"docs", "comments"}
    assert {loop.task_id for loop in loops} == {"task-1"}
    assert {loop.merge_strategy for loop in loops} == {"direct_update"}


def test_broad_plan_node_can_spawn_durable_subplan_and_child_loops() -> None:
    plan = build_plan_graph(["docs-quality"])

    expansion = LoopPlanner().expand_plan_node_into_subplan(plan, "docs-quality")

    assert expansion.subplan.plan_node_id == "docs-quality"
    assert len(expansion.child_loops) >= 2
    assert {loop.parent_loop_id for loop in expansion.child_loops} == {"loop-docs-quality"}
