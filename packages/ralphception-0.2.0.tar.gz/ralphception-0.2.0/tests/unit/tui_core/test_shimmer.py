from __future__ import annotations

from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette
from ralphception.tui_core.shimmer import shimmer_spans, spinner_span


def test_truecolor_shimmer_uses_codex_band_and_bold_styles() -> None:
    set_terminal_palette(fg=(128, 128, 128), bg=(255, 255, 255), color_level=ColorLevel.TRUECOLOR)
    try:
        spans = shimmer_spans("abcdefghijk", now=(15 / 31) * 2.0)
    finally:
        reset_terminal_palette()

    assert "".join(span.text for span in spans) == "abcdefghijk"
    assert spans[0].style.bold
    assert spans[5].style.bold
    assert spans[0].style.fg is not None
    assert spans[5].style.fg is not None


def test_fallback_shimmer_uses_dim_normal_and_bold_thresholds() -> None:
    set_terminal_palette(fg=(128, 128, 128), bg=(255, 255, 255), color_level=ColorLevel.ANSI16)
    try:
        spans = shimmer_spans("abcdefghijk", now=(15 / 31) * 2.0)
    finally:
        reset_terminal_palette()

    assert spans[0].style.dim
    assert not spans[0].style.bold
    assert not spans[2].style.dim
    assert not spans[2].style.bold
    assert spans[5].style.bold
    assert not spans[5].style.dim


def test_spinner_is_a_separate_low_level_primitive() -> None:
    set_terminal_palette(fg=(128, 128, 128), bg=(255, 255, 255), color_level=ColorLevel.ANSI16)
    try:
        spinner = spinner_span(animations_enabled=True, now=0.7)
        shimmer = shimmer_spans("•", now=0.7)[0]
    finally:
        reset_terminal_palette()

    assert spinner.text == "◦"
    assert spinner.style.dim
    assert shimmer.text == "•"
