from __future__ import annotations

from ralphception.tui_core.palette import (
    IndexedColor,
    ColorLevel,
    TerminalPalette,
    best_color,
    detect_color_level,
    palette_version,
    requery_terminal_palette,
    reset_terminal_palette,
)
from ralphception.tui_core.text import Style


def test_requery_terminal_palette_updates_value_and_version() -> None:
    reset_terminal_palette()

    assert palette_version() == 0

    first = requery_terminal_palette(fg=(1, 2, 3), bg=(4, 5, 6), color_level=ColorLevel.TRUECOLOR)
    second = requery_terminal_palette(fg=(7, 8, 9), bg=(10, 11, 12), color_level=ColorLevel.ANSI16)

    assert first == TerminalPalette(fg=(1, 2, 3), bg=(4, 5, 6), color_level=ColorLevel.TRUECOLOR)
    assert second == TerminalPalette(fg=(7, 8, 9), bg=(10, 11, 12), color_level=ColorLevel.ANSI16)
    assert palette_version() == 2


def test_detect_color_level_matches_terminal_env_buckets() -> None:
    assert detect_color_level(env={"COLORTERM": "truecolor"}, is_tty=True) == ColorLevel.TRUECOLOR
    assert detect_color_level(env={"TERM": "xterm-256color"}, is_tty=True) == ColorLevel.ANSI256
    assert detect_color_level(env={"TERM": "screen"}, is_tty=True) == ColorLevel.ANSI16
    assert detect_color_level(env={}, is_tty=False) == ColorLevel.UNKNOWN


def test_best_color_returns_exact_rgb_for_truecolor() -> None:
    assert best_color((1, 2, 3), color_level=ColorLevel.TRUECOLOR) == (1, 2, 3)


def test_best_color_returns_nearest_indexed_xterm_color_for_ansi256() -> None:
    color = best_color((0, 255, 255), color_level=ColorLevel.ANSI256)

    assert color == IndexedColor(51)


def test_best_color_falls_back_to_none_for_non_rgb_terminals() -> None:
    assert best_color((0, 255, 255), color_level=ColorLevel.ANSI16) is None
    assert best_color((0, 255, 255), color_level=ColorLevel.UNKNOWN) is None


def test_indexed_color_emits_ansi_256_sgr_sequences() -> None:
    style = Style(fg=IndexedColor(51), bg=IndexedColor(16))

    assert style.sgr_prefix() == "\x1b[38;5;51;48;5;16m"
