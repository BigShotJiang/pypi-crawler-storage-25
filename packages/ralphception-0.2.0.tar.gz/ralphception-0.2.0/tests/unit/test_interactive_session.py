from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from ralphception.models.runtime import Run
from ralphception.models.session import ChildSessionRef
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.storage.bootstrap import bootstrap_workspace


def test_interactive_session_marker_persists_thread_prompt_and_deferred_input(
    tmp_path: Path,
) -> None:
    from ralphception.runtime.interactive_session import (
        BlockedContinuationRef,
        DeferredInput,
        InteractiveSessionState,
        PendingPrompt,
        PromptResolution,
        TaskMessageClassification,
        load_interactive_session_state,
        write_interactive_session_state,
    )

    state = InteractiveSessionState(
        root_thread_id="thread-root",
        active_thread_id="thread-worker-1",
        active_task_id="task-1",
        session_id="session-1",
        plan_id="plan-1",
        loop_graph_id="loop-1",
        active_plan_node_id="plan-node-1",
        pending_prompts=[
            PendingPrompt(
                thread_id="thread-worker-1",
                owner_run_id="run-child-1",
                prompt_id="prompt-review-1",
                prompt_kind="review_decision",
                title="Review decision",
                question="Approve the change?",
                allowed_actions=("approve",),
                context={"scope": "spec"},
                blocked_continuation=BlockedContinuationRef(
                    thread_id="thread-worker-1",
                    run_id="run-child-1",
                ),
            )
        ],
        prompt_resolutions=[
            PromptResolution(
                thread_id="thread-worker-1",
                owner_run_id="run-child-1",
                prompt_id="prompt-review-1",
                action="approve",
                raw_user_reply="looks good",
                confidence=0.98,
            )
        ],
        deferred_inputs=[
            DeferredInput(thread_id="thread-worker-1", text="continue after approval")
        ],
        task_message_classifications=[
            TaskMessageClassification(
                thread_id="thread-worker-1",
                raw_user_text="also check comments",
                kind="in_task_follow_up",
                prompt_pending=False,
                active_task_summary="fix typos",
                confidence=0.91,
                clarifying_question=None,
            )
        ],
        bootstrap_source_repos=["/tmp/source-a"],
    )
    write_interactive_session_state(tmp_path, state)
    reloaded = load_interactive_session_state(tmp_path)

    assert reloaded == state


def test_interactive_session_state_clears_optional_identity_fields_on_write(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import (
        InteractiveSessionMarker,
        InteractiveSessionState,
        interactive_session_path,
        load_interactive_session_state,
        write_interactive_session_marker,
        write_interactive_session_state,
    )

    marker = InteractiveSessionMarker(
        root_run_id="run-root",
        active_run_id="run-child-1",
        resumable=True,
        blocking_surface_kind="review",
        updated_at=_utc_now(),
    )
    write_interactive_session_marker(tmp_path, marker)
    write_interactive_session_state(
        tmp_path,
        InteractiveSessionState(
            root_thread_id="thread-root",
            active_thread_id="thread-active",
            active_task_id="task-1",
            session_id="session-1",
            plan_id="plan-1",
            loop_graph_id="loop-1",
            active_plan_node_id="plan-node-1",
        ),
    )

    write_interactive_session_state(
        tmp_path,
        InteractiveSessionState(
            root_thread_id="thread-root",
            active_thread_id="thread-active",
        ),
    )

    payload = json.loads(interactive_session_path(tmp_path).read_text(encoding="utf-8"))
    reloaded = load_interactive_session_state(tmp_path)

    assert payload["root_run_id"] == "run-root"
    assert payload["active_run_id"] == "run-child-1"
    assert payload["resumable"] is True
    assert payload["blocking_surface_kind"] == "review"
    assert "active_task_id" not in payload
    assert "session_id" not in payload
    assert "plan_id" not in payload
    assert "loop_graph_id" not in payload
    assert "active_plan_node_id" not in payload
    assert reloaded.active_task_id is None
    assert reloaded.session_id is None
    assert reloaded.plan_id is None
    assert reloaded.loop_graph_id is None
    assert reloaded.active_plan_node_id is None


def test_resolver_classifies_fresh_workspace_without_runtime_state(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = bootstrap_workspace(tmp_path / "fresh-workspace")

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "fresh"
    assert state.root_run_id is None
    assert state.active_run_id is None


def test_resolver_prefers_interactive_session_marker_when_present(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = _prepare_workspace_with_resumable_root_run(tmp_path / "resumable-marker")
    marker_path = repo_root / ".ralphception" / "interactive-session.json"
    marker_path.write_text(
        json.dumps(
            {
                "root_run_id": "run-root",
                "active_run_id": "run-child-1",
                "resumable": True,
                "blocking_surface_kind": "review",
                "updated_at": _utc_now().isoformat(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    _write_run(
        repo_root,
        run_id="run-child-1",
        parent_run_id="run-root",
        goal="Inspect runtime adapter",
        thread_id="thread-child-1",
    )

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "resumable"
    assert state.root_run_id == "run-root"
    assert state.active_run_id == "run-child-1"
    assert state.blocking_surface_kind == "review"


def test_resolver_classifies_broken_resume_when_marker_points_to_non_resumable_run(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = _prepare_workspace_with_resumable_root_run(tmp_path / "broken-marker")
    marker_path = repo_root / ".ralphception" / "interactive-session.json"
    marker_path.write_text(
        json.dumps(
            {
                "root_run_id": "run-root",
                "active_run_id": "run-root",
                "resumable": True,
                "blocking_surface_kind": "review",
                "updated_at": _utc_now().isoformat(),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    _write_run(
        repo_root,
        run_id="run-root",
        parent_run_id=None,
        goal="Investigate shell failure",
        thread_id="thread-root",
        resumable=False,
    )

    original_marker = marker_path.read_text(encoding="utf-8")

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "broken_resume"
    assert state.root_run_id == "run-root"
    assert state.active_run_id == "run-root"
    assert marker_path.read_text(encoding="utf-8") == original_marker


def test_resolver_treats_runtime_state_without_marker_as_fresh(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = _prepare_workspace_with_resumable_root_run(tmp_path / "legacy-resume")

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "fresh"
    assert state.root_run_id is None
    assert state.active_run_id is None


def test_resolver_ignores_non_resumable_runtime_state_without_marker(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = _prepare_workspace_with_resumable_root_run(tmp_path / "legacy-broken")
    _write_run(
        repo_root,
        run_id="run-root",
        parent_run_id=None,
        goal="Investigate shell failure",
        thread_id="thread-root",
        resumable=False,
    )

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "fresh"
    assert state.root_run_id is None
    assert state.active_run_id is None


def test_resolver_ignores_conflicting_bootstrap_runtime_state_without_marker(tmp_path: Path) -> None:
    from ralphception.runtime.interactive_session import resolve_interactive_launch_state

    repo_root = _prepare_workspace_with_resumable_root_run(tmp_path / "conflicting-legacy")
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    _write_run(
        repo_root,
        run_id="run-root",
        parent_run_id=None,
        goal="Investigate shell failure",
        thread_id="thread-root",
        resumable=False,
    )
    (repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json").write_text(
        json.dumps(
            {
                "current_stage": "execute",
                "terminal_outcome": "failed",
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    state = resolve_interactive_launch_state(repo_root)

    assert state.kind == "fresh"
    assert state.root_run_id is None
    assert state.active_run_id is None


def _prepare_workspace_with_resumable_root_run(repo_root: Path) -> Path:
    repo_root = bootstrap_workspace(repo_root)
    _write_run(
        repo_root,
        run_id="run-root",
        parent_run_id=None,
        goal="Investigate shell failure",
        thread_id="thread-root",
    )
    return repo_root


def _write_run(
    repo_root: Path,
    *,
    run_id: str,
    parent_run_id: str | None,
    goal: str,
    thread_id: str,
    resumable: bool = True,
) -> None:
    now = _utc_now()
    run_path = repo_root / ".ralphception" / "runs" / run_id
    run_path.mkdir(parents=True, exist_ok=True)
    run = Run(
        run_id=run_id,
        parent_run_id=parent_run_id,
        supersedes_run_id=None,
        goal=goal,
        status="running",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id=run_id,
            codex_thread_id=thread_id,
            codex_session_id=f"session-{run_id}",
            workspace_path=str(repo_root),
            resumable=resumable,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    (run_path / "run.json").write_text(run.model_dump_json(indent=2), encoding="utf-8")


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)
