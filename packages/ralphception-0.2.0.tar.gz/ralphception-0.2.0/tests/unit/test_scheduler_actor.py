from __future__ import annotations

from ralphception.actor_runtime.scheduler_actor import SchedulerActor
from ralphception.actor_runtime.worker_actor import WorkerAssignment
from ralphception.models.todos import TodoNode


def test_scheduler_batches_multiple_compatible_todos_into_one_worker() -> None:
    scheduler = SchedulerActor(max_parallel_children=4)

    assignments = scheduler.plan_assignments(
        todos=[
            TodoNode(
                todo_id="todo-1",
                title="Implement parser artifact",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-1",
                scope_hints=["src/parser.py"],
            ),
            TodoNode(
                todo_id="todo-2",
                title="Add parser helpers",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-1",
                scope_hints=["src/parser_helpers.py"],
            ),
        ],
        active_workers=[],
    )

    assert len(assignments) == 1
    assert assignments[0].todo_ids == ["todo-1", "todo-2"]
    assert assignments[0].claimed_commit_intent_ids == ["intent-1"]


def test_scheduler_respects_max_parallel_children() -> None:
    scheduler = SchedulerActor(max_parallel_children=2)

    assignments = scheduler.plan_assignments(
        todos=[
            TodoNode(
                todo_id="todo-1",
                title="Implement parser artifact",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-1",
                scope_hints=["src/parser.py"],
            ),
            TodoNode(
                todo_id="todo-2",
                title="Add parser regression test",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-2",
                scope_hints=["tests/test_parser.py"],
            ),
            TodoNode(
                todo_id="todo-3",
                title="Document parser behavior",
                dependency_ids=[],
                status="ready",
                commit_intent_id="intent-3",
                scope_hints=["docs/parser.md"],
            ),
        ],
        active_workers=[
            WorkerAssignment(
                worker_id="worker-0",
                run_id="run-worker-0",
                goal="Existing work",
                todo_ids=["todo-existing"],
                claimed_commit_intent_ids=["intent-existing"],
            )
        ],
    )

    assert len(assignments) == 1
    assert assignments[0].todo_ids == ["todo-1"]
