from __future__ import annotations

from ralphception.actor_runtime.merge_actor import MergeAgent, WorkerCandidate
from ralphception.models.commit_intents import CommitIntent


def test_merge_agent_selects_best_candidate_for_intent() -> None:
    intent = CommitIntent(
        intent_id="intent-1",
        message="feat: add scheduler actor",
        todo_ids=["todo-1"],
        ordering_after=[],
    )
    agent = MergeAgent()

    decision = agent.choose_candidate(
        intent,
        [
            WorkerCandidate(
                candidate_id="candidate-a",
                commit_intent_id="intent-1",
                summary="Initial implementation",
                touched_paths=["src/ralphception/actor_runtime/scheduler_actor.py"],
                verification_passed=True,
            ),
            WorkerCandidate(
                candidate_id="candidate-b",
                commit_intent_id="intent-1",
                summary="Broader implementation with tests",
                touched_paths=[
                    "src/ralphception/actor_runtime/scheduler_actor.py",
                    "tests/unit/test_scheduler_actor.py",
                ],
                verification_passed=True,
            ),
        ],
    )

    assert decision.selected_candidate_id == "candidate-b"
    assert decision.rejected_candidate_ids == ["candidate-a"]
    assert decision.commit_message == "feat: add scheduler actor"
