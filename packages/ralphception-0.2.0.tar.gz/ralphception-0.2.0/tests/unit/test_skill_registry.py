from __future__ import annotations

from pathlib import Path
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.models.artifacts import ArtifactRef
from ralphception.skills.contracts import (
    SkillArtifactUpdate,
    SkillInvocation,
    SkillResult,
)
from ralphception.skills.registry import BUNDLED_SKILL_IDS, BundledSkillAsset, SkillRegistry


def test_registry_prefers_exact_repo_override(tmp_path: Path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "# override")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "repo"
    assert resolved.warnings == []
    assert resolved.markdown_body == "# override"


def test_invalid_override_falls_back_to_bundled_skill(tmp_path: Path) -> None:
    write_skill(tmp_path / ".ralphception/skills/spec.write.md", "")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "bundled"
    assert resolved.warnings
    assert resolved.warnings[0].code == "override_invalid"


def test_unreadable_override_falls_back_to_bundled_skill(tmp_path: Path) -> None:
    override_path = tmp_path / ".ralphception/skills/spec.write.md"
    override_path.parent.mkdir(parents=True, exist_ok=True)
    override_path.write_bytes(b"\xff")

    registry = SkillRegistry(tmp_path)
    resolved = registry.load("spec.write")

    assert resolved.source == "bundled"
    assert resolved.warnings
    assert resolved.warnings[0].code == "override_unreadable"


@pytest.mark.parametrize("skill_id", BUNDLED_SKILL_IDS)
def test_registry_loads_non_empty_bundled_skill_assets(skill_id: str, tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)
    resolved = registry.load(skill_id)

    assert resolved.source == "bundled"
    assert resolved.markdown_body.strip()


def test_registry_rejects_unknown_skill_id(tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)

    with pytest.raises(ValidationError):
        registry.load("unknown.skill")


def test_registry_rejects_duplicate_bundled_skill_ids(tmp_path: Path) -> None:
    with pytest.raises(ValidationError):
        SkillRegistry(
            tmp_path,
            bundled_assets=[
                BundledSkillAsset(skill_id="spec.write", resource_name="spec.write.md"),
                BundledSkillAsset(skill_id="spec.write", resource_name="plan.write.md"),
            ],
        )


def test_stage_skills_exist_in_registry(tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)

    assert registry.load("brainstorm.default").markdown_body
    assert registry.load("spec.write").markdown_body
    assert registry.load("plan.write").markdown_body
    assert registry.load("execute.task").markdown_body
    assert registry.load("audit.review").markdown_body


def test_stage_skills_carry_ralphception_stage_discipline(tmp_path: Path) -> None:
    registry = SkillRegistry(tmp_path)

    startup_text = registry.load("brainstorm.default").markdown_body
    spec_text = registry.load("spec.write").markdown_body
    plan_text = registry.load("plan.write").markdown_body
    execute_text = registry.load("execute.task").markdown_body
    audit_text = registry.load("audit.review").markdown_body
    merge_text = registry.load("merge.coordinator").markdown_body
    summary_text = registry.load("run.summary").markdown_body

    assert "## When To Use" in startup_text
    assert "## Anti-Pattern: \"This Is Too Simple To Need Intake\"" in startup_text
    assert "Inspect the repo context before asking a question." in startup_text
    assert "If the task actually spans multiple independent subsystems" in startup_text
    assert "Do not ask the user for permission to inspect files in the repo." in startup_text
    assert "Prefer the minimum number of questions needed to make the task safe and clear." in startup_text
    assert "## Completion Bar" in startup_text
    assert "Do not write artifacts, plans, todos, or code in this stage." in startup_text
    assert "## Required Structure" in spec_text
    assert "Turn the intake into a repo-local PRD" in spec_text
    assert "Repo Context" in spec_text
    assert "## Design for Isolation and Clarity" in spec_text
    assert "If the requested work is still too broad for one clean plan" in spec_text
    assert "## Self-Review" in spec_text
    assert "## File Map" in plan_text
    assert "assume the later loop worker has zero context" in plan_text
    assert "# [Feature Name] Implementation Plan" in plan_text
    assert "## Bite-Sized Task Granularity" in plan_text
    assert "## Loop-Safe Slice Design" in plan_text
    assert "## Task Structure" in plan_text
    assert "### Task N: [Component Name]" in plan_text
    assert "Frequent commits" in plan_text
    assert "## Ralphception Outputs" in plan_text
    assert "execution_goal" in plan_text
    assert "verification_commands" in plan_text
    assert "todos" in plan_text
    assert "commit_intents" in plan_text
    assert "execution_policy" in plan_text
    assert "## No Placeholders" in plan_text
    assert "Write the failing test or verification first when behavior is changing." in plan_text
    assert "## Self-Review" in plan_text
    assert "Spec coverage" in plan_text
    assert "Type consistency" in plan_text
    assert "Follow the red-green-refactor spirit of TDD." in execute_text
    assert "## The Iron Law" in execute_text
    assert "NO PRODUCTION CODE WITHOUT A FAILING TEST OR VERIFICATION FIRST" in execute_text
    assert "## Verification Gate" in execute_text
    assert "NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE" in execute_text
    assert "Do not claim completion without fresh verification evidence." in execute_text
    assert "## Common Mistakes" in execute_text
    assert "List findings first, ordered by severity." in audit_text
    assert "## Severity Ladder" in audit_text
    assert "## Reopen vs Complete" in audit_text
    assert "Cite repo-local evidence for every finding." in audit_text
    assert "If there are no findings, write the empty findings payload plainly and stop." in audit_text
    assert "## Merge Readiness Checklist" in merge_text
    assert "Evidence before merge." in merge_text
    assert "## Decision Ladder" in merge_text
    assert "## Blocking Signals" in merge_text
    assert "## Output Contract" in merge_text
    assert "## Required Structure" in summary_text
    assert "## Evidence Ladder" in summary_text
    assert "## Ralphception-Specific Discipline" in summary_text
    assert "What single next action should happen now?" in summary_text


def test_skill_invocation_requires_known_expected_output_mode() -> None:
    with pytest.raises(ValidationError):
        SkillInvocation(
            run_id="run-1",
            stage_id="stage-1",
            goal="Create the plan",
            current_task_description="Write the implementation plan",
            target_repo_path=Path("/repo"),
            source_repo_paths=[Path("/repo")],
            relevant_artifact_refs=[make_artifact_ref()],
            effective_config_snapshot={"codex": {"model": "gpt-5.4"}},
            expected_output_mode=cast(Any, "outline"),
        )


def test_skill_result_requires_artifact_update_schema() -> None:
    with pytest.raises(ValidationError):
        SkillResult(
            status="success",
            artifact_updates=cast(Any, [{"apply_mode": "replace"}]),
            suggested_next=[],
            findings=[],
            markdown_body="Produced a plan.",
        )


def test_skill_result_rejects_unknown_apply_mode() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode=cast(Any, "merge"),
            content="new body",
        )


def test_skill_result_rejects_invalid_structured_patch_shape() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode="structured_patch",
            structured_patch=cast(
                Any,
                [
                    {
                        "op": "replace_range",
                        "start_line": 5,
                        "end_line": 4,
                        "content": "updated block",
                    }
                ],
            ),
        )


def test_skill_result_rejects_invalid_insert_after_patch_shape() -> None:
    with pytest.raises(ValidationError):
        SkillArtifactUpdate(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/task.md",
            apply_mode="structured_patch",
            structured_patch=cast(
                Any,
                [
                    {
                        "op": "insert_after",
                        "start_line": 5,
                        "end_line": 6,
                        "content": "new line",
                    }
                ],
            ),
        )


def write_skill(path: Path, markdown_body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(markdown_body, encoding="utf-8")


def make_artifact_ref() -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        artifact_version=1,
        content_hash="sha256:spec",
    )
