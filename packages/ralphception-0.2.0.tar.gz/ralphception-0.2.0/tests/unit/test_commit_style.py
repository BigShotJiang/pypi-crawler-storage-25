from __future__ import annotations

import subprocess
from pathlib import Path

from ralphception.git.commit_style import (
    build_commit_style_prompt_hint,
    detect_commit_style,
    normalize_commit_message_for_repo,
)


def test_detect_commit_style_prefers_recent_conventional_subjects(tmp_path: Path) -> None:
    repo_root = _init_repo(tmp_path / "repo")
    _commit(repo_root, "fix: restore codex tui working footer parity")
    _commit(repo_root, "refactor: extract tui core primitives")
    _commit(repo_root, "docs: define tui core layering")
    _commit(
        repo_root,
        "feat: Goal: fix typos across the repository. Scope: the whole repo. Constraints: keep the work focused.",
    )

    profile = detect_commit_style(repo_root)

    assert profile.conventional is True
    assert profile.recent_examples == (
        "docs: define tui core layering",
        "refactor: extract tui core primitives",
        "fix: restore codex tui working footer parity",
    )


def test_normalize_commit_message_for_repo_summarizes_verbose_goal_blob(tmp_path: Path) -> None:
    repo_root = _init_repo(tmp_path / "repo")
    _commit(repo_root, "fix: restore codex tui working footer parity")
    _commit(repo_root, "refactor: extract tui core primitives")
    _commit(repo_root, "docs: define tui core layering")

    message = (
        "feat: Goal: fix typos across the repository. Scope: the whole repo; no narrower file, "
        "folder, or subsystem boundaries were provided. Constraints: proceed repo-wide with normal "
        "repo-local edits and keep the work focused on typo correction rather than unrelated changes. "
        "Success criteria: typo fixes are applied wherever needed across the repo and the resulting "
        "text/code is left in a corrected, consistent state"
    )

    normalized = normalize_commit_message_for_repo(repo_root, message, fallback_type="feat")

    assert normalized == "feat: fix typos across the repository"


def test_build_commit_style_prompt_hint_includes_recent_examples(tmp_path: Path) -> None:
    repo_root = _init_repo(tmp_path / "repo")
    _commit(repo_root, "fix: restore codex tui working footer parity")
    _commit(repo_root, "refactor: extract tui core primitives")

    hint = build_commit_style_prompt_hint(repo_root)

    assert "Match this repository's recent commit-subject style." in hint
    assert "- refactor: extract tui core primitives" in hint
    assert "- fix: restore codex tui working footer parity" in hint
    assert "Goal/Scope/Constraints/Success criteria" in hint


def _init_repo(repo_root: Path) -> Path:
    repo_root.mkdir()
    _git(repo_root, "init", "-b", "main")
    _git(repo_root, "config", "user.name", "Test User")
    _git(repo_root, "config", "user.email", "test@example.com")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    _git(repo_root, "add", "README.md")
    _git(repo_root, "commit", "-m", "init")
    return repo_root


def _commit(repo_root: Path, subject: str) -> None:
    path = repo_root / f"{abs(hash(subject))}.txt"
    path.write_text(f"{subject}\n", encoding="utf-8")
    _git(repo_root, "add", path.name)
    _git(repo_root, "commit", "-m", subject)


def _git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
