from datetime import datetime, timezone
from typing import Any, cast

import pytest
from pydantic import ValidationError

from ralphception.models.artifacts import ArtifactRef, TodoArtifact
from ralphception.models.events import (
    REQUIRED_EVENT_TYPES,
    AgentEventPayload,
    ArtifactEventPayload,
    AuditEventPayload,
    BundleEventPayload,
    Event,
    MergeEventPayload,
    RunEventPayload,
    StageEventPayload,
    TaskEventPayload,
    VerificationEventPayload,
)
from ralphception.models.runtime import (
    ApprovalRecord,
    Checkpoint,
    ChildAssignment,
    ExecutionBundle,
    Run,
    Stage,
    Task,
)


def test_artifact_and_todo_models_accept_required_fields() -> None:
    artifact_ref = make_artifact_ref()

    todo = TodoArtifact(
        todo_id="todo-1",
        title="Ship the durable runtime models",
        priority="P1",
        status="open",
        bundle_version=3,
        artifact_refs=[artifact_ref],
    )

    assert todo.priority == "P1"
    assert todo.status == "open"
    assert todo.artifact_refs == [artifact_ref]


def test_artifact_and_todo_version_fields_must_be_positive() -> None:
    with pytest.raises(ValidationError):
        ArtifactRef(
            artifact_kind="plan",
            artifact_path=".ralphception/plans/runtime-plan.md",
            artifact_version=0,
            content_hash="sha256:plan",
        )

    with pytest.raises(ValidationError):
        TodoArtifact(
            todo_id="todo-1",
            title="Ship the durable runtime models",
            priority="P1",
            status="open",
            bundle_version=0,
            artifact_refs=[make_artifact_ref()],
        )


def test_run_requires_session_reference_once_started() -> None:
    with pytest.raises(ValidationError):
        Run(
            run_id="run-1",
            parent_run_id=None,
            supersedes_run_id=None,
            goal="Coordinate the root run",
            status="running",
            stage_ids=["stage-1"],
            config_snapshot={"codex": {"model": "gpt-5.4"}},
            codex_session_ref=None,
            artifact_refs=[make_artifact_ref()],
            created_at=utc_now(),
            updated_at=utc_now(),
        )


def test_run_allows_missing_session_reference_before_startup() -> None:
    run = Run(
        run_id="run-1",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Coordinate the root run",
        status="pending",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=None,
        artifact_refs=[make_artifact_ref()],
        created_at=utc_now(),
        updated_at=utc_now(),
    )

    assert run.codex_session_ref is None


def test_run_allows_missing_session_reference_for_startup_failure() -> None:
    run = Run(
        run_id="run-1",
        parent_run_id=None,
        supersedes_run_id=None,
        goal="Coordinate the root run",
        status="failed",
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=None,
        artifact_refs=[make_artifact_ref()],
        created_at=utc_now(),
        updated_at=utc_now(),
    )

    assert run.status == "failed"


def test_run_rejects_missing_session_reference_after_orchestration_starts() -> None:
    with pytest.raises(ValidationError):
        Run(
            run_id="run-1",
            parent_run_id=None,
            supersedes_run_id=None,
            goal="Coordinate the root run",
            status="failed",
            stage_ids=["stage-1"],
            config_snapshot={"codex": {"model": "gpt-5.4"}},
            codex_session_ref=None,
            artifact_refs=[make_artifact_ref()],
            created_at=utc_now(),
            updated_at=utc_now(),
        )


def test_run_rejects_aborted_without_session_reference() -> None:
    with pytest.raises(ValidationError):
        Run(
            run_id="run-1",
            parent_run_id=None,
            supersedes_run_id=None,
            goal="Coordinate the root run",
            status="aborted",
            stage_ids=[],
            config_snapshot={"codex": {"model": "gpt-5.4"}},
            codex_session_ref=None,
            artifact_refs=[make_artifact_ref()],
            created_at=utc_now(),
            updated_at=utc_now(),
        )


def test_stage_and_task_lifecycle_timestamps_follow_status() -> None:
    with pytest.raises(ValidationError):
        Stage(
            stage_id="stage-1",
            run_id="run-1",
            stage_kind="plan",
            status="running",
            task_ids=["task-1"],
            started_at=None,
            completed_at=None,
        )

    with pytest.raises(ValidationError):
        Task(
            task_id="task-1",
            run_id="run-1",
            stage_id="stage-1",
            task_kind="turn",
            status="succeeded",
            owner="workflow_engine",
            input_refs=[make_artifact_ref()],
            output_refs=[make_artifact_ref()],
            started_at=utc_now(),
            completed_at=None,
        )


def test_pending_stage_rejects_started_at_before_execution_begins() -> None:
    with pytest.raises(ValidationError):
        Stage(
            stage_id="stage-pending",
            run_id="run-1",
            stage_kind="plan",
            status="pending",
            task_ids=[],
            started_at=utc_now(),
            completed_at=None,
        )


def test_stage_allows_awaiting_approval_before_execution_starts() -> None:
    stage = Stage(
        stage_id="stage-1",
        run_id="run-1",
        stage_kind="plan",
        status="awaiting_approval",
        task_ids=[],
        started_at=None,
        completed_at=None,
    )

    assert stage.started_at is None
    assert stage.completed_at is None


def test_aborted_stage_allows_pre_start_completion() -> None:
    stage = Stage(
        stage_id="stage-aborted",
        run_id="run-1",
        stage_kind="plan",
        status="aborted",
        task_ids=[],
        started_at=None,
        completed_at=utc_now(),
    )

    assert stage.started_at is None
    assert stage.completed_at is not None


def test_terminal_stage_still_requires_execution_timestamps() -> None:
    with pytest.raises(ValidationError):
        Stage(
            stage_id="stage-1",
            run_id="run-1",
            stage_kind="plan",
            status="completed",
            task_ids=["task-1"],
            started_at=None,
            completed_at=utc_now(),
        )

    with pytest.raises(ValidationError):
        Stage(
            stage_id="stage-2",
            run_id="run-1",
            stage_kind="plan",
            status="failed",
            task_ids=["task-1"],
            started_at=utc_now(),
            completed_at=None,
        )


@pytest.mark.parametrize("status", ["completed", "failed", "aborted"])
def test_terminal_stage_rejects_completed_before_started(status: str) -> None:
    with pytest.raises(ValidationError):
        Stage(
            stage_id=f"stage-{status}",
            run_id="run-1",
            stage_kind="plan",
            status=cast(Any, status),
            task_ids=["task-1"],
            started_at=datetime(2026, 3, 15, 21, 0, tzinfo=timezone.utc),
            completed_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        )


def test_task_allows_pre_start_blocked_and_session_lost_states() -> None:
    blocked_task = Task(
        task_id="task-1",
        run_id="run-1",
        stage_id="stage-1",
        task_kind="turn",
        status="blocked",
        owner="workflow_engine",
        input_refs=[make_artifact_ref()],
        output_refs=[],
        started_at=None,
        completed_at=None,
    )
    lost_task = Task(
        task_id="task-2",
        run_id="run-1",
        stage_id="stage-1",
        task_kind="turn",
        status="session_lost",
        owner="workflow_engine",
        input_refs=[make_artifact_ref()],
        output_refs=[],
        started_at=None,
        completed_at=None,
    )

    assert blocked_task.started_at is None
    assert lost_task.started_at is None


@pytest.mark.parametrize("status", ["failed", "aborted"])
def test_terminal_task_pre_start_failures_require_only_completed_at(status: str) -> None:
    task = Task(
        task_id="task-1",
        run_id="run-1",
        stage_id="stage-1",
        task_kind="turn",
        status=cast(Any, status),
        owner="workflow_engine",
        input_refs=[make_artifact_ref()],
        output_refs=[],
        started_at=None,
        completed_at=utc_now(),
    )

    assert task.started_at is None
    assert task.completed_at is not None

    with pytest.raises(ValidationError):
        Task(
            task_id="task-2",
            run_id="run-1",
            stage_id="stage-1",
            task_kind="turn",
            status=cast(Any, status),
            owner="workflow_engine",
            input_refs=[make_artifact_ref()],
            output_refs=[],
            started_at=None,
            completed_at=None,
        )


def test_succeeded_task_still_requires_started_at() -> None:
    with pytest.raises(ValidationError):
        Task(
            task_id="task-1",
            run_id="run-1",
            stage_id="stage-1",
            task_kind="turn",
            status="succeeded",
            owner="workflow_engine",
            input_refs=[make_artifact_ref()],
            output_refs=[make_artifact_ref()],
            started_at=None,
            completed_at=utc_now(),
        )


@pytest.mark.parametrize("status", ["succeeded", "failed", "aborted"])
def test_terminal_task_rejects_completed_before_started(status: str) -> None:
    with pytest.raises(ValidationError):
        Task(
            task_id=f"task-{status}",
            run_id="run-1",
            stage_id="stage-1",
            task_kind="turn",
            status=cast(Any, status),
            owner="workflow_engine",
            input_refs=[make_artifact_ref()],
            output_refs=[make_artifact_ref()],
            started_at=datetime(2026, 3, 15, 21, 0, tzinfo=timezone.utc),
            completed_at=datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc),
        )


def test_verification_task_requires_exactly_one_input_and_output_ref() -> None:
    verification_task = Task(
        task_id="task-verify-1",
        run_id="run-1",
        stage_id="stage-verify",
        task_kind="verification",
        status="succeeded",
        owner="workflow_engine",
        input_refs=[make_verification_spec_artifact_ref()],
        output_refs=[make_verification_artifact_ref()],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert len(verification_task.input_refs) == 1
    assert len(verification_task.output_refs) == 1


def test_verification_task_rejects_invalid_input_artifact_kind() -> None:
    with pytest.raises(ValidationError):
        Task(
            task_id="task-verify-input",
            run_id="run-1",
            stage_id="stage-verify",
            task_kind="verification",
            status="succeeded",
            owner="workflow_engine",
            input_refs=[make_artifact_ref()],
            output_refs=[make_verification_artifact_ref()],
            started_at=utc_now(),
            completed_at=utc_now(),
        )


def test_verification_task_rejects_invalid_output_artifact_kind() -> None:
    with pytest.raises(ValidationError):
        Task(
            task_id="task-verify-output",
            run_id="run-1",
            stage_id="stage-verify",
            task_kind="verification",
            status="succeeded",
            owner="workflow_engine",
            input_refs=[make_verification_spec_artifact_ref()],
            output_refs=[make_artifact_ref()],
            started_at=utc_now(),
            completed_at=utc_now(),
        )


@pytest.mark.parametrize(
    ("input_count", "output_count"),
    [
        (0, 1),
        (2, 1),
        (1, 0),
        (1, 2),
    ],
)
def test_verification_task_rejects_invalid_ref_cardinality(
    input_count: int,
    output_count: int,
) -> None:
    input_refs = [
        make_verification_spec_artifact_ref(f"verification-spec-{index}")
        for index in range(input_count)
    ]
    output_refs = [
        make_verification_artifact_ref(f"verification-{index}")
        for index in range(output_count)
    ]

    with pytest.raises(ValidationError):
        Task(
            task_id="task-verify-1",
            run_id="run-1",
            stage_id="stage-verify",
            task_kind="verification",
            status="succeeded",
            owner="workflow_engine",
            input_refs=input_refs,
            output_refs=output_refs,
            started_at=utc_now(),
            completed_at=utc_now(),
        )


def test_execution_bundle_rejects_unknown_state() -> None:
    with pytest.raises(ValidationError):
        ExecutionBundle(
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=1,
            state=cast(Any, "bad"),
            artifact_refs=[make_artifact_ref()],
            base_bundle_id=None,
            scope_hash="sha256:scope",
            created_at=utc_now(),
            assigned_run_ids=[],
        )


def test_derived_execution_bundle_requires_base_bundle_id() -> None:
    with pytest.raises(ValidationError):
        ExecutionBundle(
            bundle_id="bundle-derived",
            run_id="run-1",
            bundle_version=3,
            state="derived_in_scope",
            artifact_refs=[make_artifact_ref()],
            base_bundle_id=None,
            scope_hash="sha256:scope",
            created_at=utc_now(),
            assigned_run_ids=["run-child-1"],
        )

    draft_bundle = ExecutionBundle(
        bundle_id="bundle-draft",
        run_id="run-1",
        bundle_version=1,
        state="draft",
        artifact_refs=[make_artifact_ref()],
        base_bundle_id=None,
        scope_hash="sha256:scope",
        created_at=utc_now(),
        assigned_run_ids=[],
    )
    approved_bundle = ExecutionBundle(
        bundle_id="bundle-approved",
        run_id="run-1",
        bundle_version=2,
        state="approved",
        artifact_refs=[make_artifact_ref()],
        base_bundle_id=None,
        scope_hash="sha256:scope",
        created_at=utc_now(),
        assigned_run_ids=[],
    )

    assert draft_bundle.base_bundle_id is None
    assert approved_bundle.base_bundle_id is None


@pytest.mark.parametrize("state", ["draft", "approved", "awaiting_approval"])
def test_non_derived_execution_bundles_reject_base_bundle_id(state: str) -> None:
    with pytest.raises(ValidationError):
        ExecutionBundle(
            bundle_id=f"bundle-{state}",
            run_id="run-1",
            bundle_version=2,
            state=cast(Any, state),
            artifact_refs=[make_artifact_ref()],
            base_bundle_id="bundle-root",
            scope_hash="sha256:scope",
            created_at=utc_now(),
            assigned_run_ids=[],
        )


def test_superseded_execution_bundle_may_retain_base_bundle_id() -> None:
    bundle = ExecutionBundle(
        bundle_id="bundle-superseded",
        run_id="run-1",
        bundle_version=2,
        state="superseded",
        artifact_refs=[make_artifact_ref()],
        base_bundle_id="bundle-root",
        scope_hash="sha256:scope",
        created_at=utc_now(),
        assigned_run_ids=[],
    )

    assert bundle.base_bundle_id == "bundle-root"


def test_finding_waiver_requires_rationale() -> None:
    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-1",
            run_id="run-1",
            approval_kind="finding_waiver",
            artifact_bundle_refs=None,
            bundle_version=None,
            scope_hash=None,
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=["finding-1"],
            rationale=None,
        )


def test_finding_waiver_allows_optional_bundle_context() -> None:
    approval = ApprovalRecord(
        approval_id="approval-waiver-1",
        run_id="run-1",
        approval_kind="finding_waiver",
        artifact_bundle_refs=[make_artifact_ref()],
        bundle_version=3,
        scope_hash="sha256:scope",
        approved_at=utc_now(),
        approver="user",
        waived_finding_ids=["finding-1"],
        rationale="Waive this finding for now.",
    )

    assert approval.artifact_bundle_refs is not None
    assert approval.bundle_version == 3
    assert approval.scope_hash == "sha256:scope"


@pytest.mark.parametrize(
    ("include_refs", "bundle_version", "scope_hash"),
    [
        (True, None, "sha256:scope"),
        (True, 3, None),
        (None, 3, "sha256:scope"),
    ],
)
def test_finding_waiver_rejects_partial_bundle_context(
    include_refs: bool | None,
    bundle_version: int | None,
    scope_hash: str | None,
) -> None:
    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-waiver-partial",
            run_id="run-1",
            approval_kind="finding_waiver",
            artifact_bundle_refs=[make_artifact_ref("waiver-context")] if include_refs else None,
            bundle_version=bundle_version,
            scope_hash=scope_hash,
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=["finding-1"],
            rationale="Waive this finding for now.",
        )


def test_finding_waiver_rejects_blank_waived_finding_ids() -> None:
    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-waiver-2",
            run_id="run-1",
            approval_kind="finding_waiver",
            artifact_bundle_refs=None,
            bundle_version=None,
            scope_hash=None,
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=["finding-1", "   "],
            rationale="Waive this finding for now.",
        )


def test_non_waiver_approval_requires_bundle_and_forbids_waiver_fields() -> None:
    artifact_ref = make_artifact_ref()

    approval = ApprovalRecord(
        approval_id="approval-1",
        run_id="run-1",
        approval_kind="execution_bundle",
        artifact_bundle_refs=[artifact_ref],
        bundle_version=3,
        scope_hash="sha256:scope",
        approved_at=utc_now(),
        approver="user",
        waived_finding_ids=None,
        rationale=None,
    )

    assert approval.artifact_bundle_refs == [artifact_ref]

    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-2",
            run_id="run-1",
            approval_kind="spec_review",
            artifact_bundle_refs=[artifact_ref],
            bundle_version=3,
            scope_hash="sha256:scope",
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=["finding-1"],
            rationale="waivers are not valid here",
        )


@pytest.mark.parametrize("approval_kind", ["spec_review", "execution_bundle"])
def test_non_waiver_approval_rejects_empty_artifact_bundle_refs(
    approval_kind: str,
) -> None:
    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-empty",
            run_id="run-1",
            approval_kind=cast(Any, approval_kind),
            artifact_bundle_refs=[],
            bundle_version=3,
            scope_hash="sha256:scope",
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=None,
            rationale=None,
        )


def test_spec_review_approval_accepts_non_empty_artifact_bundle_refs() -> None:
    approval = ApprovalRecord(
        approval_id="approval-spec",
        run_id="run-1",
        approval_kind="spec_review",
        artifact_bundle_refs=[make_artifact_ref()],
        bundle_version=3,
        scope_hash="sha256:scope",
        approved_at=utc_now(),
        approver="user",
        waived_finding_ids=None,
        rationale=None,
    )

    assert len(approval.artifact_bundle_refs or []) == 1


def test_runtime_bundle_version_fields_must_be_positive() -> None:
    artifact_ref = make_artifact_ref()

    with pytest.raises(ValidationError):
        ChildAssignment(
            assignment_id="assignment-1",
            goal="Implement durable models",
            acceptance_criteria_refs=[artifact_ref],
            dependency_refs=[artifact_ref],
            bundle_version=0,
        )

    with pytest.raises(ValidationError):
        ExecutionBundle(
            bundle_id="bundle-1",
            run_id="run-1",
            bundle_version=0,
            state="draft",
            artifact_refs=[artifact_ref],
            base_bundle_id=None,
            scope_hash="sha256:scope",
            created_at=utc_now(),
            assigned_run_ids=[],
        )

    with pytest.raises(ValidationError):
        ApprovalRecord(
            approval_id="approval-spec",
            run_id="run-1",
            approval_kind="spec_review",
            artifact_bundle_refs=[artifact_ref],
            bundle_version=0,
            scope_hash="sha256:scope",
            approved_at=utc_now(),
            approver="user",
            waived_finding_ids=None,
            rationale=None,
        )

    with pytest.raises(ValidationError):
        Checkpoint(
            checkpoint_id="checkpoint-1",
            run_id="run-1",
            checkpoint_kind="safe_point",
            event_offsets={"run-1": 12},
            bundle_version=-1,
            authoritative_root="/repo",
            active_worktrees=["/repo/.worktrees/child-a"],
            created_at=utc_now(),
        )


def test_checkpoint_and_child_assignment_accept_required_fields() -> None:
    artifact_ref = make_artifact_ref()

    assignment = ChildAssignment(
        assignment_id="assignment-1",
        goal="Implement durable models",
        acceptance_criteria_refs=[artifact_ref],
        dependency_refs=[artifact_ref],
        bundle_version=3,
    )
    checkpoint = Checkpoint(
        checkpoint_id="checkpoint-1",
        run_id="run-1",
        checkpoint_kind="safe_point",
        event_offsets={"run-1": 12},
        bundle_version=3,
        authoritative_root="/repo",
        active_worktrees=["/repo/.worktrees/child-a"],
        created_at=utc_now(),
    )

    assert assignment.bundle_version == 3
    assert checkpoint.event_offsets["run-1"] == 12


def test_checkpoint_rejects_negative_event_offsets() -> None:
    with pytest.raises(ValidationError):
        Checkpoint(
            checkpoint_id="checkpoint-1",
            run_id="run-1",
            checkpoint_kind="safe_point",
            event_offsets={"run-1": -1},
            bundle_version=3,
            authoritative_root="/repo",
            active_worktrees=["/repo/.worktrees/child-a"],
            created_at=utc_now(),
        )


def test_event_payload_helpers_validate_required_fields_directly() -> None:
    run_payload = RunEventPayload(
        goal="Coordinate the root run",
        parent_run_id=None,
    )
    bundle_payload = BundleEventPayload(bundle_id="bundle-1", bundle_version=3)
    stage_payload = StageEventPayload(stage_kind="plan")
    task_payload = TaskEventPayload(task_kind="turn")
    verification_payload = VerificationEventPayload(
        verification_id="verification-1",
        status="passed",
    )
    agent_payload = AgentEventPayload(
        agent_id="agent-1",
        parent_task_id="task-1",
    )
    artifact_payload = ArtifactEventPayload(
        artifact_path=".ralphception/plans/runtime-plan.md",
        artifact_kind="plan",
        producing_run_id="run-1",
    )
    merge_payload = MergeEventPayload(child_run_id="run-child-1")
    audit_payload = AuditEventPayload(
        finding_id="finding-1",
        severity="P1",
        kind="test_gap",
    )

    assert run_payload.parent_run_id is None
    assert bundle_payload.bundle_version == 3
    assert stage_payload.stage_kind == "plan"
    assert task_payload.task_kind == "turn"
    assert verification_payload.status == "passed"
    assert agent_payload.agent_id == "agent-1"
    assert artifact_payload.producing_run_id == "run-1"
    assert merge_payload.child_run_id == "run-child-1"
    assert audit_payload.kind == "test_gap"

    with pytest.raises(ValidationError):
        RunEventPayload.model_validate(cast(Any, {"goal": "Coordinate the root run"}))

    with pytest.raises(ValidationError):
        VerificationEventPayload.model_validate(
            cast(Any, {"verification_id": "verification-1"}),
        )

    with pytest.raises(ValidationError):
        BundleEventPayload.model_validate(cast(Any, {}))

    with pytest.raises(ValidationError):
        MergeEventPayload.model_validate(cast(Any, {}))


@pytest.mark.parametrize("bundle_version", [0, -1])
def test_bundle_events_require_positive_bundle_version(bundle_version: int) -> None:
    with pytest.raises(ValidationError):
        BundleEventPayload.model_validate(
            cast(Any, {"bundle_id": "bundle-1", "bundle_version": bundle_version}),
        )

    with pytest.raises(ValidationError):
        make_event(
            event_type="bundle.created",
            payload={"bundle_id": "bundle-1", "bundle_version": bundle_version},
        )


def test_event_payload_helpers_reject_invalid_enum_values() -> None:
    with pytest.raises(ValidationError):
        TaskEventPayload.model_validate(cast(Any, {"task_kind": "unknown"}))

    with pytest.raises(ValidationError):
        VerificationEventPayload.model_validate(
            cast(Any, {"verification_id": "verification-1", "status": "unknown"}),
        )

    with pytest.raises(ValidationError):
        AuditEventPayload.model_validate(
            cast(
                Any,
                {"finding_id": "finding-1", "severity": "critical", "kind": "missing"},
            ),
        )


def test_event_catalog_includes_required_types_and_event_accepts_payload() -> None:
    assert {
        "run.created",
        "run.started",
        "run.status_changed",
        "run.replaced",
        "bundle.created",
        "bundle.state_changed",
        "bundle.assigned",
        "stage.started",
        "stage.completed",
        "task.queued",
        "task.started",
        "task.completed",
        "task.blocked",
        "task.failed",
        "task.aborted",
        "task.session_lost",
        "agent.spawned",
        "artifact.promoted",
        "verification.completed",
        "merge.completed",
        "stage.blocked",
        "stage.failed",
        "stage.aborted",
        "audit.finding_created",
        "audit.finding_status_changed",
    }.issubset(set(REQUIRED_EVENT_TYPES))

    event = Event(
        event_id="event-1",
        schema_version=1,
        run_id="run-1",
        stage_id="stage-1",
        task_id="task-1",
        event_type="task.started",
        sequence=7,
        occurred_at=utc_now(),
        source="workflow_engine",
        payload={"task_kind": "turn", "run_id": "run-1"},
    )

    assert event.event_type == "task.started"
    assert event.payload["task_kind"] == "turn"


@pytest.mark.parametrize(
    "event_type",
    [
        "taskstarteed",
        "task.starteed",
        "agent.spawend",
        "task.",
        ".started",
        "task.started.extra",
        "unknown.started",
    ],
)
def test_event_rejects_malformed_or_unknown_category_type(event_type: str) -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type=event_type,
            payload={"task_kind": "turn"},
            task_id="task-1",
        )


def test_event_accepts_custom_extension_event_type_under_known_category() -> None:
    event = make_event(
        event_type="task.custom_snapshot",
        payload={"task_kind": "turn"},
        task_id="task-1",
    )

    assert event.event_type == "task.custom_snapshot"
    assert event.payload["task_kind"] == "turn"


def test_event_rejects_unknown_current_schema_action_without_custom_prefix() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="task.retried",
            payload={"task_kind": "turn"},
            task_id="task-1",
        )


def test_event_accepts_future_official_action_for_newer_schema_version() -> None:
    event = make_event(
        event_type="task.retried",
        payload={"task_kind": "turn"},
        task_id="task-1",
        schema_version=2,
    )

    assert event.event_type == "task.retried"
    assert event.schema_version == 2


def test_future_category_events_for_newer_schema_require_stage_scope() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="worktree.retained",
            payload={"cleanup_state": "retained"},
            stage_id=None,
            task_id=None,
            schema_version=2,
        )

    event = make_event(
        event_type="worktree.retained",
        payload={"cleanup_state": "retained"},
        stage_id="stage-merge-1",
        task_id=None,
        schema_version=2,
    )

    assert event.event_type == "worktree.retained"
    assert event.stage_id == "stage-merge-1"


@pytest.mark.parametrize(
    ("event_type", "payload", "task_id", "schema_version"),
    [
        ("task.custom_", {"task_kind": "turn"}, "task-1", 2),
        (
            "agent.custom_",
            {"agent_id": "agent-1", "parent_task_id": "task-1"},
            "task-1",
            3,
        ),
    ],
)
def test_event_rejects_malformed_custom_extension_actions(
    event_type: str,
    payload: dict[str, object],
    task_id: str | None,
    schema_version: int,
) -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type=event_type,
            payload=payload,
            task_id=task_id,
            schema_version=schema_version,
        )


def test_task_events_require_stage_id_and_task_id() -> None:
    with pytest.raises(ValidationError):
        Event(
            event_id="event-1",
            schema_version=1,
            run_id="run-1",
            stage_id=None,
            task_id="task-1",
            event_type="task.started",
            sequence=7,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"task_kind": "turn"},
        )

    with pytest.raises(ValidationError):
        Event(
            event_id="event-2",
            schema_version=1,
            run_id="run-1",
            stage_id="stage-1",
            task_id=None,
            event_type="task.started",
            sequence=8,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"task_kind": "turn"},
        )


@pytest.mark.parametrize(
    ("event_type", "payload", "task_id"),
    [
        ("bundle.created", {}, None),
        ("stage.started", {"stage_kind": "plan"}, None),
        ("task.started", {"task_kind": "turn"}, "task-1"),
        (
            "agent.spawned",
            {"agent_id": "agent-1", "parent_task_id": "task-1"},
            "task-1",
        ),
        (
            "artifact.promoted",
            {
                "artifact_path": ".ralphception/plans/runtime-plan.md",
                "artifact_kind": "plan",
                "producing_run_id": "run-1",
            },
            None,
        ),
        (
            "verification.completed",
            {"verification_id": "verification-1", "status": "passed"},
            "task-1",
        ),
        ("merge.completed", {}, None),
        (
            "audit.finding_created",
            {"finding_id": "finding-1", "severity": "P1", "kind": "test_gap"},
            None,
        ),
    ],
)
def test_all_non_run_events_require_stage_id(
    event_type: str,
    payload: dict[str, object],
    task_id: str | None,
) -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type=event_type,
            payload=payload,
            stage_id=None,
            task_id=task_id,
        )


def test_agent_spawned_requires_parent_task_context() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="agent.spawned",
            payload={"agent_id": "agent-1", "parent_task_id": "task-1"},
            task_id=None,
        )


def test_agent_spawned_requires_matching_parent_task_id() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="agent.spawned",
            payload={"agent_id": "agent-1", "parent_task_id": "task-2"},
            task_id="task-1",
        )


def test_agent_events_require_parent_task_consistency_across_category() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="agent.custom_status",
            payload={"agent_id": "agent-1", "parent_task_id": "task-1"},
            task_id=None,
            schema_version=2,
        )

    with pytest.raises(ValidationError):
        make_event(
            event_type="agent.custom_status",
            payload={"agent_id": "agent-1", "parent_task_id": "task-2"},
            task_id="task-1",
            schema_version=2,
        )


def test_stage_events_require_stage_id_but_not_task_id() -> None:
    with pytest.raises(ValidationError):
        Event(
            event_id="event-1",
            schema_version=1,
            run_id="run-1",
            stage_id=None,
            task_id=None,
            event_type="stage.started",
            sequence=7,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"stage_kind": "plan"},
        )

    with pytest.raises(ValidationError):
        Event(
            event_id="event-1b",
            schema_version=1,
            run_id="run-1",
            stage_id="stage-1",
            task_id="task-1",
            event_type="stage.started",
            sequence=7,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"stage_kind": "plan"},
        )

    event = Event(
        event_id="event-2",
        schema_version=1,
        run_id="run-1",
        stage_id="stage-1",
        task_id=None,
        event_type="stage.started",
        sequence=8,
        occurred_at=utc_now(),
        source="workflow_engine",
        payload={"stage_kind": "plan"},
    )

    assert event.task_id is None


def test_run_events_allow_null_stage_and_task_ids() -> None:
    event = Event(
        event_id="event-1",
        schema_version=1,
        run_id="run-1",
        stage_id=None,
        task_id=None,
        event_type="run.started",
        sequence=1,
        occurred_at=utc_now(),
        source="workflow_engine",
        payload={"goal": "Coordinate the root run", "parent_run_id": None},
    )

    assert event.stage_id is None
    assert event.task_id is None


def test_run_events_reject_stage_or_task_scope() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="run.started",
            payload={"goal": "Coordinate the root run", "parent_run_id": None},
            stage_id="stage-1",
            task_id=None,
        )

    with pytest.raises(ValidationError):
        make_event(
            event_type="run.started",
            payload={"goal": "Coordinate the root run", "parent_run_id": None},
            stage_id=None,
            task_id="task-1",
        )


def test_run_events_require_parent_run_id_key() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="run.started",
            payload={"goal": "Coordinate the root run"},
            stage_id=None,
            task_id=None,
        )

    event = make_event(
        event_type="run.started",
        payload={"goal": "Coordinate the root run", "parent_run_id": None},
        stage_id=None,
        task_id=None,
    )

    assert event.payload["parent_run_id"] is None


def test_bundle_and_merge_events_require_minimum_payloads() -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type="bundle.created",
            payload={},
        )

    with pytest.raises(ValidationError):
        make_event(
            event_type="merge.completed",
            payload={},
        )

    bundle_event = make_event(
        event_type="bundle.created",
        payload={"bundle_id": "bundle-1", "bundle_version": 3},
    )
    merge_event = make_event(
        event_type="merge.completed",
        payload={"child_run_id": "run-child-1"},
    )

    assert bundle_event.payload["bundle_id"] == "bundle-1"
    assert merge_event.payload["child_run_id"] == "run-child-1"


def test_verification_events_require_stage_id_and_task_id() -> None:
    with pytest.raises(ValidationError):
        Event(
            event_id="event-1",
            schema_version=1,
            run_id="run-1",
            stage_id="stage-1",
            task_id=None,
            event_type="verification.completed",
            sequence=7,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"verification_id": "verification-1", "status": "passed"},
        )

    with pytest.raises(ValidationError):
        Event(
            event_id="event-2",
            schema_version=1,
            run_id="run-1",
            stage_id=None,
            task_id="task-verify-1",
            event_type="verification.completed",
            sequence=8,
            occurred_at=utc_now(),
            source="workflow_engine",
            payload={"verification_id": "verification-1", "status": "passed"},
        )


@pytest.mark.parametrize(
    ("event_type", "payload", "task_id", "stage_id"),
    [
        ("run.started", {"goal": "Coordinate the root run"}, None, None),
        ("stage.started", {}, None, "stage-1"),
        ("task.started", {}, "task-1", "stage-1"),
        ("agent.spawned", {"agent_id": "agent-1"}, "task-1", "stage-1"),
        (
            "artifact.promoted",
            {
                "artifact_path": ".ralphception/plans/runtime-plan.md",
                "artifact_kind": "plan",
            },
            None,
            "stage-1",
        ),
        ("verification.completed", {"verification_id": "verification-1"}, "task-1", "stage-1"),
        (
            "audit.finding_created",
            {"finding_id": "finding-1", "severity": "P1"},
            None,
            "stage-1",
        ),
    ],
)
def test_event_payload_requires_minimum_spec_keys(
    event_type: str,
    payload: dict[str, object],
    task_id: str | None,
    stage_id: str | None,
) -> None:
    with pytest.raises(ValidationError):
        make_event(
            event_type=event_type,
            payload=payload,
            task_id=task_id,
            stage_id=stage_id,
        )


@pytest.mark.parametrize(
    ("event_type", "payload", "task_id", "stage_id"),
    [
        (
            "run.started",
            {"goal": "Coordinate the root run", "parent_run_id": None},
            None,
            None,
        ),
        ("stage.started", {"stage_kind": "plan"}, None, "stage-1"),
        ("task.started", {"task_kind": "turn"}, "task-1", "stage-1"),
        (
            "agent.spawned",
            {"agent_id": "agent-1", "parent_task_id": "task-1"},
            "task-1",
            "stage-1",
        ),
        (
            "artifact.promoted",
            {
                "artifact_path": ".ralphception/plans/runtime-plan.md",
                "artifact_kind": "plan",
                "producing_run_id": "run-1",
            },
            None,
            "stage-1",
        ),
        (
            "verification.completed",
            {"verification_id": "verification-1", "status": "passed"},
            "task-1",
            "stage-1",
        ),
        (
            "audit.finding_created",
            {"finding_id": "finding-1", "severity": "P1", "kind": "test_gap"},
            None,
            "stage-1",
        ),
    ],
)
def test_event_payload_accepts_minimum_spec_keys(
    event_type: str,
    payload: dict[str, object],
    task_id: str | None,
    stage_id: str | None,
) -> None:
    event = make_event(
        event_type=event_type,
        payload=payload,
        task_id=task_id,
        stage_id=stage_id,
    )

    assert event.payload == payload


def make_artifact_ref(suffix: str = "plan-3") -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="plan",
        artifact_path=f".ralphception/plans/{suffix}.md",
        artifact_version=3,
        content_hash=f"sha256:{suffix}",
    )


def make_verification_spec_artifact_ref(suffix: str = "verification-spec-1") -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="verification_spec",
        artifact_path=f".ralphception/verification/{suffix}.json",
        artifact_version=1,
        content_hash=f"sha256:{suffix}",
    )


def make_verification_artifact_ref(suffix: str = "verification-1") -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="verification_result",
        artifact_path=f".ralphception/verification/{suffix}.json",
        artifact_version=1,
        content_hash=f"sha256:{suffix}",
    )


def make_event(
    *,
    event_type: str,
    payload: dict[str, object],
    stage_id: str | None = "stage-1",
    task_id: str | None = None,
    schema_version: int = 1,
) -> Event:
    return Event(
        event_id=f"{event_type}-event",
        schema_version=schema_version,
        run_id="run-1",
        stage_id=stage_id,
        task_id=task_id,
        event_type=event_type,
        sequence=1,
        occurred_at=utc_now(),
        source="workflow_engine",
        payload=payload,
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 15, 20, 0, tzinfo=timezone.utc)
