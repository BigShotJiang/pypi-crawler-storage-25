from __future__ import annotations

from ralphception.runtime.task_classifier import classify_user_message


def test_classifier_prefers_blocker_reply_when_prompt_is_pending() -> None:
    result = classify_user_message(
        text="resume it",
        prompt_pending=True,
        active_task_summary="fix typos in docs",
    )

    assert result.kind == "blocker_reply"


def test_classifier_requests_clarification_for_ambiguous_new_task_boundary() -> None:
    result = classify_user_message(
        text="do that other thing too",
        prompt_pending=False,
        active_task_summary="fix typos in docs",
    )

    assert result.kind == "needs_clarification"
    assert result.clarifying_question is not None


def test_classifier_detects_task_revision() -> None:
    result = classify_user_message(
        text="change scope to README typos only",
        prompt_pending=False,
        active_task_summary="fix typos in docs and comments",
    )

    assert result.kind == "task_revision"


def test_classifier_detects_new_task_request() -> None:
    result = classify_user_message(
        text="stop this and audit our CI pipeline instead",
        prompt_pending=False,
        active_task_summary="fix typos in docs and comments",
    )

    assert result.kind == "new_task_request"
