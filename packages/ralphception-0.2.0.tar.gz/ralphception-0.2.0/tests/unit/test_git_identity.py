from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

from ralphception.git.identity import GitIdentityError, resolve_git_commit_identity


def test_resolve_git_commit_identity_prefers_configured_user(tmp_path: Path) -> None:
    repo_root = init_git_repo(tmp_path / "repo")
    run_git(repo_root, "config", "user.name", "Configured User")
    run_git(repo_root, "config", "user.email", "configured@example.com")

    name, email = resolve_git_commit_identity(repo_root)

    assert (name, email) == ("Configured User", "configured@example.com")


def test_resolve_git_commit_identity_falls_back_to_head_author(tmp_path: Path, monkeypatch) -> None:
    repo_root = init_git_repo(tmp_path / "repo")
    disable_global_git_identity(monkeypatch, tmp_path)

    name, email = resolve_git_commit_identity(repo_root)

    assert (name, email) == ("Test User", "test@example.com")


def test_resolve_git_commit_identity_rejects_legacy_ralphception_author(tmp_path: Path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    disable_global_git_identity(monkeypatch, tmp_path)
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Ralphception",
        "-c",
        "user.email=ralphception@example.com",
        "commit",
        "-m",
        "initial",
    )

    with pytest.raises(GitIdentityError, match="Git user identity is not configured"):
        resolve_git_commit_identity(repo_root)


def init_git_repo(repo_root: Path) -> Path:
    repo_root.mkdir()
    run_git(repo_root, "init", "-b", "main")
    (repo_root / "README.md").write_text("repo\n", encoding="utf-8")
    run_git(repo_root, "add", "README.md")
    run_git(
        repo_root,
        "-c",
        "commit.gpgsign=false",
        "-c",
        "user.name=Test User",
        "-c",
        "user.email=test@example.com",
        "commit",
        "-m",
        "initial",
    )
    return repo_root


def run_git(repo_root: Path, *args: str) -> None:
    subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )


def disable_global_git_identity(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", os.devnull)
    monkeypatch.setenv("GIT_CONFIG_NOSYSTEM", "1")
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg-config"))
