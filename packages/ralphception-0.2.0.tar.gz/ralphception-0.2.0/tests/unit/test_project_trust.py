from __future__ import annotations

from pathlib import Path

from ralphception.runtime.project_trust import load_project_trust, save_project_trust


def test_project_trust_round_trips_in_workspace_state_dir(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    state_home = tmp_path / "state"

    assert load_project_trust(repo_root, xdg_state_home=state_home) is None

    save_project_trust(repo_root, "trusted", xdg_state_home=state_home)

    assert load_project_trust(repo_root, xdg_state_home=state_home) == "trusted"
