import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from ralphception.models.artifacts import ArtifactRef
from ralphception.models.verification import (
    AuditFinding,
    AuditFindingStatus,
    FindingSeverity,
)
from ralphception.storage.events import EventStore
from ralphception.audit.service import AuditService


def test_persist_finding_writes_durable_record_and_created_event(tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    finding = make_finding()

    persisted = service.persist_finding(finding, stage_id="stage-audit")

    assert persisted == finding
    stored = json.loads(
        (tmp_path / ".ralphception" / "findings" / "finding-1.json").read_text(encoding="utf-8"),
    )
    assert stored["finding_id"] == "finding-1"
    assert stored["status"] == "open"

    events = EventStore(tmp_path).read_run("run-1")
    assert events[-1].event_type == "audit.finding_created"
    assert events[-1].payload["finding_id"] == "finding-1"
    assert events[-1].payload["severity"] == "P1"
    assert events[-1].payload["kind"] == "bug"


def test_persist_finding_rejects_invalid_identifier_without_writing_outside_storage(
    tmp_path: Path,
) -> None:
    service = AuditService(tmp_path)
    finding = make_finding(finding_id="../finding-escape")

    with pytest.raises(ValueError, match="invalid .*identifier"):
        service.persist_finding(finding, stage_id="stage-audit")

    assert not (tmp_path / ".ralphception" / "finding-escape.json").exists()


def test_reopen_finding_resets_status_for_configured_priorities(tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    resolved = make_finding(status="resolved", resolved_at=utc_now())
    service.persist_finding(resolved, stage_id="stage-audit")
    reopened_at = utc_now() + timedelta(minutes=1)

    reopened = service.reopen_finding(
        resolved,
        stage_id="stage-audit",
        reopened_at=reopened_at,
    )

    assert reopened.status == "open"
    assert reopened.resolved_at is None
    assert reopened.created_at == reopened_at

    events = EventStore(tmp_path).read_run("run-1")
    assert events[-1].event_type == "audit.finding_status_changed"
    assert events[-1].occurred_at == reopened_at
    assert events[-1].payload["finding_id"] == "finding-1"
    assert events[-1].payload["status"] == "open"


def test_reopen_finding_without_timestamp_uses_current_time(tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    resolved = make_finding(status="resolved", resolved_at=utc_now())
    service.persist_finding(resolved, stage_id="stage-audit")
    before = datetime.now(timezone.utc)

    reopened = service.reopen_finding(
        resolved,
        stage_id="stage-audit",
    )

    after = datetime.now(timezone.utc)

    assert before <= reopened.created_at <= after
    events = EventStore(tmp_path).read_run("run-1")
    assert before <= events[-1].occurred_at <= after


def test_open_p0_p1_p2_findings_block_completion(tmp_path: Path) -> None:
    service = AuditService(tmp_path)

    assert service.blocks_completion([make_finding(severity="P1")]) is True
    assert service.blocks_completion([make_finding(severity="P3")]) is False
    assert service.blocks_completion(
        [make_finding(severity="P2", status="resolved", resolved_at=utc_now())],
    ) is False


def test_only_human_approval_may_accept_or_wontfix_blocking_findings(tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    finding = make_finding()

    with pytest.raises(PermissionError, match="human approval"):
        service.transition_finding_status(
            finding,
            new_status="accepted",
            actor="autonomous",
            stage_id="stage-audit",
            changed_at=utc_now(),
        )

    accepted = service.transition_finding_status(
        finding,
        new_status="accepted",
        actor="human",
        stage_id="stage-audit",
        changed_at=utc_now(),
    )

    assert accepted.status == "accepted"
    assert accepted.resolved_at == utc_now()


def test_autonomous_resolution_requires_verification_or_merge_support(tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    finding = make_finding(severity="P2")

    with pytest.raises(PermissionError, match="supported by verification or merged changes"):
        service.transition_finding_status(
            finding,
            new_status="resolved",
            actor="autonomous",
            stage_id="stage-audit",
            changed_at=utc_now(),
        )

    resolved = service.transition_finding_status(
        finding,
        new_status="resolved",
        actor="autonomous",
        stage_id="stage-audit",
        changed_at=utc_now(),
        supported_by_verification=True,
    )

    assert resolved.status == "resolved"
    assert resolved.resolved_at == utc_now()


def test_prepare_waiver_keeps_finding_open_and_returns_finding_waiver_approval(
    tmp_path: Path,
) -> None:
    service = AuditService(tmp_path)
    finding = make_finding(severity="P1")

    prepared = service.prepare_waiver(
        finding,
        approval_id="approval-waiver-1",
        approver="human-reviewer",
        rationale="Accept the temporary risk.",
        prepared_at=utc_now(),
    )

    assert prepared.finding.status == "open"
    assert prepared.required_run_state == "awaiting_approval"
    assert prepared.approval.approval_kind == "finding_waiver"
    assert prepared.approval.waived_finding_ids == ["finding-1"]


@pytest.mark.parametrize("status", ["accepted", "resolved", "wontfix"])
def test_prepare_waiver_rejects_non_open_findings(status: AuditFindingStatus, tmp_path: Path) -> None:
    service = AuditService(tmp_path)
    finding = make_finding(
        severity="P1",
        status=status,
        resolved_at=utc_now(),
    )

    with pytest.raises(ValueError, match="open finding"):
        service.prepare_waiver(
            finding,
            approval_id="approval-waiver-invalid",
            approver="human-reviewer",
            rationale="Reject invalid waiver request.",
            prepared_at=utc_now(),
        )


def make_finding(
    *,
    finding_id: str = "finding-1",
    severity: FindingSeverity = "P1",
    status: AuditFindingStatus = "open",
    resolved_at: datetime | None = None,
) -> AuditFinding:
    return AuditFinding(
        finding_id=finding_id,
        run_id="run-1",
        severity=severity,
        kind="bug",
        title="A durable test finding",
        evidence_refs=[make_artifact_ref()],
        status=status,
        created_at=utc_now() - timedelta(minutes=5),
        resolved_at=resolved_at,
    )


def make_artifact_ref() -> ArtifactRef:
    return ArtifactRef(
        artifact_kind="verification_result",
        artifact_path=".ralphception/verification/verification-1.result.json",
        artifact_version=1,
        content_hash="sha256:test",
    )


def utc_now() -> datetime:
    return datetime(2026, 3, 16, 13, 0, tzinfo=timezone.utc)
