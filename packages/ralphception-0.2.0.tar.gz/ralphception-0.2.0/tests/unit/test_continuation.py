from __future__ import annotations

from ralphception.runtime.continuation import detect_continuation_hint


def test_detect_continuation_hint_recognizes_explicit_next_steps_language() -> None:
    assert detect_continuation_hint("Here are the next steps I can take:\n1. Re-run verification\n2. Merge the child run") == "next_steps"
    assert detect_continuation_hint("Planning next steps.\nI should inspect the diff before editing.") == "next_steps"
    assert detect_continuation_hint("Implemented the parser and verified the touched files.") is None
