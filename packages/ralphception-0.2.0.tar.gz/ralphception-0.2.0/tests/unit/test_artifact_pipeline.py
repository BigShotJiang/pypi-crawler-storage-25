from __future__ import annotations

import json
from pathlib import Path

from pydantic import TypeAdapter

from ralphception.models.artifacts import TodoArtifact
from ralphception.runtime.artifact_pipeline import ArtifactPipeline
from ralphception.runtime.loop_graph import LoopGraph
from ralphception.runtime.loop_planner import LoopDefinition


def test_first_task_writes_required_artifacts_before_loop_execution(tmp_path: Path) -> None:
    pipeline = ArtifactPipeline.for_workspace(tmp_path)

    result = pipeline.initialize_from_intake(
        task_id="task-1",
        intake_summary="Fix typos in docs",
    )

    assert result.paths["intake-summary"].exists()
    assert result.paths["prd"].exists()
    assert result.paths["execution-plan"].exists()
    assert result.paths["loop-plan"].exists()
    assert result.paths["todos"].exists()
    assert result.revisions["prd"].workflow_artifact_kind == "spec"
    assert result.revisions["execution-plan"].workflow_artifact_kind == "plan"
    assert result.revisions["loop-plan"].workflow_artifact_kind == "plan"
    assert result.revisions["todos"].workflow_artifact_kind == "todo"

    for artifact_key, path in result.paths.items():
        relative_path = path.relative_to(tmp_path)
        assert relative_path.parts[:2] == (".ralphception", "artifact-pipeline")
        assert relative_path.parts[2] == artifact_key

    todo_payload = json.loads(result.paths["todos"].read_text(encoding="utf-8"))
    todos = TypeAdapter(list[TodoArtifact]).validate_python(todo_payload)
    assert todos[0].title == "Fix typos in docs"
    assert todos[0].bundle_version == 1
    assert todos[0].artifact_refs


def test_new_prd_revision_becomes_authoritative_without_deleting_history(tmp_path: Path) -> None:
    pipeline = ArtifactPipeline.for_workspace(tmp_path)

    rev1 = pipeline.write_artifact("prd", "v1")
    rev2 = pipeline.write_artifact("prd", "v2")

    assert pipeline.authoritative_revision("prd") == rev2.revision_id
    assert rev2.workflow_artifact_kind == "spec"
    assert rev1.path.exists()


def test_parallel_loop_proposals_require_explicit_consolidation_before_revision_advances(
    tmp_path: Path,
) -> None:
    pipeline = ArtifactPipeline(tmp_path)
    graph = LoopGraph.from_definitions(
        [
            LoopDefinition(
                loop_id="loop-a",
                task_id="task-1",
                plan_node_id="docs",
                parent_loop_id=None,
                objective="Update docs",
                stop_conditions=("docs settled",),
                output_contract=("publish docs proposal",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
            LoopDefinition(
                loop_id="loop-b",
                task_id="task-1",
                plan_node_id="comments",
                parent_loop_id=None,
                objective="Update comments",
                stop_conditions=("comments settled",),
                output_contract=("publish comments proposal",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
        ],
    )

    authoritative_before = pipeline.authoritative_revision("prd")
    pipeline.stage_loop_completion(loop_graph=graph, loop_id="loop-a")
    authoritative_during = pipeline.authoritative_revision("prd")
    pipeline.stage_loop_completion(loop_graph=graph, loop_id="loop-b")
    authoritative_staged = pipeline.authoritative_revision("prd")
    consolidated = pipeline.consolidate_artifact("prd", selected_loop_id="loop-b")
    authoritative_after = pipeline.authoritative_revision("prd")

    assert authoritative_before is None
    assert authoritative_during is None
    assert authoritative_staged is None
    assert consolidated.authoritative_revision_after is not None
    assert authoritative_after == consolidated.authoritative_revision_after
