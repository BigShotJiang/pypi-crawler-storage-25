import json
from datetime import datetime, timezone
from pathlib import Path
from typing import cast

import pytest

from ralphception.models.verification import VerificationScope
from ralphception.storage.events import EventStore
from ralphception.verification.service import TIMEOUT_EXIT_CODE, VerificationService


def test_create_task_bundle_merges_command_sources_by_precedence_without_silent_removal(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)

    bundle = service.create_task_bundle(
        verification_id="verification-1",
        run_id="run-1",
        stage_id="stage-execute",
        task_id="task-verify-1",
        requested_by="merge:task-1",
        scope="merge",
        config_default_commands=["uv run pytest tests/unit/test_config.py -v"],
        plan_defined_commands=["uv run ruff check src", "uv run pytest tests/unit/test_config.py -v"],
        audit_stage_required_commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
        merge_stage_required_commands=["uv run pytest tests/integration/test_merge_coordinator.py -v"],
        created_at=utc_now(),
    )

    assert bundle.spec.commands == [
        "uv run pytest tests/integration/test_merge_coordinator.py -v",
        "uv run pytest tests/unit/test_runtime_models.py -v",
        "uv run ruff check src",
        "uv run pytest tests/unit/test_config.py -v",
    ]
    assert bundle.task.task_kind == "verification"
    assert len(bundle.task.input_refs) == 1
    assert len(bundle.task.output_refs) == 1
    assert bundle.task.input_refs[0].artifact_kind == "verification_spec"
    assert bundle.task.output_refs[0].artifact_kind == "verification_result"
    assert (tmp_path / ".ralphception" / "verification" / "verification-1.spec.json").is_file()
    assert (tmp_path / ".ralphception" / "verification" / "verification-1.result.json").is_file()


def test_create_task_bundle_rejects_invalid_verification_identifier_without_writing_outside_storage(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)

    with pytest.raises(ValueError, match="invalid .*identifier"):
        service.create_task_bundle(
            verification_id="../verification-escape",
            run_id="run-1",
            stage_id="stage-execute",
            task_id="task-verify-escape",
            requested_by="audit:task-escape",
            scope="audit",
            plan_defined_commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
            created_at=utc_now(),
        )

    assert not (tmp_path / ".ralphception" / "verification-escape.spec.json").exists()
    assert not (tmp_path / ".ralphception" / "verification-escape.result.json").exists()


def test_create_task_bundle_uses_explicit_bundle_commands_to_remove_lower_precedence_checks(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)

    bundle = service.create_task_bundle(
        verification_id="verification-2",
        run_id="run-1",
        stage_id="stage-execute",
        task_id="task-verify-2",
        requested_by="execute:task-2",
        scope="task",
        config_default_commands=["uv run pytest tests/unit/test_config.py -v"],
        plan_defined_commands=["uv run ruff check src"],
        active_bundle_exact_commands=[
            "uv run ruff check src",
            "uv run pytest tests/unit/test_runtime_models.py -v",
        ],
        created_at=utc_now(),
    )

    assert bundle.spec.commands == [
        "uv run ruff check src",
        "uv run pytest tests/unit/test_runtime_models.py -v",
    ]


def test_select_execution_context_uses_scope_specific_roots(tmp_path: Path) -> None:
    service = VerificationService(tmp_path)
    authoritative_root = tmp_path / "repo"
    child_worktree = tmp_path / ".worktrees" / "child-run"
    integration_worktree = tmp_path / ".worktrees" / "run-1-integration"

    assert (
        service.select_execution_context(
            scope="task",
            authoritative_root=authoritative_root,
            child_worktree=child_worktree,
            integration_worktree=integration_worktree,
        )
        == child_worktree
    )
    assert (
        service.select_execution_context(
            scope="child_run",
            authoritative_root=authoritative_root,
            child_worktree=child_worktree,
            integration_worktree=integration_worktree,
        )
        == child_worktree
    )
    assert (
        service.select_execution_context(
            scope="merge",
            authoritative_root=authoritative_root,
            child_worktree=child_worktree,
            integration_worktree=integration_worktree,
        )
        == integration_worktree
    )
    assert (
        service.select_execution_context(
            scope="run",
            authoritative_root=authoritative_root,
            child_worktree=child_worktree,
            integration_worktree=integration_worktree,
        )
        == authoritative_root
    )
    assert (
        service.select_execution_context(
            scope="audit",
            authoritative_root=authoritative_root,
            child_worktree=child_worktree,
            integration_worktree=integration_worktree,
        )
        == authoritative_root
    )


@pytest.mark.parametrize("scope", ["task", "child_run"])
def test_select_execution_context_rejects_missing_child_worktree(scope: str, tmp_path: Path) -> None:
    service = VerificationService(tmp_path)

    with pytest.raises(ValueError, match="child_worktree is required"):
        service.select_execution_context(
            scope=cast(VerificationScope, scope),
            authoritative_root=tmp_path / "repo",
            child_worktree=None,
            integration_worktree=tmp_path / ".worktrees" / "run-1-integration",
        )


def test_select_execution_context_rejects_missing_integration_worktree(tmp_path: Path) -> None:
    service = VerificationService(tmp_path)

    with pytest.raises(ValueError, match="integration_worktree is required"):
        service.select_execution_context(
            scope="merge",
            authoritative_root=tmp_path / "repo",
            child_worktree=tmp_path / ".worktrees" / "child-run",
            integration_worktree=None,
        )


def test_shape_command_result_marks_timeouts_as_errored_and_persists_outputs(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)

    command_result = service.shape_command_result(
        verification_id="verification-3",
        command_index=0,
        command="uv run pytest tests/unit/test_runtime_models.py -v",
        cwd=tmp_path / "repo",
        exit_code=None,
        duration_ms=1800,
        stdout="stdout",
        stderr="timed out",
        timed_out=True,
    )

    assert command_result.status == "errored"
    assert command_result.exit_code == TIMEOUT_EXIT_CODE
    assert command_result.stdout_ref is not None
    assert command_result.stderr_ref is not None
    assert (tmp_path / command_result.stdout_ref.artifact_path).read_text(encoding="utf-8") == "stdout"
    assert (tmp_path / command_result.stderr_ref.artifact_path).read_text(encoding="utf-8") == "timed out"


def test_shape_command_result_rejects_invalid_verification_identifier_without_writing_outside_storage(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)

    with pytest.raises(ValueError, match="invalid .*identifier"):
        service.shape_command_result(
            verification_id="../verification-escape",
            command_index=0,
            command="uv run pytest tests/unit/test_runtime_models.py -v",
            cwd=tmp_path / "repo",
            exit_code=0,
            duration_ms=50,
            stdout="stdout",
            stderr="",
        )

    assert not (tmp_path / ".ralphception" / "verification-escape").exists()


def test_persist_result_updates_record_and_mirrors_verification_completed_event(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)
    bundle = service.create_task_bundle(
        verification_id="verification-4",
        run_id="run-1",
        stage_id="stage-execute",
        task_id="task-verify-4",
        requested_by="audit:task-4",
        scope="audit",
        plan_defined_commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
        created_at=utc_now(),
    )
    command_result = service.shape_command_result(
        verification_id="verification-4",
        command_index=0,
        command=bundle.spec.commands[0],
        cwd=tmp_path / "repo",
        exit_code=0,
        duration_ms=250,
        stdout="all good",
        stderr="",
    )

    persisted = service.persist_result(
        stage_id="stage-execute",
        spec=bundle.spec,
        command_results=[command_result],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert persisted.result.status == "passed"
    stored_result = json.loads(
        (tmp_path / ".ralphception" / "verification" / "verification-4.result.json").read_text(
            encoding="utf-8",
        ),
    )
    assert stored_result["verification_id"] == "verification-4"
    assert stored_result["status"] == "passed"
    assert persisted.result_ref.artifact_kind == "verification_result"

    events = EventStore(tmp_path).read_run("run-1")
    assert events[-1].event_type == "verification.completed"
    assert events[-1].stage_id == "stage-execute"
    assert events[-1].task_id == "task-verify-4"
    assert events[-1].payload["verification_id"] == "verification-4"
    assert events[-1].payload["status"] == "passed"


def test_persist_result_records_failed_status_and_event_for_non_zero_exit(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)
    bundle = service.create_task_bundle(
        verification_id="verification-5",
        run_id="run-1",
        stage_id="stage-execute",
        task_id="task-verify-5",
        requested_by="audit:task-5",
        scope="audit",
        plan_defined_commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
        created_at=utc_now(),
    )
    command_result = service.shape_command_result(
        verification_id="verification-5",
        command_index=0,
        command=bundle.spec.commands[0],
        cwd=tmp_path / "repo",
        exit_code=7,
        duration_ms=600,
        stdout="1 failed",
        stderr="assertion error",
    )

    persisted = service.persist_result(
        stage_id="stage-execute",
        spec=bundle.spec,
        command_results=[command_result],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert persisted.result.status == "failed"
    stored_result = json.loads(
        (tmp_path / ".ralphception" / "verification" / "verification-5.result.json").read_text(
            encoding="utf-8",
        ),
    )
    assert stored_result["status"] == "failed"
    assert stored_result["command_results"][0]["exit_code"] == 7
    assert stored_result["command_results"][0]["status"] == "failed"

    events = EventStore(tmp_path).read_run("run-1")
    assert events[-1].event_type == "verification.completed"
    assert events[-1].payload["verification_id"] == "verification-5"
    assert events[-1].payload["status"] == "failed"


def test_persist_result_records_errored_status_and_event_for_timeout(
    tmp_path: Path,
) -> None:
    service = VerificationService(tmp_path)
    bundle = service.create_task_bundle(
        verification_id="verification-6",
        run_id="run-1",
        stage_id="stage-execute",
        task_id="task-verify-6",
        requested_by="audit:task-6",
        scope="audit",
        plan_defined_commands=["uv run pytest tests/unit/test_runtime_models.py -v"],
        created_at=utc_now(),
    )
    command_result = service.shape_command_result(
        verification_id="verification-6",
        command_index=0,
        command=bundle.spec.commands[0],
        cwd=tmp_path / "repo",
        exit_code=None,
        duration_ms=1800,
        stdout="",
        stderr="timed out",
        timed_out=True,
    )

    persisted = service.persist_result(
        stage_id="stage-execute",
        spec=bundle.spec,
        command_results=[command_result],
        started_at=utc_now(),
        completed_at=utc_now(),
    )

    assert persisted.result.status == "errored"
    stored_result = json.loads(
        (tmp_path / ".ralphception" / "verification" / "verification-6.result.json").read_text(
            encoding="utf-8",
        ),
    )
    assert stored_result["status"] == "errored"
    assert stored_result["command_results"][0]["exit_code"] == TIMEOUT_EXIT_CODE
    assert stored_result["command_results"][0]["status"] == "errored"

    events = EventStore(tmp_path).read_run("run-1")
    assert events[-1].event_type == "verification.completed"
    assert events[-1].payload["verification_id"] == "verification-6"
    assert events[-1].payload["status"] == "errored"


def utc_now() -> datetime:
    return datetime(2026, 3, 16, 12, 0, tzinfo=timezone.utc)
