import os
from pathlib import Path

from ralphception.bootstrap.script import install_local_bootstrap_script


def test_install_local_bootstrap_script_writes_looping_ralph_sh(tmp_path: Path) -> None:
    script_path = install_local_bootstrap_script(tmp_path)

    assert script_path == tmp_path / "ralph.sh"
    assert script_path.exists()
    assert script_path.read_text(encoding="utf-8").startswith("#!/usr/bin/env bash")
    assert "while true; do" in script_path.read_text(encoding="utf-8")
    assert 'cd -- "$(dirname "$0")"' in script_path.read_text(encoding="utf-8")
    assert (
        'uv run python -m ralphception.bootstrap.runner --loop-once "$@"'
        in script_path.read_text(encoding="utf-8")
    )
    assert os.access(script_path, os.X_OK)
