from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from ralphception.runtime.frontier import FrontierItem, TaskFrontier
from ralphception.runtime.watchdog import (
    WATCHDOG_DECISION_BEGIN,
    WATCHDOG_DECISION_END,
    WatchdogActivation,
    WatchdogDecision,
    WatchdogInputSnapshot,
    WatchdogActivationPolicy,
    WatchdogDefinition,
    build_watchdog_decision_prompt,
    can_activate_root_watchdog_for_frontier,
    frontier_allows_watchdog_activation,
    latest_root_watchdog_activation,
    parse_watchdog_decision,
    record_root_watchdog_activation,
    write_root_watchdog,
)


def test_parse_watchdog_decision_accepts_allowed_action_payload() -> None:
    decision = parse_watchdog_decision(
        "\n".join(
            (
                WATCHDOG_DECISION_BEGIN,
                '{"action":"ask_user","rationale":"Need one constraint.","question":"What constraint should I honor?"}',
                WATCHDOG_DECISION_END,
            )
        )
    )

    assert decision == WatchdogDecision(
        action="ask_user",
        rationale="Need one constraint.",
        question="What constraint should I honor?",
    )


def test_parse_watchdog_decision_rejects_action_outside_allowed_set() -> None:
    decision = parse_watchdog_decision(
        "\n".join(
            (
                WATCHDOG_DECISION_BEGIN,
                '{"action":"delete_everything","rationale":"bad"}',
                WATCHDOG_DECISION_END,
            )
        )
    )

    assert decision is None


def test_build_watchdog_decision_prompt_includes_frontier_and_recent_events() -> None:
    frontier = TaskFrontier(
        root_run_id="run-root",
        status="incomplete",
        current_stage="execute",
        frontier_items=[
            FrontierItem(
                kind="continue_stage",
                summary="Continue execute stage",
                run_id="run-root",
                stage_kind="execute",
            )
        ],
        active_loop_ids=["loop-parser"],
        stuck_count=2,
        updated_at=datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc),
    )

    prompt = build_watchdog_decision_prompt(
        goal="Finish the parser port.",
        trigger_reason="idle",
        frontier=frontier,
        artifact_paths=("docs/prd.md", "docs/plan.md"),
        recent_runtime_events=(
            "stage.custom_loop_completed loop_id=loop-parser",
            "verification.completed status=passed",
        ),
    )

    assert "Finish the parser port." in prompt
    assert "Continue execute stage" in prompt
    assert "loop-parser" in prompt
    assert "stuck_count: 2" in prompt
    assert "verification.completed status=passed" in prompt
    assert WATCHDOG_DECISION_BEGIN in prompt
    assert WATCHDOG_DECISION_END in prompt


def test_watchdog_activation_policy_requires_idle_timeout_or_stuck_threshold() -> None:
    now = datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc)
    definition = WatchdogDefinition(
        root_run_id="run-root",
        goal="Finish the parser port.",
        cooldown_seconds=0,
        activation_policy=WatchdogActivationPolicy(idle_timeout_seconds=60, stuck_threshold=2),
        updated_at=now,
    )
    frontier = TaskFrontier(
        root_run_id="run-root",
        status="incomplete",
        goal="Finish the parser port.",
        current_stage="execute",
        frontier_items=[
            FrontierItem(
                kind="continue_stage",
                summary="Continue execute stage",
                run_id="run-root",
                stage_kind="execute",
            )
        ],
        last_progress_at=now - timedelta(seconds=10),
        stuck_count=1,
        updated_at=now,
    )

    assert can_activate_root_watchdog_for_frontier(definition, frontier, now=now) is False
    assert can_activate_root_watchdog_for_frontier(
        definition,
        frontier.model_copy(update={"stuck_count": 2}),
        now=now,
    ) is True


def test_frontier_allows_watchdog_activation_for_recovery_review_only() -> None:
    now = datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc)
    blocked_for_user = TaskFrontier(
        root_run_id="run-root",
        status="blocked",
        current_stage="execute",
        frontier_items=[
            FrontierItem(
                kind="review_prompt",
                summary="Await spec review",
                run_id="run-root",
            )
        ],
        blocked_reason="spec_review",
        updated_at=now,
    )
    blocked_for_recovery = blocked_for_user.model_copy(
        update={
            "frontier_items": [
                FrontierItem(
                    kind="review_prompt",
                    summary="Recovery review",
                    run_id="run-child-1",
                )
            ],
            "blocked_reason": "recovery_review",
        }
    )

    assert frontier_allows_watchdog_activation(blocked_for_user) is False
    assert frontier_allows_watchdog_activation(blocked_for_recovery) is True


def test_record_root_watchdog_activation_persists_rich_activation_history(tmp_path: Path) -> None:
    now = datetime(2026, 3, 28, 16, 0, tzinfo=timezone.utc)
    write_root_watchdog(
        tmp_path,
        WatchdogDefinition(
            root_run_id="run-root",
            task_id="run-root",
            goal="Finish the parser port.",
            updated_at=now,
        ),
    )
    frontier = TaskFrontier(
        root_run_id="run-root",
        status="incomplete",
        goal="Finish the parser port.",
        current_stage="execute",
        frontier_items=[
            FrontierItem(
                kind="continue_stage",
                summary="Continue execute stage",
                run_id="run-root",
                stage_kind="execute",
            )
        ],
        updated_at=now,
    )

    activation = record_root_watchdog_activation(
        tmp_path,
        trigger_reason="idle",
        source_thread_id="thread-1",
        created_child_thread_id="thread-2",
        input_snapshot=WatchdogInputSnapshot(
            goal="Finish the parser port.",
            trigger_reason="idle",
            frontier=frontier,
            artifact_paths=("docs/prd.md", "docs/plan.md"),
            recent_runtime_events=("stage.completed status=completed",),
        ),
        result=WatchdogDecision(
            action="continue_root_turn",
            rationale="The task remains incomplete and the next durable step is to continue the root turn.",
        ),
    )
    persisted = latest_root_watchdog_activation(tmp_path)

    assert persisted is not None
    assert activation == WatchdogActivation.model_validate(persisted.model_dump(mode="python"))
    assert persisted.task_id == "run-root"
    assert persisted.source_thread_id == "thread-1"
    assert persisted.created_child_thread_id == "thread-2"
    assert persisted.input_snapshot.artifact_paths == ("docs/prd.md", "docs/plan.md")
    assert persisted.result.action == "continue_root_turn"
