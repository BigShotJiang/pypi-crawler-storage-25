from __future__ import annotations

from ralphception.runtime.loop_graph import LoopDefinition, LoopGraph


def test_parallel_loops_with_overlapping_target_artifacts_require_proposal_merge() -> None:
    graph = LoopGraph.from_definitions(
        [
            LoopDefinition(
                loop_id="loop-a",
                task_id="task-1",
                plan_node_id="docs",
                parent_loop_id=None,
                objective="Update docs",
                stop_conditions=("docs are settled",),
                output_contract=("propose docs changes",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
            LoopDefinition(
                loop_id="loop-b",
                task_id="task-1",
                plan_node_id="comments",
                parent_loop_id=None,
                objective="Update comments",
                stop_conditions=("comments are settled",),
                output_contract=("propose comments changes",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
        ],
    )

    assert graph.requires_proposal_merge("prd") is True


def test_parallel_loops_with_disjoint_target_artifacts_do_not_require_proposal_merge() -> None:
    graph = LoopGraph.from_definitions(
        [
            LoopDefinition(
                loop_id="loop-a",
                task_id="task-1",
                plan_node_id="docs",
                parent_loop_id=None,
                objective="Update docs",
                stop_conditions=("docs are settled",),
                output_contract=("propose docs changes",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
            LoopDefinition(
                loop_id="loop-b",
                task_id="task-1",
                plan_node_id="comments",
                parent_loop_id=None,
                objective="Update comments",
                stop_conditions=("comments are settled",),
                output_contract=("propose comments changes",),
                target_artifacts=("todo",),
                merge_strategy="direct_update",
            ),
        ],
    )

    assert graph.requires_proposal_merge("prd") is False
    assert graph.requires_proposal_merge("todo") is False


def test_loop_graph_persists_parent_child_relationships_for_recursive_expansion() -> None:
    graph = LoopGraph.from_nested_definitions(
        [
            LoopDefinition(
                loop_id="loop-root",
                task_id="task-1",
                plan_node_id="root",
                parent_loop_id=None,
                objective="Explore root",
                stop_conditions=("root settled",),
                output_contract=("root proposal",),
                target_artifacts=("prd",),
                merge_strategy="proposal_first",
            ),
            LoopDefinition(
                loop_id="loop-child-a",
                task_id="task-1",
                plan_node_id="child-a",
                parent_loop_id="loop-root",
                objective="Explore child a",
                stop_conditions=("child a settled",),
                output_contract=("child a proposal",),
                target_artifacts=("todo",),
                merge_strategy="direct_update",
            ),
        ],
    )

    assert graph.children_for("loop-root")
