from __future__ import annotations

from ralphception.runtime import PendingPrompt


def test_runtime_package_exports_pending_prompt() -> None:
    assert PendingPrompt.__name__ == "PendingPrompt"
