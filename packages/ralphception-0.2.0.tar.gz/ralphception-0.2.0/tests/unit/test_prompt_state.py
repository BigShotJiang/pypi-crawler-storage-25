from __future__ import annotations

from datetime import datetime, timezone


def test_prompt_state_models_round_trip() -> None:
    from ralphception.runtime.prompt_state import (
        BlockedContinuationRef,
        DeferredInput,
        PendingPrompt,
        PromptResolution,
    )

    created_at = datetime(2026, 3, 22, 15, 30, tzinfo=timezone.utc)
    blocked_continuation = BlockedContinuationRef(
        thread_id="thread-worker-1",
        run_id="run-child-1",
    )
    pending_prompt = PendingPrompt(
        thread_id="thread-worker-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-review-1",
        prompt_kind="review_decision",
        title="Review decision",
        question="Approve the change?",
        allowed_actions=("approve",),
        context={"scope": "spec"},
        blocked_continuation=blocked_continuation,
    )
    deferred_input = DeferredInput(
        thread_id="thread-worker-1",
        text="continue after approval",
        created_at=created_at,
    )
    resolution = PromptResolution(
        thread_id="thread-worker-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-review-1",
        action="approve",
        raw_user_reply="looks good",
        confidence=0.98,
    )

    assert PendingPrompt.model_validate_json(pending_prompt.model_dump_json()) == pending_prompt
    assert DeferredInput.model_validate_json(deferred_input.model_dump_json()) == deferred_input
    assert PromptResolution.model_validate_json(resolution.model_dump_json()) == resolution
