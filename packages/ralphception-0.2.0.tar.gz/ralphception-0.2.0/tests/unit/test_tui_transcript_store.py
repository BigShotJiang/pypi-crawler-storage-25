from __future__ import annotations

import importlib


def _store_module():
    return importlib.import_module("ralphception.tui.chatwidget.transcript_store")


def test_transcript_store_commits_assistant_deltas_cleanly() -> None:
    store = _store_module().TranscriptStore()
    module = _store_module()

    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="the workspace."))
    store.apply(module.AssistantFinalEvent(item_id="message-1", text="Inspecting the workspace."))

    assert len(store.history_cells) == 1
    assert store.history_cells[0].text == "Inspecting the workspace."
    assert store.active_cell is None


def test_transcript_store_keeps_interleaved_command_output_in_one_committed_cell() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.CommandBeginEvent(item_id="command-1", command="tail -f log"))
    store.apply(module.CommandOutputDeltaEvent(item_id="command-1", text="line 1\n"))
    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Still waiting."))
    store.apply(module.CommandOutputDeltaEvent(item_id="command-1", text="line 2\n"))
    store.apply(module.CommandEndEvent(item_id="command-1", command="tail -f log"))

    assert len(store.history_cells) == 1
    cell = store.history_cells[0]
    assert cell.command == "tail -f log"
    assert cell.output == ("line 1", "line 2")
    assert store.active_cell is not None
    assert store.active_cell.prefix == "assistant"
    assert store.active_cell.text == "Still waiting."


def test_transcript_store_commits_previous_assistant_stream_before_switching_items() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    store.apply(module.AssistantDeltaEvent(item_id="message-2", text="Planning next steps."))

    assert len(store.history_cells) == 1
    committed = store.history_cells[0]
    assert committed.text == "Inspecting "
    assert store.active_cell is not None
    assert store.active_cell.item_id == "message-2"
    assert store.active_cell.text == "Planning next steps."


def test_transcript_store_replaces_committed_partial_assistant_when_final_arrives_late() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    store.apply(module.AssistantDeltaEvent(item_id="message-2", text="Planning next steps."))
    store.apply(module.AssistantFinalEvent(item_id="message-1", text="Inspecting the workspace."))

    assert len(store.history_cells) == 1
    committed = store.history_cells[0]
    assert committed.text == "Inspecting the workspace."
    assert store.active_cell is not None
    assert store.active_cell.item_id == "message-2"
    assert store.active_cell.text == "Planning next steps."


def test_transcript_store_replaces_partial_assistant_when_command_starts_before_final() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    store.apply(module.CommandBeginEvent(item_id="command-1", command="git status --short"))
    store.apply(module.CommandEndEvent(item_id="command-1", command="git status --short"))
    store.apply(module.AssistantFinalEvent(item_id="message-1", text="Inspecting the workspace."))

    assistant_cells = [cell.text for cell in store.history_cells if isinstance(cell, module.AssistantCell)]
    assert assistant_cells == ["Inspecting the workspace."]


def test_transcript_store_tracks_explicit_background_waiting_state() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.BackgroundWaitBeginEvent(process_id="p1", command="tail -f log"))

    assert store.waiting_state is not None
    assert store.waiting_state.process_id == "p1"
    assert store.waiting_state.command == "tail -f log"

    store.apply(module.BackgroundWaitEndEvent(process_id="p1"))

    assert store.waiting_state is None


def test_transcript_store_accumulates_reasoning_summary_and_commits_final_block() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )

    assert store.reasoning_header == "Planning codebase inspection"

    store.apply(module.ReasoningFinalEvent(item_id="reasoning-1"))

    assert store.reasoning_header is None
    assert len(store.history_cells) == 1
    assert store.history_cells[0].render_lines(width=80) == "• Inspect the repo first."


def test_transcript_store_strips_internal_agent_meta_from_reasoning_summary() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text="**Planning README inspection**\n\nI need to act as a coding agent and inspect README.md for typos.",
        )
    )

    assert len(store.history_cells) == 1
    assert store.history_cells[0].render_lines(width=80) == "• Inspect README.md for typos."


def test_transcript_store_drops_pure_internal_tool_reasoning_summary() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text="**Planning next step**\n\nI should use the commentary tools and explorer to decide what to do.",
        )
    )

    assert store.history_cells == []


def test_transcript_store_strips_first_person_loop_meta_from_reasoning_summary() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "**Planning README typo fix**\n\n"
                'I need to fix some typos. The title "Readme" should be standardized to "README." '
                "I think the best option is to keep the change scoped to README.md. "
                "I'll verify the diff and the handoff metadata after the edit. "
                "Let's take a look at the .ralphception path too."
            ),
        )
    )

    assert len(store.history_cells) == 1
    assert store.history_cells[0].render_lines(width=80) == (
        '• The title "Readme" should be standardized to "README." Keep the change scoped\n'
        "  to README.md. Verify the diff and the handoff metadata after the edit."
    )


def test_transcript_store_falls_back_to_concrete_header_for_mixed_tool_chatter_reasoning() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "**Inspecting README file**\n\n"
                "Fix some typos in the README and write a handoff.json file. "
                "I’m wondering if I should narrate progress as I go or just wait for the final response. "
                "I also need to inspect the README and check the handoff path directory. "
                "I’ll just focus on reading the README. "
                "This task isn’t about the codebase, so I can just use \"cat\" to view the README. "
                "I could use exec_command to read the file, focusing on minimal communication. "
                "Maybe I should check the repository files with a simple \"ls\" command to confirm that README is there since I need to control the scope starting from the target artifact. "
                "I’ll use exec to read the README."
            ),
        )
    )

    assert len(store.history_cells) == 1
    assert store.history_cells[0].render_lines(width=80) == "• Inspecting README file."


def test_transcript_store_drops_task_restatement_reasoning_with_internal_progress_meta() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "Modify the README.md to fix some typos and write a handoff JSON to the provided path, "
                "narrating my progress along the way. "
                "I’m considering inspecting the README first, within the repository’s root, while targeting specific artifacts. "
                "I can use shell commands for this. "
                "I should produce concrete progress updates, inspect the README, edit the necessary typos, and then write the handoff JSON, ensuring my final answer includes a clear summary."
            ),
        )
    )

    assert store.history_cells == []


def test_transcript_store_drops_handoff_schema_planning_meta() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "Write a file called handoff.json, including keys like summary, artifacts, touched_paths, and "
                "merge_readiness. The summary might be a string or an array, but the user didn't specify types, "
                "so I'll choose. I'm thinking the merge_readiness could be an object indicating if it's ready, "
                'possibly with a "true" value. Lastly, I should verify the README content and run commands to '
                "check progress before writing the handoff."
            ),
        )
    )

    assert store.history_cells == []


def test_transcript_store_drops_agent_waiting_overthinking_meta() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "I see that the README should only have two lines, which really simplifies things. "
                "It's also clear that there are some typos in the draft, but I shouldn't get too stuck on that. "
                "I might need to wait for some input from an agent, although it's not strictly necessary if I follow the instructions carefully. "
                "But I can get things moving quickly without instead of overthinking this!"
            ),
        )
    )

    assert store.history_cells == []


def test_transcript_store_drops_pure_first_person_verification_meta() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningFinalEvent(
            item_id="reasoning-1",
            text=(
                "**Planning README verification**\n\n"
                "I need to focus on mentioning verification while possibly inspecting the file. "
                "My goal is to keep this concise and efficient. "
                "Let's take a look at the .ralphception path too."
            ),
        )
    )

    assert store.history_cells == []


def test_transcript_store_keeps_reasoning_progress_out_of_live_transcript_before_final() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(
        module.ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )

    assert store.active_cell is None
    assert store.reasoning_header == "Planning codebase inspection"


def test_transcript_store_commits_active_assistant_before_switching_to_reasoning() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.AssistantDeltaEvent(item_id="message-1", text="Inspecting the workspace."))
    store.apply(
        module.ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning next steps**\n\nI should inspect the diff before editing.",
        )
    )

    assert len(store.history_cells) == 1
    assert store.history_cells[0].text == "Inspecting the workspace."
    assert store.active_cell is None
    assert store.reasoning_header == "Planning next steps"


def test_transcript_store_keeps_active_command_visible_while_reasoning_updates_arrive() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.CommandBeginEvent(item_id="command-1", command="git status --short"))
    store.apply(module.CommandOutputDeltaEvent(item_id="command-1", text="M src/app.py\n"))
    store.apply(
        module.ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Inspecting git status**\n\nI should review the modified files before changing code.",
        )
    )

    assert store.active_cell is not None
    assert store.active_cell.prefix == "$"
    assert store.active_cell.text == "git status --short"
    assert store.active_cell.output == ("M src/app.py",)

    store.apply(module.CommandEndEvent(item_id="command-1", command="git status --short"))

    assert len(store.history_cells) == 1
    assert store.history_cells[0].command == "git status --short"
    assert store.active_cell is None
    assert store.reasoning_header == "Inspecting git status"


def test_transcript_store_clears_generic_turn_wait_when_reasoning_header_arrives() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.begin_turn_wait()
    store.apply(
        module.ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )

    assert store.active_cell is None
    assert store.reasoning_header == "Planning codebase inspection"


def test_transcript_store_preserves_blank_command_output_lines() -> None:
    module = _store_module()
    store = module.TranscriptStore()

    store.apply(module.CommandBeginEvent(item_id="command-1", command="python demo.py"))
    store.apply(module.CommandOutputDeltaEvent(item_id="command-1", text="line 1\n\nline 3\n"))
    store.apply(module.CommandEndEvent(item_id="command-1", command="python demo.py"))

    assert len(store.history_cells) == 1
    cell = store.history_cells[0]
    assert cell.output == ("line 1", "", "line 3")
