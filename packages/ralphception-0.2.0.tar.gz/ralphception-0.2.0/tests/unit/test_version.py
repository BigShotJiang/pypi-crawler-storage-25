from __future__ import annotations

import importlib.metadata
from pathlib import Path

import pytest

from ralphception import version as version_module


def test_git_describe_version_matches_setuptools_scm_dev_format(monkeypatch: pytest.MonkeyPatch) -> None:
    repo_root = Path("/tmp/project")

    def fake_git_output(start_path: Path, *args: str) -> str:
        assert start_path == repo_root
        assert args == ("describe", "--dirty", "--tags", "--long", "--abbrev=9", "--match", "v*")
        return "v0.1.2-40-gd3313a533"

    monkeypatch.setattr(version_module, "_git_output", fake_git_output)

    assert version_module.checkout_version(repo_root) == "0.1.3.dev40+gd3313a533"


def test_resolve_cli_version_prefers_checkout_version_over_stale_installed_metadata(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    repo_root = Path("/tmp/project")

    monkeypatch.setattr(version_module, "checkout_version", lambda path: "0.1.3.dev40+gd3313a533")
    monkeypatch.setattr(importlib.metadata, "version", lambda name: "0.0.1.dev58+g66fa86737")

    assert version_module.resolve_cli_version(repo_root) == "0.1.3.dev40+gd3313a533"


def test_resolve_cli_version_uses_ralphception_checkout_when_workspace_is_unrelated(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace_root = Path("/tmp/unrelated-workspace")
    package_root = Path(version_module.__file__).resolve().parents[2]

    def fake_checkout_version(path: Path) -> str | None:
        if path == workspace_root:
            return None
        if path == package_root:
            return "0.1.3.dev99+gabcdef123"
        raise AssertionError(f"unexpected checkout path: {path}")

    monkeypatch.setattr(version_module, "checkout_version", fake_checkout_version)
    monkeypatch.setattr(importlib.metadata, "version", lambda name: "0.0.1.dev58+g66fa86737")

    assert version_module.resolve_cli_version(workspace_root) == "0.1.3.dev99+gabcdef123"
