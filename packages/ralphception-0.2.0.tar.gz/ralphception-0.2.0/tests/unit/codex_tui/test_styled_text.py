from __future__ import annotations

import re

from ralphception.codex_tui.styled_text import (
    StyledLine,
    StyledSpan,
    Style,
    pad_styled_line,
    reset_surface_theme,
    render_styled_line,
    set_surface_terminal_background,
    trim_styled_line,
    user_surface_style,
    visible_width,
)
from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette


def test_visible_width_ignores_ansi_style_sequences() -> None:
    line = StyledLine(
        (
            StyledSpan(">_ ", Style(dim=True)),
            StyledSpan("Ralphception", Style(bold=True)),
            StyledSpan(" fast", Style(fg="magenta")),
        )
    )

    rendered = render_styled_line(line)

    assert re.search(r"\x1b\[[0-9;]*m", rendered)
    assert visible_width(rendered) == len(">_ Ralphception fast")


def test_trim_styled_line_preserves_styles_and_visible_width() -> None:
    line = StyledLine(
        (
            StyledSpan("› ", Style(dim=True)),
            StyledSpan("Summarize recent commits", Style(fg="bright_black")),
        )
    )

    trimmed = trim_styled_line(line, width=12)
    rendered = render_styled_line(trimmed)

    assert re.search(r"\x1b\[[0-9;]*m", rendered)
    assert visible_width(rendered) == 12
    assert rendered.endswith("\x1b[0m")


def test_render_styled_line_supports_background_sgr() -> None:
    line = StyledLine((StyledSpan("surface", Style(bg="bright_black")),))

    rendered = render_styled_line(line)

    assert "\x1b[100m" in rendered
    assert rendered.endswith("\x1b[0m")


def test_pad_styled_line_can_extend_background_surface() -> None:
    line = StyledLine((StyledSpan("› hello", Style(bg="bright_black")),))

    padded = pad_styled_line(line, 12, pad_style=Style(bg="bright_black"))
    rendered = render_styled_line(padded)

    assert visible_width(rendered) == 12
    assert rendered.count("\x1b[100m") >= 1


def test_user_surface_style_uses_light_theme_rgb_when_terminal_background_is_light() -> None:
    try:
        set_surface_terminal_background((255, 255, 255))
        set_terminal_palette(fg=(0, 0, 0), bg=(255, 255, 255), color_level=ColorLevel.TRUECOLOR)

        rendered = render_styled_line(
            StyledLine((StyledSpan("surface", user_surface_style()),))
        )

        assert "\x1b[48;2;244;244;244m" in rendered
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_user_surface_style_uses_dark_theme_rgb_when_terminal_background_is_dark() -> None:
    try:
        set_surface_terminal_background((0, 0, 0))
        set_terminal_palette(fg=(255, 255, 255), bg=(0, 0, 0), color_level=ColorLevel.TRUECOLOR)

        rendered = render_styled_line(
            StyledLine((StyledSpan("surface", user_surface_style()),))
        )

        assert "\x1b[48;2;30;30;30m" in rendered
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_user_surface_style_uses_indexed_color_when_terminal_is_ansi256() -> None:
    try:
        set_surface_terminal_background((0, 0, 0))
        set_terminal_palette(fg=(255, 255, 255), bg=(0, 0, 0), color_level=ColorLevel.ANSI256)

        rendered = render_styled_line(
            StyledLine((StyledSpan("surface", user_surface_style()),))
        )

        assert "\x1b[48;5;" in rendered
        assert "\x1b[48;2;" not in rendered
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_user_surface_style_uses_default_style_when_terminal_background_unknown() -> None:
    try:
        reset_surface_theme()
        reset_terminal_palette()

        rendered = render_styled_line(
            StyledLine((StyledSpan("surface", user_surface_style()),))
        )

        assert rendered == "surface"
    finally:
        reset_terminal_palette()
        reset_surface_theme()
