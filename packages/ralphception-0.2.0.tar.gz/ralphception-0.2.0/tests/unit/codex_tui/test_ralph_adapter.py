from __future__ import annotations

from pathlib import Path

import pytest

from ralphception.codex.config import CodexRuntimeSettings
from ralphception.codex_tui.status import DEFAULT_STARTER_PLACEHOLDER
from ralphception.codex_tui.styled_text import strip_ansi
from ralphception.runtime.frontends import (
    ArtifactWriteEvent,
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BackgroundWaitBeginEvent,
    BackgroundWaitEndEvent,
    BackgroundWaitUpdateEvent,
    BlockerPromptEvent,
    FrontendEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    LoopCompletionEvent,
    LoopLaunchEvent,
    MilestoneTranscriptLineEvent,
    RequestUserInputRequestedEvent,
    RequestUserInputResolvedEvent,
    ReviewRequestedEvent,
    RuntimeStatusUpdatedEvent,
    RuntimeStep,
)


def test_adapter_initializes_idle_startup_shell_with_codex_like_footer() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    assert adapter.chatwidget.bottom_pane.composer.placeholder == DEFAULT_STARTER_PLACEHOLDER
    assert adapter.chatwidget.bottom_pane.footer.left_hint == "? for shortcuts"
    assert adapter.chatwidget.bottom_pane.footer.right_status == "100% context left"
    assert adapter.chatwidget.bottom_pane.footer.status_line is None
    assert adapter.chatwidget.notice_lines == (
        "Tip: Ralphception starts with Socratic intake, then writes the PRD, execution plan, loop plan, and todos.",
    )


def test_adapter_uses_codex_placeholder_picker(monkeypatch: pytest.MonkeyPatch) -> None:
    import ralphception.codex_tui.ralph_adapter as ralph_adapter

    monkeypatch.setattr(
        ralph_adapter,
        "pick_starter_placeholder",
        lambda: "Write tests for @filename",
    )

    adapter = ralph_adapter.RalphAdapter(repo_root=Path("/tmp/work"))

    assert adapter.chatwidget.bottom_pane.composer.placeholder == "Write tests for @filename"


def test_adapter_header_uses_codex_model_hint_and_includes_fast_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import ralphception.codex_tui.ralph_adapter as ralph_adapter

    monkeypatch.setattr(
        ralph_adapter,
        "load_codex_runtime_settings",
        lambda: CodexRuntimeSettings(
            model="gpt-5.4",
            reasoning_effort="xhigh",
            service_tier="fast",
            config_path=Path("/tmp/codex/config.toml"),
        ),
    )
    monkeypatch.setattr(ralph_adapter, "resolve_cli_version", lambda repo_root: "0.1.3.dev999+gabcdef123")

    adapter = ralph_adapter.RalphAdapter(repo_root=Path("/tmp/work"))

    assert adapter.chatwidget.header_builder is not None
    header = strip_ansi("\n".join(adapter.chatwidget.header_builder(80)))

    assert "/model to change" in header
    assert "gpt-5.4 xhigh   fast" in header


def test_first_committed_cell_flushes_startup_shell_into_history() -> None:
    from ralphception.codex_tui.history_cell import StartupShellHistoryCell, UserHistoryCell
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.commit_user_message("find typos")

    pending_cells = adapter.drain_pending_history_cells()

    assert adapter.chatwidget.header_lines == ()
    assert adapter.chatwidget.header_builder is None
    assert adapter.chatwidget.notice_lines == ()
    assert isinstance(pending_cells[0], StartupShellHistoryCell)
    assert isinstance(pending_cells[1], UserHistoryCell)
    assert "Ralphception" in "\n".join(pending_cells[0].display_lines(80))
    assert pending_cells[0].transcript_lines(80) == []


def test_committed_prompt_removes_live_startup_header(tmp_path: Path) -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=tmp_path)

    adapter.commit_user_message("hello there")

    rendered = strip_ansi("\n".join(adapter.chatwidget.render_lines(40)))

    assert ">_ Ralphception" not in rendered
    assert "/model to change" not in rendered
    assert "Tip: Ralphception starts with Socratic intake" not in rendered


def test_assistant_events_move_from_active_cell_to_committed_history() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(AssistantDeltaEvent(item_id="assistant-1", text="Inspecting README.md for typos."))

    assert adapter.chatwidget.active_cell is not None
    assert any("Inspecting README.md" in line for line in adapter.chatwidget.active_cell.display_lines(60))

    adapter.apply_event(AssistantFinalEvent(item_id="assistant-1", text="Inspecting README.md for typos."))

    assert adapter.chatwidget.active_cell is None
    history_lines = adapter.drain_pending_history_lines(width=60)
    assert any(strip_ansi(line) == "• Inspecting README.md for typos." for line in history_lines)


def test_command_events_render_live_then_commit_durable_history() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(CommandBeginEvent(item_id="cmd-1", command="git status --short"))
    assert adapter.chatwidget.active_cell is not None
    active_lines = [strip_ansi(line) for line in adapter.chatwidget.active_cell.display_lines(80)]
    assert active_lines[0] == "• Running git status --short"

    adapter.apply_event(CommandOutputDeltaEvent(item_id="cmd-1", text=" M README.md\n"))
    active_lines = [strip_ansi(line) for line in adapter.chatwidget.active_cell.display_lines(80)]
    assert active_lines[1] == "  └  M README.md"

    adapter.apply_event(CommandEndEvent(item_id="cmd-1", command="git status --short", exit_code=0))

    assert adapter.chatwidget.active_cell is None
    history_lines = [strip_ansi(line) for line in adapter.drain_pending_history_lines(width=80)]
    assert history_lines[0] == "• Ran git status --short"
    assert history_lines[1] == "  └  M README.md"


def test_command_work_inserts_separator_before_final_assistant_summary() -> None:
    from ralphception.codex_tui.history_cell import AssistantHistoryCell, CommandHistoryCell, FinalMessageSeparator
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    adapter.commit_user_message("find typos")
    adapter.drain_pending_history_cells()

    adapter.apply_event(CommandBeginEvent(item_id="cmd-1", command="git status --short"))
    adapter.apply_event(CommandEndEvent(item_id="cmd-1", command="git status --short", exit_code=0))
    adapter.apply_event(AssistantFinalEvent(item_id="assistant-1", text="README.md looks clean now."))

    pending_cells = adapter.drain_pending_history_cells()

    assert isinstance(pending_cells[0], CommandHistoryCell)
    assert isinstance(pending_cells[1], FinalMessageSeparator)
    assert isinstance(pending_cells[2], AssistantHistoryCell)


def test_waiting_events_update_bottom_pane_and_active_wait_state() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(
        BackgroundWaitBeginEvent(
            process_id="bg-1",
            command="pytest",
            summary="Waiting on background terminal",
        )
    )

    assert (
        adapter.chatwidget.bottom_pane.waiting_line
        == "• Working (0s • esc to interrupt) · Waiting on background terminal"
    )
    assert adapter.chatwidget.active_cell is not None
    assert any("Waiting on background terminal" in line for line in adapter.chatwidget.active_cell.display_lines(80))

    adapter.apply_event(
        BackgroundWaitUpdateEvent(
            process_id="bg-1",
            summary="Waiting on background terminal for pytest to finish",
        )
    )

    assert (
        adapter.chatwidget.bottom_pane.waiting_line
        == "• Working (0s • esc to interrupt) · Waiting on background terminal for pytest to finish"
    )

    adapter.apply_event(BackgroundWaitEndEvent(process_id="bg-1"))

    assert adapter.chatwidget.bottom_pane.waiting_line is None
    assert adapter.chatwidget.active_cell is None


def test_blocker_prompts_commit_once_and_leave_shell_waiting_for_reply() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    adapter.commit_user_message("find typos")
    adapter.drain_pending_history_lines(width=80)

    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-1",
            title="Startup question",
            question="For this typo pass, which files or areas should I treat as in scope?",
        )
    )
    adapter.apply_event(
        RequestUserInputRequestedEvent(
            prompt_id="prompt-1",
            title="Startup question",
            question="For this typo pass, which files or areas should I treat as in scope?",
            options=("README only", "docs and comments"),
        )
    )

    history_lines = adapter.drain_pending_history_lines(width=80)
    rendered = [strip_ansi(line) for line in adapter.chatwidget.render_lines(100)]

    assert [strip_ansi(line) for line in history_lines] == [
        "• For this typo pass, which files or areas should I treat as in scope?"
    ]
    assert any(line == "  Question 1/1 (1 unanswered)" for line in rendered)
    assert any("which files or areas should i treat as in scope" in line.lower() for line in rendered)
    assert adapter.chatwidget.bottom_pane.waiting_line is None
    assert adapter.chatwidget.bottom_pane.composer.placeholder == "Type your answer (optional)"
    assert adapter.chatwidget.bottom_pane.composer.content_inset == 2
    assert adapter.chatwidget.bottom_pane.footer.left_hint == "enter to submit answer | esc to interrupt"


def test_updated_blocker_question_with_same_prompt_id_commits_new_question() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    adapter.commit_user_message("fix typos")
    adapter.drain_pending_history_lines(width=100)

    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-startup",
            title="Startup question",
            question="For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?",
        )
    )
    adapter.apply_event(
        RequestUserInputRequestedEvent(
            prompt_id="prompt-startup",
            title="Startup question",
            question="For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?",
            options=(),
        )
    )
    adapter.drain_pending_history_lines(width=100)

    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-startup",
            title="Startup question",
            question="For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?",
        )
    )
    adapter.apply_event(
        RequestUserInputRequestedEvent(
            prompt_id="prompt-startup",
            title="Startup question",
            question="For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?",
            options=(),
        )
    )

    history_lines = [strip_ansi(line) for line in adapter.drain_pending_history_lines(width=200)]
    rendered = [strip_ansi(line) for line in adapter.chatwidget.render_lines(140)]

    assert history_lines == [
        "• For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
    ]
    assert any("cleanup constraints or success criteria" in line.lower() for line in rendered)


def test_adapter_drops_internal_skill_usage_milestones_from_history() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    for message in (
        (
            "Using the ralph-execute-task skill because this is a repo-local execution "
            "loop with a defined target artifact and verification requirements."
        ),
        "Using ralph-execute-task because this is a scoped repo-local execution loop on README.md.",
        "Using ralph-execute-task to make a README-only typo pass and verify the edit stays within scope.",
        "• Using ralph-execute-task because this is a repo-local loop execution with implementation and verification.",
    ):
        adapter.apply_event(
            MilestoneTranscriptLineEvent(
                message=message,
            )
        )

    history_lines = adapter.drain_pending_history_lines(width=100)

    assert history_lines == []


def test_adapter_drops_internal_skill_usage_assistant_finals_from_history() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(
        AssistantFinalEvent(
            text="Agent: • Using ralph-execute-task to make a README-only typo pass, keep scope tight, and verify the result.",
            item_id="assistant-1",
        )
    )

    history_lines = adapter.drain_pending_history_lines(width=100)

    assert history_lines == []


def test_adapter_drops_internal_skill_usage_assistant_deltas_from_live_cell() -> None:
    from ralphception.codex_tui.chatwidget import ActiveAssistantCell
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(
        AssistantDeltaEvent(
            item_id="assistant-1",
            text="Agent delta: Using ralph-execute-task for disciplined README-only typo cleanup and verification.",
        )
    )

    assert adapter.chatwidget.active_cell is None or not isinstance(adapter.chatwidget.active_cell, ActiveAssistantCell)


def test_resolved_blocker_restores_idle_shell_placeholder_and_footer() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    idle_placeholder = adapter.chatwidget.bottom_pane.composer.placeholder

    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-1",
            title="Startup question",
            question="For this typo pass, which files or areas should I treat as in scope?",
        )
    )
    adapter.apply_event(RequestUserInputResolvedEvent(prompt_id="prompt-1", choice="README only"))

    assert adapter.chatwidget.bottom_pane.composer.placeholder == idle_placeholder
    assert adapter.chatwidget.bottom_pane.footer.left_hint == "? for shortcuts"


def test_loop_launch_switches_shell_to_working_compose_state() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    idle_placeholder = adapter.chatwidget.bottom_pane.composer.placeholder

    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))

    assert adapter.chatwidget.bottom_pane.waiting_line == "• Working (0s • esc to interrupt) · run-child-1"
    assert adapter.chatwidget.bottom_pane.composer.placeholder == idle_placeholder
    assert adapter.chatwidget.bottom_pane.footer.left_hint == "? for shortcuts"
    assert adapter.chatwidget.bottom_pane.footer.status_line == "gpt-5.4 xhigh fast · 100% left · /tmp/work"


def test_finish_restores_idle_shell_after_working_state() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    idle_placeholder = adapter.chatwidget.bottom_pane.composer.placeholder

    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))
    adapter.finish(RuntimeStep(kind="completed"))

    assert adapter.chatwidget.bottom_pane.composer.placeholder == idle_placeholder
    assert adapter.chatwidget.bottom_pane.footer.left_hint == "? for shortcuts"
    assert adapter.chatwidget.bottom_pane.footer.status_line == "gpt-5.4 xhigh fast · 100% left · /tmp/work"


def test_reply_resolution_then_working_state_uses_shortcuts_footer() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    adapter.apply_event(
        BlockerPromptEvent(
            prompt_id="prompt-1",
            title="Startup question",
            question="For this typo pass, which files or areas should I treat as in scope?",
        )
    )
    adapter.apply_event(RequestUserInputResolvedEvent(prompt_id="prompt-1", choice="README only"))
    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))

    rendered = [strip_ansi(line) for line in adapter.chatwidget.render_lines(100)]

    assert rendered[0] == ""
    assert rendered[1] == "• Working (0s • esc to interrupt) · run-child-1"
    assert rendered[2] == ""
    assert rendered[3].strip() == ""
    assert rendered[4].rstrip() == f"› {adapter.chatwidget.bottom_pane.composer.placeholder}"
    assert rendered[6].startswith("  ? for shortcuts")
    assert rendered[6].endswith("100% context left")


def test_runtime_status_updates_do_not_override_active_loop_label() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))
    adapter.apply_event(
        RuntimeStatusUpdatedEvent(
            status_line_value="258K window",
            quota_label="82K total",
        )
    )

    assert adapter.chatwidget.bottom_pane.waiting_line == "• Working (0s • esc to interrupt) · run-child-1"


def test_milestone_events_commit_durable_transcript_lines() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(
        ArtifactWriteEvent(
            artifact_kind="todos",
            artifact_path=".ralphception/plans/todos.md",
            message="Wrote todos",
        )
    )
    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))
    adapter.apply_event(
        LoopCompletionEvent(
            loop_label="run-child-1",
            message="Loop completed: run-child-1 Completed Ralph loop work for README.md.",
        )
    )

    history_lines = adapter.drain_pending_history_lines(width=80)

    assert any("Wrote todos" in line for line in history_lines)
    assert any("Launched 1 Ralph loop" in line for line in history_lines)
    assert any("Loop completed: run-child-1" in line for line in history_lines)


def test_finish_commits_settled_runtime_line() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.finish(RuntimeStep(kind="completed"))

    history_lines = adapter.drain_pending_history_lines(width=80)

    assert any("Runtime: completed" in line for line in history_lines)


def test_finish_clears_stale_live_loop_and_task_state() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(LoopLaunchEvent(loop_label="run-child-1", message="Launched 1 Ralph loop"))
    adapter.apply_event(
        FrontendEvent(message="Stage: execute", kind="stage.started", stage_kind="execute")
    )

    assert adapter.chatwidget.bottom_pane.waiting_line == "• Working (0s • esc to interrupt) · run-child-1"

    adapter.finish(RuntimeStep(kind="completed"))

    assert adapter.chatwidget.bottom_pane.waiting_line is None


def test_adapter_humanizes_stage_and_suppresses_turn_and_child_run_noise() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))

    adapter.apply_event(FrontendEvent(message="Stage: execute", kind="stage.started", stage_kind="execute"))
    adapter.apply_event(FrontendEvent(message="Child run created: run-child-1"))
    adapter.apply_event(FrontendEvent(message="Turn started: run-child-1 execute", kind="turn.started"))
    adapter.apply_event(FrontendEvent(message="Turn completed: run-child-1 execute", kind="turn.completed"))

    history_lines = [strip_ansi(line) for line in adapter.drain_pending_history_lines(width=80)]

    assert history_lines == ["• Executing the loop plan"]


def test_review_prompt_dedupes_summary_and_follow_up_request_text() -> None:
    from ralphception.codex_tui.ralph_adapter import RalphAdapter

    adapter = RalphAdapter(repo_root=Path("/tmp/work"))
    question = "Spec review diff"

    adapter.apply_event(
        ReviewRequestedEvent(
            review_kind="spec_review",
            run_id="run-root",
            summary_text=question,
            recommended_actions=("approve", "retry"),
        )
    )
    adapter.apply_event(
        RequestUserInputRequestedEvent(
            prompt_id="prompt-1",
            title="Spec review",
            question=question,
            options=("/approve", "/retry"),
        )
    )

    history_lines = [strip_ansi(line) for line in adapter.drain_pending_history_lines(width=80)]

    assert history_lines == ["• Spec review diff"]
