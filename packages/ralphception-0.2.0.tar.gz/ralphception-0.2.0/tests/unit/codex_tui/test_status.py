from __future__ import annotations

from pathlib import Path

from ralphception.codex_tui.bottom_pane import BottomPane, ComposerState, FooterState
from ralphception.codex_tui.ralph_adapter import RalphAdapter
from ralphception.codex_tui.status import (
    ANSWER_PLACEHOLDER,
    DEFAULT_CONTEXT_STATUS,
    REPLY_FOOTER_HINT,
    build_working_status_lines,
    render_footer_lines,
    render_session_header_card,
)
from ralphception.codex_tui.styled_text import strip_ansi
from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette


def test_render_session_header_card_clamps_to_max_width() -> None:
    lines = render_session_header_card(
        version="0.1.3.dev188+gdb4c27b86.dirty",
        directory_label="/private/tmp/ralph-wrap-wdYJKO",
        model_label="gpt-5.4 xhigh   fast",
        max_width=40,
    )

    stripped = [strip_ansi(line) for line in lines]

    assert all(len(line) <= 40 for line in stripped)
    assert stripped[0].startswith("╭")
    assert stripped[0].endswith("╮")
    assert stripped[-1].startswith("╰")
    assert stripped[-1].endswith("╯")


def test_live_chatwidget_header_clamps_to_viewport_width(tmp_path: Path) -> None:
    adapter = RalphAdapter(repo_root=tmp_path)

    lines = [strip_ansi(line) for line in adapter.chatwidget.render_lines(40)]

    assert all(len(line) <= 40 for line in lines)


def test_reply_footer_drops_context_before_clipping_hint() -> None:
    pane = BottomPane(
        composer=ComposerState(value="", placeholder=ANSWER_PLACEHOLDER),
        footer=FooterState(
            left_hint=REPLY_FOOTER_HINT,
            right_status=DEFAULT_CONTEXT_STATUS,
            model_label="gpt-5.4 xhigh fast",
        ),
    )

    lines = [strip_ansi(line) for line in pane.render_lines(40)]
    footer_text = "\n".join(lines[2:])

    assert "enter to submit answer | esc to" in footer_text
    assert "interrupt" in footer_text
    assert "context left" not in footer_text


def test_reply_footer_hides_context_even_when_there_is_room() -> None:
    pane = BottomPane(
        composer=ComposerState(value="", placeholder=ANSWER_PLACEHOLDER),
        footer=FooterState(
            left_hint=REPLY_FOOTER_HINT,
            right_status=DEFAULT_CONTEXT_STATUS,
            model_label="gpt-5.4 xhigh fast",
        ),
    )

    lines = [strip_ansi(line) for line in pane.render_lines(80)]
    footer_text = "\n".join(lines[2:])

    assert "enter to submit answer | esc to interrupt" in footer_text
    assert "context left" not in footer_text


def test_running_draft_footer_shortens_queue_hint_before_dropping_context() -> None:
    lines = [strip_ansi(line) for line in render_footer_lines(
        width=40,
        left_hint="? for shortcuts",
        right_status="98% context left",
        composer_has_draft=True,
        is_task_running=True,
        status_line="gpt-5.4 xhigh fast · 98% left · ~/code/ralphception",
    )]

    assert lines == ["  tab to queue        98% context left  "]


def test_running_draft_footer_drops_context_before_dropping_full_queue_hint() -> None:
    lines = [strip_ansi(line) for line in render_footer_lines(
        width=30,
        left_hint="? for shortcuts",
        right_status="98% context left",
        composer_has_draft=True,
        is_task_running=True,
        status_line="gpt-5.4 xhigh fast · 98% left · ~/code/ralphception",
    )]

    assert lines == ["  tab to queue message        "]


def test_running_draft_footer_keeps_full_queue_hint_once_there_is_room() -> None:
    lines = [strip_ansi(line) for line in render_footer_lines(
        width=50,
        left_hint="? for shortcuts",
        right_status="98% context left",
        composer_has_draft=True,
        is_task_running=True,
        status_line="gpt-5.4 xhigh fast · 98% left · ~/code/ralphception",
    )]

    assert lines == ["  tab to queue message          98% context left  "]


def test_working_status_lines_wrap_details_with_codex_style_prefix() -> None:
    lines = [strip_ansi(line) for line in build_working_status_lines(
        header="Working",
        elapsed_seconds=64,
        inline_message="Preparing startup intake",
        details="Checking the repository and preparing the first Socratic follow-up.",
        width=44,
        animations_enabled=False,
    )]

    assert lines[0] == "• Working (1m 04s • esc to interrupt) · Pre…"
    assert lines[1].startswith("  └ Checking the repository")


def test_animated_working_status_keeps_codex_bullet_prefix() -> None:
    line = build_working_status_lines(
        header="Working",
        elapsed_seconds=5,
        inline_message="Preparing startup intake",
        width=80,
        animations_enabled=True,
        now=0.0,
    )[0]

    stripped = strip_ansi(line)

    assert stripped.startswith("• Working (5s • esc to interrupt) · Preparing startup intake")
    assert stripped[0] == "•"


def test_animated_working_status_uses_shimmer_without_changing_visible_text() -> None:
    set_terminal_palette(fg=(128, 128, 128), bg=(255, 255, 255), color_level=ColorLevel.TRUECOLOR)
    try:
        first = build_working_status_lines(
            header="Working",
            elapsed_seconds=5,
            inline_message="Preparing startup intake",
            width=80,
            animations_enabled=True,
            now=0.0,
        )[0]
        second = build_working_status_lines(
            header="Working",
            elapsed_seconds=5,
            inline_message="Preparing startup intake",
            width=80,
            animations_enabled=True,
            now=1.0,
        )[0]
    finally:
        reset_terminal_palette()

    assert strip_ansi(first) == strip_ansi(second)
    assert first != second


def test_animated_working_status_uses_hollow_spinner_without_truecolor() -> None:
    set_terminal_palette(fg=(128, 128, 128), bg=(255, 255, 255), color_level=ColorLevel.ANSI16)
    try:
        line = build_working_status_lines(
            header="Working",
            elapsed_seconds=5,
            inline_message="Preparing startup intake",
            width=80,
            animations_enabled=True,
            now=0.7,
        )[0]
    finally:
        reset_terminal_palette()

    assert strip_ansi(line).startswith("◦ Working (5s • esc to interrupt)")
