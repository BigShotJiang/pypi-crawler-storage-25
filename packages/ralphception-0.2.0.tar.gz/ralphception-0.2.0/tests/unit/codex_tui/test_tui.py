from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field

from ralphception.codex_tui.custom_terminal import CustomTerminal, Position, Rect, Size
from ralphception.codex_tui.insert_history import insert_history_lines
from ralphception.codex_tui.tui import (
    AnsiBackend,
    Tui,
    _parse_default_background_report,
)
from ralphception.tui_core.palette import (
    ColorLevel,
    get_terminal_palette,
    palette_version,
    reset_terminal_palette,
)
from ralphception.tui_core.text import reset_surface_theme, user_surface_style


@dataclass
class _FakeBackend:
    screen_size: Size = Size(width=80, height=24)
    cursor_position: Position = Position(x=0, y=23)
    writes: list[str] = field(default_factory=list)
    default_foreground: tuple[int, int, int] | None = None
    default_background: tuple[int, int, int] | None = None
    color_level: ColorLevel = ColorLevel.UNKNOWN

    def size(self) -> Size:
        return self.screen_size

    def get_cursor_position(self) -> Position:
        return self.cursor_position

    def write(self, data: str) -> None:
        self.writes.append(data)

    def flush(self) -> None:
        return

    def get_default_foreground(self) -> tuple[int, int, int] | None:
        return self.default_foreground

    def get_default_background(self) -> tuple[int, int, int] | None:
        return self.default_background

    def get_stdout_color_level(self) -> ColorLevel:
        return self.color_level


def test_draw_keeps_bottom_aligned_viewport_pinned_to_bottom_when_height_shrinks() -> None:
    backend = _FakeBackend()
    tui = Tui(terminal=CustomTerminal.with_options(backend))

    tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))
    assert tui.terminal.viewport_area == Rect(x=0, y=20, width=80, height=4)

    tui.draw(2, lambda frame: frame.lines.extend(["status"] * 2))

    assert tui.terminal.viewport_area == Rect(x=0, y=22, width=80, height=2)


def test_draw_bottom_aligns_first_live_viewport_when_cursor_query_falls_back_to_origin() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=0))
    tui = Tui(terminal=CustomTerminal.with_options(backend))

    tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))

    assert tui.terminal.viewport_area == Rect(x=0, y=20, width=80, height=4)


def test_draw_scrolls_upper_region_when_viewport_grows_past_bottom() -> None:
    backend = _FakeBackend()
    tui = Tui(terminal=CustomTerminal.with_options(backend))

    tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))
    backend.writes.clear()

    tui.draw(6, lambda frame: frame.lines.extend(["command output"] * 6))

    rendered = "".join(backend.writes)
    assert "\x1b[1;20r" in rendered
    assert "\x1bD\x1bD" in rendered
    assert tui.terminal.viewport_area == Rect(x=0, y=18, width=80, height=6)


def test_draw_adjusts_viewport_origin_when_terminal_resizes_and_cursor_moves() -> None:
    backend = _FakeBackend()
    tui = Tui(terminal=CustomTerminal.with_options(backend))

    tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))

    backend.screen_size = Size(width=80, height=40)
    backend.cursor_position = Position(x=0, y=39)

    tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))

    assert tui.terminal.viewport_area == Rect(x=0, y=36, width=80, height=4)


def test_ansi_backend_defaults_to_origin_when_cursor_query_is_unavailable(monkeypatch) -> None:
    monkeypatch.setattr(AnsiBackend, "size", lambda self: Size(width=80, height=24))
    backend = AnsiBackend()

    assert backend.get_cursor_position() == Position(x=0, y=0)


def test_parse_default_background_report_supports_rgb_response() -> None:
    report = b"\x1b]11;rgb:f4f4/f4f4/f4f4\x07"

    assert _parse_default_background_report(report) == (244, 244, 244)


def test_ansi_backend_reads_default_background_from_osc_11(monkeypatch) -> None:
    monkeypatch.setattr(AnsiBackend, "size", lambda self: Size(width=80, height=24))
    monkeypatch.setattr(
        AnsiBackend,
        "_query_default_background_report",
        lambda self: b"\x1b]11;rgb:1e1e/1e1e/1e1e\x07",
    )
    backend = AnsiBackend()

    assert backend.get_default_background() == (30, 30, 30)


def test_ansi_backend_falls_back_to_colorfgbg_background_index(monkeypatch) -> None:
    monkeypatch.setattr(AnsiBackend, "size", lambda self: Size(width=80, height=24))
    monkeypatch.setattr(AnsiBackend, "_query_default_background_report", lambda self: None)
    monkeypatch.setenv("COLORFGBG", "15;0")
    backend = AnsiBackend()

    assert backend.get_default_background() == (0, 0, 0)


def test_insert_history_lines_uses_top_anchored_path_when_viewport_starts_at_origin() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=0), writes=[])
    terminal = CustomTerminal.with_home_viewport(backend)
    terminal.set_viewport_area(Rect(x=0, y=0, width=80, height=12))

    insert_history_lines(terminal, ["header", "tip"])

    rendered = "".join(backend.writes)
    assert "\x1bM" not in rendered
    assert "\x1b[3;24r" not in rendered
    assert "\x1b[1;1H" in rendered
    assert terminal.viewport_area == Rect(x=0, y=2, width=80, height=12)


def test_insert_history_lines_uses_near_top_path_when_viewport_starts_on_second_row() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=1), writes=[])
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=1, width=80, height=3))

    insert_history_lines(terminal, ["header", "tip"])

    rendered = "".join(backend.writes)
    assert "\x1bM" not in rendered
    assert "\x1b[2;24r" not in rendered
    assert "\x1b[2;1H" in rendered
    assert terminal.viewport_area == Rect(x=0, y=3, width=80, height=3)


def test_codex_tui_terminal_wrapper_reexports_tui_core_terminal_types() -> None:
    from ralphception.tui_core.terminal import CustomTerminal as CoreCustomTerminal
    from ralphception.tui_core.terminal import Position as CorePosition

    assert CustomTerminal is CoreCustomTerminal
    assert Position is CorePosition


def test_codex_tui_tui_wrapper_reexports_tui_core_tui_types() -> None:
    from ralphception.tui_core.tui import Tui as CoreTui

    assert Tui is CoreTui


def test_draw_requeries_palette_when_terminal_resizes() -> None:
    reset_terminal_palette()
    reset_surface_theme()
    try:
        backend = _FakeBackend(
            default_foreground=(10, 20, 30),
            default_background=(240, 240, 240),
            color_level=ColorLevel.TRUECOLOR,
        )
        tui = Tui(terminal=CustomTerminal.with_options(backend))

        backend.screen_size = Size(width=120, height=40)
        backend.cursor_position = Position(x=0, y=39)
        backend.default_foreground = (40, 50, 60)
        backend.default_background = (15, 15, 15)
        backend.color_level = ColorLevel.ANSI16

        tui.draw(4, lambda frame: frame.lines.extend(["prompt"] * 4))

        assert palette_version() == 1
        assert get_terminal_palette().fg == (40, 50, 60)
        assert get_terminal_palette().bg == (15, 15, 15)
        assert get_terminal_palette().color_level == ColorLevel.ANSI16
        assert user_surface_style().bg is None
    finally:
        reset_terminal_palette()
        reset_surface_theme()
