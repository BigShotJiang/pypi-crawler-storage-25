from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
import re

import pytest

from ralphception.codex_tui.history_cell import (
    AssistantHistoryCell,
    CommandHistoryCell,
    FinalMessageSeparator,
    SystemHistoryCell,
    StartupShellHistoryCell,
    UserHistoryCell,
    WaitingHistoryCell,
)
from ralphception.codex_tui.styled_text import (
    reset_surface_theme,
    set_surface_terminal_background,
    strip_ansi,
)
from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette


@pytest.fixture(autouse=True)
def _default_surface_theme() -> Iterator[None]:
    set_surface_terminal_background((0, 0, 0))
    set_terminal_palette(fg=(255, 255, 255), bg=(0, 0, 0), color_level=ColorLevel.TRUECOLOR)
    try:
        yield
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_user_history_cell_wraps_with_full_surface_block() -> None:
    cell = UserHistoryCell("hello wide world")

    lines = cell.display_lines(10)

    assert [strip_ansi(line) for line in lines] == [
        " " * 10,
        "› hello   ",
        "  wide    ",
        "  world   ",
        " " * 10,
    ]
    assert all("\x1b[48;2;30;30;30m" in line for line in lines[:-1])
    assert all(len(strip_ansi(line)) == 10 for line in lines)
    assert cell.desired_height(10) == 5


def test_user_history_cell_leaves_only_one_blank_row_before_following_system_cell() -> None:
    user_lines = UserHistoryCell("fix all typos in the repo").display_lines(60)
    system_lines = SystemHistoryCell(
        "For this typo pass, are there any constraints or success criteria?"
    ).display_lines(60)

    lines = [strip_ansi(line) for line in [*user_lines, *system_lines]]

    assert lines[0] == " " * 60
    assert lines[1].startswith("› fix all typos in the repo")
    assert lines[2] == " " * 60
    assert lines[3].startswith("• For this typo pass")


def test_user_history_cell_uses_themed_surface_when_terminal_background_is_light() -> None:
    try:
        set_surface_terminal_background((255, 255, 255))
        set_terminal_palette(fg=(0, 0, 0), bg=(255, 255, 255), color_level=ColorLevel.TRUECOLOR)
        cell = UserHistoryCell("hello world")

        lines = cell.display_lines(40)

        assert all("\x1b[48;2;244;244;244m" in line for line in lines[:-1])
        assert "\x1b[48;2;30;30;30m" not in lines[0]
    finally:
        reset_surface_theme()


def test_assistant_history_cell_renders_markdown_lines() -> None:
    cell = AssistantHistoryCell("## Heading\n\n- first item\n- second item")

    lines = cell.display_lines(18)

    assert [strip_ansi(line) for line in lines] == [
        "• ## Heading",
        "",
        "  • first item",
        "  • second item",
    ]


def test_assistant_history_cell_preserves_inline_markdown_styling() -> None:
    cell = AssistantHistoryCell("Use the [skill](app://skill) and `code`.")

    lines = cell.display_lines(80)

    assert [strip_ansi(line) for line in lines] == ["• Use the skill (app://skill) and code."]
    assert "\x1b[" in lines[0]


def test_assistant_history_cell_drops_internal_skill_meta() -> None:
    cell = AssistantHistoryCell("• Using ralph-execute-task because this is a repo-local loop execution.")

    assert cell.display_lines(100) == []


def test_assistant_history_cell_renders_local_file_links_and_blockquotes() -> None:
    cell = AssistantHistoryCell("> See [plan](docs/superpowers/plans/example.md)")

    lines = cell.display_lines(100)

    assert [strip_ansi(line) for line in lines] == ["• > See docs/superpowers/plans/example.md"]
    assert "\x1b[" in lines[0]


def test_assistant_history_cell_shortens_absolute_local_file_links_under_cwd(
    monkeypatch,
) -> None:
    monkeypatch.chdir("/tmp/project")
    cell = AssistantHistoryCell("See [file](/tmp/project/src/app.py)")

    lines = cell.display_lines(100)

    assert [strip_ansi(line) for line in lines] == ["• See src/app.py"]


def test_assistant_history_cell_wraps_with_bullet_width_accounted_for() -> None:
    cell = AssistantHistoryCell("This is a fairly long assistant sentence that should wrap cleanly.")

    lines = [strip_ansi(line) for line in cell.display_lines(16)]

    assert lines == [
        "• This is a",
        "  fairly long",
        "  assistant",
        "  sentence that",
        "  should wrap",
        "  cleanly.",
    ]
    assert all(len(line) <= 16 for line in lines)


def test_system_history_cell_uses_bullet_prefix() -> None:
    cell = SystemHistoryCell("Wrote execution plan")

    lines = cell.display_lines(40)

    assert [strip_ansi(line) for line in lines] == ["• Wrote execution plan"]
    assert re.search(r"\x1b\[[0-9;]*m", lines[0])
    assert cell.desired_height(40) == 1


def test_command_history_cell_includes_status_for_nonzero_exit() -> None:
    cell = CommandHistoryCell(
        command="pytest tests/unit -q",
        output=("2 failed",),
        status="exit 1",
    )

    lines = cell.display_lines(80)

    assert [strip_ansi(line) for line in lines] == [
        "• Ran pytest tests/unit -q",
        "  └ 2 failed",
        "  └ exit 1",
    ]
    assert re.search(r"\x1b\[[0-9;]*m", lines[0])
    assert [strip_ansi(line) for line in cell.transcript_lines(80)] == [
        "• Ran pytest tests/unit -q",
        "  └ 2 failed",
        "  └ exit 1",
    ]


def test_command_history_cell_wraps_long_command_with_tree_continuations() -> None:
    cell = CommandHistoryCell(
        command="git grep -n --hidden --glob '!**/.git/**' --glob '!**/.ralphception/**' typo src tests docs"
    )

    lines = [strip_ansi(line) for line in cell.display_lines(40)]

    assert lines[0].startswith("• Ran git grep -n --hidden --glob")
    assert lines[1].startswith("  │ ")
    assert lines[2].startswith("  │ ")
    assert lines[3].startswith("  │ ")
    assert "typo src" in "\n".join(lines)
    assert lines[3].startswith("  │ … +")


def test_command_history_cell_truncates_long_output_in_middle() -> None:
    cell = CommandHistoryCell(
        command="codespell README.md",
        output=(
            "line 1",
            "line 2",
            "line 3",
            "line 4",
            "line 5",
            "line 6",
        ),
    )

    lines = [strip_ansi(line) for line in cell.display_lines(80)]

    assert lines == [
        "• Ran codespell README.md",
        "  └ line 1",
        "    line 2",
        "    … +2 lines",
        "    line 5",
        "    line 6",
    ]


def test_command_history_cell_wraps_overlong_commands_instead_of_compacting() -> None:
    cell = CommandHistoryCell(
        command=(
            "mkdir -p .ralphception/runs/run-child-1 && cat > "
            ".ralphception/runs/run-child-1/handoff.json <<'JSON' { "
            "\"summary\": \"Fixed obvious typos in README.md\" } JSON"
        )
    )

    lines = [strip_ansi(line) for line in cell.display_lines(40)]

    assert lines[0].startswith("• Ran mkdir -p")
    assert lines[1].startswith("  │ ")
    assert any(line.startswith("  │ … +") for line in lines)
    assert not any(line.endswith("...") for line in lines)


def test_command_history_cell_wraps_unbroken_tokens_instead_of_leaving_one_long_line() -> None:
    cell = CommandHistoryCell(
        command="a_very_long_token_without_spaces_to_force_wrapping"
    )

    lines = [strip_ansi(line) for line in cell.display_lines(24)]

    assert lines[0].startswith("• Ran a_very_long")
    assert lines[1].startswith("  │ ")
    assert lines[2].startswith("  │ ")


def test_command_history_cell_drops_internal_skill_announcement_commands() -> None:
    cell = CommandHistoryCell(
        command="printf 'Using skill: ralph-execute-task — repo-local execution and verification for the request.\\n'",
    )

    assert cell.display_lines(120) == []


def test_command_history_cell_drops_internal_skill_bootstrap_file_reads() -> None:
    cell = CommandHistoryCell(
        command=(
            "pwd && ls && printf '\\n--- SKILL ---\\n' && "
            "cat /private/var/folders/abc123/T/.tmp-skill-home/skills/ralph-execute-task/SKILL.md"
        ),
    )

    assert cell.display_lines(120) == []


def test_command_history_cell_drops_internal_temp_instruction_file_reads() -> None:
    cell = CommandHistoryCell(
        command="pwd && echo '---' && sed -n '1,220p' /private/var/folders/abc123/T/tmp-instructions.md",
    )

    assert cell.display_lines(120) == []


def test_assistant_history_cell_drops_internal_execution_instruction_progress() -> None:
    cell = AssistantHistoryCell(
        "• Progress: inspected the repository root and loaded the execution instructions. Next step is a focused pass on README.md."
    )

    assert cell.display_lines(120) == []


def test_assistant_history_cell_drops_task_specific_execution_instruction_progress() -> None:
    cell = AssistantHistoryCell(
        "• Inspecting the README and the task-specific execution instructions now."
    )

    assert cell.display_lines(120) == []


def test_final_message_separator_renders_full_width_rule() -> None:
    cell = FinalMessageSeparator()

    lines = cell.display_lines(12)

    assert [strip_ansi(line) for line in lines] == ["─" * 12]
    assert re.search(r"\x1b\[[0-9;]*m", lines[0])


def test_waiting_history_cell_height_counts_wrapped_rows() -> None:
    cell = WaitingHistoryCell("Waiting for background terminal output from run-child-1.")

    lines = cell.display_lines(24)

    assert [strip_ansi(line) for line in lines] == [
        "• Waiting for background",
        "  terminal output from",
        "  run-child-1.",
    ]
    assert re.search(r"\x1b\[[0-9;]*m", lines[0])
    assert cell.desired_height(24) == 3


def test_startup_shell_history_cell_renders_indented_notice_band() -> None:
    cell = StartupShellHistoryCell(
        version="0.1.3.dev175+gabcdef123",
        directory_label="~/code/ralphception",
        model_label="gpt-5.4 xhigh   fast",
        notice_lines=(
            "Tip: Ralphception starts with Socratic intake, then writes the PRD, execution plan, loop plan, and todos.",
        ),
    )

    lines = [strip_ansi(line) for line in cell.display_lines(60)]

    assert "  Tip: Ralphception starts with Socratic intake, then writes" in lines
    assert "  the PRD, execution plan, loop plan, and todos." in lines
    assert lines[-1] == ""
