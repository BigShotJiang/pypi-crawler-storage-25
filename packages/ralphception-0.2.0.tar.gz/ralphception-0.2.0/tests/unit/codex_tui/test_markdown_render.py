from __future__ import annotations

import re

from ralphception.codex_tui.markdown_render import render_markdown_lines
from ralphception.codex_tui.styled_text import strip_ansi


def test_render_markdown_lines_styles_h1_headings() -> None:
    lines = render_markdown_lines("# Heading", width=80)

    assert [strip_ansi(line) for line in lines] == ["# Heading"]
    assert "\x1b[1;4m" in lines[0]


def test_render_markdown_lines_styles_inline_code_and_links() -> None:
    lines = render_markdown_lines(
        "Using the [using-superpowers skill](app://skill) with `inline code`.",
        width=120,
    )

    assert [strip_ansi(line) for line in lines] == [
        "Using the using-superpowers skill (app://skill) with inline code."
    ]
    assert re.search(r"\x1b\[[0-9;]*36[0-9;]*musing-superpowers skill\x1b\[0m", lines[0])
    assert re.search(r"\x1b\[[0-9;]*4[0-9;]*m", lines[0])
    assert re.search(r"\x1b\[[0-9;]*36[0-9;]*m" r"app://skill\x1b\[0m", lines[0])
    assert re.search(r"\x1b\[[0-9;]*36[0-9;]*minline code\x1b\[0m", lines[0])


def test_render_markdown_lines_styles_emphasis_and_strong_text() -> None:
    lines = render_markdown_lines("This is *important* and **urgent**.", width=80)

    assert [strip_ansi(line) for line in lines] == ["This is important and urgent."]
    assert re.search(r"\x1b\[[0-9;]*3[0-9;]*mimportant\x1b\[0m", lines[0])
    assert re.search(r"\x1b\[[0-9;]*1[0-9;]*murgent\x1b\[0m", lines[0])


def test_render_markdown_lines_shows_local_file_link_target_instead_of_label() -> None:
    lines = render_markdown_lines("[spec](docs/superpowers/specs/spec.md)", width=80)

    assert [strip_ansi(line) for line in lines] == ["docs/superpowers/specs/spec.md"]
    assert re.search(r"\x1b\[[0-9;]*36[0-9;]*m", lines[0])
    assert not re.search(r"\x1b\[[0-9;]*4[0-9;]*m", lines[0])


def test_render_markdown_lines_renders_ordered_list_markers() -> None:
    lines = render_markdown_lines("1. first item\n2. second item", width=80)

    assert [strip_ansi(line) for line in lines] == ["1. first item", "2. second item"]
    assert "\x1b[" in lines[0]


def test_render_markdown_lines_renders_blockquotes() -> None:
    lines = render_markdown_lines("> quoted line", width=80)

    assert [strip_ansi(line) for line in lines] == ["> quoted line"]
    assert "\x1b[" in lines[0]


def test_render_markdown_lines_renders_fenced_code_blocks_literally() -> None:
    lines = render_markdown_lines("```python\nprint('hi')\n```", width=80)

    assert [strip_ansi(line) for line in lines] == ["  print('hi')"]
    assert "\x1b[" in lines[0]


def test_render_markdown_lines_shortens_absolute_local_path_under_cwd(
    monkeypatch,
) -> None:
    monkeypatch.chdir("/tmp/project")
    lines = render_markdown_lines("[file](/tmp/project/src/app.py)", width=100)

    assert [strip_ansi(line) for line in lines] == ["src/app.py"]


def test_render_markdown_lines_preserves_absolute_local_path_outside_cwd(
    monkeypatch,
) -> None:
    monkeypatch.chdir("/tmp/project")
    lines = render_markdown_lines("[file](/tmp/other/app.py)", width=100)

    assert [strip_ansi(line) for line in lines] == ["/tmp/other/app.py"]


def test_render_markdown_lines_preserves_relative_local_path() -> None:
    lines = render_markdown_lines("[file](src/app.py)", width=100)

    assert [strip_ansi(line) for line in lines] == ["src/app.py"]
