from __future__ import annotations

from dataclasses import dataclass, field

from ralphception.codex_tui.custom_terminal import CustomTerminal, Position, Rect, Size
from ralphception.codex_tui.insert_history import insert_history_lines
from ralphception.codex_tui.styled_text import Style, StyledSpan, join_spans, render_styled_line


@dataclass
class _RecordingBackend:
    screen_size: Size = Size(width=20, height=12)
    cursor_position: Position = Position(x=3, y=10)
    writes: list[str] = field(default_factory=list)

    def size(self) -> Size:
        return self.screen_size

    def get_cursor_position(self) -> Position:
        return self.cursor_position

    def write(self, data: str) -> None:
        self.writes.append(data)

    def flush(self) -> None:
        self.writes.append("<flush>")


def test_insert_history_lines_increments_visible_history_rows() -> None:
    backend = _RecordingBackend()
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=8, width=20, height=4))

    insert_history_lines(terminal, ["alpha", "beta"])

    assert terminal.visible_history_rows == 2
    assert terminal.viewport_area == Rect(x=0, y=8, width=20, height=4)


def test_insert_history_lines_restores_cursor_position() -> None:
    backend = _RecordingBackend()
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=8, width=20, height=4))

    insert_history_lines(terminal, ["alpha"])

    assert terminal.last_known_cursor_pos == Position(x=3, y=10)
    assert any("\x1b[11;4H" in write for write in backend.writes)


def test_insert_history_lines_keeps_viewport_position_when_history_fits_above() -> None:
    backend = _RecordingBackend(screen_size=Size(width=20, height=12), cursor_position=Position(x=0, y=9))
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=6, width=20, height=2))

    insert_history_lines(terminal, ["line 1", "line 2", "line 3"])

    assert terminal.viewport_area == Rect(x=0, y=6, width=20, height=2)
    assert terminal.viewport_area.bottom <= 12


def test_insert_history_lines_only_pushes_viewport_down_by_overflow_rows() -> None:
    backend = _RecordingBackend(screen_size=Size(width=20, height=12), cursor_position=Position(x=0, y=5))
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=2, width=20, height=2))

    insert_history_lines(terminal, ["line 1", "line 2", "line 3"])

    assert terminal.viewport_area == Rect(x=0, y=3, width=20, height=2)


def test_insert_history_lines_wraps_to_terminal_width() -> None:
    backend = _RecordingBackend(screen_size=Size(width=8, height=12), cursor_position=Position(x=0, y=10))
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=9, width=8, height=3))

    insert_history_lines(terminal, ["abcdefghij"])

    assert terminal.visible_history_rows == 2


def test_insert_history_lines_does_not_wrap_ansi_styled_text_by_escape_length() -> None:
    backend = _RecordingBackend(screen_size=Size(width=24, height=12), cursor_position=Position(x=0, y=10))
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=9, width=24, height=3))
    styled_line = render_styled_line(
        join_spans(
            (
                StyledSpan("› ", Style(dim=True, bg="bright_black")),
                StyledSpan("README only", Style(bg="bright_black")),
            )
        )
    )

    insert_history_lines(terminal, [styled_line])

    assert terminal.visible_history_rows == 1
