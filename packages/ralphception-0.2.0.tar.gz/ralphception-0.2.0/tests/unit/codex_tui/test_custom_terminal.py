from __future__ import annotations

from dataclasses import dataclass
from dataclasses import field

import pytest

from ralphception.codex_tui.custom_terminal import CustomTerminal, Position, Rect, Size


@dataclass
class _FakeBackend:
    screen_size: Size = Size(width=80, height=24)
    cursor_position: Position = Position(x=0, y=12)
    writes: list[str] = field(default_factory=list)

    def size(self) -> Size:
        return self.screen_size

    def get_cursor_position(self) -> Position:
        return self.cursor_position

    def write(self, data: str) -> None:
        self.writes.append(data)

    def flush(self) -> None:
        return


def test_custom_terminal_with_options_anchors_viewport_at_cursor_row() -> None:
    terminal = CustomTerminal.with_options(_FakeBackend())

    assert terminal.viewport_area == Rect(x=0, y=12, width=0, height=0)
    assert terminal.last_known_screen_size == Size(width=80, height=24)
    assert terminal.last_known_cursor_pos == Position(x=0, y=12)
    assert terminal.visible_history_rows == 0


def test_set_viewport_area_resizes_buffers_and_clamps_visible_history_rows() -> None:
    terminal = CustomTerminal.with_options(_FakeBackend())
    terminal.note_history_rows_inserted(9)

    terminal.set_viewport_area(Rect(x=0, y=4, width=80, height=8))

    assert terminal.viewport_area == Rect(x=0, y=4, width=80, height=8)
    assert terminal.visible_history_rows == 4


def test_autoresize_updates_screen_size_when_backend_changes() -> None:
    backend = _FakeBackend()
    terminal = CustomTerminal.with_options(backend)

    backend.screen_size = Size(width=120, height=40)
    terminal.autoresize()

    assert terminal.last_known_screen_size == Size(width=120, height=40)


def test_draw_requires_non_negative_height() -> None:
    terminal = CustomTerminal.with_options(_FakeBackend())

    with pytest.raises(ValueError, match="height must be non-negative"):
        terminal.update_viewport_height(-1)


def test_draw_clears_old_rows_when_viewport_top_moves_down() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=23), writes=[])
    terminal = CustomTerminal.with_options(backend)
    terminal.update_viewport_height(10)
    terminal.draw(lambda frame: frame.lines.extend(["header"] * 10))

    backend.writes.clear()

    terminal.update_viewport_height(8)
    terminal.draw(lambda frame: frame.lines.extend(["footer"] * 8))

    rendered = "".join(backend.writes)
    assert "\x1b[15;1H\x1b[2K" in rendered
    assert "\x1b[16;1H\x1b[2K" in rendered


def test_draw_does_not_clear_rows_above_new_viewport_top() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=23), writes=[])
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=14, width=80, height=10))
    terminal.draw(lambda frame: frame.lines.extend(["header"] * 10))

    backend.writes.clear()

    terminal.set_viewport_area(Rect(x=0, y=18, width=80, height=6))
    terminal.draw(lambda frame: frame.lines.extend(["footer"] * 6))

    rendered = "".join(backend.writes)
    assert "\x1b[15;1H\x1b[2K" not in rendered
    assert "\x1b[16;1H\x1b[2K" not in rendered
    assert "\x1b[17;1H\x1b[2K" not in rendered
    assert "\x1b[18;1H\x1b[2K" not in rendered


def test_draw_clears_old_rows_above_new_viewport_top_after_resize_reflow() -> None:
    backend = _FakeBackend(cursor_position=Position(x=0, y=23), writes=[])
    terminal = CustomTerminal.with_options(backend)
    terminal.set_viewport_area(Rect(x=0, y=14, width=80, height=10))
    terminal.draw(lambda frame: frame.lines.extend(["header"] * 10))

    backend.writes.clear()

    terminal.set_viewport_area(Rect(x=0, y=18, width=80, height=6))
    terminal.request_resize_reflow()
    terminal.draw(lambda frame: frame.lines.extend(["footer"] * 6))

    rendered = "".join(backend.writes)
    assert "\x1b[15;1H\x1b[2K" in rendered
    assert "\x1b[16;1H\x1b[2K" in rendered
    assert "\x1b[17;1H\x1b[2K" in rendered
    assert "\x1b[18;1H\x1b[2K" in rendered
