from __future__ import annotations

from collections.abc import Iterator
import pytest

from ralphception.codex_tui.bottom_pane import (
    BottomPane,
    ComposerState,
    FooterState,
    RequestInputOverlayState,
    StatusIndicatorState,
)
from ralphception.codex_tui.chatwidget import ActiveAssistantCell, ChatWidget
from ralphception.codex_tui.custom_terminal import BufferFrame, Rect
from ralphception.codex_tui.styled_text import (
    reset_surface_theme,
    set_surface_terminal_background,
    strip_ansi,
)
from ralphception.tui_core.palette import ColorLevel, reset_terminal_palette, set_terminal_palette


@pytest.fixture(autouse=True)
def _default_surface_theme() -> Iterator[None]:
    set_surface_terminal_background((0, 0, 0))
    set_terminal_palette(fg=(255, 255, 255), bg=(0, 0, 0), color_level=ColorLevel.TRUECOLOR)
    try:
        yield
    finally:
        reset_terminal_palette()
        reset_surface_theme()


def test_idle_chatwidget_renders_prompt_before_footer_with_placeholder() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
            ),
        )
    )

    lines = widget.render_lines(80)

    assert strip_ansi(lines[0]).strip() == ""
    assert strip_ansi(lines[1]).rstrip() == "› Summarize recent commits"
    assert strip_ansi(lines[2]).strip() == ""
    assert "\x1b[48;2;30;30;30m" in lines[0]
    assert "\x1b[48;2;30;30;30m" in lines[1]
    assert "\x1b[48;2;30;30;30m" in lines[2]
    assert strip_ansi(lines[3]).startswith("  ? for shortcuts")
    assert strip_ansi(lines[3]).endswith("100% context left")


def test_status_indicator_renders_above_prompt_with_spacer_and_footer() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(left_hint="? for shortcuts", right_status="100% context left"),
            status_indicator=StatusIndicatorState(
                header="Working",
                inline_message="Waiting on background terminal",
                elapsed_seconds=0,
            ),
        )
    )

    lines = widget.render_lines(80)

    assert strip_ansi(lines[0]).startswith("• Working (0s • esc to interrupt)")
    assert "Waiting on background terminal" in strip_ansi(lines[0])
    assert strip_ansi(lines[1]) == ""
    assert strip_ansi(lines[2]).strip() == ""
    assert strip_ansi(lines[3]).rstrip() == "› Summarize recent commits"
    assert strip_ansi(lines[4]).strip() == ""
    assert "\x1b[48;2;30;30;30m" in lines[2]
    assert "\x1b[48;2;30;30;30m" in lines[3]
    assert "\x1b[48;2;30;30;30m" in lines[4]
    assert strip_ansi(lines[5]).startswith("  ? for shortcuts")
    assert strip_ansi(lines[5]).endswith("100% context left")


def test_committed_history_adds_breathing_room_before_busy_bottom_pane() -> None:
    widget = ChatWidget(
        committed_cells=[],
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
                status_line="gpt-5.4 xhigh fast · 100% left · ~/code/ralphception",
                is_task_running=True,
            ),
            status_indicator=StatusIndicatorState(
                header="Working",
                inline_message="Preparing startup intake",
                elapsed_seconds=0,
            ),
        ),
    )
    widget.committed_cells.append(object())  # type: ignore[arg-type]

    lines = [strip_ansi(line) for line in widget.render_lines(100)]

    assert lines[0] == ""
    assert lines[1].startswith("• Working (0s • esc to interrupt)")
    assert lines[2] == ""
    assert lines[3].strip() == ""
    assert lines[4].rstrip() == "› Summarize recent commits"
    assert lines[6].startswith("  ? for shortcuts")
    assert lines[6].endswith("100% context left")


def test_committed_history_adds_breathing_room_before_active_assistant_cell() -> None:
    widget = ChatWidget(
        committed_cells=[],
        active_cell=ActiveAssistantCell(
            "For this typo pass, are there any constraints or success criteria beyond the default repo-wide scope?"
        ),
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
        ),
    )
    widget.committed_cells.append(object())  # type: ignore[arg-type]

    lines = [strip_ansi(line) for line in widget.render_lines(100)]

    assert lines[0] == ""
    assert lines[1].startswith("For this typo pass, are there any constraints")
    assert lines[2].endswith("scope?")
    assert lines[3] == ""
    assert lines[4].strip() == ""
    assert lines[5].rstrip() == "  › Type your answer (optional)"


def test_draft_hides_shortcuts_hint_and_keeps_context_footer() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="h", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
            ),
        )
    )

    lines = widget.render_lines(80)

    assert strip_ansi(lines[0]).strip() == ""
    assert strip_ansi(lines[1]).rstrip() == "› h"
    assert strip_ansi(lines[2]).strip() == ""
    assert "\x1b[48;2;30;30;30m" in lines[0]
    assert "\x1b[48;2;30;30;30m" in lines[1]
    assert "\x1b[48;2;30;30;30m" in lines[2]
    assert strip_ansi(lines[3]).strip() == "100% context left"


def test_reply_footer_remains_visible_while_typing() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="README only",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
        )
    )

    lines = widget.render_lines(100)

    assert strip_ansi(lines[0]).strip() == ""
    assert strip_ansi(lines[1]).rstrip() == "  › README only"
    assert strip_ansi(lines[2]).strip() == ""
    assert "\x1b[48;2;30;30;30m" in lines[0]
    assert "\x1b[48;2;30;30;30m" in lines[1]
    assert "\x1b[48;2;30;30;30m" in lines[2]
    assert "enter to submit answer | esc to interrupt" in strip_ansi(lines[3])
    assert "context left" not in strip_ansi(lines[3])
    assert len(strip_ansi(lines[3])) <= 100


def test_request_input_overlay_renders_codex_like_freeform_layout() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
            request_input_overlay=RequestInputOverlayState(question="Share details."),
        )
    )

    lines = [strip_ansi(line) for line in widget.render_lines(100)]

    assert lines[0] == "  Question 1/1 (1 unanswered)"
    assert lines[1] == "  Share details."
    assert lines[2] == ""
    assert lines[3].strip() == ""
    assert lines[4].rstrip() == "  › Type your answer (optional)"
    assert lines[5].strip() == ""
    assert lines[6] == ""
    assert lines[7] == ""
    assert lines[8].rstrip() == "  enter to submit answer | esc to interrupt"


def test_request_input_overlay_dims_progress_and_emphasizes_unanswered_question() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
            request_input_overlay=RequestInputOverlayState(question="Share details."),
        )
    )

    lines = widget.render_lines(100)

    assert strip_ansi(lines[0]) == "  Question 1/1 (1 unanswered)"
    assert "\x1b[2m" in lines[0]
    assert strip_ansi(lines[1]) == "  Share details."
    assert "\x1b[36m" in lines[1]


def test_request_input_overlay_keeps_question_emphasis_while_typing_answer() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="Repo-wide, no extra constraints.",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
            request_input_overlay=RequestInputOverlayState(question="Share details."),
        )
    )

    lines = widget.render_lines(100)

    assert strip_ansi(lines[1]) == "  Share details."
    assert "\x1b[36m" in lines[1]


def test_reply_composer_cursor_accounts_for_answer_inset() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(
                value="",
                placeholder="Type your answer (optional)",
                content_inset=2,
            ),
            footer=FooterState(
                left_hint="enter to submit answer | esc to interrupt",
                right_status="100% context left",
            ),
        )
    )

    area = Rect(x=0, y=10, width=80, height=widget.desired_height(80))

    assert widget.cursor_pos(area) == (4, 11)


def test_idle_chatwidget_uses_themed_surface_when_terminal_background_is_light() -> None:
    try:
        set_surface_terminal_background((255, 255, 255))
        set_terminal_palette(fg=(0, 0, 0), bg=(255, 255, 255), color_level=ColorLevel.TRUECOLOR)
        widget = ChatWidget(
            bottom_pane=BottomPane(
                composer=ComposerState(value="", placeholder="Summarize recent commits"),
                footer=FooterState(
                    left_hint="? for shortcuts",
                    right_status="100% context left",
                ),
            )
        )

        lines = widget.render_lines(80)

        assert "\x1b[48;2;244;244;244m" in lines[0]
        assert "\x1b[48;2;244;244;244m" in lines[1]
        assert "\x1b[48;2;30;30;30m" not in lines[0]
    finally:
        reset_surface_theme()


def test_working_state_renders_codex_style_status_row_and_shortcuts_footer() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Implement {feature}"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
                status_line="gpt-5.4 xhigh fast · 100% left · ~/code/ralphception",
                is_task_running=True,
            ),
            status_indicator=StatusIndicatorState(
                header="Working",
                inline_message="run-child-1",
                elapsed_seconds=0,
            ),
        )
    )

    lines = widget.render_lines(100)

    assert strip_ansi(lines[0]) == "• Working (0s • esc to interrupt) · run-child-1"
    assert strip_ansi(lines[1]) == ""
    assert strip_ansi(lines[2]).strip() == ""
    assert strip_ansi(lines[3]).rstrip() == "› Implement {feature}"
    assert "\x1b[48;2;30;30;30m" in lines[4]
    assert strip_ansi(lines[4]).strip() == ""
    assert strip_ansi(lines[5]).startswith("  ? for shortcuts")
    assert strip_ansi(lines[5]).endswith("100% context left")


def test_running_draft_uses_queue_hint_footer_instead_of_passive_status_line() -> None:
    widget = ChatWidget(
        bottom_pane=BottomPane(
            composer=ComposerState(value="follow up", placeholder="Run /review on my current changes"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
                status_line="gpt-5.4 xhigh fast · 100% left · ~/code/ralphception",
                is_task_running=True,
            ),
            status_indicator=StatusIndicatorState(
                header="Working",
                inline_message="Preparing startup intake",
                elapsed_seconds=0,
            ),
        )
    )

    lines = [strip_ansi(line) for line in widget.render_lines(100)]

    assert lines[0].startswith("• Working (0s • esc to interrupt)")
    assert lines[1] == ""
    assert lines[2].strip() == ""
    assert lines[3].rstrip() == "› follow up"
    assert lines[5].startswith("  tab to queue message")
    assert lines[5].rstrip().endswith("100% context left")


def test_notice_lines_render_between_header_and_prompt_with_wrapping() -> None:
    widget = ChatWidget(
        header_lines=("header line",),
        notice_lines=(
            "Tip: Ralphception starts with Socratic intake, then writes the PRD, execution plan, loop plan, and todos.",
        ),
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
                status_line="gpt-5.4 xhigh fast · 100% left · ~/code/ralphception",
            ),
        ),
    )

    lines = widget.render_lines(60)

    assert lines[0] == "header line"
    assert lines[1] == ""
    assert lines[2] == "  Tip: Ralphception starts with Socratic intake, then writes"
    assert lines[3] == "  the PRD, execution plan, loop plan, and todos."
    assert lines[4] == ""
    assert strip_ansi(lines[5]).strip() == ""
    assert strip_ansi(lines[6]).rstrip() == "› Summarize recent commits"


def test_active_assistant_cell_drops_internal_skill_meta() -> None:
    widget = ChatWidget(
        active_cell=ActiveAssistantCell(
            "• Using ralph-execute-task because this is a repo-local loop execution with implementation and verification."
        ),
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
            ),
        ),
    )

    lines = [strip_ansi(line) for line in widget.render_lines(100)]

    assert lines[0].strip() == ""
    assert lines[1].rstrip() == "› Summarize recent commits"


def test_cursor_position_accounts_for_header_and_notice_rows_above_bottom_pane() -> None:
    widget = ChatWidget(
        header_lines=("header line",),
        notice_lines=(
            "Tip: Ralphception starts with Socratic intake, then writes the PRD, execution plan, loop plan, and todos.",
        ),
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
            ),
        ),
    )

    area = Rect(x=0, y=10, width=60, height=widget.desired_height(60))

    assert widget.cursor_pos(area) == (2, 16)


def test_render_top_anchors_live_widget_in_taller_viewport() -> None:
    widget = ChatWidget(
        header_lines=("header line",),
        bottom_pane=BottomPane(
            composer=ComposerState(value="", placeholder="Summarize recent commits"),
            footer=FooterState(
                left_hint="? for shortcuts",
                right_status="100% context left",
            ),
        ),
    )
    frame = BufferFrame(area=Rect(x=0, y=0, width=60, height=12))

    widget.render(frame)

    stripped = [strip_ansi(line) for line in frame.lines]

    assert stripped[0] == "header line"
    assert stripped[1] == ""
    assert stripped[2].strip() == ""
    assert stripped[3].rstrip() == "› Summarize recent commits"
    assert frame.cursor_position == (2, 3)
