from __future__ import annotations


def test_resume_session_prompt_maps_continue_where_we_left_off_to_resume() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="thread-worker-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-resume-1",
        prompt_kind="resume_session",
        title="Resume session",
        question="Pick up where you left off?",
        allowed_actions=("resume", "start_fresh"),
        context={"surface": "session"},
        blocked_continuation=BlockedContinuationRef(
            thread_id="thread-worker-1",
            run_id="run-child-1",
        ),
    )

    result = resolve_prompt_reply(prompt, "continue where we left off", session_manager=None)

    assert result.kind == "resolved"
    assert result.action == "resume"
    assert result.confidence > 0.5


def test_recovery_prompt_treats_do_it_as_ambiguous() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="thread-worker-2",
        owner_run_id="run-child-2",
        prompt_id="prompt-recovery-1",
        prompt_kind="recovery_action",
        title="Recovery action",
        question="Retry or replace the blocked run?",
        allowed_actions=("retry", "replace"),
        context={"surface": "recovery"},
        blocked_continuation=BlockedContinuationRef(
            thread_id="thread-worker-2",
            run_id="run-child-2",
        ),
    )

    result = resolve_prompt_reply(prompt, "do it", session_manager=None)

    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question


def test_startup_prompt_prefers_session_manager_direct_resolution() -> None:
    from typing import cast

    from ralphception.codex.session_manager import CodexSessionManager
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    class FakeSessionManager:
        def __init__(self) -> None:
            self.calls: list[tuple[str, str]] = []

        def resolve_prompt_reply(self, *, prompt, user_text: str):
            self.calls.append((prompt.prompt_id, user_text))
            return {
                "kind": "clarify",
                "clarifying_question": "Which directories should I treat as in scope for this repo-wide cleanup?",
                "confidence": 0.73,
            }

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Start first task",
        question="Describe what you want Ralphception to work on in this workspace.",
        allowed_actions=("bootstrap",),
        context={"intake_answers": []},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )
    session_manager = FakeSessionManager()

    result = resolve_prompt_reply(
        prompt,
        "look for typos",
        session_manager=cast(CodexSessionManager, session_manager),
    )

    assert session_manager.calls == [("prompt-run-root-startup", "look for typos")]
    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )
    assert result.confidence == 0.73


def test_startup_prompt_requires_more_than_a_generic_second_reply_when_codex_is_unavailable() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Start first task",
        question=(
            "I need a little more context before I can write the intake artifacts. "
            "What scope, constraints, or success criteria should I use?"
        ),
        allowed_actions=("bootstrap",),
        context={"intake_answers": ["fix typos"]},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    result = resolve_prompt_reply(prompt, "yes", session_manager=None)

    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question == (
        "For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
    )


def test_startup_prompt_uses_task_shaped_follow_up_for_typo_pass_when_codex_is_unavailable() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Start first task",
        question="Describe what you want Ralphception to work on in this workspace.",
        allowed_actions=("bootstrap",),
        context={"intake_answers": []},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    result = resolve_prompt_reply(prompt, "look at and fix typos in the readme", session_manager=None)

    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )


def test_startup_prompt_rejects_model_authored_bootstrap_summary_when_intake_is_too_thin() -> None:
    from typing import cast

    from ralphception.codex.session_manager import CodexSessionManager
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    class FakeSessionManager:
        def resolve_prompt_reply(self, *, prompt, user_text: str):
            return {
                "kind": "resolved",
                "action": "bootstrap",
                "intake_summary": (
                    "Fix typos in README.md.\n\n"
                    "Additional context:\n"
                    "- Limit edits to README.md.\n"
                    "- Prefer wording and spelling fixes only."
                ),
                "confidence": 0.91,
            }

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Start first task",
        question="Describe what you want Ralphception to work on in this workspace.",
        allowed_actions=("bootstrap",),
        context={"intake_answers": []},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    result = resolve_prompt_reply(
        prompt,
        "fix README typos",
        session_manager=cast(CodexSessionManager, FakeSessionManager()),
    )

    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question == (
        "For this typo pass, what surfaces should be in scope: code, comments, docs, or everything repo-wide?"
    )


def test_startup_prompt_accepts_model_authored_bootstrap_summary_after_richer_loop() -> None:
    from typing import cast

    from ralphception.codex.session_manager import CodexSessionManager
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    class FakeSessionManager:
        def resolve_prompt_reply(self, *, prompt, user_text: str):
            return {
                "kind": "resolved",
                "action": "bootstrap",
                "intake_summary": (
                    "Fix typos in README.md.\n\n"
                    "Additional context:\n"
                    "- Limit edits to README.md.\n"
                    "- Prefer spelling and wording fixes only.\n"
                    "- Treat completion as a clean docs-only typo pass with verification."
                ),
                "confidence": 0.91,
            }

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Clarify scope",
        question="For this typo pass, are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?",
        allowed_actions=("bootstrap",),
        context={"intake_answers": ["fix README typos", "README only"]},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    result = resolve_prompt_reply(
        prompt,
        "Spelling and wording only, and completion means the README reads cleanly.",
        session_manager=cast(CodexSessionManager, FakeSessionManager()),
    )

    assert result.kind == "resolved"
    assert result.action == "bootstrap"
    assert result.intake_summary == (
        "Fix typos in README.md.\n\n"
        "Additional context:\n"
        "- Limit edits to README.md.\n"
        "- Prefer spelling and wording fixes only.\n"
        "- Treat completion as a clean docs-only typo pass with verification."
    )
    assert result.confidence == 0.91


def test_startup_prompt_keeps_asking_after_two_low_information_typo_answers() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-startup",
        prompt_kind="startup_prompt",
        title="Clarify constraints",
        question=(
            "For this typo pass, are there any cleanup constraints or success criteria, "
            "like spelling-only versus light wording cleanup?"
        ),
        allowed_actions=("bootstrap",),
        context={"intake_answers": ["fix any and all typos", "no"]},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    result = resolve_prompt_reply(prompt, "no", session_manager=None)

    assert result.kind == "clarify"
    assert result.action is None
    assert result.clarifying_question == (
        "I still need more context for this typo pass. Are there any cleanup constraints or success criteria, like spelling-only versus light wording cleanup?"
    )


def test_recovery_review_prompt_maps_pause_to_pause() -> None:
    from ralphception.runtime.prompt_resolution import resolve_prompt_reply
    from ralphception.runtime.prompt_state import BlockedContinuationRef, PendingPrompt

    prompt = PendingPrompt(
        thread_id="run-child-1",
        owner_run_id="run-child-1",
        prompt_id="prompt-run-child-1-recovery",
        prompt_kind="recovery_review",
        title="Recovery review",
        question="Retry, replace, pause, or abort the blocked run?",
        allowed_actions=("retry", "replace", "pause", "abort"),
        context={},
        blocked_continuation=BlockedContinuationRef(thread_id="run-child-1", run_id="run-child-1"),
    )

    result = resolve_prompt_reply(prompt, "pause", session_manager=None)

    assert result.kind == "resolved"
    assert result.action == "pause"
    assert result.confidence > 0.5
