from __future__ import annotations

from collections import deque
from pathlib import Path
from typing import cast

import pytest

from ralphception.codex.client import (
    AppServerRpcError,
    AppServerTransportProtocol,
    CodexAppServerClient,
    SubprocessAppServerTransport,
    _THREAD_BASE_INSTRUCTIONS,
    _THREAD_DEVELOPER_INSTRUCTIONS,
    codex_cli_available,
)
from ralphception.config import DEFAULT_CONFIG


def test_codex_cli_available_checks_for_codex_binary(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("ralphception.codex.client.shutil.which", lambda name: "/usr/local/bin/codex")

    assert codex_cli_available() is True


def test_codex_app_server_client_uses_transport_for_initialize_and_thread_start() -> None:
    transport = FakeTransport(
        responses=[
            {"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}},
            {
                "id": 2,
                "result": {
                    "thread": {"id": "thread-123"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    session = client.thread_start(cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)

    assert session.thread_id == "thread-123"
    assert session.workspace_path == "/tmp/workspace"
    assert transport.started is True
    assert transport.requests[0][0] == "initialize"
    assert transport.requests[1][0] == "thread/start"
    request_payload = transport.requests[1][1]
    assert request_payload["baseInstructions"]
    assert request_payload["developerInstructions"]
    assert request_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": True,
    }
    assert "model" not in request_payload


def test_codex_thread_instructions_avoid_runtime_meta_jargon() -> None:
    combined = f"{_THREAD_BASE_INSTRUCTIONS} {_THREAD_DEVELOPER_INSTRUCTIONS}".lower()

    assert "embedded coding agent" not in combined
    assert "autonomous runtime" not in combined
    assert "stage contract" not in combined
    assert "commentary" in combined
    assert "repo-local" in combined


def test_codex_app_server_client_applies_scoped_instructions_to_resume_and_fork() -> None:
    transport = FakeTransport(
        responses=[
            {"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}},
            {
                "id": 2,
                "result": {
                    "thread": {"id": "thread-123"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
            {
                "id": 3,
                "result": {
                    "thread": {"id": "thread-456"},
                    "cwd": "/tmp/workspace",
                    "model": "gpt-5.4",
                    "approvalPolicy": "never",
                    "sandbox": "danger-full-access",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.thread_resume("thread-123", cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)
    client.thread_fork("thread-123", cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)

    resume_payload = transport.requests[1][1]
    fork_payload = transport.requests[2][1]

    assert resume_payload["baseInstructions"]
    assert resume_payload["developerInstructions"]
    assert resume_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": True,
    }
    assert fork_payload["baseInstructions"]
    assert fork_payload["developerInstructions"]
    assert fork_payload["config"] == {
        "features.child_agents_md": False,
        "features.plugins": False,
        "skills.bundled.enabled": True,
    }
    assert "model" not in resume_payload
    assert "model" not in fork_payload


def test_codex_app_server_client_does_not_override_model_or_reasoning_on_turn_start() -> None:
    transport = FakeTransport(
        responses=[
            {"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}},
            {
                "id": 2,
                "result": {
                    "turn": {"id": "turn-123"},
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.turn_start("thread-123", "inspect the workspace", cwd="/tmp/workspace", config=DEFAULT_CONFIG.codex)

    turn_payload = transport.requests[1][1]
    assert "model" not in turn_payload
    assert "effort" not in turn_payload


def test_codex_app_server_client_normalizes_transport_notifications() -> None:
    transport = FakeTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
        notifications=[
            {
                "method": "turn/completed",
                "params": {
                    "threadId": "thread-123",
                    "turnId": "turn-456",
                },
            },
        ],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()
    notification = client.next_notification()

    assert notification.method == "turn/completed"
    assert notification.thread_id == "thread-123"
    assert notification.turn_id == "turn-456"


def test_codex_app_server_client_prepares_transport_for_threads_on_initialize() -> None:
    transport = FakeTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()

    assert transport.prepared_for_threads is True


def test_codex_app_server_client_does_not_wrap_keyboard_interrupt_notifications() -> None:
    class InterruptingTransport(FakeTransport):
        def next_notification(self) -> dict:
            raise KeyboardInterrupt

    transport = InterruptingTransport(
        responses=[{"id": 1, "result": {"userAgent": "ralphception-tests/0.0.0"}}],
    )
    client = CodexAppServerClient(
        cwd="/tmp/workspace",
        transport=cast(AppServerTransportProtocol, transport),
    )

    client.initialize()

    with pytest.raises(KeyboardInterrupt):
        client.next_notification()


def test_subprocess_transport_raises_rpc_errors_from_server_responses(tmp_path: Path) -> None:
    transport = SubprocessAppServerTransport(process_factory=lambda: FakeProcess(stdout_lines=[
        '{"id":1,"error":{"code":-32601,"message":"unknown method"}}',
    ]))

    with pytest.raises(AppServerRpcError, match="unknown method"):
        transport.request("initialize", {"clientInfo": {"name": "tests", "version": "0.0.0"}})


def test_subprocess_transport_disables_child_agents_md_by_default() -> None:
    transport = SubprocessAppServerTransport()

    assert transport._command == ("codex", "app-server", "--disable", "child_agents_md", "--listen", "stdio://")


def test_subprocess_transport_uses_real_user_codex_home(monkeypatch: pytest.MonkeyPatch) -> None:
    source_codex_home = Path("/Users/tester/.codex")
    monkeypatch.setenv("CODEX_HOME", str(source_codex_home))
    monkeypatch.setenv("HOME", "/Users/tester")

    captured: dict[str, object] = {}

    def fake_popen(*args, **kwargs):
        captured["command"] = args[0]
        captured["env"] = kwargs["env"]
        return FakeProcess(stdout_lines=[])

    monkeypatch.setattr("ralphception.codex.client.subprocess.Popen", fake_popen)

    transport = SubprocessAppServerTransport()
    transport.start()

    spawned_env = cast(dict[str, str], captured["env"])
    assert Path(spawned_env["CODEX_HOME"]) == source_codex_home
    assert spawned_env["HOME"] == "/Users/tester"
    assert not any("ralphception-codex-home-" in value for value in spawned_env.values())


def test_subprocess_transport_prepare_for_threads_is_a_noop() -> None:
    transport = SubprocessAppServerTransport(process_factory=lambda: FakeProcess(stdout_lines=[]))

    transport.prepare_for_threads()

    assert True


class FakeTransport:
    def __init__(
        self,
        *,
        responses: list[dict],
        notifications: list[dict] | None = None,
    ) -> None:
        self.responses = deque(responses)
        self.notifications = deque(notifications or [])
        self.requests: list[tuple[str, dict]] = []
        self.started = False
        self.closed = False
        self.prepared_for_threads = False

    def start(self) -> None:
        self.started = True

    def close(self) -> None:
        self.closed = True

    def prepare_for_threads(self) -> None:
        self.prepared_for_threads = True

    def request(self, method: str, params: dict) -> dict:
        self.requests.append((method, params))
        return self.responses.popleft()

    def next_notification(self) -> dict:
        return self.notifications.popleft()


class FakePipe:
    def __init__(self, lines: list[str]) -> None:
        self._lines = deque(lines)
        self.writes: list[str] = []

    def write(self, value: str) -> int:
        self.writes.append(value)
        return len(value)

    def flush(self) -> None:
        return None

    def readline(self) -> str:
        if self._lines:
            return self._lines.popleft() + "\n"
        return ""

    def read(self) -> str:
        remaining = "\n".join(self._lines)
        self._lines.clear()
        return remaining


class FakeProcess:
    def __init__(self, *, stdout_lines: list[str]) -> None:
        self.stdin = FakePipe([])
        self.stdout = FakePipe(stdout_lines)
        self.stderr = FakePipe([])
        self.returncode: int | None = None

    def poll(self) -> int | None:
        return self.returncode

    def terminate(self) -> None:
        self.returncode = 0

    def wait(self, timeout: float | None = None) -> int:
        self.returncode = 0
        return 0
