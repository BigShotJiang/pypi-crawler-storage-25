from __future__ import annotations

from ralphception.runtime.task_state import TaskState


def test_task_state_tracks_authoritative_artifact_revisions_and_plan_context() -> None:
    state = TaskState.new(task_id="task-1", session_id="session-1")

    state = state.with_artifact_revision("prd", "rev-2")
    state = state.with_plan_context(
        plan_id="plan-1",
        loop_graph_id="loop-graph-1",
        plan_node_id="docs",
        active_loop_ids=("loop-a", "loop-b"),
        active_subplan_id="plan-1:docs",
    )

    assert state.task_id == "task-1"
    assert state.session_id == "session-1"
    assert state.authoritative_artifact_revisions["prd"] == "rev-2"
    assert state.plan_id == "plan-1"
    assert state.loop_graph_id == "loop-graph-1"
    assert state.plan_node_id == "docs"
    assert state.active_loop_ids == ("loop-a", "loop-b")
    assert state.active_subplan_id == "plan-1:docs"
