from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
import hashlib
from pathlib import Path
from typing import cast
import threading

import ralphception.runtime.frontends as runtime_frontends
import ralphception.tui.runtime_adapter as runtime_adapter_module
from ralphception.codex.client import normalize_notification
from ralphception.models.runtime import Run, RunStageStatus
from ralphception.models.session import ChildSessionRef
from ralphception.headless import _format_turn_progress_event
from ralphception.models.artifacts import ArtifactRef
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.interactive_session import (
    InteractiveSessionMarker,
    write_interactive_session_marker,
    write_interactive_session_state,
)
from ralphception.runtime.frontends import FrontendEvent
from ralphception.runtime.frontends import (
    AssistantDeltaEvent,
    AssistantFinalEvent,
    BackgroundWaitBeginEvent,
    CommandBeginEvent,
    CommandEndEvent,
    CommandOutputDeltaEvent,
    CurrentLoopLabelEvent,
    CurrentPlanNodeLabelEvent,
    CurrentTaskLabelEvent,
    CurrentWaitingStateEvent,
    LiveStatusEvent,
    ReasoningFinalEvent,
    ReasoningSummaryDeltaEvent,
    RuntimeStatusUpdatedEvent,
    TurnStartedEvent,
)
from ralphception.runtime.prompt_state import BlockedContinuationRef, InteractiveSessionState, PendingPrompt
from ralphception.tui.chatwidget.transcript_cells import ActiveCell, AssistantCell, CommandCell, UserCell
from ralphception.tui.runtime_adapter import RuntimeAdapter
from ralphception.testing.fakes import FakeCodexClient, build_fake_session_manager


def test_runtime_adapter_maps_startup_prompt_to_shell_native_state(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    state = adapter.load_render_state()

    assert state.active_overlay_kind is None
    assert "Seed prompt required" not in "\n".join(state.transcript_rows)
    assert state.bottom_pane.startup_prompt_active is False
    assert state.bottom_pane.composer.placeholder == "Describe the task or ask a question"
    assert state.announcement_rows == ()


def test_runtime_adapter_tracks_startup_source_repos_in_announcement_rows(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.load_render_state()
    adapter.add_startup_source_repo("/tmp/source-a")
    state = adapter.current_render_state()

    assert any(
        "/tmp/source-a" in cell.render_lines(width=80)
        for cell in state.transcript.committed
    )


def test_runtime_adapter_maps_review_prompt_to_conversational_wait_state(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    adapter = RuntimeAdapter(repo_root=repo_root)

    state = adapter.load_render_state()

    assert state.active_overlay_kind is None
    assert state.bottom_pane.composer.placeholder == "Reply to continue"
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.header == "Waiting for your reply"
    assert any(
        "Runtime Spec" in cell.render_lines(width=80)
        for cell in state.transcript.committed
    )


def test_runtime_adapter_state_from_step_uses_pending_prompt_contract(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)
    prompt = PendingPrompt(
        thread_id="run-root",
        owner_run_id="run-root",
        prompt_id="prompt-run-root-spec-review",
        prompt_kind="spec_review",
        title="Review requested",
        question="Review the spec before planning.",
        allowed_actions=("approve",),
        context={"review_kind": "spec_review"},
        blocked_continuation=BlockedContinuationRef(thread_id="run-root", run_id="run-root"),
    )

    state = adapter._state_from_step(runtime_frontends.RuntimeStep(kind="review_prompt", pending_prompt=prompt))

    assert state.bottom_pane.composer.placeholder == "Reply to continue"
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.header == "Waiting for your reply"
    assert any(
        "Review the spec before planning." in cell.render_lines(width=80)
        for cell in state.transcript.committed
    )


def test_runtime_adapter_apply_review_action_resolves_pending_prompt_without_overlay(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    adapter = RuntimeAdapter(repo_root=repo_root)
    state = adapter.load_render_state()

    assert state.active_overlay_kind is None
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.composer.placeholder == "Reply to continue"

    adapter.apply_review_action("approve")
    state = adapter.drain_render_state()

    assert state is not None
    assert any("Approved: spec_review" in cell.render_lines(width=80) for cell in state.transcript.committed)


def test_runtime_adapter_surfaces_review_requested_event_in_transcript_history_while_blocked(tmp_path: Path) -> None:
    repo_root = _prepare_review_workspace(tmp_path)
    adapter = RuntimeAdapter(repo_root=repo_root)
    review_requested_event = getattr(runtime_frontends, "ReviewRequestedEvent")

    adapter.emit_event(
        review_requested_event(
            review_kind="spec_review",
            run_id="run-root",
            summary_text="Spec review pending for .ralphception/specs/runtime.md",
            recommended_actions=("approve",),
        )
    )

    state = adapter.drain_render_state()

    assert state is not None
    assert state.active_overlay_kind is None
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.composer.placeholder == "Reply to continue"
    assert state.transcript.committed
    assert any(
        "Spec review pending for .ralphception/specs/runtime.md" in cell.render_lines(width=80)
        for cell in state.transcript.committed
    )


def test_runtime_adapter_does_not_emit_canned_ready_summary(tmp_path: Path) -> None:
    repo_root = tmp_path / "dashboard-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    adapter = RuntimeAdapter(repo_root=repo_root)
    state = adapter.load_render_state()

    assert state.active_overlay_kind is None
    assert not any(row.startswith("Mission ready for ") for row in state.transcript_rows)


def test_runtime_adapter_keeps_current_task_and_loop_labels_out_of_transcript_history(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(CurrentTaskLabelEvent(label="fix typos in the readme\n\nAdditional context:\n- README only"))
    adapter.emit_event(CurrentPlanNodeLabelEvent(label="execute"))
    adapter.emit_event(CurrentLoopLabelEvent(label="run-child-1"))

    state = adapter.drain_render_state()

    assert state is not None
    rendered_cells = [cell.render_lines(width=80) for cell in state.transcript.committed]
    assert not any("Current task:" in rendered for rendered in rendered_cells)
    assert not any("Current plan node:" in rendered for rendered in rendered_cells)
    assert not any("Current loop:" in rendered for rendered in rendered_cells)


def test_runtime_adapter_activates_child_run_without_committing_child_run_created_message(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    adapter = RuntimeAdapter(repo_root=repo_root)
    adapter.load_render_state()

    adapter.emit_event(FrontendEvent(message="Child run created: run-child-1"))
    state = adapter.drain_render_state()

    assert state is not None
    rendered_cells = [cell.render_lines(width=80) for cell in state.transcript.committed]
    assert not any("Child run created:" in rendered for rendered in rendered_cells)
    assert state.bottom_pane.footer.active_thread_label == "Worker 1 [worker]"


def test_runtime_adapter_prefers_structured_command_events_over_message_parsing(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        CommandEndEvent(command="git status --short", exit_code=0)
    )

    state = adapter.drain_render_state()

    assert state is not None
    cell = state.transcript.committed[-1]
    assert isinstance(cell, CommandCell)
    assert cell.command == "git status --short"
    assert cell.status == "exit 0"


def test_runtime_adapter_maps_agent_message_delta_to_active_cell(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting the workspace."))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active == ActiveCell(
        prefix="assistant",
        text="Inspecting the workspace.",
        item_id="message-1",
    )


def test_runtime_adapter_accumulates_agent_message_deltas_for_the_same_item(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting "))
    adapter.emit_event(AssistantDeltaEvent(item_id="message-1", text="the workspace."))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active == ActiveCell(
        prefix="assistant",
        text="Inspecting the workspace.",
        item_id="message-1",
    )


def test_runtime_adapter_maps_command_output_delta_to_active_command_cell(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(CommandBeginEvent(command="git status --short", item_id="command-1"))
    adapter.emit_event(
        CommandOutputDeltaEvent(
            item_id="command-1",
            text="M src/ralphception/tui/runtime_adapter.py",
        )
    )

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active == ActiveCell(
        prefix="$",
        text="git status --short",
        item_id="command-1",
        output=("M src/ralphception/tui/runtime_adapter.py",),
    )
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.details == "git status --short"


def test_runtime_adapter_commits_assistant_message_after_delta_completion(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting the workspace."))
    adapter.emit_event(AssistantFinalEvent(item_id="message-1", text="Inspecting the workspace."))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active is None
    assert state.transcript.committed[-1] == AssistantCell("Inspecting the workspace.")


def test_runtime_adapter_preserves_milestone_rows_across_store_reprojection(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        runtime_frontends.ArtifactWriteEvent(
            artifact_kind="todos",
            artifact_path=".ralphception/todos/rev-0001.json",
            message="Wrote todos",
        )
    )
    adapter.emit_event(
        FrontendEvent(
            message="Launched 1 Ralph loop",
            kind="loop.launched",
            run_id="run-root",
            stage_kind="execute",
        )
    )
    adapter.emit_event(AssistantDeltaEvent(item_id="message-1", text="Inspecting README.md."))

    state = adapter.drain_render_state()

    assert state is not None
    rendered_cells = [cell.render_lines(width=80) for cell in state.transcript.committed]
    assert any("Wrote todos" in rendered for rendered in rendered_cells)
    assert any("Launched 1 Ralph loop" in rendered for rendered in rendered_cells)
    assert state.transcript.active == ActiveCell(
        prefix="assistant",
        text="Inspecting README.md.",
        item_id="message-1",
    )


def test_runtime_adapter_queues_user_message_while_turn_running(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(TurnStartedEvent(attempt=1))
    adapter.drain_render_state()

    adapter.queue_message(text="Check the last failure.")
    state = adapter.drain_render_state()

    assert state is not None
    assert state.bottom_pane.queued_messages == ("Check the last failure.",)


def test_runtime_adapter_submit_message_while_turn_running_does_not_commit_user_cell(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    class _AliveTurnWorker:
        def is_alive(self) -> bool:
            return True

    adapter.emit_event(TurnStartedEvent(attempt=1))
    adapter.drain_render_state()
    adapter._turn_worker = cast(threading.Thread, _AliveTurnWorker())

    adapter.submit_message(text="Check the last failure.", render_immediately=True)
    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.committed == ()
    assert state.bottom_pane.queued_messages == ("Check the last failure.",)


def test_runtime_adapter_consumed_queued_follow_up_survives_store_projection(tmp_path: Path, monkeypatch) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)
    adapter._transcript_store.commit_user_message("inspect runtime adapter")
    adapter.replace_render_state(
        replace(
            adapter.current_render_state(),
            transcript=runtime_adapter_module._project_transcript_state(adapter._transcript_store),
        )
    )

    consumed = ["check the last failure", None]
    seen_inputs: list[str] = []

    monkeypatch.setattr(adapter, "_run_single_turn", lambda input_text: seen_inputs.append(input_text))
    monkeypatch.setattr(adapter, "_wait_for_next_queued_message", lambda *, timeout: consumed.pop(0))

    adapter._run_live_turn(initial_input="inspect runtime adapter")
    state = adapter.drain_render_state()

    assert seen_inputs == ["inspect runtime adapter", "check the last failure"]
    assert state is not None
    assert [
        cell.text for cell in state.transcript.committed if isinstance(cell, UserCell)
    ] == ["inspect runtime adapter", "check the last failure"]


def test_runtime_adapter_turn_final_projection_returns_idle_after_running_turn(tmp_path: Path, monkeypatch) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)
    adapter.emit_event(TurnStartedEvent(attempt=1))
    adapter.drain_render_state()

    monkeypatch.setattr(adapter, "_run_single_turn", lambda _input_text: None)
    monkeypatch.setattr(adapter, "_wait_for_next_queued_message", lambda *, timeout: None)

    adapter._run_live_turn(initial_input="inspect runtime adapter")
    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active is None
    assert state.bottom_pane.footer.is_task_running is False
    assert state.bottom_pane.status_indicator is None


def test_runtime_adapter_reuses_a_single_session_manager_across_supervisors(tmp_path: Path) -> None:
    repo_root = tmp_path / "dashboard-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    created_managers: list[object] = []

    def session_manager_factory(_repo_root: Path, _config) -> object:
        manager = object()
        created_managers.append(manager)
        return manager

    adapter = RuntimeAdapter(
        repo_root=repo_root,
        session_manager_factory=session_manager_factory,
    )

    first_engine = adapter._build_supervisor().build_engine()
    second_engine = adapter._build_supervisor().build_engine()

    assert first_engine.session_manager is second_engine.session_manager
    assert len(created_managers) == 1


def test_runtime_adapter_updates_footer_from_runtime_status_event(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        RuntimeStatusUpdatedEvent(
            status_line_value="950K window",
            quota_label="26 total",
        )
    )

    state = adapter.drain_render_state()

    assert state is not None
    assert state.bottom_pane.footer.status_line_enabled is True
    assert state.bottom_pane.footer.status_line_value == "950K window"
    assert state.bottom_pane.footer.quota_label == "26 total"


def test_runtime_adapter_creates_running_status_indicator_on_turn_start(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(TurnStartedEvent(attempt=1))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active == ActiveCell(
        prefix="thinking",
        text="Waiting for Ralphception to respond.",
        item_id="turn-wait",
    )
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.header == "Working"
    assert state.bottom_pane.status_indicator.details == "Waiting for Ralphception to respond."
    assert state.bottom_pane.status_indicator.show_interrupt_hint is True


def test_runtime_adapter_uses_reasoning_summary_header_for_live_status(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.active is None
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.header == "Planning codebase inspection"
    assert state.bottom_pane.status_indicator.inline_message is None


def test_runtime_adapter_commits_reasoning_summary_when_reasoning_finishes(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )
    adapter.emit_event(ReasoningFinalEvent(item_id="reasoning-1"))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.committed
    assert state.transcript.committed[-1].render_lines(width=80) == "• Inspect the repo first."


def test_runtime_adapter_commits_reasoning_summary_from_completion_only_event(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(
        ReasoningFinalEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.committed
    assert state.transcript.committed[-1].render_lines(width=80) == "• Inspect the repo first."


def test_runtime_adapter_commits_nonzero_command_exit_status(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)

    adapter.emit_event(CommandEndEvent(command="git status --short", exit_code=2, status="completed"))

    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.committed[-1].render_lines(width=80) == "• Ran git status --short\n  └ exit 2"


def test_raw_token_usage_event_formats_inline_live_status_contract() -> None:
    raw_event = normalize_notification(
        "thread/tokenUsage/updated",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "tokenUsage": {
                "last": {
                    "cachedInputTokens": 1,
                    "inputTokens": 2,
                    "outputTokens": 3,
                    "reasoningOutputTokens": 0,
                    "totalTokens": 6,
                },
                "total": {
                    "cachedInputTokens": 4,
                    "inputTokens": 10,
                    "outputTokens": 12,
                    "reasoningOutputTokens": 0,
                    "totalTokens": 26,
                },
                "modelContextWindow": 950000,
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, LiveStatusEvent)
    assert not isinstance(event, RuntimeStatusUpdatedEvent)
    assert event.kind == "runtime.live_status"
    assert event.text == "Runtime status updated: 950K window · 26 total"
    assert event.status_line_value == "950K window"
    assert event.quota_label == "26 total"


def test_raw_plan_update_event_maps_to_frontend_event() -> None:
    raw_event = normalize_notification(
        "turn/plan/updated",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "explanation": None,
            "plan": [
                {
                    "step": "Inspect repository structure and identify likely failing area",
                    "status": "inProgress",
                },
                {
                    "step": "Implement a fix for the discovered bug",
                    "status": "pending",
                },
            ],
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert event.kind == "turn.plan.updated"
    assert event.payload is not None
    assert event.payload["active_step"] == "Inspect repository structure and identify likely failing area"
    assert event.message == "Plan updated: Inspect repository structure and identify likely failing area"


def test_raw_codex_task_started_event_maps_to_progress_message() -> None:
    raw_event = normalize_notification(
        "codex/event/task_started",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "msg": "Inspecting the workspace before making any changes.",
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, FrontendEvent)
    assert event.kind == "codex.progress"
    assert event.message == "Inspecting the workspace before making any changes."


def test_raw_command_progress_event_strips_shell_wrapper_from_display_command() -> None:
    raw_event = normalize_notification(
        "item/started",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "item": {
                "type": "commandExecution",
                "id": "command-1",
                "command": '/run/current-system/sw/bin/zsh -lc "echo \'--- README ---\' && sed -n \'1,220p\' README.md"',
                "status": "inProgress",
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, CommandBeginEvent)
    assert event.command == "echo '--- README ---' && sed -n '1,220p' README.md"
    assert event.item_id == "command-1"


def test_raw_command_completed_event_preserves_camel_case_exit_code() -> None:
    raw_event = normalize_notification(
        "item/completed",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "item": {
                "type": "commandExecution",
                "id": "command-1",
                "command": "git status --short",
                "status": "completed",
                "exitCode": 0,
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, CommandEndEvent)
    assert event.command == "git status --short"
    assert event.exit_code == 0


def test_raw_agent_message_delta_event_uses_accumulated_text() -> None:
    chunks: dict[str, list[str]] = {}

    first = _format_turn_progress_event(
        normalize_notification(
            "item/agentMessage/delta",
            {
                "threadId": "thread-1",
                "turnId": "turn-1",
                "itemId": "message-1",
                "delta": "Inspecting ",
            },
        ),
        chunks,
    )
    second = _format_turn_progress_event(
        normalize_notification(
            "item/agentMessage/delta",
            {
                "threadId": "thread-1",
                "turnId": "turn-1",
                "itemId": "message-1",
                "delta": "the workspace.",
            },
        ),
        chunks,
    )

    assert first is not None
    assert isinstance(first, AssistantDeltaEvent)
    assert first.item_id == "message-1"
    assert first.text == "Inspecting "
    assert second is not None
    assert isinstance(second, AssistantDeltaEvent)
    assert second.item_id == "message-1"
    assert second.text == "Inspecting the workspace."


def test_raw_agent_message_completion_event_preserves_multiline_text() -> None:
    raw_event = normalize_notification(
        "item/completed",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "item": {
                "type": "agentMessage",
                "id": "message-1",
                "text": "I inspected the workspace.\n\nNext I will run verification.",
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, AssistantFinalEvent)
    assert event.item_id == "message-1"
    assert event.text == "I inspected the workspace.\n\nNext I will run verification."


def test_raw_background_wait_event_formats_inline_waiting_state_contract() -> None:
    raw_event = normalize_notification(
        "subagent_waiting",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "agentThreadId": "worker-1",
            "summary": "Waiting on tail -f log",
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, CurrentWaitingStateEvent)
    assert not isinstance(event, BackgroundWaitBeginEvent)
    assert event.kind == "runtime.current_waiting_state"
    assert event.label == "Waiting on tail -f log"
    assert event.process_id == "worker-1"
    assert event.command == "tail -f log"


def test_raw_reasoning_summary_event_maps_to_typed_reasoning_delta() -> None:
    raw_event = normalize_notification(
        "item/reasoning/summaryTextDelta",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "itemId": "reasoning-1",
            "delta": "**Planning codebase inspection**\n\nI need to inspect the repo first.",
            "summaryIndex": 0,
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, ReasoningSummaryDeltaEvent)
    assert event.item_id == "reasoning-1"
    assert event.text == "**Planning codebase inspection**\n\nI need to inspect the repo first."


def test_raw_reasoning_completion_event_maps_to_typed_reasoning_final() -> None:
    raw_event = normalize_notification(
        "item/completed",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "item": {
                "type": "reasoning",
                "id": "reasoning-1",
                "summary": [
                    {
                        "type": "summary_text",
                        "text": "**Planning codebase inspection**\n\nI need to inspect the repo first.",
                    }
                ],
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, ReasoningFinalEvent)
    assert event.item_id == "reasoning-1"


def test_raw_reasoning_completion_event_preserves_summary_text() -> None:
    raw_event = normalize_notification(
        "item/completed",
        {
            "threadId": "thread-1",
            "turnId": "turn-1",
            "item": {
                "type": "reasoning",
                "id": "reasoning-1",
                "summary": [
                    {
                        "type": "summary_text",
                        "text": "**Planning codebase inspection**\n\nI need to inspect the repo first.",
                    }
                ],
            },
        },
    )

    event = _format_turn_progress_event(raw_event, {})

    assert event is not None
    assert isinstance(event, ReasoningFinalEvent)
    assert event.item_id == "reasoning-1"
    assert event.text == "**Planning codebase inspection**\n\nI need to inspect the repo first."


def test_runtime_adapter_projects_pending_thread_approvals_from_dashboard_state(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="awaiting_approval")
    adapter = RuntimeAdapter(repo_root=repo_root)

    state = adapter.load_render_state()

    assert state.bottom_pane.pending_thread_approvals == ("Worker 1 [worker]",)


def test_runtime_adapter_interrupt_active_turn_aborts_selected_run_session(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-child-1")
    manager.run_turn(run_id="run-child-1", input_text="inspect runtime adapter")

    adapter = RuntimeAdapter(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    adapter.select_agent_thread(thread_id="run-child-1", label="Worker 1 [worker]")
    fake_client = cast(FakeCodexClient, manager.client)

    interrupted = adapter.interrupt_active_turn()

    assert interrupted is True
    assert fake_client.interruptions == [("thread-1", "turn-1")]


def test_runtime_adapter_interrupt_restores_queued_messages_into_composer(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-child-1")
    manager.run_turn(run_id="run-child-1", input_text="inspect runtime adapter")

    adapter = RuntimeAdapter(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    adapter.select_agent_thread(thread_id="run-child-1", label="Worker 1 [worker]")
    adapter.queue_message(text="first queued")
    adapter.queue_message(text="second queued")
    adapter.drain_render_state()

    interrupted = adapter.interrupt_active_turn()
    state = adapter.drain_render_state()

    assert interrupted is True
    assert state is not None
    assert state.bottom_pane.composer.value == "first queued\nsecond queued"
    assert state.bottom_pane.queued_messages == ()


def test_runtime_adapter_interrupt_clears_transcript_store_before_reprojection(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-child-1")
    manager.run_turn(run_id="run-child-1", input_text="inspect runtime adapter")

    adapter = RuntimeAdapter(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    adapter.select_agent_thread(thread_id="run-child-1", label="Worker 1 [worker]")
    adapter.emit_event(
        ReasoningSummaryDeltaEvent(
            item_id="reasoning-1",
            text="**Planning codebase inspection**\n\nI need to inspect the repo first.",
        )
    )
    adapter.drain_render_state()

    interrupted = adapter.interrupt_active_turn()
    state = adapter.drain_render_state()

    assert interrupted is True
    assert state is not None

    reprojection = runtime_adapter_module._project_transcript_store_runtime_state(
        replace(
            state,
            transcript=runtime_adapter_module._project_transcript_state(adapter._transcript_store),
        ),
        adapter._transcript_store,
        idle_hint="? for shortcuts",
    )

    assert reprojection.transcript.active is None
    assert reprojection.bottom_pane.status_indicator is None
    assert reprojection.bottom_pane.footer.is_task_running is False


def test_runtime_adapter_interrupt_prepends_queued_messages_before_existing_draft(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    manager = build_fake_session_manager(workspace_path=str(repo_root))
    manager.start_session(run_id="run-child-1")
    manager.run_turn(run_id="run-child-1", input_text="inspect runtime adapter")

    adapter = RuntimeAdapter(
        repo_root=repo_root,
        session_manager_factory=lambda _repo_root, _config: manager,
    )
    adapter.select_agent_thread(thread_id="run-child-1", label="Worker 1 [worker]")
    adapter.replace_render_state(
        replace(
            adapter.current_render_state(),
            bottom_pane=replace(
                adapter.current_render_state().bottom_pane,
                composer=replace(
                    adapter.current_render_state().bottom_pane.composer,
                    value="current draft",
                ),
            ),
        )
    )
    adapter.queue_message(text="first queued")
    adapter.queue_message(text="second queued")
    adapter.drain_render_state()

    interrupted = adapter.interrupt_active_turn()
    state = adapter.drain_render_state()

    assert interrupted is True
    assert state is not None
    assert state.bottom_pane.composer.value == "first queued\nsecond queued\ncurrent draft"
    assert state.bottom_pane.queued_messages == ()


def test_runtime_adapter_dashboard_prefers_current_child_run_from_workspace_state(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    write_interactive_session_state(
        repo_root,
        InteractiveSessionState(
            root_thread_id="run-root",
            active_thread_id="run-root",
            pending_prompts=[],
            prompt_resolutions=[],
            deferred_inputs=[],
            bootstrap_source_repos=[],
        ),
    )
    (repo_root / ".ralphception" / "runs" / "run-root" / "headless-state.json").write_text(
        '{"current_stage":"execute","current_child_run_id":"run-child-1","child_run_ids":["run-child-1"]}',
        encoding="utf-8",
    )
    adapter = RuntimeAdapter(repo_root=repo_root)

    state = adapter.load_render_state()

    assert state.bottom_pane.footer.active_thread_label == "Worker 1 [worker]"


def test_runtime_adapter_child_run_created_event_switches_to_new_worker_thread(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    adapter = RuntimeAdapter(repo_root=repo_root)
    adapter.load_render_state()

    adapter.emit_event(FrontendEvent(message="Child run created: run-child-1"))
    state = adapter.drain_render_state()

    assert state is not None
    assert state.bottom_pane.footer.active_thread_label == "Worker 1 [worker]"


def test_runtime_adapter_child_run_created_event_sets_specific_waiting_copy(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    adapter = RuntimeAdapter(repo_root=repo_root)
    adapter.load_render_state()

    adapter.emit_event(FrontendEvent(message="Child run created: run-child-1"))
    state = adapter.drain_render_state()

    assert state is not None
    assert state.bottom_pane.status_indicator is not None
    assert state.bottom_pane.status_indicator.header == "Working"
    assert state.bottom_pane.status_indicator.inline_message == "Waiting for Worker 1 to start the Ralph loop."


def test_runtime_adapter_pop_last_queued_message_returns_newest_message(tmp_path: Path) -> None:
    adapter = RuntimeAdapter(repo_root=tmp_path)
    adapter.queue_message(text="first queued")
    adapter.queue_message(text="second queued")
    adapter.drain_render_state()

    assert adapter.pop_last_queued_message() == "second queued"
    assert adapter.pop_last_queued_message() == "first queued"
    assert adapter.pop_last_queued_message() is None


def test_runtime_adapter_start_fresh_clears_transcript_store_history(tmp_path: Path) -> None:
    repo_root = _prepare_child_run_workspace(tmp_path, child_status="running")
    write_interactive_session_marker(
        repo_root,
        InteractiveSessionMarker(
            root_run_id="run-root",
            active_run_id="run-child-1",
            resumable=True,
            updated_at=datetime.now(timezone.utc),
        ),
    )
    adapter = RuntimeAdapter(repo_root=repo_root)
    adapter._transcript_store.commit_user_message("stale transcript")
    adapter.replace_render_state(
        replace(
            adapter.current_render_state(),
            transcript=runtime_adapter_module._project_transcript_state(adapter._transcript_store),
        )
    )

    adapter.apply_launch_action("start_fresh")
    state = adapter.drain_render_state()

    assert state is not None
    assert state.transcript.committed == ()


def _prepare_review_workspace(tmp_path: Path) -> Path:
    repo_root = tmp_path / "review-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    _write_artifact(
        repo_root,
        artifact_kind="spec",
        artifact_path=".ralphception/specs/runtime.md",
        content="# Runtime Spec\n\n- Review before planning.\n",
    )
    return repo_root


def _prepare_child_run_workspace(tmp_path: Path, *, child_status: RunStageStatus) -> Path:
    repo_root = tmp_path / "child-run-workspace"
    repo_root.mkdir()
    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    child_run = Run(
        run_id="run-child-1",
        parent_run_id="run-root",
        supersedes_run_id=None,
        goal="Inspect the runtime adapter implementation",
        status=child_status,
        stage_ids=[],
        config_snapshot={"codex": {"model": "gpt-5.4"}},
        codex_session_ref=ChildSessionRef(
            run_id="run-child-1",
            codex_thread_id="thread-child-1",
            codex_session_id="session-child-1",
            workspace_path=str(repo_root),
            resumable=True,
            last_seen_at=now,
        ),
        artifact_refs=[],
        created_at=now,
        updated_at=now,
    )
    child_run_path = repo_root / ".ralphception" / "runs" / "run-child-1"
    child_run_path.mkdir(parents=True, exist_ok=True)
    (child_run_path / "run.json").write_text(child_run.model_dump_json(indent=2), encoding="utf-8")
    (child_run_path / "headless-state.json").write_text('{"current_stage":"execute"}', encoding="utf-8")
    return repo_root


def _write_artifact(
    repo_root: Path,
    *,
    artifact_kind: str,
    artifact_path: str,
    content: str,
) -> ArtifactRef:
    target = repo_root / artifact_path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return ArtifactRef(
        artifact_kind=artifact_kind,
        artifact_path=artifact_path,
        artifact_version=1,
        content_hash=f"sha256:{hashlib.sha256(content.encode('utf-8')).hexdigest()}",
    )
