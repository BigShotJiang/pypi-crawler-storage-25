import json
from datetime import datetime, timezone

import ralphception.storage.files as storage_files
from ralphception.models.runtime import Checkpoint
from ralphception.runtime.bootstrap import StartupBootstrapController
from ralphception.runtime.interactive_session import (
    InteractiveSessionState,
    interactive_session_path,
    write_interactive_session_state,
)
from ralphception.storage.bootstrap import bootstrap_workspace
from ralphception.storage.checkpoints import read_checkpoint, write_checkpoint
from ralphception.storage.files import write_json_atomic, write_markdown_atomic


def test_bootstrap_creates_required_directories_and_is_idempotent(tmp_path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    assert repo_root == tmp_path

    required_directories = (
        "events",
        "verification",
        "specs",
        "plans",
        "todos",
        "approvals",
        "runs",
        "skills",
        "findings",
        "merge",
        "artifact-pipeline",
        "artifact-pipeline/intake-summary",
        "artifact-pipeline/prd",
        "artifact-pipeline/execution-plan",
        "artifact-pipeline/loop-plan",
        "artifact-pipeline/todos",
    )

    for directory in required_directories:
        assert (repo_root / ".ralphception" / directory).is_dir()

    assert bootstrap_workspace(tmp_path) == repo_root


def test_bootstrap_workspace_durably_creates_storage_tree(tmp_path, monkeypatch) -> None:
    repo_root = tmp_path / "repo"
    repo_root.mkdir()
    fsync_calls: list[int] = []

    def record_fsync(fd: int) -> None:
        fsync_calls.append(fd)

    monkeypatch.setattr(storage_files.os, "fsync", record_fsync)

    bootstrap_workspace(repo_root)

    assert (repo_root / ".ralphception").is_dir()
    assert (repo_root / ".ralphception" / "events").is_dir()
    assert (repo_root / ".ralphception" / "merge").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline" / "intake-summary").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline" / "prd").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline" / "execution-plan").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline" / "loop-plan").is_dir()
    assert (repo_root / ".ralphception" / "artifact-pipeline" / "todos").is_dir()
    assert len(fsync_calls) >= 15


def test_atomic_write_helpers_persist_under_ralphception_without_temp_files(tmp_path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    json_target = repo_root / ".ralphception" / "verification" / "status.json"
    markdown_target = repo_root / ".ralphception" / "specs" / "runtime.md"

    write_json_atomic(json_target, {"status": "ok", "count": 2})
    write_markdown_atomic(markdown_target, "# Runtime\n")

    assert json.loads(json_target.read_text()) == {"status": "ok", "count": 2}
    assert markdown_target.read_text() == "# Runtime\n"
    assert list(json_target.parent.glob(f".{json_target.name}.*.tmp")) == []
    assert list(markdown_target.parent.glob(f".{markdown_target.name}.*.tmp")) == []


def test_atomic_write_helper_fsyncs_file_and_parent_directory(tmp_path, monkeypatch) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    json_target = repo_root / ".ralphception" / "verification" / "status.json"
    fsync_calls: list[int] = []

    def record_fsync(fd: int) -> None:
        fsync_calls.append(fd)

    monkeypatch.setattr(storage_files.os, "fsync", record_fsync)

    write_json_atomic(json_target, {"status": "durable"})

    assert json.loads(json_target.read_text()) == {"status": "durable"}
    assert len(fsync_calls) >= 2


def test_atomic_write_helper_durably_creates_fresh_nested_parent_directories(
    tmp_path,
    monkeypatch,
) -> None:
    target = tmp_path / ".ralphception" / "runs" / "run-1" / "checkpoints" / "checkpoint-1.json"
    fsync_calls: list[int] = []

    def record_fsync(fd: int) -> None:
        fsync_calls.append(fd)

    monkeypatch.setattr(storage_files.os, "fsync", record_fsync)

    write_json_atomic(target, {"checkpoint": "ok"})

    assert target.is_file()
    assert target.parent.is_dir()
    assert json.loads(target.read_text()) == {"checkpoint": "ok"}
    assert list(target.parent.glob(f".{target.name}.*.tmp")) == []
    assert len(fsync_calls) >= 6


def test_checkpoint_round_trip_preserves_recovery_state(tmp_path) -> None:
    repo_root = bootstrap_workspace(tmp_path)
    created_at = datetime(2026, 3, 15, 12, 0, tzinfo=timezone.utc)

    checkpoint = write_checkpoint(
        repo_root,
        checkpoint_id="checkpoint-1",
        run_id="run-1",
        checkpoint_kind="safe_point",
        event_offsets={"run-1": 5, "child-run-1": 2},
        bundle_version=3,
        authoritative_root="/repo",
        active_worktrees=["/repo/.wt/a", "/repo/.wt/b"],
        created_at=created_at,
    )

    persisted_path = (
        repo_root / ".ralphception" / "runs" / "run-1" / "checkpoints" / "checkpoint-1.json"
    )
    loaded = read_checkpoint(repo_root, run_id="run-1", checkpoint_id="checkpoint-1")

    assert persisted_path.is_file()
    assert isinstance(loaded, Checkpoint)
    assert loaded == checkpoint
    assert loaded.authoritative_root == "/repo"
    assert loaded.bundle_version == 3
    assert loaded.active_worktrees == ["/repo/.wt/a", "/repo/.wt/b"]
    assert loaded.event_offsets == {"run-1": 5, "child-run-1": 2}


def test_startup_record_binds_reserved_root_thread_to_root_run(tmp_path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    record = StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    assert record.outer_run_id == "run-root"
    assert record.root_thread_id == "thread-root"


def test_startup_bootstrap_clears_stale_optional_identity_fields(tmp_path) -> None:
    repo_root = bootstrap_workspace(tmp_path)

    write_interactive_session_state(
        repo_root,
        InteractiveSessionState(
            root_thread_id="thread-root",
            active_thread_id="thread-active",
            active_task_id="task-1",
            session_id="session-1",
            plan_id="plan-1",
            loop_graph_id="loop-1",
            active_plan_node_id="plan-node-1",
        ),
    )

    StartupBootstrapController(repo_root).start_first_run(
        seed_prompt="find any bugs",
        source_repos=[],
    )

    payload = json.loads(interactive_session_path(repo_root).read_text(encoding="utf-8"))

    assert payload["root_thread_id"] == "run-root"
    assert payload["active_thread_id"] == "run-root"
    assert "active_task_id" not in payload
    assert "session_id" not in payload
    assert "plan_id" not in payload
    assert "loop_graph_id" not in payload
    assert "active_plan_node_id" not in payload
