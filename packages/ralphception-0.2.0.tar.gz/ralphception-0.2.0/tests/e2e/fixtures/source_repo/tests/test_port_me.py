from pathlib import Path


def test_port_me_contract_mentions_trim_and_uppercase() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    source = (repo_root / "src" / "port_me.ts").read_text(encoding="utf-8")

    assert "trim" in source
    assert "toUpperCase" in source
