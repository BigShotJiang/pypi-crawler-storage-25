export function portMe(input: string): string {
  return input.trim().toUpperCase();
}
