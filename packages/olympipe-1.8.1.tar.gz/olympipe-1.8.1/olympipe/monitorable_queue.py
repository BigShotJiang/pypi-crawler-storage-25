from multiprocessing.managers import SyncManager
from queue import Empty
from typing import Any, Dict, Generic, List, TypeVar

from olympipe.shuttable_queue import ShuttableQueue

R = TypeVar("R")


class MonitorableQueue(ShuttableQueue[R]):
    """ShuttableQueue enrichie d'un miroir partagé permettant peek, drain, clear, pause et throughput."""

    def __init__(self, manager: SyncManager) -> None:
        super().__init__()
        self._mirror = manager.list()
        self._paused = manager.Value("b", 0)
        self._put_count = manager.Value("L", 0)
        self._get_count = manager.Value("L", 0)
        self._errors = manager.list()  # liste de str — erreurs des workers

    def __getstate__(self):  # type: ignore[override]
        return (
            *super().__getstate__(),
            self._mirror,
            self._paused,
            self._put_count,
            self._get_count,
            self._errors,
        )

    def __setstate__(self, state):  # type: ignore[override]
        (
            *parent_state,
            self._mirror,
            self._paused,
            self._put_count,
            self._get_count,
            self._errors,
        ) = state
        super().__setstate__(tuple(parent_state))

    def put(self, item: R, block: bool = True, timeout: "float | None" = None) -> None:  # type: ignore[override]
        super().put(item, block=block, timeout=timeout)
        self._mirror.append(item)
        self._put_count.value += 1

    def get(self, block: bool = True, timeout: "float | None" = None) -> R:  # type: ignore[override]
        if self._paused.value:
            raise Empty()
        item = super().get(block=block, timeout=timeout)
        try:
            self._mirror.pop(0)
        except Exception:
            pass
        self._get_count.value += 1
        return item  # type: ignore[return-value]

    # ── Inspection ────────────────────────────────────────────────────────────

    def peek_all(self) -> List[R]:
        """Retourne une copie du contenu sans consommer les messages."""
        return list(self._mirror)

    def peek_at(self, i: int) -> R:
        """Lit le message à l'index i sans le consommer."""
        try:
            return self._mirror[i]  # type: ignore[return-value]
        except IndexError:
            raise IndexError(
                f"Pas de message à l'index {i} (taille={len(self._mirror)})"
            )

    # ── Contrôle ──────────────────────────────────────────────────────────────

    def pause(self) -> None:
        """Bloque les get() jusqu'au prochain resume()."""
        self._paused.value = 1

    def resume(self) -> None:
        self._paused.value = 0

    @property
    def is_paused(self) -> bool:
        return bool(self._paused.value)

    def clear(self) -> None:
        """Vide la queue et le miroir."""
        while True:
            try:
                super().get(block=False)
            except Exception:
                break
        try:
            del self._mirror[:]
        except Exception:
            pass

    def drain(self) -> List[R]:
        """Consomme et retourne tous les messages en attente."""
        items = list(self._mirror)
        self.clear()
        return items

    # ── Erreurs workers ───────────────────────────────────────────────────────

    def add_error(self, msg: str) -> None:
        """Enregistre une erreur provenant d'un worker et met la queue en pause."""
        try:
            self._errors.append(msg[:1000])
            # Garder 10 erreurs max
            while len(self._errors) > 10:
                del self._errors[0]
        except Exception:
            pass
        # Auto-pause : on arrête de consommer pour pouvoir inspecter
        self._paused.value = 1

    def get_errors(self) -> List[str]:
        return list(self._errors)

    def clear_errors(self) -> None:
        try:
            del self._errors[:]
        except Exception:
            pass
        self._paused.value = 0

    # ── Snapshot ──────────────────────────────────────────────────────────────

    def snapshot(self) -> Dict[str, Any]:
        """État instantané pour le monitoring."""
        return {
            "pid": self.pid,
            "size": len(self._mirror),
            "max_size": self._maxsize,  # type: ignore[attr-defined]
            "paused": self.is_paused,
            "put_count": self._put_count.value,
            "get_count": self._get_count.value,
            "errors": list(self._errors),
        }
