import copy
from multiprocessing.managers import DictProxy
from queue import Empty, Full
from typing import Any, Callable, List, Optional, Tuple

from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import InPacket

from .generic import GenericPipe, _PicklableCallable


class SplitterPipe(GenericPipe[InPacket, Any]):
    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        targets: "List[ShuttableQueue[Any]]",
        split_function: Callable[[InPacket], Tuple[Optional[Any], ...]],
        target: "Optional[ShuttableQueue[Any]]" = None,
        auto_start: bool = True,
    ):
        if not targets:
            raise ValueError("SplitterPipe requires at least one target queue")
        self._targets = targets
        self._split_fn = _PicklableCallable(split_function)
        super().__init__(father_process_dag, source, targets[0], auto_start)

    @property
    def shortname(self) -> str:
        return f"split:{self._split_fn.__name__}"

    def _perform_task(self, data: InPacket) -> Any:
        results = self._split_fn(data)
        for i, result in enumerate(results):
            if result is not None and i < len(self._targets):
                while True:
                    try:
                        self._targets[i].put(result, timeout=self._timeout)
                        break
                    except (Full, TimeoutError):
                        if self.should_quit():
                            break
        return data

    def _send_to_next(self, processed: Any) -> None:
        pass

    def unregister_from_dag(self) -> None:
        pid = str(self.pid)
        try:
            frozen_dag: dict = copy.deepcopy(self._father_process_dag._getvalue())
            keys_to_delete: List[str] = []
            source_closed = False
            for key, pids in frozen_dag.items():
                if pid in pids:
                    filtered_pids = [p for p in pids if p != pid]
                    if len(filtered_pids) > 0:
                        self._father_process_dag[key] = filtered_pids
                    else:
                        keys_to_delete.append(key)
                        if not source_closed:
                            self._source_queue.close()
                            source_closed = True
            for key in keys_to_delete:
                _ = self._father_process_dag.pop(key)
            if pid in frozen_dag:
                _ = self._father_process_dag.pop(pid)
            # Signal downstream consumers (GatherPipes etc.) that production is done
            for target in self._targets:
                target.close()
        except (KeyError, OSError, ConnectionError, EOFError, BrokenPipeError) as e:
            print(f"Warning: Could not unregister SplitterPipe from DAG: {e}")
