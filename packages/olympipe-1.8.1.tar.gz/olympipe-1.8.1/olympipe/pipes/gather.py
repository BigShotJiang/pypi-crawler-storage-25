from multiprocessing.managers import DictProxy
from typing import Any, List

from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import InPacket

from .generic import GenericPipe


class GatherPipe(GenericPipe[InPacket, InPacket]):
    """Pipe identité : lit depuis une source et écrit vers la queue agrégée partagée."""

    @property
    def shortname(self) -> str:
        return "gather"

    def can_quit(self) -> bool:
        """GatherPipe se base uniquement sur is_closed, car la source peut appartenir
        à un pipeline externe (DAG différent)."""
        if self.should_quit():
            return True
        if self._source_queue.is_closed:
            return self._source_queue.empty()
        return False

    def _perform_task(self, data: InPacket) -> InPacket:
        return data
