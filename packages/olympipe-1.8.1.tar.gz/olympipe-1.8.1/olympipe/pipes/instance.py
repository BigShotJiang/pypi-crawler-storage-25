from multiprocessing.managers import BaseManager, DictProxy
from typing import Any, Callable, Dict, List, Optional, Type

from olympipe.shuttable_queue import ShuttableQueue
from olympipe.types import ClassType, InPacket, OutPacket

from .generic import GenericPipe, _PicklableCallable


class ClassInstancePipe(GenericPipe[InPacket, OutPacket]):
    def __init__(
        self,
        father_process_dag: "DictProxy[str, List[str]]",
        source: "ShuttableQueue[InPacket]",
        class_constructor: Type[ClassType],
        class_method: Callable[[ClassType, InPacket], OutPacket],
        target: "ShuttableQueue[OutPacket]",
        close_method: Optional[Callable[[ClassType], Any]] = None,
        class_args: Optional[List[Any]] = None,
        class_kwargs: Optional[Dict[str, Any]] = None,
        auto_start: bool = True,
    ):
        BaseManager.register(class_constructor.__name__, class_constructor)
        self._class_constructor = _PicklableCallable(class_constructor)
        self._class_method = _PicklableCallable(class_method)
        self._close_method = (
            _PicklableCallable(close_method) if close_method is not None else None
        )
        self._class_args = class_args or []
        self._class_kwargs = class_kwargs or {}
        super().__init__(father_process_dag, source, target, auto_start)

    @property
    def shortname(self) -> str:
        return f"{self._class_constructor.__name__}:{self._class_method.__name__}"

    def start(self) -> None:
        self._instance = self._class_constructor(
            *self._class_args, **self._class_kwargs
        )
        self._task = _PicklableCallable(
            getattr(self._instance, self._class_method.__name__)
        )
        if self._close_method is not None:
            self._close_method_name: Optional[str] = self._close_method.__name__
            self._close_method = _PicklableCallable(
                getattr(self._instance, self._close_method.__name__)
            )
        else:
            self._close_method_name = None
        return super().start()

    def __getstate__(self) -> Dict[str, Any]:
        import cloudpickle  # type: ignore[import-untyped]

        state = self.__dict__.copy()
        if "_instance" in state:
            state["_instance"] = cloudpickle.dumps(state["_instance"])
        # Ne pas sérialiser _task/_close_method (bound methods) car ils
        # seront rebindés sur _instance après désérialisation
        state.pop("_task", None)
        state.pop("_close_method", None)
        return state

    def __setstate__(self, state: Dict[str, Any]) -> None:
        import cloudpickle  # type: ignore[import-untyped]

        if "_instance" in state and isinstance(state["_instance"], bytes):
            state["_instance"] = cloudpickle.loads(state["_instance"])
        self.__dict__.update(state)
        # Rebinder _task et _close_method sur l'instance désérialisée
        instance = self.__dict__.get("_instance")
        if instance is not None:
            self._task = _PicklableCallable(
                getattr(instance, self._class_method.__name__)
            )
            close_name = getattr(self, "_close_method_name", None)
            if close_name is not None:
                self._close_method = _PicklableCallable(getattr(instance, close_name))
            else:
                self._close_method = None

    def _perform_task(self, data: InPacket) -> OutPacket:
        return self._task(data)

    def _kill(self):
        if self._close_method is not None:
            self._close_method()  # type: ignore
        super()._kill()
