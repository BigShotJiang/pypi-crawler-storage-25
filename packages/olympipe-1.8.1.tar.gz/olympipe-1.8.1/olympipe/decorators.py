import inspect
import typing
from typing import Any, Callable, Optional, Type, TypeVar

import olympipe.registry as _reg

F = TypeVar("F", bound=Callable[..., Any])
C = TypeVar("C", bound=type)


def source(fn: F) -> F:
    """Marque une fonction génératrice comme source de pipeline."""
    _reg.register_source(fn)
    return fn


def source_from(iterable: Any, name: Optional[str] = None) -> Any:
    """Enregistre n'importe quel itérable (liste, range, generateur…) comme source.

    Usage::

        my_list = source_from([1, 2, 3], name="my_list")
        my_range = source_from(range(100), name="my_range")
    """
    _name = name or getattr(iterable, "__name__", None) or f"source_{id(iterable)}"

    def _wrapper():
        yield from iterable

    _wrapper.__name__ = _name
    _wrapper.__qualname__ = _name
    _reg.register_source(_wrapper)
    return iterable  # l'itérable original reste intact


def task(fn: F) -> F:
    """Marque une fonction de transformation."""
    _reg.register_task(fn)
    return fn


def filter(fn: F) -> F:  # noqa: A001
    """Marque une fonction de filtrage (doit retourner bool)."""
    try:
        hints = typing.get_type_hints(fn)
        ret = hints.get("return", inspect.Parameter.empty)
        if ret is not inspect.Parameter.empty and ret is not bool:
            raise TypeError(
                f"@filter: '{fn.__name__}' doit retourner bool, "
                f"pas {getattr(ret, '__name__', ret)}"
            )
    except TypeError:
        raise
    except Exception:
        pass  # impossible d'inspecter → on laisse passer
    _reg.register_filter(fn)
    return fn


def splitter(fn: F) -> F:
    """Marque une fonction de séparation de packets vers N sorties.

    La fonction doit retourner un tuple/liste de taille N où chaque élément
    non-None est envoyé vers la queue de sortie correspondante.

    Exemple::

        @splitter
        def route(packet) -> Tuple[Optional[int], Optional[int]]:
            if packet % 2 == 0:
                return (packet, None)
            return (None, packet)

        evens, odds = pipeline.split(route)
    """
    _reg.register_splitter(fn)
    return fn


def class_task(
    method: str,
    close: Optional[str] = None,
    name: Optional[str] = None,
) -> Callable[[C], C]:
    """Décore une classe pour l'utiliser comme étape class_task dans un pipeline."""

    def decorator(cls: C) -> C:
        _reg.register_class_task(cls, method=method, close=close, name=name)
        return cls

    return decorator
