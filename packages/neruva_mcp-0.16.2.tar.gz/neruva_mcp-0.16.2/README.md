# neruva-mcp

MCP server for [Neruva](https://neruva.io) — agent memory substrate with knowledge graph, causal reasoning, and federated context assembly. Drop into Claude Code / Cursor / Codex / Gemini CLI in one line.

## What's new in 0.16

| Capability | Tool(s) |
|---|---|
| Auto-managed entity extraction (server-side) | `agent_remember(extract="managed")` |
| Federated agent memory (records + KG, one call) | `agent_remember` · `agent_recall` · `agent_context` |
| Cross-session graph RAG | `agent_recall(namespaces=[...])` |
| Question-type dispatch (temporal / multi-hop / single-hop / adversarial) | `agent_context(question_type="auto")` |
| Pearl's do-operator on agent memory | `agent_causal_query` |
| Provable replay (snapshot + restore) | `agent_snapshot` · `agent_restore` |
| Anomaly detection on quorum KGs | `agent_check_consistency` |
| Fact invalidation (Zep-style temporal resolution) | `hd_kg_replace_fact` |
| Canonical extraction prompt (BYO-LLM) | `hd_kg_extraction_prompt` |
| 5 KG engines: hadamard / opb / multi-shard / quorum / feature-bundle | `hd_kg_add_fact(engine=...)` |
| Concept blending (provenance-preserving merge) | `hd_blend_query` |
| Case-based episode retrieval | `hd_cbr_*` |

**~70 tools across Records, KG, Causal, Analogy, CBR, Blend, Vector memory, federated agent_*, self-introspection.**

## Install

```bash
# In Claude Code (any directory, user scope):
claude mcp add-json neruva '{"command":"npx","args":["-y","@neruva/mcp@latest"],"env":{"NERUVA_API_KEY":"nv_..."}}'
```

Or one-line install via npx for any MCP host:

```bash
npx -y @neruva/mcp@latest    # one-off
npm i -g @neruva/mcp         # then `neruva-mcp`
```

Get an API key at https://app.neruva.io (free tier, no credit card).

## Wire into a host

### Claude Code
```bash
claude mcp add-json neruva '{"command":"npx","args":["-y","@neruva/mcp@latest"],"env":{"NERUVA_API_KEY":"..."}}'
```

### Cursor (`~/.cursor/mcp.json`)
```json
{
  "mcpServers": {
    "neruva": {
      "command": "npx",
      "args": ["-y", "@neruva/mcp@latest"],
      "env": { "NERUVA_API_KEY": "..." }
    }
  }
}
```

### Codex (`~/.codex/config.toml`)
```toml
[mcp_servers.neruva]
command = "npx"
args = ["-y", "@neruva/mcp@latest"]
env = { NERUVA_API_KEY = "..." }
```

### Gemini CLI (`~/.gemini/settings.json`)
```json
{ "mcpServers": { "neruva": { "command": "npx", "args": ["-y", "@neruva/mcp@latest"], "env": { "NERUVA_API_KEY": "..." } } } }
```

## The substrate, in one paragraph

Five layers, one API. **Records** = typed agentic events (decisions, mistakes, tool_calls, llm_turns; auto-embedded at D=1024). **Knowledge Graph** = mutable structured state across 5 engines, sub-ms cosine retrieval, matrix-power N-hop derive. **Causal** = Pearl's do-operator (`observation` vs `intervention` arithmetically distinct). **Analogy** = `a:b::c:?` in HD feature space. **Concept Blending** = provenance-preserving merge of multiple memories. **CBR** = factored episode store. The new **federated agent_*** layer (agent_remember / agent_recall / agent_context) routes across all substrates so a single call handles "where does X store, and how do I get it back?"

Deterministic from a seed. Replayable bit-exactly. Portable as `.neruva` containers — your data is yours.

## Three-line LangChain integration

```python
# pip install neruva-langchain
from neruva_langchain import NeruvaChatMessageHistory
history = NeruvaChatMessageHistory(namespace="user_alice")
# wire into any chain that takes BaseChatMessageHistory
```

Same pattern: `neruva-langgraph` (BaseCheckpointSaver + BaseStore), `neruva-crewai` (Storage interface + 3 memory flavors).

## Auto-record for Claude Code

```bash
pip install neruva-record && neruva-record-install
```

Every Claude Code session lands in your Neruva account: tool calls, chat turns, secrets-redacted client-side, queryable across sessions.

## Why use this over a vector DB or Zep

| | Vector DB | Zep | Neruva |
|---|---|---|---|
| KG engines | 0 | 1 | 5 |
| Causal queries (Pearl do-operator) | ❌ | ❌ | ✅ |
| Provable replay (deterministic snapshot/restore) | ❌ | ❌ | ✅ |
| Anomaly detection (quorum disagreement) | ❌ | ❌ | ✅ |
| Federated context (records+KG one call) | ❌ | partial | ✅ |
| Portable container | ❌ | ❌ | ✅ `.neruva` |
| p95 latency | varies | 189–200ms | <100ms |
| Cost per recall vs context-stuffing | varies | varies | ~3,125× cheaper |

## Auth

Set `NERUVA_API_KEY` in env. `NERUVA_URL` defaults to `https://api.neruva.io`.

Optional: `NERUVA_AUTO_RECORD=namespace[:ttl_days]` — every tool call this agent makes auto-records into the named records namespace. Fire-and-forget, never blocks or breaks the call.

## Update flow

The startup banner prints when a newer version is available:
```
[neruva-mcp] update available: you have 0.16.0, latest is 0.16.1.
```

If registered with `@neruva/mcp@latest`, a Claude Code restart auto-updates.

## License

MIT
