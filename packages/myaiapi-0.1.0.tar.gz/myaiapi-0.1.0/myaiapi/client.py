import requests


class MyAiApiClient:
    def __init__(self, api_key: str, base_url: str = "https://api.myaiui.io/v1"):
        if not api_key:
            raise ValueError("api_key is required")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

        self.headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

    def list_endpoints(self):
        url = f"{self.base_url}/endpoints"
        r = requests.get(url, headers=self.headers, timeout=30)
        r.raise_for_status()
        return r.json()

    def get_endpoint_details(self, endpoint_name: str):
        url = f"{self.base_url}/endpoints/{endpoint_name}"
        r = requests.get(url, headers=self.headers, timeout=30)
        r.raise_for_status()
        return r.json()

    def run_llm(self, prompt, max_tokens=50, temperature=0.7, endpoint="llm_default"):
        url = f"{self.base_url}/run/{endpoint}"

        payload = {
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        r = requests.post(url, json=payload, headers=self.headers, timeout=300)
        r.raise_for_status()

        return self._parse_response(r.json())

    def _parse_response(self, data):
        runpod_data = data.get("data", {})

        return {
            "request_id": data.get("request_id"),
            "endpoint": data.get("endpoint"),
            "units": data.get("units"),
            "duration_ms": data.get("duration_ms"),
            "response": (
                runpod_data.get("output", {})
                .get("choices", [{}])[0]
                .get("text", "")
                .strip()
            ),
            "raw": runpod_data,
        }