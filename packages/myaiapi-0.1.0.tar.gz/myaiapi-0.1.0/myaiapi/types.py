from typing import Any, Dict, Optional


class LLMResponse:
    def __init__(
        self,
        request_id: Optional[str],
        endpoint: Optional[str],
        units: Optional[int],
        duration_ms: Optional[int],
        response: str,
        raw: Dict[str, Any],
    ):
        self.request_id = request_id
        self.endpoint = endpoint
        self.units = units
        self.duration_ms = duration_ms
        self.response = response
        self.raw = raw

    def __repr__(self):
        return f"<LLMResponse response={self.response[:50]!r}>"