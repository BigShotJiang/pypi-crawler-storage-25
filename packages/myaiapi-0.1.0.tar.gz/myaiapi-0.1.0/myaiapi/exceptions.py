class StepXStepError(Exception):
    """Base exception for all StepXStep SDK errors."""
    pass


class APIError(StepXStepError):
    """Raised when the API returns a non-200 response."""
    def __init__(self, status_code: int, message: str):
        super().__init__(f"APIError {status_code}: {message}")
        self.status_code = status_code
        self.message = message


class AuthenticationError(StepXStepError):
    """Raised when API key is invalid or missing."""
    pass


class RateLimitError(StepXStepError):
    """Raised when API rate limits are exceeded."""
    pass


class InvalidResponseError(StepXStepError):
    """Raised when API returns malformed data."""
    pass