---

## 🧱 Build package

```bash
python3 -m build
```

---

## 🚀 Upload to PyPI

```bash
twine upload dist/*
```

---

## 🔐 (If using API token manually)

```bash
TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi_xxx twine upload dist/*
```

---

## 🧠 Typical release flow

```bash
# bump version first (pyproject.toml)
python3 -m build
twine upload dist/*
```
# myai.api
