"""Headless Textual TUI tests using Textual's built-in ``run_test`` harness.

These exercise the real ``AutobotsTUI`` app the way a user would see it
but drive it through Textual's Pilot so they run anywhere (including CI
without a real terminal).
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

import json
import pytest


@pytest.mark.asyncio
async def test_tui_shows_login_when_unauthenticated(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # No tokens on disk → we must land on the login screen.
        assert type(app.screen).__name__ == "LoginScreen"


@pytest.mark.asyncio
async def test_tui_login_inputs_render(isolated_home: Path) -> None:
    from textual.widgets import Input

    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        # Both the email and password inputs should be present.
        inputs = {i.id for i in app.screen.query(Input)}
        assert "username-input" in inputs
        assert "password-input" in inputs


@pytest.mark.asyncio
async def test_tui_status_bar_shows_action_name(isolated_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """The status bar should show the current action name instead of the action id."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    from textual.widgets import Static
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        action_label = app.screen.query_one("#status-action", Static)
        assert str(action_label.content) == "Action: AutoCode Default"


@pytest.mark.asyncio
async def test_tui_at_symbol_opens_file_browser_only_at_start(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Typing @ mid-message should stay literal; only a leading @ opens file picker."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    from textual import events
    from kiwi_tui.main import AutobotsTUI
    from kiwi_tui.widgets import ChatInput

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        chat_input = app.screen.query_one("#chat-input", ChatInput)

        chat_input.value = "hello"
        await chat_input._on_key(events.Key("at_sign", "@"))
        await pilot.pause()

        assert type(app.screen).__name__ == "DashboardScreen"
        assert chat_input.value == "hello@"

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        chat_input = app.screen.query_one("#chat-input", ChatInput)

        await chat_input._on_key(events.Key("at_sign", "@"))
        await pilot.pause()

        assert type(app.screen).__name__ == "FileBrowserScreen"

@pytest.mark.asyncio
async def test_tui_drag_drop_paste_uploads_file_paths(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Pasting terminal drag/drop file paths should upload them as attachments."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    dropped_file = isolated_home / "drag file.txt"
    dropped_file.write_text("hello", encoding="utf-8")

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    uploaded_paths: list[list[str]] = []
    from kiwi_cli.client import AutobotsClientWrapper
    monkeypatch.setattr(
        AutobotsClientWrapper,
        "upload_files",
        lambda self, file_paths: (
            uploaded_paths.append(list(file_paths)) or True,
            ["https://example.com/uploaded/drag-file.txt"],
            "Uploaded 1 file(s)",
        ),
    )

    from textual import events
    from kiwi_tui.main import AutobotsTUI
    from kiwi_tui.widgets import ChatInput

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen
        chat_input = screen.query_one("#chat-input", ChatInput)

        pasted_path = str(dropped_file).replace(" ", "\\ ")
        await chat_input._on_paste(events.Paste(pasted_path))
        await pilot.pause()

        assert uploaded_paths == [[str(dropped_file.resolve())]]
        assert chat_input.value == ""
        assert screen._pending_urls == ["https://example.com/uploaded/drag-file.txt"]

@pytest.mark.asyncio
async def test_tui_screen_level_paste_uploads_file_paths(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If a paste/drop lands on the dashboard, it should still upload attached files."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    dropped_file = isolated_home / "screen-drop.txt"
    dropped_file.write_text("hello", encoding="utf-8")

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    uploaded_paths: list[list[str]] = []
    from kiwi_cli.client import AutobotsClientWrapper
    monkeypatch.setattr(
        AutobotsClientWrapper,
        "upload_files",
        lambda self, file_paths: (
            uploaded_paths.append(list(file_paths)) or True,
            ["https://example.com/uploaded/screen-drop.txt"],
            "Uploaded 1 file(s)",
        ),
    )

    from textual import events
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        screen.on_paste(events.Paste(str(dropped_file)))
        await pilot.pause()

        assert uploaded_paths == [[str(dropped_file.resolve())]]
        assert screen._pending_urls == ["https://example.com/uploaded/screen-drop.txt"]

@pytest.mark.asyncio
async def test_tui_upload_status_bar_renders_immediately(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Uploading should show immediately above the text box before the upload finishes."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    dropped_file = isolated_home / "slow-upload.txt"
    dropped_file.write_text("hello", encoding="utf-8")

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    from kiwi_cli.client import AutobotsClientWrapper
    def _slow_upload(self, file_paths):
        import time
        time.sleep(0.15)
        return True, ["https://example.com/uploaded/slow-upload.txt"], "Uploaded 1 file(s)"
    monkeypatch.setattr(AutobotsClientWrapper, "upload_files", _slow_upload)

    from textual.widgets import Static
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        screen._on_files_selected([str(dropped_file)])
        await pilot.pause()

        bar = screen.query_one("#pending-files-bar", Static)
        assert str(bar.content) == "Uploading: slow-upload.txt"
        assert screen._pending_urls == []


@pytest.mark.asyncio
async def test_tui_detach_button_clears_pending_files(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The detach button should clear pending attachments from the UI."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    from textual.widgets import Static, Button
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        screen._pending_urls = ["https://example.com/uploaded/a.png"]
        screen._update_pending_files_bar()
        await pilot.pause()

        bar = screen.query_one("#pending-files-bar", Static)
        detach = screen.query_one("#detach-files-btn", Button)
        assert str(bar.content) == "Attached: a.png"
        assert detach.has_class("visible")
        assert detach.disabled is False

        await pilot.click("#detach-files-btn")
        await pilot.pause()

        assert screen._pending_urls == []
        assert str(bar.content) == ""
        assert detach.has_class("visible") is False



@pytest.mark.asyncio
async def test_tui_detach_button_allows_single_file_removal_when_multiple_pending(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """With multiple attachments, detach should let the user remove just one file."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="AutoCode Default"),
        ),
    )

    from textual.widgets import Static
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        url_a = "https://example.com/uploaded/a.png"
        url_b = "https://example.com/uploaded/b.png"
        screen._pending_urls = [url_a, url_b]
        screen._update_pending_files_bar()
        await pilot.pause()

        await pilot.click("#detach-files-btn")
        await pilot.pause()

        assert type(app.screen).__name__ == "IdPickerScreen"
        screen._on_pending_file_detach_selected(url_a)
        await pilot.pause()

        bar = screen.query_one("#pending-files-bar", Static)
        assert screen._pending_urls == [url_b]
        assert str(bar.content) == "Attached: b.png"



@pytest.mark.asyncio
async def test_tui_action_switch_clears_chat(isolated_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Switching actions should reset the visible chat (new conversation UX)."""
    # Create tokens so the app boots straight into the Dashboard screen.
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    # Avoid any real HTTP calls during action selection.
    import kiwi_cli.commands as commands
    monkeypatch.setattr(commands, "actions_get", lambda _client, id: [f"OK: {id}"])

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name=f"Action {id}"),
        ),
    )

    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen
        screen.add_message("hello", "user")
        messages = screen.query_one("#messages")
        assert len(list(messages.children)) == 1

        await screen._on_action_picked_async("new-action-id")
        await pilot.pause()

        # The old chat should be cleared; next user message starts a new run.
        assert len(list(messages.children)) == 0


@pytest.mark.asyncio
async def test_tui_continue_run_updates_action_name_from_run(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Continuing a run should update the status bar to that run's action name."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    import kiwi_cli.commands as commands
    monkeypatch.setattr(commands, "runs_get", lambda _client, id: [f"OK: {id}"])

    from kiwi_tui.screens.dashboard import DashboardScreen
    monkeypatch.setattr(
        DashboardScreen,
        "_get_api_client_for_command",
        lambda self, _command: object(),
    )
    monkeypatch.setattr(
        DashboardScreen,
        "_render_conversation_history_from_action_result",
        lambda self, result: None,
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="Default Action"),
        ),
    )

    from kiwi_cli.client import AutobotsClientWrapper
    monkeypatch.setattr(
        AutobotsClientWrapper,
        "get_action_result",
        lambda self, run_id: (
            True,
            {
                "result": {
                    "_id": "special-action-id",
                    "name": "Run-owned Action",
                    "results": [],
                }
            },
            "",
        ),
    )

    from textual.widgets import Static
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        await screen._handle_slash_command_async("/continue run-123")
        await pilot.pause()

        action_label = screen.query_one("#status-action", Static)
        assert screen.current_action_id == "special-action-id"
        assert screen.current_action_name == "Run-owned Action"
        assert str(action_label.content) == "Action: Run-owned Action"


@pytest.mark.asyncio
async def test_tui_autocode_select_shows_only_special_action_names(
    isolated_home: Path, monkeypatch: pytest.MonkeyPatch
 ) -> None:
    """/autocode-select should open the picker with only the 3 special actions."""
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    names_by_id = {
        "69c2180355a89324a9926bc6": "AutoCode Alpha",
        "6a0625b8ab5f80ba8ac5d012": "AutoCode Beta",
        "69e4be0d70c2d7a89197e66e": "AutoCode Gamma",
    }

    from kiwi_tui.screens.dashboard import DashboardScreen
    monkeypatch.setattr(
        DashboardScreen,
        "_get_api_client_for_command",
        lambda self, _command: object(),
    )

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name=names_by_id[id]),
        ),
    )

    from textual.widgets import DataTable
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen

        await screen._handle_slash_command_async("/autocode-select")
        await pilot.pause()

        assert type(app.screen).__name__ == "IdPickerScreen"
        table = app.screen.query_one("#idpicker-table", DataTable)
        assert table.row_count == 3
        assert list(table.get_row_at(0)) == ["1", "AutoCode Alpha"]
        assert list(table.get_row_at(1)) == ["2", "AutoCode Beta"]
        assert list(table.get_row_at(2)) == ["3", "AutoCode Gamma"]



@pytest.mark.asyncio
async def test_tui_allows_empty_prompt(isolated_home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Sending an empty prompt should still trigger a run."""
    # Create tokens so the app boots straight into the Dashboard screen.
    tokens_path = isolated_home / ".kiwi" / "tokens.json"
    tokens_path.parent.mkdir(parents=True, exist_ok=True)
    tokens_path.write_text(
        json.dumps(
            {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_at": None,
            }
        ),
        encoding="utf-8",
    )

    from kiwi_tui.screens.dashboard import DashboardScreen
    called: list[str] = []
    monkeypatch.setattr(DashboardScreen, "process_message", lambda self, msg: called.append(msg))

    from autobots_client.api.actions import get_action_v1_actions_id_get
    monkeypatch.setattr(
        get_action_v1_actions_id_get,
        "sync_detailed",
        lambda *, id, client: SimpleNamespace(
            status_code=200,
            parsed=SimpleNamespace(field_id=id, name="Default Action"),
        ),
    )

    from kiwi_tui.main import AutobotsTUI
    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        assert type(app.screen).__name__ == "DashboardScreen"
        screen = app.screen
        chat_input = screen.query_one("#chat-input")
        chat_input.value = ""
        screen._do_send()
        await pilot.pause()

    assert called == [""]

@pytest.mark.asyncio
async def test_tui_quits_cleanly(isolated_home: Path) -> None:
    from kiwi_tui.main import AutobotsTUI

    app = AutobotsTUI()
    async with app.run_test() as pilot:
        await pilot.pause()
        await pilot.press("ctrl+c")
        await pilot.pause()
    # Reaching here without an exception is the assertion.
