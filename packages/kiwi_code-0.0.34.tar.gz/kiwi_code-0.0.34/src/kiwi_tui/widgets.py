"""Reusable widgets for Autobots TUI."""

import shlex
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

from textual.app import ComposeResult
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, Label, DataTable
from textual.reactive import reactive
from textual.message import Message
from textual import events
from textual.widgets._text_area import TextArea
from rich.text import Text


# Slash commands for autocomplete (single source of truth)
from kiwi_tui.slash_commands import autocomplete_commands

_SLASH_COMMANDS = autocomplete_commands()


class ChatInput(TextArea):
    """Chat composer with history navigation, slash suggestions, and @ file picker.

    - Soft wraps long lines.
    - Auto-grows up to a max number of visible lines, then becomes scrollable.
    - Enter submits.
    - macOS: Ctrl+N inserts a newline.
    - Windows: Shift+Enter inserts a newline (only when the terminal reports it distinctly).
    """

    _MAX_HISTORY = 200
    _MIN_VISIBLE_LINES = 1
    _MAX_VISIBLE_LINES = 6
    # Our Dashboard CSS draws a top and bottom border on #chat-input (1 cell each).
    _BORDER_LINES = 2

    class Submitted(Message):
        """Posted when the user submits the chat input (Enter)."""

        def __init__(self, value: str) -> None:
            super().__init__()
            self.value = value

    class AtTriggered(Message):
        """Posted when user types @ to open inline file picker."""

        pass

    class AtFilterChanged(Message):
        """Posted when the filter text after @ changes."""

        def __init__(self, filter_text: str) -> None:
            super().__init__()
            self.filter_text = filter_text

    class AtPickerNavigate(Message):
        """Posted when user presses up/down while picker is open."""

        def __init__(self, delta: int) -> None:
            super().__init__()
            self.delta = delta

    class FilePathsPasted(Message):
        """Posted when a paste event contains one or more local file paths."""

        def __init__(self, file_paths: list[str]) -> None:
            super().__init__()
            self.file_paths = file_paths

    class AtPickerSelect(Message):
        """Posted when user presses Enter while picker is open."""

        pass

    class AtPickerCancel(Message):
        """Posted when user presses Escape while picker is open."""

        pass

    def __init__(self, *args, **kwargs):
        # TextArea supports wrapping and scrolling.
        kwargs.setdefault("soft_wrap", True)
        kwargs.setdefault("show_line_numbers", False)
        # Compact removes TextArea's default border; we style it in Dashboard CSS.
        kwargs.setdefault("compact", True)
        # Keep Tab as focus navigation (unless picker is active, where we intercept it).
        kwargs.setdefault("tab_behavior", "focus")
        super().__init__(*args, **kwargs)

        self._history: list[str] = []
        self._history_index: int = -1
        self._draft: str = ""  # saves current text when browsing history
        self.picker_active: bool = False  # True when inline file picker is showing

        # Ensure a sensible initial height. This will be refined after the first layout.
        self._adjust_height()

    # Compatibility with the previous single-line Input-based implementation.
    @property
    def value(self) -> str:  # noqa: D401 - keep API parity with Input
        """Alias for TextArea.text (kept for backward compatibility)."""
        return self.text

    @value.setter
    def value(self, value: str) -> None:
        self.text = value
        self._move_cursor_to_end()

    def _normalize_pasted_file_token(self, token: str) -> str | None:
        """Normalize one pasted token into a local filesystem path."""
        candidate = token.strip()
        if not candidate:
            return None

        if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in {'"', "'"}:
            candidate = candidate[1:-1]

        if candidate.startswith("file://"):
            parsed = urlparse(candidate)
            if parsed.scheme != "file":
                return None
            candidate = unquote(parsed.path or "")
            if sys.platform == "win32" and candidate.startswith("/"):
                candidate = candidate.lstrip("/")

        return candidate or None

    def _extract_pasted_file_paths(self, pasted_text: str) -> list[str] | None:
        """Best-effort detect terminal drag/drop paste payloads containing local files."""
        raw = pasted_text.strip()
        if not raw:
            return None

        normalized = raw.replace("\r\n", "\n").replace("\r", "\n")
        token_sets: list[list[str]] = []

        try:
            split_tokens = shlex.split(normalized, posix=True)
        except ValueError:
            split_tokens = []
        if split_tokens:
            token_sets.append(split_tokens)

        line_tokens = [line.strip() for line in normalized.split("\n") if line.strip()]
        if line_tokens and line_tokens not in token_sets:
            token_sets.append(line_tokens)

        single_token = [normalized]
        if single_token not in token_sets:
            token_sets.append(single_token)

        for tokens in token_sets:
            resolved_paths: list[str] = []
            for token in tokens:
                normalized_token = self._normalize_pasted_file_token(token)
                if not normalized_token:
                    resolved_paths = []
                    break
                path = Path(normalized_token).expanduser()
                if not path.exists() or not path.is_file():
                    resolved_paths = []
                    break
                resolved_paths.append(str(path.resolve()))
            if resolved_paths:
                # Preserve order while removing duplicates.
                return list(dict.fromkeys(resolved_paths))

        return None

    def _move_cursor_to_end(self) -> None:
        try:
            self.move_cursor(self.document.end)
        except Exception:
            # Defensive: during early mount / teardown.
            pass

    def record(self, value: str) -> None:
        """Add a submitted value to history."""
        value = value.strip()
        if not value:
            return
        # Deduplicate consecutive
        if self._history and self._history[-1] == value:
            return
        self._history.append(value)
        if len(self._history) > self._MAX_HISTORY:
            self._history.pop(0)
        self._history_index = -1
        self._draft = ""

    def _has_at_picker_prefix(self, value: str | None = None) -> bool:
        """Return True when the composer is currently in the @-picker form."""
        val = self.value if value is None else value
        return val.startswith("@")

    def _get_at_filter(self) -> str | None:
        """Extract filter text after a leading '@' when the picker is active."""
        if not self.picker_active:
            return None
        val = self.value
        if not self._has_at_picker_prefix(val):
            return None
        return val[1:]

    def _adjust_height(self) -> None:
        """Auto-grow height based on wrapped line count, clamped to a max."""
        # `wrapped_document.height` is the number of wrapped (visual) lines.
        content_lines = max(1, int(getattr(self.wrapped_document, "height", 1) or 1))
        visible_lines = min(max(content_lines, self._MIN_VISIBLE_LINES), self._MAX_VISIBLE_LINES)
        self.styles.height = visible_lines + self._BORDER_LINES

    def _on_resize(self) -> None:
        super()._on_resize()
        self._adjust_height()

    def on_text_area_changed(self, event: TextArea.Changed) -> None:
        # Keep height in sync with content changes.
        self._adjust_height()

    def update_suggestion(self) -> None:
        """Slash-command suggestion (best-effort replacement for SuggestFromList)."""
        # Only suggest for single-line inputs.
        current = self.text
        if "\n" in current:
            self.suggestion = ""
            return
        if not current.lstrip().startswith("/"):
            self.suggestion = ""
            return

        matches = [cmd for cmd in _SLASH_COMMANDS if cmd.startswith(current)]
        if not matches:
            self.suggestion = ""
            return
        self.suggestion = matches[0][len(current) :]

    def action_cursor_up(self, select: bool = False) -> None:
        # While picker is open, use arrow keys to navigate it.
        if self.picker_active:
            self.post_message(self.AtPickerNavigate(-1))
            return

        # History: only when cursor is already at the top (otherwise allow cursor movement).
        if (
            self._history
            and self.cursor_at_first_line
            and (self.cursor_at_start_of_line or self.cursor_at_start_of_text)
        ):
            if self._history_index == -1:
                self._draft = self.value
                self._history_index = len(self._history) - 1
            elif self._history_index > 0:
                self._history_index -= 1
            self.value = self._history[self._history_index]
            self._move_cursor_to_end()
            return

        super().action_cursor_up(select)

    def action_cursor_down(self, select: bool = False) -> None:
        if self.picker_active:
            self.post_message(self.AtPickerNavigate(1))
            return

        if self._history_index == -1:
            super().action_cursor_down(select)
            return

        # History next / restore draft.
        if self._history_index < len(self._history) - 1:
            self._history_index += 1
            self.value = self._history[self._history_index]
        else:
            self._history_index = -1
            self.value = self._draft
        self._move_cursor_to_end()

    async def _on_key(self, event: events.Key) -> None:
        if self.disabled or self.read_only:
            return

        if self.picker_active:
            # While picker is open, intercept selection keys (arrows handled via action_cursor_*).
            if event.key in {"enter", "return"}:
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerSelect())
                return
            if event.key == "escape":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerCancel())
                return
            if event.key == "tab":
                event.prevent_default()
                event.stop()
                self.post_message(self.AtPickerSelect())
                return
            await super()._on_key(event)
            return

        # @ triggers the file picker only when it is the first character.
        if event.key == "at_sign" or event.character == "@":
            await super()._on_key(event)
            if self._has_at_picker_prefix():
                self.post_message(self.AtTriggered())
            return

        # Best-effort: insert a newline for modified-Enter combos that some terminals report distinctly.
        # Note: Many terminals may *not* distinguish these, in which case they will behave like plain Enter.
        #
        # macOS-specific note: Command is usually not forwarded to terminal apps, and some terminals may
        # report Ctrl+Enter as Ctrl+M (carriage return). We support a few fallbacks that work across OSes.
        newline_keys = {
            # Modified-Enter combos (only work if the terminal forwards them distinctly).
            "shift+enter", "shift+return",
            "alt+enter", "alt+return",
            "ctrl+enter", "ctrl+return",
            # macOS-style modifier names (only works if your terminal forwards them).
            "meta+enter", "meta+return",
            "cmd+enter", "cmd+return",
            "command+enter", "command+return",
            "option+enter", "option+return",
        }
        if sys.platform == "darwin":
            # On macOS, many terminals don't forward modified Enter combos distinctly; use Ctrl+N.
            newline_keys.add("ctrl+n")
        if event.key in newline_keys:
            event.prevent_default()
            event.stop()
            self.insert("\n")
            return

        # Enter submits.
        if event.key in {"enter", "return"}:
            event.prevent_default()
            event.stop()
            self.post_message(self.Submitted(self.value))
            return

        # UX: allow exiting a partially-typed slash command without triggering it.
        if event.key == "escape" and self.value.lstrip().startswith("/"):
            event.prevent_default()
            event.stop()
            self.value = ""
            self._history_index = -1
            self._draft = ""
            return

        await super()._on_key(event)

    async def _on_paste(self, event: events.Paste) -> None:
        """Handle drag/drop-style file pastes without inserting raw file paths."""
        if self.disabled or self.read_only:
            return

        file_paths = self._extract_pasted_file_paths(event.text)
        if file_paths:
            event.prevent_default()
            event.stop()
            self.post_message(self.FilePathsPasted(file_paths))
            self.focus()
            return

        await super()._on_paste(event)

class StatusBadge(Static):
    """A colored status badge widget."""

    DEFAULT_CSS = """
    StatusBadge {
        width: auto;
        height: 1;
        padding: 0 1;
        margin: 0 1;
    }

    StatusBadge.success {
        background: $success;
        color: $text;
    }

    StatusBadge.error {
        background: $error;
        color: $text;
    }

    StatusBadge.warning {
        background: $warning;
        color: $text;
    }

    StatusBadge.info {
        background: $accent;
        color: $text;
    }
    """

    def __init__(self, label: str, variant: str = "info", **kwargs):
        """Initialize status badge.

        Args:
            label: Text to display
            variant: Color variant (success, error, warning, info)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class StatCard(Container):
    """A card displaying a statistic."""

    DEFAULT_CSS = """
    StatCard {
        width: 1fr;
        height: auto;
        border: none;
        padding: 0;
        margin: 0 2;
    }

    StatCard > .stat-value {
        text-align: left;
        text-style: bold;
        color: $primary;
    }

    StatCard > .stat-label {
        text-align: left;
        color: $text-muted;
    }
    """

    value: reactive[str] = reactive("", init=False)
    label: reactive[str] = reactive("", init=False)

    def __init__(self, label: str, value: str = "0", **kwargs):
        """Initialize stat card.

        Args:
            label: Description of the stat
            value: Current value
        """
        super().__init__(**kwargs)
        self._initial_label = label
        self._initial_value = value

    def compose(self) -> ComposeResult:
        """Compose stat card widgets."""
        yield Static(self._initial_value, classes="stat-value")
        yield Static(self._initial_label, classes="stat-label")

    def on_mount(self) -> None:
        """Called when widget is mounted."""
        self.label = self._initial_label
        self.value = self._initial_value

    def watch_value(self, value: str) -> None:
        """Update displayed value."""
        if self.is_mounted:
            self.query_one(".stat-value", Static).update(value)

    def watch_label(self, label: str) -> None:
        """Update displayed label."""
        if self.is_mounted:
            self.query_one(".stat-label", Static).update(label)


class ActionButton(Button):
    """A styled action button."""

    DEFAULT_CSS = """
    ActionButton {
        min-width: 16;
        margin: 0 1;
        border: none;
        background: $surface;
        color: $text;
    }

    ActionButton:focus {
        background: $primary;
        color: black;
    }

    ActionButton.primary {
        color: $primary;
    }

    ActionButton.success {
        color: $success;
    }

    ActionButton.danger {
        color: $error;
    }
    """

    def __init__(self, label: str, variant: str = "primary", **kwargs):
        """Initialize action button.

        Args:
            label: Button text
            variant: Style variant (primary, success, danger)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class InfoPanel(Container):
    """An information panel with title and content."""

    DEFAULT_CSS = """
    InfoPanel {
        height: auto;
        border: none;
        padding: 0;
        margin: 1 0;
    }

    InfoPanel > .panel-title {
        text-style: bold;
        color: $primary;
        margin-bottom: 0;
    }

    InfoPanel > .panel-content {
        color: $text;
    }
    """

    def __init__(self, title: str, content: str = "", **kwargs):
        """Initialize info panel.

        Args:
            title: Panel title
            content: Panel content
        """
        super().__init__(**kwargs)
        self._title = title
        self._content = content

    def compose(self) -> ComposeResult:
        """Compose info panel widgets."""
        yield Static(self._title, classes="panel-title")
        yield Static(self._content, classes="panel-content")

    def update_content(self, content: str) -> None:
        """Update panel content.

        Args:
            content: New content to display
        """
        self.query_one(".panel-content", Static).update(content)
