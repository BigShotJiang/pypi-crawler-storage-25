from kiwi_tui.status_words import next_status_word
def random_verb(*, default: str = "Thinking") -> str:
    """Return a curated "-ing" status word for display (e.g. "Searching")."""

    return next_status_word(default=default)


def random_adjective(*, default: str = "Curious") -> str:  # pragma: no cover
    return default
