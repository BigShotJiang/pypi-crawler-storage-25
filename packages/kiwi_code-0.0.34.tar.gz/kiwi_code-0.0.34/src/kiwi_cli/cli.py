"""Typer CLI for Autobots — thin wrapper over commands.py."""

from typing import Optional, Callable

from loguru import logger
logger.remove()  # Suppress loguru console output in CLI mode

import typer
from autobots_client import AuthenticatedClient

from .auth import TokenManager
from .models import AppConfig
from .server import http_url_from_server
from . import commands

app = typer.Typer(name="kiwi", help="Kiwi — interact with the Kiwi AI platform.")

actions_app = typer.Typer(name="actions", help="Manage actions.")
action_runs_app = typer.Typer(name="runs", help="Manage action runs (results).")
graphs_app = typer.Typer(name="graphs", help="Manage action graphs.")
graph_runs_app = typer.Typer(name="graph-runs", help="Manage action graph runs (results).")

app.add_typer(actions_app)
app.add_typer(action_runs_app)
app.add_typer(graphs_app)
app.add_typer(graph_runs_app)

# NOTE: kiwi-runtime is a standalone executable; this CLI does not manage it.

_SERVER: str | None = None

@app.callback()
def _main(
    server: Optional[str] = typer.Option(
        None,
        "--server",
        help=(
            "Server to connect to. Use a preset name (app, dev, local) "
            "or a full URL (e.g. https://custom.server.com)."
        ),
    ),
):
    """Global options for `kiwicli`."""
    global _SERVER
    _SERVER = server


def _backend_url() -> str:
    """Resolve the HTTP backend URL for this invocation (runtime-only)."""
    if _SERVER:
        try:
            return http_url_from_server(_SERVER)
        except Exception:
            pass
    return AppConfig().backend_url


def _http_status_from_lines(lines: list[str]) -> int | None:
    """Extract an HTTP status code from commands.py output lines.

    commands.py returns errors in the form: ["Error: HTTP <code>"]
    """
    if not lines:
        return None
    if len(lines) != 1:
        return None
    s = lines[0].strip()
    prefix = "Error: HTTP "
    if not s.startswith(prefix):
        return None
    try:
        return int(s[len(prefix):].strip())
    except Exception:
        return None


def _force_refresh_tokens(tm: TokenManager) -> bool:
    """Force refresh tokens once and persist them."""
    from .client import AutobotsClientWrapper

    with tm.file_lock():
        tokens = tm.load_tokens()
        if not tokens:
            return False
        refresh = getattr(tokens, "refresh_token", None)
        if not refresh:
            return False

        wrapper = AutobotsClientWrapper(
            base_url=_backend_url(),
            access_token=getattr(tokens, "access_token", None),
        )
        ok, new_tokens, _msg = wrapper.refresh_token(str(refresh))
        if ok and new_tokens:
            tm.save_tokens(new_tokens)
            return True
        return False


def _get_client() -> AuthenticatedClient:
    """Get an authenticated OpenAPI client.

    If the access token is expired but a refresh token exists, attempt a refresh
    once. This improves CLI reliability for long-lived sessions.
    """
    tm = TokenManager()
    tokens = tm.load_tokens()
    if not tokens:
        typer.echo("Not authenticated. Run `kiwi login` first.", err=True)
        raise typer.Exit(code=1)

    try:
        if tokens.is_expired() and getattr(tokens, "refresh_token", None):
            _force_refresh_tokens(tm)
            tokens = tm.load_tokens() or tokens
    except Exception:
        pass

    access = getattr(tokens, "access_token", None)
    if not access:
        typer.echo("Not authenticated. Run `kiwi login` first.", err=True)
        raise typer.Exit(code=1)

    return AuthenticatedClient(
        base_url=_backend_url(),
        token=str(access),
        raise_on_unexpected_status=False,
    )


def _run_with_refresh_retry(run: Callable[[AuthenticatedClient], list[str]]) -> list[str]:
    """Run a CLI command with one forced refresh retry on 401/403."""
    tm = TokenManager()
    lines = run(_get_client())
    code = _http_status_from_lines(lines)
    if code in (401, 403):
        try:
            if _force_refresh_tokens(tm):
                lines = run(_get_client())
        except Exception:
            pass
    return lines

def _print(lines: list[str]) -> None:
    for line in lines:
        typer.echo(line)


# -- actions ----------------------------------------------------------------

@actions_app.command("list")
def actions_list_cmd(
    name: Optional[str] = typer.Option(None, help="Filter by name"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List actions."""
    _print(_run_with_refresh_retry(lambda c: commands.actions_list(c, name=name, limit=limit, offset=offset)))

@actions_app.command("get")
def actions_get_cmd(id: str = typer.Argument(help="Action ID")):
    """Get action details."""
    _print(_run_with_refresh_retry(lambda c: commands.actions_get(c, id=id)))


# -- runs -------------------------------------------------------------------

@action_runs_app.command("list")
def runs_list_cmd(
    action_id: Optional[str] = typer.Option(None, help="Filter by action ID"),
    action_name: Optional[str] = typer.Option(None, help="Filter by action name"),
    status: Optional[str] = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action runs (results)."""
    _print(_run_with_refresh_retry(lambda c: commands.runs_list(c, action_id=action_id, action_name=action_name, status=status, limit=limit, offset=offset)))

@action_runs_app.command("get")
def runs_get_cmd(id: str = typer.Argument(help="Action run ID")):
    """Get action run details."""
    _print(_run_with_refresh_retry(lambda c: commands.runs_get(c, id=id)))


# -- graphs -----------------------------------------------------------------

@graphs_app.command("list")
def graphs_list_cmd(
    name: Optional[str] = typer.Option(None, help="Filter by name"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action graphs."""
    _print(_run_with_refresh_retry(lambda c: commands.graphs_list(c, name=name, limit=limit, offset=offset)))

@graphs_app.command("get")
def graphs_get_cmd(id: str = typer.Argument(help="Action graph ID")):
    """Get action graph details."""
    _print(_run_with_refresh_retry(lambda c: commands.graphs_get(c, id=id)))


# -- graph-runs -------------------------------------------------------------

@graph_runs_app.command("list")
def graph_runs_list_cmd(
    graph_id: Optional[str] = typer.Option(None, "--graph-id", help="Filter by graph ID"),
    graph_name: Optional[str] = typer.Option(None, "--graph-name", help="Filter by graph name"),
    status: Optional[str] = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action graph runs (results)."""
    _print(_run_with_refresh_retry(lambda c: commands.graph_runs_list(c, action_graph_id=graph_id, action_graph_name=graph_name, status=status, limit=limit, offset=offset)))

@graph_runs_app.command("get")
def graph_runs_get_cmd(id: str = typer.Argument(help="Graph run ID")):
    """Get action graph run details."""
    _print(_run_with_refresh_retry(lambda c: commands.graph_runs_get(c, id=id)))


# -- runtime ----------------------------------------------------------------
# (runtime management removed; use `kiwi-runtime` directly)


# -- top-level --------------------------------------------------------------

@app.command()
def login(
    username: str = typer.Option(..., prompt=True, help="Email"),
    password: str = typer.Option(..., prompt=True, hide_input=True, help="Password"),
):
    """Login and save authentication tokens."""
    from .client import AutobotsClientWrapper
    from .models import LoginCredentials

    token_manager = TokenManager()
    wrapper = AutobotsClientWrapper(base_url=_backend_url())
    success, tokens, message = wrapper.login(LoginCredentials(username=username, password=password))

    if success and tokens:
        token_manager.save_tokens(tokens)
        typer.echo("Logged in successfully.")
    else:
        typer.echo(f"Login failed: {message}", err=True)
        raise typer.Exit(code=1)

@app.command()
def logout():
    """Logout and clear saved authentication tokens."""
    tm = TokenManager()
    tm.clear_tokens()
    typer.echo("Logged out successfully.")

@app.command()
def whoami():
    """Show current authentication status."""
    tm = TokenManager()
    if tm.is_authenticated():
        typer.echo(f"Authenticated\nServer: {_backend_url()}")
    else:
        typer.echo("Not authenticated. Run `kiwi login` to sign in.")

@app.command()
def tui():
    """Launch the interactive TUI."""
    from kiwi_tui.main import main
    main()


def cli():
    """Entry point for the CLI."""
    import setproctitle
    setproctitle.setproctitle("kiwicli")
    app()

if __name__ == "__main__":
    cli()
