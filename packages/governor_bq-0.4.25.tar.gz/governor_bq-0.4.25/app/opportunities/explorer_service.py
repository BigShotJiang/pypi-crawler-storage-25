"""Cross-project opportunity explorer service.

Provides query methods for browsing, filtering, sorting, and grouping
opportunities across all projects.
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from sqlalchemy import Select, and_, false, func, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.configurations.models import ManifestConfiguration
from app.core.config import is_local_mode
from app.opportunities.catalog import (
    build_effective_rule_selection,
    get_detection_rule_catalog,
)
from app.opportunities.models import Opportunity, OpportunitySavingsEstimate
from app.opportunities.presentation import (
    build_inherited_pending_savings_display,
    build_cost_display,
    build_possible_savings_display,
    get_exact_local_workload_kinds,
    get_active_solution_job_statuses,
    get_last_job_details,
    get_latest_solution_snapshots,
    to_decimal,
)
from app.solutions.models import Solution
from app.utils.pagination import PaginationContext

_TABLE_SORT_COLUMN = func.lower(
    func.coalesce(Opportunity.dbt_model_name, Opportunity.affected_table)
)
_ALWAYS_HIDDEN_EXPLORER_TYPES = (
    "storage_billing_optimization",
    "clustering",
    "clustering_not_leveraged",
)


def _normalize_workload_kind(workload_kind: str | None) -> str:
    if workload_kind in ("build", "consumption"):
        return workload_kind
    # All Governor opportunities target manifest-managed dbt models.
    # When job metadata is missing, default to "build" rather than
    # showing a misleading "other/query" label.
    return "build"


def _apply_status_filter(
    base: Select, status: str, *, collapse_pending_states: bool = False
) -> Select:
    """Apply an opportunity status filter, optionally collapsing pending states."""
    if status == "active":
        return base.where(Opportunity.status == "active")
    if status == "resolved":
        return base.where(Opportunity.status == "resolved")
    if status in {"pr_pending", "clearing"}:
        if collapse_pending_states:
            return base.where(Opportunity.status.in_(("pr_pending", "clearing")))
        return base.where(Opportunity.status == status)
    return base


# Column name → SQLAlchemy column mapping for sort
_SORT_COLUMNS = {
    "severity": Opportunity.severity_score,
    "cost": Opportunity.current_cost_estimate,
    "savings": Opportunity.expected_savings,
    "age": Opportunity.last_detected_at,
    "occurrence": Opportunity.occurrence_count,
    "project": ManifestConfiguration.name,
    "type": Opportunity.opportunity_type,
    "table": _TABLE_SORT_COLUMN,
    "status": Opportunity.status,
}


def _apply_sort(base, sort_column: str, sort_direction: str) -> Select:
    """Apply a deterministic sort order to opportunity queries."""
    col = _SORT_COLUMNS.get(sort_column, Opportunity.severity_score)
    if sort_column == "table":
        secondary = [
            Opportunity.affected_table.asc(),
            Opportunity.opportunity_type.asc(),
        ]
        if sort_direction == "asc":
            return base.order_by(col.asc(), *secondary)
        return base.order_by(
            col.desc(),
            Opportunity.affected_table.desc(),
            Opportunity.opportunity_type.desc(),
        )
    if sort_direction == "asc":
        return base.order_by(col.asc())
    return base.order_by(col.desc())


def _get_rule_visibility(
    watched_rule_types: list[str] | None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    catalog = get_detection_rule_catalog()
    known_rule_types = tuple(
        dict.fromkeys(
            [
                *(entry.rule_type.lower() for entry in catalog),
                *_ALWAYS_HIDDEN_EXPLORER_TYPES,
            ]
        )
    )
    selection = build_effective_rule_selection(watched_rule_types, catalog)
    visible_rule_types = tuple(
        rule_type.lower()
        for rule_type in selection.effective_rule_types
        if rule_type not in _ALWAYS_HIDDEN_EXPLORER_TYPES
    )
    return known_rule_types, visible_rule_types


def _load_workload_estimates(
    db: Session, opportunity_ids: list[str]
) -> dict[str, OpportunitySavingsEstimate]:
    if not opportunity_ids:
        return {}

    try:
        rows = (
            db.execute(
                select(OpportunitySavingsEstimate).where(
                    OpportunitySavingsEstimate.opportunity_id.in_(opportunity_ids)
                )
            )
            .scalars()
            .all()
        )
    except SQLAlchemyError:
        return {}

    return {estimate.opportunity_id: estimate for estimate in rows}


class OpportunityExplorerService:
    """Cross-project opportunity query service."""

    def __init__(self, db: Session) -> None:
        self.db = db

    def _get_active_config_visible_types(
        self, project_ids: list[str] | None = None
    ) -> dict[str, tuple[tuple[str, ...], tuple[str, ...]]]:
        query = select(
            ManifestConfiguration.id,
            ManifestConfiguration.watched_rule_types,
        ).where(ManifestConfiguration.status == "active")
        if project_ids:
            query = query.where(ManifestConfiguration.id.in_(project_ids))
        rows = self.db.execute(query).all()
        return {
            config_id: _get_rule_visibility(watched_rule_types)
            for config_id, watched_rule_types in rows
        }

    def _build_visible_opportunity_clause(self, project_ids: list[str] | None = None):
        visible_types_by_config = self._get_active_config_visible_types(project_ids)
        conditions = [
            and_(
                Opportunity.config_id == config_id,
                or_(
                    (
                        func.lower(Opportunity.opportunity_type).in_(visible_types)
                        if visible_types
                        else false()
                    ),
                    (
                        ~func.lower(Opportunity.opportunity_type).in_(known_rule_types)
                        if known_rule_types
                        else false()
                    ),
                ),
            )
            for config_id, (
                known_rule_types,
                visible_types,
            ) in visible_types_by_config.items()
        ]
        if not conditions:
            return false()
        return or_(*conditions)

    # ------------------------------------------------------------------
    # Filter option population (Q5)
    # ------------------------------------------------------------------

    def get_available_projects(self) -> list[tuple[str, str]]:
        """Return (id, name) tuples for all active ManifestConfigurations."""
        rows = self.db.execute(
            select(ManifestConfiguration.id, ManifestConfiguration.name)
            .where(ManifestConfiguration.status == "active")
            .order_by(ManifestConfiguration.name)
        ).all()
        return [(r[0], r[1]) for r in rows]

    def get_available_types(self) -> list[str]:
        """Return currently visible rule types from active configurations."""
        visible_types = {
            rule_type
            for _, types in self._get_active_config_visible_types().values()
            for rule_type in types
        }
        return sorted(visible_types)

    # ------------------------------------------------------------------
    # Flat list query (Q1) with pagination
    # ------------------------------------------------------------------

    def query_opportunities(
        self,
        *,
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        sort_column: str = "cost",
        sort_direction: str = "desc",
        page: int = 1,
        page_size: int = 10,
        max_items: int | None = None,
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> tuple[list[dict], PaginationContext]:
        """Query opportunities with filtering, sorting, and pagination.

        Returns (list of opportunity dicts for current page, PaginationContext).
        """
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(
                Opportunity,
                ManifestConfiguration.name.label("project_name"),
            )
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        # Apply smart view overrides first
        if smart_view == "quick-wins":
            # Active + has low-risk solution
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
            sort_column = "savings"
            sort_direction = "desc"
        elif smart_view == "chronic":
            # Active + occurrence_count > 20
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
            sort_column = "occurrence"
            sort_direction = "desc"
        elif smart_view == "unaddressed":
            # Active + no solution + severity >= 70
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
            sort_column = "severity"
            sort_direction = "desc"
        else:
            # Apply manual status filter
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        # Search filter (ILIKE with wildcard escaping)
        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        # Project filter
        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))

        # Type filter
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )

        # Date range filter
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Count total
        count_q = select(func.count()).select_from(base.subquery())
        total_items = self.db.execute(count_q).scalar() or 0

        if max_items is not None:
            total_items = min(total_items, max(0, max_items))
            page = 1

        pagination = PaginationContext(
            page=max(1, page), page_size=page_size, total_items=total_items
        )
        # Clamp page
        if pagination.page > pagination.total_pages:
            pagination = PaginationContext(
                page=pagination.total_pages,
                page_size=page_size,
                total_items=total_items,
            )

        # Sort
        base = _apply_sort(base, sort_column, sort_direction)

        # Paginate
        limit = page_size
        offset = (pagination.page - 1) * page_size
        if max_items is not None:
            offset = 0
            limit = min(page_size, max_items)
        rows = self.db.execute(base.offset(offset).limit(limit)).all()

        # Build result dicts
        opp_ids = []
        results = []
        row_opportunities = [row[0] for row in rows]
        # Batch lookup: latest job metadata per opportunity
        last_job_details_map = get_last_job_details(self.db, row_opportunities)
        exact_local_workload_map = (
            get_exact_local_workload_kinds(self.db, row_opportunities)
            if is_local_mode()
            else {}
        )
        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, [row[0].id for row in rows]
        )
        for row in rows:
            opp: Opportunity = row[0]
            project_name: str = row[1]
            opp_ids.append(opp.id)
            latest_job_details = last_job_details_map.get(opp.id, {})
            workload_kind = (
                exact_local_workload_map.get(opp.id)
                if is_local_mode()
                else _normalize_workload_kind(latest_job_details.get("workload_kind"))
            )
            results.append(
                {
                    "id": opp.id,
                    "config_id": opp.config_id,
                    "project_name": project_name,
                    "opportunity_type": opp.opportunity_type,
                    "affected_table": opp.affected_table,
                    "dbt_model_name": opp.dbt_model_name,
                    "severity_score": opp.severity_score,
                    "current_cost_estimate": opp.current_cost_estimate,
                    "expected_savings": opp.expected_savings,
                    "status": opp.status,
                    "cascade_status": opp.cascade_status,
                    "cascade_root_id": opp.cascade_root_id,
                    "occurrence_count": opp.occurrence_count,
                    "created_at": opp.created_at,
                    "last_detected_at": opp.last_detected_at,
                    "has_solution": False,
                    "solution_risk_level": None,
                    "avg_query_cost": latest_job_details.get("total_cost"),
                    "dry_run_original_cost": None,
                    "dry_run_modified_cost": None,
                    "query_cost_value": None,
                    "query_cost_source_label": None,
                    "query_workload_kind": workload_kind,
                    "query_workload_label": workload_kind.title()
                    if workload_kind
                    else "Query",
                    "optimized_cost_value": None,
                    "optimized_cost_source_label": None,
                    "optimized_delta_direction": None,
                    "solution_job_status": active_solution_job_status_map.get(opp.id),
                    "prefers_possible_savings_display": False,
                }
            )

        cascade_root_ids = [
            row[0].cascade_root_id
            for row in rows
            if row[0].cascade_status == "delegated" and row[0].cascade_root_id
        ]

        # Batch solution risk + dry run cost lookup
        if opp_ids:
            latest_solution_map = get_latest_solution_snapshots(
                self.db,
                list(dict.fromkeys([*opp_ids, *cascade_root_ids])),
                schedule_missing_dry_runs=True,
            )
            root_opportunities = (
                {
                    opp.id: opp
                    for opp in self.db.execute(
                        select(Opportunity).where(Opportunity.id.in_(cascade_root_ids))
                    )
                    .scalars()
                    .all()
                }
                if cascade_root_ids
                else {}
            )

            wl_estimates_map = _load_workload_estimates(self.db, opp_ids)

            for r in results:
                latest_solution = latest_solution_map.get(r["id"])
                if latest_solution:
                    r["has_solution"] = True
                    r["solution_risk_level"] = latest_solution.get("risk_level")
                    r["dry_run_original_cost"] = latest_solution.get(
                        "dry_run_original_cost"
                    )
                    r["dry_run_modified_cost"] = latest_solution.get(
                        "dry_run_modified_cost"
                    )
                    r["prefers_possible_savings_display"] = latest_solution.get(
                        "prefers_possible_savings_display",
                        False,
                    )
                r.update(
                    build_cost_display(
                        current_cost_estimate=r["current_cost_estimate"],
                        latest_job_cost=last_job_details_map.get(r["id"], {}).get(
                            "total_cost"
                        ),
                        dry_run_original_cost=r["dry_run_original_cost"],
                        dry_run_modified_cost=r["dry_run_modified_cost"],
                        use_dry_run_original_for_query_cost=latest_solution.get(
                            "supports_optimized_dry_run",
                            False,
                        )
                        if latest_solution
                        else False,
                        prefer_possible_savings_display=r[
                            "prefers_possible_savings_display"
                        ],
                    )
                )

                wl_est = wl_estimates_map.get(r["id"])
                r.update(
                    build_possible_savings_display(
                        opportunity_type=r["opportunity_type"],
                        expected_savings=r["expected_savings"],
                        occurrence_count=r["occurrence_count"],
                        optimized_cost_value=r["optimized_cost_value"],
                        optimized_delta_direction=r.get("optimized_delta_direction"),
                        workload_per_run_savings=wl_est.per_run_savings
                        if wl_est
                        else None,
                        workload_confidence=wl_est.confidence if wl_est else None,
                        workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
                        prefer_possible_savings_display=r[
                            "prefers_possible_savings_display"
                        ],
                        has_solution=r.get("has_solution", False),
                    )
                )
                if r.get("possible_savings_value") is None:
                    root_opp = (
                        root_opportunities.get(r["cascade_root_id"])
                        if r.get("cascade_root_id")
                        else None
                    )
                    root_solution = (
                        latest_solution_map.get(root_opp.id, {})
                        if root_opp is not None
                        else {}
                    )
                    r.update(
                        build_inherited_pending_savings_display(
                            root_possible_savings_value=build_possible_savings_display(
                                opportunity_type=root_opp.opportunity_type
                                if root_opp
                                else None,
                                expected_savings=root_opp.expected_savings
                                if root_opp
                                else None,
                                occurrence_count=root_opp.occurrence_count
                                if root_opp
                                else None,
                                optimized_cost_value=None,
                                optimized_delta_direction=None,
                                prefer_possible_savings_display=root_solution.get(
                                    "prefers_possible_savings_display",
                                    False,
                                ),
                                has_solution=bool(root_solution),
                            ).get("possible_savings_value"),
                            root_model_name=root_opp.dbt_model_name
                            if root_opp
                            else None,
                        )
                    )

        return results, pagination

    # ------------------------------------------------------------------
    # Summary cards aggregation (Q3)
    # ------------------------------------------------------------------

    def get_summary_cards(
        self,
        *,
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> dict:
        """Return aggregated summary metrics for filtered opportunities."""
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(Opportunity)
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        # Apply same filters as query_opportunities
        if smart_view == "quick-wins":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
        elif smart_view == "chronic":
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
        elif smart_view == "unaddressed":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
        else:
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Build subquery from filtered set
        sub = base.subquery()

        visible_opps = (
            self.db.execute(
                select(Opportunity).where(Opportunity.id.in_(select(sub.c.id)))
            )
            .scalars()
            .all()
        )
        active_opps = [opp for opp in visible_opps if opp.status == "active"]
        active_count = len(active_opps)
        visible_opportunity_ids = [o.id for o in visible_opps]

        latest_solution_map = get_latest_solution_snapshots(
            self.db, visible_opportunity_ids
        )
        process_cost_map = {
            o.id: o.process_cost_usd or Decimal("0") for o in visible_opps
        }
        total_savings = Decimal("0")
        for opportunity_id in visible_opportunity_ids:
            latest_solution = latest_solution_map.get(opportunity_id, {})
            if latest_solution.get("prefers_possible_savings_display", False):
                continue
            dry_run_original_cost = latest_solution.get("dry_run_original_cost")
            dry_run_modified_cost = latest_solution.get("dry_run_modified_cost")
            if dry_run_original_cost is not None and dry_run_modified_cost is not None:
                gross = dry_run_original_cost - dry_run_modified_cost
                process_cost = process_cost_map.get(opportunity_id, Decimal("0"))
                total_savings += max(Decimal("0"), gross - process_cost)

        # Total query cost: sum the same per-row query cost basis used by the
        # visible explorer table so the summary matches what the user sees.
        last_job_details_map = get_last_job_details(self.db, visible_opps)
        total_query_cost = Decimal("0")
        workload_query_costs = {
            "build": Decimal("0"),
            "consumption": Decimal("0"),
            "other": Decimal("0"),
        }
        for opp in visible_opps:
            latest_solution = latest_solution_map.get(opp.id, {})
            workload_kind = _normalize_workload_kind(
                last_job_details_map.get(opp.id, {}).get("workload_kind")
            )
            latest_job_cost = last_job_details_map.get(opp.id, {}).get("total_cost")
            cost_display = build_cost_display(
                current_cost_estimate=opp.current_cost_estimate,
                latest_job_cost=latest_job_cost,
                dry_run_original_cost=latest_solution.get("dry_run_original_cost"),
                dry_run_modified_cost=latest_solution.get("dry_run_modified_cost"),
                use_dry_run_original_for_query_cost=latest_solution.get(
                    "supports_optimized_dry_run",
                    False,
                )
                if latest_solution
                else False,
                prefer_possible_savings_display=latest_solution.get(
                    "prefers_possible_savings_display",
                    False,
                )
                if latest_solution
                else False,
            )
            query_cost_value = cost_display.get("query_cost_value")
            if query_cost_value is not None:
                total_query_cost += query_cost_value
                workload_query_costs[workload_kind] += query_cost_value

        # With solutions count (active, has at least one solution)
        with_solutions_count = (
            self.db.execute(
                select(func.count())
                .select_from(sub)
                .where(sub.c.status == "active")
                .where(sub.c.id.in_(select(Solution.opportunity_id).distinct()))
            ).scalar()
            or 0
        )

        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, visible_opportunity_ids
        )
        wl_estimates_map = _load_workload_estimates(self.db, visible_opportunity_ids)
        total_possible_savings = Decimal("0")
        workload_possible_savings = {
            "build": Decimal("0"),
            "consumption": Decimal("0"),
            "other": Decimal("0"),
        }
        for opp in visible_opps:
            latest_solution = latest_solution_map.get(opp.id, {})
            workload_kind = _normalize_workload_kind(
                last_job_details_map.get(opp.id, {}).get("workload_kind")
            )
            if active_solution_job_status_map.get(opp.id) in ("queued", "in_progress"):
                continue
            prefers_possible_savings_display = latest_solution.get(
                "prefers_possible_savings_display",
                False,
            )
            dry_run_modified_cost = latest_solution.get("dry_run_modified_cost")
            dry_run_original_cost = latest_solution.get("dry_run_original_cost")
            # Determine if the dry run shows actual improvement
            _delta_dir: str | None = None
            if dry_run_modified_cost is not None and dry_run_original_cost is not None:
                mod = to_decimal(dry_run_modified_cost)
                orig = to_decimal(dry_run_original_cost)
                if mod is not None and orig is not None and mod < orig:
                    _delta_dir = "down"
            wl_est = wl_estimates_map.get(opp.id)
            _has_solution = bool(latest_solution)
            possible_savings_display = build_possible_savings_display(
                opportunity_type=opp.opportunity_type,
                expected_savings=opp.expected_savings,
                occurrence_count=opp.occurrence_count,
                optimized_cost_value=dry_run_modified_cost,
                optimized_delta_direction=_delta_dir,
                workload_per_run_savings=wl_est.per_run_savings if wl_est else None,
                workload_confidence=wl_est.confidence if wl_est else None,
                workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
                prefer_possible_savings_display=prefers_possible_savings_display,
                has_solution=_has_solution,
            )
            possible_savings_value = possible_savings_display.get(
                "possible_savings_value"
            )
            if possible_savings_value is not None:
                total_possible_savings += possible_savings_value
                workload_possible_savings[workload_kind] += possible_savings_value

        # Verified post-merge savings (spec 068), net of process cost
        verified_rows = self.db.execute(
            select(
                Opportunity.verified_savings,
                Opportunity.process_cost_usd,
            )
            .where(Opportunity.verified_savings_status == "confirmed")
            .where(Opportunity.verified_savings > 0)
        ).all()
        verified_post_merge_savings = Decimal("0")
        verified_count = len(verified_rows)
        for row in verified_rows:
            gross = row.verified_savings or Decimal("0")
            cost = row.process_cost_usd or Decimal("0")
            verified_post_merge_savings += max(Decimal("0"), gross - cost)

        collecting_count = (
            self.db.execute(
                select(func.count()).where(
                    Opportunity.verified_savings_status == "collecting"
                )
            ).scalar()
            or 0
        )

        # Count clearing opportunities
        clearing_count = (
            self.db.execute(
                select(func.count()).select_from(sub).where(sub.c.status == "clearing")
            ).scalar()
            or 0
        )

        total_process_costs = sum(
            (o.process_cost_usd or Decimal("0")) for o in visible_opps
        )

        clearing_savings = sum(
            (o.expected_savings or Decimal("0"))
            for o in visible_opps
            if o.status == "clearing"
        )

        return {
            "active_count": active_count,
            "clearing_count": clearing_count,
            "with_solutions_count": with_solutions_count,
            "total_savings": total_savings,
            "total_possible_savings": total_possible_savings,
            "total_query_cost": total_query_cost,
            "build_query_cost": workload_query_costs["build"],
            "consumption_query_cost": workload_query_costs["consumption"],
            "other_query_cost": workload_query_costs["other"],
            "build_possible_savings": workload_possible_savings["build"],
            "consumption_possible_savings": workload_possible_savings["consumption"],
            "other_possible_savings": workload_possible_savings["other"],
            "verified_post_merge_savings": verified_post_merge_savings,
            "verified_count": verified_count,
            "collecting_count": collecting_count,
            "total_process_costs": total_process_costs,
            "clearing_savings": clearing_savings,
        }

    # ------------------------------------------------------------------
    # Grouped view (Q4)
    # ------------------------------------------------------------------

    def get_grouped_opportunities(
        self,
        *,
        group_by: str = "project",
        search: str = "",
        status: str = "active",
        project_ids: list[str] | None = None,
        type_names: list[str] | None = None,
        sort_column: str = "cost",
        sort_direction: str = "desc",
        smart_view: str = "",
        date_start: datetime | None = None,
        date_end: datetime | None = None,
        collapse_pending_states: bool = False,
    ) -> list[dict]:
        """Return grouped opportunities with headers and subtotals.

        Each group dict has: group_id, group_name, opportunity_count,
        total_savings, and opportunities (list of dicts).
        """
        # Get all matching opportunities (no pagination in grouped mode)
        visible_clause = self._build_visible_opportunity_clause(project_ids)
        base = (
            select(
                Opportunity,
                ManifestConfiguration.name.label("project_name"),
            )
            .join(
                ManifestConfiguration,
                Opportunity.config_id == ManifestConfiguration.id,
            )
            .where(ManifestConfiguration.status == "active")
            .where(visible_clause)
        )

        # Apply same filters
        if smart_view == "quick-wins":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                Opportunity.id.in_(
                    select(Solution.opportunity_id)
                    .where(Solution.risk_level == "low")
                    .distinct()
                )
            )
        elif smart_view == "chronic":
            base = base.where(Opportunity.status == "active")
            base = base.where(Opportunity.occurrence_count > 20)
        elif smart_view == "unaddressed":
            base = base.where(Opportunity.status == "active")
            base = base.where(
                ~Opportunity.id.in_(select(Solution.opportunity_id).distinct())
            )
            base = base.where(Opportunity.severity_score >= 70)
        else:
            base = _apply_status_filter(
                base,
                status,
                collapse_pending_states=collapse_pending_states,
            )

        if search:
            escaped = (
                search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            )
            like_pattern = f"%{escaped}%"
            base = base.where(
                Opportunity.opportunity_type.ilike(like_pattern, escape="\\")
                | Opportunity.affected_table.ilike(like_pattern, escape="\\")
                | Opportunity.dbt_model_name.ilike(like_pattern, escape="\\")
            )

        if project_ids:
            base = base.where(Opportunity.config_id.in_(project_ids))
        if type_names:
            base = base.where(
                func.lower(Opportunity.opportunity_type).in_(
                    [type_name.lower() for type_name in type_names]
                )
            )
        if date_start:
            base = base.where(Opportunity.created_at >= date_start)
        if date_end:
            base = base.where(Opportunity.created_at <= date_end)

        # Sort within groups
        base = _apply_sort(base, sort_column, sort_direction)

        rows = self.db.execute(base).all()

        # Batch solution risk + dry run cost + last job cost for all results
        all_opps = [row[0] for row in rows]
        all_ids = [opp.id for opp in all_opps]
        latest_solution_map = get_latest_solution_snapshots(
            self.db,
            all_ids,
            schedule_missing_dry_runs=True,
        )
        last_job_details_map = (
            get_last_job_details(self.db, all_opps) if all_opps else {}
        )
        exact_local_workload_map = (
            get_exact_local_workload_kinds(self.db, all_opps)
            if all_opps and is_local_mode()
            else {}
        )
        active_solution_job_status_map = get_active_solution_job_statuses(
            self.db, all_ids
        )

        wl_estimates_map = _load_workload_estimates(self.db, all_ids)

        # Group results
        groups: dict[str, dict] = {}
        for row in rows:
            opp: Opportunity = row[0]
            project_name: str = row[1]

            if group_by == "project":
                group_id = opp.config_id
                group_name = project_name
            else:  # type
                group_id = opp.opportunity_type
                group_name = opp.opportunity_type

            if group_id not in groups:
                groups[group_id] = {
                    "group_id": group_id,
                    "group_name": group_name,
                    "opportunity_count": 0,
                    "total_savings": Decimal("0"),
                    "opportunities": [],
                }

            g = groups[group_id]
            g["opportunity_count"] += 1

            latest_solution = latest_solution_map.get(opp.id, {})
            latest_job_details = last_job_details_map.get(opp.id, {})
            workload_kind = (
                exact_local_workload_map.get(opp.id)
                if is_local_mode()
                else _normalize_workload_kind(latest_job_details.get("workload_kind"))
            )
            entry = {
                "id": opp.id,
                "config_id": opp.config_id,
                "project_name": project_name,
                "opportunity_type": opp.opportunity_type,
                "affected_table": opp.affected_table,
                "dbt_model_name": opp.dbt_model_name,
                "severity_score": opp.severity_score,
                "current_cost_estimate": opp.current_cost_estimate,
                "expected_savings": opp.expected_savings,
                "status": opp.status,
                "cascade_status": opp.cascade_status,
                "cascade_root_id": opp.cascade_root_id,
                "occurrence_count": opp.occurrence_count,
                "created_at": opp.created_at,
                "last_detected_at": opp.last_detected_at,
                "has_solution": bool(latest_solution),
                "solution_risk_level": latest_solution.get("risk_level"),
                "avg_query_cost": latest_job_details.get("total_cost"),
                "dry_run_original_cost": latest_solution.get("dry_run_original_cost"),
                "dry_run_modified_cost": latest_solution.get("dry_run_modified_cost"),
                "solution_job_status": active_solution_job_status_map.get(opp.id),
                "prefers_possible_savings_display": latest_solution.get(
                    "prefers_possible_savings_display",
                    False,
                ),
                "query_workload_kind": workload_kind,
                "query_workload_label": workload_kind.title()
                if workload_kind
                else "Query",
            }
            entry.update(
                build_cost_display(
                    current_cost_estimate=opp.current_cost_estimate,
                    latest_job_cost=latest_job_details.get("total_cost"),
                    dry_run_original_cost=latest_solution.get("dry_run_original_cost"),
                    dry_run_modified_cost=latest_solution.get("dry_run_modified_cost"),
                    use_dry_run_original_for_query_cost=latest_solution.get(
                        "supports_optimized_dry_run",
                        False,
                    )
                    if latest_solution
                    else False,
                    prefer_possible_savings_display=entry[
                        "prefers_possible_savings_display"
                    ],
                )
            )
            wl_est = wl_estimates_map.get(opp.id)
            entry.update(
                build_possible_savings_display(
                    opportunity_type=opp.opportunity_type,
                    expected_savings=opp.expected_savings,
                    occurrence_count=opp.occurrence_count,
                    optimized_cost_value=entry["optimized_cost_value"],
                    optimized_delta_direction=entry.get("optimized_delta_direction"),
                    workload_per_run_savings=wl_est.per_run_savings if wl_est else None,
                    workload_confidence=wl_est.confidence if wl_est else None,
                    workload_jobs_analyzed=wl_est.jobs_analyzed if wl_est else None,
                    prefer_possible_savings_display=entry[
                        "prefers_possible_savings_display"
                    ],
                    has_solution=entry.get("has_solution", False),
                )
            )
            if entry["possible_savings_value"] is not None:
                g["total_savings"] += entry["possible_savings_value"]
            g["opportunities"].append(entry)

        # Sort groups by total_savings DESC
        sorted_groups = sorted(
            groups.values(), key=lambda g: g["total_savings"], reverse=True
        )
        return sorted_groups
