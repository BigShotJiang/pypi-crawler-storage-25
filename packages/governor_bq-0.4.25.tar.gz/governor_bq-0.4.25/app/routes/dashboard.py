"""
Dashboard routes for cost analytics.

Provides the main dashboard view and HTMX partial routes for section updates.
"""

from __future__ import annotations

from collections.abc import Generator
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from starlette.responses import Response

from sqlalchemy import func

from app.auth.dependencies import get_current_user
from app.auth.models import User
from app.core.config import is_local_mode
from app.dashboard.formatters import (
    apply_cost_multiplier,
    format_bytes,
    format_duration,
    format_slot_hours,
    format_usd,
)
from app.dashboard.service import DashboardService
from app.db.session import get_session
from app.routes.helpers import get_flash_message
from app.solutions.models import SolutionJob

router = APIRouter(tags=["dashboard"])

_VALID_COST_LENSES = {"all", "build", "consumption", "storage"}
_LENS_LABELS = {
    "all": "All Query",
    "build": "Build",
    "consumption": "Consumption",
    "storage": "Storage",
}


def _build_opportunity_type_breakdown(
    by_type: dict[str, int],
) -> list[dict[str, int | str]]:
    """Normalize and sort opportunity type counts for chart rendering."""
    return [
        {"label": opp_type.replace("_", " ").lower(), "count": count}
        for opp_type, count in sorted(
            by_type.items(),
            key=lambda item: (-item[1], item[0]),
        )
    ]


def _build_opportunity_type_cards(
    by_type_detail: dict[str, dict],
) -> list[dict]:
    """Build per-type summary cards sorted by estimated savings descending."""
    cards = []
    for opp_type, detail in by_type_detail.items():
        cards.append(
            {
                "label": opp_type.replace("_", " "),
                "type_key": opp_type,
                "count": detail["count"],
                "total_cost": float(detail.get("total_cost", 0)),
                "estimated_savings": float(detail.get("estimated_savings", 0)),
            }
        )
    cards.sort(key=lambda c: (-c["estimated_savings"], -c["count"]))
    return cards


def _severity_level(max_severity: int | None) -> str | None:
    """Map max_severity score to a severity level string."""
    if max_severity is None:
        return None
    if max_severity >= 70:
        return "critical"
    if max_severity >= 40:
        return "warning"
    return "info"


def _has_running_background_jobs(db: Session) -> bool:
    from app.opportunities.models import DetectionJob
    from app.sync.models import SyncOperation

    active_statuses = ("queued", "in_progress")
    running_syncs = (
        db.query(func.count())
        .filter(SyncOperation.status.in_(active_statuses))
        .scalar()
        or 0
    )
    running_detections = (
        db.query(func.count()).filter(DetectionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    running_solutions = (
        db.query(func.count()).filter(SolutionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    return running_syncs + running_detections + running_solutions > 0


def _parse_cost_lens(lens: str | None) -> str:
    if lens in _VALID_COST_LENSES:
        return lens
    return "all"


def _lens_label(lens: str) -> str:
    return _LENS_LABELS.get(lens, _LENS_LABELS["all"])


def _append_query_params(url: str, **params: str | int | None) -> str:
    query_parts = []
    for key, value in params.items():
        if value in (None, "", "all"):
            continue
        query_parts.append(f"{key}={value}")

    if not query_parts:
        return url

    separator = "&" if "?" in url else "?"
    return f"{url}{separator}{'&'.join(query_parts)}"


def _serialize_project_driver(
    driver,
    lens: str,
    days_preset: int | None = None,
) -> dict:
    project_url = _append_query_params(
        driver.project_url,
        lens=None if lens == "all" else lens,
        days=days_preset,
    )

    if lens == "storage":
        freshness = (
            driver.storage_latest_synced_at.strftime("%Y-%m-%d %H:%M UTC")
            if driver.storage_latest_synced_at
            else "No snapshot"
        )
        return {
            "config_id": driver.config_id,
            "config_name": driver.config_name,
            "spend": format_usd(driver.total_spend),
            "spend_raw": apply_cost_multiplier(driver.total_spend),
            "percentage": driver.percentage_of_total,
            "job_count": driver.storage_dataset_count,
            "slot_time": format_bytes(driver.storage_physical_bytes),
            "data_processed": format_bytes(driver.storage_logical_bytes),
            "duration": freshness,
            "opportunity_count": driver.opportunity_count,
            "potential_savings": format_usd(driver.potential_savings),
            "project_url": project_url,
        }

    return {
        "config_id": driver.config_id,
        "config_name": driver.config_name,
        "spend": format_usd(driver.total_spend),
        "spend_raw": apply_cost_multiplier(driver.total_spend),
        "percentage": driver.percentage_of_total,
        "job_count": driver.unique_job_count,
        "slot_time": format_slot_hours(driver.total_slot_ms),
        "data_processed": format_bytes(driver.total_bytes_billed),
        "duration": format_duration(driver.total_duration_ms),
        "opportunity_count": driver.opportunity_count,
        "potential_savings": format_usd(driver.potential_savings),
        "project_url": project_url,
    }


def _serialize_local_model_driver(driver) -> dict:
    return {
        "model_name": driver.model_name,
        "unique_id": driver.unique_id,
        "materialization": (driver.materialization or "unknown").replace("_", " "),
        "cost": format_usd(driver.total_cost),
        "cost_raw": apply_cost_multiplier(driver.total_cost),
        "bytes": format_bytes(driver.total_bytes_billed),
        "bytes_raw": driver.total_bytes_billed,
        "issues": driver.issue_count,
        "enhancements": driver.enhancement_count,
        "score": driver.score,
        "opportunity_count": driver.opportunity_count,
        "opportunity_url": driver.opportunity_url,
        "duration": format_duration(driver.duration_ms),
        "execution_time_s": driver.execution_time_s,
        "job_state": driver.job_state,
    }


def _parse_date_range(
    days: int | None, start: str | None, end: str | None
) -> tuple[datetime, datetime, int | None, str]:
    """
    Parse date range from query parameters.

    Args:
        days: Preset range (7, 30, or 90)
        start: Custom start date (ISO 8601)
        end: Custom end date (ISO 8601)

    Returns:
        Tuple of (start_date, end_date, days_preset, display_string)
    """
    now = datetime.now(timezone.utc)

    # If days is specified, use preset range
    if days and days in (7, 30, 90):
        start_date = now - timedelta(days=days)
        return start_date, now, days, f"Last {days} days"

    # Try to parse custom dates
    if start and end:
        try:
            start_date = datetime.fromisoformat(start.replace("Z", "+00:00"))
            end_date = datetime.fromisoformat(end.replace("Z", "+00:00"))
            if start_date.tzinfo is None:
                start_date = start_date.replace(tzinfo=timezone.utc)
            if end_date.tzinfo is None:
                end_date = end_date.replace(tzinfo=timezone.utc)
            display = (
                f"{start_date.strftime('%b %d')} - {end_date.strftime('%b %d, %Y')}"
            )
            return start_date, end_date, None, display
        except ValueError:
            pass

    # Default to 30 days
    start_date = now - timedelta(days=30)
    return start_date, now, 30, "Last 30 days"


@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None, description="Preset range: 7, 30, or 90"),
    start: str | None = Query(default=None, description="Custom start date (ISO 8601)"),
    end: str | None = Query(default=None, description="Custom end date (ISO 8601)"),
    lens: str = Query(default="all", description="Cost lens"),
) -> Response:
    """Main dashboard page with all cost analytics sections."""
    start_date, end_date, days_preset, display = _parse_date_range(days, start, end)
    selected_lens = _parse_cost_lens(lens)

    service = DashboardService(db)
    local_model_dashboard = is_local_mode() and selected_lens != "storage"

    # Get all dashboard data
    summary = service.get_summary(start_date, end_date)
    trend_data = service.get_daily_trend(start_date, end_date, lens=selected_lens)
    cost_drivers = service.get_top_cost_drivers(
        start_date, end_date, lens=selected_lens
    )
    environment_breakdown = service.get_environment_breakdown(start_date, end_date)
    opportunities = service.get_opportunities_summary(start_date, end_date)
    opportunity_type_cards = service.get_opportunity_type_summary(start_date, end_date)
    usage_data = service.get_project_daily_stats(
        None, start_date, end_date, lens=selected_lens
    )
    total_verified_savings = service.get_total_verified_savings()
    total_possible_savings = service.get_total_possible_savings()
    total_process_costs = service.get_total_process_costs()
    clearing_savings = service.get_clearing_savings()
    estimated_savings_range, verified_savings_range = (
        service.get_savings_for_date_range(start_date, end_date)
    )

    # Count running solution jobs across all configs
    active_statuses = ("queued", "in_progress")
    running_solutions = (
        db.query(func.count()).filter(SolutionJob.status.in_(active_statuses)).scalar()
        or 0
    )
    background_jobs_running = _has_running_background_jobs(db)

    # Project drivers (paginated, page 1)
    project_drivers_list, pagination = service.get_project_drivers(
        start_date, end_date, page=1, page_size=10, lens=selected_lens
    )
    project_drivers = [
        _serialize_project_driver(d, selected_lens, days_preset or 30)
        for d in project_drivers_list
    ]
    local_model_points = (
        service.get_local_model_run_points() if local_model_dashboard else []
    )
    local_model_drivers_list, local_model_pagination = (
        service.get_local_model_drivers(page=1, page_size=5)
        if local_model_dashboard
        else ([], None)
    )

    # Build template context
    context = {
        "title": "Cost Dashboard",
        "user": user,
        "flash": get_flash_message(request),
        "local_runtime_mode": is_local_mode(),
        "date_range": {
            "start": start_date,
            "end": end_date,
            "days": days_preset,
            "display": "Last execution" if local_model_dashboard else display,
        },
        "days_preset": days_preset or 30,
        "selected_lens": selected_lens,
        "selected_lens_label": _lens_label(selected_lens),
        "summary": {
            "total_spend": format_usd(summary.total_spend),
            "total_spend_raw": apply_cost_multiplier(summary.total_spend),
            "build_spend": format_usd(summary.build_spend),
            "build_spend_raw": apply_cost_multiplier(summary.build_spend),
            "consumption_spend": format_usd(summary.consumption_spend),
            "consumption_spend_raw": apply_cost_multiplier(summary.consumption_spend),
            "storage_monthly_cost": (
                format_usd(summary.storage_monthly_cost)
                if summary.storage_monthly_cost is not None
                else None
            ),
            "storage_monthly_cost_raw": (
                apply_cost_multiplier(summary.storage_monthly_cost)
                if summary.storage_monthly_cost is not None
                else None
            ),
            "storage_potential_savings": (
                format_usd(summary.storage_potential_savings)
                if summary.storage_potential_savings is not None
                else None
            ),
            "storage_potential_savings_raw": (
                apply_cost_multiplier(summary.storage_potential_savings)
                if summary.storage_potential_savings is not None
                else None
            ),
            "storage_latest_synced_at": summary.storage_latest_synced_at,
            "opportunity_count": opportunities.total_opportunities,
            "total_verified_savings": format_usd(total_verified_savings),
            "total_verified_savings_raw": apply_cost_multiplier(total_verified_savings),
            "total_possible_savings": format_usd(total_possible_savings),
            "total_possible_savings_raw": apply_cost_multiplier(total_possible_savings),
            "estimated_savings_range": format_usd(estimated_savings_range),
            "estimated_savings_range_raw": apply_cost_multiplier(
                estimated_savings_range
            ),
            "verified_savings_range": format_usd(verified_savings_range),
            "verified_savings_range_raw": apply_cost_multiplier(verified_savings_range),
            "total_process_costs": format_usd(total_process_costs),
            "total_process_costs_raw": apply_cost_multiplier(total_process_costs),
            "clearing_savings": format_usd(clearing_savings),
            "clearing_savings_raw": apply_cost_multiplier(clearing_savings),
        },
        "trend_data": [
            {
                "date": d.date.isoformat(),
                "cost": apply_cost_multiplier(d.total_cost),
                "build_cost": apply_cost_multiplier(d.build_cost),
                "consumption_cost": apply_cost_multiplier(d.consumption_cost),
                "jobs": d.job_count,
            }
            for d in trend_data
        ],
        "local_model_dashboard": local_model_dashboard,
        "local_model_points": [
            {
                "model_name": point.model_name,
                "materialization": (point.materialization or "unknown").replace(
                    "_", " "
                ),
                "cost": apply_cost_multiplier(point.total_cost),
                "bytes": point.total_bytes_billed,
                "bytes_display": format_bytes(point.total_bytes_billed),
                "duration_ms": point.duration_ms,
                "duration_display": format_duration(point.duration_ms),
                "execution_time_s": point.execution_time_s,
                "job_state": point.job_state,
            }
            for point in local_model_points
        ],
        "cost_drivers": [
            {
                "rank": d.rank,
                "name": d.identifier,
                "type": d.identifier_type,
                "spend": format_usd(d.total_spend),
                "spend_raw": apply_cost_multiplier(d.total_spend),
                "percentage": d.percentage_of_total,
                "job_count": d.job_count,
                "detail_url": d.detail_url,
            }
            for d in cost_drivers
        ],
        "project_drivers": project_drivers,
        "pagination": pagination,
        "local_model_drivers": [
            _serialize_local_model_driver(driver) for driver in local_model_drivers_list
        ],
        "local_model_pagination": local_model_pagination,
        "environment_breakdown": [
            {
                "environment": e.environment,
                "spend": format_usd(e.total_spend),
                "spend_raw": apply_cost_multiplier(e.total_spend),
                "percentage": e.percentage_of_total,
            }
            for e in environment_breakdown
        ],
        "opportunities": {
            "issue_density": opportunities.issue_density,
            "total_count": opportunities.total_opportunities,
            "type_breakdown": _build_opportunity_type_breakdown(opportunities.by_type),
            "type_cards": opportunity_type_cards,
            "detail_url": opportunities.detail_url,
        },
        "usage_stats": [
            {
                "date": d.date.isoformat(),
                "runs": d.job_count,
                "bytes": d.total_bytes_billed,
                "bytes_display": format_bytes(d.total_bytes_billed),
                "slots": d.total_slot_ms,
                "slots_display": format_slot_hours(d.total_slot_ms),
            }
            for d in usage_data
        ],
        "has_data": summary.job_count > 0 or summary.storage_monthly_cost is not None,
        "running_solutions": running_solutions,
        "background_jobs_running": background_jobs_running,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "dashboard/index.html", context)


# HTMX Partial Routes


@router.get("/dashboard/summary", response_class=HTMLResponse)
def dashboard_summary_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
    lens: str = Query(default="all"),
) -> Response:
    """HTMX partial: Refresh cost summary section."""
    start_date, end_date, _, display = _parse_date_range(days, start, end)
    selected_lens = _parse_cost_lens(lens)
    service = DashboardService(db)
    summary = service.get_summary(start_date, end_date)
    opportunities = service.get_opportunities_summary(start_date, end_date)
    total_verified_savings = service.get_total_verified_savings()
    total_possible_savings = service.get_total_possible_savings()
    total_process_costs = service.get_total_process_costs()
    clearing_savings = service.get_clearing_savings()
    estimated_savings_range, verified_savings_range = (
        service.get_savings_for_date_range(start_date, end_date)
    )
    active_statuses = ("queued", "in_progress")
    running_solutions = (
        db.query(func.count()).filter(SolutionJob.status.in_(active_statuses)).scalar()
        or 0
    )

    context = {
        "local_runtime_mode": is_local_mode(),
        "running_solutions": running_solutions,
        "summary": {
            "total_spend": format_usd(summary.total_spend),
            "total_spend_raw": apply_cost_multiplier(summary.total_spend),
            "build_spend": format_usd(summary.build_spend),
            "build_spend_raw": apply_cost_multiplier(summary.build_spend),
            "consumption_spend": format_usd(summary.consumption_spend),
            "consumption_spend_raw": apply_cost_multiplier(summary.consumption_spend),
            "storage_monthly_cost": (
                format_usd(summary.storage_monthly_cost)
                if summary.storage_monthly_cost is not None
                else None
            ),
            "storage_monthly_cost_raw": (
                apply_cost_multiplier(summary.storage_monthly_cost)
                if summary.storage_monthly_cost is not None
                else None
            ),
            "storage_potential_savings": (
                format_usd(summary.storage_potential_savings)
                if summary.storage_potential_savings is not None
                else None
            ),
            "storage_latest_synced_at": summary.storage_latest_synced_at,
            "opportunity_count": opportunities.total_opportunities,
            "total_verified_savings": format_usd(total_verified_savings),
            "total_verified_savings_raw": apply_cost_multiplier(total_verified_savings),
            "total_possible_savings": format_usd(total_possible_savings),
            "total_possible_savings_raw": apply_cost_multiplier(total_possible_savings),
            "estimated_savings_range": format_usd(estimated_savings_range),
            "estimated_savings_range_raw": apply_cost_multiplier(
                estimated_savings_range
            ),
            "verified_savings_range": format_usd(verified_savings_range),
            "verified_savings_range_raw": apply_cost_multiplier(verified_savings_range),
            "total_process_costs": format_usd(total_process_costs),
            "total_process_costs_raw": apply_cost_multiplier(total_process_costs),
            "clearing_savings": format_usd(clearing_savings),
            "clearing_savings_raw": apply_cost_multiplier(clearing_savings),
        },
        "date_range": {
            "start": start_date,
            "end": end_date,
            "days": days,
            "display": "Last execution" if is_local_mode() else display,
        },
        "days_preset": days or 30,
        "selected_lens": selected_lens,
        "selected_lens_label": _lens_label(selected_lens),
        "has_data": summary.job_count > 0 or summary.storage_monthly_cost is not None,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "dashboard/_cost_summary.html", context)


@router.get("/dashboard/trend", response_class=HTMLResponse)
def dashboard_trend_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
    lens: str = Query(default="all"),
) -> Response:
    """HTMX partial: Refresh trend chart section."""
    start_date, end_date, _, _ = _parse_date_range(days, start, end)
    selected_lens = _parse_cost_lens(lens)
    service = DashboardService(db)
    trend_data = service.get_daily_trend(start_date, end_date, lens=selected_lens)
    local_model_dashboard = is_local_mode() and selected_lens != "storage"
    local_model_points = (
        service.get_local_model_run_points() if local_model_dashboard else []
    )

    context = {
        "local_model_dashboard": local_model_dashboard,
        "local_model_points": [
            {
                "model_name": point.model_name,
                "materialization": (point.materialization or "unknown").replace(
                    "_", " "
                ),
                "cost": apply_cost_multiplier(point.total_cost),
                "bytes": point.total_bytes_billed,
                "bytes_display": format_bytes(point.total_bytes_billed),
                "duration_ms": point.duration_ms,
                "duration_display": format_duration(point.duration_ms),
                "execution_time_s": point.execution_time_s,
                "job_state": point.job_state,
            }
            for point in local_model_points
        ],
        "trend_data": [
            {
                "date": d.date.isoformat(),
                "cost": apply_cost_multiplier(d.total_cost),
                "build_cost": apply_cost_multiplier(d.build_cost),
                "consumption_cost": apply_cost_multiplier(d.consumption_cost),
                "jobs": d.job_count,
            }
            for d in trend_data
        ],
        "selected_lens": selected_lens,
        "selected_lens_label": _lens_label(selected_lens),
        "date_range": {
            "display": "Last execution"
            if local_model_dashboard
            else _parse_date_range(days, start, end)[3]
        },
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "dashboard/_trend_chart.html", context)


@router.get("/dashboard/usage", response_class=HTMLResponse)
def dashboard_usage_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
    lens: str = Query(default="all"),
) -> Response:
    """HTMX partial: Refresh usage statistics charts."""
    start_date, end_date, _, display = _parse_date_range(days, start, end)
    selected_lens = _parse_cost_lens(lens)
    local_model_dashboard = is_local_mode() and selected_lens != "storage"
    service = DashboardService(db)
    usage_data = service.get_project_daily_stats(
        None, start_date, end_date, lens=selected_lens
    )

    context = {
        "usage_stats": [
            {
                "date": d.date.isoformat(),
                "runs": d.job_count,
                "bytes": d.total_bytes_billed,
                "bytes_display": format_bytes(d.total_bytes_billed),
                "slots": d.total_slot_ms,
                "slots_display": format_slot_hours(d.total_slot_ms),
            }
            for d in usage_data
        ],
        "date_range": {
            "display": display,
        },
        "selected_lens": selected_lens,
        "selected_lens_label": _lens_label(selected_lens),
        "local_model_dashboard": local_model_dashboard,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "dashboard/_usage_stats.html", context)


@router.get("/dashboard/drivers", response_class=HTMLResponse)
def dashboard_drivers_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
    lens: str = Query(default="all"),
) -> Response:
    """HTMX partial: Refresh cost drivers section."""
    start_date, end_date, days_preset, _ = _parse_date_range(days, start, end)
    selected_lens = _parse_cost_lens(lens)
    service = DashboardService(db)
    local_model_dashboard = is_local_mode() and selected_lens != "storage"
    project_drivers_list, pagination = service.get_project_drivers(
        start_date, end_date, page=1, page_size=10, lens=selected_lens
    )
    local_model_drivers_list, local_model_pagination = (
        service.get_local_model_drivers(
            page=1,
            page_size=5,
            sort_by="execution",
            sort_direction="desc",
        )
        if local_model_dashboard
        else ([], None)
    )

    context = {
        "local_model_dashboard": local_model_dashboard,
        "project_drivers": [
            _serialize_project_driver(d, selected_lens, days_preset or 30)
            for d in project_drivers_list
        ],
        "pagination": pagination,
        "local_model_drivers": [
            _serialize_local_model_driver(driver) for driver in local_model_drivers_list
        ],
        "local_model_pagination": local_model_pagination,
        "days_preset": days_preset or 30,
        "selected_lens": selected_lens,
        "selected_lens_label": _lens_label(selected_lens),
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(request, "dashboard/_cost_drivers.html", context)


# ---------------------------------------------------------------------------
# Datastar SSE: Filter cost drivers table (spec 026)
# ---------------------------------------------------------------------------


@router.get("/dashboard/filter-drivers")
async def filter_drivers_sse(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
) -> Response:
    """SSE endpoint returning filtered cost drivers table fragment."""
    from datastar_py import SSE_HEADERS
    from datastar_py.consts import ElementPatchMode
    from datastar_py.fastapi import read_signals
    from datastar_py.sse import ServerSentEventGenerator as SSEGenerator
    from fastapi.responses import StreamingResponse

    signals = await read_signals(request)
    signals = signals or {}
    search_query = str(signals.get("driverSearch", "")).strip()
    driver_days = signals.get("driverDays", 30)
    driver_page = signals.get("driverPage", 1)
    driver_page_size = signals.get("driverPageSize", 10)
    driver_sort = str(signals.get("driverSort", "execution"))
    driver_direction = str(signals.get("driverDirection", "desc"))
    driver_lens = _parse_cost_lens(str(signals.get("driverLens", "all")))

    try:
        driver_days = int(driver_days)
    except TypeError, ValueError:
        driver_days = 30
    if driver_days not in (7, 30, 90):
        driver_days = 30

    try:
        driver_page = int(driver_page)
    except TypeError, ValueError:
        driver_page = 1
    if driver_page < 1:
        driver_page = 1
    try:
        driver_page_size = int(driver_page_size)
    except TypeError, ValueError:
        driver_page_size = 10
    if driver_page_size not in (5, 10, 100):
        driver_page_size = 10

    local_model_dashboard = is_local_mode() and driver_lens != "storage"
    if local_model_dashboard:
        valid_sorts = (
            "model",
            "cost",
            "bytes",
            "issues",
            "enhancements",
            "score",
            "opportunity",
            "execution",
        )
        default_sort = "execution"
    else:
        valid_sorts = (
            "project",
            "spend",
            "jobs",
            "slots",
            "data",
            "duration",
            "opportunities",
            "savings",
        )
        default_sort = "spend"
    if driver_sort not in valid_sorts:
        driver_sort = default_sort
    if driver_direction not in ("asc", "desc"):
        driver_direction = "desc"

    now = datetime.now(timezone.utc)
    start_date = now - timedelta(days=driver_days)
    end_date = now

    service = DashboardService(db)
    if local_model_dashboard:
        local_model_drivers_list, pagination = service.get_local_model_drivers(
            search_query=search_query,
            page=driver_page,
            page_size=driver_page_size,
            sort_by=driver_sort,
            sort_direction=driver_direction,
        )
        local_model_drivers = [
            _serialize_local_model_driver(driver) for driver in local_model_drivers_list
        ]
        project_drivers = []
    else:
        project_drivers_list, pagination = service.get_project_drivers(
            start_date,
            end_date,
            search_query=search_query,
            page=driver_page,
            page_size=10,
            sort_by=driver_sort,
            sort_direction=driver_direction,
            lens=driver_lens,
        )

        project_drivers = [
            _serialize_project_driver(d, driver_lens, driver_days)
            for d in project_drivers_list
        ]
        local_model_drivers = []

    def _generate() -> Generator[str, None, None]:
        templates = request.app.state.templates
        html = templates.get_template("dashboard/_cost_drivers_table.html").render(
            project_drivers=project_drivers,
            local_model_dashboard=local_model_dashboard,
            local_model_drivers=local_model_drivers,
            local_model_pagination=pagination if local_model_dashboard else None,
            pagination=pagination,
            search_query=search_query,
            selected_lens=driver_lens,
        )
        yield str(
            SSEGenerator.patch_elements(
                html,
                selector="#drivers-content",
                mode=ElementPatchMode.OUTER,
            )
        )

    return StreamingResponse(_generate(), headers=SSE_HEADERS)


@router.get("/dashboard/breakdown/environment", response_class=HTMLResponse)
def dashboard_environment_breakdown_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
) -> Response:
    """HTMX partial: Refresh environment breakdown section."""
    start_date, end_date, _, _ = _parse_date_range(days, start, end)
    service = DashboardService(db)
    environment_breakdown = service.get_environment_breakdown(start_date, end_date)

    context = {
        "environment_breakdown": [
            {
                "environment": e.environment,
                "spend": format_usd(e.total_spend),
                "spend_raw": apply_cost_multiplier(e.total_spend),
                "percentage": e.percentage_of_total,
            }
            for e in environment_breakdown
        ],
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request, "dashboard/_environment_breakdown.html", context
    )


@router.get("/dashboard/opportunities", response_class=HTMLResponse)
def dashboard_opportunities_partial(
    request: Request,
    db: Session = Depends(get_session),
    user: User = Depends(get_current_user),
    days: int | None = Query(default=None),
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
) -> Response:
    """HTMX partial: Refresh opportunities summary section."""
    start_date, end_date, _, display = _parse_date_range(days, start, end)
    service = DashboardService(db)
    opportunities = service.get_opportunities_summary(start_date, end_date)
    opportunity_type_cards = service.get_opportunity_type_summary(start_date, end_date)
    background_jobs_running = _has_running_background_jobs(db)

    context = {
        "opportunities": {
            "issue_density": opportunities.issue_density,
            "total_count": opportunities.total_opportunities,
            "type_breakdown": _build_opportunity_type_breakdown(opportunities.by_type),
            "type_cards": opportunity_type_cards,
            "detail_url": opportunities.detail_url,
        },
        "date_range": {"display": display},
        "background_jobs_running": background_jobs_running,
    }

    templates = request.app.state.templates
    return templates.TemplateResponse(
        request, "dashboard/_opportunities_summary.html", context
    )
