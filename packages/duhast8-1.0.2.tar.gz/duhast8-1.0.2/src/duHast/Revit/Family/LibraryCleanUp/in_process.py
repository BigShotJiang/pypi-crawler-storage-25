# License:
#
#
# Revit Batch Processor Sample Code
#
# BSD License
# Copyright 2025, Jan Christel
# All rights reserved.

# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

# - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# - Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
#
# This software is provided by the copyright holder "as is" and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed.
# In no event shall the copyright holder be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits;
# or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.
#
#
#
import os

from duHast.Utilities.Objects.result import Result
from duHast.Utilities.files_io import get_file_name_without_ext

from duHast.Revit.Family.Utility.family_swap_instances_by_type_utils import get_swap_directives
from duHast.Revit.Family.family_swap_instances_of_types import swap_family_instances_of_types
from duHast.Revit.Family.LibraryCleanUp.Utility.directives_read_from_file import read_maintain_types
from duHast.Revit.Family.LibraryCleanUp.Utility.directive_maintain_types_execute import delete_non_conforming_types
from duHast.Revit.Family.LibraryCleanUp.Utility.family_load import load_families_required_for_swapping

from duHast.Revit.Purge.purge_unused_e_transmit import purge_unused_e_transmit
from duHast.Revit.Common.file_io import save_as_family


DEBUG = True


def in_process_family(doc, library_path, output, additional_modifier_function=None, parameters_to_reset = []):
    """
    
    """

    return_value = Result()

    # read maintain list and delete unused types in family
    # export family types (?)

    # find families which need swapping load them and swap them out
    # save family

    try:

        # make sure this really is a family document
        if not doc.IsFamilyDocument:
            return_value.update_sep(False, "The document is not a family document.")
            return return_value

        # read maintain types from file
        read_maintain_result = read_maintain_types(library_path)

        # check if the read operation was successful
        if not read_maintain_result.status:
            return_value.update_sep(False, "Failed to read maintain types: {}".format(read_maintain_result.message))
            output("Failed to read maintain types: {}".format(read_maintain_result.message))
            return return_value
        
        # get the maintain types from the result
        main_tain_types = read_maintain_result.result

        output("{} maintain types read from file.".format(len(main_tain_types)))

        # attempt to delete non-conforming types
        delete_non_conforming_types_result = delete_non_conforming_types(doc, main_tain_types, parameters_to_reset)
        if not delete_non_conforming_types_result.status:
            return_value.update_sep(False, "Failed to delete non-conforming types: {}".format(delete_non_conforming_types_result.message))
            return return_value
        
        output(delete_non_conforming_types_result.message)

        # load swap directives
        swap_directives_result = get_swap_directives(directory_path=library_path)

        if not swap_directives_result.status:
            return_value.update_sep(False, "Failed to read swap directives: {}".format(swap_directives_result.message))
            output("Failed to read swap directives: {}".format(swap_directives_result.message))
            return return_value
        
        swap_directives = swap_directives_result.result

        # load families required for swapping
        load_result = load_families_required_for_swapping(doc,  swap_directives, library_path)

        if not load_result.status:
            return_value.update_sep(False, "Failed to load families required for swapping: {}".format(load_result.message))
            output("Failed to load families required for swapping: {}".format(load_result.message))
            return return_value
        
        output("Families successfully loaded for swapping: {}".format(len(load_result.result)))

        # swap out families if necessary
        if( len(load_result.result) == 0):
            return_value.update_sep(True, "No families needing swapping in file")
            output("No families needing swapping in file")
            #return return_value
        else:
            # swap away
            swap_result = swap_family_instances_of_types(doc, library_path, progress_callback=None)

            # print logs
            output("Swapped families with status: {}".format(swap_result.status))

            # check what came back
            if not swap_result.status:
                return_value.update_sep(False, "Failed to swap families: {}".format(swap_result.message))
                output("Failed to swap families: {}".format(swap_result.message))
                return return_value
       
        
        # if we get here... do a purge unused and than save that family document
        purge_action_result = purge_unused_e_transmit(doc)

        if not purge_action_result.status:
            return_value.update_sep(False, "Failed to purge unused elements: {}".format(purge_action_result.message))
            output("Failed to purge unused elements: {}".format(purge_action_result.message))
            return return_value
        
        output("Purged unused elements successfully.")

        # execute additional modifier function if provided
        if additional_modifier_function is not None:
            additional_modifier_result = additional_modifier_function(doc)

            if not additional_modifier_result.status:
                return_value.update_sep(False, "Failed to execute additional modifier function: {}".format(additional_modifier_result.message))
                output("Failed to execute additional modifier function: {}".format(additional_modifier_result.message))
            else:
            
                output("Executed additional modifier function successfully.")
        else:
            output("No additional modifier function provided, skipping this step.")


        file_name_without_ext = get_file_name_without_ext(doc.PathName)
        
        revit_fam_file_path = os.path.join(library_path, file_name_without_ext + ".rfa")
        output("Saving family to: {}".format(revit_fam_file_path))

        # save the family document
        save_result = save_as_family(
            doc=doc,
            target_directory_path=library_path,
            current_full_file_name= doc.PathName,
            name_data=[[file_name_without_ext, file_name_without_ext]],
            file_extension= ".rfa",
            compact_file=True)
        
        output("Save result: {}".format(save_result.status))


    except Exception as e:
        return_value.update_sep(False, "An error occurred: {}".format(str(e)))
        output("An error occurred: {}".format(str(e)))
        return return_value
    return return_value