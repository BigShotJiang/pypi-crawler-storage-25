import importlib.metadata

from trama.errors import JSONError, RegistryError, SchemaError, TramaError, ValidationError
from trama.export_model import export_model
from trama.import_model import import_model
from trama.io import dump, dumps, json_schema, load, loads
from trama.protocol import ExportableOp, ImportableOp, NodeFragment, compose_fragment, last_segment, parent_of
from trama.registry import OpRegistry, OpSpec, ParameterSchema
from trama.schema import FORMAT_VERSION, ExportedModel, Node, ParameterValue, ValueRef
from trama.tensor import (
    TensorValue,
    byte_size,
    decode_bytes,
    encode_bytes,
    validate_dtype,
)
from trama.validation_registry import validate, validate_with_registry
from trama.validation_structure import validate_structure

__version__ = importlib.metadata.version("trama")

__all__ = [
    "ExportableOp",
    "ExportedModel",
    "FORMAT_VERSION",
    "ImportableOp",
    "JSONError",
    "Node",
    "NodeFragment",
    "OpRegistry",
    "OpSpec",
    "ParameterSchema",
    "ParameterValue",
    "RegistryError",
    "SchemaError",
    "TensorValue",
    "TramaError",
    "ValidationError",
    "ValueRef",
    "__version__",
    "byte_size",
    "compose_fragment",
    "decode_bytes",
    "dump",
    "dumps",
    "encode_bytes",
    "export_model",
    "import_model",
    "json_schema",
    "last_segment",
    "load",
    "loads",
    "parent_of",
    "validate",
    "validate_dtype",
    "validate_structure",
    "validate_with_registry",
]
