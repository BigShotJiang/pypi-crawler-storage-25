import json
from pathlib import Path
from typing import Any

import pydantic

from trama.errors import JSONError as _JSONError
from trama.errors import SchemaError
from trama.schema import FORMAT_VERSION, ExportedModel
from trama.validation_structure import validate_structure


def loads(s: str) -> ExportedModel:
    """Parse and validate a JSON string into an ExportedModel.

    Raises:
        trama.errors.JSONError: on JSON syntax errors (line and column populated).
        trama.errors.SchemaError: on Pydantic schema validation failure or
            unrecognised format_version.
        trama.errors.ValidationError: on structural graph validation failure.
    """
    try:
        data = json.loads(s)
    except json.JSONDecodeError as exc:
        raise _JSONError(
            f"JSON parse error at line {exc.lineno}, column {exc.colno}: {exc.msg}",
            line=exc.lineno,
            column=exc.colno,
        ) from exc
    try:
        model = ExportedModel.model_validate(data)
    except pydantic.ValidationError as exc:
        raise SchemaError(str(exc)) from exc
    if model.format_version != FORMAT_VERSION:
        raise SchemaError(
            f"Unsupported format version {model.format_version!r}; this trama installation expects {FORMAT_VERSION!r}"
        )
    validate_structure(model)
    return model


def load(path: str | Path) -> ExportedModel:
    """Read, parse, and validate a .trama.json file.

    Raises:
        trama.errors.JSONError: on OS errors or JSON syntax errors.
        trama.errors.SchemaError: on Pydantic schema validation failure.
        trama.errors.ValidationError: on structural graph validation failure.
    """
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as exc:
        raise _JSONError(str(exc)) from exc
    return loads(text)


def dumps(model: ExportedModel, *, indent: int | None = 2) -> str:
    """Serialize an ExportedModel to a JSON string.

    Field order follows schema declaration order. Default indent is 2.
    indent=None produces compact single-line output (no extra whitespace).
    """
    return model.model_dump_json(indent=indent)


def dump(model: ExportedModel, path: str | Path, *, indent: int | None = 2) -> None:
    """Write an ExportedModel to a .trama.json file."""
    Path(path).write_text(dumps(model, indent=indent), encoding="utf-8")


def json_schema() -> dict[str, Any]:
    """Return the JSON Schema for the ExportedModel format.

    The schema covers format structure (field types, required fields, identifier
    patterns). Registry conformance — op name resolution, parameter types — is
    not expressible in JSON Schema and is validated at load time in Python.

    Typical usage:
        import json, trama
        print(json.dumps(trama.json_schema(), indent=2))
    """
    return ExportedModel.model_json_schema()
