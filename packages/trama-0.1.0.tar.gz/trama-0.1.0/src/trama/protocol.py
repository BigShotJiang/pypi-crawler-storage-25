import re
from collections.abc import Iterable
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, field_validator

from trama.schema import Node, ValueRef

_NODE_ID_RE = re.compile(r"^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*$")


class NodeFragment(BaseModel):
    """The result of a single module's to_node() call.

    root_id is the dotted id of the module's own node.
    nodes contains that node plus all descendants, topologically ordered
    (root node first, followed by descendants in dataflow order).
    """

    root_id: str
    nodes: list[Node]

    @field_validator("root_id")
    @classmethod
    def _check_root_id(cls, v: str) -> str:
        if not _NODE_ID_RE.match(v):
            raise ValueError(
                f"Invalid root_id {v!r}: must be a dotted identifier "
                "(alphanumeric/underscore segments separated by dots)"
            )
        return v


@runtime_checkable
class ExportableOp(Protocol):
    """Protocol for modules that can export themselves to a NodeFragment."""

    def to_node(self, *, node_id: str, input_refs: dict[str, ValueRef]) -> NodeFragment: ...


@runtime_checkable
class ImportableOp(Protocol):
    """Protocol for modules that can reconstruct themselves from a Node."""

    @classmethod
    def from_node(cls, node: Node, *, children: dict[str, Any]) -> Any: ...


def parent_of(node_id: str) -> str | None:
    """Return the dotted prefix of node_id with the last segment removed, or None for root ids.

    Examples:
        parent_of("root")          -> None
        parent_of("root.linear_0") -> "root"
        parent_of("a.b.c")         -> "a.b"
    """
    return node_id.rsplit(".", 1)[0] if "." in node_id else None


def last_segment(node_id: str) -> str:
    """Return the last dotted segment of a node id.

    Used to key the children dict passed to from_node().

    Examples:
        last_segment("root")          -> "root"
        last_segment("root.linear_0") -> "linear_0"
        last_segment("a.b.c")         -> "c"
    """
    return node_id.rsplit(".", 1)[-1]


def compose_fragment(child_fragments: Iterable[tuple[str, NodeFragment]]) -> list[Node]:
    """Merge child NodeFragments into a flat, topologically-ordered node list.

    Use this inside a composite's to_node() to assemble children into the node
    list. Each child's root node appears before its descendants; children appear
    in the order provided.

    Raises ValueError if a fragment's root_id does not match the supplied child_id.

    Example usage inside a composite to_node():
        child_nodes = compose_fragment([
            (f"{node_id}.linear_0", linear_0.to_node(...)),
            (f"{node_id}.relu_1",   relu_1.to_node(...)),
        ])
        return NodeFragment(root_id=node_id, nodes=[composite_node] + child_nodes)

    Args:
        child_fragments: Iterable of (child_id, fragment) pairs.

    Returns:
        Flat list of nodes from all fragments in topological order.
    """
    result: list[Node] = []
    for child_key, fragment in child_fragments:
        if fragment.root_id != child_key:
            raise ValueError(f"Fragment root_id {fragment.root_id!r} does not match child_id {child_key!r}")
        result.extend(fragment.nodes)
    return result
