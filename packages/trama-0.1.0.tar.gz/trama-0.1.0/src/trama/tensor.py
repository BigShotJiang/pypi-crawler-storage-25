import base64
from math import prod

from pydantic import BaseModel, field_validator

KNOWN_DTYPES: frozenset[str] = frozenset(
    {
        "float32",
        "float64",
        "float16",
        "bfloat16",
        "int8",
        "int16",
        "int32",
        "int64",
        "uint8",
        "bool",
    }
)

_DTYPE_ITEMSIZE: dict[str, int] = {
    "float32": 4,
    "float64": 8,
    "float16": 2,
    "bfloat16": 2,
    "int8": 1,
    "int16": 2,
    "int32": 4,
    "int64": 8,
    "uint8": 1,
    "bool": 1,
}


def validate_dtype(dtype: str) -> None:
    """Raise ValueError if dtype is not in the trama-recognized set.

    Recognized dtypes: float32, float64, float16, bfloat16,
    int8, int16, int32, int64, uint8, bool.
    Consumer libraries that need additional dtypes should validate
    them separately before constructing TensorValue.
    """
    if dtype not in KNOWN_DTYPES:
        raise ValueError(f"Unknown dtype {dtype!r}. Recognized dtypes: {sorted(KNOWN_DTYPES)}")


def encode_bytes(raw: bytes) -> str:
    """Base64-encode raw bytes to an ASCII string."""
    return base64.b64encode(raw).decode("ascii")


def decode_bytes(encoded: str) -> bytes:
    """Decode a base64 ASCII string back to raw bytes."""
    return base64.b64decode(encoded)


def byte_size(tv: "TensorValue") -> int:
    """Return the number of bytes the tensor occupies when decoded."""
    itemsize = _DTYPE_ITEMSIZE.get(tv.dtype)
    if itemsize is None:
        raise ValueError(f"Unknown dtype {tv.dtype!r}; cannot compute byte size")
    return prod(tv.shape) * itemsize


class TensorValue(BaseModel):
    """A serialized tensor: dtype, shape, and base64-encoded raw bytes."""

    dtype: str
    shape: list[int]
    data: str  # base64-encoded bytes

    @field_validator("dtype")
    @classmethod
    def _check_dtype(cls, v: str) -> str:
        validate_dtype(v)
        return v
