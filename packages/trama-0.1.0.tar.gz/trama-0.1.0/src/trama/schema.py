import re

from pydantic import BaseModel, field_validator

from trama.tensor import TensorValue

# Dotted identifier: one or more segments of [a-zA-Z0-9_], separated by dots.
_ID_RE = re.compile(r"^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)*$")

# Trama serialization format version.  Bumped only on breaking schema changes,
# independently of the library version.
FORMAT_VERSION = "0.1"


def _valid_id(v: str) -> bool:
    return bool(_ID_RE.match(v))


class ValueRef(BaseModel):
    """Reference to a named output of a node, or to an enclosing composite's input."""

    node: str  # dotted node id, or the sentinel "%input"
    output: str  # name of the output (or declared input when node == "%input")

    @field_validator("node")
    @classmethod
    def _check_node(cls, v: str) -> str:
        if v == "%input":
            return v
        if not _valid_id(v):
            raise ValueError(
                f"Invalid node reference {v!r}: must be a dotted identifier "
                "(alphanumeric/underscore segments) or the sentinel '%input'"
            )
        return v


class ParameterValue(BaseModel):
    """A single parameter value (scalar, tensor, or null) with a learnable flag."""

    # bool must precede int so that Python True/False are not coerced to int.
    value: TensorValue | bool | int | float | str | None
    learnable: bool = False


class Node(BaseModel):
    """One node in the flat exported graph."""

    id: str
    parent: str | None
    op: str
    inputs: dict[str, ValueRef]
    outputs: list[str]
    parameters: dict[str, ParameterValue]
    # None for leaf nodes; dict mapping each declared output name to an internal
    # ValueRef for composite nodes.
    output_bindings: dict[str, ValueRef] | None

    @field_validator("id")
    @classmethod
    def _check_id(cls, v: str) -> str:
        if not _valid_id(v):
            raise ValueError(
                f"Invalid node id {v!r}: must be a dotted identifier "
                "(alphanumeric/underscore segments separated by dots)"
            )
        return v

    @field_validator("parent")
    @classmethod
    def _check_parent(cls, v: str | None) -> str | None:
        if v is not None and not _valid_id(v):
            raise ValueError(f"Invalid parent id {v!r}: must be a dotted identifier")
        return v


class ExportedModel(BaseModel):
    """The top-level exported model: format version, interface, and flat node list."""

    format_version: str
    inputs: list[str]
    outputs: list[ValueRef]
    nodes: list[Node]
