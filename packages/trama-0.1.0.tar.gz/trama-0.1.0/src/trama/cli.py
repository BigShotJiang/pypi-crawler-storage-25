"""Command-line entry points for trama."""

import json
import sys


def schema() -> None:
    """Write the JSON Schema for .trama.json files to stdout."""
    from trama.io import json_schema

    json.dump(json_schema(), sys.stdout, indent=2)
    sys.stdout.write("\n")
