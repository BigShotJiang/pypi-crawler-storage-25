class TramaError(Exception):
    """Base class for all trama exceptions."""


class SchemaError(TramaError):
    """Raised when a document fails Pydantic schema validation."""


class ValidationError(TramaError):
    """Raised when structural graph validation fails."""

    def __init__(self, message: str, *, node_id: str | None = None) -> None:
        super().__init__(message)
        self.node_id = node_id


class RegistryError(TramaError):
    """Raised when an op is absent from the registry or fails shape conformance."""

    def __init__(self, message: str, *, node_id: str | None = None) -> None:
        super().__init__(message)
        self.node_id = node_id


class JSONError(TramaError):
    """Raised on JSON I/O errors: parse failures, file not found, permission denied.

    line and column are populated from json.JSONDecodeError when available;
    they are None for OS-level errors (file not found, permission denied).
    """

    def __init__(
        self,
        message: str,
        *,
        line: int | None = None,
        column: int | None = None,
    ) -> None:
        super().__init__(message)
        self.line = line
        self.column = column
