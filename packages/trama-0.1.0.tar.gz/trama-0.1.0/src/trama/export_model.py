from trama.protocol import ExportableOp
from trama.registry import OpRegistry
from trama.schema import FORMAT_VERSION, ExportedModel, ValueRef
from trama.validation_registry import validate_with_registry
from trama.validation_structure import validate_structure


def export_model(
    module: ExportableOp,
    *,
    inputs: list[str],
    outputs: list[str],
    registry: OpRegistry | None = None,
) -> ExportedModel:
    """Export a module to an ExportedModel.

    Calls module.to_node(node_id="root", ...) then assembles and validates the
    full ExportedModel. Structural validation always runs; registry-aware
    validation runs when a registry is supplied.

    Args:
        module:   The root module to export. Must implement ExportableOp.
        inputs:   Top-level model input names (e.g. ["x"]).
        outputs:  Top-level model output names (e.g. ["y"]).
                  Each maps to the root node's declared output of the same name.
        registry: Optional registry for registry-aware validation.

    Returns:
        A validated ExportedModel ready to serialize.
    """
    input_refs = {name: ValueRef(node="%input", output=name) for name in inputs}
    fragment = module.to_node(node_id="root", input_refs=input_refs)
    top_outputs = [ValueRef(node=fragment.root_id, output=name) for name in outputs]
    model = ExportedModel(
        format_version=FORMAT_VERSION,
        inputs=inputs,
        outputs=top_outputs,
        nodes=fragment.nodes,
    )
    validate_structure(model)
    if registry is not None:
        validate_with_registry(model, registry)
    return model
