from collections import Counter
from collections.abc import Callable
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, model_validator


class ParameterSchema(BaseModel):
    """Declares the type and optionality of one parameter in an op's schema."""

    type: Literal["int", "float", "bool", "string", "tensor"]
    required: bool = True


class OpSpec(BaseModel):
    """Full specification of a registered op."""

    # arbitrary_types_allowed is required because Callable is not a Pydantic type.
    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str
    inputs: list[str]
    outputs: list[str]
    parameters: dict[str, ParameterSchema]
    is_composite: bool
    # Optional; required only if this op needs to support import.
    factory: Callable[..., Any] | None = None

    @model_validator(mode="after")
    def _validate_names(self) -> "OpSpec":
        input_dupes = [n for n, c in Counter(self.inputs).items() if c > 1]
        if input_dupes:
            raise ValueError(f"Op {self.name!r}: duplicate input names: {sorted(input_dupes)}")
        output_dupes = [n for n, c in Counter(self.outputs).items() if c > 1]
        if output_dupes:
            raise ValueError(f"Op {self.name!r}: duplicate output names: {sorted(output_dupes)}")
        collision = set(self.inputs) & set(self.outputs)
        if collision:
            raise ValueError(f"Op {self.name!r}: input and output names collide: {sorted(collision)}")
        return self


class OpRegistry:
    """Registry mapping op names to their OpSpec.

    Not thread-safe. Trama ships with an empty registry; consumers populate it.
    """

    def __init__(self) -> None:
        self._specs: dict[str, OpSpec] = {}

    def register(self, spec: OpSpec) -> None:
        """Register an op. Raises ValueError if the name is already registered."""
        if spec.name in self._specs:
            raise ValueError(f"Op {spec.name!r} is already registered")
        self._specs[spec.name] = spec

    def get(self, name: str) -> OpSpec | None:
        """Return the OpSpec for name, or None if not registered."""
        return self._specs.get(name)

    def __contains__(self, name: str) -> bool:
        """Return True if an op with this name is registered."""
        return name in self._specs

    def names(self) -> list[str]:
        """Return the list of registered op names."""
        return list(self._specs)
