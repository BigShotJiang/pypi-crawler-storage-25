from typing import Any

from trama.errors import RegistryError, SchemaError, ValidationError
from trama.protocol import last_segment
from trama.registry import OpRegistry
from trama.schema import ExportedModel, Node
from trama.validation_registry import validate_with_registry
from trama.validation_structure import validate_structure


def import_model(model: ExportedModel, *, registry: OpRegistry) -> Any:
    """Reconstruct a runtime module from an ExportedModel.

    Runs structural and registry-aware validation before reconstruction.
    Raises RegistryError if any node's op has no factory, or if a factory raises
    an unexpected exception (trama errors from factories propagate unchanged).

    Reconstruction algorithm:
      The flat node list is in topological order (each composite before its
      children). Walking in reverse guarantees every child is built before
      the composite that holds it. Each node's factory receives its already-built
      direct children in a dict keyed by last_segment(child.id), e.g.
      "linear_0" for "root.linear_0".

      The instance for model.nodes[0] is returned. Structural validation
      guarantees that nodes[0] is a root-level node (parent=null), because any
      node with a parent must appear after that parent in the topological list.
    """
    validate_structure(model)
    validate_with_registry(model, registry)

    if not model.nodes:
        raise RegistryError("Cannot import a model with no nodes")

    # Build direct-children map: node id -> list of direct child Nodes.
    children_of: dict[str, list[Node]] = {node.id: [] for node in model.nodes}
    for node in model.nodes:
        if node.parent is not None:
            children_of[node.parent].append(node)

    # Reverse walk: children appear after their parent in the flat list, so
    # reversing ensures leaves are always reconstructed before their composites.
    instances: dict[str, Any] = {}
    for node in reversed(model.nodes):
        spec = registry.get(node.op)
        if spec is None:  # unreachable after validate_with_registry
            raise RegistryError(
                f"Node {node.id!r}: op {node.op!r} not in registry",
                node_id=node.id,
            )

        if spec.factory is None:
            raise RegistryError(
                f"Node {node.id!r}: op {node.op!r} has no factory registered",
                node_id=node.id,
            )

        children = {last_segment(child.id): instances[child.id] for child in children_of[node.id]}

        try:
            instances[node.id] = spec.factory(node, children=children)
        except (RegistryError, ValidationError, SchemaError):
            # Trama errors from a factory propagate unchanged so the original
            # node_id and message are preserved.
            raise
        except Exception as exc:
            raise RegistryError(
                f"Node {node.id!r}: factory for op {node.op!r} raised {type(exc).__name__}: {exc}",
                node_id=node.id,
            ) from exc

    return instances[model.nodes[0].id]
