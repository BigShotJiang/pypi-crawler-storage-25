from trama.errors import RegistryError
from trama.registry import OpRegistry
from trama.schema import ExportedModel
from trama.tensor import TensorValue
from trama.validation_structure import validate_structure

_TYPE_CHECKERS: dict[str, type | tuple[type, ...]] = {
    "bool": bool,
    "int": int,
    "float": (int, float),
    "string": str,
    "tensor": TensorValue,
}


def _check_param_type(node_id: str, name: str, value: object, expected: str) -> None:
    """Raise RegistryError if value does not match the declared parameter type.

    value must not be None; null-value handling is the caller's responsibility.
    """
    checker = _TYPE_CHECKERS[expected]
    # bool is a subclass of int in Python; reject bools for int/float params.
    if expected in ("int", "float") and isinstance(value, bool):
        raise RegistryError(
            f"Node {node_id!r}: parameter {name!r} has type bool but schema expects {expected!r}",
            node_id=node_id,
        )
    if not isinstance(value, checker):
        raise RegistryError(
            f"Node {node_id!r}: parameter {name!r} has type {type(value).__name__!r} but schema expects {expected!r}",
            node_id=node_id,
        )


def validate_with_registry(model: ExportedModel, registry: OpRegistry) -> None:
    """Validate op names, input/output shapes, parameters, and composite consistency.

    Raises RegistryError on first failure, with the offending node key attached.

    Checks (in order per node):
      1. Op name resolves in the registry.
      2. Input names match the op's declared inputs (set equality).
      3. Output names match the op's declared outputs (order-sensitive).
      4. Parameters satisfy the op's schema:
         4a. Required parameters are present.
         4b. No unknown parameters.
         4c. Value types match (None allowed for optional parameters).
      5. output_bindings is non-null iff the op is a composite.
    """
    for node in model.nodes:
        spec = registry.get(node.op)

        # Rule 1: op resolution.
        if spec is None:
            raise RegistryError(
                f"Node {node.id!r}: op {node.op!r} is not in the registry",
                node_id=node.id,
            )

        # Rule 2: input names — set equality.
        node_inputs = set(node.inputs)
        spec_inputs = set(spec.inputs)
        if missing := spec_inputs - node_inputs:
            raise RegistryError(
                f"Node {node.id!r}: missing inputs {sorted(missing)} required by op {node.op!r}",
                node_id=node.id,
            )
        if extra := node_inputs - spec_inputs:
            raise RegistryError(
                f"Node {node.id!r}: unexpected inputs {sorted(extra)} not declared by op {node.op!r}",
                node_id=node.id,
            )

        # Rule 3: output names — order-sensitive equality.
        if node.outputs != spec.outputs:
            raise RegistryError(
                f"Node {node.id!r}: outputs {node.outputs} do not match op {node.op!r} declaration {spec.outputs}",
                node_id=node.id,
            )

        # Rule 4a: required parameters must be present.
        for param_name, param_schema in spec.parameters.items():
            if param_schema.required and param_name not in node.parameters:
                raise RegistryError(
                    f"Node {node.id!r}: missing required parameter {param_name!r}",
                    node_id=node.id,
                )

        # Rule 4b: no unknown parameters.
        for param_name in node.parameters:
            if param_name not in spec.parameters:
                raise RegistryError(
                    f"Node {node.id!r}: unknown parameter {param_name!r} not declared by op {node.op!r}",
                    node_id=node.id,
                )

        # Rule 4c: type conformance for present parameters.
        for param_name, param_value in node.parameters.items():
            param_schema = spec.parameters[param_name]
            value = param_value.value
            if value is None:
                if param_schema.required:
                    raise RegistryError(
                        f"Node {node.id!r}: parameter {param_name!r} is null but required",
                        node_id=node.id,
                    )
                # Optional parameter with null value is allowed.
            else:
                _check_param_type(node.id, param_name, value, param_schema.type)

        # Rule 5: composite consistency.
        if spec.is_composite and node.output_bindings is None:
            raise RegistryError(
                f"Node {node.id!r}: op {node.op!r} is composite but output_bindings is null",
                node_id=node.id,
            )
        if not spec.is_composite and node.output_bindings is not None:
            raise RegistryError(
                f"Node {node.id!r}: op {node.op!r} is not composite but output_bindings is not null",
                node_id=node.id,
            )


def validate(model: ExportedModel, registry: OpRegistry | None = None) -> None:
    """Run structural validation; also registry-aware validation if registry is given."""
    validate_structure(model)
    if registry is not None:
        validate_with_registry(model, registry)
