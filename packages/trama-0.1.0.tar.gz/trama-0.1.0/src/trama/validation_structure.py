from trama.errors import ValidationError
from trama.schema import ExportedModel, Node, ValueRef


def _expected_parent(node_id: str) -> str | None:
    """Return the expected parent: dotted prefix with the last segment removed."""
    return node_id.rsplit(".", 1)[0] if "." in node_id else None


def _enclosing_input_names(
    model: ExportedModel,
    nodes_by_id: dict[str, Node],
    node: Node,
) -> list[str]:
    """Return the input names reachable via %input from inside this node's scope."""
    if node.parent is None:
        return list(model.inputs)
    return list(nodes_by_id[node.parent].inputs.keys())


def _validate_ref(
    *,
    source_id: str,
    label: str,
    ref: ValueRef,
    scope_parent: str | None,
    enclosing_inputs: list[str],
    node_index: dict[str, int],
    nodes_by_id: dict[str, Node],
    current_pos: int,
    check_order: bool,
) -> None:
    """Validate a single ValueRef in terms of scope, order, and output existence."""
    if ref.node == "%input":
        # Rule 5: %input.output must name a declared input of the enclosing scope.
        if ref.output not in enclosing_inputs:
            raise ValidationError(
                f"Node {source_id!r}: {label} references %input.{ref.output} "
                f"which is not declared in the enclosing scope "
                f"(available: {enclosing_inputs})",
                node_id=source_id,
            )
        return

    if ref.node not in node_index:
        raise ValidationError(
            f"Node {source_id!r}: {label} references unknown node {ref.node!r}",
            node_id=source_id,
        )

    # Rule 3b: referenced node must appear earlier in the list.
    if check_order and node_index[ref.node] >= current_pos:
        raise ValidationError(
            f"Node {source_id!r}: {label} references {ref.node!r} which does not appear earlier in the list",
            node_id=source_id,
        )

    # Rule 4: referenced node must be in the same scope (same parent).
    if _expected_parent(ref.node) != scope_parent:
        raise ValidationError(
            f"Node {source_id!r}: {label} references {ref.node!r} "
            f"which is out of scope (scope parent: {scope_parent!r})",
            node_id=source_id,
        )

    # Output name must be declared on the referenced node.
    ref_node = nodes_by_id[ref.node]
    if ref.output not in ref_node.outputs:
        raise ValidationError(
            f"Node {source_id!r}: {label} references output {ref.output!r} "
            f"of {ref.node!r}, but that node declares {ref_node.outputs}",
            node_id=source_id,
        )


def _validate_output_bindings(
    node_index: dict[str, int],
    nodes_by_id: dict[str, Node],
    node: Node,
) -> None:
    """Rule 6: validate a composite node's output_bindings."""
    assert node.output_bindings is not None

    binding_keys = set(node.output_bindings)
    declared = set(node.outputs)

    if missing := declared - binding_keys:
        raise ValidationError(
            f"Composite {node.id!r}: output_bindings missing entries for declared outputs {sorted(missing)}",
            node_id=node.id,
        )
    if extra := binding_keys - declared:
        raise ValidationError(
            f"Composite {node.id!r}: output_bindings has entries {sorted(extra)} not in declared outputs",
            node_id=node.id,
        )

    for output_name, ref in node.output_bindings.items():
        _validate_ref(
            source_id=node.id,
            label=f"output binding {output_name!r}",
            ref=ref,
            # References must be children of this composite.
            scope_parent=node.id,
            # %input refers to this composite's own declared inputs.
            enclosing_inputs=list(node.inputs.keys()),
            node_index=node_index,
            nodes_by_id=nodes_by_id,
            current_pos=0,
            check_order=False,
        )


def _validate_top_level_output(nodes_by_id: dict[str, Node], ref: ValueRef) -> None:
    """Rule 7: validate one entry in ExportedModel.outputs."""
    if ref.node == "%input":
        raise ValidationError("Top-level output uses the %input sentinel, which is not allowed")
    if _expected_parent(ref.node) is not None:
        raise ValidationError(
            f"Top-level output references {ref.node!r}, which is not a root-level node (dotted ids are not allowed)"
        )
    if ref.node not in nodes_by_id:
        raise ValidationError(f"Top-level output references unknown node {ref.node!r}")
    node = nodes_by_id[ref.node]
    if ref.output not in node.outputs:
        raise ValidationError(
            f"Top-level output references output {ref.output!r} of {ref.node!r}, but that node declares {node.outputs}"
        )


def validate_structure(model: ExportedModel) -> None:
    """Validate the structural consistency of an ExportedModel.

    Registry-independent. Raises ValidationError on first failure, with
    the offending node id attached where applicable.

    Checks (in order):
      1. Id uniqueness across the flat node list.
      2. Parent consistency: parent field matches the dotted prefix of the id.
      3. Topological order: parent and dataflow inputs appear earlier in the list.
      4. Scope rules: dataflow inputs reference only nodes in the same scope.
      5. %input resolution: %input.output names a declared input of the enclosing scope.
      6. Output bindings: composite bindings cover exactly the declared outputs
         and reference nodes inside the composite.
      7. Top-level outputs: reference root-level nodes and declared output names.
    """
    # Pass 1: collect node ids — rule 1 (uniqueness).
    node_index: dict[str, int] = {}
    nodes_by_id: dict[str, Node] = {}
    for i, node in enumerate(model.nodes):
        if node.id in node_index:
            raise ValidationError(
                f"Duplicate node id {node.id!r}",
                node_id=node.id,
            )
        node_index[node.id] = i
        nodes_by_id[node.id] = node

    # Pass 2: per-node structural rules.
    for node in model.nodes:
        pos = node_index[node.id]

        # Rule 2: parent field must equal the dotted prefix of the id.
        expected = _expected_parent(node.id)
        if node.parent != expected:
            raise ValidationError(
                f"Node {node.id!r}: parent {node.parent!r} does not match expected {expected!r} (derived from node id)",
                node_id=node.id,
            )
        if node.parent is not None and node.parent not in nodes_by_id:
            raise ValidationError(
                f"Node {node.id!r}: parent {node.parent!r} does not exist",
                node_id=node.id,
            )

        # Rule 3a: structural parent must appear before the child.
        if node.parent is not None and node_index[node.parent] >= pos:
            raise ValidationError(
                f"Node {node.id!r}: parent {node.parent!r} does not appear before it in the list",
                node_id=node.id,
            )

        # Rules 3b + 4 + 5: dataflow inputs.
        enclosing = _enclosing_input_names(model, nodes_by_id, node)
        for port, ref in node.inputs.items():
            _validate_ref(
                source_id=node.id,
                label=f"input {port!r}",
                ref=ref,
                scope_parent=node.parent,
                enclosing_inputs=enclosing,
                node_index=node_index,
                nodes_by_id=nodes_by_id,
                current_pos=pos,
                check_order=True,
            )

        # Rule 6: output bindings (composites only).
        if node.output_bindings is not None:
            _validate_output_bindings(node_index, nodes_by_id, node)

    # Rule 7: top-level model outputs.
    for ref in model.outputs:
        _validate_top_level_output(nodes_by_id, ref)
