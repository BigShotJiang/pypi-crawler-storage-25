"""Shared state, SoC name lists, and utility helpers for all command modules."""

from __future__ import annotations

import difflib
from pathlib import Path
from typing import Optional

import click

from socc.rules import RuleRegistry
from socc.engine import Checker
from socc.rules.rockchip import register_rockchip_rules
from socc.rules.allwinner import register_allwinner_rules, ALLWINNER_SOC_NAMES
from socc.rules.amlogic import register_amlogic_rules, AMLOGIC_SOC_NAMES
from socc.rules.qualcomm import register_qualcomm_rules, QUALCOMM_SOC_NAMES
from socc.rules.nxp import register_all_nxp_rules, NXP_SOC_NAMES
from socc.rules.common import register_common_rules
from socc.parser import build_sample_model, parse_dts_file
from socc.config import load_config, filter_by_severity, SAMPLE_CONFIG

# ── SoC name lists ─────────────────────────────────────────────────────────

ROCKCHIP_SOCS = ["rk3588", "rk3576", "rk3568", "rk3566", "rk3399", "rk3328", "rk3528", "rk3308"]
ALLWINNER_SOCS = sorted(ALLWINNER_SOC_NAMES)
AMLOGIC_SOCS = sorted(AMLOGIC_SOC_NAMES)
QUALCOMM_SOCS = sorted(QUALCOMM_SOC_NAMES)
NXP_SOCS = sorted(NXP_SOC_NAMES)
ALL_SOC_CHOICES = ROCKCHIP_SOCS + ALLWINNER_SOCS + AMLOGIC_SOCS + QUALCOMM_SOCS + NXP_SOCS + ["auto"]

# Convenience re-exports used in command modules
__all__ = [
    "ROCKCHIP_SOCS", "ALLWINNER_SOCS", "AMLOGIC_SOCS", "QUALCOMM_SOCS", "NXP_SOCS",
    "ALL_SOC_CHOICES", "FuzzySoCType", "build_registry", "auto_detect_soc",
    "severity_tag", "echo", "load_config", "filter_by_severity", "SAMPLE_CONFIG",
    "build_sample_model", "parse_dts_file", "parse_dts_cached",
    "Checker", "Path", "Optional", "click",
]


# ── Fuzzy SoC name parameter type ────────────────────────────────────────────

class FuzzySoCType(click.ParamType):
    """Click parameter type that accepts SoC names with fuzzy-match suggestions.

    If the user types an unrecognised name, the error message lists the closest
    matches (via :func:`difflib.get_close_matches`) instead of dumping the full
    ~50-item list of valid choices.
    """

    name = "SOC"

    def __init__(self, choices: list):
        self._choices = choices

    def convert(self, value, param, ctx):
        if value in self._choices:
            return value
        # Case-insensitive check
        low = value.lower()
        for c in self._choices:
            if c.lower() == low:
                return c
        # Fuzzy suggestions
        suggestions = difflib.get_close_matches(low, self._choices, n=4, cutoff=0.5)
        if suggestions:
            hint = "  Did you mean: " + ", ".join(
                click.style(s, fg="yellow", bold=True) for s in suggestions
            ) + "?"
        else:
            hint = f"  Run 'socc check --help' to see all supported SoC names."
        self.fail(
            f"Unknown SoC {value!r}.\n{hint}",
            param,
            ctx,
        )


def build_registry(extra_rules_dirs: Optional[list] = None) -> RuleRegistry:
    """Build and return a fully populated rule registry (all vendors).

    Args:
        extra_rules_dirs: Optional list of directory paths.  Each directory is
            scanned for ``*.py`` files; every module found is imported and its
            ``register(registry)`` function (if present) is called.  This is the
            plugin hook for custom / company-internal rule sets.
    """
    registry = RuleRegistry()
    register_common_rules(registry)
    for soc in ROCKCHIP_SOCS:
        register_rockchip_rules(registry, soc)
    for soc in ALLWINNER_SOCS:
        register_allwinner_rules(registry, soc)
    for soc in AMLOGIC_SOCS:
        register_amlogic_rules(registry, soc)
    for soc in QUALCOMM_SOCS:
        register_qualcomm_rules(registry, soc)
    for soc in NXP_SOCS:
        register_all_nxp_rules(registry, soc)

    # ── load plugin rules from extra directories ──────────────────────────────
    if extra_rules_dirs:
        import importlib.util
        import sys as _sys
        for raw_dir in extra_rules_dirs:
            rules_path = Path(raw_dir)
            if not rules_path.is_dir():
                click.echo(
                    click.style(f"Warning: --rules-dir {raw_dir!r} is not a directory.",
                                fg="yellow"),
                    err=True,
                )
                continue
            for py_file in sorted(rules_path.glob("*.py")):
                mod_name = f"_socc_plugin_{py_file.stem}"
                spec = importlib.util.spec_from_file_location(mod_name, py_file)
                if spec is None or spec.loader is None:
                    continue
                mod = importlib.util.module_from_spec(spec)
                _sys.modules[mod_name] = mod
                try:
                    spec.loader.exec_module(mod)  # type: ignore[union-attr]
                except Exception as e:
                    click.echo(
                        click.style(f"Warning: could not load plugin {py_file}: {e}",
                                    fg="yellow"),
                        err=True,
                    )
                    continue
                if hasattr(mod, "register"):
                    try:
                        mod.register(registry)
                    except Exception as e:
                        click.echo(
                            click.style(
                                f"Warning: plugin {py_file}.register() failed: {e}",
                                fg="yellow"),
                            err=True,
                        )
    return registry


def auto_detect_soc(filename: str) -> str:
    """Infer SoC family from a DTS filename (lower-cased)."""
    fn = filename.lower()

    for chip in ["rk3588", "rk3576", "rk3568", "rk3566", "rk3399", "rk3328"]:
        if chip in fn:
            return chip

    if "sun50i-h616" in fn or "h616" in fn or "h618" in fn:
        return "sun50i-h616"
    if "sun50i-h6" in fn or "h6-" in fn or "-h6." in fn:
        return "sun50i-h6"
    if "sun50i-a64" in fn or "a64" in fn:
        return "sun50i-a64"
    if "sun8i-h3" in fn or "h3-" in fn or "-h3." in fn:
        return "sun8i-h3"
    if "sun8i-h2" in fn or "h2-plus" in fn:
        return "sun8i-h2-plus"
    if "sun50i-h5" in fn or "h5-" in fn:
        return "sun50i-h5"
    if "sun20i-d1" in fn or "d1-" in fn:
        return "sun20i-d1"
    if "sun55i-a527" in fn or "a527" in fn or "t527" in fn:
        return "sun55i-a527"
    if "sun55i-a733" in fn or "a733" in fn:
        return "sun55i-a733"
    if "sun55i-a523" in fn or "a523" in fn:
        return "sun55i-a523"

    for chip in ["sdm845", "sm8250", "sm8350", "sm8450", "sc7180", "sc7280", "sc8280xp", "qcs6490", "qcs9100", "msm8998"]:
        if chip in fn:
            return chip

    if "gxbb" in fn or "s905." in fn or "s905-" in fn:
        return "meson-gxbb"
    if "gxl" in fn or "s905x" in fn or "s905d" in fn or "s905w" in fn:
        return "meson-gxl"
    if "gxm" in fn or "s912" in fn:
        return "meson-gxm"
    if "g12b" in fn or "s922x" in fn or ("a311d2" not in fn and "a311d" in fn):
        return "meson-g12b"
    if "g12a" in fn or "s905x2" in fn or "s905d2" in fn:
        return "meson-g12a"
    if "sm1" in fn or "s905x3" in fn or "s905d3" in fn or "odroid-c4" in fn:
        return "meson-sm1"
    if "axg" in fn or "a113d" in fn or "a113x" in fn:
        return "meson-axg"
    if "t7" in fn or "a311d2" in fn:
        return "amlogic-t7"

    for chip in ["rk3528", "rk3308"]:
        if chip in fn:
            return chip

    for chip in ["imx8mp", "imx8mq", "imx8mm", "imx8mn", "imx8ulp", "imx93", "imx95"]:
        if chip in fn:
            return chip
    if "imx8m" in fn:
        return "imx8mp"

    return "unknown"


def severity_tag(severity: str, color: Optional[bool]) -> str:
    """Return a colored severity tag for terminal output."""
    tags = {
        "error":   ("[E]", "red",    True),
        "warning": ("[W]", "yellow", False),
        "info":    ("[I]", "cyan",   False),
    }
    label, fg, bold = tags.get(severity, ("[?]", "white", False))
    if color is False:
        return label
    return click.style(label, fg=fg, bold=bold)


def echo(msg: str, color: Optional[bool] = None) -> None:
    """Print a status message."""
    click.echo(msg)


# ── Cached DTS parsing ───────────────────────────────────────────────────────

def parse_dts_cached(dts_file: str, soc_name: str):
    """Parse *dts_file* and cache the result.  Returns the :class:`~socc.model.SoC` model.

    On a cache hit the parse step is skipped entirely; on a miss the result is
    serialised to ``~/.cache/socc/`` for future calls.  Cache misses are
    transparent — failures never propagate to the caller.
    """
    from socc.cache import get_cached_model, set_cached_model
    model = get_cached_model(dts_file, soc_name)
    if model is not None:
        return model
    model = parse_dts_file(dts_file, soc_name)
    set_cached_model(dts_file, soc_name, model)
    return model


# ── Rule-code fuzzy matcher ──────────────────────────────────────────────────

def suggest_rule_codes(bad_code: str, registry) -> str:
    """Return a human-readable 'did you mean' string for an unknown rule code."""
    known = [r.code for r in registry.list_all_rules()]
    matches = difflib.get_close_matches(bad_code.upper(), known, n=3, cutoff=0.5)
    if matches:
        return "Did you mean: " + ", ".join(matches) + "?"
    return f"Run 'socc rules' to see all valid rule codes."
