"""Code Security API"""


class CodeReviewAPI:
    """
    Code security scanning operations.

    Usage:
        client = Aribot(api_key)
        scan = client.code_review.create_scan("https://github.com/org/repo")
    """

    def __init__(self, http):
        self._http = http

    def create_scan(self, repository_url, branch='main', scan_types=None, **kwargs):
        """Create a new code security scan."""
        data = {'repository_url': repository_url, 'branch': branch}
        if scan_types:
            data['scan_types'] = scan_types
        data.update(kwargs)
        return self._http.post('/v2/code-review/scans/', json=data)

    def list_scans(self, **params):
        """List code security scans."""
        return self._http.get('/v2/code-review/scans/', params=params)

    def get_scan(self, scan_id):
        """Get scan details."""
        return self._http.get(f'/v2/code-review/scans/{scan_id}/')

    def get_findings(self, scan_id, **params):
        """Get findings for a scan."""
        return self._http.get(f'/v2/code-review/scans/{scan_id}/findings/', params=params)

    def remediate_finding(self, scan_id, finding_id, **kwargs):
        """Auto-remediate a finding."""
        return self._http.post(f'/v2/code-review/scans/{scan_id}/findings/{finding_id}/remediate/', json=kwargs)

    def get_summary(self, scan_id):
        """Get scan summary."""
        return self._http.get(f'/v2/code-review/scans/{scan_id}/summary/')

    def rescan(self, scan_id):
        """Trigger a rescan."""
        return self._http.post(f'/v2/code-review/scans/{scan_id}/rescan/')
