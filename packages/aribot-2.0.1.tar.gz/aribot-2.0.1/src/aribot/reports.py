"""Reports Export & Sharing API"""


class ReportsAPI:
    """
    Report generation, export, and sharing operations.

    Usage:
        client = Aribot(api_key)
        report = client.reports.create(diagram_id, report_type="comprehensive")
    """

    def __init__(self, http):
        self._http = http

    def list(self, **params):
        """List all reports."""
        return self._http.get('/v2/threat-modeling/reports/', params=params)

    def create(self, diagram_id, report_type='comprehensive', **kwargs):
        """Create a new report."""
        data = {'diagram_id': diagram_id, 'report_type': report_type}
        data.update(kwargs)
        return self._http.post('/v2/threat-modeling/reports/', json=data)

    def get(self, report_id):
        """Get report details."""
        return self._http.get(f'/v2/threat-modeling/reports/{report_id}/')

    def export(self, report_id, format='pdf'):
        """Export report as PDF, CSV, or JSON."""
        return self._http.get(f'/v2/threat-modeling/reports/{report_id}/export/', params={'format': format})

    def share(self, report_id, **kwargs):
        """Generate a shareable link for a report."""
        return self._http.post(f'/v2/threat-modeling/reports/{report_id}/share/', json=kwargs)

    def get_shared(self, share_token):
        """Access a shared report by token."""
        return self._http.get(f'/v2/threat-modeling/reports/shared/{share_token}/')

    def email(self, report_id, recipients, **kwargs):
        """Email a report to recipients."""
        data = {'recipients': recipients}
        data.update(kwargs)
        return self._http.post(f'/v2/threat-modeling/reports/{report_id}/email/', json=data)

    def get_status(self, report_id):
        """Get report generation status."""
        return self._http.get(f'/v2/threat-modeling/reports/{report_id}/status/')

    def schedule(self, diagram_id, schedule, **kwargs):
        """Schedule recurring report generation."""
        data = {'diagram_id': diagram_id, 'schedule': schedule}
        data.update(kwargs)
        return self._http.post('/v2/threat-modeling/reports/schedule/', json=data)

    def analytics(self):
        """Get report analytics."""
        return self._http.get('/v2/threat-modeling/reports/analytics/')

    def export_diagram(self, diagram_id, format='pdf'):
        """Export a diagram directly."""
        return self._http.get(f'/v2/threat-modeling/diagrams/{diagram_id}/export/{format}/')
