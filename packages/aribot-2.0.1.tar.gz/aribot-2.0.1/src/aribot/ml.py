"""ML & Analytics API"""


class MLAPI:
    """
    Machine learning and analytics operations.

    Usage:
        client = Aribot(api_key)
        predictions = client.ml.get_predictions(diagram_id)
    """

    def __init__(self, http):
        self._http = http

    def get_predictions(self, diagram_id):
        """Get ML threat predictions for a diagram."""
        return self._http.get(f'/v2/threat-modeling/diagrams/{diagram_id}/ml-predictions/')

    def analyze_patterns(self, data, **kwargs):
        """Analyze threat patterns with ML."""
        return self._http.post('/v2/threat-modeling/ml/analyze-patterns/', json=data)

    def get_model_performance(self):
        """Get ML model performance metrics."""
        return self._http.get('/v2/threat-modeling/ml/model-performance/')

    def train_models(self, **kwargs):
        """Trigger ML model training."""
        return self._http.post('/v2/threat-modeling/ml/train-models/', json=kwargs)

    def ensemble_predict(self, data, **kwargs):
        """Run ML ensemble predictions."""
        return self._http.post('/v2/threat-modeling/ml/ensemble-predict/', json=data)
