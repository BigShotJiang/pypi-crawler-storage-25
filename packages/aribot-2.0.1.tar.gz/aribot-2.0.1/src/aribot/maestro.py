"""MAESTRO AI/ML 7-Layer Threat Analysis API"""


class MAESTROAPI:
    """
    MAESTRO 7-layer AI/ML threat analysis operations.

    Usage:
        client = Aribot(api_key)
        result = client.maestro.process(diagram_id)
    """

    def __init__(self, http):
        self._http = http

    def process(self, diagram_id, **kwargs):
        """Run MAESTRO 7-layer threat analysis on a diagram."""
        return self._http.post(f'/v2/threat-modeling/diagrams/{diagram_id}/process-maestro/', json=kwargs)

    def enrich_threats(self, diagram_id, **kwargs):
        """Enrich diagram threats with AI-powered analysis."""
        return self._http.post(f'/v2/threat-modeling/diagrams/{diagram_id}/enrich-threats/', json=kwargs)

    def get_risk_scores(self, diagram_id):
        """Calculate risk scores for a diagram."""
        return self._http.get(f'/v2/threat-modeling/diagrams/{diagram_id}/risk-scores/')

    def generate_security_requirements(self, diagram_id, **kwargs):
        """Generate security requirements for a diagram."""
        return self._http.post(f'/v2/threat-modeling/diagrams/{diagram_id}/generate-security-requirements/', json=kwargs)

    def refresh_priorities(self, diagram_id, **kwargs):
        """Refresh threat priorities using AI."""
        return self._http.post(f'/v2/threat-modeling/diagrams/{diagram_id}/refresh-priorities/', json=kwargs)

    def estimate_refresh_cost(self, diagram_id):
        """Estimate cost of priority refresh."""
        return self._http.get(f'/v2/threat-modeling/diagrams/{diagram_id}/refresh-priorities/estimate/')
