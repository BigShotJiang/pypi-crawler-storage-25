"""Multi-Agent AI Workflows API"""


class MultiAgentAPI:
    """
    Multi-agent AI workflow operations.

    Usage:
        client = Aribot(api_key)
        result = client.multi_agent.execute_workflow("threat_analysis", context)
    """

    def __init__(self, http):
        self._http = http

    def execute_workflow(self, workflow_type, context, **kwargs):
        """Execute a multi-agent AI workflow."""
        data = {'workflow_type': workflow_type, 'context': context}
        data.update(kwargs)
        return self._http.post('/v2/threat-modeling/v2/multi-agent/workflow/', json=data)

    def ai_assistant(self, message, context=None, **kwargs):
        """Chat with the AI security assistant."""
        data = {'message': message}
        if context:
            data['context'] = context
        data.update(kwargs)
        return self._http.post('/v2/threat-modeling/ai/assistant/', json=data)

    def generate_architecture(self, description, **kwargs):
        """Generate architecture from natural language description."""
        data = {'description': description}
        data.update(kwargs)
        return self._http.post('/v2/threat-modeling/ai/generate-architecture/', json=data)

    def analyze_security(self, diagram_id=None, **kwargs):
        """Analyze security posture with AI."""
        data = kwargs
        if diagram_id:
            data['diagram_id'] = diagram_id
        return self._http.post('/v2/threat-modeling/ai/analyze-security/', json=data)

    def voice_to_architecture(self, audio_data, **kwargs):
        """Generate architecture from voice recording."""
        return self._http.post('/v2/threat-modeling/ai/voice-to-architecture/', data=audio_data, **kwargs)
