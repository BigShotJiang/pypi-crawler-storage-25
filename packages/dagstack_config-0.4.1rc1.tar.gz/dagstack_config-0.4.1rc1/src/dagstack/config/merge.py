"""Deep merge для ConfigTree.

Per spec ADR-0001 §3: maps мерджатся глубоко; sequences (lists) **заменяются
атомарно**, не конкатенируются. Чтобы изменить массив — override-файл содержит
массив целиком.

Resolution order = list order в `loadFrom([sources])`: lowest priority first.

Все функции возвращают **новые** структуры — input'ы не мутируются, nested
containers не shared с input'ами (safe для дальнейшей модификации вызывающим).
"""

from __future__ import annotations

from typing import Any

# ConfigTree — nested map / sequence / scalar. Type alias для документации;
# на runtime-уровне это `dict[str, Any]` / `list[Any]` / `str|int|float|bool|None`.
ConfigTree = dict[str, Any]


def deep_merge(base: ConfigTree, override: ConfigTree) -> ConfigTree:
    """Recursively merge `override` в `base`, возвращая новый dict.

    Правила:
    - Keys из override, отсутствующие в base — добавляются.
    - Keys из base, отсутствующие в override — сохраняются.
    - Keys в обоих: если оба значения — dict, рекурсивный merge; иначе override wins.
    - Lists **replaced atomically** (не конкатенируются, не merge'атся поэлементно).

    Все nested containers — deep-copy, не share references с аргументами.
    """
    result: ConfigTree = {}
    for key, value in base.items():
        result[key] = _deep_copy(value)
    for key, override_value in override.items():
        base_value = result.get(key)
        if isinstance(base_value, dict) and isinstance(override_value, dict):
            result[key] = deep_merge(base_value, override_value)
        else:
            result[key] = _deep_copy(override_value)
    return result


def deep_merge_all(trees: list[ConfigTree]) -> ConfigTree:
    """Merge множества trees в порядке приоритета (lowest first).

    Для empty list возвращает пустой dict. Singleton list — возвращает deep copy.
    """
    if not trees:
        return {}
    result = deep_merge({}, trees[0])
    for next_tree in trees[1:]:
        result = deep_merge(result, next_tree)
    return result


def _deep_copy(value: Any) -> Any:
    """Recursively copy nested containers (dict/list). Scalars — as-is."""
    if isinstance(value, dict):
        return {k: _deep_copy(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_deep_copy(item) for item in value]
    return value
