"""Internal constants, shared between modules.

Отдельный модуль — чтобы не завязывать `canonical_json.py` /
`sources.py` / `config.py` на цикл импортов и не дублировать
значения. Public API не экспортируется; имена с `_`-префиксом.
"""

from __future__ import annotations

# i-JSON safe integer range per RFC 7493 §2.2 / spec v2.1 §4.3 +
# `_meta/coercion.yaml`.
#
# Whole-number float в этом диапазоне представим как int без потерь
# и используется в трёх местах:
#   - `get_int` accept branch для whole-number float
#   - canonical JSON emission: whole-number float → integer form
#   - `_normalize_numbers`: YAML/JSON load-time нормализация
#     whole-number float → int.
IJSON_SAFE_MAX = 2**53 - 1  # 9_007_199_254_740_991
