"""dagstack.config — Python binding for dagstack/config-spec.

Public API (Phase C):

    from dagstack.config import (
        Config,
        ConfigError,
        ConfigErrorReason,
        ConfigSource,
        Subscription,
        YamlFileSource,
        JsonFileSource,
        InMemorySource,
    )

Usage:

    config = Config.load("app-config.yaml")
    host = config.get_string("database.host")
    pool_size = config.get_int("database.pool_size", default=10)

    class DatabaseConfig(BaseModel):
        host: str
        password: str

    db = config.get_section("database", DatabaseConfig)

Phase 1 не поддерживает runtime watch — `on_change` / `on_section_change`
регистрируют subscription но callback никогда не сработает (warning в
`dagstack.config.internal` logger). Явное `config.reload()` — no-op.
"""

from dagstack.config._version import __version__
from dagstack.config.config import Config
from dagstack.config.errors import ConfigError, ConfigErrorReason
from dagstack.config.sources import (
    ConfigSource,
    InMemorySource,
    JsonFileSource,
    YamlFileSource,
)
from dagstack.config.subscription import Subscription

__all__ = [
    "Config",
    "ConfigError",
    "ConfigErrorReason",
    "ConfigSource",
    "InMemorySource",
    "JsonFileSource",
    "Subscription",
    "YamlFileSource",
    "__version__",
]
