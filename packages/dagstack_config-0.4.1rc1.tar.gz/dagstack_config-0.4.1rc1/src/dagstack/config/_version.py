"""Single-source version для dagstack-config.

Hatch читает `__version__` отсюда (см. pyproject.toml `[tool.hatch.version]`).
Tag `vX.Y.Z` должен совпадать с этим значением — CI publish-workflow валидирует.
"""

__version__ = "0.4.1rc1"
