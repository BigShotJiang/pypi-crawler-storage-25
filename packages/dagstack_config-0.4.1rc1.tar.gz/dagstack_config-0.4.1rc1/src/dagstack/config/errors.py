"""ConfigError + ConfigErrorReason enum.

Per spec ADR-0001 §4.5: структурные поля ошибки фиксированы контрактом;
per-language realization идиоматично. Python idiom — exception type.

Обязательные поля: `path` (dot-notation), `reason` (enum), `details` (str).
Опционально: `source_id` (какой ConfigSource raised, если applicable).
"""

from __future__ import annotations

from enum import StrEnum


class ConfigErrorReason(StrEnum):
    """Fixed enum values per spec ADR-0001 §4.5 / `_meta/error_reasons.yaml`.

    Source-of-truth — spec repo (`spec/_meta/error_reasons.yaml`, планируется
    emit в `_generated/` в Phase D). Пока hand-coded; emitter добавит CI gate.
    """

    MISSING = "missing"
    """Key отсутствует и default не задан."""

    TYPE_MISMATCH = "type_mismatch"
    """Значение не coerce'ится в запрошенный тип."""

    ENV_UNRESOLVED = "env_unresolved"
    """${ENV_VAR} без default, env var не установлена."""

    VALIDATION_FAILED = "validation_failed"
    """Pydantic (или другая) schema validation failed для get_section."""

    PARSE_ERROR = "parse_error"
    """YAML/JSON parse error при загрузке source."""

    SOURCE_UNAVAILABLE = "source_unavailable"
    """ConfigSource не доступен (файл отсутствует, etcd unreachable, и т.д.)."""

    RELOAD_REJECTED = "reload_rejected"
    """Reconfigure candidate отклонён на validation phase (§8.4 spec)."""


class ConfigError(Exception):
    """Structured config error со спецификационными полями.

    Поля:
        path: Dot-notation путь в config-документе (e.g. "database.host").
            Для parse errors на верхнем уровне — пустая строка.
        reason: ConfigErrorReason enum value.
        details: Human-readable message с контекстом.
        source_id: Какой ConfigSource raised (если applicable).

    Использование:
        >>> raise ConfigError(
        ...     path="database.password",
        ...     reason=ConfigErrorReason.MISSING,
        ...     details="Required key not found in merged config",
        ... )
    """

    __slots__ = ("details", "path", "reason", "source_id")

    path: str
    reason: ConfigErrorReason
    details: str
    source_id: str | None

    def __init__(
        self,
        *,
        path: str,
        reason: ConfigErrorReason,
        details: str,
        source_id: str | None = None,
    ) -> None:
        self.path = path
        self.reason = reason
        self.details = details
        self.source_id = source_id
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        parts = [f"{self.reason.value} at {self.path!r}"] if self.path else [self.reason.value]
        parts.append(self.details)
        if self.source_id is not None:
            parts.append(f"source={self.source_id!r}")
        return ": ".join(parts)

    def __repr__(self) -> str:
        return (
            f"ConfigError(path={self.path!r}, reason={self.reason.value!r}, "
            f"details={self.details!r}, source_id={self.source_id!r})"
        )
