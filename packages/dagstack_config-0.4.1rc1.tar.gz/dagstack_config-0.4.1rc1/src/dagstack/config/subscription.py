"""Subscription handle для config change callbacks.

Per spec ADR-0001 §7.2:
- `Subscription { unsubscribe(), active, inactive_reason, path }`.
- В Phase 1 `active=false` для всех subscriptions — ни один source не
  поддерживает `watch()`, значит callback никогда не срабатывает.
- Loader обязан эмитить `subscription_without_watch` warning в diagnostic
  channel при регистрации подписки без watch-capable source.

Diagnostic channel — named logger `dagstack.config.internal` (symmetry с
logger-spec §7.4 isolation requirement — но logger-spec пока не реализован,
используем стандартный Python `logging`).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

_INTERNAL_LOGGER = logging.getLogger("dagstack.config.internal")


class Subscription:
    """Subscription handle, возвращаемый `on_change` / `on_section_change`.

    Contract:
    - `unsubscribe()` идемпотентен: повторные вызовы — no-op.
    - После `unsubscribe()` callback гарантированно не вызовется.
    - `active=False` signals, что callback НЕ сработает — либо no watch-capable
      source, либо path scope не покрыт active sources. Это не ошибка, а
      honest contract signal (см. `inactive_reason`).
    """

    __slots__ = ("_unsubscribe_impl", "_unsubscribed", "active", "inactive_reason", "path")

    path: str
    active: bool
    inactive_reason: str | None
    _unsubscribe_impl: Callable[[], None]
    _unsubscribed: bool

    def __init__(
        self,
        *,
        path: str,
        active: bool,
        inactive_reason: str | None = None,
        unsubscribe: Callable[[], None] | None = None,
    ) -> None:
        self.path = path
        self.active = active
        self.inactive_reason = inactive_reason
        self._unsubscribe_impl = unsubscribe if unsubscribe is not None else _noop
        self._unsubscribed = False

    def unsubscribe(self) -> None:
        """Cancel subscription. Idempotent."""
        if self._unsubscribed:
            return
        self._unsubscribed = True
        self._unsubscribe_impl()

    def __repr__(self) -> str:
        return (
            f"Subscription(path={self.path!r}, active={self.active}, "
            f"inactive_reason={self.inactive_reason!r})"
        )


def _noop() -> None:
    """Default unsubscribe для inactive subscriptions."""


def emit_subscription_without_watch_warning(
    *,
    path: str,
    source_ids: list[str],
) -> None:
    """Emit structured warning при регистрации subscription без watch-capable source.

    Per spec §7.2: warning code `subscription_without_watch`, payload — path
    и зарегистрированные source_ids (без watch capability).
    """
    _INTERNAL_LOGGER.warning(
        "subscription_without_watch: path=%r source_ids=%r — callback will never fire "
        "(no watch-capable source registered)",
        path,
        source_ids,
    )
