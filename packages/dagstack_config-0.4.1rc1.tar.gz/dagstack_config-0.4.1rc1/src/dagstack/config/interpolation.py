"""Env interpolation для YAML-значений.

Per spec ADR-0001 §2:
    ${ENV_VAR}            → value of ENV_VAR, error if not set
    ${ENV_VAR:-default}   → value of ENV_VAR, or literal "default" if not set or empty

Semantics:
- Interpolated value всегда — строка. Type coercion — позже, при getString/getInt.
- Escape literal `$`: `$$` → `$`.
- Неразрешённый `${VAR}` без default → `ConfigError(reason=ENV_UNRESOLVED)`.
- Default value — **literal string**; nested `${...}` в defaults НЕ интерполируются (spec §2).
  `${FOO:-${BAR}}` → default=`"${BAR"` (до первого `}`), остаток `}` как literal.

Parser — state machine (regex-based подход ломается на escape-edge-cases типа `$${A}`,
где `$$` escape'ит dollar, но `{A}` не становится interpolation — compose-style
semantics).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from dagstack.config.errors import ConfigError, ConfigErrorReason

if TYPE_CHECKING:
    from collections.abc import Mapping

# Public regex для has_interpolation() — approximate detector, не полный parser.
_DETECT_RE = re.compile(r"\$\{[^}]*\}")


def interpolate(
    text: str,
    env: Mapping[str, str],
    *,
    path: str = "",
    source_id: str | None = None,
) -> str:
    """Substitute `${VAR}` / `${VAR:-default}` в тексте по значениям из env.

    Args:
        text: Raw-строка (обычно содержимое YAML/JSON файла).
        env: Mapping env-vars (обычно `os.environ`, но может быть mock).
        path: Optional dot-notation путь для error-reporting.
        source_id: Optional source id для error-reporting.

    Returns:
        Строка с замещёнными placeholders.

    Raises:
        ConfigError: если встречена `${VAR}` без default и VAR отсутствует в env.
    """
    result: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch == "$" and i + 1 < n:
            nxt = text[i + 1]
            if nxt == "$":
                # Escape: `$$` → literal `$`. Consume both.
                result.append("$")
                i += 2
                continue
            if nxt == "{":
                close = text.find("}", i + 2)
                if close == -1:
                    # No closing brace — treat `${` as literal. Soft-fail на некорректном
                    # input (e.g., нестандартное использование `${` в тексте).
                    result.append(ch)
                    i += 1
                    continue
                expr = text[i + 2 : close]
                result.append(_resolve_expr(expr, env, path=path, source_id=source_id))
                i = close + 1
                continue
        # Literal character.
        result.append(ch)
        i += 1
    return "".join(result)


def _resolve_expr(
    expr: str,
    env: Mapping[str, str],
    *,
    path: str,
    source_id: str | None,
) -> str:
    """Resolve body `${...}`: `VAR` или `VAR:-default`."""
    if ":-" in expr:
        var_name, default = expr.split(":-", 1)
        var_name = var_name.strip()
        value = env.get(var_name)
        # Empty string trigger'ит default (per spec §2: "not set or empty").
        return value if value else default
    var_name = expr.strip()
    value = env.get(var_name)
    if value is None:
        raise ConfigError(
            path=path,
            reason=ConfigErrorReason.ENV_UNRESOLVED,
            details=f"env variable {var_name!r} is not set and no default provided",
            source_id=source_id,
        )
    return value


def has_interpolation(text: str) -> bool:
    """Быстрый чекер: содержит ли строка `${...}` placeholder'ы.

    Не валидирует syntax, просто match паттерна. Используется для
    optimization (пропустить parser pass если no placeholders).
    """
    return _DETECT_RE.search(text) is not None
