"""ConfigSource abstraction + Phase 1 implementations.

Per spec ADR-0001 §8.1: source контракт — `id`, `load()`, `interpolate` hint,
optional `watch()` (Phase 2+) и `close()`. Phase 1 реализует три source:
`YamlFileSource`, `JsonFileSource`, `InMemorySource`.

Sync API только в Phase 1 — async-idiom откладывается до первого нагруженного
watch-scenario (OTLP / etcd). Per spec §4 "Sync vs async — binding decides".
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

import yaml

from dagstack.config._constants import IJSON_SAFE_MAX
from dagstack.config.errors import ConfigError, ConfigErrorReason
from dagstack.config.interpolation import interpolate


class Yaml12StrictLoader(yaml.SafeLoader):
    """PyYAML loader, приведённый к YAML 1.2 strict mode.

    ADR-0001 v2.2 §2: биндинги MUST парсить конфиги в YAML 1.2, не legacy 1.1.
    Практическое следствие: `yes` / `no` / `on` / `off` / `Y` / `N` / `y` / `n`
    остаются строками (не bool). `true` / `false` (любой регистр) — native bool.
    PyYAML по умолчанию наследует YAML 1.1 BOOL_VALUES resolver; `version=(1,2)`
    на `yaml.load()` это не меняет. Кастомный Resolver — рабочий путь.
    """


# Clear inherited YAML 1.1 bool resolvers для нашего Loader'а.
# Оригинальный pyyaml `SafeResolver.add_implicit_resolver` регистрирует
# `tag:yaml.org,2002:bool` с regex'ом, матчящим yes/no/on/off/true/false.
# Сносим все bool-resolver'ы и регистрируем YAML 1.2 вариант с true/false.
import re  # noqa: E402  — локально для bootstrap resolver

_BOOL_TAG = "tag:yaml.org,2002:bool"
Yaml12StrictLoader.yaml_implicit_resolvers = {
    ch: [(tag, regex) for (tag, regex) in resolvers if tag != _BOOL_TAG]
    for ch, resolvers in Yaml12StrictLoader.yaml_implicit_resolvers.items()
}
Yaml12StrictLoader.add_implicit_resolver(  # type: ignore[no-untyped-call]
    _BOOL_TAG,
    re.compile(r"^(?:true|True|TRUE|false|False|FALSE)$"),
    list("tTfF"),
)

if TYPE_CHECKING:
    from collections.abc import Mapping

    from dagstack.config.merge import ConfigTree


@runtime_checkable
class ConfigSource(Protocol):
    """Source контракт per spec §8.1.

    Implementations MUST expose:
        id: human-readable identifier (URI-style conventional).
        interpolate: hint to loader — если True, `${VAR}` в string leaves
            интерполируется применением env interpolation до emit dataset.
        load() -> ConfigTree: return parsed tree (may raise ConfigError).

    Optional (Phase 2+):
        watch(callback) -> Subscription — push-based reload.
        close() -> None — release resources.
    """

    id: str
    interpolate: bool

    def load(self) -> ConfigTree: ...


class YamlFileSource:
    """YAML file source с env interpolation.

    Interpolation выполняется до YAML-парсинга, на raw-тексте файла. Это
    позволяет подставлять env vars в non-string YAML positions (пример:
    `dimension: ${EMBEDDINGS_DIMENSION:-768}` → после interpolate `dimension: 768`
    → после parse — `int(768)`).
    """

    def __init__(
        self,
        path: str | Path,
        *,
        env: Mapping[str, str] | None = None,
    ) -> None:
        self._path = Path(path)
        self._env = env if env is not None else os.environ
        self.id = f"yaml:{self._path}"
        self.interpolate = True

    def load(self) -> ConfigTree:
        try:
            text = self._path.read_text(encoding="utf-8")
        except FileNotFoundError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.SOURCE_UNAVAILABLE,
                details=f"file not found: {self._path}",
                source_id=self.id,
            ) from e
        except OSError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.SOURCE_UNAVAILABLE,
                details=f"cannot read file {self._path}: {e}",
                source_id=self.id,
            ) from e

        interpolated = interpolate(text, self._env, source_id=self.id)

        try:
            # ADR-0001 v2.2 §2: YAML 1.2 strict mode (yes/no/on/off → strings).
            parsed: Any = yaml.load(interpolated, Loader=Yaml12StrictLoader)
        except yaml.YAMLError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.PARSE_ERROR,
                details=f"YAML parse error in {self._path}: {e}",
                source_id=self.id,
            ) from e

        return _coerce_root(_normalize_numbers(parsed), self.id)


class JsonFileSource:
    """JSON file source — same semantics as YAML (YAML 1.2 — superset JSON).

    Используется в сценариях где YAML parser недоступен или вход генерируется
    другим инструментом (например, terraform output, CI-generated config).
    """

    def __init__(
        self,
        path: str | Path,
        *,
        env: Mapping[str, str] | None = None,
    ) -> None:
        self._path = Path(path)
        self._env = env if env is not None else os.environ
        self.id = f"json:{self._path}"
        self.interpolate = True

    def load(self) -> ConfigTree:
        try:
            text = self._path.read_text(encoding="utf-8")
        except FileNotFoundError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.SOURCE_UNAVAILABLE,
                details=f"file not found: {self._path}",
                source_id=self.id,
            ) from e
        except OSError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.SOURCE_UNAVAILABLE,
                details=f"cannot read file {self._path}: {e}",
                source_id=self.id,
            ) from e

        interpolated = interpolate(text, self._env, source_id=self.id)

        try:
            parsed: Any = json.loads(interpolated)
        except json.JSONDecodeError as e:
            raise ConfigError(
                path="",
                reason=ConfigErrorReason.PARSE_ERROR,
                details=f"JSON parse error in {self._path}: {e}",
                source_id=self.id,
            ) from e

        return _coerce_root(_normalize_numbers(parsed), self.id)


class InMemorySource:
    """In-memory source — tests and programmatic bootstrap.

    Interpolation выключена by default (tree уже structurally-correct;
    `${VAR}` не processed). Явно `interpolate=True` — при необходимости.
    """

    def __init__(
        self,
        tree: ConfigTree,
        *,
        source_id: str = "in-memory",
        interpolate: bool = False,
    ) -> None:
        self._tree = tree
        self.id = source_id
        self.interpolate = interpolate

    def load(self) -> ConfigTree:
        # Return shallow copy — caller не должен мутировать original tree through sink.
        # Глубокое копирование делается на уровне merge step.
        return dict(self._tree)


def _coerce_root(parsed: Any, source_id: str) -> ConfigTree:
    """Validate parsed root как mapping; empty file → empty dict."""
    if parsed is None:
        return {}
    if not isinstance(parsed, dict):
        raise ConfigError(
            path="",
            reason=ConfigErrorReason.PARSE_ERROR,
            details=f"root must be a mapping, got {type(parsed).__name__}",
            source_id=source_id,
        )
    return parsed


def _normalize_numbers(obj: Any) -> Any:
    """Whole-number float в safe range → int (source-level normalization).

    Применяется к `YamlFileSource` и `JsonFileSource` для tree-level
    консистентности:

    - PyYAML `yaml.safe_load('x: 100.0')` → `{'x': 100.0}` (float).
    - `json.loads('{"x": 100.0}')` → `{'x': 100.0}` (float).
    - `yaml.safe_load('x: 100')` → `{'x': 100}` (int).
    - `json.loads('{"x": 100}')` → `{'x': 100}` (int).

    Per v2.1 §4.3 / `_meta/coercion.yaml`, whole-number float в
    i-JSON safe range (`±(2^53-1)`) семантически эквивалентен int;
    нормализуем на load-этапе — тогда `cfg.get("x")`, `get_int("x")`,
    `get_section(X, schema-with-int-field)` и canonical JSON
    эмиссия ведут себя одинаково независимо от того, был ли literal
    `100` или `100.0` в YAML/JSON-источнике. Паритет с
    `dagstack/config-go` v0.1.0 `JsonFileSource` +
    `YamlFileSource` (Go идёт через `yaml.Node.Kind` check).

    Out-of-range whole-number floats остаются float (precision не
    гарантируется); fractional — без изменений. Bool не затрагивается
    (`isinstance(bool, float)` = False).
    """
    if isinstance(obj, dict):
        return {k: _normalize_numbers(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_normalize_numbers(v) for v in obj]
    if isinstance(obj, float) and obj.is_integer() and abs(obj) <= IJSON_SAFE_MAX:
        return int(obj)
    return obj
