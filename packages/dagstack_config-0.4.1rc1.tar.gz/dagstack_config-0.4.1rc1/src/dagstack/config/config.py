"""Config class — primary user-facing API.

Per spec ADR-0001 §4: getters + typed section access + subscriptions.

Python binding использует snake_case (per PEP 8) для method names — spec
допускает idiomatic naming per binding (§4 "Bindings реализуют идиоматично"):

    Python snake_case         Spec abstract name
    ─────────────────────────────────────────────
    has(path)                  has(path)
    get(path, default)         get(path)
    get_string(path, default)  getString(path, default)
    get_int(path, default)     getInt(path, default)
    get_number(path, default)  getNumber(path, default)
    get_bool(path, default)    getBool(path, default)
    get_list(path)             getList(path)
    get_section(path, Schema)  getSection(path, schema)
    load(path)                 Config.load(path)
    load_paths([paths])        Config.load(paths)
    load_from([sources])       Config.loadFrom(sources)
    on_change(path, cb)        Config.onChange(path, callback)
    on_section_change(...)     Config.onSectionChange(path, schema, callback)
    reload()                   Config.reload()
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING, Any, ClassVar, TypeVar

from pydantic import BaseModel, ValidationError

from dagstack.config._constants import IJSON_SAFE_MAX
from dagstack.config.errors import ConfigError, ConfigErrorReason
from dagstack.config.merge import deep_merge_all
from dagstack.config.paths import navigate
from dagstack.config.secrets_mask import MASKED_PLACEHOLDER, is_secret_field
from dagstack.config.sources import ConfigSource, YamlFileSource
from dagstack.config.subscription import (
    Subscription,
    emit_subscription_without_watch_warning,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from pathlib import Path

    from dagstack.config.merge import ConfigTree

_ModelT = TypeVar("_ModelT", bound=BaseModel)

# Sentinel для "default not provided" (чтобы отличить от `default=None` как
# легитимного default). `None` — допустимое значение конфига, не sentinel.
_MISSING: Any = object()

_INT_RE = re.compile(r"^-?\d+$")
_TRUE_STRINGS = frozenset({"true", "yes", "1"})
_FALSE_STRINGS = frozenset({"false", "no", "0"})


def _join_pydantic_loc(section: str, loc: tuple[Any, ...]) -> str:
    """Собирает полный dot-notation path из section-prefix'а и pydantic loc.

    ADR-0001 v2.2 §4.2 / §4.5: integer-сегменты (array indices) wrap'аются
    в `[N]`, не конкатенируются через точку. Пример: loc=("servers", 0,
    "port") + section="db" → "db.servers[0].port".
    """
    if not loc:
        return section
    parts: list[str] = [section] if section else []
    for seg in loc:
        if isinstance(seg, int):
            # Array-index — attach без предваряющей точки.
            if parts:
                parts[-1] = f"{parts[-1]}[{seg}]"
            else:
                parts.append(f"[{seg}]")
        else:
            parts.append(str(seg))
    # Собираем: первые два — через точку если second не array-index; далее
    # аналогично. Проще: join'им на точку, но array-тail уже inline.
    return ".".join(parts)


class Config:
    """Merged config, loaded из одного или нескольких sources.

    Usage:
        >>> config = Config.load("app-config.yaml")
        >>> config.get_string("database.host")
        'localhost'
        >>> config.get_int("database.pool_size", default=10)
        10
        >>> db = config.get_section("database", DatabaseConfig)  # Pydantic-validated

    Lifecycle:
    - Config immutable по API (getters — read-only).
    - Runtime reconfigure через `reload()` / `on_change` — в Phase 1 no-op /
      inactive warning (no watch-capable sources).
    """

    _ENV_VAR_NAME: ClassVar[str] = "DAGSTACK_ENV"

    _tree: ConfigTree
    _source_ids: list[str]

    def __init__(
        self,
        tree: ConfigTree,
        *,
        source_ids: list[str] | None = None,
    ) -> None:
        self._tree = tree
        self._source_ids = source_ids or []

    # ─── Constructors ────────────────────────────────────────────────────────

    @classmethod
    def load(cls, path: str | Path) -> Config:
        """Load base config с auto-discovery layered файлов.

        Auto-discovery:
        1. `<base>` (required)
        2. `<stem>.local<suffix>` (optional, gitignored)
        3. `<stem>.${DAGSTACK_ENV}<suffix>` (optional)

        Example:
            >>> # $ DAGSTACK_ENV=production
            >>> cfg = Config.load("app-config.yaml")
            # → loads app-config.yaml + app-config.local.yaml? + app-config.production.yaml?
        """
        from pathlib import Path as _Path

        base_path = _Path(path)
        sources: list[ConfigSource] = [YamlFileSource(base_path)]

        local_path = base_path.with_name(f"{base_path.stem}.local{base_path.suffix}")
        if local_path.exists():
            sources.append(YamlFileSource(local_path))

        env_name = os.environ.get(cls._ENV_VAR_NAME)
        if env_name:
            env_path = base_path.with_name(f"{base_path.stem}.{env_name}{base_path.suffix}")
            if env_path.exists():
                sources.append(YamlFileSource(env_path))

        return cls.load_from(sources)

    @classmethod
    def load_paths(cls, paths: Sequence[str | Path]) -> Config:
        """Explicit file layering — порядок = приоритет (lowest first)."""
        sources: list[ConfigSource] = [YamlFileSource(p) for p in paths]
        return cls.load_from(sources)

    @classmethod
    def load_from(cls, sources: Sequence[ConfigSource]) -> Config:
        """Load config из произвольных sources (Phase 2+ extension point).

        `Sequence` (не `list`) для covariant input — принимает `list[YamlFileSource]`
        и т.п. без type errors.
        """
        trees: list[ConfigTree] = [source.load() for source in sources]
        merged = deep_merge_all(trees)
        return cls(merged, source_ids=[source.id for source in sources])

    # ─── Introspection ───────────────────────────────────────────────────────

    def source_ids(self) -> list[str]:
        """Source ids, из которых собран этот Config. Для diagnostics / logging.

        ADR-0001 v2.1 §4.1: метод, не property — для cross-binding паритета
        с TS `sourceIds()` и Go `SourceIDs()`. Значение вычисляется из
        текущего списка sources; копия возвращается чтобы caller не мог
        мутировать internal state.
        """
        return list(self._source_ids)

    def has(self, path: str) -> bool:
        """True если key/index по path существует в merged tree."""
        try:
            navigate(self._tree, path)
        except ConfigError as err:
            if err.reason in {ConfigErrorReason.MISSING, ConfigErrorReason.TYPE_MISMATCH}:
                return False
            raise
        return True

    # ─── Getters ─────────────────────────────────────────────────────────────

    def get(self, path: str, default: Any = _MISSING) -> Any:
        """Return raw value по path (без type coercion)."""
        try:
            return navigate(self._tree, path)
        except ConfigError as err:
            if default is not _MISSING and err.reason is ConfigErrorReason.MISSING:
                return default
            raise

    def get_string(self, path: str, default: Any = _MISSING) -> str:
        """String value по path — strict (v2.1 §4.3, без implicit coercion).

        **Breaking change v0.2.0**: до v0.1.0 `get_string` coerce'ил
        `int`/`float`/`bool` в `str` (`42 → "42"`, `True → "true"`).
        По ADR v2.1 §4.3 getters — strict; coercion убран ради паритета
        с Go-биндингом и wire-стабильности.

        Для целевой конверсии используй `str(cfg.get(path))` либо
        специализированные getters (`get_int`, `get_bool`, `get_number`).
        """
        try:
            value = navigate(self._tree, path)
        except ConfigError as err:
            if default is not _MISSING and err.reason is ConfigErrorReason.MISSING:
                return default  # type: ignore[no-any-return]
            raise
        if isinstance(value, str):
            return value
        raise ConfigError(
            path=path,
            reason=ConfigErrorReason.TYPE_MISMATCH,
            details=f"expected string, got {type(value).__name__} (v2.1 §4.3 strict)",
        )

    def get_int(self, path: str, default: Any = _MISSING) -> int:
        r"""Integer value по path.

        Accepts:
        - `int` (но не `bool` — отдельный тип per v2.1 §4.3).
        - String matching ``^-?\d+$`` — coerce'ится в int.
        - Whole-number `float` в i-JSON safe range (`±(2^53-1)`) —
          для JSON-источников, где integer-like литералы
          десериализуются как float (v2.1 §4.3 clarification).

        Float с дробной частью либо вне safe range → TYPE_MISMATCH.
        """
        try:
            value = navigate(self._tree, path)
        except ConfigError as err:
            if default is not _MISSING and err.reason is ConfigErrorReason.MISSING:
                return default  # type: ignore[no-any-return]
            raise
        if isinstance(value, bool):
            # Bool — subclass of int; не coerce в int (strict coercion per spec).
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details="expected int, got bool (strict coercion — bool not int)",
            )
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value.is_integer() and abs(value) <= IJSON_SAFE_MAX:
                return int(value)
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details=(
                    f"expected int, got float {value!r} "
                    "(fractional or outside i-JSON safe range ±(2^53-1))"
                ),
            )
        if isinstance(value, str) and _INT_RE.match(value):
            return int(value)
        raise ConfigError(
            path=path,
            reason=ConfigErrorReason.TYPE_MISMATCH,
            details=f"expected int, got {type(value).__name__}",
        )

    def get_number(self, path: str, default: Any = _MISSING) -> float:
        """Float value по path. Int / integer-string / float-string coerce'ятся."""
        try:
            value = navigate(self._tree, path)
        except ConfigError as err:
            if default is not _MISSING and err.reason is ConfigErrorReason.MISSING:
                return default  # type: ignore[no-any-return]
            raise
        if isinstance(value, bool):
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details="expected number, got bool",
            )
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value)
            except ValueError as err:
                raise ConfigError(
                    path=path,
                    reason=ConfigErrorReason.TYPE_MISMATCH,
                    details=f"string {value!r} cannot be parsed as number",
                ) from err
        raise ConfigError(
            path=path,
            reason=ConfigErrorReason.TYPE_MISMATCH,
            details=f"expected number, got {type(value).__name__}",
        )

    def get_bool(self, path: str, default: Any = _MISSING) -> bool:
        """Bool value по path.

        Coercion strict per spec §4.3: строки `true|false|yes|no|1|0`
        (case-insensitive) — only. Other strings / numbers → TYPE_MISMATCH.
        """
        try:
            value = navigate(self._tree, path)
        except ConfigError as err:
            if default is not _MISSING and err.reason is ConfigErrorReason.MISSING:
                return default  # type: ignore[no-any-return]
            raise
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            lowered = value.lower()
            if lowered in _TRUE_STRINGS:
                return True
            if lowered in _FALSE_STRINGS:
                return False
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details=(
                    f"string {value!r} cannot be parsed as bool "
                    "(expected one of true/false/yes/no/1/0, case-insensitive)"
                ),
            )
        raise ConfigError(
            path=path,
            reason=ConfigErrorReason.TYPE_MISMATCH,
            details=f"expected bool, got {type(value).__name__}",
        )

    def get_list(self, path: str) -> list[Any]:
        """List value по path. No default — list required when accessed via getList."""
        value = self.get(path)
        if not isinstance(value, list):
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details=f"expected array (list), got {type(value).__name__}",
            )
        # Return copy — caller может мутировать без effect на internal tree.
        return list(value)

    def get_section(self, path: str, schema: type[_ModelT]) -> _ModelT:
        """Typed section access через Pydantic BaseModel.

        ADR-0001 v2.1 §4.4 Typed section access: env-substituted строки
        coerce'ятся к schema-полям согласно `_meta/coercion.yaml` (Pydantic
        делает это автоматически для int/float/bool из строк, матчящих
        соответствующие regex). Reverse case — native int/float/bool в
        string-поле — отвергается с reason=TYPE_MISMATCH (зеркало §4.3
        getString strict-mode).

        v2.1 §4.5 Path preservation: для nested validation failure path =
        `<section>.<field>` (не только `<section>`).

        Args:
            path: Dot-notation путь к section (map в merged tree).
            schema: Pydantic BaseModel subclass, описывающий ожидаемую shape.

        Returns:
            Validated Pydantic instance.

        Raises:
            ConfigError(MISSING): path не существует.
            ConfigError(TYPE_MISMATCH): значение не map, либо native
                int/float/bool в string-поле schema.
            ConfigError(VALIDATION_FAILED): Pydantic validation failed
                по прочим причинам (range / pattern / enum / и т.п.).
        """
        data = self.get(path)
        if not isinstance(data, dict):
            raise ConfigError(
                path=path,
                reason=ConfigErrorReason.TYPE_MISMATCH,
                details=f"expected object (map) for section, got {type(data).__name__}",
            )
        try:
            return schema.model_validate(data)
        except ValidationError as err:
            first = err.errors()[0]
            # Полный dot-notation path: section + field-path.
            # ADR-0001 v2.2 §4.2 / §4.5: array-индексы → [N], не .N.
            full_path = _join_pydantic_loc(path, first.get("loc", ()))

            # ADR-0001 v2.2 §6 Secrets masking: если failed field — secret,
            # маскируем значение в details. Pydantic обычно включает
            # `input_value` в error; если так — подменяем.
            field_name = str(first["loc"][-1]) if first.get("loc") else ""
            details_msg = f"Pydantic validation failed: {err}"
            if is_secret_field(field_name):
                input_val = first.get("input")
                if input_val not in (None, ""):
                    details_msg = details_msg.replace(
                        repr(input_val), repr(MASKED_PLACEHOLDER)
                    ).replace(str(input_val), MASKED_PLACEHOLDER)

            # Reverse-coerce check (spec §4.4 M1): native non-string scalar
            # в string-поле — это type_mismatch, не validation_failed.
            reason = ConfigErrorReason.VALIDATION_FAILED
            if first.get("type") == "string_type":
                actual_input = first.get("input")
                if isinstance(actual_input, (int, float, bool)):
                    reason = ConfigErrorReason.TYPE_MISMATCH

            raise ConfigError(
                path=full_path,
                reason=reason,
                details=details_msg,
            ) from err

    # ─── Subscriptions (Phase 1: inactive) ────────────────────────────────────

    def on_change(
        self,
        path: str,
        callback: Callable[[Any], None],
    ) -> Subscription:
        """Subscribe на изменения values по path.

        Phase 1: callback никогда не сработает (no watch-capable sources).
        Возвращает `Subscription` с `active=False` и diagnostic warning.
        """
        return self._build_inactive_subscription(path)

    def on_section_change(
        self,
        path: str,
        schema: type[BaseModel],
        callback: Callable[[BaseModel, BaseModel], None],
    ) -> Subscription:
        """Typed subscription на section changes.

        Phase 1: inactive (см. `on_change`).
        """
        return self._build_inactive_subscription(path)

    def reload(self) -> None:
        """Trigger explicit reload всех sources.

        Phase 1: no-op на всех sources (ни один не поддерживает push events).
        Метод зарезервирован для Phase 2+ admin API.
        """
        # Phase 2+: iterate sources, collect new trees, re-merge, validate, swap.

    # ─── Internal helpers ────────────────────────────────────────────────────

    def _build_inactive_subscription(self, path: str) -> Subscription:
        """Build Subscription с active=false + emit subscription_without_watch warning."""
        emit_subscription_without_watch_warning(
            path=path,
            source_ids=list(self._source_ids),
        )
        return Subscription(
            path=path,
            active=False,
            inactive_reason="no watch-capable source registered",
        )
