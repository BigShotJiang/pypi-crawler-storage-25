"""Secret field masking per ADR-0001 v2.2 §6 / `_meta/secret_patterns.yaml`.

Определяет какие field-names считаются sensitive и заменяются на
`[MASKED]` в diagnostic-output. Паттерны — source-of-truth в
spec submodule `spec/_meta/secret_patterns.yaml`; здесь — жёстко
скопированные константы (в будущем — emitter-generated).
"""

from __future__ import annotations

from typing import Any

MASKED_PLACEHOLDER = "[MASKED]"

# Mirror of spec/_meta/secret_patterns.yaml (v2.2).
# When spec updates — bump здесь синхронно.
_SECRET_SUFFIXES: frozenset[str] = frozenset(
    (
        "_key",
        "_secret",
        "_token",
        "_password",
        "_passphrase",
        "_credentials",
        "_credential",
        "_auth",
        "_api_key",
        "_access_key",
        "_private_key",
    )
)

_SECRET_PREFIXES: frozenset[str] = frozenset(
    (
        "api_key",
        "api_token",
        "secret",
        "password",
        "private_key",
        "access_token",
        "bearer",
    )
)

_SECRET_EXACT: frozenset[str] = frozenset(
    (
        "api_key",
        "apikey",
        "password",
        "passwd",
        "pw",
        "token",
        "secret",
        "credentials",
    )
)


def is_secret_field(name: str) -> bool:
    """True если имя поля соответствует secret-паттернам.

    Порядок проверки (OR-семантика): suffix → prefix → exact.
    Case-insensitive.
    """
    lowered = name.lower()
    if lowered in _SECRET_EXACT:
        return True
    if any(lowered.endswith(suffix) for suffix in _SECRET_SUFFIXES):
        return True
    return any(lowered.startswith(prefix) for prefix in _SECRET_PREFIXES)


def mask_value(name: str, value: Any) -> Any:
    """Заменяет value на MASKED_PLACEHOLDER если name — secret и value не пустой.

    Пустые / null значения не маскируются — нечего скрывать; "[MASKED]"
    вместо None был бы misleading.
    """
    if not is_secret_field(name):
        return value
    if value is None or value == "":
        return value
    return MASKED_PLACEHOLDER
