"""Canonical JSON serializer (RFC 8785 subset per spec §9.1.1).

Per spec ADR-0001 §9.1.1 (v2.1):
- Sorted object keys (lexicographic UTF-8 code-point order).
- No whitespace except inside strings.
- Integers: no decimal point (`1`, not `1.0`).
- **Whole-number floats эмитятся в integer form** (`100.0` → `100`,
  `-0.0` → `0`) per v2.1 clarification + `_meta/canonical_json.yaml`.
  Паритет с Go `strconv.FormatFloat('g')`.
- Fractional floats: shortest round-trip (Python `float.__repr__`).
- NaN / Infinity / -Infinity запрещены.
- UTF-8 encoding (enforced для bytes output).
- No trailing newline.

Используется для:
- `conformance/expected/*.json` golden fixtures.
- Hash-based dedup (body_hash в logger-spec).
- Diff-based comparison между binding'ами (bit-identical output).

Whole-number-float → int normalization применяется к значениям в
i-JSON safe range (`±(2^53-1)`). За пределами диапазона float
сохраняется как есть — чтобы не потерять precision при переходе
обратно в float.
"""

from __future__ import annotations

import json
import math
from typing import Any

from dagstack.config._constants import IJSON_SAFE_MAX


def canonical_json_dumps(obj: Any) -> str:
    """Serialize obj в canonical JSON string.

    Args:
        obj: JSON-serializable значение (dict/list/str/int/float/bool/None).

    Returns:
        Canonical JSON Unicode string. Для wire (file / hash / network) —
        дополнительно encode в UTF-8 через `canonical_json_dumpb`.

    Raises:
        ValueError: NaN / ±Infinity in floats, non-string keys в dict,
            или non-JSON-serializable type.
    """
    normalized = _normalize(obj)
    return json.dumps(
        normalized,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
        ensure_ascii=False,
    )


def canonical_json_dumpb(obj: Any) -> bytes:
    """Serialize obj в canonical JSON UTF-8 bytes.

    Shortcut для `canonical_json_dumps(obj).encode("utf-8")` — typical wire form.
    """
    return canonical_json_dumps(obj).encode("utf-8")


def _normalize(obj: Any) -> Any:
    """Recursively normalize обоснованные edge cases перед json.dumps.

    - `-0.0` → `0.0` (RFC 8785 §3.2.2.3).
    - Валидация: ключи dict'ов — только str (JSON spec).
    - NaN / Infinity detection → ValueError заранее, с точным path'ом в ошибке.

    Рекурсивный обход dict/list; остальные типы возвращаются as-is (json.dumps
    обработает дальше или бросит TypeError).
    """
    if isinstance(obj, dict):
        result: dict[str, Any] = {}
        for key, value in obj.items():
            if not isinstance(key, str):
                raise ValueError(f"non-string dict key not allowed in canonical JSON: {key!r}")
            result[key] = _normalize(value)
        return result
    if isinstance(obj, list):
        return [_normalize(item) for item in obj]
    if isinstance(obj, bool):
        # bool должен идти до int (bool — subclass int в Python).
        return obj
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            raise ValueError(f"NaN / Infinity not allowed in canonical JSON: {obj!r}")
        # Whole-number float в i-JSON safe range → integer form
        # (`100.0` → `100`). Специально для `-0.0`: `(-0.0).is_integer()`
        # = True, `abs(-0.0) == 0 <= SAFE_MAX`, `int(-0.0) == 0` →
        # эмитим `"0"`. Это normalize-step per §9.1.1 / canonical_json.yaml,
        # а не passthrough от `FormatFloat('g')` (Go бы дал `-0`);
        # spec явно требует `0` для negative-zero.
        # Fractional и out-of-range float сохраняются как есть.
        if obj.is_integer() and abs(obj) <= IJSON_SAFE_MAX:
            return int(obj)
        return obj
    return obj
