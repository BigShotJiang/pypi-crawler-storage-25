"""Автотесты для `docs/concepts/sources.mdx` (Python snippets)."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest

from dagstack.config import Config, InMemorySource, YamlFileSource


def test_concepts_sources__load_from_layering(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`docs/concepts/sources.mdx` → "Явное перечисление источников" →
    Python TabItem.

    Snippet демонстрирует `Config.load_from` с YamlFileSource +
    InMemorySource в качестве test-override, порядок = приоритет
    (later overrides earlier).
    """
    cfg_path = tmp_path / "app-config.yaml"
    cfg_path.write_text(
        dedent("""\
            database:
              host: "localhost"
              pool_size: 20
        """),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    # --- snippet start -------------------------------------------------
    from dagstack.config import Config, InMemorySource, YamlFileSource

    config = Config.load_from(
        [
            YamlFileSource("app-config.yaml"),
            InMemorySource({"database": {"pool_size": 5}}),  # test-override
        ]
    )
    # --- snippet end ---------------------------------------------------

    # Порядок аргументов = порядок приоритета: последний побеждает.
    assert config.get_int("database.pool_size") == 5
    assert config.get_string("database.host") == "localhost"  # из YAML


# Явная ссылка чтобы линтер не ругался на unused-imports.
_ = (Config, InMemorySource, YamlFileSource)
