"""Автотесты для code snippets из `dagstack/config-docs/site/docs/intro.mdx`.

Каждый тест повторяет Python-snippet дословно, затем assert-ит ожидания
из комментариев (`# "order-service"`, `# 20` и т.д.). При drift'е API
vs docs тест падает — author видит какую страницу нужно переписать.
"""

from __future__ import annotations

import os
from pathlib import Path
from textwrap import dedent

import pytest
from pydantic import BaseModel, Field

from dagstack.config import Config

# Fixture-YAML — точная копия примера из intro.mdx секция "Установка"
# (блок `app-config.yaml`). При изменении в docs → обновить здесь.
APP_CONFIG_YAML = dedent("""\
    app:
      name: "order-service"
      tagline: "Обработчик заказов"

    database:
      host: "${DB_HOST:-localhost}"
      port: "${DB_PORT:-5432}"
      name: "${DB_NAME:-orders}"
      user: "${DB_USER}"
      password: "${DB_PASSWORD}"
      pool_size: 20

    cache:
      url: "${REDIS_URL:-redis://localhost:6379/0}"
      ttl_min: 15

    api:
      host: "0.0.0.0"
      port: 8080
      request_timeout_s: 30
""")


@pytest.fixture
def app_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Пишет app-config.yaml во временный каталог и выставляет
    минимально-необходимые env-переменные (`DB_USER`, `DB_PASSWORD`
    без default'а в YAML), чтобы интерполяция не падала с
    `env_unresolved`.
    """
    monkeypatch.setenv("DB_USER", "app")
    monkeypatch.setenv("DB_PASSWORD", "test-pw")
    cfg_path = tmp_path / "app-config.yaml"
    cfg_path.write_text(APP_CONFIG_YAML, encoding="utf-8")
    # cd в tmp_path — чтобы `Config.load("app-config.yaml")` из snippet
    # находил относительный путь (snippet в docs — именно такой).
    monkeypatch.chdir(tmp_path)
    return cfg_path


# ── Section "Загрузка и чтение" ─────────────────────────────────────


def test_intro__load_and_read(app_config: Path) -> None:
    """Snippet `docs/intro.mdx` → раздел "Загрузка и чтение" →
    TabItem Python.
    """
    # --- snippet start -------------------------------------------------
    from dagstack.config import Config

    config = Config.load("app-config.yaml")

    # Базовые методы доступа:
    print(config.get_string("app.name"))  # "order-service"
    print(config.get_int("database.pool_size"))  # 20
    print(config.get_int("api.port"))  # 8080

    # Со значением по умолчанию — если путь отсутствует, вернётся указанное значение:
    print(config.get_int("api.max_body_mb", default=10))  # 10
    # --- snippet end ---------------------------------------------------

    # Проверки ожиданий из комментариев snippet'а.
    assert config.get_string("app.name") == "order-service"
    assert config.get_int("database.pool_size") == 20
    assert config.get_int("api.port") == 8080
    assert config.get_int("api.max_body_mb", default=10) == 10


# ── Section "Типизированный доступ" ─────────────────────────────────


def test_intro__typed_section(app_config: Path) -> None:
    """Snippet `docs/intro.mdx` → раздел "Типизированный доступ" →
    TabItem Python.
    """

    # --- snippet start -------------------------------------------------
    from pydantic import BaseModel, Field

    from dagstack.config import Config

    class DatabaseConfig(BaseModel):
        host: str
        port: int = Field(5432, ge=1, le=65535)
        name: str
        user: str
        password: str = Field(..., min_length=1)
        pool_size: int = Field(20, ge=1, le=1000)

    config = Config.load("app-config.yaml")
    db = config.get_section("database", DatabaseConfig)
    # Доступ через атрибуты, с валидацией:
    # pool = create_pool(host=db.host, port=db.port, pool_size=db.pool_size)
    #   ^^ create_pool — пользовательская функция в snippet, здесь
    #   закомментирована (не относится к API биндинга). Остальное —
    #   дословно.
    # --- snippet end ---------------------------------------------------

    # Валидация прошла + значения совпадают с YAML.
    assert db.host == "localhost"
    assert db.port == 5432
    assert db.name == "orders"
    assert db.user == "app"
    assert db.password == "test-pw"
    assert db.pool_size == 20


# Явная ссылка на переменные, чтобы линтер не ругался на unused.
_ = (os, BaseModel, Field, Config)
