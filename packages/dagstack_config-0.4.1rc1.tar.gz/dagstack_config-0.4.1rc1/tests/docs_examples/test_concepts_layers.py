"""Автотесты для `docs/concepts/layers.mdx` (Python snippets)."""

from __future__ import annotations

from pathlib import Path

import pytest

from dagstack.config import Config


def test_concepts_layers__explicit_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """`docs/concepts/layers.mdx` → "Явное перечисление слоёв" →
    Python TabItem.

    `Config.load_paths(paths[])` — альтернатива auto-discovery: явный
    список файлов, порядок = приоритет, DAGSTACK_ENV не применяется.
    """
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "base.yaml").write_text(
        "database:\n  host: base-host\n  pool_size: 10\n", encoding="utf-8"
    )
    (cfg_dir / "integration-test.yaml").write_text("database:\n  pool_size: 3\n", encoding="utf-8")
    (cfg_dir / "secrets-ci.yaml").write_text("database:\n  password: ci-secret\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    # --- snippet start -------------------------------------------------
    config = Config.load_paths(
        [
            "config/base.yaml",
            "config/integration-test.yaml",
            "config/secrets-ci.yaml",
        ]
    )
    # Нет DAGSTACK_ENV-логики, порядок определяет priority.
    # --- snippet end ---------------------------------------------------

    # Priority: integration-test перекрыл pool_size, secrets-ci добавил
    # password, host из base остался.
    assert config.get_string("database.host") == "base-host"
    assert config.get_int("database.pool_size") == 3
    assert config.get_string("database.password") == "ci-secret"


def test_concepts_layers__source_ids_diagnostic(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """`docs/concepts/layers.mdx` → "Как узнать какие слои применились" →
    Python TabItem. Метод `source_ids()` возвращает список
    идентификаторов источников в порядке их загрузки.
    """
    base = tmp_path / "app-config.yaml"
    base.write_text("only: me\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    # Отключаем env-layer чтобы source_ids содержал только base.
    monkeypatch.delenv("DAGSTACK_ENV", raising=False)

    config = Config.load("app-config.yaml")

    # --- snippet start -------------------------------------------------
    print(config.source_ids())
    # → ["yaml:app-config.yaml", "yaml:app-config.local.yaml",
    #    "yaml:app-config.production.yaml"]
    # --- snippet end ---------------------------------------------------

    # В этом тесте только base, без local/production.
    ids = config.source_ids()
    assert len(ids) == 1
    assert ids[0].startswith("yaml:")
    assert "app-config.yaml" in ids[0]
