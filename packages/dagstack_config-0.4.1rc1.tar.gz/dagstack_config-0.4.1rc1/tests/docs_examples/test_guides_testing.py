"""Автотесты для `docs/guides/testing.mdx` (Python snippets)."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest
from pydantic import BaseModel

from dagstack.config import Config, InMemorySource


class DatabaseConfig(BaseModel):
    host: str
    port: int = 5432
    name: str
    user: str
    password: str
    pool_size: int = 20


# ── "Unit-тесты — inline-конфиг через in-memory источник" ───────────


def test_testing__inmemory_source_configured_size() -> None:
    """Python TabItem первого Tabs-блока."""

    # --- snippet start -------------------------------------------------
    from dagstack.config import Config, InMemorySource

    config = Config.load_from(
        [
            InMemorySource(
                {
                    "database": {
                        "host": "localhost",
                        "port": 5432,
                        "name": "test",
                        "user": "app",
                        "password": "test-pw",
                        "pool_size": 42,
                    },
                }
            ),
        ]
    )
    # pool = DatabasePool(config.get_section("database", DatabaseConfig))
    #   ^^ пользовательский DatabasePool — вне API биндинга. Вместо
    #      assert'а на pool.size проверяем валидацию схемы.
    # --- snippet end ---------------------------------------------------

    db = config.get_section("database", DatabaseConfig)
    assert db.pool_size == 42


# ── "YamlFileSource в tmpdir" ────────────────────────────────────────


def test_testing__env_interpolation_tmpdir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Python TabItem второго Tabs-блока — env-интерполяция через
    tmp-fixture."""

    # --- snippet start -------------------------------------------------
    # Env-переменные для интерполяции:
    monkeypatch.setenv("DB_PASSWORD", "test-pw")

    yaml_path = tmp_path / "app-config.yaml"
    yaml_path.write_text(
        dedent("""
        database:
          host: "${DB_HOST:-localhost}"
          password: "${DB_PASSWORD}"
          name: "test_db"
          user: "app"
          pool_size: 5
    """)
    )

    config = Config.load(str(yaml_path))
    assert config.get_string("database.password") == "test-pw"
    assert config.get_string("database.host") == "localhost"
    # --- snippet end ---------------------------------------------------


# ── "Интеграционные тесты с DAGSTACK_ENV" ───────────────────────────


def test_testing__production_overrides_base(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Python snippet, раздел "Интеграционные тесты с DAGSTACK_ENV"."""

    # --- snippet start -------------------------------------------------
    (tmp_path / "app-config.yaml").write_text(
        dedent("""
    database:
      pool_size: 20
      host: "localhost"
      name: "test"
      user: "app"
      password: "pw"
    """)
    )
    (tmp_path / "app-config.production.yaml").write_text(
        dedent("""
    database:
      pool_size: 100
    """)
    )

    monkeypatch.setenv("DAGSTACK_ENV", "production")
    monkeypatch.chdir(tmp_path)
    config = Config.load("app-config.yaml")
    assert config.get_int("database.pool_size") == 100
    # --- snippet end ---------------------------------------------------


_ = InMemorySource  # used via symbol resolution inside snippet
