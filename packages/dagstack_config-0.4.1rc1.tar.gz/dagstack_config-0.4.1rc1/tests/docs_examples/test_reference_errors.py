"""Автотесты для `docs/reference/errors.mdx` (Python snippets)."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from dagstack.config import Config, ConfigError, ConfigErrorReason, InMemorySource


class DatabaseConfig(BaseModel):
    host: str
    password: str = Field(..., min_length=1)


@pytest.fixture
def sample_config() -> Config:
    """Config с минимальной секцией для negative-тестов."""
    return Config.load_from(
        [
            InMemorySource(
                {
                    "database": {
                        "host": "localhost",
                        "pool_size": "twenty",  # некорректный для get_int
                        "password": "",  # некорректный для validation
                    }
                }
            )
        ]
    )


# ── `missing` ────────────────────────────────────────────────────────


def test_errors__missing(sample_config: Config) -> None:
    """Docs snippet: ConfigError(path="nonexistent.path", reason="missing", ...)"""
    with pytest.raises(ConfigError) as excinfo:
        # --- snippet start -----------------------------------------------
        sample_config.get_string("nonexistent.path")
        # ConfigError(
        #   path="nonexistent.path",
        #   reason="missing",
        #   details="Key 'nonexistent.path' not found in config and no default provided",
        # )
        # --- snippet end -------------------------------------------------
    err = excinfo.value
    # ADR-0001 v2.1 §4.5 Path preservation: полный dot-notation путь.
    assert err.path == "nonexistent.path"
    assert err.reason == ConfigErrorReason.MISSING


# ── `type_mismatch` ──────────────────────────────────────────────────


def test_errors__type_mismatch(sample_config: Config) -> None:
    """Docs snippet: ConfigError(path="database.pool_size", reason="type_mismatch", ...)"""
    # YAML: pool_size: "twenty"
    with pytest.raises(ConfigError) as excinfo:
        # --- snippet start -----------------------------------------------
        sample_config.get_int("database.pool_size")
        # ConfigError(
        #   path="database.pool_size",
        #   reason="type_mismatch",
        #   details="Expected int, got string 'twenty' (does not match ^-?\\d+$)",
        # )
        # --- snippet end -------------------------------------------------
    err = excinfo.value
    assert err.path == "database.pool_size"
    assert err.reason == ConfigErrorReason.TYPE_MISMATCH


# ── `env_unresolved` ─────────────────────────────────────────────────


def test_errors__env_unresolved(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Docs snippet: `${DB_PASSWORD}` без default'а + env отсутствует."""
    cfg = tmp_path / "app-config.yaml"
    cfg.write_text('database:\n  password: "${DB_PASSWORD}"\n', encoding="utf-8")
    # Убираем DB_PASSWORD из окружения, если выставлена.
    monkeypatch.delenv("DB_PASSWORD", raising=False)
    monkeypatch.chdir(tmp_path)

    with pytest.raises(ConfigError) as excinfo:
        Config.load("app-config.yaml")

    err = excinfo.value
    assert err.reason == ConfigErrorReason.ENV_UNRESOLVED


# ── `validation_failed` ──────────────────────────────────────────────


def test_errors__validation_failed(sample_config: Config) -> None:
    """Docs snippet: get_section упал на pydantic-validation."""

    # --- snippet start ---------------------------------------------------
    # class DatabaseConfig(BaseModel):
    #     host: str
    #     password: str = Field(..., min_length=1)
    #
    # YAML: password: ""  (пустая строка)
    # --- snippet end -----------------------------------------------------
    with pytest.raises(ConfigError) as excinfo:
        sample_config.get_section("database", DatabaseConfig)

    err = excinfo.value
    assert err.reason == ConfigErrorReason.VALIDATION_FAILED


# ── `source_unavailable` ─────────────────────────────────────────────


def test_errors__source_unavailable(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Docs snippet: Config.load на несуществующий файл."""
    monkeypatch.chdir(tmp_path)

    with pytest.raises(ConfigError) as excinfo:
        # --- snippet start -----------------------------------------------
        # Файл не существует:
        Config.load("non-existent.yaml")
        # --- snippet end -------------------------------------------------

    err = excinfo.value
    assert err.reason == ConfigErrorReason.SOURCE_UNAVAILABLE


# ── Handler-снип с try/except ────────────────────────────────────────


def test_errors__handler_switch(sample_config: Config) -> None:
    """Docs snippet: try/except ConfigError + switch по reason."""
    # Упрощённая версия handler'а: извлекаем reason из ошибки.
    # --- snippet start (simplified) ------------------------------------
    try:
        sample_config.get_string("nonexistent")
        handled_reason = None
    except ConfigError as exc:
        handled_reason = exc.reason
    # --- snippet end ---------------------------------------------------

    assert handled_reason == ConfigErrorReason.MISSING


_ = Field  # import используется в snippet schema
