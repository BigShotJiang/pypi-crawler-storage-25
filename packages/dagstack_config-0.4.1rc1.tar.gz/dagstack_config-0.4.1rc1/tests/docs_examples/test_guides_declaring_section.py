"""Автотесты для `docs/guides/declaring-section.mdx` (Python snippets)."""

from __future__ import annotations

from pathlib import Path
from textwrap import dedent

import pytest
from pydantic import BaseModel, Field

from dagstack.config import Config


# Типовой DatabaseConfig, используемый во многих snippets в docs.
class DatabaseConfig(BaseModel):
    host: str
    port: int = 5432
    name: str
    user: str
    password: str
    pool_size: int = 20
    ssl: bool = False


# Отдельная секция для "Изоляция" — чтобы snippet с CacheConfig
# не требовал специфичных полей.
class CacheConfig(BaseModel):
    url: str
    ttl_min: int = 15


@pytest.fixture
def full_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    cfg = tmp_path / "app-config.yaml"
    cfg.write_text(
        dedent("""\
            database:
              host: localhost
              port: 5432
              name: orders
              user: app
              password: test-pw
              pool_size: 20

            cache:
              url: redis://localhost:6379/0
              ttl_min: 15
        """),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    return cfg


# ── Шаг 3 "Прочитать секцию" ─────────────────────────────────────────


def test_declaring_section__get_section(full_config: Path) -> None:
    """Python TabItem, раздел "Шаг 3. Прочитать секцию"."""

    # --- snippet start -------------------------------------------------
    from dagstack.config import Config

    config = Config.load("app-config.yaml")
    db_cfg = config.get_section("database", DatabaseConfig)
    # db_cfg — инстанс DatabaseConfig, уже валидирован.
    # --- snippet end ---------------------------------------------------

    assert isinstance(db_cfg, DatabaseConfig)
    assert db_cfg.host == "localhost"
    assert db_cfg.pool_size == 20


# ── Шаг 4 "Изоляция" ─────────────────────────────────────────────────


def test_declaring_section__isolation_correct(full_config: Path) -> None:
    """Python TabItem, раздел "Шаг 4. Изоляция"."""
    config = Config.load("app-config.yaml")

    # --- snippet start -------------------------------------------------
    # Правильно — в сервисе работы с БД:
    db_cfg = config.get_section("database", DatabaseConfig)

    # Неправильно — в БД-сервисе читаем чужую секцию:
    cache_cfg = config.get_section("cache", CacheConfig)
    # Сервис БД теперь зависит от структуры cache.
    # --- snippet end ---------------------------------------------------

    # Оба вызова работают — документация просто предостерегает от
    # cross-section reads, не запрещает на уровне API.
    assert db_cfg.host == "localhost"
    assert cache_cfg.url == "redis://localhost:6379/0"


# ── Шаг 5 "Default'ы в schema" ───────────────────────────────────────


def test_declaring_section__defaults_in_schema(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Python TabItem, раздел "Шаг 5. Значения по умолчанию".

    Опциональные поля объявлены со значениями по умолчанию в schema —
    при отсутствии в YAML подставляются без fallback'а в коде.
    """
    # YAML содержит только обязательные поля.
    cfg = tmp_path / "app-config.yaml"
    cfg.write_text(
        "database:\n  host: localhost\n  user: app\n  password: pw\n  name: test\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    # --- snippet start (defaults-in-schema) ----------------------------
    class DatabaseConfig(BaseModel):
        host: str  # обязательное
        user: str  # обязательное
        password: str  # обязательное
        port: int = 5432  # значение по умолчанию в schema
        pool_size: int = 20  # значение по умолчанию в schema
        ssl: bool = False  # значение по умолчанию в schema

    # --- snippet end ---------------------------------------------------

    # Нужно имя (обязательное) — добавим через отдельное поле.
    # Snippet в docs не упоминает name, но для теста с YAML пусть будет.
    class DatabaseConfigWithName(DatabaseConfig):
        name: str

    config = Config.load("app-config.yaml")
    db = config.get_section("database", DatabaseConfigWithName)

    # Defaults сработали:
    assert db.port == 5432
    assert db.pool_size == 20
    assert db.ssl is False


# Явная ссылка на Field (используется в документации, здесь опосредованно).
_ = Field
