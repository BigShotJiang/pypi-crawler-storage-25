"""Conformance runner — прогоняет golden fixtures из `spec/conformance/`.

Per spec §9.1 ADR-0001: binding обязан пройти все тесты из `manifest.yaml`
с byte-identical output по canonical JSON.

Запуск:
    uv run pytest -m conformance -v

Runner читает `spec/conformance/manifest.yaml`, для каждого test entry:
1. Собирает env mapping из optional env-файла.
2. Создаёт YamlFileSource для каждого input.
3. Happy path (`expected` key): loads + merges + serialize canonical JSON,
   diffs против файла `expected/<id>.json` byte-identical.
4. Error case (`expected_error` key): asserts ConfigError raised с matching
   reason + path.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest
import yaml

from dagstack.config import Config, ConfigError, YamlFileSource
from dagstack.config.canonical_json import canonical_json_dumps

if TYPE_CHECKING:
    from collections.abc import Mapping

# ─── Paths ───────────────────────────────────────────────────────────────────

_REPO_ROOT = Path(__file__).parent.parent
_SPEC_ROOT = _REPO_ROOT / "spec"
_CONF_ROOT = _SPEC_ROOT / "conformance"
_MANIFEST_PATH = _CONF_ROOT / "manifest.yaml"


def _load_manifest() -> list[dict[str, Any]]:
    """Parse manifest.yaml → list of test specs (skipped если spec submodule отсутствует)."""
    if not _MANIFEST_PATH.exists():
        pytest.skip(f"spec submodule not initialised: {_MANIFEST_PATH} missing")
    data = yaml.safe_load(_MANIFEST_PATH.read_text(encoding="utf-8"))
    tests = data.get("tests", [])
    assert isinstance(tests, list)
    return tests


_MANIFEST = _load_manifest() if _MANIFEST_PATH.exists() else []
_TEST_IDS = [str(t["id"]) for t in _MANIFEST]


# ─── Helpers ────────────────────────────────────────────────────────────────


def _load_env(env_rel_path: str | None) -> Mapping[str, str]:
    """Parse `conformance/env/<file>.env` в dict. Blank lines и `#`-comments skip."""
    if env_rel_path is None:
        return {}
    env_path = _CONF_ROOT / env_rel_path
    if not env_path.exists():
        pytest.fail(f"env file referenced but missing: {env_rel_path}")
    env: dict[str, str] = {}
    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        key, _, value = stripped.partition("=")
        env[key.strip()] = value
    return env


def _resolve_input(rel_path: str) -> Path:
    return _CONF_ROOT / rel_path


def _read_expected_json(rel_path: str) -> str:
    """Read expected canonical JSON (canonical — no trailing newline по правилу spec)."""
    path = _CONF_ROOT / rel_path
    text = path.read_text(encoding="utf-8")
    # Soften: если файл content был written с trailing newline (редкий авторский
    # недосмотр), мы strip'аем при сравнении — wire-level actual output без newline.
    return text.rstrip("\n")


# ─── Test cases ─────────────────────────────────────────────────────────────


@pytest.mark.conformance
@pytest.mark.parametrize(
    "test_spec",
    _MANIFEST,
    ids=_TEST_IDS,
)
def test_conformance_fixture(test_spec: dict[str, Any]) -> None:
    """Выполнить один fixture из manifest."""
    # v2.1: фикстуры с тегом `runner_extension_required` требуют getter/
    # getSection-level вызовов, которые runner v1.0 не моделирует
    # (только load-level). Эти фикстуры биндинги MAY использовать в своих
    # unit-тестах напрямую — что и сделано для config-python в
    # tests/test_config.py и tests/docs_examples/*.py. Skip до runner
    # extension (tracked в config-spec как follow-up).
    tags = test_spec.get("tags", []) or []
    if "runner_extension_required" in tags:
        pytest.skip(
            "getter/getSection-level fixture — runner v1.0 supports only "
            "load-level errors; biding-native unit tests cover this case"
        )

    env = _load_env(test_spec.get("env"))
    inputs = [_resolve_input(p) for p in test_spec["inputs"]]
    sources = [YamlFileSource(p, env=env) for p in inputs]

    expected = test_spec.get("expected")
    expected_error = test_spec.get("expected_error")

    if expected is not None:
        _assert_happy_path(sources, expected)
    elif expected_error is not None:
        _assert_error_case(sources, expected_error)
    else:
        pytest.fail(f"test {test_spec['id']!r}: neither `expected` nor `expected_error` provided")


def _assert_happy_path(sources: list[YamlFileSource], expected_rel_path: str) -> None:
    cfg = Config.load_from(sources)
    # Hit __getattribute__ to access merged tree through existing getter semantics —
    # `get` с корневым паттерном вернул бы конкретный key; используем internal `_tree`
    # для full serialization (conformance tests только — в production API не exposed).
    merged = cfg._tree
    actual = canonical_json_dumps(merged)
    expected = _read_expected_json(expected_rel_path)
    assert actual == expected, f"conformance mismatch\nactual:   {actual}\nexpected: {expected}"


def _assert_error_case(
    sources: list[YamlFileSource],
    expected_error: dict[str, Any],
) -> None:
    with pytest.raises(ConfigError) as exc_info:
        Config.load_from(sources)
    err = exc_info.value
    expected_reason = expected_error["reason"]
    expected_path = expected_error.get("path", "")
    assert err.reason.value == expected_reason, (
        f"reason mismatch: got {err.reason.value!r}, expected {expected_reason!r}"
    )
    assert err.path == expected_path, f"path mismatch: got {err.path!r}, expected {expected_path!r}"
