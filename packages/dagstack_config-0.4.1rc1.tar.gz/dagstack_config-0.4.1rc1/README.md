# dagstack-config

Python binding for [dagstack/config-spec](https://github.com/dagstack/config-spec) — YAML configuration with env interpolation, deep-merge layering, Pydantic-based typed sections, runtime reconfigure.

**Status: Phase A (skeleton).** Implementation in progress — see [open issues](https://github.com/dagstack/config-python/issues).

## Roadmap

- **Phase A** (this PR) — repo skeleton, pyproject, CI, spec submodule, empty package.
- **Phase B** — core primitives: `ConfigError` + reasons, env interpolation parser, deep merge, Canonical JSON serializer.
- **Phase C** — `Config` class, `ConfigSource` abstraction (`YamlFileSource`, `JsonFileSource`, `InMemorySource`), `Subscription` handle.
- **Phase D** — conformance runner against `spec/conformance/` golden fixtures.
- **Phase 1 release (`0.1.0`)** — after Phase A-D merge. Spec MVP (no watch, hot-reload, OTLP-source, etc.).
- **Phase 2+** — source adapters (etcd, Consul, Vault, HTTP), watch + push-reload, LogProcessor-like hooks.

## Spec

The spec submodule lives in `spec/` (pointing to `dagstack/config-spec`). Normative decisions are recorded in `spec/adr/0001-yaml-configuration.md`.

## Local development

```bash
git clone --recurse-submodules git@github.com:dagstack/config-python.git
cd config-python
uv sync --group dev

make test           # pytest
make lint           # ruff check + format --check
make typecheck      # mypy --strict
```

## Licensing

Apache-2.0 (see [LICENSE](./LICENSE)).

## Related

- [`dagstack/config-spec`](https://github.com/dagstack/config-spec) — language-agnostic spec.
- [`dagstack/logger-spec`](https://github.com/dagstack/logger-spec) — logger that reads config through this binding.
- [`dagstack/plugin-system-python`](https://github.com/dagstack/plugin-system-python) — reference binding (pattern and Makefile/CI structure).
