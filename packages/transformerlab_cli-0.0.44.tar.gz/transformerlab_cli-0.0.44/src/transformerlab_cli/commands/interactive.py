import re
import time

import httpx
import typer
from rich.panel import Panel

from transformerlab_cli.util import api
from transformerlab_cli.util.config import require_current_experiment
from transformerlab_cli.util.ui import console

DEFAULT_TIMEOUT = 300
POLL_INTERVAL = 3


def _get_experiment_id() -> str:
    """Get current experiment ID from config, or exit with helpful message."""
    return require_current_experiment()


def _select_provider() -> dict:
    """Fetch providers and prompt user to select one."""
    with console.status("[bold success]Fetching providers...[/bold success]", spinner="dots"):
        response = api.get("/compute_provider/providers/")

    if response.status_code != 200:
        console.print("[error]Error:[/error] Failed to fetch providers.")
        raise typer.Exit(1)

    providers = response.json()
    if not providers:
        console.print("[error]Error:[/error] No compute providers available. Add one in team settings first.")
        raise typer.Exit(1)

    console.print("\n[bold label]Select a compute provider:[/bold label]")
    for i, provider in enumerate(providers, 1):
        ptype = provider.get("type", "")
        console.print(f"  [bold]{i}[/bold]. {provider.get('name', provider.get('id'))} ({ptype})")

    while True:
        choice = typer.prompt("Provider", default="1")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(providers):
                return providers[idx]
            console.print(f"[error]Please enter a number between 1 and {len(providers)}[/error]")
        except ValueError:
            console.print("[error]Please enter a valid number[/error]")


def _select_template(experiment_id: str, provider: dict) -> dict:
    """Fetch interactive gallery and prompt user to select a template, filtered by provider."""
    with console.status("[bold success]Fetching interactive tasks...[/bold success]", spinner="dots"):
        response = api.get(f"/experiment/{experiment_id}/task/gallery/interactive")

    if response.status_code != 200:
        console.print("[error]Error:[/error] Failed to fetch interactive gallery.")
        raise typer.Exit(1)

    # Response is wrapped: {"status": "success", "data": [...]}
    gallery = response.json().get("data", [])
    is_local = provider.get("type") == "local"

    # Filter by provider compatibility
    provider_accelerators = set()
    acc = provider.get("supported_accelerators") or provider.get("accelerators")
    if isinstance(acc, str):
        provider_accelerators = {a.strip() for a in acc.split(",") if a.strip()}
    elif isinstance(acc, list):
        provider_accelerators = set(acc)

    compatible = []
    for entry in gallery:
        # Skip remote-only tasks for local providers
        if is_local and entry.get("remoteOnly"):
            continue

        # Check accelerator compatibility (if both sides specify)
        task_acc = entry.get("supported_accelerators", [])
        if isinstance(task_acc, str):
            task_acc = [a.strip() for a in task_acc.split(",") if a.strip()]
        if task_acc and provider_accelerators:
            if not set(task_acc) & provider_accelerators:
                continue

        compatible.append(entry)

    if not compatible:
        console.print("[warning]No compatible interactive tasks for this provider.[/warning]")
        if is_local:
            console.print("[dim]Some tasks are only available on remote providers.[/dim]")
        raise typer.Exit(1)

    console.print("\n[bold label]Available interactive tasks:[/bold label]")
    for i, entry in enumerate(compatible, 1):
        console.print(f"  [bold]{i}[/bold]. {entry.get('name', entry.get('id'))} - {entry.get('description', '')}")

    while True:
        choice = typer.prompt("Task", default="1")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(compatible):
                return compatible[idx]
            console.print(f"[error]Please enter a number between 1 and {len(compatible)}[/error]")
        except ValueError:
            console.print("[error]Please enter a valid number[/error]")


def _collect_env_params(gallery_entry: dict, provider: dict) -> dict[str, str]:
    """Collect environment parameters with smart defaults."""
    env_parameters = gallery_entry.get("env_parameters", [])
    if not env_parameters:
        return {}

    is_local = provider.get("type") == "local"
    env_vars: dict[str, str] = {}

    console.print("\n[bold label]Configuration:[/bold label]")
    for param in env_parameters:
        env_var = param.get("env_var", "")
        field_name = param.get("field_name", env_var)
        required = param.get("required", False)
        is_password = param.get("password", False)

        # Skip NGROK_AUTH_TOKEN for local providers (no tunnel needed)
        if is_local and env_var == "NGROK_AUTH_TOKEN":
            continue

        # Smart default: use secret placeholder for remote providers, otherwise use placeholder
        default = param.get("placeholder", "")
        if not is_local and env_var == "NGROK_AUTH_TOKEN":
            default = "{{secret._NGROK_AUTH_TOKEN}}"

        # Show prompt with hint
        prompt_text = f"  {field_name}"
        if not required:
            prompt_text += " (optional)"
        help_text = param.get("help_text", "")
        if help_text:
            console.print(f"    [dim]{help_text}[/dim]")

        while True:
            value = typer.prompt(
                prompt_text,
                default=default if default else "",
                show_default=bool(default),
                hide_input=is_password,
            )
            if value or not required:
                break
            console.print(f"[error]  {field_name} is required.[/error]")

        if value:
            env_vars[env_var] = value

    return env_vars


def _collect_resources(gallery_entry: dict) -> dict:
    """Collect resource configuration for remote providers."""
    console.print("\n[bold label]Resource configuration:[/bold label]")

    def ask(label: str, default_val: str = "") -> str:
        return typer.prompt(f"  {label}", default=default_val, show_default=bool(default_val))

    cpus = ask("CPUs", gallery_entry.get("cpus", "2"))
    memory = ask("Memory (GB)", gallery_entry.get("memory", "16"))
    disk_space = ask("Disk (GB)", gallery_entry.get("disk_space", "50"))
    accelerators = ask("Accelerators", gallery_entry.get("accelerators", ""))
    num_nodes_str = ask("Num nodes", gallery_entry.get("num_nodes", "1"))
    try:
        num_nodes = int(num_nodes_str)
    except ValueError:
        num_nodes = 1
    minutes_str = ask("Max minutes", gallery_entry.get("minutes_requested", "60"))
    try:
        minutes_requested = int(minutes_str)
    except ValueError:
        minutes_requested = 60

    return {
        "cpus": cpus,
        "memory": memory,
        "disk_space": disk_space,
        "accelerators": accelerators,
        "num_nodes": num_nodes,
        "minutes_requested": minutes_requested,
    }


def _import_task(experiment_id: str, gallery_entry: dict, env_vars: dict) -> str:
    """Import an interactive task from the gallery. Returns the task ID."""
    payload = {
        "gallery_id": gallery_entry.get("id"),
        "experiment_id": experiment_id,
        "is_interactive": True,
        "env_vars": env_vars,
    }

    response = api.post_json(f"/experiment/{experiment_id}/task/gallery/import", payload)
    if response.status_code != 200:
        try:
            detail = response.json().get("detail", response.text)
        except (ValueError, KeyError):
            detail = response.text
        console.print(f"[error]Error:[/error] Failed to import task: {detail}")
        raise typer.Exit(1)

    data = response.json()
    task_id = data.get("id")
    if not task_id:
        console.print("[error]Error:[/error] No task ID returned from import.")
        raise typer.Exit(1)

    return str(task_id)


def _build_interactive_launch_payload(
    experiment_id: str,
    task_id: str,
    provider: dict,
    gallery_entry: dict,
    env_vars: dict,
    resources: dict,
) -> dict:
    """Build the launch payload for an interactive task.

    The backend resolves the actual run command from the task and gallery
    at launch time, so we pass the gallery's command as a hint but rely
    on the server-side fallback to the task's stored run field.
    """
    is_local = provider.get("type") == "local"

    return {
        "experiment_id": experiment_id,
        "task_id": task_id,
        "task_name": gallery_entry.get("name", "Interactive Task"),
        "cluster_name": gallery_entry.get("name", "Interactive Task"),
        "run": gallery_entry.get("command", ""),
        "setup": gallery_entry.get("setup", ""),
        "subtype": "interactive",
        "interactive_type": gallery_entry.get("interactive_type", "custom"),
        "interactive_gallery_id": gallery_entry.get("id"),
        "local": is_local,
        "env_vars": env_vars,
        "provider_name": provider.get("name"),
        "cpus": resources.get("cpus"),
        "memory": resources.get("memory"),
        "disk_space": resources.get("disk_space"),
        "accelerators": resources.get("accelerators"),
        "num_nodes": resources.get("num_nodes"),
        "minutes_requested": resources.get("minutes_requested"),
    }


def _launch(provider: dict, payload: dict) -> int:
    """Launch the task on a provider. Returns job ID."""
    provider_id = provider.get("id")
    response = api.post_json(f"/compute_provider/providers/{provider_id}/launch/", payload)

    if response.status_code != 200:
        try:
            detail = response.json().get("detail", response.text)
        except (ValueError, KeyError):
            detail = response.text
        console.print(f"[error]Error:[/error] Failed to launch task: {detail}")
        raise typer.Exit(1)

    data = response.json()
    job_id = data.get("job_id")
    if not job_id:
        console.print("[error]Error:[/error] No job ID returned from launch.")
        raise typer.Exit(1)

    return int(job_id)


ACTIVE_STATUSES = {"LAUNCHING", "INTERACTIVE", "WAITING", "RUNNING"}


def _poll_until_ready(experiment_id: str, job_id: int, timeout: int) -> dict:
    """Poll tunnel_info until service is ready, job fails, or timeout."""
    start = time.time()
    tunnel_url = f"/experiment/{experiment_id}/jobs/{job_id}/tunnel_info"
    jobs_url = f"/experiment/{experiment_id}/jobs/list?type=REMOTE"
    logs_url = f"/experiment/{experiment_id}/jobs/{job_id}/provider_logs?live=true"
    seen_log_lines = 0
    spinner = console.status("[bold success]Waiting for service...[/bold success]", spinner="dots")
    spinner.start()

    while True:
        elapsed = int(time.time() - start)
        if elapsed >= timeout:
            spinner.stop()
            console.print(f"\n[warning]Timed out after {timeout}s waiting for service.[/warning]")
            console.print(f"Check status with: [bold]lab job info {job_id}[/bold]")
            raise typer.Exit(1)

        if seen_log_lines == 0:
            spinner.update(f"[bold success]Waiting for service... ({elapsed}s)[/bold success]")

        try:
            # Check job status — only keep polling if in an active state
            jobs_resp = api.get(jobs_url, timeout=10.0)
            if jobs_resp.status_code == 200:
                job = next((j for j in jobs_resp.json() if j.get("id") == job_id), None)
                if job:
                    job_status = job.get("status")
                    if job_status not in ACTIVE_STATUSES:
                        spinner.stop()
                        error_msg = job.get("job_data", {}).get("error_msg", "")
                        console.print(f"\n[error]Job {job_id} {job_status}.[/error]")
                        if error_msg:
                            console.print(f"[error]Error: {error_msg}[/error]")
                        console.print(f"Check logs with: [bold]lab job info {job_id}[/bold]")
                        raise typer.Exit(1)
        except typer.Exit:
            raise
        except httpx.HTTPError:
            pass

        # Stream new log lines to give the user feedback
        try:
            logs_resp = api.get(logs_url, timeout=10.0)
            if logs_resp.status_code == 200:
                logs_data = logs_resp.json()
                logs_text = logs_data.get("logs", "") if isinstance(logs_data, dict) else ""
                if logs_text and "No log files found" not in logs_text:
                    lines = logs_text.splitlines()
                    if len(lines) > seen_log_lines:
                        if seen_log_lines == 0:
                            spinner.stop()
                        for line in lines[seen_log_lines:]:
                            console.print(f"[dim]{line}[/dim]")
                        seen_log_lines = len(lines)
        except httpx.HTTPError:
            pass

        try:
            response = api.get(tunnel_url, timeout=10.0)
            if response.status_code == 200:
                data = response.json()
                if data.get("is_ready"):
                    if seen_log_lines == 0:
                        spinner.stop()
                    return data
        except httpx.HTTPError:
            pass  # Server unreachable, keep polling

        time.sleep(POLL_INTERVAL)


def _print_connection_info(tunnel_info: dict, job_id: int) -> None:
    """Render connection info from tunnel_info instructions."""
    console.print("\n[success bold]✓ Service is ready![/success bold]\n")

    instructions = tunnel_info.get("instructions", [])
    values = {k: str(v) for k, v in tunnel_info.items() if v is not None and isinstance(v, (str, int, float))}

    for block in instructions:
        kind = block.get("kind")
        title = block.get("title", "")
        value_key = block.get("value_key")
        value = values.get(value_key, "") if value_key else ""

        if kind == "url" and value:
            console.print(Panel(f"[link={value}]{value}[/link]", title=title, border_style="green"))
        elif kind == "code" and value:
            console.print(Panel(f"[bold]{value}[/bold]", title=title, border_style="cyan"))
        elif kind == "command" and value:
            console.print(Panel(f"[bold]{value}[/bold]", title=title, border_style="blue"))
        elif kind == "kv":
            items = block.get("items", [])
            lines = []
            for item in items:
                val = values.get(item.get("value_key", ""), "")
                if val:
                    lines.append(f"  {item.get('label', '')}: {val}")
            if lines:
                console.print(Panel("\n".join(lines), title=title, border_style="dim"))
        elif kind == "text":
            template = block.get("template", "")
            if template:
                resolved = re.sub(r"\{\{(\w+)\}\}", lambda m: values.get(m.group(1), m.group(1)), template)
                console.print(Panel(resolved, title=title, border_style="dim"))

    # Print ports if available
    ports = tunnel_info.get("ports", [])
    if ports:
        console.print("\n[bold]Exposed Ports:[/bold]")
        for p in ports:
            console.print(f"  {p.get('label', '')}: port {p.get('port', '')} ({p.get('protocol', '')})")

    console.print(f"\nTo stop this session: [bold]lab job stop {job_id}[/bold]")
    console.print(f"To check status:      [bold]lab job info {job_id}[/bold]")


def interactive(timeout: int = DEFAULT_TIMEOUT) -> None:
    """Launch an interactive task (Jupyter, vLLM, Ollama, etc.)."""
    experiment_id = _get_experiment_id()

    # 1. Select provider
    provider = _select_provider()
    is_local = provider.get("type") == "local"

    # 2. Select template
    template = _select_template(experiment_id, provider)
    console.print(f"\n[bold]Task:[/bold] {template.get('name', 'Unknown')}")

    # 3. Collect env parameters
    env_vars = _collect_env_params(template, provider)

    # 4. Collect resources (remote only)
    resources: dict = {}
    if not is_local:
        resources = _collect_resources(template)

    # 5. Import task from gallery
    with console.status("[bold success]Importing task...[/bold success]", spinner="dots"):
        task_id = _import_task(experiment_id, template, env_vars)

    # 6. Launch
    payload = _build_interactive_launch_payload(experiment_id, task_id, provider, template, env_vars, resources)

    with console.status("[bold success]Launching...[/bold success]", spinner="dots"):
        job_id = _launch(provider, payload)

    console.print(f"Job [bold]{job_id}[/bold] created.")

    # 7. Poll until ready
    tunnel_info = _poll_until_ready(experiment_id, job_id, timeout)

    # 8. Print connection info
    _print_connection_info(tunnel_info, job_id)
