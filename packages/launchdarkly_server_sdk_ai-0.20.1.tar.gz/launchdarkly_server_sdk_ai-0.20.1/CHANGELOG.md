# Changelog

All notable changes to the LaunchDarkly Python AI package will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org).

## [0.20.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.20.0...launchdarkly-server-sdk-ai-0.20.1) (2026-05-14)


### Bug Fixes

* Make judge runners non-multi-turn ([#185](https://github.com/launchdarkly/python-server-sdk-ai/issues/185)) ([5c21bd0](https://github.com/launchdarkly/python-server-sdk-ai/commit/5c21bd08bebfbdc5672afa93ad99099202955c92))

## [0.20.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.19.0...launchdarkly-server-sdk-ai-0.20.0) (2026-05-13)


### ⚠ BREAKING CHANGES

* Remove deprecated client method aliases and type aliases ([#179](https://github.com/launchdarkly/python-server-sdk-ai/issues/179))
* Narrow AgentGraphRunner.run input from Any to str ([#177](https://github.com/launchdarkly/python-server-sdk-ai/issues/177))
* Strip legacy judge messages on direct judge_config() path ([#174](https://github.com/launchdarkly/python-server-sdk-ai/issues/174))
* Rename LDAIMetrics.usage and AIGraphMetrics.usage to .tokens ([#175](https://github.com/launchdarkly/python-server-sdk-ai/issues/175))
* rename GraphMetrics/GraphMetricSummary to AIGraphMetrics/AIGraphMetricSummary ([#173](https://github.com/launchdarkly/python-server-sdk-ai/issues/173))
* Remove stale ManagedModel message management and AgentGraphResult type ([#170](https://github.com/launchdarkly/python-server-sdk-ai/issues/170))

### Features

* Narrow AgentGraphRunner.run input from Any to str ([#177](https://github.com/launchdarkly/python-server-sdk-ai/issues/177)) ([cc7a0fe](https://github.com/launchdarkly/python-server-sdk-ai/commit/cc7a0fe64549337c71036cd67973bf0af91c7a42))
* Remove deprecated client method aliases and type aliases ([#179](https://github.com/launchdarkly/python-server-sdk-ai/issues/179)) ([20df94b](https://github.com/launchdarkly/python-server-sdk-ai/commit/20df94b3bf817d22b09b42c5918ba594ef4f2ee6))
* rename GraphMetrics/GraphMetricSummary to AIGraphMetrics/AIGraphMetricSummary ([#173](https://github.com/launchdarkly/python-server-sdk-ai/issues/173)) ([583939d](https://github.com/launchdarkly/python-server-sdk-ai/commit/583939dbe5c11c3c11ed960ee0b46ec377f1bb70))
* Rename LDAIMetrics.usage and AIGraphMetrics.usage to .tokens ([#175](https://github.com/launchdarkly/python-server-sdk-ai/issues/175)) ([d8c4a70](https://github.com/launchdarkly/python-server-sdk-ai/commit/d8c4a702d4b68f146de7ca520bc35f2aa0b155f6))


### Bug Fixes

* Remove stale ManagedModel message management and AgentGraphResult type ([#170](https://github.com/launchdarkly/python-server-sdk-ai/issues/170)) ([7d6ad23](https://github.com/launchdarkly/python-server-sdk-ai/commit/7d6ad2340717c48ccde9e718ee7f2b92fb748e9e))
* Strip legacy judge messages on direct judge_config() path ([#174](https://github.com/launchdarkly/python-server-sdk-ai/issues/174)) ([b7db754](https://github.com/launchdarkly/python-server-sdk-ai/commit/b7db7549c95bacf1fd62ec066b844ed6389b0cd1))

## [0.19.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.18.0...launchdarkly-server-sdk-ai-0.19.0) (2026-05-05)


### ⚠ BREAKING CHANGES

* StructuredResponse replaced by RunnerResult with new "parsed" property
* AgentResult replaced by RunnerResult and Managed Result
* Removed ModelRunner and AgentRunner protocols
* Removed invoke_model, invoke_structured_model from AIProvider base class.
* ModelResponse was replaced by RunnerResult
* Add ManagedResult, RunnerResult, and Runner protocol; rename invoke() to run() ([#148](https://github.com/launchdarkly/python-server-sdk-ai/issues/148))
* Swap track_metrics_of parameter order to match spec ([#144](https://github.com/launchdarkly/python-server-sdk-ai/issues/144))

### Features

* Add evaluations support to ManagedAgent.run() ([#153](https://github.com/launchdarkly/python-server-sdk-ai/issues/153)) ([442f46a](https://github.com/launchdarkly/python-server-sdk-ai/commit/442f46aa65996a4b986e9421a3348180a43b520e))
* Add judge evaluation support to agent graphs ([#142](https://github.com/launchdarkly/python-server-sdk-ai/issues/142)) ([3d5a6a9](https://github.com/launchdarkly/python-server-sdk-ai/commit/3d5a6a91a87c7475a83a7e440cd4b71337cfd56f))
* Add ManagedGraphResult, GraphMetricSummary, and AgentGraphRunnerResult types ([#151](https://github.com/launchdarkly/python-server-sdk-ai/issues/151)) ([301e24c](https://github.com/launchdarkly/python-server-sdk-ai/commit/301e24c3f84168ba8f4fed2a172c0391b3017c29))
* Add ManagedResult, RunnerResult, and Runner protocol; rename invoke() to run() ([#148](https://github.com/launchdarkly/python-server-sdk-ai/issues/148)) ([88d4ddc](https://github.com/launchdarkly/python-server-sdk-ai/commit/88d4ddce26c17fbf5509802367156e50a66d0a68))
* Add root-level tools map with customParameters to AI Config types ([#141](https://github.com/launchdarkly/python-server-sdk-ai/issues/141)) ([f17c535](https://github.com/launchdarkly/python-server-sdk-ai/commit/f17c53571e707a46c695f0955163776a2999f49a))
* bake sampling_rate into Judge at construction; simplify Evaluator to List[Judge] ([#159](https://github.com/launchdarkly/python-server-sdk-ai/issues/159)) ([86c79e6](https://github.com/launchdarkly/python-server-sdk-ai/commit/86c79e6a65c88cf9f59e8ed8ca4d29897b5ce059))
* Update LangChain runners to implement Runner protocol returning RunnerResult ([#150](https://github.com/launchdarkly/python-server-sdk-ai/issues/150)) ([62a8e25](https://github.com/launchdarkly/python-server-sdk-ai/commit/62a8e252f4389884fa2f6a90e325db4a8f79376a))


### Bug Fixes

* Add runtime DeprecationWarnings to deprecated methods ([#145](https://github.com/launchdarkly/python-server-sdk-ai/issues/145)) ([2189b81](https://github.com/launchdarkly/python-server-sdk-ai/commit/2189b812df257e122d7c7001158a219d34d9e3d0))
* AgentResult replaced by RunnerResult and Managed Result ([fbb0b4b](https://github.com/launchdarkly/python-server-sdk-ai/commit/fbb0b4b45090144e3cb14d3966ed46a2884518fb))
* build judge input as string; strip legacy judge config messages ([#165](https://github.com/launchdarkly/python-server-sdk-ai/issues/165)) ([e6942a6](https://github.com/launchdarkly/python-server-sdk-ai/commit/e6942a6e2d4db17ae1fa6191521f8ac4fb48f30d))
* Fall back to model.parameters.tools when root tools absent ([#146](https://github.com/launchdarkly/python-server-sdk-ai/issues/146)) ([2c30d75](https://github.com/launchdarkly/python-server-sdk-ai/commit/2c30d75a7df83207e8ff13bcb1af30e001554e8a))
* Graph tracking refactor — ManagedAgentGraph drives tracking for new runner shape ([#154](https://github.com/launchdarkly/python-server-sdk-ai/issues/154)) ([20a5020](https://github.com/launchdarkly/python-server-sdk-ai/commit/20a50206a58b3aa1c0d256955a3dfda59a1e20f6))
* ModelResponse was replaced by RunnerResult ([fbb0b4b](https://github.com/launchdarkly/python-server-sdk-ai/commit/fbb0b4b45090144e3cb14d3966ed46a2884518fb))
* parse model.parameters.tools as list ([#160](https://github.com/launchdarkly/python-server-sdk-ai/issues/160)) ([fb53e99](https://github.com/launchdarkly/python-server-sdk-ai/commit/fb53e99ea66634ee79867494535a28d3eac37646))
* reference correct PyPI package names in provider load error messages ([#164](https://github.com/launchdarkly/python-server-sdk-ai/issues/164)) ([48761c9](https://github.com/launchdarkly/python-server-sdk-ai/commit/48761c998d58aa8ca2f8bbbe8a886e395d3a431a))
* Removed invoke_model, invoke_structured_model from AIProvider base class. ([fbb0b4b](https://github.com/launchdarkly/python-server-sdk-ai/commit/fbb0b4b45090144e3cb14d3966ed46a2884518fb))
* Removed ModelRunner and AgentRunner protocols ([fbb0b4b](https://github.com/launchdarkly/python-server-sdk-ai/commit/fbb0b4b45090144e3cb14d3966ed46a2884518fb))
* Replace done_callback with coroutine chain for judge tracking ([#147](https://github.com/launchdarkly/python-server-sdk-ai/issues/147)) ([1e1f36b](https://github.com/launchdarkly/python-server-sdk-ai/commit/1e1f36b08ba28dafa4eb7b1dc8e192ef6a0891ad))
* StructuredResponse replaced by RunnerResult with new "parsed" property ([fbb0b4b](https://github.com/launchdarkly/python-server-sdk-ai/commit/fbb0b4b45090144e3cb14d3966ed46a2884518fb))
* Swap track_metrics_of parameter order to match spec ([#144](https://github.com/launchdarkly/python-server-sdk-ai/issues/144)) ([53db736](https://github.com/launchdarkly/python-server-sdk-ai/commit/53db736e71fbdcb0cd83e4ed20ce1b8c1084db78))

## [0.18.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.17.0...launchdarkly-server-sdk-ai-0.18.0) (2026-04-21)


### ⚠ BREAKING CHANGES

* Add per-execution runId, at-most-once tracking, and cross-process tracker resumption ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133))
* `AICompletionConfig`, `AIAgentConfig`, and `AIJudgeConfig`: `tracker` field replaced with `create_tracker` factory callable ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133))
* `ManagedModel`, `ManagedAgent`, `Judge`, and `ManagedAgentGraph` constructors no longer accept a tracker parameter; tracker is now created on-demand via `create_tracker` ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133))
* `ManagedAgentGraph.get_tracker()` method removed ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133))
* rename track_latency to track_duration on AIGraphTracker ([#138](https://github.com/launchdarkly/python-server-sdk-ai/issues/138))
* `graph_key` keyword argument removed from all `LDAIConfigTracker.track_*()` methods; trackers retrieved via a graph definition are automatically configured with the correct graph key ([#134](https://github.com/launchdarkly/python-server-sdk-ai/issues/134))
* Flatten JudgeResponse and EvalScore into new JudgeResult ([#132](https://github.com/launchdarkly/python-server-sdk-ai/issues/132))
* `LDAIConfigTracker.track_eval_scores()` and `track_judge_response()` removed and consolidated into `track_judge_result()` ([#132](https://github.com/launchdarkly/python-server-sdk-ai/issues/132))
* `AIGraphTracker.track_judge_response()` method removed ([#132](https://github.com/launchdarkly/python-server-sdk-ai/issues/132))
* `Judge.evaluate()` and `evaluate_messages()` now always return a `JudgeResult` object; use `result.sampled` to check if evaluation was actually executed ([#132](https://github.com/launchdarkly/python-server-sdk-ai/issues/132))

### Features

* Add per-execution runId, at-most-once tracking, and cross-process tracker resumption ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133)) ([68685cd](https://github.com/launchdarkly/python-server-sdk-ai/commit/68685cd9623105b0b01dd57942538c047615f4f2))
* Flatten JudgeResponse and EvalScore into new JudgeResult ([#132](https://github.com/launchdarkly/python-server-sdk-ai/issues/132)) ([af4e463](https://github.com/launchdarkly/python-server-sdk-ai/commit/af4e46332c5d9a668a7172012c89871d0fb90b56))
* Move graph_key to AIConfigTracker instantiation ([#134](https://github.com/launchdarkly/python-server-sdk-ai/issues/134)) ([20fff24](https://github.com/launchdarkly/python-server-sdk-ai/commit/20fff24fcd02aa101d7f9a6c21dc6a25e7916a1c))
* rename track_latency to track_duration on AIGraphTracker ([#138](https://github.com/launchdarkly/python-server-sdk-ai/issues/138)) ([05758a7](https://github.com/launchdarkly/python-server-sdk-ai/commit/05758a735db0c2defc4e08d02282a46f559220e5))
* Add `LDAIConfigTracker.resumption_token()` and `from_resumption_token()` methods to continue tracking a run from a separate process ([#133](https://github.com/launchdarkly/python-server-sdk-ai/issues/133)) ([68685cd](https://github.com/launchdarkly/python-server-sdk-ai/commit/68685cd9623105b0b01dd57942538c047615f4f2))

## [0.17.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.16.1...launchdarkly-server-sdk-ai-0.17.0) (2026-04-02)


### ⚠ BREAKING CHANGES

* Restructure provider factory and support additional create methods ([#102](https://github.com/launchdarkly/python-server-sdk-ai/issues/102))
* Split track_metrics_of into sync and async variants ([#112](https://github.com/launchdarkly/python-server-sdk-ai/issues/112))
* Remove node-scoped methods from AIGraphTracker (track_node_invocation, track_tool_call, track_node_judge_response), use related AIConfigTracker methods instead

### Features

* Introduce ManagedModel and ModelRunner ([#104](https://github.com/launchdarkly/python-server-sdk-ai/issues/104)) ([453c71c](https://github.com/launchdarkly/python-server-sdk-ai/commit/453c71c84adcc6b8a3e316a98907dcb511bc9d41))
* Introduce ManagedAgent and AgentRunner implementations ([#110](https://github.com/launchdarkly/python-server-sdk-ai/issues/110)) ([53fd95e](https://github.com/launchdarkly/python-server-sdk-ai/commit/53fd95e2cfb66f4c53c6844cc41170077e6eee8c))
* Add LDAIClient.create_agent() returning ManagedAgent ([53fd95e](https://github.com/launchdarkly/python-server-sdk-ai/commit/53fd95e2cfb66f4c53c6844cc41170077e6eee8c))
* Add ManagedAgentGraph support ([#111](https://github.com/launchdarkly/python-server-sdk-ai/issues/111)) ([56ce0fd](https://github.com/launchdarkly/python-server-sdk-ai/commit/56ce0fd63b4301b58f33c17c55c4ecd47e9f8559))
* Add ModelRunner protocol with invoke_model() and invoke_structured_model() ([453c71c](https://github.com/launchdarkly/python-server-sdk-ai/commit/453c71c84adcc6b8a3e316a98907dcb511bc9d41))
* Add optional graph_key to all LDAIConfigTracker track_* methods for graph correlation ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))
* Add track_tool_call/track_tool_calls to LDAIConfigTracker ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))
* Deprecated Chat object in favor of ManagedModel ([453c71c](https://github.com/launchdarkly/python-server-sdk-ai/commit/453c71c84adcc6b8a3e316a98907dcb511bc9d41))
* Deprecated create_chat(), use create_model() on the LDAIClient ([453c71c](https://github.com/launchdarkly/python-server-sdk-ai/commit/453c71c84adcc6b8a3e316a98907dcb511bc9d41))
* Drop support for python 3.9 ([#114](https://github.com/launchdarkly/python-server-sdk-ai/issues/114)) ([dc592c5](https://github.com/launchdarkly/python-server-sdk-ai/commit/dc592c5a2e2bf3bf679af14a9aa63e81678a69ab))


### Bug Fixes

* Make AIGraphTracker.track_total_tokens accept Optional[TokenUsage], skip when None or total &lt;= 0 ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))
* Remove node-scoped methods from AIGraphTracker (track_node_invocation, track_tool_call, track_node_judge_response), use related AIConfigTracker methods instead ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))
* Use time.perf_counter_ns() for sub-millisecond precision in duration calculations ([4fab18f](https://github.com/launchdarkly/python-server-sdk-ai/commit/4fab18fa62375b6c97cb12a89225805c81ca4ee8))

## [0.16.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.16.0...launchdarkly-server-sdk-ai-0.16.1) (2026-03-16)


### Bug Fixes

* Simplify judge structured output for improve reliability for judge scores for some LLMs ([#105](https://github.com/launchdarkly/python-server-sdk-ai/issues/105)) ([f951dac](https://github.com/launchdarkly/python-server-sdk-ai/commit/f951daccd569a0b5ff598f571d105a7d244939d1))

## [0.16.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.15.0...launchdarkly-server-sdk-ai-0.16.0) (2026-03-09)


### ⚠ BREAKING CHANGES

* Rename default_value args to default

### Bug Fixes

* Make default optional with a disabled config default ([#97](https://github.com/launchdarkly/python-server-sdk-ai/issues/97)) ([39e09c6](https://github.com/launchdarkly/python-server-sdk-ai/commit/39e09c616bcb36af56983094039ee72a97bd1a19))
* Rename default_value args to default ([39e09c6](https://github.com/launchdarkly/python-server-sdk-ai/commit/39e09c616bcb36af56983094039ee72a97bd1a19))

## [0.15.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.14.2...launchdarkly-server-sdk-ai-0.15.0) (2026-03-02)


### Features

* add agent graph tracker ([#89](https://github.com/launchdarkly/python-server-sdk-ai/issues/89)) ([9d371fa](https://github.com/launchdarkly/python-server-sdk-ai/commit/9d371faa43c3028062e32f44f8693ede685cb7c6))

## [0.14.2](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.14.1...launchdarkly-server-sdk-ai-0.14.2) (2026-02-25)


### Bug Fixes

* Only track usage for entry methods ([#94](https://github.com/launchdarkly/python-server-sdk-ai/issues/94)) ([22d91d9](https://github.com/launchdarkly/python-server-sdk-ai/commit/22d91d9982e27daf68016357a14fb6eca22dc8d6))

## [0.14.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.14.0...launchdarkly-server-sdk-ai-0.14.1) (2026-02-23)


### Bug Fixes

* Improve usage reporting ([#92](https://github.com/launchdarkly/python-server-sdk-ai/issues/92)) ([e21eb89](https://github.com/launchdarkly/python-server-sdk-ai/commit/e21eb890cc190822fd857f7a1032d2543400b356))
* Update pre-release usage guidance ([#90](https://github.com/launchdarkly/python-server-sdk-ai/issues/90)) ([4f986c4](https://github.com/launchdarkly/python-server-sdk-ai/commit/4f986c4b4f74f001e5487892509129bdc9aa091c))

## [0.14.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.13.0...launchdarkly-server-sdk-ai-0.14.0) (2026-01-27)


### Features

* Add support for custom judges via evaluation metric key ([#86](https://github.com/launchdarkly/python-server-sdk-ai/issues/86)) ([a55503b](https://github.com/launchdarkly/python-server-sdk-ai/commit/a55503b13553f53c05a8f004c76b25e01f6a5c40))

## [0.13.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.12.0...launchdarkly-server-sdk-ai-0.13.0) (2026-01-22)


### Features

* Added agent_graph SDK method ([#85](https://github.com/launchdarkly/python-server-sdk-ai/issues/85)) ([e9e8a50](https://github.com/launchdarkly/python-server-sdk-ai/commit/e9e8a5002e982597eb6a454c65d96713ec92e027))

## [0.12.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.11.0...launchdarkly-server-sdk-ai-0.12.0) (2026-01-02)


### ⚠ BREAKING CHANGES

* Removed SupportedAIProvider type
* Removed optional logger parameters

### Features

* Re-export ldclient log in ldai ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))


### Bug Fixes

* Enable support for existing AI Providers ([#80](https://github.com/launchdarkly/python-server-sdk-ai/issues/80)) ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))
* Order of providers is now preserved ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))
* Removed optional logger parameters ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))
* Removed SupportedAIProvider type ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))
* Use the ldclient logger ([55e0da3](https://github.com/launchdarkly/python-server-sdk-ai/commit/55e0da3dc0a142d94da6ae78a8322a8448b569c6))

## [0.11.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/launchdarkly-server-sdk-ai-0.10.1...launchdarkly-server-sdk-ai-0.11.0) (2025-12-19)


### ⚠ BREAKING CHANGES

* Renamed `LDAIAgentDefaults` to `AIAgentConfigDefault` for clarity
* Renamed `LDAIAgentConfig` to `AIAgentConfigRequest` for clarity
* Renamed `LDAIAgent` to `AIAgentConfig` (note the previous use of this name)
* Renamed `AIConfig` to `AICompletionConfigDefault` for default/input values, use `AICompletionConfig` for returned configs
* Model classes and types that were previously imported from `ldai.client` should now be imported from `ldai` or `ldai.models` (e.g., `ModelConfig`, `ProviderConfig`, `LDMessage`, `AICompletionConfig`, etc.)

### Features

* Add support for real time judge evals ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `create_chat` method to create Chat instances for conversational AI ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `create_judge` method to create Judge instances for AI evaluation ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `judge_config` method to AI SDK to retrieve an AI Judge Config ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `track_eval_scores` method to config tracker ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `track_judge_response` method to config tracker ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Added `track_metrics_of` async method to config tracker for generic AI operation tracking ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Chat will evaluate responses with configured judges ([#73](https://github.com/launchdarkly/python-server-sdk-ai/issues/73)) ([62cb2aa](https://github.com/launchdarkly/python-server-sdk-ai/commit/62cb2aa7f4641777c61fdc2cc6013357ef7289be))
* Deprecated `LDAIClient.config()` and will be removed in a future version, use `LDAIClient.completion_config()` instead
* Deprecated `LDAIClient.agent()` and will be removed in a future version, use `LDAIClient.agent_config()` instead
* Deprecated `LDAIClient.agents()` and will be removed in a future version, use `LDAIClient.agent_configs()` instead


## [0.10.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.10.0...0.10.1) (2025-08-28)


### Bug Fixes

* Add usage tracking to config method ([#60](https://github.com/launchdarkly/python-server-sdk-ai/issues/60)) ([e7294ca](https://github.com/launchdarkly/python-server-sdk-ai/commit/e7294ca14b298fc18933e055369a25be9aee4783))

## [0.10.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.9.1...0.10.0) (2025-07-29)


### Features

* Added agent support to SDK ([#54](https://github.com/launchdarkly/python-server-sdk-ai/issues/54)) ([df8cc20](https://github.com/launchdarkly/python-server-sdk-ai/commit/df8cc20fe35edcb7a84874a156039cf906c45e2d))
* Update AI tracker to include model & provider name for metrics generation ([#58](https://github.com/launchdarkly/python-server-sdk-ai/issues/58)) ([d62a779](https://github.com/launchdarkly/python-server-sdk-ai/commit/d62a779912d0b42d5965ce652d02f0258533040a))


### Bug Fixes

* Remove deprecated track generation event ([#57](https://github.com/launchdarkly/python-server-sdk-ai/issues/57)) ([ed02047](https://github.com/launchdarkly/python-server-sdk-ai/commit/ed02047ac22ae3f091168abcf5543e9e1ff87242))

## [0.9.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.9.0...0.9.1) (2025-06-26)


### Bug Fixes

* Fix Bedrock response parsing ([#50](https://github.com/launchdarkly/python-server-sdk-ai/issues/50)) ([df90bc2](https://github.com/launchdarkly/python-server-sdk-ai/commit/df90bc24c98b5a57bf944225774989b689b65d93))

## [0.9.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.8.1...0.9.0) (2025-06-26)


### ⚠ BREAKING CHANGES

* Drop support for Python 3.8 (eol 2024-10-07) ([#48](https://github.com/launchdarkly/python-server-sdk-ai/issues/48))

### Features

* Drop support for Python 3.8 (eol 2024-10-07) ([#48](https://github.com/launchdarkly/python-server-sdk-ai/issues/48)) ([8f94da6](https://github.com/launchdarkly/python-server-sdk-ai/commit/8f94da65d9019e17fbabe1d1f5ce1168ace5957e))

## [0.8.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.8.0...0.8.1) (2025-04-03)


### Documentation

* AI config --&gt; AI Config name change ([a123248](https://github.com/launchdarkly/python-server-sdk-ai/commit/a1232483bbd8a4a2212fb16e7e98ab6f6bdc8459))
* AI config --&gt; AI Config name change ([#42](https://github.com/launchdarkly/python-server-sdk-ai/issues/42)) ([bbdf1f6](https://github.com/launchdarkly/python-server-sdk-ai/commit/bbdf1f61fab77992a1d13207c81642d056e03f02))

## [0.8.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.7.0...0.8.0) (2025-02-07)


### Features

* Add variation version to metric data ([#39](https://github.com/launchdarkly/python-server-sdk-ai/issues/39)) ([1b07d08](https://github.com/launchdarkly/python-server-sdk-ai/commit/1b07d08743c409689c5a084df8c39fce2400d2dd))

## [0.7.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.6.0...0.7.0) (2025-01-23)


### Features

* Add ability to track time to first token for LDAIConfigTracker ([#37](https://github.com/launchdarkly/python-server-sdk-ai/issues/37)) ([b4a5757](https://github.com/launchdarkly/python-server-sdk-ai/commit/b4a5757ab7a1a8149891977cdfc25bdd4f7bba09))

## [0.6.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.5.0...0.6.0) (2024-12-17)


### ⚠ BREAKING CHANGES

* Unify tracking token to use only `TokenUsage` ([#32](https://github.com/launchdarkly/python-server-sdk-ai/issues/32))
* Change version_key_to variation_key ([#29](https://github.com/launchdarkly/python-server-sdk-ai/issues/29))

### Features

* Add `LDAIConfigTracker.get_summary` method ([#31](https://github.com/launchdarkly/python-server-sdk-ai/issues/31)) ([e425b1f](https://github.com/launchdarkly/python-server-sdk-ai/commit/e425b1f9e7bf27ab195b877e62af48012eb601c1))
* Add `track_error` to mirror `track_success` ([#33](https://github.com/launchdarkly/python-server-sdk-ai/issues/33)) ([404f704](https://github.com/launchdarkly/python-server-sdk-ai/commit/404f704dd38f4fc15c718e3dc1027efbda5f36b6))


### Bug Fixes

* Unify tracking token to use only `TokenUsage` ([#32](https://github.com/launchdarkly/python-server-sdk-ai/issues/32)) ([80e1845](https://github.com/launchdarkly/python-server-sdk-ai/commit/80e18452a936356937660eabe7a186beae4d17bd))


### Code Refactoring

* Change version_key_to variation_key ([#29](https://github.com/launchdarkly/python-server-sdk-ai/issues/29)) ([fcc720a](https://github.com/launchdarkly/python-server-sdk-ai/commit/fcc720a101c97ccb92fd95509b3e7819d557dde5))

## [0.5.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.4.0...0.5.0) (2024-12-09)


### ⚠ BREAKING CHANGES

* Rename model and provider id to name ([#27](https://github.com/launchdarkly/python-server-sdk-ai/issues/27))

### Code Refactoring

* Rename model and provider id to name ([#27](https://github.com/launchdarkly/python-server-sdk-ai/issues/27)) ([65260b6](https://github.com/launchdarkly/python-server-sdk-ai/commit/65260b621acee07b38e9ebaeb4a10c1e4c9db794))

## [0.4.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.3.0...0.4.0) (2024-12-02)


### Features

* Return AIConfig and LDAITracker separately [#23](https://github.com/launchdarkly/python-server-sdk-ai/issues/23) ([96f888f](https://github.com/launchdarkly/python-server-sdk-ai/commit/96f888f50503cc2e9e2c30bf1c21f80a2773c8b5))


### Bug Fixes

* Fix context usage for message interpolation ([#24](https://github.com/launchdarkly/python-server-sdk-ai/issues/24)) ([1159aee](https://github.com/launchdarkly/python-server-sdk-ai/commit/1159aeeda7c46cf2dab93f209929dbad5d35dc80))

## [0.3.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.2.0...0.3.0) (2024-11-22)


### ⚠ BREAKING CHANGES

* Rename nest parameters under model
* Change modelId to id
* Remove max_tokens and temperature as top level model config keys
* Suffix track methods with metrics
* Rename `LDAIClient.model_config` to `LDAIClient.config`
* Rename prompt to messages

### Features

* Add custom parameter support to model config ([95015f1](https://github.com/launchdarkly/python-server-sdk-ai/commit/95015f1f29b4ddf0acc2f22b72a5c0c4241fd3f3))
* Add support for provider config ([d2a2ea7](https://github.com/launchdarkly/python-server-sdk-ai/commit/d2a2ea7a16159de5c11484114ad4a7ae6369f9c6))


### Bug Fixes

* Change modelId to id ([9564780](https://github.com/launchdarkly/python-server-sdk-ai/commit/9564780ea2b919d456431e3309b73156f8e9817d))
* Remove max_tokens and temperature as top level model config keys ([55f34fe](https://github.com/launchdarkly/python-server-sdk-ai/commit/55f34fec9410124d24318feadada9e087e7d4cb8))
* Rename `LDAIClient.model_config` to `LDAIClient.config` ([3a3e913](https://github.com/launchdarkly/python-server-sdk-ai/commit/3a3e913d9e1586278d9fe6228f79f6748cbbd605))
* Rename nest parameters under model ([a2cc966](https://github.com/launchdarkly/python-server-sdk-ai/commit/a2cc9662bdc526f0b6a3a271a4b4f46b95d0ec2f))
* Rename prompt to messages ([9a86f0a](https://github.com/launchdarkly/python-server-sdk-ai/commit/9a86f0af9322baf71d7ddddb6115d585582cfc86))
* Suffix track methods with metrics ([319f64d](https://github.com/launchdarkly/python-server-sdk-ai/commit/319f64da54815854163d663022fdffc274c2059a))

## [0.2.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.1.1...0.2.0) (2024-11-21)


### Features

* Change the typing for the AIConfig ([#16](https://github.com/launchdarkly/python-server-sdk-ai/issues/16)) ([daf9537](https://github.com/launchdarkly/python-server-sdk-ai/commit/daf95372328f1b1e4e9e27333498642136f43838))


### Bug Fixes

* Change linting tools to dev-only dependency ([#15](https://github.com/launchdarkly/python-server-sdk-ai/issues/15)) ([c752739](https://github.com/launchdarkly/python-server-sdk-ai/commit/c752739d1c34cbf7f78cc3f89c37a688671c7366))
* Verify prompt payload exists before accessing it ([#19](https://github.com/launchdarkly/python-server-sdk-ai/issues/19)) ([d9dd21f](https://github.com/launchdarkly/python-server-sdk-ai/commit/d9dd21f2189de62eac70ad9db3755e4a2cf36511))

## [0.1.1](https://github.com/launchdarkly/python-server-sdk-ai/compare/0.1.0...0.1.1) (2024-11-08)


### Bug Fixes

* Update how prompt is handled ([#12](https://github.com/launchdarkly/python-server-sdk-ai/issues/12)) ([050cc71](https://github.com/launchdarkly/python-server-sdk-ai/commit/050cc71dde52db3174153a0c9c08021580530833))

## [0.1.0](https://github.com/launchdarkly/python-server-sdk-ai/compare/v0.1.0...0.1.0) (2024-11-08)

Initial release of the LaunchDarkly Python AI package. To learn more about the LaunchDarkly Python AI SDK, see the [Python AI SDK documentation](https://docs.launchdarkly.com/sdk/ai/python).
