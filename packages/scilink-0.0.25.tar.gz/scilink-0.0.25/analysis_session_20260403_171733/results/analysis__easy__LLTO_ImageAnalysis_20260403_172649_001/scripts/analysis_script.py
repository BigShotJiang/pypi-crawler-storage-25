import numpy as np
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage
from scipy.optimize import curve_fit
from skimage import filters
from sklearn.cluster import KMeans
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# MONKEY-PATCH: Fix TensorDataset empty-init for newer PyTorch
# ============================================================
import torch
import torch.utils.data

_original_tensor_dataset_init = torch.utils.data.TensorDataset.__init__

def _patched_tensor_dataset_init(self, *tensors):
    if len(tensors) == 0:
        # Handle zero-argument case that newer PyTorch rejects
        self.tensors = ()
        return
    _original_tensor_dataset_init(self, *tensors)

torch.utils.data.TensorDataset.__init__ = _patched_tensor_dataset_init

# ============================================================
# 1. LOAD IMAGE
# ============================================================
path = '/Users/maxim.ziatdinov/Code/SciLink/analysis_session_20260403_171733/results/analysis__easy__LLTO_ImageAnalysis_20260403_172649_001/image_0000/temp_image_0.npy'
image_raw = np.load(path).astype(np.float64)
print(f"Image shape: {image_raw.shape}, dtype: {image_raw.dtype}")
print(f"Raw intensity range: [{image_raw.min():.1f}, {image_raw.max():.1f}]")

H, W = image_raw.shape

# ============================================================
# 2. POLYNOMIAL BACKGROUND SUBTRACTION
# ============================================================
print("Performing polynomial background subtraction...")

# Create coordinate grids
y_coords, x_coords = np.mgrid[0:H, 0:W]

# Downsample for fitting efficiency
step = 8
y_ds = y_coords[::step, ::step].ravel()
x_ds = x_coords[::step, ::step].ravel()
z_ds = image_raw[::step, ::step].ravel()

# Normalize coordinates to [-1, 1] for numerical stability
y_norm = (y_ds - H/2) / (H/2)
x_norm = (x_ds - W/2) / (W/2)

# Build 3rd order polynomial design matrix
def poly_design(xn, yn, order=3):
    cols = []
    for i in range(order + 1):
        for j in range(order + 1 - i):
            cols.append(xn**i * yn**j)
    return np.column_stack(cols)

A_ds = poly_design(x_norm, y_norm, order=3)
coeffs, _, _, _ = np.linalg.lstsq(A_ds, z_ds, rcond=None)

# Evaluate background on full grid
y_full_norm = (y_coords.ravel() - H/2) / (H/2)
x_full_norm = (x_coords.ravel() - W/2) / (W/2)
A_full = poly_design(x_full_norm, y_full_norm, order=3)
background = (A_full @ coeffs).reshape(H, W)

# Subtract background
image_bgsub = image_raw - background

# Normalize to [0, 1] using percentile-based rescaling
p_low, p_high = np.percentile(image_bgsub, [0.5, 99.5])
image_norm = np.clip((image_bgsub - p_low) / (p_high - p_low), 0, 1).astype(np.float32)

print(f"Background-corrected range: [{image_bgsub.min():.1f}, {image_bgsub.max():.1f}]")
print(f"Normalized range: [{image_norm.min():.4f}, {image_norm.max():.4f}]")

# ============================================================
# 3. COMPUTE 2D FFT FOR LATTICE ANALYSIS
# ============================================================
print("Computing FFT...")

# Apply Hann window to reduce edge artifacts
window_y = np.hanning(H)
window_x = np.hanning(W)
window_2d = np.outer(window_y, window_x)
image_windowed = (image_norm - image_norm.mean()) * window_2d

fft_2d = np.fft.fft2(image_windowed)
fft_shifted = np.fft.fftshift(fft_2d)
power_spectrum = np.abs(fft_shifted)**2
log_ps = np.log1p(power_spectrum)

# Pixel size calculation: 20.88 nm / 1024 px = 0.02039 nm/px
fov_nm = 20.88
pixel_size_nm = fov_nm / W  # ~0.02039 nm/px
print(f"Pixel size: {pixel_size_nm:.5f} nm/px")

# Find FFT peaks (excluding DC)
center_y, center_x = H // 2, W // 2

# Mask out DC region
dc_mask_radius = 10
log_ps_masked = log_ps.copy()
y_grid, x_grid = np.ogrid[0:H, 0:W]
dc_mask = (y_grid - center_y)**2 + (x_grid - center_x)**2 < dc_mask_radius**2
log_ps_masked[dc_mask] = 0

# Find peaks in FFT
from skimage.feature import peak_local_max

fft_peaks = peak_local_max(log_ps_masked, min_distance=5, num_peaks=40, threshold_rel=0.3)
print(f"Found {len(fft_peaks)} FFT peaks")

# Calculate spatial frequencies and real-space periodicities for each peak
fft_peak_info = []
for pk in fft_peaks:
    dy = pk[0] - center_y
    dx = pk[1] - center_x
    freq_px = np.sqrt(dy**2 + dx**2)  # frequency in pixels
    if freq_px < 3:
        continue
    period_px = H / freq_px  # period in pixels
    period_nm = period_px * pixel_size_nm
    angle = np.degrees(np.arctan2(dy, dx))
    fft_peak_info.append({
        'y': int(pk[0]), 'x': int(pk[1]),
        'dy': dy, 'dx': dx,
        'freq_px': float(freq_px),
        'period_px': float(period_px),
        'period_nm': float(period_nm),
        'angle_deg': float(angle),
        'intensity': float(log_ps[pk[0], pk[1]])
    })

fft_peak_info.sort(key=lambda p: p['intensity'], reverse=True)

print("\nTop FFT peaks (sorted by intensity):")
for i, p in enumerate(fft_peak_info[:20]):
    print(f"  Peak {i}: period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f}\u00b0, intensity={p['intensity']:.1f}")

# Identify fundamental lattice peaks (~0.39-0.40 nm for perovskite)
fundamental_peaks = [p for p in fft_peak_info if 0.35 < p['period_nm'] < 0.45]
superstructure_peaks = [p for p in fft_peak_info if 0.75 < p['period_nm'] < 0.95]

print(f"\nFundamental peaks (~0.39 nm): {len(fundamental_peaks)}")
for p in fundamental_peaks[:6]:
    print(f"  period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f}\u00b0")

print(f"Superstructure peaks (~0.835 nm): {len(superstructure_peaks)}")
for p in superstructure_peaks[:6]:
    print(f"  period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f}\u00b0")

# Check for rational fraction relationships
# If fundamental ~0.39 nm and superstructure ~0.78-0.84 nm, that's ~2x
super_analysis = []
for sp in superstructure_peaks:
    for fp in fundamental_peaks:
        ratio = sp['period_nm'] / fp['period_nm']
        if 1.8 < ratio < 2.2:
            super_analysis.append({
                'super_period_nm': sp['period_nm'],
                'fund_period_nm': fp['period_nm'],
                'ratio': ratio,
                'super_angle': sp['angle_deg'],
                'fund_angle': fp['angle_deg']
            })

print(f"\nSuperstructure-fundamental relationships found: {len(super_analysis)}")
for sa in super_analysis[:5]:
    print(f"  Super={sa['super_period_nm']:.3f} nm / Fund={sa['fund_period_nm']:.3f} nm = {sa['ratio']:.2f}x, angles: {sa['super_angle']:.1f}\u00b0 / {sa['fund_angle']:.1f}\u00b0")

# ============================================================
# 4. DETECT ATOMIC COLUMNS USING DCNN
# ============================================================
print("\nDetecting atomic columns with DCNN...")
from scilink.tools.atom_finding_tools import detect_atoms, detect_atoms_dcnn, refine_positions, find_zone_axes, find_missing_atoms, subtract_atoms

dcnn_result = detect_atoms_dcnn(image_norm, fov_nm=fov_nm, threshold=0.5, refine=False)
positions_dcnn = dcnn_result['positions']  # (N, 2) as (x, y)
print(f"DCNN detected {len(positions_dcnn)} columns")

# ============================================================
# 5. EDGE ARTIFACT CLEANUP
# ============================================================
margin = 7
mask_edge = (
    (positions_dcnn[:, 0] > margin) & (positions_dcnn[:, 0] < W - margin) &
    (positions_dcnn[:, 1] > margin) & (positions_dcnn[:, 1] < H - margin)
)
positions_clean = positions_dcnn[mask_edge]
print(f"After edge cleanup: {len(positions_clean)} columns (removed {len(positions_dcnn) - len(positions_clean)})")

# ============================================================
# 6. REFINE POSITIONS WITH 2D GAUSSIAN FITTING
# ============================================================
print("Refining positions with 2D Gaussian fitting...")
try:
    refined = refine_positions(image_norm, positions_clean, percent_to_nn=0.4)
    positions_refined = refined['positions']
    amplitudes = refined['amplitude']
    sigma_x = refined['sigma_x']
    sigma_y = refined['sigma_y']
    rotation = refined['rotation']
    print(f"Refined {len(positions_refined)} columns")
    print(f"Amplitude range: [{np.nanmin(amplitudes):.4f}, {np.nanmax(amplitudes):.4f}]")
    print(f"Mean amplitude: {np.nanmean(amplitudes):.4f}")
except Exception as e:
    print(f"Refinement failed: {e}, using DCNN positions")
    positions_refined = positions_clean
    amplitudes = np.zeros(len(positions_clean))
    sigma_x = np.ones(len(positions_clean)) * 2.0
    sigma_y = np.ones(len(positions_clean)) * 2.0
    rotation = np.zeros(len(positions_clean))

# Remove NaN amplitudes
valid_mask = ~np.isnan(amplitudes) & ~np.isnan(positions_refined[:, 0]) & ~np.isnan(positions_refined[:, 1])
positions_refined = positions_refined[valid_mask]
amplitudes = amplitudes[valid_mask]
sigma_x = sigma_x[valid_mask]
sigma_y = sigma_y[valid_mask]
rotation = rotation[valid_mask]
print(f"After NaN removal: {len(positions_refined)} columns")

# ============================================================
# 7. FIND ZONE AXES / LATTICE VECTORS
# ============================================================
print("\nFinding zone axes...")
try:
    zone_axes = find_zone_axes(positions_refined, n_neighbors=12, distance_tolerance=None)
    print(f"Found {len(zone_axes)} zone axis vectors:")
    for i, zv in enumerate(zone_axes):
        length_px = np.sqrt(zv[0]**2 + zv[1]**2)
        length_nm = length_px * pixel_size_nm
        angle = np.degrees(np.arctan2(zv[1], zv[0]))
        print(f"  Vector {i}: ({zv[0]:.2f}, {zv[1]:.2f}) px, length={length_px:.2f} px = {length_nm:.3f} nm, angle={angle:.1f}\u00b0")
except Exception as e:
    print(f"Zone axis finding failed: {e}")
    zone_axes = []

# Determine the two primary lattice vectors
lattice_vectors = []
if len(zone_axes) >= 2:
    lattice_vectors = zone_axes[:2]
    lv1 = lattice_vectors[0]
    lv2 = lattice_vectors[1]
    lv1_len_nm = np.sqrt(lv1[0]**2 + lv1[1]**2) * pixel_size_nm
    lv2_len_nm = np.sqrt(lv2[0]**2 + lv2[1]**2) * pixel_size_nm
    lv1_angle = np.degrees(np.arctan2(lv1[1], lv1[0]))
    lv2_angle = np.degrees(np.arctan2(lv2[1], lv2[0]))
    inter_angle = abs(lv2_angle - lv1_angle)
    if inter_angle > 180:
        inter_angle = 360 - inter_angle
    print(f"\nLattice vector 1: {lv1_len_nm:.3f} nm at {lv1_angle:.1f}\u00b0")
    print(f"Lattice vector 2: {lv2_len_nm:.3f} nm at {lv2_angle:.1f}\u00b0")
    print(f"Inter-vector angle: {inter_angle:.1f}\u00b0")
else:
    lv1_len_nm = 0
    lv2_len_nm = 0
    inter_angle = 0

# ============================================================
# 8. GEOMETRY-BASED SUBLATTICE ASSIGNMENT
# ============================================================
print("\nAssigning sublattices by geometry...")

if len(lattice_vectors) >= 2:
    lv1 = np.array(lattice_vectors[0])
    lv2 = np.array(lattice_vectors[1])
    
    # Build transformation matrix from pixel coords to fractional coords
    # pos = n1 * lv1 + n2 * lv2 + origin
    # We need the inverse: fractional = M^-1 * (pos - origin)
    M = np.column_stack([lv1, lv2])  # 2x2 matrix
    M_inv = np.linalg.inv(M)
    
    # Use centroid as reference origin
    origin = np.mean(positions_refined, axis=0)
    
    # Project each position to fractional coordinates
    rel_pos = positions_refined - origin  # (N, 2)
    frac_coords = (M_inv @ rel_pos.T).T  # (N, 2)
    
    # Get fractional part (within unit cell)
    frac_part = frac_coords - np.floor(frac_coords)  # in [0, 1)
    
    # In perovskite ABO3 projected along [001]:
    # A-site (La): at corners (0,0) \u2192 frac ~(0,0) or (1,1) etc.
    # B-site (Ti): at body center (0.5, 0.5)
    # We classify based on distance to (0,0) vs (0.5, 0.5) in fractional space
    
    # Distance to corner (considering periodic boundaries)
    def periodic_dist_to_point(frac, target):
        """Compute minimum distance in fractional coordinates considering periodicity"""
        diff = frac - target
        # Consider periodic images
        diff = diff - np.round(diff)
        return np.sqrt(np.sum(diff**2, axis=1))
    
    dist_to_corner = periodic_dist_to_point(frac_part, np.array([0.0, 0.0]))
    dist_to_center = periodic_dist_to_point(frac_part, np.array([0.5, 0.5]))
    
    # Assign: A-site if closer to corner, B-site if closer to center
    sublattice_labels = np.where(dist_to_corner < dist_to_center, 0, 1)  # 0=A-site(La), 1=B-site(Ti)
    
    n_a_site = np.sum(sublattice_labels == 0)
    n_b_site = np.sum(sublattice_labels == 1)
    print(f"A-site (La): {n_a_site} columns")
    print(f"B-site (Ti): {n_b_site} columns")
    print(f"A/B ratio: {n_a_site/max(n_b_site,1):.3f}")
    
    # Amplitude statistics per sublattice
    amp_a = amplitudes[sublattice_labels == 0]
    amp_b = amplitudes[sublattice_labels == 1]
    
    print(f"\nA-site amplitude: mean={np.mean(amp_a):.4f}, std={np.std(amp_a):.4f}")
    print(f"B-site amplitude: mean={np.mean(amp_b):.4f}, std={np.std(amp_b):.4f}")
    
    # Secondary validation: In HAADF, La (Z=57) should be brighter than Ti (Z=22)
    # Check if assignment is consistent
    if np.mean(amp_a) < np.mean(amp_b):
        print("WARNING: A-site has lower amplitude than B-site - swapping labels")
        sublattice_labels = 1 - sublattice_labels
        n_a_site, n_b_site = n_b_site, n_a_site
        amp_a, amp_b = amp_b, amp_a
        print(f"After swap - A-site (La): {n_a_site}, B-site (Ti): {n_b_site}")
    
    # Otsu thresholding within each sublattice for anomaly detection
    from skimage.filters import threshold_otsu
    
    anomalous_a = np.zeros(len(amp_a), dtype=bool)
    anomalous_b = np.zeros(len(amp_b), dtype=bool)
    
    try:
        if len(amp_a) > 10:
            otsu_a = threshold_otsu(amp_a)
            anomalous_a = amp_a < otsu_a
            print(f"A-site Otsu threshold: {otsu_a:.4f}, anomalous (below): {np.sum(anomalous_a)}")
    except Exception:
        pass
    
    try:
        if len(amp_b) > 10:
            otsu_b = threshold_otsu(amp_b)
            anomalous_b = amp_b < otsu_b
            print(f"B-site Otsu threshold: {otsu_b:.4f}, anomalous (below): {np.sum(anomalous_b)}")
    except Exception:
        pass
else:
    print("Insufficient lattice vectors for sublattice assignment")
    sublattice_labels = np.zeros(len(positions_refined), dtype=int)
    n_a_site = len(positions_refined)
    n_b_site = 0
    amp_a = amplitudes
    amp_b = np.array([])

# ============================================================
# 9. NEAREST-NEIGHBOR DISTANCES
# ============================================================
print("\nComputing nearest-neighbor distances...")
from scipy.spatial import cKDTree

tree = cKDTree(positions_refined)
nn_dists, nn_indices = tree.query(positions_refined, k=2)  # k=2: self + nearest
nn_dists_all = nn_dists[:, 1]  # exclude self
nn_dists_nm = nn_dists_all * pixel_size_nm

print(f"Overall NN distance: mean={np.mean(nn_dists_nm):.3f} nm, std={np.std(nn_dists_nm):.3f} nm")

# Per sublattice NN distances
if n_b_site > 0:
    pos_a = positions_refined[sublattice_labels == 0]
    pos_b = positions_refined[sublattice_labels == 1]
    
    if len(pos_a) > 1:
        tree_a = cKDTree(pos_a)
        nn_a = tree_a.query(pos_a, k=2)[0][:, 1] * pixel_size_nm
        print(f"A-site NN distance: mean={np.mean(nn_a):.3f} nm, std={np.std(nn_a):.3f} nm")
    else:
        nn_a = np.array([])
    
    if len(pos_b) > 1:
        tree_b = cKDTree(pos_b)
        nn_b = tree_b.query(pos_b, k=2)[0][:, 1] * pixel_size_nm
        print(f"B-site NN distance: mean={np.mean(nn_b):.3f} nm, std={np.std(nn_b):.3f} nm")
    else:
        nn_b = np.array([])
else:
    nn_a = nn_dists_nm
    nn_b = np.array([])

# ============================================================
# 10. FIND MISSING ATOMS
# ============================================================
print("\nSearching for missing atoms...")
missing_atoms_found = 0
if len(zone_axes) >= 1:
    try:
        for i, zv in enumerate(zone_axes[:2]):
            missing = find_missing_atoms(positions_refined, zv, fraction=0.5, min_distance=3.0)
            if missing is not None and len(missing) > 0:
                # Check if these are within image bounds and have intensity
                in_bounds = (
                    (missing[:, 0] > margin) & (missing[:, 0] < W - margin) &
                    (missing[:, 1] > margin) & (missing[:, 1] < H - margin)
                )
                missing_in_bounds = missing[in_bounds]
                
                # Check intensity at predicted positions
                if len(missing_in_bounds) > 0:
                    mx = np.clip(missing_in_bounds[:, 0].astype(int), 0, W-1)
                    my = np.clip(missing_in_bounds[:, 1].astype(int), 0, H-1)
                    intensities_at_missing = image_norm[my, mx]
                    
                    # Keep only those with reasonable intensity (above median background)
                    bg_threshold = np.percentile(image_norm, 30)
                    valid_missing = missing_in_bounds[intensities_at_missing > bg_threshold]
                    missing_atoms_found += len(valid_missing)
                    print(f"  Zone vector {i}: {len(valid_missing)} valid missing atoms found")
    except Exception as e:
        print(f"Missing atom search failed: {e}")

print(f"Total missing atoms found: {missing_atoms_found}")

# ============================================================
# 11. SUPERSTRUCTURE ANALYSIS
# ============================================================
print("\nSuperstructure analysis...")

# Explicitly check for peaks at 1/2 and 1/3 of fundamental reciprocal vectors
superstructure_confirmed = []
if len(fundamental_peaks) > 0:
    for fp in fundamental_peaks[:4]:  # Check top 4 fundamental peaks
        # Expected 1/2-order peak position
        half_dy = fp['dy'] / 2
        half_dx = fp['dx'] / 2
        half_y = int(center_y + half_dy)
        half_x = int(center_x + half_dx)
        
        # Check if there's a peak near this position
        search_radius = 5
        if 0 <= half_y < H and 0 <= half_x < W:
            region = log_ps[max(0,half_y-search_radius):min(H,half_y+search_radius),
                           max(0,half_x-search_radius):min(W,half_x+search_radius)]
            if region.size > 0:
                local_max = np.max(region)
                local_mean = np.mean(log_ps_masked)
                local_std = np.std(log_ps_masked[log_ps_masked > 0])
                if local_max > local_mean + 3 * local_std:
                    period_nm = fp['period_nm'] * 2
                    superstructure_confirmed.append({
                        'type': '1/2-order',
                        'period_nm': period_nm,
                        'parent_period_nm': fp['period_nm'],
                        'direction_deg': fp['angle_deg'],
                        'peak_intensity': float(local_max)
                    })
                    print(f"  Confirmed 1/2-order: period={period_nm:.3f} nm along {fp['angle_deg']:.1f}\u00b0")
        
        # Expected 1/3-order peak position
        third_dy = fp['dy'] / 3
        third_dx = fp['dx'] / 3
        third_y = int(center_y + third_dy)
        third_x = int(center_x + third_dx)
        
        if 0 <= third_y < H and 0 <= third_x < W:
            region = log_ps[max(0,third_y-search_radius):min(H,third_y+search_radius),
                           max(0,third_x-search_radius):min(W,third_x+search_radius)]
            if region.size > 0:
                local_max = np.max(region)
                if local_max > local_mean + 3 * local_std:
                    period_nm = fp['period_nm'] * 3
                    superstructure_confirmed.append({
                        'type': '1/3-order',
                        'period_nm': period_nm,
                        'parent_period_nm': fp['period_nm'],
                        'direction_deg': fp['angle_deg'],
                        'peak_intensity': float(local_max)
                    })
                    print(f"  Confirmed 1/3-order: period={period_nm:.3f} nm along {fp['angle_deg']:.1f}\u00b0")

# Also check direct superstructure peak matches near 0.835 nm
peaks_near_835 = [p for p in fft_peak_info if 0.78 < p['period_nm'] < 0.90]
print(f"\nPeaks near 0.835 nm periodicity: {len(peaks_near_835)}")
for p in peaks_near_835[:4]:
    print(f"  period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f}\u00b0, intensity={p['intensity']:.1f}")

# Detection completeness
if len(lattice_vectors) >= 2:
    # Expected columns from lattice tiling
    area_image = (H * pixel_size_nm) * (W * pixel_size_nm)  # nm^2
    unit_cell_area = abs(np.cross(lv1, lv2)) * pixel_size_nm**2  # nm^2
    expected_total = 2 * area_image / unit_cell_area  # 2 atoms per unit cell (A + B)
    completeness = len(positions_refined) / expected_total if expected_total > 0 else 0
    print(f"\nUnit cell area: {unit_cell_area:.4f} nm\u00b2")
    print(f"Expected columns: ~{expected_total:.0f}")
    print(f"Detected columns: {len(positions_refined)}")
    print(f"Detection completeness: {completeness:.2f}")
else:
    expected_total = 0
    completeness = 0

# ============================================================
# 12. SAVE OUTPUT ARRAYS
# ============================================================
print("\nSaving output arrays...")

# Primary output: all positions with sublattice labels and amplitudes
output_columns = np.column_stack([
    positions_refined,  # x, y (columns 0, 1)
    sublattice_labels,  # 0=A-site, 1=B-site (column 2)
    amplitudes,  # fitted amplitude (column 3)
    sigma_x,  # sigma_x (column 4)
    sigma_y  # sigma_y (column 5)
])
np.save('analysis_positions.npy', output_columns)
print(f"Saved analysis_positions.npy: shape={output_columns.shape}")

# Save background-corrected image
np.save('analysis_bg_corrected.npy', image_norm)
print(f"Saved analysis_bg_corrected.npy: shape={image_norm.shape}")

# Save FFT power spectrum
np.save('analysis_fft_power.npy', log_ps.astype(np.float32))
print(f"Saved analysis_fft_power.npy: shape={log_ps.shape}")

# ============================================================
# 13. GENERATE VISUALIZATIONS
# ============================================================
print("\nGenerating visualizations...")

fig, axes = plt.subplots(2, 3, figsize=(18, 12), dpi=100)

# (a) Original image
ax = axes[0, 0]
ax.imshow(image_raw, cmap='gray', origin='upper')
ax.set_title(f'Original Image\n[{image_raw.min():.0f}, {image_raw.max():.0f}]', fontsize=10)
ax.axis('off')

# (b) Background-corrected + detected columns overlay
ax = axes[0, 1]
ax.imshow(image_norm, cmap='gray', origin='upper')
if n_b_site > 0:
    pos_a = positions_refined[sublattice_labels == 0]
    pos_b = positions_refined[sublattice_labels == 1]
    ax.scatter(pos_a[:, 0], pos_a[:, 1], c='red', s=2, alpha=0.6, label=f'A-site/La ({n_a_site})')
    ax.scatter(pos_b[:, 0], pos_b[:, 1], c='cyan', s=2, alpha=0.6, label=f'B-site/Ti ({n_b_site})')
else:
    ax.scatter(positions_refined[:, 0], positions_refined[:, 1], c='red', s=2, alpha=0.6, label=f'All ({len(positions_refined)})')
ax.legend(fontsize=7, loc='upper right', markerscale=3)
ax.set_title(f'Detected Columns ({len(positions_refined)} total)\non BG-corrected image', fontsize=10)
ax.axis('off')

# (c) FFT with annotated peaks
ax = axes[0, 2]
vmin = np.percentile(log_ps, 50)
vmax = np.percentile(log_ps, 99.9)
ax.imshow(log_ps, cmap='inferno', origin='upper', vmin=vmin, vmax=vmax,
          extent=[-W//2, W//2, H//2, -H//2])

# Annotate fundamental peaks
for p in fundamental_peaks[:4]:
    ax.plot(p['dx'], p['dy'], 'wo', markersize=6, markerfacecolor='none', markeredgewidth=1)
    ax.annotate(f"{p['period_nm']:.2f}nm", (p['dx'], p['dy']),
                fontsize=5, color='white', textcoords='offset points', xytext=(5, 5))

# Annotate superstructure peaks  
for p in peaks_near_835[:4]:
    ax.plot(p['dx'], p['dy'], 'g^', markersize=6, markerfacecolor='none', markeredgewidth=1.5)
    ax.annotate(f"{p['period_nm']:.2f}nm", (p['dx'], p['dy']),
                fontsize=5, color='lime', textcoords='offset points', xytext=(5, -10))

ax.set_title('FFT Power Spectrum\n(white=fundamental, green=superstructure)', fontsize=10)
ax.set_xlim(-W//4, W//4)
ax.set_ylim(H//4, -H//4)

# (d) Amplitude histogram by sublattice
ax = axes[1, 0]
if n_b_site > 0:
    ax.hist(amp_a, bins=50, alpha=0.6, color='red', label=f'A-site/La (n={n_a_site})', density=True)
    ax.hist(amp_b, bins=50, alpha=0.6, color='cyan', label=f'B-site/Ti (n={n_b_site})', density=True)
    ax.legend(fontsize=8)
else:
    ax.hist(amplitudes, bins=50, alpha=0.7, color='blue', density=True)
ax.set_xlabel('Gaussian Amplitude', fontsize=9)
ax.set_ylabel('Density', fontsize=9)
ax.set_title('Amplitude Distribution by Sublattice', fontsize=10)

# (e) NN distance distribution
ax = axes[1, 1]
if n_b_site > 0 and len(nn_a) > 0 and len(nn_b) > 0:
    ax.hist(nn_a, bins=50, alpha=0.6, color='red', label='A-site NN', density=True)
    ax.hist(nn_b, bins=50, alpha=0.6, color='cyan', label='B-site NN', density=True)
    ax.legend(fontsize=8)
else:
    ax.hist(nn_dists_nm, bins=50, alpha=0.7, color='blue', density=True)
ax.set_xlabel('NN Distance (nm)', fontsize=9)
ax.set_ylabel('Density', fontsize=9)
ax.set_title('Nearest-Neighbor Distance Distribution', fontsize=10)

# (f) Zoomed-in view with sublattice overlay
ax = axes[1, 2]
zoom_size = 200
zx, zy = W//2 - zoom_size//2, H//2 - zoom_size//2
ax.imshow(image_norm[zy:zy+zoom_size, zx:zx+zoom_size], cmap='gray', origin='upper',
          extent=[zx, zx+zoom_size, zy+zoom_size, zy])
if n_b_site > 0:
    # Filter positions in zoom region
    for lbl, color, name in [(0, 'red', 'La'), (1, 'cyan', 'Ti')]:
        mask = sublattice_labels == lbl
        pos = positions_refined[mask]
        in_zoom = (pos[:, 0] > zx) & (pos[:, 0] < zx+zoom_size) & (pos[:, 1] > zy) & (pos[:, 1] < zy+zoom_size)
        if np.any(in_zoom):
            ax.scatter(pos[in_zoom, 0], pos[in_zoom, 1], c=color, s=15, alpha=0.8,
                      edgecolors='white', linewidths=0.3, label=name)
    ax.legend(fontsize=8, loc='upper right')
ax.set_title(f'Zoomed Center ({zoom_size}\u00d7{zoom_size} px)', fontsize=10)
ax.axis('off')

plt.suptitle(f'LLTO STEM Analysis \u2014 {len(positions_refined)} Atomic Columns Detected\n'
             f'Lattice: {lv1_len_nm:.3f} nm \u00d7 {lv2_len_nm:.3f} nm, angle={inter_angle:.1f}\u00b0',
             fontsize=13, fontweight='bold')
plt.tight_layout(rect=[0, 0, 1, 0.94])
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("Saved analysis_visualization.png")

# ============================================================
# 14. BUILD RESULTS JSON
# ============================================================
print("\nBuilding results JSON...")

# Prepare FFT peaks for JSON (top 10)
fft_peaks_json = []
for p in fft_peak_info[:10]:
    fft_peaks_json.append({
        'period_nm': round(p['period_nm'], 4),
        'angle_deg': round(p['angle_deg'], 1),
        'intensity': round(p['intensity'], 2)
    })

superstructure_json = []
for sc in superstructure_confirmed:
    superstructure_json.append({
        'type': sc['type'],
        'period_nm': round(sc['period_nm'], 4),
        'parent_period_nm': round(sc['parent_period_nm'], 4),
        'direction_deg': round(sc['direction_deg'], 1)
    })

for p in peaks_near_835:
    superstructure_json.append({
        'type': 'direct_peak',
        'period_nm': round(p['period_nm'], 4),
        'angle_deg': round(p['angle_deg'], 1),
        'intensity': round(p['intensity'], 2)
    })

results = {
    "analysis_type": "STEM atomic column detection and sublattice analysis of LLTO perovskite with polynomial background correction, DCNN detection, geometry-based sublattice assignment, and FFT superstructure analysis",
    "extracted_features": {
        "total_columns_detected": int(len(positions_refined)),
        "a_site_La_count": int(n_a_site),
        "b_site_Ti_count": int(n_b_site),
        "a_to_b_ratio": round(n_a_site / max(n_b_site, 1), 4),
        "lattice_vector_1_nm": round(lv1_len_nm, 4),
        "lattice_vector_2_nm": round(lv2_len_nm, 4),
        "lattice_vector_1_angle_deg": round(np.degrees(np.arctan2(lattice_vectors[0][1], lattice_vectors[0][0])), 2) if len(lattice_vectors) >= 1 else None,
        "lattice_vector_2_angle_deg": round(np.degrees(np.arctan2(lattice_vectors[1][1], lattice_vectors[1][0])), 2) if len(lattice_vectors) >= 2 else None,
        "inter_vector_angle_deg": round(inter_angle, 2),
        "pixel_size_nm": round(pixel_size_nm, 5),
        "fov_nm": fov_nm,
        "amplitude_a_site_mean": round(float(np.mean(amp_a)), 5) if len(amp_a) > 0 else None,
        "amplitude_a_site_std": round(float(np.std(amp_a)), 5) if len(amp_a) > 0 else None,
        "amplitude_b_site_mean": round(float(np.mean(amp_b)), 5) if len(amp_b) > 0 else None,
        "amplitude_b_site_std": round(float(np.std(amp_b)), 5) if len(amp_b) > 0 else None,
        "nn_distance_overall_mean_nm": round(float(np.mean(nn_dists_nm)), 4),
        "nn_distance_overall_std_nm": round(float(np.std(nn_dists_nm)), 4),
        "nn_distance_a_site_mean_nm": round(float(np.mean(nn_a)), 4) if len(nn_a) > 0 else None,
        "nn_distance_b_site_mean_nm": round(float(np.mean(nn_b)), 4) if len(nn_b) > 0 else None,
        "fft_top_peaks": fft_peaks_json,
        "fundamental_peak_periods_nm": [round(p['period_nm'], 4) for p in fundamental_peaks[:4]],
        "superstructure_peaks": superstructure_json,
        "peaks_near_0835nm": [{'period_nm': round(p['period_nm'], 4), 'angle_deg': round(p['angle_deg'], 1)} for p in peaks_near_835[:4]],
        "missing_atoms_found": missing_atoms_found,
        "expected_total_columns": int(round(expected_total)) if expected_total > 0 else None,
        "detection_completeness": round(completeness, 3) if completeness > 0 else None
    },
    "quality_metrics": {
        "dcnn_raw_detections": int(len(positions_dcnn)),
        "after_edge_cleanup": int(len(positions_clean)),
        "after_refinement": int(len(positions_refined)),
        "bg_correction_applied": True,
        "polynomial_order": 3,
        "image_shape": list(image_raw.shape),
        "raw_intensity_range": [float(image_raw.min()), float(image_raw.max())],
        "corrected_intensity_range": [float(image_norm.min()), float(image_norm.max())]
    },
    "summary": f"Detected {len(positions_refined)} atomic columns in LLTO perovskite STEM image after 3rd-order polynomial background subtraction. "
               f"Geometry-based sublattice assignment identified {n_a_site} A-site (La) and {n_b_site} B-site (Ti) columns. "
               f"Lattice vectors: {lv1_len_nm:.3f} nm and {lv2_len_nm:.3f} nm at {inter_angle:.1f}\u00b0 inter-angle. "
               f"FFT analysis found {len(fundamental_peaks)} fundamental peaks near 0.39 nm and {len(peaks_near_835)} peaks near 0.835 nm superstructure periodicity. "
               f"Detection completeness: {completeness:.1%}. "
               f"DCNN threshold=0.5 used for broad detection coverage; background correction critical for uniform detection across the full field of view.",
    "saved_arrays": {
        "analysis_positions.npy": {
            "description": f"Atomic column data: columns [x_px, y_px, sublattice_label(0=A/La,1=B/Ti), gaussian_amplitude, sigma_x, sigma_y] for {len(positions_refined)} detected columns",
            "shape": list(output_columns.shape),
            "dtype": str(output_columns.dtype)
        },
        "analysis_bg_corrected.npy": {
            "description": "Background-corrected and normalized image (0-1 range) after 3rd-order polynomial subtraction",
            "shape": list(image_norm.shape),
            "dtype": str(image_norm.dtype)
        },
        "analysis_fft_power.npy": {
            "description": "Log power spectrum of background-corrected image (Hann-windowed, FFT-shifted)",
            "shape": list(log_ps.shape),
            "dtype": "float32"
        }
    }
}

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
