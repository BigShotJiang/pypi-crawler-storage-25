"""
BO Agent vs Classical BO — benchmark comparison with multi-seed statistics.

Compares three approaches on synthetic objective functions:
  1. Random search (baseline)
  2. Classical BO (fixed Matern 2.5 + LogEI, no LLM)
  3. SciLink BO Agent (LLM-adaptive strategy selection)

Each benchmark is repeated across N_SEEDS independent seeds.  Results are
reported as mean +/- std and plotted with shaded confidence bands.

Outputs (in tests/bo_comparison_results/):
  - Per-benchmark convergence plots with mean +/- 1 std bands
  - Summary bar chart with error bars
  - comparison_results.json with per-seed histories
  - Printed tables with mean +/- std metrics

Requires an LLM API key for the agent tests. Run with:

    GEMINI_API_KEY=<key> python tests/test_bo_comparison.py

To skip agent tests (classical + random only):

    python tests/test_bo_comparison.py --no-agent

To override the number of seeds (default 5):

    python tests/test_bo_comparison.py --seeds 10
"""

import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

os.environ.setdefault("UNSAFE_EXECUTION_OK", "true")

from scilink.tools.bo_tools import get_optimizer
from scilink.agents.planning_agents.bo_agent import BOAgent

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_MODEL = os.environ.get("SCILINK_TEST_MODEL", "gemini-3.1-pro-preview")
_API_KEY = os.environ.get("SCILINK_TEST_API_KEY") or os.environ.get("GEMINI_API_KEY", "")
_SKIP_AGENT = "--no-agent" in sys.argv
_OUTPUT_DIR = Path(__file__).parent / "bo_comparison_results"

# Parse --seeds N
N_SEEDS = 3
for i, arg in enumerate(sys.argv):
    if arg == "--seeds" and i + 1 < len(sys.argv):
        N_SEEDS = int(sys.argv[i + 1])
        break

SEEDS = list(range(N_SEEDS))

# ---------------------------------------------------------------------------
# Benchmark functions
# ---------------------------------------------------------------------------

def branin(x1, x2):
    """Branin — 3 global minima ~ 0.398. Domain: x1 in [-5,10], x2 in [0,15]."""
    a, b, c = 1, 5.1 / (4 * np.pi**2), 5 / np.pi
    r, s, t = 6, 10, 1 / (8 * np.pi)
    return a * (x2 - b * x1**2 + c * x1 - r)**2 + s * (1 - t) * np.cos(x1) + s


def quadratic_1d(x):
    """1D quadratic, minimum at x=3, f(3)=0. Domain: [0, 6]."""
    return (x - 3) ** 2


def sphere_3d(x1, x2, x3):
    """3D sphere, minimum at origin, f(0,0,0)=0. Domain: [-5, 5]^3."""
    return x1**2 + x2**2 + x3**2


def ackley_2d(x1, x2):
    """Ackley 2D — many local minima, global minimum = 0 at origin.
    Domain: [-5, 5]^2. Tests exploration vs exploitation."""
    a, b, c = 20, 0.2, 2 * np.pi
    s1 = -a * np.exp(-b * np.sqrt(0.5 * (x1**2 + x2**2)))
    s2 = -np.exp(0.5 * (np.cos(c * x1) + np.cos(c * x2)))
    return s1 + s2 + a + np.e


BENCHMARKS = {
    "branin_2d": {
        "func": branin,
        "bounds": [[-5.0, 10.0], [0.0, 15.0]],
        "col_names": ["x1", "x2"],
        "global_min": 0.397887,
        "n_init": 8,
        "n_iters": 15,
    },
    "ackley_2d": {
        "func": ackley_2d,
        "bounds": [[-5.0, 5.0], [-5.0, 5.0]],
        "col_names": ["x1", "x2"],
        "global_min": 0.0,
        "n_init": 10,
        "n_iters": 15,
    },
}


# ---------------------------------------------------------------------------
# Data generation
# ---------------------------------------------------------------------------

def generate_initial_data(func, bounds, n, col_names, seed=42):
    """Random initial data with controlled seed."""
    rng = np.random.RandomState(seed)
    n_dims = len(bounds)
    X = np.zeros((n, n_dims))
    for i, (lo, hi) in enumerate(bounds):
        X[:, i] = rng.uniform(lo, hi, n)
    y = np.array([func(*row) for row in X])
    data = {col_names[i]: X[:, i] for i in range(n_dims)}
    data["y"] = y
    return pd.DataFrame(data)


# ---------------------------------------------------------------------------
# Approach 1: Random search
# ---------------------------------------------------------------------------

def run_random_search(func, bounds, col_names, n_init, n_iters, seed=42):
    """Uniform random sampling — the baseline."""
    rng = np.random.RandomState(seed)
    df = generate_initial_data(func, bounds, n_init, col_names, seed=seed)

    best_history = []
    times = []

    for _ in range(n_iters):
        t0 = time.time()
        x_new = np.array([rng.uniform(lo, hi) for lo, hi in bounds])
        y_new = func(*x_new)
        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        best_history.append(df["y"].min())
        times.append(time.time() - t0)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
    }


# ---------------------------------------------------------------------------
# Approach 2: Classical BO (fixed strategy, no LLM)
# ---------------------------------------------------------------------------

def run_classical_bo(func, bounds, col_names, n_init, n_iters, seed=42,
                     kernel="matern_2.5", noise="fixed_low",
                     strategy="log_ei"):
    """Textbook BO: fixed GP kernel + fixed acquisition function."""
    np.random.seed(seed)
    df = generate_initial_data(func, bounds, n_init, col_names, seed=seed)
    optimizer = get_optimizer(is_moo=False, device="cpu")

    best_history = []
    times = []

    for step in range(n_iters):
        t0 = time.time()
        X = df[col_names].values.astype(np.float64)
        y_raw = df[["y"]].values.astype(np.float64)
        y_train = -y_raw  # BO maximizes internally; negate for minimization

        model_config = {"kernel": kernel, "noise": noise}
        optimizer.fit(X, y_train, np.array(bounds, dtype=np.float64),
                      model_config, col_names)

        candidates = optimizer.recommend(n_candidates=1, strategy=strategy, params={})
        x_new = candidates[0]
        y_new = func(*x_new)

        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)

        best_history.append(df["y"].min())
        times.append(time.time() - t0)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
    }


# ---------------------------------------------------------------------------
# Approach 3: SciLink BO Agent (LLM-adaptive)
# ---------------------------------------------------------------------------

def run_scilink_agent(func, bounds, col_names, n_init, n_iters, seed=42):
    """SciLink BOAgent — LLM chooses kernel, acquisition, noise each step."""
    df = generate_initial_data(func, bounds, n_init, col_names, seed=seed)

    tmpdir = Path(tempfile.mkdtemp(prefix="bo_cmp_agent_"))
    data_path = tmpdir / "data.csv"
    output_dir = tmpdir / "bo_artifacts"
    output_dir.mkdir()
    df.to_csv(data_path, index=False)

    agent = BOAgent(api_key=_API_KEY, model_name=_MODEL, output_dir=str(tmpdir))

    best_history = []
    times = []
    strategies_used = []

    for step in range(n_iters):
        t0 = time.time()
        try:
            result = agent.run_optimization_loop(
                data_path=str(data_path),
                objective_text="Minimize y",
                input_cols=col_names,
                input_bounds=bounds,
                target_cols=["y"],
                target_directions={"y": "minimize"},
                output_dir=str(output_dir),
                batch_size=1,
                experimental_budget=n_iters - step,
            )
        except Exception as e:
            print(f"  [agent] seed={seed} step={step} error: {e}")
            best_history.append(df["y"].min())
            times.append(time.time() - t0)
            strategies_used.append({"error": str(e)})
            continue

        elapsed = time.time() - t0

        if result.get("status") != "success":
            print(f"  [agent] seed={seed} step={step} failed: {result.get('error', 'unknown')}")
            best_history.append(df["y"].min())
            times.append(elapsed)
            strategies_used.append({"error": result.get("error", "unknown")})
            continue

        params = result["next_parameters"]
        x_new = np.array([params[c] for c in col_names])
        y_new = func(*x_new)

        row = {col_names[i]: x_new[i] for i in range(len(col_names))}
        row["y"] = y_new
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        df.to_csv(data_path, index=False)

        best_history.append(df["y"].min())
        times.append(elapsed)
        strategies_used.append(result.get("strategy", {}))

    shutil.rmtree(tmpdir, ignore_errors=True)

    return {
        "best_history": best_history,
        "final_best": best_history[-1],
        "times": times,
        "strategies_used": strategies_used,
    }


# ---------------------------------------------------------------------------
# Multi-seed runner
# ---------------------------------------------------------------------------

def run_multi_seed(runner_fn, func, bounds, col_names, n_init, n_iters, seeds):
    """Run a single approach across multiple seeds, collect per-seed histories."""
    all_histories = []
    all_times = []
    all_strategies = []

    for seed in seeds:
        res = runner_fn(func, bounds, col_names, n_init, n_iters, seed=seed)
        all_histories.append(res["best_history"])
        all_times.append(res["times"])
        if "strategies_used" in res:
            all_strategies.append(res["strategies_used"])

    # Stack into (n_seeds, n_iters) arrays
    histories = np.array(all_histories)   # (n_seeds, n_iters)
    times_arr = np.array(all_times)       # (n_seeds, n_iters)

    return {
        "histories": histories,
        "mean_history": histories.mean(axis=0),
        "std_history": histories.std(axis=0),
        "min_history": histories.min(axis=0),
        "max_history": histories.max(axis=0),
        "mean_times": times_arr.mean(axis=0),
        "all_strategies": all_strategies,
        "n_seeds": len(seeds),
    }


# ---------------------------------------------------------------------------
# Metrics (computed on aggregated results)
# ---------------------------------------------------------------------------

def compute_metrics(agg, global_min):
    """Compute comparison metrics from aggregated multi-seed results."""
    mean_h = agg["mean_history"]
    std_h = agg["std_history"]
    histories = agg["histories"]

    # Final regret: mean and std across seeds
    final_regrets = histories[:, -1] - global_min
    mean_final_regret = final_regrets.mean()
    std_final_regret = final_regrets.std()

    # Cumulative regret per seed, then average
    regrets_all = histories - global_min  # (n_seeds, n_iters)
    cum_regrets = regrets_all.sum(axis=1)  # (n_seeds,)
    mean_cum_regret = cum_regrets.mean()
    std_cum_regret = cum_regrets.std()

    # Iterations to reach regret < 1.0 (per seed, then median)
    iters_per_seed = []
    for row in regrets_all:
        found = np.where(row < 1.0)[0]
        iters_per_seed.append(int(found[0]) + 1 if len(found) > 0 else None)

    valid_iters = [i for i in iters_per_seed if i is not None]
    median_iters = float(np.median(valid_iters)) if valid_iters else None
    frac_reached = len(valid_iters) / len(iters_per_seed)

    # Time
    total_times = agg["mean_times"].sum()

    return {
        "mean_final_regret": mean_final_regret,
        "std_final_regret": std_final_regret,
        "mean_cum_regret": mean_cum_regret,
        "std_cum_regret": std_cum_regret,
        "median_iters_to_threshold": median_iters,
        "frac_reached_threshold": frac_reached,
        "mean_total_time_s": total_times,
        "mean_final_best": mean_h[-1],
        "std_final_best": std_h[-1],
    }


# ---------------------------------------------------------------------------
# Plotting
# ---------------------------------------------------------------------------

COLORS = {"Random": "#999999", "Classical BO": "#2196F3", "SciLink Agent": "#E91E63"}
LINESTYLES = {"Random": "--", "Classical BO": "-", "SciLink Agent": "-"}


def plot_comparison(benchmark_name, global_min, agg_results, save_dir):
    """Convergence plot with mean line and +/- 1 std shaded band."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left panel: best value found (linear scale)
    ax = axes[0]
    for name, agg in agg_results.items():
        iters = np.arange(1, len(agg["mean_history"]) + 1)
        mean = agg["mean_history"]
        std = agg["std_history"]
        ax.plot(iters, mean, color=COLORS[name], linestyle=LINESTYLES[name],
                linewidth=2, label=f'{name} (n={agg["n_seeds"]})')
        ax.fill_between(iters, mean - std, mean + std,
                        color=COLORS[name], alpha=0.15)
    ax.axhline(global_min, color="green", linestyle=":", linewidth=1,
               label=f"Global min = {global_min:.3f}")
    ax.set_xlabel("BO Iteration")
    ax.set_ylabel("Best Value Found")
    ax.set_title(f"{benchmark_name} — Convergence (mean +/- 1 std)")
    ax.legend()
    ax.grid(True, alpha=0.3)

    # Right panel: simple regret (log scale)
    ax = axes[1]
    for name, agg in agg_results.items():
        iters = np.arange(1, len(agg["mean_history"]) + 1)
        mean_regret = np.maximum(agg["mean_history"] - global_min, 1e-10)
        ax.semilogy(iters, mean_regret, color=COLORS[name],
                     linestyle=LINESTYLES[name], linewidth=2, label=name)
        # Shade between min and max regret across seeds
        lo = np.maximum(agg["min_history"] - global_min, 1e-10)
        hi = np.maximum(agg["max_history"] - global_min, 1e-10)
        ax.fill_between(iters, lo, hi, color=COLORS[name], alpha=0.10)
    ax.set_xlabel("BO Iteration")
    ax.set_ylabel("Simple Regret (log)")
    ax.set_title(f"{benchmark_name} — Regret (mean, shaded=min/max)")
    ax.legend()
    ax.grid(True, alpha=0.3)

    fig.tight_layout()
    save_path = save_dir / f"{benchmark_name}_comparison.png"
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    return str(save_path)


def plot_summary(all_metrics, save_dir):
    """Summary bar chart with error bars across all benchmarks."""
    benchmarks = list(all_metrics.keys())
    approaches = [a for a in ["Random", "Classical BO", "SciLink Agent"]
                  if any(a in all_metrics[b] for b in benchmarks)]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    x = np.arange(len(benchmarks))
    width = 0.8 / len(approaches)

    # Panel 1: Final regret (mean +/- std)
    ax = axes[0]
    for i, approach in enumerate(approaches):
        means = [all_metrics[bm].get(approach, {}).get("mean_final_regret", 0)
                 for bm in benchmarks]
        stds = [all_metrics[bm].get(approach, {}).get("std_final_regret", 0)
                for bm in benchmarks]
        ax.bar(x + i * width, means, width, yerr=stds, capsize=3,
               label=approach, color=COLORS[approach], alpha=0.85)
    ax.set_xticks(x + width * (len(approaches) - 1) / 2)
    ax.set_xticklabels(benchmarks, rotation=15, ha="right")
    ax.set_ylabel("Final Simple Regret (mean +/- std)")
    ax.set_title("Final Regret by Benchmark")
    ax.legend()
    ax.grid(True, alpha=0.3, axis="y")

    # Panel 2: Cumulative regret (mean +/- std)
    ax = axes[1]
    for i, approach in enumerate(approaches):
        means = [all_metrics[bm].get(approach, {}).get("mean_cum_regret", 0)
                 for bm in benchmarks]
        stds = [all_metrics[bm].get(approach, {}).get("std_cum_regret", 0)
                for bm in benchmarks]
        ax.bar(x + i * width, means, width, yerr=stds, capsize=3,
               label=approach, color=COLORS[approach], alpha=0.85)
    ax.set_xticks(x + width * (len(approaches) - 1) / 2)
    ax.set_xticklabels(benchmarks, rotation=15, ha="right")
    ax.set_ylabel("Cumulative Regret (mean +/- std)")
    ax.set_title("Cumulative Regret by Benchmark")
    ax.legend()
    ax.grid(True, alpha=0.3, axis="y")

    fig.tight_layout()
    save_path = save_dir / "summary_comparison.png"
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    return str(save_path)


# ---------------------------------------------------------------------------
# Printing
# ---------------------------------------------------------------------------

def print_table(benchmark_name, global_min, metrics_dict, n_seeds):
    """Print comparison table for one benchmark with mean +/- std."""
    print(f"\n{'=' * 80}")
    print(f"  {benchmark_name}   (global min = {global_min:.4f}, seeds = {n_seeds})")
    print(f"{'=' * 80}")
    header = (f"{'Approach':<18} {'Final Regret':>18} {'Cum. Regret':>18} "
              f"{'Med. Iters→<1':>14} {'Time (s)':>10}")
    print(header)
    print("-" * 80)
    for name, m in metrics_dict.items():
        regret_str = f"{m['mean_final_regret']:.4f} +/- {m['std_final_regret']:.4f}"
        cum_str = f"{m['mean_cum_regret']:.2f} +/- {m['std_cum_regret']:.2f}"
        iters_val = m["median_iters_to_threshold"]
        frac = m["frac_reached_threshold"]
        if iters_val is not None:
            iters_str = f"{iters_val:.0f} ({frac:.0%})"
        else:
            iters_str = f"— ({frac:.0%})"
        time_str = f"{m['mean_total_time_s']:.2f}"
        print(f"{name:<18} {regret_str:>18} {cum_str:>18} {iters_str:>14} {time_str:>10}")


def print_strategy_log(all_strategies):
    """Print LLM-chosen strategies from the first seed (as a sample)."""
    if not all_strategies:
        return
    strats = all_strategies[0]
    print("\n  Agent strategy choices (seed 0):")
    for i, s in enumerate(strats):
        if isinstance(s, dict) and "error" not in s:
            kernel = s.get("kernel", "?")
            acq = s.get("acquisition_strategy", s.get("strategy", "?"))
            if isinstance(acq, dict):
                acq = acq.get("name", "?")
            noise = s.get("noise", "?")
            print(f"    step {i+1}: kernel={kernel}, acq={acq}, noise={noise}")
        elif isinstance(s, dict) and "error" in s:
            print(f"    step {i+1}: ERROR — {s['error'][:60]}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    _OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    run_agent = not _SKIP_AGENT and bool(_API_KEY)
    if _SKIP_AGENT:
        print("Skipping SciLink Agent (--no-agent flag).\n")
    elif not _API_KEY:
        print("No API key found — skipping SciLink Agent tests.")
        print("Set GEMINI_API_KEY or SCILINK_TEST_API_KEY to include agent.\n")

    print(f"Seeds: {SEEDS}  (--seeds N to change)\n")

    all_metrics = {}
    all_agg = {}
    all_json = {}

    for bm_name, bm in BENCHMARKS.items():
        print(f"\n{'#' * 80}")
        print(f"# Benchmark: {bm_name}  ({bm['n_iters']} iters x {len(SEEDS)} seeds)")
        print(f"{'#' * 80}")

        func = bm["func"]
        bounds = bm["bounds"]
        col_names = bm["col_names"]
        global_min = bm["global_min"]
        n_init = bm["n_init"]
        n_iters = bm["n_iters"]

        agg_results = {}
        metrics = {}

        # --- Random Search ---
        print(f"\n  Running Random Search ...")
        agg = run_multi_seed(run_random_search, func, bounds, col_names,
                             n_init, n_iters, SEEDS)
        agg_results["Random"] = agg
        metrics["Random"] = compute_metrics(agg, global_min)

        # --- Classical BO ---
        print(f"  Running Classical BO ...")
        agg = run_multi_seed(run_classical_bo, func, bounds, col_names,
                             n_init, n_iters, SEEDS)
        agg_results["Classical BO"] = agg
        metrics["Classical BO"] = compute_metrics(agg, global_min)

        # --- SciLink Agent ---
        if run_agent:
            print(f"  Running SciLink Agent ...")
            agg = run_multi_seed(run_scilink_agent, func, bounds, col_names,
                                 n_init, n_iters, SEEDS)
            agg_results["SciLink Agent"] = agg
            metrics["SciLink Agent"] = compute_metrics(agg, global_min)

        # --- Print ---
        print_table(bm_name, global_min, metrics, len(SEEDS))
        if run_agent and "SciLink Agent" in agg_results:
            print_strategy_log(agg_results["SciLink Agent"]["all_strategies"])

        # --- Plot ---
        plot_path = plot_comparison(bm_name, global_min, agg_results, _OUTPUT_DIR)
        print(f"\n  Plot saved: {plot_path}")

        all_metrics[bm_name] = metrics
        all_agg[bm_name] = agg_results

        # Serialize per-seed histories
        all_json[bm_name] = {}
        for approach_name, agg in agg_results.items():
            all_json[bm_name][approach_name] = {
                "histories": agg["histories"].tolist(),
                "mean_history": agg["mean_history"].tolist(),
                "std_history": agg["std_history"].tolist(),
                "n_seeds": agg["n_seeds"],
            }

    # --- Overall Summary ---
    print(f"\n\n{'#' * 80}")
    print(f"# OVERALL SUMMARY  ({len(SEEDS)} seeds per benchmark)")
    print(f"{'#' * 80}")

    for bm_name, metrics in all_metrics.items():
        print_table(bm_name, BENCHMARKS[bm_name]["global_min"], metrics, len(SEEDS))

    summary_path = plot_summary(all_metrics, _OUTPUT_DIR)
    print(f"\n  Summary plot saved: {summary_path}")

    json_path = _OUTPUT_DIR / "comparison_results.json"
    with open(json_path, "w") as f:
        json.dump(all_json, f, indent=2)
    print(f"  Raw results saved: {json_path}")

    # --- Verdict ---
    print(f"\n{'=' * 80}")
    print("  VERDICT")
    print(f"{'=' * 80}")
    for bm_name, m in all_metrics.items():
        cr = m["Classical BO"]["mean_final_regret"]
        rr = m["Random"]["mean_final_regret"]
        msg = f"  {bm_name}: Classical BO regret={cr:.4f} vs Random={rr:.4f}"
        if "SciLink Agent" in m:
            ar = m["SciLink Agent"]["mean_final_regret"]
            msg += f" vs Agent={ar:.4f}"
            if ar < cr:
                msg += "  -> Agent wins"
            elif ar <= cr * 1.1:
                msg += "  -> Comparable"
            else:
                msg += "  -> Classical wins"
        else:
            msg += f"  -> BO {'beats' if cr < rr else 'loses to'} Random"
        print(msg)

    print()


if __name__ == "__main__":
    main()
