import pandas as pd, json
df = pd.read_excel('/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260401_225636/knowledge/PWSdatabase.xlsx')
cols = ['Li', 'Co', 'Ni', 'Mn', 'Mg', 'Sr', 'Ba', 'Rb', 'Cs', 'V', 'W', 'U', 'Be', 'Sc']
for c in cols:
    df[c] = pd.to_numeric(df[c], errors='coerce')
stats = df[cols].agg(['count', 'mean', 'median', 'max', 'min']).to_dict()
top_basin = df.groupby('BASIN')['Li'].mean().idxmax()
answer = {"stats": {k: {k2: round(v2, 4) if isinstance(v2, float) else v2 for k2, v2 in v.items()} for k, v in stats.items()}, "basin_highest_avg_Li": top_basin}
summary = f"Descriptive statistics for 14 trace-element columns computed; the basin with the highest average Li concentration is {top_basin}."
print(json.dumps({"answer": answer, "summary": summary}))
