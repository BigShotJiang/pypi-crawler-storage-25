import pandas as pd, json
df = pd.read_excel('/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260401_225636/knowledge/PWSdatabase.xlsx')
element_cols = ['Ag','Al','As','Au','B','BO3','Ba','Be','Bi','Br','CO3','HCO3','Ca','Cd','Cl','Co','Cr','Cs','Cu','F','FeTot','FeIII','FeII','FeS','FeAl','FeAl2O3','Hg','I','K','KNa','Li','Mg','Mn','Mo','N','NO2','NO3','NO3NO2','NH4','TKN','Na','Ni','OH','P','PO4','Pb','Rh','Rb','S','SO3','SO4','HS','Sb','Sc','Se','Si','Sn','Sr','Ti','Tl','U','V','W','Zn']
desc_row = df.iloc[0]
units_note = str(desc_row.get('UNITS', 'mg/L'))
result = {col: {'description': str(desc_row[col]), 'units': units_note} for col in element_cols if col in df.columns}
answer = {col: result[col]['description'] + ' (' + result[col]['units'] + ')' for col in result}
summary = f"There are {len(answer)} element/ion concentration columns, all in units of {units_note}."
print(json.dumps({"answer": answer, "summary": summary}))
