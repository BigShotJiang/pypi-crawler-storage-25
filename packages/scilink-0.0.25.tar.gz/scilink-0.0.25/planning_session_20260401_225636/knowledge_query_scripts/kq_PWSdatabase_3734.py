import pandas as pd, json
df = pd.read_excel('/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260401_225636/knowledge/PWSdatabase.xlsx')
df_work = df.iloc[1:].copy()
df_work['Li_num'] = pd.to_numeric(df_work['Li'], errors='coerce')
li_data = df_work.dropna(subset=['Li_num'])
stats = li_data.groupby('BASIN')['Li_num'].agg(['count','mean','median','max']).sort_values('mean', ascending=False).head(10).reset_index().to_dict(orient='records')
total_basins = df_work['BASIN'].nunique()
answer = {"top_10_basins_by_avg_Li": stats, "total_unique_basins": int(total_basins)}
summary = f"Top 10 basins by average Li concentration identified out of {total_basins} unique basins; results include count, mean, median, and max Li for each."
print(json.dumps({"answer": answer, "summary": summary}))
