import numpy as np
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.spatial import Delaunay
from scipy.ndimage import gaussian_filter
from sklearn.mixture import GaussianMixture
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# Step 1: Load image and Tier 1 outputs
# ============================================================
image_path = '/Users/maxim.ziatdinov/Code/SciLink/analysis_session_20260404_105417/results/analysis__easy__LLTO_ImageAnalysis_20260404_105548_001/image_0000/temp_image_0.npy'
image = np.load(image_path).astype(np.float32)
print(f"Image shape: {image.shape}, dtype: {image.dtype}")
print(f"Intensity range: [{image.min()}, {image.max()}]")

# Try to load Tier 1 outputs
import os
base_dir = os.path.dirname(image_path)

def try_load(name, alt_names=None):
    paths_to_try = [os.path.join(base_dir, name), name]
    if alt_names:
        for an in alt_names:
            paths_to_try.append(os.path.join(base_dir, an))
            paths_to_try.append(an)
    for p in paths_to_try:
        if os.path.exists(p):
            return np.load(p)
    return None

positions = try_load('atomic_column_positions.npy', ['atom_positions.npy', 'positions.npy'])
intensities = try_load('column_intensities.npy', ['intensities.npy', 'atom_intensities.npy'])
nn_distances = try_load('nn_distances_nm.npy', ['nn_distances.npy', 'nearest_neighbor_distances.npy'])

# If Tier 1 outputs not found, run atom detection
if positions is None:
    print("Tier 1 outputs not found. Running atom detection...")
    from scilink.tools.atom_finding_tools import detect_atoms, refine_positions
    
    # Estimate separation from image size - for LLTO, lattice ~3.87 Å
    # For a 1024x1024 image, estimate FOV and pixel size
    # Typical HAADF STEM of LLTO: FOV ~5-15 nm
    # Try with a reasonable separation
    
    # First try with a moderate separation
    sep_test = 20  # initial guess
    result = detect_atoms(image, separation=sep_test, threshold_rel=0.02, refine=True,
                          normalize_intensity=True, subtract_background=True)
    positions_xy = result['positions']  # (N, 2) as (x, y) where x=col, y=row
    
    if len(positions_xy) < 10:
        # Try with smaller separation
        sep_test = 12
        result = detect_atoms(image, separation=sep_test, threshold_rel=0.02, refine=True,
                              normalize_intensity=True, subtract_background=True)
        positions_xy = result['positions']
    
    print(f"Detected {len(positions_xy)} atomic columns with separation={sep_test}")
    
    # Compute NN distances in pixels
    from scipy.spatial import cKDTree
    tree = cKDTree(positions_xy)
    dd, _ = tree.query(positions_xy, k=2)
    nn_dist_px = dd[:, 1]  # nearest neighbor distance in pixels
    median_nn_px = np.median(nn_dist_px)
    print(f"Median NN distance: {median_nn_px:.1f} pixels")
    
    # If too few or too many columns, adjust separation
    if len(positions_xy) < 50:
        sep_test = max(5, int(median_nn_px * 0.5))
        result = detect_atoms(image, separation=sep_test, threshold_rel=0.01, refine=True,
                              normalize_intensity=True, subtract_background=True)
        positions_xy = result['positions']
        tree = cKDTree(positions_xy)
        dd, _ = tree.query(positions_xy, k=2)
        nn_dist_px = dd[:, 1]
        median_nn_px = np.median(nn_dist_px)
        print(f"Re-detected {len(positions_xy)} atomic columns with separation={sep_test}")
    
    # Extract intensities at column positions
    col_intensities = result.get('amplitude', None)
    if col_intensities is None:
        # Sample intensity from image at positions
        col_intensities = np.array([
            image[int(np.clip(y, 0, image.shape[0]-1)), int(np.clip(x, 0, image.shape[1]-1))]
            for x, y in positions_xy
        ])
    
    positions = positions_xy  # (N, 2) as (x, y)
    intensities = col_intensities
    
    # Estimate pixel size in nm
    # For LLTO perovskite, NN distance ~3.87 Å = 0.387 nm
    # But we might see sublattice with half that
    # Assume the median NN corresponds to the perovskite lattice parameter
    assumed_lattice_nm = 0.387  # nm, LLTO perovskite
    pixel_size_nm = assumed_lattice_nm / median_nn_px
    print(f"Estimated pixel size: {pixel_size_nm:.4f} nm/pixel")
    
    nn_distances_nm_arr = nn_dist_px * pixel_size_nm
else:
    print(f"Loaded Tier 1 positions: {positions.shape}")
    if intensities is not None:
        print(f"Loaded Tier 1 intensities: {intensities.shape}")
    if nn_distances is not None:
        print(f"Loaded Tier 1 NN distances: {nn_distances.shape}")
    
    positions_xy = positions  # assume (N, 2) as (x, y)
    col_intensities = intensities
    
    from scipy.spatial import cKDTree
    tree = cKDTree(positions_xy)
    dd, _ = tree.query(positions_xy, k=2)
    nn_dist_px = dd[:, 1]
    median_nn_px = np.median(nn_dist_px)
    
    if nn_distances is not None and len(nn_distances) > 0:
        median_nn_nm = np.median(nn_distances)
        pixel_size_nm = median_nn_nm / median_nn_px
    else:
        assumed_lattice_nm = 0.387
        pixel_size_nm = assumed_lattice_nm / median_nn_px
        median_nn_nm = assumed_lattice_nm
    
    nn_distances_nm_arr = nn_dist_px * pixel_size_nm
    print(f"Pixel size: {pixel_size_nm:.4f} nm/pixel, Median NN: {median_nn_px:.1f} px")

# Ensure we have positions and intensities
N_atoms = len(positions_xy)
print(f"Working with {N_atoms} atomic columns")

# Convert positions to nm
positions_nm = positions_xy * pixel_size_nm  # (N, 2) as (x_nm, y_nm)

# ============================================================
# Step 2: Background correction
# ============================================================
print("Step 2: Background correction...")

# Fit a 2D polynomial background to the image
# Sample points between atomic columns
from numpy.polynomial import polynomial as P

# Create a mask excluding regions around atomic columns
mask = np.ones(image.shape, dtype=bool)
for x, y in positions_xy:
    yi, xi = int(round(y)), int(round(x))
    r = max(3, int(median_nn_px * 0.3))
    y_lo, y_hi = max(0, yi-r), min(image.shape[0], yi+r+1)
    x_lo, x_hi = max(0, xi-r), min(image.shape[1], xi+r+1)
    mask[y_lo:y_hi, x_lo:x_hi] = False

# Subsample background points for polynomial fit
ys_bg, xs_bg = np.where(mask)
if len(ys_bg) > 50000:
    idx = np.random.choice(len(ys_bg), 50000, replace=False)
    ys_bg, xs_bg = ys_bg[idx], xs_bg[idx]

vals_bg = image[ys_bg, xs_bg]

# Fit 2D polynomial of order 3
# Use least squares: z = sum_{i+j<=3} a_{ij} * x^i * y^j
from numpy.linalg import lstsq

def poly2d_design(x, y, order=3):
    cols = []
    for i in range(order+1):
        for j in range(order+1-i):
            cols.append((x**i) * (y**j))
    return np.column_stack(cols)

# Normalize coordinates for numerical stability
x_norm_bg = xs_bg / image.shape[1]
y_norm_bg = ys_bg / image.shape[0]

A_bg = poly2d_design(x_norm_bg, y_norm_bg, order=3)
coeffs, _, _, _ = lstsq(A_bg, vals_bg, rcond=None)

# Evaluate background at all positions
yy_all, xx_all = np.mgrid[0:image.shape[0], 0:image.shape[1]]
x_norm_all = xx_all.ravel() / image.shape[1]
y_norm_all = yy_all.ravel() / image.shape[0]
A_all = poly2d_design(x_norm_all, y_norm_all, order=3)
background = (A_all @ coeffs).reshape(image.shape)

# Avoid division by zero
background = np.clip(background, np.percentile(background, 1), None)

# Correct intensities at column positions
corrected_intensities = np.zeros(N_atoms)
for i, (x, y) in enumerate(positions_xy):
    yi, xi = int(np.clip(round(y), 0, image.shape[0]-1)), int(np.clip(round(x), 0, image.shape[1]-1))
    bg_val = background[yi, xi]
    if col_intensities is not None:
        corrected_intensities[i] = col_intensities[i] / bg_val if bg_val > 0 else col_intensities[i]
    else:
        corrected_intensities[i] = image[yi, xi] / bg_val if bg_val > 0 else image[yi, xi]

print(f"Corrected intensity range: [{corrected_intensities.min():.4f}, {corrected_intensities.max():.4f}]")

# ============================================================
# Step 3: Cluster columns into horizontal rows
# ============================================================
print("Step 3: Clustering columns into horizontal rows...")

y_coords = positions_xy[:, 1]  # y = row coordinate
bin_width = median_nn_px * 0.5

# Use histogram-based clustering
y_min, y_max = y_coords.min(), y_coords.max()
bins = np.arange(y_min - bin_width, y_max + bin_width, bin_width)
hist, bin_edges = np.histogram(y_coords, bins=bins)

# Find peaks in histogram to identify row centers
from scipy.signal import find_peaks
peaks, _ = find_peaks(hist, distance=max(1, int(median_nn_px / bin_width * 0.7)), height=1)
row_centers = (bin_edges[peaks] + bin_edges[peaks + 1]) / 2

print(f"Found {len(row_centers)} horizontal rows")

# Assign each column to nearest row
row_assignments = np.array([np.argmin(np.abs(y - row_centers)) for y in y_coords])

# Compute mean corrected intensity per row
row_mean_intensity = np.zeros(len(row_centers))
row_std_intensity = np.zeros(len(row_centers))
row_count = np.zeros(len(row_centers), dtype=int)

for r in range(len(row_centers)):
    mask_r = row_assignments == r
    if np.sum(mask_r) > 0:
        row_mean_intensity[r] = np.mean(corrected_intensities[mask_r])
        row_std_intensity[r] = np.std(corrected_intensities[mask_r])
        row_count[r] = np.sum(mask_r)

# Convert row centers to nm
row_centers_nm = row_centers * pixel_size_nm

# ============================================================
# Step 4: Analyze row-averaged intensity profile
# ============================================================
print("Step 4: Analyzing row-averaged intensity profile...")

# Check for interface (step change in mean intensity)
valid_rows = row_count > 2
valid_row_intensities = row_mean_intensity[valid_rows]
valid_row_positions = row_centers_nm[valid_rows]

# Look for step change using sliding window difference
interface_present = False
interface_position_nm = None

if len(valid_row_intensities) > 10:
    # Smooth the profile
    from scipy.ndimage import uniform_filter1d
    smoothed = uniform_filter1d(valid_row_intensities, size=5)
    
    # Compute gradient
    gradient = np.gradient(smoothed)
    gradient_abs = np.abs(gradient)
    
    # Find maximum gradient
    max_grad_idx = np.argmax(gradient_abs)
    max_grad_val = gradient_abs[max_grad_idx]
    mean_grad = np.mean(gradient_abs)
    
    if max_grad_val > 3 * mean_grad and len(valid_row_intensities) > 5:
        interface_present = True
        interface_position_nm = valid_row_positions[max_grad_idx]
        print(f"Interface detected at y = {interface_position_nm:.2f} nm")
    else:
        print("No clear interface detected")

# Check for A-site ordering (alternating intensity pattern)
if len(valid_row_intensities) > 5:
    # Compute alternating modulation
    diffs = np.diff(valid_row_intensities)
    # Check if signs alternate
    sign_changes = np.diff(np.sign(diffs))
    n_alternations = np.sum(np.abs(sign_changes) == 2)
    alternation_ratio = n_alternations / max(1, len(sign_changes))
    
    # Also compute modulation strength
    modulation_strength = np.std(diffs) / np.mean(np.abs(valid_row_intensities) + 1e-10)
    
    a_site_ordering_present = alternation_ratio > 0.4 and modulation_strength > 0.02
    print(f"A-site ordering: alternation_ratio={alternation_ratio:.3f}, modulation_strength={modulation_strength:.4f}")
    print(f"A-site ordering present: {a_site_ordering_present}")
else:
    a_site_ordering_present = False
    alternation_ratio = 0.0
    modulation_strength = 0.0

# ============================================================
# Step 5: Build Delaunay triangulation and compute local lattice params
# ============================================================
print("Step 5: Computing local lattice parameters...")

tree = cKDTree(positions_xy)

# For each column, find neighbors within 1.5x median NN distance
search_radius = 1.5 * median_nn_px

local_h_spacing = np.full(N_atoms, np.nan)  # horizontal
local_v_spacing = np.full(N_atoms, np.nan)  # vertical

for i in range(N_atoms):
    xi, yi = positions_xy[i]
    neighbors = tree.query_ball_point([xi, yi], search_radius)
    
    h_dists = []
    v_dists = []
    
    for j in neighbors:
        if j == i:
            continue
        dx = positions_xy[j, 0] - xi
        dy = positions_xy[j, 1] - yi
        dist = np.sqrt(dx**2 + dy**2)
        
        if dist < 0.5 * median_nn_px:
            continue
        
        angle = np.abs(np.degrees(np.arctan2(dy, dx)))
        
        # Horizontal: angle within 20° of 0° or 180°
        if angle < 20 or angle > 160:
            h_dists.append(np.abs(dx))
        
        # Vertical: angle within 20° of 90°
        if 70 < angle < 110:
            v_dists.append(np.abs(dy))
    
    if h_dists:
        local_h_spacing[i] = np.median(h_dists) * pixel_size_nm
    if v_dists:
        local_v_spacing[i] = np.median(v_dists) * pixel_size_nm

# Compute tetragonality ratio
tetragonality = local_v_spacing / local_h_spacing

valid_h = ~np.isnan(local_h_spacing)
valid_v = ~np.isnan(local_v_spacing)
valid_t = ~np.isnan(tetragonality)

print(f"Valid horizontal spacings: {np.sum(valid_h)}/{N_atoms}")
print(f"Valid vertical spacings: {np.sum(valid_v)}/{N_atoms}")

mean_h = np.nanmean(local_h_spacing)
std_h = np.nanstd(local_h_spacing)
mean_v = np.nanmean(local_v_spacing)
std_v = np.nanstd(local_v_spacing)
mean_t = np.nanmean(tetragonality)
std_t = np.nanstd(tetragonality)

print(f"Mean horizontal lattice parameter: {mean_h:.4f} ± {std_h:.4f} nm")
print(f"Mean vertical lattice parameter: {mean_v:.4f} ± {std_v:.4f} nm")
print(f"Mean tetragonality (c/a): {mean_t:.4f} ± {std_t:.4f}")

# ============================================================
# Step 6: Lattice parameter profiles vs vertical position
# ============================================================
print("Step 6: Computing lattice parameter profiles...")

# Bin by vertical position in ~0.5 nm slices
y_nm = positions_xy[:, 1] * pixel_size_nm
y_min_nm, y_max_nm = y_nm.min(), y_nm.max()
slice_width = 0.5  # nm
slice_edges = np.arange(y_min_nm, y_max_nm + slice_width, slice_width)
slice_centers = (slice_edges[:-1] + slice_edges[1:]) / 2

h_profile = np.full(len(slice_centers), np.nan)
v_profile = np.full(len(slice_centers), np.nan)
t_profile = np.full(len(slice_centers), np.nan)
h_profile_std = np.full(len(slice_centers), np.nan)
v_profile_std = np.full(len(slice_centers), np.nan)

for k in range(len(slice_centers)):
    in_slice = (y_nm >= slice_edges[k]) & (y_nm < slice_edges[k+1])
    
    h_vals = local_h_spacing[in_slice & valid_h]
    v_vals = local_v_spacing[in_slice & valid_v]
    t_vals = tetragonality[in_slice & valid_t]
    
    if len(h_vals) > 1:
        h_profile[k] = np.mean(h_vals)
        h_profile_std[k] = np.std(h_vals)
    if len(v_vals) > 1:
        v_profile[k] = np.mean(v_vals)
        v_profile_std[k] = np.std(v_vals)
    if len(t_vals) > 1:
        t_profile[k] = np.mean(t_vals)

# ============================================================
# Step 7: Intensity histogram with GMM
# ============================================================
print("Step 7: Fitting intensity histogram with GMM...")

# Use corrected intensities
valid_int = corrected_intensities[corrected_intensities > 0]

# Try 2 and 3 component GMM, pick best by BIC
best_bic = np.inf
best_gmm = None
best_n = 2

for n_comp in [2, 3]:
    try:
        gmm = GaussianMixture(n_components=n_comp, random_state=42, max_iter=200)
        gmm.fit(valid_int.reshape(-1, 1))
        bic = gmm.bic(valid_int.reshape(-1, 1))
        if bic < best_bic:
            best_bic = bic
            best_gmm = gmm
            best_n = n_comp
    except:
        pass

print(f"Best GMM: {best_n} components (BIC={best_bic:.1f})")

gmm_means = best_gmm.means_.flatten()
gmm_stds = np.sqrt(best_gmm.covariances_.flatten())
gmm_weights = best_gmm.weights_.flatten()

# Sort by mean
sort_idx = np.argsort(gmm_means)
gmm_means = gmm_means[sort_idx]
gmm_stds = gmm_stds[sort_idx]
gmm_weights = gmm_weights[sort_idx]

for i in range(best_n):
    print(f"  Component {i}: mean={gmm_means[i]:.4f}, std={gmm_stds[i]:.4f}, weight={gmm_weights[i]:.3f}")

# ============================================================
# Step 8: Visualization
# ============================================================
print("Step 8: Creating visualization...")

fig, axes = plt.subplots(2, 3, figsize=(18, 12))

# (a) Row-averaged corrected intensity profile
ax = axes[0, 0]
ax.plot(valid_row_positions, valid_row_intensities, 'b.-', markersize=3, linewidth=0.8)
ax.set_xlabel('Vertical position (nm)')
ax.set_ylabel('Mean corrected intensity')
ax.set_title('(a) Row-averaged intensity profile')
if interface_present:
    ax.axvline(interface_position_nm, color='r', linestyle='--', label=f'Interface at {interface_position_nm:.1f} nm')
    ax.legend(fontsize=8)
ax.grid(True, alpha=0.3)

# (b) Lattice parameter profiles
ax = axes[0, 1]
valid_h_prof = ~np.isnan(h_profile)
valid_v_prof = ~np.isnan(v_profile)
if np.any(valid_h_prof):
    ax.plot(slice_centers[valid_h_prof], h_profile[valid_h_prof], 'b.-', label='Horizontal', markersize=3)
if np.any(valid_v_prof):
    ax.plot(slice_centers[valid_v_prof], v_profile[valid_v_prof], 'r.-', label='Vertical', markersize=3)
ax.set_xlabel('Vertical position (nm)')
ax.set_ylabel('Lattice parameter (nm)')
ax.set_title('(b) Lattice parameter profiles')
ax.legend(fontsize=8)
ax.grid(True, alpha=0.3)
if interface_present:
    ax.axvline(interface_position_nm, color='gray', linestyle='--', alpha=0.5)

# (c) 2D tetragonality map
ax = axes[0, 2]
im_bg = ax.imshow(image, cmap='gray', extent=[0, image.shape[1]*pixel_size_nm, image.shape[0]*pixel_size_nm, 0], alpha=0.5)
valid_mask = valid_t & (tetragonality > 0.8) & (tetragonality < 1.2)  # filter outliers
sc = ax.scatter(positions_nm[valid_mask, 0], positions_nm[valid_mask, 1],
                c=tetragonality[valid_mask], cmap='RdBu_r', s=8, 
                vmin=max(0.9, mean_t - 3*std_t), vmax=min(1.1, mean_t + 3*std_t))
plt.colorbar(sc, ax=ax, label='c/a ratio')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_title('(c) Tetragonality map')
if interface_present:
    ax.axhline(interface_position_nm, color='lime', linestyle='--', linewidth=1)

# (d) Corrected intensity histogram with GMM
ax = axes[1, 0]
n_hist, bin_edges_hist, _ = ax.hist(valid_int, bins=50, density=True, alpha=0.6, color='steelblue', edgecolor='black', linewidth=0.5)
x_range = np.linspace(valid_int.min(), valid_int.max(), 300)
from scipy.stats import norm
total_pdf = np.zeros_like(x_range)
colors_gmm = ['red', 'green', 'orange']
for i in range(best_n):
    component_pdf = gmm_weights[i] * norm.pdf(x_range, gmm_means[i], gmm_stds[i])
    ax.plot(x_range, component_pdf, '--', color=colors_gmm[i % 3], linewidth=1.5,
            label=f'Comp {i}: μ={gmm_means[i]:.3f}, w={gmm_weights[i]:.2f}')
    total_pdf += component_pdf
ax.plot(x_range, total_pdf, 'k-', linewidth=2, label='Total GMM')
ax.set_xlabel('Corrected intensity')
ax.set_ylabel('Density')
ax.set_title('(d) Intensity histogram + GMM')
ax.legend(fontsize=7)

# (e) 2D map of horizontal lattice parameter
ax = axes[1, 1]
im_bg2 = ax.imshow(image, cmap='gray', extent=[0, image.shape[1]*pixel_size_nm, image.shape[0]*pixel_size_nm, 0], alpha=0.5)
valid_h_mask = valid_h & (local_h_spacing > mean_h - 3*std_h) & (local_h_spacing < mean_h + 3*std_h)
sc2 = ax.scatter(positions_nm[valid_h_mask, 0], positions_nm[valid_h_mask, 1],
                 c=local_h_spacing[valid_h_mask], cmap='viridis', s=8,
                 vmin=mean_h - 2*std_h, vmax=mean_h + 2*std_h)
plt.colorbar(sc2, ax=ax, label='a (nm)')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_title('(e) Horizontal lattice parameter map')
if interface_present:
    ax.axhline(interface_position_nm, color='lime', linestyle='--', linewidth=1)

# (f) Original image with detected columns
ax = axes[1, 2]
ax.imshow(image, cmap='gray', extent=[0, image.shape[1]*pixel_size_nm, image.shape[0]*pixel_size_nm, 0])
ax.scatter(positions_nm[:, 0], positions_nm[:, 1], s=4, c=corrected_intensities, 
           cmap='hot', alpha=0.7, edgecolors='none')
ax.set_xlabel('x (nm)')
ax.set_ylabel('y (nm)')
ax.set_title(f'(f) Detected columns (N={N_atoms})')
if interface_present:
    ax.axhline(interface_position_nm, color='lime', linestyle='--', linewidth=1, label='Interface')
    ax.legend(fontsize=8)

plt.tight_layout()
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("Saved analysis_visualization.png")

# ============================================================
# Save output arrays
# ============================================================
np.save('atomic_column_positions_nm.npy', positions_nm)
np.save('corrected_intensities.npy', corrected_intensities)
np.save('local_horizontal_lattice_parameter.npy', local_h_spacing)
np.save('local_vertical_lattice_parameter.npy', local_v_spacing)
np.save('tetragonality_ratio.npy', tetragonality)
np.save('row_averaged_intensity_profile.npy', np.column_stack([valid_row_positions, valid_row_intensities]))
np.save('lattice_parameter_profiles.npy', np.column_stack([slice_centers, h_profile, v_profile]))

print("Saved all .npy files")

# ============================================================
# Print results JSON
# ============================================================
results = {
    "analysis_type": "LLTO STEM image analysis: A-site ordering, lattice strain, and interface characterization",
    "extracted_features": {
        "n_atomic_columns": int(N_atoms),
        "pixel_size_nm": float(round(pixel_size_nm, 5)),
        "median_nn_distance_nm": float(round(np.median(nn_distances_nm_arr), 4)),
        "interface_present": bool(interface_present),
        "interface_position_nm": float(round(interface_position_nm, 2)) if interface_present else None,
        "A_site_ordering_present": bool(a_site_ordering_present),
        "A_site_ordering_alternation_ratio": float(round(alternation_ratio, 4)),
        "A_site_ordering_modulation_strength": float(round(modulation_strength, 4)),
        "mean_horizontal_lattice_parameter_nm": float(round(mean_h, 4)),
        "std_horizontal_lattice_parameter_nm": float(round(std_h, 4)),
        "mean_vertical_lattice_parameter_nm": float(round(mean_v, 4)),
        "std_vertical_lattice_parameter_nm": float(round(std_v, 4)),
        "mean_tetragonality_ratio": float(round(mean_t, 4)),
        "std_tetragonality_ratio": float(round(std_t, 4)),
        "gmm_n_components": int(best_n),
        "gmm_means": [float(round(m, 4)) for m in gmm_means],
        "gmm_stds": [float(round(s, 4)) for s in gmm_stds],
        "gmm_weights": [float(round(w, 4)) for w in gmm_weights],
        "sublattice_population_fractions": [float(round(w, 4)) for w in gmm_weights],
        "corrected_intensity_range": [float(round(corrected_intensities.min(), 4)), float(round(corrected_intensities.max(), 4))]
    },
    "quality_metrics": {
        "columns_with_valid_h_spacing": int(np.sum(valid_h)),
        "columns_with_valid_v_spacing": int(np.sum(valid_v)),
        "columns_with_valid_tetragonality": int(np.sum(valid_t & (tetragonality > 0.8) & (tetragonality < 1.2))),
        "background_poly_order": 3,
        "gmm_bic": float(round(best_bic, 1)),
        "n_rows_detected": int(len(row_centers)),
        "mean_columns_per_row": float(round(np.mean(row_count[row_count > 0]), 1))
    },
    "summary": f"Analyzed {N_atoms} atomic columns in LLTO STEM image. Mean lattice parameters: a={mean_h:.4f}±{std_h:.4f} nm, c={mean_v:.4f}±{std_v:.4f} nm, tetragonality c/a={mean_t:.4f}±{std_t:.4f}. Interface {'detected at ' + str(round(interface_position_nm, 1)) + ' nm' if interface_present else 'not detected'}. A-site ordering {'observed (modulation={:.3f})'.format(modulation_strength) if a_site_ordering_present else 'not clearly observed'}. GMM identified {best_n} intensity populations with fractions {[round(w, 2) for w in gmm_weights]}. Pixel size estimated as {pixel_size_nm:.4f} nm/pixel assuming ~0.387 nm perovskite NN distance.",
    "saved_arrays": {
        "atomic_column_positions_nm.npy": {
            "description": f"Atomic column positions in nm, (x_nm, y_nm) for {N_atoms} columns",
            "shape": list(positions_nm.shape),
            "dtype": str(positions_nm.dtype)
        },
        "corrected_intensities.npy": {
            "description": f"Background-corrected intensities for {N_atoms} atomic columns",
            "shape": list(corrected_intensities.shape),
            "dtype": str(corrected_intensities.dtype)
        },
        "local_horizontal_lattice_parameter.npy": {
            "description": f"Local horizontal lattice parameter (nm) for {N_atoms} columns, NaN where not computed",
            "shape": list(local_h_spacing.shape),
            "dtype": str(local_h_spacing.dtype)
        },
        "local_vertical_lattice_parameter.npy": {
            "description": f"Local vertical lattice parameter (nm) for {N_atoms} columns, NaN where not computed",
            "shape": list(local_v_spacing.shape),
            "dtype": str(local_v_spacing.dtype)
        },
        "tetragonality_ratio.npy": {
            "description": f"Tetragonality ratio (c/a) for {N_atoms} columns, NaN where not computed",
            "shape": list(tetragonality.shape),
            "dtype": str(tetragonality.dtype)
        },
        "row_averaged_intensity_profile.npy": {
            "description": "Row-averaged corrected intensity profile: columns [y_position_nm, mean_corrected_intensity]",
            "shape": [int(np.sum(valid_rows)), 2],
            "dtype": "float64"
        },
        "lattice_parameter_profiles.npy": {
            "description": "Lattice parameter profiles vs vertical position: columns [y_nm, h_param_nm, v_param_nm]",
            "shape": [len(slice_centers), 3],
            "dtype": "float64"
        }
    }
}

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
