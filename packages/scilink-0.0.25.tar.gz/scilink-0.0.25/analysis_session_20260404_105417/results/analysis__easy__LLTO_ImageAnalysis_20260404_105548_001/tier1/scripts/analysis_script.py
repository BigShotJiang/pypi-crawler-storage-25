import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage, signal
import json
import warnings
warnings.filterwarnings('ignore')

from scilink.tools.atom_finding_tools import detect_atoms_dcnn, refine_positions, find_zone_axes

# Load image
path = '/Users/maxim.ziatdinov/Code/SciLink/analysis_session_20260404_105417/results/analysis__easy__LLTO_ImageAnalysis_20260404_105548_001/image_0000/temp_image_0.npy'
image = np.load(path)
print(f"Image shape: {image.shape}, dtype: {image.dtype}")
print(f"Intensity range: [{image.min()}, {image.max()}]")

# Parameters
fov_nm = 20.88
image_size = image.shape[0]  # 1024
pixel_size_nm = fov_nm / image_size  # nm per pixel
pixel_size_A = pixel_size_nm * 10  # Angstroms per pixel
print(f"Pixel size: {pixel_size_nm:.4f} nm = {pixel_size_A:.4f} A")

# ============================================================
# Step 1: Identify LLTO film vs LSAT substrate regions
# ============================================================
print("Identifying LLTO thin film and LSAT substrate regions...")

# In cross-section STEM, the film/substrate interface is typically
# along the horizontal direction (interface is a horizontal line).
# We analyze intensity statistics along vertical (row) direction.

# Compute row-wise mean intensity and local variance
row_mean = np.mean(image, axis=1)
row_std = np.std(image, axis=1)

# Smooth the profiles to reduce noise
from scipy.ndimage import uniform_filter1d
row_mean_smooth = uniform_filter1d(row_mean, size=30)
row_std_smooth = uniform_filter1d(row_std, size=30)

# Also compute local intensity variance in sliding windows along vertical
# LLTO has a distinctive layered structure (La-rich and Li/Ti layers alternate)
# giving periodic intensity modulation, while LSAT is more uniform
window_size = 40
row_local_var = np.zeros(image.shape[0])
for i in range(image.shape[0]):
    r_min = max(0, i - window_size // 2)
    r_max = min(image.shape[0], i + window_size // 2)
    strip = image[r_min:r_max, :]
    # Compute variance of row means within this strip (captures layering)
    strip_row_means = np.mean(strip, axis=1)
    row_local_var[i] = np.var(strip_row_means)

row_local_var_smooth = uniform_filter1d(row_local_var, size=30)

# Compute gradient of mean intensity to find sharp interface
row_mean_gradient = np.abs(np.gradient(row_mean_smooth))
row_mean_gradient_smooth = uniform_filter1d(row_mean_gradient, size=20)

# Use a combination of metrics to find the interface
# The interface typically shows: change in mean intensity, change in variance pattern
# We look for the strongest transition in the combined metric
combined_metric = row_mean_gradient_smooth / (row_mean_gradient_smooth.max() + 1e-10) + \
                  np.abs(np.gradient(row_local_var_smooth)) / (np.abs(np.gradient(row_local_var_smooth)).max() + 1e-10)
combined_metric_smooth = uniform_filter1d(combined_metric, size=15)

# Exclude edges (top/bottom 5% of image) from interface search
edge_margin = int(0.05 * image.shape[0])
combined_metric_search = combined_metric_smooth.copy()
combined_metric_search[:edge_margin] = 0
combined_metric_search[-edge_margin:] = 0

# Find the interface as the location of maximum gradient change
interface_row = int(np.argmax(combined_metric_search))
print(f"Detected interface at row {interface_row} (y = {interface_row * pixel_size_nm:.2f} nm)")

# Determine which side is the film vs substrate
# LLTO on LSAT: LSAT substrate is typically thicker/at bottom, LLTO film on top
# But let's determine this from the data:
# LLTO has characteristic layered structure -> higher local variance
# We compare variance above and below interface
var_above = np.mean(row_local_var_smooth[:interface_row]) if interface_row > 0 else 0
var_below = np.mean(row_local_var_smooth[interface_row:]) if interface_row < image.shape[0] else 0
mean_above = np.mean(row_mean_smooth[:interface_row]) if interface_row > 0 else 0
mean_below = np.mean(row_mean_smooth[interface_row:]) if interface_row < image.shape[0] else 0

print(f"Region above interface (rows 0-{interface_row}): mean_intensity={mean_above:.1f}, local_var={var_above:.1f}")
print(f"Region below interface (rows {interface_row}-{image.shape[0]}): mean_intensity={mean_below:.1f}, local_var={var_below:.1f}")

# LLTO typically shows higher row-to-row variance due to La-rich/La-poor layering
# The film is usually the thinner region
count_above = interface_row
count_below = image.shape[0] - interface_row

# Heuristic: the thinner region is likely the film
# Also LLTO has higher local variance due to layering
if var_above > var_below:
    film_region = 'above'  # Film is above (rows 0 to interface_row)
    film_row_min = 0
    film_row_max = interface_row
    substrate_row_min = interface_row
    substrate_row_max = image.shape[0]
else:
    film_region = 'below'  # Film is below (rows interface_row to end)
    film_row_min = interface_row
    film_row_max = image.shape[0]
    substrate_row_min = 0
    substrate_row_max = interface_row

# Add a small buffer around the interface to exclude transition region
interface_buffer = int(1.0 / pixel_size_nm)  # ~1 nm buffer
if film_region == 'above':
    film_row_max_effective = max(0, interface_row - interface_buffer)
    film_row_min_effective = 0
else:
    film_row_min_effective = min(image.shape[0], interface_row + interface_buffer)
    film_row_max_effective = image.shape[0]

print(f"LLTO film region: {film_region} interface, rows [{film_row_min_effective}, {film_row_max_effective}]")
print(f"Film region in nm: [{film_row_min_effective * pixel_size_nm:.2f}, {film_row_max_effective * pixel_size_nm:.2f}]")
film_thickness_nm = abs(film_row_max_effective - film_row_min_effective) * pixel_size_nm
print(f"Approximate film thickness: {film_thickness_nm:.2f} nm")

# ============================================================
# Step 2: DCNN-based atom detection on full image
# ============================================================
print("Running DCNN atom detection on full image...")
dcnn_result = detect_atoms_dcnn(image, fov_nm=fov_nm, threshold=0.8, refine=True)
positions_dcnn = dcnn_result['positions']  # (N, 2) as (x, y)
heatmap = dcnn_result.get('heatmap', None)
print(f"DCNN detected {len(positions_dcnn)} atomic columns (full image)")

# ============================================================
# Step 3: Refine positions with 2D Gaussian fitting
# ============================================================
print("Refining positions with 2D Gaussian fitting...")
try:
    refined = refine_positions(image, positions_dcnn, percent_to_nn=0.4)
    positions_refined = refined['positions']
    sigma_x = refined['sigma_x']
    sigma_y = refined['sigma_y']
    amplitude = refined['amplitude']
    rotation = refined['rotation']
    print(f"Refined {len(positions_refined)} positions")
    use_refined = True
except Exception as e:
    print(f"Refinement failed: {e}, using DCNN positions")
    positions_refined = positions_dcnn
    sigma_x = None
    sigma_y = None
    amplitude = None
    rotation = None
    use_refined = False

total_count_all = len(positions_refined)
print(f"Total atomic columns (full image): {total_count_all}")

# ============================================================
# Step 4: Filter positions to LLTO film region only
# ============================================================
print("Filtering atomic positions to LLTO film region...")
# positions_refined has (x, y) = (col, row)
pos_y_all = positions_refined[:, 1]  # row coordinate

film_mask = (pos_y_all >= film_row_min_effective) & (pos_y_all <= film_row_max_effective)
positions_film = positions_refined[film_mask]

# Also identify substrate positions for comparison
substrate_mask = ~film_mask
positions_substrate = positions_refined[substrate_mask]

total_count_film = len(positions_film)
total_count_substrate = len(positions_substrate)
print(f"Atomic columns in LLTO film: {total_count_film}")
print(f"Atomic columns in LSAT substrate: {total_count_substrate}")

if total_count_film < 10:
    print("WARNING: Very few atoms detected in film region. Trying alternative segmentation...")
    # Fallback: try splitting at image midpoint
    mid_row = image.shape[0] // 2
    # Use whichever half has more row-to-row variance (LLTO signature)
    var_top = np.mean(row_local_var_smooth[:mid_row])
    var_bot = np.mean(row_local_var_smooth[mid_row:])
    if var_top > var_bot:
        film_row_min_effective = 0
        film_row_max_effective = mid_row
    else:
        film_row_min_effective = mid_row
        film_row_max_effective = image.shape[0]
    film_mask = (pos_y_all >= film_row_min_effective) & (pos_y_all <= film_row_max_effective)
    positions_film = positions_refined[film_mask]
    substrate_mask = ~film_mask
    positions_substrate = positions_refined[substrate_mask]
    total_count_film = len(positions_film)
    total_count_substrate = len(positions_substrate)
    print(f"Fallback: LLTO film atoms: {total_count_film}, LSAT substrate atoms: {total_count_substrate}")

# ============================================================
# Step 5: Compute nearest-neighbor distances for LLTO film only
# ============================================================
print("Computing nearest-neighbor distances for LLTO film region...")
from scipy.spatial import cKDTree

if total_count_film >= 2:
    tree_film = cKDTree(positions_film)
    k_nn = min(7, total_count_film)
    dists_film, indices_film = tree_film.query(positions_film, k=k_nn)
    nn_distances_film_pix = dists_film[:, 1]  # First nearest neighbor
    nn_distances_film_nm = nn_distances_film_pix * pixel_size_nm
    nn_distances_film_A = nn_distances_film_pix * pixel_size_A

    nn_mean_film_pix = float(np.mean(nn_distances_film_pix))
    nn_std_film_pix = float(np.std(nn_distances_film_pix))
    nn_mean_film_nm = float(np.mean(nn_distances_film_nm))
    nn_std_film_nm = float(np.std(nn_distances_film_nm))
    nn_mean_film_A = float(np.mean(nn_distances_film_A))
    nn_std_film_A = float(np.std(nn_distances_film_A))
    nn_median_film_nm = float(np.median(nn_distances_film_nm))
    nn_median_film_A = float(np.median(nn_distances_film_A))

    print(f"LLTO Film NN distance: {nn_mean_film_pix:.2f} +/- {nn_std_film_pix:.2f} pixels")
    print(f"LLTO Film NN distance: {nn_mean_film_nm:.3f} +/- {nn_std_film_nm:.3f} nm")
    print(f"LLTO Film NN distance: {nn_mean_film_A:.2f} +/- {nn_std_film_A:.2f} A")

    # Also compute 2nd NN for lattice constant estimation
    if k_nn >= 3:
        nn2_distances_film_pix = dists_film[:, 2]
        nn2_mean_film_nm = float(np.mean(nn2_distances_film_pix * pixel_size_nm))
        nn2_mean_film_A = float(np.mean(nn2_distances_film_pix * pixel_size_A))
    else:
        nn2_mean_film_nm = None
        nn2_mean_film_A = None

    # Compute all pairwise NN distances histogram for lattice constant peaks
    # Use up to 4th NN to capture lattice structure
    all_nn_dists_nm = []
    if k_nn >= 5:
        for ki in range(1, min(k_nn, 5)):
            all_nn_dists_nm.extend((dists_film[:, ki] * pixel_size_nm).tolist())
    all_nn_dists_nm = np.array(all_nn_dists_nm)

else:
    print("WARNING: Not enough atoms in film region for NN analysis")
    nn_distances_film_nm = np.array([])
    nn_distances_film_A = np.array([])
    nn_mean_film_nm = 0
    nn_std_film_nm = 0
    nn_mean_film_A = 0
    nn_std_film_A = 0
    nn_median_film_nm = 0
    nn_median_film_A = 0
    nn2_mean_film_nm = None
    nn2_mean_film_A = None
    all_nn_dists_nm = np.array([])

# ============================================================
# Step 6: FFT analysis of LLTO film region only
# ============================================================
print("Computing FFT of LLTO film region...")
# Extract film region of the image
film_image = image[film_row_min_effective:film_row_max_effective, :]
print(f"Film region image shape: {film_image.shape}")

if film_image.shape[0] > 20 and film_image.shape[1] > 20:
    # Normalize
    film_norm = (film_image - film_image.mean()) / (film_image.std() + 1e-10)
    
    # Apply Hanning window
    hanning_y = np.hanning(film_image.shape[0])
    hanning_x = np.hanning(film_image.shape[1])
    window_2d = np.outer(hanning_y, hanning_x)
    film_windowed = film_norm * window_2d
    
    # Compute FFT
    fft_film = np.fft.fft2(film_windowed)
    fft_film_shifted = np.fft.fftshift(fft_film)
    fft_film_mag = np.abs(fft_film_shifted)
    fft_film_log = np.log1p(fft_film_mag)
    
    # Find peaks
    center_fy = fft_film_log.shape[0] // 2
    center_fx = fft_film_log.shape[1] // 2
    
    fft_film_peaks_search = fft_film_log.copy()
    mask_radius = 15
    Y_f, X_f = np.ogrid[:fft_film_log.shape[0], :fft_film_log.shape[1]]
    dc_mask_f = (X_f - center_fx)**2 + (Y_f - center_fy)**2 < mask_radius**2
    fft_film_peaks_search[dc_mask_f] = 0
    
    from skimage.feature import peak_local_max
    fft_film_peaks = peak_local_max(fft_film_peaks_search, min_distance=8, num_peaks=20, threshold_rel=0.3)
    
    # Calculate real-space periodicities
    fft_film_peak_info = []
    for peak in fft_film_peaks:
        dy = peak[0] - center_fy
        dx = peak[1] - center_fx
        dist_pix = np.sqrt(dy**2 + dx**2)
        if dist_pix > 0:
            # For non-square FFT, need to account for different pixel sizes in each direction
            period_y_pix = film_image.shape[0] / abs(dy) if abs(dy) > 0 else float('inf')
            period_x_pix = film_image.shape[1] / abs(dx) if abs(dx) > 0 else float('inf')
            # General period
            freq_y = dy / film_image.shape[0]  # cycles per pixel
            freq_x = dx / film_image.shape[1]
            freq_total = np.sqrt(freq_y**2 + freq_x**2)
            period_pix = 1.0 / freq_total if freq_total > 0 else float('inf')
            period_nm = period_pix * pixel_size_nm
            angle_deg = np.degrees(np.arctan2(dy, dx))
            fft_film_peak_info.append({
                'row': int(peak[0]), 'col': int(peak[1]),
                'period_nm': float(period_nm),
                'period_A': float(period_nm * 10),
                'angle_deg': float(angle_deg),
                'intensity': float(fft_film_log[peak[0], peak[1]])
            })
    
    fft_film_peak_info.sort(key=lambda x: x['intensity'], reverse=True)
    
    # Filter to reasonable lattice periods for LLTO (perovskite: ~0.38-0.39 nm lattice constant)
    reasonable_peaks_film = [p for p in fft_film_peak_info if 0.15 < p['period_nm'] < 3.0]
    print(f"FFT peaks in film region (0.15-3.0 nm): {len(reasonable_peaks_film)}")
    
    lattice_params_fft_film = {}
    if len(reasonable_peaks_film) >= 2:
        p1 = reasonable_peaks_film[0]
        p2 = None
        for p in reasonable_peaks_film[1:]:
            angle_diff = abs(p['angle_deg'] - p1['angle_deg'])
            if angle_diff > 160:
                angle_diff = 180 - angle_diff
            if angle_diff > 20:
                p2 = p
                break
        if p2 is None and len(reasonable_peaks_film) > 1:
            p2 = reasonable_peaks_film[1]
        
        lattice_params_fft_film = {
            'lattice_vector_1_period_nm': round(p1['period_nm'], 4),
            'lattice_vector_1_period_A': round(p1['period_A'], 2),
            'lattice_vector_1_angle_deg': round(p1['angle_deg'], 1),
            'lattice_vector_2_period_nm': round(p2['period_nm'], 4) if p2 else None,
            'lattice_vector_2_period_A': round(p2['period_A'], 2) if p2 else None,
            'lattice_vector_2_angle_deg': round(p2['angle_deg'], 1) if p2 else None,
        }
        print(f"LLTO Film lattice from FFT: d1={p1['period_nm']:.4f} nm ({p1['period_A']:.2f} A) at {p1['angle_deg']:.1f} deg")
        if p2:
            print(f"                            d2={p2['period_nm']:.4f} nm ({p2['period_A']:.2f} A) at {p2['angle_deg']:.1f} deg")
    elif len(reasonable_peaks_film) == 1:
        p1 = reasonable_peaks_film[0]
        lattice_params_fft_film = {
            'lattice_vector_1_period_nm': round(p1['period_nm'], 4),
            'lattice_vector_1_period_A': round(p1['period_A'], 2),
            'lattice_vector_1_angle_deg': round(p1['angle_deg'], 1),
        }
    else:
        lattice_params_fft_film = {'note': 'No clear lattice peaks found in film FFT'}
else:
    fft_film_log = None
    lattice_params_fft_film = {'note': 'Film region too small for FFT analysis'}
    reasonable_peaks_film = []

# ============================================================
# Step 7: Find zone axes for film region only
# ============================================================
print("Finding zone axes for LLTO film region...")
zone_axes_film_info = []
if total_count_film >= 10:
    try:
        zone_axes_film = find_zone_axes(positions_film, n_neighbors=9)
        zone_axes_film_list = [(float(v[0]), float(v[1])) for v in zone_axes_film]
        print(f"Found {len(zone_axes_film_list)} zone axis vectors in film")
        for i, v in enumerate(zone_axes_film_list):
            length_pix = np.sqrt(v[0]**2 + v[1]**2)
            length_nm = length_pix * pixel_size_nm
            length_A = length_pix * pixel_size_A
            angle = np.degrees(np.arctan2(v[1], v[0]))
            print(f"  Vector {i+1}: ({v[0]:.2f}, {v[1]:.2f}) pix, length={length_nm:.4f} nm ({length_A:.2f} A), angle={angle:.1f} deg")
            zone_axes_film_info.append({
                'vector_pixels': [round(v[0], 2), round(v[1], 2)],
                'length_nm': round(length_nm, 4),
                'length_A': round(length_A, 2),
                'angle_deg': round(angle, 1)
            })
    except Exception as e:
        print(f"Zone axes detection for film failed: {e}")
        zone_axes_film_list = []
else:
    zone_axes_film_list = []
    print("Not enough atoms in film for zone axis analysis")

# ============================================================
# Step 8: Extract column intensities for film atoms
# ============================================================
print("Extracting column intensities for LLTO film atoms...")
pos_x_film = positions_film[:, 0]
pos_y_film = positions_film[:, 1]
pos_row_film = np.clip(np.round(pos_y_film).astype(int), 0, image.shape[0] - 1)
pos_col_film = np.clip(np.round(pos_x_film).astype(int), 0, image.shape[1] - 1)

window = 2
intensities_film = []
for r, c in zip(pos_row_film, pos_col_film):
    r_min = max(0, r - window)
    r_max = min(image.shape[0], r + window + 1)
    c_min = max(0, c - window)
    c_max = min(image.shape[1], c + window + 1)
    intensities_film.append(float(np.mean(image[r_min:r_max, c_min:c_max])))
intensities_film = np.array(intensities_film)

if len(intensities_film) > 0:
    print(f"Film column intensity range: [{intensities_film.min():.1f}, {intensities_film.max():.1f}]")
    print(f"Film mean intensity: {intensities_film.mean():.1f} +/- {intensities_film.std():.1f}")

# ============================================================
# Step 9: Lattice constant estimation from NN distance distribution
# ============================================================
print("\n" + "="*60)
print("LATTICE CONSTANT ESTIMATION FOR LLTO FILM")
print("="*60)

# Method 1: Direct NN distance (this gives the projected nearest-neighbor distance)
print(f"\nMethod 1: Direct nearest-neighbor distance")
print(f"  Mean NN distance: {nn_mean_film_nm:.4f} +/- {nn_std_film_nm:.4f} nm")
print(f"  Mean NN distance: {nn_mean_film_A:.2f} +/- {nn_std_film_A:.2f} A")
print(f"  Median NN distance: {nn_median_film_nm:.4f} nm ({nn_median_film_A:.2f} A)")

# Method 2: Histogram peak fitting for more robust estimate
# The NN distance distribution may be multimodal if viewing along a zone axis
if len(nn_distances_film_nm) > 20:
    from scipy.signal import find_peaks as scipy_find_peaks
    hist_counts, hist_edges = np.histogram(nn_distances_film_nm, bins=80)
    hist_centers = (hist_edges[:-1] + hist_edges[1:]) / 2
    hist_smooth = uniform_filter1d(hist_counts.astype(float), size=3)
    
    peaks_idx, peak_props = scipy_find_peaks(hist_smooth, height=max(hist_smooth)*0.15, distance=5, prominence=max(hist_smooth)*0.05)
    
    if len(peaks_idx) > 0:
        nn_peak_distances = hist_centers[peaks_idx]
        nn_peak_heights = hist_smooth[peaks_idx]
        # Sort by height (most common distance first)
        sort_idx = np.argsort(nn_peak_heights)[::-1]
        nn_peak_distances = nn_peak_distances[sort_idx]
        nn_peak_heights = nn_peak_heights[sort_idx]
        
        print(f"\nMethod 2: Histogram peak analysis")
        for i, (d, h) in enumerate(zip(nn_peak_distances[:4], nn_peak_heights[:4])):
            print(f"  Peak {i+1}: {d:.4f} nm ({d*10:.2f} A), count={h:.0f}")
        
        # The most prominent peak is the best estimate of the lattice constant
        lattice_constant_nm = float(nn_peak_distances[0])
        lattice_constant_A = lattice_constant_nm * 10
        print(f"\n  >> Best estimate of lattice constant (NN): {lattice_constant_nm:.4f} nm ({lattice_constant_A:.2f} A)")
    else:
        lattice_constant_nm = nn_mean_film_nm
        lattice_constant_A = nn_mean_film_A
else:
    lattice_constant_nm = nn_mean_film_nm
    lattice_constant_A = nn_mean_film_A

# For perovskite LLTO, the lattice constant is typically ~3.87 A
# The NN distance in a perovskite [100] projection is a/sqrt(1) = a ~ 3.87 A (B-O-B distance)
print(f"\nNote: LLTO perovskite lattice constant (literature): ~3.87 A")
print(f"Measured NN distance: {lattice_constant_A:.2f} A")

# ============================================================
# Step 10: Generate visualizations
# ============================================================
print("\nGenerating visualizations...")

fig, axes = plt.subplots(2, 3, figsize=(20, 13), dpi=100)

# 1. Full image with film/substrate segmentation
ax = axes[0, 0]
ax.imshow(image, cmap='gray')
ax.axhline(y=interface_row, color='red', linestyle='--', linewidth=2, label='Interface')
if film_region == 'above':
    ax.axhline(y=film_row_max_effective, color='cyan', linestyle=':', linewidth=1, label='Film boundary')
    ax.fill_between([0, image.shape[1]-1], film_row_min_effective, film_row_max_effective,
                    alpha=0.1, color='lime')
    ax.text(10, film_row_min_effective + 20, 'LLTO Film', color='lime', fontsize=12, fontweight='bold')
    ax.text(10, substrate_row_min + 20, 'LSAT Substrate', color='red', fontsize=12, fontweight='bold')
else:
    ax.axhline(y=film_row_min_effective, color='cyan', linestyle=':', linewidth=1, label='Film boundary')
    ax.fill_between([0, image.shape[1]-1], film_row_min_effective, film_row_max_effective,
                    alpha=0.1, color='lime')
    ax.text(10, substrate_row_min + 20, 'LSAT Substrate', color='red', fontsize=12, fontweight='bold')
    ax.text(10, film_row_min_effective + 20, 'LLTO Film', color='lime', fontsize=12, fontweight='bold')
ax.legend(loc='lower right', fontsize=9)
ax.set_title('Image with Film/Substrate Segmentation', fontsize=11)
ax.set_xlim(0, image.shape[1])
ax.set_ylim(image.shape[0], 0)

# 2. Detected positions - film vs substrate
ax = axes[0, 1]
ax.imshow(image, cmap='gray')
if len(positions_substrate) > 0:
    ax.scatter(positions_substrate[:, 0], positions_substrate[:, 1], c='blue', s=2, alpha=0.4,
              linewidths=0, label=f'LSAT ({total_count_substrate})')
ax.scatter(positions_film[:, 0], positions_film[:, 1], c='lime', s=3, alpha=0.6,
          linewidths=0, label=f'LLTO ({total_count_film})')
ax.axhline(y=interface_row, color='red', linestyle='--', linewidth=1.5)
ax.legend(loc='lower right', fontsize=9, markerscale=5)
ax.set_title(f'Atomic Columns: LLTO film ({total_count_film}) vs LSAT ({total_count_substrate})', fontsize=11)
ax.set_xlim(0, image.shape[1])
ax.set_ylim(image.shape[0], 0)

# 3. Zoomed view of LLTO film with detected atoms
ax = axes[0, 2]
film_center_y = (film_row_min_effective + film_row_max_effective) // 2
zoom_size = min(200, abs(film_row_max_effective - film_row_min_effective) // 2 + 50)
zoom_center_x = image.shape[1] // 2
ymin_z = max(0, film_center_y - zoom_size)
ymax_z = min(image.shape[0], film_center_y + zoom_size)
xmin_z = max(0, zoom_center_x - zoom_size)
xmax_z = min(image.shape[1], zoom_center_x + zoom_size)
ax.imshow(image, cmap='gray')
mask_zoom = ((positions_film[:, 0] >= xmin_z) & (positions_film[:, 0] <= xmax_z) &
             (positions_film[:, 1] >= ymin_z) & (positions_film[:, 1] <= ymax_z))
ax.scatter(positions_film[mask_zoom, 0], positions_film[mask_zoom, 1],
          c='lime', s=20, alpha=0.8, linewidths=0.5, edgecolors='darkgreen')
ax.set_xlim(xmin_z, xmax_z)
ax.set_ylim(ymax_z, ymin_z)
ax.set_title('Zoomed: LLTO Film Region', fontsize=11)

# 4. NN distance histogram for LLTO film
ax = axes[1, 0]
if len(nn_distances_film_nm) > 0:
    ax.hist(nn_distances_film_nm, bins=60, color='steelblue', edgecolor='black',
            linewidth=0.5, alpha=0.8, label='LLTO film')
    ax.axvline(nn_mean_film_nm, color='red', linestyle='--', linewidth=1.5,
              label=f'Mean={nn_mean_film_nm:.3f} nm ({nn_mean_film_A:.2f} A)')
    ax.axvline(nn_median_film_nm, color='orange', linestyle=':', linewidth=1.5,
              label=f'Median={nn_median_film_nm:.3f} nm ({nn_median_film_A:.2f} A)')
    if 'lattice_constant_nm' in dir() and lattice_constant_nm != nn_mean_film_nm:
        ax.axvline(lattice_constant_nm, color='lime', linestyle='-', linewidth=2,
                  label=f'Peak={lattice_constant_nm:.3f} nm ({lattice_constant_A:.2f} A)')
ax.set_xlabel('Nearest-neighbor distance (nm)', fontsize=10)
ax.set_ylabel('Count', fontsize=10)
ax.set_title('NN Distance Distribution (LLTO Film Only)', fontsize=11)
ax.legend(fontsize=8)

# 5. FFT of film region
ax = axes[1, 1]
if fft_film_log is not None:
    ax.imshow(fft_film_log, cmap='inferno', origin='lower')
    center_fy_plot = fft_film_log.shape[0] // 2
    center_fx_plot = fft_film_log.shape[1] // 2
    # Annotate peaks
    for i, p in enumerate(reasonable_peaks_film[:6]):
        ax.scatter(p['col'], p['row'], c='cyan', s=40, marker='o', facecolors='none', linewidths=1.5)
        ax.annotate(f"{p['period_nm']:.2f}nm\n({p['period_A']:.1f}A)", (p['col'], p['row']),
                   color='white', fontsize=7, ha='left', va='bottom')
    view_range_y = min(150, fft_film_log.shape[0] // 2 - 5)
    view_range_x = min(200, fft_film_log.shape[1] // 2 - 5)
    ax.set_xlim(center_fx_plot - view_range_x, center_fx_plot + view_range_x)
    ax.set_ylim(center_fy_plot - view_range_y, center_fy_plot + view_range_y)
    ax.set_title('FFT of LLTO Film Region', fontsize=11)
else:
    ax.text(0.5, 0.5, 'Film region too small\nfor FFT analysis', transform=ax.transAxes,
            ha='center', va='center', fontsize=12)
    ax.set_title('FFT of LLTO Film Region', fontsize=11)

# 6. Intensity profile showing interface
ax = axes[1, 2]
ax_twin = ax.twinx()
row_positions_nm = np.arange(image.shape[0]) * pixel_size_nm
ax.plot(row_positions_nm, row_mean_smooth, 'b-', linewidth=1, label='Mean intensity')
ax_twin.plot(row_positions_nm, row_local_var_smooth, 'r-', linewidth=1, alpha=0.7, label='Local variance')
ax.axvline(interface_row * pixel_size_nm, color='green', linestyle='--', linewidth=2, label='Interface')
ax.axvspan(film_row_min_effective * pixel_size_nm, film_row_max_effective * pixel_size_nm,
           alpha=0.15, color='lime', label='LLTO Film')
ax.set_xlabel('Position (nm)', fontsize=10)
ax.set_ylabel('Mean Intensity', fontsize=10, color='blue')
ax_twin.set_ylabel('Local Variance', fontsize=10, color='red')
ax.set_title('Vertical Intensity Profile & Interface', fontsize=11)
lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax_twin.get_legend_handles_labels()
ax.legend(lines1 + lines2, labels1 + labels2, fontsize=8, loc='upper right')

plt.tight_layout()
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("Saved analysis_visualization.png")

# ============================================================
# Save arrays
# ============================================================
np.save('atomic_column_positions.npy', positions_film)
print(f"Saved atomic_column_positions.npy (LLTO film only), shape={positions_film.shape}")

np.save('column_intensities.npy', intensities_film)
print(f"Saved column_intensities.npy (LLTO film only), shape={intensities_film.shape}")

np.save('nn_distances_nm.npy', nn_distances_film_nm)
print(f"Saved nn_distances_nm.npy (LLTO film only), shape={nn_distances_film_nm.shape}")

if heatmap is not None:
    np.save('dcnn_heatmap.npy', heatmap)
    print(f"Saved dcnn_heatmap.npy, shape={heatmap.shape}")

# ============================================================
# Gaussian fit statistics for film atoms
# ============================================================
gaussian_stats = {}
if use_refined and sigma_x is not None:
    sigma_x_film = sigma_x[film_mask]
    sigma_y_film = sigma_y[film_mask]
    valid_sx = sigma_x_film[np.isfinite(sigma_x_film)]
    valid_sy = sigma_y_film[np.isfinite(sigma_y_film)]
    if len(valid_sx) > 0:
        gaussian_stats['mean_sigma_x_pix'] = round(float(np.mean(valid_sx)), 3)
        gaussian_stats['mean_sigma_x_nm'] = round(float(np.mean(valid_sx)) * pixel_size_nm, 4)
    if len(valid_sy) > 0:
        gaussian_stats['mean_sigma_y_pix'] = round(float(np.mean(valid_sy)), 3)
        gaussian_stats['mean_sigma_y_nm'] = round(float(np.mean(valid_sy)) * pixel_size_nm, 4)
    if amplitude is not None:
        amp_film = amplitude[film_mask]
        valid_amp = amp_film[np.isfinite(amp_film)]
        if len(valid_amp) > 0:
            gaussian_stats['mean_amplitude'] = round(float(np.mean(valid_amp)), 2)
            gaussian_stats['std_amplitude'] = round(float(np.std(valid_amp)), 2)

# ============================================================
# Compile results
# ============================================================
saved_arrays = {
    'atomic_column_positions.npy': {
        'description': f'Refined atomic column positions (x,y) in pixel coordinates for LLTO film region only, {total_count_film} columns',
        'shape': list(positions_film.shape),
        'dtype': str(positions_film.dtype)
    },
    'column_intensities.npy': {
        'description': f'Raw intensities at each LLTO film atomic column position (5x5 window average), {total_count_film} values',
        'shape': list(intensities_film.shape),
        'dtype': str(intensities_film.dtype)
    },
    'nn_distances_nm.npy': {
        'description': f'Nearest-neighbor distances in nm for LLTO film columns only, {len(nn_distances_film_nm)} values',
        'shape': list(nn_distances_film_nm.shape),
        'dtype': str(nn_distances_film_nm.dtype)
    }
}
if heatmap is not None:
    saved_arrays['dcnn_heatmap.npy'] = {
        'description': 'DCNN detection probability heatmap (full image)',
        'shape': list(heatmap.shape),
        'dtype': str(heatmap.dtype)
    }

results = {
    'analysis_type': 'Lattice constant measurement in LLTO thin film (excluding LSAT substrate) from STEM image using DCNN atom detection and FFT analysis',
    'extracted_features': {
        'film_substrate_segmentation': {
            'interface_row_pixel': interface_row,
            'interface_position_nm': round(interface_row * pixel_size_nm, 2),
            'film_region': film_region + ' interface',
            'film_row_range_pixels': [film_row_min_effective, film_row_max_effective],
            'film_row_range_nm': [round(film_row_min_effective * pixel_size_nm, 2), round(film_row_max_effective * pixel_size_nm, 2)],
            'film_thickness_nm': round(film_thickness_nm, 2),
            'atoms_in_LLTO_film': total_count_film,
            'atoms_in_LSAT_substrate': total_count_substrate,
            'total_atoms_detected': total_count_all
        },
        'lattice_constant_LLTO_film': {
            'nearest_neighbor_distance': {
                'mean_nm': round(nn_mean_film_nm, 4),
                'mean_A': round(nn_mean_film_A, 2),
                'std_nm': round(nn_std_film_nm, 4),
                'std_A': round(nn_std_film_A, 2),
                'median_nm': round(nn_median_film_nm, 4),
                'median_A': round(nn_median_film_A, 2)
            },
            'lattice_constant_from_NN_peak': {
                'value_nm': round(lattice_constant_nm, 4),
                'value_A': round(lattice_constant_A, 2),
                'method': 'Most prominent peak in NN distance histogram'
            },
            'second_nearest_neighbor': {
                'mean_nm': round(nn2_mean_film_nm, 4) if nn2_mean_film_nm else None,
                'mean_A': round(nn2_mean_film_A, 2) if nn2_mean_film_A else None
            },
            'lattice_parameters_from_FFT': lattice_params_fft_film,
            'lattice_vectors_from_zone_axes': zone_axes_film_info,
            'literature_comparison': {
                'LLTO_bulk_lattice_constant_A': 3.87,
                'measured_A': round(lattice_constant_A, 2),
                'deviation_percent': round(abs(lattice_constant_A - 3.87) / 3.87 * 100, 2)
            }
        },
        'column_intensity_distribution_film': {
            'mean': round(float(intensities_film.mean()), 1) if len(intensities_film) > 0 else None,
            'std': round(float(intensities_film.std()), 1) if len(intensities_film) > 0 else None,
            'min': round(float(intensities_film.min()), 1) if len(intensities_film) > 0 else None,
            'max': round(float(intensities_film.max()), 1) if len(intensities_film) > 0 else None
        },
        'spatial_calibration': {
            'pixel_size_nm': round(pixel_size_nm, 4),
            'pixel_size_A': round(pixel_size_A, 4),
            'fov_nm': fov_nm,
            'image_size_pixels': image_size
        },
        'gaussian_fit_statistics': gaussian_stats
    },
    'quality_metrics': {
        'detection_method': 'detect_atoms_dcnn (AtomNet3) + refine_positions',
        'dcnn_threshold': 0.8,
        'refinement_percent_to_nn': 0.4,
        'positions_refined': use_refined,
        'nn_distance_coefficient_of_variation': round(nn_std_film_nm / nn_mean_film_nm, 4) if nn_mean_film_nm > 0 else None,
        'num_fft_lattice_peaks_film': len(reasonable_peaks_film),
        'num_zone_axes_found_film': len(zone_axes_film_info)
    },
    'summary': f'Measured lattice constant in LLTO thin film (excluding LSAT substrate). The film/substrate interface was detected at row {interface_row} ({interface_row * pixel_size_nm:.1f} nm). {total_count_film} atomic columns were identified in the LLTO film region (thickness ~{film_thickness_nm:.1f} nm). The nearest-neighbor distance in the LLTO film is {nn_mean_film_nm:.4f} +/- {nn_std_film_nm:.4f} nm ({nn_mean_film_A:.2f} +/- {nn_std_film_A:.2f} A). The best estimate of the lattice constant from the NN distance histogram peak is {lattice_constant_nm:.4f} nm ({lattice_constant_A:.2f} A). This compares to the bulk LLTO value of ~3.87 A ({abs(lattice_constant_A - 3.87) / 3.87 * 100:.1f}% deviation).',
    'saved_arrays': saved_arrays
}

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
