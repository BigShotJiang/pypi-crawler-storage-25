import numpy as np
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import least_squares

# Load data
data = np.load('/Users/maxim.ziatdinov/Code/SciLink/analysis_session_20260402_182506/results/analysis_raman_silicon_CurveFit_20260402_182647_001/temp_spectrum_0.npy')

if data.ndim == 2:
    if data.shape[0] == 2:
        x = data[0]
        y = data[1]
    elif data.shape[1] == 2:
        x = data[:, 0]
        y = data[:, 1]
    else:
        x = np.linspace(200, 1100, data.shape[-1])
        y = data.flatten()
else:
    n = len(data)
    x = np.linspace(200, 1100, n)
    y = data

# Sort by x
sort_idx = np.argsort(x)
x = x[sort_idx]
y = y[sort_idx]

# Model functions
def lorentzian(x, center, amplitude, gamma):
    """Lorentzian peak. gamma is half-width at half-maximum (HWHM).
    FWHM = 2*gamma. Peak height = amplitude.
    L(x) = amplitude * gamma^2 / ((x - center)^2 + gamma^2)
    """
    return amplitude * gamma**2 / ((x - center)**2 + gamma**2)

def gaussian(x, center, amplitude, sigma):
    """Gaussian peak. FWHM = 2*sqrt(2*ln2)*sigma ~ 2.3548*sigma.
    Peak height = amplitude.
    G(x) = amplitude * exp(-(x-center)^2 / (2*sigma^2))
    """
    return amplitude * np.exp(-(x - center)**2 / (2 * sigma**2))

def model(x, params):
    """Total model: constant baseline + Lorentzian(F2g) + Gaussian(2TA) + Gaussian(2TO)"""
    C = params[0]
    # Peak 1: Lorentzian (F2g at ~520)
    center1, amp1, gamma1 = params[1], params[2], params[3]
    # Peak 2: Gaussian (2TA at ~300)
    center2, amp2, sigma2 = params[4], params[5], params[6]
    # Peak 3: Gaussian (2TO at ~950)
    center3, amp3, sigma3 = params[7], params[8], params[9]
    
    return (C 
            + lorentzian(x, center1, amp1, gamma1) 
            + gaussian(x, center2, amp2, sigma2) 
            + gaussian(x, center3, amp3, sigma3))

def residuals(params, x, y):
    return model(x, params) - y

# Initial guesses:
# [C, center1, amp1, gamma1, center2, amp2, sigma2, center3, amp3, sigma3]
# Note: gamma1 is HWHM, so FWHM=5 means gamma=2.5
# sigma2: FWHM=2*sqrt(2*ln2)*sigma => sigma = FWHM/(2.3548). For FWHM~59 => sigma=25
p0 = np.array([105.0,   # baseline
               520.0, 800.0, 2.5,   # F2g: center, amplitude, HWHM (FWHM~5)
               302.0, 200.0, 25.0,  # 2TA: center, amplitude, sigma (FWHM~59)
               945.0, 160.0, 20.0]) # 2TO: center, amplitude, sigma (FWHM~47)

# Bounds: [lower, upper]
# C: [80, 130]
# center1: [515, 525], amp1: [0, 5000], gamma1 (HWHM): [1, 7.5] (FWHM [2,15])
# center2: [270, 330], amp2: [0, 3000], sigma2: [10/2.3548, 60/2.3548] ~ [4.25, 25.48] but plan says sigma bounded [10,60] directly
# center3: [920, 970], amp3: [0, 3000], sigma3: bounded [10, 50] directly
# Note: The plan states sigma bounds as [10,60] and [10,50]. Interpreting these as the sigma parameter directly.
lower = [80,   515, 0,   1.0,  270, 0,   10.0,  920, 0,   10.0]
upper = [130,  525, 5000, 7.5, 330, 3000, 60.0, 970, 3000, 50.0]

# Fit using Levenberg-Marquardt via least_squares (method='lm' doesn't support bounds,
# so use 'trf' which supports bounds and is similar)
result = least_squares(residuals, p0, args=(x, y), bounds=(lower, upper), method='trf', 
                       max_nfev=10000, ftol=1e-12, xtol=1e-12, gtol=1e-12)

popt = result.x

# Compute covariance matrix from Jacobian
J = result.jac
# Covariance = inv(J^T J) * s^2, where s^2 = sum(residuals^2) / (n - p)
n_data = len(x)
n_params = len(popt)
res = result.fun
s_sq = np.sum(res**2) / (n_data - n_params)
try:
    cov = np.linalg.inv(J.T @ J) * s_sq
    perr = np.sqrt(np.diag(cov))
except np.linalg.LinAlgError:
    perr = np.zeros(n_params)

# Extract parameters
C_val, C_err = popt[0], perr[0]
center1, center1_err = popt[1], perr[1]
amp1, amp1_err = popt[2], perr[2]
gamma1, gamma1_err = popt[3], perr[3]  # HWHM
center2, center2_err = popt[4], perr[4]
amp2, amp2_err = popt[5], perr[5]
sigma2, sigma2_err = popt[6], perr[6]
center3, center3_err = popt[7], perr[7]
amp3, amp3_err = popt[8], perr[8]
sigma3, sigma3_err = popt[9], perr[9]

# Derived quantities
# Peak 1 (Lorentzian): FWHM = 2*gamma; integrated area = amplitude * pi * gamma
fwhm1 = 2 * gamma1
fwhm1_err = 2 * gamma1_err
area1 = amp1 * np.pi * gamma1
area1_err = np.pi * np.sqrt((gamma1 * amp1_err)**2 + (amp1 * gamma1_err)**2)

# Peak 2 (Gaussian): FWHM = 2*sqrt(2*ln2)*sigma; integrated area = amplitude * sigma * sqrt(2*pi)
fwhm2 = 2 * np.sqrt(2 * np.log(2)) * sigma2
fwhm2_err = 2 * np.sqrt(2 * np.log(2)) * sigma2_err
area2 = amp2 * sigma2 * np.sqrt(2 * np.pi)
area2_err = np.sqrt(2 * np.pi) * np.sqrt((sigma2 * amp2_err)**2 + (amp2 * sigma2_err)**2)

# Peak 3 (Gaussian): same formulas
fwhm3 = 2 * np.sqrt(2 * np.log(2)) * sigma3
fwhm3_err = 2 * np.sqrt(2 * np.log(2)) * sigma3_err
area3 = amp3 * sigma3 * np.sqrt(2 * np.pi)
area3_err = np.sqrt(2 * np.pi) * np.sqrt((sigma3 * amp3_err)**2 + (amp3 * sigma3_err)**2)

# Fit quality
y_fit = model(x, popt)
ss_res = np.sum((y - y_fit)**2)
ss_tot = np.sum((y - np.mean(y))**2)
r_squared = 1 - ss_res / ss_tot
rmse = np.sqrt(np.mean((y - y_fit)**2))

# --- Visualization ---
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), gridspec_kw={'height_ratios': [3, 1]}, sharex=True)

# Top panel: data + fit + components
ax1.plot(x, y, 'k.', markersize=1.5, alpha=0.5, label='Data')
ax1.plot(x, y_fit, 'r-', linewidth=2, label='Total Fit')

# Components
baseline = np.full_like(x, C_val)
comp1 = lorentzian(x, popt[1], popt[2], popt[3]) + C_val
comp2 = gaussian(x, popt[4], popt[5], popt[6]) + C_val
comp3 = gaussian(x, popt[7], popt[8], popt[9]) + C_val

ax1.plot(x, baseline, 'k--', linewidth=1, alpha=0.5, label=f'Baseline (C={C_val:.1f})')
ax1.fill_between(x, C_val, comp1, alpha=0.3, color='blue', label=f'Si F$_{{2g}}$ ({center1:.1f} cm$^{{-1}}$)')
ax1.fill_between(x, C_val, comp2, alpha=0.3, color='green', label=f'2TA ({center2:.1f} cm$^{{-1}}$)')
ax1.fill_between(x, C_val, comp3, alpha=0.3, color='orange', label=f'2TO ({center3:.1f} cm$^{{-1}}$)')

ax1.set_ylabel('Intensity (counts)', fontsize=12)
ax1.set_title('Raman Spectrum of Crystalline Silicon — Curve Fit', fontsize=14)
ax1.legend(loc='upper right', fontsize=9)
ax1.set_xlim(x.min(), x.max())

# Bottom panel: residuals
residual = y - y_fit
ax2.plot(x, residual, 'k.', markersize=1, alpha=0.5)
ax2.axhline(0, color='r', linewidth=1)
ax2.set_xlabel('Raman Shift (cm$^{-1}$)', fontsize=12)
ax2.set_ylabel('Residual', fontsize=12)
ax2.set_title(f'Residuals (RMSE={rmse:.2f}, R²={r_squared:.6f})', fontsize=11)

plt.tight_layout()
plt.savefig('fit_visualization.png', dpi=150, bbox_inches='tight')
plt.close()

# --- Results JSON ---
results = {
    "model_type": "Constant baseline + Lorentzian (Si F2g ~520 cm-1) + Gaussian (2TA ~300 cm-1) + Gaussian (2TO ~950 cm-1)",
    "parameters": {
        "baseline": {
            "offset": round(float(C_val), 4),
            "offset_err": round(float(C_err), 4)
        },
        "Si_F2g": {
            "center": round(float(center1), 4),
            "center_err": round(float(center1_err), 4),
            "amplitude": round(float(amp1), 4),
            "amplitude_err": round(float(amp1_err), 4),
            "FWHM": round(float(fwhm1), 4),
            "FWHM_err": round(float(fwhm1_err), 4),
            "integrated_area": round(float(area1), 4),
            "integrated_area_err": round(float(area1_err), 4),
            "lineshape": "Lorentzian"
        },
        "2TA": {
            "center": round(float(center2), 4),
            "center_err": round(float(center2_err), 4),
            "amplitude": round(float(amp2), 4),
            "amplitude_err": round(float(amp2_err), 4),
            "FWHM": round(float(fwhm2), 4),
            "FWHM_err": round(float(fwhm2_err), 4),
            "integrated_area": round(float(area2), 4),
            "integrated_area_err": round(float(area2_err), 4),
            "lineshape": "Gaussian"
        },
        "2TO": {
            "center": round(float(center3), 4),
            "center_err": round(float(center3_err), 4),
            "amplitude": round(float(amp3), 4),
            "amplitude_err": round(float(amp3_err), 4),
            "FWHM": round(float(fwhm3), 4),
            "FWHM_err": round(float(fwhm3_err), 4),
            "integrated_area": round(float(area3), 4),
            "integrated_area_err": round(float(area3_err), 4),
            "lineshape": "Gaussian"
        }
    },
    "fit_quality": {
        "r_squared": round(float(r_squared), 6),
        "rmse": round(float(rmse), 4),
        "n_data_points": int(n_data),
        "n_parameters": int(n_params),
        "degrees_of_freedom": int(n_data - n_params)
    },
    "summary": (
        f"Crystalline Si Raman spectrum fitted with 3 peaks on a constant baseline. "
        f"The first-order Si F2g phonon is at {center1:.2f} +/- {center1_err:.2f} cm-1 "
        f"with Lorentzian FWHM = {fwhm1:.2f} +/- {fwhm1_err:.2f} cm-1. "
        f"Second-order 2TA overtone at {center2:.1f} cm-1 (Gaussian, FWHM={fwhm2:.1f} cm-1) "
        f"and 2TO overtone at {center3:.1f} cm-1 (Gaussian, FWHM={fwhm3:.1f} cm-1). "
        f"R-squared = {r_squared:.6f}, RMSE = {rmse:.2f} counts. "
        f"Fit used scipy.optimize.least_squares (TRF algorithm with bounds) "
        f"implementing Levenberg-Marquardt-like trust region approach with parameter bounds."
    )
}

print(f"FIT_RESULTS_JSON:{json.dumps(results)}")
