"""
Generate synthetic tabular catalyst screening data for testing analyze_file.

Scenario: A researcher runs a catalyst screening experiment varying temperature,
pressure, and catalyst loading. Each run measures raw product and byproduct
masses. The user wants to optimize yield and selectivity, which require simple
math from the raw columns:
  - yield_pct = product_mass_g / feed_mass_g * 100
  - selectivity = product_mass_g / (product_mass_g + byproduct_mass_g)

This tests that the scalarizer can derive meaningful targets from raw
measurements via simple calculations.
"""

import numpy as np
import pandas as pd
from pathlib import Path

HERE = Path(__file__).parent
np.random.seed(123)

n_runs = 20
feed_mass = 10.0  # grams, constant

# Input parameters (controllable)
temperature_C = np.random.uniform(150, 350, n_runs).round(1)
pressure_bar = np.random.uniform(1, 10, n_runs).round(1)
catalyst_loading_pct = np.random.uniform(0.5, 5.0, n_runs).round(2)

# Simulate product mass (depends on all three inputs)
# Higher temp and moderate pressure → more product; catalyst has diminishing returns
product_mass = (
    feed_mass
    * (0.3 + 0.002 * (temperature_C - 150))                  # temp effect
    * np.clip(0.5 + 0.08 * pressure_bar, 0.5, 1.2)           # pressure effect
    * (1 - np.exp(-1.5 * catalyst_loading_pct))               # catalyst saturation
    + np.random.normal(0, 0.15, n_runs)                       # noise
)
product_mass = np.clip(product_mass, 0.1, feed_mass).round(3)

# Byproduct mass (inversely correlated with selectivity at high temp)
byproduct_mass = (
    0.5
    + 0.005 * (temperature_C - 150)       # more byproduct at high temp
    + 0.1 * pressure_bar                   # more byproduct at high pressure
    + np.random.normal(0, 0.1, n_runs)
)
byproduct_mass = np.clip(byproduct_mass, 0.05, 5.0).round(3)

df = pd.DataFrame({
    "run_id": [f"R{i+1:03d}" for i in range(n_runs)],
    "temperature_C": temperature_C,
    "pressure_bar": pressure_bar,
    "catalyst_loading_pct": catalyst_loading_pct,
    "feed_mass_g": feed_mass,
    "product_mass_g": product_mass,
    "byproduct_mass_g": byproduct_mass,
})

df.to_csv(HERE / "catalyst_screening.csv", index=False)
print(f"Generated catalyst_screening.csv with {n_runs} runs")
print(f"Output: {HERE / 'catalyst_screening.csv'}")
print()
print("Expected scalarizer derivations:")
print("  - yield_pct = product_mass_g / feed_mass_g * 100")
print("  - selectivity = product_mass_g / (product_mass_g + byproduct_mass_g)")
print("  - inputs: temperature_C, pressure_bar, catalyst_loading_pct")
print("  - targets: yield_pct, selectivity")
