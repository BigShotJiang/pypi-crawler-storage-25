import pandas as pd, json
df = pd.read_excel('/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260401_224650/knowledge/PWSdatabase.xlsx')
cols = df.columns.tolist()
start_idx = cols.index('Ag')
end_idx = cols.index('Zn')
element_cols = cols[start_idx:end_idx+1]
answer = element_cols
summary = f"There are {len(element_cols)} element/ion concentration columns from 'Ag' to 'Zn': {', '.join(element_cols)}"
print(json.dumps({"answer": answer, "summary": summary}))
