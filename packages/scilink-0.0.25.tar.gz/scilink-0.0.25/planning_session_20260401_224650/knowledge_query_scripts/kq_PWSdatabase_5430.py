import pandas as pd, json
df = pd.read_excel('/Users/maxim.ziatdinov/Code/SciLink/planning_session_20260401_224650/knowledge/PWSdatabase.xlsx')
elements = ['Li', 'Co', 'Ni', 'Mn', 'V', 'W', 'Cs', 'Rb', 'Sr', 'Ba', 'U', 'Sc']
df_num = df[elements].apply(pd.to_numeric, errors='coerce')
stats = {k: {kk: (round(float(vv), 4) if pd.notna(vv) else None) for kk, vv in v.items()} for k, v in df_num.agg(['count', 'mean', 'median', 'max']).to_dict().items()}
top_basin = df.assign(Li_num=pd.to_numeric(df['Li'], errors='coerce')).dropna(subset=['Li_num']).groupby('BASIN')['Li_num'].mean().idxmax()
answer = {"element_stats": stats, "units": "mg/L (as noted in UNITS column)", "highest_mean_Li_basin": top_basin}; summary = f"Statistics (count, mean, median, max) computed for Li, Co, Ni, Mn, V, W, Cs, Rb, Sr, Ba, U, Sc in mg/L; the basin with the highest mean Li concentration is {top_basin}"
print(json.dumps({"answer": answer, "summary": summary}))
