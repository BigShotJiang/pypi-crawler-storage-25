import numpy as np
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import ndimage, signal
from scipy.spatial import cKDTree
from skimage import filters
import warnings
warnings.filterwarnings('ignore')

# Load image
path = '/Users/maxim.ziatdinov/Code/SciLink/analysis_session_20260403_183439/results/analysis__easy__LLTO_ImageAnalysis_20260403_183642_001/image_0000/temp_image_0.npy'
image = np.load(path)
print(f"Image shape: {image.shape}, dtype: {image.dtype}")
print(f"Intensity range: [{image.min()}, {image.max()}]")

# Image parameters
image_size_px = image.shape[0]  # 1024
fov_nm = 20.88
pixel_size_nm = fov_nm / image_size_px  # nm/pixel
pixel_size_A = pixel_size_nm * 10  # Angstroms/pixel
print(f"Pixel size: {pixel_size_nm:.4f} nm/pixel = {pixel_size_A:.4f} A/pixel")

# Expected lattice parameter for LLTO pseudocubic ~0.387 nm
a_pseudocubic_nm = 0.387
a_superstructure_nm = 0.774  # 2x pseudocubic
sep_pseudocubic_px = a_pseudocubic_nm / pixel_size_nm
print(f"Expected pseudocubic separation: {sep_pseudocubic_px:.1f} pixels")

# Normalize image for display
img_norm = (image - image.min()) / (image.max() - image.min())

# ======== STEP 1: FFT Analysis ========
print("\n=== Step 1: FFT Analysis ===")
# Apply window to reduce edge artifacts
window_1d = np.hanning(image_size_px)
window_2d = np.outer(window_1d, window_1d)
img_windowed = (image - image.mean()) * window_2d

fft2 = np.fft.fft2(img_windowed)
fft_shift = np.fft.fftshift(fft2)
power_spectrum = np.abs(fft_shift) ** 2
log_power = np.log1p(power_spectrum)

# Find peaks in FFT (excluding center)
center = image_size_px // 2
# Create radial mask to exclude center
y_grid, x_grid = np.mgrid[:image_size_px, :image_size_px]
r_grid = np.sqrt((x_grid - center)**2 + (y_grid - center)**2)

# Mask center and very edges
mask_fft = (r_grid > 15) & (r_grid < center - 10)
log_power_masked = log_power * mask_fft

# Find FFT peaks
from skimage.feature import peak_local_max
fft_peaks = peak_local_max(log_power_masked, min_distance=5, num_peaks=30, threshold_rel=0.3)
print(f"Found {len(fft_peaks)} FFT peaks")

# Compute distances from center and corresponding spatial frequencies
fft_peak_info = []
for pk in fft_peaks:
    dy = pk[0] - center
    dx = pk[1] - center
    dist = np.sqrt(dx**2 + dy**2)
    if dist > 5:  # skip center
        spatial_freq = dist / image_size_px  # cycles/pixel
        real_space_period_px = 1.0 / spatial_freq if spatial_freq > 0 else np.inf
        real_space_period_nm = real_space_period_px * pixel_size_nm
        angle = np.degrees(np.arctan2(dy, dx))
        fft_peak_info.append({
            'row': int(pk[0]), 'col': int(pk[1]),
            'dist_px': float(dist),
            'period_nm': float(real_space_period_nm),
            'angle_deg': float(angle),
            'intensity': float(log_power[pk[0], pk[1]])
        })

fft_peak_info.sort(key=lambda x: x['intensity'], reverse=True)

# Identify pseudocubic and superstructure peaks
pseudocubic_peaks = [p for p in fft_peak_info if 0.30 < p['period_nm'] < 0.50]
superstructure_peaks = [p for p in fft_peak_info if 0.60 < p['period_nm'] < 1.00]

print(f"Pseudocubic FFT peaks (~0.387 nm): {len(pseudocubic_peaks)}")
for p in pseudocubic_peaks[:4]:
    print(f"  period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f} deg, intensity={p['intensity']:.1f}")

print(f"Superstructure FFT peaks (~0.774 nm): {len(superstructure_peaks)}")
for p in superstructure_peaks[:4]:
    print(f"  period={p['period_nm']:.3f} nm, angle={p['angle_deg']:.1f} deg, intensity={p['intensity']:.1f}")

# Extract lattice parameters from FFT
lattice_params_fft = {}
if pseudocubic_peaks:
    periods_pc = [p['period_nm'] for p in pseudocubic_peaks[:4]]
    lattice_params_fft['pseudocubic_period_nm'] = float(np.mean(periods_pc))
    lattice_params_fft['pseudocubic_period_std_nm'] = float(np.std(periods_pc))
    lattice_params_fft['pseudocubic_angles_deg'] = [p['angle_deg'] for p in pseudocubic_peaks[:4]]

if superstructure_peaks:
    periods_ss = [p['period_nm'] for p in superstructure_peaks[:4]]
    lattice_params_fft['superstructure_period_nm'] = float(np.mean(periods_ss))
    lattice_params_fft['superstructure_period_std_nm'] = float(np.std(periods_ss))
    lattice_params_fft['superstructure_angles_deg'] = [p['angle_deg'] for p in superstructure_peaks[:4]]
    lattice_params_fft['superstructure_direction'] = superstructure_peaks[0]['angle_deg'] if superstructure_peaks else None

print(f"\nLattice parameters from FFT: {lattice_params_fft}")

# ======== STEP 2: DCNN Atom Detection ========
print("\n=== Step 2: DCNN Atom Detection ===")
from scilink.tools.atom_finding_tools import detect_atoms, detect_atoms_dcnn, refine_positions, find_zone_axes, find_missing_atoms, subtract_atoms

try:
    dcnn_result = detect_atoms_dcnn(image, fov_nm=fov_nm, threshold=0.8, refine=True)
    positions_dcnn = dcnn_result['positions']
    heatmap = dcnn_result.get('heatmap', None)
    print(f"DCNN detected {len(positions_dcnn)} columns")
except Exception as e:
    print(f"DCNN detection failed: {e}")
    positions_dcnn = np.array([])
    heatmap = None

# ======== STEP 3: Fallback if needed ========
# Expected column count: for pseudocubic lattice, ~(fov/a)^2
expected_count = (fov_nm / a_pseudocubic_nm) ** 2
print(f"Expected column count (pseudocubic): ~{expected_count:.0f}")

use_dcnn = len(positions_dcnn) >= 0.90 * expected_count

if not use_dcnn and len(positions_dcnn) > 0:
    print(f"DCNN count {len(positions_dcnn)} < 0.90 * {expected_count:.0f}, but trying with what we have first")
    # Still try DCNN result if reasonably close
    if len(positions_dcnn) >= 0.5 * expected_count:
        use_dcnn = True

if use_dcnn:
    positions_all = positions_dcnn
    print(f"Using DCNN positions: {len(positions_all)} columns")
else:
    print("Falling back to classical detection with bandpass filtering")
    sep_px = int(sep_pseudocubic_px * 0.75)
    classical_result = detect_atoms(image, separation=max(sep_px, 5),
                                     threshold_rel=0.02, refine=True,
                                     subtract_background=True,
                                     normalize_intensity=True)
    positions_all = classical_result['positions']
    print(f"Classical detected {len(positions_all)} columns")

# ======== STEP 4: Refine positions ========
print("\n=== Step 4: Refine Positions ===")
try:
    refined = refine_positions(image, positions_all, percent_to_nn=0.4)
    positions_refined = refined['positions']
    sigma_x = refined['sigma_x']
    sigma_y = refined['sigma_y']
    amplitude = refined['amplitude']
    rotation = refined['rotation']
    print(f"Refined {len(positions_refined)} positions")
    print(f"Amplitude range: [{np.nanmin(amplitude):.1f}, {np.nanmax(amplitude):.1f}]")
    print(f"Mean sigma_x: {np.nanmean(sigma_x):.2f}, sigma_y: {np.nanmean(sigma_y):.2f}")
except Exception as e:
    print(f"Refinement failed: {e}, using unrefined positions")
    positions_refined = positions_all
    sigma_x = None
    sigma_y = None
    amplitude = None
    rotation = None

# ======== STEP 5: Find zone axes ========
print("\n=== Step 5: Find Zone Axes ===")
try:
    zone_axes = find_zone_axes(positions_refined, n_neighbors=15)
    print(f"Found {len(zone_axes)} zone axes:")
    for i, zv in enumerate(zone_axes):
        length_px = np.sqrt(zv[0]**2 + zv[1]**2)
        length_nm = length_px * pixel_size_nm
        angle = np.degrees(np.arctan2(zv[1], zv[0]))
        print(f"  Vector {i}: ({zv[0]:.1f}, {zv[1]:.1f}) px = {length_nm:.3f} nm, angle={angle:.1f} deg")
except Exception as e:
    print(f"Zone axis finding failed: {e}")
    zone_axes = []

# ======== STEP 6: Find missing atoms (secondary sublattice) ========
print("\n=== Step 6: Find Missing Atoms ===")
predicted_secondary = None
if len(zone_axes) >= 1:
    try:
        min_dist = sep_pseudocubic_px / 3.0
        predicted_secondary = find_missing_atoms(positions_refined, zone_axes[0],
                                                  fraction=0.5, min_distance=max(min_dist, 3.0))
        print(f"Predicted {len(predicted_secondary)} secondary sublattice positions")
    except Exception as e:
        print(f"find_missing_atoms failed: {e}")

# ======== STEP 7: Subtract atoms for secondary sublattice verification ========
print("\n=== Step 7: Subtract Atoms ===")
residual = None
result2 = None
if sigma_x is not None and amplitude is not None:
    try:
        rot_arg = rotation if rotation is not None else None
        residual = subtract_atoms(image, positions_refined, sigma_x, sigma_y, amplitude, rot_arg)
        print(f"Residual range: [{residual.min():.1f}, {residual.max():.1f}]")
        
        # Try to detect secondary sublattice in residual
        sep_px_secondary = int(sep_pseudocubic_px * 0.6)
        try:
            result2 = detect_atoms(residual, separation=max(sep_px_secondary, 5),
                                   threshold_rel=0.01, refine=True,
                                   subtract_background=True,
                                   normalize_intensity=True)
            print(f"Secondary sublattice: {len(result2['positions'])} columns detected in residual")
        except Exception as e:
            print(f"Secondary detection failed: {e}")
    except Exception as e:
        print(f"Atom subtraction failed: {e}")

# ======== STEP 8: Assign sublattices by position and intensity ========
print("\n=== Step 8: Sublattice Assignment ===")

# Approach: Use zone axes to define unit cell, then classify by fractional coordinates
# A-site (La-rich) at corners, B-site (Ti) at body center

# Get intensities at each position
positions_int = positions_refined.copy()
x_coords = positions_int[:, 0]  # column coordinates
y_coords = positions_int[:, 1]  # row coordinates

# Sample intensity at each position using bilinear interpolation
from scipy.ndimage import map_coordinates
intensities_at_positions = map_coordinates(image, [y_coords, x_coords], order=1)

if amplitude is not None:
    col_intensities = amplitude.copy()
    # Replace NaN with interpolated image intensity
    nan_mask = np.isnan(col_intensities)
    if np.any(nan_mask):
        col_intensities[nan_mask] = intensities_at_positions[nan_mask]
else:
    col_intensities = intensities_at_positions

print(f"Column intensity range: [{np.nanmin(col_intensities):.1f}, {np.nanmax(col_intensities):.1f}]")
print(f"Column intensity mean: {np.nanmean(col_intensities):.1f}, std: {np.nanstd(col_intensities):.1f}")

# Classify using Otsu thresholding on intensities
valid_mask = ~np.isnan(col_intensities)
valid_intensities = col_intensities[valid_mask]

# Otsu threshold
try:
    threshold_otsu = filters.threshold_otsu(valid_intensities)
    print(f"Otsu threshold: {threshold_otsu:.1f}")
except:
    threshold_otsu = np.median(valid_intensities)
    print(f"Median threshold (Otsu failed): {threshold_otsu:.1f}")

# Assign sublattices: A-site (brighter, La-rich) vs B-site (dimmer, Ti)
sublattice_labels = np.zeros(len(positions_refined), dtype=int)
sublattice_labels[col_intensities >= threshold_otsu] = 1  # A-site
sublattice_labels[col_intensities < threshold_otsu] = 2   # B-site
# Handle NaN
sublattice_labels[~valid_mask] = 0  # unclassified

A_site_mask = sublattice_labels == 1
B_site_mask = sublattice_labels == 2

count_A = np.sum(A_site_mask)
count_B = np.sum(B_site_mask)
count_unclassified = np.sum(sublattice_labels == 0)
print(f"A-site (La-rich, bright): {count_A}")
print(f"B-site (Ti, dim): {count_B}")
print(f"Unclassified: {count_unclassified}")
print(f"A/B ratio: {count_A/max(count_B,1):.2f}")

# If zone axes available, also validate by position within unit cell
if len(zone_axes) >= 2:
    v1 = np.array(zone_axes[0])
    v2 = np.array(zone_axes[1])
    # Compute fractional coordinates for each atom relative to nearest A-site
    # Build transformation matrix
    M = np.column_stack([v1, v2])  # 2x2
    try:
        M_inv = np.linalg.inv(M)
        # For each position, compute fractional coords modulo 1
        frac_coords = (M_inv @ positions_refined.T).T  # N x 2
        frac_coords_mod = np.mod(frac_coords, 1.0)
        # Atoms near (0,0) or (1,1) corners are A-site, near (0.5, 0.5) are B-site
        dist_to_corner = np.minimum(
            np.sqrt(frac_coords_mod[:, 0]**2 + frac_coords_mod[:, 1]**2),
            np.sqrt((frac_coords_mod[:, 0]-1)**2 + (frac_coords_mod[:, 1]-1)**2)
        )
        dist_to_corner = np.minimum(dist_to_corner,
            np.sqrt(frac_coords_mod[:, 0]**2 + (frac_coords_mod[:, 1]-1)**2))
        dist_to_corner = np.minimum(dist_to_corner,
            np.sqrt((frac_coords_mod[:, 0]-1)**2 + frac_coords_mod[:, 1]**2))
        dist_to_center = np.sqrt((frac_coords_mod[:, 0]-0.5)**2 + (frac_coords_mod[:, 1]-0.5)**2)
        
        positional_A = dist_to_corner < dist_to_center
        positional_B = ~positional_A
        
        # Combine position and intensity classification
        # Use position as primary, intensity as confirmation
        combined_labels = np.zeros(len(positions_refined), dtype=int)
        combined_labels[positional_A & A_site_mask] = 1  # High confidence A-site
        combined_labels[positional_B & B_site_mask] = 2  # High confidence B-site
        # Resolve conflicts using intensity
        combined_labels[(positional_A & B_site_mask)] = 1  # Trust position for corners
        combined_labels[(positional_B & A_site_mask)] = 2  # Trust position for body center
        combined_labels[~valid_mask] = 0
        
        # Override sublattice_labels with combined
        sublattice_labels = combined_labels
        A_site_mask = sublattice_labels == 1
        B_site_mask = sublattice_labels == 2
        count_A = np.sum(A_site_mask)
        count_B = np.sum(B_site_mask)
        print(f"After positional refinement - A-site: {count_A}, B-site: {count_B}")
    except np.linalg.LinAlgError:
        print("Could not invert zone axis matrix for positional classification")

# ======== STEP 9: Locally normalized intensity ========
print("\n=== Step 9: Local Intensity Normalization ===")

# Compute local background using large Gaussian filter
local_bg = ndimage.gaussian_filter(image.astype(np.float64), sigma=50)
img_local_norm = image.astype(np.float64) / np.maximum(local_bg, 1.0)

# Sample locally normalized intensity at each column position
intensities_local_norm = map_coordinates(img_local_norm, [y_coords, x_coords], order=1)

# Per-sublattice intensity statistics
A_intensities_norm = intensities_local_norm[A_site_mask]
B_intensities_norm = intensities_local_norm[B_site_mask]

print(f"A-site locally normalized intensity: mean={np.mean(A_intensities_norm):.4f}, std={np.std(A_intensities_norm):.4f}")
print(f"B-site locally normalized intensity: mean={np.mean(B_intensities_norm):.4f}, std={np.std(B_intensities_norm):.4f}")

# ======== STEP 10: Lattice parameters from FFT ========
# Already computed above in Step 1
print("\n=== Step 10: Lattice Parameters from FFT ===")
print(f"Pseudocubic: {lattice_params_fft.get('pseudocubic_period_nm', 'N/A')} nm")
print(f"Superstructure: {lattice_params_fft.get('superstructure_period_nm', 'N/A')} nm")

# ======== STEP 11: Nearest-neighbor distances ========
print("\n=== Step 11: Nearest-Neighbor Distances ===")
tree_all = cKDTree(positions_refined)
dists_all, _ = tree_all.query(positions_refined, k=2)  # k=2 because first is self
nn_dists_px = dists_all[:, 1]
nn_dists_nm = nn_dists_px * pixel_size_nm

print(f"All columns NN distance: mean={np.mean(nn_dists_nm):.3f} nm, std={np.std(nn_dists_nm):.3f} nm")

# Per-sublattice NN distances (within same sublattice)
nn_stats = {}
for label, name, mask in [(1, 'A_site', A_site_mask), (2, 'B_site', B_site_mask)]:
    if np.sum(mask) > 2:
        pos_sub = positions_refined[mask]
        tree_sub = cKDTree(pos_sub)
        d_sub, _ = tree_sub.query(pos_sub, k=2)
        nn_sub_nm = d_sub[:, 1] * pixel_size_nm
        nn_stats[name] = {
            'mean_nm': float(np.mean(nn_sub_nm)),
            'std_nm': float(np.std(nn_sub_nm)),
            'min_nm': float(np.min(nn_sub_nm)),
            'max_nm': float(np.max(nn_sub_nm))
        }
        print(f"{name} NN distance: mean={nn_stats[name]['mean_nm']:.3f} +/- {nn_stats[name]['std_nm']:.3f} nm")

# ======== STEP 12: Intensity maps per sublattice ========
print("\n=== Step 12: Intensity Maps ===")
# Create intensity map images for each sublattice (thickness corrected = locally normalized)
# We'll store the per-column data for mapping

# Compile results
A_site_positions = positions_refined[A_site_mask]
B_site_positions = positions_refined[B_site_mask]
A_site_norm_intensities = intensities_local_norm[A_site_mask]
B_site_norm_intensities = intensities_local_norm[B_site_mask]

# ======== VISUALIZATION ========
print("\n=== Creating Visualization ===")
fig, axes = plt.subplots(2, 3, figsize=(18, 12), dpi=100)

# 1. Original image
ax = axes[0, 0]
ax.imshow(img_norm, cmap='gray')
ax.set_title(f'Original STEM Image\n{image.shape[0]}x{image.shape[1]}, FOV={fov_nm} nm')
ax.axis('off')

# 2. Detected columns with sublattice assignment
ax = axes[0, 1]
ax.imshow(img_norm, cmap='gray')
if count_A > 0:
    ax.scatter(A_site_positions[:, 0], A_site_positions[:, 1],
              c='red', s=3, alpha=0.6, label=f'A-site (La) N={count_A}')
if count_B > 0:
    ax.scatter(B_site_positions[:, 0], B_site_positions[:, 1],
              c='cyan', s=3, alpha=0.6, label=f'B-site (Ti) N={count_B}')
ax.legend(fontsize=8, loc='upper right')
ax.set_title(f'Sublattice Assignment\nTotal: {len(positions_refined)} columns')
ax.axis('off')

# 3. FFT power spectrum
ax = axes[0, 2]
vmin_fft = np.percentile(log_power, 50)
vmax_fft = np.percentile(log_power, 99.9)
ax.imshow(log_power, cmap='inferno', vmin=vmin_fft, vmax=vmax_fft,
          extent=[-center, center, -center, center])
# Mark pseudocubic peaks
for p in pseudocubic_peaks[:4]:
    ax.plot(p['col'] - center, p['row'] - center, 'go', markersize=6, fillstyle='none', linewidth=1.5)
# Mark superstructure peaks
for p in superstructure_peaks[:4]:
    ax.plot(p['col'] - center, p['row'] - center, 'rs', markersize=8, fillstyle='none', linewidth=1.5)
ax.set_title('FFT Power Spectrum\n(green=pseudocubic, red=superstructure)')
ax.set_xlabel('Frequency (pixels)')
ax.set_ylabel('Frequency (pixels)')

# 4. Locally normalized intensity map for A-site
ax = axes[1, 0]
if count_A > 2:
    scatter = ax.scatter(A_site_positions[:, 0], A_site_positions[:, 1],
                         c=A_site_norm_intensities, cmap='hot', s=5, alpha=0.8)
    plt.colorbar(scatter, ax=ax, shrink=0.7, label='Normalized Intensity')
    ax.set_xlim(0, image_size_px)
    ax.set_ylim(image_size_px, 0)
ax.set_title(f'A-site (La) Intensity Map\n(thickness corrected)')
ax.set_aspect('equal')
ax.set_facecolor('black')

# 5. Locally normalized intensity map for B-site
ax = axes[1, 1]
if count_B > 2:
    scatter = ax.scatter(B_site_positions[:, 0], B_site_positions[:, 1],
                         c=B_site_norm_intensities, cmap='hot', s=5, alpha=0.8)
    plt.colorbar(scatter, ax=ax, shrink=0.7, label='Normalized Intensity')
    ax.set_xlim(0, image_size_px)
    ax.set_ylim(image_size_px, 0)
ax.set_title(f'B-site (Ti) Intensity Map\n(thickness corrected)')
ax.set_aspect('equal')
ax.set_facecolor('black')

# 6. Intensity histograms
ax = axes[1, 2]
if count_A > 0:
    ax.hist(A_site_norm_intensities, bins=40, alpha=0.6, color='red',
            label=f'A-site (mean={np.mean(A_site_norm_intensities):.3f})', density=True)
if count_B > 0:
    ax.hist(B_site_norm_intensities, bins=40, alpha=0.6, color='cyan',
            label=f'B-site (mean={np.mean(B_site_norm_intensities):.3f})', density=True)
ax.set_xlabel('Locally Normalized Intensity')
ax.set_ylabel('Density')
ax.set_title('Column Intensity Distribution\n(thickness corrected)')
ax.legend(fontsize=8)

plt.tight_layout()
plt.savefig('analysis_visualization.png', dpi=100, bbox_inches='tight')
plt.close()
print("Saved analysis_visualization.png")

# ======== SAVE ARRAYS ========
print("\n=== Saving Arrays ===")

# Primary: all atom positions with sublattice labels
# Format: [x, y, sublattice_label, locally_normalized_intensity]
output_data = np.column_stack([
    positions_refined,
    sublattice_labels,
    intensities_local_norm
]).astype(np.float32)
np.save('atomic_column_positions.npy', output_data)
print(f"Saved atomic_column_positions.npy: shape={output_data.shape}")

# FFT power spectrum
np.save('fft_power_spectrum.npy', log_power.astype(np.float32))
print(f"Saved fft_power_spectrum.npy: shape={log_power.shape}")

# Heatmap from DCNN if available
if heatmap is not None:
    np.save('dcnn_heatmap.npy', heatmap.astype(np.float32))
    print(f"Saved dcnn_heatmap.npy: shape={heatmap.shape}")

# Residual image after atom subtraction
if residual is not None:
    np.save('residual_image.npy', residual.astype(np.float32))
    print(f"Saved residual_image.npy: shape={residual.shape}")

# ======== COMPILE RESULTS ========
results = {
    "analysis_type": "LLTO STEM atomic column analysis: DCNN-based atom detection, sublattice separation, FFT lattice analysis, locally-normalized intensity mapping",
    "extracted_features": {
        "total_column_count": int(len(positions_refined)),
        "A_site_count": int(count_A),
        "B_site_count": int(count_B),
        "A_B_ratio": float(count_A / max(count_B, 1)),
        "lattice_parameters_from_FFT_pseudocubic_and_superstructure": lattice_params_fft,
        "nearest_neighbor_distances": {
            "all_columns": {
                "mean_nm": float(np.mean(nn_dists_nm)),
                "std_nm": float(np.std(nn_dists_nm)),
                "min_nm": float(np.min(nn_dists_nm)),
                "max_nm": float(np.max(nn_dists_nm))
            },
            **nn_stats
        },
        "sublattice_assignment_A_site_B_site_by_position_and_intensity": {
            "method": "Otsu threshold on amplitude + positional validation via fractional unit cell coordinates",
            "otsu_threshold": float(threshold_otsu),
            "A_site_description": "La-rich, brighter, at unit cell corners",
            "B_site_description": "Ti, dimmer, at body center"
        },
        "locally_normalized_column_intensity_distribution": {
            "A_site_mean": float(np.mean(A_site_norm_intensities)) if count_A > 0 else None,
            "A_site_std": float(np.std(A_site_norm_intensities)) if count_A > 0 else None,
            "B_site_mean": float(np.mean(B_site_norm_intensities)) if count_B > 0 else None,
            "B_site_std": float(np.std(B_site_norm_intensities)) if count_B > 0 else None,
            "normalization_method": "Division by Gaussian-smoothed local background (sigma=50px)"
        },
        "FFT_power_spectrum_with_fundamental_and_superlattice_peaks": {
            "num_pseudocubic_peaks": len(pseudocubic_peaks),
            "num_superstructure_peaks": len(superstructure_peaks),
            "top_pseudocubic_peaks": pseudocubic_peaks[:4],
            "top_superstructure_peaks": superstructure_peaks[:4]
        },
        "superstructure_periodicity_and_direction": {
            "periodicity_nm": lattice_params_fft.get('superstructure_period_nm', None),
            "direction_deg": lattice_params_fft.get('superstructure_direction', None),
            "relation_to_pseudocubic": f"~{lattice_params_fft.get('superstructure_period_nm', 0) / max(lattice_params_fft.get('pseudocubic_period_nm', 1), 0.001):.1f}x pseudocubic" if lattice_params_fft.get('superstructure_period_nm') else "not detected"
        },
        "zone_axes": [
            {"dx_px": float(zv[0]), "dy_px": float(zv[1]),
             "length_nm": float(np.sqrt(zv[0]**2 + zv[1]**2) * pixel_size_nm),
             "angle_deg": float(np.degrees(np.arctan2(zv[1], zv[0])))}
            for zv in zone_axes[:4]
        ] if zone_axes else [],
        "pixel_size_nm": float(pixel_size_nm),
        "fov_nm": float(fov_nm)
    },
    "quality_metrics": {
        "detection_method": "DCNN" if use_dcnn else "classical_bandpass",
        "detection_count_vs_expected": float(len(positions_refined) / expected_count),
        "mean_fit_sigma_x_px": float(np.nanmean(sigma_x)) if sigma_x is not None else None,
        "mean_fit_sigma_y_px": float(np.nanmean(sigma_y)) if sigma_y is not None else None,
        "nn_distance_coefficient_of_variation": float(np.std(nn_dists_nm) / np.mean(nn_dists_nm)),
        "secondary_sublattice_detected_in_residual": result2 is not None and len(result2.get('positions', [])) > 0,
        "predicted_secondary_count": int(len(predicted_secondary)) if predicted_secondary is not None else 0
    },
    "summary": f"Detected {len(positions_refined)} atomic columns in LLTO STEM image ({fov_nm} nm FOV). Separated into {count_A} A-site (La-rich) and {count_B} B-site (Ti) columns using Otsu intensity thresholding with positional validation. FFT analysis reveals pseudocubic periodicity of {lattice_params_fft.get('pseudocubic_period_nm', 'N/A'):.3f} nm" + (f" and superstructure periodicity of {lattice_params_fft.get('superstructure_period_nm', 0):.3f} nm" if lattice_params_fft.get('superstructure_period_nm') else "") + f". Mean NN distance: {np.mean(nn_dists_nm):.3f} nm. Locally-normalized intensities show A-site mean={np.mean(A_site_norm_intensities):.3f} vs B-site mean={np.mean(B_site_norm_intensities):.3f}, consistent with La/vacancy ordering.",
    "saved_arrays": {
        "atomic_column_positions.npy": {
            "description": f"Atomic column data: columns [x_px, y_px, sublattice_label(1=A-site/La, 2=B-site/Ti, 0=unclassified), locally_normalized_intensity]. {len(positions_refined)} columns total.",
            "shape": list(output_data.shape),
            "dtype": "float32"
        },
        "fft_power_spectrum.npy": {
            "description": "Log(1+power) of 2D FFT, shifted so DC is at center. Use for lattice periodicity analysis.",
            "shape": list(log_power.shape),
            "dtype": "float32"
        }
    }
}

if heatmap is not None:
    results["saved_arrays"]["dcnn_heatmap.npy"] = {
        "description": "DCNN detection probability heatmap (0-1), pre-threshold",
        "shape": list(heatmap.shape),
        "dtype": "float32"
    }

if residual is not None:
    results["saved_arrays"]["residual_image.npy"] = {
        "description": "Image after subtracting fitted Gaussians at primary sublattice positions. Use to verify secondary sublattice.",
        "shape": list(residual.shape),
        "dtype": "float32"
    }

print(f"IMAGE_ANALYSIS_RESULTS_JSON:{json.dumps(results)}")
