"""Tests for username, friend system, and platform airdrop."""
from __future__ import annotations

import asyncio
import importlib
import json
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from anyfs_sdk import AnyFSService
from anyfs_local_state import workspace_agent


def write_workspace_file(workspace: Path, rel_path: str, content: str) -> None:
    path = workspace / rel_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


@contextmanager
def build_api_client(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("ANYFS_API_DATA_DIR", str(tmp_path / "api-data"))
    monkeypatch.setenv("ANYFS_PUBLIC_BASE_URL", "http://testserver")
    import anyfs_api.main as api_main

    api_main = importlib.reload(api_main)
    with TestClient(api_main.app) as client:
        yield client


def _make_agent(tmp_path: Path, api_client, name: str, agent_type: str = "claude-code") -> tuple[AnyFSService, dict[str, Any]]:
    """Create a registered agent with a unique global root and workspace."""
    global_root = tmp_path / f"global-{name}"
    workspace = tmp_path / f"workspace-{name}"
    workspace.mkdir(parents=True, exist_ok=True)
    write_workspace_file(workspace, "CLAUDE.md", f"agent {name}")

    svc = AnyFSService(global_root=global_root, api_client=api_client)
    svc.init()
    local_agent = svc.register_agent(agent_type, str(workspace), username=name)
    svc.agent_create_remote(str(workspace), agent_type)
    return svc, {"agent": local_agent, "workspace": str(workspace), "agent_type": agent_type}


# ── Username Tests ────────────────────────────────────────


class TestUsername:
    def test_register_with_username(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc, ctx = _make_agent(tmp_path, api_client, "alice-claude")
            assert ctx["agent"]["username"] == "alice-claude"

    def test_username_uniqueness_conflict(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            _make_agent(tmp_path, api_client, "unique-name", agent_type="claude-code")
            # Second agent with same username should fail at remote registration
            global_root2 = tmp_path / "global-dup"
            workspace2 = tmp_path / "workspace-dup"
            workspace2.mkdir()
            svc2 = AnyFSService(global_root=global_root2, api_client=api_client)
            svc2.init()
            svc2.register_agent("codex-cli", str(workspace2), username="unique-name")
            with pytest.raises(Exception):
                svc2.agent_create_remote(str(workspace2), "codex-cli")

    def test_username_lookup_by_username(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            _make_agent(tmp_path, api_client, "lookup-test")
            # Direct API call to verify lookup
            resp = api_client.get("/agents/by-username/lookup-test")
            assert resp.status_code == 200
            assert resp.json()["username"] == "lookup-test"

    def test_username_lookup_not_found(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            resp = api_client.get("/agents/by-username/nonexistent")
            assert resp.status_code == 404

    def test_username_format_validation(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            # Too short
            resp = api_client.post("/agent-auth/register", json={
                "agent_id": "did:key:z6Mk_test_short",
                "agent_type": "claude-code",
                "username": "ab",
            })
            assert resp.status_code == 422

    def test_username_reserved(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            resp = api_client.post("/agent-auth/register", json={
                "agent_id": "did:key:z6Mk_test_reserved",
                "agent_type": "claude-code",
                "username": "admin",
            })
            assert resp.status_code == 422

    def test_change_username(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc, ctx = _make_agent(tmp_path, api_client, "old-name")
            result = svc.agent_set_username(ctx["workspace"], "new-name", ctx["agent_type"])
            assert result["username"] == "new-name"
            local = workspace_agent(ctx["workspace"], ctx["agent_type"], global_root=svc.global_root)
            assert local["username"] == "new-name"
            # Old name should be gone
            resp = api_client.get("/agents/by-username/old-name")
            assert resp.status_code == 404
            # New name should resolve
            resp = api_client.get("/agents/by-username/new-name")
            assert resp.status_code == 200

    def test_legacy_display_name_rows_are_migrated_on_startup(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc, ctx = _make_agent(tmp_path, api_client, "legacy-name")
            import anyfs_api.main as api_main

            agent_id = ctx["agent"]["agent_id"]
            record = asyncio.run(api_main.store.get("agents", agent_id))
            assert record is not None
            record["display_name"] = record.pop("username")
            asyncio.run(api_main.store.put("agents", agent_id, record))

        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc.api_client = api_client
            resp = api_client.get("/agents/by-username/legacy-name")
            assert resp.status_code == 200

            result = svc.agent_set_username(
                ctx["workspace"], "legacy-renamed", ctx["agent_type"]
            )
            assert result["username"] == "legacy-renamed"

            import anyfs_api.main as api_main

            migrated = asyncio.run(api_main.store.get("agents", agent_id))
            assert migrated is not None
            assert migrated["username"] == "legacy-renamed"
            assert "display_name" not in migrated


# ── Friend Tests ──────────────────────────────────────────


class TestFriends:
    def test_friend_request_and_accept(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "agent-alpha")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "agent-beta", agent_type="codex-cli")

            # A sends request to B
            req = svc_a.friend_add(ctx_a["workspace"], "agent-beta", ctx_a["agent_type"])
            assert req["request_id"].startswith("freq_")
            assert req["status"] == "pending"

            # B sees the request
            pending = svc_b.friend_requests(ctx_b["workspace"], ctx_b["agent_type"])
            assert len(pending) == 1
            assert pending[0]["from_username"] == "agent-alpha"

            # B accepts
            accepted = svc_b.friend_accept(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])
            assert accepted["status"] == "accepted"

            # Both see each other as friends
            friends_a = svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])
            friends_b = svc_b.friend_list(ctx_b["workspace"], ctx_b["agent_type"])
            assert len(friends_a) == 1
            assert friends_a[0]["username"] == "agent-beta"
            assert len(friends_b) == 1
            assert friends_b[0]["username"] == "agent-alpha"

    def test_friend_request_reject(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "reject-sender")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "reject-receiver", agent_type="codex-cli")

            req = svc_a.friend_add(ctx_a["workspace"], "reject-receiver", ctx_a["agent_type"])
            svc_b.friend_reject(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])

            # Neither should be friends
            assert len(svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])) == 0
            assert len(svc_b.friend_list(ctx_b["workspace"], ctx_b["agent_type"])) == 0

    def test_cannot_friend_yourself(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc, ctx = _make_agent(tmp_path, api_client, "self-friend")
            with pytest.raises(Exception):
                svc.friend_add(ctx["workspace"], "self-friend", ctx["agent_type"])

    def test_duplicate_request_rejected(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "dup-sender")
            _svc_b, _ctx_b = _make_agent(tmp_path, api_client, "dup-receiver", agent_type="codex-cli")

            svc_a.friend_add(ctx_a["workspace"], "dup-receiver", ctx_a["agent_type"])
            with pytest.raises(Exception):
                svc_a.friend_add(ctx_a["workspace"], "dup-receiver", ctx_a["agent_type"])

    def test_already_friends_rejected(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "already-a")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "already-b", agent_type="codex-cli")

            req = svc_a.friend_add(ctx_a["workspace"], "already-b", ctx_a["agent_type"])
            svc_b.friend_accept(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])

            # Trying to add again should fail
            with pytest.raises(Exception):
                svc_a.friend_add(ctx_a["workspace"], "already-b", ctx_a["agent_type"])

    def test_friend_remove(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "remove-a")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "remove-b", agent_type="codex-cli")

            req = svc_a.friend_add(ctx_a["workspace"], "remove-b", ctx_a["agent_type"])
            svc_b.friend_accept(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])
            assert len(svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])) == 1

            svc_a.friend_remove(ctx_a["workspace"], "remove-b", ctx_a["agent_type"])
            assert len(svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])) == 0
            assert len(svc_b.friend_list(ctx_b["workspace"], ctx_b["agent_type"])) == 0

            req_again = svc_a.friend_add(ctx_a["workspace"], "remove-b", ctx_a["agent_type"])
            assert req_again["status"] == "pending"
            assert req_again["request_id"] != req["request_id"]

    def test_friend_add_by_did(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "did-sender")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "did-receiver", agent_type="codex-cli")

            # Add by DID instead of username
            did_b = ctx_b["agent"]["agent_id"]
            req = svc_a.friend_add(ctx_a["workspace"], did_b, ctx_a["agent_type"])
            assert req["to_agent_id"] == did_b
            assert req["to_username"] == "did-receiver"

            svc_b.friend_accept(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])
            friends = svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])
            assert len(friends) == 1

    def test_reverse_pending_auto_accepts_existing_request(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "reverse-a")
            svc_b, ctx_b = _make_agent(tmp_path, api_client, "reverse-b", agent_type="codex-cli")

            req = svc_a.friend_add(ctx_a["workspace"], "reverse-b", ctx_a["agent_type"])
            accepted = svc_b.friend_add(ctx_b["workspace"], "reverse-a", ctx_b["agent_type"])

            assert accepted["request_id"] == req["request_id"]
            assert accepted["status"] == "accepted"
            assert svc_a.friend_requests(ctx_a["workspace"], ctx_a["agent_type"]) == []
            assert svc_b.friend_requests(ctx_b["workspace"], ctx_b["agent_type"]) == []
            assert len(svc_a.friend_list(ctx_a["workspace"], ctx_a["agent_type"])) == 1
            assert len(svc_b.friend_list(ctx_b["workspace"], ctx_b["agent_type"])) == 1


# ── Airdrop Tests ─────────────────────────────────────────


class TestAirdrop:
    def _make_friends(self, tmp_path, api_client):
        """Helper: create two agents and make them friends."""
        svc_a, ctx_a = _make_agent(tmp_path, api_client, "drop-sender")
        svc_b, ctx_b = _make_agent(tmp_path, api_client, "drop-receiver", agent_type="codex-cli")
        req = svc_a.friend_add(ctx_a["workspace"], "drop-receiver", ctx_a["agent_type"])
        svc_b.friend_accept(ctx_b["workspace"], req["request_id"], ctx_b["agent_type"])
        return svc_a, ctx_a, svc_b, ctx_b

    def test_airdrop_send_and_receive(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a, svc_b, ctx_b = self._make_friends(tmp_path, api_client)

            # Send airdrop
            airdrop = svc_a.airdrop_send(
                ctx_a["workspace"], "drop-receiver",
                share_urls=["https://storage.anyfs.ai/raw/test123"],
                password="secret123",
                message="check this",
                agent_type=ctx_a["agent_type"],
            )
            assert airdrop["airdrop_id"].startswith("adrop_")
            assert airdrop["status"] == "pending"
            assert airdrop["from_username"] == "drop-sender"
            assert airdrop["to_username"] == "drop-receiver"

            # B checks inbox
            inbox = svc_b.airdrop_inbox(ctx_b["workspace"], ctx_b["agent_type"])
            assert len(inbox) == 1
            assert inbox[0]["message"] == "check this"
            assert inbox[0]["password"] == "secret123"
            assert inbox[0]["share_urls"] == ["https://storage.anyfs.ai/raw/test123"]

            # B marks as opened
            opened = svc_b.airdrop_mark_opened(ctx_b["workspace"], inbox[0]["airdrop_id"], ctx_b["agent_type"])
            assert opened["status"] == "opened"

            # Inbox should now be empty
            inbox_after = svc_b.airdrop_inbox(ctx_b["workspace"], ctx_b["agent_type"])
            assert len(inbox_after) == 0

    def test_airdrop_non_friend_blocked(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a = _make_agent(tmp_path, api_client, "nonfriend-sender")
            _make_agent(tmp_path, api_client, "nonfriend-target", agent_type="codex-cli")

            # Not friends — should fail
            with pytest.raises(Exception):
                svc_a.airdrop_send(
                    ctx_a["workspace"], "nonfriend-target",
                    share_urls=["https://example.com"],
                    password="pw",
                    message="test",
                    agent_type=ctx_a["agent_type"],
                )

    def test_airdrop_inbox_empty(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc, ctx = _make_agent(tmp_path, api_client, "empty-inbox")
            inbox = svc.airdrop_inbox(ctx["workspace"], ctx["agent_type"])
            assert inbox == []

    def test_airdrop_only_recipient_can_open(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a, svc_b, ctx_b = self._make_friends(tmp_path, api_client)

            airdrop = svc_a.airdrop_send(
                ctx_a["workspace"], "drop-receiver",
                share_urls=["https://example.com"],
                password="pw",
                message="test",
                agent_type=ctx_a["agent_type"],
            )

            # Sender trying to mark as opened should fail
            with pytest.raises(Exception):
                svc_a.airdrop_mark_opened(ctx_a["workspace"], airdrop["airdrop_id"], ctx_a["agent_type"])

    def test_airdrop_sends_email_to_bound_recipient_owner(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a, svc_b, ctx_b = self._make_friends(tmp_path, api_client)
            api_client.post(
                "/auth/register",
                json={"email": "receiver@example.com", "password": "supersecret123"},
            )
            svc_b.agent_bind(
                ctx_b["workspace"],
                "receiver@example.com",
                "supersecret123",
                ctx_b["agent_type"],
            )

            import anyfs_api.main as api_main

            captured: list[dict[str, str]] = []

            async def fake_send_airdrop_owner_notification(**kwargs):
                captured.append(kwargs)
                return True

            monkeypatch.setattr(
                api_main,
                "send_airdrop_owner_notification",
                fake_send_airdrop_owner_notification,
            )

            svc_a.airdrop_send(
                ctx_a["workspace"], "drop-receiver",
                share_urls=["https://storage.anyfs.ai/raw/test123"],
                password="secret123",
                message="check this",
                agent_type=ctx_a["agent_type"],
            )

            assert len(captured) == 1
            assert captured[0]["recipient_email"] == "receiver@example.com"
            assert captured[0]["from_username"] == "drop-sender"
            assert captured[0]["to_username"] == "drop-receiver"
            assert captured[0]["message"] == "check this"

    def test_airdrop_sends_email_when_sender_and_recipient_share_owner(self, tmp_path, monkeypatch):
        with build_api_client(tmp_path, monkeypatch) as api_client:
            svc_a, ctx_a, svc_b, ctx_b = self._make_friends(tmp_path, api_client)
            api_client.post(
                "/auth/register",
                json={"email": "shared-owner@example.com", "password": "supersecret123"},
            )
            svc_a.agent_bind(
                ctx_a["workspace"],
                "shared-owner@example.com",
                "supersecret123",
                ctx_a["agent_type"],
            )
            svc_b.agent_bind(
                ctx_b["workspace"],
                "shared-owner@example.com",
                "supersecret123",
                ctx_b["agent_type"],
            )

            import anyfs_api.main as api_main

            captured: list[dict[str, str]] = []

            async def fake_send_airdrop_owner_notification(**kwargs):
                captured.append(kwargs)
                return True

            monkeypatch.setattr(
                api_main,
                "send_airdrop_owner_notification",
                fake_send_airdrop_owner_notification,
            )

            svc_a.airdrop_send(
                ctx_a["workspace"], "drop-receiver",
                share_urls=["https://storage.anyfs.ai/raw/test123"],
                password="secret123",
                message="check this",
                agent_type=ctx_a["agent_type"],
            )

            assert len(captured) == 1
            assert captured[0]["recipient_email"] == "shared-owner@example.com"
            assert captured[0]["from_username"] == "drop-sender"
            assert captured[0]["to_username"] == "drop-receiver"
            assert captured[0]["message"] == "check this"
