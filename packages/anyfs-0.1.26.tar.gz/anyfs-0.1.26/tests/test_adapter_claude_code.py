"""Unit tests for anyfs_adapter_claude_code package."""
from __future__ import annotations

import os
import re
from pathlib import Path

import pytest

from anyfs_adapter_claude_code import ClaudeCodeAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(ws: Path, rel: str, content: str) -> None:
    path = ws / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _encode_claude_project_dir(workspace: Path) -> str:
    return re.sub(r"[^A-Za-z0-9-]", "-", str(workspace.resolve()))


# ---------------------------------------------------------------------------
# ClaudeCodeAdapter.discover
# ---------------------------------------------------------------------------

class TestDiscover:
    def test_finds_claude_md(self, tmp_path):
        _write_file(tmp_path, "CLAUDE.md", "system guidance")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any(f.name == "CLAUDE.md" for f in files)

    def test_finds_prompt_files(self, tmp_path):
        _write_file(tmp_path, "prompts/system_prompt.md", "prompt content")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("prompt" in str(f) for f in files)

    def test_finds_instruction_files(self, tmp_path):
        _write_file(tmp_path, "instructions/setup.md", "instructions")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("instruction" in str(f) for f in files)

    def test_finds_md_files(self, tmp_path):
        _write_file(tmp_path, "docs/guide.md", "guide")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("guide.md" in str(f) for f in files)

    def test_finds_json_files(self, tmp_path):
        _write_file(tmp_path, "config.json", '{}')
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("config.json" in str(f) for f in files)

    def test_finds_txt_files(self, tmp_path):
        _write_file(tmp_path, "notes.txt", "notes")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("notes.txt" in str(f) for f in files)

    def test_empty_workspace(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path / "home"))
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert files == []

    def test_only_files(self, tmp_path):
        _write_file(tmp_path, "artifact_dir/file.txt", "x")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        for f in files:
            assert f.is_file()

    def test_max_100_files(self, tmp_path):
        for i in range(120):
            _write_file(tmp_path, f"data/file_{i:03d}.json", "{}")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert len(files) <= 100

    def test_finds_process_files(self, tmp_path):
        _write_file(tmp_path, "process/steps.txt", "step 1")
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("process" in str(f) for f in files)

    def test_finds_log_files(self, tmp_path):
        _write_file(tmp_path, "logs/app.log", "log entry")  # log pattern
        adapter = ClaudeCodeAdapter()
        files = adapter.discover(str(tmp_path))
        assert any("log" in str(f) for f in files)


# ---------------------------------------------------------------------------
# ClaudeCodeAdapter.extract
# ---------------------------------------------------------------------------

class TestExtract:
    def test_extracts_records(self, tmp_path):
        _write_file(tmp_path, "CLAUDE.md", "system guidance")
        _write_file(tmp_path, "memory/session.md", "session data")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        assert len(records) >= 2
        for rec in records:
            assert "path" in rec
            assert "relative_path" in rec
            assert "namespace" in rec
            assert "content" in rec

    def test_claude_md_namespace_is_skills(self, tmp_path):
        _write_file(tmp_path, "CLAUDE.md", "system guidance")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        claude_recs = [r for r in records if r["relative_path"] == "CLAUDE.md"]
        assert len(claude_recs) >= 1
        assert claude_recs[0]["namespace"] == "skills"

    def test_nested_claude_md_skills(self, tmp_path):
        _write_file(tmp_path, "sub/CLAUDE.md", "nested guidance")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        claude_recs = [r for r in records if "CLAUDE.md" in r["relative_path"]]
        assert all(r["namespace"] == "skills" for r in claude_recs)

    def test_memory_namespace(self, tmp_path):
        _write_file(tmp_path, "memory/session.md", "session")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        mem_recs = [r for r in records if "memory" in r["relative_path"]]
        assert any(r["namespace"] == "memory" for r in mem_recs)

    def test_relative_paths(self, tmp_path):
        _write_file(tmp_path, "data/file.json", '{}')
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        for rec in records:
            assert not rec["relative_path"].startswith("/")

    def test_reads_content(self, tmp_path):
        _write_file(tmp_path, "CLAUDE.md", "test content here")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        claude_rec = [r for r in records if r["relative_path"] == "CLAUDE.md"][0]
        assert claude_rec["content"] == "test content here"

    def test_login_named_file_is_not_misclassified_as_process(self, tmp_path):
        _write_file(tmp_path, "apps/web/components/login-form.tsx", "export const x = 1;")
        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(tmp_path))
        rec = next(r for r in records if r["relative_path"] == "apps/web/components/login-form.tsx")
        assert rec["namespace"] != "process"

    def test_excludes_global_claude_settings_from_capture(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        home = tmp_path / "home"
        _write_file(home, ".claude/settings.json", '{"theme":"dark"}')
        _write_file(home, ".claude/commands/review.md", "# review")
        monkeypatch.setenv("HOME", str(home))

        adapter = ClaudeCodeAdapter()
        records = adapter.extract(str(workspace))
        assert all(not item["path"].endswith(".claude/settings.json") for item in records)
        assert any(item["path"].endswith(".claude/commands/review.md") for item in records)

    def test_defaults_to_current_claude_session_only(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        home = tmp_path / "home"
        project_dir = home / ".claude" / "projects" / _encode_claude_project_dir(workspace)
        project_dir.mkdir(parents=True, exist_ok=True)
        older = project_dir / "older.jsonl"
        newer = project_dir / "newer.jsonl"
        older.write_text('{"type":"user","message":{"role":"user","content":"older"}}\n', encoding="utf-8")
        newer.write_text('{"type":"user","message":{"role":"user","content":"newer"}}\n', encoding="utf-8")
        os.utime(older, (1, 1))
        os.utime(newer, (2, 2))
        monkeypatch.setenv("HOME", str(home))

        adapter = ClaudeCodeAdapter()
        files = [path for path in adapter.discover(str(workspace)) if path.suffix == ".jsonl"]
        assert files == [newer]

    def test_picks_actively_written_jsonl_over_higher_embedded_timestamp(self, tmp_path, monkeypatch):
        """Regression: when --process-scope=current and no hint is supplied,
        the freshly-written-to transcript should win even if a stale session
        on disk has a higher embedded last-message timestamp.

        Reproduces the airdrop race we hit in practice: the current Claude
        Code session hadn't flushed its latest line yet, so its highest
        embedded timestamp was older than another session that had finished
        more recently from a wall-clock standpoint.
        """
        import time

        workspace = tmp_path / "workspace"
        workspace.mkdir()
        home = tmp_path / "home"
        project_dir = home / ".claude" / "projects" / _encode_claude_project_dir(workspace)
        project_dir.mkdir(parents=True, exist_ok=True)

        stale_with_newer_embedded_ts = project_dir / "stale.jsonl"
        active_with_older_embedded_ts = project_dir / "active.jsonl"
        stale_with_newer_embedded_ts.write_text(
            '{"type":"user","message":{"role":"user","content":"stale","timestamp":"2099-01-01T00:00:00Z"}}\n',
            encoding="utf-8",
        )
        active_with_older_embedded_ts.write_text(
            '{"type":"user","message":{"role":"user","content":"active","timestamp":"2000-01-01T00:00:00Z"}}\n',
            encoding="utf-8",
        )
        # Stale: ancient mtime. Active: fresh mtime (now).
        os.utime(stale_with_newer_embedded_ts, (1, 1))
        now = time.time()
        os.utime(active_with_older_embedded_ts, (now, now))
        monkeypatch.setenv("HOME", str(home))

        adapter = ClaudeCodeAdapter()
        files = [path for path in adapter.discover(str(workspace)) if path.suffix == ".jsonl"]
        assert files == [active_with_older_embedded_ts]

    def test_can_capture_all_claude_sessions(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        home = tmp_path / "home"
        project_dir = home / ".claude" / "projects" / _encode_claude_project_dir(workspace)
        project_dir.mkdir(parents=True, exist_ok=True)
        one = project_dir / "one.jsonl"
        two = project_dir / "two.jsonl"
        one.write_text('{"type":"user","message":{"role":"user","content":"one"}}\n', encoding="utf-8")
        two.write_text('{"type":"user","message":{"role":"user","content":"two"}}\n', encoding="utf-8")
        os.utime(one, (1, 1))
        os.utime(two, (2, 2))
        monkeypatch.setenv("HOME", str(home))

        adapter = ClaudeCodeAdapter(process_scope="all")
        files = [path for path in adapter.discover(str(workspace)) if path.suffix == ".jsonl"]
        assert len(files) == 2

    def test_discovers_sessions_for_workspace_paths_with_underscores(self, tmp_path, monkeypatch):
        workspace = tmp_path / ".anyfs" / "imports" / "adrop_demo_id" / "workspace"
        workspace.mkdir(parents=True)
        home = tmp_path / "home"
        project_dir = home / ".claude" / "projects" / _encode_claude_project_dir(workspace)
        project_dir.mkdir(parents=True, exist_ok=True)
        session = project_dir / "session.jsonl"
        session.write_text('{"type":"user","message":{"role":"user","content":"demo"}}\n', encoding="utf-8")
        monkeypatch.setenv("HOME", str(home))

        adapter = ClaudeCodeAdapter()
        files = [path for path in adapter.discover(str(workspace)) if path.suffix == ".jsonl"]
        assert files == [session]

# ---------------------------------------------------------------------------
# ClaudeCodeAdapter.normalize
# ---------------------------------------------------------------------------

class TestNormalize:
    def test_groups_by_namespace(self):
        adapter = ClaudeCodeAdapter()
        raw = [
            {"namespace": "skills", "content": "a"},
            {"namespace": "memory", "content": "b"},
            {"namespace": "skills", "content": "c"},
        ]
        result = adapter.normalize(raw)
        assert len(result["skills"]) == 2
        assert len(result["memory"]) == 1

    def test_empty_input(self):
        adapter = ClaudeCodeAdapter()
        assert adapter.normalize([]) == {}


# ---------------------------------------------------------------------------
# ClaudeCodeAdapter.bundle
# ---------------------------------------------------------------------------

class TestBundle:
    def test_creates_capture_result(self):
        adapter = ClaudeCodeAdapter()
        normalized = {"skills": [{"content": "data"}], "memory": [{"content": "notes"}]}
        result = adapter.bundle(normalized)
        assert isinstance(result, CaptureResult)
        assert result.ok is True
        assert result.agent_id == "pending"
        assert result.agent_type == "claude-code"
        assert set(result.captured_namespaces) == {"skills", "memory"}
        assert result.warnings == []

    def test_empty_warns(self):
        adapter = ClaudeCodeAdapter()
        result = adapter.bundle({})
        assert result.warnings == ["no Claude Code files were discovered"]
        assert result.captured_namespaces == []

    def test_agent_type(self):
        adapter = ClaudeCodeAdapter()
        assert adapter.agent_type == AgentType.CLAUDE_CODE


# ---------------------------------------------------------------------------
# Integration: full pipeline
# ---------------------------------------------------------------------------

class TestFullPipeline:
    def test_pipeline(self, tmp_path):
        _write_file(tmp_path, "CLAUDE.md", "system guidance")
        _write_file(tmp_path, "memory/session.md", "memory block")
        _write_file(tmp_path, "process/log.txt", "process block")
        _write_file(tmp_path, "artifacts/output.md", "artifact")

        adapter = ClaudeCodeAdapter()
        raw = adapter.extract(str(tmp_path))
        normalized = adapter.normalize(raw)
        result = adapter.bundle(normalized)

        assert result.ok is True
        assert "skills" in result.captured_namespaces
        assert "memory" in result.captured_namespaces
        assert len(result.warnings) == 0
