from __future__ import annotations

import json
from types import SimpleNamespace

from typer.testing import CliRunner

import anyfs_cli.main as cli_main
import anyfs_local_state


runner = CliRunner()


def test_open_requires_registered_agent_type_before_decrypt(monkeypatch, tmp_path) -> None:
    class FakeService:
        def init(self) -> None:
            return None

        def agent_status(self, workspace: str, agent_type: str):
            raise RuntimeError("not registered")

        def open_shared(self, share_path: str, password: str, output: str | None = None, **kwargs):
            raise AssertionError("open_shared should not be called before registration")

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "https://storage.anyfs.ai/raw/demo",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 1
    assert "codex-cli is not registered with AnyFS on this machine yet." in result.stderr
    assert "anyfs register --type codex-cli <your-username>" in result.stderr


def test_open_register_as_registers_before_decrypt(monkeypatch, tmp_path) -> None:
    calls: list[str] = []

    class FakeService:
        def init(self) -> None:
            calls.append("init")

        def agent_status(self, workspace: str, agent_type: str):
            raise RuntimeError("not registered")

        def register_agent(self, agent_type: str, workspace: str, username: str):
            calls.append("register")
            return {
                "username": username,
                "agent_type": agent_type,
                "agent_id": "did:key:demo",
            }

        def agent_create_remote(self, workspace: str, agent_type: str):
            calls.append("remote")
            return {"ok": True}

        def open_shared(self, share_path: str, password: str, output: str | None = None, **kwargs):
            calls.append("open")
            return {
                "namespace": "process",
                "item_count": 1,
                "output_file": str(tmp_path / "opened.json"),
                "restore_dir": None,
                "message": None,
            }

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "https://storage.anyfs.ai/raw/demo",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "--register-username",
            "alice-codex",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "Registered AnyFS agent for this machine:" in result.stdout
    assert "Decrypted process (1 items)" in result.stdout
    assert calls == ["init", "register", "remote", "open"]


def test_open_reports_share_failure_without_traceback(monkeypatch, tmp_path) -> None:
    calls: list[str] = []

    class FakeService:
        def init(self) -> None:
            return None

        def agent_status(self, workspace: str, agent_type: str):
            return {"ok": True}

        def open_shared(self, share_path: str, password: str, output: str | None = None, **kwargs):
            calls.append(share_path)
            if "workspace" in share_path:
                raise RuntimeError("network dropped")
            return {
                "namespace": "process",
                "item_count": 1,
                "output_file": str(tmp_path / "process.json"),
                "restore_dir": None,
                "message": None,
            }

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "process.share.json",
            "workspace.share.json",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 1
    assert calls == ["process.share.json", "workspace.share.json"]
    assert "Decrypted process (1 items)" in result.stdout
    assert "Failed to open shared item 2/2: workspace.share.json" in result.stderr
    assert "RuntimeError: network dropped" in result.stderr
    assert "Already restored before failure: process" in result.stderr
    assert "Traceback" not in result.stderr


def test_register_command_prints_account_binding_followup(monkeypatch, tmp_path) -> None:
    class FakeService:
        def register_agent(self, agent_type: str, workspace: str, username: str | None = None):
            return {
                "username": username or "claude-opus",
                "agent_id": "did:key:demo",
                "agent_type": agent_type,
            }

        def agent_create_remote(self, workspace: str, agent_type: str):
            return {"ok": True}

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())
    monkeypatch.setattr(anyfs_local_state, "workspace_agent", lambda workspace, agent_type=None, global_root=None: {})

    result = runner.invoke(
        cli_main.app,
        [
            "register",
            "--type",
            "claude-code",
            "Claude-Opus",
            "-w",
            str(tmp_path),
        ],
    )

    assert result.exit_code == 0
    assert "https://anyfs.ai" in result.stdout
    assert "anyfs agent bind --type claude-code --email <email> --password <password>" in result.stdout


def test_open_resume_prefers_restored_workspace(monkeypatch, tmp_path) -> None:
    process_path = tmp_path / "opened" / "process.json"
    process_path.parent.mkdir(parents=True, exist_ok=True)
    process_path.write_text("[]", encoding="utf-8")
    restored_workspace = tmp_path / "opened" / "workspace"
    restored_workspace.mkdir(parents=True, exist_ok=True)

    calls: list[str] = []

    class FakeService:
        def init(self) -> None:
            return None

        def agent_status(self, workspace: str, agent_type: str):
            return {"ok": True}

        def open_shared(self, share_path: str, password: str, output: str | None = None, **kwargs):
            calls.append(f"open:{share_path}")
            if "workspace" in share_path:
                manifest_path = tmp_path / "opened" / "workspace.json"
                manifest_path.write_text(json.dumps({"mode": "changed", "binding": {"cwd": "/tmp/demo"}}), encoding="utf-8")
                return {
                    "namespace": "workspace",
                    "item_count": 1,
                    "output_file": str(manifest_path),
                    "restore_dir": str(restored_workspace),
                    "message": None,
                }
            return {
                "namespace": "process",
                "item_count": 1,
                "output_file": str(process_path),
                "restore_dir": None,
                "message": None,
            }

        def materialize_transcript_for_target(
            self,
            transcript,
            *,
            target_agent: str,
            workspace: str,
            mode: str,
            source_agent: str | None = None,
            stable_identity: bool = False,
        ):
            calls.append(f"resume:{workspace}")
            return {"session_id": "target-session"}

        def _stable_migration_session_id(self, *, source_agent: str, target_agent: str, source_session_id: str) -> str:
            return "target-session"

    service_instance = FakeService()
    monkeypatch.setattr(cli_main, "service", lambda: service_instance)
    monkeypatch.setattr(
        "anyfs_transcript.load_transcripts",
        lambda path, agent_type=None: [SimpleNamespace(session=SimpleNamespace(agent="claude-code", id="source-session"))],
    )

    result = runner.invoke(
        cli_main.app,
        [
            "open",
            "process.share.json",
            "workspace.share.json",
            "-p",
            "SharedPass123",
            "--type",
            "codex-cli",
            "--resume",
            "-w",
            str(tmp_path / "fallback-workspace"),
        ],
    )

    assert result.exit_code == 0
    assert f"resume:{restored_workspace}" in calls


def test_resume_command_prefers_sibling_restored_workspace(monkeypatch, tmp_path) -> None:
    process_path = tmp_path / "restored" / "process.json"
    process_path.parent.mkdir(parents=True, exist_ok=True)
    process_path.write_text("[]", encoding="utf-8")
    sibling_workspace = process_path.parent / "workspace"
    sibling_workspace.mkdir()
    (process_path.parent / "workspace.json").write_text(json.dumps({"mode": "changed"}), encoding="utf-8")

    used_workspaces: list[str] = []

    class FakeService:
        def materialize_transcript_for_target(
            self,
            transcript,
            *,
            target_agent: str,
            workspace: str,
            mode: str,
            source_agent: str | None = None,
            stable_identity: bool = False,
        ):
            used_workspaces.append(workspace)
            return {"files_written": {}, "session_id": "target-session"}

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())
    monkeypatch.setattr(
        "anyfs_transcript.load_transcripts",
        lambda path, agent_type=None: [
            SimpleNamespace(
                session=SimpleNamespace(agent="claude-code", id="source-session", model="gpt-5.4"),
                events=[],
            )
        ],
    )

    result = runner.invoke(
        cli_main.app,
        [
            "resume",
            str(process_path),
            "--target",
            "codex-cli",
            "--workspace",
            str(tmp_path / "fallback-workspace"),
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert used_workspaces == [str(sibling_workspace)]


def test_resume_command_prefers_flat_restored_workspace_root(monkeypatch, tmp_path) -> None:
    process_path = tmp_path / "restored-flat" / "process.json"
    process_path.parent.mkdir(parents=True, exist_ok=True)
    process_path.write_text("[]", encoding="utf-8")
    (process_path.parent / "workspace.json").write_text(json.dumps({"mode": "changed"}), encoding="utf-8")

    used_workspaces: list[str] = []

    class FakeService:
        def materialize_transcript_for_target(
            self,
            transcript,
            *,
            target_agent: str,
            workspace: str,
            mode: str,
            source_agent: str | None = None,
            stable_identity: bool = False,
        ):
            used_workspaces.append(workspace)
            return {"files_written": {}, "session_id": "target-session"}

    monkeypatch.setattr(cli_main, "service", lambda: FakeService())
    monkeypatch.setattr(
        "anyfs_transcript.load_transcripts",
        lambda path, agent_type=None: [
            SimpleNamespace(
                session=SimpleNamespace(agent="claude-code", id="source-session", model="gpt-5.4"),
                events=[],
            )
        ],
    )

    result = runner.invoke(
        cli_main.app,
        [
            "resume",
            str(process_path),
            "--target",
            "codex-cli",
            "--workspace",
            str(tmp_path / "fallback-workspace"),
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert used_workspaces == [str(process_path.parent)]
