from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapter_opencode import OpenCodeAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _make_export_payload(workspace: Path, session_id: str, prompt: str) -> dict:
    return {
        "info": {
            "id": session_id,
            "slug": "demo",
            "projectID": "proj_anyfs",
            "directory": str(workspace.resolve()),
            "title": "Resumed from claude-code",
            "version": "2.1.89",
            "time": {"created": 1775736000000, "updated": 1775736001000},
        },
        "messages": [
            {
                "info": {
                    "id": "msg_u1",
                    "sessionID": session_id,
                    "role": "user",
                    "time": {"created": 1775736000000},
                    "agent": "build",
                    "model": {"providerID": "moonshotai-cn", "modelID": "kimi-k2.5"},
                },
                "parts": [
                    {
                        "id": "prt_u1",
                        "sessionID": session_id,
                        "messageID": "msg_u1",
                        "type": "text",
                        "text": prompt,
                        "time": {"start": 1775736000000, "end": 1775736000000},
                    }
                ],
            },
            {
                "info": {
                    "id": "msg_a1",
                    "sessionID": session_id,
                    "role": "assistant",
                    "time": {"created": 1775736001000, "completed": 1775736001000},
                    "parentID": "msg_u1",
                    "modelID": "kimi-k2.5",
                    "providerID": "moonshotai-cn",
                    "mode": "default",
                    "agent": "build",
                    "path": {"cwd": str(workspace.resolve()), "root": str(workspace.resolve())},
                    "cost": 0,
                    "tokens": {"input": 0, "output": 0, "reasoning": 0, "cache": {"read": 0, "write": 0}},
                    "finish": "stop",
                },
                "parts": [
                    {
                        "id": "prt_a1",
                        "sessionID": session_id,
                        "messageID": "msg_a1",
                        "type": "reasoning",
                        "text": "Reviewing current state",
                        "time": {"start": 1775736001000, "end": 1775736001000},
                    },
                    {
                        "id": "prt_a2",
                        "sessionID": session_id,
                        "messageID": "msg_a1",
                        "type": "tool",
                        "tool": "bash",
                        "callID": "tool_1",
                        "state": {
                            "status": "completed",
                            "input": {"command": "git status"},
                            "output": "clean",
                            "title": "git status",
                            "metadata": {},
                            "time": {"start": 1775736001000, "end": 1775736001000},
                        },
                    },
                    {
                        "id": "prt_a3",
                        "sessionID": session_id,
                        "messageID": "msg_a1",
                        "type": "text",
                        "text": "No pending changes.",
                        "time": {"start": 1775736001000, "end": 1775736001000},
                    },
                ],
            },
        ],
    }


def _install_fake_opencode(tmp_path: Path, workspace: Path) -> None:
    export_payloads = {
        "ses_test": _make_export_payload(workspace, "ses_test", "What changed?"),
        "ses_test_2": _make_export_payload(workspace, "ses_test_2", "Newest session"),
    }
    script = tmp_path / "opencode"
    script.write_text(
        "\n".join(
            [
                "#!/usr/bin/env python3",
                "import json, sys",
                f"workspace = {str(workspace.resolve())!r}",
                f"payloads = {export_payloads!r}",
                "argv = sys.argv[1:]",
                "if argv == ['session', 'list', '--format', 'json']:",
                "    print(json.dumps([",
                "        {'id': 'ses_test_2', 'title': 'Demo 2', 'updated': 1775736002000, 'created': 1775736001000, 'projectId': 'proj_anyfs', 'directory': workspace},",
                "        {'id': 'ses_test', 'title': 'Demo', 'updated': 1775736001000, 'created': 1775736000000, 'projectId': 'proj_anyfs', 'directory': workspace},",
                "    ]))",
                "    raise SystemExit(0)",
                "if len(argv) == 2 and argv[0] == 'export' and argv[1] in payloads:",
                "    print('Exporting session:', argv[1])",
                "    print(json.dumps(payloads[argv[1]]))",
                "    raise SystemExit(0)",
                "raise SystemExit(1)",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    script.chmod(0o755)
    os.environ["PATH"] = f"{tmp_path}{os.pathsep}{os.environ.get('PATH', '')}"
    os.environ.pop("OPENCODE_BIN", None)


def test_opencode_adapter_discovers_and_extracts_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    _write_file(workspace, "opencode.json", '{"model":"moonshotai-cn/kimi-k2.5"}')
    _write_file(workspace, ".opencode/local.md", "# local opencode skill")
    _install_fake_opencode(tmp_path, workspace)
    monkeypatch.setenv("HOME", str(tmp_path))
    _write_file(tmp_path, ".config/opencode/skills/demo/SKILL.md", "# global opencode skill")
    _write_file(tmp_path, ".config/opencode/package.json", '{"dependencies":{"@opencode-ai/plugin":"1.0.0"}}')

    adapter = OpenCodeAdapter()
    files = adapter.discover(str(workspace))
    assert all(path.name != "opencode.json" for path in files)
    assert any(path.name == "ses_test_2.json" for path in files)
    assert any(path.name == "SKILL.md" for path in files)

    records = adapter.extract(str(workspace))
    process_record = next(item for item in records if item["namespace"] == "process")
    assert process_record["canonical_transcript"]["session"]["agent"] == "opencode"
    assert "Newest session" in process_record["content"]
    assert any(item["namespace"] == "skills" for item in records)
    assert any(item["relative_path"].startswith("skills/opencode/global/skills") for item in records)
    assert all(not item["path"].endswith("opencode.json") for item in records)
    assert all(not item["path"].endswith("package.json") for item in records)


def test_opencode_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    _write_file(workspace, ".opencode/local.md", "# local opencode skill")
    _install_fake_opencode(tmp_path, workspace)
    monkeypatch.setenv("HOME", str(tmp_path))

    adapter = OpenCodeAdapter(process_scope="all")
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 2


def test_opencode_adapter_bundle_and_agent_type():
    adapter = OpenCodeAdapter()
    normalized = {"process": [{"content": "session"}], "skills": [{"content": "config"}]}
    result = adapter.bundle(normalized)
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.OPENCODE
    assert set(result.captured_namespaces) == {"process", "skills"}
