from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapter_gemini_cli import GeminiCLIAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_gemini_session(home: Path, workspace: Path) -> Path:
    project_dir = home / ".gemini" / "tmp" / "workspace-a"
    (project_dir / "chats").mkdir(parents=True, exist_ok=True)
    (project_dir / ".project_root").write_text(str(workspace.resolve()), encoding="utf-8")
    session_path = project_dir / "chats" / "session-1.json"
    session_path.write_text(
        json.dumps(
            {
                "sessionId": "gem-1",
                "projectHash": "workspace-a",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:01+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "Check skills"},
                    {
                        "id": "a1",
                        "timestamp": "2026-04-09T12:00:01+00:00",
                        "type": "gemini",
                        "content": "Loaded Gemini state.",
                        "thoughts": [{"subject": "reasoning", "description": "Inspecting skills", "timestamp": "2026-04-09T12:00:01+00:00"}],
                    },
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return session_path


def test_gemini_adapter_extracts_process_and_skills(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    gemini_home = tmp_path / "gemini-home"
    _write_gemini_session(gemini_home, workspace)
    _write_file(gemini_home, ".gemini/skills/demo/SKILL.md", "# Gemini skill")
    _write_file(gemini_home, ".gemini/antigravity/global_skills/global.md", "# Global skill")
    _write_file(gemini_home, ".gemini/projects.json", '{"workspace-a":{"name":"workspace-a"}}')
    _write_file(workspace, "GEMINI.md", "# Workspace Gemini instructions")
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home / ".gemini"))

    adapter = GeminiCLIAdapter()
    files = adapter.discover(str(workspace))
    assert any(path.name == "GEMINI.md" for path in files)
    assert any(path.name == "SKILL.md" for path in files)
    assert any(path.name == "session-1.json" for path in files)

    records = adapter.extract(str(workspace))
    assert any(item["namespace"] == "process" for item in records)
    assert any(item["namespace"] == "skills" for item in records)
    assert any(item["relative_path"].startswith("skills/gemini/global/skills") for item in records)
    assert all(not item["path"].endswith(".gemini/projects.json") for item in records)
    process = next(item for item in records if item["namespace"] == "process")
    assert process["canonical_transcript"]["session"]["agent"] == "gemini-cli"
    assert "Check skills" in process["content"]


def test_gemini_adapter_defaults_to_current_session_only(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    gemini_home = tmp_path / "gemini-home"
    _write_gemini_session(gemini_home, workspace)
    second = _write_file(
        gemini_home,
        ".gemini/tmp/workspace-a/chats/session-2.json",
        json.dumps(
            {
                "sessionId": "gem-2",
                "projectHash": "workspace-a",
                "startTime": "2026-04-09T12:00:02+00:00",
                "lastUpdated": "2026-04-09T12:00:03+00:00",
                "messages": [{"id": "u2", "timestamp": "2026-04-09T12:00:02+00:00", "type": "user", "content": "Newest"}],
            }
        ),
    )
    first = gemini_home / ".gemini/tmp/workspace-a/chats/session-1.json"
    os.utime(first, (1, 1))
    os.utime(second, (2, 2))
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home / ".gemini"))

    adapter = GeminiCLIAdapter()
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 1
    assert records[0]["path"] == str(second)


def test_gemini_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    gemini_home = tmp_path / "gemini-home"
    _write_gemini_session(gemini_home, workspace)
    _write_file(
        gemini_home,
        ".gemini/tmp/workspace-a/chats/session-2.json",
        json.dumps(
            {
                "sessionId": "gem-2",
                "projectHash": "workspace-a",
                "startTime": "2026-04-09T12:00:02+00:00",
                "lastUpdated": "2026-04-09T12:00:03+00:00",
                "messages": [{"id": "u2", "timestamp": "2026-04-09T12:00:02+00:00", "type": "user", "content": "Newest"}],
            }
        ),
    )
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home / ".gemini"))

    adapter = GeminiCLIAdapter(process_scope="all")
    records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(records) == 2


def test_gemini_adapter_bundle():
    adapter = GeminiCLIAdapter()
    result = adapter.bundle({"process": [{"content": "session"}], "skills": [{"content": "skill"}]})
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.GEMINI_CLI
    assert set(result.captured_namespaces) == {"process", "skills"}
