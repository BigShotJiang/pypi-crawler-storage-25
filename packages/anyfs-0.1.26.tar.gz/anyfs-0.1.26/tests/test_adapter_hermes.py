from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from anyfs_adapters_core import build_current_session_hint
from anyfs_adapter_hermes import HermesAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_hermes_session(hermes_home: Path, session_id: str, prompt: str) -> Path:
    sessions_dir = hermes_home / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    path = sessions_dir / f"{session_id}.jsonl"
    path.write_text(
        "\n".join(
            [
                json.dumps({"role": "user", "content": prompt, "timestamp": "2026-04-09T12:00:00+00:00"}),
                json.dumps({"role": "assistant", "content": "Working on it.", "timestamp": "2026-04-09T12:00:01+00:00"}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def _write_hermes_session_json(hermes_home: Path, session_id: str, prompt: str) -> Path:
    sessions_dir = hermes_home / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    path = sessions_dir / f"session_{session_id}.json"
    path.write_text(
        json.dumps(
            {
                "session_id": session_id,
                "session_start": "2026-04-09T12:00:00+00:00",
                "last_updated": "2026-04-09T12:00:01+00:00",
                "messages": [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": "Working on it.", "reasoning": "Thinking..."},
                ],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return path


def _write_hermes_state_db(hermes_home: Path, session_ids: list[str] | list[tuple[str, str]]) -> None:
    db_path = hermes_home / "state.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        CREATE TABLE sessions (
            id TEXT PRIMARY KEY,
            source TEXT NOT NULL,
            started_at REAL NOT NULL,
            title TEXT
        )
        """
    )
    for index, entry in enumerate(session_ids, start=1):
        if isinstance(entry, tuple):
            session_id, source = entry
        else:
            session_id, source = entry, "cli"
        conn.execute(
            "INSERT INTO sessions (id, source, started_at, title) VALUES (?, ?, ?, ?)",
            (session_id, source, float(index), session_id),
        )
    conn.commit()
    conn.close()


def test_hermes_adapter_discovers_and_extracts_personal_agent_state(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"

    _write_file(hermes_home, "AGENTS.md", "# agent instructions")
    _write_file(hermes_home, "SOUL.md", "# soul")
    _write_file(hermes_home, "memories/USER.md", "# user profile")
    _write_file(hermes_home, "memories/MEMORY.md", "# durable memory")
    _write_file(hermes_home, "skills/demo/SKILL.md", "# skill")
    _write_file(workspace, ".hermes/local.md", "# local hidden")
    _write_file(hermes_home, "config.yaml", "model: test")
    session_path = _write_hermes_session(hermes_home, "20260409_120000_demo", "Resume from here")
    _write_hermes_state_db(hermes_home, ["20260409_120000_demo"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter()
    files = adapter.discover(str(workspace))
    assert all(path.name != "config.yaml" for path in files)
    assert any(path.name == "SOUL.md" for path in files)
    assert any(path.name == "SKILL.md" for path in files)
    assert session_path in files
    assert all(".hermes" not in str(path) for path in files)

    records = adapter.extract(str(workspace))
    namespaces = {item["namespace"] for item in records}
    assert {"soul", "user", "memory", "skills", "process"} <= namespaces
    assert any(item["relative_path"].startswith("skills/hermes/global/skills") for item in records)
    assert any(item["relative_path"] == "skills/hermes/global/AGENTS.md" for item in records)
    assert all(not item["path"].endswith("config.yaml") for item in records)
    assert all(".hermes/local.md" not in item["path"] for item in records)
    process = next(item for item in records if item["namespace"] == "process")
    assert process["canonical_transcript"]["session"]["agent"] == "hermes"
    assert "Resume from here" in process["content"]


def test_hermes_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    _write_hermes_session(hermes_home, "20260409_050010_old", "Old session")
    _write_hermes_session(hermes_home, "20260409_120000_new", "New session")
    _write_hermes_state_db(hermes_home, ["20260409_120000_new", "20260409_050010_old"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(process_scope="all")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(process_records) == 2


def test_hermes_adapter_current_scope_skips_stale_state_db_session_ids(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    valid = _write_hermes_session(hermes_home, "20260409_120000_valid", "Valid session")
    _write_hermes_state_db(hermes_home, ["20260414_122734_missing", "20260409_120000_valid"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(process_scope="current")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]

    assert len(process_records) == 1
    assert process_records[0]["path"] == str(valid)


def test_hermes_adapter_current_scope_prefers_latest_feishu_session(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    older_cli = _write_hermes_session(hermes_home, "20260409_120000_cli", "CLI session")
    newer_feishu = _write_hermes_session(hermes_home, "20260415_050448_feishu", "Share current session")
    _write_hermes_state_db(
        hermes_home,
        [
            ("20260409_120000_cli", "cli"),
            ("20260415_050448_feishu", "feishu"),
        ],
    )
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(process_scope="current")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]

    assert len(process_records) == 1
    assert process_records[0]["path"] == str(newer_feishu)
    assert process_records[0]["path"] != str(older_cli)


def test_hermes_adapter_current_scope_supports_session_json_files(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    expected = _write_hermes_session_json(hermes_home, "20260415_093111_b50d51", "Share current session")
    _write_hermes_state_db(hermes_home, ["20260415_093111_b50d51"])
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(process_scope="current")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]

    assert len(process_records) == 1
    assert process_records[0]["path"] == str(expected)
    assert process_records[0]["canonical_transcript"]["session"]["id"] == "20260415_093111_b50d51"
    assert "Share current session" in process_records[0]["content"]


def test_hermes_adapter_current_hint_can_reorder_candidates(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    hermes_home = tmp_path / "hermes-home"
    older = _write_hermes_session(hermes_home, "20260409_120000_old", "Share current session")
    newer = _write_hermes_session(hermes_home, "20260415_050448_new", "Different prompt")
    _write_hermes_state_db(
        hermes_home,
        [
            ("20260409_120000_old", "cli"),
            ("20260415_050448_new", "feishu"),
        ],
    )
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))

    adapter = HermesAdapter(
        process_scope="current",
        current_session_hint=build_current_session_hint("Share current session"),
    )
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]

    assert len(process_records) == 1
    assert process_records[0]["path"] == str(older)


def test_hermes_adapter_bundle_and_agent_type():
    adapter = HermesAdapter()
    normalized = {"soul": [{"content": "persona"}], "skills": [{"content": "guidance"}]}
    result = adapter.bundle(normalized)
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.HERMES
    assert set(result.captured_namespaces) == {"soul", "skills"}
