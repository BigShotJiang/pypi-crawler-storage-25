from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from typer.testing import CliRunner

from anyfs_cli.main import app
from anyfs_crypto import encrypt_json_payload, rewrap_dek_for_share
from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)
from anyfs_transcript import export_transcript, inject_transcript, load_transcripts


def _sample_transcript() -> CanonicalTranscript:
    now = datetime(2026, 4, 9, 12, 0, tzinfo=timezone.utc)
    return CanonicalTranscript(
        session=TranscriptSessionMeta(
            id="session-1",
            agent="claude-code",
            model="gpt-5.4",
            cwd="/tmp/demo",
            git_branch="main",
            started_at=now,
            ended_at=now,
        ),
        events=[
            UserMessageEvent(ts=now, text="Fix the bug"),
            ThinkingEvent(ts=now, text="Inspecting the failing path"),
            AssistantTextEvent(ts=now, text="I found the issue."),
            ShellCommandEvent(ts=now, command="pytest -q", output_preview="1 failed", exit_code=1),
            CodeSearchEvent(ts=now, tool_name="search", query="bug", result_preview="match"),
        ],
    )


def _process_share_file(tmp_path: Path, transcript: CanonicalTranscript, password: str) -> Path:
    bundle = [{"canonical_transcript": transcript.model_dump(mode="json")}]
    root_key = b"r" * 32
    share_envelope = rewrap_dek_for_share(
        root_key,
        encrypt_json_payload(root_key, bundle, "process"),
        password,
    )
    path = tmp_path / "process.share.json"
    path.write_text(json.dumps(share_envelope, indent=2), encoding="utf-8")
    return path


def _install_fake_opencode(tmp_path: Path, monkeypatch) -> Path:
    log_path = tmp_path / "opencode.log"
    script_path = tmp_path / "opencode"
    script_path.write_text(
        "\n".join(
            [
                "#!/usr/bin/env bash",
                'printf "cwd=%s\\n" "$PWD" >> "' + str(log_path) + '"',
                'printf "args=%s\\n" "$*" >> "' + str(log_path) + '"',
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    script_path.chmod(0o755)
    monkeypatch.setenv("PATH", f"{tmp_path}{os.pathsep}{os.environ.get('PATH', '')}")
    monkeypatch.delenv("OPENCODE_BIN", raising=False)
    return log_path


def test_export_transcript_supports_gemini_openclaw_and_opencode(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    gemini_home = tmp_path / "gemini-home"
    gemini_dir = gemini_home / ".gemini"
    monkeypatch.setenv("GEMINI_CLI_HOME", str(gemini_home))
    gemini_result = export_transcript(transcript, target_agent="gemini-cli", workspace=str(workspace))

    gemini_path = Path(gemini_result["transcript"])
    payload = json.loads(gemini_path.read_text(encoding="utf-8"))
    assert gemini_path.exists()
    assert payload["sessionId"] == gemini_result["session_id"]
    assert payload["projectHash"] == hashlib.sha256(str(workspace.resolve()).encode("utf-8")).hexdigest()
    assert payload["kind"] == "main"
    assert payload["messages"][0]["type"] == "user"
    assert payload["messages"][1]["type"] == "gemini"
    assert payload["messages"][1]["thoughts"]
    assert payload["messages"][1]["toolCalls"]
    assert (gemini_dir / "projects.json").exists()
    assert (gemini_dir / "tmp" / gemini_result["project_id"] / ".project_root").exists()

    openclaw_home = tmp_path / "openclaw-home"
    agent_root = openclaw_home / "agents" / "agent-default"
    agent_root.mkdir(parents=True)
    monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))
    openclaw_result = export_transcript(transcript, target_agent="openclaw", workspace=str(workspace))

    store_path = Path(openclaw_result["session_store"])
    transcript_path = Path(openclaw_result["transcript"])
    store_payload = json.loads(store_path.read_text(encoding="utf-8"))
    transcript_lines = transcript_path.read_text(encoding="utf-8").strip().splitlines()

    assert transcript_path.exists()
    assert store_payload[openclaw_result["session_key"]]["sessionId"] == openclaw_result["session_id"]
    assert store_payload[openclaw_result["session_key"]]["sessionFile"] == str(transcript_path)
    assert openclaw_result["session_key"].startswith("agent:agent-default:resume:")
    assert json.loads(transcript_lines[0])["type"] == "session"
    assert json.loads(transcript_lines[1])["message"]["role"] == "user"
    assert json.loads(transcript_lines[2])["message"]["role"] == "assistant"
    parsed_openclaw = load_transcripts(transcript_path, agent_type="openclaw")[0]
    assert parsed_openclaw.session.agent == "openclaw"
    assert parsed_openclaw.session.id == openclaw_result["session_id"]
    assert [event.kind for event in parsed_openclaw.events[:5]] == [
        "user_message",
        "thinking",
        "assistant_text",
        "shell_command",
        "code_search",
    ]

    monkeypatch.setenv("HOME", str(tmp_path))
    opencode_config_dir = tmp_path / ".config" / "opencode"
    opencode_config_dir.mkdir(parents=True)
    (opencode_config_dir / "opencode.json").write_text(
        json.dumps({"model": "moonshotai-cn/kimi-k2.5"}, indent=2),
        encoding="utf-8",
    )
    opencode_log = _install_fake_opencode(tmp_path, monkeypatch)
    opencode_result = export_transcript(transcript, target_agent="opencode", workspace=str(workspace))
    export_path = Path(opencode_result["session_export"])
    payload = json.loads(export_path.read_text(encoding="utf-8"))

    assert export_path.exists()
    assert payload["info"]["id"] == opencode_result["session_id"]
    assert payload["messages"][0]["info"]["role"] == "user"
    assert payload["messages"][0]["parts"][0]["type"] == "text"
    assert payload["messages"][1]["info"]["role"] == "assistant"
    assert {part["type"] for part in payload["messages"][1]["parts"]} >= {"text", "reasoning", "tool"}
    assert payload["messages"][1]["info"]["providerID"] == "moonshotai-cn"
    assert payload["messages"][1]["info"]["modelID"] == "kimi-k2.5"
    assert opencode_result["resume_hint"] == f"opencode --session {opencode_result['session_id']}"
    assert f"args=import {export_path}" in opencode_log.read_text(encoding="utf-8")
    parsed_opencode = load_transcripts(export_path, agent_type="opencode")[0]
    assert parsed_opencode.session.agent == "opencode"
    assert parsed_opencode.session.id == opencode_result["session_id"]
    assert [event.kind for event in parsed_opencode.events[:5]] == [
        "user_message",
        "thinking",
        "assistant_text",
        "shell_command",
        "code_search",
    ]


def test_export_transcript_writes_codex_turn_events(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    monkeypatch.setenv("HOME", str(tmp_path))
    codex_result = export_transcript(transcript, target_agent="codex-cli", workspace=str(workspace))
    codex_path = Path(codex_result["transcript"])
    entries = [
        json.loads(line)
        for line in codex_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]

    assert codex_path.exists()
    assert entries[0]["type"] == "session_meta"
    assert entries[1]["type"] == "event_msg"
    assert entries[1]["payload"]["type"] == "task_started"
    assert entries[2]["type"] == "turn_context"

    event_types = [
        entry["payload"]["type"]
        for entry in entries
        if entry["type"] == "event_msg"
    ]
    assert "user_message" in event_types
    assert "agent_message" in event_types
    assert event_types[-1] == "task_complete"

    response_messages = [
        entry["payload"]
        for entry in entries
        if entry["type"] == "response_item" and entry["payload"]["type"] == "message"
    ]
    assert response_messages[0]["role"] == "user"
    assert response_messages[1]["role"] == "assistant"
    assert codex_result["resume_hint"] == f"codex resume {codex_result['session_id']}"


def test_export_transcript_reuses_stable_code_session_id(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()
    stable_session_id = "7c5e7a89-54ff-5b7d-9110-55d0cbe308f1"

    monkeypatch.setenv("HOME", str(tmp_path))
    codex_first = export_transcript(
        transcript,
        target_agent="codex-cli",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    codex_second = export_transcript(
        transcript,
        target_agent="codex-cli",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    assert codex_first["session_id"] == stable_session_id
    assert codex_first["transcript"] == codex_second["transcript"]

    monkeypatch.setenv("GEMINI_CLI_HOME", str(tmp_path / "gemini-home"))
    gemini_first = export_transcript(
        transcript,
        target_agent="gemini-cli",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    gemini_second = export_transcript(
        transcript,
        target_agent="gemini-cli",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    assert gemini_first["session_id"] == stable_session_id
    assert gemini_first["transcript"] == gemini_second["transcript"]

    claude_first = export_transcript(
        transcript,
        target_agent="claude-code",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    claude_second = export_transcript(
        transcript,
        target_agent="claude-code",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    assert claude_first["session_id"] == stable_session_id
    assert claude_first["transcript"] == claude_second["transcript"]
    assert claude_first["session_meta"] == claude_second["session_meta"]
    assert claude_first["resume_hint"] == f"claude --resume {stable_session_id}"

    opencode_config_dir = tmp_path / ".config" / "opencode"
    opencode_config_dir.mkdir(parents=True, exist_ok=True)
    (opencode_config_dir / "opencode.json").write_text(
        json.dumps({"model": "openai/gpt-5.4"}, indent=2),
        encoding="utf-8",
    )
    _install_fake_opencode(tmp_path, monkeypatch)
    opencode_first = export_transcript(
        transcript,
        target_agent="opencode",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    opencode_second = export_transcript(
        transcript,
        target_agent="opencode",
        workspace=str(workspace),
        session_id=stable_session_id,
    )
    assert opencode_first["session_id"].startswith("ses_")
    assert opencode_first["session_id"] == opencode_second["session_id"]
    assert opencode_first["session_export"] == opencode_second["session_export"]


def test_export_transcript_supports_hermes_and_nanobot(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    hermes_home = tmp_path / "hermes-home"
    monkeypatch.setenv("HERMES_HOME", str(hermes_home))
    hermes_result = export_transcript(transcript, target_agent="hermes", workspace=str(workspace))

    hermes_db = Path(hermes_result["state_db"])
    hermes_transcript = Path(hermes_result["transcript"])
    assert hermes_db.exists()
    assert hermes_transcript.exists()
    with sqlite3.connect(hermes_db) as conn:
        row = conn.execute("SELECT source, model, title FROM sessions WHERE id = ?", (hermes_result["session_id"],)).fetchone()
        msg_count = conn.execute("SELECT COUNT(*) FROM messages WHERE session_id = ?", (hermes_result["session_id"],)).fetchone()[0]
    assert row == ("cli", "gpt-5.4", "Resumed from claude-code")
    assert msg_count >= 5
    parsed_hermes = load_transcripts(hermes_result["transcript"], agent_type="hermes")[0]
    assert parsed_hermes.session.agent == "hermes"
    assert parsed_hermes.session.id == hermes_result["session_id"]
    assert [event.kind for event in parsed_hermes.events[:5]] == [
        "user_message",
        "thinking",
        "assistant_text",
        "shell_command",
        "code_search",
    ]

    nanobot_result = export_transcript(transcript, target_agent="nanobot", workspace=str(workspace))
    nanobot_path = Path(nanobot_result["transcript"])
    lines = nanobot_path.read_text(encoding="utf-8").strip().splitlines()
    metadata = json.loads(lines[0])
    assert metadata["_type"] == "metadata"
    assert metadata["key"] == nanobot_result["session_key"]
    parsed_nanobot = load_transcripts(nanobot_result["transcript"], agent_type="nanobot")[0]
    assert parsed_nanobot.session.agent == "nanobot"
    assert parsed_nanobot.session.id == nanobot_result["session_key"]
    assert [event.kind for event in parsed_nanobot.events[:5]] == [
        "user_message",
        "thinking",
        "assistant_text",
        "shell_command",
        "code_search",
    ]


def test_load_transcripts_auto_detects_openclaw_and_opencode(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    openclaw_home = tmp_path / "openclaw-home"
    (openclaw_home / "agents" / "agent-default").mkdir(parents=True)
    monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))
    openclaw_result = export_transcript(transcript, target_agent="openclaw", workspace=str(workspace))
    detected_openclaw = load_transcripts(openclaw_result["transcript"])[0]
    assert detected_openclaw.session.agent == "openclaw"
    assert detected_openclaw.events[0].kind == "user_message"

    monkeypatch.setenv("HOME", str(tmp_path))
    opencode_config_dir = tmp_path / ".config" / "opencode"
    opencode_config_dir.mkdir(parents=True)
    (opencode_config_dir / "opencode.json").write_text(
        json.dumps({"model": "openai/gpt-5.4"}, indent=2),
        encoding="utf-8",
    )
    _install_fake_opencode(tmp_path, monkeypatch)
    opencode_result = export_transcript(transcript, target_agent="opencode", workspace=str(workspace))
    detected_opencode = load_transcripts(opencode_result["session_export"])[0]
    assert detected_opencode.session.agent == "opencode"
    assert detected_opencode.events[0].kind == "user_message"


def test_load_transcripts_auto_detects_hermes_and_nanobot(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    monkeypatch.setenv("HERMES_HOME", str(tmp_path / "hermes-home"))
    hermes_result = export_transcript(transcript, target_agent="hermes", workspace=str(workspace))
    detected_hermes = load_transcripts(hermes_result["transcript"])[0]
    assert detected_hermes.session.agent == "hermes"
    assert detected_hermes.events[0].kind == "user_message"

    nanobot_result = export_transcript(transcript, target_agent="nanobot", workspace=str(workspace))
    detected_nanobot = load_transcripts(nanobot_result["transcript"])[0]
    assert detected_nanobot.session.agent == "nanobot"
    assert detected_nanobot.events[0].kind == "user_message"


def test_inject_transcript_keeps_gemini_context_mode(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    result = inject_transcript(transcript, target_agent="gemini-cli", workspace=str(workspace))

    gemini_md = Path(result["gemini_md"])
    assert gemini_md.exists()
    assert "Resumed Session Context" in gemini_md.read_text(encoding="utf-8")


def test_resume_cli_uses_native_export_for_gemini_openclaw_and_opencode(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    source_path = tmp_path / "source-gemini.json"
    source_path.write_text(
        json.dumps(
            {
                "sessionId": "src-session",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:00+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "hello"},
                    {"id": "a1", "timestamp": "2026-04-09T12:00:01+00:00", "type": "gemini", "content": "hi"},
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    gemini_home = tmp_path / "gemini-home"
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home))
    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "gemini-cli",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["target_agent"] == "gemini-cli"
    assert Path(payload["files_written"]["transcript"]).exists()
    assert payload["resume_hint"] == f"gemini --resume {payload['files_written']['session_id']}"

    openclaw_home = tmp_path / "openclaw-home"
    (openclaw_home / "agents" / "agent-default").mkdir(parents=True)
    monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))
    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "openclaw",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["target_agent"] == "openclaw"
    assert Path(payload["files_written"]["session_store"]).exists()
    assert payload["resume_hint"].startswith("openclaw agent --session-id ")

    opencode_log = _install_fake_opencode(tmp_path, monkeypatch)
    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "opencode",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["target_agent"] == "opencode"
    assert Path(payload["files_written"]["session_export"]).exists()
    assert payload["resume_hint"] == f"opencode --session {payload['files_written']['session_id']}"
    assert "args=import " in opencode_log.read_text(encoding="utf-8")


def test_resume_cli_uses_native_export_for_hermes_and_nanobot(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    source_path = tmp_path / "source-gemini.json"
    source_path.write_text(
        json.dumps(
            {
                "sessionId": "src-session",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:00+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "hello"},
                    {"id": "a1", "timestamp": "2026-04-09T12:00:01+00:00", "type": "gemini", "content": "hi"},
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    monkeypatch.setenv("HERMES_HOME", str(tmp_path / "hermes-home"))
    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "hermes",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["target_agent"] == "hermes"
    assert Path(payload["files_written"]["state_db"]).exists()
    assert payload["resume_hint"] == f"hermes --resume {payload['files_written']['session_id']}"

    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "nanobot",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["target_agent"] == "nanobot"
    assert Path(payload["files_written"]["transcript"]).exists()
    assert payload["resume_hint"].startswith("nanobot agent --session ")


def test_resume_cli_accepts_process_share_file(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    share_path = _process_share_file(tmp_path, _sample_transcript(), "SharedPass123")

    gemini_home = tmp_path / "gemini-home"
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home))
    result = runner.invoke(
        app,
        [
            "resume",
            str(share_path),
            "--target",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--password",
            "SharedPass123",
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["opened_share"]["namespace"] == "process"
    assert payload["resolved_source"].endswith("process.json")
    assert Path(payload["files_written"]["transcript"]).exists()


def test_resume_cli_shows_summary_and_native_open_hint_by_default(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    source_path = tmp_path / "source-gemini.json"
    source_path.write_text(
        json.dumps(
            {
                "sessionId": "src-session",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:00+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "hello"},
                    {"id": "a1", "timestamp": "2026-04-09T12:00:01+00:00", "type": "gemini", "content": "hi"},
                ],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    gemini_home = tmp_path / "gemini-home"
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home))
    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "gemini-cli",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
        ],
    )

    assert result.exit_code == 0, result.output
    assert not result.stdout.lstrip().startswith("{")
    assert "Resume Summary" in result.stdout
    assert "gemini --resume" in result.stdout
    assert "src-session" in result.stdout
    assert "hello" in result.stdout


def test_resume_cli_summary_shows_skills_import_line(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    transcript = _sample_transcript()
    process_path = tmp_path / "process.json"
    process_path.write_text(
        json.dumps([{"canonical_transcript": transcript.model_dump(mode="json")}], indent=2),
        encoding="utf-8",
    )
    skills_path = tmp_path / "skills.json"
    skills_path.write_text(
        json.dumps(
            [
                {
                    "namespace": "skills",
                    "path": "/tmp/source/skills/demo/SKILL.md",
                    "relative_path": "skills/demo/SKILL.md",
                    "content": "# Demo Skill\n",
                }
            ],
            indent=2,
        ),
        encoding="utf-8",
    )

    monkeypatch.setenv("HOME", str(tmp_path))
    result = runner.invoke(
        app,
        [
            "resume",
            str(process_path),
            "--target",
            "codex-cli",
            "--workspace",
            str(workspace),
        ],
    )

    assert result.exit_code == 0, result.output
    assert "Resume Summary" in result.stdout
    assert "Skills imported:" in result.stdout
    assert ".codex/skills/anyfs-imports/claude-code" in result.stdout


def test_resume_cli_requires_password_for_share_artifact(tmp_path: Path) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    share_path = _process_share_file(tmp_path, _sample_transcript(), "SharedPass123")

    result = runner.invoke(
        app,
        [
            "resume",
            str(share_path),
            "--target",
            "gemini-cli",
            "--workspace",
            str(workspace),
        ],
    )

    assert result.exit_code != 0
    assert "share resume requires --password" in result.output


def test_share_cli_requires_message(tmp_path: Path) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    (workspace / "CLAUDE.md").write_text("# guidance\n", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "share",
            "--workspace",
            str(workspace),
            "--type",
            "claude-code",
        ],
    )

    assert result.exit_code != 0
    assert "--message" in result.output


def test_export_openclaw_bootstraps_default_agent_root(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()
    monkeypatch.setenv("OPENCLAW_HOME", str(tmp_path / "openclaw-home"))
    result = export_transcript(transcript, target_agent="openclaw", workspace=str(workspace))

    assert result["agent_id"] == "main"
    assert Path(result["transcript"]).exists()


def test_export_opencode_without_binary_returns_manual_import_hint(tmp_path: Path, monkeypatch) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()

    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("PATH", str(tmp_path))
    monkeypatch.delenv("OPENCODE_BIN", raising=False)
    result = export_transcript(transcript, target_agent="opencode", workspace=str(workspace))

    assert result["imported"] is False
    assert result["resume_hint"].startswith("opencode import ")
    assert Path(result["session_export"]).exists()


def test_resume_cli_cursor_requires_context_only(tmp_path: Path) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    source_path = tmp_path / "source-gemini.json"
    source_path.write_text(
        json.dumps(
            {
                "sessionId": "src-session",
                "startTime": "2026-04-09T12:00:00+00:00",
                "lastUpdated": "2026-04-09T12:00:00+00:00",
                "messages": [
                    {"id": "u1", "timestamp": "2026-04-09T12:00:00+00:00", "type": "user", "content": "hello"},
                ],
            }
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "cursor",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
        ],
    )
    assert result.exit_code != 0
    assert "native export not yet supported" in result.output

    result = runner.invoke(
        app,
        [
            "resume",
            str(source_path),
            "--target",
            "cursor",
            "--source",
            "gemini-cli",
            "--workspace",
            str(workspace),
            "--context-only",
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "context"


def test_load_transcripts_supports_canonical_bundle(tmp_path: Path) -> None:
    transcript_one = _sample_transcript()
    transcript_two = _sample_transcript().model_copy(
        update={
            "session": _sample_transcript().session.model_copy(update={"id": "session-2"}),
        }
    )
    bundle_path = tmp_path / "process.json"
    bundle_path.write_text(
        json.dumps(
            [
                {"canonical_transcript": transcript_one.model_dump(mode="json")},
                {"canonical_transcript": transcript_two.model_dump(mode="json")},
            ],
            indent=2,
        ),
        encoding="utf-8",
    )

    transcripts = load_transcripts(bundle_path)
    assert [item.session.id for item in transcripts] == ["session-1", "session-2"]


def test_resume_cli_native_exports_multiple_canonical_sessions(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    transcript_one = _sample_transcript()
    transcript_two = _sample_transcript().model_copy(
        update={
            "session": transcript_one.session.model_copy(update={"id": "session-2"}),
        }
    )
    bundle_path = tmp_path / "process.json"
    bundle_path.write_text(
        json.dumps(
            [
                {"canonical_transcript": transcript_one.model_dump(mode="json")},
                {"canonical_transcript": transcript_two.model_dump(mode="json")},
            ],
            indent=2,
        ),
        encoding="utf-8",
    )

    gemini_home = tmp_path / "gemini-home"
    monkeypatch.setenv("GEMINI_HOME", str(gemini_home))
    result = runner.invoke(
        app,
        ["resume", str(bundle_path), "--target", "gemini-cli", "--workspace", str(workspace), "--json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["transcript_count"] == 2
    assert len(payload["sessions"]) == 2
    assert all(Path(item["files_written"]["transcript"]).exists() for item in payload["sessions"])

    openclaw_home = tmp_path / "openclaw-home"
    (openclaw_home / "agents" / "agent-default").mkdir(parents=True)
    monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))
    result = runner.invoke(
        app,
        ["resume", str(bundle_path), "--target", "openclaw", "--workspace", str(workspace), "--json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["transcript_count"] == 2
    store_path = Path(payload["sessions"][0]["files_written"]["session_store"])
    store_payload = json.loads(store_path.read_text(encoding="utf-8"))
    assert len(store_payload) == 2

    opencode_log = _install_fake_opencode(tmp_path, monkeypatch)
    result = runner.invoke(
        app,
        ["resume", str(bundle_path), "--target", "opencode", "--workspace", str(workspace), "--json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["transcript_count"] == 2
    assert all(Path(item["files_written"]["session_export"]).exists() for item in payload["sessions"])
    assert opencode_log.read_text(encoding="utf-8").count("args=import ") == 2


def test_resume_cli_materializes_adjacent_skills_payload_with_dedupe(tmp_path: Path, monkeypatch) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    transcript = _sample_transcript()
    process_path = tmp_path / "process.json"
    process_path.write_text(
        json.dumps(
            [
                {"canonical_transcript": transcript.model_dump(mode="json")},
            ],
            indent=2,
        ),
        encoding="utf-8",
    )
    skills_path = tmp_path / "skills.json"
    skills_path.write_text(
        json.dumps(
            [
                {
                    "namespace": "skills",
                    "path": "/tmp/source/skills/demo/SKILL.md",
                    "relative_path": "skills/demo/SKILL.md",
                    "content": "# Demo Skill\n",
                },
                {
                    "namespace": "skills",
                    "path": "/tmp/source/skills/demo/SKILL.md",
                    "relative_path": "skills/demo/SKILL.md",
                    "content": "# Demo Skill\n",
                },
            ],
            indent=2,
        ),
        encoding="utf-8",
    )

    monkeypatch.setenv("HOME", str(tmp_path))
    result = runner.invoke(
        app,
        [
            "resume",
            str(process_path),
            "--target",
            "codex-cli",
            "--workspace",
            str(workspace),
            "--json",
        ],
    )

    assert result.exit_code == 0, result.output
    payload = json.loads(result.stdout)
    assert payload["mode"] == "native"
    assert payload["skills_import"]["namespace"] == "skills"
    assert len(payload["skills_import"]["applied_files"]) == 1
    assert len(payload["skills_import"]["skipped_files"]) == 1
    imported_skill = workspace / ".codex" / "skills" / "anyfs-imports" / "claude-code" / "skills" / "demo" / "SKILL.md"
    assert imported_skill.exists()
    assert imported_skill.read_text(encoding="utf-8") == "# Demo Skill\n"
    assert "codex resume" in payload["target_open_hint"]
    assert "Imported skills into .codex/skills/anyfs-imports/claude-code" in payload["target_open_hint"]


def test_resume_cli_context_only_rejects_multiple_canonical_sessions(tmp_path: Path) -> None:
    runner = CliRunner()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    transcript = _sample_transcript()
    bundle_path = tmp_path / "process.json"
    bundle_path.write_text(
        json.dumps(
            [
                {"canonical_transcript": transcript.model_dump(mode="json")},
                {"canonical_transcript": transcript.model_dump(mode="json")},
            ]
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        ["resume", str(bundle_path), "--target", "cursor", "--workspace", str(workspace), "--context-only"],
    )
    assert result.exit_code != 0
    assert "context-only resume requires exactly one transcript" in result.output
