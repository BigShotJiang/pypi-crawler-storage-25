"""Unit tests for anyfs_adapter_openclaw package."""
from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapter_openclaw import OpenClawAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_openclaw_session(openclaw_home: Path, workspace: Path, session_id: str = "session-1") -> Path:
    sessions_dir = openclaw_home / "agents" / "main" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    session_path = sessions_dir / f"{session_id}.jsonl"
    session_path.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "type": "session",
                        "version": 3,
                        "id": session_id,
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "cwd": str(workspace.resolve()),
                    }
                ),
                json.dumps(
                    {
                        "type": "message",
                        "id": "u1",
                        "parentId": None,
                        "timestamp": "2026-04-09T12:00:00+00:00",
                        "message": {
                            "role": "user",
                            "content": [{"type": "text", "text": "Inspect current status"}],
                            "timestamp": 1775736000000,
                        },
                    }
                ),
                json.dumps(
                    {
                        "type": "message",
                        "id": "a1",
                        "parentId": "u1",
                        "timestamp": "2026-04-09T12:00:01+00:00",
                        "message": {
                            "role": "assistant",
                            "content": [
                                {
                                    "type": "text",
                                    "text": "[Thinking]\nScanning session state\n\n[Tool: shell] git status\nclean\n\nReady.",
                                }
                            ],
                            "model": "gpt-5.4",
                        },
                    }
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    (sessions_dir / "sessions.json").write_text(
        json.dumps({"agent:main:resume:session-1": {"sessionId": session_id}}, indent=2),
        encoding="utf-8",
    )
    return session_path


class TestDiscover:
    def test_finds_matching_openclaw_sessions(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        openclaw_home = tmp_path / "openclaw-home"
        session_path = _write_openclaw_session(openclaw_home, workspace)
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter()
        files = adapter.discover(str(workspace))

        assert session_path in files
        assert (session_path.parent / "sessions.json") not in files

    def test_all_scope_includes_store_file(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        openclaw_home = tmp_path / "openclaw-home"
        session_path = _write_openclaw_session(openclaw_home, workspace)
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter(process_scope="all")
        files = adapter.discover(str(workspace))

        assert session_path in files
        assert (session_path.parent / "sessions.json") in files

    def test_filters_out_other_workspace_sessions(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        other_workspace = tmp_path / "other"
        other_workspace.mkdir()
        openclaw_home = tmp_path / "openclaw-home"
        _write_openclaw_session(openclaw_home, other_workspace, session_id="other-session")
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter()
        files = adapter.discover(str(workspace))

        assert all("other-session" not in str(path) for path in files)


class TestExtract:
    def test_extracts_canonical_process_records(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        openclaw_home = tmp_path / "openclaw-home"
        session_path = _write_openclaw_session(openclaw_home, workspace)
        _write_file(openclaw_home, "openclaw.json", '{"model":"openai-codex/gpt-5.4"}')
        _write_file(openclaw_home, "agents/main/agent/auth-profiles.json", '{"auth":true}')
        _write_file(openclaw_home, "workspace/TOOLS.md", "# tools")
        _write_file(openclaw_home, "workspace/SOUL.md", "# soul")
        _write_file(openclaw_home, "workspace/skills/demo/SKILL.md", "# demo skill")
        _write_file(openclaw_home, "skills/global/SKILL.md", "# global skill")
        _write_file(openclaw_home, "workspace/.openclaw/workspace-state.json", '{"workspace":"state"}')
        _write_file(workspace, "memory/notes.md", "# memory")
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter()
        records = adapter.extract(str(workspace))

        process_records = [item for item in records if item["namespace"] == "process"]
        assert any(item["relative_path"].endswith(session_path.name) for item in process_records)
        transcript_record = next(item for item in process_records if item["relative_path"].endswith(session_path.name))
        assert "canonical_transcript" in transcript_record
        assert transcript_record["canonical_transcript"]["session"]["agent"] == "openclaw"
        assert "Inspect current status" in transcript_record["content"]
        assert any(item["namespace"] == "skills" and "TOOLS.md" in item["relative_path"] for item in records)
        assert any(item["namespace"] == "skills" and "skills/demo/SKILL.md" in item["relative_path"] for item in records)
        assert any(item["namespace"] == "skills" and "skills/global/SKILL.md" in item["relative_path"] for item in records)
        assert any(item["namespace"] == "soul" and item["relative_path"].endswith("SOUL.md") for item in records)
        assert all(not item["path"].endswith("openclaw.json") for item in records)
        assert all("auth-profiles.json" not in item["path"] for item in records)
        assert all("workspace-state.json" not in item["path"] for item in records)

    def test_defaults_to_current_session_only(self, tmp_path, monkeypatch):
        workspace = tmp_path / "workspace"
        workspace.mkdir()
        openclaw_home = tmp_path / "openclaw-home"
        older = _write_openclaw_session(openclaw_home, workspace, session_id="session-1")
        newer = _write_openclaw_session(openclaw_home, workspace, session_id="session-2")
        os.utime(older, (1, 1))
        os.utime(newer, (2, 2))
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter()
        process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
        transcript_records = [item for item in process_records if item["path"].endswith(".jsonl")]
        assert len(transcript_records) == 1
        assert transcript_records[0]["path"] == str(newer)

    def test_home_workspace_can_fall_back_to_latest_global_session(self, tmp_path, monkeypatch):
        openclaw_home = tmp_path / "openclaw-home"
        home_workspace = openclaw_home / "workspace"
        home_workspace.mkdir(parents=True, exist_ok=True)
        actual_workspace = tmp_path / "project"
        actual_workspace.mkdir()
        older = _write_openclaw_session(openclaw_home, actual_workspace, session_id="session-1")
        newer = _write_openclaw_session(openclaw_home, actual_workspace, session_id="session-2")
        sessions_dir = newer.parent
        (sessions_dir / "sessions.json").write_text(
            json.dumps(
                {
                    "agent:main:resume:session-1": {"sessionId": "session-1", "updatedAt": 1},
                    "agent:main:resume:session-2": {"sessionId": "session-2", "updatedAt": 2},
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        os.utime(older, (1, 1))
        os.utime(newer, (2, 2))
        monkeypatch.setenv("OPENCLAW_HOME", str(openclaw_home))

        adapter = OpenClawAdapter()
        process_records = [item for item in adapter.extract(str(home_workspace)) if item["namespace"] == "process"]
        transcript_records = [item for item in process_records if item["path"].endswith(".jsonl")]
        assert len(transcript_records) == 1
        assert transcript_records[0]["path"] == str(newer)


class TestNormalize:
    def test_groups_by_namespace(self):
        adapter = OpenClawAdapter()
        raw = [
            {"namespace": "soul", "content": "a"},
            {"namespace": "memory", "content": "b"},
            {"namespace": "soul", "content": "c"},
        ]
        result = adapter.normalize(raw)
        assert len(result["soul"]) == 2
        assert len(result["memory"]) == 1


class TestBundle:
    def test_creates_capture_result(self):
        adapter = OpenClawAdapter()
        normalized = {"soul": [{"content": "data"}], "process": [{"content": "notes"}]}
        result = adapter.bundle(normalized)
        assert isinstance(result, CaptureResult)
        assert result.ok is True
        assert result.agent_id == "pending"
        assert result.agent_type == "openclaw"
        assert set(result.captured_namespaces) == {"soul", "process"}
        assert result.warnings == []

    def test_agent_type(self):
        adapter = OpenClawAdapter()
        assert adapter.agent_type == AgentType.OPENCLAW
