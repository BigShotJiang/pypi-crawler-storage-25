from __future__ import annotations

import json
from pathlib import Path

from anyfs_adapter_nanobot import NanobotAdapter
from anyfs_schemas import AgentType, CaptureResult


def _write_file(root: Path, rel: str, content: str) -> Path:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _write_nanobot_session(workspace: Path, session_key: str, prompt: str, updated_at: str) -> Path:
    path = workspace / "sessions" / f"{session_key.replace(':', '_')}.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "_type": "metadata",
                        "key": session_key,
                        "created_at": "2026-04-09T12:00:00",
                        "updated_at": updated_at,
                        "metadata": {},
                        "last_consolidated": 0,
                    }
                ),
                json.dumps({"role": "user", "content": prompt, "timestamp": "2026-04-09T12:00:00"}),
                json.dumps({"role": "assistant", "content": "OK", "timestamp": "2026-04-09T12:00:01"}),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return path


def test_nanobot_adapter_discovers_and_extracts_personal_workspace_state(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    nanobot_home = tmp_path / "nanobot-home"
    nanobot_workspace = nanobot_home / "workspace"

    _write_file(nanobot_workspace, "SOUL.md", "# soul")
    _write_file(nanobot_workspace, "USER.md", "# user")
    _write_file(nanobot_workspace, "AGENTS.md", "# instructions")
    _write_file(nanobot_workspace, "HEARTBEAT.md", "- [ ] check status")
    _write_file(nanobot_workspace, "TOOLS.md", "# tools")
    _write_file(nanobot_workspace, "memory/MEMORY.md", "# memory")
    _write_file(nanobot_workspace, "memory/history.jsonl", '{"cursor":1,"content":"summary"}\n')
    session_path = _write_nanobot_session(nanobot_workspace, "cli:direct", "Reply with OK", "2026-04-09T12:00:02")
    _write_file(nanobot_workspace, "skills/demo/SKILL.md", "# local skill")
    _write_file(workspace, ".nanobot/local.md", "# local hidden")
    _write_file(nanobot_home, "skills/global/SKILL.md", "# home skill")
    _write_file(nanobot_home, "config.json", '{"providers":{}}')
    monkeypatch.setenv("NANOBOT_HOME", str(nanobot_home))

    adapter = NanobotAdapter()
    files = adapter.discover(str(workspace))
    assert all(path.name != "config.json" for path in files)
    assert any(path.name == "HEARTBEAT.md" for path in files)
    assert any(path.name == "history.jsonl" for path in files)
    assert session_path in files
    assert all(".nanobot/local.md" not in str(path) for path in files)
    assert all("nanobot-home/skills/global" not in str(path) for path in files)

    records = adapter.extract(str(workspace))
    namespaces = {item["namespace"] for item in records}
    assert {"soul", "user", "memory", "skills", "process"} <= namespaces
    assert any(item["relative_path"].startswith("skills/nanobot/global/workspace/skills") for item in records)
    assert any(item["relative_path"] == "skills/nanobot/global/workspace/TOOLS.md" for item in records)
    assert all(not item["path"].endswith("config.json") for item in records)
    assert all("nanobot-home/skills/global" not in item["path"] for item in records)
    process = next(item for item in records if item["namespace"] == "process")
    assert process["canonical_transcript"]["session"]["agent"] == "nanobot"
    assert "Reply with OK" in process["content"]


def test_nanobot_adapter_can_capture_all_sessions(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    nanobot_home = tmp_path / "nanobot-home"
    nanobot_workspace = nanobot_home / "workspace"
    _write_nanobot_session(nanobot_workspace, "cli:direct", "Older", "2026-04-09T12:00:01")
    _write_nanobot_session(nanobot_workspace, "cli:other", "Newer", "2026-04-09T12:00:02")
    monkeypatch.setenv("NANOBOT_HOME", str(nanobot_home))

    adapter = NanobotAdapter(process_scope="all")
    process_records = [item for item in adapter.extract(str(workspace)) if item["namespace"] == "process"]
    assert len(process_records) == 2


def test_nanobot_adapter_bundle_and_agent_type():
    adapter = NanobotAdapter()
    normalized = {"memory": [{"content": "memory"}], "skills": [{"content": "skill"}]}
    result = adapter.bundle(normalized)
    assert isinstance(result, CaptureResult)
    assert result.agent_type == AgentType.NANOBOT
    assert set(result.captured_namespaces) == {"memory", "skills"}
