from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any

from anyfs_schemas import AgentType, DoctorReport, utc_now_iso


GLOBAL_DEFAULTS = {
    "config.json": {
        "version": 1,
        "default_api_base_url": "https://api.anyfs.ai",
        "storage_gateway_url": "https://storage.anyfs.ai",
        "auth_token": None,
        "auth_email": None,
        "agent_token": None,
        "agent_token_agent_id": None,
    },
    "agents/registry.json": {"agents": []},
}

WORKSPACE_DEFAULTS = {
    "workspace.json": {"version": 1},
    "state/capture.json": {},
    "state/snapshot-head.json": {},
    "state/package-head.json": {},
    "state/snapshots.json": {"items": []},
    "state/backups.json": {"items": []},
    "state/links.json": {"items": []},
    "state/packages.json": {"items": []},
    "state/releases.json": {"items": []},
    "state/lineage.json": {"items": []},
}


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def read_json(path: Path, default: Any | None = None) -> Any:
    if not path.exists():
        return {} if default is None else default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def append_list_item(path: Path, item: dict[str, Any]) -> None:
    current = read_json(path, {"items": []})
    current.setdefault("items", []).append(item)
    write_json(path, current)


def upsert_list_item(path: Path, item: dict[str, Any], key: str) -> None:
    current = read_json(path, {"items": []})
    items = current.setdefault("items", [])
    for index, existing in enumerate(items):
        if existing.get(key) == item.get(key):
            items[index] = item
            write_json(path, current)
            return
    items.append(item)
    write_json(path, current)


def default_global_root(root: Path | None = None) -> Path:
    return (root or Path.home() / ".anyfs").resolve()


def default_workspace_root(workspace: str | Path) -> Path:
    return (Path(workspace).resolve() / ".anyfs")


def _ensure_global_db(global_root: Path) -> None:
    db_path = ensure_dir(global_root / "db") / "local.db"
    conn = sqlite3.connect(db_path)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS kv (namespace TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(namespace, key))"
    )
    conn.commit()
    conn.close()


def initialize_global_state(global_root: Path | None = None) -> dict[str, Any]:
    global_root = default_global_root(global_root)
    ensure_dir(global_root)
    ensure_dir(global_root / "keys")
    ensure_dir(global_root / "db")
    ensure_dir(global_root / "agents")
    ensure_dir(global_root / "cache")
    ensure_dir(global_root / "logs")
    ensure_dir(global_root / "adapters")
    _ensure_global_db(global_root)

    for rel_path, content in GLOBAL_DEFAULTS.items():
        file_path = global_root / rel_path
        if not file_path.exists():
            write_json(file_path, content)

    identity_path = global_root / "identity.json"
    if not identity_path.exists():
        identity = {
            "user_id": f"usr_{uuid.uuid4().hex[:12]}",
            "device_id": f"dev_{uuid.uuid4().hex[:12]}",
            "created_at": utc_now_iso(),
        }
        write_json(identity_path, identity)

    adapters_path = global_root / "adapters" / "config.yaml"
    if not adapters_path.exists():
        adapters_path.write_text("default_adapter: auto\n", encoding="utf-8")

    recovery_path = global_root / "keys" / "recovery.anyfs"
    if not recovery_path.exists():
        recovery_path.write_text("{}", encoding="utf-8")

    return {
        "global_root": str(global_root),
        "identity": read_json(identity_path),
    }


def initialize_workspace_state(workspace: str | Path, agent_type: AgentType | str | None = None) -> dict[str, Any]:
    workspace_path = Path(workspace).resolve()
    state_root = default_workspace_root(workspace_path)
    ensure_dir(state_root)
    ensure_dir(state_root / "state")
    ensure_dir(state_root / "agents")
    ensure_dir(state_root / "state" / "agent-remote")
    ensure_dir(state_root / "manifests")
    ensure_dir(state_root / "staging")
    ensure_dir(state_root / "exports")
    ensure_dir(state_root / "logs")

    for rel_path, content in WORKSPACE_DEFAULTS.items():
        file_path = state_root / rel_path
        if not file_path.exists():
            write_json(file_path, content)

    workspace_json = read_json(state_root / "workspace.json")
    workspace_json.update(
        {
            "workspace_path": str(workspace_path),
            "initialized_at": workspace_json.get("initialized_at") or utc_now_iso(),
            "default_adapter": agent_type or workspace_json.get("default_adapter") or "auto",
        }
    )
    write_json(state_root / "workspace.json", workspace_json)

    policy_path = state_root / "policy.yaml"
    if not policy_path.exists():
        policy_path.write_text(
            "visibility:\n  artifacts: public\n  default: private\nfork_policy: free\n",
            encoding="utf-8",
        )

    return {
        "workspace_root": str(state_root),
        "workspace": str(workspace_path),
        "default_adapter": workspace_json["default_adapter"],
    }


def _agent_slug(agent_type: AgentType | str) -> str:
    return (agent_type.value if isinstance(agent_type, AgentType) else str(agent_type)).strip()


def _global_agents_root(global_root: Path | None = None) -> Path:
    return default_global_root(global_root) / "agents"


def _global_agent_path(global_root: Path | None, agent_type: AgentType | str) -> Path:
    return _global_agents_root(global_root) / f"{_agent_slug(agent_type)}.json"


def _global_agent_key_path(global_root: Path | None, agent_type: AgentType | str) -> Path:
    return _global_agents_root(global_root) / f"{_agent_slug(agent_type)}.key"


def _global_agent_remote_state_path(global_root: Path | None, agent_type: AgentType | str) -> Path:
    return _global_agents_root(global_root) / "remote" / f"{_agent_slug(agent_type)}.json"


def _workspace_agent_path(workspace: str | Path, agent_type: AgentType | str) -> Path:
    return default_workspace_root(workspace) / "agents" / f"{_agent_slug(agent_type)}.json"


def _workspace_agent_key_path(workspace: str | Path, agent_type: AgentType | str) -> Path:
    return default_workspace_root(workspace) / "agents" / f"{_agent_slug(agent_type)}.key"


def _workspace_agent_remote_state_path(workspace: str | Path, agent_type: AgentType | str) -> Path:
    return default_workspace_root(workspace) / "state" / "agent-remote" / f"{_agent_slug(agent_type)}.json"


def list_registered_agents(global_root: Path | None = None) -> list[dict[str, Any]]:
    registry = read_json(_global_agents_root(global_root) / "registry.json", {"agents": []})
    return registry.get("agents", [])


def global_agent(global_root: Path | None, agent_type: AgentType | str) -> dict[str, Any]:
    path = _global_agent_path(global_root, agent_type)
    if path.exists():
        return read_json(path, {})
    return {}


def global_agent_private_key(global_root: Path | None, agent_type: AgentType | str) -> str | None:
    key_path = _global_agent_key_path(global_root, agent_type)
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip()
    return None


def register_agent(global_root: Path | None, workspace: str | Path, agent_type: AgentType | str, username: str | None = None) -> dict[str, Any]:
    from anyfs_crypto import generate_agent_keypair

    global_state = initialize_global_state(global_root)
    workspace_state = initialize_workspace_state(workspace, agent_type)
    identity = global_state["identity"]
    agent_type_value = agent_type.value if isinstance(agent_type, AgentType) else agent_type
    existing = global_agent(global_root, agent_type_value)
    if existing:
        return existing

    # Generate Ed25519 key pair — DID becomes the agent_id
    keypair = generate_agent_keypair()

    record = {
        "agent_id": keypair["did"],
        "owner_user_id": identity["user_id"],
        "agent_type": agent_type_value,
        "username": username or f"{agent_type_value}-{Path(workspace).resolve().name}",
        "public_key": keypair["public_key"],
        "created_at": utc_now_iso(),
        "head_snapshot_id": None,
    }

    # Store private key separately (never leaves this device)
    key_path = _global_agent_key_path(global_root, agent_type_value)
    ensure_dir(key_path.parent)
    key_path.write_text(keypair["private_key"], encoding="utf-8")
    key_path.chmod(0o600)

    write_json(_global_agent_path(global_root, agent_type_value), record)

    registry = read_json(Path(global_state["global_root"]) / "agents" / "registry.json", {"agents": []})
    agents = [
        item for item in registry.get("agents", [])
        if item.get("agent_type") != record["agent_type"]
    ]
    agents.append(record)
    registry["agents"] = agents
    write_json(Path(global_state["global_root"]) / "agents" / "registry.json", registry)
    return record


def rename_agent(global_root: Path | None, workspace: str | Path, agent_type: AgentType | str, nickname: str) -> dict[str, Any]:
    global_state = initialize_global_state(global_root)
    initialize_workspace_state(workspace, agent_type)
    agent_type_value = agent_type.value if isinstance(agent_type, AgentType) else agent_type
    record = global_agent(global_root, agent_type_value)
    if not record:
        raise KeyError(f"agent not registered for {agent_type_value}")
    record["username"] = nickname
    write_json(_global_agent_path(global_root, agent_type_value), record)

    registry_path = Path(global_state["global_root"]) / "agents" / "registry.json"
    registry = read_json(registry_path, {"agents": []})
    updated_agents = []
    matched = False
    for item in registry.get("agents", []):
        if item.get("agent_type") == agent_type_value:
            item = {**item, "username": nickname}
            matched = True
        updated_agents.append(item)
    if not matched:
        updated_agents.append(record)
    registry["agents"] = updated_agents
    write_json(registry_path, registry)
    return record


def read_config(global_root: Path | None = None) -> dict[str, Any]:
    return read_json(default_global_root(global_root) / "config.json", GLOBAL_DEFAULTS["config.json"])


def write_config(global_root: Path | None, payload: dict[str, Any]) -> None:
    write_json(default_global_root(global_root) / "config.json", payload)


def read_agent_remote_state(
    workspace: str | Path,
    agent_type: AgentType | str | None = None,
    global_root: Path | None = None,
) -> dict[str, Any]:
    if agent_type is not None:
        path = _global_agent_remote_state_path(global_root, agent_type)
        if path.exists():
            return read_json(path, {})
        path = _workspace_agent_remote_state_path(workspace, agent_type)
        if path.exists():
            return read_json(path, {})
    return read_json(default_workspace_root(workspace) / "state" / "agent-remote.json", {})


def write_agent_remote_state(
    workspace: str | Path,
    payload: dict[str, Any],
    agent_type: AgentType | str | None = None,
    global_root: Path | None = None,
) -> None:
    if agent_type is None:
        inferred = workspace_agent(workspace, agent_type=None, global_root=global_root)
        agent_type = inferred.get("agent_type")
    if agent_type is not None:
        write_json(_global_agent_remote_state_path(global_root, agent_type), payload)
        return
    write_json(default_workspace_root(workspace) / "state" / "agent-remote.json", payload)


def record_capture(workspace: str | Path, capture_payload: dict[str, Any]) -> None:
    workspace_root = default_workspace_root(workspace)
    write_json(workspace_root / "state" / "capture.json", capture_payload)


def latest_capture(workspace: str | Path) -> dict[str, Any]:
    return read_json(default_workspace_root(workspace) / "state" / "capture.json", {})


def append_snapshot(workspace: str | Path, snapshot_payload: dict[str, Any]) -> None:
    workspace_root = default_workspace_root(workspace)
    upsert_list_item(workspace_root / "state" / "snapshots.json", snapshot_payload, "snapshot_id")
    write_json(workspace_root / "state" / "snapshot-head.json", {"snapshot_id": snapshot_payload["snapshot_id"]})


def list_snapshots(workspace: str | Path) -> list[dict[str, Any]]:
    workspace_root = default_workspace_root(workspace)
    return read_json(workspace_root / "state" / "snapshots.json", {"items": []}).get("items", [])


def latest_snapshot_id(workspace: str | Path) -> str | None:
    workspace_root = default_workspace_root(workspace)
    return read_json(workspace_root / "state" / "snapshot-head.json", {}).get("snapshot_id")


def append_package(workspace: str | Path, package_payload: dict[str, Any]) -> None:
    workspace_root = default_workspace_root(workspace)
    upsert_list_item(workspace_root / "state" / "packages.json", package_payload, "package_id")
    write_json(workspace_root / "state" / "package-head.json", {"package_id": package_payload["package_id"]})


def list_packages(workspace: str | Path) -> list[dict[str, Any]]:
    workspace_root = default_workspace_root(workspace)
    return read_json(workspace_root / "state" / "packages.json", {"items": []}).get("items", [])


def append_release(workspace: str | Path, release_payload: dict[str, Any]) -> None:
    upsert_list_item(default_workspace_root(workspace) / "state" / "releases.json", release_payload, "release_id")


def list_releases(workspace: str | Path) -> list[dict[str, Any]]:
    return read_json(default_workspace_root(workspace) / "state" / "releases.json", {"items": []}).get("items", [])


def append_lineage(workspace: str | Path, lineage_payload: dict[str, Any]) -> None:
    append_list_item(default_workspace_root(workspace) / "state" / "lineage.json", lineage_payload)


def lineage_for_package(workspace: str | Path, package_id: str) -> list[dict[str, Any]]:
    items = read_json(default_workspace_root(workspace) / "state" / "lineage.json", {"items": []}).get("items", [])
    return [item for item in items if item.get("parent_package_id") == package_id or item.get("child_package_id") == package_id]


def workspace_agent(
    workspace: str | Path,
    agent_type: AgentType | str | None = None,
    global_root: Path | None = None,
) -> dict[str, Any]:
    if agent_type is not None:
        agent = global_agent(global_root, agent_type)
        if agent:
            return agent
        agent_path = _workspace_agent_path(workspace, agent_type)
        if agent_path.exists():
            return read_json(agent_path, {})
        return {}
    agents = list_registered_agents(global_root)
    if len(agents) == 1:
        return agents[0]
    return read_json(default_workspace_root(workspace) / "agent.json", {})


def workspace_agent_private_key(
    workspace: str | Path,
    agent_type: AgentType | str | None = None,
    global_root: Path | None = None,
) -> str | None:
    if agent_type is None:
        default_agent = workspace_agent(workspace, agent_type=None, global_root=global_root)
        agent_type = default_agent.get("agent_type")
    if agent_type is not None:
        key = global_agent_private_key(global_root, agent_type)
        if key:
            return key
        key_path = _workspace_agent_key_path(workspace, agent_type)
        if key_path.exists():
            return key_path.read_text(encoding="utf-8").strip()
    key_path = default_workspace_root(workspace) / "agent.key"
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip()
    return None


def workspace_agent_by_id(workspace: str | Path, agent_id: str, global_root: Path | None = None) -> dict[str, Any]:
    registry = {"agents": list_registered_agents(global_root)}
    for item in registry.get("agents", []):
        if item.get("agent_id") == agent_id:
            return item
    registry = read_json(default_workspace_root(workspace) / "agents" / "registry.json", {"agents": []})
    for item in registry.get("agents", []):
        if item.get("agent_id") == agent_id:
            return item
    agent = read_json(default_workspace_root(workspace) / "agent.json", {})
    if agent.get("agent_id") == agent_id:
        return agent
    return {}


def write_manifest(workspace: str | Path, snapshot_id: str, manifest: dict[str, Any]) -> Path:
    manifest_path = default_workspace_root(workspace) / "manifests" / f"{snapshot_id}.json"
    write_json(manifest_path, manifest)
    return manifest_path


def read_manifest(workspace: str | Path, snapshot_id: str) -> dict[str, Any]:
    return read_json(default_workspace_root(workspace) / "manifests" / f"{snapshot_id}.json", {})


def append_backup(workspace: str | Path, backup_payload: dict[str, Any]) -> None:
    upsert_list_item(default_workspace_root(workspace) / "state" / "backups.json", backup_payload, "backup_id")


def list_backups(workspace: str | Path) -> list[dict[str, Any]]:
    return read_json(default_workspace_root(workspace) / "state" / "backups.json", {"items": []}).get("items", [])


def append_link(workspace: str | Path, link_payload: dict[str, Any]) -> None:
    upsert_list_item(default_workspace_root(workspace) / "state" / "links.json", link_payload, "link_id")


def list_links(workspace: str | Path) -> list[dict[str, Any]]:
    return read_json(default_workspace_root(workspace) / "state" / "links.json", {"items": []}).get("items", [])


def doctor(global_root: Path | None, workspace: str | Path | None = None) -> DoctorReport:
    global_root = default_global_root(global_root)
    registered_agents = list_registered_agents(global_root)
    checks = {
        "global_root_exists": global_root.exists(),
        "identity_exists": (global_root / "identity.json").exists(),
        "root_key_exists": (global_root / "keys" / "rootkey.enc").exists(),
        "registry_exists": (global_root / "agents" / "registry.json").exists(),
        "sqlite_exists": (global_root / "db" / "local.db").exists(),
        "registered_agent_exists": bool(registered_agents),
    }
    warnings: list[str] = []
    if workspace:
        workspace_root = default_workspace_root(workspace)
        checks.update(
            {
                "workspace_root_exists": workspace_root.exists(),
                "capture_state_exists": (workspace_root / "state" / "capture.json").exists(),
            }
        )
    if not checks["registered_agent_exists"]:
        warnings.append("no AnyFS agent is registered on this machine")
    required = {key: value for key, value in checks.items() if key != "registered_agent_exists"}
    return DoctorReport(ok=all(required.values()), checks=checks, warnings=warnings)
