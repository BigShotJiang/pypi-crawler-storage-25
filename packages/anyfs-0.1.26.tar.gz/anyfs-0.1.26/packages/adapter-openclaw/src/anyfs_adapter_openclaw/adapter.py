from __future__ import annotations

import json
import os
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file, select_best_path_by_current_session_hint
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_OPENCLAW_HOME = ".openclaw"
_OPENCLAW_EXCLUDED_CONTEXT_FILES = {"openclaw.json", "workspace-state.json"}


def _openclaw_home() -> Path:
    return Path(os.environ.get("OPENCLAW_HOME", Path.home() / _DEFAULT_OPENCLAW_HOME)).expanduser()


def _openclaw_workspace() -> Path:
    return (_openclaw_home() / "workspace").resolve()


def _openclaw_skill_files() -> list[Path]:
    root = _openclaw_home()
    workspace_root = _openclaw_workspace()
    candidates: list[Path] = []
    for direct in (
        workspace_root / "AGENTS.md",
        workspace_root / "TOOLS.md",
        workspace_root / "SOUL.md",
        workspace_root / "USER.md",
    ):
        append_unique(candidates, direct)
    for directory in (workspace_root / "memory",):
        for path in collect_text_files(directory, max_files=120, exclude_names=_OPENCLAW_EXCLUDED_CONTEXT_FILES):
            append_unique(candidates, path)
    for directory in (workspace_root / "skills",):
        for path in collect_text_files(directory, max_files=120, exclude_names=_OPENCLAW_EXCLUDED_CONTEXT_FILES):
            append_unique(candidates, path)
    for directory in (root / "skills",):
        for path in collect_text_files(directory, max_files=120, exclude_names=_OPENCLAW_EXCLUDED_CONTEXT_FILES):
            append_unique(candidates, path)
    return candidates[:200]


def _session_header_matches_workspace(path: Path, workspace_path: Path) -> bool:
    try:
        first_line = path.read_text(encoding="utf-8").split("\n", 1)[0]
        payload = json.loads(first_line)
    except (OSError, json.JSONDecodeError):
        return False
    cwd = payload.get("cwd")
    return isinstance(cwd, str) and Path(cwd).resolve() == workspace_path


def _is_openclaw_home_workspace(workspace_path: Path) -> bool:
    return workspace_path == (_openclaw_home() / "workspace").resolve()


def _load_openclaw_store(sessions_dir: Path) -> dict:
    store_file = sessions_dir / "sessions.json"
    if not store_file.is_file():
        return {}
    try:
        payload = json.loads(store_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def _store_matching_ids(store_payload: dict, workspace_matches: list[Path]) -> dict[str, dict]:
    by_id = {path.stem: path for path in workspace_matches}
    matched: dict[str, dict] = {}
    for session_key, entry in store_payload.items():
        if not isinstance(entry, dict):
            continue
        session_id = entry.get("sessionId")
        if isinstance(session_id, str) and session_id in by_id:
            matched[str(session_key)] = entry
    return matched


def _openclaw_process_files(workspace_path: Path, process_scope: str = "current") -> list[Path]:
    root = _openclaw_home()
    agents_dir = root / "agents"
    if not agents_dir.exists():
        return []

    candidates: list[Path] = []
    newest_session: Path | None = None
    newest_sort_key: tuple[int, float] = (-1, -1.0)
    home_workspace = _is_openclaw_home_workspace(workspace_path)
    for agent_dir in agents_dir.iterdir():
        if not agent_dir.is_dir():
            continue
        sessions_dir = agent_dir / "sessions"
        if not sessions_dir.exists():
            continue
        all_sessions = sorted(sessions_dir.glob("*.jsonl"), key=lambda item: item.stat().st_mtime, reverse=True)
        matching_sessions: list[Path] = []
        for session_file in all_sessions:
            if _session_header_matches_workspace(session_file, workspace_path):
                matching_sessions.append(session_file)
        candidate_sessions = matching_sessions or (all_sessions if home_workspace else [])
        if not candidate_sessions:
            continue
        store_payload = _load_openclaw_store(sessions_dir)
        store_matches = _store_matching_ids(store_payload, candidate_sessions)
        if process_scope == "all":
            candidates.extend(candidate_sessions[:20])
            store_file = sessions_dir / "sessions.json"
            if store_file.is_file():
                candidates.append(store_file)
            continue

        session = candidate_sessions[0]
        if store_matches:
            ranked = sorted(
                (
                    (
                        int(entry.get("updatedAt", -1)),
                        next((path for path in candidate_sessions if path.stem == entry.get("sessionId")), None),
                    )
                    for entry in store_matches.values()
                ),
                key=lambda item: item[0],
                reverse=True,
            )
            ranked_path = next((path for _, path in ranked if path is not None), None)
            if ranked_path is not None:
                session = ranked_path
                sort_key = (ranked[0][0], session.stat().st_mtime)
            else:
                sort_key = (-1, session.stat().st_mtime)
        else:
            sort_key = (-1, session.stat().st_mtime)

        if newest_session is None or sort_key > newest_sort_key:
            newest_session = session
            newest_sort_key = sort_key
    if process_scope == "all":
        return candidates
    return [newest_session] if newest_session is not None else []


class OpenClawAdapter(AgentAdapter):
    agent_type = AgentType.OPENCLAW

    def __init__(self, process_scope: str = "current", current_session_hint: dict | None = None) -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"
        self.current_session_hint = current_session_hint

    def discover(self, workspace: str) -> list[Path]:
        workspace_path = Path(workspace).resolve()
        process_files = _openclaw_process_files(workspace_path, self.process_scope)
        if self.process_scope == "current":
            hinted = select_best_path_by_current_session_hint(
                process_files,
                agent_type="openclaw",
                hint=self.current_session_hint,
            )
            process_files = [hinted] if hinted is not None else process_files[:1]
        candidates = process_files
        for path in _openclaw_skill_files():
            if path not in candidates:
                candidates.append(path)
        return candidates[:100]

    def extract(self, workspace: str) -> list[dict]:
        workspace_path = Path(workspace).resolve()
        openclaw_home = _openclaw_home()
        records = []
        for path in self.discover(workspace):
            if path.suffix == ".jsonl" and path.parent.name == "sessions":
                try:
                    canonical = parse_transcript(path, agent_type="openclaw")
                    content = render_markdown(canonical)
                    relative = f"process/openclaw/{path.parent.parent.name}/{path.name}"
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": relative,
                            "namespace": "process",
                            "content": content,
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass
            if path.name == "sessions.json" and path.parent.name == "sessions":
                records.append(
                    {
                        "path": str(path),
                        "relative_path": f"process/openclaw/{path.parent.parent.name}/{path.name}",
                        "namespace": "process",
                        "content": read_text_file(path),
                    }
                )
                continue

            workspace_root = _openclaw_workspace()
            if path.is_relative_to(openclaw_home):
                relative = str(path.relative_to(openclaw_home))
                relative_lower = relative.lower()
                name_lower = path.name.lower()
                path_parts = {part.lower() for part in Path(relative).parts[:-1]}
            else:
                relative = str(path.relative_to(workspace_path))
                relative_lower = relative.lower()
                name_lower = path.name.lower()
                path_parts = {part.lower() for part in Path(relative).parts[:-1]}
            if "soul" in name_lower or "soul" in relative_lower:
                namespace = "soul"
            elif name_lower == "user.md":
                namespace = "user"
            elif "memory" in path_parts or "memory" in name_lower or "session" in name_lower:
                namespace = "memory"
            elif "process" in path_parts or "logs" in path_parts or "log" in name_lower:
                namespace = "process"
            elif (
                name_lower in {"agents.md", "tools.md"}
                or path.is_relative_to(workspace_root / "skills")
                or path.is_relative_to(openclaw_home / "skills")
            ):
                namespace = "skills"
            else:
                namespace = "artifacts"
            records.append(
                {
                    "path": str(path),
                    "relative_path": (
                        f"{namespace}/openclaw/global/{relative}"
                        if path.is_relative_to(openclaw_home)
                        else relative
                    ),
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no OpenClaw files were discovered"],
        )
