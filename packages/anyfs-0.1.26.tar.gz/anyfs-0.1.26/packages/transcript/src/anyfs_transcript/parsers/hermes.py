from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    TranscriptSessionMeta,
    UserMessageEvent,
)

_PREVIEW_LIMIT = 500


class HermesParser:
    agent_type = "hermes"

    def can_parse(self, path: Path) -> bool:
        if not path.is_file() or path.suffix not in {".jsonl", ".json"}:
            return False
        try:
            messages = _load_messages(path)
        except (OSError, json.JSONDecodeError):
            return False
        if not messages:
            return False
        first = messages[0]
        return (
            path.parent.name == "sessions"
            and ".hermes" in path.as_posix()
            or first.get("role") in {"user", "assistant", "tool", "system", "session_meta", "transcript_note"}
        )

    def parse(self, path: Path) -> CanonicalTranscript:
        messages = _load_messages(path)
        session_id = _session_id_for_path(path)
        started_at = _session_started_at(path, messages)
        ended_at = _session_ended_at(path, messages)

        session = TranscriptSessionMeta(
            id=session_id,
            agent="hermes",
            started_at=started_at,
            ended_at=ended_at,
        )
        events = _messages_to_events(messages)
        return CanonicalTranscript(session=session, events=events)


def _load_messages(path: Path) -> list[dict[str, Any]]:
    if path.suffix == ".json":
        payload = json.loads(path.read_text(encoding="utf-8"))
        messages = payload.get("messages", []) if isinstance(payload, dict) else []
        return [item for item in messages if isinstance(item, dict)]

    messages: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(payload, dict):
            messages.append(payload)
    return messages


def _session_id_for_path(path: Path) -> str:
    if path.suffix == ".json" and path.name.startswith("session_"):
        return path.stem.removeprefix("session_")
    return path.stem


def _session_started_at(path: Path, messages: list[dict[str, Any]]) -> datetime:
    if path.suffix == ".json":
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            payload = {}
        raw = payload.get("session_start")
        if raw is not None:
            return _parse_ts(raw)
    return _parse_ts(messages[0].get("timestamp")) if messages else datetime.now(timezone.utc)


def _session_ended_at(path: Path, messages: list[dict[str, Any]]) -> datetime | None:
    if path.suffix == ".json":
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            payload = {}
        raw = payload.get("last_updated")
        if raw is not None:
            return _parse_ts(raw)
    return _parse_ts(messages[-1].get("timestamp")) if messages else None


def _messages_to_events(messages: list[dict[str, Any]]) -> list[Any]:
    events: list[Any] = []
    pending_calls: dict[str, Any] = {}
    for message in messages:
        role = message.get("role")
        ts = _parse_ts(message.get("timestamp"))
        if role == "user":
            text = _extract_text(message.get("content"))
            if text:
                events.append(UserMessageEvent(ts=ts, text=text))
            continue
        if role == "assistant":
            reasoning = str(message.get("reasoning", "")).strip()
            if reasoning:
                events.append(ThinkingEvent(ts=ts, text=reasoning))
            text = _extract_text(message.get("content"))
            if text:
                events.append(AssistantTextEvent(ts=ts, text=text))
            for call in message.get("tool_calls") or []:
                event = _tool_event_from_call(call, ts)
                if event is None:
                    continue
                call_id = call.get("id")
                if call_id:
                    pending_calls[str(call_id)] = event
                events.append(event)
            continue
        if role == "tool":
            call_id = str(message.get("tool_call_id") or "")
            preview = _truncate(_extract_text(message.get("content")))
            event = pending_calls.pop(call_id, None)
            if isinstance(event, ShellCommandEvent):
                event.output_preview = preview
            elif isinstance(event, FileReadEvent):
                event.content_preview = preview
            elif isinstance(event, FileEditEvent):
                event.diff = preview
            elif isinstance(event, FileWriteEvent):
                event.content_preview = preview
            elif isinstance(event, CodeSearchEvent):
                event.result_preview = preview
            elif preview:
                events.append(AssistantTextEvent(ts=ts, text=f"[Tool result] {preview}"))
    return events


def _tool_event_from_call(call: dict[str, Any], ts: datetime) -> Any:
    function = call.get("function") or {}
    name = str(function.get("name") or call.get("name") or "").lower()
    arguments = function.get("arguments") or {}
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            arguments = {"raw": arguments}
    if name in {"shell", "bash", "exec", "run_command"}:
        return ShellCommandEvent(ts=ts, command=arguments.get("command", "") or str(arguments), meta={"tool_call_id": call.get("id")})
    if name in {"read", "read_file"}:
        return FileReadEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""))
    if name in {"edit", "edit_file"}:
        return FileEditEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""), diff=arguments.get("diff"))
    if name in {"write", "write_file"}:
        return FileWriteEvent(ts=ts, path=arguments.get("path", "") or arguments.get("file_path", ""))
    if name in {"search", "grep", "glob", "codesearch"}:
        return CodeSearchEvent(ts=ts, tool_name=name, query=arguments.get("query", "") or str(arguments))
    return AssistantTextEvent(ts=ts, text=f"[Tool: {name}] {json.dumps(arguments, ensure_ascii=False)}")


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(part for part in parts if part).strip()
    return ""


def _parse_ts(raw: Any) -> datetime:
    if raw is None:
        return datetime.now(timezone.utc)
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            return datetime.now(timezone.utc)
    if isinstance(raw, (int, float)):
        return datetime.fromtimestamp(raw, tz=timezone.utc)
    return datetime.now(timezone.utc)


def _truncate(text: str, limit: int = _PREVIEW_LIMIT) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "..."
