"""Export a CanonicalTranscript to Gemini CLI's native JSON format."""
from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)

_DEFAULT_GEMINI_DIR_NAME = ".gemini"
_PROJECT_ROOT_FILE = ".project_root"


@dataclass
class _GeminiMessageAccumulator:
    timestamp: str
    content_parts: list[str]
    thoughts: list[dict[str, str]]
    tool_calls: list[dict[str, Any]]

    def has_content(self) -> bool:
        return bool(self.content_parts or self.thoughts or self.tool_calls)


def export_gemini_cli(
    transcript: CanonicalTranscript,
    workspace: str,
    session_id: str | None = None,
) -> dict[str, str]:
    """Export a canonical transcript as a Gemini CLI native session."""
    workspace_path = Path(workspace).resolve()
    now = datetime.now(timezone.utc)
    started_at = transcript.session.started_at or _latest_event_ts(transcript) or now
    last_updated = transcript.session.ended_at or _latest_event_ts(transcript) or now
    session_id = session_id or str(uuid.uuid4())

    registry = _GeminiProjectRegistry(_gemini_home())
    project_id = registry.get_short_id(workspace_path)

    chats_dir = registry.chats_dir(project_id)
    chats_dir.mkdir(parents=True, exist_ok=True)

    conversation = {
        "sessionId": session_id,
        "projectHash": _project_hash(workspace_path),
        "startTime": started_at.isoformat(),
        "lastUpdated": last_updated.isoformat(),
        "messages": _build_messages(transcript, last_updated, model=transcript.session.model),
        "kind": "main",
    }

    filename = f"session-{started_at.strftime('%Y-%m-%dT%H-%M')}-{session_id[:8]}.json"
    session_path = chats_dir / filename
    session_path.write_text(json.dumps(conversation, indent=2, default=str), encoding="utf-8")

    return {
        "transcript": str(session_path),
        "session_id": session_id,
        "project_id": project_id,
        "resume_hint": f"gemini --resume {session_id}",
    }


def _build_messages(
    transcript: CanonicalTranscript,
    fallback_ts: datetime,
    model: str | None,
) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    assistant: _GeminiMessageAccumulator | None = None

    def ensure_assistant(ts: str) -> _GeminiMessageAccumulator:
        nonlocal assistant
        if assistant is None:
            assistant = _GeminiMessageAccumulator(ts, [], [], [])
        return assistant

    def flush_assistant() -> None:
        nonlocal assistant
        if assistant is None or not assistant.has_content():
            assistant = None
            return
        message: dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "timestamp": assistant.timestamp,
            "type": "gemini",
            "content": "\n\n".join(part for part in assistant.content_parts if part).strip(),
            "model": model or "unknown",
        }
        if assistant.thoughts:
            message["thoughts"] = assistant.thoughts
        if assistant.tool_calls:
            message["toolCalls"] = assistant.tool_calls
        messages.append(message)
        assistant = None

    for event in transcript.events:
        ts = _event_ts(event, fallback_ts).isoformat()
        if isinstance(event, UserMessageEvent):
            flush_assistant()
            messages.append(
                {
                    "id": str(uuid.uuid4()),
                    "timestamp": ts,
                    "type": "user",
                    "content": event.text,
                }
            )
            continue

        current = ensure_assistant(ts)
        if isinstance(event, AssistantTextEvent):
            if event.text:
                current.content_parts.append(event.text)
        elif isinstance(event, ThinkingEvent):
            text = (event.text or "").strip()
            if text:
                current.thoughts.append(
                    {
                        "subject": "reasoning",
                        "description": text,
                        "timestamp": ts,
                    }
                )
        elif isinstance(event, ShellCommandEvent):
            current.tool_calls.append(
                _tool_call(
                    name="shell",
                    args={"command": event.command},
                    result=event.output_preview or "",
                    status="error" if event.exit_code not in (None, 0) else "success",
                    timestamp=ts,
                )
            )
        elif isinstance(event, FileReadEvent):
            current.tool_calls.append(
                _tool_call(
                    name="read_file",
                    args={"path": event.path},
                    result=event.content_preview or "",
                    status="success",
                    timestamp=ts,
                )
            )
        elif isinstance(event, FileEditEvent):
            current.tool_calls.append(
                _tool_call(
                    name="edit_file",
                    args={"path": event.path},
                    result=event.diff or "ok",
                    status="success",
                    timestamp=ts,
                )
            )
        elif isinstance(event, FileWriteEvent):
            current.tool_calls.append(
                _tool_call(
                    name="write_file",
                    args={"path": event.path},
                    result=event.content_preview or "ok",
                    status="success",
                    timestamp=ts,
                )
            )
        elif isinstance(event, CodeSearchEvent):
            current.tool_calls.append(
                _tool_call(
                    name="search",
                    args={"query": event.query},
                    result=event.result_preview or "",
                    status="success",
                    timestamp=ts,
                )
            )
        elif isinstance(event, ErrorEvent):
            current.content_parts.append(f"[Error] {event.message}")
        else:
            current.content_parts.append(f"[{event.kind}]")

    flush_assistant()
    return messages


def _tool_call(
    name: str,
    args: dict[str, Any],
    result: str,
    status: str,
    timestamp: str,
) -> dict[str, Any]:
    return {
        "id": str(uuid.uuid4()),
        "name": name,
        "args": args,
        "result": result,
        "status": status,
        "timestamp": timestamp,
    }


def _event_ts(event: Any, fallback: datetime) -> datetime:
    return getattr(event, "ts", None) or fallback


def _latest_event_ts(transcript: CanonicalTranscript) -> datetime | None:
    if not transcript.events:
        return None
    return max((_event_ts(event, transcript.session.started_at) for event in transcript.events), default=None)


def _gemini_home() -> Path:
    cli_home = os.environ.get("GEMINI_CLI_HOME")
    if cli_home:
        return Path(cli_home).expanduser() / _DEFAULT_GEMINI_DIR_NAME
    legacy_home = os.environ.get("GEMINI_HOME")
    if legacy_home:
        return Path(legacy_home).expanduser()
    return Path.home() / _DEFAULT_GEMINI_DIR_NAME


def _project_hash(project_path: Path) -> str:
    import hashlib

    return hashlib.sha256(str(project_path.resolve()).encode("utf-8")).hexdigest()


class _GeminiProjectRegistry:
    def __init__(self, gemini_home: Path) -> None:
        self.gemini_home = gemini_home
        self.registry_path = gemini_home / "projects.json"
        self.base_dirs = [
            gemini_home / "tmp",
            gemini_home / "history",
        ]

    def chats_dir(self, project_id: str) -> Path:
        return self.gemini_home / "tmp" / project_id / "chats"

    def get_short_id(self, project_path: Path) -> str:
        normalized = self._normalize(project_path)
        data = self._load()

        mapped = data["projects"].get(normalized)
        if mapped and self._verify_slug(mapped, normalized):
            self._ensure_markers(mapped, normalized)
            return mapped
        if mapped:
            del data["projects"][normalized]

        existing = self._find_existing_slug(normalized)
        if existing:
            data["projects"][normalized] = existing
            self._save(data)
            return existing

        slug = self._claim_new_slug(project_path, normalized, data["projects"])
        data["projects"][normalized] = slug
        self._save(data)
        return slug

    def _load(self) -> dict[str, dict[str, str]]:
        if not self.registry_path.exists():
            return {"projects": {}}
        try:
            return json.loads(self.registry_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"projects": {}}

    def _save(self, data: dict[str, dict[str, str]]) -> None:
        self.registry_path.parent.mkdir(parents=True, exist_ok=True)
        self.registry_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def _normalize(self, project_path: Path) -> str:
        resolved = str(project_path.resolve())
        if os.name == "nt":
            resolved = resolved.lower()
        return resolved

    def _verify_slug(self, slug: str, normalized_project: str) -> bool:
        for base_dir in self.base_dirs:
            marker = base_dir / slug / _PROJECT_ROOT_FILE
            if not marker.exists():
                continue
            try:
                owner = marker.read_text(encoding="utf-8").strip()
            except OSError:
                return False
            if self._normalize(Path(owner)) != normalized_project:
                return False
        return True

    def _find_existing_slug(self, normalized_project: str) -> str | None:
        for base_dir in self.base_dirs:
            if not base_dir.exists():
                continue
            for candidate in base_dir.iterdir():
                marker = candidate / _PROJECT_ROOT_FILE
                if not marker.exists():
                    continue
                try:
                    owner = marker.read_text(encoding="utf-8").strip()
                except OSError:
                    continue
                if self._normalize(Path(owner)) == normalized_project:
                    self._ensure_markers(candidate.name, normalized_project)
                    return candidate.name
        return None

    def _claim_new_slug(
        self,
        project_path: Path,
        normalized_project: str,
        existing_mappings: dict[str, str],
    ) -> str:
        slug = self._slugify(project_path.name or "project")
        counter = 0
        existing_ids = set(existing_mappings.values())
        while True:
            candidate = slug if counter == 0 else f"{slug}-{counter}"
            counter += 1
            if candidate in existing_ids:
                continue
            try:
                self._ensure_markers(candidate, normalized_project, create_only=True)
            except FileExistsError:
                continue
            except ValueError:
                continue
            return candidate

    def _ensure_markers(
        self,
        slug: str,
        normalized_project: str,
        create_only: bool = False,
    ) -> None:
        for base_dir in self.base_dirs:
            slug_dir = base_dir / slug
            slug_dir.mkdir(parents=True, exist_ok=True)
            marker = slug_dir / _PROJECT_ROOT_FILE
            if marker.exists():
                owner = self._normalize(Path(marker.read_text(encoding="utf-8").strip()))
                if owner != normalized_project:
                    if create_only:
                        raise FileExistsError(f"slug {slug} is already owned")
                    raise ValueError(f"slug {slug} is already owned by {owner}")
                continue
            marker.write_text(normalized_project, encoding="utf-8")

    def _slugify(self, text: str) -> str:
        slug = []
        last_dash = False
        for ch in text.lower():
            if ch.isalnum():
                slug.append(ch)
                last_dash = False
            elif not last_dash:
                slug.append("-")
                last_dash = True
        value = "".join(slug).strip("-")
        return value or "project"
