"""Export a CanonicalTranscript to Codex CLI's native JSONL format."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)


def _event_line(timestamp: str, payload: dict[str, object]) -> str:
    return json.dumps(
        {
            "timestamp": timestamp,
            "type": "event_msg",
            "payload": payload,
        },
        default=str,
    )


def _response_line(timestamp: str, payload: dict[str, object]) -> str:
    return json.dumps(
        {
            "type": "response_item",
            "timestamp": timestamp,
            "payload": payload,
        },
        default=str,
    )


def _turn_context_line(
    timestamp: str,
    turn_id: str,
    cwd: str,
    model: str | None,
) -> str:
    return json.dumps(
        {
            "timestamp": timestamp,
            "type": "turn_context",
            "payload": {
                "turn_id": turn_id,
                "cwd": cwd,
                "current_date": timestamp[:10],
                "timezone": "Etc/UTC",
                "approval_policy": "never",
                "sandbox_policy": {"type": "danger-full-access"},
                "model": model or "gpt-5.4",
                "personality": "pragmatic",
                "collaboration_mode": {
                    "mode": "default",
                    "settings": {
                        "model": model or "gpt-5.4",
                        "reasoning_effort": "high",
                    },
                },
                "realtime_active": False,
                "effort": "high",
                "summary": "none",
                "truncation_policy": {
                    "mode": "tokens",
                    "limit": 10000,
                },
            },
        },
        default=str,
    )


def export_codex_cli(
    transcript: CanonicalTranscript,
    workspace: str,
    session_id: str | None = None,
) -> dict[str, str]:
    """Export a canonical transcript as a Codex CLI native JSONL session.

    Creates the rollout .jsonl file in ~/.codex/sessions/ so Codex can
    see it as a previous session.

    Returns dict with paths of files written.
    """
    workspace_path = Path(workspace).resolve()
    now = datetime.now(timezone.utc)
    started_at = transcript.session.started_at or transcript.session.ended_at or now
    session_id = session_id or str(uuid.uuid4())

    lines: list[str] = []

    # Session meta (first line)
    lines.append(json.dumps({
        "type": "session_meta",
        "timestamp": now.isoformat(),
        "payload": {
            "id": session_id,
            "timestamp": started_at.isoformat(),
            "cwd": str(workspace_path),
            "originator": "anyfs_resume",
            "cli_version": "0.80.0",
            "model_provider": transcript.session.model or "unknown",
            "git": {
                "branch": transcript.session.git_branch or "main",
            },
            "instructions": f"Resumed from {transcript.session.agent} session",
        },
    }, default=str))

    turn_id: str | None = None
    turn_started = False
    last_agent_message: str | None = None
    last_turn_ts = now.isoformat()

    def start_turn(ts: str) -> None:
        nonlocal turn_id, turn_started
        turn_id = str(uuid.uuid4())
        turn_started = True
        lines.append(
            _event_line(
                ts,
                {
                    "type": "task_started",
                    "turn_id": turn_id,
                    "model_context_window": 258400,
                    "collaboration_mode_kind": "default",
                },
            )
        )
        lines.append(_turn_context_line(ts, turn_id, str(workspace_path), transcript.session.model))

    def finish_turn(ts: str) -> None:
        nonlocal turn_started, last_agent_message
        if not turn_started or turn_id is None:
            return
        lines.append(
            _event_line(
                ts,
                {
                    "type": "task_complete",
                    "turn_id": turn_id,
                    "last_agent_message": last_agent_message or "",
                },
            )
        )
        turn_started = False
        last_agent_message = None

    for event in transcript.events:
        ts = event.ts.isoformat() if event.ts else now.isoformat()
        last_turn_ts = ts

        if isinstance(event, UserMessageEvent):
            if turn_started:
                finish_turn(ts)
            start_turn(ts)
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "message",
                        "role": "user",
                        "content": [{"type": "input_text", "text": event.text}],
                    },
                )
            )
            lines.append(
                _event_line(
                    ts,
                    {
                        "type": "user_message",
                        "message": event.text,
                        "images": [],
                        "local_images": [],
                        "text_elements": [],
                    },
                )
            )

        elif isinstance(event, AssistantTextEvent):
            if not turn_started:
                start_turn(ts)
            lines.append(
                _event_line(
                    ts,
                    {
                        "type": "agent_message",
                        "message": event.text,
                        "phase": event.meta.get("phase"),
                        "memory_citation": event.meta.get("memory_citation"),
                    },
                )
            )
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "message",
                        "role": "assistant",
                        "content": [{"type": "output_text", "text": event.text}],
                    },
                )
            )
            last_agent_message = event.text

        elif isinstance(event, ThinkingEvent):
            if not turn_started:
                start_turn(ts)
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "reasoning",
                        "summary": [],
                        "content": event.text or None,
                        "encrypted_content": None,
                    },
                )
            )

        elif isinstance(event, ShellCommandEvent):
            if not turn_started:
                start_turn(ts)
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call",
                        "name": "shell",
                        "arguments": json.dumps({"command": event.command}),
                        "call_id": call_id,
                    },
                )
            )
            if event.output_preview:
                lines.append(
                    _response_line(
                        ts,
                        {
                            "type": "function_call_output",
                            "call_id": call_id,
                            "output": event.output_preview,
                        },
                    )
                )

        elif isinstance(event, FileReadEvent):
            if not turn_started:
                start_turn(ts)
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call",
                        "name": "read_file",
                        "arguments": json.dumps({"path": event.path}),
                        "call_id": call_id,
                    },
                )
            )
            if event.content_preview:
                lines.append(
                    _response_line(
                        ts,
                        {
                            "type": "function_call_output",
                            "call_id": call_id,
                            "output": event.content_preview,
                        },
                    )
                )

        elif isinstance(event, FileEditEvent):
            if not turn_started:
                start_turn(ts)
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call",
                        "name": "edit_file",
                        "arguments": json.dumps({"path": event.path, "diff": event.diff or ""}),
                        "call_id": call_id,
                    },
                )
            )
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": "ok",
                    },
                )
            )

        elif isinstance(event, FileWriteEvent):
            if not turn_started:
                start_turn(ts)
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call",
                        "name": "write_file",
                        "arguments": json.dumps({"path": event.path}),
                        "call_id": call_id,
                    },
                )
            )
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": "ok",
                    },
                )
            )

        elif isinstance(event, CodeSearchEvent):
            if not turn_started:
                start_turn(ts)
            call_id = f"call_{uuid.uuid4().hex[:24]}"
            lines.append(
                _response_line(
                    ts,
                    {
                        "type": "function_call",
                        "name": "search",
                        "arguments": json.dumps({"query": event.query}),
                        "call_id": call_id,
                    },
                )
            )
            if event.result_preview:
                lines.append(
                    _response_line(
                        ts,
                        {
                            "type": "function_call_output",
                            "call_id": call_id,
                            "output": event.result_preview,
                        },
                    )
                )

    finish_turn(last_turn_ts)

    # Write to Codex sessions directory
    sessions_dir = (
        Path.home()
        / ".codex"
        / "sessions"
        / started_at.strftime("%Y")
        / started_at.strftime("%m")
        / started_at.strftime("%d")
    )
    sessions_dir.mkdir(parents=True, exist_ok=True)
    filename = f"rollout-{started_at.strftime('%Y-%m-%dT%H-%M-%S')}-{session_id}.jsonl"
    jsonl_path = sessions_dir / filename
    jsonl_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    return {
        "transcript": str(jsonl_path),
        "session_id": session_id,
        "resume_hint": f"codex resume {session_id}",
    }
