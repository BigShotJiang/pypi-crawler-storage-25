"""Export a CanonicalTranscript to Hermes Agent's native session stores."""
from __future__ import annotations

import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from anyfs_schemas import (
    AssistantTextEvent,
    CanonicalTranscript,
    CodeSearchEvent,
    ErrorEvent,
    FileEditEvent,
    FileReadEvent,
    FileWriteEvent,
    ShellCommandEvent,
    ThinkingEvent,
    UserMessageEvent,
)

_DEFAULT_HERMES_DIR_NAME = ".hermes"
_SCHEMA_VERSION = 6
_LOCAL_ORIGIN = {
    "platform": "local",
    "chat_id": "cli",
    "chat_name": "CLI terminal",
    "chat_type": "dm",
    "user_id": None,
    "user_name": None,
    "thread_id": None,
    "chat_topic": None,
}
_SESSION_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    user_id TEXT,
    model TEXT,
    model_config TEXT,
    system_prompt TEXT,
    parent_session_id TEXT,
    started_at REAL NOT NULL,
    ended_at REAL,
    end_reason TEXT,
    message_count INTEGER DEFAULT 0,
    tool_call_count INTEGER DEFAULT 0,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cache_read_tokens INTEGER DEFAULT 0,
    cache_write_tokens INTEGER DEFAULT 0,
    reasoning_tokens INTEGER DEFAULT 0,
    billing_provider TEXT,
    billing_base_url TEXT,
    billing_mode TEXT,
    estimated_cost_usd REAL,
    actual_cost_usd REAL,
    cost_status TEXT,
    cost_source TEXT,
    pricing_version TEXT,
    title TEXT
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT,
    tool_call_id TEXT,
    tool_calls TEXT,
    tool_name TEXT,
    timestamp REAL NOT NULL,
    token_count INTEGER,
    finish_reason TEXT,
    reasoning TEXT,
    reasoning_details TEXT,
    codex_reasoning_items TEXT
);

CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, timestamp);
"""


def export_hermes(
    transcript: CanonicalTranscript,
    workspace: str,
    session_id: str | None = None,
) -> dict[str, str]:
    """Export a canonical transcript as a Hermes native session."""
    workspace_path = Path(workspace).resolve()
    hermes_home = Path(os.environ.get("HERMES_HOME", Path.home() / _DEFAULT_HERMES_DIR_NAME)).expanduser()
    sessions_dir = hermes_home / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)

    started_at = transcript.session.started_at or _latest_event_ts(transcript) or datetime.now(timezone.utc)
    updated_at = transcript.session.ended_at or _latest_event_ts(transcript) or started_at
    # Honor the caller-supplied id so the "Target session id" anyfs
    # prints matches what `hermes --resume <id>` will look up.
    session_id = session_id or _make_session_id(started_at)
    session_key = f"agent:main:local:dm:anyfs-resume:{session_id}"
    transcript_path = sessions_dir / f"{session_id}.jsonl"
    state_db_path = hermes_home / "state.db"
    sessions_index_path = sessions_dir / "sessions.json"

    messages = _build_messages(transcript)
    _write_transcript(transcript_path, messages)
    _write_session_index(
        sessions_index_path=sessions_index_path,
        session_key=session_key,
        session_id=session_id,
        started_at=started_at,
        updated_at=updated_at,
    )
    _write_state_db(
        state_db_path=state_db_path,
        session_id=session_id,
        model=transcript.session.model,
        started_at=started_at,
        updated_at=updated_at,
        messages=messages,
        title=f"Resumed from {transcript.session.agent}",
    )

    return {
        "state_db": str(state_db_path),
        "session_store": str(sessions_index_path),
        "transcript": str(transcript_path),
        "session_id": session_id,
        "session_key": session_key,
        "resume_hint": f"hermes --resume {session_id}",
    }


def _make_session_id(started_at: datetime) -> str:
    return f"{started_at.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"


def _build_messages(transcript: CanonicalTranscript) -> list[dict[str, Any]]:
    messages: list[dict[str, Any]] = []
    assistant_content: list[str] = []
    assistant_reasoning: list[str] = []

    def flush_assistant(ts: str | None) -> None:
        nonlocal assistant_content, assistant_reasoning
        if not assistant_content and not assistant_reasoning:
            return
        messages.append(
            {
                "role": "assistant",
                "content": "\n\n".join(part for part in assistant_content if part).strip() or None,
                "reasoning": "\n\n".join(part for part in assistant_reasoning if part).strip() or None,
                "timestamp": ts or datetime.now(timezone.utc).isoformat(),
            }
        )
        assistant_content = []
        assistant_reasoning = []

    for event in transcript.events:
        ts = (getattr(event, "ts", None) or transcript.session.started_at or datetime.now(timezone.utc)).isoformat()
        if isinstance(event, UserMessageEvent):
            flush_assistant(ts)
            messages.append({"role": "user", "content": event.text, "timestamp": ts})
            continue

        if isinstance(event, AssistantTextEvent):
            if event.text:
                assistant_content.append(event.text)
            continue
        if isinstance(event, ThinkingEvent):
            if event.text:
                assistant_reasoning.append(event.text)
            continue

        flush_assistant(ts)
        tool_message = _tool_messages_for_event(event, ts)
        if tool_message:
            messages.extend(tool_message)

    flush_assistant((transcript.session.ended_at or transcript.session.started_at or datetime.now(timezone.utc)).isoformat())
    return [message for message in messages if message.get("content") is not None or message.get("tool_calls") or message.get("role") == "tool"]


def _tool_messages_for_event(event: Any, ts: str) -> list[dict[str, Any]]:
    call_id = f"call_{uuid.uuid4().hex[:24]}"
    if isinstance(event, ShellCommandEvent):
        return [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [_tool_call(call_id, "shell", {"command": event.command})],
                "timestamp": ts,
            },
            {
                "role": "tool",
                "tool_call_id": call_id,
                "tool_name": "shell",
                "content": event.output_preview or "",
                "timestamp": ts,
            },
        ]
    if isinstance(event, FileReadEvent):
        return [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [_tool_call(call_id, "read_file", {"path": event.path})],
                "timestamp": ts,
            },
            {
                "role": "tool",
                "tool_call_id": call_id,
                "tool_name": "read_file",
                "content": event.content_preview or "",
                "timestamp": ts,
            },
        ]
    if isinstance(event, FileEditEvent):
        return [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [_tool_call(call_id, "edit_file", {"path": event.path, "diff": event.diff or ""})],
                "timestamp": ts,
            },
            {
                "role": "tool",
                "tool_call_id": call_id,
                "tool_name": "edit_file",
                "content": event.diff or "ok",
                "timestamp": ts,
            },
        ]
    if isinstance(event, FileWriteEvent):
        return [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [_tool_call(call_id, "write_file", {"path": event.path})],
                "timestamp": ts,
            },
            {
                "role": "tool",
                "tool_call_id": call_id,
                "tool_name": "write_file",
                "content": event.content_preview or "ok",
                "timestamp": ts,
            },
        ]
    if isinstance(event, CodeSearchEvent):
        return [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [_tool_call(call_id, "search", {"query": event.query})],
                "timestamp": ts,
            },
            {
                "role": "tool",
                "tool_call_id": call_id,
                "tool_name": "search",
                "content": event.result_preview or "",
                "timestamp": ts,
            },
        ]
    if isinstance(event, ErrorEvent):
        return [{"role": "assistant", "content": f"[Error] {event.message}", "timestamp": ts}]
    return [{"role": "assistant", "content": f"[{getattr(event, 'kind', 'event')}]", "timestamp": ts}]


def _tool_call(call_id: str, name: str, args: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": call_id,
        "type": "function",
        "function": {
            "name": name,
            "arguments": json.dumps(args, ensure_ascii=False),
        },
    }


def _write_transcript(path: Path, messages: list[dict[str, Any]]) -> None:
    path.write_text(
        "\n".join(json.dumps(message, ensure_ascii=False) for message in messages) + "\n",
        encoding="utf-8",
    )


def _write_session_index(
    *,
    sessions_index_path: Path,
    session_key: str,
    session_id: str,
    started_at: datetime,
    updated_at: datetime,
) -> None:
    payload: dict[str, Any]
    if sessions_index_path.exists():
        try:
            payload = json.loads(sessions_index_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            payload = {}
    else:
        payload = {}
    payload[session_key] = {
        "session_key": session_key,
        "session_id": session_id,
        "created_at": started_at.isoformat(),
        "updated_at": updated_at.isoformat(),
        "display_name": "AnyFS Resumed Session",
        "platform": "local",
        "chat_type": "dm",
        "input_tokens": 0,
        "output_tokens": 0,
        "cache_read_tokens": 0,
        "cache_write_tokens": 0,
        "total_tokens": 0,
        "last_prompt_tokens": 0,
        "estimated_cost_usd": 0.0,
        "cost_status": "unknown",
        "memory_flushed": False,
        "origin": _LOCAL_ORIGIN,
    }
    sessions_index_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _write_state_db(
    *,
    state_db_path: Path,
    session_id: str,
    model: str | None,
    started_at: datetime,
    updated_at: datetime,
    messages: list[dict[str, Any]],
    title: str,
) -> None:
    state_db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(state_db_path))
    try:
        conn.executescript(_SESSION_SCHEMA_SQL)
        cursor = conn.execute("SELECT version FROM schema_version LIMIT 1")
        row = cursor.fetchone()
        if row is None:
            conn.execute("INSERT INTO schema_version (version) VALUES (?)", (_SCHEMA_VERSION,))
        else:
            conn.execute("UPDATE schema_version SET version = ?", (_SCHEMA_VERSION,))

        started_ts = started_at.timestamp()
        updated_ts = updated_at.timestamp()
        conn.execute(
            """
            INSERT OR REPLACE INTO sessions (
                id, source, model, started_at, ended_at, message_count, tool_call_count,
                input_tokens, output_tokens, cache_read_tokens, cache_write_tokens,
                reasoning_tokens, estimated_cost_usd, actual_cost_usd, cost_status, title
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, 0, ?, ?)
            """,
            (
                session_id,
                "cli",
                model,
                started_ts,
                updated_ts,
                len(messages),
                sum(len(message.get("tool_calls") or []) for message in messages),
                "estimated",
                title,
            ),
        )
        conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        for index, message in enumerate(messages):
            timestamp = _message_timestamp(message, fallback=started_at, index=index)
            conn.execute(
                """
                INSERT INTO messages (
                    session_id, role, content, tool_call_id, tool_calls, tool_name,
                    timestamp, token_count, finish_reason, reasoning, reasoning_details, codex_reasoning_items
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    message.get("role", "assistant"),
                    message.get("content"),
                    message.get("tool_call_id"),
                    json.dumps(message["tool_calls"], ensure_ascii=False) if message.get("tool_calls") else None,
                    message.get("tool_name"),
                    timestamp,
                    None,
                    None,
                    message.get("reasoning"),
                    None,
                    None,
                ),
            )
        conn.commit()
    finally:
        conn.close()


def _message_timestamp(message: dict[str, Any], *, fallback: datetime, index: int) -> float:
    raw = message.get("timestamp")
    if isinstance(raw, str):
        try:
            return datetime.fromisoformat(raw).timestamp()
        except ValueError:
            pass
    return fallback.timestamp() + index * 0.001


def _latest_event_ts(transcript: CanonicalTranscript) -> datetime | None:
    if not transcript.events:
        return None
    timestamps = [event.ts for event in transcript.events if getattr(event, "ts", None)]
    return max(timestamps) if timestamps else None
