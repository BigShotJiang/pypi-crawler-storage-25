from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from anyfs_adapters_core import AgentAdapter, append_unique, collect_text_files, read_text_file, select_best_path_by_current_session_hint
from anyfs_schemas import AgentType, CaptureResult, CodeRef, Namespace, WorkspaceBinding, WorkspaceOverlay
from anyfs_transcript import parse_transcript, render_markdown

_DEFAULT_HERMES_HOME = ".hermes"
_HERMES_EXCLUDED_CONTEXT_FILES = {"config.yaml", ".env"}


def _hermes_home() -> Path:
    return Path(os.environ.get("HERMES_HOME", Path.home() / _DEFAULT_HERMES_HOME)).expanduser()


def _hermes_recent_session_ids(hermes_home: Path) -> list[str]:
    discovered: list[str] = []
    state_db = hermes_home / "state.db"
    if state_db.is_file():
        try:
            conn = sqlite3.connect(state_db)
            rows = conn.execute(
                "SELECT id FROM sessions ORDER BY started_at DESC LIMIT 20"
            ).fetchall()
            conn.close()
            discovered.extend(row[0] for row in rows if isinstance(row[0], str) and row[0])
        except sqlite3.Error:
            pass

    sessions_dir = hermes_home / "sessions"
    for path in sorted(sessions_dir.glob("*.jsonl"), key=lambda item: item.stat().st_mtime, reverse=True)[:20]:
        if path.stem not in discovered:
            discovered.append(path.stem)
    return discovered[:20]


def _hermes_process_files(process_scope: str = "current") -> list[Path]:
    hermes_home = _hermes_home()
    sessions_dir = hermes_home / "sessions"
    if not sessions_dir.exists():
        return []

    if process_scope == "all":
        session_ids = _hermes_recent_session_ids(hermes_home)
    else:
        session_ids = _hermes_recent_session_ids(hermes_home)

    files: list[Path] = []
    for session_id in session_ids:
        if not session_id:
            continue
        candidates = [
            sessions_dir / f"{session_id}.jsonl",
            sessions_dir / f"session_{session_id}.json",
        ]
        for path in candidates:
            if path.is_file():
                append_unique(files, path)
                if process_scope != "all":
                    break
        if files and process_scope != "all":
            break
    return files[:20] if process_scope == "all" else files[:1]


class HermesAdapter(AgentAdapter):
    agent_type = AgentType.HERMES

    def __init__(self, process_scope: str = "current", current_session_hint: dict | None = None) -> None:
        self.process_scope = process_scope if process_scope in {"current", "all"} else "current"
        self.current_session_hint = current_session_hint

    def discover(self, workspace: str) -> list[Path]:
        hermes_home = _hermes_home()
        process_scope = "all" if self.process_scope == "current" and self.current_session_hint else self.process_scope
        process_files = list(_hermes_process_files(process_scope))
        if self.process_scope == "current":
            hinted = select_best_path_by_current_session_hint(
                process_files,
                agent_type="hermes",
                hint=self.current_session_hint,
            )
            process_files = [hinted] if hinted is not None else process_files[:1]
        candidates: list[Path] = list(process_files)

        for path in (
            hermes_home / "AGENTS.md",
            hermes_home / "SOUL.md",
            hermes_home / "memories" / "USER.md",
            hermes_home / "memories" / "MEMORY.md",
        ):
            append_unique(candidates, path)

        for root in (
            hermes_home / "skills",
        ):
            for path in collect_text_files(root, max_files=120, exclude_names=_HERMES_EXCLUDED_CONTEXT_FILES):
                append_unique(candidates, path)

        return candidates[:200]

    def extract(self, workspace: str) -> list[dict]:
        hermes_home = _hermes_home()
        records = []
        for path in self.discover(workspace):
            name = path.name.lower()
            if path.suffix in {".jsonl", ".json"} and path.parent == hermes_home / "sessions":
                try:
                    canonical = parse_transcript(path, agent_type="hermes")
                    records.append(
                        {
                            "path": str(path),
                            "relative_path": f"process/hermes/{path.name}",
                            "namespace": "process",
                            "content": render_markdown(canonical),
                            "canonical_transcript": canonical.model_dump(mode="json"),
                        }
                    )
                    continue
                except Exception:
                    pass
            if path.is_relative_to(hermes_home):
                relative = path.relative_to(hermes_home)
                if name == "soul.md":
                    namespace = "soul"
                elif name == "user.md":
                    namespace = "user"
                elif "memory" in relative.parts or name == "memory.md":
                    namespace = "memory"
                else:
                    namespace = "skills"
                relative_path = f"{namespace}/hermes/global/{relative}"
            else:
                namespace = "skills"
                relative_path = path.name

            records.append(
                {
                    "path": str(path),
                    "relative_path": relative_path,
                    "namespace": namespace,
                    "content": read_text_file(path),
                }
            )
        return records

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        normalized: dict[str, list[dict]] = {}
        for record in raw:
            normalized.setdefault(record["namespace"], []).append(record)
        return normalized

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        trajectory = {ns: items for ns, items in normalized.items() if ns != "artifacts"}
        components = [Namespace(ns) for ns in trajectory.keys()]
        return CaptureResult(
            agent_id="pending",
            agent_type=self.agent_type,
            workspace="",
            code_ref=CodeRef(),
            workspace_overlay=WorkspaceOverlay(mode="none", binding=WorkspaceBinding(cwd="")),
            trajectory=trajectory,
            artifacts=normalized.get("artifacts", []),
            trajectory_components=components,
            captured_namespaces=list(normalized.keys()),
            payloads=normalized,
            warnings=[] if normalized else ["no Hermes Agent files were discovered"],
        )
