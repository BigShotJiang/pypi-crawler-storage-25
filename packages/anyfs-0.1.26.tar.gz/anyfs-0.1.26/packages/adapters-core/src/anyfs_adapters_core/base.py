from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Protocol

from anyfs_schemas import AgentType, CaptureResult, Namespace


class AgentAdapter(Protocol):
    agent_type: AgentType

    def discover(self, workspace: str) -> list[Path]:
        ...

    def extract(self, workspace: str) -> list[dict]:
        ...

    def normalize(self, raw: list[dict]) -> dict[str, list[dict]]:
        ...

    def bundle(self, normalized: dict[str, list[dict]], policy: dict | None = None) -> CaptureResult:
        ...


def classify_by_path(path: Path) -> Namespace:
    full_path = str(path).lower()
    name = path.name.lower()
    if "soul" in full_path:
        return Namespace.SOUL
    if "user" in full_path or "profile" in full_path:
        return Namespace.USER
    if "memory" in full_path or "session" in full_path:
        return Namespace.MEMORY
    if "skill" in full_path or "instruction" in full_path or "prompt" in full_path or name == "claude.md":
        return Namespace.SKILLS
    if "process" in full_path or "log" in full_path or "trace" in full_path:
        return Namespace.PROCESS
    return Namespace.ARTIFACTS


def read_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="replace")


_TEXT_SUFFIXES = {
    ".md",
    ".txt",
    ".json",
    ".jsonl",
    ".yaml",
    ".yml",
    ".toml",
    ".conf",
    ".cfg",
    ".ini",
    ".sh",
    ".py",
    ".js",
    ".ts",
}
_TEXT_NAMES = {
    "agents.md",
    "claude.md",
    "gemini.md",
    "tools.md",
    "bootstrap.md",
    "heartbeat.md",
    "identity.md",
    "user.md",
    "soul.md",
    "skill.md",
    "readme.md",
    "license.txt",
    "package.json",
    "plugin.json",
    ".app.json",
    ".project_root",
    "config.toml",
    "settings.json",
    ".claude.json",
    "openclaw.json",
    "opencode.json",
}
_IGNORED_DIR_NAMES = {
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    "dist",
    "build",
    ".next",
    ".cache",
}


def append_unique(candidates: list[Path], path: Path) -> None:
    if path.is_file() and path not in candidates:
        candidates.append(path)


def is_text_state_file(path: Path) -> bool:
    name = path.name.lower()
    return path.suffix.lower() in _TEXT_SUFFIXES or name in _TEXT_NAMES


def collect_text_files(root: Path, *, max_files: int = 200, exclude_names: set[str] | None = None) -> list[Path]:
    if not root.exists():
        return []
    excluded = {name.lower() for name in (exclude_names or set())}
    candidates: list[Path] = []
    for path in sorted(root.rglob("*")):
        if any(part in _IGNORED_DIR_NAMES for part in path.parts):
            continue
        if path.is_file() and is_text_state_file(path) and path.name.lower() not in excluded:
            candidates.append(path)
            if len(candidates) >= max_files:
                break
    return candidates


_WHITESPACE_RE = re.compile(r"\s+")


def normalize_message_text(text: str | None) -> str | None:
    if not text:
        return None
    normalized = _WHITESPACE_RE.sub(" ", text).strip().lower()
    return normalized[:4000] or None


def build_current_session_hint(
    user_text: str | None = None,
    assistant_text: str | None = None,
) -> dict[str, Any] | None:
    normalized_user = normalize_message_text(user_text)
    normalized_assistant = normalize_message_text(assistant_text)
    if not normalized_user and not normalized_assistant:
        return None
    hint: dict[str, Any] = {}
    if normalized_user:
        hint["user_text"] = normalized_user
        hint["user_fingerprint"] = hashlib.sha256(normalized_user.encode("utf-8")).hexdigest()
    if normalized_assistant:
        hint["assistant_text"] = normalized_assistant
        hint["assistant_fingerprint"] = hashlib.sha256(normalized_assistant.encode("utf-8")).hexdigest()
    return hint


def _latest_transcript_messages(path: Path, agent_type: str) -> tuple[str | None, str | None]:
    try:
        from anyfs_transcript import parse_transcript

        canonical = parse_transcript(path, agent_type=agent_type)
    except Exception:
        return (None, None)

    latest_user: str | None = None
    latest_assistant: str | None = None
    for event in reversed(canonical.events):
        if latest_user is None and getattr(event, "kind", None) == "user_message":
            latest_user = normalize_message_text(getattr(event, "text", None))
        elif latest_assistant is None and getattr(event, "kind", None) == "assistant_text":
            latest_assistant = normalize_message_text(getattr(event, "text", None))
        if latest_user is not None and latest_assistant is not None:
            break
    return latest_user, latest_assistant


def select_best_path_by_current_session_hint(
    paths: list[Path],
    *,
    agent_type: str,
    hint: dict[str, Any] | None,
) -> Path | None:
    if not paths or not hint:
        return None

    scored: list[tuple[int, int, int, Path]] = []
    for index, path in enumerate(paths):
        latest_user, latest_assistant = _latest_transcript_messages(path, agent_type)
        total_score = 0
        exact_matches = 0

        if hint.get("user_fingerprint") and latest_user:
            latest_fp = hashlib.sha256(latest_user.encode("utf-8")).hexdigest()
            if latest_fp == hint["user_fingerprint"]:
                total_score += 2
                exact_matches += 1
            elif hint.get("user_text") and (hint["user_text"] in latest_user or latest_user in hint["user_text"]):
                total_score += 1

        if hint.get("assistant_fingerprint") and latest_assistant:
            latest_fp = hashlib.sha256(latest_assistant.encode("utf-8")).hexdigest()
            if latest_fp == hint["assistant_fingerprint"]:
                total_score += 2
                exact_matches += 1
            elif hint.get("assistant_text") and (
                hint["assistant_text"] in latest_assistant or latest_assistant in hint["assistant_text"]
            ):
                total_score += 1

        scored.append((total_score, exact_matches, -index, path))

    best = max(scored, default=None)
    if best is None or best[0] <= 0:
        return None
    return best[3]
