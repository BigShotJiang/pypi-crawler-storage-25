from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

# ── Handle validation ─────────────────────────────────────
USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,30}[a-z0-9]$")
RESERVED_USERNAMES = frozenset({"admin", "system", "anyfs", "api", "root", "null", "undefined"})


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_now_iso() -> str:
    return utc_now().isoformat()


class AnyFSModel(BaseModel):
    model_config = {
        "populate_by_name": True,
        "use_enum_values": True,
        "extra": "forbid",
    }


class AgentType(str, Enum):
    HERMES = "hermes"
    NANOBOT = "nanobot"
    OPENCLAW = "openclaw"
    OPENCODE = "opencode"
    CLAUDE_CODE = "claude-code"
    GEMINI_CLI = "gemini-cli"
    CODEX_CLI = "codex-cli"
    CURSOR = "cursor"


class Namespace(str, Enum):
    SOUL = "soul"
    USER = "user"
    MEMORY = "memory"
    SKILLS = "skills"
    PROCESS = "process"
    ARTIFACTS = "artifacts"
    WORKSPACE_OVERLAY = "workspace_overlay"


class Visibility(str, Enum):
    PUBLIC = "public"
    PRIVATE = "private"


class PublishVisibilityMode(str, Enum):
    ALL_PUBLIC = "all-public"
    ARTIFACTS_PUBLIC = "artifacts-public"
    ALL_PRIVATE = "all-private"


class CodeRefProvider(str, Enum):
    GITHUB = "github"
    GIT = "git"
    NONE = "none"


class AgentAuthMode(str, Enum):
    STANDALONE = "standalone"
    BOUND = "bound"


class AgentBindingStatus(str, Enum):
    UNCLAIMED = "unclaimed"
    CLAIMED = "claimed"
    REVOKED = "revoked"


class SkillAction(str, Enum):
    INIT = "anyfs.init"
    AUTH_LOGIN = "anyfs.auth_login"
    REGISTER_AGENT = "anyfs.register_agent"
    AGENT_CREATE_REMOTE = "anyfs.agent_create_remote"
    AGENT_STATUS = "anyfs.agent_status"
    AGENT_BIND = "anyfs.agent_bind"
    CAPTURE = "anyfs.capture"
    SNAPSHOT_CREATE = "anyfs.snapshot_create"
    SNAPSHOT_LIST = "anyfs.snapshot_list"
    RESTORE = "anyfs.restore"
    BACKUP_CREATE = "anyfs.backup_create"
    SHARE_LINK = "anyfs.share_link"
    PACK = "anyfs.pack"
    PUBLISH = "anyfs.publish"
    BUY = "anyfs.buy"
    RELEASE_CREATE = "anyfs.release_create"
    FORK = "anyfs.fork"
    LINEAGE_SHOW = "anyfs.lineage_show"
    MIGRATE = "anyfs.migrate"


class UserRecord(AnyFSModel):
    user_id: str
    email: str
    created_at: datetime = Field(default_factory=utc_now)


class AgentRecord(AnyFSModel):
    agent_id: str
    owner_user_id: str
    agent_type: AgentType
    username: str
    public_key: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    head_snapshot_id: str | None = None


class AgentRecordLite(AnyFSModel):
    agent_id: str
    owner_user_id: str | None = None
    agent_type: AgentType
    username: str
    public_key: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    last_seen_at: datetime = Field(default_factory=utc_now)
    auth_mode: AgentAuthMode = AgentAuthMode.STANDALONE
    status: AgentBindingStatus = AgentBindingStatus.UNCLAIMED


class AgentCredential(AnyFSModel):
    agent_id: str
    token_hash: str
    issued_at: datetime = Field(default_factory=utc_now)
    revoked_at: datetime | None = None


class AgentBinding(AnyFSModel):
    binding_id: str
    agent_id: str
    user_id: str
    status: AgentBindingStatus = AgentBindingStatus.CLAIMED
    created_at: datetime = Field(default_factory=utc_now)
    claimed_at: datetime = Field(default_factory=utc_now)


class ArtifactRecord(AnyFSModel):
    artifact_id: str
    snapshot_id: str
    type: str
    visibility: Visibility
    cid: str
    title: str


class SnapshotRecord(AnyFSModel):
    snapshot_id: str
    agent_id: str
    namespace: list[Namespace]
    parent_snapshot_id: str | None = None
    manifest_cid: str
    payload_cid: str
    encrypted: bool = True
    created_at: datetime = Field(default_factory=utc_now)


class SnapshotRecordLite(AnyFSModel):
    snapshot_id: str
    agent_id: str
    parent_snapshot_id: str | None = None
    manifest_cid: str
    payload_cid: str
    namespace_summary: list[Namespace]
    encrypted: bool = True
    created_at: datetime = Field(default_factory=utc_now)
    origin: str
    owner_user_id: str | None = None


class CodeRef(AnyFSModel):
    provider: CodeRefProvider = CodeRefProvider.NONE
    repo_url: str | None = None
    default_branch: str | None = None
    commit_sha: str | None = None
    subdir: str | None = None
    pr_number: int | None = None
    issue_number: int | None = None


class WorkspaceBinding(AnyFSModel):
    cwd: str
    repo_root: str | None = None
    branch: str | None = None
    commit_sha: str | None = None
    remote: str | None = None
    dirty: bool = False
    status_summary: list[str] = Field(default_factory=list)


class WorkspaceOverlayFile(AnyFSModel):
    relative_path: str
    encoding: str
    content: str
    executable: bool = False
    size: int = 0


class WorkspaceOverlay(AnyFSModel):
    mode: str = "changed"
    captured_at: datetime = Field(default_factory=utc_now)
    binding: WorkspaceBinding
    files: list[WorkspaceOverlayFile] = Field(default_factory=list)
    deleted_paths: list[str] = Field(default_factory=list)
    omitted_paths: list[str] = Field(default_factory=list)
    archive_name: str | None = None
    archive_encoding: str | None = None
    archive_content: str | None = None
    archive_size: int = 0
    archive_file_count: int = 0


class WorkspaceOverlaySummary(AnyFSModel):
    mode: str = "changed"
    binding: WorkspaceBinding
    file_count: int = 0
    deleted_count: int = 0
    omitted_count: int = 0
    captured_at: datetime = Field(default_factory=utc_now)


class TrajectorySummary(AnyFSModel):
    components: list[Namespace] = Field(default_factory=list)
    counts: dict[str, int] = Field(default_factory=dict)


class ArtifactsSummary(AnyFSModel):
    visibility: Visibility = Visibility.PUBLIC
    count: int = 0
    index: list[dict[str, Any]] = Field(default_factory=list)


class PackageRecord(AnyFSModel):
    package_id: str
    source_snapshot_id: str
    manifest_cid: str
    message: str | None = None
    visibility_mode: PublishVisibilityMode = PublishVisibilityMode.ARTIFACTS_PUBLIC
    secret_scan: dict[str, Any] | None = None
    code_ref: CodeRef
    workspace_overlay: WorkspaceOverlaySummary | None = None
    trajectory: TrajectorySummary
    artifacts: ArtifactsSummary
    fork_policy: str
    created_by_agent_id: str | None = None
    owner_user_id: str | None = None
    owner_handle: str | None = None
    repo_owner: str | None = None
    project_name: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    published_at: datetime | None = None


class ReleaseRecord(AnyFSModel):
    release_id: str
    package_id: str
    version: str
    published_at: datetime = Field(default_factory=utc_now)


class LineageRecord(AnyFSModel):
    parent_package_id: str
    child_package_id: str
    created_at: datetime = Field(default_factory=utc_now)


class BackupRecord(AnyFSModel):
    backup_id: str
    agent_id: str
    snapshot_id: str
    namespaces: list[Namespace]
    manifest_cid: str
    payload_cid: str
    created_by_agent_id: str | None = None
    owner_user_id: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    restore_hint: str
    remote_url: str | None = None


class LinkRecord(AnyFSModel):
    link_id: str
    agent_id: str
    snapshot_id: str
    namespaces: list[Namespace]
    visibility: Visibility = Visibility.PRIVATE
    access_mode: str = "analysis"
    created_by_agent_id: str | None = None
    owner_user_id: str | None = None
    url: str
    created_at: datetime = Field(default_factory=utc_now)


class RecoveryRecord(AnyFSModel):
    recovery_id: str
    agent_id: str
    device_id: str
    created_at: datetime = Field(default_factory=utc_now)
    bundle_version: str = "v1"


class CaptureResult(AnyFSModel):
    ok: bool = True
    agent_id: str
    agent_type: AgentType
    workspace: str
    client_scope: str = "project"
    process_scope: str = "current"
    captured_agent_types: list[AgentType] = Field(default_factory=list)
    code_ref: CodeRef
    workspace_overlay: WorkspaceOverlay | None = None
    trajectory: dict[str, list[dict[str, Any]]]
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    trajectory_components: list[Namespace] = Field(default_factory=list)
    captured_namespaces: list[Namespace] = Field(default_factory=list)
    payloads: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=utc_now)


class SnapshotManifest(AnyFSModel):
    snapshot_id: str
    agent_id: str
    workspace: str
    code_ref: CodeRef
    workspace_overlay: WorkspaceOverlaySummary | None = None
    trajectory: TrajectorySummary
    artifacts: ArtifactsSummary
    restore_metadata: dict[str, Any]
    created_at: datetime = Field(default_factory=utc_now)


class PackageManifest(AnyFSModel):
    name: str
    description: str
    message: str | None = None
    agent_type: AgentType
    version: str
    tags: list[str] = Field(default_factory=list)
    visibility_mode: PublishVisibilityMode = PublishVisibilityMode.ARTIFACTS_PUBLIC
    secret_scan: dict[str, Any] | None = None
    code_ref: CodeRef
    workspace_overlay: WorkspaceOverlaySummary | None = None
    trajectory: TrajectorySummary
    artifacts: ArtifactsSummary


class SkillActionSpec(AnyFSModel):
    action: SkillAction
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    error_codes: list[str]
    side_effect: str
    requires_workspace: bool
    requires_init: bool


class DoctorReport(AnyFSModel):
    ok: bool
    checks: dict[str, bool]
    warnings: list[str] = Field(default_factory=list)


class AuthLoginRequest(AnyFSModel):
    email: str
    password: str = Field(min_length=8)


class AuthRegisterRequest(AnyFSModel):
    email: str
    password: str = Field(min_length=8)


class AuthLoginResponse(AnyFSModel):
    ok: bool = True
    token: str
    user: UserRecord
    expires_at: datetime = Field(default_factory=lambda: utc_now() + timedelta(days=30))


class AuthRegisterResponse(AnyFSModel):
    ok: bool = True
    token: str
    user: UserRecord
    expires_at: datetime = Field(default_factory=lambda: utc_now() + timedelta(days=30))


class MeResponse(AnyFSModel):
    ok: bool = True
    user: UserRecord


class DelegationRequest(AnyFSModel):
    agent_did: str
    scope: str


class DelegationResponse(AnyFSModel):
    ok: bool = True
    proof: str
    scope: str
    expires_at: datetime = Field(default_factory=lambda: utc_now() + timedelta(hours=1))


class StorageCommitRequest(AnyFSModel):
    resource_type: str
    resource_id: str
    cid: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class StorageCommitResponse(AnyFSModel):
    ok: bool = True
    commit_id: str
    cid: str


class StorageCommitRecord(AnyFSModel):
    commit_id: str
    resource_type: str
    resource_id: str
    cid: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)


class AuthStatus(AnyFSModel):
    ok: bool = True
    email: str
    token: str


class AgentAuthRegisterRequest(AnyFSModel):
    agent_id: str
    agent_type: AgentType
    username: str
    public_key: str | None = None


class AgentAuthRegisterResponse(AnyFSModel):
    ok: bool = True
    agent: AgentRecordLite


class AgentStatusResponse(AnyFSModel):
    ok: bool = True
    agent: AgentRecordLite
    binding: AgentBinding | None = None


class AgentBindRequest(AnyFSModel):
    email: str
    password: str = Field(min_length=8)


class AgentBindResponse(AnyFSModel):
    ok: bool = True
    agent: AgentRecordLite
    binding: AgentBinding


class PublishResult(AnyFSModel):
    ok: bool = True
    package_id: str
    cid: str
    path: str
    visibility_mode: PublishVisibilityMode = PublishVisibilityMode.ARTIFACTS_PUBLIC
    secret_scan: dict[str, Any] | None = None


class BackupCreateRequest(AnyFSModel):
    agent: AgentRecordLite
    snapshot: SnapshotRecordLite
    backup: BackupRecord


class LinkCreateRequest(AnyFSModel):
    agent: AgentRecordLite
    snapshot: SnapshotRecordLite
    link: LinkRecord


class PackageCreateRequest(AnyFSModel):
    agent: AgentRecordLite
    snapshot: SnapshotRecordLite
    package: PackageRecord


class PackagePublicContentsResponse(AnyFSModel):
    ok: bool = True
    package_id: str
    visibility_mode: PublishVisibilityMode = PublishVisibilityMode.ARTIFACTS_PUBLIC
    code_ref: CodeRef | None = None
    workspace_overlay: dict[str, Any] | None = None
    trajectory: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)


class ShareLinkResult(AnyFSModel):
    ok: bool = True
    link_id: str
    url: str
    remote_ref: str
    expires_at: datetime | None = None


class ForkRequest(AnyFSModel):
    package_id: str
    child_username: str
    fork_policy: str = "free"


class ForkResponse(AnyFSModel):
    ok: bool = True
    child_package: PackageRecord
    lineage: LineageRecord


class APIAck(AnyFSModel):
    ok: bool = True
    message: str


# ── Username ──────────────────────────────────────────────

class AgentSetUsernameRequest(AnyFSModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[a-z0-9][a-z0-9-]{1,30}[a-z0-9]$")


# ── Friends ───────────────────────────────────────────────

class FriendshipStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    REMOVED = "removed"


class FriendRequestRecord(AnyFSModel):
    request_id: str
    from_agent_id: str
    from_username: str
    to_agent_id: str
    to_username: str
    status: FriendshipStatus = FriendshipStatus.PENDING
    created_at: datetime = Field(default_factory=utc_now)
    responded_at: datetime | None = None


class FriendRequestCreateRequest(AnyFSModel):
    to_username: str | None = None
    to_agent_id: str | None = None


class FriendRequestRespondRequest(AnyFSModel):
    accept: bool


class FriendRecord(AnyFSModel):
    agent_id: str
    username: str
    agent_type: str


# ── Airdrop ───────────────────────────────────────────────

class AirdropRecord(AnyFSModel):
    model_config = {"populate_by_name": True, "use_enum_values": True, "extra": "ignore"}

    airdrop_id: str
    from_agent_id: str
    from_username: str
    to_agent_id: str
    to_username: str
    share_urls: list[str]
    password: str
    message: str = ""
    status: str = "pending"
    created_at: datetime = Field(default_factory=utc_now)
    opened_at: datetime | None = None
    expires_at: datetime = Field(default_factory=lambda: utc_now() + timedelta(days=30))


class AirdropCreateRequest(AnyFSModel):
    to_username: str | None = None
    to_agent_id: str | None = None
    share_urls: list[str]
    password: str
    message: str = ""
