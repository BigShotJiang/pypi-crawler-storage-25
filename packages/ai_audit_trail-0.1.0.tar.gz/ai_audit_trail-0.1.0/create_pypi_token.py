"""
Creates a PyPI API token via browser automation.
Login via Google OAuth with sunds.connect@gmail.com
"""
import time
import sys
import re
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError


def create_pypi_token():
    with sync_playwright() as p:
        # Launch headed browser so Google OAuth works (headless often blocked)
        browser = p.chromium.launch(
            headless=False,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--start-maximized"]
        )
        context = browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        page = context.new_page()

        print("[1/8] Navigating to PyPI login page...")
        page.goto("https://pypi.org/account/login/", wait_until="networkidle")
        page.screenshot(path="C:/tmp/step1_login.png")
        print(f"  Title: {page.title()}")
        print(f"  URL: {page.url}")

        print("[2/8] Looking for Google Sign-In button...")
        # Print all links and buttons to debug
        links = page.locator('a').all()
        for link in links:
            href = link.get_attribute("href") or ""
            text = (link.text_content() or "").strip()[:50]
            if "google" in href.lower() or "google" in text.lower():
                print(f"  GOOGLE LINK: href={href}, text={text}")

        # Look for the Google login form/button
        # PyPI uses a form with action pointing to Google
        forms = page.locator('form').all()
        for i, form in enumerate(forms):
            action = form.get_attribute("action") or ""
            print(f"  Form {i}: action={action}")

        # Find Google login button - it's usually a button in a form
        # Try different selectors
        google_selectors = [
            'a[href*="google"]',
            'button:has-text("Google")',
            'a:has-text("Sign in with Google")',
            '[data-provider="google"]',
            'form[action*="google"] button',
            'a.btn-google, .google-login',
        ]

        clicked = False
        for selector in google_selectors:
            try:
                el = page.locator(selector).first
                if el.count() > 0 or True:
                    el.wait_for(timeout=2000)
                    print(f"  Found element with: {selector}")
                    print(f"  Text: {(el.text_content() or '').strip()[:50]}")
                    print(f"  href: {el.get_attribute('href')}")
                    el.click()
                    clicked = True
                    break
            except Exception as e:
                continue

        if not clicked:
            print("  Could not find Google button via selectors, checking page HTML...")
            # Get full HTML of login area
            html = page.content()
            # Find Google-related links
            google_links = re.findall(r'href="([^"]*google[^"]*)"', html, re.IGNORECASE)
            print(f"  Google links in HTML: {google_links[:5]}")

            if google_links:
                print(f"  Navigating directly to: {google_links[0]}")
                # Make absolute URL if needed
                url = google_links[0]
                if url.startswith("/"):
                    url = "https://pypi.org" + url
                page.goto(url, wait_until="networkidle")
                clicked = True

        if not clicked:
            print("  FALLBACK: Looking for all clickable elements with 'google'...")
            all_els = page.locator('[class*="google"], [id*="google"]').all()
            for el in all_els:
                print(f"  El: tag={el.evaluate('e => e.tagName')}, text={el.text_content()[:30]}")
                el.click()
                clicked = True
                break

        print("[3/8] Waiting after Google button click...")
        time.sleep(3)
        page.screenshot(path="C:/tmp/step3_after_click.png")
        print(f"  Current URL: {page.url}")
        print(f"  Title: {page.title()}")

        # Check if new page/popup opened
        all_pages = context.pages
        print(f"  Number of pages: {len(all_pages)}")
        for i, p2 in enumerate(all_pages):
            print(f"  Page {i}: {p2.url}")

        # If we're still on PyPI login, the click might have opened a popup
        if "pypi.org/account/login" in page.url:
            print("  Still on login page - checking for popup...")
            # Wait for a new page to open
            try:
                with context.expect_page(timeout=10000) as new_page_info:
                    # Try clicking again if needed
                    pass
                new_page = new_page_info.value
                print(f"  New page opened: {new_page.url}")
                page = new_page
            except PlaywrightTimeoutError:
                print("  No popup opened")

        # If we're on Google OAuth page
        if "accounts.google.com" in page.url:
            print("[4/8] On Google sign-in page...")
            page.screenshot(path="C:/tmp/step4_google.png")

            # Check for account picker first
            try:
                account = page.locator(f'[data-identifier="sunds.connect@gmail.com"], div:has-text("sunds.connect@gmail.com")').first
                account.wait_for(timeout=5000)
                print("  Found account picker, clicking account...")
                account.click()
            except PlaywrightTimeoutError:
                # Enter email
                print("  Entering email address...")
                try:
                    email_input = page.locator('input[type="email"], input[name="identifier"]').first
                    email_input.wait_for(timeout=10000)
                    email_input.fill("sunds.connect@gmail.com")

                    # Click Next
                    page.locator('#identifierNext, button:has-text("Next"), button:has-text("Weiter")').first.click()
                    time.sleep(2)
                    page.screenshot(path="C:/tmp/step4b_after_email.png")
                    print(f"  URL after email: {page.url}")
                except Exception as e:
                    print(f"  Error entering email: {e}")

            # Wait for password or 2FA
            print("  Waiting for password/2FA page...")
            time.sleep(2)
            page.screenshot(path="C:/tmp/step4c_password_page.png")

            # Check for password field
            try:
                pwd = page.locator('input[type="password"]').first
                pwd.wait_for(timeout=5000)
                print("  PASSWORD FIELD FOUND!")
                print("  Please enter your Google password in the browser window that just opened.")
                print("  Waiting up to 120 seconds for you to complete login...")
            except PlaywrightTimeoutError:
                print("  No password field, might need manual intervention")
                print("  Waiting for manual login completion (120s)...")

        elif "pypi.org" not in page.url:
            print(f"  On unknown page: {page.url}")
            print("  Waiting for manual navigation (120s)...")

        # Wait for successful PyPI login (token page)
        print("[5/8] Waiting for PyPI token page (up to 120s for manual steps)...")
        try:
            page.wait_for_url("*pypi.org/manage/account/token*", timeout=120000)
            print("  Successfully on token page!")
        except PlaywrightTimeoutError:
            # Try navigating directly
            print("  Timeout - trying to navigate directly to token page...")
            page.goto("https://pypi.org/manage/account/token/", wait_until="networkidle")
            time.sleep(2)

        page.screenshot(path="C:/tmp/step5_token_page.png")
        print(f"  Current URL: {page.url}")

        if "/account/login" in page.url:
            print("  STILL NOT LOGGED IN!")
            print("  Please complete the Google login manually in the browser.")
            print("  Waiting up to 3 minutes...")
            try:
                page.wait_for_url("*manage/account/token*", timeout=180000)
            except PlaywrightTimeoutError:
                print("  Still not on token page after 3 minutes")

        print("[6/8] On token creation page, filling form...")
        page.screenshot(path="C:/tmp/step6_form.png")

        # Debug: show page title and URL
        print(f"  Title: {page.title()}")
        print(f"  URL: {page.url}")

        # Find and fill token name
        # PyPI's token form - look for the token name input
        try:
            # Try multiple selectors for the name field
            name_selectors = [
                'input[name="description"]',
                'input[name="token_name"]',
                'input[id="token_name"]',
                'input[id*="token"]',
                'input[placeholder*="oken"]',
                'input[placeholder*="ame"]',
                'input[type="text"]:not([name="csrf"])',
            ]
            name_input = None
            for sel in name_selectors:
                try:
                    el = page.locator(sel).first
                    el.wait_for(timeout=2000)
                    print(f"  Found name input with: {sel}")
                    name_input = el
                    break
                except:
                    continue

            if name_input:
                name_input.clear()
                name_input.fill("ai-audit-publish")
                print("  Filled token name: ai-audit-publish")
            else:
                print("  Could not find token name input!")
                # List all inputs
                inputs = page.locator('input').all()
                for inp in inputs:
                    print(f"    Input: type={inp.get_attribute('type')}, name={inp.get_attribute('name')}, id={inp.get_attribute('id')}, placeholder={inp.get_attribute('placeholder')}")
        except Exception as e:
            print(f"  Error filling token name: {e}")

        # Scope: Entire account (default, usually pre-selected)
        # PyPI token scope is usually a select or radio
        try:
            # Try select element
            scope = page.locator('select[name="token_scope"]').first
            scope.wait_for(timeout=3000)
            scope.select_option(label="Entire account")
            print("  Selected scope: Entire account")
        except:
            try:
                # Try radio/option
                entire_account = page.locator('input[value*="user"], option:has-text("Entire account")').first
                entire_account.click()
                print("  Clicked Entire account option")
            except:
                print("  Scope might already be set to Entire account (default)")

        page.screenshot(path="C:/tmp/step6_filled.png")

        # Submit the form
        print("[7/8] Submitting token creation form...")
        try:
            submit_btns = [
                'button:has-text("Add token")',
                'input[value="Add token"]',
                'button[type="submit"]',
                'input[type="submit"]',
            ]
            for sel in submit_btns:
                try:
                    btn = page.locator(sel).first
                    btn.wait_for(timeout=2000)
                    print(f"  Found submit button: {sel}")
                    btn.click()
                    break
                except:
                    continue
        except Exception as e:
            print(f"  Submit error: {e}")

        print("[8/8] Waiting for token to appear...")
        time.sleep(4)
        page.screenshot(path="C:/tmp/step8_result.png")
        print(f"  URL: {page.url}")
        print(f"  Title: {page.title()}")

        # Extract token from page
        content = page.content()
        body_text = page.locator('body').text_content() or ""

        # Search for pypi- token
        token_matches = re.findall(r'pypi-[A-Za-z0-9_\-]{50,}', content)
        if not token_matches:
            token_matches = re.findall(r'pypi-[A-Za-z0-9_\-]{50,}', body_text)

        if token_matches:
            print(f"\n{'='*70}")
            print(f"SUCCESS! TOKEN CREATED:")
            for token in token_matches:
                print(f"  {token}")
            print(f"{'='*70}\n")
        else:
            print("  Token not found in page. Trying element selectors...")
            try:
                # Try to find token in specific elements
                token_el = page.locator('code, [class*="token"], input[readonly], textarea[readonly]').all()
                for el in token_el:
                    text = el.text_content() or el.get_attribute("value") or ""
                    if text.startswith("pypi-"):
                        print(f"\n{'='*70}")
                        print(f"TOKEN FOUND: {text}")
                        print(f"{'='*70}\n")
                        break
                else:
                    print("  No token element found")
                    print("  Page content (first 3000 chars):")
                    print(body_text[:3000])
            except Exception as e:
                print(f"  Error: {e}")

        print("\nScreenshots saved to C:/tmp/step*.png")
        input("Press Enter to close browser...")
        browser.close()


if __name__ == "__main__":
    import os
    os.makedirs("C:/tmp", exist_ok=True)
    create_pypi_token()
