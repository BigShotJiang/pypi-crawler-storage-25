"""
Debug script: Capture the full PyPI login page to understand the structure
"""
import os
import re
from playwright.sync_api import sync_playwright

os.makedirs("C:/tmp", exist_ok=True)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False, args=["--start-maximized"])
    context = browser.new_context(viewport={"width": 1280, "height": 1200})
    page = context.new_page()

    print("Loading PyPI login page...")
    page.goto("https://pypi.org/account/login/", wait_until="networkidle")

    # Scroll down to see full page
    page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
    import time; time.sleep(1)
    page.screenshot(path="C:/tmp/debug_full_page.png", full_page=True)

    # Get all links and buttons
    print("\nAll links with href:")
    links = page.locator('a').all()
    for link in links:
        href = link.get_attribute("href") or ""
        text = (link.text_content() or "").strip().replace('\n', ' ')[:60]
        if text or href:
            print(f"  href={href!r:50} text={text!r}")

    print("\nAll buttons:")
    btns = page.locator('button, input[type="submit"]').all()
    for btn in btns:
        btype = btn.get_attribute("type") or ""
        text = (btn.text_content() or "").strip()[:60]
        val = btn.get_attribute("value") or ""
        print(f"  type={btype!r} text={text!r} value={val!r}")

    print("\nAll forms:")
    forms = page.locator('form').all()
    for i, form in enumerate(forms):
        action = form.get_attribute("action") or ""
        method = form.get_attribute("method") or ""
        print(f"  Form {i}: action={action!r} method={method!r}")

    # Get HTML of the page for analysis
    html = page.content()
    # Find all hrefs with google or oauth
    oauth_links = re.findall(r'href=["\']([^"\']*(?:google|oauth|federat|openid)[^"\']*)["\']', html, re.IGNORECASE)
    print(f"\nOAuth/Google links in HTML: {oauth_links}")

    # Find social login sections
    social_section = re.findall(r'(?:social|federat|google|oauth)[^>]{0,200}', html, re.IGNORECASE)
    for s in social_section[:5]:
        print(f"  Social section: {s[:100]}")

    print("\nScreenshot saved to C:/tmp/debug_full_page.png")
    input("Press Enter to close...")
    browser.close()
