"""
Interactive PyPI token creation.
Opens a browser - user logs in manually, then script creates the token automatically.
"""
import os
import re
import time
import sys

os.environ['PYTHONIOENCODING'] = 'utf-8'
os.makedirs("C:/tmp", exist_ok=True)

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

TOKEN_NAME = "ai-audit-publish"

def create_pypi_token():
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=False,
            args=["--start-maximized", "--no-sandbox"]
        )
        context = browser.new_context(viewport={"width": 1280, "height": 900})
        page = context.new_page()

        print("="*60)
        print("PyPI Token Creator")
        print("="*60)
        print(f"\nNavigating to PyPI login...")
        page.goto("https://pypi.org/account/login/", wait_until="networkidle")
        page.screenshot(path="C:/tmp/login_page.png", full_page=False)

        print("\nA browser window has opened.")
        print("Please log in to your PyPI account (sunds.connect@gmail.com)")
        print("After login, the script will automatically create the token.")
        print("\nWaiting for you to log in... (max 3 minutes)")

        # Wait for user to log in - detected by URL change away from login
        try:
            # Wait for navigation away from login page (max 3 min)
            page.wait_for_url(
                lambda url: "login" not in url and "pypi.org" in url,
                timeout=180000
            )
            print(f"\nLogin detected! URL: {page.url}")
        except PlaywrightTimeoutError:
            print("Timeout waiting for login. Trying to proceed anyway...")

        time.sleep(2)
        page.screenshot(path="C:/tmp/after_login.png")
        print(f"Current URL: {page.url}")

        # Navigate to token creation page
        print(f"\nNavigating to token creation page...")
        page.goto("https://pypi.org/manage/account/token/", wait_until="networkidle")
        time.sleep(2)
        page.screenshot(path="C:/tmp/token_page.png")
        print(f"URL: {page.url}")
        print(f"Title: {page.title()}")

        # Check if redirected to login
        if "/account/login" in page.url:
            print("\nStill not logged in! Please complete login in the browser.")
            print("Waiting another 3 minutes...")
            try:
                page.wait_for_url("*manage/account*", timeout=180000)
            except PlaywrightTimeoutError:
                print("Still not logged in after 3 minutes total. Exiting.")
                browser.close()
                return

        print("\nOn token management page!")
        page.screenshot(path="C:/tmp/token_form.png", full_page=True)

        # ---- Fill in the token creation form ----
        print(f"\nFilling token name: {TOKEN_NAME}")

        # Debug: show all inputs on page
        inputs = page.locator('input, select, textarea').all()
        print(f"Found {len(inputs)} form elements:")
        for inp in inputs:
            try:
                tag = inp.evaluate("e => e.tagName")
                itype = inp.get_attribute("type") or ""
                name = inp.get_attribute("name") or ""
                iid = inp.get_attribute("id") or ""
                placeholder = inp.get_attribute("placeholder") or ""
                value = inp.get_attribute("value") or ""
                print(f"  {tag} type={itype!r} name={name!r} id={iid!r} placeholder={placeholder!r} value={value[:30]!r}")
            except:
                pass

        # Try to fill the token description/name field
        # PyPI token form field is "description" based on warehouse source code
        name_filled = False
        for selector in [
            'input[id="token_name"]',
            'input[name="description"]',
            'input[name="token_name"]',
            'input[id="description"]',
            '#token-form input[type="text"]',
            'form input[type="text"]',
        ]:
            try:
                el = page.locator(selector).first
                if el.count() > 0:
                    el.scroll_into_view_if_needed()
                    el.clear()
                    el.fill(TOKEN_NAME)
                    print(f"  Filled with selector: {selector}")
                    name_filled = True
                    break
            except:
                continue

        if not name_filled:
            print("  WARNING: Could not find token name field!")
            # Try to find any text input
            text_inputs = page.locator('input[type="text"]').all()
            print(f"  Text inputs found: {len(text_inputs)}")
            if text_inputs:
                text_inputs[0].fill(TOKEN_NAME)
                print(f"  Filled first text input")
                name_filled = True

        # Scope: Entire account (value is "scope:user" in PyPI warehouse)
        print("Setting scope to 'Entire account'...")
        scope_set = False
        for selector in [
            'select[name="token_scope"]',
            'select[id="token_scope"]',
            'select[name="scope"]',
        ]:
            try:
                el = page.locator(selector).first
                if el.count() > 0:
                    # Try selecting by value or label
                    try:
                        el.select_option(value="scope:user")
                        print(f"  Set scope by value 'scope:user'")
                        scope_set = True
                        break
                    except:
                        try:
                            el.select_option(label="Entire account")
                            print(f"  Set scope by label 'Entire account'")
                            scope_set = True
                            break
                        except:
                            # Get all options
                            options = el.locator('option').all()
                            print(f"  Select options:")
                            for opt in options:
                                print(f"    value={opt.get_attribute('value')!r} text={opt.text_content()!r}")
            except:
                continue

        if not scope_set:
            print("  Scope might be default (Entire account) or using radio buttons")
            # Check for radio buttons
            radios = page.locator('input[type="radio"]').all()
            for radio in radios:
                val = radio.get_attribute("value") or ""
                label_for = radio.get_attribute("id") or ""
                print(f"  Radio: value={val!r} id={label_for!r}")
                if "user" in val.lower() or "entire" in val.lower() or "account" in val.lower():
                    radio.click()
                    print(f"  Clicked radio: {val}")
                    scope_set = True
                    break

        page.screenshot(path="C:/tmp/token_form_filled.png")
        print("Screenshot saved: C:/tmp/token_form_filled.png")

        # Submit the form
        print("\nSubmitting token creation form...")
        submitted = False
        for selector in [
            'button:has-text("Add token")',
            'input[value="Add token"]',
            'button:has-text("Token hinzuf\u00fcgen")',
            'button[type="submit"]',
            'input[type="submit"]',
        ]:
            try:
                el = page.locator(selector).first
                if el.count() > 0:
                    el.scroll_into_view_if_needed()
                    el.click()
                    print(f"  Clicked submit: {selector}")
                    submitted = True
                    break
            except:
                continue

        if not submitted:
            print("  Could not find submit button, listing all buttons:")
            btns = page.locator('button, input[type="submit"]').all()
            for btn in btns:
                text = (btn.text_content() or "").strip()
                val = btn.get_attribute("value") or ""
                btype = btn.get_attribute("type") or ""
                print(f"  Button: text={text!r} value={val!r} type={btype!r}")

        # Wait for result
        print("\nWaiting for token to appear...")
        time.sleep(5)
        page.screenshot(path="C:/tmp/token_result.png", full_page=True)
        print(f"URL: {page.url}")

        # Extract the token
        content = page.content()
        body_text = page.locator('body').inner_text()

        # Search for pypi- token in page content
        token_matches = re.findall(r'pypi-[A-Za-z0-9_\-]{50,}', content)
        if not token_matches:
            token_matches = re.findall(r'pypi-[A-Za-z0-9_\-]{30,}', body_text)

        if token_matches:
            print(f"\n{'='*70}")
            print(f"SUCCESS! TOKEN CREATED:")
            for token in set(token_matches):
                print(f"\n  {token}")
            print(f"\n{'='*70}")
            # Write token to file
            with open("C:/tmp/pypi_token.txt", "w") as f:
                f.write(token_matches[0])
            print(f"\nToken saved to: C:/tmp/pypi_token.txt")
        else:
            print("\nToken not found in page content!")
            # Try specific element selectors
            for selector in ['code', '[class*="token"]', 'input[readonly]', '.callout-warning code']:
                try:
                    els = page.locator(selector).all()
                    for el in els:
                        text = el.text_content() or el.get_attribute("value") or ""
                        if text and len(text) > 20:
                            print(f"  Element ({selector}): {text[:100]}")
                except:
                    pass

            print("\nPage content (searching for 'pypi'):")
            lines = body_text.split('\n')
            for line in lines:
                if 'pypi' in line.lower() and len(line.strip()) > 5:
                    print(f"  {line.strip()[:200]}")

        print("\nScreenshots:")
        for f in ['login_page', 'after_login', 'token_page', 'token_form', 'token_form_filled', 'token_result']:
            print(f"  C:/tmp/{f}.png")

        input("\nPress Enter to close browser...")
        browser.close()


if __name__ == "__main__":
    create_pypi_token()
