# Codebase Explainer

A production-ready CLI tool to analyze, explain, and audit codebases.

## Features

- **Architecture Analysis**: High-level overview of the project structure.
- **Dependency Mapping**: Visualize how files import each other.
- **Call Graph**: Trace function calls across the entire project.
- **Endpoint Detection**: Automatically find Flask, FastAPI, and Express routes.
- **Gemini Integration**: Uses the `gemini` CLI for intelligent code explanations.
- **HTML Reports**: Generates a beautiful, interactive report.

## Installation

### Via Pip

```bash
pip install .
```

### Via Docker

```bash
docker build -t code-explainer .
```

## Usage

### Analyze a codebase
```bash
code-explainer analyze .
```

### Explain a specific file
```bash
code-explainer explain path/to/file.py
```

### Audit for issues
```bash
code-explainer audit .
```

### List endpoints
```bash
code-explainer endpoints .
```

### Run via Docker
```bash
docker run -v $(pwd):/app code-explainer analyze /app
```

## Requirements

- Python 3.7+
- `gemini` CLI (system-installed) for LLM features.
