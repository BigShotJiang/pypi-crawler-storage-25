from setuptools import setup, find_packages

setup(
    name="codebase-explainer",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "typer",
        "jinja2",
    ],
    entry_points={
        "console_scripts": [
            "code-explainer=code_explainer.cli:app",
        ],
    },
)