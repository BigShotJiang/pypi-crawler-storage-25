import os
import json
from jinja2 import Template

class ReportGenerator:
    def __init__(self, template_path):
        self.template_path = template_path

    def generate(self, data, output_path='report.html'):
        with open(self.template_path, 'r', encoding='utf-8') as f:
            template_content = f.read()
        
        template = Template(template_content)
        
        # Process call_graph keys to strings for JSON serialization
        if 'call_graph' in data:
            serializable_call_graph = {}
            for key, value in data['call_graph'].items():
                str_key = f"{key[0]}::{key[1]}"
                serializable_call_graph[str_key] = [f"{v[0]}::{v[1]}" for v in value]
            data['call_graph'] = serializable_call_graph

        rendered_html = template.render(**data)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(rendered_html)
        
        return os.path.abspath(output_path)
