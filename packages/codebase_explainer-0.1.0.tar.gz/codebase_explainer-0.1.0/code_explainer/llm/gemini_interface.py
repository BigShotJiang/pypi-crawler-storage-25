import subprocess
import shutil
import hashlib
import json
import os

class GeminiInterface:
    def __init__(self, cache_file=".code_explainer_cache.json"):
        self.gemini_path = shutil.which("gemini")
        self.cache_file = cache_file
        self.cache = self._load_cache()

    def _load_cache(self):
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f).get('llm_cache', {})
            except:
                return {}
        return {}

    def _save_cache(self):
        data = {}
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    data = json.load(f)
            except:
                pass
        
        data['llm_cache'] = self.cache
        with open(self.cache_file, 'w') as f:
            json.dump(data, f, indent=2)

    def query(self, prompt: str) -> str:
        prompt_hash = hashlib.md5(prompt.encode()).hexdigest()
        if prompt_hash in self.cache:
            return self.cache[prompt_hash]

        if not self.gemini_path:
            return "Error: 'gemini' CLI not found in PATH."
        
        try:
            result = subprocess.run(
                [self.gemini_path, "-p", prompt],
                capture_output=True,
                text=True,
                check=True
            )
            response = result.stdout.strip()
            self.cache[prompt_hash] = response
            self._save_cache()
            return response
        except subprocess.CalledProcessError as e:
            return f"Error calling gemini CLI: {e.stderr}"

    def explain_file(self, file_path: str, content: str) -> str:
        prompt = f"Explain the purpose and logic of this file ({file_path}):\n\n```\n{content}\n```"
        return self.query(prompt)

    def explain_architecture(self, summary: str) -> str:
        prompt = f"""Based on this codebase summary, explain the overall architecture.
        
        {summary}
        
        Format the output into clear technical sections:
        - Overview
        - Core Components
        - Execution Flow
        - Key Observations

        CRITICAL: DO NOT use any Markdown symbols. 
        - NO bold (**text**)
        - NO bullet points with * or - (use "•" or "1." instead if needed, but prefer simple line breaks)
        - NO Markdown headings (###)

        Output should be CLEAN, PLAIN TEXT that can be safely wrapped in <pre> or structured via simple line breaks in HTML.
        
        No emojis. Concise, scannable, and professional. 
        DO NOT include any introductory or concluding "storytelling" phrases.
        Specifically, NEVER start with "I will analyze the codebase structure..." or similar.
        """
        response = self.query(prompt)
        
        # Sanitize common storytelling phrases if the LLM ignores instructions
        bad_phrases = [
            "I will analyze the codebase structure and key files to provide a technical architectural overview.",
            "I will analyze the codebase structure and key files to provide a technical architecture overview.",
            "Based on the provided summary, I will analyze the codebase structure...",
        ]
        for phrase in bad_phrases:
            response = response.replace(phrase, "").strip()
            
        return response

    def explain_flow(self, flow_data: str) -> str:
        prompt = f"Trace and explain the execution flow for this path:\n\n{flow_data}"
        return self.query(prompt)
