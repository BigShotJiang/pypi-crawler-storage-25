import ast
import re
import os

class EndpointDetector:
    def __init__(self, root_path):
        self.root_path = root_path
        self.endpoints = [] # list of {method, route, file, handler}

    def analyze(self, files):
        for file_path in files:
            if file_path.endswith('.py'):
                self._detect_python_endpoints(file_path)
            elif file_path.endswith('.js') or file_path.endswith('.ts'):
                self._detect_node_endpoints(file_path)
        return self.endpoints

    def _detect_python_endpoints(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read())
            
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    for decorator in node.decorator_list:
                        # Flask: @app.route('/...')
                        if isinstance(decorator, ast.Call) and getattr(decorator.func, 'attr', None) == 'route':
                            route = decorator.args[0].value if decorator.args and isinstance(decorator.args[0], ast.Constant) else "unknown"
                            methods = "GET" # default
                            for keyword in decorator.keywords:
                                if keyword.arg == 'methods':
                                    if isinstance(keyword.value, ast.List):
                                        methods = ",".join([m.value for m in keyword.value.elts if isinstance(m, ast.Constant)])
                            
                            self.endpoints.append({
                                'method': methods,
                                'route': route,
                                'file': file_path,
                                'handler': node.name
                            })
                        
                        # FastAPI: @app.get('/...')
                        elif isinstance(decorator, ast.Call) and getattr(decorator.func, 'attr', None) in ['get', 'post', 'put', 'delete', 'patch']:
                            method = decorator.func.attr.upper()
                            route = decorator.args[0].value if decorator.args and isinstance(decorator.args[0], ast.Constant) else "unknown"
                            self.endpoints.append({
                                'method': method,
                                'route': route,
                                'file': file_path,
                                'handler': node.name
                            })
        except Exception:
            pass

    def _detect_node_endpoints(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Simple regex for Express: app.get('/...', (req, res) => { ... })
            # Matches app.get, router.post, etc.
            pattern = r'(?:app|router)\.(get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]'
            matches = re.finditer(pattern, content)
            for match in matches:
                self.endpoints.append({
                    'method': match.group(1).upper(),
                    'route': match.group(2),
                    'file': file_path,
                    'handler': 'anonymous/callback'
                })
        except Exception:
            pass
