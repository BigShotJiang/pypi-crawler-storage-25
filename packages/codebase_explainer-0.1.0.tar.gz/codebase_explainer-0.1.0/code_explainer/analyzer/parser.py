import os

class RepoParser:
    def __init__(self, root_path, scope='recursive'):
        self.root_path = os.path.abspath(root_path)
        self.scope = scope
        self.ignore_dirs = {'.git', 'node_modules', 'venv', '__pycache__'}

    def get_files(self):
        files_list = []
        if self.scope == 'current':
            for entry in os.scandir(self.root_path):
                if entry.is_file():
                    files_list.append(entry.path)
        else: # recursive
            for root, dirs, files in os.walk(self.root_path):
                # Prune ignored directories
                dirs[:] = [d for d in dirs if d not in self.ignore_dirs]
                for file in files:
                    files_list.append(os.path.join(root, file))
        return files_list

    def read_file(self, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return ""

    def detect_entry_points(self, files):
        entry_points = []
        for file_path in files:
            name = os.path.basename(file_path)
            if name in ['main.py', 'app.py', 'index.js']:
                entry_points.append(file_path)
            
            # Check for __main__ blocks in Python files
            if file_path.endswith('.py'):
                content = self.read_file(file_path)
                if 'if __name__ == "__main__":' in content or "if __name__ == '__main__':" in content:
                    if file_path not in entry_points:
                        entry_points.append(file_path)
        return entry_points
