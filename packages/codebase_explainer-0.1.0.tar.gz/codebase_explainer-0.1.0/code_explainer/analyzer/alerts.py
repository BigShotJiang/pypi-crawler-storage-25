import os

class AlertSystem:
    def __init__(self):
        self.alerts = []

    def _should_ignore(self, file_path):
        ignore_patterns = ['__init__.py', 'setup.py', 'build/', '.egg-info']
        for pattern in ignore_patterns:
            if pattern in file_path:
                return True
        return False

    def run_checks(self, files, dependencies, circular_deps, entry_points):
        # Pre-filter files
        filtered_files = [f for f in files if not self._should_ignore(f)]
        
        self._check_circular_dependencies(circular_deps)
        self._check_large_files(filtered_files)
        self._check_unused_files(filtered_files, dependencies, entry_points)
        self._check_missing_entry_points(entry_points)
        self._check_highly_coupled_modules(dependencies)
        return self.alerts

    def _check_circular_dependencies(self, circular_deps):
        for circle in circular_deps:
            # Filter circle to ignore files we don't care about
            filtered_circle = [f for f in circle if not self._should_ignore(f)]
            if len(filtered_circle) > 1:
                self.alerts.append({
                    'type': 'Circular Dependency',
                    'files': filtered_circle,
                    'explanation': f"Circular dependency detected between modules: {' -> '.join([os.path.basename(f) for f in filtered_circle])}"
                })

    def _check_large_files(self, files, threshold=500):
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    if len(lines) > threshold:
                        self.alerts.append({
                            'type': 'Large File',
                            'files': [file_path],
                            'explanation': f"File '{os.path.basename(file_path)}' has {len(lines)} lines, exceeding threshold of {threshold}. Consider refactoring."
                        })
            except Exception:
                pass

    def _check_unused_files(self, files, dependencies, entry_points):
        all_imported = set()
        for imports in dependencies.values():
            for imp in imports:
                all_imported.add(imp)
        
        for file_path in files:
            if file_path.endswith('.py') and \
               file_path not in all_imported and file_path not in entry_points:
                self.alerts.append({
                    'type': 'Unused File',
                    'files': [file_path],
                    'explanation': f"File '{os.path.basename(file_path)}' is not imported by any other module and is not a detected entry point."
                })

    def _check_missing_entry_points(self, entry_points):
        if not entry_points:
            self.alerts.append({
                'type': 'Missing Entry Point',
                'files': [],
                'explanation': "No common entry points (main.py, app.py, cli.py) detected in the project."
            })

    def _check_highly_coupled_modules(self, dependencies, threshold=10):
        for file_path, imports in dependencies.items():
            if self._should_ignore(file_path):
                continue
            if len(imports) > threshold:
                self.alerts.append({
                    'type': 'Highly Coupled Module',
                    'files': [file_path],
                    'explanation': f"Module '{os.path.basename(file_path)}' imports {len(imports)} other modules, suggesting high coupling."
                })
