import ast
import os

class CallGraphAnalyzer:
    def __init__(self, root_path):
        self.root_path = root_path
        self.call_graph = {} # (file, function) -> list of called (file, function)
        self.function_map = {} # function_name -> file

    def analyze(self, files):
        python_files = [f for f in files if f.endswith('.py')]
        
        # Phase 1: Map function names to their files
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        self.function_map[node.name] = file_path
            except Exception:
                pass

        # Phase 2: Map function calls
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    tree = ast.parse(f.read())
                
                current_func = None
                for node in ast.walk(tree):
                    if isinstance(node, ast.FunctionDef):
                        current_func = node.name
                        self.call_graph[(file_path, current_func)] = []
                        for child in ast.walk(node):
                            if isinstance(child, ast.Call):
                                if isinstance(child.func, ast.Name):
                                    called_func = child.func.id
                                    if called_func in self.function_map:
                                        self.call_graph[(file_path, current_func)].append(
                                            (self.function_map[called_func], called_func)
                                        )
                                elif isinstance(child.func, ast.Attribute):
                                    called_func = child.func.attr
                                    if called_func in self.function_map:
                                        self.call_graph[(file_path, current_func)].append(
                                            (self.function_map[called_func], called_func)
                                        )
            except Exception:
                pass
        
        return self.call_graph
