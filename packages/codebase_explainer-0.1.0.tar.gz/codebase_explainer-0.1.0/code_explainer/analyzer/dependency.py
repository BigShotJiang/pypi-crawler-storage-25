import ast
import os

class DependencyAnalyzer:
    def __init__(self, root_path):
        self.root_path = root_path
        self.dependencies = {} # file -> list of imported files

    def analyze(self, files):
        python_files = [f for f in files if f.endswith('.py')]
        for file_path in python_files:
            imports = self._get_python_imports(file_path)
            resolved_imports = self._resolve_imports(file_path, imports, python_files)
            self.dependencies[file_path] = resolved_imports
        return self.dependencies

    def _get_python_imports(self, file_path):
        imports = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read())
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.append(node.module)
        except Exception:
            pass
        return imports

    def _resolve_imports(self, current_file, imports, all_files):
        resolved = []
        for imp in imports:
            # Simple resolution logic: try to find a file that matches the import path
            imp_path = imp.replace('.', os.sep)
            for f in all_files:
                if f.endswith(f"{imp_path}.py") or f.endswith(f"{imp_path}/__init__.py"):
                    resolved.append(f)
        return list(set(resolved))

    def detect_circular_dependencies(self):
        circles = []
        visited = set()
        stack = []

        def visit(node, path):
            if node in stack:
                circles.append(path[stack.index(node):] + [node])
                return
            if node in visited:
                return
            
            visited.add(node)
            stack.append(node)
            for neighbor in self.dependencies.get(node, []):
                visit(neighbor, path + [node])
            stack.pop()

        for node in self.dependencies:
            if node not in visited:
                visit(node, [])
        
        return circles

    def _get_node_color(self, file_path):
        rel_path = os.path.relpath(file_path, self.root_path)
        if "cli.py" in rel_path or rel_path.endswith("main.py") or rel_path.endswith("app.py"):
            return "#3b82f6" # blue: CLI / entry
        if "analyzer" in rel_path:
            return "#10b981" # green: Analyzer
        if "llm" in rel_path:
            return "#a855f7" # purple: LLM
        if "report" in rel_path:
            return "#f97316" # orange: Report
        return "#64748b" # gray: Unknown

    def to_dot(self, edge_threshold=50):
        dot = [
            "digraph G {",
            "  rankdir=LR;",
            "  node [shape=box, style=\"filled,rounded\", fontname=\"Inter, Arial\", fontcolor=\"#ffffff\", color=\"transparent\"];",
            "  edge [color=\"#475569\", penwidth=0.5];",
            "  bgcolor=\"transparent\";",
            "  compound=true;"
        ]

        # Group by directory
        clusters = {}
        for file in self.dependencies:
            rel_path = os.path.relpath(file, self.root_path)
            dirname = os.path.dirname(rel_path)
            if dirname not in clusters:
                clusters[dirname] = []
            clusters[dirname].append(file)

        for i, (dirname, files) in enumerate(clusters.items()):
            cluster_id = f"cluster_{i}"
            label = dirname if dirname else "root"
            dot.append(f'  subgraph "{cluster_id}" {{')
            dot.append(f'    label="{label}";')
            dot.append('    color="#334155";')
            dot.append('    fontcolor="#94a3b8";')
            dot.append('    style="dashed,rounded";')
            
            for file in files:
                node_name = os.path.relpath(file, self.root_path)
                color = self._get_node_color(file)
                dot.append(f'    "{node_name}" [fillcolor="{color}", label="{os.path.basename(file)}"];')
            dot.append('  }')

        # Add edges with threshold check
        total_edges = sum(len(imports) for imports in self.dependencies.values())
        hide_edges = total_edges > edge_threshold

        if not hide_edges:
            for file, imports in self.dependencies.items():
                node_name = os.path.relpath(file, self.root_path)
                for imp in imports:
                    imp_name = os.path.relpath(imp, self.root_path)
                    dot.append(f'  "{node_name}" -> "{imp_name}";')
        else:
            dot.append('  // Edges hidden due to density threshold')

        dot.append("}")
        return "\n".join(dot)
