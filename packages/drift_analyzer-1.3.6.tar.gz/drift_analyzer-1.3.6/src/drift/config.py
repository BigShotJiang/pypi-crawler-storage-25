"""Configuration loading and validation for Drift."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]
from pydantic import BaseModel, ConfigDict, Field, ValidationError


class LayerBoundary(BaseModel):
    """A single layer boundary rule."""

    name: str
    from_pattern: str = Field(alias="from")
    deny_import: list[str] = []

    model_config = ConfigDict(populate_by_name=True, extra="forbid")


class PolicyConfig(BaseModel):
    """Policy configuration for enforcement rules."""

    model_config = ConfigDict(extra="forbid")

    error_handling: dict[str, Any] = Field(default_factory=dict)
    layer_boundaries: list[LayerBoundary] = Field(default_factory=list)
    max_pattern_variants: dict[str, int] = Field(default_factory=dict)
    ai_attribution: dict[str, Any] = Field(default_factory=dict)
    allowed_cross_layer: list[str] = Field(default_factory=list)


class ThresholdsConfig(BaseModel):
    """Tunable thresholds for detection signals."""

    model_config = ConfigDict(extra="forbid")

    high_complexity: int = 10
    medium_complexity: int = 5
    min_function_loc: int = 10
    min_complexity: int = 5
    similarity_threshold: float = 0.80
    recency_days: int = 14
    volatility_z_threshold: float = 1.5
    ai_confidence_threshold: float = 0.50
    bem_min_handlers: int = 3
    tpd_min_test_functions: int = 5
    tpd_min_assertions_per_test: int = 1  # flag zero-assertion tests
    gcd_min_public_functions: int = 3
    gcd_max_nesting_depth: int = 4  # deep nesting threshold per function
    nbv_min_function_loc: int = 3  # ADR-008: ignore trivial stubs
    bat_density_threshold: float = 0.05  # ADR-008: markers per LOC
    bat_min_loc: int = 50  # ADR-008: skip tiny files
    ecm_max_files: int = 50  # ADR-008: perf guardrail
    ecm_lookback_commits: int = 20  # ADR-008: git history depth
    cxs_max_complexity: int = 15  # cognitive complexity threshold per function
    foe_max_imports: int = 15  # fan-out explosion: unique imports threshold
    dca_ignore_re_exports: bool = True  # dead-code: ignore __init__.py re-exports
    max_discovery_files: int = 10000  # safety guardrail for huge repos
    small_repo_module_threshold: int = 15  # adaptive dampening below this
    small_repo_min_findings: int = 2  # per-signal minimum to score

    # Security-by-default thresholds
    hsc_min_entropy: float = 3.5  # Shannon entropy per char for secret detection
    hsc_min_length: int = 16  # minimum string length for entropy-based detection
    maz_public_endpoint_allowlist: list[str] = Field(
        default_factory=lambda: [
            "health",
            "healthcheck",
            "health_check",
            "ping",
            "ready",
            "readiness",
            "liveness",
            "metrics",
            "openapi",
            "docs",
            "redoc",
            "favicon",
            "robots",
            "sitemap",
            "schema",
        ]
    )


class SignalWeights(BaseModel):
    """Weights for each detection signal in composite scoring.

    Weights are normalised internally — they don't need to sum to 1.0,
    but a warning is emitted if they deviate significantly.

    As of v0.7.0 all signals are scoring-active (no report-only signals).
    Previously report-only signals (ADR-007/008) receive conservative
    initial weights; auto-calibration adjusts at runtime.
    """

    model_config = ConfigDict(extra="forbid")

    # Core signals (ablation-validated)
    pattern_fragmentation: float = 0.16
    architecture_violation: float = 0.16
    mutant_duplicate: float = 0.13
    explainability_deficit: float = 0.09
    temporal_volatility: float = 0.13
    system_misalignment: float = 0.08

    # Promoted from report-only (v0.7.0)
    doc_impl_drift: float = 0.04
    broad_exception_monoculture: float = 0.04
    test_polarity_deficit: float = 0.04
    guard_clause_deficit: float = 0.03
    cohesion_deficit: float = 0.01
    naming_contract_violation: float = 0.04
    bypass_accumulation: float = 0.03
    exception_contract_drift: float = 0.03
    co_change_coupling: float = 0.005

    # New signals — report-only until precision/recall validated
    ts_architecture: float = 0.0
    cognitive_complexity: float = 0.0
    fan_out_explosion: float = 0.0
    circular_import: float = 0.0
    dead_code_accumulation: float = 0.0

    # Security-by-default signals (report-only until precision validated)
    missing_authorization: float = 0.0
    insecure_default: float = 0.0
    hardcoded_secret: float = 0.0

    def as_dict(self) -> dict[str, float]:
        return self.model_dump()


class PathOverride(BaseModel):
    """Per-path configuration overrides.

    Match paths using glob patterns (e.g. ``tests/**``, ``legacy/``).
    More specific patterns take precedence over broader ones.
    """

    model_config = ConfigDict(extra="forbid")

    weights: SignalWeights | None = None
    exclude_signals: list[str] = Field(default_factory=list)
    severity_gate: str | None = None


class DeferredArea(BaseModel):
    """A glob-matched area marked as known technical debt (not excluded).

    Unlike ``exclude``, deferred areas are still analysed.  Findings in
    deferred areas are tagged ``deferred=True`` so CI gates and reports
    can treat them differently.
    """

    model_config = ConfigDict(extra="forbid")

    pattern: str
    reason: str = ""
    review_by: str | None = None  # ISO date or sprint identifier


def _default_includes() -> list[str]:
    """Return default include patterns, auto-extending for TypeScript when available."""
    patterns = ["**/*.py"]
    try:
        from drift.ingestion.ts_parser import tree_sitter_available

        if tree_sitter_available():
            patterns.extend(["**/*.ts", "**/*.tsx", "**/*.js", "**/*.jsx"])
    except ImportError:
        pass
    return patterns


class DriftConfig(BaseModel):
    """Main drift configuration, loaded from drift.yaml."""

    model_config = ConfigDict(extra="forbid")

    include: list[str] = Field(default_factory=_default_includes)
    exclude: list[str] = Field(
        default_factory=lambda: [
            "**/node_modules/**",
            "**/__pycache__/**",
            "**/venv/**",
            "**/.venv/**",
            "**/.git/**",
            "**/dist/**",
            "**/build/**",
            "**/.tox/**",
            "**/*.egg-info/**",
            "**/docs/**",
            "**/docs_src/**",
            "**/examples/**",
            "**/site/**",
        ]
    )
    policies: PolicyConfig = Field(default_factory=PolicyConfig)
    weights: SignalWeights = Field(default_factory=SignalWeights)
    thresholds: ThresholdsConfig = Field(default_factory=ThresholdsConfig)
    cache_dir: str = ".drift-cache"
    fail_on: str = "high"
    context_dampening: float = 0.5
    fail_on_delta: float | None = None
    fail_on_delta_window: int = 5
    auto_calibrate: bool = True
    embeddings_enabled: bool = True
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_batch_size: int = 64
    path_overrides: dict[str, PathOverride] = Field(default_factory=dict)
    deferred: list[DeferredArea] = Field(default_factory=list)

    @staticmethod
    def _find_config_file(repo_path: Path) -> Path | None:
        for name in ("drift.yaml", "drift.yml", ".drift.yaml"):
            candidate = repo_path / name
            if candidate.exists():
                return candidate
        # TOML config files (lower priority than YAML)
        drift_toml = repo_path / "drift.toml"
        if drift_toml.exists():
            return drift_toml
        pyproject = repo_path / "pyproject.toml"
        if pyproject.exists():
            return pyproject
        return None

    @classmethod
    def _load_toml(cls, config_path: Path) -> DriftConfig:
        """Load configuration from a TOML file (drift.toml or pyproject.toml)."""
        import tomllib

        raw = config_path.read_bytes()
        try:
            # Accept UTF-8 BOM to avoid first-run failures on editor-generated TOML files.
            data = tomllib.loads(raw.decode("utf-8-sig"))
        except Exception as exc:
            from drift.errors import DriftConfigError

            raise DriftConfigError(
                "DRIFT-1002",
                config_path=str(config_path),
                reason=str(exc),
                line="?",
                context=None,
            ) from exc

        # For pyproject.toml, extract [tool.drift] section
        if config_path.name == "pyproject.toml":
            data = data.get("tool", {}).get("drift", {})
            if not data:
                return cls()

        try:
            return cls.model_validate(data)
        except ValidationError as exc:
            from drift.errors import DriftConfigError

            first: Any = exc.errors()[0] if exc.errors() else None
            loc = first.get("loc", ()) if first else ()
            field_path = ".".join(str(s) for s in loc) if loc else "unknown"
            reason = str(first.get("msg", str(exc))) if first else str(exc)
            raise DriftConfigError(
                "DRIFT-1001",
                config_path=str(config_path),
                field=field_path,
                reason=reason,
                line="?",
                context=None,
            ) from exc

    @classmethod
    def load(cls, repo_path: Path, config_path: Path | None = None) -> DriftConfig:
        if config_path is None:
            config_path = cls._find_config_file(repo_path)

        if config_path and config_path.exists():
            if config_path.suffix == ".toml":
                return cls._load_toml(config_path)

            raw = config_path.read_text(encoding="utf-8")

            try:
                data = yaml.safe_load(raw) or {}
            except yaml.YAMLError as exc:
                from drift.errors import DriftConfigError, yaml_context_snippet

                line = getattr(exc, "problem_mark", None)
                parse_lineno = (line.line + 1) if line else 1
                parse_context = yaml_context_snippet(raw, parse_lineno)
                raise DriftConfigError(
                    "DRIFT-1002",
                    config_path=str(config_path),
                    reason=str(exc),
                    line=parse_lineno,
                    context=parse_context,
                ) from exc

            try:
                return cls.model_validate(data)
            except ValidationError as exc:
                from drift.errors import (
                    DriftConfigError,
                    _find_yaml_line,
                    yaml_context_snippet,
                )

                first: Any = exc.errors()[0] if exc.errors() else None
                loc = first.get("loc", ()) if first else ()
                field_path = ".".join(str(s) for s in loc) if loc else "unknown"
                reason = str(first.get("msg", str(exc))) if first else str(exc)
                validation_lineno = _find_yaml_line(raw, loc) if loc else None
                validation_context = (
                    yaml_context_snippet(raw, validation_lineno or 1) if raw else None
                )
                raise DriftConfigError(
                    "DRIFT-1001",
                    config_path=str(config_path),
                    field=field_path,
                    reason=reason,
                    line=validation_lineno or "?",
                    context=validation_context,
                ) from exc

        return cls()

    def severity_gate(self) -> str:
        return self.fail_on


# ---------------------------------------------------------------------------
# Signal abbreviation map & CLI filter helpers
# ---------------------------------------------------------------------------

SIGNAL_ABBREV: dict[str, str] = {
    "PFS": "pattern_fragmentation",
    "AVS": "architecture_violation",
    "MDS": "mutant_duplicate",
    "EDS": "explainability_deficit",
    "TVS": "temporal_volatility",
    "SMS": "system_misalignment",
    "DIA": "doc_impl_drift",
    "BEM": "broad_exception_monoculture",
    "TPD": "test_polarity_deficit",
    "GCD": "guard_clause_deficit",
    "COD": "cohesion_deficit",
    "NBV": "naming_contract_violation",
    "BAT": "bypass_accumulation",
    "ECM": "exception_contract_drift",
    "CCC": "co_change_coupling",
    "TSA": "ts_architecture",
    "CXS": "cognitive_complexity",
    "FOE": "fan_out_explosion",
    "CIR": "circular_import",
    "DCA": "dead_code_accumulation",
    "MAZ": "missing_authorization",
    "ISD": "insecure_default",
    "HSC": "hardcoded_secret",
}


def resolve_signal_names(raw: str) -> list[str]:
    """Resolve comma-separated signal IDs (abbreviations or full names) to full names.

    Raises ValueError for unknown signal IDs.
    """
    all_known = set(SignalWeights.model_fields.keys())
    result: list[str] = []
    for token in raw.split(","):
        token = token.strip()
        if not token:
            continue
        upper = token.upper()
        if upper in SIGNAL_ABBREV:
            result.append(SIGNAL_ABBREV[upper])
        elif token.lower() in all_known:
            result.append(token.lower())
        else:
            abbrevs = ", ".join(sorted(SIGNAL_ABBREV))
            raise ValueError(
                f"Unknown signal: {token!r}. "
                f"Use abbreviations ({abbrevs}) or full names."
            )
    return result


def apply_signal_filter(
    cfg: DriftConfig,
    select: str | None,
    ignore: str | None,
) -> None:
    """Modify config weights based on --select / --ignore CLI flags.

    --select: only these signals are active (all others set to weight 0).
    --ignore: these signals are deactivated (weight 0).
    If both are given, --select is applied first, then --ignore removes
    from the selected set.
    """
    if select:
        selected = set(resolve_signal_names(select))
        for key in SignalWeights.model_fields:
            if key not in selected:
                setattr(cfg.weights, key, 0.0)

    if ignore:
        ignored = set(resolve_signal_names(ignore))
        for key in ignored:
            setattr(cfg.weights, key, 0.0)
