# -*- coding: utf-8 -*-
"""Compression configuration and timing utilities."""

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


class _CompactionTimer:
    """Timer for compaction phases."""

    __slots__ = ("_stage_durations", "_current_stage", "_current_start")

    def __init__(self) -> None:
        self._stage_durations: dict[str, float] = {}
        self._current_stage: str | None = None
        self._current_start: float = 0.0

    def start(self, phase: str) -> None:
        import time as _time
        self._current_stage = phase
        self._current_start = _time.monotonic()

    def stop(self, phase: str) -> float:
        import time as _time
        if phase and self._current_stage == phase:
            elapsed = _time.monotonic() - self._current_start
            self._stage_durations[phase] = round(elapsed * 1000, 1)
            self._current_stage = None
            return elapsed
        return 0.0

    def start_stage(self, stage_name: str) -> None:
        import time as _time
        self._current_stage = stage_name
        self._current_start = _time.monotonic()

    def end_stage(self) -> None:
        import time as _time
        if self._current_stage is not None:
            elapsed = _time.monotonic() - self._current_start
            self._stage_durations[self._current_stage] = round(elapsed * 1000, 1)
            self._current_stage = None

    def get_phase_times(self) -> dict[str, float]:
        return dict(self._stage_durations)


def _log_compaction_performance(
    timer: _CompactionTimer,
    original_tokens: int,
    final_tokens: int,
    strategy: str,
) -> None:
    """Log compaction performance metrics."""
    phase_times = timer.get_phase_times()
    ratio = final_tokens / max(original_tokens, 1)
    logger.info(
        "[CompactionPerf] strategy=%s original=%d final=%d ratio=%.2f phases=%s",
        strategy, original_tokens, final_tokens, ratio, phase_times,
    )


class _CompressionLevel:
    """Compression level configuration."""

    CONFIGS = {
        "light": {
            "max_summary_ratio": 0.7,
            "keep_recent": 10,
            "enable_semantic": False,
            "enable_recycle": True,
        },
        "medium": {
            "max_summary_ratio": 0.5,
            "keep_recent": 6,
            "enable_semantic": True,
            "enable_recycle": True,
        },
        "heavy": {
            "max_summary_ratio": 0.3,
            "keep_recent": 4,
            "enable_semantic": True,
            "enable_recycle": True,
        },
    }

    @staticmethod
    def get_config(level: str) -> Dict[str, Any]:
        return _CompressionLevel.CONFIGS.get(level, _CompressionLevel.CONFIGS["medium"])
