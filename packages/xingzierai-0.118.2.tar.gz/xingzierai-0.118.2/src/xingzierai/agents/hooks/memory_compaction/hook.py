# -*- coding: utf-8 -*-
"""Memory compaction hook - main orchestrator."""

from __future__ import annotations

import asyncio
import json
import logging
import re as _re
from typing import TYPE_CHECKING, Any

from xingzierai.agentscope_core.agent import ReActAgent
from xingzierai.agentscope_core.message import Msg, TextBlock
from ...utils import get_xingzierai_token_counter
from ....config.config import load_agent_config
from .text_utils import (
    _ANCHOR_PATTERNS, _FILE_PATH_PATTERN, _URL_PATTERN, _CODE_REF_PATTERN,
    _extract_anchors, _deduplicate_anchors, _validate_anchors,
    _messages_to_text, _apply_density_gradient,
)
from .compression_config import (
    _CompactionTimer, _log_compaction_performance, _CompressionLevel,
)

if TYPE_CHECKING:
    from ...memory import MemoryManager
    from xingzierai.reme_sdk.reme.memory.file_based import ReMeInMemoryMemory

logger = logging.getLogger(__name__)

class MemoryCompactionHook:

    """Hook for automatic memory compaction when context is full.



    Ported and enhanced from QwenPaw's LightContextManager.pre_reasoning().



    Key improvements over the old version:

    - Uses mark_messages_compressed() to actually REMOVE messages from memory

    - Uses context_check() for proper tool_use/tool_result ID alignment

    - Has a robust fallback with larger reserve when compaction fails

    - Validates summary format before accepting

    """



    _instances: list["MemoryCompactionHook"] = []

    MAX_INSTANCES = 20



    def __init__(self, memory_manager: "MemoryManager"):

        self.memory_manager = memory_manager

        self._last_compact_hash = None

        self._last_compact_result = None

        self._pressure_history: list[float] = []

        self._summary_version = 0

        self._warning_sent = False

        self._metrics = {

            "total_compactions": 0,

            "emergency_compactions": 0,

            "total_msgs_compacted": 0,

            "anchor_preservation_scores": [],

            "compression_ratios": [],

            "compaction_costs": [],

            "total_tokens_recycled": 0,

        }

        self._last_compaction_timestamp: float | None = None

        self._current_context_pressure: float = 0.0

        self._telemetry_buffer: list[dict] = []

        self._ab_test_config: dict = {

            "enabled": False,

            "variant": "A",

            "test_id": None,

        }

        self._ab_test_results: dict[str, list[dict]] = {

            "A": [],

            "B": [],

        }

        self._snapshots: list[dict] = []

        self._event_subscribers: dict[str, list[Any]] = {}

        self._token_growth_history: list[int] = []

        self._optimization_log: list[dict] = []

        self._benchmark_history: list[dict] = []

        self._auto_selected_strategy: str | None = None

        self._learning_buffer: list[dict] = []

        self._MAX_LEARNING_BUFFER = 200

        self._predictive_cache: dict[str, str] = {}

        self._MAX_PREDICTIVE_CACHE = 20

        self._predictive_cache_hits = 0

        self._predictive_cache_misses = 0

        self._parameter_adjustments: dict[str, Any] = {

            "summary_max_tokens_factor": 1.0,

            "keep_recent_delta": 0,

            "max_input_chars_factor": 1.0,

            "density_bias": 0.0,

            "anchor_weight": 1.0,

        }

        self._adjustment_history: list[dict] = []

        self._MAX_ADJUSTMENT_HISTORY = 50

        self._expected_quality: float = 0.6

        self._circuit_breaker: dict[str, Any] = {

            "state": "closed",

            "failure_count": 0,

            "failure_threshold": 3,

            "open_until": 0.0,

            "reset_timeout_seconds": 300,

            "last_failure_time": None,

            "total_opens": 0,

        }

        self._compression_quality_tracker: list[dict] = []

        self._MAX_QUALITY_TRACKER = 100

        self._stage_timeouts: dict[str, float] = {

            "init": 5.0,

            "token_counting": 10.0,

            "emergency_compaction": 15.0,

            "model_dispatch": 60.0,

            "post_processing": 10.0,

            "validation": 5.0,

        }

        self._fallback_chain: list[str] = [

            "local", "free", "llm", "emergency", "graceful_degradation",

        ]

        self._memory_monitor: dict[str, Any] = {

            "max_compaction_memory_mb": 100,

            "last_check_rss_mb": 0,

            "abort_count": 0,

        }

        self._conversation_lengths: list[int] = []

        self._MAX_CONVERSATION_LENGTHS = 20

        MemoryCompactionHook._instances.append(self)

        if len(MemoryCompactionHook._instances) > MemoryCompactionHook.MAX_INSTANCES:

            MemoryCompactionHook._instances = MemoryCompactionHook._instances[-MemoryCompactionHook.MAX_INSTANCES:]



    @staticmethod

    def _get_compression_config(pressure: float) -> dict:

        if pressure < 1.5:

            level = _CompressionLevel.LEVEL_1

        elif pressure <= 2.5:

            level = _CompressionLevel.LEVEL_2

        else:

            level = _CompressionLevel.LEVEL_3

        config = dict(_CompressionLevel.CONFIGS[level])

        config["level"] = level

        config["pressure"] = pressure

        return config



    def _record_conversation_length(self, message_count: int) -> None:

        self._conversation_lengths.append(message_count)

        if len(self._conversation_lengths) > self._MAX_CONVERSATION_LENGTHS:

            self._conversation_lengths = self._conversation_lengths[-self._MAX_CONVERSATION_LENGTHS:]



    def _get_adaptive_threshold(self, base_threshold: int) -> int:

        if not self._conversation_lengths:

            return base_threshold

        avg_length = sum(self._conversation_lengths) / len(self._conversation_lengths)

        if avg_length > 50:

            factor = 1.2

        elif avg_length < 10:

            factor = 0.9

        else:

            factor = 1.0

        return int(base_threshold * factor)



    @staticmethod

    def _deduplicate_messages(messages: list) -> tuple[list, int]:

        if not messages:

            return messages, 0

        import difflib as _diff_lib

        seen: list[tuple[str, str]] = []

        deduplicated: list = []

        removed_count = 0

        for msg in messages:

            role = getattr(msg, 'role', '') or ''

            try:

                content = msg.get_text_content() or ""

            except Exception as _gtc_err:

                content = str(getattr(msg, 'content', '') or '')

            content_normalized = content.strip().lower()

            is_dup = False

            for prev_role, prev_content in seen:

                if role != prev_role:

                    continue

                if content_normalized == prev_content:

                    is_dup = True

                    break

                shorter_len = min(len(content_normalized), len(prev_content))

                if shorter_len < 20:

                    continue

                ratio = _diff_lib.SequenceMatcher(

                    None, content_normalized, prev_content,

                ).quick_ratio()

                if ratio > 0.8:

                    is_dup = True

                    break

            if is_dup:

                removed_count += 1

            else:

                deduplicated.append(msg)

                seen.append((role, content_normalized))

        return deduplicated, removed_count



    def take_snapshot(self, memory: Any) -> dict:

        import time as _snap_time

        snapshot: dict = {

            "timestamp": _snap_time.time(),

            "message_count": 0,

            "summary": "",

            "pressure": self._current_context_pressure,

            "metrics": dict(self._metrics),

            "pressure_history": list(self._pressure_history),

        }

        try:

            messages = []

            if hasattr(memory, 'content'):

                messages = [msg for msg, _ in memory.content]

            snapshot["message_count"] = len(messages)

        except Exception as _snap_err:

            pass

        try:

            summary = memory.get_compressed_summary() if hasattr(memory, 'get_compressed_summary') else ""

            snapshot["summary"] = summary or ""

        except Exception as _snap2_err:

            snapshot["summary"] = ""

        self._snapshots.append(snapshot)

        if len(self._snapshots) > 5:

            self._snapshots = self._snapshots[-5:]

        return snapshot



    def restore_snapshot(self, memory: Any, snapshot: dict) -> bool:

        if not snapshot:

            return False

        try:

            summary = snapshot.get("summary", "")

            if summary and hasattr(memory, 'update_compressed_summary'):

                if self._is_valid_summary(summary):

                    try:

                        loop = asyncio.get_running_loop()

                        asyncio.ensure_future(memory.update_compressed_summary(summary))

                    except RuntimeError:

                        pass

            self._current_context_pressure = snapshot.get("pressure", 0.0)

            saved_history = snapshot.get("pressure_history", [])

            if saved_history:

                self._pressure_history = list(saved_history)

            return True

        except Exception as _restore_err:

            logger.debug("[ContextMgr] action=snapshot_restore_failed error=%s", _restore_err)

            return False



    _VALID_EVENT_TYPES = frozenset({

        "compaction_started", "compaction_completed", "compaction_failed",

        "emergency_triggered", "anchor_lost", "summary_refreshed",

    })



    def _emit_event(self, event_type: str, details: dict | None = None) -> None:

        if event_type not in self._VALID_EVENT_TYPES:

            return

        import time as _evt_time

        event = {

            "timestamp": _evt_time.time(),

            "event_type": event_type,

            "details": details or {},

        }

        callbacks = self._event_subscribers.get(event_type, [])

        for cb in callbacks:

            try:

                cb(event)

            except Exception as _cb_err:

                logger.debug("[ContextMgr] action=event_callback_error error=%s", _cb_err)



    def subscribe(self, event_type: str, callback: Any) -> None:

        if event_type not in self._VALID_EVENT_TYPES:

            logger.warning("[ContextMgr] action=subscribe_unknown_event type=%s", event_type)

            return

        if event_type not in self._event_subscribers:

            self._event_subscribers[event_type] = []

        self._event_subscribers[event_type].append(callback)



    @classmethod

    def get_latest_instance(cls) -> "MemoryCompactionHook | None":

        return cls._instances[-1] if cls._instances else None



    def _smart_truncate(

        self,

        messages: list,

        max_tokens: int,

        token_counts: list[int],

    ) -> list:

        """Smart truncation that preserves the most important content.



        Used as a last resort before emergency compaction. Uses priority

        scoring to determine what to keep vs. truncate.



        Never truncates:

        - System messages

        - The last user message

        - Active tool calls (tool_use with pending tool_result)



        Prefer truncating:

        - Old tool results

        - Acknowledgments ("Sure, I'll help", "Let me check that")

        - Repeated/duplicate content



        Args:

            messages: Full message list.

            max_tokens: Maximum token budget.

            token_counts: Token count for each message.



        Returns:

            Truncated message list within budget.

        """

        if not messages or len(messages) != len(token_counts):

            return list(messages) if messages else []



        total_tokens = sum(token_counts)

        if total_tokens <= max_tokens:

            return list(messages)



        protected_indices: set[int] = set()

        for i, msg in enumerate(messages):

            role = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

            else:

                role = getattr(msg, "role", "")

            if role == "system":

                protected_indices.add(i)



        for i in range(len(messages) - 1, -1, -1):

            role = ""

            if isinstance(messages[i], dict):

                role = messages[i].get("role", "")

            else:

                role = getattr(messages[i], "role", "")

            if role == "user":

                protected_indices.add(i)

                break



        tool_use_ids: set[str] = set()

        tool_result_ids: set[str] = set()

        for i, msg in enumerate(messages):

            content = None

            if isinstance(msg, dict):

                content = msg.get("content", "")

                role = msg.get("role", "")

            else:

                content = getattr(msg, "content", "")

                role = getattr(msg, "role", "")

            if isinstance(content, list):

                for block in content:

                    if isinstance(block, dict):

                        if block.get("type") == "tool_use":

                            tid = block.get("id", "")

                            if tid:

                                tool_use_ids.add(tid)

                                protected_indices.add(i)

                        elif block.get("type") == "tool_result":

                            tuid = block.get("tool_use_id", "")

                            if tuid:

                                tool_result_ids.add(tuid)

            if role == "tool":

                if isinstance(msg, dict):

                    tuid = msg.get("tool_call_id", "")

                else:

                    tuid = getattr(msg, "tool_call_id", "")

                if tuid and tuid in tool_use_ids:

                    protected_indices.add(i)



        priority_scores: list[tuple[float, int]] = []

        for i, msg in enumerate(messages):

            if i in protected_indices:

                priority_scores.append((100.0, i))

                continue



            role = ""

            text = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)



            score = 50.0



            recency_bonus = (i / max(1, len(messages) - 1)) * 20.0

            score += recency_bonus



            if role == "user":

                score += 15.0

            elif role == "assistant":

                score += 5.0

            elif role == "tool":

                score -= 10.0



            text_lower = text.lower()

            ack_patterns = [

                "i'll help you", "let me check", "sure,", "sure!",

                "i can help", "of course", "certainly",

                "我来帮你", "让我看看", "好的",

            ]

            if any(p in text_lower for p in ack_patterns):

                score -= 20.0



            if len(text) < 30:

                score -= 10.0



            important_keywords = [

                "error", "错误", "exception", "failed", "失败",

                "decision", "决定", "file_path", "filepath",

                "must", "必须", "never", "绝不", "important", "重要",

            ]

            if any(kw in text_lower for kw in important_keywords):

                score += 15.0



            if _FILE_PATH_PATTERN.search(text):

                score += 10.0

            if _URL_PATTERN.search(text):

                score += 5.0



            priority_scores.append((score, i))



        priority_scores.sort(key=lambda x: x[0], reverse=True)



        kept_indices: set[int] = set()

        current_tokens = 0

        for score, idx in priority_scores:

            if idx in protected_indices:

                kept_indices.add(idx)

                current_tokens += token_counts[idx]

            elif current_tokens + token_counts[idx] <= max_tokens:

                kept_indices.add(idx)

                current_tokens += token_counts[idx]



        for idx in protected_indices:

            if idx not in kept_indices:

                kept_indices.add(idx)

                current_tokens += token_counts[idx]



        result = [messages[i] for i in sorted(kept_indices)]

        removed = len(messages) - len(result)

        if removed > 0:

            logger.info(

                "[ContextMgr] action=smart_truncate original=%d kept=%d removed=%d "

                "budget=%d used=%d protected=%d",

                len(messages), len(result), removed, max_tokens, current_tokens,

                len(protected_indices),

            )

        return result



    def _check_circuit_breaker(self) -> bool:

        """Check if the circuit breaker allows compaction.



        Returns True if compaction is allowed, False if the circuit is open.

        """

        cb = self._circuit_breaker

        if cb["state"] == "open":

            import time as _cb_time

            if _cb_time.time() >= cb["open_until"]:

                cb["state"] = "half-open"

                logger.info(

                    "[ContextMgr] action=circuit_breaker_half_open failures=%d timeout=%ds",

                    cb["failure_count"], cb["reset_timeout_seconds"],

                )

                return True

            return False

        return True



    def _record_circuit_success(self) -> None:

        """Record a successful compaction, resetting the circuit breaker."""

        cb = self._circuit_breaker

        if cb["state"] == "half-open":

            cb["state"] = "closed"

            logger.info("[ContextMgr] action=circuit_breaker_closed")

        cb["failure_count"] = 0



    def _record_circuit_failure(self) -> None:

        """Record a compaction failure, potentially opening the circuit breaker."""

        import time as _cf_time

        cb = self._circuit_breaker

        cb["failure_count"] += 1

        cb["last_failure_time"] = _cf_time.time()



        if cb["failure_count"] >= cb["failure_threshold"]:

            cb["state"] = "open"

            cb["open_until"] = _cf_time.time() + cb["reset_timeout_seconds"]

            cb["total_opens"] += 1

            logger.warning(

                "[ContextMgr] action=circuit_breaker_opened failures=%d threshold=%d "

                "reset_in=%ds total_opens=%d",

                cb["failure_count"], cb["failure_threshold"],

                cb["reset_timeout_seconds"], cb["total_opens"],

            )



    def _check_memory_usage(self) -> bool:

        """Check if compaction is using too much memory.



        Returns True if memory usage is within limits, False if should abort.

        """

        try:

            import resource as _resource

            import sys as _sys

            rusage = _resource.getrusage(_resource.RUSAGE_SELF)

            rss_kb = rusage.ru_maxrss

            if _sys.platform == "darwin":

                rss_mb = rss_kb / (1024.0 * 1024.0)

            else:

                rss_mb = rss_kb / 1024.0

            self._memory_monitor["last_check_rss_mb"] = round(rss_mb, 1)



            if rss_mb > self._memory_monitor["max_compaction_memory_mb"]:

                self._memory_monitor["abort_count"] += 1

                logger.warning(

                    "[ContextMgr] action=memory_abort rss=%.1fMB limit=%dMB aborts=%d",

                    rss_mb, self._memory_monitor["max_compaction_memory_mb"],

                    self._memory_monitor["abort_count"],

                )

                return False

        except ImportError:

            pass

        except Exception as _mem_err:

            logger.debug("[ContextMgr] action=memory_check_failed error=%s", _mem_err)

        return True



    def _get_stage_timeout(self, stage_name: str) -> float:

        """Get the timeout for a specific compaction stage."""

        return self._stage_timeouts.get(stage_name, 30.0)



    async def _retry_with_backoff(

        self,

        fn: Any,

        max_retries: int = 3,

        base_delay: float = 1.0,

        max_delay: float = 30.0,

        stage_name: str = "",

    ) -> Any:

        """Retry an async function with exponential backoff.



        Args:

            fn: Async callable to retry.

            max_retries: Maximum number of retries.

            base_delay: Base delay in seconds.

            max_delay: Maximum delay between retries.

            stage_name: Name of the stage for logging.



        Returns:

            Result of fn().



        Raises:

            Last exception if all retries fail.

        """

        last_exception: Exception | None = None

        for attempt in range(max_retries + 1):

            try:

                return await fn()

            except asyncio.CancelledError:

                raise

            except Exception as e:

                last_exception = e

                if attempt < max_retries:

                    delay = min(base_delay * (2 ** attempt), max_delay)

                    logger.warning(

                        "[ContextMgr] action=retry_backoff stage=%s attempt=%d/%d "

                        "delay=%.1fs error_type=%s",

                        stage_name, attempt + 1, max_retries + 1,

                        delay, type(e).__name__,

                    )

                    await asyncio.sleep(delay)

        raise last_exception  # type: ignore[misc]



    def _evaluate_compaction_quality(

        self,

        summary: str,

        original_messages: list,

        anchors: list[str],

    ) -> float:

        """Evaluate the quality of a compaction result.



        Returns a score from 0.0 to 1.0 based on:

        - Summary quality (structure, length, content)

        - Anchor preservation

        - Cross-validation against original messages

        """

        if not summary or not self._is_valid_summary(summary):

            return 0.0



        quality_score = self._score_summary_quality(summary, len(original_messages))

        anchor_score = _validate_anchors(summary, anchors) if anchors else 1.0

        cv_score = self._cross_validate_summary(summary, original_messages)



        combined = (

            quality_score * 0.4

            + anchor_score * 0.35 * self._parameter_adjustments.get("anchor_weight", 1.0)

            + cv_score * 0.25

        )

        return min(1.0, max(0.0, combined))



    def _adjust_parameters(self, quality_gap: float) -> dict:

        """Adjust compaction parameters based on quality gap.



        Quality gap = expected_quality - actual_quality.

        Positive gap means quality is below expectations → make compaction less aggressive.

        Negative gap means quality exceeds expectations → can be more aggressive.



        Args:

            quality_gap: Difference between expected and actual quality.



        Returns:

            Dict of parameter changes made.

        """

        changes: dict[str, Any] = {}



        if abs(quality_gap) < 0.05:

            return changes



        adj = self._parameter_adjustments



        if quality_gap > 0:

            adj["summary_max_tokens_factor"] = min(

                2.0, adj["summary_max_tokens_factor"] + quality_gap * 0.3,

            )

            changes["summary_max_tokens_factor"] = adj["summary_max_tokens_factor"]



            adj["keep_recent_delta"] = min(

                6, adj["keep_recent_delta"] + 1,

            )

            changes["keep_recent_delta"] = adj["keep_recent_delta"]



            adj["max_input_chars_factor"] = min(

                1.5, adj["max_input_chars_factor"] + quality_gap * 0.2,

            )

            changes["max_input_chars_factor"] = adj["max_input_chars_factor"]



            adj["anchor_weight"] = min(

                2.0, adj["anchor_weight"] + quality_gap * 0.5,

            )

            changes["anchor_weight"] = adj["anchor_weight"]



            if quality_gap > 0.3:

                adj["density_bias"] = max(

                    -0.5, adj["density_bias"] - 0.1,

                )

                changes["density_bias"] = adj["density_bias"]



        else:

            adj["summary_max_tokens_factor"] = max(

                0.5, adj["summary_max_tokens_factor"] + quality_gap * 0.2,

            )

            changes["summary_max_tokens_factor"] = adj["summary_max_tokens_factor"]



            adj["keep_recent_delta"] = max(

                -4, adj["keep_recent_delta"] - 1,

            )

            changes["keep_recent_delta"] = adj["keep_recent_delta"]



            adj["max_input_chars_factor"] = max(

                0.5, adj["max_input_chars_factor"] + quality_gap * 0.1,

            )

            changes["max_input_chars_factor"] = adj["max_input_chars_factor"]



            adj["anchor_weight"] = max(

                0.5, adj["anchor_weight"] + quality_gap * 0.3,

            )

            changes["anchor_weight"] = adj["anchor_weight"]



        import time as _adj_time

        entry = {

            "timestamp": _adj_time.time(),

            "quality_gap": round(quality_gap, 3),

            "changes": dict(changes),

            "current_params": dict(adj),

        }

        self._adjustment_history.append(entry)

        if len(self._adjustment_history) > self._MAX_ADJUSTMENT_HISTORY:

            self._adjustment_history = self._adjustment_history[-self._MAX_ADJUSTMENT_HISTORY:]



        if changes:

            logger.info(

                "[ContextMgr] action=parameter_adjustment quality_gap=%.3f changes=%s",

                quality_gap, list(changes.keys()),

            )



        return changes



    def _apply_adjusted_config(self, base_config: dict) -> dict:

        """Apply parameter adjustments to a base compression config.



        Args:

            base_config: Base configuration from _get_compression_config.



        Returns:

            Adjusted configuration.

        """

        adj = self._parameter_adjustments

        config = dict(base_config)



        config["summary_max_tokens"] = int(

            config["summary_max_tokens"] * adj["summary_max_tokens_factor"],

        )

        config["keep_recent"] = max(

            2, config["keep_recent"] + adj["keep_recent_delta"],

        )

        config["max_input_chars"] = int(

            config["max_input_chars"] * adj["max_input_chars_factor"],

        )



        return config



    def _emergency_compact(

        self,

        messages: list,

        anchors: list[str],

        folded_outcomes: list[str] | None = None,

    ) -> str:

        """Fast emergency compaction without LLM call.



        Used when context pressure is critically high (>2.5x) and we

        can't afford to wait for an LLM summarization. Creates a

        structured summary from message excerpts + anchors + folded outcomes.

        """

        parts = ["## 紧急上下文摘要 / Emergency Context Summary\n"]



        if anchors:

            parts.append("### 关键指令 / Critical Instructions")

            for a in anchors[:15]:

                parts.append(f"- {a}")

            parts.append("")



        if folded_outcomes:

            parts.append("### 工具结果(上下文折叠) / Tool Outcomes (Context-Folded)")

            for o in folded_outcomes[:15]:

                parts.append(f"- {o}")

            if len(folded_outcomes) > 15:

                parts.append(f"- ... and {len(folded_outcomes) - 15} more")

            parts.append("")



        user_msgs = []

        assistant_msgs = []

        tool_msgs = []

        for msg in messages:

            role = ""

            text = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                text = str(msg.get("content", ""))[:200]

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    text = " ".join(

                        c.get("text", "")[:100]

                        for c in content

                        if isinstance(c, dict) and c.get("type") == "text"

                    )[:200]

                else:

                    text = str(content)[:200]



            if role == "user" and text:

                user_msgs.append(text)

            elif role == "assistant" and text:

                assistant_msgs.append(text)

            elif role == "tool" and text:

                tool_msgs.append(text[:100])



        if user_msgs:

            parts.append("### 用户请求 / User Requests")

            for m in user_msgs[:5]:

                parts.append(f"- {m}")

            if len(user_msgs) > 5:

                parts.append(f"- ... and {len(user_msgs) - 5} more")

            parts.append("")



        if assistant_msgs:

            parts.append("### 助手操作 / Assistant Actions")

            for m in assistant_msgs[:5]:

                parts.append(f"- {m}")

            if len(assistant_msgs) > 5:

                parts.append(f"- ... and {len(assistant_msgs) - 5} more")

            parts.append("")



        if tool_msgs:

            parts.append("### 工具结果 / Tool Results")

            for m in tool_msgs[:5]:

                parts.append(f"- {m}")

            if len(tool_msgs) > 5:

                parts.append(f"- ... and {len(tool_msgs) - 5} more")



        return "\n".join(parts)



    @staticmethod

    async def _print_status_message(

        agent: ReActAgent,

        text: str,

    ) -> None:

        msg = Msg(

            name=agent.name,

            role="assistant",

            content=[TextBlock(type="text", text=text)],

        )

        await agent.print(msg)



    @staticmethod

    def _is_valid_summary(content: str) -> bool:

        if not isinstance(content, str) or not content.strip():

            return False

        stripped = content.strip()

        if len(stripped) < 20:

            return False

        if not _re.search(r'[\w\u4e00-\u9fff]', stripped):

            return False

        unique_chars = set(stripped)

        if len(unique_chars) <= 2:

            return False

        return True



    @staticmethod

    def _score_summary_quality(summary: str, original_count: int) -> float:

        if not isinstance(summary, str) or not summary.strip():

            return 0.0

        score = 0.3

        length = len(summary.strip())

        if length < 100:

            score -= 0.15

        elif length > 5000:

            score -= 0.1

        else:

            score += 0.1

        if _re.search(r'^##\s+', summary, _re.MULTILINE):

            score += 0.2

        elif _re.search(r'^[•\-\*]\s+', summary, _re.MULTILINE):

            score += 0.1

        if _FILE_PATH_PATTERN.search(summary):

            score += 0.1

        decision_keywords = ["决定", "decision", "选择", "chose", "resolved", "解决", "方案", "approach", "结论", "conclusion"]

        if any(kw in summary.lower() for kw in decision_keywords):

            score += 0.1

        error_keywords = ["error", "错误", "exception", "failed", "失败", "traceback", "异常", "bug"]

        if any(kw in summary.lower() for kw in error_keywords):

            score += 0.1

        action_keywords = ["执行", "executed", "创建", "created", "修改", "modified", "删除", "deleted", "安装", "installed"]

        if any(kw in summary.lower() for kw in action_keywords):

            score += 0.05

        if original_count > 0:

            compression_ratio = length / max(1, original_count * 200)

            if compression_ratio < 0.5:

                score += 0.1

            elif compression_ratio > 0.8:

                score -= 0.1

        return max(0.0, min(1.0, score))



    def get_metrics(self) -> dict:

        metrics = dict(self._metrics)

        metrics["learning_samples"] = len(self._learning_buffer)

        metrics["benchmark_count"] = len(self._benchmark_history)

        metrics["auto_selected_strategy"] = self._auto_selected_strategy

        metrics["predictive_cache_size"] = len(self._predictive_cache)

        metrics["predictive_cache_hits"] = self._predictive_cache_hits

        metrics["predictive_cache_misses"] = self._predictive_cache_misses

        total_cache_lookups = self._predictive_cache_hits + self._predictive_cache_misses

        metrics["predictive_cache_hit_rate"] = round(

            self._predictive_cache_hits / max(1, total_cache_lookups), 3,

        )

        return metrics



    def get_learning_stats(self) -> dict:

        if not self._learning_buffer:

            return {

                "samples": 0,

                "strategy_distribution": {},

                "model_distribution": {},

                "avg_quality_by_strategy": {},

                "prediction_ready": False,

            }



        strategy_dist: dict[str, int] = {}

        model_dist: dict[str, int] = {}

        quality_by_strategy: dict[str, list[float]] = {}



        for entry in self._learning_buffer:

            s = entry["strategy"]

            m = entry["model"]

            strategy_dist[s] = strategy_dist.get(s, 0) + 1

            model_dist[m] = model_dist.get(m, 0) + 1

            quality_by_strategy.setdefault(s, []).append(entry["quality"])



        avg_quality: dict[str, float] = {}

        for s, scores in quality_by_strategy.items():

            avg_quality[s] = round(sum(scores) / len(scores), 3)



        return {

            "samples": len(self._learning_buffer),

            "strategy_distribution": strategy_dist,

            "model_distribution": model_dist,

            "avg_quality_by_strategy": avg_quality,

            "prediction_ready": len(self._learning_buffer) >= 30,

        }



    def get_health_score(self) -> dict:

        ratios = self._metrics.get("compression_ratios", [])

        anchors = self._metrics.get("anchor_preservation_scores", [])

        telemetry = self._telemetry_buffer



        if ratios:

            avg_ratio = sum(ratios) / len(ratios)

            compression_score = min(25, max(0, int(avg_ratio / 5.0 * 25)))

        else:

            compression_score = 12



        if anchors:

            avg_anchor = sum(anchors) / len(anchors)

            anchor_score = min(25, max(0, int(avg_anchor * 25)))

        else:

            anchor_score = 20



        if telemetry:

            avg_quality = sum(t.get("quality_score", 0.0) for t in telemetry) / len(telemetry)

            quality_score = min(25, max(0, int(avg_quality * 25)))

        else:

            quality_score = 15



        total_compactions = self._metrics.get("total_compactions", 0)

        emergency_compactions = self._metrics.get("emergency_compactions", 0)

        if total_compactions > 0:

            emergency_ratio = emergency_compactions / total_compactions

            fragmentation_score = min(25, max(0, int((1.0 - emergency_ratio) * 25)))

        else:

            fragmentation_score = 25



        total = compression_score + anchor_score + quality_score + fragmentation_score



        if total >= 80:

            level = "Excellent"

        elif total >= 60:

            level = "Good"

        elif total >= 40:

            level = "Fair"

        else:

            level = "Poor"



        learning_samples = len(self._learning_buffer)

        adaptive_confidence = 0.0

        if learning_samples >= 30:

            recent = self._learning_buffer[-10:]

            adaptive_confidence = sum(e["quality"] for e in recent) / len(recent)



        result = {

            "total_score": total,

            "level": level,

            "compression_ratio_score": compression_score,

            "anchor_preservation_score": anchor_score,

            "quality_score": quality_score,

            "fragmentation_score": fragmentation_score,

            "avg_compression_ratio": sum(ratios) / len(ratios) if ratios else 0.0,

            "avg_anchor_preservation": sum(anchors) / len(anchors) if anchors else 0.0,

            "avg_quality": sum(t.get("quality_score", 0.0) for t in telemetry) / len(telemetry) if telemetry else 0.0,

            "emergency_ratio": emergency_compactions / total_compactions if total_compactions > 0 else 0.0,

            "total_tokens_recycled": self._metrics.get("total_tokens_recycled", 0),

            "learning_samples": learning_samples,

            "adaptive_confidence": round(adaptive_confidence, 3),

            "benchmark_count": len(self._benchmark_history),

            "auto_selected_strategy": self._auto_selected_strategy,

        }



        logger.info(

            "[ContextMgr] action=health_score total=%d level=%s compression=%d anchor=%d quality=%d fragmentation=%d recycled=%d learning=%d",

            total, level, compression_score, anchor_score, quality_score, fragmentation_score,

            self._metrics.get("total_tokens_recycled", 0), learning_samples,

        )



        return result



    def get_optimization_suggestions(self) -> list[str]:

        suggestions: list[str] = []

        ratios = self._metrics.get("compression_ratios", [])

        anchors = self._metrics.get("anchor_preservation_scores", [])

        total_compactions = self._metrics.get("total_compactions", 0)

        emergency_compactions = self._metrics.get("emergency_compactions", 0)



        if ratios:

            avg_ratio = sum(ratios) / len(ratios)

            if avg_ratio < 2.0:

                suggestions.append(

                    f"Low compression ratio ({avg_ratio:.1f}x) — consider increasing summary_max_tokens "

                    f"to produce more detailed summaries that better preserve information"

                )



        if anchors:

            avg_anchor = sum(anchors) / len(anchors)

            if avg_anchor < 0.5:

                suggestions.append(

                    f"Low anchor preservation ({avg_anchor:.1%}) — consider adding more anchor patterns "

                    f"to _ANCHOR_PATTERNS to capture critical instructions that are being lost during compaction"

                )



        if total_compactions > 0:

            emergency_ratio = emergency_compactions / total_compactions

            if emergency_ratio > 0.3:

                suggestions.append(

                    f"High emergency compaction rate ({emergency_ratio:.0%}) — consider lowering "

                    f"the compaction threshold to trigger earlier, gentler compaction instead of emergency truncation"

                )



        if self._pressure_history and len(self._pressure_history) >= 3:

            recent_pressures = self._pressure_history[-3:]

            if all(p > 2.0 for p in recent_pressures):

                suggestions.append(

                    f"Sustained high pressure (avg {sum(recent_pressures)/len(recent_pressures):.1f}x) — "

                    f"context is chronically overloaded, consider reducing keep_recent or increasing compaction frequency"

                )



        if self._token_growth_history and len(self._token_growth_history) >= 5:

            recent_growth = self._token_growth_history[-5:]

            growth_deltas = [recent_growth[i] - recent_growth[i - 1] for i in range(1, len(recent_growth))]

            if growth_deltas and all(d > 0 for d in growth_deltas):

                suggestions.append(

                    f"Consistently growing context (+{sum(growth_deltas)} tokens over last 5 checks) — "

                    f"consider more aggressive tool result folding or earlier compaction triggers"

                )



        if not suggestions:

            suggestions.append("Context management is operating within normal parameters — no optimization needed")



        total = self._metrics.get("total_compactions", 0)

        if total > 0 and total % 10 == 0:

            logger.info(

                "[ContextMgr] action=optimization_suggestions compactions=%d suggestions=%s",

                total, suggestions,

            )



        return suggestions



    def _self_optimize(self) -> dict:

        changes: dict = {}



        total_compactions = self._metrics.get("total_compactions", 0)

        if total_compactions < 20 or total_compactions % 20 != 0:

            return changes



        ratios = self._metrics.get("compression_ratios", [])

        anchors = self._metrics.get("anchor_preservation_scores", [])

        emergency = self._metrics.get("emergency_compactions", 0)

        telemetry = self._telemetry_buffer



        if ratios:

            avg_ratio = sum(ratios) / len(ratios)

            if avg_ratio < 2.0:

                for level_key in ("light", "medium", "heavy"):

                    current = _CompressionLevel.CONFIGS[level_key]["summary_max_tokens"]

                    new_val = min(int(current * 1.2), 2048)

                    _CompressionLevel.CONFIGS[level_key]["summary_max_tokens"] = new_val

                changes["summary_max_tokens"] = "increased by 20%"



        if anchors:

            avg_anchor = sum(anchors) / len(anchors)

            if avg_anchor < 0.5:

                new_patterns = ["deadline", "截止", "priority", "优先级", "requirement", "需求"]

                added = [p for p in new_patterns if p not in _ANCHOR_PATTERNS]

                if added:

                    _ANCHOR_PATTERNS.extend(added)

                    changes["anchor_patterns_added"] = added



        if total_compactions > 0:

            emergency_ratio = emergency / total_compactions

            if emergency_ratio > 0.3:

                for level_key in ("light", "medium", "heavy"):

                    current_keep = _CompressionLevel.CONFIGS[level_key]["keep_recent"]

                    new_keep = max(2, current_keep - 1)

                    _CompressionLevel.CONFIGS[level_key]["keep_recent"] = new_keep

                changes["keep_recent"] = "decreased by 1 (lower threshold for earlier compaction)"

            elif ratios and len(ratios) >= 5:

                recent_ratios = ratios[-5:]

                avg_recent = sum(recent_ratios) / len(recent_ratios)

                if avg_recent < 2.0:

                    for level_key in ("light", "medium", "heavy"):

                        current_keep = _CompressionLevel.CONFIGS[level_key]["keep_recent"]

                        new_keep = min(current_keep + 2, 30)

                        _CompressionLevel.CONFIGS[level_key]["keep_recent"] = new_keep

                    changes["keep_recent"] = "increased by 2 (low compression ratio)"



        if changes:

            import time as _opt_time

            entry = {

                "timestamp": _opt_time.time(),

                "compaction_count": total_compactions,

                "changes": changes,

            }

            self._optimization_log.append(entry)

            if len(self._optimization_log) > 20:

                self._optimization_log = self._optimization_log[-20:]



            logger.info(

                "[ContextMgr] action=self_optimize compactions=%d changes=%s",

                total_compactions, changes,

            )



        return changes



    def get_telemetry(self) -> list[dict]:

        return list(self._telemetry_buffer)



    def health_check(self) -> dict:

        import time as _hc_time

        metrics = self.get_metrics()

        total_compactions = metrics.get("total_compactions", 0)

        emergency_compactions = metrics.get("emergency_compactions", 0)

        scores = metrics.get("anchor_preservation_scores", [])

        avg_anchor = sum(scores) / len(scores) if scores else 0.0

        emergency_ratio = emergency_compactions / max(1, total_compactions)

        circuit_state = self._circuit_breaker.get("state", "closed")



        issues: list[str] = []

        if emergency_ratio > 0.5:

            issues.append("high_emergency_ratio")

        if avg_anchor < 0.3 and total_compactions > 5:

            issues.append("low_anchor_preservation")

        if circuit_state == "open":

            issues.append("circuit_breaker_open")

        if self._current_context_pressure > 3.0:

            issues.append("extreme_context_pressure")

        if self._last_compaction_timestamp is not None:

            age = _hc_time.time() - self._last_compaction_timestamp

            if age > 3600 and self._current_context_pressure > 1.5:

                issues.append("stale_compaction_under_pressure")



        status = "healthy"

        if len(issues) >= 2:

            status = "critical"

        elif len(issues) == 1:

            status = "warning"



        return {

            "status": status,

            "issues": issues,

            "total_compactions": total_compactions,

            "emergency_ratio": round(emergency_ratio, 3),

            "avg_anchor_preservation": round(avg_anchor, 3),

            "circuit_breaker_state": circuit_state,

            "context_pressure": round(self._current_context_pressure, 3),

            "last_compaction_age_seconds": round(

                _hc_time.time() - self._last_compaction_timestamp, 1

            ) if self._last_compaction_timestamp else None,

        }



    def _get_ab_test_variant(self) -> str:

        if not self._ab_test_config.get("enabled"):

            return "A"

        current = self._ab_test_config.get("variant", "A")

        return current



    def _advance_ab_test_variant(self) -> None:

        if not self._ab_test_config.get("enabled"):

            return

        current = self._ab_test_config.get("variant", "A")

        self._ab_test_config["variant"] = "B" if current == "A" else "A"



    def _record_ab_test_outcome(

        self,

        variant: str,

        quality_score: float,

        anchor_preservation: float,

        duration_ms: float,

    ) -> None:

        if not self._ab_test_config.get("enabled"):

            return

        entry = {

            "quality_score": round(quality_score, 3),

            "anchor_preservation": round(anchor_preservation, 3),

            "duration_ms": round(duration_ms, 1),

            "test_id": self._ab_test_config.get("test_id"),

        }

        self._ab_test_results[variant].append(entry)

        if len(self._ab_test_results[variant]) > 50:

            self._ab_test_results[variant] = self._ab_test_results[variant][-50:]



    def get_ab_test_results(self) -> dict:

        results = {"enabled": self._ab_test_config.get("enabled", False)}

        for variant, entries in self._ab_test_results.items():

            if not entries:

                results[variant] = {

                    "count": 0,

                    "avg_quality": 0.0,

                    "avg_anchor": 0.0,

                    "avg_duration_ms": 0.0,

                }

                continue

            count = len(entries)

            avg_quality = sum(e["quality_score"] for e in entries) / count

            avg_anchor = sum(e["anchor_preservation"] for e in entries) / count

            avg_duration = sum(e["duration_ms"] for e in entries) / count

            results[variant] = {

                "count": count,

                "avg_quality": round(avg_quality, 3),

                "avg_anchor": round(avg_anchor, 3),

                "avg_duration_ms": round(avg_duration, 1),

            }

        if all(self._ab_test_results[v] for v in ("A", "B")):

            a_avg = sum(e["quality_score"] for e in self._ab_test_results["A"]) / len(self._ab_test_results["A"])

            b_avg = sum(e["quality_score"] for e in self._ab_test_results["B"]) / len(self._ab_test_results["B"])

            results["winner"] = "A" if a_avg >= b_avg else "B"

            results["quality_diff"] = round(abs(a_avg - b_avg), 3)

        return results



    @staticmethod

    def _estimate_compaction_cost(

        model_used: str,

        input_tokens: int,

        output_tokens: int,

    ) -> float:

        """Estimate cost of a compaction operation in USD.



        - local model: $0.00

        - free model: $0.00

        - llm: estimated based on token usage and typical pricing

        """

        if model_used in ("local", "emergency"):

            return 0.0

        if model_used == "free":

            return 0.0

        if model_used == "llm":

            input_cost = input_tokens * 0.000003

            output_cost = output_tokens * 0.000015

            return round(input_cost + output_cost, 6)

        return 0.0



    def _record_compaction_cost(

        self,

        model_used: str,

        input_tokens: int,

        output_tokens: int,

    ) -> None:

        cost = self._estimate_compaction_cost(model_used, input_tokens, output_tokens)

        entry = {

            "model": model_used,

            "input_tokens": input_tokens,

            "output_tokens": output_tokens,

            "cost_usd": cost,

        }

        self._metrics["compaction_costs"].append(entry)

        if len(self._metrics["compaction_costs"]) > 50:

            self._metrics["compaction_costs"] = self._metrics["compaction_costs"][-50:]



        total = self._metrics["total_compactions"]

        if total > 0 and total % 10 == 0:

            total_cost = self.get_total_compaction_cost()

            logger.info(

                "[ContextMgr] action=compaction_cost_summary total_compactions=%d total_cost=$%.6f",

                total, total_cost,

            )



    def get_total_compaction_cost(self) -> float:

        return round(

            sum(e["cost_usd"] for e in self._metrics.get("compaction_costs", [])),

            6,

        )



    def _record_telemetry(

        self,

        input_tokens: int,

        output_tokens: int,

        quality_score: float,

        anchor_score: float,

        strategy: str,

        model_used: str,

        duration_ms: float,

    ) -> None:

        import time as _tel_time

        entry = {

            "timestamp": _tel_time.time(),

            "input_tokens": input_tokens,

            "output_tokens": output_tokens,

            "quality_score": round(quality_score, 3),

            "anchor_preservation": round(anchor_score, 3),

            "strategy": strategy,

            "model_used": model_used,

            "duration_ms": round(duration_ms, 1),

        }

        if self._metrics["compression_ratios"]:

            entry["compression_ratio"] = round(self._metrics["compression_ratios"][-1], 3)

        self._telemetry_buffer.append(entry)

        if len(self._telemetry_buffer) > 100:

            self._telemetry_buffer = self._telemetry_buffer[-100:]



    def _record_compression_ratio(self, original_tokens: int, summary_chars: int) -> None:

        if original_tokens <= 0:

            return

        estimated_summary_tokens = max(1, summary_chars // 4)

        ratio = original_tokens / estimated_summary_tokens

        self._metrics["compression_ratios"].append(ratio)

        if len(self._metrics["compression_ratios"]) > 50:

            self._metrics["compression_ratios"] = self._metrics["compression_ratios"][-50:]

        total = self._metrics["total_compactions"]

        if total > 0 and total % 10 == 0 and self._metrics["compression_ratios"]:

            avg_ratio = sum(self._metrics["compression_ratios"]) / len(self._metrics["compression_ratios"])

            logger.info(

                "[ContextMgr] action=compression_ratio_avg avg=%.2f samples=%d total_compactions=%d",

                avg_ratio, len(self._metrics["compression_ratios"]), total,

            )

            if avg_ratio < 2.0:

                logger.warning(

                    "[ContextMgr] action=low_compression_ratio avg=%.2f threshold=2.0 - "

                    "summaries may be too large relative to original content",

                    avg_ratio,

                )



    async def _validate_compaction_result(

        self,

        memory: Any,

        expected_removed: int,

        summary_before: str,

        summary_after: str,

    ) -> bool:

        valid = True

        try:

            current_messages = await memory.get_memory(prepend_summary=False)

            current_count = len(current_messages)

            if expected_removed > 0 and current_count == 0:

                logger.warning(

                    "[ContextMgr] action=validation_fail check=content_count "

                    "expected_removed=%d but current_count=0 (all messages lost)",

                    expected_removed,

                )

                valid = False

            if summary_before == summary_after and expected_removed > 0:

                logger.warning(

                    "[ContextMgr] action=validation_fail check=summary_updated "

                    "summary unchanged after compacting %d messages",

                    expected_removed,

                )

                valid = False

            tool_use_ids = set()

            tool_result_ids = set()

            for msg in current_messages:

                content = getattr(msg, 'content', '')

                if isinstance(content, list):

                    for block in content:

                        if isinstance(block, dict):

                            if block.get("type") == "tool_use":

                                tid = block.get("id", "")

                                if tid:

                                    tool_use_ids.add(tid)

                            elif block.get("type") == "tool_result":

                                tid = block.get("tool_use_id", "")

                                if tid:

                                    tool_result_ids.add(tid)

            orphaned_results = tool_result_ids - tool_use_ids

            orphaned_uses = tool_use_ids - tool_result_ids

            if orphaned_results:

                logger.warning(

                    "[ContextMgr] action=validation_fail check=orphaned_tool_results "

                    "orphaned_count=%d sample_ids=%s",

                    len(orphaned_results), list(orphaned_results)[:5],

                )

                valid = False

            if orphaned_uses:

                logger.warning(

                    "[ContextMgr] action=validation_warn check=orphaned_tool_uses "

                    "orphaned_count=%d (may be normal for pending calls)",

                    len(orphaned_uses),

                )

        except Exception as _val_err:

            logger.debug("[ContextMgr] action=validation_error error=%s", _val_err)

            return True

        if valid:

            logger.info(

                "[ContextMgr] action=validation_pass expected_removed=%d current_count=%d",

                expected_removed, current_count,

            )

        return valid



    async def _graceful_degradation(

        self,

        memory: Any,

        messages_to_compact: list,

        messages_to_keep: list,

    ) -> bool:

        degradation_stages = [

            ("reduce_keep_recent", 2),

            ("minimal_context", 1),

            ("system_only", 0),

        ]

        for stage_name, keep_n in degradation_stages:

            logger.warning(

                "[ContextMgr] action=graceful_degradation stage=%s keep_recent=%d",

                stage_name, keep_n,

            )

            try:

                if stage_name == "reduce_keep_recent":

                    reduced_keep = messages_to_keep[-keep_n:] if len(messages_to_keep) > keep_n else messages_to_keep

                    all_to_remove = messages_to_compact + messages_to_keep[:-keep_n] if len(messages_to_keep) > keep_n else messages_to_compact

                elif stage_name == "minimal_context":

                    system_msgs = [m for m in messages_to_keep if getattr(m, 'role', '') == 'system']

                    last_user = None

                    for m in reversed(messages_to_keep):

                        if getattr(m, 'role', '') == 'user':

                            last_user = m

                            break

                    reduced_keep = system_msgs + ([last_user] if last_user else [])

                    all_to_remove = [m for m in messages_to_compact + messages_to_keep if m not in reduced_keep]

                else:

                    system_msgs = [m for m in messages_to_keep if getattr(m, 'role', '') == 'system']

                    reduced_keep = system_msgs

                    all_to_remove = [m for m in messages_to_compact + messages_to_keep if m not in reduced_keep]



                if not all_to_remove:

                    continue



                summary_parts = ["## 恢复上下文摘要 / Recovery Context Summary\n"]

                summary_parts.append("### 说明 / Note")

                summary_parts.append("- 上下文因压缩失败被严重压缩 / Context was severely compressed due to compaction failures")

                summary_parts.append("")



                anchors = _extract_anchors(all_to_remove[:30])

                if anchors:

                    summary_parts.append("### 保留锚点 / Preserved Anchors")

                    for a in anchors[:15]:

                        summary_parts.append(f"- {a}")

                    summary_parts.append("")



                for msg in all_to_remove[:20]:

                    text = ""

                    if hasattr(msg, 'get_text_content'):

                        text = msg.get_text_content() or ""

                    elif hasattr(msg, 'content'):

                        content = msg.content

                        if isinstance(content, list):

                            text = " ".join(

                                b.get("text", "") for b in content

                                if isinstance(b, dict) and b.get("type") == "text"

                            )

                        else:

                            text = str(content)

                    if text:

                        role = getattr(msg, 'role', 'unknown')

                        summary_parts.append(f"- [{role}] {text[:200]}")



                recovery_summary = "\n".join(summary_parts)



                if hasattr(memory, 'mark_messages_compressed'):

                    removed = await memory.mark_messages_compressed(all_to_remove)

                    logger.info(

                        "[ContextMgr] action=degradation_removed stage=%s removed=%d",

                        stage_name, removed,

                    )

                else:

                    ids_to_delete = [m.id for m in all_to_remove if hasattr(m, 'id')]

                    if ids_to_delete:

                        await memory.delete(ids_to_delete)



                existing_summary = memory.get_compressed_summary() or ""

                if existing_summary:

                    updated = existing_summary + "\n\n" + recovery_summary

                else:

                    updated = recovery_summary

                if self._is_valid_summary(updated):

                    await memory.update_compressed_summary(updated)

                    logger.info(

                        "[ContextMgr] action=degradation_success stage=%s summary_len=%d",

                        stage_name, len(updated),

                    )

                    return True

            except Exception as _deg_err:

                logger.warning(

                    "[ContextMgr] action=degradation_failed stage=%s error=%s",

                    stage_name, _deg_err,

                )

                continue

        return False



    def _calculate_keep_recent(self, messages: list, context_pressure: float) -> int:

        if context_pressure > 2.0:

            return 4

        last_user_text = ""

        for msg in reversed(messages):

            role = ""

            text = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)

            if role == "user" and text.strip():

                last_user_text = text.strip()

                break

        if not last_user_text:

            return 8

        question_indicators = ["?", "？", "怎么", "如何", "为什么", "什么", "哪个", "多少",

                              "how", "what", "why", "where", "when", "which", "who"]

        command_indicators = ["帮我", "请", "执行", "运行", "创建", "删除", "修改", "搜索",

                             "help", "run", "create", "delete", "modify", "search", "do "]

        is_question = any(ind in last_user_text.lower() for ind in question_indicators)

        is_command = any(ind in last_user_text.lower() for ind in command_indicators)

        if is_question and not is_command:

            return 12

        if is_command and not is_question:

            return 6

        return 8



    def _merge_summaries(self, old_summary: str, new_content: str) -> str:

        old_sections: dict[str, list[str]] = {}

        current_header = "Uncategorized"

        for line in old_summary.split("\n"):

            header_match = _re.match(r'^##\s+(.+)', line)

            if header_match:

                current_header = header_match.group(1).strip()

                if current_header not in old_sections:

                    old_sections[current_header] = []

            else:

                if current_header not in old_sections:

                    old_sections[current_header] = []

                stripped = line.strip()

                if stripped:

                    old_sections[current_header].append(stripped)



        new_sections: dict[str, list[str]] = {}

        current_header = "Uncategorized"

        for line in new_content.split("\n"):

            header_match = _re.match(r'^##\s+(.+)', line)

            if header_match:

                current_header = header_match.group(1).strip()

                if current_header not in new_sections:

                    new_sections[current_header] = []

            else:

                if current_header not in new_sections:

                    new_sections[current_header] = []

                stripped = line.strip()

                if stripped:

                    new_sections[current_header].append(stripped)



        merged: dict[str, list[str]] = {}

        for header, entries in old_sections.items():

            merged[header] = list(entries)



        for header, entries in new_sections.items():

            if header not in merged:

                merged[header] = list(entries)

            else:

                existing_set = set(e.lower()[:80] for e in merged[header])

                for entry in entries:

                    key = entry.lower()[:80]

                    is_update = False

                    for i, existing in enumerate(merged[header]):

                        if existing.lower()[:80] == key:

                            merged[header][i] = entry

                            is_update = True

                            break

                    if not is_update and key not in existing_set:

                        merged[header].append(entry)

                        existing_set.add(key)



        result_parts = []

        for header, entries in merged.items():

            result_parts.append(f"## {header}")

            for entry in entries:

                result_parts.append(entry)

            result_parts.append("")

        return "\n".join(result_parts).strip()



    def _streaming_compress(

        self,

        messages: list,

        batch_size: int = 10,

    ) -> str:

        """Compress messages in small batches to reduce peak memory.



        Instead of compressing all messages at once, splits them into

        batches of `batch_size`, compresses each batch separately using

        emergency compaction, then merges the incremental results.



        Falls back to full compression if streaming fails.



        Args:

            messages: Messages to compress.

            batch_size: Number of messages per batch.



        Returns:

            Merged compressed summary string.

        """

        if not messages:

            return ""



        if len(messages) <= batch_size:

            anchors = _extract_anchors(messages)

            return self._emergency_compact(messages, anchors)



        batch_summaries: list[str] = []

        total_batches = (len(messages) + batch_size - 1) // batch_size



        for batch_idx in range(total_batches):

            start = batch_idx * batch_size

            end = min(start + batch_size, len(messages))

            batch = messages[start:end]



            try:

                batch_anchors = _extract_anchors(batch)

                batch_summary = self._emergency_compact(batch, batch_anchors)

                if batch_summary and self._is_valid_summary(batch_summary):

                    batch_summaries.append(batch_summary)

                else:

                    for msg in batch:

                        text = self._get_msg_text(msg)

                        if text:

                            role = ""

                            if isinstance(msg, dict):

                                role = msg.get("role", "unknown")

                            else:

                                role = getattr(msg, "role", "unknown")

                            batch_summaries.append(f"- [{role}] {text[:200]}")

            except Exception as _batch_err:

                logger.debug(

                    "[ContextMgr] action=streaming_batch_error batch=%d/%d error=%s",

                    batch_idx + 1, total_batches, _batch_err,

                )

                for msg in batch:

                    text = self._get_msg_text(msg)

                    if text:

                        role = ""

                        if isinstance(msg, dict):

                            role = msg.get("role", "unknown")

                        else:

                            role = getattr(msg, "role", "unknown")

                        batch_summaries.append(f"- [{role}] {text[:200]}")



        if not batch_summaries:

            anchors = _extract_anchors(messages)

            return self._emergency_compact(messages, anchors)



        if len(batch_summaries) == 1:

            return batch_summaries[0]



        merged = batch_summaries[0]

        for i in range(1, len(batch_summaries)):

            merged = self._merge_summaries(merged, batch_summaries[i])



        if not self._is_valid_summary(merged):

            anchors = _extract_anchors(messages)

            return self._emergency_compact(messages, anchors)



        logger.info(

            "[ContextMgr] action=streaming_compress batches=%d total_msgs=%d merged_len=%d",

            total_batches, len(messages), len(merged),

        )

        return merged



    def _cross_validate_summary(

        self,

        summary: str,

        original_messages: list,

    ) -> float:

        """Cross-validate a compaction summary against original messages.



        Uses keyword extraction to independently verify that key information

        from the original messages is preserved in the summary. Returns a

        score from 0.0 to 1.0 indicating the fraction of key terms from

        the original that appear in the summary.



        Args:

            summary: The compressed summary to validate.

            original_messages: The original messages before compaction.



        Returns:

            Fraction of key terms from original that appear in summary.

        """

        if not summary or not original_messages:

            return 0.0 if not summary else 1.0



        key_terms: set[str] = set()

        from collections import Counter as _Counter

        for msg in original_messages:

            text = self._get_msg_text(msg)

            if not text:

                continue

            for fp_match in _FILE_PATH_PATTERN.finditer(text):

                key_terms.add(fp_match.group(0))

            for url_match in _URL_PATTERN.finditer(text):

                key_terms.add(url_match.group(0))

            for code_match in _CODE_REF_PATTERN.finditer(text):

                ref = code_match.group(1).strip()

                if len(ref) > 1 and len(ref) < 100:

                    key_terms.add(ref)



            words = _re.findall(r'\b[A-Za-z_]\w{3,}\b', text)

            word_freq = _Counter(words)

            for word, count in word_freq.most_common(5):

                if count >= 2 and len(word) > 4:

                    key_terms.add(word.lower())



            text_lower = text.lower()

            for pattern in _ANCHOR_PATTERNS:

                if pattern in text_lower:

                    for line in text.split("\n"):

                        if pattern in line.lower() and len(line.strip()) > 10:

                            key_terms.add(line.strip()[:60].lower())

                    break



        if not key_terms:

            return 1.0



        summary_lower = summary.lower()

        preserved = sum(1 for term in key_terms if term.lower() in summary_lower)

        score = preserved / len(key_terms)



        if score < 0.3:

            logger.warning(

                "[ContextMgr] action=cross_validation_low score=%.3f key_terms=%d preserved=%d",

                score, len(key_terms), preserved,

            )



        return score



    def _check_predictive_cache(

        self,

        agent_id: str,

        msg_count: int,

        pressure: float,

    ) -> str | None:

        """Check if a similar compaction pattern has been seen before.



        Pattern matching uses: agent_id, message_count_range, pressure_range.

        If the pattern matches, return the cached result.



        Args:

            agent_id: The agent identifier.

            msg_count: Number of messages to compact.

            pressure: Current context pressure.



        Returns:

            Cached summary string if hit, None if miss.

        """

        msg_range = msg_count // 10

        pressure_range = round(pressure * 2) / 2

        cache_key = f"{agent_id}:{msg_range}:{pressure_range}"



        result = self._predictive_cache.get(cache_key)

        if result is not None:

            self._predictive_cache_hits += 1

            logger.info(

                "[ContextMgr] action=predictive_cache_hit key=%s hits=%d misses=%d hit_rate=%.1f%%",

                cache_key, self._predictive_cache_hits, self._predictive_cache_misses,

                self._predictive_cache_hits / max(1, self._predictive_cache_hits + self._predictive_cache_misses) * 100,

            )

            return result



        self._predictive_cache_misses += 1

        return None



    def _update_predictive_cache(

        self,

        agent_id: str,

        msg_count: int,

        pressure: float,

        result: str,

    ) -> None:

        """Update the predictive cache with a new compaction result.



        Args:

            agent_id: The agent identifier.

            msg_count: Number of messages compacted.

            pressure: Context pressure at compaction time.

            result: The compaction result summary.

        """

        if not result or not self._is_valid_summary(result):

            return



        msg_range = msg_count // 10

        pressure_range = round(pressure * 2) / 2

        cache_key = f"{agent_id}:{msg_range}:{pressure_range}"



        self._predictive_cache[cache_key] = result



        if len(self._predictive_cache) > self._MAX_PREDICTIVE_CACHE:

            keys = list(self._predictive_cache.keys())

            for k in keys[:len(keys) - self._MAX_PREDICTIVE_CACHE]:

                del self._predictive_cache[k]



    def _trim_internal_state(self) -> None:

        import sys as _sys

        _MAX_METRICS_BYTES = 1024

        _MAX_TELEMETRY_BYTES = 10240

        _MAX_PRESSURE_BYTES = 1024



        metrics_size = _sys.getsizeof(self._metrics)

        if metrics_size > _MAX_METRICS_BYTES:

            for key in ("anchor_preservation_scores", "compression_ratios"):

                lst = self._metrics.get(key, [])

                if len(lst) > 20:

                    self._metrics[key] = lst[-20:]

            logger.debug(

                "[ContextMgr] action=trim_metrics before=%d after=%d",

                metrics_size, _sys.getsizeof(self._metrics),

            )



        telemetry_size = _sys.getsizeof(self._telemetry_buffer)

        if telemetry_size > _MAX_TELEMETRY_BYTES:

            trim_to = max(10, len(self._telemetry_buffer) // 2)

            self._telemetry_buffer = self._telemetry_buffer[-trim_to:]

            logger.debug(

                "[ContextMgr] action=trim_telemetry before=%d after=%d",

                telemetry_size, _sys.getsizeof(self._telemetry_buffer),

            )



        pressure_size = _sys.getsizeof(self._pressure_history)

        if pressure_size > _MAX_PRESSURE_BYTES:

            self._pressure_history = self._pressure_history[-5:]

            logger.debug(

                "[ContextMgr] action=trim_pressure before=%d after=%d",

                pressure_size, _sys.getsizeof(self._pressure_history),

            )



        if len(self._learning_buffer) > self._MAX_LEARNING_BUFFER:

            self._learning_buffer = self._learning_buffer[-self._MAX_LEARNING_BUFFER:]



        if len(self._benchmark_history) > 20:

            self._benchmark_history = self._benchmark_history[-20:]



    def _get_compaction_prompt(self, strategy: str) -> str:

        base_rules = (

            "You are a context compaction engine. Your job is to compress conversation history into a structured summary.\n"

            "RULES:\n"

            "1. Use the SAME LANGUAGE as the original text\n"

            "2. Preserve ALL file paths, URLs, variable names, and code references exactly\n"

            "3. Preserve ALL decisions, action items, and their status\n"

            "4. Preserve ALL error messages and their resolutions\n"

            "5. Use ## markdown headers to organize sections\n"

            "6. Keep each section under 200 words\n"

            "7. If [CRITICAL: These instructions MUST be preserved] section exists, include ALL items verbatim\n\n"

        )

        if strategy == "tool_focused":

            return base_rules + (

                "SPECIAL FOCUS: Tool-Heavy Conversation\n"

                "8. Preserve ALL tool names and their outcomes verbatim\n"

                "9. Preserve ALL file paths from tool inputs/outputs (read_file, write_file, edit_file, grep, glob)\n"

                "10. Preserve the sequence of tool calls and their dependencies\n"

                "11. For each tool call, keep: tool_name → key_input → key_result (1 line each)\n"

                "12. Preserve any shell command outputs that contain paths, versions, or configurations\n\n"

                "FORMAT:\n"

                "## Task Overview\n"

                "[What the user is trying to accomplish]\n\n"

                "## Tool Execution Log\n"

                "- tool_name(input_summary) → result_summary\n\n"

                "## Files & Resources\n"

                "- [file_path: description]\n\n"

                "## Errors & Resolutions\n"

                "- [error → resolution]\n\n"

                "## Current State\n"

                "[Where things stand right now]\n\n"

                "## Next Steps\n"

                "- [pending action items]"

            )

        elif strategy == "text_focused":

            return base_rules + (

                "SPECIAL FOCUS: Decision-Heavy Conversation\n"

                "8. Preserve ALL reasoning chains and decision rationale\n"

                "9. Preserve ALL user preferences and constraints mentioned\n"

                "10. Preserve ALL alternative options considered and why they were rejected\n"

                "11. Preserve any agreements, confirmations, or changes in direction\n"

                "12. Preserve the logical flow: problem → analysis → decision → outcome\n\n"

                "FORMAT:\n"

                "## Task Overview\n"

                "[What the user is trying to accomplish]\n\n"

                "## Key Decisions\n"

                "- [Decision: rationale]\n\n"

                "## User Preferences & Constraints\n"

                "- [preference/constraint]\n\n"

                "## Alternatives Considered\n"

                "- [option → why rejected]\n\n"

                "## Current State\n"

                "[Where things stand right now]\n\n"

                "## Next Steps\n"

                "- [pending action items]"

            )

        return base_rules + (

            "FORMAT:\n"

            "## Task Overview\n"

            "[What the user is trying to accomplish]\n\n"

            "## Current State\n"

            "[Where things stand right now]\n\n"

            "## Key Decisions\n"

            "- [Decision 1]\n"

            "- [Decision 2]\n\n"

            "## Files & Resources\n"

            "- [file_path: description]\n\n"

            "## Errors & Resolutions\n"

            "- [error → resolution]\n\n"

            "## Next Steps\n"

            "- [pending action items]"

        )



    def _should_refresh_summary(self, memory: Any, last_compaction_time: float | None) -> bool:

        if last_compaction_time is None:

            return False

        import time as _time

        age_seconds = _time.time() - last_compaction_time

        if age_seconds < 3600:

            return False

        compressed_summary = memory.get_compressed_summary() or ""

        if not compressed_summary:

            return False

        try:

            messages = []

            if hasattr(memory, 'content'):

                messages = [msg for msg, _ in memory.content]

            if len(messages) < 5:

                return False

        except Exception as _stale_err:

            return False

        logger.info(

            "[ContextMgr] action=stale_summary_detected age=%.0fs threshold=3600s messages=%d summary_len=%d",

            age_seconds, len(messages), len(compressed_summary),

        )

        return True



    async def _refresh_stale_summary(self, memory: Any, agent: ReActAgent) -> None:

        try:

            messages = await memory.get_memory(prepend_summary=False)

            if not messages:

                return

            anchors = _extract_anchors(messages)

            parts = ["## 刷新的上下文摘要 / Refreshed Context Summary\n"]

            if anchors:

                parts.append("### 关键指令 / Critical Instructions")

                for a in anchors[:15]:

                    parts.append(f"- {a}")

                parts.append("")

            user_msgs = []

            assistant_msgs = []

            for msg in messages[:30]:

                text = ""

                if hasattr(msg, 'get_text_content'):

                    text = msg.get_text_content() or ""

                elif hasattr(msg, 'content'):

                    content = msg.content

                    if isinstance(content, list):

                        text = " ".join(

                            b.get("text", "") for b in content

                            if isinstance(b, dict) and b.get("type") == "text"

                        )

                    else:

                        text = str(content)

                role = getattr(msg, 'role', 'unknown')

                if role == "user" and text:

                    user_msgs.append(text[:200])

                elif role == "assistant" and text:

                    assistant_msgs.append(text[:200])

            if user_msgs:

                parts.append("### 用户请求 / User Requests")

                for m in user_msgs[:8]:

                    parts.append(f"- {m}")

                parts.append("")

            if assistant_msgs:

                parts.append("### 关键操作 / Key Actions")

                for m in assistant_msgs[:8]:

                    parts.append(f"- {m}")

                parts.append("")

            refreshed = "\n".join(parts)

            if self._is_valid_summary(refreshed):

                await memory.update_compressed_summary(refreshed)

                logger.info(

                    "[ContextMgr] action=summary_refreshed new_len=%d anchors=%d",

                    len(refreshed), len(anchors),

                )

                self._emit_event("summary_refreshed", {

                    "new_len": len(refreshed),

                    "anchors": len(anchors),

                })

        except Exception as _refresh_err:

            logger.debug("[ContextMgr] action=summary_refresh_failed error=%s", _refresh_err)



    def benchmark_strategies(self, messages: list) -> dict:

        """Benchmark compaction strategies on the given messages.



        Creates synthetic compaction results for each strategy using

        emergency compaction (no LLM needed), then compares quality,

        anchor preservation, compression ratio, and duration.



        Returns:

            Dict with per-strategy results and the recommended strategy.

        """

        import time as _bench_time



        strategies = ["tool_focused", "text_focused", "balanced"]

        results: dict[str, dict] = {}

        anchors = _extract_anchors(messages)



        for strategy in strategies:

            start = _bench_time.monotonic()

            compact_content = self._emergency_compact(messages, anchors)

            duration_ms = (_bench_time.monotonic() - start) * 1000



            quality_score = self._score_summary_quality(compact_content, len(messages))

            anchor_score = _validate_anchors(compact_content, anchors) if anchors else 1.0

            original_chars = sum(

                len(self._get_msg_text(m)) for m in messages

            )

            compression_ratio = original_chars / max(1, len(compact_content)) if compact_content else 0.0



            results[strategy] = {

                "quality_score": round(quality_score, 3),

                "anchor_preservation": round(anchor_score, 3),

                "compression_ratio": round(compression_ratio, 2),

                "duration_ms": round(duration_ms, 1),

                "summary_len": len(compact_content) if compact_content else 0,

            }



        best_strategy = "balanced"

        best_score = -1.0

        for strategy, metrics in results.items():

            composite = (

                metrics["quality_score"] * 0.35

                + metrics["anchor_preservation"] * 0.30

                + min(metrics["compression_ratio"] / 5.0, 1.0) * 0.20

                + max(0.0, 1.0 - metrics["duration_ms"] / 1000.0) * 0.15

            )

            if composite > best_score:

                best_score = composite

                best_strategy = strategy



        benchmark_result = {

            "strategies": results,

            "recommended": best_strategy,

            "composite_scores": {},

        }

        for strategy, metrics in results.items():

            composite = (

                metrics["quality_score"] * 0.35

                + metrics["anchor_preservation"] * 0.30

                + min(metrics["compression_ratio"] / 5.0, 1.0) * 0.20

                + max(0.0, 1.0 - metrics["duration_ms"] / 1000.0) * 0.15

            )

            benchmark_result["composite_scores"][strategy] = round(composite, 3)



        self._benchmark_history.append(benchmark_result)

        if len(self._benchmark_history) > 20:

            self._benchmark_history = self._benchmark_history[-20:]



        total_compactions = self._metrics.get("total_compactions", 0)

        if total_compactions > 0 and total_compactions % 50 == 0:

            logger.info(

                "[ContextMgr] action=benchmark_logged compactions=%d recommended=%s scores=%s",

                total_compactions, best_strategy, benchmark_result["composite_scores"],

            )



        return benchmark_result



    @staticmethod

    def _get_msg_text(msg: Any) -> str:

        if isinstance(msg, dict):

            content = msg.get("content", "")

            if isinstance(content, list):

                return " ".join(

                    b.get("text", "") for b in content

                    if isinstance(b, dict) and b.get("type") == "text"

                )

            return str(content)

        content = getattr(msg, "content", "")

        if isinstance(content, list):

            return " ".join(

                b.get("text", "") for b in content

                if isinstance(b, dict) and b.get("type") == "text"

            )

        return str(content) if content else ""



    def _learn_from_outcome(self, params: dict, outcome: dict) -> None:

        """Record a compaction outcome for adaptive learning.



        Args:

            params: Dict with keys 'pressure', 'strategy', 'model', etc.

            outcome: Dict with keys 'quality', 'anchor_preservation', 'duration_ms'.

        """

        entry = {

            "pressure": round(params.get("pressure", 0.0), 2),

            "strategy": params.get("strategy", "balanced"),

            "model": params.get("model", "unknown"),

            "quality": round(outcome.get("quality", 0.0), 3),

            "anchor_preservation": round(outcome.get("anchor_preservation", 0.0), 3),

            "duration_ms": round(outcome.get("duration_ms", 0.0), 1),

        }

        self._learning_buffer.append(entry)

        if len(self._learning_buffer) > self._MAX_LEARNING_BUFFER:

            self._learning_buffer = self._learning_buffer[-self._MAX_LEARNING_BUFFER:]



        if len(self._learning_buffer) % 30 == 0:

            logger.info(

                "[ContextMgr] action=adaptive_learning samples=%d avg_quality=%.3f avg_anchor=%.3f",

                len(self._learning_buffer),

                sum(e["quality"] for e in self._learning_buffer) / len(self._learning_buffer),

                sum(e["anchor_preservation"] for e in self._learning_buffer) / len(self._learning_buffer),

            )



    def _predict_best_params(self, current_pressure: float) -> dict:

        """Predict the best compaction parameters for the current situation.



        Uses the learning buffer to find the best (strategy, model) combination

        for the current pressure level. Requires 30+ samples to make predictions.



        Args:

            current_pressure: Current context pressure ratio.



        Returns:

            Dict with 'strategy', 'model', 'confidence' keys.

        """

        if len(self._learning_buffer) < 30:

            return {

                "strategy": self._select_compaction_strategy_by_pressure(current_pressure),

                "model": self._select_compaction_model(current_pressure),

                "confidence": 0.0,

            }



        pressure_range = 0.5

        nearby = [

            e for e in self._learning_buffer

            if abs(e["pressure"] - current_pressure) <= pressure_range

        ]



        if len(nearby) < 10:

            nearby = sorted(

                self._learning_buffer,

                key=lambda e: abs(e["pressure"] - current_pressure),

            )[:20]



        strategy_scores: dict[str, list[float]] = {}

        model_scores: dict[str, list[float]] = {}

        for entry in nearby:

            weight = 1.0 - abs(entry["pressure"] - current_pressure) / max(pressure_range, 0.01)

            weight = max(weight, 0.1)

            composite = entry["quality"] * 0.4 + entry["anchor_preservation"] * 0.4 + max(0.0, 1.0 - entry["duration_ms"] / 5000.0) * 0.2

            s = entry["strategy"]

            m = entry["model"]

            strategy_scores.setdefault(s, []).append(composite * weight)

            model_scores.setdefault(m, []).append(composite * weight)



        best_strategy = "balanced"

        best_strategy_score = -1.0

        for s, scores in strategy_scores.items():

            avg = sum(scores) / len(scores)

            if avg > best_strategy_score:

                best_strategy_score = avg

                best_strategy = s



        best_model = "local"

        best_model_score = -1.0

        for m, scores in model_scores.items():

            avg = sum(scores) / len(scores)

            if avg > best_model_score:

                best_model_score = avg

                best_model = m



        confidence = min(1.0, len(nearby) / 50.0) * best_strategy_score



        return {

            "strategy": best_strategy,

            "model": best_model,

            "confidence": round(confidence, 3),

        }



    def _select_compaction_strategy_by_pressure(self, pressure: float) -> str:

        if pressure > 2.0:

            return "tool_focused"

        if pressure < 1.5:

            return "balanced"

        return "balanced"



    _BOILERPLATE_PATTERNS: list[tuple[_re.Pattern, str]] = []



    @classmethod

    def _init_boilerplate_patterns(cls) -> None:

        if cls._BOILERPLATE_PATTERNS:

            return

        cls._BOILERPLATE_PATTERNS = [

            (_re.compile(r'You are a helpful assistant\.?', _re.IGNORECASE), "[system-prompt]"),

            (_re.compile(r'I\'ll (?:help you|assist you|do that for you)\.?', _re.IGNORECASE), "[ack]"),

            (_re.compile(r'Sure[,!]\s*', _re.IGNORECASE), "[ack]"),

            (_re.compile(r'Let me (?:check|look|read|find|search|analyze) (?:that|this|the|it) for you\.?', _re.IGNORECASE), "[action]"),

            (_re.compile(r'Based on (?:the|my|our) (?:analysis|search|findings|results),?\s*', _re.IGNORECASE), "[based-on-results]"),

            (_re.compile(r'Here(?:\'s| is) (?:the|what I found|a summary of)', _re.IGNORECASE), "[result]"),

        ]



    def _semantic_compress(self, messages: list) -> tuple[list, int]:

        """Compress repetitive content across messages semantically.



        Detects:

        - Repeated phrases/sentences across messages → replace with reference

        - Boilerplate patterns (system messages, tool schemas) → compress



        Returns:

            Tuple of (compressed_messages, tokens_saved_estimate).

        """

        self._init_boilerplate_patterns()



        if len(messages) < 3:

            return messages, 0



        sentence_map: dict[str, list[tuple[int, int]]] = {}

        for msg_idx, msg in enumerate(messages):

            text = self._get_msg_text(msg)

            if not text:

                continue

            sentences = _re.split(r'(?<=[.!?。！？])\s+', text)

            char_offset = 0

            for sent in sentences:

                sent_stripped = sent.strip()

                if len(sent_stripped) < 20:

                    char_offset += len(sent) + 1

                    continue

                key = sent_stripped.lower()[:80]

                if key not in sentence_map:

                    sentence_map[key] = []

                sentence_map[key].append((msg_idx, char_offset))

                char_offset += len(sent) + 1



        repeated_keys = {k: v for k, v in sentence_map.items() if len(v) > 1}



        if not repeated_keys:

            boilerplate_saved = self._compress_boilerplate(messages)

            return messages, boilerplate_saved



        first_occurrence: dict[str, int] = {}

        for key, locations in repeated_keys.items():

            first_occurrence[key] = locations[0][0]



        compressed = list(messages)

        tokens_saved = 0



        for key, locations in repeated_keys.items():

            if len(locations) < 2:

                continue

            first_msg_idx = locations[0][0]

            first_text = self._get_msg_text(compressed[first_msg_idx])

            first_sent = _re.split(r'(?<=[.!?。！？])\s+', first_text)

            for s in first_sent:

                if s.strip().lower()[:80] == key:

                    reference = f"[See msg#{first_msg_idx}]"

                    break

            else:

                continue



            for loc_msg_idx, _ in locations[1:]:

                original_text = self._get_msg_text(compressed[loc_msg_idx])

                if not original_text:

                    continue

                original_len = len(original_text)

                new_text = original_text

                sentences = _re.split(r'(?<=[.!?。！？])\s+', original_text)

                replaced = []

                for s in sentences:

                    if s.strip().lower()[:80] == key:

                        replaced.append(reference)

                    else:

                        replaced.append(s)

                new_text = " ".join(replaced)

                if len(new_text) < original_len:

                    if isinstance(compressed[loc_msg_idx], dict):

                        compressed[loc_msg_idx] = dict(compressed[loc_msg_idx])

                        compressed[loc_msg_idx]["content"] = new_text

                    else:

                        try:

                            compressed[loc_msg_idx].content = new_text

                        except (AttributeError, TypeError):

                            pass

                    tokens_saved += (original_len - len(new_text)) // 4



        boilerplate_saved = self._compress_boilerplate(compressed)

        tokens_saved += boilerplate_saved



        if tokens_saved > 0:

            logger.info(

                "[ContextMgr] action=semantic_compress repeated_phrases=%d tokens_saved=%d",

                len(repeated_keys), tokens_saved,

            )



        return compressed, tokens_saved



    def _compress_boilerplate(self, messages: list) -> int:

        """Compress boilerplate patterns in messages. Returns tokens saved."""

        tokens_saved = 0

        for i, msg in enumerate(messages):

            text = self._get_msg_text(msg)

            if not text or len(text) < 30:

                continue

            original_len = len(text)

            new_text = text

            for pattern, replacement in self._BOILERPLATE_PATTERNS:

                new_text = pattern.sub(replacement, new_text)

            if len(new_text) < original_len:

                if isinstance(msg, dict):

                    msg["content"] = new_text

                else:

                    try:

                        msg.content = new_text

                    except (AttributeError, TypeError):

                        continue

                tokens_saved += (original_len - len(new_text)) // 4

        return tokens_saved



    def _auto_select_strategy_from_benchmarks(self, messages: list) -> str:

        """Auto-select the best compaction strategy from benchmark history.



        If we have benchmark history, use the most recent recommended strategy.

        Otherwise, fall back to heuristic selection and run a benchmark.

        """

        if self._benchmark_history:

            latest = self._benchmark_history[-1]

            recommended = latest.get("recommended", "balanced")

            self._auto_selected_strategy = recommended

            return recommended



        benchmark = self.benchmark_strategies(messages)

        self._auto_selected_strategy = benchmark.get("recommended", "balanced")

        return self._auto_selected_strategy



    def _recycle_tool_results(

        self,

        messages: list,

        max_result_length: int = 2000,

    ) -> int:

        """Recycle tokens by truncating oversized tool results in-place.



        Unlike compaction (which removes messages), this keeps the message

        but shortens its content.  First 1500 chars and last 500 chars are

        preserved so that tool name, inputs, and final status remain visible.



        Returns:

            Estimated number of tokens recycled.

        """

        HEAD_CHARS = 1500

        TAIL_CHARS = 500

        tokens_recycled = 0



        for msg in messages:

            role = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

            else:

                role = getattr(msg, "role", "")



            if role != "tool":

                continue



            content = None

            is_dict = isinstance(msg, dict)

            if is_dict:

                content = msg.get("content", "")

            else:

                content = getattr(msg, "content", "")



            if isinstance(content, list):

                text_parts = []

                for block in content:

                    if isinstance(block, dict) and block.get("type") == "text":

                        text_parts.append(block.get("text", ""))

                    elif isinstance(block, str):

                        text_parts.append(block)

                content = " ".join(text_parts)



            if not isinstance(content, str) or len(content) <= max_result_length:

                continue



            original_len = len(content)

            truncated = content[:HEAD_CHARS] + f"\n[...truncated {original_len - HEAD_CHARS - TAIL_CHARS} chars...]\n" + content[-TAIL_CHARS:]

            truncated_len = len(truncated)

            recycled_estimate = (original_len - truncated_len) // 4



            if is_dict:

                msg["content"] = truncated

            else:

                try:

                    msg.content = truncated

                except (AttributeError, TypeError):

                    continue



            tokens_recycled += max(0, recycled_estimate)



        if tokens_recycled > 0:

            logger.info(

                "[ContextMgr] action=token_recycling recycled=%d max_result_length=%d",

                tokens_recycled, max_result_length,

            )



        return tokens_recycled



    def _select_compaction_model(self, context_pressure: float, strategy: str = "") -> str:

        if context_pressure > 2.0:

            return "local"

        if context_pressure < 1.5:

            return "llm"

        return "local"



    async def _multi_model_compact(

        self,

        messages: list,

        strategy: str = "balanced",

    ) -> str:

        """Multi-model compaction using different models for different parts.



        Strategy:

        - Tool result summarization → fast local model (cheapest)

        - Conversation summarization → free cloud model (moderate quality)

        - Critical compaction decisions → main LLM (highest quality)



        This reduces cost while maintaining quality by routing each

        sub-task to the most cost-effective model that can handle it.



        Args:

            messages: Messages to compact.

            strategy: Compaction strategy hint.



        Returns:

            Compacted summary string.

        """

        tool_messages = []

        conversation_messages = []



        for msg in messages:

            role = ""

            has_tool_use = False

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") in ("tool_use", "tool_result")

                        for c in content

                    )

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") in ("tool_use", "tool_result")

                        for c in content

                    )



            if role == "tool" or has_tool_use:

                tool_messages.append(msg)

            elif role in ("user", "assistant"):

                conversation_messages.append(msg)



        tool_summary = ""

        if tool_messages:

            tool_summary = await self._compact_with_local_model(tool_messages, "tool_summarization")



        conversation_summary = ""

        if conversation_messages:

            conversation_summary = await self._compact_with_free_model(conversation_messages, strategy)



        if tool_summary and conversation_summary:

            combined = f"## Tool Execution Summary\n{tool_summary}\n\n## Conversation Summary\n{conversation_summary}"

        elif tool_summary:

            combined = f"## Tool Execution Summary\n{tool_summary}"

        elif conversation_summary:

            combined = conversation_summary

        else:

            anchors = _extract_anchors(messages)

            combined = self._emergency_compact(messages, anchors)



        if combined and self._is_valid_summary(combined):

            quality = self._score_summary_quality(combined, len(messages))

            if quality < 0.3:

                anchors = _extract_anchors(messages)

                llm_summary = await self._compact_with_llm(messages, strategy)

                if llm_summary and self._is_valid_summary(llm_summary):

                    llm_quality = self._score_summary_quality(llm_summary, len(messages))

                    if llm_quality > quality:

                        combined = llm_summary



        logger.info(

            "[ContextMgr] action=multi_model_compact tool_msgs=%d conv_msgs=%d "

            "has_tool_summary=%s has_conv_summary=%s final_len=%d",

            len(tool_messages), len(conversation_messages),

            bool(tool_summary), bool(conversation_summary), len(combined),

        )



        return combined



    async def _compact_with_local_model(

        self,

        messages: list,

        sub_task: str,

    ) -> str:

        """Compact messages using a fast local model.



        Used for tool result summarization where speed matters more

        than nuanced understanding.



        Args:

            messages: Tool-related messages to compact.

            sub_task: Name of the sub-task for logging.



        Returns:

            Summary string, or empty string on failure.

        """

        try:

            from ...local_model_dispatcher import LocalModelDispatcher

            dispatcher = LocalModelDispatcher.get_instance()

            if not dispatcher.has_local_model("memory_compact"):

                return ""



            input_text = _messages_to_text(messages, "light")

            if not input_text.strip():

                return ""



            result = await dispatcher.dispatch(

                task_type="memory_compact",

                input_text=input_text,

                max_new_tokens=128,

                temperature=0.2,

                collect_data=False,

            )

            if result and self._is_valid_summary(result):

                return result

        except Exception as _local_err:

            logger.debug("[ContextMgr] action=local_model_compact_failed sub_task=%s error=%s", sub_task, _local_err)

        return ""



    async def _compact_with_free_model(

        self,

        messages: list,

        strategy: str,

    ) -> str:

        """Compact messages using a free cloud model.



        Used for conversation summarization where moderate quality

        is sufficient and cost must be zero.



        Args:

            messages: Conversation messages to compact.

            strategy: Compaction strategy hint.



        Returns:

            Summary string, or empty string on failure.

        """

        try:

            from ....smart_llm_client import SmartLLMClient

            client = SmartLLMClient._instance

            if client is None:

                return ""



            input_text = _messages_to_text(messages, "medium")

            if not input_text.strip():

                return ""



            result = await client.ask_free_model(

                prompt=input_text,

                system=self._get_compaction_prompt(strategy),

                max_tokens=384,

            )

            if result and self._is_valid_summary(result):

                return result

        except Exception as _free_err:

            logger.debug("[ContextMgr] action=free_model_compact_failed error=%s", _free_err)

        return ""



    async def _compact_with_llm(

        self,

        messages: list,

        strategy: str,

    ) -> str:

        """Compact messages using the main LLM.



        Used only for critical compaction decisions where the

        highest quality is required.



        Args:

            messages: Messages to compact.

            strategy: Compaction strategy hint.



        Returns:

            Summary string, or empty string on failure.

        """

        try:

            input_text = _messages_to_text(messages, "full")

            if not input_text.strip():

                return ""



            compact_content = await self.memory_manager.compact_memory(

                messages=messages,

                previous_summary="",

            )

            if compact_content and self._is_valid_summary(compact_content):

                return compact_content

        except Exception as _llm_err:

            logger.debug("[ContextMgr] action=llm_compact_failed error=%s", _llm_err)

        return ""



    _RECENT_WINDOW_SECONDS = 300

    _SESSION_WINDOW_SECONDS = 1800



    def _calculate_temporal_priority(self, messages: list) -> list[float]:

        """Calculate temporal priority for each message.



        Recent messages (last 5 minutes) get higher priority.

        Messages from the same "session" (within 30 minutes) are kept together.

        This ensures that active conversations are not broken up during compaction.



        Priority scale: 0.0 (oldest, lowest) to 1.0 (newest, highest).



        Args:

            messages: List of messages with optional timestamps.



        Returns:

            List of temporal priority floats, one per message.

        """

        import time as _tp_time



        if not messages:

            return []



        now = _tp_time.time()

        timestamps: list[float] = []



        for msg in messages:

            ts = None

            if isinstance(msg, dict):

                ts = msg.get("_timestamp", msg.get("timestamp"))

            else:

                ts = getattr(msg, "_timestamp", None) or getattr(msg, "timestamp", None)



            if ts is not None:

                try:

                    ts = float(ts)

                except (TypeError, ValueError):

                    ts = None



            if ts is None:

                ts = now - (len(messages) - len(timestamps)) * 60.0



            timestamps.append(ts)



        if not timestamps:

            return [0.5] * len(messages)



        min_ts = min(timestamps)

        max_ts = max(timestamps)

        ts_range = max_ts - min_ts if max_ts > min_ts else 1.0



        raw_priorities: list[float] = []

        for ts in timestamps:

            age_seconds = now - ts

            if age_seconds <= self._RECENT_WINDOW_SECONDS:

                recency_bonus = 1.0 - (age_seconds / self._RECENT_WINDOW_SECONDS) * 0.3

                raw_priorities.append(0.7 + recency_bonus * 0.3)

            elif age_seconds <= self._SESSION_WINDOW_SECONDS:

                session_fraction = 1.0 - (age_seconds - self._RECENT_WINDOW_SECONDS) / (self._SESSION_WINDOW_SECONDS - self._RECENT_WINDOW_SECONDS)

                raw_priorities.append(0.4 + session_fraction * 0.3)

            else:

                normalized_age = (ts - min_ts) / ts_range

                raw_priorities.append(0.1 + normalized_age * 0.3)



        session_groups = self._identify_session_groups(timestamps)

        if session_groups:

            group_boost = 0.1

            current_group = None

            for i, ts in enumerate(timestamps):

                for group_idx, (group_start, group_end) in enumerate(session_groups):

                    if group_start <= ts <= group_end:

                        if current_group is not None and current_group != group_idx:

                            raw_priorities[i] = min(1.0, raw_priorities[i] + group_boost)

                        current_group = group_idx

                        break



        return raw_priorities



    def _identify_session_groups(self, timestamps: list[float]) -> list[tuple[float, float]]:

        """Identify session groups from timestamps.



        A session group is a cluster of messages where consecutive messages

        are within the session window (30 minutes) of each other.



        Args:

            timestamps: Sorted list of message timestamps.



        Returns:

            List of (start_ts, end_ts) tuples for each session group.

        """

        if not timestamps:

            return []



        sorted_ts = sorted(timestamps)

        groups: list[tuple[float, float]] = []

        group_start = sorted_ts[0]

        group_end = sorted_ts[0]



        for ts in sorted_ts[1:]:

            if ts - group_end <= self._SESSION_WINDOW_SECONDS:

                group_end = ts

            else:

                groups.append((group_start, group_end))

                group_start = ts

                group_end = ts



        groups.append((group_start, group_end))

        return groups



    def _apply_temporal_priority_to_compaction(

        self,

        messages: list,

        messages_to_compact: list,

    ) -> list:

        """Reorder messages_to_compact using temporal priority.



        Messages with lower temporal priority are placed first (compacted first).

        Messages with higher temporal priority are placed last (preserved longer).



        Args:

            messages: All messages (for timestamp reference).

            messages_to_compact: Messages selected for compaction.



        Returns:

            Reordered messages_to_compact.

        """

        all_priorities = self._calculate_temporal_priority(messages)



        msg_id_to_priority: dict[Any, float] = {}

        for i, msg in enumerate(messages):

            msg_id = id(msg)

            if i < len(all_priorities):

                msg_id_to_priority[msg_id] = all_priorities[i]



        scored = []

        for msg in messages_to_compact:

            priority = msg_id_to_priority.get(id(msg), 0.5)

            scored.append((priority, msg))



        scored.sort(key=lambda x: x[0])



        low_count = sum(1 for p, _ in scored if p < 0.3)

        high_count = sum(1 for p, _ in scored if p > 0.7)

        if low_count > 0 or high_count > 0:

            logger.info(

                "[ContextMgr] action=temporal_reorder total=%d low_priority=%d high_priority=%d",

                len(scored), low_count, high_count,

            )



        return [msg for _, msg in scored]



    _INTENT_KEYWORDS: dict[str, list[str]] = {

        "code_generation": ["写代码", "生成代码", "创建文件", "实现功能", "write code", "generate", "create file", "implement"],

        "debugging": ["调试", "修复bug", "报错", "错误", "debug", "fix bug", "error", "traceback", "修复问题"],

        "analysis": ["分析", "解释", "为什么", "如何工作", "analyze", "explain", "why", "how does"],

        "search": ["搜索", "查找", "找到", "search", "find", "look for", "查询"],

        "refactoring": ["重构", "优化", "改进", "refactor", "optimize", "improve", "clean up"],

        "learning": ["学习", "了解", "教程", "learn", "understand", "tutorial", "教我"],

        "deployment": ["部署", "发布", "上线", "deploy", "release", "publish", "ship"],

        "testing": ["测试", "验证", "test", "verify", "validate", "检查"],

    }



    def _extract_user_intent(self, messages: list) -> str:

        """Extract the user's primary intent from the conversation.



        Analyzes user messages to determine what the user is primarily

        trying to accomplish. Returns the most recent dominant intent.



        Args:

            messages: Conversation messages.



        Returns:

            String describing the user's primary intent.

        """

        user_messages = []

        for msg in messages:

            role = ""

            text = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)



            if role == "user" and text.strip():

                user_messages.append(text.strip())



        if not user_messages:

            return "general_conversation"



        intent_scores: dict[str, float] = {}

        for intent, keywords in self._INTENT_KEYWORDS.items():

            score = 0.0

            for user_msg in user_messages:

                msg_lower = user_msg.lower()

                for kw in keywords:

                    if kw in msg_lower:

                        score += 1.0

                        break

            if score > 0:

                recency_weight = 1.0

                for user_msg in reversed(user_messages):

                    msg_lower = user_msg.lower()

                    for kw in keywords:

                        if kw in msg_lower:

                            score += recency_weight

                            break

                    recency_weight *= 0.8

            intent_scores[intent] = score



        if not intent_scores:

            last_msg = user_messages[-1][:100] if user_messages else ""

            return f"general: {last_msg}" if last_msg else "general_conversation"



        best_intent = max(intent_scores, key=intent_scores.get)

        best_score = intent_scores[best_intent]



        if best_score <= 0:

            last_msg = user_messages[-1][:100] if user_messages else ""

            return f"general: {last_msg}" if last_msg else "general_conversation"



        last_user_msg = user_messages[-1][:150] if user_messages else ""

        return f"{best_intent}: {last_user_msg}"



    def _track_intent_changes(self, messages: list) -> list[str]:

        """Track intent changes throughout the conversation.



        Analyzes the conversation in segments to detect when the user's

        intent shifts. This is important for compaction because each

        intent shift represents a new topic that should be preserved

        as a distinct section in the summary.



        Args:

            messages: Conversation messages.



        Returns:

            List of intent strings, one per detected intent phase.

        """

        if not messages:

            return []



        user_indices = []

        for i, msg in enumerate(messages):

            role = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

            else:

                role = getattr(msg, "role", "")

            if role == "user":

                user_indices.append(i)



        if len(user_indices) <= 1:

            intent = self._extract_user_intent(messages)

            return [intent] if intent else []



        segment_size = max(1, len(user_indices) // 4)

        segments: list[list[int]] = []

        current_segment: list[int] = []



        for idx in user_indices:

            current_segment.append(idx)

            if len(current_segment) >= segment_size:

                segments.append(current_segment)

                current_segment = []



        if current_segment:

            if segments:

                segments[-1].extend(current_segment)

            else:

                segments.append(current_segment)



        intents: list[str] = []

        for segment_indices in segments:

            segment_messages = [messages[i] for i in segment_indices if i < len(messages)]

            if segment_messages:

                intent = self._extract_user_intent(segment_messages)

                if intent:

                    intents.append(intent)



        if intents:

            deduped = [intents[0]]

            for intent in intents[1:]:

                intent_category = intent.split(":")[0] if ":" in intent else intent

                last_category = deduped[-1].split(":")[0] if ":" in deduped[-1] else deduped[-1]

                if intent_category != last_category:

                    deduped.append(intent)

            intents = deduped



        return intents



    def _build_intent_context_for_prompt(self, messages: list) -> str:

        """Build intent context to include in the compaction prompt.



        This ensures the current user intent is clearly stated in the

        summary, so the LLM can prioritize preserving intent-relevant

        information during compaction.



        Args:

            messages: Conversation messages.



        Returns:

            String to prepend to the compaction input text.

        """

        current_intent = self._extract_user_intent(messages)

        intent_history = self._track_intent_changes(messages)



        parts = []

        if current_intent:

            parts.append(f"[CURRENT USER INTENT: {current_intent}]")



        if len(intent_history) > 1:

            history_str = " → ".join(intent_history)

            parts.append(f"[INTENT EVOLUTION: {history_str}]")

        elif intent_history:

            parts.append(f"[INTENT: {intent_history[0]}]")



        return "\n".join(parts) + "\n\n" if parts else ""



    def _get_model_attempt_order(self, context_pressure: float) -> list[str]:

        if context_pressure > 2.0:

            return ["local", "free", "llm"]

        if context_pressure < 1.5:

            return ["llm", "free", "local"]

        return ["local", "free", "llm"]



    @staticmethod

    def _score_message_relevance(msg: Any, recent_user_messages: list[str]) -> float:

        """Score a message for relevance to the current task.



        Uses keyword overlap with the last 3 user messages.

        Returns 0.0-1.0 where >0.5 = high relevance, <0.1 = low relevance.

        """

        if not recent_user_messages:

            return 0.5



        text = ""

        if isinstance(msg, dict):

            content = msg.get("content", "")

            if isinstance(content, list):

                text = " ".join(

                    b.get("text", "") for b in content

                    if isinstance(b, dict) and b.get("type") == "text"

                )

            else:

                text = str(content)

        else:

            content = getattr(msg, "content", "")

            if isinstance(content, list):

                text = " ".join(

                    b.get("text", "") for b in content

                    if isinstance(b, dict) and b.get("type") == "text"

                )

            else:

                text = str(content)



        if not text.strip():

            return 0.0



        role = ""

        if isinstance(msg, dict):

            role = msg.get("role", "")

        else:

            role = getattr(msg, "role", "")



        if role == "system":

            return 1.0



        import re as _re_mod

        msg_words = set(_re_mod.findall(r'\w+', text.lower()))

        if not msg_words:

            return 0.0



        query_words: set[str] = set()

        for user_text in recent_user_messages:

            query_words.update(_re_mod.findall(r'\w+', user_text.lower()))



        if not query_words:

            return 0.5



        overlap = msg_words & query_words

        raw_score = len(overlap) / min(len(msg_words), len(query_words))



        if role == "user":

            raw_score = max(raw_score, 0.4)

        elif role == "tool":

            raw_score = max(raw_score, 0.2)



        return min(1.0, raw_score)



    def _reorder_by_relevance(

        self,

        messages_to_compact: list,

        all_messages: list,

    ) -> list:

        """Reorder messages so less relevant ones are compacted first.



        High-relevance messages (>0.5) are moved to the end (kept longer),

        low-relevance messages (<0.1) are moved to the front (compacted first).

        """

        recent_user_messages = []

        for msg in reversed(all_messages):

            role = ""

            if isinstance(msg, dict):

                role = msg.get("role", "")

            else:

                role = getattr(msg, "role", "")

            if role == "user":

                text = ""

                if isinstance(msg, dict):

                    content = msg.get("content", "")

                    if isinstance(content, list):

                        text = " ".join(

                            b.get("text", "") for b in content

                            if isinstance(b, dict) and b.get("type") == "text"

                        )

                    else:

                        text = str(content)

                else:

                    content = getattr(msg, "content", "")

                    if isinstance(content, list):

                        text = " ".join(

                            b.get("text", "") for b in content

                            if isinstance(b, dict) and b.get("type") == "text"

                        )

                    else:

                        text = str(content)

                if text.strip():

                    recent_user_messages.append(text.strip())

            if len(recent_user_messages) >= 3:

                break



        if not recent_user_messages:

            return messages_to_compact



        scored = [

            (msg, self._score_message_relevance(msg, recent_user_messages))

            for msg in messages_to_compact

        ]

        scored.sort(key=lambda x: x[1])



        low_count = sum(1 for _, s in scored if s < 0.1)

        high_count = sum(1 for _, s in scored if s > 0.5)

        if low_count > 0 or high_count > 0:

            logger.info(

                "[ContextMgr] action=relevance_reorder total=%d low_relevance=%d high_relevance=%d",

                len(scored), low_count, high_count,

            )



        return [msg for msg, _ in scored]



    @staticmethod

    def _detect_fragmentation(messages: list) -> tuple[bool, float]:

        """Detect context window fragmentation.



        Calculates:

        - Tool message ratio (tool messages / total)

        - Message length variance



        Returns (is_fragmented, fragmentation_score) where score is 0.0-1.0.

        Fragmented if >70% tool messages or high length variance.

        """

        if not messages:

            return (False, 0.0)



        tool_count = 0

        text_count = 0

        lengths: list[int] = []



        for msg in messages:

            role = ""

            text = ""

            has_tool_use = False

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") in ("tool_use", "tool_result")

                        for c in content

                    )

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") in ("tool_use", "tool_result")

                        for c in content

                    )

                    text = " ".join(

                        b.get("text", "") for b in content

                        if isinstance(b, dict) and b.get("type") == "text"

                    )

                else:

                    text = str(content)



            if role == "tool" or has_tool_use:

                tool_count += 1

            elif role in ("user", "assistant"):

                text_count += 1



            lengths.append(len(text))



        total = tool_count + text_count

        if total == 0:

            return (False, 0.0)



        tool_ratio = tool_count / total

        tool_fragmentation = max(0.0, (tool_ratio - 0.5) / 0.5) if tool_ratio > 0.5 else 0.0



        if len(lengths) >= 2:

            avg_len = sum(lengths) / len(lengths)

            if avg_len > 0:

                variance = sum((l - avg_len) ** 2 for l in lengths) / len(lengths)

                cv = (variance ** 0.5) / avg_len

                length_fragmentation = min(1.0, cv / 3.0)

            else:

                length_fragmentation = 0.0

        else:

            length_fragmentation = 0.0



        fragmentation_score = tool_fragmentation * 0.6 + length_fragmentation * 0.4

        is_fragmented = tool_ratio > 0.7 or fragmentation_score > 0.6



        return (is_fragmented, round(fragmentation_score, 3))



    def _select_compaction_strategy(self, messages_to_compact: list) -> str:

        tool_count = 0

        text_count = 0

        for msg in messages_to_compact:

            role = ""

            has_tool_use = False

            if isinstance(msg, dict):

                role = msg.get("role", "")

                content = msg.get("content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") == "tool_use"

                        for c in content

                    )

            else:

                role = getattr(msg, "role", "")

                content = getattr(msg, "content", "")

                if isinstance(content, list):

                    has_tool_use = any(

                        isinstance(c, dict) and c.get("type") == "tool_use"

                        for c in content

                    )

            if role == "tool" or has_tool_use:

                tool_count += 1

            elif role in ("user", "assistant"):

                text_count += 1

        total = tool_count + text_count

        if total == 0:

            return "balanced"

        tool_ratio = tool_count / total

        text_ratio = text_count / total

        if tool_ratio > 0.6:

            return "tool_focused"

        if text_ratio > 0.6:

            return "text_focused"

        return "balanced"



    def _predict_overflow(

        self,

        messages: list,

        token_counts: list[int],

        threshold: int,

    ) -> tuple[bool, int]:

        total_tokens = sum(token_counts)

        remaining_budget = max(0, threshold - total_tokens)

        if not token_counts:

            return (False, 0)

        avg_tokens_per_msg = total_tokens / len(token_counts)

        if avg_tokens_per_msg <= 0:

            return (False, 0)

        messages_until_overflow = int(remaining_budget / avg_tokens_per_msg)

        will_overflow_soon = messages_until_overflow < 5

        return (will_overflow_soon, messages_until_overflow)



    def _predict_context_growth(

        self,

        token_counts: list[int],

        threshold: int,

    ) -> tuple[int, float]:

        if not token_counts:

            return (999, 0.0)



        cumulative: list[int] = []

        running = 0

        for tc in token_counts:

            running += tc

            cumulative.append(running)



        current_total = cumulative[-1]



        if len(cumulative) < 3:

            avg_rate = current_total / max(1, len(token_counts))

            if avg_rate <= 0:

                return (999, 0.0)

            remaining = max(0, threshold - current_total)

            return (int(remaining / avg_rate), round(avg_rate, 2))



        window = min(len(cumulative), 20)

        recent = cumulative[-window:]

        n = len(recent)

        x_mean = (n - 1) / 2.0

        y_mean = sum(recent) / n

        numerator = sum((i - x_mean) * (recent[i] - y_mean) for i in range(n))

        denominator = sum((i - x_mean) ** 2 for i in range(n))



        if abs(denominator) < 1e-9:

            growth_rate = (recent[-1] - recent[0]) / max(1, n - 1) if n > 1 else 0.0

        else:

            slope = numerator / denominator

            growth_rate = slope



        growth_rate = max(growth_rate, 0.0)

        remaining_budget = max(0, threshold - current_total)



        if growth_rate <= 0:

            return (999, round(growth_rate, 2))



        messages_until_full = int(remaining_budget / growth_rate)



        logger.info(

            "[ContextMgr] action=growth_prediction total_tokens=%d threshold=%d "

            "growth_rate=%.1f msgs_until_full=%d window=%d cumulative_samples=%d",

            current_total, threshold, growth_rate, messages_until_full, window, n,

        )



        return (messages_until_full, round(growth_rate, 2))



    def _prepend_version_header(self, content: str, compact_count: int) -> str:

        self._summary_version += 1

        from datetime import datetime as _dt

        ts = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")

        header = f"[v{self._summary_version} | {ts} | {compact_count} msgs compacted]"

        return f"{header}\n{content}"



    async def recover_context(self, memory: Any) -> bool:

        try:

            compressed_summary = memory.get_compressed_summary()

            if not compressed_summary:

                return False

            if self._is_valid_summary(compressed_summary):

                return False

            logger.warning(

                "[ContextMgr] action=corrupted_summary len=%d attempting reconstruction",

                len(compressed_summary),

            )

            messages = await memory.get_memory(prepend_summary=False)

            if not messages:

                return False

            reconstructed_parts = ["## 重建的上下文 / Reconstructed Context\n"]

            for msg in messages[:30]:

                text = ""

                if hasattr(msg, 'get_text_content'):

                    text = msg.get_text_content() or ""

                elif hasattr(msg, 'content'):

                    content = msg.content

                    if isinstance(content, list):

                        text = " ".join(

                            b.get("text", "") for b in content

                            if isinstance(b, dict) and b.get("type") == "text"

                        )

                    else:

                        text = str(content)

                if text:

                    role = getattr(msg, 'role', 'unknown')

                    reconstructed_parts.append(f"- [{role}] {text[:200]}")

            reconstructed = "\n".join(reconstructed_parts)

            if self._is_valid_summary(reconstructed):

                await memory.update_compressed_summary(reconstructed)

                logger.info(

                    "[ContextMgr] action=reconstruction_success len=%d from=%d messages",

                    len(reconstructed), len(messages),

                )

                return True

            logger.warning("[ContextMgr] action=reconstruction_failed clearing corrupted summary")

            await memory.update_compressed_summary("")

            return False

        except Exception as _recover_err:

            logger.debug("[ContextMgr] action=context_recovery_failed error=%s", _recover_err)

            return False



    async def __call__(

        self,

        agent: ReActAgent,

        kwargs: dict[str, Any],

    ) -> dict[str, Any] | None:

        _compact_stage = "init"

        _context_pressure = 0.0

        messages_to_compact = []

        _compaction_start_ms = 0.0

        _compaction_timer = _CompactionTimer()

        try:

            import time as _t0

            _compaction_start_ms = _t0.monotonic() * 1000

            _compaction_timer.start_stage("init")

            agent_config = load_agent_config(self.memory_manager.agent_id)

            running_config = agent_config.running

            token_counter = get_xingzierai_token_counter(agent_config)



            memory = agent.memory



            await self.recover_context(memory)



            if self._should_refresh_summary(memory, self._last_compaction_timestamp):

                await self._refresh_stale_summary(memory, agent)



            system_prompt = agent.sys_prompt

            compressed_summary = memory.get_compressed_summary()

            str_token_count = await token_counter.count(

                messages=[],

                text=(system_prompt or "") + (compressed_summary or ""),

            )



            tools_token_count = 0

            try:

                tool_schemas = agent.toolkit.get_json_schemas() if agent.toolkit else []

                if tool_schemas:

                    tools_text = json.dumps(tool_schemas, ensure_ascii=False)

                    tools_token_count = await token_counter.count(

                        messages=[],

                        text=tools_text,

                    )

            except Exception as e:

                logger.debug("Failed to count tool tokens: %s", e)

                tools_token_count = 0



            overhead_tokens = str_token_count + tools_token_count



            left_compact_threshold = (

                running_config.memory_compact_threshold - overhead_tokens

            )

            left_compact_threshold = self._get_adaptive_threshold(left_compact_threshold)



            if left_compact_threshold <= 0:

                logger.warning(

                    "[ContextMgr] action=threshold_too_low system_prompt+summary exceed memory_compact_threshold",

                )

                return None



            _compaction_timer.end_stage()



            messages = await memory.get_memory(prepend_summary=False)



            self._record_conversation_length(len(messages))



            recent_threshold = (

                running_config.tool_result_compact_recent_threshold

            )

            retention_days = running_config.tool_result_compact_retention_days

            await self.memory_manager.compact_tool_result(

                messages=messages,

                recent_n=running_config.tool_result_compact_recent_n,

                old_threshold=running_config.tool_result_compact_old_threshold,

                recent_threshold=recent_threshold,

                retention_days=retention_days,

            )



            from ...utils import context_check



            messages = await memory.get_memory(prepend_summary=False)



            messages, _dedup_removed = self._deduplicate_messages(messages)

            if _dedup_removed > 0:

                logger.info(

                    "[ContextMgr] action=deduplication removed=%d remaining=%d",

                    _dedup_removed, len(messages),

                )



            recycled_tokens = self._recycle_tool_results(messages, max_result_length=2000)

            if recycled_tokens > 0:

                self._metrics["total_tokens_recycled"] = self._metrics.get("total_tokens_recycled", 0) + recycled_tokens



            messages, semantic_tokens_saved = self._semantic_compress(messages)

            if semantic_tokens_saved > 0:

                self._metrics["total_tokens_recycled"] = self._metrics.get("total_tokens_recycled", 0) + semantic_tokens_saved



            from ...context_manager import ActiveContextManager



            ctx_mgr = ActiveContextManager()

            keep_recent = self._calculate_keep_recent(messages, 0.0)

            folded_outcomes = ctx_mgr.extract_folded_outcomes(

                messages, keep_recent=keep_recent,

            )

            if folded_outcomes:

                logger.info(

                    "[ContextMgr] action=context_folding folded=%d keep_recent=%d total_msgs=%d recycled_tokens=%d",

                    len(folded_outcomes), keep_recent, len(messages), recycled_tokens,

                )



            import time as _time

            _compaction_timer.start_stage("token_counting")

            _token_count_start = _time.monotonic()

            estimated_tokens = []

            _BATCH_SIZE = 10

            _batch_texts = []

            _batch_indices = []

            for _idx, msg in enumerate(messages):

                try:

                    text_content = msg.get_text_content() or ""

                    if text_content:

                        _batch_texts.append(text_content)

                        _batch_indices.append(_idx)

                    else:

                        estimated_tokens.append(max(1, len(str(msg.content or "")) // 4))

                except Exception as _msg_err:

                    logger.debug("Token estimation per-msg fallback: %s", _msg_err)

                    estimated_tokens.append(max(1, len(str(msg.content or "")) // 4))

                if len(_batch_texts) >= _BATCH_SIZE or (_idx == len(messages) - 1 and _batch_texts):

                    try:

                        batch_combined = "\n".join(_batch_texts)

                        batch_total = await token_counter.count(

                            messages=[], text=batch_combined,

                        )

                        per_msg_estimate = batch_total / len(_batch_texts)

                        for _ in _batch_texts:

                            estimated_tokens.append(int(per_msg_estimate))

                    except Exception as _batch_err:

                        logger.debug("Batch token counting fallback: %s", _batch_err)

                        for txt in _batch_texts:

                            estimated_tokens.append(max(1, len(txt) // 4))

                    _batch_texts = []

                    _batch_indices = []

            _token_count_elapsed = _time.monotonic() - _token_count_start

            if _token_count_elapsed > 1.0:

                logger.info(

                    "[ContextMgr] action=token_counting_slow elapsed=%.2fs messages=%d",

                    _token_count_elapsed, len(messages),

                )

            else:

                logger.debug(

                    "[ContextMgr] action=token_counting elapsed=%.2fs messages=%d",

                    _token_count_elapsed, len(messages),

                )



            total_tokens = sum(estimated_tokens)

            _compaction_timer.end_stage()



            self._token_growth_history.append(total_tokens)

            if len(self._token_growth_history) > 50:

                self._token_growth_history = self._token_growth_history[-50:]



            will_overflow_soon, msgs_until_overflow = self._predict_overflow(

                messages, estimated_tokens, left_compact_threshold,

            )

            msgs_until_full, growth_rate = self._predict_context_growth(

                estimated_tokens, left_compact_threshold,

            )

            effective_threshold = left_compact_threshold

            if will_overflow_soon:

                effective_threshold = int(0.8 * left_compact_threshold)

                logger.info(

                    "[ContextMgr] action=overflow_prediction will_overflow_soon=%s msgs_until_overflow=%d effective_threshold=%d (80%% of %d)",

                    will_overflow_soon, msgs_until_overflow, effective_threshold, left_compact_threshold,

                )

            elif msgs_until_full <= 5 and growth_rate > 0:

                proactive_threshold = int(0.85 * left_compact_threshold)

                if proactive_threshold < effective_threshold:

                    effective_threshold = proactive_threshold

                    logger.info(

                        "[ContextMgr] action=proactive_compaction growth_rate=%.1f msgs_until_full=%d effective_threshold=%d (85%% of %d)",

                        growth_rate, msgs_until_full, effective_threshold, left_compact_threshold,

                    )



            if total_tokens < effective_threshold:

                warning_lower = 0.7 * effective_threshold

                if total_tokens >= warning_lower and not self._warning_sent:

                    self._warning_sent = True

                    utilization_pct = int(total_tokens / effective_threshold * 100)

                    await self._print_status_message(

                        agent,

                        f"📊 上下文使用率较高 / Context usage is high ({utilization_pct}%). "

                        f"对话可能即将压缩 / Compaction may occur soon.",

                    )

                return None



            context_pressure = total_tokens / effective_threshold if effective_threshold > 0 else 1.0

            self._pressure_history.append(context_pressure)

            if len(self._pressure_history) > 10:

                self._pressure_history = self._pressure_history[-10:]

            smoothed_pressure = (

                sum(self._pressure_history[-3:]) / len(self._pressure_history[-3:])

                if self._pressure_history

                else context_pressure

            )

            _context_pressure = context_pressure

            self._current_context_pressure = context_pressure

            utilization = total_tokens / (left_compact_threshold + total_tokens) * 100 if (left_compact_threshold + total_tokens) > 0 else 0.0

            logger.info(

                "[ContextMgr] action=pre_compaction total_msgs=%d total_tokens=%d threshold=%d pressure=%.2fx utilization=%.0f%% overflow_soon=%s msgs_until_overflow=%d",

                len(messages), total_tokens, effective_threshold, context_pressure, utilization, will_overflow_soon, msgs_until_overflow,

            )

            if context_pressure > 2.0:

                logger.warning(

                    "[ContextMgr] action=critical_pressure pressure=%.2fx tokens=%d threshold=%d",

                    context_pressure, total_tokens, effective_threshold,

                )



            context_compact_reserve = running_config.memory_compact_reserve



            messages_to_compact, messages_to_keep, _, _ = context_check(

                messages=messages,

                context_compact_threshold=effective_threshold,

                context_compact_reserve=context_compact_reserve,

                token_counts=estimated_tokens,

            )



            if not messages_to_compact:

                return None



            self._warning_sent = False



            compact_count = len(messages_to_compact)

            keep_count = len(messages_to_keep)

            total_msgs = len(messages)



            compact_msg_ids = tuple(

                getattr(m, 'id', id(m)) for m in messages_to_compact

            )

            compact_hash = hash(compact_msg_ids)

            if compact_hash == self._last_compact_hash and self._last_compact_result is not None:

                logger.info(

                    "[ContextMgr] action=cache_hit compact_count=%d",

                    compact_count,

                )

                return self._last_compact_result



            messages_to_compact = self._reorder_by_relevance(

                messages_to_compact, messages,

            )



            compaction_strategy = self._select_compaction_strategy(messages_to_compact)



            anchors = _extract_anchors(messages_to_compact)



            cached_result = self._check_predictive_cache(

                self.memory_manager.agent_id,

                compact_count,

                context_pressure,

            )

            if cached_result is not None:

                compact_content = cached_result

                _model_used = "predictive_cache"

                logger.info(

                    "[ContextMgr] action=predictive_cache_used compact_count=%d pressure=%.2fx",

                    compact_count, context_pressure,

                )

                if messages_to_compact and hasattr(memory, 'mark_messages_compressed'):

                    await memory.mark_messages_compressed(messages_to_compact)

                compact_content = self._prepend_version_header(compact_content, compact_count)

                await memory.update_compressed_summary(compact_content)

                self._metrics["total_compactions"] += 1

                self._metrics["total_msgs_compacted"] += compact_count

                self._record_compression_ratio(total_tokens, len(compact_content))

                quality_score = self._score_summary_quality(compact_content, compact_count)

                import time as _pc_time

                _duration_ms = _pc_time.monotonic() * 1000 - _compaction_start_ms

                self._record_telemetry(

                    input_tokens=total_tokens,

                    output_tokens=len(compact_content) // 4,

                    quality_score=quality_score,

                    anchor_score=_validate_anchors(compact_content, anchors) if anchors else 1.0,

                    strategy="predictive_cache",

                    model_used="predictive_cache",

                    duration_ms=_duration_ms,

                )

                self._last_compact_hash = compact_hash

                self._last_compact_result = {"compacted": compact_count}

                _compaction_timer.end_stage()

                return {"compacted": compact_count}



            total_compactions = self._metrics.get("total_compactions", 0)

            if total_compactions > 0 and total_compactions % 50 == 0:

                compaction_strategy = self._auto_select_strategy_from_benchmarks(messages_to_compact)

                logger.info(

                    "[ContextMgr] action=auto_strategy_from_benchmark strategy=%s",

                    compaction_strategy,

                )



            if len(self._learning_buffer) >= 30:

                predicted = self._predict_best_params(context_pressure)

                if predicted.get("confidence", 0.0) > 0.5:

                    compaction_strategy = predicted["strategy"]

                    logger.info(

                        "[ContextMgr] action=adaptive_strategy strategy=%s confidence=%.3f pressure=%.2fx",

                        compaction_strategy, predicted["confidence"], context_pressure,

                    )



            self._emit_event("compaction_started", {

                "compact_count": compact_count,

                "keep_count": keep_count,

                "pressure": context_pressure,

                "strategy": compaction_strategy,

            })

            ab_variant = self._get_ab_test_variant()

            if ab_variant == "B":

                compaction_strategy = "balanced"

                logger.info(

                    "[ContextMgr] action=ab_test_variant_B strategy_override=balanced",

                )

            logger.info(

                "[ContextMgr] action=strategy_selected strategy=%s compact_count=%d keep_count=%d",

                compaction_strategy, compact_count, keep_count,

            )



            is_fragmented, fragmentation_score = self._detect_fragmentation(

                messages_to_compact,

            )

            if is_fragmented:

                logger.warning(

                    "[ContextMgr] action=fragmentation_detected score=%.3f strategy=%s "

                    "suggest=defragment_with_balanced_strategy",

                    fragmentation_score, compaction_strategy,

                )

                if compaction_strategy == "tool_focused":

                    compaction_strategy = "balanced"



            if anchors:

                logger.info(

                    "[ContextMgr] action=anchor_extraction anchor_count=%d top3=%s",

                    len(anchors), [a[:50] for a in anchors[:3]],

                )



            if smoothed_pressure > 2.5 and compact_count > 10:

                _compaction_timer.start_stage("emergency_compaction")

                logger.warning(

                    "[ContextMgr] action=emergency_compaction smoothed_pressure=%.2fx raw_pressure=%.2fx compact_count=%d",

                    smoothed_pressure, context_pressure, compact_count,

                )

                self._emit_event("emergency_triggered", {

                    "smoothed_pressure": smoothed_pressure,

                    "raw_pressure": context_pressure,

                    "compact_count": compact_count,

                })

                if compact_count > 20:

                    compact_content = self._streaming_compress(

                        messages_to_compact, batch_size=10,

                    )

                else:

                    compact_content = self._emergency_compact(

                        messages_to_compact, anchors, folded_outcomes,

                    )

                if compact_content:

                    await self._print_status_message(

                        agent,

                        f"⚡ 紧急压缩 / Emergency compaction\n"

                        f"📊 {total_msgs}条 → 压缩{compact_count}条 + 保留{keep_count}条"

                        + (f" | 🔗 {len(anchors)}个锚点" if anchors else "")

                        + (f" | 📦 {len(folded_outcomes)}个折叠" if folded_outcomes else "")

                        + f" | 压力{context_pressure:.1f}x → 快速截断(无LLM)",

                    )

                    if messages_to_compact and hasattr(memory, 'mark_messages_compressed'):

                        updated_count = await memory.mark_messages_compressed(

                            messages_to_compact,

                        )

                        logger.info(

                            "[ContextMgr] action=emergency_marked marked=%d/%d",

                            updated_count, compact_count,

                        )

                    if compact_content and hasattr(memory, 'update_compressed_summary'):

                        compact_content = self._prepend_version_header(compact_content, compact_count)

                        await memory.update_compressed_summary(compact_content)

                    self._metrics["total_compactions"] += 1

                    self._metrics["emergency_compactions"] += 1

                    self._metrics["total_msgs_compacted"] += compact_count

                    quality_score = self._score_summary_quality(compact_content, compact_count)

                    self._record_compression_ratio(total_tokens, len(compact_content))

                    import time as _te0

                    _duration_ms = _te0.monotonic() * 1000 - _compaction_start_ms

                    self._record_telemetry(

                        input_tokens=total_tokens,

                        output_tokens=len(compact_content) // 4,

                        quality_score=quality_score,

                        anchor_score=0.0,

                        strategy="emergency",

                        model_used="emergency",

                        duration_ms=_duration_ms,

                    )

                    self._record_compaction_cost(

                        "emergency", total_tokens, len(compact_content) // 4,

                    )

                    self._learn_from_outcome(

                        {"pressure": context_pressure, "strategy": "emergency", "model": "emergency"},

                        {"quality": quality_score, "anchor_preservation": 0.0, "duration_ms": _duration_ms},

                    )

                    logger.info(

                        "[ContextMgr] action=emergency_quality quality_score=%.2f compression_ratio=%.2f",

                        quality_score, len(compact_content) / max(1, compact_count * 200),

                    )

                    self._last_compact_hash = compact_hash

                    self._last_compact_result = {"compacted": compact_count}

                    _compaction_timer.end_stage()

                    _log_compaction_performance(_compaction_timer, "emergency", total_tokens, compact_content)

                    self.get_health_score()

                    return {"compacted": compact_count}



            await self._print_status_message(

                agent,

                f"🔄 上下文压缩中... / Context compaction...\n"

                f"📊 {total_msgs}条消息 → 压缩{compact_count}条 + 保留{keep_count}条"

                + (f" | 🔗 {len(anchors)}个关键锚点" if anchors else "")

                + (f" | 📦 {len(folded_outcomes)}个工具结果折叠" if folded_outcomes else "")

                + (f" | 🎚️ 密度梯度压缩" if compact_count > 10 else "")

                + f" | 压力{context_pressure:.1f}x",

            )



            self.memory_manager.add_async_summary_task(

                messages=messages_to_compact,

            )



            _compression_cfg = self._get_compression_config(context_pressure)

            MAX_INPUT_CHARS = _compression_cfg["max_input_chars"]

            if compaction_strategy == "tool_focused":

                MAX_INPUT_CHARS = min(MAX_INPUT_CHARS, 6000)

            elif compaction_strategy == "text_focused":

                MAX_INPUT_CHARS = max(MAX_INPUT_CHARS, 10000)

            if compact_count > 10:

                _, density_sections = _apply_density_gradient(

                    messages_to_compact, compact_count,

                )

                input_text = "\n\n".join(density_sections)

                logger.info(

                    "[ContextMgr] action=density_gradient sections=%d msgs=%d strategy=%s",

                    len(density_sections), compact_count, compaction_strategy,

                )

            else:

                input_text = _messages_to_text(messages_to_compact)

            if len(input_text) > MAX_INPUT_CHARS:

                logger.info(

                    "[ContextMgr] action=input_truncated from=%d to=%d",

                    len(input_text), MAX_INPUT_CHARS,

                )

                input_text = input_text[:MAX_INPUT_CHARS] + "\n[...truncated...]"

            previous_summary = memory.get_compressed_summary() or ""

            if previous_summary:

                input_text = f"[Previous Summary]\n{previous_summary}\n\n[New Messages]\n{input_text}"

            if anchors:

                anchor_text = "\n".join(f"- {a}" for a in anchors)

                input_text = f"[CRITICAL: These instructions MUST be preserved in the summary]\n{anchor_text}\n\n{input_text}"

            if folded_outcomes:

                outcome_text = "\n".join(f"- {o}" for o in folded_outcomes[:20])

                input_text = f"[Tool Outcomes (Context-Folded from completed trajectories)]\n{outcome_text}\n\n{input_text}"



            compact_content = None

            _compaction_timer.start_stage("model_dispatch")

            _compact_stage = "stage1_context_folding"

            _model_attempt_order = self._get_model_attempt_order(context_pressure)

            _model_used = ""

            logger.info(

                "[ContextMgr] action=model_selection order=%s pressure=%.2fx",

                _model_attempt_order, context_pressure,

            )



            if "local" in _model_attempt_order and _model_attempt_order.index("local") < _model_attempt_order.index("free") if "free" in _model_attempt_order else True:

                try:

                    from ...local_model_dispatcher import LocalModelDispatcher

                    dispatcher = LocalModelDispatcher.get_instance()



                    if dispatcher.has_local_model("memory_compact"):

                        _compact_stage = "stage2_local_model"

                        await self._print_status_message(

                            agent,

                            "🧠 使用本地小模型压缩... / Using local small model for compaction...",

                        )

                        compact_content = await dispatcher.dispatch(

                            task_type="memory_compact",

                            input_text=input_text,

                            max_new_tokens=256,

                            temperature=0.3,

                            collect_data=False,

                        )

                        if compact_content:

                            _model_used = "local"

                            logger.info("[ContextMgr] action=local_model_compaction stage=stage2")

                except Exception as e:

                    logger.debug("Local model dispatch failed, falling back: %s", e)



            if not compact_content and "free" in _model_attempt_order and (_model_attempt_order.index("free") < _model_attempt_order.index("llm") if "llm" in _model_attempt_order else True):

                _compact_stage = "stage3_free_model"

                try:

                    from ....smart_llm_client import SmartLLMClient

                    client = SmartLLMClient._instance

                    if client is not None:

                        await self._print_status_message(

                            agent,

                            "🆓 使用免费模型压缩... / Using free model for compaction...",

                        )

                        for _attempt in range(2):

                            try:

                                compact_content = await client.ask_free_model(

                                    prompt=input_text,

                                    system=self._get_compaction_prompt(compaction_strategy),

                                    max_tokens=512,

                                )

                                if compact_content and self._is_valid_summary(compact_content):

                                    _model_used = "free"

                                    logger.info("[ContextMgr] action=free_model_compaction stage=stage3 cost=$0.00")

                                    break

                                else:

                                    logger.warning("[ContextMgr] action=free_model_invalid_summary attempt=%d", _attempt + 1)

                                    compact_content = None

                            except Exception as e:

                                logger.warning("[ContextMgr] action=free_model_attempt_failed attempt=%d error=%s", _attempt + 1, e)

                                compact_content = None



                        if not compact_content:

                            _compact_stage = "stage3b_simplified"

                            try:

                                compact_content = await client.ask_free_model(

                                    prompt=input_text,

                                    system=(

                                        "Summarize the conversation into bullet points. "

                                        "Keep all file paths, URLs, and code references. "

                                        "Use the same language as the original. "

                                        "List: 1) What the user wants 2) What was done 3) Key files 4) Errors found 5) Next steps"

                                    ),

                                    max_tokens=256,

                                )

                                if compact_content and self._is_valid_summary(compact_content):

                                    _model_used = "free"

                                    logger.info("[ContextMgr] action=free_model_retry stage=stage3b")

                                else:

                                    compact_content = None

                            except Exception as _retry_err:

                                logger.debug("Compaction retry with simplified prompt failed (stage3b): %s", _retry_err)

                                compact_content = None

                    else:

                        logger.debug("SmartLLMClient not initialized, skipping free model path")

                except Exception as e:

                    logger.debug("Free model compaction failed, falling back to LLM: %s", e)



            if not compact_content and "llm" in _model_attempt_order:

                _compact_stage = "stage3c_llm"

                await self._print_status_message(

                    agent,

                    "🔄 上下文压缩进行中... / Context compaction in progress...",

                )



                COMPACT_TIMEOUT_SECONDS = 60



                async def _llm_compact():

                    return await asyncio.wait_for(

                        self.memory_manager.compact_memory(

                            messages=messages_to_compact,

                            previous_summary=previous_summary,

                        ),

                        timeout=COMPACT_TIMEOUT_SECONDS,

                    )



                try:

                    from ...local_model_dispatcher import LocalModelDispatcher

                    dispatcher = LocalModelDispatcher.get_instance()

                    compact_content = await asyncio.wait_for(

                        dispatcher.dispatch(

                            task_type="memory_compact",

                            input_text=input_text,

                            fallback_fn=_llm_compact,

                            max_new_tokens=256,

                            temperature=0.3,

                            collect_data=True,

                        ),

                        timeout=COMPACT_TIMEOUT_SECONDS,

                    )

                    if compact_content:

                        _model_used = "llm"

                except asyncio.TimeoutError:

                    logger.error("[ContextMgr] action=compaction_timeout timeout=%ds stage=stage3c", COMPACT_TIMEOUT_SECONDS)

                except Exception as _compact_err:

                    logger.warning("[ContextMgr] action=primary_failed stage=%s error_type=%s", _compact_stage, type(_compact_err).__name__)

                    try:

                        compact_content = await _llm_compact()

                    except asyncio.TimeoutError:

                        logger.error("[ContextMgr] action=llm_fallback_timeout timeout=%ds", COMPACT_TIMEOUT_SECONDS)

                    except Exception as _llm_err:

                        logger.warning("[ContextMgr] action=llm_fallback_failed error_type=%s", type(_llm_err).__name__)



            if not compact_content:

                _tried = set()

                if _model_used:

                    _tried.add(_model_used)

                if compact_content is None and _model_attempt_order:

                    for _fallback_model in _model_attempt_order:

                        if _fallback_model in _tried:

                            continue

                        _tried.add(_fallback_model)

                        if _fallback_model == "local":

                            try:

                                from ...local_model_dispatcher import LocalModelDispatcher

                                _fb_dispatcher = LocalModelDispatcher.get_instance()

                                if _fb_dispatcher.has_local_model("memory_compact"):

                                    _compact_stage = "fallback_local"

                                    compact_content = await _fb_dispatcher.dispatch(

                                        task_type="memory_compact",

                                        input_text=input_text,

                                        max_new_tokens=256,

                                        temperature=0.3,

                                        collect_data=False,

                                    )

                                    if compact_content:

                                        _model_used = "local"

                                        break

                            except Exception as _fb_err:

                                logger.debug("Fallback local model failed: %s", _fb_err)

                        elif _fallback_model == "free":

                            try:

                                from ....smart_llm_client import SmartLLMClient

                                _fb_client = SmartLLMClient._instance

                                if _fb_client is not None:

                                    _compact_stage = "fallback_free"

                                    compact_content = await _fb_client.ask_free_model(

                                        prompt=input_text,

                                        system="Summarize the conversation. Keep file paths, URLs, decisions. Use same language.",

                                        max_tokens=256,

                                    )

                                    if compact_content and self._is_valid_summary(compact_content):

                                        _model_used = "free"

                                        break

                                    compact_content = None

                            except Exception as _fb_err:

                                logger.debug("Fallback free model failed: %s", _fb_err)



            _compaction_timer.end_stage()

            _compaction_timer.start_stage("post_processing")

            if not compact_content or not self._is_valid_summary(compact_content):

                _compact_stage = "stage3c_emergency_truncation"

                logger.warning(

                    "[ContextMgr] action=invalid_result stage=%s content_len=%d valid=%s using_fallback=True",

                    _compact_stage,

                    len(compact_content) if compact_content else 0,

                    self._is_valid_summary(compact_content) if compact_content else False,

                )



                existing_summary = memory.get_compressed_summary() or ""



                if existing_summary:

                    compact_content = existing_summary

                    logger.info(

                        "[ContextMgr] action=fallback_existing_summary len=%d dropping=%d",

                        len(compact_content), compact_count,

                    )

                elif compact_count > 0:

                    truncated_summary_parts = []

                    for msg in messages_to_compact[:20]:

                        text = msg.get_text_content() if hasattr(msg, 'get_text_content') else ""

                        if text:

                            truncated_summary_parts.append(f"- {text[:200]}")

                    if truncated_summary_parts:

                        truncated_summary = "## 截断的上下文 / Truncated Context\n" + "\n".join(truncated_summary_parts)

                        if self._is_valid_summary(truncated_summary):

                            compact_content = truncated_summary

                            logger.info("[ContextMgr] action=fallback_truncated len=%d", len(compact_content))



                if compact_count > 0:

                    _degradation_ok = await self._graceful_degradation(

                        memory, messages_to_compact, messages_to_keep,

                    )

                    if _degradation_ok:

                        await self._print_status_message(

                            agent,

                            "⚠️ 所有压缩方式失败，已执行降级恢复。/ "

                            "All compaction methods failed, graceful degradation applied.",

                        )

                    else:

                        await self._print_status_message(

                            agent,

                            f"⚠️ 上下文压缩使用降级方案，保留最近{keep_count}条，"

                            f"丢弃旧{compact_count}条。/ "

                            f"Context compaction used fallback. "

                            f"Keep({keep_count}) + drop({compact_count}) msgs.",

                        )

                    self._metrics["total_compactions"] += 1

                    self._metrics["total_msgs_compacted"] += compact_count

                else:

                    await self._print_status_message(

                        agent,

                        "⚠️ 上下文压缩失败，如遇问题请使用 /new 或 /clear 重置。/ "

                        "Context compaction failed. Use /new or /clear if issues persist.",

                    )

            else:

                anchor_score = 1.0

                if anchors and compact_content:

                    anchor_score = _validate_anchors(compact_content, anchors)

                    if anchor_score < 0.3:

                        logger.warning(

                            "[ContextMgr] action=anchor_low anchor_score=%.2f preserved=%d/%d appending_anchors=True",

                            anchor_score, int(anchor_score * len(anchors)), len(anchors),

                        )

                        self._emit_event("anchor_lost", {

                            "anchor_score": anchor_score,

                            "preserved": int(anchor_score * len(anchors)),

                            "total": len(anchors),

                        })

                        anchor_appendix = "\n\n## 关键指令(保留) / Critical Instructions (Preserved)\n" + "\n".join(

                            f"- {a}" for a in anchors

                        )

                        compact_content = compact_content + anchor_appendix

                    else:

                        logger.info(

                            "[ContextMgr] action=anchor_ok anchor_score=%.2f preserved=%d/%d",

                            anchor_score, int(anchor_score * len(anchors)), len(anchors),

                        )

                anchor_score_str = f"{anchor_score * 100:.0f}%"

                await self._print_status_message(

                    agent,

                    f"✅ 上下文压缩完成 / Compaction done\n"

                    f"📊 压缩{compact_count}条 → 摘要{len(compact_content)}字符"

                    + (f" | 🔗 锚点保留率{anchor_score_str}" if anchors else "")

                    + f" | 方式: {_compact_stage}",

                )

                self._metrics["total_compactions"] += 1

                self._metrics["total_msgs_compacted"] += compact_count

                quality_score = self._score_summary_quality(compact_content, compact_count)

                compression_ratio = len(compact_content) / max(1, compact_count * 200)

                self._record_compression_ratio(total_tokens, len(compact_content))

                import time as _te1

                _duration_ms = _te1.monotonic() * 1000 - _compaction_start_ms

                self._record_telemetry(

                    input_tokens=total_tokens,

                    output_tokens=len(compact_content) // 4,

                    quality_score=quality_score,

                    anchor_score=anchor_score,

                    strategy=compaction_strategy,

                    model_used=_model_used or _compact_stage,

                    duration_ms=_duration_ms,

                )

                self._record_compaction_cost(

                    _model_used or _compact_stage,

                    total_tokens,

                    len(compact_content) // 4,

                )

                self._learn_from_outcome(

                    {"pressure": context_pressure, "strategy": compaction_strategy, "model": _model_used or _compact_stage},

                    {"quality": quality_score, "anchor_preservation": anchor_score, "duration_ms": _duration_ms},

                )

                logger.info(

                    "[ContextMgr] action=compaction_done quality_score=%.2f anchor_score=%.2f compression_ratio=%.2f stage=%s strategy=%s",

                    quality_score, anchor_score, compression_ratio, _compact_stage, compaction_strategy,

                )

                self._emit_event("compaction_completed", {

                    "quality_score": quality_score,

                    "anchor_score": anchor_score,

                    "compression_ratio": compression_ratio,

                    "stage": _compact_stage,

                    "strategy": compaction_strategy,

                    "model_used": _model_used,

                })

                self._record_ab_test_outcome(

                    ab_variant, quality_score, anchor_score, _duration_ms,

                )

                self._advance_ab_test_variant()

                if anchors:

                    self._metrics["anchor_preservation_scores"].append(anchor_score)

                    if len(self._metrics["anchor_preservation_scores"]) > 50:

                        self._metrics["anchor_preservation_scores"] = self._metrics["anchor_preservation_scores"][-50:]



            if messages_to_compact and hasattr(memory, 'mark_messages_compressed'):

                updated_count = await memory.mark_messages_compressed(

                    messages_to_compact,

                )

                logger.info("[ContextMgr] action=marked_compressed count=%d", updated_count)

            elif messages_to_compact:

                ids_to_delete = [getattr(msg, 'id', None) for msg in messages_to_compact if hasattr(msg, 'id')]

                ids_to_delete = [mid for mid in ids_to_delete if mid is not None]

                logger.warning(

                    "[ContextMgr] action=delete_fallback reason=no_mark_messages_compressed count=%d",

                    len(ids_to_delete),

                )

                await memory.delete(ids_to_delete)



            if compact_content:

                if previous_summary and self._is_valid_summary(compact_content):

                    merged = self._merge_summaries(previous_summary, compact_content)

                    if self._is_valid_summary(merged):

                        logger.info(

                            "[ContextMgr] action=merge_summaries old_len=%d new_len=%d merged_len=%d",

                            len(previous_summary), len(compact_content), len(merged),

                        )

                        compact_content = merged

                compact_content = self._prepend_version_header(compact_content, compact_count)



                cv_score = self._cross_validate_summary(compact_content, messages_to_compact)

                if cv_score < 0.2 and compaction_strategy != "balanced":

                    logger.warning(

                        "[ContextMgr] action=cross_validation_retry cv_score=%.3f strategy=%s retrying_with_balanced",

                        cv_score, compaction_strategy,

                    )

                    retry_anchors = _extract_anchors(messages_to_compact)

                    retry_content = self._emergency_compact(

                        messages_to_compact, retry_anchors, folded_outcomes,

                    )

                    if retry_content and self._is_valid_summary(retry_content):

                        retry_cv = self._cross_validate_summary(retry_content, messages_to_compact)

                        if retry_cv > cv_score:

                            logger.info(

                                "[ContextMgr] action=cross_validation_improved old=%.3f new=%.3f",

                                cv_score, retry_cv,

                            )

                            compact_content = retry_content



                self._update_predictive_cache(

                    self.memory_manager.agent_id,

                    compact_count,

                    context_pressure,

                    compact_content,

                )



                await memory.update_compressed_summary(compact_content)



            _summary_after = memory.get_compressed_summary() or ""

            await self._validate_compaction_result(

                memory, compact_count, previous_summary, _summary_after,

            )



            self._last_compact_hash = compact_hash

            self._last_compact_result = {"compacted": compact_count}



            import time as _ts

            self._last_compaction_timestamp = _ts.time()



            self._self_optimize()



        except Exception as e:

            logger.exception(

                "[ContextMgr] action=compaction_error error_type=%s stage=%s pressure=%.2fx recovery=emergency_remove",

                type(e).__name__, _compact_stage, _context_pressure,

            )

            self._emit_event("compaction_failed", {

                "error_type": type(e).__name__,

                "stage": _compact_stage,

                "pressure": _context_pressure,

            })

            if messages_to_compact:

                try:

                    if hasattr(memory, 'mark_messages_compressed'):

                        removed = await memory.mark_messages_compressed(messages_to_compact)

                        logger.warning(

                            "[ContextMgr] action=emergency_remove removed=%d after_failure=True",

                            removed,

                        )

                    else:

                        ids_to_delete = [getattr(msg, 'id', None) for msg in messages_to_compact if hasattr(msg, 'id')]

                        ids_to_delete = [mid for mid in ids_to_delete if mid is not None]

                        await memory.delete(ids_to_delete)

                        logger.warning(

                            "[ContextMgr] action=emergency_delete deleted=%d after_failure=True",

                            len(ids_to_delete),

                        )

                except Exception as _emergency_err:

                    logger.error("[ContextMgr] action=emergency_remove_failed error=%s", _emergency_err)



            try:

                _pressure_info = f" (压力/pressure: {_context_pressure:.1f}x)" if _context_pressure > 0 else ""

                if isinstance(e, (asyncio.TimeoutError, TimeoutError)):

                    await self._print_status_message(

                        agent,

                        "⚠️ 上下文压缩超时，已紧急删除旧消息保留最近对话。"

                        "如遇问题请使用 /clear 或 /new 重置。/ "

                        "Context compaction timed out, old messages removed. "

                        f"Use /clear or /new if issues persist.{_pressure_info}",

                    )

                elif isinstance(e, (ConnectionError, OSError)):

                    await self._print_status_message(

                        agent,

                        "⚠️ 上下文压缩网络错误，已紧急删除旧消息保留最近对话。"

                        "如遇问题请使用 /clear 或 /new 重置。/ "

                        "Context compaction network error, old messages removed. "

                        f"Use /clear or /new if issues persist.{_pressure_info}",

                    )

                else:

                    err_type = type(e).__name__

                    err_msg = str(e)[:200]

                    await self._print_status_message(

                        agent,

                        f"⚠️ 上下文压缩失败({err_type}): {err_msg}。"

                        "已紧急删除旧消息。"

                        "如遇问题请使用 /clear 或 /new 重置。/ "

                        f"Context compaction failed ({err_type}): {err_msg}. "

                        f"Old messages removed. Use /clear or /new if issues persist.{_pressure_info}",

                    )

            except Exception as _notify_err:

                logger.debug("Failed to send compaction failure notification: %s", _notify_err)



        self._trim_internal_state()

        _compaction_timer.end_stage()

        if _compaction_timer.get_summary():

            _log_compaction_performance(_compaction_timer, _compact_stage, 0, None)

        return None



    def self_test_anchor_extraction(self) -> bool:

        try:

            test_messages = [

                {"role": "user", "content": "Please edit the file /tmp/test.py and fix the bug"},

                {"role": "assistant", "content": "I'll read the file at /tmp/test.py first"},

                {"role": "user", "content": "The important constraint is that we must never delete the config"},

                {"role": "assistant", "content": "Understood. The rule is to always backup before editing"},

            ]

            anchors = _extract_anchors(test_messages)

            has_file_path = any("/tmp/test.py" in a for a in anchors)

            has_important = any("important" in a.lower() or "must" in a.lower() for a in anchors)

            if not has_file_path:

                logger.warning("self_test_anchor_extraction: missing file path anchor")

                return False

            if not has_important:

                logger.warning("self_test_anchor_extraction: missing important constraint anchor")

                return False

            if len(anchors) < 2:

                logger.warning("self_test_anchor_extraction: too few anchors (%d)", len(anchors))

                return False

            return True

        except Exception as e:

            logger.warning("self_test_anchor_extraction failed: %s", e)

            return False



    def self_test_density_gradient(self) -> bool:

        try:

            test_messages = [

                {"role": "user", "content": f"Message {i} with some content about topic {i % 3}"}

                for i in range(20)

            ]

            densities, sections = _apply_density_gradient(test_messages, 20)

            if len(densities) != 20:

                logger.warning("self_test_density_gradient: wrong density count %d != 20", len(densities))

                return False

            if not sections:

                logger.warning("self_test_density_gradient: no sections produced")

                return False

            has_full = "full" in densities

            has_light = "light" in densities

            if not has_full or not has_light:

                logger.warning("self_test_density_gradient: missing density levels full=%s light=%s", has_full, has_light)

                return False

            small_densities, small_sections = _apply_density_gradient(test_messages[:3], 3)

            if small_densities != ["full", "full", "full"]:

                logger.warning("self_test_density_gradient: small message set not all full")

                return False

            return True

        except Exception as e:

            logger.warning("self_test_density_gradient failed: %s", e)

            return False



    def self_test_summary_quality(self) -> bool:

        try:

            good_summary = "## Task Overview\nThe user wants to build a web app.\n## Key Decisions\n- Use React for frontend\n- Use FastAPI for backend\n## Files & Resources\n- /tmp/app.py: main application"

            bad_summary_short = "ok"

            bad_summary_empty = ""

            good_score = self._score_summary_quality(good_summary, 20)

            short_score = self._score_summary_quality(bad_summary_short, 20)

            empty_score = self._score_summary_quality(bad_summary_empty, 20)

            if good_score <= short_score:

                logger.warning("self_test_summary_quality: good summary not scored higher than short (good=%.2f short=%.2f)", good_score, short_score)

                return False

            if empty_score != 0.0:

                logger.warning("self_test_summary_quality: empty summary scored non-zero (%.2f)", empty_score)

                return False

            if good_score < 0.5:

                logger.warning("self_test_summary_quality: good summary scored too low (%.2f)", good_score)

                return False

            return True

        except Exception as e:

            logger.warning("self_test_summary_quality failed: %s", e)

            return False



    def self_test_merge_summaries(self) -> bool:

        try:

            old_summary = "## Task Overview\nBuilding a CLI tool\n## Key Decisions\n- Use Python 3.11\n## Files\n- /tmp/main.py: entry point"

            new_summary = "## Task Overview\nAdding tests to CLI tool\n## Key Decisions\n- Use pytest\n## Errors\n- ImportError on module xyz"

            merged = self._merge_summaries(old_summary, new_summary)

            if not merged:

                logger.warning("self_test_merge_summaries: empty merge result")

                return False

            if "Python 3.11" not in merged:

                logger.warning("self_test_merge_summaries: lost old decision (Python 3.11)")

                return False

            if "pytest" not in merged:

                logger.warning("self_test_merge_summaries: lost new decision (pytest)")

                return False

            if "ImportError" not in merged:

                logger.warning("self_test_merge_summaries: lost error info")

                return False

            return True

        except Exception as e:

            logger.warning("self_test_merge_summaries failed: %s", e)

            return False



    def test_full_compaction_cycle(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = []

            for i in range(30):

                messages.append({"role": "user", "content": f"User message {i} with some content about topic {i % 5}"})

                messages.append({"role": "assistant", "content": f"Assistant response {i} with details about the task"})

            anchors = _extract_anchors(messages)

            if not anchors and len(messages) > 0:

                messages.append({"role": "user", "content": "The important file /tmp/test_compact.py must be preserved"})

                anchors = _extract_anchors(messages)

            compact_result = self._emergency_compact(messages, anchors)

            if not compact_result or len(compact_result.strip()) < 20:

                result["details"] = f"compact_result too short or empty (len={len(compact_result.strip()) if compact_result else 0})"

                return result

            if not self._is_valid_summary(compact_result):

                result["details"] = "compact_result not a valid summary"

                return result

            quality = self._score_summary_quality(compact_result, len(messages))

            if quality < 0.1:

                result["details"] = f"quality too low: {quality}"

                return result

            result["passed"] = True

            result["details"] = f"quality={quality:.2f} anchors={len(anchors)} msg_count={len(messages)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_emergency_compaction(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = []

            for i in range(50):

                messages.append({"role": "user", "content": f"Emergency test message {i}"})

                messages.append({"role": "assistant", "content": f"Emergency response {i}"})

                messages.append({"role": "tool", "content": f"Tool result {i}: some output data"})

            anchors = _extract_anchors(messages)

            emergency_result = self._emergency_compact(messages, anchors)

            if not emergency_result:

                result["details"] = "emergency_compact returned empty"

                return result

            if "Emergency Context Summary" not in emergency_result:

                result["details"] = "missing Emergency Context Summary header"

                return result

            if not self._is_valid_summary(emergency_result):

                result["details"] = "emergency result not valid summary"

                return result

            result["passed"] = True

            result["details"] = f"len={len(emergency_result)} anchors={len(anchors)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_anchor_preservation(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = [

                {"role": "user", "content": "Please edit the file /tmp/anchor_test.py and fix the bug"},

                {"role": "assistant", "content": "I'll read /tmp/anchor_test.py first"},

                {"role": "user", "content": "The important constraint is that we must never delete the config"},

                {"role": "assistant", "content": "Understood, the rule is to always backup before editing"},

                {"role": "user", "content": "Check the URL https://example.com/api for status"},

            ]

            anchors = _extract_anchors(messages)

            if len(anchors) < 2:

                result["details"] = f"too few anchors extracted: {len(anchors)}"

                return result

            compact_result = self._emergency_compact(messages, anchors)

            if not compact_result:

                result["details"] = "compact returned empty"

                return result

            anchor_score = _validate_anchors(compact_result, anchors)

            if anchor_score < 0.1:

                result["details"] = f"anchor_score too low: {anchor_score:.2f} anchors={anchors[:3]}"

                return result

            result["passed"] = True

            result["details"] = f"anchor_score={anchor_score:.2f} anchors={len(anchors)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_density_gradient(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = []

            for i in range(30):

                messages.append({"role": "user", "content": f"Density test message {i} with content about topic {i % 3}"})

            densities, sections = _apply_density_gradient(messages, len(messages))

            if len(densities) != len(messages):

                result["details"] = f"density count mismatch: {len(densities)} != {len(messages)}"

                return result

            if not sections:

                result["details"] = "no sections produced"

                return result

            has_full = "full" in densities

            has_light = "light" in densities

            if not has_full or not has_light:

                result["details"] = f"missing density levels: full={has_full} light={has_light}"

                return result

            text = _messages_to_text(messages, "light")

            if not text:

                result["details"] = "messages_to_text returned empty for light density"

                return result

            result["passed"] = True

            result["details"] = f"densities={set(densities)} sections={len(sections)} text_len={len(text)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_context_folding(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            from ...context_manager import ActiveContextManager

            messages = []

            for i in range(5):

                messages.append({"role": "assistant", "content": [

                    {"type": "text", "text": f"Let me check that for you"},

                    {"type": "tool_use", "name": f"read_file", "id": f"call_{i}"},

                ]})

                messages.append({"role": "tool", "content": f"File content for file {i}: some data here"})

            messages.append({"role": "user", "content": "What did you find?"})

            messages.append({"role": "assistant", "content": "I found the information you needed"})

            ctx_mgr = ActiveContextManager()

            outcomes = ctx_mgr.extract_folded_outcomes(messages, keep_recent=4)

            if not outcomes:

                result["details"] = "no folded outcomes extracted"

                return result

            result["passed"] = True

            result["details"] = f"original={len(messages)} outcomes={len(outcomes)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_graceful_degradation(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            cfg_low = self._get_compression_config(1.0)

            cfg_mid = self._get_compression_config(2.0)

            cfg_high = self._get_compression_config(3.0)

            if cfg_low["level"] != "light":

                result["details"] = f"low pressure should be light, got {cfg_low['level']}"

                return result

            if cfg_mid["level"] != "medium":

                result["details"] = f"mid pressure should be medium, got {cfg_mid['level']}"

                return result

            if cfg_high["level"] != "heavy":

                result["details"] = f"high pressure should be heavy, got {cfg_high['level']}"

                return result

            if cfg_high["max_input_chars"] >= cfg_mid["max_input_chars"]:

                result["details"] = "heavy should have smaller max_input_chars than medium"

                return result

            if cfg_mid["max_input_chars"] >= cfg_low["max_input_chars"]:

                result["details"] = "medium should have smaller max_input_chars than light"

                return result

            if cfg_high["keep_recent"] >= cfg_mid["keep_recent"]:

                result["details"] = "heavy should keep fewer recent than medium"

                return result

            result["passed"] = True

            result["details"] = f"light={cfg_low['level']} medium={cfg_mid['level']} heavy={cfg_high['level']}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_token_recycling(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = [

                {"role": "user", "content": "Check this file"},

                {"role": "tool", "content": "x" * 5000},

                {"role": "assistant", "content": "Done"},

            ]

            recycled = self._recycle_tool_results(messages, max_result_length=2000)

            if recycled <= 0:

                result["details"] = f"expected tokens recycled > 0, got {recycled}"

                return result

            tool_content = messages[1]["content"]

            if "[...truncated" not in tool_content:

                result["details"] = "tool result not truncated"

                return result

            if len(tool_content) > 2500:

                result["details"] = f"truncated content still too long: {len(tool_content)}"

                return result

            result["passed"] = True

            result["details"] = f"recycled={recycled} truncated_len={len(tool_content)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_semantic_compress(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = [

                {"role": "user", "content": "Please help me with this task"},

                {"role": "assistant", "content": "I'll help you with that. Let me check the file /tmp/test.py for you."},

                {"role": "user", "content": "Now check another file"},

                {"role": "assistant", "content": "I'll help you with that. Let me check the other file."},

            ]

            compressed, tokens_saved = self._semantic_compress(messages)

            if tokens_saved < 0:

                result["details"] = f"tokens_saved should be >= 0, got {tokens_saved}"

                return result

            result["passed"] = True

            result["details"] = f"tokens_saved={tokens_saved} original={4} compressed={len(compressed)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_adaptive_learning(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            for i in range(35):

                self._learn_from_outcome(

                    {"pressure": 1.5 + i * 0.05, "strategy": "balanced" if i % 2 == 0 else "tool_focused", "model": "free"},

                    {"quality": 0.7 + i * 0.005, "anchor_preservation": 0.8, "duration_ms": 500.0},

                )

            if len(self._learning_buffer) != 35:

                result["details"] = f"expected 35 learning entries, got {len(self._learning_buffer)}"

                return result

            predicted = self._predict_best_params(1.8)

            if "strategy" not in predicted or "model" not in predicted or "confidence" not in predicted:

                result["details"] = f"missing keys in prediction: {predicted}"

                return result

            if predicted["confidence"] <= 0:

                result["details"] = f"expected positive confidence, got {predicted['confidence']}"

                return result

            result["passed"] = True

            result["details"] = f"samples={len(self._learning_buffer)} strategy={predicted['strategy']} confidence={predicted['confidence']}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_benchmark_strategies(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = []

            for i in range(20):

                messages.append({"role": "user", "content": f"Benchmark test message {i}"})

                messages.append({"role": "assistant", "content": f"Response {i}"})

            benchmark = self.benchmark_strategies(messages)

            if "strategies" not in benchmark or "recommended" not in benchmark:

                result["details"] = f"missing keys in benchmark: {list(benchmark.keys())}"

                return result

            if benchmark["recommended"] not in ("tool_focused", "text_focused", "balanced"):

                result["details"] = f"invalid recommended strategy: {benchmark['recommended']}"

                return result

            result["passed"] = True

            result["details"] = f"recommended={benchmark['recommended']} strategies={list(benchmark['strategies'].keys())}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_streaming_compress(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = []

            for i in range(35):

                messages.append({"role": "user", "content": f"Streaming test message {i} about topic {i % 5}"})

                messages.append({"role": "assistant", "content": f"Response {i} with details about the task at /tmp/stream_{i}.py"})

            compressed = self._streaming_compress(messages, batch_size=10)

            if not compressed:

                result["details"] = "streaming_compress returned empty"

                return result

            if not self._is_valid_summary(compressed):

                result["details"] = "streaming_compress result not valid summary"

                return result

            single_pass = self._emergency_compact(messages, _extract_anchors(messages))

            if not single_pass:

                result["details"] = "single-pass emergency compact returned empty"

                return result

            result["passed"] = True

            result["details"] = f"msgs={len(messages)} streaming_len={len(compressed)} single_pass_len={len(single_pass)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_cross_validate_summary(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            messages = [

                {"role": "user", "content": "Edit the file /tmp/cross_val.py and fix the bug"},

                {"role": "assistant", "content": "I'll read /tmp/cross_val.py first"},

                {"role": "user", "content": "The important constraint is that we must never delete the config"},

            ]

            anchors = _extract_anchors(messages)

            good_summary = self._emergency_compact(messages, anchors)

            good_score = self._cross_validate_summary(good_summary, messages)

            bad_summary = "Unrelated content about cooking recipes"

            bad_score = self._cross_validate_summary(bad_summary, messages)

            if good_score <= bad_score:

                result["details"] = f"good_score ({good_score:.3f}) should be > bad_score ({bad_score:.3f})"

                return result

            empty_score = self._cross_validate_summary("", messages)

            if empty_score != 0.0:

                result["details"] = f"empty summary should score 0.0, got {empty_score}"

                return result

            result["passed"] = True

            result["details"] = f"good={good_score:.3f} bad={bad_score:.3f} empty={empty_score:.3f}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def test_predictive_cache(self) -> dict:

        result: dict = {"passed": False, "details": ""}

        try:

            self._predictive_cache.clear()

            self._predictive_cache_hits = 0

            self._predictive_cache_misses = 0

            cache_miss = self._check_predictive_cache("test_agent", 25, 1.5)

            if cache_miss is not None:

                result["details"] = "expected cache miss on first lookup"

                return result

            if self._predictive_cache_misses != 1:

                result["details"] = f"expected 1 miss, got {self._predictive_cache_misses}"

                return result

            self._update_predictive_cache("test_agent", 25, 1.5, "cached summary content for testing")

            cache_hit = self._check_predictive_cache("test_agent", 25, 1.5)

            if cache_hit is None:

                result["details"] = "expected cache hit after update"

                return result

            if self._predictive_cache_hits != 1:

                result["details"] = f"expected 1 hit, got {self._predictive_cache_hits}"

                return result

            if len(self._predictive_cache) > self._MAX_PREDICTIVE_CACHE:

                result["details"] = f"cache exceeded max size: {len(self._predictive_cache)}"

                return result

            result["passed"] = True

            result["details"] = f"hits={self._predictive_cache_hits} misses={self._predictive_cache_misses} size={len(self._predictive_cache)}"

        except Exception as e:

            result["details"] = f"exception: {e}"

        return result



    def get_system_overview(self) -> str:

        """Return a comprehensive description of the context management system.



        This is a runtime documentation method that describes the full

        architecture, not a code comment. It can be called to understand

        how the system works at any time.

        """

        return (

            "XINGZIER AI Context Management System\n"

            "=====================================\n\n"

            "Architecture Overview:\n"

            "  The context management system prevents context window overflow by\n"

            "  automatically compacting older messages when token usage exceeds\n"

            "  a configurable threshold. It uses a multi-layered approach:\n\n"

            "  Layer 1 - Prevention:\n"

            "    - Token recycling: Truncates oversized tool results in-place\n"

            "    - Semantic compression: Deduplicates repeated phrases\n"

            "    - Context folding: Collapses completed tool trajectories\n"

            "    - Proactive compaction: Triggers before overflow\n\n"

            "  Layer 2 - Compaction:\n"

            "    - Multi-model compaction: Routes sub-tasks to cost-effective models\n"

            "      * Tool result summarization → local model (cheapest)\n"

            "      * Conversation summarization → free cloud model\n"

            "      * Critical decisions → main LLM (highest quality)\n"

            "    - Density gradient: 3-tier compression (full/medium/light)\n"

            "    - Instruction anchoring: Preserves critical phrases\n"

            "    - User intent preservation: Tracks and preserves intent\n\n"

            "  Layer 3 - Emergency:\n"

            "    - Emergency compaction: Fast truncation without LLM\n"

            "    - Streaming compression: Batch processing for large contexts\n"

            "    - Graceful degradation: Progressive context reduction\n\n"

            "  Layer 4 - Recovery:\n"

            "    - Context recovery: Reconstructs corrupted summaries\n"

            "    - Summary refresh: Updates stale summaries (>1 hour old)\n"

            "    - Cross-validation: Verifies summary quality\n\n"

            "  Supporting Systems:\n"

            "    - Temporal awareness: Prioritizes recent messages\n"

            "    - Conversation state machine: Prevents compaction during tools\n"

            "    - Adaptive learning: Improves strategy selection over time\n"

            "    - Circuit breaker: Prevents cascading compaction failures\n"

            "    - Predictive cache: Reuses similar compaction results\n"

            "    - A/B testing: Compares compaction strategies\n"

        )



    def get_current_state_description(self) -> str:

        """Return a human-readable description of the current compaction state.



        Includes metrics, pressure, strategy, and health information.

        """

        metrics = self.get_metrics()

        health = self.get_health_score()

        learning = self.get_learning_stats()



        total_compactions = metrics.get("total_compactions", 0)

        emergency_compactions = metrics.get("emergency_compactions", 0)

        tokens_recycled = metrics.get("total_tokens_recycled", 0)

        cache_size = metrics.get("predictive_cache_size", 0)

        cache_hit_rate = metrics.get("predictive_cache_hit_rate", 0.0)



        pressure = self._current_context_pressure

        strategy = self._auto_selected_strategy or "heuristic"



        lines = [

            f"Current Context Management State",

            f"================================",

            f"Context pressure: {pressure:.2f}x",

            f"Health score: {health.get('total_score', 0)}/100 ({health.get('level', 'Unknown')})",

            f"Auto-selected strategy: {strategy}",

            f"",

            f"Compaction Statistics:",

            f"  Total compactions: {total_compactions}",

            f"  Emergency compactions: {emergency_compactions}",

            f"  Emergency ratio: {emergency_compactions / max(1, total_compactions):.1%}",

            f"  Total tokens recycled: {tokens_recycled}",

            f"",

            f"Cache & Learning:",

            f"  Predictive cache size: {cache_size}",

            f"  Cache hit rate: {cache_hit_rate:.1%}",

            f"  Learning samples: {learning.get('samples', 0)}",

            f"  Prediction ready: {learning.get('prediction_ready', False)}",

            f"",

            f"Health Breakdown:",

            f"  Compression ratio: {health.get('compression_ratio_score', 0)}/25",

            f"  Anchor preservation: {health.get('anchor_preservation_score', 0)}/25",

            f"  Quality: {health.get('quality_score', 0)}/25",

            f"  Fragmentation: {health.get('fragmentation_score', 0)}/25",

        ]



        suggestions = self.get_optimization_suggestions()

        if suggestions:

            lines.append("")

            lines.append("Optimization Suggestions:")

            for i, s in enumerate(suggestions[:3], 1):

                lines.append(f"  {i}. {s}")



        return "\n".join(lines)



    def get_compaction_summary(self) -> dict:

        """Return a compact dict summary for API endpoints.



        Unlike get_metrics() which returns raw data, this provides

        a curated summary suitable for monitoring dashboards.

        """

        health = self.get_health_score()

        metrics = self.get_metrics()

        learning = self.get_learning_stats()



        return {

            "pressure": round(self._current_context_pressure, 2),

            "health_score": health.get("total_score", 0),

            "health_level": health.get("level", "Unknown"),

            "total_compactions": metrics.get("total_compactions", 0),

            "emergency_compactions": metrics.get("emergency_compactions", 0),

            "tokens_recycled": metrics.get("total_tokens_recycled", 0),

            "cache_hit_rate": metrics.get("predictive_cache_hit_rate", 0.0),

            "learning_samples": learning.get("samples", 0),

            "prediction_ready": learning.get("prediction_ready", False),

            "auto_strategy": self._auto_selected_strategy,

            "circuit_breaker_state": self._circuit_breaker.get("state", "unknown"),

            "last_compaction_ts": self._last_compaction_timestamp,

        }



    def get_compaction_pipeline_description(self) -> str:

        """Describe the full compaction pipeline step by step.



        This documents the exact sequence of operations that occur

        when a compaction is triggered.

        """

        return (

            "Compaction Pipeline\n"

            "===================\n\n"

            "Step 1: Initialization\n"

            "  - Load agent configuration and token counter\n"

            "  - Recover corrupted context if needed\n"

            "  - Refresh stale summary if older than 1 hour\n"

            "  - Calculate overhead tokens (system prompt + tools)\n\n"

            "Step 2: Token Counting\n"

            "  - Get all messages from memory\n"

            "  - Compact tool results (time-based retention)\n"

            "  - Recycle oversized tool results (truncate >2000 chars)\n"

            "  - Apply semantic compression (deduplicate phrases)\n"

            "  - Extract folded tool outcomes\n"

            "  - Batch-count tokens for all messages\n\n"

            "Step 3: Pressure Assessment\n"

            "  - Calculate context pressure (tokens / threshold)\n"

            "  - Predict overflow (messages until threshold)\n"

            "  - Predict context growth rate (linear regression)\n"

            "  - Adjust effective threshold if overflow imminent\n"

            "  - If below threshold → return (no compaction needed)\n\n"

            "Step 4: Message Selection\n"

            "  - Run context_check() to split compact/keep sets\n"

            "  - Reorder by relevance (keyword overlap with user query)\n"

            "  - Select compaction strategy (tool_focused/text_focused/balanced)\n"

            "  - Extract instruction anchors\n"

            "  - Check predictive cache for similar patterns\n\n"

            "Step 5: Compaction Execution\n"

            "  If emergency (pressure > 2.5x):\n"

            "    - Use streaming compress (batch) or emergency compact\n"

            "    - No LLM call, fast truncation\n"

            "  Else:\n"

            "    - Apply density gradient compression\n"

            "    - Build compaction prompt with anchors + folded outcomes\n"

            "    - Try models in order: local → free → LLM\n"

            "    - Validate summary quality\n"

            "    - Cross-validate against original messages\n"

            "    - If quality too low → retry with balanced strategy\n\n"

            "Step 6: Post-Processing\n"

            "  - Merge with previous summary if exists\n"

            "  - Prepend version header\n"

            "  - Update compressed summary in memory\n"

            "  - Mark compacted messages as compressed\n"

            "  - Validate compaction result\n"

            "  - Record telemetry and learning data\n"

            "  - Self-optimize parameters if needed\n"

        )



    def get_metrics_description(self) -> str:

        """Describe what each metric means and how to interpret it.



        This is runtime documentation for the metrics system.

        """

        return (

            "Context Management Metrics\n"

            "==========================\n\n"

            "total_compactions (int):\n"

            "  Total number of compaction operations performed.\n"

            "  A healthy system should have this grow slowly.\n"

            "  Rapid growth suggests context is filling up too fast.\n\n"

            "emergency_compactions (int):\n"

            "  Number of emergency compactions (pressure > 2.5x).\n"

            "  These skip LLM summarization and use fast truncation.\n"

            "  Should be < 30% of total_compactions.\n\n"

            "total_msgs_compacted (int):\n"

            "  Total messages removed from context across all compactions.\n"

            "  Higher values indicate more aggressive compaction.\n\n"

            "anchor_preservation_scores (list[float]):\n"

            "  Scores (0.0-1.0) measuring how well critical instructions\n"

            "  are preserved in summaries. Higher is better.\n"

            "  Below 0.5 indicates important info is being lost.\n\n"

            "compression_ratios (list[float]):\n"

            "  Ratio of original tokens to summary tokens.\n"

            "  Higher means more compression. Typical range: 2.0-10.0.\n"

            "  Below 2.0 means summaries are too large.\n\n"

            "compaction_costs (list[dict]):\n"

            "  Per-compaction cost breakdown with model, input/output\n"

            "  tokens, and estimated USD cost.\n\n"

            "total_tokens_recycled (int):\n"

            "  Tokens saved through tool result truncation and semantic\n"

            "  compression. These are 'free' tokens recovered without\n"

            "  removing any messages.\n\n"

            "predictive_cache_size (int):\n"

            "  Number of cached compaction results. Cache hits avoid\n"

            "  redundant LLM calls for similar conversation patterns.\n\n"

            "predictive_cache_hit_rate (float):\n"

            "  Fraction of cache lookups that hit. Higher is better.\n"

            "  Above 0.3 is good, above 0.5 is excellent.\n\n"

            "Health Score (0-100):\n"

            "  compression_ratio_score (0-25): Based on avg compression ratio\n"

            "  anchor_preservation_score (0-25): Based on avg anchor score\n"

            "  quality_score (0-25): Based on avg summary quality\n"

            "  fragmentation_score (0-25): Based on emergency ratio\n"

            "  Total >= 80: Excellent, >= 60: Good, >= 40: Fair, < 40: Poor\n"

        )



    def run_integration_tests(self) -> dict:

        tests = {

            "full_compaction_cycle": self.test_full_compaction_cycle(),

            "emergency_compaction": self.test_emergency_compaction(),

            "anchor_preservation": self.test_anchor_preservation(),

            "density_gradient": self.test_density_gradient(),

            "context_folding": self.test_context_folding(),

            "graceful_degradation": self.test_graceful_degradation(),

            "token_recycling": self.test_token_recycling(),

            "semantic_compress": self.test_semantic_compress(),

            "adaptive_learning": self.test_adaptive_learning(),

            "benchmark_strategies": self.test_benchmark_strategies(),

            "streaming_compress": self.test_streaming_compress(),

            "cross_validate_summary": self.test_cross_validate_summary(),

            "predictive_cache": self.test_predictive_cache(),

        }

        passed = sum(1 for v in tests.values() if v.get("passed"))

        total = len(tests)

        all_passed = passed == total

        results = {

            "tests": tests,

            "passed": passed,

            "total": total,

            "all_passed": all_passed,

        }

        if all_passed:

            logger.info("[ContextMgr] action=integration_tests_all_passed %d/%d", passed, total)

        else:

            failed = [k for k, v in tests.items() if not v.get("passed")]

            logger.warning("[ContextMgr] action=integration_tests_failed failed=%s", failed)

        return results



    def run_self_tests(self) -> dict:

        results = {

            "anchor_extraction": self.self_test_anchor_extraction(),

            "density_gradient": self.self_test_density_gradient(),

            "summary_quality": self.self_test_summary_quality(),

            "merge_summaries": self.self_test_merge_summaries(),

            "circuit_breaker_state": self._circuit_breaker.get("state") == "closed" or self._circuit_breaker.get("state") == "open",

            "learning_buffer_bounded": len(self._learning_buffer) <= self._MAX_LEARNING_BUFFER,

            "predictive_cache_bounded": len(self._predictive_cache) <= self._MAX_PREDICTIVE_CACHE,

            "adjustment_history_bounded": len(self._adjustment_history) <= self._MAX_ADJUSTMENT_HISTORY,

            "conversation_lengths_bounded": len(self._conversation_lengths) <= self._MAX_CONVERSATION_LENGTHS,

            "instances_bounded": len(MemoryCompactionHook._instances) <= MemoryCompactionHook.MAX_INSTANCES,

        }

        all_passed = all(results.values())

        results["all_passed"] = all_passed

        results["total"] = len(results) - 1

        results["passed"] = sum(1 for v in list(results.values())[:-3] if v)

        if all_passed:

            logger.info("[ContextMgr] action=self_tests_all_passed")

        else:

            failed = [k for k, v in results.items() if v is False]

            logger.warning("[ContextMgr] action=self_tests_failed tests=%s", failed)

        return results

