"""唐人街 Agent 记忆系统"""
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def parse_cash_str(v: Optional[str]) -> int:
    if v is None or v == "":
        return 0
    return int(v)


def parse_plots_str(v: Optional[str]) -> List[int]:
    if v is None or v == "":
        return []
    return [int(x) for x in v.split(",")]


def parse_shops_str(v: Optional[str]) -> List[str]:
    if v is None or v == "":
        return []
    return v.split(",")


class ChinatownMemory:

    def __init__(self, max_vars: int = 50):
        self._variables: Dict[str, Any] = {}
        self._events: List[dict] = []
        self._deal_threads: Dict[str, List[dict]] = {}
        self._my_decisions: List[dict] = []
        self._max_vars = max_vars

    def set_variable(self, key: str, value: Any):
        if len(self._variables) >= self._max_vars and key not in self._variables:
            logger.warning(f"Memory variables limit reached ({self._max_vars})")
        self._variables[key] = value

    def get_variable(self, key: str, default: Any = None) -> Any:
        return self._variables.get(key, default)

    def has_variable(self, key: str) -> bool:
        return key in self._variables

    def append_event(self, status: str, source: str, target: str,
                     round_num: int = 0, deal_id: str = None, **fields):
        event = {
            "status": status,
            "source": source,
            "target": target,
            "round": round_num,
            "deal_id": deal_id,
            **fields,
        }
        self._events.append(event)
        if deal_id and status.startswith("deal_"):
            self._deal_threads.setdefault(deal_id, []).append(event)

    def get_events(self) -> List[dict]:
        return self._events

    def append_decision(self, phase: str, action: str, detail: str = ""):
        self._my_decisions.append({"phase": phase, "action": action, "detail": detail})

    def get_deal_thread(self, deal_id: str) -> List[dict]:
        return self._deal_threads.get(deal_id, [])

    def get_context_summary(self) -> dict:
        return {
            "cash": self.get_variable("cash", 0),
            "plots": self.get_variable("plots", []),
            "shops": self.get_variable("shops", []),
            "round": self.get_variable("round"),
            "phase": self.get_variable("phase"),
        }

    def clear(self):
        self._variables.clear()
        self._events.clear()
        self._deal_threads.clear()
        self._my_decisions.clear()

    def to_dict(self) -> dict:
        return {
            "variables": self._variables,
            "events": self._events,
            "deal_threads": {k: list(v) for k, v in self._deal_threads.items()},
            "decisions": self._my_decisions,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ChinatownMemory":
        memory = cls()
        memory._variables = data.get("variables", {})
        memory._events = list(data.get("events", []))
        memory._my_decisions = list(data.get("decisions", []))
        for evt in memory._events:
            deal_id = evt.get("deal_id")
            if deal_id and evt.get("status", "").startswith("deal_"):
                memory._deal_threads.setdefault(deal_id, []).append(evt)
        return memory
