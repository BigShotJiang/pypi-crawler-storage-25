import uvicorn
from fastapi import FastAPI

from agent_build_sdk.model.werewolf_model import AgentReq, AgentResp

from agent_build_sdk.sdk.agent import BasicAgent
from agent_build_sdk.utils.logger import logger
from fastapi.responses import HTMLResponse
import re
import html as html_lib
import markdown2


def remove_text_between_dashes(text):
    # 使用正则表达式去除被 --- 包裹的内容
    cleaned_text = re.sub(r'---.*?---', '', text, flags=re.DOTALL)
    return cleaned_text


def has_method(obj, method_name):
    return hasattr(obj, method_name) and callable(getattr(obj, method_name))

class EndpointServer:
    def __init__(self, agent: BasicAgent):
        self.app = FastAPI()
        self.agent = agent

        @self.app.get("/", response_class=HTMLResponse)
        async def read_root():
            with open("README.md", "r", encoding="utf-8") as f:
                readme_content = f.read()

            readme_content = remove_text_between_dashes(readme_content)

            # 将 Markdown 格式转换为 HTML
            html_content = markdown2.markdown(readme_content, extras=["fenced-code-blocks", "tables"])
            # return HTMLResponse(content=html_content)
            # 返回 HTML 响应
            return HTMLResponse(content=f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://github.githubassets.com/assets/github-dark.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/4.0.0/github-markdown.min.css">
        <title>Markdown to HTML</title>
        <style>
            /* 适应样式 */
            .markdown-body {{
                box-sizing: border-box;
                min-width: 200px;
                max-width: 800px;
                margin: 0 auto;
                padding: 45px;
            }}
        </style>
    </head>
    <body>
        <article class="markdown-body">
            {html_content}
        </article>
    </body>
    </html>
    """)

        @self.app.post("/agent/init")
        def init(req: AgentReq) -> AgentResp:
            self.agent.memory.clear()
            return AgentResp(success=True, result=self.agent.model_name)

        @self.app.post("/agent/getModelName")
        def get_model_name(req: AgentReq) -> AgentResp:
            return AgentResp(success=True, result=self.agent.model_name)
        # interact
        @self.app.post("/agent/interact")
        def interact(req: AgentReq) -> AgentResp:
            return self.agent.interact(req)

        # perceive
        @self.app.post("/agent/perceive")
        def perceive(req: AgentReq):
            try:
                self.agent.perceive(req)
                return AgentResp(success=True)
            except Exception as e:
                logger.error(f"invoke perceive error.", e)
                return AgentResp(success=False, errMsg=f"perceive error {e}")

        @self.app.post("/agent/checkHealth")
        def checkHealth(req: AgentReq):
            return AgentResp(success=True)

        if has_method(self.agent, 'get_prompt_history'):
            @self.app.get("/debug/prompts")
            def get_prompts():
                history = self.agent.get_prompt_history()
                return {
                    "success": True,
                    "total": len(history),
                    "prompts": history,
                }

            @self.app.get("/debug/prompts/view")
            def view_prompts():
                history = self.agent.get_prompt_history()
                html_items = ""
                for i, item in enumerate(reversed(history)):
                    html_items += f"""
                    <div class='prompt-item'>
                        <div class='header'>
                            <span class='meta'>{html_lib.escape(str(item.get('elapsed_sec', 0)))}s | {html_lib.escape(str(item.get('timestamp', '')))}</span>
                        </div>
                        <details>
                            <summary>Prompt</summary>
                            <pre>{html_lib.escape(str(item.get('prompt', '')))}</pre>
                        </details>
                        <details>
                            <summary>Response</summary>
                            <pre>{html_lib.escape(str(item.get('response', '')))}</pre>
                        </details>
                    </div>
                    """
                
                return HTMLResponse(content=f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='UTF-8'>
                    <title>Prompt History</title>
                    <style>
                        body {{ font-family: monospace; margin: 20px; background: #f5f5f5; }}
                        .prompt-item {{ background: white; margin: 10px 0; padding: 15px; border-radius: 5px; }}
                        .header {{ display: flex; justify-content: space-between; margin-bottom: 10px; }}
                        .meta {{ color: #666; font-size: 0.9em; }}
                        details {{ margin: 5px 0; }}
                        summary {{ cursor: pointer; color: #0066cc; font-weight: bold; }}
                        pre {{ background: #f0f0f0; padding: 10px; overflow-x: auto; white-space: pre-wrap; }}
                    </style>
                </head>
                <body>
                    <h2>Prompt History ({len(history)} items)</h2>
                    {html_items}
                </body>
                </html>
                """)

            @self.app.post("/debug/prompts/clear")
            def clear_prompts():
                self.agent.clear_prompt_history()
                return {"success": True, "message": "提示词历史已清空"}

    def start(self):
        uvicorn.run(self.app, host="0.0.0.0", port=7860)

