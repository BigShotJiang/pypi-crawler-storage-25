"""唐人街游戏模型定义"""
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class GamePhase(str, Enum):
    PHASE_START = "phase_start"
    PHASE_ROUND_START = "phase_round_start"
    PHASE_PLOT_ISSUE = "phase_plot_issue"
    PHASE_MAP_SYNC = "phase_map_sync"
    PHASE_SHOP_ISSUE = "phase_shop_issue"
    PHASE_FREE_TRADE = "phase_free_trade"
    PHASE_DIRECTED_TRADE = "phase_directed_trade"
    PHASE_BUILD = "phase_build"
    PHASE_SETTLE = "phase_settle"
    PHASE_RESULT = "phase_result"

    # 棋盘物理事件
    BOARD_PLOT_RESERVED = "board_plot_reserved"
    BOARD_SHOP_ISSUED = "board_shop_issued"
    BOARD_SHOP_BUILT = "board_shop_built"

    # 交易事件
    DEAL_PROPOSED = "deal_proposed"
    DEAL_COUNTERED = "deal_countered"
    DEAL_ACCEPTED = "deal_accepted"
    DEAL_REJECTED = "deal_rejected"
    DEAL_SKIPPED = "deal_skipped"
    DEAL_CANCELLED = "deal_cancelled"

    # 决策请求
    SELECT_PLOTS = "select_plots"
    PROPOSE_TRADE = "propose_trade"
    EVALUATE_TRADE = "evaluate_trade"
    PLAN_BUILD = "plan_build"


class TradeAction(str, Enum):
    SKIP = "SKIP"
    INITIATE = "INITIATE"
    ACCEPT = "ACCEPT"
    REJECT = "REJECT"
    COUNTER = "COUNTER"
    BUILD = "BUILD"
    RESERVE = "RESERVE"
    ACK = "ACK"


class AgentReq(BaseModel):

    status: Optional[str] = Field(default=None, alias="status", description="游戏阶段状态")
    round: Optional[int] = Field(default=None, description="当前回合数")
    source: Optional[str] = Field(default=None, description="动作主体")
    target: Optional[str] = Field(default=None, description="动作目标")
    deal_id: Optional[str] = Field(default=None, alias="dealId", description="交易会话ID")

    message: Optional[str] = Field(default=None, description="消息")
    name: Optional[str] = Field(default=None, description="玩家名称")
    quota: Optional[int] = Field(default=None, description="配额")

    offer_cash: Optional[str] = Field(default=None, alias="offerCash", description="提供的现金")
    offer_plots: Optional[str] = Field(default=None, alias="offerPlots", description="提供的地块")
    offer_shops: Optional[str] = Field(default=None, alias="offerShops", description="提供的店铺")
    demand_cash: Optional[str] = Field(default=None, alias="demandCash", description="要求的现金")
    demand_plots: Optional[str] = Field(default=None, alias="demandPlots", description="要求的地块")
    demand_shops: Optional[str] = Field(default=None, alias="demandShops", description="要求的店铺")

    snapshot: Optional[str] = Field(default=None, description="上帝视角数据")

    class Config:
        populate_by_name = True


class AgentResp(BaseModel):

    success: bool = Field(description="调用是否成功")
    errMsg: Optional[str] = Field(default=None, description="异常信息")

    action: Optional[str] = Field(default=None, description="决策动作")
    result: Optional[str] = Field(default=None, description="通用结果")
    target: Optional[str] = Field(default=None, description="目标方")
    deal_id: Optional[str] = Field(default=None, alias="dealId", description="交易会话ID")

    message: Optional[str] = Field(default=None, description="文本")

    offer_cash: Optional[str] = Field(default=None, alias="offerCash", description="提供的现金")
    offer_plots: Optional[str] = Field(default=None, alias="offerPlots", description="提供的地块")
    offer_shops: Optional[str] = Field(default=None, alias="offerShops", description="提供的店铺")
    demand_cash: Optional[str] = Field(default=None, alias="demandCash", description="要求的现金")
    demand_plots: Optional[str] = Field(default=None, alias="demandPlots", description="要求的地块")
    demand_shops: Optional[str] = Field(default=None, alias="demandShops", description="要求的店铺")

    class Config:
        populate_by_name = True

    @staticmethod
    def failure(error_msg: str) -> "AgentResp":
        return AgentResp(success=False, errMsg=error_msg)

    @staticmethod
    def ack() -> "AgentResp":
        return AgentResp(success=True, action="ACK")

    @staticmethod
    def action_only(action: str, message: str, deal_id: str = None) -> "AgentResp":
        return AgentResp(success=True, action=action, message=message, deal_id=deal_id)
