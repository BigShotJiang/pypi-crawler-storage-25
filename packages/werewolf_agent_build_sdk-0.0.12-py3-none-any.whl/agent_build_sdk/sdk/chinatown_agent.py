"""唐人街 Agent SDK 支持"""
import os
import time

from typing import Optional

from agent_build_sdk.memory.chinatown_memory import ChinatownMemory
from agent_build_sdk.model.chinatown_model import AgentReq, AgentResp
from agent_build_sdk.sdk.agent import BasicAgent
from agent_build_sdk.utils.logger import logger
from openai import OpenAI


class ChinatownAgent(BasicAgent):

    def __init__(self, name, memory=None, model_name=None, max_history=100):
        memory = memory or ChinatownMemory()
        super().__init__(name, memory, model_name or os.getenv("MODEL_NAME", "qwen-plus"))
        self._prompt_history: list = []
        self._max_history = max_history
        self.player_id: str = ""
        self._client: Optional[OpenAI] = None

    def _get_client(self) -> OpenAI:
        if self._client is None:
            self._client = OpenAI(
                api_key=os.getenv("API_KEY", ""),
                base_url=os.getenv("BASE_URL", ""),
            )
        return self._client

    def call_llm(self, prompt: str, phase: str = "") -> str:
        t_start = time.time()
        result = self._do_llm_call(prompt)
        elapsed = round(time.time() - t_start, 2)

        self._prompt_history.append({
            "phase": phase,
            "prompt": prompt,
            "response": result,
            "elapsed_sec": elapsed,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })

        if len(self._prompt_history) > self._max_history:
            self._prompt_history = self._prompt_history[-self._max_history:]

        return result

    def _do_llm_call(self, prompt: str) -> str:
        client = self._get_client()
        completion = client.chat.completions.create(
            model=self.model_name,
            messages=[
                {'role': 'system', 'content': 'You are a helpful assistant.'},
                {'role': 'user', 'content': prompt}
            ],
            temperature=0.7,
        )
        if not completion.choices:
            logger.error(f"LLM returned empty choices, model={self.model_name}")
            return ""
        return completion.choices[0].message.content or ""

    def get_prompt_history(self) -> list:
        return self._prompt_history

    def clear_prompt_history(self):
        self._prompt_history.clear()

    def perceive(self, req=AgentReq):
        raise NotImplementedError("子类必须实现 perceive 方法")

    def interact(self, req=AgentReq) -> AgentResp:
        raise NotImplementedError("子类必须实现 interact 方法")
