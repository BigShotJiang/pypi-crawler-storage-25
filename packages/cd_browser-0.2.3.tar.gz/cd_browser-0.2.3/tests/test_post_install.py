from pathlib import Path

import pytest

from cd_browser_post_install import main

CD_FUNCTION_SNIPPET = "cd_() {"


def test_post_install_handles_eof_without_crashing(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setattr(
        "builtins.input", lambda _prompt: (_ for _ in ()).throw(EOFError)
    )

    main()

    output = capsys.readouterr().out
    assert "No interactive input detected" in output
    assert "source ~/.zshrc" in output


def test_post_install_adds_cd_function_once(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("SHELL", "/bin/zsh")
    monkeypatch.setenv("HOME", str(tmp_path))

    responses = iter(["y", "y"])
    monkeypatch.setattr("builtins.input", lambda _prompt: next(responses))

    main()
    main()

    profile_path = tmp_path / ".zshrc"
    content = profile_path.read_text(encoding="utf-8")

    assert content.count(CD_FUNCTION_SNIPPET) == 1

    output = capsys.readouterr().out
    assert "already exists" in output
    assert "source ~/.zshrc" in output
