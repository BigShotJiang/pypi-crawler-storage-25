#!/usr/bin/env python3
"""Post-install script for cd-browser to guide users on shell integration."""

import os
import sys


def _profile_for_shell(shell: str) -> str:
    if shell == "zsh":
        return "~/.zshrc"

    return "~/.bashrc"


def _is_cd_function_present(profile_path: str) -> bool:
    if not os.path.exists(profile_path):
        return False

    with open(profile_path, encoding="utf-8") as profile_file:
        return "cd_() {" in profile_file.read()


def main() -> None:
    """Print shell integration instructions after installation."""
    print("\n" + "=" * 60)
    print("🎉 cd-browser installed successfully!")
    print("=" * 60)
    print()
    print(
        "To enable the 'cd_' command, you need to add a function to your shell profile."
    )
    print()

    shell = os.environ.get("SHELL", "").split("/")[-1]
    profile = _profile_for_shell(shell)

    cd_function = """cd_() {
  local target
  target="$(cd_browser)" || return
  if [ -n "$target" ] && [ -d "$target" ]; then
    cd "$target"
  fi
}"""

    print(f"Copy this to the end of {profile}:")
    print()
    print(cd_function)
    print()

    profile_path = os.path.expanduser(profile)

    try:
        response = (
            input("Do you want me to add it automatically? (y/n): ").strip().lower()
        )
        if response == "y":
            if _is_cd_function_present(profile_path):
                print(f"\nℹ️ cd_() already exists in {profile}, no changes made.")
            else:
                with open(profile_path, "a", encoding="utf-8") as f:
                    f.write("\n" + cd_function + "\n")
                print(f"\n✅ Added to {profile}")
            print(f"Run 'source {profile}' or restart your terminal to activate cd_.")
        else:
            print(f"\nAdd the function to {profile} manually.")
            print(f"Then run 'source {profile}' or restart terminal.")
    except EOFError:
        print(
            f"\nNo interactive input detected. Add the function to {profile} manually."
        )
        print(f"Then run 'source {profile}' or restart terminal.")
    except KeyboardInterrupt:
        print("\n\nSetup cancelled. You can add the function manually later.")
        sys.exit(0)

    print("\n" + "=" * 60)
    print(
        f"For uninstall: after 'pip uninstall cd-browser', remove cd_() from {profile}."
    )
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
