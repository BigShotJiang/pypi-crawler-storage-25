from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, ValidationError


class RepoConfig(BaseModel):
    branch: str = "main"


class GitHubAppConfig(BaseModel):
    app_id: str = ""
    installation_id: str = ""
    private_key_env: str = "GITHUB_APP_PRIVATE_KEY"


class AWSConfig(BaseModel):
    region: str = "us-east-1"
    codebuild_project: str = "visionguard-runner"
    artifacts_bucket: str = "visionguard-artifacts"


class BuildConfig(BaseModel):
    install: str = "pip install -r requirements.txt"


class RunConfig(BaseModel):
    baseline: str = "python eval.py --input {input_dir} --output {output_dir}"


class MetricsConfig(BaseModel):
    command: str = "python metrics.py --pred {output_dir} --gt {gt_dir}"
    primary_metric: str = "mAP"


class DataConfig(BaseModel):
    baseline_dataset: str
    ground_truth: str


class ThresholdConfig(BaseModel):
    max_primary_metric_drop: float = 0.05


class LLMConfig(BaseModel):
    provider: str = "gemini"
    model: str = "gemini-2.5-pro"
    api_key_env: str = "GEMINI_API_KEY"
    base_url: str = ""


class VisionGuardConfig(BaseModel):
    version: int = 1
    repo: RepoConfig = Field(default_factory=RepoConfig)
    github: GitHubAppConfig = Field(default_factory=GitHubAppConfig)
    aws: AWSConfig = Field(default_factory=AWSConfig)
    task_type: str = "detection"
    build: BuildConfig = Field(default_factory=BuildConfig)
    run: RunConfig = Field(default_factory=RunConfig)
    metrics: MetricsConfig = Field(default_factory=MetricsConfig)
    data: DataConfig
    suites: list[str] = Field(default_factory=lambda: ["core"])
    thresholds: ThresholdConfig = Field(default_factory=ThresholdConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)


class ConfigError(Exception):
    pass


def load_config(config_path: str | Path) -> VisionGuardConfig:
    path = Path(config_path)
    if not path.exists():
        raise ConfigError(f"Config file not found: {path}")
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    try:
        return VisionGuardConfig.model_validate(data)
    except ValidationError as exc:
        raise ConfigError(f"Invalid config: {exc}") from exc


def write_sample_config(path: str | Path) -> Path:
    sample = {
        "version": 1,
        "repo": {"branch": "main"},
        "github": {
            "app_id": "",
            "installation_id": "",
            "private_key_env": "GITHUB_APP_PRIVATE_KEY",
        },
        "aws": {
            "region": "us-east-1",
            "codebuild_project": "visionguard-runner",
            "artifacts_bucket": "visionguard-artifacts",
        },
        "task_type": "detection",
        "build": {"install": "pip install -r requirements.txt"},
        "run": {"baseline": "python eval.py --input {input_dir} --output {output_dir}"},
        "metrics": {
            "command": "python metrics.py --pred {output_dir} --gt {gt_dir}",
            "primary_metric": "mAP",
        },
        "data": {
            "baseline_dataset": "./sample_data/images",
            "ground_truth": "./sample_data/gt",
        },
        "suites": ["core"],
        "thresholds": {"max_primary_metric_drop": 0.05},
        "llm": {
            "provider": "gemini",
            "model": "gemini-2.5-pro",
            "api_key_env": "GEMINI_API_KEY",
            "base_url": "",
        },
    }
    output = Path(path)
    output.write_text(yaml.safe_dump(sample, sort_keys=False), encoding="utf-8")
    return output


def normalized_config_dict(cfg: VisionGuardConfig) -> dict[str, Any]:
    return cfg.model_dump(mode="json")
