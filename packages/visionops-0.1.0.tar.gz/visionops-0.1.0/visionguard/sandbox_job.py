from __future__ import annotations

import json
import os
import tempfile
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from visionguard.adapters.command_adapter import CommandAdapter
from visionguard.agent.fix_agent import FixAgent
from visionguard.agent.llm_client import LLMClient
from visionguard.agent.rca_agent import RCAAgent
from visionguard.agent.repo_mapper import RepoMapperAgent
from visionguard.analysis.compare import compute_regression_summary
from visionguard.analysis.evidence_bundle import build_evidence_bundle
from visionguard.analysis.report import write_reports
from visionguard.analysis.stage_localizer import localize_failure_stage
from visionguard.aws_codebuild import AWSExecutionError, poll_build, start_codebuild
from visionguard.config import VisionGuardConfig
from visionguard.github_app import GitHubAppError, build_authenticated_clone_url, get_installation_token
from visionguard.simulator.generator import generate_corruption_datasets
from visionguard.utils import copy_repo, ensure_dir


def _resolve_repo_path(repo_root: Path, value: str) -> Path:
    p = Path(value)
    if p.is_absolute():
        return p
    return (repo_root / p).resolve()


def _extract_logs(*text_blobs: str) -> list[str]:
    snippets: list[str] = []
    for blob in text_blobs:
        if not blob:
            continue
        lines = [line for line in blob.splitlines() if line.strip()]
        snippets.extend(lines[-10:])
    return snippets[-30:]


def _compact(text: str, max_chars: int = 400) -> str:
    text = text.strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3] + "..."


def _build_execution_diagnostics(
    install_result: Any,
    baseline_run: Any,
    baseline_metrics_run: Any,
    suite_results: list[dict[str, Any]],
) -> dict[str, Any]:
    failed_suites = [
        row
        for row in suite_results
        if int(row.get("run_returncode", 0)) != 0 or int(row.get("metrics_returncode", 0)) != 0
    ]
    return {
        "install": {
            "returncode": install_result.returncode,
            "stderr_tail": _compact(install_result.stderr, 600),
        },
        "baseline_run": {
            "returncode": baseline_run.returncode,
            "stderr_tail": _compact(baseline_run.stderr, 600),
        },
        "baseline_metrics": {
            "returncode": baseline_metrics_run.returncode,
            "stderr_tail": _compact(baseline_metrics_run.stderr, 600),
        },
        "suite_failures_count": len(failed_suites),
        "suite_failures_sample": [
            {
                "suite": row.get("suite"),
                "corruption": row.get("corruption"),
                "severity": row.get("severity"),
                "run_returncode": row.get("run_returncode"),
                "metrics_returncode": row.get("metrics_returncode"),
            }
            for row in failed_suites[:8]
        ],
    }


def run_local_pipeline(repo_path: str | Path, config: VisionGuardConfig, output_dir: str | Path | None = None) -> dict[str, Any]:
    repo_source = Path(repo_path).resolve()
    if not repo_source.exists():
        raise FileNotFoundError(f"Repo path not found: {repo_source}")

    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    out_root = ensure_dir(output_dir or Path.cwd() / f"visionguard_output_{timestamp}")

    with tempfile.TemporaryDirectory(prefix="visionguard_") as temp_dir:
        temp_root = Path(temp_dir)
        sandbox_repo = copy_repo(repo_source, temp_root / "repo")
        sandbox_data = temp_root / "datasets"
        ensure_dir(sandbox_data)
        adapter = CommandAdapter(repo_dir=sandbox_repo, config=config)
        llm = LLMClient(config.llm)

        install_result = adapter.install()

        baseline_input = _resolve_repo_path(sandbox_repo, config.data.baseline_dataset)
        gt_dir = _resolve_repo_path(sandbox_repo, config.data.ground_truth)
        baseline_output = ensure_dir(temp_root / "baseline_output")

        baseline_run = adapter.run_baseline(input_dir=baseline_input, output_dir=baseline_output)
        baseline_metrics_run, baseline_metrics = adapter.run_metrics(output_dir=baseline_output, gt_dir=gt_dir)

        manifest = generate_corruption_datasets(
            source_dataset=baseline_input,
            output_root=sandbox_data / "corrupted",
            suites=config.suites,
            severities=[1, 2, 3],
        )

        suite_results: list[dict[str, Any]] = []
        run_logs: list[str] = _extract_logs(
            install_result.stdout,
            install_result.stderr,
            baseline_run.stdout,
            baseline_run.stderr,
            baseline_metrics_run.stdout,
            baseline_metrics_run.stderr,
        )

        for item in manifest:
            suite_output = ensure_dir(temp_root / "outputs" / f"{item['suite']}_{item['corruption']}_s{item['severity']}")
            run_result = adapter.run_baseline(input_dir=Path(item["dataset_dir"]), output_dir=suite_output)
            metrics_result, metrics = adapter.run_metrics(output_dir=suite_output, gt_dir=gt_dir)
            run_logs.extend(_extract_logs(run_result.stdout, run_result.stderr, metrics_result.stdout, metrics_result.stderr))
            suite_results.append(
                {
                    "suite": item["suite"],
                    "corruption": item["corruption"],
                    "severity": item["severity"],
                    "dataset_dir": item["dataset_dir"],
                    "metrics": metrics,
                    "run_returncode": run_result.returncode,
                    "metrics_returncode": metrics_result.returncode,
                }
            )

        regression = compute_regression_summary(
            baseline_metrics=baseline_metrics,
            suite_runs=suite_results,
            metric_name=config.metrics.primary_metric,
            max_drop=config.thresholds.max_primary_metric_drop,
        )
        stage = localize_failure_stage(
            regression_rows=regression.suite_metrics,
            baseline_run_ok=baseline_run.returncode == 0 and baseline_metrics_run.returncode == 0,
            run_logs=run_logs,
            parser_errors=[line for line in run_logs if "parser" in line.lower() and "error" in line.lower()],
        )

        repo_map = RepoMapperAgent(llm=llm).map_repo(sandbox_repo)
        evidence = build_evidence_bundle(
            repo_summary=repo_map,
            baseline_metrics=baseline_metrics,
            suite_metrics=regression.suite_metrics,
            stage_localization=stage,
            logs=run_logs,
            artifact_paths={
                "sandbox_repo": str(sandbox_repo),
                "baseline_output": str(baseline_output),
                "corruption_manifest": str(out_root / "artifact_manifest.json"),
            },
        )

        rca_hypotheses, rca_summary, rca_llm_used = RCAAgent(llm=llm).analyze(evidence)
        fix_suggestions, fix_llm_used = FixAgent(llm=llm).suggest(evidence)
        evidence.llm_used = repo_map.llm_used or rca_llm_used or fix_llm_used
        execution_diagnostics = _build_execution_diagnostics(
            install_result=install_result,
            baseline_run=baseline_run,
            baseline_metrics_run=baseline_metrics_run,
            suite_results=suite_results,
        )

        report_paths = write_reports(
            output_dir=out_root,
            repo=str(repo_source),
            task_type=config.task_type,
            regression=regression,
            evidence=evidence,
            rca=rca_hypotheses,
            rca_summary=rca_summary,
            fixes_text=fix_suggestions,
            execution_diagnostics=execution_diagnostics,
        )

        (Path(report_paths["artifact_manifest_json"])).write_text(
            json.dumps({"manifest": manifest, "suite_runs": suite_results, "stage": asdict(stage)}, indent=2),
            encoding="utf-8",
        )

        return {
            "output_dir": str(out_root),
            "report_paths": report_paths,
            "baseline_metrics": baseline_metrics,
            "regression": asdict(regression),
            "stage": asdict(stage),
            "rca_summary": rca_summary,
            "llm_used": evidence.llm_used,
            "execution_diagnostics": execution_diagnostics,
        }


def run_aws_pipeline(repo: str, config: VisionGuardConfig) -> dict[str, Any]:
    try:
        sts = boto3.client("sts", region_name=config.aws.region)
        identity = sts.get_caller_identity()
    except (ClientError, BotoCoreError) as exc:
        raise AWSExecutionError(
            "AWS credentials/config not available. Configure AWS credentials and region, "
            "then retry. Example: aws configure, set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY, "
            f"and ensure CodeBuild project `{config.aws.codebuild_project}` exists. Details: {exc}"
        ) from exc

    clone_url = repo
    token = ""
    if "/" in repo or repo.startswith("http"):
        try:
            token = get_installation_token(
                app_id=config.github.app_id,
                installation_id=config.github.installation_id,
                private_key_env=config.github.private_key_env,
            )
            clone_url = build_authenticated_clone_url(repo=repo, token=token)
        except GitHubAppError:
            clone_url = repo

    env_vars = {
        "VISIONGUARD_REPO": repo,
        "VISIONGUARD_CLONE_URL": clone_url,
        "VISIONGUARD_CONFIG_B64": "",
        "VISIONGUARD_TASK_TYPE": config.task_type,
        "VISIONGUARD_REGION": config.aws.region,
    }
    if token:
        env_vars["GITHUB_INSTALLATION_TOKEN"] = token
    env_vars.update(
        {
            "OPENAI_API_KEY": os.getenv(config.llm.api_key_env, ""),
            "AWS_DEFAULT_REGION": config.aws.region,
        }
    )

    build = start_codebuild(
        project_name=config.aws.codebuild_project,
        region=config.aws.region,
        env_vars=env_vars,
        source_version=config.repo.branch,
    )
    build_id = build["id"]
    final = poll_build(region=config.aws.region, build_id=build_id)
    return {
        "build_id": build_id,
        "status": final.get("buildStatus"),
        "log_group": final.get("logs", {}).get("groupName"),
        "log_stream": final.get("logs", {}).get("streamName"),
        "artifact_location": final.get("artifacts", {}).get("location"),
        "caller_arn": identity.get("Arn"),
    }
