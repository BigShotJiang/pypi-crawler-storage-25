from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class RunResult:
    command: str
    returncode: int
    stdout: str
    stderr: str
    duration_s: float
    output_dir: Path | None = None


@dataclass
class SuiteRun:
    suite_name: str
    severity: int
    corruption: str
    dataset_dir: Path
    metrics: dict[str, Any]
    run_result: RunResult
    metrics_result: RunResult


@dataclass
class BaselineRun:
    dataset_dir: Path
    metrics: dict[str, Any]
    run_result: RunResult
    metrics_result: RunResult


@dataclass
class RegressionSummary:
    primary_metric_name: str
    baseline_metric: float
    suite_metrics: list[dict[str, Any]]
    worst_suite: str | None
    worst_delta: float
    severity: str
    has_regression: bool
    latency_deltas: dict[str, float] = field(default_factory=dict)


@dataclass
class RepoMap:
    entrypoints: list[str]
    preprocess_files: list[str]
    postprocess_files: list[str]
    parser_files: list[str]
    model_files: list[str]
    setup_files: list[str]
    summary: str
    pipeline_graph: str
    llm_used: bool = False


@dataclass
class RCAHypothesis:
    category: str
    explanation: str
    confidence: float
    likely_files: list[str] = field(default_factory=list)


@dataclass
class FixCandidate:
    title: str
    explanation: str
    confidence: float
    related_stage: str


@dataclass
class StageLocalization:
    stage: str
    reasons: list[str]
    confidence: float


@dataclass
class EvidenceBundle:
    repo_summary: RepoMap
    baseline_metrics: dict[str, Any]
    suite_metrics: list[dict[str, Any]]
    failing_suites: list[dict[str, Any]]
    stage_localization: StageLocalization
    log_snippets: list[str]
    artifact_paths: dict[str, str]
    heuristic_explanations: list[str]
    fix_candidates: list[FixCandidate]
    llm_used: bool = False
