from __future__ import annotations

import json
import logging
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

from visionguard.models import RunResult


LOGGER = logging.getLogger("visionguard")


def configure_logging(verbose: bool = False) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )


def substitute_placeholders(template: str, values: dict[str, str]) -> str:
    command = template
    for key, value in values.items():
        command = command.replace(f"{{{key}}}", value)
    return command


def run_command(command: str, cwd: str | Path, env: dict[str, str] | None = None) -> RunResult:
    start = time.time()
    process = subprocess.run(
        command,
        shell=True,
        cwd=str(cwd),
        env=env,
        capture_output=True,
        text=True,
    )
    duration = time.time() - start
    result = RunResult(
        command=command,
        returncode=process.returncode,
        stdout=process.stdout,
        stderr=process.stderr,
        duration_s=duration,
    )
    LOGGER.info(
        "command_completed",
        extra={
            "command": command,
            "returncode": process.returncode,
            "duration_s": round(duration, 3),
        },
    )
    return result


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_read_json(path: str | Path) -> dict[str, Any]:
    data_path = Path(path)
    if not data_path.exists():
        return {}
    try:
        return json.loads(data_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def copy_repo(src: str | Path, dst: str | Path) -> Path:
    src_path = Path(src).resolve()
    dst_path = Path(dst).resolve()
    if dst_path.exists():
        shutil.rmtree(dst_path)
    shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
    return dst_path


def list_text_files(base_dir: str | Path, max_files: int = 200) -> list[Path]:
    base = Path(base_dir)
    files: list[Path] = []
    for path in base.rglob("*"):
        if len(files) >= max_files:
            break
        if path.is_file() and path.suffix.lower() in {
            ".py",
            ".yaml",
            ".yml",
            ".json",
            ".toml",
            ".txt",
            ".md",
            ".cfg",
            ".ini",
        }:
            files.append(path)
    return files
