from __future__ import annotations

import json
import os
from pathlib import Path

import typer
import yaml

from visionguard.analysis.report import pretty_print_report
from visionguard.autoconfig import build_autoconfig_with_meta, write_autoconfig
from visionguard.aws_codebuild import AWSExecutionError
from visionguard.builtin_metrics import compute_yolo_metrics
from visionguard.config import ConfigError, load_config, normalized_config_dict, write_sample_config
from visionguard.github_app import generate_jwt
from visionguard.sandbox_job import run_aws_pipeline, run_local_pipeline
from visionguard.utils import configure_logging


app = typer.Typer(help="visionguard CLI prototype")


@app.command("init-config")
def init_config(path: str = typer.Option("visionguard.yaml", help="Path to write sample config")) -> None:
    output = write_sample_config(path)
    typer.echo(f"Wrote sample config to {output}")


@app.command("validate-config")
def validate_config(config: str = typer.Option(..., "--config", help="Path to visionguard yaml config")) -> None:
    try:
        cfg = load_config(config)
    except ConfigError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1)
    typer.echo(yaml.safe_dump(normalized_config_dict(cfg), sort_keys=False))


@app.command("local-run")
def local_run(
    repo_path: str = typer.Option(..., "--repo-path", help="Path to local CV repository"),
    config: str = typer.Option(..., "--config", help="Path to visionguard yaml config"),
    output_dir: str = typer.Option("", "--output-dir", help="Optional output directory"),
    verbose: bool = typer.Option(False, "--verbose", help="Enable debug logging"),
) -> None:
    configure_logging(verbose=verbose)
    try:
        cfg = load_config(config)
    except ConfigError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1)
    result = run_local_pipeline(repo_path=repo_path, config=cfg, output_dir=output_dir or None)
    typer.echo("Local run completed.")
    typer.echo(json.dumps(result, indent=2))
    typer.echo(f"Report: {Path(result['output_dir']) / 'report.md'}")


@app.command("aws-run")
def aws_run(
    repo: str = typer.Option(..., "--repo", help="GitHub owner/repo or clone URL"),
    config: str = typer.Option(..., "--config", help="Path to visionguard yaml config"),
    verbose: bool = typer.Option(False, "--verbose", help="Enable debug logging"),
) -> None:
    configure_logging(verbose=verbose)
    try:
        cfg = load_config(config)
    except ConfigError as exc:
        typer.echo(str(exc))
        raise typer.Exit(code=1)
    try:
        result = run_aws_pipeline(repo=repo, config=cfg)
    except AWSExecutionError as exc:
        typer.echo("AWS run failed due to setup/config issue.")
        typer.echo(str(exc))
        typer.echo(
            "Setup guidance:\n"
            "1) Configure AWS credentials (`aws configure` or env vars).\n"
            "2) Create/configure CodeBuild project matching aws.codebuild_project.\n"
            "3) Ensure IAM grants CodeBuild + S3 access.\n"
            "4) (Optional private repos) set GitHub App values and private key env."
        )
        raise typer.Exit(code=2)
    typer.echo(json.dumps(result, indent=2))


@app.command("report")
def report(path: str = typer.Option(..., "--path", help="Output dir containing report.md")) -> None:
    typer.echo(pretty_print_report(path))


@app.command("autoconfig")
def autoconfig(
    repo_path: str = typer.Option(..., "--repo-path", help="Path to local CV repository"),
    output: str = typer.Option("visionguard.yaml", "--output", help="Path to write inferred config"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing output file"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show inferred config without writing"),
    explain: bool = typer.Option(False, "--explain", help="Print confidence/explanation metadata"),
) -> None:
    config, notes, meta = build_autoconfig_with_meta(repo_path)
    if dry_run:
        typer.echo(yaml.safe_dump(config, sort_keys=False))
        if explain:
            typer.echo(json.dumps(meta, indent=2))
        return

    output_path = Path(output)
    if output_path.exists() and not overwrite:
        typer.echo(f"Output already exists: {output_path}. Use --overwrite to replace.")
        raise typer.Exit(code=2)
    out, notes, meta_path = write_autoconfig(repo_path=repo_path, output_path=output_path)
    typer.echo(f"Wrote autoconfig to {out}")
    typer.echo(f"Wrote autoconfig metadata to {meta_path}")
    if notes:
        typer.echo("Autoconfig notes:")
        for note in notes:
            typer.echo(f"- {note}")
    if explain:
        typer.echo(json.dumps(meta, indent=2))


@app.command("builtin-metrics")
def builtin_metrics(
    pred: str = typer.Option(..., "--pred", help="Prediction output directory"),
    gt: str = typer.Option(..., "--gt", help="Ground-truth labels directory"),
) -> None:
    metrics = compute_yolo_metrics(pred_dir=pred, gt_dir=gt)
    typer.echo(json.dumps(metrics))


@app.command("doctor")
def doctor(
    config: str = typer.Option("", "--config", help="Optional config path to validate"),
    repo_path: str = typer.Option("", "--repo-path", help="Optional repo path for autoconfig dry-run checks"),
) -> None:
    checks: dict[str, str] = {}
    checks["python"] = "ok"
    checks["gemini_api_key"] = "present" if bool(os.getenv("GEMINI_API_KEY", "").strip().strip('"').strip("'")) else "missing"

    if config:
        try:
            cfg = load_config(config)
            checks["config"] = "valid"
            checks["llm_config"] = f"{cfg.llm.provider}:{cfg.llm.model}"
        except Exception as exc:
            checks["config"] = f"invalid: {exc}"
    else:
        checks["config"] = "skipped"

    if repo_path:
        try:
            _cfg, notes, _meta = build_autoconfig_with_meta(repo_path)
            checks["autoconfig"] = "ok"
            checks["autoconfig_notes"] = f"{len(notes)} notes"
        except Exception as exc:
            checks["autoconfig"] = f"failed: {exc}"
    else:
        checks["autoconfig"] = "skipped"

    # Validate GitHub App private key shape if present.
    gh_key = os.getenv("GITHUB_APP_PRIVATE_KEY", "")
    if gh_key:
        try:
            generate_jwt(app_id="12345", private_key_pem=gh_key)
            checks["github_app_private_key"] = "looks valid"
        except Exception:
            checks["github_app_private_key"] = "present but invalid format"
    else:
        checks["github_app_private_key"] = "missing"

    typer.echo(json.dumps(checks, indent=2))


def main() -> None:
    from dotenv import load_dotenv
    from dotenv.main import find_dotenv

    # Load .env from cwd or nearest parent; real env vars win (override=False).
    load_dotenv(find_dotenv(), override=False)
    app()


if __name__ == "__main__":
    main()
