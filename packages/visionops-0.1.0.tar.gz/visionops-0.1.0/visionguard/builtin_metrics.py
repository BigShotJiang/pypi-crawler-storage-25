from __future__ import annotations

import json
from pathlib import Path


def yolo_to_xyxy(cx: float, cy: float, bw: float, bh: float, w: int, h: int) -> list[float]:
    x1 = (cx - bw / 2.0) * w
    y1 = (cy - bh / 2.0) * h
    x2 = (cx + bw / 2.0) * w
    y2 = (cy + bh / 2.0) * h
    return [x1, y1, x2, y2]


def iou(a: list[float], b: list[float]) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, (ax2 - ax1)) * max(0.0, (ay2 - ay1))
    area_b = max(0.0, (bx2 - bx1)) * max(0.0, (by2 - by1))
    union = area_a + area_b - inter
    if union <= 0:
        return 0.0
    return inter / union


def _load_gt(gt_file: Path, width: int, height: int) -> list[tuple[int, list[float]]]:
    if not gt_file.exists():
        return []
    out: list[tuple[int, list[float]]] = []
    for line in gt_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 5:
            continue
        cls_id, cx, cy, bw, bh = parts[:5]
        out.append((int(cls_id), yolo_to_xyxy(float(cx), float(cy), float(bw), float(bh), width, height)))
    return out


def compute_yolo_metrics(pred_dir: str | Path, gt_dir: str | Path) -> dict[str, float]:
    pred_root = Path(pred_dir)
    gt_root = Path(gt_dir)
    pred_files = [p for p in pred_root.rglob("*.json") if p.name != "predictions.json" and "raw" not in p.parts]
    tp = 0
    fp = 0
    fn = 0

    for pred_file in pred_files:
        payload = json.loads(pred_file.read_text(encoding="utf-8"))
        width = int(payload.get("size", {}).get("width", 0))
        height = int(payload.get("size", {}).get("height", 0))
        if width <= 0 or height <= 0:
            continue
        rel = Path(payload.get("image", "")).with_suffix(".txt")
        gt_items = _load_gt(gt_root / rel, width=width, height=height)
        preds = [(int(d.get("class_id", 0)), [float(x) for x in d.get("bbox_xyxy", [0, 0, 0, 0])]) for d in payload.get("detections", [])]

        used_gt: set[int] = set()
        for p_cls, p_box in preds:
            best_iou = 0.0
            best_idx = -1
            for idx, (g_cls, g_box) in enumerate(gt_items):
                if idx in used_gt or p_cls != g_cls:
                    continue
                score = iou(p_box, g_box)
                if score > best_iou:
                    best_iou = score
                    best_idx = idx
            if best_iou >= 0.5 and best_idx >= 0:
                tp += 1
                used_gt.add(best_idx)
            else:
                fp += 1
        fn += max(0, len(gt_items) - len(used_gt))

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    map_proxy = precision * recall
    return {
        "primary_metric": map_proxy,
        "mAP": map_proxy,
        "precision": precision,
        "recall": recall,
        "tp": float(tp),
        "fp": float(fp),
        "fn": float(fn),
    }
