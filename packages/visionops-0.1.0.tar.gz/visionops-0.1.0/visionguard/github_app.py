from __future__ import annotations

import os
import time
from urllib.parse import urlparse

import jwt
import requests


class GitHubAppError(Exception):
    pass


def generate_jwt(app_id: str, private_key_pem: str) -> str:
    now = int(time.time())
    payload = {"iat": now - 60, "exp": now + 540, "iss": app_id}
    return jwt.encode(payload, private_key_pem, algorithm="RS256")


def get_installation_token(app_id: str, installation_id: str, private_key_env: str) -> str:
    private_key = os.getenv(private_key_env, "")
    if not (app_id and installation_id and private_key):
        raise GitHubAppError(
            "Missing GitHub App config. Required: github.app_id, github.installation_id, and private key env value."
        )
    app_jwt = generate_jwt(app_id=app_id, private_key_pem=private_key)
    headers = {
        "Authorization": f"Bearer {app_jwt}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    response = requests.post(
        f"https://api.github.com/app/installations/{installation_id}/access_tokens",
        headers=headers,
        timeout=20,
    )
    if response.status_code >= 300:
        raise GitHubAppError(
            f"Failed to fetch installation token: {response.status_code} {response.text[:200]}"
        )
    return response.json()["token"]


def build_authenticated_clone_url(repo: str, token: str) -> str:
    if repo.startswith("http://") or repo.startswith("https://"):
        parsed = urlparse(repo)
        return f"https://x-access-token:{token}@{parsed.netloc}{parsed.path}"
    if "/" in repo:
        return f"https://x-access-token:{token}@github.com/{repo}.git"
    raise GitHubAppError(f"Unsupported repo value: {repo}")
