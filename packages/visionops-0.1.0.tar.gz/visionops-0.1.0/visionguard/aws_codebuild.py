from __future__ import annotations

import time
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError


class AWSExecutionError(Exception):
    pass


def start_codebuild(
    project_name: str,
    region: str,
    env_vars: dict[str, str],
    source_version: str | None = None,
) -> dict[str, Any]:
    client = boto3.client("codebuild", region_name=region)
    env = [{"name": k, "value": v, "type": "PLAINTEXT"} for k, v in env_vars.items()]
    try:
        response = client.start_build(
            projectName=project_name,
            sourceVersion=source_version,
            environmentVariablesOverride=env,
        )
        return response["build"]
    except (ClientError, BotoCoreError) as exc:
        raise AWSExecutionError(str(exc)) from exc


def poll_build(region: str, build_id: str, timeout_s: int = 1800, interval_s: int = 10) -> dict[str, Any]:
    client = boto3.client("codebuild", region_name=region)
    start = time.time()
    while time.time() - start < timeout_s:
        resp = client.batch_get_builds(ids=[build_id])
        builds = resp.get("builds", [])
        if not builds:
            raise AWSExecutionError(f"Build not found: {build_id}")
        build = builds[0]
        status = build.get("buildStatus", "UNKNOWN")
        if status in {"SUCCEEDED", "FAILED", "FAULT", "TIMED_OUT", "STOPPED"}:
            return build
        time.sleep(interval_s)
    raise AWSExecutionError(f"Build did not finish in {timeout_s}s")
