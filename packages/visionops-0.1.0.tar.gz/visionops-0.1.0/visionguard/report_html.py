from __future__ import annotations

import html
import json
import re
from pathlib import Path


def convert_report_md_to_html(
    report_md_path: str | Path,
    output_html_path: str | Path | None = None,
    summary_json_path: str | Path | None = None,
) -> Path:
    md_path = Path(report_md_path)
    if not md_path.exists():
        raise FileNotFoundError(f"Markdown report not found: {md_path}")
    html_path = Path(output_html_path) if output_html_path else md_path.with_suffix(".html")
    markdown = md_path.read_text(encoding="utf-8")
    summary_data = _load_summary_data(summary_json_path)
    html_path.write_text(_markdown_to_html_document(markdown, summary_data), encoding="utf-8")
    return html_path


def _markdown_to_html_document(markdown: str, summary_data: dict[str, object]) -> str:
    dashboard = _render_dashboard(summary_data)
    body = _render_markdown_body(markdown)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>visionguard Report</title>
  <style>
    :root {{
      --bg: #0f172a;
      --panel: #111827;
      --text: #e5e7eb;
      --muted: #94a3b8;
      --accent: #38bdf8;
      --border: #1f2937;
      --table-head: #0b1220;
      --code-bg: #020617;
    }}
    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 10px;
      margin-bottom: 14px;
    }}
    .kpi {{
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 10px 12px;
      background: rgba(2, 6, 23, 0.45);
    }}
    .kpi .label {{
      color: var(--muted);
      font-size: 0.86rem;
      margin-bottom: 4px;
    }}
    .kpi .value {{
      color: #e2e8f0;
      font-size: 1.02rem;
      font-weight: 600;
    }}
    .severity {{
      display: inline-block;
      padding: 2px 8px;
      border-radius: 999px;
      border: 1px solid var(--border);
      font-size: 0.83rem;
      margin-left: 6px;
    }}
    .severity-critical {{ background: rgba(220, 38, 38, 0.2); color: #fecaca; }}
    .severity-high {{ background: rgba(234, 88, 12, 0.2); color: #fed7aa; }}
    .severity-moderate {{ background: rgba(245, 158, 11, 0.2); color: #fde68a; }}
    .severity-none {{ background: rgba(22, 163, 74, 0.2); color: #bbf7d0; }}
    .bar-chart {{
      margin: 8px 0 18px 0;
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 10px 12px;
      background: rgba(2, 6, 23, 0.35);
    }}
    .bar-row {{
      display: grid;
      grid-template-columns: 220px 1fr 74px;
      gap: 10px;
      align-items: center;
      margin: 6px 0;
    }}
    .bar-label {{
      color: var(--muted);
      font-size: 0.84rem;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .bar-track {{
      height: 11px;
      border-radius: 999px;
      background: #0b1220;
      border: 1px solid var(--border);
      overflow: hidden;
    }}
    .bar-fill {{
      height: 100%;
      background: linear-gradient(90deg, #0ea5e9, #38bdf8);
    }}
    .bar-value {{
      text-align: right;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      color: #bae6fd;
      font-size: 0.83rem;
    }}
    body {{
      margin: 0;
      background: linear-gradient(180deg, #020617 0%, #0f172a 100%);
      color: var(--text);
      font-family: Inter, Segoe UI, Roboto, Arial, sans-serif;
      line-height: 1.5;
    }}
    .container {{
      max-width: 1000px;
      margin: 28px auto;
      padding: 28px;
      border: 1px solid var(--border);
      border-radius: 12px;
      background: rgba(17, 24, 39, 0.92);
      box-shadow: 0 18px 60px rgba(2, 6, 23, 0.5);
    }}
    h1, h2, h3 {{
      color: #f8fafc;
      margin-top: 1.3em;
      margin-bottom: 0.5em;
    }}
    h1 {{
      margin-top: 0;
      border-bottom: 1px solid var(--border);
      padding-bottom: 10px;
    }}
    p, li {{
      color: var(--text);
    }}
    ul {{
      padding-left: 1.1rem;
    }}
    code {{
      background: var(--code-bg);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 0.12rem 0.35rem;
      color: #bae6fd;
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.92em;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      margin: 14px 0 18px 0;
      font-size: 0.95rem;
      border: 1px solid var(--border);
    }}
    th, td {{
      border: 1px solid var(--border);
      padding: 8px 10px;
      text-align: left;
    }}
    th {{
      background: var(--table-head);
      color: #f1f5f9;
    }}
    tr:nth-child(even) td {{
      background: rgba(15, 23, 42, 0.42);
    }}
    .muted {{
      color: var(--muted);
    }}
  </style>
</head>
<body>
  <div class="container">
    {dashboard}
    {body}
  </div>
</body>
</html>
"""


def _render_markdown_body(markdown: str) -> str:
    lines = markdown.splitlines()
    out: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i].rstrip("\n")
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        if stripped.startswith("### "):
            out.append(f"<h3>{_inline(stripped[4:])}</h3>")
            i += 1
            continue
        if stripped.startswith("## "):
            out.append(f"<h2>{_inline(stripped[3:])}</h2>")
            i += 1
            continue
        if stripped.startswith("# "):
            out.append(f"<h1>{_inline(stripped[2:])}</h1>")
            i += 1
            continue

        if stripped.startswith("|"):
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                table_lines.append(lines[i].strip())
                i += 1
            out.append(_render_table(table_lines))
            continue

        if stripped.startswith("- "):
            items = []
            while i < len(lines) and lines[i].strip().startswith("- "):
                items.append(lines[i].strip()[2:])
                i += 1
            rendered_items = "".join(f"<li>{_inline(item)}</li>" for item in items)
            out.append(f"<ul>{rendered_items}</ul>")
            continue

        out.append(f"<p>{_inline(stripped)}</p>")
        i += 1

    return "\n".join(out)


def _render_table(lines: list[str]) -> str:
    if len(lines) < 2:
        return "".join(f"<p>{_inline(line)}</p>" for line in lines)
    headers = [_inline(c.strip()) for c in lines[0].strip("|").split("|")]
    rows = []
    for row_line in lines[2:]:
        cols = [_inline(c.strip()) for c in row_line.strip("|").split("|")]
        rows.append(cols)

    thead = "<thead><tr>" + "".join(f"<th>{h}</th>" for h in headers) + "</tr></thead>"
    tbody_rows = []
    for row in rows:
        cells = "".join(f"<td>{c}</td>" for c in row)
        tbody_rows.append(f"<tr>{cells}</tr>")
    tbody = "<tbody>" + "".join(tbody_rows) + "</tbody>"
    return f"<table>{thead}{tbody}</table>"


def _inline(text: str) -> str:
    escaped = html.escape(text)
    return re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)


def _load_summary_data(summary_json_path: str | Path | None) -> dict[str, object]:
    if not summary_json_path:
        return {}
    path = Path(summary_json_path)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _render_dashboard(summary: dict[str, object]) -> str:
    if not summary:
        return ""
    baseline = float(summary.get("baseline_metric", 0.0) or 0.0)
    worst_delta = float(summary.get("worst_delta", 0.0) or 0.0)
    severity = str(summary.get("severity", "unknown")).lower()
    task_type = str(summary.get("task_type", "unknown"))
    worst_suite = str(summary.get("worst_suite", "n/a"))
    stage_data = summary.get("stage_localization", {})
    stage = "unknown"
    if isinstance(stage_data, dict):
        stage = str(stage_data.get("stage", "unknown"))
    top = summary.get("top_regressions", [])
    if not isinstance(top, list):
        top = []

    sev_class = {
        "critical": "severity-critical",
        "high": "severity-high",
        "moderate": "severity-moderate",
        "none": "severity-none",
    }.get(severity, "severity-none")
    sev_badge = f"<span class='severity {sev_class}'>{html.escape(severity)}</span>"

    kpis = f"""
    <div class="kpi-grid">
      <div class="kpi"><div class="label">Task Type</div><div class="value">{html.escape(task_type)}</div></div>
      <div class="kpi"><div class="label">Baseline Metric</div><div class="value">{baseline:.4f}</div></div>
      <div class="kpi"><div class="label">Worst Delta</div><div class="value">{worst_delta:.4f}</div></div>
      <div class="kpi"><div class="label">Worst Suite</div><div class="value">{html.escape(worst_suite)}</div></div>
      <div class="kpi"><div class="label">Likely Stage</div><div class="value">{html.escape(stage)}</div></div>
      <div class="kpi"><div class="label">Severity</div><div class="value">{sev_badge}</div></div>
    </div>
    """

    bars = _render_top_regression_bars(top)
    return f"<h2>Overview</h2>{kpis}{bars}"


def _render_top_regression_bars(top_rows: list[object]) -> str:
    values: list[tuple[str, float]] = []
    for row in top_rows[:8]:
        if not isinstance(row, dict):
            continue
        label = str(row.get("suite_label", "unknown"))
        delta = float(row.get("delta", 0.0) or 0.0)
        if delta <= 0:
            continue
        values.append((label, delta))
    if not values:
        return ""
    max_delta = max(delta for _, delta in values) or 1.0
    rows = []
    for label, delta in values:
        width = max(1.0, min(100.0, (delta / max_delta) * 100.0))
        rows.append(
            "<div class='bar-row'>"
            f"<div class='bar-label'>{html.escape(label)}</div>"
            f"<div class='bar-track'><div class='bar-fill' style='width:{width:.2f}%'></div></div>"
            f"<div class='bar-value'>{delta:.4f}</div>"
            "</div>"
        )
    return "<div class='bar-chart'><h3>Top Regressions</h3>" + "".join(rows) + "</div>"
