from __future__ import annotations

from pathlib import Path
from typing import Any

import json
import yaml

from visionguard.agent.repo_mapper import RepoMapperAgent


IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
IGNORED_PARTS = {
    ".git",
    "__pycache__",
    "site-packages",
    "node_modules",
    "dist",
    "build",
    "target",
    ".venv",
    "venv",
    "env",
    ".mypy_cache",
    ".pytest_cache",
}

RUN_SCRIPT_CANDIDATES = [
    "eval.py",
    "evaluate.py",
    "infer.py",
    "inference.py",
    "predict.py",
    "run.py",
    "main.py",
]

METRICS_SCRIPT_CANDIDATES = [
    "metrics.py",
    "evaluate_metrics.py",
    "eval_metrics.py",
    "score.py",
]


def build_autoconfig(repo_path: str | Path) -> tuple[dict[str, Any], list[str]]:
    config, notes, _meta = build_autoconfig_with_meta(repo_path)
    return config, notes


def build_autoconfig_with_meta(repo_path: str | Path) -> tuple[dict[str, Any], list[str], dict[str, Any]]:
    repo = Path(repo_path).resolve()
    notes: list[str] = []
    repo_map = RepoMapperAgent(llm=None).map_repo(repo)
    confidence: dict[str, dict[str, Any]] = {}
    if repo_map.entrypoints:
        notes.append(f"Repo understanding candidates: {', '.join(repo_map.entrypoints[:3])}")

    install_cmd, install_conf = _guess_install_command(repo, notes)
    run_cmd, run_conf = _guess_run_command(repo, notes, inferred_entrypoints=repo_map.entrypoints)
    metrics_cmd = _guess_metrics_command(
        repo,
        notes,
        inferred_candidates=[*repo_map.entrypoints, *repo_map.parser_files, *repo_map.postprocess_files],
    )
    metrics_cmd, metrics_conf = metrics_cmd
    data_paths = _guess_data_paths(repo, notes)
    data_paths, data_conf = data_paths
    task_type = _guess_task_type(repo, repo_map)
    suites = _guess_suites(task_type)
    confidence["build.install"] = install_conf
    confidence["run.baseline"] = run_conf
    confidence["metrics.command"] = metrics_conf
    confidence["data.baseline_dataset"] = data_conf["baseline_dataset"]
    confidence["data.ground_truth"] = data_conf["ground_truth"]

    config = {
        "version": 1,
        "repo": {"branch": "main"},
        "github": {
            "app_id": "",
            "installation_id": "",
            "private_key_env": "GITHUB_APP_PRIVATE_KEY",
        },
        "aws": {
            "region": "us-east-1",
            "codebuild_project": "visionguard-runner",
            "artifacts_bucket": "visionguard-artifacts",
        },
        "task_type": task_type,
        "build": {"install": install_cmd},
        "run": {"baseline": run_cmd},
        "metrics": {"command": metrics_cmd, "primary_metric": "mAP"},
        "data": {
            "baseline_dataset": data_paths["baseline_dataset"],
            "ground_truth": data_paths["ground_truth"],
        },
        "suites": suites,
        "thresholds": {"max_primary_metric_drop": 0.05},
        "llm": {
            "provider": "gemini",
            "model": "gemini-2.5-pro",
            "api_key_env": "GEMINI_API_KEY",
            "base_url": "",
        },
    }
    meta = {
        "repo_path": str(repo),
        "repo_map": {
            "entrypoints": repo_map.entrypoints[:8],
            "preprocess_files": repo_map.preprocess_files[:8],
            "postprocess_files": repo_map.postprocess_files[:8],
            "parser_files": repo_map.parser_files[:8],
            "model_files": repo_map.model_files[:8],
            "summary": repo_map.summary,
        },
        "field_confidence": confidence,
        "notes": notes,
    }
    return config, notes, meta


def write_autoconfig(repo_path: str | Path, output_path: str | Path) -> tuple[Path, list[str], Path]:
    config, notes, meta = build_autoconfig_with_meta(repo_path)
    out = Path(output_path).resolve()
    out.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    meta_out = out.with_suffix(".autoconfig.meta.json")
    meta_out.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return out, notes, meta_out


def _guess_install_command(repo: Path, notes: list[str]) -> tuple[str, dict[str, Any]]:
    if (repo / "requirements.txt").exists():
        return "pip install -r requirements.txt", {"score": 0.93, "reason": "requirements.txt detected"}
    if (repo / "pyproject.toml").exists():
        notes.append("Detected pyproject.toml; using editable install.")
        return "pip install -e .", {"score": 0.84, "reason": "pyproject.toml detected"}
    if (repo / "Pipfile").exists():
        notes.append("Detected Pipfile; using pipenv install.")
        return "pipenv install", {"score": 0.8, "reason": "Pipfile detected"}
    if (repo / "environment.yml").exists() or (repo / "conda.yml").exists():
        notes.append("Detected conda env file; using conda environment update.")
        return "conda env update -f environment.yml", {"score": 0.76, "reason": "conda env file detected"}
    notes.append("No install manifest found; using no-op install command.")
    return "echo 'No install step inferred'", {"score": 0.25, "reason": "fallback no-op install"}


def _guess_run_command(repo: Path, notes: list[str], inferred_entrypoints: list[str]) -> tuple[str, dict[str, Any]]:
    scripts = _resolve_inferred_python_files(repo, inferred_entrypoints, include_keywords=("eval", "infer", "predict", "main", "run", "serve"))
    if not scripts:
        scripts = _find_python_scripts(repo, RUN_SCRIPT_CANDIDATES)
    if scripts:
        chosen = scripts[0]
        rel = str(chosen.relative_to(repo)).replace("\\", "/")
        text = _safe_read_text(chosen).lower()
        if "--images" in text and "--output" in text:
            return (
                f"python {rel} --images {{input_dir}} --output {{output_dir}}",
                {"score": 0.86, "reason": f"entrypoint {rel} with --images/--output"},
            )
        if "--source" in text and "--save-dir" in text:
            return (
                f"python {rel} --source {{input_dir}} --save-dir {{output_dir}}",
                {"score": 0.84, "reason": f"entrypoint {rel} with --source/--save-dir"},
            )
        return (
            f"python {rel} --input {{input_dir}} --output {{output_dir}}",
            {"score": 0.8, "reason": f"entrypoint {rel} inferred from repo map"},
        )
    notes.append("No obvious eval/infer script found; defaulting to eval.py template.")
    return (
        "python eval.py --input {input_dir} --output {output_dir}",
        {"score": 0.35, "reason": "fallback eval.py template"},
    )


def _guess_metrics_command(
    repo: Path, notes: list[str], inferred_candidates: list[str]
) -> tuple[str, dict[str, Any]]:
    # Prefer explicit metrics-like filenames before broader inferred candidates.
    scripts = _find_python_scripts(repo, METRICS_SCRIPT_CANDIDATES)
    if not scripts:
        scripts = _resolve_inferred_python_files(
            repo,
            inferred_candidates,
            include_keywords=("metric", "score", "eval", "evaluate"),
        )
    if scripts:
        chosen = scripts[0]
        rel = str(chosen.relative_to(repo)).replace("\\", "/")
        text = _safe_read_text(chosen).lower()
        if "--predictions" in text and "--ground-truth" in text:
            return (
                f"python {rel} --predictions {{output_dir}} --ground-truth {{gt_dir}}",
                {"score": 0.9, "reason": f"metrics script {rel} with predictions/ground-truth args"},
            )
        if "--pred" in text and "--gt" in text:
            return (
                f"python {rel} --pred {{output_dir}} --gt {{gt_dir}}",
                {"score": 0.9, "reason": f"metrics script {rel} with --pred/--gt args"},
            )
        if "--input" in text and "--labels" in text:
            return (
                f"python {rel} --input {{output_dir}} --labels {{gt_dir}}",
                {"score": 0.85, "reason": f"metrics script {rel} with --input/--labels args"},
            )
        return (
            f"python {rel} --pred {{output_dir}} --gt {{gt_dir}}",
            {"score": 0.72, "reason": f"metrics script {rel} inferred"},
        )

    gt_dir = _pick_ground_truth_dir(repo)
    if gt_dir:
        notes.append("No metrics script detected; using built-in YOLO-style metrics fallback.")
        return (
            "python -m visionguard.cli builtin-metrics --pred {output_dir} --gt {gt_dir}",
            {"score": 0.66, "reason": "fallback to built-in metrics command with detected ground-truth dir"},
        )

    notes.append("No metrics script detected; using metrics.py template.")
    return (
        "python metrics.py --pred {output_dir} --gt {gt_dir}",
        {"score": 0.3, "reason": "fallback metrics.py template"},
    )


def _guess_data_paths(repo: Path, notes: list[str]) -> tuple[dict[str, str], dict[str, dict[str, Any]]]:
    image_dirs = _discover_image_dirs(repo)
    baseline = _pick_baseline_dataset_dir(image_dirs, repo)
    gt = _pick_ground_truth_dir(repo)
    conf = {
        "baseline_dataset": {"score": 0.72 if baseline else 0.3, "reason": "detected image directory" if baseline else "fallback sample path"},
        "ground_truth": {"score": 0.72 if gt else 0.3, "reason": "detected ground-truth directory" if gt else "fallback sample path"},
    }

    if not baseline:
        notes.append("No image dataset directory detected; defaulting to ./sample_data/images.")
        baseline = "./sample_data/images"
    if not gt:
        notes.append("No ground-truth directory detected; defaulting to ./sample_data/gt.")
        gt = "./sample_data/gt"
    return {"baseline_dataset": baseline, "ground_truth": gt}, conf


def _guess_task_type(repo: Path, repo_map: Any) -> str:
    text = _combined_repo_surface(repo)
    map_surface = " ".join(
        [
            *repo_map.entrypoints,
            *repo_map.preprocess_files,
            *repo_map.postprocess_files,
            *repo_map.model_files,
            repo_map.summary,
            repo_map.pipeline_graph,
        ]
    ).lower()
    text = f"{text} {map_surface}"
    if "yolo" in text or "detector" in text or "detect" in text:
        return "detection"
    if "ocr" in text:
        return "ocr"
    if "face" in text:
        return "face"
    if "segment" in text:
        return "segmentation"
    return "detection"


def _guess_suites(task_type: str) -> list[str]:
    if task_type == "ocr":
        return ["core", "ocr"]
    if task_type == "face":
        return ["core", "face"]
    if task_type == "detection":
        return ["core", "detection"]
    return ["core"]


def _find_python_scripts(repo: Path, candidates: list[str]) -> list[Path]:
    hits: list[Path] = []
    for candidate in candidates:
        direct = list(repo.rglob(candidate))
        for path in direct:
            if _is_ignored(path):
                continue
            hits.append(path)
    return sorted(hits, key=lambda p: len(p.parts))


def _safe_read_text(path: Path, max_chars: int = 8000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")[:max_chars]
    except Exception:
        return ""


def _discover_image_dirs(repo: Path) -> list[Path]:
    candidates: list[Path] = []
    for path in repo.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in IMAGE_EXTS:
            continue
        if _is_ignored(path):
            continue
        candidates.append(path.parent)

    unique = sorted(set(candidates), key=lambda p: len(p.parts))
    return unique


def _pick_baseline_dataset_dir(image_dirs: list[Path], repo: Path) -> str | None:
    if not image_dirs:
        return None
    preferred_keywords = ("sample_data/images", "data/images", "images", "dataset")
    rel_dirs = [str(p.relative_to(repo)).replace("\\", "/") for p in image_dirs if repo in p.parents or p == repo]
    for key in preferred_keywords:
        for rel in rel_dirs:
            if key in rel.lower():
                return f"./{rel}"
    return f"./{rel_dirs[0]}" if rel_dirs else None


def _pick_ground_truth_dir(repo: Path) -> str | None:
    candidate_names = [
        "sample_data/gt",
        "sample_data/labels",
        "data/gt",
        "data/labels",
        "labels",
        "annotations",
        "ground_truth",
    ]
    all_dirs = [p for p in repo.rglob("*") if p.is_dir() and not _is_ignored(p)]
    rel_dirs = [str(p.relative_to(repo)).replace("\\", "/") for p in all_dirs if repo in p.parents or p == repo]
    for name in candidate_names:
        for rel in rel_dirs:
            if rel.lower().endswith(name):
                return f"./{rel}"
    return None


def _combined_repo_surface(repo: Path) -> str:
    names = [p.name.lower() for p in repo.rglob("*") if p.is_file() and not _is_ignored(p)]
    return " ".join(names[:2000])


def _is_ignored(path: Path) -> bool:
    parts = {part.lower() for part in path.parts}
    return any(part in IGNORED_PARTS for part in parts)


def _resolve_inferred_python_files(repo: Path, inferred_paths: list[str], include_keywords: tuple[str, ...]) -> list[Path]:
    matched: list[Path] = []
    fallback: list[Path] = []
    for rel in inferred_paths:
        try:
            path = (repo / rel).resolve()
            if not path.exists() or not path.is_file() or path.suffix.lower() != ".py":
                continue
            if _is_ignored(path):
                continue
            lower = str(path.name).lower()
            if include_keywords and any(keyword in lower for keyword in include_keywords):
                matched.append(path)
            else:
                fallback.append(path)
        except Exception:
            continue
    primary = sorted(set(matched), key=lambda p: len(p.parts))
    secondary = sorted(set(fallback), key=lambda p: len(p.parts))
    return [*primary, *secondary]
