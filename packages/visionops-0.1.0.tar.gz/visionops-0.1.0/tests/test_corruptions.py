from pathlib import Path

import cv2
import numpy as np

from visionguard.simulator.generator import generate_corruption_datasets


def test_generate_corruption_dataset_manifest(tmp_path: Path) -> None:
    src = tmp_path / "images"
    src.mkdir()
    image = np.zeros((32, 32, 3), dtype=np.uint8)
    image[:, :, 0] = 255
    cv2.imwrite(str(src / "a.jpg"), image)

    manifest = generate_corruption_datasets(
        source_dataset=src,
        output_root=tmp_path / "out",
        suites=["core"],
        severities=[1],
    )
    assert manifest
    first = manifest[0]
    assert first["files_total"] == 1
    assert Path(first["dataset_dir"]).exists()
