from pathlib import Path

from visionguard.autoconfig import build_autoconfig, build_autoconfig_with_meta


def test_build_autoconfig_detects_basic_repo_shape(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    (repo / "requirements.txt").write_text("numpy\n", encoding="utf-8")
    (repo / "eval.py").write_text(
        "import argparse\nif __name__ == '__main__':\n    parser=argparse.ArgumentParser()\n    parser.add_argument('--input')\n    parser.add_argument('--output')\n",
        encoding="utf-8",
    )
    (repo / "metrics.py").write_text(
        "import argparse\nif __name__ == '__main__':\n    parser=argparse.ArgumentParser()\n    parser.add_argument('--pred')\n    parser.add_argument('--gt')\n",
        encoding="utf-8",
    )
    (repo / "sample_data" / "images").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "gt").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "images" / "a.jpg").write_bytes(b"fake")
    (repo / "sample_data" / "gt" / "a.txt").write_text("0 0.5 0.5 0.2 0.2\n", encoding="utf-8")

    config, notes = build_autoconfig(repo)
    assert config["build"]["install"] == "pip install -r requirements.txt"
    assert config["run"]["baseline"].startswith("python eval.py")
    assert config["metrics"]["command"].startswith("python metrics.py")
    assert config["data"]["baseline_dataset"] == "./sample_data/images"
    assert config["data"]["ground_truth"] == "./sample_data/gt"
    assert isinstance(notes, list)


def test_build_autoconfig_falls_back_when_files_missing(tmp_path: Path) -> None:
    repo = tmp_path / "repo_empty"
    repo.mkdir()
    config, notes = build_autoconfig(repo)

    assert config["run"]["baseline"] == "python eval.py --input {input_dir} --output {output_dir}"
    assert config["metrics"]["command"] == "python metrics.py --pred {output_dir} --gt {gt_dir}"
    assert config["data"]["baseline_dataset"] == "./sample_data/images"
    assert config["data"]["ground_truth"] == "./sample_data/gt"
    assert notes


def test_build_autoconfig_uses_repo_mapper_entrypoint_for_nonstandard_name(tmp_path: Path) -> None:
    repo = tmp_path / "repo_mapper_case"
    repo.mkdir()
    (repo / "requirements.txt").write_text("numpy\n", encoding="utf-8")
    (repo / "app_entry.py").write_text(
        "\n".join(
            [
                "import argparse",
                "def main():",
                "    parser = argparse.ArgumentParser()",
                "    parser.add_argument('--input')",
                "    parser.add_argument('--output')",
                "if __name__ == '__main__':",
                "    main()",
            ]
        ),
        encoding="utf-8",
    )
    (repo / "sample_data" / "images").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "gt").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "images" / "a.jpg").write_bytes(b"fake")

    config, notes = build_autoconfig(repo)
    assert config["run"]["baseline"].startswith("python app_entry.py")
    assert any("Repo understanding candidates" in note for note in notes)


def test_build_autoconfig_returns_meta_with_confidence(tmp_path: Path) -> None:
    repo = tmp_path / "repo_meta"
    repo.mkdir()
    (repo / "requirements.txt").write_text("numpy\n", encoding="utf-8")
    (repo / "eval.py").write_text("print('x')\n", encoding="utf-8")
    (repo / "sample_data" / "images").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "gt").mkdir(parents=True, exist_ok=True)
    (repo / "sample_data" / "images" / "a.jpg").write_bytes(b"fake")

    config, notes, meta = build_autoconfig_with_meta(repo)
    assert config["build"]["install"] == "pip install -r requirements.txt"
    assert notes
    assert "field_confidence" in meta
    assert "run.baseline" in meta["field_confidence"]
    assert "repo_map" in meta
