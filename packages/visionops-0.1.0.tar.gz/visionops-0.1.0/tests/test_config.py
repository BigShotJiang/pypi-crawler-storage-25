from pathlib import Path

from visionguard.config import load_config, write_sample_config


def test_sample_config_roundtrip(tmp_path: Path) -> None:
    config_path = tmp_path / "visionguard.yaml"
    write_sample_config(config_path)
    cfg = load_config(config_path)
    assert cfg.version == 1
    assert cfg.metrics.primary_metric
    assert cfg.data.baseline_dataset
