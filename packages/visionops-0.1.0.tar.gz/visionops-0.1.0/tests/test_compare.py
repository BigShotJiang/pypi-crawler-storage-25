from visionguard.analysis.compare import compute_regression_summary


def test_compute_regression_summary_detects_drop() -> None:
    baseline = {"primary_metric": 0.82, "latency_ms": 10.0}
    suites = [
        {"suite": "core", "corruption": "gaussian_blur", "severity": 1, "metrics": {"primary_metric": 0.78, "latency_ms": 12.0}},
        {"suite": "core", "corruption": "jpeg_compression", "severity": 3, "metrics": {"primary_metric": 0.65, "latency_ms": 14.0}},
    ]
    summary = compute_regression_summary(baseline, suites, "mAP", 0.05)
    assert summary.has_regression is True
    assert summary.worst_suite is not None
    assert summary.worst_delta > 0.1
