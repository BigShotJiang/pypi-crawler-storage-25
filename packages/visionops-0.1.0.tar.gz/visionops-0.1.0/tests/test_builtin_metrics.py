from pathlib import Path

from visionguard.builtin_metrics import compute_yolo_metrics


def test_compute_yolo_metrics_reads_prediction_json_and_gt(tmp_path: Path) -> None:
    pred_dir = tmp_path / "pred"
    gt_dir = tmp_path / "gt"
    pred_dir.mkdir()
    gt_dir.mkdir()

    (pred_dir / "img1.json").write_text(
        """{
  "image": "img1.jpg",
  "size": {"width": 100, "height": 100},
  "detections": [{"class_id": 0, "bbox_xyxy": [10, 10, 40, 40]}]
}""",
        encoding="utf-8",
    )
    (gt_dir / "img1.txt").write_text("0 0.25 0.25 0.30 0.30\n", encoding="utf-8")

    metrics = compute_yolo_metrics(pred_dir=pred_dir, gt_dir=gt_dir)
    assert metrics["primary_metric"] > 0
    assert metrics["tp"] >= 1
