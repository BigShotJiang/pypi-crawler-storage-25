from pathlib import Path

from visionguard.report_html import convert_report_md_to_html


def test_convert_report_md_to_html_creates_visualizable_file(tmp_path: Path) -> None:
    report_md = tmp_path / "report.md"
    report_md.write_text(
        "\n".join(
            [
                "# visionguard Report",
                "",
                "## 1. Repo info",
                "- Repo: `foo/bar`",
                "",
                "## 4. Per-suite degradation table",
                "| Suite | Corruption | Severity | Metric | Delta |",
                "|---|---:|---:|---:|---:|",
                "| core | blur | 1 | 0.7000 | 0.1200 |",
            ]
        ),
        encoding="utf-8",
    )

    summary_json = tmp_path / "summary.json"
    summary_json.write_text(
        """{
  "task_type": "detection",
  "baseline_metric": 0.81,
  "worst_delta": 0.22,
  "worst_suite": "core/motion_blur/s2",
  "severity": "high",
  "stage_localization": {"stage": "preprocessing-sensitive"},
  "top_regressions": [{"suite_label": "core/motion_blur/s2", "delta": 0.22}]
}""",
        encoding="utf-8",
    )
    report_html = convert_report_md_to_html(report_md, summary_json_path=summary_json)
    text = report_html.read_text(encoding="utf-8")
    assert report_html.exists()
    assert "<html" in text.lower()
    assert "<table>" in text.lower()
    assert "visionguard report" in text.lower()
    assert "top regressions" in text.lower()
