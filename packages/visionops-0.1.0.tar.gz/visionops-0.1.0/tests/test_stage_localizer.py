from visionguard.analysis.stage_localizer import localize_failure_stage


def test_stage_localizer_env_issue_when_baseline_fails() -> None:
    stage = localize_failure_stage(
        regression_rows=[],
        baseline_run_ok=False,
        run_logs=["ModuleNotFoundError: cv2"],
    )
    assert "environment" in stage.stage
    assert stage.confidence > 0.8
