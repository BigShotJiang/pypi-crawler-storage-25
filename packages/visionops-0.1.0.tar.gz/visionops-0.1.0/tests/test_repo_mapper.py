from pathlib import Path

from visionguard.agent.repo_mapper import RepoMapperAgent


def test_repo_mapper_uses_content_and_instruction_context(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()

    (repo / "CLAW.md").write_text("# CLAW\nFocus on preprocess and parser stages.\n", encoding="utf-8")
    (repo / "runner.py").write_text(
        "\n".join(
            [
                "import argparse",
                "from transforms_custom import preprocess",
                "",
                "def main():",
                "    parser = argparse.ArgumentParser()",
                "    parser.add_argument('--input')",
                "",
                "if __name__ == '__main__':",
                "    main()",
            ]
        ),
        encoding="utf-8",
    )
    (repo / "transforms_custom.py").write_text(
        "import cv2\n\ndef preprocess(img):\n    return cv2.resize(img, (640, 640))\n",
        encoding="utf-8",
    )
    (repo / "rules_engine.py").write_text(
        "import json\n\ndef parse_output(payload):\n    return json.loads(payload)\n",
        encoding="utf-8",
    )
    (repo / "detector_core.py").write_text(
        "class Detector:\n    def predict(self, x):\n        return x\n",
        encoding="utf-8",
    )

    mapped = RepoMapperAgent(llm=None).map_repo(repo)

    assert "runner.py" in mapped.entrypoints
    assert "transforms_custom.py" in mapped.preprocess_files
    assert "rules_engine.py" in mapped.parser_files
    assert "detector_core.py" in mapped.model_files
    assert "CLAW.md" in mapped.setup_files
    assert "context files" in mapped.summary
