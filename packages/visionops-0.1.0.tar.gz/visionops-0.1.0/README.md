# VisionOps-AI

`visionops` is a CLI-first application for pre-deployment reliability testing and root-cause analysis (RCA) of computer-vision pipelines and repositories.

It is designed to answer not only _whether_ performance drops under corruption, but also _where_ the failure likely starts in the pipeline and what to fix next.

## What it does

- Runs a baseline pipeline in a sandbox-style workspace.
- Generates corruption suites (blur, occlusion, low light, compression, crop truncation, perspective warp, noise).
- Re-runs pipeline and metrics on corrupted datasets.
- Compares baseline vs suite metrics and detects regressions.
- Performs stage localization using runtime evidence (metrics, logs, execution behavior).
- Uses AI agents for repo mapping, RCA, and fix recommendations.
- Writes `summary.json`, `artifact_manifest.json`, `report.md`, and `report.html`.

A key differentiator in Visionops is repository understanding. Before generating RCA hypotheses, the system builds a lightweight structural map of the target codebase (entry points, pipeline stages, likely data flow, and high-signal files) and combines that map with runtime evidence from regressions, logs, and command outcomes. This repo-aware context helps it produce recommendations tied to real files and likely failure boundaries instead of generic “check your model” advice. In practice, that means faster triage, more actionable fixes, and better trust in the output because each hypothesis is grounded in both observed behavior and code structure.

## Install

```bash
python -m pip install -e ".[dev]"
```

## Environment variables and `.env`

The CLI loads a `.env` file from the current working directory (or the nearest parent directory) on startup using [python-dotenv](https://github.com/theskumar/python-dotenv). Variables already set in your shell take precedence over entries in `.env`.

Copy `.env.sample` to `.env` in your project root and fill in values as needed:

- `GEMINI_API_KEY` — optional; enables Gemini-backed repo mapping, RCA, and fix suggestions.
- `GITHUB_APP_PRIVATE_KEY` — optional; used for private-repo GitHub App flows.
- `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_DEFAULT_REGION` — optional; for `aws-run` and related tooling.

If `GEMINI_API_KEY` is unset (in both the environment and `.env`), agents use deterministic fallback logic.

## CLI commands

### 1) Create starter config

```bash
visionops init-config --path config.yaml
```
### 2) Autogenerate config

```bash
visionops autoconfig --repo-path /path/to/cv-repo --output config.yaml
```
This scans a repository and infers:

- install command
- baseline run command
- metrics command
- dataset and ground-truth paths
- task type and suite defaults

Review the generated file before running.

### 3) Validate config

```bash
visionops validate-config --config config.yaml
```

To preview without writing and inspect confidence metadata:

```bash
visionops autoconfig --repo-path /path/to/cv-repo --dry-run --explain
```

### 4) Run full local prototype (primary path)

```bash
visionops local-run --repo-path /path/to/cv-repo --config config.yaml
```

This performs:

1. sandbox copy of repo
2. install command
3. baseline run + metrics
4. corruption dataset generation
5. per-suite reruns + metrics
6. regression analysis
7. stage localization
8. repo mapping + RCA + fix suggestions
9. report generation

### 5) Run AWS path (secondary path)

```bash
visionops aws-run --repo owner/repo --config config.yaml
```

Behavior:

- checks AWS credentials/config
- starts CodeBuild build
- polls status until terminal state
- returns build id, status, logs, artifact location
- private repo support uses GitHub App auth (no PAT)

If setup is incomplete, command exits gracefully with actionable guidance.

### 6) Pretty print an existing report

```bash
visionops report --path ./visionguard_output_YYYYMMDDTHHMMSSZ
```

### 7) Environment health check

```bash
visionops doctor --config config.yaml --repo-path /path/to/cv-repo
```

This validates config, checks key environment variables, and runs autoconfig sanity checks.

### 8) Built-in metrics fallback

If a target repo does not provide a metrics script, you can use built-in YOLO-format scoring:

```bash
visionops builtin-metrics --pred /path/to/pred --gt /path/to/gt
```

### 9) Convert markdown report to HTML manually

HTML conversion now runs automatically during report generation. For existing output folders:

```bash
python report_to_html.py --path ./visionguard_output_YYYYMMDDTHHMMSSZ
```

## Config

Use `visionguard.sample.yaml` as baseline (or copy it to `config.yaml`). Placeholders supported in run/metrics commands:

- `{input_dir}`
- `{output_dir}`
- `{gt_dir}`

## GitHub repo support

GitHub App helper functions in the internal package module `visionguard/github_app.py`:

- `generate_jwt()`
- `get_installation_token()`
- `build_authenticated_clone_url()`

This enables authenticated clone URLs for private repos without PATs.

## AI-assisted RCA approach

Three AI agents:

- `RepoMapperAgent`: scans repo and identifies likely pipeline files/stages.
- `RCAAgent`: combines runtime evidence + repo map into ranked hypotheses.
- `FixAgent`: converts rule-based remediations into concrete fix suggestions.

By default the application uses Gemini 2.5 Pro via OpenAI-compatible API shape. Set `GEMINI_API_KEY` in your environment or in `.env` (see above). If it is missing, all agents use deterministic fallback logic.

## Evidence grounding

RCA is grounded in:

- metric deltas
- per-suite regressions
- logs and return codes
- stage localization heuristics
- repo-aware file mapping

The LLM is never the sole source of truth.

## AWS sandbox expectations

Before `aws-run`:

1. configure AWS credentials (`aws configure` or env vars)
2. create a CodeBuild project named in config (`aws.codebuild_project`)
3. ensure IAM allows CodeBuild + S3 artifact access
4. optionally configure GitHub App values for private repos

`buildspec.sample.yml` is included as a starting template.

## Tests

```bash
pytest -q
```

Current tests cover:

- autoconfig inference
- config parsing
- corruption generation
- regression comparison
- stage localization heuristic

## License

Proprietary. Copyright © 2026 VisionOps AI Lab. All rights reserved. See [`LICENSE`](LICENSE) for terms.

